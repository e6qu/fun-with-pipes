
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-reference-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 0f 01 00 	mov    0x10fd1(%rip),%rax        # 13fe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 0d 01 00    	push   0x10df2(%rip)        # 13e18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 0d 01 00    	jmp    *0x10df4(%rip)        # 13e20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 0c 01 00    	jmp    *0x10c66(%rip)        # 13ff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e 0a 01 00    	jmp    *0x10a8e(%rip)        # 13e28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 0a 01 00    	jmp    *0x10a86(%rip)        # 13e30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e 0a 01 00    	jmp    *0x10a7e(%rip)        # 13e38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 0a 01 00    	jmp    *0x10a76(%rip)        # 13e40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e 0a 01 00    	jmp    *0x10a6e(%rip)        # 13e48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 0a 01 00    	jmp    *0x10a66(%rip)        # 13e50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e 0a 01 00    	jmp    *0x10a5e(%rip)        # 13e58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 0a 01 00    	jmp    *0x10a56(%rip)        # 13e60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e 0a 01 00    	jmp    *0x10a4e(%rip)        # 13e68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 0a 01 00    	jmp    *0x10a46(%rip)        # 13e70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e 0a 01 00    	jmp    *0x10a3e(%rip)        # 13e78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 0a 01 00    	jmp    *0x10a36(%rip)        # 13e80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e 0a 01 00    	jmp    *0x10a2e(%rip)        # 13e88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 0a 01 00    	jmp    *0x10a26(%rip)        # 13e90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e 0a 01 00    	jmp    *0x10a1e(%rip)        # 13e98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 0a 01 00    	jmp    *0x10a16(%rip)        # 13ea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e 0a 01 00    	jmp    *0x10a0e(%rip)        # 13ea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 0a 01 00    	jmp    *0x10a06(%rip)        # 13eb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe 09 01 00    	jmp    *0x109fe(%rip)        # 13eb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 09 01 00    	jmp    *0x109f6(%rip)        # 13ec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee 09 01 00    	jmp    *0x109ee(%rip)        # 13ec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 09 01 00    	jmp    *0x109e6(%rip)        # 13ed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de 09 01 00    	jmp    *0x109de(%rip)        # 13ed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 09 01 00    	jmp    *0x109d6(%rip)        # 13ee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce 09 01 00    	jmp    *0x109ce(%rip)        # 13ee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 09 01 00    	jmp    *0x109c6(%rip)        # 13ef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be 09 01 00    	jmp    *0x109be(%rip)        # 13ef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 09 01 00    	jmp    *0x109b6(%rip)        # 13f00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae 09 01 00    	jmp    *0x109ae(%rip)        # 13f08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 09 01 00    	jmp    *0x109a6(%rip)        # 13f10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e 09 01 00    	jmp    *0x1099e(%rip)        # 13f18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 09 01 00    	jmp    *0x10996(%rip)        # 13f20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e 09 01 00    	jmp    *0x1098e(%rip)        # 13f28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 09 01 00    	jmp    *0x10986(%rip)        # 13f30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e 09 01 00    	jmp    *0x1097e(%rip)        # 13f38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 09 01 00    	jmp    *0x10976(%rip)        # 13f40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e 09 01 00    	jmp    *0x1096e(%rip)        # 13f48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 09 01 00    	jmp    *0x10966(%rip)        # 13f50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e 09 01 00    	jmp    *0x1095e(%rip)        # 13f58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 09 01 00    	jmp    *0x10956(%rip)        # 13f60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e 09 01 00    	jmp    *0x1094e(%rip)        # 13f68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 09 01 00    	jmp    *0x10946(%rip)        # 13f70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e 09 01 00    	jmp    *0x1093e(%rip)        # 13f78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 09 01 00    	jmp    *0x10936(%rip)        # 13f80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e 09 01 00    	jmp    *0x1092e(%rip)        # 13f88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 09 01 00    	jmp    *0x10926(%rip)        # 13f90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e 09 01 00    	jmp    *0x1091e(%rip)        # 13f98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 09 01 00    	jmp    *0x10916(%rip)        # 13fa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e 09 01 00    	jmp    *0x1090e(%rip)        # 13fa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 09 01 00    	jmp    *0x10906(%rip)        # 13fb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe 08 01 00    	jmp    *0x108fe(%rip)        # 13fb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 08 01 00    	jmp    *0x108f6(%rip)        # 13fc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee 08 01 00    	jmp    *0x108ee(%rip)        # 13fc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 c9 00 00 	lea    0xc9b8(%rip),%r9        # 100cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 c9 00 00 	lea    0xc9b5(%rip),%r8        # 100d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 6b fc ff ff       	call   33c0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 66 fc ff ff       	call   33c0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 ed 00 00 	lea    0xed01(%rip),%rax        # 12480 <fwp_fn_table>
    377f:	48 89 05 32 ad 06 00 	mov    %rax,0x6ad32(%rip)        # 6e4b8 <fwp_fns>
    3786:	48 8b 05 b3 08 01 00 	mov    0x108b3(%rip),%rax        # 14040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 2c ad 06 00 	mov    %rax,0x6ad2c(%rip)        # 6e4c0 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e cb 00 00 	lea    0xcb4e(%rip),%rdi        # 102ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 08 01 00 	mov    0x10838(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 3f b1 00 00 	lea    0xb13f(%rip),%rdx        # e9a0 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 07 01 00 	mov    0x107a3(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 18 08 02 00    	mov    0x20818(%rip),%eax        # 240c0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe c9 00 00 	lea    0xc9fe(%rip),%rdi        # 102f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 46 d3 00 00 	lea    0xd346(%rip),%rdi        # 10c50 <_IO_stdin_used+0xc50>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 00 d3 00 00 	lea    0xd300(%rip),%rdi        # 10c28 <_IO_stdin_used+0xc28>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d c4 d2 00 00 	lea    0xd2c4(%rip),%rdi        # 10bf8 <_IO_stdin_used+0xbf8>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d 90 d2 00 00 	lea    0xd290(%rip),%rdi        # 10bd0 <_IO_stdin_used+0xbd0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b 06 01 00    	call   *0x1065b(%rip)        # 13fd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 06 01 00 	lea    0x106a1(%rip),%rdi        # 14028 <__TMC_END__>
    3987:	48 8d 05 9a 06 01 00 	lea    0x1069a(%rip),%rax        # 14028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e 06 01 00 	mov    0x1063e(%rip),%rax        # 13fd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 06 01 00 	lea    0x10671(%rip),%rdi        # 14028 <__TMC_END__>
    39b7:	48 8d 35 6a 06 01 00 	lea    0x1066a(%rip),%rsi        # 14028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d 06 01 00 	mov    0x1060d(%rip),%rax        # 13fe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d 06 01 00 00 	cmpb   $0x0,0x1066d(%rip)        # 14068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea 05 01 00 	cmpq   $0x0,0x105ea(%rip)        # 13ff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 05 01 00 	mov    0x105f6(%rip),%rdi        # 14008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 06 01 00 01 	movb   $0x1,0x10645(%rip)        # 14068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 d7 05 05 00 	lea    0x505d7(%rip),%r8        # 541e0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 7b 05 05 00 	lea    0x5057b(%rip),%rcx        # 541a0 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 4f 05 05 00 	lea    0x5054f(%rip),%rcx        # 54180 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 81 05 05 00 	lea    0x50581(%rip),%rcx        # 541c0 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 90 05 05 	movdqa 0x50590(%rip),%xmm0        # 541f0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 78 05 05 	paddq  0x50578(%rip),%xmm0        # 541e0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 df 04 05 00 	cmp    %rax,0x504df(%rip)        # 54160 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 d5 04 05 	movq   %xmm0,0x504d5(%rip)        # 54160 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 7e 04 02 00 	add    0x2047e(%rip),%rdx        # 24130 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 6c 04 02 00 	add    0x2046c(%rip),%rax        # 24130 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args161>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d b9 a7 06 00 	mov    0x6a7b9(%rip),%rdi        # 6e4c0 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 24 03 01 00 	mov    0x10324(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d 11 03 01 00 	mov    0x10311(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 f1 8a 06 00 	mov    0x68af1(%rip),%rax        # 6c840 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 39 84 06 00 	mov    0x68439(%rip),%rax        # 6c208 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 25 84 06 00 	sub    0x68425(%rip),%rax        # 6c200 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 1d cf 00 00 	lea    0xcf1d(%rip),%rsi        # 10d30 <msg.8>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 c1 00 00 	lea    0xc1c5(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d 12 02 01 00 	mov    0x10212(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 cb 9d 06 00 	mov    0x69dcb(%rip),%rax        # 6dc50 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 c4 9d 06 00 	lea    0x69dc4(%rip),%r8        # 6dc50 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d a5 9d 06 00 	mov    0x69da5(%rip),%rbx        # 6dc38 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d b5 9d 06 00 	mov    0x69db5(%rip),%rcx        # 6dc58 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 51 9d 06 00 	mov    0x69d51(%rip),%rdi        # 6dc40 <fwp_heap+0x13e0>
    3eef:	48 29 35 9a 9d 06 00 	sub    %rsi,0x69d9a(%rip)        # 6dc90 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 2a 9d 06 00 	mov    0x69d2a(%rip),%rax        # 6dc30 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d e0 9c 06 00 	add    0x69ce0(%rip),%rdi        # 6dc10 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ee 9c 06 00 	mov    0x69cee(%rip),%rsi        # 6dc40 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 fc 9c 06 00 	mov    0x69cfc(%rip),%rax        # 6dc58 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 ab 9c 06 00 	mov    %r12,0x69cab(%rip)        # 6dc40 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 99 9c 06 00 	mov    %rbp,0x69c99(%rip)        # 6dc38 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 7e 9c 06 00 	cmp    %rdi,0x69c7e(%rip)        # 6dc28 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 75 9c 06 00 	mov    %rdi,0x69c75(%rip)        # 6dc28 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d b9 9c 06 00 	sub    %rdi,0x69cb9(%rip)        # 6dc90 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 61 9c 06 00 	mov    0x69c61(%rip),%rax        # 6dc48 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 5a 9c 06 00 	lea    0x69c5a(%rip),%r8        # 6dc48 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ef c6 00 00 	lea    0xc6ef(%rip),%rdx        # 106f8 <_IO_stdin_used+0x6f8>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 42 00 01 00 	mov    0x10042(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 9d ff 00 00 	mov    0xff9d(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 bf 00 00 	lea    0xbf34(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d 09 87 06 00 	cmp    0x68709(%rip),%rdi        # 6c840 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 cf 86 06 00 	mov    0x686cf(%rip),%rax        # 6c820 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d ad 86 06 00 	mov    %rdi,0x686ad(%rip)        # 6c820 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 89 86 06 00 	mov    %rdi,0x68689(%rip)        # 6c828 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 5f c0 00 00 	lea    0xc05f(%rip),%rsi        # 10240 <_IO_stdin_used+0x240>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 be 00 00 	lea    0xbe27(%rip),%rsi        # 1001c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 b6 ff 04 	movdqa 0x4ffb6(%rip),%xmm0        # 541f0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 9e ff 04 	paddq  0x4ff9e(%rip),%xmm0        # 541e0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 c4 fe 01 00 	mov    0x1fec4(%rip),%r8        # 24138 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d de fe 04 00 	mov    0x4fede(%rip),%rcx        # 54160 <ad_raw_total_peak>
    4282:	48 8b 3d d7 fd 00 00 	mov    0xfdd7(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 b5 c4 00 00 	lea    0xc4b5(%rip),%rdx        # 10748 <_IO_stdin_used+0x748>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d 21 ff 04 00 	lea    0x4ff21(%rip),%r15        # 541c0 <ad_raw_peak>
    429f:	4c 8d 35 da fe 04 00 	lea    0x4feda(%rip),%r14        # 54180 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 bd 00 00 	lea    0xbd79(%rip),%rax        # 1002b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 f9 00 	movq   0xf956(%rip),%xmm0        # 13c10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d df fe 04 00 	lea    0x4fedf(%rip),%r13        # 541a0 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f bd 00 00 	lea    0xbd6f(%rip),%rax        # 1003c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 f9 00 	movq   0xf936(%rip),%xmm0        # 13c18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 53 fd 00 00 	mov    0xfd53(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c bd 00 00 	lea    0xbd0c(%rip),%rcx        # 10020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 8d c4 00 00 	lea    0xc48d(%rip),%rdx        # 107a8 <_IO_stdin_used+0x7a8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 24 fd 00 00 	mov    0xfd24(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 bc 00 00 	lea    0xbcf8(%rip),%rdi        # 10045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d e6 fd 01 00 	cmpq   $0x0,0x1fde6(%rip)        # 24140 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 fd fd 01 00 	mov    0x1fdfd(%rip),%r8        # 24160 <ad_raw_checkpoints>
    4363:	4c 8b 0d fe fd 01 00 	mov    0x1fdfe(%rip),%r9        # 24168 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d ef fd 01 00 	lea    0x1fdef(%rip),%rbx        # 24160 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 bc 00 00 	lea    0xbcf4(%rip),%rcx        # 1006c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 f1 fd 01 00 	mov    0x1fdf1(%rip),%rax        # 24170 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a bc 00 00 	lea    0xbc9a(%rip),%r12        # 10020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d a9 fc 00 00 	mov    0xfca9(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 29 c4 00 00 	lea    0xc429(%rip),%rdx        # 107e8 <_IO_stdin_used+0x7e8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 73 fd 01 00 	cmp    0x1fd73(%rip),%rbp        # 24140 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 78 fc 00 00 	mov    0xfc78(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b bc 00 00 	lea    0xbc5b(%rip),%rdi        # 10059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 43 fc 00 00 	mov    0xfc43(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 84 c3 00 00 	lea    0xc384(%rip),%rdx        # 107a8 <_IO_stdin_used+0x7a8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 bc 00 00 	lea    0xbc40(%rip),%rcx        # 1006c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d da c2 00 00 	lea    0xc2da(%rip),%rdi        # 10720 <_IO_stdin_used+0x720>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d e8 fb 00 00 	mov    0xfbe8(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df bb 00 00 	lea    0xbbdf(%rip),%rdx        # 1005e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d d0 fb 00 00 	mov    0xfbd0(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d e1 fa 00 00 	mov    0xfae1(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 ba 00 00 	lea    0xba78(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 ba 00 00 	lea    0xbac0(%rip),%rdi        # 1006d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 ba 00 00 	lea    0xba48(%rip),%rdi        # 10087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d d8 c1 00 00 	lea    0xc1d8(%rip),%rdi        # 10828 <_IO_stdin_used+0x828>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 e0 c6 00 	movdqa 0xc6e0(%rip),%xmm0        # 10d50 <msg.8+0x20>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 ea 9d 06 00 	add    0x69dea(%rip),%rax        # 6e4b8 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 2c c1 00 00 	lea    0xc12c(%rip),%rdi        # 10850 <_IO_stdin_used+0x850>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 e5 f9 01 00 	cmp    %rax,0x1f9e5(%rip)        # 24128 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 e0 f9 01 00 	add    0x1f9e0(%rip),%rax        # 24130 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 15 c1 00 00 	lea    0xc115(%rip),%rdi        # 10880 <_IO_stdin_used+0x880>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 b9 00 00 	lea    0xb920(%rip),%r8        # 100a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 b7 00 00 	lea    0xb775(%rip),%r8        # 100b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 b6 00 00 	lea    0xb612(%rip),%r8        # 100a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea b3 00 00 	lea    0xb3ea(%rip),%rdi        # 100b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 9a b5 00 00 	lea    0xb59a(%rip),%rsi        # 10288 <_IO_stdin_used+0x288>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d c5 8e 06 00 	mov    0x68ec5(%rip),%r9        # 6dc28 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 1e 8f 06 00 	mov    0x68f1e(%rip),%r8        # 6dc88 <fwp_heap+0x1428>
    4d6a:	48 8d 15 5f bb 00 00 	lea    0xbb5f(%rip),%rdx        # 108d0 <_IO_stdin_used+0x8d0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d 06 8f 06 00 	mov    0x68f06(%rip),%rcx        # 6dc80 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d 14 8f 06 	movsd  0x68f14(%rip),%xmm1        # 6dca0 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 04 8f 06 	movsd  0x68f04(%rip),%xmm0        # 6dc98 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d c5 f2 00 00 	mov    0xf2c5(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 88 bf 00 	movdqa 0xbf88(%rip),%xmm0        # 10d60 <msg.8+0x30>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 bf 89 06 00 	lea    0x689bf(%rip),%rax        # 6d7a0 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 b1 bf 00 	movdqa 0xbfb1(%rip),%xmm2        # 10da0 <msg.8+0x70>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 65 89 06 00 	movaps %xmm0,0x68965(%rip)        # 6d760 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 6d bf 00 	movdqa 0xbf6d(%rip),%xmm0        # 10d70 <msg.8+0x40>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 f3 8d 06 00 01 	movl   $0x1,0x68df3(%rip)        # 6dc04 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 53 89 06 00 	movaps %xmm0,0x68953(%rip)        # 6d770 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 5b bf 00 	movdqa 0xbf5b(%rip),%xmm0        # 10d80 <msg.8+0x50>
    4e24:	00 
    4e25:	0f 29 05 54 89 06 00 	movaps %xmm0,0x68954(%rip)        # 6d780 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 5c bf 00 	movdqa 0xbf5c(%rip),%xmm0        # 10d90 <msg.8+0x60>
    4e33:	00 
    4e34:	0f 29 05 55 89 06 00 	movaps %xmm0,0x68955(%rip)        # 6d790 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 d5 79 06 00 	lea    0x679d5(%rip),%r8        # 6c860 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 f0 8c 06 00 	mov    %rax,0x68cf0(%rip)        # 6dc18 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 ce 8c 06 00 	mov    %r12,0x68cce(%rip)        # 6dc20 <fwp_heap+0x13c0>
    4f52:	48 89 05 b7 8c 06 00 	mov    %rax,0x68cb7(%rip)        # 6dc10 <fwp_heap+0x13b0>
    4f59:	48 89 1d d0 8c 06 00 	mov    %rbx,0x68cd0(%rip)        # 6dc30 <fwp_heap+0x13d0>
    4f60:	48 89 35 f9 8c 06 00 	mov    %rsi,0x68cf9(%rip)        # 6dc60 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 b1 00 00 	lea    0xb174(%rip),%rdi        # 100ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 d8 8c 06 00 	mov    %rax,0x68cd8(%rip)        # 6dc58 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 5c 8c 06 00    	mov    %eax,0x68c5c(%rip)        # 6dc08 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <caf61>:
    4fc0:	8b 15 da f0 00 00    	mov    0xf0da(%rip),%edx        # 140a0 <st.4>
    4fc6:	85 d2                	test   %edx,%edx
    4fc8:	74 0e                	je     4fd8 <caf61+0x18>
    4fca:	48 8b 05 c7 f0 00 00 	mov    0xf0c7(%rip),%rax        # 14098 <v.3>
    4fd1:	c3                   	ret
    4fd2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4fd8:	8b 05 b2 f0 00 00    	mov    0xf0b2(%rip),%eax        # 14090 <st.2>
    4fde:	85 c0                	test   %eax,%eax
    4fe0:	74 1e                	je     5000 <caf61+0x40>
    4fe2:	48 8b 05 9f f0 00 00 	mov    0xf09f(%rip),%rax        # 14088 <v.1>
    4fe9:	48 89 05 a8 f0 00 00 	mov    %rax,0xf0a8(%rip)        # 14098 <v.3>
    4ff0:	c7 05 a6 f0 00 00 01 	movl   $0x1,0xf0a6(%rip)        # 140a0 <st.4>
    4ff7:	00 00 00 
    4ffa:	c3                   	ret
    4ffb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5000:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    5007:	00 f0 3f 
    500a:	c7 05 7c f0 00 00 01 	movl   $0x1,0xf07c(%rip)        # 14090 <st.2>
    5011:	00 00 00 
    5014:	48 89 05 6d f0 00 00 	mov    %rax,0xf06d(%rip)        # 14088 <v.1>
    501b:	eb cc                	jmp    4fe9 <caf61+0x29>
    501d:	0f 1f 00             	nopl   (%rax)

0000000000005020 <fwp_wake_io>:
    5020:	48 8b 07             	mov    (%rdi),%rax
    5023:	48 85 c0             	test   %rax,%rax
    5026:	0f 84 f4 00 00 00    	je     5120 <fwp_wake_io+0x100>
    502c:	53                   	push   %rbx
    502d:	4c 8b 05 ec 77 06 00 	mov    0x677ec(%rip),%r8        # 6c820 <fwp_ready_tail>
    5034:	49 89 f9             	mov    %rdi,%r9
    5037:	48 89 c2             	mov    %rax,%rdx
    503a:	45 31 db             	xor    %r11d,%r11d
    503d:	45 31 d2             	xor    %r10d,%r10d
    5040:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5044:	eb 71                	jmp    50b7 <fwp_wake_io+0x97>
    5046:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    504d:	00 00 00 
    5050:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    5057:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    505e:	48 85 c9             	test   %rcx,%rcx
    5061:	74 07                	je     506a <fwp_wake_io+0x4a>
    5063:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    506a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5071:	00 00 00 00 
    5075:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    507c:	49 8b 01             	mov    (%r9),%rax
    507f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5083:	75 2a                	jne    50af <fwp_wake_io+0x8f>
    5085:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5089:	75 24                	jne    50af <fwp_wake_io+0x8f>
    508b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    508f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5096:	00 00 00 00 
    509a:	4d 85 c0             	test   %r8,%r8
    509d:	74 51                	je     50f0 <fwp_wake_io+0xd0>
    509f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    50a6:	49 89 d0             	mov    %rdx,%r8
    50a9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    50af:	48 89 c2             	mov    %rax,%rdx
    50b2:	48 85 c0             	test   %rax,%rax
    50b5:	74 49                	je     5100 <fwp_wake_io+0xe0>
    50b7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    50be:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    50c2:	48 85 ff             	test   %rdi,%rdi
    50c5:	74 b8                	je     507f <fwp_wake_io+0x5f>
    50c7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    50ce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    50d5:	48 85 f6             	test   %rsi,%rsi
    50d8:	0f 85 72 ff ff ff    	jne    5050 <fwp_wake_io+0x30>
    50de:	48 89 0f             	mov    %rcx,(%rdi)
    50e1:	e9 78 ff ff ff       	jmp    505e <fwp_wake_io+0x3e>
    50e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    50ed:	00 00 00 
    50f0:	48 89 d3             	mov    %rdx,%rbx
    50f3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    50f9:	eb ab                	jmp    50a6 <fwp_wake_io+0x86>
    50fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5100:	45 84 db             	test   %r11b,%r11b
    5103:	74 07                	je     510c <fwp_wake_io+0xec>
    5105:	48 89 1d 1c 77 06 00 	mov    %rbx,0x6771c(%rip)        # 6c828 <fwp_ready_head>
    510c:	45 84 d2             	test   %r10b,%r10b
    510f:	74 07                	je     5118 <fwp_wake_io+0xf8>
    5111:	4c 89 05 08 77 06 00 	mov    %r8,0x67708(%rip)        # 6c820 <fwp_ready_tail>
    5118:	5b                   	pop    %rbx
    5119:	c3                   	ret
    511a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5120:	c3                   	ret
    5121:	0f 1f 40 00          	nopl   0x0(%rax)
    5125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    512c:	00 00 00 00 

0000000000005130 <ad_raw_free.part.0>:
    5130:	48 8d 0d c9 f0 04 00 	lea    0x4f0c9(%rip),%rcx        # 54200 <ad_raw_blocks>
    5137:	31 c0                	xor    %eax,%eax
    5139:	48 89 ca             	mov    %rcx,%rdx
    513c:	eb 12                	jmp    5150 <ad_raw_free.part.0+0x20>
    513e:	66 90                	xchg   %ax,%ax
    5140:	48 83 c0 01          	add    $0x1,%rax
    5144:	48 83 c2 18          	add    $0x18,%rdx
    5148:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    514e:	74 40                	je     5190 <ad_raw_free.part.0+0x60>
    5150:	48 3b 3a             	cmp    (%rdx),%rdi
    5153:	75 eb                	jne    5140 <ad_raw_free.part.0+0x10>
    5155:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5159:	66 0f ef c0          	pxor   %xmm0,%xmm0
    515d:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5161:	48 8d 0d 78 f0 04 00 	lea    0x4f078(%rip),%rcx        # 541e0 <ad_raw_live>
    5168:	8b 70 10             	mov    0x10(%rax),%esi
    516b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5172:	00 
    5173:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5177:	48 2b 50 08          	sub    0x8(%rax),%rdx
    517b:	0f 11 00             	movups %xmm0,(%rax)
    517e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5182:	e9 29 e2 ff ff       	jmp    33b0 <free@plt>
    5187:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    518e:	00 00 
    5190:	48 83 ec 08          	sub    $0x8,%rsp
    5194:	48 8d 3d 62 af 00 00 	lea    0xaf62(%rip),%rdi        # 100fd <_IO_stdin_used+0xfd>
    519b:	e8 60 ee ff ff       	call   4000 <ad_raw_fail>

00000000000051a0 <fwp_tape_buffers_dispose>:
    51a0:	53                   	push   %rbx
    51a1:	48 89 fb             	mov    %rdi,%rbx
    51a4:	48 8b 3f             	mov    (%rdi),%rdi
    51a7:	48 85 ff             	test   %rdi,%rdi
    51aa:	74 05                	je     51b1 <fwp_tape_buffers_dispose+0x11>
    51ac:	e8 7f ff ff ff       	call   5130 <ad_raw_free.part.0>
    51b1:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    51b5:	48 85 ff             	test   %rdi,%rdi
    51b8:	74 05                	je     51bf <fwp_tape_buffers_dispose+0x1f>
    51ba:	e8 71 ff ff ff       	call   5130 <ad_raw_free.part.0>
    51bf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    51c3:	48 85 ff             	test   %rdi,%rdi
    51c6:	74 05                	je     51cd <fwp_tape_buffers_dispose+0x2d>
    51c8:	e8 63 ff ff ff       	call   5130 <ad_raw_free.part.0>
    51cd:	66 0f ef c0          	pxor   %xmm0,%xmm0
    51d1:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    51d8:	00 
    51d9:	0f 11 03             	movups %xmm0,(%rbx)
    51dc:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    51e0:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    51e4:	5b                   	pop    %rbx
    51e5:	c3                   	ret
    51e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51ed:	00 00 00 

00000000000051f0 <ad_raw_realloc>:
    51f0:	41 55                	push   %r13
    51f2:	41 54                	push   %r12
    51f4:	55                   	push   %rbp
    51f5:	53                   	push   %rbx
    51f6:	48 83 ec 08          	sub    $0x8,%rsp
    51fa:	48 85 f6             	test   %rsi,%rsi
    51fd:	0f 84 a6 00 00 00    	je     52a9 <ad_raw_realloc+0xb9>
    5203:	4c 8d 25 f6 ef 04 00 	lea    0x4eff6(%rip),%r12        # 54200 <ad_raw_blocks>
    520a:	48 89 f5             	mov    %rsi,%rbp
    520d:	41 89 d5             	mov    %edx,%r13d
    5210:	31 db                	xor    %ebx,%ebx
    5212:	4c 89 e0             	mov    %r12,%rax
    5215:	eb 1a                	jmp    5231 <ad_raw_realloc+0x41>
    5217:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    521e:	00 00 
    5220:	48 83 c3 01          	add    $0x1,%rbx
    5224:	48 83 c0 18          	add    $0x18,%rax
    5228:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    522f:	74 4f                	je     5280 <ad_raw_realloc+0x90>
    5231:	48 3b 38             	cmp    (%rax),%rdi
    5234:	75 ea                	jne    5220 <ad_raw_realloc+0x30>
    5236:	48 85 ff             	test   %rdi,%rdi
    5239:	74 0b                	je     5246 <ad_raw_realloc+0x56>
    523b:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    523f:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    5244:	75 57                	jne    529d <ad_raw_realloc+0xad>
    5246:	48 89 ee             	mov    %rbp,%rsi
    5249:	e8 62 e3 ff ff       	call   35b0 <realloc@plt>
    524e:	49 89 c2             	mov    %rax,%r10
    5251:	48 85 c0             	test   %rax,%rax
    5254:	74 16                	je     526c <ad_raw_realloc+0x7c>
    5256:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    525a:	44 89 e9             	mov    %r13d,%ecx
    525d:	48 89 ea             	mov    %rbp,%rdx
    5260:	4c 89 d6             	mov    %r10,%rsi
    5263:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5267:	e8 94 e9 ff ff       	call   3c00 <ad_raw_record>
    526c:	48 83 c4 08          	add    $0x8,%rsp
    5270:	4c 89 d0             	mov    %r10,%rax
    5273:	5b                   	pop    %rbx
    5274:	5d                   	pop    %rbp
    5275:	41 5c                	pop    %r12
    5277:	41 5d                	pop    %r13
    5279:	c3                   	ret
    527a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5280:	48 85 ff             	test   %rdi,%rdi
    5283:	48 8d 05 88 ae 00 00 	lea    0xae88(%rip),%rax        # 10112 <_IO_stdin_used+0x112>
    528a:	48 8d 15 6c ae 00 00 	lea    0xae6c(%rip),%rdx        # 100fd <_IO_stdin_used+0xfd>
    5291:	48 0f 45 c2          	cmovne %rdx,%rax
    5295:	48 89 c7             	mov    %rax,%rdi
    5298:	e8 63 ed ff ff       	call   4000 <ad_raw_fail>
    529d:	48 8d 3d a4 ae 00 00 	lea    0xaea4(%rip),%rdi        # 10148 <_IO_stdin_used+0x148>
    52a4:	e8 57 ed ff ff       	call   4000 <ad_raw_fail>
    52a9:	48 8d 3d 7d ae 00 00 	lea    0xae7d(%rip),%rdi        # 1012d <_IO_stdin_used+0x12d>
    52b0:	e8 4b ed ff ff       	call   4000 <ad_raw_fail>
    52b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    52bc:	00 00 00 00 

00000000000052c0 <fwp_tape_buffers_release>:
    52c0:	f3 0f 1e fa          	endbr64
    52c4:	53                   	push   %rbx
    52c5:	48 89 fb             	mov    %rdi,%rbx
    52c8:	48 83 ec 10          	sub    $0x10,%rsp
    52cc:	48 8b 47 28          	mov    0x28(%rdi),%rax
    52d0:	48 85 c0             	test   %rax,%rax
    52d3:	0f 88 d7 00 00 00    	js     53b0 <fwp_tape_buffers_release+0xf0>
    52d9:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    52dd:	48 85 d2             	test   %rdx,%rdx
    52e0:	0f 88 ca 00 00 00    	js     53b0 <fwp_tape_buffers_release+0xf0>
    52e6:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    52ec:	0f 87 be 00 00 00    	ja     53b0 <fwp_tape_buffers_release+0xf0>
    52f2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    52f6:	b8 00 00 08 00       	mov    $0x80000,%eax
    52fb:	48 c1 e1 03          	shl    $0x3,%rcx
    52ff:	48 29 c8             	sub    %rcx,%rax
    5302:	48 c1 e8 03          	shr    $0x3,%rax
    5306:	48 39 d0             	cmp    %rdx,%rax
    5309:	0f 82 a1 00 00 00    	jb     53b0 <fwp_tape_buffers_release+0xf0>
    530f:	48 8d 3d 4a ae 00 00 	lea    0xae4a(%rip),%rdi        # 10160 <_IO_stdin_used+0x160>
    5316:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    531b:	48 89 14 24          	mov    %rdx,(%rsp)
    531f:	e8 6c e0 ff ff       	call   3390 <getenv@plt>
    5324:	48 8b 14 24          	mov    (%rsp),%rdx
    5328:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    532d:	48 85 c0             	test   %rax,%rax
    5330:	74 09                	je     533b <fwp_tape_buffers_release+0x7b>
    5332:	80 38 30             	cmpb   $0x30,(%rax)
    5335:	0f 84 05 01 00 00    	je     5440 <fwp_tape_buffers_release+0x180>
    533b:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    533f:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    5343:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    5349:	77 71                	ja     53bc <fwp_tape_buffers_release+0xfc>
    534b:	48 8d 3d 8e ed 01 00 	lea    0x1ed8e(%rip),%rdi        # 240e0 <fwp_tape_workspace>
    5352:	48 89 34 24          	mov    %rsi,(%rsp)
    5356:	e8 45 fe ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    535b:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    535f:	48 8b 34 24          	mov    (%rsp),%rsi
    5363:	0f 29 05 76 ed 01 00 	movaps %xmm0,0x1ed76(%rip)        # 240e0 <fwp_tape_workspace>
    536a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    536f:	48 89 35 52 ed 01 00 	mov    %rsi,0x1ed52(%rip)        # 240c8 <fwp_tape_cached_bytes>
    5376:	0f 29 05 73 ed 01 00 	movaps %xmm0,0x1ed73(%rip)        # 240f0 <fwp_tape_workspace+0x10>
    537d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5382:	0f 29 05 77 ed 01 00 	movaps %xmm0,0x1ed77(%rip)        # 24100 <fwp_tape_workspace+0x20>
    5389:	48 8b 43 30          	mov    0x30(%rbx),%rax
    538d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5391:	48 89 05 78 ed 01 00 	mov    %rax,0x1ed78(%rip)        # 24110 <fwp_tape_workspace+0x30>
    5398:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    539f:	00 
    53a0:	0f 11 03             	movups %xmm0,(%rbx)
    53a3:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    53a7:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    53ab:	eb 1e                	jmp    53cb <fwp_tape_buffers_release+0x10b>
    53ad:	0f 1f 00             	nopl   (%rax)
    53b0:	48 8d 3d a9 ad 00 00 	lea    0xada9(%rip),%rdi        # 10160 <_IO_stdin_used+0x160>
    53b7:	e8 d4 df ff ff       	call   3390 <getenv@plt>
    53bc:	48 89 df             	mov    %rbx,%rdi
    53bf:	e8 dc fd ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    53c4:	48 8b 35 fd ec 01 00 	mov    0x1ecfd(%rip),%rsi        # 240c8 <fwp_tape_cached_bytes>
    53cb:	48 6b 15 4d ed 01 00 	imul   $0x68,0x1ed4d(%rip),%rdx        # 24120 <fwp_tapes_cap>
    53d2:	68 
    53d3:	48 3b 15 06 ee 04 00 	cmp    0x4ee06(%rip),%rdx        # 541e0 <ad_raw_live>
    53da:	75 73                	jne    544f <fwp_tape_buffers_release+0x18f>
    53dc:	48 8b 05 05 ee 04 00 	mov    0x4ee05(%rip),%rax        # 541e8 <ad_raw_live+0x8>
    53e3:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    53e7:	48 01 d0             	add    %rdx,%rax
    53ea:	48 03 05 ff ed 04 00 	add    0x4edff(%rip),%rax        # 541f0 <ad_raw_live+0x10>
    53f1:	48 03 05 00 ee 04 00 	add    0x4ee00(%rip),%rax        # 541f8 <ad_raw_live+0x18>
    53f8:	48 39 c8             	cmp    %rcx,%rax
    53fb:	72 52                	jb     544f <fwp_tape_buffers_release+0x18f>
    53fd:	48 8b 0d 3c ed 01 00 	mov    0x1ed3c(%rip),%rcx        # 24140 <ad_raw_checkpoint_count>
    5404:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    540b:	74 4e                	je     545b <fwp_tape_buffers_release+0x19b>
    540d:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    5411:	48 29 d0             	sub    %rdx,%rax
    5414:	48 89 3d 25 ed 01 00 	mov    %rdi,0x1ed25(%rip)        # 24140 <ad_raw_checkpoint_count>
    541b:	48 29 f0             	sub    %rsi,%rax
    541e:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    5422:	48 8d 0d 37 ed 01 00 	lea    0x1ed37(%rip),%rcx        # 24160 <ad_raw_checkpoints>
    5429:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    542d:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    5432:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    5437:	48 83 c4 10          	add    $0x10,%rsp
    543b:	5b                   	pop    %rbx
    543c:	c3                   	ret
    543d:	0f 1f 00             	nopl   (%rax)
    5440:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    5444:	0f 84 72 ff ff ff    	je     53bc <fwp_tape_buffers_release+0xfc>
    544a:	e9 ec fe ff ff       	jmp    533b <fwp_tape_buffers_release+0x7b>
    544f:	48 8d 3d 02 b5 00 00 	lea    0xb502(%rip),%rdi        # 10958 <_IO_stdin_used+0x958>
    5456:	e8 a5 eb ff ff       	call   4000 <ad_raw_fail>
    545b:	48 8d 3d 0f ad 00 00 	lea    0xad0f(%rip),%rdi        # 10171 <_IO_stdin_used+0x171>
    5462:	e8 99 eb ff ff       	call   4000 <ad_raw_fail>
    5467:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    546e:	00 00 

0000000000005470 <fwp_poll_events>:
    5470:	53                   	push   %rbx
    5471:	48 83 ec 20          	sub    $0x20,%rsp
    5475:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    547c:	00 00 
    547e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5483:	31 c0                	xor    %eax,%eax
    5485:	e8 36 f1 ff ff       	call   45c0 <fwp_now_ns>
    548a:	48 8b 1d 87 73 06 00 	mov    0x67387(%rip),%rbx        # 6c818 <fwp_timers>
    5491:	48 85 db             	test   %rbx,%rbx
    5494:	0f 84 e6 00 00 00    	je     5580 <fwp_poll_events+0x110>
    549a:	48 89 c6             	mov    %rax,%rsi
    549d:	48 89 da             	mov    %rbx,%rdx
    54a0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    54a7:	eb 26                	jmp    54cf <fwp_poll_events+0x5f>
    54a9:	90                   	nop
    54aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    54b1:	00 00 00 00 
    54b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    54bc:	00 00 00 00 
    54c0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    54c7:	48 89 c8             	mov    %rcx,%rax
    54ca:	48 85 d2             	test   %rdx,%rdx
    54cd:	74 31                	je     5500 <fwp_poll_events+0x90>
    54cf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    54d3:	48 85 c0             	test   %rax,%rax
    54d6:	78 e8                	js     54c0 <fwp_poll_events+0x50>
    54d8:	48 39 c1             	cmp    %rax,%rcx
    54db:	7c e3                	jl     54c0 <fwp_poll_events+0x50>
    54dd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    54e4:	48 85 d2             	test   %rdx,%rdx
    54e7:	74 1c                	je     5505 <fwp_poll_events+0x95>
    54e9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    54ed:	48 39 c1             	cmp    %rax,%rcx
    54f0:	7c ce                	jl     54c0 <fwp_poll_events+0x50>
    54f2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    54f9:	48 85 d2             	test   %rdx,%rdx
    54fc:	75 d1                	jne    54cf <fwp_poll_events+0x5f>
    54fe:	66 90                	xchg   %ax,%ax
    5500:	48 85 c0             	test   %rax,%rax
    5503:	78 7b                	js     5580 <fwp_poll_events+0x110>
    5505:	48 29 f0             	sub    %rsi,%rax
    5508:	48 89 c1             	mov    %rax,%rcx
    550b:	48 85 c0             	test   %rax,%rax
    550e:	0f 8e 9c 00 00 00    	jle    55b0 <fwp_poll_events+0x140>
    5514:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    551b:	de 1b 43 
    551e:	48 f7 ea             	imul   %rdx
    5521:	48 89 c8             	mov    %rcx,%rax
    5524:	48 c1 f8 3f          	sar    $0x3f,%rax
    5528:	48 c1 fa 12          	sar    $0x12,%rdx
    552c:	48 29 c2             	sub    %rax,%rdx
    552f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5536:	48 39 c1             	cmp    %rax,%rcx
    5539:	0f 95 c0             	setne  %al
    553c:	0f b6 c0             	movzbl %al,%eax
    553f:	48 01 d0             	add    %rdx,%rax
    5542:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5548:	0f 8f 32 01 00 00    	jg     5680 <fwp_poll_events+0x210>
    554e:	48 85 c0             	test   %rax,%rax
    5551:	74 5d                	je     55b0 <fwp_poll_events+0x140>
    5553:	89 c1                	mov    %eax,%ecx
    5555:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    555c:	48 c1 e9 26          	shr    $0x26,%rcx
    5560:	48 63 d1             	movslq %ecx,%rdx
    5563:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5569:	29 c8                	sub    %ecx,%eax
    556b:	48 98                	cltq
    556d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5574:	e9 11 01 00 00       	jmp    568a <fwp_poll_events+0x21a>
    5579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5580:	e8 7b e7 ff ff       	call   3d00 <fwp_flush>
    5585:	ba 2b 00 00 00       	mov    $0x2b,%edx
    558a:	be 01 00 00 00       	mov    $0x1,%esi
    558f:	48 8b 0d ca ea 00 00 	mov    0xeaca(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    5596:	48 8d 3d eb b3 00 00 	lea    0xb3eb(%rip),%rdi        # 10988 <_IO_stdin_used+0x988>
    559d:	e8 be e0 ff ff       	call   3660 <fwrite@plt>
    55a2:	bf 65 00 00 00       	mov    $0x65,%edi
    55a7:	e8 a4 e0 ff ff       	call   3650 <exit@plt>
    55ac:	0f 1f 40 00          	nopl   0x0(%rax)
    55b0:	e8 0b f0 ff ff       	call   45c0 <fwp_now_ns>
    55b5:	48 89 c1             	mov    %rax,%rcx
    55b8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    55bc:	eb 44                	jmp    5602 <fwp_poll_events+0x192>
    55be:	66 90                	xchg   %ax,%ax
    55c0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    55c4:	75 33                	jne    55f9 <fwp_poll_events+0x189>
    55c6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    55ca:	75 2d                	jne    55f9 <fwp_poll_events+0x189>
    55cc:	48 8b 05 4d 72 06 00 	mov    0x6724d(%rip),%rax        # 6c820 <fwp_ready_tail>
    55d3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    55d7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    55de:	00 00 00 00 
    55e2:	48 85 c0             	test   %rax,%rax
    55e5:	0f 84 05 01 00 00    	je     56f0 <fwp_poll_events+0x280>
    55eb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    55f2:	48 89 15 27 72 06 00 	mov    %rdx,0x67227(%rip)        # 6c820 <fwp_ready_tail>
    55f9:	48 85 db             	test   %rbx,%rbx
    55fc:	0f 84 be 00 00 00    	je     56c0 <fwp_poll_events+0x250>
    5602:	48 89 da             	mov    %rbx,%rdx
    5605:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    560c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5610:	7f e7                	jg     55f9 <fwp_poll_events+0x189>
    5612:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5616:	74 2e                	je     5646 <fwp_poll_events+0x1d6>
    5618:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    561f:	48 85 c0             	test   %rax,%rax
    5622:	0f 84 b8 00 00 00    	je     56e0 <fwp_poll_events+0x270>
    5628:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    562f:	48 85 db             	test   %rbx,%rbx
    5632:	74 07                	je     563b <fwp_poll_events+0x1cb>
    5634:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    563b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    563f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5646:	48 8b 42 60          	mov    0x60(%rdx),%rax
    564a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    564e:	48 85 c0             	test   %rax,%rax
    5651:	0f 84 69 ff ff ff    	je     55c0 <fwp_poll_events+0x150>
    5657:	48 39 c8             	cmp    %rcx,%rax
    565a:	0f 8f 60 ff ff ff    	jg     55c0 <fwp_poll_events+0x150>
    5660:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5664:	0f 85 56 ff ff ff    	jne    55c0 <fwp_poll_events+0x150>
    566a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    566e:	75 89                	jne    55f9 <fwp_poll_events+0x189>
    5670:	48 89 d7             	mov    %rdx,%rdi
    5673:	e8 b8 ea ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5678:	e9 43 ff ff ff       	jmp    55c0 <fwp_poll_events+0x150>
    567d:	0f 1f 00             	nopl   (%rax)
    5680:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5685:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    568a:	48 89 e7             	mov    %rsp,%rdi
    568d:	31 f6                	xor    %esi,%esi
    568f:	48 89 14 24          	mov    %rdx,(%rsp)
    5693:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5698:	e8 f3 dd ff ff       	call   3490 <nanosleep@plt>
    569d:	48 8b 1d 74 71 06 00 	mov    0x67174(%rip),%rbx        # 6c818 <fwp_timers>
    56a4:	e8 17 ef ff ff       	call   45c0 <fwp_now_ns>
    56a9:	48 89 c1             	mov    %rax,%rcx
    56ac:	48 85 db             	test   %rbx,%rbx
    56af:	0f 85 03 ff ff ff    	jne    55b8 <fwp_poll_events+0x148>
    56b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56bc:	00 00 00 00 
    56c0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    56c5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    56cc:	00 00 
    56ce:	75 2c                	jne    56fc <fwp_poll_events+0x28c>
    56d0:	48 83 c4 20          	add    $0x20,%rsp
    56d4:	5b                   	pop    %rbx
    56d5:	c3                   	ret
    56d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    56dd:	00 00 00 
    56e0:	48 89 1d 31 71 06 00 	mov    %rbx,0x67131(%rip)        # 6c818 <fwp_timers>
    56e7:	e9 43 ff ff ff       	jmp    562f <fwp_poll_events+0x1bf>
    56ec:	0f 1f 40 00          	nopl   0x0(%rax)
    56f0:	48 89 15 31 71 06 00 	mov    %rdx,0x67131(%rip)        # 6c828 <fwp_ready_head>
    56f7:	e9 f6 fe ff ff       	jmp    55f2 <fwp_poll_events+0x182>
    56fc:	e8 4f dd ff ff       	call   3450 <__stack_chk_fail@plt>
    5701:	0f 1f 40 00          	nopl   0x0(%rax)
    5705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    570c:	00 00 00 00 

0000000000005710 <fwp_rc_wide_dup>:
    5710:	48 89 fa             	mov    %rdi,%rdx
    5713:	48 8d 35 46 71 06 00 	lea    0x67146(%rip),%rsi        # 6c860 <fwp_heap>
    571a:	48 83 ec 18          	sub    $0x18,%rsp
    571e:	48 89 f9             	mov    %rdi,%rcx
    5721:	48 c1 ea 11          	shr    $0x11,%rdx
    5725:	48 31 fa             	xor    %rdi,%rdx
    5728:	48 89 d0             	mov    %rdx,%rax
    572b:	48 c1 e8 09          	shr    $0x9,%rax
    572f:	48 31 c2             	xor    %rax,%rdx
    5732:	0f b6 d2             	movzbl %dl,%edx
    5735:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    573c:	00 
    573d:	49 8b 00             	mov    (%r8),%rax
    5740:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5747:	00 00 
    5749:	75 21                	jne    576c <fwp_rc_wide_dup+0x5c>
    574b:	e9 98 00 00 00       	jmp    57e8 <fwp_rc_wide_dup+0xd8>
    5750:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5755:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    575c:	00 00 00 00 
    5760:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5764:	48 85 d2             	test   %rdx,%rdx
    5767:	74 2f                	je     5798 <fwp_rc_wide_dup+0x88>
    5769:	48 89 d0             	mov    %rdx,%rax
    576c:	48 3b 08             	cmp    (%rax),%rcx
    576f:	75 ef                	jne    5760 <fwp_rc_wide_dup+0x50>
    5771:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5774:	74 7c                	je     57f2 <fwp_rc_wide_dup+0xe2>
    5776:	48 8b 50 08          	mov    0x8(%rax),%rdx
    577a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    577e:	0f 84 91 00 00 00    	je     5815 <fwp_rc_wide_dup+0x105>
    5784:	48 83 c2 01          	add    $0x1,%rdx
    5788:	48 89 50 08          	mov    %rdx,0x8(%rax)
    578c:	48 83 c4 18          	add    $0x18,%rsp
    5790:	c3                   	ret
    5791:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5798:	4c 8d 40 10          	lea    0x10(%rax),%r8
    579c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    579f:	75 68                	jne    5809 <fwp_rc_wide_dup+0xf9>
    57a1:	bf 18 00 00 00       	mov    $0x18,%edi
    57a6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    57ab:	4c 89 04 24          	mov    %r8,(%rsp)
    57af:	e8 dc dd ff ff       	call   3590 <malloc@plt>
    57b4:	4c 8b 04 24          	mov    (%rsp),%r8
    57b8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    57bd:	48 85 c0             	test   %rax,%rax
    57c0:	74 5f                	je     5821 <fwp_rc_wide_dup+0x111>
    57c2:	48 89 08             	mov    %rcx,(%rax)
    57c5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    57cc:	00 
    57cd:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    57d4:	00 
    57d5:	49 89 00             	mov    %rax,(%r8)
    57d8:	c6 01 ff             	movb   $0xff,(%rcx)
    57db:	48 83 05 c5 8c 06 00 	addq   $0x1,0x68cc5(%rip)        # 6e4a8 <fwp_heap+0x1c48>
    57e2:	01 
    57e3:	48 83 c4 18          	add    $0x18,%rsp
    57e7:	c3                   	ret
    57e8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    57eb:	75 13                	jne    5800 <fwp_rc_wide_dup+0xf0>
    57ed:	48 85 c0             	test   %rax,%rax
    57f0:	74 af                	je     57a1 <fwp_rc_wide_dup+0x91>
    57f2:	48 8d 3d bf b1 00 00 	lea    0xb1bf(%rip),%rdi        # 109b8 <_IO_stdin_used+0x9b8>
    57f9:	e8 52 ec ff ff       	call   4450 <fwp_trap>
    57fe:	66 90                	xchg   %ax,%ax
    5800:	48 85 c0             	test   %rax,%rax
    5803:	0f 85 6d ff ff ff    	jne    5776 <fwp_rc_wide_dup+0x66>
    5809:	48 8d 3d d0 b1 00 00 	lea    0xb1d0(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    5810:	e8 3b ec ff ff       	call   4450 <fwp_trap>
    5815:	48 8d 3d 72 a9 00 00 	lea    0xa972(%rip),%rdi        # 1018e <_IO_stdin_used+0x18e>
    581c:	e8 2f ec ff ff       	call   4450 <fwp_trap>
    5821:	e8 0a e6 ff ff       	call   3e30 <fwp_heap_oom>
    5826:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    582d:	00 00 00 

0000000000005830 <fwp_rc_forget_slot>:
    5830:	80 3f ff             	cmpb   $0xff,(%rdi)
    5833:	74 0b                	je     5840 <fwp_rc_forget_slot+0x10>
    5835:	c3                   	ret
    5836:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    583d:	00 00 00 
    5840:	48 89 f8             	mov    %rdi,%rax
    5843:	48 83 ec 08          	sub    $0x8,%rsp
    5847:	48 89 fa             	mov    %rdi,%rdx
    584a:	48 c1 e8 11          	shr    $0x11,%rax
    584e:	48 31 f8             	xor    %rdi,%rax
    5851:	48 89 c1             	mov    %rax,%rcx
    5854:	48 c1 e9 09          	shr    $0x9,%rcx
    5858:	48 31 c8             	xor    %rcx,%rax
    585b:	48 8d 0d fe 6f 06 00 	lea    0x66ffe(%rip),%rcx        # 6c860 <fwp_heap>
    5862:	0f b6 c0             	movzbl %al,%eax
    5865:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    586c:	00 
    586d:	48 85 ff             	test   %rdi,%rdi
    5870:	74 3c                	je     58ae <fwp_rc_forget_slot+0x7e>
    5872:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5879:	00 
    587a:	48 8b 01             	mov    (%rcx),%rax
    587d:	eb 11                	jmp    5890 <fwp_rc_forget_slot+0x60>
    587f:	90                   	nop
    5880:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5884:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5888:	48 85 ff             	test   %rdi,%rdi
    588b:	74 21                	je     58ae <fwp_rc_forget_slot+0x7e>
    588d:	48 89 f8             	mov    %rdi,%rax
    5890:	48 3b 10             	cmp    (%rax),%rdx
    5893:	75 eb                	jne    5880 <fwp_rc_forget_slot+0x50>
    5895:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5899:	48 89 01             	mov    %rax,(%rcx)
    589c:	e8 0f db ff ff       	call   33b0 <free@plt>
    58a1:	48 83 2d ff 8b 06 00 	subq   $0x1,0x68bff(%rip)        # 6e4a8 <fwp_heap+0x1c48>
    58a8:	01 
    58a9:	48 83 c4 08          	add    $0x8,%rsp
    58ad:	c3                   	ret
    58ae:	48 8d 3d 2b b1 00 00 	lea    0xb12b(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    58b5:	e8 96 eb ff ff       	call   4450 <fwp_trap>
    58ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000058c0 <fwp_rc_prepare_chunk>:
    58c0:	48 83 3d e0 8b 06 00 	cmpq   $0x0,0x68be0(%rip)        # 6e4a8 <fwp_heap+0x1c48>
    58c7:	00 
    58c8:	41 54                	push   %r12
    58ca:	49 89 f4             	mov    %rsi,%r12
    58cd:	55                   	push   %rbp
    58ce:	48 89 fd             	mov    %rdi,%rbp
    58d1:	53                   	push   %rbx
    58d2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    58d5:	0f 84 7d 00 00 00    	je     5958 <fwp_rc_prepare_chunk+0x98>
    58db:	31 db                	xor    %ebx,%ebx
    58dd:	85 c0                	test   %eax,%eax
    58df:	75 5f                	jne    5940 <fwp_rc_prepare_chunk+0x80>
    58e1:	48 85 f6             	test   %rsi,%rsi
    58e4:	74 7c                	je     5962 <fwp_rc_prepare_chunk+0xa2>
    58e6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    58ea:	e8 c1 da ff ff       	call   33b0 <free@plt>
    58ef:	90                   	nop
    58f0:	be 01 00 00 00       	mov    $0x1,%esi
    58f5:	4c 89 e7             	mov    %r12,%rdi
    58f8:	e8 13 dc ff ff       	call   3510 <calloc@plt>
    58fd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5901:	48 85 c0             	test   %rax,%rax
    5904:	0f 85 87 00 00 00    	jne    5991 <fwp_rc_prepare_chunk+0xd1>
    590a:	e8 21 e5 ff ff       	call   3e30 <fwp_heap_oom>
    590f:	90                   	nop
    5910:	e8 1b ff ff ff       	call   5830 <fwp_rc_forget_slot>
    5915:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5918:	48 83 c3 01          	add    $0x1,%rbx
    591c:	48 39 c3             	cmp    %rax,%rbx
    591f:	73 37                	jae    5958 <fwp_rc_prepare_chunk+0x98>
    5921:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5928:	00 00 
    592a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5931:	00 00 00 00 
    5935:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    593c:	00 00 00 00 
    5940:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5944:	48 01 df             	add    %rbx,%rdi
    5947:	80 3f ff             	cmpb   $0xff,(%rdi)
    594a:	74 c4                	je     5910 <fwp_rc_prepare_chunk+0x50>
    594c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    594f:	48 83 c3 01          	add    $0x1,%rbx
    5953:	48 39 c3             	cmp    %rax,%rbx
    5956:	72 e8                	jb     5940 <fwp_rc_prepare_chunk+0x80>
    5958:	49 39 c4             	cmp    %rax,%r12
    595b:	75 13                	jne    5970 <fwp_rc_prepare_chunk+0xb0>
    595d:	4d 85 e4             	test   %r12,%r12
    5960:	75 46                	jne    59a8 <fwp_rc_prepare_chunk+0xe8>
    5962:	5b                   	pop    %rbx
    5963:	5d                   	pop    %rbp
    5964:	41 5c                	pop    %r12
    5966:	c3                   	ret
    5967:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    596e:	00 00 
    5970:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5974:	48 29 05 35 8b 06 00 	sub    %rax,0x68b35(%rip)        # 6e4b0 <fwp_heap+0x1c50>
    597b:	e8 30 da ff ff       	call   33b0 <free@plt>
    5980:	4d 85 e4             	test   %r12,%r12
    5983:	0f 85 67 ff ff ff    	jne    58f0 <fwp_rc_prepare_chunk+0x30>
    5989:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5990:	00 
    5991:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5995:	5b                   	pop    %rbx
    5996:	4c 01 25 13 8b 06 00 	add    %r12,0x68b13(%rip)        # 6e4b0 <fwp_heap+0x1c50>
    599d:	5d                   	pop    %rbp
    599e:	41 5c                	pop    %r12
    59a0:	c3                   	ret
    59a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    59a8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    59ac:	5b                   	pop    %rbx
    59ad:	4c 89 e2             	mov    %r12,%rdx
    59b0:	31 f6                	xor    %esi,%esi
    59b2:	5d                   	pop    %rbp
    59b3:	41 5c                	pop    %r12
    59b5:	e9 f6 da ff ff       	jmp    34b0 <memset@plt>
    59ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000059c0 <fwp_heap_refill>:
    59c0:	41 56                	push   %r14
    59c2:	41 89 d6             	mov    %edx,%r14d
    59c5:	41 55                	push   %r13
    59c7:	41 89 f5             	mov    %esi,%r13d
    59ca:	41 54                	push   %r12
    59cc:	49 89 fc             	mov    %rdi,%r12
    59cf:	bf 01 00 00 00       	mov    $0x1,%edi
    59d4:	55                   	push   %rbp
    59d5:	53                   	push   %rbx
    59d6:	e8 95 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    59db:	48 89 c3             	mov    %rax,%rbx
    59de:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    59e2:	48 8b 05 6f 82 06 00 	mov    0x6826f(%rip),%rax        # 6dc58 <fwp_heap+0x13f8>
    59e9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    59ed:	48 8d 05 6c 6e 06 00 	lea    0x66e6c(%rip),%rax        # 6c860 <fwp_heap>
    59f4:	31 d2                	xor    %edx,%edx
    59f6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    59fa:	48 89 ef             	mov    %rbp,%rdi
    59fd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5a01:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5a05:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    5a0c:	00 
    5a0d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5a12:	f7 f1                	div    %ecx
    5a14:	31 d2                	xor    %edx,%edx
    5a16:	66 0f 6e c1          	movd   %ecx,%xmm0
    5a1a:	66 0f 6e c8          	movd   %eax,%xmm1
    5a1e:	89 c6                	mov    %eax,%esi
    5a20:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5a25:	48 01 c8             	add    %rcx,%rax
    5a28:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5a2c:	48 f7 f1             	div    %rcx
    5a2f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5a34:	89 45 18             	mov    %eax,0x18(%rbp)
    5a37:	e8 84 fe ff ff       	call   58c0 <fwp_rc_prepare_chunk>
    5a3c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    5a3f:	48 89 d8             	mov    %rbx,%rax
    5a42:	48 c1 e0 10          	shl    $0x10,%rax
    5a46:	48 03 05 c3 81 06 00 	add    0x681c3(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    5a4d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5a51:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5a56:	8b 55 08             	mov    0x8(%rbp),%edx
    5a59:	48 0f af d1          	imul   %rcx,%rdx
    5a5d:	48 01 c2             	add    %rax,%rdx
    5a60:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a65:	5b                   	pop    %rbx
    5a66:	5d                   	pop    %rbp
    5a67:	41 5c                	pop    %r12
    5a69:	41 5d                	pop    %r13
    5a6b:	41 5e                	pop    %r14
    5a6d:	c3                   	ret
    5a6e:	66 90                	xchg   %ax,%ax

0000000000005a70 <fwp_mem_free>:
    5a70:	48 85 ff             	test   %rdi,%rdi
    5a73:	0f 84 17 02 00 00    	je     5c90 <fwp_mem_free+0x220>
    5a79:	48 8b 35 90 81 06 00 	mov    0x68190(%rip),%rsi        # 6dc10 <fwp_heap+0x13b0>
    5a80:	48 8b 05 b1 81 06 00 	mov    0x681b1(%rip),%rax        # 6dc38 <fwp_heap+0x13d8>
    5a87:	48 89 fa             	mov    %rdi,%rdx
    5a8a:	48 29 f2             	sub    %rsi,%rdx
    5a8d:	48 c1 e0 10          	shl    $0x10,%rax
    5a91:	48 39 c2             	cmp    %rax,%rdx
    5a94:	0f 83 f6 01 00 00    	jae    5c90 <fwp_mem_free+0x220>
    5a9a:	49 89 d1             	mov    %rdx,%r9
    5a9d:	49 c1 e9 10          	shr    $0x10,%r9
    5aa1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5aa5:	48 c1 e0 03          	shl    $0x3,%rax
    5aa9:	49 89 c0             	mov    %rax,%r8
    5aac:	4c 03 05 a5 81 06 00 	add    0x681a5(%rip),%r8        # 6dc58 <fwp_heap+0x13f8>
    5ab3:	0f 84 d7 01 00 00    	je     5c90 <fwp_mem_free+0x220>
    5ab9:	48 83 ec 38          	sub    $0x38,%rsp
    5abd:	48 89 f9             	mov    %rdi,%rcx
    5ac0:	41 0f b6 38          	movzbl (%r8),%edi
    5ac4:	40 80 ff 01          	cmp    $0x1,%dil
    5ac8:	74 16                	je     5ae0 <fwp_mem_free+0x70>
    5aca:	40 80 ff 02          	cmp    $0x2,%dil
    5ace:	0f 84 94 00 00 00    	je     5b68 <fwp_mem_free+0xf8>
    5ad4:	48 83 c4 38          	add    $0x38,%rsp
    5ad8:	c3                   	ret
    5ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ae0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5ae4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5ae9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5aee:	41 8b 78 04          	mov    0x4(%r8),%edi
    5af2:	4d 85 d2             	test   %r10,%r10
    5af5:	74 1d                	je     5b14 <fwp_mem_free+0xa4>
    5af7:	0f b7 c1             	movzwl %cx,%eax
    5afa:	31 d2                	xor    %edx,%edx
    5afc:	48 f7 f7             	div    %rdi
    5aff:	49 01 c2             	add    %rax,%r10
    5b02:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5b06:	0f 84 44 01 00 00    	je     5c50 <fwp_mem_free+0x1e0>
    5b0c:	41 c6 02 00          	movb   $0x0,(%r10)
    5b10:	41 8b 78 04          	mov    0x4(%r8),%edi
    5b14:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5b1b:	49 63 c1             	movslq %r9d,%rax
    5b1e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b22:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5b26:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5b2b:	f2 0f 58 05 6d 81 06 	addsd  0x6816d(%rip),%xmm0        # 6dca0 <fwp_heap+0x1440>
    5b32:	00 
    5b33:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5b37:	48 8d 05 22 6d 06 00 	lea    0x66d22(%rip),%rax        # 6c860 <fwp_heap>
    5b3e:	48 01 d0             	add    %rdx,%rax
    5b41:	48 8b 10             	mov    (%rax),%rdx
    5b44:	48 f7 d2             	not    %rdx
    5b47:	48 89 11             	mov    %rdx,(%rcx)
    5b4a:	48 89 08             	mov    %rcx,(%rax)
    5b4d:	48 29 3d 2c 81 06 00 	sub    %rdi,0x6812c(%rip)        # 6dc80 <fwp_heap+0x1420>
    5b54:	f2 0f 11 05 44 81 06 	movsd  %xmm0,0x68144(%rip)        # 6dca0 <fwp_heap+0x1440>
    5b5b:	00 
    5b5c:	48 83 c4 38          	add    $0x38,%rsp
    5b60:	c3                   	ret
    5b61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b68:	66 31 d2             	xor    %dx,%dx
    5b6b:	48 01 d6             	add    %rdx,%rsi
    5b6e:	48 39 f1             	cmp    %rsi,%rcx
    5b71:	0f 85 5d ff ff ff    	jne    5ad4 <fwp_mem_free+0x64>
    5b77:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b7b:	48 29 15 fe 80 06 00 	sub    %rdx,0x680fe(%rip)        # 6dc80 <fwp_heap+0x1420>
    5b82:	48 85 d2             	test   %rdx,%rdx
    5b85:	0f 88 a5 00 00 00    	js     5c30 <fwp_mem_free+0x1c0>
    5b8b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b8f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b94:	f2 0f 58 05 04 81 06 	addsd  0x68104(%rip),%xmm0        # 6dca0 <fwp_heap+0x1440>
    5b9b:	00 
    5b9c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5ba0:	f2 0f 11 05 f8 80 06 	movsd  %xmm0,0x680f8(%rip)        # 6dca0 <fwp_heap+0x1440>
    5ba7:	00 
    5ba8:	48 85 d2             	test   %rdx,%rdx
    5bab:	74 0c                	je     5bb9 <fwp_mem_free+0x149>
    5bad:	80 3a ff             	cmpb   $0xff,(%rdx)
    5bb0:	0f 84 db 00 00 00    	je     5c91 <fwp_mem_free+0x221>
    5bb6:	c6 02 00             	movb   $0x0,(%rdx)
    5bb9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5bbd:	48 85 c9             	test   %rcx,%rcx
    5bc0:	74 3e                	je     5c00 <fwp_mem_free+0x190>
    5bc2:	48 8b 15 8f 80 06 00 	mov    0x6808f(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    5bc9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5bcd:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5bd1:	48 01 d0             	add    %rdx,%rax
    5bd4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5bd8:	48 89 d6             	mov    %rdx,%rsi
    5bdb:	48 29 c6             	sub    %rax,%rsi
    5bde:	83 e6 08             	and    $0x8,%esi
    5be1:	74 0d                	je     5bf0 <fwp_mem_free+0x180>
    5be3:	c6 00 00             	movb   $0x0,(%rax)
    5be6:	48 83 c0 28          	add    $0x28,%rax
    5bea:	48 39 c2             	cmp    %rax,%rdx
    5bed:	74 11                	je     5c00 <fwp_mem_free+0x190>
    5bef:	90                   	nop
    5bf0:	c6 00 00             	movb   $0x0,(%rax)
    5bf3:	48 83 c0 50          	add    $0x50,%rax
    5bf7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5bfb:	48 39 c2             	cmp    %rax,%rdx
    5bfe:	75 f0                	jne    5bf0 <fwp_mem_free+0x180>
    5c00:	48 01 0d 89 80 06 00 	add    %rcx,0x68089(%rip)        # 6dc90 <fwp_heap+0x1430>
    5c07:	4c 3b 0d 42 80 06 00 	cmp    0x68042(%rip),%r9        # 6dc50 <fwp_heap+0x13f0>
    5c0e:	73 07                	jae    5c17 <fwp_mem_free+0x1a7>
    5c10:	4c 89 0d 39 80 06 00 	mov    %r9,0x68039(%rip)        # 6dc50 <fwp_heap+0x13f0>
    5c17:	4c 3b 0d 2a 80 06 00 	cmp    0x6802a(%rip),%r9        # 6dc48 <fwp_heap+0x13e8>
    5c1e:	0f 83 b0 fe ff ff    	jae    5ad4 <fwp_mem_free+0x64>
    5c24:	4c 89 0d 1d 80 06 00 	mov    %r9,0x6801d(%rip)        # 6dc48 <fwp_heap+0x13e8>
    5c2b:	e9 a4 fe ff ff       	jmp    5ad4 <fwp_mem_free+0x64>
    5c30:	48 89 d1             	mov    %rdx,%rcx
    5c33:	83 e2 01             	and    $0x1,%edx
    5c36:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c3a:	48 d1 e9             	shr    $1,%rcx
    5c3d:	48 09 d1             	or     %rdx,%rcx
    5c40:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5c45:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5c49:	e9 46 ff ff ff       	jmp    5b94 <fwp_mem_free+0x124>
    5c4e:	66 90                	xchg   %ax,%ax
    5c50:	4c 89 d7             	mov    %r10,%rdi
    5c53:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5c58:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5c5d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c62:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c66:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c6b:	e8 c0 fb ff ff       	call   5830 <fwp_rc_forget_slot>
    5c70:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c75:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c7a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c7f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c84:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c89:	e9 7e fe ff ff       	jmp    5b0c <fwp_mem_free+0x9c>
    5c8e:	66 90                	xchg   %ax,%ax
    5c90:	c3                   	ret
    5c91:	48 89 d7             	mov    %rdx,%rdi
    5c94:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c99:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c9e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5ca3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5ca8:	e8 83 fb ff ff       	call   5830 <fwp_rc_forget_slot>
    5cad:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5cb2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5cb7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5cbc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5cc1:	e9 f0 fe ff ff       	jmp    5bb6 <fwp_mem_free+0x146>
    5cc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5ccd:	00 00 00 

0000000000005cd0 <fwp_heap_alloc_big>:
    5cd0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5cd7:	00 00 40 
    5cda:	41 57                	push   %r15
    5cdc:	41 56                	push   %r14
    5cde:	41 55                	push   %r13
    5ce0:	41 54                	push   %r12
    5ce2:	55                   	push   %rbp
    5ce3:	53                   	push   %rbx
    5ce4:	48 83 ec 08          	sub    $0x8,%rsp
    5ce8:	48 39 f8             	cmp    %rdi,%rax
    5ceb:	0f 82 fa 00 00 00    	jb     5deb <fwp_heap_alloc_big+0x11b>
    5cf1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5cf8:	49 89 fd             	mov    %rdi,%r13
    5cfb:	41 89 f6             	mov    %esi,%r14d
    5cfe:	48 c1 ed 10          	shr    $0x10,%rbp
    5d02:	48 89 ef             	mov    %rbp,%rdi
    5d05:	e8 66 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5d0a:	be 01 00 00 00       	mov    $0x1,%esi
    5d0f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5d13:	49 89 c4             	mov    %rax,%r12
    5d16:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5d1d:	00 
    5d1e:	48 03 3d 33 7f 06 00 	add    0x67f33(%rip),%rdi        # 6dc58 <fwp_heap+0x13f8>
    5d25:	c6 07 02             	movb   $0x2,(%rdi)
    5d28:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5d2c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5d2f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5d33:	e8 88 fb ff ff       	call   58c0 <fwp_rc_prepare_chunk>
    5d38:	48 83 fd 01          	cmp    $0x1,%rbp
    5d3c:	76 47                	jbe    5d85 <fwp_heap_alloc_big+0xb5>
    5d3e:	4c 01 e5             	add    %r12,%rbp
    5d41:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5d48:	00 
    5d49:	4c 8d 3d 10 6b 06 00 	lea    0x66b10(%rip),%r15        # 6c860 <fwp_heap>
    5d50:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5d55:	49 c1 e6 03          	shl    $0x3,%r14
    5d59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d60:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d67:	31 f6                	xor    %esi,%esi
    5d69:	48 01 dd             	add    %rbx,%rbp
    5d6c:	48 83 c3 28          	add    $0x28,%rbx
    5d70:	48 89 ef             	mov    %rbp,%rdi
    5d73:	e8 48 fb ff ff       	call   58c0 <fwp_rc_prepare_chunk>
    5d78:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d7c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d80:	49 39 de             	cmp    %rbx,%r14
    5d83:	75 db                	jne    5d60 <fwp_heap_alloc_big+0x90>
    5d85:	49 c1 e4 10          	shl    $0x10,%r12
    5d89:	4c 03 25 80 7e 06 00 	add    0x67e80(%rip),%r12        # 6dc10 <fwp_heap+0x13b0>
    5d90:	4c 89 ea             	mov    %r13,%rdx
    5d93:	31 f6                	xor    %esi,%esi
    5d95:	4c 89 e7             	mov    %r12,%rdi
    5d98:	e8 13 d7 ff ff       	call   34b0 <memset@plt>
    5d9d:	4c 89 e8             	mov    %r13,%rax
    5da0:	48 03 05 d9 7e 06 00 	add    0x67ed9(%rip),%rax        # 6dc80 <fwp_heap+0x1420>
    5da7:	72 42                	jb     5deb <fwp_heap_alloc_big+0x11b>
    5da9:	48 39 05 d8 7e 06 00 	cmp    %rax,0x67ed8(%rip)        # 6dc88 <fwp_heap+0x1428>
    5db0:	48 89 05 c9 7e 06 00 	mov    %rax,0x67ec9(%rip)        # 6dc80 <fwp_heap+0x1420>
    5db7:	73 07                	jae    5dc0 <fwp_heap_alloc_big+0xf0>
    5db9:	48 89 05 c8 7e 06 00 	mov    %rax,0x67ec8(%rip)        # 6dc88 <fwp_heap+0x1428>
    5dc0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5dc4:	4c 89 e0             	mov    %r12,%rax
    5dc7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5dcc:	f2 0f 58 05 c4 7e 06 	addsd  0x67ec4(%rip),%xmm0        # 6dc98 <fwp_heap+0x1438>
    5dd3:	00 
    5dd4:	f2 0f 11 05 bc 7e 06 	movsd  %xmm0,0x67ebc(%rip)        # 6dc98 <fwp_heap+0x1438>
    5ddb:	00 
    5ddc:	48 83 c4 08          	add    $0x8,%rsp
    5de0:	5b                   	pop    %rbx
    5de1:	5d                   	pop    %rbp
    5de2:	41 5c                	pop    %r12
    5de4:	41 5d                	pop    %r13
    5de6:	41 5e                	pop    %r14
    5de8:	41 5f                	pop    %r15
    5dea:	c3                   	ret
    5deb:	e8 40 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005df0 <fwp_heap_alloc_slow>:
    5df0:	53                   	push   %rbx
    5df1:	48 89 f9             	mov    %rdi,%rcx
    5df4:	41 89 f1             	mov    %esi,%r9d
    5df7:	48 83 ec 10          	sub    $0x10,%rsp
    5dfb:	8b 05 03 7e 06 00    	mov    0x67e03(%rip),%eax        # 6dc04 <fwp_heap+0x13a4>
    5e01:	85 c0                	test   %eax,%eax
    5e03:	0f 84 c7 00 00 00    	je     5ed0 <fwp_heap_alloc_slow+0xe0>
    5e09:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e10:	0f 87 dd 00 00 00    	ja     5ef3 <fwp_heap_alloc_slow+0x103>
    5e16:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5e1a:	48 8d 3d 3f 6a 06 00 	lea    0x66a3f(%rip),%rdi        # 6c860 <fwp_heap>
    5e21:	49 63 f1             	movslq %r9d,%rsi
    5e24:	48 c1 e8 04          	shr    $0x4,%rax
    5e28:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5e2f:	00 00 
    5e31:	41 0f b6 c2          	movzbl %r10b,%eax
    5e35:	4c 89 d2             	mov    %r10,%rdx
    5e38:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5e3c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5e43:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5e4a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5e4e:	48 01 f8             	add    %rdi,%rax
    5e51:	4c 8b 00             	mov    (%rax),%r8
    5e54:	4d 85 c0             	test   %r8,%r8
    5e57:	0f 84 ab 00 00 00    	je     5f08 <fwp_heap_alloc_slow+0x118>
    5e5d:	49 8b 10             	mov    (%r8),%rdx
    5e60:	48 f7 d2             	not    %rdx
    5e63:	48 89 10             	mov    %rdx,(%rax)
    5e66:	41 83 f9 01          	cmp    $0x1,%r9d
    5e6a:	4c 89 c7             	mov    %r8,%rdi
    5e6d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e71:	31 f6                	xor    %esi,%esi
    5e73:	48 89 ca             	mov    %rcx,%rdx
    5e76:	e8 35 d6 ff ff       	call   34b0 <memset@plt>
    5e7b:	49 89 c0             	mov    %rax,%r8
    5e7e:	48 89 d8             	mov    %rbx,%rax
    5e81:	48 03 05 f8 7d 06 00 	add    0x67df8(%rip),%rax        # 6dc80 <fwp_heap+0x1420>
    5e88:	0f 82 d9 00 00 00    	jb     5f67 <fwp_heap_alloc_slow+0x177>
    5e8e:	48 39 05 f3 7d 06 00 	cmp    %rax,0x67df3(%rip)        # 6dc88 <fwp_heap+0x1428>
    5e95:	48 89 05 e4 7d 06 00 	mov    %rax,0x67de4(%rip)        # 6dc80 <fwp_heap+0x1420>
    5e9c:	73 07                	jae    5ea5 <fwp_heap_alloc_slow+0xb5>
    5e9e:	48 89 05 e3 7d 06 00 	mov    %rax,0x67de3(%rip)        # 6dc88 <fwp_heap+0x1428>
    5ea5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ea9:	4c 89 c0             	mov    %r8,%rax
    5eac:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5eb1:	f2 0f 58 05 df 7d 06 	addsd  0x67ddf(%rip),%xmm0        # 6dc98 <fwp_heap+0x1438>
    5eb8:	00 
    5eb9:	f2 0f 11 05 d7 7d 06 	movsd  %xmm0,0x67dd7(%rip)        # 6dc98 <fwp_heap+0x1438>
    5ec0:	00 
    5ec1:	48 83 c4 10          	add    $0x10,%rsp
    5ec5:	5b                   	pop    %rbx
    5ec6:	c3                   	ret
    5ec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5ece:	00 00 
    5ed0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5ed4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5ed8:	e8 f3 ee ff ff       	call   4dd0 <fwp_heap_init>
    5edd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5ee1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5ee6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5eed:	0f 86 23 ff ff ff    	jbe    5e16 <fwp_heap_alloc_slow+0x26>
    5ef3:	48 83 c4 10          	add    $0x10,%rsp
    5ef7:	44 89 ce             	mov    %r9d,%esi
    5efa:	48 89 cf             	mov    %rcx,%rdi
    5efd:	5b                   	pop    %rbx
    5efe:	e9 cd fd ff ff       	jmp    5cd0 <fwp_heap_alloc_big>
    5f03:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5f08:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5f0c:	4d 85 c0             	test   %r8,%r8
    5f0f:	74 1f                	je     5f30 <fwp_heap_alloc_slow+0x140>
    5f11:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5f15:	4d 29 c3             	sub    %r8,%r11
    5f18:	49 39 db             	cmp    %rbx,%r11
    5f1b:	72 13                	jb     5f30 <fwp_heap_alloc_slow+0x140>
    5f1d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5f21:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5f25:	e9 3c ff ff ff       	jmp    5e66 <fwp_heap_alloc_slow+0x76>
    5f2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5f30:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5f37:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5f3b:	44 89 ca             	mov    %r9d,%edx
    5f3e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5f43:	44 89 0c 24          	mov    %r9d,(%rsp)
    5f47:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5f4b:	44 89 d6             	mov    %r10d,%esi
    5f4e:	48 01 c7             	add    %rax,%rdi
    5f51:	e8 6a fa ff ff       	call   59c0 <fwp_heap_refill>
    5f56:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5f5b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5f5f:	49 89 c0             	mov    %rax,%r8
    5f62:	e9 ff fe ff ff       	jmp    5e66 <fwp_heap_alloc_slow+0x76>
    5f67:	e8 c4 de ff ff       	call   3e30 <fwp_heap_oom>
    5f6c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f70 <fwp_heap_alloc>:
    5f70:	53                   	push   %rbx
    5f71:	48 89 fa             	mov    %rdi,%rdx
    5f74:	48 83 ec 10          	sub    $0x10,%rsp
    5f78:	8b 1d aa 85 06 00    	mov    0x685aa(%rip),%ebx        # 6e528 <iteration_active>
    5f7e:	8b 05 80 7c 06 00    	mov    0x67c80(%rip),%eax        # 6dc04 <fwp_heap+0x13a4>
    5f84:	85 db                	test   %ebx,%ebx
    5f86:	0f 85 04 01 00 00    	jne    6090 <fwp_heap_alloc+0x120>
    5f8c:	85 c0                	test   %eax,%eax
    5f8e:	0f 84 ac 01 00 00    	je     6140 <fwp_heap_alloc+0x1d0>
    5f94:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f9b:	0f 87 9f 01 00 00    	ja     6140 <fwp_heap_alloc+0x1d0>
    5fa1:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5fa5:	48 8d 05 b4 68 06 00 	lea    0x668b4(%rip),%rax        # 6c860 <fwp_heap>
    5fac:	48 c1 e9 04          	shr    $0x4,%rcx
    5fb0:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5fb7:	00 
    5fb8:	48 63 ce             	movslq %esi,%rcx
    5fbb:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5fc2:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5fc9:	00 
    5fca:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5fce:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5fd2:	48 01 c8             	add    %rcx,%rax
    5fd5:	48 8b 08             	mov    (%rax),%rcx
    5fd8:	48 85 c9             	test   %rcx,%rcx
    5fdb:	0f 84 ff 00 00 00    	je     60e0 <fwp_heap_alloc+0x170>
    5fe1:	48 8b 39             	mov    (%rcx),%rdi
    5fe4:	48 f7 d7             	not    %rdi
    5fe7:	48 89 38             	mov    %rdi,(%rax)
    5fea:	83 fe 01             	cmp    $0x1,%esi
    5fed:	48 89 cf             	mov    %rcx,%rdi
    5ff0:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5ff5:	49 0f 45 d0          	cmovne %r8,%rdx
    5ff9:	31 f6                	xor    %esi,%esi
    5ffb:	e8 b0 d4 ff ff       	call   34b0 <memset@plt>
    6000:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    6005:	48 89 c1             	mov    %rax,%rcx
    6008:	4c 89 c0             	mov    %r8,%rax
    600b:	48 03 05 6e 7c 06 00 	add    0x67c6e(%rip),%rax        # 6dc80 <fwp_heap+0x1420>
    6012:	0f 82 35 01 00 00    	jb     614d <fwp_heap_alloc+0x1dd>
    6018:	48 39 05 69 7c 06 00 	cmp    %rax,0x67c69(%rip)        # 6dc88 <fwp_heap+0x1428>
    601f:	48 89 05 5a 7c 06 00 	mov    %rax,0x67c5a(%rip)        # 6dc80 <fwp_heap+0x1420>
    6026:	73 07                	jae    602f <fwp_heap_alloc+0xbf>
    6028:	48 89 05 59 7c 06 00 	mov    %rax,0x67c59(%rip)        # 6dc88 <fwp_heap+0x1428>
    602f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6033:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    6038:	f2 0f 58 05 58 7c 06 	addsd  0x67c58(%rip),%xmm0        # 6dc98 <fwp_heap+0x1438>
    603f:	00 
    6040:	f2 0f 11 05 50 7c 06 	movsd  %xmm0,0x67c50(%rip)        # 6dc98 <fwp_heap+0x1438>
    6047:	00 
    6048:	85 db                	test   %ebx,%ebx
    604a:	74 33                	je     607f <fwp_heap_alloc+0x10f>
    604c:	48 8b 05 2d 7c 06 00 	mov    0x67c2d(%rip),%rax        # 6dc80 <fwp_heap+0x1420>
    6053:	48 85 c0             	test   %rax,%rax
    6056:	0f 88 ac 00 00 00    	js     6108 <fwp_heap_alloc+0x198>
    605c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6060:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6065:	f2 0f 5c 05 9b 84 06 	subsd  0x6849b(%rip),%xmm0        # 6e508 <iteration_start_charge>
    606c:	00 
    606d:	66 0f 2f 05 8b 84 06 	comisd 0x6848b(%rip),%xmm0        # 6e500 <iteration_peak>
    6074:	00 
    6075:	76 08                	jbe    607f <fwp_heap_alloc+0x10f>
    6077:	f2 0f 11 05 81 84 06 	movsd  %xmm0,0x68481(%rip)        # 6e500 <iteration_peak>
    607e:	00 
    607f:	48 83 c4 10          	add    $0x10,%rsp
    6083:	48 89 c8             	mov    %rcx,%rax
    6086:	5b                   	pop    %rbx
    6087:	c3                   	ret
    6088:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    608f:	00 
    6090:	85 f6                	test   %esi,%esi
    6092:	74 34                	je     60c8 <fwp_heap_alloc+0x158>
    6094:	48 83 05 84 84 06 00 	addq   $0x1,0x68484(%rip)        # 6e520 <iteration_requests>
    609b:	01 
    609c:	48 01 3d 75 84 06 00 	add    %rdi,0x68475(%rip)        # 6e518 <iteration_bytes>
    60a3:	85 c0                	test   %eax,%eax
    60a5:	74 0d                	je     60b4 <fwp_heap_alloc+0x144>
    60a7:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    60ae:	0f 86 ed fe ff ff    	jbe    5fa1 <fwp_heap_alloc+0x31>
    60b4:	48 89 d7             	mov    %rdx,%rdi
    60b7:	e8 34 fd ff ff       	call   5df0 <fwp_heap_alloc_slow>
    60bc:	48 89 c1             	mov    %rax,%rcx
    60bf:	eb 8b                	jmp    604c <fwp_heap_alloc+0xdc>
    60c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    60c8:	85 c0                	test   %eax,%eax
    60ca:	74 0d                	je     60d9 <fwp_heap_alloc+0x169>
    60cc:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    60d3:	0f 86 c8 fe ff ff    	jbe    5fa1 <fwp_heap_alloc+0x31>
    60d9:	31 f6                	xor    %esi,%esi
    60db:	eb d7                	jmp    60b4 <fwp_heap_alloc+0x144>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    60e4:	48 85 c9             	test   %rcx,%rcx
    60e7:	74 0c                	je     60f5 <fwp_heap_alloc+0x185>
    60e9:	48 8b 78 10          	mov    0x10(%rax),%rdi
    60ed:	48 29 cf             	sub    %rcx,%rdi
    60f0:	4c 39 c7             	cmp    %r8,%rdi
    60f3:	73 3b                	jae    6130 <fwp_heap_alloc+0x1c0>
    60f5:	48 89 d7             	mov    %rdx,%rdi
    60f8:	e8 f3 fc ff ff       	call   5df0 <fwp_heap_alloc_slow>
    60fd:	48 89 c1             	mov    %rax,%rcx
    6100:	e9 43 ff ff ff       	jmp    6048 <fwp_heap_alloc+0xd8>
    6105:	0f 1f 00             	nopl   (%rax)
    6108:	48 89 c2             	mov    %rax,%rdx
    610b:	83 e0 01             	and    $0x1,%eax
    610e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6112:	48 d1 ea             	shr    $1,%rdx
    6115:	48 09 c2             	or     %rax,%rdx
    6118:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    611d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6121:	e9 3f ff ff ff       	jmp    6065 <fwp_heap_alloc+0xf5>
    6126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    612d:	00 00 00 
    6130:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    6134:	48 89 78 08          	mov    %rdi,0x8(%rax)
    6138:	e9 ad fe ff ff       	jmp    5fea <fwp_heap_alloc+0x7a>
    613d:	0f 1f 00             	nopl   (%rax)
    6140:	48 83 c4 10          	add    $0x10,%rsp
    6144:	48 89 d7             	mov    %rdx,%rdi
    6147:	5b                   	pop    %rbx
    6148:	e9 a3 fc ff ff       	jmp    5df0 <fwp_heap_alloc_slow>
    614d:	e8 de dc ff ff       	call   3e30 <fwp_heap_oom>
    6152:	0f 1f 00             	nopl   (%rax)
    6155:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    615c:	00 00 00 00 

0000000000006160 <fwp_apply>:
    6160:	55                   	push   %rbp
    6161:	48 89 f9             	mov    %rdi,%rcx
    6164:	48 89 e5             	mov    %rsp,%rbp
    6167:	41 57                	push   %r15
    6169:	41 56                	push   %r14
    616b:	41 55                	push   %r13
    616d:	41 89 f5             	mov    %esi,%r13d
    6170:	41 54                	push   %r12
    6172:	53                   	push   %rbx
    6173:	48 83 ec 28          	sub    $0x28,%rsp
    6177:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    617e:	00 00 
    6180:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    6184:	49 89 d6             	mov    %rdx,%r14
    6187:	44 8b 09             	mov    (%rcx),%r9d
    618a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    618e:	49 89 e0             	mov    %rsp,%r8
    6191:	49 c1 e1 05          	shl    $0x5,%r9
    6195:	4c 03 0d 1c 83 06 00 	add    0x6831c(%rip),%r9        # 6e4b8 <fwp_fns>
    619c:	41 8b 19             	mov    (%r9),%ebx
    619f:	45 85 e4             	test   %r12d,%r12d
    61a2:	75 2c                	jne    61d0 <fwp_apply+0x70>
    61a4:	41 39 dd             	cmp    %ebx,%r13d
    61a7:	72 27                	jb     61d0 <fwp_apply+0x70>
    61a9:	85 db                	test   %ebx,%ebx
    61ab:	0f 84 b7 01 00 00    	je     6368 <fwp_apply+0x208>
    61b1:	4c 89 f7             	mov    %r14,%rdi
    61b4:	41 ff 51 08          	call   *0x8(%r9)
    61b8:	48 89 c1             	mov    %rax,%rcx
    61bb:	41 39 dd             	cmp    %ebx,%r13d
    61be:	0f 84 7c 01 00 00    	je     6340 <fwp_apply+0x1e0>
    61c4:	89 d8                	mov    %ebx,%eax
    61c6:	41 29 dd             	sub    %ebx,%r13d
    61c9:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    61cd:	eb b8                	jmp    6187 <fwp_apply+0x27>
    61cf:	90                   	nop
    61d0:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    61d5:	41 39 df             	cmp    %ebx,%r15d
    61d8:	0f 82 dc 00 00 00    	jb     62ba <fwp_apply+0x15a>
    61de:	41 89 df             	mov    %ebx,%r15d
    61e1:	b8 01 00 00 00       	mov    $0x1,%eax
    61e6:	48 89 e2             	mov    %rsp,%rdx
    61e9:	45 29 e7             	sub    %r12d,%r15d
    61ec:	85 db                	test   %ebx,%ebx
    61ee:	0f 45 c3             	cmovne %ebx,%eax
    61f1:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    61f8:	00 
    61f9:	48 c1 e8 04          	shr    $0x4,%rax
    61fd:	48 c1 e0 04          	shl    $0x4,%rax
    6201:	48 89 c6             	mov    %rax,%rsi
    6204:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    620b:	48 29 f2             	sub    %rsi,%rdx
    620e:	48 39 d4             	cmp    %rdx,%rsp
    6211:	74 15                	je     6228 <fwp_apply+0xc8>
    6213:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    621a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    6221:	00 00 
    6223:	48 39 d4             	cmp    %rdx,%rsp
    6226:	75 eb                	jne    6213 <fwp_apply+0xb3>
    6228:	25 ff 0f 00 00       	and    $0xfff,%eax
    622d:	48 29 c4             	sub    %rax,%rsp
    6230:	48 85 c0             	test   %rax,%rax
    6233:	0f 85 59 01 00 00    	jne    6392 <fwp_apply+0x232>
    6239:	45 89 e2             	mov    %r12d,%r10d
    623c:	48 89 e6             	mov    %rsp,%rsi
    623f:	48 89 e7             	mov    %rsp,%rdi
    6242:	31 c0                	xor    %eax,%eax
    6244:	49 c1 e2 03          	shl    $0x3,%r10
    6248:	45 85 e4             	test   %r12d,%r12d
    624b:	74 25                	je     6272 <fwp_apply+0x112>
    624d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6254:	00 
    6255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    625c:	00 00 00 00 
    6260:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    6265:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    6269:	48 83 c0 08          	add    $0x8,%rax
    626d:	4c 39 d0             	cmp    %r10,%rax
    6270:	75 ee                	jne    6260 <fwp_apply+0x100>
    6272:	45 85 ff             	test   %r15d,%r15d
    6275:	0f 84 f4 00 00 00    	je     636f <fwp_apply+0x20f>
    627b:	44 89 fa             	mov    %r15d,%edx
    627e:	4c 89 f0             	mov    %r14,%rax
    6281:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    6285:	44 89 e2             	mov    %r12d,%edx
    6288:	66 90                	xchg   %ax,%ax
    628a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6291:	00 00 00 00 
    6295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    629c:	00 00 00 00 
    62a0:	4c 8b 10             	mov    (%rax),%r10
    62a3:	89 d1                	mov    %edx,%ecx
    62a5:	48 83 c0 08          	add    $0x8,%rax
    62a9:	83 c2 01             	add    $0x1,%edx
    62ac:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    62b0:	4c 39 d8             	cmp    %r11,%rax
    62b3:	75 eb                	jne    62a0 <fwp_apply+0x140>
    62b5:	e9 b5 00 00 00       	jmp    636f <fwp_apply+0x20f>
    62ba:	41 8d 7f 01          	lea    0x1(%r15),%edi
    62be:	be 02 00 00 00       	mov    $0x2,%esi
    62c3:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    62c7:	48 c1 e7 03          	shl    $0x3,%rdi
    62cb:	e8 a0 fc ff ff       	call   5f70 <fwp_heap_alloc>
    62d0:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    62d4:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    62d9:	48 89 c3             	mov    %rax,%rbx
    62dc:	66 0f 6e 01          	movd   (%rcx),%xmm0
    62e0:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    62e4:	66 0f d6 00          	movq   %xmm0,(%rax)
    62e8:	45 85 e4             	test   %r12d,%r12d
    62eb:	74 14                	je     6301 <fwp_apply+0x1a1>
    62ed:	44 89 e2             	mov    %r12d,%edx
    62f0:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    62f4:	48 8d 78 08          	lea    0x8(%rax),%rdi
    62f8:	48 c1 e2 03          	shl    $0x3,%rdx
    62fc:	e8 ef d2 ff ff       	call   35f0 <memmove@plt>
    6301:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    6305:	45 85 ed             	test   %r13d,%r13d
    6308:	74 2e                	je     6338 <fwp_apply+0x1d8>
    630a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6311:	00 00 00 00 
    6315:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    631c:	00 00 00 00 
    6320:	49 8b 16             	mov    (%r14),%rdx
    6323:	44 89 e0             	mov    %r12d,%eax
    6326:	49 83 c6 08          	add    $0x8,%r14
    632a:	41 83 c4 01          	add    $0x1,%r12d
    632e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    6333:	49 39 ce             	cmp    %rcx,%r14
    6336:	75 e8                	jne    6320 <fwp_apply+0x1c0>
    6338:	48 89 d9             	mov    %rbx,%rcx
    633b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6340:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    6344:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    634b:	00 00 
    634d:	75 4e                	jne    639d <fwp_apply+0x23d>
    634f:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    6353:	48 89 c8             	mov    %rcx,%rax
    6356:	5b                   	pop    %rbx
    6357:	41 5c                	pop    %r12
    6359:	41 5d                	pop    %r13
    635b:	41 5e                	pop    %r14
    635d:	41 5f                	pop    %r15
    635f:	5d                   	pop    %rbp
    6360:	c3                   	ret
    6361:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6368:	45 31 ff             	xor    %r15d,%r15d
    636b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    636f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    6373:	41 ff 51 08          	call   *0x8(%r9)
    6377:	48 89 c1             	mov    %rax,%rcx
    637a:	45 39 fd             	cmp    %r15d,%r13d
    637d:	74 c1                	je     6340 <fwp_apply+0x1e0>
    637f:	45 01 e5             	add    %r12d,%r13d
    6382:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    6386:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    638a:	41 29 dd             	sub    %ebx,%r13d
    638d:	e9 f5 fd ff ff       	jmp    6187 <fwp_apply+0x27>
    6392:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    6398:	e9 9c fe ff ff       	jmp    6239 <fwp_apply+0xd9>
    639d:	e8 ae d0 ff ff       	call   3450 <__stack_chk_fail@plt>
    63a2:	0f 1f 00             	nopl   (%rax)
    63a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    63ac:	00 00 00 00 

00000000000063b0 <fwp_p_ad_push>:
    63b0:	41 57                	push   %r15
    63b2:	41 56                	push   %r14
    63b4:	41 55                	push   %r13
    63b6:	49 89 d5             	mov    %rdx,%r13
    63b9:	41 54                	push   %r12
    63bb:	49 89 fc             	mov    %rdi,%r12
    63be:	55                   	push   %rbp
    63bf:	53                   	push   %rbx
    63c0:	48 83 ec 38          	sub    $0x38,%rsp
    63c4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    63c9:	48 85 ff             	test   %rdi,%rdi
    63cc:	79 09                	jns    63d7 <fwp_p_ad_push+0x27>
    63ce:	48 85 d2             	test   %rdx,%rdx
    63d1:	0f 88 a9 01 00 00    	js     6580 <fwp_p_ad_push+0x1d0>
    63d7:	48 89 f8             	mov    %rdi,%rax
    63da:	48 89 0c 24          	mov    %rcx,(%rsp)
    63de:	48 09 d0             	or     %rdx,%rax
    63e1:	0f 89 71 01 00 00    	jns    6558 <fwp_p_ad_push+0x1a8>
    63e7:	48 89 f8             	mov    %rdi,%rax
    63ea:	48 c1 f8 20          	sar    $0x20,%rax
    63ee:	48 85 ff             	test   %rdi,%rdi
    63f1:	79 24                	jns    6417 <fwp_p_ad_push+0x67>
    63f3:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    63f8:	48 89 d0             	mov    %rdx,%rax
    63fb:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    6402:	00 
    6403:	49 89 d4             	mov    %rdx,%r12
    6406:	48 c1 f8 20          	sar    $0x20,%rax
    640a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    6411:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6417:	48 89 c7             	mov    %rax,%rdi
    641a:	e8 11 e3 ff ff       	call   4730 <fwp_tape_of>
    641f:	48 89 c3             	mov    %rax,%rbx
    6422:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6427:	0f 85 6e 02 00 00    	jne    669b <fwp_p_ad_push+0x2eb>
    642d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    6431:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6438:	0f 8f 51 02 00 00    	jg     668f <fwp_p_ad_push+0x2df>
    643e:	44 89 e0             	mov    %r12d,%eax
    6441:	4c 39 f8             	cmp    %r15,%rax
    6444:	0f 8d 39 02 00 00    	jge    6683 <fwp_p_ad_push+0x2d3>
    644a:	4d 85 ed             	test   %r13,%r13
    644d:	78 0c                	js     645b <fwp_p_ad_push+0xab>
    644f:	44 89 e8             	mov    %r13d,%eax
    6452:	4c 39 f8             	cmp    %r15,%rax
    6455:	0f 8d 28 02 00 00    	jge    6683 <fwp_p_ad_push+0x2d3>
    645b:	4d 89 fe             	mov    %r15,%r14
    645e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6462:	49 8d 46 01          	lea    0x1(%r14),%rax
    6466:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    646c:	0f 87 1d 02 00 00    	ja     668f <fwp_p_ad_push+0x2df>
    6472:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    6476:	48 39 e8             	cmp    %rbp,%rax
    6479:	0f 8e 31 01 00 00    	jle    65b0 <fwp_p_ad_push+0x200>
    647f:	48 85 ed             	test   %rbp,%rbp
    6482:	ba 40 00 00 00       	mov    $0x40,%edx
    6487:	48 0f 44 ea          	cmove  %rdx,%rbp
    648b:	48 39 e8             	cmp    %rbp,%rax
    648e:	7e 20                	jle    64b0 <fwp_p_ad_push+0x100>
    6490:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    6497:	0f 8f 03 01 00 00    	jg     65a0 <fwp_p_ad_push+0x1f0>
    649d:	48 01 ed             	add    %rbp,%rbp
    64a0:	48 39 e8             	cmp    %rbp,%rax
    64a3:	7f eb                	jg     6490 <fwp_p_ad_push+0xe0>
    64a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    64ac:	00 00 00 00 
    64b0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    64b7:	00 
    64b8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    64bc:	ba 01 00 00 00       	mov    $0x1,%edx
    64c1:	48 89 c6             	mov    %rax,%rsi
    64c4:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    64c9:	e8 22 ed ff ff       	call   51f0 <ad_raw_realloc>
    64ce:	48 85 c0             	test   %rax,%rax
    64d1:	0f 84 d0 01 00 00    	je     66a7 <fwp_p_ad_push+0x2f7>
    64d7:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    64db:	48 89 ee             	mov    %rbp,%rsi
    64de:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    64e2:	48 89 43 20          	mov    %rax,0x20(%rbx)
    64e6:	48 c1 e6 04          	shl    $0x4,%rsi
    64ea:	48 8d 04 90          	lea    (%rax,%rdx,4),%rax
    64ee:	ba 02 00 00 00       	mov    $0x2,%edx
    64f3:	48 89 43 28          	mov    %rax,0x28(%rbx)
    64f7:	e8 f4 ec ff ff       	call   51f0 <ad_raw_realloc>
    64fc:	48 85 c0             	test   %rax,%rax
    64ff:	0f 84 a2 01 00 00    	je     66a7 <fwp_p_ad_push+0x2f7>
    6505:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    6509:	48 89 43 30          	mov    %rax,0x30(%rbx)
    650d:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6514:	00 
    6515:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    651c:	00 
    651d:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
    6524:	00 
    6525:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    6529:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    652e:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6532:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    6536:	4d 85 f6             	test   %r14,%r14
    6539:	0f 85 e5 00 00 00    	jne    6624 <fwp_p_ad_push+0x274>
    653f:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6543:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    6547:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    654b:	48 01 d1             	add    %rdx,%rcx
    654e:	48 89 4b 28          	mov    %rcx,0x28(%rbx)
    6552:	eb 7c                	jmp    65d0 <fwp_p_ad_push+0x220>
    6554:	0f 1f 40 00          	nopl   0x0(%rax)
    6558:	48 89 d0             	mov    %rdx,%rax
    655b:	48 c1 ff 20          	sar    $0x20,%rdi
    655f:	48 c1 f8 20          	sar    $0x20,%rax
    6563:	48 39 c7             	cmp    %rax,%rdi
    6566:	0f 84 ab fe ff ff    	je     6417 <fwp_p_ad_push+0x67>
    656c:	48 8d 3d 95 a4 00 00 	lea    0xa495(%rip),%rdi        # 10a08 <_IO_stdin_used+0xa08>
    6573:	e8 d8 de ff ff       	call   4450 <fwp_trap>
    6578:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    657f:	00 
    6580:	48 83 c4 38          	add    $0x38,%rsp
    6584:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    658b:	5b                   	pop    %rbx
    658c:	5d                   	pop    %rbp
    658d:	41 5c                	pop    %r12
    658f:	41 5d                	pop    %r13
    6591:	41 5e                	pop    %r14
    6593:	41 5f                	pop    %r15
    6595:	c3                   	ret
    6596:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    659d:	00 00 00 
    65a0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    65a5:	e9 06 ff ff ff       	jmp    64b0 <fwp_p_ad_push+0x100>
    65aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    65b0:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    65b4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    65b8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    65bf:	00 
    65c0:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    65c7:	00 
    65c8:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
    65cc:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    65d0:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    65d6:	46 89 24 12          	mov    %r12d,(%rdx,%r10,1)
    65da:	4d 85 ed             	test   %r13,%r13
    65dd:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    65e2:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    65e8:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    65ef:	4c 0f 48 e8          	cmovs  %rax,%r13
    65f3:	49 8d 47 01          	lea    0x1(%r15),%rax
    65f7:	46 89 2c 11          	mov    %r13d,(%rcx,%r10,1)
    65fb:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6601:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6605:	48 83 c4 38          	add    $0x38,%rsp
    6609:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6610:	ff ff ff 
    6613:	4c 21 e0             	and    %r12,%rax
    6616:	5b                   	pop    %rbx
    6617:	5d                   	pop    %rbp
    6618:	4c 09 f8             	or     %r15,%rax
    661b:	41 5c                	pop    %r12
    661d:	41 5d                	pop    %r13
    661f:	41 5e                	pop    %r14
    6621:	41 5f                	pop    %r15
    6623:	c3                   	ret
    6624:	4c 89 ca             	mov    %r9,%rdx
    6627:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    662c:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    6631:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    6636:	e8 b5 cf ff ff       	call   35f0 <memmove@plt>
    663b:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    6640:	4c 03 73 30          	add    0x30(%rbx),%r14
    6644:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    6649:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    664d:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6651:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    6656:	48 03 7b 20          	add    0x20(%rbx),%rdi
    665a:	4c 89 d2             	mov    %r10,%rdx
    665d:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    6662:	e8 89 cf ff ff       	call   35f0 <memmove@plt>
    6667:	48 8b 43 30          	mov    0x30(%rbx),%rax
    666b:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    666f:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    6674:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6679:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    667e:	e9 c0 fe ff ff       	jmp    6543 <fwp_p_ad_push+0x193>
    6683:	48 8d 3d 38 9b 00 00 	lea    0x9b38(%rip),%rdi        # 101c2 <_IO_stdin_used+0x1c2>
    668a:	e8 c1 dd ff ff       	call   4450 <fwp_trap>
    668f:	48 8d 3d 11 9b 00 00 	lea    0x9b11(%rip),%rdi        # 101a7 <_IO_stdin_used+0x1a7>
    6696:	e8 b5 dd ff ff       	call   4450 <fwp_trap>
    669b:	48 8d 3d ae a3 00 00 	lea    0xa3ae(%rip),%rdi        # 10a50 <_IO_stdin_used+0xa50>
    66a2:	e8 a9 dd ff ff       	call   4450 <fwp_trap>
    66a7:	48 89 df             	mov    %rbx,%rdi
    66aa:	e8 e1 d5 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    66af:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    66b3:	48 85 ff             	test   %rdi,%rdi
    66b6:	74 05                	je     66bd <fwp_p_ad_push+0x30d>
    66b8:	e8 73 ea ff ff       	call   5130 <ad_raw_free.part.0>
    66bd:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    66c1:	48 85 ff             	test   %rdi,%rdi
    66c4:	74 05                	je     66cb <fwp_p_ad_push+0x31b>
    66c6:	e8 65 ea ff ff       	call   5130 <ad_raw_free.part.0>
    66cb:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    66cf:	48 85 ff             	test   %rdi,%rdi
    66d2:	74 05                	je     66d9 <fwp_p_ad_push+0x329>
    66d4:	e8 57 ea ff ff       	call   5130 <ad_raw_free.part.0>
    66d9:	31 c9                	xor    %ecx,%ecx
    66db:	31 c0                	xor    %eax,%eax
    66dd:	31 d2                	xor    %edx,%edx
    66df:	be 01 00 00 00       	mov    $0x1,%esi
    66e4:	89 53 04             	mov    %edx,0x4(%rbx)
    66e7:	66 0f ef c0          	pxor   %xmm0,%xmm0
    66eb:	ba 13 00 00 00       	mov    $0x13,%edx
    66f0:	48 8d 3d 11 99 00 00 	lea    0x9911(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    66f7:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    66fb:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    66ff:	48 8b 0d 5a d9 00 00 	mov    0xd95a(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    6706:	48 89 43 40          	mov    %rax,0x40(%rbx)
    670a:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    670e:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    6712:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    6716:	e8 45 cf ff ff       	call   3660 <fwrite@plt>
    671b:	31 ff                	xor    %edi,%edi
    671d:	e8 7e ce ff ff       	call   35a0 <fflush@plt>
    6722:	bf 66 00 00 00       	mov    $0x66,%edi
    6727:	e8 54 cf ff ff       	call   3680 <_Exit@plt>
    672c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006730 <w107>:
    6730:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6734:	41 55                	push   %r13
    6736:	48 89 fa             	mov    %rdi,%rdx
    6739:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    673d:	41 54                	push   %r12
    673f:	49 89 fc             	mov    %rdi,%r12
    6742:	55                   	push   %rbp
    6743:	53                   	push   %rbx
    6744:	48 89 f3             	mov    %rsi,%rbx
    6747:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    674c:	48 89 f1             	mov    %rsi,%rcx
    674f:	48 83 ec 28          	sub    $0x28,%rsp
    6753:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6759:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    675f:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6765:	e8 46 fc ff ff       	call   63b0 <fwp_p_ad_push>
    676a:	48 89 c7             	mov    %rax,%rdi
    676d:	e8 4e e8 ff ff       	call   4fc0 <caf61>
    6772:	66 48 0f 6e c0       	movq   %rax,%xmm0
    6777:	e8 44 e8 ff ff       	call   4fc0 <caf61>
    677c:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6782:	66 0f 57 05 26 a6 00 	xorpd  0xa626(%rip),%xmm0        # 10db0 <msg.8+0x80>
    6789:	00 
    678a:	48 89 da             	mov    %rbx,%rdx
    678d:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6793:	48 89 c1             	mov    %rax,%rcx
    6796:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    679b:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    67a0:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    67a6:	e8 05 fc ff ff       	call   63b0 <fwp_p_ad_push>
    67ab:	4c 89 e7             	mov    %r12,%rdi
    67ae:	49 89 c5             	mov    %rax,%r13
    67b1:	e8 0a e8 ff ff       	call   4fc0 <caf61>
    67b6:	48 89 c6             	mov    %rax,%rsi
    67b9:	e8 02 e8 ff ff       	call   4fc0 <caf61>
    67be:	66 48 0f 6e d6       	movq   %rsi,%xmm2
    67c3:	f2 0f 10 05 25 a6 00 	movsd  0xa625(%rip),%xmm0        # 10df0 <msg.8+0xc0>
    67ca:	00 
    67cb:	66 0f 57 15 dd a5 00 	xorpd  0xa5dd(%rip),%xmm2        # 10db0 <msg.8+0x80>
    67d2:	00 
    67d3:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    67d9:	48 89 c1             	mov    %rax,%rcx
    67dc:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    67e3:	66 48 0f 7e d6       	movq   %xmm2,%rsi
    67e8:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    67ed:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    67f3:	e8 b8 fb ff ff       	call   63b0 <fwp_p_ad_push>
    67f8:	48 89 e9             	mov    %rbp,%rcx
    67fb:	4c 89 ea             	mov    %r13,%rdx
    67fe:	48 89 ee             	mov    %rbp,%rsi
    6801:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6807:	4c 89 ef             	mov    %r13,%rdi
    680a:	49 89 c4             	mov    %rax,%r12
    680d:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6811:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6817:	e8 94 fb ff ff       	call   63b0 <fwp_p_ad_push>
    681c:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6822:	f2 0f 59 1d ce a5 00 	mulsd  0xa5ce(%rip),%xmm3        # 10df8 <msg.8+0xc8>
    6829:	00 
    682a:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6831:	00 59 40 
    6834:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6839:	48 89 c2             	mov    %rax,%rdx
    683c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6843:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6849:	e8 62 fb ff ff       	call   63b0 <fwp_p_ad_push>
    684e:	4c 89 e2             	mov    %r12,%rdx
    6851:	48 89 d9             	mov    %rbx,%rcx
    6854:	48 89 de             	mov    %rbx,%rsi
    6857:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    685d:	4c 89 e7             	mov    %r12,%rdi
    6860:	48 89 c5             	mov    %rax,%rbp
    6863:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6867:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    686d:	e8 3e fb ff ff       	call   63b0 <fwp_p_ad_push>
    6872:	48 89 c7             	mov    %rax,%rdi
    6875:	e8 46 e7 ff ff       	call   4fc0 <caf61>
    687a:	48 89 c6             	mov    %rax,%rsi
    687d:	e8 3e e7 ff ff       	call   4fc0 <caf61>
    6882:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6888:	48 89 ea             	mov    %rbp,%rdx
    688b:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6891:	48 89 c1             	mov    %rax,%rcx
    6894:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6899:	e8 12 fb ff ff       	call   63b0 <fwp_p_ad_push>
    689e:	48 83 c4 28          	add    $0x28,%rsp
    68a2:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    68a7:	5b                   	pop    %rbx
    68a8:	5d                   	pop    %rbp
    68a9:	41 5c                	pop    %r12
    68ab:	41 5d                	pop    %r13
    68ad:	c3                   	ret
    68ae:	66 90                	xchg   %ax,%ax

00000000000068b0 <w164.constprop.0>:
    68b0:	41 54                	push   %r12
    68b2:	55                   	push   %rbp
    68b3:	53                   	push   %rbx
    68b4:	48 83 ec 10          	sub    $0x10,%rsp
    68b8:	4c 8b 27             	mov    (%rdi),%r12
    68bb:	4d 85 e4             	test   %r12,%r12
    68be:	74 78                	je     6938 <w164.constprop.0+0x88>
    68c0:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    68c7:	00 00 
    68c9:	48 89 fd             	mov    %rdi,%rbp
    68cc:	31 db                	xor    %ebx,%ebx
    68ce:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    68d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    68dc:	00 00 00 00 
    68e0:	4c 8b 44 dd 10       	mov    0x10(%rbp,%rbx,8),%r8
    68e5:	f2 0f 10 44 dd 08    	movsd  0x8(%rbp,%rbx,8),%xmm0
    68eb:	48 83 c3 02          	add    $0x2,%rbx
    68ef:	e8 cc e6 ff ff       	call   4fc0 <caf61>
    68f4:	48 89 c6             	mov    %rax,%rsi
    68f7:	e8 c4 e6 ff ff       	call   4fc0 <caf61>
    68fc:	f2 0f 58 44 24 08    	addsd  0x8(%rsp),%xmm0
    6902:	4c 89 c2             	mov    %r8,%rdx
    6905:	48 89 c1             	mov    %rax,%rcx
    6908:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    690e:	e8 9d fa ff ff       	call   63b0 <fwp_p_ad_push>
    6913:	48 89 c7             	mov    %rax,%rdi
    6916:	4c 39 e3             	cmp    %r12,%rbx
    6919:	72 c5                	jb     68e0 <w164.constprop.0+0x30>
    691b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6920:	48 83 c4 10          	add    $0x10,%rsp
    6924:	5b                   	pop    %rbx
    6925:	5d                   	pop    %rbp
    6926:	66 48 0f 6e c0       	movq   %rax,%xmm0
    692b:	41 5c                	pop    %r12
    692d:	48 89 f8             	mov    %rdi,%rax
    6930:	c3                   	ret
    6931:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6938:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    693f:	00 00 
    6941:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6948:	eb d1                	jmp    691b <w164.constprop.0+0x6b>
    694a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000006950 <fwp_data.part.0.constprop.0>:
    6950:	41 56                	push   %r14
    6952:	8b 05 ac 72 06 00    	mov    0x672ac(%rip),%eax        # 6dc04 <fwp_heap+0x13a4>
    6958:	41 89 fe             	mov    %edi,%r14d
    695b:	41 55                	push   %r13
    695d:	44 8b 2d c4 7b 06 00 	mov    0x67bc4(%rip),%r13d        # 6e528 <iteration_active>
    6964:	41 54                	push   %r12
    6966:	49 89 f4             	mov    %rsi,%r12
    6969:	55                   	push   %rbp
    696a:	53                   	push   %rbx
    696b:	45 85 ed             	test   %r13d,%r13d
    696e:	0f 84 1c 01 00 00    	je     6a90 <fwp_data.part.0.constprop.0+0x140>
    6974:	48 83 05 a4 7b 06 00 	addq   $0x1,0x67ba4(%rip)        # 6e520 <iteration_requests>
    697b:	01 
    697c:	48 83 05 94 7b 06 00 	addq   $0x18,0x67b94(%rip)        # 6e518 <iteration_bytes>
    6983:	18 
    6984:	85 c0                	test   %eax,%eax
    6986:	0f 84 8c 01 00 00    	je     6b18 <fwp_data.part.0.constprop.0+0x1c8>
    698c:	0f b6 05 6f 6e 06 00 	movzbl 0x66e6f(%rip),%eax        # 6d802 <fwp_heap+0xfa2>
    6993:	48 8d 15 c6 5e 06 00 	lea    0x65ec6(%rip),%rdx        # 6c860 <fwp_heap>
    699a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    69a1:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    69a5:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    69a9:	48 8b 18             	mov    (%rax),%rbx
    69ac:	48 85 db             	test   %rbx,%rbx
    69af:	0f 84 fb 00 00 00    	je     6ab0 <fwp_data.part.0.constprop.0+0x160>
    69b5:	48 8b 13             	mov    (%rbx),%rdx
    69b8:	48 f7 d2             	not    %rdx
    69bb:	48 89 10             	mov    %rdx,(%rax)
    69be:	48 83 fd 18          	cmp    $0x18,%rbp
    69c2:	76 1b                	jbe    69df <fwp_data.part.0.constprop.0+0x8f>
    69c4:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    69c8:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    69cc:	31 f6                	xor    %esi,%esi
    69ce:	48 c1 e8 03          	shr    $0x3,%rax
    69d2:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    69d9:	00 
    69da:	e8 d1 ca ff ff       	call   34b0 <memset@plt>
    69df:	48 89 e8             	mov    %rbp,%rax
    69e2:	48 03 05 97 72 06 00 	add    0x67297(%rip),%rax        # 6dc80 <fwp_heap+0x1420>
    69e9:	0f 82 3d 01 00 00    	jb     6b2c <fwp_data.part.0.constprop.0+0x1dc>
    69ef:	48 39 05 92 72 06 00 	cmp    %rax,0x67292(%rip)        # 6dc88 <fwp_heap+0x1428>
    69f6:	48 89 05 83 72 06 00 	mov    %rax,0x67283(%rip)        # 6dc80 <fwp_heap+0x1420>
    69fd:	73 07                	jae    6a06 <fwp_data.part.0.constprop.0+0xb6>
    69ff:	48 89 05 82 72 06 00 	mov    %rax,0x67282(%rip)        # 6dc88 <fwp_heap+0x1428>
    6a06:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6a0a:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6a0f:	f2 0f 58 05 81 72 06 	addsd  0x67281(%rip),%xmm0        # 6dc98 <fwp_heap+0x1438>
    6a16:	00 
    6a17:	f2 0f 11 05 79 72 06 	movsd  %xmm0,0x67279(%rip)        # 6dc98 <fwp_heap+0x1438>
    6a1e:	00 
    6a1f:	45 85 ed             	test   %r13d,%r13d
    6a22:	74 33                	je     6a57 <fwp_data.part.0.constprop.0+0x107>
    6a24:	48 8b 05 55 72 06 00 	mov    0x67255(%rip),%rax        # 6dc80 <fwp_heap+0x1420>
    6a2b:	48 85 c0             	test   %rax,%rax
    6a2e:	0f 88 a4 00 00 00    	js     6ad8 <fwp_data.part.0.constprop.0+0x188>
    6a34:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6a38:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6a3d:	f2 0f 5c 05 c3 7a 06 	subsd  0x67ac3(%rip),%xmm0        # 6e508 <iteration_start_charge>
    6a44:	00 
    6a45:	66 0f 2f 05 b3 7a 06 	comisd 0x67ab3(%rip),%xmm0        # 6e500 <iteration_peak>
    6a4c:	00 
    6a4d:	76 08                	jbe    6a57 <fwp_data.part.0.constprop.0+0x107>
    6a4f:	f2 0f 11 05 a9 7a 06 	movsd  %xmm0,0x67aa9(%rip)        # 6e500 <iteration_peak>
    6a56:	00 
    6a57:	b8 02 00 00 00       	mov    $0x2,%eax
    6a5c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6a61:	66 0f 6e c8          	movd   %eax,%xmm1
    6a65:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6a69:	66 0f d6 03          	movq   %xmm0,(%rbx)
    6a6d:	49 8b 04 24          	mov    (%r12),%rax
    6a71:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6a75:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6a7a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6a7e:	48 89 d8             	mov    %rbx,%rax
    6a81:	5b                   	pop    %rbx
    6a82:	5d                   	pop    %rbp
    6a83:	41 5c                	pop    %r12
    6a85:	41 5d                	pop    %r13
    6a87:	41 5e                	pop    %r14
    6a89:	c3                   	ret
    6a8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a90:	85 c0                	test   %eax,%eax
    6a92:	0f 85 f4 fe ff ff    	jne    698c <fwp_data.part.0.constprop.0+0x3c>
    6a98:	31 f6                	xor    %esi,%esi
    6a9a:	bf 18 00 00 00       	mov    $0x18,%edi
    6a9f:	e8 cc f4 ff ff       	call   5f70 <fwp_heap_alloc>
    6aa4:	48 89 c3             	mov    %rax,%rbx
    6aa7:	eb ae                	jmp    6a57 <fwp_data.part.0.constprop.0+0x107>
    6aa9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6ab0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6ab4:	48 85 db             	test   %rbx,%rbx
    6ab7:	74 47                	je     6b00 <fwp_data.part.0.constprop.0+0x1b0>
    6ab9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    6abd:	48 29 da             	sub    %rbx,%rdx
    6ac0:	48 39 ea             	cmp    %rbp,%rdx
    6ac3:	72 3b                	jb     6b00 <fwp_data.part.0.constprop.0+0x1b0>
    6ac5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6ac9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6acd:	e9 ec fe ff ff       	jmp    69be <fwp_data.part.0.constprop.0+0x6e>
    6ad2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ad8:	48 89 c2             	mov    %rax,%rdx
    6adb:	83 e0 01             	and    $0x1,%eax
    6ade:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6ae2:	48 d1 ea             	shr    $1,%rdx
    6ae5:	48 09 c2             	or     %rax,%rdx
    6ae8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    6aed:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6af1:	e9 47 ff ff ff       	jmp    6a3d <fwp_data.part.0.constprop.0+0xed>
    6af6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6afd:	00 00 00 
    6b00:	31 f6                	xor    %esi,%esi
    6b02:	bf 18 00 00 00       	mov    $0x18,%edi
    6b07:	e8 64 f4 ff ff       	call   5f70 <fwp_heap_alloc>
    6b0c:	48 89 c3             	mov    %rax,%rbx
    6b0f:	e9 0b ff ff ff       	jmp    6a1f <fwp_data.part.0.constprop.0+0xcf>
    6b14:	0f 1f 40 00          	nopl   0x0(%rax)
    6b18:	31 f6                	xor    %esi,%esi
    6b1a:	bf 18 00 00 00       	mov    $0x18,%edi
    6b1f:	e8 4c f4 ff ff       	call   5f70 <fwp_heap_alloc>
    6b24:	48 89 c3             	mov    %rax,%rbx
    6b27:	e9 f8 fe ff ff       	jmp    6a24 <fwp_data.part.0.constprop.0+0xd4>
    6b2c:	e8 ff d2 ff ff       	call   3e30 <fwp_heap_oom>
    6b31:	0f 1f 40 00          	nopl   0x0(%rax)
    6b35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6b3c:	00 00 00 00 

0000000000006b40 <fwp_rc_share>:
    6b40:	48 8b 05 f1 70 06 00 	mov    0x670f1(%rip),%rax        # 6dc38 <fwp_heap+0x13d8>
    6b47:	48 2b 3d c2 70 06 00 	sub    0x670c2(%rip),%rdi        # 6dc10 <fwp_heap+0x13b0>
    6b4e:	48 c1 e0 10          	shl    $0x10,%rax
    6b52:	48 39 c7             	cmp    %rax,%rdi
    6b55:	73 4a                	jae    6ba1 <fwp_rc_share+0x61>
    6b57:	48 89 f8             	mov    %rdi,%rax
    6b5a:	48 c1 e8 10          	shr    $0x10,%rax
    6b5e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6b62:	48 8b 05 ef 70 06 00 	mov    0x670ef(%rip),%rax        # 6dc58 <fwp_heap+0x13f8>
    6b69:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6b6d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6b71:	48 85 d2             	test   %rdx,%rdx
    6b74:	74 2b                	je     6ba1 <fwp_rc_share+0x61>
    6b76:	0f b6 08             	movzbl (%rax),%ecx
    6b79:	80 f9 02             	cmp    $0x2,%cl
    6b7c:	74 2a                	je     6ba8 <fwp_rc_share+0x68>
    6b7e:	80 f9 01             	cmp    $0x1,%cl
    6b81:	75 1e                	jne    6ba1 <fwp_rc_share+0x61>
    6b83:	8b 48 18             	mov    0x18(%rax),%ecx
    6b86:	0f b7 ff             	movzwl %di,%edi
    6b89:	8b 40 1c             	mov    0x1c(%rax),%eax
    6b8c:	48 0f af f9          	imul   %rcx,%rdi
    6b90:	48 c1 ef 20          	shr    $0x20,%rdi
    6b94:	48 39 c7             	cmp    %rax,%rdi
    6b97:	73 08                	jae    6ba1 <fwp_rc_share+0x61>
    6b99:	48 01 fa             	add    %rdi,%rdx
    6b9c:	80 3a 00             	cmpb   $0x0,(%rdx)
    6b9f:	75 0d                	jne    6bae <fwp_rc_share+0x6e>
    6ba1:	c3                   	ret
    6ba2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ba8:	66 85 ff             	test   %di,%di
    6bab:	74 ef                	je     6b9c <fwp_rc_share+0x5c>
    6bad:	c3                   	ret
    6bae:	50                   	push   %rax
    6baf:	48 8d 3d ca 9e 00 00 	lea    0x9eca(%rip),%rdi        # 10a80 <_IO_stdin_used+0xa80>
    6bb6:	e8 95 d8 ff ff       	call   4450 <fwp_trap>
    6bbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006bc0 <fwp_rc_fresh>:
    6bc0:	48 8b 15 71 70 06 00 	mov    0x67071(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    6bc7:	48 89 f8             	mov    %rdi,%rax
    6bca:	48 89 fe             	mov    %rdi,%rsi
    6bcd:	48 2b 05 3c 70 06 00 	sub    0x6703c(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    6bd4:	48 c1 e2 10          	shl    $0x10,%rdx
    6bd8:	48 39 d0             	cmp    %rdx,%rax
    6bdb:	73 4f                	jae    6c2c <fwp_rc_fresh+0x6c>
    6bdd:	48 89 c2             	mov    %rax,%rdx
    6be0:	48 c1 ea 10          	shr    $0x10,%rdx
    6be4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6be8:	48 8b 15 69 70 06 00 	mov    0x67069(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    6bef:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6bf3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6bf7:	48 85 d2             	test   %rdx,%rdx
    6bfa:	74 30                	je     6c2c <fwp_rc_fresh+0x6c>
    6bfc:	0f b6 39             	movzbl (%rcx),%edi
    6bff:	40 80 ff 02          	cmp    $0x2,%dil
    6c03:	74 2b                	je     6c30 <fwp_rc_fresh+0x70>
    6c05:	40 80 ff 01          	cmp    $0x1,%dil
    6c09:	75 21                	jne    6c2c <fwp_rc_fresh+0x6c>
    6c0b:	8b 79 18             	mov    0x18(%rcx),%edi
    6c0e:	0f b7 c0             	movzwl %ax,%eax
    6c11:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c14:	48 0f af c7          	imul   %rdi,%rax
    6c18:	48 c1 e8 20          	shr    $0x20,%rax
    6c1c:	48 39 c8             	cmp    %rcx,%rax
    6c1f:	73 0b                	jae    6c2c <fwp_rc_fresh+0x6c>
    6c21:	48 01 c2             	add    %rax,%rdx
    6c24:	80 3a ff             	cmpb   $0xff,(%rdx)
    6c27:	74 17                	je     6c40 <fwp_rc_fresh+0x80>
    6c29:	c6 02 01             	movb   $0x1,(%rdx)
    6c2c:	48 89 f0             	mov    %rsi,%rax
    6c2f:	c3                   	ret
    6c30:	66 85 c0             	test   %ax,%ax
    6c33:	74 ef                	je     6c24 <fwp_rc_fresh+0x64>
    6c35:	48 89 f0             	mov    %rsi,%rax
    6c38:	c3                   	ret
    6c39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c40:	48 83 ec 18          	sub    $0x18,%rsp
    6c44:	48 89 d7             	mov    %rdx,%rdi
    6c47:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6c4c:	48 89 14 24          	mov    %rdx,(%rsp)
    6c50:	e8 db eb ff ff       	call   5830 <fwp_rc_forget_slot>
    6c55:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6c5a:	48 8b 14 24          	mov    (%rsp),%rdx
    6c5e:	48 89 f0             	mov    %rsi,%rax
    6c61:	c6 02 01             	movb   $0x1,(%rdx)
    6c64:	48 83 c4 18          	add    $0x18,%rsp
    6c68:	c3                   	ret
    6c69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006c70 <fwp_rc_free_arr>:
    6c70:	48 8b 15 c1 6f 06 00 	mov    0x66fc1(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    6c77:	48 89 f8             	mov    %rdi,%rax
    6c7a:	48 2b 05 8f 6f 06 00 	sub    0x66f8f(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    6c81:	48 c1 e2 10          	shl    $0x10,%rdx
    6c85:	48 39 d0             	cmp    %rdx,%rax
    6c88:	73 5b                	jae    6ce5 <fwp_rc_free_arr+0x75>
    6c8a:	48 89 c2             	mov    %rax,%rdx
    6c8d:	48 c1 ea 10          	shr    $0x10,%rdx
    6c91:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c95:	48 8b 15 bc 6f 06 00 	mov    0x66fbc(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    6c9c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6ca0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6ca4:	48 85 c9             	test   %rcx,%rcx
    6ca7:	74 3c                	je     6ce5 <fwp_rc_free_arr+0x75>
    6ca9:	0f b6 32             	movzbl (%rdx),%esi
    6cac:	40 80 fe 02          	cmp    $0x2,%sil
    6cb0:	74 2e                	je     6ce0 <fwp_rc_free_arr+0x70>
    6cb2:	40 80 fe 01          	cmp    $0x1,%sil
    6cb6:	75 2d                	jne    6ce5 <fwp_rc_free_arr+0x75>
    6cb8:	8b 72 18             	mov    0x18(%rdx),%esi
    6cbb:	0f b7 c0             	movzwl %ax,%eax
    6cbe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6cc1:	48 0f af c6          	imul   %rsi,%rax
    6cc5:	48 c1 e8 20          	shr    $0x20,%rax
    6cc9:	48 39 d0             	cmp    %rdx,%rax
    6ccc:	73 17                	jae    6ce5 <fwp_rc_free_arr+0x75>
    6cce:	48 01 c1             	add    %rax,%rcx
    6cd1:	80 39 01             	cmpb   $0x1,(%rcx)
    6cd4:	75 0f                	jne    6ce5 <fwp_rc_free_arr+0x75>
    6cd6:	e9 95 ed ff ff       	jmp    5a70 <fwp_mem_free>
    6cdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6ce0:	66 85 c0             	test   %ax,%ax
    6ce3:	74 ec                	je     6cd1 <fwp_rc_free_arr+0x61>
    6ce5:	c3                   	ret
    6ce6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6ced:	00 00 00 

0000000000006cf0 <fwp_rc_dup>:
    6cf0:	f3 0f 1e fa          	endbr64
    6cf4:	48 8b 05 3d 6f 06 00 	mov    0x66f3d(%rip),%rax        # 6dc38 <fwp_heap+0x13d8>
    6cfb:	48 2b 3d 0e 6f 06 00 	sub    0x66f0e(%rip),%rdi        # 6dc10 <fwp_heap+0x13b0>
    6d02:	48 c1 e0 10          	shl    $0x10,%rax
    6d06:	48 39 c7             	cmp    %rax,%rdi
    6d09:	73 60                	jae    6d6b <fwp_rc_dup+0x7b>
    6d0b:	48 89 f8             	mov    %rdi,%rax
    6d0e:	48 c1 e8 10          	shr    $0x10,%rax
    6d12:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6d16:	48 8b 05 3b 6f 06 00 	mov    0x66f3b(%rip),%rax        # 6dc58 <fwp_heap+0x13f8>
    6d1d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6d21:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6d25:	48 85 c0             	test   %rax,%rax
    6d28:	74 41                	je     6d6b <fwp_rc_dup+0x7b>
    6d2a:	0f b6 0a             	movzbl (%rdx),%ecx
    6d2d:	80 f9 02             	cmp    $0x2,%cl
    6d30:	74 3e                	je     6d70 <fwp_rc_dup+0x80>
    6d32:	80 f9 01             	cmp    $0x1,%cl
    6d35:	75 34                	jne    6d6b <fwp_rc_dup+0x7b>
    6d37:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6d3a:	0f b7 ff             	movzwl %di,%edi
    6d3d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6d40:	48 0f af f9          	imul   %rcx,%rdi
    6d44:	48 c1 ef 20          	shr    $0x20,%rdi
    6d48:	48 39 d7             	cmp    %rdx,%rdi
    6d4b:	73 1e                	jae    6d6b <fwp_rc_dup+0x7b>
    6d4d:	48 01 f8             	add    %rdi,%rax
    6d50:	0f b6 10             	movzbl (%rax),%edx
    6d53:	84 d2                	test   %dl,%dl
    6d55:	74 14                	je     6d6b <fwp_rc_dup+0x7b>
    6d57:	8b 0d cb 77 06 00    	mov    0x677cb(%rip),%ecx        # 6e528 <iteration_active>
    6d5d:	85 c9                	test   %ecx,%ecx
    6d5f:	75 1f                	jne    6d80 <fwp_rc_dup+0x90>
    6d61:	80 fa fd             	cmp    $0xfd,%dl
    6d64:	77 2a                	ja     6d90 <fwp_rc_dup+0xa0>
    6d66:	83 c2 01             	add    $0x1,%edx
    6d69:	88 10                	mov    %dl,(%rax)
    6d6b:	c3                   	ret
    6d6c:	0f 1f 40 00          	nopl   0x0(%rax)
    6d70:	66 85 ff             	test   %di,%di
    6d73:	74 db                	je     6d50 <fwp_rc_dup+0x60>
    6d75:	c3                   	ret
    6d76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d7d:	00 00 00 
    6d80:	48 83 05 88 77 06 00 	addq   $0x1,0x67788(%rip)        # 6e510 <iteration_retains>
    6d87:	01 
    6d88:	eb d7                	jmp    6d61 <fwp_rc_dup+0x71>
    6d8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d90:	48 89 c7             	mov    %rax,%rdi
    6d93:	e9 78 e9 ff ff       	jmp    5710 <fwp_rc_wide_dup>
    6d98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6d9f:	00 

0000000000006da0 <fwp_owned_entry161>:
    6da0:	f3 0f 1e fa          	endbr64
    6da4:	48 83 ec 38          	sub    $0x38,%rsp
    6da8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6dad:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6db4:	00 00 
    6db6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6dbb:	31 c0                	xor    %eax,%eax
    6dbd:	48 8b 07             	mov    (%rdi),%rax
    6dc0:	48 03 47 10          	add    0x10(%rdi),%rax
    6dc4:	0f 80 c2 00 00 00    	jo     6e8c <fwp_owned_entry161+0xec>
    6dca:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6dcf:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6dd4:	31 ff                	xor    %edi,%edi
    6dd6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6dda:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6ddf:	e8 6c fb ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    6de4:	48 8b 15 4d 6e 06 00 	mov    0x66e4d(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    6deb:	48 89 c6             	mov    %rax,%rsi
    6dee:	48 2b 05 1b 6e 06 00 	sub    0x66e1b(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    6df5:	48 c1 e2 10          	shl    $0x10,%rdx
    6df9:	48 39 d0             	cmp    %rdx,%rax
    6dfc:	73 4f                	jae    6e4d <fwp_owned_entry161+0xad>
    6dfe:	48 89 c2             	mov    %rax,%rdx
    6e01:	48 c1 ea 10          	shr    $0x10,%rdx
    6e05:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6e09:	48 8b 15 48 6e 06 00 	mov    0x66e48(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    6e10:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6e14:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6e18:	48 85 d2             	test   %rdx,%rdx
    6e1b:	74 30                	je     6e4d <fwp_owned_entry161+0xad>
    6e1d:	0f b6 39             	movzbl (%rcx),%edi
    6e20:	40 80 ff 02          	cmp    $0x2,%dil
    6e24:	74 42                	je     6e68 <fwp_owned_entry161+0xc8>
    6e26:	40 80 ff 01          	cmp    $0x1,%dil
    6e2a:	75 21                	jne    6e4d <fwp_owned_entry161+0xad>
    6e2c:	8b 79 18             	mov    0x18(%rcx),%edi
    6e2f:	0f b7 c0             	movzwl %ax,%eax
    6e32:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6e35:	48 0f af c7          	imul   %rdi,%rax
    6e39:	48 c1 e8 20          	shr    $0x20,%rax
    6e3d:	48 39 c8             	cmp    %rcx,%rax
    6e40:	73 0b                	jae    6e4d <fwp_owned_entry161+0xad>
    6e42:	48 01 c2             	add    %rax,%rdx
    6e45:	80 3a ff             	cmpb   $0xff,(%rdx)
    6e48:	74 26                	je     6e70 <fwp_owned_entry161+0xd0>
    6e4a:	c6 02 01             	movb   $0x1,(%rdx)
    6e4d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6e52:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6e59:	00 00 
    6e5b:	75 34                	jne    6e91 <fwp_owned_entry161+0xf1>
    6e5d:	48 89 f0             	mov    %rsi,%rax
    6e60:	48 83 c4 38          	add    $0x38,%rsp
    6e64:	c3                   	ret
    6e65:	0f 1f 00             	nopl   (%rax)
    6e68:	66 85 c0             	test   %ax,%ax
    6e6b:	75 e0                	jne    6e4d <fwp_owned_entry161+0xad>
    6e6d:	eb d6                	jmp    6e45 <fwp_owned_entry161+0xa5>
    6e6f:	90                   	nop
    6e70:	48 89 d7             	mov    %rdx,%rdi
    6e73:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6e78:	48 89 14 24          	mov    %rdx,(%rsp)
    6e7c:	e8 af e9 ff ff       	call   5830 <fwp_rc_forget_slot>
    6e81:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6e86:	48 8b 14 24          	mov    (%rsp),%rdx
    6e8a:	eb be                	jmp    6e4a <fwp_owned_entry161+0xaa>
    6e8c:	e8 6f c8 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6e91:	e8 ba c5 ff ff       	call   3450 <__stack_chk_fail@plt>
    6e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e9d:	00 00 00 

0000000000006ea0 <e161>:
    6ea0:	f3 0f 1e fa          	endbr64
    6ea4:	53                   	push   %rbx
    6ea5:	48 83 ec 30          	sub    $0x30,%rsp
    6ea9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6eae:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6eb5:	00 00 
    6eb7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6ebc:	31 c0                	xor    %eax,%eax
    6ebe:	48 8b 07             	mov    (%rdi),%rax
    6ec1:	48 03 47 10          	add    0x10(%rdi),%rax
    6ec5:	0f 80 c9 00 00 00    	jo     6f94 <e161+0xf4>
    6ecb:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6ed0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6ed5:	31 ff                	xor    %edi,%edi
    6ed7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6edb:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6ee0:	e8 6b fa ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    6ee5:	48 8b 15 4c 6d 06 00 	mov    0x66d4c(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    6eec:	48 89 c3             	mov    %rax,%rbx
    6eef:	48 2b 05 1a 6d 06 00 	sub    0x66d1a(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    6ef6:	48 c1 e2 10          	shl    $0x10,%rdx
    6efa:	48 39 d0             	cmp    %rdx,%rax
    6efd:	73 4f                	jae    6f4e <e161+0xae>
    6eff:	48 89 c2             	mov    %rax,%rdx
    6f02:	48 c1 ea 10          	shr    $0x10,%rdx
    6f06:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6f0a:	48 8b 15 47 6d 06 00 	mov    0x66d47(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    6f11:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6f15:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6f19:	48 85 d2             	test   %rdx,%rdx
    6f1c:	74 30                	je     6f4e <e161+0xae>
    6f1e:	0f b6 31             	movzbl (%rcx),%esi
    6f21:	40 80 fe 02          	cmp    $0x2,%sil
    6f25:	74 49                	je     6f70 <e161+0xd0>
    6f27:	40 80 fe 01          	cmp    $0x1,%sil
    6f2b:	75 21                	jne    6f4e <e161+0xae>
    6f2d:	8b 71 18             	mov    0x18(%rcx),%esi
    6f30:	0f b7 c0             	movzwl %ax,%eax
    6f33:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6f36:	48 0f af c6          	imul   %rsi,%rax
    6f3a:	48 c1 e8 20          	shr    $0x20,%rax
    6f3e:	48 39 c8             	cmp    %rcx,%rax
    6f41:	73 0b                	jae    6f4e <e161+0xae>
    6f43:	48 01 c2             	add    %rax,%rdx
    6f46:	80 3a ff             	cmpb   $0xff,(%rdx)
    6f49:	74 35                	je     6f80 <e161+0xe0>
    6f4b:	c6 02 01             	movb   $0x1,(%rdx)
    6f4e:	48 89 df             	mov    %rbx,%rdi
    6f51:	e8 ea fb ff ff       	call   6b40 <fwp_rc_share>
    6f56:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6f5b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6f62:	00 00 
    6f64:	75 33                	jne    6f99 <e161+0xf9>
    6f66:	48 83 c4 30          	add    $0x30,%rsp
    6f6a:	48 89 d8             	mov    %rbx,%rax
    6f6d:	5b                   	pop    %rbx
    6f6e:	c3                   	ret
    6f6f:	90                   	nop
    6f70:	66 85 c0             	test   %ax,%ax
    6f73:	75 d9                	jne    6f4e <e161+0xae>
    6f75:	eb cf                	jmp    6f46 <e161+0xa6>
    6f77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6f7e:	00 00 
    6f80:	48 89 d7             	mov    %rdx,%rdi
    6f83:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6f88:	e8 a3 e8 ff ff       	call   5830 <fwp_rc_forget_slot>
    6f8d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6f92:	eb b7                	jmp    6f4b <e161+0xab>
    6f94:	e8 67 c7 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6f99:	e8 b2 c4 ff ff       	call   3450 <__stack_chk_fail@plt>
    6f9e:	66 90                	xchg   %ax,%ax

0000000000006fa0 <fwp_drop0>:
    6fa0:	f3 0f 1e fa          	endbr64
    6fa4:	48 8b 15 8d 6c 06 00 	mov    0x66c8d(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    6fab:	48 89 f8             	mov    %rdi,%rax
    6fae:	48 2b 05 5b 6c 06 00 	sub    0x66c5b(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    6fb5:	48 c1 e2 10          	shl    $0x10,%rdx
    6fb9:	48 39 d0             	cmp    %rdx,%rax
    6fbc:	0f 83 be 00 00 00    	jae    7080 <fwp_drop0+0xe0>
    6fc2:	48 83 ec 18          	sub    $0x18,%rsp
    6fc6:	4c 8d 05 93 58 06 00 	lea    0x65893(%rip),%r8        # 6c860 <fwp_heap>
    6fcd:	48 89 c2             	mov    %rax,%rdx
    6fd0:	48 c1 ea 10          	shr    $0x10,%rdx
    6fd4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6fd8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6fdf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6fe3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6fe7:	48 85 d2             	test   %rdx,%rdx
    6fea:	74 3c                	je     7028 <fwp_drop0+0x88>
    6fec:	0f b6 31             	movzbl (%rcx),%esi
    6fef:	40 80 fe 02          	cmp    $0x2,%sil
    6ff3:	74 3b                	je     7030 <fwp_drop0+0x90>
    6ff5:	40 80 fe 01          	cmp    $0x1,%sil
    6ff9:	75 2d                	jne    7028 <fwp_drop0+0x88>
    6ffb:	8b 71 18             	mov    0x18(%rcx),%esi
    6ffe:	0f b7 c0             	movzwl %ax,%eax
    7001:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7004:	48 0f af c6          	imul   %rsi,%rax
    7008:	48 c1 e8 20          	shr    $0x20,%rax
    700c:	48 39 c8             	cmp    %rcx,%rax
    700f:	73 17                	jae    7028 <fwp_drop0+0x88>
    7011:	48 01 c2             	add    %rax,%rdx
    7014:	0f b6 02             	movzbl (%rdx),%eax
    7017:	84 c0                	test   %al,%al
    7019:	74 0d                	je     7028 <fwp_drop0+0x88>
    701b:	3c 01                	cmp    $0x1,%al
    701d:	74 21                	je     7040 <fwp_drop0+0xa0>
    701f:	3c ff                	cmp    $0xff,%al
    7021:	74 65                	je     7088 <fwp_drop0+0xe8>
    7023:	83 e8 01             	sub    $0x1,%eax
    7026:	88 02                	mov    %al,(%rdx)
    7028:	48 83 c4 18          	add    $0x18,%rsp
    702c:	c3                   	ret
    702d:	0f 1f 00             	nopl   (%rax)
    7030:	66 85 c0             	test   %ax,%ax
    7033:	74 df                	je     7014 <fwp_drop0+0x74>
    7035:	48 83 c4 18          	add    $0x18,%rsp
    7039:	c3                   	ret
    703a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7040:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    7044:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7049:	e8 22 fc ff ff       	call   6c70 <fwp_rc_free_arr>
    704e:	4c 8d 05 0b 58 06 00 	lea    0x6580b(%rip),%r8        # 6c860 <fwp_heap>
    7055:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    705a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7061:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7068:	48 c1 e2 10          	shl    $0x10,%rdx
    706c:	48 39 d0             	cmp    %rdx,%rax
    706f:	73 b7                	jae    7028 <fwp_drop0+0x88>
    7071:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7076:	e9 52 ff ff ff       	jmp    6fcd <fwp_drop0+0x2d>
    707b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7080:	c3                   	ret
    7081:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7088:	48 89 d0             	mov    %rdx,%rax
    708b:	48 c1 e8 11          	shr    $0x11,%rax
    708f:	48 31 d0             	xor    %rdx,%rax
    7092:	48 89 c1             	mov    %rax,%rcx
    7095:	48 c1 e9 09          	shr    $0x9,%rcx
    7099:	48 31 c8             	xor    %rcx,%rax
    709c:	0f b6 c8             	movzbl %al,%ecx
    709f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    70a6:	00 
    70a7:	48 85 c0             	test   %rax,%rax
    70aa:	75 1d                	jne    70c9 <fwp_drop0+0x129>
    70ac:	eb 56                	jmp    7104 <fwp_drop0+0x164>
    70ae:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    70b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    70bc:	00 00 00 00 
    70c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    70c4:	48 85 c0             	test   %rax,%rax
    70c7:	74 3b                	je     7104 <fwp_drop0+0x164>
    70c9:	48 89 c1             	mov    %rax,%rcx
    70cc:	48 39 10             	cmp    %rdx,(%rax)
    70cf:	75 ef                	jne    70c0 <fwp_drop0+0x120>
    70d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    70d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    70d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    70dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    70e4:	0f 85 3e ff ff ff    	jne    7028 <fwp_drop0+0x88>
    70ea:	48 89 d7             	mov    %rdx,%rdi
    70ed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    70f2:	e8 39 e7 ff ff       	call   5830 <fwp_rc_forget_slot>
    70f7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    70fc:	c6 02 fe             	movb   $0xfe,(%rdx)
    70ff:	e9 24 ff ff ff       	jmp    7028 <fwp_drop0+0x88>
    7104:	48 8d 3d d5 98 00 00 	lea    0x98d5(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    710b:	e8 40 d3 ff ff       	call   4450 <fwp_trap>

0000000000007110 <fwp_arg_drop12>:
    7110:	f3 0f 1e fa          	endbr64
    7114:	85 f6                	test   %esi,%esi
    7116:	75 04                	jne    711c <fwp_arg_drop12+0xc>
    7118:	85 d2                	test   %edx,%edx
    711a:	75 04                	jne    7120 <fwp_arg_drop12+0x10>
    711c:	c3                   	ret
    711d:	0f 1f 00             	nopl   (%rax)
    7120:	48 8b 3f             	mov    (%rdi),%rdi
    7123:	e9 78 fe ff ff       	jmp    6fa0 <fwp_drop0>
    7128:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    712f:	00 

0000000000007130 <fwp_drop1>:
    7130:	f3 0f 1e fa          	endbr64
    7134:	48 8b 15 fd 6a 06 00 	mov    0x66afd(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    713b:	48 89 f8             	mov    %rdi,%rax
    713e:	48 2b 05 cb 6a 06 00 	sub    0x66acb(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    7145:	48 c1 e2 10          	shl    $0x10,%rdx
    7149:	48 39 d0             	cmp    %rdx,%rax
    714c:	0f 83 be 00 00 00    	jae    7210 <fwp_drop1+0xe0>
    7152:	48 83 ec 18          	sub    $0x18,%rsp
    7156:	4c 8d 05 03 57 06 00 	lea    0x65703(%rip),%r8        # 6c860 <fwp_heap>
    715d:	48 89 c2             	mov    %rax,%rdx
    7160:	48 c1 ea 10          	shr    $0x10,%rdx
    7164:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7168:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    716f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7173:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7177:	48 85 d2             	test   %rdx,%rdx
    717a:	74 3c                	je     71b8 <fwp_drop1+0x88>
    717c:	0f b6 31             	movzbl (%rcx),%esi
    717f:	40 80 fe 02          	cmp    $0x2,%sil
    7183:	74 3b                	je     71c0 <fwp_drop1+0x90>
    7185:	40 80 fe 01          	cmp    $0x1,%sil
    7189:	75 2d                	jne    71b8 <fwp_drop1+0x88>
    718b:	8b 71 18             	mov    0x18(%rcx),%esi
    718e:	0f b7 c0             	movzwl %ax,%eax
    7191:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7194:	48 0f af c6          	imul   %rsi,%rax
    7198:	48 c1 e8 20          	shr    $0x20,%rax
    719c:	48 39 c8             	cmp    %rcx,%rax
    719f:	73 17                	jae    71b8 <fwp_drop1+0x88>
    71a1:	48 01 c2             	add    %rax,%rdx
    71a4:	0f b6 02             	movzbl (%rdx),%eax
    71a7:	84 c0                	test   %al,%al
    71a9:	74 0d                	je     71b8 <fwp_drop1+0x88>
    71ab:	3c 01                	cmp    $0x1,%al
    71ad:	74 21                	je     71d0 <fwp_drop1+0xa0>
    71af:	3c ff                	cmp    $0xff,%al
    71b1:	74 65                	je     7218 <fwp_drop1+0xe8>
    71b3:	83 e8 01             	sub    $0x1,%eax
    71b6:	88 02                	mov    %al,(%rdx)
    71b8:	48 83 c4 18          	add    $0x18,%rsp
    71bc:	c3                   	ret
    71bd:	0f 1f 00             	nopl   (%rax)
    71c0:	66 85 c0             	test   %ax,%ax
    71c3:	74 df                	je     71a4 <fwp_drop1+0x74>
    71c5:	48 83 c4 18          	add    $0x18,%rsp
    71c9:	c3                   	ret
    71ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    71d0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    71d4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    71d9:	e8 92 fa ff ff       	call   6c70 <fwp_rc_free_arr>
    71de:	4c 8d 05 7b 56 06 00 	lea    0x6567b(%rip),%r8        # 6c860 <fwp_heap>
    71e5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    71ea:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    71f1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    71f8:	48 c1 e2 10          	shl    $0x10,%rdx
    71fc:	48 39 d0             	cmp    %rdx,%rax
    71ff:	73 b7                	jae    71b8 <fwp_drop1+0x88>
    7201:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7206:	e9 52 ff ff ff       	jmp    715d <fwp_drop1+0x2d>
    720b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7210:	c3                   	ret
    7211:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7218:	48 89 d0             	mov    %rdx,%rax
    721b:	48 c1 e8 11          	shr    $0x11,%rax
    721f:	48 31 d0             	xor    %rdx,%rax
    7222:	48 89 c1             	mov    %rax,%rcx
    7225:	48 c1 e9 09          	shr    $0x9,%rcx
    7229:	48 31 c8             	xor    %rcx,%rax
    722c:	0f b6 c8             	movzbl %al,%ecx
    722f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7236:	00 
    7237:	48 85 c0             	test   %rax,%rax
    723a:	75 0d                	jne    7249 <fwp_drop1+0x119>
    723c:	eb 46                	jmp    7284 <fwp_drop1+0x154>
    723e:	66 90                	xchg   %ax,%ax
    7240:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7244:	48 85 c0             	test   %rax,%rax
    7247:	74 3b                	je     7284 <fwp_drop1+0x154>
    7249:	48 89 c1             	mov    %rax,%rcx
    724c:	48 39 10             	cmp    %rdx,(%rax)
    724f:	75 ef                	jne    7240 <fwp_drop1+0x110>
    7251:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7255:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7259:	48 89 48 08          	mov    %rcx,0x8(%rax)
    725d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7264:	0f 85 4e ff ff ff    	jne    71b8 <fwp_drop1+0x88>
    726a:	48 89 d7             	mov    %rdx,%rdi
    726d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7272:	e8 b9 e5 ff ff       	call   5830 <fwp_rc_forget_slot>
    7277:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    727c:	c6 02 fe             	movb   $0xfe,(%rdx)
    727f:	e9 34 ff ff ff       	jmp    71b8 <fwp_drop1+0x88>
    7284:	48 8d 3d 55 97 00 00 	lea    0x9755(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    728b:	e8 c0 d1 ff ff       	call   4450 <fwp_trap>

0000000000007290 <fwp_closure_drop>:
    7290:	48 8b 15 a1 69 06 00 	mov    0x669a1(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    7297:	48 89 f8             	mov    %rdi,%rax
    729a:	48 2b 05 6f 69 06 00 	sub    0x6696f(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    72a1:	48 c1 e2 10          	shl    $0x10,%rdx
    72a5:	48 39 d0             	cmp    %rdx,%rax
    72a8:	73 6b                	jae    7315 <fwp_closure_drop+0x85>
    72aa:	48 89 c2             	mov    %rax,%rdx
    72ad:	48 c1 ea 10          	shr    $0x10,%rdx
    72b1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    72b5:	48 8b 15 9c 69 06 00 	mov    0x6699c(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    72bc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    72c0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    72c4:	48 85 d2             	test   %rdx,%rdx
    72c7:	74 4c                	je     7315 <fwp_closure_drop+0x85>
    72c9:	0f b6 31             	movzbl (%rcx),%esi
    72cc:	40 80 fe 02          	cmp    $0x2,%sil
    72d0:	74 3e                	je     7310 <fwp_closure_drop+0x80>
    72d2:	40 80 fe 01          	cmp    $0x1,%sil
    72d6:	75 3d                	jne    7315 <fwp_closure_drop+0x85>
    72d8:	8b 71 18             	mov    0x18(%rcx),%esi
    72db:	0f b7 c0             	movzwl %ax,%eax
    72de:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    72e1:	48 0f af c6          	imul   %rsi,%rax
    72e5:	48 c1 e8 20          	shr    $0x20,%rax
    72e9:	48 39 c8             	cmp    %rcx,%rax
    72ec:	73 27                	jae    7315 <fwp_closure_drop+0x85>
    72ee:	48 01 c2             	add    %rax,%rdx
    72f1:	0f b6 02             	movzbl (%rdx),%eax
    72f4:	84 c0                	test   %al,%al
    72f6:	74 1d                	je     7315 <fwp_closure_drop+0x85>
    72f8:	3c 01                	cmp    $0x1,%al
    72fa:	74 24                	je     7320 <fwp_closure_drop+0x90>
    72fc:	3c ff                	cmp    $0xff,%al
    72fe:	74 48                	je     7348 <fwp_closure_drop+0xb8>
    7300:	83 e8 01             	sub    $0x1,%eax
    7303:	88 02                	mov    %al,(%rdx)
    7305:	c3                   	ret
    7306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    730d:	00 00 00 
    7310:	66 85 c0             	test   %ax,%ax
    7313:	74 dc                	je     72f1 <fwp_closure_drop+0x61>
    7315:	c3                   	ret
    7316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    731d:	00 00 00 
    7320:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    7327:	ff ff 
    7329:	48 85 c0             	test   %rax,%rax
    732c:	74 12                	je     7340 <fwp_closure_drop+0xb0>
    732e:	48 89 fe             	mov    %rdi,%rsi
    7331:	48 89 c7             	mov    %rax,%rdi
    7334:	e9 77 d1 ff ff       	jmp    44b0 <fwp_closure_drop_push>
    7339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7340:	e9 1b d3 ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    7345:	0f 1f 00             	nopl   (%rax)
    7348:	48 89 d0             	mov    %rdx,%rax
    734b:	48 8d 35 0e 55 06 00 	lea    0x6550e(%rip),%rsi        # 6c860 <fwp_heap>
    7352:	48 83 ec 18          	sub    $0x18,%rsp
    7356:	48 c1 e8 11          	shr    $0x11,%rax
    735a:	48 31 d0             	xor    %rdx,%rax
    735d:	48 89 c1             	mov    %rax,%rcx
    7360:	48 c1 e9 09          	shr    $0x9,%rcx
    7364:	48 31 c8             	xor    %rcx,%rax
    7367:	0f b6 c8             	movzbl %al,%ecx
    736a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7371:	00 
    7372:	48 85 c0             	test   %rax,%rax
    7375:	75 12                	jne    7389 <fwp_closure_drop+0xf9>
    7377:	eb 49                	jmp    73c2 <fwp_closure_drop+0x132>
    7379:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7380:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7384:	48 85 c0             	test   %rax,%rax
    7387:	74 39                	je     73c2 <fwp_closure_drop+0x132>
    7389:	48 89 c1             	mov    %rax,%rcx
    738c:	48 39 10             	cmp    %rdx,(%rax)
    738f:	75 ef                	jne    7380 <fwp_closure_drop+0xf0>
    7391:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7395:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7399:	48 89 48 08          	mov    %rcx,0x8(%rax)
    739d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    73a4:	74 05                	je     73ab <fwp_closure_drop+0x11b>
    73a6:	48 83 c4 18          	add    $0x18,%rsp
    73aa:	c3                   	ret
    73ab:	48 89 d7             	mov    %rdx,%rdi
    73ae:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    73b3:	e8 78 e4 ff ff       	call   5830 <fwp_rc_forget_slot>
    73b8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    73bd:	c6 02 fe             	movb   $0xfe,(%rdx)
    73c0:	eb e4                	jmp    73a6 <fwp_closure_drop+0x116>
    73c2:	48 8d 3d 17 96 00 00 	lea    0x9617(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    73c9:	e8 82 d0 ff ff       	call   4450 <fwp_trap>
    73ce:	66 90                	xchg   %ax,%ax

00000000000073d0 <fwp_owned_tape_release>:
    73d0:	48 85 ff             	test   %rdi,%rdi
    73d3:	0f 84 f7 00 00 00    	je     74d0 <fwp_owned_tape_release+0x100>
    73d9:	41 54                	push   %r12
    73db:	55                   	push   %rbp
    73dc:	53                   	push   %rbx
    73dd:	48 8b 07             	mov    (%rdi),%rax
    73e0:	48 85 c0             	test   %rax,%rax
    73e3:	74 08                	je     73ed <fwp_owned_tape_release+0x1d>
    73e5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    73e9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    73ed:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    73f1:	48 85 d2             	test   %rdx,%rdx
    73f4:	74 03                	je     73f9 <fwp_owned_tape_release+0x29>
    73f6:	48 89 02             	mov    %rax,(%rdx)
    73f9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    73fd:	48 89 fb             	mov    %rdi,%rbx
    7400:	48 8b 42 68          	mov    0x68(%rdx),%rax
    7404:	48 85 c0             	test   %rax,%rax
    7407:	0f 84 89 00 00 00    	je     7496 <fwp_owned_tape_release+0xc6>
    740d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    7411:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    7415:	7e 47                	jle    745e <fwp_owned_tape_release+0x8e>
    7417:	31 ed                	xor    %ebp,%ebp
    7419:	eb 0d                	jmp    7428 <fwp_owned_tape_release+0x58>
    741b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7420:	48 8b 43 10          	mov    0x10(%rbx),%rax
    7424:	48 8b 40 68          	mov    0x68(%rax),%rax
    7428:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    742c:	49 89 ec             	mov    %rbp,%r12
    742f:	48 83 c5 01          	add    $0x1,%rbp
    7433:	49 c1 e4 04          	shl    $0x4,%r12
    7437:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    743b:	ff d0                	call   *%rax
    743d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    7441:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    7446:	48 8b 43 10          	mov    0x10(%rbx),%rax
    744a:	ff 50 68             	call   *0x68(%rax)
    744d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    7451:	48 2b 43 50          	sub    0x50(%rbx),%rax
    7455:	48 39 e8             	cmp    %rbp,%rax
    7458:	7f c6                	jg     7420 <fwp_owned_tape_release+0x50>
    745a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    745e:	31 ed                	xor    %ebp,%ebp
    7460:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    7465:	7e 28                	jle    748f <fwp_owned_tape_release+0xbf>
    7467:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    746e:	00 00 
    7470:	48 8b 43 48          	mov    0x48(%rbx),%rax
    7474:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    7478:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    747c:	74 07                	je     7485 <fwp_owned_tape_release+0xb5>
    747e:	ff 52 68             	call   *0x68(%rdx)
    7481:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    7485:	48 83 c5 01          	add    $0x1,%rbp
    7489:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    748d:	7f e1                	jg     7470 <fwp_owned_tape_release+0xa0>
    748f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7493:	ff 52 68             	call   *0x68(%rdx)
    7496:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    749a:	e8 f1 fd ff ff       	call   7290 <fwp_closure_drop>
    749f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    74a3:	e8 e8 fd ff ff       	call   7290 <fwp_closure_drop>
    74a8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    74ac:	e8 df fd ff ff       	call   7290 <fwp_closure_drop>
    74b1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    74b5:	e8 b6 e5 ff ff       	call   5a70 <fwp_mem_free>
    74ba:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    74be:	e8 ad e5 ff ff       	call   5a70 <fwp_mem_free>
    74c3:	48 89 df             	mov    %rbx,%rdi
    74c6:	5b                   	pop    %rbx
    74c7:	5d                   	pop    %rbp
    74c8:	41 5c                	pop    %r12
    74ca:	e9 a1 e5 ff ff       	jmp    5a70 <fwp_mem_free>
    74cf:	90                   	nop
    74d0:	c3                   	ret
    74d1:	0f 1f 40 00          	nopl   0x0(%rax)
    74d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74dc:	00 00 00 00 

00000000000074e0 <fwp_tape_finish>:
    74e0:	f3 0f 1e fa          	endbr64
    74e4:	41 55                	push   %r13
    74e6:	41 54                	push   %r12
    74e8:	55                   	push   %rbp
    74e9:	53                   	push   %rbx
    74ea:	48 83 ec 48          	sub    $0x48,%rsp
    74ee:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    74f5:	00 00 
    74f7:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    74fc:	48 8d 3d dd cb 01 00 	lea    0x1cbdd(%rip),%rdi        # 240e0 <fwp_tape_workspace>
    7503:	e8 98 dc ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    7508:	48 83 3d 18 cc 01 00 	cmpq   $0x0,0x1cc18(%rip)        # 24128 <fwp_ntapes>
    750f:	00 
    7510:	48 c7 05 ad cb 01 00 	movq   $0x0,0x1cbad(%rip)        # 240c8 <fwp_tape_cached_bytes>
    7517:	00 00 00 00 
    751b:	7e 79                	jle    7596 <fwp_tape_finish+0xb6>
    751d:	45 31 e4             	xor    %r12d,%r12d
    7520:	31 ed                	xor    %ebp,%ebp
    7522:	0f 1f 00             	nopl   (%rax)
    7525:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    752c:	00 00 00 00 
    7530:	48 8b 1d f9 cb 01 00 	mov    0x1cbf9(%rip),%rbx        # 24130 <fwp_tapes>
    7537:	48 83 c5 01          	add    $0x1,%rbp
    753b:	4c 01 e3             	add    %r12,%rbx
    753e:	49 83 c4 68          	add    $0x68,%r12
    7542:	48 89 df             	mov    %rbx,%rdi
    7545:	e8 46 c7 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    754a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    754f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    7554:	48 89 e7             	mov    %rsp,%rdi
    7557:	48 8b 43 40          	mov    0x40(%rbx),%rax
    755b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    755f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    7564:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7569:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    756e:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    7572:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7577:	e8 24 dc ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    757c:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    7580:	e8 4b fe ff ff       	call   73d0 <fwp_owned_tape_release>
    7585:	48 39 2d 9c cb 01 00 	cmp    %rbp,0x1cb9c(%rip)        # 24128 <fwp_ntapes>
    758c:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    7593:	00 
    7594:	7f 9a                	jg     7530 <fwp_tape_finish+0x50>
    7596:	48 8b 3d 93 cb 01 00 	mov    0x1cb93(%rip),%rdi        # 24130 <fwp_tapes>
    759d:	48 85 ff             	test   %rdi,%rdi
    75a0:	74 05                	je     75a7 <fwp_tape_finish+0xc7>
    75a2:	e8 89 db ff ff       	call   5130 <ad_raw_free.part.0>
    75a7:	48 c7 05 7e cb 01 00 	movq   $0x0,0x1cb7e(%rip)        # 24130 <fwp_tapes>
    75ae:	00 00 00 00 
    75b2:	48 c7 05 63 cb 01 00 	movq   $0x0,0x1cb63(%rip)        # 24120 <fwp_tapes_cap>
    75b9:	00 00 00 00 
    75bd:	48 c7 05 60 cb 01 00 	movq   $0x0,0x1cb60(%rip)        # 24128 <fwp_ntapes>
    75c4:	00 00 00 00 
    75c8:	48 c7 05 45 cb 01 00 	movq   $0x0,0x1cb45(%rip)        # 24118 <fwp_tape_next_slot>
    75cf:	00 00 00 00 
    75d3:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    75d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    75df:	00 00 
    75e1:	75 0b                	jne    75ee <fwp_tape_finish+0x10e>
    75e3:	48 83 c4 48          	add    $0x48,%rsp
    75e7:	5b                   	pop    %rbx
    75e8:	5d                   	pop    %rbp
    75e9:	41 5c                	pop    %r12
    75eb:	41 5d                	pop    %r13
    75ed:	c3                   	ret
    75ee:	e8 5d be ff ff       	call   3450 <__stack_chk_fail@plt>
    75f3:	66 90                	xchg   %ax,%ax
    75f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    75fc:	00 00 00 00 

0000000000007600 <fwp_tape_scope_release>:
    7600:	f3 0f 1e fa          	endbr64
    7604:	41 55                	push   %r13
    7606:	41 54                	push   %r12
    7608:	55                   	push   %rbp
    7609:	53                   	push   %rbx
    760a:	48 83 ec 48          	sub    $0x48,%rsp
    760e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7615:	00 00 
    7617:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    761c:	48 63 07             	movslq (%rdi),%rax
    761f:	85 c0                	test   %eax,%eax
    7621:	0f 88 e8 00 00 00    	js     770f <fwp_tape_scope_release+0x10f>
    7627:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    762e:	ec c4 4e 
    7631:	48 89 fb             	mov    %rdi,%rbx
    7634:	48 89 e5             	mov    %rsp,%rbp
    7637:	eb 1f                	jmp    7658 <fwp_tape_scope_release+0x58>
    7639:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7640:	e8 5b db ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    7645:	4c 89 ef             	mov    %r13,%rdi
    7648:	e8 83 fd ff ff       	call   73d0 <fwp_owned_tape_release>
    764d:	48 63 03             	movslq (%rbx),%rax
    7650:	85 c0                	test   %eax,%eax
    7652:	0f 88 b7 00 00 00    	js     770f <fwp_tape_scope_release+0x10f>
    7658:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    765c:	48 8b 35 cd ca 01 00 	mov    0x1cacd(%rip),%rsi        # 24130 <fwp_tapes>
    7663:	4c 01 c6             	add    %r8,%rsi
    7666:	48 89 f7             	mov    %rsi,%rdi
    7669:	e8 22 c6 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    766e:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7673:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    7678:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    767f:	48 8b 46 40          	mov    0x40(%rsi),%rax
    7683:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    7687:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    768e:	00 
    768f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7694:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    7699:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    769d:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    76a2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    76a6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    76ab:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    76b2:	00 
    76b3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    76ba:	00 
    76bb:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    76c2:	00 
    76c3:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    76c7:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    76cb:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    76cf:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    76d3:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    76d9:	77 18                	ja     76f3 <fwp_tape_scope_release+0xf3>
    76db:	49 c1 f8 03          	sar    $0x3,%r8
    76df:	4d 0f af c4          	imul   %r12,%r8
    76e3:	4c 3b 05 2e ca 01 00 	cmp    0x1ca2e(%rip),%r8        # 24118 <fwp_tape_next_slot>
    76ea:	7d 07                	jge    76f3 <fwp_tape_scope_release+0xf3>
    76ec:	4c 89 05 25 ca 01 00 	mov    %r8,0x1ca25(%rip)        # 24118 <fwp_tape_next_slot>
    76f3:	48 89 ef             	mov    %rbp,%rdi
    76f6:	4d 85 ed             	test   %r13,%r13
    76f9:	0f 85 41 ff ff ff    	jne    7640 <fwp_tape_scope_release+0x40>
    76ff:	e8 bc db ff ff       	call   52c0 <fwp_tape_buffers_release>
    7704:	48 63 03             	movslq (%rbx),%rax
    7707:	85 c0                	test   %eax,%eax
    7709:	0f 89 49 ff ff ff    	jns    7658 <fwp_tape_scope_release+0x58>
    770f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7714:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    771b:	00 00 
    771d:	75 0b                	jne    772a <fwp_tape_scope_release+0x12a>
    771f:	48 83 c4 48          	add    $0x48,%rsp
    7723:	5b                   	pop    %rbx
    7724:	5d                   	pop    %rbp
    7725:	41 5c                	pop    %r12
    7727:	41 5d                	pop    %r13
    7729:	c3                   	ret
    772a:	e8 21 bd ff ff       	call   3450 <__stack_chk_fail@plt>
    772f:	90                   	nop

0000000000007730 <fwp_task_dispose>:
    7730:	53                   	push   %rbx
    7731:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7735:	0f 84 0b c0 ff ff    	je     3746 <fwp_task_dispose.cold>
    773b:	48 89 fb             	mov    %rdi,%rbx
    773e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7743:	0f 85 fd bf ff ff    	jne    3746 <fwp_task_dispose.cold>
    7749:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    774d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7754:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    775b:	00 
    775c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7760:	48 85 ff             	test   %rdi,%rdi
    7763:	74 07                	je     776c <fwp_task_dispose+0x3c>
    7765:	48 85 c0             	test   %rax,%rax
    7768:	74 02                	je     776c <fwp_task_dispose+0x3c>
    776a:	ff d0                	call   *%rax
    776c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7773:	e8 f8 e2 ff ff       	call   5a70 <fwp_mem_free>
    7778:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    777f:	00 00 00 00 
    7783:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7787:	74 6f                	je     77f8 <fwp_task_dispose+0xc8>
    7789:	48 8b 15 a8 64 06 00 	mov    0x664a8(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    7790:	48 89 d8             	mov    %rbx,%rax
    7793:	48 2b 05 76 64 06 00 	sub    0x66476(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    779a:	48 c1 e2 10          	shl    $0x10,%rdx
    779e:	48 39 d0             	cmp    %rdx,%rax
    77a1:	73 4c                	jae    77ef <fwp_task_dispose+0xbf>
    77a3:	48 89 c2             	mov    %rax,%rdx
    77a6:	48 c1 ea 10          	shr    $0x10,%rdx
    77aa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    77ae:	48 8b 15 a3 64 06 00 	mov    0x664a3(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    77b5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    77b9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    77bd:	48 85 c9             	test   %rcx,%rcx
    77c0:	74 2d                	je     77ef <fwp_task_dispose+0xbf>
    77c2:	0f b6 32             	movzbl (%rdx),%esi
    77c5:	40 80 fe 02          	cmp    $0x2,%sil
    77c9:	74 3d                	je     7808 <fwp_task_dispose+0xd8>
    77cb:	40 80 fe 01          	cmp    $0x1,%sil
    77cf:	75 1e                	jne    77ef <fwp_task_dispose+0xbf>
    77d1:	8b 72 18             	mov    0x18(%rdx),%esi
    77d4:	0f b7 c0             	movzwl %ax,%eax
    77d7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    77da:	48 0f af c6          	imul   %rsi,%rax
    77de:	48 c1 e8 20          	shr    $0x20,%rax
    77e2:	48 39 d0             	cmp    %rdx,%rax
    77e5:	73 08                	jae    77ef <fwp_task_dispose+0xbf>
    77e7:	48 01 c1             	add    %rax,%rcx
    77ea:	80 39 01             	cmpb   $0x1,(%rcx)
    77ed:	74 09                	je     77f8 <fwp_task_dispose+0xc8>
    77ef:	5b                   	pop    %rbx
    77f0:	c3                   	ret
    77f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    77f8:	48 89 df             	mov    %rbx,%rdi
    77fb:	5b                   	pop    %rbx
    77fc:	e9 6f e2 ff ff       	jmp    5a70 <fwp_mem_free>
    7801:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7808:	66 85 c0             	test   %ax,%ax
    780b:	74 dd                	je     77ea <fwp_task_dispose+0xba>
    780d:	5b                   	pop    %rbx
    780e:	c3                   	ret
    780f:	90                   	nop

0000000000007810 <fwp_free_zombie>:
    7810:	48 8b 15 19 50 06 00 	mov    0x65019(%rip),%rdx        # 6c830 <fwp_zombie>
    7817:	48 85 d2             	test   %rdx,%rdx
    781a:	0f 84 98 00 00 00    	je     78b8 <fwp_free_zombie+0xa8>
    7820:	48 3b 15 19 50 06 00 	cmp    0x65019(%rip),%rdx        # 6c840 <fwp_cur>
    7827:	0f 84 8b 00 00 00    	je     78b8 <fwp_free_zombie+0xa8>
    782d:	48 83 ec 18          	sub    $0x18,%rsp
    7831:	48 63 05 dc 49 06 00 	movslq 0x649dc(%rip),%rax        # 6c214 <fwp_stack_pool_n>
    7838:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    783c:	83 f8 3f             	cmp    $0x3f,%eax
    783f:	7f 7f                	jg     78c0 <fwp_free_zombie+0xb0>
    7841:	8d 48 01             	lea    0x1(%rax),%ecx
    7844:	89 0d ca 49 06 00    	mov    %ecx,0x649ca(%rip)        # 6c214 <fwp_stack_pool_n>
    784a:	48 8d 0d cf 49 06 00 	lea    0x649cf(%rip),%rcx        # 6c220 <fwp_stack_pool>
    7851:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7855:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    785c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7860:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7867:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    786b:	48 85 c9             	test   %rcx,%rcx
    786e:	0f 84 fc 00 00 00    	je     7970 <fwp_free_zombie+0x160>
    7874:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    787b:	48 85 c0             	test   %rax,%rax
    787e:	74 07                	je     7887 <fwp_free_zombie+0x77>
    7880:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7887:	8b 42 5c             	mov    0x5c(%rdx),%eax
    788a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    788e:	48 c7 05 97 4f 06 00 	movq   $0x0,0x64f97(%rip)        # 6c830 <fwp_zombie>
    7895:	00 00 00 00 
    7899:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    78a0:	85 c0                	test   %eax,%eax
    78a2:	74 34                	je     78d8 <fwp_free_zombie+0xc8>
    78a4:	83 f8 01             	cmp    $0x1,%eax
    78a7:	0f 84 b3 00 00 00    	je     7960 <fwp_free_zombie+0x150>
    78ad:	48 83 c4 18          	add    $0x18,%rsp
    78b1:	c3                   	ret
    78b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    78b8:	c3                   	ret
    78b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    78c0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    78c4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    78c9:	e8 f2 bc ff ff       	call   35c0 <munmap@plt>
    78ce:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    78d3:	eb 80                	jmp    7855 <fwp_free_zombie+0x45>
    78d5:	0f 1f 00             	nopl   (%rax)
    78d8:	48 8b 0d 59 63 06 00 	mov    0x66359(%rip),%rcx        # 6dc38 <fwp_heap+0x13d8>
    78df:	48 89 d0             	mov    %rdx,%rax
    78e2:	48 2b 05 27 63 06 00 	sub    0x66327(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    78e9:	48 c1 e1 10          	shl    $0x10,%rcx
    78ed:	48 39 c8             	cmp    %rcx,%rax
    78f0:	73 bb                	jae    78ad <fwp_free_zombie+0x9d>
    78f2:	48 89 c1             	mov    %rax,%rcx
    78f5:	48 c1 e9 10          	shr    $0x10,%rcx
    78f9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    78fd:	48 8b 0d 54 63 06 00 	mov    0x66354(%rip),%rcx        # 6dc58 <fwp_heap+0x13f8>
    7904:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7908:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    790c:	48 85 c9             	test   %rcx,%rcx
    790f:	74 9c                	je     78ad <fwp_free_zombie+0x9d>
    7911:	0f b6 3e             	movzbl (%rsi),%edi
    7914:	40 80 ff 02          	cmp    $0x2,%dil
    7918:	74 66                	je     7980 <fwp_free_zombie+0x170>
    791a:	40 80 ff 01          	cmp    $0x1,%dil
    791e:	75 8d                	jne    78ad <fwp_free_zombie+0x9d>
    7920:	8b 7e 18             	mov    0x18(%rsi),%edi
    7923:	0f b7 c0             	movzwl %ax,%eax
    7926:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7929:	48 0f af c7          	imul   %rdi,%rax
    792d:	48 c1 e8 20          	shr    $0x20,%rax
    7931:	48 39 f0             	cmp    %rsi,%rax
    7934:	0f 83 73 ff ff ff    	jae    78ad <fwp_free_zombie+0x9d>
    793a:	48 01 c1             	add    %rax,%rcx
    793d:	0f b6 01             	movzbl (%rcx),%eax
    7940:	84 c0                	test   %al,%al
    7942:	0f 84 65 ff ff ff    	je     78ad <fwp_free_zombie+0x9d>
    7948:	3c 01                	cmp    $0x1,%al
    794a:	74 14                	je     7960 <fwp_free_zombie+0x150>
    794c:	3c ff                	cmp    $0xff,%al
    794e:	74 3b                	je     798b <fwp_free_zombie+0x17b>
    7950:	83 e8 01             	sub    $0x1,%eax
    7953:	88 01                	mov    %al,(%rcx)
    7955:	e9 53 ff ff ff       	jmp    78ad <fwp_free_zombie+0x9d>
    795a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7960:	48 89 d7             	mov    %rdx,%rdi
    7963:	48 83 c4 18          	add    $0x18,%rsp
    7967:	e9 c4 fd ff ff       	jmp    7730 <fwp_task_dispose>
    796c:	0f 1f 40 00          	nopl   0x0(%rax)
    7970:	48 89 05 91 4e 06 00 	mov    %rax,0x64e91(%rip)        # 6c808 <fwp_tasks_active>
    7977:	e9 ff fe ff ff       	jmp    787b <fwp_free_zombie+0x6b>
    797c:	0f 1f 40 00          	nopl   0x0(%rax)
    7980:	66 85 c0             	test   %ax,%ax
    7983:	0f 85 24 ff ff ff    	jne    78ad <fwp_free_zombie+0x9d>
    7989:	eb b2                	jmp    793d <fwp_free_zombie+0x12d>
    798b:	48 89 ca             	mov    %rcx,%rdx
    798e:	48 8d 35 cb 4e 06 00 	lea    0x64ecb(%rip),%rsi        # 6c860 <fwp_heap>
    7995:	48 c1 ea 11          	shr    $0x11,%rdx
    7999:	48 31 ca             	xor    %rcx,%rdx
    799c:	48 89 d0             	mov    %rdx,%rax
    799f:	48 c1 e8 09          	shr    $0x9,%rax
    79a3:	48 31 c2             	xor    %rax,%rdx
    79a6:	0f b6 d2             	movzbl %dl,%edx
    79a9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    79b0:	00 
    79b1:	48 85 c0             	test   %rax,%rax
    79b4:	75 13                	jne    79c9 <fwp_free_zombie+0x1b9>
    79b6:	eb 4c                	jmp    7a04 <fwp_free_zombie+0x1f4>
    79b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    79bf:	00 
    79c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    79c4:	48 85 c0             	test   %rax,%rax
    79c7:	74 3b                	je     7a04 <fwp_free_zombie+0x1f4>
    79c9:	48 89 c2             	mov    %rax,%rdx
    79cc:	48 39 08             	cmp    %rcx,(%rax)
    79cf:	75 ef                	jne    79c0 <fwp_free_zombie+0x1b0>
    79d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    79d5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    79d9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    79dd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    79e4:	0f 85 c3 fe ff ff    	jne    78ad <fwp_free_zombie+0x9d>
    79ea:	48 89 cf             	mov    %rcx,%rdi
    79ed:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    79f2:	e8 39 de ff ff       	call   5830 <fwp_rc_forget_slot>
    79f7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    79fc:	c6 01 fe             	movb   $0xfe,(%rcx)
    79ff:	e9 a9 fe ff ff       	jmp    78ad <fwp_free_zombie+0x9d>
    7a04:	48 8d 3d d5 8f 00 00 	lea    0x8fd5(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    7a0b:	e8 40 ca ff ff       	call   4450 <fwp_trap>

0000000000007a10 <fwp_block>:
    7a10:	48 83 ec 08          	sub    $0x8,%rsp
    7a14:	48 8b 05 0d 4e 06 00 	mov    0x64e0d(%rip),%rax        # 6c828 <fwp_ready_head>
    7a1b:	48 85 c0             	test   %rax,%rax
    7a1e:	0f 84 1c 01 00 00    	je     7b40 <fwp_block+0x130>
    7a24:	90                   	nop
    7a25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7a2c:	00 00 00 00 
    7a30:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7a37:	48 89 15 ea 4d 06 00 	mov    %rdx,0x64dea(%rip)        # 6c828 <fwp_ready_head>
    7a3e:	48 85 d2             	test   %rdx,%rdx
    7a41:	0f 84 19 01 00 00    	je     7b60 <fwp_block+0x150>
    7a47:	48 8b 15 f2 4d 06 00 	mov    0x64df2(%rip),%rdx        # 6c840 <fwp_cur>
    7a4e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7a52:	48 39 c2             	cmp    %rax,%rdx
    7a55:	0f 84 d5 00 00 00    	je     7b30 <fwp_block+0x120>
    7a5b:	48 8b 0d 66 6a 06 00 	mov    0x66a66(%rip),%rcx        # 6e4c8 <fwp_state_owners>
    7a62:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7a66:	48 89 05 d3 4d 06 00 	mov    %rax,0x64dd3(%rip)        # 6c840 <fwp_cur>
    7a6d:	f3 0f 7e 05 7b 6a 06 	movq   0x66a7b(%rip),%xmm0        # 6e4f0 <fwp_foreign_callbacks>
    7a74:	00 
    7a75:	0f 16 05 64 6a 06 00 	movhps 0x66a64(%rip),%xmm0        # 6e4e0 <fwp_state>
    7a7c:	f3 0f 7e 0d 64 6a 06 	movq   0x66a64(%rip),%xmm1        # 6e4e8 <fwp_handlers>
    7a83:	00 
    7a84:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    7a8b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7a92:	0f 16 0d 5f 6a 06 00 	movhps 0x66a5f(%rip),%xmm1        # 6e4f8 <fwp_cleanups>
    7a99:	f3 0f 7e 05 37 6a 06 	movq   0x66a37(%rip),%xmm0        # 6e4d8 <fwp_state_len>
    7aa0:	00 
    7aa1:	0f 16 05 28 6a 06 00 	movhps 0x66a28(%rip),%xmm0        # 6e4d0 <fwp_state_cap>
    7aa8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    7aaf:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7ab6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7aba:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7ac1:	48 89 0d 20 6a 06 00 	mov    %rcx,0x66a20(%rip)        # 6e4e8 <fwp_handlers>
    7ac8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    7acf:	48 89 0d 22 6a 06 00 	mov    %rcx,0x66a22(%rip)        # 6e4f8 <fwp_cleanups>
    7ad6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    7add:	48 89 0d 0c 6a 06 00 	mov    %rcx,0x66a0c(%rip)        # 6e4f0 <fwp_foreign_callbacks>
    7ae4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    7aeb:	48 89 0d ee 69 06 00 	mov    %rcx,0x669ee(%rip)        # 6e4e0 <fwp_state>
    7af2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7af9:	48 89 0d d8 69 06 00 	mov    %rcx,0x669d8(%rip)        # 6e4d8 <fwp_state_len>
    7b00:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7b07:	48 89 0d c2 69 06 00 	mov    %rcx,0x669c2(%rip)        # 6e4d0 <fwp_state_cap>
    7b0e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7b15:	48 89 0d ac 69 06 00 	mov    %rcx,0x669ac(%rip)        # 6e4c8 <fwp_state_owners>
    7b1c:	e8 5f b9 ff ff       	call   3480 <swapcontext@plt>
    7b21:	f3 0f 1e fa          	endbr64
    7b25:	e8 e6 fc ff ff       	call   7810 <fwp_free_zombie>
    7b2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b30:	8b 05 da 46 06 00    	mov    0x646da(%rip),%eax        # 6c210 <fwp_slice>
    7b36:	85 c0                	test   %eax,%eax
    7b38:	74 36                	je     7b70 <fwp_block+0x160>
    7b3a:	48 83 c4 08          	add    $0x8,%rsp
    7b3e:	c3                   	ret
    7b3f:	90                   	nop
    7b40:	e8 2b d9 ff ff       	call   5470 <fwp_poll_events>
    7b45:	48 8b 05 dc 4c 06 00 	mov    0x64cdc(%rip),%rax        # 6c828 <fwp_ready_head>
    7b4c:	48 85 c0             	test   %rax,%rax
    7b4f:	0f 85 db fe ff ff    	jne    7a30 <fwp_block+0x20>
    7b55:	eb e9                	jmp    7b40 <fwp_block+0x130>
    7b57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7b5e:	00 00 
    7b60:	48 c7 05 b5 4c 06 00 	movq   $0x0,0x64cb5(%rip)        # 6c820 <fwp_ready_tail>
    7b67:	00 00 00 00 
    7b6b:	e9 d7 fe ff ff       	jmp    7a47 <fwp_block+0x37>
    7b70:	48 8d 3d 68 86 00 00 	lea    0x8668(%rip),%rdi        # 101df <_IO_stdin_used+0x1df>
    7b77:	e8 14 b8 ff ff       	call   3390 <getenv@plt>
    7b7c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7b81:	48 85 c0             	test   %rax,%rax
    7b84:	74 05                	je     7b8b <fwp_block+0x17b>
    7b86:	80 38 00             	cmpb   $0x0,(%rax)
    7b89:	75 0b                	jne    7b96 <fwp_block+0x186>
    7b8b:	89 15 7f 46 06 00    	mov    %edx,0x6467f(%rip)        # 6c210 <fwp_slice>
    7b91:	48 83 c4 08          	add    $0x8,%rsp
    7b95:	c3                   	ret
    7b96:	ba 0a 00 00 00       	mov    $0xa,%edx
    7b9b:	31 f6                	xor    %esi,%esi
    7b9d:	48 89 c7             	mov    %rax,%rdi
    7ba0:	e8 9b b9 ff ff       	call   3540 <strtoll@plt>
    7ba5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7ba9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7bb0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7bb5:	0f 46 d0             	cmovbe %eax,%edx
    7bb8:	eb d1                	jmp    7b8b <fwp_block+0x17b>
    7bba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007bc0 <fwp_drop4>:
    7bc0:	48 8b 15 71 60 06 00 	mov    0x66071(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    7bc7:	48 89 f8             	mov    %rdi,%rax
    7bca:	48 2b 05 3f 60 06 00 	sub    0x6603f(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    7bd1:	48 c1 e2 10          	shl    $0x10,%rdx
    7bd5:	48 39 d0             	cmp    %rdx,%rax
    7bd8:	0f 83 52 01 00 00    	jae    7d30 <fwp_drop4+0x170>
    7bde:	48 83 ec 18          	sub    $0x18,%rsp
    7be2:	4c 8d 05 77 4c 06 00 	lea    0x64c77(%rip),%r8        # 6c860 <fwp_heap>
    7be9:	48 89 c2             	mov    %rax,%rdx
    7bec:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7bf3:	48 c1 ea 10          	shr    $0x10,%rdx
    7bf7:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7bfb:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    7bff:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7c03:	48 85 d2             	test   %rdx,%rdx
    7c06:	74 46                	je     7c4e <fwp_drop4+0x8e>
    7c08:	44 0f b6 09          	movzbl (%rcx),%r9d
    7c0c:	41 80 f9 02          	cmp    $0x2,%r9b
    7c10:	0f 84 ca 00 00 00    	je     7ce0 <fwp_drop4+0x120>
    7c16:	41 80 f9 01          	cmp    $0x1,%r9b
    7c1a:	75 32                	jne    7c4e <fwp_drop4+0x8e>
    7c1c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7c20:	0f b7 c0             	movzwl %ax,%eax
    7c23:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7c26:	49 0f af c1          	imul   %r9,%rax
    7c2a:	48 c1 e8 20          	shr    $0x20,%rax
    7c2e:	48 39 c8             	cmp    %rcx,%rax
    7c31:	73 1b                	jae    7c4e <fwp_drop4+0x8e>
    7c33:	48 01 c2             	add    %rax,%rdx
    7c36:	0f b6 02             	movzbl (%rdx),%eax
    7c39:	84 c0                	test   %al,%al
    7c3b:	74 11                	je     7c4e <fwp_drop4+0x8e>
    7c3d:	3c 01                	cmp    $0x1,%al
    7c3f:	74 17                	je     7c58 <fwp_drop4+0x98>
    7c41:	3c ff                	cmp    $0xff,%al
    7c43:	0f 84 ef 00 00 00    	je     7d38 <fwp_drop4+0x178>
    7c49:	83 e8 01             	sub    $0x1,%eax
    7c4c:	88 02                	mov    %al,(%rdx)
    7c4e:	48 83 c4 18          	add    $0x18,%rsp
    7c52:	c3                   	ret
    7c53:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7c58:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    7c5c:	0f 88 8e 00 00 00    	js     7cf0 <fwp_drop4+0x130>
    7c62:	48 8b 15 cf 5f 06 00 	mov    0x65fcf(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    7c69:	48 89 f8             	mov    %rdi,%rax
    7c6c:	48 2b 05 9d 5f 06 00 	sub    0x65f9d(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    7c73:	48 c1 e2 10          	shl    $0x10,%rdx
    7c77:	48 39 d0             	cmp    %rdx,%rax
    7c7a:	73 d2                	jae    7c4e <fwp_drop4+0x8e>
    7c7c:	48 89 c2             	mov    %rax,%rdx
    7c7f:	48 c1 ea 10          	shr    $0x10,%rdx
    7c83:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7c87:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    7c8b:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7c8f:	48 85 c9             	test   %rcx,%rcx
    7c92:	74 ba                	je     7c4e <fwp_drop4+0x8e>
    7c94:	0f b6 32             	movzbl (%rdx),%esi
    7c97:	40 80 fe 02          	cmp    $0x2,%sil
    7c9b:	74 33                	je     7cd0 <fwp_drop4+0x110>
    7c9d:	40 80 fe 01          	cmp    $0x1,%sil
    7ca1:	75 ab                	jne    7c4e <fwp_drop4+0x8e>
    7ca3:	8b 72 18             	mov    0x18(%rdx),%esi
    7ca6:	0f b7 c0             	movzwl %ax,%eax
    7ca9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7cac:	48 0f af c6          	imul   %rsi,%rax
    7cb0:	48 c1 e8 20          	shr    $0x20,%rax
    7cb4:	48 39 d0             	cmp    %rdx,%rax
    7cb7:	73 95                	jae    7c4e <fwp_drop4+0x8e>
    7cb9:	48 01 c1             	add    %rax,%rcx
    7cbc:	80 39 01             	cmpb   $0x1,(%rcx)
    7cbf:	75 8d                	jne    7c4e <fwp_drop4+0x8e>
    7cc1:	48 83 c4 18          	add    $0x18,%rsp
    7cc5:	e9 a6 dd ff ff       	jmp    5a70 <fwp_mem_free>
    7cca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7cd0:	66 85 c0             	test   %ax,%ax
    7cd3:	74 e7                	je     7cbc <fwp_drop4+0xfc>
    7cd5:	48 83 c4 18          	add    $0x18,%rsp
    7cd9:	c3                   	ret
    7cda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ce0:	66 85 c0             	test   %ax,%ax
    7ce3:	0f 84 4d ff ff ff    	je     7c36 <fwp_drop4+0x76>
    7ce9:	48 83 c4 18          	add    $0x18,%rsp
    7ced:	c3                   	ret
    7cee:	66 90                	xchg   %ax,%ax
    7cf0:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7cf4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7cf9:	e8 72 ef ff ff       	call   6c70 <fwp_rc_free_arr>
    7cfe:	4c 8d 05 5b 4b 06 00 	lea    0x64b5b(%rip),%r8        # 6c860 <fwp_heap>
    7d05:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7d0a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7d11:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7d18:	48 c1 e2 10          	shl    $0x10,%rdx
    7d1c:	48 39 d0             	cmp    %rdx,%rax
    7d1f:	0f 83 29 ff ff ff    	jae    7c4e <fwp_drop4+0x8e>
    7d25:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7d2a:	e9 ba fe ff ff       	jmp    7be9 <fwp_drop4+0x29>
    7d2f:	90                   	nop
    7d30:	c3                   	ret
    7d31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7d38:	48 89 d0             	mov    %rdx,%rax
    7d3b:	48 c1 e8 11          	shr    $0x11,%rax
    7d3f:	48 31 d0             	xor    %rdx,%rax
    7d42:	48 89 c1             	mov    %rax,%rcx
    7d45:	48 c1 e9 09          	shr    $0x9,%rcx
    7d49:	48 31 c8             	xor    %rcx,%rax
    7d4c:	0f b6 c8             	movzbl %al,%ecx
    7d4f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7d56:	00 
    7d57:	48 85 c0             	test   %rax,%rax
    7d5a:	75 0d                	jne    7d69 <fwp_drop4+0x1a9>
    7d5c:	eb 46                	jmp    7da4 <fwp_drop4+0x1e4>
    7d5e:	66 90                	xchg   %ax,%ax
    7d60:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7d64:	48 85 c0             	test   %rax,%rax
    7d67:	74 3b                	je     7da4 <fwp_drop4+0x1e4>
    7d69:	48 89 c1             	mov    %rax,%rcx
    7d6c:	48 39 10             	cmp    %rdx,(%rax)
    7d6f:	75 ef                	jne    7d60 <fwp_drop4+0x1a0>
    7d71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7d75:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7d79:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7d7d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7d84:	0f 85 c4 fe ff ff    	jne    7c4e <fwp_drop4+0x8e>
    7d8a:	48 89 d7             	mov    %rdx,%rdi
    7d8d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7d92:	e8 99 da ff ff       	call   5830 <fwp_rc_forget_slot>
    7d97:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7d9c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7d9f:	e9 aa fe ff ff       	jmp    7c4e <fwp_drop4+0x8e>
    7da4:	48 8d 3d 35 8c 00 00 	lea    0x8c35(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    7dab:	e8 a0 c6 ff ff       	call   4450 <fwp_trap>

0000000000007db0 <fwp_caps161>:
    7db0:	f3 0f 1e fa          	endbr64
    7db4:	85 f6                	test   %esi,%esi
    7db6:	74 08                	je     7dc0 <fwp_caps161+0x10>
    7db8:	c3                   	ret
    7db9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7dc0:	48 8b 15 71 5e 06 00 	mov    0x65e71(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    7dc7:	48 89 f8             	mov    %rdi,%rax
    7dca:	48 2b 05 3f 5e 06 00 	sub    0x65e3f(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    7dd1:	48 c1 e2 10          	shl    $0x10,%rdx
    7dd5:	48 39 d0             	cmp    %rdx,%rax
    7dd8:	73 de                	jae    7db8 <fwp_caps161+0x8>
    7dda:	48 89 c2             	mov    %rax,%rdx
    7ddd:	48 c1 ea 10          	shr    $0x10,%rdx
    7de1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7de5:	48 8b 15 6c 5e 06 00 	mov    0x65e6c(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    7dec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7df0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7df4:	48 85 c9             	test   %rcx,%rcx
    7df7:	74 bf                	je     7db8 <fwp_caps161+0x8>
    7df9:	0f b6 32             	movzbl (%rdx),%esi
    7dfc:	40 80 fe 02          	cmp    $0x2,%sil
    7e00:	74 2e                	je     7e30 <fwp_caps161+0x80>
    7e02:	40 80 fe 01          	cmp    $0x1,%sil
    7e06:	75 b0                	jne    7db8 <fwp_caps161+0x8>
    7e08:	8b 72 18             	mov    0x18(%rdx),%esi
    7e0b:	0f b7 c0             	movzwl %ax,%eax
    7e0e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e11:	48 0f af c6          	imul   %rsi,%rax
    7e15:	48 c1 e8 20          	shr    $0x20,%rax
    7e19:	48 39 d0             	cmp    %rdx,%rax
    7e1c:	73 9a                	jae    7db8 <fwp_caps161+0x8>
    7e1e:	48 01 c1             	add    %rax,%rcx
    7e21:	80 39 01             	cmpb   $0x1,(%rcx)
    7e24:	75 92                	jne    7db8 <fwp_caps161+0x8>
    7e26:	e9 45 dc ff ff       	jmp    5a70 <fwp_mem_free>
    7e2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7e30:	66 85 c0             	test   %ax,%ax
    7e33:	74 ec                	je     7e21 <fwp_caps161+0x71>
    7e35:	c3                   	ret
    7e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7e3d:	00 00 00 

0000000000007e40 <fwp_drop2>:
    7e40:	48 8b 0d f1 5d 06 00 	mov    0x65df1(%rip),%rcx        # 6dc38 <fwp_heap+0x13d8>
    7e47:	48 89 f8             	mov    %rdi,%rax
    7e4a:	48 2b 05 bf 5d 06 00 	sub    0x65dbf(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    7e51:	48 c1 e1 10          	shl    $0x10,%rcx
    7e55:	48 39 c8             	cmp    %rcx,%rax
    7e58:	0f 83 42 01 00 00    	jae    7fa0 <fwp_drop2+0x160>
    7e5e:	48 83 ec 18          	sub    $0x18,%rsp
    7e62:	48 89 fa             	mov    %rdi,%rdx
    7e65:	4c 8d 05 f4 49 06 00 	lea    0x649f4(%rip),%r8        # 6c860 <fwp_heap>
    7e6c:	48 89 c1             	mov    %rax,%rcx
    7e6f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7e76:	48 c1 e9 10          	shr    $0x10,%rcx
    7e7a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7e7e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7e82:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7e86:	48 85 c9             	test   %rcx,%rcx
    7e89:	74 40                	je     7ecb <fwp_drop2+0x8b>
    7e8b:	0f b6 3e             	movzbl (%rsi),%edi
    7e8e:	40 80 ff 02          	cmp    $0x2,%dil
    7e92:	74 3c                	je     7ed0 <fwp_drop2+0x90>
    7e94:	40 80 ff 01          	cmp    $0x1,%dil
    7e98:	75 31                	jne    7ecb <fwp_drop2+0x8b>
    7e9a:	8b 7e 18             	mov    0x18(%rsi),%edi
    7e9d:	0f b7 c0             	movzwl %ax,%eax
    7ea0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7ea3:	48 0f af c7          	imul   %rdi,%rax
    7ea7:	48 c1 e8 20          	shr    $0x20,%rax
    7eab:	48 39 f0             	cmp    %rsi,%rax
    7eae:	73 1b                	jae    7ecb <fwp_drop2+0x8b>
    7eb0:	48 01 c1             	add    %rax,%rcx
    7eb3:	0f b6 01             	movzbl (%rcx),%eax
    7eb6:	84 c0                	test   %al,%al
    7eb8:	74 11                	je     7ecb <fwp_drop2+0x8b>
    7eba:	3c 01                	cmp    $0x1,%al
    7ebc:	74 22                	je     7ee0 <fwp_drop2+0xa0>
    7ebe:	3c ff                	cmp    $0xff,%al
    7ec0:	0f 84 0a 01 00 00    	je     7fd0 <fwp_drop2+0x190>
    7ec6:	83 e8 01             	sub    $0x1,%eax
    7ec9:	88 01                	mov    %al,(%rcx)
    7ecb:	48 83 c4 18          	add    $0x18,%rsp
    7ecf:	c3                   	ret
    7ed0:	66 85 c0             	test   %ax,%ax
    7ed3:	74 de                	je     7eb3 <fwp_drop2+0x73>
    7ed5:	48 83 c4 18          	add    $0x18,%rsp
    7ed9:	c3                   	ret
    7eda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ee0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7ee4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    7eeb:	48 89 f8             	mov    %rdi,%rax
    7eee:	48 c1 e1 10          	shl    $0x10,%rcx
    7ef2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7ef9:	48 39 c8             	cmp    %rcx,%rax
    7efc:	73 62                	jae    7f60 <fwp_drop2+0x120>
    7efe:	48 89 c1             	mov    %rax,%rcx
    7f01:	48 c1 e9 10          	shr    $0x10,%rcx
    7f05:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7f09:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7f0d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7f11:	48 85 c9             	test   %rcx,%rcx
    7f14:	74 4a                	je     7f60 <fwp_drop2+0x120>
    7f16:	44 0f b6 0e          	movzbl (%rsi),%r9d
    7f1a:	41 80 f9 02          	cmp    $0x2,%r9b
    7f1e:	0f 84 9c 00 00 00    	je     7fc0 <fwp_drop2+0x180>
    7f24:	41 80 f9 01          	cmp    $0x1,%r9b
    7f28:	75 36                	jne    7f60 <fwp_drop2+0x120>
    7f2a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    7f2e:	0f b7 c0             	movzwl %ax,%eax
    7f31:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7f34:	49 0f af c1          	imul   %r9,%rax
    7f38:	48 c1 e8 20          	shr    $0x20,%rax
    7f3c:	48 39 f0             	cmp    %rsi,%rax
    7f3f:	73 1f                	jae    7f60 <fwp_drop2+0x120>
    7f41:	48 01 c1             	add    %rax,%rcx
    7f44:	0f b6 01             	movzbl (%rcx),%eax
    7f47:	84 c0                	test   %al,%al
    7f49:	74 15                	je     7f60 <fwp_drop2+0x120>
    7f4b:	3c 01                	cmp    $0x1,%al
    7f4d:	74 59                	je     7fa8 <fwp_drop2+0x168>
    7f4f:	3c ff                	cmp    $0xff,%al
    7f51:	0f 84 ef 00 00 00    	je     8046 <fwp_drop2+0x206>
    7f57:	83 e8 01             	sub    $0x1,%eax
    7f5a:	88 01                	mov    %al,(%rcx)
    7f5c:	0f 1f 40 00          	nopl   0x0(%rax)
    7f60:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7f64:	48 89 d7             	mov    %rdx,%rdi
    7f67:	48 89 0c 24          	mov    %rcx,(%rsp)
    7f6b:	e8 00 ed ff ff       	call   6c70 <fwp_rc_free_arr>
    7f70:	4c 8d 05 e9 48 06 00 	lea    0x648e9(%rip),%r8        # 6c860 <fwp_heap>
    7f77:	48 8b 04 24          	mov    (%rsp),%rax
    7f7b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7f82:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7f89:	48 c1 e2 10          	shl    $0x10,%rdx
    7f8d:	48 39 d0             	cmp    %rdx,%rax
    7f90:	0f 83 35 ff ff ff    	jae    7ecb <fwp_drop2+0x8b>
    7f96:	48 8b 14 24          	mov    (%rsp),%rdx
    7f9a:	e9 cd fe ff ff       	jmp    7e6c <fwp_drop2+0x2c>
    7f9f:	90                   	nop
    7fa0:	c3                   	ret
    7fa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7fa8:	48 89 14 24          	mov    %rdx,(%rsp)
    7fac:	e8 bf ec ff ff       	call   6c70 <fwp_rc_free_arr>
    7fb1:	48 8b 14 24          	mov    (%rsp),%rdx
    7fb5:	eb a9                	jmp    7f60 <fwp_drop2+0x120>
    7fb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7fbe:	00 00 
    7fc0:	66 85 c0             	test   %ax,%ax
    7fc3:	75 9b                	jne    7f60 <fwp_drop2+0x120>
    7fc5:	e9 7a ff ff ff       	jmp    7f44 <fwp_drop2+0x104>
    7fca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7fd0:	48 89 c8             	mov    %rcx,%rax
    7fd3:	48 c1 e8 11          	shr    $0x11,%rax
    7fd7:	48 31 c8             	xor    %rcx,%rax
    7fda:	48 89 c2             	mov    %rax,%rdx
    7fdd:	48 c1 ea 09          	shr    $0x9,%rdx
    7fe1:	48 31 d0             	xor    %rdx,%rax
    7fe4:	0f b6 d0             	movzbl %al,%edx
    7fe7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    7fee:	00 
    7fef:	48 85 c0             	test   %rax,%rax
    7ff2:	75 19                	jne    800d <fwp_drop2+0x1cd>
    7ff4:	e9 d3 00 00 00       	jmp    80cc <fwp_drop2+0x28c>
    7ff9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8000:	48 8b 42 10          	mov    0x10(%rdx),%rax
    8004:	48 85 c0             	test   %rax,%rax
    8007:	0f 84 bf 00 00 00    	je     80cc <fwp_drop2+0x28c>
    800d:	48 89 c2             	mov    %rax,%rdx
    8010:	48 39 08             	cmp    %rcx,(%rax)
    8013:	75 eb                	jne    8000 <fwp_drop2+0x1c0>
    8015:	48 8b 50 08          	mov    0x8(%rax),%rdx
    8019:	48 83 ea 01          	sub    $0x1,%rdx
    801d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    8021:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    8028:	0f 85 9d fe ff ff    	jne    7ecb <fwp_drop2+0x8b>
    802e:	48 89 cf             	mov    %rcx,%rdi
    8031:	48 89 0c 24          	mov    %rcx,(%rsp)
    8035:	e8 f6 d7 ff ff       	call   5830 <fwp_rc_forget_slot>
    803a:	48 8b 0c 24          	mov    (%rsp),%rcx
    803e:	c6 01 fe             	movb   $0xfe,(%rcx)
    8041:	e9 85 fe ff ff       	jmp    7ecb <fwp_drop2+0x8b>
    8046:	48 89 ce             	mov    %rcx,%rsi
    8049:	48 c1 ee 11          	shr    $0x11,%rsi
    804d:	48 31 ce             	xor    %rcx,%rsi
    8050:	48 89 f0             	mov    %rsi,%rax
    8053:	48 c1 e8 09          	shr    $0x9,%rax
    8057:	48 31 c6             	xor    %rax,%rsi
    805a:	40 0f b6 f6          	movzbl %sil,%esi
    805e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    8065:	00 
    8066:	48 85 c0             	test   %rax,%rax
    8069:	75 1e                	jne    8089 <fwp_drop2+0x249>
    806b:	eb 5f                	jmp    80cc <fwp_drop2+0x28c>
    806d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8074:	00 
    8075:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    807c:	00 00 00 00 
    8080:	48 8b 46 10          	mov    0x10(%rsi),%rax
    8084:	48 85 c0             	test   %rax,%rax
    8087:	74 43                	je     80cc <fwp_drop2+0x28c>
    8089:	48 89 c6             	mov    %rax,%rsi
    808c:	48 39 08             	cmp    %rcx,(%rax)
    808f:	75 ef                	jne    8080 <fwp_drop2+0x240>
    8091:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8095:	48 83 ee 01          	sub    $0x1,%rsi
    8099:	48 89 70 08          	mov    %rsi,0x8(%rax)
    809d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    80a4:	0f 85 b6 fe ff ff    	jne    7f60 <fwp_drop2+0x120>
    80aa:	48 89 cf             	mov    %rcx,%rdi
    80ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    80b2:	48 89 0c 24          	mov    %rcx,(%rsp)
    80b6:	e8 75 d7 ff ff       	call   5830 <fwp_rc_forget_slot>
    80bb:	48 8b 0c 24          	mov    (%rsp),%rcx
    80bf:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    80c4:	c6 01 fe             	movb   $0xfe,(%rcx)
    80c7:	e9 94 fe ff ff       	jmp    7f60 <fwp_drop2+0x120>
    80cc:	48 8d 3d 0d 89 00 00 	lea    0x890d(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    80d3:	e8 78 c3 ff ff       	call   4450 <fwp_trap>
    80d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    80df:	00 

00000000000080e0 <fwp_arg_drop23>:
    80e0:	f3 0f 1e fa          	endbr64
    80e4:	85 f6                	test   %esi,%esi
    80e6:	75 04                	jne    80ec <fwp_arg_drop23+0xc>
    80e8:	85 d2                	test   %edx,%edx
    80ea:	75 04                	jne    80f0 <fwp_arg_drop23+0x10>
    80ec:	c3                   	ret
    80ed:	0f 1f 00             	nopl   (%rax)
    80f0:	48 8b 3f             	mov    (%rdi),%rdi
    80f3:	e9 48 fd ff ff       	jmp    7e40 <fwp_drop2>
    80f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    80ff:	00 

0000000000008100 <fwp_args12>:
    8100:	f3 0f 1e fa          	endbr64
    8104:	85 d2                	test   %edx,%edx
    8106:	74 04                	je     810c <fwp_args12+0xc>
    8108:	85 f6                	test   %esi,%esi
    810a:	74 04                	je     8110 <fwp_args12+0x10>
    810c:	c3                   	ret
    810d:	0f 1f 00             	nopl   (%rax)
    8110:	48 8b 15 21 5b 06 00 	mov    0x65b21(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    8117:	48 8b 07             	mov    (%rdi),%rax
    811a:	48 2b 05 ef 5a 06 00 	sub    0x65aef(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    8121:	48 c1 e2 10          	shl    $0x10,%rdx
    8125:	48 39 d0             	cmp    %rdx,%rax
    8128:	73 e2                	jae    810c <fwp_args12+0xc>
    812a:	48 89 c2             	mov    %rax,%rdx
    812d:	48 c1 ea 10          	shr    $0x10,%rdx
    8131:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8135:	48 8b 15 1c 5b 06 00 	mov    0x65b1c(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    813c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8140:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8144:	48 85 ff             	test   %rdi,%rdi
    8147:	74 c3                	je     810c <fwp_args12+0xc>
    8149:	0f b6 0a             	movzbl (%rdx),%ecx
    814c:	80 f9 02             	cmp    $0x2,%cl
    814f:	74 4f                	je     81a0 <fwp_args12+0xa0>
    8151:	80 f9 01             	cmp    $0x1,%cl
    8154:	75 b6                	jne    810c <fwp_args12+0xc>
    8156:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8159:	0f b7 c0             	movzwl %ax,%eax
    815c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    815f:	48 0f af c1          	imul   %rcx,%rax
    8163:	48 c1 e8 20          	shr    $0x20,%rax
    8167:	48 39 d0             	cmp    %rdx,%rax
    816a:	73 a0                	jae    810c <fwp_args12+0xc>
    816c:	48 01 c7             	add    %rax,%rdi
    816f:	0f b6 07             	movzbl (%rdi),%eax
    8172:	84 c0                	test   %al,%al
    8174:	74 96                	je     810c <fwp_args12+0xc>
    8176:	8b 15 ac 63 06 00    	mov    0x663ac(%rip),%edx        # 6e528 <iteration_active>
    817c:	85 d2                	test   %edx,%edx
    817e:	75 10                	jne    8190 <fwp_args12+0x90>
    8180:	3c fd                	cmp    $0xfd,%al
    8182:	77 22                	ja     81a6 <fwp_args12+0xa6>
    8184:	83 c0 01             	add    $0x1,%eax
    8187:	88 07                	mov    %al,(%rdi)
    8189:	c3                   	ret
    818a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8190:	48 83 05 78 63 06 00 	addq   $0x1,0x66378(%rip)        # 6e510 <iteration_retains>
    8197:	01 
    8198:	eb e6                	jmp    8180 <fwp_args12+0x80>
    819a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    81a0:	66 85 c0             	test   %ax,%ax
    81a3:	74 ca                	je     816f <fwp_args12+0x6f>
    81a5:	c3                   	ret
    81a6:	e9 65 d5 ff ff       	jmp    5710 <fwp_rc_wide_dup>
    81ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000081b0 <fwp_args23>:
    81b0:	f3 0f 1e fa          	endbr64
    81b4:	85 d2                	test   %edx,%edx
    81b6:	74 04                	je     81bc <fwp_args23+0xc>
    81b8:	85 f6                	test   %esi,%esi
    81ba:	74 04                	je     81c0 <fwp_args23+0x10>
    81bc:	c3                   	ret
    81bd:	0f 1f 00             	nopl   (%rax)
    81c0:	48 8b 15 71 5a 06 00 	mov    0x65a71(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    81c7:	48 8b 07             	mov    (%rdi),%rax
    81ca:	48 2b 05 3f 5a 06 00 	sub    0x65a3f(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    81d1:	48 c1 e2 10          	shl    $0x10,%rdx
    81d5:	48 39 d0             	cmp    %rdx,%rax
    81d8:	73 e2                	jae    81bc <fwp_args23+0xc>
    81da:	48 89 c2             	mov    %rax,%rdx
    81dd:	48 c1 ea 10          	shr    $0x10,%rdx
    81e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    81e5:	48 8b 15 6c 5a 06 00 	mov    0x65a6c(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    81ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    81f0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    81f4:	48 85 ff             	test   %rdi,%rdi
    81f7:	74 c3                	je     81bc <fwp_args23+0xc>
    81f9:	0f b6 0a             	movzbl (%rdx),%ecx
    81fc:	80 f9 02             	cmp    $0x2,%cl
    81ff:	74 4f                	je     8250 <fwp_args23+0xa0>
    8201:	80 f9 01             	cmp    $0x1,%cl
    8204:	75 b6                	jne    81bc <fwp_args23+0xc>
    8206:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8209:	0f b7 c0             	movzwl %ax,%eax
    820c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    820f:	48 0f af c1          	imul   %rcx,%rax
    8213:	48 c1 e8 20          	shr    $0x20,%rax
    8217:	48 39 d0             	cmp    %rdx,%rax
    821a:	73 a0                	jae    81bc <fwp_args23+0xc>
    821c:	48 01 c7             	add    %rax,%rdi
    821f:	0f b6 07             	movzbl (%rdi),%eax
    8222:	84 c0                	test   %al,%al
    8224:	74 96                	je     81bc <fwp_args23+0xc>
    8226:	8b 15 fc 62 06 00    	mov    0x662fc(%rip),%edx        # 6e528 <iteration_active>
    822c:	85 d2                	test   %edx,%edx
    822e:	75 10                	jne    8240 <fwp_args23+0x90>
    8230:	3c fd                	cmp    $0xfd,%al
    8232:	77 22                	ja     8256 <fwp_args23+0xa6>
    8234:	83 c0 01             	add    $0x1,%eax
    8237:	88 07                	mov    %al,(%rdi)
    8239:	c3                   	ret
    823a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8240:	48 83 05 c8 62 06 00 	addq   $0x1,0x662c8(%rip)        # 6e510 <iteration_retains>
    8247:	01 
    8248:	eb e6                	jmp    8230 <fwp_args23+0x80>
    824a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8250:	66 85 c0             	test   %ax,%ax
    8253:	74 ca                	je     821f <fwp_args23+0x6f>
    8255:	c3                   	ret
    8256:	e9 b5 d4 ff ff       	jmp    5710 <fwp_rc_wide_dup>
    825b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000008260 <fwp_caps12>:
    8260:	f3 0f 1e fa          	endbr64
    8264:	48 83 ec 18          	sub    $0x18,%rsp
    8268:	48 89 f8             	mov    %rdi,%rax
    826b:	8b 7f 04             	mov    0x4(%rdi),%edi
    826e:	85 ff                	test   %edi,%edi
    8270:	0f 84 9a 00 00 00    	je     8310 <fwp_caps12+0xb0>
    8276:	48 8b 78 08          	mov    0x8(%rax),%rdi
    827a:	85 f6                	test   %esi,%esi
    827c:	0f 85 9e 00 00 00    	jne    8320 <fwp_caps12+0xc0>
    8282:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8287:	e8 14 ed ff ff       	call   6fa0 <fwp_drop0>
    828c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8291:	48 8b 0d a0 59 06 00 	mov    0x659a0(%rip),%rcx        # 6dc38 <fwp_heap+0x13d8>
    8298:	48 89 c2             	mov    %rax,%rdx
    829b:	48 2b 15 6e 59 06 00 	sub    0x6596e(%rip),%rdx        # 6dc10 <fwp_heap+0x13b0>
    82a2:	48 c1 e1 10          	shl    $0x10,%rcx
    82a6:	48 39 ca             	cmp    %rcx,%rdx
    82a9:	73 6d                	jae    8318 <fwp_caps12+0xb8>
    82ab:	48 89 d1             	mov    %rdx,%rcx
    82ae:	48 c1 e9 10          	shr    $0x10,%rcx
    82b2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    82b6:	48 8b 0d 9b 59 06 00 	mov    0x6599b(%rip),%rcx        # 6dc58 <fwp_heap+0x13f8>
    82bd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    82c1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    82c5:	48 85 f6             	test   %rsi,%rsi
    82c8:	74 4e                	je     8318 <fwp_caps12+0xb8>
    82ca:	0f b6 39             	movzbl (%rcx),%edi
    82cd:	40 80 ff 02          	cmp    $0x2,%dil
    82d1:	0f 84 c9 00 00 00    	je     83a0 <fwp_caps12+0x140>
    82d7:	40 80 ff 01          	cmp    $0x1,%dil
    82db:	75 3b                	jne    8318 <fwp_caps12+0xb8>
    82dd:	8b 79 18             	mov    0x18(%rcx),%edi
    82e0:	0f b7 d2             	movzwl %dx,%edx
    82e3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    82e6:	48 0f af d7          	imul   %rdi,%rdx
    82ea:	48 c1 ea 20          	shr    $0x20,%rdx
    82ee:	48 39 ca             	cmp    %rcx,%rdx
    82f1:	73 25                	jae    8318 <fwp_caps12+0xb8>
    82f3:	48 01 d6             	add    %rdx,%rsi
    82f6:	80 3e 01             	cmpb   $0x1,(%rsi)
    82f9:	75 1d                	jne    8318 <fwp_caps12+0xb8>
    82fb:	48 89 c7             	mov    %rax,%rdi
    82fe:	48 83 c4 18          	add    $0x18,%rsp
    8302:	e9 69 d7 ff ff       	jmp    5a70 <fwp_mem_free>
    8307:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    830e:	00 00 
    8310:	85 f6                	test   %esi,%esi
    8312:	0f 84 79 ff ff ff    	je     8291 <fwp_caps12+0x31>
    8318:	48 83 c4 18          	add    $0x18,%rsp
    831c:	c3                   	ret
    831d:	0f 1f 00             	nopl   (%rax)
    8320:	48 8b 05 11 59 06 00 	mov    0x65911(%rip),%rax        # 6dc38 <fwp_heap+0x13d8>
    8327:	48 2b 3d e2 58 06 00 	sub    0x658e2(%rip),%rdi        # 6dc10 <fwp_heap+0x13b0>
    832e:	48 c1 e0 10          	shl    $0x10,%rax
    8332:	48 39 c7             	cmp    %rax,%rdi
    8335:	73 e1                	jae    8318 <fwp_caps12+0xb8>
    8337:	48 89 f8             	mov    %rdi,%rax
    833a:	48 c1 e8 10          	shr    $0x10,%rax
    833e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8342:	48 8b 05 0f 59 06 00 	mov    0x6590f(%rip),%rax        # 6dc58 <fwp_heap+0x13f8>
    8349:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    834d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    8351:	48 85 c0             	test   %rax,%rax
    8354:	74 c2                	je     8318 <fwp_caps12+0xb8>
    8356:	0f b6 0a             	movzbl (%rdx),%ecx
    8359:	80 f9 02             	cmp    $0x2,%cl
    835c:	74 52                	je     83b0 <fwp_caps12+0x150>
    835e:	80 f9 01             	cmp    $0x1,%cl
    8361:	75 b5                	jne    8318 <fwp_caps12+0xb8>
    8363:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8366:	0f b7 ff             	movzwl %di,%edi
    8369:	8b 52 1c             	mov    0x1c(%rdx),%edx
    836c:	48 0f af f9          	imul   %rcx,%rdi
    8370:	48 c1 ef 20          	shr    $0x20,%rdi
    8374:	48 39 d7             	cmp    %rdx,%rdi
    8377:	73 9f                	jae    8318 <fwp_caps12+0xb8>
    8379:	48 01 f8             	add    %rdi,%rax
    837c:	0f b6 10             	movzbl (%rax),%edx
    837f:	84 d2                	test   %dl,%dl
    8381:	74 95                	je     8318 <fwp_caps12+0xb8>
    8383:	8b 0d 9f 61 06 00    	mov    0x6619f(%rip),%ecx        # 6e528 <iteration_active>
    8389:	85 c9                	test   %ecx,%ecx
    838b:	75 33                	jne    83c0 <fwp_caps12+0x160>
    838d:	80 fa fd             	cmp    $0xfd,%dl
    8390:	77 38                	ja     83ca <fwp_caps12+0x16a>
    8392:	83 c2 01             	add    $0x1,%edx
    8395:	88 10                	mov    %dl,(%rax)
    8397:	e9 7c ff ff ff       	jmp    8318 <fwp_caps12+0xb8>
    839c:	0f 1f 40 00          	nopl   0x0(%rax)
    83a0:	66 85 d2             	test   %dx,%dx
    83a3:	0f 85 6f ff ff ff    	jne    8318 <fwp_caps12+0xb8>
    83a9:	e9 48 ff ff ff       	jmp    82f6 <fwp_caps12+0x96>
    83ae:	66 90                	xchg   %ax,%ax
    83b0:	66 85 ff             	test   %di,%di
    83b3:	0f 85 5f ff ff ff    	jne    8318 <fwp_caps12+0xb8>
    83b9:	eb c1                	jmp    837c <fwp_caps12+0x11c>
    83bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    83c0:	48 83 05 48 61 06 00 	addq   $0x1,0x66148(%rip)        # 6e510 <iteration_retains>
    83c7:	01 
    83c8:	eb c3                	jmp    838d <fwp_caps12+0x12d>
    83ca:	48 89 c7             	mov    %rax,%rdi
    83cd:	48 83 c4 18          	add    $0x18,%rsp
    83d1:	e9 3a d3 ff ff       	jmp    5710 <fwp_rc_wide_dup>
    83d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    83dd:	00 00 00 

00000000000083e0 <fwp_caps23>:
    83e0:	f3 0f 1e fa          	endbr64
    83e4:	48 83 ec 18          	sub    $0x18,%rsp
    83e8:	48 89 f8             	mov    %rdi,%rax
    83eb:	8b 7f 04             	mov    0x4(%rdi),%edi
    83ee:	85 ff                	test   %edi,%edi
    83f0:	0f 84 9a 00 00 00    	je     8490 <fwp_caps23+0xb0>
    83f6:	48 8b 78 08          	mov    0x8(%rax),%rdi
    83fa:	85 f6                	test   %esi,%esi
    83fc:	0f 85 9e 00 00 00    	jne    84a0 <fwp_caps23+0xc0>
    8402:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8407:	e8 34 fa ff ff       	call   7e40 <fwp_drop2>
    840c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8411:	48 8b 0d 20 58 06 00 	mov    0x65820(%rip),%rcx        # 6dc38 <fwp_heap+0x13d8>
    8418:	48 89 c2             	mov    %rax,%rdx
    841b:	48 2b 15 ee 57 06 00 	sub    0x657ee(%rip),%rdx        # 6dc10 <fwp_heap+0x13b0>
    8422:	48 c1 e1 10          	shl    $0x10,%rcx
    8426:	48 39 ca             	cmp    %rcx,%rdx
    8429:	73 6d                	jae    8498 <fwp_caps23+0xb8>
    842b:	48 89 d1             	mov    %rdx,%rcx
    842e:	48 c1 e9 10          	shr    $0x10,%rcx
    8432:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    8436:	48 8b 0d 1b 58 06 00 	mov    0x6581b(%rip),%rcx        # 6dc58 <fwp_heap+0x13f8>
    843d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    8441:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8445:	48 85 f6             	test   %rsi,%rsi
    8448:	74 4e                	je     8498 <fwp_caps23+0xb8>
    844a:	0f b6 39             	movzbl (%rcx),%edi
    844d:	40 80 ff 02          	cmp    $0x2,%dil
    8451:	0f 84 c9 00 00 00    	je     8520 <fwp_caps23+0x140>
    8457:	40 80 ff 01          	cmp    $0x1,%dil
    845b:	75 3b                	jne    8498 <fwp_caps23+0xb8>
    845d:	8b 79 18             	mov    0x18(%rcx),%edi
    8460:	0f b7 d2             	movzwl %dx,%edx
    8463:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8466:	48 0f af d7          	imul   %rdi,%rdx
    846a:	48 c1 ea 20          	shr    $0x20,%rdx
    846e:	48 39 ca             	cmp    %rcx,%rdx
    8471:	73 25                	jae    8498 <fwp_caps23+0xb8>
    8473:	48 01 d6             	add    %rdx,%rsi
    8476:	80 3e 01             	cmpb   $0x1,(%rsi)
    8479:	75 1d                	jne    8498 <fwp_caps23+0xb8>
    847b:	48 89 c7             	mov    %rax,%rdi
    847e:	48 83 c4 18          	add    $0x18,%rsp
    8482:	e9 e9 d5 ff ff       	jmp    5a70 <fwp_mem_free>
    8487:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    848e:	00 00 
    8490:	85 f6                	test   %esi,%esi
    8492:	0f 84 79 ff ff ff    	je     8411 <fwp_caps23+0x31>
    8498:	48 83 c4 18          	add    $0x18,%rsp
    849c:	c3                   	ret
    849d:	0f 1f 00             	nopl   (%rax)
    84a0:	48 8b 05 91 57 06 00 	mov    0x65791(%rip),%rax        # 6dc38 <fwp_heap+0x13d8>
    84a7:	48 2b 3d 62 57 06 00 	sub    0x65762(%rip),%rdi        # 6dc10 <fwp_heap+0x13b0>
    84ae:	48 c1 e0 10          	shl    $0x10,%rax
    84b2:	48 39 c7             	cmp    %rax,%rdi
    84b5:	73 e1                	jae    8498 <fwp_caps23+0xb8>
    84b7:	48 89 f8             	mov    %rdi,%rax
    84ba:	48 c1 e8 10          	shr    $0x10,%rax
    84be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    84c2:	48 8b 05 8f 57 06 00 	mov    0x6578f(%rip),%rax        # 6dc58 <fwp_heap+0x13f8>
    84c9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    84cd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    84d1:	48 85 c0             	test   %rax,%rax
    84d4:	74 c2                	je     8498 <fwp_caps23+0xb8>
    84d6:	0f b6 0a             	movzbl (%rdx),%ecx
    84d9:	80 f9 02             	cmp    $0x2,%cl
    84dc:	74 52                	je     8530 <fwp_caps23+0x150>
    84de:	80 f9 01             	cmp    $0x1,%cl
    84e1:	75 b5                	jne    8498 <fwp_caps23+0xb8>
    84e3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    84e6:	0f b7 ff             	movzwl %di,%edi
    84e9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    84ec:	48 0f af f9          	imul   %rcx,%rdi
    84f0:	48 c1 ef 20          	shr    $0x20,%rdi
    84f4:	48 39 d7             	cmp    %rdx,%rdi
    84f7:	73 9f                	jae    8498 <fwp_caps23+0xb8>
    84f9:	48 01 f8             	add    %rdi,%rax
    84fc:	0f b6 10             	movzbl (%rax),%edx
    84ff:	84 d2                	test   %dl,%dl
    8501:	74 95                	je     8498 <fwp_caps23+0xb8>
    8503:	8b 0d 1f 60 06 00    	mov    0x6601f(%rip),%ecx        # 6e528 <iteration_active>
    8509:	85 c9                	test   %ecx,%ecx
    850b:	75 33                	jne    8540 <fwp_caps23+0x160>
    850d:	80 fa fd             	cmp    $0xfd,%dl
    8510:	77 38                	ja     854a <fwp_caps23+0x16a>
    8512:	83 c2 01             	add    $0x1,%edx
    8515:	88 10                	mov    %dl,(%rax)
    8517:	e9 7c ff ff ff       	jmp    8498 <fwp_caps23+0xb8>
    851c:	0f 1f 40 00          	nopl   0x0(%rax)
    8520:	66 85 d2             	test   %dx,%dx
    8523:	0f 85 6f ff ff ff    	jne    8498 <fwp_caps23+0xb8>
    8529:	e9 48 ff ff ff       	jmp    8476 <fwp_caps23+0x96>
    852e:	66 90                	xchg   %ax,%ax
    8530:	66 85 ff             	test   %di,%di
    8533:	0f 85 5f ff ff ff    	jne    8498 <fwp_caps23+0xb8>
    8539:	eb c1                	jmp    84fc <fwp_caps23+0x11c>
    853b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8540:	48 83 05 c8 5f 06 00 	addq   $0x1,0x65fc8(%rip)        # 6e510 <iteration_retains>
    8547:	01 
    8548:	eb c3                	jmp    850d <fwp_caps23+0x12d>
    854a:	48 89 c7             	mov    %rax,%rdi
    854d:	48 83 c4 18          	add    $0x18,%rsp
    8551:	e9 ba d1 ff ff       	jmp    5710 <fwp_rc_wide_dup>
    8556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    855d:	00 00 00 

0000000000008560 <f23>:
    8560:	41 57                	push   %r15
    8562:	41 56                	push   %r14
    8564:	41 55                	push   %r13
    8566:	41 54                	push   %r12
    8568:	55                   	push   %rbp
    8569:	53                   	push   %rbx
    856a:	48 83 ec 38          	sub    $0x38,%rsp
    856e:	48 8b 15 c3 56 06 00 	mov    0x656c3(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    8575:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    857a:	48 c1 e2 10          	shl    $0x10,%rdx
    857e:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    8585:	00 00 
    8587:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    858c:	48 8b 0d 7d 56 06 00 	mov    0x6567d(%rip),%rcx        # 6dc10 <fwp_heap+0x13b0>
    8593:	48 85 ff             	test   %rdi,%rdi
    8596:	0f 84 1e 03 00 00    	je     88ba <f23+0x35a>
    859c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    85a1:	4c 8b 68 10          	mov    0x10(%rax),%r13
    85a5:	4c 89 e8             	mov    %r13,%rax
    85a8:	48 29 c8             	sub    %rcx,%rax
    85ab:	48 39 d0             	cmp    %rdx,%rax
    85ae:	0f 83 ec 02 00 00    	jae    88a0 <f23+0x340>
    85b4:	48 89 c2             	mov    %rax,%rdx
    85b7:	48 c1 ea 10          	shr    $0x10,%rdx
    85bb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    85bf:	48 8b 15 92 56 06 00 	mov    0x65692(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    85c6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    85ca:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    85ce:	48 85 ff             	test   %rdi,%rdi
    85d1:	0f 84 c9 02 00 00    	je     88a0 <f23+0x340>
    85d7:	0f b6 0a             	movzbl (%rdx),%ecx
    85da:	80 f9 02             	cmp    $0x2,%cl
    85dd:	0f 84 4d 02 00 00    	je     8830 <f23+0x2d0>
    85e3:	80 f9 01             	cmp    $0x1,%cl
    85e6:	75 24                	jne    860c <f23+0xac>
    85e8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    85eb:	0f b7 c0             	movzwl %ax,%eax
    85ee:	8b 52 1c             	mov    0x1c(%rdx),%edx
    85f1:	48 0f af c1          	imul   %rcx,%rax
    85f5:	48 c1 e8 20          	shr    $0x20,%rax
    85f9:	48 39 d0             	cmp    %rdx,%rax
    85fc:	73 0e                	jae    860c <f23+0xac>
    85fe:	48 01 c7             	add    %rax,%rdi
    8601:	0f b6 07             	movzbl (%rdi),%eax
    8604:	84 c0                	test   %al,%al
    8606:	0f 85 44 02 00 00    	jne    8850 <f23+0x2f0>
    860c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8611:	48 8b 40 10          	mov    0x10(%rax),%rax
    8615:	ba 01 00 00 00       	mov    $0x1,%edx
    861a:	48 85 c0             	test   %rax,%rax
    861d:	74 0e                	je     862d <f23+0xcd>
    861f:	90                   	nop
    8620:	48 8b 40 10          	mov    0x10(%rax),%rax
    8624:	48 83 c2 01          	add    $0x1,%rdx
    8628:	48 85 c0             	test   %rax,%rax
    862b:	75 f3                	jne    8620 <f23+0xc0>
    862d:	4d 85 ed             	test   %r13,%r13
    8630:	0f 84 9a 02 00 00    	je     88d0 <f23+0x370>
    8636:	4c 89 e8             	mov    %r13,%rax
    8639:	31 db                	xor    %ebx,%ebx
    863b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8640:	48 8b 40 10          	mov    0x10(%rax),%rax
    8644:	48 83 c3 01          	add    $0x1,%rbx
    8648:	48 85 c0             	test   %rax,%rax
    864b:	75 f3                	jne    8640 <f23+0xe0>
    864d:	48 39 d3             	cmp    %rdx,%rbx
    8650:	48 0f 47 da          	cmova  %rdx,%rbx
    8654:	48 89 d8             	mov    %rbx,%rax
    8657:	48 c1 e8 3c          	shr    $0x3c,%rax
    865b:	0f 85 7d 03 00 00    	jne    89de <f23+0x47e>
    8661:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8665:	be 02 00 00 00       	mov    $0x2,%esi
    866a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8671:	00 
    8672:	e8 f9 d8 ff ff       	call   5f70 <fwp_heap_alloc>
    8677:	48 89 28             	mov    %rbp,(%rax)
    867a:	48 8b 15 b7 55 06 00 	mov    0x655b7(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    8681:	49 89 c4             	mov    %rax,%r12
    8684:	48 2b 05 85 55 06 00 	sub    0x65585(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    868b:	48 c1 e2 10          	shl    $0x10,%rdx
    868f:	48 39 d0             	cmp    %rdx,%rax
    8692:	73 57                	jae    86eb <f23+0x18b>
    8694:	48 89 c2             	mov    %rax,%rdx
    8697:	48 c1 ea 10          	shr    $0x10,%rdx
    869b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    869f:	48 8b 15 b2 55 06 00 	mov    0x655b2(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    86a6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    86aa:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    86ae:	48 85 ed             	test   %rbp,%rbp
    86b1:	74 38                	je     86eb <f23+0x18b>
    86b3:	0f b6 0a             	movzbl (%rdx),%ecx
    86b6:	80 f9 02             	cmp    $0x2,%cl
    86b9:	0f 84 d1 01 00 00    	je     8890 <f23+0x330>
    86bf:	80 f9 01             	cmp    $0x1,%cl
    86c2:	75 27                	jne    86eb <f23+0x18b>
    86c4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    86c7:	0f b7 c0             	movzwl %ax,%eax
    86ca:	8b 52 1c             	mov    0x1c(%rdx),%edx
    86cd:	48 0f af c1          	imul   %rcx,%rax
    86d1:	48 c1 e8 20          	shr    $0x20,%rax
    86d5:	48 39 d0             	cmp    %rdx,%rax
    86d8:	73 11                	jae    86eb <f23+0x18b>
    86da:	48 01 c5             	add    %rax,%rbp
    86dd:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    86e1:	0f 84 57 02 00 00    	je     893e <f23+0x3de>
    86e7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    86eb:	48 85 db             	test   %rbx,%rbx
    86ee:	74 5d                	je     874d <f23+0x1ed>
    86f0:	48 c1 e3 04          	shl    $0x4,%rbx
    86f4:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    86f9:	4c 89 e5             	mov    %r12,%rbp
    86fc:	4d 89 ef             	mov    %r13,%r15
    86ff:	4c 01 e3             	add    %r12,%rbx
    8702:	0f 1f 00             	nopl   (%rax)
    8705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    870c:	00 00 00 00 
    8710:	49 8b 46 08          	mov    0x8(%r14),%rax
    8714:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8718:	48 83 c5 10          	add    $0x10,%rbp
    871c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8721:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8725:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8729:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    872e:	e8 fd df ff ff       	call   6730 <w107>
    8733:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8738:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    873c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8740:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8744:	4d 8b 76 10          	mov    0x10(%r14),%r14
    8748:	48 39 dd             	cmp    %rbx,%rbp
    874b:	75 c3                	jne    8710 <f23+0x1b0>
    874d:	4c 89 ef             	mov    %r13,%rdi
    8750:	e8 eb f6 ff ff       	call   7e40 <fwp_drop2>
    8755:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    875a:	e8 e1 f6 ff ff       	call   7e40 <fwp_drop2>
    875f:	4c 89 e7             	mov    %r12,%rdi
    8762:	e8 49 e1 ff ff       	call   68b0 <w164.constprop.0>
    8767:	4c 89 e7             	mov    %r12,%rdi
    876a:	48 89 c3             	mov    %rax,%rbx
    876d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8773:	e8 48 f4 ff ff       	call   7bc0 <fwp_drop4>
    8778:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    877e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    8783:	31 ff                	xor    %edi,%edi
    8785:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    878a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    878e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    8793:	e8 b8 e1 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    8798:	48 8b 15 99 54 06 00 	mov    0x65499(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    879f:	48 89 c5             	mov    %rax,%rbp
    87a2:	48 2b 05 67 54 06 00 	sub    0x65467(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    87a9:	48 c1 e2 10          	shl    $0x10,%rdx
    87ad:	48 39 d0             	cmp    %rdx,%rax
    87b0:	73 55                	jae    8807 <f23+0x2a7>
    87b2:	48 89 c2             	mov    %rax,%rdx
    87b5:	48 c1 ea 10          	shr    $0x10,%rdx
    87b9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    87bd:	48 8b 15 94 54 06 00 	mov    0x65494(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    87c4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    87c8:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    87cc:	48 85 db             	test   %rbx,%rbx
    87cf:	74 36                	je     8807 <f23+0x2a7>
    87d1:	0f b6 0a             	movzbl (%rdx),%ecx
    87d4:	80 f9 02             	cmp    $0x2,%cl
    87d7:	0f 84 a3 00 00 00    	je     8880 <f23+0x320>
    87dd:	80 f9 01             	cmp    $0x1,%cl
    87e0:	75 25                	jne    8807 <f23+0x2a7>
    87e2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    87e5:	0f b7 c0             	movzwl %ax,%eax
    87e8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    87eb:	48 0f af c1          	imul   %rcx,%rax
    87ef:	48 c1 e8 20          	shr    $0x20,%rax
    87f3:	48 39 d0             	cmp    %rdx,%rax
    87f6:	73 0f                	jae    8807 <f23+0x2a7>
    87f8:	48 01 c3             	add    %rax,%rbx
    87fb:	80 3b ff             	cmpb   $0xff,(%rbx)
    87fe:	0f 84 2d 01 00 00    	je     8931 <f23+0x3d1>
    8804:	c6 03 01             	movb   $0x1,(%rbx)
    8807:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    880c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8813:	00 00 
    8815:	0f 85 cf 01 00 00    	jne    89ea <f23+0x48a>
    881b:	48 83 c4 38          	add    $0x38,%rsp
    881f:	48 89 e8             	mov    %rbp,%rax
    8822:	5b                   	pop    %rbx
    8823:	5d                   	pop    %rbp
    8824:	41 5c                	pop    %r12
    8826:	41 5d                	pop    %r13
    8828:	41 5e                	pop    %r14
    882a:	41 5f                	pop    %r15
    882c:	c3                   	ret
    882d:	0f 1f 00             	nopl   (%rax)
    8830:	66 85 c0             	test   %ax,%ax
    8833:	0f 85 d3 fd ff ff    	jne    860c <f23+0xac>
    8839:	0f b6 07             	movzbl (%rdi),%eax
    883c:	84 c0                	test   %al,%al
    883e:	0f 84 c8 fd ff ff    	je     860c <f23+0xac>
    8844:	90                   	nop
    8845:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    884c:	00 00 00 00 
    8850:	8b 15 d2 5c 06 00    	mov    0x65cd2(%rip),%edx        # 6e528 <iteration_active>
    8856:	85 d2                	test   %edx,%edx
    8858:	75 56                	jne    88b0 <f23+0x350>
    885a:	3c fd                	cmp    $0xfd,%al
    885c:	0f 87 4b 01 00 00    	ja     89ad <f23+0x44d>
    8862:	83 c0 01             	add    $0x1,%eax
    8865:	88 07                	mov    %al,(%rdi)
    8867:	31 d2                	xor    %edx,%edx
    8869:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    886f:	0f 85 97 fd ff ff    	jne    860c <f23+0xac>
    8875:	e9 b3 fd ff ff       	jmp    862d <f23+0xcd>
    887a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8880:	66 85 c0             	test   %ax,%ax
    8883:	0f 85 7e ff ff ff    	jne    8807 <f23+0x2a7>
    8889:	e9 6d ff ff ff       	jmp    87fb <f23+0x29b>
    888e:	66 90                	xchg   %ax,%ax
    8890:	66 85 c0             	test   %ax,%ax
    8893:	0f 85 52 fe ff ff    	jne    86eb <f23+0x18b>
    8899:	e9 3f fe ff ff       	jmp    86dd <f23+0x17d>
    889e:	66 90                	xchg   %ax,%ax
    88a0:	4c 89 e8             	mov    %r13,%rax
    88a3:	e9 6d fd ff ff       	jmp    8615 <f23+0xb5>
    88a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    88af:	00 
    88b0:	48 83 05 58 5c 06 00 	addq   $0x1,0x65c58(%rip)        # 6e510 <iteration_retains>
    88b7:	01 
    88b8:	eb a0                	jmp    885a <f23+0x2fa>
    88ba:	48 f7 d9             	neg    %rcx
    88bd:	48 39 d1             	cmp    %rdx,%rcx
    88c0:	0f 82 85 00 00 00    	jb     894b <f23+0x3eb>
    88c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    88cd:	00 00 00 
    88d0:	be 02 00 00 00       	mov    $0x2,%esi
    88d5:	bf 08 00 00 00       	mov    $0x8,%edi
    88da:	e8 91 d6 ff ff       	call   5f70 <fwp_heap_alloc>
    88df:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    88e6:	48 8b 15 4b 53 06 00 	mov    0x6534b(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    88ed:	49 89 c4             	mov    %rax,%r12
    88f0:	48 2b 05 19 53 06 00 	sub    0x65319(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    88f7:	48 c1 e2 10          	shl    $0x10,%rdx
    88fb:	48 39 d0             	cmp    %rdx,%rax
    88fe:	0f 83 b3 00 00 00    	jae    89b7 <f23+0x457>
    8904:	48 89 c2             	mov    %rax,%rdx
    8907:	48 c1 ea 10          	shr    $0x10,%rdx
    890b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    890f:	48 8b 15 42 53 06 00 	mov    0x65342(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    8916:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    891a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    891e:	48 85 ed             	test   %rbp,%rbp
    8921:	0f 84 90 00 00 00    	je     89b7 <f23+0x457>
    8927:	31 db                	xor    %ebx,%ebx
    8929:	45 31 ed             	xor    %r13d,%r13d
    892c:	e9 82 fd ff ff       	jmp    86b3 <f23+0x153>
    8931:	48 89 df             	mov    %rbx,%rdi
    8934:	e8 f7 ce ff ff       	call   5830 <fwp_rc_forget_slot>
    8939:	e9 c6 fe ff ff       	jmp    8804 <f23+0x2a4>
    893e:	48 89 ef             	mov    %rbp,%rdi
    8941:	e8 ea ce ff ff       	call   5830 <fwp_rc_forget_slot>
    8946:	e9 9c fd ff ff       	jmp    86e7 <f23+0x187>
    894b:	48 89 c8             	mov    %rcx,%rax
    894e:	48 c1 e8 10          	shr    $0x10,%rax
    8952:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8956:	48 8b 05 fb 52 06 00 	mov    0x652fb(%rip),%rax        # 6dc58 <fwp_heap+0x13f8>
    895d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8961:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8965:	48 85 ff             	test   %rdi,%rdi
    8968:	0f 84 62 ff ff ff    	je     88d0 <f23+0x370>
    896e:	0f b6 02             	movzbl (%rdx),%eax
    8971:	3c 02                	cmp    $0x2,%al
    8973:	74 4a                	je     89bf <f23+0x45f>
    8975:	3c 01                	cmp    $0x1,%al
    8977:	0f 85 53 ff ff ff    	jne    88d0 <f23+0x370>
    897d:	0f b7 c1             	movzwl %cx,%eax
    8980:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8983:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8986:	48 0f af c1          	imul   %rcx,%rax
    898a:	48 c1 e8 20          	shr    $0x20,%rax
    898e:	48 39 d0             	cmp    %rdx,%rax
    8991:	0f 83 39 ff ff ff    	jae    88d0 <f23+0x370>
    8997:	48 01 c7             	add    %rax,%rdi
    899a:	0f b6 07             	movzbl (%rdi),%eax
    899d:	84 c0                	test   %al,%al
    899f:	0f 84 2b ff ff ff    	je     88d0 <f23+0x370>
    89a5:	45 31 ed             	xor    %r13d,%r13d
    89a8:	e9 a3 fe ff ff       	jmp    8850 <f23+0x2f0>
    89ad:	e8 5e cd ff ff       	call   5710 <fwp_rc_wide_dup>
    89b2:	e9 b0 fe ff ff       	jmp    8867 <f23+0x307>
    89b7:	45 31 ed             	xor    %r13d,%r13d
    89ba:	e9 8e fd ff ff       	jmp    874d <f23+0x1ed>
    89bf:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    89c5:	49 89 cd             	mov    %rcx,%r13
    89c8:	0f 85 02 ff ff ff    	jne    88d0 <f23+0x370>
    89ce:	0f b6 07             	movzbl (%rdi),%eax
    89d1:	84 c0                	test   %al,%al
    89d3:	0f 85 77 fe ff ff    	jne    8850 <f23+0x2f0>
    89d9:	e9 f2 fe ff ff       	jmp    88d0 <f23+0x370>
    89de:	48 8d 3d 06 78 00 00 	lea    0x7806(%rip),%rdi        # 101eb <_IO_stdin_used+0x1eb>
    89e5:	e8 66 ba ff ff       	call   4450 <fwp_trap>
    89ea:	e8 61 aa ff ff       	call   3450 <__stack_chk_fail@plt>
    89ef:	90                   	nop

00000000000089f0 <fwp_owned_entry23>:
    89f0:	f3 0f 1e fa          	endbr64
    89f4:	48 8b 3f             	mov    (%rdi),%rdi
    89f7:	e9 64 fb ff ff       	jmp    8560 <f23>
    89fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008a00 <e23>:
    8a00:	f3 0f 1e fa          	endbr64
    8a04:	53                   	push   %rbx
    8a05:	48 8b 1f             	mov    (%rdi),%rbx
    8a08:	48 89 df             	mov    %rbx,%rdi
    8a0b:	e8 30 e1 ff ff       	call   6b40 <fwp_rc_share>
    8a10:	48 89 df             	mov    %rbx,%rdi
    8a13:	e8 48 fb ff ff       	call   8560 <f23>
    8a18:	48 89 c3             	mov    %rax,%rbx
    8a1b:	48 89 c7             	mov    %rax,%rdi
    8a1e:	e8 1d e1 ff ff       	call   6b40 <fwp_rc_share>
    8a23:	48 89 d8             	mov    %rbx,%rax
    8a26:	5b                   	pop    %rbx
    8a27:	c3                   	ret
    8a28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8a2f:	00 

0000000000008a30 <f12>:
    8a30:	41 57                	push   %r15
    8a32:	41 56                	push   %r14
    8a34:	41 55                	push   %r13
    8a36:	4c 8d 2d c3 eb ff ff 	lea    -0x143d(%rip),%r13        # 7600 <fwp_tape_scope_release>
    8a3d:	41 54                	push   %r12
    8a3f:	55                   	push   %rbp
    8a40:	53                   	push   %rbx
    8a41:	48 81 ec 18 01 00 00 	sub    $0x118,%rsp
    8a48:	48 8b 05 a9 5a 06 00 	mov    0x65aa9(%rip),%rax        # 6e4f8 <fwp_cleanups>
    8a4f:	48 8b 15 e2 51 06 00 	mov    0x651e2(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    8a56:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    8a5d:	00 00 
    8a5f:	48 89 ac 24 08 01 00 	mov    %rbp,0x108(%rsp)
    8a66:	00 
    8a67:	48 89 fd             	mov    %rdi,%rbp
    8a6a:	4c 8d 7c 24 70       	lea    0x70(%rsp),%r15
    8a6f:	c7 44 24 6c ff ff ff 	movl   $0xffffffff,0x6c(%rsp)
    8a76:	ff 
    8a77:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    8a7c:	48 8d 44 24 6c       	lea    0x6c(%rsp),%rax
    8a81:	48 c1 e2 10          	shl    $0x10,%rdx
    8a85:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8a8a:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    8a91:	00 
    8a92:	48 8d 05 77 b5 00 00 	lea    0xb577(%rip),%rax        # 14010 <fc23>
    8a99:	48 2b 05 70 51 06 00 	sub    0x65170(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    8aa0:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    8aa5:	4c 89 3d 4c 5a 06 00 	mov    %r15,0x65a4c(%rip)        # 6e4f8 <fwp_cleanups>
    8aac:	48 39 d0             	cmp    %rdx,%rax
    8aaf:	73 6d                	jae    8b1e <f12+0xee>
    8ab1:	48 89 c2             	mov    %rax,%rdx
    8ab4:	48 c1 ea 10          	shr    $0x10,%rdx
    8ab8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8abc:	48 8b 15 95 51 06 00 	mov    0x65195(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    8ac3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8ac7:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8acb:	48 85 ff             	test   %rdi,%rdi
    8ace:	74 4e                	je     8b1e <f12+0xee>
    8ad0:	0f b6 0a             	movzbl (%rdx),%ecx
    8ad3:	80 f9 02             	cmp    $0x2,%cl
    8ad6:	0f 84 64 0f 00 00    	je     9a40 <f12+0x1010>
    8adc:	80 f9 01             	cmp    $0x1,%cl
    8adf:	75 3d                	jne    8b1e <f12+0xee>
    8ae1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8ae4:	0f b7 c0             	movzwl %ax,%eax
    8ae7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8aea:	48 0f af c1          	imul   %rcx,%rax
    8aee:	48 c1 e8 20          	shr    $0x20,%rax
    8af2:	48 39 d0             	cmp    %rdx,%rax
    8af5:	73 27                	jae    8b1e <f12+0xee>
    8af7:	48 01 c7             	add    %rax,%rdi
    8afa:	0f b6 07             	movzbl (%rdi),%eax
    8afd:	84 c0                	test   %al,%al
    8aff:	74 1d                	je     8b1e <f12+0xee>
    8b01:	44 8b 05 20 5a 06 00 	mov    0x65a20(%rip),%r8d        # 6e528 <iteration_active>
    8b08:	45 85 c0             	test   %r8d,%r8d
    8b0b:	0f 85 5f 10 00 00    	jne    9b70 <f12+0x1140>
    8b11:	3c fd                	cmp    $0xfd,%al
    8b13:	0f 87 1b 12 00 00    	ja     9d34 <f12+0x1304>
    8b19:	83 c0 01             	add    $0x1,%eax
    8b1c:	88 07                	mov    %al,(%rdi)
    8b1e:	48 8d 3d eb b4 00 00 	lea    0xb4eb(%rip),%rdi        # 14010 <fc23>
    8b25:	e8 66 e7 ff ff       	call   7290 <fwp_closure_drop>
    8b2a:	48 85 ed             	test   %rbp,%rbp
    8b2d:	0f 84 56 11 00 00    	je     9c89 <f12+0x1259>
    8b33:	48 89 e8             	mov    %rbp,%rax
    8b36:	31 d2                	xor    %edx,%edx
    8b38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8b3f:	00 
    8b40:	48 8b 40 10          	mov    0x10(%rax),%rax
    8b44:	48 83 c2 01          	add    $0x1,%rdx
    8b48:	48 85 c0             	test   %rax,%rax
    8b4b:	75 f3                	jne    8b40 <f12+0x110>
    8b4d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    8b54:	0f 87 6a 12 00 00    	ja     9dc4 <f12+0x1394>
    8b5a:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    8b5f:	8b 35 1b b5 00 00    	mov    0xb51b(%rip),%esi        # 14080 <registered_finish.0>
    8b65:	85 f6                	test   %esi,%esi
    8b67:	0f 84 a3 0e 00 00    	je     9a10 <f12+0xfe0>
    8b6d:	48 8b 1d a4 b5 01 00 	mov    0x1b5a4(%rip),%rbx        # 24118 <fwp_tape_next_slot>
    8b74:	4c 8b 25 ad b5 01 00 	mov    0x1b5ad(%rip),%r12        # 24128 <fwp_ntapes>
    8b7b:	4c 39 e3             	cmp    %r12,%rbx
    8b7e:	0f 8d d4 00 00 00    	jge    8c58 <f12+0x228>
    8b84:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    8b88:	48 03 05 a1 b5 01 00 	add    0x1b5a1(%rip),%rax        # 24130 <fwp_tapes>
    8b8f:	90                   	nop
    8b90:	8b 48 04             	mov    0x4(%rax),%ecx
    8b93:	85 c9                	test   %ecx,%ecx
    8b95:	75 0c                	jne    8ba3 <f12+0x173>
    8b97:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    8b9d:	0f 86 b5 00 00 00    	jbe    8c58 <f12+0x228>
    8ba3:	48 83 c3 01          	add    $0x1,%rbx
    8ba7:	48 83 c0 68          	add    $0x68,%rax
    8bab:	4c 39 e3             	cmp    %r12,%rbx
    8bae:	75 e0                	jne    8b90 <f12+0x160>
    8bb0:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    8bb7:	0f 8f 7c 12 00 00    	jg     9e39 <f12+0x1409>
    8bbd:	4c 39 25 5c b5 01 00 	cmp    %r12,0x1b55c(%rip)        # 24120 <fwp_tapes_cap>
    8bc4:	4c 8b 35 65 b5 01 00 	mov    0x1b565(%rip),%r14        # 24130 <fwp_tapes>
    8bcb:	75 4b                	jne    8c18 <f12+0x1e8>
    8bcd:	4d 85 e4             	test   %r12,%r12
    8bd0:	0f 84 18 11 00 00    	je     9cee <f12+0x12be>
    8bd6:	4b 8d 1c 24          	lea    (%r12,%r12,1),%rbx
    8bda:	b8 ff ff 00 00       	mov    $0xffff,%eax
    8bdf:	48 39 c3             	cmp    %rax,%rbx
    8be2:	48 0f 4f d8          	cmovg  %rax,%rbx
    8be6:	48 6b f3 68          	imul   $0x68,%rbx,%rsi
    8bea:	31 d2                	xor    %edx,%edx
    8bec:	4c 89 f7             	mov    %r14,%rdi
    8bef:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8bf4:	e8 f7 c5 ff ff       	call   51f0 <ad_raw_realloc>
    8bf9:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8bfe:	48 85 c0             	test   %rax,%rax
    8c01:	49 89 c6             	mov    %rax,%r14
    8c04:	0f 84 f5 11 00 00    	je     9dff <f12+0x13cf>
    8c0a:	48 89 05 1f b5 01 00 	mov    %rax,0x1b51f(%rip)        # 24130 <fwp_tapes>
    8c11:	48 89 1d 08 b5 01 00 	mov    %rbx,0x1b508(%rip)        # 24120 <fwp_tapes_cap>
    8c18:	49 6b c4 68          	imul   $0x68,%r12,%rax
    8c1c:	4c 89 e3             	mov    %r12,%rbx
    8c1f:	4c 01 f0             	add    %r14,%rax
    8c22:	48 8d 78 08          	lea    0x8(%rax),%rdi
    8c26:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8c2d:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    8c31:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    8c38:	00 
    8c39:	48 29 f8             	sub    %rdi,%rax
    8c3c:	8d 48 68             	lea    0x68(%rax),%ecx
    8c3f:	31 c0                	xor    %eax,%eax
    8c41:	c1 e9 03             	shr    $0x3,%ecx
    8c44:	f3 48 ab             	rep stos %rax,(%rdi)
    8c47:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    8c4c:	48 89 05 d5 b4 01 00 	mov    %rax,0x1b4d5(%rip)        # 24128 <fwp_ntapes>
    8c53:	eb 13                	jmp    8c68 <f12+0x238>
    8c55:	0f 1f 00             	nopl   (%rax)
    8c58:	49 39 dc             	cmp    %rbx,%r12
    8c5b:	0f 84 4f ff ff ff    	je     8bb0 <f12+0x180>
    8c61:	4c 8b 35 c8 b4 01 00 	mov    0x1b4c8(%rip),%r14        # 24130 <fwp_tapes>
    8c68:	4c 6b e3 68          	imul   $0x68,%rbx,%r12
    8c6c:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    8c70:	48 8d 3d e9 74 00 00 	lea    0x74e9(%rip),%rdi        # 10160 <_IO_stdin_used+0x160>
    8c77:	0f 29 04 24          	movaps %xmm0,(%rsp)
    8c7b:	4d 01 f4             	add    %r14,%r12
    8c7e:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    8c85:	00 00 
    8c87:	e8 04 a7 ff ff       	call   3390 <getenv@plt>
    8c8c:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    8c91:	48 85 c0             	test   %rax,%rax
    8c94:	74 09                	je     8c9f <f12+0x26f>
    8c96:	80 38 30             	cmpb   $0x30,(%rax)
    8c99:	0f 84 21 07 00 00    	je     93c0 <f12+0x990>
    8c9f:	48 83 3d 21 b4 01 00 	cmpq   $0x0,0x1b421(%rip)        # 240c8 <fwp_tape_cached_bytes>
    8ca6:	00 
    8ca7:	0f 85 f3 0d 00 00    	jne    9aa0 <f12+0x1070>
    8cad:	41 8b 04 24          	mov    (%r12),%eax
    8cb1:	48 8d 7b 01          	lea    0x1(%rbx),%rdi
    8cb5:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    8cbc:	00 00 
    8cbe:	48 89 3d 53 b4 01 00 	mov    %rdi,0x1b453(%rip)        # 24118 <fwp_tape_next_slot>
    8cc5:	8d 70 01             	lea    0x1(%rax),%esi
    8cc8:	48 8b 05 29 58 06 00 	mov    0x65829(%rip),%rax        # 6e4f8 <fwp_cleanups>
    8ccf:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    8cd6:	00 00 
    8cd8:	41 89 34 24          	mov    %esi,(%r12)
    8cdc:	49 c7 44 24 58 ff ff 	movq   $0xffffffffffffffff,0x58(%r12)
    8ce3:	ff ff 
    8ce5:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    8ceb:	48 85 c0             	test   %rax,%rax
    8cee:	75 1c                	jne    8d0c <f12+0x2dc>
    8cf0:	e9 61 11 00 00       	jmp    9e56 <f12+0x1426>
    8cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8cfc:	00 00 00 00 
    8d00:	48 8b 00             	mov    (%rax),%rax
    8d03:	48 85 c0             	test   %rax,%rax
    8d06:	0f 84 4a 11 00 00    	je     9e56 <f12+0x1426>
    8d0c:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    8d10:	75 ee                	jne    8d00 <f12+0x2d0>
    8d12:	48 8b 50 10          	mov    0x10(%rax),%rdx
    8d16:	89 d9                	mov    %ebx,%ecx
    8d18:	48 63 02             	movslq (%rdx),%rax
    8d1b:	49 89 54 24 50       	mov    %rdx,0x50(%r12)
    8d20:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    8d25:	85 c0                	test   %eax,%eax
    8d27:	78 09                	js     8d32 <f12+0x302>
    8d29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    8d2d:	41 89 5c 06 58       	mov    %ebx,0x58(%r14,%rax,1)
    8d32:	89 0a                	mov    %ecx,(%rdx)
    8d34:	48 89 e8             	mov    %rbp,%rax
    8d37:	31 c9                	xor    %ecx,%ecx
    8d39:	48 85 ed             	test   %rbp,%rbp
    8d3c:	0f 84 ae 0b 00 00    	je     98f0 <f12+0xec0>
    8d42:	0f 1f 00             	nopl   (%rax)
    8d45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d4c:	00 00 00 00 
    8d50:	48 8b 40 10          	mov    0x10(%rax),%rax
    8d54:	48 83 c1 01          	add    $0x1,%rcx
    8d58:	48 85 c0             	test   %rax,%rax
    8d5b:	75 f3                	jne    8d50 <f12+0x320>
    8d5d:	48 89 ea             	mov    %rbp,%rdx
    8d60:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8d64:	48 83 c0 01          	add    $0x1,%rax
    8d68:	48 85 d2             	test   %rdx,%rdx
    8d6b:	75 f3                	jne    8d60 <f12+0x330>
    8d6d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    8d74:	ff ff 1f 
    8d77:	48 39 c2             	cmp    %rax,%rdx
    8d7a:	0f 82 50 10 00 00    	jb     9dd0 <f12+0x13a0>
    8d80:	48 85 c9             	test   %rcx,%rcx
    8d83:	0f 8e 67 0b 00 00    	jle    98f0 <f12+0xec0>
    8d89:	48 39 c1             	cmp    %rax,%rcx
    8d8c:	48 0f 46 c1          	cmovbe %rcx,%rax
    8d90:	49 89 c5             	mov    %rax,%r13
    8d93:	48 c1 e8 3c          	shr    $0x3c,%rax
    8d97:	0f 85 33 10 00 00    	jne    9dd0 <f12+0x13a0>
    8d9d:	48 c1 e6 10          	shl    $0x10,%rsi
    8da1:	4f 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%r14
    8da6:	48 09 fe             	or     %rdi,%rsi
    8da9:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8db0:	00 
    8db1:	49 89 f4             	mov    %rsi,%r12
    8db4:	be 02 00 00 00       	mov    $0x2,%esi
    8db9:	e8 b2 d1 ff ff       	call   5f70 <fwp_heap_alloc>
    8dbe:	4c 89 30             	mov    %r14,(%rax)
    8dc1:	48 8b 15 70 4e 06 00 	mov    0x64e70(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    8dc8:	48 89 c3             	mov    %rax,%rbx
    8dcb:	48 2b 05 3e 4e 06 00 	sub    0x64e3e(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    8dd2:	48 c1 e2 10          	shl    $0x10,%rdx
    8dd6:	48 39 d0             	cmp    %rdx,%rax
    8dd9:	0f 83 a9 0b 00 00    	jae    9988 <f12+0xf58>
    8ddf:	48 89 c2             	mov    %rax,%rdx
    8de2:	48 c1 ea 10          	shr    $0x10,%rdx
    8de6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8dea:	48 8b 15 67 4e 06 00 	mov    0x64e67(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    8df1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8df5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8df9:	48 85 d2             	test   %rdx,%rdx
    8dfc:	74 38                	je     8e36 <f12+0x406>
    8dfe:	0f b6 31             	movzbl (%rcx),%esi
    8e01:	40 80 fe 02          	cmp    $0x2,%sil
    8e05:	0f 84 52 0b 00 00    	je     995d <f12+0xf2d>
    8e0b:	40 80 fe 01          	cmp    $0x1,%sil
    8e0f:	75 25                	jne    8e36 <f12+0x406>
    8e11:	8b 71 18             	mov    0x18(%rcx),%esi
    8e14:	0f b7 c0             	movzwl %ax,%eax
    8e17:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8e1a:	48 0f af c6          	imul   %rsi,%rax
    8e1e:	48 c1 e8 20          	shr    $0x20,%rax
    8e22:	48 39 c8             	cmp    %rcx,%rax
    8e25:	73 0f                	jae    8e36 <f12+0x406>
    8e27:	48 01 c2             	add    %rax,%rdx
    8e2a:	80 3a ff             	cmpb   $0xff,(%rdx)
    8e2d:	0f 84 ca 0e 00 00    	je     9cfd <f12+0x12cd>
    8e33:	c6 02 01             	movb   $0x1,(%rdx)
    8e36:	4d 85 ed             	test   %r13,%r13
    8e39:	74 78                	je     8eb3 <f12+0x483>
    8e3b:	4c 89 e1             	mov    %r12,%rcx
    8e3e:	48 89 ea             	mov    %rbp,%rdx
    8e41:	31 c0                	xor    %eax,%eax
    8e43:	48 c1 e1 20          	shl    $0x20,%rcx
    8e47:	66 90                	xchg   %ax,%ax
    8e49:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e50:	00 00 00 00 
    8e54:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e5b:	00 00 00 00 
    8e5f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e66:	00 00 00 00 
    8e6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e71:	00 00 00 00 
    8e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e7c:	00 00 00 00 
    8e80:	48 89 c6             	mov    %rax,%rsi
    8e83:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8e88:	48 01 ce             	add    %rcx,%rsi
    8e8b:	0f 80 26 0f 00 00    	jo     9db7 <f12+0x1387>
    8e91:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    8e96:	48 89 c6             	mov    %rax,%rsi
    8e99:	48 83 c0 01          	add    $0x1,%rax
    8e9d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    8ea1:	48 c1 e6 04          	shl    $0x4,%rsi
    8ea5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    8eaa:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8eae:	4c 39 e8             	cmp    %r13,%rax
    8eb1:	72 cd                	jb     8e80 <f12+0x450>
    8eb3:	48 8b 03             	mov    (%rbx),%rax
    8eb6:	48 d1 e8             	shr    $1,%rax
    8eb9:	0f 84 e1 0a 00 00    	je     99a0 <f12+0xf70>
    8ebf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    8ec3:	48 89 d1             	mov    %rdx,%rcx
    8ec6:	48 c1 e9 3c          	shr    $0x3c,%rcx
    8eca:	0f 85 00 0f 00 00    	jne    9dd0 <f12+0x13a0>
    8ed0:	48 8d 0c 12          	lea    (%rdx,%rdx,1),%rcx
    8ed4:	48 89 0c 24          	mov    %rcx,(%rsp)
    8ed8:	48 85 d2             	test   %rdx,%rdx
    8edb:	74 41                	je     8f1e <f12+0x4ee>
    8edd:	48 c1 e0 04          	shl    $0x4,%rax
    8ee1:	4c 8d 73 08          	lea    0x8(%rbx),%r14
    8ee5:	4c 8d 6c 03 f8       	lea    -0x8(%rbx,%rax,1),%r13
    8eea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ef0:	f2 41 0f 10 06       	movsd  (%r14),%xmm0
    8ef5:	49 8b 76 18          	mov    0x18(%r14),%rsi
    8ef9:	49 83 c6 10          	add    $0x10,%r14
    8efd:	49 8b 7e f8          	mov    -0x8(%r14),%rdi
    8f01:	f2 41 0f 10 0e       	movsd  (%r14),%xmm1
    8f06:	e8 25 d8 ff ff       	call   6730 <w107>
    8f0b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    8f10:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    8f14:	41 0f 11 46 f0       	movups %xmm0,-0x10(%r14)
    8f19:	4d 39 f5             	cmp    %r14,%r13
    8f1c:	75 d2                	jne    8ef0 <f12+0x4c0>
    8f1e:	48 8b 04 24          	mov    (%rsp),%rax
    8f22:	48 89 df             	mov    %rbx,%rdi
    8f25:	48 89 03             	mov    %rax,(%rbx)
    8f28:	e8 83 d9 ff ff       	call   68b0 <w164.constprop.0>
    8f2d:	48 89 df             	mov    %rbx,%rdi
    8f30:	49 63 dc             	movslq %r12d,%rbx
    8f33:	49 89 c5             	mov    %rax,%r13
    8f36:	e8 85 ec ff ff       	call   7bc0 <fwp_drop4>
    8f3b:	48 89 df             	mov    %rbx,%rdi
    8f3e:	e8 7d c0 ff ff       	call   4fc0 <caf61>
    8f43:	48 89 04 24          	mov    %rax,(%rsp)
    8f47:	e8 e4 b7 ff ff       	call   4730 <fwp_tape_of>
    8f4c:	48 89 c6             	mov    %rax,%rsi
    8f4f:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    8f54:	0f 85 f0 0e 00 00    	jne    9e4a <f12+0x141a>
    8f5a:	48 89 c7             	mov    %rax,%rdi
    8f5d:	e8 2e ad ff ff       	call   3c90 <fwp_tape_unlink_scope>
    8f62:	4c 8b 46 48          	mov    0x48(%rsi),%r8
    8f66:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    8f6b:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    8f72:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    8f76:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    8f7a:	66 49 0f 6e f8       	movq   %r8,%xmm7
    8f7f:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    8f84:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    8f89:	4c 8b 4e 40          	mov    0x40(%rsi),%r9
    8f8d:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    8f91:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    8f97:	77 19                	ja     8fb2 <f12+0x582>
    8f99:	41 0f b7 c4          	movzwl %r12w,%eax
    8f9d:	83 e8 01             	sub    $0x1,%eax
    8fa0:	48 98                	cltq
    8fa2:	48 3b 05 6f b1 01 00 	cmp    0x1b16f(%rip),%rax        # 24118 <fwp_tape_next_slot>
    8fa9:	7d 07                	jge    8fb2 <f12+0x582>
    8fab:	48 89 05 66 b1 01 00 	mov    %rax,0x1b166(%rip)        # 24118 <fwp_tape_next_slot>
    8fb2:	48 8b 05 3f 55 06 00 	mov    0x6553f(%rip),%rax        # 6e4f8 <fwp_cleanups>
    8fb9:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8fbd:	4c 8d a4 24 b0 00 00 	lea    0xb0(%rsp),%r12
    8fc4:	00 
    8fc5:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    8fcc:	00 
    8fcd:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8fd1:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    8fd8:	00 
    8fd9:	48 8d 05 e0 c2 ff ff 	lea    -0x3d20(%rip),%rax        # 52c0 <fwp_tape_buffers_release>
    8fe0:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    8fe7:	00 
    8fe8:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    8fef:	00 
    8ff0:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    8ff4:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    8ff8:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    8fff:	00 
    9000:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    9007:	00 
    9008:	4c 89 8c 24 d0 00 00 	mov    %r9,0xd0(%rsp)
    900f:	00 
    9010:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
    9017:	00 
    9018:	48 89 05 d9 54 06 00 	mov    %rax,0x654d9(%rip)        # 6e4f8 <fwp_cleanups>
    901f:	0f 29 9c 24 b0 00 00 	movaps %xmm3,0xb0(%rsp)
    9026:	00 
    9027:	0f 29 94 24 c0 00 00 	movaps %xmm2,0xc0(%rsp)
    902e:	00 
    902f:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
    9036:	00 
    9037:	4d 85 ed             	test   %r13,%r13
    903a:	0f 88 10 0a 00 00    	js     9a50 <f12+0x1020>
    9040:	4c 89 e8             	mov    %r13,%rax
    9043:	48 c1 f8 20          	sar    $0x20,%rax
    9047:	48 39 c3             	cmp    %rax,%rbx
    904a:	0f 85 43 0d 00 00    	jne    9d93 <f12+0x1363>
    9050:	45 89 eb             	mov    %r13d,%r11d
    9053:	4c 39 da             	cmp    %r11,%rdx
    9056:	0f 8e 43 0d 00 00    	jle    9d9f <f12+0x136f>
    905c:	4d 39 de             	cmp    %r11,%r14
    905f:	0f 8e 4b 09 00 00    	jle    99b0 <f12+0xf80>
    9065:	4d 39 c6             	cmp    %r8,%r14
    9068:	0f 8e aa 0a 00 00    	jle    9b18 <f12+0x10e8>
    906e:	4c 89 f3             	mov    %r14,%rbx
    9071:	4d 85 c0             	test   %r8,%r8
    9074:	4c 0f 44 c3          	cmove  %rbx,%r8
    9078:	eb 1b                	jmp    9095 <f12+0x665>
    907a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9080:	4b 8d 14 00          	lea    (%r8,%r8,1),%rdx
    9084:	49 81 f8 00 00 00 40 	cmp    $0x40000000,%r8
    908b:	48 89 d8             	mov    %rbx,%rax
    908e:	48 0f 4c c2          	cmovl  %rdx,%rax
    9092:	49 89 c0             	mov    %rax,%r8
    9095:	49 39 d8             	cmp    %rbx,%r8
    9098:	7c e6                	jl     9080 <f12+0x650>
    909a:	4d 85 c9             	test   %r9,%r9
    909d:	0f 84 0d 0b 00 00    	je     9bb0 <f12+0x1180>
    90a3:	4a 8d 34 c5 00 00 00 	lea    0x0(,%r8,8),%rsi
    90aa:	00 
    90ab:	4c 89 cf             	mov    %r9,%rdi
    90ae:	ba 03 00 00 00       	mov    $0x3,%edx
    90b3:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    90b8:	0f 29 5c 24 40       	movaps %xmm3,0x40(%rsp)
    90bd:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    90c2:	e8 29 c1 ff ff       	call   51f0 <ad_raw_realloc>
    90c7:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    90cc:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    90d2:	48 85 c0             	test   %rax,%rax
    90d5:	66 0f 6f 5c 24 40    	movdqa 0x40(%rsp),%xmm3
    90db:	49 89 c1             	mov    %rax,%r9
    90de:	0f 84 94 0b 00 00    	je     9c78 <f12+0x1248>
    90e4:	4c 89 8c 24 d0 00 00 	mov    %r9,0xd0(%rsp)
    90eb:	00 
    90ec:	4c 89 84 24 e0 00 00 	mov    %r8,0xe0(%rsp)
    90f3:	00 
    90f4:	48 85 db             	test   %rbx,%rbx
    90f7:	0f 85 44 0c 00 00    	jne    9d41 <f12+0x1311>
    90fd:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    9104:	4d 85 ed             	test   %r13,%r13
    9107:	78 14                	js     911d <f12+0x6ed>
    9109:	45 89 eb             	mov    %r13d,%r11d
    910c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    9111:	f2 43 0f 58 04 d9    	addsd  (%r9,%r11,8),%xmm0
    9117:	f2 43 0f 11 04 d9    	movsd  %xmm0,(%r9,%r11,8)
    911d:	49 39 ce             	cmp    %rcx,%r14
    9120:	0f 8f 93 00 00 00    	jg     91b9 <f12+0x789>
    9126:	0f 12 fb             	movhlps %xmm3,%xmm7
    9129:	66 48 0f 7e db       	movq   %xmm3,%rbx
    912e:	66 49 0f 7e d0       	movq   %xmm2,%r8
    9133:	48 89 c8             	mov    %rcx,%rax
    9136:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    913b:	0f 12 fa             	movhlps %xmm2,%xmm7
    913e:	4b 8d 3c f1          	lea    (%r9,%r14,8),%rdi
    9142:	4c 29 f0             	sub    %r14,%rax
    9145:	66 49 0f 7e fb       	movq   %xmm7,%r11
    914a:	48 29 f3             	sub    %rsi,%rbx
    914d:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9151:	49 8d 14 c3          	lea    (%r11,%rax,8),%rdx
    9155:	4c 29 df             	sub    %r11,%rdi
    9158:	48 8d 04 86          	lea    (%rsi,%rax,4),%rax
    915c:	48 89 d9             	mov    %rbx,%rcx
    915f:	4d 29 d8             	sub    %r11,%r8
    9162:	eb 08                	jmp    916c <f12+0x73c>
    9164:	0f 1f 40 00          	nopl   0x0(%rax)
    9168:	48 83 e8 04          	sub    $0x4,%rax
    916c:	f2 0f 10 04 17       	movsd  (%rdi,%rdx,1),%xmm0
    9171:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    9175:	7a 02                	jp     9179 <f12+0x749>
    9177:	74 37                	je     91b0 <f12+0x780>
    9179:	4c 63 1c 01          	movslq (%rcx,%rax,1),%r11
    917d:	45 85 db             	test   %r11d,%r11d
    9180:	78 16                	js     9198 <f12+0x768>
    9182:	f2 41 0f 10 0c 10    	movsd  (%r8,%rdx,1),%xmm1
    9188:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    918c:	f2 43 0f 58 0c d9    	addsd  (%r9,%r11,8),%xmm1
    9192:	f2 43 0f 11 0c d9    	movsd  %xmm1,(%r9,%r11,8)
    9198:	4c 63 18             	movslq (%rax),%r11
    919b:	45 85 db             	test   %r11d,%r11d
    919e:	78 10                	js     91b0 <f12+0x780>
    91a0:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    91a4:	f2 43 0f 58 04 d9    	addsd  (%r9,%r11,8),%xmm0
    91aa:	f2 43 0f 11 04 d9    	movsd  %xmm0,(%r9,%r11,8)
    91b0:	48 83 ea 08          	sub    $0x8,%rdx
    91b4:	48 39 c6             	cmp    %rax,%rsi
    91b7:	75 af                	jne    9168 <f12+0x738>
    91b9:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    91c0:	ff ff 1f 
    91c3:	4c 39 f0             	cmp    %r14,%rax
    91c6:	0f 82 10 0c 00 00    	jb     9ddc <f12+0x13ac>
    91cc:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    91d3:	00 
    91d4:	be 02 00 00 00       	mov    $0x2,%esi
    91d9:	4c 89 0c 24          	mov    %r9,(%rsp)
    91dd:	e8 8e cd ff ff       	call   5f70 <fwp_heap_alloc>
    91e2:	4c 8b 0c 24          	mov    (%rsp),%r9
    91e6:	4c 89 30             	mov    %r14,(%rax)
    91e9:	49 89 c5             	mov    %rax,%r13
    91ec:	31 c0                	xor    %eax,%eax
    91ee:	4d 85 f6             	test   %r14,%r14
    91f1:	74 1f                	je     9212 <f12+0x7e2>
    91f3:	66 90                	xchg   %ax,%ax
    91f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    91fc:	00 00 00 00 
    9200:	49 8b 14 c1          	mov    (%r9,%rax,8),%rdx
    9204:	49 89 54 c5 08       	mov    %rdx,0x8(%r13,%rax,8)
    9209:	48 83 c0 01          	add    $0x1,%rax
    920d:	49 39 c6             	cmp    %rax,%r14
    9210:	75 ee                	jne    9200 <f12+0x7d0>
    9212:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
    9219:	00 
    921a:	4c 89 e7             	mov    %r12,%rdi
    921d:	48 89 0d d4 52 06 00 	mov    %rcx,0x652d4(%rip)        # 6e4f8 <fwp_cleanups>
    9224:	48 89 0c 24          	mov    %rcx,(%rsp)
    9228:	e8 93 c0 ff ff       	call   52c0 <fwp_tape_buffers_release>
    922d:	48 8b 15 04 4a 06 00 	mov    0x64a04(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    9234:	4c 89 e8             	mov    %r13,%rax
    9237:	48 8b 0c 24          	mov    (%rsp),%rcx
    923b:	48 2b 05 ce 49 06 00 	sub    0x649ce(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    9242:	48 c1 e2 10          	shl    $0x10,%rdx
    9246:	48 39 d0             	cmp    %rdx,%rax
    9249:	73 57                	jae    92a2 <f12+0x872>
    924b:	48 89 c2             	mov    %rax,%rdx
    924e:	48 c1 ea 10          	shr    $0x10,%rdx
    9252:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    9256:	48 8b 15 fb 49 06 00 	mov    0x649fb(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    925d:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    9261:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9265:	48 85 db             	test   %rbx,%rbx
    9268:	74 38                	je     92a2 <f12+0x872>
    926a:	0f b6 32             	movzbl (%rdx),%esi
    926d:	40 80 fe 02          	cmp    $0x2,%sil
    9271:	0f 84 09 08 00 00    	je     9a80 <f12+0x1050>
    9277:	40 80 fe 01          	cmp    $0x1,%sil
    927b:	75 25                	jne    92a2 <f12+0x872>
    927d:	8b 72 18             	mov    0x18(%rdx),%esi
    9280:	0f b7 c0             	movzwl %ax,%eax
    9283:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9286:	48 0f af c6          	imul   %rsi,%rax
    928a:	48 c1 e8 20          	shr    $0x20,%rax
    928e:	48 39 d0             	cmp    %rdx,%rax
    9291:	73 0f                	jae    92a2 <f12+0x872>
    9293:	48 01 c3             	add    %rax,%rbx
    9296:	80 3b ff             	cmpb   $0xff,(%rbx)
    9299:	0f 84 73 0a 00 00    	je     9d12 <f12+0x12e2>
    929f:	c6 03 01             	movb   $0x1,(%rbx)
    92a2:	4c 39 f9             	cmp    %r15,%rcx
    92a5:	0f 85 a0 a4 ff ff    	jne    374b <f12.cold>
    92ab:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    92b0:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    92b5:	48 89 05 3c 52 06 00 	mov    %rax,0x6523c(%rip)        # 6e4f8 <fwp_cleanups>
    92bc:	e8 3f e3 ff ff       	call   7600 <fwp_tape_scope_release>
    92c1:	49 8b 45 00          	mov    0x0(%r13),%rax
    92c5:	49 89 c4             	mov    %rax,%r12
    92c8:	49 0f ba f4 3f       	btr    $0x3f,%r12
    92cd:	48 85 c0             	test   %rax,%rax
    92d0:	0f 88 6a 05 00 00    	js     9840 <f12+0xe10>
    92d6:	48 8b 15 5b 49 06 00 	mov    0x6495b(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    92dd:	4c 89 e8             	mov    %r13,%rax
    92e0:	48 2b 05 29 49 06 00 	sub    0x64929(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    92e7:	48 c1 e2 10          	shl    $0x10,%rdx
    92eb:	48 39 d0             	cmp    %rdx,%rax
    92ee:	0f 83 4c 05 00 00    	jae    9840 <f12+0xe10>
    92f4:	48 89 c2             	mov    %rax,%rdx
    92f7:	48 c1 ea 10          	shr    $0x10,%rdx
    92fb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    92ff:	48 8b 15 52 49 06 00 	mov    0x64952(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    9306:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    930a:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    930e:	48 85 c9             	test   %rcx,%rcx
    9311:	0f 84 29 05 00 00    	je     9840 <f12+0xe10>
    9317:	0f b6 32             	movzbl (%rdx),%esi
    931a:	40 80 fe 02          	cmp    $0x2,%sil
    931e:	0f 84 0c 05 00 00    	je     9830 <f12+0xe00>
    9324:	40 80 fe 01          	cmp    $0x1,%sil
    9328:	0f 85 12 05 00 00    	jne    9840 <f12+0xe10>
    932e:	8b 72 18             	mov    0x18(%rdx),%esi
    9331:	0f b7 c0             	movzwl %ax,%eax
    9334:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9337:	48 0f af c6          	imul   %rsi,%rax
    933b:	48 c1 e8 20          	shr    $0x20,%rax
    933f:	48 39 d0             	cmp    %rdx,%rax
    9342:	0f 83 f8 04 00 00    	jae    9840 <f12+0xe10>
    9348:	48 01 c1             	add    %rax,%rcx
    934b:	80 39 01             	cmpb   $0x1,(%rcx)
    934e:	0f 85 ec 04 00 00    	jne    9840 <f12+0xe10>
    9354:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    9359:	4d 89 ef             	mov    %r13,%r15
    935c:	31 ff                	xor    %edi,%edi
    935e:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    9363:	f2 0f 10 0d 95 7a 00 	movsd  0x7a95(%rip),%xmm1        # 10e00 <msg.8+0xd0>
    936a:	00 
    936b:	48 8d 50 08          	lea    0x8(%rax),%rdx
    936f:	31 c0                	xor    %eax,%eax
    9371:	4d 85 e4             	test   %r12,%r12
    9374:	75 2f                	jne    93a5 <f12+0x975>
    9376:	eb 58                	jmp    93d0 <f12+0x9a0>
    9378:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    937f:	00 
    9380:	49 83 3f 00          	cmpq   $0x0,(%r15)
    9384:	0f 88 21 0a 00 00    	js     9dab <f12+0x137b>
    938a:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    938f:	48 83 c0 01          	add    $0x1,%rax
    9393:	48 83 c2 08          	add    $0x8,%rdx
    9397:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    939b:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    93a0:	49 39 c4             	cmp    %rax,%r12
    93a3:	74 2b                	je     93d0 <f12+0x9a0>
    93a5:	49 8d 4d 08          	lea    0x8(%r13),%rcx
    93a9:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    93ae:	79 d0                	jns    9380 <f12+0x950>
    93b0:	49 8b 4d 10          	mov    0x10(%r13),%rcx
    93b4:	eb ca                	jmp    9380 <f12+0x950>
    93b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    93bd:	00 00 00 
    93c0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    93c4:	0f 84 e3 f8 ff ff    	je     8cad <f12+0x27d>
    93ca:	e9 d0 f8 ff ff       	jmp    8c9f <f12+0x26f>
    93cf:	90                   	nop
    93d0:	e8 eb e7 ff ff       	call   7bc0 <fwp_drop4>
    93d5:	48 89 e8             	mov    %rbp,%rax
    93d8:	31 d2                	xor    %edx,%edx
    93da:	48 85 ed             	test   %rbp,%rbp
    93dd:	0f 84 af 08 00 00    	je     9c92 <f12+0x1262>
    93e3:	66 90                	xchg   %ax,%ax
    93e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    93ec:	00 00 00 00 
    93f0:	48 8b 40 10          	mov    0x10(%rax),%rax
    93f4:	48 83 c2 01          	add    $0x1,%rdx
    93f8:	48 85 c0             	test   %rax,%rax
    93fb:	75 f3                	jne    93f0 <f12+0x9c0>
    93fd:	49 8b 07             	mov    (%r15),%rax
    9400:	49 89 c5             	mov    %rax,%r13
    9403:	49 0f ba f5 3f       	btr    $0x3f,%r13
    9408:	48 85 c0             	test   %rax,%rax
    940b:	0f 88 81 03 00 00    	js     9792 <f12+0xd62>
    9411:	48 8b 05 20 48 06 00 	mov    0x64820(%rip),%rax        # 6dc38 <fwp_heap+0x13d8>
    9418:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    941d:	48 2b 0d ec 47 06 00 	sub    0x647ec(%rip),%rcx        # 6dc10 <fwp_heap+0x13b0>
    9424:	48 c1 e0 10          	shl    $0x10,%rax
    9428:	48 39 c1             	cmp    %rax,%rcx
    942b:	0f 83 61 03 00 00    	jae    9792 <f12+0xd62>
    9431:	48 89 c8             	mov    %rcx,%rax
    9434:	48 c1 e8 10          	shr    $0x10,%rax
    9438:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    943c:	48 8b 05 15 48 06 00 	mov    0x64815(%rip),%rax        # 6dc58 <fwp_heap+0x13f8>
    9443:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    9447:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    944b:	48 85 ff             	test   %rdi,%rdi
    944e:	0f 84 3e 03 00 00    	je     9792 <f12+0xd62>
    9454:	0f b6 06             	movzbl (%rsi),%eax
    9457:	3c 02                	cmp    $0x2,%al
    9459:	0f 84 21 03 00 00    	je     9780 <f12+0xd50>
    945f:	3c 01                	cmp    $0x1,%al
    9461:	0f 85 22 03 00 00    	jne    9789 <f12+0xd59>
    9467:	8b 46 18             	mov    0x18(%rsi),%eax
    946a:	0f b7 c9             	movzwl %cx,%ecx
    946d:	48 0f af c8          	imul   %rax,%rcx
    9471:	8b 46 1c             	mov    0x1c(%rsi),%eax
    9474:	48 c1 e9 20          	shr    $0x20,%rcx
    9478:	48 39 c1             	cmp    %rax,%rcx
    947b:	0f 83 08 03 00 00    	jae    9789 <f12+0xd59>
    9481:	48 01 cf             	add    %rcx,%rdi
    9484:	80 3f 01             	cmpb   $0x1,(%rdi)
    9487:	0f 85 fc 02 00 00    	jne    9789 <f12+0xd59>
    948d:	49 39 d5             	cmp    %rdx,%r13
    9490:	48 89 d0             	mov    %rdx,%rax
    9493:	49 0f 46 c5          	cmovbe %r13,%rax
    9497:	48 85 c0             	test   %rax,%rax
    949a:	0f 84 1c 09 00 00    	je     9dbc <f12+0x138c>
    94a0:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
    94a7:	00 
    94a8:	4d 8d 77 08          	lea    0x8(%r15),%r14
    94ac:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    94b1:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    94b8:	00 
    94b9:	48 89 e9             	mov    %rbp,%rcx
    94bc:	31 d2                	xor    %edx,%edx
    94be:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    94c2:	eb 59                	jmp    951d <f12+0xaed>
    94c4:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    94c9:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    94d0:	00 00 00 00 
    94d4:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    94db:	00 00 00 00 
    94df:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    94e6:	00 00 00 00 
    94ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    94f1:	00 00 00 00 
    94f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    94fc:	00 00 00 00 
    9500:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9505:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    950a:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    9510:	48 83 c2 08          	add    $0x8,%rdx
    9514:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9518:	49 39 d0             	cmp    %rdx,%r8
    951b:	74 1b                	je     9538 <f12+0xb08>
    951d:	48 89 fe             	mov    %rdi,%rsi
    9520:	49 83 3f 00          	cmpq   $0x0,(%r15)
    9524:	79 da                	jns    9500 <f12+0xad0>
    9526:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    952b:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    952f:	eb cf                	jmp    9500 <f12+0xad0>
    9531:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9538:	48 85 ed             	test   %rbp,%rbp
    953b:	0f 84 4a 08 00 00    	je     9d8b <f12+0x135b>
    9541:	4c 8b 05 f0 46 06 00 	mov    0x646f0(%rip),%r8        # 6dc38 <fwp_heap+0x13d8>
    9548:	4c 8b 0d c1 46 06 00 	mov    0x646c1(%rip),%r9        # 6dc10 <fwp_heap+0x13b0>
    954f:	48 89 e9             	mov    %rbp,%rcx
    9552:	45 31 ed             	xor    %r13d,%r13d
    9555:	4c 8b 15 fc 46 06 00 	mov    0x646fc(%rip),%r10        # 6dc58 <fwp_heap+0x13f8>
    955c:	49 c1 e0 10          	shl    $0x10,%r8
    9560:	eb 1c                	jmp    957e <f12+0xb4e>
    9562:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9568:	49 83 c5 01          	add    $0x1,%r13
    956c:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9570:	49 39 c5             	cmp    %rax,%r13
    9573:	0f 83 67 01 00 00    	jae    96e0 <f12+0xcb0>
    9579:	48 85 c9             	test   %rcx,%rcx
    957c:	74 56                	je     95d4 <f12+0xba4>
    957e:	48 89 ca             	mov    %rcx,%rdx
    9581:	4c 29 ca             	sub    %r9,%rdx
    9584:	4c 39 c2             	cmp    %r8,%rdx
    9587:	73 4b                	jae    95d4 <f12+0xba4>
    9589:	48 89 d6             	mov    %rdx,%rsi
    958c:	48 c1 ee 10          	shr    $0x10,%rsi
    9590:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    9594:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    9598:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    959c:	48 85 ff             	test   %rdi,%rdi
    959f:	74 33                	je     95d4 <f12+0xba4>
    95a1:	44 0f b6 1e          	movzbl (%rsi),%r11d
    95a5:	41 80 fb 02          	cmp    $0x2,%r11b
    95a9:	0f 84 19 01 00 00    	je     96c8 <f12+0xc98>
    95af:	41 80 fb 01          	cmp    $0x1,%r11b
    95b3:	75 1f                	jne    95d4 <f12+0xba4>
    95b5:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    95b9:	0f b7 d2             	movzwl %dx,%edx
    95bc:	8b 76 1c             	mov    0x1c(%rsi),%esi
    95bf:	49 0f af d3          	imul   %r11,%rdx
    95c3:	48 c1 ea 20          	shr    $0x20,%rdx
    95c7:	48 39 f2             	cmp    %rsi,%rdx
    95ca:	73 08                	jae    95d4 <f12+0xba4>
    95cc:	48 01 d7             	add    %rdx,%rdi
    95cf:	80 3f 01             	cmpb   $0x1,(%rdi)
    95d2:	74 94                	je     9568 <f12+0xb38>
    95d4:	49 39 c5             	cmp    %rax,%r13
    95d7:	0f 83 03 01 00 00    	jae    96e0 <f12+0xcb0>
    95dd:	49 89 c7             	mov    %rax,%r15
    95e0:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
    95e7:	00 
    95e8:	45 31 e4             	xor    %r12d,%r12d
    95eb:	48 89 04 24          	mov    %rax,(%rsp)
    95ef:	48 8d 1d 6a 32 06 00 	lea    0x6326a(%rip),%rbx        # 6c860 <fwp_heap>
    95f6:	eb 3a                	jmp    9632 <f12+0xc02>
    95f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    95ff:	00 
    9600:	41 80 f9 01          	cmp    $0x1,%r9b
    9604:	75 27                	jne    962d <f12+0xbfd>
    9606:	45 8b 48 18          	mov    0x18(%r8),%r9d
    960a:	0f b7 c0             	movzwl %ax,%eax
    960d:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    9611:	49 0f af c1          	imul   %r9,%rax
    9615:	48 c1 e8 20          	shr    $0x20,%rax
    9619:	4c 39 c0             	cmp    %r8,%rax
    961c:	73 0f                	jae    962d <f12+0xbfd>
    961e:	48 01 c7             	add    %rax,%rdi
    9621:	80 3f ff             	cmpb   $0xff,(%rdi)
    9624:	0f 84 46 03 00 00    	je     9970 <f12+0xf40>
    962a:	c6 07 01             	movb   $0x1,(%rdi)
    962d:	4d 39 fd             	cmp    %r15,%r13
    9630:	73 7e                	jae    96b0 <f12+0xc80>
    9632:	49 83 ef 01          	sub    $0x1,%r15
    9636:	66 49 0f 6e f4       	movq   %r12,%xmm6
    963b:	48 8b 34 24          	mov    (%rsp),%rsi
    963f:	bf 01 00 00 00       	mov    $0x1,%edi
    9644:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    964a:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    964e:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
    9655:	00 
    9656:	e8 f5 d2 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    965b:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    9662:	49 89 c4             	mov    %rax,%r12
    9665:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    966c:	48 c1 e7 10          	shl    $0x10,%rdi
    9670:	48 39 f8             	cmp    %rdi,%rax
    9673:	73 b8                	jae    962d <f12+0xbfd>
    9675:	48 89 c7             	mov    %rax,%rdi
    9678:	48 c1 ef 10          	shr    $0x10,%rdi
    967c:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    9680:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    9687:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    968b:	49 8b 78 20          	mov    0x20(%r8),%rdi
    968f:	48 85 ff             	test   %rdi,%rdi
    9692:	74 99                	je     962d <f12+0xbfd>
    9694:	45 0f b6 08          	movzbl (%r8),%r9d
    9698:	41 80 f9 02          	cmp    $0x2,%r9b
    969c:	0f 85 5e ff ff ff    	jne    9600 <f12+0xbd0>
    96a2:	66 85 c0             	test   %ax,%ax
    96a5:	0f 84 76 ff ff ff    	je     9621 <f12+0xbf1>
    96ab:	4d 39 fd             	cmp    %r15,%r13
    96ae:	72 82                	jb     9632 <f12+0xc02>
    96b0:	4d 85 ed             	test   %r13,%r13
    96b3:	75 2e                	jne    96e3 <f12+0xcb3>
    96b5:	8b 44 24 20          	mov    0x20(%rsp),%eax
    96b9:	85 c0                	test   %eax,%eax
    96bb:	4d 0f 45 f5          	cmovne %r13,%r14
    96bf:	eb 6f                	jmp    9730 <f12+0xd00>
    96c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    96c8:	66 85 d2             	test   %dx,%dx
    96cb:	0f 84 fe fe ff ff    	je     95cf <f12+0xb9f>
    96d1:	49 39 c5             	cmp    %rax,%r13
    96d4:	0f 82 03 ff ff ff    	jb     95dd <f12+0xbad>
    96da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    96e0:	45 31 e4             	xor    %r12d,%r12d
    96e3:	4c 89 f2             	mov    %r14,%rdx
    96e6:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    96ea:	48 89 e8             	mov    %rbp,%rax
    96ed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    96f4:	00 
    96f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    96fc:	00 00 00 00 
    9700:	48 8b 0a             	mov    (%rdx),%rcx
    9703:	48 83 c2 08          	add    $0x8,%rdx
    9707:	48 89 c7             	mov    %rax,%rdi
    970a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    970e:	48 8b 40 10          	mov    0x10(%rax),%rax
    9712:	49 39 d0             	cmp    %rdx,%r8
    9715:	75 e9                	jne    9700 <f12+0xcd0>
    9717:	8b 54 24 20          	mov    0x20(%rsp),%edx
    971b:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    971f:	85 d2                	test   %edx,%edx
    9721:	0f 84 69 03 00 00    	je     9a90 <f12+0x1060>
    9727:	49 89 ec             	mov    %rbp,%r12
    972a:	45 31 f6             	xor    %r14d,%r14d
    972d:	48 89 c5             	mov    %rax,%rbp
    9730:	4c 89 f7             	mov    %r14,%rdi
    9733:	e8 38 c3 ff ff       	call   5a70 <fwp_mem_free>
    9738:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    973d:	e8 7e e4 ff ff       	call   7bc0 <fwp_drop4>
    9742:	48 89 ef             	mov    %rbp,%rdi
    9745:	e8 56 d8 ff ff       	call   6fa0 <fwp_drop0>
    974a:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    9751:	00 
    9752:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9759:	00 00 
    975b:	0f 85 e4 06 00 00    	jne    9e45 <f12+0x1415>
    9761:	48 81 c4 18 01 00 00 	add    $0x118,%rsp
    9768:	4c 89 e0             	mov    %r12,%rax
    976b:	5b                   	pop    %rbx
    976c:	5d                   	pop    %rbp
    976d:	41 5c                	pop    %r12
    976f:	41 5d                	pop    %r13
    9771:	41 5e                	pop    %r14
    9773:	41 5f                	pop    %r15
    9775:	c3                   	ret
    9776:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    977d:	00 00 00 
    9780:	66 85 c9             	test   %cx,%cx
    9783:	0f 84 fb fc ff ff    	je     9484 <f12+0xa54>
    9789:	48 85 ed             	test   %rbp,%rbp
    978c:	0f 84 eb 03 00 00    	je     9b7d <f12+0x114d>
    9792:	48 89 e8             	mov    %rbp,%rax
    9795:	45 31 e4             	xor    %r12d,%r12d
    9798:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    979f:	00 
    97a0:	48 8b 40 10          	mov    0x10(%rax),%rax
    97a4:	4c 89 e2             	mov    %r12,%rdx
    97a7:	49 83 c4 01          	add    $0x1,%r12
    97ab:	48 85 c0             	test   %rax,%rax
    97ae:	75 f0                	jne    97a0 <f12+0xd70>
    97b0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    97b7:	ff ff 1f 
    97ba:	4c 39 e0             	cmp    %r12,%rax
    97bd:	0f 82 0d 06 00 00    	jb     9dd0 <f12+0x13a0>
    97c3:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    97ca:	00 
    97cb:	be 02 00 00 00       	mov    $0x2,%esi
    97d0:	e8 9b c7 ff ff       	call   5f70 <fwp_heap_alloc>
    97d5:	4d 39 e5             	cmp    %r12,%r13
    97d8:	48 89 ea             	mov    %rbp,%rdx
    97db:	49 89 c6             	mov    %rax,%r14
    97de:	4c 89 e0             	mov    %r12,%rax
    97e1:	49 0f 46 c5          	cmovbe %r13,%rax
    97e5:	4c 89 f1             	mov    %r14,%rcx
    97e8:	66 90                	xchg   %ax,%ax
    97ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    97f1:	00 00 00 00 
    97f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    97fc:	00 00 00 00 
    9800:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    9804:	48 83 c1 08          	add    $0x8,%rcx
    9808:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    980c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9810:	48 85 d2             	test   %rdx,%rdx
    9813:	75 eb                	jne    9800 <f12+0xdd0>
    9815:	48 85 c0             	test   %rax,%rax
    9818:	0f 84 71 03 00 00    	je     9b8f <f12+0x115f>
    981e:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
    9825:	00 
    9826:	e9 81 fc ff ff       	jmp    94ac <f12+0xa7c>
    982b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9830:	66 85 c0             	test   %ax,%ax
    9833:	0f 84 12 fb ff ff    	je     934b <f12+0x91b>
    9839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9840:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9847:	ff ff 1f 
    984a:	4c 39 e0             	cmp    %r12,%rax
    984d:	0f 82 89 05 00 00    	jb     9ddc <f12+0x13ac>
    9853:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    985a:	00 
    985b:	be 01 00 00 00       	mov    $0x1,%esi
    9860:	e8 0b c7 ff ff       	call   5f70 <fwp_heap_alloc>
    9865:	4c 89 20             	mov    %r12,(%rax)
    9868:	48 8b 15 c9 43 06 00 	mov    0x643c9(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    986f:	49 89 c7             	mov    %rax,%r15
    9872:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9877:	48 2b 05 92 43 06 00 	sub    0x64392(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    987e:	48 c1 e2 10          	shl    $0x10,%rdx
    9882:	48 39 d0             	cmp    %rdx,%rax
    9885:	73 57                	jae    98de <f12+0xeae>
    9887:	48 89 c2             	mov    %rax,%rdx
    988a:	48 c1 ea 10          	shr    $0x10,%rdx
    988e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9892:	48 8b 15 bf 43 06 00 	mov    0x643bf(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    9899:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    989d:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    98a1:	4d 85 f6             	test   %r14,%r14
    98a4:	74 38                	je     98de <f12+0xeae>
    98a6:	0f b6 0a             	movzbl (%rdx),%ecx
    98a9:	80 f9 02             	cmp    $0x2,%cl
    98ac:	0f 84 ee 02 00 00    	je     9ba0 <f12+0x1170>
    98b2:	80 f9 01             	cmp    $0x1,%cl
    98b5:	75 27                	jne    98de <f12+0xeae>
    98b7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    98ba:	0f b7 c0             	movzwl %ax,%eax
    98bd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    98c0:	48 0f af c1          	imul   %rcx,%rax
    98c4:	48 c1 e8 20          	shr    $0x20,%rax
    98c8:	48 39 d0             	cmp    %rdx,%rax
    98cb:	73 11                	jae    98de <f12+0xeae>
    98cd:	49 01 c6             	add    %rax,%r14
    98d0:	41 80 3e ff          	cmpb   $0xff,(%r14)
    98d4:	0f 84 4d 04 00 00    	je     9d27 <f12+0x12f7>
    98da:	41 c6 06 01          	movb   $0x1,(%r14)
    98de:	4c 89 ef             	mov    %r13,%rdi
    98e1:	e9 78 fa ff ff       	jmp    935e <f12+0x92e>
    98e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    98ed:	00 00 00 
    98f0:	48 c1 e6 10          	shl    $0x10,%rsi
    98f4:	48 09 fe             	or     %rdi,%rsi
    98f7:	bf 08 00 00 00       	mov    $0x8,%edi
    98fc:	49 89 f4             	mov    %rsi,%r12
    98ff:	be 02 00 00 00       	mov    $0x2,%esi
    9904:	e8 67 c6 ff ff       	call   5f70 <fwp_heap_alloc>
    9909:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9910:	48 8b 15 21 43 06 00 	mov    0x64321(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    9917:	48 89 c3             	mov    %rax,%rbx
    991a:	48 2b 05 ef 42 06 00 	sub    0x642ef(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    9921:	48 c1 e2 10          	shl    $0x10,%rdx
    9925:	48 39 d0             	cmp    %rdx,%rax
    9928:	73 76                	jae    99a0 <f12+0xf70>
    992a:	48 89 c2             	mov    %rax,%rdx
    992d:	48 c1 ea 10          	shr    $0x10,%rdx
    9931:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9935:	48 8b 15 1c 43 06 00 	mov    0x6431c(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    993c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    9940:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    9944:	48 85 d2             	test   %rdx,%rdx
    9947:	0f 84 66 f5 ff ff    	je     8eb3 <f12+0x483>
    994d:	0f b6 31             	movzbl (%rcx),%esi
    9950:	45 31 ed             	xor    %r13d,%r13d
    9953:	40 80 fe 02          	cmp    $0x2,%sil
    9957:	0f 85 ae f4 ff ff    	jne    8e0b <f12+0x3db>
    995d:	66 85 c0             	test   %ax,%ax
    9960:	0f 85 d0 f4 ff ff    	jne    8e36 <f12+0x406>
    9966:	e9 bf f4 ff ff       	jmp    8e2a <f12+0x3fa>
    996b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9970:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    9975:	e8 b6 be ff ff       	call   5830 <fwp_rc_forget_slot>
    997a:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    997f:	e9 a6 fc ff ff       	jmp    962a <f12+0xbfa>
    9984:	0f 1f 40 00          	nopl   0x0(%rax)
    9988:	4d 85 ed             	test   %r13,%r13
    998b:	0f 85 aa f4 ff ff    	jne    8e3b <f12+0x40b>
    9991:	0f 1f 40 00          	nopl   0x0(%rax)
    9995:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    999c:	00 00 00 00 
    99a0:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    99a7:	00 
    99a8:	e9 71 f5 ff ff       	jmp    8f1e <f12+0x4ee>
    99ad:	0f 1f 00             	nopl   (%rax)
    99b0:	49 8d 5b 01          	lea    0x1(%r11),%rbx
    99b4:	49 39 d8             	cmp    %rbx,%r8
    99b7:	0f 8c b4 f6 ff ff    	jl     9071 <f12+0x641>
    99bd:	4d 85 c9             	test   %r9,%r9
    99c0:	0f 84 22 04 00 00    	je     9de8 <f12+0x13b8>
    99c6:	4c 89 cf             	mov    %r9,%rdi
    99c9:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    99d0:	00 
    99d1:	31 f6                	xor    %esi,%esi
    99d3:	4c 89 5c 24 40       	mov    %r11,0x40(%rsp)
    99d8:	4c 89 5c 24 50       	mov    %r11,0x50(%rsp)
    99dd:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    99e2:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    99e7:	e8 c4 9a ff ff       	call   34b0 <memset@plt>
    99ec:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    99f2:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    99f8:	4c 8b 5c 24 40       	mov    0x40(%rsp),%r11
    99fd:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    9a02:	49 89 c1             	mov    %rax,%r9
    9a05:	e9 02 f7 ff ff       	jmp    910c <f12+0x6dc>
    9a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9a10:	48 8d 3d c9 da ff ff 	lea    -0x2537(%rip),%rdi        # 74e0 <fwp_tape_finish>
    9a17:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    9a1c:	e8 af 59 00 00       	call   f3d0 <atexit>
    9a21:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    9a26:	85 c0                	test   %eax,%eax
    9a28:	0f 85 d1 03 00 00    	jne    9dff <f12+0x13cf>
    9a2e:	c7 05 48 a6 00 00 01 	movl   $0x1,0xa648(%rip)        # 14080 <registered_finish.0>
    9a35:	00 00 00 
    9a38:	e9 30 f1 ff ff       	jmp    8b6d <f12+0x13d>
    9a3d:	0f 1f 00             	nopl   (%rax)
    9a40:	66 85 c0             	test   %ax,%ax
    9a43:	0f 85 d5 f0 ff ff    	jne    8b1e <f12+0xee>
    9a49:	e9 ac f0 ff ff       	jmp    8afa <f12+0xca>
    9a4e:	66 90                	xchg   %ax,%ax
    9a50:	4d 39 c6             	cmp    %r8,%r14
    9a53:	0f 8f 15 f6 ff ff    	jg     906e <f12+0x63e>
    9a59:	4d 85 f6             	test   %r14,%r14
    9a5c:	74 12                	je     9a70 <f12+0x1040>
    9a5e:	4d 85 c9             	test   %r9,%r9
    9a61:	0f 84 81 03 00 00    	je     9de8 <f12+0x13b8>
    9a67:	4d 85 f6             	test   %r14,%r14
    9a6a:	0f 85 ce 02 00 00    	jne    9d3e <f12+0x130e>
    9a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    9a77:	e9 a1 f6 ff ff       	jmp    911d <f12+0x6ed>
    9a7c:	0f 1f 40 00          	nopl   0x0(%rax)
    9a80:	66 85 c0             	test   %ax,%ax
    9a83:	0f 85 19 f8 ff ff    	jne    92a2 <f12+0x872>
    9a89:	e9 08 f8 ff ff       	jmp    9296 <f12+0x866>
    9a8e:	66 90                	xchg   %ax,%ax
    9a90:	49 89 ec             	mov    %rbp,%r12
    9a93:	48 89 c5             	mov    %rax,%rbp
    9a96:	e9 95 fc ff ff       	jmp    9730 <f12+0xd00>
    9a9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9aa0:	66 0f 6f 0d 38 a6 01 	movdqa 0x1a638(%rip),%xmm1        # 240e0 <fwp_tape_workspace>
    9aa7:	00 
    9aa8:	48 c7 05 15 a6 01 00 	movq   $0x0,0x1a615(%rip)        # 240c8 <fwp_tape_cached_bytes>
    9aaf:	00 00 00 00 
    9ab3:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    9ab9:	48 8b 05 40 a6 01 00 	mov    0x1a640(%rip),%rax        # 24100 <fwp_tape_workspace+0x20>
    9ac0:	66 0f 6f 0d 28 a6 01 	movdqa 0x1a628(%rip),%xmm1        # 240f0 <fwp_tape_workspace+0x10>
    9ac7:	00 
    9ac8:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    9acd:	48 8b 05 34 a6 01 00 	mov    0x1a634(%rip),%rax        # 24108 <fwp_tape_workspace+0x28>
    9ad4:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    9ada:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9ade:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    9ae3:	48 8b 05 26 a6 01 00 	mov    0x1a626(%rip),%rax        # 24110 <fwp_tape_workspace+0x30>
    9aea:	0f 29 0d ef a5 01 00 	movaps %xmm1,0x1a5ef(%rip)        # 240e0 <fwp_tape_workspace>
    9af1:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    9af6:	0f 29 0d f3 a5 01 00 	movaps %xmm1,0x1a5f3(%rip)        # 240f0 <fwp_tape_workspace+0x10>
    9afd:	48 c7 05 08 a6 01 00 	movq   $0x0,0x1a608(%rip)        # 24110 <fwp_tape_workspace+0x30>
    9b04:	00 00 00 00 
    9b08:	0f 29 0d f1 a5 01 00 	movaps %xmm1,0x1a5f1(%rip)        # 24100 <fwp_tape_workspace+0x20>
    9b0f:	e9 99 f1 ff ff       	jmp    8cad <f12+0x27d>
    9b14:	0f 1f 40 00          	nopl   0x0(%rax)
    9b18:	4d 85 c9             	test   %r9,%r9
    9b1b:	0f 84 c7 02 00 00    	je     9de8 <f12+0x13b8>
    9b21:	49 8d 4e ff          	lea    -0x1(%r14),%rcx
    9b25:	4c 89 cf             	mov    %r9,%rdi
    9b28:	31 f6                	xor    %esi,%esi
    9b2a:	4c 89 5c 24 50       	mov    %r11,0x50(%rsp)
    9b2f:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    9b36:	00 
    9b37:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    9b3c:	0f 29 5c 24 40       	movaps %xmm3,0x40(%rsp)
    9b41:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    9b46:	e8 65 99 ff ff       	call   34b0 <memset@plt>
    9b4b:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    9b50:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    9b56:	66 0f 6f 5c 24 40    	movdqa 0x40(%rsp),%xmm3
    9b5c:	4c 8b 5c 24 50       	mov    0x50(%rsp),%r11
    9b61:	49 89 c1             	mov    %rax,%r9
    9b64:	e9 a3 f5 ff ff       	jmp    910c <f12+0x6dc>
    9b69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9b70:	48 83 05 98 49 06 00 	addq   $0x1,0x64998(%rip)        # 6e510 <iteration_retains>
    9b77:	01 
    9b78:	e9 94 ef ff ff       	jmp    8b11 <f12+0xe1>
    9b7d:	be 02 00 00 00       	mov    $0x2,%esi
    9b82:	bf 08 00 00 00       	mov    $0x8,%edi
    9b87:	e8 e4 c3 ff ff       	call   5f70 <fwp_heap_alloc>
    9b8c:	49 89 c6             	mov    %rax,%r14
    9b8f:	45 31 e4             	xor    %r12d,%r12d
    9b92:	e9 99 fb ff ff       	jmp    9730 <f12+0xd00>
    9b97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9b9e:	00 00 
    9ba0:	66 85 c0             	test   %ax,%ax
    9ba3:	0f 85 35 fd ff ff    	jne    98de <f12+0xeae>
    9ba9:	e9 22 fd ff ff       	jmp    98d0 <f12+0xea0>
    9bae:	66 90                	xchg   %ax,%ax
    9bb0:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    9bb7:	ff ff 1f 
    9bba:	49 8d 40 ff          	lea    -0x1(%r8),%rax
    9bbe:	48 39 c2             	cmp    %rax,%rdx
    9bc1:	0f 82 66 02 00 00    	jb     9e2d <f12+0x13fd>
    9bc7:	48 8d 05 32 a6 04 00 	lea    0x4a632(%rip),%rax        # 54200 <ad_raw_blocks>
    9bce:	31 d2                	xor    %edx,%edx
    9bd0:	eb 23                	jmp    9bf5 <f12+0x11c5>
    9bd2:	0f 1f 00             	nopl   (%rax)
    9bd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9bdc:	00 00 00 00 
    9be0:	48 83 c2 01          	add    $0x1,%rdx
    9be4:	48 83 c0 18          	add    $0x18,%rax
    9be8:	48 81 fa 00 10 00 00 	cmp    $0x1000,%rdx
    9bef:	0f 84 8a 01 00 00    	je     9d7f <f12+0x134f>
    9bf5:	48 83 38 00          	cmpq   $0x0,(%rax)
    9bf9:	75 e5                	jne    9be0 <f12+0x11b0>
    9bfb:	4c 89 c7             	mov    %r8,%rdi
    9bfe:	be 08 00 00 00       	mov    $0x8,%esi
    9c03:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    9c08:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    9c0d:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    9c12:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
    9c17:	e8 f4 98 ff ff       	call   3510 <calloc@plt>
    9c1c:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    9c21:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    9c26:	48 8d 0d d3 a5 04 00 	lea    0x4a5d3(%rip),%rcx        # 54200 <ad_raw_blocks>
    9c2d:	48 85 c0             	test   %rax,%rax
    9c30:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
    9c36:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    9c3c:	74 3a                	je     9c78 <f12+0x1248>
    9c3e:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    9c42:	48 89 c6             	mov    %rax,%rsi
    9c45:	4c 89 44 24 30       	mov    %r8,0x30(%rsp)
    9c4a:	48 8d 3c d1          	lea    (%rcx,%rdx,8),%rdi
    9c4e:	b9 03 00 00 00       	mov    $0x3,%ecx
    9c53:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9c58:	4a 8d 14 c5 00 00 00 	lea    0x0(,%r8,8),%rdx
    9c5f:	00 
    9c60:	e8 9b 9f ff ff       	call   3c00 <ad_raw_record>
    9c65:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
    9c6a:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    9c6f:	e9 70 f4 ff ff       	jmp    90e4 <f12+0x6b4>
    9c74:	0f 1f 40 00          	nopl   0x0(%rax)
    9c78:	48 85 db             	test   %rbx,%rbx
    9c7b:	0f 85 67 01 00 00    	jne    9de8 <f12+0x13b8>
    9c81:	45 31 c9             	xor    %r9d,%r9d
    9c84:	e9 74 f4 ff ff       	jmp    90fd <f12+0x6cd>
    9c89:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9c8d:	e9 cd ee ff ff       	jmp    8b5f <f12+0x12f>
    9c92:	49 8b 07             	mov    (%r15),%rax
    9c95:	48 85 c0             	test   %rax,%rax
    9c98:	0f 88 df fe ff ff    	js     9b7d <f12+0x114d>
    9c9e:	48 8b 35 93 3f 06 00 	mov    0x63f93(%rip),%rsi        # 6dc38 <fwp_heap+0x13d8>
    9ca5:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    9caa:	48 2b 0d 5f 3f 06 00 	sub    0x63f5f(%rip),%rcx        # 6dc10 <fwp_heap+0x13b0>
    9cb1:	48 c1 e6 10          	shl    $0x10,%rsi
    9cb5:	48 39 f1             	cmp    %rsi,%rcx
    9cb8:	0f 83 bf fe ff ff    	jae    9b7d <f12+0x114d>
    9cbe:	48 89 ce             	mov    %rcx,%rsi
    9cc1:	48 c1 ee 10          	shr    $0x10,%rsi
    9cc5:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9cc9:	48 8b 35 88 3f 06 00 	mov    0x63f88(%rip),%rsi        # 6dc58 <fwp_heap+0x13f8>
    9cd0:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9cd4:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9cd8:	48 85 ff             	test   %rdi,%rdi
    9cdb:	0f 84 9c fe ff ff    	je     9b7d <f12+0x114d>
    9ce1:	48 0f ba f0 3f       	btr    $0x3f,%rax
    9ce6:	49 89 c5             	mov    %rax,%r13
    9ce9:	e9 66 f7 ff ff       	jmp    9454 <f12+0xa24>
    9cee:	be 68 00 00 00       	mov    $0x68,%esi
    9cf3:	bb 01 00 00 00       	mov    $0x1,%ebx
    9cf8:	e9 ed ee ff ff       	jmp    8bea <f12+0x1ba>
    9cfd:	48 89 d7             	mov    %rdx,%rdi
    9d00:	48 89 14 24          	mov    %rdx,(%rsp)
    9d04:	e8 27 bb ff ff       	call   5830 <fwp_rc_forget_slot>
    9d09:	48 8b 14 24          	mov    (%rsp),%rdx
    9d0d:	e9 21 f1 ff ff       	jmp    8e33 <f12+0x403>
    9d12:	48 89 df             	mov    %rbx,%rdi
    9d15:	48 89 0c 24          	mov    %rcx,(%rsp)
    9d19:	e8 12 bb ff ff       	call   5830 <fwp_rc_forget_slot>
    9d1e:	48 8b 0c 24          	mov    (%rsp),%rcx
    9d22:	e9 78 f5 ff ff       	jmp    929f <f12+0x86f>
    9d27:	4c 89 f7             	mov    %r14,%rdi
    9d2a:	e8 01 bb ff ff       	call   5830 <fwp_rc_forget_slot>
    9d2f:	e9 a6 fb ff ff       	jmp    98da <f12+0xeaa>
    9d34:	e8 d7 b9 ff ff       	call   5710 <fwp_rc_wide_dup>
    9d39:	e9 e0 ed ff ff       	jmp    8b1e <f12+0xee>
    9d3e:	4c 89 f3             	mov    %r14,%rbx
    9d41:	48 8d 4b ff          	lea    -0x1(%rbx),%rcx
    9d45:	4c 89 cf             	mov    %r9,%rdi
    9d48:	31 f6                	xor    %esi,%esi
    9d4a:	0f 29 5c 24 40       	movaps %xmm3,0x40(%rsp)
    9d4f:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    9d56:	00 
    9d57:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    9d5c:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    9d61:	e8 4a 97 ff ff       	call   34b0 <memset@plt>
    9d66:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    9d6b:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    9d71:	66 0f 6f 5c 24 40    	movdqa 0x40(%rsp),%xmm3
    9d77:	49 89 c1             	mov    %rax,%r9
    9d7a:	e9 85 f3 ff ff       	jmp    9104 <f12+0x6d4>
    9d7f:	48 8d 3d 8c 63 00 00 	lea    0x638c(%rip),%rdi        # 10112 <_IO_stdin_used+0x112>
    9d86:	e8 75 a2 ff ff       	call   4000 <ad_raw_fail>
    9d8b:	45 31 ed             	xor    %r13d,%r13d
    9d8e:	e9 4a f8 ff ff       	jmp    95dd <f12+0xbad>
    9d93:	48 8d 3d 6e 6c 00 00 	lea    0x6c6e(%rip),%rdi        # 10a08 <_IO_stdin_used+0xa08>
    9d9a:	e8 b1 a6 ff ff       	call   4450 <fwp_trap>
    9d9f:	48 8d 3d 1c 64 00 00 	lea    0x641c(%rip),%rdi        # 101c2 <_IO_stdin_used+0x1c2>
    9da6:	e8 a5 a6 ff ff       	call   4450 <fwp_trap>
    9dab:	48 8d 3d 5e 6d 00 00 	lea    0x6d5e(%rip),%rdi        # 10b10 <_IO_stdin_used+0xb10>
    9db2:	e8 99 a6 ff ff       	call   4450 <fwp_trap>
    9db7:	e8 44 99 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9dbc:	45 31 f6             	xor    %r14d,%r14d
    9dbf:	e9 cb fd ff ff       	jmp    9b8f <f12+0x115f>
    9dc4:	48 8d 3d 2e 64 00 00 	lea    0x642e(%rip),%rdi        # 101f9 <_IO_stdin_used+0x1f9>
    9dcb:	e8 80 a6 ff ff       	call   4450 <fwp_trap>
    9dd0:	48 8d 3d 14 64 00 00 	lea    0x6414(%rip),%rdi        # 101eb <_IO_stdin_used+0x1eb>
    9dd7:	e8 74 a6 ff ff       	call   4450 <fwp_trap>
    9ddc:	48 8d 3d 4c 64 00 00 	lea    0x644c(%rip),%rdi        # 1022f <_IO_stdin_used+0x22f>
    9de3:	e8 68 a6 ff ff       	call   4450 <fwp_trap>
    9de8:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
    9def:	00 
    9df0:	4c 89 e7             	mov    %r12,%rdi
    9df3:	48 89 05 fe 46 06 00 	mov    %rax,0x646fe(%rip)        # 6e4f8 <fwp_cleanups>
    9dfa:	e8 c1 b4 ff ff       	call   52c0 <fwp_tape_buffers_release>
    9dff:	48 8b 0d 5a a2 00 00 	mov    0xa25a(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    9e06:	ba 13 00 00 00       	mov    $0x13,%edx
    9e0b:	be 01 00 00 00       	mov    $0x1,%esi
    9e10:	48 8d 3d f1 61 00 00 	lea    0x61f1(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    9e17:	e8 44 98 ff ff       	call   3660 <fwrite@plt>
    9e1c:	31 ff                	xor    %edi,%edi
    9e1e:	e8 7d 97 ff ff       	call   35a0 <fflush@plt>
    9e23:	bf 66 00 00 00       	mov    $0x66,%edi
    9e28:	e8 53 98 ff ff       	call   3680 <_Exit@plt>
    9e2d:	48 8d 3d df 63 00 00 	lea    0x63df(%rip),%rdi        # 10213 <_IO_stdin_used+0x213>
    9e34:	e8 c7 a1 ff ff       	call   4000 <ad_raw_fail>
    9e39:	48 8d 3d 70 6c 00 00 	lea    0x6c70(%rip),%rdi        # 10ab0 <_IO_stdin_used+0xab0>
    9e40:	e8 0b a6 ff ff       	call   4450 <fwp_trap>
    9e45:	e8 06 96 ff ff       	call   3450 <__stack_chk_fail@plt>
    9e4a:	48 8d 3d ff 6b 00 00 	lea    0x6bff(%rip),%rdi        # 10a50 <_IO_stdin_used+0xa50>
    9e51:	e8 fa a5 ff ff       	call   4450 <fwp_trap>
    9e56:	48 8d 3d 83 6c 00 00 	lea    0x6c83(%rip),%rdi        # 10ae0 <_IO_stdin_used+0xae0>
    9e5d:	e8 ee a5 ff ff       	call   4450 <fwp_trap>
    9e62:	0f 1f 00             	nopl   (%rax)
    9e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9e6c:	00 00 00 00 

0000000000009e70 <fwp_owned_entry12>:
    9e70:	f3 0f 1e fa          	endbr64
    9e74:	48 8b 3f             	mov    (%rdi),%rdi
    9e77:	e9 b4 eb ff ff       	jmp    8a30 <f12>
    9e7c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009e80 <e12>:
    9e80:	f3 0f 1e fa          	endbr64
    9e84:	53                   	push   %rbx
    9e85:	48 8b 1f             	mov    (%rdi),%rbx
    9e88:	48 89 df             	mov    %rbx,%rdi
    9e8b:	e8 b0 cc ff ff       	call   6b40 <fwp_rc_share>
    9e90:	48 89 df             	mov    %rbx,%rdi
    9e93:	e8 98 eb ff ff       	call   8a30 <f12>
    9e98:	48 89 c3             	mov    %rax,%rbx
    9e9b:	48 89 c7             	mov    %rax,%rdi
    9e9e:	e8 9d cc ff ff       	call   6b40 <fwp_rc_share>
    9ea3:	48 89 d8             	mov    %rbx,%rax
    9ea6:	5b                   	pop    %rbx
    9ea7:	c3                   	ret
    9ea8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9eaf:	00 

0000000000009eb0 <fwp_write>:
    9eb0:	41 57                	push   %r15
    9eb2:	41 56                	push   %r14
    9eb4:	41 55                	push   %r13
    9eb6:	41 54                	push   %r12
    9eb8:	55                   	push   %rbp
    9eb9:	53                   	push   %rbx
    9eba:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9ec1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9ec8:	00 00 
    9eca:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9ed1:	00 
    9ed2:	49 89 d4             	mov    %rdx,%r12
    9ed5:	8b 12                	mov    (%rdx),%edx
    9ed7:	83 fa 19             	cmp    $0x19,%edx
    9eda:	77 6a                	ja     9f46 <fwp_write+0x96>
    9edc:	48 89 f5             	mov    %rsi,%rbp
    9edf:	89 d0                	mov    %edx,%eax
    9ee1:	89 ce                	mov    %ecx,%esi
    9ee3:	48 89 fb             	mov    %rdi,%rbx
    9ee6:	48 8d 0d d3 6d 00 00 	lea    0x6dd3(%rip),%rcx        # 10cc0 <_IO_stdin_used+0xcc0>
    9eed:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9ef1:	48 01 c8             	add    %rcx,%rax
    9ef4:	3e ff e0             	notrack jmp *%rax
    9ef7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9efe:	00 00 
    9f00:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9f04:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9f08:	48 89 ca             	mov    %rcx,%rdx
    9f0b:	48 85 c9             	test   %rcx,%rcx
    9f0e:	0f 88 9c 0c 00 00    	js     abb0 <fwp_write+0xd00>
    9f14:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9f1b:	00 
    9f1c:	48 89 c6             	mov    %rax,%rsi
    9f1f:	4c 89 e7             	mov    %r12,%rdi
    9f22:	e8 19 9b ff ff       	call   3a40 <fwp_fmt_u128>
    9f27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9f2e:	00 00 
    9f30:	4c 89 e7             	mov    %r12,%rdi
    9f33:	e8 08 95 ff ff       	call   3440 <strlen@plt>
    9f38:	4c 89 e6             	mov    %r12,%rsi
    9f3b:	48 89 df             	mov    %rbx,%rdi
    9f3e:	48 89 c2             	mov    %rax,%rdx
    9f41:	e8 aa a1 ff ff       	call   40f0 <buf_put>
    9f46:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9f4d:	00 
    9f4e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9f55:	00 00 
    9f57:	0f 85 28 04 00 00    	jne    a385 <fwp_write+0x4d5>
    9f5d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9f64:	5b                   	pop    %rbx
    9f65:	5d                   	pop    %rbp
    9f66:	41 5c                	pop    %r12
    9f68:	41 5d                	pop    %r13
    9f6a:	41 5e                	pop    %r14
    9f6c:	41 5f                	pop    %r15
    9f6e:	c3                   	ret
    9f6f:	90                   	nop
    9f70:	49 89 e9             	mov    %rbp,%r9
    9f73:	4c 8d 05 e1 62 00 00 	lea    0x62e1(%rip),%r8        # 1025b <_IO_stdin_used+0x25b>
    9f7a:	b9 00 02 00 00       	mov    $0x200,%ecx
    9f7f:	ba 02 00 00 00       	mov    $0x2,%edx
    9f84:	be 00 02 00 00       	mov    $0x200,%esi
    9f89:	31 c0                	xor    %eax,%eax
    9f8b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9f92:	00 
    9f93:	e8 08 94 ff ff       	call   33a0 <__snprintf_chk@plt>
    9f98:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9f9f:	00 
    9fa0:	e8 9b 94 ff ff       	call   3440 <strlen@plt>
    9fa5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9fac:	00 
    9fad:	48 89 df             	mov    %rbx,%rdi
    9fb0:	48 89 c2             	mov    %rax,%rdx
    9fb3:	e8 38 a1 ff ff       	call   40f0 <buf_put>
    9fb8:	eb 8c                	jmp    9f46 <fwp_write+0x96>
    9fba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9fc0:	49 89 e9             	mov    %rbp,%r9
    9fc3:	4c 8d 05 8c 62 00 00 	lea    0x628c(%rip),%r8        # 10256 <_IO_stdin_used+0x256>
    9fca:	eb ae                	jmp    9f7a <fwp_write+0xca>
    9fcc:	0f 1f 40 00          	nopl   0x0(%rax)
    9fd0:	83 fa 13             	cmp    $0x13,%edx
    9fd3:	48 8d 05 72 62 00 00 	lea    0x6272(%rip),%rax        # 1024c <_IO_stdin_used+0x24c>
    9fda:	48 8d 35 70 62 00 00 	lea    0x6270(%rip),%rsi        # 10251 <_IO_stdin_used+0x251>
    9fe1:	ba 04 00 00 00       	mov    $0x4,%edx
    9fe6:	48 0f 44 f0          	cmove  %rax,%rsi
    9fea:	45 31 ed             	xor    %r13d,%r13d
    9fed:	e8 fe a0 ff ff       	call   40f0 <buf_put>
    9ff2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9ff7:	0f 84 a3 08 00 00    	je     a8a0 <fwp_write+0x9f0>
    9ffd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    a002:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    a007:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a00c:	48 89 df             	mov    %rbx,%rdi
    a00f:	49 0f 44 c5          	cmove  %r13,%rax
    a013:	31 c9                	xor    %ecx,%ecx
    a015:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    a01a:	e8 91 fe ff ff       	call   9eb0 <fwp_write>
    a01f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    a024:	0f 84 6e 09 00 00    	je     a998 <fwp_write+0xae8>
    a02a:	49 83 c5 01          	add    $0x1,%r13
    a02e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a032:	0f 83 68 08 00 00    	jae    a8a0 <fwp_write+0x9f0>
    a038:	ba 02 00 00 00       	mov    $0x2,%edx
    a03d:	48 8d 35 57 62 00 00 	lea    0x6257(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a044:	48 89 df             	mov    %rbx,%rdi
    a047:	e8 a4 a0 ff ff       	call   40f0 <buf_put>
    a04c:	eb af                	jmp    9ffd <fwp_write+0x14d>
    a04e:	66 90                	xchg   %ax,%ax
    a050:	ba 06 00 00 00       	mov    $0x6,%edx
    a055:	48 8d 35 18 62 00 00 	lea    0x6218(%rip),%rsi        # 10274 <_IO_stdin_used+0x274>
    a05c:	48 83 c5 10          	add    $0x10,%rbp
    a060:	e8 8b a0 ff ff       	call   40f0 <buf_put>
    a065:	48 89 ef             	mov    %rbp,%rdi
    a068:	e8 d3 93 ff ff       	call   3440 <strlen@plt>
    a06d:	48 89 ee             	mov    %rbp,%rsi
    a070:	48 89 df             	mov    %rbx,%rdi
    a073:	48 89 c2             	mov    %rax,%rdx
    a076:	e8 75 a0 ff ff       	call   40f0 <buf_put>
    a07b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a080:	ba 01 00 00 00       	mov    $0x1,%edx
    a085:	48 89 df             	mov    %rbx,%rdi
    a088:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a08d:	e8 5e a0 ff ff       	call   40f0 <buf_put>
    a092:	e9 af fe ff ff       	jmp    9f46 <fwp_write+0x96>
    a097:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a09e:	00 00 
    a0a0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a0a7:	00 
    a0a8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a0af:	00 00 
    a0b1:	0f 85 ce 02 00 00    	jne    a385 <fwp_write+0x4d5>
    a0b7:	ba 0a 00 00 00       	mov    $0xa,%edx
    a0bc:	48 8d 35 9d 61 00 00 	lea    0x619d(%rip),%rsi        # 10260 <_IO_stdin_used+0x260>
    a0c3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    a0ca:	48 89 df             	mov    %rbx,%rdi
    a0cd:	5b                   	pop    %rbx
    a0ce:	5d                   	pop    %rbp
    a0cf:	41 5c                	pop    %r12
    a0d1:	41 5d                	pop    %r13
    a0d3:	41 5e                	pop    %r14
    a0d5:	41 5f                	pop    %r15
    a0d7:	e9 14 a0 ff ff       	jmp    40f0 <buf_put>
    a0dc:	0f 1f 40 00          	nopl   0x0(%rax)
    a0e0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    a0e5:	4d 85 ed             	test   %r13,%r13
    a0e8:	0f 84 02 0c 00 00    	je     acf0 <fwp_write+0xe40>
    a0ee:	48 8d 35 b3 61 00 00 	lea    0x61b3(%rip),%rsi        # 102a8 <_IO_stdin_used+0x2a8>
    a0f5:	4c 89 ef             	mov    %r13,%rdi
    a0f8:	e8 23 94 ff ff       	call   3520 <strcmp@plt>
    a0fd:	41 89 c1             	mov    %eax,%r9d
    a100:	85 c0                	test   %eax,%eax
    a102:	0f 84 6c 0c 00 00    	je     ad74 <fwp_write+0xec4>
    a108:	4c 89 ef             	mov    %r13,%rdi
    a10b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a110:	e8 2b 93 ff ff       	call   3440 <strlen@plt>
    a115:	4c 89 ee             	mov    %r13,%rsi
    a118:	48 89 df             	mov    %rbx,%rdi
    a11b:	48 89 c2             	mov    %rax,%rdx
    a11e:	e8 cd 9f ff ff       	call   40f0 <buf_put>
    a123:	ba 01 00 00 00       	mov    $0x1,%edx
    a128:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a12d:	48 89 df             	mov    %rbx,%rdi
    a130:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a135:	e8 b6 9f ff ff       	call   40f0 <buf_put>
    a13a:	ba 01 00 00 00       	mov    $0x1,%edx
    a13f:	4c 89 fe             	mov    %r15,%rsi
    a142:	48 89 df             	mov    %rbx,%rdi
    a145:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    a14a:	e8 a1 9f ff ff       	call   40f0 <buf_put>
    a14f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    a154:	45 31 f6             	xor    %r14d,%r14d
    a157:	85 d2                	test   %edx,%edx
    a159:	0f 8e 81 0a 00 00    	jle    abe0 <fwp_write+0xd30>
    a15f:	45 31 ed             	xor    %r13d,%r13d
    a162:	4d 85 ed             	test   %r13,%r13
    a165:	0f 85 75 07 00 00    	jne    a8e0 <fwp_write+0xa30>
    a16b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a172:	00 
    a173:	45 85 f6             	test   %r14d,%r14d
    a176:	0f 84 84 07 00 00    	je     a900 <fwp_write+0xa50>
    a17c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    a181:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    a186:	48 89 df             	mov    %rbx,%rdi
    a189:	49 83 c5 01          	add    $0x1,%r13
    a18d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    a191:	31 c9                	xor    %ecx,%ecx
    a193:	e8 18 fd ff ff       	call   9eb0 <fwp_write>
    a198:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    a19d:	7f c3                	jg     a162 <fwp_write+0x2b2>
    a19f:	45 85 f6             	test   %r14d,%r14d
    a1a2:	0f 84 38 0a 00 00    	je     abe0 <fwp_write+0xd30>
    a1a8:	b8 29 00 00 00       	mov    $0x29,%eax
    a1ad:	ba 01 00 00 00       	mov    $0x1,%edx
    a1b2:	4c 89 fe             	mov    %r15,%rsi
    a1b5:	48 89 df             	mov    %rbx,%rdi
    a1b8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    a1bc:	e8 2f 9f ff ff       	call   40f0 <buf_put>
    a1c1:	e9 80 fd ff ff       	jmp    9f46 <fwp_write+0x96>
    a1c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a1cd:	00 00 00 
    a1d0:	ba 01 00 00 00       	mov    $0x1,%edx
    a1d5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a1da:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    a1df:	e8 0c 9f ff ff       	call   40f0 <buf_put>
    a1e4:	48 85 ed             	test   %rbp,%rbp
    a1e7:	0f 84 93 06 00 00    	je     a880 <fwp_write+0x9d0>
    a1ed:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    a1f1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a1f6:	31 c9                	xor    %ecx,%ecx
    a1f8:	48 89 df             	mov    %rbx,%rdi
    a1fb:	e8 b0 fc ff ff       	call   9eb0 <fwp_write>
    a200:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    a204:	48 85 ed             	test   %rbp,%rbp
    a207:	0f 84 73 06 00 00    	je     a880 <fwp_write+0x9d0>
    a20d:	ba 02 00 00 00       	mov    $0x2,%edx
    a212:	48 8d 35 82 60 00 00 	lea    0x6082(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a219:	48 89 df             	mov    %rbx,%rdi
    a21c:	e8 cf 9e ff ff       	call   40f0 <buf_put>
    a221:	eb ca                	jmp    a1ed <fwp_write+0x33d>
    a223:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a228:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    a22c:	85 f6                	test   %esi,%esi
    a22e:	0f 84 fc 07 00 00    	je     aa30 <fwp_write+0xb80>
    a234:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a23b:	00 
    a23c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a243:	00 00 
    a245:	0f 85 3a 01 00 00    	jne    a385 <fwp_write+0x4d5>
    a24b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    a24f:	4c 89 ea             	mov    %r13,%rdx
    a252:	e9 6c fe ff ff       	jmp    a0c3 <fwp_write+0x213>
    a257:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a25e:	00 00 
    a260:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    a265:	ba 01 00 00 00       	mov    $0x1,%edx
    a26a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    a26f:	48 89 ee             	mov    %rbp,%rsi
    a272:	e8 79 9e ff ff       	call   40f0 <buf_put>
    a277:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    a27c:	4c 89 e7             	mov    %r12,%rdi
    a27f:	e8 bc 91 ff ff       	call   3440 <strlen@plt>
    a284:	4c 89 e6             	mov    %r12,%rsi
    a287:	48 89 df             	mov    %rbx,%rdi
    a28a:	48 89 c2             	mov    %rax,%rdx
    a28d:	e8 5e 9e ff ff       	call   40f0 <buf_put>
    a292:	ba 01 00 00 00       	mov    $0x1,%edx
    a297:	48 89 ee             	mov    %rbp,%rsi
    a29a:	48 89 df             	mov    %rbx,%rdi
    a29d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a2a2:	e8 49 9e ff ff       	call   40f0 <buf_put>
    a2a7:	e9 9a fc ff ff       	jmp    9f46 <fwp_write+0x96>
    a2ac:	0f 1f 40 00          	nopl   0x0(%rax)
    a2b0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    a2b5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    a2b9:	0f 8a 8e 0b 00 00    	jp     ae4d <fwp_write+0xf9d>
    a2bf:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a2c3:	66 0f 54 05 05 6b 00 	andpd  0x6b05(%rip),%xmm0        # 10dd0 <msg.8+0xa0>
    a2ca:	00 
    a2cb:	bd 01 00 00 00       	mov    $0x1,%ebp
    a2d0:	66 0f 2e 05 30 6b 00 	ucomisd 0x6b30(%rip),%xmm0        # 10e08 <msg.8+0xd8>
    a2d7:	00 
    a2d8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a2df:	00 
    a2e0:	0f 87 b2 09 00 00    	ja     ac98 <fwp_write+0xde8>
    a2e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a2ed:	00 00 00 
    a2f0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a2f4:	89 ee                	mov    %ebp,%esi
    a2f6:	4c 89 e7             	mov    %r12,%rdi
    a2f9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    a2fe:	e8 6d a4 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a303:	31 f6                	xor    %esi,%esi
    a305:	4c 89 e7             	mov    %r12,%rdi
    a308:	e8 f3 90 ff ff       	call   3400 <strtod@plt>
    a30d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    a312:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    a316:	7a 06                	jp     a31e <fwp_write+0x46e>
    a318:	0f 84 e9 01 00 00    	je     a507 <fwp_write+0x657>
    a31e:	83 c5 01             	add    $0x1,%ebp
    a321:	83 fd 12             	cmp    $0x12,%ebp
    a324:	75 ca                	jne    a2f0 <fwp_write+0x440>
    a326:	be 11 00 00 00       	mov    $0x11,%esi
    a32b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a32f:	4c 89 e7             	mov    %r12,%rdi
    a332:	e8 39 a4 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a337:	e9 cb 01 00 00       	jmp    a507 <fwp_write+0x657>
    a33c:	0f 1f 40 00          	nopl   0x0(%rax)
    a340:	48 83 fd 01          	cmp    $0x1,%rbp
    a344:	0f 84 e6 08 00 00    	je     ac30 <fwp_write+0xd80>
    a34a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    a34e:	b8 02 00 00 00       	mov    $0x2,%eax
    a353:	ba 01 00 00 00       	mov    $0x1,%edx
    a358:	48 0f 44 d0          	cmove  %rax,%rdx
    a35c:	48 8d 35 e1 5e 00 00 	lea    0x5ee1(%rip),%rsi        # 10244 <_IO_stdin_used+0x244>
    a363:	48 8d 05 df 5e 00 00 	lea    0x5edf(%rip),%rax        # 10249 <_IO_stdin_used+0x249>
    a36a:	48 0f 44 f0          	cmove  %rax,%rsi
    a36e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a375:	00 
    a376:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a37d:	00 00 
    a37f:	0f 84 3e fd ff ff    	je     a0c3 <fwp_write+0x213>
    a385:	e8 c6 90 ff ff       	call   3450 <__stack_chk_fail@plt>
    a38a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a390:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    a395:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    a39a:	e8 91 9c ff ff       	call   4030 <buf_grow>
    a39f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    a3a3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    a3a9:	4c 03 0b             	add    (%rbx),%r9
    a3ac:	66 45 89 11          	mov    %r10w,(%r9)
    a3b0:	45 85 e4             	test   %r12d,%r12d
    a3b3:	0f 8e 07 05 00 00    	jle    a8c0 <fwp_write+0xa10>
    a3b9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    a3c0:	55 55 55 
    a3c3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    a3c8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    a3cf:	aa aa aa 
    a3d2:	49 83 c1 01          	add    $0x1,%r9
    a3d6:	eb 45                	jmp    a41d <fwp_write+0x56d>
    a3d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a3df:	00 
    a3e0:	be 01 00 00 00       	mov    $0x1,%esi
    a3e5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    a3ea:	88 07                	mov    %al,(%rdi)
    a3ec:	48 89 e8             	mov    %rbp,%rax
    a3ef:	49 f7 e8             	imul   %r8
    a3f2:	48 89 e8             	mov    %rbp,%rax
    a3f5:	48 c1 f8 3f          	sar    $0x3f,%rax
    a3f9:	48 29 c2             	sub    %rax,%rdx
    a3fc:	48 85 c9             	test   %rcx,%rcx
    a3ff:	0f 95 c0             	setne  %al
    a402:	48 c1 ed 3f          	shr    $0x3f,%rbp
    a406:	48 83 ef 01          	sub    $0x1,%rdi
    a40a:	48 21 c5             	and    %rax,%rbp
    a40d:	48 29 ea             	sub    %rbp,%rdx
    a410:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    a414:	49 39 f9             	cmp    %rdi,%r9
    a417:	0f 84 a3 04 00 00    	je     a8c0 <fwp_write+0xa10>
    a41d:	48 89 e8             	mov    %rbp,%rax
    a420:	49 f7 e8             	imul   %r8
    a423:	48 89 e8             	mov    %rbp,%rax
    a426:	48 c1 f8 3f          	sar    $0x3f,%rax
    a42a:	48 89 d1             	mov    %rdx,%rcx
    a42d:	48 29 c1             	sub    %rax,%rcx
    a430:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a434:	48 89 e9             	mov    %rbp,%rcx
    a437:	48 29 c1             	sub    %rax,%rcx
    a43a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a43e:	49 f7 e2             	mul    %r10
    a441:	b8 30 00 00 00       	mov    $0x30,%eax
    a446:	48 89 d6             	mov    %rdx,%rsi
    a449:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a44d:	48 d1 ee             	shr    $1,%rsi
    a450:	48 01 f2             	add    %rsi,%rdx
    a453:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a457:	48 29 d6             	sub    %rdx,%rsi
    a45a:	74 8e                	je     a3ea <fwp_write+0x53a>
    a45c:	48 83 fe 01          	cmp    $0x1,%rsi
    a460:	0f 85 7a ff ff ff    	jne    a3e0 <fwp_write+0x530>
    a466:	31 f6                	xor    %esi,%esi
    a468:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a46d:	e9 78 ff ff ff       	jmp    a3ea <fwp_write+0x53a>
    a472:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a478:	66 0f 6e cd          	movd   %ebp,%xmm1
    a47c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a47f:	0f 8a c8 09 00 00    	jp     ae4d <fwp_write+0xf9d>
    a485:	0f 28 c1             	movaps %xmm1,%xmm0
    a488:	0f 54 05 31 69 00 00 	andps  0x6931(%rip),%xmm0        # 10dc0 <msg.8+0x90>
    a48f:	0f 2e 05 6e 5b 00 00 	ucomiss 0x5b6e(%rip),%xmm0        # 10004 <_IO_stdin_used+0x4>
    a496:	0f 87 24 08 00 00    	ja     acc0 <fwp_write+0xe10>
    a49c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a4a0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a4a6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a4ad:	00 
    a4ae:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a4b2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a4b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a4be:	00 00 
    a4c0:	44 89 ee             	mov    %r13d,%esi
    a4c3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a4c8:	4c 89 e7             	mov    %r12,%rdi
    a4cb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a4d0:	e8 9b a2 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a4d5:	31 f6                	xor    %esi,%esi
    a4d7:	4c 89 e7             	mov    %r12,%rdi
    a4da:	e8 c1 8f ff ff       	call   34a0 <strtof@plt>
    a4df:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a4e4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a4e7:	7a 02                	jp     a4eb <fwp_write+0x63b>
    a4e9:	74 1c                	je     a507 <fwp_write+0x657>
    a4eb:	41 83 c5 01          	add    $0x1,%r13d
    a4ef:	41 83 fd 0a          	cmp    $0xa,%r13d
    a4f3:	75 cb                	jne    a4c0 <fwp_write+0x610>
    a4f5:	be 09 00 00 00       	mov    $0x9,%esi
    a4fa:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a4ff:	4c 89 e7             	mov    %r12,%rdi
    a502:	e8 69 a2 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a507:	4c 89 e7             	mov    %r12,%rdi
    a50a:	e8 a1 9c ff ff       	call   41b0 <fwp_finish_float>
    a50f:	e9 1c fa ff ff       	jmp    9f30 <fwp_write+0x80>
    a514:	0f 1f 40 00          	nopl   0x0(%rax)
    a518:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a51c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a520:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a527:	00 
    a528:	48 89 ef             	mov    %rbp,%rdi
    a52b:	e8 10 95 ff ff       	call   3a40 <fwp_fmt_u128>
    a530:	48 89 ef             	mov    %rbp,%rdi
    a533:	e8 08 8f ff ff       	call   3440 <strlen@plt>
    a538:	48 89 ee             	mov    %rbp,%rsi
    a53b:	48 89 df             	mov    %rbx,%rdi
    a53e:	48 89 c2             	mov    %rax,%rdx
    a541:	e8 aa 9b ff ff       	call   40f0 <buf_put>
    a546:	e9 fb f9 ff ff       	jmp    9f46 <fwp_write+0x96>
    a54b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a550:	ba 06 00 00 00       	mov    $0x6,%edx
    a555:	48 8d 35 42 5d 00 00 	lea    0x5d42(%rip),%rsi        # 1029e <_IO_stdin_used+0x29e>
    a55c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a562:	e8 89 9b ff ff       	call   40f0 <buf_put>
    a567:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a56e:	ff ff 7f 
    a571:	48 23 55 00          	and    0x0(%rbp),%rdx
    a575:	0f 84 86 02 00 00    	je     a801 <fwp_write+0x951>
    a57b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a580:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a584:	48 85 d2             	test   %rdx,%rdx
    a587:	0f 84 ae 00 00 00    	je     a63b <fwp_write+0x78b>
    a58d:	8b 0a                	mov    (%rdx),%ecx
    a58f:	83 f9 1c             	cmp    $0x1c,%ecx
    a592:	0f 84 58 06 00 00    	je     abf0 <fwp_write+0xd40>
    a598:	83 f9 1b             	cmp    $0x1b,%ecx
    a59b:	0f 87 9a 00 00 00    	ja     a63b <fwp_write+0x78b>
    a5a1:	be 01 00 00 00       	mov    $0x1,%esi
    a5a6:	48 d3 e6             	shl    %cl,%rsi
    a5a9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a5af:	0f 85 4b 04 00 00    	jne    aa00 <fwp_write+0xb50>
    a5b5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a5bb:	0f 85 0f 04 00 00    	jne    a9d0 <fwp_write+0xb20>
    a5c1:	83 e6 21             	and    $0x21,%esi
    a5c4:	74 75                	je     a63b <fwp_write+0x78b>
    a5c6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a5cb:	48 85 ff             	test   %rdi,%rdi
    a5ce:	79 07                	jns    a5d7 <fwp_write+0x727>
    a5d0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a5d4:	4c 01 ee             	add    %r13,%rsi
    a5d7:	48 0f be 3e          	movsbq (%rsi),%rdi
    a5db:	85 c9                	test   %ecx,%ecx
    a5dd:	40 0f b6 f7          	movzbl %dil,%esi
    a5e1:	48 0f 44 f7          	cmove  %rdi,%rsi
    a5e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a5ec:	00 00 00 00 
    a5f0:	31 c9                	xor    %ecx,%ecx
    a5f2:	48 89 df             	mov    %rbx,%rdi
    a5f5:	49 83 c5 01          	add    $0x1,%r13
    a5f9:	e8 b2 f8 ff ff       	call   9eb0 <fwp_write>
    a5fe:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a605:	ff ff 7f 
    a608:	48 23 55 00          	and    0x0(%rbp),%rdx
    a60c:	49 39 d5             	cmp    %rdx,%r13
    a60f:	0f 83 ec 01 00 00    	jae    a801 <fwp_write+0x951>
    a615:	ba 02 00 00 00       	mov    $0x2,%edx
    a61a:	48 89 df             	mov    %rbx,%rdi
    a61d:	48 8d 35 77 5c 00 00 	lea    0x5c77(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a624:	e8 c7 9a ff ff       	call   40f0 <buf_put>
    a629:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a62e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a632:	48 85 d2             	test   %rdx,%rdx
    a635:	0f 85 52 ff ff ff    	jne    a58d <fwp_write+0x6dd>
    a63b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a640:	48 85 ff             	test   %rdi,%rdi
    a643:	0f 88 cf 05 00 00    	js     ac18 <fwp_write+0xd68>
    a649:	48 8b 31             	mov    (%rcx),%rsi
    a64c:	eb a2                	jmp    a5f0 <fwp_write+0x740>
    a64e:	66 90                	xchg   %ax,%ax
    a650:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a657:	00 
    a658:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a65f:	00 00 
    a661:	0f 85 1e fd ff ff    	jne    a385 <fwp_write+0x4d5>
    a667:	ba 08 00 00 00       	mov    $0x8,%edx
    a66c:	48 8d 35 f8 5b 00 00 	lea    0x5bf8(%rip),%rsi        # 1026b <_IO_stdin_used+0x26b>
    a673:	e9 4b fa ff ff       	jmp    a0c3 <fwp_write+0x213>
    a678:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a67f:	00 
    a680:	89 e8                	mov    %ebp,%eax
    a682:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a689:	76 03                	jbe    a68e <fwp_write+0x7de>
    a68b:	8b 45 00             	mov    0x0(%rbp),%eax
    a68e:	41 89 c6             	mov    %eax,%r14d
    a691:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a696:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a69b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a69f:	4c 89 ef             	mov    %r13,%rdi
    a6a2:	e8 99 8d ff ff       	call   3440 <strlen@plt>
    a6a7:	4c 89 ee             	mov    %r13,%rsi
    a6aa:	48 89 df             	mov    %rbx,%rdi
    a6ad:	48 89 c2             	mov    %rax,%rdx
    a6b0:	e8 3b 9a ff ff       	call   40f0 <buf_put>
    a6b5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a6ba:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a6be:	85 f6                	test   %esi,%esi
    a6c0:	0f 8e 80 f8 ff ff    	jle    9f46 <fwp_write+0x96>
    a6c6:	45 31 ed             	xor    %r13d,%r13d
    a6c9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a6ce:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a6d3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a6d8:	ba 01 00 00 00       	mov    $0x1,%edx
    a6dd:	4c 89 fe             	mov    %r15,%rsi
    a6e0:	48 89 04 24          	mov    %rax,(%rsp)
    a6e4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a6e9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a6ed:	48 89 df             	mov    %rbx,%rdi
    a6f0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a6f4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a6f9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a6fe:	e8 ed 99 ff ff       	call   40f0 <buf_put>
    a703:	41 8b 06             	mov    (%r14),%eax
    a706:	83 f8 0e             	cmp    $0xe,%eax
    a709:	0f 84 71 02 00 00    	je     a980 <fwp_write+0xad0>
    a70f:	83 f8 10             	cmp    $0x10,%eax
    a712:	0f 84 38 02 00 00    	je     a950 <fwp_write+0xaa0>
    a718:	83 f8 0a             	cmp    $0xa,%eax
    a71b:	0f 84 7f 04 00 00    	je     aba0 <fwp_write+0xcf0>
    a721:	0f 8f f9 00 00 00    	jg     a820 <fwp_write+0x970>
    a727:	83 f8 03             	cmp    $0x3,%eax
    a72a:	0f 8f 50 04 00 00    	jg     ab80 <fwp_write+0xcd0>
    a730:	85 c0                	test   %eax,%eax
    a732:	78 10                	js     a744 <fwp_write+0x894>
    a734:	48 8b 04 24          	mov    (%rsp),%rax
    a738:	48 c1 e8 3f          	shr    $0x3f,%rax
    a73c:	85 c0                	test   %eax,%eax
    a73e:	0f 85 f9 00 00 00    	jne    a83d <fwp_write+0x98d>
    a744:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a749:	48 8b 34 24          	mov    (%rsp),%rsi
    a74d:	31 c9                	xor    %ecx,%ecx
    a74f:	48 89 df             	mov    %rbx,%rdi
    a752:	e8 59 f7 ff ff       	call   9eb0 <fwp_write>
    a757:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a75c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a761:	49 83 c5 01          	add    $0x1,%r13
    a765:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a769:	0f 8f 5f ff ff ff    	jg     a6ce <fwp_write+0x81e>
    a76f:	e9 d2 f7 ff ff       	jmp    9f46 <fwp_write+0x96>
    a774:	0f 1f 40 00          	nopl   0x0(%rax)
    a778:	ba 06 00 00 00       	mov    $0x6,%edx
    a77d:	48 8d 35 0d 5b 00 00 	lea    0x5b0d(%rip),%rsi        # 10291 <_IO_stdin_used+0x291>
    a784:	45 31 ed             	xor    %r13d,%r13d
    a787:	e8 64 99 ff ff       	call   40f0 <buf_put>
    a78c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a791:	75 19                	jne    a7ac <fwp_write+0x8fc>
    a793:	eb 6c                	jmp    a801 <fwp_write+0x951>
    a795:	0f 1f 00             	nopl   (%rax)
    a798:	ba 02 00 00 00       	mov    $0x2,%edx
    a79d:	48 8d 35 f7 5a 00 00 	lea    0x5af7(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a7a4:	48 89 df             	mov    %rbx,%rdi
    a7a7:	e8 44 99 ff ff       	call   40f0 <buf_put>
    a7ac:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a7b2:	b9 00 02 00 00       	mov    $0x200,%ecx
    a7b7:	31 c0                	xor    %eax,%eax
    a7b9:	49 83 c5 01          	add    $0x1,%r13
    a7bd:	4c 8d 05 d4 5a 00 00 	lea    0x5ad4(%rip),%r8        # 10298 <_IO_stdin_used+0x298>
    a7c4:	ba 02 00 00 00       	mov    $0x2,%edx
    a7c9:	be 00 02 00 00       	mov    $0x200,%esi
    a7ce:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a7d5:	00 
    a7d6:	e8 c5 8b ff ff       	call   33a0 <__snprintf_chk@plt>
    a7db:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a7e2:	00 
    a7e3:	e8 58 8c ff ff       	call   3440 <strlen@plt>
    a7e8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a7ef:	00 
    a7f0:	48 89 df             	mov    %rbx,%rdi
    a7f3:	48 89 c2             	mov    %rax,%rdx
    a7f6:	e8 f5 98 ff ff       	call   40f0 <buf_put>
    a7fb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a7ff:	72 97                	jb     a798 <fwp_write+0x8e8>
    a801:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a806:	ba 01 00 00 00       	mov    $0x1,%edx
    a80b:	48 89 df             	mov    %rbx,%rdi
    a80e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a813:	e8 d8 98 ff ff       	call   40f0 <buf_put>
    a818:	e9 29 f7 ff ff       	jmp    9f46 <fwp_write+0x96>
    a81d:	0f 1f 00             	nopl   (%rax)
    a820:	83 f8 0b             	cmp    $0xb,%eax
    a823:	0f 85 1b ff ff ff    	jne    a744 <fwp_write+0x894>
    a829:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a82e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a832:	83 e0 01             	and    $0x1,%eax
    a835:	85 c0                	test   %eax,%eax
    a837:	0f 84 07 ff ff ff    	je     a744 <fwp_write+0x894>
    a83d:	4c 89 fe             	mov    %r15,%rsi
    a840:	48 89 df             	mov    %rbx,%rdi
    a843:	ba 01 00 00 00       	mov    $0x1,%edx
    a848:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a84d:	e8 9e 98 ff ff       	call   40f0 <buf_put>
    a852:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a857:	48 8b 34 24          	mov    (%rsp),%rsi
    a85b:	31 c9                	xor    %ecx,%ecx
    a85d:	48 89 df             	mov    %rbx,%rdi
    a860:	e8 4b f6 ff ff       	call   9eb0 <fwp_write>
    a865:	ba 01 00 00 00       	mov    $0x1,%edx
    a86a:	4c 89 fe             	mov    %r15,%rsi
    a86d:	48 89 df             	mov    %rbx,%rdi
    a870:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a875:	e8 76 98 ff ff       	call   40f0 <buf_put>
    a87a:	e9 d8 fe ff ff       	jmp    a757 <fwp_write+0x8a7>
    a87f:	90                   	nop
    a880:	ba 01 00 00 00       	mov    $0x1,%edx
    a885:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a88a:	48 89 df             	mov    %rbx,%rdi
    a88d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a892:	e8 59 98 ff ff       	call   40f0 <buf_put>
    a897:	e9 aa f6 ff ff       	jmp    9f46 <fwp_write+0x96>
    a89c:	0f 1f 40 00          	nopl   0x0(%rax)
    a8a0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a8a5:	ba 01 00 00 00       	mov    $0x1,%edx
    a8aa:	48 89 df             	mov    %rbx,%rdi
    a8ad:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a8b2:	e8 39 98 ff ff       	call   40f0 <buf_put>
    a8b7:	e9 8a f6 ff ff       	jmp    9f46 <fwp_write+0x96>
    a8bc:	0f 1f 40 00          	nopl   0x0(%rax)
    a8c0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a8c4:	48 8b 13             	mov    (%rbx),%rdx
    a8c7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a8cc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a8d0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a8d4:	e9 6d f6 ff ff       	jmp    9f46 <fwp_write+0x96>
    a8d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a8e0:	ba 02 00 00 00       	mov    $0x2,%edx
    a8e5:	48 8d 35 af 59 00 00 	lea    0x59af(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a8ec:	48 89 df             	mov    %rbx,%rdi
    a8ef:	e8 fc 97 ff ff       	call   40f0 <buf_put>
    a8f4:	e9 72 f8 ff ff       	jmp    a16b <fwp_write+0x2bb>
    a8f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a900:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a905:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a90a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a90e:	48 89 f7             	mov    %rsi,%rdi
    a911:	48 89 34 24          	mov    %rsi,(%rsp)
    a915:	e8 26 8b ff ff       	call   3440 <strlen@plt>
    a91a:	48 8b 34 24          	mov    (%rsp),%rsi
    a91e:	48 89 df             	mov    %rbx,%rdi
    a921:	48 89 c2             	mov    %rax,%rdx
    a924:	e8 c7 97 ff ff       	call   40f0 <buf_put>
    a929:	ba 03 00 00 00       	mov    $0x3,%edx
    a92e:	48 8d 35 89 59 00 00 	lea    0x5989(%rip),%rsi        # 102be <_IO_stdin_used+0x2be>
    a935:	48 89 df             	mov    %rbx,%rdi
    a938:	e8 b3 97 ff ff       	call   40f0 <buf_put>
    a93d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a942:	e9 35 f8 ff ff       	jmp    a17c <fwp_write+0x2cc>
    a947:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a94e:	00 00 
    a950:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a955:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a959:	48 85 ff             	test   %rdi,%rdi
    a95c:	0f 84 e2 fd ff ff    	je     a744 <fwp_write+0x894>
    a962:	48 8d 35 3f 59 00 00 	lea    0x593f(%rip),%rsi        # 102a8 <_IO_stdin_used+0x2a8>
    a969:	e8 b2 8b ff ff       	call   3520 <strcmp@plt>
    a96e:	85 c0                	test   %eax,%eax
    a970:	0f 95 c0             	setne  %al
    a973:	0f b6 c0             	movzbl %al,%eax
    a976:	e9 c1 fd ff ff       	jmp    a73c <fwp_write+0x88c>
    a97b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a980:	31 c0                	xor    %eax,%eax
    a982:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a989:	00 
    a98a:	0f 97 c0             	seta   %al
    a98d:	e9 aa fd ff ff       	jmp    a73c <fwp_write+0x88c>
    a992:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a998:	48 89 df             	mov    %rbx,%rdi
    a99b:	ba 02 00 00 00       	mov    $0x2,%edx
    a9a0:	48 8d 35 fe 58 00 00 	lea    0x58fe(%rip),%rsi        # 102a5 <_IO_stdin_used+0x2a5>
    a9a7:	e8 44 97 ff ff       	call   40f0 <buf_put>
    a9ac:	4c 89 e8             	mov    %r13,%rax
    a9af:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a9b4:	31 c9                	xor    %ecx,%ecx
    a9b6:	48 c1 e0 04          	shl    $0x4,%rax
    a9ba:	48 89 df             	mov    %rbx,%rdi
    a9bd:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a9c2:	e8 e9 f4 ff ff       	call   9eb0 <fwp_write>
    a9c7:	e9 5e f6 ff ff       	jmp    a02a <fwp_write+0x17a>
    a9cc:	0f 1f 40 00          	nopl   0x0(%rax)
    a9d0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a9d5:	48 85 ff             	test   %rdi,%rdi
    a9d8:	79 0c                	jns    a9e6 <fwp_write+0xb36>
    a9da:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a9e1:	00 
    a9e2:	48 03 75 10          	add    0x10(%rbp),%rsi
    a9e6:	48 63 3e             	movslq (%rsi),%rdi
    a9e9:	83 f9 02             	cmp    $0x2,%ecx
    a9ec:	89 fe                	mov    %edi,%esi
    a9ee:	48 0f 44 f7          	cmove  %rdi,%rsi
    a9f2:	e9 f9 fb ff ff       	jmp    a5f0 <fwp_write+0x740>
    a9f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a9fe:	00 00 
    aa00:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    aa05:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    aa0a:	48 85 ff             	test   %rdi,%rdi
    aa0d:	0f 88 0f 03 00 00    	js     ad22 <fwp_write+0xe72>
    aa13:	49 0f bf 38          	movswq (%r8),%rdi
    aa17:	83 f9 01             	cmp    $0x1,%ecx
    aa1a:	0f b7 f7             	movzwl %di,%esi
    aa1d:	48 0f 44 f7          	cmove  %rdi,%rsi
    aa21:	e9 ca fb ff ff       	jmp    a5f0 <fwp_write+0x740>
    aa26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aa2d:	00 00 00 
    aa30:	ba 01 00 00 00       	mov    $0x1,%edx
    aa35:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    aa3a:	48 83 c5 08          	add    $0x8,%rbp
    aa3e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    aa43:	e8 a8 96 ff ff       	call   40f0 <buf_put>
    aa48:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    aa4d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    aa52:	4d 85 ed             	test   %r13,%r13
    aa55:	75 46                	jne    aa9d <fwp_write+0xbed>
    aa57:	e9 04 01 00 00       	jmp    ab60 <fwp_write+0xcb0>
    aa5c:	0f 1f 40 00          	nopl   0x0(%rax)
    aa60:	41 80 f9 09          	cmp    $0x9,%r9b
    aa64:	0f 84 d6 00 00 00    	je     ab40 <fwp_write+0xc90>
    aa6a:	41 80 f9 0a          	cmp    $0xa,%r9b
    aa6e:	0f 85 9c 00 00 00    	jne    ab10 <fwp_write+0xc60>
    aa74:	ba 02 00 00 00       	mov    $0x2,%edx
    aa79:	48 8d 35 01 58 00 00 	lea    0x5801(%rip),%rsi        # 10281 <_IO_stdin_used+0x281>
    aa80:	48 89 df             	mov    %rbx,%rdi
    aa83:	e8 68 96 ff ff       	call   40f0 <buf_put>
    aa88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    aa8f:	00 
    aa90:	48 83 c5 01          	add    $0x1,%rbp
    aa94:	49 39 ec             	cmp    %rbp,%r12
    aa97:	0f 84 c3 00 00 00    	je     ab60 <fwp_write+0xcb0>
    aa9d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    aaa2:	41 80 f9 0d          	cmp    $0xd,%r9b
    aaa6:	74 28                	je     aad0 <fwp_write+0xc20>
    aaa8:	7e b6                	jle    aa60 <fwp_write+0xbb0>
    aaaa:	41 80 f9 22          	cmp    $0x22,%r9b
    aaae:	74 40                	je     aaf0 <fwp_write+0xc40>
    aab0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    aab4:	75 5a                	jne    ab10 <fwp_write+0xc60>
    aab6:	ba 02 00 00 00       	mov    $0x2,%edx
    aabb:	48 8d 35 bc 57 00 00 	lea    0x57bc(%rip),%rsi        # 1027e <_IO_stdin_used+0x27e>
    aac2:	48 89 df             	mov    %rbx,%rdi
    aac5:	e8 26 96 ff ff       	call   40f0 <buf_put>
    aaca:	eb c4                	jmp    aa90 <fwp_write+0xbe0>
    aacc:	0f 1f 40 00          	nopl   0x0(%rax)
    aad0:	ba 02 00 00 00       	mov    $0x2,%edx
    aad5:	48 8d 35 ab 57 00 00 	lea    0x57ab(%rip),%rsi        # 10287 <_IO_stdin_used+0x287>
    aadc:	48 89 df             	mov    %rbx,%rdi
    aadf:	e8 0c 96 ff ff       	call   40f0 <buf_put>
    aae4:	eb aa                	jmp    aa90 <fwp_write+0xbe0>
    aae6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aaed:	00 00 00 
    aaf0:	ba 02 00 00 00       	mov    $0x2,%edx
    aaf5:	48 8d 35 7f 57 00 00 	lea    0x577f(%rip),%rsi        # 1027b <_IO_stdin_used+0x27b>
    aafc:	48 89 df             	mov    %rbx,%rdi
    aaff:	e8 ec 95 ff ff       	call   40f0 <buf_put>
    ab04:	eb 8a                	jmp    aa90 <fwp_write+0xbe0>
    ab06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ab0d:	00 00 00 
    ab10:	41 80 f9 1f          	cmp    $0x1f,%r9b
    ab14:	0f 86 2e 01 00 00    	jbe    ac48 <fwp_write+0xd98>
    ab1a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    ab1e:	0f 84 24 01 00 00    	je     ac48 <fwp_write+0xd98>
    ab24:	ba 01 00 00 00       	mov    $0x1,%edx
    ab29:	4c 89 fe             	mov    %r15,%rsi
    ab2c:	48 89 df             	mov    %rbx,%rdi
    ab2f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    ab34:	e8 b7 95 ff ff       	call   40f0 <buf_put>
    ab39:	e9 52 ff ff ff       	jmp    aa90 <fwp_write+0xbe0>
    ab3e:	66 90                	xchg   %ax,%ax
    ab40:	ba 02 00 00 00       	mov    $0x2,%edx
    ab45:	48 8d 35 38 57 00 00 	lea    0x5738(%rip),%rsi        # 10284 <_IO_stdin_used+0x284>
    ab4c:	48 89 df             	mov    %rbx,%rdi
    ab4f:	e8 9c 95 ff ff       	call   40f0 <buf_put>
    ab54:	e9 37 ff ff ff       	jmp    aa90 <fwp_write+0xbe0>
    ab59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab60:	ba 01 00 00 00       	mov    $0x1,%edx
    ab65:	4c 89 fe             	mov    %r15,%rsi
    ab68:	48 89 df             	mov    %rbx,%rdi
    ab6b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    ab70:	e8 7b 95 ff ff       	call   40f0 <buf_put>
    ab75:	e9 cc f3 ff ff       	jmp    9f46 <fwp_write+0x96>
    ab7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ab80:	83 f8 04             	cmp    $0x4,%eax
    ab83:	0f 85 bb fb ff ff    	jne    a744 <fwp_write+0x894>
    ab89:	48 8b 04 24          	mov    (%rsp),%rax
    ab8d:	48 8b 40 08          	mov    0x8(%rax),%rax
    ab91:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    ab96:	48 c1 e8 3f          	shr    $0x3f,%rax
    ab9a:	e9 96 fc ff ff       	jmp    a835 <fwp_write+0x985>
    ab9f:	90                   	nop
    aba0:	8b 0c 24             	mov    (%rsp),%ecx
    aba3:	31 c0                	xor    %eax,%eax
    aba5:	85 c9                	test   %ecx,%ecx
    aba7:	0f 98 c0             	sets   %al
    abaa:	e9 86 fc ff ff       	jmp    a835 <fwp_write+0x985>
    abaf:	90                   	nop
    abb0:	48 f7 d8             	neg    %rax
    abb3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    abba:	00 
    abbb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    abc2:	2d 
    abc3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    abca:	00 
    abcb:	48 83 d2 00          	adc    $0x0,%rdx
    abcf:	48 89 c6             	mov    %rax,%rsi
    abd2:	48 f7 da             	neg    %rdx
    abd5:	e8 66 8e ff ff       	call   3a40 <fwp_fmt_u128>
    abda:	e9 51 f3 ff ff       	jmp    9f30 <fwp_write+0x80>
    abdf:	90                   	nop
    abe0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    abe5:	e9 c3 f5 ff ff       	jmp    a1ad <fwp_write+0x2fd>
    abea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    abf0:	4c 89 e9             	mov    %r13,%rcx
    abf3:	48 c1 e1 04          	shl    $0x4,%rcx
    abf7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    abfc:	48 85 ff             	test   %rdi,%rdi
    abff:	0f 89 eb f9 ff ff    	jns    a5f0 <fwp_write+0x740>
    ac05:	48 03 4d 10          	add    0x10(%rbp),%rcx
    ac09:	48 89 ce             	mov    %rcx,%rsi
    ac0c:	e9 df f9 ff ff       	jmp    a5f0 <fwp_write+0x740>
    ac11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ac18:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    ac1f:	00 
    ac20:	48 03 4d 10          	add    0x10(%rbp),%rcx
    ac24:	e9 20 fa ff ff       	jmp    a649 <fwp_write+0x799>
    ac29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ac30:	ba 02 00 00 00       	mov    $0x2,%edx
    ac35:	48 8d 35 0a 56 00 00 	lea    0x560a(%rip),%rsi        # 10246 <_IO_stdin_used+0x246>
    ac3c:	e9 2d f7 ff ff       	jmp    a36e <fwp_write+0x4be>
    ac41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ac48:	4c 8d 05 3b 56 00 00 	lea    0x563b(%rip),%r8        # 1028a <_IO_stdin_used+0x28a>
    ac4f:	b9 10 00 00 00       	mov    $0x10,%ecx
    ac54:	31 c0                	xor    %eax,%eax
    ac56:	ba 02 00 00 00       	mov    $0x2,%edx
    ac5b:	be 10 00 00 00       	mov    $0x10,%esi
    ac60:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    ac67:	00 
    ac68:	e8 33 87 ff ff       	call   33a0 <__snprintf_chk@plt>
    ac6d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    ac74:	00 
    ac75:	e8 c6 87 ff ff       	call   3440 <strlen@plt>
    ac7a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    ac81:	00 
    ac82:	48 89 df             	mov    %rbx,%rdi
    ac85:	48 89 c2             	mov    %rax,%rdx
    ac88:	e8 63 94 ff ff       	call   40f0 <buf_put>
    ac8d:	e9 fe fd ff ff       	jmp    aa90 <fwp_write+0xbe0>
    ac92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ac98:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ac9c:	48 8d 35 9d 55 00 00 	lea    0x559d(%rip),%rsi        # 10240 <_IO_stdin_used+0x240>
    aca3:	48 8d 05 95 55 00 00 	lea    0x5595(%rip),%rax        # 1023f <_IO_stdin_used+0x23f>
    acaa:	4c 89 e7             	mov    %r12,%rdi
    acad:	66 0f 2f c8          	comisd %xmm0,%xmm1
    acb1:	48 0f 46 f0          	cmovbe %rax,%rsi
    acb5:	e8 26 87 ff ff       	call   33e0 <strcpy@plt>
    acba:	e9 71 f2 ff ff       	jmp    9f30 <fwp_write+0x80>
    acbf:	90                   	nop
    acc0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    acc4:	48 8d 35 75 55 00 00 	lea    0x5575(%rip),%rsi        # 10240 <_IO_stdin_used+0x240>
    accb:	48 8d 05 6d 55 00 00 	lea    0x556d(%rip),%rax        # 1023f <_IO_stdin_used+0x23f>
    acd2:	0f 2f c8             	comiss %xmm0,%xmm1
    acd5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    acdc:	00 
    acdd:	4c 89 e7             	mov    %r12,%rdi
    ace0:	48 0f 46 f0          	cmovbe %rax,%rsi
    ace4:	e8 f7 86 ff ff       	call   33e0 <strcpy@plt>
    ace9:	e9 42 f2 ff ff       	jmp    9f30 <fwp_write+0x80>
    acee:	66 90                	xchg   %ax,%ax
    acf0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    acf5:	45 85 c0             	test   %r8d,%r8d
    acf8:	75 34                	jne    ad2e <fwp_write+0xe7e>
    acfa:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    ad01:	00 
    ad02:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    ad09:	00 00 
    ad0b:	0f 85 74 f6 ff ff    	jne    a385 <fwp_write+0x4d5>
    ad11:	ba 02 00 00 00       	mov    $0x2,%edx
    ad16:	48 8d 35 9e 55 00 00 	lea    0x559e(%rip),%rsi        # 102bb <_IO_stdin_used+0x2bb>
    ad1d:	e9 a1 f3 ff ff       	jmp    a0c3 <fwp_write+0x213>
    ad22:	48 03 75 10          	add    0x10(%rbp),%rsi
    ad26:	49 89 f0             	mov    %rsi,%r8
    ad29:	e9 e5 fc ff ff       	jmp    aa13 <fwp_write+0xb63>
    ad2e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    ad33:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ad38:	85 ff                	test   %edi,%edi
    ad3a:	0f 84 fa f3 ff ff    	je     a13a <fwp_write+0x28a>
    ad40:	ba 01 00 00 00       	mov    $0x1,%edx
    ad45:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    ad4a:	48 89 df             	mov    %rbx,%rdi
    ad4d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    ad52:	e8 99 93 ff ff       	call   40f0 <buf_put>
    ad57:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    ad5c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ad61:	41 be 01 00 00 00    	mov    $0x1,%r14d
    ad67:	85 c0                	test   %eax,%eax
    ad69:	0f 8f f0 f3 ff ff    	jg     a15f <fwp_write+0x2af>
    ad6f:	e9 34 f4 ff ff       	jmp    a1a8 <fwp_write+0x2f8>
    ad74:	48 8b 45 08          	mov    0x8(%rbp),%rax
    ad78:	49 89 c5             	mov    %rax,%r13
    ad7b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ad80:	49 89 c4             	mov    %rax,%r12
    ad83:	49 c1 fd 3f          	sar    $0x3f,%r13
    ad87:	4c 09 e8             	or     %r13,%rax
    ad8a:	0f 84 a7 00 00 00    	je     ae37 <fwp_write+0xf87>
    ad90:	48 8d 2d 89 76 00 00 	lea    0x7689(%rip),%rbp        # 12420 <units.5>
    ad97:	4d 89 e7             	mov    %r12,%r15
    ad9a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    ad9e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    ada3:	4c 89 ff             	mov    %r15,%rdi
    ada6:	4c 89 ee             	mov    %r13,%rsi
    ada9:	44 89 0c 24          	mov    %r9d,(%rsp)
    adad:	48 99                	cqto
    adaf:	48 89 d1             	mov    %rdx,%rcx
    adb2:	48 89 c2             	mov    %rax,%rdx
    adb5:	e8 06 44 00 00       	call   f1c0 <__divmodti4>
    adba:	44 8b 0c 24          	mov    (%rsp),%r9d
    adbe:	48 89 c1             	mov    %rax,%rcx
    adc1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    adc6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    adcb:	0f 84 94 00 00 00    	je     ae65 <fwp_write+0xfb5>
    add1:	41 83 c1 01          	add    $0x1,%r9d
    add5:	48 83 c5 10          	add    $0x10,%rbp
    add9:	41 83 f9 05          	cmp    $0x5,%r9d
    addd:	75 bb                	jne    ad9a <fwp_write+0xeea>
    addf:	4d 85 ed             	test   %r13,%r13
    ade2:	79 53                	jns    ae37 <fwp_write+0xf87>
    ade4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    ade9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    adee:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    adf3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    adf8:	48 99                	cqto
    adfa:	48 f7 d8             	neg    %rax
    adfd:	48 83 d2 00          	adc    $0x0,%rdx
    ae01:	48 89 c6             	mov    %rax,%rsi
    ae04:	48 f7 da             	neg    %rdx
    ae07:	e8 34 8c ff ff       	call   3a40 <fwp_fmt_u128>
    ae0c:	49 89 e8             	mov    %rbp,%r8
    ae0f:	ba 00 02 00 00       	mov    $0x200,%edx
    ae14:	be 02 00 00 00       	mov    $0x2,%esi
    ae19:	31 c0                	xor    %eax,%eax
    ae1b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ae22:	00 
    ae23:	48 8d 0d 8c 54 00 00 	lea    0x548c(%rip),%rcx        # 102b6 <_IO_stdin_used+0x2b6>
    ae2a:	4c 89 e7             	mov    %r12,%rdi
    ae2d:	e8 8e 88 ff ff       	call   36c0 <__sprintf_chk@plt>
    ae32:	e9 f9 f0 ff ff       	jmp    9f30 <fwp_write+0x80>
    ae37:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ae3c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    ae41:	31 d2                	xor    %edx,%edx
    ae43:	48 89 ef             	mov    %rbp,%rdi
    ae46:	e8 f5 8b ff ff       	call   3a40 <fwp_fmt_u128>
    ae4b:	eb bf                	jmp    ae0c <fwp_write+0xf5c>
    ae4d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    ae54:	4e 61 4e 00 
    ae58:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ae5f:	00 
    ae60:	e9 cb f0 ff ff       	jmp    9f30 <fwp_write+0x80>
    ae65:	44 89 0c 24          	mov    %r9d,(%rsp)
    ae69:	48 89 c8             	mov    %rcx,%rax
    ae6c:	48 85 d2             	test   %rdx,%rdx
    ae6f:	78 51                	js     aec2 <fwp_write+0x1012>
    ae71:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ae76:	48 89 c6             	mov    %rax,%rsi
    ae79:	48 89 ef             	mov    %rbp,%rdi
    ae7c:	e8 bf 8b ff ff       	call   3a40 <fwp_fmt_u128>
    ae81:	44 8b 0c 24          	mov    (%rsp),%r9d
    ae85:	49 63 c1             	movslq %r9d,%rax
    ae88:	49 89 e8             	mov    %rbp,%r8
    ae8b:	ba 00 02 00 00       	mov    $0x200,%edx
    ae90:	be 02 00 00 00       	mov    $0x2,%esi
    ae95:	48 c1 e0 04          	shl    $0x4,%rax
    ae99:	48 8d 3d 80 75 00 00 	lea    0x7580(%rip),%rdi        # 12420 <units.5>
    aea0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    aea7:	00 
    aea8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    aeac:	48 8d 0d fe 53 00 00 	lea    0x53fe(%rip),%rcx        # 102b1 <_IO_stdin_used+0x2b1>
    aeb3:	4c 89 e7             	mov    %r12,%rdi
    aeb6:	31 c0                	xor    %eax,%eax
    aeb8:	e8 03 88 ff ff       	call   36c0 <__sprintf_chk@plt>
    aebd:	e9 6e f0 ff ff       	jmp    9f30 <fwp_write+0x80>
    aec2:	48 f7 d8             	neg    %rax
    aec5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    aeca:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    aecf:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    aed4:	48 83 d2 00          	adc    $0x0,%rdx
    aed8:	48 89 c6             	mov    %rax,%rsi
    aedb:	48 f7 da             	neg    %rdx
    aede:	e8 5d 8b ff ff       	call   3a40 <fwp_fmt_u128>
    aee3:	44 8b 0c 24          	mov    (%rsp),%r9d
    aee7:	eb 9c                	jmp    ae85 <fwp_write+0xfd5>
    aee9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000aef0 <fwp_hof0.constprop.0>:
    aef0:	55                   	push   %rbp
    aef1:	48 89 e5             	mov    %rsp,%rbp
    aef4:	41 57                	push   %r15
    aef6:	41 56                	push   %r14
    aef8:	41 55                	push   %r13
    aefa:	41 54                	push   %r12
    aefc:	53                   	push   %rbx
    aefd:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    af04:	48 89 bd 58 ff ff ff 	mov    %rdi,-0xa8(%rbp)
    af0b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    af12:	00 00 
    af14:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    af18:	31 c0                	xor    %eax,%eax
    af1a:	48 85 f6             	test   %rsi,%rsi
    af1d:	0f 84 bc 06 00 00    	je     b5df <fwp_hof0.constprop.0+0x6ef>
    af23:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
    af27:	49 89 f7             	mov    %rsi,%r15
    af2a:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
    af31:	48 8d 35 28 19 06 00 	lea    0x61928(%rip),%rsi        # 6c860 <fwp_heap>
    af38:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    af3f:	48 8b be d8 13 00 00 	mov    0x13d8(%rsi),%rdi
    af46:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    af4d:	48 89 fa             	mov    %rdi,%rdx
    af50:	48 89 7d a8          	mov    %rdi,-0x58(%rbp)
    af54:	48 c1 e2 10          	shl    $0x10,%rdx
    af58:	48 39 d0             	cmp    %rdx,%rax
    af5b:	73 6b                	jae    afc8 <fwp_hof0.constprop.0+0xd8>
    af5d:	48 89 c2             	mov    %rax,%rdx
    af60:	48 c1 ea 10          	shr    $0x10,%rdx
    af64:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    af68:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    af6f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    af73:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    af77:	48 85 ff             	test   %rdi,%rdi
    af7a:	74 4c                	je     afc8 <fwp_hof0.constprop.0+0xd8>
    af7c:	0f b6 0a             	movzbl (%rdx),%ecx
    af7f:	80 f9 02             	cmp    $0x2,%cl
    af82:	0f 84 01 0c 00 00    	je     bb89 <fwp_hof0.constprop.0+0xc99>
    af88:	80 f9 01             	cmp    $0x1,%cl
    af8b:	75 3b                	jne    afc8 <fwp_hof0.constprop.0+0xd8>
    af8d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    af90:	0f b7 c0             	movzwl %ax,%eax
    af93:	8b 52 1c             	mov    0x1c(%rdx),%edx
    af96:	48 0f af c1          	imul   %rcx,%rax
    af9a:	48 c1 e8 20          	shr    $0x20,%rax
    af9e:	48 39 d0             	cmp    %rdx,%rax
    afa1:	73 25                	jae    afc8 <fwp_hof0.constprop.0+0xd8>
    afa3:	48 01 c7             	add    %rax,%rdi
    afa6:	0f b6 07             	movzbl (%rdi),%eax
    afa9:	84 c0                	test   %al,%al
    afab:	74 1b                	je     afc8 <fwp_hof0.constprop.0+0xd8>
    afad:	8b 35 75 35 06 00    	mov    0x63575(%rip),%esi        # 6e528 <iteration_active>
    afb3:	85 f6                	test   %esi,%esi
    afb5:	0f 85 dc 0b 00 00    	jne    bb97 <fwp_hof0.constprop.0+0xca7>
    afbb:	3c fd                	cmp    $0xfd,%al
    afbd:	0f 87 bd 0c 00 00    	ja     bc80 <fwp_hof0.constprop.0+0xd90>
    afc3:	83 c0 01             	add    $0x1,%eax
    afc6:	88 07                	mov    %al,(%rdi)
    afc8:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    afcf:	4c 89 bd 50 ff ff ff 	mov    %r15,-0xb0(%rbp)
    afd6:	48 c7 85 60 ff ff ff 	movq   $0xc7,-0xa0(%rbp)
    afdd:	c7 00 00 00 
    afe1:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    afe5:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    afe9:	48 8b 15 c8 34 06 00 	mov    0x634c8(%rip),%rdx        # 6e4b8 <fwp_fns>
    aff0:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
    aff4:	48 8d 05 1d 90 00 00 	lea    0x901d(%rip),%rax        # 14018 <fc12>
    affb:	44 8b 20             	mov    (%rax),%r12d
    affe:	49 c1 e4 05          	shl    $0x5,%r12
    b002:	49 01 d4             	add    %rdx,%r12
    b005:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
    b00a:	48 85 c9             	test   %rcx,%rcx
    b00d:	0f 84 43 0b 00 00    	je     bb56 <fwp_hof0.constprop.0+0xc66>
    b013:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    b018:	0f 84 1a 09 00 00    	je     b938 <fwp_hof0.constprop.0+0xa48>
    b01e:	48 8d 1d 3b 18 06 00 	lea    0x6183b(%rip),%rbx        # 6c860 <fwp_heap>
    b025:	48 8d 05 ec 8f 00 00 	lea    0x8fec(%rip),%rax        # 14018 <fc12>
    b02c:	48 8b b3 d8 13 00 00 	mov    0x13d8(%rbx),%rsi
    b033:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    b03a:	48 89 f1             	mov    %rsi,%rcx
    b03d:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
    b041:	48 c1 e1 10          	shl    $0x10,%rcx
    b045:	48 39 c8             	cmp    %rcx,%rax
    b048:	73 71                	jae    b0bb <fwp_hof0.constprop.0+0x1cb>
    b04a:	48 89 c1             	mov    %rax,%rcx
    b04d:	48 c1 e9 10          	shr    $0x10,%rcx
    b051:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b055:	48 8b 8b f8 13 00 00 	mov    0x13f8(%rbx),%rcx
    b05c:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b060:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    b064:	48 85 ff             	test   %rdi,%rdi
    b067:	74 52                	je     b0bb <fwp_hof0.constprop.0+0x1cb>
    b069:	0f b6 31             	movzbl (%rcx),%esi
    b06c:	40 80 fe 02          	cmp    $0x2,%sil
    b070:	0f 84 dd 09 00 00    	je     ba53 <fwp_hof0.constprop.0+0xb63>
    b076:	40 80 fe 01          	cmp    $0x1,%sil
    b07a:	75 3f                	jne    b0bb <fwp_hof0.constprop.0+0x1cb>
    b07c:	8b 71 18             	mov    0x18(%rcx),%esi
    b07f:	0f b7 c0             	movzwl %ax,%eax
    b082:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b085:	48 0f af c6          	imul   %rsi,%rax
    b089:	48 c1 e8 20          	shr    $0x20,%rax
    b08d:	48 39 c8             	cmp    %rcx,%rax
    b090:	73 29                	jae    b0bb <fwp_hof0.constprop.0+0x1cb>
    b092:	48 01 c7             	add    %rax,%rdi
    b095:	0f b6 07             	movzbl (%rdi),%eax
    b098:	84 c0                	test   %al,%al
    b09a:	74 1f                	je     b0bb <fwp_hof0.constprop.0+0x1cb>
    b09c:	8b 0d 86 34 06 00    	mov    0x63486(%rip),%ecx        # 6e528 <iteration_active>
    b0a2:	85 c9                	test   %ecx,%ecx
    b0a4:	74 08                	je     b0ae <fwp_hof0.constprop.0+0x1be>
    b0a6:	48 83 05 62 34 06 00 	addq   $0x1,0x63462(%rip)        # 6e510 <iteration_retains>
    b0ad:	01 
    b0ae:	3c fd                	cmp    $0xfd,%al
    b0b0:	0f 87 7a 0a 00 00    	ja     bb30 <fwp_hof0.constprop.0+0xc40>
    b0b6:	83 c0 01             	add    $0x1,%eax
    b0b9:	88 07                	mov    %al,(%rdi)
    b0bb:	48 8d 05 56 8f 00 00 	lea    0x8f56(%rip),%rax        # 14018 <fc12>
    b0c2:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    b0c9:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b0cd:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    b0d4:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b0d8:	48 8d 05 39 8f 00 00 	lea    0x8f39(%rip),%rax        # 14018 <fc12>
    b0df:	41 8b 0c 24          	mov    (%r12),%ecx
    b0e3:	2b 48 04             	sub    0x4(%rax),%ecx
    b0e6:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b0ea:	44 8b 6d 94          	mov    -0x6c(%rbp),%r13d
    b0ee:	89 4d 90             	mov    %ecx,-0x70(%rbp)
    b0f1:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    b0f5:	49 89 c1             	mov    %rax,%r9
    b0f8:	8b 00                	mov    (%rax),%eax
    b0fa:	44 39 e9             	cmp    %r13d,%ecx
    b0fd:	44 0f 46 e9          	cmovbe %ecx,%r13d
    b101:	4c 89 cb             	mov    %r9,%rbx
    b104:	48 c1 e0 05          	shl    $0x5,%rax
    b108:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    b10c:	44 89 ad 7c ff ff ff 	mov    %r13d,-0x84(%rbp)
    b113:	4d 8b 50 18          	mov    0x18(%r8),%r10
    b117:	4d 85 d2             	test   %r10,%r10
    b11a:	75 5c                	jne    b178 <fwp_hof0.constprop.0+0x288>
    b11c:	e9 02 02 00 00       	jmp    b323 <fwp_hof0.constprop.0+0x433>
    b121:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b128:	85 db                	test   %ebx,%ebx
    b12a:	74 6a                	je     b196 <fwp_hof0.constprop.0+0x2a6>
    b12c:	4c 89 e7             	mov    %r12,%rdi
    b12f:	41 ff 12             	call   *(%r10)
    b132:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b136:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
    b13a:	e8 51 c1 ff ff       	call   7290 <fwp_closure_drop>
    b13f:	45 39 ee             	cmp    %r13d,%r14d
    b142:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    b146:	0f 84 dc 07 00 00    	je     b928 <fwp_hof0.constprop.0+0xa38>
    b14c:	44 8b 00             	mov    (%rax),%r8d
    b14f:	41 29 df             	sub    %ebx,%r15d
    b152:	4f 8d 24 f4          	lea    (%r12,%r14,8),%r12
    b156:	49 89 c1             	mov    %rax,%r9
    b159:	45 89 fd             	mov    %r15d,%r13d
    b15c:	49 c1 e0 05          	shl    $0x5,%r8
    b160:	4c 03 05 51 33 06 00 	add    0x63351(%rip),%r8        # 6e4b8 <fwp_fns>
    b167:	4d 8b 50 18          	mov    0x18(%r8),%r10
    b16b:	4d 85 d2             	test   %r10,%r10
    b16e:	0f 84 ac 01 00 00    	je     b320 <fwp_hof0.constprop.0+0x430>
    b174:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b178:	41 8b 49 04          	mov    0x4(%r9),%ecx
    b17c:	41 8b 18             	mov    (%r8),%ebx
    b17f:	46 8d 3c 29          	lea    (%rcx,%r13,1),%r15d
    b183:	41 39 df             	cmp    %ebx,%r15d
    b186:	0f 82 7c 04 00 00    	jb     b608 <fwp_hof0.constprop.0+0x718>
    b18c:	41 89 de             	mov    %ebx,%r14d
    b18f:	41 29 ce             	sub    %ecx,%r14d
    b192:	85 c9                	test   %ecx,%ecx
    b194:	74 92                	je     b128 <fwp_hof0.constprop.0+0x238>
    b196:	85 db                	test   %ebx,%ebx
    b198:	b8 01 00 00 00       	mov    $0x1,%eax
    b19d:	48 89 e6             	mov    %rsp,%rsi
    b1a0:	48 89 65 a0          	mov    %rsp,-0x60(%rbp)
    b1a4:	0f 45 c3             	cmovne %ebx,%eax
    b1a7:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    b1ae:	00 
    b1af:	48 c1 e8 04          	shr    $0x4,%rax
    b1b3:	48 c1 e0 04          	shl    $0x4,%rax
    b1b7:	48 89 c7             	mov    %rax,%rdi
    b1ba:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    b1c1:	48 29 fe             	sub    %rdi,%rsi
    b1c4:	48 39 f4             	cmp    %rsi,%rsp
    b1c7:	74 15                	je     b1de <fwp_hof0.constprop.0+0x2ee>
    b1c9:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    b1d0:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    b1d7:	00 00 
    b1d9:	48 39 f4             	cmp    %rsi,%rsp
    b1dc:	75 eb                	jne    b1c9 <fwp_hof0.constprop.0+0x2d9>
    b1de:	25 ff 0f 00 00       	and    $0xfff,%eax
    b1e3:	48 29 c4             	sub    %rax,%rsp
    b1e6:	48 85 c0             	test   %rax,%rax
    b1e9:	74 06                	je     b1f1 <fwp_hof0.constprop.0+0x301>
    b1eb:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    b1f1:	89 cf                	mov    %ecx,%edi
    b1f3:	49 89 e3             	mov    %rsp,%r11
    b1f6:	31 c0                	xor    %eax,%eax
    b1f8:	48 c1 e7 03          	shl    $0x3,%rdi
    b1fc:	85 c9                	test   %ecx,%ecx
    b1fe:	74 12                	je     b212 <fwp_hof0.constprop.0+0x322>
    b200:	49 8b 54 01 08       	mov    0x8(%r9,%rax,1),%rdx
    b205:	49 89 14 03          	mov    %rdx,(%r11,%rax,1)
    b209:	48 83 c0 08          	add    $0x8,%rax
    b20d:	48 39 c7             	cmp    %rax,%rdi
    b210:	75 ee                	jne    b200 <fwp_hof0.constprop.0+0x310>
    b212:	45 85 f6             	test   %r14d,%r14d
    b215:	74 3e                	je     b255 <fwp_hof0.constprop.0+0x365>
    b217:	44 89 f6             	mov    %r14d,%esi
    b21a:	4c 89 e0             	mov    %r12,%rax
    b21d:	49 8d 3c f4          	lea    (%r12,%rsi,8),%rdi
    b221:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b228:	00 00 
    b22a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b231:	00 00 00 00 
    b235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b23c:	00 00 00 00 
    b240:	48 8b 30             	mov    (%rax),%rsi
    b243:	89 ca                	mov    %ecx,%edx
    b245:	48 83 c0 08          	add    $0x8,%rax
    b249:	83 c1 01             	add    $0x1,%ecx
    b24c:	49 89 34 d3          	mov    %rsi,(%r11,%rdx,8)
    b250:	48 39 c7             	cmp    %rax,%rdi
    b253:	75 eb                	jne    b240 <fwp_hof0.constprop.0+0x350>
    b255:	48 8d 15 04 16 06 00 	lea    0x61604(%rip),%rdx        # 6c860 <fwp_heap>
    b25c:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b260:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    b267:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    b26e:	48 89 f1             	mov    %rsi,%rcx
    b271:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
    b275:	48 c1 e1 10          	shl    $0x10,%rcx
    b279:	48 39 c8             	cmp    %rcx,%rax
    b27c:	73 4c                	jae    b2ca <fwp_hof0.constprop.0+0x3da>
    b27e:	48 89 c1             	mov    %rax,%rcx
    b281:	48 c1 e9 10          	shr    $0x10,%rcx
    b285:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b289:	48 8b 0d c8 29 06 00 	mov    0x629c8(%rip),%rcx        # 6dc58 <fwp_heap+0x13f8>
    b290:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b294:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    b298:	48 85 f6             	test   %rsi,%rsi
    b29b:	74 2d                	je     b2ca <fwp_hof0.constprop.0+0x3da>
    b29d:	0f b6 39             	movzbl (%rcx),%edi
    b2a0:	40 80 ff 02          	cmp    $0x2,%dil
    b2a4:	74 6a                	je     b310 <fwp_hof0.constprop.0+0x420>
    b2a6:	40 80 ff 01          	cmp    $0x1,%dil
    b2aa:	75 1e                	jne    b2ca <fwp_hof0.constprop.0+0x3da>
    b2ac:	8b 79 18             	mov    0x18(%rcx),%edi
    b2af:	0f b7 c0             	movzwl %ax,%eax
    b2b2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b2b5:	48 0f af c7          	imul   %rdi,%rax
    b2b9:	48 c1 e8 20          	shr    $0x20,%rax
    b2bd:	48 39 c8             	cmp    %rcx,%rax
    b2c0:	73 08                	jae    b2ca <fwp_hof0.constprop.0+0x3da>
    b2c2:	48 01 c6             	add    %rax,%rsi
    b2c5:	80 3e 01             	cmpb   $0x1,(%rsi)
    b2c8:	74 36                	je     b300 <fwp_hof0.constprop.0+0x410>
    b2ca:	4c 89 45 80          	mov    %r8,-0x80(%rbp)
    b2ce:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b2d2:	be 01 00 00 00       	mov    $0x1,%esi
    b2d7:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
    b2db:	41 ff 52 08          	call   *0x8(%r10)
    b2df:	4c 8b 5d 98          	mov    -0x68(%rbp),%r11
    b2e3:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
    b2e7:	49 8b 40 18          	mov    0x18(%r8),%rax
    b2eb:	4c 89 df             	mov    %r11,%rdi
    b2ee:	ff 10                	call   *(%rax)
    b2f0:	48 8b 65 a0          	mov    -0x60(%rbp),%rsp
    b2f4:	e9 39 fe ff ff       	jmp    b132 <fwp_hof0.constprop.0+0x242>
    b2f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b300:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    b307:	00 
    b308:	eb dd                	jmp    b2e7 <fwp_hof0.constprop.0+0x3f7>
    b30a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b310:	66 85 c0             	test   %ax,%ax
    b313:	75 b5                	jne    b2ca <fwp_hof0.constprop.0+0x3da>
    b315:	eb ae                	jmp    b2c5 <fwp_hof0.constprop.0+0x3d5>
    b317:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b31e:	00 00 
    b320:	48 89 c3             	mov    %rax,%rbx
    b323:	48 89 df             	mov    %rbx,%rdi
    b326:	e8 15 b8 ff ff       	call   6b40 <fwp_rc_share>
    b32b:	45 85 ed             	test   %r13d,%r13d
    b32e:	74 21                	je     b351 <fwp_hof0.constprop.0+0x461>
    b330:	44 89 ea             	mov    %r13d,%edx
    b333:	4d 89 e7             	mov    %r12,%r15
    b336:	4d 8d 34 d4          	lea    (%r12,%rdx,8),%r14
    b33a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b340:	49 8b 3f             	mov    (%r15),%rdi
    b343:	49 83 c7 08          	add    $0x8,%r15
    b347:	e8 f4 b7 ff ff       	call   6b40 <fwp_rc_share>
    b34c:	4d 39 f7             	cmp    %r14,%r15
    b34f:	75 ef                	jne    b340 <fwp_hof0.constprop.0+0x450>
    b351:	4c 89 e2             	mov    %r12,%rdx
    b354:	44 89 ee             	mov    %r13d,%esi
    b357:	48 89 df             	mov    %rbx,%rdi
    b35a:	e8 01 ae ff ff       	call   6160 <fwp_apply>
    b35f:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b363:	8b 75 94             	mov    -0x6c(%rbp),%esi
    b366:	39 75 90             	cmp    %esi,-0x70(%rbp)
    b369:	0f 83 87 00 00 00    	jae    b3f6 <fwp_hof0.constprop.0+0x506>
    b36f:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    b375:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    b379:	48 89 c3             	mov    %rax,%rbx
    b37c:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    b380:	48 8b 15 31 31 06 00 	mov    0x63131(%rip),%rdx        # 6e4b8 <fwp_fns>
    b387:	29 de                	sub    %ebx,%esi
    b389:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b38d:	89 75 94             	mov    %esi,-0x6c(%rbp)
    b390:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    b394:	44 8b 26             	mov    (%rsi),%r12d
    b397:	48 89 f0             	mov    %rsi,%rax
    b39a:	49 c1 e4 05          	shl    $0x5,%r12
    b39e:	49 01 d4             	add    %rdx,%r12
    b3a1:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
    b3a7:	0f 85 32 fd ff ff    	jne    b0df <fwp_hof0.constprop.0+0x1ef>
    b3ad:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b3b1:	e8 8a b7 ff ff       	call   6b40 <fwp_rc_share>
    b3b6:	44 8b 75 94          	mov    -0x6c(%rbp),%r14d
    b3ba:	45 85 f6             	test   %r14d,%r14d
    b3bd:	74 23                	je     b3e2 <fwp_hof0.constprop.0+0x4f2>
    b3bf:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    b3c3:	31 db                	xor    %ebx,%ebx
    b3c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b3cc:	00 00 00 00 
    b3d0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b3d4:	48 83 c3 01          	add    $0x1,%rbx
    b3d8:	e8 63 b7 ff ff       	call   6b40 <fwp_rc_share>
    b3dd:	44 39 f3             	cmp    %r14d,%ebx
    b3e0:	72 ee                	jb     b3d0 <fwp_hof0.constprop.0+0x4e0>
    b3e2:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    b3e6:	8b 75 94             	mov    -0x6c(%rbp),%esi
    b3e9:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b3ed:	e8 6e ad ff ff       	call   6160 <fwp_apply>
    b3f2:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b3f6:	48 83 ad 60 ff ff ff 	subq   $0x1,-0xa0(%rbp)
    b3fd:	01 
    b3fe:	0f 85 e1 fb ff ff    	jne    afe5 <fwp_hof0.constprop.0+0xf5>
    b404:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    b408:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    b40f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b413:	b9 01 00 00 00       	mov    $0x1,%ecx
    b418:	48 8d 15 81 87 00 00 	lea    0x8781(%rip),%rdx        # 13ba0 <d0>
    b41f:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
    b426:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
    b42d:	00 
    b42e:	0f 29 45 b0          	movaps %xmm0,-0x50(%rbp)
    b432:	e8 79 ea ff ff       	call   9eb0 <fwp_write>
    b437:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
    b43b:	4c 8b 75 b8          	mov    -0x48(%rbp),%r14
    b43f:	48 8d 05 26 4c 00 00 	lea    0x4c26(%rip),%rax        # 1006c <_IO_stdin_used+0x6c>
    b446:	48 85 c9             	test   %rcx,%rcx
    b449:	48 0f 44 c8          	cmove  %rax,%rcx
    b44d:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    b451:	0f 87 15 08 00 00    	ja     bc6c <fwp_hof0.constprop.0+0xd7c>
    b457:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    b45b:	be 01 00 00 00       	mov    $0x1,%esi
    b460:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    b464:	e8 07 ab ff ff       	call   5f70 <fwp_heap_alloc>
    b469:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
    b46d:	4c 89 f2             	mov    %r14,%rdx
    b470:	4c 89 30             	mov    %r14,(%rax)
    b473:	4c 8d 60 08          	lea    0x8(%rax),%r12
    b477:	48 89 c3             	mov    %rax,%rbx
    b47a:	4c 89 e7             	mov    %r12,%rdi
    b47d:	e8 fe 80 ff ff       	call   3580 <memcpy@plt>
    b482:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    b488:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
    b48c:	e8 1f 7f ff ff       	call   33b0 <free@plt>
    b491:	48 8d 35 c8 13 06 00 	lea    0x613c8(%rip),%rsi        # 6c860 <fwp_heap>
    b498:	48 89 d8             	mov    %rbx,%rax
    b49b:	48 8b be d8 13 00 00 	mov    0x13d8(%rsi),%rdi
    b4a2:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b4a9:	48 89 fa             	mov    %rdi,%rdx
    b4ac:	48 89 7d a0          	mov    %rdi,-0x60(%rbp)
    b4b0:	48 c1 e2 10          	shl    $0x10,%rdx
    b4b4:	48 39 d0             	cmp    %rdx,%rax
    b4b7:	73 57                	jae    b510 <fwp_hof0.constprop.0+0x620>
    b4b9:	48 89 c2             	mov    %rax,%rdx
    b4bc:	48 c1 ea 10          	shr    $0x10,%rdx
    b4c0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b4c4:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b4cb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b4cf:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b4d3:	4d 85 f6             	test   %r14,%r14
    b4d6:	74 38                	je     b510 <fwp_hof0.constprop.0+0x620>
    b4d8:	0f b6 0a             	movzbl (%rdx),%ecx
    b4db:	80 f9 02             	cmp    $0x2,%cl
    b4de:	0f 84 da 06 00 00    	je     bbbe <fwp_hof0.constprop.0+0xcce>
    b4e4:	80 f9 01             	cmp    $0x1,%cl
    b4e7:	75 27                	jne    b510 <fwp_hof0.constprop.0+0x620>
    b4e9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b4ec:	0f b7 c0             	movzwl %ax,%eax
    b4ef:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b4f2:	48 0f af c1          	imul   %rcx,%rax
    b4f6:	48 c1 e8 20          	shr    $0x20,%rax
    b4fa:	48 39 d0             	cmp    %rdx,%rax
    b4fd:	73 11                	jae    b510 <fwp_hof0.constprop.0+0x620>
    b4ff:	49 01 c6             	add    %rax,%r14
    b502:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b506:	0f 84 84 07 00 00    	je     bc90 <fwp_hof0.constprop.0+0xda0>
    b50c:	41 c6 06 01          	movb   $0x1,(%r14)
    b510:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b514:	e8 87 ba ff ff       	call   6fa0 <fwp_drop0>
    b519:	48 8b 13             	mov    (%rbx),%rdx
    b51c:	be 01 00 00 00       	mov    $0x1,%esi
    b521:	4c 89 e7             	mov    %r12,%rdi
    b524:	48 8b 0d 95 2f 06 00 	mov    0x62f95(%rip),%rcx        # 6e4c0 <fwp_prog_out>
    b52b:	e8 30 81 ff ff       	call   3660 <fwrite@plt>
    b530:	48 8b 35 89 2f 06 00 	mov    0x62f89(%rip),%rsi        # 6e4c0 <fwp_prog_out>
    b537:	bf 0a 00 00 00       	mov    $0xa,%edi
    b53c:	e8 8f 7f ff ff       	call   34d0 <fputc@plt>
    b541:	48 8d 35 18 13 06 00 	lea    0x61318(%rip),%rsi        # 6c860 <fwp_heap>
    b548:	48 89 d8             	mov    %rbx,%rax
    b54b:	48 8b be d8 13 00 00 	mov    0x13d8(%rsi),%rdi
    b552:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b559:	48 89 fa             	mov    %rdi,%rdx
    b55c:	48 89 7d a8          	mov    %rdi,-0x58(%rbp)
    b560:	48 c1 e2 10          	shl    $0x10,%rdx
    b564:	48 39 d0             	cmp    %rdx,%rax
    b567:	73 69                	jae    b5d2 <fwp_hof0.constprop.0+0x6e2>
    b569:	48 89 c2             	mov    %rax,%rdx
    b56c:	48 c1 ea 10          	shr    $0x10,%rdx
    b570:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b574:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b57b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b57f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b583:	4d 85 e4             	test   %r12,%r12
    b586:	74 4a                	je     b5d2 <fwp_hof0.constprop.0+0x6e2>
    b588:	0f b6 0a             	movzbl (%rdx),%ecx
    b58b:	80 f9 02             	cmp    $0x2,%cl
    b58e:	0f 84 38 06 00 00    	je     bbcc <fwp_hof0.constprop.0+0xcdc>
    b594:	80 f9 01             	cmp    $0x1,%cl
    b597:	75 39                	jne    b5d2 <fwp_hof0.constprop.0+0x6e2>
    b599:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b59c:	0f b7 c0             	movzwl %ax,%eax
    b59f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b5a2:	48 0f af c1          	imul   %rcx,%rax
    b5a6:	48 c1 e8 20          	shr    $0x20,%rax
    b5aa:	48 39 d0             	cmp    %rdx,%rax
    b5ad:	73 23                	jae    b5d2 <fwp_hof0.constprop.0+0x6e2>
    b5af:	49 01 c4             	add    %rax,%r12
    b5b2:	41 0f b6 04 24       	movzbl (%r12),%eax
    b5b7:	84 c0                	test   %al,%al
    b5b9:	74 17                	je     b5d2 <fwp_hof0.constprop.0+0x6e2>
    b5bb:	3c 01                	cmp    $0x1,%al
    b5bd:	0f 84 e1 05 00 00    	je     bba4 <fwp_hof0.constprop.0+0xcb4>
    b5c3:	3c ff                	cmp    $0xff,%al
    b5c5:	0f 84 0f 06 00 00    	je     bbda <fwp_hof0.constprop.0+0xcea>
    b5cb:	83 e8 01             	sub    $0x1,%eax
    b5ce:	41 88 04 24          	mov    %al,(%r12)
    b5d2:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    b5d6:	4d 85 ff             	test   %r15,%r15
    b5d9:	0f 85 52 f9 ff ff    	jne    af31 <fwp_hof0.constprop.0+0x41>
    b5df:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    b5e3:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b5ea:	00 00 
    b5ec:	0f 85 98 06 00 00    	jne    bc8a <fwp_hof0.constprop.0+0xd9a>
    b5f2:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    b5f6:	31 c0                	xor    %eax,%eax
    b5f8:	5b                   	pop    %rbx
    b5f9:	41 5c                	pop    %r12
    b5fb:	41 5d                	pop    %r13
    b5fd:	41 5e                	pop    %r14
    b5ff:	41 5f                	pop    %r15
    b601:	5d                   	pop    %rbp
    b602:	c3                   	ret
    b603:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b608:	44 8b 1d 19 2f 06 00 	mov    0x62f19(%rip),%r11d        # 6e528 <iteration_active>
    b60f:	41 8d 77 01          	lea    0x1(%r15),%esi
    b613:	8b 05 eb 25 06 00    	mov    0x625eb(%rip),%eax        # 6dc04 <fwp_heap+0x13a4>
    b619:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    b620:	00 
    b621:	45 85 db             	test   %r11d,%r11d
    b624:	0f 84 f3 03 00 00    	je     ba1d <fwp_hof0.constprop.0+0xb2d>
    b62a:	48 83 05 ee 2e 06 00 	addq   $0x1,0x62eee(%rip)        # 6e520 <iteration_requests>
    b631:	01 
    b632:	48 01 3d df 2e 06 00 	add    %rdi,0x62edf(%rip)        # 6e518 <iteration_bytes>
    b639:	85 c0                	test   %eax,%eax
    b63b:	0f 84 ca 04 00 00    	je     bb0b <fwp_hof0.constprop.0+0xc1b>
    b641:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    b648:	0f 87 bd 04 00 00    	ja     bb0b <fwp_hof0.constprop.0+0xc1b>
    b64e:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    b652:	48 8d 1d 07 12 06 00 	lea    0x61207(%rip),%rbx        # 6c860 <fwp_heap>
    b659:	48 c1 e8 04          	shr    $0x4,%rax
    b65d:	0f b6 94 03 a0 0f 00 	movzbl 0xfa0(%rbx,%rax,1),%edx
    b664:	00 
    b665:	8b 84 93 00 0f 00 00 	mov    0xf00(%rbx,%rdx,4),%eax
    b66c:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    b670:	48 8d 14 d3          	lea    (%rbx,%rdx,8),%rdx
    b674:	4c 8b 12             	mov    (%rdx),%r10
    b677:	4d 85 d2             	test   %r10,%r10
    b67a:	0f 84 e1 03 00 00    	je     ba61 <fwp_hof0.constprop.0+0xb71>
    b680:	49 8b 1a             	mov    (%r10),%rbx
    b683:	48 f7 d3             	not    %rbx
    b686:	48 89 1a             	mov    %rbx,(%rdx)
    b689:	48 39 c7             	cmp    %rax,%rdi
    b68c:	73 6c                	jae    b6fa <fwp_hof0.constprop.0+0x80a>
    b68e:	48 89 fa             	mov    %rdi,%rdx
    b691:	48 83 c7 08          	add    $0x8,%rdi
    b695:	49 c7 04 f2 00 00 00 	movq   $0x0,(%r10,%rsi,8)
    b69c:	00 
    b69d:	48 f7 d2             	not    %rdx
    b6a0:	48 01 c2             	add    %rax,%rdx
    b6a3:	48 c1 ea 03          	shr    $0x3,%rdx
    b6a7:	48 39 c7             	cmp    %rax,%rdi
    b6aa:	73 4e                	jae    b6fa <fwp_hof0.constprop.0+0x80a>
    b6ac:	83 e2 01             	and    $0x1,%edx
    b6af:	74 2f                	je     b6e0 <fwp_hof0.constprop.0+0x7f0>
    b6b1:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    b6b8:	00 
    b6b9:	48 83 c7 08          	add    $0x8,%rdi
    b6bd:	48 39 c7             	cmp    %rax,%rdi
    b6c0:	73 38                	jae    b6fa <fwp_hof0.constprop.0+0x80a>
    b6c2:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b6c9:	00 
    b6ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b6d1:	00 00 00 00 
    b6d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b6dc:	00 00 00 00 
    b6e0:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    b6e7:	00 
    b6e8:	49 c7 44 3a 08 00 00 	movq   $0x0,0x8(%r10,%rdi,1)
    b6ef:	00 00 
    b6f1:	48 83 c7 10          	add    $0x10,%rdi
    b6f5:	48 39 c7             	cmp    %rax,%rdi
    b6f8:	72 e6                	jb     b6e0 <fwp_hof0.constprop.0+0x7f0>
    b6fa:	48 8d 3d 5f 11 06 00 	lea    0x6115f(%rip),%rdi        # 6c860 <fwp_heap>
    b701:	48 89 c2             	mov    %rax,%rdx
    b704:	48 03 97 20 14 00 00 	add    0x1420(%rdi),%rdx
    b70b:	0f 82 4a 05 00 00    	jb     bc5b <fwp_hof0.constprop.0+0xd6b>
    b711:	48 89 97 20 14 00 00 	mov    %rdx,0x1420(%rdi)
    b718:	48 39 97 28 14 00 00 	cmp    %rdx,0x1428(%rdi)
    b71f:	73 07                	jae    b728 <fwp_hof0.constprop.0+0x838>
    b721:	48 89 15 60 25 06 00 	mov    %rdx,0x62560(%rip)        # 6dc88 <fwp_heap+0x1428>
    b728:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b72c:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    b731:	f2 0f 58 05 5f 25 06 	addsd  0x6255f(%rip),%xmm0        # 6dc98 <fwp_heap+0x1438>
    b738:	00 
    b739:	f2 0f 11 05 57 25 06 	movsd  %xmm0,0x62557(%rip)        # 6dc98 <fwp_heap+0x1438>
    b740:	00 
    b741:	45 85 db             	test   %r11d,%r11d
    b744:	74 33                	je     b779 <fwp_hof0.constprop.0+0x889>
    b746:	48 8b 05 33 25 06 00 	mov    0x62533(%rip),%rax        # 6dc80 <fwp_heap+0x1420>
    b74d:	48 85 c0             	test   %rax,%rax
    b750:	0f 88 64 03 00 00    	js     baba <fwp_hof0.constprop.0+0xbca>
    b756:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b75a:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    b75f:	f2 0f 5c 05 a1 2d 06 	subsd  0x62da1(%rip),%xmm0        # 6e508 <iteration_start_charge>
    b766:	00 
    b767:	66 0f 2f 05 91 2d 06 	comisd 0x62d91(%rip),%xmm0        # 6e500 <iteration_peak>
    b76e:	00 
    b76f:	76 08                	jbe    b779 <fwp_hof0.constprop.0+0x889>
    b771:	f2 0f 11 05 87 2d 06 	movsd  %xmm0,0x62d87(%rip)        # 6e500 <iteration_peak>
    b778:	00 
    b779:	66 41 0f 6e 01       	movd   (%r9),%xmm0
    b77e:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    b783:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    b787:	66 41 0f d6 02       	movq   %xmm0,(%r10)
    b78c:	85 c9                	test   %ecx,%ecx
    b78e:	74 37                	je     b7c7 <fwp_hof0.constprop.0+0x8d7>
    b790:	89 ca                	mov    %ecx,%edx
    b792:	49 8d 71 08          	lea    0x8(%r9),%rsi
    b796:	49 8d 7a 08          	lea    0x8(%r10),%rdi
    b79a:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b79d:	48 c1 e2 03          	shl    $0x3,%rdx
    b7a1:	4c 89 85 68 ff ff ff 	mov    %r8,-0x98(%rbp)
    b7a8:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
    b7ac:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b7b0:	e8 3b 7e ff ff       	call   35f0 <memmove@plt>
    b7b5:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b7b9:	4c 8b 4d 98          	mov    -0x68(%rbp),%r9
    b7bd:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b7c0:	4c 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%r8
    b7c7:	45 85 ed             	test   %r13d,%r13d
    b7ca:	74 2b                	je     b7f7 <fwp_hof0.constprop.0+0x907>
    b7cc:	45 89 ed             	mov    %r13d,%r13d
    b7cf:	4b 8d 34 ec          	lea    (%r12,%r13,8),%rsi
    b7d3:	66 90                	xchg   %ax,%ax
    b7d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b7dc:	00 00 00 00 
    b7e0:	49 8b 14 24          	mov    (%r12),%rdx
    b7e4:	89 c8                	mov    %ecx,%eax
    b7e6:	49 83 c4 08          	add    $0x8,%r12
    b7ea:	83 c1 01             	add    $0x1,%ecx
    b7ed:	49 89 54 c2 08       	mov    %rdx,0x8(%r10,%rax,8)
    b7f2:	4c 39 e6             	cmp    %r12,%rsi
    b7f5:	75 e9                	jne    b7e0 <fwp_hof0.constprop.0+0x8f0>
    b7f7:	48 8d 15 62 10 06 00 	lea    0x61062(%rip),%rdx        # 6c860 <fwp_heap>
    b7fe:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b802:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    b809:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    b810:	48 89 f2             	mov    %rsi,%rdx
    b813:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
    b817:	48 c1 e2 10          	shl    $0x10,%rdx
    b81b:	48 39 d0             	cmp    %rdx,%rax
    b81e:	73 54                	jae    b874 <fwp_hof0.constprop.0+0x984>
    b820:	48 89 c2             	mov    %rax,%rdx
    b823:	48 c1 ea 10          	shr    $0x10,%rdx
    b827:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b82b:	48 8b 15 26 24 06 00 	mov    0x62426(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    b832:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b836:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    b83a:	48 85 c9             	test   %rcx,%rcx
    b83d:	74 35                	je     b874 <fwp_hof0.constprop.0+0x984>
    b83f:	0f b6 32             	movzbl (%rdx),%esi
    b842:	40 80 fe 02          	cmp    $0x2,%sil
    b846:	0f 84 37 02 00 00    	je     ba83 <fwp_hof0.constprop.0+0xb93>
    b84c:	40 80 fe 01          	cmp    $0x1,%sil
    b850:	75 22                	jne    b874 <fwp_hof0.constprop.0+0x984>
    b852:	8b 72 18             	mov    0x18(%rdx),%esi
    b855:	0f b7 c0             	movzwl %ax,%eax
    b858:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b85b:	48 0f af c6          	imul   %rsi,%rax
    b85f:	48 c1 e8 20          	shr    $0x20,%rax
    b863:	48 39 d0             	cmp    %rdx,%rax
    b866:	73 0c                	jae    b874 <fwp_hof0.constprop.0+0x984>
    b868:	48 01 c1             	add    %rax,%rcx
    b86b:	80 39 01             	cmpb   $0x1,(%rcx)
    b86e:	0f 84 9c 01 00 00    	je     ba10 <fwp_hof0.constprop.0+0xb20>
    b874:	49 8b 40 18          	mov    0x18(%r8),%rax
    b878:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b87c:	be 01 00 00 00       	mov    $0x1,%esi
    b881:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b885:	ff 50 08             	call   *0x8(%rax)
    b888:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b88c:	48 8d 35 cd 0f 06 00 	lea    0x60fcd(%rip),%rsi        # 6c860 <fwp_heap>
    b893:	4c 89 d0             	mov    %r10,%rax
    b896:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b89d:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b8a4:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    b8a8:	48 c1 e2 10          	shl    $0x10,%rdx
    b8ac:	48 39 d0             	cmp    %rdx,%rax
    b8af:	73 59                	jae    b90a <fwp_hof0.constprop.0+0xa1a>
    b8b1:	48 89 c2             	mov    %rax,%rdx
    b8b4:	48 c1 ea 10          	shr    $0x10,%rdx
    b8b8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b8bc:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b8c3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b8c7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b8cb:	4d 85 e4             	test   %r12,%r12
    b8ce:	74 3a                	je     b90a <fwp_hof0.constprop.0+0xa1a>
    b8d0:	0f b6 0a             	movzbl (%rdx),%ecx
    b8d3:	80 f9 02             	cmp    $0x2,%cl
    b8d6:	0f 84 b5 01 00 00    	je     ba91 <fwp_hof0.constprop.0+0xba1>
    b8dc:	80 f9 01             	cmp    $0x1,%cl
    b8df:	75 29                	jne    b90a <fwp_hof0.constprop.0+0xa1a>
    b8e1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b8e4:	0f b7 c0             	movzwl %ax,%eax
    b8e7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b8ea:	48 0f af c1          	imul   %rcx,%rax
    b8ee:	48 c1 e8 20          	shr    $0x20,%rax
    b8f2:	48 39 d0             	cmp    %rdx,%rax
    b8f5:	73 13                	jae    b90a <fwp_hof0.constprop.0+0xa1a>
    b8f7:	49 01 c4             	add    %rax,%r12
    b8fa:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b8ff:	0f 84 a0 01 00 00    	je     baa5 <fwp_hof0.constprop.0+0xbb5>
    b905:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b90a:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b90e:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b912:	e8 79 b9 ff ff       	call   7290 <fwp_closure_drop>
    b917:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b91b:	4c 89 55 a8          	mov    %r10,-0x58(%rbp)
    b91f:	e9 3f fa ff ff       	jmp    b363 <fwp_hof0.constprop.0+0x473>
    b924:	0f 1f 40 00          	nopl   0x0(%rax)
    b928:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b92c:	e9 32 fa ff ff       	jmp    b363 <fwp_hof0.constprop.0+0x473>
    b931:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b938:	41 8b 34 24          	mov    (%r12),%esi
    b93c:	8b 05 da 86 00 00    	mov    0x86da(%rip),%eax        # 1401c <fc12+0x4>
    b942:	89 f7                	mov    %esi,%edi
    b944:	29 c7                	sub    %eax,%edi
    b946:	83 ff 01             	cmp    $0x1,%edi
    b949:	0f 85 cf f6 ff ff    	jne    b01e <fwp_hof0.constprop.0+0x12e>
    b94f:	48 89 e3             	mov    %rsp,%rbx
    b952:	85 c0                	test   %eax,%eax
    b954:	0f 84 e7 01 00 00    	je     bb41 <fwp_hof0.constprop.0+0xc51>
    b95a:	89 f1                	mov    %esi,%ecx
    b95c:	ba 08 00 00 00       	mov    $0x8,%edx
    b961:	48 c1 e1 03          	shl    $0x3,%rcx
    b965:	85 f6                	test   %esi,%esi
    b967:	48 89 e6             	mov    %rsp,%rsi
    b96a:	48 0f 45 d1          	cmovne %rcx,%rdx
    b96e:	49 89 d7             	mov    %rdx,%r15
    b971:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    b975:	48 c1 ea 04          	shr    $0x4,%rdx
    b979:	48 c1 e2 04          	shl    $0x4,%rdx
    b97d:	48 89 d7             	mov    %rdx,%rdi
    b980:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    b987:	48 29 fe             	sub    %rdi,%rsi
    b98a:	48 39 f4             	cmp    %rsi,%rsp
    b98d:	74 15                	je     b9a4 <fwp_hof0.constprop.0+0xab4>
    b98f:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    b996:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    b99d:	00 00 
    b99f:	48 39 f4             	cmp    %rsi,%rsp
    b9a2:	75 eb                	jne    b98f <fwp_hof0.constprop.0+0xa9f>
    b9a4:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    b9aa:	48 29 d4             	sub    %rdx,%rsp
    b9ad:	48 85 d2             	test   %rdx,%rdx
    b9b0:	74 06                	je     b9b8 <fwp_hof0.constprop.0+0xac8>
    b9b2:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    b9b8:	4c 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%r14
    b9bf:	00 
    b9c0:	4c 89 f9             	mov    %r15,%rcx
    b9c3:	48 8d 35 56 86 00 00 	lea    0x8656(%rip),%rsi        # 14020 <fwp_epfd>
    b9ca:	48 89 e7             	mov    %rsp,%rdi
    b9cd:	4c 89 f2             	mov    %r14,%rdx
    b9d0:	e8 7b 7b ff ff       	call   3550 <__memcpy_chk@plt>
    b9d5:	4d 39 f7             	cmp    %r14,%r15
    b9d8:	4c 89 f9             	mov    %r15,%rcx
    b9db:	4a 8d 3c 34          	lea    (%rsp,%r14,1),%rdi
    b9df:	49 0f 42 ce          	cmovb  %r14,%rcx
    b9e3:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
    b9ea:	ba 08 00 00 00       	mov    $0x8,%edx
    b9ef:	4c 29 f1             	sub    %r14,%rcx
    b9f2:	e8 59 7b ff ff       	call   3550 <__memcpy_chk@plt>
    b9f7:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    b9fc:	48 89 e7             	mov    %rsp,%rdi
    b9ff:	ff 10                	call   *(%rax)
    ba01:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    ba05:	e9 44 01 00 00       	jmp    bb4e <fwp_hof0.constprop.0+0xc5e>
    ba0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ba10:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    ba17:	00 
    ba18:	e9 6f fe ff ff       	jmp    b88c <fwp_hof0.constprop.0+0x99c>
    ba1d:	85 c0                	test   %eax,%eax
    ba1f:	74 0d                	je     ba2e <fwp_hof0.constprop.0+0xb3e>
    ba21:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    ba28:	0f 86 20 fc ff ff    	jbe    b64e <fwp_hof0.constprop.0+0x75e>
    ba2e:	31 f6                	xor    %esi,%esi
    ba30:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    ba33:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    ba37:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    ba3b:	e8 30 a5 ff ff       	call   5f70 <fwp_heap_alloc>
    ba40:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    ba44:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    ba48:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    ba4b:	49 89 c2             	mov    %rax,%r10
    ba4e:	e9 26 fd ff ff       	jmp    b779 <fwp_hof0.constprop.0+0x889>
    ba53:	66 85 c0             	test   %ax,%ax
    ba56:	0f 85 5f f6 ff ff    	jne    b0bb <fwp_hof0.constprop.0+0x1cb>
    ba5c:	e9 34 f6 ff ff       	jmp    b095 <fwp_hof0.constprop.0+0x1a5>
    ba61:	4c 8b 52 08          	mov    0x8(%rdx),%r10
    ba65:	4d 85 d2             	test   %r10,%r10
    ba68:	74 6e                	je     bad8 <fwp_hof0.constprop.0+0xbe8>
    ba6a:	48 8b 5a 10          	mov    0x10(%rdx),%rbx
    ba6e:	4c 29 d3             	sub    %r10,%rbx
    ba71:	48 39 c3             	cmp    %rax,%rbx
    ba74:	72 62                	jb     bad8 <fwp_hof0.constprop.0+0xbe8>
    ba76:	49 8d 1c 02          	lea    (%r10,%rax,1),%rbx
    ba7a:	48 89 5a 08          	mov    %rbx,0x8(%rdx)
    ba7e:	e9 06 fc ff ff       	jmp    b689 <fwp_hof0.constprop.0+0x799>
    ba83:	66 85 c0             	test   %ax,%ax
    ba86:	0f 85 e8 fd ff ff    	jne    b874 <fwp_hof0.constprop.0+0x984>
    ba8c:	e9 da fd ff ff       	jmp    b86b <fwp_hof0.constprop.0+0x97b>
    ba91:	66 85 c0             	test   %ax,%ax
    ba94:	0f 85 70 fe ff ff    	jne    b90a <fwp_hof0.constprop.0+0xa1a>
    ba9a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ba9f:	0f 85 60 fe ff ff    	jne    b905 <fwp_hof0.constprop.0+0xa15>
    baa5:	4c 89 e7             	mov    %r12,%rdi
    baa8:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    baac:	e8 7f 9d ff ff       	call   5830 <fwp_rc_forget_slot>
    bab1:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    bab5:	e9 4b fe ff ff       	jmp    b905 <fwp_hof0.constprop.0+0xa15>
    baba:	48 89 c2             	mov    %rax,%rdx
    babd:	83 e0 01             	and    $0x1,%eax
    bac0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    bac4:	48 d1 ea             	shr    $1,%rdx
    bac7:	48 09 c2             	or     %rax,%rdx
    baca:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    bacf:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    bad3:	e9 87 fc ff ff       	jmp    b75f <fwp_hof0.constprop.0+0x86f>
    bad8:	31 f6                	xor    %esi,%esi
    bada:	89 8d 68 ff ff ff    	mov    %ecx,-0x98(%rbp)
    bae0:	44 89 5d 80          	mov    %r11d,-0x80(%rbp)
    bae4:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    bae8:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    baec:	e8 7f a4 ff ff       	call   5f70 <fwp_heap_alloc>
    baf1:	8b 8d 68 ff ff ff    	mov    -0x98(%rbp),%ecx
    baf7:	44 8b 5d 80          	mov    -0x80(%rbp),%r11d
    bafb:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    baff:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    bb03:	49 89 c2             	mov    %rax,%r10
    bb06:	e9 36 fc ff ff       	jmp    b741 <fwp_hof0.constprop.0+0x851>
    bb0b:	31 f6                	xor    %esi,%esi
    bb0d:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    bb10:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    bb14:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    bb18:	e8 53 a4 ff ff       	call   5f70 <fwp_heap_alloc>
    bb1d:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    bb21:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    bb25:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    bb28:	49 89 c2             	mov    %rax,%r10
    bb2b:	e9 16 fc ff ff       	jmp    b746 <fwp_hof0.constprop.0+0x856>
    bb30:	e8 db 9b ff ff       	call   5710 <fwp_rc_wide_dup>
    bb35:	48 8b 15 7c 29 06 00 	mov    0x6297c(%rip),%rdx        # 6e4b8 <fwp_fns>
    bb3c:	e9 7a f5 ff ff       	jmp    b0bb <fwp_hof0.constprop.0+0x1cb>
    bb41:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    bb48:	ff 11                	call   *(%rcx)
    bb4a:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    bb4e:	48 89 dc             	mov    %rbx,%rsp
    bb51:	e9 a0 f8 ff ff       	jmp    b3f6 <fwp_hof0.constprop.0+0x506>
    bb56:	48 89 c7             	mov    %rax,%rdi
    bb59:	e8 e2 af ff ff       	call   6b40 <fwp_rc_share>
    bb5e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    bb62:	e8 d9 af ff ff       	call   6b40 <fwp_rc_share>
    bb67:	48 8d 05 aa 84 00 00 	lea    0x84aa(%rip),%rax        # 14018 <fc12>
    bb6e:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    bb75:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    bb79:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    bb80:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    bb84:	e9 59 f8 ff ff       	jmp    b3e2 <fwp_hof0.constprop.0+0x4f2>
    bb89:	66 85 c0             	test   %ax,%ax
    bb8c:	0f 85 36 f4 ff ff    	jne    afc8 <fwp_hof0.constprop.0+0xd8>
    bb92:	e9 0f f4 ff ff       	jmp    afa6 <fwp_hof0.constprop.0+0xb6>
    bb97:	48 83 05 71 29 06 00 	addq   $0x1,0x62971(%rip)        # 6e510 <iteration_retains>
    bb9e:	01 
    bb9f:	e9 17 f4 ff ff       	jmp    afbb <fwp_hof0.constprop.0+0xcb>
    bba4:	48 89 df             	mov    %rbx,%rdi
    bba7:	e8 c4 b0 ff ff       	call   6c70 <fwp_rc_free_arr>
    bbac:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    bbb0:	4d 85 ff             	test   %r15,%r15
    bbb3:	0f 85 78 f3 ff ff    	jne    af31 <fwp_hof0.constprop.0+0x41>
    bbb9:	e9 21 fa ff ff       	jmp    b5df <fwp_hof0.constprop.0+0x6ef>
    bbbe:	66 85 c0             	test   %ax,%ax
    bbc1:	0f 85 49 f9 ff ff    	jne    b510 <fwp_hof0.constprop.0+0x620>
    bbc7:	e9 36 f9 ff ff       	jmp    b502 <fwp_hof0.constprop.0+0x612>
    bbcc:	66 85 c0             	test   %ax,%ax
    bbcf:	0f 85 fd f9 ff ff    	jne    b5d2 <fwp_hof0.constprop.0+0x6e2>
    bbd5:	e9 d8 f9 ff ff       	jmp    b5b2 <fwp_hof0.constprop.0+0x6c2>
    bbda:	4c 89 e0             	mov    %r12,%rax
    bbdd:	48 8d 35 7c 0c 06 00 	lea    0x60c7c(%rip),%rsi        # 6c860 <fwp_heap>
    bbe4:	48 c1 e8 11          	shr    $0x11,%rax
    bbe8:	4c 31 e0             	xor    %r12,%rax
    bbeb:	48 89 c2             	mov    %rax,%rdx
    bbee:	48 c1 ea 09          	shr    $0x9,%rdx
    bbf2:	48 31 d0             	xor    %rdx,%rax
    bbf5:	0f b6 c0             	movzbl %al,%eax
    bbf8:	48 8b 94 c6 48 14 00 	mov    0x1448(%rsi,%rax,8),%rdx
    bbff:	00 
    bc00:	48 85 d2             	test   %rdx,%rdx
    bc03:	75 24                	jne    bc29 <fwp_hof0.constprop.0+0xd39>
    bc05:	eb 59                	jmp    bc60 <fwp_hof0.constprop.0+0xd70>
    bc07:	0f 1f 00             	nopl   (%rax)
    bc0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bc11:	00 00 00 00 
    bc15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bc1c:	00 00 00 00 
    bc20:	48 8b 50 10          	mov    0x10(%rax),%rdx
    bc24:	48 85 d2             	test   %rdx,%rdx
    bc27:	74 37                	je     bc60 <fwp_hof0.constprop.0+0xd70>
    bc29:	48 89 d0             	mov    %rdx,%rax
    bc2c:	4c 3b 22             	cmp    (%rdx),%r12
    bc2f:	75 ef                	jne    bc20 <fwp_hof0.constprop.0+0xd30>
    bc31:	48 8b 42 08          	mov    0x8(%rdx),%rax
    bc35:	48 83 e8 01          	sub    $0x1,%rax
    bc39:	48 89 42 08          	mov    %rax,0x8(%rdx)
    bc3d:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    bc43:	0f 85 89 f9 ff ff    	jne    b5d2 <fwp_hof0.constprop.0+0x6e2>
    bc49:	4c 89 e7             	mov    %r12,%rdi
    bc4c:	e8 df 9b ff ff       	call   5830 <fwp_rc_forget_slot>
    bc51:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    bc56:	e9 77 f9 ff ff       	jmp    b5d2 <fwp_hof0.constprop.0+0x6e2>
    bc5b:	e8 d0 81 ff ff       	call   3e30 <fwp_heap_oom>
    bc60:	48 8d 3d 79 4d 00 00 	lea    0x4d79(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    bc67:	e8 e4 87 ff ff       	call   4450 <fwp_trap>
    bc6c:	48 8d 3d 4f 46 00 00 	lea    0x464f(%rip),%rdi        # 102c2 <_IO_stdin_used+0x2c2>
    bc73:	e8 d8 87 ff ff       	call   4450 <fwp_trap>
    bc78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    bc7f:	00 
    bc80:	e8 8b 9a ff ff       	call   5710 <fwp_rc_wide_dup>
    bc85:	e9 3e f3 ff ff       	jmp    afc8 <fwp_hof0.constprop.0+0xd8>
    bc8a:	e8 c1 77 ff ff       	call   3450 <__stack_chk_fail@plt>
    bc8f:	90                   	nop
    bc90:	4c 89 f7             	mov    %r14,%rdi
    bc93:	e8 98 9b ff ff       	call   5830 <fwp_rc_forget_slot>
    bc98:	e9 6f f8 ff ff       	jmp    b50c <fwp_hof0.constprop.0+0x61c>
    bc9d:	0f 1f 00             	nopl   (%rax)

000000000000bca0 <f0>:
    bca0:	41 56                	push   %r14
    bca2:	4c 8d 35 b7 0b 06 00 	lea    0x60bb7(%rip),%r14        # 6c860 <fwp_heap>
    bca9:	41 55                	push   %r13
    bcab:	41 54                	push   %r12
    bcad:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    bcb3:	55                   	push   %rbp
    bcb4:	53                   	push   %rbx
    bcb5:	31 db                	xor    %ebx,%ebx
    bcb7:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    bcbe:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    bcc5:	00 00 
    bcc7:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    bcce:	00 
    bccf:	31 c0                	xor    %eax,%eax
    bcd1:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    bcd8:	00 
    bcd9:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    bce0:	00 00 
    bce2:	66 48 0f 6e c0       	movq   %rax,%xmm0
    bce7:	48 8d 05 42 b4 ff ff 	lea    -0x4bbe(%rip),%rax        # 7130 <fwp_drop1>
    bcee:	66 48 0f 6e c8       	movq   %rax,%xmm1
    bcf3:	48 8b 05 fe 27 06 00 	mov    0x627fe(%rip),%rax        # 6e4f8 <fwp_cleanups>
    bcfa:	48 89 25 f7 27 06 00 	mov    %rsp,0x627f7(%rip)        # 6e4f8 <fwp_cleanups>
    bd01:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    bd05:	48 89 04 24          	mov    %rax,(%rsp)
    bd09:	48 8d 05 c0 7e ff ff 	lea    -0x8140(%rip),%rax        # 3bd0 <fwp_range_release>
    bd10:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    bd15:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    bd1a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    bd1f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    bd24:	eb 47                	jmp    bd6d <f0+0xcd>
    bd26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bd2d:	00 00 00 
    bd30:	80 f9 01             	cmp    $0x1,%cl
    bd33:	75 29                	jne    bd5e <f0+0xbe>
    bd35:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bd38:	0f b7 c0             	movzwl %ax,%eax
    bd3b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bd3e:	48 0f af c1          	imul   %rcx,%rax
    bd42:	48 c1 e8 20          	shr    $0x20,%rax
    bd46:	48 39 d0             	cmp    %rdx,%rax
    bd49:	73 13                	jae    bd5e <f0+0xbe>
    bd4b:	49 01 c5             	add    %rax,%r13
    bd4e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    bd53:	0f 84 c7 27 00 00    	je     e520 <f0+0x2880>
    bd59:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    bd5e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    bd63:	49 83 ec 01          	sub    $0x1,%r12
    bd67:	0f 82 83 00 00 00    	jb     bdf0 <f0+0x150>
    bd6d:	48 89 ee             	mov    %rbp,%rsi
    bd70:	bf 01 00 00 00       	mov    $0x1,%edi
    bd75:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    bd7c:	00 
    bd7d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    bd82:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    bd89:	00 
    bd8a:	e8 c1 ab ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    bd8f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    bd96:	48 89 c3             	mov    %rax,%rbx
    bd99:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    bda0:	48 c1 e2 10          	shl    $0x10,%rdx
    bda4:	48 39 d0             	cmp    %rdx,%rax
    bda7:	73 b5                	jae    bd5e <f0+0xbe>
    bda9:	48 89 c2             	mov    %rax,%rdx
    bdac:	48 c1 ea 10          	shr    $0x10,%rdx
    bdb0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bdb4:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    bdbb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bdbf:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    bdc3:	4d 85 ed             	test   %r13,%r13
    bdc6:	74 96                	je     bd5e <f0+0xbe>
    bdc8:	0f b6 0a             	movzbl (%rdx),%ecx
    bdcb:	80 f9 02             	cmp    $0x2,%cl
    bdce:	0f 85 5c ff ff ff    	jne    bd30 <f0+0x90>
    bdd4:	66 85 c0             	test   %ax,%ax
    bdd7:	0f 84 71 ff ff ff    	je     bd4e <f0+0xae>
    bddd:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    bde2:	49 83 ec 01          	sub    $0x1,%r12
    bde6:	73 85                	jae    bd6d <f0+0xcd>
    bde8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    bdef:	00 
    bdf0:	48 8b 04 24          	mov    (%rsp),%rax
    bdf4:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    bdf9:	bf 01 00 00 00       	mov    $0x1,%edi
    bdfe:	66 0f 6f 05 da 4f 00 	movdqa 0x4fda(%rip),%xmm0        # 10de0 <msg.8+0xb0>
    be05:	00 
    be06:	48 89 05 eb 26 06 00 	mov    %rax,0x626eb(%rip)        # 6e4f8 <fwp_cleanups>
    be0d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    be12:	e8 39 ab ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    be17:	48 8b 15 1a 1e 06 00 	mov    0x61e1a(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    be1e:	49 89 c5             	mov    %rax,%r13
    be21:	48 2b 05 e8 1d 06 00 	sub    0x61de8(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    be28:	48 c1 e2 10          	shl    $0x10,%rdx
    be2c:	48 39 d0             	cmp    %rdx,%rax
    be2f:	73 59                	jae    be8a <f0+0x1ea>
    be31:	48 89 c2             	mov    %rax,%rdx
    be34:	48 c1 ea 10          	shr    $0x10,%rdx
    be38:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    be3c:	48 8b 15 15 1e 06 00 	mov    0x61e15(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    be43:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    be47:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    be4b:	4d 85 e4             	test   %r12,%r12
    be4e:	74 3a                	je     be8a <f0+0x1ea>
    be50:	0f b6 0a             	movzbl (%rdx),%ecx
    be53:	80 f9 02             	cmp    $0x2,%cl
    be56:	0f 84 74 27 00 00    	je     e5d0 <f0+0x2930>
    be5c:	80 f9 01             	cmp    $0x1,%cl
    be5f:	75 29                	jne    be8a <f0+0x1ea>
    be61:	8b 4a 18             	mov    0x18(%rdx),%ecx
    be64:	0f b7 c0             	movzwl %ax,%eax
    be67:	8b 52 1c             	mov    0x1c(%rdx),%edx
    be6a:	48 0f af c1          	imul   %rcx,%rax
    be6e:	48 c1 e8 20          	shr    $0x20,%rax
    be72:	48 39 d0             	cmp    %rdx,%rax
    be75:	73 13                	jae    be8a <f0+0x1ea>
    be77:	49 01 c4             	add    %rax,%r12
    be7a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    be7f:	0f 84 26 29 00 00    	je     e7ab <f0+0x2b0b>
    be85:	41 c6 04 24 01       	movb   $0x1,(%r12)
    be8a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    be8f:	bf 01 00 00 00       	mov    $0x1,%edi
    be94:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    be99:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    bea0:	00 f0 3f 
    bea3:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    bea8:	e8 a3 aa ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    bead:	48 8b 15 84 1d 06 00 	mov    0x61d84(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    beb4:	49 89 c5             	mov    %rax,%r13
    beb7:	48 2b 05 52 1d 06 00 	sub    0x61d52(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    bebe:	48 c1 e2 10          	shl    $0x10,%rdx
    bec2:	48 39 d0             	cmp    %rdx,%rax
    bec5:	73 59                	jae    bf20 <f0+0x280>
    bec7:	48 89 c2             	mov    %rax,%rdx
    beca:	48 c1 ea 10          	shr    $0x10,%rdx
    bece:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bed2:	48 8b 15 7f 1d 06 00 	mov    0x61d7f(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    bed9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bedd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bee1:	4d 85 e4             	test   %r12,%r12
    bee4:	74 3a                	je     bf20 <f0+0x280>
    bee6:	0f b6 0a             	movzbl (%rdx),%ecx
    bee9:	80 f9 02             	cmp    $0x2,%cl
    beec:	0f 84 ce 26 00 00    	je     e5c0 <f0+0x2920>
    bef2:	80 f9 01             	cmp    $0x1,%cl
    bef5:	75 29                	jne    bf20 <f0+0x280>
    bef7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    befa:	0f b7 c0             	movzwl %ax,%eax
    befd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bf00:	48 0f af c1          	imul   %rcx,%rax
    bf04:	48 c1 e8 20          	shr    $0x20,%rax
    bf08:	48 39 d0             	cmp    %rdx,%rax
    bf0b:	73 13                	jae    bf20 <f0+0x280>
    bf0d:	49 01 c4             	add    %rax,%r12
    bf10:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bf15:	0f 84 9d 28 00 00    	je     e7b8 <f0+0x2b18>
    bf1b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bf20:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    bf25:	bf 01 00 00 00       	mov    $0x1,%edi
    bf2a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    bf2f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    bf36:	33 f3 bf 
    bf39:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    bf3e:	e8 0d aa ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    bf43:	48 8b 15 ee 1c 06 00 	mov    0x61cee(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    bf4a:	49 89 c5             	mov    %rax,%r13
    bf4d:	48 2b 05 bc 1c 06 00 	sub    0x61cbc(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    bf54:	48 c1 e2 10          	shl    $0x10,%rdx
    bf58:	48 39 d0             	cmp    %rdx,%rax
    bf5b:	73 59                	jae    bfb6 <f0+0x316>
    bf5d:	48 89 c2             	mov    %rax,%rdx
    bf60:	48 c1 ea 10          	shr    $0x10,%rdx
    bf64:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bf68:	48 8b 15 e9 1c 06 00 	mov    0x61ce9(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    bf6f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bf73:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bf77:	4d 85 e4             	test   %r12,%r12
    bf7a:	74 3a                	je     bfb6 <f0+0x316>
    bf7c:	0f b6 0a             	movzbl (%rdx),%ecx
    bf7f:	80 f9 02             	cmp    $0x2,%cl
    bf82:	0f 84 28 26 00 00    	je     e5b0 <f0+0x2910>
    bf88:	80 f9 01             	cmp    $0x1,%cl
    bf8b:	75 29                	jne    bfb6 <f0+0x316>
    bf8d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bf90:	0f b7 c0             	movzwl %ax,%eax
    bf93:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bf96:	48 0f af c1          	imul   %rcx,%rax
    bf9a:	48 c1 e8 20          	shr    $0x20,%rax
    bf9e:	48 39 d0             	cmp    %rdx,%rax
    bfa1:	73 13                	jae    bfb6 <f0+0x316>
    bfa3:	49 01 c4             	add    %rax,%r12
    bfa6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bfab:	0f 84 14 28 00 00    	je     e7c5 <f0+0x2b25>
    bfb1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bfb6:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    bfbb:	bf 01 00 00 00       	mov    $0x1,%edi
    bfc0:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    bfc5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    bfcc:	00 f0 3f 
    bfcf:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    bfd4:	e8 77 a9 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    bfd9:	48 8b 15 58 1c 06 00 	mov    0x61c58(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    bfe0:	49 89 c5             	mov    %rax,%r13
    bfe3:	48 2b 05 26 1c 06 00 	sub    0x61c26(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    bfea:	48 c1 e2 10          	shl    $0x10,%rdx
    bfee:	48 39 d0             	cmp    %rdx,%rax
    bff1:	73 59                	jae    c04c <f0+0x3ac>
    bff3:	48 89 c2             	mov    %rax,%rdx
    bff6:	48 c1 ea 10          	shr    $0x10,%rdx
    bffa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bffe:	48 8b 15 53 1c 06 00 	mov    0x61c53(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    c005:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c009:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c00d:	4d 85 e4             	test   %r12,%r12
    c010:	74 3a                	je     c04c <f0+0x3ac>
    c012:	0f b6 0a             	movzbl (%rdx),%ecx
    c015:	80 f9 02             	cmp    $0x2,%cl
    c018:	0f 84 f2 25 00 00    	je     e610 <f0+0x2970>
    c01e:	80 f9 01             	cmp    $0x1,%cl
    c021:	75 29                	jne    c04c <f0+0x3ac>
    c023:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c026:	0f b7 c0             	movzwl %ax,%eax
    c029:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c02c:	48 0f af c1          	imul   %rcx,%rax
    c030:	48 c1 e8 20          	shr    $0x20,%rax
    c034:	48 39 d0             	cmp    %rdx,%rax
    c037:	73 13                	jae    c04c <f0+0x3ac>
    c039:	49 01 c4             	add    %rax,%r12
    c03c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c041:	0f 84 8b 27 00 00    	je     e7d2 <f0+0x2b32>
    c047:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c04c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c053:	33 f3 bf 
    c056:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    c05d:	00 
    c05e:	bf 01 00 00 00       	mov    $0x1,%edi
    c063:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    c06a:	00 
    c06b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    c072:	00 
    c073:	e8 d8 a8 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c078:	48 8b 15 b9 1b 06 00 	mov    0x61bb9(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    c07f:	49 89 c5             	mov    %rax,%r13
    c082:	48 2b 05 87 1b 06 00 	sub    0x61b87(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    c089:	48 c1 e2 10          	shl    $0x10,%rdx
    c08d:	48 39 d0             	cmp    %rdx,%rax
    c090:	73 59                	jae    c0eb <f0+0x44b>
    c092:	48 89 c2             	mov    %rax,%rdx
    c095:	48 c1 ea 10          	shr    $0x10,%rdx
    c099:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c09d:	48 8b 15 b4 1b 06 00 	mov    0x61bb4(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    c0a4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c0a8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c0ac:	4d 85 e4             	test   %r12,%r12
    c0af:	74 3a                	je     c0eb <f0+0x44b>
    c0b1:	0f b6 0a             	movzbl (%rdx),%ecx
    c0b4:	80 f9 02             	cmp    $0x2,%cl
    c0b7:	0f 84 43 25 00 00    	je     e600 <f0+0x2960>
    c0bd:	80 f9 01             	cmp    $0x1,%cl
    c0c0:	75 29                	jne    c0eb <f0+0x44b>
    c0c2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c0c5:	0f b7 c0             	movzwl %ax,%eax
    c0c8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c0cb:	48 0f af c1          	imul   %rcx,%rax
    c0cf:	48 c1 e8 20          	shr    $0x20,%rax
    c0d3:	48 39 d0             	cmp    %rdx,%rax
    c0d6:	73 13                	jae    c0eb <f0+0x44b>
    c0d8:	49 01 c4             	add    %rax,%r12
    c0db:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c0e0:	0f 84 f9 26 00 00    	je     e7df <f0+0x2b3f>
    c0e6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c0eb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c0f2:	00 f0 3f 
    c0f5:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    c0fc:	00 
    c0fd:	bf 01 00 00 00       	mov    $0x1,%edi
    c102:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    c109:	00 
    c10a:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    c111:	00 
    c112:	e8 39 a8 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c117:	48 8b 15 1a 1b 06 00 	mov    0x61b1a(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    c11e:	49 89 c5             	mov    %rax,%r13
    c121:	48 2b 05 e8 1a 06 00 	sub    0x61ae8(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    c128:	48 c1 e2 10          	shl    $0x10,%rdx
    c12c:	48 39 d0             	cmp    %rdx,%rax
    c12f:	73 59                	jae    c18a <f0+0x4ea>
    c131:	48 89 c2             	mov    %rax,%rdx
    c134:	48 c1 ea 10          	shr    $0x10,%rdx
    c138:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c13c:	48 8b 15 15 1b 06 00 	mov    0x61b15(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    c143:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c147:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c14b:	4d 85 e4             	test   %r12,%r12
    c14e:	74 3a                	je     c18a <f0+0x4ea>
    c150:	0f b6 0a             	movzbl (%rdx),%ecx
    c153:	80 f9 02             	cmp    $0x2,%cl
    c156:	0f 84 94 24 00 00    	je     e5f0 <f0+0x2950>
    c15c:	80 f9 01             	cmp    $0x1,%cl
    c15f:	75 29                	jne    c18a <f0+0x4ea>
    c161:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c164:	0f b7 c0             	movzwl %ax,%eax
    c167:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c16a:	48 0f af c1          	imul   %rcx,%rax
    c16e:	48 c1 e8 20          	shr    $0x20,%rax
    c172:	48 39 d0             	cmp    %rdx,%rax
    c175:	73 13                	jae    c18a <f0+0x4ea>
    c177:	49 01 c4             	add    %rax,%r12
    c17a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c17f:	0f 84 67 26 00 00    	je     e7ec <f0+0x2b4c>
    c185:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c18a:	49 bc 33 33 33 33 33 	movabs $0xbff3333333333333,%r12
    c191:	33 f3 bf 
    c194:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    c19b:	00 
    c19c:	bf 01 00 00 00       	mov    $0x1,%edi
    c1a1:	4c 89 ac 24 a8 00 00 	mov    %r13,0xa8(%rsp)
    c1a8:	00 
    c1a9:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
    c1b0:	00 
    c1b1:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
    c1b8:	00 f0 3f 
    c1bb:	e8 90 a7 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c1c0:	48 89 c7             	mov    %rax,%rdi
    c1c3:	e8 f8 a9 ff ff       	call   6bc0 <fwp_rc_fresh>
    c1c8:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    c1cf:	00 
    c1d0:	bf 01 00 00 00       	mov    $0x1,%edi
    c1d5:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
    c1dc:	00 
    c1dd:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    c1e4:	00 
    c1e5:	e8 66 a7 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c1ea:	48 89 c7             	mov    %rax,%rdi
    c1ed:	e8 ce a9 ff ff       	call   6bc0 <fwp_rc_fresh>
    c1f2:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    c1f9:	00 
    c1fa:	bf 01 00 00 00       	mov    $0x1,%edi
    c1ff:	4c 89 a4 24 c0 00 00 	mov    %r12,0xc0(%rsp)
    c206:	00 
    c207:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    c20e:	00 
    c20f:	e8 3c a7 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c214:	48 89 c7             	mov    %rax,%rdi
    c217:	e8 a4 a9 ff ff       	call   6bc0 <fwp_rc_fresh>
    c21c:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    c223:	00 
    c224:	bf 01 00 00 00       	mov    $0x1,%edi
    c229:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
    c230:	00 
    c231:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    c238:	00 
    c239:	e8 12 a7 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c23e:	48 89 c7             	mov    %rax,%rdi
    c241:	e8 7a a9 ff ff       	call   6bc0 <fwp_rc_fresh>
    c246:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    c24d:	00 
    c24e:	bf 01 00 00 00       	mov    $0x1,%edi
    c253:	4c 89 a4 24 e0 00 00 	mov    %r12,0xe0(%rsp)
    c25a:	00 
    c25b:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    c262:	00 
    c263:	e8 e8 a6 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c268:	48 89 c7             	mov    %rax,%rdi
    c26b:	e8 50 a9 ff ff       	call   6bc0 <fwp_rc_fresh>
    c270:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    c277:	00 
    c278:	bf 01 00 00 00       	mov    $0x1,%edi
    c27d:	4c 89 ac 24 f0 00 00 	mov    %r13,0xf0(%rsp)
    c284:	00 
    c285:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    c28c:	00 
    c28d:	e8 be a6 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c292:	48 89 c7             	mov    %rax,%rdi
    c295:	e8 26 a9 ff ff       	call   6bc0 <fwp_rc_fresh>
    c29a:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    c2a1:	00 
    c2a2:	bf 01 00 00 00       	mov    $0x1,%edi
    c2a7:	4c 89 a4 24 00 01 00 	mov    %r12,0x100(%rsp)
    c2ae:	00 
    c2af:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    c2b6:	00 
    c2b7:	e8 94 a6 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c2bc:	48 89 c7             	mov    %rax,%rdi
    c2bf:	e8 fc a8 ff ff       	call   6bc0 <fwp_rc_fresh>
    c2c4:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    c2cb:	00 
    c2cc:	bf 01 00 00 00       	mov    $0x1,%edi
    c2d1:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
    c2d8:	00 
    c2d9:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    c2e0:	00 
    c2e1:	e8 6a a6 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c2e6:	48 89 c7             	mov    %rax,%rdi
    c2e9:	e8 d2 a8 ff ff       	call   6bc0 <fwp_rc_fresh>
    c2ee:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    c2f5:	00 
    c2f6:	bf 01 00 00 00       	mov    $0x1,%edi
    c2fb:	4c 89 a4 24 20 01 00 	mov    %r12,0x120(%rsp)
    c302:	00 
    c303:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    c30a:	00 
    c30b:	e8 40 a6 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c310:	48 89 c7             	mov    %rax,%rdi
    c313:	e8 a8 a8 ff ff       	call   6bc0 <fwp_rc_fresh>
    c318:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    c31f:	00 
    c320:	bf 01 00 00 00       	mov    $0x1,%edi
    c325:	4c 89 ac 24 30 01 00 	mov    %r13,0x130(%rsp)
    c32c:	00 
    c32d:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    c334:	00 
    c335:	e8 16 a6 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c33a:	48 89 c7             	mov    %rax,%rdi
    c33d:	e8 7e a8 ff ff       	call   6bc0 <fwp_rc_fresh>
    c342:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    c349:	00 
    c34a:	bf 01 00 00 00       	mov    $0x1,%edi
    c34f:	4c 89 a4 24 40 01 00 	mov    %r12,0x140(%rsp)
    c356:	00 
    c357:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    c35e:	00 
    c35f:	e8 ec a5 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c364:	48 89 c7             	mov    %rax,%rdi
    c367:	e8 54 a8 ff ff       	call   6bc0 <fwp_rc_fresh>
    c36c:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    c373:	00 
    c374:	bf 01 00 00 00       	mov    $0x1,%edi
    c379:	4c 89 ac 24 50 01 00 	mov    %r13,0x150(%rsp)
    c380:	00 
    c381:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    c388:	00 
    c389:	e8 c2 a5 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c38e:	48 89 c7             	mov    %rax,%rdi
    c391:	e8 2a a8 ff ff       	call   6bc0 <fwp_rc_fresh>
    c396:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    c39d:	00 
    c39e:	bf 01 00 00 00       	mov    $0x1,%edi
    c3a3:	4c 89 a4 24 60 01 00 	mov    %r12,0x160(%rsp)
    c3aa:	00 
    c3ab:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    c3b2:	00 
    c3b3:	e8 98 a5 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c3b8:	48 89 c7             	mov    %rax,%rdi
    c3bb:	e8 00 a8 ff ff       	call   6bc0 <fwp_rc_fresh>
    c3c0:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    c3c7:	00 
    c3c8:	bf 01 00 00 00       	mov    $0x1,%edi
    c3cd:	4c 89 ac 24 70 01 00 	mov    %r13,0x170(%rsp)
    c3d4:	00 
    c3d5:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    c3dc:	00 
    c3dd:	e8 6e a5 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c3e2:	48 89 c7             	mov    %rax,%rdi
    c3e5:	e8 d6 a7 ff ff       	call   6bc0 <fwp_rc_fresh>
    c3ea:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    c3f1:	00 
    c3f2:	bf 01 00 00 00       	mov    $0x1,%edi
    c3f7:	4c 89 a4 24 80 01 00 	mov    %r12,0x180(%rsp)
    c3fe:	00 
    c3ff:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    c406:	00 
    c407:	e8 44 a5 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c40c:	48 89 c7             	mov    %rax,%rdi
    c40f:	e8 ac a7 ff ff       	call   6bc0 <fwp_rc_fresh>
    c414:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    c41b:	00 
    c41c:	bf 01 00 00 00       	mov    $0x1,%edi
    c421:	4c 89 ac 24 90 01 00 	mov    %r13,0x190(%rsp)
    c428:	00 
    c429:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    c430:	00 
    c431:	e8 1a a5 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c436:	48 89 c7             	mov    %rax,%rdi
    c439:	e8 82 a7 ff ff       	call   6bc0 <fwp_rc_fresh>
    c43e:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    c445:	00 
    c446:	bf 01 00 00 00       	mov    $0x1,%edi
    c44b:	4c 89 a4 24 a0 01 00 	mov    %r12,0x1a0(%rsp)
    c452:	00 
    c453:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    c45a:	00 
    c45b:	e8 f0 a4 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c460:	48 89 c7             	mov    %rax,%rdi
    c463:	e8 58 a7 ff ff       	call   6bc0 <fwp_rc_fresh>
    c468:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    c46f:	00 
    c470:	bf 01 00 00 00       	mov    $0x1,%edi
    c475:	4c 89 ac 24 b0 01 00 	mov    %r13,0x1b0(%rsp)
    c47c:	00 
    c47d:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    c484:	00 
    c485:	e8 c6 a4 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c48a:	48 89 c7             	mov    %rax,%rdi
    c48d:	e8 2e a7 ff ff       	call   6bc0 <fwp_rc_fresh>
    c492:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    c499:	00 
    c49a:	bf 01 00 00 00       	mov    $0x1,%edi
    c49f:	4c 89 a4 24 c0 01 00 	mov    %r12,0x1c0(%rsp)
    c4a6:	00 
    c4a7:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    c4ae:	00 
    c4af:	e8 9c a4 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c4b4:	48 89 c7             	mov    %rax,%rdi
    c4b7:	e8 04 a7 ff ff       	call   6bc0 <fwp_rc_fresh>
    c4bc:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    c4c3:	00 
    c4c4:	bf 01 00 00 00       	mov    $0x1,%edi
    c4c9:	4c 89 ac 24 d0 01 00 	mov    %r13,0x1d0(%rsp)
    c4d0:	00 
    c4d1:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    c4d8:	00 
    c4d9:	e8 72 a4 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c4de:	48 89 c7             	mov    %rax,%rdi
    c4e1:	e8 da a6 ff ff       	call   6bc0 <fwp_rc_fresh>
    c4e6:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    c4ed:	00 
    c4ee:	bf 01 00 00 00       	mov    $0x1,%edi
    c4f3:	4c 89 a4 24 e0 01 00 	mov    %r12,0x1e0(%rsp)
    c4fa:	00 
    c4fb:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    c502:	00 
    c503:	e8 48 a4 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c508:	48 89 c7             	mov    %rax,%rdi
    c50b:	e8 b0 a6 ff ff       	call   6bc0 <fwp_rc_fresh>
    c510:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    c517:	00 
    c518:	bf 01 00 00 00       	mov    $0x1,%edi
    c51d:	4c 89 ac 24 f0 01 00 	mov    %r13,0x1f0(%rsp)
    c524:	00 
    c525:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    c52c:	00 
    c52d:	e8 1e a4 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c532:	48 89 c7             	mov    %rax,%rdi
    c535:	e8 86 a6 ff ff       	call   6bc0 <fwp_rc_fresh>
    c53a:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    c541:	00 
    c542:	bf 01 00 00 00       	mov    $0x1,%edi
    c547:	4c 89 a4 24 00 02 00 	mov    %r12,0x200(%rsp)
    c54e:	00 
    c54f:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    c556:	00 
    c557:	e8 f4 a3 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c55c:	48 89 c7             	mov    %rax,%rdi
    c55f:	e8 5c a6 ff ff       	call   6bc0 <fwp_rc_fresh>
    c564:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    c56b:	00 
    c56c:	bf 01 00 00 00       	mov    $0x1,%edi
    c571:	4c 89 ac 24 10 02 00 	mov    %r13,0x210(%rsp)
    c578:	00 
    c579:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    c580:	00 
    c581:	e8 ca a3 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c586:	48 89 c7             	mov    %rax,%rdi
    c589:	e8 32 a6 ff ff       	call   6bc0 <fwp_rc_fresh>
    c58e:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    c595:	00 
    c596:	bf 01 00 00 00       	mov    $0x1,%edi
    c59b:	4c 89 a4 24 20 02 00 	mov    %r12,0x220(%rsp)
    c5a2:	00 
    c5a3:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    c5aa:	00 
    c5ab:	e8 a0 a3 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c5b0:	48 89 c7             	mov    %rax,%rdi
    c5b3:	e8 08 a6 ff ff       	call   6bc0 <fwp_rc_fresh>
    c5b8:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    c5bf:	00 
    c5c0:	bf 01 00 00 00       	mov    $0x1,%edi
    c5c5:	4c 89 ac 24 30 02 00 	mov    %r13,0x230(%rsp)
    c5cc:	00 
    c5cd:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    c5d4:	00 
    c5d5:	e8 76 a3 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c5da:	48 89 c7             	mov    %rax,%rdi
    c5dd:	e8 de a5 ff ff       	call   6bc0 <fwp_rc_fresh>
    c5e2:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    c5e9:	00 
    c5ea:	bf 01 00 00 00       	mov    $0x1,%edi
    c5ef:	4c 89 a4 24 40 02 00 	mov    %r12,0x240(%rsp)
    c5f6:	00 
    c5f7:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    c5fe:	00 
    c5ff:	e8 4c a3 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c604:	48 89 c7             	mov    %rax,%rdi
    c607:	e8 b4 a5 ff ff       	call   6bc0 <fwp_rc_fresh>
    c60c:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    c613:	00 
    c614:	bf 01 00 00 00       	mov    $0x1,%edi
    c619:	4c 89 ac 24 50 02 00 	mov    %r13,0x250(%rsp)
    c620:	00 
    c621:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    c628:	00 
    c629:	e8 22 a3 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c62e:	48 89 c7             	mov    %rax,%rdi
    c631:	e8 8a a5 ff ff       	call   6bc0 <fwp_rc_fresh>
    c636:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    c63d:	00 
    c63e:	bf 01 00 00 00       	mov    $0x1,%edi
    c643:	4c 89 a4 24 60 02 00 	mov    %r12,0x260(%rsp)
    c64a:	00 
    c64b:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    c652:	00 
    c653:	e8 f8 a2 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c658:	48 89 c7             	mov    %rax,%rdi
    c65b:	e8 60 a5 ff ff       	call   6bc0 <fwp_rc_fresh>
    c660:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    c667:	00 
    c668:	bf 01 00 00 00       	mov    $0x1,%edi
    c66d:	4c 89 ac 24 70 02 00 	mov    %r13,0x270(%rsp)
    c674:	00 
    c675:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    c67c:	00 
    c67d:	e8 ce a2 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c682:	48 89 c7             	mov    %rax,%rdi
    c685:	e8 36 a5 ff ff       	call   6bc0 <fwp_rc_fresh>
    c68a:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    c691:	00 
    c692:	bf 01 00 00 00       	mov    $0x1,%edi
    c697:	4c 89 a4 24 80 02 00 	mov    %r12,0x280(%rsp)
    c69e:	00 
    c69f:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    c6a6:	00 
    c6a7:	e8 a4 a2 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c6ac:	48 89 c7             	mov    %rax,%rdi
    c6af:	e8 0c a5 ff ff       	call   6bc0 <fwp_rc_fresh>
    c6b4:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    c6bb:	00 
    c6bc:	bf 01 00 00 00       	mov    $0x1,%edi
    c6c1:	4c 89 ac 24 90 02 00 	mov    %r13,0x290(%rsp)
    c6c8:	00 
    c6c9:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    c6d0:	00 
    c6d1:	e8 7a a2 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c6d6:	48 89 c7             	mov    %rax,%rdi
    c6d9:	e8 e2 a4 ff ff       	call   6bc0 <fwp_rc_fresh>
    c6de:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    c6e5:	00 
    c6e6:	bf 01 00 00 00       	mov    $0x1,%edi
    c6eb:	4c 89 a4 24 a0 02 00 	mov    %r12,0x2a0(%rsp)
    c6f2:	00 
    c6f3:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    c6fa:	00 
    c6fb:	e8 50 a2 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c700:	48 89 c7             	mov    %rax,%rdi
    c703:	e8 b8 a4 ff ff       	call   6bc0 <fwp_rc_fresh>
    c708:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    c70f:	00 
    c710:	bf 01 00 00 00       	mov    $0x1,%edi
    c715:	4c 89 ac 24 b0 02 00 	mov    %r13,0x2b0(%rsp)
    c71c:	00 
    c71d:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    c724:	00 
    c725:	e8 26 a2 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c72a:	48 89 c7             	mov    %rax,%rdi
    c72d:	e8 8e a4 ff ff       	call   6bc0 <fwp_rc_fresh>
    c732:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    c739:	00 
    c73a:	bf 01 00 00 00       	mov    $0x1,%edi
    c73f:	4c 89 a4 24 c0 02 00 	mov    %r12,0x2c0(%rsp)
    c746:	00 
    c747:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    c74e:	00 
    c74f:	e8 fc a1 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c754:	48 89 c7             	mov    %rax,%rdi
    c757:	e8 64 a4 ff ff       	call   6bc0 <fwp_rc_fresh>
    c75c:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    c763:	00 
    c764:	bf 01 00 00 00       	mov    $0x1,%edi
    c769:	4c 89 ac 24 d0 02 00 	mov    %r13,0x2d0(%rsp)
    c770:	00 
    c771:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    c778:	00 
    c779:	e8 d2 a1 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c77e:	48 89 c7             	mov    %rax,%rdi
    c781:	e8 3a a4 ff ff       	call   6bc0 <fwp_rc_fresh>
    c786:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    c78d:	00 
    c78e:	bf 01 00 00 00       	mov    $0x1,%edi
    c793:	4c 89 a4 24 e0 02 00 	mov    %r12,0x2e0(%rsp)
    c79a:	00 
    c79b:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    c7a2:	00 
    c7a3:	e8 a8 a1 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c7a8:	48 89 c7             	mov    %rax,%rdi
    c7ab:	e8 10 a4 ff ff       	call   6bc0 <fwp_rc_fresh>
    c7b0:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    c7b7:	00 
    c7b8:	bf 01 00 00 00       	mov    $0x1,%edi
    c7bd:	4c 89 ac 24 f0 02 00 	mov    %r13,0x2f0(%rsp)
    c7c4:	00 
    c7c5:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    c7cc:	00 
    c7cd:	e8 7e a1 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c7d2:	48 89 c7             	mov    %rax,%rdi
    c7d5:	e8 e6 a3 ff ff       	call   6bc0 <fwp_rc_fresh>
    c7da:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    c7e1:	00 
    c7e2:	bf 01 00 00 00       	mov    $0x1,%edi
    c7e7:	4c 89 a4 24 00 03 00 	mov    %r12,0x300(%rsp)
    c7ee:	00 
    c7ef:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    c7f6:	00 
    c7f7:	e8 54 a1 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c7fc:	48 89 c7             	mov    %rax,%rdi
    c7ff:	e8 bc a3 ff ff       	call   6bc0 <fwp_rc_fresh>
    c804:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    c80b:	00 
    c80c:	bf 01 00 00 00       	mov    $0x1,%edi
    c811:	4c 89 ac 24 10 03 00 	mov    %r13,0x310(%rsp)
    c818:	00 
    c819:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    c820:	00 
    c821:	e8 2a a1 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c826:	48 89 c7             	mov    %rax,%rdi
    c829:	e8 92 a3 ff ff       	call   6bc0 <fwp_rc_fresh>
    c82e:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    c835:	00 
    c836:	bf 01 00 00 00       	mov    $0x1,%edi
    c83b:	4c 89 a4 24 20 03 00 	mov    %r12,0x320(%rsp)
    c842:	00 
    c843:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    c84a:	00 
    c84b:	e8 00 a1 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c850:	48 89 c7             	mov    %rax,%rdi
    c853:	e8 68 a3 ff ff       	call   6bc0 <fwp_rc_fresh>
    c858:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    c85f:	00 
    c860:	bf 01 00 00 00       	mov    $0x1,%edi
    c865:	4c 89 ac 24 30 03 00 	mov    %r13,0x330(%rsp)
    c86c:	00 
    c86d:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    c874:	00 
    c875:	e8 d6 a0 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c87a:	48 89 c7             	mov    %rax,%rdi
    c87d:	e8 3e a3 ff ff       	call   6bc0 <fwp_rc_fresh>
    c882:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    c889:	00 
    c88a:	bf 01 00 00 00       	mov    $0x1,%edi
    c88f:	4c 89 a4 24 40 03 00 	mov    %r12,0x340(%rsp)
    c896:	00 
    c897:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    c89e:	00 
    c89f:	e8 ac a0 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c8a4:	48 89 c7             	mov    %rax,%rdi
    c8a7:	e8 14 a3 ff ff       	call   6bc0 <fwp_rc_fresh>
    c8ac:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    c8b3:	00 
    c8b4:	bf 01 00 00 00       	mov    $0x1,%edi
    c8b9:	4c 89 ac 24 50 03 00 	mov    %r13,0x350(%rsp)
    c8c0:	00 
    c8c1:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    c8c8:	00 
    c8c9:	e8 82 a0 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c8ce:	48 89 c7             	mov    %rax,%rdi
    c8d1:	e8 ea a2 ff ff       	call   6bc0 <fwp_rc_fresh>
    c8d6:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    c8dd:	00 
    c8de:	bf 01 00 00 00       	mov    $0x1,%edi
    c8e3:	4c 89 a4 24 60 03 00 	mov    %r12,0x360(%rsp)
    c8ea:	00 
    c8eb:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    c8f2:	00 
    c8f3:	e8 58 a0 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c8f8:	48 89 c7             	mov    %rax,%rdi
    c8fb:	e8 c0 a2 ff ff       	call   6bc0 <fwp_rc_fresh>
    c900:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    c907:	00 
    c908:	bf 01 00 00 00       	mov    $0x1,%edi
    c90d:	4c 89 ac 24 70 03 00 	mov    %r13,0x370(%rsp)
    c914:	00 
    c915:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    c91c:	00 
    c91d:	e8 2e a0 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c922:	48 89 c7             	mov    %rax,%rdi
    c925:	e8 96 a2 ff ff       	call   6bc0 <fwp_rc_fresh>
    c92a:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    c931:	00 
    c932:	bf 01 00 00 00       	mov    $0x1,%edi
    c937:	4c 89 a4 24 80 03 00 	mov    %r12,0x380(%rsp)
    c93e:	00 
    c93f:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    c946:	00 
    c947:	e8 04 a0 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c94c:	48 89 c7             	mov    %rax,%rdi
    c94f:	e8 6c a2 ff ff       	call   6bc0 <fwp_rc_fresh>
    c954:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    c95b:	00 
    c95c:	bf 01 00 00 00       	mov    $0x1,%edi
    c961:	4c 89 ac 24 90 03 00 	mov    %r13,0x390(%rsp)
    c968:	00 
    c969:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    c970:	00 
    c971:	e8 da 9f ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c976:	48 89 c7             	mov    %rax,%rdi
    c979:	e8 42 a2 ff ff       	call   6bc0 <fwp_rc_fresh>
    c97e:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    c985:	00 
    c986:	bf 01 00 00 00       	mov    $0x1,%edi
    c98b:	4c 89 a4 24 a0 03 00 	mov    %r12,0x3a0(%rsp)
    c992:	00 
    c993:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    c99a:	00 
    c99b:	e8 b0 9f ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c9a0:	48 89 c7             	mov    %rax,%rdi
    c9a3:	e8 18 a2 ff ff       	call   6bc0 <fwp_rc_fresh>
    c9a8:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    c9af:	00 
    c9b0:	bf 01 00 00 00       	mov    $0x1,%edi
    c9b5:	4c 89 ac 24 b0 03 00 	mov    %r13,0x3b0(%rsp)
    c9bc:	00 
    c9bd:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    c9c4:	00 
    c9c5:	e8 86 9f ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c9ca:	48 89 c7             	mov    %rax,%rdi
    c9cd:	e8 ee a1 ff ff       	call   6bc0 <fwp_rc_fresh>
    c9d2:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    c9d9:	00 
    c9da:	bf 01 00 00 00       	mov    $0x1,%edi
    c9df:	4c 89 a4 24 c0 03 00 	mov    %r12,0x3c0(%rsp)
    c9e6:	00 
    c9e7:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    c9ee:	00 
    c9ef:	e8 5c 9f ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    c9f4:	48 89 c7             	mov    %rax,%rdi
    c9f7:	e8 c4 a1 ff ff       	call   6bc0 <fwp_rc_fresh>
    c9fc:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    ca03:	00 
    ca04:	bf 01 00 00 00       	mov    $0x1,%edi
    ca09:	4c 89 ac 24 d0 03 00 	mov    %r13,0x3d0(%rsp)
    ca10:	00 
    ca11:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    ca18:	00 
    ca19:	e8 32 9f ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    ca1e:	48 89 c7             	mov    %rax,%rdi
    ca21:	e8 9a a1 ff ff       	call   6bc0 <fwp_rc_fresh>
    ca26:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    ca2d:	00 
    ca2e:	bf 01 00 00 00       	mov    $0x1,%edi
    ca33:	4c 89 a4 24 e0 03 00 	mov    %r12,0x3e0(%rsp)
    ca3a:	00 
    ca3b:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    ca42:	00 
    ca43:	e8 08 9f ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    ca48:	48 89 c7             	mov    %rax,%rdi
    ca4b:	e8 70 a1 ff ff       	call   6bc0 <fwp_rc_fresh>
    ca50:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    ca57:	00 
    ca58:	bf 01 00 00 00       	mov    $0x1,%edi
    ca5d:	4c 89 ac 24 f0 03 00 	mov    %r13,0x3f0(%rsp)
    ca64:	00 
    ca65:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    ca6c:	00 
    ca6d:	e8 de 9e ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    ca72:	48 89 c7             	mov    %rax,%rdi
    ca75:	e8 46 a1 ff ff       	call   6bc0 <fwp_rc_fresh>
    ca7a:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    ca81:	00 
    ca82:	bf 01 00 00 00       	mov    $0x1,%edi
    ca87:	4c 89 a4 24 00 04 00 	mov    %r12,0x400(%rsp)
    ca8e:	00 
    ca8f:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    ca96:	00 
    ca97:	e8 b4 9e ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    ca9c:	48 89 c7             	mov    %rax,%rdi
    ca9f:	e8 1c a1 ff ff       	call   6bc0 <fwp_rc_fresh>
    caa4:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    caab:	00 
    caac:	bf 01 00 00 00       	mov    $0x1,%edi
    cab1:	4c 89 ac 24 10 04 00 	mov    %r13,0x410(%rsp)
    cab8:	00 
    cab9:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    cac0:	00 
    cac1:	e8 8a 9e ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cac6:	48 89 c7             	mov    %rax,%rdi
    cac9:	e8 f2 a0 ff ff       	call   6bc0 <fwp_rc_fresh>
    cace:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    cad5:	00 
    cad6:	bf 01 00 00 00       	mov    $0x1,%edi
    cadb:	4c 89 a4 24 20 04 00 	mov    %r12,0x420(%rsp)
    cae2:	00 
    cae3:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    caea:	00 
    caeb:	e8 60 9e ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    caf0:	48 89 c7             	mov    %rax,%rdi
    caf3:	e8 c8 a0 ff ff       	call   6bc0 <fwp_rc_fresh>
    caf8:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    caff:	00 
    cb00:	bf 01 00 00 00       	mov    $0x1,%edi
    cb05:	4c 89 ac 24 30 04 00 	mov    %r13,0x430(%rsp)
    cb0c:	00 
    cb0d:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    cb14:	00 
    cb15:	e8 36 9e ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cb1a:	48 89 c7             	mov    %rax,%rdi
    cb1d:	e8 9e a0 ff ff       	call   6bc0 <fwp_rc_fresh>
    cb22:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    cb29:	00 
    cb2a:	bf 01 00 00 00       	mov    $0x1,%edi
    cb2f:	4c 89 a4 24 40 04 00 	mov    %r12,0x440(%rsp)
    cb36:	00 
    cb37:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    cb3e:	00 
    cb3f:	e8 0c 9e ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cb44:	48 89 c7             	mov    %rax,%rdi
    cb47:	e8 74 a0 ff ff       	call   6bc0 <fwp_rc_fresh>
    cb4c:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    cb53:	00 
    cb54:	bf 01 00 00 00       	mov    $0x1,%edi
    cb59:	4c 89 ac 24 50 04 00 	mov    %r13,0x450(%rsp)
    cb60:	00 
    cb61:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    cb68:	00 
    cb69:	e8 e2 9d ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cb6e:	48 89 c7             	mov    %rax,%rdi
    cb71:	e8 4a a0 ff ff       	call   6bc0 <fwp_rc_fresh>
    cb76:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    cb7d:	00 
    cb7e:	bf 01 00 00 00       	mov    $0x1,%edi
    cb83:	4c 89 a4 24 60 04 00 	mov    %r12,0x460(%rsp)
    cb8a:	00 
    cb8b:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    cb92:	00 
    cb93:	e8 b8 9d ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cb98:	48 89 c7             	mov    %rax,%rdi
    cb9b:	e8 20 a0 ff ff       	call   6bc0 <fwp_rc_fresh>
    cba0:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    cba7:	00 
    cba8:	bf 01 00 00 00       	mov    $0x1,%edi
    cbad:	4c 89 ac 24 70 04 00 	mov    %r13,0x470(%rsp)
    cbb4:	00 
    cbb5:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    cbbc:	00 
    cbbd:	e8 8e 9d ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cbc2:	48 89 c7             	mov    %rax,%rdi
    cbc5:	e8 f6 9f ff ff       	call   6bc0 <fwp_rc_fresh>
    cbca:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    cbd1:	00 
    cbd2:	bf 01 00 00 00       	mov    $0x1,%edi
    cbd7:	4c 89 a4 24 80 04 00 	mov    %r12,0x480(%rsp)
    cbde:	00 
    cbdf:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    cbe6:	00 
    cbe7:	e8 64 9d ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cbec:	48 89 c7             	mov    %rax,%rdi
    cbef:	e8 cc 9f ff ff       	call   6bc0 <fwp_rc_fresh>
    cbf4:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    cbfb:	00 
    cbfc:	bf 01 00 00 00       	mov    $0x1,%edi
    cc01:	4c 89 ac 24 90 04 00 	mov    %r13,0x490(%rsp)
    cc08:	00 
    cc09:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    cc10:	00 
    cc11:	e8 3a 9d ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cc16:	48 89 c7             	mov    %rax,%rdi
    cc19:	e8 a2 9f ff ff       	call   6bc0 <fwp_rc_fresh>
    cc1e:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    cc25:	00 
    cc26:	bf 01 00 00 00       	mov    $0x1,%edi
    cc2b:	4c 89 a4 24 a0 04 00 	mov    %r12,0x4a0(%rsp)
    cc32:	00 
    cc33:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    cc3a:	00 
    cc3b:	e8 10 9d ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cc40:	48 89 c7             	mov    %rax,%rdi
    cc43:	e8 78 9f ff ff       	call   6bc0 <fwp_rc_fresh>
    cc48:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    cc4f:	00 
    cc50:	bf 01 00 00 00       	mov    $0x1,%edi
    cc55:	4c 89 ac 24 b0 04 00 	mov    %r13,0x4b0(%rsp)
    cc5c:	00 
    cc5d:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    cc64:	00 
    cc65:	e8 e6 9c ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cc6a:	48 89 c7             	mov    %rax,%rdi
    cc6d:	e8 4e 9f ff ff       	call   6bc0 <fwp_rc_fresh>
    cc72:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    cc79:	00 
    cc7a:	bf 01 00 00 00       	mov    $0x1,%edi
    cc7f:	4c 89 a4 24 c0 04 00 	mov    %r12,0x4c0(%rsp)
    cc86:	00 
    cc87:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    cc8e:	00 
    cc8f:	e8 bc 9c ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cc94:	48 89 c7             	mov    %rax,%rdi
    cc97:	e8 24 9f ff ff       	call   6bc0 <fwp_rc_fresh>
    cc9c:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    cca3:	00 
    cca4:	bf 01 00 00 00       	mov    $0x1,%edi
    cca9:	4c 89 ac 24 d0 04 00 	mov    %r13,0x4d0(%rsp)
    ccb0:	00 
    ccb1:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    ccb8:	00 
    ccb9:	e8 92 9c ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    ccbe:	48 89 c7             	mov    %rax,%rdi
    ccc1:	e8 fa 9e ff ff       	call   6bc0 <fwp_rc_fresh>
    ccc6:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    cccd:	00 
    ccce:	bf 01 00 00 00       	mov    $0x1,%edi
    ccd3:	4c 89 a4 24 e0 04 00 	mov    %r12,0x4e0(%rsp)
    ccda:	00 
    ccdb:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    cce2:	00 
    cce3:	e8 68 9c ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cce8:	48 89 c7             	mov    %rax,%rdi
    cceb:	e8 d0 9e ff ff       	call   6bc0 <fwp_rc_fresh>
    ccf0:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    ccf7:	00 
    ccf8:	bf 01 00 00 00       	mov    $0x1,%edi
    ccfd:	4c 89 ac 24 f0 04 00 	mov    %r13,0x4f0(%rsp)
    cd04:	00 
    cd05:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    cd0c:	00 
    cd0d:	e8 3e 9c ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cd12:	48 89 c7             	mov    %rax,%rdi
    cd15:	e8 a6 9e ff ff       	call   6bc0 <fwp_rc_fresh>
    cd1a:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    cd21:	00 
    cd22:	bf 01 00 00 00       	mov    $0x1,%edi
    cd27:	4c 89 a4 24 00 05 00 	mov    %r12,0x500(%rsp)
    cd2e:	00 
    cd2f:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    cd36:	00 
    cd37:	e8 14 9c ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cd3c:	48 89 c7             	mov    %rax,%rdi
    cd3f:	e8 7c 9e ff ff       	call   6bc0 <fwp_rc_fresh>
    cd44:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    cd4b:	00 
    cd4c:	bf 01 00 00 00       	mov    $0x1,%edi
    cd51:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
    cd58:	00 
    cd59:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    cd60:	00 
    cd61:	e8 ea 9b ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cd66:	48 89 c7             	mov    %rax,%rdi
    cd69:	e8 52 9e ff ff       	call   6bc0 <fwp_rc_fresh>
    cd6e:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    cd75:	00 
    cd76:	bf 01 00 00 00       	mov    $0x1,%edi
    cd7b:	4c 89 a4 24 20 05 00 	mov    %r12,0x520(%rsp)
    cd82:	00 
    cd83:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    cd8a:	00 
    cd8b:	e8 c0 9b ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cd90:	48 89 c7             	mov    %rax,%rdi
    cd93:	e8 28 9e ff ff       	call   6bc0 <fwp_rc_fresh>
    cd98:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    cd9f:	00 
    cda0:	bf 01 00 00 00       	mov    $0x1,%edi
    cda5:	4c 89 ac 24 30 05 00 	mov    %r13,0x530(%rsp)
    cdac:	00 
    cdad:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    cdb4:	00 
    cdb5:	e8 96 9b ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cdba:	48 89 c7             	mov    %rax,%rdi
    cdbd:	e8 fe 9d ff ff       	call   6bc0 <fwp_rc_fresh>
    cdc2:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    cdc9:	00 
    cdca:	bf 01 00 00 00       	mov    $0x1,%edi
    cdcf:	4c 89 a4 24 40 05 00 	mov    %r12,0x540(%rsp)
    cdd6:	00 
    cdd7:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    cdde:	00 
    cddf:	e8 6c 9b ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cde4:	48 89 c7             	mov    %rax,%rdi
    cde7:	e8 d4 9d ff ff       	call   6bc0 <fwp_rc_fresh>
    cdec:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    cdf3:	00 
    cdf4:	bf 01 00 00 00       	mov    $0x1,%edi
    cdf9:	4c 89 ac 24 50 05 00 	mov    %r13,0x550(%rsp)
    ce00:	00 
    ce01:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    ce08:	00 
    ce09:	e8 42 9b ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    ce0e:	48 89 c7             	mov    %rax,%rdi
    ce11:	e8 aa 9d ff ff       	call   6bc0 <fwp_rc_fresh>
    ce16:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    ce1d:	00 
    ce1e:	bf 01 00 00 00       	mov    $0x1,%edi
    ce23:	4c 89 a4 24 60 05 00 	mov    %r12,0x560(%rsp)
    ce2a:	00 
    ce2b:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    ce32:	00 
    ce33:	e8 18 9b ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    ce38:	48 89 c7             	mov    %rax,%rdi
    ce3b:	e8 80 9d ff ff       	call   6bc0 <fwp_rc_fresh>
    ce40:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    ce47:	00 
    ce48:	bf 01 00 00 00       	mov    $0x1,%edi
    ce4d:	4c 89 ac 24 70 05 00 	mov    %r13,0x570(%rsp)
    ce54:	00 
    ce55:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    ce5c:	00 
    ce5d:	e8 ee 9a ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    ce62:	48 89 c7             	mov    %rax,%rdi
    ce65:	e8 56 9d ff ff       	call   6bc0 <fwp_rc_fresh>
    ce6a:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    ce71:	00 
    ce72:	bf 01 00 00 00       	mov    $0x1,%edi
    ce77:	4c 89 a4 24 80 05 00 	mov    %r12,0x580(%rsp)
    ce7e:	00 
    ce7f:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    ce86:	00 
    ce87:	e8 c4 9a ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    ce8c:	48 89 c7             	mov    %rax,%rdi
    ce8f:	e8 2c 9d ff ff       	call   6bc0 <fwp_rc_fresh>
    ce94:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    ce9b:	00 
    ce9c:	bf 01 00 00 00       	mov    $0x1,%edi
    cea1:	4c 89 ac 24 90 05 00 	mov    %r13,0x590(%rsp)
    cea8:	00 
    cea9:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    ceb0:	00 
    ceb1:	e8 9a 9a ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    ceb6:	48 89 c7             	mov    %rax,%rdi
    ceb9:	e8 02 9d ff ff       	call   6bc0 <fwp_rc_fresh>
    cebe:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    cec5:	00 
    cec6:	bf 01 00 00 00       	mov    $0x1,%edi
    cecb:	4c 89 a4 24 a0 05 00 	mov    %r12,0x5a0(%rsp)
    ced2:	00 
    ced3:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    ceda:	00 
    cedb:	e8 70 9a ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cee0:	48 89 c7             	mov    %rax,%rdi
    cee3:	e8 d8 9c ff ff       	call   6bc0 <fwp_rc_fresh>
    cee8:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    ceef:	00 
    cef0:	bf 01 00 00 00       	mov    $0x1,%edi
    cef5:	4c 89 ac 24 b0 05 00 	mov    %r13,0x5b0(%rsp)
    cefc:	00 
    cefd:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    cf04:	00 
    cf05:	e8 46 9a ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cf0a:	48 89 c7             	mov    %rax,%rdi
    cf0d:	e8 ae 9c ff ff       	call   6bc0 <fwp_rc_fresh>
    cf12:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    cf19:	00 
    cf1a:	bf 01 00 00 00       	mov    $0x1,%edi
    cf1f:	4c 89 a4 24 c0 05 00 	mov    %r12,0x5c0(%rsp)
    cf26:	00 
    cf27:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    cf2e:	00 
    cf2f:	e8 1c 9a ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cf34:	48 89 c7             	mov    %rax,%rdi
    cf37:	e8 84 9c ff ff       	call   6bc0 <fwp_rc_fresh>
    cf3c:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    cf43:	00 
    cf44:	bf 01 00 00 00       	mov    $0x1,%edi
    cf49:	4c 89 ac 24 d0 05 00 	mov    %r13,0x5d0(%rsp)
    cf50:	00 
    cf51:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    cf58:	00 
    cf59:	e8 f2 99 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cf5e:	48 89 c7             	mov    %rax,%rdi
    cf61:	e8 5a 9c ff ff       	call   6bc0 <fwp_rc_fresh>
    cf66:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    cf6d:	00 
    cf6e:	bf 01 00 00 00       	mov    $0x1,%edi
    cf73:	4c 89 a4 24 e0 05 00 	mov    %r12,0x5e0(%rsp)
    cf7a:	00 
    cf7b:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    cf82:	00 
    cf83:	e8 c8 99 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cf88:	48 89 c7             	mov    %rax,%rdi
    cf8b:	e8 30 9c ff ff       	call   6bc0 <fwp_rc_fresh>
    cf90:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    cf97:	00 
    cf98:	bf 01 00 00 00       	mov    $0x1,%edi
    cf9d:	4c 89 ac 24 f0 05 00 	mov    %r13,0x5f0(%rsp)
    cfa4:	00 
    cfa5:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    cfac:	00 
    cfad:	e8 9e 99 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cfb2:	48 89 c7             	mov    %rax,%rdi
    cfb5:	e8 06 9c ff ff       	call   6bc0 <fwp_rc_fresh>
    cfba:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    cfc1:	00 
    cfc2:	bf 01 00 00 00       	mov    $0x1,%edi
    cfc7:	4c 89 a4 24 00 06 00 	mov    %r12,0x600(%rsp)
    cfce:	00 
    cfcf:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    cfd6:	00 
    cfd7:	e8 74 99 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    cfdc:	48 89 c7             	mov    %rax,%rdi
    cfdf:	e8 dc 9b ff ff       	call   6bc0 <fwp_rc_fresh>
    cfe4:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    cfeb:	00 
    cfec:	bf 01 00 00 00       	mov    $0x1,%edi
    cff1:	4c 89 ac 24 10 06 00 	mov    %r13,0x610(%rsp)
    cff8:	00 
    cff9:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    d000:	00 
    d001:	e8 4a 99 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    d006:	48 89 c7             	mov    %rax,%rdi
    d009:	e8 b2 9b ff ff       	call   6bc0 <fwp_rc_fresh>
    d00e:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    d015:	00 
    d016:	bf 01 00 00 00       	mov    $0x1,%edi
    d01b:	4c 89 a4 24 20 06 00 	mov    %r12,0x620(%rsp)
    d022:	00 
    d023:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    d02a:	00 
    d02b:	e8 20 99 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    d030:	48 89 c7             	mov    %rax,%rdi
    d033:	e8 88 9b ff ff       	call   6bc0 <fwp_rc_fresh>
    d038:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    d03f:	00 
    d040:	bf 01 00 00 00       	mov    $0x1,%edi
    d045:	4c 89 ac 24 30 06 00 	mov    %r13,0x630(%rsp)
    d04c:	00 
    d04d:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    d054:	00 
    d055:	e8 f6 98 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    d05a:	48 89 c7             	mov    %rax,%rdi
    d05d:	e8 5e 9b ff ff       	call   6bc0 <fwp_rc_fresh>
    d062:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    d069:	00 
    d06a:	bf 01 00 00 00       	mov    $0x1,%edi
    d06f:	4c 89 a4 24 40 06 00 	mov    %r12,0x640(%rsp)
    d076:	00 
    d077:	48 89 84 24 48 06 00 	mov    %rax,0x648(%rsp)
    d07e:	00 
    d07f:	e8 cc 98 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    d084:	48 8b 15 ad 0b 06 00 	mov    0x60bad(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    d08b:	49 89 c5             	mov    %rax,%r13
    d08e:	48 2b 05 7b 0b 06 00 	sub    0x60b7b(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    d095:	48 c1 e2 10          	shl    $0x10,%rdx
    d099:	48 39 d0             	cmp    %rdx,%rax
    d09c:	73 59                	jae    d0f7 <f0+0x1457>
    d09e:	48 89 c2             	mov    %rax,%rdx
    d0a1:	48 c1 ea 10          	shr    $0x10,%rdx
    d0a5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0a9:	48 8b 15 a8 0b 06 00 	mov    0x60ba8(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    d0b0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d0b4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d0b8:	4d 85 e4             	test   %r12,%r12
    d0bb:	74 3a                	je     d0f7 <f0+0x1457>
    d0bd:	0f b6 0a             	movzbl (%rdx),%ecx
    d0c0:	80 f9 02             	cmp    $0x2,%cl
    d0c3:	0f 84 17 15 00 00    	je     e5e0 <f0+0x2940>
    d0c9:	80 f9 01             	cmp    $0x1,%cl
    d0cc:	75 29                	jne    d0f7 <f0+0x1457>
    d0ce:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d0d1:	0f b7 c0             	movzwl %ax,%eax
    d0d4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d0d7:	48 0f af c1          	imul   %rcx,%rax
    d0db:	48 c1 e8 20          	shr    $0x20,%rax
    d0df:	48 39 d0             	cmp    %rdx,%rax
    d0e2:	73 13                	jae    d0f7 <f0+0x1457>
    d0e4:	49 01 c4             	add    %rax,%r12
    d0e7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d0ec:	0f 84 07 17 00 00    	je     e7f9 <f0+0x2b59>
    d0f2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0f7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d0fe:	00 f0 3f 
    d101:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    d108:	00 
    d109:	bf 01 00 00 00       	mov    $0x1,%edi
    d10e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    d115:	00 
    d116:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    d11d:	00 
    d11e:	e8 2d 98 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    d123:	48 8b 15 0e 0b 06 00 	mov    0x60b0e(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    d12a:	49 89 c5             	mov    %rax,%r13
    d12d:	48 2b 05 dc 0a 06 00 	sub    0x60adc(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    d134:	48 c1 e2 10          	shl    $0x10,%rdx
    d138:	48 39 d0             	cmp    %rdx,%rax
    d13b:	73 59                	jae    d196 <f0+0x14f6>
    d13d:	48 89 c2             	mov    %rax,%rdx
    d140:	48 c1 ea 10          	shr    $0x10,%rdx
    d144:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d148:	48 8b 15 09 0b 06 00 	mov    0x60b09(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    d14f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d153:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d157:	4d 85 e4             	test   %r12,%r12
    d15a:	74 3a                	je     d196 <f0+0x14f6>
    d15c:	0f b6 0a             	movzbl (%rdx),%ecx
    d15f:	80 f9 02             	cmp    $0x2,%cl
    d162:	0f 84 28 15 00 00    	je     e690 <f0+0x29f0>
    d168:	80 f9 01             	cmp    $0x1,%cl
    d16b:	75 29                	jne    d196 <f0+0x14f6>
    d16d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d170:	0f b7 c0             	movzwl %ax,%eax
    d173:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d176:	48 0f af c1          	imul   %rcx,%rax
    d17a:	48 c1 e8 20          	shr    $0x20,%rax
    d17e:	48 39 d0             	cmp    %rdx,%rax
    d181:	73 13                	jae    d196 <f0+0x14f6>
    d183:	49 01 c4             	add    %rax,%r12
    d186:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d18b:	0f 84 75 16 00 00    	je     e806 <f0+0x2b66>
    d191:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d196:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d19d:	33 f3 bf 
    d1a0:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    d1a7:	00 
    d1a8:	bf 01 00 00 00       	mov    $0x1,%edi
    d1ad:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    d1b4:	00 
    d1b5:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    d1bc:	00 
    d1bd:	e8 8e 97 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    d1c2:	48 8b 15 6f 0a 06 00 	mov    0x60a6f(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    d1c9:	49 89 c5             	mov    %rax,%r13
    d1cc:	48 2b 05 3d 0a 06 00 	sub    0x60a3d(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    d1d3:	48 c1 e2 10          	shl    $0x10,%rdx
    d1d7:	48 39 d0             	cmp    %rdx,%rax
    d1da:	73 59                	jae    d235 <f0+0x1595>
    d1dc:	48 89 c2             	mov    %rax,%rdx
    d1df:	48 c1 ea 10          	shr    $0x10,%rdx
    d1e3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d1e7:	48 8b 15 6a 0a 06 00 	mov    0x60a6a(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    d1ee:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d1f2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d1f6:	4d 85 e4             	test   %r12,%r12
    d1f9:	74 3a                	je     d235 <f0+0x1595>
    d1fb:	0f b6 0a             	movzbl (%rdx),%ecx
    d1fe:	80 f9 02             	cmp    $0x2,%cl
    d201:	0f 84 79 14 00 00    	je     e680 <f0+0x29e0>
    d207:	80 f9 01             	cmp    $0x1,%cl
    d20a:	75 29                	jne    d235 <f0+0x1595>
    d20c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d20f:	0f b7 c0             	movzwl %ax,%eax
    d212:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d215:	48 0f af c1          	imul   %rcx,%rax
    d219:	48 c1 e8 20          	shr    $0x20,%rax
    d21d:	48 39 d0             	cmp    %rdx,%rax
    d220:	73 13                	jae    d235 <f0+0x1595>
    d222:	49 01 c4             	add    %rax,%r12
    d225:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d22a:	0f 84 e3 15 00 00    	je     e813 <f0+0x2b73>
    d230:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d235:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d23c:	00 f0 3f 
    d23f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    d246:	00 
    d247:	bf 01 00 00 00       	mov    $0x1,%edi
    d24c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    d253:	00 
    d254:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    d25b:	00 
    d25c:	e8 ef 96 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    d261:	48 8b 15 d0 09 06 00 	mov    0x609d0(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    d268:	49 89 c5             	mov    %rax,%r13
    d26b:	48 2b 05 9e 09 06 00 	sub    0x6099e(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    d272:	48 c1 e2 10          	shl    $0x10,%rdx
    d276:	48 39 d0             	cmp    %rdx,%rax
    d279:	73 59                	jae    d2d4 <f0+0x1634>
    d27b:	48 89 c2             	mov    %rax,%rdx
    d27e:	48 c1 ea 10          	shr    $0x10,%rdx
    d282:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d286:	48 8b 15 cb 09 06 00 	mov    0x609cb(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    d28d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d291:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d295:	4d 85 e4             	test   %r12,%r12
    d298:	74 3a                	je     d2d4 <f0+0x1634>
    d29a:	0f b6 0a             	movzbl (%rdx),%ecx
    d29d:	80 f9 02             	cmp    $0x2,%cl
    d2a0:	0f 84 ca 13 00 00    	je     e670 <f0+0x29d0>
    d2a6:	80 f9 01             	cmp    $0x1,%cl
    d2a9:	75 29                	jne    d2d4 <f0+0x1634>
    d2ab:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2ae:	0f b7 c0             	movzwl %ax,%eax
    d2b1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d2b4:	48 0f af c1          	imul   %rcx,%rax
    d2b8:	48 c1 e8 20          	shr    $0x20,%rax
    d2bc:	48 39 d0             	cmp    %rdx,%rax
    d2bf:	73 13                	jae    d2d4 <f0+0x1634>
    d2c1:	49 01 c4             	add    %rax,%r12
    d2c4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d2c9:	0f 84 51 15 00 00    	je     e820 <f0+0x2b80>
    d2cf:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d2d4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d2db:	33 f3 bf 
    d2de:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    d2e5:	00 
    d2e6:	bf 01 00 00 00       	mov    $0x1,%edi
    d2eb:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    d2f2:	00 
    d2f3:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    d2fa:	00 
    d2fb:	e8 50 96 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    d300:	48 8b 15 31 09 06 00 	mov    0x60931(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    d307:	49 89 c5             	mov    %rax,%r13
    d30a:	48 2b 05 ff 08 06 00 	sub    0x608ff(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    d311:	48 c1 e2 10          	shl    $0x10,%rdx
    d315:	48 39 d0             	cmp    %rdx,%rax
    d318:	73 59                	jae    d373 <f0+0x16d3>
    d31a:	48 89 c2             	mov    %rax,%rdx
    d31d:	48 c1 ea 10          	shr    $0x10,%rdx
    d321:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d325:	48 8b 15 2c 09 06 00 	mov    0x6092c(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    d32c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d330:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d334:	4d 85 e4             	test   %r12,%r12
    d337:	74 3a                	je     d373 <f0+0x16d3>
    d339:	0f b6 0a             	movzbl (%rdx),%ecx
    d33c:	80 f9 02             	cmp    $0x2,%cl
    d33f:	0f 84 1b 13 00 00    	je     e660 <f0+0x29c0>
    d345:	80 f9 01             	cmp    $0x1,%cl
    d348:	75 29                	jne    d373 <f0+0x16d3>
    d34a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d34d:	0f b7 c0             	movzwl %ax,%eax
    d350:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d353:	48 0f af c1          	imul   %rcx,%rax
    d357:	48 c1 e8 20          	shr    $0x20,%rax
    d35b:	48 39 d0             	cmp    %rdx,%rax
    d35e:	73 13                	jae    d373 <f0+0x16d3>
    d360:	49 01 c4             	add    %rax,%r12
    d363:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d368:	0f 84 bf 14 00 00    	je     e82d <f0+0x2b8d>
    d36e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d373:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d37a:	00 f0 3f 
    d37d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    d384:	00 
    d385:	bf 01 00 00 00       	mov    $0x1,%edi
    d38a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    d391:	00 
    d392:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    d399:	00 
    d39a:	e8 b1 95 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    d39f:	48 8b 15 92 08 06 00 	mov    0x60892(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    d3a6:	49 89 c5             	mov    %rax,%r13
    d3a9:	48 2b 05 60 08 06 00 	sub    0x60860(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    d3b0:	48 c1 e2 10          	shl    $0x10,%rdx
    d3b4:	48 39 d0             	cmp    %rdx,%rax
    d3b7:	73 59                	jae    d412 <f0+0x1772>
    d3b9:	48 89 c2             	mov    %rax,%rdx
    d3bc:	48 c1 ea 10          	shr    $0x10,%rdx
    d3c0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d3c4:	48 8b 15 8d 08 06 00 	mov    0x6088d(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    d3cb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d3cf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d3d3:	4d 85 e4             	test   %r12,%r12
    d3d6:	74 3a                	je     d412 <f0+0x1772>
    d3d8:	0f b6 0a             	movzbl (%rdx),%ecx
    d3db:	80 f9 02             	cmp    $0x2,%cl
    d3de:	0f 84 6c 12 00 00    	je     e650 <f0+0x29b0>
    d3e4:	80 f9 01             	cmp    $0x1,%cl
    d3e7:	75 29                	jne    d412 <f0+0x1772>
    d3e9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d3ec:	0f b7 c0             	movzwl %ax,%eax
    d3ef:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d3f2:	48 0f af c1          	imul   %rcx,%rax
    d3f6:	48 c1 e8 20          	shr    $0x20,%rax
    d3fa:	48 39 d0             	cmp    %rdx,%rax
    d3fd:	73 13                	jae    d412 <f0+0x1772>
    d3ff:	49 01 c4             	add    %rax,%r12
    d402:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d407:	0f 84 2d 14 00 00    	je     e83a <f0+0x2b9a>
    d40d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d412:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d419:	33 f3 bf 
    d41c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    d423:	00 
    d424:	bf 01 00 00 00       	mov    $0x1,%edi
    d429:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    d430:	00 
    d431:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    d438:	00 
    d439:	e8 12 95 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    d43e:	48 8b 15 f3 07 06 00 	mov    0x607f3(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    d445:	49 89 c5             	mov    %rax,%r13
    d448:	48 2b 05 c1 07 06 00 	sub    0x607c1(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    d44f:	48 c1 e2 10          	shl    $0x10,%rdx
    d453:	48 39 d0             	cmp    %rdx,%rax
    d456:	73 59                	jae    d4b1 <f0+0x1811>
    d458:	48 89 c2             	mov    %rax,%rdx
    d45b:	48 c1 ea 10          	shr    $0x10,%rdx
    d45f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d463:	48 8b 15 ee 07 06 00 	mov    0x607ee(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    d46a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d46e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d472:	4d 85 e4             	test   %r12,%r12
    d475:	74 3a                	je     d4b1 <f0+0x1811>
    d477:	0f b6 0a             	movzbl (%rdx),%ecx
    d47a:	80 f9 02             	cmp    $0x2,%cl
    d47d:	0f 84 bd 11 00 00    	je     e640 <f0+0x29a0>
    d483:	80 f9 01             	cmp    $0x1,%cl
    d486:	75 29                	jne    d4b1 <f0+0x1811>
    d488:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d48b:	0f b7 c0             	movzwl %ax,%eax
    d48e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d491:	48 0f af c1          	imul   %rcx,%rax
    d495:	48 c1 e8 20          	shr    $0x20,%rax
    d499:	48 39 d0             	cmp    %rdx,%rax
    d49c:	73 13                	jae    d4b1 <f0+0x1811>
    d49e:	49 01 c4             	add    %rax,%r12
    d4a1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d4a6:	0f 84 9b 13 00 00    	je     e847 <f0+0x2ba7>
    d4ac:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d4b1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d4b8:	00 f0 3f 
    d4bb:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    d4c2:	00 
    d4c3:	bf 01 00 00 00       	mov    $0x1,%edi
    d4c8:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    d4cf:	00 
    d4d0:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    d4d7:	00 
    d4d8:	e8 73 94 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    d4dd:	48 8b 15 54 07 06 00 	mov    0x60754(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    d4e4:	49 89 c5             	mov    %rax,%r13
    d4e7:	48 2b 05 22 07 06 00 	sub    0x60722(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    d4ee:	48 c1 e2 10          	shl    $0x10,%rdx
    d4f2:	48 39 d0             	cmp    %rdx,%rax
    d4f5:	73 59                	jae    d550 <f0+0x18b0>
    d4f7:	48 89 c2             	mov    %rax,%rdx
    d4fa:	48 c1 ea 10          	shr    $0x10,%rdx
    d4fe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d502:	48 8b 15 4f 07 06 00 	mov    0x6074f(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    d509:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d50d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d511:	4d 85 e4             	test   %r12,%r12
    d514:	74 3a                	je     d550 <f0+0x18b0>
    d516:	0f b6 0a             	movzbl (%rdx),%ecx
    d519:	80 f9 02             	cmp    $0x2,%cl
    d51c:	0f 84 0e 11 00 00    	je     e630 <f0+0x2990>
    d522:	80 f9 01             	cmp    $0x1,%cl
    d525:	75 29                	jne    d550 <f0+0x18b0>
    d527:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d52a:	0f b7 c0             	movzwl %ax,%eax
    d52d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d530:	48 0f af c1          	imul   %rcx,%rax
    d534:	48 c1 e8 20          	shr    $0x20,%rax
    d538:	48 39 d0             	cmp    %rdx,%rax
    d53b:	73 13                	jae    d550 <f0+0x18b0>
    d53d:	49 01 c4             	add    %rax,%r12
    d540:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d545:	0f 84 09 13 00 00    	je     e854 <f0+0x2bb4>
    d54b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d550:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d557:	33 f3 bf 
    d55a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    d561:	00 
    d562:	bf 01 00 00 00       	mov    $0x1,%edi
    d567:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    d56e:	00 
    d56f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    d576:	00 
    d577:	e8 d4 93 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    d57c:	48 8b 15 b5 06 06 00 	mov    0x606b5(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    d583:	49 89 c5             	mov    %rax,%r13
    d586:	48 2b 05 83 06 06 00 	sub    0x60683(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    d58d:	48 c1 e2 10          	shl    $0x10,%rdx
    d591:	48 39 d0             	cmp    %rdx,%rax
    d594:	73 59                	jae    d5ef <f0+0x194f>
    d596:	48 89 c2             	mov    %rax,%rdx
    d599:	48 c1 ea 10          	shr    $0x10,%rdx
    d59d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d5a1:	48 8b 15 b0 06 06 00 	mov    0x606b0(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    d5a8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d5ac:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d5b0:	4d 85 e4             	test   %r12,%r12
    d5b3:	74 3a                	je     d5ef <f0+0x194f>
    d5b5:	0f b6 0a             	movzbl (%rdx),%ecx
    d5b8:	80 f9 02             	cmp    $0x2,%cl
    d5bb:	0f 84 5f 10 00 00    	je     e620 <f0+0x2980>
    d5c1:	80 f9 01             	cmp    $0x1,%cl
    d5c4:	75 29                	jne    d5ef <f0+0x194f>
    d5c6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d5c9:	0f b7 c0             	movzwl %ax,%eax
    d5cc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d5cf:	48 0f af c1          	imul   %rcx,%rax
    d5d3:	48 c1 e8 20          	shr    $0x20,%rax
    d5d7:	48 39 d0             	cmp    %rdx,%rax
    d5da:	73 13                	jae    d5ef <f0+0x194f>
    d5dc:	49 01 c4             	add    %rax,%r12
    d5df:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d5e4:	0f 84 77 12 00 00    	je     e861 <f0+0x2bc1>
    d5ea:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d5ef:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d5f6:	00 f0 3f 
    d5f9:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    d600:	00 
    d601:	bf 01 00 00 00       	mov    $0x1,%edi
    d606:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    d60d:	00 
    d60e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    d615:	00 
    d616:	e8 35 93 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    d61b:	48 8b 15 16 06 06 00 	mov    0x60616(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    d622:	49 89 c5             	mov    %rax,%r13
    d625:	48 2b 05 e4 05 06 00 	sub    0x605e4(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    d62c:	48 c1 e2 10          	shl    $0x10,%rdx
    d630:	48 39 d0             	cmp    %rdx,%rax
    d633:	73 59                	jae    d68e <f0+0x19ee>
    d635:	48 89 c2             	mov    %rax,%rdx
    d638:	48 c1 ea 10          	shr    $0x10,%rdx
    d63c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d640:	48 8b 15 11 06 06 00 	mov    0x60611(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    d647:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d64b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d64f:	4d 85 e4             	test   %r12,%r12
    d652:	74 3a                	je     d68e <f0+0x19ee>
    d654:	0f b6 0a             	movzbl (%rdx),%ecx
    d657:	80 f9 02             	cmp    $0x2,%cl
    d65a:	0f 84 40 0f 00 00    	je     e5a0 <f0+0x2900>
    d660:	80 f9 01             	cmp    $0x1,%cl
    d663:	75 29                	jne    d68e <f0+0x19ee>
    d665:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d668:	0f b7 c0             	movzwl %ax,%eax
    d66b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d66e:	48 0f af c1          	imul   %rcx,%rax
    d672:	48 c1 e8 20          	shr    $0x20,%rax
    d676:	48 39 d0             	cmp    %rdx,%rax
    d679:	73 13                	jae    d68e <f0+0x19ee>
    d67b:	49 01 c4             	add    %rax,%r12
    d67e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d683:	0f 84 e5 11 00 00    	je     e86e <f0+0x2bce>
    d689:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d68e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d695:	33 f3 bf 
    d698:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    d69f:	00 
    d6a0:	bf 01 00 00 00       	mov    $0x1,%edi
    d6a5:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    d6ac:	00 
    d6ad:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    d6b4:	00 
    d6b5:	e8 96 92 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    d6ba:	48 8b 15 77 05 06 00 	mov    0x60577(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    d6c1:	49 89 c5             	mov    %rax,%r13
    d6c4:	48 2b 05 45 05 06 00 	sub    0x60545(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    d6cb:	48 c1 e2 10          	shl    $0x10,%rdx
    d6cf:	48 39 d0             	cmp    %rdx,%rax
    d6d2:	73 59                	jae    d72d <f0+0x1a8d>
    d6d4:	48 89 c2             	mov    %rax,%rdx
    d6d7:	48 c1 ea 10          	shr    $0x10,%rdx
    d6db:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d6df:	48 8b 15 72 05 06 00 	mov    0x60572(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    d6e6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d6ea:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d6ee:	4d 85 e4             	test   %r12,%r12
    d6f1:	74 3a                	je     d72d <f0+0x1a8d>
    d6f3:	0f b6 0a             	movzbl (%rdx),%ecx
    d6f6:	80 f9 02             	cmp    $0x2,%cl
    d6f9:	0f 84 91 0e 00 00    	je     e590 <f0+0x28f0>
    d6ff:	80 f9 01             	cmp    $0x1,%cl
    d702:	75 29                	jne    d72d <f0+0x1a8d>
    d704:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d707:	0f b7 c0             	movzwl %ax,%eax
    d70a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d70d:	48 0f af c1          	imul   %rcx,%rax
    d711:	48 c1 e8 20          	shr    $0x20,%rax
    d715:	48 39 d0             	cmp    %rdx,%rax
    d718:	73 13                	jae    d72d <f0+0x1a8d>
    d71a:	49 01 c4             	add    %rax,%r12
    d71d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d722:	0f 84 53 11 00 00    	je     e87b <f0+0x2bdb>
    d728:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d72d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d734:	00 f0 3f 
    d737:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    d73e:	00 
    d73f:	bf 01 00 00 00       	mov    $0x1,%edi
    d744:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    d74b:	00 
    d74c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    d753:	00 
    d754:	e8 f7 91 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    d759:	48 8b 15 d8 04 06 00 	mov    0x604d8(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    d760:	49 89 c5             	mov    %rax,%r13
    d763:	48 2b 05 a6 04 06 00 	sub    0x604a6(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    d76a:	48 c1 e2 10          	shl    $0x10,%rdx
    d76e:	48 39 d0             	cmp    %rdx,%rax
    d771:	73 59                	jae    d7cc <f0+0x1b2c>
    d773:	48 89 c2             	mov    %rax,%rdx
    d776:	48 c1 ea 10          	shr    $0x10,%rdx
    d77a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d77e:	48 8b 15 d3 04 06 00 	mov    0x604d3(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    d785:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d789:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d78d:	4d 85 e4             	test   %r12,%r12
    d790:	74 3a                	je     d7cc <f0+0x1b2c>
    d792:	0f b6 0a             	movzbl (%rdx),%ecx
    d795:	80 f9 02             	cmp    $0x2,%cl
    d798:	0f 84 e2 0d 00 00    	je     e580 <f0+0x28e0>
    d79e:	80 f9 01             	cmp    $0x1,%cl
    d7a1:	75 29                	jne    d7cc <f0+0x1b2c>
    d7a3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d7a6:	0f b7 c0             	movzwl %ax,%eax
    d7a9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d7ac:	48 0f af c1          	imul   %rcx,%rax
    d7b0:	48 c1 e8 20          	shr    $0x20,%rax
    d7b4:	48 39 d0             	cmp    %rdx,%rax
    d7b7:	73 13                	jae    d7cc <f0+0x1b2c>
    d7b9:	49 01 c4             	add    %rax,%r12
    d7bc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d7c1:	0f 84 c1 10 00 00    	je     e888 <f0+0x2be8>
    d7c7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d7cc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d7d3:	33 f3 bf 
    d7d6:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    d7dd:	00 
    d7de:	bf 01 00 00 00       	mov    $0x1,%edi
    d7e3:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    d7ea:	00 
    d7eb:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    d7f2:	00 
    d7f3:	e8 58 91 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    d7f8:	48 8b 15 39 04 06 00 	mov    0x60439(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    d7ff:	49 89 c5             	mov    %rax,%r13
    d802:	48 2b 05 07 04 06 00 	sub    0x60407(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    d809:	48 c1 e2 10          	shl    $0x10,%rdx
    d80d:	48 39 d0             	cmp    %rdx,%rax
    d810:	73 59                	jae    d86b <f0+0x1bcb>
    d812:	48 89 c2             	mov    %rax,%rdx
    d815:	48 c1 ea 10          	shr    $0x10,%rdx
    d819:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d81d:	48 8b 15 34 04 06 00 	mov    0x60434(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    d824:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d828:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d82c:	4d 85 e4             	test   %r12,%r12
    d82f:	74 3a                	je     d86b <f0+0x1bcb>
    d831:	0f b6 0a             	movzbl (%rdx),%ecx
    d834:	80 f9 02             	cmp    $0x2,%cl
    d837:	0f 84 33 0d 00 00    	je     e570 <f0+0x28d0>
    d83d:	80 f9 01             	cmp    $0x1,%cl
    d840:	75 29                	jne    d86b <f0+0x1bcb>
    d842:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d845:	0f b7 c0             	movzwl %ax,%eax
    d848:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d84b:	48 0f af c1          	imul   %rcx,%rax
    d84f:	48 c1 e8 20          	shr    $0x20,%rax
    d853:	48 39 d0             	cmp    %rdx,%rax
    d856:	73 13                	jae    d86b <f0+0x1bcb>
    d858:	49 01 c4             	add    %rax,%r12
    d85b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d860:	0f 84 2f 10 00 00    	je     e895 <f0+0x2bf5>
    d866:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d86b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d872:	00 f0 3f 
    d875:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    d87c:	00 
    d87d:	bf 01 00 00 00       	mov    $0x1,%edi
    d882:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    d889:	00 
    d88a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    d891:	00 
    d892:	e8 b9 90 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    d897:	48 8b 15 9a 03 06 00 	mov    0x6039a(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    d89e:	49 89 c5             	mov    %rax,%r13
    d8a1:	48 2b 05 68 03 06 00 	sub    0x60368(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    d8a8:	48 c1 e2 10          	shl    $0x10,%rdx
    d8ac:	48 39 d0             	cmp    %rdx,%rax
    d8af:	73 59                	jae    d90a <f0+0x1c6a>
    d8b1:	48 89 c2             	mov    %rax,%rdx
    d8b4:	48 c1 ea 10          	shr    $0x10,%rdx
    d8b8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d8bc:	48 8b 15 95 03 06 00 	mov    0x60395(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    d8c3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d8c7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d8cb:	4d 85 e4             	test   %r12,%r12
    d8ce:	74 3a                	je     d90a <f0+0x1c6a>
    d8d0:	0f b6 0a             	movzbl (%rdx),%ecx
    d8d3:	80 f9 02             	cmp    $0x2,%cl
    d8d6:	0f 84 84 0c 00 00    	je     e560 <f0+0x28c0>
    d8dc:	80 f9 01             	cmp    $0x1,%cl
    d8df:	75 29                	jne    d90a <f0+0x1c6a>
    d8e1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d8e4:	0f b7 c0             	movzwl %ax,%eax
    d8e7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d8ea:	48 0f af c1          	imul   %rcx,%rax
    d8ee:	48 c1 e8 20          	shr    $0x20,%rax
    d8f2:	48 39 d0             	cmp    %rdx,%rax
    d8f5:	73 13                	jae    d90a <f0+0x1c6a>
    d8f7:	49 01 c4             	add    %rax,%r12
    d8fa:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d8ff:	0f 84 9d 0f 00 00    	je     e8a2 <f0+0x2c02>
    d905:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d90a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d911:	33 f3 bf 
    d914:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    d91b:	00 
    d91c:	bf 01 00 00 00       	mov    $0x1,%edi
    d921:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    d928:	00 
    d929:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    d930:	00 
    d931:	e8 1a 90 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    d936:	48 8b 15 fb 02 06 00 	mov    0x602fb(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    d93d:	49 89 c5             	mov    %rax,%r13
    d940:	48 2b 05 c9 02 06 00 	sub    0x602c9(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    d947:	48 c1 e2 10          	shl    $0x10,%rdx
    d94b:	48 39 d0             	cmp    %rdx,%rax
    d94e:	73 59                	jae    d9a9 <f0+0x1d09>
    d950:	48 89 c2             	mov    %rax,%rdx
    d953:	48 c1 ea 10          	shr    $0x10,%rdx
    d957:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d95b:	48 8b 15 f6 02 06 00 	mov    0x602f6(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    d962:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d966:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d96a:	4d 85 e4             	test   %r12,%r12
    d96d:	74 3a                	je     d9a9 <f0+0x1d09>
    d96f:	0f b6 0a             	movzbl (%rdx),%ecx
    d972:	80 f9 02             	cmp    $0x2,%cl
    d975:	0f 84 d5 0b 00 00    	je     e550 <f0+0x28b0>
    d97b:	80 f9 01             	cmp    $0x1,%cl
    d97e:	75 29                	jne    d9a9 <f0+0x1d09>
    d980:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d983:	0f b7 c0             	movzwl %ax,%eax
    d986:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d989:	48 0f af c1          	imul   %rcx,%rax
    d98d:	48 c1 e8 20          	shr    $0x20,%rax
    d991:	48 39 d0             	cmp    %rdx,%rax
    d994:	73 13                	jae    d9a9 <f0+0x1d09>
    d996:	49 01 c4             	add    %rax,%r12
    d999:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d99e:	0f 84 0b 0f 00 00    	je     e8af <f0+0x2c0f>
    d9a4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d9a9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d9b0:	00 f0 3f 
    d9b3:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    d9ba:	00 
    d9bb:	bf 01 00 00 00       	mov    $0x1,%edi
    d9c0:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    d9c7:	00 
    d9c8:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    d9cf:	00 
    d9d0:	e8 7b 8f ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    d9d5:	48 8b 15 5c 02 06 00 	mov    0x6025c(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    d9dc:	49 89 c5             	mov    %rax,%r13
    d9df:	48 2b 05 2a 02 06 00 	sub    0x6022a(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    d9e6:	48 c1 e2 10          	shl    $0x10,%rdx
    d9ea:	48 39 d0             	cmp    %rdx,%rax
    d9ed:	73 59                	jae    da48 <f0+0x1da8>
    d9ef:	48 89 c2             	mov    %rax,%rdx
    d9f2:	48 c1 ea 10          	shr    $0x10,%rdx
    d9f6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d9fa:	48 8b 15 57 02 06 00 	mov    0x60257(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    da01:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    da05:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    da09:	4d 85 e4             	test   %r12,%r12
    da0c:	74 3a                	je     da48 <f0+0x1da8>
    da0e:	0f b6 0a             	movzbl (%rdx),%ecx
    da11:	80 f9 02             	cmp    $0x2,%cl
    da14:	0f 84 26 0b 00 00    	je     e540 <f0+0x28a0>
    da1a:	80 f9 01             	cmp    $0x1,%cl
    da1d:	75 29                	jne    da48 <f0+0x1da8>
    da1f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    da22:	0f b7 c0             	movzwl %ax,%eax
    da25:	8b 52 1c             	mov    0x1c(%rdx),%edx
    da28:	48 0f af c1          	imul   %rcx,%rax
    da2c:	48 c1 e8 20          	shr    $0x20,%rax
    da30:	48 39 d0             	cmp    %rdx,%rax
    da33:	73 13                	jae    da48 <f0+0x1da8>
    da35:	49 01 c4             	add    %rax,%r12
    da38:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    da3d:	0f 84 79 0e 00 00    	je     e8bc <f0+0x2c1c>
    da43:	41 c6 04 24 01       	movb   $0x1,(%r12)
    da48:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    da4f:	33 f3 bf 
    da52:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    da59:	00 
    da5a:	bf 01 00 00 00       	mov    $0x1,%edi
    da5f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    da66:	00 
    da67:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    da6e:	00 
    da6f:	e8 dc 8e ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    da74:	48 8b 15 bd 01 06 00 	mov    0x601bd(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    da7b:	49 89 c5             	mov    %rax,%r13
    da7e:	48 2b 05 8b 01 06 00 	sub    0x6018b(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    da85:	48 c1 e2 10          	shl    $0x10,%rdx
    da89:	48 39 d0             	cmp    %rdx,%rax
    da8c:	73 59                	jae    dae7 <f0+0x1e47>
    da8e:	48 89 c2             	mov    %rax,%rdx
    da91:	48 c1 ea 10          	shr    $0x10,%rdx
    da95:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    da99:	48 8b 15 b8 01 06 00 	mov    0x601b8(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    daa0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    daa4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    daa8:	4d 85 e4             	test   %r12,%r12
    daab:	74 3a                	je     dae7 <f0+0x1e47>
    daad:	0f b6 0a             	movzbl (%rdx),%ecx
    dab0:	80 f9 02             	cmp    $0x2,%cl
    dab3:	0f 84 77 0a 00 00    	je     e530 <f0+0x2890>
    dab9:	80 f9 01             	cmp    $0x1,%cl
    dabc:	75 29                	jne    dae7 <f0+0x1e47>
    dabe:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dac1:	0f b7 c0             	movzwl %ax,%eax
    dac4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dac7:	48 0f af c1          	imul   %rcx,%rax
    dacb:	48 c1 e8 20          	shr    $0x20,%rax
    dacf:	48 39 d0             	cmp    %rdx,%rax
    dad2:	73 13                	jae    dae7 <f0+0x1e47>
    dad4:	49 01 c4             	add    %rax,%r12
    dad7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dadc:	0f 84 e7 0d 00 00    	je     e8c9 <f0+0x2c29>
    dae2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dae7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    daee:	00 f0 3f 
    daf1:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    daf8:	00 
    daf9:	bf 01 00 00 00       	mov    $0x1,%edi
    dafe:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    db05:	00 
    db06:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    db0d:	00 
    db0e:	e8 3d 8e ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    db13:	48 8b 15 1e 01 06 00 	mov    0x6011e(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    db1a:	49 89 c5             	mov    %rax,%r13
    db1d:	48 2b 05 ec 00 06 00 	sub    0x600ec(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    db24:	48 c1 e2 10          	shl    $0x10,%rdx
    db28:	48 39 d0             	cmp    %rdx,%rax
    db2b:	73 59                	jae    db86 <f0+0x1ee6>
    db2d:	48 89 c2             	mov    %rax,%rdx
    db30:	48 c1 ea 10          	shr    $0x10,%rdx
    db34:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    db38:	48 8b 15 19 01 06 00 	mov    0x60119(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    db3f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    db43:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    db47:	4d 85 e4             	test   %r12,%r12
    db4a:	74 3a                	je     db86 <f0+0x1ee6>
    db4c:	0f b6 0a             	movzbl (%rdx),%ecx
    db4f:	80 f9 02             	cmp    $0x2,%cl
    db52:	0f 84 38 0c 00 00    	je     e790 <f0+0x2af0>
    db58:	80 f9 01             	cmp    $0x1,%cl
    db5b:	75 29                	jne    db86 <f0+0x1ee6>
    db5d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    db60:	0f b7 c0             	movzwl %ax,%eax
    db63:	8b 52 1c             	mov    0x1c(%rdx),%edx
    db66:	48 0f af c1          	imul   %rcx,%rax
    db6a:	48 c1 e8 20          	shr    $0x20,%rax
    db6e:	48 39 d0             	cmp    %rdx,%rax
    db71:	73 13                	jae    db86 <f0+0x1ee6>
    db73:	49 01 c4             	add    %rax,%r12
    db76:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    db7b:	0f 84 55 0d 00 00    	je     e8d6 <f0+0x2c36>
    db81:	41 c6 04 24 01       	movb   $0x1,(%r12)
    db86:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    db8d:	33 f3 bf 
    db90:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    db97:	00 
    db98:	bf 01 00 00 00       	mov    $0x1,%edi
    db9d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    dba4:	00 
    dba5:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    dbac:	00 
    dbad:	e8 9e 8d ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    dbb2:	48 8b 15 7f 00 06 00 	mov    0x6007f(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    dbb9:	49 89 c5             	mov    %rax,%r13
    dbbc:	48 2b 05 4d 00 06 00 	sub    0x6004d(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    dbc3:	48 c1 e2 10          	shl    $0x10,%rdx
    dbc7:	48 39 d0             	cmp    %rdx,%rax
    dbca:	73 59                	jae    dc25 <f0+0x1f85>
    dbcc:	48 89 c2             	mov    %rax,%rdx
    dbcf:	48 c1 ea 10          	shr    $0x10,%rdx
    dbd3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dbd7:	48 8b 15 7a 00 06 00 	mov    0x6007a(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    dbde:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dbe2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dbe6:	4d 85 e4             	test   %r12,%r12
    dbe9:	74 3a                	je     dc25 <f0+0x1f85>
    dbeb:	0f b6 0a             	movzbl (%rdx),%ecx
    dbee:	80 f9 02             	cmp    $0x2,%cl
    dbf1:	0f 84 89 0b 00 00    	je     e780 <f0+0x2ae0>
    dbf7:	80 f9 01             	cmp    $0x1,%cl
    dbfa:	75 29                	jne    dc25 <f0+0x1f85>
    dbfc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dbff:	0f b7 c0             	movzwl %ax,%eax
    dc02:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dc05:	48 0f af c1          	imul   %rcx,%rax
    dc09:	48 c1 e8 20          	shr    $0x20,%rax
    dc0d:	48 39 d0             	cmp    %rdx,%rax
    dc10:	73 13                	jae    dc25 <f0+0x1f85>
    dc12:	49 01 c4             	add    %rax,%r12
    dc15:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dc1a:	0f 84 c3 0c 00 00    	je     e8e3 <f0+0x2c43>
    dc20:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dc25:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dc2c:	00 f0 3f 
    dc2f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    dc36:	00 
    dc37:	bf 01 00 00 00       	mov    $0x1,%edi
    dc3c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    dc43:	00 
    dc44:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    dc4b:	00 
    dc4c:	e8 ff 8c ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    dc51:	48 8b 15 e0 ff 05 00 	mov    0x5ffe0(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    dc58:	49 89 c5             	mov    %rax,%r13
    dc5b:	48 2b 05 ae ff 05 00 	sub    0x5ffae(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    dc62:	48 c1 e2 10          	shl    $0x10,%rdx
    dc66:	48 39 d0             	cmp    %rdx,%rax
    dc69:	73 59                	jae    dcc4 <f0+0x2024>
    dc6b:	48 89 c2             	mov    %rax,%rdx
    dc6e:	48 c1 ea 10          	shr    $0x10,%rdx
    dc72:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dc76:	48 8b 15 db ff 05 00 	mov    0x5ffdb(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    dc7d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dc81:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dc85:	4d 85 e4             	test   %r12,%r12
    dc88:	74 3a                	je     dcc4 <f0+0x2024>
    dc8a:	0f b6 0a             	movzbl (%rdx),%ecx
    dc8d:	80 f9 02             	cmp    $0x2,%cl
    dc90:	0f 84 da 0a 00 00    	je     e770 <f0+0x2ad0>
    dc96:	80 f9 01             	cmp    $0x1,%cl
    dc99:	75 29                	jne    dcc4 <f0+0x2024>
    dc9b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dc9e:	0f b7 c0             	movzwl %ax,%eax
    dca1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dca4:	48 0f af c1          	imul   %rcx,%rax
    dca8:	48 c1 e8 20          	shr    $0x20,%rax
    dcac:	48 39 d0             	cmp    %rdx,%rax
    dcaf:	73 13                	jae    dcc4 <f0+0x2024>
    dcb1:	49 01 c4             	add    %rax,%r12
    dcb4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dcb9:	0f 84 31 0c 00 00    	je     e8f0 <f0+0x2c50>
    dcbf:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dcc4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dccb:	33 f3 bf 
    dcce:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    dcd5:	00 
    dcd6:	bf 01 00 00 00       	mov    $0x1,%edi
    dcdb:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    dce2:	00 
    dce3:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    dcea:	00 
    dceb:	e8 60 8c ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    dcf0:	48 8b 15 41 ff 05 00 	mov    0x5ff41(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    dcf7:	49 89 c5             	mov    %rax,%r13
    dcfa:	48 2b 05 0f ff 05 00 	sub    0x5ff0f(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    dd01:	48 c1 e2 10          	shl    $0x10,%rdx
    dd05:	48 39 d0             	cmp    %rdx,%rax
    dd08:	73 59                	jae    dd63 <f0+0x20c3>
    dd0a:	48 89 c2             	mov    %rax,%rdx
    dd0d:	48 c1 ea 10          	shr    $0x10,%rdx
    dd11:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dd15:	48 8b 15 3c ff 05 00 	mov    0x5ff3c(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    dd1c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dd20:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dd24:	4d 85 e4             	test   %r12,%r12
    dd27:	74 3a                	je     dd63 <f0+0x20c3>
    dd29:	0f b6 0a             	movzbl (%rdx),%ecx
    dd2c:	80 f9 02             	cmp    $0x2,%cl
    dd2f:	0f 84 2b 0a 00 00    	je     e760 <f0+0x2ac0>
    dd35:	80 f9 01             	cmp    $0x1,%cl
    dd38:	75 29                	jne    dd63 <f0+0x20c3>
    dd3a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dd3d:	0f b7 c0             	movzwl %ax,%eax
    dd40:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dd43:	48 0f af c1          	imul   %rcx,%rax
    dd47:	48 c1 e8 20          	shr    $0x20,%rax
    dd4b:	48 39 d0             	cmp    %rdx,%rax
    dd4e:	73 13                	jae    dd63 <f0+0x20c3>
    dd50:	49 01 c4             	add    %rax,%r12
    dd53:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dd58:	0f 84 9f 0b 00 00    	je     e8fd <f0+0x2c5d>
    dd5e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dd63:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dd6a:	00 f0 3f 
    dd6d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    dd74:	00 
    dd75:	bf 01 00 00 00       	mov    $0x1,%edi
    dd7a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    dd81:	00 
    dd82:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    dd89:	00 
    dd8a:	e8 c1 8b ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    dd8f:	48 8b 15 a2 fe 05 00 	mov    0x5fea2(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    dd96:	49 89 c5             	mov    %rax,%r13
    dd99:	48 2b 05 70 fe 05 00 	sub    0x5fe70(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    dda0:	48 c1 e2 10          	shl    $0x10,%rdx
    dda4:	48 39 d0             	cmp    %rdx,%rax
    dda7:	73 59                	jae    de02 <f0+0x2162>
    dda9:	48 89 c2             	mov    %rax,%rdx
    ddac:	48 c1 ea 10          	shr    $0x10,%rdx
    ddb0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ddb4:	48 8b 15 9d fe 05 00 	mov    0x5fe9d(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    ddbb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ddbf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ddc3:	4d 85 e4             	test   %r12,%r12
    ddc6:	74 3a                	je     de02 <f0+0x2162>
    ddc8:	0f b6 0a             	movzbl (%rdx),%ecx
    ddcb:	80 f9 02             	cmp    $0x2,%cl
    ddce:	0f 84 7c 09 00 00    	je     e750 <f0+0x2ab0>
    ddd4:	80 f9 01             	cmp    $0x1,%cl
    ddd7:	75 29                	jne    de02 <f0+0x2162>
    ddd9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dddc:	0f b7 c0             	movzwl %ax,%eax
    dddf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dde2:	48 0f af c1          	imul   %rcx,%rax
    dde6:	48 c1 e8 20          	shr    $0x20,%rax
    ddea:	48 39 d0             	cmp    %rdx,%rax
    dded:	73 13                	jae    de02 <f0+0x2162>
    ddef:	49 01 c4             	add    %rax,%r12
    ddf2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ddf7:	0f 84 0d 0b 00 00    	je     e90a <f0+0x2c6a>
    ddfd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    de02:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    de09:	33 f3 bf 
    de0c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    de13:	00 
    de14:	bf 01 00 00 00       	mov    $0x1,%edi
    de19:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    de20:	00 
    de21:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    de28:	00 
    de29:	e8 22 8b ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    de2e:	48 8b 15 03 fe 05 00 	mov    0x5fe03(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    de35:	49 89 c5             	mov    %rax,%r13
    de38:	48 2b 05 d1 fd 05 00 	sub    0x5fdd1(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    de3f:	48 c1 e2 10          	shl    $0x10,%rdx
    de43:	48 39 d0             	cmp    %rdx,%rax
    de46:	73 59                	jae    dea1 <f0+0x2201>
    de48:	48 89 c2             	mov    %rax,%rdx
    de4b:	48 c1 ea 10          	shr    $0x10,%rdx
    de4f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    de53:	48 8b 15 fe fd 05 00 	mov    0x5fdfe(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    de5a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    de5e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    de62:	4d 85 e4             	test   %r12,%r12
    de65:	74 3a                	je     dea1 <f0+0x2201>
    de67:	0f b6 0a             	movzbl (%rdx),%ecx
    de6a:	80 f9 02             	cmp    $0x2,%cl
    de6d:	0f 84 cd 08 00 00    	je     e740 <f0+0x2aa0>
    de73:	80 f9 01             	cmp    $0x1,%cl
    de76:	75 29                	jne    dea1 <f0+0x2201>
    de78:	8b 4a 18             	mov    0x18(%rdx),%ecx
    de7b:	0f b7 c0             	movzwl %ax,%eax
    de7e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    de81:	48 0f af c1          	imul   %rcx,%rax
    de85:	48 c1 e8 20          	shr    $0x20,%rax
    de89:	48 39 d0             	cmp    %rdx,%rax
    de8c:	73 13                	jae    dea1 <f0+0x2201>
    de8e:	49 01 c4             	add    %rax,%r12
    de91:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    de96:	0f 84 7b 0a 00 00    	je     e917 <f0+0x2c77>
    de9c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dea1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dea8:	00 f0 3f 
    deab:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    deb2:	00 
    deb3:	bf 01 00 00 00       	mov    $0x1,%edi
    deb8:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    debf:	00 
    dec0:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    dec7:	00 
    dec8:	e8 83 8a ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    decd:	48 8b 15 64 fd 05 00 	mov    0x5fd64(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    ded4:	49 89 c5             	mov    %rax,%r13
    ded7:	48 2b 05 32 fd 05 00 	sub    0x5fd32(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    dede:	48 c1 e2 10          	shl    $0x10,%rdx
    dee2:	48 39 d0             	cmp    %rdx,%rax
    dee5:	73 59                	jae    df40 <f0+0x22a0>
    dee7:	48 89 c2             	mov    %rax,%rdx
    deea:	48 c1 ea 10          	shr    $0x10,%rdx
    deee:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    def2:	48 8b 15 5f fd 05 00 	mov    0x5fd5f(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    def9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    defd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    df01:	4d 85 e4             	test   %r12,%r12
    df04:	74 3a                	je     df40 <f0+0x22a0>
    df06:	0f b6 0a             	movzbl (%rdx),%ecx
    df09:	80 f9 02             	cmp    $0x2,%cl
    df0c:	0f 84 1e 08 00 00    	je     e730 <f0+0x2a90>
    df12:	80 f9 01             	cmp    $0x1,%cl
    df15:	75 29                	jne    df40 <f0+0x22a0>
    df17:	8b 4a 18             	mov    0x18(%rdx),%ecx
    df1a:	0f b7 c0             	movzwl %ax,%eax
    df1d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    df20:	48 0f af c1          	imul   %rcx,%rax
    df24:	48 c1 e8 20          	shr    $0x20,%rax
    df28:	48 39 d0             	cmp    %rdx,%rax
    df2b:	73 13                	jae    df40 <f0+0x22a0>
    df2d:	49 01 c4             	add    %rax,%r12
    df30:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    df35:	0f 84 e9 09 00 00    	je     e924 <f0+0x2c84>
    df3b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    df40:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    df47:	33 f3 bf 
    df4a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    df51:	00 
    df52:	bf 01 00 00 00       	mov    $0x1,%edi
    df57:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    df5e:	00 
    df5f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    df66:	00 
    df67:	e8 e4 89 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    df6c:	48 8b 15 c5 fc 05 00 	mov    0x5fcc5(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    df73:	49 89 c5             	mov    %rax,%r13
    df76:	48 2b 05 93 fc 05 00 	sub    0x5fc93(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    df7d:	48 c1 e2 10          	shl    $0x10,%rdx
    df81:	48 39 d0             	cmp    %rdx,%rax
    df84:	73 59                	jae    dfdf <f0+0x233f>
    df86:	48 89 c2             	mov    %rax,%rdx
    df89:	48 c1 ea 10          	shr    $0x10,%rdx
    df8d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    df91:	48 8b 15 c0 fc 05 00 	mov    0x5fcc0(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    df98:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    df9c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dfa0:	4d 85 e4             	test   %r12,%r12
    dfa3:	74 3a                	je     dfdf <f0+0x233f>
    dfa5:	0f b6 0a             	movzbl (%rdx),%ecx
    dfa8:	80 f9 02             	cmp    $0x2,%cl
    dfab:	0f 84 6f 07 00 00    	je     e720 <f0+0x2a80>
    dfb1:	80 f9 01             	cmp    $0x1,%cl
    dfb4:	75 29                	jne    dfdf <f0+0x233f>
    dfb6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dfb9:	0f b7 c0             	movzwl %ax,%eax
    dfbc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dfbf:	48 0f af c1          	imul   %rcx,%rax
    dfc3:	48 c1 e8 20          	shr    $0x20,%rax
    dfc7:	48 39 d0             	cmp    %rdx,%rax
    dfca:	73 13                	jae    dfdf <f0+0x233f>
    dfcc:	49 01 c4             	add    %rax,%r12
    dfcf:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dfd4:	0f 84 57 09 00 00    	je     e931 <f0+0x2c91>
    dfda:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dfdf:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dfe6:	00 f0 3f 
    dfe9:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    dff0:	00 
    dff1:	bf 01 00 00 00       	mov    $0x1,%edi
    dff6:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    dffd:	00 
    dffe:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    e005:	00 
    e006:	e8 45 89 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    e00b:	48 8b 15 26 fc 05 00 	mov    0x5fc26(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    e012:	49 89 c5             	mov    %rax,%r13
    e015:	48 2b 05 f4 fb 05 00 	sub    0x5fbf4(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    e01c:	48 c1 e2 10          	shl    $0x10,%rdx
    e020:	48 39 d0             	cmp    %rdx,%rax
    e023:	73 59                	jae    e07e <f0+0x23de>
    e025:	48 89 c2             	mov    %rax,%rdx
    e028:	48 c1 ea 10          	shr    $0x10,%rdx
    e02c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e030:	48 8b 15 21 fc 05 00 	mov    0x5fc21(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    e037:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e03b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e03f:	4d 85 e4             	test   %r12,%r12
    e042:	74 3a                	je     e07e <f0+0x23de>
    e044:	0f b6 0a             	movzbl (%rdx),%ecx
    e047:	80 f9 02             	cmp    $0x2,%cl
    e04a:	0f 84 c0 06 00 00    	je     e710 <f0+0x2a70>
    e050:	80 f9 01             	cmp    $0x1,%cl
    e053:	75 29                	jne    e07e <f0+0x23de>
    e055:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e058:	0f b7 c0             	movzwl %ax,%eax
    e05b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e05e:	48 0f af c1          	imul   %rcx,%rax
    e062:	48 c1 e8 20          	shr    $0x20,%rax
    e066:	48 39 d0             	cmp    %rdx,%rax
    e069:	73 13                	jae    e07e <f0+0x23de>
    e06b:	49 01 c4             	add    %rax,%r12
    e06e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e073:	0f 84 c5 08 00 00    	je     e93e <f0+0x2c9e>
    e079:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e07e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e085:	33 f3 bf 
    e088:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    e08f:	00 
    e090:	bf 01 00 00 00       	mov    $0x1,%edi
    e095:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    e09c:	00 
    e09d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    e0a4:	00 
    e0a5:	e8 a6 88 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    e0aa:	48 8b 15 87 fb 05 00 	mov    0x5fb87(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    e0b1:	49 89 c5             	mov    %rax,%r13
    e0b4:	48 2b 05 55 fb 05 00 	sub    0x5fb55(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    e0bb:	48 c1 e2 10          	shl    $0x10,%rdx
    e0bf:	48 39 d0             	cmp    %rdx,%rax
    e0c2:	73 59                	jae    e11d <f0+0x247d>
    e0c4:	48 89 c2             	mov    %rax,%rdx
    e0c7:	48 c1 ea 10          	shr    $0x10,%rdx
    e0cb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e0cf:	48 8b 15 82 fb 05 00 	mov    0x5fb82(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    e0d6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e0da:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e0de:	4d 85 e4             	test   %r12,%r12
    e0e1:	74 3a                	je     e11d <f0+0x247d>
    e0e3:	0f b6 0a             	movzbl (%rdx),%ecx
    e0e6:	80 f9 02             	cmp    $0x2,%cl
    e0e9:	0f 84 11 06 00 00    	je     e700 <f0+0x2a60>
    e0ef:	80 f9 01             	cmp    $0x1,%cl
    e0f2:	75 29                	jne    e11d <f0+0x247d>
    e0f4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e0f7:	0f b7 c0             	movzwl %ax,%eax
    e0fa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e0fd:	48 0f af c1          	imul   %rcx,%rax
    e101:	48 c1 e8 20          	shr    $0x20,%rax
    e105:	48 39 d0             	cmp    %rdx,%rax
    e108:	73 13                	jae    e11d <f0+0x247d>
    e10a:	49 01 c4             	add    %rax,%r12
    e10d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e112:	0f 84 33 08 00 00    	je     e94b <f0+0x2cab>
    e118:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e11d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    e124:	00 f0 3f 
    e127:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    e12e:	00 
    e12f:	bf 01 00 00 00       	mov    $0x1,%edi
    e134:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    e13b:	00 
    e13c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    e143:	00 
    e144:	e8 07 88 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    e149:	48 8b 15 e8 fa 05 00 	mov    0x5fae8(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    e150:	49 89 c5             	mov    %rax,%r13
    e153:	48 2b 05 b6 fa 05 00 	sub    0x5fab6(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    e15a:	48 c1 e2 10          	shl    $0x10,%rdx
    e15e:	48 39 d0             	cmp    %rdx,%rax
    e161:	73 59                	jae    e1bc <f0+0x251c>
    e163:	48 89 c2             	mov    %rax,%rdx
    e166:	48 c1 ea 10          	shr    $0x10,%rdx
    e16a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e16e:	48 8b 15 e3 fa 05 00 	mov    0x5fae3(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    e175:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e179:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e17d:	4d 85 e4             	test   %r12,%r12
    e180:	74 3a                	je     e1bc <f0+0x251c>
    e182:	0f b6 0a             	movzbl (%rdx),%ecx
    e185:	80 f9 02             	cmp    $0x2,%cl
    e188:	0f 84 62 05 00 00    	je     e6f0 <f0+0x2a50>
    e18e:	80 f9 01             	cmp    $0x1,%cl
    e191:	75 29                	jne    e1bc <f0+0x251c>
    e193:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e196:	0f b7 c0             	movzwl %ax,%eax
    e199:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e19c:	48 0f af c1          	imul   %rcx,%rax
    e1a0:	48 c1 e8 20          	shr    $0x20,%rax
    e1a4:	48 39 d0             	cmp    %rdx,%rax
    e1a7:	73 13                	jae    e1bc <f0+0x251c>
    e1a9:	49 01 c4             	add    %rax,%r12
    e1ac:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e1b1:	0f 84 a1 07 00 00    	je     e958 <f0+0x2cb8>
    e1b7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e1bc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e1c3:	33 f3 bf 
    e1c6:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    e1cd:	00 
    e1ce:	bf 01 00 00 00       	mov    $0x1,%edi
    e1d3:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    e1da:	00 
    e1db:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    e1e2:	00 
    e1e3:	e8 68 87 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    e1e8:	48 8b 15 49 fa 05 00 	mov    0x5fa49(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    e1ef:	49 89 c5             	mov    %rax,%r13
    e1f2:	48 2b 05 17 fa 05 00 	sub    0x5fa17(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    e1f9:	48 c1 e2 10          	shl    $0x10,%rdx
    e1fd:	48 39 d0             	cmp    %rdx,%rax
    e200:	73 59                	jae    e25b <f0+0x25bb>
    e202:	48 89 c2             	mov    %rax,%rdx
    e205:	48 c1 ea 10          	shr    $0x10,%rdx
    e209:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e20d:	48 8b 15 44 fa 05 00 	mov    0x5fa44(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    e214:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e218:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e21c:	4d 85 e4             	test   %r12,%r12
    e21f:	74 3a                	je     e25b <f0+0x25bb>
    e221:	0f b6 0a             	movzbl (%rdx),%ecx
    e224:	80 f9 02             	cmp    $0x2,%cl
    e227:	0f 84 b3 04 00 00    	je     e6e0 <f0+0x2a40>
    e22d:	80 f9 01             	cmp    $0x1,%cl
    e230:	75 29                	jne    e25b <f0+0x25bb>
    e232:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e235:	0f b7 c0             	movzwl %ax,%eax
    e238:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e23b:	48 0f af c1          	imul   %rcx,%rax
    e23f:	48 c1 e8 20          	shr    $0x20,%rax
    e243:	48 39 d0             	cmp    %rdx,%rax
    e246:	73 13                	jae    e25b <f0+0x25bb>
    e248:	49 01 c4             	add    %rax,%r12
    e24b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e250:	0f 84 0f 07 00 00    	je     e965 <f0+0x2cc5>
    e256:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e25b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    e262:	00 f0 3f 
    e265:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    e26c:	00 
    e26d:	bf 01 00 00 00       	mov    $0x1,%edi
    e272:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    e279:	00 
    e27a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    e281:	00 
    e282:	e8 c9 86 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    e287:	48 8b 15 aa f9 05 00 	mov    0x5f9aa(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    e28e:	49 89 c5             	mov    %rax,%r13
    e291:	48 2b 05 78 f9 05 00 	sub    0x5f978(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    e298:	48 c1 e2 10          	shl    $0x10,%rdx
    e29c:	48 39 d0             	cmp    %rdx,%rax
    e29f:	73 59                	jae    e2fa <f0+0x265a>
    e2a1:	48 89 c2             	mov    %rax,%rdx
    e2a4:	48 c1 ea 10          	shr    $0x10,%rdx
    e2a8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e2ac:	48 8b 15 a5 f9 05 00 	mov    0x5f9a5(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    e2b3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e2b7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e2bb:	4d 85 e4             	test   %r12,%r12
    e2be:	74 3a                	je     e2fa <f0+0x265a>
    e2c0:	0f b6 0a             	movzbl (%rdx),%ecx
    e2c3:	80 f9 02             	cmp    $0x2,%cl
    e2c6:	0f 84 04 04 00 00    	je     e6d0 <f0+0x2a30>
    e2cc:	80 f9 01             	cmp    $0x1,%cl
    e2cf:	75 29                	jne    e2fa <f0+0x265a>
    e2d1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e2d4:	0f b7 c0             	movzwl %ax,%eax
    e2d7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e2da:	48 0f af c1          	imul   %rcx,%rax
    e2de:	48 c1 e8 20          	shr    $0x20,%rax
    e2e2:	48 39 d0             	cmp    %rdx,%rax
    e2e5:	73 13                	jae    e2fa <f0+0x265a>
    e2e7:	49 01 c4             	add    %rax,%r12
    e2ea:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e2ef:	0f 84 7d 06 00 00    	je     e972 <f0+0x2cd2>
    e2f5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e2fa:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e301:	33 f3 bf 
    e304:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    e30b:	00 
    e30c:	bf 01 00 00 00       	mov    $0x1,%edi
    e311:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    e318:	00 
    e319:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    e320:	00 
    e321:	e8 2a 86 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    e326:	48 8b 15 0b f9 05 00 	mov    0x5f90b(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    e32d:	49 89 c5             	mov    %rax,%r13
    e330:	48 2b 05 d9 f8 05 00 	sub    0x5f8d9(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    e337:	48 c1 e2 10          	shl    $0x10,%rdx
    e33b:	48 39 d0             	cmp    %rdx,%rax
    e33e:	73 59                	jae    e399 <f0+0x26f9>
    e340:	48 89 c2             	mov    %rax,%rdx
    e343:	48 c1 ea 10          	shr    $0x10,%rdx
    e347:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e34b:	48 8b 15 06 f9 05 00 	mov    0x5f906(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    e352:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e356:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e35a:	4d 85 e4             	test   %r12,%r12
    e35d:	74 3a                	je     e399 <f0+0x26f9>
    e35f:	0f b6 0a             	movzbl (%rdx),%ecx
    e362:	80 f9 02             	cmp    $0x2,%cl
    e365:	0f 84 55 03 00 00    	je     e6c0 <f0+0x2a20>
    e36b:	80 f9 01             	cmp    $0x1,%cl
    e36e:	75 29                	jne    e399 <f0+0x26f9>
    e370:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e373:	0f b7 c0             	movzwl %ax,%eax
    e376:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e379:	48 0f af c1          	imul   %rcx,%rax
    e37d:	48 c1 e8 20          	shr    $0x20,%rax
    e381:	48 39 d0             	cmp    %rdx,%rax
    e384:	73 13                	jae    e399 <f0+0x26f9>
    e386:	49 01 c4             	add    %rax,%r12
    e389:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e38e:	0f 84 eb 05 00 00    	je     e97f <f0+0x2cdf>
    e394:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e399:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    e3a0:	00 f0 3f 
    e3a3:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    e3aa:	00 
    e3ab:	bf 01 00 00 00       	mov    $0x1,%edi
    e3b0:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    e3b7:	00 
    e3b8:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    e3bf:	00 
    e3c0:	e8 8b 85 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    e3c5:	48 8b 15 6c f8 05 00 	mov    0x5f86c(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    e3cc:	49 89 c5             	mov    %rax,%r13
    e3cf:	48 2b 05 3a f8 05 00 	sub    0x5f83a(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    e3d6:	48 c1 e2 10          	shl    $0x10,%rdx
    e3da:	48 39 d0             	cmp    %rdx,%rax
    e3dd:	73 59                	jae    e438 <f0+0x2798>
    e3df:	48 89 c2             	mov    %rax,%rdx
    e3e2:	48 c1 ea 10          	shr    $0x10,%rdx
    e3e6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e3ea:	48 8b 15 67 f8 05 00 	mov    0x5f867(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    e3f1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e3f5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e3f9:	4d 85 e4             	test   %r12,%r12
    e3fc:	74 3a                	je     e438 <f0+0x2798>
    e3fe:	0f b6 0a             	movzbl (%rdx),%ecx
    e401:	80 f9 02             	cmp    $0x2,%cl
    e404:	0f 84 a6 02 00 00    	je     e6b0 <f0+0x2a10>
    e40a:	80 f9 01             	cmp    $0x1,%cl
    e40d:	75 29                	jne    e438 <f0+0x2798>
    e40f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e412:	0f b7 c0             	movzwl %ax,%eax
    e415:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e418:	48 0f af c1          	imul   %rcx,%rax
    e41c:	48 c1 e8 20          	shr    $0x20,%rax
    e420:	48 39 d0             	cmp    %rdx,%rax
    e423:	73 13                	jae    e438 <f0+0x2798>
    e425:	49 01 c4             	add    %rax,%r12
    e428:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e42d:	0f 84 59 05 00 00    	je     e98c <f0+0x2cec>
    e433:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e438:	48 89 ee             	mov    %rbp,%rsi
    e43b:	bf 01 00 00 00       	mov    $0x1,%edi
    e440:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e447:	33 f3 bf 
    e44a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    e451:	00 
    e452:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    e459:	00 
    e45a:	e8 f1 84 ff ff       	call   6950 <fwp_data.part.0.constprop.0>
    e45f:	48 8b 15 d2 f7 05 00 	mov    0x5f7d2(%rip),%rdx        # 6dc38 <fwp_heap+0x13d8>
    e466:	48 89 c5             	mov    %rax,%rbp
    e469:	48 2b 05 a0 f7 05 00 	sub    0x5f7a0(%rip),%rax        # 6dc10 <fwp_heap+0x13b0>
    e470:	48 c1 e2 10          	shl    $0x10,%rdx
    e474:	48 39 d0             	cmp    %rdx,%rax
    e477:	73 59                	jae    e4d2 <f0+0x2832>
    e479:	48 89 c2             	mov    %rax,%rdx
    e47c:	48 c1 ea 10          	shr    $0x10,%rdx
    e480:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e484:	48 8b 15 cd f7 05 00 	mov    0x5f7cd(%rip),%rdx        # 6dc58 <fwp_heap+0x13f8>
    e48b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e48f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e493:	4d 85 e4             	test   %r12,%r12
    e496:	74 3a                	je     e4d2 <f0+0x2832>
    e498:	0f b6 0a             	movzbl (%rdx),%ecx
    e49b:	80 f9 02             	cmp    $0x2,%cl
    e49e:	0f 84 fc 01 00 00    	je     e6a0 <f0+0x2a00>
    e4a4:	80 f9 01             	cmp    $0x1,%cl
    e4a7:	75 29                	jne    e4d2 <f0+0x2832>
    e4a9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e4ac:	0f b7 c0             	movzwl %ax,%eax
    e4af:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e4b2:	48 0f af c1          	imul   %rcx,%rax
    e4b6:	48 c1 e8 20          	shr    $0x20,%rax
    e4ba:	48 39 d0             	cmp    %rdx,%rax
    e4bd:	73 13                	jae    e4d2 <f0+0x2832>
    e4bf:	49 01 c4             	add    %rax,%r12
    e4c2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e4c7:	0f 84 d1 02 00 00    	je     e79e <f0+0x2afe>
    e4cd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e4d2:	48 89 de             	mov    %rbx,%rsi
    e4d5:	48 89 ef             	mov    %rbp,%rdi
    e4d8:	e8 13 ca ff ff       	call   aef0 <fwp_hof0.constprop.0>
    e4dd:	48 89 ef             	mov    %rbp,%rdi
    e4e0:	e8 bb 8a ff ff       	call   6fa0 <fwp_drop0>
    e4e5:	48 89 df             	mov    %rbx,%rdi
    e4e8:	e8 b3 8a ff ff       	call   6fa0 <fwp_drop0>
    e4ed:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    e4f4:	00 
    e4f5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e4fc:	00 00 
    e4fe:	0f 85 95 04 00 00    	jne    e999 <f0+0x2cf9>
    e504:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    e50b:	31 c0                	xor    %eax,%eax
    e50d:	5b                   	pop    %rbx
    e50e:	5d                   	pop    %rbp
    e50f:	41 5c                	pop    %r12
    e511:	41 5d                	pop    %r13
    e513:	41 5e                	pop    %r14
    e515:	c3                   	ret
    e516:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e51d:	00 00 00 
    e520:	4c 89 ef             	mov    %r13,%rdi
    e523:	e8 08 73 ff ff       	call   5830 <fwp_rc_forget_slot>
    e528:	e9 2c d8 ff ff       	jmp    bd59 <f0+0xb9>
    e52d:	0f 1f 00             	nopl   (%rax)
    e530:	66 85 c0             	test   %ax,%ax
    e533:	0f 85 ae f5 ff ff    	jne    dae7 <f0+0x1e47>
    e539:	e9 99 f5 ff ff       	jmp    dad7 <f0+0x1e37>
    e53e:	66 90                	xchg   %ax,%ax
    e540:	66 85 c0             	test   %ax,%ax
    e543:	0f 85 ff f4 ff ff    	jne    da48 <f0+0x1da8>
    e549:	e9 ea f4 ff ff       	jmp    da38 <f0+0x1d98>
    e54e:	66 90                	xchg   %ax,%ax
    e550:	66 85 c0             	test   %ax,%ax
    e553:	0f 85 50 f4 ff ff    	jne    d9a9 <f0+0x1d09>
    e559:	e9 3b f4 ff ff       	jmp    d999 <f0+0x1cf9>
    e55e:	66 90                	xchg   %ax,%ax
    e560:	66 85 c0             	test   %ax,%ax
    e563:	0f 85 a1 f3 ff ff    	jne    d90a <f0+0x1c6a>
    e569:	e9 8c f3 ff ff       	jmp    d8fa <f0+0x1c5a>
    e56e:	66 90                	xchg   %ax,%ax
    e570:	66 85 c0             	test   %ax,%ax
    e573:	0f 85 f2 f2 ff ff    	jne    d86b <f0+0x1bcb>
    e579:	e9 dd f2 ff ff       	jmp    d85b <f0+0x1bbb>
    e57e:	66 90                	xchg   %ax,%ax
    e580:	66 85 c0             	test   %ax,%ax
    e583:	0f 85 43 f2 ff ff    	jne    d7cc <f0+0x1b2c>
    e589:	e9 2e f2 ff ff       	jmp    d7bc <f0+0x1b1c>
    e58e:	66 90                	xchg   %ax,%ax
    e590:	66 85 c0             	test   %ax,%ax
    e593:	0f 85 94 f1 ff ff    	jne    d72d <f0+0x1a8d>
    e599:	e9 7f f1 ff ff       	jmp    d71d <f0+0x1a7d>
    e59e:	66 90                	xchg   %ax,%ax
    e5a0:	66 85 c0             	test   %ax,%ax
    e5a3:	0f 85 e5 f0 ff ff    	jne    d68e <f0+0x19ee>
    e5a9:	e9 d0 f0 ff ff       	jmp    d67e <f0+0x19de>
    e5ae:	66 90                	xchg   %ax,%ax
    e5b0:	66 85 c0             	test   %ax,%ax
    e5b3:	0f 85 fd d9 ff ff    	jne    bfb6 <f0+0x316>
    e5b9:	e9 e8 d9 ff ff       	jmp    bfa6 <f0+0x306>
    e5be:	66 90                	xchg   %ax,%ax
    e5c0:	66 85 c0             	test   %ax,%ax
    e5c3:	0f 85 57 d9 ff ff    	jne    bf20 <f0+0x280>
    e5c9:	e9 42 d9 ff ff       	jmp    bf10 <f0+0x270>
    e5ce:	66 90                	xchg   %ax,%ax
    e5d0:	66 85 c0             	test   %ax,%ax
    e5d3:	0f 85 b1 d8 ff ff    	jne    be8a <f0+0x1ea>
    e5d9:	e9 9c d8 ff ff       	jmp    be7a <f0+0x1da>
    e5de:	66 90                	xchg   %ax,%ax
    e5e0:	66 85 c0             	test   %ax,%ax
    e5e3:	0f 85 0e eb ff ff    	jne    d0f7 <f0+0x1457>
    e5e9:	e9 f9 ea ff ff       	jmp    d0e7 <f0+0x1447>
    e5ee:	66 90                	xchg   %ax,%ax
    e5f0:	66 85 c0             	test   %ax,%ax
    e5f3:	0f 85 91 db ff ff    	jne    c18a <f0+0x4ea>
    e5f9:	e9 7c db ff ff       	jmp    c17a <f0+0x4da>
    e5fe:	66 90                	xchg   %ax,%ax
    e600:	66 85 c0             	test   %ax,%ax
    e603:	0f 85 e2 da ff ff    	jne    c0eb <f0+0x44b>
    e609:	e9 cd da ff ff       	jmp    c0db <f0+0x43b>
    e60e:	66 90                	xchg   %ax,%ax
    e610:	66 85 c0             	test   %ax,%ax
    e613:	0f 85 33 da ff ff    	jne    c04c <f0+0x3ac>
    e619:	e9 1e da ff ff       	jmp    c03c <f0+0x39c>
    e61e:	66 90                	xchg   %ax,%ax
    e620:	66 85 c0             	test   %ax,%ax
    e623:	0f 85 c6 ef ff ff    	jne    d5ef <f0+0x194f>
    e629:	e9 b1 ef ff ff       	jmp    d5df <f0+0x193f>
    e62e:	66 90                	xchg   %ax,%ax
    e630:	66 85 c0             	test   %ax,%ax
    e633:	0f 85 17 ef ff ff    	jne    d550 <f0+0x18b0>
    e639:	e9 02 ef ff ff       	jmp    d540 <f0+0x18a0>
    e63e:	66 90                	xchg   %ax,%ax
    e640:	66 85 c0             	test   %ax,%ax
    e643:	0f 85 68 ee ff ff    	jne    d4b1 <f0+0x1811>
    e649:	e9 53 ee ff ff       	jmp    d4a1 <f0+0x1801>
    e64e:	66 90                	xchg   %ax,%ax
    e650:	66 85 c0             	test   %ax,%ax
    e653:	0f 85 b9 ed ff ff    	jne    d412 <f0+0x1772>
    e659:	e9 a4 ed ff ff       	jmp    d402 <f0+0x1762>
    e65e:	66 90                	xchg   %ax,%ax
    e660:	66 85 c0             	test   %ax,%ax
    e663:	0f 85 0a ed ff ff    	jne    d373 <f0+0x16d3>
    e669:	e9 f5 ec ff ff       	jmp    d363 <f0+0x16c3>
    e66e:	66 90                	xchg   %ax,%ax
    e670:	66 85 c0             	test   %ax,%ax
    e673:	0f 85 5b ec ff ff    	jne    d2d4 <f0+0x1634>
    e679:	e9 46 ec ff ff       	jmp    d2c4 <f0+0x1624>
    e67e:	66 90                	xchg   %ax,%ax
    e680:	66 85 c0             	test   %ax,%ax
    e683:	0f 85 ac eb ff ff    	jne    d235 <f0+0x1595>
    e689:	e9 97 eb ff ff       	jmp    d225 <f0+0x1585>
    e68e:	66 90                	xchg   %ax,%ax
    e690:	66 85 c0             	test   %ax,%ax
    e693:	0f 85 fd ea ff ff    	jne    d196 <f0+0x14f6>
    e699:	e9 e8 ea ff ff       	jmp    d186 <f0+0x14e6>
    e69e:	66 90                	xchg   %ax,%ax
    e6a0:	66 85 c0             	test   %ax,%ax
    e6a3:	0f 85 29 fe ff ff    	jne    e4d2 <f0+0x2832>
    e6a9:	e9 14 fe ff ff       	jmp    e4c2 <f0+0x2822>
    e6ae:	66 90                	xchg   %ax,%ax
    e6b0:	66 85 c0             	test   %ax,%ax
    e6b3:	0f 85 7f fd ff ff    	jne    e438 <f0+0x2798>
    e6b9:	e9 6a fd ff ff       	jmp    e428 <f0+0x2788>
    e6be:	66 90                	xchg   %ax,%ax
    e6c0:	66 85 c0             	test   %ax,%ax
    e6c3:	0f 85 d0 fc ff ff    	jne    e399 <f0+0x26f9>
    e6c9:	e9 bb fc ff ff       	jmp    e389 <f0+0x26e9>
    e6ce:	66 90                	xchg   %ax,%ax
    e6d0:	66 85 c0             	test   %ax,%ax
    e6d3:	0f 85 21 fc ff ff    	jne    e2fa <f0+0x265a>
    e6d9:	e9 0c fc ff ff       	jmp    e2ea <f0+0x264a>
    e6de:	66 90                	xchg   %ax,%ax
    e6e0:	66 85 c0             	test   %ax,%ax
    e6e3:	0f 85 72 fb ff ff    	jne    e25b <f0+0x25bb>
    e6e9:	e9 5d fb ff ff       	jmp    e24b <f0+0x25ab>
    e6ee:	66 90                	xchg   %ax,%ax
    e6f0:	66 85 c0             	test   %ax,%ax
    e6f3:	0f 85 c3 fa ff ff    	jne    e1bc <f0+0x251c>
    e6f9:	e9 ae fa ff ff       	jmp    e1ac <f0+0x250c>
    e6fe:	66 90                	xchg   %ax,%ax
    e700:	66 85 c0             	test   %ax,%ax
    e703:	0f 85 14 fa ff ff    	jne    e11d <f0+0x247d>
    e709:	e9 ff f9 ff ff       	jmp    e10d <f0+0x246d>
    e70e:	66 90                	xchg   %ax,%ax
    e710:	66 85 c0             	test   %ax,%ax
    e713:	0f 85 65 f9 ff ff    	jne    e07e <f0+0x23de>
    e719:	e9 50 f9 ff ff       	jmp    e06e <f0+0x23ce>
    e71e:	66 90                	xchg   %ax,%ax
    e720:	66 85 c0             	test   %ax,%ax
    e723:	0f 85 b6 f8 ff ff    	jne    dfdf <f0+0x233f>
    e729:	e9 a1 f8 ff ff       	jmp    dfcf <f0+0x232f>
    e72e:	66 90                	xchg   %ax,%ax
    e730:	66 85 c0             	test   %ax,%ax
    e733:	0f 85 07 f8 ff ff    	jne    df40 <f0+0x22a0>
    e739:	e9 f2 f7 ff ff       	jmp    df30 <f0+0x2290>
    e73e:	66 90                	xchg   %ax,%ax
    e740:	66 85 c0             	test   %ax,%ax
    e743:	0f 85 58 f7 ff ff    	jne    dea1 <f0+0x2201>
    e749:	e9 43 f7 ff ff       	jmp    de91 <f0+0x21f1>
    e74e:	66 90                	xchg   %ax,%ax
    e750:	66 85 c0             	test   %ax,%ax
    e753:	0f 85 a9 f6 ff ff    	jne    de02 <f0+0x2162>
    e759:	e9 94 f6 ff ff       	jmp    ddf2 <f0+0x2152>
    e75e:	66 90                	xchg   %ax,%ax
    e760:	66 85 c0             	test   %ax,%ax
    e763:	0f 85 fa f5 ff ff    	jne    dd63 <f0+0x20c3>
    e769:	e9 e5 f5 ff ff       	jmp    dd53 <f0+0x20b3>
    e76e:	66 90                	xchg   %ax,%ax
    e770:	66 85 c0             	test   %ax,%ax
    e773:	0f 85 4b f5 ff ff    	jne    dcc4 <f0+0x2024>
    e779:	e9 36 f5 ff ff       	jmp    dcb4 <f0+0x2014>
    e77e:	66 90                	xchg   %ax,%ax
    e780:	66 85 c0             	test   %ax,%ax
    e783:	0f 85 9c f4 ff ff    	jne    dc25 <f0+0x1f85>
    e789:	e9 87 f4 ff ff       	jmp    dc15 <f0+0x1f75>
    e78e:	66 90                	xchg   %ax,%ax
    e790:	66 85 c0             	test   %ax,%ax
    e793:	0f 85 ed f3 ff ff    	jne    db86 <f0+0x1ee6>
    e799:	e9 d8 f3 ff ff       	jmp    db76 <f0+0x1ed6>
    e79e:	4c 89 e7             	mov    %r12,%rdi
    e7a1:	e8 8a 70 ff ff       	call   5830 <fwp_rc_forget_slot>
    e7a6:	e9 22 fd ff ff       	jmp    e4cd <f0+0x282d>
    e7ab:	4c 89 e7             	mov    %r12,%rdi
    e7ae:	e8 7d 70 ff ff       	call   5830 <fwp_rc_forget_slot>
    e7b3:	e9 cd d6 ff ff       	jmp    be85 <f0+0x1e5>
    e7b8:	4c 89 e7             	mov    %r12,%rdi
    e7bb:	e8 70 70 ff ff       	call   5830 <fwp_rc_forget_slot>
    e7c0:	e9 56 d7 ff ff       	jmp    bf1b <f0+0x27b>
    e7c5:	4c 89 e7             	mov    %r12,%rdi
    e7c8:	e8 63 70 ff ff       	call   5830 <fwp_rc_forget_slot>
    e7cd:	e9 df d7 ff ff       	jmp    bfb1 <f0+0x311>
    e7d2:	4c 89 e7             	mov    %r12,%rdi
    e7d5:	e8 56 70 ff ff       	call   5830 <fwp_rc_forget_slot>
    e7da:	e9 68 d8 ff ff       	jmp    c047 <f0+0x3a7>
    e7df:	4c 89 e7             	mov    %r12,%rdi
    e7e2:	e8 49 70 ff ff       	call   5830 <fwp_rc_forget_slot>
    e7e7:	e9 fa d8 ff ff       	jmp    c0e6 <f0+0x446>
    e7ec:	4c 89 e7             	mov    %r12,%rdi
    e7ef:	e8 3c 70 ff ff       	call   5830 <fwp_rc_forget_slot>
    e7f4:	e9 8c d9 ff ff       	jmp    c185 <f0+0x4e5>
    e7f9:	4c 89 e7             	mov    %r12,%rdi
    e7fc:	e8 2f 70 ff ff       	call   5830 <fwp_rc_forget_slot>
    e801:	e9 ec e8 ff ff       	jmp    d0f2 <f0+0x1452>
    e806:	4c 89 e7             	mov    %r12,%rdi
    e809:	e8 22 70 ff ff       	call   5830 <fwp_rc_forget_slot>
    e80e:	e9 7e e9 ff ff       	jmp    d191 <f0+0x14f1>
    e813:	4c 89 e7             	mov    %r12,%rdi
    e816:	e8 15 70 ff ff       	call   5830 <fwp_rc_forget_slot>
    e81b:	e9 10 ea ff ff       	jmp    d230 <f0+0x1590>
    e820:	4c 89 e7             	mov    %r12,%rdi
    e823:	e8 08 70 ff ff       	call   5830 <fwp_rc_forget_slot>
    e828:	e9 a2 ea ff ff       	jmp    d2cf <f0+0x162f>
    e82d:	4c 89 e7             	mov    %r12,%rdi
    e830:	e8 fb 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e835:	e9 34 eb ff ff       	jmp    d36e <f0+0x16ce>
    e83a:	4c 89 e7             	mov    %r12,%rdi
    e83d:	e8 ee 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e842:	e9 c6 eb ff ff       	jmp    d40d <f0+0x176d>
    e847:	4c 89 e7             	mov    %r12,%rdi
    e84a:	e8 e1 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e84f:	e9 58 ec ff ff       	jmp    d4ac <f0+0x180c>
    e854:	4c 89 e7             	mov    %r12,%rdi
    e857:	e8 d4 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e85c:	e9 ea ec ff ff       	jmp    d54b <f0+0x18ab>
    e861:	4c 89 e7             	mov    %r12,%rdi
    e864:	e8 c7 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e869:	e9 7c ed ff ff       	jmp    d5ea <f0+0x194a>
    e86e:	4c 89 e7             	mov    %r12,%rdi
    e871:	e8 ba 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e876:	e9 0e ee ff ff       	jmp    d689 <f0+0x19e9>
    e87b:	4c 89 e7             	mov    %r12,%rdi
    e87e:	e8 ad 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e883:	e9 a0 ee ff ff       	jmp    d728 <f0+0x1a88>
    e888:	4c 89 e7             	mov    %r12,%rdi
    e88b:	e8 a0 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e890:	e9 32 ef ff ff       	jmp    d7c7 <f0+0x1b27>
    e895:	4c 89 e7             	mov    %r12,%rdi
    e898:	e8 93 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e89d:	e9 c4 ef ff ff       	jmp    d866 <f0+0x1bc6>
    e8a2:	4c 89 e7             	mov    %r12,%rdi
    e8a5:	e8 86 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e8aa:	e9 56 f0 ff ff       	jmp    d905 <f0+0x1c65>
    e8af:	4c 89 e7             	mov    %r12,%rdi
    e8b2:	e8 79 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e8b7:	e9 e8 f0 ff ff       	jmp    d9a4 <f0+0x1d04>
    e8bc:	4c 89 e7             	mov    %r12,%rdi
    e8bf:	e8 6c 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e8c4:	e9 7a f1 ff ff       	jmp    da43 <f0+0x1da3>
    e8c9:	4c 89 e7             	mov    %r12,%rdi
    e8cc:	e8 5f 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e8d1:	e9 0c f2 ff ff       	jmp    dae2 <f0+0x1e42>
    e8d6:	4c 89 e7             	mov    %r12,%rdi
    e8d9:	e8 52 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e8de:	e9 9e f2 ff ff       	jmp    db81 <f0+0x1ee1>
    e8e3:	4c 89 e7             	mov    %r12,%rdi
    e8e6:	e8 45 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e8eb:	e9 30 f3 ff ff       	jmp    dc20 <f0+0x1f80>
    e8f0:	4c 89 e7             	mov    %r12,%rdi
    e8f3:	e8 38 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e8f8:	e9 c2 f3 ff ff       	jmp    dcbf <f0+0x201f>
    e8fd:	4c 89 e7             	mov    %r12,%rdi
    e900:	e8 2b 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e905:	e9 54 f4 ff ff       	jmp    dd5e <f0+0x20be>
    e90a:	4c 89 e7             	mov    %r12,%rdi
    e90d:	e8 1e 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e912:	e9 e6 f4 ff ff       	jmp    ddfd <f0+0x215d>
    e917:	4c 89 e7             	mov    %r12,%rdi
    e91a:	e8 11 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e91f:	e9 78 f5 ff ff       	jmp    de9c <f0+0x21fc>
    e924:	4c 89 e7             	mov    %r12,%rdi
    e927:	e8 04 6f ff ff       	call   5830 <fwp_rc_forget_slot>
    e92c:	e9 0a f6 ff ff       	jmp    df3b <f0+0x229b>
    e931:	4c 89 e7             	mov    %r12,%rdi
    e934:	e8 f7 6e ff ff       	call   5830 <fwp_rc_forget_slot>
    e939:	e9 9c f6 ff ff       	jmp    dfda <f0+0x233a>
    e93e:	4c 89 e7             	mov    %r12,%rdi
    e941:	e8 ea 6e ff ff       	call   5830 <fwp_rc_forget_slot>
    e946:	e9 2e f7 ff ff       	jmp    e079 <f0+0x23d9>
    e94b:	4c 89 e7             	mov    %r12,%rdi
    e94e:	e8 dd 6e ff ff       	call   5830 <fwp_rc_forget_slot>
    e953:	e9 c0 f7 ff ff       	jmp    e118 <f0+0x2478>
    e958:	4c 89 e7             	mov    %r12,%rdi
    e95b:	e8 d0 6e ff ff       	call   5830 <fwp_rc_forget_slot>
    e960:	e9 52 f8 ff ff       	jmp    e1b7 <f0+0x2517>
    e965:	4c 89 e7             	mov    %r12,%rdi
    e968:	e8 c3 6e ff ff       	call   5830 <fwp_rc_forget_slot>
    e96d:	e9 e4 f8 ff ff       	jmp    e256 <f0+0x25b6>
    e972:	4c 89 e7             	mov    %r12,%rdi
    e975:	e8 b6 6e ff ff       	call   5830 <fwp_rc_forget_slot>
    e97a:	e9 76 f9 ff ff       	jmp    e2f5 <f0+0x2655>
    e97f:	4c 89 e7             	mov    %r12,%rdi
    e982:	e8 a9 6e ff ff       	call   5830 <fwp_rc_forget_slot>
    e987:	e9 08 fa ff ff       	jmp    e394 <f0+0x26f4>
    e98c:	4c 89 e7             	mov    %r12,%rdi
    e98f:	e8 9c 6e ff ff       	call   5830 <fwp_rc_forget_slot>
    e994:	e9 9a fa ff ff       	jmp    e433 <f0+0x2793>
    e999:	e8 b2 4a ff ff       	call   3450 <__stack_chk_fail@plt>
    e99e:	66 90                	xchg   %ax,%ax

000000000000e9a0 <fwp_main_thread>:
    e9a0:	f3 0f 1e fa          	endbr64
    e9a4:	41 54                	push   %r12
    e9a6:	55                   	push   %rbp
    e9a7:	53                   	push   %rbx
    e9a8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    e9af:	8b 0d 4f f2 05 00    	mov    0x5f24f(%rip),%ecx        # 6dc04 <fwp_heap+0x13a4>
    e9b5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    e9bc:	00 00 
    e9be:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    e9c5:	00 
    e9c6:	31 c0                	xor    %eax,%eax
    e9c8:	85 c9                	test   %ecx,%ecx
    e9ca:	0f 84 58 07 00 00    	je     f128 <fwp_main_thread+0x788>
    e9d0:	8b 15 32 f2 05 00    	mov    0x5f232(%rip),%edx        # 6dc08 <fwp_heap+0x13a8>
    e9d6:	85 d2                	test   %edx,%edx
    e9d8:	0f 85 32 07 00 00    	jne    f110 <fwp_main_thread+0x770>
    e9de:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    e9e3:	31 f6                	xor    %esi,%esi
    e9e5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    e9ea:	48 c7 05 0b d8 05 00 	movq   $0x40000000,0x5d80b(%rip)        # 6c200 <fwp_main_stack_size>
    e9f1:	00 00 00 40 
    e9f5:	48 89 05 0c d8 05 00 	mov    %rax,0x5d80c(%rip)        # 6c208 <fwp_main_stack_top>
    e9fc:	48 8d 05 bd 56 00 00 	lea    0x56bd(%rip),%rax        # 140c0 <alt.9>
    ea03:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    ea08:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    ea0f:	01 00 
    ea11:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    ea18:	00 
    ea19:	e8 82 4c ff ff       	call   36a0 <sigaltstack@plt>
    ea1e:	85 c0                	test   %eax,%eax
    ea20:	0f 85 6a 07 00 00    	jne    f190 <fwp_main_thread+0x7f0>
    ea26:	31 c0                	xor    %eax,%eax
    ea28:	b9 12 00 00 00       	mov    $0x12,%ecx
    ea2d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    ea32:	f3 48 ab             	rep stos %rax,(%rdi)
    ea35:	48 8d 05 04 53 ff ff 	lea    -0xacfc(%rip),%rax        # 3d40 <fwp_segv>
    ea3c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    ea41:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    ea48:	04 00 00 08 
    ea4c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    ea51:	e8 0a 4b ff ff       	call   3560 <sigemptyset@plt>
    ea56:	85 c0                	test   %eax,%eax
    ea58:	0f 85 32 07 00 00    	jne    f190 <fwp_main_thread+0x7f0>
    ea5e:	31 d2                	xor    %edx,%edx
    ea60:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    ea65:	bf 0b 00 00 00       	mov    $0xb,%edi
    ea6a:	e8 81 49 ff ff       	call   33f0 <sigaction@plt>
    ea6f:	85 c0                	test   %eax,%eax
    ea71:	0f 85 19 07 00 00    	jne    f190 <fwp_main_thread+0x7f0>
    ea77:	31 d2                	xor    %edx,%edx
    ea79:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    ea7e:	bf 07 00 00 00       	mov    $0x7,%edi
    ea83:	e8 68 49 ff ff       	call   33f0 <sigaction@plt>
    ea88:	85 c0                	test   %eax,%eax
    ea8a:	0f 85 00 07 00 00    	jne    f190 <fwp_main_thread+0x7f0>
    ea90:	48 8b 05 e9 f1 05 00 	mov    0x5f1e9(%rip),%rax        # 6dc80 <fwp_heap+0x1420>
    ea97:	48 85 c0             	test   %rax,%rax
    ea9a:	0f 88 50 06 00 00    	js     f0f0 <fwp_main_thread+0x750>
    eaa0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    eaa4:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    eaa9:	48 8d 3d 70 57 ff ff 	lea    -0xa890(%rip),%rdi        # 4220 <ad_raw_report>
    eab0:	f2 0f 11 05 50 fa 05 	movsd  %xmm0,0x5fa50(%rip)        # 6e508 <iteration_start_charge>
    eab7:	00 
    eab8:	c7 05 66 fa 05 00 01 	movl   $0x1,0x5fa66(%rip)        # 6e528 <iteration_active>
    eabf:	00 00 00 
    eac2:	e8 09 09 00 00       	call   f3d0 <atexit>
    eac7:	85 c0                	test   %eax,%eax
    eac9:	0f 85 cd 06 00 00    	jne    f19c <fwp_main_thread+0x7fc>
    eacf:	8b 05 db 55 00 00    	mov    0x55db(%rip),%eax        # 140b0 <st.7>
    ead5:	85 c0                	test   %eax,%eax
    ead7:	0f 84 5b 06 00 00    	je     f138 <fwp_main_thread+0x798>
    eadd:	48 8b 2d 5c dd 05 00 	mov    0x5dd5c(%rip),%rbp        # 6c840 <fwp_cur>
    eae4:	48 85 ed             	test   %rbp,%rbp
    eae7:	0f 84 03 03 00 00    	je     edf0 <fwp_main_thread+0x450>
    eaed:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    eaf2:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    eaf6:	48 89 eb             	mov    %rbp,%rbx
    eaf9:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    eafe:	0f 84 41 01 00 00    	je     ec45 <fwp_main_thread+0x2a5>
    eb04:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    eb09:	0f 84 11 02 00 00    	je     ed20 <fwp_main_thread+0x380>
    eb0f:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    eb13:	0f 84 f7 01 00 00    	je     ed10 <fwp_main_thread+0x370>
    eb19:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    eb1d:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    eb21:	0f 85 79 02 00 00    	jne    eda0 <fwp_main_thread+0x400>
    eb27:	48 8b 43 60          	mov    0x60(%rbx),%rax
    eb2b:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    eb32:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    eb36:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    eb3d:	00 00 00 00 
    eb41:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    eb48:	48 85 d2             	test   %rdx,%rdx
    eb4b:	74 07                	je     eb54 <fwp_main_thread+0x1b4>
    eb4d:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    eb54:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    eb58:	48 85 c0             	test   %rax,%rax
    eb5b:	74 34                	je     eb91 <fwp_main_thread+0x1f1>
    eb5d:	48 89 43 68          	mov    %rax,0x68(%rbx)
    eb61:	48 8b 05 b0 dc 05 00 	mov    0x5dcb0(%rip),%rax        # 6c818 <fwp_timers>
    eb68:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    eb6c:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    eb73:	00 00 00 00 
    eb77:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    eb7e:	48 85 c0             	test   %rax,%rax
    eb81:	74 07                	je     eb8a <fwp_main_thread+0x1ea>
    eb83:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    eb8a:	48 89 1d 87 dc 05 00 	mov    %rbx,0x5dc87(%rip)        # 6c818 <fwp_timers>
    eb91:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    eb95:	e8 76 8e ff ff       	call   7a10 <fwp_block>
    eb9a:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    eba1:	48 85 c9             	test   %rcx,%rcx
    eba4:	74 47                	je     ebed <fwp_main_thread+0x24d>
    eba6:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    ebad:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    ebb4:	48 85 d2             	test   %rdx,%rdx
    ebb7:	0f 84 23 02 00 00    	je     ede0 <fwp_main_thread+0x440>
    ebbd:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    ebc4:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    ebcb:	48 85 c0             	test   %rax,%rax
    ebce:	74 07                	je     ebd7 <fwp_main_thread+0x237>
    ebd0:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    ebd7:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    ebde:	00 00 00 00 
    ebe2:	66 0f ef d2          	pxor   %xmm2,%xmm2
    ebe6:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    ebed:	48 8b 0d 4c dc 05 00 	mov    0x5dc4c(%rip),%rcx        # 6c840 <fwp_cur>
    ebf4:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    ebf8:	0f 84 92 01 00 00    	je     ed90 <fwp_main_thread+0x3f0>
    ebfe:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    ec05:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    ec0c:	48 85 d2             	test   %rdx,%rdx
    ec0f:	0f 84 1b 04 00 00    	je     f030 <fwp_main_thread+0x690>
    ec15:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    ec1c:	48 85 c0             	test   %rax,%rax
    ec1f:	74 07                	je     ec28 <fwp_main_thread+0x288>
    ec21:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    ec28:	66 0f ef db          	pxor   %xmm3,%xmm3
    ec2c:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    ec30:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    ec37:	48 89 cb             	mov    %rcx,%rbx
    ec3a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    ec3f:	0f 85 bf fe ff ff    	jne    eb04 <fwp_main_thread+0x164>
    ec45:	48 83 3d 8b f8 05 00 	cmpq   $0x0,0x5f88b(%rip)        # 6e4d8 <fwp_state_len>
    ec4c:	00 
    ec4d:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    ec51:	0f 84 0b 04 00 00    	je     f062 <fwp_main_thread+0x6c2>
    ec57:	48 3b 1d da db 05 00 	cmp    0x5dbda(%rip),%rbx        # 6c838 <fwp_root>
    ec5e:	c7 05 58 54 01 00 00 	movl   $0x0,0x15458(%rip)        # 240c0 <fwp_exit_code>
    ec65:	00 00 00 
    ec68:	0f 85 4c 05 00 00    	jne    f1ba <fwp_main_thread+0x81a>
    ec6e:	48 85 db             	test   %rbx,%rbx
    ec71:	0f 84 9f 01 00 00    	je     ee16 <fwp_main_thread+0x476>
    ec77:	48 8b 15 8a db 05 00 	mov    0x5db8a(%rip),%rdx        # 6c808 <fwp_tasks_active>
    ec7e:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    ec82:	48 85 d2             	test   %rdx,%rdx
    ec85:	0f 84 8b 01 00 00    	je     ee16 <fwp_main_thread+0x476>
    ec8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ec90:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    ec94:	75 08                	jne    ec9e <fwp_main_thread+0x2fe>
    ec96:	48 89 d7             	mov    %rdx,%rdi
    ec99:	e8 92 54 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    ec9e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    eca5:	48 85 d2             	test   %rdx,%rdx
    eca8:	75 e6                	jne    ec90 <fwp_main_thread+0x2f0>
    ecaa:	eb 31                	jmp    ecdd <fwp_main_thread+0x33d>
    ecac:	0f 1f 40 00          	nopl   0x0(%rax)
    ecb0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    ecb7:	48 89 1d 62 db 05 00 	mov    %rbx,0x5db62(%rip)        # 6c820 <fwp_ready_tail>
    ecbe:	e8 4d 8d ff ff       	call   7a10 <fwp_block>
    ecc3:	e8 48 8b ff ff       	call   7810 <fwp_free_zombie>
    ecc8:	48 83 3d 38 db 05 00 	cmpq   $0x0,0x5db38(%rip)        # 6c808 <fwp_tasks_active>
    eccf:	00 
    ecd0:	0f 84 40 01 00 00    	je     ee16 <fwp_main_thread+0x476>
    ecd6:	48 8b 1d 5b db 05 00 	mov    0x5db5b(%rip),%rbx        # 6c838 <fwp_root>
    ecdd:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    ece1:	75 db                	jne    ecbe <fwp_main_thread+0x31e>
    ece3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    ece7:	75 d5                	jne    ecbe <fwp_main_thread+0x31e>
    ece9:	48 8b 05 30 db 05 00 	mov    0x5db30(%rip),%rax        # 6c820 <fwp_ready_tail>
    ecf0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    ecf4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    ecfb:	00 00 00 00 
    ecff:	48 85 c0             	test   %rax,%rax
    ed02:	75 ac                	jne    ecb0 <fwp_main_thread+0x310>
    ed04:	48 89 1d 1d db 05 00 	mov    %rbx,0x5db1d(%rip)        # 6c828 <fwp_ready_head>
    ed0b:	eb aa                	jmp    ecb7 <fwp_main_thread+0x317>
    ed0d:	0f 1f 00             	nopl   (%rax)
    ed10:	e8 ab 58 ff ff       	call   45c0 <fwp_now_ns>
    ed15:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    ed19:	0f 8d 21 03 00 00    	jge    f040 <fwp_main_thread+0x6a0>
    ed1f:	90                   	nop
    ed20:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    ed24:	0f 85 ef fd ff ff    	jne    eb19 <fwp_main_thread+0x179>
    ed2a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    ed2e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    ed32:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    ed36:	0f 85 ef fd ff ff    	jne    eb2b <fwp_main_thread+0x18b>
    ed3c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    ed40:	48 85 c9             	test   %rcx,%rcx
    ed43:	0f 84 e2 fd ff ff    	je     eb2b <fwp_main_thread+0x18b>
    ed49:	48 85 c0             	test   %rax,%rax
    ed4c:	0f 84 5b 04 00 00    	je     f1ad <fwp_main_thread+0x80d>
    ed52:	48 39 c8             	cmp    %rcx,%rax
    ed55:	48 0f 4f c1          	cmovg  %rcx,%rax
    ed59:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    ed60:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    ed64:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ed6b:	00 00 00 00 
    ed6f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    ed76:	48 85 d2             	test   %rdx,%rdx
    ed79:	74 07                	je     ed82 <fwp_main_thread+0x3e2>
    ed7b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    ed82:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ed86:	e9 d2 fd ff ff       	jmp    eb5d <fwp_main_thread+0x1bd>
    ed8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ed90:	48 89 cb             	mov    %rcx,%rbx
    ed93:	e9 61 fd ff ff       	jmp    eaf9 <fwp_main_thread+0x159>
    ed98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ed9f:	00 
    eda0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    eda4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    edab:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    edb2:	00 00 00 00 
    edb6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    edbd:	48 85 c0             	test   %rax,%rax
    edc0:	0f 84 9a 03 00 00    	je     f160 <fwp_main_thread+0x7c0>
    edc6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    edcd:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    edd1:	e9 bb fd ff ff       	jmp    eb91 <fwp_main_thread+0x1f1>
    edd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    eddd:	00 00 00 
    ede0:	48 89 01             	mov    %rax,(%rcx)
    ede3:	e9 e3 fd ff ff       	jmp    ebcb <fwp_main_thread+0x22b>
    ede8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    edef:	00 
    edf0:	48 83 3d e0 f6 05 00 	cmpq   $0x0,0x5f6e0(%rip)        # 6e4d8 <fwp_state_len>
    edf7:	00 
    edf8:	0f 84 62 02 00 00    	je     f060 <fwp_main_thread+0x6c0>
    edfe:	48 83 3d 32 da 05 00 	cmpq   $0x0,0x5da32(%rip)        # 6c838 <fwp_root>
    ee05:	00 
    ee06:	c7 05 b0 52 01 00 00 	movl   $0x0,0x152b0(%rip)        # 240c0 <fwp_exit_code>
    ee0d:	00 00 00 
    ee10:	0f 85 9f 03 00 00    	jne    f1b5 <fwp_main_thread+0x815>
    ee16:	e8 f5 89 ff ff       	call   7810 <fwp_free_zombie>
    ee1b:	48 83 3d 05 da 05 00 	cmpq   $0x0,0x5da05(%rip)        # 6c828 <fwp_ready_head>
    ee22:	00 
    ee23:	0f 85 27 49 ff ff    	jne    3750 <fwp_main_thread.cold>
    ee29:	48 83 3d e7 d9 05 00 	cmpq   $0x0,0x5d9e7(%rip)        # 6c818 <fwp_timers>
    ee30:	00 
    ee31:	0f 85 19 49 ff ff    	jne    3750 <fwp_main_thread.cold>
    ee37:	8b 1d d7 d3 05 00    	mov    0x5d3d7(%rip),%ebx        # 6c214 <fwp_stack_pool_n>
    ee3d:	85 db                	test   %ebx,%ebx
    ee3f:	74 36                	je     ee77 <fwp_main_thread+0x4d7>
    ee41:	83 eb 01             	sub    $0x1,%ebx
    ee44:	48 8d 05 d5 d3 05 00 	lea    0x5d3d5(%rip),%rax        # 6c220 <fwp_stack_pool>
    ee4b:	48 63 d3             	movslq %ebx,%rdx
    ee4e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    ee52:	eb 07                	jmp    ee5b <fwp_main_thread+0x4bb>
    ee54:	0f 1f 40 00          	nopl   0x0(%rax)
    ee58:	83 eb 01             	sub    $0x1,%ebx
    ee5b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    ee5f:	be 00 00 00 10       	mov    $0x10000000,%esi
    ee64:	89 1d aa d3 05 00    	mov    %ebx,0x5d3aa(%rip)        # 6c214 <fwp_stack_pool_n>
    ee6a:	48 83 ed 08          	sub    $0x8,%rbp
    ee6e:	e8 4d 47 ff ff       	call   35c0 <munmap@plt>
    ee73:	85 db                	test   %ebx,%ebx
    ee75:	75 e1                	jne    ee58 <fwp_main_thread+0x4b8>
    ee77:	8b 3d a3 51 00 00    	mov    0x51a3(%rip),%edi        # 14020 <fwp_epfd>
    ee7d:	85 ff                	test   %edi,%edi
    ee7f:	78 05                	js     ee86 <fwp_main_thread+0x4e6>
    ee81:	e8 3a 46 ff ff       	call   34c0 <close@plt>
    ee86:	4c 8b 25 93 d5 05 00 	mov    0x5d593(%rip),%r12        # 6c420 <fwp_nfdws>
    ee8d:	48 8b 2d 94 d5 05 00 	mov    0x5d594(%rip),%rbp        # 6c428 <fwp_fdws>
    ee94:	31 db                	xor    %ebx,%ebx
    ee96:	c7 05 80 51 00 00 ff 	movl   $0xffffffff,0x5180(%rip)        # 14020 <fwp_epfd>
    ee9d:	ff ff ff 
    eea0:	4d 85 e4             	test   %r12,%r12
    eea3:	74 38                	je     eedd <fwp_main_thread+0x53d>
    eea5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    eeac:	00 00 00 00 
    eeb0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    eeb5:	48 85 ff             	test   %rdi,%rdi
    eeb8:	74 1a                	je     eed4 <fwp_main_thread+0x534>
    eeba:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    eebe:	0f 85 8c 48 ff ff    	jne    3750 <fwp_main_thread.cold>
    eec4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    eec9:	0f 85 81 48 ff ff    	jne    3750 <fwp_main_thread.cold>
    eecf:	e8 9c 6b ff ff       	call   5a70 <fwp_mem_free>
    eed4:	48 83 c3 01          	add    $0x1,%rbx
    eed8:	49 39 dc             	cmp    %rbx,%r12
    eedb:	75 d3                	jne    eeb0 <fwp_main_thread+0x510>
    eedd:	48 89 ef             	mov    %rbp,%rdi
    eee0:	e8 8b 6b ff ff       	call   5a70 <fwp_mem_free>
    eee5:	48 8b 15 4c d9 05 00 	mov    0x5d94c(%rip),%rdx        # 6c838 <fwp_root>
    eeec:	48 c7 05 31 d5 05 00 	movq   $0x0,0x5d531(%rip)        # 6c428 <fwp_fdws>
    eef3:	00 00 00 00 
    eef7:	48 c7 05 1e d5 05 00 	movq   $0x0,0x5d51e(%rip)        # 6c420 <fwp_nfdws>
    eefe:	00 00 00 00 
    ef02:	48 85 d2             	test   %rdx,%rdx
    ef05:	74 4e                	je     ef55 <fwp_main_thread+0x5b5>
    ef07:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    ef0c:	0f 85 3e 48 ff ff    	jne    3750 <fwp_main_thread.cold>
    ef12:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    ef19:	00 
    ef1a:	0f 85 30 48 ff ff    	jne    3750 <fwp_main_thread.cold>
    ef20:	48 83 3d b0 f5 05 00 	cmpq   $0x0,0x5f5b0(%rip)        # 6e4d8 <fwp_state_len>
    ef27:	00 
    ef28:	0f 85 22 48 ff ff    	jne    3750 <fwp_main_thread.cold>
    ef2e:	48 83 3d 92 f5 05 00 	cmpq   $0x0,0x5f592(%rip)        # 6e4c8 <fwp_state_owners>
    ef35:	00 
    ef36:	0f 85 14 48 ff ff    	jne    3750 <fwp_main_thread.cold>
    ef3c:	b9 79 00 00 00       	mov    $0x79,%ecx
    ef41:	31 c0                	xor    %eax,%eax
    ef43:	48 8d 3d f6 d4 05 00 	lea    0x5d4f6(%rip),%rdi        # 6c440 <fwp_root_context>
    ef4a:	f3 48 ab             	rep stos %rax,(%rdi)
    ef4d:	48 89 d7             	mov    %rdx,%rdi
    ef50:	e8 1b 6b ff ff       	call   5a70 <fwp_mem_free>
    ef55:	66 0f 6f 05 93 52 04 	movdqa 0x45293(%rip),%xmm0        # 541f0 <ad_raw_live+0x10>
    ef5c:	00 
    ef5d:	66 0f d4 05 7b 52 04 	paddq  0x4527b(%rip),%xmm0        # 541e0 <ad_raw_live>
    ef64:	00 
    ef65:	48 c7 05 d0 d8 05 00 	movq   $0x0,0x5d8d0(%rip)        # 6c840 <fwp_cur>
    ef6c:	00 00 00 00 
    ef70:	48 8b 05 09 ed 05 00 	mov    0x5ed09(%rip),%rax        # 6dc80 <fwp_heap+0x1420>
    ef77:	48 c7 05 b6 d8 05 00 	movq   $0x0,0x5d8b6(%rip)        # 6c838 <fwp_root>
    ef7e:	00 00 00 00 
    ef82:	c7 05 9c f5 05 00 00 	movl   $0x0,0x5f59c(%rip)        # 6e528 <iteration_active>
    ef89:	00 00 00 
    ef8c:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    ef90:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    ef95:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    ef99:	66 0f d6 05 97 51 01 	movq   %xmm0,0x15197(%rip)        # 24138 <ad_raw_before_shutdown>
    efa0:	00 
    efa1:	48 85 c0             	test   %rax,%rax
    efa4:	0f 88 26 01 00 00    	js     f0d0 <fwp_main_thread+0x730>
    efaa:	66 0f ef c9          	pxor   %xmm1,%xmm1
    efae:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    efb3:	f2 0f 5c 0d 4d f5 05 	subsd  0x5f54d(%rip),%xmm1        # 6e508 <iteration_start_charge>
    efba:	00 
    efbb:	48 8b 3d 9e 50 00 00 	mov    0x509e(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    efc2:	48 8d 15 97 1b 00 00 	lea    0x1b97(%rip),%rdx        # 10b60 <_IO_stdin_used+0xb60>
    efc9:	be 02 00 00 00       	mov    $0x2,%esi
    efce:	f2 0f 10 05 2a f5 05 	movsd  0x5f52a(%rip),%xmm0        # 6e500 <iteration_peak>
    efd5:	00 
    efd6:	4c 8b 0d 33 f5 05 00 	mov    0x5f533(%rip),%r9        # 6e510 <iteration_retains>
    efdd:	b8 02 00 00 00       	mov    $0x2,%eax
    efe2:	4c 8b 05 2f f5 05 00 	mov    0x5f52f(%rip),%r8        # 6e518 <iteration_bytes>
    efe9:	48 8b 0d 30 f5 05 00 	mov    0x5f530(%rip),%rcx        # 6e520 <iteration_requests>
    eff0:	e8 7b 46 ff ff       	call   3670 <__fprintf_chk@plt>
    eff5:	48 8b 3d 44 50 00 00 	mov    0x5044(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    effc:	e8 9f 45 ff ff       	call   35a0 <fflush@plt>
    f001:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    f008:	00 
    f009:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    f010:	00 00 
    f012:	0f 85 90 01 00 00    	jne    f1a8 <fwp_main_thread+0x808>
    f018:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    f01f:	31 c0                	xor    %eax,%eax
    f021:	5b                   	pop    %rbx
    f022:	5d                   	pop    %rbp
    f023:	41 5c                	pop    %r12
    f025:	c3                   	ret
    f026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    f02d:	00 00 00 
    f030:	48 89 05 e1 d7 05 00 	mov    %rax,0x5d7e1(%rip)        # 6c818 <fwp_timers>
    f037:	e9 e0 fb ff ff       	jmp    ec1c <fwp_main_thread+0x27c>
    f03c:	0f 1f 40 00          	nopl   0x0(%rax)
    f040:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    f044:	0f 85 d6 fc ff ff    	jne    ed20 <fwp_main_thread+0x380>
    f04a:	48 89 ef             	mov    %rbp,%rdi
    f04d:	e8 de 50 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    f052:	e9 c9 fc ff ff       	jmp    ed20 <fwp_main_thread+0x380>
    f057:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    f05e:	00 00 
    f060:	31 db                	xor    %ebx,%ebx
    f062:	48 83 3d 5e f4 05 00 	cmpq   $0x0,0x5f45e(%rip)        # 6e4c8 <fwp_state_owners>
    f069:	00 
    f06a:	0f 85 e7 fb ff ff    	jne    ec57 <fwp_main_thread+0x2b7>
    f070:	48 8b 3d 69 f4 05 00 	mov    0x5f469(%rip),%rdi        # 6e4e0 <fwp_state>
    f077:	e8 f4 69 ff ff       	call   5a70 <fwp_mem_free>
    f07c:	48 c7 05 59 f4 05 00 	movq   $0x0,0x5f459(%rip)        # 6e4e0 <fwp_state>
    f083:	00 00 00 00 
    f087:	48 c7 05 3e f4 05 00 	movq   $0x0,0x5f43e(%rip)        # 6e4d0 <fwp_state_cap>
    f08e:	00 00 00 00 
    f092:	48 85 db             	test   %rbx,%rbx
    f095:	0f 84 ce 00 00 00    	je     f169 <fwp_main_thread+0x7c9>
    f09b:	48 39 1d 96 d7 05 00 	cmp    %rbx,0x5d796(%rip)        # 6c838 <fwp_root>
    f0a2:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    f0a9:	00 00 00 00 
    f0ad:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    f0b4:	00 00 00 00 
    f0b8:	c7 05 fe 4f 01 00 00 	movl   $0x0,0x14ffe(%rip)        # 240c0 <fwp_exit_code>
    f0bf:	00 00 00 
    f0c2:	0f 84 af fb ff ff    	je     ec77 <fwp_main_thread+0x2d7>
    f0c8:	e9 83 46 ff ff       	jmp    3750 <fwp_main_thread.cold>
    f0cd:	0f 1f 00             	nopl   (%rax)
    f0d0:	48 89 c2             	mov    %rax,%rdx
    f0d3:	83 e0 01             	and    $0x1,%eax
    f0d6:	66 0f ef c9          	pxor   %xmm1,%xmm1
    f0da:	48 d1 ea             	shr    $1,%rdx
    f0dd:	48 09 c2             	or     %rax,%rdx
    f0e0:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    f0e5:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    f0e9:	e9 c5 fe ff ff       	jmp    efb3 <fwp_main_thread+0x613>
    f0ee:	66 90                	xchg   %ax,%ax
    f0f0:	48 89 c2             	mov    %rax,%rdx
    f0f3:	83 e0 01             	and    $0x1,%eax
    f0f6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    f0fa:	48 d1 ea             	shr    $1,%rdx
    f0fd:	48 09 c2             	or     %rax,%rdx
    f100:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    f105:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    f109:	e9 9b f9 ff ff       	jmp    eaa9 <fwp_main_thread+0x109>
    f10e:	66 90                	xchg   %ax,%ax
    f110:	48 8d 3d a9 5b ff ff 	lea    -0xa457(%rip),%rdi        # 4cc0 <fwp_heap_report>
    f117:	e8 b4 02 00 00       	call   f3d0 <atexit>
    f11c:	e9 bd f8 ff ff       	jmp    e9de <fwp_main_thread+0x3e>
    f121:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    f128:	e8 a3 5c ff ff       	call   4dd0 <fwp_heap_init>
    f12d:	e9 9e f8 ff ff       	jmp    e9d0 <fwp_main_thread+0x30>
    f132:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    f138:	e8 63 cb ff ff       	call   bca0 <f0>
    f13d:	48 c7 05 60 4f 00 00 	movq   $0x0,0x4f60(%rip)        # 140a8 <v.6>
    f144:	00 00 00 00 
    f148:	c7 05 5e 4f 00 00 01 	movl   $0x1,0x4f5e(%rip)        # 140b0 <st.7>
    f14f:	00 00 00 
    f152:	e9 86 f9 ff ff       	jmp    eadd <fwp_main_thread+0x13d>
    f157:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    f15e:	00 00 
    f160:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    f164:	e9 28 fa ff ff       	jmp    eb91 <fwp_main_thread+0x1f1>
    f169:	48 83 3d c7 d6 05 00 	cmpq   $0x0,0x5d6c7(%rip)        # 6c838 <fwp_root>
    f170:	00 
    f171:	c7 05 45 4f 01 00 00 	movl   $0x0,0x14f45(%rip)        # 240c0 <fwp_exit_code>
    f178:	00 00 00 
    f17b:	0f 84 95 fc ff ff    	je     ee16 <fwp_main_thread+0x476>
    f181:	e9 ca 45 ff ff       	jmp    3750 <fwp_main_thread.cold>
    f186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    f18d:	00 00 00 
    f190:	48 8d 3d a1 19 00 00 	lea    0x19a1(%rip),%rdi        # 10b38 <_IO_stdin_used+0xb38>
    f197:	e8 b4 52 ff ff       	call   4450 <fwp_trap>
    f19c:	48 8d 3d 30 11 00 00 	lea    0x1130(%rip),%rdi        # 102d3 <_IO_stdin_used+0x2d3>
    f1a3:	e8 58 4e ff ff       	call   4000 <ad_raw_fail>
    f1a8:	e8 a3 42 ff ff       	call   3450 <__stack_chk_fail@plt>
    f1ad:	48 89 c8             	mov    %rcx,%rax
    f1b0:	e9 a4 fb ff ff       	jmp    ed59 <fwp_main_thread+0x3b9>
    f1b5:	e9 96 45 ff ff       	jmp    3750 <fwp_main_thread.cold>
    f1ba:	e9 91 45 ff ff       	jmp    3750 <fwp_main_thread.cold>
    f1bf:	90                   	nop

000000000000f1c0 <__divmodti4>:
    f1c0:	f3 0f 1e fa          	endbr64
    f1c4:	55                   	push   %rbp
    f1c5:	49 89 f1             	mov    %rsi,%r9
    f1c8:	49 89 d2             	mov    %rdx,%r10
    f1cb:	48 89 fe             	mov    %rdi,%rsi
    f1ce:	49 89 cb             	mov    %rcx,%r11
    f1d1:	48 89 e5             	mov    %rsp,%rbp
    f1d4:	41 57                	push   %r15
    f1d6:	41 56                	push   %r14
    f1d8:	41 55                	push   %r13
    f1da:	41 54                	push   %r12
    f1dc:	53                   	push   %rbx
    f1dd:	4c 89 c3             	mov    %r8,%rbx
    f1e0:	45 31 c0             	xor    %r8d,%r8d
    f1e3:	4d 85 c9             	test   %r9,%r9
    f1e6:	79 12                	jns    f1fa <__divmodti4+0x3a>
    f1e8:	31 ff                	xor    %edi,%edi
    f1ea:	48 f7 de             	neg    %rsi
    f1ed:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    f1f4:	4c 19 cf             	sbb    %r9,%rdi
    f1f7:	49 89 f9             	mov    %rdi,%r9
    f1fa:	4c 89 d8             	mov    %r11,%rax
    f1fd:	4d 85 db             	test   %r11,%r11
    f200:	0f 88 1a 01 00 00    	js     f320 <__divmodti4+0x160>
    f206:	4c 89 d9             	mov    %r11,%rcx
    f209:	49 89 f3             	mov    %rsi,%r11
    f20c:	75 62                	jne    f270 <__divmodti4+0xb0>
    f20e:	4d 89 c4             	mov    %r8,%r12
    f211:	4d 39 d1             	cmp    %r10,%r9
    f214:	0f 83 46 01 00 00    	jae    f360 <__divmodti4+0x1a0>
    f21a:	4c 89 d8             	mov    %r11,%rax
    f21d:	4c 89 ca             	mov    %r9,%rdx
    f220:	49 f7 f2             	div    %r10
    f223:	49 89 c3             	mov    %rax,%r11
    f226:	31 c0                	xor    %eax,%eax
    f228:	48 89 d6             	mov    %rdx,%rsi
    f22b:	31 ff                	xor    %edi,%edi
    f22d:	4c 89 d9             	mov    %r11,%rcx
    f230:	48 89 c2             	mov    %rax,%rdx
    f233:	48 89 c8             	mov    %rcx,%rax
    f236:	4d 85 e4             	test   %r12,%r12
    f239:	74 0a                	je     f245 <__divmodti4+0x85>
    f23b:	48 f7 d8             	neg    %rax
    f23e:	48 83 d2 00          	adc    $0x0,%rdx
    f242:	48 f7 da             	neg    %rdx
    f245:	4d 85 c0             	test   %r8,%r8
    f248:	74 0a                	je     f254 <__divmodti4+0x94>
    f24a:	48 f7 de             	neg    %rsi
    f24d:	48 83 d7 00          	adc    $0x0,%rdi
    f251:	48 f7 df             	neg    %rdi
    f254:	48 89 33             	mov    %rsi,(%rbx)
    f257:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    f25b:	5b                   	pop    %rbx
    f25c:	41 5c                	pop    %r12
    f25e:	41 5d                	pop    %r13
    f260:	41 5e                	pop    %r14
    f262:	41 5f                	pop    %r15
    f264:	5d                   	pop    %rbp
    f265:	c3                   	ret
    f266:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    f26d:	00 00 00 
    f270:	4d 89 c4             	mov    %r8,%r12
    f273:	49 39 c1             	cmp    %rax,%r9
    f276:	0f 82 ce 00 00 00    	jb     f34a <__divmodti4+0x18a>
    f27c:	31 ff                	xor    %edi,%edi
    f27e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    f283:	48 63 c7             	movslq %edi,%rax
    f286:	be 40 00 00 00       	mov    $0x40,%esi
    f28b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    f290:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    f295:	48 29 c6             	sub    %rax,%rsi
    f298:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    f29d:	48 09 c8             	or     %rcx,%rax
    f2a0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    f2a5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    f2aa:	49 89 c6             	mov    %rax,%r14
    f2ad:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    f2b1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    f2b6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    f2bb:	49 09 c1             	or     %rax,%r9
    f2be:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    f2c2:	4c 89 c8             	mov    %r9,%rax
    f2c5:	49 f7 f6             	div    %r14
    f2c8:	48 89 d1             	mov    %rdx,%rcx
    f2cb:	49 89 c3             	mov    %rax,%r11
    f2ce:	49 89 c1             	mov    %rax,%r9
    f2d1:	49 f7 e2             	mul    %r10
    f2d4:	49 89 c6             	mov    %rax,%r14
    f2d7:	49 89 d2             	mov    %rdx,%r10
    f2da:	48 39 d1             	cmp    %rdx,%rcx
    f2dd:	72 07                	jb     f2e6 <__divmodti4+0x126>
    f2df:	75 17                	jne    f2f8 <__divmodti4+0x138>
    f2e1:	49 39 c7             	cmp    %rax,%r15
    f2e4:	73 12                	jae    f2f8 <__divmodti4+0x138>
    f2e6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    f2ea:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    f2ee:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    f2f2:	49 89 d2             	mov    %rdx,%r10
    f2f5:	49 89 c6             	mov    %rax,%r14
    f2f8:	4c 89 f8             	mov    %r15,%rax
    f2fb:	4c 29 f0             	sub    %r14,%rax
    f2fe:	4c 19 d1             	sbb    %r10,%rcx
    f301:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    f306:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    f30b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    f310:	48 09 c6             	or     %rax,%rsi
    f313:	48 89 cf             	mov    %rcx,%rdi
    f316:	31 c0                	xor    %eax,%eax
    f318:	4c 89 c9             	mov    %r9,%rcx
    f31b:	e9 10 ff ff ff       	jmp    f230 <__divmodti4+0x70>
    f320:	4c 89 d0             	mov    %r10,%rax
    f323:	4c 89 da             	mov    %r11,%rdx
    f326:	4d 89 c4             	mov    %r8,%r12
    f329:	49 89 f3             	mov    %rsi,%r11
    f32c:	48 f7 d8             	neg    %rax
    f32f:	49 f7 d4             	not    %r12
    f332:	48 83 d2 00          	adc    $0x0,%rdx
    f336:	49 89 c2             	mov    %rax,%r10
    f339:	48 f7 da             	neg    %rdx
    f33c:	48 89 d1             	mov    %rdx,%rcx
    f33f:	0f 84 cc fe ff ff    	je     f211 <__divmodti4+0x51>
    f345:	49 39 d1             	cmp    %rdx,%r9
    f348:	73 46                	jae    f390 <__divmodti4+0x1d0>
    f34a:	4c 89 cf             	mov    %r9,%rdi
    f34d:	31 c0                	xor    %eax,%eax
    f34f:	31 c9                	xor    %ecx,%ecx
    f351:	e9 da fe ff ff       	jmp    f230 <__divmodti4+0x70>
    f356:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    f35d:	00 00 00 
    f360:	4d 85 d2             	test   %r10,%r10
    f363:	75 0d                	jne    f372 <__divmodti4+0x1b2>
    f365:	b8 01 00 00 00       	mov    $0x1,%eax
    f36a:	31 d2                	xor    %edx,%edx
    f36c:	49 f7 f2             	div    %r10
    f36f:	49 89 c2             	mov    %rax,%r10
    f372:	4c 89 c8             	mov    %r9,%rax
    f375:	31 d2                	xor    %edx,%edx
    f377:	49 f7 f2             	div    %r10
    f37a:	49 89 c1             	mov    %rax,%r9
    f37d:	4c 89 d8             	mov    %r11,%rax
    f380:	49 f7 f2             	div    %r10
    f383:	49 89 c3             	mov    %rax,%r11
    f386:	4c 89 c8             	mov    %r9,%rax
    f389:	e9 9a fe ff ff       	jmp    f228 <__divmodti4+0x68>
    f38e:	66 90                	xchg   %ax,%ax
    f390:	45 31 f6             	xor    %r14d,%r14d
    f393:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    f398:	44 89 f7             	mov    %r14d,%edi
    f39b:	45 85 f6             	test   %r14d,%r14d
    f39e:	0f 85 df fe ff ff    	jne    f283 <__divmodti4+0xc3>
    f3a4:	4c 39 ca             	cmp    %r9,%rdx
    f3a7:	72 17                	jb     f3c0 <__divmodti4+0x200>
    f3a9:	31 c9                	xor    %ecx,%ecx
    f3ab:	48 39 c6             	cmp    %rax,%rsi
    f3ae:	73 10                	jae    f3c0 <__divmodti4+0x200>
    f3b0:	4c 89 cf             	mov    %r9,%rdi
    f3b3:	31 c0                	xor    %eax,%eax
    f3b5:	e9 76 fe ff ff       	jmp    f230 <__divmodti4+0x70>
    f3ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    f3c0:	4c 89 de             	mov    %r11,%rsi
    f3c3:	b9 01 00 00 00       	mov    $0x1,%ecx
    f3c8:	48 29 c6             	sub    %rax,%rsi
    f3cb:	49 19 d1             	sbb    %rdx,%r9
    f3ce:	eb e0                	jmp    f3b0 <__divmodti4+0x1f0>

000000000000f3d0 <atexit>:
    f3d0:	f3 0f 1e fa          	endbr64
    f3d4:	48 8b 15 2d 4c 00 00 	mov    0x4c2d(%rip),%rdx        # 14008 <__dso_handle>
    f3db:	31 f6                	xor    %esi,%esi
    f3dd:	e9 5e 42 ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000f3e4 <_fini>:
    f3e4:	f3 0f 1e fa          	endbr64
    f3e8:	48 83 ec 08          	sub    $0x8,%rsp
    f3ec:	48 83 c4 08          	add    $0x8,%rsp
    f3f0:	c3                   	ret
