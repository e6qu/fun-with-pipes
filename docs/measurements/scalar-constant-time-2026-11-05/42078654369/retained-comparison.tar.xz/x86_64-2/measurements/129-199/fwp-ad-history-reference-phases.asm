
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-reference-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 ff 00 00 	mov    0xffc1(%rip),%rax        # 12fd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da fd 00 00    	push   0xfdda(%rip)        # 12e00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc fd 00 00    	jmp    *0xfddc(%rip)        # 12e08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 fc 00 00    	jmp    *0xfc46(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12e60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12e68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12e70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12e78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12e80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12e88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12e90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12e98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12ea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12ea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12eb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12eb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12ec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12ec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12ed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12ed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12ee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12ee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12ef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12ef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12f60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12f68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12f70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12f78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12f80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12f88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 f8 00 00    	jmp    *0xf8e6(%rip)        # 12f90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de f8 00 00    	jmp    *0xf8de(%rip)        # 12f98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 f8 00 00    	jmp    *0xf8d6(%rip)        # 12fa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce f8 00 00    	jmp    *0xf8ce(%rip)        # 12fa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 f8 00 00    	jmp    *0xf8c6(%rip)        # 12fb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be f8 00 00    	jmp    *0xf8be(%rip)        # 12fb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd b9 00 00 	lea    0xb9dd(%rip),%r9        # f0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da b9 00 00 	lea    0xb9da(%rip),%r8        # f0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 e1 dc 00 00 	lea    0xdce1(%rip),%rax        # 11460 <fwp_fn_table>
    377f:	48 89 05 d2 1c 02 00 	mov    %rax,0x21cd2(%rip)        # 25458 <fwp_fns>
    3786:	48 8b 05 b3 f8 00 00 	mov    0xf8b3(%rip),%rax        # 13040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 cc 1c 02 00 	mov    %rax,0x21ccc(%rip)        # 25460 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d b7 ba 00 00 	lea    0xbab7(%rip),%rdi        # f257 <_IO_stdin_used+0x257>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 f8 00 00 	mov    0xf838(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 df a9 00 00 	lea    0xa9df(%rip),%rdx        # e240 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 f7 00 00 	mov    0xf7a3(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 18 f8 01 00    	mov    0x1f818(%rip),%eax        # 230c0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 67 b9 00 00 	lea    0xb967(%rip),%rdi        # f260 <_IO_stdin_used+0x260>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 7e c1 00 00 	lea    0xc17e(%rip),%rdi        # fa88 <_IO_stdin_used+0xa88>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 38 c1 00 00 	lea    0xc138(%rip),%rdi        # fa60 <_IO_stdin_used+0xa60>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d fc c0 00 00 	lea    0xc0fc(%rip),%rdi        # fa30 <_IO_stdin_used+0xa30>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d c8 c0 00 00 	lea    0xc0c8(%rip),%rdi        # fa08 <_IO_stdin_used+0xa08>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b f6 00 00    	call   *0xf64b(%rip)        # 12fc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 f6 00 00 	lea    0xf6a1(%rip),%rdi        # 13028 <__TMC_END__>
    3987:	48 8d 05 9a f6 00 00 	lea    0xf69a(%rip),%rax        # 13028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e f6 00 00 	mov    0xf62e(%rip),%rax        # 12fc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 f6 00 00 	lea    0xf671(%rip),%rdi        # 13028 <__TMC_END__>
    39b7:	48 8d 35 6a f6 00 00 	lea    0xf66a(%rip),%rsi        # 13028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd f5 00 00 	mov    0xf5fd(%rip),%rax        # 12fd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d f6 00 00 00 	cmpb   $0x0,0xf66d(%rip)        # 13068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da f5 00 00 	cmpq   $0x0,0xf5da(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 f6 00 00 01 	movb   $0x1,0xf645(%rip)        # 13068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 0e f5 01 00 	add    0x1f50e(%rip),%rdx        # 23130 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 fc f4 01 00 	add    0x1f4fc(%rip),%rax        # 23130 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d e9 17 02 00 	mov    0x217e9(%rip),%rdi        # 25460 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d b4 f3 00 00 	mov    0xf3b4(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d a1 f3 00 00 	mov    0xf3a1(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 b3 00 00 	lea    0xb345(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 92 f3 00 00 	mov    0xf392(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 e1 fa 01 00 	mov    0x1fae1(%rip),%rax        # 237e0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 19 f4 01 00 	mov    0x1f419(%rip),%rax        # 23198 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 05 f4 01 00 	sub    0x1f405(%rip),%rax        # 23190 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 ad bd 00 00 	lea    0xbdad(%rip),%rsi        # fb70 <msg.8>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 7f b8 00 00 	lea    0xb87f(%rip),%rdi        # f668 <_IO_stdin_used+0x668>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 62 f2 00 00 	mov    0xf262(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d ed f1 00 00 ff 	cmpl   $0xffffffff,0xf1ed(%rip)        # 13020 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 b1 00 00 	lea    0xb1e2(%rip),%rax        # f022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d 01 f3 01 00 	mov    0x1f301(%rip),%r9        # 23148 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f ed 00 	movq   0xed9f(%rip),%xmm0        # 12bf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 b1 00 00 	lea    0xb1e7(%rip),%rax        # f044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 dc f2 01 00 	mov    0x1f2dc(%rip),%r8        # 23140 <descent_inputs>
    3e64:	48 8b 0d e5 f2 01 00 	mov    0x1f2e5(%rip),%rcx        # 23150 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d e2 f1 00 00 	mov    0xf1e2(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 b1 00 00 	lea    0xb1d8(%rip),%rax        # f061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 ed 00 	movq   0xed67(%rip),%xmm0        # 12bf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 18 b8 00 00 	lea    0xb818(%rip),%rdx        # f6b0 <_IO_stdin_used+0x6b0>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 b1 f2 01 00 	lea    0x1f2b1(%rip),%r12        # 23160 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 ed 00 	movq   0xed44(%rip),%xmm0        # 12c00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 7b f1 00 00 	mov    0xf17b(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 b1 00 00 	lea    0xb175(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 b1 00 00 	lea    0xb170(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 40 f1 00 00 	mov    0xf140(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 b1 00 00 	lea    0xb144(%rip),%rdi        # f07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d 19 f1 00 00 	mov    0xf119(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 b1 00 00 	lea    0xb143(%rip),%rcx        # f091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 b1 00 00 	lea    0xb119(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 5b 0c 02 00 	mov    0x20c5b(%rip),%rax        # 24bf0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 54 0c 02 00 	lea    0x20c54(%rip),%r8        # 24bf0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d 35 0c 02 00 	mov    0x20c35(%rip),%rbx        # 24bd8 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 45 0c 02 00 	mov    0x20c45(%rip),%rcx        # 24bf8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d e1 0b 02 00 	mov    0x20be1(%rip),%rdi        # 24be0 <fwp_heap+0x13e0>
    3fff:	48 29 35 2a 0c 02 00 	sub    %rsi,0x20c2a(%rip)        # 24c30 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 ba 0b 02 00 	mov    0x20bba(%rip),%rax        # 24bd0 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 70 0b 02 00 	add    0x20b70(%rip),%rdi        # 24bb0 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 7e 0b 02 00 	mov    0x20b7e(%rip),%rsi        # 24be0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 8c 0b 02 00 	mov    0x20b8c(%rip),%rax        # 24bf8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 3b 0b 02 00 	mov    %r12,0x20b3b(%rip)        # 24be0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d 29 0b 02 00 	mov    %rbp,0x20b29(%rip)        # 24bd8 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d 0e 0b 02 00 	cmp    %rdi,0x20b0e(%rip)        # 24bc8 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d 05 0b 02 00 	mov    %rdi,0x20b05(%rip)        # 24bc8 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 49 0b 02 00 	sub    %rdi,0x20b49(%rip)        # 24c30 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 f1 0a 02 00 	mov    0x20af1(%rip),%rax        # 24be8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 ea 0a 02 00 	lea    0x20aea(%rip),%r8        # 24be8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 7d ee 00 00 	mov    0xee7d(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 ae 00 00 	lea    0xae14(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d b5 ed 00 00 	movslq 0xedb5(%rip),%rbp        # 13020 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 ba ee 01 00 	mov    0x1eeba(%rip),%rsi        # 23158 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d b6 ee 01 00 	lea    0x1eeb6(%rip),%rcx        # 23160 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 8b ee 01 00 	addq   $0x1,0x1ee8b(%rip)        # 23150 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 50 ed 00 00    	mov    %ebx,0xed50(%rip)        # 13020 <descent_active_phase>
    42d0:	48 89 05 81 ee 01 00 	mov    %rax,0x1ee81(%rip)        # 23158 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d d9 f4 01 00 	cmp    0x1f4d9(%rip),%rdi        # 237e0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 9f f4 01 00 	mov    0x1f49f(%rip),%rax        # 237c0 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 7d f4 01 00 	mov    %rdi,0x1f47d(%rip)        # 237c0 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 59 f4 01 00 	mov    %rdi,0x1f459(%rip)        # 237c8 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 18 ae 00 00 	lea    0xae18(%rip),%rsi        # f1c9 <_IO_stdin_used+0x1c9>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba ac 00 00 	lea    0xacba(%rip),%rsi        # f07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 48 ec 00 00 	mov    0xec48(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 ac 00 00 	lea    0xac64(%rip),%rdx        # f083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 30 ec 00 00 	mov    0xec30(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 41 eb 00 00 	mov    0xeb41(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 aa 00 00 	lea    0xaad8(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 ab 00 00 	lea    0xab45(%rip),%rdi        # f092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd aa 00 00 	lea    0xaacd(%rip),%rdi        # f0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d 10 b1 00 00 	lea    0xb110(%rip),%rdi        # f700 <_IO_stdin_used+0x700>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 80 b5 00 	movdqa 0xb580(%rip),%xmm0        # fb90 <msg.8+0x20>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 ea 0d 02 00 	add    0x20dea(%rip),%rax        # 25458 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 64 b0 00 00 	lea    0xb064(%rip),%rdi        # f728 <_IO_stdin_used+0x728>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 45 ea 01 00 	cmp    %rax,0x1ea45(%rip)        # 23128 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 40 ea 01 00 	add    0x1ea40(%rip),%rax        # 23130 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 4d b0 00 00 	lea    0xb04d(%rip),%rdi        # f758 <_IO_stdin_used+0x758>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 a9 00 00 	lea    0xa9a5(%rip),%r8        # f0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa a7 00 00 	lea    0xa7fa(%rip),%r8        # f0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 a6 00 00 	lea    0xa697(%rip),%r8        # f0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f a4 00 00 	lea    0xa46f(%rip),%rdi        # f0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 7e a5 00 00 	lea    0xa57e(%rip),%rsi        # f20c <_IO_stdin_used+0x20c>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d c5 fe 01 00 	mov    0x1fec5(%rip),%r9        # 24bc8 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 1e ff 01 00 	mov    0x1ff1e(%rip),%r8        # 24c28 <fwp_heap+0x1428>
    4d0a:	48 8d 15 97 aa 00 00 	lea    0xaa97(%rip),%rdx        # f7a8 <_IO_stdin_used+0x7a8>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d 06 ff 01 00 	mov    0x1ff06(%rip),%rcx        # 24c20 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d 14 ff 01 	movsd  0x1ff14(%rip),%xmm1        # 24c40 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 04 ff 01 	movsd  0x1ff04(%rip),%xmm0        # 24c38 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 25 e3 00 00 	mov    0xe325(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 28 ae 00 	movdqa 0xae28(%rip),%xmm0        # fba0 <msg.8+0x30>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 bf f9 01 00 	lea    0x1f9bf(%rip),%rax        # 24740 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 51 ae 00 	movdqa 0xae51(%rip),%xmm2        # fbe0 <msg.8+0x70>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 65 f9 01 00 	movaps %xmm0,0x1f965(%rip)        # 24700 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 0d ae 00 	movdqa 0xae0d(%rip),%xmm0        # fbb0 <msg.8+0x40>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 f3 fd 01 00 01 	movl   $0x1,0x1fdf3(%rip)        # 24ba4 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 53 f9 01 00 	movaps %xmm0,0x1f953(%rip)        # 24710 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 fb ad 00 	movdqa 0xadfb(%rip),%xmm0        # fbc0 <msg.8+0x50>
    4dc4:	00 
    4dc5:	0f 29 05 54 f9 01 00 	movaps %xmm0,0x1f954(%rip)        # 24720 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 fc ad 00 	movdqa 0xadfc(%rip),%xmm0        # fbd0 <msg.8+0x60>
    4dd3:	00 
    4dd4:	0f 29 05 55 f9 01 00 	movaps %xmm0,0x1f955(%rip)        # 24730 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 d5 e9 01 00 	lea    0x1e9d5(%rip),%r8        # 23800 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 f0 fc 01 00 	mov    %rax,0x1fcf0(%rip)        # 24bb8 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 ce fc 01 00 	mov    %r12,0x1fcce(%rip)        # 24bc0 <fwp_heap+0x13c0>
    4ef2:	48 89 05 b7 fc 01 00 	mov    %rax,0x1fcb7(%rip)        # 24bb0 <fwp_heap+0x13b0>
    4ef9:	48 89 1d d0 fc 01 00 	mov    %rbx,0x1fcd0(%rip)        # 24bd0 <fwp_heap+0x13d0>
    4f00:	48 89 35 f9 fc 01 00 	mov    %rsi,0x1fcf9(%rip)        # 24c00 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 a1 00 00 	lea    0xa1f9(%rip),%rdi        # f112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 d8 fc 01 00 	mov    %rax,0x1fcd8(%rip)        # 24bf8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 5c fc 01 00    	mov    %eax,0x1fc5c(%rip)        # 24ba8 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <caf61>:
    4f60:	8b 15 3a e1 00 00    	mov    0xe13a(%rip),%edx        # 130a0 <st.4>
    4f66:	85 d2                	test   %edx,%edx
    4f68:	74 0e                	je     4f78 <caf61+0x18>
    4f6a:	48 8b 05 27 e1 00 00 	mov    0xe127(%rip),%rax        # 13098 <v.3>
    4f71:	c3                   	ret
    4f72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f78:	8b 05 12 e1 00 00    	mov    0xe112(%rip),%eax        # 13090 <st.2>
    4f7e:	85 c0                	test   %eax,%eax
    4f80:	74 1e                	je     4fa0 <caf61+0x40>
    4f82:	48 8b 05 ff e0 00 00 	mov    0xe0ff(%rip),%rax        # 13088 <v.1>
    4f89:	48 89 05 08 e1 00 00 	mov    %rax,0xe108(%rip)        # 13098 <v.3>
    4f90:	c7 05 06 e1 00 00 01 	movl   $0x1,0xe106(%rip)        # 130a0 <st.4>
    4f97:	00 00 00 
    4f9a:	c3                   	ret
    4f9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4fa0:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    4fa7:	00 f0 3f 
    4faa:	c7 05 dc e0 00 00 01 	movl   $0x1,0xe0dc(%rip)        # 13090 <st.2>
    4fb1:	00 00 00 
    4fb4:	48 89 05 cd e0 00 00 	mov    %rax,0xe0cd(%rip)        # 13088 <v.1>
    4fbb:	eb cc                	jmp    4f89 <caf61+0x29>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 ec e7 01 00 	mov    0x1e7ec(%rip),%r8        # 237c0 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d 1c e7 01 00 	mov    %rbx,0x1e71c(%rip)        # 237c8 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 08 e7 01 00 	mov    %r8,0x1e708(%rip)        # 237c0 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <fwp_tape_buffers_release>:
    50d0:	f3 0f 1e fa          	endbr64
    50d4:	53                   	push   %rbx
    50d5:	48 89 fb             	mov    %rdi,%rbx
    50d8:	48 83 ec 10          	sub    $0x10,%rsp
    50dc:	48 8b 47 28          	mov    0x28(%rdi),%rax
    50e0:	48 85 c0             	test   %rax,%rax
    50e3:	0f 88 df 00 00 00    	js     51c8 <fwp_tape_buffers_release+0xf8>
    50e9:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    50ed:	48 85 d2             	test   %rdx,%rdx
    50f0:	0f 88 d2 00 00 00    	js     51c8 <fwp_tape_buffers_release+0xf8>
    50f6:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    50fc:	0f 87 c6 00 00 00    	ja     51c8 <fwp_tape_buffers_release+0xf8>
    5102:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5106:	b8 00 00 08 00       	mov    $0x80000,%eax
    510b:	48 c1 e1 03          	shl    $0x3,%rcx
    510f:	48 29 c8             	sub    %rcx,%rax
    5112:	48 c1 e8 03          	shr    $0x3,%rax
    5116:	48 39 d0             	cmp    %rdx,%rax
    5119:	0f 82 a9 00 00 00    	jb     51c8 <fwp_tape_buffers_release+0xf8>
    511f:	48 8d 3d fc 9f 00 00 	lea    0x9ffc(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    5126:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    512b:	48 89 14 24          	mov    %rdx,(%rsp)
    512f:	e8 6c e2 ff ff       	call   33a0 <getenv@plt>
    5134:	48 8b 14 24          	mov    (%rsp),%rdx
    5138:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    513d:	48 85 c0             	test   %rax,%rax
    5140:	74 09                	je     514b <fwp_tape_buffers_release+0x7b>
    5142:	80 38 30             	cmpb   $0x30,(%rax)
    5145:	0f 84 9d 00 00 00    	je     51e8 <fwp_tape_buffers_release+0x118>
    514b:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    514f:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    5153:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    515a:	77 78                	ja     51d4 <fwp_tape_buffers_release+0x104>
    515c:	48 8d 3d 7d df 01 00 	lea    0x1df7d(%rip),%rdi        # 230e0 <fwp_tape_workspace>
    5163:	48 89 04 24          	mov    %rax,(%rsp)
    5167:	e8 a4 ef ff ff       	call   4110 <fwp_tape_buffers_dispose>
    516c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5170:	48 8b 04 24          	mov    (%rsp),%rax
    5174:	0f 29 05 65 df 01 00 	movaps %xmm0,0x1df65(%rip)        # 230e0 <fwp_tape_workspace>
    517b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5180:	48 89 05 41 df 01 00 	mov    %rax,0x1df41(%rip)        # 230c8 <fwp_tape_cached_bytes>
    5187:	0f 29 05 62 df 01 00 	movaps %xmm0,0x1df62(%rip)        # 230f0 <fwp_tape_workspace+0x10>
    518e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5193:	0f 29 05 66 df 01 00 	movaps %xmm0,0x1df66(%rip)        # 23100 <fwp_tape_workspace+0x20>
    519a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    519e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    51a2:	48 89 15 67 df 01 00 	mov    %rdx,0x1df67(%rip)        # 23110 <fwp_tape_workspace+0x30>
    51a9:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    51b0:	00 
    51b1:	0f 11 03             	movups %xmm0,(%rbx)
    51b4:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    51b8:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    51bc:	48 83 c4 10          	add    $0x10,%rsp
    51c0:	5b                   	pop    %rbx
    51c1:	c3                   	ret
    51c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    51c8:	48 8d 3d 53 9f 00 00 	lea    0x9f53(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    51cf:	e8 cc e1 ff ff       	call   33a0 <getenv@plt>
    51d4:	48 83 c4 10          	add    $0x10,%rsp
    51d8:	48 89 df             	mov    %rbx,%rdi
    51db:	5b                   	pop    %rbx
    51dc:	e9 2f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    51e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e8:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    51ec:	0f 85 59 ff ff ff    	jne    514b <fwp_tape_buffers_release+0x7b>
    51f2:	48 83 c4 10          	add    $0x10,%rsp
    51f6:	48 89 df             	mov    %rbx,%rdi
    51f9:	5b                   	pop    %rbx
    51fa:	e9 11 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    51ff:	90                   	nop

0000000000005200 <fwp_poll_events>:
    5200:	53                   	push   %rbx
    5201:	48 83 ec 20          	sub    $0x20,%rsp
    5205:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    520c:	00 00 
    520e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5213:	31 c0                	xor    %eax,%eax
    5215:	e8 46 f3 ff ff       	call   4560 <fwp_now_ns>
    521a:	48 8b 1d 97 e5 01 00 	mov    0x1e597(%rip),%rbx        # 237b8 <fwp_timers>
    5221:	48 85 db             	test   %rbx,%rbx
    5224:	0f 84 d6 00 00 00    	je     5300 <fwp_poll_events+0x100>
    522a:	48 89 c6             	mov    %rax,%rsi
    522d:	48 89 da             	mov    %rbx,%rdx
    5230:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5237:	eb 16                	jmp    524f <fwp_poll_events+0x4f>
    5239:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5240:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5247:	48 89 c8             	mov    %rcx,%rax
    524a:	48 85 d2             	test   %rdx,%rdx
    524d:	74 31                	je     5280 <fwp_poll_events+0x80>
    524f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5253:	48 85 c0             	test   %rax,%rax
    5256:	78 e8                	js     5240 <fwp_poll_events+0x40>
    5258:	48 39 c1             	cmp    %rax,%rcx
    525b:	7c e3                	jl     5240 <fwp_poll_events+0x40>
    525d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5264:	48 85 d2             	test   %rdx,%rdx
    5267:	74 1c                	je     5285 <fwp_poll_events+0x85>
    5269:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    526d:	48 39 c1             	cmp    %rax,%rcx
    5270:	7c ce                	jl     5240 <fwp_poll_events+0x40>
    5272:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5279:	48 85 d2             	test   %rdx,%rdx
    527c:	75 d1                	jne    524f <fwp_poll_events+0x4f>
    527e:	66 90                	xchg   %ax,%ax
    5280:	48 85 c0             	test   %rax,%rax
    5283:	78 7b                	js     5300 <fwp_poll_events+0x100>
    5285:	48 29 f0             	sub    %rsi,%rax
    5288:	48 89 c1             	mov    %rax,%rcx
    528b:	48 85 c0             	test   %rax,%rax
    528e:	0f 8e 9c 00 00 00    	jle    5330 <fwp_poll_events+0x130>
    5294:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    529b:	de 1b 43 
    529e:	48 f7 ea             	imul   %rdx
    52a1:	48 89 c8             	mov    %rcx,%rax
    52a4:	48 c1 f8 3f          	sar    $0x3f,%rax
    52a8:	48 c1 fa 12          	sar    $0x12,%rdx
    52ac:	48 29 c2             	sub    %rax,%rdx
    52af:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    52b6:	48 39 c1             	cmp    %rax,%rcx
    52b9:	0f 95 c0             	setne  %al
    52bc:	0f b6 c0             	movzbl %al,%eax
    52bf:	48 01 d0             	add    %rdx,%rax
    52c2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    52c8:	0f 8f 32 01 00 00    	jg     5400 <fwp_poll_events+0x200>
    52ce:	48 85 c0             	test   %rax,%rax
    52d1:	74 5d                	je     5330 <fwp_poll_events+0x130>
    52d3:	89 c1                	mov    %eax,%ecx
    52d5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    52dc:	48 c1 e9 26          	shr    $0x26,%rcx
    52e0:	48 63 d1             	movslq %ecx,%rdx
    52e3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    52e9:	29 c8                	sub    %ecx,%eax
    52eb:	48 98                	cltq
    52ed:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    52f4:	e9 11 01 00 00       	jmp    540a <fwp_poll_events+0x20a>
    52f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5300:	e8 6b e9 ff ff       	call   3c70 <fwp_flush>
    5305:	ba 2b 00 00 00       	mov    $0x2b,%edx
    530a:	be 01 00 00 00       	mov    $0x1,%esi
    530f:	48 8b 0d 4a dd 00 00 	mov    0xdd4a(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    5316:	48 8d 3d 13 a5 00 00 	lea    0xa513(%rip),%rdi        # f830 <_IO_stdin_used+0x830>
    531d:	e8 5e e3 ff ff       	call   3680 <fwrite@plt>
    5322:	bf 65 00 00 00       	mov    $0x65,%edi
    5327:	e8 44 e3 ff ff       	call   3670 <exit@plt>
    532c:	0f 1f 40 00          	nopl   0x0(%rax)
    5330:	e8 2b f2 ff ff       	call   4560 <fwp_now_ns>
    5335:	48 89 c1             	mov    %rax,%rcx
    5338:	66 0f ef c0          	pxor   %xmm0,%xmm0
    533c:	eb 44                	jmp    5382 <fwp_poll_events+0x182>
    533e:	66 90                	xchg   %ax,%ax
    5340:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5344:	75 33                	jne    5379 <fwp_poll_events+0x179>
    5346:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    534a:	75 2d                	jne    5379 <fwp_poll_events+0x179>
    534c:	48 8b 05 6d e4 01 00 	mov    0x1e46d(%rip),%rax        # 237c0 <fwp_ready_tail>
    5353:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5357:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    535e:	00 00 00 00 
    5362:	48 85 c0             	test   %rax,%rax
    5365:	0f 84 05 01 00 00    	je     5470 <fwp_poll_events+0x270>
    536b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5372:	48 89 15 47 e4 01 00 	mov    %rdx,0x1e447(%rip)        # 237c0 <fwp_ready_tail>
    5379:	48 85 db             	test   %rbx,%rbx
    537c:	0f 84 be 00 00 00    	je     5440 <fwp_poll_events+0x240>
    5382:	48 89 da             	mov    %rbx,%rdx
    5385:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    538c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5390:	7f e7                	jg     5379 <fwp_poll_events+0x179>
    5392:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5396:	74 2e                	je     53c6 <fwp_poll_events+0x1c6>
    5398:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    539f:	48 85 c0             	test   %rax,%rax
    53a2:	0f 84 b8 00 00 00    	je     5460 <fwp_poll_events+0x260>
    53a8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    53af:	48 85 db             	test   %rbx,%rbx
    53b2:	74 07                	je     53bb <fwp_poll_events+0x1bb>
    53b4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    53bb:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    53bf:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    53c6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    53ca:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    53ce:	48 85 c0             	test   %rax,%rax
    53d1:	0f 84 69 ff ff ff    	je     5340 <fwp_poll_events+0x140>
    53d7:	48 39 c8             	cmp    %rcx,%rax
    53da:	0f 8f 60 ff ff ff    	jg     5340 <fwp_poll_events+0x140>
    53e0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    53e4:	0f 85 56 ff ff ff    	jne    5340 <fwp_poll_events+0x140>
    53ea:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    53ee:	75 89                	jne    5379 <fwp_poll_events+0x179>
    53f0:	48 89 d7             	mov    %rdx,%rdi
    53f3:	e8 08 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    53f8:	e9 43 ff ff ff       	jmp    5340 <fwp_poll_events+0x140>
    53fd:	0f 1f 00             	nopl   (%rax)
    5400:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5405:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    540a:	48 89 e7             	mov    %rsp,%rdi
    540d:	31 f6                	xor    %esi,%esi
    540f:	48 89 14 24          	mov    %rdx,(%rsp)
    5413:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5418:	e8 83 e0 ff ff       	call   34a0 <nanosleep@plt>
    541d:	48 8b 1d 94 e3 01 00 	mov    0x1e394(%rip),%rbx        # 237b8 <fwp_timers>
    5424:	e8 37 f1 ff ff       	call   4560 <fwp_now_ns>
    5429:	48 89 c1             	mov    %rax,%rcx
    542c:	48 85 db             	test   %rbx,%rbx
    542f:	0f 85 03 ff ff ff    	jne    5338 <fwp_poll_events+0x138>
    5435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    543c:	00 00 00 00 
    5440:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5445:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    544c:	00 00 
    544e:	75 2c                	jne    547c <fwp_poll_events+0x27c>
    5450:	48 83 c4 20          	add    $0x20,%rsp
    5454:	5b                   	pop    %rbx
    5455:	c3                   	ret
    5456:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    545d:	00 00 00 
    5460:	48 89 1d 51 e3 01 00 	mov    %rbx,0x1e351(%rip)        # 237b8 <fwp_timers>
    5467:	e9 43 ff ff ff       	jmp    53af <fwp_poll_events+0x1af>
    546c:	0f 1f 40 00          	nopl   0x0(%rax)
    5470:	48 89 15 51 e3 01 00 	mov    %rdx,0x1e351(%rip)        # 237c8 <fwp_ready_head>
    5477:	e9 f6 fe ff ff       	jmp    5372 <fwp_poll_events+0x172>
    547c:	e8 df df ff ff       	call   3460 <__stack_chk_fail@plt>
    5481:	0f 1f 40 00          	nopl   0x0(%rax)
    5485:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    548c:	00 00 00 00 

0000000000005490 <fwp_rc_wide_dup>:
    5490:	48 89 fa             	mov    %rdi,%rdx
    5493:	48 8d 35 66 e3 01 00 	lea    0x1e366(%rip),%rsi        # 23800 <fwp_heap>
    549a:	48 83 ec 18          	sub    $0x18,%rsp
    549e:	48 89 f9             	mov    %rdi,%rcx
    54a1:	48 c1 ea 11          	shr    $0x11,%rdx
    54a5:	48 31 fa             	xor    %rdi,%rdx
    54a8:	48 89 d0             	mov    %rdx,%rax
    54ab:	48 c1 e8 09          	shr    $0x9,%rax
    54af:	48 31 c2             	xor    %rax,%rdx
    54b2:	0f b6 d2             	movzbl %dl,%edx
    54b5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    54bc:	00 
    54bd:	49 8b 00             	mov    (%r8),%rax
    54c0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    54c7:	00 00 
    54c9:	75 21                	jne    54ec <fwp_rc_wide_dup+0x5c>
    54cb:	e9 98 00 00 00       	jmp    5568 <fwp_rc_wide_dup+0xd8>
    54d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    54d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    54dc:	00 00 00 00 
    54e0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    54e4:	48 85 d2             	test   %rdx,%rdx
    54e7:	74 2f                	je     5518 <fwp_rc_wide_dup+0x88>
    54e9:	48 89 d0             	mov    %rdx,%rax
    54ec:	48 3b 08             	cmp    (%rax),%rcx
    54ef:	75 ef                	jne    54e0 <fwp_rc_wide_dup+0x50>
    54f1:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54f4:	74 7c                	je     5572 <fwp_rc_wide_dup+0xe2>
    54f6:	48 8b 50 08          	mov    0x8(%rax),%rdx
    54fa:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    54fe:	0f 84 91 00 00 00    	je     5595 <fwp_rc_wide_dup+0x105>
    5504:	48 83 c2 01          	add    $0x1,%rdx
    5508:	48 89 50 08          	mov    %rdx,0x8(%rax)
    550c:	48 83 c4 18          	add    $0x18,%rsp
    5510:	c3                   	ret
    5511:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5518:	4c 8d 40 10          	lea    0x10(%rax),%r8
    551c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    551f:	75 68                	jne    5589 <fwp_rc_wide_dup+0xf9>
    5521:	bf 18 00 00 00       	mov    $0x18,%edi
    5526:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    552b:	4c 89 04 24          	mov    %r8,(%rsp)
    552f:	e8 7c e0 ff ff       	call   35b0 <malloc@plt>
    5534:	4c 8b 04 24          	mov    (%rsp),%r8
    5538:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    553d:	48 85 c0             	test   %rax,%rax
    5540:	74 5f                	je     55a1 <fwp_rc_wide_dup+0x111>
    5542:	48 89 08             	mov    %rcx,(%rax)
    5545:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    554c:	00 
    554d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5554:	00 
    5555:	49 89 00             	mov    %rax,(%r8)
    5558:	c6 01 ff             	movb   $0xff,(%rcx)
    555b:	48 83 05 e5 fe 01 00 	addq   $0x1,0x1fee5(%rip)        # 25448 <fwp_heap+0x1c48>
    5562:	01 
    5563:	48 83 c4 18          	add    $0x18,%rsp
    5567:	c3                   	ret
    5568:	80 3f fe             	cmpb   $0xfe,(%rdi)
    556b:	75 13                	jne    5580 <fwp_rc_wide_dup+0xf0>
    556d:	48 85 c0             	test   %rax,%rax
    5570:	74 af                	je     5521 <fwp_rc_wide_dup+0x91>
    5572:	48 8d 3d e7 a2 00 00 	lea    0xa2e7(%rip),%rdi        # f860 <_IO_stdin_used+0x860>
    5579:	e8 72 ee ff ff       	call   43f0 <fwp_trap>
    557e:	66 90                	xchg   %ax,%ax
    5580:	48 85 c0             	test   %rax,%rax
    5583:	0f 85 6d ff ff ff    	jne    54f6 <fwp_rc_wide_dup+0x66>
    5589:	48 8d 3d f8 a2 00 00 	lea    0xa2f8(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    5590:	e8 5b ee ff ff       	call   43f0 <fwp_trap>
    5595:	48 8d 3d 97 9b 00 00 	lea    0x9b97(%rip),%rdi        # f133 <_IO_stdin_used+0x133>
    559c:	e8 4f ee ff ff       	call   43f0 <fwp_trap>
    55a1:	e8 0a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    55a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    55ad:	00 00 00 

00000000000055b0 <fwp_rc_forget_slot>:
    55b0:	80 3f ff             	cmpb   $0xff,(%rdi)
    55b3:	74 0b                	je     55c0 <fwp_rc_forget_slot+0x10>
    55b5:	c3                   	ret
    55b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    55bd:	00 00 00 
    55c0:	48 89 f8             	mov    %rdi,%rax
    55c3:	48 83 ec 08          	sub    $0x8,%rsp
    55c7:	48 89 fa             	mov    %rdi,%rdx
    55ca:	48 c1 e8 11          	shr    $0x11,%rax
    55ce:	48 31 f8             	xor    %rdi,%rax
    55d1:	48 89 c1             	mov    %rax,%rcx
    55d4:	48 c1 e9 09          	shr    $0x9,%rcx
    55d8:	48 31 c8             	xor    %rcx,%rax
    55db:	48 8d 0d 1e e2 01 00 	lea    0x1e21e(%rip),%rcx        # 23800 <fwp_heap>
    55e2:	0f b6 c0             	movzbl %al,%eax
    55e5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    55ec:	00 
    55ed:	48 85 ff             	test   %rdi,%rdi
    55f0:	74 3c                	je     562e <fwp_rc_forget_slot+0x7e>
    55f2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    55f9:	00 
    55fa:	48 8b 01             	mov    (%rcx),%rax
    55fd:	eb 11                	jmp    5610 <fwp_rc_forget_slot+0x60>
    55ff:	90                   	nop
    5600:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5604:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5608:	48 85 ff             	test   %rdi,%rdi
    560b:	74 21                	je     562e <fwp_rc_forget_slot+0x7e>
    560d:	48 89 f8             	mov    %rdi,%rax
    5610:	48 3b 10             	cmp    (%rax),%rdx
    5613:	75 eb                	jne    5600 <fwp_rc_forget_slot+0x50>
    5615:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5619:	48 89 01             	mov    %rax,(%rcx)
    561c:	e8 9f dd ff ff       	call   33c0 <free@plt>
    5621:	48 83 2d 1f fe 01 00 	subq   $0x1,0x1fe1f(%rip)        # 25448 <fwp_heap+0x1c48>
    5628:	01 
    5629:	48 83 c4 08          	add    $0x8,%rsp
    562d:	c3                   	ret
    562e:	48 8d 3d 53 a2 00 00 	lea    0xa253(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    5635:	e8 b6 ed ff ff       	call   43f0 <fwp_trap>
    563a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005640 <fwp_rc_prepare_chunk>:
    5640:	48 83 3d 00 fe 01 00 	cmpq   $0x0,0x1fe00(%rip)        # 25448 <fwp_heap+0x1c48>
    5647:	00 
    5648:	41 54                	push   %r12
    564a:	49 89 f4             	mov    %rsi,%r12
    564d:	55                   	push   %rbp
    564e:	48 89 fd             	mov    %rdi,%rbp
    5651:	53                   	push   %rbx
    5652:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5655:	0f 84 7d 00 00 00    	je     56d8 <fwp_rc_prepare_chunk+0x98>
    565b:	31 db                	xor    %ebx,%ebx
    565d:	85 c0                	test   %eax,%eax
    565f:	75 5f                	jne    56c0 <fwp_rc_prepare_chunk+0x80>
    5661:	48 85 f6             	test   %rsi,%rsi
    5664:	74 7c                	je     56e2 <fwp_rc_prepare_chunk+0xa2>
    5666:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    566a:	e8 51 dd ff ff       	call   33c0 <free@plt>
    566f:	90                   	nop
    5670:	be 01 00 00 00       	mov    $0x1,%esi
    5675:	4c 89 e7             	mov    %r12,%rdi
    5678:	e8 a3 de ff ff       	call   3520 <calloc@plt>
    567d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5681:	48 85 c0             	test   %rax,%rax
    5684:	0f 85 87 00 00 00    	jne    5711 <fwp_rc_prepare_chunk+0xd1>
    568a:	e8 21 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    568f:	90                   	nop
    5690:	e8 1b ff ff ff       	call   55b0 <fwp_rc_forget_slot>
    5695:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5698:	48 83 c3 01          	add    $0x1,%rbx
    569c:	48 39 c3             	cmp    %rax,%rbx
    569f:	73 37                	jae    56d8 <fwp_rc_prepare_chunk+0x98>
    56a1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    56a8:	00 00 
    56aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56b1:	00 00 00 00 
    56b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56bc:	00 00 00 00 
    56c0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56c4:	48 01 df             	add    %rbx,%rdi
    56c7:	80 3f ff             	cmpb   $0xff,(%rdi)
    56ca:	74 c4                	je     5690 <fwp_rc_prepare_chunk+0x50>
    56cc:	8b 45 1c             	mov    0x1c(%rbp),%eax
    56cf:	48 83 c3 01          	add    $0x1,%rbx
    56d3:	48 39 c3             	cmp    %rax,%rbx
    56d6:	72 e8                	jb     56c0 <fwp_rc_prepare_chunk+0x80>
    56d8:	49 39 c4             	cmp    %rax,%r12
    56db:	75 13                	jne    56f0 <fwp_rc_prepare_chunk+0xb0>
    56dd:	4d 85 e4             	test   %r12,%r12
    56e0:	75 46                	jne    5728 <fwp_rc_prepare_chunk+0xe8>
    56e2:	5b                   	pop    %rbx
    56e3:	5d                   	pop    %rbp
    56e4:	41 5c                	pop    %r12
    56e6:	c3                   	ret
    56e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    56ee:	00 00 
    56f0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56f4:	48 29 05 55 fd 01 00 	sub    %rax,0x1fd55(%rip)        # 25450 <fwp_heap+0x1c50>
    56fb:	e8 c0 dc ff ff       	call   33c0 <free@plt>
    5700:	4d 85 e4             	test   %r12,%r12
    5703:	0f 85 67 ff ff ff    	jne    5670 <fwp_rc_prepare_chunk+0x30>
    5709:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5710:	00 
    5711:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5715:	5b                   	pop    %rbx
    5716:	4c 01 25 33 fd 01 00 	add    %r12,0x1fd33(%rip)        # 25450 <fwp_heap+0x1c50>
    571d:	5d                   	pop    %rbp
    571e:	41 5c                	pop    %r12
    5720:	c3                   	ret
    5721:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5728:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    572c:	5b                   	pop    %rbx
    572d:	4c 89 e2             	mov    %r12,%rdx
    5730:	31 f6                	xor    %esi,%esi
    5732:	5d                   	pop    %rbp
    5733:	41 5c                	pop    %r12
    5735:	e9 86 dd ff ff       	jmp    34c0 <memset@plt>
    573a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005740 <fwp_heap_refill>:
    5740:	41 56                	push   %r14
    5742:	41 89 d6             	mov    %edx,%r14d
    5745:	41 55                	push   %r13
    5747:	41 89 f5             	mov    %esi,%r13d
    574a:	41 54                	push   %r12
    574c:	49 89 fc             	mov    %rdi,%r12
    574f:	bf 01 00 00 00       	mov    $0x1,%edi
    5754:	55                   	push   %rbp
    5755:	53                   	push   %rbx
    5756:	e8 25 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    575b:	48 89 c3             	mov    %rax,%rbx
    575e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5762:	48 8b 05 8f f4 01 00 	mov    0x1f48f(%rip),%rax        # 24bf8 <fwp_heap+0x13f8>
    5769:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    576d:	48 8d 05 8c e0 01 00 	lea    0x1e08c(%rip),%rax        # 23800 <fwp_heap>
    5774:	31 d2                	xor    %edx,%edx
    5776:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    577a:	48 89 ef             	mov    %rbp,%rdi
    577d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5781:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5785:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    578c:	00 
    578d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5792:	f7 f1                	div    %ecx
    5794:	31 d2                	xor    %edx,%edx
    5796:	66 0f 6e c1          	movd   %ecx,%xmm0
    579a:	66 0f 6e c8          	movd   %eax,%xmm1
    579e:	89 c6                	mov    %eax,%esi
    57a0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    57a5:	48 01 c8             	add    %rcx,%rax
    57a8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    57ac:	48 f7 f1             	div    %rcx
    57af:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    57b4:	89 45 18             	mov    %eax,0x18(%rbp)
    57b7:	e8 84 fe ff ff       	call   5640 <fwp_rc_prepare_chunk>
    57bc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    57bf:	48 89 d8             	mov    %rbx,%rax
    57c2:	48 c1 e0 10          	shl    $0x10,%rax
    57c6:	48 03 05 e3 f3 01 00 	add    0x1f3e3(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    57cd:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    57d1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    57d6:	8b 55 08             	mov    0x8(%rbp),%edx
    57d9:	48 0f af d1          	imul   %rcx,%rdx
    57dd:	48 01 c2             	add    %rax,%rdx
    57e0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    57e5:	5b                   	pop    %rbx
    57e6:	5d                   	pop    %rbp
    57e7:	41 5c                	pop    %r12
    57e9:	41 5d                	pop    %r13
    57eb:	41 5e                	pop    %r14
    57ed:	c3                   	ret
    57ee:	66 90                	xchg   %ax,%ax

00000000000057f0 <fwp_mem_free>:
    57f0:	48 85 ff             	test   %rdi,%rdi
    57f3:	0f 84 17 02 00 00    	je     5a10 <fwp_mem_free+0x220>
    57f9:	48 8b 35 b0 f3 01 00 	mov    0x1f3b0(%rip),%rsi        # 24bb0 <fwp_heap+0x13b0>
    5800:	48 8b 05 d1 f3 01 00 	mov    0x1f3d1(%rip),%rax        # 24bd8 <fwp_heap+0x13d8>
    5807:	48 89 fa             	mov    %rdi,%rdx
    580a:	48 29 f2             	sub    %rsi,%rdx
    580d:	48 c1 e0 10          	shl    $0x10,%rax
    5811:	48 39 c2             	cmp    %rax,%rdx
    5814:	0f 83 f6 01 00 00    	jae    5a10 <fwp_mem_free+0x220>
    581a:	49 89 d1             	mov    %rdx,%r9
    581d:	49 c1 e9 10          	shr    $0x10,%r9
    5821:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5825:	48 c1 e0 03          	shl    $0x3,%rax
    5829:	49 89 c0             	mov    %rax,%r8
    582c:	4c 03 05 c5 f3 01 00 	add    0x1f3c5(%rip),%r8        # 24bf8 <fwp_heap+0x13f8>
    5833:	0f 84 d7 01 00 00    	je     5a10 <fwp_mem_free+0x220>
    5839:	48 83 ec 38          	sub    $0x38,%rsp
    583d:	48 89 f9             	mov    %rdi,%rcx
    5840:	41 0f b6 38          	movzbl (%r8),%edi
    5844:	40 80 ff 01          	cmp    $0x1,%dil
    5848:	74 16                	je     5860 <fwp_mem_free+0x70>
    584a:	40 80 ff 02          	cmp    $0x2,%dil
    584e:	0f 84 94 00 00 00    	je     58e8 <fwp_mem_free+0xf8>
    5854:	48 83 c4 38          	add    $0x38,%rsp
    5858:	c3                   	ret
    5859:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5860:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5864:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5869:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    586e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5872:	4d 85 d2             	test   %r10,%r10
    5875:	74 1d                	je     5894 <fwp_mem_free+0xa4>
    5877:	0f b7 c1             	movzwl %cx,%eax
    587a:	31 d2                	xor    %edx,%edx
    587c:	48 f7 f7             	div    %rdi
    587f:	49 01 c2             	add    %rax,%r10
    5882:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5886:	0f 84 44 01 00 00    	je     59d0 <fwp_mem_free+0x1e0>
    588c:	41 c6 02 00          	movb   $0x0,(%r10)
    5890:	41 8b 78 04          	mov    0x4(%r8),%edi
    5894:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    589b:	49 63 c1             	movslq %r9d,%rax
    589e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    58a6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    58ab:	f2 0f 58 05 8d f3 01 	addsd  0x1f38d(%rip),%xmm0        # 24c40 <fwp_heap+0x1440>
    58b2:	00 
    58b3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    58b7:	48 8d 05 42 df 01 00 	lea    0x1df42(%rip),%rax        # 23800 <fwp_heap>
    58be:	48 01 d0             	add    %rdx,%rax
    58c1:	48 8b 10             	mov    (%rax),%rdx
    58c4:	48 f7 d2             	not    %rdx
    58c7:	48 89 11             	mov    %rdx,(%rcx)
    58ca:	48 89 08             	mov    %rcx,(%rax)
    58cd:	48 29 3d 4c f3 01 00 	sub    %rdi,0x1f34c(%rip)        # 24c20 <fwp_heap+0x1420>
    58d4:	f2 0f 11 05 64 f3 01 	movsd  %xmm0,0x1f364(%rip)        # 24c40 <fwp_heap+0x1440>
    58db:	00 
    58dc:	48 83 c4 38          	add    $0x38,%rsp
    58e0:	c3                   	ret
    58e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    58e8:	66 31 d2             	xor    %dx,%dx
    58eb:	48 01 d6             	add    %rdx,%rsi
    58ee:	48 39 f1             	cmp    %rsi,%rcx
    58f1:	0f 85 5d ff ff ff    	jne    5854 <fwp_mem_free+0x64>
    58f7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    58fb:	48 29 15 1e f3 01 00 	sub    %rdx,0x1f31e(%rip)        # 24c20 <fwp_heap+0x1420>
    5902:	48 85 d2             	test   %rdx,%rdx
    5905:	0f 88 a5 00 00 00    	js     59b0 <fwp_mem_free+0x1c0>
    590b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    590f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5914:	f2 0f 58 05 24 f3 01 	addsd  0x1f324(%rip),%xmm0        # 24c40 <fwp_heap+0x1440>
    591b:	00 
    591c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5920:	f2 0f 11 05 18 f3 01 	movsd  %xmm0,0x1f318(%rip)        # 24c40 <fwp_heap+0x1440>
    5927:	00 
    5928:	48 85 d2             	test   %rdx,%rdx
    592b:	74 0c                	je     5939 <fwp_mem_free+0x149>
    592d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5930:	0f 84 db 00 00 00    	je     5a11 <fwp_mem_free+0x221>
    5936:	c6 02 00             	movb   $0x0,(%rdx)
    5939:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    593d:	48 85 c9             	test   %rcx,%rcx
    5940:	74 3e                	je     5980 <fwp_mem_free+0x190>
    5942:	48 8b 15 af f2 01 00 	mov    0x1f2af(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    5949:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    594d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5951:	48 01 d0             	add    %rdx,%rax
    5954:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5958:	48 89 d6             	mov    %rdx,%rsi
    595b:	48 29 c6             	sub    %rax,%rsi
    595e:	83 e6 08             	and    $0x8,%esi
    5961:	74 0d                	je     5970 <fwp_mem_free+0x180>
    5963:	c6 00 00             	movb   $0x0,(%rax)
    5966:	48 83 c0 28          	add    $0x28,%rax
    596a:	48 39 c2             	cmp    %rax,%rdx
    596d:	74 11                	je     5980 <fwp_mem_free+0x190>
    596f:	90                   	nop
    5970:	c6 00 00             	movb   $0x0,(%rax)
    5973:	48 83 c0 50          	add    $0x50,%rax
    5977:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    597b:	48 39 c2             	cmp    %rax,%rdx
    597e:	75 f0                	jne    5970 <fwp_mem_free+0x180>
    5980:	48 01 0d a9 f2 01 00 	add    %rcx,0x1f2a9(%rip)        # 24c30 <fwp_heap+0x1430>
    5987:	4c 3b 0d 62 f2 01 00 	cmp    0x1f262(%rip),%r9        # 24bf0 <fwp_heap+0x13f0>
    598e:	73 07                	jae    5997 <fwp_mem_free+0x1a7>
    5990:	4c 89 0d 59 f2 01 00 	mov    %r9,0x1f259(%rip)        # 24bf0 <fwp_heap+0x13f0>
    5997:	4c 3b 0d 4a f2 01 00 	cmp    0x1f24a(%rip),%r9        # 24be8 <fwp_heap+0x13e8>
    599e:	0f 83 b0 fe ff ff    	jae    5854 <fwp_mem_free+0x64>
    59a4:	4c 89 0d 3d f2 01 00 	mov    %r9,0x1f23d(%rip)        # 24be8 <fwp_heap+0x13e8>
    59ab:	e9 a4 fe ff ff       	jmp    5854 <fwp_mem_free+0x64>
    59b0:	48 89 d1             	mov    %rdx,%rcx
    59b3:	83 e2 01             	and    $0x1,%edx
    59b6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    59ba:	48 d1 e9             	shr    $1,%rcx
    59bd:	48 09 d1             	or     %rdx,%rcx
    59c0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    59c5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    59c9:	e9 46 ff ff ff       	jmp    5914 <fwp_mem_free+0x124>
    59ce:	66 90                	xchg   %ax,%ax
    59d0:	4c 89 d7             	mov    %r10,%rdi
    59d3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    59d8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    59dd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    59e2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    59e6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    59eb:	e8 c0 fb ff ff       	call   55b0 <fwp_rc_forget_slot>
    59f0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    59f5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    59fa:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    59ff:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5a04:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5a09:	e9 7e fe ff ff       	jmp    588c <fwp_mem_free+0x9c>
    5a0e:	66 90                	xchg   %ax,%ax
    5a10:	c3                   	ret
    5a11:	48 89 d7             	mov    %rdx,%rdi
    5a14:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5a19:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5a1e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5a23:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5a28:	e8 83 fb ff ff       	call   55b0 <fwp_rc_forget_slot>
    5a2d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5a32:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5a37:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5a3c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5a41:	e9 f0 fe ff ff       	jmp    5936 <fwp_mem_free+0x146>
    5a46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5a4d:	00 00 00 

0000000000005a50 <fwp_heap_alloc_big>:
    5a50:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5a57:	00 00 40 
    5a5a:	41 57                	push   %r15
    5a5c:	41 56                	push   %r14
    5a5e:	41 55                	push   %r13
    5a60:	41 54                	push   %r12
    5a62:	55                   	push   %rbp
    5a63:	53                   	push   %rbx
    5a64:	48 83 ec 08          	sub    $0x8,%rsp
    5a68:	48 39 f8             	cmp    %rdi,%rax
    5a6b:	0f 82 fa 00 00 00    	jb     5b6b <fwp_heap_alloc_big+0x11b>
    5a71:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a78:	49 89 fd             	mov    %rdi,%r13
    5a7b:	41 89 f6             	mov    %esi,%r14d
    5a7e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a82:	48 89 ef             	mov    %rbp,%rdi
    5a85:	e8 f6 e4 ff ff       	call   3f80 <fwp_heap_chunks>
    5a8a:	be 01 00 00 00       	mov    $0x1,%esi
    5a8f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a93:	49 89 c4             	mov    %rax,%r12
    5a96:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a9d:	00 
    5a9e:	48 03 3d 53 f1 01 00 	add    0x1f153(%rip),%rdi        # 24bf8 <fwp_heap+0x13f8>
    5aa5:	c6 07 02             	movb   $0x2,(%rdi)
    5aa8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5aac:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5aaf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5ab3:	e8 88 fb ff ff       	call   5640 <fwp_rc_prepare_chunk>
    5ab8:	48 83 fd 01          	cmp    $0x1,%rbp
    5abc:	76 47                	jbe    5b05 <fwp_heap_alloc_big+0xb5>
    5abe:	4c 01 e5             	add    %r12,%rbp
    5ac1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ac8:	00 
    5ac9:	4c 8d 3d 30 dd 01 00 	lea    0x1dd30(%rip),%r15        # 23800 <fwp_heap>
    5ad0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5ad5:	49 c1 e6 03          	shl    $0x3,%r14
    5ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ae0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5ae7:	31 f6                	xor    %esi,%esi
    5ae9:	48 01 dd             	add    %rbx,%rbp
    5aec:	48 83 c3 28          	add    $0x28,%rbx
    5af0:	48 89 ef             	mov    %rbp,%rdi
    5af3:	e8 48 fb ff ff       	call   5640 <fwp_rc_prepare_chunk>
    5af8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5afc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5b00:	49 39 de             	cmp    %rbx,%r14
    5b03:	75 db                	jne    5ae0 <fwp_heap_alloc_big+0x90>
    5b05:	49 c1 e4 10          	shl    $0x10,%r12
    5b09:	4c 03 25 a0 f0 01 00 	add    0x1f0a0(%rip),%r12        # 24bb0 <fwp_heap+0x13b0>
    5b10:	4c 89 ea             	mov    %r13,%rdx
    5b13:	31 f6                	xor    %esi,%esi
    5b15:	4c 89 e7             	mov    %r12,%rdi
    5b18:	e8 a3 d9 ff ff       	call   34c0 <memset@plt>
    5b1d:	4c 89 e8             	mov    %r13,%rax
    5b20:	48 03 05 f9 f0 01 00 	add    0x1f0f9(%rip),%rax        # 24c20 <fwp_heap+0x1420>
    5b27:	72 42                	jb     5b6b <fwp_heap_alloc_big+0x11b>
    5b29:	48 39 05 f8 f0 01 00 	cmp    %rax,0x1f0f8(%rip)        # 24c28 <fwp_heap+0x1428>
    5b30:	48 89 05 e9 f0 01 00 	mov    %rax,0x1f0e9(%rip)        # 24c20 <fwp_heap+0x1420>
    5b37:	73 07                	jae    5b40 <fwp_heap_alloc_big+0xf0>
    5b39:	48 89 05 e8 f0 01 00 	mov    %rax,0x1f0e8(%rip)        # 24c28 <fwp_heap+0x1428>
    5b40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b44:	4c 89 e0             	mov    %r12,%rax
    5b47:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5b4c:	f2 0f 58 05 e4 f0 01 	addsd  0x1f0e4(%rip),%xmm0        # 24c38 <fwp_heap+0x1438>
    5b53:	00 
    5b54:	f2 0f 11 05 dc f0 01 	movsd  %xmm0,0x1f0dc(%rip)        # 24c38 <fwp_heap+0x1438>
    5b5b:	00 
    5b5c:	48 83 c4 08          	add    $0x8,%rsp
    5b60:	5b                   	pop    %rbx
    5b61:	5d                   	pop    %rbp
    5b62:	41 5c                	pop    %r12
    5b64:	41 5d                	pop    %r13
    5b66:	41 5e                	pop    %r14
    5b68:	41 5f                	pop    %r15
    5b6a:	c3                   	ret
    5b6b:	e8 40 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b70 <fwp_heap_alloc_slow>:
    5b70:	53                   	push   %rbx
    5b71:	48 89 f9             	mov    %rdi,%rcx
    5b74:	41 89 f1             	mov    %esi,%r9d
    5b77:	48 83 ec 10          	sub    $0x10,%rsp
    5b7b:	8b 05 23 f0 01 00    	mov    0x1f023(%rip),%eax        # 24ba4 <fwp_heap+0x13a4>
    5b81:	85 c0                	test   %eax,%eax
    5b83:	0f 84 c7 00 00 00    	je     5c50 <fwp_heap_alloc_slow+0xe0>
    5b89:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b90:	0f 87 dd 00 00 00    	ja     5c73 <fwp_heap_alloc_slow+0x103>
    5b96:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b9a:	48 8d 3d 5f dc 01 00 	lea    0x1dc5f(%rip),%rdi        # 23800 <fwp_heap>
    5ba1:	49 63 f1             	movslq %r9d,%rsi
    5ba4:	48 c1 e8 04          	shr    $0x4,%rax
    5ba8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5baf:	00 00 
    5bb1:	41 0f b6 c2          	movzbl %r10b,%eax
    5bb5:	4c 89 d2             	mov    %r10,%rdx
    5bb8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5bbc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5bc3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5bca:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5bce:	48 01 f8             	add    %rdi,%rax
    5bd1:	4c 8b 00             	mov    (%rax),%r8
    5bd4:	4d 85 c0             	test   %r8,%r8
    5bd7:	0f 84 ab 00 00 00    	je     5c88 <fwp_heap_alloc_slow+0x118>
    5bdd:	49 8b 10             	mov    (%r8),%rdx
    5be0:	48 f7 d2             	not    %rdx
    5be3:	48 89 10             	mov    %rdx,(%rax)
    5be6:	41 83 f9 01          	cmp    $0x1,%r9d
    5bea:	4c 89 c7             	mov    %r8,%rdi
    5bed:	48 0f 45 cb          	cmovne %rbx,%rcx
    5bf1:	31 f6                	xor    %esi,%esi
    5bf3:	48 89 ca             	mov    %rcx,%rdx
    5bf6:	e8 c5 d8 ff ff       	call   34c0 <memset@plt>
    5bfb:	49 89 c0             	mov    %rax,%r8
    5bfe:	48 89 d8             	mov    %rbx,%rax
    5c01:	48 03 05 18 f0 01 00 	add    0x1f018(%rip),%rax        # 24c20 <fwp_heap+0x1420>
    5c08:	0f 82 d9 00 00 00    	jb     5ce7 <fwp_heap_alloc_slow+0x177>
    5c0e:	48 39 05 13 f0 01 00 	cmp    %rax,0x1f013(%rip)        # 24c28 <fwp_heap+0x1428>
    5c15:	48 89 05 04 f0 01 00 	mov    %rax,0x1f004(%rip)        # 24c20 <fwp_heap+0x1420>
    5c1c:	73 07                	jae    5c25 <fwp_heap_alloc_slow+0xb5>
    5c1e:	48 89 05 03 f0 01 00 	mov    %rax,0x1f003(%rip)        # 24c28 <fwp_heap+0x1428>
    5c25:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c29:	4c 89 c0             	mov    %r8,%rax
    5c2c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5c31:	f2 0f 58 05 ff ef 01 	addsd  0x1efff(%rip),%xmm0        # 24c38 <fwp_heap+0x1438>
    5c38:	00 
    5c39:	f2 0f 11 05 f7 ef 01 	movsd  %xmm0,0x1eff7(%rip)        # 24c38 <fwp_heap+0x1438>
    5c40:	00 
    5c41:	48 83 c4 10          	add    $0x10,%rsp
    5c45:	5b                   	pop    %rbx
    5c46:	c3                   	ret
    5c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5c4e:	00 00 
    5c50:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5c54:	48 89 3c 24          	mov    %rdi,(%rsp)
    5c58:	e8 13 f1 ff ff       	call   4d70 <fwp_heap_init>
    5c5d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c61:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c66:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c6d:	0f 86 23 ff ff ff    	jbe    5b96 <fwp_heap_alloc_slow+0x26>
    5c73:	48 83 c4 10          	add    $0x10,%rsp
    5c77:	44 89 ce             	mov    %r9d,%esi
    5c7a:	48 89 cf             	mov    %rcx,%rdi
    5c7d:	5b                   	pop    %rbx
    5c7e:	e9 cd fd ff ff       	jmp    5a50 <fwp_heap_alloc_big>
    5c83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c88:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c8c:	4d 85 c0             	test   %r8,%r8
    5c8f:	74 1f                	je     5cb0 <fwp_heap_alloc_slow+0x140>
    5c91:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c95:	4d 29 c3             	sub    %r8,%r11
    5c98:	49 39 db             	cmp    %rbx,%r11
    5c9b:	72 13                	jb     5cb0 <fwp_heap_alloc_slow+0x140>
    5c9d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ca1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ca5:	e9 3c ff ff ff       	jmp    5be6 <fwp_heap_alloc_slow+0x76>
    5caa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5cb0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5cb7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5cbb:	44 89 ca             	mov    %r9d,%edx
    5cbe:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5cc3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5cc7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5ccb:	44 89 d6             	mov    %r10d,%esi
    5cce:	48 01 c7             	add    %rax,%rdi
    5cd1:	e8 6a fa ff ff       	call   5740 <fwp_heap_refill>
    5cd6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5cdb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5cdf:	49 89 c0             	mov    %rax,%r8
    5ce2:	e9 ff fe ff ff       	jmp    5be6 <fwp_heap_alloc_slow+0x76>
    5ce7:	e8 c4 df ff ff       	call   3cb0 <fwp_heap_oom>
    5cec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005cf0 <fwp_heap_alloc>:
    5cf0:	8b 05 ae ee 01 00    	mov    0x1eeae(%rip),%eax        # 24ba4 <fwp_heap+0x13a4>
    5cf6:	48 89 fa             	mov    %rdi,%rdx
    5cf9:	89 f7                	mov    %esi,%edi
    5cfb:	85 c0                	test   %eax,%eax
    5cfd:	0f 84 f5 00 00 00    	je     5df8 <fwp_heap_alloc+0x108>
    5d03:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5d0a:	0f 87 e8 00 00 00    	ja     5df8 <fwp_heap_alloc+0x108>
    5d10:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5d14:	48 8d 05 e5 da 01 00 	lea    0x1dae5(%rip),%rax        # 23800 <fwp_heap>
    5d1b:	48 83 ec 18          	sub    $0x18,%rsp
    5d1f:	41 89 f0             	mov    %esi,%r8d
    5d22:	48 c1 e9 04          	shr    $0x4,%rcx
    5d26:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5d2d:	00 
    5d2e:	48 63 cf             	movslq %edi,%rcx
    5d31:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5d38:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5d3f:	00 
    5d40:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5d44:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5d48:	48 01 c8             	add    %rcx,%rax
    5d4b:	48 8b 08             	mov    (%rax),%rcx
    5d4e:	48 85 c9             	test   %rcx,%rcx
    5d51:	74 6d                	je     5dc0 <fwp_heap_alloc+0xd0>
    5d53:	48 8b 31             	mov    (%rcx),%rsi
    5d56:	48 f7 d6             	not    %rsi
    5d59:	48 89 30             	mov    %rsi,(%rax)
    5d5c:	41 83 f8 01          	cmp    $0x1,%r8d
    5d60:	48 89 cf             	mov    %rcx,%rdi
    5d63:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d68:	49 0f 45 d1          	cmovne %r9,%rdx
    5d6c:	31 f6                	xor    %esi,%esi
    5d6e:	e8 4d d7 ff ff       	call   34c0 <memset@plt>
    5d73:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d78:	48 89 c1             	mov    %rax,%rcx
    5d7b:	4c 89 c8             	mov    %r9,%rax
    5d7e:	48 03 05 9b ee 01 00 	add    0x1ee9b(%rip),%rax        # 24c20 <fwp_heap+0x1420>
    5d85:	72 7b                	jb     5e02 <fwp_heap_alloc+0x112>
    5d87:	48 39 05 9a ee 01 00 	cmp    %rax,0x1ee9a(%rip)        # 24c28 <fwp_heap+0x1428>
    5d8e:	48 89 05 8b ee 01 00 	mov    %rax,0x1ee8b(%rip)        # 24c20 <fwp_heap+0x1420>
    5d95:	73 07                	jae    5d9e <fwp_heap_alloc+0xae>
    5d97:	48 89 05 8a ee 01 00 	mov    %rax,0x1ee8a(%rip)        # 24c28 <fwp_heap+0x1428>
    5d9e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5da2:	48 89 c8             	mov    %rcx,%rax
    5da5:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5daa:	f2 0f 58 05 86 ee 01 	addsd  0x1ee86(%rip),%xmm0        # 24c38 <fwp_heap+0x1438>
    5db1:	00 
    5db2:	f2 0f 11 05 7e ee 01 	movsd  %xmm0,0x1ee7e(%rip)        # 24c38 <fwp_heap+0x1438>
    5db9:	00 
    5dba:	48 83 c4 18          	add    $0x18,%rsp
    5dbe:	c3                   	ret
    5dbf:	90                   	nop
    5dc0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5dc4:	48 85 c9             	test   %rcx,%rcx
    5dc7:	74 0c                	je     5dd5 <fwp_heap_alloc+0xe5>
    5dc9:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5dcd:	48 29 ce             	sub    %rcx,%rsi
    5dd0:	4c 39 ce             	cmp    %r9,%rsi
    5dd3:	73 13                	jae    5de8 <fwp_heap_alloc+0xf8>
    5dd5:	89 fe                	mov    %edi,%esi
    5dd7:	48 83 c4 18          	add    $0x18,%rsp
    5ddb:	48 89 d7             	mov    %rdx,%rdi
    5dde:	e9 8d fd ff ff       	jmp    5b70 <fwp_heap_alloc_slow>
    5de3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5de8:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5dec:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5df0:	e9 67 ff ff ff       	jmp    5d5c <fwp_heap_alloc+0x6c>
    5df5:	0f 1f 00             	nopl   (%rax)
    5df8:	89 fe                	mov    %edi,%esi
    5dfa:	48 89 d7             	mov    %rdx,%rdi
    5dfd:	e9 6e fd ff ff       	jmp    5b70 <fwp_heap_alloc_slow>
    5e02:	e8 a9 de ff ff       	call   3cb0 <fwp_heap_oom>
    5e07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e0e:	00 00 

0000000000005e10 <fwp_apply>:
    5e10:	55                   	push   %rbp
    5e11:	48 89 f9             	mov    %rdi,%rcx
    5e14:	48 89 e5             	mov    %rsp,%rbp
    5e17:	41 57                	push   %r15
    5e19:	41 56                	push   %r14
    5e1b:	41 55                	push   %r13
    5e1d:	41 89 f5             	mov    %esi,%r13d
    5e20:	41 54                	push   %r12
    5e22:	53                   	push   %rbx
    5e23:	48 83 ec 28          	sub    $0x28,%rsp
    5e27:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5e2e:	00 00 
    5e30:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5e34:	49 89 d6             	mov    %rdx,%r14
    5e37:	44 8b 09             	mov    (%rcx),%r9d
    5e3a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5e3e:	49 89 e0             	mov    %rsp,%r8
    5e41:	49 c1 e1 05          	shl    $0x5,%r9
    5e45:	4c 03 0d 0c f6 01 00 	add    0x1f60c(%rip),%r9        # 25458 <fwp_fns>
    5e4c:	41 8b 19             	mov    (%r9),%ebx
    5e4f:	45 85 e4             	test   %r12d,%r12d
    5e52:	75 2c                	jne    5e80 <fwp_apply+0x70>
    5e54:	41 39 dd             	cmp    %ebx,%r13d
    5e57:	72 27                	jb     5e80 <fwp_apply+0x70>
    5e59:	85 db                	test   %ebx,%ebx
    5e5b:	0f 84 a7 01 00 00    	je     6008 <fwp_apply+0x1f8>
    5e61:	4c 89 f7             	mov    %r14,%rdi
    5e64:	41 ff 51 08          	call   *0x8(%r9)
    5e68:	48 89 c1             	mov    %rax,%rcx
    5e6b:	41 39 dd             	cmp    %ebx,%r13d
    5e6e:	0f 84 6c 01 00 00    	je     5fe0 <fwp_apply+0x1d0>
    5e74:	89 d8                	mov    %ebx,%eax
    5e76:	41 29 dd             	sub    %ebx,%r13d
    5e79:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5e7d:	eb b8                	jmp    5e37 <fwp_apply+0x27>
    5e7f:	90                   	nop
    5e80:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5e85:	41 39 df             	cmp    %ebx,%r15d
    5e88:	0f 82 cc 00 00 00    	jb     5f5a <fwp_apply+0x14a>
    5e8e:	41 89 df             	mov    %ebx,%r15d
    5e91:	b8 01 00 00 00       	mov    $0x1,%eax
    5e96:	48 89 e2             	mov    %rsp,%rdx
    5e99:	45 29 e7             	sub    %r12d,%r15d
    5e9c:	85 db                	test   %ebx,%ebx
    5e9e:	0f 45 c3             	cmovne %ebx,%eax
    5ea1:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5ea8:	00 
    5ea9:	48 c1 e8 04          	shr    $0x4,%rax
    5ead:	48 c1 e0 04          	shl    $0x4,%rax
    5eb1:	48 89 c6             	mov    %rax,%rsi
    5eb4:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5ebb:	48 29 f2             	sub    %rsi,%rdx
    5ebe:	48 39 d4             	cmp    %rdx,%rsp
    5ec1:	74 15                	je     5ed8 <fwp_apply+0xc8>
    5ec3:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5eca:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5ed1:	00 00 
    5ed3:	48 39 d4             	cmp    %rdx,%rsp
    5ed6:	75 eb                	jne    5ec3 <fwp_apply+0xb3>
    5ed8:	25 ff 0f 00 00       	and    $0xfff,%eax
    5edd:	48 29 c4             	sub    %rax,%rsp
    5ee0:	48 85 c0             	test   %rax,%rax
    5ee3:	0f 85 49 01 00 00    	jne    6032 <fwp_apply+0x222>
    5ee9:	45 89 e2             	mov    %r12d,%r10d
    5eec:	48 89 e6             	mov    %rsp,%rsi
    5eef:	48 89 e7             	mov    %rsp,%rdi
    5ef2:	31 c0                	xor    %eax,%eax
    5ef4:	49 c1 e2 03          	shl    $0x3,%r10
    5ef8:	45 85 e4             	test   %r12d,%r12d
    5efb:	74 15                	je     5f12 <fwp_apply+0x102>
    5efd:	0f 1f 00             	nopl   (%rax)
    5f00:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5f05:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5f09:	48 83 c0 08          	add    $0x8,%rax
    5f0d:	4c 39 d0             	cmp    %r10,%rax
    5f10:	75 ee                	jne    5f00 <fwp_apply+0xf0>
    5f12:	45 85 ff             	test   %r15d,%r15d
    5f15:	0f 84 f4 00 00 00    	je     600f <fwp_apply+0x1ff>
    5f1b:	44 89 fa             	mov    %r15d,%edx
    5f1e:	4c 89 f0             	mov    %r14,%rax
    5f21:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5f25:	44 89 e2             	mov    %r12d,%edx
    5f28:	66 90                	xchg   %ax,%ax
    5f2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f31:	00 00 00 00 
    5f35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f3c:	00 00 00 00 
    5f40:	4c 8b 10             	mov    (%rax),%r10
    5f43:	89 d1                	mov    %edx,%ecx
    5f45:	48 83 c0 08          	add    $0x8,%rax
    5f49:	83 c2 01             	add    $0x1,%edx
    5f4c:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5f50:	4c 39 d8             	cmp    %r11,%rax
    5f53:	75 eb                	jne    5f40 <fwp_apply+0x130>
    5f55:	e9 b5 00 00 00       	jmp    600f <fwp_apply+0x1ff>
    5f5a:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5f5e:	be 02 00 00 00       	mov    $0x2,%esi
    5f63:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5f67:	48 c1 e7 03          	shl    $0x3,%rdi
    5f6b:	e8 80 fd ff ff       	call   5cf0 <fwp_heap_alloc>
    5f70:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5f74:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5f79:	48 89 c3             	mov    %rax,%rbx
    5f7c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5f80:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5f84:	66 0f d6 00          	movq   %xmm0,(%rax)
    5f88:	45 85 e4             	test   %r12d,%r12d
    5f8b:	74 14                	je     5fa1 <fwp_apply+0x191>
    5f8d:	44 89 e2             	mov    %r12d,%edx
    5f90:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5f94:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5f98:	48 c1 e2 03          	shl    $0x3,%rdx
    5f9c:	e8 6f d6 ff ff       	call   3610 <memmove@plt>
    5fa1:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5fa5:	45 85 ed             	test   %r13d,%r13d
    5fa8:	74 2e                	je     5fd8 <fwp_apply+0x1c8>
    5faa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5fb1:	00 00 00 00 
    5fb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5fbc:	00 00 00 00 
    5fc0:	49 8b 16             	mov    (%r14),%rdx
    5fc3:	44 89 e0             	mov    %r12d,%eax
    5fc6:	49 83 c6 08          	add    $0x8,%r14
    5fca:	41 83 c4 01          	add    $0x1,%r12d
    5fce:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5fd3:	49 39 ce             	cmp    %rcx,%r14
    5fd6:	75 e8                	jne    5fc0 <fwp_apply+0x1b0>
    5fd8:	48 89 d9             	mov    %rbx,%rcx
    5fdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5fe0:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5fe4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5feb:	00 00 
    5fed:	75 4e                	jne    603d <fwp_apply+0x22d>
    5fef:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5ff3:	48 89 c8             	mov    %rcx,%rax
    5ff6:	5b                   	pop    %rbx
    5ff7:	41 5c                	pop    %r12
    5ff9:	41 5d                	pop    %r13
    5ffb:	41 5e                	pop    %r14
    5ffd:	41 5f                	pop    %r15
    5fff:	5d                   	pop    %rbp
    6000:	c3                   	ret
    6001:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6008:	45 31 ff             	xor    %r15d,%r15d
    600b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    600f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    6013:	41 ff 51 08          	call   *0x8(%r9)
    6017:	48 89 c1             	mov    %rax,%rcx
    601a:	45 39 fd             	cmp    %r15d,%r13d
    601d:	74 c1                	je     5fe0 <fwp_apply+0x1d0>
    601f:	45 01 e5             	add    %r12d,%r13d
    6022:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    6026:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    602a:	41 29 dd             	sub    %ebx,%r13d
    602d:	e9 05 fe ff ff       	jmp    5e37 <fwp_apply+0x27>
    6032:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    6038:	e9 ac fe ff ff       	jmp    5ee9 <fwp_apply+0xd9>
    603d:	e8 1e d4 ff ff       	call   3460 <__stack_chk_fail@plt>
    6042:	0f 1f 00             	nopl   (%rax)
    6045:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    604c:	00 00 00 00 

0000000000006050 <fwp_p_ad_push>:
    6050:	41 57                	push   %r15
    6052:	41 56                	push   %r14
    6054:	41 55                	push   %r13
    6056:	49 89 d5             	mov    %rdx,%r13
    6059:	41 54                	push   %r12
    605b:	49 89 fc             	mov    %rdi,%r12
    605e:	55                   	push   %rbp
    605f:	53                   	push   %rbx
    6060:	48 83 ec 38          	sub    $0x38,%rsp
    6064:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6069:	48 85 ff             	test   %rdi,%rdi
    606c:	79 09                	jns    6077 <fwp_p_ad_push+0x27>
    606e:	48 85 d2             	test   %rdx,%rdx
    6071:	0f 88 a9 01 00 00    	js     6220 <fwp_p_ad_push+0x1d0>
    6077:	48 89 f8             	mov    %rdi,%rax
    607a:	48 89 0c 24          	mov    %rcx,(%rsp)
    607e:	48 09 d0             	or     %rdx,%rax
    6081:	0f 89 79 01 00 00    	jns    6200 <fwp_p_ad_push+0x1b0>
    6087:	48 89 f8             	mov    %rdi,%rax
    608a:	48 c1 f8 20          	sar    $0x20,%rax
    608e:	48 85 ff             	test   %rdi,%rdi
    6091:	79 24                	jns    60b7 <fwp_p_ad_push+0x67>
    6093:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6098:	48 89 d0             	mov    %rdx,%rax
    609b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    60a2:	00 
    60a3:	49 89 d4             	mov    %rdx,%r12
    60a6:	48 c1 f8 20          	sar    $0x20,%rax
    60aa:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    60b1:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    60b7:	48 89 c7             	mov    %rax,%rdi
    60ba:	e8 11 e6 ff ff       	call   46d0 <fwp_tape_of>
    60bf:	48 89 c3             	mov    %rax,%rbx
    60c2:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    60c7:	0f 85 76 02 00 00    	jne    6343 <fwp_p_ad_push+0x2f3>
    60cd:	4c 8b 78 10          	mov    0x10(%rax),%r15
    60d1:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    60d8:	0f 8f 59 02 00 00    	jg     6337 <fwp_p_ad_push+0x2e7>
    60de:	44 89 e0             	mov    %r12d,%eax
    60e1:	4c 39 f8             	cmp    %r15,%rax
    60e4:	0f 8d 41 02 00 00    	jge    632b <fwp_p_ad_push+0x2db>
    60ea:	4d 85 ed             	test   %r13,%r13
    60ed:	78 0c                	js     60fb <fwp_p_ad_push+0xab>
    60ef:	44 89 e8             	mov    %r13d,%eax
    60f2:	4c 39 f8             	cmp    %r15,%rax
    60f5:	0f 8d 30 02 00 00    	jge    632b <fwp_p_ad_push+0x2db>
    60fb:	4d 89 fe             	mov    %r15,%r14
    60fe:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6102:	49 8d 46 01          	lea    0x1(%r14),%rax
    6106:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    610c:	0f 87 25 02 00 00    	ja     6337 <fwp_p_ad_push+0x2e7>
    6112:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    6116:	48 39 e8             	cmp    %rbp,%rax
    6119:	0f 8e 31 01 00 00    	jle    6250 <fwp_p_ad_push+0x200>
    611f:	48 85 ed             	test   %rbp,%rbp
    6122:	b9 40 00 00 00       	mov    $0x40,%ecx
    6127:	48 0f 44 e9          	cmove  %rcx,%rbp
    612b:	48 39 e8             	cmp    %rbp,%rax
    612e:	7e 20                	jle    6150 <fwp_p_ad_push+0x100>
    6130:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    6137:	0f 8f 03 01 00 00    	jg     6240 <fwp_p_ad_push+0x1f0>
    613d:	48 01 ed             	add    %rbp,%rbp
    6140:	48 39 e8             	cmp    %rbp,%rax
    6143:	7f eb                	jg     6130 <fwp_p_ad_push+0xe0>
    6145:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    614c:	00 00 00 00 
    6150:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6157:	00 
    6158:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    615c:	48 89 c6             	mov    %rax,%rsi
    615f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6164:	e8 67 d4 ff ff       	call   35d0 <realloc@plt>
    6169:	48 85 c0             	test   %rax,%rax
    616c:	0f 84 dd 01 00 00    	je     634f <fwp_p_ad_push+0x2ff>
    6172:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    6176:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    617a:	48 89 43 20          	mov    %rax,0x20(%rbx)
    617e:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    6182:	48 89 e9             	mov    %rbp,%rcx
    6185:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6189:	48 c1 e1 04          	shl    $0x4,%rcx
    618d:	48 89 ce             	mov    %rcx,%rsi
    6190:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6195:	e8 36 d4 ff ff       	call   35d0 <realloc@plt>
    619a:	48 85 c0             	test   %rax,%rax
    619d:	0f 84 ac 01 00 00    	je     634f <fwp_p_ad_push+0x2ff>
    61a3:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    61a7:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    61ac:	4d 85 f6             	test   %r14,%r14
    61af:	48 89 43 30          	mov    %rax,0x30(%rbx)
    61b3:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    61b8:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    61bf:	00 
    61c0:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    61c7:	00 
    61c8:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    61cc:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    61d3:	00 
    61d4:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    61d8:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    61dc:	0f 85 e2 00 00 00    	jne    62c4 <fwp_p_ad_push+0x274>
    61e2:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    61e6:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    61ea:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    61ee:	49 01 c8             	add    %rcx,%r8
    61f1:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    61f5:	eb 79                	jmp    6270 <fwp_p_ad_push+0x220>
    61f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    61fe:	00 00 
    6200:	48 89 d0             	mov    %rdx,%rax
    6203:	48 c1 ff 20          	sar    $0x20,%rdi
    6207:	48 c1 f8 20          	sar    $0x20,%rax
    620b:	48 39 c7             	cmp    %rax,%rdi
    620e:	0f 84 a3 fe ff ff    	je     60b7 <fwp_p_ad_push+0x67>
    6214:	48 8d 3d 95 96 00 00 	lea    0x9695(%rip),%rdi        # f8b0 <_IO_stdin_used+0x8b0>
    621b:	e8 d0 e1 ff ff       	call   43f0 <fwp_trap>
    6220:	48 83 c4 38          	add    $0x38,%rsp
    6224:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    622b:	5b                   	pop    %rbx
    622c:	5d                   	pop    %rbp
    622d:	41 5c                	pop    %r12
    622f:	41 5d                	pop    %r13
    6231:	41 5e                	pop    %r14
    6233:	41 5f                	pop    %r15
    6235:	c3                   	ret
    6236:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    623d:	00 00 00 
    6240:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    6245:	e9 06 ff ff ff       	jmp    6150 <fwp_p_ad_push+0x100>
    624a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6250:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    6254:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6258:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    625f:	00 
    6260:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6267:	00 
    6268:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    626c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6270:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6276:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    627a:	4d 85 ed             	test   %r13,%r13
    627d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6282:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6288:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    628f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6293:	49 8d 47 01          	lea    0x1(%r15),%rax
    6297:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    629b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    62a1:	48 89 43 10          	mov    %rax,0x10(%rbx)
    62a5:	48 83 c4 38          	add    $0x38,%rsp
    62a9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    62b0:	ff ff ff 
    62b3:	4c 21 e0             	and    %r12,%rax
    62b6:	5b                   	pop    %rbx
    62b7:	5d                   	pop    %rbp
    62b8:	4c 09 f8             	or     %r15,%rax
    62bb:	41 5c                	pop    %r12
    62bd:	41 5d                	pop    %r13
    62bf:	41 5e                	pop    %r14
    62c1:	41 5f                	pop    %r15
    62c3:	c3                   	ret
    62c4:	48 39 ca             	cmp    %rcx,%rdx
    62c7:	49 89 d6             	mov    %rdx,%r14
    62ca:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    62cf:	48 0f 43 ca          	cmovae %rdx,%rcx
    62d3:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    62d8:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    62dd:	48 29 d1             	sub    %rdx,%rcx
    62e0:	4c 89 ca             	mov    %r9,%rdx
    62e3:	e8 78 d2 ff ff       	call   3560 <__memmove_chk@plt>
    62e8:	4c 03 73 30          	add    0x30(%rbx),%r14
    62ec:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    62f1:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    62f5:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    62fa:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    62fe:	48 03 7b 20          	add    0x20(%rbx),%rdi
    6302:	4c 89 d2             	mov    %r10,%rdx
    6305:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    630a:	e8 01 d3 ff ff       	call   3610 <memmove@plt>
    630f:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6313:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6317:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    631c:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    6321:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    6326:	e9 bb fe ff ff       	jmp    61e6 <fwp_p_ad_push+0x196>
    632b:	48 8d 3d 35 8e 00 00 	lea    0x8e35(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    6332:	e8 b9 e0 ff ff       	call   43f0 <fwp_trap>
    6337:	48 8d 3d 0e 8e 00 00 	lea    0x8e0e(%rip),%rdi        # f14c <_IO_stdin_used+0x14c>
    633e:	e8 ad e0 ff ff       	call   43f0 <fwp_trap>
    6343:	48 8d 3d ae 95 00 00 	lea    0x95ae(%rip),%rdi        # f8f8 <_IO_stdin_used+0x8f8>
    634a:	e8 a1 e0 ff ff       	call   43f0 <fwp_trap>
    634f:	48 89 df             	mov    %rbx,%rdi
    6352:	e8 a9 d8 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6357:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    635b:	e8 60 d0 ff ff       	call   33c0 <free@plt>
    6360:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6364:	e8 57 d0 ff ff       	call   33c0 <free@plt>
    6369:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    636d:	e8 4e d0 ff ff       	call   33c0 <free@plt>
    6372:	31 c9                	xor    %ecx,%ecx
    6374:	31 c0                	xor    %eax,%eax
    6376:	31 d2                	xor    %edx,%edx
    6378:	89 53 04             	mov    %edx,0x4(%rbx)
    637b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    637f:	ba 13 00 00 00       	mov    $0x13,%edx
    6384:	be 01 00 00 00       	mov    $0x1,%esi
    6389:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    638d:	48 8d 3d 74 8c 00 00 	lea    0x8c74(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    6394:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6398:	48 8b 0d c1 cc 00 00 	mov    0xccc1(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    639f:	48 89 43 40          	mov    %rax,0x40(%rbx)
    63a3:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    63a7:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    63ab:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    63af:	e8 cc d2 ff ff       	call   3680 <fwrite@plt>
    63b4:	31 ff                	xor    %edi,%edi
    63b6:	e8 05 d2 ff ff       	call   35c0 <fflush@plt>
    63bb:	bf 66 00 00 00       	mov    $0x66,%edi
    63c0:	e8 db d2 ff ff       	call   36a0 <_Exit@plt>
    63c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    63cc:	00 00 00 00 

00000000000063d0 <w107>:
    63d0:	66 0f 28 e0          	movapd %xmm0,%xmm4
    63d4:	41 55                	push   %r13
    63d6:	48 89 fa             	mov    %rdi,%rdx
    63d9:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    63dd:	41 54                	push   %r12
    63df:	49 89 fc             	mov    %rdi,%r12
    63e2:	55                   	push   %rbp
    63e3:	53                   	push   %rbx
    63e4:	48 89 f3             	mov    %rsi,%rbx
    63e7:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    63ec:	48 89 f1             	mov    %rsi,%rcx
    63ef:	48 83 ec 28          	sub    $0x28,%rsp
    63f3:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    63f9:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    63ff:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6405:	e8 46 fc ff ff       	call   6050 <fwp_p_ad_push>
    640a:	48 89 c7             	mov    %rax,%rdi
    640d:	e8 4e eb ff ff       	call   4f60 <caf61>
    6412:	66 48 0f 6e c0       	movq   %rax,%xmm0
    6417:	e8 44 eb ff ff       	call   4f60 <caf61>
    641c:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6422:	66 0f 57 05 c6 97 00 	xorpd  0x97c6(%rip),%xmm0        # fbf0 <msg.8+0x80>
    6429:	00 
    642a:	48 89 da             	mov    %rbx,%rdx
    642d:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6433:	48 89 c1             	mov    %rax,%rcx
    6436:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    643b:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6440:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6446:	e8 05 fc ff ff       	call   6050 <fwp_p_ad_push>
    644b:	4c 89 e7             	mov    %r12,%rdi
    644e:	49 89 c5             	mov    %rax,%r13
    6451:	e8 0a eb ff ff       	call   4f60 <caf61>
    6456:	48 89 c6             	mov    %rax,%rsi
    6459:	e8 02 eb ff ff       	call   4f60 <caf61>
    645e:	66 48 0f 6e d6       	movq   %rsi,%xmm2
    6463:	f2 0f 10 05 c5 97 00 	movsd  0x97c5(%rip),%xmm0        # fc30 <msg.8+0xc0>
    646a:	00 
    646b:	66 0f 57 15 7d 97 00 	xorpd  0x977d(%rip),%xmm2        # fbf0 <msg.8+0x80>
    6472:	00 
    6473:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    6479:	48 89 c1             	mov    %rax,%rcx
    647c:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6483:	66 48 0f 7e d6       	movq   %xmm2,%rsi
    6488:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    648d:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6493:	e8 b8 fb ff ff       	call   6050 <fwp_p_ad_push>
    6498:	48 89 e9             	mov    %rbp,%rcx
    649b:	4c 89 ea             	mov    %r13,%rdx
    649e:	48 89 ee             	mov    %rbp,%rsi
    64a1:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    64a7:	4c 89 ef             	mov    %r13,%rdi
    64aa:	49 89 c4             	mov    %rax,%r12
    64ad:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    64b1:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    64b7:	e8 94 fb ff ff       	call   6050 <fwp_p_ad_push>
    64bc:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    64c2:	f2 0f 59 1d 6e 97 00 	mulsd  0x976e(%rip),%xmm3        # fc38 <msg.8+0xc8>
    64c9:	00 
    64ca:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    64d1:	00 59 40 
    64d4:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    64d9:	48 89 c2             	mov    %rax,%rdx
    64dc:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    64e3:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    64e9:	e8 62 fb ff ff       	call   6050 <fwp_p_ad_push>
    64ee:	4c 89 e2             	mov    %r12,%rdx
    64f1:	48 89 d9             	mov    %rbx,%rcx
    64f4:	48 89 de             	mov    %rbx,%rsi
    64f7:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    64fd:	4c 89 e7             	mov    %r12,%rdi
    6500:	48 89 c5             	mov    %rax,%rbp
    6503:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6507:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    650d:	e8 3e fb ff ff       	call   6050 <fwp_p_ad_push>
    6512:	48 89 c7             	mov    %rax,%rdi
    6515:	e8 46 ea ff ff       	call   4f60 <caf61>
    651a:	48 89 c6             	mov    %rax,%rsi
    651d:	e8 3e ea ff ff       	call   4f60 <caf61>
    6522:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6528:	48 89 ea             	mov    %rbp,%rdx
    652b:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6531:	48 89 c1             	mov    %rax,%rcx
    6534:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6539:	e8 12 fb ff ff       	call   6050 <fwp_p_ad_push>
    653e:	48 83 c4 28          	add    $0x28,%rsp
    6542:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    6547:	5b                   	pop    %rbx
    6548:	5d                   	pop    %rbp
    6549:	41 5c                	pop    %r12
    654b:	41 5d                	pop    %r13
    654d:	c3                   	ret
    654e:	66 90                	xchg   %ax,%ax

0000000000006550 <w164.constprop.0>:
    6550:	41 54                	push   %r12
    6552:	55                   	push   %rbp
    6553:	53                   	push   %rbx
    6554:	48 83 ec 10          	sub    $0x10,%rsp
    6558:	4c 8b 27             	mov    (%rdi),%r12
    655b:	4d 85 e4             	test   %r12,%r12
    655e:	74 78                	je     65d8 <w164.constprop.0+0x88>
    6560:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    6567:	00 00 
    6569:	48 89 fd             	mov    %rdi,%rbp
    656c:	31 db                	xor    %ebx,%ebx
    656e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6575:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    657c:	00 00 00 00 
    6580:	4c 8b 44 dd 10       	mov    0x10(%rbp,%rbx,8),%r8
    6585:	f2 0f 10 44 dd 08    	movsd  0x8(%rbp,%rbx,8),%xmm0
    658b:	48 83 c3 02          	add    $0x2,%rbx
    658f:	e8 cc e9 ff ff       	call   4f60 <caf61>
    6594:	48 89 c6             	mov    %rax,%rsi
    6597:	e8 c4 e9 ff ff       	call   4f60 <caf61>
    659c:	f2 0f 58 44 24 08    	addsd  0x8(%rsp),%xmm0
    65a2:	4c 89 c2             	mov    %r8,%rdx
    65a5:	48 89 c1             	mov    %rax,%rcx
    65a8:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    65ae:	e8 9d fa ff ff       	call   6050 <fwp_p_ad_push>
    65b3:	48 89 c7             	mov    %rax,%rdi
    65b6:	4c 39 e3             	cmp    %r12,%rbx
    65b9:	72 c5                	jb     6580 <w164.constprop.0+0x30>
    65bb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    65c0:	48 83 c4 10          	add    $0x10,%rsp
    65c4:	5b                   	pop    %rbx
    65c5:	5d                   	pop    %rbp
    65c6:	66 48 0f 6e c0       	movq   %rax,%xmm0
    65cb:	41 5c                	pop    %r12
    65cd:	48 89 f8             	mov    %rdi,%rax
    65d0:	c3                   	ret
    65d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    65d8:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    65df:	00 00 
    65e1:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    65e8:	eb d1                	jmp    65bb <w164.constprop.0+0x6b>
    65ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000065f0 <fwp_data.part.0.constprop.0>:
    65f0:	41 56                	push   %r14
    65f2:	41 89 fe             	mov    %edi,%r14d
    65f5:	41 54                	push   %r12
    65f7:	49 89 f4             	mov    %rsi,%r12
    65fa:	55                   	push   %rbp
    65fb:	53                   	push   %rbx
    65fc:	48 83 ec 08          	sub    $0x8,%rsp
    6600:	8b 05 9e e5 01 00    	mov    0x1e59e(%rip),%eax        # 24ba4 <fwp_heap+0x13a4>
    6606:	85 c0                	test   %eax,%eax
    6608:	0f 84 fa 00 00 00    	je     6708 <fwp_data.part.0.constprop.0+0x118>
    660e:	0f b6 05 8d e1 01 00 	movzbl 0x1e18d(%rip),%eax        # 247a2 <fwp_heap+0xfa2>
    6615:	48 8d 15 e4 d1 01 00 	lea    0x1d1e4(%rip),%rdx        # 23800 <fwp_heap>
    661c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6623:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6627:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    662b:	48 8b 18             	mov    (%rax),%rbx
    662e:	48 85 db             	test   %rbx,%rbx
    6631:	0f 84 a9 00 00 00    	je     66e0 <fwp_data.part.0.constprop.0+0xf0>
    6637:	48 8b 13             	mov    (%rbx),%rdx
    663a:	48 f7 d2             	not    %rdx
    663d:	48 89 10             	mov    %rdx,(%rax)
    6640:	48 83 fd 18          	cmp    $0x18,%rbp
    6644:	76 1b                	jbe    6661 <fwp_data.part.0.constprop.0+0x71>
    6646:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    664a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    664e:	31 f6                	xor    %esi,%esi
    6650:	48 c1 e8 03          	shr    $0x3,%rax
    6654:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    665b:	00 
    665c:	e8 5f ce ff ff       	call   34c0 <memset@plt>
    6661:	48 89 e8             	mov    %rbp,%rax
    6664:	48 03 05 b5 e5 01 00 	add    0x1e5b5(%rip),%rax        # 24c20 <fwp_heap+0x1420>
    666b:	0f 82 a8 00 00 00    	jb     6719 <fwp_data.part.0.constprop.0+0x129>
    6671:	48 39 05 b0 e5 01 00 	cmp    %rax,0x1e5b0(%rip)        # 24c28 <fwp_heap+0x1428>
    6678:	48 89 05 a1 e5 01 00 	mov    %rax,0x1e5a1(%rip)        # 24c20 <fwp_heap+0x1420>
    667f:	73 07                	jae    6688 <fwp_data.part.0.constprop.0+0x98>
    6681:	48 89 05 a0 e5 01 00 	mov    %rax,0x1e5a0(%rip)        # 24c28 <fwp_heap+0x1428>
    6688:	66 0f ef c0          	pxor   %xmm0,%xmm0
    668c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6691:	f2 0f 58 05 9f e5 01 	addsd  0x1e59f(%rip),%xmm0        # 24c38 <fwp_heap+0x1438>
    6698:	00 
    6699:	f2 0f 11 05 97 e5 01 	movsd  %xmm0,0x1e597(%rip)        # 24c38 <fwp_heap+0x1438>
    66a0:	00 
    66a1:	b8 02 00 00 00       	mov    $0x2,%eax
    66a6:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    66ab:	66 0f 6e c8          	movd   %eax,%xmm1
    66af:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    66b3:	66 0f d6 03          	movq   %xmm0,(%rbx)
    66b7:	49 8b 04 24          	mov    (%r12),%rax
    66bb:	48 89 43 08          	mov    %rax,0x8(%rbx)
    66bf:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    66c4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    66c8:	48 83 c4 08          	add    $0x8,%rsp
    66cc:	48 89 d8             	mov    %rbx,%rax
    66cf:	5b                   	pop    %rbx
    66d0:	5d                   	pop    %rbp
    66d1:	41 5c                	pop    %r12
    66d3:	41 5e                	pop    %r14
    66d5:	c3                   	ret
    66d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    66dd:	00 00 00 
    66e0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    66e4:	48 85 db             	test   %rbx,%rbx
    66e7:	74 1f                	je     6708 <fwp_data.part.0.constprop.0+0x118>
    66e9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    66ed:	48 29 da             	sub    %rbx,%rdx
    66f0:	48 39 ea             	cmp    %rbp,%rdx
    66f3:	72 13                	jb     6708 <fwp_data.part.0.constprop.0+0x118>
    66f5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    66f9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    66fd:	e9 3e ff ff ff       	jmp    6640 <fwp_data.part.0.constprop.0+0x50>
    6702:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6708:	31 f6                	xor    %esi,%esi
    670a:	bf 18 00 00 00       	mov    $0x18,%edi
    670f:	e8 dc f5 ff ff       	call   5cf0 <fwp_heap_alloc>
    6714:	48 89 c3             	mov    %rax,%rbx
    6717:	eb 88                	jmp    66a1 <fwp_data.part.0.constprop.0+0xb1>
    6719:	e8 92 d5 ff ff       	call   3cb0 <fwp_heap_oom>
    671e:	66 90                	xchg   %ax,%ax

0000000000006720 <fwp_rc_share>:
    6720:	48 8b 05 b1 e4 01 00 	mov    0x1e4b1(%rip),%rax        # 24bd8 <fwp_heap+0x13d8>
    6727:	48 2b 3d 82 e4 01 00 	sub    0x1e482(%rip),%rdi        # 24bb0 <fwp_heap+0x13b0>
    672e:	48 c1 e0 10          	shl    $0x10,%rax
    6732:	48 39 c7             	cmp    %rax,%rdi
    6735:	73 4a                	jae    6781 <fwp_rc_share+0x61>
    6737:	48 89 f8             	mov    %rdi,%rax
    673a:	48 c1 e8 10          	shr    $0x10,%rax
    673e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6742:	48 8b 05 af e4 01 00 	mov    0x1e4af(%rip),%rax        # 24bf8 <fwp_heap+0x13f8>
    6749:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    674d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6751:	48 85 d2             	test   %rdx,%rdx
    6754:	74 2b                	je     6781 <fwp_rc_share+0x61>
    6756:	0f b6 08             	movzbl (%rax),%ecx
    6759:	80 f9 02             	cmp    $0x2,%cl
    675c:	74 2a                	je     6788 <fwp_rc_share+0x68>
    675e:	80 f9 01             	cmp    $0x1,%cl
    6761:	75 1e                	jne    6781 <fwp_rc_share+0x61>
    6763:	8b 48 18             	mov    0x18(%rax),%ecx
    6766:	0f b7 ff             	movzwl %di,%edi
    6769:	8b 40 1c             	mov    0x1c(%rax),%eax
    676c:	48 0f af f9          	imul   %rcx,%rdi
    6770:	48 c1 ef 20          	shr    $0x20,%rdi
    6774:	48 39 c7             	cmp    %rax,%rdi
    6777:	73 08                	jae    6781 <fwp_rc_share+0x61>
    6779:	48 01 fa             	add    %rdi,%rdx
    677c:	80 3a 00             	cmpb   $0x0,(%rdx)
    677f:	75 0d                	jne    678e <fwp_rc_share+0x6e>
    6781:	c3                   	ret
    6782:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6788:	66 85 ff             	test   %di,%di
    678b:	74 ef                	je     677c <fwp_rc_share+0x5c>
    678d:	c3                   	ret
    678e:	50                   	push   %rax
    678f:	48 8d 3d 92 91 00 00 	lea    0x9192(%rip),%rdi        # f928 <_IO_stdin_used+0x928>
    6796:	e8 55 dc ff ff       	call   43f0 <fwp_trap>
    679b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000067a0 <fwp_rc_fresh>:
    67a0:	48 8b 15 31 e4 01 00 	mov    0x1e431(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    67a7:	48 89 f8             	mov    %rdi,%rax
    67aa:	48 89 fe             	mov    %rdi,%rsi
    67ad:	48 2b 05 fc e3 01 00 	sub    0x1e3fc(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    67b4:	48 c1 e2 10          	shl    $0x10,%rdx
    67b8:	48 39 d0             	cmp    %rdx,%rax
    67bb:	73 4f                	jae    680c <fwp_rc_fresh+0x6c>
    67bd:	48 89 c2             	mov    %rax,%rdx
    67c0:	48 c1 ea 10          	shr    $0x10,%rdx
    67c4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    67c8:	48 8b 15 29 e4 01 00 	mov    0x1e429(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    67cf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    67d3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    67d7:	48 85 d2             	test   %rdx,%rdx
    67da:	74 30                	je     680c <fwp_rc_fresh+0x6c>
    67dc:	0f b6 39             	movzbl (%rcx),%edi
    67df:	40 80 ff 02          	cmp    $0x2,%dil
    67e3:	74 2b                	je     6810 <fwp_rc_fresh+0x70>
    67e5:	40 80 ff 01          	cmp    $0x1,%dil
    67e9:	75 21                	jne    680c <fwp_rc_fresh+0x6c>
    67eb:	8b 79 18             	mov    0x18(%rcx),%edi
    67ee:	0f b7 c0             	movzwl %ax,%eax
    67f1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    67f4:	48 0f af c7          	imul   %rdi,%rax
    67f8:	48 c1 e8 20          	shr    $0x20,%rax
    67fc:	48 39 c8             	cmp    %rcx,%rax
    67ff:	73 0b                	jae    680c <fwp_rc_fresh+0x6c>
    6801:	48 01 c2             	add    %rax,%rdx
    6804:	80 3a ff             	cmpb   $0xff,(%rdx)
    6807:	74 17                	je     6820 <fwp_rc_fresh+0x80>
    6809:	c6 02 01             	movb   $0x1,(%rdx)
    680c:	48 89 f0             	mov    %rsi,%rax
    680f:	c3                   	ret
    6810:	66 85 c0             	test   %ax,%ax
    6813:	74 ef                	je     6804 <fwp_rc_fresh+0x64>
    6815:	48 89 f0             	mov    %rsi,%rax
    6818:	c3                   	ret
    6819:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6820:	48 83 ec 18          	sub    $0x18,%rsp
    6824:	48 89 d7             	mov    %rdx,%rdi
    6827:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    682c:	48 89 14 24          	mov    %rdx,(%rsp)
    6830:	e8 7b ed ff ff       	call   55b0 <fwp_rc_forget_slot>
    6835:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    683a:	48 8b 14 24          	mov    (%rsp),%rdx
    683e:	48 89 f0             	mov    %rsi,%rax
    6841:	c6 02 01             	movb   $0x1,(%rdx)
    6844:	48 83 c4 18          	add    $0x18,%rsp
    6848:	c3                   	ret
    6849:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006850 <fwp_rc_free_arr>:
    6850:	48 8b 15 81 e3 01 00 	mov    0x1e381(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    6857:	48 89 f8             	mov    %rdi,%rax
    685a:	48 2b 05 4f e3 01 00 	sub    0x1e34f(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    6861:	48 c1 e2 10          	shl    $0x10,%rdx
    6865:	48 39 d0             	cmp    %rdx,%rax
    6868:	73 5b                	jae    68c5 <fwp_rc_free_arr+0x75>
    686a:	48 89 c2             	mov    %rax,%rdx
    686d:	48 c1 ea 10          	shr    $0x10,%rdx
    6871:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6875:	48 8b 15 7c e3 01 00 	mov    0x1e37c(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    687c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6880:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6884:	48 85 c9             	test   %rcx,%rcx
    6887:	74 3c                	je     68c5 <fwp_rc_free_arr+0x75>
    6889:	0f b6 32             	movzbl (%rdx),%esi
    688c:	40 80 fe 02          	cmp    $0x2,%sil
    6890:	74 2e                	je     68c0 <fwp_rc_free_arr+0x70>
    6892:	40 80 fe 01          	cmp    $0x1,%sil
    6896:	75 2d                	jne    68c5 <fwp_rc_free_arr+0x75>
    6898:	8b 72 18             	mov    0x18(%rdx),%esi
    689b:	0f b7 c0             	movzwl %ax,%eax
    689e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    68a1:	48 0f af c6          	imul   %rsi,%rax
    68a5:	48 c1 e8 20          	shr    $0x20,%rax
    68a9:	48 39 d0             	cmp    %rdx,%rax
    68ac:	73 17                	jae    68c5 <fwp_rc_free_arr+0x75>
    68ae:	48 01 c1             	add    %rax,%rcx
    68b1:	80 39 01             	cmpb   $0x1,(%rcx)
    68b4:	75 0f                	jne    68c5 <fwp_rc_free_arr+0x75>
    68b6:	e9 35 ef ff ff       	jmp    57f0 <fwp_mem_free>
    68bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    68c0:	66 85 c0             	test   %ax,%ax
    68c3:	74 ec                	je     68b1 <fwp_rc_free_arr+0x61>
    68c5:	c3                   	ret
    68c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    68cd:	00 00 00 

00000000000068d0 <fwp_rc_dup>:
    68d0:	f3 0f 1e fa          	endbr64
    68d4:	48 8b 05 fd e2 01 00 	mov    0x1e2fd(%rip),%rax        # 24bd8 <fwp_heap+0x13d8>
    68db:	48 2b 3d ce e2 01 00 	sub    0x1e2ce(%rip),%rdi        # 24bb0 <fwp_heap+0x13b0>
    68e2:	48 c1 e0 10          	shl    $0x10,%rax
    68e6:	48 39 c7             	cmp    %rax,%rdi
    68e9:	73 56                	jae    6941 <fwp_rc_dup+0x71>
    68eb:	48 89 f8             	mov    %rdi,%rax
    68ee:	48 c1 e8 10          	shr    $0x10,%rax
    68f2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    68f6:	48 8b 05 fb e2 01 00 	mov    0x1e2fb(%rip),%rax        # 24bf8 <fwp_heap+0x13f8>
    68fd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6901:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6905:	48 85 c0             	test   %rax,%rax
    6908:	74 37                	je     6941 <fwp_rc_dup+0x71>
    690a:	0f b6 0a             	movzbl (%rdx),%ecx
    690d:	80 f9 02             	cmp    $0x2,%cl
    6910:	74 36                	je     6948 <fwp_rc_dup+0x78>
    6912:	80 f9 01             	cmp    $0x1,%cl
    6915:	75 2a                	jne    6941 <fwp_rc_dup+0x71>
    6917:	8b 4a 18             	mov    0x18(%rdx),%ecx
    691a:	0f b7 ff             	movzwl %di,%edi
    691d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6920:	48 0f af f9          	imul   %rcx,%rdi
    6924:	48 c1 ef 20          	shr    $0x20,%rdi
    6928:	48 39 d7             	cmp    %rdx,%rdi
    692b:	73 14                	jae    6941 <fwp_rc_dup+0x71>
    692d:	48 01 f8             	add    %rdi,%rax
    6930:	0f b6 10             	movzbl (%rax),%edx
    6933:	84 d2                	test   %dl,%dl
    6935:	74 0a                	je     6941 <fwp_rc_dup+0x71>
    6937:	80 fa fd             	cmp    $0xfd,%dl
    693a:	77 14                	ja     6950 <fwp_rc_dup+0x80>
    693c:	83 c2 01             	add    $0x1,%edx
    693f:	88 10                	mov    %dl,(%rax)
    6941:	c3                   	ret
    6942:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6948:	66 85 ff             	test   %di,%di
    694b:	74 e3                	je     6930 <fwp_rc_dup+0x60>
    694d:	c3                   	ret
    694e:	66 90                	xchg   %ax,%ax
    6950:	48 89 c7             	mov    %rax,%rdi
    6953:	e9 38 eb ff ff       	jmp    5490 <fwp_rc_wide_dup>
    6958:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    695f:	00 

0000000000006960 <fwp_owned_entry161>:
    6960:	f3 0f 1e fa          	endbr64
    6964:	48 83 ec 38          	sub    $0x38,%rsp
    6968:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    696d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6974:	00 00 
    6976:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    697b:	31 c0                	xor    %eax,%eax
    697d:	48 8b 07             	mov    (%rdi),%rax
    6980:	48 03 47 10          	add    0x10(%rdi),%rax
    6984:	0f 80 c2 00 00 00    	jo     6a4c <fwp_owned_entry161+0xec>
    698a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    698f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6994:	31 ff                	xor    %edi,%edi
    6996:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    699a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    699f:	e8 4c fc ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    69a4:	48 8b 15 2d e2 01 00 	mov    0x1e22d(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    69ab:	48 89 c6             	mov    %rax,%rsi
    69ae:	48 2b 05 fb e1 01 00 	sub    0x1e1fb(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    69b5:	48 c1 e2 10          	shl    $0x10,%rdx
    69b9:	48 39 d0             	cmp    %rdx,%rax
    69bc:	73 4f                	jae    6a0d <fwp_owned_entry161+0xad>
    69be:	48 89 c2             	mov    %rax,%rdx
    69c1:	48 c1 ea 10          	shr    $0x10,%rdx
    69c5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    69c9:	48 8b 15 28 e2 01 00 	mov    0x1e228(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    69d0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    69d4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    69d8:	48 85 d2             	test   %rdx,%rdx
    69db:	74 30                	je     6a0d <fwp_owned_entry161+0xad>
    69dd:	0f b6 39             	movzbl (%rcx),%edi
    69e0:	40 80 ff 02          	cmp    $0x2,%dil
    69e4:	74 42                	je     6a28 <fwp_owned_entry161+0xc8>
    69e6:	40 80 ff 01          	cmp    $0x1,%dil
    69ea:	75 21                	jne    6a0d <fwp_owned_entry161+0xad>
    69ec:	8b 79 18             	mov    0x18(%rcx),%edi
    69ef:	0f b7 c0             	movzwl %ax,%eax
    69f2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    69f5:	48 0f af c7          	imul   %rdi,%rax
    69f9:	48 c1 e8 20          	shr    $0x20,%rax
    69fd:	48 39 c8             	cmp    %rcx,%rax
    6a00:	73 0b                	jae    6a0d <fwp_owned_entry161+0xad>
    6a02:	48 01 c2             	add    %rax,%rdx
    6a05:	80 3a ff             	cmpb   $0xff,(%rdx)
    6a08:	74 26                	je     6a30 <fwp_owned_entry161+0xd0>
    6a0a:	c6 02 01             	movb   $0x1,(%rdx)
    6a0d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6a12:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6a19:	00 00 
    6a1b:	75 34                	jne    6a51 <fwp_owned_entry161+0xf1>
    6a1d:	48 89 f0             	mov    %rsi,%rax
    6a20:	48 83 c4 38          	add    $0x38,%rsp
    6a24:	c3                   	ret
    6a25:	0f 1f 00             	nopl   (%rax)
    6a28:	66 85 c0             	test   %ax,%ax
    6a2b:	75 e0                	jne    6a0d <fwp_owned_entry161+0xad>
    6a2d:	eb d6                	jmp    6a05 <fwp_owned_entry161+0xa5>
    6a2f:	90                   	nop
    6a30:	48 89 d7             	mov    %rdx,%rdi
    6a33:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6a38:	48 89 14 24          	mov    %rdx,(%rsp)
    6a3c:	e8 6f eb ff ff       	call   55b0 <fwp_rc_forget_slot>
    6a41:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6a46:	48 8b 14 24          	mov    (%rsp),%rdx
    6a4a:	eb be                	jmp    6a0a <fwp_owned_entry161+0xaa>
    6a4c:	e8 af cc ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6a51:	e8 0a ca ff ff       	call   3460 <__stack_chk_fail@plt>
    6a56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a5d:	00 00 00 

0000000000006a60 <e161>:
    6a60:	f3 0f 1e fa          	endbr64
    6a64:	53                   	push   %rbx
    6a65:	48 83 ec 30          	sub    $0x30,%rsp
    6a69:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6a6e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6a75:	00 00 
    6a77:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6a7c:	31 c0                	xor    %eax,%eax
    6a7e:	48 8b 07             	mov    (%rdi),%rax
    6a81:	48 03 47 10          	add    0x10(%rdi),%rax
    6a85:	0f 80 c9 00 00 00    	jo     6b54 <e161+0xf4>
    6a8b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6a90:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6a95:	31 ff                	xor    %edi,%edi
    6a97:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6a9b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6aa0:	e8 4b fb ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    6aa5:	48 8b 15 2c e1 01 00 	mov    0x1e12c(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    6aac:	48 89 c3             	mov    %rax,%rbx
    6aaf:	48 2b 05 fa e0 01 00 	sub    0x1e0fa(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    6ab6:	48 c1 e2 10          	shl    $0x10,%rdx
    6aba:	48 39 d0             	cmp    %rdx,%rax
    6abd:	73 4f                	jae    6b0e <e161+0xae>
    6abf:	48 89 c2             	mov    %rax,%rdx
    6ac2:	48 c1 ea 10          	shr    $0x10,%rdx
    6ac6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6aca:	48 8b 15 27 e1 01 00 	mov    0x1e127(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    6ad1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ad5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ad9:	48 85 d2             	test   %rdx,%rdx
    6adc:	74 30                	je     6b0e <e161+0xae>
    6ade:	0f b6 31             	movzbl (%rcx),%esi
    6ae1:	40 80 fe 02          	cmp    $0x2,%sil
    6ae5:	74 49                	je     6b30 <e161+0xd0>
    6ae7:	40 80 fe 01          	cmp    $0x1,%sil
    6aeb:	75 21                	jne    6b0e <e161+0xae>
    6aed:	8b 71 18             	mov    0x18(%rcx),%esi
    6af0:	0f b7 c0             	movzwl %ax,%eax
    6af3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6af6:	48 0f af c6          	imul   %rsi,%rax
    6afa:	48 c1 e8 20          	shr    $0x20,%rax
    6afe:	48 39 c8             	cmp    %rcx,%rax
    6b01:	73 0b                	jae    6b0e <e161+0xae>
    6b03:	48 01 c2             	add    %rax,%rdx
    6b06:	80 3a ff             	cmpb   $0xff,(%rdx)
    6b09:	74 35                	je     6b40 <e161+0xe0>
    6b0b:	c6 02 01             	movb   $0x1,(%rdx)
    6b0e:	48 89 df             	mov    %rbx,%rdi
    6b11:	e8 0a fc ff ff       	call   6720 <fwp_rc_share>
    6b16:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6b1b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6b22:	00 00 
    6b24:	75 33                	jne    6b59 <e161+0xf9>
    6b26:	48 83 c4 30          	add    $0x30,%rsp
    6b2a:	48 89 d8             	mov    %rbx,%rax
    6b2d:	5b                   	pop    %rbx
    6b2e:	c3                   	ret
    6b2f:	90                   	nop
    6b30:	66 85 c0             	test   %ax,%ax
    6b33:	75 d9                	jne    6b0e <e161+0xae>
    6b35:	eb cf                	jmp    6b06 <e161+0xa6>
    6b37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6b3e:	00 00 
    6b40:	48 89 d7             	mov    %rdx,%rdi
    6b43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6b48:	e8 63 ea ff ff       	call   55b0 <fwp_rc_forget_slot>
    6b4d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6b52:	eb b7                	jmp    6b0b <e161+0xab>
    6b54:	e8 a7 cb ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6b59:	e8 02 c9 ff ff       	call   3460 <__stack_chk_fail@plt>
    6b5e:	66 90                	xchg   %ax,%ax

0000000000006b60 <fwp_drop0>:
    6b60:	f3 0f 1e fa          	endbr64
    6b64:	48 8b 15 6d e0 01 00 	mov    0x1e06d(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    6b6b:	48 89 f8             	mov    %rdi,%rax
    6b6e:	48 2b 05 3b e0 01 00 	sub    0x1e03b(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    6b75:	48 c1 e2 10          	shl    $0x10,%rdx
    6b79:	48 39 d0             	cmp    %rdx,%rax
    6b7c:	0f 83 be 00 00 00    	jae    6c40 <fwp_drop0+0xe0>
    6b82:	48 83 ec 18          	sub    $0x18,%rsp
    6b86:	4c 8d 05 73 cc 01 00 	lea    0x1cc73(%rip),%r8        # 23800 <fwp_heap>
    6b8d:	48 89 c2             	mov    %rax,%rdx
    6b90:	48 c1 ea 10          	shr    $0x10,%rdx
    6b94:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b98:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6b9f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ba3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ba7:	48 85 d2             	test   %rdx,%rdx
    6baa:	74 3c                	je     6be8 <fwp_drop0+0x88>
    6bac:	0f b6 31             	movzbl (%rcx),%esi
    6baf:	40 80 fe 02          	cmp    $0x2,%sil
    6bb3:	74 3b                	je     6bf0 <fwp_drop0+0x90>
    6bb5:	40 80 fe 01          	cmp    $0x1,%sil
    6bb9:	75 2d                	jne    6be8 <fwp_drop0+0x88>
    6bbb:	8b 71 18             	mov    0x18(%rcx),%esi
    6bbe:	0f b7 c0             	movzwl %ax,%eax
    6bc1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6bc4:	48 0f af c6          	imul   %rsi,%rax
    6bc8:	48 c1 e8 20          	shr    $0x20,%rax
    6bcc:	48 39 c8             	cmp    %rcx,%rax
    6bcf:	73 17                	jae    6be8 <fwp_drop0+0x88>
    6bd1:	48 01 c2             	add    %rax,%rdx
    6bd4:	0f b6 02             	movzbl (%rdx),%eax
    6bd7:	84 c0                	test   %al,%al
    6bd9:	74 0d                	je     6be8 <fwp_drop0+0x88>
    6bdb:	3c 01                	cmp    $0x1,%al
    6bdd:	74 21                	je     6c00 <fwp_drop0+0xa0>
    6bdf:	3c ff                	cmp    $0xff,%al
    6be1:	74 65                	je     6c48 <fwp_drop0+0xe8>
    6be3:	83 e8 01             	sub    $0x1,%eax
    6be6:	88 02                	mov    %al,(%rdx)
    6be8:	48 83 c4 18          	add    $0x18,%rsp
    6bec:	c3                   	ret
    6bed:	0f 1f 00             	nopl   (%rax)
    6bf0:	66 85 c0             	test   %ax,%ax
    6bf3:	74 df                	je     6bd4 <fwp_drop0+0x74>
    6bf5:	48 83 c4 18          	add    $0x18,%rsp
    6bf9:	c3                   	ret
    6bfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c00:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6c04:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6c09:	e8 42 fc ff ff       	call   6850 <fwp_rc_free_arr>
    6c0e:	4c 8d 05 eb cb 01 00 	lea    0x1cbeb(%rip),%r8        # 23800 <fwp_heap>
    6c15:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6c1a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6c21:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6c28:	48 c1 e2 10          	shl    $0x10,%rdx
    6c2c:	48 39 d0             	cmp    %rdx,%rax
    6c2f:	73 b7                	jae    6be8 <fwp_drop0+0x88>
    6c31:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6c36:	e9 52 ff ff ff       	jmp    6b8d <fwp_drop0+0x2d>
    6c3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6c40:	c3                   	ret
    6c41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c48:	48 89 d0             	mov    %rdx,%rax
    6c4b:	48 c1 e8 11          	shr    $0x11,%rax
    6c4f:	48 31 d0             	xor    %rdx,%rax
    6c52:	48 89 c1             	mov    %rax,%rcx
    6c55:	48 c1 e9 09          	shr    $0x9,%rcx
    6c59:	48 31 c8             	xor    %rcx,%rax
    6c5c:	0f b6 c8             	movzbl %al,%ecx
    6c5f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6c66:	00 
    6c67:	48 85 c0             	test   %rax,%rax
    6c6a:	75 1d                	jne    6c89 <fwp_drop0+0x129>
    6c6c:	eb 56                	jmp    6cc4 <fwp_drop0+0x164>
    6c6e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6c7c:	00 00 00 00 
    6c80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6c84:	48 85 c0             	test   %rax,%rax
    6c87:	74 3b                	je     6cc4 <fwp_drop0+0x164>
    6c89:	48 89 c1             	mov    %rax,%rcx
    6c8c:	48 39 10             	cmp    %rdx,(%rax)
    6c8f:	75 ef                	jne    6c80 <fwp_drop0+0x120>
    6c91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6c95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6c99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6c9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6ca4:	0f 85 3e ff ff ff    	jne    6be8 <fwp_drop0+0x88>
    6caa:	48 89 d7             	mov    %rdx,%rdi
    6cad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6cb2:	e8 f9 e8 ff ff       	call   55b0 <fwp_rc_forget_slot>
    6cb7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6cbc:	c6 02 fe             	movb   $0xfe,(%rdx)
    6cbf:	e9 24 ff ff ff       	jmp    6be8 <fwp_drop0+0x88>
    6cc4:	48 8d 3d bd 8b 00 00 	lea    0x8bbd(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    6ccb:	e8 20 d7 ff ff       	call   43f0 <fwp_trap>

0000000000006cd0 <fwp_arg_drop12>:
    6cd0:	f3 0f 1e fa          	endbr64
    6cd4:	85 f6                	test   %esi,%esi
    6cd6:	75 04                	jne    6cdc <fwp_arg_drop12+0xc>
    6cd8:	85 d2                	test   %edx,%edx
    6cda:	75 04                	jne    6ce0 <fwp_arg_drop12+0x10>
    6cdc:	c3                   	ret
    6cdd:	0f 1f 00             	nopl   (%rax)
    6ce0:	48 8b 3f             	mov    (%rdi),%rdi
    6ce3:	e9 78 fe ff ff       	jmp    6b60 <fwp_drop0>
    6ce8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6cef:	00 

0000000000006cf0 <fwp_drop1>:
    6cf0:	f3 0f 1e fa          	endbr64
    6cf4:	48 8b 15 dd de 01 00 	mov    0x1dedd(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    6cfb:	48 89 f8             	mov    %rdi,%rax
    6cfe:	48 2b 05 ab de 01 00 	sub    0x1deab(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    6d05:	48 c1 e2 10          	shl    $0x10,%rdx
    6d09:	48 39 d0             	cmp    %rdx,%rax
    6d0c:	0f 83 be 00 00 00    	jae    6dd0 <fwp_drop1+0xe0>
    6d12:	48 83 ec 18          	sub    $0x18,%rsp
    6d16:	4c 8d 05 e3 ca 01 00 	lea    0x1cae3(%rip),%r8        # 23800 <fwp_heap>
    6d1d:	48 89 c2             	mov    %rax,%rdx
    6d20:	48 c1 ea 10          	shr    $0x10,%rdx
    6d24:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d28:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6d2f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6d33:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d37:	48 85 d2             	test   %rdx,%rdx
    6d3a:	74 3c                	je     6d78 <fwp_drop1+0x88>
    6d3c:	0f b6 31             	movzbl (%rcx),%esi
    6d3f:	40 80 fe 02          	cmp    $0x2,%sil
    6d43:	74 3b                	je     6d80 <fwp_drop1+0x90>
    6d45:	40 80 fe 01          	cmp    $0x1,%sil
    6d49:	75 2d                	jne    6d78 <fwp_drop1+0x88>
    6d4b:	8b 71 18             	mov    0x18(%rcx),%esi
    6d4e:	0f b7 c0             	movzwl %ax,%eax
    6d51:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6d54:	48 0f af c6          	imul   %rsi,%rax
    6d58:	48 c1 e8 20          	shr    $0x20,%rax
    6d5c:	48 39 c8             	cmp    %rcx,%rax
    6d5f:	73 17                	jae    6d78 <fwp_drop1+0x88>
    6d61:	48 01 c2             	add    %rax,%rdx
    6d64:	0f b6 02             	movzbl (%rdx),%eax
    6d67:	84 c0                	test   %al,%al
    6d69:	74 0d                	je     6d78 <fwp_drop1+0x88>
    6d6b:	3c 01                	cmp    $0x1,%al
    6d6d:	74 21                	je     6d90 <fwp_drop1+0xa0>
    6d6f:	3c ff                	cmp    $0xff,%al
    6d71:	74 65                	je     6dd8 <fwp_drop1+0xe8>
    6d73:	83 e8 01             	sub    $0x1,%eax
    6d76:	88 02                	mov    %al,(%rdx)
    6d78:	48 83 c4 18          	add    $0x18,%rsp
    6d7c:	c3                   	ret
    6d7d:	0f 1f 00             	nopl   (%rax)
    6d80:	66 85 c0             	test   %ax,%ax
    6d83:	74 df                	je     6d64 <fwp_drop1+0x74>
    6d85:	48 83 c4 18          	add    $0x18,%rsp
    6d89:	c3                   	ret
    6d8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d90:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6d94:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6d99:	e8 b2 fa ff ff       	call   6850 <fwp_rc_free_arr>
    6d9e:	4c 8d 05 5b ca 01 00 	lea    0x1ca5b(%rip),%r8        # 23800 <fwp_heap>
    6da5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6daa:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6db1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6db8:	48 c1 e2 10          	shl    $0x10,%rdx
    6dbc:	48 39 d0             	cmp    %rdx,%rax
    6dbf:	73 b7                	jae    6d78 <fwp_drop1+0x88>
    6dc1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6dc6:	e9 52 ff ff ff       	jmp    6d1d <fwp_drop1+0x2d>
    6dcb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6dd0:	c3                   	ret
    6dd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6dd8:	48 89 d0             	mov    %rdx,%rax
    6ddb:	48 c1 e8 11          	shr    $0x11,%rax
    6ddf:	48 31 d0             	xor    %rdx,%rax
    6de2:	48 89 c1             	mov    %rax,%rcx
    6de5:	48 c1 e9 09          	shr    $0x9,%rcx
    6de9:	48 31 c8             	xor    %rcx,%rax
    6dec:	0f b6 c8             	movzbl %al,%ecx
    6def:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6df6:	00 
    6df7:	48 85 c0             	test   %rax,%rax
    6dfa:	75 0d                	jne    6e09 <fwp_drop1+0x119>
    6dfc:	eb 46                	jmp    6e44 <fwp_drop1+0x154>
    6dfe:	66 90                	xchg   %ax,%ax
    6e00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6e04:	48 85 c0             	test   %rax,%rax
    6e07:	74 3b                	je     6e44 <fwp_drop1+0x154>
    6e09:	48 89 c1             	mov    %rax,%rcx
    6e0c:	48 39 10             	cmp    %rdx,(%rax)
    6e0f:	75 ef                	jne    6e00 <fwp_drop1+0x110>
    6e11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6e15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6e19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6e1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6e24:	0f 85 4e ff ff ff    	jne    6d78 <fwp_drop1+0x88>
    6e2a:	48 89 d7             	mov    %rdx,%rdi
    6e2d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6e32:	e8 79 e7 ff ff       	call   55b0 <fwp_rc_forget_slot>
    6e37:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6e3c:	c6 02 fe             	movb   $0xfe,(%rdx)
    6e3f:	e9 34 ff ff ff       	jmp    6d78 <fwp_drop1+0x88>
    6e44:	48 8d 3d 3d 8a 00 00 	lea    0x8a3d(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    6e4b:	e8 a0 d5 ff ff       	call   43f0 <fwp_trap>

0000000000006e50 <fwp_closure_drop>:
    6e50:	48 8b 15 81 dd 01 00 	mov    0x1dd81(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    6e57:	48 89 f8             	mov    %rdi,%rax
    6e5a:	48 2b 05 4f dd 01 00 	sub    0x1dd4f(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    6e61:	48 c1 e2 10          	shl    $0x10,%rdx
    6e65:	48 39 d0             	cmp    %rdx,%rax
    6e68:	73 6b                	jae    6ed5 <fwp_closure_drop+0x85>
    6e6a:	48 89 c2             	mov    %rax,%rdx
    6e6d:	48 c1 ea 10          	shr    $0x10,%rdx
    6e71:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6e75:	48 8b 15 7c dd 01 00 	mov    0x1dd7c(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    6e7c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6e80:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6e84:	48 85 d2             	test   %rdx,%rdx
    6e87:	74 4c                	je     6ed5 <fwp_closure_drop+0x85>
    6e89:	0f b6 31             	movzbl (%rcx),%esi
    6e8c:	40 80 fe 02          	cmp    $0x2,%sil
    6e90:	74 3e                	je     6ed0 <fwp_closure_drop+0x80>
    6e92:	40 80 fe 01          	cmp    $0x1,%sil
    6e96:	75 3d                	jne    6ed5 <fwp_closure_drop+0x85>
    6e98:	8b 71 18             	mov    0x18(%rcx),%esi
    6e9b:	0f b7 c0             	movzwl %ax,%eax
    6e9e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ea1:	48 0f af c6          	imul   %rsi,%rax
    6ea5:	48 c1 e8 20          	shr    $0x20,%rax
    6ea9:	48 39 c8             	cmp    %rcx,%rax
    6eac:	73 27                	jae    6ed5 <fwp_closure_drop+0x85>
    6eae:	48 01 c2             	add    %rax,%rdx
    6eb1:	0f b6 02             	movzbl (%rdx),%eax
    6eb4:	84 c0                	test   %al,%al
    6eb6:	74 1d                	je     6ed5 <fwp_closure_drop+0x85>
    6eb8:	3c 01                	cmp    $0x1,%al
    6eba:	74 24                	je     6ee0 <fwp_closure_drop+0x90>
    6ebc:	3c ff                	cmp    $0xff,%al
    6ebe:	74 48                	je     6f08 <fwp_closure_drop+0xb8>
    6ec0:	83 e8 01             	sub    $0x1,%eax
    6ec3:	88 02                	mov    %al,(%rdx)
    6ec5:	c3                   	ret
    6ec6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6ecd:	00 00 00 
    6ed0:	66 85 c0             	test   %ax,%ax
    6ed3:	74 dc                	je     6eb1 <fwp_closure_drop+0x61>
    6ed5:	c3                   	ret
    6ed6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6edd:	00 00 00 
    6ee0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6ee7:	ff ff 
    6ee9:	48 85 c0             	test   %rax,%rax
    6eec:	74 12                	je     6f00 <fwp_closure_drop+0xb0>
    6eee:	48 89 fe             	mov    %rdi,%rsi
    6ef1:	48 89 c7             	mov    %rax,%rdi
    6ef4:	e9 57 d5 ff ff       	jmp    4450 <fwp_closure_drop_push>
    6ef9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f00:	e9 fb d6 ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    6f05:	0f 1f 00             	nopl   (%rax)
    6f08:	48 89 d0             	mov    %rdx,%rax
    6f0b:	48 8d 35 ee c8 01 00 	lea    0x1c8ee(%rip),%rsi        # 23800 <fwp_heap>
    6f12:	48 83 ec 18          	sub    $0x18,%rsp
    6f16:	48 c1 e8 11          	shr    $0x11,%rax
    6f1a:	48 31 d0             	xor    %rdx,%rax
    6f1d:	48 89 c1             	mov    %rax,%rcx
    6f20:	48 c1 e9 09          	shr    $0x9,%rcx
    6f24:	48 31 c8             	xor    %rcx,%rax
    6f27:	0f b6 c8             	movzbl %al,%ecx
    6f2a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6f31:	00 
    6f32:	48 85 c0             	test   %rax,%rax
    6f35:	75 12                	jne    6f49 <fwp_closure_drop+0xf9>
    6f37:	eb 49                	jmp    6f82 <fwp_closure_drop+0x132>
    6f39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6f44:	48 85 c0             	test   %rax,%rax
    6f47:	74 39                	je     6f82 <fwp_closure_drop+0x132>
    6f49:	48 89 c1             	mov    %rax,%rcx
    6f4c:	48 39 10             	cmp    %rdx,(%rax)
    6f4f:	75 ef                	jne    6f40 <fwp_closure_drop+0xf0>
    6f51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6f55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6f59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6f5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6f64:	74 05                	je     6f6b <fwp_closure_drop+0x11b>
    6f66:	48 83 c4 18          	add    $0x18,%rsp
    6f6a:	c3                   	ret
    6f6b:	48 89 d7             	mov    %rdx,%rdi
    6f6e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6f73:	e8 38 e6 ff ff       	call   55b0 <fwp_rc_forget_slot>
    6f78:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6f7d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6f80:	eb e4                	jmp    6f66 <fwp_closure_drop+0x116>
    6f82:	48 8d 3d ff 88 00 00 	lea    0x88ff(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    6f89:	e8 62 d4 ff ff       	call   43f0 <fwp_trap>
    6f8e:	66 90                	xchg   %ax,%ax

0000000000006f90 <fwp_owned_tape_release>:
    6f90:	48 85 ff             	test   %rdi,%rdi
    6f93:	0f 84 f7 00 00 00    	je     7090 <fwp_owned_tape_release+0x100>
    6f99:	41 54                	push   %r12
    6f9b:	55                   	push   %rbp
    6f9c:	53                   	push   %rbx
    6f9d:	48 8b 07             	mov    (%rdi),%rax
    6fa0:	48 85 c0             	test   %rax,%rax
    6fa3:	74 08                	je     6fad <fwp_owned_tape_release+0x1d>
    6fa5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6fa9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6fad:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6fb1:	48 85 d2             	test   %rdx,%rdx
    6fb4:	74 03                	je     6fb9 <fwp_owned_tape_release+0x29>
    6fb6:	48 89 02             	mov    %rax,(%rdx)
    6fb9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6fbd:	48 89 fb             	mov    %rdi,%rbx
    6fc0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6fc4:	48 85 c0             	test   %rax,%rax
    6fc7:	0f 84 89 00 00 00    	je     7056 <fwp_owned_tape_release+0xc6>
    6fcd:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6fd1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6fd5:	7e 47                	jle    701e <fwp_owned_tape_release+0x8e>
    6fd7:	31 ed                	xor    %ebp,%ebp
    6fd9:	eb 0d                	jmp    6fe8 <fwp_owned_tape_release+0x58>
    6fdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6fe0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6fe4:	48 8b 40 68          	mov    0x68(%rax),%rax
    6fe8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6fec:	49 89 ec             	mov    %rbp,%r12
    6fef:	48 83 c5 01          	add    $0x1,%rbp
    6ff3:	49 c1 e4 04          	shl    $0x4,%r12
    6ff7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6ffb:	ff d0                	call   *%rax
    6ffd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    7001:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    7006:	48 8b 43 10          	mov    0x10(%rbx),%rax
    700a:	ff 50 68             	call   *0x68(%rax)
    700d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    7011:	48 2b 43 50          	sub    0x50(%rbx),%rax
    7015:	48 39 e8             	cmp    %rbp,%rax
    7018:	7f c6                	jg     6fe0 <fwp_owned_tape_release+0x50>
    701a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    701e:	31 ed                	xor    %ebp,%ebp
    7020:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    7025:	7e 28                	jle    704f <fwp_owned_tape_release+0xbf>
    7027:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    702e:	00 00 
    7030:	48 8b 43 48          	mov    0x48(%rbx),%rax
    7034:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    7038:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    703c:	74 07                	je     7045 <fwp_owned_tape_release+0xb5>
    703e:	ff 52 68             	call   *0x68(%rdx)
    7041:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    7045:	48 83 c5 01          	add    $0x1,%rbp
    7049:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    704d:	7f e1                	jg     7030 <fwp_owned_tape_release+0xa0>
    704f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7053:	ff 52 68             	call   *0x68(%rdx)
    7056:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    705a:	e8 f1 fd ff ff       	call   6e50 <fwp_closure_drop>
    705f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    7063:	e8 e8 fd ff ff       	call   6e50 <fwp_closure_drop>
    7068:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    706c:	e8 df fd ff ff       	call   6e50 <fwp_closure_drop>
    7071:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    7075:	e8 76 e7 ff ff       	call   57f0 <fwp_mem_free>
    707a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    707e:	e8 6d e7 ff ff       	call   57f0 <fwp_mem_free>
    7083:	48 89 df             	mov    %rbx,%rdi
    7086:	5b                   	pop    %rbx
    7087:	5d                   	pop    %rbp
    7088:	41 5c                	pop    %r12
    708a:	e9 61 e7 ff ff       	jmp    57f0 <fwp_mem_free>
    708f:	90                   	nop
    7090:	c3                   	ret
    7091:	0f 1f 40 00          	nopl   0x0(%rax)
    7095:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    709c:	00 00 00 00 

00000000000070a0 <fwp_tape_finish>:
    70a0:	f3 0f 1e fa          	endbr64
    70a4:	41 56                	push   %r14
    70a6:	48 8d 3d 33 c0 01 00 	lea    0x1c033(%rip),%rdi        # 230e0 <fwp_tape_workspace>
    70ad:	41 55                	push   %r13
    70af:	41 54                	push   %r12
    70b1:	55                   	push   %rbp
    70b2:	53                   	push   %rbx
    70b3:	e8 58 d0 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    70b8:	48 83 3d 68 c0 01 00 	cmpq   $0x0,0x1c068(%rip)        # 23128 <fwp_ntapes>
    70bf:	00 
    70c0:	48 c7 05 fd bf 01 00 	movq   $0x0,0x1bffd(%rip)        # 230c8 <fwp_tape_cached_bytes>
    70c7:	00 00 00 00 
    70cb:	7e 68                	jle    7135 <fwp_tape_finish+0x95>
    70cd:	45 31 e4             	xor    %r12d,%r12d
    70d0:	31 ed                	xor    %ebp,%ebp
    70d2:	0f 1f 00             	nopl   (%rax)
    70d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    70dc:	00 00 00 00 
    70e0:	48 8b 1d 49 c0 01 00 	mov    0x1c049(%rip),%rbx        # 23130 <fwp_tapes>
    70e7:	48 83 c5 01          	add    $0x1,%rbp
    70eb:	4c 01 e3             	add    %r12,%rbx
    70ee:	49 83 c4 68          	add    $0x68,%r12
    70f2:	48 89 df             	mov    %rbx,%rdi
    70f5:	e8 06 cb ff ff       	call   3c00 <fwp_tape_unlink_scope>
    70fa:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    70fe:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7102:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    7106:	e8 b5 c2 ff ff       	call   33c0 <free@plt>
    710b:	4c 89 f7             	mov    %r14,%rdi
    710e:	e8 ad c2 ff ff       	call   33c0 <free@plt>
    7113:	4c 89 ef             	mov    %r13,%rdi
    7116:	e8 a5 c2 ff ff       	call   33c0 <free@plt>
    711b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    711f:	e8 6c fe ff ff       	call   6f90 <fwp_owned_tape_release>
    7124:	48 39 2d fd bf 01 00 	cmp    %rbp,0x1bffd(%rip)        # 23128 <fwp_ntapes>
    712b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    7132:	00 
    7133:	7f ab                	jg     70e0 <fwp_tape_finish+0x40>
    7135:	48 8b 3d f4 bf 01 00 	mov    0x1bff4(%rip),%rdi        # 23130 <fwp_tapes>
    713c:	e8 7f c2 ff ff       	call   33c0 <free@plt>
    7141:	5b                   	pop    %rbx
    7142:	5d                   	pop    %rbp
    7143:	48 c7 05 e2 bf 01 00 	movq   $0x0,0x1bfe2(%rip)        # 23130 <fwp_tapes>
    714a:	00 00 00 00 
    714e:	48 c7 05 c7 bf 01 00 	movq   $0x0,0x1bfc7(%rip)        # 23120 <fwp_tapes_cap>
    7155:	00 00 00 00 
    7159:	41 5c                	pop    %r12
    715b:	48 c7 05 c2 bf 01 00 	movq   $0x0,0x1bfc2(%rip)        # 23128 <fwp_ntapes>
    7162:	00 00 00 00 
    7166:	41 5d                	pop    %r13
    7168:	48 c7 05 a5 bf 01 00 	movq   $0x0,0x1bfa5(%rip)        # 23118 <fwp_tape_next_slot>
    716f:	00 00 00 00 
    7173:	41 5e                	pop    %r14
    7175:	c3                   	ret
    7176:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    717d:	00 00 00 

0000000000007180 <fwp_tape_scope_release>:
    7180:	f3 0f 1e fa          	endbr64
    7184:	41 55                	push   %r13
    7186:	41 54                	push   %r12
    7188:	55                   	push   %rbp
    7189:	53                   	push   %rbx
    718a:	48 83 ec 58          	sub    $0x58,%rsp
    718e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7195:	00 00 
    7197:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    719c:	48 63 07             	movslq (%rdi),%rax
    719f:	85 c0                	test   %eax,%eax
    71a1:	0f 88 05 01 00 00    	js     72ac <fwp_tape_scope_release+0x12c>
    71a7:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    71ae:	ec c4 4e 
    71b1:	48 89 fb             	mov    %rdi,%rbx
    71b4:	eb 3c                	jmp    71f2 <fwp_tape_scope_release+0x72>
    71b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    71bd:	00 00 00 
    71c0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    71c5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    71c9:	e8 f2 c1 ff ff       	call   33c0 <free@plt>
    71ce:	48 8b 3c 24          	mov    (%rsp),%rdi
    71d2:	e8 e9 c1 ff ff       	call   33c0 <free@plt>
    71d7:	4c 89 ef             	mov    %r13,%rdi
    71da:	e8 e1 c1 ff ff       	call   33c0 <free@plt>
    71df:	4c 89 e7             	mov    %r12,%rdi
    71e2:	e8 a9 fd ff ff       	call   6f90 <fwp_owned_tape_release>
    71e7:	48 63 03             	movslq (%rbx),%rax
    71ea:	85 c0                	test   %eax,%eax
    71ec:	0f 88 ba 00 00 00    	js     72ac <fwp_tape_scope_release+0x12c>
    71f2:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    71f6:	48 8b 35 33 bf 01 00 	mov    0x1bf33(%rip),%rsi        # 23130 <fwp_tapes>
    71fd:	4c 01 c6             	add    %r8,%rsi
    7200:	48 89 f7             	mov    %rsi,%rdi
    7203:	e8 f8 c9 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    7208:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    720d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7212:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    7219:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    721d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    7221:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    7228:	00 
    7229:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    722e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    7232:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    7237:	66 0f ef d2          	pxor   %xmm2,%xmm2
    723b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    7240:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7247:	00 
    7248:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    724f:	00 
    7250:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7257:	00 
    7258:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    725d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    7262:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    7266:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    726a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    726e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7274:	77 18                	ja     728e <fwp_tape_scope_release+0x10e>
    7276:	49 c1 f8 03          	sar    $0x3,%r8
    727a:	4c 0f af c5          	imul   %rbp,%r8
    727e:	4c 3b 05 93 be 01 00 	cmp    0x1be93(%rip),%r8        # 23118 <fwp_tape_next_slot>
    7285:	7d 07                	jge    728e <fwp_tape_scope_release+0x10e>
    7287:	4c 89 05 8a be 01 00 	mov    %r8,0x1be8a(%rip)        # 23118 <fwp_tape_next_slot>
    728e:	4d 85 e4             	test   %r12,%r12
    7291:	0f 85 29 ff ff ff    	jne    71c0 <fwp_tape_scope_release+0x40>
    7297:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    729c:	e8 2f de ff ff       	call   50d0 <fwp_tape_buffers_release>
    72a1:	48 63 03             	movslq (%rbx),%rax
    72a4:	85 c0                	test   %eax,%eax
    72a6:	0f 89 46 ff ff ff    	jns    71f2 <fwp_tape_scope_release+0x72>
    72ac:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    72b1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    72b8:	00 00 
    72ba:	75 0b                	jne    72c7 <fwp_tape_scope_release+0x147>
    72bc:	48 83 c4 58          	add    $0x58,%rsp
    72c0:	5b                   	pop    %rbx
    72c1:	5d                   	pop    %rbp
    72c2:	41 5c                	pop    %r12
    72c4:	41 5d                	pop    %r13
    72c6:	c3                   	ret
    72c7:	e8 94 c1 ff ff       	call   3460 <__stack_chk_fail@plt>
    72cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000072d0 <fwp_task_dispose>:
    72d0:	53                   	push   %rbx
    72d1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    72d5:	0f 84 6b c4 ff ff    	je     3746 <fwp_task_dispose.cold>
    72db:	48 89 fb             	mov    %rdi,%rbx
    72de:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    72e3:	0f 85 5d c4 ff ff    	jne    3746 <fwp_task_dispose.cold>
    72e9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    72ed:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    72f4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    72fb:	00 
    72fc:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7300:	48 85 ff             	test   %rdi,%rdi
    7303:	74 07                	je     730c <fwp_task_dispose+0x3c>
    7305:	48 85 c0             	test   %rax,%rax
    7308:	74 02                	je     730c <fwp_task_dispose+0x3c>
    730a:	ff d0                	call   *%rax
    730c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7313:	e8 d8 e4 ff ff       	call   57f0 <fwp_mem_free>
    7318:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    731f:	00 00 00 00 
    7323:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7327:	74 6f                	je     7398 <fwp_task_dispose+0xc8>
    7329:	48 8b 15 a8 d8 01 00 	mov    0x1d8a8(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    7330:	48 89 d8             	mov    %rbx,%rax
    7333:	48 2b 05 76 d8 01 00 	sub    0x1d876(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    733a:	48 c1 e2 10          	shl    $0x10,%rdx
    733e:	48 39 d0             	cmp    %rdx,%rax
    7341:	73 4c                	jae    738f <fwp_task_dispose+0xbf>
    7343:	48 89 c2             	mov    %rax,%rdx
    7346:	48 c1 ea 10          	shr    $0x10,%rdx
    734a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    734e:	48 8b 15 a3 d8 01 00 	mov    0x1d8a3(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    7355:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7359:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    735d:	48 85 c9             	test   %rcx,%rcx
    7360:	74 2d                	je     738f <fwp_task_dispose+0xbf>
    7362:	0f b6 32             	movzbl (%rdx),%esi
    7365:	40 80 fe 02          	cmp    $0x2,%sil
    7369:	74 3d                	je     73a8 <fwp_task_dispose+0xd8>
    736b:	40 80 fe 01          	cmp    $0x1,%sil
    736f:	75 1e                	jne    738f <fwp_task_dispose+0xbf>
    7371:	8b 72 18             	mov    0x18(%rdx),%esi
    7374:	0f b7 c0             	movzwl %ax,%eax
    7377:	8b 52 1c             	mov    0x1c(%rdx),%edx
    737a:	48 0f af c6          	imul   %rsi,%rax
    737e:	48 c1 e8 20          	shr    $0x20,%rax
    7382:	48 39 d0             	cmp    %rdx,%rax
    7385:	73 08                	jae    738f <fwp_task_dispose+0xbf>
    7387:	48 01 c1             	add    %rax,%rcx
    738a:	80 39 01             	cmpb   $0x1,(%rcx)
    738d:	74 09                	je     7398 <fwp_task_dispose+0xc8>
    738f:	5b                   	pop    %rbx
    7390:	c3                   	ret
    7391:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7398:	48 89 df             	mov    %rbx,%rdi
    739b:	5b                   	pop    %rbx
    739c:	e9 4f e4 ff ff       	jmp    57f0 <fwp_mem_free>
    73a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    73a8:	66 85 c0             	test   %ax,%ax
    73ab:	74 dd                	je     738a <fwp_task_dispose+0xba>
    73ad:	5b                   	pop    %rbx
    73ae:	c3                   	ret
    73af:	90                   	nop

00000000000073b0 <fwp_free_zombie>:
    73b0:	48 8b 15 19 c4 01 00 	mov    0x1c419(%rip),%rdx        # 237d0 <fwp_zombie>
    73b7:	48 85 d2             	test   %rdx,%rdx
    73ba:	0f 84 98 00 00 00    	je     7458 <fwp_free_zombie+0xa8>
    73c0:	48 3b 15 19 c4 01 00 	cmp    0x1c419(%rip),%rdx        # 237e0 <fwp_cur>
    73c7:	0f 84 8b 00 00 00    	je     7458 <fwp_free_zombie+0xa8>
    73cd:	48 83 ec 18          	sub    $0x18,%rsp
    73d1:	48 63 05 cc bd 01 00 	movslq 0x1bdcc(%rip),%rax        # 231a4 <fwp_stack_pool_n>
    73d8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    73dc:	83 f8 3f             	cmp    $0x3f,%eax
    73df:	7f 7f                	jg     7460 <fwp_free_zombie+0xb0>
    73e1:	8d 48 01             	lea    0x1(%rax),%ecx
    73e4:	89 0d ba bd 01 00    	mov    %ecx,0x1bdba(%rip)        # 231a4 <fwp_stack_pool_n>
    73ea:	48 8d 0d cf bd 01 00 	lea    0x1bdcf(%rip),%rcx        # 231c0 <fwp_stack_pool>
    73f1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    73f5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    73fc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7400:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7407:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    740b:	48 85 c9             	test   %rcx,%rcx
    740e:	0f 84 fc 00 00 00    	je     7510 <fwp_free_zombie+0x160>
    7414:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    741b:	48 85 c0             	test   %rax,%rax
    741e:	74 07                	je     7427 <fwp_free_zombie+0x77>
    7420:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7427:	8b 42 5c             	mov    0x5c(%rdx),%eax
    742a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    742e:	48 c7 05 97 c3 01 00 	movq   $0x0,0x1c397(%rip)        # 237d0 <fwp_zombie>
    7435:	00 00 00 00 
    7439:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7440:	85 c0                	test   %eax,%eax
    7442:	74 34                	je     7478 <fwp_free_zombie+0xc8>
    7444:	83 f8 01             	cmp    $0x1,%eax
    7447:	0f 84 b3 00 00 00    	je     7500 <fwp_free_zombie+0x150>
    744d:	48 83 c4 18          	add    $0x18,%rsp
    7451:	c3                   	ret
    7452:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7458:	c3                   	ret
    7459:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7460:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7464:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7469:	e8 72 c1 ff ff       	call   35e0 <munmap@plt>
    746e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7473:	eb 80                	jmp    73f5 <fwp_free_zombie+0x45>
    7475:	0f 1f 00             	nopl   (%rax)
    7478:	48 8b 0d 59 d7 01 00 	mov    0x1d759(%rip),%rcx        # 24bd8 <fwp_heap+0x13d8>
    747f:	48 89 d0             	mov    %rdx,%rax
    7482:	48 2b 05 27 d7 01 00 	sub    0x1d727(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    7489:	48 c1 e1 10          	shl    $0x10,%rcx
    748d:	48 39 c8             	cmp    %rcx,%rax
    7490:	73 bb                	jae    744d <fwp_free_zombie+0x9d>
    7492:	48 89 c1             	mov    %rax,%rcx
    7495:	48 c1 e9 10          	shr    $0x10,%rcx
    7499:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    749d:	48 8b 0d 54 d7 01 00 	mov    0x1d754(%rip),%rcx        # 24bf8 <fwp_heap+0x13f8>
    74a4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    74a8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    74ac:	48 85 c9             	test   %rcx,%rcx
    74af:	74 9c                	je     744d <fwp_free_zombie+0x9d>
    74b1:	0f b6 3e             	movzbl (%rsi),%edi
    74b4:	40 80 ff 02          	cmp    $0x2,%dil
    74b8:	74 66                	je     7520 <fwp_free_zombie+0x170>
    74ba:	40 80 ff 01          	cmp    $0x1,%dil
    74be:	75 8d                	jne    744d <fwp_free_zombie+0x9d>
    74c0:	8b 7e 18             	mov    0x18(%rsi),%edi
    74c3:	0f b7 c0             	movzwl %ax,%eax
    74c6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    74c9:	48 0f af c7          	imul   %rdi,%rax
    74cd:	48 c1 e8 20          	shr    $0x20,%rax
    74d1:	48 39 f0             	cmp    %rsi,%rax
    74d4:	0f 83 73 ff ff ff    	jae    744d <fwp_free_zombie+0x9d>
    74da:	48 01 c1             	add    %rax,%rcx
    74dd:	0f b6 01             	movzbl (%rcx),%eax
    74e0:	84 c0                	test   %al,%al
    74e2:	0f 84 65 ff ff ff    	je     744d <fwp_free_zombie+0x9d>
    74e8:	3c 01                	cmp    $0x1,%al
    74ea:	74 14                	je     7500 <fwp_free_zombie+0x150>
    74ec:	3c ff                	cmp    $0xff,%al
    74ee:	74 3b                	je     752b <fwp_free_zombie+0x17b>
    74f0:	83 e8 01             	sub    $0x1,%eax
    74f3:	88 01                	mov    %al,(%rcx)
    74f5:	e9 53 ff ff ff       	jmp    744d <fwp_free_zombie+0x9d>
    74fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7500:	48 89 d7             	mov    %rdx,%rdi
    7503:	48 83 c4 18          	add    $0x18,%rsp
    7507:	e9 c4 fd ff ff       	jmp    72d0 <fwp_task_dispose>
    750c:	0f 1f 40 00          	nopl   0x0(%rax)
    7510:	48 89 05 91 c2 01 00 	mov    %rax,0x1c291(%rip)        # 237a8 <fwp_tasks_active>
    7517:	e9 ff fe ff ff       	jmp    741b <fwp_free_zombie+0x6b>
    751c:	0f 1f 40 00          	nopl   0x0(%rax)
    7520:	66 85 c0             	test   %ax,%ax
    7523:	0f 85 24 ff ff ff    	jne    744d <fwp_free_zombie+0x9d>
    7529:	eb b2                	jmp    74dd <fwp_free_zombie+0x12d>
    752b:	48 89 ca             	mov    %rcx,%rdx
    752e:	48 8d 35 cb c2 01 00 	lea    0x1c2cb(%rip),%rsi        # 23800 <fwp_heap>
    7535:	48 c1 ea 11          	shr    $0x11,%rdx
    7539:	48 31 ca             	xor    %rcx,%rdx
    753c:	48 89 d0             	mov    %rdx,%rax
    753f:	48 c1 e8 09          	shr    $0x9,%rax
    7543:	48 31 c2             	xor    %rax,%rdx
    7546:	0f b6 d2             	movzbl %dl,%edx
    7549:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7550:	00 
    7551:	48 85 c0             	test   %rax,%rax
    7554:	75 13                	jne    7569 <fwp_free_zombie+0x1b9>
    7556:	eb 4c                	jmp    75a4 <fwp_free_zombie+0x1f4>
    7558:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    755f:	00 
    7560:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7564:	48 85 c0             	test   %rax,%rax
    7567:	74 3b                	je     75a4 <fwp_free_zombie+0x1f4>
    7569:	48 89 c2             	mov    %rax,%rdx
    756c:	48 39 08             	cmp    %rcx,(%rax)
    756f:	75 ef                	jne    7560 <fwp_free_zombie+0x1b0>
    7571:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7575:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7579:	48 89 50 08          	mov    %rdx,0x8(%rax)
    757d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7584:	0f 85 c3 fe ff ff    	jne    744d <fwp_free_zombie+0x9d>
    758a:	48 89 cf             	mov    %rcx,%rdi
    758d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7592:	e8 19 e0 ff ff       	call   55b0 <fwp_rc_forget_slot>
    7597:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    759c:	c6 01 fe             	movb   $0xfe,(%rcx)
    759f:	e9 a9 fe ff ff       	jmp    744d <fwp_free_zombie+0x9d>
    75a4:	48 8d 3d dd 82 00 00 	lea    0x82dd(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    75ab:	e8 40 ce ff ff       	call   43f0 <fwp_trap>

00000000000075b0 <fwp_block>:
    75b0:	48 83 ec 08          	sub    $0x8,%rsp
    75b4:	48 8b 05 0d c2 01 00 	mov    0x1c20d(%rip),%rax        # 237c8 <fwp_ready_head>
    75bb:	48 85 c0             	test   %rax,%rax
    75be:	0f 84 1c 01 00 00    	je     76e0 <fwp_block+0x130>
    75c4:	90                   	nop
    75c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    75cc:	00 00 00 00 
    75d0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    75d7:	48 89 15 ea c1 01 00 	mov    %rdx,0x1c1ea(%rip)        # 237c8 <fwp_ready_head>
    75de:	48 85 d2             	test   %rdx,%rdx
    75e1:	0f 84 19 01 00 00    	je     7700 <fwp_block+0x150>
    75e7:	48 8b 15 f2 c1 01 00 	mov    0x1c1f2(%rip),%rdx        # 237e0 <fwp_cur>
    75ee:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    75f2:	48 39 c2             	cmp    %rax,%rdx
    75f5:	0f 84 d5 00 00 00    	je     76d0 <fwp_block+0x120>
    75fb:	48 8b 0d 66 de 01 00 	mov    0x1de66(%rip),%rcx        # 25468 <fwp_state_owners>
    7602:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7606:	48 89 05 d3 c1 01 00 	mov    %rax,0x1c1d3(%rip)        # 237e0 <fwp_cur>
    760d:	f3 0f 7e 05 7b de 01 	movq   0x1de7b(%rip),%xmm0        # 25490 <fwp_foreign_callbacks>
    7614:	00 
    7615:	0f 16 05 64 de 01 00 	movhps 0x1de64(%rip),%xmm0        # 25480 <fwp_state>
    761c:	f3 0f 7e 0d 64 de 01 	movq   0x1de64(%rip),%xmm1        # 25488 <fwp_handlers>
    7623:	00 
    7624:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    762b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7632:	0f 16 0d 5f de 01 00 	movhps 0x1de5f(%rip),%xmm1        # 25498 <fwp_cleanups>
    7639:	f3 0f 7e 05 37 de 01 	movq   0x1de37(%rip),%xmm0        # 25478 <fwp_state_len>
    7640:	00 
    7641:	0f 16 05 28 de 01 00 	movhps 0x1de28(%rip),%xmm0        # 25470 <fwp_state_cap>
    7648:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    764f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7656:	48 8b 70 08          	mov    0x8(%rax),%rsi
    765a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7661:	48 89 0d 20 de 01 00 	mov    %rcx,0x1de20(%rip)        # 25488 <fwp_handlers>
    7668:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    766f:	48 89 0d 22 de 01 00 	mov    %rcx,0x1de22(%rip)        # 25498 <fwp_cleanups>
    7676:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    767d:	48 89 0d 0c de 01 00 	mov    %rcx,0x1de0c(%rip)        # 25490 <fwp_foreign_callbacks>
    7684:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    768b:	48 89 0d ee dd 01 00 	mov    %rcx,0x1ddee(%rip)        # 25480 <fwp_state>
    7692:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7699:	48 89 0d d8 dd 01 00 	mov    %rcx,0x1ddd8(%rip)        # 25478 <fwp_state_len>
    76a0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    76a7:	48 89 0d c2 dd 01 00 	mov    %rcx,0x1ddc2(%rip)        # 25470 <fwp_state_cap>
    76ae:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    76b5:	48 89 0d ac dd 01 00 	mov    %rcx,0x1ddac(%rip)        # 25468 <fwp_state_owners>
    76bc:	e8 cf bd ff ff       	call   3490 <swapcontext@plt>
    76c1:	f3 0f 1e fa          	endbr64
    76c5:	e8 e6 fc ff ff       	call   73b0 <fwp_free_zombie>
    76ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    76d0:	8b 05 ca ba 01 00    	mov    0x1baca(%rip),%eax        # 231a0 <fwp_slice>
    76d6:	85 c0                	test   %eax,%eax
    76d8:	74 36                	je     7710 <fwp_block+0x160>
    76da:	48 83 c4 08          	add    $0x8,%rsp
    76de:	c3                   	ret
    76df:	90                   	nop
    76e0:	e8 1b db ff ff       	call   5200 <fwp_poll_events>
    76e5:	48 8b 05 dc c0 01 00 	mov    0x1c0dc(%rip),%rax        # 237c8 <fwp_ready_head>
    76ec:	48 85 c0             	test   %rax,%rax
    76ef:	0f 85 db fe ff ff    	jne    75d0 <fwp_block+0x20>
    76f5:	eb e9                	jmp    76e0 <fwp_block+0x130>
    76f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    76fe:	00 00 
    7700:	48 c7 05 b5 c0 01 00 	movq   $0x0,0x1c0b5(%rip)        # 237c0 <fwp_ready_tail>
    7707:	00 00 00 00 
    770b:	e9 d7 fe ff ff       	jmp    75e7 <fwp_block+0x37>
    7710:	48 8d 3d 6d 7a 00 00 	lea    0x7a6d(%rip),%rdi        # f184 <_IO_stdin_used+0x184>
    7717:	e8 84 bc ff ff       	call   33a0 <getenv@plt>
    771c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7721:	48 85 c0             	test   %rax,%rax
    7724:	74 05                	je     772b <fwp_block+0x17b>
    7726:	80 38 00             	cmpb   $0x0,(%rax)
    7729:	75 0b                	jne    7736 <fwp_block+0x186>
    772b:	89 15 6f ba 01 00    	mov    %edx,0x1ba6f(%rip)        # 231a0 <fwp_slice>
    7731:	48 83 c4 08          	add    $0x8,%rsp
    7735:	c3                   	ret
    7736:	ba 0a 00 00 00       	mov    $0xa,%edx
    773b:	31 f6                	xor    %esi,%esi
    773d:	48 89 c7             	mov    %rax,%rdi
    7740:	e8 0b be ff ff       	call   3550 <strtoll@plt>
    7745:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7749:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7750:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7755:	0f 46 d0             	cmovbe %eax,%edx
    7758:	eb d1                	jmp    772b <fwp_block+0x17b>
    775a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007760 <fwp_drop4>:
    7760:	48 8b 15 71 d4 01 00 	mov    0x1d471(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    7767:	48 89 f8             	mov    %rdi,%rax
    776a:	48 2b 05 3f d4 01 00 	sub    0x1d43f(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    7771:	48 c1 e2 10          	shl    $0x10,%rdx
    7775:	48 39 d0             	cmp    %rdx,%rax
    7778:	0f 83 52 01 00 00    	jae    78d0 <fwp_drop4+0x170>
    777e:	48 83 ec 18          	sub    $0x18,%rsp
    7782:	4c 8d 05 77 c0 01 00 	lea    0x1c077(%rip),%r8        # 23800 <fwp_heap>
    7789:	48 89 c2             	mov    %rax,%rdx
    778c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7793:	48 c1 ea 10          	shr    $0x10,%rdx
    7797:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    779b:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    779f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    77a3:	48 85 d2             	test   %rdx,%rdx
    77a6:	74 46                	je     77ee <fwp_drop4+0x8e>
    77a8:	44 0f b6 09          	movzbl (%rcx),%r9d
    77ac:	41 80 f9 02          	cmp    $0x2,%r9b
    77b0:	0f 84 ca 00 00 00    	je     7880 <fwp_drop4+0x120>
    77b6:	41 80 f9 01          	cmp    $0x1,%r9b
    77ba:	75 32                	jne    77ee <fwp_drop4+0x8e>
    77bc:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    77c0:	0f b7 c0             	movzwl %ax,%eax
    77c3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    77c6:	49 0f af c1          	imul   %r9,%rax
    77ca:	48 c1 e8 20          	shr    $0x20,%rax
    77ce:	48 39 c8             	cmp    %rcx,%rax
    77d1:	73 1b                	jae    77ee <fwp_drop4+0x8e>
    77d3:	48 01 c2             	add    %rax,%rdx
    77d6:	0f b6 02             	movzbl (%rdx),%eax
    77d9:	84 c0                	test   %al,%al
    77db:	74 11                	je     77ee <fwp_drop4+0x8e>
    77dd:	3c 01                	cmp    $0x1,%al
    77df:	74 17                	je     77f8 <fwp_drop4+0x98>
    77e1:	3c ff                	cmp    $0xff,%al
    77e3:	0f 84 ef 00 00 00    	je     78d8 <fwp_drop4+0x178>
    77e9:	83 e8 01             	sub    $0x1,%eax
    77ec:	88 02                	mov    %al,(%rdx)
    77ee:	48 83 c4 18          	add    $0x18,%rsp
    77f2:	c3                   	ret
    77f3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    77f8:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    77fc:	0f 88 8e 00 00 00    	js     7890 <fwp_drop4+0x130>
    7802:	48 8b 15 cf d3 01 00 	mov    0x1d3cf(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    7809:	48 89 f8             	mov    %rdi,%rax
    780c:	48 2b 05 9d d3 01 00 	sub    0x1d39d(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    7813:	48 c1 e2 10          	shl    $0x10,%rdx
    7817:	48 39 d0             	cmp    %rdx,%rax
    781a:	73 d2                	jae    77ee <fwp_drop4+0x8e>
    781c:	48 89 c2             	mov    %rax,%rdx
    781f:	48 c1 ea 10          	shr    $0x10,%rdx
    7823:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7827:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    782b:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    782f:	48 85 c9             	test   %rcx,%rcx
    7832:	74 ba                	je     77ee <fwp_drop4+0x8e>
    7834:	0f b6 32             	movzbl (%rdx),%esi
    7837:	40 80 fe 02          	cmp    $0x2,%sil
    783b:	74 33                	je     7870 <fwp_drop4+0x110>
    783d:	40 80 fe 01          	cmp    $0x1,%sil
    7841:	75 ab                	jne    77ee <fwp_drop4+0x8e>
    7843:	8b 72 18             	mov    0x18(%rdx),%esi
    7846:	0f b7 c0             	movzwl %ax,%eax
    7849:	8b 52 1c             	mov    0x1c(%rdx),%edx
    784c:	48 0f af c6          	imul   %rsi,%rax
    7850:	48 c1 e8 20          	shr    $0x20,%rax
    7854:	48 39 d0             	cmp    %rdx,%rax
    7857:	73 95                	jae    77ee <fwp_drop4+0x8e>
    7859:	48 01 c1             	add    %rax,%rcx
    785c:	80 39 01             	cmpb   $0x1,(%rcx)
    785f:	75 8d                	jne    77ee <fwp_drop4+0x8e>
    7861:	48 83 c4 18          	add    $0x18,%rsp
    7865:	e9 86 df ff ff       	jmp    57f0 <fwp_mem_free>
    786a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7870:	66 85 c0             	test   %ax,%ax
    7873:	74 e7                	je     785c <fwp_drop4+0xfc>
    7875:	48 83 c4 18          	add    $0x18,%rsp
    7879:	c3                   	ret
    787a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7880:	66 85 c0             	test   %ax,%ax
    7883:	0f 84 4d ff ff ff    	je     77d6 <fwp_drop4+0x76>
    7889:	48 83 c4 18          	add    $0x18,%rsp
    788d:	c3                   	ret
    788e:	66 90                	xchg   %ax,%ax
    7890:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7894:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7899:	e8 b2 ef ff ff       	call   6850 <fwp_rc_free_arr>
    789e:	4c 8d 05 5b bf 01 00 	lea    0x1bf5b(%rip),%r8        # 23800 <fwp_heap>
    78a5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    78aa:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    78b1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    78b8:	48 c1 e2 10          	shl    $0x10,%rdx
    78bc:	48 39 d0             	cmp    %rdx,%rax
    78bf:	0f 83 29 ff ff ff    	jae    77ee <fwp_drop4+0x8e>
    78c5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    78ca:	e9 ba fe ff ff       	jmp    7789 <fwp_drop4+0x29>
    78cf:	90                   	nop
    78d0:	c3                   	ret
    78d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    78d8:	48 89 d0             	mov    %rdx,%rax
    78db:	48 c1 e8 11          	shr    $0x11,%rax
    78df:	48 31 d0             	xor    %rdx,%rax
    78e2:	48 89 c1             	mov    %rax,%rcx
    78e5:	48 c1 e9 09          	shr    $0x9,%rcx
    78e9:	48 31 c8             	xor    %rcx,%rax
    78ec:	0f b6 c8             	movzbl %al,%ecx
    78ef:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    78f6:	00 
    78f7:	48 85 c0             	test   %rax,%rax
    78fa:	75 0d                	jne    7909 <fwp_drop4+0x1a9>
    78fc:	eb 46                	jmp    7944 <fwp_drop4+0x1e4>
    78fe:	66 90                	xchg   %ax,%ax
    7900:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7904:	48 85 c0             	test   %rax,%rax
    7907:	74 3b                	je     7944 <fwp_drop4+0x1e4>
    7909:	48 89 c1             	mov    %rax,%rcx
    790c:	48 39 10             	cmp    %rdx,(%rax)
    790f:	75 ef                	jne    7900 <fwp_drop4+0x1a0>
    7911:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7915:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7919:	48 89 48 08          	mov    %rcx,0x8(%rax)
    791d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7924:	0f 85 c4 fe ff ff    	jne    77ee <fwp_drop4+0x8e>
    792a:	48 89 d7             	mov    %rdx,%rdi
    792d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7932:	e8 79 dc ff ff       	call   55b0 <fwp_rc_forget_slot>
    7937:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    793c:	c6 02 fe             	movb   $0xfe,(%rdx)
    793f:	e9 aa fe ff ff       	jmp    77ee <fwp_drop4+0x8e>
    7944:	48 8d 3d 3d 7f 00 00 	lea    0x7f3d(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    794b:	e8 a0 ca ff ff       	call   43f0 <fwp_trap>

0000000000007950 <fwp_caps161>:
    7950:	f3 0f 1e fa          	endbr64
    7954:	85 f6                	test   %esi,%esi
    7956:	74 08                	je     7960 <fwp_caps161+0x10>
    7958:	c3                   	ret
    7959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7960:	48 8b 15 71 d2 01 00 	mov    0x1d271(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    7967:	48 89 f8             	mov    %rdi,%rax
    796a:	48 2b 05 3f d2 01 00 	sub    0x1d23f(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    7971:	48 c1 e2 10          	shl    $0x10,%rdx
    7975:	48 39 d0             	cmp    %rdx,%rax
    7978:	73 de                	jae    7958 <fwp_caps161+0x8>
    797a:	48 89 c2             	mov    %rax,%rdx
    797d:	48 c1 ea 10          	shr    $0x10,%rdx
    7981:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7985:	48 8b 15 6c d2 01 00 	mov    0x1d26c(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    798c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7990:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7994:	48 85 c9             	test   %rcx,%rcx
    7997:	74 bf                	je     7958 <fwp_caps161+0x8>
    7999:	0f b6 32             	movzbl (%rdx),%esi
    799c:	40 80 fe 02          	cmp    $0x2,%sil
    79a0:	74 2e                	je     79d0 <fwp_caps161+0x80>
    79a2:	40 80 fe 01          	cmp    $0x1,%sil
    79a6:	75 b0                	jne    7958 <fwp_caps161+0x8>
    79a8:	8b 72 18             	mov    0x18(%rdx),%esi
    79ab:	0f b7 c0             	movzwl %ax,%eax
    79ae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    79b1:	48 0f af c6          	imul   %rsi,%rax
    79b5:	48 c1 e8 20          	shr    $0x20,%rax
    79b9:	48 39 d0             	cmp    %rdx,%rax
    79bc:	73 9a                	jae    7958 <fwp_caps161+0x8>
    79be:	48 01 c1             	add    %rax,%rcx
    79c1:	80 39 01             	cmpb   $0x1,(%rcx)
    79c4:	75 92                	jne    7958 <fwp_caps161+0x8>
    79c6:	e9 25 de ff ff       	jmp    57f0 <fwp_mem_free>
    79cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    79d0:	66 85 c0             	test   %ax,%ax
    79d3:	74 ec                	je     79c1 <fwp_caps161+0x71>
    79d5:	c3                   	ret
    79d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    79dd:	00 00 00 

00000000000079e0 <fwp_args12>:
    79e0:	f3 0f 1e fa          	endbr64
    79e4:	85 d2                	test   %edx,%edx
    79e6:	74 04                	je     79ec <fwp_args12+0xc>
    79e8:	85 f6                	test   %esi,%esi
    79ea:	74 04                	je     79f0 <fwp_args12+0x10>
    79ec:	c3                   	ret
    79ed:	0f 1f 00             	nopl   (%rax)
    79f0:	48 8b 15 e1 d1 01 00 	mov    0x1d1e1(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    79f7:	48 8b 07             	mov    (%rdi),%rax
    79fa:	48 2b 05 af d1 01 00 	sub    0x1d1af(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    7a01:	48 c1 e2 10          	shl    $0x10,%rdx
    7a05:	48 39 d0             	cmp    %rdx,%rax
    7a08:	73 e2                	jae    79ec <fwp_args12+0xc>
    7a0a:	48 89 c2             	mov    %rax,%rdx
    7a0d:	48 c1 ea 10          	shr    $0x10,%rdx
    7a11:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7a15:	48 8b 15 dc d1 01 00 	mov    0x1d1dc(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    7a1c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7a20:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7a24:	48 85 ff             	test   %rdi,%rdi
    7a27:	74 c3                	je     79ec <fwp_args12+0xc>
    7a29:	0f b6 0a             	movzbl (%rdx),%ecx
    7a2c:	80 f9 02             	cmp    $0x2,%cl
    7a2f:	74 2f                	je     7a60 <fwp_args12+0x80>
    7a31:	80 f9 01             	cmp    $0x1,%cl
    7a34:	75 b6                	jne    79ec <fwp_args12+0xc>
    7a36:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7a39:	0f b7 c0             	movzwl %ax,%eax
    7a3c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7a3f:	48 0f af c1          	imul   %rcx,%rax
    7a43:	48 c1 e8 20          	shr    $0x20,%rax
    7a47:	48 39 d0             	cmp    %rdx,%rax
    7a4a:	73 a0                	jae    79ec <fwp_args12+0xc>
    7a4c:	48 01 c7             	add    %rax,%rdi
    7a4f:	0f b6 07             	movzbl (%rdi),%eax
    7a52:	84 c0                	test   %al,%al
    7a54:	74 96                	je     79ec <fwp_args12+0xc>
    7a56:	3c fd                	cmp    $0xfd,%al
    7a58:	77 0c                	ja     7a66 <fwp_args12+0x86>
    7a5a:	83 c0 01             	add    $0x1,%eax
    7a5d:	88 07                	mov    %al,(%rdi)
    7a5f:	c3                   	ret
    7a60:	66 85 c0             	test   %ax,%ax
    7a63:	74 ea                	je     7a4f <fwp_args12+0x6f>
    7a65:	c3                   	ret
    7a66:	e9 25 da ff ff       	jmp    5490 <fwp_rc_wide_dup>
    7a6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007a70 <fwp_args23>:
    7a70:	f3 0f 1e fa          	endbr64
    7a74:	85 d2                	test   %edx,%edx
    7a76:	74 04                	je     7a7c <fwp_args23+0xc>
    7a78:	85 f6                	test   %esi,%esi
    7a7a:	74 04                	je     7a80 <fwp_args23+0x10>
    7a7c:	c3                   	ret
    7a7d:	0f 1f 00             	nopl   (%rax)
    7a80:	48 8b 15 51 d1 01 00 	mov    0x1d151(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    7a87:	48 8b 07             	mov    (%rdi),%rax
    7a8a:	48 2b 05 1f d1 01 00 	sub    0x1d11f(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    7a91:	48 c1 e2 10          	shl    $0x10,%rdx
    7a95:	48 39 d0             	cmp    %rdx,%rax
    7a98:	73 e2                	jae    7a7c <fwp_args23+0xc>
    7a9a:	48 89 c2             	mov    %rax,%rdx
    7a9d:	48 c1 ea 10          	shr    $0x10,%rdx
    7aa1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7aa5:	48 8b 15 4c d1 01 00 	mov    0x1d14c(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    7aac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ab0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7ab4:	48 85 ff             	test   %rdi,%rdi
    7ab7:	74 c3                	je     7a7c <fwp_args23+0xc>
    7ab9:	0f b6 0a             	movzbl (%rdx),%ecx
    7abc:	80 f9 02             	cmp    $0x2,%cl
    7abf:	74 2f                	je     7af0 <fwp_args23+0x80>
    7ac1:	80 f9 01             	cmp    $0x1,%cl
    7ac4:	75 b6                	jne    7a7c <fwp_args23+0xc>
    7ac6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ac9:	0f b7 c0             	movzwl %ax,%eax
    7acc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7acf:	48 0f af c1          	imul   %rcx,%rax
    7ad3:	48 c1 e8 20          	shr    $0x20,%rax
    7ad7:	48 39 d0             	cmp    %rdx,%rax
    7ada:	73 a0                	jae    7a7c <fwp_args23+0xc>
    7adc:	48 01 c7             	add    %rax,%rdi
    7adf:	0f b6 07             	movzbl (%rdi),%eax
    7ae2:	84 c0                	test   %al,%al
    7ae4:	74 96                	je     7a7c <fwp_args23+0xc>
    7ae6:	3c fd                	cmp    $0xfd,%al
    7ae8:	77 0c                	ja     7af6 <fwp_args23+0x86>
    7aea:	83 c0 01             	add    $0x1,%eax
    7aed:	88 07                	mov    %al,(%rdi)
    7aef:	c3                   	ret
    7af0:	66 85 c0             	test   %ax,%ax
    7af3:	74 ea                	je     7adf <fwp_args23+0x6f>
    7af5:	c3                   	ret
    7af6:	e9 95 d9 ff ff       	jmp    5490 <fwp_rc_wide_dup>
    7afb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007b00 <fwp_caps12>:
    7b00:	f3 0f 1e fa          	endbr64
    7b04:	48 83 ec 18          	sub    $0x18,%rsp
    7b08:	8b 57 04             	mov    0x4(%rdi),%edx
    7b0b:	48 89 f8             	mov    %rdi,%rax
    7b0e:	85 d2                	test   %edx,%edx
    7b10:	0f 84 9a 00 00 00    	je     7bb0 <fwp_caps12+0xb0>
    7b16:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7b1a:	85 f6                	test   %esi,%esi
    7b1c:	0f 85 9e 00 00 00    	jne    7bc0 <fwp_caps12+0xc0>
    7b22:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7b27:	e8 34 f0 ff ff       	call   6b60 <fwp_drop0>
    7b2c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7b31:	48 8b 0d a0 d0 01 00 	mov    0x1d0a0(%rip),%rcx        # 24bd8 <fwp_heap+0x13d8>
    7b38:	48 89 c2             	mov    %rax,%rdx
    7b3b:	48 2b 15 6e d0 01 00 	sub    0x1d06e(%rip),%rdx        # 24bb0 <fwp_heap+0x13b0>
    7b42:	48 c1 e1 10          	shl    $0x10,%rcx
    7b46:	48 39 ca             	cmp    %rcx,%rdx
    7b49:	73 6d                	jae    7bb8 <fwp_caps12+0xb8>
    7b4b:	48 89 d1             	mov    %rdx,%rcx
    7b4e:	48 c1 e9 10          	shr    $0x10,%rcx
    7b52:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7b56:	48 8b 0d 9b d0 01 00 	mov    0x1d09b(%rip),%rcx        # 24bf8 <fwp_heap+0x13f8>
    7b5d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7b61:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7b65:	48 85 f6             	test   %rsi,%rsi
    7b68:	74 4e                	je     7bb8 <fwp_caps12+0xb8>
    7b6a:	0f b6 39             	movzbl (%rcx),%edi
    7b6d:	40 80 ff 02          	cmp    $0x2,%dil
    7b71:	0f 84 b9 00 00 00    	je     7c30 <fwp_caps12+0x130>
    7b77:	40 80 ff 01          	cmp    $0x1,%dil
    7b7b:	75 3b                	jne    7bb8 <fwp_caps12+0xb8>
    7b7d:	8b 79 18             	mov    0x18(%rcx),%edi
    7b80:	0f b7 d2             	movzwl %dx,%edx
    7b83:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7b86:	48 0f af d7          	imul   %rdi,%rdx
    7b8a:	48 c1 ea 20          	shr    $0x20,%rdx
    7b8e:	48 39 ca             	cmp    %rcx,%rdx
    7b91:	73 25                	jae    7bb8 <fwp_caps12+0xb8>
    7b93:	48 01 d6             	add    %rdx,%rsi
    7b96:	80 3e 01             	cmpb   $0x1,(%rsi)
    7b99:	75 1d                	jne    7bb8 <fwp_caps12+0xb8>
    7b9b:	48 89 c7             	mov    %rax,%rdi
    7b9e:	48 83 c4 18          	add    $0x18,%rsp
    7ba2:	e9 49 dc ff ff       	jmp    57f0 <fwp_mem_free>
    7ba7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7bae:	00 00 
    7bb0:	85 f6                	test   %esi,%esi
    7bb2:	0f 84 79 ff ff ff    	je     7b31 <fwp_caps12+0x31>
    7bb8:	48 83 c4 18          	add    $0x18,%rsp
    7bbc:	c3                   	ret
    7bbd:	0f 1f 00             	nopl   (%rax)
    7bc0:	48 8b 05 11 d0 01 00 	mov    0x1d011(%rip),%rax        # 24bd8 <fwp_heap+0x13d8>
    7bc7:	48 2b 3d e2 cf 01 00 	sub    0x1cfe2(%rip),%rdi        # 24bb0 <fwp_heap+0x13b0>
    7bce:	48 c1 e0 10          	shl    $0x10,%rax
    7bd2:	48 39 c7             	cmp    %rax,%rdi
    7bd5:	73 e1                	jae    7bb8 <fwp_caps12+0xb8>
    7bd7:	48 89 f8             	mov    %rdi,%rax
    7bda:	48 c1 e8 10          	shr    $0x10,%rax
    7bde:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7be2:	48 8b 05 0f d0 01 00 	mov    0x1d00f(%rip),%rax        # 24bf8 <fwp_heap+0x13f8>
    7be9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7bed:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7bf1:	48 85 c0             	test   %rax,%rax
    7bf4:	74 c2                	je     7bb8 <fwp_caps12+0xb8>
    7bf6:	0f b6 0a             	movzbl (%rdx),%ecx
    7bf9:	80 f9 02             	cmp    $0x2,%cl
    7bfc:	74 42                	je     7c40 <fwp_caps12+0x140>
    7bfe:	80 f9 01             	cmp    $0x1,%cl
    7c01:	75 b5                	jne    7bb8 <fwp_caps12+0xb8>
    7c03:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7c06:	0f b7 ff             	movzwl %di,%edi
    7c09:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7c0c:	48 0f af f9          	imul   %rcx,%rdi
    7c10:	48 c1 ef 20          	shr    $0x20,%rdi
    7c14:	48 39 d7             	cmp    %rdx,%rdi
    7c17:	73 9f                	jae    7bb8 <fwp_caps12+0xb8>
    7c19:	48 01 f8             	add    %rdi,%rax
    7c1c:	0f b6 10             	movzbl (%rax),%edx
    7c1f:	84 d2                	test   %dl,%dl
    7c21:	74 95                	je     7bb8 <fwp_caps12+0xb8>
    7c23:	80 fa fd             	cmp    $0xfd,%dl
    7c26:	77 23                	ja     7c4b <fwp_caps12+0x14b>
    7c28:	83 c2 01             	add    $0x1,%edx
    7c2b:	88 10                	mov    %dl,(%rax)
    7c2d:	eb 89                	jmp    7bb8 <fwp_caps12+0xb8>
    7c2f:	90                   	nop
    7c30:	66 85 d2             	test   %dx,%dx
    7c33:	0f 85 7f ff ff ff    	jne    7bb8 <fwp_caps12+0xb8>
    7c39:	e9 58 ff ff ff       	jmp    7b96 <fwp_caps12+0x96>
    7c3e:	66 90                	xchg   %ax,%ax
    7c40:	66 85 ff             	test   %di,%di
    7c43:	0f 85 6f ff ff ff    	jne    7bb8 <fwp_caps12+0xb8>
    7c49:	eb d1                	jmp    7c1c <fwp_caps12+0x11c>
    7c4b:	48 89 c7             	mov    %rax,%rdi
    7c4e:	48 83 c4 18          	add    $0x18,%rsp
    7c52:	e9 39 d8 ff ff       	jmp    5490 <fwp_rc_wide_dup>
    7c57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c5e:	00 00 

0000000000007c60 <fwp_drop2>:
    7c60:	48 8b 0d 71 cf 01 00 	mov    0x1cf71(%rip),%rcx        # 24bd8 <fwp_heap+0x13d8>
    7c67:	48 89 f8             	mov    %rdi,%rax
    7c6a:	48 2b 05 3f cf 01 00 	sub    0x1cf3f(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    7c71:	48 c1 e1 10          	shl    $0x10,%rcx
    7c75:	48 39 c8             	cmp    %rcx,%rax
    7c78:	0f 83 42 01 00 00    	jae    7dc0 <fwp_drop2+0x160>
    7c7e:	48 83 ec 18          	sub    $0x18,%rsp
    7c82:	48 89 fa             	mov    %rdi,%rdx
    7c85:	4c 8d 05 74 bb 01 00 	lea    0x1bb74(%rip),%r8        # 23800 <fwp_heap>
    7c8c:	48 89 c1             	mov    %rax,%rcx
    7c8f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7c96:	48 c1 e9 10          	shr    $0x10,%rcx
    7c9a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7c9e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7ca2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7ca6:	48 85 c9             	test   %rcx,%rcx
    7ca9:	74 40                	je     7ceb <fwp_drop2+0x8b>
    7cab:	0f b6 3e             	movzbl (%rsi),%edi
    7cae:	40 80 ff 02          	cmp    $0x2,%dil
    7cb2:	74 3c                	je     7cf0 <fwp_drop2+0x90>
    7cb4:	40 80 ff 01          	cmp    $0x1,%dil
    7cb8:	75 31                	jne    7ceb <fwp_drop2+0x8b>
    7cba:	8b 7e 18             	mov    0x18(%rsi),%edi
    7cbd:	0f b7 c0             	movzwl %ax,%eax
    7cc0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7cc3:	48 0f af c7          	imul   %rdi,%rax
    7cc7:	48 c1 e8 20          	shr    $0x20,%rax
    7ccb:	48 39 f0             	cmp    %rsi,%rax
    7cce:	73 1b                	jae    7ceb <fwp_drop2+0x8b>
    7cd0:	48 01 c1             	add    %rax,%rcx
    7cd3:	0f b6 01             	movzbl (%rcx),%eax
    7cd6:	84 c0                	test   %al,%al
    7cd8:	74 11                	je     7ceb <fwp_drop2+0x8b>
    7cda:	3c 01                	cmp    $0x1,%al
    7cdc:	74 22                	je     7d00 <fwp_drop2+0xa0>
    7cde:	3c ff                	cmp    $0xff,%al
    7ce0:	0f 84 0a 01 00 00    	je     7df0 <fwp_drop2+0x190>
    7ce6:	83 e8 01             	sub    $0x1,%eax
    7ce9:	88 01                	mov    %al,(%rcx)
    7ceb:	48 83 c4 18          	add    $0x18,%rsp
    7cef:	c3                   	ret
    7cf0:	66 85 c0             	test   %ax,%ax
    7cf3:	74 de                	je     7cd3 <fwp_drop2+0x73>
    7cf5:	48 83 c4 18          	add    $0x18,%rsp
    7cf9:	c3                   	ret
    7cfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d00:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7d04:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    7d0b:	48 89 f8             	mov    %rdi,%rax
    7d0e:	48 c1 e1 10          	shl    $0x10,%rcx
    7d12:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7d19:	48 39 c8             	cmp    %rcx,%rax
    7d1c:	73 62                	jae    7d80 <fwp_drop2+0x120>
    7d1e:	48 89 c1             	mov    %rax,%rcx
    7d21:	48 c1 e9 10          	shr    $0x10,%rcx
    7d25:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7d29:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7d2d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7d31:	48 85 c9             	test   %rcx,%rcx
    7d34:	74 4a                	je     7d80 <fwp_drop2+0x120>
    7d36:	44 0f b6 0e          	movzbl (%rsi),%r9d
    7d3a:	41 80 f9 02          	cmp    $0x2,%r9b
    7d3e:	0f 84 9c 00 00 00    	je     7de0 <fwp_drop2+0x180>
    7d44:	41 80 f9 01          	cmp    $0x1,%r9b
    7d48:	75 36                	jne    7d80 <fwp_drop2+0x120>
    7d4a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    7d4e:	0f b7 c0             	movzwl %ax,%eax
    7d51:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7d54:	49 0f af c1          	imul   %r9,%rax
    7d58:	48 c1 e8 20          	shr    $0x20,%rax
    7d5c:	48 39 f0             	cmp    %rsi,%rax
    7d5f:	73 1f                	jae    7d80 <fwp_drop2+0x120>
    7d61:	48 01 c1             	add    %rax,%rcx
    7d64:	0f b6 01             	movzbl (%rcx),%eax
    7d67:	84 c0                	test   %al,%al
    7d69:	74 15                	je     7d80 <fwp_drop2+0x120>
    7d6b:	3c 01                	cmp    $0x1,%al
    7d6d:	74 59                	je     7dc8 <fwp_drop2+0x168>
    7d6f:	3c ff                	cmp    $0xff,%al
    7d71:	0f 84 ef 00 00 00    	je     7e66 <fwp_drop2+0x206>
    7d77:	83 e8 01             	sub    $0x1,%eax
    7d7a:	88 01                	mov    %al,(%rcx)
    7d7c:	0f 1f 40 00          	nopl   0x0(%rax)
    7d80:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7d84:	48 89 d7             	mov    %rdx,%rdi
    7d87:	48 89 0c 24          	mov    %rcx,(%rsp)
    7d8b:	e8 c0 ea ff ff       	call   6850 <fwp_rc_free_arr>
    7d90:	4c 8d 05 69 ba 01 00 	lea    0x1ba69(%rip),%r8        # 23800 <fwp_heap>
    7d97:	48 8b 04 24          	mov    (%rsp),%rax
    7d9b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7da2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7da9:	48 c1 e2 10          	shl    $0x10,%rdx
    7dad:	48 39 d0             	cmp    %rdx,%rax
    7db0:	0f 83 35 ff ff ff    	jae    7ceb <fwp_drop2+0x8b>
    7db6:	48 8b 14 24          	mov    (%rsp),%rdx
    7dba:	e9 cd fe ff ff       	jmp    7c8c <fwp_drop2+0x2c>
    7dbf:	90                   	nop
    7dc0:	c3                   	ret
    7dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7dc8:	48 89 14 24          	mov    %rdx,(%rsp)
    7dcc:	e8 7f ea ff ff       	call   6850 <fwp_rc_free_arr>
    7dd1:	48 8b 14 24          	mov    (%rsp),%rdx
    7dd5:	eb a9                	jmp    7d80 <fwp_drop2+0x120>
    7dd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7dde:	00 00 
    7de0:	66 85 c0             	test   %ax,%ax
    7de3:	75 9b                	jne    7d80 <fwp_drop2+0x120>
    7de5:	e9 7a ff ff ff       	jmp    7d64 <fwp_drop2+0x104>
    7dea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7df0:	48 89 c8             	mov    %rcx,%rax
    7df3:	48 c1 e8 11          	shr    $0x11,%rax
    7df7:	48 31 c8             	xor    %rcx,%rax
    7dfa:	48 89 c2             	mov    %rax,%rdx
    7dfd:	48 c1 ea 09          	shr    $0x9,%rdx
    7e01:	48 31 d0             	xor    %rdx,%rax
    7e04:	0f b6 d0             	movzbl %al,%edx
    7e07:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    7e0e:	00 
    7e0f:	48 85 c0             	test   %rax,%rax
    7e12:	75 19                	jne    7e2d <fwp_drop2+0x1cd>
    7e14:	e9 d3 00 00 00       	jmp    7eec <fwp_drop2+0x28c>
    7e19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e20:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7e24:	48 85 c0             	test   %rax,%rax
    7e27:	0f 84 bf 00 00 00    	je     7eec <fwp_drop2+0x28c>
    7e2d:	48 89 c2             	mov    %rax,%rdx
    7e30:	48 39 08             	cmp    %rcx,(%rax)
    7e33:	75 eb                	jne    7e20 <fwp_drop2+0x1c0>
    7e35:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7e39:	48 83 ea 01          	sub    $0x1,%rdx
    7e3d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7e41:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7e48:	0f 85 9d fe ff ff    	jne    7ceb <fwp_drop2+0x8b>
    7e4e:	48 89 cf             	mov    %rcx,%rdi
    7e51:	48 89 0c 24          	mov    %rcx,(%rsp)
    7e55:	e8 56 d7 ff ff       	call   55b0 <fwp_rc_forget_slot>
    7e5a:	48 8b 0c 24          	mov    (%rsp),%rcx
    7e5e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7e61:	e9 85 fe ff ff       	jmp    7ceb <fwp_drop2+0x8b>
    7e66:	48 89 ce             	mov    %rcx,%rsi
    7e69:	48 c1 ee 11          	shr    $0x11,%rsi
    7e6d:	48 31 ce             	xor    %rcx,%rsi
    7e70:	48 89 f0             	mov    %rsi,%rax
    7e73:	48 c1 e8 09          	shr    $0x9,%rax
    7e77:	48 31 c6             	xor    %rax,%rsi
    7e7a:	40 0f b6 f6          	movzbl %sil,%esi
    7e7e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7e85:	00 
    7e86:	48 85 c0             	test   %rax,%rax
    7e89:	75 1e                	jne    7ea9 <fwp_drop2+0x249>
    7e8b:	eb 5f                	jmp    7eec <fwp_drop2+0x28c>
    7e8d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7e94:	00 
    7e95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e9c:	00 00 00 00 
    7ea0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7ea4:	48 85 c0             	test   %rax,%rax
    7ea7:	74 43                	je     7eec <fwp_drop2+0x28c>
    7ea9:	48 89 c6             	mov    %rax,%rsi
    7eac:	48 39 08             	cmp    %rcx,(%rax)
    7eaf:	75 ef                	jne    7ea0 <fwp_drop2+0x240>
    7eb1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7eb5:	48 83 ee 01          	sub    $0x1,%rsi
    7eb9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    7ebd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7ec4:	0f 85 b6 fe ff ff    	jne    7d80 <fwp_drop2+0x120>
    7eca:	48 89 cf             	mov    %rcx,%rdi
    7ecd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7ed2:	48 89 0c 24          	mov    %rcx,(%rsp)
    7ed6:	e8 d5 d6 ff ff       	call   55b0 <fwp_rc_forget_slot>
    7edb:	48 8b 0c 24          	mov    (%rsp),%rcx
    7edf:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7ee4:	c6 01 fe             	movb   $0xfe,(%rcx)
    7ee7:	e9 94 fe ff ff       	jmp    7d80 <fwp_drop2+0x120>
    7eec:	48 8d 3d 95 79 00 00 	lea    0x7995(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    7ef3:	e8 f8 c4 ff ff       	call   43f0 <fwp_trap>
    7ef8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7eff:	00 

0000000000007f00 <fwp_arg_drop23>:
    7f00:	f3 0f 1e fa          	endbr64
    7f04:	85 f6                	test   %esi,%esi
    7f06:	75 04                	jne    7f0c <fwp_arg_drop23+0xc>
    7f08:	85 d2                	test   %edx,%edx
    7f0a:	75 04                	jne    7f10 <fwp_arg_drop23+0x10>
    7f0c:	c3                   	ret
    7f0d:	0f 1f 00             	nopl   (%rax)
    7f10:	48 8b 3f             	mov    (%rdi),%rdi
    7f13:	e9 48 fd ff ff       	jmp    7c60 <fwp_drop2>
    7f18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7f1f:	00 

0000000000007f20 <fwp_caps23>:
    7f20:	f3 0f 1e fa          	endbr64
    7f24:	48 83 ec 18          	sub    $0x18,%rsp
    7f28:	8b 57 04             	mov    0x4(%rdi),%edx
    7f2b:	48 89 f8             	mov    %rdi,%rax
    7f2e:	85 d2                	test   %edx,%edx
    7f30:	0f 84 9a 00 00 00    	je     7fd0 <fwp_caps23+0xb0>
    7f36:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7f3a:	85 f6                	test   %esi,%esi
    7f3c:	0f 85 9e 00 00 00    	jne    7fe0 <fwp_caps23+0xc0>
    7f42:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7f47:	e8 14 fd ff ff       	call   7c60 <fwp_drop2>
    7f4c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7f51:	48 8b 0d 80 cc 01 00 	mov    0x1cc80(%rip),%rcx        # 24bd8 <fwp_heap+0x13d8>
    7f58:	48 89 c2             	mov    %rax,%rdx
    7f5b:	48 2b 15 4e cc 01 00 	sub    0x1cc4e(%rip),%rdx        # 24bb0 <fwp_heap+0x13b0>
    7f62:	48 c1 e1 10          	shl    $0x10,%rcx
    7f66:	48 39 ca             	cmp    %rcx,%rdx
    7f69:	73 6d                	jae    7fd8 <fwp_caps23+0xb8>
    7f6b:	48 89 d1             	mov    %rdx,%rcx
    7f6e:	48 c1 e9 10          	shr    $0x10,%rcx
    7f72:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7f76:	48 8b 0d 7b cc 01 00 	mov    0x1cc7b(%rip),%rcx        # 24bf8 <fwp_heap+0x13f8>
    7f7d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7f81:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7f85:	48 85 f6             	test   %rsi,%rsi
    7f88:	74 4e                	je     7fd8 <fwp_caps23+0xb8>
    7f8a:	0f b6 39             	movzbl (%rcx),%edi
    7f8d:	40 80 ff 02          	cmp    $0x2,%dil
    7f91:	0f 84 b9 00 00 00    	je     8050 <fwp_caps23+0x130>
    7f97:	40 80 ff 01          	cmp    $0x1,%dil
    7f9b:	75 3b                	jne    7fd8 <fwp_caps23+0xb8>
    7f9d:	8b 79 18             	mov    0x18(%rcx),%edi
    7fa0:	0f b7 d2             	movzwl %dx,%edx
    7fa3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7fa6:	48 0f af d7          	imul   %rdi,%rdx
    7faa:	48 c1 ea 20          	shr    $0x20,%rdx
    7fae:	48 39 ca             	cmp    %rcx,%rdx
    7fb1:	73 25                	jae    7fd8 <fwp_caps23+0xb8>
    7fb3:	48 01 d6             	add    %rdx,%rsi
    7fb6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7fb9:	75 1d                	jne    7fd8 <fwp_caps23+0xb8>
    7fbb:	48 89 c7             	mov    %rax,%rdi
    7fbe:	48 83 c4 18          	add    $0x18,%rsp
    7fc2:	e9 29 d8 ff ff       	jmp    57f0 <fwp_mem_free>
    7fc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7fce:	00 00 
    7fd0:	85 f6                	test   %esi,%esi
    7fd2:	0f 84 79 ff ff ff    	je     7f51 <fwp_caps23+0x31>
    7fd8:	48 83 c4 18          	add    $0x18,%rsp
    7fdc:	c3                   	ret
    7fdd:	0f 1f 00             	nopl   (%rax)
    7fe0:	48 8b 05 f1 cb 01 00 	mov    0x1cbf1(%rip),%rax        # 24bd8 <fwp_heap+0x13d8>
    7fe7:	48 2b 3d c2 cb 01 00 	sub    0x1cbc2(%rip),%rdi        # 24bb0 <fwp_heap+0x13b0>
    7fee:	48 c1 e0 10          	shl    $0x10,%rax
    7ff2:	48 39 c7             	cmp    %rax,%rdi
    7ff5:	73 e1                	jae    7fd8 <fwp_caps23+0xb8>
    7ff7:	48 89 f8             	mov    %rdi,%rax
    7ffa:	48 c1 e8 10          	shr    $0x10,%rax
    7ffe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8002:	48 8b 05 ef cb 01 00 	mov    0x1cbef(%rip),%rax        # 24bf8 <fwp_heap+0x13f8>
    8009:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    800d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    8011:	48 85 c0             	test   %rax,%rax
    8014:	74 c2                	je     7fd8 <fwp_caps23+0xb8>
    8016:	0f b6 0a             	movzbl (%rdx),%ecx
    8019:	80 f9 02             	cmp    $0x2,%cl
    801c:	74 42                	je     8060 <fwp_caps23+0x140>
    801e:	80 f9 01             	cmp    $0x1,%cl
    8021:	75 b5                	jne    7fd8 <fwp_caps23+0xb8>
    8023:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8026:	0f b7 ff             	movzwl %di,%edi
    8029:	8b 52 1c             	mov    0x1c(%rdx),%edx
    802c:	48 0f af f9          	imul   %rcx,%rdi
    8030:	48 c1 ef 20          	shr    $0x20,%rdi
    8034:	48 39 d7             	cmp    %rdx,%rdi
    8037:	73 9f                	jae    7fd8 <fwp_caps23+0xb8>
    8039:	48 01 f8             	add    %rdi,%rax
    803c:	0f b6 10             	movzbl (%rax),%edx
    803f:	84 d2                	test   %dl,%dl
    8041:	74 95                	je     7fd8 <fwp_caps23+0xb8>
    8043:	80 fa fd             	cmp    $0xfd,%dl
    8046:	77 23                	ja     806b <fwp_caps23+0x14b>
    8048:	83 c2 01             	add    $0x1,%edx
    804b:	88 10                	mov    %dl,(%rax)
    804d:	eb 89                	jmp    7fd8 <fwp_caps23+0xb8>
    804f:	90                   	nop
    8050:	66 85 d2             	test   %dx,%dx
    8053:	0f 85 7f ff ff ff    	jne    7fd8 <fwp_caps23+0xb8>
    8059:	e9 58 ff ff ff       	jmp    7fb6 <fwp_caps23+0x96>
    805e:	66 90                	xchg   %ax,%ax
    8060:	66 85 ff             	test   %di,%di
    8063:	0f 85 6f ff ff ff    	jne    7fd8 <fwp_caps23+0xb8>
    8069:	eb d1                	jmp    803c <fwp_caps23+0x11c>
    806b:	48 89 c7             	mov    %rax,%rdi
    806e:	48 83 c4 18          	add    $0x18,%rsp
    8072:	e9 19 d4 ff ff       	jmp    5490 <fwp_rc_wide_dup>
    8077:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    807e:	00 00 

0000000000008080 <f23>:
    8080:	41 57                	push   %r15
    8082:	41 56                	push   %r14
    8084:	41 55                	push   %r13
    8086:	41 54                	push   %r12
    8088:	55                   	push   %rbp
    8089:	53                   	push   %rbx
    808a:	48 83 ec 38          	sub    $0x38,%rsp
    808e:	48 8b 15 43 cb 01 00 	mov    0x1cb43(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    8095:	48 8b 0d 14 cb 01 00 	mov    0x1cb14(%rip),%rcx        # 24bb0 <fwp_heap+0x13b0>
    809c:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    80a3:	00 00 
    80a5:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    80aa:	49 89 fc             	mov    %rdi,%r12
    80ad:	48 c1 e2 10          	shl    $0x10,%rdx
    80b1:	48 85 ff             	test   %rdi,%rdi
    80b4:	0f 84 bc 02 00 00    	je     8376 <f23+0x2f6>
    80ba:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    80bf:	48 89 d8             	mov    %rbx,%rax
    80c2:	48 29 c8             	sub    %rcx,%rax
    80c5:	48 39 d0             	cmp    %rdx,%rax
    80c8:	0f 83 72 03 00 00    	jae    8440 <f23+0x3c0>
    80ce:	48 89 c2             	mov    %rax,%rdx
    80d1:	48 c1 ea 10          	shr    $0x10,%rdx
    80d5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    80d9:	48 8b 15 18 cb 01 00 	mov    0x1cb18(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    80e0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    80e4:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    80e8:	48 85 ff             	test   %rdi,%rdi
    80eb:	0f 84 4f 03 00 00    	je     8440 <f23+0x3c0>
    80f1:	0f b6 0a             	movzbl (%rdx),%ecx
    80f4:	80 f9 02             	cmp    $0x2,%cl
    80f7:	0f 84 53 02 00 00    	je     8350 <f23+0x2d0>
    80fd:	80 f9 01             	cmp    $0x1,%cl
    8100:	75 24                	jne    8126 <f23+0xa6>
    8102:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8105:	0f b7 c0             	movzwl %ax,%eax
    8108:	8b 52 1c             	mov    0x1c(%rdx),%edx
    810b:	48 0f af c1          	imul   %rcx,%rax
    810f:	48 c1 e8 20          	shr    $0x20,%rax
    8113:	48 39 d0             	cmp    %rdx,%rax
    8116:	73 0e                	jae    8126 <f23+0xa6>
    8118:	48 01 c7             	add    %rax,%rdi
    811b:	0f b6 07             	movzbl (%rdi),%eax
    811e:	84 c0                	test   %al,%al
    8120:	0f 85 ca 02 00 00    	jne    83f0 <f23+0x370>
    8126:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    812b:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    8130:	ba 01 00 00 00       	mov    $0x1,%edx
    8135:	48 85 db             	test   %rbx,%rbx
    8138:	74 13                	je     814d <f23+0xcd>
    813a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8140:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    8144:	48 83 c2 01          	add    $0x1,%rdx
    8148:	48 85 db             	test   %rbx,%rbx
    814b:	75 f3                	jne    8140 <f23+0xc0>
    814d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8152:	48 85 c0             	test   %rax,%rax
    8155:	0f 84 15 03 00 00    	je     8470 <f23+0x3f0>
    815b:	31 db                	xor    %ebx,%ebx
    815d:	0f 1f 00             	nopl   (%rax)
    8160:	48 8b 40 10          	mov    0x10(%rax),%rax
    8164:	48 83 c3 01          	add    $0x1,%rbx
    8168:	48 85 c0             	test   %rax,%rax
    816b:	75 f3                	jne    8160 <f23+0xe0>
    816d:	48 39 d3             	cmp    %rdx,%rbx
    8170:	48 0f 47 da          	cmova  %rdx,%rbx
    8174:	48 89 d8             	mov    %rbx,%rax
    8177:	48 c1 e8 3c          	shr    $0x3c,%rax
    817b:	0f 85 8f 03 00 00    	jne    8510 <f23+0x490>
    8181:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8185:	be 02 00 00 00       	mov    $0x2,%esi
    818a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8191:	00 
    8192:	e8 59 db ff ff       	call   5cf0 <fwp_heap_alloc>
    8197:	48 89 28             	mov    %rbp,(%rax)
    819a:	48 8b 15 37 ca 01 00 	mov    0x1ca37(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    81a1:	49 89 c6             	mov    %rax,%r14
    81a4:	48 2b 05 05 ca 01 00 	sub    0x1ca05(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    81ab:	48 c1 e2 10          	shl    $0x10,%rdx
    81af:	48 39 d0             	cmp    %rdx,%rax
    81b2:	73 57                	jae    820b <f23+0x18b>
    81b4:	48 89 c2             	mov    %rax,%rdx
    81b7:	48 c1 ea 10          	shr    $0x10,%rdx
    81bb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    81bf:	48 8b 15 32 ca 01 00 	mov    0x1ca32(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    81c6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    81ca:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    81ce:	48 85 ed             	test   %rbp,%rbp
    81d1:	74 38                	je     820b <f23+0x18b>
    81d3:	0f b6 0a             	movzbl (%rdx),%ecx
    81d6:	80 f9 02             	cmp    $0x2,%cl
    81d9:	0f 84 51 02 00 00    	je     8430 <f23+0x3b0>
    81df:	80 f9 01             	cmp    $0x1,%cl
    81e2:	75 27                	jne    820b <f23+0x18b>
    81e4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    81e7:	0f b7 c0             	movzwl %ax,%eax
    81ea:	8b 52 1c             	mov    0x1c(%rdx),%edx
    81ed:	48 0f af c1          	imul   %rcx,%rax
    81f1:	48 c1 e8 20          	shr    $0x20,%rax
    81f5:	48 39 d0             	cmp    %rdx,%rax
    81f8:	73 11                	jae    820b <f23+0x18b>
    81fa:	48 01 c5             	add    %rax,%rbp
    81fd:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8201:	0f 84 d5 02 00 00    	je     84dc <f23+0x45c>
    8207:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    820b:	48 85 db             	test   %rbx,%rbx
    820e:	74 5d                	je     826d <f23+0x1ed>
    8210:	48 c1 e3 04          	shl    $0x4,%rbx
    8214:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    8219:	4c 89 f5             	mov    %r14,%rbp
    821c:	4d 89 e5             	mov    %r12,%r13
    821f:	4c 01 f3             	add    %r14,%rbx
    8222:	0f 1f 00             	nopl   (%rax)
    8225:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    822c:	00 00 00 00 
    8230:	49 8b 45 08          	mov    0x8(%r13),%rax
    8234:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8238:	48 83 c5 10          	add    $0x10,%rbp
    823c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8241:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8245:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8249:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    824e:	e8 7d e1 ff ff       	call   63d0 <w107>
    8253:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8258:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    825c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8260:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8264:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    8268:	48 39 dd             	cmp    %rbx,%rbp
    826b:	75 c3                	jne    8230 <f23+0x1b0>
    826d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8272:	e8 e9 f9 ff ff       	call   7c60 <fwp_drop2>
    8277:	4c 89 e7             	mov    %r12,%rdi
    827a:	e8 e1 f9 ff ff       	call   7c60 <fwp_drop2>
    827f:	4c 89 f7             	mov    %r14,%rdi
    8282:	e8 c9 e2 ff ff       	call   6550 <w164.constprop.0>
    8287:	4c 89 f7             	mov    %r14,%rdi
    828a:	48 89 c3             	mov    %rax,%rbx
    828d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8293:	e8 c8 f4 ff ff       	call   7760 <fwp_drop4>
    8298:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    829e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    82a3:	31 ff                	xor    %edi,%edi
    82a5:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    82aa:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    82ae:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    82b3:	e8 38 e3 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    82b8:	48 8b 15 19 c9 01 00 	mov    0x1c919(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    82bf:	48 89 c5             	mov    %rax,%rbp
    82c2:	48 2b 05 e7 c8 01 00 	sub    0x1c8e7(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    82c9:	48 c1 e2 10          	shl    $0x10,%rdx
    82cd:	48 39 d0             	cmp    %rdx,%rax
    82d0:	73 55                	jae    8327 <f23+0x2a7>
    82d2:	48 89 c2             	mov    %rax,%rdx
    82d5:	48 c1 ea 10          	shr    $0x10,%rdx
    82d9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    82dd:	48 8b 15 14 c9 01 00 	mov    0x1c914(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    82e4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    82e8:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    82ec:	48 85 db             	test   %rbx,%rbx
    82ef:	74 36                	je     8327 <f23+0x2a7>
    82f1:	0f b6 0a             	movzbl (%rdx),%ecx
    82f4:	80 f9 02             	cmp    $0x2,%cl
    82f7:	0f 84 1b 01 00 00    	je     8418 <f23+0x398>
    82fd:	80 f9 01             	cmp    $0x1,%cl
    8300:	75 25                	jne    8327 <f23+0x2a7>
    8302:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8305:	0f b7 c0             	movzwl %ax,%eax
    8308:	8b 52 1c             	mov    0x1c(%rdx),%edx
    830b:	48 0f af c1          	imul   %rcx,%rax
    830f:	48 c1 e8 20          	shr    $0x20,%rax
    8313:	48 39 d0             	cmp    %rdx,%rax
    8316:	73 0f                	jae    8327 <f23+0x2a7>
    8318:	48 01 c3             	add    %rax,%rbx
    831b:	80 3b ff             	cmpb   $0xff,(%rbx)
    831e:	0f 84 ab 01 00 00    	je     84cf <f23+0x44f>
    8324:	c6 03 01             	movb   $0x1,(%rbx)
    8327:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    832c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8333:	00 00 
    8335:	0f 85 d0 01 00 00    	jne    850b <f23+0x48b>
    833b:	48 83 c4 38          	add    $0x38,%rsp
    833f:	48 89 e8             	mov    %rbp,%rax
    8342:	5b                   	pop    %rbx
    8343:	5d                   	pop    %rbp
    8344:	41 5c                	pop    %r12
    8346:	41 5d                	pop    %r13
    8348:	41 5e                	pop    %r14
    834a:	41 5f                	pop    %r15
    834c:	c3                   	ret
    834d:	0f 1f 00             	nopl   (%rax)
    8350:	66 85 c0             	test   %ax,%ax
    8353:	0f 85 cd fd ff ff    	jne    8126 <f23+0xa6>
    8359:	0f b6 07             	movzbl (%rdi),%eax
    835c:	84 c0                	test   %al,%al
    835e:	0f 84 c2 fd ff ff    	je     8126 <f23+0xa6>
    8364:	3c fd                	cmp    $0xfd,%al
    8366:	0f 87 95 01 00 00    	ja     8501 <f23+0x481>
    836c:	83 c0 01             	add    $0x1,%eax
    836f:	88 07                	mov    %al,(%rdi)
    8371:	e9 b0 fd ff ff       	jmp    8126 <f23+0xa6>
    8376:	48 f7 d9             	neg    %rcx
    8379:	48 39 d1             	cmp    %rdx,%rcx
    837c:	0f 83 ee 00 00 00    	jae    8470 <f23+0x3f0>
    8382:	48 89 c8             	mov    %rcx,%rax
    8385:	48 c1 e8 10          	shr    $0x10,%rax
    8389:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    838d:	48 8b 05 64 c8 01 00 	mov    0x1c864(%rip),%rax        # 24bf8 <fwp_heap+0x13f8>
    8394:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8398:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    839c:	48 85 ff             	test   %rdi,%rdi
    839f:	0f 84 cb 00 00 00    	je     8470 <f23+0x3f0>
    83a5:	0f b6 02             	movzbl (%rdx),%eax
    83a8:	3c 02                	cmp    $0x2,%al
    83aa:	0f 84 9a 00 00 00    	je     844a <f23+0x3ca>
    83b0:	3c 01                	cmp    $0x1,%al
    83b2:	0f 85 b8 00 00 00    	jne    8470 <f23+0x3f0>
    83b8:	0f b7 c1             	movzwl %cx,%eax
    83bb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    83be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    83c1:	48 0f af c1          	imul   %rcx,%rax
    83c5:	48 c1 e8 20          	shr    $0x20,%rax
    83c9:	48 39 d0             	cmp    %rdx,%rax
    83cc:	0f 83 9e 00 00 00    	jae    8470 <f23+0x3f0>
    83d2:	48 01 c7             	add    %rax,%rdi
    83d5:	0f b6 07             	movzbl (%rdi),%eax
    83d8:	84 c0                	test   %al,%al
    83da:	0f 84 90 00 00 00    	je     8470 <f23+0x3f0>
    83e0:	31 db                	xor    %ebx,%ebx
    83e2:	0f 1f 00             	nopl   (%rax)
    83e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    83ec:	00 00 00 00 
    83f0:	3c fd                	cmp    $0xfd,%al
    83f2:	0f 87 f1 00 00 00    	ja     84e9 <f23+0x469>
    83f8:	83 c0 01             	add    $0x1,%eax
    83fb:	88 07                	mov    %al,(%rdi)
    83fd:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8402:	31 d2                	xor    %edx,%edx
    8404:	4d 85 e4             	test   %r12,%r12
    8407:	0f 85 1e fd ff ff    	jne    812b <f23+0xab>
    840d:	e9 3b fd ff ff       	jmp    814d <f23+0xcd>
    8412:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8418:	66 85 c0             	test   %ax,%ax
    841b:	0f 85 06 ff ff ff    	jne    8327 <f23+0x2a7>
    8421:	e9 f5 fe ff ff       	jmp    831b <f23+0x29b>
    8426:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    842d:	00 00 00 
    8430:	66 85 c0             	test   %ax,%ax
    8433:	0f 85 d2 fd ff ff    	jne    820b <f23+0x18b>
    8439:	e9 bf fd ff ff       	jmp    81fd <f23+0x17d>
    843e:	66 90                	xchg   %ax,%ax
    8440:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8445:	e9 e6 fc ff ff       	jmp    8130 <f23+0xb0>
    844a:	66 85 c9             	test   %cx,%cx
    844d:	75 21                	jne    8470 <f23+0x3f0>
    844f:	0f b6 07             	movzbl (%rdi),%eax
    8452:	84 c0                	test   %al,%al
    8454:	74 1a                	je     8470 <f23+0x3f0>
    8456:	3c fd                	cmp    $0xfd,%al
    8458:	0f 87 be 00 00 00    	ja     851c <f23+0x49c>
    845e:	83 c0 01             	add    $0x1,%eax
    8461:	88 07                	mov    %al,(%rdi)
    8463:	66 90                	xchg   %ax,%ax
    8465:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    846c:	00 00 00 00 
    8470:	be 02 00 00 00       	mov    $0x2,%esi
    8475:	bf 08 00 00 00       	mov    $0x8,%edi
    847a:	e8 71 d8 ff ff       	call   5cf0 <fwp_heap_alloc>
    847f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8486:	48 8b 15 4b c7 01 00 	mov    0x1c74b(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    848d:	49 89 c6             	mov    %rax,%r14
    8490:	48 2b 05 19 c7 01 00 	sub    0x1c719(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    8497:	48 c1 e2 10          	shl    $0x10,%rdx
    849b:	48 39 d0             	cmp    %rdx,%rax
    849e:	73 53                	jae    84f3 <f23+0x473>
    84a0:	48 89 c2             	mov    %rax,%rdx
    84a3:	48 c1 ea 10          	shr    $0x10,%rdx
    84a7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    84ab:	48 8b 15 46 c7 01 00 	mov    0x1c746(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    84b2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    84b6:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    84ba:	48 85 ed             	test   %rbp,%rbp
    84bd:	74 34                	je     84f3 <f23+0x473>
    84bf:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    84c6:	00 00 
    84c8:	31 db                	xor    %ebx,%ebx
    84ca:	e9 04 fd ff ff       	jmp    81d3 <f23+0x153>
    84cf:	48 89 df             	mov    %rbx,%rdi
    84d2:	e8 d9 d0 ff ff       	call   55b0 <fwp_rc_forget_slot>
    84d7:	e9 48 fe ff ff       	jmp    8324 <f23+0x2a4>
    84dc:	48 89 ef             	mov    %rbp,%rdi
    84df:	e8 cc d0 ff ff       	call   55b0 <fwp_rc_forget_slot>
    84e4:	e9 1e fd ff ff       	jmp    8207 <f23+0x187>
    84e9:	e8 a2 cf ff ff       	call   5490 <fwp_rc_wide_dup>
    84ee:	e9 0a ff ff ff       	jmp    83fd <f23+0x37d>
    84f3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    84fa:	00 00 
    84fc:	e9 6c fd ff ff       	jmp    826d <f23+0x1ed>
    8501:	e8 8a cf ff ff       	call   5490 <fwp_rc_wide_dup>
    8506:	e9 1b fc ff ff       	jmp    8126 <f23+0xa6>
    850b:	e8 50 af ff ff       	call   3460 <__stack_chk_fail@plt>
    8510:	48 8d 3d 79 6c 00 00 	lea    0x6c79(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    8517:	e8 d4 be ff ff       	call   43f0 <fwp_trap>
    851c:	e8 6f cf ff ff       	call   5490 <fwp_rc_wide_dup>
    8521:	e9 4a ff ff ff       	jmp    8470 <f23+0x3f0>
    8526:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    852d:	00 00 00 

0000000000008530 <fwp_owned_entry23>:
    8530:	f3 0f 1e fa          	endbr64
    8534:	48 8b 3f             	mov    (%rdi),%rdi
    8537:	e9 44 fb ff ff       	jmp    8080 <f23>
    853c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008540 <e23>:
    8540:	f3 0f 1e fa          	endbr64
    8544:	53                   	push   %rbx
    8545:	48 8b 1f             	mov    (%rdi),%rbx
    8548:	48 89 df             	mov    %rbx,%rdi
    854b:	e8 d0 e1 ff ff       	call   6720 <fwp_rc_share>
    8550:	48 89 df             	mov    %rbx,%rdi
    8553:	e8 28 fb ff ff       	call   8080 <f23>
    8558:	48 89 c3             	mov    %rax,%rbx
    855b:	48 89 c7             	mov    %rax,%rdi
    855e:	e8 bd e1 ff ff       	call   6720 <fwp_rc_share>
    8563:	48 89 d8             	mov    %rbx,%rax
    8566:	5b                   	pop    %rbx
    8567:	c3                   	ret
    8568:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    856f:	00 

0000000000008570 <f12>:
    8570:	41 57                	push   %r15
    8572:	41 56                	push   %r14
    8574:	41 55                	push   %r13
    8576:	4c 8d 2d 03 ec ff ff 	lea    -0x13fd(%rip),%r13        # 7180 <fwp_tape_scope_release>
    857d:	41 54                	push   %r12
    857f:	55                   	push   %rbp
    8580:	53                   	push   %rbx
    8581:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
    8588:	48 8b 05 09 cf 01 00 	mov    0x1cf09(%rip),%rax        # 25498 <fwp_cleanups>
    858f:	48 8b 15 42 c6 01 00 	mov    0x1c642(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    8596:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    859d:	00 00 
    859f:	48 89 ac 24 f8 00 00 	mov    %rbp,0xf8(%rsp)
    85a6:	00 
    85a7:	48 89 fd             	mov    %rdi,%rbp
    85aa:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    85b1:	ff 
    85b2:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    85b7:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    85bc:	48 c1 e2 10          	shl    $0x10,%rdx
    85c0:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    85c5:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    85ca:	48 8d 44 24 60       	lea    0x60(%rsp),%rax
    85cf:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    85d4:	48 89 05 bd ce 01 00 	mov    %rax,0x1cebd(%rip)        # 25498 <fwp_cleanups>
    85db:	48 8d 05 2e aa 00 00 	lea    0xaa2e(%rip),%rax        # 13010 <fc23>
    85e2:	48 2b 05 c7 c5 01 00 	sub    0x1c5c7(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    85e9:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    85ee:	48 39 d0             	cmp    %rdx,%rax
    85f1:	73 5d                	jae    8650 <f12+0xe0>
    85f3:	48 89 c2             	mov    %rax,%rdx
    85f6:	48 c1 ea 10          	shr    $0x10,%rdx
    85fa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    85fe:	48 8b 15 f3 c5 01 00 	mov    0x1c5f3(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    8605:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8609:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    860d:	48 85 ff             	test   %rdi,%rdi
    8610:	74 3e                	je     8650 <f12+0xe0>
    8612:	0f b6 0a             	movzbl (%rdx),%ecx
    8615:	80 f9 02             	cmp    $0x2,%cl
    8618:	0f 84 1a 0f 00 00    	je     9538 <f12+0xfc8>
    861e:	80 f9 01             	cmp    $0x1,%cl
    8621:	75 2d                	jne    8650 <f12+0xe0>
    8623:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8626:	0f b7 c0             	movzwl %ax,%eax
    8629:	8b 52 1c             	mov    0x1c(%rdx),%edx
    862c:	48 0f af c1          	imul   %rcx,%rax
    8630:	48 c1 e8 20          	shr    $0x20,%rax
    8634:	48 39 d0             	cmp    %rdx,%rax
    8637:	73 17                	jae    8650 <f12+0xe0>
    8639:	48 01 c7             	add    %rax,%rdi
    863c:	0f b6 07             	movzbl (%rdi),%eax
    863f:	84 c0                	test   %al,%al
    8641:	74 0d                	je     8650 <f12+0xe0>
    8643:	3c fd                	cmp    $0xfd,%al
    8645:	0f 87 68 11 00 00    	ja     97b3 <f12+0x1243>
    864b:	83 c0 01             	add    $0x1,%eax
    864e:	88 07                	mov    %al,(%rdi)
    8650:	48 8d 3d b9 a9 00 00 	lea    0xa9b9(%rip),%rdi        # 13010 <fc23>
    8657:	e8 f4 e7 ff ff       	call   6e50 <fwp_closure_drop>
    865c:	48 85 ed             	test   %rbp,%rbp
    865f:	0f 84 af 10 00 00    	je     9714 <f12+0x11a4>
    8665:	48 89 e8             	mov    %rbp,%rax
    8668:	31 db                	xor    %ebx,%ebx
    866a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8670:	48 8b 40 10          	mov    0x10(%rax),%rax
    8674:	48 83 c3 01          	add    $0x1,%rbx
    8678:	48 85 c0             	test   %rax,%rax
    867b:	75 f3                	jne    8670 <f12+0x100>
    867d:	31 ff                	xor    %edi,%edi
    867f:	e8 cc bb ff ff       	call   4250 <descent_phase_step>
    8684:	48 81 fb ff ff ff 7f 	cmp    $0x7fffffff,%rbx
    868b:	0f 87 8c 11 00 00    	ja     981d <f12+0x12ad>
    8691:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    8696:	8b 35 e4 a9 00 00    	mov    0xa9e4(%rip),%esi        # 13080 <registered_finish.0>
    869c:	85 f6                	test   %esi,%esi
    869e:	0f 84 64 0e 00 00    	je     9508 <f12+0xf98>
    86a4:	48 8b 1d 6d aa 01 00 	mov    0x1aa6d(%rip),%rbx        # 23118 <fwp_tape_next_slot>
    86ab:	4c 8b 25 76 aa 01 00 	mov    0x1aa76(%rip),%r12        # 23128 <fwp_ntapes>
    86b2:	49 39 dc             	cmp    %rbx,%r12
    86b5:	0f 8e b5 05 00 00    	jle    8c70 <f12+0x700>
    86bb:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    86bf:	48 03 05 6a aa 01 00 	add    0x1aa6a(%rip),%rax        # 23130 <fwp_tapes>
    86c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    86cd:	00 00 00 
    86d0:	8b 48 04             	mov    0x4(%rax),%ecx
    86d3:	85 c9                	test   %ecx,%ecx
    86d5:	75 0c                	jne    86e3 <f12+0x173>
    86d7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    86dd:	0f 86 8d 05 00 00    	jbe    8c70 <f12+0x700>
    86e3:	48 83 c3 01          	add    $0x1,%rbx
    86e7:	48 83 c0 68          	add    $0x68,%rax
    86eb:	49 39 dc             	cmp    %rbx,%r12
    86ee:	75 e0                	jne    86d0 <f12+0x160>
    86f0:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    86f7:	0f 8f 44 11 00 00    	jg     9841 <f12+0x12d1>
    86fd:	4c 3b 25 1c aa 01 00 	cmp    0x1aa1c(%rip),%r12        # 23120 <fwp_tapes_cap>
    8704:	4c 8b 35 25 aa 01 00 	mov    0x1aa25(%rip),%r14        # 23130 <fwp_tapes>
    870b:	75 40                	jne    874d <f12+0x1dd>
    870d:	4d 85 e4             	test   %r12,%r12
    8710:	0f 85 8a 0f 00 00    	jne    96a0 <f12+0x1130>
    8716:	be 68 00 00 00       	mov    $0x68,%esi
    871b:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    8721:	4c 89 f7             	mov    %r14,%rdi
    8724:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8729:	e8 a2 ae ff ff       	call   35d0 <realloc@plt>
    872e:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8733:	48 85 c0             	test   %rax,%rax
    8736:	49 89 c6             	mov    %rax,%r14
    8739:	0f 84 46 0e 00 00    	je     9585 <f12+0x1015>
    873f:	48 89 05 ea a9 01 00 	mov    %rax,0x1a9ea(%rip)        # 23130 <fwp_tapes>
    8746:	4c 89 3d d3 a9 01 00 	mov    %r15,0x1a9d3(%rip)        # 23120 <fwp_tapes_cap>
    874d:	49 6b c4 68          	imul   $0x68,%r12,%rax
    8751:	49 83 c4 01          	add    $0x1,%r12
    8755:	4c 01 f0             	add    %r14,%rax
    8758:	48 8d 78 08          	lea    0x8(%rax),%rdi
    875c:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8763:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    8767:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    876e:	00 
    876f:	48 29 f8             	sub    %rdi,%rax
    8772:	8d 48 68             	lea    0x68(%rax),%ecx
    8775:	31 c0                	xor    %eax,%eax
    8777:	c1 e9 03             	shr    $0x3,%ecx
    877a:	f3 48 ab             	rep stos %rax,(%rdi)
    877d:	4c 89 25 a4 a9 01 00 	mov    %r12,0x1a9a4(%rip)        # 23128 <fwp_ntapes>
    8784:	4c 6b e3 68          	imul   $0x68,%rbx,%r12
    8788:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    878c:	48 8d 3d 8f 69 00 00 	lea    0x698f(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    8793:	0f 29 04 24          	movaps %xmm0,(%rsp)
    8797:	4d 01 f4             	add    %r14,%r12
    879a:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    87a1:	00 00 
    87a3:	e8 f8 ab ff ff       	call   33a0 <getenv@plt>
    87a8:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    87ad:	48 85 c0             	test   %rax,%rax
    87b0:	74 09                	je     87bb <f12+0x24b>
    87b2:	80 38 30             	cmpb   $0x30,(%rax)
    87b5:	0f 84 05 04 00 00    	je     8bc0 <f12+0x650>
    87bb:	48 83 3d 05 a9 01 00 	cmpq   $0x0,0x1a905(%rip)        # 230c8 <fwp_tape_cached_bytes>
    87c2:	00 
    87c3:	0f 85 17 0e 00 00    	jne    95e0 <f12+0x1070>
    87c9:	41 8b 04 24          	mov    (%r12),%eax
    87cd:	4c 8d 43 01          	lea    0x1(%rbx),%r8
    87d1:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    87d8:	00 00 
    87da:	4c 89 05 37 a9 01 00 	mov    %r8,0x1a937(%rip)        # 23118 <fwp_tape_next_slot>
    87e1:	8d 70 01             	lea    0x1(%rax),%esi
    87e4:	48 8b 05 ad cc 01 00 	mov    0x1ccad(%rip),%rax        # 25498 <fwp_cleanups>
    87eb:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    87f2:	00 00 
    87f4:	41 89 34 24          	mov    %esi,(%r12)
    87f8:	49 c7 44 24 58 ff ff 	movq   $0xffffffffffffffff,0x58(%r12)
    87ff:	ff ff 
    8801:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    8807:	48 85 c0             	test   %rax,%rax
    880a:	75 20                	jne    882c <f12+0x2bc>
    880c:	e9 4d 10 00 00       	jmp    985e <f12+0x12ee>
    8811:	0f 1f 40 00          	nopl   0x0(%rax)
    8815:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    881c:	00 00 00 00 
    8820:	48 8b 00             	mov    (%rax),%rax
    8823:	48 85 c0             	test   %rax,%rax
    8826:	0f 84 32 10 00 00    	je     985e <f12+0x12ee>
    882c:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    8830:	75 ee                	jne    8820 <f12+0x2b0>
    8832:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8836:	89 df                	mov    %ebx,%edi
    8838:	48 63 01             	movslq (%rcx),%rax
    883b:	49 89 4c 24 50       	mov    %rcx,0x50(%r12)
    8840:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    8845:	85 c0                	test   %eax,%eax
    8847:	78 09                	js     8852 <f12+0x2e2>
    8849:	48 6b c0 68          	imul   $0x68,%rax,%rax
    884d:	41 89 5c 06 58       	mov    %ebx,0x58(%r14,%rax,1)
    8852:	89 39                	mov    %edi,(%rcx)
    8854:	bf 01 00 00 00       	mov    $0x1,%edi
    8859:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    885e:	89 34 24             	mov    %esi,(%rsp)
    8861:	e8 ea b9 ff ff       	call   4250 <descent_phase_step>
    8866:	31 c9                	xor    %ecx,%ecx
    8868:	48 85 ed             	test   %rbp,%rbp
    886b:	8b 34 24             	mov    (%rsp),%esi
    886e:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    8873:	48 89 e8             	mov    %rbp,%rax
    8876:	0f 84 54 03 00 00    	je     8bd0 <f12+0x660>
    887c:	0f 1f 40 00          	nopl   0x0(%rax)
    8880:	48 8b 40 10          	mov    0x10(%rax),%rax
    8884:	48 83 c1 01          	add    $0x1,%rcx
    8888:	48 85 c0             	test   %rax,%rax
    888b:	75 f3                	jne    8880 <f12+0x310>
    888d:	48 89 ea             	mov    %rbp,%rdx
    8890:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8894:	48 83 c0 01          	add    $0x1,%rax
    8898:	48 85 d2             	test   %rdx,%rdx
    889b:	75 f3                	jne    8890 <f12+0x320>
    889d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    88a4:	ff ff 1f 
    88a7:	48 39 c2             	cmp    %rax,%rdx
    88aa:	0f 82 79 0f 00 00    	jb     9829 <f12+0x12b9>
    88b0:	48 85 c9             	test   %rcx,%rcx
    88b3:	0f 8e 17 03 00 00    	jle    8bd0 <f12+0x660>
    88b9:	48 39 c1             	cmp    %rax,%rcx
    88bc:	48 0f 46 c1          	cmovbe %rcx,%rax
    88c0:	49 89 c5             	mov    %rax,%r13
    88c3:	48 c1 e8 3c          	shr    $0x3c,%rax
    88c7:	0f 85 5c 0f 00 00    	jne    9829 <f12+0x12b9>
    88cd:	48 c1 e6 10          	shl    $0x10,%rsi
    88d1:	4f 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%r14
    88d6:	4c 09 c6             	or     %r8,%rsi
    88d9:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    88e0:	00 
    88e1:	49 89 f4             	mov    %rsi,%r12
    88e4:	be 02 00 00 00       	mov    $0x2,%esi
    88e9:	e8 02 d4 ff ff       	call   5cf0 <fwp_heap_alloc>
    88ee:	4c 89 30             	mov    %r14,(%rax)
    88f1:	48 8b 15 e0 c2 01 00 	mov    0x1c2e0(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    88f8:	48 89 c3             	mov    %rax,%rbx
    88fb:	48 2b 05 ae c2 01 00 	sub    0x1c2ae(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    8902:	48 c1 e2 10          	shl    $0x10,%rdx
    8906:	48 39 d0             	cmp    %rdx,%rax
    8909:	0f 83 41 03 00 00    	jae    8c50 <f12+0x6e0>
    890f:	48 89 c2             	mov    %rax,%rdx
    8912:	48 c1 ea 10          	shr    $0x10,%rdx
    8916:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    891a:	48 8b 15 d7 c2 01 00 	mov    0x1c2d7(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    8921:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8925:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8929:	48 85 d2             	test   %rdx,%rdx
    892c:	74 38                	je     8966 <f12+0x3f6>
    892e:	0f b6 31             	movzbl (%rcx),%esi
    8931:	40 80 fe 02          	cmp    $0x2,%sil
    8935:	0f 84 02 03 00 00    	je     8c3d <f12+0x6cd>
    893b:	40 80 fe 01          	cmp    $0x1,%sil
    893f:	75 25                	jne    8966 <f12+0x3f6>
    8941:	8b 71 18             	mov    0x18(%rcx),%esi
    8944:	0f b7 c0             	movzwl %ax,%eax
    8947:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    894a:	48 0f af c6          	imul   %rsi,%rax
    894e:	48 c1 e8 20          	shr    $0x20,%rax
    8952:	48 39 c8             	cmp    %rcx,%rax
    8955:	73 0f                	jae    8966 <f12+0x3f6>
    8957:	48 01 c2             	add    %rax,%rdx
    895a:	80 3a ff             	cmpb   $0xff,(%rdx)
    895d:	0f 84 19 0e 00 00    	je     977c <f12+0x120c>
    8963:	c6 02 01             	movb   $0x1,(%rdx)
    8966:	4d 85 ed             	test   %r13,%r13
    8969:	74 48                	je     89b3 <f12+0x443>
    896b:	4c 89 e1             	mov    %r12,%rcx
    896e:	48 89 ea             	mov    %rbp,%rdx
    8971:	31 c0                	xor    %eax,%eax
    8973:	48 c1 e1 20          	shl    $0x20,%rcx
    8977:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    897e:	00 00 
    8980:	48 89 c6             	mov    %rax,%rsi
    8983:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8988:	48 01 ce             	add    %rcx,%rsi
    898b:	0f 80 7f 0e 00 00    	jo     9810 <f12+0x12a0>
    8991:	66 48 0f 6e de       	movq   %rsi,%xmm3
    8996:	48 89 c6             	mov    %rax,%rsi
    8999:	48 83 c0 01          	add    $0x1,%rax
    899d:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    89a1:	48 c1 e6 04          	shl    $0x4,%rsi
    89a5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    89aa:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    89ae:	4c 39 e8             	cmp    %r13,%rax
    89b1:	72 cd                	jb     8980 <f12+0x410>
    89b3:	48 8b 03             	mov    (%rbx),%rax
    89b6:	48 d1 e8             	shr    $1,%rax
    89b9:	0f 84 a1 02 00 00    	je     8c60 <f12+0x6f0>
    89bf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    89c3:	48 89 d1             	mov    %rdx,%rcx
    89c6:	48 c1 e9 3c          	shr    $0x3c,%rcx
    89ca:	0f 85 59 0e 00 00    	jne    9829 <f12+0x12b9>
    89d0:	4c 8d 34 12          	lea    (%rdx,%rdx,1),%r14
    89d4:	48 85 d2             	test   %rdx,%rdx
    89d7:	74 45                	je     8a1e <f12+0x4ae>
    89d9:	48 c1 e0 04          	shl    $0x4,%rax
    89dd:	4c 8d 7b 08          	lea    0x8(%rbx),%r15
    89e1:	4c 8d 6c 03 f8       	lea    -0x8(%rbx,%rax,1),%r13
    89e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    89ed:	00 00 00 
    89f0:	f2 41 0f 10 07       	movsd  (%r15),%xmm0
    89f5:	49 8b 77 18          	mov    0x18(%r15),%rsi
    89f9:	49 83 c7 10          	add    $0x10,%r15
    89fd:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
    8a01:	f2 41 0f 10 0f       	movsd  (%r15),%xmm1
    8a06:	e8 c5 d9 ff ff       	call   63d0 <w107>
    8a0b:	66 48 0f 6e e0       	movq   %rax,%xmm4
    8a10:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    8a14:	41 0f 11 47 f0       	movups %xmm0,-0x10(%r15)
    8a19:	4d 39 fd             	cmp    %r15,%r13
    8a1c:	75 d2                	jne    89f0 <f12+0x480>
    8a1e:	4c 89 33             	mov    %r14,(%rbx)
    8a21:	48 89 df             	mov    %rbx,%rdi
    8a24:	e8 27 db ff ff       	call   6550 <w164.constprop.0>
    8a29:	48 89 df             	mov    %rbx,%rdi
    8a2c:	49 63 dc             	movslq %r12d,%rbx
    8a2f:	49 89 c5             	mov    %rax,%r13
    8a32:	e8 29 ed ff ff       	call   7760 <fwp_drop4>
    8a37:	bf 02 00 00 00       	mov    $0x2,%edi
    8a3c:	e8 1f c5 ff ff       	call   4f60 <caf61>
    8a41:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    8a46:	e8 05 b8 ff ff       	call   4250 <descent_phase_step>
    8a4b:	48 89 df             	mov    %rbx,%rdi
    8a4e:	e8 7d bc ff ff       	call   46d0 <fwp_tape_of>
    8a53:	48 89 c6             	mov    %rax,%rsi
    8a56:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    8a5b:	0f 85 ec 0d 00 00    	jne    984d <f12+0x12dd>
    8a61:	48 89 c7             	mov    %rax,%rdi
    8a64:	e8 97 b1 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    8a69:	f3 0f 6f 76 20       	movdqu 0x20(%rsi),%xmm6
    8a6e:	4c 8b 56 48          	mov    0x48(%rsi),%r10
    8a72:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    8a79:	f3 0f 6f 7e 30       	movdqu 0x30(%rsi),%xmm7
    8a7e:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    8a83:	0f 29 74 24 10       	movaps %xmm6,0x10(%rsp)
    8a88:	66 49 0f 6e f2       	movq   %r10,%xmm6
    8a8d:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    8a91:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    8a95:	4c 8b 7e 40          	mov    0x40(%rsi),%r15
    8a99:	0f 29 3c 24          	movaps %xmm7,(%rsp)
    8a9d:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    8aa1:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    8aa7:	77 19                	ja     8ac2 <f12+0x552>
    8aa9:	41 0f b7 c4          	movzwl %r12w,%eax
    8aad:	83 e8 01             	sub    $0x1,%eax
    8ab0:	48 98                	cltq
    8ab2:	48 3b 05 5f a6 01 00 	cmp    0x1a65f(%rip),%rax        # 23118 <fwp_tape_next_slot>
    8ab9:	7d 07                	jge    8ac2 <f12+0x552>
    8abb:	48 89 05 56 a6 01 00 	mov    %rax,0x1a656(%rip)        # 23118 <fwp_tape_next_slot>
    8ac2:	48 8b 05 cf c9 01 00 	mov    0x1c9cf(%rip),%rax        # 25498 <fwp_cleanups>
    8ac9:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8acd:	66 0f 6f 7c 24 10    	movdqa 0x10(%rsp),%xmm7
    8ad3:	4c 8d a4 24 a0 00 00 	lea    0xa0(%rsp),%r12
    8ada:	00 
    8adb:	66 0f 6f 34 24       	movdqa (%rsp),%xmm6
    8ae0:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8ae4:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    8aeb:	00 
    8aec:	48 8d 05 dd c5 ff ff 	lea    -0x3a23(%rip),%rax        # 50d0 <fwp_tape_buffers_release>
    8af3:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    8afa:	00 
    8afb:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    8b02:	00 
    8b03:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    8b0a:	00 
    8b0b:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    8b0f:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    8b13:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    8b1a:	00 
    8b1b:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    8b22:	00 
    8b23:	4c 89 bc 24 c0 00 00 	mov    %r15,0xc0(%rsp)
    8b2a:	00 
    8b2b:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    8b32:	00 
    8b33:	48 89 05 5e c9 01 00 	mov    %rax,0x1c95e(%rip)        # 25498 <fwp_cleanups>
    8b3a:	0f 29 bc 24 a0 00 00 	movaps %xmm7,0xa0(%rsp)
    8b41:	00 
    8b42:	0f 29 b4 24 b0 00 00 	movaps %xmm6,0xb0(%rsp)
    8b49:	00 
    8b4a:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    8b51:	00 
    8b52:	4d 85 ed             	test   %r13,%r13
    8b55:	0f 88 f5 09 00 00    	js     9550 <f12+0xfe0>
    8b5b:	4c 89 e8             	mov    %r13,%rax
    8b5e:	48 c1 f8 20          	sar    $0x20,%rax
    8b62:	48 39 c3             	cmp    %rax,%rbx
    8b65:	0f 85 8d 0c 00 00    	jne    97f8 <f12+0x1288>
    8b6b:	45 89 e9             	mov    %r13d,%r9d
    8b6e:	4c 89 cb             	mov    %r9,%rbx
    8b71:	4c 39 ca             	cmp    %r9,%rdx
    8b74:	0f 8e 72 0c 00 00    	jle    97ec <f12+0x127c>
    8b7a:	4d 39 ce             	cmp    %r9,%r14
    8b7d:	0f 8e 05 01 00 00    	jle    8c88 <f12+0x718>
    8b83:	4d 39 d6             	cmp    %r10,%r14
    8b86:	0f 8f cc 0a 00 00    	jg     9658 <f12+0x10e8>
    8b8c:	4d 85 ff             	test   %r15,%r15
    8b8f:	0f 84 d9 09 00 00    	je     956e <f12+0xffe>
    8b95:	31 f6                	xor    %esi,%esi
    8b97:	4c 89 ff             	mov    %r15,%rdi
    8b9a:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
    8b9f:	49 8d 5e ff          	lea    -0x1(%r14),%rbx
    8ba3:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    8baa:	00 
    8bab:	e8 10 a9 ff ff       	call   34c0 <memset@plt>
    8bb0:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
    8bb5:	45 31 d2             	xor    %r10d,%r10d
    8bb8:	e9 64 01 00 00       	jmp    8d21 <f12+0x7b1>
    8bbd:	0f 1f 00             	nopl   (%rax)
    8bc0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    8bc4:	0f 84 ff fb ff ff    	je     87c9 <f12+0x259>
    8bca:	e9 ec fb ff ff       	jmp    87bb <f12+0x24b>
    8bcf:	90                   	nop
    8bd0:	48 c1 e6 10          	shl    $0x10,%rsi
    8bd4:	bf 08 00 00 00       	mov    $0x8,%edi
    8bd9:	4c 09 c6             	or     %r8,%rsi
    8bdc:	49 89 f4             	mov    %rsi,%r12
    8bdf:	be 02 00 00 00       	mov    $0x2,%esi
    8be4:	e8 07 d1 ff ff       	call   5cf0 <fwp_heap_alloc>
    8be9:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8bf0:	48 8b 15 e1 bf 01 00 	mov    0x1bfe1(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    8bf7:	48 89 c3             	mov    %rax,%rbx
    8bfa:	48 2b 05 af bf 01 00 	sub    0x1bfaf(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    8c01:	48 c1 e2 10          	shl    $0x10,%rdx
    8c05:	48 39 d0             	cmp    %rdx,%rax
    8c08:	73 56                	jae    8c60 <f12+0x6f0>
    8c0a:	48 89 c2             	mov    %rax,%rdx
    8c0d:	48 c1 ea 10          	shr    $0x10,%rdx
    8c11:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8c15:	48 8b 15 dc bf 01 00 	mov    0x1bfdc(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    8c1c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8c20:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8c24:	48 85 d2             	test   %rdx,%rdx
    8c27:	0f 84 86 fd ff ff    	je     89b3 <f12+0x443>
    8c2d:	0f b6 31             	movzbl (%rcx),%esi
    8c30:	45 31 ed             	xor    %r13d,%r13d
    8c33:	40 80 fe 02          	cmp    $0x2,%sil
    8c37:	0f 85 fe fc ff ff    	jne    893b <f12+0x3cb>
    8c3d:	66 85 c0             	test   %ax,%ax
    8c40:	0f 85 20 fd ff ff    	jne    8966 <f12+0x3f6>
    8c46:	e9 0f fd ff ff       	jmp    895a <f12+0x3ea>
    8c4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8c50:	4d 85 ed             	test   %r13,%r13
    8c53:	0f 85 12 fd ff ff    	jne    896b <f12+0x3fb>
    8c59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8c60:	45 31 f6             	xor    %r14d,%r14d
    8c63:	e9 b6 fd ff ff       	jmp    8a1e <f12+0x4ae>
    8c68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8c6f:	00 
    8c70:	4c 39 e3             	cmp    %r12,%rbx
    8c73:	0f 84 77 fa ff ff    	je     86f0 <f12+0x180>
    8c79:	4c 8b 35 b0 a4 01 00 	mov    0x1a4b0(%rip),%r14        # 23130 <fwp_tapes>
    8c80:	e9 ff fa ff ff       	jmp    8784 <f12+0x214>
    8c85:	0f 1f 00             	nopl   (%rax)
    8c88:	49 8d 51 01          	lea    0x1(%r9),%rdx
    8c8c:	49 39 d2             	cmp    %rdx,%r10
    8c8f:	0f 8d cb 09 00 00    	jge    9660 <f12+0x10f0>
    8c95:	4d 85 d2             	test   %r10,%r10
    8c98:	4c 0f 44 d2          	cmove  %rdx,%r10
    8c9c:	eb 17                	jmp    8cb5 <f12+0x745>
    8c9e:	66 90                	xchg   %ax,%ax
    8ca0:	4b 8d 34 12          	lea    (%r10,%r10,1),%rsi
    8ca4:	49 81 fa 00 00 00 40 	cmp    $0x40000000,%r10
    8cab:	48 89 d0             	mov    %rdx,%rax
    8cae:	48 0f 4c c6          	cmovl  %rsi,%rax
    8cb2:	49 89 c2             	mov    %rax,%r10
    8cb5:	49 39 d2             	cmp    %rdx,%r10
    8cb8:	7c e6                	jl     8ca0 <f12+0x730>
    8cba:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
    8cbf:	4d 85 ff             	test   %r15,%r15
    8cc2:	0f 84 28 0a 00 00    	je     96f0 <f12+0x1180>
    8cc8:	4a 8d 34 d5 00 00 00 	lea    0x0(,%r10,8),%rsi
    8ccf:	00 
    8cd0:	4c 89 ff             	mov    %r15,%rdi
    8cd3:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
    8cd8:	e8 f3 a8 ff ff       	call   35d0 <realloc@plt>
    8cdd:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
    8ce2:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
    8ce7:	49 89 c7             	mov    %rax,%r15
    8cea:	4d 85 ff             	test   %r15,%r15
    8ced:	0f 84 69 08 00 00    	je     955c <f12+0xfec>
    8cf3:	4c 89 bc 24 c0 00 00 	mov    %r15,0xc0(%rsp)
    8cfa:	00 
    8cfb:	4c 89 94 24 d0 00 00 	mov    %r10,0xd0(%rsp)
    8d02:	00 
    8d03:	48 85 d2             	test   %rdx,%rdx
    8d06:	0f 85 b1 0a 00 00    	jne    97bd <f12+0x124d>
    8d0c:	4d 89 f2             	mov    %r14,%r10
    8d0f:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    8d16:	49 f7 da             	neg    %r10
    8d19:	4d 85 ed             	test   %r13,%r13
    8d1c:	78 15                	js     8d33 <f12+0x7c3>
    8d1e:	45 89 e9             	mov    %r13d,%r9d
    8d21:	f2 0f 10 44 24 38    	movsd  0x38(%rsp),%xmm0
    8d27:	f2 43 0f 58 04 cf    	addsd  (%r15,%r9,8),%xmm0
    8d2d:	f2 43 0f 11 04 cf    	movsd  %xmm0,(%r15,%r9,8)
    8d33:	bf 03 00 00 00       	mov    $0x3,%edi
    8d38:	4c 01 35 01 a4 01 00 	add    %r14,0x1a401(%rip)        # 23140 <descent_inputs>
    8d3f:	4c 01 15 02 a4 01 00 	add    %r10,0x1a402(%rip)        # 23148 <descent_nodes>
    8d46:	e8 05 b5 ff ff       	call   4250 <descent_phase_step>
    8d4b:	4c 39 f3             	cmp    %r14,%rbx
    8d4e:	0f 8c 86 00 00 00    	jl     8dda <f12+0x86a>
    8d54:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    8d59:	4c 8b 14 24          	mov    (%rsp),%r10
    8d5d:	4c 29 f3             	sub    %r14,%rbx
    8d60:	4f 8d 0c f7          	lea    (%r15,%r14,8),%r9
    8d64:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    8d69:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    8d6e:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8d72:	49 8d 14 db          	lea    (%r11,%rbx,8),%rdx
    8d76:	4d 29 d9             	sub    %r11,%r9
    8d79:	4d 29 da             	sub    %r11,%r10
    8d7c:	48 8d 04 9f          	lea    (%rdi,%rbx,4),%rax
    8d80:	48 29 fe             	sub    %rdi,%rsi
    8d83:	eb 07                	jmp    8d8c <f12+0x81c>
    8d85:	0f 1f 00             	nopl   (%rax)
    8d88:	48 83 e8 04          	sub    $0x4,%rax
    8d8c:	f2 41 0f 10 04 11    	movsd  (%r9,%rdx,1),%xmm0
    8d92:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    8d96:	7a 02                	jp     8d9a <f12+0x82a>
    8d98:	74 37                	je     8dd1 <f12+0x861>
    8d9a:	4c 63 1c 06          	movslq (%rsi,%rax,1),%r11
    8d9e:	45 85 db             	test   %r11d,%r11d
    8da1:	78 16                	js     8db9 <f12+0x849>
    8da3:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    8da9:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    8dad:	f2 43 0f 58 0c df    	addsd  (%r15,%r11,8),%xmm1
    8db3:	f2 43 0f 11 0c df    	movsd  %xmm1,(%r15,%r11,8)
    8db9:	4c 63 18             	movslq (%rax),%r11
    8dbc:	45 85 db             	test   %r11d,%r11d
    8dbf:	78 10                	js     8dd1 <f12+0x861>
    8dc1:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    8dc5:	f2 43 0f 58 04 df    	addsd  (%r15,%r11,8),%xmm0
    8dcb:	f2 43 0f 11 04 df    	movsd  %xmm0,(%r15,%r11,8)
    8dd1:	48 83 ea 08          	sub    $0x8,%rdx
    8dd5:	48 39 c7             	cmp    %rax,%rdi
    8dd8:	75 ae                	jne    8d88 <f12+0x818>
    8dda:	bf 04 00 00 00       	mov    $0x4,%edi
    8ddf:	e8 6c b4 ff ff       	call   4250 <descent_phase_step>
    8de4:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8deb:	ff ff 1f 
    8dee:	4c 39 f0             	cmp    %r14,%rax
    8df1:	0f 82 3e 0a 00 00    	jb     9835 <f12+0x12c5>
    8df7:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8dfe:	00 
    8dff:	be 02 00 00 00       	mov    $0x2,%esi
    8e04:	e8 e7 ce ff ff       	call   5cf0 <fwp_heap_alloc>
    8e09:	4c 89 30             	mov    %r14,(%rax)
    8e0c:	49 89 c5             	mov    %rax,%r13
    8e0f:	31 c0                	xor    %eax,%eax
    8e11:	4d 85 f6             	test   %r14,%r14
    8e14:	74 1c                	je     8e32 <f12+0x8c2>
    8e16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8e1d:	00 00 00 
    8e20:	49 8b 14 c7          	mov    (%r15,%rax,8),%rdx
    8e24:	49 89 54 c5 08       	mov    %rdx,0x8(%r13,%rax,8)
    8e29:	48 83 c0 01          	add    $0x1,%rax
    8e2d:	49 39 c6             	cmp    %rax,%r14
    8e30:	75 ee                	jne    8e20 <f12+0x8b0>
    8e32:	bf 05 00 00 00       	mov    $0x5,%edi
    8e37:	e8 14 b4 ff ff       	call   4250 <descent_phase_step>
    8e3c:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
    8e43:	00 
    8e44:	4c 89 e7             	mov    %r12,%rdi
    8e47:	48 89 0d 4a c6 01 00 	mov    %rcx,0x1c64a(%rip)        # 25498 <fwp_cleanups>
    8e4e:	48 89 0c 24          	mov    %rcx,(%rsp)
    8e52:	e8 79 c2 ff ff       	call   50d0 <fwp_tape_buffers_release>
    8e57:	bf 06 00 00 00       	mov    $0x6,%edi
    8e5c:	e8 ef b3 ff ff       	call   4250 <descent_phase_step>
    8e61:	48 8b 15 70 bd 01 00 	mov    0x1bd70(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    8e68:	4c 89 e8             	mov    %r13,%rax
    8e6b:	48 8b 0c 24          	mov    (%rsp),%rcx
    8e6f:	48 2b 05 3a bd 01 00 	sub    0x1bd3a(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    8e76:	48 c1 e2 10          	shl    $0x10,%rdx
    8e7a:	48 39 d0             	cmp    %rdx,%rax
    8e7d:	73 57                	jae    8ed6 <f12+0x966>
    8e7f:	48 89 c2             	mov    %rax,%rdx
    8e82:	48 c1 ea 10          	shr    $0x10,%rdx
    8e86:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8e8a:	48 8b 15 67 bd 01 00 	mov    0x1bd67(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    8e91:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    8e95:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    8e99:	48 85 db             	test   %rbx,%rbx
    8e9c:	74 38                	je     8ed6 <f12+0x966>
    8e9e:	0f b6 32             	movzbl (%rdx),%esi
    8ea1:	40 80 fe 02          	cmp    $0x2,%sil
    8ea5:	0f 84 0d 07 00 00    	je     95b8 <f12+0x1048>
    8eab:	40 80 fe 01          	cmp    $0x1,%sil
    8eaf:	75 25                	jne    8ed6 <f12+0x966>
    8eb1:	8b 72 18             	mov    0x18(%rdx),%esi
    8eb4:	0f b7 c0             	movzwl %ax,%eax
    8eb7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8eba:	48 0f af c6          	imul   %rsi,%rax
    8ebe:	48 c1 e8 20          	shr    $0x20,%rax
    8ec2:	48 39 d0             	cmp    %rdx,%rax
    8ec5:	73 0f                	jae    8ed6 <f12+0x966>
    8ec7:	48 01 c3             	add    %rax,%rbx
    8eca:	80 3b ff             	cmpb   $0xff,(%rbx)
    8ecd:	0f 84 be 08 00 00    	je     9791 <f12+0x1221>
    8ed3:	c6 03 01             	movb   $0x1,(%rbx)
    8ed6:	48 3b 4c 24 30       	cmp    0x30(%rsp),%rcx
    8edb:	0f 85 6a a8 ff ff    	jne    374b <f12.cold>
    8ee1:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    8ee6:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    8eeb:	48 89 05 a6 c5 01 00 	mov    %rax,0x1c5a6(%rip)        # 25498 <fwp_cleanups>
    8ef2:	e8 89 e2 ff ff       	call   7180 <fwp_tape_scope_release>
    8ef7:	49 8b 45 00          	mov    0x0(%r13),%rax
    8efb:	49 89 c4             	mov    %rax,%r12
    8efe:	49 0f ba f4 3f       	btr    $0x3f,%r12
    8f03:	48 85 c0             	test   %rax,%rax
    8f06:	0f 88 34 05 00 00    	js     9440 <f12+0xed0>
    8f0c:	48 8b 15 c5 bc 01 00 	mov    0x1bcc5(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    8f13:	4c 89 e8             	mov    %r13,%rax
    8f16:	48 2b 05 93 bc 01 00 	sub    0x1bc93(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    8f1d:	48 c1 e2 10          	shl    $0x10,%rdx
    8f21:	48 39 d0             	cmp    %rdx,%rax
    8f24:	0f 83 16 05 00 00    	jae    9440 <f12+0xed0>
    8f2a:	48 89 c2             	mov    %rax,%rdx
    8f2d:	48 c1 ea 10          	shr    $0x10,%rdx
    8f31:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8f35:	48 8b 15 bc bc 01 00 	mov    0x1bcbc(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    8f3c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8f40:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    8f44:	48 85 c9             	test   %rcx,%rcx
    8f47:	0f 84 f3 04 00 00    	je     9440 <f12+0xed0>
    8f4d:	0f b6 32             	movzbl (%rdx),%esi
    8f50:	40 80 fe 02          	cmp    $0x2,%sil
    8f54:	0f 84 d6 04 00 00    	je     9430 <f12+0xec0>
    8f5a:	40 80 fe 01          	cmp    $0x1,%sil
    8f5e:	0f 85 dc 04 00 00    	jne    9440 <f12+0xed0>
    8f64:	8b 72 18             	mov    0x18(%rdx),%esi
    8f67:	0f b7 c0             	movzwl %ax,%eax
    8f6a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8f6d:	48 0f af c6          	imul   %rsi,%rax
    8f71:	48 c1 e8 20          	shr    $0x20,%rax
    8f75:	48 39 d0             	cmp    %rdx,%rax
    8f78:	0f 83 c2 04 00 00    	jae    9440 <f12+0xed0>
    8f7e:	48 01 c1             	add    %rax,%rcx
    8f81:	80 39 01             	cmpb   $0x1,(%rcx)
    8f84:	0f 85 b6 04 00 00    	jne    9440 <f12+0xed0>
    8f8a:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    8f8f:	4d 89 ef             	mov    %r13,%r15
    8f92:	31 ff                	xor    %edi,%edi
    8f94:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8f99:	f2 0f 10 0d 9f 6c 00 	movsd  0x6c9f(%rip),%xmm1        # fc40 <msg.8+0xd0>
    8fa0:	00 
    8fa1:	48 8d 50 08          	lea    0x8(%rax),%rdx
    8fa5:	31 c0                	xor    %eax,%eax
    8fa7:	4d 85 e4             	test   %r12,%r12
    8faa:	75 29                	jne    8fd5 <f12+0xa65>
    8fac:	eb 42                	jmp    8ff0 <f12+0xa80>
    8fae:	66 90                	xchg   %ax,%ax
    8fb0:	49 83 3f 00          	cmpq   $0x0,(%r15)
    8fb4:	0f 88 4a 08 00 00    	js     9804 <f12+0x1294>
    8fba:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    8fbf:	48 83 c0 01          	add    $0x1,%rax
    8fc3:	48 83 c2 08          	add    $0x8,%rdx
    8fc7:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    8fcb:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8fd0:	49 39 c4             	cmp    %rax,%r12
    8fd3:	74 1b                	je     8ff0 <f12+0xa80>
    8fd5:	49 8d 4d 08          	lea    0x8(%r13),%rcx
    8fd9:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    8fde:	79 d0                	jns    8fb0 <f12+0xa40>
    8fe0:	49 8b 4d 10          	mov    0x10(%r13),%rcx
    8fe4:	eb ca                	jmp    8fb0 <f12+0xa40>
    8fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8fed:	00 00 00 
    8ff0:	e8 6b e7 ff ff       	call   7760 <fwp_drop4>
    8ff5:	48 89 e8             	mov    %rbp,%rax
    8ff8:	31 d2                	xor    %edx,%edx
    8ffa:	48 85 ed             	test   %rbp,%rbp
    8ffd:	0f 84 21 07 00 00    	je     9724 <f12+0x11b4>
    9003:	66 90                	xchg   %ax,%ax
    9005:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    900c:	00 00 00 00 
    9010:	48 8b 40 10          	mov    0x10(%rax),%rax
    9014:	48 83 c2 01          	add    $0x1,%rdx
    9018:	48 85 c0             	test   %rax,%rax
    901b:	75 f3                	jne    9010 <f12+0xaa0>
    901d:	49 8b 07             	mov    (%r15),%rax
    9020:	49 89 c5             	mov    %rax,%r13
    9023:	49 0f ba f5 3f       	btr    $0x3f,%r13
    9028:	48 85 c0             	test   %rax,%rax
    902b:	0f 88 61 03 00 00    	js     9392 <f12+0xe22>
    9031:	48 8b 05 a0 bb 01 00 	mov    0x1bba0(%rip),%rax        # 24bd8 <fwp_heap+0x13d8>
    9038:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    903d:	48 2b 0d 6c bb 01 00 	sub    0x1bb6c(%rip),%rcx        # 24bb0 <fwp_heap+0x13b0>
    9044:	48 c1 e0 10          	shl    $0x10,%rax
    9048:	48 39 c1             	cmp    %rax,%rcx
    904b:	0f 83 41 03 00 00    	jae    9392 <f12+0xe22>
    9051:	48 89 c8             	mov    %rcx,%rax
    9054:	48 c1 e8 10          	shr    $0x10,%rax
    9058:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    905c:	48 8b 05 95 bb 01 00 	mov    0x1bb95(%rip),%rax        # 24bf8 <fwp_heap+0x13f8>
    9063:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    9067:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    906b:	48 85 ff             	test   %rdi,%rdi
    906e:	0f 84 1e 03 00 00    	je     9392 <f12+0xe22>
    9074:	0f b6 06             	movzbl (%rsi),%eax
    9077:	3c 02                	cmp    $0x2,%al
    9079:	0f 84 01 03 00 00    	je     9380 <f12+0xe10>
    907f:	3c 01                	cmp    $0x1,%al
    9081:	0f 85 02 03 00 00    	jne    9389 <f12+0xe19>
    9087:	8b 46 18             	mov    0x18(%rsi),%eax
    908a:	0f b7 c9             	movzwl %cx,%ecx
    908d:	48 0f af c8          	imul   %rax,%rcx
    9091:	8b 46 1c             	mov    0x1c(%rsi),%eax
    9094:	48 c1 e9 20          	shr    $0x20,%rcx
    9098:	48 39 c1             	cmp    %rax,%rcx
    909b:	0f 83 e8 02 00 00    	jae    9389 <f12+0xe19>
    90a1:	48 01 cf             	add    %rcx,%rdi
    90a4:	80 3f 01             	cmpb   $0x1,(%rdi)
    90a7:	0f 85 dc 02 00 00    	jne    9389 <f12+0xe19>
    90ad:	49 39 d5             	cmp    %rdx,%r13
    90b0:	48 89 d0             	mov    %rdx,%rax
    90b3:	49 0f 46 c5          	cmovbe %r13,%rax
    90b7:	48 85 c0             	test   %rax,%rax
    90ba:	0f 84 55 07 00 00    	je     9815 <f12+0x12a5>
    90c0:	c7 44 24 28 01 00 00 	movl   $0x1,0x28(%rsp)
    90c7:	00 
    90c8:	4d 8d 77 08          	lea    0x8(%r15),%r14
    90cc:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    90d1:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    90d8:	00 
    90d9:	48 89 e9             	mov    %rbp,%rcx
    90dc:	31 d2                	xor    %edx,%edx
    90de:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    90e2:	eb 39                	jmp    911d <f12+0xbad>
    90e4:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    90ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    90f1:	00 00 00 00 
    90f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    90fc:	00 00 00 00 
    9100:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9105:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    910a:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    9110:	48 83 c2 08          	add    $0x8,%rdx
    9114:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9118:	49 39 d0             	cmp    %rdx,%r8
    911b:	74 1b                	je     9138 <f12+0xbc8>
    911d:	48 89 fe             	mov    %rdi,%rsi
    9120:	49 83 3f 00          	cmpq   $0x0,(%r15)
    9124:	79 da                	jns    9100 <f12+0xb90>
    9126:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    912b:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    912f:	eb cf                	jmp    9100 <f12+0xb90>
    9131:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9138:	48 85 ed             	test   %rbp,%rbp
    913b:	0f 84 a3 06 00 00    	je     97e4 <f12+0x1274>
    9141:	4c 8b 05 90 ba 01 00 	mov    0x1ba90(%rip),%r8        # 24bd8 <fwp_heap+0x13d8>
    9148:	4c 8b 0d 61 ba 01 00 	mov    0x1ba61(%rip),%r9        # 24bb0 <fwp_heap+0x13b0>
    914f:	48 89 e9             	mov    %rbp,%rcx
    9152:	45 31 ed             	xor    %r13d,%r13d
    9155:	4c 8b 15 9c ba 01 00 	mov    0x1ba9c(%rip),%r10        # 24bf8 <fwp_heap+0x13f8>
    915c:	49 c1 e0 10          	shl    $0x10,%r8
    9160:	eb 1c                	jmp    917e <f12+0xc0e>
    9162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9168:	49 83 c5 01          	add    $0x1,%r13
    916c:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9170:	49 39 c5             	cmp    %rax,%r13
    9173:	0f 83 67 01 00 00    	jae    92e0 <f12+0xd70>
    9179:	48 85 c9             	test   %rcx,%rcx
    917c:	74 56                	je     91d4 <f12+0xc64>
    917e:	48 89 ca             	mov    %rcx,%rdx
    9181:	4c 29 ca             	sub    %r9,%rdx
    9184:	4c 39 c2             	cmp    %r8,%rdx
    9187:	73 4b                	jae    91d4 <f12+0xc64>
    9189:	48 89 d6             	mov    %rdx,%rsi
    918c:	48 c1 ee 10          	shr    $0x10,%rsi
    9190:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    9194:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    9198:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    919c:	48 85 ff             	test   %rdi,%rdi
    919f:	74 33                	je     91d4 <f12+0xc64>
    91a1:	44 0f b6 1e          	movzbl (%rsi),%r11d
    91a5:	41 80 fb 02          	cmp    $0x2,%r11b
    91a9:	0f 84 19 01 00 00    	je     92c8 <f12+0xd58>
    91af:	41 80 fb 01          	cmp    $0x1,%r11b
    91b3:	75 1f                	jne    91d4 <f12+0xc64>
    91b5:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    91b9:	0f b7 d2             	movzwl %dx,%edx
    91bc:	8b 76 1c             	mov    0x1c(%rsi),%esi
    91bf:	49 0f af d3          	imul   %r11,%rdx
    91c3:	48 c1 ea 20          	shr    $0x20,%rdx
    91c7:	48 39 f2             	cmp    %rsi,%rdx
    91ca:	73 08                	jae    91d4 <f12+0xc64>
    91cc:	48 01 d7             	add    %rdx,%rdi
    91cf:	80 3f 01             	cmpb   $0x1,(%rdi)
    91d2:	74 94                	je     9168 <f12+0xbf8>
    91d4:	49 39 c5             	cmp    %rax,%r13
    91d7:	0f 83 03 01 00 00    	jae    92e0 <f12+0xd70>
    91dd:	49 89 c7             	mov    %rax,%r15
    91e0:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
    91e7:	00 
    91e8:	45 31 e4             	xor    %r12d,%r12d
    91eb:	48 89 04 24          	mov    %rax,(%rsp)
    91ef:	48 8d 1d 0a a6 01 00 	lea    0x1a60a(%rip),%rbx        # 23800 <fwp_heap>
    91f6:	eb 3a                	jmp    9232 <f12+0xcc2>
    91f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    91ff:	00 
    9200:	41 80 f9 01          	cmp    $0x1,%r9b
    9204:	75 27                	jne    922d <f12+0xcbd>
    9206:	45 8b 48 18          	mov    0x18(%r8),%r9d
    920a:	0f b7 c0             	movzwl %ax,%eax
    920d:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    9211:	49 0f af c1          	imul   %r9,%rax
    9215:	48 c1 e8 20          	shr    $0x20,%rax
    9219:	4c 39 c0             	cmp    %r8,%rax
    921c:	73 0f                	jae    922d <f12+0xcbd>
    921e:	48 01 c7             	add    %rax,%rdi
    9221:	80 3f ff             	cmpb   $0xff,(%rdi)
    9224:	0f 84 c6 02 00 00    	je     94f0 <f12+0xf80>
    922a:	c6 07 01             	movb   $0x1,(%rdi)
    922d:	4d 39 fd             	cmp    %r15,%r13
    9230:	73 7e                	jae    92b0 <f12+0xd40>
    9232:	49 83 ef 01          	sub    $0x1,%r15
    9236:	66 49 0f 6e ec       	movq   %r12,%xmm5
    923b:	48 8b 34 24          	mov    (%rsp),%rsi
    923f:	bf 01 00 00 00       	mov    $0x1,%edi
    9244:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    924a:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    924e:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    9255:	00 
    9256:	e8 95 d3 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    925b:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    9262:	49 89 c4             	mov    %rax,%r12
    9265:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    926c:	48 c1 e7 10          	shl    $0x10,%rdi
    9270:	48 39 f8             	cmp    %rdi,%rax
    9273:	73 b8                	jae    922d <f12+0xcbd>
    9275:	48 89 c7             	mov    %rax,%rdi
    9278:	48 c1 ef 10          	shr    $0x10,%rdi
    927c:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    9280:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    9287:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    928b:	49 8b 78 20          	mov    0x20(%r8),%rdi
    928f:	48 85 ff             	test   %rdi,%rdi
    9292:	74 99                	je     922d <f12+0xcbd>
    9294:	45 0f b6 08          	movzbl (%r8),%r9d
    9298:	41 80 f9 02          	cmp    $0x2,%r9b
    929c:	0f 85 5e ff ff ff    	jne    9200 <f12+0xc90>
    92a2:	66 85 c0             	test   %ax,%ax
    92a5:	0f 84 76 ff ff ff    	je     9221 <f12+0xcb1>
    92ab:	4d 39 fd             	cmp    %r15,%r13
    92ae:	72 82                	jb     9232 <f12+0xcc2>
    92b0:	4d 85 ed             	test   %r13,%r13
    92b3:	75 2e                	jne    92e3 <f12+0xd73>
    92b5:	8b 44 24 28          	mov    0x28(%rsp),%eax
    92b9:	85 c0                	test   %eax,%eax
    92bb:	4d 0f 45 f5          	cmovne %r13,%r14
    92bf:	eb 6f                	jmp    9330 <f12+0xdc0>
    92c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    92c8:	66 85 d2             	test   %dx,%dx
    92cb:	0f 84 fe fe ff ff    	je     91cf <f12+0xc5f>
    92d1:	49 39 c5             	cmp    %rax,%r13
    92d4:	0f 82 03 ff ff ff    	jb     91dd <f12+0xc6d>
    92da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    92e0:	45 31 e4             	xor    %r12d,%r12d
    92e3:	4c 89 f2             	mov    %r14,%rdx
    92e6:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    92ea:	48 89 e8             	mov    %rbp,%rax
    92ed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    92f4:	00 
    92f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    92fc:	00 00 00 00 
    9300:	48 8b 0a             	mov    (%rdx),%rcx
    9303:	48 83 c2 08          	add    $0x8,%rdx
    9307:	48 89 c7             	mov    %rax,%rdi
    930a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    930e:	48 8b 40 10          	mov    0x10(%rax),%rax
    9312:	4c 39 c2             	cmp    %r8,%rdx
    9315:	75 e9                	jne    9300 <f12+0xd90>
    9317:	8b 54 24 28          	mov    0x28(%rsp),%edx
    931b:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    931f:	85 d2                	test   %edx,%edx
    9321:	0f 84 a9 02 00 00    	je     95d0 <f12+0x1060>
    9327:	49 89 ec             	mov    %rbp,%r12
    932a:	45 31 f6             	xor    %r14d,%r14d
    932d:	48 89 c5             	mov    %rax,%rbp
    9330:	4c 89 f7             	mov    %r14,%rdi
    9333:	e8 b8 c4 ff ff       	call   57f0 <fwp_mem_free>
    9338:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    933d:	e8 1e e4 ff ff       	call   7760 <fwp_drop4>
    9342:	48 89 ef             	mov    %rbp,%rdi
    9345:	e8 16 d8 ff ff       	call   6b60 <fwp_drop0>
    934a:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
    9351:	00 
    9352:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9359:	00 00 
    935b:	0f 85 f8 04 00 00    	jne    9859 <f12+0x12e9>
    9361:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
    9368:	4c 89 e0             	mov    %r12,%rax
    936b:	5b                   	pop    %rbx
    936c:	5d                   	pop    %rbp
    936d:	41 5c                	pop    %r12
    936f:	41 5d                	pop    %r13
    9371:	41 5e                	pop    %r14
    9373:	41 5f                	pop    %r15
    9375:	c3                   	ret
    9376:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    937d:	00 00 00 
    9380:	66 85 c9             	test   %cx,%cx
    9383:	0f 84 1b fd ff ff    	je     90a4 <f12+0xb34>
    9389:	48 85 ed             	test   %rbp,%rbp
    938c:	0f 84 27 03 00 00    	je     96b9 <f12+0x1149>
    9392:	48 89 e8             	mov    %rbp,%rax
    9395:	45 31 e4             	xor    %r12d,%r12d
    9398:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    939f:	00 
    93a0:	48 8b 40 10          	mov    0x10(%rax),%rax
    93a4:	4c 89 e2             	mov    %r12,%rdx
    93a7:	49 83 c4 01          	add    $0x1,%r12
    93ab:	48 85 c0             	test   %rax,%rax
    93ae:	75 f0                	jne    93a0 <f12+0xe30>
    93b0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    93b7:	ff ff 1f 
    93ba:	4c 39 e0             	cmp    %r12,%rax
    93bd:	0f 82 66 04 00 00    	jb     9829 <f12+0x12b9>
    93c3:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    93ca:	00 
    93cb:	be 02 00 00 00       	mov    $0x2,%esi
    93d0:	e8 1b c9 ff ff       	call   5cf0 <fwp_heap_alloc>
    93d5:	4d 39 e5             	cmp    %r12,%r13
    93d8:	48 89 ea             	mov    %rbp,%rdx
    93db:	49 89 c6             	mov    %rax,%r14
    93de:	4c 89 e0             	mov    %r12,%rax
    93e1:	49 0f 46 c5          	cmovbe %r13,%rax
    93e5:	4c 89 f1             	mov    %r14,%rcx
    93e8:	66 90                	xchg   %ax,%ax
    93ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    93f1:	00 00 00 00 
    93f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    93fc:	00 00 00 00 
    9400:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    9404:	48 83 c1 08          	add    $0x8,%rcx
    9408:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    940c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9410:	48 85 d2             	test   %rdx,%rdx
    9413:	75 eb                	jne    9400 <f12+0xe90>
    9415:	48 85 c0             	test   %rax,%rax
    9418:	0f 84 ad 02 00 00    	je     96cb <f12+0x115b>
    941e:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
    9425:	00 
    9426:	e9 a1 fc ff ff       	jmp    90cc <f12+0xb5c>
    942b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9430:	66 85 c0             	test   %ax,%ax
    9433:	0f 84 48 fb ff ff    	je     8f81 <f12+0xa11>
    9439:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9440:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9447:	ff ff 1f 
    944a:	4c 39 e0             	cmp    %r12,%rax
    944d:	0f 82 e2 03 00 00    	jb     9835 <f12+0x12c5>
    9453:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    945a:	00 
    945b:	be 01 00 00 00       	mov    $0x1,%esi
    9460:	e8 8b c8 ff ff       	call   5cf0 <fwp_heap_alloc>
    9465:	4c 89 20             	mov    %r12,(%rax)
    9468:	48 8b 15 69 b7 01 00 	mov    0x1b769(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    946f:	49 89 c7             	mov    %rax,%r15
    9472:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    9477:	48 2b 05 32 b7 01 00 	sub    0x1b732(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    947e:	48 c1 e2 10          	shl    $0x10,%rdx
    9482:	48 39 d0             	cmp    %rdx,%rax
    9485:	73 57                	jae    94de <f12+0xf6e>
    9487:	48 89 c2             	mov    %rax,%rdx
    948a:	48 c1 ea 10          	shr    $0x10,%rdx
    948e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9492:	48 8b 15 5f b7 01 00 	mov    0x1b75f(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    9499:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    949d:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    94a1:	4d 85 f6             	test   %r14,%r14
    94a4:	74 38                	je     94de <f12+0xf6e>
    94a6:	0f b6 0a             	movzbl (%rdx),%ecx
    94a9:	80 f9 02             	cmp    $0x2,%cl
    94ac:	0f 84 26 02 00 00    	je     96d8 <f12+0x1168>
    94b2:	80 f9 01             	cmp    $0x1,%cl
    94b5:	75 27                	jne    94de <f12+0xf6e>
    94b7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    94ba:	0f b7 c0             	movzwl %ax,%eax
    94bd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    94c0:	48 0f af c1          	imul   %rcx,%rax
    94c4:	48 c1 e8 20          	shr    $0x20,%rax
    94c8:	48 39 d0             	cmp    %rdx,%rax
    94cb:	73 11                	jae    94de <f12+0xf6e>
    94cd:	49 01 c6             	add    %rax,%r14
    94d0:	41 80 3e ff          	cmpb   $0xff,(%r14)
    94d4:	0f 84 cc 02 00 00    	je     97a6 <f12+0x1236>
    94da:	41 c6 06 01          	movb   $0x1,(%r14)
    94de:	4c 89 ef             	mov    %r13,%rdi
    94e1:	e9 ae fa ff ff       	jmp    8f94 <f12+0xa24>
    94e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    94ed:	00 00 00 
    94f0:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    94f5:	e8 b6 c0 ff ff       	call   55b0 <fwp_rc_forget_slot>
    94fa:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    94ff:	e9 26 fd ff ff       	jmp    922a <f12+0xcba>
    9504:	0f 1f 40 00          	nopl   0x0(%rax)
    9508:	48 8d 3d 91 db ff ff 	lea    -0x246f(%rip),%rdi        # 70a0 <fwp_tape_finish>
    950f:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    9514:	e8 77 56 00 00       	call   eb90 <atexit>
    9519:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    951e:	85 c0                	test   %eax,%eax
    9520:	75 63                	jne    9585 <f12+0x1015>
    9522:	c7 05 54 9b 00 00 01 	movl   $0x1,0x9b54(%rip)        # 13080 <registered_finish.0>
    9529:	00 00 00 
    952c:	e9 73 f1 ff ff       	jmp    86a4 <f12+0x134>
    9531:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9538:	66 85 c0             	test   %ax,%ax
    953b:	0f 85 0f f1 ff ff    	jne    8650 <f12+0xe0>
    9541:	e9 f6 f0 ff ff       	jmp    863c <f12+0xcc>
    9546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    954d:	00 00 00 
    9550:	4c 89 f2             	mov    %r14,%rdx
    9553:	4d 39 d6             	cmp    %r10,%r14
    9556:	0f 8f 39 f7 ff ff    	jg     8c95 <f12+0x725>
    955c:	48 85 d2             	test   %rdx,%rdx
    955f:	0f 84 a7 f7 ff ff    	je     8d0c <f12+0x79c>
    9565:	4d 85 ff             	test   %r15,%r15
    9568:	0f 85 95 f7 ff ff    	jne    8d03 <f12+0x793>
    956e:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    9575:	00 
    9576:	4c 89 e7             	mov    %r12,%rdi
    9579:	48 89 05 18 bf 01 00 	mov    %rax,0x1bf18(%rip)        # 25498 <fwp_cleanups>
    9580:	e8 4b bb ff ff       	call   50d0 <fwp_tape_buffers_release>
    9585:	48 8b 0d d4 9a 00 00 	mov    0x9ad4(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    958c:	ba 13 00 00 00       	mov    $0x13,%edx
    9591:	be 01 00 00 00       	mov    $0x1,%esi
    9596:	48 8d 3d 6b 5a 00 00 	lea    0x5a6b(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    959d:	e8 de a0 ff ff       	call   3680 <fwrite@plt>
    95a2:	31 ff                	xor    %edi,%edi
    95a4:	e8 17 a0 ff ff       	call   35c0 <fflush@plt>
    95a9:	bf 66 00 00 00       	mov    $0x66,%edi
    95ae:	e8 ed a0 ff ff       	call   36a0 <_Exit@plt>
    95b3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    95b8:	66 85 c0             	test   %ax,%ax
    95bb:	0f 85 15 f9 ff ff    	jne    8ed6 <f12+0x966>
    95c1:	e9 04 f9 ff ff       	jmp    8eca <f12+0x95a>
    95c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    95cd:	00 00 00 
    95d0:	49 89 ec             	mov    %rbp,%r12
    95d3:	48 89 c5             	mov    %rax,%rbp
    95d6:	e9 55 fd ff ff       	jmp    9330 <f12+0xdc0>
    95db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    95e0:	66 0f 6f 0d f8 9a 01 	movdqa 0x19af8(%rip),%xmm1        # 230e0 <fwp_tape_workspace>
    95e7:	00 
    95e8:	48 c7 05 d5 9a 01 00 	movq   $0x0,0x19ad5(%rip)        # 230c8 <fwp_tape_cached_bytes>
    95ef:	00 00 00 00 
    95f3:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    95f9:	48 8b 05 00 9b 01 00 	mov    0x19b00(%rip),%rax        # 23100 <fwp_tape_workspace+0x20>
    9600:	66 0f 6f 0d e8 9a 01 	movdqa 0x19ae8(%rip),%xmm1        # 230f0 <fwp_tape_workspace+0x10>
    9607:	00 
    9608:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    960d:	48 8b 05 f4 9a 01 00 	mov    0x19af4(%rip),%rax        # 23108 <fwp_tape_workspace+0x28>
    9614:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    961a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    961e:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    9623:	48 8b 05 e6 9a 01 00 	mov    0x19ae6(%rip),%rax        # 23110 <fwp_tape_workspace+0x30>
    962a:	0f 29 0d af 9a 01 00 	movaps %xmm1,0x19aaf(%rip)        # 230e0 <fwp_tape_workspace>
    9631:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    9636:	0f 29 0d b3 9a 01 00 	movaps %xmm1,0x19ab3(%rip)        # 230f0 <fwp_tape_workspace+0x10>
    963d:	48 c7 05 c8 9a 01 00 	movq   $0x0,0x19ac8(%rip)        # 23110 <fwp_tape_workspace+0x30>
    9644:	00 00 00 00 
    9648:	0f 29 0d b1 9a 01 00 	movaps %xmm1,0x19ab1(%rip)        # 23100 <fwp_tape_workspace+0x20>
    964f:	e9 75 f1 ff ff       	jmp    87c9 <f12+0x259>
    9654:	0f 1f 40 00          	nopl   0x0(%rax)
    9658:	4c 89 f2             	mov    %r14,%rdx
    965b:	e9 35 f6 ff ff       	jmp    8c95 <f12+0x725>
    9660:	4d 85 ff             	test   %r15,%r15
    9663:	0f 84 05 ff ff ff    	je     956e <f12+0xffe>
    9669:	49 89 d2             	mov    %rdx,%r10
    966c:	31 f6                	xor    %esi,%esi
    966e:	48 c1 e2 03          	shl    $0x3,%rdx
    9672:	4c 89 ff             	mov    %r15,%rdi
    9675:	4d 29 f2             	sub    %r14,%r10
    9678:	4c 89 4c 24 48       	mov    %r9,0x48(%rsp)
    967d:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
    9682:	e8 39 9e ff ff       	call   34c0 <memset@plt>
    9687:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
    968c:	4c 8b 4c 24 48       	mov    0x48(%rsp),%r9
    9691:	e9 8b f6 ff ff       	jmp    8d21 <f12+0x7b1>
    9696:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    969d:	00 00 00 
    96a0:	4f 8d 3c 24          	lea    (%r12,%r12,1),%r15
    96a4:	b8 ff ff 00 00       	mov    $0xffff,%eax
    96a9:	49 39 c7             	cmp    %rax,%r15
    96ac:	4c 0f 4f f8          	cmovg  %rax,%r15
    96b0:	49 6b f7 68          	imul   $0x68,%r15,%rsi
    96b4:	e9 68 f0 ff ff       	jmp    8721 <f12+0x1b1>
    96b9:	be 02 00 00 00       	mov    $0x2,%esi
    96be:	bf 08 00 00 00       	mov    $0x8,%edi
    96c3:	e8 28 c6 ff ff       	call   5cf0 <fwp_heap_alloc>
    96c8:	49 89 c6             	mov    %rax,%r14
    96cb:	45 31 e4             	xor    %r12d,%r12d
    96ce:	e9 5d fc ff ff       	jmp    9330 <f12+0xdc0>
    96d3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    96d8:	66 85 c0             	test   %ax,%ax
    96db:	0f 85 fd fd ff ff    	jne    94de <f12+0xf6e>
    96e1:	e9 ea fd ff ff       	jmp    94d0 <f12+0xf60>
    96e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    96ed:	00 00 00 
    96f0:	4c 89 d7             	mov    %r10,%rdi
    96f3:	be 08 00 00 00       	mov    $0x8,%esi
    96f8:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
    96fd:	e8 1e 9e ff ff       	call   3520 <calloc@plt>
    9702:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
    9707:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
    970c:	49 89 c7             	mov    %rax,%r15
    970f:	e9 d6 f5 ff ff       	jmp    8cea <f12+0x77a>
    9714:	31 ff                	xor    %edi,%edi
    9716:	e8 35 ab ff ff       	call   4250 <descent_phase_step>
    971b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    971f:	e9 72 ef ff ff       	jmp    8696 <f12+0x126>
    9724:	49 8b 07             	mov    (%r15),%rax
    9727:	48 85 c0             	test   %rax,%rax
    972a:	78 8d                	js     96b9 <f12+0x1149>
    972c:	48 8b 35 a5 b4 01 00 	mov    0x1b4a5(%rip),%rsi        # 24bd8 <fwp_heap+0x13d8>
    9733:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    9738:	48 2b 0d 71 b4 01 00 	sub    0x1b471(%rip),%rcx        # 24bb0 <fwp_heap+0x13b0>
    973f:	48 c1 e6 10          	shl    $0x10,%rsi
    9743:	48 39 f1             	cmp    %rsi,%rcx
    9746:	0f 83 6d ff ff ff    	jae    96b9 <f12+0x1149>
    974c:	48 89 ce             	mov    %rcx,%rsi
    974f:	48 c1 ee 10          	shr    $0x10,%rsi
    9753:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9757:	48 8b 35 9a b4 01 00 	mov    0x1b49a(%rip),%rsi        # 24bf8 <fwp_heap+0x13f8>
    975e:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9762:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9766:	48 85 ff             	test   %rdi,%rdi
    9769:	0f 84 4a ff ff ff    	je     96b9 <f12+0x1149>
    976f:	48 0f ba f0 3f       	btr    $0x3f,%rax
    9774:	49 89 c5             	mov    %rax,%r13
    9777:	e9 f8 f8 ff ff       	jmp    9074 <f12+0xb04>
    977c:	48 89 d7             	mov    %rdx,%rdi
    977f:	48 89 14 24          	mov    %rdx,(%rsp)
    9783:	e8 28 be ff ff       	call   55b0 <fwp_rc_forget_slot>
    9788:	48 8b 14 24          	mov    (%rsp),%rdx
    978c:	e9 d2 f1 ff ff       	jmp    8963 <f12+0x3f3>
    9791:	48 89 df             	mov    %rbx,%rdi
    9794:	48 89 0c 24          	mov    %rcx,(%rsp)
    9798:	e8 13 be ff ff       	call   55b0 <fwp_rc_forget_slot>
    979d:	48 8b 0c 24          	mov    (%rsp),%rcx
    97a1:	e9 2d f7 ff ff       	jmp    8ed3 <f12+0x963>
    97a6:	4c 89 f7             	mov    %r14,%rdi
    97a9:	e8 02 be ff ff       	call   55b0 <fwp_rc_forget_slot>
    97ae:	e9 27 fd ff ff       	jmp    94da <f12+0xf6a>
    97b3:	e8 d8 bc ff ff       	call   5490 <fwp_rc_wide_dup>
    97b8:	e9 93 ee ff ff       	jmp    8650 <f12+0xe0>
    97bd:	49 89 d2             	mov    %rdx,%r10
    97c0:	48 8d 5a ff          	lea    -0x1(%rdx),%rbx
    97c4:	31 f6                	xor    %esi,%esi
    97c6:	48 c1 e2 03          	shl    $0x3,%rdx
    97ca:	4d 29 f2             	sub    %r14,%r10
    97cd:	4c 89 ff             	mov    %r15,%rdi
    97d0:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
    97d5:	e8 e6 9c ff ff       	call   34c0 <memset@plt>
    97da:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
    97df:	e9 35 f5 ff ff       	jmp    8d19 <f12+0x7a9>
    97e4:	45 31 ed             	xor    %r13d,%r13d
    97e7:	e9 f1 f9 ff ff       	jmp    91dd <f12+0xc6d>
    97ec:	48 8d 3d 74 59 00 00 	lea    0x5974(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    97f3:	e8 f8 ab ff ff       	call   43f0 <fwp_trap>
    97f8:	48 8d 3d b1 60 00 00 	lea    0x60b1(%rip),%rdi        # f8b0 <_IO_stdin_used+0x8b0>
    97ff:	e8 ec ab ff ff       	call   43f0 <fwp_trap>
    9804:	48 8d 3d ad 61 00 00 	lea    0x61ad(%rip),%rdi        # f9b8 <_IO_stdin_used+0x9b8>
    980b:	e8 e0 ab ff ff       	call   43f0 <fwp_trap>
    9810:	e8 eb 9e ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9815:	45 31 f6             	xor    %r14d,%r14d
    9818:	e9 ae fe ff ff       	jmp    96cb <f12+0x115b>
    981d:	48 8d 3d 7a 59 00 00 	lea    0x597a(%rip),%rdi        # f19e <_IO_stdin_used+0x19e>
    9824:	e8 c7 ab ff ff       	call   43f0 <fwp_trap>
    9829:	48 8d 3d 60 59 00 00 	lea    0x5960(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    9830:	e8 bb ab ff ff       	call   43f0 <fwp_trap>
    9835:	48 8d 3d 7c 59 00 00 	lea    0x597c(%rip),%rdi        # f1b8 <_IO_stdin_used+0x1b8>
    983c:	e8 af ab ff ff       	call   43f0 <fwp_trap>
    9841:	48 8d 3d 10 61 00 00 	lea    0x6110(%rip),%rdi        # f958 <_IO_stdin_used+0x958>
    9848:	e8 a3 ab ff ff       	call   43f0 <fwp_trap>
    984d:	48 8d 3d a4 60 00 00 	lea    0x60a4(%rip),%rdi        # f8f8 <_IO_stdin_used+0x8f8>
    9854:	e8 97 ab ff ff       	call   43f0 <fwp_trap>
    9859:	e8 02 9c ff ff       	call   3460 <__stack_chk_fail@plt>
    985e:	48 8d 3d 23 61 00 00 	lea    0x6123(%rip),%rdi        # f988 <_IO_stdin_used+0x988>
    9865:	e8 86 ab ff ff       	call   43f0 <fwp_trap>
    986a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000009870 <fwp_owned_entry12>:
    9870:	f3 0f 1e fa          	endbr64
    9874:	48 8b 3f             	mov    (%rdi),%rdi
    9877:	e9 f4 ec ff ff       	jmp    8570 <f12>
    987c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009880 <e12>:
    9880:	f3 0f 1e fa          	endbr64
    9884:	53                   	push   %rbx
    9885:	48 8b 1f             	mov    (%rdi),%rbx
    9888:	48 89 df             	mov    %rbx,%rdi
    988b:	e8 90 ce ff ff       	call   6720 <fwp_rc_share>
    9890:	48 89 df             	mov    %rbx,%rdi
    9893:	e8 d8 ec ff ff       	call   8570 <f12>
    9898:	48 89 c3             	mov    %rax,%rbx
    989b:	48 89 c7             	mov    %rax,%rdi
    989e:	e8 7d ce ff ff       	call   6720 <fwp_rc_share>
    98a3:	48 89 d8             	mov    %rbx,%rax
    98a6:	5b                   	pop    %rbx
    98a7:	c3                   	ret
    98a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    98af:	00 

00000000000098b0 <fwp_write>:
    98b0:	41 57                	push   %r15
    98b2:	41 56                	push   %r14
    98b4:	41 55                	push   %r13
    98b6:	41 54                	push   %r12
    98b8:	55                   	push   %rbp
    98b9:	53                   	push   %rbx
    98ba:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    98c1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    98c8:	00 00 
    98ca:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    98d1:	00 
    98d2:	49 89 d4             	mov    %rdx,%r12
    98d5:	8b 12                	mov    (%rdx),%edx
    98d7:	83 fa 19             	cmp    $0x19,%edx
    98da:	77 6a                	ja     9946 <fwp_write+0x96>
    98dc:	48 89 f5             	mov    %rsi,%rbp
    98df:	89 d0                	mov    %edx,%eax
    98e1:	89 ce                	mov    %ecx,%esi
    98e3:	48 89 fb             	mov    %rdi,%rbx
    98e6:	48 8d 0d 13 62 00 00 	lea    0x6213(%rip),%rcx        # fb00 <_IO_stdin_used+0xb00>
    98ed:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    98f1:	48 01 c8             	add    %rcx,%rax
    98f4:	3e ff e0             	notrack jmp *%rax
    98f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    98fe:	00 00 
    9900:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9904:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9908:	48 89 ca             	mov    %rcx,%rdx
    990b:	48 85 c9             	test   %rcx,%rcx
    990e:	0f 88 9c 0c 00 00    	js     a5b0 <fwp_write+0xd00>
    9914:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    991b:	00 
    991c:	48 89 c6             	mov    %rax,%rsi
    991f:	4c 89 e7             	mov    %r12,%rdi
    9922:	e8 19 a1 ff ff       	call   3a40 <fwp_fmt_u128>
    9927:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    992e:	00 00 
    9930:	4c 89 e7             	mov    %r12,%rdi
    9933:	e8 18 9b ff ff       	call   3450 <strlen@plt>
    9938:	4c 89 e6             	mov    %r12,%rsi
    993b:	48 89 df             	mov    %rbx,%rdi
    993e:	48 89 c2             	mov    %rax,%rdx
    9941:	e8 ca a8 ff ff       	call   4210 <buf_put>
    9946:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    994d:	00 
    994e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9955:	00 00 
    9957:	0f 85 28 04 00 00    	jne    9d85 <fwp_write+0x4d5>
    995d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9964:	5b                   	pop    %rbx
    9965:	5d                   	pop    %rbp
    9966:	41 5c                	pop    %r12
    9968:	41 5d                	pop    %r13
    996a:	41 5e                	pop    %r14
    996c:	41 5f                	pop    %r15
    996e:	c3                   	ret
    996f:	90                   	nop
    9970:	49 89 e9             	mov    %rbp,%r9
    9973:	4c 8d 05 fb 56 00 00 	lea    0x56fb(%rip),%r8        # f075 <_IO_stdin_used+0x75>
    997a:	b9 00 02 00 00       	mov    $0x200,%ecx
    997f:	ba 02 00 00 00       	mov    $0x2,%edx
    9984:	be 00 02 00 00       	mov    $0x200,%esi
    9989:	31 c0                	xor    %eax,%eax
    998b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9992:	00 
    9993:	e8 18 9a ff ff       	call   33b0 <__snprintf_chk@plt>
    9998:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    999f:	00 
    99a0:	e8 ab 9a ff ff       	call   3450 <strlen@plt>
    99a5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    99ac:	00 
    99ad:	48 89 df             	mov    %rbx,%rdi
    99b0:	48 89 c2             	mov    %rax,%rdx
    99b3:	e8 58 a8 ff ff       	call   4210 <buf_put>
    99b8:	eb 8c                	jmp    9946 <fwp_write+0x96>
    99ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    99c0:	49 89 e9             	mov    %rbp,%r9
    99c3:	4c 8d 05 15 58 00 00 	lea    0x5815(%rip),%r8        # f1df <_IO_stdin_used+0x1df>
    99ca:	eb ae                	jmp    997a <fwp_write+0xca>
    99cc:	0f 1f 40 00          	nopl   0x0(%rax)
    99d0:	83 fa 13             	cmp    $0x13,%edx
    99d3:	48 8d 05 fb 57 00 00 	lea    0x57fb(%rip),%rax        # f1d5 <_IO_stdin_used+0x1d5>
    99da:	48 8d 35 f9 57 00 00 	lea    0x57f9(%rip),%rsi        # f1da <_IO_stdin_used+0x1da>
    99e1:	ba 04 00 00 00       	mov    $0x4,%edx
    99e6:	48 0f 44 f0          	cmove  %rax,%rsi
    99ea:	45 31 ed             	xor    %r13d,%r13d
    99ed:	e8 1e a8 ff ff       	call   4210 <buf_put>
    99f2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    99f7:	0f 84 a3 08 00 00    	je     a2a0 <fwp_write+0x9f0>
    99fd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9a02:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9a07:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9a0c:	48 89 df             	mov    %rbx,%rdi
    9a0f:	49 0f 44 c5          	cmove  %r13,%rax
    9a13:	31 c9                	xor    %ecx,%ecx
    9a15:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    9a1a:	e8 91 fe ff ff       	call   98b0 <fwp_write>
    9a1f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9a24:	0f 84 6e 09 00 00    	je     a398 <fwp_write+0xae8>
    9a2a:	49 83 c5 01          	add    $0x1,%r13
    9a2e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9a32:	0f 83 68 08 00 00    	jae    a2a0 <fwp_write+0x9f0>
    9a38:	ba 02 00 00 00       	mov    $0x2,%edx
    9a3d:	48 8d 35 db 57 00 00 	lea    0x57db(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    9a44:	48 89 df             	mov    %rbx,%rdi
    9a47:	e8 c4 a7 ff ff       	call   4210 <buf_put>
    9a4c:	eb af                	jmp    99fd <fwp_write+0x14d>
    9a4e:	66 90                	xchg   %ax,%ax
    9a50:	ba 06 00 00 00       	mov    $0x6,%edx
    9a55:	48 8d 35 9c 57 00 00 	lea    0x579c(%rip),%rsi        # f1f8 <_IO_stdin_used+0x1f8>
    9a5c:	48 83 c5 10          	add    $0x10,%rbp
    9a60:	e8 ab a7 ff ff       	call   4210 <buf_put>
    9a65:	48 89 ef             	mov    %rbp,%rdi
    9a68:	e8 e3 99 ff ff       	call   3450 <strlen@plt>
    9a6d:	48 89 ee             	mov    %rbp,%rsi
    9a70:	48 89 df             	mov    %rbx,%rdi
    9a73:	48 89 c2             	mov    %rax,%rdx
    9a76:	e8 95 a7 ff ff       	call   4210 <buf_put>
    9a7b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9a80:	ba 01 00 00 00       	mov    $0x1,%edx
    9a85:	48 89 df             	mov    %rbx,%rdi
    9a88:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9a8d:	e8 7e a7 ff ff       	call   4210 <buf_put>
    9a92:	e9 af fe ff ff       	jmp    9946 <fwp_write+0x96>
    9a97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9a9e:	00 00 
    9aa0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9aa7:	00 
    9aa8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9aaf:	00 00 
    9ab1:	0f 85 ce 02 00 00    	jne    9d85 <fwp_write+0x4d5>
    9ab7:	ba 0a 00 00 00       	mov    $0xa,%edx
    9abc:	48 8d 35 21 57 00 00 	lea    0x5721(%rip),%rsi        # f1e4 <_IO_stdin_used+0x1e4>
    9ac3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9aca:	48 89 df             	mov    %rbx,%rdi
    9acd:	5b                   	pop    %rbx
    9ace:	5d                   	pop    %rbp
    9acf:	41 5c                	pop    %r12
    9ad1:	41 5d                	pop    %r13
    9ad3:	41 5e                	pop    %r14
    9ad5:	41 5f                	pop    %r15
    9ad7:	e9 34 a7 ff ff       	jmp    4210 <buf_put>
    9adc:	0f 1f 40 00          	nopl   0x0(%rax)
    9ae0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    9ae5:	4d 85 ed             	test   %r13,%r13
    9ae8:	0f 84 02 0c 00 00    	je     a6f0 <fwp_write+0xe40>
    9aee:	48 8d 35 37 57 00 00 	lea    0x5737(%rip),%rsi        # f22c <_IO_stdin_used+0x22c>
    9af5:	4c 89 ef             	mov    %r13,%rdi
    9af8:	e8 33 9a ff ff       	call   3530 <strcmp@plt>
    9afd:	41 89 c1             	mov    %eax,%r9d
    9b00:	85 c0                	test   %eax,%eax
    9b02:	0f 84 6c 0c 00 00    	je     a774 <fwp_write+0xec4>
    9b08:	4c 89 ef             	mov    %r13,%rdi
    9b0b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9b10:	e8 3b 99 ff ff       	call   3450 <strlen@plt>
    9b15:	4c 89 ee             	mov    %r13,%rsi
    9b18:	48 89 df             	mov    %rbx,%rdi
    9b1b:	48 89 c2             	mov    %rax,%rdx
    9b1e:	e8 ed a6 ff ff       	call   4210 <buf_put>
    9b23:	ba 01 00 00 00       	mov    $0x1,%edx
    9b28:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9b2d:	48 89 df             	mov    %rbx,%rdi
    9b30:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9b35:	e8 d6 a6 ff ff       	call   4210 <buf_put>
    9b3a:	ba 01 00 00 00       	mov    $0x1,%edx
    9b3f:	4c 89 fe             	mov    %r15,%rsi
    9b42:	48 89 df             	mov    %rbx,%rdi
    9b45:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    9b4a:	e8 c1 a6 ff ff       	call   4210 <buf_put>
    9b4f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9b54:	45 31 f6             	xor    %r14d,%r14d
    9b57:	85 d2                	test   %edx,%edx
    9b59:	0f 8e 81 0a 00 00    	jle    a5e0 <fwp_write+0xd30>
    9b5f:	45 31 ed             	xor    %r13d,%r13d
    9b62:	4d 85 ed             	test   %r13,%r13
    9b65:	0f 85 75 07 00 00    	jne    a2e0 <fwp_write+0xa30>
    9b6b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9b72:	00 
    9b73:	45 85 f6             	test   %r14d,%r14d
    9b76:	0f 84 84 07 00 00    	je     a300 <fwp_write+0xa50>
    9b7c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    9b81:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    9b86:	48 89 df             	mov    %rbx,%rdi
    9b89:	49 83 c5 01          	add    $0x1,%r13
    9b8d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    9b91:	31 c9                	xor    %ecx,%ecx
    9b93:	e8 18 fd ff ff       	call   98b0 <fwp_write>
    9b98:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    9b9d:	7f c3                	jg     9b62 <fwp_write+0x2b2>
    9b9f:	45 85 f6             	test   %r14d,%r14d
    9ba2:	0f 84 38 0a 00 00    	je     a5e0 <fwp_write+0xd30>
    9ba8:	b8 29 00 00 00       	mov    $0x29,%eax
    9bad:	ba 01 00 00 00       	mov    $0x1,%edx
    9bb2:	4c 89 fe             	mov    %r15,%rsi
    9bb5:	48 89 df             	mov    %rbx,%rdi
    9bb8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    9bbc:	e8 4f a6 ff ff       	call   4210 <buf_put>
    9bc1:	e9 80 fd ff ff       	jmp    9946 <fwp_write+0x96>
    9bc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9bcd:	00 00 00 
    9bd0:	ba 01 00 00 00       	mov    $0x1,%edx
    9bd5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9bda:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    9bdf:	e8 2c a6 ff ff       	call   4210 <buf_put>
    9be4:	48 85 ed             	test   %rbp,%rbp
    9be7:	0f 84 93 06 00 00    	je     a280 <fwp_write+0x9d0>
    9bed:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    9bf1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9bf6:	31 c9                	xor    %ecx,%ecx
    9bf8:	48 89 df             	mov    %rbx,%rdi
    9bfb:	e8 b0 fc ff ff       	call   98b0 <fwp_write>
    9c00:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    9c04:	48 85 ed             	test   %rbp,%rbp
    9c07:	0f 84 73 06 00 00    	je     a280 <fwp_write+0x9d0>
    9c0d:	ba 02 00 00 00       	mov    $0x2,%edx
    9c12:	48 8d 35 06 56 00 00 	lea    0x5606(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    9c19:	48 89 df             	mov    %rbx,%rdi
    9c1c:	e8 ef a5 ff ff       	call   4210 <buf_put>
    9c21:	eb ca                	jmp    9bed <fwp_write+0x33d>
    9c23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9c28:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    9c2c:	85 f6                	test   %esi,%esi
    9c2e:	0f 84 fc 07 00 00    	je     a430 <fwp_write+0xb80>
    9c34:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9c3b:	00 
    9c3c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9c43:	00 00 
    9c45:	0f 85 3a 01 00 00    	jne    9d85 <fwp_write+0x4d5>
    9c4b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    9c4f:	4c 89 ea             	mov    %r13,%rdx
    9c52:	e9 6c fe ff ff       	jmp    9ac3 <fwp_write+0x213>
    9c57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9c5e:	00 00 
    9c60:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    9c65:	ba 01 00 00 00       	mov    $0x1,%edx
    9c6a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    9c6f:	48 89 ee             	mov    %rbp,%rsi
    9c72:	e8 99 a5 ff ff       	call   4210 <buf_put>
    9c77:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    9c7c:	4c 89 e7             	mov    %r12,%rdi
    9c7f:	e8 cc 97 ff ff       	call   3450 <strlen@plt>
    9c84:	4c 89 e6             	mov    %r12,%rsi
    9c87:	48 89 df             	mov    %rbx,%rdi
    9c8a:	48 89 c2             	mov    %rax,%rdx
    9c8d:	e8 7e a5 ff ff       	call   4210 <buf_put>
    9c92:	ba 01 00 00 00       	mov    $0x1,%edx
    9c97:	48 89 ee             	mov    %rbp,%rsi
    9c9a:	48 89 df             	mov    %rbx,%rdi
    9c9d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9ca2:	e8 69 a5 ff ff       	call   4210 <buf_put>
    9ca7:	e9 9a fc ff ff       	jmp    9946 <fwp_write+0x96>
    9cac:	0f 1f 40 00          	nopl   0x0(%rax)
    9cb0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    9cb5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    9cb9:	0f 8a 8e 0b 00 00    	jp     a84d <fwp_write+0xf9d>
    9cbf:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9cc3:	66 0f 54 05 45 5f 00 	andpd  0x5f45(%rip),%xmm0        # fc10 <msg.8+0xa0>
    9cca:	00 
    9ccb:	bd 01 00 00 00       	mov    $0x1,%ebp
    9cd0:	66 0f 2e 05 70 5f 00 	ucomisd 0x5f70(%rip),%xmm0        # fc48 <msg.8+0xd8>
    9cd7:	00 
    9cd8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9cdf:	00 
    9ce0:	0f 87 b2 09 00 00    	ja     a698 <fwp_write+0xde8>
    9ce6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9ced:	00 00 00 
    9cf0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9cf4:	89 ee                	mov    %ebp,%esi
    9cf6:	4c 89 e7             	mov    %r12,%rdi
    9cf9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    9cfe:	e8 0d aa ff ff       	call   4710 <fwp_format_g.constprop.0>
    9d03:	31 f6                	xor    %esi,%esi
    9d05:	4c 89 e7             	mov    %r12,%rdi
    9d08:	e8 03 97 ff ff       	call   3410 <strtod@plt>
    9d0d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    9d12:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    9d16:	7a 06                	jp     9d1e <fwp_write+0x46e>
    9d18:	0f 84 e9 01 00 00    	je     9f07 <fwp_write+0x657>
    9d1e:	83 c5 01             	add    $0x1,%ebp
    9d21:	83 fd 12             	cmp    $0x12,%ebp
    9d24:	75 ca                	jne    9cf0 <fwp_write+0x440>
    9d26:	be 11 00 00 00       	mov    $0x11,%esi
    9d2b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9d2f:	4c 89 e7             	mov    %r12,%rdi
    9d32:	e8 d9 a9 ff ff       	call   4710 <fwp_format_g.constprop.0>
    9d37:	e9 cb 01 00 00       	jmp    9f07 <fwp_write+0x657>
    9d3c:	0f 1f 40 00          	nopl   0x0(%rax)
    9d40:	48 83 fd 01          	cmp    $0x1,%rbp
    9d44:	0f 84 e6 08 00 00    	je     a630 <fwp_write+0xd80>
    9d4a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    9d4e:	b8 02 00 00 00       	mov    $0x2,%eax
    9d53:	ba 01 00 00 00       	mov    $0x1,%edx
    9d58:	48 0f 44 d0          	cmove  %rax,%rdx
    9d5c:	48 8d 35 6a 54 00 00 	lea    0x546a(%rip),%rsi        # f1cd <_IO_stdin_used+0x1cd>
    9d63:	48 8d 05 68 54 00 00 	lea    0x5468(%rip),%rax        # f1d2 <_IO_stdin_used+0x1d2>
    9d6a:	48 0f 44 f0          	cmove  %rax,%rsi
    9d6e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9d75:	00 
    9d76:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9d7d:	00 00 
    9d7f:	0f 84 3e fd ff ff    	je     9ac3 <fwp_write+0x213>
    9d85:	e8 d6 96 ff ff       	call   3460 <__stack_chk_fail@plt>
    9d8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9d90:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    9d95:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    9d9a:	e8 b1 a3 ff ff       	call   4150 <buf_grow>
    9d9f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    9da3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    9da9:	4c 03 0b             	add    (%rbx),%r9
    9dac:	66 45 89 11          	mov    %r10w,(%r9)
    9db0:	45 85 e4             	test   %r12d,%r12d
    9db3:	0f 8e 07 05 00 00    	jle    a2c0 <fwp_write+0xa10>
    9db9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    9dc0:	55 55 55 
    9dc3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    9dc8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    9dcf:	aa aa aa 
    9dd2:	49 83 c1 01          	add    $0x1,%r9
    9dd6:	eb 45                	jmp    9e1d <fwp_write+0x56d>
    9dd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9ddf:	00 
    9de0:	be 01 00 00 00       	mov    $0x1,%esi
    9de5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    9dea:	88 07                	mov    %al,(%rdi)
    9dec:	48 89 e8             	mov    %rbp,%rax
    9def:	49 f7 e8             	imul   %r8
    9df2:	48 89 e8             	mov    %rbp,%rax
    9df5:	48 c1 f8 3f          	sar    $0x3f,%rax
    9df9:	48 29 c2             	sub    %rax,%rdx
    9dfc:	48 85 c9             	test   %rcx,%rcx
    9dff:	0f 95 c0             	setne  %al
    9e02:	48 c1 ed 3f          	shr    $0x3f,%rbp
    9e06:	48 83 ef 01          	sub    $0x1,%rdi
    9e0a:	48 21 c5             	and    %rax,%rbp
    9e0d:	48 29 ea             	sub    %rbp,%rdx
    9e10:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    9e14:	49 39 f9             	cmp    %rdi,%r9
    9e17:	0f 84 a3 04 00 00    	je     a2c0 <fwp_write+0xa10>
    9e1d:	48 89 e8             	mov    %rbp,%rax
    9e20:	49 f7 e8             	imul   %r8
    9e23:	48 89 e8             	mov    %rbp,%rax
    9e26:	48 c1 f8 3f          	sar    $0x3f,%rax
    9e2a:	48 89 d1             	mov    %rdx,%rcx
    9e2d:	48 29 c1             	sub    %rax,%rcx
    9e30:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    9e34:	48 89 e9             	mov    %rbp,%rcx
    9e37:	48 29 c1             	sub    %rax,%rcx
    9e3a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    9e3e:	49 f7 e2             	mul    %r10
    9e41:	b8 30 00 00 00       	mov    $0x30,%eax
    9e46:	48 89 d6             	mov    %rdx,%rsi
    9e49:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    9e4d:	48 d1 ee             	shr    $1,%rsi
    9e50:	48 01 f2             	add    %rsi,%rdx
    9e53:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    9e57:	48 29 d6             	sub    %rdx,%rsi
    9e5a:	74 8e                	je     9dea <fwp_write+0x53a>
    9e5c:	48 83 fe 01          	cmp    $0x1,%rsi
    9e60:	0f 85 7a ff ff ff    	jne    9de0 <fwp_write+0x530>
    9e66:	31 f6                	xor    %esi,%esi
    9e68:	b8 2b 00 00 00       	mov    $0x2b,%eax
    9e6d:	e9 78 ff ff ff       	jmp    9dea <fwp_write+0x53a>
    9e72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9e78:	66 0f 6e cd          	movd   %ebp,%xmm1
    9e7c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    9e7f:	0f 8a c8 09 00 00    	jp     a84d <fwp_write+0xf9d>
    9e85:	0f 28 c1             	movaps %xmm1,%xmm0
    9e88:	0f 54 05 71 5d 00 00 	andps  0x5d71(%rip),%xmm0        # fc00 <msg.8+0x90>
    9e8f:	0f 2e 05 6e 51 00 00 	ucomiss 0x516e(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    9e96:	0f 87 24 08 00 00    	ja     a6c0 <fwp_write+0xe10>
    9e9c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9ea0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    9ea6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9ead:	00 
    9eae:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    9eb2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    9eb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9ebe:	00 00 
    9ec0:	44 89 ee             	mov    %r13d,%esi
    9ec3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    9ec8:	4c 89 e7             	mov    %r12,%rdi
    9ecb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    9ed0:	e8 3b a8 ff ff       	call   4710 <fwp_format_g.constprop.0>
    9ed5:	31 f6                	xor    %esi,%esi
    9ed7:	4c 89 e7             	mov    %r12,%rdi
    9eda:	e8 d1 95 ff ff       	call   34b0 <strtof@plt>
    9edf:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    9ee4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    9ee7:	7a 02                	jp     9eeb <fwp_write+0x63b>
    9ee9:	74 1c                	je     9f07 <fwp_write+0x657>
    9eeb:	41 83 c5 01          	add    $0x1,%r13d
    9eef:	41 83 fd 0a          	cmp    $0xa,%r13d
    9ef3:	75 cb                	jne    9ec0 <fwp_write+0x610>
    9ef5:	be 09 00 00 00       	mov    $0x9,%esi
    9efa:	66 49 0f 6e c7       	movq   %r15,%xmm0
    9eff:	4c 89 e7             	mov    %r12,%rdi
    9f02:	e8 09 a8 ff ff       	call   4710 <fwp_format_g.constprop.0>
    9f07:	4c 89 e7             	mov    %r12,%rdi
    9f0a:	e8 71 a4 ff ff       	call   4380 <fwp_finish_float>
    9f0f:	e9 1c fa ff ff       	jmp    9930 <fwp_write+0x80>
    9f14:	0f 1f 40 00          	nopl   0x0(%rax)
    9f18:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    9f1c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    9f20:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    9f27:	00 
    9f28:	48 89 ef             	mov    %rbp,%rdi
    9f2b:	e8 10 9b ff ff       	call   3a40 <fwp_fmt_u128>
    9f30:	48 89 ef             	mov    %rbp,%rdi
    9f33:	e8 18 95 ff ff       	call   3450 <strlen@plt>
    9f38:	48 89 ee             	mov    %rbp,%rsi
    9f3b:	48 89 df             	mov    %rbx,%rdi
    9f3e:	48 89 c2             	mov    %rax,%rdx
    9f41:	e8 ca a2 ff ff       	call   4210 <buf_put>
    9f46:	e9 fb f9 ff ff       	jmp    9946 <fwp_write+0x96>
    9f4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9f50:	ba 06 00 00 00       	mov    $0x6,%edx
    9f55:	48 8d 35 c6 52 00 00 	lea    0x52c6(%rip),%rsi        # f222 <_IO_stdin_used+0x222>
    9f5c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    9f62:	e8 a9 a2 ff ff       	call   4210 <buf_put>
    9f67:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    9f6e:	ff ff 7f 
    9f71:	48 23 55 00          	and    0x0(%rbp),%rdx
    9f75:	0f 84 86 02 00 00    	je     a201 <fwp_write+0x951>
    9f7b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9f80:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9f84:	48 85 d2             	test   %rdx,%rdx
    9f87:	0f 84 ae 00 00 00    	je     a03b <fwp_write+0x78b>
    9f8d:	8b 0a                	mov    (%rdx),%ecx
    9f8f:	83 f9 1c             	cmp    $0x1c,%ecx
    9f92:	0f 84 58 06 00 00    	je     a5f0 <fwp_write+0xd40>
    9f98:	83 f9 1b             	cmp    $0x1b,%ecx
    9f9b:	0f 87 9a 00 00 00    	ja     a03b <fwp_write+0x78b>
    9fa1:	be 01 00 00 00       	mov    $0x1,%esi
    9fa6:	48 d3 e6             	shl    %cl,%rsi
    9fa9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    9faf:	0f 85 4b 04 00 00    	jne    a400 <fwp_write+0xb50>
    9fb5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    9fbb:	0f 85 0f 04 00 00    	jne    a3d0 <fwp_write+0xb20>
    9fc1:	83 e6 21             	and    $0x21,%esi
    9fc4:	74 75                	je     a03b <fwp_write+0x78b>
    9fc6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    9fcb:	48 85 ff             	test   %rdi,%rdi
    9fce:	79 07                	jns    9fd7 <fwp_write+0x727>
    9fd0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    9fd4:	4c 01 ee             	add    %r13,%rsi
    9fd7:	48 0f be 3e          	movsbq (%rsi),%rdi
    9fdb:	85 c9                	test   %ecx,%ecx
    9fdd:	40 0f b6 f7          	movzbl %dil,%esi
    9fe1:	48 0f 44 f7          	cmove  %rdi,%rsi
    9fe5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9fec:	00 00 00 00 
    9ff0:	31 c9                	xor    %ecx,%ecx
    9ff2:	48 89 df             	mov    %rbx,%rdi
    9ff5:	49 83 c5 01          	add    $0x1,%r13
    9ff9:	e8 b2 f8 ff ff       	call   98b0 <fwp_write>
    9ffe:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a005:	ff ff 7f 
    a008:	48 23 55 00          	and    0x0(%rbp),%rdx
    a00c:	49 39 d5             	cmp    %rdx,%r13
    a00f:	0f 83 ec 01 00 00    	jae    a201 <fwp_write+0x951>
    a015:	ba 02 00 00 00       	mov    $0x2,%edx
    a01a:	48 89 df             	mov    %rbx,%rdi
    a01d:	48 8d 35 fb 51 00 00 	lea    0x51fb(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    a024:	e8 e7 a1 ff ff       	call   4210 <buf_put>
    a029:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a02e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a032:	48 85 d2             	test   %rdx,%rdx
    a035:	0f 85 52 ff ff ff    	jne    9f8d <fwp_write+0x6dd>
    a03b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a040:	48 85 ff             	test   %rdi,%rdi
    a043:	0f 88 cf 05 00 00    	js     a618 <fwp_write+0xd68>
    a049:	48 8b 31             	mov    (%rcx),%rsi
    a04c:	eb a2                	jmp    9ff0 <fwp_write+0x740>
    a04e:	66 90                	xchg   %ax,%ax
    a050:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a057:	00 
    a058:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a05f:	00 00 
    a061:	0f 85 1e fd ff ff    	jne    9d85 <fwp_write+0x4d5>
    a067:	ba 08 00 00 00       	mov    $0x8,%edx
    a06c:	48 8d 35 7c 51 00 00 	lea    0x517c(%rip),%rsi        # f1ef <_IO_stdin_used+0x1ef>
    a073:	e9 4b fa ff ff       	jmp    9ac3 <fwp_write+0x213>
    a078:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a07f:	00 
    a080:	89 e8                	mov    %ebp,%eax
    a082:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a089:	76 03                	jbe    a08e <fwp_write+0x7de>
    a08b:	8b 45 00             	mov    0x0(%rbp),%eax
    a08e:	41 89 c6             	mov    %eax,%r14d
    a091:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a096:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a09b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a09f:	4c 89 ef             	mov    %r13,%rdi
    a0a2:	e8 a9 93 ff ff       	call   3450 <strlen@plt>
    a0a7:	4c 89 ee             	mov    %r13,%rsi
    a0aa:	48 89 df             	mov    %rbx,%rdi
    a0ad:	48 89 c2             	mov    %rax,%rdx
    a0b0:	e8 5b a1 ff ff       	call   4210 <buf_put>
    a0b5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a0ba:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a0be:	85 f6                	test   %esi,%esi
    a0c0:	0f 8e 80 f8 ff ff    	jle    9946 <fwp_write+0x96>
    a0c6:	45 31 ed             	xor    %r13d,%r13d
    a0c9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a0ce:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a0d3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a0d8:	ba 01 00 00 00       	mov    $0x1,%edx
    a0dd:	4c 89 fe             	mov    %r15,%rsi
    a0e0:	48 89 04 24          	mov    %rax,(%rsp)
    a0e4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a0e9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a0ed:	48 89 df             	mov    %rbx,%rdi
    a0f0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a0f4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a0f9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a0fe:	e8 0d a1 ff ff       	call   4210 <buf_put>
    a103:	41 8b 06             	mov    (%r14),%eax
    a106:	83 f8 0e             	cmp    $0xe,%eax
    a109:	0f 84 71 02 00 00    	je     a380 <fwp_write+0xad0>
    a10f:	83 f8 10             	cmp    $0x10,%eax
    a112:	0f 84 38 02 00 00    	je     a350 <fwp_write+0xaa0>
    a118:	83 f8 0a             	cmp    $0xa,%eax
    a11b:	0f 84 7f 04 00 00    	je     a5a0 <fwp_write+0xcf0>
    a121:	0f 8f f9 00 00 00    	jg     a220 <fwp_write+0x970>
    a127:	83 f8 03             	cmp    $0x3,%eax
    a12a:	0f 8f 50 04 00 00    	jg     a580 <fwp_write+0xcd0>
    a130:	85 c0                	test   %eax,%eax
    a132:	78 10                	js     a144 <fwp_write+0x894>
    a134:	48 8b 04 24          	mov    (%rsp),%rax
    a138:	48 c1 e8 3f          	shr    $0x3f,%rax
    a13c:	85 c0                	test   %eax,%eax
    a13e:	0f 85 f9 00 00 00    	jne    a23d <fwp_write+0x98d>
    a144:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a149:	48 8b 34 24          	mov    (%rsp),%rsi
    a14d:	31 c9                	xor    %ecx,%ecx
    a14f:	48 89 df             	mov    %rbx,%rdi
    a152:	e8 59 f7 ff ff       	call   98b0 <fwp_write>
    a157:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a15c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a161:	49 83 c5 01          	add    $0x1,%r13
    a165:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a169:	0f 8f 5f ff ff ff    	jg     a0ce <fwp_write+0x81e>
    a16f:	e9 d2 f7 ff ff       	jmp    9946 <fwp_write+0x96>
    a174:	0f 1f 40 00          	nopl   0x0(%rax)
    a178:	ba 06 00 00 00       	mov    $0x6,%edx
    a17d:	48 8d 35 91 50 00 00 	lea    0x5091(%rip),%rsi        # f215 <_IO_stdin_used+0x215>
    a184:	45 31 ed             	xor    %r13d,%r13d
    a187:	e8 84 a0 ff ff       	call   4210 <buf_put>
    a18c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a191:	75 19                	jne    a1ac <fwp_write+0x8fc>
    a193:	eb 6c                	jmp    a201 <fwp_write+0x951>
    a195:	0f 1f 00             	nopl   (%rax)
    a198:	ba 02 00 00 00       	mov    $0x2,%edx
    a19d:	48 8d 35 7b 50 00 00 	lea    0x507b(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    a1a4:	48 89 df             	mov    %rbx,%rdi
    a1a7:	e8 64 a0 ff ff       	call   4210 <buf_put>
    a1ac:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a1b2:	b9 00 02 00 00       	mov    $0x200,%ecx
    a1b7:	31 c0                	xor    %eax,%eax
    a1b9:	49 83 c5 01          	add    $0x1,%r13
    a1bd:	4c 8d 05 58 50 00 00 	lea    0x5058(%rip),%r8        # f21c <_IO_stdin_used+0x21c>
    a1c4:	ba 02 00 00 00       	mov    $0x2,%edx
    a1c9:	be 00 02 00 00       	mov    $0x200,%esi
    a1ce:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a1d5:	00 
    a1d6:	e8 d5 91 ff ff       	call   33b0 <__snprintf_chk@plt>
    a1db:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a1e2:	00 
    a1e3:	e8 68 92 ff ff       	call   3450 <strlen@plt>
    a1e8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a1ef:	00 
    a1f0:	48 89 df             	mov    %rbx,%rdi
    a1f3:	48 89 c2             	mov    %rax,%rdx
    a1f6:	e8 15 a0 ff ff       	call   4210 <buf_put>
    a1fb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a1ff:	72 97                	jb     a198 <fwp_write+0x8e8>
    a201:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a206:	ba 01 00 00 00       	mov    $0x1,%edx
    a20b:	48 89 df             	mov    %rbx,%rdi
    a20e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a213:	e8 f8 9f ff ff       	call   4210 <buf_put>
    a218:	e9 29 f7 ff ff       	jmp    9946 <fwp_write+0x96>
    a21d:	0f 1f 00             	nopl   (%rax)
    a220:	83 f8 0b             	cmp    $0xb,%eax
    a223:	0f 85 1b ff ff ff    	jne    a144 <fwp_write+0x894>
    a229:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a22e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a232:	83 e0 01             	and    $0x1,%eax
    a235:	85 c0                	test   %eax,%eax
    a237:	0f 84 07 ff ff ff    	je     a144 <fwp_write+0x894>
    a23d:	4c 89 fe             	mov    %r15,%rsi
    a240:	48 89 df             	mov    %rbx,%rdi
    a243:	ba 01 00 00 00       	mov    $0x1,%edx
    a248:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a24d:	e8 be 9f ff ff       	call   4210 <buf_put>
    a252:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a257:	48 8b 34 24          	mov    (%rsp),%rsi
    a25b:	31 c9                	xor    %ecx,%ecx
    a25d:	48 89 df             	mov    %rbx,%rdi
    a260:	e8 4b f6 ff ff       	call   98b0 <fwp_write>
    a265:	ba 01 00 00 00       	mov    $0x1,%edx
    a26a:	4c 89 fe             	mov    %r15,%rsi
    a26d:	48 89 df             	mov    %rbx,%rdi
    a270:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a275:	e8 96 9f ff ff       	call   4210 <buf_put>
    a27a:	e9 d8 fe ff ff       	jmp    a157 <fwp_write+0x8a7>
    a27f:	90                   	nop
    a280:	ba 01 00 00 00       	mov    $0x1,%edx
    a285:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a28a:	48 89 df             	mov    %rbx,%rdi
    a28d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a292:	e8 79 9f ff ff       	call   4210 <buf_put>
    a297:	e9 aa f6 ff ff       	jmp    9946 <fwp_write+0x96>
    a29c:	0f 1f 40 00          	nopl   0x0(%rax)
    a2a0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a2a5:	ba 01 00 00 00       	mov    $0x1,%edx
    a2aa:	48 89 df             	mov    %rbx,%rdi
    a2ad:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a2b2:	e8 59 9f ff ff       	call   4210 <buf_put>
    a2b7:	e9 8a f6 ff ff       	jmp    9946 <fwp_write+0x96>
    a2bc:	0f 1f 40 00          	nopl   0x0(%rax)
    a2c0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a2c4:	48 8b 13             	mov    (%rbx),%rdx
    a2c7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a2cc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a2d0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a2d4:	e9 6d f6 ff ff       	jmp    9946 <fwp_write+0x96>
    a2d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a2e0:	ba 02 00 00 00       	mov    $0x2,%edx
    a2e5:	48 8d 35 33 4f 00 00 	lea    0x4f33(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    a2ec:	48 89 df             	mov    %rbx,%rdi
    a2ef:	e8 1c 9f ff ff       	call   4210 <buf_put>
    a2f4:	e9 72 f8 ff ff       	jmp    9b6b <fwp_write+0x2bb>
    a2f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a300:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a305:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a30a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a30e:	48 89 f7             	mov    %rsi,%rdi
    a311:	48 89 34 24          	mov    %rsi,(%rsp)
    a315:	e8 36 91 ff ff       	call   3450 <strlen@plt>
    a31a:	48 8b 34 24          	mov    (%rsp),%rsi
    a31e:	48 89 df             	mov    %rbx,%rdi
    a321:	48 89 c2             	mov    %rax,%rdx
    a324:	e8 e7 9e ff ff       	call   4210 <buf_put>
    a329:	ba 03 00 00 00       	mov    $0x3,%edx
    a32e:	48 8d 35 0d 4f 00 00 	lea    0x4f0d(%rip),%rsi        # f242 <_IO_stdin_used+0x242>
    a335:	48 89 df             	mov    %rbx,%rdi
    a338:	e8 d3 9e ff ff       	call   4210 <buf_put>
    a33d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a342:	e9 35 f8 ff ff       	jmp    9b7c <fwp_write+0x2cc>
    a347:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a34e:	00 00 
    a350:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a355:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a359:	48 85 ff             	test   %rdi,%rdi
    a35c:	0f 84 e2 fd ff ff    	je     a144 <fwp_write+0x894>
    a362:	48 8d 35 c3 4e 00 00 	lea    0x4ec3(%rip),%rsi        # f22c <_IO_stdin_used+0x22c>
    a369:	e8 c2 91 ff ff       	call   3530 <strcmp@plt>
    a36e:	85 c0                	test   %eax,%eax
    a370:	0f 95 c0             	setne  %al
    a373:	0f b6 c0             	movzbl %al,%eax
    a376:	e9 c1 fd ff ff       	jmp    a13c <fwp_write+0x88c>
    a37b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a380:	31 c0                	xor    %eax,%eax
    a382:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a389:	00 
    a38a:	0f 97 c0             	seta   %al
    a38d:	e9 aa fd ff ff       	jmp    a13c <fwp_write+0x88c>
    a392:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a398:	48 89 df             	mov    %rbx,%rdi
    a39b:	ba 02 00 00 00       	mov    $0x2,%edx
    a3a0:	48 8d 35 82 4e 00 00 	lea    0x4e82(%rip),%rsi        # f229 <_IO_stdin_used+0x229>
    a3a7:	e8 64 9e ff ff       	call   4210 <buf_put>
    a3ac:	4c 89 e8             	mov    %r13,%rax
    a3af:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a3b4:	31 c9                	xor    %ecx,%ecx
    a3b6:	48 c1 e0 04          	shl    $0x4,%rax
    a3ba:	48 89 df             	mov    %rbx,%rdi
    a3bd:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a3c2:	e8 e9 f4 ff ff       	call   98b0 <fwp_write>
    a3c7:	e9 5e f6 ff ff       	jmp    9a2a <fwp_write+0x17a>
    a3cc:	0f 1f 40 00          	nopl   0x0(%rax)
    a3d0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a3d5:	48 85 ff             	test   %rdi,%rdi
    a3d8:	79 0c                	jns    a3e6 <fwp_write+0xb36>
    a3da:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a3e1:	00 
    a3e2:	48 03 75 10          	add    0x10(%rbp),%rsi
    a3e6:	48 63 3e             	movslq (%rsi),%rdi
    a3e9:	83 f9 02             	cmp    $0x2,%ecx
    a3ec:	89 fe                	mov    %edi,%esi
    a3ee:	48 0f 44 f7          	cmove  %rdi,%rsi
    a3f2:	e9 f9 fb ff ff       	jmp    9ff0 <fwp_write+0x740>
    a3f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a3fe:	00 00 
    a400:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a405:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a40a:	48 85 ff             	test   %rdi,%rdi
    a40d:	0f 88 0f 03 00 00    	js     a722 <fwp_write+0xe72>
    a413:	49 0f bf 38          	movswq (%r8),%rdi
    a417:	83 f9 01             	cmp    $0x1,%ecx
    a41a:	0f b7 f7             	movzwl %di,%esi
    a41d:	48 0f 44 f7          	cmove  %rdi,%rsi
    a421:	e9 ca fb ff ff       	jmp    9ff0 <fwp_write+0x740>
    a426:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a42d:	00 00 00 
    a430:	ba 01 00 00 00       	mov    $0x1,%edx
    a435:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a43a:	48 83 c5 08          	add    $0x8,%rbp
    a43e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a443:	e8 c8 9d ff ff       	call   4210 <buf_put>
    a448:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a44d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a452:	4d 85 ed             	test   %r13,%r13
    a455:	75 46                	jne    a49d <fwp_write+0xbed>
    a457:	e9 04 01 00 00       	jmp    a560 <fwp_write+0xcb0>
    a45c:	0f 1f 40 00          	nopl   0x0(%rax)
    a460:	41 80 f9 09          	cmp    $0x9,%r9b
    a464:	0f 84 d6 00 00 00    	je     a540 <fwp_write+0xc90>
    a46a:	41 80 f9 0a          	cmp    $0xa,%r9b
    a46e:	0f 85 9c 00 00 00    	jne    a510 <fwp_write+0xc60>
    a474:	ba 02 00 00 00       	mov    $0x2,%edx
    a479:	48 8d 35 85 4d 00 00 	lea    0x4d85(%rip),%rsi        # f205 <_IO_stdin_used+0x205>
    a480:	48 89 df             	mov    %rbx,%rdi
    a483:	e8 88 9d ff ff       	call   4210 <buf_put>
    a488:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a48f:	00 
    a490:	48 83 c5 01          	add    $0x1,%rbp
    a494:	49 39 ec             	cmp    %rbp,%r12
    a497:	0f 84 c3 00 00 00    	je     a560 <fwp_write+0xcb0>
    a49d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a4a2:	41 80 f9 0d          	cmp    $0xd,%r9b
    a4a6:	74 28                	je     a4d0 <fwp_write+0xc20>
    a4a8:	7e b6                	jle    a460 <fwp_write+0xbb0>
    a4aa:	41 80 f9 22          	cmp    $0x22,%r9b
    a4ae:	74 40                	je     a4f0 <fwp_write+0xc40>
    a4b0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a4b4:	75 5a                	jne    a510 <fwp_write+0xc60>
    a4b6:	ba 02 00 00 00       	mov    $0x2,%edx
    a4bb:	48 8d 35 40 4d 00 00 	lea    0x4d40(%rip),%rsi        # f202 <_IO_stdin_used+0x202>
    a4c2:	48 89 df             	mov    %rbx,%rdi
    a4c5:	e8 46 9d ff ff       	call   4210 <buf_put>
    a4ca:	eb c4                	jmp    a490 <fwp_write+0xbe0>
    a4cc:	0f 1f 40 00          	nopl   0x0(%rax)
    a4d0:	ba 02 00 00 00       	mov    $0x2,%edx
    a4d5:	48 8d 35 2f 4d 00 00 	lea    0x4d2f(%rip),%rsi        # f20b <_IO_stdin_used+0x20b>
    a4dc:	48 89 df             	mov    %rbx,%rdi
    a4df:	e8 2c 9d ff ff       	call   4210 <buf_put>
    a4e4:	eb aa                	jmp    a490 <fwp_write+0xbe0>
    a4e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a4ed:	00 00 00 
    a4f0:	ba 02 00 00 00       	mov    $0x2,%edx
    a4f5:	48 8d 35 03 4d 00 00 	lea    0x4d03(%rip),%rsi        # f1ff <_IO_stdin_used+0x1ff>
    a4fc:	48 89 df             	mov    %rbx,%rdi
    a4ff:	e8 0c 9d ff ff       	call   4210 <buf_put>
    a504:	eb 8a                	jmp    a490 <fwp_write+0xbe0>
    a506:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a50d:	00 00 00 
    a510:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a514:	0f 86 2e 01 00 00    	jbe    a648 <fwp_write+0xd98>
    a51a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a51e:	0f 84 24 01 00 00    	je     a648 <fwp_write+0xd98>
    a524:	ba 01 00 00 00       	mov    $0x1,%edx
    a529:	4c 89 fe             	mov    %r15,%rsi
    a52c:	48 89 df             	mov    %rbx,%rdi
    a52f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a534:	e8 d7 9c ff ff       	call   4210 <buf_put>
    a539:	e9 52 ff ff ff       	jmp    a490 <fwp_write+0xbe0>
    a53e:	66 90                	xchg   %ax,%ax
    a540:	ba 02 00 00 00       	mov    $0x2,%edx
    a545:	48 8d 35 bc 4c 00 00 	lea    0x4cbc(%rip),%rsi        # f208 <_IO_stdin_used+0x208>
    a54c:	48 89 df             	mov    %rbx,%rdi
    a54f:	e8 bc 9c ff ff       	call   4210 <buf_put>
    a554:	e9 37 ff ff ff       	jmp    a490 <fwp_write+0xbe0>
    a559:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a560:	ba 01 00 00 00       	mov    $0x1,%edx
    a565:	4c 89 fe             	mov    %r15,%rsi
    a568:	48 89 df             	mov    %rbx,%rdi
    a56b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a570:	e8 9b 9c ff ff       	call   4210 <buf_put>
    a575:	e9 cc f3 ff ff       	jmp    9946 <fwp_write+0x96>
    a57a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a580:	83 f8 04             	cmp    $0x4,%eax
    a583:	0f 85 bb fb ff ff    	jne    a144 <fwp_write+0x894>
    a589:	48 8b 04 24          	mov    (%rsp),%rax
    a58d:	48 8b 40 08          	mov    0x8(%rax),%rax
    a591:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    a596:	48 c1 e8 3f          	shr    $0x3f,%rax
    a59a:	e9 96 fc ff ff       	jmp    a235 <fwp_write+0x985>
    a59f:	90                   	nop
    a5a0:	8b 0c 24             	mov    (%rsp),%ecx
    a5a3:	31 c0                	xor    %eax,%eax
    a5a5:	85 c9                	test   %ecx,%ecx
    a5a7:	0f 98 c0             	sets   %al
    a5aa:	e9 86 fc ff ff       	jmp    a235 <fwp_write+0x985>
    a5af:	90                   	nop
    a5b0:	48 f7 d8             	neg    %rax
    a5b3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    a5ba:	00 
    a5bb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    a5c2:	2d 
    a5c3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a5ca:	00 
    a5cb:	48 83 d2 00          	adc    $0x0,%rdx
    a5cf:	48 89 c6             	mov    %rax,%rsi
    a5d2:	48 f7 da             	neg    %rdx
    a5d5:	e8 66 94 ff ff       	call   3a40 <fwp_fmt_u128>
    a5da:	e9 51 f3 ff ff       	jmp    9930 <fwp_write+0x80>
    a5df:	90                   	nop
    a5e0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    a5e5:	e9 c3 f5 ff ff       	jmp    9bad <fwp_write+0x2fd>
    a5ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a5f0:	4c 89 e9             	mov    %r13,%rcx
    a5f3:	48 c1 e1 04          	shl    $0x4,%rcx
    a5f7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    a5fc:	48 85 ff             	test   %rdi,%rdi
    a5ff:	0f 89 eb f9 ff ff    	jns    9ff0 <fwp_write+0x740>
    a605:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a609:	48 89 ce             	mov    %rcx,%rsi
    a60c:	e9 df f9 ff ff       	jmp    9ff0 <fwp_write+0x740>
    a611:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a618:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a61f:	00 
    a620:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a624:	e9 20 fa ff ff       	jmp    a049 <fwp_write+0x799>
    a629:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a630:	ba 02 00 00 00       	mov    $0x2,%edx
    a635:	48 8d 35 93 4b 00 00 	lea    0x4b93(%rip),%rsi        # f1cf <_IO_stdin_used+0x1cf>
    a63c:	e9 2d f7 ff ff       	jmp    9d6e <fwp_write+0x4be>
    a641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a648:	4c 8d 05 bf 4b 00 00 	lea    0x4bbf(%rip),%r8        # f20e <_IO_stdin_used+0x20e>
    a64f:	b9 10 00 00 00       	mov    $0x10,%ecx
    a654:	31 c0                	xor    %eax,%eax
    a656:	ba 02 00 00 00       	mov    $0x2,%edx
    a65b:	be 10 00 00 00       	mov    $0x10,%esi
    a660:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a667:	00 
    a668:	e8 43 8d ff ff       	call   33b0 <__snprintf_chk@plt>
    a66d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a674:	00 
    a675:	e8 d6 8d ff ff       	call   3450 <strlen@plt>
    a67a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a681:	00 
    a682:	48 89 df             	mov    %rbx,%rdi
    a685:	48 89 c2             	mov    %rax,%rdx
    a688:	e8 83 9b ff ff       	call   4210 <buf_put>
    a68d:	e9 fe fd ff ff       	jmp    a490 <fwp_write+0xbe0>
    a692:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a698:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a69c:	48 8d 35 26 4b 00 00 	lea    0x4b26(%rip),%rsi        # f1c9 <_IO_stdin_used+0x1c9>
    a6a3:	48 8d 05 1e 4b 00 00 	lea    0x4b1e(%rip),%rax        # f1c8 <_IO_stdin_used+0x1c8>
    a6aa:	4c 89 e7             	mov    %r12,%rdi
    a6ad:	66 0f 2f c8          	comisd %xmm0,%xmm1
    a6b1:	48 0f 46 f0          	cmovbe %rax,%rsi
    a6b5:	e8 36 8d ff ff       	call   33f0 <strcpy@plt>
    a6ba:	e9 71 f2 ff ff       	jmp    9930 <fwp_write+0x80>
    a6bf:	90                   	nop
    a6c0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a6c4:	48 8d 35 fe 4a 00 00 	lea    0x4afe(%rip),%rsi        # f1c9 <_IO_stdin_used+0x1c9>
    a6cb:	48 8d 05 f6 4a 00 00 	lea    0x4af6(%rip),%rax        # f1c8 <_IO_stdin_used+0x1c8>
    a6d2:	0f 2f c8             	comiss %xmm0,%xmm1
    a6d5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a6dc:	00 
    a6dd:	4c 89 e7             	mov    %r12,%rdi
    a6e0:	48 0f 46 f0          	cmovbe %rax,%rsi
    a6e4:	e8 07 8d ff ff       	call   33f0 <strcpy@plt>
    a6e9:	e9 42 f2 ff ff       	jmp    9930 <fwp_write+0x80>
    a6ee:	66 90                	xchg   %ax,%ax
    a6f0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    a6f5:	45 85 c0             	test   %r8d,%r8d
    a6f8:	75 34                	jne    a72e <fwp_write+0xe7e>
    a6fa:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a701:	00 
    a702:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a709:	00 00 
    a70b:	0f 85 74 f6 ff ff    	jne    9d85 <fwp_write+0x4d5>
    a711:	ba 02 00 00 00       	mov    $0x2,%edx
    a716:	48 8d 35 22 4b 00 00 	lea    0x4b22(%rip),%rsi        # f23f <_IO_stdin_used+0x23f>
    a71d:	e9 a1 f3 ff ff       	jmp    9ac3 <fwp_write+0x213>
    a722:	48 03 75 10          	add    0x10(%rbp),%rsi
    a726:	49 89 f0             	mov    %rsi,%r8
    a729:	e9 e5 fc ff ff       	jmp    a413 <fwp_write+0xb63>
    a72e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    a733:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a738:	85 ff                	test   %edi,%edi
    a73a:	0f 84 fa f3 ff ff    	je     9b3a <fwp_write+0x28a>
    a740:	ba 01 00 00 00       	mov    $0x1,%edx
    a745:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a74a:	48 89 df             	mov    %rbx,%rdi
    a74d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a752:	e8 b9 9a ff ff       	call   4210 <buf_put>
    a757:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    a75c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a761:	41 be 01 00 00 00    	mov    $0x1,%r14d
    a767:	85 c0                	test   %eax,%eax
    a769:	0f 8f f0 f3 ff ff    	jg     9b5f <fwp_write+0x2af>
    a76f:	e9 34 f4 ff ff       	jmp    9ba8 <fwp_write+0x2f8>
    a774:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a778:	49 89 c5             	mov    %rax,%r13
    a77b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a780:	49 89 c4             	mov    %rax,%r12
    a783:	49 c1 fd 3f          	sar    $0x3f,%r13
    a787:	4c 09 e8             	or     %r13,%rax
    a78a:	0f 84 a7 00 00 00    	je     a837 <fwp_write+0xf87>
    a790:	48 8d 2d 69 6c 00 00 	lea    0x6c69(%rip),%rbp        # 11400 <units.5>
    a797:	4d 89 e7             	mov    %r12,%r15
    a79a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a79e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    a7a3:	4c 89 ff             	mov    %r15,%rdi
    a7a6:	4c 89 ee             	mov    %r13,%rsi
    a7a9:	44 89 0c 24          	mov    %r9d,(%rsp)
    a7ad:	48 99                	cqto
    a7af:	48 89 d1             	mov    %rdx,%rcx
    a7b2:	48 89 c2             	mov    %rax,%rdx
    a7b5:	e8 c6 41 00 00       	call   e980 <__divmodti4>
    a7ba:	44 8b 0c 24          	mov    (%rsp),%r9d
    a7be:	48 89 c1             	mov    %rax,%rcx
    a7c1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a7c6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    a7cb:	0f 84 94 00 00 00    	je     a865 <fwp_write+0xfb5>
    a7d1:	41 83 c1 01          	add    $0x1,%r9d
    a7d5:	48 83 c5 10          	add    $0x10,%rbp
    a7d9:	41 83 f9 05          	cmp    $0x5,%r9d
    a7dd:	75 bb                	jne    a79a <fwp_write+0xeea>
    a7df:	4d 85 ed             	test   %r13,%r13
    a7e2:	79 53                	jns    a837 <fwp_write+0xf87>
    a7e4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a7e9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a7ee:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a7f3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a7f8:	48 99                	cqto
    a7fa:	48 f7 d8             	neg    %rax
    a7fd:	48 83 d2 00          	adc    $0x0,%rdx
    a801:	48 89 c6             	mov    %rax,%rsi
    a804:	48 f7 da             	neg    %rdx
    a807:	e8 34 92 ff ff       	call   3a40 <fwp_fmt_u128>
    a80c:	49 89 e8             	mov    %rbp,%r8
    a80f:	ba 00 02 00 00       	mov    $0x200,%edx
    a814:	be 02 00 00 00       	mov    $0x2,%esi
    a819:	31 c0                	xor    %eax,%eax
    a81b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a822:	00 
    a823:	48 8d 0d 10 4a 00 00 	lea    0x4a10(%rip),%rcx        # f23a <_IO_stdin_used+0x23a>
    a82a:	4c 89 e7             	mov    %r12,%rdi
    a82d:	e8 ae 8e ff ff       	call   36e0 <__sprintf_chk@plt>
    a832:	e9 f9 f0 ff ff       	jmp    9930 <fwp_write+0x80>
    a837:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a83c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a841:	31 d2                	xor    %edx,%edx
    a843:	48 89 ef             	mov    %rbp,%rdi
    a846:	e8 f5 91 ff ff       	call   3a40 <fwp_fmt_u128>
    a84b:	eb bf                	jmp    a80c <fwp_write+0xf5c>
    a84d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    a854:	4e 61 4e 00 
    a858:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a85f:	00 
    a860:	e9 cb f0 ff ff       	jmp    9930 <fwp_write+0x80>
    a865:	44 89 0c 24          	mov    %r9d,(%rsp)
    a869:	48 89 c8             	mov    %rcx,%rax
    a86c:	48 85 d2             	test   %rdx,%rdx
    a86f:	78 51                	js     a8c2 <fwp_write+0x1012>
    a871:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a876:	48 89 c6             	mov    %rax,%rsi
    a879:	48 89 ef             	mov    %rbp,%rdi
    a87c:	e8 bf 91 ff ff       	call   3a40 <fwp_fmt_u128>
    a881:	44 8b 0c 24          	mov    (%rsp),%r9d
    a885:	49 63 c1             	movslq %r9d,%rax
    a888:	49 89 e8             	mov    %rbp,%r8
    a88b:	ba 00 02 00 00       	mov    $0x200,%edx
    a890:	be 02 00 00 00       	mov    $0x2,%esi
    a895:	48 c1 e0 04          	shl    $0x4,%rax
    a899:	48 8d 3d 60 6b 00 00 	lea    0x6b60(%rip),%rdi        # 11400 <units.5>
    a8a0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a8a7:	00 
    a8a8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    a8ac:	48 8d 0d 82 49 00 00 	lea    0x4982(%rip),%rcx        # f235 <_IO_stdin_used+0x235>
    a8b3:	4c 89 e7             	mov    %r12,%rdi
    a8b6:	31 c0                	xor    %eax,%eax
    a8b8:	e8 23 8e ff ff       	call   36e0 <__sprintf_chk@plt>
    a8bd:	e9 6e f0 ff ff       	jmp    9930 <fwp_write+0x80>
    a8c2:	48 f7 d8             	neg    %rax
    a8c5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a8ca:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a8cf:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a8d4:	48 83 d2 00          	adc    $0x0,%rdx
    a8d8:	48 89 c6             	mov    %rax,%rsi
    a8db:	48 f7 da             	neg    %rdx
    a8de:	e8 5d 91 ff ff       	call   3a40 <fwp_fmt_u128>
    a8e3:	44 8b 0c 24          	mov    (%rsp),%r9d
    a8e7:	eb 9c                	jmp    a885 <fwp_write+0xfd5>
    a8e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000a8f0 <fwp_hof0.constprop.0>:
    a8f0:	55                   	push   %rbp
    a8f1:	48 89 e5             	mov    %rsp,%rbp
    a8f4:	41 57                	push   %r15
    a8f6:	41 56                	push   %r14
    a8f8:	41 55                	push   %r13
    a8fa:	41 54                	push   %r12
    a8fc:	53                   	push   %rbx
    a8fd:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    a904:	48 89 bd 58 ff ff ff 	mov    %rdi,-0xa8(%rbp)
    a90b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    a912:	00 00 
    a914:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    a918:	31 c0                	xor    %eax,%eax
    a91a:	48 85 f6             	test   %rsi,%rsi
    a91d:	0f 84 76 06 00 00    	je     af99 <fwp_hof0.constprop.0+0x6a9>
    a923:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
    a927:	49 89 f7             	mov    %rsi,%r15
    a92a:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
    a931:	48 8d 35 c8 8e 01 00 	lea    0x18ec8(%rip),%rsi        # 23800 <fwp_heap>
    a938:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    a93f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    a946:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    a94d:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    a951:	48 c1 e2 10          	shl    $0x10,%rdx
    a955:	48 39 d0             	cmp    %rdx,%rax
    a958:	73 5d                	jae    a9b7 <fwp_hof0.constprop.0+0xc7>
    a95a:	48 89 c2             	mov    %rax,%rdx
    a95d:	48 c1 ea 10          	shr    $0x10,%rdx
    a961:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a965:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    a96c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a970:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a974:	48 85 ff             	test   %rdi,%rdi
    a977:	74 3e                	je     a9b7 <fwp_hof0.constprop.0+0xc7>
    a979:	0f b6 0a             	movzbl (%rdx),%ecx
    a97c:	80 f9 02             	cmp    $0x2,%cl
    a97f:	0f 84 bd 0a 00 00    	je     b442 <fwp_hof0.constprop.0+0xb52>
    a985:	80 f9 01             	cmp    $0x1,%cl
    a988:	75 2d                	jne    a9b7 <fwp_hof0.constprop.0+0xc7>
    a98a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a98d:	0f b7 c0             	movzwl %ax,%eax
    a990:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a993:	48 0f af c1          	imul   %rcx,%rax
    a997:	48 c1 e8 20          	shr    $0x20,%rax
    a99b:	48 39 d0             	cmp    %rdx,%rax
    a99e:	73 17                	jae    a9b7 <fwp_hof0.constprop.0+0xc7>
    a9a0:	48 01 c7             	add    %rax,%rdi
    a9a3:	0f b6 07             	movzbl (%rdi),%eax
    a9a6:	84 c0                	test   %al,%al
    a9a8:	74 0d                	je     a9b7 <fwp_hof0.constprop.0+0xc7>
    a9aa:	3c fd                	cmp    $0xfd,%al
    a9ac:	0f 87 6e 0b 00 00    	ja     b520 <fwp_hof0.constprop.0+0xc30>
    a9b2:	83 c0 01             	add    $0x1,%eax
    a9b5:	88 07                	mov    %al,(%rdi)
    a9b7:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    a9be:	4c 89 bd 50 ff ff ff 	mov    %r15,-0xb0(%rbp)
    a9c5:	48 c7 85 60 ff ff ff 	movq   $0xc7,-0xa0(%rbp)
    a9cc:	c7 00 00 00 
    a9d0:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    a9d4:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    a9d8:	48 8b 15 79 aa 01 00 	mov    0x1aa79(%rip),%rdx        # 25458 <fwp_fns>
    a9df:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
    a9e3:	48 8d 05 2e 86 00 00 	lea    0x862e(%rip),%rax        # 13018 <fc12>
    a9ea:	44 8b 20             	mov    (%rax),%r12d
    a9ed:	49 c1 e4 05          	shl    $0x5,%r12
    a9f1:	49 01 d4             	add    %rdx,%r12
    a9f4:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
    a9f9:	48 85 c9             	test   %rcx,%rcx
    a9fc:	0f 84 0d 0a 00 00    	je     b40f <fwp_hof0.constprop.0+0xb1f>
    aa02:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    aa07:	0f 84 6b 08 00 00    	je     b278 <fwp_hof0.constprop.0+0x988>
    aa0d:	48 8d 3d ec 8d 01 00 	lea    0x18dec(%rip),%rdi        # 23800 <fwp_heap>
    aa14:	48 8d 05 fd 85 00 00 	lea    0x85fd(%rip),%rax        # 13018 <fc12>
    aa1b:	48 8b b7 d8 13 00 00 	mov    0x13d8(%rdi),%rsi
    aa22:	48 2b 87 b0 13 00 00 	sub    0x13b0(%rdi),%rax
    aa29:	48 89 f1             	mov    %rsi,%rcx
    aa2c:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
    aa30:	48 c1 e1 10          	shl    $0x10,%rcx
    aa34:	48 39 c8             	cmp    %rcx,%rax
    aa37:	73 5f                	jae    aa98 <fwp_hof0.constprop.0+0x1a8>
    aa39:	48 89 c1             	mov    %rax,%rcx
    aa3c:	48 c1 e9 10          	shr    $0x10,%rcx
    aa40:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    aa44:	48 8b 8f f8 13 00 00 	mov    0x13f8(%rdi),%rcx
    aa4b:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    aa4f:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    aa53:	48 85 ff             	test   %rdi,%rdi
    aa56:	74 40                	je     aa98 <fwp_hof0.constprop.0+0x1a8>
    aa58:	0f b6 31             	movzbl (%rcx),%esi
    aa5b:	40 80 fe 02          	cmp    $0x2,%sil
    aa5f:	0f 84 f8 08 00 00    	je     b35d <fwp_hof0.constprop.0+0xa6d>
    aa65:	40 80 fe 01          	cmp    $0x1,%sil
    aa69:	75 2d                	jne    aa98 <fwp_hof0.constprop.0+0x1a8>
    aa6b:	8b 71 18             	mov    0x18(%rcx),%esi
    aa6e:	0f b7 c0             	movzwl %ax,%eax
    aa71:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    aa74:	48 0f af c6          	imul   %rsi,%rax
    aa78:	48 c1 e8 20          	shr    $0x20,%rax
    aa7c:	48 39 c8             	cmp    %rcx,%rax
    aa7f:	73 17                	jae    aa98 <fwp_hof0.constprop.0+0x1a8>
    aa81:	48 01 c7             	add    %rax,%rdi
    aa84:	0f b6 07             	movzbl (%rdi),%eax
    aa87:	84 c0                	test   %al,%al
    aa89:	74 0d                	je     aa98 <fwp_hof0.constprop.0+0x1a8>
    aa8b:	3c fd                	cmp    $0xfd,%al
    aa8d:	0f 87 56 09 00 00    	ja     b3e9 <fwp_hof0.constprop.0+0xaf9>
    aa93:	83 c0 01             	add    $0x1,%eax
    aa96:	88 07                	mov    %al,(%rdi)
    aa98:	48 8d 05 79 85 00 00 	lea    0x8579(%rip),%rax        # 13018 <fc12>
    aa9f:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    aaa6:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    aaaa:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    aab1:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    aab5:	48 8d 05 5c 85 00 00 	lea    0x855c(%rip),%rax        # 13018 <fc12>
    aabc:	41 8b 0c 24          	mov    (%r12),%ecx
    aac0:	2b 48 04             	sub    0x4(%rax),%ecx
    aac3:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    aac7:	44 8b 6d 94          	mov    -0x6c(%rbp),%r13d
    aacb:	89 4d 90             	mov    %ecx,-0x70(%rbp)
    aace:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    aad2:	49 89 c1             	mov    %rax,%r9
    aad5:	8b 00                	mov    (%rax),%eax
    aad7:	44 39 e9             	cmp    %r13d,%ecx
    aada:	44 0f 46 e9          	cmovbe %ecx,%r13d
    aade:	4d 89 cf             	mov    %r9,%r15
    aae1:	48 c1 e0 05          	shl    $0x5,%rax
    aae5:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    aae9:	44 89 ad 7c ff ff ff 	mov    %r13d,-0x84(%rbp)
    aaf0:	4d 8b 50 18          	mov    0x18(%r8),%r10
    aaf4:	4d 85 d2             	test   %r10,%r10
    aaf7:	75 58                	jne    ab51 <fwp_hof0.constprop.0+0x261>
    aaf9:	e9 e5 01 00 00       	jmp    ace3 <fwp_hof0.constprop.0+0x3f3>
    aafe:	66 90                	xchg   %ax,%ax
    ab00:	45 85 ff             	test   %r15d,%r15d
    ab03:	74 69                	je     ab6e <fwp_hof0.constprop.0+0x27e>
    ab05:	4c 89 e7             	mov    %r12,%rdi
    ab08:	41 ff 12             	call   *(%r10)
    ab0b:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ab0f:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
    ab13:	e8 38 c3 ff ff       	call   6e50 <fwp_closure_drop>
    ab18:	44 39 eb             	cmp    %r13d,%ebx
    ab1b:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    ab1f:	0f 84 43 07 00 00    	je     b268 <fwp_hof0.constprop.0+0x978>
    ab25:	44 8b 00             	mov    (%rax),%r8d
    ab28:	45 29 fe             	sub    %r15d,%r14d
    ab2b:	4d 8d 24 dc          	lea    (%r12,%rbx,8),%r12
    ab2f:	49 89 c1             	mov    %rax,%r9
    ab32:	45 89 f5             	mov    %r14d,%r13d
    ab35:	49 c1 e0 05          	shl    $0x5,%r8
    ab39:	4c 03 05 18 a9 01 00 	add    0x1a918(%rip),%r8        # 25458 <fwp_fns>
    ab40:	4d 8b 50 18          	mov    0x18(%r8),%r10
    ab44:	4d 85 d2             	test   %r10,%r10
    ab47:	0f 84 93 01 00 00    	je     ace0 <fwp_hof0.constprop.0+0x3f0>
    ab4d:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    ab51:	41 8b 49 04          	mov    0x4(%r9),%ecx
    ab55:	45 8b 38             	mov    (%r8),%r15d
    ab58:	46 8d 34 29          	lea    (%rcx,%r13,1),%r14d
    ab5c:	45 39 fe             	cmp    %r15d,%r14d
    ab5f:	0f 82 5b 04 00 00    	jb     afc0 <fwp_hof0.constprop.0+0x6d0>
    ab65:	44 89 fb             	mov    %r15d,%ebx
    ab68:	29 cb                	sub    %ecx,%ebx
    ab6a:	85 c9                	test   %ecx,%ecx
    ab6c:	74 92                	je     ab00 <fwp_hof0.constprop.0+0x210>
    ab6e:	45 85 ff             	test   %r15d,%r15d
    ab71:	b8 01 00 00 00       	mov    $0x1,%eax
    ab76:	48 89 e6             	mov    %rsp,%rsi
    ab79:	48 89 65 a0          	mov    %rsp,-0x60(%rbp)
    ab7d:	41 0f 45 c7          	cmovne %r15d,%eax
    ab81:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    ab88:	00 
    ab89:	48 c1 e8 04          	shr    $0x4,%rax
    ab8d:	48 c1 e0 04          	shl    $0x4,%rax
    ab91:	48 89 c7             	mov    %rax,%rdi
    ab94:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    ab9b:	48 29 fe             	sub    %rdi,%rsi
    ab9e:	48 39 f4             	cmp    %rsi,%rsp
    aba1:	74 15                	je     abb8 <fwp_hof0.constprop.0+0x2c8>
    aba3:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    abaa:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    abb1:	00 00 
    abb3:	48 39 f4             	cmp    %rsi,%rsp
    abb6:	75 eb                	jne    aba3 <fwp_hof0.constprop.0+0x2b3>
    abb8:	25 ff 0f 00 00       	and    $0xfff,%eax
    abbd:	48 29 c4             	sub    %rax,%rsp
    abc0:	48 85 c0             	test   %rax,%rax
    abc3:	74 06                	je     abcb <fwp_hof0.constprop.0+0x2db>
    abc5:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    abcb:	89 cf                	mov    %ecx,%edi
    abcd:	49 89 e3             	mov    %rsp,%r11
    abd0:	31 c0                	xor    %eax,%eax
    abd2:	48 c1 e7 03          	shl    $0x3,%rdi
    abd6:	85 c9                	test   %ecx,%ecx
    abd8:	74 18                	je     abf2 <fwp_hof0.constprop.0+0x302>
    abda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    abe0:	49 8b 54 01 08       	mov    0x8(%r9,%rax,1),%rdx
    abe5:	49 89 14 03          	mov    %rdx,(%r11,%rax,1)
    abe9:	48 83 c0 08          	add    $0x8,%rax
    abed:	48 39 c7             	cmp    %rax,%rdi
    abf0:	75 ee                	jne    abe0 <fwp_hof0.constprop.0+0x2f0>
    abf2:	85 db                	test   %ebx,%ebx
    abf4:	74 1f                	je     ac15 <fwp_hof0.constprop.0+0x325>
    abf6:	89 de                	mov    %ebx,%esi
    abf8:	4c 89 e0             	mov    %r12,%rax
    abfb:	49 8d 3c f4          	lea    (%r12,%rsi,8),%rdi
    abff:	90                   	nop
    ac00:	48 8b 30             	mov    (%rax),%rsi
    ac03:	89 ca                	mov    %ecx,%edx
    ac05:	48 83 c0 08          	add    $0x8,%rax
    ac09:	83 c1 01             	add    $0x1,%ecx
    ac0c:	49 89 34 d3          	mov    %rsi,(%r11,%rdx,8)
    ac10:	48 39 c7             	cmp    %rax,%rdi
    ac13:	75 eb                	jne    ac00 <fwp_hof0.constprop.0+0x310>
    ac15:	48 8d 15 e4 8b 01 00 	lea    0x18be4(%rip),%rdx        # 23800 <fwp_heap>
    ac1c:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    ac20:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    ac27:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    ac2e:	48 89 f1             	mov    %rsi,%rcx
    ac31:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
    ac35:	48 c1 e1 10          	shl    $0x10,%rcx
    ac39:	48 39 c8             	cmp    %rcx,%rax
    ac3c:	73 4c                	jae    ac8a <fwp_hof0.constprop.0+0x39a>
    ac3e:	48 89 c1             	mov    %rax,%rcx
    ac41:	48 c1 e9 10          	shr    $0x10,%rcx
    ac45:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    ac49:	48 8b 0d a8 9f 01 00 	mov    0x19fa8(%rip),%rcx        # 24bf8 <fwp_heap+0x13f8>
    ac50:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    ac54:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    ac58:	48 85 f6             	test   %rsi,%rsi
    ac5b:	74 2d                	je     ac8a <fwp_hof0.constprop.0+0x39a>
    ac5d:	0f b6 39             	movzbl (%rcx),%edi
    ac60:	40 80 ff 02          	cmp    $0x2,%dil
    ac64:	74 6a                	je     acd0 <fwp_hof0.constprop.0+0x3e0>
    ac66:	40 80 ff 01          	cmp    $0x1,%dil
    ac6a:	75 1e                	jne    ac8a <fwp_hof0.constprop.0+0x39a>
    ac6c:	8b 79 18             	mov    0x18(%rcx),%edi
    ac6f:	0f b7 c0             	movzwl %ax,%eax
    ac72:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    ac75:	48 0f af c7          	imul   %rdi,%rax
    ac79:	48 c1 e8 20          	shr    $0x20,%rax
    ac7d:	48 39 c8             	cmp    %rcx,%rax
    ac80:	73 08                	jae    ac8a <fwp_hof0.constprop.0+0x39a>
    ac82:	48 01 c6             	add    %rax,%rsi
    ac85:	80 3e 01             	cmpb   $0x1,(%rsi)
    ac88:	74 36                	je     acc0 <fwp_hof0.constprop.0+0x3d0>
    ac8a:	4c 89 45 80          	mov    %r8,-0x80(%rbp)
    ac8e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ac92:	be 01 00 00 00       	mov    $0x1,%esi
    ac97:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
    ac9b:	41 ff 52 08          	call   *0x8(%r10)
    ac9f:	4c 8b 5d 98          	mov    -0x68(%rbp),%r11
    aca3:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
    aca7:	49 8b 40 18          	mov    0x18(%r8),%rax
    acab:	4c 89 df             	mov    %r11,%rdi
    acae:	ff 10                	call   *(%rax)
    acb0:	48 8b 65 a0          	mov    -0x60(%rbp),%rsp
    acb4:	e9 52 fe ff ff       	jmp    ab0b <fwp_hof0.constprop.0+0x21b>
    acb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    acc0:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    acc7:	00 
    acc8:	eb dd                	jmp    aca7 <fwp_hof0.constprop.0+0x3b7>
    acca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    acd0:	66 85 c0             	test   %ax,%ax
    acd3:	75 b5                	jne    ac8a <fwp_hof0.constprop.0+0x39a>
    acd5:	eb ae                	jmp    ac85 <fwp_hof0.constprop.0+0x395>
    acd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    acde:	00 00 
    ace0:	49 89 c7             	mov    %rax,%r15
    ace3:	4c 89 ff             	mov    %r15,%rdi
    ace6:	e8 35 ba ff ff       	call   6720 <fwp_rc_share>
    aceb:	45 85 ed             	test   %r13d,%r13d
    acee:	74 21                	je     ad11 <fwp_hof0.constprop.0+0x421>
    acf0:	44 89 ea             	mov    %r13d,%edx
    acf3:	4c 89 e3             	mov    %r12,%rbx
    acf6:	4d 8d 34 d4          	lea    (%r12,%rdx,8),%r14
    acfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ad00:	48 8b 3b             	mov    (%rbx),%rdi
    ad03:	48 83 c3 08          	add    $0x8,%rbx
    ad07:	e8 14 ba ff ff       	call   6720 <fwp_rc_share>
    ad0c:	4c 39 f3             	cmp    %r14,%rbx
    ad0f:	75 ef                	jne    ad00 <fwp_hof0.constprop.0+0x410>
    ad11:	4c 89 e2             	mov    %r12,%rdx
    ad14:	44 89 ee             	mov    %r13d,%esi
    ad17:	4c 89 ff             	mov    %r15,%rdi
    ad1a:	e8 f1 b0 ff ff       	call   5e10 <fwp_apply>
    ad1f:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    ad23:	8b 75 94             	mov    -0x6c(%rbp),%esi
    ad26:	39 75 90             	cmp    %esi,-0x70(%rbp)
    ad29:	0f 83 87 00 00 00    	jae    adb6 <fwp_hof0.constprop.0+0x4c6>
    ad2f:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    ad35:	48 8b 7d 88          	mov    -0x78(%rbp),%rdi
    ad39:	48 89 c2             	mov    %rax,%rdx
    ad3c:	48 8d 04 c7          	lea    (%rdi,%rax,8),%rax
    ad40:	29 d6                	sub    %edx,%esi
    ad42:	48 8b 15 0f a7 01 00 	mov    0x1a70f(%rip),%rdx        # 25458 <fwp_fns>
    ad49:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    ad4d:	89 75 94             	mov    %esi,-0x6c(%rbp)
    ad50:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    ad54:	44 8b 26             	mov    (%rsi),%r12d
    ad57:	48 89 f0             	mov    %rsi,%rax
    ad5a:	49 c1 e4 05          	shl    $0x5,%r12
    ad5e:	49 01 d4             	add    %rdx,%r12
    ad61:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
    ad67:	0f 85 4f fd ff ff    	jne    aabc <fwp_hof0.constprop.0+0x1cc>
    ad6d:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ad71:	e8 aa b9 ff ff       	call   6720 <fwp_rc_share>
    ad76:	44 8b 75 94          	mov    -0x6c(%rbp),%r14d
    ad7a:	45 85 f6             	test   %r14d,%r14d
    ad7d:	74 23                	je     ada2 <fwp_hof0.constprop.0+0x4b2>
    ad7f:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    ad83:	31 db                	xor    %ebx,%ebx
    ad85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ad8c:	00 00 00 00 
    ad90:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    ad94:	48 83 c3 01          	add    $0x1,%rbx
    ad98:	e8 83 b9 ff ff       	call   6720 <fwp_rc_share>
    ad9d:	44 39 f3             	cmp    %r14d,%ebx
    ada0:	72 ee                	jb     ad90 <fwp_hof0.constprop.0+0x4a0>
    ada2:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    ada6:	8b 75 94             	mov    -0x6c(%rbp),%esi
    ada9:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    adad:	e8 5e b0 ff ff       	call   5e10 <fwp_apply>
    adb2:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    adb6:	48 83 ad 60 ff ff ff 	subq   $0x1,-0xa0(%rbp)
    adbd:	01 
    adbe:	0f 85 10 fc ff ff    	jne    a9d4 <fwp_hof0.constprop.0+0xe4>
    adc4:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    adc8:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    adcf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    add3:	b9 01 00 00 00       	mov    $0x1,%ecx
    add8:	48 8d 15 a1 7d 00 00 	lea    0x7da1(%rip),%rdx        # 12b80 <d0>
    addf:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
    ade6:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
    aded:	00 
    adee:	0f 29 45 b0          	movaps %xmm0,-0x50(%rbp)
    adf2:	e8 b9 ea ff ff       	call   98b0 <fwp_write>
    adf7:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
    adfb:	4c 8b 75 b8          	mov    -0x48(%rbp),%r14
    adff:	48 8d 05 8b 42 00 00 	lea    0x428b(%rip),%rax        # f091 <_IO_stdin_used+0x91>
    ae06:	48 85 c9             	test   %rcx,%rcx
    ae09:	48 0f 44 c8          	cmove  %rax,%rcx
    ae0d:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    ae11:	0f 87 f5 06 00 00    	ja     b50c <fwp_hof0.constprop.0+0xc1c>
    ae17:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    ae1b:	be 01 00 00 00       	mov    $0x1,%esi
    ae20:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    ae24:	e8 c7 ae ff ff       	call   5cf0 <fwp_heap_alloc>
    ae29:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
    ae2d:	4c 89 f2             	mov    %r14,%rdx
    ae30:	4c 89 30             	mov    %r14,(%rax)
    ae33:	4c 8d 60 08          	lea    0x8(%rax),%r12
    ae37:	48 89 c3             	mov    %rax,%rbx
    ae3a:	4c 89 e7             	mov    %r12,%rdi
    ae3d:	e8 5e 87 ff ff       	call   35a0 <memcpy@plt>
    ae42:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    ae48:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
    ae4c:	e8 6f 85 ff ff       	call   33c0 <free@plt>
    ae51:	48 8d 35 a8 89 01 00 	lea    0x189a8(%rip),%rsi        # 23800 <fwp_heap>
    ae58:	48 89 d8             	mov    %rbx,%rax
    ae5b:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    ae62:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    ae69:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    ae6d:	48 c1 e2 10          	shl    $0x10,%rdx
    ae71:	48 39 d0             	cmp    %rdx,%rax
    ae74:	73 57                	jae    aecd <fwp_hof0.constprop.0+0x5dd>
    ae76:	48 89 c2             	mov    %rax,%rdx
    ae79:	48 c1 ea 10          	shr    $0x10,%rdx
    ae7d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ae81:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    ae88:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ae8c:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    ae90:	4d 85 f6             	test   %r14,%r14
    ae93:	74 38                	je     aecd <fwp_hof0.constprop.0+0x5dd>
    ae95:	0f b6 0a             	movzbl (%rdx),%ecx
    ae98:	80 f9 02             	cmp    $0x2,%cl
    ae9b:	0f 84 c9 05 00 00    	je     b46a <fwp_hof0.constprop.0+0xb7a>
    aea1:	80 f9 01             	cmp    $0x1,%cl
    aea4:	75 27                	jne    aecd <fwp_hof0.constprop.0+0x5dd>
    aea6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aea9:	0f b7 c0             	movzwl %ax,%eax
    aeac:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aeaf:	48 0f af c1          	imul   %rcx,%rax
    aeb3:	48 c1 e8 20          	shr    $0x20,%rax
    aeb7:	48 39 d0             	cmp    %rdx,%rax
    aeba:	73 11                	jae    aecd <fwp_hof0.constprop.0+0x5dd>
    aebc:	49 01 c6             	add    %rax,%r14
    aebf:	41 80 3e ff          	cmpb   $0xff,(%r14)
    aec3:	0f 84 67 06 00 00    	je     b530 <fwp_hof0.constprop.0+0xc40>
    aec9:	41 c6 06 01          	movb   $0x1,(%r14)
    aecd:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    aed1:	e8 8a bc ff ff       	call   6b60 <fwp_drop0>
    aed6:	48 8b 13             	mov    (%rbx),%rdx
    aed9:	be 01 00 00 00       	mov    $0x1,%esi
    aede:	4c 89 e7             	mov    %r12,%rdi
    aee1:	48 8b 0d 78 a5 01 00 	mov    0x1a578(%rip),%rcx        # 25460 <fwp_prog_out>
    aee8:	e8 93 87 ff ff       	call   3680 <fwrite@plt>
    aeed:	48 8b 35 6c a5 01 00 	mov    0x1a56c(%rip),%rsi        # 25460 <fwp_prog_out>
    aef4:	bf 0a 00 00 00       	mov    $0xa,%edi
    aef9:	e8 e2 85 ff ff       	call   34e0 <fputc@plt>
    aefe:	48 8d 35 fb 88 01 00 	lea    0x188fb(%rip),%rsi        # 23800 <fwp_heap>
    af05:	48 89 d8             	mov    %rbx,%rax
    af08:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    af0f:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    af16:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    af1a:	48 c1 e2 10          	shl    $0x10,%rdx
    af1e:	48 39 d0             	cmp    %rdx,%rax
    af21:	73 69                	jae    af8c <fwp_hof0.constprop.0+0x69c>
    af23:	48 89 c2             	mov    %rax,%rdx
    af26:	48 c1 ea 10          	shr    $0x10,%rdx
    af2a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    af2e:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    af35:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    af39:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    af3d:	4d 85 e4             	test   %r12,%r12
    af40:	74 4a                	je     af8c <fwp_hof0.constprop.0+0x69c>
    af42:	0f b6 0a             	movzbl (%rdx),%ecx
    af45:	80 f9 02             	cmp    $0x2,%cl
    af48:	0f 84 2a 05 00 00    	je     b478 <fwp_hof0.constprop.0+0xb88>
    af4e:	80 f9 01             	cmp    $0x1,%cl
    af51:	75 39                	jne    af8c <fwp_hof0.constprop.0+0x69c>
    af53:	8b 4a 18             	mov    0x18(%rdx),%ecx
    af56:	0f b7 c0             	movzwl %ax,%eax
    af59:	8b 52 1c             	mov    0x1c(%rdx),%edx
    af5c:	48 0f af c1          	imul   %rcx,%rax
    af60:	48 c1 e8 20          	shr    $0x20,%rax
    af64:	48 39 d0             	cmp    %rdx,%rax
    af67:	73 23                	jae    af8c <fwp_hof0.constprop.0+0x69c>
    af69:	49 01 c4             	add    %rax,%r12
    af6c:	41 0f b6 04 24       	movzbl (%r12),%eax
    af71:	84 c0                	test   %al,%al
    af73:	74 17                	je     af8c <fwp_hof0.constprop.0+0x69c>
    af75:	3c 01                	cmp    $0x1,%al
    af77:	0f 84 d3 04 00 00    	je     b450 <fwp_hof0.constprop.0+0xb60>
    af7d:	3c ff                	cmp    $0xff,%al
    af7f:	0f 84 01 05 00 00    	je     b486 <fwp_hof0.constprop.0+0xb96>
    af85:	83 e8 01             	sub    $0x1,%eax
    af88:	41 88 04 24          	mov    %al,(%r12)
    af8c:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    af90:	4d 85 ff             	test   %r15,%r15
    af93:	0f 85 98 f9 ff ff    	jne    a931 <fwp_hof0.constprop.0+0x41>
    af99:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    af9d:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    afa4:	00 00 
    afa6:	0f 85 7e 05 00 00    	jne    b52a <fwp_hof0.constprop.0+0xc3a>
    afac:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    afb0:	31 c0                	xor    %eax,%eax
    afb2:	5b                   	pop    %rbx
    afb3:	41 5c                	pop    %r12
    afb5:	41 5d                	pop    %r13
    afb7:	41 5e                	pop    %r14
    afb9:	41 5f                	pop    %r15
    afbb:	5d                   	pop    %rbp
    afbc:	c3                   	ret
    afbd:	0f 1f 00             	nopl   (%rax)
    afc0:	48 8d 1d 39 88 01 00 	lea    0x18839(%rip),%rbx        # 23800 <fwp_heap>
    afc7:	41 8d 76 01          	lea    0x1(%r14),%esi
    afcb:	45 89 f7             	mov    %r14d,%r15d
    afce:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    afd4:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    afdb:	00 
    afdc:	85 c0                	test   %eax,%eax
    afde:	0f 84 a9 03 00 00    	je     b38d <fwp_hof0.constprop.0+0xa9d>
    afe4:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    afeb:	0f 87 9c 03 00 00    	ja     b38d <fwp_hof0.constprop.0+0xa9d>
    aff1:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    aff5:	48 c1 e8 04          	shr    $0x4,%rax
    aff9:	0f b6 94 03 a0 0f 00 	movzbl 0xfa0(%rbx,%rax,1),%edx
    b000:	00 
    b001:	8b 84 93 00 0f 00 00 	mov    0xf00(%rbx,%rdx,4),%eax
    b008:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    b00c:	48 8d 14 d3          	lea    (%rbx,%rdx,8),%rdx
    b010:	4c 8b 12             	mov    (%rdx),%r10
    b013:	4d 85 d2             	test   %r10,%r10
    b016:	0f 84 4f 03 00 00    	je     b36b <fwp_hof0.constprop.0+0xa7b>
    b01c:	4d 8b 1a             	mov    (%r10),%r11
    b01f:	49 f7 d3             	not    %r11
    b022:	4c 89 1a             	mov    %r11,(%rdx)
    b025:	48 39 c7             	cmp    %rax,%rdi
    b028:	73 50                	jae    b07a <fwp_hof0.constprop.0+0x78a>
    b02a:	48 89 fa             	mov    %rdi,%rdx
    b02d:	48 83 c7 08          	add    $0x8,%rdi
    b031:	49 c7 04 f2 00 00 00 	movq   $0x0,(%r10,%rsi,8)
    b038:	00 
    b039:	48 f7 d2             	not    %rdx
    b03c:	48 01 c2             	add    %rax,%rdx
    b03f:	48 c1 ea 03          	shr    $0x3,%rdx
    b043:	48 39 c7             	cmp    %rax,%rdi
    b046:	73 32                	jae    b07a <fwp_hof0.constprop.0+0x78a>
    b048:	83 e2 01             	and    $0x1,%edx
    b04b:	74 13                	je     b060 <fwp_hof0.constprop.0+0x770>
    b04d:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    b054:	00 
    b055:	48 83 c7 08          	add    $0x8,%rdi
    b059:	48 39 c7             	cmp    %rax,%rdi
    b05c:	73 1c                	jae    b07a <fwp_hof0.constprop.0+0x78a>
    b05e:	66 90                	xchg   %ax,%ax
    b060:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    b067:	00 
    b068:	49 c7 44 3a 08 00 00 	movq   $0x0,0x8(%r10,%rdi,1)
    b06f:	00 00 
    b071:	48 83 c7 10          	add    $0x10,%rdi
    b075:	48 39 c7             	cmp    %rax,%rdi
    b078:	72 e6                	jb     b060 <fwp_hof0.constprop.0+0x770>
    b07a:	48 8d 35 7f 87 01 00 	lea    0x1877f(%rip),%rsi        # 23800 <fwp_heap>
    b081:	48 89 c2             	mov    %rax,%rdx
    b084:	48 03 96 20 14 00 00 	add    0x1420(%rsi),%rdx
    b08b:	0f 82 6a 04 00 00    	jb     b4fb <fwp_hof0.constprop.0+0xc0b>
    b091:	48 89 96 20 14 00 00 	mov    %rdx,0x1420(%rsi)
    b098:	48 39 96 28 14 00 00 	cmp    %rdx,0x1428(%rsi)
    b09f:	73 07                	jae    b0a8 <fwp_hof0.constprop.0+0x7b8>
    b0a1:	48 89 15 80 9b 01 00 	mov    %rdx,0x19b80(%rip)        # 24c28 <fwp_heap+0x1428>
    b0a8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b0ac:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    b0b1:	f2 0f 58 05 7f 9b 01 	addsd  0x19b7f(%rip),%xmm0        # 24c38 <fwp_heap+0x1438>
    b0b8:	00 
    b0b9:	f2 0f 11 05 77 9b 01 	movsd  %xmm0,0x19b77(%rip)        # 24c38 <fwp_heap+0x1438>
    b0c0:	00 
    b0c1:	66 41 0f 6e 01       	movd   (%r9),%xmm0
    b0c6:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    b0cb:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    b0cf:	66 41 0f d6 02       	movq   %xmm0,(%r10)
    b0d4:	85 c9                	test   %ecx,%ecx
    b0d6:	74 37                	je     b10f <fwp_hof0.constprop.0+0x81f>
    b0d8:	89 ca                	mov    %ecx,%edx
    b0da:	49 8d 71 08          	lea    0x8(%r9),%rsi
    b0de:	49 8d 7a 08          	lea    0x8(%r10),%rdi
    b0e2:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b0e5:	48 c1 e2 03          	shl    $0x3,%rdx
    b0e9:	4c 89 85 68 ff ff ff 	mov    %r8,-0x98(%rbp)
    b0f0:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
    b0f4:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b0f8:	e8 13 85 ff ff       	call   3610 <memmove@plt>
    b0fd:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b101:	4c 8b 4d 98          	mov    -0x68(%rbp),%r9
    b105:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b108:	4c 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%r8
    b10f:	45 85 ed             	test   %r13d,%r13d
    b112:	74 23                	je     b137 <fwp_hof0.constprop.0+0x847>
    b114:	45 89 ed             	mov    %r13d,%r13d
    b117:	4b 8d 34 ec          	lea    (%r12,%r13,8),%rsi
    b11b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b120:	49 8b 14 24          	mov    (%r12),%rdx
    b124:	89 c8                	mov    %ecx,%eax
    b126:	49 83 c4 08          	add    $0x8,%r12
    b12a:	83 c1 01             	add    $0x1,%ecx
    b12d:	49 89 54 c2 08       	mov    %rdx,0x8(%r10,%rax,8)
    b132:	4c 39 e6             	cmp    %r12,%rsi
    b135:	75 e9                	jne    b120 <fwp_hof0.constprop.0+0x830>
    b137:	48 8d 35 c2 86 01 00 	lea    0x186c2(%rip),%rsi        # 23800 <fwp_heap>
    b13e:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b142:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b149:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b150:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    b154:	48 c1 e2 10          	shl    $0x10,%rdx
    b158:	48 39 d0             	cmp    %rdx,%rax
    b15b:	73 54                	jae    b1b1 <fwp_hof0.constprop.0+0x8c1>
    b15d:	48 89 c2             	mov    %rax,%rdx
    b160:	48 c1 ea 10          	shr    $0x10,%rdx
    b164:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b168:	48 8b 15 89 9a 01 00 	mov    0x19a89(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    b16f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b173:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    b177:	48 85 c9             	test   %rcx,%rcx
    b17a:	74 35                	je     b1b1 <fwp_hof0.constprop.0+0x8c1>
    b17c:	0f b6 32             	movzbl (%rdx),%esi
    b17f:	40 80 fe 02          	cmp    $0x2,%sil
    b183:	0f 84 52 02 00 00    	je     b3db <fwp_hof0.constprop.0+0xaeb>
    b189:	40 80 fe 01          	cmp    $0x1,%sil
    b18d:	75 22                	jne    b1b1 <fwp_hof0.constprop.0+0x8c1>
    b18f:	8b 72 18             	mov    0x18(%rdx),%esi
    b192:	0f b7 c0             	movzwl %ax,%eax
    b195:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b198:	48 0f af c6          	imul   %rsi,%rax
    b19c:	48 c1 e8 20          	shr    $0x20,%rax
    b1a0:	48 39 d0             	cmp    %rdx,%rax
    b1a3:	73 0c                	jae    b1b1 <fwp_hof0.constprop.0+0x8c1>
    b1a5:	48 01 c1             	add    %rax,%rcx
    b1a8:	80 39 01             	cmpb   $0x1,(%rcx)
    b1ab:	0f 84 9f 01 00 00    	je     b350 <fwp_hof0.constprop.0+0xa60>
    b1b1:	49 8b 40 18          	mov    0x18(%r8),%rax
    b1b5:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b1b9:	be 01 00 00 00       	mov    $0x1,%esi
    b1be:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b1c2:	ff 50 08             	call   *0x8(%rax)
    b1c5:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b1c9:	48 8d 35 30 86 01 00 	lea    0x18630(%rip),%rsi        # 23800 <fwp_heap>
    b1d0:	4c 89 d0             	mov    %r10,%rax
    b1d3:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b1da:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b1e1:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    b1e5:	48 c1 e2 10          	shl    $0x10,%rdx
    b1e9:	48 39 d0             	cmp    %rdx,%rax
    b1ec:	73 59                	jae    b247 <fwp_hof0.constprop.0+0x957>
    b1ee:	48 89 c2             	mov    %rax,%rdx
    b1f1:	48 c1 ea 10          	shr    $0x10,%rdx
    b1f5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b1f9:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b200:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b204:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b208:	4d 85 e4             	test   %r12,%r12
    b20b:	74 3a                	je     b247 <fwp_hof0.constprop.0+0x957>
    b20d:	0f b6 0a             	movzbl (%rdx),%ecx
    b210:	80 f9 02             	cmp    $0x2,%cl
    b213:	0f 84 99 01 00 00    	je     b3b2 <fwp_hof0.constprop.0+0xac2>
    b219:	80 f9 01             	cmp    $0x1,%cl
    b21c:	75 29                	jne    b247 <fwp_hof0.constprop.0+0x957>
    b21e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b221:	0f b7 c0             	movzwl %ax,%eax
    b224:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b227:	48 0f af c1          	imul   %rcx,%rax
    b22b:	48 c1 e8 20          	shr    $0x20,%rax
    b22f:	48 39 d0             	cmp    %rdx,%rax
    b232:	73 13                	jae    b247 <fwp_hof0.constprop.0+0x957>
    b234:	49 01 c4             	add    %rax,%r12
    b237:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b23c:	0f 84 84 01 00 00    	je     b3c6 <fwp_hof0.constprop.0+0xad6>
    b242:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b247:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b24b:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b24f:	e8 fc bb ff ff       	call   6e50 <fwp_closure_drop>
    b254:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b258:	4c 89 55 a8          	mov    %r10,-0x58(%rbp)
    b25c:	e9 c2 fa ff ff       	jmp    ad23 <fwp_hof0.constprop.0+0x433>
    b261:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b268:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b26c:	e9 b2 fa ff ff       	jmp    ad23 <fwp_hof0.constprop.0+0x433>
    b271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b278:	41 8b 34 24          	mov    (%r12),%esi
    b27c:	8b 05 9a 7d 00 00    	mov    0x7d9a(%rip),%eax        # 1301c <fc12+0x4>
    b282:	89 f7                	mov    %esi,%edi
    b284:	29 c7                	sub    %eax,%edi
    b286:	83 ff 01             	cmp    $0x1,%edi
    b289:	0f 85 7e f7 ff ff    	jne    aa0d <fwp_hof0.constprop.0+0x11d>
    b28f:	48 89 e3             	mov    %rsp,%rbx
    b292:	85 c0                	test   %eax,%eax
    b294:	0f 84 60 01 00 00    	je     b3fa <fwp_hof0.constprop.0+0xb0a>
    b29a:	89 f1                	mov    %esi,%ecx
    b29c:	ba 08 00 00 00       	mov    $0x8,%edx
    b2a1:	48 c1 e1 03          	shl    $0x3,%rcx
    b2a5:	85 f6                	test   %esi,%esi
    b2a7:	48 89 e6             	mov    %rsp,%rsi
    b2aa:	48 0f 45 d1          	cmovne %rcx,%rdx
    b2ae:	49 89 d7             	mov    %rdx,%r15
    b2b1:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    b2b5:	48 c1 ea 04          	shr    $0x4,%rdx
    b2b9:	48 c1 e2 04          	shl    $0x4,%rdx
    b2bd:	48 89 d7             	mov    %rdx,%rdi
    b2c0:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    b2c7:	48 29 fe             	sub    %rdi,%rsi
    b2ca:	48 39 f4             	cmp    %rsi,%rsp
    b2cd:	74 15                	je     b2e4 <fwp_hof0.constprop.0+0x9f4>
    b2cf:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    b2d6:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    b2dd:	00 00 
    b2df:	48 39 f4             	cmp    %rsi,%rsp
    b2e2:	75 eb                	jne    b2cf <fwp_hof0.constprop.0+0x9df>
    b2e4:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    b2ea:	48 29 d4             	sub    %rdx,%rsp
    b2ed:	48 85 d2             	test   %rdx,%rdx
    b2f0:	74 06                	je     b2f8 <fwp_hof0.constprop.0+0xa08>
    b2f2:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    b2f8:	4c 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%r14
    b2ff:	00 
    b300:	4c 89 f9             	mov    %r15,%rcx
    b303:	48 8d 35 16 7d 00 00 	lea    0x7d16(%rip),%rsi        # 13020 <descent_active_phase>
    b30a:	48 89 e7             	mov    %rsp,%rdi
    b30d:	4c 89 f2             	mov    %r14,%rdx
    b310:	e8 5b 82 ff ff       	call   3570 <__memcpy_chk@plt>
    b315:	4d 39 f7             	cmp    %r14,%r15
    b318:	4c 89 f9             	mov    %r15,%rcx
    b31b:	4a 8d 3c 34          	lea    (%rsp,%r14,1),%rdi
    b31f:	49 0f 42 ce          	cmovb  %r14,%rcx
    b323:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
    b32a:	ba 08 00 00 00       	mov    $0x8,%edx
    b32f:	4c 29 f1             	sub    %r14,%rcx
    b332:	e8 39 82 ff ff       	call   3570 <__memcpy_chk@plt>
    b337:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    b33c:	48 89 e7             	mov    %rsp,%rdi
    b33f:	ff 10                	call   *(%rax)
    b341:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b345:	e9 bd 00 00 00       	jmp    b407 <fwp_hof0.constprop.0+0xb17>
    b34a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b350:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    b357:	00 
    b358:	e9 6c fe ff ff       	jmp    b1c9 <fwp_hof0.constprop.0+0x8d9>
    b35d:	66 85 c0             	test   %ax,%ax
    b360:	0f 85 32 f7 ff ff    	jne    aa98 <fwp_hof0.constprop.0+0x1a8>
    b366:	e9 19 f7 ff ff       	jmp    aa84 <fwp_hof0.constprop.0+0x194>
    b36b:	4c 8b 52 08          	mov    0x8(%rdx),%r10
    b36f:	4d 85 d2             	test   %r10,%r10
    b372:	74 19                	je     b38d <fwp_hof0.constprop.0+0xa9d>
    b374:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
    b378:	4d 29 d3             	sub    %r10,%r11
    b37b:	49 39 c3             	cmp    %rax,%r11
    b37e:	72 0d                	jb     b38d <fwp_hof0.constprop.0+0xa9d>
    b380:	4d 8d 1c 02          	lea    (%r10,%rax,1),%r11
    b384:	4c 89 5a 08          	mov    %r11,0x8(%rdx)
    b388:	e9 98 fc ff ff       	jmp    b025 <fwp_hof0.constprop.0+0x735>
    b38d:	31 f6                	xor    %esi,%esi
    b38f:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b392:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    b396:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    b39a:	e8 51 a9 ff ff       	call   5cf0 <fwp_heap_alloc>
    b39f:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b3a2:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    b3a6:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    b3aa:	49 89 c2             	mov    %rax,%r10
    b3ad:	e9 0f fd ff ff       	jmp    b0c1 <fwp_hof0.constprop.0+0x7d1>
    b3b2:	66 85 c0             	test   %ax,%ax
    b3b5:	0f 85 8c fe ff ff    	jne    b247 <fwp_hof0.constprop.0+0x957>
    b3bb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b3c0:	0f 85 7c fe ff ff    	jne    b242 <fwp_hof0.constprop.0+0x952>
    b3c6:	4c 89 e7             	mov    %r12,%rdi
    b3c9:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b3cd:	e8 de a1 ff ff       	call   55b0 <fwp_rc_forget_slot>
    b3d2:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b3d6:	e9 67 fe ff ff       	jmp    b242 <fwp_hof0.constprop.0+0x952>
    b3db:	66 85 c0             	test   %ax,%ax
    b3de:	0f 85 cd fd ff ff    	jne    b1b1 <fwp_hof0.constprop.0+0x8c1>
    b3e4:	e9 bf fd ff ff       	jmp    b1a8 <fwp_hof0.constprop.0+0x8b8>
    b3e9:	e8 a2 a0 ff ff       	call   5490 <fwp_rc_wide_dup>
    b3ee:	48 8b 15 63 a0 01 00 	mov    0x1a063(%rip),%rdx        # 25458 <fwp_fns>
    b3f5:	e9 9e f6 ff ff       	jmp    aa98 <fwp_hof0.constprop.0+0x1a8>
    b3fa:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    b401:	ff 11                	call   *(%rcx)
    b403:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b407:	48 89 dc             	mov    %rbx,%rsp
    b40a:	e9 a7 f9 ff ff       	jmp    adb6 <fwp_hof0.constprop.0+0x4c6>
    b40f:	48 89 c7             	mov    %rax,%rdi
    b412:	e8 09 b3 ff ff       	call   6720 <fwp_rc_share>
    b417:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b41b:	e8 00 b3 ff ff       	call   6720 <fwp_rc_share>
    b420:	48 8d 05 f1 7b 00 00 	lea    0x7bf1(%rip),%rax        # 13018 <fc12>
    b427:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    b42e:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b432:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    b439:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b43d:	e9 60 f9 ff ff       	jmp    ada2 <fwp_hof0.constprop.0+0x4b2>
    b442:	66 85 c0             	test   %ax,%ax
    b445:	0f 85 6c f5 ff ff    	jne    a9b7 <fwp_hof0.constprop.0+0xc7>
    b44b:	e9 53 f5 ff ff       	jmp    a9a3 <fwp_hof0.constprop.0+0xb3>
    b450:	48 89 df             	mov    %rbx,%rdi
    b453:	e8 f8 b3 ff ff       	call   6850 <fwp_rc_free_arr>
    b458:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    b45c:	4d 85 ff             	test   %r15,%r15
    b45f:	0f 85 cc f4 ff ff    	jne    a931 <fwp_hof0.constprop.0+0x41>
    b465:	e9 2f fb ff ff       	jmp    af99 <fwp_hof0.constprop.0+0x6a9>
    b46a:	66 85 c0             	test   %ax,%ax
    b46d:	0f 85 5a fa ff ff    	jne    aecd <fwp_hof0.constprop.0+0x5dd>
    b473:	e9 47 fa ff ff       	jmp    aebf <fwp_hof0.constprop.0+0x5cf>
    b478:	66 85 c0             	test   %ax,%ax
    b47b:	0f 85 0b fb ff ff    	jne    af8c <fwp_hof0.constprop.0+0x69c>
    b481:	e9 e6 fa ff ff       	jmp    af6c <fwp_hof0.constprop.0+0x67c>
    b486:	4c 89 e0             	mov    %r12,%rax
    b489:	48 8d 35 70 83 01 00 	lea    0x18370(%rip),%rsi        # 23800 <fwp_heap>
    b490:	48 c1 e8 11          	shr    $0x11,%rax
    b494:	4c 31 e0             	xor    %r12,%rax
    b497:	48 89 c2             	mov    %rax,%rdx
    b49a:	48 c1 ea 09          	shr    $0x9,%rdx
    b49e:	48 31 d0             	xor    %rdx,%rax
    b4a1:	0f b6 c0             	movzbl %al,%eax
    b4a4:	48 8b 94 c6 48 14 00 	mov    0x1448(%rsi,%rax,8),%rdx
    b4ab:	00 
    b4ac:	48 85 d2             	test   %rdx,%rdx
    b4af:	75 18                	jne    b4c9 <fwp_hof0.constprop.0+0xbd9>
    b4b1:	eb 4d                	jmp    b500 <fwp_hof0.constprop.0+0xc10>
    b4b3:	66 90                	xchg   %ax,%ax
    b4b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b4bc:	00 00 00 00 
    b4c0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b4c4:	48 85 d2             	test   %rdx,%rdx
    b4c7:	74 37                	je     b500 <fwp_hof0.constprop.0+0xc10>
    b4c9:	48 89 d0             	mov    %rdx,%rax
    b4cc:	4c 39 22             	cmp    %r12,(%rdx)
    b4cf:	75 ef                	jne    b4c0 <fwp_hof0.constprop.0+0xbd0>
    b4d1:	48 8b 42 08          	mov    0x8(%rdx),%rax
    b4d5:	48 83 e8 01          	sub    $0x1,%rax
    b4d9:	48 89 42 08          	mov    %rax,0x8(%rdx)
    b4dd:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    b4e3:	0f 85 a3 fa ff ff    	jne    af8c <fwp_hof0.constprop.0+0x69c>
    b4e9:	4c 89 e7             	mov    %r12,%rdi
    b4ec:	e8 bf a0 ff ff       	call   55b0 <fwp_rc_forget_slot>
    b4f1:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b4f6:	e9 91 fa ff ff       	jmp    af8c <fwp_hof0.constprop.0+0x69c>
    b4fb:	e8 b0 87 ff ff       	call   3cb0 <fwp_heap_oom>
    b500:	48 8d 3d 81 43 00 00 	lea    0x4381(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    b507:	e8 e4 8e ff ff       	call   43f0 <fwp_trap>
    b50c:	48 8d 3d 33 3d 00 00 	lea    0x3d33(%rip),%rdi        # f246 <_IO_stdin_used+0x246>
    b513:	e8 d8 8e ff ff       	call   43f0 <fwp_trap>
    b518:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b51f:	00 
    b520:	e8 6b 9f ff ff       	call   5490 <fwp_rc_wide_dup>
    b525:	e9 8d f4 ff ff       	jmp    a9b7 <fwp_hof0.constprop.0+0xc7>
    b52a:	e8 31 7f ff ff       	call   3460 <__stack_chk_fail@plt>
    b52f:	90                   	nop
    b530:	4c 89 f7             	mov    %r14,%rdi
    b533:	e8 78 a0 ff ff       	call   55b0 <fwp_rc_forget_slot>
    b538:	e9 8c f9 ff ff       	jmp    aec9 <fwp_hof0.constprop.0+0x5d9>
    b53d:	0f 1f 00             	nopl   (%rax)

000000000000b540 <f0>:
    b540:	41 56                	push   %r14
    b542:	4c 8d 35 b7 82 01 00 	lea    0x182b7(%rip),%r14        # 23800 <fwp_heap>
    b549:	41 55                	push   %r13
    b54b:	41 54                	push   %r12
    b54d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    b553:	55                   	push   %rbp
    b554:	53                   	push   %rbx
    b555:	31 db                	xor    %ebx,%ebx
    b557:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    b55e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b565:	00 00 
    b567:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    b56e:	00 
    b56f:	31 c0                	xor    %eax,%eax
    b571:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    b578:	00 
    b579:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    b580:	00 00 
    b582:	66 48 0f 6e c0       	movq   %rax,%xmm0
    b587:	48 8d 05 62 b7 ff ff 	lea    -0x489e(%rip),%rax        # 6cf0 <fwp_drop1>
    b58e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    b593:	48 8b 05 fe 9e 01 00 	mov    0x19efe(%rip),%rax        # 25498 <fwp_cleanups>
    b59a:	48 89 25 f7 9e 01 00 	mov    %rsp,0x19ef7(%rip)        # 25498 <fwp_cleanups>
    b5a1:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    b5a5:	48 89 04 24          	mov    %rax,(%rsp)
    b5a9:	48 8d 05 20 86 ff ff 	lea    -0x79e0(%rip),%rax        # 3bd0 <fwp_range_release>
    b5b0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b5b5:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    b5ba:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b5bf:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    b5c4:	eb 47                	jmp    b60d <f0+0xcd>
    b5c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b5cd:	00 00 00 
    b5d0:	80 f9 01             	cmp    $0x1,%cl
    b5d3:	75 29                	jne    b5fe <f0+0xbe>
    b5d5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b5d8:	0f b7 c0             	movzwl %ax,%eax
    b5db:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b5de:	48 0f af c1          	imul   %rcx,%rax
    b5e2:	48 c1 e8 20          	shr    $0x20,%rax
    b5e6:	48 39 d0             	cmp    %rdx,%rax
    b5e9:	73 13                	jae    b5fe <f0+0xbe>
    b5eb:	49 01 c5             	add    %rax,%r13
    b5ee:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b5f3:	0f 84 c7 27 00 00    	je     ddc0 <f0+0x2880>
    b5f9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b5fe:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b603:	49 83 ec 01          	sub    $0x1,%r12
    b607:	0f 82 83 00 00 00    	jb     b690 <f0+0x150>
    b60d:	48 89 ee             	mov    %rbp,%rsi
    b610:	bf 01 00 00 00       	mov    $0x1,%edi
    b615:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    b61c:	00 
    b61d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    b622:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    b629:	00 
    b62a:	e8 c1 af ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    b62f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b636:	48 89 c3             	mov    %rax,%rbx
    b639:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b640:	48 c1 e2 10          	shl    $0x10,%rdx
    b644:	48 39 d0             	cmp    %rdx,%rax
    b647:	73 b5                	jae    b5fe <f0+0xbe>
    b649:	48 89 c2             	mov    %rax,%rdx
    b64c:	48 c1 ea 10          	shr    $0x10,%rdx
    b650:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b654:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b65b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b65f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b663:	4d 85 ed             	test   %r13,%r13
    b666:	74 96                	je     b5fe <f0+0xbe>
    b668:	0f b6 0a             	movzbl (%rdx),%ecx
    b66b:	80 f9 02             	cmp    $0x2,%cl
    b66e:	0f 85 5c ff ff ff    	jne    b5d0 <f0+0x90>
    b674:	66 85 c0             	test   %ax,%ax
    b677:	0f 84 71 ff ff ff    	je     b5ee <f0+0xae>
    b67d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b682:	49 83 ec 01          	sub    $0x1,%r12
    b686:	73 85                	jae    b60d <f0+0xcd>
    b688:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b68f:	00 
    b690:	48 8b 04 24          	mov    (%rsp),%rax
    b694:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    b699:	bf 01 00 00 00       	mov    $0x1,%edi
    b69e:	66 0f 6f 05 7a 45 00 	movdqa 0x457a(%rip),%xmm0        # fc20 <msg.8+0xb0>
    b6a5:	00 
    b6a6:	48 89 05 eb 9d 01 00 	mov    %rax,0x19deb(%rip)        # 25498 <fwp_cleanups>
    b6ad:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b6b2:	e8 39 af ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    b6b7:	48 8b 15 1a 95 01 00 	mov    0x1951a(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    b6be:	49 89 c5             	mov    %rax,%r13
    b6c1:	48 2b 05 e8 94 01 00 	sub    0x194e8(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    b6c8:	48 c1 e2 10          	shl    $0x10,%rdx
    b6cc:	48 39 d0             	cmp    %rdx,%rax
    b6cf:	73 59                	jae    b72a <f0+0x1ea>
    b6d1:	48 89 c2             	mov    %rax,%rdx
    b6d4:	48 c1 ea 10          	shr    $0x10,%rdx
    b6d8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b6dc:	48 8b 15 15 95 01 00 	mov    0x19515(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    b6e3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b6e7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b6eb:	4d 85 e4             	test   %r12,%r12
    b6ee:	74 3a                	je     b72a <f0+0x1ea>
    b6f0:	0f b6 0a             	movzbl (%rdx),%ecx
    b6f3:	80 f9 02             	cmp    $0x2,%cl
    b6f6:	0f 84 74 27 00 00    	je     de70 <f0+0x2930>
    b6fc:	80 f9 01             	cmp    $0x1,%cl
    b6ff:	75 29                	jne    b72a <f0+0x1ea>
    b701:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b704:	0f b7 c0             	movzwl %ax,%eax
    b707:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b70a:	48 0f af c1          	imul   %rcx,%rax
    b70e:	48 c1 e8 20          	shr    $0x20,%rax
    b712:	48 39 d0             	cmp    %rdx,%rax
    b715:	73 13                	jae    b72a <f0+0x1ea>
    b717:	49 01 c4             	add    %rax,%r12
    b71a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b71f:	0f 84 26 29 00 00    	je     e04b <f0+0x2b0b>
    b725:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b72a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    b72f:	bf 01 00 00 00       	mov    $0x1,%edi
    b734:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    b739:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b740:	00 f0 3f 
    b743:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    b748:	e8 a3 ae ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    b74d:	48 8b 15 84 94 01 00 	mov    0x19484(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    b754:	49 89 c5             	mov    %rax,%r13
    b757:	48 2b 05 52 94 01 00 	sub    0x19452(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    b75e:	48 c1 e2 10          	shl    $0x10,%rdx
    b762:	48 39 d0             	cmp    %rdx,%rax
    b765:	73 59                	jae    b7c0 <f0+0x280>
    b767:	48 89 c2             	mov    %rax,%rdx
    b76a:	48 c1 ea 10          	shr    $0x10,%rdx
    b76e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b772:	48 8b 15 7f 94 01 00 	mov    0x1947f(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    b779:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b77d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b781:	4d 85 e4             	test   %r12,%r12
    b784:	74 3a                	je     b7c0 <f0+0x280>
    b786:	0f b6 0a             	movzbl (%rdx),%ecx
    b789:	80 f9 02             	cmp    $0x2,%cl
    b78c:	0f 84 ce 26 00 00    	je     de60 <f0+0x2920>
    b792:	80 f9 01             	cmp    $0x1,%cl
    b795:	75 29                	jne    b7c0 <f0+0x280>
    b797:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b79a:	0f b7 c0             	movzwl %ax,%eax
    b79d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b7a0:	48 0f af c1          	imul   %rcx,%rax
    b7a4:	48 c1 e8 20          	shr    $0x20,%rax
    b7a8:	48 39 d0             	cmp    %rdx,%rax
    b7ab:	73 13                	jae    b7c0 <f0+0x280>
    b7ad:	49 01 c4             	add    %rax,%r12
    b7b0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b7b5:	0f 84 9d 28 00 00    	je     e058 <f0+0x2b18>
    b7bb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b7c0:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b7c5:	bf 01 00 00 00       	mov    $0x1,%edi
    b7ca:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    b7cf:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b7d6:	33 f3 bf 
    b7d9:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b7de:	e8 0d ae ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    b7e3:	48 8b 15 ee 93 01 00 	mov    0x193ee(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    b7ea:	49 89 c5             	mov    %rax,%r13
    b7ed:	48 2b 05 bc 93 01 00 	sub    0x193bc(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    b7f4:	48 c1 e2 10          	shl    $0x10,%rdx
    b7f8:	48 39 d0             	cmp    %rdx,%rax
    b7fb:	73 59                	jae    b856 <f0+0x316>
    b7fd:	48 89 c2             	mov    %rax,%rdx
    b800:	48 c1 ea 10          	shr    $0x10,%rdx
    b804:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b808:	48 8b 15 e9 93 01 00 	mov    0x193e9(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    b80f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b813:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b817:	4d 85 e4             	test   %r12,%r12
    b81a:	74 3a                	je     b856 <f0+0x316>
    b81c:	0f b6 0a             	movzbl (%rdx),%ecx
    b81f:	80 f9 02             	cmp    $0x2,%cl
    b822:	0f 84 28 26 00 00    	je     de50 <f0+0x2910>
    b828:	80 f9 01             	cmp    $0x1,%cl
    b82b:	75 29                	jne    b856 <f0+0x316>
    b82d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b830:	0f b7 c0             	movzwl %ax,%eax
    b833:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b836:	48 0f af c1          	imul   %rcx,%rax
    b83a:	48 c1 e8 20          	shr    $0x20,%rax
    b83e:	48 39 d0             	cmp    %rdx,%rax
    b841:	73 13                	jae    b856 <f0+0x316>
    b843:	49 01 c4             	add    %rax,%r12
    b846:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b84b:	0f 84 14 28 00 00    	je     e065 <f0+0x2b25>
    b851:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b856:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b85b:	bf 01 00 00 00       	mov    $0x1,%edi
    b860:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    b865:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b86c:	00 f0 3f 
    b86f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b874:	e8 77 ad ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    b879:	48 8b 15 58 93 01 00 	mov    0x19358(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    b880:	49 89 c5             	mov    %rax,%r13
    b883:	48 2b 05 26 93 01 00 	sub    0x19326(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    b88a:	48 c1 e2 10          	shl    $0x10,%rdx
    b88e:	48 39 d0             	cmp    %rdx,%rax
    b891:	73 59                	jae    b8ec <f0+0x3ac>
    b893:	48 89 c2             	mov    %rax,%rdx
    b896:	48 c1 ea 10          	shr    $0x10,%rdx
    b89a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b89e:	48 8b 15 53 93 01 00 	mov    0x19353(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    b8a5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b8a9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b8ad:	4d 85 e4             	test   %r12,%r12
    b8b0:	74 3a                	je     b8ec <f0+0x3ac>
    b8b2:	0f b6 0a             	movzbl (%rdx),%ecx
    b8b5:	80 f9 02             	cmp    $0x2,%cl
    b8b8:	0f 84 f2 25 00 00    	je     deb0 <f0+0x2970>
    b8be:	80 f9 01             	cmp    $0x1,%cl
    b8c1:	75 29                	jne    b8ec <f0+0x3ac>
    b8c3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b8c6:	0f b7 c0             	movzwl %ax,%eax
    b8c9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b8cc:	48 0f af c1          	imul   %rcx,%rax
    b8d0:	48 c1 e8 20          	shr    $0x20,%rax
    b8d4:	48 39 d0             	cmp    %rdx,%rax
    b8d7:	73 13                	jae    b8ec <f0+0x3ac>
    b8d9:	49 01 c4             	add    %rax,%r12
    b8dc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b8e1:	0f 84 8b 27 00 00    	je     e072 <f0+0x2b32>
    b8e7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b8ec:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b8f3:	33 f3 bf 
    b8f6:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    b8fd:	00 
    b8fe:	bf 01 00 00 00       	mov    $0x1,%edi
    b903:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    b90a:	00 
    b90b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    b912:	00 
    b913:	e8 d8 ac ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    b918:	48 8b 15 b9 92 01 00 	mov    0x192b9(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    b91f:	49 89 c5             	mov    %rax,%r13
    b922:	48 2b 05 87 92 01 00 	sub    0x19287(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    b929:	48 c1 e2 10          	shl    $0x10,%rdx
    b92d:	48 39 d0             	cmp    %rdx,%rax
    b930:	73 59                	jae    b98b <f0+0x44b>
    b932:	48 89 c2             	mov    %rax,%rdx
    b935:	48 c1 ea 10          	shr    $0x10,%rdx
    b939:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b93d:	48 8b 15 b4 92 01 00 	mov    0x192b4(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    b944:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b948:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b94c:	4d 85 e4             	test   %r12,%r12
    b94f:	74 3a                	je     b98b <f0+0x44b>
    b951:	0f b6 0a             	movzbl (%rdx),%ecx
    b954:	80 f9 02             	cmp    $0x2,%cl
    b957:	0f 84 43 25 00 00    	je     dea0 <f0+0x2960>
    b95d:	80 f9 01             	cmp    $0x1,%cl
    b960:	75 29                	jne    b98b <f0+0x44b>
    b962:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b965:	0f b7 c0             	movzwl %ax,%eax
    b968:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b96b:	48 0f af c1          	imul   %rcx,%rax
    b96f:	48 c1 e8 20          	shr    $0x20,%rax
    b973:	48 39 d0             	cmp    %rdx,%rax
    b976:	73 13                	jae    b98b <f0+0x44b>
    b978:	49 01 c4             	add    %rax,%r12
    b97b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b980:	0f 84 f9 26 00 00    	je     e07f <f0+0x2b3f>
    b986:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b98b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    b992:	00 f0 3f 
    b995:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    b99c:	00 
    b99d:	bf 01 00 00 00       	mov    $0x1,%edi
    b9a2:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    b9a9:	00 
    b9aa:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    b9b1:	00 
    b9b2:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    b9b9:	33 f3 bf 
    b9bc:	e8 2f ac ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    b9c1:	48 89 c7             	mov    %rax,%rdi
    b9c4:	e8 d7 ad ff ff       	call   67a0 <fwp_rc_fresh>
    b9c9:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    b9d0:	00 
    b9d1:	bf 01 00 00 00       	mov    $0x1,%edi
    b9d6:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    b9dd:	00 
    b9de:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    b9e5:	00 
    b9e6:	e8 05 ac ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    b9eb:	48 89 c7             	mov    %rax,%rdi
    b9ee:	e8 ad ad ff ff       	call   67a0 <fwp_rc_fresh>
    b9f3:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    b9fa:	00 
    b9fb:	bf 01 00 00 00       	mov    $0x1,%edi
    ba00:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    ba07:	00 
    ba08:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    ba0f:	00 
    ba10:	e8 db ab ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    ba15:	48 89 c7             	mov    %rax,%rdi
    ba18:	e8 83 ad ff ff       	call   67a0 <fwp_rc_fresh>
    ba1d:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    ba24:	00 
    ba25:	bf 01 00 00 00       	mov    $0x1,%edi
    ba2a:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    ba31:	00 
    ba32:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    ba39:	00 
    ba3a:	e8 b1 ab ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    ba3f:	48 89 c7             	mov    %rax,%rdi
    ba42:	e8 59 ad ff ff       	call   67a0 <fwp_rc_fresh>
    ba47:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    ba4e:	00 
    ba4f:	bf 01 00 00 00       	mov    $0x1,%edi
    ba54:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    ba5b:	00 
    ba5c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    ba63:	00 
    ba64:	e8 87 ab ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    ba69:	48 89 c7             	mov    %rax,%rdi
    ba6c:	e8 2f ad ff ff       	call   67a0 <fwp_rc_fresh>
    ba71:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    ba78:	00 
    ba79:	bf 01 00 00 00       	mov    $0x1,%edi
    ba7e:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    ba85:	00 
    ba86:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    ba8d:	00 
    ba8e:	e8 5d ab ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    ba93:	48 89 c7             	mov    %rax,%rdi
    ba96:	e8 05 ad ff ff       	call   67a0 <fwp_rc_fresh>
    ba9b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    baa2:	00 
    baa3:	bf 01 00 00 00       	mov    $0x1,%edi
    baa8:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    baaf:	00 
    bab0:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    bab7:	00 
    bab8:	e8 33 ab ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    babd:	48 89 c7             	mov    %rax,%rdi
    bac0:	e8 db ac ff ff       	call   67a0 <fwp_rc_fresh>
    bac5:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    bacc:	00 
    bacd:	bf 01 00 00 00       	mov    $0x1,%edi
    bad2:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    bad9:	00 
    bada:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    bae1:	00 
    bae2:	e8 09 ab ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bae7:	48 89 c7             	mov    %rax,%rdi
    baea:	e8 b1 ac ff ff       	call   67a0 <fwp_rc_fresh>
    baef:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    baf6:	00 
    baf7:	bf 01 00 00 00       	mov    $0x1,%edi
    bafc:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    bb03:	00 
    bb04:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    bb0b:	00 
    bb0c:	e8 df aa ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bb11:	48 89 c7             	mov    %rax,%rdi
    bb14:	e8 87 ac ff ff       	call   67a0 <fwp_rc_fresh>
    bb19:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    bb20:	00 
    bb21:	bf 01 00 00 00       	mov    $0x1,%edi
    bb26:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    bb2d:	00 
    bb2e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    bb35:	00 
    bb36:	e8 b5 aa ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bb3b:	48 89 c7             	mov    %rax,%rdi
    bb3e:	e8 5d ac ff ff       	call   67a0 <fwp_rc_fresh>
    bb43:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    bb4a:	00 
    bb4b:	bf 01 00 00 00       	mov    $0x1,%edi
    bb50:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    bb57:	00 
    bb58:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    bb5f:	00 
    bb60:	e8 8b aa ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bb65:	48 89 c7             	mov    %rax,%rdi
    bb68:	e8 33 ac ff ff       	call   67a0 <fwp_rc_fresh>
    bb6d:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    bb74:	00 
    bb75:	bf 01 00 00 00       	mov    $0x1,%edi
    bb7a:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    bb81:	00 
    bb82:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    bb89:	00 
    bb8a:	e8 61 aa ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bb8f:	48 89 c7             	mov    %rax,%rdi
    bb92:	e8 09 ac ff ff       	call   67a0 <fwp_rc_fresh>
    bb97:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    bb9e:	00 
    bb9f:	bf 01 00 00 00       	mov    $0x1,%edi
    bba4:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    bbab:	00 
    bbac:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    bbb3:	00 
    bbb4:	e8 37 aa ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bbb9:	48 89 c7             	mov    %rax,%rdi
    bbbc:	e8 df ab ff ff       	call   67a0 <fwp_rc_fresh>
    bbc1:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    bbc8:	00 
    bbc9:	bf 01 00 00 00       	mov    $0x1,%edi
    bbce:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    bbd5:	00 
    bbd6:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    bbdd:	00 
    bbde:	e8 0d aa ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bbe3:	48 89 c7             	mov    %rax,%rdi
    bbe6:	e8 b5 ab ff ff       	call   67a0 <fwp_rc_fresh>
    bbeb:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    bbf2:	00 
    bbf3:	bf 01 00 00 00       	mov    $0x1,%edi
    bbf8:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    bbff:	00 
    bc00:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    bc07:	00 
    bc08:	e8 e3 a9 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bc0d:	48 89 c7             	mov    %rax,%rdi
    bc10:	e8 8b ab ff ff       	call   67a0 <fwp_rc_fresh>
    bc15:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    bc1c:	00 
    bc1d:	bf 01 00 00 00       	mov    $0x1,%edi
    bc22:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    bc29:	00 
    bc2a:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    bc31:	00 
    bc32:	e8 b9 a9 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bc37:	48 89 c7             	mov    %rax,%rdi
    bc3a:	e8 61 ab ff ff       	call   67a0 <fwp_rc_fresh>
    bc3f:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    bc46:	00 
    bc47:	bf 01 00 00 00       	mov    $0x1,%edi
    bc4c:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    bc53:	00 
    bc54:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    bc5b:	00 
    bc5c:	e8 8f a9 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bc61:	48 89 c7             	mov    %rax,%rdi
    bc64:	e8 37 ab ff ff       	call   67a0 <fwp_rc_fresh>
    bc69:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    bc70:	00 
    bc71:	bf 01 00 00 00       	mov    $0x1,%edi
    bc76:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    bc7d:	00 
    bc7e:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    bc85:	00 
    bc86:	e8 65 a9 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bc8b:	48 89 c7             	mov    %rax,%rdi
    bc8e:	e8 0d ab ff ff       	call   67a0 <fwp_rc_fresh>
    bc93:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    bc9a:	00 
    bc9b:	bf 01 00 00 00       	mov    $0x1,%edi
    bca0:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    bca7:	00 
    bca8:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    bcaf:	00 
    bcb0:	e8 3b a9 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bcb5:	48 89 c7             	mov    %rax,%rdi
    bcb8:	e8 e3 aa ff ff       	call   67a0 <fwp_rc_fresh>
    bcbd:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    bcc4:	00 
    bcc5:	bf 01 00 00 00       	mov    $0x1,%edi
    bcca:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    bcd1:	00 
    bcd2:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    bcd9:	00 
    bcda:	e8 11 a9 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bcdf:	48 89 c7             	mov    %rax,%rdi
    bce2:	e8 b9 aa ff ff       	call   67a0 <fwp_rc_fresh>
    bce7:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    bcee:	00 
    bcef:	bf 01 00 00 00       	mov    $0x1,%edi
    bcf4:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    bcfb:	00 
    bcfc:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    bd03:	00 
    bd04:	e8 e7 a8 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bd09:	48 89 c7             	mov    %rax,%rdi
    bd0c:	e8 8f aa ff ff       	call   67a0 <fwp_rc_fresh>
    bd11:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    bd18:	00 
    bd19:	bf 01 00 00 00       	mov    $0x1,%edi
    bd1e:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    bd25:	00 
    bd26:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    bd2d:	00 
    bd2e:	e8 bd a8 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bd33:	48 89 c7             	mov    %rax,%rdi
    bd36:	e8 65 aa ff ff       	call   67a0 <fwp_rc_fresh>
    bd3b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    bd42:	00 
    bd43:	bf 01 00 00 00       	mov    $0x1,%edi
    bd48:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    bd4f:	00 
    bd50:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    bd57:	00 
    bd58:	e8 93 a8 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bd5d:	48 89 c7             	mov    %rax,%rdi
    bd60:	e8 3b aa ff ff       	call   67a0 <fwp_rc_fresh>
    bd65:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    bd6c:	00 
    bd6d:	bf 01 00 00 00       	mov    $0x1,%edi
    bd72:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    bd79:	00 
    bd7a:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    bd81:	00 
    bd82:	e8 69 a8 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bd87:	48 89 c7             	mov    %rax,%rdi
    bd8a:	e8 11 aa ff ff       	call   67a0 <fwp_rc_fresh>
    bd8f:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    bd96:	00 
    bd97:	bf 01 00 00 00       	mov    $0x1,%edi
    bd9c:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    bda3:	00 
    bda4:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    bdab:	00 
    bdac:	e8 3f a8 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bdb1:	48 89 c7             	mov    %rax,%rdi
    bdb4:	e8 e7 a9 ff ff       	call   67a0 <fwp_rc_fresh>
    bdb9:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    bdc0:	00 
    bdc1:	bf 01 00 00 00       	mov    $0x1,%edi
    bdc6:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    bdcd:	00 
    bdce:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    bdd5:	00 
    bdd6:	e8 15 a8 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bddb:	48 89 c7             	mov    %rax,%rdi
    bdde:	e8 bd a9 ff ff       	call   67a0 <fwp_rc_fresh>
    bde3:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    bdea:	00 
    bdeb:	bf 01 00 00 00       	mov    $0x1,%edi
    bdf0:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    bdf7:	00 
    bdf8:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    bdff:	00 
    be00:	e8 eb a7 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    be05:	48 89 c7             	mov    %rax,%rdi
    be08:	e8 93 a9 ff ff       	call   67a0 <fwp_rc_fresh>
    be0d:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    be14:	00 
    be15:	bf 01 00 00 00       	mov    $0x1,%edi
    be1a:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    be21:	00 
    be22:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    be29:	00 
    be2a:	e8 c1 a7 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    be2f:	48 89 c7             	mov    %rax,%rdi
    be32:	e8 69 a9 ff ff       	call   67a0 <fwp_rc_fresh>
    be37:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    be3e:	00 
    be3f:	bf 01 00 00 00       	mov    $0x1,%edi
    be44:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    be4b:	00 
    be4c:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    be53:	00 
    be54:	e8 97 a7 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    be59:	48 89 c7             	mov    %rax,%rdi
    be5c:	e8 3f a9 ff ff       	call   67a0 <fwp_rc_fresh>
    be61:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    be68:	00 
    be69:	bf 01 00 00 00       	mov    $0x1,%edi
    be6e:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    be75:	00 
    be76:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    be7d:	00 
    be7e:	e8 6d a7 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    be83:	48 89 c7             	mov    %rax,%rdi
    be86:	e8 15 a9 ff ff       	call   67a0 <fwp_rc_fresh>
    be8b:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    be92:	00 
    be93:	bf 01 00 00 00       	mov    $0x1,%edi
    be98:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    be9f:	00 
    bea0:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    bea7:	00 
    bea8:	e8 43 a7 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bead:	48 89 c7             	mov    %rax,%rdi
    beb0:	e8 eb a8 ff ff       	call   67a0 <fwp_rc_fresh>
    beb5:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    bebc:	00 
    bebd:	bf 01 00 00 00       	mov    $0x1,%edi
    bec2:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    bec9:	00 
    beca:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    bed1:	00 
    bed2:	e8 19 a7 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bed7:	48 89 c7             	mov    %rax,%rdi
    beda:	e8 c1 a8 ff ff       	call   67a0 <fwp_rc_fresh>
    bedf:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    bee6:	00 
    bee7:	bf 01 00 00 00       	mov    $0x1,%edi
    beec:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    bef3:	00 
    bef4:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    befb:	00 
    befc:	e8 ef a6 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bf01:	48 89 c7             	mov    %rax,%rdi
    bf04:	e8 97 a8 ff ff       	call   67a0 <fwp_rc_fresh>
    bf09:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    bf10:	00 
    bf11:	bf 01 00 00 00       	mov    $0x1,%edi
    bf16:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    bf1d:	00 
    bf1e:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    bf25:	00 
    bf26:	e8 c5 a6 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bf2b:	48 89 c7             	mov    %rax,%rdi
    bf2e:	e8 6d a8 ff ff       	call   67a0 <fwp_rc_fresh>
    bf33:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    bf3a:	00 
    bf3b:	bf 01 00 00 00       	mov    $0x1,%edi
    bf40:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    bf47:	00 
    bf48:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    bf4f:	00 
    bf50:	e8 9b a6 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bf55:	48 89 c7             	mov    %rax,%rdi
    bf58:	e8 43 a8 ff ff       	call   67a0 <fwp_rc_fresh>
    bf5d:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    bf64:	00 
    bf65:	bf 01 00 00 00       	mov    $0x1,%edi
    bf6a:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    bf71:	00 
    bf72:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    bf79:	00 
    bf7a:	e8 71 a6 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bf7f:	48 89 c7             	mov    %rax,%rdi
    bf82:	e8 19 a8 ff ff       	call   67a0 <fwp_rc_fresh>
    bf87:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    bf8e:	00 
    bf8f:	bf 01 00 00 00       	mov    $0x1,%edi
    bf94:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    bf9b:	00 
    bf9c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    bfa3:	00 
    bfa4:	e8 47 a6 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bfa9:	48 89 c7             	mov    %rax,%rdi
    bfac:	e8 ef a7 ff ff       	call   67a0 <fwp_rc_fresh>
    bfb1:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    bfb8:	00 
    bfb9:	bf 01 00 00 00       	mov    $0x1,%edi
    bfbe:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    bfc5:	00 
    bfc6:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    bfcd:	00 
    bfce:	e8 1d a6 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bfd3:	48 89 c7             	mov    %rax,%rdi
    bfd6:	e8 c5 a7 ff ff       	call   67a0 <fwp_rc_fresh>
    bfdb:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    bfe2:	00 
    bfe3:	bf 01 00 00 00       	mov    $0x1,%edi
    bfe8:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    bfef:	00 
    bff0:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    bff7:	00 
    bff8:	e8 f3 a5 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    bffd:	48 89 c7             	mov    %rax,%rdi
    c000:	e8 9b a7 ff ff       	call   67a0 <fwp_rc_fresh>
    c005:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    c00c:	00 
    c00d:	bf 01 00 00 00       	mov    $0x1,%edi
    c012:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    c019:	00 
    c01a:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    c021:	00 
    c022:	e8 c9 a5 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c027:	48 89 c7             	mov    %rax,%rdi
    c02a:	e8 71 a7 ff ff       	call   67a0 <fwp_rc_fresh>
    c02f:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    c036:	00 
    c037:	bf 01 00 00 00       	mov    $0x1,%edi
    c03c:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    c043:	00 
    c044:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    c04b:	00 
    c04c:	e8 9f a5 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c051:	48 89 c7             	mov    %rax,%rdi
    c054:	e8 47 a7 ff ff       	call   67a0 <fwp_rc_fresh>
    c059:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    c060:	00 
    c061:	bf 01 00 00 00       	mov    $0x1,%edi
    c066:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    c06d:	00 
    c06e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    c075:	00 
    c076:	e8 75 a5 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c07b:	48 89 c7             	mov    %rax,%rdi
    c07e:	e8 1d a7 ff ff       	call   67a0 <fwp_rc_fresh>
    c083:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    c08a:	00 
    c08b:	bf 01 00 00 00       	mov    $0x1,%edi
    c090:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    c097:	00 
    c098:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    c09f:	00 
    c0a0:	e8 4b a5 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c0a5:	48 89 c7             	mov    %rax,%rdi
    c0a8:	e8 f3 a6 ff ff       	call   67a0 <fwp_rc_fresh>
    c0ad:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    c0b4:	00 
    c0b5:	bf 01 00 00 00       	mov    $0x1,%edi
    c0ba:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    c0c1:	00 
    c0c2:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    c0c9:	00 
    c0ca:	e8 21 a5 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c0cf:	48 89 c7             	mov    %rax,%rdi
    c0d2:	e8 c9 a6 ff ff       	call   67a0 <fwp_rc_fresh>
    c0d7:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    c0de:	00 
    c0df:	bf 01 00 00 00       	mov    $0x1,%edi
    c0e4:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    c0eb:	00 
    c0ec:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    c0f3:	00 
    c0f4:	e8 f7 a4 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c0f9:	48 89 c7             	mov    %rax,%rdi
    c0fc:	e8 9f a6 ff ff       	call   67a0 <fwp_rc_fresh>
    c101:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    c108:	00 
    c109:	bf 01 00 00 00       	mov    $0x1,%edi
    c10e:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    c115:	00 
    c116:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    c11d:	00 
    c11e:	e8 cd a4 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c123:	48 89 c7             	mov    %rax,%rdi
    c126:	e8 75 a6 ff ff       	call   67a0 <fwp_rc_fresh>
    c12b:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    c132:	00 
    c133:	bf 01 00 00 00       	mov    $0x1,%edi
    c138:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    c13f:	00 
    c140:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    c147:	00 
    c148:	e8 a3 a4 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c14d:	48 89 c7             	mov    %rax,%rdi
    c150:	e8 4b a6 ff ff       	call   67a0 <fwp_rc_fresh>
    c155:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    c15c:	00 
    c15d:	bf 01 00 00 00       	mov    $0x1,%edi
    c162:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    c169:	00 
    c16a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    c171:	00 
    c172:	e8 79 a4 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c177:	48 89 c7             	mov    %rax,%rdi
    c17a:	e8 21 a6 ff ff       	call   67a0 <fwp_rc_fresh>
    c17f:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    c186:	00 
    c187:	bf 01 00 00 00       	mov    $0x1,%edi
    c18c:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    c193:	00 
    c194:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    c19b:	00 
    c19c:	e8 4f a4 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c1a1:	48 89 c7             	mov    %rax,%rdi
    c1a4:	e8 f7 a5 ff ff       	call   67a0 <fwp_rc_fresh>
    c1a9:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    c1b0:	00 
    c1b1:	bf 01 00 00 00       	mov    $0x1,%edi
    c1b6:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    c1bd:	00 
    c1be:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    c1c5:	00 
    c1c6:	e8 25 a4 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c1cb:	48 89 c7             	mov    %rax,%rdi
    c1ce:	e8 cd a5 ff ff       	call   67a0 <fwp_rc_fresh>
    c1d3:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    c1da:	00 
    c1db:	bf 01 00 00 00       	mov    $0x1,%edi
    c1e0:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    c1e7:	00 
    c1e8:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    c1ef:	00 
    c1f0:	e8 fb a3 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c1f5:	48 89 c7             	mov    %rax,%rdi
    c1f8:	e8 a3 a5 ff ff       	call   67a0 <fwp_rc_fresh>
    c1fd:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    c204:	00 
    c205:	bf 01 00 00 00       	mov    $0x1,%edi
    c20a:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    c211:	00 
    c212:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    c219:	00 
    c21a:	e8 d1 a3 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c21f:	48 89 c7             	mov    %rax,%rdi
    c222:	e8 79 a5 ff ff       	call   67a0 <fwp_rc_fresh>
    c227:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    c22e:	00 
    c22f:	bf 01 00 00 00       	mov    $0x1,%edi
    c234:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    c23b:	00 
    c23c:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    c243:	00 
    c244:	e8 a7 a3 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c249:	48 89 c7             	mov    %rax,%rdi
    c24c:	e8 4f a5 ff ff       	call   67a0 <fwp_rc_fresh>
    c251:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    c258:	00 
    c259:	bf 01 00 00 00       	mov    $0x1,%edi
    c25e:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    c265:	00 
    c266:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    c26d:	00 
    c26e:	e8 7d a3 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c273:	48 89 c7             	mov    %rax,%rdi
    c276:	e8 25 a5 ff ff       	call   67a0 <fwp_rc_fresh>
    c27b:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    c282:	00 
    c283:	bf 01 00 00 00       	mov    $0x1,%edi
    c288:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    c28f:	00 
    c290:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    c297:	00 
    c298:	e8 53 a3 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c29d:	48 89 c7             	mov    %rax,%rdi
    c2a0:	e8 fb a4 ff ff       	call   67a0 <fwp_rc_fresh>
    c2a5:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    c2ac:	00 
    c2ad:	bf 01 00 00 00       	mov    $0x1,%edi
    c2b2:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    c2b9:	00 
    c2ba:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    c2c1:	00 
    c2c2:	e8 29 a3 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c2c7:	48 89 c7             	mov    %rax,%rdi
    c2ca:	e8 d1 a4 ff ff       	call   67a0 <fwp_rc_fresh>
    c2cf:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    c2d6:	00 
    c2d7:	bf 01 00 00 00       	mov    $0x1,%edi
    c2dc:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    c2e3:	00 
    c2e4:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    c2eb:	00 
    c2ec:	e8 ff a2 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c2f1:	48 89 c7             	mov    %rax,%rdi
    c2f4:	e8 a7 a4 ff ff       	call   67a0 <fwp_rc_fresh>
    c2f9:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    c300:	00 
    c301:	bf 01 00 00 00       	mov    $0x1,%edi
    c306:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    c30d:	00 
    c30e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    c315:	00 
    c316:	e8 d5 a2 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c31b:	48 89 c7             	mov    %rax,%rdi
    c31e:	e8 7d a4 ff ff       	call   67a0 <fwp_rc_fresh>
    c323:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    c32a:	00 
    c32b:	bf 01 00 00 00       	mov    $0x1,%edi
    c330:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    c337:	00 
    c338:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    c33f:	00 
    c340:	e8 ab a2 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c345:	48 89 c7             	mov    %rax,%rdi
    c348:	e8 53 a4 ff ff       	call   67a0 <fwp_rc_fresh>
    c34d:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    c354:	00 
    c355:	bf 01 00 00 00       	mov    $0x1,%edi
    c35a:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    c361:	00 
    c362:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    c369:	00 
    c36a:	e8 81 a2 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c36f:	48 89 c7             	mov    %rax,%rdi
    c372:	e8 29 a4 ff ff       	call   67a0 <fwp_rc_fresh>
    c377:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    c37e:	00 
    c37f:	bf 01 00 00 00       	mov    $0x1,%edi
    c384:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    c38b:	00 
    c38c:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    c393:	00 
    c394:	e8 57 a2 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c399:	48 89 c7             	mov    %rax,%rdi
    c39c:	e8 ff a3 ff ff       	call   67a0 <fwp_rc_fresh>
    c3a1:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    c3a8:	00 
    c3a9:	bf 01 00 00 00       	mov    $0x1,%edi
    c3ae:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    c3b5:	00 
    c3b6:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    c3bd:	00 
    c3be:	e8 2d a2 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c3c3:	48 89 c7             	mov    %rax,%rdi
    c3c6:	e8 d5 a3 ff ff       	call   67a0 <fwp_rc_fresh>
    c3cb:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    c3d2:	00 
    c3d3:	bf 01 00 00 00       	mov    $0x1,%edi
    c3d8:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    c3df:	00 
    c3e0:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    c3e7:	00 
    c3e8:	e8 03 a2 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c3ed:	48 89 c7             	mov    %rax,%rdi
    c3f0:	e8 ab a3 ff ff       	call   67a0 <fwp_rc_fresh>
    c3f5:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    c3fc:	00 
    c3fd:	bf 01 00 00 00       	mov    $0x1,%edi
    c402:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    c409:	00 
    c40a:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    c411:	00 
    c412:	e8 d9 a1 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c417:	48 89 c7             	mov    %rax,%rdi
    c41a:	e8 81 a3 ff ff       	call   67a0 <fwp_rc_fresh>
    c41f:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    c426:	00 
    c427:	bf 01 00 00 00       	mov    $0x1,%edi
    c42c:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    c433:	00 
    c434:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    c43b:	00 
    c43c:	e8 af a1 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c441:	48 89 c7             	mov    %rax,%rdi
    c444:	e8 57 a3 ff ff       	call   67a0 <fwp_rc_fresh>
    c449:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    c450:	00 
    c451:	bf 01 00 00 00       	mov    $0x1,%edi
    c456:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    c45d:	00 
    c45e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    c465:	00 
    c466:	e8 85 a1 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c46b:	48 89 c7             	mov    %rax,%rdi
    c46e:	e8 2d a3 ff ff       	call   67a0 <fwp_rc_fresh>
    c473:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    c47a:	00 
    c47b:	bf 01 00 00 00       	mov    $0x1,%edi
    c480:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    c487:	00 
    c488:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    c48f:	00 
    c490:	e8 5b a1 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c495:	48 89 c7             	mov    %rax,%rdi
    c498:	e8 03 a3 ff ff       	call   67a0 <fwp_rc_fresh>
    c49d:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    c4a4:	00 
    c4a5:	bf 01 00 00 00       	mov    $0x1,%edi
    c4aa:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    c4b1:	00 
    c4b2:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    c4b9:	00 
    c4ba:	e8 31 a1 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c4bf:	48 89 c7             	mov    %rax,%rdi
    c4c2:	e8 d9 a2 ff ff       	call   67a0 <fwp_rc_fresh>
    c4c7:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    c4ce:	00 
    c4cf:	bf 01 00 00 00       	mov    $0x1,%edi
    c4d4:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    c4db:	00 
    c4dc:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    c4e3:	00 
    c4e4:	e8 07 a1 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c4e9:	48 89 c7             	mov    %rax,%rdi
    c4ec:	e8 af a2 ff ff       	call   67a0 <fwp_rc_fresh>
    c4f1:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    c4f8:	00 
    c4f9:	bf 01 00 00 00       	mov    $0x1,%edi
    c4fe:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    c505:	00 
    c506:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    c50d:	00 
    c50e:	e8 dd a0 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c513:	48 89 c7             	mov    %rax,%rdi
    c516:	e8 85 a2 ff ff       	call   67a0 <fwp_rc_fresh>
    c51b:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    c522:	00 
    c523:	bf 01 00 00 00       	mov    $0x1,%edi
    c528:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    c52f:	00 
    c530:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    c537:	00 
    c538:	e8 b3 a0 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c53d:	48 89 c7             	mov    %rax,%rdi
    c540:	e8 5b a2 ff ff       	call   67a0 <fwp_rc_fresh>
    c545:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    c54c:	00 
    c54d:	bf 01 00 00 00       	mov    $0x1,%edi
    c552:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    c559:	00 
    c55a:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    c561:	00 
    c562:	e8 89 a0 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c567:	48 89 c7             	mov    %rax,%rdi
    c56a:	e8 31 a2 ff ff       	call   67a0 <fwp_rc_fresh>
    c56f:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    c576:	00 
    c577:	bf 01 00 00 00       	mov    $0x1,%edi
    c57c:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    c583:	00 
    c584:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    c58b:	00 
    c58c:	e8 5f a0 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c591:	48 89 c7             	mov    %rax,%rdi
    c594:	e8 07 a2 ff ff       	call   67a0 <fwp_rc_fresh>
    c599:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    c5a0:	00 
    c5a1:	bf 01 00 00 00       	mov    $0x1,%edi
    c5a6:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    c5ad:	00 
    c5ae:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    c5b5:	00 
    c5b6:	e8 35 a0 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c5bb:	48 89 c7             	mov    %rax,%rdi
    c5be:	e8 dd a1 ff ff       	call   67a0 <fwp_rc_fresh>
    c5c3:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    c5ca:	00 
    c5cb:	bf 01 00 00 00       	mov    $0x1,%edi
    c5d0:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    c5d7:	00 
    c5d8:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    c5df:	00 
    c5e0:	e8 0b a0 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c5e5:	48 89 c7             	mov    %rax,%rdi
    c5e8:	e8 b3 a1 ff ff       	call   67a0 <fwp_rc_fresh>
    c5ed:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    c5f4:	00 
    c5f5:	bf 01 00 00 00       	mov    $0x1,%edi
    c5fa:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    c601:	00 
    c602:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    c609:	00 
    c60a:	e8 e1 9f ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c60f:	48 89 c7             	mov    %rax,%rdi
    c612:	e8 89 a1 ff ff       	call   67a0 <fwp_rc_fresh>
    c617:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    c61e:	00 
    c61f:	bf 01 00 00 00       	mov    $0x1,%edi
    c624:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    c62b:	00 
    c62c:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    c633:	00 
    c634:	e8 b7 9f ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c639:	48 89 c7             	mov    %rax,%rdi
    c63c:	e8 5f a1 ff ff       	call   67a0 <fwp_rc_fresh>
    c641:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    c648:	00 
    c649:	bf 01 00 00 00       	mov    $0x1,%edi
    c64e:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    c655:	00 
    c656:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    c65d:	00 
    c65e:	e8 8d 9f ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c663:	48 89 c7             	mov    %rax,%rdi
    c666:	e8 35 a1 ff ff       	call   67a0 <fwp_rc_fresh>
    c66b:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    c672:	00 
    c673:	bf 01 00 00 00       	mov    $0x1,%edi
    c678:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    c67f:	00 
    c680:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    c687:	00 
    c688:	e8 63 9f ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c68d:	48 89 c7             	mov    %rax,%rdi
    c690:	e8 0b a1 ff ff       	call   67a0 <fwp_rc_fresh>
    c695:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    c69c:	00 
    c69d:	bf 01 00 00 00       	mov    $0x1,%edi
    c6a2:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    c6a9:	00 
    c6aa:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    c6b1:	00 
    c6b2:	e8 39 9f ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c6b7:	48 89 c7             	mov    %rax,%rdi
    c6ba:	e8 e1 a0 ff ff       	call   67a0 <fwp_rc_fresh>
    c6bf:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    c6c6:	00 
    c6c7:	bf 01 00 00 00       	mov    $0x1,%edi
    c6cc:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    c6d3:	00 
    c6d4:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    c6db:	00 
    c6dc:	e8 0f 9f ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c6e1:	48 89 c7             	mov    %rax,%rdi
    c6e4:	e8 b7 a0 ff ff       	call   67a0 <fwp_rc_fresh>
    c6e9:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    c6f0:	00 
    c6f1:	bf 01 00 00 00       	mov    $0x1,%edi
    c6f6:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    c6fd:	00 
    c6fe:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    c705:	00 
    c706:	e8 e5 9e ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c70b:	48 89 c7             	mov    %rax,%rdi
    c70e:	e8 8d a0 ff ff       	call   67a0 <fwp_rc_fresh>
    c713:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    c71a:	00 
    c71b:	bf 01 00 00 00       	mov    $0x1,%edi
    c720:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    c727:	00 
    c728:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    c72f:	00 
    c730:	e8 bb 9e ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c735:	48 89 c7             	mov    %rax,%rdi
    c738:	e8 63 a0 ff ff       	call   67a0 <fwp_rc_fresh>
    c73d:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    c744:	00 
    c745:	bf 01 00 00 00       	mov    $0x1,%edi
    c74a:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    c751:	00 
    c752:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    c759:	00 
    c75a:	e8 91 9e ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c75f:	48 89 c7             	mov    %rax,%rdi
    c762:	e8 39 a0 ff ff       	call   67a0 <fwp_rc_fresh>
    c767:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    c76e:	00 
    c76f:	bf 01 00 00 00       	mov    $0x1,%edi
    c774:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    c77b:	00 
    c77c:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    c783:	00 
    c784:	e8 67 9e ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c789:	48 89 c7             	mov    %rax,%rdi
    c78c:	e8 0f a0 ff ff       	call   67a0 <fwp_rc_fresh>
    c791:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    c798:	00 
    c799:	bf 01 00 00 00       	mov    $0x1,%edi
    c79e:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    c7a5:	00 
    c7a6:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    c7ad:	00 
    c7ae:	e8 3d 9e ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c7b3:	48 89 c7             	mov    %rax,%rdi
    c7b6:	e8 e5 9f ff ff       	call   67a0 <fwp_rc_fresh>
    c7bb:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    c7c2:	00 
    c7c3:	bf 01 00 00 00       	mov    $0x1,%edi
    c7c8:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    c7cf:	00 
    c7d0:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    c7d7:	00 
    c7d8:	e8 13 9e ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c7dd:	48 89 c7             	mov    %rax,%rdi
    c7e0:	e8 bb 9f ff ff       	call   67a0 <fwp_rc_fresh>
    c7e5:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    c7ec:	00 
    c7ed:	bf 01 00 00 00       	mov    $0x1,%edi
    c7f2:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    c7f9:	00 
    c7fa:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    c801:	00 
    c802:	e8 e9 9d ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c807:	48 89 c7             	mov    %rax,%rdi
    c80a:	e8 91 9f ff ff       	call   67a0 <fwp_rc_fresh>
    c80f:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    c816:	00 
    c817:	bf 01 00 00 00       	mov    $0x1,%edi
    c81c:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    c823:	00 
    c824:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    c82b:	00 
    c82c:	e8 bf 9d ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c831:	48 89 c7             	mov    %rax,%rdi
    c834:	e8 67 9f ff ff       	call   67a0 <fwp_rc_fresh>
    c839:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c840:	00 
    c841:	bf 01 00 00 00       	mov    $0x1,%edi
    c846:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c84d:	00 
    c84e:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c855:	00 
    c856:	e8 95 9d ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c85b:	48 89 c7             	mov    %rax,%rdi
    c85e:	e8 3d 9f ff ff       	call   67a0 <fwp_rc_fresh>
    c863:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    c86a:	00 
    c86b:	bf 01 00 00 00       	mov    $0x1,%edi
    c870:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    c877:	00 
    c878:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    c87f:	00 
    c880:	e8 6b 9d ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c885:	48 8b 15 4c 83 01 00 	mov    0x1834c(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    c88c:	49 89 c5             	mov    %rax,%r13
    c88f:	48 2b 05 1a 83 01 00 	sub    0x1831a(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    c896:	48 c1 e2 10          	shl    $0x10,%rdx
    c89a:	48 39 d0             	cmp    %rdx,%rax
    c89d:	73 59                	jae    c8f8 <f0+0x13b8>
    c89f:	48 89 c2             	mov    %rax,%rdx
    c8a2:	48 c1 ea 10          	shr    $0x10,%rdx
    c8a6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c8aa:	48 8b 15 47 83 01 00 	mov    0x18347(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    c8b1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c8b5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c8b9:	4d 85 e4             	test   %r12,%r12
    c8bc:	74 3a                	je     c8f8 <f0+0x13b8>
    c8be:	0f b6 0a             	movzbl (%rdx),%ecx
    c8c1:	80 f9 02             	cmp    $0x2,%cl
    c8c4:	0f 84 c6 15 00 00    	je     de90 <f0+0x2950>
    c8ca:	80 f9 01             	cmp    $0x1,%cl
    c8cd:	75 29                	jne    c8f8 <f0+0x13b8>
    c8cf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c8d2:	0f b7 c0             	movzwl %ax,%eax
    c8d5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c8d8:	48 0f af c1          	imul   %rcx,%rax
    c8dc:	48 c1 e8 20          	shr    $0x20,%rax
    c8e0:	48 39 d0             	cmp    %rdx,%rax
    c8e3:	73 13                	jae    c8f8 <f0+0x13b8>
    c8e5:	49 01 c4             	add    %rax,%r12
    c8e8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c8ed:	0f 84 99 17 00 00    	je     e08c <f0+0x2b4c>
    c8f3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c8f8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c8ff:	33 f3 bf 
    c902:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    c909:	00 
    c90a:	bf 01 00 00 00       	mov    $0x1,%edi
    c90f:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    c916:	00 
    c917:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    c91e:	00 
    c91f:	e8 cc 9c ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c924:	48 8b 15 ad 82 01 00 	mov    0x182ad(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    c92b:	49 89 c5             	mov    %rax,%r13
    c92e:	48 2b 05 7b 82 01 00 	sub    0x1827b(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    c935:	48 c1 e2 10          	shl    $0x10,%rdx
    c939:	48 39 d0             	cmp    %rdx,%rax
    c93c:	73 59                	jae    c997 <f0+0x1457>
    c93e:	48 89 c2             	mov    %rax,%rdx
    c941:	48 c1 ea 10          	shr    $0x10,%rdx
    c945:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c949:	48 8b 15 a8 82 01 00 	mov    0x182a8(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    c950:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c954:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c958:	4d 85 e4             	test   %r12,%r12
    c95b:	74 3a                	je     c997 <f0+0x1457>
    c95d:	0f b6 0a             	movzbl (%rdx),%ecx
    c960:	80 f9 02             	cmp    $0x2,%cl
    c963:	0f 84 17 15 00 00    	je     de80 <f0+0x2940>
    c969:	80 f9 01             	cmp    $0x1,%cl
    c96c:	75 29                	jne    c997 <f0+0x1457>
    c96e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c971:	0f b7 c0             	movzwl %ax,%eax
    c974:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c977:	48 0f af c1          	imul   %rcx,%rax
    c97b:	48 c1 e8 20          	shr    $0x20,%rax
    c97f:	48 39 d0             	cmp    %rdx,%rax
    c982:	73 13                	jae    c997 <f0+0x1457>
    c984:	49 01 c4             	add    %rax,%r12
    c987:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c98c:	0f 84 07 17 00 00    	je     e099 <f0+0x2b59>
    c992:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c997:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c99e:	00 f0 3f 
    c9a1:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    c9a8:	00 
    c9a9:	bf 01 00 00 00       	mov    $0x1,%edi
    c9ae:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    c9b5:	00 
    c9b6:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    c9bd:	00 
    c9be:	e8 2d 9c ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    c9c3:	48 8b 15 0e 82 01 00 	mov    0x1820e(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    c9ca:	49 89 c5             	mov    %rax,%r13
    c9cd:	48 2b 05 dc 81 01 00 	sub    0x181dc(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    c9d4:	48 c1 e2 10          	shl    $0x10,%rdx
    c9d8:	48 39 d0             	cmp    %rdx,%rax
    c9db:	73 59                	jae    ca36 <f0+0x14f6>
    c9dd:	48 89 c2             	mov    %rax,%rdx
    c9e0:	48 c1 ea 10          	shr    $0x10,%rdx
    c9e4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c9e8:	48 8b 15 09 82 01 00 	mov    0x18209(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    c9ef:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c9f3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c9f7:	4d 85 e4             	test   %r12,%r12
    c9fa:	74 3a                	je     ca36 <f0+0x14f6>
    c9fc:	0f b6 0a             	movzbl (%rdx),%ecx
    c9ff:	80 f9 02             	cmp    $0x2,%cl
    ca02:	0f 84 28 15 00 00    	je     df30 <f0+0x29f0>
    ca08:	80 f9 01             	cmp    $0x1,%cl
    ca0b:	75 29                	jne    ca36 <f0+0x14f6>
    ca0d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca10:	0f b7 c0             	movzwl %ax,%eax
    ca13:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca16:	48 0f af c1          	imul   %rcx,%rax
    ca1a:	48 c1 e8 20          	shr    $0x20,%rax
    ca1e:	48 39 d0             	cmp    %rdx,%rax
    ca21:	73 13                	jae    ca36 <f0+0x14f6>
    ca23:	49 01 c4             	add    %rax,%r12
    ca26:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca2b:	0f 84 75 16 00 00    	je     e0a6 <f0+0x2b66>
    ca31:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca36:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ca3d:	33 f3 bf 
    ca40:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    ca47:	00 
    ca48:	bf 01 00 00 00       	mov    $0x1,%edi
    ca4d:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    ca54:	00 
    ca55:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    ca5c:	00 
    ca5d:	e8 8e 9b ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    ca62:	48 8b 15 6f 81 01 00 	mov    0x1816f(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    ca69:	49 89 c5             	mov    %rax,%r13
    ca6c:	48 2b 05 3d 81 01 00 	sub    0x1813d(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    ca73:	48 c1 e2 10          	shl    $0x10,%rdx
    ca77:	48 39 d0             	cmp    %rdx,%rax
    ca7a:	73 59                	jae    cad5 <f0+0x1595>
    ca7c:	48 89 c2             	mov    %rax,%rdx
    ca7f:	48 c1 ea 10          	shr    $0x10,%rdx
    ca83:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca87:	48 8b 15 6a 81 01 00 	mov    0x1816a(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    ca8e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca92:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca96:	4d 85 e4             	test   %r12,%r12
    ca99:	74 3a                	je     cad5 <f0+0x1595>
    ca9b:	0f b6 0a             	movzbl (%rdx),%ecx
    ca9e:	80 f9 02             	cmp    $0x2,%cl
    caa1:	0f 84 79 14 00 00    	je     df20 <f0+0x29e0>
    caa7:	80 f9 01             	cmp    $0x1,%cl
    caaa:	75 29                	jne    cad5 <f0+0x1595>
    caac:	8b 4a 18             	mov    0x18(%rdx),%ecx
    caaf:	0f b7 c0             	movzwl %ax,%eax
    cab2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cab5:	48 0f af c1          	imul   %rcx,%rax
    cab9:	48 c1 e8 20          	shr    $0x20,%rax
    cabd:	48 39 d0             	cmp    %rdx,%rax
    cac0:	73 13                	jae    cad5 <f0+0x1595>
    cac2:	49 01 c4             	add    %rax,%r12
    cac5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    caca:	0f 84 e3 15 00 00    	je     e0b3 <f0+0x2b73>
    cad0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cad5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cadc:	00 f0 3f 
    cadf:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    cae6:	00 
    cae7:	bf 01 00 00 00       	mov    $0x1,%edi
    caec:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    caf3:	00 
    caf4:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    cafb:	00 
    cafc:	e8 ef 9a ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    cb01:	48 8b 15 d0 80 01 00 	mov    0x180d0(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    cb08:	49 89 c5             	mov    %rax,%r13
    cb0b:	48 2b 05 9e 80 01 00 	sub    0x1809e(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    cb12:	48 c1 e2 10          	shl    $0x10,%rdx
    cb16:	48 39 d0             	cmp    %rdx,%rax
    cb19:	73 59                	jae    cb74 <f0+0x1634>
    cb1b:	48 89 c2             	mov    %rax,%rdx
    cb1e:	48 c1 ea 10          	shr    $0x10,%rdx
    cb22:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb26:	48 8b 15 cb 80 01 00 	mov    0x180cb(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    cb2d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb31:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb35:	4d 85 e4             	test   %r12,%r12
    cb38:	74 3a                	je     cb74 <f0+0x1634>
    cb3a:	0f b6 0a             	movzbl (%rdx),%ecx
    cb3d:	80 f9 02             	cmp    $0x2,%cl
    cb40:	0f 84 ca 13 00 00    	je     df10 <f0+0x29d0>
    cb46:	80 f9 01             	cmp    $0x1,%cl
    cb49:	75 29                	jne    cb74 <f0+0x1634>
    cb4b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb4e:	0f b7 c0             	movzwl %ax,%eax
    cb51:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb54:	48 0f af c1          	imul   %rcx,%rax
    cb58:	48 c1 e8 20          	shr    $0x20,%rax
    cb5c:	48 39 d0             	cmp    %rdx,%rax
    cb5f:	73 13                	jae    cb74 <f0+0x1634>
    cb61:	49 01 c4             	add    %rax,%r12
    cb64:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb69:	0f 84 51 15 00 00    	je     e0c0 <f0+0x2b80>
    cb6f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb74:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cb7b:	33 f3 bf 
    cb7e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    cb85:	00 
    cb86:	bf 01 00 00 00       	mov    $0x1,%edi
    cb8b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    cb92:	00 
    cb93:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    cb9a:	00 
    cb9b:	e8 50 9a ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    cba0:	48 8b 15 31 80 01 00 	mov    0x18031(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    cba7:	49 89 c5             	mov    %rax,%r13
    cbaa:	48 2b 05 ff 7f 01 00 	sub    0x17fff(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    cbb1:	48 c1 e2 10          	shl    $0x10,%rdx
    cbb5:	48 39 d0             	cmp    %rdx,%rax
    cbb8:	73 59                	jae    cc13 <f0+0x16d3>
    cbba:	48 89 c2             	mov    %rax,%rdx
    cbbd:	48 c1 ea 10          	shr    $0x10,%rdx
    cbc1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cbc5:	48 8b 15 2c 80 01 00 	mov    0x1802c(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    cbcc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cbd0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cbd4:	4d 85 e4             	test   %r12,%r12
    cbd7:	74 3a                	je     cc13 <f0+0x16d3>
    cbd9:	0f b6 0a             	movzbl (%rdx),%ecx
    cbdc:	80 f9 02             	cmp    $0x2,%cl
    cbdf:	0f 84 1b 13 00 00    	je     df00 <f0+0x29c0>
    cbe5:	80 f9 01             	cmp    $0x1,%cl
    cbe8:	75 29                	jne    cc13 <f0+0x16d3>
    cbea:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cbed:	0f b7 c0             	movzwl %ax,%eax
    cbf0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cbf3:	48 0f af c1          	imul   %rcx,%rax
    cbf7:	48 c1 e8 20          	shr    $0x20,%rax
    cbfb:	48 39 d0             	cmp    %rdx,%rax
    cbfe:	73 13                	jae    cc13 <f0+0x16d3>
    cc00:	49 01 c4             	add    %rax,%r12
    cc03:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc08:	0f 84 bf 14 00 00    	je     e0cd <f0+0x2b8d>
    cc0e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc13:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc1a:	00 f0 3f 
    cc1d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    cc24:	00 
    cc25:	bf 01 00 00 00       	mov    $0x1,%edi
    cc2a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    cc31:	00 
    cc32:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    cc39:	00 
    cc3a:	e8 b1 99 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    cc3f:	48 8b 15 92 7f 01 00 	mov    0x17f92(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    cc46:	49 89 c5             	mov    %rax,%r13
    cc49:	48 2b 05 60 7f 01 00 	sub    0x17f60(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    cc50:	48 c1 e2 10          	shl    $0x10,%rdx
    cc54:	48 39 d0             	cmp    %rdx,%rax
    cc57:	73 59                	jae    ccb2 <f0+0x1772>
    cc59:	48 89 c2             	mov    %rax,%rdx
    cc5c:	48 c1 ea 10          	shr    $0x10,%rdx
    cc60:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc64:	48 8b 15 8d 7f 01 00 	mov    0x17f8d(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    cc6b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc6f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc73:	4d 85 e4             	test   %r12,%r12
    cc76:	74 3a                	je     ccb2 <f0+0x1772>
    cc78:	0f b6 0a             	movzbl (%rdx),%ecx
    cc7b:	80 f9 02             	cmp    $0x2,%cl
    cc7e:	0f 84 6c 12 00 00    	je     def0 <f0+0x29b0>
    cc84:	80 f9 01             	cmp    $0x1,%cl
    cc87:	75 29                	jne    ccb2 <f0+0x1772>
    cc89:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc8c:	0f b7 c0             	movzwl %ax,%eax
    cc8f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc92:	48 0f af c1          	imul   %rcx,%rax
    cc96:	48 c1 e8 20          	shr    $0x20,%rax
    cc9a:	48 39 d0             	cmp    %rdx,%rax
    cc9d:	73 13                	jae    ccb2 <f0+0x1772>
    cc9f:	49 01 c4             	add    %rax,%r12
    cca2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cca7:	0f 84 2d 14 00 00    	je     e0da <f0+0x2b9a>
    ccad:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ccb2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ccb9:	33 f3 bf 
    ccbc:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    ccc3:	00 
    ccc4:	bf 01 00 00 00       	mov    $0x1,%edi
    ccc9:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    ccd0:	00 
    ccd1:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    ccd8:	00 
    ccd9:	e8 12 99 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    ccde:	48 8b 15 f3 7e 01 00 	mov    0x17ef3(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    cce5:	49 89 c5             	mov    %rax,%r13
    cce8:	48 2b 05 c1 7e 01 00 	sub    0x17ec1(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    ccef:	48 c1 e2 10          	shl    $0x10,%rdx
    ccf3:	48 39 d0             	cmp    %rdx,%rax
    ccf6:	73 59                	jae    cd51 <f0+0x1811>
    ccf8:	48 89 c2             	mov    %rax,%rdx
    ccfb:	48 c1 ea 10          	shr    $0x10,%rdx
    ccff:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd03:	48 8b 15 ee 7e 01 00 	mov    0x17eee(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    cd0a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd0e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd12:	4d 85 e4             	test   %r12,%r12
    cd15:	74 3a                	je     cd51 <f0+0x1811>
    cd17:	0f b6 0a             	movzbl (%rdx),%ecx
    cd1a:	80 f9 02             	cmp    $0x2,%cl
    cd1d:	0f 84 bd 11 00 00    	je     dee0 <f0+0x29a0>
    cd23:	80 f9 01             	cmp    $0x1,%cl
    cd26:	75 29                	jne    cd51 <f0+0x1811>
    cd28:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd2b:	0f b7 c0             	movzwl %ax,%eax
    cd2e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd31:	48 0f af c1          	imul   %rcx,%rax
    cd35:	48 c1 e8 20          	shr    $0x20,%rax
    cd39:	48 39 d0             	cmp    %rdx,%rax
    cd3c:	73 13                	jae    cd51 <f0+0x1811>
    cd3e:	49 01 c4             	add    %rax,%r12
    cd41:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd46:	0f 84 9b 13 00 00    	je     e0e7 <f0+0x2ba7>
    cd4c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd51:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cd58:	00 f0 3f 
    cd5b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    cd62:	00 
    cd63:	bf 01 00 00 00       	mov    $0x1,%edi
    cd68:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    cd6f:	00 
    cd70:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    cd77:	00 
    cd78:	e8 73 98 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    cd7d:	48 8b 15 54 7e 01 00 	mov    0x17e54(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    cd84:	49 89 c5             	mov    %rax,%r13
    cd87:	48 2b 05 22 7e 01 00 	sub    0x17e22(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    cd8e:	48 c1 e2 10          	shl    $0x10,%rdx
    cd92:	48 39 d0             	cmp    %rdx,%rax
    cd95:	73 59                	jae    cdf0 <f0+0x18b0>
    cd97:	48 89 c2             	mov    %rax,%rdx
    cd9a:	48 c1 ea 10          	shr    $0x10,%rdx
    cd9e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cda2:	48 8b 15 4f 7e 01 00 	mov    0x17e4f(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    cda9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cdad:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cdb1:	4d 85 e4             	test   %r12,%r12
    cdb4:	74 3a                	je     cdf0 <f0+0x18b0>
    cdb6:	0f b6 0a             	movzbl (%rdx),%ecx
    cdb9:	80 f9 02             	cmp    $0x2,%cl
    cdbc:	0f 84 0e 11 00 00    	je     ded0 <f0+0x2990>
    cdc2:	80 f9 01             	cmp    $0x1,%cl
    cdc5:	75 29                	jne    cdf0 <f0+0x18b0>
    cdc7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cdca:	0f b7 c0             	movzwl %ax,%eax
    cdcd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cdd0:	48 0f af c1          	imul   %rcx,%rax
    cdd4:	48 c1 e8 20          	shr    $0x20,%rax
    cdd8:	48 39 d0             	cmp    %rdx,%rax
    cddb:	73 13                	jae    cdf0 <f0+0x18b0>
    cddd:	49 01 c4             	add    %rax,%r12
    cde0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cde5:	0f 84 09 13 00 00    	je     e0f4 <f0+0x2bb4>
    cdeb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cdf0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cdf7:	33 f3 bf 
    cdfa:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    ce01:	00 
    ce02:	bf 01 00 00 00       	mov    $0x1,%edi
    ce07:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    ce0e:	00 
    ce0f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    ce16:	00 
    ce17:	e8 d4 97 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    ce1c:	48 8b 15 b5 7d 01 00 	mov    0x17db5(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    ce23:	49 89 c5             	mov    %rax,%r13
    ce26:	48 2b 05 83 7d 01 00 	sub    0x17d83(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    ce2d:	48 c1 e2 10          	shl    $0x10,%rdx
    ce31:	48 39 d0             	cmp    %rdx,%rax
    ce34:	73 59                	jae    ce8f <f0+0x194f>
    ce36:	48 89 c2             	mov    %rax,%rdx
    ce39:	48 c1 ea 10          	shr    $0x10,%rdx
    ce3d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce41:	48 8b 15 b0 7d 01 00 	mov    0x17db0(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    ce48:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce4c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce50:	4d 85 e4             	test   %r12,%r12
    ce53:	74 3a                	je     ce8f <f0+0x194f>
    ce55:	0f b6 0a             	movzbl (%rdx),%ecx
    ce58:	80 f9 02             	cmp    $0x2,%cl
    ce5b:	0f 84 5f 10 00 00    	je     dec0 <f0+0x2980>
    ce61:	80 f9 01             	cmp    $0x1,%cl
    ce64:	75 29                	jne    ce8f <f0+0x194f>
    ce66:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce69:	0f b7 c0             	movzwl %ax,%eax
    ce6c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce6f:	48 0f af c1          	imul   %rcx,%rax
    ce73:	48 c1 e8 20          	shr    $0x20,%rax
    ce77:	48 39 d0             	cmp    %rdx,%rax
    ce7a:	73 13                	jae    ce8f <f0+0x194f>
    ce7c:	49 01 c4             	add    %rax,%r12
    ce7f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce84:	0f 84 77 12 00 00    	je     e101 <f0+0x2bc1>
    ce8a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce8f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ce96:	00 f0 3f 
    ce99:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    cea0:	00 
    cea1:	bf 01 00 00 00       	mov    $0x1,%edi
    cea6:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    cead:	00 
    ceae:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    ceb5:	00 
    ceb6:	e8 35 97 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    cebb:	48 8b 15 16 7d 01 00 	mov    0x17d16(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    cec2:	49 89 c5             	mov    %rax,%r13
    cec5:	48 2b 05 e4 7c 01 00 	sub    0x17ce4(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    cecc:	48 c1 e2 10          	shl    $0x10,%rdx
    ced0:	48 39 d0             	cmp    %rdx,%rax
    ced3:	73 59                	jae    cf2e <f0+0x19ee>
    ced5:	48 89 c2             	mov    %rax,%rdx
    ced8:	48 c1 ea 10          	shr    $0x10,%rdx
    cedc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cee0:	48 8b 15 11 7d 01 00 	mov    0x17d11(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    cee7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ceeb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ceef:	4d 85 e4             	test   %r12,%r12
    cef2:	74 3a                	je     cf2e <f0+0x19ee>
    cef4:	0f b6 0a             	movzbl (%rdx),%ecx
    cef7:	80 f9 02             	cmp    $0x2,%cl
    cefa:	0f 84 40 0f 00 00    	je     de40 <f0+0x2900>
    cf00:	80 f9 01             	cmp    $0x1,%cl
    cf03:	75 29                	jne    cf2e <f0+0x19ee>
    cf05:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf08:	0f b7 c0             	movzwl %ax,%eax
    cf0b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf0e:	48 0f af c1          	imul   %rcx,%rax
    cf12:	48 c1 e8 20          	shr    $0x20,%rax
    cf16:	48 39 d0             	cmp    %rdx,%rax
    cf19:	73 13                	jae    cf2e <f0+0x19ee>
    cf1b:	49 01 c4             	add    %rax,%r12
    cf1e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf23:	0f 84 e5 11 00 00    	je     e10e <f0+0x2bce>
    cf29:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf2e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cf35:	33 f3 bf 
    cf38:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    cf3f:	00 
    cf40:	bf 01 00 00 00       	mov    $0x1,%edi
    cf45:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    cf4c:	00 
    cf4d:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    cf54:	00 
    cf55:	e8 96 96 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    cf5a:	48 8b 15 77 7c 01 00 	mov    0x17c77(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    cf61:	49 89 c5             	mov    %rax,%r13
    cf64:	48 2b 05 45 7c 01 00 	sub    0x17c45(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    cf6b:	48 c1 e2 10          	shl    $0x10,%rdx
    cf6f:	48 39 d0             	cmp    %rdx,%rax
    cf72:	73 59                	jae    cfcd <f0+0x1a8d>
    cf74:	48 89 c2             	mov    %rax,%rdx
    cf77:	48 c1 ea 10          	shr    $0x10,%rdx
    cf7b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf7f:	48 8b 15 72 7c 01 00 	mov    0x17c72(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    cf86:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf8a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf8e:	4d 85 e4             	test   %r12,%r12
    cf91:	74 3a                	je     cfcd <f0+0x1a8d>
    cf93:	0f b6 0a             	movzbl (%rdx),%ecx
    cf96:	80 f9 02             	cmp    $0x2,%cl
    cf99:	0f 84 91 0e 00 00    	je     de30 <f0+0x28f0>
    cf9f:	80 f9 01             	cmp    $0x1,%cl
    cfa2:	75 29                	jne    cfcd <f0+0x1a8d>
    cfa4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfa7:	0f b7 c0             	movzwl %ax,%eax
    cfaa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cfad:	48 0f af c1          	imul   %rcx,%rax
    cfb1:	48 c1 e8 20          	shr    $0x20,%rax
    cfb5:	48 39 d0             	cmp    %rdx,%rax
    cfb8:	73 13                	jae    cfcd <f0+0x1a8d>
    cfba:	49 01 c4             	add    %rax,%r12
    cfbd:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cfc2:	0f 84 53 11 00 00    	je     e11b <f0+0x2bdb>
    cfc8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cfcd:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cfd4:	00 f0 3f 
    cfd7:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    cfde:	00 
    cfdf:	bf 01 00 00 00       	mov    $0x1,%edi
    cfe4:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    cfeb:	00 
    cfec:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    cff3:	00 
    cff4:	e8 f7 95 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    cff9:	48 8b 15 d8 7b 01 00 	mov    0x17bd8(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    d000:	49 89 c5             	mov    %rax,%r13
    d003:	48 2b 05 a6 7b 01 00 	sub    0x17ba6(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    d00a:	48 c1 e2 10          	shl    $0x10,%rdx
    d00e:	48 39 d0             	cmp    %rdx,%rax
    d011:	73 59                	jae    d06c <f0+0x1b2c>
    d013:	48 89 c2             	mov    %rax,%rdx
    d016:	48 c1 ea 10          	shr    $0x10,%rdx
    d01a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d01e:	48 8b 15 d3 7b 01 00 	mov    0x17bd3(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    d025:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d029:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d02d:	4d 85 e4             	test   %r12,%r12
    d030:	74 3a                	je     d06c <f0+0x1b2c>
    d032:	0f b6 0a             	movzbl (%rdx),%ecx
    d035:	80 f9 02             	cmp    $0x2,%cl
    d038:	0f 84 e2 0d 00 00    	je     de20 <f0+0x28e0>
    d03e:	80 f9 01             	cmp    $0x1,%cl
    d041:	75 29                	jne    d06c <f0+0x1b2c>
    d043:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d046:	0f b7 c0             	movzwl %ax,%eax
    d049:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d04c:	48 0f af c1          	imul   %rcx,%rax
    d050:	48 c1 e8 20          	shr    $0x20,%rax
    d054:	48 39 d0             	cmp    %rdx,%rax
    d057:	73 13                	jae    d06c <f0+0x1b2c>
    d059:	49 01 c4             	add    %rax,%r12
    d05c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d061:	0f 84 c1 10 00 00    	je     e128 <f0+0x2be8>
    d067:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d06c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d073:	33 f3 bf 
    d076:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    d07d:	00 
    d07e:	bf 01 00 00 00       	mov    $0x1,%edi
    d083:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    d08a:	00 
    d08b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    d092:	00 
    d093:	e8 58 95 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    d098:	48 8b 15 39 7b 01 00 	mov    0x17b39(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    d09f:	49 89 c5             	mov    %rax,%r13
    d0a2:	48 2b 05 07 7b 01 00 	sub    0x17b07(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    d0a9:	48 c1 e2 10          	shl    $0x10,%rdx
    d0ad:	48 39 d0             	cmp    %rdx,%rax
    d0b0:	73 59                	jae    d10b <f0+0x1bcb>
    d0b2:	48 89 c2             	mov    %rax,%rdx
    d0b5:	48 c1 ea 10          	shr    $0x10,%rdx
    d0b9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0bd:	48 8b 15 34 7b 01 00 	mov    0x17b34(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    d0c4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d0c8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d0cc:	4d 85 e4             	test   %r12,%r12
    d0cf:	74 3a                	je     d10b <f0+0x1bcb>
    d0d1:	0f b6 0a             	movzbl (%rdx),%ecx
    d0d4:	80 f9 02             	cmp    $0x2,%cl
    d0d7:	0f 84 33 0d 00 00    	je     de10 <f0+0x28d0>
    d0dd:	80 f9 01             	cmp    $0x1,%cl
    d0e0:	75 29                	jne    d10b <f0+0x1bcb>
    d0e2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d0e5:	0f b7 c0             	movzwl %ax,%eax
    d0e8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d0eb:	48 0f af c1          	imul   %rcx,%rax
    d0ef:	48 c1 e8 20          	shr    $0x20,%rax
    d0f3:	48 39 d0             	cmp    %rdx,%rax
    d0f6:	73 13                	jae    d10b <f0+0x1bcb>
    d0f8:	49 01 c4             	add    %rax,%r12
    d0fb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d100:	0f 84 2f 10 00 00    	je     e135 <f0+0x2bf5>
    d106:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d10b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d112:	00 f0 3f 
    d115:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    d11c:	00 
    d11d:	bf 01 00 00 00       	mov    $0x1,%edi
    d122:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    d129:	00 
    d12a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    d131:	00 
    d132:	e8 b9 94 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    d137:	48 8b 15 9a 7a 01 00 	mov    0x17a9a(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    d13e:	49 89 c5             	mov    %rax,%r13
    d141:	48 2b 05 68 7a 01 00 	sub    0x17a68(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    d148:	48 c1 e2 10          	shl    $0x10,%rdx
    d14c:	48 39 d0             	cmp    %rdx,%rax
    d14f:	73 59                	jae    d1aa <f0+0x1c6a>
    d151:	48 89 c2             	mov    %rax,%rdx
    d154:	48 c1 ea 10          	shr    $0x10,%rdx
    d158:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d15c:	48 8b 15 95 7a 01 00 	mov    0x17a95(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    d163:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d167:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d16b:	4d 85 e4             	test   %r12,%r12
    d16e:	74 3a                	je     d1aa <f0+0x1c6a>
    d170:	0f b6 0a             	movzbl (%rdx),%ecx
    d173:	80 f9 02             	cmp    $0x2,%cl
    d176:	0f 84 84 0c 00 00    	je     de00 <f0+0x28c0>
    d17c:	80 f9 01             	cmp    $0x1,%cl
    d17f:	75 29                	jne    d1aa <f0+0x1c6a>
    d181:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d184:	0f b7 c0             	movzwl %ax,%eax
    d187:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d18a:	48 0f af c1          	imul   %rcx,%rax
    d18e:	48 c1 e8 20          	shr    $0x20,%rax
    d192:	48 39 d0             	cmp    %rdx,%rax
    d195:	73 13                	jae    d1aa <f0+0x1c6a>
    d197:	49 01 c4             	add    %rax,%r12
    d19a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d19f:	0f 84 9d 0f 00 00    	je     e142 <f0+0x2c02>
    d1a5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d1aa:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d1b1:	33 f3 bf 
    d1b4:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    d1bb:	00 
    d1bc:	bf 01 00 00 00       	mov    $0x1,%edi
    d1c1:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    d1c8:	00 
    d1c9:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    d1d0:	00 
    d1d1:	e8 1a 94 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    d1d6:	48 8b 15 fb 79 01 00 	mov    0x179fb(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    d1dd:	49 89 c5             	mov    %rax,%r13
    d1e0:	48 2b 05 c9 79 01 00 	sub    0x179c9(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    d1e7:	48 c1 e2 10          	shl    $0x10,%rdx
    d1eb:	48 39 d0             	cmp    %rdx,%rax
    d1ee:	73 59                	jae    d249 <f0+0x1d09>
    d1f0:	48 89 c2             	mov    %rax,%rdx
    d1f3:	48 c1 ea 10          	shr    $0x10,%rdx
    d1f7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d1fb:	48 8b 15 f6 79 01 00 	mov    0x179f6(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    d202:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d206:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d20a:	4d 85 e4             	test   %r12,%r12
    d20d:	74 3a                	je     d249 <f0+0x1d09>
    d20f:	0f b6 0a             	movzbl (%rdx),%ecx
    d212:	80 f9 02             	cmp    $0x2,%cl
    d215:	0f 84 d5 0b 00 00    	je     ddf0 <f0+0x28b0>
    d21b:	80 f9 01             	cmp    $0x1,%cl
    d21e:	75 29                	jne    d249 <f0+0x1d09>
    d220:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d223:	0f b7 c0             	movzwl %ax,%eax
    d226:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d229:	48 0f af c1          	imul   %rcx,%rax
    d22d:	48 c1 e8 20          	shr    $0x20,%rax
    d231:	48 39 d0             	cmp    %rdx,%rax
    d234:	73 13                	jae    d249 <f0+0x1d09>
    d236:	49 01 c4             	add    %rax,%r12
    d239:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d23e:	0f 84 0b 0f 00 00    	je     e14f <f0+0x2c0f>
    d244:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d249:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d250:	00 f0 3f 
    d253:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    d25a:	00 
    d25b:	bf 01 00 00 00       	mov    $0x1,%edi
    d260:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    d267:	00 
    d268:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    d26f:	00 
    d270:	e8 7b 93 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    d275:	48 8b 15 5c 79 01 00 	mov    0x1795c(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    d27c:	49 89 c5             	mov    %rax,%r13
    d27f:	48 2b 05 2a 79 01 00 	sub    0x1792a(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    d286:	48 c1 e2 10          	shl    $0x10,%rdx
    d28a:	48 39 d0             	cmp    %rdx,%rax
    d28d:	73 59                	jae    d2e8 <f0+0x1da8>
    d28f:	48 89 c2             	mov    %rax,%rdx
    d292:	48 c1 ea 10          	shr    $0x10,%rdx
    d296:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d29a:	48 8b 15 57 79 01 00 	mov    0x17957(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    d2a1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d2a5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d2a9:	4d 85 e4             	test   %r12,%r12
    d2ac:	74 3a                	je     d2e8 <f0+0x1da8>
    d2ae:	0f b6 0a             	movzbl (%rdx),%ecx
    d2b1:	80 f9 02             	cmp    $0x2,%cl
    d2b4:	0f 84 26 0b 00 00    	je     dde0 <f0+0x28a0>
    d2ba:	80 f9 01             	cmp    $0x1,%cl
    d2bd:	75 29                	jne    d2e8 <f0+0x1da8>
    d2bf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2c2:	0f b7 c0             	movzwl %ax,%eax
    d2c5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d2c8:	48 0f af c1          	imul   %rcx,%rax
    d2cc:	48 c1 e8 20          	shr    $0x20,%rax
    d2d0:	48 39 d0             	cmp    %rdx,%rax
    d2d3:	73 13                	jae    d2e8 <f0+0x1da8>
    d2d5:	49 01 c4             	add    %rax,%r12
    d2d8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d2dd:	0f 84 79 0e 00 00    	je     e15c <f0+0x2c1c>
    d2e3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d2e8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d2ef:	33 f3 bf 
    d2f2:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    d2f9:	00 
    d2fa:	bf 01 00 00 00       	mov    $0x1,%edi
    d2ff:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    d306:	00 
    d307:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    d30e:	00 
    d30f:	e8 dc 92 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    d314:	48 8b 15 bd 78 01 00 	mov    0x178bd(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    d31b:	49 89 c5             	mov    %rax,%r13
    d31e:	48 2b 05 8b 78 01 00 	sub    0x1788b(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    d325:	48 c1 e2 10          	shl    $0x10,%rdx
    d329:	48 39 d0             	cmp    %rdx,%rax
    d32c:	73 59                	jae    d387 <f0+0x1e47>
    d32e:	48 89 c2             	mov    %rax,%rdx
    d331:	48 c1 ea 10          	shr    $0x10,%rdx
    d335:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d339:	48 8b 15 b8 78 01 00 	mov    0x178b8(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    d340:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d344:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d348:	4d 85 e4             	test   %r12,%r12
    d34b:	74 3a                	je     d387 <f0+0x1e47>
    d34d:	0f b6 0a             	movzbl (%rdx),%ecx
    d350:	80 f9 02             	cmp    $0x2,%cl
    d353:	0f 84 77 0a 00 00    	je     ddd0 <f0+0x2890>
    d359:	80 f9 01             	cmp    $0x1,%cl
    d35c:	75 29                	jne    d387 <f0+0x1e47>
    d35e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d361:	0f b7 c0             	movzwl %ax,%eax
    d364:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d367:	48 0f af c1          	imul   %rcx,%rax
    d36b:	48 c1 e8 20          	shr    $0x20,%rax
    d36f:	48 39 d0             	cmp    %rdx,%rax
    d372:	73 13                	jae    d387 <f0+0x1e47>
    d374:	49 01 c4             	add    %rax,%r12
    d377:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d37c:	0f 84 e7 0d 00 00    	je     e169 <f0+0x2c29>
    d382:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d387:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d38e:	00 f0 3f 
    d391:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    d398:	00 
    d399:	bf 01 00 00 00       	mov    $0x1,%edi
    d39e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    d3a5:	00 
    d3a6:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    d3ad:	00 
    d3ae:	e8 3d 92 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    d3b3:	48 8b 15 1e 78 01 00 	mov    0x1781e(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    d3ba:	49 89 c5             	mov    %rax,%r13
    d3bd:	48 2b 05 ec 77 01 00 	sub    0x177ec(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    d3c4:	48 c1 e2 10          	shl    $0x10,%rdx
    d3c8:	48 39 d0             	cmp    %rdx,%rax
    d3cb:	73 59                	jae    d426 <f0+0x1ee6>
    d3cd:	48 89 c2             	mov    %rax,%rdx
    d3d0:	48 c1 ea 10          	shr    $0x10,%rdx
    d3d4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d3d8:	48 8b 15 19 78 01 00 	mov    0x17819(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    d3df:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d3e3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d3e7:	4d 85 e4             	test   %r12,%r12
    d3ea:	74 3a                	je     d426 <f0+0x1ee6>
    d3ec:	0f b6 0a             	movzbl (%rdx),%ecx
    d3ef:	80 f9 02             	cmp    $0x2,%cl
    d3f2:	0f 84 38 0c 00 00    	je     e030 <f0+0x2af0>
    d3f8:	80 f9 01             	cmp    $0x1,%cl
    d3fb:	75 29                	jne    d426 <f0+0x1ee6>
    d3fd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d400:	0f b7 c0             	movzwl %ax,%eax
    d403:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d406:	48 0f af c1          	imul   %rcx,%rax
    d40a:	48 c1 e8 20          	shr    $0x20,%rax
    d40e:	48 39 d0             	cmp    %rdx,%rax
    d411:	73 13                	jae    d426 <f0+0x1ee6>
    d413:	49 01 c4             	add    %rax,%r12
    d416:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d41b:	0f 84 55 0d 00 00    	je     e176 <f0+0x2c36>
    d421:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d426:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d42d:	33 f3 bf 
    d430:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    d437:	00 
    d438:	bf 01 00 00 00       	mov    $0x1,%edi
    d43d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    d444:	00 
    d445:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    d44c:	00 
    d44d:	e8 9e 91 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    d452:	48 8b 15 7f 77 01 00 	mov    0x1777f(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    d459:	49 89 c5             	mov    %rax,%r13
    d45c:	48 2b 05 4d 77 01 00 	sub    0x1774d(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    d463:	48 c1 e2 10          	shl    $0x10,%rdx
    d467:	48 39 d0             	cmp    %rdx,%rax
    d46a:	73 59                	jae    d4c5 <f0+0x1f85>
    d46c:	48 89 c2             	mov    %rax,%rdx
    d46f:	48 c1 ea 10          	shr    $0x10,%rdx
    d473:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d477:	48 8b 15 7a 77 01 00 	mov    0x1777a(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    d47e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d482:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d486:	4d 85 e4             	test   %r12,%r12
    d489:	74 3a                	je     d4c5 <f0+0x1f85>
    d48b:	0f b6 0a             	movzbl (%rdx),%ecx
    d48e:	80 f9 02             	cmp    $0x2,%cl
    d491:	0f 84 89 0b 00 00    	je     e020 <f0+0x2ae0>
    d497:	80 f9 01             	cmp    $0x1,%cl
    d49a:	75 29                	jne    d4c5 <f0+0x1f85>
    d49c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d49f:	0f b7 c0             	movzwl %ax,%eax
    d4a2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d4a5:	48 0f af c1          	imul   %rcx,%rax
    d4a9:	48 c1 e8 20          	shr    $0x20,%rax
    d4ad:	48 39 d0             	cmp    %rdx,%rax
    d4b0:	73 13                	jae    d4c5 <f0+0x1f85>
    d4b2:	49 01 c4             	add    %rax,%r12
    d4b5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d4ba:	0f 84 c3 0c 00 00    	je     e183 <f0+0x2c43>
    d4c0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d4c5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d4cc:	00 f0 3f 
    d4cf:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    d4d6:	00 
    d4d7:	bf 01 00 00 00       	mov    $0x1,%edi
    d4dc:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    d4e3:	00 
    d4e4:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    d4eb:	00 
    d4ec:	e8 ff 90 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    d4f1:	48 8b 15 e0 76 01 00 	mov    0x176e0(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    d4f8:	49 89 c5             	mov    %rax,%r13
    d4fb:	48 2b 05 ae 76 01 00 	sub    0x176ae(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    d502:	48 c1 e2 10          	shl    $0x10,%rdx
    d506:	48 39 d0             	cmp    %rdx,%rax
    d509:	73 59                	jae    d564 <f0+0x2024>
    d50b:	48 89 c2             	mov    %rax,%rdx
    d50e:	48 c1 ea 10          	shr    $0x10,%rdx
    d512:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d516:	48 8b 15 db 76 01 00 	mov    0x176db(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    d51d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d521:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d525:	4d 85 e4             	test   %r12,%r12
    d528:	74 3a                	je     d564 <f0+0x2024>
    d52a:	0f b6 0a             	movzbl (%rdx),%ecx
    d52d:	80 f9 02             	cmp    $0x2,%cl
    d530:	0f 84 da 0a 00 00    	je     e010 <f0+0x2ad0>
    d536:	80 f9 01             	cmp    $0x1,%cl
    d539:	75 29                	jne    d564 <f0+0x2024>
    d53b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d53e:	0f b7 c0             	movzwl %ax,%eax
    d541:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d544:	48 0f af c1          	imul   %rcx,%rax
    d548:	48 c1 e8 20          	shr    $0x20,%rax
    d54c:	48 39 d0             	cmp    %rdx,%rax
    d54f:	73 13                	jae    d564 <f0+0x2024>
    d551:	49 01 c4             	add    %rax,%r12
    d554:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d559:	0f 84 31 0c 00 00    	je     e190 <f0+0x2c50>
    d55f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d564:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d56b:	33 f3 bf 
    d56e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    d575:	00 
    d576:	bf 01 00 00 00       	mov    $0x1,%edi
    d57b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    d582:	00 
    d583:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    d58a:	00 
    d58b:	e8 60 90 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    d590:	48 8b 15 41 76 01 00 	mov    0x17641(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    d597:	49 89 c5             	mov    %rax,%r13
    d59a:	48 2b 05 0f 76 01 00 	sub    0x1760f(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    d5a1:	48 c1 e2 10          	shl    $0x10,%rdx
    d5a5:	48 39 d0             	cmp    %rdx,%rax
    d5a8:	73 59                	jae    d603 <f0+0x20c3>
    d5aa:	48 89 c2             	mov    %rax,%rdx
    d5ad:	48 c1 ea 10          	shr    $0x10,%rdx
    d5b1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d5b5:	48 8b 15 3c 76 01 00 	mov    0x1763c(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    d5bc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d5c0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d5c4:	4d 85 e4             	test   %r12,%r12
    d5c7:	74 3a                	je     d603 <f0+0x20c3>
    d5c9:	0f b6 0a             	movzbl (%rdx),%ecx
    d5cc:	80 f9 02             	cmp    $0x2,%cl
    d5cf:	0f 84 2b 0a 00 00    	je     e000 <f0+0x2ac0>
    d5d5:	80 f9 01             	cmp    $0x1,%cl
    d5d8:	75 29                	jne    d603 <f0+0x20c3>
    d5da:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d5dd:	0f b7 c0             	movzwl %ax,%eax
    d5e0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d5e3:	48 0f af c1          	imul   %rcx,%rax
    d5e7:	48 c1 e8 20          	shr    $0x20,%rax
    d5eb:	48 39 d0             	cmp    %rdx,%rax
    d5ee:	73 13                	jae    d603 <f0+0x20c3>
    d5f0:	49 01 c4             	add    %rax,%r12
    d5f3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d5f8:	0f 84 9f 0b 00 00    	je     e19d <f0+0x2c5d>
    d5fe:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d603:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d60a:	00 f0 3f 
    d60d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    d614:	00 
    d615:	bf 01 00 00 00       	mov    $0x1,%edi
    d61a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    d621:	00 
    d622:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    d629:	00 
    d62a:	e8 c1 8f ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    d62f:	48 8b 15 a2 75 01 00 	mov    0x175a2(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    d636:	49 89 c5             	mov    %rax,%r13
    d639:	48 2b 05 70 75 01 00 	sub    0x17570(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    d640:	48 c1 e2 10          	shl    $0x10,%rdx
    d644:	48 39 d0             	cmp    %rdx,%rax
    d647:	73 59                	jae    d6a2 <f0+0x2162>
    d649:	48 89 c2             	mov    %rax,%rdx
    d64c:	48 c1 ea 10          	shr    $0x10,%rdx
    d650:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d654:	48 8b 15 9d 75 01 00 	mov    0x1759d(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    d65b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d65f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d663:	4d 85 e4             	test   %r12,%r12
    d666:	74 3a                	je     d6a2 <f0+0x2162>
    d668:	0f b6 0a             	movzbl (%rdx),%ecx
    d66b:	80 f9 02             	cmp    $0x2,%cl
    d66e:	0f 84 7c 09 00 00    	je     dff0 <f0+0x2ab0>
    d674:	80 f9 01             	cmp    $0x1,%cl
    d677:	75 29                	jne    d6a2 <f0+0x2162>
    d679:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d67c:	0f b7 c0             	movzwl %ax,%eax
    d67f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d682:	48 0f af c1          	imul   %rcx,%rax
    d686:	48 c1 e8 20          	shr    $0x20,%rax
    d68a:	48 39 d0             	cmp    %rdx,%rax
    d68d:	73 13                	jae    d6a2 <f0+0x2162>
    d68f:	49 01 c4             	add    %rax,%r12
    d692:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d697:	0f 84 0d 0b 00 00    	je     e1aa <f0+0x2c6a>
    d69d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d6a2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d6a9:	33 f3 bf 
    d6ac:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    d6b3:	00 
    d6b4:	bf 01 00 00 00       	mov    $0x1,%edi
    d6b9:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    d6c0:	00 
    d6c1:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    d6c8:	00 
    d6c9:	e8 22 8f ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    d6ce:	48 8b 15 03 75 01 00 	mov    0x17503(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    d6d5:	49 89 c5             	mov    %rax,%r13
    d6d8:	48 2b 05 d1 74 01 00 	sub    0x174d1(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    d6df:	48 c1 e2 10          	shl    $0x10,%rdx
    d6e3:	48 39 d0             	cmp    %rdx,%rax
    d6e6:	73 59                	jae    d741 <f0+0x2201>
    d6e8:	48 89 c2             	mov    %rax,%rdx
    d6eb:	48 c1 ea 10          	shr    $0x10,%rdx
    d6ef:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d6f3:	48 8b 15 fe 74 01 00 	mov    0x174fe(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    d6fa:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d6fe:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d702:	4d 85 e4             	test   %r12,%r12
    d705:	74 3a                	je     d741 <f0+0x2201>
    d707:	0f b6 0a             	movzbl (%rdx),%ecx
    d70a:	80 f9 02             	cmp    $0x2,%cl
    d70d:	0f 84 cd 08 00 00    	je     dfe0 <f0+0x2aa0>
    d713:	80 f9 01             	cmp    $0x1,%cl
    d716:	75 29                	jne    d741 <f0+0x2201>
    d718:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d71b:	0f b7 c0             	movzwl %ax,%eax
    d71e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d721:	48 0f af c1          	imul   %rcx,%rax
    d725:	48 c1 e8 20          	shr    $0x20,%rax
    d729:	48 39 d0             	cmp    %rdx,%rax
    d72c:	73 13                	jae    d741 <f0+0x2201>
    d72e:	49 01 c4             	add    %rax,%r12
    d731:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d736:	0f 84 7b 0a 00 00    	je     e1b7 <f0+0x2c77>
    d73c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d741:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d748:	00 f0 3f 
    d74b:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    d752:	00 
    d753:	bf 01 00 00 00       	mov    $0x1,%edi
    d758:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    d75f:	00 
    d760:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    d767:	00 
    d768:	e8 83 8e ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    d76d:	48 8b 15 64 74 01 00 	mov    0x17464(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    d774:	49 89 c5             	mov    %rax,%r13
    d777:	48 2b 05 32 74 01 00 	sub    0x17432(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    d77e:	48 c1 e2 10          	shl    $0x10,%rdx
    d782:	48 39 d0             	cmp    %rdx,%rax
    d785:	73 59                	jae    d7e0 <f0+0x22a0>
    d787:	48 89 c2             	mov    %rax,%rdx
    d78a:	48 c1 ea 10          	shr    $0x10,%rdx
    d78e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d792:	48 8b 15 5f 74 01 00 	mov    0x1745f(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    d799:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d79d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d7a1:	4d 85 e4             	test   %r12,%r12
    d7a4:	74 3a                	je     d7e0 <f0+0x22a0>
    d7a6:	0f b6 0a             	movzbl (%rdx),%ecx
    d7a9:	80 f9 02             	cmp    $0x2,%cl
    d7ac:	0f 84 1e 08 00 00    	je     dfd0 <f0+0x2a90>
    d7b2:	80 f9 01             	cmp    $0x1,%cl
    d7b5:	75 29                	jne    d7e0 <f0+0x22a0>
    d7b7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d7ba:	0f b7 c0             	movzwl %ax,%eax
    d7bd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d7c0:	48 0f af c1          	imul   %rcx,%rax
    d7c4:	48 c1 e8 20          	shr    $0x20,%rax
    d7c8:	48 39 d0             	cmp    %rdx,%rax
    d7cb:	73 13                	jae    d7e0 <f0+0x22a0>
    d7cd:	49 01 c4             	add    %rax,%r12
    d7d0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d7d5:	0f 84 e9 09 00 00    	je     e1c4 <f0+0x2c84>
    d7db:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d7e0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d7e7:	33 f3 bf 
    d7ea:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    d7f1:	00 
    d7f2:	bf 01 00 00 00       	mov    $0x1,%edi
    d7f7:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    d7fe:	00 
    d7ff:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    d806:	00 
    d807:	e8 e4 8d ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    d80c:	48 8b 15 c5 73 01 00 	mov    0x173c5(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    d813:	49 89 c5             	mov    %rax,%r13
    d816:	48 2b 05 93 73 01 00 	sub    0x17393(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    d81d:	48 c1 e2 10          	shl    $0x10,%rdx
    d821:	48 39 d0             	cmp    %rdx,%rax
    d824:	73 59                	jae    d87f <f0+0x233f>
    d826:	48 89 c2             	mov    %rax,%rdx
    d829:	48 c1 ea 10          	shr    $0x10,%rdx
    d82d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d831:	48 8b 15 c0 73 01 00 	mov    0x173c0(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    d838:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d83c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d840:	4d 85 e4             	test   %r12,%r12
    d843:	74 3a                	je     d87f <f0+0x233f>
    d845:	0f b6 0a             	movzbl (%rdx),%ecx
    d848:	80 f9 02             	cmp    $0x2,%cl
    d84b:	0f 84 6f 07 00 00    	je     dfc0 <f0+0x2a80>
    d851:	80 f9 01             	cmp    $0x1,%cl
    d854:	75 29                	jne    d87f <f0+0x233f>
    d856:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d859:	0f b7 c0             	movzwl %ax,%eax
    d85c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d85f:	48 0f af c1          	imul   %rcx,%rax
    d863:	48 c1 e8 20          	shr    $0x20,%rax
    d867:	48 39 d0             	cmp    %rdx,%rax
    d86a:	73 13                	jae    d87f <f0+0x233f>
    d86c:	49 01 c4             	add    %rax,%r12
    d86f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d874:	0f 84 57 09 00 00    	je     e1d1 <f0+0x2c91>
    d87a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d87f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d886:	00 f0 3f 
    d889:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    d890:	00 
    d891:	bf 01 00 00 00       	mov    $0x1,%edi
    d896:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    d89d:	00 
    d89e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    d8a5:	00 
    d8a6:	e8 45 8d ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    d8ab:	48 8b 15 26 73 01 00 	mov    0x17326(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    d8b2:	49 89 c5             	mov    %rax,%r13
    d8b5:	48 2b 05 f4 72 01 00 	sub    0x172f4(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    d8bc:	48 c1 e2 10          	shl    $0x10,%rdx
    d8c0:	48 39 d0             	cmp    %rdx,%rax
    d8c3:	73 59                	jae    d91e <f0+0x23de>
    d8c5:	48 89 c2             	mov    %rax,%rdx
    d8c8:	48 c1 ea 10          	shr    $0x10,%rdx
    d8cc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d8d0:	48 8b 15 21 73 01 00 	mov    0x17321(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    d8d7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d8db:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d8df:	4d 85 e4             	test   %r12,%r12
    d8e2:	74 3a                	je     d91e <f0+0x23de>
    d8e4:	0f b6 0a             	movzbl (%rdx),%ecx
    d8e7:	80 f9 02             	cmp    $0x2,%cl
    d8ea:	0f 84 c0 06 00 00    	je     dfb0 <f0+0x2a70>
    d8f0:	80 f9 01             	cmp    $0x1,%cl
    d8f3:	75 29                	jne    d91e <f0+0x23de>
    d8f5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d8f8:	0f b7 c0             	movzwl %ax,%eax
    d8fb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d8fe:	48 0f af c1          	imul   %rcx,%rax
    d902:	48 c1 e8 20          	shr    $0x20,%rax
    d906:	48 39 d0             	cmp    %rdx,%rax
    d909:	73 13                	jae    d91e <f0+0x23de>
    d90b:	49 01 c4             	add    %rax,%r12
    d90e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d913:	0f 84 c5 08 00 00    	je     e1de <f0+0x2c9e>
    d919:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d91e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d925:	33 f3 bf 
    d928:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    d92f:	00 
    d930:	bf 01 00 00 00       	mov    $0x1,%edi
    d935:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    d93c:	00 
    d93d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    d944:	00 
    d945:	e8 a6 8c ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    d94a:	48 8b 15 87 72 01 00 	mov    0x17287(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    d951:	49 89 c5             	mov    %rax,%r13
    d954:	48 2b 05 55 72 01 00 	sub    0x17255(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    d95b:	48 c1 e2 10          	shl    $0x10,%rdx
    d95f:	48 39 d0             	cmp    %rdx,%rax
    d962:	73 59                	jae    d9bd <f0+0x247d>
    d964:	48 89 c2             	mov    %rax,%rdx
    d967:	48 c1 ea 10          	shr    $0x10,%rdx
    d96b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d96f:	48 8b 15 82 72 01 00 	mov    0x17282(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    d976:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d97a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d97e:	4d 85 e4             	test   %r12,%r12
    d981:	74 3a                	je     d9bd <f0+0x247d>
    d983:	0f b6 0a             	movzbl (%rdx),%ecx
    d986:	80 f9 02             	cmp    $0x2,%cl
    d989:	0f 84 11 06 00 00    	je     dfa0 <f0+0x2a60>
    d98f:	80 f9 01             	cmp    $0x1,%cl
    d992:	75 29                	jne    d9bd <f0+0x247d>
    d994:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d997:	0f b7 c0             	movzwl %ax,%eax
    d99a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d99d:	48 0f af c1          	imul   %rcx,%rax
    d9a1:	48 c1 e8 20          	shr    $0x20,%rax
    d9a5:	48 39 d0             	cmp    %rdx,%rax
    d9a8:	73 13                	jae    d9bd <f0+0x247d>
    d9aa:	49 01 c4             	add    %rax,%r12
    d9ad:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d9b2:	0f 84 33 08 00 00    	je     e1eb <f0+0x2cab>
    d9b8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d9bd:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d9c4:	00 f0 3f 
    d9c7:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    d9ce:	00 
    d9cf:	bf 01 00 00 00       	mov    $0x1,%edi
    d9d4:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    d9db:	00 
    d9dc:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    d9e3:	00 
    d9e4:	e8 07 8c ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    d9e9:	48 8b 15 e8 71 01 00 	mov    0x171e8(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    d9f0:	49 89 c5             	mov    %rax,%r13
    d9f3:	48 2b 05 b6 71 01 00 	sub    0x171b6(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    d9fa:	48 c1 e2 10          	shl    $0x10,%rdx
    d9fe:	48 39 d0             	cmp    %rdx,%rax
    da01:	73 59                	jae    da5c <f0+0x251c>
    da03:	48 89 c2             	mov    %rax,%rdx
    da06:	48 c1 ea 10          	shr    $0x10,%rdx
    da0a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    da0e:	48 8b 15 e3 71 01 00 	mov    0x171e3(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    da15:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    da19:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    da1d:	4d 85 e4             	test   %r12,%r12
    da20:	74 3a                	je     da5c <f0+0x251c>
    da22:	0f b6 0a             	movzbl (%rdx),%ecx
    da25:	80 f9 02             	cmp    $0x2,%cl
    da28:	0f 84 62 05 00 00    	je     df90 <f0+0x2a50>
    da2e:	80 f9 01             	cmp    $0x1,%cl
    da31:	75 29                	jne    da5c <f0+0x251c>
    da33:	8b 4a 18             	mov    0x18(%rdx),%ecx
    da36:	0f b7 c0             	movzwl %ax,%eax
    da39:	8b 52 1c             	mov    0x1c(%rdx),%edx
    da3c:	48 0f af c1          	imul   %rcx,%rax
    da40:	48 c1 e8 20          	shr    $0x20,%rax
    da44:	48 39 d0             	cmp    %rdx,%rax
    da47:	73 13                	jae    da5c <f0+0x251c>
    da49:	49 01 c4             	add    %rax,%r12
    da4c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    da51:	0f 84 a1 07 00 00    	je     e1f8 <f0+0x2cb8>
    da57:	41 c6 04 24 01       	movb   $0x1,(%r12)
    da5c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    da63:	33 f3 bf 
    da66:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    da6d:	00 
    da6e:	bf 01 00 00 00       	mov    $0x1,%edi
    da73:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    da7a:	00 
    da7b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    da82:	00 
    da83:	e8 68 8b ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    da88:	48 8b 15 49 71 01 00 	mov    0x17149(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    da8f:	49 89 c5             	mov    %rax,%r13
    da92:	48 2b 05 17 71 01 00 	sub    0x17117(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    da99:	48 c1 e2 10          	shl    $0x10,%rdx
    da9d:	48 39 d0             	cmp    %rdx,%rax
    daa0:	73 59                	jae    dafb <f0+0x25bb>
    daa2:	48 89 c2             	mov    %rax,%rdx
    daa5:	48 c1 ea 10          	shr    $0x10,%rdx
    daa9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    daad:	48 8b 15 44 71 01 00 	mov    0x17144(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    dab4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dab8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dabc:	4d 85 e4             	test   %r12,%r12
    dabf:	74 3a                	je     dafb <f0+0x25bb>
    dac1:	0f b6 0a             	movzbl (%rdx),%ecx
    dac4:	80 f9 02             	cmp    $0x2,%cl
    dac7:	0f 84 b3 04 00 00    	je     df80 <f0+0x2a40>
    dacd:	80 f9 01             	cmp    $0x1,%cl
    dad0:	75 29                	jne    dafb <f0+0x25bb>
    dad2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dad5:	0f b7 c0             	movzwl %ax,%eax
    dad8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dadb:	48 0f af c1          	imul   %rcx,%rax
    dadf:	48 c1 e8 20          	shr    $0x20,%rax
    dae3:	48 39 d0             	cmp    %rdx,%rax
    dae6:	73 13                	jae    dafb <f0+0x25bb>
    dae8:	49 01 c4             	add    %rax,%r12
    daeb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    daf0:	0f 84 0f 07 00 00    	je     e205 <f0+0x2cc5>
    daf6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dafb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    db02:	00 f0 3f 
    db05:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    db0c:	00 
    db0d:	bf 01 00 00 00       	mov    $0x1,%edi
    db12:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    db19:	00 
    db1a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    db21:	00 
    db22:	e8 c9 8a ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    db27:	48 8b 15 aa 70 01 00 	mov    0x170aa(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    db2e:	49 89 c5             	mov    %rax,%r13
    db31:	48 2b 05 78 70 01 00 	sub    0x17078(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    db38:	48 c1 e2 10          	shl    $0x10,%rdx
    db3c:	48 39 d0             	cmp    %rdx,%rax
    db3f:	73 59                	jae    db9a <f0+0x265a>
    db41:	48 89 c2             	mov    %rax,%rdx
    db44:	48 c1 ea 10          	shr    $0x10,%rdx
    db48:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    db4c:	48 8b 15 a5 70 01 00 	mov    0x170a5(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    db53:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    db57:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    db5b:	4d 85 e4             	test   %r12,%r12
    db5e:	74 3a                	je     db9a <f0+0x265a>
    db60:	0f b6 0a             	movzbl (%rdx),%ecx
    db63:	80 f9 02             	cmp    $0x2,%cl
    db66:	0f 84 04 04 00 00    	je     df70 <f0+0x2a30>
    db6c:	80 f9 01             	cmp    $0x1,%cl
    db6f:	75 29                	jne    db9a <f0+0x265a>
    db71:	8b 4a 18             	mov    0x18(%rdx),%ecx
    db74:	0f b7 c0             	movzwl %ax,%eax
    db77:	8b 52 1c             	mov    0x1c(%rdx),%edx
    db7a:	48 0f af c1          	imul   %rcx,%rax
    db7e:	48 c1 e8 20          	shr    $0x20,%rax
    db82:	48 39 d0             	cmp    %rdx,%rax
    db85:	73 13                	jae    db9a <f0+0x265a>
    db87:	49 01 c4             	add    %rax,%r12
    db8a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    db8f:	0f 84 7d 06 00 00    	je     e212 <f0+0x2cd2>
    db95:	41 c6 04 24 01       	movb   $0x1,(%r12)
    db9a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dba1:	33 f3 bf 
    dba4:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    dbab:	00 
    dbac:	bf 01 00 00 00       	mov    $0x1,%edi
    dbb1:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    dbb8:	00 
    dbb9:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    dbc0:	00 
    dbc1:	e8 2a 8a ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    dbc6:	48 8b 15 0b 70 01 00 	mov    0x1700b(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    dbcd:	49 89 c5             	mov    %rax,%r13
    dbd0:	48 2b 05 d9 6f 01 00 	sub    0x16fd9(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    dbd7:	48 c1 e2 10          	shl    $0x10,%rdx
    dbdb:	48 39 d0             	cmp    %rdx,%rax
    dbde:	73 59                	jae    dc39 <f0+0x26f9>
    dbe0:	48 89 c2             	mov    %rax,%rdx
    dbe3:	48 c1 ea 10          	shr    $0x10,%rdx
    dbe7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dbeb:	48 8b 15 06 70 01 00 	mov    0x17006(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    dbf2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dbf6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dbfa:	4d 85 e4             	test   %r12,%r12
    dbfd:	74 3a                	je     dc39 <f0+0x26f9>
    dbff:	0f b6 0a             	movzbl (%rdx),%ecx
    dc02:	80 f9 02             	cmp    $0x2,%cl
    dc05:	0f 84 55 03 00 00    	je     df60 <f0+0x2a20>
    dc0b:	80 f9 01             	cmp    $0x1,%cl
    dc0e:	75 29                	jne    dc39 <f0+0x26f9>
    dc10:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dc13:	0f b7 c0             	movzwl %ax,%eax
    dc16:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dc19:	48 0f af c1          	imul   %rcx,%rax
    dc1d:	48 c1 e8 20          	shr    $0x20,%rax
    dc21:	48 39 d0             	cmp    %rdx,%rax
    dc24:	73 13                	jae    dc39 <f0+0x26f9>
    dc26:	49 01 c4             	add    %rax,%r12
    dc29:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dc2e:	0f 84 eb 05 00 00    	je     e21f <f0+0x2cdf>
    dc34:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dc39:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dc40:	00 f0 3f 
    dc43:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    dc4a:	00 
    dc4b:	bf 01 00 00 00       	mov    $0x1,%edi
    dc50:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    dc57:	00 
    dc58:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    dc5f:	00 
    dc60:	e8 8b 89 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    dc65:	48 8b 15 6c 6f 01 00 	mov    0x16f6c(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    dc6c:	49 89 c5             	mov    %rax,%r13
    dc6f:	48 2b 05 3a 6f 01 00 	sub    0x16f3a(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    dc76:	48 c1 e2 10          	shl    $0x10,%rdx
    dc7a:	48 39 d0             	cmp    %rdx,%rax
    dc7d:	73 59                	jae    dcd8 <f0+0x2798>
    dc7f:	48 89 c2             	mov    %rax,%rdx
    dc82:	48 c1 ea 10          	shr    $0x10,%rdx
    dc86:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dc8a:	48 8b 15 67 6f 01 00 	mov    0x16f67(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    dc91:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dc95:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dc99:	4d 85 e4             	test   %r12,%r12
    dc9c:	74 3a                	je     dcd8 <f0+0x2798>
    dc9e:	0f b6 0a             	movzbl (%rdx),%ecx
    dca1:	80 f9 02             	cmp    $0x2,%cl
    dca4:	0f 84 a6 02 00 00    	je     df50 <f0+0x2a10>
    dcaa:	80 f9 01             	cmp    $0x1,%cl
    dcad:	75 29                	jne    dcd8 <f0+0x2798>
    dcaf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dcb2:	0f b7 c0             	movzwl %ax,%eax
    dcb5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dcb8:	48 0f af c1          	imul   %rcx,%rax
    dcbc:	48 c1 e8 20          	shr    $0x20,%rax
    dcc0:	48 39 d0             	cmp    %rdx,%rax
    dcc3:	73 13                	jae    dcd8 <f0+0x2798>
    dcc5:	49 01 c4             	add    %rax,%r12
    dcc8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dccd:	0f 84 59 05 00 00    	je     e22c <f0+0x2cec>
    dcd3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dcd8:	48 89 ee             	mov    %rbp,%rsi
    dcdb:	bf 01 00 00 00       	mov    $0x1,%edi
    dce0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dce7:	33 f3 bf 
    dcea:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    dcf1:	00 
    dcf2:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    dcf9:	00 
    dcfa:	e8 f1 88 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    dcff:	48 8b 15 d2 6e 01 00 	mov    0x16ed2(%rip),%rdx        # 24bd8 <fwp_heap+0x13d8>
    dd06:	48 89 c5             	mov    %rax,%rbp
    dd09:	48 2b 05 a0 6e 01 00 	sub    0x16ea0(%rip),%rax        # 24bb0 <fwp_heap+0x13b0>
    dd10:	48 c1 e2 10          	shl    $0x10,%rdx
    dd14:	48 39 d0             	cmp    %rdx,%rax
    dd17:	73 59                	jae    dd72 <f0+0x2832>
    dd19:	48 89 c2             	mov    %rax,%rdx
    dd1c:	48 c1 ea 10          	shr    $0x10,%rdx
    dd20:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dd24:	48 8b 15 cd 6e 01 00 	mov    0x16ecd(%rip),%rdx        # 24bf8 <fwp_heap+0x13f8>
    dd2b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dd2f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dd33:	4d 85 e4             	test   %r12,%r12
    dd36:	74 3a                	je     dd72 <f0+0x2832>
    dd38:	0f b6 0a             	movzbl (%rdx),%ecx
    dd3b:	80 f9 02             	cmp    $0x2,%cl
    dd3e:	0f 84 fc 01 00 00    	je     df40 <f0+0x2a00>
    dd44:	80 f9 01             	cmp    $0x1,%cl
    dd47:	75 29                	jne    dd72 <f0+0x2832>
    dd49:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dd4c:	0f b7 c0             	movzwl %ax,%eax
    dd4f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dd52:	48 0f af c1          	imul   %rcx,%rax
    dd56:	48 c1 e8 20          	shr    $0x20,%rax
    dd5a:	48 39 d0             	cmp    %rdx,%rax
    dd5d:	73 13                	jae    dd72 <f0+0x2832>
    dd5f:	49 01 c4             	add    %rax,%r12
    dd62:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dd67:	0f 84 d1 02 00 00    	je     e03e <f0+0x2afe>
    dd6d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dd72:	48 89 de             	mov    %rbx,%rsi
    dd75:	48 89 ef             	mov    %rbp,%rdi
    dd78:	e8 73 cb ff ff       	call   a8f0 <fwp_hof0.constprop.0>
    dd7d:	48 89 ef             	mov    %rbp,%rdi
    dd80:	e8 db 8d ff ff       	call   6b60 <fwp_drop0>
    dd85:	48 89 df             	mov    %rbx,%rdi
    dd88:	e8 d3 8d ff ff       	call   6b60 <fwp_drop0>
    dd8d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    dd94:	00 
    dd95:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    dd9c:	00 00 
    dd9e:	0f 85 95 04 00 00    	jne    e239 <f0+0x2cf9>
    dda4:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    ddab:	31 c0                	xor    %eax,%eax
    ddad:	5b                   	pop    %rbx
    ddae:	5d                   	pop    %rbp
    ddaf:	41 5c                	pop    %r12
    ddb1:	41 5d                	pop    %r13
    ddb3:	41 5e                	pop    %r14
    ddb5:	c3                   	ret
    ddb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ddbd:	00 00 00 
    ddc0:	4c 89 ef             	mov    %r13,%rdi
    ddc3:	e8 e8 77 ff ff       	call   55b0 <fwp_rc_forget_slot>
    ddc8:	e9 2c d8 ff ff       	jmp    b5f9 <f0+0xb9>
    ddcd:	0f 1f 00             	nopl   (%rax)
    ddd0:	66 85 c0             	test   %ax,%ax
    ddd3:	0f 85 ae f5 ff ff    	jne    d387 <f0+0x1e47>
    ddd9:	e9 99 f5 ff ff       	jmp    d377 <f0+0x1e37>
    ddde:	66 90                	xchg   %ax,%ax
    dde0:	66 85 c0             	test   %ax,%ax
    dde3:	0f 85 ff f4 ff ff    	jne    d2e8 <f0+0x1da8>
    dde9:	e9 ea f4 ff ff       	jmp    d2d8 <f0+0x1d98>
    ddee:	66 90                	xchg   %ax,%ax
    ddf0:	66 85 c0             	test   %ax,%ax
    ddf3:	0f 85 50 f4 ff ff    	jne    d249 <f0+0x1d09>
    ddf9:	e9 3b f4 ff ff       	jmp    d239 <f0+0x1cf9>
    ddfe:	66 90                	xchg   %ax,%ax
    de00:	66 85 c0             	test   %ax,%ax
    de03:	0f 85 a1 f3 ff ff    	jne    d1aa <f0+0x1c6a>
    de09:	e9 8c f3 ff ff       	jmp    d19a <f0+0x1c5a>
    de0e:	66 90                	xchg   %ax,%ax
    de10:	66 85 c0             	test   %ax,%ax
    de13:	0f 85 f2 f2 ff ff    	jne    d10b <f0+0x1bcb>
    de19:	e9 dd f2 ff ff       	jmp    d0fb <f0+0x1bbb>
    de1e:	66 90                	xchg   %ax,%ax
    de20:	66 85 c0             	test   %ax,%ax
    de23:	0f 85 43 f2 ff ff    	jne    d06c <f0+0x1b2c>
    de29:	e9 2e f2 ff ff       	jmp    d05c <f0+0x1b1c>
    de2e:	66 90                	xchg   %ax,%ax
    de30:	66 85 c0             	test   %ax,%ax
    de33:	0f 85 94 f1 ff ff    	jne    cfcd <f0+0x1a8d>
    de39:	e9 7f f1 ff ff       	jmp    cfbd <f0+0x1a7d>
    de3e:	66 90                	xchg   %ax,%ax
    de40:	66 85 c0             	test   %ax,%ax
    de43:	0f 85 e5 f0 ff ff    	jne    cf2e <f0+0x19ee>
    de49:	e9 d0 f0 ff ff       	jmp    cf1e <f0+0x19de>
    de4e:	66 90                	xchg   %ax,%ax
    de50:	66 85 c0             	test   %ax,%ax
    de53:	0f 85 fd d9 ff ff    	jne    b856 <f0+0x316>
    de59:	e9 e8 d9 ff ff       	jmp    b846 <f0+0x306>
    de5e:	66 90                	xchg   %ax,%ax
    de60:	66 85 c0             	test   %ax,%ax
    de63:	0f 85 57 d9 ff ff    	jne    b7c0 <f0+0x280>
    de69:	e9 42 d9 ff ff       	jmp    b7b0 <f0+0x270>
    de6e:	66 90                	xchg   %ax,%ax
    de70:	66 85 c0             	test   %ax,%ax
    de73:	0f 85 b1 d8 ff ff    	jne    b72a <f0+0x1ea>
    de79:	e9 9c d8 ff ff       	jmp    b71a <f0+0x1da>
    de7e:	66 90                	xchg   %ax,%ax
    de80:	66 85 c0             	test   %ax,%ax
    de83:	0f 85 0e eb ff ff    	jne    c997 <f0+0x1457>
    de89:	e9 f9 ea ff ff       	jmp    c987 <f0+0x1447>
    de8e:	66 90                	xchg   %ax,%ax
    de90:	66 85 c0             	test   %ax,%ax
    de93:	0f 85 5f ea ff ff    	jne    c8f8 <f0+0x13b8>
    de99:	e9 4a ea ff ff       	jmp    c8e8 <f0+0x13a8>
    de9e:	66 90                	xchg   %ax,%ax
    dea0:	66 85 c0             	test   %ax,%ax
    dea3:	0f 85 e2 da ff ff    	jne    b98b <f0+0x44b>
    dea9:	e9 cd da ff ff       	jmp    b97b <f0+0x43b>
    deae:	66 90                	xchg   %ax,%ax
    deb0:	66 85 c0             	test   %ax,%ax
    deb3:	0f 85 33 da ff ff    	jne    b8ec <f0+0x3ac>
    deb9:	e9 1e da ff ff       	jmp    b8dc <f0+0x39c>
    debe:	66 90                	xchg   %ax,%ax
    dec0:	66 85 c0             	test   %ax,%ax
    dec3:	0f 85 c6 ef ff ff    	jne    ce8f <f0+0x194f>
    dec9:	e9 b1 ef ff ff       	jmp    ce7f <f0+0x193f>
    dece:	66 90                	xchg   %ax,%ax
    ded0:	66 85 c0             	test   %ax,%ax
    ded3:	0f 85 17 ef ff ff    	jne    cdf0 <f0+0x18b0>
    ded9:	e9 02 ef ff ff       	jmp    cde0 <f0+0x18a0>
    dede:	66 90                	xchg   %ax,%ax
    dee0:	66 85 c0             	test   %ax,%ax
    dee3:	0f 85 68 ee ff ff    	jne    cd51 <f0+0x1811>
    dee9:	e9 53 ee ff ff       	jmp    cd41 <f0+0x1801>
    deee:	66 90                	xchg   %ax,%ax
    def0:	66 85 c0             	test   %ax,%ax
    def3:	0f 85 b9 ed ff ff    	jne    ccb2 <f0+0x1772>
    def9:	e9 a4 ed ff ff       	jmp    cca2 <f0+0x1762>
    defe:	66 90                	xchg   %ax,%ax
    df00:	66 85 c0             	test   %ax,%ax
    df03:	0f 85 0a ed ff ff    	jne    cc13 <f0+0x16d3>
    df09:	e9 f5 ec ff ff       	jmp    cc03 <f0+0x16c3>
    df0e:	66 90                	xchg   %ax,%ax
    df10:	66 85 c0             	test   %ax,%ax
    df13:	0f 85 5b ec ff ff    	jne    cb74 <f0+0x1634>
    df19:	e9 46 ec ff ff       	jmp    cb64 <f0+0x1624>
    df1e:	66 90                	xchg   %ax,%ax
    df20:	66 85 c0             	test   %ax,%ax
    df23:	0f 85 ac eb ff ff    	jne    cad5 <f0+0x1595>
    df29:	e9 97 eb ff ff       	jmp    cac5 <f0+0x1585>
    df2e:	66 90                	xchg   %ax,%ax
    df30:	66 85 c0             	test   %ax,%ax
    df33:	0f 85 fd ea ff ff    	jne    ca36 <f0+0x14f6>
    df39:	e9 e8 ea ff ff       	jmp    ca26 <f0+0x14e6>
    df3e:	66 90                	xchg   %ax,%ax
    df40:	66 85 c0             	test   %ax,%ax
    df43:	0f 85 29 fe ff ff    	jne    dd72 <f0+0x2832>
    df49:	e9 14 fe ff ff       	jmp    dd62 <f0+0x2822>
    df4e:	66 90                	xchg   %ax,%ax
    df50:	66 85 c0             	test   %ax,%ax
    df53:	0f 85 7f fd ff ff    	jne    dcd8 <f0+0x2798>
    df59:	e9 6a fd ff ff       	jmp    dcc8 <f0+0x2788>
    df5e:	66 90                	xchg   %ax,%ax
    df60:	66 85 c0             	test   %ax,%ax
    df63:	0f 85 d0 fc ff ff    	jne    dc39 <f0+0x26f9>
    df69:	e9 bb fc ff ff       	jmp    dc29 <f0+0x26e9>
    df6e:	66 90                	xchg   %ax,%ax
    df70:	66 85 c0             	test   %ax,%ax
    df73:	0f 85 21 fc ff ff    	jne    db9a <f0+0x265a>
    df79:	e9 0c fc ff ff       	jmp    db8a <f0+0x264a>
    df7e:	66 90                	xchg   %ax,%ax
    df80:	66 85 c0             	test   %ax,%ax
    df83:	0f 85 72 fb ff ff    	jne    dafb <f0+0x25bb>
    df89:	e9 5d fb ff ff       	jmp    daeb <f0+0x25ab>
    df8e:	66 90                	xchg   %ax,%ax
    df90:	66 85 c0             	test   %ax,%ax
    df93:	0f 85 c3 fa ff ff    	jne    da5c <f0+0x251c>
    df99:	e9 ae fa ff ff       	jmp    da4c <f0+0x250c>
    df9e:	66 90                	xchg   %ax,%ax
    dfa0:	66 85 c0             	test   %ax,%ax
    dfa3:	0f 85 14 fa ff ff    	jne    d9bd <f0+0x247d>
    dfa9:	e9 ff f9 ff ff       	jmp    d9ad <f0+0x246d>
    dfae:	66 90                	xchg   %ax,%ax
    dfb0:	66 85 c0             	test   %ax,%ax
    dfb3:	0f 85 65 f9 ff ff    	jne    d91e <f0+0x23de>
    dfb9:	e9 50 f9 ff ff       	jmp    d90e <f0+0x23ce>
    dfbe:	66 90                	xchg   %ax,%ax
    dfc0:	66 85 c0             	test   %ax,%ax
    dfc3:	0f 85 b6 f8 ff ff    	jne    d87f <f0+0x233f>
    dfc9:	e9 a1 f8 ff ff       	jmp    d86f <f0+0x232f>
    dfce:	66 90                	xchg   %ax,%ax
    dfd0:	66 85 c0             	test   %ax,%ax
    dfd3:	0f 85 07 f8 ff ff    	jne    d7e0 <f0+0x22a0>
    dfd9:	e9 f2 f7 ff ff       	jmp    d7d0 <f0+0x2290>
    dfde:	66 90                	xchg   %ax,%ax
    dfe0:	66 85 c0             	test   %ax,%ax
    dfe3:	0f 85 58 f7 ff ff    	jne    d741 <f0+0x2201>
    dfe9:	e9 43 f7 ff ff       	jmp    d731 <f0+0x21f1>
    dfee:	66 90                	xchg   %ax,%ax
    dff0:	66 85 c0             	test   %ax,%ax
    dff3:	0f 85 a9 f6 ff ff    	jne    d6a2 <f0+0x2162>
    dff9:	e9 94 f6 ff ff       	jmp    d692 <f0+0x2152>
    dffe:	66 90                	xchg   %ax,%ax
    e000:	66 85 c0             	test   %ax,%ax
    e003:	0f 85 fa f5 ff ff    	jne    d603 <f0+0x20c3>
    e009:	e9 e5 f5 ff ff       	jmp    d5f3 <f0+0x20b3>
    e00e:	66 90                	xchg   %ax,%ax
    e010:	66 85 c0             	test   %ax,%ax
    e013:	0f 85 4b f5 ff ff    	jne    d564 <f0+0x2024>
    e019:	e9 36 f5 ff ff       	jmp    d554 <f0+0x2014>
    e01e:	66 90                	xchg   %ax,%ax
    e020:	66 85 c0             	test   %ax,%ax
    e023:	0f 85 9c f4 ff ff    	jne    d4c5 <f0+0x1f85>
    e029:	e9 87 f4 ff ff       	jmp    d4b5 <f0+0x1f75>
    e02e:	66 90                	xchg   %ax,%ax
    e030:	66 85 c0             	test   %ax,%ax
    e033:	0f 85 ed f3 ff ff    	jne    d426 <f0+0x1ee6>
    e039:	e9 d8 f3 ff ff       	jmp    d416 <f0+0x1ed6>
    e03e:	4c 89 e7             	mov    %r12,%rdi
    e041:	e8 6a 75 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e046:	e9 22 fd ff ff       	jmp    dd6d <f0+0x282d>
    e04b:	4c 89 e7             	mov    %r12,%rdi
    e04e:	e8 5d 75 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e053:	e9 cd d6 ff ff       	jmp    b725 <f0+0x1e5>
    e058:	4c 89 e7             	mov    %r12,%rdi
    e05b:	e8 50 75 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e060:	e9 56 d7 ff ff       	jmp    b7bb <f0+0x27b>
    e065:	4c 89 e7             	mov    %r12,%rdi
    e068:	e8 43 75 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e06d:	e9 df d7 ff ff       	jmp    b851 <f0+0x311>
    e072:	4c 89 e7             	mov    %r12,%rdi
    e075:	e8 36 75 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e07a:	e9 68 d8 ff ff       	jmp    b8e7 <f0+0x3a7>
    e07f:	4c 89 e7             	mov    %r12,%rdi
    e082:	e8 29 75 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e087:	e9 fa d8 ff ff       	jmp    b986 <f0+0x446>
    e08c:	4c 89 e7             	mov    %r12,%rdi
    e08f:	e8 1c 75 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e094:	e9 5a e8 ff ff       	jmp    c8f3 <f0+0x13b3>
    e099:	4c 89 e7             	mov    %r12,%rdi
    e09c:	e8 0f 75 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e0a1:	e9 ec e8 ff ff       	jmp    c992 <f0+0x1452>
    e0a6:	4c 89 e7             	mov    %r12,%rdi
    e0a9:	e8 02 75 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e0ae:	e9 7e e9 ff ff       	jmp    ca31 <f0+0x14f1>
    e0b3:	4c 89 e7             	mov    %r12,%rdi
    e0b6:	e8 f5 74 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e0bb:	e9 10 ea ff ff       	jmp    cad0 <f0+0x1590>
    e0c0:	4c 89 e7             	mov    %r12,%rdi
    e0c3:	e8 e8 74 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e0c8:	e9 a2 ea ff ff       	jmp    cb6f <f0+0x162f>
    e0cd:	4c 89 e7             	mov    %r12,%rdi
    e0d0:	e8 db 74 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e0d5:	e9 34 eb ff ff       	jmp    cc0e <f0+0x16ce>
    e0da:	4c 89 e7             	mov    %r12,%rdi
    e0dd:	e8 ce 74 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e0e2:	e9 c6 eb ff ff       	jmp    ccad <f0+0x176d>
    e0e7:	4c 89 e7             	mov    %r12,%rdi
    e0ea:	e8 c1 74 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e0ef:	e9 58 ec ff ff       	jmp    cd4c <f0+0x180c>
    e0f4:	4c 89 e7             	mov    %r12,%rdi
    e0f7:	e8 b4 74 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e0fc:	e9 ea ec ff ff       	jmp    cdeb <f0+0x18ab>
    e101:	4c 89 e7             	mov    %r12,%rdi
    e104:	e8 a7 74 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e109:	e9 7c ed ff ff       	jmp    ce8a <f0+0x194a>
    e10e:	4c 89 e7             	mov    %r12,%rdi
    e111:	e8 9a 74 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e116:	e9 0e ee ff ff       	jmp    cf29 <f0+0x19e9>
    e11b:	4c 89 e7             	mov    %r12,%rdi
    e11e:	e8 8d 74 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e123:	e9 a0 ee ff ff       	jmp    cfc8 <f0+0x1a88>
    e128:	4c 89 e7             	mov    %r12,%rdi
    e12b:	e8 80 74 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e130:	e9 32 ef ff ff       	jmp    d067 <f0+0x1b27>
    e135:	4c 89 e7             	mov    %r12,%rdi
    e138:	e8 73 74 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e13d:	e9 c4 ef ff ff       	jmp    d106 <f0+0x1bc6>
    e142:	4c 89 e7             	mov    %r12,%rdi
    e145:	e8 66 74 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e14a:	e9 56 f0 ff ff       	jmp    d1a5 <f0+0x1c65>
    e14f:	4c 89 e7             	mov    %r12,%rdi
    e152:	e8 59 74 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e157:	e9 e8 f0 ff ff       	jmp    d244 <f0+0x1d04>
    e15c:	4c 89 e7             	mov    %r12,%rdi
    e15f:	e8 4c 74 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e164:	e9 7a f1 ff ff       	jmp    d2e3 <f0+0x1da3>
    e169:	4c 89 e7             	mov    %r12,%rdi
    e16c:	e8 3f 74 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e171:	e9 0c f2 ff ff       	jmp    d382 <f0+0x1e42>
    e176:	4c 89 e7             	mov    %r12,%rdi
    e179:	e8 32 74 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e17e:	e9 9e f2 ff ff       	jmp    d421 <f0+0x1ee1>
    e183:	4c 89 e7             	mov    %r12,%rdi
    e186:	e8 25 74 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e18b:	e9 30 f3 ff ff       	jmp    d4c0 <f0+0x1f80>
    e190:	4c 89 e7             	mov    %r12,%rdi
    e193:	e8 18 74 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e198:	e9 c2 f3 ff ff       	jmp    d55f <f0+0x201f>
    e19d:	4c 89 e7             	mov    %r12,%rdi
    e1a0:	e8 0b 74 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e1a5:	e9 54 f4 ff ff       	jmp    d5fe <f0+0x20be>
    e1aa:	4c 89 e7             	mov    %r12,%rdi
    e1ad:	e8 fe 73 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e1b2:	e9 e6 f4 ff ff       	jmp    d69d <f0+0x215d>
    e1b7:	4c 89 e7             	mov    %r12,%rdi
    e1ba:	e8 f1 73 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e1bf:	e9 78 f5 ff ff       	jmp    d73c <f0+0x21fc>
    e1c4:	4c 89 e7             	mov    %r12,%rdi
    e1c7:	e8 e4 73 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e1cc:	e9 0a f6 ff ff       	jmp    d7db <f0+0x229b>
    e1d1:	4c 89 e7             	mov    %r12,%rdi
    e1d4:	e8 d7 73 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e1d9:	e9 9c f6 ff ff       	jmp    d87a <f0+0x233a>
    e1de:	4c 89 e7             	mov    %r12,%rdi
    e1e1:	e8 ca 73 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e1e6:	e9 2e f7 ff ff       	jmp    d919 <f0+0x23d9>
    e1eb:	4c 89 e7             	mov    %r12,%rdi
    e1ee:	e8 bd 73 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e1f3:	e9 c0 f7 ff ff       	jmp    d9b8 <f0+0x2478>
    e1f8:	4c 89 e7             	mov    %r12,%rdi
    e1fb:	e8 b0 73 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e200:	e9 52 f8 ff ff       	jmp    da57 <f0+0x2517>
    e205:	4c 89 e7             	mov    %r12,%rdi
    e208:	e8 a3 73 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e20d:	e9 e4 f8 ff ff       	jmp    daf6 <f0+0x25b6>
    e212:	4c 89 e7             	mov    %r12,%rdi
    e215:	e8 96 73 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e21a:	e9 76 f9 ff ff       	jmp    db95 <f0+0x2655>
    e21f:	4c 89 e7             	mov    %r12,%rdi
    e222:	e8 89 73 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e227:	e9 08 fa ff ff       	jmp    dc34 <f0+0x26f4>
    e22c:	4c 89 e7             	mov    %r12,%rdi
    e22f:	e8 7c 73 ff ff       	call   55b0 <fwp_rc_forget_slot>
    e234:	e9 9a fa ff ff       	jmp    dcd3 <f0+0x2793>
    e239:	e8 22 52 ff ff       	call   3460 <__stack_chk_fail@plt>
    e23e:	66 90                	xchg   %ax,%ax

000000000000e240 <fwp_main_thread>:
    e240:	f3 0f 1e fa          	endbr64
    e244:	41 54                	push   %r12
    e246:	55                   	push   %rbp
    e247:	53                   	push   %rbx
    e248:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    e24f:	8b 35 4f 69 01 00    	mov    0x1694f(%rip),%esi        # 24ba4 <fwp_heap+0x13a4>
    e255:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    e25c:	00 00 
    e25e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    e265:	00 
    e266:	31 c0                	xor    %eax,%eax
    e268:	85 f6                	test   %esi,%esi
    e26a:	0f 84 a8 06 00 00    	je     e918 <fwp_main_thread+0x6d8>
    e270:	8b 0d 32 69 01 00    	mov    0x16932(%rip),%ecx        # 24ba8 <fwp_heap+0x13a8>
    e276:	85 c9                	test   %ecx,%ecx
    e278:	0f 85 82 06 00 00    	jne    e900 <fwp_main_thread+0x6c0>
    e27e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    e283:	31 f6                	xor    %esi,%esi
    e285:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    e28a:	48 c7 05 fb 4e 01 00 	movq   $0x40000000,0x14efb(%rip)        # 23190 <fwp_main_stack_size>
    e291:	00 00 00 40 
    e295:	48 89 05 fc 4e 01 00 	mov    %rax,0x14efc(%rip)        # 23198 <fwp_main_stack_top>
    e29c:	48 8d 05 1d 4e 00 00 	lea    0x4e1d(%rip),%rax        # 130c0 <alt.9>
    e2a3:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    e2a8:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    e2af:	01 00 
    e2b1:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    e2b8:	00 
    e2b9:	e8 02 54 ff ff       	call   36c0 <sigaltstack@plt>
    e2be:	85 c0                	test   %eax,%eax
    e2c0:	0f 85 8a 06 00 00    	jne    e950 <fwp_main_thread+0x710>
    e2c6:	31 c0                	xor    %eax,%eax
    e2c8:	b9 12 00 00 00       	mov    $0x12,%ecx
    e2cd:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e2d2:	f3 48 ab             	rep stos %rax,(%rdi)
    e2d5:	48 8d 05 14 5a ff ff 	lea    -0xa5ec(%rip),%rax        # 3cf0 <fwp_segv>
    e2dc:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e2e1:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    e2e8:	04 00 00 08 
    e2ec:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    e2f1:	e8 8a 52 ff ff       	call   3580 <sigemptyset@plt>
    e2f6:	85 c0                	test   %eax,%eax
    e2f8:	0f 85 52 06 00 00    	jne    e950 <fwp_main_thread+0x710>
    e2fe:	31 d2                	xor    %edx,%edx
    e300:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e305:	bf 0b 00 00 00       	mov    $0xb,%edi
    e30a:	e8 f1 50 ff ff       	call   3400 <sigaction@plt>
    e30f:	85 c0                	test   %eax,%eax
    e311:	0f 85 39 06 00 00    	jne    e950 <fwp_main_thread+0x710>
    e317:	31 d2                	xor    %edx,%edx
    e319:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e31e:	bf 07 00 00 00       	mov    $0x7,%edi
    e323:	e8 d8 50 ff ff       	call   3400 <sigaction@plt>
    e328:	85 c0                	test   %eax,%eax
    e32a:	0f 85 20 06 00 00    	jne    e950 <fwp_main_thread+0x710>
    e330:	8b 15 02 4e 01 00    	mov    0x14e02(%rip),%edx        # 23138 <descent_registered>
    e336:	85 d2                	test   %edx,%edx
    e338:	0f 84 72 05 00 00    	je     e8b0 <fwp_main_thread+0x670>
    e33e:	8b 05 6c 4d 00 00    	mov    0x4d6c(%rip),%eax        # 130b0 <st.7>
    e344:	85 c0                	test   %eax,%eax
    e346:	0f 84 90 05 00 00    	je     e8dc <fwp_main_thread+0x69c>
    e34c:	48 8b 2d 8d 54 01 00 	mov    0x1548d(%rip),%rbp        # 237e0 <fwp_cur>
    e353:	48 85 ed             	test   %rbp,%rbp
    e356:	0f 84 74 03 00 00    	je     e6d0 <fwp_main_thread+0x490>
    e35c:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    e361:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    e365:	48 89 eb             	mov    %rbp,%rbx
    e368:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e36d:	0f 84 41 01 00 00    	je     e4b4 <fwp_main_thread+0x274>
    e373:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    e378:	0f 84 82 02 00 00    	je     e600 <fwp_main_thread+0x3c0>
    e37e:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e382:	0f 84 68 02 00 00    	je     e5f0 <fwp_main_thread+0x3b0>
    e388:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e38c:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e390:	0f 85 ea 02 00 00    	jne    e680 <fwp_main_thread+0x440>
    e396:	48 8b 43 60          	mov    0x60(%rbx),%rax
    e39a:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e3a1:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e3a5:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e3ac:	00 00 00 00 
    e3b0:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e3b7:	48 85 d2             	test   %rdx,%rdx
    e3ba:	74 07                	je     e3c3 <fwp_main_thread+0x183>
    e3bc:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e3c3:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e3c7:	48 85 c0             	test   %rax,%rax
    e3ca:	74 34                	je     e400 <fwp_main_thread+0x1c0>
    e3cc:	48 89 43 68          	mov    %rax,0x68(%rbx)
    e3d0:	48 8b 05 e1 53 01 00 	mov    0x153e1(%rip),%rax        # 237b8 <fwp_timers>
    e3d7:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    e3db:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    e3e2:	00 00 00 00 
    e3e6:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    e3ed:	48 85 c0             	test   %rax,%rax
    e3f0:	74 07                	je     e3f9 <fwp_main_thread+0x1b9>
    e3f2:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    e3f9:	48 89 1d b8 53 01 00 	mov    %rbx,0x153b8(%rip)        # 237b8 <fwp_timers>
    e400:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    e404:	e8 a7 91 ff ff       	call   75b0 <fwp_block>
    e409:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    e410:	48 85 c9             	test   %rcx,%rcx
    e413:	74 47                	je     e45c <fwp_main_thread+0x21c>
    e415:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    e41c:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e423:	48 85 d2             	test   %rdx,%rdx
    e426:	0f 84 94 02 00 00    	je     e6c0 <fwp_main_thread+0x480>
    e42c:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    e433:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e43a:	48 85 c0             	test   %rax,%rax
    e43d:	74 07                	je     e446 <fwp_main_thread+0x206>
    e43f:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    e446:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    e44d:	00 00 00 00 
    e451:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e455:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    e45c:	48 8b 0d 7d 53 01 00 	mov    0x1537d(%rip),%rcx        # 237e0 <fwp_cur>
    e463:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    e467:	0f 84 03 02 00 00    	je     e670 <fwp_main_thread+0x430>
    e46d:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    e474:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    e47b:	48 85 d2             	test   %rdx,%rdx
    e47e:	0f 84 fc 03 00 00    	je     e880 <fwp_main_thread+0x640>
    e484:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    e48b:	48 85 c0             	test   %rax,%rax
    e48e:	74 07                	je     e497 <fwp_main_thread+0x257>
    e490:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    e497:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e49b:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    e49f:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    e4a6:	48 89 cb             	mov    %rcx,%rbx
    e4a9:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e4ae:	0f 85 bf fe ff ff    	jne    e373 <fwp_main_thread+0x133>
    e4b4:	48 83 3d bc 6f 01 00 	cmpq   $0x0,0x16fbc(%rip)        # 25478 <fwp_state_len>
    e4bb:	00 
    e4bc:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    e4c0:	0f 84 bc 00 00 00    	je     e582 <fwp_main_thread+0x342>
    e4c6:	48 39 1d 0b 53 01 00 	cmp    %rbx,0x1530b(%rip)        # 237d8 <fwp_root>
    e4cd:	c7 05 e9 4b 01 00 00 	movl   $0x0,0x14be9(%rip)        # 230c0 <fwp_exit_code>
    e4d4:	00 00 00 
    e4d7:	0f 85 91 04 00 00    	jne    e96e <fwp_main_thread+0x72e>
    e4dd:	48 85 db             	test   %rbx,%rbx
    e4e0:	0f 84 10 02 00 00    	je     e6f6 <fwp_main_thread+0x4b6>
    e4e6:	48 8b 15 bb 52 01 00 	mov    0x152bb(%rip),%rdx        # 237a8 <fwp_tasks_active>
    e4ed:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    e4f1:	48 85 d2             	test   %rdx,%rdx
    e4f4:	0f 84 fc 01 00 00    	je     e6f6 <fwp_main_thread+0x4b6>
    e4fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e500:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    e504:	75 08                	jne    e50e <fwp_main_thread+0x2ce>
    e506:	48 89 d7             	mov    %rdx,%rdi
    e509:	e8 f2 5d ff ff       	call   4300 <fwp_cancel_tree.part.0>
    e50e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    e515:	48 85 d2             	test   %rdx,%rdx
    e518:	75 e6                	jne    e500 <fwp_main_thread+0x2c0>
    e51a:	eb 31                	jmp    e54d <fwp_main_thread+0x30d>
    e51c:	0f 1f 40 00          	nopl   0x0(%rax)
    e520:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    e527:	48 89 1d 92 52 01 00 	mov    %rbx,0x15292(%rip)        # 237c0 <fwp_ready_tail>
    e52e:	e8 7d 90 ff ff       	call   75b0 <fwp_block>
    e533:	e8 78 8e ff ff       	call   73b0 <fwp_free_zombie>
    e538:	48 83 3d 68 52 01 00 	cmpq   $0x0,0x15268(%rip)        # 237a8 <fwp_tasks_active>
    e53f:	00 
    e540:	0f 84 b0 01 00 00    	je     e6f6 <fwp_main_thread+0x4b6>
    e546:	48 8b 1d 8b 52 01 00 	mov    0x1528b(%rip),%rbx        # 237d8 <fwp_root>
    e54d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    e551:	75 db                	jne    e52e <fwp_main_thread+0x2ee>
    e553:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    e557:	75 d5                	jne    e52e <fwp_main_thread+0x2ee>
    e559:	48 8b 05 60 52 01 00 	mov    0x15260(%rip),%rax        # 237c0 <fwp_ready_tail>
    e560:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    e564:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    e56b:	00 00 00 00 
    e56f:	48 85 c0             	test   %rax,%rax
    e572:	75 ac                	jne    e520 <fwp_main_thread+0x2e0>
    e574:	48 89 1d 4d 52 01 00 	mov    %rbx,0x1524d(%rip)        # 237c8 <fwp_ready_head>
    e57b:	eb aa                	jmp    e527 <fwp_main_thread+0x2e7>
    e57d:	0f 1f 00             	nopl   (%rax)
    e580:	31 db                	xor    %ebx,%ebx
    e582:	48 83 3d de 6e 01 00 	cmpq   $0x0,0x16ede(%rip)        # 25468 <fwp_state_owners>
    e589:	00 
    e58a:	0f 85 36 ff ff ff    	jne    e4c6 <fwp_main_thread+0x286>
    e590:	48 8b 3d e9 6e 01 00 	mov    0x16ee9(%rip),%rdi        # 25480 <fwp_state>
    e597:	e8 54 72 ff ff       	call   57f0 <fwp_mem_free>
    e59c:	48 c7 05 d9 6e 01 00 	movq   $0x0,0x16ed9(%rip)        # 25480 <fwp_state>
    e5a3:	00 00 00 00 
    e5a7:	48 c7 05 be 6e 01 00 	movq   $0x0,0x16ebe(%rip)        # 25470 <fwp_state_cap>
    e5ae:	00 00 00 00 
    e5b2:	48 85 db             	test   %rbx,%rbx
    e5b5:	0f 84 76 03 00 00    	je     e931 <fwp_main_thread+0x6f1>
    e5bb:	48 39 1d 16 52 01 00 	cmp    %rbx,0x15216(%rip)        # 237d8 <fwp_root>
    e5c2:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    e5c9:	00 00 00 00 
    e5cd:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    e5d4:	00 00 00 00 
    e5d8:	c7 05 de 4a 01 00 00 	movl   $0x0,0x14ade(%rip)        # 230c0 <fwp_exit_code>
    e5df:	00 00 00 
    e5e2:	0f 84 fe fe ff ff    	je     e4e6 <fwp_main_thread+0x2a6>
    e5e8:	e9 63 51 ff ff       	jmp    3750 <fwp_main_thread.cold>
    e5ed:	0f 1f 00             	nopl   (%rax)
    e5f0:	e8 6b 5f ff ff       	call   4560 <fwp_now_ns>
    e5f5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    e5f9:	0f 8d 91 02 00 00    	jge    e890 <fwp_main_thread+0x650>
    e5ff:	90                   	nop
    e600:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e604:	0f 85 7e fd ff ff    	jne    e388 <fwp_main_thread+0x148>
    e60a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    e60e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e612:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e616:	0f 85 7e fd ff ff    	jne    e39a <fwp_main_thread+0x15a>
    e61c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    e620:	48 85 c9             	test   %rcx,%rcx
    e623:	0f 84 71 fd ff ff    	je     e39a <fwp_main_thread+0x15a>
    e629:	48 85 c0             	test   %rax,%rax
    e62c:	0f 84 2f 03 00 00    	je     e961 <fwp_main_thread+0x721>
    e632:	48 39 c8             	cmp    %rcx,%rax
    e635:	48 0f 4f c1          	cmovg  %rcx,%rax
    e639:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e640:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e644:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e64b:	00 00 00 00 
    e64f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e656:	48 85 d2             	test   %rdx,%rdx
    e659:	74 07                	je     e662 <fwp_main_thread+0x422>
    e65b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e662:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e666:	e9 61 fd ff ff       	jmp    e3cc <fwp_main_thread+0x18c>
    e66b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e670:	48 89 cb             	mov    %rcx,%rbx
    e673:	e9 f0 fc ff ff       	jmp    e368 <fwp_main_thread+0x128>
    e678:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e67f:	00 
    e680:	48 8b 45 40          	mov    0x40(%rbp),%rax
    e684:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e68b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e692:	00 00 00 00 
    e696:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    e69d:	48 85 c0             	test   %rax,%rax
    e6a0:	0f 84 82 02 00 00    	je     e928 <fwp_main_thread+0x6e8>
    e6a6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    e6ad:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e6b1:	e9 4a fd ff ff       	jmp    e400 <fwp_main_thread+0x1c0>
    e6b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e6bd:	00 00 00 
    e6c0:	48 89 01             	mov    %rax,(%rcx)
    e6c3:	e9 72 fd ff ff       	jmp    e43a <fwp_main_thread+0x1fa>
    e6c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e6cf:	00 
    e6d0:	48 83 3d a0 6d 01 00 	cmpq   $0x0,0x16da0(%rip)        # 25478 <fwp_state_len>
    e6d7:	00 
    e6d8:	0f 84 a2 fe ff ff    	je     e580 <fwp_main_thread+0x340>
    e6de:	48 83 3d f2 50 01 00 	cmpq   $0x0,0x150f2(%rip)        # 237d8 <fwp_root>
    e6e5:	00 
    e6e6:	c7 05 d0 49 01 00 00 	movl   $0x0,0x149d0(%rip)        # 230c0 <fwp_exit_code>
    e6ed:	00 00 00 
    e6f0:	0f 85 7d 02 00 00    	jne    e973 <fwp_main_thread+0x733>
    e6f6:	e8 b5 8c ff ff       	call   73b0 <fwp_free_zombie>
    e6fb:	48 83 3d c5 50 01 00 	cmpq   $0x0,0x150c5(%rip)        # 237c8 <fwp_ready_head>
    e702:	00 
    e703:	0f 85 47 50 ff ff    	jne    3750 <fwp_main_thread.cold>
    e709:	48 83 3d a7 50 01 00 	cmpq   $0x0,0x150a7(%rip)        # 237b8 <fwp_timers>
    e710:	00 
    e711:	0f 85 39 50 ff ff    	jne    3750 <fwp_main_thread.cold>
    e717:	8b 1d 87 4a 01 00    	mov    0x14a87(%rip),%ebx        # 231a4 <fwp_stack_pool_n>
    e71d:	85 db                	test   %ebx,%ebx
    e71f:	74 36                	je     e757 <fwp_main_thread+0x517>
    e721:	83 eb 01             	sub    $0x1,%ebx
    e724:	48 8d 05 95 4a 01 00 	lea    0x14a95(%rip),%rax        # 231c0 <fwp_stack_pool>
    e72b:	48 63 d3             	movslq %ebx,%rdx
    e72e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    e732:	eb 07                	jmp    e73b <fwp_main_thread+0x4fb>
    e734:	0f 1f 40 00          	nopl   0x0(%rax)
    e738:	83 eb 01             	sub    $0x1,%ebx
    e73b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    e73f:	be 00 00 00 10       	mov    $0x10000000,%esi
    e744:	89 1d 5a 4a 01 00    	mov    %ebx,0x14a5a(%rip)        # 231a4 <fwp_stack_pool_n>
    e74a:	48 83 ed 08          	sub    $0x8,%rbp
    e74e:	e8 8d 4e ff ff       	call   35e0 <munmap@plt>
    e753:	85 db                	test   %ebx,%ebx
    e755:	75 e1                	jne    e738 <fwp_main_thread+0x4f8>
    e757:	8b 3d c7 48 00 00    	mov    0x48c7(%rip),%edi        # 13024 <fwp_epfd>
    e75d:	85 ff                	test   %edi,%edi
    e75f:	78 05                	js     e766 <fwp_main_thread+0x526>
    e761:	e8 6a 4d ff ff       	call   34d0 <close@plt>
    e766:	4c 8b 25 53 4c 01 00 	mov    0x14c53(%rip),%r12        # 233c0 <fwp_nfdws>
    e76d:	48 8b 2d 54 4c 01 00 	mov    0x14c54(%rip),%rbp        # 233c8 <fwp_fdws>
    e774:	31 db                	xor    %ebx,%ebx
    e776:	c7 05 a4 48 00 00 ff 	movl   $0xffffffff,0x48a4(%rip)        # 13024 <fwp_epfd>
    e77d:	ff ff ff 
    e780:	4d 85 e4             	test   %r12,%r12
    e783:	74 38                	je     e7bd <fwp_main_thread+0x57d>
    e785:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    e78c:	00 00 00 00 
    e790:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    e795:	48 85 ff             	test   %rdi,%rdi
    e798:	74 1a                	je     e7b4 <fwp_main_thread+0x574>
    e79a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    e79e:	0f 85 ac 4f ff ff    	jne    3750 <fwp_main_thread.cold>
    e7a4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    e7a9:	0f 85 a1 4f ff ff    	jne    3750 <fwp_main_thread.cold>
    e7af:	e8 3c 70 ff ff       	call   57f0 <fwp_mem_free>
    e7b4:	48 83 c3 01          	add    $0x1,%rbx
    e7b8:	4c 39 e3             	cmp    %r12,%rbx
    e7bb:	75 d3                	jne    e790 <fwp_main_thread+0x550>
    e7bd:	48 89 ef             	mov    %rbp,%rdi
    e7c0:	e8 2b 70 ff ff       	call   57f0 <fwp_mem_free>
    e7c5:	48 8b 15 0c 50 01 00 	mov    0x1500c(%rip),%rdx        # 237d8 <fwp_root>
    e7cc:	48 c7 05 f1 4b 01 00 	movq   $0x0,0x14bf1(%rip)        # 233c8 <fwp_fdws>
    e7d3:	00 00 00 00 
    e7d7:	48 c7 05 de 4b 01 00 	movq   $0x0,0x14bde(%rip)        # 233c0 <fwp_nfdws>
    e7de:	00 00 00 00 
    e7e2:	48 85 d2             	test   %rdx,%rdx
    e7e5:	74 4e                	je     e835 <fwp_main_thread+0x5f5>
    e7e7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    e7ec:	0f 85 5e 4f ff ff    	jne    3750 <fwp_main_thread.cold>
    e7f2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    e7f9:	00 
    e7fa:	0f 85 50 4f ff ff    	jne    3750 <fwp_main_thread.cold>
    e800:	48 83 3d 70 6c 01 00 	cmpq   $0x0,0x16c70(%rip)        # 25478 <fwp_state_len>
    e807:	00 
    e808:	0f 85 42 4f ff ff    	jne    3750 <fwp_main_thread.cold>
    e80e:	48 83 3d 52 6c 01 00 	cmpq   $0x0,0x16c52(%rip)        # 25468 <fwp_state_owners>
    e815:	00 
    e816:	0f 85 34 4f ff ff    	jne    3750 <fwp_main_thread.cold>
    e81c:	b9 79 00 00 00       	mov    $0x79,%ecx
    e821:	31 c0                	xor    %eax,%eax
    e823:	48 8d 3d b6 4b 01 00 	lea    0x14bb6(%rip),%rdi        # 233e0 <fwp_root_context>
    e82a:	f3 48 ab             	rep stos %rax,(%rdi)
    e82d:	48 89 d7             	mov    %rdx,%rdi
    e830:	e8 bb 6f ff ff       	call   57f0 <fwp_mem_free>
    e835:	48 8b 3d 04 48 00 00 	mov    0x4804(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    e83c:	48 c7 05 99 4f 01 00 	movq   $0x0,0x14f99(%rip)        # 237e0 <fwp_cur>
    e843:	00 00 00 00 
    e847:	48 c7 05 86 4f 01 00 	movq   $0x0,0x14f86(%rip)        # 237d8 <fwp_root>
    e84e:	00 00 00 00 
    e852:	e8 69 4d ff ff       	call   35c0 <fflush@plt>
    e857:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    e85e:	00 
    e85f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e866:	00 00 
    e868:	0f 85 fb 00 00 00    	jne    e969 <fwp_main_thread+0x729>
    e86e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    e875:	31 c0                	xor    %eax,%eax
    e877:	5b                   	pop    %rbx
    e878:	5d                   	pop    %rbp
    e879:	41 5c                	pop    %r12
    e87b:	c3                   	ret
    e87c:	0f 1f 40 00          	nopl   0x0(%rax)
    e880:	48 89 05 31 4f 01 00 	mov    %rax,0x14f31(%rip)        # 237b8 <fwp_timers>
    e887:	e9 ff fb ff ff       	jmp    e48b <fwp_main_thread+0x24b>
    e88c:	0f 1f 40 00          	nopl   0x0(%rax)
    e890:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    e894:	0f 85 66 fd ff ff    	jne    e600 <fwp_main_thread+0x3c0>
    e89a:	48 89 ef             	mov    %rbp,%rdi
    e89d:	e8 5e 5a ff ff       	call   4300 <fwp_cancel_tree.part.0>
    e8a2:	e9 59 fd ff ff       	jmp    e600 <fwp_main_thread+0x3c0>
    e8a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e8ae:	00 00 
    e8b0:	48 8d 3d 59 55 ff ff 	lea    -0xaaa7(%rip),%rdi        # 3e10 <descent_phase_report>
    e8b7:	e8 d4 02 00 00       	call   eb90 <atexit>
    e8bc:	85 c0                	test   %eax,%eax
    e8be:	0f 85 98 00 00 00    	jne    e95c <fwp_main_thread+0x71c>
    e8c4:	c7 05 6a 48 01 00 01 	movl   $0x1,0x1486a(%rip)        # 23138 <descent_registered>
    e8cb:	00 00 00 
    e8ce:	8b 05 dc 47 00 00    	mov    0x47dc(%rip),%eax        # 130b0 <st.7>
    e8d4:	85 c0                	test   %eax,%eax
    e8d6:	0f 85 70 fa ff ff    	jne    e34c <fwp_main_thread+0x10c>
    e8dc:	e8 5f cc ff ff       	call   b540 <f0>
    e8e1:	48 c7 05 bc 47 00 00 	movq   $0x0,0x47bc(%rip)        # 130a8 <v.6>
    e8e8:	00 00 00 00 
    e8ec:	c7 05 ba 47 00 00 01 	movl   $0x1,0x47ba(%rip)        # 130b0 <st.7>
    e8f3:	00 00 00 
    e8f6:	e9 51 fa ff ff       	jmp    e34c <fwp_main_thread+0x10c>
    e8fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e900:	48 8d 3d 59 63 ff ff 	lea    -0x9ca7(%rip),%rdi        # 4c60 <fwp_heap_report>
    e907:	e8 84 02 00 00       	call   eb90 <atexit>
    e90c:	e9 6d f9 ff ff       	jmp    e27e <fwp_main_thread+0x3e>
    e911:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    e918:	e8 53 64 ff ff       	call   4d70 <fwp_heap_init>
    e91d:	e9 4e f9 ff ff       	jmp    e270 <fwp_main_thread+0x30>
    e922:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e928:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e92c:	e9 cf fa ff ff       	jmp    e400 <fwp_main_thread+0x1c0>
    e931:	48 83 3d 9f 4e 01 00 	cmpq   $0x0,0x14e9f(%rip)        # 237d8 <fwp_root>
    e938:	00 
    e939:	c7 05 7d 47 01 00 00 	movl   $0x0,0x1477d(%rip)        # 230c0 <fwp_exit_code>
    e940:	00 00 00 
    e943:	0f 84 ad fd ff ff    	je     e6f6 <fwp_main_thread+0x4b6>
    e949:	e9 02 4e ff ff       	jmp    3750 <fwp_main_thread.cold>
    e94e:	66 90                	xchg   %ax,%ax
    e950:	48 8d 3d 89 10 00 00 	lea    0x1089(%rip),%rdi        # f9e0 <_IO_stdin_used+0x9e0>
    e957:	e8 94 5a ff ff       	call   43f0 <fwp_trap>
    e95c:	e8 7f 54 ff ff       	call   3de0 <descent_phase_fail>
    e961:	48 89 c8             	mov    %rcx,%rax
    e964:	e9 d0 fc ff ff       	jmp    e639 <fwp_main_thread+0x3f9>
    e969:	e8 f2 4a ff ff       	call   3460 <__stack_chk_fail@plt>
    e96e:	e9 dd 4d ff ff       	jmp    3750 <fwp_main_thread.cold>
    e973:	e9 d8 4d ff ff       	jmp    3750 <fwp_main_thread.cold>
    e978:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e97f:	00 

000000000000e980 <__divmodti4>:
    e980:	f3 0f 1e fa          	endbr64
    e984:	55                   	push   %rbp
    e985:	49 89 f1             	mov    %rsi,%r9
    e988:	49 89 d2             	mov    %rdx,%r10
    e98b:	48 89 fe             	mov    %rdi,%rsi
    e98e:	49 89 cb             	mov    %rcx,%r11
    e991:	48 89 e5             	mov    %rsp,%rbp
    e994:	41 57                	push   %r15
    e996:	41 56                	push   %r14
    e998:	41 55                	push   %r13
    e99a:	41 54                	push   %r12
    e99c:	53                   	push   %rbx
    e99d:	4c 89 c3             	mov    %r8,%rbx
    e9a0:	45 31 c0             	xor    %r8d,%r8d
    e9a3:	4d 85 c9             	test   %r9,%r9
    e9a6:	79 12                	jns    e9ba <__divmodti4+0x3a>
    e9a8:	31 ff                	xor    %edi,%edi
    e9aa:	48 f7 de             	neg    %rsi
    e9ad:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    e9b4:	4c 19 cf             	sbb    %r9,%rdi
    e9b7:	49 89 f9             	mov    %rdi,%r9
    e9ba:	4c 89 d8             	mov    %r11,%rax
    e9bd:	4d 85 db             	test   %r11,%r11
    e9c0:	0f 88 1a 01 00 00    	js     eae0 <__divmodti4+0x160>
    e9c6:	4c 89 d9             	mov    %r11,%rcx
    e9c9:	49 89 f3             	mov    %rsi,%r11
    e9cc:	75 62                	jne    ea30 <__divmodti4+0xb0>
    e9ce:	4d 89 c4             	mov    %r8,%r12
    e9d1:	4d 39 d1             	cmp    %r10,%r9
    e9d4:	0f 83 46 01 00 00    	jae    eb20 <__divmodti4+0x1a0>
    e9da:	4c 89 d8             	mov    %r11,%rax
    e9dd:	4c 89 ca             	mov    %r9,%rdx
    e9e0:	49 f7 f2             	div    %r10
    e9e3:	49 89 c3             	mov    %rax,%r11
    e9e6:	31 c0                	xor    %eax,%eax
    e9e8:	48 89 d6             	mov    %rdx,%rsi
    e9eb:	31 ff                	xor    %edi,%edi
    e9ed:	4c 89 d9             	mov    %r11,%rcx
    e9f0:	48 89 c2             	mov    %rax,%rdx
    e9f3:	48 89 c8             	mov    %rcx,%rax
    e9f6:	4d 85 e4             	test   %r12,%r12
    e9f9:	74 0a                	je     ea05 <__divmodti4+0x85>
    e9fb:	48 f7 d8             	neg    %rax
    e9fe:	48 83 d2 00          	adc    $0x0,%rdx
    ea02:	48 f7 da             	neg    %rdx
    ea05:	4d 85 c0             	test   %r8,%r8
    ea08:	74 0a                	je     ea14 <__divmodti4+0x94>
    ea0a:	48 f7 de             	neg    %rsi
    ea0d:	48 83 d7 00          	adc    $0x0,%rdi
    ea11:	48 f7 df             	neg    %rdi
    ea14:	48 89 33             	mov    %rsi,(%rbx)
    ea17:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    ea1b:	5b                   	pop    %rbx
    ea1c:	41 5c                	pop    %r12
    ea1e:	41 5d                	pop    %r13
    ea20:	41 5e                	pop    %r14
    ea22:	41 5f                	pop    %r15
    ea24:	5d                   	pop    %rbp
    ea25:	c3                   	ret
    ea26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ea2d:	00 00 00 
    ea30:	4d 89 c4             	mov    %r8,%r12
    ea33:	49 39 c1             	cmp    %rax,%r9
    ea36:	0f 82 ce 00 00 00    	jb     eb0a <__divmodti4+0x18a>
    ea3c:	31 ff                	xor    %edi,%edi
    ea3e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    ea43:	48 63 c7             	movslq %edi,%rax
    ea46:	be 40 00 00 00       	mov    $0x40,%esi
    ea4b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    ea50:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    ea55:	48 29 c6             	sub    %rax,%rsi
    ea58:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    ea5d:	48 09 c8             	or     %rcx,%rax
    ea60:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    ea65:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    ea6a:	49 89 c6             	mov    %rax,%r14
    ea6d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    ea71:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    ea76:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    ea7b:	49 09 c1             	or     %rax,%r9
    ea7e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    ea82:	4c 89 c8             	mov    %r9,%rax
    ea85:	49 f7 f6             	div    %r14
    ea88:	48 89 d1             	mov    %rdx,%rcx
    ea8b:	49 89 c3             	mov    %rax,%r11
    ea8e:	49 89 c1             	mov    %rax,%r9
    ea91:	49 f7 e2             	mul    %r10
    ea94:	49 89 c6             	mov    %rax,%r14
    ea97:	49 89 d2             	mov    %rdx,%r10
    ea9a:	48 39 d1             	cmp    %rdx,%rcx
    ea9d:	72 07                	jb     eaa6 <__divmodti4+0x126>
    ea9f:	75 17                	jne    eab8 <__divmodti4+0x138>
    eaa1:	49 39 c7             	cmp    %rax,%r15
    eaa4:	73 12                	jae    eab8 <__divmodti4+0x138>
    eaa6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    eaaa:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    eaae:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    eab2:	49 89 d2             	mov    %rdx,%r10
    eab5:	49 89 c6             	mov    %rax,%r14
    eab8:	4c 89 f8             	mov    %r15,%rax
    eabb:	4c 29 f0             	sub    %r14,%rax
    eabe:	4c 19 d1             	sbb    %r10,%rcx
    eac1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    eac6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    eacb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    ead0:	48 09 c6             	or     %rax,%rsi
    ead3:	48 89 cf             	mov    %rcx,%rdi
    ead6:	31 c0                	xor    %eax,%eax
    ead8:	4c 89 c9             	mov    %r9,%rcx
    eadb:	e9 10 ff ff ff       	jmp    e9f0 <__divmodti4+0x70>
    eae0:	4c 89 d0             	mov    %r10,%rax
    eae3:	4c 89 da             	mov    %r11,%rdx
    eae6:	4d 89 c4             	mov    %r8,%r12
    eae9:	49 89 f3             	mov    %rsi,%r11
    eaec:	48 f7 d8             	neg    %rax
    eaef:	49 f7 d4             	not    %r12
    eaf2:	48 83 d2 00          	adc    $0x0,%rdx
    eaf6:	49 89 c2             	mov    %rax,%r10
    eaf9:	48 f7 da             	neg    %rdx
    eafc:	48 89 d1             	mov    %rdx,%rcx
    eaff:	0f 84 cc fe ff ff    	je     e9d1 <__divmodti4+0x51>
    eb05:	49 39 d1             	cmp    %rdx,%r9
    eb08:	73 46                	jae    eb50 <__divmodti4+0x1d0>
    eb0a:	4c 89 cf             	mov    %r9,%rdi
    eb0d:	31 c0                	xor    %eax,%eax
    eb0f:	31 c9                	xor    %ecx,%ecx
    eb11:	e9 da fe ff ff       	jmp    e9f0 <__divmodti4+0x70>
    eb16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    eb1d:	00 00 00 
    eb20:	4d 85 d2             	test   %r10,%r10
    eb23:	75 0d                	jne    eb32 <__divmodti4+0x1b2>
    eb25:	b8 01 00 00 00       	mov    $0x1,%eax
    eb2a:	31 d2                	xor    %edx,%edx
    eb2c:	49 f7 f2             	div    %r10
    eb2f:	49 89 c2             	mov    %rax,%r10
    eb32:	4c 89 c8             	mov    %r9,%rax
    eb35:	31 d2                	xor    %edx,%edx
    eb37:	49 f7 f2             	div    %r10
    eb3a:	49 89 c1             	mov    %rax,%r9
    eb3d:	4c 89 d8             	mov    %r11,%rax
    eb40:	49 f7 f2             	div    %r10
    eb43:	49 89 c3             	mov    %rax,%r11
    eb46:	4c 89 c8             	mov    %r9,%rax
    eb49:	e9 9a fe ff ff       	jmp    e9e8 <__divmodti4+0x68>
    eb4e:	66 90                	xchg   %ax,%ax
    eb50:	45 31 f6             	xor    %r14d,%r14d
    eb53:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    eb58:	44 89 f7             	mov    %r14d,%edi
    eb5b:	45 85 f6             	test   %r14d,%r14d
    eb5e:	0f 85 df fe ff ff    	jne    ea43 <__divmodti4+0xc3>
    eb64:	4c 39 ca             	cmp    %r9,%rdx
    eb67:	72 17                	jb     eb80 <__divmodti4+0x200>
    eb69:	31 c9                	xor    %ecx,%ecx
    eb6b:	48 39 c6             	cmp    %rax,%rsi
    eb6e:	73 10                	jae    eb80 <__divmodti4+0x200>
    eb70:	4c 89 cf             	mov    %r9,%rdi
    eb73:	31 c0                	xor    %eax,%eax
    eb75:	e9 76 fe ff ff       	jmp    e9f0 <__divmodti4+0x70>
    eb7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    eb80:	4c 89 de             	mov    %r11,%rsi
    eb83:	b9 01 00 00 00       	mov    $0x1,%ecx
    eb88:	48 29 c6             	sub    %rax,%rsi
    eb8b:	49 19 d1             	sbb    %rdx,%r9
    eb8e:	eb e0                	jmp    eb70 <__divmodti4+0x1f0>

000000000000eb90 <atexit>:
    eb90:	f3 0f 1e fa          	endbr64
    eb94:	48 8b 15 6d 44 00 00 	mov    0x446d(%rip),%rdx        # 13008 <__dso_handle>
    eb9b:	31 f6                	xor    %esi,%esi
    eb9d:	e9 be 4a ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000eba4 <_fini>:
    eba4:	f3 0f 1e fa          	endbr64
    eba8:	48 83 ec 08          	sub    $0x8,%rsp
    ebac:	48 83 c4 08          	add    $0x8,%rsp
    ebb0:	c3                   	ret
