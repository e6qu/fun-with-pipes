
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-reference:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 ff 00 00 	mov    0xffc9(%rip),%rax        # 12fd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 fd 00 00    	push   0xfde2(%rip)        # 12e08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 fd 00 00    	jmp    *0xfde4(%rip)        # 12e10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e fc 00 00    	jmp    *0xfc4e(%rip)        # 12fe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e fa 00 00    	jmp    *0xfa6e(%rip)        # 12e18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12e70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12e78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12e80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12e88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12e90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12e98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12ea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12ea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12eb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12eb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12ec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12ec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12ed0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12ed8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12ee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12ee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12ef0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12ef8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12f00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12f08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12f70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12f78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12f80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12f88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12f90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12f98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 f8 00 00    	jmp    *0xf8e6(%rip)        # 12fa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de f8 00 00    	jmp    *0xf8de(%rip)        # 12fa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 f8 00 00    	jmp    *0xf8d6(%rip)        # 12fb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce f8 00 00    	jmp    *0xf8ce(%rip)        # 12fb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 f8 00 00    	jmp    *0xf8c6(%rip)        # 12fc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a b9 00 00 	lea    0xb97a(%rip),%r9        # f091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 b9 00 00 	lea    0xb977(%rip),%r8        # f095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 dd 00 00 	lea    0xdd01(%rip),%rax        # 11480 <fwp_fn_table>
    377f:	48 89 05 72 1c 02 00 	mov    %rax,0x21c72(%rip)        # 253f8 <fwp_fns>
    3786:	48 8b 05 b3 f8 00 00 	mov    0xf8b3(%rip),%rax        # 13040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 6c 1c 02 00 	mov    %rax,0x21c6c(%rip)        # 25400 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 59 ba 00 00 	lea    0xba59(%rip),%rdi        # f1f9 <_IO_stdin_used+0x1f9>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 f8 00 00 	mov    0xf838(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 9f a7 00 00 	lea    0xa79f(%rip),%rdx        # e000 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 f7 00 00 	mov    0xf7a3(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 18 f8 01 00    	mov    0x1f818(%rip),%eax        # 230c0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 09 b9 00 00 	lea    0xb909(%rip),%rdi        # f202 <_IO_stdin_used+0x202>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 8e c0 00 00 	lea    0xc08e(%rip),%rdi        # f998 <_IO_stdin_used+0x998>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 48 c0 00 00 	lea    0xc048(%rip),%rdi        # f970 <_IO_stdin_used+0x970>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 0c c0 00 00 	lea    0xc00c(%rip),%rdi        # f940 <_IO_stdin_used+0x940>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d d8 bf 00 00 	lea    0xbfd8(%rip),%rdi        # f918 <_IO_stdin_used+0x918>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 f6 00 00    	call   *0xf653(%rip)        # 12fc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 f6 00 00 	lea    0xf6a1(%rip),%rdi        # 13028 <__TMC_END__>
    3987:	48 8d 05 9a f6 00 00 	lea    0xf69a(%rip),%rax        # 13028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 f6 00 00 	mov    0xf636(%rip),%rax        # 12fd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 f6 00 00 	lea    0xf671(%rip),%rdi        # 13028 <__TMC_END__>
    39b7:	48 8d 35 6a f6 00 00 	lea    0xf66a(%rip),%rsi        # 13028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 f6 00 00 	mov    0xf605(%rip),%rax        # 12fe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d f6 00 00 00 	cmpb   $0x0,0xf66d(%rip)        # 13068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 f5 00 00 	cmpq   $0x0,0xf5e2(%rip)        # 12fe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 f6 00 00 01 	movb   $0x1,0xf645(%rip)        # 13068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 0e f5 01 00 	add    0x1f50e(%rip),%rdx        # 23130 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 fc f4 01 00 	add    0x1f4fc(%rip),%rax        # 23130 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 89 17 02 00 	mov    0x21789(%rip),%rdi        # 25400 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d b4 f3 00 00 	mov    0xf3b4(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d a1 f3 00 00 	mov    0xf3a1(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 b3 00 00 	lea    0xb345(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 92 f3 00 00 	mov    0xf392(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 81 fa 01 00 	mov    0x1fa81(%rip),%rax        # 23780 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 c1 f3 01 00 	mov    0x1f3c1(%rip),%rax        # 23140 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 ad f3 01 00 	sub    0x1f3ad(%rip),%rax        # 23138 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 bd bc 00 00 	lea    0xbcbd(%rip),%rsi        # fa80 <msg.8>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 9b 0d 02 00 	mov    0x20d9b(%rip),%rax        # 24b90 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 94 0d 02 00 	lea    0x20d94(%rip),%r8        # 24b90 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 75 0d 02 00 	mov    0x20d75(%rip),%rbx        # 24b78 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 85 0d 02 00 	mov    0x20d85(%rip),%rcx        # 24b98 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d 21 0d 02 00 	mov    0x20d21(%rip),%rdi        # 24b80 <fwp_heap+0x13e0>
    3e5f:	48 29 35 6a 0d 02 00 	sub    %rsi,0x20d6a(%rip)        # 24bd0 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 fa 0c 02 00 	mov    0x20cfa(%rip),%rax        # 24b70 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d b0 0c 02 00 	add    0x20cb0(%rip),%rdi        # 24b50 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 be 0c 02 00 	mov    0x20cbe(%rip),%rsi        # 24b80 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 cc 0c 02 00 	mov    0x20ccc(%rip),%rax        # 24b98 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 7b 0c 02 00 	mov    %r12,0x20c7b(%rip)        # 24b80 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 69 0c 02 00 	mov    %rbp,0x20c69(%rip)        # 24b78 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 4e 0c 02 00 	cmp    %rdi,0x20c4e(%rip)        # 24b68 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 45 0c 02 00 	mov    %rdi,0x20c45(%rip)        # 24b68 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 89 0c 02 00 	sub    %rdi,0x20c89(%rip)        # 24bd0 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 31 0c 02 00 	mov    0x20c31(%rip),%rax        # 24b88 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 2a 0c 02 00 	lea    0x20c2a(%rip),%r8        # 24b88 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d 1d f0 00 00 	mov    0xf01d(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 af 00 00 	lea    0xafb4(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d c9 f6 01 00 	cmp    0x1f6c9(%rip),%rdi        # 23780 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 8f f6 01 00 	mov    0x1f68f(%rip),%rax        # 23760 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 6d f6 01 00 	mov    %rdi,0x1f66d(%rip)        # 23760 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 49 f6 01 00 	mov    %rdi,0x1f649(%rip)        # 23768 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 05 b0 00 00 	lea    0xb005(%rip),%rsi        # f166 <_IO_stdin_used+0x166>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 ae 00 00 	lea    0xaea7(%rip),%rsi        # f01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 98 ee 00 00 	mov    0xee98(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 ae 00 00 	lea    0xae51(%rip),%rdx        # f020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 80 ee 00 00 	mov    0xee80(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 91 ed 00 00 	mov    0xed91(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 ad 00 00 	lea    0xad28(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 ad 00 00 	lea    0xad32(%rip),%rdi        # f02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba ac 00 00 	lea    0xacba(%rip),%rdi        # f049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 68 b2 00 00 	lea    0xb268(%rip),%rdi        # f608 <_IO_stdin_used+0x608>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 e0 b6 00 	movdqa 0xb6e0(%rip),%xmm0        # faa0 <msg.8+0x20>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 da 0f 02 00 	add    0x20fda(%rip),%rax        # 253f8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d c4 b1 00 00 	lea    0xb1c4(%rip),%rdi        # f638 <_IO_stdin_used+0x638>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 95 ec 01 00 	cmp    %rax,0x1ec95(%rip)        # 23128 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 90 ec 01 00 	add    0x1ec90(%rip),%rax        # 23130 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d ad b1 00 00 	lea    0xb1ad(%rip),%rdi        # f668 <_IO_stdin_used+0x668>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 ab 00 00 	lea    0xab92(%rip),%r8        # f065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 a9 00 00 	lea    0xa9e7(%rip),%r8        # f074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 a8 00 00 	lea    0xa874(%rip),%r8        # f06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c a6 00 00 	lea    0xa64c(%rip),%rdi        # f079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 60 a7 00 00 	lea    0xa760(%rip),%rsi        # f1ae <_IO_stdin_used+0x1ae>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d a5 00 02 00 	mov    0x200a5(%rip),%r9        # 24b68 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 fe 00 02 00 	mov    0x200fe(%rip),%r8        # 24bc8 <fwp_heap+0x1428>
    4aca:	48 8d 15 e7 ab 00 00 	lea    0xabe7(%rip),%rdx        # f6b8 <_IO_stdin_used+0x6b8>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d e6 00 02 00 	mov    0x200e6(%rip),%rcx        # 24bc0 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d f4 00 02 	movsd  0x200f4(%rip),%xmm1        # 24be0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 e4 00 02 	movsd  0x200e4(%rip),%xmm0        # 24bd8 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 65 e5 00 00 	mov    0xe565(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 78 af 00 	movdqa 0xaf78(%rip),%xmm0        # fab0 <msg.8+0x30>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 9f fb 01 00 	lea    0x1fb9f(%rip),%rax        # 246e0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 a1 af 00 	movdqa 0xafa1(%rip),%xmm2        # faf0 <msg.8+0x70>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 45 fb 01 00 	movaps %xmm0,0x1fb45(%rip)        # 246a0 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 5d af 00 	movdqa 0xaf5d(%rip),%xmm0        # fac0 <msg.8+0x40>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 d3 ff 01 00 01 	movl   $0x1,0x1ffd3(%rip)        # 24b44 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 33 fb 01 00 	movaps %xmm0,0x1fb33(%rip)        # 246b0 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 4b af 00 	movdqa 0xaf4b(%rip),%xmm0        # fad0 <msg.8+0x50>
    4b84:	00 
    4b85:	0f 29 05 34 fb 01 00 	movaps %xmm0,0x1fb34(%rip)        # 246c0 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 4c af 00 	movdqa 0xaf4c(%rip),%xmm0        # fae0 <msg.8+0x60>
    4b93:	00 
    4b94:	0f 29 05 35 fb 01 00 	movaps %xmm0,0x1fb35(%rip)        # 246d0 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 b5 eb 01 00 	lea    0x1ebb5(%rip),%r8        # 237a0 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 d0 fe 01 00 	mov    %rax,0x1fed0(%rip)        # 24b58 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 ae fe 01 00 	mov    %r12,0x1feae(%rip)        # 24b60 <fwp_heap+0x13c0>
    4cb2:	48 89 05 97 fe 01 00 	mov    %rax,0x1fe97(%rip)        # 24b50 <fwp_heap+0x13b0>
    4cb9:	48 89 1d b0 fe 01 00 	mov    %rbx,0x1feb0(%rip)        # 24b70 <fwp_heap+0x13d0>
    4cc0:	48 89 35 d9 fe 01 00 	mov    %rsi,0x1fed9(%rip)        # 24ba0 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 a3 00 00 	lea    0xa3d6(%rip),%rdi        # f0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 b8 fe 01 00 	mov    %rax,0x1feb8(%rip)        # 24b98 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 3c fe 01 00    	mov    %eax,0x1fe3c(%rip)        # 24b48 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <caf61>:
    4d20:	8b 15 7a e3 00 00    	mov    0xe37a(%rip),%edx        # 130a0 <st.4>
    4d26:	85 d2                	test   %edx,%edx
    4d28:	74 0e                	je     4d38 <caf61+0x18>
    4d2a:	48 8b 05 67 e3 00 00 	mov    0xe367(%rip),%rax        # 13098 <v.3>
    4d31:	c3                   	ret
    4d32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4d38:	8b 05 52 e3 00 00    	mov    0xe352(%rip),%eax        # 13090 <st.2>
    4d3e:	85 c0                	test   %eax,%eax
    4d40:	74 1e                	je     4d60 <caf61+0x40>
    4d42:	48 8b 05 3f e3 00 00 	mov    0xe33f(%rip),%rax        # 13088 <v.1>
    4d49:	48 89 05 48 e3 00 00 	mov    %rax,0xe348(%rip)        # 13098 <v.3>
    4d50:	c7 05 46 e3 00 00 01 	movl   $0x1,0xe346(%rip)        # 130a0 <st.4>
    4d57:	00 00 00 
    4d5a:	c3                   	ret
    4d5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4d60:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    4d67:	00 f0 3f 
    4d6a:	c7 05 1c e3 00 00 01 	movl   $0x1,0xe31c(%rip)        # 13090 <st.2>
    4d71:	00 00 00 
    4d74:	48 89 05 0d e3 00 00 	mov    %rax,0xe30d(%rip)        # 13088 <v.1>
    4d7b:	eb cc                	jmp    4d49 <caf61+0x29>
    4d7d:	0f 1f 00             	nopl   (%rax)

0000000000004d80 <fwp_wake_io>:
    4d80:	48 8b 07             	mov    (%rdi),%rax
    4d83:	48 85 c0             	test   %rax,%rax
    4d86:	0f 84 f4 00 00 00    	je     4e80 <fwp_wake_io+0x100>
    4d8c:	53                   	push   %rbx
    4d8d:	4c 8b 05 cc e9 01 00 	mov    0x1e9cc(%rip),%r8        # 23760 <fwp_ready_tail>
    4d94:	49 89 f9             	mov    %rdi,%r9
    4d97:	48 89 c2             	mov    %rax,%rdx
    4d9a:	45 31 db             	xor    %r11d,%r11d
    4d9d:	45 31 d2             	xor    %r10d,%r10d
    4da0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4da4:	eb 71                	jmp    4e17 <fwp_wake_io+0x97>
    4da6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4dad:	00 00 00 
    4db0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4db7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dbe:	48 85 c9             	test   %rcx,%rcx
    4dc1:	74 07                	je     4dca <fwp_wake_io+0x4a>
    4dc3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4dca:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4dd1:	00 00 00 00 
    4dd5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4ddc:	49 8b 01             	mov    (%r9),%rax
    4ddf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4de3:	75 2a                	jne    4e0f <fwp_wake_io+0x8f>
    4de5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4de9:	75 24                	jne    4e0f <fwp_wake_io+0x8f>
    4deb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4def:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4df6:	00 00 00 00 
    4dfa:	4d 85 c0             	test   %r8,%r8
    4dfd:	74 51                	je     4e50 <fwp_wake_io+0xd0>
    4dff:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4e06:	49 89 d0             	mov    %rdx,%r8
    4e09:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4e0f:	48 89 c2             	mov    %rax,%rdx
    4e12:	48 85 c0             	test   %rax,%rax
    4e15:	74 49                	je     4e60 <fwp_wake_io+0xe0>
    4e17:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4e1e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4e22:	48 85 ff             	test   %rdi,%rdi
    4e25:	74 b8                	je     4ddf <fwp_wake_io+0x5f>
    4e27:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4e2e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4e35:	48 85 f6             	test   %rsi,%rsi
    4e38:	0f 85 72 ff ff ff    	jne    4db0 <fwp_wake_io+0x30>
    4e3e:	48 89 0f             	mov    %rcx,(%rdi)
    4e41:	e9 78 ff ff ff       	jmp    4dbe <fwp_wake_io+0x3e>
    4e46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e4d:	00 00 00 
    4e50:	48 89 d3             	mov    %rdx,%rbx
    4e53:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4e59:	eb ab                	jmp    4e06 <fwp_wake_io+0x86>
    4e5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e60:	45 84 db             	test   %r11b,%r11b
    4e63:	74 07                	je     4e6c <fwp_wake_io+0xec>
    4e65:	48 89 1d fc e8 01 00 	mov    %rbx,0x1e8fc(%rip)        # 23768 <fwp_ready_head>
    4e6c:	45 84 d2             	test   %r10b,%r10b
    4e6f:	74 07                	je     4e78 <fwp_wake_io+0xf8>
    4e71:	4c 89 05 e8 e8 01 00 	mov    %r8,0x1e8e8(%rip)        # 23760 <fwp_ready_tail>
    4e78:	5b                   	pop    %rbx
    4e79:	c3                   	ret
    4e7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e80:	c3                   	ret
    4e81:	0f 1f 40 00          	nopl   0x0(%rax)
    4e85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e8c:	00 00 00 00 

0000000000004e90 <fwp_tape_buffers_release>:
    4e90:	f3 0f 1e fa          	endbr64
    4e94:	53                   	push   %rbx
    4e95:	48 89 fb             	mov    %rdi,%rbx
    4e98:	48 83 ec 10          	sub    $0x10,%rsp
    4e9c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4ea0:	48 85 c0             	test   %rax,%rax
    4ea3:	0f 88 df 00 00 00    	js     4f88 <fwp_tape_buffers_release+0xf8>
    4ea9:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4ead:	48 85 d2             	test   %rdx,%rdx
    4eb0:	0f 88 d2 00 00 00    	js     4f88 <fwp_tape_buffers_release+0xf8>
    4eb6:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4ebc:	0f 87 c6 00 00 00    	ja     4f88 <fwp_tape_buffers_release+0xf8>
    4ec2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4ec6:	b8 00 00 08 00       	mov    $0x80000,%eax
    4ecb:	48 c1 e1 03          	shl    $0x3,%rcx
    4ecf:	48 29 c8             	sub    %rcx,%rax
    4ed2:	48 c1 e8 03          	shr    $0x3,%rax
    4ed6:	48 39 d0             	cmp    %rdx,%rax
    4ed9:	0f 82 a9 00 00 00    	jb     4f88 <fwp_tape_buffers_release+0xf8>
    4edf:	48 8d 3d d9 a1 00 00 	lea    0xa1d9(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    4ee6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4eeb:	48 89 14 24          	mov    %rdx,(%rsp)
    4eef:	e8 ac e4 ff ff       	call   33a0 <getenv@plt>
    4ef4:	48 8b 14 24          	mov    (%rsp),%rdx
    4ef8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4efd:	48 85 c0             	test   %rax,%rax
    4f00:	74 09                	je     4f0b <fwp_tape_buffers_release+0x7b>
    4f02:	80 38 30             	cmpb   $0x30,(%rax)
    4f05:	0f 84 9d 00 00 00    	je     4fa8 <fwp_tape_buffers_release+0x118>
    4f0b:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4f0f:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4f13:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4f1a:	77 78                	ja     4f94 <fwp_tape_buffers_release+0x104>
    4f1c:	48 8d 3d bd e1 01 00 	lea    0x1e1bd(%rip),%rdi        # 230e0 <fwp_tape_workspace>
    4f23:	48 89 04 24          	mov    %rax,(%rsp)
    4f27:	e8 44 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4f2c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4f30:	48 8b 04 24          	mov    (%rsp),%rax
    4f34:	0f 29 05 a5 e1 01 00 	movaps %xmm0,0x1e1a5(%rip)        # 230e0 <fwp_tape_workspace>
    4f3b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4f40:	48 89 05 81 e1 01 00 	mov    %rax,0x1e181(%rip)        # 230c8 <fwp_tape_cached_bytes>
    4f47:	0f 29 05 a2 e1 01 00 	movaps %xmm0,0x1e1a2(%rip)        # 230f0 <fwp_tape_workspace+0x10>
    4f4e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4f53:	0f 29 05 a6 e1 01 00 	movaps %xmm0,0x1e1a6(%rip)        # 23100 <fwp_tape_workspace+0x20>
    4f5a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4f5e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f62:	48 89 15 a7 e1 01 00 	mov    %rdx,0x1e1a7(%rip)        # 23110 <fwp_tape_workspace+0x30>
    4f69:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f70:	00 
    4f71:	0f 11 03             	movups %xmm0,(%rbx)
    4f74:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f78:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f7c:	48 83 c4 10          	add    $0x10,%rsp
    4f80:	5b                   	pop    %rbx
    4f81:	c3                   	ret
    4f82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f88:	48 8d 3d 30 a1 00 00 	lea    0xa130(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    4f8f:	e8 0c e4 ff ff       	call   33a0 <getenv@plt>
    4f94:	48 83 c4 10          	add    $0x10,%rsp
    4f98:	48 89 df             	mov    %rbx,%rdi
    4f9b:	5b                   	pop    %rbx
    4f9c:	e9 cf ef ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4fa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa8:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4fac:	0f 85 59 ff ff ff    	jne    4f0b <fwp_tape_buffers_release+0x7b>
    4fb2:	48 83 c4 10          	add    $0x10,%rsp
    4fb6:	48 89 df             	mov    %rbx,%rdi
    4fb9:	5b                   	pop    %rbx
    4fba:	e9 b1 ef ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4fbf:	90                   	nop

0000000000004fc0 <fwp_poll_events>:
    4fc0:	53                   	push   %rbx
    4fc1:	48 83 ec 20          	sub    $0x20,%rsp
    4fc5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4fcc:	00 00 
    4fce:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4fd3:	31 c0                	xor    %eax,%eax
    4fd5:	e8 36 f3 ff ff       	call   4310 <fwp_now_ns>
    4fda:	48 8b 1d 77 e7 01 00 	mov    0x1e777(%rip),%rbx        # 23758 <fwp_timers>
    4fe1:	48 85 db             	test   %rbx,%rbx
    4fe4:	0f 84 d6 00 00 00    	je     50c0 <fwp_poll_events+0x100>
    4fea:	48 89 c6             	mov    %rax,%rsi
    4fed:	48 89 da             	mov    %rbx,%rdx
    4ff0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4ff7:	eb 16                	jmp    500f <fwp_poll_events+0x4f>
    4ff9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5000:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5007:	48 89 c8             	mov    %rcx,%rax
    500a:	48 85 d2             	test   %rdx,%rdx
    500d:	74 31                	je     5040 <fwp_poll_events+0x80>
    500f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5013:	48 85 c0             	test   %rax,%rax
    5016:	78 e8                	js     5000 <fwp_poll_events+0x40>
    5018:	48 39 c1             	cmp    %rax,%rcx
    501b:	7c e3                	jl     5000 <fwp_poll_events+0x40>
    501d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5024:	48 85 d2             	test   %rdx,%rdx
    5027:	74 1c                	je     5045 <fwp_poll_events+0x85>
    5029:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    502d:	48 39 c1             	cmp    %rax,%rcx
    5030:	7c ce                	jl     5000 <fwp_poll_events+0x40>
    5032:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5039:	48 85 d2             	test   %rdx,%rdx
    503c:	75 d1                	jne    500f <fwp_poll_events+0x4f>
    503e:	66 90                	xchg   %ax,%ax
    5040:	48 85 c0             	test   %rax,%rax
    5043:	78 7b                	js     50c0 <fwp_poll_events+0x100>
    5045:	48 29 f0             	sub    %rsi,%rax
    5048:	48 89 c1             	mov    %rax,%rcx
    504b:	48 85 c0             	test   %rax,%rax
    504e:	0f 8e 9c 00 00 00    	jle    50f0 <fwp_poll_events+0x130>
    5054:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    505b:	de 1b 43 
    505e:	48 f7 ea             	imul   %rdx
    5061:	48 89 c8             	mov    %rcx,%rax
    5064:	48 c1 f8 3f          	sar    $0x3f,%rax
    5068:	48 c1 fa 12          	sar    $0x12,%rdx
    506c:	48 29 c2             	sub    %rax,%rdx
    506f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5076:	48 39 c1             	cmp    %rax,%rcx
    5079:	0f 95 c0             	setne  %al
    507c:	0f b6 c0             	movzbl %al,%eax
    507f:	48 01 d0             	add    %rdx,%rax
    5082:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5088:	0f 8f 32 01 00 00    	jg     51c0 <fwp_poll_events+0x200>
    508e:	48 85 c0             	test   %rax,%rax
    5091:	74 5d                	je     50f0 <fwp_poll_events+0x130>
    5093:	89 c1                	mov    %eax,%ecx
    5095:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    509c:	48 c1 e9 26          	shr    $0x26,%rcx
    50a0:	48 63 d1             	movslq %ecx,%rdx
    50a3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    50a9:	29 c8                	sub    %ecx,%eax
    50ab:	48 98                	cltq
    50ad:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    50b4:	e9 11 01 00 00       	jmp    51ca <fwp_poll_events+0x20a>
    50b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    50c0:	e8 ab eb ff ff       	call   3c70 <fwp_flush>
    50c5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    50ca:	be 01 00 00 00       	mov    $0x1,%esi
    50cf:	48 8b 0d 8a df 00 00 	mov    0xdf8a(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    50d6:	48 8d 3d 63 a6 00 00 	lea    0xa663(%rip),%rdi        # f740 <_IO_stdin_used+0x740>
    50dd:	e8 9e e5 ff ff       	call   3680 <fwrite@plt>
    50e2:	bf 65 00 00 00       	mov    $0x65,%edi
    50e7:	e8 84 e5 ff ff       	call   3670 <exit@plt>
    50ec:	0f 1f 40 00          	nopl   0x0(%rax)
    50f0:	e8 1b f2 ff ff       	call   4310 <fwp_now_ns>
    50f5:	48 89 c1             	mov    %rax,%rcx
    50f8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fc:	eb 44                	jmp    5142 <fwp_poll_events+0x182>
    50fe:	66 90                	xchg   %ax,%ax
    5100:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5104:	75 33                	jne    5139 <fwp_poll_events+0x179>
    5106:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    510a:	75 2d                	jne    5139 <fwp_poll_events+0x179>
    510c:	48 8b 05 4d e6 01 00 	mov    0x1e64d(%rip),%rax        # 23760 <fwp_ready_tail>
    5113:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5117:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    511e:	00 00 00 00 
    5122:	48 85 c0             	test   %rax,%rax
    5125:	0f 84 05 01 00 00    	je     5230 <fwp_poll_events+0x270>
    512b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5132:	48 89 15 27 e6 01 00 	mov    %rdx,0x1e627(%rip)        # 23760 <fwp_ready_tail>
    5139:	48 85 db             	test   %rbx,%rbx
    513c:	0f 84 be 00 00 00    	je     5200 <fwp_poll_events+0x240>
    5142:	48 89 da             	mov    %rbx,%rdx
    5145:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    514c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5150:	7f e7                	jg     5139 <fwp_poll_events+0x179>
    5152:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5156:	74 2e                	je     5186 <fwp_poll_events+0x1c6>
    5158:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    515f:	48 85 c0             	test   %rax,%rax
    5162:	0f 84 b8 00 00 00    	je     5220 <fwp_poll_events+0x260>
    5168:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    516f:	48 85 db             	test   %rbx,%rbx
    5172:	74 07                	je     517b <fwp_poll_events+0x1bb>
    5174:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    517b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    517f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5186:	48 8b 42 60          	mov    0x60(%rdx),%rax
    518a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    518e:	48 85 c0             	test   %rax,%rax
    5191:	0f 84 69 ff ff ff    	je     5100 <fwp_poll_events+0x140>
    5197:	48 39 c8             	cmp    %rcx,%rax
    519a:	0f 8f 60 ff ff ff    	jg     5100 <fwp_poll_events+0x140>
    51a0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    51a4:	0f 85 56 ff ff ff    	jne    5100 <fwp_poll_events+0x140>
    51aa:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    51ae:	75 89                	jne    5139 <fwp_poll_events+0x179>
    51b0:	48 89 d7             	mov    %rdx,%rdi
    51b3:	e8 f8 ee ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    51b8:	e9 43 ff ff ff       	jmp    5100 <fwp_poll_events+0x140>
    51bd:	0f 1f 00             	nopl   (%rax)
    51c0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    51c5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    51ca:	48 89 e7             	mov    %rsp,%rdi
    51cd:	31 f6                	xor    %esi,%esi
    51cf:	48 89 14 24          	mov    %rdx,(%rsp)
    51d3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    51d8:	e8 c3 e2 ff ff       	call   34a0 <nanosleep@plt>
    51dd:	48 8b 1d 74 e5 01 00 	mov    0x1e574(%rip),%rbx        # 23758 <fwp_timers>
    51e4:	e8 27 f1 ff ff       	call   4310 <fwp_now_ns>
    51e9:	48 89 c1             	mov    %rax,%rcx
    51ec:	48 85 db             	test   %rbx,%rbx
    51ef:	0f 85 03 ff ff ff    	jne    50f8 <fwp_poll_events+0x138>
    51f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51fc:	00 00 00 00 
    5200:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5205:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    520c:	00 00 
    520e:	75 2c                	jne    523c <fwp_poll_events+0x27c>
    5210:	48 83 c4 20          	add    $0x20,%rsp
    5214:	5b                   	pop    %rbx
    5215:	c3                   	ret
    5216:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    521d:	00 00 00 
    5220:	48 89 1d 31 e5 01 00 	mov    %rbx,0x1e531(%rip)        # 23758 <fwp_timers>
    5227:	e9 43 ff ff ff       	jmp    516f <fwp_poll_events+0x1af>
    522c:	0f 1f 40 00          	nopl   0x0(%rax)
    5230:	48 89 15 31 e5 01 00 	mov    %rdx,0x1e531(%rip)        # 23768 <fwp_ready_head>
    5237:	e9 f6 fe ff ff       	jmp    5132 <fwp_poll_events+0x172>
    523c:	e8 1f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    5241:	0f 1f 40 00          	nopl   0x0(%rax)
    5245:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    524c:	00 00 00 00 

0000000000005250 <fwp_rc_wide_dup>:
    5250:	48 89 fa             	mov    %rdi,%rdx
    5253:	48 8d 35 46 e5 01 00 	lea    0x1e546(%rip),%rsi        # 237a0 <fwp_heap>
    525a:	48 83 ec 18          	sub    $0x18,%rsp
    525e:	48 89 f9             	mov    %rdi,%rcx
    5261:	48 c1 ea 11          	shr    $0x11,%rdx
    5265:	48 31 fa             	xor    %rdi,%rdx
    5268:	48 89 d0             	mov    %rdx,%rax
    526b:	48 c1 e8 09          	shr    $0x9,%rax
    526f:	48 31 c2             	xor    %rax,%rdx
    5272:	0f b6 d2             	movzbl %dl,%edx
    5275:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    527c:	00 
    527d:	49 8b 00             	mov    (%r8),%rax
    5280:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5287:	00 00 
    5289:	75 21                	jne    52ac <fwp_rc_wide_dup+0x5c>
    528b:	e9 98 00 00 00       	jmp    5328 <fwp_rc_wide_dup+0xd8>
    5290:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    529c:	00 00 00 00 
    52a0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    52a4:	48 85 d2             	test   %rdx,%rdx
    52a7:	74 2f                	je     52d8 <fwp_rc_wide_dup+0x88>
    52a9:	48 89 d0             	mov    %rdx,%rax
    52ac:	48 3b 08             	cmp    (%rax),%rcx
    52af:	75 ef                	jne    52a0 <fwp_rc_wide_dup+0x50>
    52b1:	80 39 fe             	cmpb   $0xfe,(%rcx)
    52b4:	74 7c                	je     5332 <fwp_rc_wide_dup+0xe2>
    52b6:	48 8b 50 08          	mov    0x8(%rax),%rdx
    52ba:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    52be:	0f 84 91 00 00 00    	je     5355 <fwp_rc_wide_dup+0x105>
    52c4:	48 83 c2 01          	add    $0x1,%rdx
    52c8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    52cc:	48 83 c4 18          	add    $0x18,%rsp
    52d0:	c3                   	ret
    52d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52d8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    52dc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    52df:	75 68                	jne    5349 <fwp_rc_wide_dup+0xf9>
    52e1:	bf 18 00 00 00       	mov    $0x18,%edi
    52e6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52eb:	4c 89 04 24          	mov    %r8,(%rsp)
    52ef:	e8 bc e2 ff ff       	call   35b0 <malloc@plt>
    52f4:	4c 8b 04 24          	mov    (%rsp),%r8
    52f8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52fd:	48 85 c0             	test   %rax,%rax
    5300:	74 5f                	je     5361 <fwp_rc_wide_dup+0x111>
    5302:	48 89 08             	mov    %rcx,(%rax)
    5305:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    530c:	00 
    530d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5314:	00 
    5315:	49 89 00             	mov    %rax,(%r8)
    5318:	c6 01 ff             	movb   $0xff,(%rcx)
    531b:	48 83 05 c5 00 02 00 	addq   $0x1,0x200c5(%rip)        # 253e8 <fwp_heap+0x1c48>
    5322:	01 
    5323:	48 83 c4 18          	add    $0x18,%rsp
    5327:	c3                   	ret
    5328:	80 3f fe             	cmpb   $0xfe,(%rdi)
    532b:	75 13                	jne    5340 <fwp_rc_wide_dup+0xf0>
    532d:	48 85 c0             	test   %rax,%rax
    5330:	74 af                	je     52e1 <fwp_rc_wide_dup+0x91>
    5332:	48 8d 3d 37 a4 00 00 	lea    0xa437(%rip),%rdi        # f770 <_IO_stdin_used+0x770>
    5339:	e8 62 ee ff ff       	call   41a0 <fwp_trap>
    533e:	66 90                	xchg   %ax,%ax
    5340:	48 85 c0             	test   %rax,%rax
    5343:	0f 85 6d ff ff ff    	jne    52b6 <fwp_rc_wide_dup+0x66>
    5349:	48 8d 3d 48 a4 00 00 	lea    0xa448(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    5350:	e8 4b ee ff ff       	call   41a0 <fwp_trap>
    5355:	48 8d 3d 74 9d 00 00 	lea    0x9d74(%rip),%rdi        # f0d0 <_IO_stdin_used+0xd0>
    535c:	e8 3f ee ff ff       	call   41a0 <fwp_trap>
    5361:	e8 4a e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5366:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    536d:	00 00 00 

0000000000005370 <fwp_rc_forget_slot>:
    5370:	80 3f ff             	cmpb   $0xff,(%rdi)
    5373:	74 0b                	je     5380 <fwp_rc_forget_slot+0x10>
    5375:	c3                   	ret
    5376:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    537d:	00 00 00 
    5380:	48 89 f8             	mov    %rdi,%rax
    5383:	48 83 ec 08          	sub    $0x8,%rsp
    5387:	48 89 fa             	mov    %rdi,%rdx
    538a:	48 c1 e8 11          	shr    $0x11,%rax
    538e:	48 31 f8             	xor    %rdi,%rax
    5391:	48 89 c1             	mov    %rax,%rcx
    5394:	48 c1 e9 09          	shr    $0x9,%rcx
    5398:	48 31 c8             	xor    %rcx,%rax
    539b:	48 8d 0d fe e3 01 00 	lea    0x1e3fe(%rip),%rcx        # 237a0 <fwp_heap>
    53a2:	0f b6 c0             	movzbl %al,%eax
    53a5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    53ac:	00 
    53ad:	48 85 ff             	test   %rdi,%rdi
    53b0:	74 3c                	je     53ee <fwp_rc_forget_slot+0x7e>
    53b2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    53b9:	00 
    53ba:	48 8b 01             	mov    (%rcx),%rax
    53bd:	eb 11                	jmp    53d0 <fwp_rc_forget_slot+0x60>
    53bf:	90                   	nop
    53c0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    53c4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    53c8:	48 85 ff             	test   %rdi,%rdi
    53cb:	74 21                	je     53ee <fwp_rc_forget_slot+0x7e>
    53cd:	48 89 f8             	mov    %rdi,%rax
    53d0:	48 3b 10             	cmp    (%rax),%rdx
    53d3:	75 eb                	jne    53c0 <fwp_rc_forget_slot+0x50>
    53d5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    53d9:	48 89 01             	mov    %rax,(%rcx)
    53dc:	e8 df df ff ff       	call   33c0 <free@plt>
    53e1:	48 83 2d ff ff 01 00 	subq   $0x1,0x1ffff(%rip)        # 253e8 <fwp_heap+0x1c48>
    53e8:	01 
    53e9:	48 83 c4 08          	add    $0x8,%rsp
    53ed:	c3                   	ret
    53ee:	48 8d 3d a3 a3 00 00 	lea    0xa3a3(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    53f5:	e8 a6 ed ff ff       	call   41a0 <fwp_trap>
    53fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005400 <fwp_rc_prepare_chunk>:
    5400:	48 83 3d e0 ff 01 00 	cmpq   $0x0,0x1ffe0(%rip)        # 253e8 <fwp_heap+0x1c48>
    5407:	00 
    5408:	41 54                	push   %r12
    540a:	49 89 f4             	mov    %rsi,%r12
    540d:	55                   	push   %rbp
    540e:	48 89 fd             	mov    %rdi,%rbp
    5411:	53                   	push   %rbx
    5412:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5415:	0f 84 7d 00 00 00    	je     5498 <fwp_rc_prepare_chunk+0x98>
    541b:	31 db                	xor    %ebx,%ebx
    541d:	85 c0                	test   %eax,%eax
    541f:	75 5f                	jne    5480 <fwp_rc_prepare_chunk+0x80>
    5421:	48 85 f6             	test   %rsi,%rsi
    5424:	74 7c                	je     54a2 <fwp_rc_prepare_chunk+0xa2>
    5426:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    542a:	e8 91 df ff ff       	call   33c0 <free@plt>
    542f:	90                   	nop
    5430:	be 01 00 00 00       	mov    $0x1,%esi
    5435:	4c 89 e7             	mov    %r12,%rdi
    5438:	e8 e3 e0 ff ff       	call   3520 <calloc@plt>
    543d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5441:	48 85 c0             	test   %rax,%rax
    5444:	0f 85 87 00 00 00    	jne    54d1 <fwp_rc_prepare_chunk+0xd1>
    544a:	e8 61 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    544f:	90                   	nop
    5450:	e8 1b ff ff ff       	call   5370 <fwp_rc_forget_slot>
    5455:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5458:	48 83 c3 01          	add    $0x1,%rbx
    545c:	48 39 c3             	cmp    %rax,%rbx
    545f:	73 37                	jae    5498 <fwp_rc_prepare_chunk+0x98>
    5461:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5468:	00 00 
    546a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5471:	00 00 00 00 
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5484:	48 01 df             	add    %rbx,%rdi
    5487:	80 3f ff             	cmpb   $0xff,(%rdi)
    548a:	74 c4                	je     5450 <fwp_rc_prepare_chunk+0x50>
    548c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    548f:	48 83 c3 01          	add    $0x1,%rbx
    5493:	48 39 c3             	cmp    %rax,%rbx
    5496:	72 e8                	jb     5480 <fwp_rc_prepare_chunk+0x80>
    5498:	49 39 c4             	cmp    %rax,%r12
    549b:	75 13                	jne    54b0 <fwp_rc_prepare_chunk+0xb0>
    549d:	4d 85 e4             	test   %r12,%r12
    54a0:	75 46                	jne    54e8 <fwp_rc_prepare_chunk+0xe8>
    54a2:	5b                   	pop    %rbx
    54a3:	5d                   	pop    %rbp
    54a4:	41 5c                	pop    %r12
    54a6:	c3                   	ret
    54a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    54ae:	00 00 
    54b0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    54b4:	48 29 05 35 ff 01 00 	sub    %rax,0x1ff35(%rip)        # 253f0 <fwp_heap+0x1c50>
    54bb:	e8 00 df ff ff       	call   33c0 <free@plt>
    54c0:	4d 85 e4             	test   %r12,%r12
    54c3:	0f 85 67 ff ff ff    	jne    5430 <fwp_rc_prepare_chunk+0x30>
    54c9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    54d0:	00 
    54d1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    54d5:	5b                   	pop    %rbx
    54d6:	4c 01 25 13 ff 01 00 	add    %r12,0x1ff13(%rip)        # 253f0 <fwp_heap+0x1c50>
    54dd:	5d                   	pop    %rbp
    54de:	41 5c                	pop    %r12
    54e0:	c3                   	ret
    54e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54e8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    54ec:	5b                   	pop    %rbx
    54ed:	4c 89 e2             	mov    %r12,%rdx
    54f0:	31 f6                	xor    %esi,%esi
    54f2:	5d                   	pop    %rbp
    54f3:	41 5c                	pop    %r12
    54f5:	e9 c6 df ff ff       	jmp    34c0 <memset@plt>
    54fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005500 <fwp_heap_refill>:
    5500:	41 56                	push   %r14
    5502:	41 89 d6             	mov    %edx,%r14d
    5505:	41 55                	push   %r13
    5507:	41 89 f5             	mov    %esi,%r13d
    550a:	41 54                	push   %r12
    550c:	49 89 fc             	mov    %rdi,%r12
    550f:	bf 01 00 00 00       	mov    $0x1,%edi
    5514:	55                   	push   %rbp
    5515:	53                   	push   %rbx
    5516:	e8 c5 e8 ff ff       	call   3de0 <fwp_heap_chunks>
    551b:	48 89 c3             	mov    %rax,%rbx
    551e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5522:	48 8b 05 6f f6 01 00 	mov    0x1f66f(%rip),%rax        # 24b98 <fwp_heap+0x13f8>
    5529:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    552d:	48 8d 05 6c e2 01 00 	lea    0x1e26c(%rip),%rax        # 237a0 <fwp_heap>
    5534:	31 d2                	xor    %edx,%edx
    5536:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    553a:	48 89 ef             	mov    %rbp,%rdi
    553d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5541:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5545:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    554c:	00 
    554d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5552:	f7 f1                	div    %ecx
    5554:	31 d2                	xor    %edx,%edx
    5556:	66 0f 6e c1          	movd   %ecx,%xmm0
    555a:	66 0f 6e c8          	movd   %eax,%xmm1
    555e:	89 c6                	mov    %eax,%esi
    5560:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5565:	48 01 c8             	add    %rcx,%rax
    5568:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    556c:	48 f7 f1             	div    %rcx
    556f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5574:	89 45 18             	mov    %eax,0x18(%rbp)
    5577:	e8 84 fe ff ff       	call   5400 <fwp_rc_prepare_chunk>
    557c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    557f:	48 89 d8             	mov    %rbx,%rax
    5582:	48 c1 e0 10          	shl    $0x10,%rax
    5586:	48 03 05 c3 f5 01 00 	add    0x1f5c3(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    558d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5591:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5596:	8b 55 08             	mov    0x8(%rbp),%edx
    5599:	48 0f af d1          	imul   %rcx,%rdx
    559d:	48 01 c2             	add    %rax,%rdx
    55a0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    55a5:	5b                   	pop    %rbx
    55a6:	5d                   	pop    %rbp
    55a7:	41 5c                	pop    %r12
    55a9:	41 5d                	pop    %r13
    55ab:	41 5e                	pop    %r14
    55ad:	c3                   	ret
    55ae:	66 90                	xchg   %ax,%ax

00000000000055b0 <fwp_mem_free>:
    55b0:	48 85 ff             	test   %rdi,%rdi
    55b3:	0f 84 17 02 00 00    	je     57d0 <fwp_mem_free+0x220>
    55b9:	48 8b 35 90 f5 01 00 	mov    0x1f590(%rip),%rsi        # 24b50 <fwp_heap+0x13b0>
    55c0:	48 8b 05 b1 f5 01 00 	mov    0x1f5b1(%rip),%rax        # 24b78 <fwp_heap+0x13d8>
    55c7:	48 89 fa             	mov    %rdi,%rdx
    55ca:	48 29 f2             	sub    %rsi,%rdx
    55cd:	48 c1 e0 10          	shl    $0x10,%rax
    55d1:	48 39 c2             	cmp    %rax,%rdx
    55d4:	0f 83 f6 01 00 00    	jae    57d0 <fwp_mem_free+0x220>
    55da:	49 89 d1             	mov    %rdx,%r9
    55dd:	49 c1 e9 10          	shr    $0x10,%r9
    55e1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    55e5:	48 c1 e0 03          	shl    $0x3,%rax
    55e9:	49 89 c0             	mov    %rax,%r8
    55ec:	4c 03 05 a5 f5 01 00 	add    0x1f5a5(%rip),%r8        # 24b98 <fwp_heap+0x13f8>
    55f3:	0f 84 d7 01 00 00    	je     57d0 <fwp_mem_free+0x220>
    55f9:	48 83 ec 38          	sub    $0x38,%rsp
    55fd:	48 89 f9             	mov    %rdi,%rcx
    5600:	41 0f b6 38          	movzbl (%r8),%edi
    5604:	40 80 ff 01          	cmp    $0x1,%dil
    5608:	74 16                	je     5620 <fwp_mem_free+0x70>
    560a:	40 80 ff 02          	cmp    $0x2,%dil
    560e:	0f 84 94 00 00 00    	je     56a8 <fwp_mem_free+0xf8>
    5614:	48 83 c4 38          	add    $0x38,%rsp
    5618:	c3                   	ret
    5619:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5620:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5624:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5629:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    562e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5632:	4d 85 d2             	test   %r10,%r10
    5635:	74 1d                	je     5654 <fwp_mem_free+0xa4>
    5637:	0f b7 c1             	movzwl %cx,%eax
    563a:	31 d2                	xor    %edx,%edx
    563c:	48 f7 f7             	div    %rdi
    563f:	49 01 c2             	add    %rax,%r10
    5642:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5646:	0f 84 44 01 00 00    	je     5790 <fwp_mem_free+0x1e0>
    564c:	41 c6 02 00          	movb   $0x0,(%r10)
    5650:	41 8b 78 04          	mov    0x4(%r8),%edi
    5654:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    565b:	49 63 c1             	movslq %r9d,%rax
    565e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5662:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5666:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    566b:	f2 0f 58 05 6d f5 01 	addsd  0x1f56d(%rip),%xmm0        # 24be0 <fwp_heap+0x1440>
    5672:	00 
    5673:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5677:	48 8d 05 22 e1 01 00 	lea    0x1e122(%rip),%rax        # 237a0 <fwp_heap>
    567e:	48 01 d0             	add    %rdx,%rax
    5681:	48 8b 10             	mov    (%rax),%rdx
    5684:	48 f7 d2             	not    %rdx
    5687:	48 89 11             	mov    %rdx,(%rcx)
    568a:	48 89 08             	mov    %rcx,(%rax)
    568d:	48 29 3d 2c f5 01 00 	sub    %rdi,0x1f52c(%rip)        # 24bc0 <fwp_heap+0x1420>
    5694:	f2 0f 11 05 44 f5 01 	movsd  %xmm0,0x1f544(%rip)        # 24be0 <fwp_heap+0x1440>
    569b:	00 
    569c:	48 83 c4 38          	add    $0x38,%rsp
    56a0:	c3                   	ret
    56a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56a8:	66 31 d2             	xor    %dx,%dx
    56ab:	48 01 d6             	add    %rdx,%rsi
    56ae:	48 39 f1             	cmp    %rsi,%rcx
    56b1:	0f 85 5d ff ff ff    	jne    5614 <fwp_mem_free+0x64>
    56b7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    56bb:	48 29 15 fe f4 01 00 	sub    %rdx,0x1f4fe(%rip)        # 24bc0 <fwp_heap+0x1420>
    56c2:	48 85 d2             	test   %rdx,%rdx
    56c5:	0f 88 a5 00 00 00    	js     5770 <fwp_mem_free+0x1c0>
    56cb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    56cf:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    56d4:	f2 0f 58 05 04 f5 01 	addsd  0x1f504(%rip),%xmm0        # 24be0 <fwp_heap+0x1440>
    56db:	00 
    56dc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    56e0:	f2 0f 11 05 f8 f4 01 	movsd  %xmm0,0x1f4f8(%rip)        # 24be0 <fwp_heap+0x1440>
    56e7:	00 
    56e8:	48 85 d2             	test   %rdx,%rdx
    56eb:	74 0c                	je     56f9 <fwp_mem_free+0x149>
    56ed:	80 3a ff             	cmpb   $0xff,(%rdx)
    56f0:	0f 84 db 00 00 00    	je     57d1 <fwp_mem_free+0x221>
    56f6:	c6 02 00             	movb   $0x0,(%rdx)
    56f9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    56fd:	48 85 c9             	test   %rcx,%rcx
    5700:	74 3e                	je     5740 <fwp_mem_free+0x190>
    5702:	48 8b 15 8f f4 01 00 	mov    0x1f48f(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    5709:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    570d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5711:	48 01 d0             	add    %rdx,%rax
    5714:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5718:	48 89 d6             	mov    %rdx,%rsi
    571b:	48 29 c6             	sub    %rax,%rsi
    571e:	83 e6 08             	and    $0x8,%esi
    5721:	74 0d                	je     5730 <fwp_mem_free+0x180>
    5723:	c6 00 00             	movb   $0x0,(%rax)
    5726:	48 83 c0 28          	add    $0x28,%rax
    572a:	48 39 c2             	cmp    %rax,%rdx
    572d:	74 11                	je     5740 <fwp_mem_free+0x190>
    572f:	90                   	nop
    5730:	c6 00 00             	movb   $0x0,(%rax)
    5733:	48 83 c0 50          	add    $0x50,%rax
    5737:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    573b:	48 39 c2             	cmp    %rax,%rdx
    573e:	75 f0                	jne    5730 <fwp_mem_free+0x180>
    5740:	48 01 0d 89 f4 01 00 	add    %rcx,0x1f489(%rip)        # 24bd0 <fwp_heap+0x1430>
    5747:	4c 3b 0d 42 f4 01 00 	cmp    0x1f442(%rip),%r9        # 24b90 <fwp_heap+0x13f0>
    574e:	73 07                	jae    5757 <fwp_mem_free+0x1a7>
    5750:	4c 89 0d 39 f4 01 00 	mov    %r9,0x1f439(%rip)        # 24b90 <fwp_heap+0x13f0>
    5757:	4c 3b 0d 2a f4 01 00 	cmp    0x1f42a(%rip),%r9        # 24b88 <fwp_heap+0x13e8>
    575e:	0f 83 b0 fe ff ff    	jae    5614 <fwp_mem_free+0x64>
    5764:	4c 89 0d 1d f4 01 00 	mov    %r9,0x1f41d(%rip)        # 24b88 <fwp_heap+0x13e8>
    576b:	e9 a4 fe ff ff       	jmp    5614 <fwp_mem_free+0x64>
    5770:	48 89 d1             	mov    %rdx,%rcx
    5773:	83 e2 01             	and    $0x1,%edx
    5776:	66 0f ef c0          	pxor   %xmm0,%xmm0
    577a:	48 d1 e9             	shr    $1,%rcx
    577d:	48 09 d1             	or     %rdx,%rcx
    5780:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5785:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5789:	e9 46 ff ff ff       	jmp    56d4 <fwp_mem_free+0x124>
    578e:	66 90                	xchg   %ax,%ax
    5790:	4c 89 d7             	mov    %r10,%rdi
    5793:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5798:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    579d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    57a2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    57a6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    57ab:	e8 c0 fb ff ff       	call   5370 <fwp_rc_forget_slot>
    57b0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    57b5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    57ba:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    57bf:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    57c4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    57c9:	e9 7e fe ff ff       	jmp    564c <fwp_mem_free+0x9c>
    57ce:	66 90                	xchg   %ax,%ax
    57d0:	c3                   	ret
    57d1:	48 89 d7             	mov    %rdx,%rdi
    57d4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    57d9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    57de:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    57e3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    57e8:	e8 83 fb ff ff       	call   5370 <fwp_rc_forget_slot>
    57ed:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    57f2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    57f7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    57fc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5801:	e9 f0 fe ff ff       	jmp    56f6 <fwp_mem_free+0x146>
    5806:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    580d:	00 00 00 

0000000000005810 <fwp_heap_alloc_big>:
    5810:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5817:	00 00 40 
    581a:	41 57                	push   %r15
    581c:	41 56                	push   %r14
    581e:	41 55                	push   %r13
    5820:	41 54                	push   %r12
    5822:	55                   	push   %rbp
    5823:	53                   	push   %rbx
    5824:	48 83 ec 08          	sub    $0x8,%rsp
    5828:	48 39 f8             	cmp    %rdi,%rax
    582b:	0f 82 fa 00 00 00    	jb     592b <fwp_heap_alloc_big+0x11b>
    5831:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5838:	49 89 fd             	mov    %rdi,%r13
    583b:	41 89 f6             	mov    %esi,%r14d
    583e:	48 c1 ed 10          	shr    $0x10,%rbp
    5842:	48 89 ef             	mov    %rbp,%rdi
    5845:	e8 96 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    584a:	be 01 00 00 00       	mov    $0x1,%esi
    584f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5853:	49 89 c4             	mov    %rax,%r12
    5856:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    585d:	00 
    585e:	48 03 3d 33 f3 01 00 	add    0x1f333(%rip),%rdi        # 24b98 <fwp_heap+0x13f8>
    5865:	c6 07 02             	movb   $0x2,(%rdi)
    5868:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    586c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    586f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5873:	e8 88 fb ff ff       	call   5400 <fwp_rc_prepare_chunk>
    5878:	48 83 fd 01          	cmp    $0x1,%rbp
    587c:	76 47                	jbe    58c5 <fwp_heap_alloc_big+0xb5>
    587e:	4c 01 e5             	add    %r12,%rbp
    5881:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5888:	00 
    5889:	4c 8d 3d 10 df 01 00 	lea    0x1df10(%rip),%r15        # 237a0 <fwp_heap>
    5890:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5895:	49 c1 e6 03          	shl    $0x3,%r14
    5899:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    58a0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    58a7:	31 f6                	xor    %esi,%esi
    58a9:	48 01 dd             	add    %rbx,%rbp
    58ac:	48 83 c3 28          	add    $0x28,%rbx
    58b0:	48 89 ef             	mov    %rbp,%rdi
    58b3:	e8 48 fb ff ff       	call   5400 <fwp_rc_prepare_chunk>
    58b8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    58bc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    58c0:	49 39 de             	cmp    %rbx,%r14
    58c3:	75 db                	jne    58a0 <fwp_heap_alloc_big+0x90>
    58c5:	49 c1 e4 10          	shl    $0x10,%r12
    58c9:	4c 03 25 80 f2 01 00 	add    0x1f280(%rip),%r12        # 24b50 <fwp_heap+0x13b0>
    58d0:	4c 89 ea             	mov    %r13,%rdx
    58d3:	31 f6                	xor    %esi,%esi
    58d5:	4c 89 e7             	mov    %r12,%rdi
    58d8:	e8 e3 db ff ff       	call   34c0 <memset@plt>
    58dd:	4c 89 e8             	mov    %r13,%rax
    58e0:	48 03 05 d9 f2 01 00 	add    0x1f2d9(%rip),%rax        # 24bc0 <fwp_heap+0x1420>
    58e7:	72 42                	jb     592b <fwp_heap_alloc_big+0x11b>
    58e9:	48 39 05 d8 f2 01 00 	cmp    %rax,0x1f2d8(%rip)        # 24bc8 <fwp_heap+0x1428>
    58f0:	48 89 05 c9 f2 01 00 	mov    %rax,0x1f2c9(%rip)        # 24bc0 <fwp_heap+0x1420>
    58f7:	73 07                	jae    5900 <fwp_heap_alloc_big+0xf0>
    58f9:	48 89 05 c8 f2 01 00 	mov    %rax,0x1f2c8(%rip)        # 24bc8 <fwp_heap+0x1428>
    5900:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5904:	4c 89 e0             	mov    %r12,%rax
    5907:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    590c:	f2 0f 58 05 c4 f2 01 	addsd  0x1f2c4(%rip),%xmm0        # 24bd8 <fwp_heap+0x1438>
    5913:	00 
    5914:	f2 0f 11 05 bc f2 01 	movsd  %xmm0,0x1f2bc(%rip)        # 24bd8 <fwp_heap+0x1438>
    591b:	00 
    591c:	48 83 c4 08          	add    $0x8,%rsp
    5920:	5b                   	pop    %rbx
    5921:	5d                   	pop    %rbp
    5922:	41 5c                	pop    %r12
    5924:	41 5d                	pop    %r13
    5926:	41 5e                	pop    %r14
    5928:	41 5f                	pop    %r15
    592a:	c3                   	ret
    592b:	e8 80 e3 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005930 <fwp_heap_alloc_slow>:
    5930:	53                   	push   %rbx
    5931:	48 89 f9             	mov    %rdi,%rcx
    5934:	41 89 f1             	mov    %esi,%r9d
    5937:	48 83 ec 10          	sub    $0x10,%rsp
    593b:	8b 05 03 f2 01 00    	mov    0x1f203(%rip),%eax        # 24b44 <fwp_heap+0x13a4>
    5941:	85 c0                	test   %eax,%eax
    5943:	0f 84 c7 00 00 00    	je     5a10 <fwp_heap_alloc_slow+0xe0>
    5949:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5950:	0f 87 dd 00 00 00    	ja     5a33 <fwp_heap_alloc_slow+0x103>
    5956:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    595a:	48 8d 3d 3f de 01 00 	lea    0x1de3f(%rip),%rdi        # 237a0 <fwp_heap>
    5961:	49 63 f1             	movslq %r9d,%rsi
    5964:	48 c1 e8 04          	shr    $0x4,%rax
    5968:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    596f:	00 00 
    5971:	41 0f b6 c2          	movzbl %r10b,%eax
    5975:	4c 89 d2             	mov    %r10,%rdx
    5978:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    597c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5983:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    598a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    598e:	48 01 f8             	add    %rdi,%rax
    5991:	4c 8b 00             	mov    (%rax),%r8
    5994:	4d 85 c0             	test   %r8,%r8
    5997:	0f 84 ab 00 00 00    	je     5a48 <fwp_heap_alloc_slow+0x118>
    599d:	49 8b 10             	mov    (%r8),%rdx
    59a0:	48 f7 d2             	not    %rdx
    59a3:	48 89 10             	mov    %rdx,(%rax)
    59a6:	41 83 f9 01          	cmp    $0x1,%r9d
    59aa:	4c 89 c7             	mov    %r8,%rdi
    59ad:	48 0f 45 cb          	cmovne %rbx,%rcx
    59b1:	31 f6                	xor    %esi,%esi
    59b3:	48 89 ca             	mov    %rcx,%rdx
    59b6:	e8 05 db ff ff       	call   34c0 <memset@plt>
    59bb:	49 89 c0             	mov    %rax,%r8
    59be:	48 89 d8             	mov    %rbx,%rax
    59c1:	48 03 05 f8 f1 01 00 	add    0x1f1f8(%rip),%rax        # 24bc0 <fwp_heap+0x1420>
    59c8:	0f 82 d9 00 00 00    	jb     5aa7 <fwp_heap_alloc_slow+0x177>
    59ce:	48 39 05 f3 f1 01 00 	cmp    %rax,0x1f1f3(%rip)        # 24bc8 <fwp_heap+0x1428>
    59d5:	48 89 05 e4 f1 01 00 	mov    %rax,0x1f1e4(%rip)        # 24bc0 <fwp_heap+0x1420>
    59dc:	73 07                	jae    59e5 <fwp_heap_alloc_slow+0xb5>
    59de:	48 89 05 e3 f1 01 00 	mov    %rax,0x1f1e3(%rip)        # 24bc8 <fwp_heap+0x1428>
    59e5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    59e9:	4c 89 c0             	mov    %r8,%rax
    59ec:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    59f1:	f2 0f 58 05 df f1 01 	addsd  0x1f1df(%rip),%xmm0        # 24bd8 <fwp_heap+0x1438>
    59f8:	00 
    59f9:	f2 0f 11 05 d7 f1 01 	movsd  %xmm0,0x1f1d7(%rip)        # 24bd8 <fwp_heap+0x1438>
    5a00:	00 
    5a01:	48 83 c4 10          	add    $0x10,%rsp
    5a05:	5b                   	pop    %rbx
    5a06:	c3                   	ret
    5a07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5a0e:	00 00 
    5a10:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5a14:	48 89 3c 24          	mov    %rdi,(%rsp)
    5a18:	e8 13 f1 ff ff       	call   4b30 <fwp_heap_init>
    5a1d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5a21:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5a26:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5a2d:	0f 86 23 ff ff ff    	jbe    5956 <fwp_heap_alloc_slow+0x26>
    5a33:	48 83 c4 10          	add    $0x10,%rsp
    5a37:	44 89 ce             	mov    %r9d,%esi
    5a3a:	48 89 cf             	mov    %rcx,%rdi
    5a3d:	5b                   	pop    %rbx
    5a3e:	e9 cd fd ff ff       	jmp    5810 <fwp_heap_alloc_big>
    5a43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5a48:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5a4c:	4d 85 c0             	test   %r8,%r8
    5a4f:	74 1f                	je     5a70 <fwp_heap_alloc_slow+0x140>
    5a51:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5a55:	4d 29 c3             	sub    %r8,%r11
    5a58:	49 39 db             	cmp    %rbx,%r11
    5a5b:	72 13                	jb     5a70 <fwp_heap_alloc_slow+0x140>
    5a5d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a61:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a65:	e9 3c ff ff ff       	jmp    59a6 <fwp_heap_alloc_slow+0x76>
    5a6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a70:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a77:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a7b:	44 89 ca             	mov    %r9d,%edx
    5a7e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a83:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a87:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a8b:	44 89 d6             	mov    %r10d,%esi
    5a8e:	48 01 c7             	add    %rax,%rdi
    5a91:	e8 6a fa ff ff       	call   5500 <fwp_heap_refill>
    5a96:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a9b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a9f:	49 89 c0             	mov    %rax,%r8
    5aa2:	e9 ff fe ff ff       	jmp    59a6 <fwp_heap_alloc_slow+0x76>
    5aa7:	e8 04 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5aac:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005ab0 <fwp_heap_alloc>:
    5ab0:	8b 05 8e f0 01 00    	mov    0x1f08e(%rip),%eax        # 24b44 <fwp_heap+0x13a4>
    5ab6:	48 89 fa             	mov    %rdi,%rdx
    5ab9:	89 f7                	mov    %esi,%edi
    5abb:	85 c0                	test   %eax,%eax
    5abd:	0f 84 f5 00 00 00    	je     5bb8 <fwp_heap_alloc+0x108>
    5ac3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5aca:	0f 87 e8 00 00 00    	ja     5bb8 <fwp_heap_alloc+0x108>
    5ad0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5ad4:	48 8d 05 c5 dc 01 00 	lea    0x1dcc5(%rip),%rax        # 237a0 <fwp_heap>
    5adb:	48 83 ec 18          	sub    $0x18,%rsp
    5adf:	41 89 f0             	mov    %esi,%r8d
    5ae2:	48 c1 e9 04          	shr    $0x4,%rcx
    5ae6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5aed:	00 
    5aee:	48 63 cf             	movslq %edi,%rcx
    5af1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5af8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5aff:	00 
    5b00:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5b04:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5b08:	48 01 c8             	add    %rcx,%rax
    5b0b:	48 8b 08             	mov    (%rax),%rcx
    5b0e:	48 85 c9             	test   %rcx,%rcx
    5b11:	74 6d                	je     5b80 <fwp_heap_alloc+0xd0>
    5b13:	48 8b 31             	mov    (%rcx),%rsi
    5b16:	48 f7 d6             	not    %rsi
    5b19:	48 89 30             	mov    %rsi,(%rax)
    5b1c:	41 83 f8 01          	cmp    $0x1,%r8d
    5b20:	48 89 cf             	mov    %rcx,%rdi
    5b23:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5b28:	49 0f 45 d1          	cmovne %r9,%rdx
    5b2c:	31 f6                	xor    %esi,%esi
    5b2e:	e8 8d d9 ff ff       	call   34c0 <memset@plt>
    5b33:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5b38:	48 89 c1             	mov    %rax,%rcx
    5b3b:	4c 89 c8             	mov    %r9,%rax
    5b3e:	48 03 05 7b f0 01 00 	add    0x1f07b(%rip),%rax        # 24bc0 <fwp_heap+0x1420>
    5b45:	72 7b                	jb     5bc2 <fwp_heap_alloc+0x112>
    5b47:	48 39 05 7a f0 01 00 	cmp    %rax,0x1f07a(%rip)        # 24bc8 <fwp_heap+0x1428>
    5b4e:	48 89 05 6b f0 01 00 	mov    %rax,0x1f06b(%rip)        # 24bc0 <fwp_heap+0x1420>
    5b55:	73 07                	jae    5b5e <fwp_heap_alloc+0xae>
    5b57:	48 89 05 6a f0 01 00 	mov    %rax,0x1f06a(%rip)        # 24bc8 <fwp_heap+0x1428>
    5b5e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b62:	48 89 c8             	mov    %rcx,%rax
    5b65:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b6a:	f2 0f 58 05 66 f0 01 	addsd  0x1f066(%rip),%xmm0        # 24bd8 <fwp_heap+0x1438>
    5b71:	00 
    5b72:	f2 0f 11 05 5e f0 01 	movsd  %xmm0,0x1f05e(%rip)        # 24bd8 <fwp_heap+0x1438>
    5b79:	00 
    5b7a:	48 83 c4 18          	add    $0x18,%rsp
    5b7e:	c3                   	ret
    5b7f:	90                   	nop
    5b80:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b84:	48 85 c9             	test   %rcx,%rcx
    5b87:	74 0c                	je     5b95 <fwp_heap_alloc+0xe5>
    5b89:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b8d:	48 29 ce             	sub    %rcx,%rsi
    5b90:	4c 39 ce             	cmp    %r9,%rsi
    5b93:	73 13                	jae    5ba8 <fwp_heap_alloc+0xf8>
    5b95:	89 fe                	mov    %edi,%esi
    5b97:	48 83 c4 18          	add    $0x18,%rsp
    5b9b:	48 89 d7             	mov    %rdx,%rdi
    5b9e:	e9 8d fd ff ff       	jmp    5930 <fwp_heap_alloc_slow>
    5ba3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ba8:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5bac:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5bb0:	e9 67 ff ff ff       	jmp    5b1c <fwp_heap_alloc+0x6c>
    5bb5:	0f 1f 00             	nopl   (%rax)
    5bb8:	89 fe                	mov    %edi,%esi
    5bba:	48 89 d7             	mov    %rdx,%rdi
    5bbd:	e9 6e fd ff ff       	jmp    5930 <fwp_heap_alloc_slow>
    5bc2:	e8 e9 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5bc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bce:	00 00 

0000000000005bd0 <fwp_apply>:
    5bd0:	55                   	push   %rbp
    5bd1:	48 89 f9             	mov    %rdi,%rcx
    5bd4:	48 89 e5             	mov    %rsp,%rbp
    5bd7:	41 57                	push   %r15
    5bd9:	41 56                	push   %r14
    5bdb:	41 55                	push   %r13
    5bdd:	41 89 f5             	mov    %esi,%r13d
    5be0:	41 54                	push   %r12
    5be2:	53                   	push   %rbx
    5be3:	48 83 ec 28          	sub    $0x28,%rsp
    5be7:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5bee:	00 00 
    5bf0:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5bf4:	49 89 d6             	mov    %rdx,%r14
    5bf7:	44 8b 09             	mov    (%rcx),%r9d
    5bfa:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5bfe:	49 89 e0             	mov    %rsp,%r8
    5c01:	49 c1 e1 05          	shl    $0x5,%r9
    5c05:	4c 03 0d ec f7 01 00 	add    0x1f7ec(%rip),%r9        # 253f8 <fwp_fns>
    5c0c:	41 8b 19             	mov    (%r9),%ebx
    5c0f:	45 85 e4             	test   %r12d,%r12d
    5c12:	75 2c                	jne    5c40 <fwp_apply+0x70>
    5c14:	41 39 dd             	cmp    %ebx,%r13d
    5c17:	72 27                	jb     5c40 <fwp_apply+0x70>
    5c19:	85 db                	test   %ebx,%ebx
    5c1b:	0f 84 a7 01 00 00    	je     5dc8 <fwp_apply+0x1f8>
    5c21:	4c 89 f7             	mov    %r14,%rdi
    5c24:	41 ff 51 08          	call   *0x8(%r9)
    5c28:	48 89 c1             	mov    %rax,%rcx
    5c2b:	41 39 dd             	cmp    %ebx,%r13d
    5c2e:	0f 84 6c 01 00 00    	je     5da0 <fwp_apply+0x1d0>
    5c34:	89 d8                	mov    %ebx,%eax
    5c36:	41 29 dd             	sub    %ebx,%r13d
    5c39:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5c3d:	eb b8                	jmp    5bf7 <fwp_apply+0x27>
    5c3f:	90                   	nop
    5c40:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5c45:	41 39 df             	cmp    %ebx,%r15d
    5c48:	0f 82 cc 00 00 00    	jb     5d1a <fwp_apply+0x14a>
    5c4e:	41 89 df             	mov    %ebx,%r15d
    5c51:	b8 01 00 00 00       	mov    $0x1,%eax
    5c56:	48 89 e2             	mov    %rsp,%rdx
    5c59:	45 29 e7             	sub    %r12d,%r15d
    5c5c:	85 db                	test   %ebx,%ebx
    5c5e:	0f 45 c3             	cmovne %ebx,%eax
    5c61:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5c68:	00 
    5c69:	48 c1 e8 04          	shr    $0x4,%rax
    5c6d:	48 c1 e0 04          	shl    $0x4,%rax
    5c71:	48 89 c6             	mov    %rax,%rsi
    5c74:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5c7b:	48 29 f2             	sub    %rsi,%rdx
    5c7e:	48 39 d4             	cmp    %rdx,%rsp
    5c81:	74 15                	je     5c98 <fwp_apply+0xc8>
    5c83:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5c8a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5c91:	00 00 
    5c93:	48 39 d4             	cmp    %rdx,%rsp
    5c96:	75 eb                	jne    5c83 <fwp_apply+0xb3>
    5c98:	25 ff 0f 00 00       	and    $0xfff,%eax
    5c9d:	48 29 c4             	sub    %rax,%rsp
    5ca0:	48 85 c0             	test   %rax,%rax
    5ca3:	0f 85 49 01 00 00    	jne    5df2 <fwp_apply+0x222>
    5ca9:	45 89 e2             	mov    %r12d,%r10d
    5cac:	48 89 e6             	mov    %rsp,%rsi
    5caf:	48 89 e7             	mov    %rsp,%rdi
    5cb2:	31 c0                	xor    %eax,%eax
    5cb4:	49 c1 e2 03          	shl    $0x3,%r10
    5cb8:	45 85 e4             	test   %r12d,%r12d
    5cbb:	74 15                	je     5cd2 <fwp_apply+0x102>
    5cbd:	0f 1f 00             	nopl   (%rax)
    5cc0:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5cc5:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5cc9:	48 83 c0 08          	add    $0x8,%rax
    5ccd:	4c 39 d0             	cmp    %r10,%rax
    5cd0:	75 ee                	jne    5cc0 <fwp_apply+0xf0>
    5cd2:	45 85 ff             	test   %r15d,%r15d
    5cd5:	0f 84 f4 00 00 00    	je     5dcf <fwp_apply+0x1ff>
    5cdb:	44 89 fa             	mov    %r15d,%edx
    5cde:	4c 89 f0             	mov    %r14,%rax
    5ce1:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5ce5:	44 89 e2             	mov    %r12d,%edx
    5ce8:	66 90                	xchg   %ax,%ax
    5cea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5cf1:	00 00 00 00 
    5cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5cfc:	00 00 00 00 
    5d00:	4c 8b 10             	mov    (%rax),%r10
    5d03:	89 d1                	mov    %edx,%ecx
    5d05:	48 83 c0 08          	add    $0x8,%rax
    5d09:	83 c2 01             	add    $0x1,%edx
    5d0c:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5d10:	4c 39 d8             	cmp    %r11,%rax
    5d13:	75 eb                	jne    5d00 <fwp_apply+0x130>
    5d15:	e9 b5 00 00 00       	jmp    5dcf <fwp_apply+0x1ff>
    5d1a:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5d1e:	be 02 00 00 00       	mov    $0x2,%esi
    5d23:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5d27:	48 c1 e7 03          	shl    $0x3,%rdi
    5d2b:	e8 80 fd ff ff       	call   5ab0 <fwp_heap_alloc>
    5d30:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5d34:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5d39:	48 89 c3             	mov    %rax,%rbx
    5d3c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5d40:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5d44:	66 0f d6 00          	movq   %xmm0,(%rax)
    5d48:	45 85 e4             	test   %r12d,%r12d
    5d4b:	74 14                	je     5d61 <fwp_apply+0x191>
    5d4d:	44 89 e2             	mov    %r12d,%edx
    5d50:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5d54:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5d58:	48 c1 e2 03          	shl    $0x3,%rdx
    5d5c:	e8 af d8 ff ff       	call   3610 <memmove@plt>
    5d61:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5d65:	45 85 ed             	test   %r13d,%r13d
    5d68:	74 2e                	je     5d98 <fwp_apply+0x1c8>
    5d6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d71:	00 00 00 00 
    5d75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d7c:	00 00 00 00 
    5d80:	49 8b 16             	mov    (%r14),%rdx
    5d83:	44 89 e0             	mov    %r12d,%eax
    5d86:	49 83 c6 08          	add    $0x8,%r14
    5d8a:	41 83 c4 01          	add    $0x1,%r12d
    5d8e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5d93:	49 39 ce             	cmp    %rcx,%r14
    5d96:	75 e8                	jne    5d80 <fwp_apply+0x1b0>
    5d98:	48 89 d9             	mov    %rbx,%rcx
    5d9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5da0:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5da4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5dab:	00 00 
    5dad:	75 4e                	jne    5dfd <fwp_apply+0x22d>
    5daf:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5db3:	48 89 c8             	mov    %rcx,%rax
    5db6:	5b                   	pop    %rbx
    5db7:	41 5c                	pop    %r12
    5db9:	41 5d                	pop    %r13
    5dbb:	41 5e                	pop    %r14
    5dbd:	41 5f                	pop    %r15
    5dbf:	5d                   	pop    %rbp
    5dc0:	c3                   	ret
    5dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5dc8:	45 31 ff             	xor    %r15d,%r15d
    5dcb:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    5dcf:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    5dd3:	41 ff 51 08          	call   *0x8(%r9)
    5dd7:	48 89 c1             	mov    %rax,%rcx
    5dda:	45 39 fd             	cmp    %r15d,%r13d
    5ddd:	74 c1                	je     5da0 <fwp_apply+0x1d0>
    5ddf:	45 01 e5             	add    %r12d,%r13d
    5de2:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    5de6:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    5dea:	41 29 dd             	sub    %ebx,%r13d
    5ded:	e9 05 fe ff ff       	jmp    5bf7 <fwp_apply+0x27>
    5df2:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    5df8:	e9 ac fe ff ff       	jmp    5ca9 <fwp_apply+0xd9>
    5dfd:	e8 5e d6 ff ff       	call   3460 <__stack_chk_fail@plt>
    5e02:	0f 1f 00             	nopl   (%rax)
    5e05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5e0c:	00 00 00 00 

0000000000005e10 <fwp_p_ad_push>:
    5e10:	41 57                	push   %r15
    5e12:	41 56                	push   %r14
    5e14:	41 55                	push   %r13
    5e16:	49 89 d5             	mov    %rdx,%r13
    5e19:	41 54                	push   %r12
    5e1b:	49 89 fc             	mov    %rdi,%r12
    5e1e:	55                   	push   %rbp
    5e1f:	53                   	push   %rbx
    5e20:	48 83 ec 38          	sub    $0x38,%rsp
    5e24:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5e29:	48 85 ff             	test   %rdi,%rdi
    5e2c:	79 09                	jns    5e37 <fwp_p_ad_push+0x27>
    5e2e:	48 85 d2             	test   %rdx,%rdx
    5e31:	0f 88 a9 01 00 00    	js     5fe0 <fwp_p_ad_push+0x1d0>
    5e37:	48 89 f8             	mov    %rdi,%rax
    5e3a:	48 89 0c 24          	mov    %rcx,(%rsp)
    5e3e:	48 09 d0             	or     %rdx,%rax
    5e41:	0f 89 79 01 00 00    	jns    5fc0 <fwp_p_ad_push+0x1b0>
    5e47:	48 89 f8             	mov    %rdi,%rax
    5e4a:	48 c1 f8 20          	sar    $0x20,%rax
    5e4e:	48 85 ff             	test   %rdi,%rdi
    5e51:	79 24                	jns    5e77 <fwp_p_ad_push+0x67>
    5e53:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5e58:	48 89 d0             	mov    %rdx,%rax
    5e5b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5e62:	00 
    5e63:	49 89 d4             	mov    %rdx,%r12
    5e66:	48 c1 f8 20          	sar    $0x20,%rax
    5e6a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5e71:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5e77:	48 89 c7             	mov    %rax,%rdi
    5e7a:	e8 01 e6 ff ff       	call   4480 <fwp_tape_of>
    5e7f:	48 89 c3             	mov    %rax,%rbx
    5e82:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5e87:	0f 85 76 02 00 00    	jne    6103 <fwp_p_ad_push+0x2f3>
    5e8d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    5e91:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    5e98:	0f 8f 59 02 00 00    	jg     60f7 <fwp_p_ad_push+0x2e7>
    5e9e:	44 89 e0             	mov    %r12d,%eax
    5ea1:	4c 39 f8             	cmp    %r15,%rax
    5ea4:	0f 8d 41 02 00 00    	jge    60eb <fwp_p_ad_push+0x2db>
    5eaa:	4d 85 ed             	test   %r13,%r13
    5ead:	78 0c                	js     5ebb <fwp_p_ad_push+0xab>
    5eaf:	44 89 e8             	mov    %r13d,%eax
    5eb2:	4c 39 f8             	cmp    %r15,%rax
    5eb5:	0f 8d 30 02 00 00    	jge    60eb <fwp_p_ad_push+0x2db>
    5ebb:	4d 89 fe             	mov    %r15,%r14
    5ebe:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5ec2:	49 8d 46 01          	lea    0x1(%r14),%rax
    5ec6:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5ecc:	0f 87 25 02 00 00    	ja     60f7 <fwp_p_ad_push+0x2e7>
    5ed2:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5ed6:	48 39 e8             	cmp    %rbp,%rax
    5ed9:	0f 8e 31 01 00 00    	jle    6010 <fwp_p_ad_push+0x200>
    5edf:	48 85 ed             	test   %rbp,%rbp
    5ee2:	b9 40 00 00 00       	mov    $0x40,%ecx
    5ee7:	48 0f 44 e9          	cmove  %rcx,%rbp
    5eeb:	48 39 e8             	cmp    %rbp,%rax
    5eee:	7e 20                	jle    5f10 <fwp_p_ad_push+0x100>
    5ef0:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5ef7:	0f 8f 03 01 00 00    	jg     6000 <fwp_p_ad_push+0x1f0>
    5efd:	48 01 ed             	add    %rbp,%rbp
    5f00:	48 39 e8             	cmp    %rbp,%rax
    5f03:	7f eb                	jg     5ef0 <fwp_p_ad_push+0xe0>
    5f05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f0c:	00 00 00 00 
    5f10:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5f17:	00 
    5f18:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5f1c:	48 89 c6             	mov    %rax,%rsi
    5f1f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    5f24:	e8 a7 d6 ff ff       	call   35d0 <realloc@plt>
    5f29:	48 85 c0             	test   %rax,%rax
    5f2c:	0f 84 dd 01 00 00    	je     610f <fwp_p_ad_push+0x2ff>
    5f32:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    5f36:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    5f3a:	48 89 43 20          	mov    %rax,0x20(%rbx)
    5f3e:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    5f42:	48 89 e9             	mov    %rbp,%rcx
    5f45:	48 89 43 28          	mov    %rax,0x28(%rbx)
    5f49:	48 c1 e1 04          	shl    $0x4,%rcx
    5f4d:	48 89 ce             	mov    %rcx,%rsi
    5f50:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    5f55:	e8 76 d6 ff ff       	call   35d0 <realloc@plt>
    5f5a:	48 85 c0             	test   %rax,%rax
    5f5d:	0f 84 ac 01 00 00    	je     610f <fwp_p_ad_push+0x2ff>
    5f63:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    5f67:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5f6c:	4d 85 f6             	test   %r14,%r14
    5f6f:	48 89 43 30          	mov    %rax,0x30(%rbx)
    5f73:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    5f78:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5f7f:	00 
    5f80:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5f87:	00 
    5f88:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    5f8c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    5f93:	00 
    5f94:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    5f98:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    5f9c:	0f 85 e2 00 00 00    	jne    6084 <fwp_p_ad_push+0x274>
    5fa2:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    5fa6:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5faa:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    5fae:	49 01 c8             	add    %rcx,%r8
    5fb1:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    5fb5:	eb 79                	jmp    6030 <fwp_p_ad_push+0x220>
    5fb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5fbe:	00 00 
    5fc0:	48 89 d0             	mov    %rdx,%rax
    5fc3:	48 c1 ff 20          	sar    $0x20,%rdi
    5fc7:	48 c1 f8 20          	sar    $0x20,%rax
    5fcb:	48 39 c7             	cmp    %rax,%rdi
    5fce:	0f 84 a3 fe ff ff    	je     5e77 <fwp_p_ad_push+0x67>
    5fd4:	48 8d 3d e5 97 00 00 	lea    0x97e5(%rip),%rdi        # f7c0 <_IO_stdin_used+0x7c0>
    5fdb:	e8 c0 e1 ff ff       	call   41a0 <fwp_trap>
    5fe0:	48 83 c4 38          	add    $0x38,%rsp
    5fe4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5feb:	5b                   	pop    %rbx
    5fec:	5d                   	pop    %rbp
    5fed:	41 5c                	pop    %r12
    5fef:	41 5d                	pop    %r13
    5ff1:	41 5e                	pop    %r14
    5ff3:	41 5f                	pop    %r15
    5ff5:	c3                   	ret
    5ff6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5ffd:	00 00 00 
    6000:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    6005:	e9 06 ff ff ff       	jmp    5f10 <fwp_p_ad_push+0x100>
    600a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6010:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    6014:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6018:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    601f:	00 
    6020:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6027:	00 
    6028:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    602c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6030:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6036:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    603a:	4d 85 ed             	test   %r13,%r13
    603d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6042:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6048:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    604f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6053:	49 8d 47 01          	lea    0x1(%r15),%rax
    6057:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    605b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6061:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6065:	48 83 c4 38          	add    $0x38,%rsp
    6069:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6070:	ff ff ff 
    6073:	4c 21 e0             	and    %r12,%rax
    6076:	5b                   	pop    %rbx
    6077:	5d                   	pop    %rbp
    6078:	4c 09 f8             	or     %r15,%rax
    607b:	41 5c                	pop    %r12
    607d:	41 5d                	pop    %r13
    607f:	41 5e                	pop    %r14
    6081:	41 5f                	pop    %r15
    6083:	c3                   	ret
    6084:	48 39 ca             	cmp    %rcx,%rdx
    6087:	49 89 d6             	mov    %rdx,%r14
    608a:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    608f:	48 0f 43 ca          	cmovae %rdx,%rcx
    6093:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    6098:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    609d:	48 29 d1             	sub    %rdx,%rcx
    60a0:	4c 89 ca             	mov    %r9,%rdx
    60a3:	e8 b8 d4 ff ff       	call   3560 <__memmove_chk@plt>
    60a8:	4c 03 73 30          	add    0x30(%rbx),%r14
    60ac:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    60b1:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    60b5:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    60ba:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    60be:	48 03 7b 20          	add    0x20(%rbx),%rdi
    60c2:	4c 89 d2             	mov    %r10,%rdx
    60c5:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    60ca:	e8 41 d5 ff ff       	call   3610 <memmove@plt>
    60cf:	48 8b 43 30          	mov    0x30(%rbx),%rax
    60d3:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    60d7:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    60dc:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    60e1:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    60e6:	e9 bb fe ff ff       	jmp    5fa6 <fwp_p_ad_push+0x196>
    60eb:	48 8d 3d 12 90 00 00 	lea    0x9012(%rip),%rdi        # f104 <_IO_stdin_used+0x104>
    60f2:	e8 a9 e0 ff ff       	call   41a0 <fwp_trap>
    60f7:	48 8d 3d eb 8f 00 00 	lea    0x8feb(%rip),%rdi        # f0e9 <_IO_stdin_used+0xe9>
    60fe:	e8 9d e0 ff ff       	call   41a0 <fwp_trap>
    6103:	48 8d 3d fe 96 00 00 	lea    0x96fe(%rip),%rdi        # f808 <_IO_stdin_used+0x808>
    610a:	e8 91 e0 ff ff       	call   41a0 <fwp_trap>
    610f:	48 89 df             	mov    %rbx,%rdi
    6112:	e8 e9 da ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6117:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    611b:	e8 a0 d2 ff ff       	call   33c0 <free@plt>
    6120:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6124:	e8 97 d2 ff ff       	call   33c0 <free@plt>
    6129:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    612d:	e8 8e d2 ff ff       	call   33c0 <free@plt>
    6132:	31 c9                	xor    %ecx,%ecx
    6134:	31 c0                	xor    %eax,%eax
    6136:	31 d2                	xor    %edx,%edx
    6138:	89 53 04             	mov    %edx,0x4(%rbx)
    613b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    613f:	ba 13 00 00 00       	mov    $0x13,%edx
    6144:	be 01 00 00 00       	mov    $0x1,%esi
    6149:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    614d:	48 8d 3d b4 8e 00 00 	lea    0x8eb4(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    6154:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6158:	48 8b 0d 01 cf 00 00 	mov    0xcf01(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    615f:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6163:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    6167:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    616b:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    616f:	e8 0c d5 ff ff       	call   3680 <fwrite@plt>
    6174:	31 ff                	xor    %edi,%edi
    6176:	e8 45 d4 ff ff       	call   35c0 <fflush@plt>
    617b:	bf 66 00 00 00       	mov    $0x66,%edi
    6180:	e8 1b d5 ff ff       	call   36a0 <_Exit@plt>
    6185:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    618c:	00 00 00 00 

0000000000006190 <w107>:
    6190:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6194:	41 55                	push   %r13
    6196:	48 89 fa             	mov    %rdi,%rdx
    6199:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    619d:	41 54                	push   %r12
    619f:	49 89 fc             	mov    %rdi,%r12
    61a2:	55                   	push   %rbp
    61a3:	53                   	push   %rbx
    61a4:	48 89 f3             	mov    %rsi,%rbx
    61a7:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    61ac:	48 89 f1             	mov    %rsi,%rcx
    61af:	48 83 ec 28          	sub    $0x28,%rsp
    61b3:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    61b9:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    61bf:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    61c5:	e8 46 fc ff ff       	call   5e10 <fwp_p_ad_push>
    61ca:	48 89 c7             	mov    %rax,%rdi
    61cd:	e8 4e eb ff ff       	call   4d20 <caf61>
    61d2:	66 48 0f 6e c0       	movq   %rax,%xmm0
    61d7:	e8 44 eb ff ff       	call   4d20 <caf61>
    61dc:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    61e2:	66 0f 57 05 16 99 00 	xorpd  0x9916(%rip),%xmm0        # fb00 <msg.8+0x80>
    61e9:	00 
    61ea:	48 89 da             	mov    %rbx,%rdx
    61ed:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    61f3:	48 89 c1             	mov    %rax,%rcx
    61f6:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    61fb:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6200:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6206:	e8 05 fc ff ff       	call   5e10 <fwp_p_ad_push>
    620b:	4c 89 e7             	mov    %r12,%rdi
    620e:	49 89 c5             	mov    %rax,%r13
    6211:	e8 0a eb ff ff       	call   4d20 <caf61>
    6216:	48 89 c6             	mov    %rax,%rsi
    6219:	e8 02 eb ff ff       	call   4d20 <caf61>
    621e:	66 48 0f 6e d6       	movq   %rsi,%xmm2
    6223:	f2 0f 10 05 15 99 00 	movsd  0x9915(%rip),%xmm0        # fb40 <msg.8+0xc0>
    622a:	00 
    622b:	66 0f 57 15 cd 98 00 	xorpd  0x98cd(%rip),%xmm2        # fb00 <msg.8+0x80>
    6232:	00 
    6233:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    6239:	48 89 c1             	mov    %rax,%rcx
    623c:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6243:	66 48 0f 7e d6       	movq   %xmm2,%rsi
    6248:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    624d:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6253:	e8 b8 fb ff ff       	call   5e10 <fwp_p_ad_push>
    6258:	48 89 e9             	mov    %rbp,%rcx
    625b:	4c 89 ea             	mov    %r13,%rdx
    625e:	48 89 ee             	mov    %rbp,%rsi
    6261:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6267:	4c 89 ef             	mov    %r13,%rdi
    626a:	49 89 c4             	mov    %rax,%r12
    626d:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6271:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6277:	e8 94 fb ff ff       	call   5e10 <fwp_p_ad_push>
    627c:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6282:	f2 0f 59 1d be 98 00 	mulsd  0x98be(%rip),%xmm3        # fb48 <msg.8+0xc8>
    6289:	00 
    628a:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6291:	00 59 40 
    6294:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6299:	48 89 c2             	mov    %rax,%rdx
    629c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    62a3:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    62a9:	e8 62 fb ff ff       	call   5e10 <fwp_p_ad_push>
    62ae:	4c 89 e2             	mov    %r12,%rdx
    62b1:	48 89 d9             	mov    %rbx,%rcx
    62b4:	48 89 de             	mov    %rbx,%rsi
    62b7:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    62bd:	4c 89 e7             	mov    %r12,%rdi
    62c0:	48 89 c5             	mov    %rax,%rbp
    62c3:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    62c7:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    62cd:	e8 3e fb ff ff       	call   5e10 <fwp_p_ad_push>
    62d2:	48 89 c7             	mov    %rax,%rdi
    62d5:	e8 46 ea ff ff       	call   4d20 <caf61>
    62da:	48 89 c6             	mov    %rax,%rsi
    62dd:	e8 3e ea ff ff       	call   4d20 <caf61>
    62e2:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    62e8:	48 89 ea             	mov    %rbp,%rdx
    62eb:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    62f1:	48 89 c1             	mov    %rax,%rcx
    62f4:	66 48 0f 7e db       	movq   %xmm3,%rbx
    62f9:	e8 12 fb ff ff       	call   5e10 <fwp_p_ad_push>
    62fe:	48 83 c4 28          	add    $0x28,%rsp
    6302:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    6307:	5b                   	pop    %rbx
    6308:	5d                   	pop    %rbp
    6309:	41 5c                	pop    %r12
    630b:	41 5d                	pop    %r13
    630d:	c3                   	ret
    630e:	66 90                	xchg   %ax,%ax

0000000000006310 <w164.constprop.0>:
    6310:	41 54                	push   %r12
    6312:	55                   	push   %rbp
    6313:	53                   	push   %rbx
    6314:	48 83 ec 10          	sub    $0x10,%rsp
    6318:	4c 8b 27             	mov    (%rdi),%r12
    631b:	4d 85 e4             	test   %r12,%r12
    631e:	74 78                	je     6398 <w164.constprop.0+0x88>
    6320:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    6327:	00 00 
    6329:	48 89 fd             	mov    %rdi,%rbp
    632c:	31 db                	xor    %ebx,%ebx
    632e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    633c:	00 00 00 00 
    6340:	4c 8b 44 dd 10       	mov    0x10(%rbp,%rbx,8),%r8
    6345:	f2 0f 10 44 dd 08    	movsd  0x8(%rbp,%rbx,8),%xmm0
    634b:	48 83 c3 02          	add    $0x2,%rbx
    634f:	e8 cc e9 ff ff       	call   4d20 <caf61>
    6354:	48 89 c6             	mov    %rax,%rsi
    6357:	e8 c4 e9 ff ff       	call   4d20 <caf61>
    635c:	f2 0f 58 44 24 08    	addsd  0x8(%rsp),%xmm0
    6362:	4c 89 c2             	mov    %r8,%rdx
    6365:	48 89 c1             	mov    %rax,%rcx
    6368:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    636e:	e8 9d fa ff ff       	call   5e10 <fwp_p_ad_push>
    6373:	48 89 c7             	mov    %rax,%rdi
    6376:	4c 39 e3             	cmp    %r12,%rbx
    6379:	72 c5                	jb     6340 <w164.constprop.0+0x30>
    637b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6380:	48 83 c4 10          	add    $0x10,%rsp
    6384:	5b                   	pop    %rbx
    6385:	5d                   	pop    %rbp
    6386:	66 48 0f 6e c0       	movq   %rax,%xmm0
    638b:	41 5c                	pop    %r12
    638d:	48 89 f8             	mov    %rdi,%rax
    6390:	c3                   	ret
    6391:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6398:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    639f:	00 00 
    63a1:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    63a8:	eb d1                	jmp    637b <w164.constprop.0+0x6b>
    63aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000063b0 <fwp_data.part.0.constprop.0>:
    63b0:	41 56                	push   %r14
    63b2:	41 89 fe             	mov    %edi,%r14d
    63b5:	41 54                	push   %r12
    63b7:	49 89 f4             	mov    %rsi,%r12
    63ba:	55                   	push   %rbp
    63bb:	53                   	push   %rbx
    63bc:	48 83 ec 08          	sub    $0x8,%rsp
    63c0:	8b 05 7e e7 01 00    	mov    0x1e77e(%rip),%eax        # 24b44 <fwp_heap+0x13a4>
    63c6:	85 c0                	test   %eax,%eax
    63c8:	0f 84 fa 00 00 00    	je     64c8 <fwp_data.part.0.constprop.0+0x118>
    63ce:	0f b6 05 6d e3 01 00 	movzbl 0x1e36d(%rip),%eax        # 24742 <fwp_heap+0xfa2>
    63d5:	48 8d 15 c4 d3 01 00 	lea    0x1d3c4(%rip),%rdx        # 237a0 <fwp_heap>
    63dc:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    63e3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    63e7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    63eb:	48 8b 18             	mov    (%rax),%rbx
    63ee:	48 85 db             	test   %rbx,%rbx
    63f1:	0f 84 a9 00 00 00    	je     64a0 <fwp_data.part.0.constprop.0+0xf0>
    63f7:	48 8b 13             	mov    (%rbx),%rdx
    63fa:	48 f7 d2             	not    %rdx
    63fd:	48 89 10             	mov    %rdx,(%rax)
    6400:	48 83 fd 18          	cmp    $0x18,%rbp
    6404:	76 1b                	jbe    6421 <fwp_data.part.0.constprop.0+0x71>
    6406:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    640a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    640e:	31 f6                	xor    %esi,%esi
    6410:	48 c1 e8 03          	shr    $0x3,%rax
    6414:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    641b:	00 
    641c:	e8 9f d0 ff ff       	call   34c0 <memset@plt>
    6421:	48 89 e8             	mov    %rbp,%rax
    6424:	48 03 05 95 e7 01 00 	add    0x1e795(%rip),%rax        # 24bc0 <fwp_heap+0x1420>
    642b:	0f 82 a8 00 00 00    	jb     64d9 <fwp_data.part.0.constprop.0+0x129>
    6431:	48 39 05 90 e7 01 00 	cmp    %rax,0x1e790(%rip)        # 24bc8 <fwp_heap+0x1428>
    6438:	48 89 05 81 e7 01 00 	mov    %rax,0x1e781(%rip)        # 24bc0 <fwp_heap+0x1420>
    643f:	73 07                	jae    6448 <fwp_data.part.0.constprop.0+0x98>
    6441:	48 89 05 80 e7 01 00 	mov    %rax,0x1e780(%rip)        # 24bc8 <fwp_heap+0x1428>
    6448:	66 0f ef c0          	pxor   %xmm0,%xmm0
    644c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6451:	f2 0f 58 05 7f e7 01 	addsd  0x1e77f(%rip),%xmm0        # 24bd8 <fwp_heap+0x1438>
    6458:	00 
    6459:	f2 0f 11 05 77 e7 01 	movsd  %xmm0,0x1e777(%rip)        # 24bd8 <fwp_heap+0x1438>
    6460:	00 
    6461:	b8 02 00 00 00       	mov    $0x2,%eax
    6466:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    646b:	66 0f 6e c8          	movd   %eax,%xmm1
    646f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6473:	66 0f d6 03          	movq   %xmm0,(%rbx)
    6477:	49 8b 04 24          	mov    (%r12),%rax
    647b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    647f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6484:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6488:	48 83 c4 08          	add    $0x8,%rsp
    648c:	48 89 d8             	mov    %rbx,%rax
    648f:	5b                   	pop    %rbx
    6490:	5d                   	pop    %rbp
    6491:	41 5c                	pop    %r12
    6493:	41 5e                	pop    %r14
    6495:	c3                   	ret
    6496:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    649d:	00 00 00 
    64a0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    64a4:	48 85 db             	test   %rbx,%rbx
    64a7:	74 1f                	je     64c8 <fwp_data.part.0.constprop.0+0x118>
    64a9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    64ad:	48 29 da             	sub    %rbx,%rdx
    64b0:	48 39 ea             	cmp    %rbp,%rdx
    64b3:	72 13                	jb     64c8 <fwp_data.part.0.constprop.0+0x118>
    64b5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    64b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    64bd:	e9 3e ff ff ff       	jmp    6400 <fwp_data.part.0.constprop.0+0x50>
    64c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    64c8:	31 f6                	xor    %esi,%esi
    64ca:	bf 18 00 00 00       	mov    $0x18,%edi
    64cf:	e8 dc f5 ff ff       	call   5ab0 <fwp_heap_alloc>
    64d4:	48 89 c3             	mov    %rax,%rbx
    64d7:	eb 88                	jmp    6461 <fwp_data.part.0.constprop.0+0xb1>
    64d9:	e8 d2 d7 ff ff       	call   3cb0 <fwp_heap_oom>
    64de:	66 90                	xchg   %ax,%ax

00000000000064e0 <fwp_rc_share>:
    64e0:	48 8b 05 91 e6 01 00 	mov    0x1e691(%rip),%rax        # 24b78 <fwp_heap+0x13d8>
    64e7:	48 2b 3d 62 e6 01 00 	sub    0x1e662(%rip),%rdi        # 24b50 <fwp_heap+0x13b0>
    64ee:	48 c1 e0 10          	shl    $0x10,%rax
    64f2:	48 39 c7             	cmp    %rax,%rdi
    64f5:	73 4a                	jae    6541 <fwp_rc_share+0x61>
    64f7:	48 89 f8             	mov    %rdi,%rax
    64fa:	48 c1 e8 10          	shr    $0x10,%rax
    64fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6502:	48 8b 05 8f e6 01 00 	mov    0x1e68f(%rip),%rax        # 24b98 <fwp_heap+0x13f8>
    6509:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    650d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6511:	48 85 d2             	test   %rdx,%rdx
    6514:	74 2b                	je     6541 <fwp_rc_share+0x61>
    6516:	0f b6 08             	movzbl (%rax),%ecx
    6519:	80 f9 02             	cmp    $0x2,%cl
    651c:	74 2a                	je     6548 <fwp_rc_share+0x68>
    651e:	80 f9 01             	cmp    $0x1,%cl
    6521:	75 1e                	jne    6541 <fwp_rc_share+0x61>
    6523:	8b 48 18             	mov    0x18(%rax),%ecx
    6526:	0f b7 ff             	movzwl %di,%edi
    6529:	8b 40 1c             	mov    0x1c(%rax),%eax
    652c:	48 0f af f9          	imul   %rcx,%rdi
    6530:	48 c1 ef 20          	shr    $0x20,%rdi
    6534:	48 39 c7             	cmp    %rax,%rdi
    6537:	73 08                	jae    6541 <fwp_rc_share+0x61>
    6539:	48 01 fa             	add    %rdi,%rdx
    653c:	80 3a 00             	cmpb   $0x0,(%rdx)
    653f:	75 0d                	jne    654e <fwp_rc_share+0x6e>
    6541:	c3                   	ret
    6542:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6548:	66 85 ff             	test   %di,%di
    654b:	74 ef                	je     653c <fwp_rc_share+0x5c>
    654d:	c3                   	ret
    654e:	50                   	push   %rax
    654f:	48 8d 3d e2 92 00 00 	lea    0x92e2(%rip),%rdi        # f838 <_IO_stdin_used+0x838>
    6556:	e8 45 dc ff ff       	call   41a0 <fwp_trap>
    655b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006560 <fwp_rc_fresh>:
    6560:	48 8b 15 11 e6 01 00 	mov    0x1e611(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    6567:	48 89 f8             	mov    %rdi,%rax
    656a:	48 89 fe             	mov    %rdi,%rsi
    656d:	48 2b 05 dc e5 01 00 	sub    0x1e5dc(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    6574:	48 c1 e2 10          	shl    $0x10,%rdx
    6578:	48 39 d0             	cmp    %rdx,%rax
    657b:	73 4f                	jae    65cc <fwp_rc_fresh+0x6c>
    657d:	48 89 c2             	mov    %rax,%rdx
    6580:	48 c1 ea 10          	shr    $0x10,%rdx
    6584:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6588:	48 8b 15 09 e6 01 00 	mov    0x1e609(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    658f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6593:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6597:	48 85 d2             	test   %rdx,%rdx
    659a:	74 30                	je     65cc <fwp_rc_fresh+0x6c>
    659c:	0f b6 39             	movzbl (%rcx),%edi
    659f:	40 80 ff 02          	cmp    $0x2,%dil
    65a3:	74 2b                	je     65d0 <fwp_rc_fresh+0x70>
    65a5:	40 80 ff 01          	cmp    $0x1,%dil
    65a9:	75 21                	jne    65cc <fwp_rc_fresh+0x6c>
    65ab:	8b 79 18             	mov    0x18(%rcx),%edi
    65ae:	0f b7 c0             	movzwl %ax,%eax
    65b1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    65b4:	48 0f af c7          	imul   %rdi,%rax
    65b8:	48 c1 e8 20          	shr    $0x20,%rax
    65bc:	48 39 c8             	cmp    %rcx,%rax
    65bf:	73 0b                	jae    65cc <fwp_rc_fresh+0x6c>
    65c1:	48 01 c2             	add    %rax,%rdx
    65c4:	80 3a ff             	cmpb   $0xff,(%rdx)
    65c7:	74 17                	je     65e0 <fwp_rc_fresh+0x80>
    65c9:	c6 02 01             	movb   $0x1,(%rdx)
    65cc:	48 89 f0             	mov    %rsi,%rax
    65cf:	c3                   	ret
    65d0:	66 85 c0             	test   %ax,%ax
    65d3:	74 ef                	je     65c4 <fwp_rc_fresh+0x64>
    65d5:	48 89 f0             	mov    %rsi,%rax
    65d8:	c3                   	ret
    65d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    65e0:	48 83 ec 18          	sub    $0x18,%rsp
    65e4:	48 89 d7             	mov    %rdx,%rdi
    65e7:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    65ec:	48 89 14 24          	mov    %rdx,(%rsp)
    65f0:	e8 7b ed ff ff       	call   5370 <fwp_rc_forget_slot>
    65f5:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    65fa:	48 8b 14 24          	mov    (%rsp),%rdx
    65fe:	48 89 f0             	mov    %rsi,%rax
    6601:	c6 02 01             	movb   $0x1,(%rdx)
    6604:	48 83 c4 18          	add    $0x18,%rsp
    6608:	c3                   	ret
    6609:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006610 <fwp_rc_free_arr>:
    6610:	48 8b 15 61 e5 01 00 	mov    0x1e561(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    6617:	48 89 f8             	mov    %rdi,%rax
    661a:	48 2b 05 2f e5 01 00 	sub    0x1e52f(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    6621:	48 c1 e2 10          	shl    $0x10,%rdx
    6625:	48 39 d0             	cmp    %rdx,%rax
    6628:	73 5b                	jae    6685 <fwp_rc_free_arr+0x75>
    662a:	48 89 c2             	mov    %rax,%rdx
    662d:	48 c1 ea 10          	shr    $0x10,%rdx
    6631:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6635:	48 8b 15 5c e5 01 00 	mov    0x1e55c(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    663c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6640:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6644:	48 85 c9             	test   %rcx,%rcx
    6647:	74 3c                	je     6685 <fwp_rc_free_arr+0x75>
    6649:	0f b6 32             	movzbl (%rdx),%esi
    664c:	40 80 fe 02          	cmp    $0x2,%sil
    6650:	74 2e                	je     6680 <fwp_rc_free_arr+0x70>
    6652:	40 80 fe 01          	cmp    $0x1,%sil
    6656:	75 2d                	jne    6685 <fwp_rc_free_arr+0x75>
    6658:	8b 72 18             	mov    0x18(%rdx),%esi
    665b:	0f b7 c0             	movzwl %ax,%eax
    665e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6661:	48 0f af c6          	imul   %rsi,%rax
    6665:	48 c1 e8 20          	shr    $0x20,%rax
    6669:	48 39 d0             	cmp    %rdx,%rax
    666c:	73 17                	jae    6685 <fwp_rc_free_arr+0x75>
    666e:	48 01 c1             	add    %rax,%rcx
    6671:	80 39 01             	cmpb   $0x1,(%rcx)
    6674:	75 0f                	jne    6685 <fwp_rc_free_arr+0x75>
    6676:	e9 35 ef ff ff       	jmp    55b0 <fwp_mem_free>
    667b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6680:	66 85 c0             	test   %ax,%ax
    6683:	74 ec                	je     6671 <fwp_rc_free_arr+0x61>
    6685:	c3                   	ret
    6686:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    668d:	00 00 00 

0000000000006690 <fwp_rc_dup>:
    6690:	f3 0f 1e fa          	endbr64
    6694:	48 8b 05 dd e4 01 00 	mov    0x1e4dd(%rip),%rax        # 24b78 <fwp_heap+0x13d8>
    669b:	48 2b 3d ae e4 01 00 	sub    0x1e4ae(%rip),%rdi        # 24b50 <fwp_heap+0x13b0>
    66a2:	48 c1 e0 10          	shl    $0x10,%rax
    66a6:	48 39 c7             	cmp    %rax,%rdi
    66a9:	73 56                	jae    6701 <fwp_rc_dup+0x71>
    66ab:	48 89 f8             	mov    %rdi,%rax
    66ae:	48 c1 e8 10          	shr    $0x10,%rax
    66b2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    66b6:	48 8b 05 db e4 01 00 	mov    0x1e4db(%rip),%rax        # 24b98 <fwp_heap+0x13f8>
    66bd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    66c1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    66c5:	48 85 c0             	test   %rax,%rax
    66c8:	74 37                	je     6701 <fwp_rc_dup+0x71>
    66ca:	0f b6 0a             	movzbl (%rdx),%ecx
    66cd:	80 f9 02             	cmp    $0x2,%cl
    66d0:	74 36                	je     6708 <fwp_rc_dup+0x78>
    66d2:	80 f9 01             	cmp    $0x1,%cl
    66d5:	75 2a                	jne    6701 <fwp_rc_dup+0x71>
    66d7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    66da:	0f b7 ff             	movzwl %di,%edi
    66dd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    66e0:	48 0f af f9          	imul   %rcx,%rdi
    66e4:	48 c1 ef 20          	shr    $0x20,%rdi
    66e8:	48 39 d7             	cmp    %rdx,%rdi
    66eb:	73 14                	jae    6701 <fwp_rc_dup+0x71>
    66ed:	48 01 f8             	add    %rdi,%rax
    66f0:	0f b6 10             	movzbl (%rax),%edx
    66f3:	84 d2                	test   %dl,%dl
    66f5:	74 0a                	je     6701 <fwp_rc_dup+0x71>
    66f7:	80 fa fd             	cmp    $0xfd,%dl
    66fa:	77 14                	ja     6710 <fwp_rc_dup+0x80>
    66fc:	83 c2 01             	add    $0x1,%edx
    66ff:	88 10                	mov    %dl,(%rax)
    6701:	c3                   	ret
    6702:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6708:	66 85 ff             	test   %di,%di
    670b:	74 e3                	je     66f0 <fwp_rc_dup+0x60>
    670d:	c3                   	ret
    670e:	66 90                	xchg   %ax,%ax
    6710:	48 89 c7             	mov    %rax,%rdi
    6713:	e9 38 eb ff ff       	jmp    5250 <fwp_rc_wide_dup>
    6718:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    671f:	00 

0000000000006720 <fwp_owned_entry161>:
    6720:	f3 0f 1e fa          	endbr64
    6724:	48 83 ec 38          	sub    $0x38,%rsp
    6728:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    672d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6734:	00 00 
    6736:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    673b:	31 c0                	xor    %eax,%eax
    673d:	48 8b 07             	mov    (%rdi),%rax
    6740:	48 03 47 10          	add    0x10(%rdi),%rax
    6744:	0f 80 c2 00 00 00    	jo     680c <fwp_owned_entry161+0xec>
    674a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    674f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6754:	31 ff                	xor    %edi,%edi
    6756:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    675a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    675f:	e8 4c fc ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    6764:	48 8b 15 0d e4 01 00 	mov    0x1e40d(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    676b:	48 89 c6             	mov    %rax,%rsi
    676e:	48 2b 05 db e3 01 00 	sub    0x1e3db(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    6775:	48 c1 e2 10          	shl    $0x10,%rdx
    6779:	48 39 d0             	cmp    %rdx,%rax
    677c:	73 4f                	jae    67cd <fwp_owned_entry161+0xad>
    677e:	48 89 c2             	mov    %rax,%rdx
    6781:	48 c1 ea 10          	shr    $0x10,%rdx
    6785:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6789:	48 8b 15 08 e4 01 00 	mov    0x1e408(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    6790:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6794:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6798:	48 85 d2             	test   %rdx,%rdx
    679b:	74 30                	je     67cd <fwp_owned_entry161+0xad>
    679d:	0f b6 39             	movzbl (%rcx),%edi
    67a0:	40 80 ff 02          	cmp    $0x2,%dil
    67a4:	74 42                	je     67e8 <fwp_owned_entry161+0xc8>
    67a6:	40 80 ff 01          	cmp    $0x1,%dil
    67aa:	75 21                	jne    67cd <fwp_owned_entry161+0xad>
    67ac:	8b 79 18             	mov    0x18(%rcx),%edi
    67af:	0f b7 c0             	movzwl %ax,%eax
    67b2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    67b5:	48 0f af c7          	imul   %rdi,%rax
    67b9:	48 c1 e8 20          	shr    $0x20,%rax
    67bd:	48 39 c8             	cmp    %rcx,%rax
    67c0:	73 0b                	jae    67cd <fwp_owned_entry161+0xad>
    67c2:	48 01 c2             	add    %rax,%rdx
    67c5:	80 3a ff             	cmpb   $0xff,(%rdx)
    67c8:	74 26                	je     67f0 <fwp_owned_entry161+0xd0>
    67ca:	c6 02 01             	movb   $0x1,(%rdx)
    67cd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    67d2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    67d9:	00 00 
    67db:	75 34                	jne    6811 <fwp_owned_entry161+0xf1>
    67dd:	48 89 f0             	mov    %rsi,%rax
    67e0:	48 83 c4 38          	add    $0x38,%rsp
    67e4:	c3                   	ret
    67e5:	0f 1f 00             	nopl   (%rax)
    67e8:	66 85 c0             	test   %ax,%ax
    67eb:	75 e0                	jne    67cd <fwp_owned_entry161+0xad>
    67ed:	eb d6                	jmp    67c5 <fwp_owned_entry161+0xa5>
    67ef:	90                   	nop
    67f0:	48 89 d7             	mov    %rdx,%rdi
    67f3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    67f8:	48 89 14 24          	mov    %rdx,(%rsp)
    67fc:	e8 6f eb ff ff       	call   5370 <fwp_rc_forget_slot>
    6801:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6806:	48 8b 14 24          	mov    (%rsp),%rdx
    680a:	eb be                	jmp    67ca <fwp_owned_entry161+0xaa>
    680c:	e8 ef ce ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6811:	e8 4a cc ff ff       	call   3460 <__stack_chk_fail@plt>
    6816:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    681d:	00 00 00 

0000000000006820 <e161>:
    6820:	f3 0f 1e fa          	endbr64
    6824:	53                   	push   %rbx
    6825:	48 83 ec 30          	sub    $0x30,%rsp
    6829:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    682e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6835:	00 00 
    6837:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    683c:	31 c0                	xor    %eax,%eax
    683e:	48 8b 07             	mov    (%rdi),%rax
    6841:	48 03 47 10          	add    0x10(%rdi),%rax
    6845:	0f 80 c9 00 00 00    	jo     6914 <e161+0xf4>
    684b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6850:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6855:	31 ff                	xor    %edi,%edi
    6857:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    685b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6860:	e8 4b fb ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    6865:	48 8b 15 0c e3 01 00 	mov    0x1e30c(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    686c:	48 89 c3             	mov    %rax,%rbx
    686f:	48 2b 05 da e2 01 00 	sub    0x1e2da(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    6876:	48 c1 e2 10          	shl    $0x10,%rdx
    687a:	48 39 d0             	cmp    %rdx,%rax
    687d:	73 4f                	jae    68ce <e161+0xae>
    687f:	48 89 c2             	mov    %rax,%rdx
    6882:	48 c1 ea 10          	shr    $0x10,%rdx
    6886:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    688a:	48 8b 15 07 e3 01 00 	mov    0x1e307(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    6891:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6895:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6899:	48 85 d2             	test   %rdx,%rdx
    689c:	74 30                	je     68ce <e161+0xae>
    689e:	0f b6 31             	movzbl (%rcx),%esi
    68a1:	40 80 fe 02          	cmp    $0x2,%sil
    68a5:	74 49                	je     68f0 <e161+0xd0>
    68a7:	40 80 fe 01          	cmp    $0x1,%sil
    68ab:	75 21                	jne    68ce <e161+0xae>
    68ad:	8b 71 18             	mov    0x18(%rcx),%esi
    68b0:	0f b7 c0             	movzwl %ax,%eax
    68b3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    68b6:	48 0f af c6          	imul   %rsi,%rax
    68ba:	48 c1 e8 20          	shr    $0x20,%rax
    68be:	48 39 c8             	cmp    %rcx,%rax
    68c1:	73 0b                	jae    68ce <e161+0xae>
    68c3:	48 01 c2             	add    %rax,%rdx
    68c6:	80 3a ff             	cmpb   $0xff,(%rdx)
    68c9:	74 35                	je     6900 <e161+0xe0>
    68cb:	c6 02 01             	movb   $0x1,(%rdx)
    68ce:	48 89 df             	mov    %rbx,%rdi
    68d1:	e8 0a fc ff ff       	call   64e0 <fwp_rc_share>
    68d6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    68db:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    68e2:	00 00 
    68e4:	75 33                	jne    6919 <e161+0xf9>
    68e6:	48 83 c4 30          	add    $0x30,%rsp
    68ea:	48 89 d8             	mov    %rbx,%rax
    68ed:	5b                   	pop    %rbx
    68ee:	c3                   	ret
    68ef:	90                   	nop
    68f0:	66 85 c0             	test   %ax,%ax
    68f3:	75 d9                	jne    68ce <e161+0xae>
    68f5:	eb cf                	jmp    68c6 <e161+0xa6>
    68f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    68fe:	00 00 
    6900:	48 89 d7             	mov    %rdx,%rdi
    6903:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6908:	e8 63 ea ff ff       	call   5370 <fwp_rc_forget_slot>
    690d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6912:	eb b7                	jmp    68cb <e161+0xab>
    6914:	e8 e7 cd ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6919:	e8 42 cb ff ff       	call   3460 <__stack_chk_fail@plt>
    691e:	66 90                	xchg   %ax,%ax

0000000000006920 <fwp_drop0>:
    6920:	f3 0f 1e fa          	endbr64
    6924:	48 8b 15 4d e2 01 00 	mov    0x1e24d(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    692b:	48 89 f8             	mov    %rdi,%rax
    692e:	48 2b 05 1b e2 01 00 	sub    0x1e21b(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    6935:	48 c1 e2 10          	shl    $0x10,%rdx
    6939:	48 39 d0             	cmp    %rdx,%rax
    693c:	0f 83 be 00 00 00    	jae    6a00 <fwp_drop0+0xe0>
    6942:	48 83 ec 18          	sub    $0x18,%rsp
    6946:	4c 8d 05 53 ce 01 00 	lea    0x1ce53(%rip),%r8        # 237a0 <fwp_heap>
    694d:	48 89 c2             	mov    %rax,%rdx
    6950:	48 c1 ea 10          	shr    $0x10,%rdx
    6954:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6958:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    695f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6963:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6967:	48 85 d2             	test   %rdx,%rdx
    696a:	74 3c                	je     69a8 <fwp_drop0+0x88>
    696c:	0f b6 31             	movzbl (%rcx),%esi
    696f:	40 80 fe 02          	cmp    $0x2,%sil
    6973:	74 3b                	je     69b0 <fwp_drop0+0x90>
    6975:	40 80 fe 01          	cmp    $0x1,%sil
    6979:	75 2d                	jne    69a8 <fwp_drop0+0x88>
    697b:	8b 71 18             	mov    0x18(%rcx),%esi
    697e:	0f b7 c0             	movzwl %ax,%eax
    6981:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6984:	48 0f af c6          	imul   %rsi,%rax
    6988:	48 c1 e8 20          	shr    $0x20,%rax
    698c:	48 39 c8             	cmp    %rcx,%rax
    698f:	73 17                	jae    69a8 <fwp_drop0+0x88>
    6991:	48 01 c2             	add    %rax,%rdx
    6994:	0f b6 02             	movzbl (%rdx),%eax
    6997:	84 c0                	test   %al,%al
    6999:	74 0d                	je     69a8 <fwp_drop0+0x88>
    699b:	3c 01                	cmp    $0x1,%al
    699d:	74 21                	je     69c0 <fwp_drop0+0xa0>
    699f:	3c ff                	cmp    $0xff,%al
    69a1:	74 65                	je     6a08 <fwp_drop0+0xe8>
    69a3:	83 e8 01             	sub    $0x1,%eax
    69a6:	88 02                	mov    %al,(%rdx)
    69a8:	48 83 c4 18          	add    $0x18,%rsp
    69ac:	c3                   	ret
    69ad:	0f 1f 00             	nopl   (%rax)
    69b0:	66 85 c0             	test   %ax,%ax
    69b3:	74 df                	je     6994 <fwp_drop0+0x74>
    69b5:	48 83 c4 18          	add    $0x18,%rsp
    69b9:	c3                   	ret
    69ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    69c0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    69c4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    69c9:	e8 42 fc ff ff       	call   6610 <fwp_rc_free_arr>
    69ce:	4c 8d 05 cb cd 01 00 	lea    0x1cdcb(%rip),%r8        # 237a0 <fwp_heap>
    69d5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    69da:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    69e1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    69e8:	48 c1 e2 10          	shl    $0x10,%rdx
    69ec:	48 39 d0             	cmp    %rdx,%rax
    69ef:	73 b7                	jae    69a8 <fwp_drop0+0x88>
    69f1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    69f6:	e9 52 ff ff ff       	jmp    694d <fwp_drop0+0x2d>
    69fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6a00:	c3                   	ret
    6a01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6a08:	48 89 d0             	mov    %rdx,%rax
    6a0b:	48 c1 e8 11          	shr    $0x11,%rax
    6a0f:	48 31 d0             	xor    %rdx,%rax
    6a12:	48 89 c1             	mov    %rax,%rcx
    6a15:	48 c1 e9 09          	shr    $0x9,%rcx
    6a19:	48 31 c8             	xor    %rcx,%rax
    6a1c:	0f b6 c8             	movzbl %al,%ecx
    6a1f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6a26:	00 
    6a27:	48 85 c0             	test   %rax,%rax
    6a2a:	75 1d                	jne    6a49 <fwp_drop0+0x129>
    6a2c:	eb 56                	jmp    6a84 <fwp_drop0+0x164>
    6a2e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6a3c:	00 00 00 00 
    6a40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6a44:	48 85 c0             	test   %rax,%rax
    6a47:	74 3b                	je     6a84 <fwp_drop0+0x164>
    6a49:	48 89 c1             	mov    %rax,%rcx
    6a4c:	48 39 10             	cmp    %rdx,(%rax)
    6a4f:	75 ef                	jne    6a40 <fwp_drop0+0x120>
    6a51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6a55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6a59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6a5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6a64:	0f 85 3e ff ff ff    	jne    69a8 <fwp_drop0+0x88>
    6a6a:	48 89 d7             	mov    %rdx,%rdi
    6a6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6a72:	e8 f9 e8 ff ff       	call   5370 <fwp_rc_forget_slot>
    6a77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6a7c:	c6 02 fe             	movb   $0xfe,(%rdx)
    6a7f:	e9 24 ff ff ff       	jmp    69a8 <fwp_drop0+0x88>
    6a84:	48 8d 3d 0d 8d 00 00 	lea    0x8d0d(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    6a8b:	e8 10 d7 ff ff       	call   41a0 <fwp_trap>

0000000000006a90 <fwp_arg_drop12>:
    6a90:	f3 0f 1e fa          	endbr64
    6a94:	85 f6                	test   %esi,%esi
    6a96:	75 04                	jne    6a9c <fwp_arg_drop12+0xc>
    6a98:	85 d2                	test   %edx,%edx
    6a9a:	75 04                	jne    6aa0 <fwp_arg_drop12+0x10>
    6a9c:	c3                   	ret
    6a9d:	0f 1f 00             	nopl   (%rax)
    6aa0:	48 8b 3f             	mov    (%rdi),%rdi
    6aa3:	e9 78 fe ff ff       	jmp    6920 <fwp_drop0>
    6aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6aaf:	00 

0000000000006ab0 <fwp_drop1>:
    6ab0:	f3 0f 1e fa          	endbr64
    6ab4:	48 8b 15 bd e0 01 00 	mov    0x1e0bd(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    6abb:	48 89 f8             	mov    %rdi,%rax
    6abe:	48 2b 05 8b e0 01 00 	sub    0x1e08b(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    6ac5:	48 c1 e2 10          	shl    $0x10,%rdx
    6ac9:	48 39 d0             	cmp    %rdx,%rax
    6acc:	0f 83 be 00 00 00    	jae    6b90 <fwp_drop1+0xe0>
    6ad2:	48 83 ec 18          	sub    $0x18,%rsp
    6ad6:	4c 8d 05 c3 cc 01 00 	lea    0x1ccc3(%rip),%r8        # 237a0 <fwp_heap>
    6add:	48 89 c2             	mov    %rax,%rdx
    6ae0:	48 c1 ea 10          	shr    $0x10,%rdx
    6ae4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ae8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6aef:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6af3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6af7:	48 85 d2             	test   %rdx,%rdx
    6afa:	74 3c                	je     6b38 <fwp_drop1+0x88>
    6afc:	0f b6 31             	movzbl (%rcx),%esi
    6aff:	40 80 fe 02          	cmp    $0x2,%sil
    6b03:	74 3b                	je     6b40 <fwp_drop1+0x90>
    6b05:	40 80 fe 01          	cmp    $0x1,%sil
    6b09:	75 2d                	jne    6b38 <fwp_drop1+0x88>
    6b0b:	8b 71 18             	mov    0x18(%rcx),%esi
    6b0e:	0f b7 c0             	movzwl %ax,%eax
    6b11:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6b14:	48 0f af c6          	imul   %rsi,%rax
    6b18:	48 c1 e8 20          	shr    $0x20,%rax
    6b1c:	48 39 c8             	cmp    %rcx,%rax
    6b1f:	73 17                	jae    6b38 <fwp_drop1+0x88>
    6b21:	48 01 c2             	add    %rax,%rdx
    6b24:	0f b6 02             	movzbl (%rdx),%eax
    6b27:	84 c0                	test   %al,%al
    6b29:	74 0d                	je     6b38 <fwp_drop1+0x88>
    6b2b:	3c 01                	cmp    $0x1,%al
    6b2d:	74 21                	je     6b50 <fwp_drop1+0xa0>
    6b2f:	3c ff                	cmp    $0xff,%al
    6b31:	74 65                	je     6b98 <fwp_drop1+0xe8>
    6b33:	83 e8 01             	sub    $0x1,%eax
    6b36:	88 02                	mov    %al,(%rdx)
    6b38:	48 83 c4 18          	add    $0x18,%rsp
    6b3c:	c3                   	ret
    6b3d:	0f 1f 00             	nopl   (%rax)
    6b40:	66 85 c0             	test   %ax,%ax
    6b43:	74 df                	je     6b24 <fwp_drop1+0x74>
    6b45:	48 83 c4 18          	add    $0x18,%rsp
    6b49:	c3                   	ret
    6b4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6b50:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6b54:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6b59:	e8 b2 fa ff ff       	call   6610 <fwp_rc_free_arr>
    6b5e:	4c 8d 05 3b cc 01 00 	lea    0x1cc3b(%rip),%r8        # 237a0 <fwp_heap>
    6b65:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6b6a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6b71:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6b78:	48 c1 e2 10          	shl    $0x10,%rdx
    6b7c:	48 39 d0             	cmp    %rdx,%rax
    6b7f:	73 b7                	jae    6b38 <fwp_drop1+0x88>
    6b81:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6b86:	e9 52 ff ff ff       	jmp    6add <fwp_drop1+0x2d>
    6b8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6b90:	c3                   	ret
    6b91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b98:	48 89 d0             	mov    %rdx,%rax
    6b9b:	48 c1 e8 11          	shr    $0x11,%rax
    6b9f:	48 31 d0             	xor    %rdx,%rax
    6ba2:	48 89 c1             	mov    %rax,%rcx
    6ba5:	48 c1 e9 09          	shr    $0x9,%rcx
    6ba9:	48 31 c8             	xor    %rcx,%rax
    6bac:	0f b6 c8             	movzbl %al,%ecx
    6baf:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6bb6:	00 
    6bb7:	48 85 c0             	test   %rax,%rax
    6bba:	75 0d                	jne    6bc9 <fwp_drop1+0x119>
    6bbc:	eb 46                	jmp    6c04 <fwp_drop1+0x154>
    6bbe:	66 90                	xchg   %ax,%ax
    6bc0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6bc4:	48 85 c0             	test   %rax,%rax
    6bc7:	74 3b                	je     6c04 <fwp_drop1+0x154>
    6bc9:	48 89 c1             	mov    %rax,%rcx
    6bcc:	48 39 10             	cmp    %rdx,(%rax)
    6bcf:	75 ef                	jne    6bc0 <fwp_drop1+0x110>
    6bd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6bd5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6bd9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6bdd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6be4:	0f 85 4e ff ff ff    	jne    6b38 <fwp_drop1+0x88>
    6bea:	48 89 d7             	mov    %rdx,%rdi
    6bed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6bf2:	e8 79 e7 ff ff       	call   5370 <fwp_rc_forget_slot>
    6bf7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6bfc:	c6 02 fe             	movb   $0xfe,(%rdx)
    6bff:	e9 34 ff ff ff       	jmp    6b38 <fwp_drop1+0x88>
    6c04:	48 8d 3d 8d 8b 00 00 	lea    0x8b8d(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    6c0b:	e8 90 d5 ff ff       	call   41a0 <fwp_trap>

0000000000006c10 <fwp_closure_drop>:
    6c10:	48 8b 15 61 df 01 00 	mov    0x1df61(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    6c17:	48 89 f8             	mov    %rdi,%rax
    6c1a:	48 2b 05 2f df 01 00 	sub    0x1df2f(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    6c21:	48 c1 e2 10          	shl    $0x10,%rdx
    6c25:	48 39 d0             	cmp    %rdx,%rax
    6c28:	73 6b                	jae    6c95 <fwp_closure_drop+0x85>
    6c2a:	48 89 c2             	mov    %rax,%rdx
    6c2d:	48 c1 ea 10          	shr    $0x10,%rdx
    6c31:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c35:	48 8b 15 5c df 01 00 	mov    0x1df5c(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    6c3c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c40:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c44:	48 85 d2             	test   %rdx,%rdx
    6c47:	74 4c                	je     6c95 <fwp_closure_drop+0x85>
    6c49:	0f b6 31             	movzbl (%rcx),%esi
    6c4c:	40 80 fe 02          	cmp    $0x2,%sil
    6c50:	74 3e                	je     6c90 <fwp_closure_drop+0x80>
    6c52:	40 80 fe 01          	cmp    $0x1,%sil
    6c56:	75 3d                	jne    6c95 <fwp_closure_drop+0x85>
    6c58:	8b 71 18             	mov    0x18(%rcx),%esi
    6c5b:	0f b7 c0             	movzwl %ax,%eax
    6c5e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c61:	48 0f af c6          	imul   %rsi,%rax
    6c65:	48 c1 e8 20          	shr    $0x20,%rax
    6c69:	48 39 c8             	cmp    %rcx,%rax
    6c6c:	73 27                	jae    6c95 <fwp_closure_drop+0x85>
    6c6e:	48 01 c2             	add    %rax,%rdx
    6c71:	0f b6 02             	movzbl (%rdx),%eax
    6c74:	84 c0                	test   %al,%al
    6c76:	74 1d                	je     6c95 <fwp_closure_drop+0x85>
    6c78:	3c 01                	cmp    $0x1,%al
    6c7a:	74 24                	je     6ca0 <fwp_closure_drop+0x90>
    6c7c:	3c ff                	cmp    $0xff,%al
    6c7e:	74 48                	je     6cc8 <fwp_closure_drop+0xb8>
    6c80:	83 e8 01             	sub    $0x1,%eax
    6c83:	88 02                	mov    %al,(%rdx)
    6c85:	c3                   	ret
    6c86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c8d:	00 00 00 
    6c90:	66 85 c0             	test   %ax,%ax
    6c93:	74 dc                	je     6c71 <fwp_closure_drop+0x61>
    6c95:	c3                   	ret
    6c96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c9d:	00 00 00 
    6ca0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6ca7:	ff ff 
    6ca9:	48 85 c0             	test   %rax,%rax
    6cac:	74 12                	je     6cc0 <fwp_closure_drop+0xb0>
    6cae:	48 89 fe             	mov    %rdi,%rsi
    6cb1:	48 89 c7             	mov    %rax,%rdi
    6cb4:	e9 47 d5 ff ff       	jmp    4200 <fwp_closure_drop_push>
    6cb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6cc0:	e9 eb d6 ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    6cc5:	0f 1f 00             	nopl   (%rax)
    6cc8:	48 89 d0             	mov    %rdx,%rax
    6ccb:	48 8d 35 ce ca 01 00 	lea    0x1cace(%rip),%rsi        # 237a0 <fwp_heap>
    6cd2:	48 83 ec 18          	sub    $0x18,%rsp
    6cd6:	48 c1 e8 11          	shr    $0x11,%rax
    6cda:	48 31 d0             	xor    %rdx,%rax
    6cdd:	48 89 c1             	mov    %rax,%rcx
    6ce0:	48 c1 e9 09          	shr    $0x9,%rcx
    6ce4:	48 31 c8             	xor    %rcx,%rax
    6ce7:	0f b6 c8             	movzbl %al,%ecx
    6cea:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6cf1:	00 
    6cf2:	48 85 c0             	test   %rax,%rax
    6cf5:	75 12                	jne    6d09 <fwp_closure_drop+0xf9>
    6cf7:	eb 49                	jmp    6d42 <fwp_closure_drop+0x132>
    6cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6d00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6d04:	48 85 c0             	test   %rax,%rax
    6d07:	74 39                	je     6d42 <fwp_closure_drop+0x132>
    6d09:	48 89 c1             	mov    %rax,%rcx
    6d0c:	48 39 10             	cmp    %rdx,(%rax)
    6d0f:	75 ef                	jne    6d00 <fwp_closure_drop+0xf0>
    6d11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6d15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6d19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6d1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6d24:	74 05                	je     6d2b <fwp_closure_drop+0x11b>
    6d26:	48 83 c4 18          	add    $0x18,%rsp
    6d2a:	c3                   	ret
    6d2b:	48 89 d7             	mov    %rdx,%rdi
    6d2e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6d33:	e8 38 e6 ff ff       	call   5370 <fwp_rc_forget_slot>
    6d38:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6d3d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6d40:	eb e4                	jmp    6d26 <fwp_closure_drop+0x116>
    6d42:	48 8d 3d 4f 8a 00 00 	lea    0x8a4f(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    6d49:	e8 52 d4 ff ff       	call   41a0 <fwp_trap>
    6d4e:	66 90                	xchg   %ax,%ax

0000000000006d50 <fwp_owned_tape_release>:
    6d50:	48 85 ff             	test   %rdi,%rdi
    6d53:	0f 84 f7 00 00 00    	je     6e50 <fwp_owned_tape_release+0x100>
    6d59:	41 54                	push   %r12
    6d5b:	55                   	push   %rbp
    6d5c:	53                   	push   %rbx
    6d5d:	48 8b 07             	mov    (%rdi),%rax
    6d60:	48 85 c0             	test   %rax,%rax
    6d63:	74 08                	je     6d6d <fwp_owned_tape_release+0x1d>
    6d65:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6d69:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6d6d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6d71:	48 85 d2             	test   %rdx,%rdx
    6d74:	74 03                	je     6d79 <fwp_owned_tape_release+0x29>
    6d76:	48 89 02             	mov    %rax,(%rdx)
    6d79:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6d7d:	48 89 fb             	mov    %rdi,%rbx
    6d80:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6d84:	48 85 c0             	test   %rax,%rax
    6d87:	0f 84 89 00 00 00    	je     6e16 <fwp_owned_tape_release+0xc6>
    6d8d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6d91:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6d95:	7e 47                	jle    6dde <fwp_owned_tape_release+0x8e>
    6d97:	31 ed                	xor    %ebp,%ebp
    6d99:	eb 0d                	jmp    6da8 <fwp_owned_tape_release+0x58>
    6d9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6da0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6da4:	48 8b 40 68          	mov    0x68(%rax),%rax
    6da8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6dac:	49 89 ec             	mov    %rbp,%r12
    6daf:	48 83 c5 01          	add    $0x1,%rbp
    6db3:	49 c1 e4 04          	shl    $0x4,%r12
    6db7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6dbb:	ff d0                	call   *%rax
    6dbd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6dc1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6dc6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6dca:	ff 50 68             	call   *0x68(%rax)
    6dcd:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6dd1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6dd5:	48 39 e8             	cmp    %rbp,%rax
    6dd8:	7f c6                	jg     6da0 <fwp_owned_tape_release+0x50>
    6dda:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6dde:	31 ed                	xor    %ebp,%ebp
    6de0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6de5:	7e 28                	jle    6e0f <fwp_owned_tape_release+0xbf>
    6de7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6dee:	00 00 
    6df0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6df4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6df8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6dfc:	74 07                	je     6e05 <fwp_owned_tape_release+0xb5>
    6dfe:	ff 52 68             	call   *0x68(%rdx)
    6e01:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6e05:	48 83 c5 01          	add    $0x1,%rbp
    6e09:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6e0d:	7f e1                	jg     6df0 <fwp_owned_tape_release+0xa0>
    6e0f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6e13:	ff 52 68             	call   *0x68(%rdx)
    6e16:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6e1a:	e8 f1 fd ff ff       	call   6c10 <fwp_closure_drop>
    6e1f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6e23:	e8 e8 fd ff ff       	call   6c10 <fwp_closure_drop>
    6e28:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6e2c:	e8 df fd ff ff       	call   6c10 <fwp_closure_drop>
    6e31:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6e35:	e8 76 e7 ff ff       	call   55b0 <fwp_mem_free>
    6e3a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6e3e:	e8 6d e7 ff ff       	call   55b0 <fwp_mem_free>
    6e43:	48 89 df             	mov    %rbx,%rdi
    6e46:	5b                   	pop    %rbx
    6e47:	5d                   	pop    %rbp
    6e48:	41 5c                	pop    %r12
    6e4a:	e9 61 e7 ff ff       	jmp    55b0 <fwp_mem_free>
    6e4f:	90                   	nop
    6e50:	c3                   	ret
    6e51:	0f 1f 40 00          	nopl   0x0(%rax)
    6e55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e5c:	00 00 00 00 

0000000000006e60 <fwp_tape_finish>:
    6e60:	f3 0f 1e fa          	endbr64
    6e64:	41 56                	push   %r14
    6e66:	48 8d 3d 73 c2 01 00 	lea    0x1c273(%rip),%rdi        # 230e0 <fwp_tape_workspace>
    6e6d:	41 55                	push   %r13
    6e6f:	41 54                	push   %r12
    6e71:	55                   	push   %rbp
    6e72:	53                   	push   %rbx
    6e73:	e8 f8 d0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    6e78:	48 83 3d a8 c2 01 00 	cmpq   $0x0,0x1c2a8(%rip)        # 23128 <fwp_ntapes>
    6e7f:	00 
    6e80:	48 c7 05 3d c2 01 00 	movq   $0x0,0x1c23d(%rip)        # 230c8 <fwp_tape_cached_bytes>
    6e87:	00 00 00 00 
    6e8b:	7e 68                	jle    6ef5 <fwp_tape_finish+0x95>
    6e8d:	45 31 e4             	xor    %r12d,%r12d
    6e90:	31 ed                	xor    %ebp,%ebp
    6e92:	0f 1f 00             	nopl   (%rax)
    6e95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e9c:	00 00 00 00 
    6ea0:	48 8b 1d 89 c2 01 00 	mov    0x1c289(%rip),%rbx        # 23130 <fwp_tapes>
    6ea7:	48 83 c5 01          	add    $0x1,%rbp
    6eab:	4c 01 e3             	add    %r12,%rbx
    6eae:	49 83 c4 68          	add    $0x68,%r12
    6eb2:	48 89 df             	mov    %rbx,%rdi
    6eb5:	e8 46 cd ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6eba:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6ebe:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6ec2:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6ec6:	e8 f5 c4 ff ff       	call   33c0 <free@plt>
    6ecb:	4c 89 f7             	mov    %r14,%rdi
    6ece:	e8 ed c4 ff ff       	call   33c0 <free@plt>
    6ed3:	4c 89 ef             	mov    %r13,%rdi
    6ed6:	e8 e5 c4 ff ff       	call   33c0 <free@plt>
    6edb:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6edf:	e8 6c fe ff ff       	call   6d50 <fwp_owned_tape_release>
    6ee4:	48 39 2d 3d c2 01 00 	cmp    %rbp,0x1c23d(%rip)        # 23128 <fwp_ntapes>
    6eeb:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6ef2:	00 
    6ef3:	7f ab                	jg     6ea0 <fwp_tape_finish+0x40>
    6ef5:	48 8b 3d 34 c2 01 00 	mov    0x1c234(%rip),%rdi        # 23130 <fwp_tapes>
    6efc:	e8 bf c4 ff ff       	call   33c0 <free@plt>
    6f01:	5b                   	pop    %rbx
    6f02:	5d                   	pop    %rbp
    6f03:	48 c7 05 22 c2 01 00 	movq   $0x0,0x1c222(%rip)        # 23130 <fwp_tapes>
    6f0a:	00 00 00 00 
    6f0e:	48 c7 05 07 c2 01 00 	movq   $0x0,0x1c207(%rip)        # 23120 <fwp_tapes_cap>
    6f15:	00 00 00 00 
    6f19:	41 5c                	pop    %r12
    6f1b:	48 c7 05 02 c2 01 00 	movq   $0x0,0x1c202(%rip)        # 23128 <fwp_ntapes>
    6f22:	00 00 00 00 
    6f26:	41 5d                	pop    %r13
    6f28:	48 c7 05 e5 c1 01 00 	movq   $0x0,0x1c1e5(%rip)        # 23118 <fwp_tape_next_slot>
    6f2f:	00 00 00 00 
    6f33:	41 5e                	pop    %r14
    6f35:	c3                   	ret
    6f36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6f3d:	00 00 00 

0000000000006f40 <fwp_tape_scope_release>:
    6f40:	f3 0f 1e fa          	endbr64
    6f44:	41 55                	push   %r13
    6f46:	41 54                	push   %r12
    6f48:	55                   	push   %rbp
    6f49:	53                   	push   %rbx
    6f4a:	48 83 ec 58          	sub    $0x58,%rsp
    6f4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6f55:	00 00 
    6f57:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6f5c:	48 63 07             	movslq (%rdi),%rax
    6f5f:	85 c0                	test   %eax,%eax
    6f61:	0f 88 05 01 00 00    	js     706c <fwp_tape_scope_release+0x12c>
    6f67:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6f6e:	ec c4 4e 
    6f71:	48 89 fb             	mov    %rdi,%rbx
    6f74:	eb 3c                	jmp    6fb2 <fwp_tape_scope_release+0x72>
    6f76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6f7d:	00 00 00 
    6f80:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6f85:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6f89:	e8 32 c4 ff ff       	call   33c0 <free@plt>
    6f8e:	48 8b 3c 24          	mov    (%rsp),%rdi
    6f92:	e8 29 c4 ff ff       	call   33c0 <free@plt>
    6f97:	4c 89 ef             	mov    %r13,%rdi
    6f9a:	e8 21 c4 ff ff       	call   33c0 <free@plt>
    6f9f:	4c 89 e7             	mov    %r12,%rdi
    6fa2:	e8 a9 fd ff ff       	call   6d50 <fwp_owned_tape_release>
    6fa7:	48 63 03             	movslq (%rbx),%rax
    6faa:	85 c0                	test   %eax,%eax
    6fac:	0f 88 ba 00 00 00    	js     706c <fwp_tape_scope_release+0x12c>
    6fb2:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6fb6:	48 8b 35 73 c1 01 00 	mov    0x1c173(%rip),%rsi        # 23130 <fwp_tapes>
    6fbd:	4c 01 c6             	add    %r8,%rsi
    6fc0:	48 89 f7             	mov    %rsi,%rdi
    6fc3:	e8 38 cc ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6fc8:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6fcd:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6fd2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6fd9:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6fdd:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6fe1:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6fe8:	00 
    6fe9:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6fee:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6ff2:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6ff7:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6ffb:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    7000:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7007:	00 
    7008:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    700f:	00 
    7010:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7017:	00 
    7018:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    701d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    7022:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    7026:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    702a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    702e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7034:	77 18                	ja     704e <fwp_tape_scope_release+0x10e>
    7036:	49 c1 f8 03          	sar    $0x3,%r8
    703a:	4c 0f af c5          	imul   %rbp,%r8
    703e:	4c 3b 05 d3 c0 01 00 	cmp    0x1c0d3(%rip),%r8        # 23118 <fwp_tape_next_slot>
    7045:	7d 07                	jge    704e <fwp_tape_scope_release+0x10e>
    7047:	4c 89 05 ca c0 01 00 	mov    %r8,0x1c0ca(%rip)        # 23118 <fwp_tape_next_slot>
    704e:	4d 85 e4             	test   %r12,%r12
    7051:	0f 85 29 ff ff ff    	jne    6f80 <fwp_tape_scope_release+0x40>
    7057:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    705c:	e8 2f de ff ff       	call   4e90 <fwp_tape_buffers_release>
    7061:	48 63 03             	movslq (%rbx),%rax
    7064:	85 c0                	test   %eax,%eax
    7066:	0f 89 46 ff ff ff    	jns    6fb2 <fwp_tape_scope_release+0x72>
    706c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    7071:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7078:	00 00 
    707a:	75 0b                	jne    7087 <fwp_tape_scope_release+0x147>
    707c:	48 83 c4 58          	add    $0x58,%rsp
    7080:	5b                   	pop    %rbx
    7081:	5d                   	pop    %rbp
    7082:	41 5c                	pop    %r12
    7084:	41 5d                	pop    %r13
    7086:	c3                   	ret
    7087:	e8 d4 c3 ff ff       	call   3460 <__stack_chk_fail@plt>
    708c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000007090 <fwp_task_dispose>:
    7090:	53                   	push   %rbx
    7091:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7095:	0f 84 ab c6 ff ff    	je     3746 <fwp_task_dispose.cold>
    709b:	48 89 fb             	mov    %rdi,%rbx
    709e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    70a3:	0f 85 9d c6 ff ff    	jne    3746 <fwp_task_dispose.cold>
    70a9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    70ad:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    70b4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    70bb:	00 
    70bc:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    70c0:	48 85 ff             	test   %rdi,%rdi
    70c3:	74 07                	je     70cc <fwp_task_dispose+0x3c>
    70c5:	48 85 c0             	test   %rax,%rax
    70c8:	74 02                	je     70cc <fwp_task_dispose+0x3c>
    70ca:	ff d0                	call   *%rax
    70cc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    70d3:	e8 d8 e4 ff ff       	call   55b0 <fwp_mem_free>
    70d8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    70df:	00 00 00 00 
    70e3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    70e7:	74 6f                	je     7158 <fwp_task_dispose+0xc8>
    70e9:	48 8b 15 88 da 01 00 	mov    0x1da88(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    70f0:	48 89 d8             	mov    %rbx,%rax
    70f3:	48 2b 05 56 da 01 00 	sub    0x1da56(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    70fa:	48 c1 e2 10          	shl    $0x10,%rdx
    70fe:	48 39 d0             	cmp    %rdx,%rax
    7101:	73 4c                	jae    714f <fwp_task_dispose+0xbf>
    7103:	48 89 c2             	mov    %rax,%rdx
    7106:	48 c1 ea 10          	shr    $0x10,%rdx
    710a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    710e:	48 8b 15 83 da 01 00 	mov    0x1da83(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    7115:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7119:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    711d:	48 85 c9             	test   %rcx,%rcx
    7120:	74 2d                	je     714f <fwp_task_dispose+0xbf>
    7122:	0f b6 32             	movzbl (%rdx),%esi
    7125:	40 80 fe 02          	cmp    $0x2,%sil
    7129:	74 3d                	je     7168 <fwp_task_dispose+0xd8>
    712b:	40 80 fe 01          	cmp    $0x1,%sil
    712f:	75 1e                	jne    714f <fwp_task_dispose+0xbf>
    7131:	8b 72 18             	mov    0x18(%rdx),%esi
    7134:	0f b7 c0             	movzwl %ax,%eax
    7137:	8b 52 1c             	mov    0x1c(%rdx),%edx
    713a:	48 0f af c6          	imul   %rsi,%rax
    713e:	48 c1 e8 20          	shr    $0x20,%rax
    7142:	48 39 d0             	cmp    %rdx,%rax
    7145:	73 08                	jae    714f <fwp_task_dispose+0xbf>
    7147:	48 01 c1             	add    %rax,%rcx
    714a:	80 39 01             	cmpb   $0x1,(%rcx)
    714d:	74 09                	je     7158 <fwp_task_dispose+0xc8>
    714f:	5b                   	pop    %rbx
    7150:	c3                   	ret
    7151:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7158:	48 89 df             	mov    %rbx,%rdi
    715b:	5b                   	pop    %rbx
    715c:	e9 4f e4 ff ff       	jmp    55b0 <fwp_mem_free>
    7161:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7168:	66 85 c0             	test   %ax,%ax
    716b:	74 dd                	je     714a <fwp_task_dispose+0xba>
    716d:	5b                   	pop    %rbx
    716e:	c3                   	ret
    716f:	90                   	nop

0000000000007170 <fwp_free_zombie>:
    7170:	48 8b 15 f9 c5 01 00 	mov    0x1c5f9(%rip),%rdx        # 23770 <fwp_zombie>
    7177:	48 85 d2             	test   %rdx,%rdx
    717a:	0f 84 98 00 00 00    	je     7218 <fwp_free_zombie+0xa8>
    7180:	48 3b 15 f9 c5 01 00 	cmp    0x1c5f9(%rip),%rdx        # 23780 <fwp_cur>
    7187:	0f 84 8b 00 00 00    	je     7218 <fwp_free_zombie+0xa8>
    718d:	48 83 ec 18          	sub    $0x18,%rsp
    7191:	48 63 05 b4 bf 01 00 	movslq 0x1bfb4(%rip),%rax        # 2314c <fwp_stack_pool_n>
    7198:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    719c:	83 f8 3f             	cmp    $0x3f,%eax
    719f:	7f 7f                	jg     7220 <fwp_free_zombie+0xb0>
    71a1:	8d 48 01             	lea    0x1(%rax),%ecx
    71a4:	89 0d a2 bf 01 00    	mov    %ecx,0x1bfa2(%rip)        # 2314c <fwp_stack_pool_n>
    71aa:	48 8d 0d af bf 01 00 	lea    0x1bfaf(%rip),%rcx        # 23160 <fwp_stack_pool>
    71b1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    71b5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    71bc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    71c0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    71c7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    71cb:	48 85 c9             	test   %rcx,%rcx
    71ce:	0f 84 fc 00 00 00    	je     72d0 <fwp_free_zombie+0x160>
    71d4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    71db:	48 85 c0             	test   %rax,%rax
    71de:	74 07                	je     71e7 <fwp_free_zombie+0x77>
    71e0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    71e7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    71ea:	66 0f ef c0          	pxor   %xmm0,%xmm0
    71ee:	48 c7 05 77 c5 01 00 	movq   $0x0,0x1c577(%rip)        # 23770 <fwp_zombie>
    71f5:	00 00 00 00 
    71f9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7200:	85 c0                	test   %eax,%eax
    7202:	74 34                	je     7238 <fwp_free_zombie+0xc8>
    7204:	83 f8 01             	cmp    $0x1,%eax
    7207:	0f 84 b3 00 00 00    	je     72c0 <fwp_free_zombie+0x150>
    720d:	48 83 c4 18          	add    $0x18,%rsp
    7211:	c3                   	ret
    7212:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7218:	c3                   	ret
    7219:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7220:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7224:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7229:	e8 b2 c3 ff ff       	call   35e0 <munmap@plt>
    722e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7233:	eb 80                	jmp    71b5 <fwp_free_zombie+0x45>
    7235:	0f 1f 00             	nopl   (%rax)
    7238:	48 8b 0d 39 d9 01 00 	mov    0x1d939(%rip),%rcx        # 24b78 <fwp_heap+0x13d8>
    723f:	48 89 d0             	mov    %rdx,%rax
    7242:	48 2b 05 07 d9 01 00 	sub    0x1d907(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    7249:	48 c1 e1 10          	shl    $0x10,%rcx
    724d:	48 39 c8             	cmp    %rcx,%rax
    7250:	73 bb                	jae    720d <fwp_free_zombie+0x9d>
    7252:	48 89 c1             	mov    %rax,%rcx
    7255:	48 c1 e9 10          	shr    $0x10,%rcx
    7259:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    725d:	48 8b 0d 34 d9 01 00 	mov    0x1d934(%rip),%rcx        # 24b98 <fwp_heap+0x13f8>
    7264:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7268:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    726c:	48 85 c9             	test   %rcx,%rcx
    726f:	74 9c                	je     720d <fwp_free_zombie+0x9d>
    7271:	0f b6 3e             	movzbl (%rsi),%edi
    7274:	40 80 ff 02          	cmp    $0x2,%dil
    7278:	74 66                	je     72e0 <fwp_free_zombie+0x170>
    727a:	40 80 ff 01          	cmp    $0x1,%dil
    727e:	75 8d                	jne    720d <fwp_free_zombie+0x9d>
    7280:	8b 7e 18             	mov    0x18(%rsi),%edi
    7283:	0f b7 c0             	movzwl %ax,%eax
    7286:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7289:	48 0f af c7          	imul   %rdi,%rax
    728d:	48 c1 e8 20          	shr    $0x20,%rax
    7291:	48 39 f0             	cmp    %rsi,%rax
    7294:	0f 83 73 ff ff ff    	jae    720d <fwp_free_zombie+0x9d>
    729a:	48 01 c1             	add    %rax,%rcx
    729d:	0f b6 01             	movzbl (%rcx),%eax
    72a0:	84 c0                	test   %al,%al
    72a2:	0f 84 65 ff ff ff    	je     720d <fwp_free_zombie+0x9d>
    72a8:	3c 01                	cmp    $0x1,%al
    72aa:	74 14                	je     72c0 <fwp_free_zombie+0x150>
    72ac:	3c ff                	cmp    $0xff,%al
    72ae:	74 3b                	je     72eb <fwp_free_zombie+0x17b>
    72b0:	83 e8 01             	sub    $0x1,%eax
    72b3:	88 01                	mov    %al,(%rcx)
    72b5:	e9 53 ff ff ff       	jmp    720d <fwp_free_zombie+0x9d>
    72ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    72c0:	48 89 d7             	mov    %rdx,%rdi
    72c3:	48 83 c4 18          	add    $0x18,%rsp
    72c7:	e9 c4 fd ff ff       	jmp    7090 <fwp_task_dispose>
    72cc:	0f 1f 40 00          	nopl   0x0(%rax)
    72d0:	48 89 05 71 c4 01 00 	mov    %rax,0x1c471(%rip)        # 23748 <fwp_tasks_active>
    72d7:	e9 ff fe ff ff       	jmp    71db <fwp_free_zombie+0x6b>
    72dc:	0f 1f 40 00          	nopl   0x0(%rax)
    72e0:	66 85 c0             	test   %ax,%ax
    72e3:	0f 85 24 ff ff ff    	jne    720d <fwp_free_zombie+0x9d>
    72e9:	eb b2                	jmp    729d <fwp_free_zombie+0x12d>
    72eb:	48 89 ca             	mov    %rcx,%rdx
    72ee:	48 8d 35 ab c4 01 00 	lea    0x1c4ab(%rip),%rsi        # 237a0 <fwp_heap>
    72f5:	48 c1 ea 11          	shr    $0x11,%rdx
    72f9:	48 31 ca             	xor    %rcx,%rdx
    72fc:	48 89 d0             	mov    %rdx,%rax
    72ff:	48 c1 e8 09          	shr    $0x9,%rax
    7303:	48 31 c2             	xor    %rax,%rdx
    7306:	0f b6 d2             	movzbl %dl,%edx
    7309:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7310:	00 
    7311:	48 85 c0             	test   %rax,%rax
    7314:	75 13                	jne    7329 <fwp_free_zombie+0x1b9>
    7316:	eb 4c                	jmp    7364 <fwp_free_zombie+0x1f4>
    7318:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    731f:	00 
    7320:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7324:	48 85 c0             	test   %rax,%rax
    7327:	74 3b                	je     7364 <fwp_free_zombie+0x1f4>
    7329:	48 89 c2             	mov    %rax,%rdx
    732c:	48 39 08             	cmp    %rcx,(%rax)
    732f:	75 ef                	jne    7320 <fwp_free_zombie+0x1b0>
    7331:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7335:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7339:	48 89 50 08          	mov    %rdx,0x8(%rax)
    733d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7344:	0f 85 c3 fe ff ff    	jne    720d <fwp_free_zombie+0x9d>
    734a:	48 89 cf             	mov    %rcx,%rdi
    734d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7352:	e8 19 e0 ff ff       	call   5370 <fwp_rc_forget_slot>
    7357:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    735c:	c6 01 fe             	movb   $0xfe,(%rcx)
    735f:	e9 a9 fe ff ff       	jmp    720d <fwp_free_zombie+0x9d>
    7364:	48 8d 3d 2d 84 00 00 	lea    0x842d(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    736b:	e8 30 ce ff ff       	call   41a0 <fwp_trap>

0000000000007370 <fwp_block>:
    7370:	48 83 ec 08          	sub    $0x8,%rsp
    7374:	48 8b 05 ed c3 01 00 	mov    0x1c3ed(%rip),%rax        # 23768 <fwp_ready_head>
    737b:	48 85 c0             	test   %rax,%rax
    737e:	0f 84 1c 01 00 00    	je     74a0 <fwp_block+0x130>
    7384:	90                   	nop
    7385:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    738c:	00 00 00 00 
    7390:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7397:	48 89 15 ca c3 01 00 	mov    %rdx,0x1c3ca(%rip)        # 23768 <fwp_ready_head>
    739e:	48 85 d2             	test   %rdx,%rdx
    73a1:	0f 84 19 01 00 00    	je     74c0 <fwp_block+0x150>
    73a7:	48 8b 15 d2 c3 01 00 	mov    0x1c3d2(%rip),%rdx        # 23780 <fwp_cur>
    73ae:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    73b2:	48 39 c2             	cmp    %rax,%rdx
    73b5:	0f 84 d5 00 00 00    	je     7490 <fwp_block+0x120>
    73bb:	48 8b 0d 46 e0 01 00 	mov    0x1e046(%rip),%rcx        # 25408 <fwp_state_owners>
    73c2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    73c6:	48 89 05 b3 c3 01 00 	mov    %rax,0x1c3b3(%rip)        # 23780 <fwp_cur>
    73cd:	f3 0f 7e 05 5b e0 01 	movq   0x1e05b(%rip),%xmm0        # 25430 <fwp_foreign_callbacks>
    73d4:	00 
    73d5:	0f 16 05 44 e0 01 00 	movhps 0x1e044(%rip),%xmm0        # 25420 <fwp_state>
    73dc:	f3 0f 7e 0d 44 e0 01 	movq   0x1e044(%rip),%xmm1        # 25428 <fwp_handlers>
    73e3:	00 
    73e4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    73eb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    73f2:	0f 16 0d 3f e0 01 00 	movhps 0x1e03f(%rip),%xmm1        # 25438 <fwp_cleanups>
    73f9:	f3 0f 7e 05 17 e0 01 	movq   0x1e017(%rip),%xmm0        # 25418 <fwp_state_len>
    7400:	00 
    7401:	0f 16 05 08 e0 01 00 	movhps 0x1e008(%rip),%xmm0        # 25410 <fwp_state_cap>
    7408:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    740f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7416:	48 8b 70 08          	mov    0x8(%rax),%rsi
    741a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7421:	48 89 0d 00 e0 01 00 	mov    %rcx,0x1e000(%rip)        # 25428 <fwp_handlers>
    7428:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    742f:	48 89 0d 02 e0 01 00 	mov    %rcx,0x1e002(%rip)        # 25438 <fwp_cleanups>
    7436:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    743d:	48 89 0d ec df 01 00 	mov    %rcx,0x1dfec(%rip)        # 25430 <fwp_foreign_callbacks>
    7444:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    744b:	48 89 0d ce df 01 00 	mov    %rcx,0x1dfce(%rip)        # 25420 <fwp_state>
    7452:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7459:	48 89 0d b8 df 01 00 	mov    %rcx,0x1dfb8(%rip)        # 25418 <fwp_state_len>
    7460:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7467:	48 89 0d a2 df 01 00 	mov    %rcx,0x1dfa2(%rip)        # 25410 <fwp_state_cap>
    746e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7475:	48 89 0d 8c df 01 00 	mov    %rcx,0x1df8c(%rip)        # 25408 <fwp_state_owners>
    747c:	e8 0f c0 ff ff       	call   3490 <swapcontext@plt>
    7481:	f3 0f 1e fa          	endbr64
    7485:	e8 e6 fc ff ff       	call   7170 <fwp_free_zombie>
    748a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7490:	8b 05 b2 bc 01 00    	mov    0x1bcb2(%rip),%eax        # 23148 <fwp_slice>
    7496:	85 c0                	test   %eax,%eax
    7498:	74 36                	je     74d0 <fwp_block+0x160>
    749a:	48 83 c4 08          	add    $0x8,%rsp
    749e:	c3                   	ret
    749f:	90                   	nop
    74a0:	e8 1b db ff ff       	call   4fc0 <fwp_poll_events>
    74a5:	48 8b 05 bc c2 01 00 	mov    0x1c2bc(%rip),%rax        # 23768 <fwp_ready_head>
    74ac:	48 85 c0             	test   %rax,%rax
    74af:	0f 85 db fe ff ff    	jne    7390 <fwp_block+0x20>
    74b5:	eb e9                	jmp    74a0 <fwp_block+0x130>
    74b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    74be:	00 00 
    74c0:	48 c7 05 95 c2 01 00 	movq   $0x0,0x1c295(%rip)        # 23760 <fwp_ready_tail>
    74c7:	00 00 00 00 
    74cb:	e9 d7 fe ff ff       	jmp    73a7 <fwp_block+0x37>
    74d0:	48 8d 3d 4a 7c 00 00 	lea    0x7c4a(%rip),%rdi        # f121 <_IO_stdin_used+0x121>
    74d7:	e8 c4 be ff ff       	call   33a0 <getenv@plt>
    74dc:	ba 10 27 00 00       	mov    $0x2710,%edx
    74e1:	48 85 c0             	test   %rax,%rax
    74e4:	74 05                	je     74eb <fwp_block+0x17b>
    74e6:	80 38 00             	cmpb   $0x0,(%rax)
    74e9:	75 0b                	jne    74f6 <fwp_block+0x186>
    74eb:	89 15 57 bc 01 00    	mov    %edx,0x1bc57(%rip)        # 23148 <fwp_slice>
    74f1:	48 83 c4 08          	add    $0x8,%rsp
    74f5:	c3                   	ret
    74f6:	ba 0a 00 00 00       	mov    $0xa,%edx
    74fb:	31 f6                	xor    %esi,%esi
    74fd:	48 89 c7             	mov    %rax,%rdi
    7500:	e8 4b c0 ff ff       	call   3550 <strtoll@plt>
    7505:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7509:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7510:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7515:	0f 46 d0             	cmovbe %eax,%edx
    7518:	eb d1                	jmp    74eb <fwp_block+0x17b>
    751a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007520 <fwp_drop4>:
    7520:	48 8b 15 51 d6 01 00 	mov    0x1d651(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    7527:	48 89 f8             	mov    %rdi,%rax
    752a:	48 2b 05 1f d6 01 00 	sub    0x1d61f(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    7531:	48 c1 e2 10          	shl    $0x10,%rdx
    7535:	48 39 d0             	cmp    %rdx,%rax
    7538:	0f 83 52 01 00 00    	jae    7690 <fwp_drop4+0x170>
    753e:	48 83 ec 18          	sub    $0x18,%rsp
    7542:	4c 8d 05 57 c2 01 00 	lea    0x1c257(%rip),%r8        # 237a0 <fwp_heap>
    7549:	48 89 c2             	mov    %rax,%rdx
    754c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7553:	48 c1 ea 10          	shr    $0x10,%rdx
    7557:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    755b:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    755f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7563:	48 85 d2             	test   %rdx,%rdx
    7566:	74 46                	je     75ae <fwp_drop4+0x8e>
    7568:	44 0f b6 09          	movzbl (%rcx),%r9d
    756c:	41 80 f9 02          	cmp    $0x2,%r9b
    7570:	0f 84 ca 00 00 00    	je     7640 <fwp_drop4+0x120>
    7576:	41 80 f9 01          	cmp    $0x1,%r9b
    757a:	75 32                	jne    75ae <fwp_drop4+0x8e>
    757c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7580:	0f b7 c0             	movzwl %ax,%eax
    7583:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7586:	49 0f af c1          	imul   %r9,%rax
    758a:	48 c1 e8 20          	shr    $0x20,%rax
    758e:	48 39 c8             	cmp    %rcx,%rax
    7591:	73 1b                	jae    75ae <fwp_drop4+0x8e>
    7593:	48 01 c2             	add    %rax,%rdx
    7596:	0f b6 02             	movzbl (%rdx),%eax
    7599:	84 c0                	test   %al,%al
    759b:	74 11                	je     75ae <fwp_drop4+0x8e>
    759d:	3c 01                	cmp    $0x1,%al
    759f:	74 17                	je     75b8 <fwp_drop4+0x98>
    75a1:	3c ff                	cmp    $0xff,%al
    75a3:	0f 84 ef 00 00 00    	je     7698 <fwp_drop4+0x178>
    75a9:	83 e8 01             	sub    $0x1,%eax
    75ac:	88 02                	mov    %al,(%rdx)
    75ae:	48 83 c4 18          	add    $0x18,%rsp
    75b2:	c3                   	ret
    75b3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    75b8:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    75bc:	0f 88 8e 00 00 00    	js     7650 <fwp_drop4+0x130>
    75c2:	48 8b 15 af d5 01 00 	mov    0x1d5af(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    75c9:	48 89 f8             	mov    %rdi,%rax
    75cc:	48 2b 05 7d d5 01 00 	sub    0x1d57d(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    75d3:	48 c1 e2 10          	shl    $0x10,%rdx
    75d7:	48 39 d0             	cmp    %rdx,%rax
    75da:	73 d2                	jae    75ae <fwp_drop4+0x8e>
    75dc:	48 89 c2             	mov    %rax,%rdx
    75df:	48 c1 ea 10          	shr    $0x10,%rdx
    75e3:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    75e7:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    75eb:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    75ef:	48 85 c9             	test   %rcx,%rcx
    75f2:	74 ba                	je     75ae <fwp_drop4+0x8e>
    75f4:	0f b6 32             	movzbl (%rdx),%esi
    75f7:	40 80 fe 02          	cmp    $0x2,%sil
    75fb:	74 33                	je     7630 <fwp_drop4+0x110>
    75fd:	40 80 fe 01          	cmp    $0x1,%sil
    7601:	75 ab                	jne    75ae <fwp_drop4+0x8e>
    7603:	8b 72 18             	mov    0x18(%rdx),%esi
    7606:	0f b7 c0             	movzwl %ax,%eax
    7609:	8b 52 1c             	mov    0x1c(%rdx),%edx
    760c:	48 0f af c6          	imul   %rsi,%rax
    7610:	48 c1 e8 20          	shr    $0x20,%rax
    7614:	48 39 d0             	cmp    %rdx,%rax
    7617:	73 95                	jae    75ae <fwp_drop4+0x8e>
    7619:	48 01 c1             	add    %rax,%rcx
    761c:	80 39 01             	cmpb   $0x1,(%rcx)
    761f:	75 8d                	jne    75ae <fwp_drop4+0x8e>
    7621:	48 83 c4 18          	add    $0x18,%rsp
    7625:	e9 86 df ff ff       	jmp    55b0 <fwp_mem_free>
    762a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7630:	66 85 c0             	test   %ax,%ax
    7633:	74 e7                	je     761c <fwp_drop4+0xfc>
    7635:	48 83 c4 18          	add    $0x18,%rsp
    7639:	c3                   	ret
    763a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7640:	66 85 c0             	test   %ax,%ax
    7643:	0f 84 4d ff ff ff    	je     7596 <fwp_drop4+0x76>
    7649:	48 83 c4 18          	add    $0x18,%rsp
    764d:	c3                   	ret
    764e:	66 90                	xchg   %ax,%ax
    7650:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7654:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7659:	e8 b2 ef ff ff       	call   6610 <fwp_rc_free_arr>
    765e:	4c 8d 05 3b c1 01 00 	lea    0x1c13b(%rip),%r8        # 237a0 <fwp_heap>
    7665:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    766a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7671:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7678:	48 c1 e2 10          	shl    $0x10,%rdx
    767c:	48 39 d0             	cmp    %rdx,%rax
    767f:	0f 83 29 ff ff ff    	jae    75ae <fwp_drop4+0x8e>
    7685:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    768a:	e9 ba fe ff ff       	jmp    7549 <fwp_drop4+0x29>
    768f:	90                   	nop
    7690:	c3                   	ret
    7691:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7698:	48 89 d0             	mov    %rdx,%rax
    769b:	48 c1 e8 11          	shr    $0x11,%rax
    769f:	48 31 d0             	xor    %rdx,%rax
    76a2:	48 89 c1             	mov    %rax,%rcx
    76a5:	48 c1 e9 09          	shr    $0x9,%rcx
    76a9:	48 31 c8             	xor    %rcx,%rax
    76ac:	0f b6 c8             	movzbl %al,%ecx
    76af:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    76b6:	00 
    76b7:	48 85 c0             	test   %rax,%rax
    76ba:	75 0d                	jne    76c9 <fwp_drop4+0x1a9>
    76bc:	eb 46                	jmp    7704 <fwp_drop4+0x1e4>
    76be:	66 90                	xchg   %ax,%ax
    76c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    76c4:	48 85 c0             	test   %rax,%rax
    76c7:	74 3b                	je     7704 <fwp_drop4+0x1e4>
    76c9:	48 89 c1             	mov    %rax,%rcx
    76cc:	48 39 10             	cmp    %rdx,(%rax)
    76cf:	75 ef                	jne    76c0 <fwp_drop4+0x1a0>
    76d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    76d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    76d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    76dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    76e4:	0f 85 c4 fe ff ff    	jne    75ae <fwp_drop4+0x8e>
    76ea:	48 89 d7             	mov    %rdx,%rdi
    76ed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    76f2:	e8 79 dc ff ff       	call   5370 <fwp_rc_forget_slot>
    76f7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    76fc:	c6 02 fe             	movb   $0xfe,(%rdx)
    76ff:	e9 aa fe ff ff       	jmp    75ae <fwp_drop4+0x8e>
    7704:	48 8d 3d 8d 80 00 00 	lea    0x808d(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    770b:	e8 90 ca ff ff       	call   41a0 <fwp_trap>

0000000000007710 <fwp_caps161>:
    7710:	f3 0f 1e fa          	endbr64
    7714:	85 f6                	test   %esi,%esi
    7716:	74 08                	je     7720 <fwp_caps161+0x10>
    7718:	c3                   	ret
    7719:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7720:	48 8b 15 51 d4 01 00 	mov    0x1d451(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    7727:	48 89 f8             	mov    %rdi,%rax
    772a:	48 2b 05 1f d4 01 00 	sub    0x1d41f(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    7731:	48 c1 e2 10          	shl    $0x10,%rdx
    7735:	48 39 d0             	cmp    %rdx,%rax
    7738:	73 de                	jae    7718 <fwp_caps161+0x8>
    773a:	48 89 c2             	mov    %rax,%rdx
    773d:	48 c1 ea 10          	shr    $0x10,%rdx
    7741:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7745:	48 8b 15 4c d4 01 00 	mov    0x1d44c(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    774c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7750:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7754:	48 85 c9             	test   %rcx,%rcx
    7757:	74 bf                	je     7718 <fwp_caps161+0x8>
    7759:	0f b6 32             	movzbl (%rdx),%esi
    775c:	40 80 fe 02          	cmp    $0x2,%sil
    7760:	74 2e                	je     7790 <fwp_caps161+0x80>
    7762:	40 80 fe 01          	cmp    $0x1,%sil
    7766:	75 b0                	jne    7718 <fwp_caps161+0x8>
    7768:	8b 72 18             	mov    0x18(%rdx),%esi
    776b:	0f b7 c0             	movzwl %ax,%eax
    776e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7771:	48 0f af c6          	imul   %rsi,%rax
    7775:	48 c1 e8 20          	shr    $0x20,%rax
    7779:	48 39 d0             	cmp    %rdx,%rax
    777c:	73 9a                	jae    7718 <fwp_caps161+0x8>
    777e:	48 01 c1             	add    %rax,%rcx
    7781:	80 39 01             	cmpb   $0x1,(%rcx)
    7784:	75 92                	jne    7718 <fwp_caps161+0x8>
    7786:	e9 25 de ff ff       	jmp    55b0 <fwp_mem_free>
    778b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7790:	66 85 c0             	test   %ax,%ax
    7793:	74 ec                	je     7781 <fwp_caps161+0x71>
    7795:	c3                   	ret
    7796:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    779d:	00 00 00 

00000000000077a0 <fwp_args12>:
    77a0:	f3 0f 1e fa          	endbr64
    77a4:	85 d2                	test   %edx,%edx
    77a6:	74 04                	je     77ac <fwp_args12+0xc>
    77a8:	85 f6                	test   %esi,%esi
    77aa:	74 04                	je     77b0 <fwp_args12+0x10>
    77ac:	c3                   	ret
    77ad:	0f 1f 00             	nopl   (%rax)
    77b0:	48 8b 15 c1 d3 01 00 	mov    0x1d3c1(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    77b7:	48 8b 07             	mov    (%rdi),%rax
    77ba:	48 2b 05 8f d3 01 00 	sub    0x1d38f(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    77c1:	48 c1 e2 10          	shl    $0x10,%rdx
    77c5:	48 39 d0             	cmp    %rdx,%rax
    77c8:	73 e2                	jae    77ac <fwp_args12+0xc>
    77ca:	48 89 c2             	mov    %rax,%rdx
    77cd:	48 c1 ea 10          	shr    $0x10,%rdx
    77d1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    77d5:	48 8b 15 bc d3 01 00 	mov    0x1d3bc(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    77dc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    77e0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    77e4:	48 85 ff             	test   %rdi,%rdi
    77e7:	74 c3                	je     77ac <fwp_args12+0xc>
    77e9:	0f b6 0a             	movzbl (%rdx),%ecx
    77ec:	80 f9 02             	cmp    $0x2,%cl
    77ef:	74 2f                	je     7820 <fwp_args12+0x80>
    77f1:	80 f9 01             	cmp    $0x1,%cl
    77f4:	75 b6                	jne    77ac <fwp_args12+0xc>
    77f6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    77f9:	0f b7 c0             	movzwl %ax,%eax
    77fc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    77ff:	48 0f af c1          	imul   %rcx,%rax
    7803:	48 c1 e8 20          	shr    $0x20,%rax
    7807:	48 39 d0             	cmp    %rdx,%rax
    780a:	73 a0                	jae    77ac <fwp_args12+0xc>
    780c:	48 01 c7             	add    %rax,%rdi
    780f:	0f b6 07             	movzbl (%rdi),%eax
    7812:	84 c0                	test   %al,%al
    7814:	74 96                	je     77ac <fwp_args12+0xc>
    7816:	3c fd                	cmp    $0xfd,%al
    7818:	77 0c                	ja     7826 <fwp_args12+0x86>
    781a:	83 c0 01             	add    $0x1,%eax
    781d:	88 07                	mov    %al,(%rdi)
    781f:	c3                   	ret
    7820:	66 85 c0             	test   %ax,%ax
    7823:	74 ea                	je     780f <fwp_args12+0x6f>
    7825:	c3                   	ret
    7826:	e9 25 da ff ff       	jmp    5250 <fwp_rc_wide_dup>
    782b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007830 <fwp_args23>:
    7830:	f3 0f 1e fa          	endbr64
    7834:	85 d2                	test   %edx,%edx
    7836:	74 04                	je     783c <fwp_args23+0xc>
    7838:	85 f6                	test   %esi,%esi
    783a:	74 04                	je     7840 <fwp_args23+0x10>
    783c:	c3                   	ret
    783d:	0f 1f 00             	nopl   (%rax)
    7840:	48 8b 15 31 d3 01 00 	mov    0x1d331(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    7847:	48 8b 07             	mov    (%rdi),%rax
    784a:	48 2b 05 ff d2 01 00 	sub    0x1d2ff(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    7851:	48 c1 e2 10          	shl    $0x10,%rdx
    7855:	48 39 d0             	cmp    %rdx,%rax
    7858:	73 e2                	jae    783c <fwp_args23+0xc>
    785a:	48 89 c2             	mov    %rax,%rdx
    785d:	48 c1 ea 10          	shr    $0x10,%rdx
    7861:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7865:	48 8b 15 2c d3 01 00 	mov    0x1d32c(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    786c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7870:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7874:	48 85 ff             	test   %rdi,%rdi
    7877:	74 c3                	je     783c <fwp_args23+0xc>
    7879:	0f b6 0a             	movzbl (%rdx),%ecx
    787c:	80 f9 02             	cmp    $0x2,%cl
    787f:	74 2f                	je     78b0 <fwp_args23+0x80>
    7881:	80 f9 01             	cmp    $0x1,%cl
    7884:	75 b6                	jne    783c <fwp_args23+0xc>
    7886:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7889:	0f b7 c0             	movzwl %ax,%eax
    788c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    788f:	48 0f af c1          	imul   %rcx,%rax
    7893:	48 c1 e8 20          	shr    $0x20,%rax
    7897:	48 39 d0             	cmp    %rdx,%rax
    789a:	73 a0                	jae    783c <fwp_args23+0xc>
    789c:	48 01 c7             	add    %rax,%rdi
    789f:	0f b6 07             	movzbl (%rdi),%eax
    78a2:	84 c0                	test   %al,%al
    78a4:	74 96                	je     783c <fwp_args23+0xc>
    78a6:	3c fd                	cmp    $0xfd,%al
    78a8:	77 0c                	ja     78b6 <fwp_args23+0x86>
    78aa:	83 c0 01             	add    $0x1,%eax
    78ad:	88 07                	mov    %al,(%rdi)
    78af:	c3                   	ret
    78b0:	66 85 c0             	test   %ax,%ax
    78b3:	74 ea                	je     789f <fwp_args23+0x6f>
    78b5:	c3                   	ret
    78b6:	e9 95 d9 ff ff       	jmp    5250 <fwp_rc_wide_dup>
    78bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000078c0 <fwp_caps12>:
    78c0:	f3 0f 1e fa          	endbr64
    78c4:	48 83 ec 18          	sub    $0x18,%rsp
    78c8:	8b 57 04             	mov    0x4(%rdi),%edx
    78cb:	48 89 f8             	mov    %rdi,%rax
    78ce:	85 d2                	test   %edx,%edx
    78d0:	0f 84 9a 00 00 00    	je     7970 <fwp_caps12+0xb0>
    78d6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    78da:	85 f6                	test   %esi,%esi
    78dc:	0f 85 9e 00 00 00    	jne    7980 <fwp_caps12+0xc0>
    78e2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    78e7:	e8 34 f0 ff ff       	call   6920 <fwp_drop0>
    78ec:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    78f1:	48 8b 0d 80 d2 01 00 	mov    0x1d280(%rip),%rcx        # 24b78 <fwp_heap+0x13d8>
    78f8:	48 89 c2             	mov    %rax,%rdx
    78fb:	48 2b 15 4e d2 01 00 	sub    0x1d24e(%rip),%rdx        # 24b50 <fwp_heap+0x13b0>
    7902:	48 c1 e1 10          	shl    $0x10,%rcx
    7906:	48 39 ca             	cmp    %rcx,%rdx
    7909:	73 6d                	jae    7978 <fwp_caps12+0xb8>
    790b:	48 89 d1             	mov    %rdx,%rcx
    790e:	48 c1 e9 10          	shr    $0x10,%rcx
    7912:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7916:	48 8b 0d 7b d2 01 00 	mov    0x1d27b(%rip),%rcx        # 24b98 <fwp_heap+0x13f8>
    791d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7921:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7925:	48 85 f6             	test   %rsi,%rsi
    7928:	74 4e                	je     7978 <fwp_caps12+0xb8>
    792a:	0f b6 39             	movzbl (%rcx),%edi
    792d:	40 80 ff 02          	cmp    $0x2,%dil
    7931:	0f 84 b9 00 00 00    	je     79f0 <fwp_caps12+0x130>
    7937:	40 80 ff 01          	cmp    $0x1,%dil
    793b:	75 3b                	jne    7978 <fwp_caps12+0xb8>
    793d:	8b 79 18             	mov    0x18(%rcx),%edi
    7940:	0f b7 d2             	movzwl %dx,%edx
    7943:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7946:	48 0f af d7          	imul   %rdi,%rdx
    794a:	48 c1 ea 20          	shr    $0x20,%rdx
    794e:	48 39 ca             	cmp    %rcx,%rdx
    7951:	73 25                	jae    7978 <fwp_caps12+0xb8>
    7953:	48 01 d6             	add    %rdx,%rsi
    7956:	80 3e 01             	cmpb   $0x1,(%rsi)
    7959:	75 1d                	jne    7978 <fwp_caps12+0xb8>
    795b:	48 89 c7             	mov    %rax,%rdi
    795e:	48 83 c4 18          	add    $0x18,%rsp
    7962:	e9 49 dc ff ff       	jmp    55b0 <fwp_mem_free>
    7967:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    796e:	00 00 
    7970:	85 f6                	test   %esi,%esi
    7972:	0f 84 79 ff ff ff    	je     78f1 <fwp_caps12+0x31>
    7978:	48 83 c4 18          	add    $0x18,%rsp
    797c:	c3                   	ret
    797d:	0f 1f 00             	nopl   (%rax)
    7980:	48 8b 05 f1 d1 01 00 	mov    0x1d1f1(%rip),%rax        # 24b78 <fwp_heap+0x13d8>
    7987:	48 2b 3d c2 d1 01 00 	sub    0x1d1c2(%rip),%rdi        # 24b50 <fwp_heap+0x13b0>
    798e:	48 c1 e0 10          	shl    $0x10,%rax
    7992:	48 39 c7             	cmp    %rax,%rdi
    7995:	73 e1                	jae    7978 <fwp_caps12+0xb8>
    7997:	48 89 f8             	mov    %rdi,%rax
    799a:	48 c1 e8 10          	shr    $0x10,%rax
    799e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    79a2:	48 8b 05 ef d1 01 00 	mov    0x1d1ef(%rip),%rax        # 24b98 <fwp_heap+0x13f8>
    79a9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    79ad:	48 8b 42 20          	mov    0x20(%rdx),%rax
    79b1:	48 85 c0             	test   %rax,%rax
    79b4:	74 c2                	je     7978 <fwp_caps12+0xb8>
    79b6:	0f b6 0a             	movzbl (%rdx),%ecx
    79b9:	80 f9 02             	cmp    $0x2,%cl
    79bc:	74 42                	je     7a00 <fwp_caps12+0x140>
    79be:	80 f9 01             	cmp    $0x1,%cl
    79c1:	75 b5                	jne    7978 <fwp_caps12+0xb8>
    79c3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    79c6:	0f b7 ff             	movzwl %di,%edi
    79c9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    79cc:	48 0f af f9          	imul   %rcx,%rdi
    79d0:	48 c1 ef 20          	shr    $0x20,%rdi
    79d4:	48 39 d7             	cmp    %rdx,%rdi
    79d7:	73 9f                	jae    7978 <fwp_caps12+0xb8>
    79d9:	48 01 f8             	add    %rdi,%rax
    79dc:	0f b6 10             	movzbl (%rax),%edx
    79df:	84 d2                	test   %dl,%dl
    79e1:	74 95                	je     7978 <fwp_caps12+0xb8>
    79e3:	80 fa fd             	cmp    $0xfd,%dl
    79e6:	77 23                	ja     7a0b <fwp_caps12+0x14b>
    79e8:	83 c2 01             	add    $0x1,%edx
    79eb:	88 10                	mov    %dl,(%rax)
    79ed:	eb 89                	jmp    7978 <fwp_caps12+0xb8>
    79ef:	90                   	nop
    79f0:	66 85 d2             	test   %dx,%dx
    79f3:	0f 85 7f ff ff ff    	jne    7978 <fwp_caps12+0xb8>
    79f9:	e9 58 ff ff ff       	jmp    7956 <fwp_caps12+0x96>
    79fe:	66 90                	xchg   %ax,%ax
    7a00:	66 85 ff             	test   %di,%di
    7a03:	0f 85 6f ff ff ff    	jne    7978 <fwp_caps12+0xb8>
    7a09:	eb d1                	jmp    79dc <fwp_caps12+0x11c>
    7a0b:	48 89 c7             	mov    %rax,%rdi
    7a0e:	48 83 c4 18          	add    $0x18,%rsp
    7a12:	e9 39 d8 ff ff       	jmp    5250 <fwp_rc_wide_dup>
    7a17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a1e:	00 00 

0000000000007a20 <fwp_drop2>:
    7a20:	48 8b 0d 51 d1 01 00 	mov    0x1d151(%rip),%rcx        # 24b78 <fwp_heap+0x13d8>
    7a27:	48 89 f8             	mov    %rdi,%rax
    7a2a:	48 2b 05 1f d1 01 00 	sub    0x1d11f(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    7a31:	48 c1 e1 10          	shl    $0x10,%rcx
    7a35:	48 39 c8             	cmp    %rcx,%rax
    7a38:	0f 83 42 01 00 00    	jae    7b80 <fwp_drop2+0x160>
    7a3e:	48 83 ec 18          	sub    $0x18,%rsp
    7a42:	48 89 fa             	mov    %rdi,%rdx
    7a45:	4c 8d 05 54 bd 01 00 	lea    0x1bd54(%rip),%r8        # 237a0 <fwp_heap>
    7a4c:	48 89 c1             	mov    %rax,%rcx
    7a4f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7a56:	48 c1 e9 10          	shr    $0x10,%rcx
    7a5a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7a5e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7a62:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7a66:	48 85 c9             	test   %rcx,%rcx
    7a69:	74 40                	je     7aab <fwp_drop2+0x8b>
    7a6b:	0f b6 3e             	movzbl (%rsi),%edi
    7a6e:	40 80 ff 02          	cmp    $0x2,%dil
    7a72:	74 3c                	je     7ab0 <fwp_drop2+0x90>
    7a74:	40 80 ff 01          	cmp    $0x1,%dil
    7a78:	75 31                	jne    7aab <fwp_drop2+0x8b>
    7a7a:	8b 7e 18             	mov    0x18(%rsi),%edi
    7a7d:	0f b7 c0             	movzwl %ax,%eax
    7a80:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7a83:	48 0f af c7          	imul   %rdi,%rax
    7a87:	48 c1 e8 20          	shr    $0x20,%rax
    7a8b:	48 39 f0             	cmp    %rsi,%rax
    7a8e:	73 1b                	jae    7aab <fwp_drop2+0x8b>
    7a90:	48 01 c1             	add    %rax,%rcx
    7a93:	0f b6 01             	movzbl (%rcx),%eax
    7a96:	84 c0                	test   %al,%al
    7a98:	74 11                	je     7aab <fwp_drop2+0x8b>
    7a9a:	3c 01                	cmp    $0x1,%al
    7a9c:	74 22                	je     7ac0 <fwp_drop2+0xa0>
    7a9e:	3c ff                	cmp    $0xff,%al
    7aa0:	0f 84 0a 01 00 00    	je     7bb0 <fwp_drop2+0x190>
    7aa6:	83 e8 01             	sub    $0x1,%eax
    7aa9:	88 01                	mov    %al,(%rcx)
    7aab:	48 83 c4 18          	add    $0x18,%rsp
    7aaf:	c3                   	ret
    7ab0:	66 85 c0             	test   %ax,%ax
    7ab3:	74 de                	je     7a93 <fwp_drop2+0x73>
    7ab5:	48 83 c4 18          	add    $0x18,%rsp
    7ab9:	c3                   	ret
    7aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ac0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7ac4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    7acb:	48 89 f8             	mov    %rdi,%rax
    7ace:	48 c1 e1 10          	shl    $0x10,%rcx
    7ad2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7ad9:	48 39 c8             	cmp    %rcx,%rax
    7adc:	73 62                	jae    7b40 <fwp_drop2+0x120>
    7ade:	48 89 c1             	mov    %rax,%rcx
    7ae1:	48 c1 e9 10          	shr    $0x10,%rcx
    7ae5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7ae9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7aed:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7af1:	48 85 c9             	test   %rcx,%rcx
    7af4:	74 4a                	je     7b40 <fwp_drop2+0x120>
    7af6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    7afa:	41 80 f9 02          	cmp    $0x2,%r9b
    7afe:	0f 84 9c 00 00 00    	je     7ba0 <fwp_drop2+0x180>
    7b04:	41 80 f9 01          	cmp    $0x1,%r9b
    7b08:	75 36                	jne    7b40 <fwp_drop2+0x120>
    7b0a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    7b0e:	0f b7 c0             	movzwl %ax,%eax
    7b11:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7b14:	49 0f af c1          	imul   %r9,%rax
    7b18:	48 c1 e8 20          	shr    $0x20,%rax
    7b1c:	48 39 f0             	cmp    %rsi,%rax
    7b1f:	73 1f                	jae    7b40 <fwp_drop2+0x120>
    7b21:	48 01 c1             	add    %rax,%rcx
    7b24:	0f b6 01             	movzbl (%rcx),%eax
    7b27:	84 c0                	test   %al,%al
    7b29:	74 15                	je     7b40 <fwp_drop2+0x120>
    7b2b:	3c 01                	cmp    $0x1,%al
    7b2d:	74 59                	je     7b88 <fwp_drop2+0x168>
    7b2f:	3c ff                	cmp    $0xff,%al
    7b31:	0f 84 ef 00 00 00    	je     7c26 <fwp_drop2+0x206>
    7b37:	83 e8 01             	sub    $0x1,%eax
    7b3a:	88 01                	mov    %al,(%rcx)
    7b3c:	0f 1f 40 00          	nopl   0x0(%rax)
    7b40:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7b44:	48 89 d7             	mov    %rdx,%rdi
    7b47:	48 89 0c 24          	mov    %rcx,(%rsp)
    7b4b:	e8 c0 ea ff ff       	call   6610 <fwp_rc_free_arr>
    7b50:	4c 8d 05 49 bc 01 00 	lea    0x1bc49(%rip),%r8        # 237a0 <fwp_heap>
    7b57:	48 8b 04 24          	mov    (%rsp),%rax
    7b5b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7b62:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7b69:	48 c1 e2 10          	shl    $0x10,%rdx
    7b6d:	48 39 d0             	cmp    %rdx,%rax
    7b70:	0f 83 35 ff ff ff    	jae    7aab <fwp_drop2+0x8b>
    7b76:	48 8b 14 24          	mov    (%rsp),%rdx
    7b7a:	e9 cd fe ff ff       	jmp    7a4c <fwp_drop2+0x2c>
    7b7f:	90                   	nop
    7b80:	c3                   	ret
    7b81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7b88:	48 89 14 24          	mov    %rdx,(%rsp)
    7b8c:	e8 7f ea ff ff       	call   6610 <fwp_rc_free_arr>
    7b91:	48 8b 14 24          	mov    (%rsp),%rdx
    7b95:	eb a9                	jmp    7b40 <fwp_drop2+0x120>
    7b97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7b9e:	00 00 
    7ba0:	66 85 c0             	test   %ax,%ax
    7ba3:	75 9b                	jne    7b40 <fwp_drop2+0x120>
    7ba5:	e9 7a ff ff ff       	jmp    7b24 <fwp_drop2+0x104>
    7baa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7bb0:	48 89 c8             	mov    %rcx,%rax
    7bb3:	48 c1 e8 11          	shr    $0x11,%rax
    7bb7:	48 31 c8             	xor    %rcx,%rax
    7bba:	48 89 c2             	mov    %rax,%rdx
    7bbd:	48 c1 ea 09          	shr    $0x9,%rdx
    7bc1:	48 31 d0             	xor    %rdx,%rax
    7bc4:	0f b6 d0             	movzbl %al,%edx
    7bc7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    7bce:	00 
    7bcf:	48 85 c0             	test   %rax,%rax
    7bd2:	75 19                	jne    7bed <fwp_drop2+0x1cd>
    7bd4:	e9 d3 00 00 00       	jmp    7cac <fwp_drop2+0x28c>
    7bd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7be0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7be4:	48 85 c0             	test   %rax,%rax
    7be7:	0f 84 bf 00 00 00    	je     7cac <fwp_drop2+0x28c>
    7bed:	48 89 c2             	mov    %rax,%rdx
    7bf0:	48 39 08             	cmp    %rcx,(%rax)
    7bf3:	75 eb                	jne    7be0 <fwp_drop2+0x1c0>
    7bf5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7bf9:	48 83 ea 01          	sub    $0x1,%rdx
    7bfd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7c01:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7c08:	0f 85 9d fe ff ff    	jne    7aab <fwp_drop2+0x8b>
    7c0e:	48 89 cf             	mov    %rcx,%rdi
    7c11:	48 89 0c 24          	mov    %rcx,(%rsp)
    7c15:	e8 56 d7 ff ff       	call   5370 <fwp_rc_forget_slot>
    7c1a:	48 8b 0c 24          	mov    (%rsp),%rcx
    7c1e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7c21:	e9 85 fe ff ff       	jmp    7aab <fwp_drop2+0x8b>
    7c26:	48 89 ce             	mov    %rcx,%rsi
    7c29:	48 c1 ee 11          	shr    $0x11,%rsi
    7c2d:	48 31 ce             	xor    %rcx,%rsi
    7c30:	48 89 f0             	mov    %rsi,%rax
    7c33:	48 c1 e8 09          	shr    $0x9,%rax
    7c37:	48 31 c6             	xor    %rax,%rsi
    7c3a:	40 0f b6 f6          	movzbl %sil,%esi
    7c3e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7c45:	00 
    7c46:	48 85 c0             	test   %rax,%rax
    7c49:	75 1e                	jne    7c69 <fwp_drop2+0x249>
    7c4b:	eb 5f                	jmp    7cac <fwp_drop2+0x28c>
    7c4d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7c54:	00 
    7c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7c5c:	00 00 00 00 
    7c60:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7c64:	48 85 c0             	test   %rax,%rax
    7c67:	74 43                	je     7cac <fwp_drop2+0x28c>
    7c69:	48 89 c6             	mov    %rax,%rsi
    7c6c:	48 39 08             	cmp    %rcx,(%rax)
    7c6f:	75 ef                	jne    7c60 <fwp_drop2+0x240>
    7c71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7c75:	48 83 ee 01          	sub    $0x1,%rsi
    7c79:	48 89 70 08          	mov    %rsi,0x8(%rax)
    7c7d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7c84:	0f 85 b6 fe ff ff    	jne    7b40 <fwp_drop2+0x120>
    7c8a:	48 89 cf             	mov    %rcx,%rdi
    7c8d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7c92:	48 89 0c 24          	mov    %rcx,(%rsp)
    7c96:	e8 d5 d6 ff ff       	call   5370 <fwp_rc_forget_slot>
    7c9b:	48 8b 0c 24          	mov    (%rsp),%rcx
    7c9f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7ca4:	c6 01 fe             	movb   $0xfe,(%rcx)
    7ca7:	e9 94 fe ff ff       	jmp    7b40 <fwp_drop2+0x120>
    7cac:	48 8d 3d e5 7a 00 00 	lea    0x7ae5(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    7cb3:	e8 e8 c4 ff ff       	call   41a0 <fwp_trap>
    7cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7cbf:	00 

0000000000007cc0 <fwp_arg_drop23>:
    7cc0:	f3 0f 1e fa          	endbr64
    7cc4:	85 f6                	test   %esi,%esi
    7cc6:	75 04                	jne    7ccc <fwp_arg_drop23+0xc>
    7cc8:	85 d2                	test   %edx,%edx
    7cca:	75 04                	jne    7cd0 <fwp_arg_drop23+0x10>
    7ccc:	c3                   	ret
    7ccd:	0f 1f 00             	nopl   (%rax)
    7cd0:	48 8b 3f             	mov    (%rdi),%rdi
    7cd3:	e9 48 fd ff ff       	jmp    7a20 <fwp_drop2>
    7cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7cdf:	00 

0000000000007ce0 <fwp_caps23>:
    7ce0:	f3 0f 1e fa          	endbr64
    7ce4:	48 83 ec 18          	sub    $0x18,%rsp
    7ce8:	8b 57 04             	mov    0x4(%rdi),%edx
    7ceb:	48 89 f8             	mov    %rdi,%rax
    7cee:	85 d2                	test   %edx,%edx
    7cf0:	0f 84 9a 00 00 00    	je     7d90 <fwp_caps23+0xb0>
    7cf6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7cfa:	85 f6                	test   %esi,%esi
    7cfc:	0f 85 9e 00 00 00    	jne    7da0 <fwp_caps23+0xc0>
    7d02:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7d07:	e8 14 fd ff ff       	call   7a20 <fwp_drop2>
    7d0c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7d11:	48 8b 0d 60 ce 01 00 	mov    0x1ce60(%rip),%rcx        # 24b78 <fwp_heap+0x13d8>
    7d18:	48 89 c2             	mov    %rax,%rdx
    7d1b:	48 2b 15 2e ce 01 00 	sub    0x1ce2e(%rip),%rdx        # 24b50 <fwp_heap+0x13b0>
    7d22:	48 c1 e1 10          	shl    $0x10,%rcx
    7d26:	48 39 ca             	cmp    %rcx,%rdx
    7d29:	73 6d                	jae    7d98 <fwp_caps23+0xb8>
    7d2b:	48 89 d1             	mov    %rdx,%rcx
    7d2e:	48 c1 e9 10          	shr    $0x10,%rcx
    7d32:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7d36:	48 8b 0d 5b ce 01 00 	mov    0x1ce5b(%rip),%rcx        # 24b98 <fwp_heap+0x13f8>
    7d3d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7d41:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7d45:	48 85 f6             	test   %rsi,%rsi
    7d48:	74 4e                	je     7d98 <fwp_caps23+0xb8>
    7d4a:	0f b6 39             	movzbl (%rcx),%edi
    7d4d:	40 80 ff 02          	cmp    $0x2,%dil
    7d51:	0f 84 b9 00 00 00    	je     7e10 <fwp_caps23+0x130>
    7d57:	40 80 ff 01          	cmp    $0x1,%dil
    7d5b:	75 3b                	jne    7d98 <fwp_caps23+0xb8>
    7d5d:	8b 79 18             	mov    0x18(%rcx),%edi
    7d60:	0f b7 d2             	movzwl %dx,%edx
    7d63:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7d66:	48 0f af d7          	imul   %rdi,%rdx
    7d6a:	48 c1 ea 20          	shr    $0x20,%rdx
    7d6e:	48 39 ca             	cmp    %rcx,%rdx
    7d71:	73 25                	jae    7d98 <fwp_caps23+0xb8>
    7d73:	48 01 d6             	add    %rdx,%rsi
    7d76:	80 3e 01             	cmpb   $0x1,(%rsi)
    7d79:	75 1d                	jne    7d98 <fwp_caps23+0xb8>
    7d7b:	48 89 c7             	mov    %rax,%rdi
    7d7e:	48 83 c4 18          	add    $0x18,%rsp
    7d82:	e9 29 d8 ff ff       	jmp    55b0 <fwp_mem_free>
    7d87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7d8e:	00 00 
    7d90:	85 f6                	test   %esi,%esi
    7d92:	0f 84 79 ff ff ff    	je     7d11 <fwp_caps23+0x31>
    7d98:	48 83 c4 18          	add    $0x18,%rsp
    7d9c:	c3                   	ret
    7d9d:	0f 1f 00             	nopl   (%rax)
    7da0:	48 8b 05 d1 cd 01 00 	mov    0x1cdd1(%rip),%rax        # 24b78 <fwp_heap+0x13d8>
    7da7:	48 2b 3d a2 cd 01 00 	sub    0x1cda2(%rip),%rdi        # 24b50 <fwp_heap+0x13b0>
    7dae:	48 c1 e0 10          	shl    $0x10,%rax
    7db2:	48 39 c7             	cmp    %rax,%rdi
    7db5:	73 e1                	jae    7d98 <fwp_caps23+0xb8>
    7db7:	48 89 f8             	mov    %rdi,%rax
    7dba:	48 c1 e8 10          	shr    $0x10,%rax
    7dbe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7dc2:	48 8b 05 cf cd 01 00 	mov    0x1cdcf(%rip),%rax        # 24b98 <fwp_heap+0x13f8>
    7dc9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7dcd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7dd1:	48 85 c0             	test   %rax,%rax
    7dd4:	74 c2                	je     7d98 <fwp_caps23+0xb8>
    7dd6:	0f b6 0a             	movzbl (%rdx),%ecx
    7dd9:	80 f9 02             	cmp    $0x2,%cl
    7ddc:	74 42                	je     7e20 <fwp_caps23+0x140>
    7dde:	80 f9 01             	cmp    $0x1,%cl
    7de1:	75 b5                	jne    7d98 <fwp_caps23+0xb8>
    7de3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7de6:	0f b7 ff             	movzwl %di,%edi
    7de9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7dec:	48 0f af f9          	imul   %rcx,%rdi
    7df0:	48 c1 ef 20          	shr    $0x20,%rdi
    7df4:	48 39 d7             	cmp    %rdx,%rdi
    7df7:	73 9f                	jae    7d98 <fwp_caps23+0xb8>
    7df9:	48 01 f8             	add    %rdi,%rax
    7dfc:	0f b6 10             	movzbl (%rax),%edx
    7dff:	84 d2                	test   %dl,%dl
    7e01:	74 95                	je     7d98 <fwp_caps23+0xb8>
    7e03:	80 fa fd             	cmp    $0xfd,%dl
    7e06:	77 23                	ja     7e2b <fwp_caps23+0x14b>
    7e08:	83 c2 01             	add    $0x1,%edx
    7e0b:	88 10                	mov    %dl,(%rax)
    7e0d:	eb 89                	jmp    7d98 <fwp_caps23+0xb8>
    7e0f:	90                   	nop
    7e10:	66 85 d2             	test   %dx,%dx
    7e13:	0f 85 7f ff ff ff    	jne    7d98 <fwp_caps23+0xb8>
    7e19:	e9 58 ff ff ff       	jmp    7d76 <fwp_caps23+0x96>
    7e1e:	66 90                	xchg   %ax,%ax
    7e20:	66 85 ff             	test   %di,%di
    7e23:	0f 85 6f ff ff ff    	jne    7d98 <fwp_caps23+0xb8>
    7e29:	eb d1                	jmp    7dfc <fwp_caps23+0x11c>
    7e2b:	48 89 c7             	mov    %rax,%rdi
    7e2e:	48 83 c4 18          	add    $0x18,%rsp
    7e32:	e9 19 d4 ff ff       	jmp    5250 <fwp_rc_wide_dup>
    7e37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7e3e:	00 00 

0000000000007e40 <f23>:
    7e40:	41 57                	push   %r15
    7e42:	41 56                	push   %r14
    7e44:	41 55                	push   %r13
    7e46:	41 54                	push   %r12
    7e48:	55                   	push   %rbp
    7e49:	53                   	push   %rbx
    7e4a:	48 83 ec 38          	sub    $0x38,%rsp
    7e4e:	48 8b 15 23 cd 01 00 	mov    0x1cd23(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    7e55:	48 8b 0d f4 cc 01 00 	mov    0x1ccf4(%rip),%rcx        # 24b50 <fwp_heap+0x13b0>
    7e5c:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7e63:	00 00 
    7e65:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7e6a:	49 89 fc             	mov    %rdi,%r12
    7e6d:	48 c1 e2 10          	shl    $0x10,%rdx
    7e71:	48 85 ff             	test   %rdi,%rdi
    7e74:	0f 84 bc 02 00 00    	je     8136 <f23+0x2f6>
    7e7a:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7e7f:	48 89 d8             	mov    %rbx,%rax
    7e82:	48 29 c8             	sub    %rcx,%rax
    7e85:	48 39 d0             	cmp    %rdx,%rax
    7e88:	0f 83 72 03 00 00    	jae    8200 <f23+0x3c0>
    7e8e:	48 89 c2             	mov    %rax,%rdx
    7e91:	48 c1 ea 10          	shr    $0x10,%rdx
    7e95:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e99:	48 8b 15 f8 cc 01 00 	mov    0x1ccf8(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    7ea0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ea4:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7ea8:	48 85 ff             	test   %rdi,%rdi
    7eab:	0f 84 4f 03 00 00    	je     8200 <f23+0x3c0>
    7eb1:	0f b6 0a             	movzbl (%rdx),%ecx
    7eb4:	80 f9 02             	cmp    $0x2,%cl
    7eb7:	0f 84 53 02 00 00    	je     8110 <f23+0x2d0>
    7ebd:	80 f9 01             	cmp    $0x1,%cl
    7ec0:	75 24                	jne    7ee6 <f23+0xa6>
    7ec2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ec5:	0f b7 c0             	movzwl %ax,%eax
    7ec8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7ecb:	48 0f af c1          	imul   %rcx,%rax
    7ecf:	48 c1 e8 20          	shr    $0x20,%rax
    7ed3:	48 39 d0             	cmp    %rdx,%rax
    7ed6:	73 0e                	jae    7ee6 <f23+0xa6>
    7ed8:	48 01 c7             	add    %rax,%rdi
    7edb:	0f b6 07             	movzbl (%rdi),%eax
    7ede:	84 c0                	test   %al,%al
    7ee0:	0f 85 ca 02 00 00    	jne    81b0 <f23+0x370>
    7ee6:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7eeb:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7ef0:	ba 01 00 00 00       	mov    $0x1,%edx
    7ef5:	48 85 db             	test   %rbx,%rbx
    7ef8:	74 13                	je     7f0d <f23+0xcd>
    7efa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7f00:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7f04:	48 83 c2 01          	add    $0x1,%rdx
    7f08:	48 85 db             	test   %rbx,%rbx
    7f0b:	75 f3                	jne    7f00 <f23+0xc0>
    7f0d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7f12:	48 85 c0             	test   %rax,%rax
    7f15:	0f 84 15 03 00 00    	je     8230 <f23+0x3f0>
    7f1b:	31 db                	xor    %ebx,%ebx
    7f1d:	0f 1f 00             	nopl   (%rax)
    7f20:	48 8b 40 10          	mov    0x10(%rax),%rax
    7f24:	48 83 c3 01          	add    $0x1,%rbx
    7f28:	48 85 c0             	test   %rax,%rax
    7f2b:	75 f3                	jne    7f20 <f23+0xe0>
    7f2d:	48 39 d3             	cmp    %rdx,%rbx
    7f30:	48 0f 47 da          	cmova  %rdx,%rbx
    7f34:	48 89 d8             	mov    %rbx,%rax
    7f37:	48 c1 e8 3c          	shr    $0x3c,%rax
    7f3b:	0f 85 8f 03 00 00    	jne    82d0 <f23+0x490>
    7f41:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7f45:	be 02 00 00 00       	mov    $0x2,%esi
    7f4a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7f51:	00 
    7f52:	e8 59 db ff ff       	call   5ab0 <fwp_heap_alloc>
    7f57:	48 89 28             	mov    %rbp,(%rax)
    7f5a:	48 8b 15 17 cc 01 00 	mov    0x1cc17(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    7f61:	49 89 c6             	mov    %rax,%r14
    7f64:	48 2b 05 e5 cb 01 00 	sub    0x1cbe5(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    7f6b:	48 c1 e2 10          	shl    $0x10,%rdx
    7f6f:	48 39 d0             	cmp    %rdx,%rax
    7f72:	73 57                	jae    7fcb <f23+0x18b>
    7f74:	48 89 c2             	mov    %rax,%rdx
    7f77:	48 c1 ea 10          	shr    $0x10,%rdx
    7f7b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7f7f:	48 8b 15 12 cc 01 00 	mov    0x1cc12(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    7f86:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7f8a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7f8e:	48 85 ed             	test   %rbp,%rbp
    7f91:	74 38                	je     7fcb <f23+0x18b>
    7f93:	0f b6 0a             	movzbl (%rdx),%ecx
    7f96:	80 f9 02             	cmp    $0x2,%cl
    7f99:	0f 84 51 02 00 00    	je     81f0 <f23+0x3b0>
    7f9f:	80 f9 01             	cmp    $0x1,%cl
    7fa2:	75 27                	jne    7fcb <f23+0x18b>
    7fa4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7fa7:	0f b7 c0             	movzwl %ax,%eax
    7faa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7fad:	48 0f af c1          	imul   %rcx,%rax
    7fb1:	48 c1 e8 20          	shr    $0x20,%rax
    7fb5:	48 39 d0             	cmp    %rdx,%rax
    7fb8:	73 11                	jae    7fcb <f23+0x18b>
    7fba:	48 01 c5             	add    %rax,%rbp
    7fbd:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7fc1:	0f 84 d5 02 00 00    	je     829c <f23+0x45c>
    7fc7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7fcb:	48 85 db             	test   %rbx,%rbx
    7fce:	74 5d                	je     802d <f23+0x1ed>
    7fd0:	48 c1 e3 04          	shl    $0x4,%rbx
    7fd4:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    7fd9:	4c 89 f5             	mov    %r14,%rbp
    7fdc:	4d 89 e5             	mov    %r12,%r13
    7fdf:	4c 01 f3             	add    %r14,%rbx
    7fe2:	0f 1f 00             	nopl   (%rax)
    7fe5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7fec:	00 00 00 00 
    7ff0:	49 8b 45 08          	mov    0x8(%r13),%rax
    7ff4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    7ff8:	48 83 c5 10          	add    $0x10,%rbp
    7ffc:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8001:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8005:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8009:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    800e:	e8 7d e1 ff ff       	call   6190 <w107>
    8013:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8018:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    801c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8020:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8024:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    8028:	48 39 dd             	cmp    %rbx,%rbp
    802b:	75 c3                	jne    7ff0 <f23+0x1b0>
    802d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8032:	e8 e9 f9 ff ff       	call   7a20 <fwp_drop2>
    8037:	4c 89 e7             	mov    %r12,%rdi
    803a:	e8 e1 f9 ff ff       	call   7a20 <fwp_drop2>
    803f:	4c 89 f7             	mov    %r14,%rdi
    8042:	e8 c9 e2 ff ff       	call   6310 <w164.constprop.0>
    8047:	4c 89 f7             	mov    %r14,%rdi
    804a:	48 89 c3             	mov    %rax,%rbx
    804d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8053:	e8 c8 f4 ff ff       	call   7520 <fwp_drop4>
    8058:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    805e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    8063:	31 ff                	xor    %edi,%edi
    8065:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    806a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    806e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    8073:	e8 38 e3 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    8078:	48 8b 15 f9 ca 01 00 	mov    0x1caf9(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    807f:	48 89 c5             	mov    %rax,%rbp
    8082:	48 2b 05 c7 ca 01 00 	sub    0x1cac7(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    8089:	48 c1 e2 10          	shl    $0x10,%rdx
    808d:	48 39 d0             	cmp    %rdx,%rax
    8090:	73 55                	jae    80e7 <f23+0x2a7>
    8092:	48 89 c2             	mov    %rax,%rdx
    8095:	48 c1 ea 10          	shr    $0x10,%rdx
    8099:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    809d:	48 8b 15 f4 ca 01 00 	mov    0x1caf4(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    80a4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    80a8:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    80ac:	48 85 db             	test   %rbx,%rbx
    80af:	74 36                	je     80e7 <f23+0x2a7>
    80b1:	0f b6 0a             	movzbl (%rdx),%ecx
    80b4:	80 f9 02             	cmp    $0x2,%cl
    80b7:	0f 84 1b 01 00 00    	je     81d8 <f23+0x398>
    80bd:	80 f9 01             	cmp    $0x1,%cl
    80c0:	75 25                	jne    80e7 <f23+0x2a7>
    80c2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    80c5:	0f b7 c0             	movzwl %ax,%eax
    80c8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    80cb:	48 0f af c1          	imul   %rcx,%rax
    80cf:	48 c1 e8 20          	shr    $0x20,%rax
    80d3:	48 39 d0             	cmp    %rdx,%rax
    80d6:	73 0f                	jae    80e7 <f23+0x2a7>
    80d8:	48 01 c3             	add    %rax,%rbx
    80db:	80 3b ff             	cmpb   $0xff,(%rbx)
    80de:	0f 84 ab 01 00 00    	je     828f <f23+0x44f>
    80e4:	c6 03 01             	movb   $0x1,(%rbx)
    80e7:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    80ec:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    80f3:	00 00 
    80f5:	0f 85 d0 01 00 00    	jne    82cb <f23+0x48b>
    80fb:	48 83 c4 38          	add    $0x38,%rsp
    80ff:	48 89 e8             	mov    %rbp,%rax
    8102:	5b                   	pop    %rbx
    8103:	5d                   	pop    %rbp
    8104:	41 5c                	pop    %r12
    8106:	41 5d                	pop    %r13
    8108:	41 5e                	pop    %r14
    810a:	41 5f                	pop    %r15
    810c:	c3                   	ret
    810d:	0f 1f 00             	nopl   (%rax)
    8110:	66 85 c0             	test   %ax,%ax
    8113:	0f 85 cd fd ff ff    	jne    7ee6 <f23+0xa6>
    8119:	0f b6 07             	movzbl (%rdi),%eax
    811c:	84 c0                	test   %al,%al
    811e:	0f 84 c2 fd ff ff    	je     7ee6 <f23+0xa6>
    8124:	3c fd                	cmp    $0xfd,%al
    8126:	0f 87 95 01 00 00    	ja     82c1 <f23+0x481>
    812c:	83 c0 01             	add    $0x1,%eax
    812f:	88 07                	mov    %al,(%rdi)
    8131:	e9 b0 fd ff ff       	jmp    7ee6 <f23+0xa6>
    8136:	48 f7 d9             	neg    %rcx
    8139:	48 39 d1             	cmp    %rdx,%rcx
    813c:	0f 83 ee 00 00 00    	jae    8230 <f23+0x3f0>
    8142:	48 89 c8             	mov    %rcx,%rax
    8145:	48 c1 e8 10          	shr    $0x10,%rax
    8149:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    814d:	48 8b 05 44 ca 01 00 	mov    0x1ca44(%rip),%rax        # 24b98 <fwp_heap+0x13f8>
    8154:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8158:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    815c:	48 85 ff             	test   %rdi,%rdi
    815f:	0f 84 cb 00 00 00    	je     8230 <f23+0x3f0>
    8165:	0f b6 02             	movzbl (%rdx),%eax
    8168:	3c 02                	cmp    $0x2,%al
    816a:	0f 84 9a 00 00 00    	je     820a <f23+0x3ca>
    8170:	3c 01                	cmp    $0x1,%al
    8172:	0f 85 b8 00 00 00    	jne    8230 <f23+0x3f0>
    8178:	0f b7 c1             	movzwl %cx,%eax
    817b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    817e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8181:	48 0f af c1          	imul   %rcx,%rax
    8185:	48 c1 e8 20          	shr    $0x20,%rax
    8189:	48 39 d0             	cmp    %rdx,%rax
    818c:	0f 83 9e 00 00 00    	jae    8230 <f23+0x3f0>
    8192:	48 01 c7             	add    %rax,%rdi
    8195:	0f b6 07             	movzbl (%rdi),%eax
    8198:	84 c0                	test   %al,%al
    819a:	0f 84 90 00 00 00    	je     8230 <f23+0x3f0>
    81a0:	31 db                	xor    %ebx,%ebx
    81a2:	0f 1f 00             	nopl   (%rax)
    81a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    81ac:	00 00 00 00 
    81b0:	3c fd                	cmp    $0xfd,%al
    81b2:	0f 87 f1 00 00 00    	ja     82a9 <f23+0x469>
    81b8:	83 c0 01             	add    $0x1,%eax
    81bb:	88 07                	mov    %al,(%rdi)
    81bd:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    81c2:	31 d2                	xor    %edx,%edx
    81c4:	4d 85 e4             	test   %r12,%r12
    81c7:	0f 85 1e fd ff ff    	jne    7eeb <f23+0xab>
    81cd:	e9 3b fd ff ff       	jmp    7f0d <f23+0xcd>
    81d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    81d8:	66 85 c0             	test   %ax,%ax
    81db:	0f 85 06 ff ff ff    	jne    80e7 <f23+0x2a7>
    81e1:	e9 f5 fe ff ff       	jmp    80db <f23+0x29b>
    81e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    81ed:	00 00 00 
    81f0:	66 85 c0             	test   %ax,%ax
    81f3:	0f 85 d2 fd ff ff    	jne    7fcb <f23+0x18b>
    81f9:	e9 bf fd ff ff       	jmp    7fbd <f23+0x17d>
    81fe:	66 90                	xchg   %ax,%ax
    8200:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8205:	e9 e6 fc ff ff       	jmp    7ef0 <f23+0xb0>
    820a:	66 85 c9             	test   %cx,%cx
    820d:	75 21                	jne    8230 <f23+0x3f0>
    820f:	0f b6 07             	movzbl (%rdi),%eax
    8212:	84 c0                	test   %al,%al
    8214:	74 1a                	je     8230 <f23+0x3f0>
    8216:	3c fd                	cmp    $0xfd,%al
    8218:	0f 87 be 00 00 00    	ja     82dc <f23+0x49c>
    821e:	83 c0 01             	add    $0x1,%eax
    8221:	88 07                	mov    %al,(%rdi)
    8223:	66 90                	xchg   %ax,%ax
    8225:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    822c:	00 00 00 00 
    8230:	be 02 00 00 00       	mov    $0x2,%esi
    8235:	bf 08 00 00 00       	mov    $0x8,%edi
    823a:	e8 71 d8 ff ff       	call   5ab0 <fwp_heap_alloc>
    823f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8246:	48 8b 15 2b c9 01 00 	mov    0x1c92b(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    824d:	49 89 c6             	mov    %rax,%r14
    8250:	48 2b 05 f9 c8 01 00 	sub    0x1c8f9(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    8257:	48 c1 e2 10          	shl    $0x10,%rdx
    825b:	48 39 d0             	cmp    %rdx,%rax
    825e:	73 53                	jae    82b3 <f23+0x473>
    8260:	48 89 c2             	mov    %rax,%rdx
    8263:	48 c1 ea 10          	shr    $0x10,%rdx
    8267:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    826b:	48 8b 15 26 c9 01 00 	mov    0x1c926(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    8272:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8276:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    827a:	48 85 ed             	test   %rbp,%rbp
    827d:	74 34                	je     82b3 <f23+0x473>
    827f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8286:	00 00 
    8288:	31 db                	xor    %ebx,%ebx
    828a:	e9 04 fd ff ff       	jmp    7f93 <f23+0x153>
    828f:	48 89 df             	mov    %rbx,%rdi
    8292:	e8 d9 d0 ff ff       	call   5370 <fwp_rc_forget_slot>
    8297:	e9 48 fe ff ff       	jmp    80e4 <f23+0x2a4>
    829c:	48 89 ef             	mov    %rbp,%rdi
    829f:	e8 cc d0 ff ff       	call   5370 <fwp_rc_forget_slot>
    82a4:	e9 1e fd ff ff       	jmp    7fc7 <f23+0x187>
    82a9:	e8 a2 cf ff ff       	call   5250 <fwp_rc_wide_dup>
    82ae:	e9 0a ff ff ff       	jmp    81bd <f23+0x37d>
    82b3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    82ba:	00 00 
    82bc:	e9 6c fd ff ff       	jmp    802d <f23+0x1ed>
    82c1:	e8 8a cf ff ff       	call   5250 <fwp_rc_wide_dup>
    82c6:	e9 1b fc ff ff       	jmp    7ee6 <f23+0xa6>
    82cb:	e8 90 b1 ff ff       	call   3460 <__stack_chk_fail@plt>
    82d0:	48 8d 3d 56 6e 00 00 	lea    0x6e56(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    82d7:	e8 c4 be ff ff       	call   41a0 <fwp_trap>
    82dc:	e8 6f cf ff ff       	call   5250 <fwp_rc_wide_dup>
    82e1:	e9 4a ff ff ff       	jmp    8230 <f23+0x3f0>
    82e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    82ed:	00 00 00 

00000000000082f0 <fwp_owned_entry23>:
    82f0:	f3 0f 1e fa          	endbr64
    82f4:	48 8b 3f             	mov    (%rdi),%rdi
    82f7:	e9 44 fb ff ff       	jmp    7e40 <f23>
    82fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008300 <e23>:
    8300:	f3 0f 1e fa          	endbr64
    8304:	53                   	push   %rbx
    8305:	48 8b 1f             	mov    (%rdi),%rbx
    8308:	48 89 df             	mov    %rbx,%rdi
    830b:	e8 d0 e1 ff ff       	call   64e0 <fwp_rc_share>
    8310:	48 89 df             	mov    %rbx,%rdi
    8313:	e8 28 fb ff ff       	call   7e40 <f23>
    8318:	48 89 c3             	mov    %rax,%rbx
    831b:	48 89 c7             	mov    %rax,%rdi
    831e:	e8 bd e1 ff ff       	call   64e0 <fwp_rc_share>
    8323:	48 89 d8             	mov    %rbx,%rax
    8326:	5b                   	pop    %rbx
    8327:	c3                   	ret
    8328:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    832f:	00 

0000000000008330 <f12>:
    8330:	41 57                	push   %r15
    8332:	41 56                	push   %r14
    8334:	41 55                	push   %r13
    8336:	4c 8d 2d 03 ec ff ff 	lea    -0x13fd(%rip),%r13        # 6f40 <fwp_tape_scope_release>
    833d:	41 54                	push   %r12
    833f:	55                   	push   %rbp
    8340:	53                   	push   %rbx
    8341:	48 81 ec 18 01 00 00 	sub    $0x118,%rsp
    8348:	48 8b 05 e9 d0 01 00 	mov    0x1d0e9(%rip),%rax        # 25438 <fwp_cleanups>
    834f:	48 8b 15 22 c8 01 00 	mov    0x1c822(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    8356:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    835d:	00 00 
    835f:	48 89 ac 24 08 01 00 	mov    %rbp,0x108(%rsp)
    8366:	00 
    8367:	48 89 fd             	mov    %rdi,%rbp
    836a:	4c 8d 7c 24 70       	lea    0x70(%rsp),%r15
    836f:	c7 44 24 6c ff ff ff 	movl   $0xffffffff,0x6c(%rsp)
    8376:	ff 
    8377:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    837c:	48 8d 44 24 6c       	lea    0x6c(%rsp),%rax
    8381:	48 c1 e2 10          	shl    $0x10,%rdx
    8385:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    838a:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    8391:	00 
    8392:	48 8d 05 77 ac 00 00 	lea    0xac77(%rip),%rax        # 13010 <fc23>
    8399:	48 2b 05 b0 c7 01 00 	sub    0x1c7b0(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    83a0:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    83a5:	4c 89 3d 8c d0 01 00 	mov    %r15,0x1d08c(%rip)        # 25438 <fwp_cleanups>
    83ac:	48 39 d0             	cmp    %rdx,%rax
    83af:	73 5d                	jae    840e <f12+0xde>
    83b1:	48 89 c2             	mov    %rax,%rdx
    83b4:	48 c1 ea 10          	shr    $0x10,%rdx
    83b8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    83bc:	48 8b 15 d5 c7 01 00 	mov    0x1c7d5(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    83c3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    83c7:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    83cb:	48 85 ff             	test   %rdi,%rdi
    83ce:	74 3e                	je     840e <f12+0xde>
    83d0:	0f b6 0a             	movzbl (%rdx),%ecx
    83d3:	80 f9 02             	cmp    $0x2,%cl
    83d6:	0f 84 04 0f 00 00    	je     92e0 <f12+0xfb0>
    83dc:	80 f9 01             	cmp    $0x1,%cl
    83df:	75 2d                	jne    840e <f12+0xde>
    83e1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    83e4:	0f b7 c0             	movzwl %ax,%eax
    83e7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    83ea:	48 0f af c1          	imul   %rcx,%rax
    83ee:	48 c1 e8 20          	shr    $0x20,%rax
    83f2:	48 39 d0             	cmp    %rdx,%rax
    83f5:	73 17                	jae    840e <f12+0xde>
    83f7:	48 01 c7             	add    %rax,%rdi
    83fa:	0f b6 07             	movzbl (%rdi),%eax
    83fd:	84 c0                	test   %al,%al
    83ff:	74 0d                	je     840e <f12+0xde>
    8401:	3c fd                	cmp    $0xfd,%al
    8403:	0f 87 fe 10 00 00    	ja     9507 <f12+0x11d7>
    8409:	83 c0 01             	add    $0x1,%eax
    840c:	88 07                	mov    %al,(%rdi)
    840e:	48 8d 3d fb ab 00 00 	lea    0xabfb(%rip),%rdi        # 13010 <fc23>
    8415:	e8 f6 e7 ff ff       	call   6c10 <fwp_closure_drop>
    841a:	48 85 ed             	test   %rbp,%rbp
    841d:	0f 84 3d 10 00 00    	je     9460 <f12+0x1130>
    8423:	48 89 e8             	mov    %rbp,%rax
    8426:	31 d2                	xor    %edx,%edx
    8428:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    842f:	00 
    8430:	48 8b 40 10          	mov    0x10(%rax),%rax
    8434:	48 83 c2 01          	add    $0x1,%rdx
    8438:	48 85 c0             	test   %rax,%rax
    843b:	75 f3                	jne    8430 <f12+0x100>
    843d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    8444:	0f 87 9d 11 00 00    	ja     95e7 <f12+0x12b7>
    844a:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    844f:	8b 35 2b ac 00 00    	mov    0xac2b(%rip),%esi        # 13080 <registered_finish.0>
    8455:	85 f6                	test   %esi,%esi
    8457:	0f 84 53 0e 00 00    	je     92b0 <f12+0xf80>
    845d:	48 8b 1d b4 ac 01 00 	mov    0x1acb4(%rip),%rbx        # 23118 <fwp_tape_next_slot>
    8464:	4c 8b 25 bd ac 01 00 	mov    0x1acbd(%rip),%r12        # 23128 <fwp_ntapes>
    846b:	49 39 dc             	cmp    %rbx,%r12
    846e:	0f 8e dc 00 00 00    	jle    8550 <f12+0x220>
    8474:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    8478:	48 03 05 b1 ac 01 00 	add    0x1acb1(%rip),%rax        # 23130 <fwp_tapes>
    847f:	90                   	nop
    8480:	8b 48 04             	mov    0x4(%rax),%ecx
    8483:	85 c9                	test   %ecx,%ecx
    8485:	75 0c                	jne    8493 <f12+0x163>
    8487:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    848d:	0f 86 bd 00 00 00    	jbe    8550 <f12+0x220>
    8493:	48 83 c3 01          	add    $0x1,%rbx
    8497:	48 83 c0 68          	add    $0x68,%rax
    849b:	49 39 dc             	cmp    %rbx,%r12
    849e:	75 e0                	jne    8480 <f12+0x150>
    84a0:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    84a7:	0f 8f 63 11 00 00    	jg     9610 <f12+0x12e0>
    84ad:	4c 3b 25 6c ac 01 00 	cmp    0x1ac6c(%rip),%r12        # 23120 <fwp_tapes_cap>
    84b4:	4c 8b 35 75 ac 01 00 	mov    0x1ac75(%rip),%r14        # 23130 <fwp_tapes>
    84bb:	75 53                	jne    8510 <f12+0x1e0>
    84bd:	4d 85 e4             	test   %r12,%r12
    84c0:	0f 84 fb 0f 00 00    	je     94c1 <f12+0x1191>
    84c6:	4b 8d 0c 24          	lea    (%r12,%r12,1),%rcx
    84ca:	b8 ff ff 00 00       	mov    $0xffff,%eax
    84cf:	48 39 c1             	cmp    %rax,%rcx
    84d2:	48 0f 4f c8          	cmovg  %rax,%rcx
    84d6:	48 6b f1 68          	imul   $0x68,%rcx,%rsi
    84da:	4c 89 f7             	mov    %r14,%rdi
    84dd:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    84e2:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    84e7:	e8 e4 b0 ff ff       	call   35d0 <realloc@plt>
    84ec:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    84f1:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    84f6:	48 85 c0             	test   %rax,%rax
    84f9:	49 89 c6             	mov    %rax,%r14
    84fc:	0f 84 9f 10 00 00    	je     95a1 <f12+0x1271>
    8502:	48 89 05 27 ac 01 00 	mov    %rax,0x1ac27(%rip)        # 23130 <fwp_tapes>
    8509:	48 89 0d 10 ac 01 00 	mov    %rcx,0x1ac10(%rip)        # 23120 <fwp_tapes_cap>
    8510:	49 6b c4 68          	imul   $0x68,%r12,%rax
    8514:	49 83 c4 01          	add    $0x1,%r12
    8518:	4c 01 f0             	add    %r14,%rax
    851b:	48 8d 78 08          	lea    0x8(%rax),%rdi
    851f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8526:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    852a:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    8531:	00 
    8532:	48 29 f8             	sub    %rdi,%rax
    8535:	8d 48 68             	lea    0x68(%rax),%ecx
    8538:	31 c0                	xor    %eax,%eax
    853a:	c1 e9 03             	shr    $0x3,%ecx
    853d:	f3 48 ab             	rep stos %rax,(%rdi)
    8540:	4c 89 25 e1 ab 01 00 	mov    %r12,0x1abe1(%rip)        # 23128 <fwp_ntapes>
    8547:	eb 17                	jmp    8560 <f12+0x230>
    8549:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8550:	4c 39 e3             	cmp    %r12,%rbx
    8553:	0f 84 47 ff ff ff    	je     84a0 <f12+0x170>
    8559:	4c 8b 35 d0 ab 01 00 	mov    0x1abd0(%rip),%r14        # 23130 <fwp_tapes>
    8560:	4c 6b e3 68          	imul   $0x68,%rbx,%r12
    8564:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    8568:	48 8d 3d 50 6b 00 00 	lea    0x6b50(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    856f:	0f 29 04 24          	movaps %xmm0,(%rsp)
    8573:	4d 01 f4             	add    %r14,%r12
    8576:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    857d:	00 00 
    857f:	e8 1c ae ff ff       	call   33a0 <getenv@plt>
    8584:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    8589:	48 85 c0             	test   %rax,%rax
    858c:	74 09                	je     8597 <f12+0x267>
    858e:	80 38 30             	cmpb   $0x30,(%rax)
    8591:	0f 84 e9 06 00 00    	je     8c80 <f12+0x950>
    8597:	48 83 3d 29 ab 01 00 	cmpq   $0x0,0x1ab29(%rip)        # 230c8 <fwp_tape_cached_bytes>
    859e:	00 
    859f:	0f 85 9b 0d 00 00    	jne    9340 <f12+0x1010>
    85a5:	41 8b 04 24          	mov    (%r12),%eax
    85a9:	48 8d 7b 01          	lea    0x1(%rbx),%rdi
    85ad:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    85b4:	00 00 
    85b6:	48 89 3d 5b ab 01 00 	mov    %rdi,0x1ab5b(%rip)        # 23118 <fwp_tape_next_slot>
    85bd:	8d 70 01             	lea    0x1(%rax),%esi
    85c0:	48 8b 05 71 ce 01 00 	mov    0x1ce71(%rip),%rax        # 25438 <fwp_cleanups>
    85c7:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    85ce:	00 00 
    85d0:	41 89 34 24          	mov    %esi,(%r12)
    85d4:	49 c7 44 24 58 ff ff 	movq   $0xffffffffffffffff,0x58(%r12)
    85db:	ff ff 
    85dd:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    85e3:	48 85 c0             	test   %rax,%rax
    85e6:	75 14                	jne    85fc <f12+0x2cc>
    85e8:	e9 17 10 00 00       	jmp    9604 <f12+0x12d4>
    85ed:	0f 1f 00             	nopl   (%rax)
    85f0:	48 8b 00             	mov    (%rax),%rax
    85f3:	48 85 c0             	test   %rax,%rax
    85f6:	0f 84 08 10 00 00    	je     9604 <f12+0x12d4>
    85fc:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    8600:	75 ee                	jne    85f0 <f12+0x2c0>
    8602:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8606:	41 89 d8             	mov    %ebx,%r8d
    8609:	48 63 01             	movslq (%rcx),%rax
    860c:	49 89 4c 24 50       	mov    %rcx,0x50(%r12)
    8611:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    8616:	85 c0                	test   %eax,%eax
    8618:	78 09                	js     8623 <f12+0x2f3>
    861a:	48 6b c0 68          	imul   $0x68,%rax,%rax
    861e:	41 89 5c 06 58       	mov    %ebx,0x58(%r14,%rax,1)
    8623:	44 89 01             	mov    %r8d,(%rcx)
    8626:	48 89 e8             	mov    %rbp,%rax
    8629:	31 c9                	xor    %ecx,%ecx
    862b:	48 85 ed             	test   %rbp,%rbp
    862e:	0f 84 94 0b 00 00    	je     91c8 <f12+0xe98>
    8634:	90                   	nop
    8635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    863c:	00 00 00 00 
    8640:	48 8b 40 10          	mov    0x10(%rax),%rax
    8644:	48 83 c1 01          	add    $0x1,%rcx
    8648:	48 85 c0             	test   %rax,%rax
    864b:	75 f3                	jne    8640 <f12+0x310>
    864d:	48 89 ea             	mov    %rbp,%rdx
    8650:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8654:	48 83 c0 01          	add    $0x1,%rax
    8658:	48 85 d2             	test   %rdx,%rdx
    865b:	75 f3                	jne    8650 <f12+0x320>
    865d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    8664:	ff ff 1f 
    8667:	48 39 c2             	cmp    %rax,%rdx
    866a:	0f 82 6b 0f 00 00    	jb     95db <f12+0x12ab>
    8670:	48 85 c9             	test   %rcx,%rcx
    8673:	0f 8e 4f 0b 00 00    	jle    91c8 <f12+0xe98>
    8679:	48 39 c1             	cmp    %rax,%rcx
    867c:	48 0f 46 c1          	cmovbe %rcx,%rax
    8680:	49 89 c5             	mov    %rax,%r13
    8683:	48 c1 e8 3c          	shr    $0x3c,%rax
    8687:	0f 85 4e 0f 00 00    	jne    95db <f12+0x12ab>
    868d:	48 c1 e6 10          	shl    $0x10,%rsi
    8691:	4f 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%r14
    8696:	48 09 fe             	or     %rdi,%rsi
    8699:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    86a0:	00 
    86a1:	49 89 f4             	mov    %rsi,%r12
    86a4:	be 02 00 00 00       	mov    $0x2,%esi
    86a9:	e8 02 d4 ff ff       	call   5ab0 <fwp_heap_alloc>
    86ae:	4c 89 30             	mov    %r14,(%rax)
    86b1:	48 8b 15 c0 c4 01 00 	mov    0x1c4c0(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    86b8:	48 89 c3             	mov    %rax,%rbx
    86bb:	48 2b 05 8e c4 01 00 	sub    0x1c48e(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    86c2:	48 c1 e2 10          	shl    $0x10,%rdx
    86c6:	48 39 d0             	cmp    %rdx,%rax
    86c9:	0f 83 79 0b 00 00    	jae    9248 <f12+0xf18>
    86cf:	48 89 c2             	mov    %rax,%rdx
    86d2:	48 c1 ea 10          	shr    $0x10,%rdx
    86d6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    86da:	48 8b 15 b7 c4 01 00 	mov    0x1c4b7(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    86e1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    86e5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    86e9:	48 85 d2             	test   %rdx,%rdx
    86ec:	74 38                	je     8726 <f12+0x3f6>
    86ee:	0f b6 31             	movzbl (%rcx),%esi
    86f1:	40 80 fe 02          	cmp    $0x2,%sil
    86f5:	0f 84 3a 0b 00 00    	je     9235 <f12+0xf05>
    86fb:	40 80 fe 01          	cmp    $0x1,%sil
    86ff:	75 25                	jne    8726 <f12+0x3f6>
    8701:	8b 71 18             	mov    0x18(%rcx),%esi
    8704:	0f b7 c0             	movzwl %ax,%eax
    8707:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    870a:	48 0f af c6          	imul   %rsi,%rax
    870e:	48 c1 e8 20          	shr    $0x20,%rax
    8712:	48 39 c8             	cmp    %rcx,%rax
    8715:	73 0f                	jae    8726 <f12+0x3f6>
    8717:	48 01 c2             	add    %rax,%rdx
    871a:	80 3a ff             	cmpb   $0xff,(%rdx)
    871d:	0f 84 ad 0d 00 00    	je     94d0 <f12+0x11a0>
    8723:	c6 02 01             	movb   $0x1,(%rdx)
    8726:	4d 85 ed             	test   %r13,%r13
    8729:	74 48                	je     8773 <f12+0x443>
    872b:	4c 89 e1             	mov    %r12,%rcx
    872e:	48 89 ea             	mov    %rbp,%rdx
    8731:	31 c0                	xor    %eax,%eax
    8733:	48 c1 e1 20          	shl    $0x20,%rcx
    8737:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    873e:	00 00 
    8740:	48 89 c6             	mov    %rax,%rsi
    8743:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8748:	48 01 ce             	add    %rcx,%rsi
    874b:	0f 80 23 0e 00 00    	jo     9574 <f12+0x1244>
    8751:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    8756:	48 89 c6             	mov    %rax,%rsi
    8759:	48 83 c0 01          	add    $0x1,%rax
    875d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    8761:	48 c1 e6 04          	shl    $0x4,%rsi
    8765:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    876a:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    876e:	4c 39 e8             	cmp    %r13,%rax
    8771:	72 cd                	jb     8740 <f12+0x410>
    8773:	48 8b 03             	mov    (%rbx),%rax
    8776:	48 d1 e8             	shr    $1,%rax
    8779:	0f 84 e1 0a 00 00    	je     9260 <f12+0xf30>
    877f:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    8783:	48 89 d1             	mov    %rdx,%rcx
    8786:	48 c1 e9 3c          	shr    $0x3c,%rcx
    878a:	0f 85 4b 0e 00 00    	jne    95db <f12+0x12ab>
    8790:	48 8d 0c 12          	lea    (%rdx,%rdx,1),%rcx
    8794:	48 89 0c 24          	mov    %rcx,(%rsp)
    8798:	48 85 d2             	test   %rdx,%rdx
    879b:	74 41                	je     87de <f12+0x4ae>
    879d:	48 c1 e0 04          	shl    $0x4,%rax
    87a1:	4c 8d 73 08          	lea    0x8(%rbx),%r14
    87a5:	4c 8d 6c 03 f8       	lea    -0x8(%rbx,%rax,1),%r13
    87aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    87b0:	f2 41 0f 10 06       	movsd  (%r14),%xmm0
    87b5:	49 8b 76 18          	mov    0x18(%r14),%rsi
    87b9:	49 83 c6 10          	add    $0x10,%r14
    87bd:	49 8b 7e f8          	mov    -0x8(%r14),%rdi
    87c1:	f2 41 0f 10 0e       	movsd  (%r14),%xmm1
    87c6:	e8 c5 d9 ff ff       	call   6190 <w107>
    87cb:	66 48 0f 6e e8       	movq   %rax,%xmm5
    87d0:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    87d4:	41 0f 11 46 f0       	movups %xmm0,-0x10(%r14)
    87d9:	4d 39 f5             	cmp    %r14,%r13
    87dc:	75 d2                	jne    87b0 <f12+0x480>
    87de:	48 8b 04 24          	mov    (%rsp),%rax
    87e2:	48 89 df             	mov    %rbx,%rdi
    87e5:	48 89 03             	mov    %rax,(%rbx)
    87e8:	e8 23 db ff ff       	call   6310 <w164.constprop.0>
    87ed:	48 89 df             	mov    %rbx,%rdi
    87f0:	49 63 dc             	movslq %r12d,%rbx
    87f3:	49 89 c5             	mov    %rax,%r13
    87f6:	e8 25 ed ff ff       	call   7520 <fwp_drop4>
    87fb:	48 89 df             	mov    %rbx,%rdi
    87fe:	e8 1d c5 ff ff       	call   4d20 <caf61>
    8803:	48 89 04 24          	mov    %rax,(%rsp)
    8807:	e8 74 bc ff ff       	call   4480 <fwp_tape_of>
    880c:	48 89 c6             	mov    %rax,%rsi
    880f:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    8814:	0f 85 d9 0d 00 00    	jne    95f3 <f12+0x12c3>
    881a:	48 89 c7             	mov    %rax,%rdi
    881d:	e8 de b3 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    8822:	48 8b 56 48          	mov    0x48(%rsi),%rdx
    8826:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    882b:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    8832:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    8836:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
    883a:	66 48 0f 6e fa       	movq   %rdx,%xmm7
    883f:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    8844:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    8849:	48 8b 4e 40          	mov    0x40(%rsi),%rcx
    884d:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    8851:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    8857:	77 19                	ja     8872 <f12+0x542>
    8859:	41 0f b7 c4          	movzwl %r12w,%eax
    885d:	83 e8 01             	sub    $0x1,%eax
    8860:	48 98                	cltq
    8862:	48 3b 05 af a8 01 00 	cmp    0x1a8af(%rip),%rax        # 23118 <fwp_tape_next_slot>
    8869:	7d 07                	jge    8872 <f12+0x542>
    886b:	48 89 05 a6 a8 01 00 	mov    %rax,0x1a8a6(%rip)        # 23118 <fwp_tape_next_slot>
    8872:	48 8b 05 bf cb 01 00 	mov    0x1cbbf(%rip),%rax        # 25438 <fwp_cleanups>
    8879:	66 0f ef c9          	pxor   %xmm1,%xmm1
    887d:	4c 8d a4 24 b0 00 00 	lea    0xb0(%rsp),%r12
    8884:	00 
    8885:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    888c:	00 
    888d:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8891:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    8898:	00 
    8899:	48 8d 05 f0 c5 ff ff 	lea    -0x3a10(%rip),%rax        # 4e90 <fwp_tape_buffers_release>
    88a0:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    88a7:	00 
    88a8:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    88af:	00 
    88b0:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    88b4:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    88b8:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    88bf:	00 
    88c0:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    88c7:	00 
    88c8:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
    88cf:	00 
    88d0:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
    88d7:	00 
    88d8:	48 89 05 59 cb 01 00 	mov    %rax,0x1cb59(%rip)        # 25438 <fwp_cleanups>
    88df:	0f 29 9c 24 b0 00 00 	movaps %xmm3,0xb0(%rsp)
    88e6:	00 
    88e7:	0f 29 94 24 c0 00 00 	movaps %xmm2,0xc0(%rsp)
    88ee:	00 
    88ef:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
    88f6:	00 
    88f7:	4d 85 ed             	test   %r13,%r13
    88fa:	0f 88 f0 09 00 00    	js     92f0 <f12+0xfc0>
    8900:	4c 89 e8             	mov    %r13,%rax
    8903:	48 c1 f8 20          	sar    $0x20,%rax
    8907:	48 39 c3             	cmp    %rax,%rbx
    890a:	0f 85 4c 0c 00 00    	jne    955c <f12+0x122c>
    8910:	45 89 e9             	mov    %r13d,%r9d
    8913:	4c 89 cb             	mov    %r9,%rbx
    8916:	4c 39 cf             	cmp    %r9,%rdi
    8919:	0f 8e 31 0c 00 00    	jle    9550 <f12+0x1220>
    891f:	4d 39 ce             	cmp    %r9,%r14
    8922:	0f 8e 48 09 00 00    	jle    9270 <f12+0xf40>
    8928:	49 39 d6             	cmp    %rdx,%r14
    892b:	0f 8e 87 0a 00 00    	jle    93b8 <f12+0x1088>
    8931:	4d 89 f2             	mov    %r14,%r10
    8934:	48 85 d2             	test   %rdx,%rdx
    8937:	49 0f 44 d2          	cmove  %r10,%rdx
    893b:	eb 18                	jmp    8955 <f12+0x625>
    893d:	0f 1f 00             	nopl   (%rax)
    8940:	48 8d 34 12          	lea    (%rdx,%rdx,1),%rsi
    8944:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
    894b:	4c 89 d0             	mov    %r10,%rax
    894e:	48 0f 4c c6          	cmovl  %rsi,%rax
    8952:	48 89 c2             	mov    %rax,%rdx
    8955:	4c 39 d2             	cmp    %r10,%rdx
    8958:	7c e6                	jl     8940 <f12+0x610>
    895a:	4c 89 54 24 30       	mov    %r10,0x30(%rsp)
    895f:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    8964:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
    8969:	48 85 c9             	test   %rcx,%rcx
    896c:	0f 84 be 0a 00 00    	je     9430 <f12+0x1100>
    8972:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
    8979:	00 
    897a:	48 89 cf             	mov    %rcx,%rdi
    897d:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    8982:	e8 49 ac ff ff       	call   35d0 <realloc@plt>
    8987:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    898c:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
    8991:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
    8997:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    899d:	48 89 c1             	mov    %rax,%rcx
    89a0:	48 85 c9             	test   %rcx,%rcx
    89a3:	0f 84 d8 0b 00 00    	je     9581 <f12+0x1251>
    89a9:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
    89b0:	00 
    89b1:	48 89 94 24 e0 00 00 	mov    %rdx,0xe0(%rsp)
    89b8:	00 
    89b9:	4d 85 d2             	test   %r10,%r10
    89bc:	0f 85 52 0b 00 00    	jne    9514 <f12+0x11e4>
    89c2:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    89c9:	4d 85 ed             	test   %r13,%r13
    89cc:	78 14                	js     89e2 <f12+0x6b2>
    89ce:	45 89 e9             	mov    %r13d,%r9d
    89d1:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    89d6:	f2 42 0f 58 04 c9    	addsd  (%rcx,%r9,8),%xmm0
    89dc:	f2 42 0f 11 04 c9    	movsd  %xmm0,(%rcx,%r9,8)
    89e2:	49 39 de             	cmp    %rbx,%r14
    89e5:	0f 8f 8f 00 00 00    	jg     8a7a <f12+0x74a>
    89eb:	0f 12 fb             	movhlps %xmm3,%xmm7
    89ee:	66 49 0f 7e d2       	movq   %xmm2,%r10
    89f3:	66 48 0f 7e de       	movq   %xmm3,%rsi
    89f8:	4c 29 f3             	sub    %r14,%rbx
    89fb:	66 48 0f 7e ff       	movq   %xmm7,%rdi
    8a00:	0f 12 fa             	movhlps %xmm2,%xmm7
    8a03:	4e 8d 0c f1          	lea    (%rcx,%r14,8),%r9
    8a07:	66 49 0f 7e fb       	movq   %xmm7,%r11
    8a0c:	48 8d 04 9f          	lea    (%rdi,%rbx,4),%rax
    8a10:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8a14:	48 29 fe             	sub    %rdi,%rsi
    8a17:	49 8d 14 db          	lea    (%r11,%rbx,8),%rdx
    8a1b:	4d 29 d9             	sub    %r11,%r9
    8a1e:	4d 29 da             	sub    %r11,%r10
    8a21:	eb 09                	jmp    8a2c <f12+0x6fc>
    8a23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8a28:	48 83 e8 04          	sub    $0x4,%rax
    8a2c:	f2 41 0f 10 04 11    	movsd  (%r9,%rdx,1),%xmm0
    8a32:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    8a36:	7a 02                	jp     8a3a <f12+0x70a>
    8a38:	74 37                	je     8a71 <f12+0x741>
    8a3a:	4c 63 1c 06          	movslq (%rsi,%rax,1),%r11
    8a3e:	45 85 db             	test   %r11d,%r11d
    8a41:	78 16                	js     8a59 <f12+0x729>
    8a43:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    8a49:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    8a4d:	f2 42 0f 58 0c d9    	addsd  (%rcx,%r11,8),%xmm1
    8a53:	f2 42 0f 11 0c d9    	movsd  %xmm1,(%rcx,%r11,8)
    8a59:	4c 63 18             	movslq (%rax),%r11
    8a5c:	45 85 db             	test   %r11d,%r11d
    8a5f:	78 10                	js     8a71 <f12+0x741>
    8a61:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    8a65:	f2 42 0f 58 04 d9    	addsd  (%rcx,%r11,8),%xmm0
    8a6b:	f2 42 0f 11 04 d9    	movsd  %xmm0,(%rcx,%r11,8)
    8a71:	48 83 ea 08          	sub    $0x8,%rdx
    8a75:	48 39 c7             	cmp    %rax,%rdi
    8a78:	75 ae                	jne    8a28 <f12+0x6f8>
    8a7a:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8a81:	ff ff 1f 
    8a84:	4c 39 f0             	cmp    %r14,%rax
    8a87:	0f 82 42 0b 00 00    	jb     95cf <f12+0x129f>
    8a8d:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8a94:	00 
    8a95:	be 02 00 00 00       	mov    $0x2,%esi
    8a9a:	48 89 0c 24          	mov    %rcx,(%rsp)
    8a9e:	e8 0d d0 ff ff       	call   5ab0 <fwp_heap_alloc>
    8aa3:	48 8b 0c 24          	mov    (%rsp),%rcx
    8aa7:	4c 89 30             	mov    %r14,(%rax)
    8aaa:	49 89 c5             	mov    %rax,%r13
    8aad:	31 c0                	xor    %eax,%eax
    8aaf:	4d 85 f6             	test   %r14,%r14
    8ab2:	74 1e                	je     8ad2 <f12+0x7a2>
    8ab4:	90                   	nop
    8ab5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8abc:	00 00 00 00 
    8ac0:	48 8b 14 c1          	mov    (%rcx,%rax,8),%rdx
    8ac4:	49 89 54 c5 08       	mov    %rdx,0x8(%r13,%rax,8)
    8ac9:	48 83 c0 01          	add    $0x1,%rax
    8acd:	49 39 c6             	cmp    %rax,%r14
    8ad0:	75 ee                	jne    8ac0 <f12+0x790>
    8ad2:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
    8ad9:	00 
    8ada:	4c 89 e7             	mov    %r12,%rdi
    8add:	48 89 0d 54 c9 01 00 	mov    %rcx,0x1c954(%rip)        # 25438 <fwp_cleanups>
    8ae4:	48 89 0c 24          	mov    %rcx,(%rsp)
    8ae8:	e8 a3 c3 ff ff       	call   4e90 <fwp_tape_buffers_release>
    8aed:	48 8b 15 84 c0 01 00 	mov    0x1c084(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    8af4:	4c 89 e8             	mov    %r13,%rax
    8af7:	48 8b 0c 24          	mov    (%rsp),%rcx
    8afb:	48 2b 05 4e c0 01 00 	sub    0x1c04e(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    8b02:	48 c1 e2 10          	shl    $0x10,%rdx
    8b06:	48 39 d0             	cmp    %rdx,%rax
    8b09:	73 57                	jae    8b62 <f12+0x832>
    8b0b:	48 89 c2             	mov    %rax,%rdx
    8b0e:	48 c1 ea 10          	shr    $0x10,%rdx
    8b12:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8b16:	48 8b 15 7b c0 01 00 	mov    0x1c07b(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    8b1d:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    8b21:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    8b25:	48 85 db             	test   %rbx,%rbx
    8b28:	74 38                	je     8b62 <f12+0x832>
    8b2a:	0f b6 32             	movzbl (%rdx),%esi
    8b2d:	40 80 fe 02          	cmp    $0x2,%sil
    8b31:	0f 84 e9 07 00 00    	je     9320 <f12+0xff0>
    8b37:	40 80 fe 01          	cmp    $0x1,%sil
    8b3b:	75 25                	jne    8b62 <f12+0x832>
    8b3d:	8b 72 18             	mov    0x18(%rdx),%esi
    8b40:	0f b7 c0             	movzwl %ax,%eax
    8b43:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8b46:	48 0f af c6          	imul   %rsi,%rax
    8b4a:	48 c1 e8 20          	shr    $0x20,%rax
    8b4e:	48 39 d0             	cmp    %rdx,%rax
    8b51:	73 0f                	jae    8b62 <f12+0x832>
    8b53:	48 01 c3             	add    %rax,%rbx
    8b56:	80 3b ff             	cmpb   $0xff,(%rbx)
    8b59:	0f 84 86 09 00 00    	je     94e5 <f12+0x11b5>
    8b5f:	c6 03 01             	movb   $0x1,(%rbx)
    8b62:	4c 39 f9             	cmp    %r15,%rcx
    8b65:	0f 85 e0 ab ff ff    	jne    374b <f12.cold>
    8b6b:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    8b70:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    8b75:	48 89 05 bc c8 01 00 	mov    %rax,0x1c8bc(%rip)        # 25438 <fwp_cleanups>
    8b7c:	e8 bf e3 ff ff       	call   6f40 <fwp_tape_scope_release>
    8b81:	49 8b 45 00          	mov    0x0(%r13),%rax
    8b85:	49 89 c4             	mov    %rax,%r12
    8b88:	49 0f ba f4 3f       	btr    $0x3f,%r12
    8b8d:	48 85 c0             	test   %rax,%rax
    8b90:	0f 88 6a 05 00 00    	js     9100 <f12+0xdd0>
    8b96:	48 8b 15 db bf 01 00 	mov    0x1bfdb(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    8b9d:	4c 89 e8             	mov    %r13,%rax
    8ba0:	48 2b 05 a9 bf 01 00 	sub    0x1bfa9(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    8ba7:	48 c1 e2 10          	shl    $0x10,%rdx
    8bab:	48 39 d0             	cmp    %rdx,%rax
    8bae:	0f 83 4c 05 00 00    	jae    9100 <f12+0xdd0>
    8bb4:	48 89 c2             	mov    %rax,%rdx
    8bb7:	48 c1 ea 10          	shr    $0x10,%rdx
    8bbb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8bbf:	48 8b 15 d2 bf 01 00 	mov    0x1bfd2(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    8bc6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8bca:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    8bce:	48 85 c9             	test   %rcx,%rcx
    8bd1:	0f 84 29 05 00 00    	je     9100 <f12+0xdd0>
    8bd7:	0f b6 32             	movzbl (%rdx),%esi
    8bda:	40 80 fe 02          	cmp    $0x2,%sil
    8bde:	0f 84 0c 05 00 00    	je     90f0 <f12+0xdc0>
    8be4:	40 80 fe 01          	cmp    $0x1,%sil
    8be8:	0f 85 12 05 00 00    	jne    9100 <f12+0xdd0>
    8bee:	8b 72 18             	mov    0x18(%rdx),%esi
    8bf1:	0f b7 c0             	movzwl %ax,%eax
    8bf4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8bf7:	48 0f af c6          	imul   %rsi,%rax
    8bfb:	48 c1 e8 20          	shr    $0x20,%rax
    8bff:	48 39 d0             	cmp    %rdx,%rax
    8c02:	0f 83 f8 04 00 00    	jae    9100 <f12+0xdd0>
    8c08:	48 01 c1             	add    %rax,%rcx
    8c0b:	80 39 01             	cmpb   $0x1,(%rcx)
    8c0e:	0f 85 ec 04 00 00    	jne    9100 <f12+0xdd0>
    8c14:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    8c19:	4d 89 ef             	mov    %r13,%r15
    8c1c:	31 ff                	xor    %edi,%edi
    8c1e:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    8c23:	f2 0f 10 0d 25 6f 00 	movsd  0x6f25(%rip),%xmm1        # fb50 <msg.8+0xd0>
    8c2a:	00 
    8c2b:	48 8d 50 08          	lea    0x8(%rax),%rdx
    8c2f:	31 c0                	xor    %eax,%eax
    8c31:	4d 85 e4             	test   %r12,%r12
    8c34:	75 2f                	jne    8c65 <f12+0x935>
    8c36:	eb 58                	jmp    8c90 <f12+0x960>
    8c38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8c3f:	00 
    8c40:	49 83 3f 00          	cmpq   $0x0,(%r15)
    8c44:	0f 88 1e 09 00 00    	js     9568 <f12+0x1238>
    8c4a:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    8c4f:	48 83 c0 01          	add    $0x1,%rax
    8c53:	48 83 c2 08          	add    $0x8,%rdx
    8c57:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    8c5b:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8c60:	49 39 c4             	cmp    %rax,%r12
    8c63:	74 2b                	je     8c90 <f12+0x960>
    8c65:	49 8d 4d 08          	lea    0x8(%r13),%rcx
    8c69:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    8c6e:	79 d0                	jns    8c40 <f12+0x910>
    8c70:	49 8b 4d 10          	mov    0x10(%r13),%rcx
    8c74:	eb ca                	jmp    8c40 <f12+0x910>
    8c76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8c7d:	00 00 00 
    8c80:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    8c84:	0f 84 1b f9 ff ff    	je     85a5 <f12+0x275>
    8c8a:	e9 08 f9 ff ff       	jmp    8597 <f12+0x267>
    8c8f:	90                   	nop
    8c90:	e8 8b e8 ff ff       	call   7520 <fwp_drop4>
    8c95:	48 89 e8             	mov    %rbp,%rax
    8c98:	31 d2                	xor    %edx,%edx
    8c9a:	48 85 ed             	test   %rbp,%rbp
    8c9d:	0f 84 c6 07 00 00    	je     9469 <f12+0x1139>
    8ca3:	66 90                	xchg   %ax,%ax
    8ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8cac:	00 00 00 00 
    8cb0:	48 8b 40 10          	mov    0x10(%rax),%rax
    8cb4:	48 83 c2 01          	add    $0x1,%rdx
    8cb8:	48 85 c0             	test   %rax,%rax
    8cbb:	75 f3                	jne    8cb0 <f12+0x980>
    8cbd:	49 8b 07             	mov    (%r15),%rax
    8cc0:	49 89 c5             	mov    %rax,%r13
    8cc3:	49 0f ba f5 3f       	btr    $0x3f,%r13
    8cc8:	48 85 c0             	test   %rax,%rax
    8ccb:	0f 88 81 03 00 00    	js     9052 <f12+0xd22>
    8cd1:	48 8b 05 a0 be 01 00 	mov    0x1bea0(%rip),%rax        # 24b78 <fwp_heap+0x13d8>
    8cd8:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    8cdd:	48 2b 0d 6c be 01 00 	sub    0x1be6c(%rip),%rcx        # 24b50 <fwp_heap+0x13b0>
    8ce4:	48 c1 e0 10          	shl    $0x10,%rax
    8ce8:	48 39 c1             	cmp    %rax,%rcx
    8ceb:	0f 83 61 03 00 00    	jae    9052 <f12+0xd22>
    8cf1:	48 89 c8             	mov    %rcx,%rax
    8cf4:	48 c1 e8 10          	shr    $0x10,%rax
    8cf8:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    8cfc:	48 8b 05 95 be 01 00 	mov    0x1be95(%rip),%rax        # 24b98 <fwp_heap+0x13f8>
    8d03:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    8d07:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8d0b:	48 85 ff             	test   %rdi,%rdi
    8d0e:	0f 84 3e 03 00 00    	je     9052 <f12+0xd22>
    8d14:	0f b6 06             	movzbl (%rsi),%eax
    8d17:	3c 02                	cmp    $0x2,%al
    8d19:	0f 84 21 03 00 00    	je     9040 <f12+0xd10>
    8d1f:	3c 01                	cmp    $0x1,%al
    8d21:	0f 85 22 03 00 00    	jne    9049 <f12+0xd19>
    8d27:	8b 46 18             	mov    0x18(%rsi),%eax
    8d2a:	0f b7 c9             	movzwl %cx,%ecx
    8d2d:	48 0f af c8          	imul   %rax,%rcx
    8d31:	8b 46 1c             	mov    0x1c(%rsi),%eax
    8d34:	48 c1 e9 20          	shr    $0x20,%rcx
    8d38:	48 39 c1             	cmp    %rax,%rcx
    8d3b:	0f 83 08 03 00 00    	jae    9049 <f12+0xd19>
    8d41:	48 01 cf             	add    %rcx,%rdi
    8d44:	80 3f 01             	cmpb   $0x1,(%rdi)
    8d47:	0f 85 fc 02 00 00    	jne    9049 <f12+0xd19>
    8d4d:	49 39 d5             	cmp    %rdx,%r13
    8d50:	48 89 d0             	mov    %rdx,%rax
    8d53:	49 0f 46 c5          	cmovbe %r13,%rax
    8d57:	48 85 c0             	test   %rax,%rax
    8d5a:	0f 84 19 08 00 00    	je     9579 <f12+0x1249>
    8d60:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
    8d67:	00 
    8d68:	4d 8d 77 08          	lea    0x8(%r15),%r14
    8d6c:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    8d71:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    8d78:	00 
    8d79:	48 89 e9             	mov    %rbp,%rcx
    8d7c:	31 d2                	xor    %edx,%edx
    8d7e:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    8d82:	eb 59                	jmp    8ddd <f12+0xaad>
    8d84:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8d89:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d90:	00 00 00 00 
    8d94:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d9b:	00 00 00 00 
    8d9f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8da6:	00 00 00 00 
    8daa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8db1:	00 00 00 00 
    8db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8dbc:	00 00 00 00 
    8dc0:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    8dc5:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    8dca:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    8dd0:	48 83 c2 08          	add    $0x8,%rdx
    8dd4:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    8dd8:	49 39 d0             	cmp    %rdx,%r8
    8ddb:	74 1b                	je     8df8 <f12+0xac8>
    8ddd:	48 89 fe             	mov    %rdi,%rsi
    8de0:	49 83 3f 00          	cmpq   $0x0,(%r15)
    8de4:	79 da                	jns    8dc0 <f12+0xa90>
    8de6:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    8deb:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    8def:	eb cf                	jmp    8dc0 <f12+0xa90>
    8df1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8df8:	48 85 ed             	test   %rbp,%rbp
    8dfb:	0f 84 47 07 00 00    	je     9548 <f12+0x1218>
    8e01:	4c 8b 05 70 bd 01 00 	mov    0x1bd70(%rip),%r8        # 24b78 <fwp_heap+0x13d8>
    8e08:	4c 8b 0d 41 bd 01 00 	mov    0x1bd41(%rip),%r9        # 24b50 <fwp_heap+0x13b0>
    8e0f:	48 89 e9             	mov    %rbp,%rcx
    8e12:	45 31 ed             	xor    %r13d,%r13d
    8e15:	4c 8b 15 7c bd 01 00 	mov    0x1bd7c(%rip),%r10        # 24b98 <fwp_heap+0x13f8>
    8e1c:	49 c1 e0 10          	shl    $0x10,%r8
    8e20:	eb 1c                	jmp    8e3e <f12+0xb0e>
    8e22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8e28:	49 83 c5 01          	add    $0x1,%r13
    8e2c:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    8e30:	49 39 c5             	cmp    %rax,%r13
    8e33:	0f 83 67 01 00 00    	jae    8fa0 <f12+0xc70>
    8e39:	48 85 c9             	test   %rcx,%rcx
    8e3c:	74 56                	je     8e94 <f12+0xb64>
    8e3e:	48 89 ca             	mov    %rcx,%rdx
    8e41:	4c 29 ca             	sub    %r9,%rdx
    8e44:	4c 39 c2             	cmp    %r8,%rdx
    8e47:	73 4b                	jae    8e94 <f12+0xb64>
    8e49:	48 89 d6             	mov    %rdx,%rsi
    8e4c:	48 c1 ee 10          	shr    $0x10,%rsi
    8e50:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    8e54:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    8e58:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8e5c:	48 85 ff             	test   %rdi,%rdi
    8e5f:	74 33                	je     8e94 <f12+0xb64>
    8e61:	44 0f b6 1e          	movzbl (%rsi),%r11d
    8e65:	41 80 fb 02          	cmp    $0x2,%r11b
    8e69:	0f 84 19 01 00 00    	je     8f88 <f12+0xc58>
    8e6f:	41 80 fb 01          	cmp    $0x1,%r11b
    8e73:	75 1f                	jne    8e94 <f12+0xb64>
    8e75:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    8e79:	0f b7 d2             	movzwl %dx,%edx
    8e7c:	8b 76 1c             	mov    0x1c(%rsi),%esi
    8e7f:	49 0f af d3          	imul   %r11,%rdx
    8e83:	48 c1 ea 20          	shr    $0x20,%rdx
    8e87:	48 39 f2             	cmp    %rsi,%rdx
    8e8a:	73 08                	jae    8e94 <f12+0xb64>
    8e8c:	48 01 d7             	add    %rdx,%rdi
    8e8f:	80 3f 01             	cmpb   $0x1,(%rdi)
    8e92:	74 94                	je     8e28 <f12+0xaf8>
    8e94:	49 39 c5             	cmp    %rax,%r13
    8e97:	0f 83 03 01 00 00    	jae    8fa0 <f12+0xc70>
    8e9d:	49 89 c7             	mov    %rax,%r15
    8ea0:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
    8ea7:	00 
    8ea8:	45 31 e4             	xor    %r12d,%r12d
    8eab:	48 89 04 24          	mov    %rax,(%rsp)
    8eaf:	48 8d 1d ea a8 01 00 	lea    0x1a8ea(%rip),%rbx        # 237a0 <fwp_heap>
    8eb6:	eb 3a                	jmp    8ef2 <f12+0xbc2>
    8eb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8ebf:	00 
    8ec0:	41 80 f9 01          	cmp    $0x1,%r9b
    8ec4:	75 27                	jne    8eed <f12+0xbbd>
    8ec6:	45 8b 48 18          	mov    0x18(%r8),%r9d
    8eca:	0f b7 c0             	movzwl %ax,%eax
    8ecd:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    8ed1:	49 0f af c1          	imul   %r9,%rax
    8ed5:	48 c1 e8 20          	shr    $0x20,%rax
    8ed9:	4c 39 c0             	cmp    %r8,%rax
    8edc:	73 0f                	jae    8eed <f12+0xbbd>
    8ede:	48 01 c7             	add    %rax,%rdi
    8ee1:	80 3f ff             	cmpb   $0xff,(%rdi)
    8ee4:	0f 84 c6 02 00 00    	je     91b0 <f12+0xe80>
    8eea:	c6 07 01             	movb   $0x1,(%rdi)
    8eed:	4d 39 fd             	cmp    %r15,%r13
    8ef0:	73 7e                	jae    8f70 <f12+0xc40>
    8ef2:	49 83 ef 01          	sub    $0x1,%r15
    8ef6:	66 49 0f 6e f4       	movq   %r12,%xmm6
    8efb:	48 8b 34 24          	mov    (%rsp),%rsi
    8eff:	bf 01 00 00 00       	mov    $0x1,%edi
    8f04:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    8f0a:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    8f0e:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
    8f15:	00 
    8f16:	e8 95 d4 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    8f1b:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    8f22:	49 89 c4             	mov    %rax,%r12
    8f25:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    8f2c:	48 c1 e7 10          	shl    $0x10,%rdi
    8f30:	48 39 f8             	cmp    %rdi,%rax
    8f33:	73 b8                	jae    8eed <f12+0xbbd>
    8f35:	48 89 c7             	mov    %rax,%rdi
    8f38:	48 c1 ef 10          	shr    $0x10,%rdi
    8f3c:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    8f40:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    8f47:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    8f4b:	49 8b 78 20          	mov    0x20(%r8),%rdi
    8f4f:	48 85 ff             	test   %rdi,%rdi
    8f52:	74 99                	je     8eed <f12+0xbbd>
    8f54:	45 0f b6 08          	movzbl (%r8),%r9d
    8f58:	41 80 f9 02          	cmp    $0x2,%r9b
    8f5c:	0f 85 5e ff ff ff    	jne    8ec0 <f12+0xb90>
    8f62:	66 85 c0             	test   %ax,%ax
    8f65:	0f 84 76 ff ff ff    	je     8ee1 <f12+0xbb1>
    8f6b:	4d 39 fd             	cmp    %r15,%r13
    8f6e:	72 82                	jb     8ef2 <f12+0xbc2>
    8f70:	4d 85 ed             	test   %r13,%r13
    8f73:	75 2e                	jne    8fa3 <f12+0xc73>
    8f75:	8b 44 24 20          	mov    0x20(%rsp),%eax
    8f79:	85 c0                	test   %eax,%eax
    8f7b:	4d 0f 45 f5          	cmovne %r13,%r14
    8f7f:	eb 6f                	jmp    8ff0 <f12+0xcc0>
    8f81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8f88:	66 85 d2             	test   %dx,%dx
    8f8b:	0f 84 fe fe ff ff    	je     8e8f <f12+0xb5f>
    8f91:	49 39 c5             	cmp    %rax,%r13
    8f94:	0f 82 03 ff ff ff    	jb     8e9d <f12+0xb6d>
    8f9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8fa0:	45 31 e4             	xor    %r12d,%r12d
    8fa3:	4c 89 f2             	mov    %r14,%rdx
    8fa6:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    8faa:	48 89 e8             	mov    %rbp,%rax
    8fad:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8fb4:	00 
    8fb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8fbc:	00 00 00 00 
    8fc0:	48 8b 0a             	mov    (%rdx),%rcx
    8fc3:	48 83 c2 08          	add    $0x8,%rdx
    8fc7:	48 89 c7             	mov    %rax,%rdi
    8fca:	48 89 48 08          	mov    %rcx,0x8(%rax)
    8fce:	48 8b 40 10          	mov    0x10(%rax),%rax
    8fd2:	4c 39 c2             	cmp    %r8,%rdx
    8fd5:	75 e9                	jne    8fc0 <f12+0xc90>
    8fd7:	8b 54 24 20          	mov    0x20(%rsp),%edx
    8fdb:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    8fdf:	85 d2                	test   %edx,%edx
    8fe1:	0f 84 49 03 00 00    	je     9330 <f12+0x1000>
    8fe7:	49 89 ec             	mov    %rbp,%r12
    8fea:	45 31 f6             	xor    %r14d,%r14d
    8fed:	48 89 c5             	mov    %rax,%rbp
    8ff0:	4c 89 f7             	mov    %r14,%rdi
    8ff3:	e8 b8 c5 ff ff       	call   55b0 <fwp_mem_free>
    8ff8:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    8ffd:	e8 1e e5 ff ff       	call   7520 <fwp_drop4>
    9002:	48 89 ef             	mov    %rbp,%rdi
    9005:	e8 16 d9 ff ff       	call   6920 <fwp_drop0>
    900a:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    9011:	00 
    9012:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9019:	00 00 
    901b:	0f 85 de 05 00 00    	jne    95ff <f12+0x12cf>
    9021:	48 81 c4 18 01 00 00 	add    $0x118,%rsp
    9028:	4c 89 e0             	mov    %r12,%rax
    902b:	5b                   	pop    %rbx
    902c:	5d                   	pop    %rbp
    902d:	41 5c                	pop    %r12
    902f:	41 5d                	pop    %r13
    9031:	41 5e                	pop    %r14
    9033:	41 5f                	pop    %r15
    9035:	c3                   	ret
    9036:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    903d:	00 00 00 
    9040:	66 85 c9             	test   %cx,%cx
    9043:	0f 84 fb fc ff ff    	je     8d44 <f12+0xa14>
    9049:	48 85 ed             	test   %rbp,%rbp
    904c:	0f 84 ad 03 00 00    	je     93ff <f12+0x10cf>
    9052:	48 89 e8             	mov    %rbp,%rax
    9055:	45 31 e4             	xor    %r12d,%r12d
    9058:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    905f:	00 
    9060:	48 8b 40 10          	mov    0x10(%rax),%rax
    9064:	4c 89 e2             	mov    %r12,%rdx
    9067:	49 83 c4 01          	add    $0x1,%r12
    906b:	48 85 c0             	test   %rax,%rax
    906e:	75 f0                	jne    9060 <f12+0xd30>
    9070:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9077:	ff ff 1f 
    907a:	4c 39 e0             	cmp    %r12,%rax
    907d:	0f 82 58 05 00 00    	jb     95db <f12+0x12ab>
    9083:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    908a:	00 
    908b:	be 02 00 00 00       	mov    $0x2,%esi
    9090:	e8 1b ca ff ff       	call   5ab0 <fwp_heap_alloc>
    9095:	4d 39 e5             	cmp    %r12,%r13
    9098:	48 89 ea             	mov    %rbp,%rdx
    909b:	49 89 c6             	mov    %rax,%r14
    909e:	4c 89 e0             	mov    %r12,%rax
    90a1:	49 0f 46 c5          	cmovbe %r13,%rax
    90a5:	4c 89 f1             	mov    %r14,%rcx
    90a8:	66 90                	xchg   %ax,%ax
    90aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    90b1:	00 00 00 00 
    90b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    90bc:	00 00 00 00 
    90c0:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    90c4:	48 83 c1 08          	add    $0x8,%rcx
    90c8:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    90cc:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    90d0:	48 85 d2             	test   %rdx,%rdx
    90d3:	75 eb                	jne    90c0 <f12+0xd90>
    90d5:	48 85 c0             	test   %rax,%rax
    90d8:	0f 84 33 03 00 00    	je     9411 <f12+0x10e1>
    90de:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
    90e5:	00 
    90e6:	e9 81 fc ff ff       	jmp    8d6c <f12+0xa3c>
    90eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    90f0:	66 85 c0             	test   %ax,%ax
    90f3:	0f 84 12 fb ff ff    	je     8c0b <f12+0x8db>
    90f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9100:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9107:	ff ff 1f 
    910a:	4c 39 e0             	cmp    %r12,%rax
    910d:	0f 82 bc 04 00 00    	jb     95cf <f12+0x129f>
    9113:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    911a:	00 
    911b:	be 01 00 00 00       	mov    $0x1,%esi
    9120:	e8 8b c9 ff ff       	call   5ab0 <fwp_heap_alloc>
    9125:	4c 89 20             	mov    %r12,(%rax)
    9128:	48 8b 15 49 ba 01 00 	mov    0x1ba49(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    912f:	49 89 c7             	mov    %rax,%r15
    9132:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9137:	48 2b 05 12 ba 01 00 	sub    0x1ba12(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    913e:	48 c1 e2 10          	shl    $0x10,%rdx
    9142:	48 39 d0             	cmp    %rdx,%rax
    9145:	73 57                	jae    919e <f12+0xe6e>
    9147:	48 89 c2             	mov    %rax,%rdx
    914a:	48 c1 ea 10          	shr    $0x10,%rdx
    914e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9152:	48 8b 15 3f ba 01 00 	mov    0x1ba3f(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    9159:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    915d:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    9161:	4d 85 f6             	test   %r14,%r14
    9164:	74 38                	je     919e <f12+0xe6e>
    9166:	0f b6 0a             	movzbl (%rdx),%ecx
    9169:	80 f9 02             	cmp    $0x2,%cl
    916c:	0f 84 ae 02 00 00    	je     9420 <f12+0x10f0>
    9172:	80 f9 01             	cmp    $0x1,%cl
    9175:	75 27                	jne    919e <f12+0xe6e>
    9177:	8b 4a 18             	mov    0x18(%rdx),%ecx
    917a:	0f b7 c0             	movzwl %ax,%eax
    917d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9180:	48 0f af c1          	imul   %rcx,%rax
    9184:	48 c1 e8 20          	shr    $0x20,%rax
    9188:	48 39 d0             	cmp    %rdx,%rax
    918b:	73 11                	jae    919e <f12+0xe6e>
    918d:	49 01 c6             	add    %rax,%r14
    9190:	41 80 3e ff          	cmpb   $0xff,(%r14)
    9194:	0f 84 60 03 00 00    	je     94fa <f12+0x11ca>
    919a:	41 c6 06 01          	movb   $0x1,(%r14)
    919e:	4c 89 ef             	mov    %r13,%rdi
    91a1:	e9 78 fa ff ff       	jmp    8c1e <f12+0x8ee>
    91a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    91ad:	00 00 00 
    91b0:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    91b5:	e8 b6 c1 ff ff       	call   5370 <fwp_rc_forget_slot>
    91ba:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    91bf:	e9 26 fd ff ff       	jmp    8eea <f12+0xbba>
    91c4:	0f 1f 40 00          	nopl   0x0(%rax)
    91c8:	48 c1 e6 10          	shl    $0x10,%rsi
    91cc:	48 09 fe             	or     %rdi,%rsi
    91cf:	bf 08 00 00 00       	mov    $0x8,%edi
    91d4:	49 89 f4             	mov    %rsi,%r12
    91d7:	be 02 00 00 00       	mov    $0x2,%esi
    91dc:	e8 cf c8 ff ff       	call   5ab0 <fwp_heap_alloc>
    91e1:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    91e8:	48 8b 15 89 b9 01 00 	mov    0x1b989(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    91ef:	48 89 c3             	mov    %rax,%rbx
    91f2:	48 2b 05 57 b9 01 00 	sub    0x1b957(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    91f9:	48 c1 e2 10          	shl    $0x10,%rdx
    91fd:	48 39 d0             	cmp    %rdx,%rax
    9200:	73 5e                	jae    9260 <f12+0xf30>
    9202:	48 89 c2             	mov    %rax,%rdx
    9205:	48 c1 ea 10          	shr    $0x10,%rdx
    9209:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    920d:	48 8b 15 84 b9 01 00 	mov    0x1b984(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    9214:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    9218:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    921c:	48 85 d2             	test   %rdx,%rdx
    921f:	0f 84 4e f5 ff ff    	je     8773 <f12+0x443>
    9225:	0f b6 31             	movzbl (%rcx),%esi
    9228:	45 31 ed             	xor    %r13d,%r13d
    922b:	40 80 fe 02          	cmp    $0x2,%sil
    922f:	0f 85 c6 f4 ff ff    	jne    86fb <f12+0x3cb>
    9235:	66 85 c0             	test   %ax,%ax
    9238:	0f 85 e8 f4 ff ff    	jne    8726 <f12+0x3f6>
    923e:	e9 d7 f4 ff ff       	jmp    871a <f12+0x3ea>
    9243:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9248:	4d 85 ed             	test   %r13,%r13
    924b:	0f 85 da f4 ff ff    	jne    872b <f12+0x3fb>
    9251:	0f 1f 40 00          	nopl   0x0(%rax)
    9255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    925c:	00 00 00 00 
    9260:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    9267:	00 
    9268:	e9 71 f5 ff ff       	jmp    87de <f12+0x4ae>
    926d:	0f 1f 00             	nopl   (%rax)
    9270:	4d 8d 51 01          	lea    0x1(%r9),%r10
    9274:	4c 39 d2             	cmp    %r10,%rdx
    9277:	0f 8c b7 f6 ff ff    	jl     8934 <f12+0x604>
    927d:	48 85 c9             	test   %rcx,%rcx
    9280:	0f 84 04 03 00 00    	je     958a <f12+0x125a>
    9286:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
    928b:	4a 8d 14 d5 00 00 00 	lea    0x0(,%r10,8),%rdx
    9292:	00 
    9293:	31 f6                	xor    %esi,%esi
    9295:	48 89 cf             	mov    %rcx,%rdi
    9298:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    929d:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    92a2:	e9 3a 01 00 00       	jmp    93e1 <f12+0x10b1>
    92a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    92ae:	00 00 
    92b0:	48 8d 3d a9 db ff ff 	lea    -0x2457(%rip),%rdi        # 6e60 <fwp_tape_finish>
    92b7:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    92bc:	e8 4f 56 00 00       	call   e910 <atexit>
    92c1:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    92c6:	85 c0                	test   %eax,%eax
    92c8:	0f 85 d3 02 00 00    	jne    95a1 <f12+0x1271>
    92ce:	c7 05 a8 9d 00 00 01 	movl   $0x1,0x9da8(%rip)        # 13080 <registered_finish.0>
    92d5:	00 00 00 
    92d8:	e9 80 f1 ff ff       	jmp    845d <f12+0x12d>
    92dd:	0f 1f 00             	nopl   (%rax)
    92e0:	66 85 c0             	test   %ax,%ax
    92e3:	0f 85 25 f1 ff ff    	jne    840e <f12+0xde>
    92e9:	e9 0c f1 ff ff       	jmp    83fa <f12+0xca>
    92ee:	66 90                	xchg   %ax,%ax
    92f0:	49 39 d6             	cmp    %rdx,%r14
    92f3:	0f 8f 38 f6 ff ff    	jg     8931 <f12+0x601>
    92f9:	4d 85 f6             	test   %r14,%r14
    92fc:	74 12                	je     9310 <f12+0xfe0>
    92fe:	48 85 c9             	test   %rcx,%rcx
    9301:	0f 84 83 02 00 00    	je     958a <f12+0x125a>
    9307:	4d 85 f6             	test   %r14,%r14
    930a:	0f 85 01 02 00 00    	jne    9511 <f12+0x11e1>
    9310:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    9317:	e9 c6 f6 ff ff       	jmp    89e2 <f12+0x6b2>
    931c:	0f 1f 40 00          	nopl   0x0(%rax)
    9320:	66 85 c0             	test   %ax,%ax
    9323:	0f 85 39 f8 ff ff    	jne    8b62 <f12+0x832>
    9329:	e9 28 f8 ff ff       	jmp    8b56 <f12+0x826>
    932e:	66 90                	xchg   %ax,%ax
    9330:	49 89 ec             	mov    %rbp,%r12
    9333:	48 89 c5             	mov    %rax,%rbp
    9336:	e9 b5 fc ff ff       	jmp    8ff0 <f12+0xcc0>
    933b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9340:	66 0f 6f 0d 98 9d 01 	movdqa 0x19d98(%rip),%xmm1        # 230e0 <fwp_tape_workspace>
    9347:	00 
    9348:	48 c7 05 75 9d 01 00 	movq   $0x0,0x19d75(%rip)        # 230c8 <fwp_tape_cached_bytes>
    934f:	00 00 00 00 
    9353:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    9359:	48 8b 05 a0 9d 01 00 	mov    0x19da0(%rip),%rax        # 23100 <fwp_tape_workspace+0x20>
    9360:	66 0f 6f 0d 88 9d 01 	movdqa 0x19d88(%rip),%xmm1        # 230f0 <fwp_tape_workspace+0x10>
    9367:	00 
    9368:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    936d:	48 8b 05 94 9d 01 00 	mov    0x19d94(%rip),%rax        # 23108 <fwp_tape_workspace+0x28>
    9374:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    937a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    937e:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    9383:	48 8b 05 86 9d 01 00 	mov    0x19d86(%rip),%rax        # 23110 <fwp_tape_workspace+0x30>
    938a:	0f 29 0d 4f 9d 01 00 	movaps %xmm1,0x19d4f(%rip)        # 230e0 <fwp_tape_workspace>
    9391:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    9396:	0f 29 0d 53 9d 01 00 	movaps %xmm1,0x19d53(%rip)        # 230f0 <fwp_tape_workspace+0x10>
    939d:	48 c7 05 68 9d 01 00 	movq   $0x0,0x19d68(%rip)        # 23110 <fwp_tape_workspace+0x30>
    93a4:	00 00 00 00 
    93a8:	0f 29 0d 51 9d 01 00 	movaps %xmm1,0x19d51(%rip)        # 23100 <fwp_tape_workspace+0x20>
    93af:	e9 f1 f1 ff ff       	jmp    85a5 <f12+0x275>
    93b4:	0f 1f 40 00          	nopl   0x0(%rax)
    93b8:	48 85 c9             	test   %rcx,%rcx
    93bb:	0f 84 c9 01 00 00    	je     958a <f12+0x125a>
    93c1:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
    93c6:	49 8d 5e ff          	lea    -0x1(%r14),%rbx
    93ca:	31 f6                	xor    %esi,%esi
    93cc:	48 89 cf             	mov    %rcx,%rdi
    93cf:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    93d4:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    93db:	00 
    93dc:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    93e1:	e8 da a0 ff ff       	call   34c0 <memset@plt>
    93e6:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    93ec:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    93f2:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
    93f7:	48 89 c1             	mov    %rax,%rcx
    93fa:	e9 d2 f5 ff ff       	jmp    89d1 <f12+0x6a1>
    93ff:	be 02 00 00 00       	mov    $0x2,%esi
    9404:	bf 08 00 00 00       	mov    $0x8,%edi
    9409:	e8 a2 c6 ff ff       	call   5ab0 <fwp_heap_alloc>
    940e:	49 89 c6             	mov    %rax,%r14
    9411:	45 31 e4             	xor    %r12d,%r12d
    9414:	e9 d7 fb ff ff       	jmp    8ff0 <f12+0xcc0>
    9419:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9420:	66 85 c0             	test   %ax,%ax
    9423:	0f 85 75 fd ff ff    	jne    919e <f12+0xe6e>
    9429:	e9 62 fd ff ff       	jmp    9190 <f12+0xe60>
    942e:	66 90                	xchg   %ax,%ax
    9430:	48 89 d7             	mov    %rdx,%rdi
    9433:	be 08 00 00 00       	mov    $0x8,%esi
    9438:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    943d:	e8 de a0 ff ff       	call   3520 <calloc@plt>
    9442:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    9448:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
    944e:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
    9453:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    9458:	48 89 c1             	mov    %rax,%rcx
    945b:	e9 40 f5 ff ff       	jmp    89a0 <f12+0x670>
    9460:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9464:	e9 e6 ef ff ff       	jmp    844f <f12+0x11f>
    9469:	49 8b 07             	mov    (%r15),%rax
    946c:	48 85 c0             	test   %rax,%rax
    946f:	78 8e                	js     93ff <f12+0x10cf>
    9471:	48 8b 35 00 b7 01 00 	mov    0x1b700(%rip),%rsi        # 24b78 <fwp_heap+0x13d8>
    9478:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    947d:	48 2b 0d cc b6 01 00 	sub    0x1b6cc(%rip),%rcx        # 24b50 <fwp_heap+0x13b0>
    9484:	48 c1 e6 10          	shl    $0x10,%rsi
    9488:	48 39 f1             	cmp    %rsi,%rcx
    948b:	0f 83 6e ff ff ff    	jae    93ff <f12+0x10cf>
    9491:	48 89 ce             	mov    %rcx,%rsi
    9494:	48 c1 ee 10          	shr    $0x10,%rsi
    9498:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    949c:	48 8b 35 f5 b6 01 00 	mov    0x1b6f5(%rip),%rsi        # 24b98 <fwp_heap+0x13f8>
    94a3:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    94a7:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    94ab:	48 85 ff             	test   %rdi,%rdi
    94ae:	0f 84 4b ff ff ff    	je     93ff <f12+0x10cf>
    94b4:	48 0f ba f0 3f       	btr    $0x3f,%rax
    94b9:	49 89 c5             	mov    %rax,%r13
    94bc:	e9 53 f8 ff ff       	jmp    8d14 <f12+0x9e4>
    94c1:	be 68 00 00 00       	mov    $0x68,%esi
    94c6:	b9 01 00 00 00       	mov    $0x1,%ecx
    94cb:	e9 0a f0 ff ff       	jmp    84da <f12+0x1aa>
    94d0:	48 89 d7             	mov    %rdx,%rdi
    94d3:	48 89 14 24          	mov    %rdx,(%rsp)
    94d7:	e8 94 be ff ff       	call   5370 <fwp_rc_forget_slot>
    94dc:	48 8b 14 24          	mov    (%rsp),%rdx
    94e0:	e9 3e f2 ff ff       	jmp    8723 <f12+0x3f3>
    94e5:	48 89 df             	mov    %rbx,%rdi
    94e8:	48 89 0c 24          	mov    %rcx,(%rsp)
    94ec:	e8 7f be ff ff       	call   5370 <fwp_rc_forget_slot>
    94f1:	48 8b 0c 24          	mov    (%rsp),%rcx
    94f5:	e9 65 f6 ff ff       	jmp    8b5f <f12+0x82f>
    94fa:	4c 89 f7             	mov    %r14,%rdi
    94fd:	e8 6e be ff ff       	call   5370 <fwp_rc_forget_slot>
    9502:	e9 93 fc ff ff       	jmp    919a <f12+0xe6a>
    9507:	e8 44 bd ff ff       	call   5250 <fwp_rc_wide_dup>
    950c:	e9 fd ee ff ff       	jmp    840e <f12+0xde>
    9511:	4d 89 f2             	mov    %r14,%r10
    9514:	48 89 cf             	mov    %rcx,%rdi
    9517:	31 f6                	xor    %esi,%esi
    9519:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    951e:	49 8d 5a ff          	lea    -0x1(%r10),%rbx
    9522:	4a 8d 14 d5 00 00 00 	lea    0x0(,%r10,8),%rdx
    9529:	00 
    952a:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    952f:	e8 8c 9f ff ff       	call   34c0 <memset@plt>
    9534:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    953a:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    9540:	48 89 c1             	mov    %rax,%rcx
    9543:	e9 81 f4 ff ff       	jmp    89c9 <f12+0x699>
    9548:	45 31 ed             	xor    %r13d,%r13d
    954b:	e9 4d f9 ff ff       	jmp    8e9d <f12+0xb6d>
    9550:	48 8d 3d ad 5b 00 00 	lea    0x5bad(%rip),%rdi        # f104 <_IO_stdin_used+0x104>
    9557:	e8 44 ac ff ff       	call   41a0 <fwp_trap>
    955c:	48 8d 3d 5d 62 00 00 	lea    0x625d(%rip),%rdi        # f7c0 <_IO_stdin_used+0x7c0>
    9563:	e8 38 ac ff ff       	call   41a0 <fwp_trap>
    9568:	48 8d 3d 59 63 00 00 	lea    0x6359(%rip),%rdi        # f8c8 <_IO_stdin_used+0x8c8>
    956f:	e8 2c ac ff ff       	call   41a0 <fwp_trap>
    9574:	e8 87 a1 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9579:	45 31 f6             	xor    %r14d,%r14d
    957c:	e9 90 fe ff ff       	jmp    9411 <f12+0x10e1>
    9581:	4d 85 d2             	test   %r10,%r10
    9584:	0f 84 38 f4 ff ff    	je     89c2 <f12+0x692>
    958a:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
    9591:	00 
    9592:	4c 89 e7             	mov    %r12,%rdi
    9595:	48 89 05 9c be 01 00 	mov    %rax,0x1be9c(%rip)        # 25438 <fwp_cleanups>
    959c:	e8 ef b8 ff ff       	call   4e90 <fwp_tape_buffers_release>
    95a1:	48 8b 0d b8 9a 00 00 	mov    0x9ab8(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    95a8:	ba 13 00 00 00       	mov    $0x13,%edx
    95ad:	be 01 00 00 00       	mov    $0x1,%esi
    95b2:	48 8d 3d 4f 5a 00 00 	lea    0x5a4f(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    95b9:	e8 c2 a0 ff ff       	call   3680 <fwrite@plt>
    95be:	31 ff                	xor    %edi,%edi
    95c0:	e8 fb 9f ff ff       	call   35c0 <fflush@plt>
    95c5:	bf 66 00 00 00       	mov    $0x66,%edi
    95ca:	e8 d1 a0 ff ff       	call   36a0 <_Exit@plt>
    95cf:	48 8d 3d 7f 5b 00 00 	lea    0x5b7f(%rip),%rdi        # f155 <_IO_stdin_used+0x155>
    95d6:	e8 c5 ab ff ff       	call   41a0 <fwp_trap>
    95db:	48 8d 3d 4b 5b 00 00 	lea    0x5b4b(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    95e2:	e8 b9 ab ff ff       	call   41a0 <fwp_trap>
    95e7:	48 8d 3d 4d 5b 00 00 	lea    0x5b4d(%rip),%rdi        # f13b <_IO_stdin_used+0x13b>
    95ee:	e8 ad ab ff ff       	call   41a0 <fwp_trap>
    95f3:	48 8d 3d 0e 62 00 00 	lea    0x620e(%rip),%rdi        # f808 <_IO_stdin_used+0x808>
    95fa:	e8 a1 ab ff ff       	call   41a0 <fwp_trap>
    95ff:	e8 5c 9e ff ff       	call   3460 <__stack_chk_fail@plt>
    9604:	48 8d 3d 8d 62 00 00 	lea    0x628d(%rip),%rdi        # f898 <_IO_stdin_used+0x898>
    960b:	e8 90 ab ff ff       	call   41a0 <fwp_trap>
    9610:	48 8d 3d 51 62 00 00 	lea    0x6251(%rip),%rdi        # f868 <_IO_stdin_used+0x868>
    9617:	e8 84 ab ff ff       	call   41a0 <fwp_trap>
    961c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009620 <fwp_owned_entry12>:
    9620:	f3 0f 1e fa          	endbr64
    9624:	48 8b 3f             	mov    (%rdi),%rdi
    9627:	e9 04 ed ff ff       	jmp    8330 <f12>
    962c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009630 <e12>:
    9630:	f3 0f 1e fa          	endbr64
    9634:	53                   	push   %rbx
    9635:	48 8b 1f             	mov    (%rdi),%rbx
    9638:	48 89 df             	mov    %rbx,%rdi
    963b:	e8 a0 ce ff ff       	call   64e0 <fwp_rc_share>
    9640:	48 89 df             	mov    %rbx,%rdi
    9643:	e8 e8 ec ff ff       	call   8330 <f12>
    9648:	48 89 c3             	mov    %rax,%rbx
    964b:	48 89 c7             	mov    %rax,%rdi
    964e:	e8 8d ce ff ff       	call   64e0 <fwp_rc_share>
    9653:	48 89 d8             	mov    %rbx,%rax
    9656:	5b                   	pop    %rbx
    9657:	c3                   	ret
    9658:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    965f:	00 

0000000000009660 <fwp_write>:
    9660:	41 57                	push   %r15
    9662:	41 56                	push   %r14
    9664:	41 55                	push   %r13
    9666:	41 54                	push   %r12
    9668:	55                   	push   %rbp
    9669:	53                   	push   %rbx
    966a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9671:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9678:	00 00 
    967a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9681:	00 
    9682:	49 89 d4             	mov    %rdx,%r12
    9685:	8b 12                	mov    (%rdx),%edx
    9687:	83 fa 19             	cmp    $0x19,%edx
    968a:	77 6a                	ja     96f6 <fwp_write+0x96>
    968c:	48 89 f5             	mov    %rsi,%rbp
    968f:	89 d0                	mov    %edx,%eax
    9691:	89 ce                	mov    %ecx,%esi
    9693:	48 89 fb             	mov    %rdi,%rbx
    9696:	48 8d 0d 73 63 00 00 	lea    0x6373(%rip),%rcx        # fa10 <_IO_stdin_used+0xa10>
    969d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    96a1:	48 01 c8             	add    %rcx,%rax
    96a4:	3e ff e0             	notrack jmp *%rax
    96a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    96ae:	00 00 
    96b0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    96b4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    96b8:	48 89 ca             	mov    %rcx,%rdx
    96bb:	48 85 c9             	test   %rcx,%rcx
    96be:	0f 88 9c 0c 00 00    	js     a360 <fwp_write+0xd00>
    96c4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    96cb:	00 
    96cc:	48 89 c6             	mov    %rax,%rsi
    96cf:	4c 89 e7             	mov    %r12,%rdi
    96d2:	e8 69 a3 ff ff       	call   3a40 <fwp_fmt_u128>
    96d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    96de:	00 00 
    96e0:	4c 89 e7             	mov    %r12,%rdi
    96e3:	e8 68 9d ff ff       	call   3450 <strlen@plt>
    96e8:	4c 89 e6             	mov    %r12,%rsi
    96eb:	48 89 df             	mov    %rbx,%rdi
    96ee:	48 89 c2             	mov    %rax,%rdx
    96f1:	e8 7a a9 ff ff       	call   4070 <buf_put>
    96f6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    96fd:	00 
    96fe:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9705:	00 00 
    9707:	0f 85 28 04 00 00    	jne    9b35 <fwp_write+0x4d5>
    970d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9714:	5b                   	pop    %rbx
    9715:	5d                   	pop    %rbp
    9716:	41 5c                	pop    %r12
    9718:	41 5d                	pop    %r13
    971a:	41 5e                	pop    %r14
    971c:	41 5f                	pop    %r15
    971e:	c3                   	ret
    971f:	90                   	nop
    9720:	49 89 e9             	mov    %rbp,%r9
    9723:	4c 8d 05 57 5a 00 00 	lea    0x5a57(%rip),%r8        # f181 <_IO_stdin_used+0x181>
    972a:	b9 00 02 00 00       	mov    $0x200,%ecx
    972f:	ba 02 00 00 00       	mov    $0x2,%edx
    9734:	be 00 02 00 00       	mov    $0x200,%esi
    9739:	31 c0                	xor    %eax,%eax
    973b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9742:	00 
    9743:	e8 68 9c ff ff       	call   33b0 <__snprintf_chk@plt>
    9748:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    974f:	00 
    9750:	e8 fb 9c ff ff       	call   3450 <strlen@plt>
    9755:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    975c:	00 
    975d:	48 89 df             	mov    %rbx,%rdi
    9760:	48 89 c2             	mov    %rax,%rdx
    9763:	e8 08 a9 ff ff       	call   4070 <buf_put>
    9768:	eb 8c                	jmp    96f6 <fwp_write+0x96>
    976a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9770:	49 89 e9             	mov    %rbp,%r9
    9773:	4c 8d 05 02 5a 00 00 	lea    0x5a02(%rip),%r8        # f17c <_IO_stdin_used+0x17c>
    977a:	eb ae                	jmp    972a <fwp_write+0xca>
    977c:	0f 1f 40 00          	nopl   0x0(%rax)
    9780:	83 fa 13             	cmp    $0x13,%edx
    9783:	48 8d 05 e8 59 00 00 	lea    0x59e8(%rip),%rax        # f172 <_IO_stdin_used+0x172>
    978a:	48 8d 35 e6 59 00 00 	lea    0x59e6(%rip),%rsi        # f177 <_IO_stdin_used+0x177>
    9791:	ba 04 00 00 00       	mov    $0x4,%edx
    9796:	48 0f 44 f0          	cmove  %rax,%rsi
    979a:	45 31 ed             	xor    %r13d,%r13d
    979d:	e8 ce a8 ff ff       	call   4070 <buf_put>
    97a2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    97a7:	0f 84 a3 08 00 00    	je     a050 <fwp_write+0x9f0>
    97ad:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    97b2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    97b7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    97bc:	48 89 df             	mov    %rbx,%rdi
    97bf:	49 0f 44 c5          	cmove  %r13,%rax
    97c3:	31 c9                	xor    %ecx,%ecx
    97c5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    97ca:	e8 91 fe ff ff       	call   9660 <fwp_write>
    97cf:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    97d4:	0f 84 6e 09 00 00    	je     a148 <fwp_write+0xae8>
    97da:	49 83 c5 01          	add    $0x1,%r13
    97de:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    97e2:	0f 83 68 08 00 00    	jae    a050 <fwp_write+0x9f0>
    97e8:	ba 02 00 00 00       	mov    $0x2,%edx
    97ed:	48 8d 35 cd 59 00 00 	lea    0x59cd(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    97f4:	48 89 df             	mov    %rbx,%rdi
    97f7:	e8 74 a8 ff ff       	call   4070 <buf_put>
    97fc:	eb af                	jmp    97ad <fwp_write+0x14d>
    97fe:	66 90                	xchg   %ax,%ax
    9800:	ba 06 00 00 00       	mov    $0x6,%edx
    9805:	48 8d 35 8e 59 00 00 	lea    0x598e(%rip),%rsi        # f19a <_IO_stdin_used+0x19a>
    980c:	48 83 c5 10          	add    $0x10,%rbp
    9810:	e8 5b a8 ff ff       	call   4070 <buf_put>
    9815:	48 89 ef             	mov    %rbp,%rdi
    9818:	e8 33 9c ff ff       	call   3450 <strlen@plt>
    981d:	48 89 ee             	mov    %rbp,%rsi
    9820:	48 89 df             	mov    %rbx,%rdi
    9823:	48 89 c2             	mov    %rax,%rdx
    9826:	e8 45 a8 ff ff       	call   4070 <buf_put>
    982b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9830:	ba 01 00 00 00       	mov    $0x1,%edx
    9835:	48 89 df             	mov    %rbx,%rdi
    9838:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    983d:	e8 2e a8 ff ff       	call   4070 <buf_put>
    9842:	e9 af fe ff ff       	jmp    96f6 <fwp_write+0x96>
    9847:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    984e:	00 00 
    9850:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9857:	00 
    9858:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    985f:	00 00 
    9861:	0f 85 ce 02 00 00    	jne    9b35 <fwp_write+0x4d5>
    9867:	ba 0a 00 00 00       	mov    $0xa,%edx
    986c:	48 8d 35 13 59 00 00 	lea    0x5913(%rip),%rsi        # f186 <_IO_stdin_used+0x186>
    9873:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    987a:	48 89 df             	mov    %rbx,%rdi
    987d:	5b                   	pop    %rbx
    987e:	5d                   	pop    %rbp
    987f:	41 5c                	pop    %r12
    9881:	41 5d                	pop    %r13
    9883:	41 5e                	pop    %r14
    9885:	41 5f                	pop    %r15
    9887:	e9 e4 a7 ff ff       	jmp    4070 <buf_put>
    988c:	0f 1f 40 00          	nopl   0x0(%rax)
    9890:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    9895:	4d 85 ed             	test   %r13,%r13
    9898:	0f 84 02 0c 00 00    	je     a4a0 <fwp_write+0xe40>
    989e:	48 8d 35 29 59 00 00 	lea    0x5929(%rip),%rsi        # f1ce <_IO_stdin_used+0x1ce>
    98a5:	4c 89 ef             	mov    %r13,%rdi
    98a8:	e8 83 9c ff ff       	call   3530 <strcmp@plt>
    98ad:	41 89 c1             	mov    %eax,%r9d
    98b0:	85 c0                	test   %eax,%eax
    98b2:	0f 84 6c 0c 00 00    	je     a524 <fwp_write+0xec4>
    98b8:	4c 89 ef             	mov    %r13,%rdi
    98bb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    98c0:	e8 8b 9b ff ff       	call   3450 <strlen@plt>
    98c5:	4c 89 ee             	mov    %r13,%rsi
    98c8:	48 89 df             	mov    %rbx,%rdi
    98cb:	48 89 c2             	mov    %rax,%rdx
    98ce:	e8 9d a7 ff ff       	call   4070 <buf_put>
    98d3:	ba 01 00 00 00       	mov    $0x1,%edx
    98d8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    98dd:	48 89 df             	mov    %rbx,%rdi
    98e0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    98e5:	e8 86 a7 ff ff       	call   4070 <buf_put>
    98ea:	ba 01 00 00 00       	mov    $0x1,%edx
    98ef:	4c 89 fe             	mov    %r15,%rsi
    98f2:	48 89 df             	mov    %rbx,%rdi
    98f5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    98fa:	e8 71 a7 ff ff       	call   4070 <buf_put>
    98ff:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9904:	45 31 f6             	xor    %r14d,%r14d
    9907:	85 d2                	test   %edx,%edx
    9909:	0f 8e 81 0a 00 00    	jle    a390 <fwp_write+0xd30>
    990f:	45 31 ed             	xor    %r13d,%r13d
    9912:	4d 85 ed             	test   %r13,%r13
    9915:	0f 85 75 07 00 00    	jne    a090 <fwp_write+0xa30>
    991b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9922:	00 
    9923:	45 85 f6             	test   %r14d,%r14d
    9926:	0f 84 84 07 00 00    	je     a0b0 <fwp_write+0xa50>
    992c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    9931:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    9936:	48 89 df             	mov    %rbx,%rdi
    9939:	49 83 c5 01          	add    $0x1,%r13
    993d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    9941:	31 c9                	xor    %ecx,%ecx
    9943:	e8 18 fd ff ff       	call   9660 <fwp_write>
    9948:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    994d:	7f c3                	jg     9912 <fwp_write+0x2b2>
    994f:	45 85 f6             	test   %r14d,%r14d
    9952:	0f 84 38 0a 00 00    	je     a390 <fwp_write+0xd30>
    9958:	b8 29 00 00 00       	mov    $0x29,%eax
    995d:	ba 01 00 00 00       	mov    $0x1,%edx
    9962:	4c 89 fe             	mov    %r15,%rsi
    9965:	48 89 df             	mov    %rbx,%rdi
    9968:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    996c:	e8 ff a6 ff ff       	call   4070 <buf_put>
    9971:	e9 80 fd ff ff       	jmp    96f6 <fwp_write+0x96>
    9976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    997d:	00 00 00 
    9980:	ba 01 00 00 00       	mov    $0x1,%edx
    9985:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    998a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    998f:	e8 dc a6 ff ff       	call   4070 <buf_put>
    9994:	48 85 ed             	test   %rbp,%rbp
    9997:	0f 84 93 06 00 00    	je     a030 <fwp_write+0x9d0>
    999d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    99a1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    99a6:	31 c9                	xor    %ecx,%ecx
    99a8:	48 89 df             	mov    %rbx,%rdi
    99ab:	e8 b0 fc ff ff       	call   9660 <fwp_write>
    99b0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    99b4:	48 85 ed             	test   %rbp,%rbp
    99b7:	0f 84 73 06 00 00    	je     a030 <fwp_write+0x9d0>
    99bd:	ba 02 00 00 00       	mov    $0x2,%edx
    99c2:	48 8d 35 f8 57 00 00 	lea    0x57f8(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    99c9:	48 89 df             	mov    %rbx,%rdi
    99cc:	e8 9f a6 ff ff       	call   4070 <buf_put>
    99d1:	eb ca                	jmp    999d <fwp_write+0x33d>
    99d3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    99d8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    99dc:	85 f6                	test   %esi,%esi
    99de:	0f 84 fc 07 00 00    	je     a1e0 <fwp_write+0xb80>
    99e4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    99eb:	00 
    99ec:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    99f3:	00 00 
    99f5:	0f 85 3a 01 00 00    	jne    9b35 <fwp_write+0x4d5>
    99fb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    99ff:	4c 89 ea             	mov    %r13,%rdx
    9a02:	e9 6c fe ff ff       	jmp    9873 <fwp_write+0x213>
    9a07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9a0e:	00 00 
    9a10:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    9a15:	ba 01 00 00 00       	mov    $0x1,%edx
    9a1a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    9a1f:	48 89 ee             	mov    %rbp,%rsi
    9a22:	e8 49 a6 ff ff       	call   4070 <buf_put>
    9a27:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    9a2c:	4c 89 e7             	mov    %r12,%rdi
    9a2f:	e8 1c 9a ff ff       	call   3450 <strlen@plt>
    9a34:	4c 89 e6             	mov    %r12,%rsi
    9a37:	48 89 df             	mov    %rbx,%rdi
    9a3a:	48 89 c2             	mov    %rax,%rdx
    9a3d:	e8 2e a6 ff ff       	call   4070 <buf_put>
    9a42:	ba 01 00 00 00       	mov    $0x1,%edx
    9a47:	48 89 ee             	mov    %rbp,%rsi
    9a4a:	48 89 df             	mov    %rbx,%rdi
    9a4d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9a52:	e8 19 a6 ff ff       	call   4070 <buf_put>
    9a57:	e9 9a fc ff ff       	jmp    96f6 <fwp_write+0x96>
    9a5c:	0f 1f 40 00          	nopl   0x0(%rax)
    9a60:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    9a65:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    9a69:	0f 8a 8e 0b 00 00    	jp     a5fd <fwp_write+0xf9d>
    9a6f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9a73:	66 0f 54 05 a5 60 00 	andpd  0x60a5(%rip),%xmm0        # fb20 <msg.8+0xa0>
    9a7a:	00 
    9a7b:	bd 01 00 00 00       	mov    $0x1,%ebp
    9a80:	66 0f 2e 05 d0 60 00 	ucomisd 0x60d0(%rip),%xmm0        # fb58 <msg.8+0xd8>
    9a87:	00 
    9a88:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9a8f:	00 
    9a90:	0f 87 b2 09 00 00    	ja     a448 <fwp_write+0xde8>
    9a96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9a9d:	00 00 00 
    9aa0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9aa4:	89 ee                	mov    %ebp,%esi
    9aa6:	4c 89 e7             	mov    %r12,%rdi
    9aa9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    9aae:	e8 0d aa ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9ab3:	31 f6                	xor    %esi,%esi
    9ab5:	4c 89 e7             	mov    %r12,%rdi
    9ab8:	e8 53 99 ff ff       	call   3410 <strtod@plt>
    9abd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    9ac2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    9ac6:	7a 06                	jp     9ace <fwp_write+0x46e>
    9ac8:	0f 84 e9 01 00 00    	je     9cb7 <fwp_write+0x657>
    9ace:	83 c5 01             	add    $0x1,%ebp
    9ad1:	83 fd 12             	cmp    $0x12,%ebp
    9ad4:	75 ca                	jne    9aa0 <fwp_write+0x440>
    9ad6:	be 11 00 00 00       	mov    $0x11,%esi
    9adb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9adf:	4c 89 e7             	mov    %r12,%rdi
    9ae2:	e8 d9 a9 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9ae7:	e9 cb 01 00 00       	jmp    9cb7 <fwp_write+0x657>
    9aec:	0f 1f 40 00          	nopl   0x0(%rax)
    9af0:	48 83 fd 01          	cmp    $0x1,%rbp
    9af4:	0f 84 e6 08 00 00    	je     a3e0 <fwp_write+0xd80>
    9afa:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    9afe:	b8 02 00 00 00       	mov    $0x2,%eax
    9b03:	ba 01 00 00 00       	mov    $0x1,%edx
    9b08:	48 0f 44 d0          	cmove  %rax,%rdx
    9b0c:	48 8d 35 57 56 00 00 	lea    0x5657(%rip),%rsi        # f16a <_IO_stdin_used+0x16a>
    9b13:	48 8d 05 55 56 00 00 	lea    0x5655(%rip),%rax        # f16f <_IO_stdin_used+0x16f>
    9b1a:	48 0f 44 f0          	cmove  %rax,%rsi
    9b1e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9b25:	00 
    9b26:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9b2d:	00 00 
    9b2f:	0f 84 3e fd ff ff    	je     9873 <fwp_write+0x213>
    9b35:	e8 26 99 ff ff       	call   3460 <__stack_chk_fail@plt>
    9b3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9b40:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    9b45:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    9b4a:	e8 61 a4 ff ff       	call   3fb0 <buf_grow>
    9b4f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    9b53:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    9b59:	4c 03 0b             	add    (%rbx),%r9
    9b5c:	66 45 89 11          	mov    %r10w,(%r9)
    9b60:	45 85 e4             	test   %r12d,%r12d
    9b63:	0f 8e 07 05 00 00    	jle    a070 <fwp_write+0xa10>
    9b69:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    9b70:	55 55 55 
    9b73:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    9b78:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    9b7f:	aa aa aa 
    9b82:	49 83 c1 01          	add    $0x1,%r9
    9b86:	eb 45                	jmp    9bcd <fwp_write+0x56d>
    9b88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9b8f:	00 
    9b90:	be 01 00 00 00       	mov    $0x1,%esi
    9b95:	b8 2d 00 00 00       	mov    $0x2d,%eax
    9b9a:	88 07                	mov    %al,(%rdi)
    9b9c:	48 89 e8             	mov    %rbp,%rax
    9b9f:	49 f7 e8             	imul   %r8
    9ba2:	48 89 e8             	mov    %rbp,%rax
    9ba5:	48 c1 f8 3f          	sar    $0x3f,%rax
    9ba9:	48 29 c2             	sub    %rax,%rdx
    9bac:	48 85 c9             	test   %rcx,%rcx
    9baf:	0f 95 c0             	setne  %al
    9bb2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    9bb6:	48 83 ef 01          	sub    $0x1,%rdi
    9bba:	48 21 c5             	and    %rax,%rbp
    9bbd:	48 29 ea             	sub    %rbp,%rdx
    9bc0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    9bc4:	49 39 f9             	cmp    %rdi,%r9
    9bc7:	0f 84 a3 04 00 00    	je     a070 <fwp_write+0xa10>
    9bcd:	48 89 e8             	mov    %rbp,%rax
    9bd0:	49 f7 e8             	imul   %r8
    9bd3:	48 89 e8             	mov    %rbp,%rax
    9bd6:	48 c1 f8 3f          	sar    $0x3f,%rax
    9bda:	48 89 d1             	mov    %rdx,%rcx
    9bdd:	48 29 c1             	sub    %rax,%rcx
    9be0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    9be4:	48 89 e9             	mov    %rbp,%rcx
    9be7:	48 29 c1             	sub    %rax,%rcx
    9bea:	48 8d 41 03          	lea    0x3(%rcx),%rax
    9bee:	49 f7 e2             	mul    %r10
    9bf1:	b8 30 00 00 00       	mov    $0x30,%eax
    9bf6:	48 89 d6             	mov    %rdx,%rsi
    9bf9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    9bfd:	48 d1 ee             	shr    $1,%rsi
    9c00:	48 01 f2             	add    %rsi,%rdx
    9c03:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    9c07:	48 29 d6             	sub    %rdx,%rsi
    9c0a:	74 8e                	je     9b9a <fwp_write+0x53a>
    9c0c:	48 83 fe 01          	cmp    $0x1,%rsi
    9c10:	0f 85 7a ff ff ff    	jne    9b90 <fwp_write+0x530>
    9c16:	31 f6                	xor    %esi,%esi
    9c18:	b8 2b 00 00 00       	mov    $0x2b,%eax
    9c1d:	e9 78 ff ff ff       	jmp    9b9a <fwp_write+0x53a>
    9c22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9c28:	66 0f 6e cd          	movd   %ebp,%xmm1
    9c2c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    9c2f:	0f 8a c8 09 00 00    	jp     a5fd <fwp_write+0xf9d>
    9c35:	0f 28 c1             	movaps %xmm1,%xmm0
    9c38:	0f 54 05 d1 5e 00 00 	andps  0x5ed1(%rip),%xmm0        # fb10 <msg.8+0x90>
    9c3f:	0f 2e 05 be 53 00 00 	ucomiss 0x53be(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    9c46:	0f 87 24 08 00 00    	ja     a470 <fwp_write+0xe10>
    9c4c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9c50:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    9c56:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9c5d:	00 
    9c5e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    9c62:	66 49 0f 7e d7       	movq   %xmm2,%r15
    9c67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9c6e:	00 00 
    9c70:	44 89 ee             	mov    %r13d,%esi
    9c73:	66 49 0f 6e c7       	movq   %r15,%xmm0
    9c78:	4c 89 e7             	mov    %r12,%rdi
    9c7b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    9c80:	e8 3b a8 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9c85:	31 f6                	xor    %esi,%esi
    9c87:	4c 89 e7             	mov    %r12,%rdi
    9c8a:	e8 21 98 ff ff       	call   34b0 <strtof@plt>
    9c8f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    9c94:	0f 2e c8             	ucomiss %xmm0,%xmm1
    9c97:	7a 02                	jp     9c9b <fwp_write+0x63b>
    9c99:	74 1c                	je     9cb7 <fwp_write+0x657>
    9c9b:	41 83 c5 01          	add    $0x1,%r13d
    9c9f:	41 83 fd 0a          	cmp    $0xa,%r13d
    9ca3:	75 cb                	jne    9c70 <fwp_write+0x610>
    9ca5:	be 09 00 00 00       	mov    $0x9,%esi
    9caa:	66 49 0f 6e c7       	movq   %r15,%xmm0
    9caf:	4c 89 e7             	mov    %r12,%rdi
    9cb2:	e8 09 a8 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9cb7:	4c 89 e7             	mov    %r12,%rdi
    9cba:	e8 71 a4 ff ff       	call   4130 <fwp_finish_float>
    9cbf:	e9 1c fa ff ff       	jmp    96e0 <fwp_write+0x80>
    9cc4:	0f 1f 40 00          	nopl   0x0(%rax)
    9cc8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    9ccc:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    9cd0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    9cd7:	00 
    9cd8:	48 89 ef             	mov    %rbp,%rdi
    9cdb:	e8 60 9d ff ff       	call   3a40 <fwp_fmt_u128>
    9ce0:	48 89 ef             	mov    %rbp,%rdi
    9ce3:	e8 68 97 ff ff       	call   3450 <strlen@plt>
    9ce8:	48 89 ee             	mov    %rbp,%rsi
    9ceb:	48 89 df             	mov    %rbx,%rdi
    9cee:	48 89 c2             	mov    %rax,%rdx
    9cf1:	e8 7a a3 ff ff       	call   4070 <buf_put>
    9cf6:	e9 fb f9 ff ff       	jmp    96f6 <fwp_write+0x96>
    9cfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9d00:	ba 06 00 00 00       	mov    $0x6,%edx
    9d05:	48 8d 35 b8 54 00 00 	lea    0x54b8(%rip),%rsi        # f1c4 <_IO_stdin_used+0x1c4>
    9d0c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    9d12:	e8 59 a3 ff ff       	call   4070 <buf_put>
    9d17:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    9d1e:	ff ff 7f 
    9d21:	48 23 55 00          	and    0x0(%rbp),%rdx
    9d25:	0f 84 86 02 00 00    	je     9fb1 <fwp_write+0x951>
    9d2b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9d30:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9d34:	48 85 d2             	test   %rdx,%rdx
    9d37:	0f 84 ae 00 00 00    	je     9deb <fwp_write+0x78b>
    9d3d:	8b 0a                	mov    (%rdx),%ecx
    9d3f:	83 f9 1c             	cmp    $0x1c,%ecx
    9d42:	0f 84 58 06 00 00    	je     a3a0 <fwp_write+0xd40>
    9d48:	83 f9 1b             	cmp    $0x1b,%ecx
    9d4b:	0f 87 9a 00 00 00    	ja     9deb <fwp_write+0x78b>
    9d51:	be 01 00 00 00       	mov    $0x1,%esi
    9d56:	48 d3 e6             	shl    %cl,%rsi
    9d59:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    9d5f:	0f 85 4b 04 00 00    	jne    a1b0 <fwp_write+0xb50>
    9d65:	f7 c6 84 04 00 00    	test   $0x484,%esi
    9d6b:	0f 85 0f 04 00 00    	jne    a180 <fwp_write+0xb20>
    9d71:	83 e6 21             	and    $0x21,%esi
    9d74:	74 75                	je     9deb <fwp_write+0x78b>
    9d76:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    9d7b:	48 85 ff             	test   %rdi,%rdi
    9d7e:	79 07                	jns    9d87 <fwp_write+0x727>
    9d80:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    9d84:	4c 01 ee             	add    %r13,%rsi
    9d87:	48 0f be 3e          	movsbq (%rsi),%rdi
    9d8b:	85 c9                	test   %ecx,%ecx
    9d8d:	40 0f b6 f7          	movzbl %dil,%esi
    9d91:	48 0f 44 f7          	cmove  %rdi,%rsi
    9d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9d9c:	00 00 00 00 
    9da0:	31 c9                	xor    %ecx,%ecx
    9da2:	48 89 df             	mov    %rbx,%rdi
    9da5:	49 83 c5 01          	add    $0x1,%r13
    9da9:	e8 b2 f8 ff ff       	call   9660 <fwp_write>
    9dae:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    9db5:	ff ff 7f 
    9db8:	48 23 55 00          	and    0x0(%rbp),%rdx
    9dbc:	49 39 d5             	cmp    %rdx,%r13
    9dbf:	0f 83 ec 01 00 00    	jae    9fb1 <fwp_write+0x951>
    9dc5:	ba 02 00 00 00       	mov    $0x2,%edx
    9dca:	48 89 df             	mov    %rbx,%rdi
    9dcd:	48 8d 35 ed 53 00 00 	lea    0x53ed(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    9dd4:	e8 97 a2 ff ff       	call   4070 <buf_put>
    9dd9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9dde:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9de2:	48 85 d2             	test   %rdx,%rdx
    9de5:	0f 85 52 ff ff ff    	jne    9d3d <fwp_write+0x6dd>
    9deb:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    9df0:	48 85 ff             	test   %rdi,%rdi
    9df3:	0f 88 cf 05 00 00    	js     a3c8 <fwp_write+0xd68>
    9df9:	48 8b 31             	mov    (%rcx),%rsi
    9dfc:	eb a2                	jmp    9da0 <fwp_write+0x740>
    9dfe:	66 90                	xchg   %ax,%ax
    9e00:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9e07:	00 
    9e08:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9e0f:	00 00 
    9e11:	0f 85 1e fd ff ff    	jne    9b35 <fwp_write+0x4d5>
    9e17:	ba 08 00 00 00       	mov    $0x8,%edx
    9e1c:	48 8d 35 6e 53 00 00 	lea    0x536e(%rip),%rsi        # f191 <_IO_stdin_used+0x191>
    9e23:	e9 4b fa ff ff       	jmp    9873 <fwp_write+0x213>
    9e28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9e2f:	00 
    9e30:	89 e8                	mov    %ebp,%eax
    9e32:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    9e39:	76 03                	jbe    9e3e <fwp_write+0x7de>
    9e3b:	8b 45 00             	mov    0x0(%rbp),%eax
    9e3e:	41 89 c6             	mov    %eax,%r14d
    9e41:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9e46:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    9e4b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    9e4f:	4c 89 ef             	mov    %r13,%rdi
    9e52:	e8 f9 95 ff ff       	call   3450 <strlen@plt>
    9e57:	4c 89 ee             	mov    %r13,%rsi
    9e5a:	48 89 df             	mov    %rbx,%rdi
    9e5d:	48 89 c2             	mov    %rax,%rdx
    9e60:	e8 0b a2 ff ff       	call   4070 <buf_put>
    9e65:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    9e6a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    9e6e:	85 f6                	test   %esi,%esi
    9e70:	0f 8e 80 f8 ff ff    	jle    96f6 <fwp_write+0x96>
    9e76:	45 31 ed             	xor    %r13d,%r13d
    9e79:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9e7e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    9e83:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9e88:	ba 01 00 00 00       	mov    $0x1,%edx
    9e8d:	4c 89 fe             	mov    %r15,%rsi
    9e90:	48 89 04 24          	mov    %rax,(%rsp)
    9e94:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    9e99:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    9e9d:	48 89 df             	mov    %rbx,%rdi
    9ea0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    9ea4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9ea9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    9eae:	e8 bd a1 ff ff       	call   4070 <buf_put>
    9eb3:	41 8b 06             	mov    (%r14),%eax
    9eb6:	83 f8 0e             	cmp    $0xe,%eax
    9eb9:	0f 84 71 02 00 00    	je     a130 <fwp_write+0xad0>
    9ebf:	83 f8 10             	cmp    $0x10,%eax
    9ec2:	0f 84 38 02 00 00    	je     a100 <fwp_write+0xaa0>
    9ec8:	83 f8 0a             	cmp    $0xa,%eax
    9ecb:	0f 84 7f 04 00 00    	je     a350 <fwp_write+0xcf0>
    9ed1:	0f 8f f9 00 00 00    	jg     9fd0 <fwp_write+0x970>
    9ed7:	83 f8 03             	cmp    $0x3,%eax
    9eda:	0f 8f 50 04 00 00    	jg     a330 <fwp_write+0xcd0>
    9ee0:	85 c0                	test   %eax,%eax
    9ee2:	78 10                	js     9ef4 <fwp_write+0x894>
    9ee4:	48 8b 04 24          	mov    (%rsp),%rax
    9ee8:	48 c1 e8 3f          	shr    $0x3f,%rax
    9eec:	85 c0                	test   %eax,%eax
    9eee:	0f 85 f9 00 00 00    	jne    9fed <fwp_write+0x98d>
    9ef4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9ef9:	48 8b 34 24          	mov    (%rsp),%rsi
    9efd:	31 c9                	xor    %ecx,%ecx
    9eff:	48 89 df             	mov    %rbx,%rdi
    9f02:	e8 59 f7 ff ff       	call   9660 <fwp_write>
    9f07:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    9f0c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9f11:	49 83 c5 01          	add    $0x1,%r13
    9f15:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    9f19:	0f 8f 5f ff ff ff    	jg     9e7e <fwp_write+0x81e>
    9f1f:	e9 d2 f7 ff ff       	jmp    96f6 <fwp_write+0x96>
    9f24:	0f 1f 40 00          	nopl   0x0(%rax)
    9f28:	ba 06 00 00 00       	mov    $0x6,%edx
    9f2d:	48 8d 35 83 52 00 00 	lea    0x5283(%rip),%rsi        # f1b7 <_IO_stdin_used+0x1b7>
    9f34:	45 31 ed             	xor    %r13d,%r13d
    9f37:	e8 34 a1 ff ff       	call   4070 <buf_put>
    9f3c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9f41:	75 19                	jne    9f5c <fwp_write+0x8fc>
    9f43:	eb 6c                	jmp    9fb1 <fwp_write+0x951>
    9f45:	0f 1f 00             	nopl   (%rax)
    9f48:	ba 02 00 00 00       	mov    $0x2,%edx
    9f4d:	48 8d 35 6d 52 00 00 	lea    0x526d(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    9f54:	48 89 df             	mov    %rbx,%rdi
    9f57:	e8 14 a1 ff ff       	call   4070 <buf_put>
    9f5c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    9f62:	b9 00 02 00 00       	mov    $0x200,%ecx
    9f67:	31 c0                	xor    %eax,%eax
    9f69:	49 83 c5 01          	add    $0x1,%r13
    9f6d:	4c 8d 05 4a 52 00 00 	lea    0x524a(%rip),%r8        # f1be <_IO_stdin_used+0x1be>
    9f74:	ba 02 00 00 00       	mov    $0x2,%edx
    9f79:	be 00 02 00 00       	mov    $0x200,%esi
    9f7e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9f85:	00 
    9f86:	e8 25 94 ff ff       	call   33b0 <__snprintf_chk@plt>
    9f8b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9f92:	00 
    9f93:	e8 b8 94 ff ff       	call   3450 <strlen@plt>
    9f98:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9f9f:	00 
    9fa0:	48 89 df             	mov    %rbx,%rdi
    9fa3:	48 89 c2             	mov    %rax,%rdx
    9fa6:	e8 c5 a0 ff ff       	call   4070 <buf_put>
    9fab:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9faf:	72 97                	jb     9f48 <fwp_write+0x8e8>
    9fb1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9fb6:	ba 01 00 00 00       	mov    $0x1,%edx
    9fbb:	48 89 df             	mov    %rbx,%rdi
    9fbe:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9fc3:	e8 a8 a0 ff ff       	call   4070 <buf_put>
    9fc8:	e9 29 f7 ff ff       	jmp    96f6 <fwp_write+0x96>
    9fcd:	0f 1f 00             	nopl   (%rax)
    9fd0:	83 f8 0b             	cmp    $0xb,%eax
    9fd3:	0f 85 1b ff ff ff    	jne    9ef4 <fwp_write+0x894>
    9fd9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    9fde:	66 0f 50 c3          	movmskpd %xmm3,%eax
    9fe2:	83 e0 01             	and    $0x1,%eax
    9fe5:	85 c0                	test   %eax,%eax
    9fe7:	0f 84 07 ff ff ff    	je     9ef4 <fwp_write+0x894>
    9fed:	4c 89 fe             	mov    %r15,%rsi
    9ff0:	48 89 df             	mov    %rbx,%rdi
    9ff3:	ba 01 00 00 00       	mov    $0x1,%edx
    9ff8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9ffd:	e8 6e a0 ff ff       	call   4070 <buf_put>
    a002:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a007:	48 8b 34 24          	mov    (%rsp),%rsi
    a00b:	31 c9                	xor    %ecx,%ecx
    a00d:	48 89 df             	mov    %rbx,%rdi
    a010:	e8 4b f6 ff ff       	call   9660 <fwp_write>
    a015:	ba 01 00 00 00       	mov    $0x1,%edx
    a01a:	4c 89 fe             	mov    %r15,%rsi
    a01d:	48 89 df             	mov    %rbx,%rdi
    a020:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a025:	e8 46 a0 ff ff       	call   4070 <buf_put>
    a02a:	e9 d8 fe ff ff       	jmp    9f07 <fwp_write+0x8a7>
    a02f:	90                   	nop
    a030:	ba 01 00 00 00       	mov    $0x1,%edx
    a035:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a03a:	48 89 df             	mov    %rbx,%rdi
    a03d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a042:	e8 29 a0 ff ff       	call   4070 <buf_put>
    a047:	e9 aa f6 ff ff       	jmp    96f6 <fwp_write+0x96>
    a04c:	0f 1f 40 00          	nopl   0x0(%rax)
    a050:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a055:	ba 01 00 00 00       	mov    $0x1,%edx
    a05a:	48 89 df             	mov    %rbx,%rdi
    a05d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a062:	e8 09 a0 ff ff       	call   4070 <buf_put>
    a067:	e9 8a f6 ff ff       	jmp    96f6 <fwp_write+0x96>
    a06c:	0f 1f 40 00          	nopl   0x0(%rax)
    a070:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a074:	48 8b 13             	mov    (%rbx),%rdx
    a077:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a07c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a080:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a084:	e9 6d f6 ff ff       	jmp    96f6 <fwp_write+0x96>
    a089:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a090:	ba 02 00 00 00       	mov    $0x2,%edx
    a095:	48 8d 35 25 51 00 00 	lea    0x5125(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    a09c:	48 89 df             	mov    %rbx,%rdi
    a09f:	e8 cc 9f ff ff       	call   4070 <buf_put>
    a0a4:	e9 72 f8 ff ff       	jmp    991b <fwp_write+0x2bb>
    a0a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a0b0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a0b5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a0ba:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a0be:	48 89 f7             	mov    %rsi,%rdi
    a0c1:	48 89 34 24          	mov    %rsi,(%rsp)
    a0c5:	e8 86 93 ff ff       	call   3450 <strlen@plt>
    a0ca:	48 8b 34 24          	mov    (%rsp),%rsi
    a0ce:	48 89 df             	mov    %rbx,%rdi
    a0d1:	48 89 c2             	mov    %rax,%rdx
    a0d4:	e8 97 9f ff ff       	call   4070 <buf_put>
    a0d9:	ba 03 00 00 00       	mov    $0x3,%edx
    a0de:	48 8d 35 ff 50 00 00 	lea    0x50ff(%rip),%rsi        # f1e4 <_IO_stdin_used+0x1e4>
    a0e5:	48 89 df             	mov    %rbx,%rdi
    a0e8:	e8 83 9f ff ff       	call   4070 <buf_put>
    a0ed:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a0f2:	e9 35 f8 ff ff       	jmp    992c <fwp_write+0x2cc>
    a0f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a0fe:	00 00 
    a100:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a105:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a109:	48 85 ff             	test   %rdi,%rdi
    a10c:	0f 84 e2 fd ff ff    	je     9ef4 <fwp_write+0x894>
    a112:	48 8d 35 b5 50 00 00 	lea    0x50b5(%rip),%rsi        # f1ce <_IO_stdin_used+0x1ce>
    a119:	e8 12 94 ff ff       	call   3530 <strcmp@plt>
    a11e:	85 c0                	test   %eax,%eax
    a120:	0f 95 c0             	setne  %al
    a123:	0f b6 c0             	movzbl %al,%eax
    a126:	e9 c1 fd ff ff       	jmp    9eec <fwp_write+0x88c>
    a12b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a130:	31 c0                	xor    %eax,%eax
    a132:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a139:	00 
    a13a:	0f 97 c0             	seta   %al
    a13d:	e9 aa fd ff ff       	jmp    9eec <fwp_write+0x88c>
    a142:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a148:	48 89 df             	mov    %rbx,%rdi
    a14b:	ba 02 00 00 00       	mov    $0x2,%edx
    a150:	48 8d 35 74 50 00 00 	lea    0x5074(%rip),%rsi        # f1cb <_IO_stdin_used+0x1cb>
    a157:	e8 14 9f ff ff       	call   4070 <buf_put>
    a15c:	4c 89 e8             	mov    %r13,%rax
    a15f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a164:	31 c9                	xor    %ecx,%ecx
    a166:	48 c1 e0 04          	shl    $0x4,%rax
    a16a:	48 89 df             	mov    %rbx,%rdi
    a16d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a172:	e8 e9 f4 ff ff       	call   9660 <fwp_write>
    a177:	e9 5e f6 ff ff       	jmp    97da <fwp_write+0x17a>
    a17c:	0f 1f 40 00          	nopl   0x0(%rax)
    a180:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a185:	48 85 ff             	test   %rdi,%rdi
    a188:	79 0c                	jns    a196 <fwp_write+0xb36>
    a18a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a191:	00 
    a192:	48 03 75 10          	add    0x10(%rbp),%rsi
    a196:	48 63 3e             	movslq (%rsi),%rdi
    a199:	83 f9 02             	cmp    $0x2,%ecx
    a19c:	89 fe                	mov    %edi,%esi
    a19e:	48 0f 44 f7          	cmove  %rdi,%rsi
    a1a2:	e9 f9 fb ff ff       	jmp    9da0 <fwp_write+0x740>
    a1a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a1ae:	00 00 
    a1b0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a1b5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a1ba:	48 85 ff             	test   %rdi,%rdi
    a1bd:	0f 88 0f 03 00 00    	js     a4d2 <fwp_write+0xe72>
    a1c3:	49 0f bf 38          	movswq (%r8),%rdi
    a1c7:	83 f9 01             	cmp    $0x1,%ecx
    a1ca:	0f b7 f7             	movzwl %di,%esi
    a1cd:	48 0f 44 f7          	cmove  %rdi,%rsi
    a1d1:	e9 ca fb ff ff       	jmp    9da0 <fwp_write+0x740>
    a1d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a1dd:	00 00 00 
    a1e0:	ba 01 00 00 00       	mov    $0x1,%edx
    a1e5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a1ea:	48 83 c5 08          	add    $0x8,%rbp
    a1ee:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a1f3:	e8 78 9e ff ff       	call   4070 <buf_put>
    a1f8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a1fd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a202:	4d 85 ed             	test   %r13,%r13
    a205:	75 46                	jne    a24d <fwp_write+0xbed>
    a207:	e9 04 01 00 00       	jmp    a310 <fwp_write+0xcb0>
    a20c:	0f 1f 40 00          	nopl   0x0(%rax)
    a210:	41 80 f9 09          	cmp    $0x9,%r9b
    a214:	0f 84 d6 00 00 00    	je     a2f0 <fwp_write+0xc90>
    a21a:	41 80 f9 0a          	cmp    $0xa,%r9b
    a21e:	0f 85 9c 00 00 00    	jne    a2c0 <fwp_write+0xc60>
    a224:	ba 02 00 00 00       	mov    $0x2,%edx
    a229:	48 8d 35 77 4f 00 00 	lea    0x4f77(%rip),%rsi        # f1a7 <_IO_stdin_used+0x1a7>
    a230:	48 89 df             	mov    %rbx,%rdi
    a233:	e8 38 9e ff ff       	call   4070 <buf_put>
    a238:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a23f:	00 
    a240:	48 83 c5 01          	add    $0x1,%rbp
    a244:	49 39 ec             	cmp    %rbp,%r12
    a247:	0f 84 c3 00 00 00    	je     a310 <fwp_write+0xcb0>
    a24d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a252:	41 80 f9 0d          	cmp    $0xd,%r9b
    a256:	74 28                	je     a280 <fwp_write+0xc20>
    a258:	7e b6                	jle    a210 <fwp_write+0xbb0>
    a25a:	41 80 f9 22          	cmp    $0x22,%r9b
    a25e:	74 40                	je     a2a0 <fwp_write+0xc40>
    a260:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a264:	75 5a                	jne    a2c0 <fwp_write+0xc60>
    a266:	ba 02 00 00 00       	mov    $0x2,%edx
    a26b:	48 8d 35 32 4f 00 00 	lea    0x4f32(%rip),%rsi        # f1a4 <_IO_stdin_used+0x1a4>
    a272:	48 89 df             	mov    %rbx,%rdi
    a275:	e8 f6 9d ff ff       	call   4070 <buf_put>
    a27a:	eb c4                	jmp    a240 <fwp_write+0xbe0>
    a27c:	0f 1f 40 00          	nopl   0x0(%rax)
    a280:	ba 02 00 00 00       	mov    $0x2,%edx
    a285:	48 8d 35 21 4f 00 00 	lea    0x4f21(%rip),%rsi        # f1ad <_IO_stdin_used+0x1ad>
    a28c:	48 89 df             	mov    %rbx,%rdi
    a28f:	e8 dc 9d ff ff       	call   4070 <buf_put>
    a294:	eb aa                	jmp    a240 <fwp_write+0xbe0>
    a296:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a29d:	00 00 00 
    a2a0:	ba 02 00 00 00       	mov    $0x2,%edx
    a2a5:	48 8d 35 f5 4e 00 00 	lea    0x4ef5(%rip),%rsi        # f1a1 <_IO_stdin_used+0x1a1>
    a2ac:	48 89 df             	mov    %rbx,%rdi
    a2af:	e8 bc 9d ff ff       	call   4070 <buf_put>
    a2b4:	eb 8a                	jmp    a240 <fwp_write+0xbe0>
    a2b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a2bd:	00 00 00 
    a2c0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a2c4:	0f 86 2e 01 00 00    	jbe    a3f8 <fwp_write+0xd98>
    a2ca:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a2ce:	0f 84 24 01 00 00    	je     a3f8 <fwp_write+0xd98>
    a2d4:	ba 01 00 00 00       	mov    $0x1,%edx
    a2d9:	4c 89 fe             	mov    %r15,%rsi
    a2dc:	48 89 df             	mov    %rbx,%rdi
    a2df:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a2e4:	e8 87 9d ff ff       	call   4070 <buf_put>
    a2e9:	e9 52 ff ff ff       	jmp    a240 <fwp_write+0xbe0>
    a2ee:	66 90                	xchg   %ax,%ax
    a2f0:	ba 02 00 00 00       	mov    $0x2,%edx
    a2f5:	48 8d 35 ae 4e 00 00 	lea    0x4eae(%rip),%rsi        # f1aa <_IO_stdin_used+0x1aa>
    a2fc:	48 89 df             	mov    %rbx,%rdi
    a2ff:	e8 6c 9d ff ff       	call   4070 <buf_put>
    a304:	e9 37 ff ff ff       	jmp    a240 <fwp_write+0xbe0>
    a309:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a310:	ba 01 00 00 00       	mov    $0x1,%edx
    a315:	4c 89 fe             	mov    %r15,%rsi
    a318:	48 89 df             	mov    %rbx,%rdi
    a31b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a320:	e8 4b 9d ff ff       	call   4070 <buf_put>
    a325:	e9 cc f3 ff ff       	jmp    96f6 <fwp_write+0x96>
    a32a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a330:	83 f8 04             	cmp    $0x4,%eax
    a333:	0f 85 bb fb ff ff    	jne    9ef4 <fwp_write+0x894>
    a339:	48 8b 04 24          	mov    (%rsp),%rax
    a33d:	48 8b 40 08          	mov    0x8(%rax),%rax
    a341:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    a346:	48 c1 e8 3f          	shr    $0x3f,%rax
    a34a:	e9 96 fc ff ff       	jmp    9fe5 <fwp_write+0x985>
    a34f:	90                   	nop
    a350:	8b 0c 24             	mov    (%rsp),%ecx
    a353:	31 c0                	xor    %eax,%eax
    a355:	85 c9                	test   %ecx,%ecx
    a357:	0f 98 c0             	sets   %al
    a35a:	e9 86 fc ff ff       	jmp    9fe5 <fwp_write+0x985>
    a35f:	90                   	nop
    a360:	48 f7 d8             	neg    %rax
    a363:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    a36a:	00 
    a36b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    a372:	2d 
    a373:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a37a:	00 
    a37b:	48 83 d2 00          	adc    $0x0,%rdx
    a37f:	48 89 c6             	mov    %rax,%rsi
    a382:	48 f7 da             	neg    %rdx
    a385:	e8 b6 96 ff ff       	call   3a40 <fwp_fmt_u128>
    a38a:	e9 51 f3 ff ff       	jmp    96e0 <fwp_write+0x80>
    a38f:	90                   	nop
    a390:	b8 7d 00 00 00       	mov    $0x7d,%eax
    a395:	e9 c3 f5 ff ff       	jmp    995d <fwp_write+0x2fd>
    a39a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a3a0:	4c 89 e9             	mov    %r13,%rcx
    a3a3:	48 c1 e1 04          	shl    $0x4,%rcx
    a3a7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    a3ac:	48 85 ff             	test   %rdi,%rdi
    a3af:	0f 89 eb f9 ff ff    	jns    9da0 <fwp_write+0x740>
    a3b5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a3b9:	48 89 ce             	mov    %rcx,%rsi
    a3bc:	e9 df f9 ff ff       	jmp    9da0 <fwp_write+0x740>
    a3c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a3c8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a3cf:	00 
    a3d0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a3d4:	e9 20 fa ff ff       	jmp    9df9 <fwp_write+0x799>
    a3d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a3e0:	ba 02 00 00 00       	mov    $0x2,%edx
    a3e5:	48 8d 35 80 4d 00 00 	lea    0x4d80(%rip),%rsi        # f16c <_IO_stdin_used+0x16c>
    a3ec:	e9 2d f7 ff ff       	jmp    9b1e <fwp_write+0x4be>
    a3f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a3f8:	4c 8d 05 b1 4d 00 00 	lea    0x4db1(%rip),%r8        # f1b0 <_IO_stdin_used+0x1b0>
    a3ff:	b9 10 00 00 00       	mov    $0x10,%ecx
    a404:	31 c0                	xor    %eax,%eax
    a406:	ba 02 00 00 00       	mov    $0x2,%edx
    a40b:	be 10 00 00 00       	mov    $0x10,%esi
    a410:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a417:	00 
    a418:	e8 93 8f ff ff       	call   33b0 <__snprintf_chk@plt>
    a41d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a424:	00 
    a425:	e8 26 90 ff ff       	call   3450 <strlen@plt>
    a42a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a431:	00 
    a432:	48 89 df             	mov    %rbx,%rdi
    a435:	48 89 c2             	mov    %rax,%rdx
    a438:	e8 33 9c ff ff       	call   4070 <buf_put>
    a43d:	e9 fe fd ff ff       	jmp    a240 <fwp_write+0xbe0>
    a442:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a448:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a44c:	48 8d 35 13 4d 00 00 	lea    0x4d13(%rip),%rsi        # f166 <_IO_stdin_used+0x166>
    a453:	48 8d 05 0b 4d 00 00 	lea    0x4d0b(%rip),%rax        # f165 <_IO_stdin_used+0x165>
    a45a:	4c 89 e7             	mov    %r12,%rdi
    a45d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    a461:	48 0f 46 f0          	cmovbe %rax,%rsi
    a465:	e8 86 8f ff ff       	call   33f0 <strcpy@plt>
    a46a:	e9 71 f2 ff ff       	jmp    96e0 <fwp_write+0x80>
    a46f:	90                   	nop
    a470:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a474:	48 8d 35 eb 4c 00 00 	lea    0x4ceb(%rip),%rsi        # f166 <_IO_stdin_used+0x166>
    a47b:	48 8d 05 e3 4c 00 00 	lea    0x4ce3(%rip),%rax        # f165 <_IO_stdin_used+0x165>
    a482:	0f 2f c8             	comiss %xmm0,%xmm1
    a485:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a48c:	00 
    a48d:	4c 89 e7             	mov    %r12,%rdi
    a490:	48 0f 46 f0          	cmovbe %rax,%rsi
    a494:	e8 57 8f ff ff       	call   33f0 <strcpy@plt>
    a499:	e9 42 f2 ff ff       	jmp    96e0 <fwp_write+0x80>
    a49e:	66 90                	xchg   %ax,%ax
    a4a0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    a4a5:	45 85 c0             	test   %r8d,%r8d
    a4a8:	75 34                	jne    a4de <fwp_write+0xe7e>
    a4aa:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a4b1:	00 
    a4b2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a4b9:	00 00 
    a4bb:	0f 85 74 f6 ff ff    	jne    9b35 <fwp_write+0x4d5>
    a4c1:	ba 02 00 00 00       	mov    $0x2,%edx
    a4c6:	48 8d 35 14 4d 00 00 	lea    0x4d14(%rip),%rsi        # f1e1 <_IO_stdin_used+0x1e1>
    a4cd:	e9 a1 f3 ff ff       	jmp    9873 <fwp_write+0x213>
    a4d2:	48 03 75 10          	add    0x10(%rbp),%rsi
    a4d6:	49 89 f0             	mov    %rsi,%r8
    a4d9:	e9 e5 fc ff ff       	jmp    a1c3 <fwp_write+0xb63>
    a4de:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    a4e3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a4e8:	85 ff                	test   %edi,%edi
    a4ea:	0f 84 fa f3 ff ff    	je     98ea <fwp_write+0x28a>
    a4f0:	ba 01 00 00 00       	mov    $0x1,%edx
    a4f5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a4fa:	48 89 df             	mov    %rbx,%rdi
    a4fd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a502:	e8 69 9b ff ff       	call   4070 <buf_put>
    a507:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    a50c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a511:	41 be 01 00 00 00    	mov    $0x1,%r14d
    a517:	85 c0                	test   %eax,%eax
    a519:	0f 8f f0 f3 ff ff    	jg     990f <fwp_write+0x2af>
    a51f:	e9 34 f4 ff ff       	jmp    9958 <fwp_write+0x2f8>
    a524:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a528:	49 89 c5             	mov    %rax,%r13
    a52b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a530:	49 89 c4             	mov    %rax,%r12
    a533:	49 c1 fd 3f          	sar    $0x3f,%r13
    a537:	4c 09 e8             	or     %r13,%rax
    a53a:	0f 84 a7 00 00 00    	je     a5e7 <fwp_write+0xf87>
    a540:	48 8d 2d d9 6e 00 00 	lea    0x6ed9(%rip),%rbp        # 11420 <units.5>
    a547:	4d 89 e7             	mov    %r12,%r15
    a54a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a54e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    a553:	4c 89 ff             	mov    %r15,%rdi
    a556:	4c 89 ee             	mov    %r13,%rsi
    a559:	44 89 0c 24          	mov    %r9d,(%rsp)
    a55d:	48 99                	cqto
    a55f:	48 89 d1             	mov    %rdx,%rcx
    a562:	48 89 c2             	mov    %rax,%rdx
    a565:	e8 96 41 00 00       	call   e700 <__divmodti4>
    a56a:	44 8b 0c 24          	mov    (%rsp),%r9d
    a56e:	48 89 c1             	mov    %rax,%rcx
    a571:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a576:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    a57b:	0f 84 94 00 00 00    	je     a615 <fwp_write+0xfb5>
    a581:	41 83 c1 01          	add    $0x1,%r9d
    a585:	48 83 c5 10          	add    $0x10,%rbp
    a589:	41 83 f9 05          	cmp    $0x5,%r9d
    a58d:	75 bb                	jne    a54a <fwp_write+0xeea>
    a58f:	4d 85 ed             	test   %r13,%r13
    a592:	79 53                	jns    a5e7 <fwp_write+0xf87>
    a594:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a599:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a59e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a5a3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a5a8:	48 99                	cqto
    a5aa:	48 f7 d8             	neg    %rax
    a5ad:	48 83 d2 00          	adc    $0x0,%rdx
    a5b1:	48 89 c6             	mov    %rax,%rsi
    a5b4:	48 f7 da             	neg    %rdx
    a5b7:	e8 84 94 ff ff       	call   3a40 <fwp_fmt_u128>
    a5bc:	49 89 e8             	mov    %rbp,%r8
    a5bf:	ba 00 02 00 00       	mov    $0x200,%edx
    a5c4:	be 02 00 00 00       	mov    $0x2,%esi
    a5c9:	31 c0                	xor    %eax,%eax
    a5cb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a5d2:	00 
    a5d3:	48 8d 0d 02 4c 00 00 	lea    0x4c02(%rip),%rcx        # f1dc <_IO_stdin_used+0x1dc>
    a5da:	4c 89 e7             	mov    %r12,%rdi
    a5dd:	e8 fe 90 ff ff       	call   36e0 <__sprintf_chk@plt>
    a5e2:	e9 f9 f0 ff ff       	jmp    96e0 <fwp_write+0x80>
    a5e7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a5ec:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a5f1:	31 d2                	xor    %edx,%edx
    a5f3:	48 89 ef             	mov    %rbp,%rdi
    a5f6:	e8 45 94 ff ff       	call   3a40 <fwp_fmt_u128>
    a5fb:	eb bf                	jmp    a5bc <fwp_write+0xf5c>
    a5fd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    a604:	4e 61 4e 00 
    a608:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a60f:	00 
    a610:	e9 cb f0 ff ff       	jmp    96e0 <fwp_write+0x80>
    a615:	44 89 0c 24          	mov    %r9d,(%rsp)
    a619:	48 89 c8             	mov    %rcx,%rax
    a61c:	48 85 d2             	test   %rdx,%rdx
    a61f:	78 51                	js     a672 <fwp_write+0x1012>
    a621:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a626:	48 89 c6             	mov    %rax,%rsi
    a629:	48 89 ef             	mov    %rbp,%rdi
    a62c:	e8 0f 94 ff ff       	call   3a40 <fwp_fmt_u128>
    a631:	44 8b 0c 24          	mov    (%rsp),%r9d
    a635:	49 63 c1             	movslq %r9d,%rax
    a638:	49 89 e8             	mov    %rbp,%r8
    a63b:	ba 00 02 00 00       	mov    $0x200,%edx
    a640:	be 02 00 00 00       	mov    $0x2,%esi
    a645:	48 c1 e0 04          	shl    $0x4,%rax
    a649:	48 8d 3d d0 6d 00 00 	lea    0x6dd0(%rip),%rdi        # 11420 <units.5>
    a650:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a657:	00 
    a658:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    a65c:	48 8d 0d 74 4b 00 00 	lea    0x4b74(%rip),%rcx        # f1d7 <_IO_stdin_used+0x1d7>
    a663:	4c 89 e7             	mov    %r12,%rdi
    a666:	31 c0                	xor    %eax,%eax
    a668:	e8 73 90 ff ff       	call   36e0 <__sprintf_chk@plt>
    a66d:	e9 6e f0 ff ff       	jmp    96e0 <fwp_write+0x80>
    a672:	48 f7 d8             	neg    %rax
    a675:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a67a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a67f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a684:	48 83 d2 00          	adc    $0x0,%rdx
    a688:	48 89 c6             	mov    %rax,%rsi
    a68b:	48 f7 da             	neg    %rdx
    a68e:	e8 ad 93 ff ff       	call   3a40 <fwp_fmt_u128>
    a693:	44 8b 0c 24          	mov    (%rsp),%r9d
    a697:	eb 9c                	jmp    a635 <fwp_write+0xfd5>
    a699:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000a6a0 <fwp_hof0.constprop.0>:
    a6a0:	55                   	push   %rbp
    a6a1:	48 89 e5             	mov    %rsp,%rbp
    a6a4:	41 57                	push   %r15
    a6a6:	41 56                	push   %r14
    a6a8:	41 55                	push   %r13
    a6aa:	41 54                	push   %r12
    a6ac:	53                   	push   %rbx
    a6ad:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    a6b4:	48 89 bd 58 ff ff ff 	mov    %rdi,-0xa8(%rbp)
    a6bb:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    a6c2:	00 00 
    a6c4:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    a6c8:	31 c0                	xor    %eax,%eax
    a6ca:	48 85 f6             	test   %rsi,%rsi
    a6cd:	0f 84 86 06 00 00    	je     ad59 <fwp_hof0.constprop.0+0x6b9>
    a6d3:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
    a6d7:	49 89 f7             	mov    %rsi,%r15
    a6da:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
    a6e1:	48 8d 35 b8 90 01 00 	lea    0x190b8(%rip),%rsi        # 237a0 <fwp_heap>
    a6e8:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    a6ef:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    a6f6:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    a6fd:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    a701:	48 c1 e2 10          	shl    $0x10,%rdx
    a705:	48 39 d0             	cmp    %rdx,%rax
    a708:	73 5d                	jae    a767 <fwp_hof0.constprop.0+0xc7>
    a70a:	48 89 c2             	mov    %rax,%rdx
    a70d:	48 c1 ea 10          	shr    $0x10,%rdx
    a711:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a715:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    a71c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a720:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a724:	48 85 ff             	test   %rdi,%rdi
    a727:	74 3e                	je     a767 <fwp_hof0.constprop.0+0xc7>
    a729:	0f b6 0a             	movzbl (%rdx),%ecx
    a72c:	80 f9 02             	cmp    $0x2,%cl
    a72f:	0f 84 cd 0a 00 00    	je     b202 <fwp_hof0.constprop.0+0xb62>
    a735:	80 f9 01             	cmp    $0x1,%cl
    a738:	75 2d                	jne    a767 <fwp_hof0.constprop.0+0xc7>
    a73a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a73d:	0f b7 c0             	movzwl %ax,%eax
    a740:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a743:	48 0f af c1          	imul   %rcx,%rax
    a747:	48 c1 e8 20          	shr    $0x20,%rax
    a74b:	48 39 d0             	cmp    %rdx,%rax
    a74e:	73 17                	jae    a767 <fwp_hof0.constprop.0+0xc7>
    a750:	48 01 c7             	add    %rax,%rdi
    a753:	0f b6 07             	movzbl (%rdi),%eax
    a756:	84 c0                	test   %al,%al
    a758:	74 0d                	je     a767 <fwp_hof0.constprop.0+0xc7>
    a75a:	3c fd                	cmp    $0xfd,%al
    a75c:	0f 87 7e 0b 00 00    	ja     b2e0 <fwp_hof0.constprop.0+0xc40>
    a762:	83 c0 01             	add    $0x1,%eax
    a765:	88 07                	mov    %al,(%rdi)
    a767:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    a76e:	4c 89 bd 50 ff ff ff 	mov    %r15,-0xb0(%rbp)
    a775:	48 c7 85 60 ff ff ff 	movq   $0xc7,-0xa0(%rbp)
    a77c:	c7 00 00 00 
    a780:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    a784:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    a788:	48 8b 15 69 ac 01 00 	mov    0x1ac69(%rip),%rdx        # 253f8 <fwp_fns>
    a78f:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
    a793:	48 8d 05 7e 88 00 00 	lea    0x887e(%rip),%rax        # 13018 <fc12>
    a79a:	44 8b 20             	mov    (%rax),%r12d
    a79d:	49 c1 e4 05          	shl    $0x5,%r12
    a7a1:	49 01 d4             	add    %rdx,%r12
    a7a4:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
    a7a9:	48 85 c9             	test   %rcx,%rcx
    a7ac:	0f 84 1d 0a 00 00    	je     b1cf <fwp_hof0.constprop.0+0xb2f>
    a7b2:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    a7b7:	0f 84 7b 08 00 00    	je     b038 <fwp_hof0.constprop.0+0x998>
    a7bd:	48 8d 3d dc 8f 01 00 	lea    0x18fdc(%rip),%rdi        # 237a0 <fwp_heap>
    a7c4:	48 8d 05 4d 88 00 00 	lea    0x884d(%rip),%rax        # 13018 <fc12>
    a7cb:	48 8b b7 d8 13 00 00 	mov    0x13d8(%rdi),%rsi
    a7d2:	48 2b 87 b0 13 00 00 	sub    0x13b0(%rdi),%rax
    a7d9:	48 89 f1             	mov    %rsi,%rcx
    a7dc:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
    a7e0:	48 c1 e1 10          	shl    $0x10,%rcx
    a7e4:	48 39 c8             	cmp    %rcx,%rax
    a7e7:	73 5f                	jae    a848 <fwp_hof0.constprop.0+0x1a8>
    a7e9:	48 89 c1             	mov    %rax,%rcx
    a7ec:	48 c1 e9 10          	shr    $0x10,%rcx
    a7f0:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    a7f4:	48 8b 8f f8 13 00 00 	mov    0x13f8(%rdi),%rcx
    a7fb:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    a7ff:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    a803:	48 85 ff             	test   %rdi,%rdi
    a806:	74 40                	je     a848 <fwp_hof0.constprop.0+0x1a8>
    a808:	0f b6 31             	movzbl (%rcx),%esi
    a80b:	40 80 fe 02          	cmp    $0x2,%sil
    a80f:	0f 84 08 09 00 00    	je     b11d <fwp_hof0.constprop.0+0xa7d>
    a815:	40 80 fe 01          	cmp    $0x1,%sil
    a819:	75 2d                	jne    a848 <fwp_hof0.constprop.0+0x1a8>
    a81b:	8b 71 18             	mov    0x18(%rcx),%esi
    a81e:	0f b7 c0             	movzwl %ax,%eax
    a821:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a824:	48 0f af c6          	imul   %rsi,%rax
    a828:	48 c1 e8 20          	shr    $0x20,%rax
    a82c:	48 39 c8             	cmp    %rcx,%rax
    a82f:	73 17                	jae    a848 <fwp_hof0.constprop.0+0x1a8>
    a831:	48 01 c7             	add    %rax,%rdi
    a834:	0f b6 07             	movzbl (%rdi),%eax
    a837:	84 c0                	test   %al,%al
    a839:	74 0d                	je     a848 <fwp_hof0.constprop.0+0x1a8>
    a83b:	3c fd                	cmp    $0xfd,%al
    a83d:	0f 87 66 09 00 00    	ja     b1a9 <fwp_hof0.constprop.0+0xb09>
    a843:	83 c0 01             	add    $0x1,%eax
    a846:	88 07                	mov    %al,(%rdi)
    a848:	48 8d 05 c9 87 00 00 	lea    0x87c9(%rip),%rax        # 13018 <fc12>
    a84f:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    a856:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    a85a:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    a861:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    a865:	48 8d 05 ac 87 00 00 	lea    0x87ac(%rip),%rax        # 13018 <fc12>
    a86c:	41 8b 0c 24          	mov    (%r12),%ecx
    a870:	2b 48 04             	sub    0x4(%rax),%ecx
    a873:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    a877:	44 8b 6d 94          	mov    -0x6c(%rbp),%r13d
    a87b:	89 4d 90             	mov    %ecx,-0x70(%rbp)
    a87e:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    a882:	49 89 c1             	mov    %rax,%r9
    a885:	8b 00                	mov    (%rax),%eax
    a887:	44 39 e9             	cmp    %r13d,%ecx
    a88a:	44 0f 46 e9          	cmovbe %ecx,%r13d
    a88e:	4d 89 cf             	mov    %r9,%r15
    a891:	48 c1 e0 05          	shl    $0x5,%rax
    a895:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    a899:	44 89 ad 7c ff ff ff 	mov    %r13d,-0x84(%rbp)
    a8a0:	4d 8b 50 18          	mov    0x18(%r8),%r10
    a8a4:	4d 85 d2             	test   %r10,%r10
    a8a7:	75 58                	jne    a901 <fwp_hof0.constprop.0+0x261>
    a8a9:	e9 f5 01 00 00       	jmp    aaa3 <fwp_hof0.constprop.0+0x403>
    a8ae:	66 90                	xchg   %ax,%ax
    a8b0:	45 85 ff             	test   %r15d,%r15d
    a8b3:	74 69                	je     a91e <fwp_hof0.constprop.0+0x27e>
    a8b5:	4c 89 e7             	mov    %r12,%rdi
    a8b8:	41 ff 12             	call   *(%r10)
    a8bb:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    a8bf:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
    a8c3:	e8 48 c3 ff ff       	call   6c10 <fwp_closure_drop>
    a8c8:	44 39 eb             	cmp    %r13d,%ebx
    a8cb:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    a8cf:	0f 84 53 07 00 00    	je     b028 <fwp_hof0.constprop.0+0x988>
    a8d5:	44 8b 00             	mov    (%rax),%r8d
    a8d8:	45 29 fe             	sub    %r15d,%r14d
    a8db:	4d 8d 24 dc          	lea    (%r12,%rbx,8),%r12
    a8df:	49 89 c1             	mov    %rax,%r9
    a8e2:	45 89 f5             	mov    %r14d,%r13d
    a8e5:	49 c1 e0 05          	shl    $0x5,%r8
    a8e9:	4c 03 05 08 ab 01 00 	add    0x1ab08(%rip),%r8        # 253f8 <fwp_fns>
    a8f0:	4d 8b 50 18          	mov    0x18(%r8),%r10
    a8f4:	4d 85 d2             	test   %r10,%r10
    a8f7:	0f 84 a3 01 00 00    	je     aaa0 <fwp_hof0.constprop.0+0x400>
    a8fd:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    a901:	41 8b 49 04          	mov    0x4(%r9),%ecx
    a905:	45 8b 38             	mov    (%r8),%r15d
    a908:	46 8d 34 29          	lea    (%rcx,%r13,1),%r14d
    a90c:	45 39 fe             	cmp    %r15d,%r14d
    a90f:	0f 82 6b 04 00 00    	jb     ad80 <fwp_hof0.constprop.0+0x6e0>
    a915:	44 89 fb             	mov    %r15d,%ebx
    a918:	29 cb                	sub    %ecx,%ebx
    a91a:	85 c9                	test   %ecx,%ecx
    a91c:	74 92                	je     a8b0 <fwp_hof0.constprop.0+0x210>
    a91e:	45 85 ff             	test   %r15d,%r15d
    a921:	b8 01 00 00 00       	mov    $0x1,%eax
    a926:	48 89 e6             	mov    %rsp,%rsi
    a929:	48 89 65 a0          	mov    %rsp,-0x60(%rbp)
    a92d:	41 0f 45 c7          	cmovne %r15d,%eax
    a931:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    a938:	00 
    a939:	48 c1 e8 04          	shr    $0x4,%rax
    a93d:	48 c1 e0 04          	shl    $0x4,%rax
    a941:	48 89 c7             	mov    %rax,%rdi
    a944:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    a94b:	48 29 fe             	sub    %rdi,%rsi
    a94e:	48 39 f4             	cmp    %rsi,%rsp
    a951:	74 15                	je     a968 <fwp_hof0.constprop.0+0x2c8>
    a953:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    a95a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    a961:	00 00 
    a963:	48 39 f4             	cmp    %rsi,%rsp
    a966:	75 eb                	jne    a953 <fwp_hof0.constprop.0+0x2b3>
    a968:	25 ff 0f 00 00       	and    $0xfff,%eax
    a96d:	48 29 c4             	sub    %rax,%rsp
    a970:	48 85 c0             	test   %rax,%rax
    a973:	74 06                	je     a97b <fwp_hof0.constprop.0+0x2db>
    a975:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    a97b:	89 cf                	mov    %ecx,%edi
    a97d:	49 89 e3             	mov    %rsp,%r11
    a980:	31 c0                	xor    %eax,%eax
    a982:	48 c1 e7 03          	shl    $0x3,%rdi
    a986:	85 c9                	test   %ecx,%ecx
    a988:	74 28                	je     a9b2 <fwp_hof0.constprop.0+0x312>
    a98a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a991:	00 00 00 00 
    a995:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a99c:	00 00 00 00 
    a9a0:	49 8b 54 01 08       	mov    0x8(%r9,%rax,1),%rdx
    a9a5:	49 89 14 03          	mov    %rdx,(%r11,%rax,1)
    a9a9:	48 83 c0 08          	add    $0x8,%rax
    a9ad:	48 39 c7             	cmp    %rax,%rdi
    a9b0:	75 ee                	jne    a9a0 <fwp_hof0.constprop.0+0x300>
    a9b2:	85 db                	test   %ebx,%ebx
    a9b4:	74 1f                	je     a9d5 <fwp_hof0.constprop.0+0x335>
    a9b6:	89 de                	mov    %ebx,%esi
    a9b8:	4c 89 e0             	mov    %r12,%rax
    a9bb:	49 8d 3c f4          	lea    (%r12,%rsi,8),%rdi
    a9bf:	90                   	nop
    a9c0:	48 8b 30             	mov    (%rax),%rsi
    a9c3:	89 ca                	mov    %ecx,%edx
    a9c5:	48 83 c0 08          	add    $0x8,%rax
    a9c9:	83 c1 01             	add    $0x1,%ecx
    a9cc:	49 89 34 d3          	mov    %rsi,(%r11,%rdx,8)
    a9d0:	48 39 c7             	cmp    %rax,%rdi
    a9d3:	75 eb                	jne    a9c0 <fwp_hof0.constprop.0+0x320>
    a9d5:	48 8d 15 c4 8d 01 00 	lea    0x18dc4(%rip),%rdx        # 237a0 <fwp_heap>
    a9dc:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    a9e0:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    a9e7:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    a9ee:	48 89 f1             	mov    %rsi,%rcx
    a9f1:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
    a9f5:	48 c1 e1 10          	shl    $0x10,%rcx
    a9f9:	48 39 c8             	cmp    %rcx,%rax
    a9fc:	73 4c                	jae    aa4a <fwp_hof0.constprop.0+0x3aa>
    a9fe:	48 89 c1             	mov    %rax,%rcx
    aa01:	48 c1 e9 10          	shr    $0x10,%rcx
    aa05:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    aa09:	48 8b 0d 88 a1 01 00 	mov    0x1a188(%rip),%rcx        # 24b98 <fwp_heap+0x13f8>
    aa10:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    aa14:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    aa18:	48 85 f6             	test   %rsi,%rsi
    aa1b:	74 2d                	je     aa4a <fwp_hof0.constprop.0+0x3aa>
    aa1d:	0f b6 39             	movzbl (%rcx),%edi
    aa20:	40 80 ff 02          	cmp    $0x2,%dil
    aa24:	74 6a                	je     aa90 <fwp_hof0.constprop.0+0x3f0>
    aa26:	40 80 ff 01          	cmp    $0x1,%dil
    aa2a:	75 1e                	jne    aa4a <fwp_hof0.constprop.0+0x3aa>
    aa2c:	8b 79 18             	mov    0x18(%rcx),%edi
    aa2f:	0f b7 c0             	movzwl %ax,%eax
    aa32:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    aa35:	48 0f af c7          	imul   %rdi,%rax
    aa39:	48 c1 e8 20          	shr    $0x20,%rax
    aa3d:	48 39 c8             	cmp    %rcx,%rax
    aa40:	73 08                	jae    aa4a <fwp_hof0.constprop.0+0x3aa>
    aa42:	48 01 c6             	add    %rax,%rsi
    aa45:	80 3e 01             	cmpb   $0x1,(%rsi)
    aa48:	74 36                	je     aa80 <fwp_hof0.constprop.0+0x3e0>
    aa4a:	4c 89 45 80          	mov    %r8,-0x80(%rbp)
    aa4e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    aa52:	be 01 00 00 00       	mov    $0x1,%esi
    aa57:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
    aa5b:	41 ff 52 08          	call   *0x8(%r10)
    aa5f:	4c 8b 5d 98          	mov    -0x68(%rbp),%r11
    aa63:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
    aa67:	49 8b 40 18          	mov    0x18(%r8),%rax
    aa6b:	4c 89 df             	mov    %r11,%rdi
    aa6e:	ff 10                	call   *(%rax)
    aa70:	48 8b 65 a0          	mov    -0x60(%rbp),%rsp
    aa74:	e9 42 fe ff ff       	jmp    a8bb <fwp_hof0.constprop.0+0x21b>
    aa79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa80:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    aa87:	00 
    aa88:	eb dd                	jmp    aa67 <fwp_hof0.constprop.0+0x3c7>
    aa8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aa90:	66 85 c0             	test   %ax,%ax
    aa93:	75 b5                	jne    aa4a <fwp_hof0.constprop.0+0x3aa>
    aa95:	eb ae                	jmp    aa45 <fwp_hof0.constprop.0+0x3a5>
    aa97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    aa9e:	00 00 
    aaa0:	49 89 c7             	mov    %rax,%r15
    aaa3:	4c 89 ff             	mov    %r15,%rdi
    aaa6:	e8 35 ba ff ff       	call   64e0 <fwp_rc_share>
    aaab:	45 85 ed             	test   %r13d,%r13d
    aaae:	74 21                	je     aad1 <fwp_hof0.constprop.0+0x431>
    aab0:	44 89 ea             	mov    %r13d,%edx
    aab3:	4c 89 e3             	mov    %r12,%rbx
    aab6:	4d 8d 34 d4          	lea    (%r12,%rdx,8),%r14
    aaba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aac0:	48 8b 3b             	mov    (%rbx),%rdi
    aac3:	48 83 c3 08          	add    $0x8,%rbx
    aac7:	e8 14 ba ff ff       	call   64e0 <fwp_rc_share>
    aacc:	4c 39 f3             	cmp    %r14,%rbx
    aacf:	75 ef                	jne    aac0 <fwp_hof0.constprop.0+0x420>
    aad1:	4c 89 e2             	mov    %r12,%rdx
    aad4:	44 89 ee             	mov    %r13d,%esi
    aad7:	4c 89 ff             	mov    %r15,%rdi
    aada:	e8 f1 b0 ff ff       	call   5bd0 <fwp_apply>
    aadf:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    aae3:	8b 75 94             	mov    -0x6c(%rbp),%esi
    aae6:	39 75 90             	cmp    %esi,-0x70(%rbp)
    aae9:	0f 83 87 00 00 00    	jae    ab76 <fwp_hof0.constprop.0+0x4d6>
    aaef:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    aaf5:	48 8b 7d 88          	mov    -0x78(%rbp),%rdi
    aaf9:	48 89 c2             	mov    %rax,%rdx
    aafc:	48 8d 04 c7          	lea    (%rdi,%rax,8),%rax
    ab00:	29 d6                	sub    %edx,%esi
    ab02:	48 8b 15 ef a8 01 00 	mov    0x1a8ef(%rip),%rdx        # 253f8 <fwp_fns>
    ab09:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    ab0d:	89 75 94             	mov    %esi,-0x6c(%rbp)
    ab10:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    ab14:	44 8b 26             	mov    (%rsi),%r12d
    ab17:	48 89 f0             	mov    %rsi,%rax
    ab1a:	49 c1 e4 05          	shl    $0x5,%r12
    ab1e:	49 01 d4             	add    %rdx,%r12
    ab21:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
    ab27:	0f 85 3f fd ff ff    	jne    a86c <fwp_hof0.constprop.0+0x1cc>
    ab2d:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ab31:	e8 aa b9 ff ff       	call   64e0 <fwp_rc_share>
    ab36:	44 8b 75 94          	mov    -0x6c(%rbp),%r14d
    ab3a:	45 85 f6             	test   %r14d,%r14d
    ab3d:	74 23                	je     ab62 <fwp_hof0.constprop.0+0x4c2>
    ab3f:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    ab43:	31 db                	xor    %ebx,%ebx
    ab45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ab4c:	00 00 00 00 
    ab50:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    ab54:	48 83 c3 01          	add    $0x1,%rbx
    ab58:	e8 83 b9 ff ff       	call   64e0 <fwp_rc_share>
    ab5d:	44 39 f3             	cmp    %r14d,%ebx
    ab60:	72 ee                	jb     ab50 <fwp_hof0.constprop.0+0x4b0>
    ab62:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    ab66:	8b 75 94             	mov    -0x6c(%rbp),%esi
    ab69:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ab6d:	e8 5e b0 ff ff       	call   5bd0 <fwp_apply>
    ab72:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    ab76:	48 83 ad 60 ff ff ff 	subq   $0x1,-0xa0(%rbp)
    ab7d:	01 
    ab7e:	0f 85 00 fc ff ff    	jne    a784 <fwp_hof0.constprop.0+0xe4>
    ab84:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    ab88:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    ab8f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ab93:	b9 01 00 00 00       	mov    $0x1,%ecx
    ab98:	48 8d 15 01 80 00 00 	lea    0x8001(%rip),%rdx        # 12ba0 <d0>
    ab9f:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
    aba6:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
    abad:	00 
    abae:	0f 29 45 b0          	movaps %xmm0,-0x50(%rbp)
    abb2:	e8 a9 ea ff ff       	call   9660 <fwp_write>
    abb7:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
    abbb:	4c 8b 75 b8          	mov    -0x48(%rbp),%r14
    abbf:	48 8d 05 68 44 00 00 	lea    0x4468(%rip),%rax        # f02e <_IO_stdin_used+0x2e>
    abc6:	48 85 c9             	test   %rcx,%rcx
    abc9:	48 0f 44 c8          	cmove  %rax,%rcx
    abcd:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    abd1:	0f 87 f5 06 00 00    	ja     b2cc <fwp_hof0.constprop.0+0xc2c>
    abd7:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    abdb:	be 01 00 00 00       	mov    $0x1,%esi
    abe0:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    abe4:	e8 c7 ae ff ff       	call   5ab0 <fwp_heap_alloc>
    abe9:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
    abed:	4c 89 f2             	mov    %r14,%rdx
    abf0:	4c 89 30             	mov    %r14,(%rax)
    abf3:	4c 8d 60 08          	lea    0x8(%rax),%r12
    abf7:	48 89 c3             	mov    %rax,%rbx
    abfa:	4c 89 e7             	mov    %r12,%rdi
    abfd:	e8 9e 89 ff ff       	call   35a0 <memcpy@plt>
    ac02:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    ac08:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
    ac0c:	e8 af 87 ff ff       	call   33c0 <free@plt>
    ac11:	48 8d 35 88 8b 01 00 	lea    0x18b88(%rip),%rsi        # 237a0 <fwp_heap>
    ac18:	48 89 d8             	mov    %rbx,%rax
    ac1b:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    ac22:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    ac29:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    ac2d:	48 c1 e2 10          	shl    $0x10,%rdx
    ac31:	48 39 d0             	cmp    %rdx,%rax
    ac34:	73 57                	jae    ac8d <fwp_hof0.constprop.0+0x5ed>
    ac36:	48 89 c2             	mov    %rax,%rdx
    ac39:	48 c1 ea 10          	shr    $0x10,%rdx
    ac3d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ac41:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    ac48:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ac4c:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    ac50:	4d 85 f6             	test   %r14,%r14
    ac53:	74 38                	je     ac8d <fwp_hof0.constprop.0+0x5ed>
    ac55:	0f b6 0a             	movzbl (%rdx),%ecx
    ac58:	80 f9 02             	cmp    $0x2,%cl
    ac5b:	0f 84 c9 05 00 00    	je     b22a <fwp_hof0.constprop.0+0xb8a>
    ac61:	80 f9 01             	cmp    $0x1,%cl
    ac64:	75 27                	jne    ac8d <fwp_hof0.constprop.0+0x5ed>
    ac66:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ac69:	0f b7 c0             	movzwl %ax,%eax
    ac6c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ac6f:	48 0f af c1          	imul   %rcx,%rax
    ac73:	48 c1 e8 20          	shr    $0x20,%rax
    ac77:	48 39 d0             	cmp    %rdx,%rax
    ac7a:	73 11                	jae    ac8d <fwp_hof0.constprop.0+0x5ed>
    ac7c:	49 01 c6             	add    %rax,%r14
    ac7f:	41 80 3e ff          	cmpb   $0xff,(%r14)
    ac83:	0f 84 67 06 00 00    	je     b2f0 <fwp_hof0.constprop.0+0xc50>
    ac89:	41 c6 06 01          	movb   $0x1,(%r14)
    ac8d:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ac91:	e8 8a bc ff ff       	call   6920 <fwp_drop0>
    ac96:	48 8b 13             	mov    (%rbx),%rdx
    ac99:	be 01 00 00 00       	mov    $0x1,%esi
    ac9e:	4c 89 e7             	mov    %r12,%rdi
    aca1:	48 8b 0d 58 a7 01 00 	mov    0x1a758(%rip),%rcx        # 25400 <fwp_prog_out>
    aca8:	e8 d3 89 ff ff       	call   3680 <fwrite@plt>
    acad:	48 8b 35 4c a7 01 00 	mov    0x1a74c(%rip),%rsi        # 25400 <fwp_prog_out>
    acb4:	bf 0a 00 00 00       	mov    $0xa,%edi
    acb9:	e8 22 88 ff ff       	call   34e0 <fputc@plt>
    acbe:	48 8d 35 db 8a 01 00 	lea    0x18adb(%rip),%rsi        # 237a0 <fwp_heap>
    acc5:	48 89 d8             	mov    %rbx,%rax
    acc8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    accf:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    acd6:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    acda:	48 c1 e2 10          	shl    $0x10,%rdx
    acde:	48 39 d0             	cmp    %rdx,%rax
    ace1:	73 69                	jae    ad4c <fwp_hof0.constprop.0+0x6ac>
    ace3:	48 89 c2             	mov    %rax,%rdx
    ace6:	48 c1 ea 10          	shr    $0x10,%rdx
    acea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    acee:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    acf5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    acf9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    acfd:	4d 85 e4             	test   %r12,%r12
    ad00:	74 4a                	je     ad4c <fwp_hof0.constprop.0+0x6ac>
    ad02:	0f b6 0a             	movzbl (%rdx),%ecx
    ad05:	80 f9 02             	cmp    $0x2,%cl
    ad08:	0f 84 2a 05 00 00    	je     b238 <fwp_hof0.constprop.0+0xb98>
    ad0e:	80 f9 01             	cmp    $0x1,%cl
    ad11:	75 39                	jne    ad4c <fwp_hof0.constprop.0+0x6ac>
    ad13:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ad16:	0f b7 c0             	movzwl %ax,%eax
    ad19:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ad1c:	48 0f af c1          	imul   %rcx,%rax
    ad20:	48 c1 e8 20          	shr    $0x20,%rax
    ad24:	48 39 d0             	cmp    %rdx,%rax
    ad27:	73 23                	jae    ad4c <fwp_hof0.constprop.0+0x6ac>
    ad29:	49 01 c4             	add    %rax,%r12
    ad2c:	41 0f b6 04 24       	movzbl (%r12),%eax
    ad31:	84 c0                	test   %al,%al
    ad33:	74 17                	je     ad4c <fwp_hof0.constprop.0+0x6ac>
    ad35:	3c 01                	cmp    $0x1,%al
    ad37:	0f 84 d3 04 00 00    	je     b210 <fwp_hof0.constprop.0+0xb70>
    ad3d:	3c ff                	cmp    $0xff,%al
    ad3f:	0f 84 01 05 00 00    	je     b246 <fwp_hof0.constprop.0+0xba6>
    ad45:	83 e8 01             	sub    $0x1,%eax
    ad48:	41 88 04 24          	mov    %al,(%r12)
    ad4c:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    ad50:	4d 85 ff             	test   %r15,%r15
    ad53:	0f 85 88 f9 ff ff    	jne    a6e1 <fwp_hof0.constprop.0+0x41>
    ad59:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    ad5d:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    ad64:	00 00 
    ad66:	0f 85 7e 05 00 00    	jne    b2ea <fwp_hof0.constprop.0+0xc4a>
    ad6c:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    ad70:	31 c0                	xor    %eax,%eax
    ad72:	5b                   	pop    %rbx
    ad73:	41 5c                	pop    %r12
    ad75:	41 5d                	pop    %r13
    ad77:	41 5e                	pop    %r14
    ad79:	41 5f                	pop    %r15
    ad7b:	5d                   	pop    %rbp
    ad7c:	c3                   	ret
    ad7d:	0f 1f 00             	nopl   (%rax)
    ad80:	48 8d 1d 19 8a 01 00 	lea    0x18a19(%rip),%rbx        # 237a0 <fwp_heap>
    ad87:	41 8d 76 01          	lea    0x1(%r14),%esi
    ad8b:	45 89 f7             	mov    %r14d,%r15d
    ad8e:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    ad94:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    ad9b:	00 
    ad9c:	85 c0                	test   %eax,%eax
    ad9e:	0f 84 a9 03 00 00    	je     b14d <fwp_hof0.constprop.0+0xaad>
    ada4:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    adab:	0f 87 9c 03 00 00    	ja     b14d <fwp_hof0.constprop.0+0xaad>
    adb1:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    adb5:	48 c1 e8 04          	shr    $0x4,%rax
    adb9:	0f b6 94 03 a0 0f 00 	movzbl 0xfa0(%rbx,%rax,1),%edx
    adc0:	00 
    adc1:	8b 84 93 00 0f 00 00 	mov    0xf00(%rbx,%rdx,4),%eax
    adc8:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    adcc:	48 8d 14 d3          	lea    (%rbx,%rdx,8),%rdx
    add0:	4c 8b 12             	mov    (%rdx),%r10
    add3:	4d 85 d2             	test   %r10,%r10
    add6:	0f 84 4f 03 00 00    	je     b12b <fwp_hof0.constprop.0+0xa8b>
    addc:	4d 8b 1a             	mov    (%r10),%r11
    addf:	49 f7 d3             	not    %r11
    ade2:	4c 89 1a             	mov    %r11,(%rdx)
    ade5:	48 39 c7             	cmp    %rax,%rdi
    ade8:	73 50                	jae    ae3a <fwp_hof0.constprop.0+0x79a>
    adea:	48 89 fa             	mov    %rdi,%rdx
    aded:	48 83 c7 08          	add    $0x8,%rdi
    adf1:	49 c7 04 f2 00 00 00 	movq   $0x0,(%r10,%rsi,8)
    adf8:	00 
    adf9:	48 f7 d2             	not    %rdx
    adfc:	48 01 c2             	add    %rax,%rdx
    adff:	48 c1 ea 03          	shr    $0x3,%rdx
    ae03:	48 39 c7             	cmp    %rax,%rdi
    ae06:	73 32                	jae    ae3a <fwp_hof0.constprop.0+0x79a>
    ae08:	83 e2 01             	and    $0x1,%edx
    ae0b:	74 13                	je     ae20 <fwp_hof0.constprop.0+0x780>
    ae0d:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    ae14:	00 
    ae15:	48 83 c7 08          	add    $0x8,%rdi
    ae19:	48 39 c7             	cmp    %rax,%rdi
    ae1c:	73 1c                	jae    ae3a <fwp_hof0.constprop.0+0x79a>
    ae1e:	66 90                	xchg   %ax,%ax
    ae20:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    ae27:	00 
    ae28:	49 c7 44 3a 08 00 00 	movq   $0x0,0x8(%r10,%rdi,1)
    ae2f:	00 00 
    ae31:	48 83 c7 10          	add    $0x10,%rdi
    ae35:	48 39 c7             	cmp    %rax,%rdi
    ae38:	72 e6                	jb     ae20 <fwp_hof0.constprop.0+0x780>
    ae3a:	48 8d 35 5f 89 01 00 	lea    0x1895f(%rip),%rsi        # 237a0 <fwp_heap>
    ae41:	48 89 c2             	mov    %rax,%rdx
    ae44:	48 03 96 20 14 00 00 	add    0x1420(%rsi),%rdx
    ae4b:	0f 82 6a 04 00 00    	jb     b2bb <fwp_hof0.constprop.0+0xc1b>
    ae51:	48 89 96 20 14 00 00 	mov    %rdx,0x1420(%rsi)
    ae58:	48 39 96 28 14 00 00 	cmp    %rdx,0x1428(%rsi)
    ae5f:	73 07                	jae    ae68 <fwp_hof0.constprop.0+0x7c8>
    ae61:	48 89 15 60 9d 01 00 	mov    %rdx,0x19d60(%rip)        # 24bc8 <fwp_heap+0x1428>
    ae68:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ae6c:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    ae71:	f2 0f 58 05 5f 9d 01 	addsd  0x19d5f(%rip),%xmm0        # 24bd8 <fwp_heap+0x1438>
    ae78:	00 
    ae79:	f2 0f 11 05 57 9d 01 	movsd  %xmm0,0x19d57(%rip)        # 24bd8 <fwp_heap+0x1438>
    ae80:	00 
    ae81:	66 41 0f 6e 01       	movd   (%r9),%xmm0
    ae86:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    ae8b:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    ae8f:	66 41 0f d6 02       	movq   %xmm0,(%r10)
    ae94:	85 c9                	test   %ecx,%ecx
    ae96:	74 37                	je     aecf <fwp_hof0.constprop.0+0x82f>
    ae98:	89 ca                	mov    %ecx,%edx
    ae9a:	49 8d 71 08          	lea    0x8(%r9),%rsi
    ae9e:	49 8d 7a 08          	lea    0x8(%r10),%rdi
    aea2:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    aea5:	48 c1 e2 03          	shl    $0x3,%rdx
    aea9:	4c 89 85 68 ff ff ff 	mov    %r8,-0x98(%rbp)
    aeb0:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
    aeb4:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    aeb8:	e8 53 87 ff ff       	call   3610 <memmove@plt>
    aebd:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    aec1:	4c 8b 4d 98          	mov    -0x68(%rbp),%r9
    aec5:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    aec8:	4c 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%r8
    aecf:	45 85 ed             	test   %r13d,%r13d
    aed2:	74 23                	je     aef7 <fwp_hof0.constprop.0+0x857>
    aed4:	45 89 ed             	mov    %r13d,%r13d
    aed7:	4b 8d 34 ec          	lea    (%r12,%r13,8),%rsi
    aedb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    aee0:	49 8b 14 24          	mov    (%r12),%rdx
    aee4:	89 c8                	mov    %ecx,%eax
    aee6:	49 83 c4 08          	add    $0x8,%r12
    aeea:	83 c1 01             	add    $0x1,%ecx
    aeed:	49 89 54 c2 08       	mov    %rdx,0x8(%r10,%rax,8)
    aef2:	4c 39 e6             	cmp    %r12,%rsi
    aef5:	75 e9                	jne    aee0 <fwp_hof0.constprop.0+0x840>
    aef7:	48 8d 35 a2 88 01 00 	lea    0x188a2(%rip),%rsi        # 237a0 <fwp_heap>
    aefe:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    af02:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    af09:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    af10:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    af14:	48 c1 e2 10          	shl    $0x10,%rdx
    af18:	48 39 d0             	cmp    %rdx,%rax
    af1b:	73 54                	jae    af71 <fwp_hof0.constprop.0+0x8d1>
    af1d:	48 89 c2             	mov    %rax,%rdx
    af20:	48 c1 ea 10          	shr    $0x10,%rdx
    af24:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    af28:	48 8b 15 69 9c 01 00 	mov    0x19c69(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    af2f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    af33:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    af37:	48 85 c9             	test   %rcx,%rcx
    af3a:	74 35                	je     af71 <fwp_hof0.constprop.0+0x8d1>
    af3c:	0f b6 32             	movzbl (%rdx),%esi
    af3f:	40 80 fe 02          	cmp    $0x2,%sil
    af43:	0f 84 52 02 00 00    	je     b19b <fwp_hof0.constprop.0+0xafb>
    af49:	40 80 fe 01          	cmp    $0x1,%sil
    af4d:	75 22                	jne    af71 <fwp_hof0.constprop.0+0x8d1>
    af4f:	8b 72 18             	mov    0x18(%rdx),%esi
    af52:	0f b7 c0             	movzwl %ax,%eax
    af55:	8b 52 1c             	mov    0x1c(%rdx),%edx
    af58:	48 0f af c6          	imul   %rsi,%rax
    af5c:	48 c1 e8 20          	shr    $0x20,%rax
    af60:	48 39 d0             	cmp    %rdx,%rax
    af63:	73 0c                	jae    af71 <fwp_hof0.constprop.0+0x8d1>
    af65:	48 01 c1             	add    %rax,%rcx
    af68:	80 39 01             	cmpb   $0x1,(%rcx)
    af6b:	0f 84 9f 01 00 00    	je     b110 <fwp_hof0.constprop.0+0xa70>
    af71:	49 8b 40 18          	mov    0x18(%r8),%rax
    af75:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    af79:	be 01 00 00 00       	mov    $0x1,%esi
    af7e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    af82:	ff 50 08             	call   *0x8(%rax)
    af85:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    af89:	48 8d 35 10 88 01 00 	lea    0x18810(%rip),%rsi        # 237a0 <fwp_heap>
    af90:	4c 89 d0             	mov    %r10,%rax
    af93:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    af9a:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    afa1:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    afa5:	48 c1 e2 10          	shl    $0x10,%rdx
    afa9:	48 39 d0             	cmp    %rdx,%rax
    afac:	73 59                	jae    b007 <fwp_hof0.constprop.0+0x967>
    afae:	48 89 c2             	mov    %rax,%rdx
    afb1:	48 c1 ea 10          	shr    $0x10,%rdx
    afb5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    afb9:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    afc0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    afc4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    afc8:	4d 85 e4             	test   %r12,%r12
    afcb:	74 3a                	je     b007 <fwp_hof0.constprop.0+0x967>
    afcd:	0f b6 0a             	movzbl (%rdx),%ecx
    afd0:	80 f9 02             	cmp    $0x2,%cl
    afd3:	0f 84 99 01 00 00    	je     b172 <fwp_hof0.constprop.0+0xad2>
    afd9:	80 f9 01             	cmp    $0x1,%cl
    afdc:	75 29                	jne    b007 <fwp_hof0.constprop.0+0x967>
    afde:	8b 4a 18             	mov    0x18(%rdx),%ecx
    afe1:	0f b7 c0             	movzwl %ax,%eax
    afe4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    afe7:	48 0f af c1          	imul   %rcx,%rax
    afeb:	48 c1 e8 20          	shr    $0x20,%rax
    afef:	48 39 d0             	cmp    %rdx,%rax
    aff2:	73 13                	jae    b007 <fwp_hof0.constprop.0+0x967>
    aff4:	49 01 c4             	add    %rax,%r12
    aff7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    affc:	0f 84 84 01 00 00    	je     b186 <fwp_hof0.constprop.0+0xae6>
    b002:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b007:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b00b:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b00f:	e8 fc bb ff ff       	call   6c10 <fwp_closure_drop>
    b014:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b018:	4c 89 55 a8          	mov    %r10,-0x58(%rbp)
    b01c:	e9 c2 fa ff ff       	jmp    aae3 <fwp_hof0.constprop.0+0x443>
    b021:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b028:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b02c:	e9 b2 fa ff ff       	jmp    aae3 <fwp_hof0.constprop.0+0x443>
    b031:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b038:	41 8b 34 24          	mov    (%r12),%esi
    b03c:	8b 05 da 7f 00 00    	mov    0x7fda(%rip),%eax        # 1301c <fc12+0x4>
    b042:	89 f7                	mov    %esi,%edi
    b044:	29 c7                	sub    %eax,%edi
    b046:	83 ff 01             	cmp    $0x1,%edi
    b049:	0f 85 6e f7 ff ff    	jne    a7bd <fwp_hof0.constprop.0+0x11d>
    b04f:	48 89 e3             	mov    %rsp,%rbx
    b052:	85 c0                	test   %eax,%eax
    b054:	0f 84 60 01 00 00    	je     b1ba <fwp_hof0.constprop.0+0xb1a>
    b05a:	89 f1                	mov    %esi,%ecx
    b05c:	ba 08 00 00 00       	mov    $0x8,%edx
    b061:	48 c1 e1 03          	shl    $0x3,%rcx
    b065:	85 f6                	test   %esi,%esi
    b067:	48 89 e6             	mov    %rsp,%rsi
    b06a:	48 0f 45 d1          	cmovne %rcx,%rdx
    b06e:	49 89 d7             	mov    %rdx,%r15
    b071:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    b075:	48 c1 ea 04          	shr    $0x4,%rdx
    b079:	48 c1 e2 04          	shl    $0x4,%rdx
    b07d:	48 89 d7             	mov    %rdx,%rdi
    b080:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    b087:	48 29 fe             	sub    %rdi,%rsi
    b08a:	48 39 f4             	cmp    %rsi,%rsp
    b08d:	74 15                	je     b0a4 <fwp_hof0.constprop.0+0xa04>
    b08f:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    b096:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    b09d:	00 00 
    b09f:	48 39 f4             	cmp    %rsi,%rsp
    b0a2:	75 eb                	jne    b08f <fwp_hof0.constprop.0+0x9ef>
    b0a4:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    b0aa:	48 29 d4             	sub    %rdx,%rsp
    b0ad:	48 85 d2             	test   %rdx,%rdx
    b0b0:	74 06                	je     b0b8 <fwp_hof0.constprop.0+0xa18>
    b0b2:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    b0b8:	4c 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%r14
    b0bf:	00 
    b0c0:	4c 89 f9             	mov    %r15,%rcx
    b0c3:	48 8d 35 56 7f 00 00 	lea    0x7f56(%rip),%rsi        # 13020 <fwp_epfd>
    b0ca:	48 89 e7             	mov    %rsp,%rdi
    b0cd:	4c 89 f2             	mov    %r14,%rdx
    b0d0:	e8 9b 84 ff ff       	call   3570 <__memcpy_chk@plt>
    b0d5:	4d 39 f7             	cmp    %r14,%r15
    b0d8:	4c 89 f9             	mov    %r15,%rcx
    b0db:	4a 8d 3c 34          	lea    (%rsp,%r14,1),%rdi
    b0df:	49 0f 42 ce          	cmovb  %r14,%rcx
    b0e3:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
    b0ea:	ba 08 00 00 00       	mov    $0x8,%edx
    b0ef:	4c 29 f1             	sub    %r14,%rcx
    b0f2:	e8 79 84 ff ff       	call   3570 <__memcpy_chk@plt>
    b0f7:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    b0fc:	48 89 e7             	mov    %rsp,%rdi
    b0ff:	ff 10                	call   *(%rax)
    b101:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b105:	e9 bd 00 00 00       	jmp    b1c7 <fwp_hof0.constprop.0+0xb27>
    b10a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b110:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    b117:	00 
    b118:	e9 6c fe ff ff       	jmp    af89 <fwp_hof0.constprop.0+0x8e9>
    b11d:	66 85 c0             	test   %ax,%ax
    b120:	0f 85 22 f7 ff ff    	jne    a848 <fwp_hof0.constprop.0+0x1a8>
    b126:	e9 09 f7 ff ff       	jmp    a834 <fwp_hof0.constprop.0+0x194>
    b12b:	4c 8b 52 08          	mov    0x8(%rdx),%r10
    b12f:	4d 85 d2             	test   %r10,%r10
    b132:	74 19                	je     b14d <fwp_hof0.constprop.0+0xaad>
    b134:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
    b138:	4d 29 d3             	sub    %r10,%r11
    b13b:	49 39 c3             	cmp    %rax,%r11
    b13e:	72 0d                	jb     b14d <fwp_hof0.constprop.0+0xaad>
    b140:	4d 8d 1c 02          	lea    (%r10,%rax,1),%r11
    b144:	4c 89 5a 08          	mov    %r11,0x8(%rdx)
    b148:	e9 98 fc ff ff       	jmp    ade5 <fwp_hof0.constprop.0+0x745>
    b14d:	31 f6                	xor    %esi,%esi
    b14f:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b152:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    b156:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    b15a:	e8 51 a9 ff ff       	call   5ab0 <fwp_heap_alloc>
    b15f:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b162:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    b166:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    b16a:	49 89 c2             	mov    %rax,%r10
    b16d:	e9 0f fd ff ff       	jmp    ae81 <fwp_hof0.constprop.0+0x7e1>
    b172:	66 85 c0             	test   %ax,%ax
    b175:	0f 85 8c fe ff ff    	jne    b007 <fwp_hof0.constprop.0+0x967>
    b17b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b180:	0f 85 7c fe ff ff    	jne    b002 <fwp_hof0.constprop.0+0x962>
    b186:	4c 89 e7             	mov    %r12,%rdi
    b189:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b18d:	e8 de a1 ff ff       	call   5370 <fwp_rc_forget_slot>
    b192:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b196:	e9 67 fe ff ff       	jmp    b002 <fwp_hof0.constprop.0+0x962>
    b19b:	66 85 c0             	test   %ax,%ax
    b19e:	0f 85 cd fd ff ff    	jne    af71 <fwp_hof0.constprop.0+0x8d1>
    b1a4:	e9 bf fd ff ff       	jmp    af68 <fwp_hof0.constprop.0+0x8c8>
    b1a9:	e8 a2 a0 ff ff       	call   5250 <fwp_rc_wide_dup>
    b1ae:	48 8b 15 43 a2 01 00 	mov    0x1a243(%rip),%rdx        # 253f8 <fwp_fns>
    b1b5:	e9 8e f6 ff ff       	jmp    a848 <fwp_hof0.constprop.0+0x1a8>
    b1ba:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    b1c1:	ff 11                	call   *(%rcx)
    b1c3:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b1c7:	48 89 dc             	mov    %rbx,%rsp
    b1ca:	e9 a7 f9 ff ff       	jmp    ab76 <fwp_hof0.constprop.0+0x4d6>
    b1cf:	48 89 c7             	mov    %rax,%rdi
    b1d2:	e8 09 b3 ff ff       	call   64e0 <fwp_rc_share>
    b1d7:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b1db:	e8 00 b3 ff ff       	call   64e0 <fwp_rc_share>
    b1e0:	48 8d 05 31 7e 00 00 	lea    0x7e31(%rip),%rax        # 13018 <fc12>
    b1e7:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    b1ee:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b1f2:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    b1f9:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b1fd:	e9 60 f9 ff ff       	jmp    ab62 <fwp_hof0.constprop.0+0x4c2>
    b202:	66 85 c0             	test   %ax,%ax
    b205:	0f 85 5c f5 ff ff    	jne    a767 <fwp_hof0.constprop.0+0xc7>
    b20b:	e9 43 f5 ff ff       	jmp    a753 <fwp_hof0.constprop.0+0xb3>
    b210:	48 89 df             	mov    %rbx,%rdi
    b213:	e8 f8 b3 ff ff       	call   6610 <fwp_rc_free_arr>
    b218:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    b21c:	4d 85 ff             	test   %r15,%r15
    b21f:	0f 85 bc f4 ff ff    	jne    a6e1 <fwp_hof0.constprop.0+0x41>
    b225:	e9 2f fb ff ff       	jmp    ad59 <fwp_hof0.constprop.0+0x6b9>
    b22a:	66 85 c0             	test   %ax,%ax
    b22d:	0f 85 5a fa ff ff    	jne    ac8d <fwp_hof0.constprop.0+0x5ed>
    b233:	e9 47 fa ff ff       	jmp    ac7f <fwp_hof0.constprop.0+0x5df>
    b238:	66 85 c0             	test   %ax,%ax
    b23b:	0f 85 0b fb ff ff    	jne    ad4c <fwp_hof0.constprop.0+0x6ac>
    b241:	e9 e6 fa ff ff       	jmp    ad2c <fwp_hof0.constprop.0+0x68c>
    b246:	4c 89 e0             	mov    %r12,%rax
    b249:	48 8d 35 50 85 01 00 	lea    0x18550(%rip),%rsi        # 237a0 <fwp_heap>
    b250:	48 c1 e8 11          	shr    $0x11,%rax
    b254:	4c 31 e0             	xor    %r12,%rax
    b257:	48 89 c2             	mov    %rax,%rdx
    b25a:	48 c1 ea 09          	shr    $0x9,%rdx
    b25e:	48 31 d0             	xor    %rdx,%rax
    b261:	0f b6 c0             	movzbl %al,%eax
    b264:	48 8b 94 c6 48 14 00 	mov    0x1448(%rsi,%rax,8),%rdx
    b26b:	00 
    b26c:	48 85 d2             	test   %rdx,%rdx
    b26f:	75 18                	jne    b289 <fwp_hof0.constprop.0+0xbe9>
    b271:	eb 4d                	jmp    b2c0 <fwp_hof0.constprop.0+0xc20>
    b273:	66 90                	xchg   %ax,%ax
    b275:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b27c:	00 00 00 00 
    b280:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b284:	48 85 d2             	test   %rdx,%rdx
    b287:	74 37                	je     b2c0 <fwp_hof0.constprop.0+0xc20>
    b289:	48 89 d0             	mov    %rdx,%rax
    b28c:	4c 39 22             	cmp    %r12,(%rdx)
    b28f:	75 ef                	jne    b280 <fwp_hof0.constprop.0+0xbe0>
    b291:	48 8b 42 08          	mov    0x8(%rdx),%rax
    b295:	48 83 e8 01          	sub    $0x1,%rax
    b299:	48 89 42 08          	mov    %rax,0x8(%rdx)
    b29d:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    b2a3:	0f 85 a3 fa ff ff    	jne    ad4c <fwp_hof0.constprop.0+0x6ac>
    b2a9:	4c 89 e7             	mov    %r12,%rdi
    b2ac:	e8 bf a0 ff ff       	call   5370 <fwp_rc_forget_slot>
    b2b1:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b2b6:	e9 91 fa ff ff       	jmp    ad4c <fwp_hof0.constprop.0+0x6ac>
    b2bb:	e8 f0 89 ff ff       	call   3cb0 <fwp_heap_oom>
    b2c0:	48 8d 3d d1 44 00 00 	lea    0x44d1(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    b2c7:	e8 d4 8e ff ff       	call   41a0 <fwp_trap>
    b2cc:	48 8d 3d 15 3f 00 00 	lea    0x3f15(%rip),%rdi        # f1e8 <_IO_stdin_used+0x1e8>
    b2d3:	e8 c8 8e ff ff       	call   41a0 <fwp_trap>
    b2d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b2df:	00 
    b2e0:	e8 6b 9f ff ff       	call   5250 <fwp_rc_wide_dup>
    b2e5:	e9 7d f4 ff ff       	jmp    a767 <fwp_hof0.constprop.0+0xc7>
    b2ea:	e8 71 81 ff ff       	call   3460 <__stack_chk_fail@plt>
    b2ef:	90                   	nop
    b2f0:	4c 89 f7             	mov    %r14,%rdi
    b2f3:	e8 78 a0 ff ff       	call   5370 <fwp_rc_forget_slot>
    b2f8:	e9 8c f9 ff ff       	jmp    ac89 <fwp_hof0.constprop.0+0x5e9>
    b2fd:	0f 1f 00             	nopl   (%rax)

000000000000b300 <f0>:
    b300:	41 56                	push   %r14
    b302:	4c 8d 35 97 84 01 00 	lea    0x18497(%rip),%r14        # 237a0 <fwp_heap>
    b309:	41 55                	push   %r13
    b30b:	41 54                	push   %r12
    b30d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    b313:	55                   	push   %rbp
    b314:	53                   	push   %rbx
    b315:	31 db                	xor    %ebx,%ebx
    b317:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    b31e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b325:	00 00 
    b327:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    b32e:	00 
    b32f:	31 c0                	xor    %eax,%eax
    b331:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    b338:	00 
    b339:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    b340:	00 00 
    b342:	66 48 0f 6e c0       	movq   %rax,%xmm0
    b347:	48 8d 05 62 b7 ff ff 	lea    -0x489e(%rip),%rax        # 6ab0 <fwp_drop1>
    b34e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    b353:	48 8b 05 de a0 01 00 	mov    0x1a0de(%rip),%rax        # 25438 <fwp_cleanups>
    b35a:	48 89 25 d7 a0 01 00 	mov    %rsp,0x1a0d7(%rip)        # 25438 <fwp_cleanups>
    b361:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    b365:	48 89 04 24          	mov    %rax,(%rsp)
    b369:	48 8d 05 60 88 ff ff 	lea    -0x77a0(%rip),%rax        # 3bd0 <fwp_range_release>
    b370:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b375:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    b37a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b37f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    b384:	eb 47                	jmp    b3cd <f0+0xcd>
    b386:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b38d:	00 00 00 
    b390:	80 f9 01             	cmp    $0x1,%cl
    b393:	75 29                	jne    b3be <f0+0xbe>
    b395:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b398:	0f b7 c0             	movzwl %ax,%eax
    b39b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b39e:	48 0f af c1          	imul   %rcx,%rax
    b3a2:	48 c1 e8 20          	shr    $0x20,%rax
    b3a6:	48 39 d0             	cmp    %rdx,%rax
    b3a9:	73 13                	jae    b3be <f0+0xbe>
    b3ab:	49 01 c5             	add    %rax,%r13
    b3ae:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b3b3:	0f 84 c7 27 00 00    	je     db80 <f0+0x2880>
    b3b9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b3be:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b3c3:	49 83 ec 01          	sub    $0x1,%r12
    b3c7:	0f 82 83 00 00 00    	jb     b450 <f0+0x150>
    b3cd:	48 89 ee             	mov    %rbp,%rsi
    b3d0:	bf 01 00 00 00       	mov    $0x1,%edi
    b3d5:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    b3dc:	00 
    b3dd:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    b3e2:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    b3e9:	00 
    b3ea:	e8 c1 af ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b3ef:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b3f6:	48 89 c3             	mov    %rax,%rbx
    b3f9:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b400:	48 c1 e2 10          	shl    $0x10,%rdx
    b404:	48 39 d0             	cmp    %rdx,%rax
    b407:	73 b5                	jae    b3be <f0+0xbe>
    b409:	48 89 c2             	mov    %rax,%rdx
    b40c:	48 c1 ea 10          	shr    $0x10,%rdx
    b410:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b414:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b41b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b41f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b423:	4d 85 ed             	test   %r13,%r13
    b426:	74 96                	je     b3be <f0+0xbe>
    b428:	0f b6 0a             	movzbl (%rdx),%ecx
    b42b:	80 f9 02             	cmp    $0x2,%cl
    b42e:	0f 85 5c ff ff ff    	jne    b390 <f0+0x90>
    b434:	66 85 c0             	test   %ax,%ax
    b437:	0f 84 71 ff ff ff    	je     b3ae <f0+0xae>
    b43d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b442:	49 83 ec 01          	sub    $0x1,%r12
    b446:	73 85                	jae    b3cd <f0+0xcd>
    b448:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b44f:	00 
    b450:	48 8b 04 24          	mov    (%rsp),%rax
    b454:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    b459:	bf 01 00 00 00       	mov    $0x1,%edi
    b45e:	66 0f 6f 05 ca 46 00 	movdqa 0x46ca(%rip),%xmm0        # fb30 <msg.8+0xb0>
    b465:	00 
    b466:	48 89 05 cb 9f 01 00 	mov    %rax,0x19fcb(%rip)        # 25438 <fwp_cleanups>
    b46d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b472:	e8 39 af ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b477:	48 8b 15 fa 96 01 00 	mov    0x196fa(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    b47e:	49 89 c5             	mov    %rax,%r13
    b481:	48 2b 05 c8 96 01 00 	sub    0x196c8(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    b488:	48 c1 e2 10          	shl    $0x10,%rdx
    b48c:	48 39 d0             	cmp    %rdx,%rax
    b48f:	73 59                	jae    b4ea <f0+0x1ea>
    b491:	48 89 c2             	mov    %rax,%rdx
    b494:	48 c1 ea 10          	shr    $0x10,%rdx
    b498:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b49c:	48 8b 15 f5 96 01 00 	mov    0x196f5(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    b4a3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b4a7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b4ab:	4d 85 e4             	test   %r12,%r12
    b4ae:	74 3a                	je     b4ea <f0+0x1ea>
    b4b0:	0f b6 0a             	movzbl (%rdx),%ecx
    b4b3:	80 f9 02             	cmp    $0x2,%cl
    b4b6:	0f 84 74 27 00 00    	je     dc30 <f0+0x2930>
    b4bc:	80 f9 01             	cmp    $0x1,%cl
    b4bf:	75 29                	jne    b4ea <f0+0x1ea>
    b4c1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b4c4:	0f b7 c0             	movzwl %ax,%eax
    b4c7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b4ca:	48 0f af c1          	imul   %rcx,%rax
    b4ce:	48 c1 e8 20          	shr    $0x20,%rax
    b4d2:	48 39 d0             	cmp    %rdx,%rax
    b4d5:	73 13                	jae    b4ea <f0+0x1ea>
    b4d7:	49 01 c4             	add    %rax,%r12
    b4da:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b4df:	0f 84 26 29 00 00    	je     de0b <f0+0x2b0b>
    b4e5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b4ea:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    b4ef:	bf 01 00 00 00       	mov    $0x1,%edi
    b4f4:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    b4f9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b500:	00 f0 3f 
    b503:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    b508:	e8 a3 ae ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b50d:	48 8b 15 64 96 01 00 	mov    0x19664(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    b514:	49 89 c5             	mov    %rax,%r13
    b517:	48 2b 05 32 96 01 00 	sub    0x19632(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    b51e:	48 c1 e2 10          	shl    $0x10,%rdx
    b522:	48 39 d0             	cmp    %rdx,%rax
    b525:	73 59                	jae    b580 <f0+0x280>
    b527:	48 89 c2             	mov    %rax,%rdx
    b52a:	48 c1 ea 10          	shr    $0x10,%rdx
    b52e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b532:	48 8b 15 5f 96 01 00 	mov    0x1965f(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    b539:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b53d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b541:	4d 85 e4             	test   %r12,%r12
    b544:	74 3a                	je     b580 <f0+0x280>
    b546:	0f b6 0a             	movzbl (%rdx),%ecx
    b549:	80 f9 02             	cmp    $0x2,%cl
    b54c:	0f 84 ce 26 00 00    	je     dc20 <f0+0x2920>
    b552:	80 f9 01             	cmp    $0x1,%cl
    b555:	75 29                	jne    b580 <f0+0x280>
    b557:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b55a:	0f b7 c0             	movzwl %ax,%eax
    b55d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b560:	48 0f af c1          	imul   %rcx,%rax
    b564:	48 c1 e8 20          	shr    $0x20,%rax
    b568:	48 39 d0             	cmp    %rdx,%rax
    b56b:	73 13                	jae    b580 <f0+0x280>
    b56d:	49 01 c4             	add    %rax,%r12
    b570:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b575:	0f 84 9d 28 00 00    	je     de18 <f0+0x2b18>
    b57b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b580:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b585:	bf 01 00 00 00       	mov    $0x1,%edi
    b58a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    b58f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b596:	33 f3 bf 
    b599:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b59e:	e8 0d ae ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b5a3:	48 8b 15 ce 95 01 00 	mov    0x195ce(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    b5aa:	49 89 c5             	mov    %rax,%r13
    b5ad:	48 2b 05 9c 95 01 00 	sub    0x1959c(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    b5b4:	48 c1 e2 10          	shl    $0x10,%rdx
    b5b8:	48 39 d0             	cmp    %rdx,%rax
    b5bb:	73 59                	jae    b616 <f0+0x316>
    b5bd:	48 89 c2             	mov    %rax,%rdx
    b5c0:	48 c1 ea 10          	shr    $0x10,%rdx
    b5c4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b5c8:	48 8b 15 c9 95 01 00 	mov    0x195c9(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    b5cf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b5d3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b5d7:	4d 85 e4             	test   %r12,%r12
    b5da:	74 3a                	je     b616 <f0+0x316>
    b5dc:	0f b6 0a             	movzbl (%rdx),%ecx
    b5df:	80 f9 02             	cmp    $0x2,%cl
    b5e2:	0f 84 28 26 00 00    	je     dc10 <f0+0x2910>
    b5e8:	80 f9 01             	cmp    $0x1,%cl
    b5eb:	75 29                	jne    b616 <f0+0x316>
    b5ed:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b5f0:	0f b7 c0             	movzwl %ax,%eax
    b5f3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b5f6:	48 0f af c1          	imul   %rcx,%rax
    b5fa:	48 c1 e8 20          	shr    $0x20,%rax
    b5fe:	48 39 d0             	cmp    %rdx,%rax
    b601:	73 13                	jae    b616 <f0+0x316>
    b603:	49 01 c4             	add    %rax,%r12
    b606:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b60b:	0f 84 14 28 00 00    	je     de25 <f0+0x2b25>
    b611:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b616:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b61b:	bf 01 00 00 00       	mov    $0x1,%edi
    b620:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    b625:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b62c:	00 f0 3f 
    b62f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b634:	e8 77 ad ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b639:	48 8b 15 38 95 01 00 	mov    0x19538(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    b640:	49 89 c5             	mov    %rax,%r13
    b643:	48 2b 05 06 95 01 00 	sub    0x19506(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    b64a:	48 c1 e2 10          	shl    $0x10,%rdx
    b64e:	48 39 d0             	cmp    %rdx,%rax
    b651:	73 59                	jae    b6ac <f0+0x3ac>
    b653:	48 89 c2             	mov    %rax,%rdx
    b656:	48 c1 ea 10          	shr    $0x10,%rdx
    b65a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b65e:	48 8b 15 33 95 01 00 	mov    0x19533(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    b665:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b669:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b66d:	4d 85 e4             	test   %r12,%r12
    b670:	74 3a                	je     b6ac <f0+0x3ac>
    b672:	0f b6 0a             	movzbl (%rdx),%ecx
    b675:	80 f9 02             	cmp    $0x2,%cl
    b678:	0f 84 f2 25 00 00    	je     dc70 <f0+0x2970>
    b67e:	80 f9 01             	cmp    $0x1,%cl
    b681:	75 29                	jne    b6ac <f0+0x3ac>
    b683:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b686:	0f b7 c0             	movzwl %ax,%eax
    b689:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b68c:	48 0f af c1          	imul   %rcx,%rax
    b690:	48 c1 e8 20          	shr    $0x20,%rax
    b694:	48 39 d0             	cmp    %rdx,%rax
    b697:	73 13                	jae    b6ac <f0+0x3ac>
    b699:	49 01 c4             	add    %rax,%r12
    b69c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b6a1:	0f 84 8b 27 00 00    	je     de32 <f0+0x2b32>
    b6a7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b6ac:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b6b3:	33 f3 bf 
    b6b6:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    b6bd:	00 
    b6be:	bf 01 00 00 00       	mov    $0x1,%edi
    b6c3:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    b6ca:	00 
    b6cb:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    b6d2:	00 
    b6d3:	e8 d8 ac ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b6d8:	48 8b 15 99 94 01 00 	mov    0x19499(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    b6df:	49 89 c5             	mov    %rax,%r13
    b6e2:	48 2b 05 67 94 01 00 	sub    0x19467(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    b6e9:	48 c1 e2 10          	shl    $0x10,%rdx
    b6ed:	48 39 d0             	cmp    %rdx,%rax
    b6f0:	73 59                	jae    b74b <f0+0x44b>
    b6f2:	48 89 c2             	mov    %rax,%rdx
    b6f5:	48 c1 ea 10          	shr    $0x10,%rdx
    b6f9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b6fd:	48 8b 15 94 94 01 00 	mov    0x19494(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    b704:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b708:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b70c:	4d 85 e4             	test   %r12,%r12
    b70f:	74 3a                	je     b74b <f0+0x44b>
    b711:	0f b6 0a             	movzbl (%rdx),%ecx
    b714:	80 f9 02             	cmp    $0x2,%cl
    b717:	0f 84 43 25 00 00    	je     dc60 <f0+0x2960>
    b71d:	80 f9 01             	cmp    $0x1,%cl
    b720:	75 29                	jne    b74b <f0+0x44b>
    b722:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b725:	0f b7 c0             	movzwl %ax,%eax
    b728:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b72b:	48 0f af c1          	imul   %rcx,%rax
    b72f:	48 c1 e8 20          	shr    $0x20,%rax
    b733:	48 39 d0             	cmp    %rdx,%rax
    b736:	73 13                	jae    b74b <f0+0x44b>
    b738:	49 01 c4             	add    %rax,%r12
    b73b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b740:	0f 84 f9 26 00 00    	je     de3f <f0+0x2b3f>
    b746:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b74b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    b752:	00 f0 3f 
    b755:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    b75c:	00 
    b75d:	bf 01 00 00 00       	mov    $0x1,%edi
    b762:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    b769:	00 
    b76a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    b771:	00 
    b772:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    b779:	33 f3 bf 
    b77c:	e8 2f ac ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b781:	48 89 c7             	mov    %rax,%rdi
    b784:	e8 d7 ad ff ff       	call   6560 <fwp_rc_fresh>
    b789:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    b790:	00 
    b791:	bf 01 00 00 00       	mov    $0x1,%edi
    b796:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    b79d:	00 
    b79e:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    b7a5:	00 
    b7a6:	e8 05 ac ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b7ab:	48 89 c7             	mov    %rax,%rdi
    b7ae:	e8 ad ad ff ff       	call   6560 <fwp_rc_fresh>
    b7b3:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    b7ba:	00 
    b7bb:	bf 01 00 00 00       	mov    $0x1,%edi
    b7c0:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    b7c7:	00 
    b7c8:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    b7cf:	00 
    b7d0:	e8 db ab ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b7d5:	48 89 c7             	mov    %rax,%rdi
    b7d8:	e8 83 ad ff ff       	call   6560 <fwp_rc_fresh>
    b7dd:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    b7e4:	00 
    b7e5:	bf 01 00 00 00       	mov    $0x1,%edi
    b7ea:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    b7f1:	00 
    b7f2:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    b7f9:	00 
    b7fa:	e8 b1 ab ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b7ff:	48 89 c7             	mov    %rax,%rdi
    b802:	e8 59 ad ff ff       	call   6560 <fwp_rc_fresh>
    b807:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    b80e:	00 
    b80f:	bf 01 00 00 00       	mov    $0x1,%edi
    b814:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    b81b:	00 
    b81c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    b823:	00 
    b824:	e8 87 ab ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b829:	48 89 c7             	mov    %rax,%rdi
    b82c:	e8 2f ad ff ff       	call   6560 <fwp_rc_fresh>
    b831:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    b838:	00 
    b839:	bf 01 00 00 00       	mov    $0x1,%edi
    b83e:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    b845:	00 
    b846:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    b84d:	00 
    b84e:	e8 5d ab ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b853:	48 89 c7             	mov    %rax,%rdi
    b856:	e8 05 ad ff ff       	call   6560 <fwp_rc_fresh>
    b85b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    b862:	00 
    b863:	bf 01 00 00 00       	mov    $0x1,%edi
    b868:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    b86f:	00 
    b870:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    b877:	00 
    b878:	e8 33 ab ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b87d:	48 89 c7             	mov    %rax,%rdi
    b880:	e8 db ac ff ff       	call   6560 <fwp_rc_fresh>
    b885:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    b88c:	00 
    b88d:	bf 01 00 00 00       	mov    $0x1,%edi
    b892:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    b899:	00 
    b89a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    b8a1:	00 
    b8a2:	e8 09 ab ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b8a7:	48 89 c7             	mov    %rax,%rdi
    b8aa:	e8 b1 ac ff ff       	call   6560 <fwp_rc_fresh>
    b8af:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    b8b6:	00 
    b8b7:	bf 01 00 00 00       	mov    $0x1,%edi
    b8bc:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    b8c3:	00 
    b8c4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    b8cb:	00 
    b8cc:	e8 df aa ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b8d1:	48 89 c7             	mov    %rax,%rdi
    b8d4:	e8 87 ac ff ff       	call   6560 <fwp_rc_fresh>
    b8d9:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    b8e0:	00 
    b8e1:	bf 01 00 00 00       	mov    $0x1,%edi
    b8e6:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    b8ed:	00 
    b8ee:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    b8f5:	00 
    b8f6:	e8 b5 aa ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b8fb:	48 89 c7             	mov    %rax,%rdi
    b8fe:	e8 5d ac ff ff       	call   6560 <fwp_rc_fresh>
    b903:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    b90a:	00 
    b90b:	bf 01 00 00 00       	mov    $0x1,%edi
    b910:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    b917:	00 
    b918:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    b91f:	00 
    b920:	e8 8b aa ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b925:	48 89 c7             	mov    %rax,%rdi
    b928:	e8 33 ac ff ff       	call   6560 <fwp_rc_fresh>
    b92d:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    b934:	00 
    b935:	bf 01 00 00 00       	mov    $0x1,%edi
    b93a:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    b941:	00 
    b942:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    b949:	00 
    b94a:	e8 61 aa ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b94f:	48 89 c7             	mov    %rax,%rdi
    b952:	e8 09 ac ff ff       	call   6560 <fwp_rc_fresh>
    b957:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    b95e:	00 
    b95f:	bf 01 00 00 00       	mov    $0x1,%edi
    b964:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    b96b:	00 
    b96c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    b973:	00 
    b974:	e8 37 aa ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b979:	48 89 c7             	mov    %rax,%rdi
    b97c:	e8 df ab ff ff       	call   6560 <fwp_rc_fresh>
    b981:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    b988:	00 
    b989:	bf 01 00 00 00       	mov    $0x1,%edi
    b98e:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    b995:	00 
    b996:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    b99d:	00 
    b99e:	e8 0d aa ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b9a3:	48 89 c7             	mov    %rax,%rdi
    b9a6:	e8 b5 ab ff ff       	call   6560 <fwp_rc_fresh>
    b9ab:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    b9b2:	00 
    b9b3:	bf 01 00 00 00       	mov    $0x1,%edi
    b9b8:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    b9bf:	00 
    b9c0:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    b9c7:	00 
    b9c8:	e8 e3 a9 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b9cd:	48 89 c7             	mov    %rax,%rdi
    b9d0:	e8 8b ab ff ff       	call   6560 <fwp_rc_fresh>
    b9d5:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    b9dc:	00 
    b9dd:	bf 01 00 00 00       	mov    $0x1,%edi
    b9e2:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    b9e9:	00 
    b9ea:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    b9f1:	00 
    b9f2:	e8 b9 a9 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b9f7:	48 89 c7             	mov    %rax,%rdi
    b9fa:	e8 61 ab ff ff       	call   6560 <fwp_rc_fresh>
    b9ff:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    ba06:	00 
    ba07:	bf 01 00 00 00       	mov    $0x1,%edi
    ba0c:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    ba13:	00 
    ba14:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    ba1b:	00 
    ba1c:	e8 8f a9 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    ba21:	48 89 c7             	mov    %rax,%rdi
    ba24:	e8 37 ab ff ff       	call   6560 <fwp_rc_fresh>
    ba29:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    ba30:	00 
    ba31:	bf 01 00 00 00       	mov    $0x1,%edi
    ba36:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    ba3d:	00 
    ba3e:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    ba45:	00 
    ba46:	e8 65 a9 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    ba4b:	48 89 c7             	mov    %rax,%rdi
    ba4e:	e8 0d ab ff ff       	call   6560 <fwp_rc_fresh>
    ba53:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    ba5a:	00 
    ba5b:	bf 01 00 00 00       	mov    $0x1,%edi
    ba60:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    ba67:	00 
    ba68:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    ba6f:	00 
    ba70:	e8 3b a9 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    ba75:	48 89 c7             	mov    %rax,%rdi
    ba78:	e8 e3 aa ff ff       	call   6560 <fwp_rc_fresh>
    ba7d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    ba84:	00 
    ba85:	bf 01 00 00 00       	mov    $0x1,%edi
    ba8a:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    ba91:	00 
    ba92:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    ba99:	00 
    ba9a:	e8 11 a9 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    ba9f:	48 89 c7             	mov    %rax,%rdi
    baa2:	e8 b9 aa ff ff       	call   6560 <fwp_rc_fresh>
    baa7:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    baae:	00 
    baaf:	bf 01 00 00 00       	mov    $0x1,%edi
    bab4:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    babb:	00 
    babc:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    bac3:	00 
    bac4:	e8 e7 a8 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bac9:	48 89 c7             	mov    %rax,%rdi
    bacc:	e8 8f aa ff ff       	call   6560 <fwp_rc_fresh>
    bad1:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    bad8:	00 
    bad9:	bf 01 00 00 00       	mov    $0x1,%edi
    bade:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    bae5:	00 
    bae6:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    baed:	00 
    baee:	e8 bd a8 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    baf3:	48 89 c7             	mov    %rax,%rdi
    baf6:	e8 65 aa ff ff       	call   6560 <fwp_rc_fresh>
    bafb:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    bb02:	00 
    bb03:	bf 01 00 00 00       	mov    $0x1,%edi
    bb08:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    bb0f:	00 
    bb10:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    bb17:	00 
    bb18:	e8 93 a8 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bb1d:	48 89 c7             	mov    %rax,%rdi
    bb20:	e8 3b aa ff ff       	call   6560 <fwp_rc_fresh>
    bb25:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    bb2c:	00 
    bb2d:	bf 01 00 00 00       	mov    $0x1,%edi
    bb32:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    bb39:	00 
    bb3a:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    bb41:	00 
    bb42:	e8 69 a8 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bb47:	48 89 c7             	mov    %rax,%rdi
    bb4a:	e8 11 aa ff ff       	call   6560 <fwp_rc_fresh>
    bb4f:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    bb56:	00 
    bb57:	bf 01 00 00 00       	mov    $0x1,%edi
    bb5c:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    bb63:	00 
    bb64:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    bb6b:	00 
    bb6c:	e8 3f a8 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bb71:	48 89 c7             	mov    %rax,%rdi
    bb74:	e8 e7 a9 ff ff       	call   6560 <fwp_rc_fresh>
    bb79:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    bb80:	00 
    bb81:	bf 01 00 00 00       	mov    $0x1,%edi
    bb86:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    bb8d:	00 
    bb8e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    bb95:	00 
    bb96:	e8 15 a8 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bb9b:	48 89 c7             	mov    %rax,%rdi
    bb9e:	e8 bd a9 ff ff       	call   6560 <fwp_rc_fresh>
    bba3:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    bbaa:	00 
    bbab:	bf 01 00 00 00       	mov    $0x1,%edi
    bbb0:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    bbb7:	00 
    bbb8:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    bbbf:	00 
    bbc0:	e8 eb a7 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bbc5:	48 89 c7             	mov    %rax,%rdi
    bbc8:	e8 93 a9 ff ff       	call   6560 <fwp_rc_fresh>
    bbcd:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    bbd4:	00 
    bbd5:	bf 01 00 00 00       	mov    $0x1,%edi
    bbda:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    bbe1:	00 
    bbe2:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    bbe9:	00 
    bbea:	e8 c1 a7 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bbef:	48 89 c7             	mov    %rax,%rdi
    bbf2:	e8 69 a9 ff ff       	call   6560 <fwp_rc_fresh>
    bbf7:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    bbfe:	00 
    bbff:	bf 01 00 00 00       	mov    $0x1,%edi
    bc04:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    bc0b:	00 
    bc0c:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    bc13:	00 
    bc14:	e8 97 a7 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bc19:	48 89 c7             	mov    %rax,%rdi
    bc1c:	e8 3f a9 ff ff       	call   6560 <fwp_rc_fresh>
    bc21:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    bc28:	00 
    bc29:	bf 01 00 00 00       	mov    $0x1,%edi
    bc2e:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    bc35:	00 
    bc36:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    bc3d:	00 
    bc3e:	e8 6d a7 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bc43:	48 89 c7             	mov    %rax,%rdi
    bc46:	e8 15 a9 ff ff       	call   6560 <fwp_rc_fresh>
    bc4b:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    bc52:	00 
    bc53:	bf 01 00 00 00       	mov    $0x1,%edi
    bc58:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    bc5f:	00 
    bc60:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    bc67:	00 
    bc68:	e8 43 a7 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bc6d:	48 89 c7             	mov    %rax,%rdi
    bc70:	e8 eb a8 ff ff       	call   6560 <fwp_rc_fresh>
    bc75:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    bc7c:	00 
    bc7d:	bf 01 00 00 00       	mov    $0x1,%edi
    bc82:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    bc89:	00 
    bc8a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    bc91:	00 
    bc92:	e8 19 a7 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bc97:	48 89 c7             	mov    %rax,%rdi
    bc9a:	e8 c1 a8 ff ff       	call   6560 <fwp_rc_fresh>
    bc9f:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    bca6:	00 
    bca7:	bf 01 00 00 00       	mov    $0x1,%edi
    bcac:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    bcb3:	00 
    bcb4:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    bcbb:	00 
    bcbc:	e8 ef a6 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bcc1:	48 89 c7             	mov    %rax,%rdi
    bcc4:	e8 97 a8 ff ff       	call   6560 <fwp_rc_fresh>
    bcc9:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    bcd0:	00 
    bcd1:	bf 01 00 00 00       	mov    $0x1,%edi
    bcd6:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    bcdd:	00 
    bcde:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    bce5:	00 
    bce6:	e8 c5 a6 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bceb:	48 89 c7             	mov    %rax,%rdi
    bcee:	e8 6d a8 ff ff       	call   6560 <fwp_rc_fresh>
    bcf3:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    bcfa:	00 
    bcfb:	bf 01 00 00 00       	mov    $0x1,%edi
    bd00:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    bd07:	00 
    bd08:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    bd0f:	00 
    bd10:	e8 9b a6 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bd15:	48 89 c7             	mov    %rax,%rdi
    bd18:	e8 43 a8 ff ff       	call   6560 <fwp_rc_fresh>
    bd1d:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    bd24:	00 
    bd25:	bf 01 00 00 00       	mov    $0x1,%edi
    bd2a:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    bd31:	00 
    bd32:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    bd39:	00 
    bd3a:	e8 71 a6 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bd3f:	48 89 c7             	mov    %rax,%rdi
    bd42:	e8 19 a8 ff ff       	call   6560 <fwp_rc_fresh>
    bd47:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    bd4e:	00 
    bd4f:	bf 01 00 00 00       	mov    $0x1,%edi
    bd54:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    bd5b:	00 
    bd5c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    bd63:	00 
    bd64:	e8 47 a6 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bd69:	48 89 c7             	mov    %rax,%rdi
    bd6c:	e8 ef a7 ff ff       	call   6560 <fwp_rc_fresh>
    bd71:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    bd78:	00 
    bd79:	bf 01 00 00 00       	mov    $0x1,%edi
    bd7e:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    bd85:	00 
    bd86:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    bd8d:	00 
    bd8e:	e8 1d a6 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bd93:	48 89 c7             	mov    %rax,%rdi
    bd96:	e8 c5 a7 ff ff       	call   6560 <fwp_rc_fresh>
    bd9b:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    bda2:	00 
    bda3:	bf 01 00 00 00       	mov    $0x1,%edi
    bda8:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    bdaf:	00 
    bdb0:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    bdb7:	00 
    bdb8:	e8 f3 a5 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bdbd:	48 89 c7             	mov    %rax,%rdi
    bdc0:	e8 9b a7 ff ff       	call   6560 <fwp_rc_fresh>
    bdc5:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    bdcc:	00 
    bdcd:	bf 01 00 00 00       	mov    $0x1,%edi
    bdd2:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    bdd9:	00 
    bdda:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    bde1:	00 
    bde2:	e8 c9 a5 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bde7:	48 89 c7             	mov    %rax,%rdi
    bdea:	e8 71 a7 ff ff       	call   6560 <fwp_rc_fresh>
    bdef:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    bdf6:	00 
    bdf7:	bf 01 00 00 00       	mov    $0x1,%edi
    bdfc:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    be03:	00 
    be04:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    be0b:	00 
    be0c:	e8 9f a5 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    be11:	48 89 c7             	mov    %rax,%rdi
    be14:	e8 47 a7 ff ff       	call   6560 <fwp_rc_fresh>
    be19:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    be20:	00 
    be21:	bf 01 00 00 00       	mov    $0x1,%edi
    be26:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    be2d:	00 
    be2e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    be35:	00 
    be36:	e8 75 a5 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    be3b:	48 89 c7             	mov    %rax,%rdi
    be3e:	e8 1d a7 ff ff       	call   6560 <fwp_rc_fresh>
    be43:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    be4a:	00 
    be4b:	bf 01 00 00 00       	mov    $0x1,%edi
    be50:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    be57:	00 
    be58:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    be5f:	00 
    be60:	e8 4b a5 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    be65:	48 89 c7             	mov    %rax,%rdi
    be68:	e8 f3 a6 ff ff       	call   6560 <fwp_rc_fresh>
    be6d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    be74:	00 
    be75:	bf 01 00 00 00       	mov    $0x1,%edi
    be7a:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    be81:	00 
    be82:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    be89:	00 
    be8a:	e8 21 a5 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    be8f:	48 89 c7             	mov    %rax,%rdi
    be92:	e8 c9 a6 ff ff       	call   6560 <fwp_rc_fresh>
    be97:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    be9e:	00 
    be9f:	bf 01 00 00 00       	mov    $0x1,%edi
    bea4:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    beab:	00 
    beac:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    beb3:	00 
    beb4:	e8 f7 a4 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    beb9:	48 89 c7             	mov    %rax,%rdi
    bebc:	e8 9f a6 ff ff       	call   6560 <fwp_rc_fresh>
    bec1:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    bec8:	00 
    bec9:	bf 01 00 00 00       	mov    $0x1,%edi
    bece:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    bed5:	00 
    bed6:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    bedd:	00 
    bede:	e8 cd a4 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bee3:	48 89 c7             	mov    %rax,%rdi
    bee6:	e8 75 a6 ff ff       	call   6560 <fwp_rc_fresh>
    beeb:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    bef2:	00 
    bef3:	bf 01 00 00 00       	mov    $0x1,%edi
    bef8:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    beff:	00 
    bf00:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    bf07:	00 
    bf08:	e8 a3 a4 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bf0d:	48 89 c7             	mov    %rax,%rdi
    bf10:	e8 4b a6 ff ff       	call   6560 <fwp_rc_fresh>
    bf15:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    bf1c:	00 
    bf1d:	bf 01 00 00 00       	mov    $0x1,%edi
    bf22:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    bf29:	00 
    bf2a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    bf31:	00 
    bf32:	e8 79 a4 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bf37:	48 89 c7             	mov    %rax,%rdi
    bf3a:	e8 21 a6 ff ff       	call   6560 <fwp_rc_fresh>
    bf3f:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    bf46:	00 
    bf47:	bf 01 00 00 00       	mov    $0x1,%edi
    bf4c:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    bf53:	00 
    bf54:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    bf5b:	00 
    bf5c:	e8 4f a4 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bf61:	48 89 c7             	mov    %rax,%rdi
    bf64:	e8 f7 a5 ff ff       	call   6560 <fwp_rc_fresh>
    bf69:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    bf70:	00 
    bf71:	bf 01 00 00 00       	mov    $0x1,%edi
    bf76:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    bf7d:	00 
    bf7e:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    bf85:	00 
    bf86:	e8 25 a4 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bf8b:	48 89 c7             	mov    %rax,%rdi
    bf8e:	e8 cd a5 ff ff       	call   6560 <fwp_rc_fresh>
    bf93:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    bf9a:	00 
    bf9b:	bf 01 00 00 00       	mov    $0x1,%edi
    bfa0:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    bfa7:	00 
    bfa8:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    bfaf:	00 
    bfb0:	e8 fb a3 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bfb5:	48 89 c7             	mov    %rax,%rdi
    bfb8:	e8 a3 a5 ff ff       	call   6560 <fwp_rc_fresh>
    bfbd:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    bfc4:	00 
    bfc5:	bf 01 00 00 00       	mov    $0x1,%edi
    bfca:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    bfd1:	00 
    bfd2:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    bfd9:	00 
    bfda:	e8 d1 a3 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    bfdf:	48 89 c7             	mov    %rax,%rdi
    bfe2:	e8 79 a5 ff ff       	call   6560 <fwp_rc_fresh>
    bfe7:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    bfee:	00 
    bfef:	bf 01 00 00 00       	mov    $0x1,%edi
    bff4:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    bffb:	00 
    bffc:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    c003:	00 
    c004:	e8 a7 a3 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c009:	48 89 c7             	mov    %rax,%rdi
    c00c:	e8 4f a5 ff ff       	call   6560 <fwp_rc_fresh>
    c011:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    c018:	00 
    c019:	bf 01 00 00 00       	mov    $0x1,%edi
    c01e:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    c025:	00 
    c026:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    c02d:	00 
    c02e:	e8 7d a3 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c033:	48 89 c7             	mov    %rax,%rdi
    c036:	e8 25 a5 ff ff       	call   6560 <fwp_rc_fresh>
    c03b:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    c042:	00 
    c043:	bf 01 00 00 00       	mov    $0x1,%edi
    c048:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    c04f:	00 
    c050:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    c057:	00 
    c058:	e8 53 a3 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c05d:	48 89 c7             	mov    %rax,%rdi
    c060:	e8 fb a4 ff ff       	call   6560 <fwp_rc_fresh>
    c065:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    c06c:	00 
    c06d:	bf 01 00 00 00       	mov    $0x1,%edi
    c072:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    c079:	00 
    c07a:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    c081:	00 
    c082:	e8 29 a3 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c087:	48 89 c7             	mov    %rax,%rdi
    c08a:	e8 d1 a4 ff ff       	call   6560 <fwp_rc_fresh>
    c08f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    c096:	00 
    c097:	bf 01 00 00 00       	mov    $0x1,%edi
    c09c:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    c0a3:	00 
    c0a4:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    c0ab:	00 
    c0ac:	e8 ff a2 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c0b1:	48 89 c7             	mov    %rax,%rdi
    c0b4:	e8 a7 a4 ff ff       	call   6560 <fwp_rc_fresh>
    c0b9:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    c0c0:	00 
    c0c1:	bf 01 00 00 00       	mov    $0x1,%edi
    c0c6:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    c0cd:	00 
    c0ce:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    c0d5:	00 
    c0d6:	e8 d5 a2 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c0db:	48 89 c7             	mov    %rax,%rdi
    c0de:	e8 7d a4 ff ff       	call   6560 <fwp_rc_fresh>
    c0e3:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    c0ea:	00 
    c0eb:	bf 01 00 00 00       	mov    $0x1,%edi
    c0f0:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    c0f7:	00 
    c0f8:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    c0ff:	00 
    c100:	e8 ab a2 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c105:	48 89 c7             	mov    %rax,%rdi
    c108:	e8 53 a4 ff ff       	call   6560 <fwp_rc_fresh>
    c10d:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    c114:	00 
    c115:	bf 01 00 00 00       	mov    $0x1,%edi
    c11a:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    c121:	00 
    c122:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    c129:	00 
    c12a:	e8 81 a2 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c12f:	48 89 c7             	mov    %rax,%rdi
    c132:	e8 29 a4 ff ff       	call   6560 <fwp_rc_fresh>
    c137:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    c13e:	00 
    c13f:	bf 01 00 00 00       	mov    $0x1,%edi
    c144:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    c14b:	00 
    c14c:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    c153:	00 
    c154:	e8 57 a2 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c159:	48 89 c7             	mov    %rax,%rdi
    c15c:	e8 ff a3 ff ff       	call   6560 <fwp_rc_fresh>
    c161:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    c168:	00 
    c169:	bf 01 00 00 00       	mov    $0x1,%edi
    c16e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    c175:	00 
    c176:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    c17d:	00 
    c17e:	e8 2d a2 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c183:	48 89 c7             	mov    %rax,%rdi
    c186:	e8 d5 a3 ff ff       	call   6560 <fwp_rc_fresh>
    c18b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    c192:	00 
    c193:	bf 01 00 00 00       	mov    $0x1,%edi
    c198:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    c19f:	00 
    c1a0:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    c1a7:	00 
    c1a8:	e8 03 a2 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c1ad:	48 89 c7             	mov    %rax,%rdi
    c1b0:	e8 ab a3 ff ff       	call   6560 <fwp_rc_fresh>
    c1b5:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    c1bc:	00 
    c1bd:	bf 01 00 00 00       	mov    $0x1,%edi
    c1c2:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    c1c9:	00 
    c1ca:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    c1d1:	00 
    c1d2:	e8 d9 a1 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c1d7:	48 89 c7             	mov    %rax,%rdi
    c1da:	e8 81 a3 ff ff       	call   6560 <fwp_rc_fresh>
    c1df:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    c1e6:	00 
    c1e7:	bf 01 00 00 00       	mov    $0x1,%edi
    c1ec:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    c1f3:	00 
    c1f4:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    c1fb:	00 
    c1fc:	e8 af a1 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c201:	48 89 c7             	mov    %rax,%rdi
    c204:	e8 57 a3 ff ff       	call   6560 <fwp_rc_fresh>
    c209:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    c210:	00 
    c211:	bf 01 00 00 00       	mov    $0x1,%edi
    c216:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    c21d:	00 
    c21e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    c225:	00 
    c226:	e8 85 a1 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c22b:	48 89 c7             	mov    %rax,%rdi
    c22e:	e8 2d a3 ff ff       	call   6560 <fwp_rc_fresh>
    c233:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    c23a:	00 
    c23b:	bf 01 00 00 00       	mov    $0x1,%edi
    c240:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    c247:	00 
    c248:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    c24f:	00 
    c250:	e8 5b a1 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c255:	48 89 c7             	mov    %rax,%rdi
    c258:	e8 03 a3 ff ff       	call   6560 <fwp_rc_fresh>
    c25d:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    c264:	00 
    c265:	bf 01 00 00 00       	mov    $0x1,%edi
    c26a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    c271:	00 
    c272:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    c279:	00 
    c27a:	e8 31 a1 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c27f:	48 89 c7             	mov    %rax,%rdi
    c282:	e8 d9 a2 ff ff       	call   6560 <fwp_rc_fresh>
    c287:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    c28e:	00 
    c28f:	bf 01 00 00 00       	mov    $0x1,%edi
    c294:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    c29b:	00 
    c29c:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    c2a3:	00 
    c2a4:	e8 07 a1 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c2a9:	48 89 c7             	mov    %rax,%rdi
    c2ac:	e8 af a2 ff ff       	call   6560 <fwp_rc_fresh>
    c2b1:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    c2b8:	00 
    c2b9:	bf 01 00 00 00       	mov    $0x1,%edi
    c2be:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    c2c5:	00 
    c2c6:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    c2cd:	00 
    c2ce:	e8 dd a0 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c2d3:	48 89 c7             	mov    %rax,%rdi
    c2d6:	e8 85 a2 ff ff       	call   6560 <fwp_rc_fresh>
    c2db:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    c2e2:	00 
    c2e3:	bf 01 00 00 00       	mov    $0x1,%edi
    c2e8:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    c2ef:	00 
    c2f0:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    c2f7:	00 
    c2f8:	e8 b3 a0 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c2fd:	48 89 c7             	mov    %rax,%rdi
    c300:	e8 5b a2 ff ff       	call   6560 <fwp_rc_fresh>
    c305:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    c30c:	00 
    c30d:	bf 01 00 00 00       	mov    $0x1,%edi
    c312:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    c319:	00 
    c31a:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    c321:	00 
    c322:	e8 89 a0 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c327:	48 89 c7             	mov    %rax,%rdi
    c32a:	e8 31 a2 ff ff       	call   6560 <fwp_rc_fresh>
    c32f:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    c336:	00 
    c337:	bf 01 00 00 00       	mov    $0x1,%edi
    c33c:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    c343:	00 
    c344:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    c34b:	00 
    c34c:	e8 5f a0 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c351:	48 89 c7             	mov    %rax,%rdi
    c354:	e8 07 a2 ff ff       	call   6560 <fwp_rc_fresh>
    c359:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    c360:	00 
    c361:	bf 01 00 00 00       	mov    $0x1,%edi
    c366:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    c36d:	00 
    c36e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    c375:	00 
    c376:	e8 35 a0 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c37b:	48 89 c7             	mov    %rax,%rdi
    c37e:	e8 dd a1 ff ff       	call   6560 <fwp_rc_fresh>
    c383:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    c38a:	00 
    c38b:	bf 01 00 00 00       	mov    $0x1,%edi
    c390:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    c397:	00 
    c398:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    c39f:	00 
    c3a0:	e8 0b a0 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c3a5:	48 89 c7             	mov    %rax,%rdi
    c3a8:	e8 b3 a1 ff ff       	call   6560 <fwp_rc_fresh>
    c3ad:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    c3b4:	00 
    c3b5:	bf 01 00 00 00       	mov    $0x1,%edi
    c3ba:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    c3c1:	00 
    c3c2:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    c3c9:	00 
    c3ca:	e8 e1 9f ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c3cf:	48 89 c7             	mov    %rax,%rdi
    c3d2:	e8 89 a1 ff ff       	call   6560 <fwp_rc_fresh>
    c3d7:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    c3de:	00 
    c3df:	bf 01 00 00 00       	mov    $0x1,%edi
    c3e4:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    c3eb:	00 
    c3ec:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    c3f3:	00 
    c3f4:	e8 b7 9f ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c3f9:	48 89 c7             	mov    %rax,%rdi
    c3fc:	e8 5f a1 ff ff       	call   6560 <fwp_rc_fresh>
    c401:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    c408:	00 
    c409:	bf 01 00 00 00       	mov    $0x1,%edi
    c40e:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    c415:	00 
    c416:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    c41d:	00 
    c41e:	e8 8d 9f ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c423:	48 89 c7             	mov    %rax,%rdi
    c426:	e8 35 a1 ff ff       	call   6560 <fwp_rc_fresh>
    c42b:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    c432:	00 
    c433:	bf 01 00 00 00       	mov    $0x1,%edi
    c438:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    c43f:	00 
    c440:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    c447:	00 
    c448:	e8 63 9f ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c44d:	48 89 c7             	mov    %rax,%rdi
    c450:	e8 0b a1 ff ff       	call   6560 <fwp_rc_fresh>
    c455:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    c45c:	00 
    c45d:	bf 01 00 00 00       	mov    $0x1,%edi
    c462:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    c469:	00 
    c46a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    c471:	00 
    c472:	e8 39 9f ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c477:	48 89 c7             	mov    %rax,%rdi
    c47a:	e8 e1 a0 ff ff       	call   6560 <fwp_rc_fresh>
    c47f:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    c486:	00 
    c487:	bf 01 00 00 00       	mov    $0x1,%edi
    c48c:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    c493:	00 
    c494:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    c49b:	00 
    c49c:	e8 0f 9f ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c4a1:	48 89 c7             	mov    %rax,%rdi
    c4a4:	e8 b7 a0 ff ff       	call   6560 <fwp_rc_fresh>
    c4a9:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    c4b0:	00 
    c4b1:	bf 01 00 00 00       	mov    $0x1,%edi
    c4b6:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    c4bd:	00 
    c4be:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    c4c5:	00 
    c4c6:	e8 e5 9e ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c4cb:	48 89 c7             	mov    %rax,%rdi
    c4ce:	e8 8d a0 ff ff       	call   6560 <fwp_rc_fresh>
    c4d3:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    c4da:	00 
    c4db:	bf 01 00 00 00       	mov    $0x1,%edi
    c4e0:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    c4e7:	00 
    c4e8:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    c4ef:	00 
    c4f0:	e8 bb 9e ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c4f5:	48 89 c7             	mov    %rax,%rdi
    c4f8:	e8 63 a0 ff ff       	call   6560 <fwp_rc_fresh>
    c4fd:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    c504:	00 
    c505:	bf 01 00 00 00       	mov    $0x1,%edi
    c50a:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    c511:	00 
    c512:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    c519:	00 
    c51a:	e8 91 9e ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c51f:	48 89 c7             	mov    %rax,%rdi
    c522:	e8 39 a0 ff ff       	call   6560 <fwp_rc_fresh>
    c527:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    c52e:	00 
    c52f:	bf 01 00 00 00       	mov    $0x1,%edi
    c534:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    c53b:	00 
    c53c:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    c543:	00 
    c544:	e8 67 9e ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c549:	48 89 c7             	mov    %rax,%rdi
    c54c:	e8 0f a0 ff ff       	call   6560 <fwp_rc_fresh>
    c551:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    c558:	00 
    c559:	bf 01 00 00 00       	mov    $0x1,%edi
    c55e:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    c565:	00 
    c566:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    c56d:	00 
    c56e:	e8 3d 9e ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c573:	48 89 c7             	mov    %rax,%rdi
    c576:	e8 e5 9f ff ff       	call   6560 <fwp_rc_fresh>
    c57b:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    c582:	00 
    c583:	bf 01 00 00 00       	mov    $0x1,%edi
    c588:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    c58f:	00 
    c590:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    c597:	00 
    c598:	e8 13 9e ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c59d:	48 89 c7             	mov    %rax,%rdi
    c5a0:	e8 bb 9f ff ff       	call   6560 <fwp_rc_fresh>
    c5a5:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    c5ac:	00 
    c5ad:	bf 01 00 00 00       	mov    $0x1,%edi
    c5b2:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    c5b9:	00 
    c5ba:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    c5c1:	00 
    c5c2:	e8 e9 9d ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c5c7:	48 89 c7             	mov    %rax,%rdi
    c5ca:	e8 91 9f ff ff       	call   6560 <fwp_rc_fresh>
    c5cf:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    c5d6:	00 
    c5d7:	bf 01 00 00 00       	mov    $0x1,%edi
    c5dc:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    c5e3:	00 
    c5e4:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    c5eb:	00 
    c5ec:	e8 bf 9d ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c5f1:	48 89 c7             	mov    %rax,%rdi
    c5f4:	e8 67 9f ff ff       	call   6560 <fwp_rc_fresh>
    c5f9:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c600:	00 
    c601:	bf 01 00 00 00       	mov    $0x1,%edi
    c606:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c60d:	00 
    c60e:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c615:	00 
    c616:	e8 95 9d ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c61b:	48 89 c7             	mov    %rax,%rdi
    c61e:	e8 3d 9f ff ff       	call   6560 <fwp_rc_fresh>
    c623:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    c62a:	00 
    c62b:	bf 01 00 00 00       	mov    $0x1,%edi
    c630:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    c637:	00 
    c638:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    c63f:	00 
    c640:	e8 6b 9d ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c645:	48 8b 15 2c 85 01 00 	mov    0x1852c(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    c64c:	49 89 c5             	mov    %rax,%r13
    c64f:	48 2b 05 fa 84 01 00 	sub    0x184fa(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    c656:	48 c1 e2 10          	shl    $0x10,%rdx
    c65a:	48 39 d0             	cmp    %rdx,%rax
    c65d:	73 59                	jae    c6b8 <f0+0x13b8>
    c65f:	48 89 c2             	mov    %rax,%rdx
    c662:	48 c1 ea 10          	shr    $0x10,%rdx
    c666:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c66a:	48 8b 15 27 85 01 00 	mov    0x18527(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    c671:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c675:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c679:	4d 85 e4             	test   %r12,%r12
    c67c:	74 3a                	je     c6b8 <f0+0x13b8>
    c67e:	0f b6 0a             	movzbl (%rdx),%ecx
    c681:	80 f9 02             	cmp    $0x2,%cl
    c684:	0f 84 c6 15 00 00    	je     dc50 <f0+0x2950>
    c68a:	80 f9 01             	cmp    $0x1,%cl
    c68d:	75 29                	jne    c6b8 <f0+0x13b8>
    c68f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c692:	0f b7 c0             	movzwl %ax,%eax
    c695:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c698:	48 0f af c1          	imul   %rcx,%rax
    c69c:	48 c1 e8 20          	shr    $0x20,%rax
    c6a0:	48 39 d0             	cmp    %rdx,%rax
    c6a3:	73 13                	jae    c6b8 <f0+0x13b8>
    c6a5:	49 01 c4             	add    %rax,%r12
    c6a8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c6ad:	0f 84 99 17 00 00    	je     de4c <f0+0x2b4c>
    c6b3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c6b8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c6bf:	33 f3 bf 
    c6c2:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    c6c9:	00 
    c6ca:	bf 01 00 00 00       	mov    $0x1,%edi
    c6cf:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    c6d6:	00 
    c6d7:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    c6de:	00 
    c6df:	e8 cc 9c ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c6e4:	48 8b 15 8d 84 01 00 	mov    0x1848d(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    c6eb:	49 89 c5             	mov    %rax,%r13
    c6ee:	48 2b 05 5b 84 01 00 	sub    0x1845b(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    c6f5:	48 c1 e2 10          	shl    $0x10,%rdx
    c6f9:	48 39 d0             	cmp    %rdx,%rax
    c6fc:	73 59                	jae    c757 <f0+0x1457>
    c6fe:	48 89 c2             	mov    %rax,%rdx
    c701:	48 c1 ea 10          	shr    $0x10,%rdx
    c705:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c709:	48 8b 15 88 84 01 00 	mov    0x18488(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    c710:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c714:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c718:	4d 85 e4             	test   %r12,%r12
    c71b:	74 3a                	je     c757 <f0+0x1457>
    c71d:	0f b6 0a             	movzbl (%rdx),%ecx
    c720:	80 f9 02             	cmp    $0x2,%cl
    c723:	0f 84 17 15 00 00    	je     dc40 <f0+0x2940>
    c729:	80 f9 01             	cmp    $0x1,%cl
    c72c:	75 29                	jne    c757 <f0+0x1457>
    c72e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c731:	0f b7 c0             	movzwl %ax,%eax
    c734:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c737:	48 0f af c1          	imul   %rcx,%rax
    c73b:	48 c1 e8 20          	shr    $0x20,%rax
    c73f:	48 39 d0             	cmp    %rdx,%rax
    c742:	73 13                	jae    c757 <f0+0x1457>
    c744:	49 01 c4             	add    %rax,%r12
    c747:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c74c:	0f 84 07 17 00 00    	je     de59 <f0+0x2b59>
    c752:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c757:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c75e:	00 f0 3f 
    c761:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    c768:	00 
    c769:	bf 01 00 00 00       	mov    $0x1,%edi
    c76e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    c775:	00 
    c776:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    c77d:	00 
    c77e:	e8 2d 9c ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c783:	48 8b 15 ee 83 01 00 	mov    0x183ee(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    c78a:	49 89 c5             	mov    %rax,%r13
    c78d:	48 2b 05 bc 83 01 00 	sub    0x183bc(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    c794:	48 c1 e2 10          	shl    $0x10,%rdx
    c798:	48 39 d0             	cmp    %rdx,%rax
    c79b:	73 59                	jae    c7f6 <f0+0x14f6>
    c79d:	48 89 c2             	mov    %rax,%rdx
    c7a0:	48 c1 ea 10          	shr    $0x10,%rdx
    c7a4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c7a8:	48 8b 15 e9 83 01 00 	mov    0x183e9(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    c7af:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c7b3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c7b7:	4d 85 e4             	test   %r12,%r12
    c7ba:	74 3a                	je     c7f6 <f0+0x14f6>
    c7bc:	0f b6 0a             	movzbl (%rdx),%ecx
    c7bf:	80 f9 02             	cmp    $0x2,%cl
    c7c2:	0f 84 28 15 00 00    	je     dcf0 <f0+0x29f0>
    c7c8:	80 f9 01             	cmp    $0x1,%cl
    c7cb:	75 29                	jne    c7f6 <f0+0x14f6>
    c7cd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c7d0:	0f b7 c0             	movzwl %ax,%eax
    c7d3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c7d6:	48 0f af c1          	imul   %rcx,%rax
    c7da:	48 c1 e8 20          	shr    $0x20,%rax
    c7de:	48 39 d0             	cmp    %rdx,%rax
    c7e1:	73 13                	jae    c7f6 <f0+0x14f6>
    c7e3:	49 01 c4             	add    %rax,%r12
    c7e6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c7eb:	0f 84 75 16 00 00    	je     de66 <f0+0x2b66>
    c7f1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c7f6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c7fd:	33 f3 bf 
    c800:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    c807:	00 
    c808:	bf 01 00 00 00       	mov    $0x1,%edi
    c80d:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    c814:	00 
    c815:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    c81c:	00 
    c81d:	e8 8e 9b ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c822:	48 8b 15 4f 83 01 00 	mov    0x1834f(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    c829:	49 89 c5             	mov    %rax,%r13
    c82c:	48 2b 05 1d 83 01 00 	sub    0x1831d(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    c833:	48 c1 e2 10          	shl    $0x10,%rdx
    c837:	48 39 d0             	cmp    %rdx,%rax
    c83a:	73 59                	jae    c895 <f0+0x1595>
    c83c:	48 89 c2             	mov    %rax,%rdx
    c83f:	48 c1 ea 10          	shr    $0x10,%rdx
    c843:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c847:	48 8b 15 4a 83 01 00 	mov    0x1834a(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    c84e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c852:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c856:	4d 85 e4             	test   %r12,%r12
    c859:	74 3a                	je     c895 <f0+0x1595>
    c85b:	0f b6 0a             	movzbl (%rdx),%ecx
    c85e:	80 f9 02             	cmp    $0x2,%cl
    c861:	0f 84 79 14 00 00    	je     dce0 <f0+0x29e0>
    c867:	80 f9 01             	cmp    $0x1,%cl
    c86a:	75 29                	jne    c895 <f0+0x1595>
    c86c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c86f:	0f b7 c0             	movzwl %ax,%eax
    c872:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c875:	48 0f af c1          	imul   %rcx,%rax
    c879:	48 c1 e8 20          	shr    $0x20,%rax
    c87d:	48 39 d0             	cmp    %rdx,%rax
    c880:	73 13                	jae    c895 <f0+0x1595>
    c882:	49 01 c4             	add    %rax,%r12
    c885:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c88a:	0f 84 e3 15 00 00    	je     de73 <f0+0x2b73>
    c890:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c895:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c89c:	00 f0 3f 
    c89f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    c8a6:	00 
    c8a7:	bf 01 00 00 00       	mov    $0x1,%edi
    c8ac:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    c8b3:	00 
    c8b4:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    c8bb:	00 
    c8bc:	e8 ef 9a ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c8c1:	48 8b 15 b0 82 01 00 	mov    0x182b0(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    c8c8:	49 89 c5             	mov    %rax,%r13
    c8cb:	48 2b 05 7e 82 01 00 	sub    0x1827e(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    c8d2:	48 c1 e2 10          	shl    $0x10,%rdx
    c8d6:	48 39 d0             	cmp    %rdx,%rax
    c8d9:	73 59                	jae    c934 <f0+0x1634>
    c8db:	48 89 c2             	mov    %rax,%rdx
    c8de:	48 c1 ea 10          	shr    $0x10,%rdx
    c8e2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c8e6:	48 8b 15 ab 82 01 00 	mov    0x182ab(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    c8ed:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c8f1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c8f5:	4d 85 e4             	test   %r12,%r12
    c8f8:	74 3a                	je     c934 <f0+0x1634>
    c8fa:	0f b6 0a             	movzbl (%rdx),%ecx
    c8fd:	80 f9 02             	cmp    $0x2,%cl
    c900:	0f 84 ca 13 00 00    	je     dcd0 <f0+0x29d0>
    c906:	80 f9 01             	cmp    $0x1,%cl
    c909:	75 29                	jne    c934 <f0+0x1634>
    c90b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c90e:	0f b7 c0             	movzwl %ax,%eax
    c911:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c914:	48 0f af c1          	imul   %rcx,%rax
    c918:	48 c1 e8 20          	shr    $0x20,%rax
    c91c:	48 39 d0             	cmp    %rdx,%rax
    c91f:	73 13                	jae    c934 <f0+0x1634>
    c921:	49 01 c4             	add    %rax,%r12
    c924:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c929:	0f 84 51 15 00 00    	je     de80 <f0+0x2b80>
    c92f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c934:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c93b:	33 f3 bf 
    c93e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    c945:	00 
    c946:	bf 01 00 00 00       	mov    $0x1,%edi
    c94b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    c952:	00 
    c953:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    c95a:	00 
    c95b:	e8 50 9a ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c960:	48 8b 15 11 82 01 00 	mov    0x18211(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    c967:	49 89 c5             	mov    %rax,%r13
    c96a:	48 2b 05 df 81 01 00 	sub    0x181df(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    c971:	48 c1 e2 10          	shl    $0x10,%rdx
    c975:	48 39 d0             	cmp    %rdx,%rax
    c978:	73 59                	jae    c9d3 <f0+0x16d3>
    c97a:	48 89 c2             	mov    %rax,%rdx
    c97d:	48 c1 ea 10          	shr    $0x10,%rdx
    c981:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c985:	48 8b 15 0c 82 01 00 	mov    0x1820c(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    c98c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c990:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c994:	4d 85 e4             	test   %r12,%r12
    c997:	74 3a                	je     c9d3 <f0+0x16d3>
    c999:	0f b6 0a             	movzbl (%rdx),%ecx
    c99c:	80 f9 02             	cmp    $0x2,%cl
    c99f:	0f 84 1b 13 00 00    	je     dcc0 <f0+0x29c0>
    c9a5:	80 f9 01             	cmp    $0x1,%cl
    c9a8:	75 29                	jne    c9d3 <f0+0x16d3>
    c9aa:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c9ad:	0f b7 c0             	movzwl %ax,%eax
    c9b0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c9b3:	48 0f af c1          	imul   %rcx,%rax
    c9b7:	48 c1 e8 20          	shr    $0x20,%rax
    c9bb:	48 39 d0             	cmp    %rdx,%rax
    c9be:	73 13                	jae    c9d3 <f0+0x16d3>
    c9c0:	49 01 c4             	add    %rax,%r12
    c9c3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c9c8:	0f 84 bf 14 00 00    	je     de8d <f0+0x2b8d>
    c9ce:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c9d3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c9da:	00 f0 3f 
    c9dd:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    c9e4:	00 
    c9e5:	bf 01 00 00 00       	mov    $0x1,%edi
    c9ea:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    c9f1:	00 
    c9f2:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    c9f9:	00 
    c9fa:	e8 b1 99 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    c9ff:	48 8b 15 72 81 01 00 	mov    0x18172(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    ca06:	49 89 c5             	mov    %rax,%r13
    ca09:	48 2b 05 40 81 01 00 	sub    0x18140(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    ca10:	48 c1 e2 10          	shl    $0x10,%rdx
    ca14:	48 39 d0             	cmp    %rdx,%rax
    ca17:	73 59                	jae    ca72 <f0+0x1772>
    ca19:	48 89 c2             	mov    %rax,%rdx
    ca1c:	48 c1 ea 10          	shr    $0x10,%rdx
    ca20:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca24:	48 8b 15 6d 81 01 00 	mov    0x1816d(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    ca2b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca2f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca33:	4d 85 e4             	test   %r12,%r12
    ca36:	74 3a                	je     ca72 <f0+0x1772>
    ca38:	0f b6 0a             	movzbl (%rdx),%ecx
    ca3b:	80 f9 02             	cmp    $0x2,%cl
    ca3e:	0f 84 6c 12 00 00    	je     dcb0 <f0+0x29b0>
    ca44:	80 f9 01             	cmp    $0x1,%cl
    ca47:	75 29                	jne    ca72 <f0+0x1772>
    ca49:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca4c:	0f b7 c0             	movzwl %ax,%eax
    ca4f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca52:	48 0f af c1          	imul   %rcx,%rax
    ca56:	48 c1 e8 20          	shr    $0x20,%rax
    ca5a:	48 39 d0             	cmp    %rdx,%rax
    ca5d:	73 13                	jae    ca72 <f0+0x1772>
    ca5f:	49 01 c4             	add    %rax,%r12
    ca62:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca67:	0f 84 2d 14 00 00    	je     de9a <f0+0x2b9a>
    ca6d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca72:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ca79:	33 f3 bf 
    ca7c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    ca83:	00 
    ca84:	bf 01 00 00 00       	mov    $0x1,%edi
    ca89:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    ca90:	00 
    ca91:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    ca98:	00 
    ca99:	e8 12 99 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    ca9e:	48 8b 15 d3 80 01 00 	mov    0x180d3(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    caa5:	49 89 c5             	mov    %rax,%r13
    caa8:	48 2b 05 a1 80 01 00 	sub    0x180a1(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    caaf:	48 c1 e2 10          	shl    $0x10,%rdx
    cab3:	48 39 d0             	cmp    %rdx,%rax
    cab6:	73 59                	jae    cb11 <f0+0x1811>
    cab8:	48 89 c2             	mov    %rax,%rdx
    cabb:	48 c1 ea 10          	shr    $0x10,%rdx
    cabf:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cac3:	48 8b 15 ce 80 01 00 	mov    0x180ce(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    caca:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cace:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cad2:	4d 85 e4             	test   %r12,%r12
    cad5:	74 3a                	je     cb11 <f0+0x1811>
    cad7:	0f b6 0a             	movzbl (%rdx),%ecx
    cada:	80 f9 02             	cmp    $0x2,%cl
    cadd:	0f 84 bd 11 00 00    	je     dca0 <f0+0x29a0>
    cae3:	80 f9 01             	cmp    $0x1,%cl
    cae6:	75 29                	jne    cb11 <f0+0x1811>
    cae8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    caeb:	0f b7 c0             	movzwl %ax,%eax
    caee:	8b 52 1c             	mov    0x1c(%rdx),%edx
    caf1:	48 0f af c1          	imul   %rcx,%rax
    caf5:	48 c1 e8 20          	shr    $0x20,%rax
    caf9:	48 39 d0             	cmp    %rdx,%rax
    cafc:	73 13                	jae    cb11 <f0+0x1811>
    cafe:	49 01 c4             	add    %rax,%r12
    cb01:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb06:	0f 84 9b 13 00 00    	je     dea7 <f0+0x2ba7>
    cb0c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb11:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cb18:	00 f0 3f 
    cb1b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    cb22:	00 
    cb23:	bf 01 00 00 00       	mov    $0x1,%edi
    cb28:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    cb2f:	00 
    cb30:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    cb37:	00 
    cb38:	e8 73 98 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    cb3d:	48 8b 15 34 80 01 00 	mov    0x18034(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    cb44:	49 89 c5             	mov    %rax,%r13
    cb47:	48 2b 05 02 80 01 00 	sub    0x18002(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    cb4e:	48 c1 e2 10          	shl    $0x10,%rdx
    cb52:	48 39 d0             	cmp    %rdx,%rax
    cb55:	73 59                	jae    cbb0 <f0+0x18b0>
    cb57:	48 89 c2             	mov    %rax,%rdx
    cb5a:	48 c1 ea 10          	shr    $0x10,%rdx
    cb5e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb62:	48 8b 15 2f 80 01 00 	mov    0x1802f(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    cb69:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb6d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb71:	4d 85 e4             	test   %r12,%r12
    cb74:	74 3a                	je     cbb0 <f0+0x18b0>
    cb76:	0f b6 0a             	movzbl (%rdx),%ecx
    cb79:	80 f9 02             	cmp    $0x2,%cl
    cb7c:	0f 84 0e 11 00 00    	je     dc90 <f0+0x2990>
    cb82:	80 f9 01             	cmp    $0x1,%cl
    cb85:	75 29                	jne    cbb0 <f0+0x18b0>
    cb87:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb8a:	0f b7 c0             	movzwl %ax,%eax
    cb8d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb90:	48 0f af c1          	imul   %rcx,%rax
    cb94:	48 c1 e8 20          	shr    $0x20,%rax
    cb98:	48 39 d0             	cmp    %rdx,%rax
    cb9b:	73 13                	jae    cbb0 <f0+0x18b0>
    cb9d:	49 01 c4             	add    %rax,%r12
    cba0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cba5:	0f 84 09 13 00 00    	je     deb4 <f0+0x2bb4>
    cbab:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cbb0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cbb7:	33 f3 bf 
    cbba:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    cbc1:	00 
    cbc2:	bf 01 00 00 00       	mov    $0x1,%edi
    cbc7:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    cbce:	00 
    cbcf:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    cbd6:	00 
    cbd7:	e8 d4 97 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    cbdc:	48 8b 15 95 7f 01 00 	mov    0x17f95(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    cbe3:	49 89 c5             	mov    %rax,%r13
    cbe6:	48 2b 05 63 7f 01 00 	sub    0x17f63(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    cbed:	48 c1 e2 10          	shl    $0x10,%rdx
    cbf1:	48 39 d0             	cmp    %rdx,%rax
    cbf4:	73 59                	jae    cc4f <f0+0x194f>
    cbf6:	48 89 c2             	mov    %rax,%rdx
    cbf9:	48 c1 ea 10          	shr    $0x10,%rdx
    cbfd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc01:	48 8b 15 90 7f 01 00 	mov    0x17f90(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    cc08:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc0c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc10:	4d 85 e4             	test   %r12,%r12
    cc13:	74 3a                	je     cc4f <f0+0x194f>
    cc15:	0f b6 0a             	movzbl (%rdx),%ecx
    cc18:	80 f9 02             	cmp    $0x2,%cl
    cc1b:	0f 84 5f 10 00 00    	je     dc80 <f0+0x2980>
    cc21:	80 f9 01             	cmp    $0x1,%cl
    cc24:	75 29                	jne    cc4f <f0+0x194f>
    cc26:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc29:	0f b7 c0             	movzwl %ax,%eax
    cc2c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc2f:	48 0f af c1          	imul   %rcx,%rax
    cc33:	48 c1 e8 20          	shr    $0x20,%rax
    cc37:	48 39 d0             	cmp    %rdx,%rax
    cc3a:	73 13                	jae    cc4f <f0+0x194f>
    cc3c:	49 01 c4             	add    %rax,%r12
    cc3f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc44:	0f 84 77 12 00 00    	je     dec1 <f0+0x2bc1>
    cc4a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc4f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc56:	00 f0 3f 
    cc59:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    cc60:	00 
    cc61:	bf 01 00 00 00       	mov    $0x1,%edi
    cc66:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    cc6d:	00 
    cc6e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    cc75:	00 
    cc76:	e8 35 97 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    cc7b:	48 8b 15 f6 7e 01 00 	mov    0x17ef6(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    cc82:	49 89 c5             	mov    %rax,%r13
    cc85:	48 2b 05 c4 7e 01 00 	sub    0x17ec4(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    cc8c:	48 c1 e2 10          	shl    $0x10,%rdx
    cc90:	48 39 d0             	cmp    %rdx,%rax
    cc93:	73 59                	jae    ccee <f0+0x19ee>
    cc95:	48 89 c2             	mov    %rax,%rdx
    cc98:	48 c1 ea 10          	shr    $0x10,%rdx
    cc9c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cca0:	48 8b 15 f1 7e 01 00 	mov    0x17ef1(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    cca7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ccab:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ccaf:	4d 85 e4             	test   %r12,%r12
    ccb2:	74 3a                	je     ccee <f0+0x19ee>
    ccb4:	0f b6 0a             	movzbl (%rdx),%ecx
    ccb7:	80 f9 02             	cmp    $0x2,%cl
    ccba:	0f 84 40 0f 00 00    	je     dc00 <f0+0x2900>
    ccc0:	80 f9 01             	cmp    $0x1,%cl
    ccc3:	75 29                	jne    ccee <f0+0x19ee>
    ccc5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ccc8:	0f b7 c0             	movzwl %ax,%eax
    cccb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ccce:	48 0f af c1          	imul   %rcx,%rax
    ccd2:	48 c1 e8 20          	shr    $0x20,%rax
    ccd6:	48 39 d0             	cmp    %rdx,%rax
    ccd9:	73 13                	jae    ccee <f0+0x19ee>
    ccdb:	49 01 c4             	add    %rax,%r12
    ccde:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cce3:	0f 84 e5 11 00 00    	je     dece <f0+0x2bce>
    cce9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ccee:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ccf5:	33 f3 bf 
    ccf8:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    ccff:	00 
    cd00:	bf 01 00 00 00       	mov    $0x1,%edi
    cd05:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    cd0c:	00 
    cd0d:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    cd14:	00 
    cd15:	e8 96 96 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    cd1a:	48 8b 15 57 7e 01 00 	mov    0x17e57(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    cd21:	49 89 c5             	mov    %rax,%r13
    cd24:	48 2b 05 25 7e 01 00 	sub    0x17e25(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    cd2b:	48 c1 e2 10          	shl    $0x10,%rdx
    cd2f:	48 39 d0             	cmp    %rdx,%rax
    cd32:	73 59                	jae    cd8d <f0+0x1a8d>
    cd34:	48 89 c2             	mov    %rax,%rdx
    cd37:	48 c1 ea 10          	shr    $0x10,%rdx
    cd3b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd3f:	48 8b 15 52 7e 01 00 	mov    0x17e52(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    cd46:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd4a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd4e:	4d 85 e4             	test   %r12,%r12
    cd51:	74 3a                	je     cd8d <f0+0x1a8d>
    cd53:	0f b6 0a             	movzbl (%rdx),%ecx
    cd56:	80 f9 02             	cmp    $0x2,%cl
    cd59:	0f 84 91 0e 00 00    	je     dbf0 <f0+0x28f0>
    cd5f:	80 f9 01             	cmp    $0x1,%cl
    cd62:	75 29                	jne    cd8d <f0+0x1a8d>
    cd64:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd67:	0f b7 c0             	movzwl %ax,%eax
    cd6a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd6d:	48 0f af c1          	imul   %rcx,%rax
    cd71:	48 c1 e8 20          	shr    $0x20,%rax
    cd75:	48 39 d0             	cmp    %rdx,%rax
    cd78:	73 13                	jae    cd8d <f0+0x1a8d>
    cd7a:	49 01 c4             	add    %rax,%r12
    cd7d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd82:	0f 84 53 11 00 00    	je     dedb <f0+0x2bdb>
    cd88:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd8d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cd94:	00 f0 3f 
    cd97:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    cd9e:	00 
    cd9f:	bf 01 00 00 00       	mov    $0x1,%edi
    cda4:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    cdab:	00 
    cdac:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    cdb3:	00 
    cdb4:	e8 f7 95 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    cdb9:	48 8b 15 b8 7d 01 00 	mov    0x17db8(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    cdc0:	49 89 c5             	mov    %rax,%r13
    cdc3:	48 2b 05 86 7d 01 00 	sub    0x17d86(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    cdca:	48 c1 e2 10          	shl    $0x10,%rdx
    cdce:	48 39 d0             	cmp    %rdx,%rax
    cdd1:	73 59                	jae    ce2c <f0+0x1b2c>
    cdd3:	48 89 c2             	mov    %rax,%rdx
    cdd6:	48 c1 ea 10          	shr    $0x10,%rdx
    cdda:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cdde:	48 8b 15 b3 7d 01 00 	mov    0x17db3(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    cde5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cde9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cded:	4d 85 e4             	test   %r12,%r12
    cdf0:	74 3a                	je     ce2c <f0+0x1b2c>
    cdf2:	0f b6 0a             	movzbl (%rdx),%ecx
    cdf5:	80 f9 02             	cmp    $0x2,%cl
    cdf8:	0f 84 e2 0d 00 00    	je     dbe0 <f0+0x28e0>
    cdfe:	80 f9 01             	cmp    $0x1,%cl
    ce01:	75 29                	jne    ce2c <f0+0x1b2c>
    ce03:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce06:	0f b7 c0             	movzwl %ax,%eax
    ce09:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce0c:	48 0f af c1          	imul   %rcx,%rax
    ce10:	48 c1 e8 20          	shr    $0x20,%rax
    ce14:	48 39 d0             	cmp    %rdx,%rax
    ce17:	73 13                	jae    ce2c <f0+0x1b2c>
    ce19:	49 01 c4             	add    %rax,%r12
    ce1c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce21:	0f 84 c1 10 00 00    	je     dee8 <f0+0x2be8>
    ce27:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce2c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ce33:	33 f3 bf 
    ce36:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    ce3d:	00 
    ce3e:	bf 01 00 00 00       	mov    $0x1,%edi
    ce43:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    ce4a:	00 
    ce4b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    ce52:	00 
    ce53:	e8 58 95 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    ce58:	48 8b 15 19 7d 01 00 	mov    0x17d19(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    ce5f:	49 89 c5             	mov    %rax,%r13
    ce62:	48 2b 05 e7 7c 01 00 	sub    0x17ce7(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    ce69:	48 c1 e2 10          	shl    $0x10,%rdx
    ce6d:	48 39 d0             	cmp    %rdx,%rax
    ce70:	73 59                	jae    cecb <f0+0x1bcb>
    ce72:	48 89 c2             	mov    %rax,%rdx
    ce75:	48 c1 ea 10          	shr    $0x10,%rdx
    ce79:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce7d:	48 8b 15 14 7d 01 00 	mov    0x17d14(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    ce84:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce88:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce8c:	4d 85 e4             	test   %r12,%r12
    ce8f:	74 3a                	je     cecb <f0+0x1bcb>
    ce91:	0f b6 0a             	movzbl (%rdx),%ecx
    ce94:	80 f9 02             	cmp    $0x2,%cl
    ce97:	0f 84 33 0d 00 00    	je     dbd0 <f0+0x28d0>
    ce9d:	80 f9 01             	cmp    $0x1,%cl
    cea0:	75 29                	jne    cecb <f0+0x1bcb>
    cea2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cea5:	0f b7 c0             	movzwl %ax,%eax
    cea8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ceab:	48 0f af c1          	imul   %rcx,%rax
    ceaf:	48 c1 e8 20          	shr    $0x20,%rax
    ceb3:	48 39 d0             	cmp    %rdx,%rax
    ceb6:	73 13                	jae    cecb <f0+0x1bcb>
    ceb8:	49 01 c4             	add    %rax,%r12
    cebb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cec0:	0f 84 2f 10 00 00    	je     def5 <f0+0x2bf5>
    cec6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cecb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ced2:	00 f0 3f 
    ced5:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    cedc:	00 
    cedd:	bf 01 00 00 00       	mov    $0x1,%edi
    cee2:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    cee9:	00 
    ceea:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    cef1:	00 
    cef2:	e8 b9 94 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    cef7:	48 8b 15 7a 7c 01 00 	mov    0x17c7a(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    cefe:	49 89 c5             	mov    %rax,%r13
    cf01:	48 2b 05 48 7c 01 00 	sub    0x17c48(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    cf08:	48 c1 e2 10          	shl    $0x10,%rdx
    cf0c:	48 39 d0             	cmp    %rdx,%rax
    cf0f:	73 59                	jae    cf6a <f0+0x1c6a>
    cf11:	48 89 c2             	mov    %rax,%rdx
    cf14:	48 c1 ea 10          	shr    $0x10,%rdx
    cf18:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf1c:	48 8b 15 75 7c 01 00 	mov    0x17c75(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    cf23:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf27:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf2b:	4d 85 e4             	test   %r12,%r12
    cf2e:	74 3a                	je     cf6a <f0+0x1c6a>
    cf30:	0f b6 0a             	movzbl (%rdx),%ecx
    cf33:	80 f9 02             	cmp    $0x2,%cl
    cf36:	0f 84 84 0c 00 00    	je     dbc0 <f0+0x28c0>
    cf3c:	80 f9 01             	cmp    $0x1,%cl
    cf3f:	75 29                	jne    cf6a <f0+0x1c6a>
    cf41:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf44:	0f b7 c0             	movzwl %ax,%eax
    cf47:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf4a:	48 0f af c1          	imul   %rcx,%rax
    cf4e:	48 c1 e8 20          	shr    $0x20,%rax
    cf52:	48 39 d0             	cmp    %rdx,%rax
    cf55:	73 13                	jae    cf6a <f0+0x1c6a>
    cf57:	49 01 c4             	add    %rax,%r12
    cf5a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf5f:	0f 84 9d 0f 00 00    	je     df02 <f0+0x2c02>
    cf65:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf6a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cf71:	33 f3 bf 
    cf74:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    cf7b:	00 
    cf7c:	bf 01 00 00 00       	mov    $0x1,%edi
    cf81:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    cf88:	00 
    cf89:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    cf90:	00 
    cf91:	e8 1a 94 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    cf96:	48 8b 15 db 7b 01 00 	mov    0x17bdb(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    cf9d:	49 89 c5             	mov    %rax,%r13
    cfa0:	48 2b 05 a9 7b 01 00 	sub    0x17ba9(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    cfa7:	48 c1 e2 10          	shl    $0x10,%rdx
    cfab:	48 39 d0             	cmp    %rdx,%rax
    cfae:	73 59                	jae    d009 <f0+0x1d09>
    cfb0:	48 89 c2             	mov    %rax,%rdx
    cfb3:	48 c1 ea 10          	shr    $0x10,%rdx
    cfb7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cfbb:	48 8b 15 d6 7b 01 00 	mov    0x17bd6(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    cfc2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cfc6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cfca:	4d 85 e4             	test   %r12,%r12
    cfcd:	74 3a                	je     d009 <f0+0x1d09>
    cfcf:	0f b6 0a             	movzbl (%rdx),%ecx
    cfd2:	80 f9 02             	cmp    $0x2,%cl
    cfd5:	0f 84 d5 0b 00 00    	je     dbb0 <f0+0x28b0>
    cfdb:	80 f9 01             	cmp    $0x1,%cl
    cfde:	75 29                	jne    d009 <f0+0x1d09>
    cfe0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfe3:	0f b7 c0             	movzwl %ax,%eax
    cfe6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cfe9:	48 0f af c1          	imul   %rcx,%rax
    cfed:	48 c1 e8 20          	shr    $0x20,%rax
    cff1:	48 39 d0             	cmp    %rdx,%rax
    cff4:	73 13                	jae    d009 <f0+0x1d09>
    cff6:	49 01 c4             	add    %rax,%r12
    cff9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cffe:	0f 84 0b 0f 00 00    	je     df0f <f0+0x2c0f>
    d004:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d009:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d010:	00 f0 3f 
    d013:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    d01a:	00 
    d01b:	bf 01 00 00 00       	mov    $0x1,%edi
    d020:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    d027:	00 
    d028:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    d02f:	00 
    d030:	e8 7b 93 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    d035:	48 8b 15 3c 7b 01 00 	mov    0x17b3c(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    d03c:	49 89 c5             	mov    %rax,%r13
    d03f:	48 2b 05 0a 7b 01 00 	sub    0x17b0a(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    d046:	48 c1 e2 10          	shl    $0x10,%rdx
    d04a:	48 39 d0             	cmp    %rdx,%rax
    d04d:	73 59                	jae    d0a8 <f0+0x1da8>
    d04f:	48 89 c2             	mov    %rax,%rdx
    d052:	48 c1 ea 10          	shr    $0x10,%rdx
    d056:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d05a:	48 8b 15 37 7b 01 00 	mov    0x17b37(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    d061:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d065:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d069:	4d 85 e4             	test   %r12,%r12
    d06c:	74 3a                	je     d0a8 <f0+0x1da8>
    d06e:	0f b6 0a             	movzbl (%rdx),%ecx
    d071:	80 f9 02             	cmp    $0x2,%cl
    d074:	0f 84 26 0b 00 00    	je     dba0 <f0+0x28a0>
    d07a:	80 f9 01             	cmp    $0x1,%cl
    d07d:	75 29                	jne    d0a8 <f0+0x1da8>
    d07f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d082:	0f b7 c0             	movzwl %ax,%eax
    d085:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d088:	48 0f af c1          	imul   %rcx,%rax
    d08c:	48 c1 e8 20          	shr    $0x20,%rax
    d090:	48 39 d0             	cmp    %rdx,%rax
    d093:	73 13                	jae    d0a8 <f0+0x1da8>
    d095:	49 01 c4             	add    %rax,%r12
    d098:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d09d:	0f 84 79 0e 00 00    	je     df1c <f0+0x2c1c>
    d0a3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0a8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d0af:	33 f3 bf 
    d0b2:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    d0b9:	00 
    d0ba:	bf 01 00 00 00       	mov    $0x1,%edi
    d0bf:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    d0c6:	00 
    d0c7:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    d0ce:	00 
    d0cf:	e8 dc 92 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    d0d4:	48 8b 15 9d 7a 01 00 	mov    0x17a9d(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    d0db:	49 89 c5             	mov    %rax,%r13
    d0de:	48 2b 05 6b 7a 01 00 	sub    0x17a6b(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    d0e5:	48 c1 e2 10          	shl    $0x10,%rdx
    d0e9:	48 39 d0             	cmp    %rdx,%rax
    d0ec:	73 59                	jae    d147 <f0+0x1e47>
    d0ee:	48 89 c2             	mov    %rax,%rdx
    d0f1:	48 c1 ea 10          	shr    $0x10,%rdx
    d0f5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0f9:	48 8b 15 98 7a 01 00 	mov    0x17a98(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    d100:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d104:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d108:	4d 85 e4             	test   %r12,%r12
    d10b:	74 3a                	je     d147 <f0+0x1e47>
    d10d:	0f b6 0a             	movzbl (%rdx),%ecx
    d110:	80 f9 02             	cmp    $0x2,%cl
    d113:	0f 84 77 0a 00 00    	je     db90 <f0+0x2890>
    d119:	80 f9 01             	cmp    $0x1,%cl
    d11c:	75 29                	jne    d147 <f0+0x1e47>
    d11e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d121:	0f b7 c0             	movzwl %ax,%eax
    d124:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d127:	48 0f af c1          	imul   %rcx,%rax
    d12b:	48 c1 e8 20          	shr    $0x20,%rax
    d12f:	48 39 d0             	cmp    %rdx,%rax
    d132:	73 13                	jae    d147 <f0+0x1e47>
    d134:	49 01 c4             	add    %rax,%r12
    d137:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d13c:	0f 84 e7 0d 00 00    	je     df29 <f0+0x2c29>
    d142:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d147:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d14e:	00 f0 3f 
    d151:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    d158:	00 
    d159:	bf 01 00 00 00       	mov    $0x1,%edi
    d15e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    d165:	00 
    d166:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    d16d:	00 
    d16e:	e8 3d 92 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    d173:	48 8b 15 fe 79 01 00 	mov    0x179fe(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    d17a:	49 89 c5             	mov    %rax,%r13
    d17d:	48 2b 05 cc 79 01 00 	sub    0x179cc(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    d184:	48 c1 e2 10          	shl    $0x10,%rdx
    d188:	48 39 d0             	cmp    %rdx,%rax
    d18b:	73 59                	jae    d1e6 <f0+0x1ee6>
    d18d:	48 89 c2             	mov    %rax,%rdx
    d190:	48 c1 ea 10          	shr    $0x10,%rdx
    d194:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d198:	48 8b 15 f9 79 01 00 	mov    0x179f9(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    d19f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d1a3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d1a7:	4d 85 e4             	test   %r12,%r12
    d1aa:	74 3a                	je     d1e6 <f0+0x1ee6>
    d1ac:	0f b6 0a             	movzbl (%rdx),%ecx
    d1af:	80 f9 02             	cmp    $0x2,%cl
    d1b2:	0f 84 38 0c 00 00    	je     ddf0 <f0+0x2af0>
    d1b8:	80 f9 01             	cmp    $0x1,%cl
    d1bb:	75 29                	jne    d1e6 <f0+0x1ee6>
    d1bd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d1c0:	0f b7 c0             	movzwl %ax,%eax
    d1c3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d1c6:	48 0f af c1          	imul   %rcx,%rax
    d1ca:	48 c1 e8 20          	shr    $0x20,%rax
    d1ce:	48 39 d0             	cmp    %rdx,%rax
    d1d1:	73 13                	jae    d1e6 <f0+0x1ee6>
    d1d3:	49 01 c4             	add    %rax,%r12
    d1d6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d1db:	0f 84 55 0d 00 00    	je     df36 <f0+0x2c36>
    d1e1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d1e6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d1ed:	33 f3 bf 
    d1f0:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    d1f7:	00 
    d1f8:	bf 01 00 00 00       	mov    $0x1,%edi
    d1fd:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    d204:	00 
    d205:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    d20c:	00 
    d20d:	e8 9e 91 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    d212:	48 8b 15 5f 79 01 00 	mov    0x1795f(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    d219:	49 89 c5             	mov    %rax,%r13
    d21c:	48 2b 05 2d 79 01 00 	sub    0x1792d(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    d223:	48 c1 e2 10          	shl    $0x10,%rdx
    d227:	48 39 d0             	cmp    %rdx,%rax
    d22a:	73 59                	jae    d285 <f0+0x1f85>
    d22c:	48 89 c2             	mov    %rax,%rdx
    d22f:	48 c1 ea 10          	shr    $0x10,%rdx
    d233:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d237:	48 8b 15 5a 79 01 00 	mov    0x1795a(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    d23e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d242:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d246:	4d 85 e4             	test   %r12,%r12
    d249:	74 3a                	je     d285 <f0+0x1f85>
    d24b:	0f b6 0a             	movzbl (%rdx),%ecx
    d24e:	80 f9 02             	cmp    $0x2,%cl
    d251:	0f 84 89 0b 00 00    	je     dde0 <f0+0x2ae0>
    d257:	80 f9 01             	cmp    $0x1,%cl
    d25a:	75 29                	jne    d285 <f0+0x1f85>
    d25c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d25f:	0f b7 c0             	movzwl %ax,%eax
    d262:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d265:	48 0f af c1          	imul   %rcx,%rax
    d269:	48 c1 e8 20          	shr    $0x20,%rax
    d26d:	48 39 d0             	cmp    %rdx,%rax
    d270:	73 13                	jae    d285 <f0+0x1f85>
    d272:	49 01 c4             	add    %rax,%r12
    d275:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d27a:	0f 84 c3 0c 00 00    	je     df43 <f0+0x2c43>
    d280:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d285:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d28c:	00 f0 3f 
    d28f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    d296:	00 
    d297:	bf 01 00 00 00       	mov    $0x1,%edi
    d29c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    d2a3:	00 
    d2a4:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    d2ab:	00 
    d2ac:	e8 ff 90 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    d2b1:	48 8b 15 c0 78 01 00 	mov    0x178c0(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    d2b8:	49 89 c5             	mov    %rax,%r13
    d2bb:	48 2b 05 8e 78 01 00 	sub    0x1788e(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    d2c2:	48 c1 e2 10          	shl    $0x10,%rdx
    d2c6:	48 39 d0             	cmp    %rdx,%rax
    d2c9:	73 59                	jae    d324 <f0+0x2024>
    d2cb:	48 89 c2             	mov    %rax,%rdx
    d2ce:	48 c1 ea 10          	shr    $0x10,%rdx
    d2d2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d2d6:	48 8b 15 bb 78 01 00 	mov    0x178bb(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    d2dd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d2e1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d2e5:	4d 85 e4             	test   %r12,%r12
    d2e8:	74 3a                	je     d324 <f0+0x2024>
    d2ea:	0f b6 0a             	movzbl (%rdx),%ecx
    d2ed:	80 f9 02             	cmp    $0x2,%cl
    d2f0:	0f 84 da 0a 00 00    	je     ddd0 <f0+0x2ad0>
    d2f6:	80 f9 01             	cmp    $0x1,%cl
    d2f9:	75 29                	jne    d324 <f0+0x2024>
    d2fb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2fe:	0f b7 c0             	movzwl %ax,%eax
    d301:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d304:	48 0f af c1          	imul   %rcx,%rax
    d308:	48 c1 e8 20          	shr    $0x20,%rax
    d30c:	48 39 d0             	cmp    %rdx,%rax
    d30f:	73 13                	jae    d324 <f0+0x2024>
    d311:	49 01 c4             	add    %rax,%r12
    d314:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d319:	0f 84 31 0c 00 00    	je     df50 <f0+0x2c50>
    d31f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d324:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d32b:	33 f3 bf 
    d32e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    d335:	00 
    d336:	bf 01 00 00 00       	mov    $0x1,%edi
    d33b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    d342:	00 
    d343:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    d34a:	00 
    d34b:	e8 60 90 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    d350:	48 8b 15 21 78 01 00 	mov    0x17821(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    d357:	49 89 c5             	mov    %rax,%r13
    d35a:	48 2b 05 ef 77 01 00 	sub    0x177ef(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    d361:	48 c1 e2 10          	shl    $0x10,%rdx
    d365:	48 39 d0             	cmp    %rdx,%rax
    d368:	73 59                	jae    d3c3 <f0+0x20c3>
    d36a:	48 89 c2             	mov    %rax,%rdx
    d36d:	48 c1 ea 10          	shr    $0x10,%rdx
    d371:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d375:	48 8b 15 1c 78 01 00 	mov    0x1781c(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    d37c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d380:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d384:	4d 85 e4             	test   %r12,%r12
    d387:	74 3a                	je     d3c3 <f0+0x20c3>
    d389:	0f b6 0a             	movzbl (%rdx),%ecx
    d38c:	80 f9 02             	cmp    $0x2,%cl
    d38f:	0f 84 2b 0a 00 00    	je     ddc0 <f0+0x2ac0>
    d395:	80 f9 01             	cmp    $0x1,%cl
    d398:	75 29                	jne    d3c3 <f0+0x20c3>
    d39a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d39d:	0f b7 c0             	movzwl %ax,%eax
    d3a0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d3a3:	48 0f af c1          	imul   %rcx,%rax
    d3a7:	48 c1 e8 20          	shr    $0x20,%rax
    d3ab:	48 39 d0             	cmp    %rdx,%rax
    d3ae:	73 13                	jae    d3c3 <f0+0x20c3>
    d3b0:	49 01 c4             	add    %rax,%r12
    d3b3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d3b8:	0f 84 9f 0b 00 00    	je     df5d <f0+0x2c5d>
    d3be:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d3c3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d3ca:	00 f0 3f 
    d3cd:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    d3d4:	00 
    d3d5:	bf 01 00 00 00       	mov    $0x1,%edi
    d3da:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    d3e1:	00 
    d3e2:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    d3e9:	00 
    d3ea:	e8 c1 8f ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    d3ef:	48 8b 15 82 77 01 00 	mov    0x17782(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    d3f6:	49 89 c5             	mov    %rax,%r13
    d3f9:	48 2b 05 50 77 01 00 	sub    0x17750(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    d400:	48 c1 e2 10          	shl    $0x10,%rdx
    d404:	48 39 d0             	cmp    %rdx,%rax
    d407:	73 59                	jae    d462 <f0+0x2162>
    d409:	48 89 c2             	mov    %rax,%rdx
    d40c:	48 c1 ea 10          	shr    $0x10,%rdx
    d410:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d414:	48 8b 15 7d 77 01 00 	mov    0x1777d(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    d41b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d41f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d423:	4d 85 e4             	test   %r12,%r12
    d426:	74 3a                	je     d462 <f0+0x2162>
    d428:	0f b6 0a             	movzbl (%rdx),%ecx
    d42b:	80 f9 02             	cmp    $0x2,%cl
    d42e:	0f 84 7c 09 00 00    	je     ddb0 <f0+0x2ab0>
    d434:	80 f9 01             	cmp    $0x1,%cl
    d437:	75 29                	jne    d462 <f0+0x2162>
    d439:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d43c:	0f b7 c0             	movzwl %ax,%eax
    d43f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d442:	48 0f af c1          	imul   %rcx,%rax
    d446:	48 c1 e8 20          	shr    $0x20,%rax
    d44a:	48 39 d0             	cmp    %rdx,%rax
    d44d:	73 13                	jae    d462 <f0+0x2162>
    d44f:	49 01 c4             	add    %rax,%r12
    d452:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d457:	0f 84 0d 0b 00 00    	je     df6a <f0+0x2c6a>
    d45d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d462:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d469:	33 f3 bf 
    d46c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    d473:	00 
    d474:	bf 01 00 00 00       	mov    $0x1,%edi
    d479:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    d480:	00 
    d481:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    d488:	00 
    d489:	e8 22 8f ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    d48e:	48 8b 15 e3 76 01 00 	mov    0x176e3(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    d495:	49 89 c5             	mov    %rax,%r13
    d498:	48 2b 05 b1 76 01 00 	sub    0x176b1(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    d49f:	48 c1 e2 10          	shl    $0x10,%rdx
    d4a3:	48 39 d0             	cmp    %rdx,%rax
    d4a6:	73 59                	jae    d501 <f0+0x2201>
    d4a8:	48 89 c2             	mov    %rax,%rdx
    d4ab:	48 c1 ea 10          	shr    $0x10,%rdx
    d4af:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d4b3:	48 8b 15 de 76 01 00 	mov    0x176de(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    d4ba:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d4be:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d4c2:	4d 85 e4             	test   %r12,%r12
    d4c5:	74 3a                	je     d501 <f0+0x2201>
    d4c7:	0f b6 0a             	movzbl (%rdx),%ecx
    d4ca:	80 f9 02             	cmp    $0x2,%cl
    d4cd:	0f 84 cd 08 00 00    	je     dda0 <f0+0x2aa0>
    d4d3:	80 f9 01             	cmp    $0x1,%cl
    d4d6:	75 29                	jne    d501 <f0+0x2201>
    d4d8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d4db:	0f b7 c0             	movzwl %ax,%eax
    d4de:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d4e1:	48 0f af c1          	imul   %rcx,%rax
    d4e5:	48 c1 e8 20          	shr    $0x20,%rax
    d4e9:	48 39 d0             	cmp    %rdx,%rax
    d4ec:	73 13                	jae    d501 <f0+0x2201>
    d4ee:	49 01 c4             	add    %rax,%r12
    d4f1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d4f6:	0f 84 7b 0a 00 00    	je     df77 <f0+0x2c77>
    d4fc:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d501:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d508:	00 f0 3f 
    d50b:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    d512:	00 
    d513:	bf 01 00 00 00       	mov    $0x1,%edi
    d518:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    d51f:	00 
    d520:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    d527:	00 
    d528:	e8 83 8e ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    d52d:	48 8b 15 44 76 01 00 	mov    0x17644(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    d534:	49 89 c5             	mov    %rax,%r13
    d537:	48 2b 05 12 76 01 00 	sub    0x17612(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    d53e:	48 c1 e2 10          	shl    $0x10,%rdx
    d542:	48 39 d0             	cmp    %rdx,%rax
    d545:	73 59                	jae    d5a0 <f0+0x22a0>
    d547:	48 89 c2             	mov    %rax,%rdx
    d54a:	48 c1 ea 10          	shr    $0x10,%rdx
    d54e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d552:	48 8b 15 3f 76 01 00 	mov    0x1763f(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    d559:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d55d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d561:	4d 85 e4             	test   %r12,%r12
    d564:	74 3a                	je     d5a0 <f0+0x22a0>
    d566:	0f b6 0a             	movzbl (%rdx),%ecx
    d569:	80 f9 02             	cmp    $0x2,%cl
    d56c:	0f 84 1e 08 00 00    	je     dd90 <f0+0x2a90>
    d572:	80 f9 01             	cmp    $0x1,%cl
    d575:	75 29                	jne    d5a0 <f0+0x22a0>
    d577:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d57a:	0f b7 c0             	movzwl %ax,%eax
    d57d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d580:	48 0f af c1          	imul   %rcx,%rax
    d584:	48 c1 e8 20          	shr    $0x20,%rax
    d588:	48 39 d0             	cmp    %rdx,%rax
    d58b:	73 13                	jae    d5a0 <f0+0x22a0>
    d58d:	49 01 c4             	add    %rax,%r12
    d590:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d595:	0f 84 e9 09 00 00    	je     df84 <f0+0x2c84>
    d59b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d5a0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d5a7:	33 f3 bf 
    d5aa:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    d5b1:	00 
    d5b2:	bf 01 00 00 00       	mov    $0x1,%edi
    d5b7:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    d5be:	00 
    d5bf:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    d5c6:	00 
    d5c7:	e8 e4 8d ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    d5cc:	48 8b 15 a5 75 01 00 	mov    0x175a5(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    d5d3:	49 89 c5             	mov    %rax,%r13
    d5d6:	48 2b 05 73 75 01 00 	sub    0x17573(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    d5dd:	48 c1 e2 10          	shl    $0x10,%rdx
    d5e1:	48 39 d0             	cmp    %rdx,%rax
    d5e4:	73 59                	jae    d63f <f0+0x233f>
    d5e6:	48 89 c2             	mov    %rax,%rdx
    d5e9:	48 c1 ea 10          	shr    $0x10,%rdx
    d5ed:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d5f1:	48 8b 15 a0 75 01 00 	mov    0x175a0(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    d5f8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d5fc:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d600:	4d 85 e4             	test   %r12,%r12
    d603:	74 3a                	je     d63f <f0+0x233f>
    d605:	0f b6 0a             	movzbl (%rdx),%ecx
    d608:	80 f9 02             	cmp    $0x2,%cl
    d60b:	0f 84 6f 07 00 00    	je     dd80 <f0+0x2a80>
    d611:	80 f9 01             	cmp    $0x1,%cl
    d614:	75 29                	jne    d63f <f0+0x233f>
    d616:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d619:	0f b7 c0             	movzwl %ax,%eax
    d61c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d61f:	48 0f af c1          	imul   %rcx,%rax
    d623:	48 c1 e8 20          	shr    $0x20,%rax
    d627:	48 39 d0             	cmp    %rdx,%rax
    d62a:	73 13                	jae    d63f <f0+0x233f>
    d62c:	49 01 c4             	add    %rax,%r12
    d62f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d634:	0f 84 57 09 00 00    	je     df91 <f0+0x2c91>
    d63a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d63f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d646:	00 f0 3f 
    d649:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    d650:	00 
    d651:	bf 01 00 00 00       	mov    $0x1,%edi
    d656:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    d65d:	00 
    d65e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    d665:	00 
    d666:	e8 45 8d ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    d66b:	48 8b 15 06 75 01 00 	mov    0x17506(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    d672:	49 89 c5             	mov    %rax,%r13
    d675:	48 2b 05 d4 74 01 00 	sub    0x174d4(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    d67c:	48 c1 e2 10          	shl    $0x10,%rdx
    d680:	48 39 d0             	cmp    %rdx,%rax
    d683:	73 59                	jae    d6de <f0+0x23de>
    d685:	48 89 c2             	mov    %rax,%rdx
    d688:	48 c1 ea 10          	shr    $0x10,%rdx
    d68c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d690:	48 8b 15 01 75 01 00 	mov    0x17501(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    d697:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d69b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d69f:	4d 85 e4             	test   %r12,%r12
    d6a2:	74 3a                	je     d6de <f0+0x23de>
    d6a4:	0f b6 0a             	movzbl (%rdx),%ecx
    d6a7:	80 f9 02             	cmp    $0x2,%cl
    d6aa:	0f 84 c0 06 00 00    	je     dd70 <f0+0x2a70>
    d6b0:	80 f9 01             	cmp    $0x1,%cl
    d6b3:	75 29                	jne    d6de <f0+0x23de>
    d6b5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d6b8:	0f b7 c0             	movzwl %ax,%eax
    d6bb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d6be:	48 0f af c1          	imul   %rcx,%rax
    d6c2:	48 c1 e8 20          	shr    $0x20,%rax
    d6c6:	48 39 d0             	cmp    %rdx,%rax
    d6c9:	73 13                	jae    d6de <f0+0x23de>
    d6cb:	49 01 c4             	add    %rax,%r12
    d6ce:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d6d3:	0f 84 c5 08 00 00    	je     df9e <f0+0x2c9e>
    d6d9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d6de:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d6e5:	33 f3 bf 
    d6e8:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    d6ef:	00 
    d6f0:	bf 01 00 00 00       	mov    $0x1,%edi
    d6f5:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    d6fc:	00 
    d6fd:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    d704:	00 
    d705:	e8 a6 8c ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    d70a:	48 8b 15 67 74 01 00 	mov    0x17467(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    d711:	49 89 c5             	mov    %rax,%r13
    d714:	48 2b 05 35 74 01 00 	sub    0x17435(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    d71b:	48 c1 e2 10          	shl    $0x10,%rdx
    d71f:	48 39 d0             	cmp    %rdx,%rax
    d722:	73 59                	jae    d77d <f0+0x247d>
    d724:	48 89 c2             	mov    %rax,%rdx
    d727:	48 c1 ea 10          	shr    $0x10,%rdx
    d72b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d72f:	48 8b 15 62 74 01 00 	mov    0x17462(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    d736:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d73a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d73e:	4d 85 e4             	test   %r12,%r12
    d741:	74 3a                	je     d77d <f0+0x247d>
    d743:	0f b6 0a             	movzbl (%rdx),%ecx
    d746:	80 f9 02             	cmp    $0x2,%cl
    d749:	0f 84 11 06 00 00    	je     dd60 <f0+0x2a60>
    d74f:	80 f9 01             	cmp    $0x1,%cl
    d752:	75 29                	jne    d77d <f0+0x247d>
    d754:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d757:	0f b7 c0             	movzwl %ax,%eax
    d75a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d75d:	48 0f af c1          	imul   %rcx,%rax
    d761:	48 c1 e8 20          	shr    $0x20,%rax
    d765:	48 39 d0             	cmp    %rdx,%rax
    d768:	73 13                	jae    d77d <f0+0x247d>
    d76a:	49 01 c4             	add    %rax,%r12
    d76d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d772:	0f 84 33 08 00 00    	je     dfab <f0+0x2cab>
    d778:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d77d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d784:	00 f0 3f 
    d787:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    d78e:	00 
    d78f:	bf 01 00 00 00       	mov    $0x1,%edi
    d794:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    d79b:	00 
    d79c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    d7a3:	00 
    d7a4:	e8 07 8c ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    d7a9:	48 8b 15 c8 73 01 00 	mov    0x173c8(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    d7b0:	49 89 c5             	mov    %rax,%r13
    d7b3:	48 2b 05 96 73 01 00 	sub    0x17396(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    d7ba:	48 c1 e2 10          	shl    $0x10,%rdx
    d7be:	48 39 d0             	cmp    %rdx,%rax
    d7c1:	73 59                	jae    d81c <f0+0x251c>
    d7c3:	48 89 c2             	mov    %rax,%rdx
    d7c6:	48 c1 ea 10          	shr    $0x10,%rdx
    d7ca:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d7ce:	48 8b 15 c3 73 01 00 	mov    0x173c3(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    d7d5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d7d9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d7dd:	4d 85 e4             	test   %r12,%r12
    d7e0:	74 3a                	je     d81c <f0+0x251c>
    d7e2:	0f b6 0a             	movzbl (%rdx),%ecx
    d7e5:	80 f9 02             	cmp    $0x2,%cl
    d7e8:	0f 84 62 05 00 00    	je     dd50 <f0+0x2a50>
    d7ee:	80 f9 01             	cmp    $0x1,%cl
    d7f1:	75 29                	jne    d81c <f0+0x251c>
    d7f3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d7f6:	0f b7 c0             	movzwl %ax,%eax
    d7f9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d7fc:	48 0f af c1          	imul   %rcx,%rax
    d800:	48 c1 e8 20          	shr    $0x20,%rax
    d804:	48 39 d0             	cmp    %rdx,%rax
    d807:	73 13                	jae    d81c <f0+0x251c>
    d809:	49 01 c4             	add    %rax,%r12
    d80c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d811:	0f 84 a1 07 00 00    	je     dfb8 <f0+0x2cb8>
    d817:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d81c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d823:	33 f3 bf 
    d826:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    d82d:	00 
    d82e:	bf 01 00 00 00       	mov    $0x1,%edi
    d833:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    d83a:	00 
    d83b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    d842:	00 
    d843:	e8 68 8b ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    d848:	48 8b 15 29 73 01 00 	mov    0x17329(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    d84f:	49 89 c5             	mov    %rax,%r13
    d852:	48 2b 05 f7 72 01 00 	sub    0x172f7(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    d859:	48 c1 e2 10          	shl    $0x10,%rdx
    d85d:	48 39 d0             	cmp    %rdx,%rax
    d860:	73 59                	jae    d8bb <f0+0x25bb>
    d862:	48 89 c2             	mov    %rax,%rdx
    d865:	48 c1 ea 10          	shr    $0x10,%rdx
    d869:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d86d:	48 8b 15 24 73 01 00 	mov    0x17324(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    d874:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d878:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d87c:	4d 85 e4             	test   %r12,%r12
    d87f:	74 3a                	je     d8bb <f0+0x25bb>
    d881:	0f b6 0a             	movzbl (%rdx),%ecx
    d884:	80 f9 02             	cmp    $0x2,%cl
    d887:	0f 84 b3 04 00 00    	je     dd40 <f0+0x2a40>
    d88d:	80 f9 01             	cmp    $0x1,%cl
    d890:	75 29                	jne    d8bb <f0+0x25bb>
    d892:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d895:	0f b7 c0             	movzwl %ax,%eax
    d898:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d89b:	48 0f af c1          	imul   %rcx,%rax
    d89f:	48 c1 e8 20          	shr    $0x20,%rax
    d8a3:	48 39 d0             	cmp    %rdx,%rax
    d8a6:	73 13                	jae    d8bb <f0+0x25bb>
    d8a8:	49 01 c4             	add    %rax,%r12
    d8ab:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d8b0:	0f 84 0f 07 00 00    	je     dfc5 <f0+0x2cc5>
    d8b6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d8bb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d8c2:	00 f0 3f 
    d8c5:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    d8cc:	00 
    d8cd:	bf 01 00 00 00       	mov    $0x1,%edi
    d8d2:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    d8d9:	00 
    d8da:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    d8e1:	00 
    d8e2:	e8 c9 8a ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    d8e7:	48 8b 15 8a 72 01 00 	mov    0x1728a(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    d8ee:	49 89 c5             	mov    %rax,%r13
    d8f1:	48 2b 05 58 72 01 00 	sub    0x17258(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    d8f8:	48 c1 e2 10          	shl    $0x10,%rdx
    d8fc:	48 39 d0             	cmp    %rdx,%rax
    d8ff:	73 59                	jae    d95a <f0+0x265a>
    d901:	48 89 c2             	mov    %rax,%rdx
    d904:	48 c1 ea 10          	shr    $0x10,%rdx
    d908:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d90c:	48 8b 15 85 72 01 00 	mov    0x17285(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    d913:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d917:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d91b:	4d 85 e4             	test   %r12,%r12
    d91e:	74 3a                	je     d95a <f0+0x265a>
    d920:	0f b6 0a             	movzbl (%rdx),%ecx
    d923:	80 f9 02             	cmp    $0x2,%cl
    d926:	0f 84 04 04 00 00    	je     dd30 <f0+0x2a30>
    d92c:	80 f9 01             	cmp    $0x1,%cl
    d92f:	75 29                	jne    d95a <f0+0x265a>
    d931:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d934:	0f b7 c0             	movzwl %ax,%eax
    d937:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d93a:	48 0f af c1          	imul   %rcx,%rax
    d93e:	48 c1 e8 20          	shr    $0x20,%rax
    d942:	48 39 d0             	cmp    %rdx,%rax
    d945:	73 13                	jae    d95a <f0+0x265a>
    d947:	49 01 c4             	add    %rax,%r12
    d94a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d94f:	0f 84 7d 06 00 00    	je     dfd2 <f0+0x2cd2>
    d955:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d95a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d961:	33 f3 bf 
    d964:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    d96b:	00 
    d96c:	bf 01 00 00 00       	mov    $0x1,%edi
    d971:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    d978:	00 
    d979:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    d980:	00 
    d981:	e8 2a 8a ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    d986:	48 8b 15 eb 71 01 00 	mov    0x171eb(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    d98d:	49 89 c5             	mov    %rax,%r13
    d990:	48 2b 05 b9 71 01 00 	sub    0x171b9(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    d997:	48 c1 e2 10          	shl    $0x10,%rdx
    d99b:	48 39 d0             	cmp    %rdx,%rax
    d99e:	73 59                	jae    d9f9 <f0+0x26f9>
    d9a0:	48 89 c2             	mov    %rax,%rdx
    d9a3:	48 c1 ea 10          	shr    $0x10,%rdx
    d9a7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d9ab:	48 8b 15 e6 71 01 00 	mov    0x171e6(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    d9b2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d9b6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d9ba:	4d 85 e4             	test   %r12,%r12
    d9bd:	74 3a                	je     d9f9 <f0+0x26f9>
    d9bf:	0f b6 0a             	movzbl (%rdx),%ecx
    d9c2:	80 f9 02             	cmp    $0x2,%cl
    d9c5:	0f 84 55 03 00 00    	je     dd20 <f0+0x2a20>
    d9cb:	80 f9 01             	cmp    $0x1,%cl
    d9ce:	75 29                	jne    d9f9 <f0+0x26f9>
    d9d0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d9d3:	0f b7 c0             	movzwl %ax,%eax
    d9d6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d9d9:	48 0f af c1          	imul   %rcx,%rax
    d9dd:	48 c1 e8 20          	shr    $0x20,%rax
    d9e1:	48 39 d0             	cmp    %rdx,%rax
    d9e4:	73 13                	jae    d9f9 <f0+0x26f9>
    d9e6:	49 01 c4             	add    %rax,%r12
    d9e9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d9ee:	0f 84 eb 05 00 00    	je     dfdf <f0+0x2cdf>
    d9f4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d9f9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    da00:	00 f0 3f 
    da03:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    da0a:	00 
    da0b:	bf 01 00 00 00       	mov    $0x1,%edi
    da10:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    da17:	00 
    da18:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    da1f:	00 
    da20:	e8 8b 89 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    da25:	48 8b 15 4c 71 01 00 	mov    0x1714c(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    da2c:	49 89 c5             	mov    %rax,%r13
    da2f:	48 2b 05 1a 71 01 00 	sub    0x1711a(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    da36:	48 c1 e2 10          	shl    $0x10,%rdx
    da3a:	48 39 d0             	cmp    %rdx,%rax
    da3d:	73 59                	jae    da98 <f0+0x2798>
    da3f:	48 89 c2             	mov    %rax,%rdx
    da42:	48 c1 ea 10          	shr    $0x10,%rdx
    da46:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    da4a:	48 8b 15 47 71 01 00 	mov    0x17147(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    da51:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    da55:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    da59:	4d 85 e4             	test   %r12,%r12
    da5c:	74 3a                	je     da98 <f0+0x2798>
    da5e:	0f b6 0a             	movzbl (%rdx),%ecx
    da61:	80 f9 02             	cmp    $0x2,%cl
    da64:	0f 84 a6 02 00 00    	je     dd10 <f0+0x2a10>
    da6a:	80 f9 01             	cmp    $0x1,%cl
    da6d:	75 29                	jne    da98 <f0+0x2798>
    da6f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    da72:	0f b7 c0             	movzwl %ax,%eax
    da75:	8b 52 1c             	mov    0x1c(%rdx),%edx
    da78:	48 0f af c1          	imul   %rcx,%rax
    da7c:	48 c1 e8 20          	shr    $0x20,%rax
    da80:	48 39 d0             	cmp    %rdx,%rax
    da83:	73 13                	jae    da98 <f0+0x2798>
    da85:	49 01 c4             	add    %rax,%r12
    da88:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    da8d:	0f 84 59 05 00 00    	je     dfec <f0+0x2cec>
    da93:	41 c6 04 24 01       	movb   $0x1,(%r12)
    da98:	48 89 ee             	mov    %rbp,%rsi
    da9b:	bf 01 00 00 00       	mov    $0x1,%edi
    daa0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    daa7:	33 f3 bf 
    daaa:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    dab1:	00 
    dab2:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    dab9:	00 
    daba:	e8 f1 88 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    dabf:	48 8b 15 b2 70 01 00 	mov    0x170b2(%rip),%rdx        # 24b78 <fwp_heap+0x13d8>
    dac6:	48 89 c5             	mov    %rax,%rbp
    dac9:	48 2b 05 80 70 01 00 	sub    0x17080(%rip),%rax        # 24b50 <fwp_heap+0x13b0>
    dad0:	48 c1 e2 10          	shl    $0x10,%rdx
    dad4:	48 39 d0             	cmp    %rdx,%rax
    dad7:	73 59                	jae    db32 <f0+0x2832>
    dad9:	48 89 c2             	mov    %rax,%rdx
    dadc:	48 c1 ea 10          	shr    $0x10,%rdx
    dae0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dae4:	48 8b 15 ad 70 01 00 	mov    0x170ad(%rip),%rdx        # 24b98 <fwp_heap+0x13f8>
    daeb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    daef:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    daf3:	4d 85 e4             	test   %r12,%r12
    daf6:	74 3a                	je     db32 <f0+0x2832>
    daf8:	0f b6 0a             	movzbl (%rdx),%ecx
    dafb:	80 f9 02             	cmp    $0x2,%cl
    dafe:	0f 84 fc 01 00 00    	je     dd00 <f0+0x2a00>
    db04:	80 f9 01             	cmp    $0x1,%cl
    db07:	75 29                	jne    db32 <f0+0x2832>
    db09:	8b 4a 18             	mov    0x18(%rdx),%ecx
    db0c:	0f b7 c0             	movzwl %ax,%eax
    db0f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    db12:	48 0f af c1          	imul   %rcx,%rax
    db16:	48 c1 e8 20          	shr    $0x20,%rax
    db1a:	48 39 d0             	cmp    %rdx,%rax
    db1d:	73 13                	jae    db32 <f0+0x2832>
    db1f:	49 01 c4             	add    %rax,%r12
    db22:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    db27:	0f 84 d1 02 00 00    	je     ddfe <f0+0x2afe>
    db2d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    db32:	48 89 de             	mov    %rbx,%rsi
    db35:	48 89 ef             	mov    %rbp,%rdi
    db38:	e8 63 cb ff ff       	call   a6a0 <fwp_hof0.constprop.0>
    db3d:	48 89 ef             	mov    %rbp,%rdi
    db40:	e8 db 8d ff ff       	call   6920 <fwp_drop0>
    db45:	48 89 df             	mov    %rbx,%rdi
    db48:	e8 d3 8d ff ff       	call   6920 <fwp_drop0>
    db4d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    db54:	00 
    db55:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    db5c:	00 00 
    db5e:	0f 85 95 04 00 00    	jne    dff9 <f0+0x2cf9>
    db64:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    db6b:	31 c0                	xor    %eax,%eax
    db6d:	5b                   	pop    %rbx
    db6e:	5d                   	pop    %rbp
    db6f:	41 5c                	pop    %r12
    db71:	41 5d                	pop    %r13
    db73:	41 5e                	pop    %r14
    db75:	c3                   	ret
    db76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    db7d:	00 00 00 
    db80:	4c 89 ef             	mov    %r13,%rdi
    db83:	e8 e8 77 ff ff       	call   5370 <fwp_rc_forget_slot>
    db88:	e9 2c d8 ff ff       	jmp    b3b9 <f0+0xb9>
    db8d:	0f 1f 00             	nopl   (%rax)
    db90:	66 85 c0             	test   %ax,%ax
    db93:	0f 85 ae f5 ff ff    	jne    d147 <f0+0x1e47>
    db99:	e9 99 f5 ff ff       	jmp    d137 <f0+0x1e37>
    db9e:	66 90                	xchg   %ax,%ax
    dba0:	66 85 c0             	test   %ax,%ax
    dba3:	0f 85 ff f4 ff ff    	jne    d0a8 <f0+0x1da8>
    dba9:	e9 ea f4 ff ff       	jmp    d098 <f0+0x1d98>
    dbae:	66 90                	xchg   %ax,%ax
    dbb0:	66 85 c0             	test   %ax,%ax
    dbb3:	0f 85 50 f4 ff ff    	jne    d009 <f0+0x1d09>
    dbb9:	e9 3b f4 ff ff       	jmp    cff9 <f0+0x1cf9>
    dbbe:	66 90                	xchg   %ax,%ax
    dbc0:	66 85 c0             	test   %ax,%ax
    dbc3:	0f 85 a1 f3 ff ff    	jne    cf6a <f0+0x1c6a>
    dbc9:	e9 8c f3 ff ff       	jmp    cf5a <f0+0x1c5a>
    dbce:	66 90                	xchg   %ax,%ax
    dbd0:	66 85 c0             	test   %ax,%ax
    dbd3:	0f 85 f2 f2 ff ff    	jne    cecb <f0+0x1bcb>
    dbd9:	e9 dd f2 ff ff       	jmp    cebb <f0+0x1bbb>
    dbde:	66 90                	xchg   %ax,%ax
    dbe0:	66 85 c0             	test   %ax,%ax
    dbe3:	0f 85 43 f2 ff ff    	jne    ce2c <f0+0x1b2c>
    dbe9:	e9 2e f2 ff ff       	jmp    ce1c <f0+0x1b1c>
    dbee:	66 90                	xchg   %ax,%ax
    dbf0:	66 85 c0             	test   %ax,%ax
    dbf3:	0f 85 94 f1 ff ff    	jne    cd8d <f0+0x1a8d>
    dbf9:	e9 7f f1 ff ff       	jmp    cd7d <f0+0x1a7d>
    dbfe:	66 90                	xchg   %ax,%ax
    dc00:	66 85 c0             	test   %ax,%ax
    dc03:	0f 85 e5 f0 ff ff    	jne    ccee <f0+0x19ee>
    dc09:	e9 d0 f0 ff ff       	jmp    ccde <f0+0x19de>
    dc0e:	66 90                	xchg   %ax,%ax
    dc10:	66 85 c0             	test   %ax,%ax
    dc13:	0f 85 fd d9 ff ff    	jne    b616 <f0+0x316>
    dc19:	e9 e8 d9 ff ff       	jmp    b606 <f0+0x306>
    dc1e:	66 90                	xchg   %ax,%ax
    dc20:	66 85 c0             	test   %ax,%ax
    dc23:	0f 85 57 d9 ff ff    	jne    b580 <f0+0x280>
    dc29:	e9 42 d9 ff ff       	jmp    b570 <f0+0x270>
    dc2e:	66 90                	xchg   %ax,%ax
    dc30:	66 85 c0             	test   %ax,%ax
    dc33:	0f 85 b1 d8 ff ff    	jne    b4ea <f0+0x1ea>
    dc39:	e9 9c d8 ff ff       	jmp    b4da <f0+0x1da>
    dc3e:	66 90                	xchg   %ax,%ax
    dc40:	66 85 c0             	test   %ax,%ax
    dc43:	0f 85 0e eb ff ff    	jne    c757 <f0+0x1457>
    dc49:	e9 f9 ea ff ff       	jmp    c747 <f0+0x1447>
    dc4e:	66 90                	xchg   %ax,%ax
    dc50:	66 85 c0             	test   %ax,%ax
    dc53:	0f 85 5f ea ff ff    	jne    c6b8 <f0+0x13b8>
    dc59:	e9 4a ea ff ff       	jmp    c6a8 <f0+0x13a8>
    dc5e:	66 90                	xchg   %ax,%ax
    dc60:	66 85 c0             	test   %ax,%ax
    dc63:	0f 85 e2 da ff ff    	jne    b74b <f0+0x44b>
    dc69:	e9 cd da ff ff       	jmp    b73b <f0+0x43b>
    dc6e:	66 90                	xchg   %ax,%ax
    dc70:	66 85 c0             	test   %ax,%ax
    dc73:	0f 85 33 da ff ff    	jne    b6ac <f0+0x3ac>
    dc79:	e9 1e da ff ff       	jmp    b69c <f0+0x39c>
    dc7e:	66 90                	xchg   %ax,%ax
    dc80:	66 85 c0             	test   %ax,%ax
    dc83:	0f 85 c6 ef ff ff    	jne    cc4f <f0+0x194f>
    dc89:	e9 b1 ef ff ff       	jmp    cc3f <f0+0x193f>
    dc8e:	66 90                	xchg   %ax,%ax
    dc90:	66 85 c0             	test   %ax,%ax
    dc93:	0f 85 17 ef ff ff    	jne    cbb0 <f0+0x18b0>
    dc99:	e9 02 ef ff ff       	jmp    cba0 <f0+0x18a0>
    dc9e:	66 90                	xchg   %ax,%ax
    dca0:	66 85 c0             	test   %ax,%ax
    dca3:	0f 85 68 ee ff ff    	jne    cb11 <f0+0x1811>
    dca9:	e9 53 ee ff ff       	jmp    cb01 <f0+0x1801>
    dcae:	66 90                	xchg   %ax,%ax
    dcb0:	66 85 c0             	test   %ax,%ax
    dcb3:	0f 85 b9 ed ff ff    	jne    ca72 <f0+0x1772>
    dcb9:	e9 a4 ed ff ff       	jmp    ca62 <f0+0x1762>
    dcbe:	66 90                	xchg   %ax,%ax
    dcc0:	66 85 c0             	test   %ax,%ax
    dcc3:	0f 85 0a ed ff ff    	jne    c9d3 <f0+0x16d3>
    dcc9:	e9 f5 ec ff ff       	jmp    c9c3 <f0+0x16c3>
    dcce:	66 90                	xchg   %ax,%ax
    dcd0:	66 85 c0             	test   %ax,%ax
    dcd3:	0f 85 5b ec ff ff    	jne    c934 <f0+0x1634>
    dcd9:	e9 46 ec ff ff       	jmp    c924 <f0+0x1624>
    dcde:	66 90                	xchg   %ax,%ax
    dce0:	66 85 c0             	test   %ax,%ax
    dce3:	0f 85 ac eb ff ff    	jne    c895 <f0+0x1595>
    dce9:	e9 97 eb ff ff       	jmp    c885 <f0+0x1585>
    dcee:	66 90                	xchg   %ax,%ax
    dcf0:	66 85 c0             	test   %ax,%ax
    dcf3:	0f 85 fd ea ff ff    	jne    c7f6 <f0+0x14f6>
    dcf9:	e9 e8 ea ff ff       	jmp    c7e6 <f0+0x14e6>
    dcfe:	66 90                	xchg   %ax,%ax
    dd00:	66 85 c0             	test   %ax,%ax
    dd03:	0f 85 29 fe ff ff    	jne    db32 <f0+0x2832>
    dd09:	e9 14 fe ff ff       	jmp    db22 <f0+0x2822>
    dd0e:	66 90                	xchg   %ax,%ax
    dd10:	66 85 c0             	test   %ax,%ax
    dd13:	0f 85 7f fd ff ff    	jne    da98 <f0+0x2798>
    dd19:	e9 6a fd ff ff       	jmp    da88 <f0+0x2788>
    dd1e:	66 90                	xchg   %ax,%ax
    dd20:	66 85 c0             	test   %ax,%ax
    dd23:	0f 85 d0 fc ff ff    	jne    d9f9 <f0+0x26f9>
    dd29:	e9 bb fc ff ff       	jmp    d9e9 <f0+0x26e9>
    dd2e:	66 90                	xchg   %ax,%ax
    dd30:	66 85 c0             	test   %ax,%ax
    dd33:	0f 85 21 fc ff ff    	jne    d95a <f0+0x265a>
    dd39:	e9 0c fc ff ff       	jmp    d94a <f0+0x264a>
    dd3e:	66 90                	xchg   %ax,%ax
    dd40:	66 85 c0             	test   %ax,%ax
    dd43:	0f 85 72 fb ff ff    	jne    d8bb <f0+0x25bb>
    dd49:	e9 5d fb ff ff       	jmp    d8ab <f0+0x25ab>
    dd4e:	66 90                	xchg   %ax,%ax
    dd50:	66 85 c0             	test   %ax,%ax
    dd53:	0f 85 c3 fa ff ff    	jne    d81c <f0+0x251c>
    dd59:	e9 ae fa ff ff       	jmp    d80c <f0+0x250c>
    dd5e:	66 90                	xchg   %ax,%ax
    dd60:	66 85 c0             	test   %ax,%ax
    dd63:	0f 85 14 fa ff ff    	jne    d77d <f0+0x247d>
    dd69:	e9 ff f9 ff ff       	jmp    d76d <f0+0x246d>
    dd6e:	66 90                	xchg   %ax,%ax
    dd70:	66 85 c0             	test   %ax,%ax
    dd73:	0f 85 65 f9 ff ff    	jne    d6de <f0+0x23de>
    dd79:	e9 50 f9 ff ff       	jmp    d6ce <f0+0x23ce>
    dd7e:	66 90                	xchg   %ax,%ax
    dd80:	66 85 c0             	test   %ax,%ax
    dd83:	0f 85 b6 f8 ff ff    	jne    d63f <f0+0x233f>
    dd89:	e9 a1 f8 ff ff       	jmp    d62f <f0+0x232f>
    dd8e:	66 90                	xchg   %ax,%ax
    dd90:	66 85 c0             	test   %ax,%ax
    dd93:	0f 85 07 f8 ff ff    	jne    d5a0 <f0+0x22a0>
    dd99:	e9 f2 f7 ff ff       	jmp    d590 <f0+0x2290>
    dd9e:	66 90                	xchg   %ax,%ax
    dda0:	66 85 c0             	test   %ax,%ax
    dda3:	0f 85 58 f7 ff ff    	jne    d501 <f0+0x2201>
    dda9:	e9 43 f7 ff ff       	jmp    d4f1 <f0+0x21f1>
    ddae:	66 90                	xchg   %ax,%ax
    ddb0:	66 85 c0             	test   %ax,%ax
    ddb3:	0f 85 a9 f6 ff ff    	jne    d462 <f0+0x2162>
    ddb9:	e9 94 f6 ff ff       	jmp    d452 <f0+0x2152>
    ddbe:	66 90                	xchg   %ax,%ax
    ddc0:	66 85 c0             	test   %ax,%ax
    ddc3:	0f 85 fa f5 ff ff    	jne    d3c3 <f0+0x20c3>
    ddc9:	e9 e5 f5 ff ff       	jmp    d3b3 <f0+0x20b3>
    ddce:	66 90                	xchg   %ax,%ax
    ddd0:	66 85 c0             	test   %ax,%ax
    ddd3:	0f 85 4b f5 ff ff    	jne    d324 <f0+0x2024>
    ddd9:	e9 36 f5 ff ff       	jmp    d314 <f0+0x2014>
    ddde:	66 90                	xchg   %ax,%ax
    dde0:	66 85 c0             	test   %ax,%ax
    dde3:	0f 85 9c f4 ff ff    	jne    d285 <f0+0x1f85>
    dde9:	e9 87 f4 ff ff       	jmp    d275 <f0+0x1f75>
    ddee:	66 90                	xchg   %ax,%ax
    ddf0:	66 85 c0             	test   %ax,%ax
    ddf3:	0f 85 ed f3 ff ff    	jne    d1e6 <f0+0x1ee6>
    ddf9:	e9 d8 f3 ff ff       	jmp    d1d6 <f0+0x1ed6>
    ddfe:	4c 89 e7             	mov    %r12,%rdi
    de01:	e8 6a 75 ff ff       	call   5370 <fwp_rc_forget_slot>
    de06:	e9 22 fd ff ff       	jmp    db2d <f0+0x282d>
    de0b:	4c 89 e7             	mov    %r12,%rdi
    de0e:	e8 5d 75 ff ff       	call   5370 <fwp_rc_forget_slot>
    de13:	e9 cd d6 ff ff       	jmp    b4e5 <f0+0x1e5>
    de18:	4c 89 e7             	mov    %r12,%rdi
    de1b:	e8 50 75 ff ff       	call   5370 <fwp_rc_forget_slot>
    de20:	e9 56 d7 ff ff       	jmp    b57b <f0+0x27b>
    de25:	4c 89 e7             	mov    %r12,%rdi
    de28:	e8 43 75 ff ff       	call   5370 <fwp_rc_forget_slot>
    de2d:	e9 df d7 ff ff       	jmp    b611 <f0+0x311>
    de32:	4c 89 e7             	mov    %r12,%rdi
    de35:	e8 36 75 ff ff       	call   5370 <fwp_rc_forget_slot>
    de3a:	e9 68 d8 ff ff       	jmp    b6a7 <f0+0x3a7>
    de3f:	4c 89 e7             	mov    %r12,%rdi
    de42:	e8 29 75 ff ff       	call   5370 <fwp_rc_forget_slot>
    de47:	e9 fa d8 ff ff       	jmp    b746 <f0+0x446>
    de4c:	4c 89 e7             	mov    %r12,%rdi
    de4f:	e8 1c 75 ff ff       	call   5370 <fwp_rc_forget_slot>
    de54:	e9 5a e8 ff ff       	jmp    c6b3 <f0+0x13b3>
    de59:	4c 89 e7             	mov    %r12,%rdi
    de5c:	e8 0f 75 ff ff       	call   5370 <fwp_rc_forget_slot>
    de61:	e9 ec e8 ff ff       	jmp    c752 <f0+0x1452>
    de66:	4c 89 e7             	mov    %r12,%rdi
    de69:	e8 02 75 ff ff       	call   5370 <fwp_rc_forget_slot>
    de6e:	e9 7e e9 ff ff       	jmp    c7f1 <f0+0x14f1>
    de73:	4c 89 e7             	mov    %r12,%rdi
    de76:	e8 f5 74 ff ff       	call   5370 <fwp_rc_forget_slot>
    de7b:	e9 10 ea ff ff       	jmp    c890 <f0+0x1590>
    de80:	4c 89 e7             	mov    %r12,%rdi
    de83:	e8 e8 74 ff ff       	call   5370 <fwp_rc_forget_slot>
    de88:	e9 a2 ea ff ff       	jmp    c92f <f0+0x162f>
    de8d:	4c 89 e7             	mov    %r12,%rdi
    de90:	e8 db 74 ff ff       	call   5370 <fwp_rc_forget_slot>
    de95:	e9 34 eb ff ff       	jmp    c9ce <f0+0x16ce>
    de9a:	4c 89 e7             	mov    %r12,%rdi
    de9d:	e8 ce 74 ff ff       	call   5370 <fwp_rc_forget_slot>
    dea2:	e9 c6 eb ff ff       	jmp    ca6d <f0+0x176d>
    dea7:	4c 89 e7             	mov    %r12,%rdi
    deaa:	e8 c1 74 ff ff       	call   5370 <fwp_rc_forget_slot>
    deaf:	e9 58 ec ff ff       	jmp    cb0c <f0+0x180c>
    deb4:	4c 89 e7             	mov    %r12,%rdi
    deb7:	e8 b4 74 ff ff       	call   5370 <fwp_rc_forget_slot>
    debc:	e9 ea ec ff ff       	jmp    cbab <f0+0x18ab>
    dec1:	4c 89 e7             	mov    %r12,%rdi
    dec4:	e8 a7 74 ff ff       	call   5370 <fwp_rc_forget_slot>
    dec9:	e9 7c ed ff ff       	jmp    cc4a <f0+0x194a>
    dece:	4c 89 e7             	mov    %r12,%rdi
    ded1:	e8 9a 74 ff ff       	call   5370 <fwp_rc_forget_slot>
    ded6:	e9 0e ee ff ff       	jmp    cce9 <f0+0x19e9>
    dedb:	4c 89 e7             	mov    %r12,%rdi
    dede:	e8 8d 74 ff ff       	call   5370 <fwp_rc_forget_slot>
    dee3:	e9 a0 ee ff ff       	jmp    cd88 <f0+0x1a88>
    dee8:	4c 89 e7             	mov    %r12,%rdi
    deeb:	e8 80 74 ff ff       	call   5370 <fwp_rc_forget_slot>
    def0:	e9 32 ef ff ff       	jmp    ce27 <f0+0x1b27>
    def5:	4c 89 e7             	mov    %r12,%rdi
    def8:	e8 73 74 ff ff       	call   5370 <fwp_rc_forget_slot>
    defd:	e9 c4 ef ff ff       	jmp    cec6 <f0+0x1bc6>
    df02:	4c 89 e7             	mov    %r12,%rdi
    df05:	e8 66 74 ff ff       	call   5370 <fwp_rc_forget_slot>
    df0a:	e9 56 f0 ff ff       	jmp    cf65 <f0+0x1c65>
    df0f:	4c 89 e7             	mov    %r12,%rdi
    df12:	e8 59 74 ff ff       	call   5370 <fwp_rc_forget_slot>
    df17:	e9 e8 f0 ff ff       	jmp    d004 <f0+0x1d04>
    df1c:	4c 89 e7             	mov    %r12,%rdi
    df1f:	e8 4c 74 ff ff       	call   5370 <fwp_rc_forget_slot>
    df24:	e9 7a f1 ff ff       	jmp    d0a3 <f0+0x1da3>
    df29:	4c 89 e7             	mov    %r12,%rdi
    df2c:	e8 3f 74 ff ff       	call   5370 <fwp_rc_forget_slot>
    df31:	e9 0c f2 ff ff       	jmp    d142 <f0+0x1e42>
    df36:	4c 89 e7             	mov    %r12,%rdi
    df39:	e8 32 74 ff ff       	call   5370 <fwp_rc_forget_slot>
    df3e:	e9 9e f2 ff ff       	jmp    d1e1 <f0+0x1ee1>
    df43:	4c 89 e7             	mov    %r12,%rdi
    df46:	e8 25 74 ff ff       	call   5370 <fwp_rc_forget_slot>
    df4b:	e9 30 f3 ff ff       	jmp    d280 <f0+0x1f80>
    df50:	4c 89 e7             	mov    %r12,%rdi
    df53:	e8 18 74 ff ff       	call   5370 <fwp_rc_forget_slot>
    df58:	e9 c2 f3 ff ff       	jmp    d31f <f0+0x201f>
    df5d:	4c 89 e7             	mov    %r12,%rdi
    df60:	e8 0b 74 ff ff       	call   5370 <fwp_rc_forget_slot>
    df65:	e9 54 f4 ff ff       	jmp    d3be <f0+0x20be>
    df6a:	4c 89 e7             	mov    %r12,%rdi
    df6d:	e8 fe 73 ff ff       	call   5370 <fwp_rc_forget_slot>
    df72:	e9 e6 f4 ff ff       	jmp    d45d <f0+0x215d>
    df77:	4c 89 e7             	mov    %r12,%rdi
    df7a:	e8 f1 73 ff ff       	call   5370 <fwp_rc_forget_slot>
    df7f:	e9 78 f5 ff ff       	jmp    d4fc <f0+0x21fc>
    df84:	4c 89 e7             	mov    %r12,%rdi
    df87:	e8 e4 73 ff ff       	call   5370 <fwp_rc_forget_slot>
    df8c:	e9 0a f6 ff ff       	jmp    d59b <f0+0x229b>
    df91:	4c 89 e7             	mov    %r12,%rdi
    df94:	e8 d7 73 ff ff       	call   5370 <fwp_rc_forget_slot>
    df99:	e9 9c f6 ff ff       	jmp    d63a <f0+0x233a>
    df9e:	4c 89 e7             	mov    %r12,%rdi
    dfa1:	e8 ca 73 ff ff       	call   5370 <fwp_rc_forget_slot>
    dfa6:	e9 2e f7 ff ff       	jmp    d6d9 <f0+0x23d9>
    dfab:	4c 89 e7             	mov    %r12,%rdi
    dfae:	e8 bd 73 ff ff       	call   5370 <fwp_rc_forget_slot>
    dfb3:	e9 c0 f7 ff ff       	jmp    d778 <f0+0x2478>
    dfb8:	4c 89 e7             	mov    %r12,%rdi
    dfbb:	e8 b0 73 ff ff       	call   5370 <fwp_rc_forget_slot>
    dfc0:	e9 52 f8 ff ff       	jmp    d817 <f0+0x2517>
    dfc5:	4c 89 e7             	mov    %r12,%rdi
    dfc8:	e8 a3 73 ff ff       	call   5370 <fwp_rc_forget_slot>
    dfcd:	e9 e4 f8 ff ff       	jmp    d8b6 <f0+0x25b6>
    dfd2:	4c 89 e7             	mov    %r12,%rdi
    dfd5:	e8 96 73 ff ff       	call   5370 <fwp_rc_forget_slot>
    dfda:	e9 76 f9 ff ff       	jmp    d955 <f0+0x2655>
    dfdf:	4c 89 e7             	mov    %r12,%rdi
    dfe2:	e8 89 73 ff ff       	call   5370 <fwp_rc_forget_slot>
    dfe7:	e9 08 fa ff ff       	jmp    d9f4 <f0+0x26f4>
    dfec:	4c 89 e7             	mov    %r12,%rdi
    dfef:	e8 7c 73 ff ff       	call   5370 <fwp_rc_forget_slot>
    dff4:	e9 9a fa ff ff       	jmp    da93 <f0+0x2793>
    dff9:	e8 62 54 ff ff       	call   3460 <__stack_chk_fail@plt>
    dffe:	66 90                	xchg   %ax,%ax

000000000000e000 <fwp_main_thread>:
    e000:	f3 0f 1e fa          	endbr64
    e004:	41 54                	push   %r12
    e006:	55                   	push   %rbp
    e007:	53                   	push   %rbx
    e008:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    e00f:	8b 0d 2f 6b 01 00    	mov    0x16b2f(%rip),%ecx        # 24b44 <fwp_heap+0x13a4>
    e015:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    e01c:	00 00 
    e01e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    e025:	00 
    e026:	31 c0                	xor    %eax,%eax
    e028:	85 c9                	test   %ecx,%ecx
    e02a:	0f 84 68 06 00 00    	je     e698 <fwp_main_thread+0x698>
    e030:	8b 15 12 6b 01 00    	mov    0x16b12(%rip),%edx        # 24b48 <fwp_heap+0x13a8>
    e036:	85 d2                	test   %edx,%edx
    e038:	0f 85 42 06 00 00    	jne    e680 <fwp_main_thread+0x680>
    e03e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    e043:	31 f6                	xor    %esi,%esi
    e045:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    e04a:	48 c7 05 e3 50 01 00 	movq   $0x40000000,0x150e3(%rip)        # 23138 <fwp_main_stack_size>
    e051:	00 00 00 40 
    e055:	48 89 05 e4 50 01 00 	mov    %rax,0x150e4(%rip)        # 23140 <fwp_main_stack_top>
    e05c:	48 8d 05 5d 50 00 00 	lea    0x505d(%rip),%rax        # 130c0 <alt.9>
    e063:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    e068:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    e06f:	01 00 
    e071:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    e078:	00 
    e079:	e8 42 56 ff ff       	call   36c0 <sigaltstack@plt>
    e07e:	85 c0                	test   %eax,%eax
    e080:	0f 85 4a 06 00 00    	jne    e6d0 <fwp_main_thread+0x6d0>
    e086:	31 c0                	xor    %eax,%eax
    e088:	b9 12 00 00 00       	mov    $0x12,%ecx
    e08d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e092:	f3 48 ab             	rep stos %rax,(%rdi)
    e095:	48 8d 05 54 5c ff ff 	lea    -0xa3ac(%rip),%rax        # 3cf0 <fwp_segv>
    e09c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e0a1:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    e0a8:	04 00 00 08 
    e0ac:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    e0b1:	e8 ca 54 ff ff       	call   3580 <sigemptyset@plt>
    e0b6:	85 c0                	test   %eax,%eax
    e0b8:	0f 85 12 06 00 00    	jne    e6d0 <fwp_main_thread+0x6d0>
    e0be:	31 d2                	xor    %edx,%edx
    e0c0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e0c5:	bf 0b 00 00 00       	mov    $0xb,%edi
    e0ca:	e8 31 53 ff ff       	call   3400 <sigaction@plt>
    e0cf:	85 c0                	test   %eax,%eax
    e0d1:	0f 85 f9 05 00 00    	jne    e6d0 <fwp_main_thread+0x6d0>
    e0d7:	31 d2                	xor    %edx,%edx
    e0d9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e0de:	bf 07 00 00 00       	mov    $0x7,%edi
    e0e3:	e8 18 53 ff ff       	call   3400 <sigaction@plt>
    e0e8:	85 c0                	test   %eax,%eax
    e0ea:	0f 85 e0 05 00 00    	jne    e6d0 <fwp_main_thread+0x6d0>
    e0f0:	8b 05 ba 4f 00 00    	mov    0x4fba(%rip),%eax        # 130b0 <st.7>
    e0f6:	85 c0                	test   %eax,%eax
    e0f8:	0f 84 62 05 00 00    	je     e660 <fwp_main_thread+0x660>
    e0fe:	48 8b 2d 7b 56 01 00 	mov    0x1567b(%rip),%rbp        # 23780 <fwp_cur>
    e105:	48 85 ed             	test   %rbp,%rbp
    e108:	0f 84 72 03 00 00    	je     e480 <fwp_main_thread+0x480>
    e10e:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    e113:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    e117:	48 89 eb             	mov    %rbp,%rbx
    e11a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e11f:	0f 84 41 01 00 00    	je     e266 <fwp_main_thread+0x266>
    e125:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    e12a:	0f 84 80 02 00 00    	je     e3b0 <fwp_main_thread+0x3b0>
    e130:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e134:	0f 84 66 02 00 00    	je     e3a0 <fwp_main_thread+0x3a0>
    e13a:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e13e:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e142:	0f 85 e8 02 00 00    	jne    e430 <fwp_main_thread+0x430>
    e148:	48 8b 43 60          	mov    0x60(%rbx),%rax
    e14c:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e153:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e157:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e15e:	00 00 00 00 
    e162:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e169:	48 85 d2             	test   %rdx,%rdx
    e16c:	74 07                	je     e175 <fwp_main_thread+0x175>
    e16e:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e175:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e179:	48 85 c0             	test   %rax,%rax
    e17c:	74 34                	je     e1b2 <fwp_main_thread+0x1b2>
    e17e:	48 89 43 68          	mov    %rax,0x68(%rbx)
    e182:	48 8b 05 cf 55 01 00 	mov    0x155cf(%rip),%rax        # 23758 <fwp_timers>
    e189:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    e18d:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    e194:	00 00 00 00 
    e198:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    e19f:	48 85 c0             	test   %rax,%rax
    e1a2:	74 07                	je     e1ab <fwp_main_thread+0x1ab>
    e1a4:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    e1ab:	48 89 1d a6 55 01 00 	mov    %rbx,0x155a6(%rip)        # 23758 <fwp_timers>
    e1b2:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    e1b6:	e8 b5 91 ff ff       	call   7370 <fwp_block>
    e1bb:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    e1c2:	48 85 c9             	test   %rcx,%rcx
    e1c5:	74 47                	je     e20e <fwp_main_thread+0x20e>
    e1c7:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    e1ce:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e1d5:	48 85 d2             	test   %rdx,%rdx
    e1d8:	0f 84 92 02 00 00    	je     e470 <fwp_main_thread+0x470>
    e1de:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    e1e5:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e1ec:	48 85 c0             	test   %rax,%rax
    e1ef:	74 07                	je     e1f8 <fwp_main_thread+0x1f8>
    e1f1:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    e1f8:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    e1ff:	00 00 00 00 
    e203:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e207:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    e20e:	48 8b 0d 6b 55 01 00 	mov    0x1556b(%rip),%rcx        # 23780 <fwp_cur>
    e215:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    e219:	0f 84 01 02 00 00    	je     e420 <fwp_main_thread+0x420>
    e21f:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    e226:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    e22d:	48 85 d2             	test   %rdx,%rdx
    e230:	0f 84 fa 03 00 00    	je     e630 <fwp_main_thread+0x630>
    e236:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    e23d:	48 85 c0             	test   %rax,%rax
    e240:	74 07                	je     e249 <fwp_main_thread+0x249>
    e242:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    e249:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e24d:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    e251:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    e258:	48 89 cb             	mov    %rcx,%rbx
    e25b:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e260:	0f 85 bf fe ff ff    	jne    e125 <fwp_main_thread+0x125>
    e266:	48 83 3d aa 71 01 00 	cmpq   $0x0,0x171aa(%rip)        # 25418 <fwp_state_len>
    e26d:	00 
    e26e:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    e272:	0f 84 ba 00 00 00    	je     e332 <fwp_main_thread+0x332>
    e278:	48 39 1d f9 54 01 00 	cmp    %rbx,0x154f9(%rip)        # 23778 <fwp_root>
    e27f:	c7 05 37 4e 01 00 00 	movl   $0x0,0x14e37(%rip)        # 230c0 <fwp_exit_code>
    e286:	00 00 00 
    e289:	0f 85 5f 04 00 00    	jne    e6ee <fwp_main_thread+0x6ee>
    e28f:	48 85 db             	test   %rbx,%rbx
    e292:	0f 84 0e 02 00 00    	je     e4a6 <fwp_main_thread+0x4a6>
    e298:	48 8b 15 a9 54 01 00 	mov    0x154a9(%rip),%rdx        # 23748 <fwp_tasks_active>
    e29f:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    e2a3:	48 85 d2             	test   %rdx,%rdx
    e2a6:	0f 84 fa 01 00 00    	je     e4a6 <fwp_main_thread+0x4a6>
    e2ac:	0f 1f 40 00          	nopl   0x0(%rax)
    e2b0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    e2b4:	75 08                	jne    e2be <fwp_main_thread+0x2be>
    e2b6:	48 89 d7             	mov    %rdx,%rdi
    e2b9:	e8 f2 5d ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    e2be:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    e2c5:	48 85 d2             	test   %rdx,%rdx
    e2c8:	75 e6                	jne    e2b0 <fwp_main_thread+0x2b0>
    e2ca:	eb 31                	jmp    e2fd <fwp_main_thread+0x2fd>
    e2cc:	0f 1f 40 00          	nopl   0x0(%rax)
    e2d0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    e2d7:	48 89 1d 82 54 01 00 	mov    %rbx,0x15482(%rip)        # 23760 <fwp_ready_tail>
    e2de:	e8 8d 90 ff ff       	call   7370 <fwp_block>
    e2e3:	e8 88 8e ff ff       	call   7170 <fwp_free_zombie>
    e2e8:	48 83 3d 58 54 01 00 	cmpq   $0x0,0x15458(%rip)        # 23748 <fwp_tasks_active>
    e2ef:	00 
    e2f0:	0f 84 b0 01 00 00    	je     e4a6 <fwp_main_thread+0x4a6>
    e2f6:	48 8b 1d 7b 54 01 00 	mov    0x1547b(%rip),%rbx        # 23778 <fwp_root>
    e2fd:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    e301:	75 db                	jne    e2de <fwp_main_thread+0x2de>
    e303:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    e307:	75 d5                	jne    e2de <fwp_main_thread+0x2de>
    e309:	48 8b 05 50 54 01 00 	mov    0x15450(%rip),%rax        # 23760 <fwp_ready_tail>
    e310:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    e314:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    e31b:	00 00 00 00 
    e31f:	48 85 c0             	test   %rax,%rax
    e322:	75 ac                	jne    e2d0 <fwp_main_thread+0x2d0>
    e324:	48 89 1d 3d 54 01 00 	mov    %rbx,0x1543d(%rip)        # 23768 <fwp_ready_head>
    e32b:	eb aa                	jmp    e2d7 <fwp_main_thread+0x2d7>
    e32d:	0f 1f 00             	nopl   (%rax)
    e330:	31 db                	xor    %ebx,%ebx
    e332:	48 83 3d ce 70 01 00 	cmpq   $0x0,0x170ce(%rip)        # 25408 <fwp_state_owners>
    e339:	00 
    e33a:	0f 85 38 ff ff ff    	jne    e278 <fwp_main_thread+0x278>
    e340:	48 8b 3d d9 70 01 00 	mov    0x170d9(%rip),%rdi        # 25420 <fwp_state>
    e347:	e8 64 72 ff ff       	call   55b0 <fwp_mem_free>
    e34c:	48 c7 05 c9 70 01 00 	movq   $0x0,0x170c9(%rip)        # 25420 <fwp_state>
    e353:	00 00 00 00 
    e357:	48 c7 05 ae 70 01 00 	movq   $0x0,0x170ae(%rip)        # 25410 <fwp_state_cap>
    e35e:	00 00 00 00 
    e362:	48 85 db             	test   %rbx,%rbx
    e365:	0f 84 46 03 00 00    	je     e6b1 <fwp_main_thread+0x6b1>
    e36b:	48 39 1d 06 54 01 00 	cmp    %rbx,0x15406(%rip)        # 23778 <fwp_root>
    e372:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    e379:	00 00 00 00 
    e37d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    e384:	00 00 00 00 
    e388:	c7 05 2e 4d 01 00 00 	movl   $0x0,0x14d2e(%rip)        # 230c0 <fwp_exit_code>
    e38f:	00 00 00 
    e392:	0f 84 00 ff ff ff    	je     e298 <fwp_main_thread+0x298>
    e398:	e9 b3 53 ff ff       	jmp    3750 <fwp_main_thread.cold>
    e39d:	0f 1f 00             	nopl   (%rax)
    e3a0:	e8 6b 5f ff ff       	call   4310 <fwp_now_ns>
    e3a5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    e3a9:	0f 8d 91 02 00 00    	jge    e640 <fwp_main_thread+0x640>
    e3af:	90                   	nop
    e3b0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e3b4:	0f 85 80 fd ff ff    	jne    e13a <fwp_main_thread+0x13a>
    e3ba:	48 8b 45 60          	mov    0x60(%rbp),%rax
    e3be:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e3c2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e3c6:	0f 85 80 fd ff ff    	jne    e14c <fwp_main_thread+0x14c>
    e3cc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    e3d0:	48 85 c9             	test   %rcx,%rcx
    e3d3:	0f 84 73 fd ff ff    	je     e14c <fwp_main_thread+0x14c>
    e3d9:	48 85 c0             	test   %rax,%rax
    e3dc:	0f 84 ff 02 00 00    	je     e6e1 <fwp_main_thread+0x6e1>
    e3e2:	48 39 c8             	cmp    %rcx,%rax
    e3e5:	48 0f 4f c1          	cmovg  %rcx,%rax
    e3e9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e3f0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e3f4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e3fb:	00 00 00 00 
    e3ff:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e406:	48 85 d2             	test   %rdx,%rdx
    e409:	74 07                	je     e412 <fwp_main_thread+0x412>
    e40b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e412:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e416:	e9 63 fd ff ff       	jmp    e17e <fwp_main_thread+0x17e>
    e41b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e420:	48 89 cb             	mov    %rcx,%rbx
    e423:	e9 f2 fc ff ff       	jmp    e11a <fwp_main_thread+0x11a>
    e428:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e42f:	00 
    e430:	48 8b 45 40          	mov    0x40(%rbp),%rax
    e434:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e43b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e442:	00 00 00 00 
    e446:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    e44d:	48 85 c0             	test   %rax,%rax
    e450:	0f 84 52 02 00 00    	je     e6a8 <fwp_main_thread+0x6a8>
    e456:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    e45d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e461:	e9 4c fd ff ff       	jmp    e1b2 <fwp_main_thread+0x1b2>
    e466:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e46d:	00 00 00 
    e470:	48 89 01             	mov    %rax,(%rcx)
    e473:	e9 74 fd ff ff       	jmp    e1ec <fwp_main_thread+0x1ec>
    e478:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e47f:	00 
    e480:	48 83 3d 90 6f 01 00 	cmpq   $0x0,0x16f90(%rip)        # 25418 <fwp_state_len>
    e487:	00 
    e488:	0f 84 a2 fe ff ff    	je     e330 <fwp_main_thread+0x330>
    e48e:	48 83 3d e2 52 01 00 	cmpq   $0x0,0x152e2(%rip)        # 23778 <fwp_root>
    e495:	00 
    e496:	c7 05 20 4c 01 00 00 	movl   $0x0,0x14c20(%rip)        # 230c0 <fwp_exit_code>
    e49d:	00 00 00 
    e4a0:	0f 85 43 02 00 00    	jne    e6e9 <fwp_main_thread+0x6e9>
    e4a6:	e8 c5 8c ff ff       	call   7170 <fwp_free_zombie>
    e4ab:	48 83 3d b5 52 01 00 	cmpq   $0x0,0x152b5(%rip)        # 23768 <fwp_ready_head>
    e4b2:	00 
    e4b3:	0f 85 97 52 ff ff    	jne    3750 <fwp_main_thread.cold>
    e4b9:	48 83 3d 97 52 01 00 	cmpq   $0x0,0x15297(%rip)        # 23758 <fwp_timers>
    e4c0:	00 
    e4c1:	0f 85 89 52 ff ff    	jne    3750 <fwp_main_thread.cold>
    e4c7:	8b 1d 7f 4c 01 00    	mov    0x14c7f(%rip),%ebx        # 2314c <fwp_stack_pool_n>
    e4cd:	85 db                	test   %ebx,%ebx
    e4cf:	74 36                	je     e507 <fwp_main_thread+0x507>
    e4d1:	83 eb 01             	sub    $0x1,%ebx
    e4d4:	48 8d 05 85 4c 01 00 	lea    0x14c85(%rip),%rax        # 23160 <fwp_stack_pool>
    e4db:	48 63 d3             	movslq %ebx,%rdx
    e4de:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    e4e2:	eb 07                	jmp    e4eb <fwp_main_thread+0x4eb>
    e4e4:	0f 1f 40 00          	nopl   0x0(%rax)
    e4e8:	83 eb 01             	sub    $0x1,%ebx
    e4eb:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    e4ef:	be 00 00 00 10       	mov    $0x10000000,%esi
    e4f4:	89 1d 52 4c 01 00    	mov    %ebx,0x14c52(%rip)        # 2314c <fwp_stack_pool_n>
    e4fa:	48 83 ed 08          	sub    $0x8,%rbp
    e4fe:	e8 dd 50 ff ff       	call   35e0 <munmap@plt>
    e503:	85 db                	test   %ebx,%ebx
    e505:	75 e1                	jne    e4e8 <fwp_main_thread+0x4e8>
    e507:	8b 3d 13 4b 00 00    	mov    0x4b13(%rip),%edi        # 13020 <fwp_epfd>
    e50d:	85 ff                	test   %edi,%edi
    e50f:	78 05                	js     e516 <fwp_main_thread+0x516>
    e511:	e8 ba 4f ff ff       	call   34d0 <close@plt>
    e516:	4c 8b 25 43 4e 01 00 	mov    0x14e43(%rip),%r12        # 23360 <fwp_nfdws>
    e51d:	48 8b 2d 44 4e 01 00 	mov    0x14e44(%rip),%rbp        # 23368 <fwp_fdws>
    e524:	31 db                	xor    %ebx,%ebx
    e526:	c7 05 f0 4a 00 00 ff 	movl   $0xffffffff,0x4af0(%rip)        # 13020 <fwp_epfd>
    e52d:	ff ff ff 
    e530:	4d 85 e4             	test   %r12,%r12
    e533:	74 38                	je     e56d <fwp_main_thread+0x56d>
    e535:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    e53c:	00 00 00 00 
    e540:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    e545:	48 85 ff             	test   %rdi,%rdi
    e548:	74 1a                	je     e564 <fwp_main_thread+0x564>
    e54a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    e54e:	0f 85 fc 51 ff ff    	jne    3750 <fwp_main_thread.cold>
    e554:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    e559:	0f 85 f1 51 ff ff    	jne    3750 <fwp_main_thread.cold>
    e55f:	e8 4c 70 ff ff       	call   55b0 <fwp_mem_free>
    e564:	48 83 c3 01          	add    $0x1,%rbx
    e568:	4c 39 e3             	cmp    %r12,%rbx
    e56b:	75 d3                	jne    e540 <fwp_main_thread+0x540>
    e56d:	48 89 ef             	mov    %rbp,%rdi
    e570:	e8 3b 70 ff ff       	call   55b0 <fwp_mem_free>
    e575:	48 8b 15 fc 51 01 00 	mov    0x151fc(%rip),%rdx        # 23778 <fwp_root>
    e57c:	48 c7 05 e1 4d 01 00 	movq   $0x0,0x14de1(%rip)        # 23368 <fwp_fdws>
    e583:	00 00 00 00 
    e587:	48 c7 05 ce 4d 01 00 	movq   $0x0,0x14dce(%rip)        # 23360 <fwp_nfdws>
    e58e:	00 00 00 00 
    e592:	48 85 d2             	test   %rdx,%rdx
    e595:	74 4e                	je     e5e5 <fwp_main_thread+0x5e5>
    e597:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    e59c:	0f 85 ae 51 ff ff    	jne    3750 <fwp_main_thread.cold>
    e5a2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    e5a9:	00 
    e5aa:	0f 85 a0 51 ff ff    	jne    3750 <fwp_main_thread.cold>
    e5b0:	48 83 3d 60 6e 01 00 	cmpq   $0x0,0x16e60(%rip)        # 25418 <fwp_state_len>
    e5b7:	00 
    e5b8:	0f 85 92 51 ff ff    	jne    3750 <fwp_main_thread.cold>
    e5be:	48 83 3d 42 6e 01 00 	cmpq   $0x0,0x16e42(%rip)        # 25408 <fwp_state_owners>
    e5c5:	00 
    e5c6:	0f 85 84 51 ff ff    	jne    3750 <fwp_main_thread.cold>
    e5cc:	b9 79 00 00 00       	mov    $0x79,%ecx
    e5d1:	31 c0                	xor    %eax,%eax
    e5d3:	48 8d 3d a6 4d 01 00 	lea    0x14da6(%rip),%rdi        # 23380 <fwp_root_context>
    e5da:	f3 48 ab             	rep stos %rax,(%rdi)
    e5dd:	48 89 d7             	mov    %rdx,%rdi
    e5e0:	e8 cb 6f ff ff       	call   55b0 <fwp_mem_free>
    e5e5:	48 8b 3d 54 4a 00 00 	mov    0x4a54(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    e5ec:	48 c7 05 89 51 01 00 	movq   $0x0,0x15189(%rip)        # 23780 <fwp_cur>
    e5f3:	00 00 00 00 
    e5f7:	48 c7 05 76 51 01 00 	movq   $0x0,0x15176(%rip)        # 23778 <fwp_root>
    e5fe:	00 00 00 00 
    e602:	e8 b9 4f ff ff       	call   35c0 <fflush@plt>
    e607:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    e60e:	00 
    e60f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e616:	00 00 
    e618:	0f 85 be 00 00 00    	jne    e6dc <fwp_main_thread+0x6dc>
    e61e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    e625:	31 c0                	xor    %eax,%eax
    e627:	5b                   	pop    %rbx
    e628:	5d                   	pop    %rbp
    e629:	41 5c                	pop    %r12
    e62b:	c3                   	ret
    e62c:	0f 1f 40 00          	nopl   0x0(%rax)
    e630:	48 89 05 21 51 01 00 	mov    %rax,0x15121(%rip)        # 23758 <fwp_timers>
    e637:	e9 01 fc ff ff       	jmp    e23d <fwp_main_thread+0x23d>
    e63c:	0f 1f 40 00          	nopl   0x0(%rax)
    e640:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    e644:	0f 85 66 fd ff ff    	jne    e3b0 <fwp_main_thread+0x3b0>
    e64a:	48 89 ef             	mov    %rbp,%rdi
    e64d:	e8 5e 5a ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    e652:	e9 59 fd ff ff       	jmp    e3b0 <fwp_main_thread+0x3b0>
    e657:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e65e:	00 00 
    e660:	e8 9b cc ff ff       	call   b300 <f0>
    e665:	48 c7 05 38 4a 00 00 	movq   $0x0,0x4a38(%rip)        # 130a8 <v.6>
    e66c:	00 00 00 00 
    e670:	c7 05 36 4a 00 00 01 	movl   $0x1,0x4a36(%rip)        # 130b0 <st.7>
    e677:	00 00 00 
    e67a:	e9 7f fa ff ff       	jmp    e0fe <fwp_main_thread+0xfe>
    e67f:	90                   	nop
    e680:	48 8d 3d 99 63 ff ff 	lea    -0x9c67(%rip),%rdi        # 4a20 <fwp_heap_report>
    e687:	e8 84 02 00 00       	call   e910 <atexit>
    e68c:	e9 ad f9 ff ff       	jmp    e03e <fwp_main_thread+0x3e>
    e691:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    e698:	e8 93 64 ff ff       	call   4b30 <fwp_heap_init>
    e69d:	e9 8e f9 ff ff       	jmp    e030 <fwp_main_thread+0x30>
    e6a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e6a8:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e6ac:	e9 01 fb ff ff       	jmp    e1b2 <fwp_main_thread+0x1b2>
    e6b1:	48 83 3d bf 50 01 00 	cmpq   $0x0,0x150bf(%rip)        # 23778 <fwp_root>
    e6b8:	00 
    e6b9:	c7 05 fd 49 01 00 00 	movl   $0x0,0x149fd(%rip)        # 230c0 <fwp_exit_code>
    e6c0:	00 00 00 
    e6c3:	0f 84 dd fd ff ff    	je     e4a6 <fwp_main_thread+0x4a6>
    e6c9:	e9 82 50 ff ff       	jmp    3750 <fwp_main_thread.cold>
    e6ce:	66 90                	xchg   %ax,%ax
    e6d0:	48 8d 3d 19 12 00 00 	lea    0x1219(%rip),%rdi        # f8f0 <_IO_stdin_used+0x8f0>
    e6d7:	e8 c4 5a ff ff       	call   41a0 <fwp_trap>
    e6dc:	e8 7f 4d ff ff       	call   3460 <__stack_chk_fail@plt>
    e6e1:	48 89 c8             	mov    %rcx,%rax
    e6e4:	e9 00 fd ff ff       	jmp    e3e9 <fwp_main_thread+0x3e9>
    e6e9:	e9 62 50 ff ff       	jmp    3750 <fwp_main_thread.cold>
    e6ee:	e9 5d 50 ff ff       	jmp    3750 <fwp_main_thread.cold>
    e6f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e6fa:	00 00 00 
    e6fd:	0f 1f 00             	nopl   (%rax)

000000000000e700 <__divmodti4>:
    e700:	f3 0f 1e fa          	endbr64
    e704:	55                   	push   %rbp
    e705:	49 89 f1             	mov    %rsi,%r9
    e708:	49 89 d2             	mov    %rdx,%r10
    e70b:	48 89 fe             	mov    %rdi,%rsi
    e70e:	49 89 cb             	mov    %rcx,%r11
    e711:	48 89 e5             	mov    %rsp,%rbp
    e714:	41 57                	push   %r15
    e716:	41 56                	push   %r14
    e718:	41 55                	push   %r13
    e71a:	41 54                	push   %r12
    e71c:	53                   	push   %rbx
    e71d:	4c 89 c3             	mov    %r8,%rbx
    e720:	45 31 c0             	xor    %r8d,%r8d
    e723:	4d 85 c9             	test   %r9,%r9
    e726:	79 12                	jns    e73a <__divmodti4+0x3a>
    e728:	31 ff                	xor    %edi,%edi
    e72a:	48 f7 de             	neg    %rsi
    e72d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    e734:	4c 19 cf             	sbb    %r9,%rdi
    e737:	49 89 f9             	mov    %rdi,%r9
    e73a:	4c 89 d8             	mov    %r11,%rax
    e73d:	4d 85 db             	test   %r11,%r11
    e740:	0f 88 1a 01 00 00    	js     e860 <__divmodti4+0x160>
    e746:	4c 89 d9             	mov    %r11,%rcx
    e749:	49 89 f3             	mov    %rsi,%r11
    e74c:	75 62                	jne    e7b0 <__divmodti4+0xb0>
    e74e:	4d 89 c4             	mov    %r8,%r12
    e751:	4d 39 d1             	cmp    %r10,%r9
    e754:	0f 83 46 01 00 00    	jae    e8a0 <__divmodti4+0x1a0>
    e75a:	4c 89 d8             	mov    %r11,%rax
    e75d:	4c 89 ca             	mov    %r9,%rdx
    e760:	49 f7 f2             	div    %r10
    e763:	49 89 c3             	mov    %rax,%r11
    e766:	31 c0                	xor    %eax,%eax
    e768:	48 89 d6             	mov    %rdx,%rsi
    e76b:	31 ff                	xor    %edi,%edi
    e76d:	4c 89 d9             	mov    %r11,%rcx
    e770:	48 89 c2             	mov    %rax,%rdx
    e773:	48 89 c8             	mov    %rcx,%rax
    e776:	4d 85 e4             	test   %r12,%r12
    e779:	74 0a                	je     e785 <__divmodti4+0x85>
    e77b:	48 f7 d8             	neg    %rax
    e77e:	48 83 d2 00          	adc    $0x0,%rdx
    e782:	48 f7 da             	neg    %rdx
    e785:	4d 85 c0             	test   %r8,%r8
    e788:	74 0a                	je     e794 <__divmodti4+0x94>
    e78a:	48 f7 de             	neg    %rsi
    e78d:	48 83 d7 00          	adc    $0x0,%rdi
    e791:	48 f7 df             	neg    %rdi
    e794:	48 89 33             	mov    %rsi,(%rbx)
    e797:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    e79b:	5b                   	pop    %rbx
    e79c:	41 5c                	pop    %r12
    e79e:	41 5d                	pop    %r13
    e7a0:	41 5e                	pop    %r14
    e7a2:	41 5f                	pop    %r15
    e7a4:	5d                   	pop    %rbp
    e7a5:	c3                   	ret
    e7a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e7ad:	00 00 00 
    e7b0:	4d 89 c4             	mov    %r8,%r12
    e7b3:	49 39 c1             	cmp    %rax,%r9
    e7b6:	0f 82 ce 00 00 00    	jb     e88a <__divmodti4+0x18a>
    e7bc:	31 ff                	xor    %edi,%edi
    e7be:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    e7c3:	48 63 c7             	movslq %edi,%rax
    e7c6:	be 40 00 00 00       	mov    $0x40,%esi
    e7cb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    e7d0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    e7d5:	48 29 c6             	sub    %rax,%rsi
    e7d8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    e7dd:	48 09 c8             	or     %rcx,%rax
    e7e0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    e7e5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    e7ea:	49 89 c6             	mov    %rax,%r14
    e7ed:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    e7f1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    e7f6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    e7fb:	49 09 c1             	or     %rax,%r9
    e7fe:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    e802:	4c 89 c8             	mov    %r9,%rax
    e805:	49 f7 f6             	div    %r14
    e808:	48 89 d1             	mov    %rdx,%rcx
    e80b:	49 89 c3             	mov    %rax,%r11
    e80e:	49 89 c1             	mov    %rax,%r9
    e811:	49 f7 e2             	mul    %r10
    e814:	49 89 c6             	mov    %rax,%r14
    e817:	49 89 d2             	mov    %rdx,%r10
    e81a:	48 39 d1             	cmp    %rdx,%rcx
    e81d:	72 07                	jb     e826 <__divmodti4+0x126>
    e81f:	75 17                	jne    e838 <__divmodti4+0x138>
    e821:	49 39 c7             	cmp    %rax,%r15
    e824:	73 12                	jae    e838 <__divmodti4+0x138>
    e826:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    e82a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    e82e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    e832:	49 89 d2             	mov    %rdx,%r10
    e835:	49 89 c6             	mov    %rax,%r14
    e838:	4c 89 f8             	mov    %r15,%rax
    e83b:	4c 29 f0             	sub    %r14,%rax
    e83e:	4c 19 d1             	sbb    %r10,%rcx
    e841:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    e846:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    e84b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    e850:	48 09 c6             	or     %rax,%rsi
    e853:	48 89 cf             	mov    %rcx,%rdi
    e856:	31 c0                	xor    %eax,%eax
    e858:	4c 89 c9             	mov    %r9,%rcx
    e85b:	e9 10 ff ff ff       	jmp    e770 <__divmodti4+0x70>
    e860:	4c 89 d0             	mov    %r10,%rax
    e863:	4c 89 da             	mov    %r11,%rdx
    e866:	4d 89 c4             	mov    %r8,%r12
    e869:	49 89 f3             	mov    %rsi,%r11
    e86c:	48 f7 d8             	neg    %rax
    e86f:	49 f7 d4             	not    %r12
    e872:	48 83 d2 00          	adc    $0x0,%rdx
    e876:	49 89 c2             	mov    %rax,%r10
    e879:	48 f7 da             	neg    %rdx
    e87c:	48 89 d1             	mov    %rdx,%rcx
    e87f:	0f 84 cc fe ff ff    	je     e751 <__divmodti4+0x51>
    e885:	49 39 d1             	cmp    %rdx,%r9
    e888:	73 46                	jae    e8d0 <__divmodti4+0x1d0>
    e88a:	4c 89 cf             	mov    %r9,%rdi
    e88d:	31 c0                	xor    %eax,%eax
    e88f:	31 c9                	xor    %ecx,%ecx
    e891:	e9 da fe ff ff       	jmp    e770 <__divmodti4+0x70>
    e896:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e89d:	00 00 00 
    e8a0:	4d 85 d2             	test   %r10,%r10
    e8a3:	75 0d                	jne    e8b2 <__divmodti4+0x1b2>
    e8a5:	b8 01 00 00 00       	mov    $0x1,%eax
    e8aa:	31 d2                	xor    %edx,%edx
    e8ac:	49 f7 f2             	div    %r10
    e8af:	49 89 c2             	mov    %rax,%r10
    e8b2:	4c 89 c8             	mov    %r9,%rax
    e8b5:	31 d2                	xor    %edx,%edx
    e8b7:	49 f7 f2             	div    %r10
    e8ba:	49 89 c1             	mov    %rax,%r9
    e8bd:	4c 89 d8             	mov    %r11,%rax
    e8c0:	49 f7 f2             	div    %r10
    e8c3:	49 89 c3             	mov    %rax,%r11
    e8c6:	4c 89 c8             	mov    %r9,%rax
    e8c9:	e9 9a fe ff ff       	jmp    e768 <__divmodti4+0x68>
    e8ce:	66 90                	xchg   %ax,%ax
    e8d0:	45 31 f6             	xor    %r14d,%r14d
    e8d3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    e8d8:	44 89 f7             	mov    %r14d,%edi
    e8db:	45 85 f6             	test   %r14d,%r14d
    e8de:	0f 85 df fe ff ff    	jne    e7c3 <__divmodti4+0xc3>
    e8e4:	4c 39 ca             	cmp    %r9,%rdx
    e8e7:	72 17                	jb     e900 <__divmodti4+0x200>
    e8e9:	31 c9                	xor    %ecx,%ecx
    e8eb:	48 39 c6             	cmp    %rax,%rsi
    e8ee:	73 10                	jae    e900 <__divmodti4+0x200>
    e8f0:	4c 89 cf             	mov    %r9,%rdi
    e8f3:	31 c0                	xor    %eax,%eax
    e8f5:	e9 76 fe ff ff       	jmp    e770 <__divmodti4+0x70>
    e8fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e900:	4c 89 de             	mov    %r11,%rsi
    e903:	b9 01 00 00 00       	mov    $0x1,%ecx
    e908:	48 29 c6             	sub    %rax,%rsi
    e90b:	49 19 d1             	sbb    %rdx,%r9
    e90e:	eb e0                	jmp    e8f0 <__divmodti4+0x1f0>

000000000000e910 <atexit>:
    e910:	f3 0f 1e fa          	endbr64
    e914:	48 8b 15 ed 46 00 00 	mov    0x46ed(%rip),%rdx        # 13008 <__dso_handle>
    e91b:	31 f6                	xor    %esi,%esi
    e91d:	e9 3e 4d ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000e924 <_fini>:
    e924:	f3 0f 1e fa          	endbr64
    e928:	48 83 ec 08          	sub    $0x8,%rsp
    e92c:	48 83 c4 08          	add    $0x8,%rsp
    e930:	c3                   	ret
