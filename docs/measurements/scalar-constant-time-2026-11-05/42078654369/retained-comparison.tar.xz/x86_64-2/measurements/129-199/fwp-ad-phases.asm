
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 ff 00 00 	mov    0xffc1(%rip),%rax        # 12fd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da fd 00 00    	push   0xfdda(%rip)        # 12e00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc fd 00 00    	jmp    *0xfddc(%rip)        # 12e08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 fc 00 00    	jmp    *0xfc46(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12e60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12e68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12e70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12e78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12e80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12e88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12e90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12e98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12ea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12ea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12eb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12eb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12ec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12ec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12ed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12ed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12ee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12ee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12ef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12ef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12f60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12f68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12f70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12f78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12f80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12f88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 f8 00 00    	jmp    *0xf8e6(%rip)        # 12f90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de f8 00 00    	jmp    *0xf8de(%rip)        # 12f98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 f8 00 00    	jmp    *0xf8d6(%rip)        # 12fa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce f8 00 00    	jmp    *0xf8ce(%rip)        # 12fa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 f8 00 00    	jmp    *0xf8c6(%rip)        # 12fb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be f8 00 00    	jmp    *0xf8be(%rip)        # 12fb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd b9 00 00 	lea    0xb9dd(%rip),%r9        # f0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da b9 00 00 	lea    0xb9da(%rip),%r8        # f0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_hof0.constprop.0.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>
    3750:	e8 ab ff ff ff       	call   3700 <fwp_trap_overflow.constprop.0>

0000000000003755 <fwp_main_thread.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>

000000000000375a <main.cold>:
    375a:	e8 71 fc ff ff       	call   33d0 <abort@plt>
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 81 db 00 00 	lea    0xdb81(%rip),%rax        # 11300 <fwp_fn_table>
    377f:	48 89 05 92 1c 02 00 	mov    %rax,0x21c92(%rip)        # 25418 <fwp_fns>
    3786:	48 8b 05 93 f8 00 00 	mov    0xf893(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 8c 1c 02 00 	mov    %rax,0x21c8c(%rip)        # 25420 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d b7 ba 00 00 	lea    0xbab7(%rip),%rdi        # f257 <_IO_stdin_used+0x257>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 f8 00 00 	mov    0xf818(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 0f a0 00 00 	lea    0xa00f(%rip),%rdx        # d870 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 e0 fe ff ff    	jne    375a <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 c4 fe ff ff    	jne    375a <main.cold>
    3896:	48 8b 3d 83 f7 00 00 	mov    0xf783(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 f7 01 00    	mov    0x1f7d8(%rip),%eax        # 23080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 67 b9 00 00 	lea    0xb967(%rip),%rdi        # f260 <_IO_stdin_used+0x260>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 86 c1 00 00 	lea    0xc186(%rip),%rdi        # fa90 <_IO_stdin_used+0xa90>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 39 fe ff ff    	jne    375a <main.cold>
    3921:	48 8d 3d 40 c1 00 00 	lea    0xc140(%rip),%rdi        # fa68 <_IO_stdin_used+0xa68>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d 04 c1 00 00 	lea    0xc104(%rip),%rdi        # fa38 <_IO_stdin_used+0xa38>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d d0 c0 00 00 	lea    0xc0d0(%rip),%rdi        # fa10 <_IO_stdin_used+0xa10>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b f6 00 00    	call   *0xf64b(%rip)        # 12fc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 f6 00 00 	lea    0xf699(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 f6 00 00 	lea    0xf692(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e f6 00 00 	mov    0xf62e(%rip),%rax        # 12fc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 f6 00 00 	lea    0xf669(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 f6 00 00 	lea    0xf662(%rip),%rsi        # 13020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd f5 00 00 	mov    0xf5fd(%rip),%rax        # 12fd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d f6 00 00 00 	cmpb   $0x0,0xf64d(%rip)        # 13048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da f5 00 00 	cmpq   $0x0,0xf5da(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 f6 00 00 01 	movb   $0x1,0xf625(%rip)        # 13048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce f4 01 00 	add    0x1f4ce(%rip),%rdx        # 230f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc f4 01 00 	add    0x1f4bc(%rip),%rax        # 230f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d a9 17 02 00 	mov    0x217a9(%rip),%rdi        # 25420 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 f3 00 00 	mov    0xf394(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 f3 00 00 	mov    0xf381(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 b3 00 00 	lea    0xb345(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 f3 00 00 	mov    0xf372(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 a1 fa 01 00 	mov    0x1faa1(%rip),%rax        # 237a0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 d9 f3 01 00 	mov    0x1f3d9(%rip),%rax        # 23158 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 c5 f3 01 00 	sub    0x1f3c5(%rip),%rax        # 23150 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 ad bd 00 00 	lea    0xbdad(%rip),%rsi        # fb70 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 87 b8 00 00 	lea    0xb887(%rip),%rdi        # f670 <_IO_stdin_used+0x670>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 42 f2 00 00 	mov    0xf242(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d e5 f1 00 00 ff 	cmpl   $0xffffffff,0xf1e5(%rip)        # 13018 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 b1 00 00 	lea    0xb1e2(%rip),%rax        # f022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d c1 f2 01 00 	mov    0x1f2c1(%rip),%r9        # 23108 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f ed 00 	movq   0xed9f(%rip),%xmm0        # 12bf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 b1 00 00 	lea    0xb1e7(%rip),%rax        # f044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 9c f2 01 00 	mov    0x1f29c(%rip),%r8        # 23100 <descent_inputs>
    3e64:	48 8b 0d a5 f2 01 00 	mov    0x1f2a5(%rip),%rcx        # 23110 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d c2 f1 00 00 	mov    0xf1c2(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 b1 00 00 	lea    0xb1d8(%rip),%rax        # f061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 ed 00 	movq   0xed67(%rip),%xmm0        # 12bf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 20 b8 00 00 	lea    0xb820(%rip),%rdx        # f6b8 <_IO_stdin_used+0x6b8>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 71 f2 01 00 	lea    0x1f271(%rip),%r12        # 23120 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 ed 00 	movq   0xed44(%rip),%xmm0        # 12c00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 5b f1 00 00 	mov    0xf15b(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 b1 00 00 	lea    0xb175(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 b1 00 00 	lea    0xb170(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 20 f1 00 00 	mov    0xf120(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 b1 00 00 	lea    0xb144(%rip),%rdi        # f07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d f9 f0 00 00 	mov    0xf0f9(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 b1 00 00 	lea    0xb143(%rip),%rcx        # f091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 b1 00 00 	lea    0xb119(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 1b 0c 02 00 	mov    0x20c1b(%rip),%rax        # 24bb0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 14 0c 02 00 	lea    0x20c14(%rip),%r8        # 24bb0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d f5 0b 02 00 	mov    0x20bf5(%rip),%rbx        # 24b98 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 05 0c 02 00 	mov    0x20c05(%rip),%rcx        # 24bb8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d a1 0b 02 00 	mov    0x20ba1(%rip),%rdi        # 24ba0 <fwp_heap+0x13e0>
    3fff:	48 29 35 ea 0b 02 00 	sub    %rsi,0x20bea(%rip)        # 24bf0 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 7a 0b 02 00 	mov    0x20b7a(%rip),%rax        # 24b90 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 30 0b 02 00 	add    0x20b30(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 3e 0b 02 00 	mov    0x20b3e(%rip),%rsi        # 24ba0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 4c 0b 02 00 	mov    0x20b4c(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 fb 0a 02 00 	mov    %r12,0x20afb(%rip)        # 24ba0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d e9 0a 02 00 	mov    %rbp,0x20ae9(%rip)        # 24b98 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d ce 0a 02 00 	cmp    %rdi,0x20ace(%rip)        # 24b88 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d c5 0a 02 00 	mov    %rdi,0x20ac5(%rip)        # 24b88 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 09 0b 02 00 	sub    %rdi,0x20b09(%rip)        # 24bf0 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 b1 0a 02 00 	mov    0x20ab1(%rip),%rax        # 24ba8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 aa 0a 02 00 	lea    0x20aaa(%rip),%r8        # 24ba8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 5d ee 00 00 	mov    0xee5d(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 ae 00 00 	lea    0xae14(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d ad ed 00 00 	movslq 0xedad(%rip),%rbp        # 13018 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 7a ee 01 00 	mov    0x1ee7a(%rip),%rsi        # 23118 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d 76 ee 01 00 	lea    0x1ee76(%rip),%rcx        # 23120 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 4b ee 01 00 	addq   $0x1,0x1ee4b(%rip)        # 23110 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 48 ed 00 00    	mov    %ebx,0xed48(%rip)        # 13018 <descent_active_phase>
    42d0:	48 89 05 41 ee 01 00 	mov    %rax,0x1ee41(%rip)        # 23118 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d 99 f4 01 00 	cmp    0x1f499(%rip),%rdi        # 237a0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 5f f4 01 00 	mov    0x1f45f(%rip),%rax        # 23780 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 3d f4 01 00 	mov    %rdi,0x1f43d(%rip)        # 23780 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 19 f4 01 00 	mov    %rdi,0x1f419(%rip)        # 23788 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 ee ad 00 00 	lea    0xadee(%rip),%rsi        # f19f <_IO_stdin_used+0x19f>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba ac 00 00 	lea    0xacba(%rip),%rsi        # f07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 28 ec 00 00 	mov    0xec28(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 ac 00 00 	lea    0xac64(%rip),%rdx        # f083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 10 ec 00 00 	mov    0xec10(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 21 eb 00 00 	mov    0xeb21(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 aa 00 00 	lea    0xaad8(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 ab 00 00 	lea    0xab45(%rip),%rdi        # f092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd aa 00 00 	lea    0xaacd(%rip),%rdi        # f0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d 18 b1 00 00 	lea    0xb118(%rip),%rdi        # f708 <_IO_stdin_used+0x708>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 b0 b5 00 	movdqa 0xb5b0(%rip),%xmm0        # fbc0 <msg.4+0x50>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 aa 0d 02 00 	add    0x20daa(%rip),%rax        # 25418 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 6c b0 00 00 	lea    0xb06c(%rip),%rdi        # f730 <_IO_stdin_used+0x730>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 05 ea 01 00 	cmp    %rax,0x1ea05(%rip)        # 230e8 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 00 ea 01 00 	add    0x1ea00(%rip),%rax        # 230f0 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 55 b0 00 00 	lea    0xb055(%rip),%rdi        # f760 <_IO_stdin_used+0x760>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 a9 00 00 	lea    0xa9a5(%rip),%r8        # f0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa a7 00 00 	lea    0xa7fa(%rip),%r8        # f0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 a6 00 00 	lea    0xa697(%rip),%r8        # f0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f a4 00 00 	lea    0xa46f(%rip),%rdi        # f0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 54 a5 00 00 	lea    0xa554(%rip),%rsi        # f1e2 <_IO_stdin_used+0x1e2>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d 85 fe 01 00 	mov    0x1fe85(%rip),%r9        # 24b88 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 de fe 01 00 	mov    0x1fede(%rip),%r8        # 24be8 <fwp_heap+0x1428>
    4d0a:	48 8d 15 9f aa 00 00 	lea    0xaa9f(%rip),%rdx        # f7b0 <_IO_stdin_used+0x7b0>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d c6 fe 01 00 	mov    0x1fec6(%rip),%rcx        # 24be0 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d d4 fe 01 	movsd  0x1fed4(%rip),%xmm1        # 24c00 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 c4 fe 01 	movsd  0x1fec4(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 05 e3 00 00 	mov    0xe305(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 58 ae 00 	movdqa 0xae58(%rip),%xmm0        # fbd0 <msg.4+0x60>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 7f f9 01 00 	lea    0x1f97f(%rip),%rax        # 24700 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 81 ae 00 	movdqa 0xae81(%rip),%xmm2        # fc10 <msg.4+0xa0>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 25 f9 01 00 	movaps %xmm0,0x1f925(%rip)        # 246c0 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 3d ae 00 	movdqa 0xae3d(%rip),%xmm0        # fbe0 <msg.4+0x70>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 b3 fd 01 00 01 	movl   $0x1,0x1fdb3(%rip)        # 24b64 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 13 f9 01 00 	movaps %xmm0,0x1f913(%rip)        # 246d0 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 2b ae 00 	movdqa 0xae2b(%rip),%xmm0        # fbf0 <msg.4+0x80>
    4dc4:	00 
    4dc5:	0f 29 05 14 f9 01 00 	movaps %xmm0,0x1f914(%rip)        # 246e0 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 2c ae 00 	movdqa 0xae2c(%rip),%xmm0        # fc00 <msg.4+0x90>
    4dd3:	00 
    4dd4:	0f 29 05 15 f9 01 00 	movaps %xmm0,0x1f915(%rip)        # 246f0 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 95 e9 01 00 	lea    0x1e995(%rip),%r8        # 237c0 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 b0 fc 01 00 	mov    %rax,0x1fcb0(%rip)        # 24b78 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 8e fc 01 00 	mov    %r12,0x1fc8e(%rip)        # 24b80 <fwp_heap+0x13c0>
    4ef2:	48 89 05 77 fc 01 00 	mov    %rax,0x1fc77(%rip)        # 24b70 <fwp_heap+0x13b0>
    4ef9:	48 89 1d 90 fc 01 00 	mov    %rbx,0x1fc90(%rip)        # 24b90 <fwp_heap+0x13d0>
    4f00:	48 89 35 b9 fc 01 00 	mov    %rsi,0x1fcb9(%rip)        # 24bc0 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 a1 00 00 	lea    0xa1f9(%rip),%rdi        # f112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 98 fc 01 00 	mov    %rax,0x1fc98(%rip)        # 24bb8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 1c fc 01 00    	mov    %eax,0x1fc1c(%rip)        # 24b68 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <fwp_wake_io>:
    4f60:	48 8b 07             	mov    (%rdi),%rax
    4f63:	48 85 c0             	test   %rax,%rax
    4f66:	0f 84 f4 00 00 00    	je     5060 <fwp_wake_io+0x100>
    4f6c:	53                   	push   %rbx
    4f6d:	4c 8b 05 0c e8 01 00 	mov    0x1e80c(%rip),%r8        # 23780 <fwp_ready_tail>
    4f74:	49 89 f9             	mov    %rdi,%r9
    4f77:	48 89 c2             	mov    %rax,%rdx
    4f7a:	45 31 db             	xor    %r11d,%r11d
    4f7d:	45 31 d2             	xor    %r10d,%r10d
    4f80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f84:	eb 71                	jmp    4ff7 <fwp_wake_io+0x97>
    4f86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f8d:	00 00 00 
    4f90:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4f97:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4f9e:	48 85 c9             	test   %rcx,%rcx
    4fa1:	74 07                	je     4faa <fwp_wake_io+0x4a>
    4fa3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4faa:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4fb1:	00 00 00 00 
    4fb5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4fbc:	49 8b 01             	mov    (%r9),%rax
    4fbf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4fc3:	75 2a                	jne    4fef <fwp_wake_io+0x8f>
    4fc5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4fc9:	75 24                	jne    4fef <fwp_wake_io+0x8f>
    4fcb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4fcf:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4fd6:	00 00 00 00 
    4fda:	4d 85 c0             	test   %r8,%r8
    4fdd:	74 51                	je     5030 <fwp_wake_io+0xd0>
    4fdf:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4fe6:	49 89 d0             	mov    %rdx,%r8
    4fe9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4fef:	48 89 c2             	mov    %rax,%rdx
    4ff2:	48 85 c0             	test   %rax,%rax
    4ff5:	74 49                	je     5040 <fwp_wake_io+0xe0>
    4ff7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4ffe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5002:	48 85 ff             	test   %rdi,%rdi
    5005:	74 b8                	je     4fbf <fwp_wake_io+0x5f>
    5007:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    500e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5015:	48 85 f6             	test   %rsi,%rsi
    5018:	0f 85 72 ff ff ff    	jne    4f90 <fwp_wake_io+0x30>
    501e:	48 89 0f             	mov    %rcx,(%rdi)
    5021:	e9 78 ff ff ff       	jmp    4f9e <fwp_wake_io+0x3e>
    5026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    502d:	00 00 00 
    5030:	48 89 d3             	mov    %rdx,%rbx
    5033:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5039:	eb ab                	jmp    4fe6 <fwp_wake_io+0x86>
    503b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5040:	45 84 db             	test   %r11b,%r11b
    5043:	74 07                	je     504c <fwp_wake_io+0xec>
    5045:	48 89 1d 3c e7 01 00 	mov    %rbx,0x1e73c(%rip)        # 23788 <fwp_ready_head>
    504c:	45 84 d2             	test   %r10b,%r10b
    504f:	74 07                	je     5058 <fwp_wake_io+0xf8>
    5051:	4c 89 05 28 e7 01 00 	mov    %r8,0x1e728(%rip)        # 23780 <fwp_ready_tail>
    5058:	5b                   	pop    %rbx
    5059:	c3                   	ret
    505a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5060:	c3                   	ret
    5061:	0f 1f 40 00          	nopl   0x0(%rax)
    5065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    506c:	00 00 00 00 

0000000000005070 <fwp_tape_buffers_release>:
    5070:	f3 0f 1e fa          	endbr64
    5074:	53                   	push   %rbx
    5075:	48 89 fb             	mov    %rdi,%rbx
    5078:	48 83 ec 10          	sub    $0x10,%rsp
    507c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5080:	48 85 c0             	test   %rax,%rax
    5083:	0f 88 df 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5089:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    508d:	48 85 d2             	test   %rdx,%rdx
    5090:	0f 88 d2 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5096:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    509c:	0f 87 c6 00 00 00    	ja     5168 <fwp_tape_buffers_release+0xf8>
    50a2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    50a6:	b8 00 00 08 00       	mov    $0x80000,%eax
    50ab:	48 c1 e1 03          	shl    $0x3,%rcx
    50af:	48 29 c8             	sub    %rcx,%rax
    50b2:	48 c1 e8 03          	shr    $0x3,%rax
    50b6:	48 39 d0             	cmp    %rdx,%rax
    50b9:	0f 82 a9 00 00 00    	jb     5168 <fwp_tape_buffers_release+0xf8>
    50bf:	48 8d 3d 5c a0 00 00 	lea    0xa05c(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    50c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    50cb:	48 89 14 24          	mov    %rdx,(%rsp)
    50cf:	e8 cc e2 ff ff       	call   33a0 <getenv@plt>
    50d4:	48 8b 14 24          	mov    (%rsp),%rdx
    50d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    50dd:	48 85 c0             	test   %rax,%rax
    50e0:	74 09                	je     50eb <fwp_tape_buffers_release+0x7b>
    50e2:	80 38 30             	cmpb   $0x30,(%rax)
    50e5:	0f 84 9d 00 00 00    	je     5188 <fwp_tape_buffers_release+0x118>
    50eb:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    50ef:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    50f3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    50fa:	77 78                	ja     5174 <fwp_tape_buffers_release+0x104>
    50fc:	48 8d 3d 9d df 01 00 	lea    0x1df9d(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    5103:	48 89 04 24          	mov    %rax,(%rsp)
    5107:	e8 04 f0 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    510c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5110:	48 8b 04 24          	mov    (%rsp),%rax
    5114:	0f 29 05 85 df 01 00 	movaps %xmm0,0x1df85(%rip)        # 230a0 <fwp_tape_workspace>
    511b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5120:	48 89 05 61 df 01 00 	mov    %rax,0x1df61(%rip)        # 23088 <fwp_tape_cached_bytes>
    5127:	0f 29 05 82 df 01 00 	movaps %xmm0,0x1df82(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    512e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5133:	0f 29 05 86 df 01 00 	movaps %xmm0,0x1df86(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    513a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    513e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5142:	48 89 15 87 df 01 00 	mov    %rdx,0x1df87(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    5149:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5150:	00 
    5151:	0f 11 03             	movups %xmm0,(%rbx)
    5154:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5158:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    515c:	48 83 c4 10          	add    $0x10,%rsp
    5160:	5b                   	pop    %rbx
    5161:	c3                   	ret
    5162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5168:	48 8d 3d b3 9f 00 00 	lea    0x9fb3(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    516f:	e8 2c e2 ff ff       	call   33a0 <getenv@plt>
    5174:	48 83 c4 10          	add    $0x10,%rsp
    5178:	48 89 df             	mov    %rbx,%rdi
    517b:	5b                   	pop    %rbx
    517c:	e9 8f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    5181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5188:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    518c:	0f 85 59 ff ff ff    	jne    50eb <fwp_tape_buffers_release+0x7b>
    5192:	48 83 c4 10          	add    $0x10,%rsp
    5196:	48 89 df             	mov    %rbx,%rdi
    5199:	5b                   	pop    %rbx
    519a:	e9 71 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    519f:	90                   	nop

00000000000051a0 <fwp_poll_events>:
    51a0:	53                   	push   %rbx
    51a1:	48 83 ec 20          	sub    $0x20,%rsp
    51a5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    51b3:	31 c0                	xor    %eax,%eax
    51b5:	e8 a6 f3 ff ff       	call   4560 <fwp_now_ns>
    51ba:	48 8b 1d b7 e5 01 00 	mov    0x1e5b7(%rip),%rbx        # 23778 <fwp_timers>
    51c1:	48 85 db             	test   %rbx,%rbx
    51c4:	0f 84 d6 00 00 00    	je     52a0 <fwp_poll_events+0x100>
    51ca:	48 89 c6             	mov    %rax,%rsi
    51cd:	48 89 da             	mov    %rbx,%rdx
    51d0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    51d7:	eb 16                	jmp    51ef <fwp_poll_events+0x4f>
    51d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51e7:	48 89 c8             	mov    %rcx,%rax
    51ea:	48 85 d2             	test   %rdx,%rdx
    51ed:	74 31                	je     5220 <fwp_poll_events+0x80>
    51ef:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51f3:	48 85 c0             	test   %rax,%rax
    51f6:	78 e8                	js     51e0 <fwp_poll_events+0x40>
    51f8:	48 39 c1             	cmp    %rax,%rcx
    51fb:	7c e3                	jl     51e0 <fwp_poll_events+0x40>
    51fd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5204:	48 85 d2             	test   %rdx,%rdx
    5207:	74 1c                	je     5225 <fwp_poll_events+0x85>
    5209:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    520d:	48 39 c1             	cmp    %rax,%rcx
    5210:	7c ce                	jl     51e0 <fwp_poll_events+0x40>
    5212:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5219:	48 85 d2             	test   %rdx,%rdx
    521c:	75 d1                	jne    51ef <fwp_poll_events+0x4f>
    521e:	66 90                	xchg   %ax,%ax
    5220:	48 85 c0             	test   %rax,%rax
    5223:	78 7b                	js     52a0 <fwp_poll_events+0x100>
    5225:	48 29 f0             	sub    %rsi,%rax
    5228:	48 89 c1             	mov    %rax,%rcx
    522b:	48 85 c0             	test   %rax,%rax
    522e:	0f 8e 9c 00 00 00    	jle    52d0 <fwp_poll_events+0x130>
    5234:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    523b:	de 1b 43 
    523e:	48 f7 ea             	imul   %rdx
    5241:	48 89 c8             	mov    %rcx,%rax
    5244:	48 c1 f8 3f          	sar    $0x3f,%rax
    5248:	48 c1 fa 12          	sar    $0x12,%rdx
    524c:	48 29 c2             	sub    %rax,%rdx
    524f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5256:	48 39 c1             	cmp    %rax,%rcx
    5259:	0f 95 c0             	setne  %al
    525c:	0f b6 c0             	movzbl %al,%eax
    525f:	48 01 d0             	add    %rdx,%rax
    5262:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5268:	0f 8f 32 01 00 00    	jg     53a0 <fwp_poll_events+0x200>
    526e:	48 85 c0             	test   %rax,%rax
    5271:	74 5d                	je     52d0 <fwp_poll_events+0x130>
    5273:	89 c1                	mov    %eax,%ecx
    5275:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    527c:	48 c1 e9 26          	shr    $0x26,%rcx
    5280:	48 63 d1             	movslq %ecx,%rdx
    5283:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5289:	29 c8                	sub    %ecx,%eax
    528b:	48 98                	cltq
    528d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5294:	e9 11 01 00 00       	jmp    53aa <fwp_poll_events+0x20a>
    5299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52a0:	e8 cb e9 ff ff       	call   3c70 <fwp_flush>
    52a5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    52aa:	be 01 00 00 00       	mov    $0x1,%esi
    52af:	48 8b 0d 8a dd 00 00 	mov    0xdd8a(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    52b6:	48 8d 3d 7b a5 00 00 	lea    0xa57b(%rip),%rdi        # f838 <_IO_stdin_used+0x838>
    52bd:	e8 be e3 ff ff       	call   3680 <fwrite@plt>
    52c2:	bf 65 00 00 00       	mov    $0x65,%edi
    52c7:	e8 a4 e3 ff ff       	call   3670 <exit@plt>
    52cc:	0f 1f 40 00          	nopl   0x0(%rax)
    52d0:	e8 8b f2 ff ff       	call   4560 <fwp_now_ns>
    52d5:	48 89 c1             	mov    %rax,%rcx
    52d8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    52dc:	eb 44                	jmp    5322 <fwp_poll_events+0x182>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    52e4:	75 33                	jne    5319 <fwp_poll_events+0x179>
    52e6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    52ea:	75 2d                	jne    5319 <fwp_poll_events+0x179>
    52ec:	48 8b 05 8d e4 01 00 	mov    0x1e48d(%rip),%rax        # 23780 <fwp_ready_tail>
    52f3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    52f7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    52fe:	00 00 00 00 
    5302:	48 85 c0             	test   %rax,%rax
    5305:	0f 84 05 01 00 00    	je     5410 <fwp_poll_events+0x270>
    530b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5312:	48 89 15 67 e4 01 00 	mov    %rdx,0x1e467(%rip)        # 23780 <fwp_ready_tail>
    5319:	48 85 db             	test   %rbx,%rbx
    531c:	0f 84 be 00 00 00    	je     53e0 <fwp_poll_events+0x240>
    5322:	48 89 da             	mov    %rbx,%rdx
    5325:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    532c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5330:	7f e7                	jg     5319 <fwp_poll_events+0x179>
    5332:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5336:	74 2e                	je     5366 <fwp_poll_events+0x1c6>
    5338:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    533f:	48 85 c0             	test   %rax,%rax
    5342:	0f 84 b8 00 00 00    	je     5400 <fwp_poll_events+0x260>
    5348:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    534f:	48 85 db             	test   %rbx,%rbx
    5352:	74 07                	je     535b <fwp_poll_events+0x1bb>
    5354:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    535b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    535f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5366:	48 8b 42 60          	mov    0x60(%rdx),%rax
    536a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    536e:	48 85 c0             	test   %rax,%rax
    5371:	0f 84 69 ff ff ff    	je     52e0 <fwp_poll_events+0x140>
    5377:	48 39 c8             	cmp    %rcx,%rax
    537a:	0f 8f 60 ff ff ff    	jg     52e0 <fwp_poll_events+0x140>
    5380:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5384:	0f 85 56 ff ff ff    	jne    52e0 <fwp_poll_events+0x140>
    538a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    538e:	75 89                	jne    5319 <fwp_poll_events+0x179>
    5390:	48 89 d7             	mov    %rdx,%rdi
    5393:	e8 68 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    5398:	e9 43 ff ff ff       	jmp    52e0 <fwp_poll_events+0x140>
    539d:	0f 1f 00             	nopl   (%rax)
    53a0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    53a5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    53aa:	48 89 e7             	mov    %rsp,%rdi
    53ad:	31 f6                	xor    %esi,%esi
    53af:	48 89 14 24          	mov    %rdx,(%rsp)
    53b3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    53b8:	e8 e3 e0 ff ff       	call   34a0 <nanosleep@plt>
    53bd:	48 8b 1d b4 e3 01 00 	mov    0x1e3b4(%rip),%rbx        # 23778 <fwp_timers>
    53c4:	e8 97 f1 ff ff       	call   4560 <fwp_now_ns>
    53c9:	48 89 c1             	mov    %rax,%rcx
    53cc:	48 85 db             	test   %rbx,%rbx
    53cf:	0f 85 03 ff ff ff    	jne    52d8 <fwp_poll_events+0x138>
    53d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53dc:	00 00 00 00 
    53e0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    53e5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    53ec:	00 00 
    53ee:	75 2c                	jne    541c <fwp_poll_events+0x27c>
    53f0:	48 83 c4 20          	add    $0x20,%rsp
    53f4:	5b                   	pop    %rbx
    53f5:	c3                   	ret
    53f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53fd:	00 00 00 
    5400:	48 89 1d 71 e3 01 00 	mov    %rbx,0x1e371(%rip)        # 23778 <fwp_timers>
    5407:	e9 43 ff ff ff       	jmp    534f <fwp_poll_events+0x1af>
    540c:	0f 1f 40 00          	nopl   0x0(%rax)
    5410:	48 89 15 71 e3 01 00 	mov    %rdx,0x1e371(%rip)        # 23788 <fwp_ready_head>
    5417:	e9 f6 fe ff ff       	jmp    5312 <fwp_poll_events+0x172>
    541c:	e8 3f e0 ff ff       	call   3460 <__stack_chk_fail@plt>
    5421:	0f 1f 40 00          	nopl   0x0(%rax)
    5425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    542c:	00 00 00 00 

0000000000005430 <fwp_rc_wide_dup>:
    5430:	48 89 fa             	mov    %rdi,%rdx
    5433:	48 8d 35 86 e3 01 00 	lea    0x1e386(%rip),%rsi        # 237c0 <fwp_heap>
    543a:	48 83 ec 18          	sub    $0x18,%rsp
    543e:	48 89 f9             	mov    %rdi,%rcx
    5441:	48 c1 ea 11          	shr    $0x11,%rdx
    5445:	48 31 fa             	xor    %rdi,%rdx
    5448:	48 89 d0             	mov    %rdx,%rax
    544b:	48 c1 e8 09          	shr    $0x9,%rax
    544f:	48 31 c2             	xor    %rax,%rdx
    5452:	0f b6 d2             	movzbl %dl,%edx
    5455:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    545c:	00 
    545d:	49 8b 00             	mov    (%r8),%rax
    5460:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5467:	00 00 
    5469:	75 21                	jne    548c <fwp_rc_wide_dup+0x5c>
    546b:	e9 98 00 00 00       	jmp    5508 <fwp_rc_wide_dup+0xd8>
    5470:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 2f                	je     54b8 <fwp_rc_wide_dup+0x88>
    5489:	48 89 d0             	mov    %rdx,%rax
    548c:	48 3b 08             	cmp    (%rax),%rcx
    548f:	75 ef                	jne    5480 <fwp_rc_wide_dup+0x50>
    5491:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5494:	74 7c                	je     5512 <fwp_rc_wide_dup+0xe2>
    5496:	48 8b 50 08          	mov    0x8(%rax),%rdx
    549a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    549e:	0f 84 91 00 00 00    	je     5535 <fwp_rc_wide_dup+0x105>
    54a4:	48 83 c2 01          	add    $0x1,%rdx
    54a8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    54ac:	48 83 c4 18          	add    $0x18,%rsp
    54b0:	c3                   	ret
    54b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54b8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    54bc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54bf:	75 68                	jne    5529 <fwp_rc_wide_dup+0xf9>
    54c1:	bf 18 00 00 00       	mov    $0x18,%edi
    54c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    54cb:	4c 89 04 24          	mov    %r8,(%rsp)
    54cf:	e8 dc e0 ff ff       	call   35b0 <malloc@plt>
    54d4:	4c 8b 04 24          	mov    (%rsp),%r8
    54d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    54dd:	48 85 c0             	test   %rax,%rax
    54e0:	74 5f                	je     5541 <fwp_rc_wide_dup+0x111>
    54e2:	48 89 08             	mov    %rcx,(%rax)
    54e5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    54ec:	00 
    54ed:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    54f4:	00 
    54f5:	49 89 00             	mov    %rax,(%r8)
    54f8:	c6 01 ff             	movb   $0xff,(%rcx)
    54fb:	48 83 05 05 ff 01 00 	addq   $0x1,0x1ff05(%rip)        # 25408 <fwp_heap+0x1c48>
    5502:	01 
    5503:	48 83 c4 18          	add    $0x18,%rsp
    5507:	c3                   	ret
    5508:	80 3f fe             	cmpb   $0xfe,(%rdi)
    550b:	75 13                	jne    5520 <fwp_rc_wide_dup+0xf0>
    550d:	48 85 c0             	test   %rax,%rax
    5510:	74 af                	je     54c1 <fwp_rc_wide_dup+0x91>
    5512:	48 8d 3d 4f a3 00 00 	lea    0xa34f(%rip),%rdi        # f868 <_IO_stdin_used+0x868>
    5519:	e8 d2 ee ff ff       	call   43f0 <fwp_trap>
    551e:	66 90                	xchg   %ax,%ax
    5520:	48 85 c0             	test   %rax,%rax
    5523:	0f 85 6d ff ff ff    	jne    5496 <fwp_rc_wide_dup+0x66>
    5529:	48 8d 3d 60 a3 00 00 	lea    0xa360(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    5530:	e8 bb ee ff ff       	call   43f0 <fwp_trap>
    5535:	48 8d 3d f7 9b 00 00 	lea    0x9bf7(%rip),%rdi        # f133 <_IO_stdin_used+0x133>
    553c:	e8 af ee ff ff       	call   43f0 <fwp_trap>
    5541:	e8 6a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    5546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    554d:	00 00 00 

0000000000005550 <fwp_rc_forget_slot>:
    5550:	80 3f ff             	cmpb   $0xff,(%rdi)
    5553:	74 0b                	je     5560 <fwp_rc_forget_slot+0x10>
    5555:	c3                   	ret
    5556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    555d:	00 00 00 
    5560:	48 89 f8             	mov    %rdi,%rax
    5563:	48 83 ec 08          	sub    $0x8,%rsp
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 c1 e8 11          	shr    $0x11,%rax
    556e:	48 31 f8             	xor    %rdi,%rax
    5571:	48 89 c1             	mov    %rax,%rcx
    5574:	48 c1 e9 09          	shr    $0x9,%rcx
    5578:	48 31 c8             	xor    %rcx,%rax
    557b:	48 8d 0d 3e e2 01 00 	lea    0x1e23e(%rip),%rcx        # 237c0 <fwp_heap>
    5582:	0f b6 c0             	movzbl %al,%eax
    5585:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    558c:	00 
    558d:	48 85 ff             	test   %rdi,%rdi
    5590:	74 3c                	je     55ce <fwp_rc_forget_slot+0x7e>
    5592:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5599:	00 
    559a:	48 8b 01             	mov    (%rcx),%rax
    559d:	eb 11                	jmp    55b0 <fwp_rc_forget_slot+0x60>
    559f:	90                   	nop
    55a0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    55a4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    55a8:	48 85 ff             	test   %rdi,%rdi
    55ab:	74 21                	je     55ce <fwp_rc_forget_slot+0x7e>
    55ad:	48 89 f8             	mov    %rdi,%rax
    55b0:	48 3b 10             	cmp    (%rax),%rdx
    55b3:	75 eb                	jne    55a0 <fwp_rc_forget_slot+0x50>
    55b5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    55b9:	48 89 01             	mov    %rax,(%rcx)
    55bc:	e8 ff dd ff ff       	call   33c0 <free@plt>
    55c1:	48 83 2d 3f fe 01 00 	subq   $0x1,0x1fe3f(%rip)        # 25408 <fwp_heap+0x1c48>
    55c8:	01 
    55c9:	48 83 c4 08          	add    $0x8,%rsp
    55cd:	c3                   	ret
    55ce:	48 8d 3d bb a2 00 00 	lea    0xa2bb(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    55d5:	e8 16 ee ff ff       	call   43f0 <fwp_trap>
    55da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000055e0 <fwp_rc_prepare_chunk>:
    55e0:	48 83 3d 20 fe 01 00 	cmpq   $0x0,0x1fe20(%rip)        # 25408 <fwp_heap+0x1c48>
    55e7:	00 
    55e8:	41 54                	push   %r12
    55ea:	49 89 f4             	mov    %rsi,%r12
    55ed:	55                   	push   %rbp
    55ee:	48 89 fd             	mov    %rdi,%rbp
    55f1:	53                   	push   %rbx
    55f2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    55f5:	0f 84 7d 00 00 00    	je     5678 <fwp_rc_prepare_chunk+0x98>
    55fb:	31 db                	xor    %ebx,%ebx
    55fd:	85 c0                	test   %eax,%eax
    55ff:	75 5f                	jne    5660 <fwp_rc_prepare_chunk+0x80>
    5601:	48 85 f6             	test   %rsi,%rsi
    5604:	74 7c                	je     5682 <fwp_rc_prepare_chunk+0xa2>
    5606:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    560a:	e8 b1 dd ff ff       	call   33c0 <free@plt>
    560f:	90                   	nop
    5610:	be 01 00 00 00       	mov    $0x1,%esi
    5615:	4c 89 e7             	mov    %r12,%rdi
    5618:	e8 03 df ff ff       	call   3520 <calloc@plt>
    561d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5621:	48 85 c0             	test   %rax,%rax
    5624:	0f 85 87 00 00 00    	jne    56b1 <fwp_rc_prepare_chunk+0xd1>
    562a:	e8 81 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    562f:	90                   	nop
    5630:	e8 1b ff ff ff       	call   5550 <fwp_rc_forget_slot>
    5635:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5638:	48 83 c3 01          	add    $0x1,%rbx
    563c:	48 39 c3             	cmp    %rax,%rbx
    563f:	73 37                	jae    5678 <fwp_rc_prepare_chunk+0x98>
    5641:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5648:	00 00 
    564a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5651:	00 00 00 00 
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5664:	48 01 df             	add    %rbx,%rdi
    5667:	80 3f ff             	cmpb   $0xff,(%rdi)
    566a:	74 c4                	je     5630 <fwp_rc_prepare_chunk+0x50>
    566c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    566f:	48 83 c3 01          	add    $0x1,%rbx
    5673:	48 39 c3             	cmp    %rax,%rbx
    5676:	72 e8                	jb     5660 <fwp_rc_prepare_chunk+0x80>
    5678:	49 39 c4             	cmp    %rax,%r12
    567b:	75 13                	jne    5690 <fwp_rc_prepare_chunk+0xb0>
    567d:	4d 85 e4             	test   %r12,%r12
    5680:	75 46                	jne    56c8 <fwp_rc_prepare_chunk+0xe8>
    5682:	5b                   	pop    %rbx
    5683:	5d                   	pop    %rbp
    5684:	41 5c                	pop    %r12
    5686:	c3                   	ret
    5687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    568e:	00 00 
    5690:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5694:	48 29 05 75 fd 01 00 	sub    %rax,0x1fd75(%rip)        # 25410 <fwp_heap+0x1c50>
    569b:	e8 20 dd ff ff       	call   33c0 <free@plt>
    56a0:	4d 85 e4             	test   %r12,%r12
    56a3:	0f 85 67 ff ff ff    	jne    5610 <fwp_rc_prepare_chunk+0x30>
    56a9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    56b0:	00 
    56b1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    56b5:	5b                   	pop    %rbx
    56b6:	4c 01 25 53 fd 01 00 	add    %r12,0x1fd53(%rip)        # 25410 <fwp_heap+0x1c50>
    56bd:	5d                   	pop    %rbp
    56be:	41 5c                	pop    %r12
    56c0:	c3                   	ret
    56c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56c8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56cc:	5b                   	pop    %rbx
    56cd:	4c 89 e2             	mov    %r12,%rdx
    56d0:	31 f6                	xor    %esi,%esi
    56d2:	5d                   	pop    %rbp
    56d3:	41 5c                	pop    %r12
    56d5:	e9 e6 dd ff ff       	jmp    34c0 <memset@plt>
    56da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000056e0 <fwp_heap_refill>:
    56e0:	41 56                	push   %r14
    56e2:	41 89 d6             	mov    %edx,%r14d
    56e5:	41 55                	push   %r13
    56e7:	41 89 f5             	mov    %esi,%r13d
    56ea:	41 54                	push   %r12
    56ec:	49 89 fc             	mov    %rdi,%r12
    56ef:	bf 01 00 00 00       	mov    $0x1,%edi
    56f4:	55                   	push   %rbp
    56f5:	53                   	push   %rbx
    56f6:	e8 85 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    56fb:	48 89 c3             	mov    %rax,%rbx
    56fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5702:	48 8b 05 af f4 01 00 	mov    0x1f4af(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    5709:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    570d:	48 8d 05 ac e0 01 00 	lea    0x1e0ac(%rip),%rax        # 237c0 <fwp_heap>
    5714:	31 d2                	xor    %edx,%edx
    5716:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    571a:	48 89 ef             	mov    %rbp,%rdi
    571d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5721:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5725:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    572c:	00 
    572d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5732:	f7 f1                	div    %ecx
    5734:	31 d2                	xor    %edx,%edx
    5736:	66 0f 6e c1          	movd   %ecx,%xmm0
    573a:	66 0f 6e c8          	movd   %eax,%xmm1
    573e:	89 c6                	mov    %eax,%esi
    5740:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5745:	48 01 c8             	add    %rcx,%rax
    5748:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    574c:	48 f7 f1             	div    %rcx
    574f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5754:	89 45 18             	mov    %eax,0x18(%rbp)
    5757:	e8 84 fe ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    575c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    575f:	48 89 d8             	mov    %rbx,%rax
    5762:	48 c1 e0 10          	shl    $0x10,%rax
    5766:	48 03 05 03 f4 01 00 	add    0x1f403(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    576d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5771:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5776:	8b 55 08             	mov    0x8(%rbp),%edx
    5779:	48 0f af d1          	imul   %rcx,%rdx
    577d:	48 01 c2             	add    %rax,%rdx
    5780:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5785:	5b                   	pop    %rbx
    5786:	5d                   	pop    %rbp
    5787:	41 5c                	pop    %r12
    5789:	41 5d                	pop    %r13
    578b:	41 5e                	pop    %r14
    578d:	c3                   	ret
    578e:	66 90                	xchg   %ax,%ax

0000000000005790 <fwp_mem_free>:
    5790:	48 85 ff             	test   %rdi,%rdi
    5793:	0f 84 17 02 00 00    	je     59b0 <fwp_mem_free+0x220>
    5799:	48 8b 35 d0 f3 01 00 	mov    0x1f3d0(%rip),%rsi        # 24b70 <fwp_heap+0x13b0>
    57a0:	48 8b 05 f1 f3 01 00 	mov    0x1f3f1(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    57a7:	48 89 fa             	mov    %rdi,%rdx
    57aa:	48 29 f2             	sub    %rsi,%rdx
    57ad:	48 c1 e0 10          	shl    $0x10,%rax
    57b1:	48 39 c2             	cmp    %rax,%rdx
    57b4:	0f 83 f6 01 00 00    	jae    59b0 <fwp_mem_free+0x220>
    57ba:	49 89 d1             	mov    %rdx,%r9
    57bd:	49 c1 e9 10          	shr    $0x10,%r9
    57c1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    57c5:	48 c1 e0 03          	shl    $0x3,%rax
    57c9:	49 89 c0             	mov    %rax,%r8
    57cc:	4c 03 05 e5 f3 01 00 	add    0x1f3e5(%rip),%r8        # 24bb8 <fwp_heap+0x13f8>
    57d3:	0f 84 d7 01 00 00    	je     59b0 <fwp_mem_free+0x220>
    57d9:	48 83 ec 38          	sub    $0x38,%rsp
    57dd:	48 89 f9             	mov    %rdi,%rcx
    57e0:	41 0f b6 38          	movzbl (%r8),%edi
    57e4:	40 80 ff 01          	cmp    $0x1,%dil
    57e8:	74 16                	je     5800 <fwp_mem_free+0x70>
    57ea:	40 80 ff 02          	cmp    $0x2,%dil
    57ee:	0f 84 94 00 00 00    	je     5888 <fwp_mem_free+0xf8>
    57f4:	48 83 c4 38          	add    $0x38,%rsp
    57f8:	c3                   	ret
    57f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5800:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5804:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5809:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    580e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5812:	4d 85 d2             	test   %r10,%r10
    5815:	74 1d                	je     5834 <fwp_mem_free+0xa4>
    5817:	0f b7 c1             	movzwl %cx,%eax
    581a:	31 d2                	xor    %edx,%edx
    581c:	48 f7 f7             	div    %rdi
    581f:	49 01 c2             	add    %rax,%r10
    5822:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5826:	0f 84 44 01 00 00    	je     5970 <fwp_mem_free+0x1e0>
    582c:	41 c6 02 00          	movb   $0x0,(%r10)
    5830:	41 8b 78 04          	mov    0x4(%r8),%edi
    5834:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    583b:	49 63 c1             	movslq %r9d,%rax
    583e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5842:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5846:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    584b:	f2 0f 58 05 ad f3 01 	addsd  0x1f3ad(%rip),%xmm0        # 24c00 <fwp_heap+0x1440>
    5852:	00 
    5853:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5857:	48 8d 05 62 df 01 00 	lea    0x1df62(%rip),%rax        # 237c0 <fwp_heap>
    585e:	48 01 d0             	add    %rdx,%rax
    5861:	48 8b 10             	mov    (%rax),%rdx
    5864:	48 f7 d2             	not    %rdx
    5867:	48 89 11             	mov    %rdx,(%rcx)
    586a:	48 89 08             	mov    %rcx,(%rax)
    586d:	48 29 3d 6c f3 01 00 	sub    %rdi,0x1f36c(%rip)        # 24be0 <fwp_heap+0x1420>
    5874:	f2 0f 11 05 84 f3 01 	movsd  %xmm0,0x1f384(%rip)        # 24c00 <fwp_heap+0x1440>
    587b:	00 
    587c:	48 83 c4 38          	add    $0x38,%rsp
    5880:	c3                   	ret
    5881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5888:	66 31 d2             	xor    %dx,%dx
    588b:	48 01 d6             	add    %rdx,%rsi
    588e:	48 39 f1             	cmp    %rsi,%rcx
    5891:	0f 85 5d ff ff ff    	jne    57f4 <fwp_mem_free+0x64>
    5897:	49 8b 50 10          	mov    0x10(%r8),%rdx
    589b:	48 29 15 3e f3 01 00 	sub    %rdx,0x1f33e(%rip)        # 24be0 <fwp_heap+0x1420>
    58a2:	48 85 d2             	test   %rdx,%rdx
    58a5:	0f 88 a5 00 00 00    	js     5950 <fwp_mem_free+0x1c0>
    58ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58af:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    58b4:	f2 0f 58 05 44 f3 01 	addsd  0x1f344(%rip),%xmm0        # 24c00 <fwp_heap+0x1440>
    58bb:	00 
    58bc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    58c0:	f2 0f 11 05 38 f3 01 	movsd  %xmm0,0x1f338(%rip)        # 24c00 <fwp_heap+0x1440>
    58c7:	00 
    58c8:	48 85 d2             	test   %rdx,%rdx
    58cb:	74 0c                	je     58d9 <fwp_mem_free+0x149>
    58cd:	80 3a ff             	cmpb   $0xff,(%rdx)
    58d0:	0f 84 db 00 00 00    	je     59b1 <fwp_mem_free+0x221>
    58d6:	c6 02 00             	movb   $0x0,(%rdx)
    58d9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    58dd:	48 85 c9             	test   %rcx,%rcx
    58e0:	74 3e                	je     5920 <fwp_mem_free+0x190>
    58e2:	48 8b 15 cf f2 01 00 	mov    0x1f2cf(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    58e9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    58ed:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    58f1:	48 01 d0             	add    %rdx,%rax
    58f4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    58f8:	48 89 d6             	mov    %rdx,%rsi
    58fb:	48 29 c6             	sub    %rax,%rsi
    58fe:	83 e6 08             	and    $0x8,%esi
    5901:	74 0d                	je     5910 <fwp_mem_free+0x180>
    5903:	c6 00 00             	movb   $0x0,(%rax)
    5906:	48 83 c0 28          	add    $0x28,%rax
    590a:	48 39 c2             	cmp    %rax,%rdx
    590d:	74 11                	je     5920 <fwp_mem_free+0x190>
    590f:	90                   	nop
    5910:	c6 00 00             	movb   $0x0,(%rax)
    5913:	48 83 c0 50          	add    $0x50,%rax
    5917:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    591b:	48 39 c2             	cmp    %rax,%rdx
    591e:	75 f0                	jne    5910 <fwp_mem_free+0x180>
    5920:	48 01 0d c9 f2 01 00 	add    %rcx,0x1f2c9(%rip)        # 24bf0 <fwp_heap+0x1430>
    5927:	4c 3b 0d 82 f2 01 00 	cmp    0x1f282(%rip),%r9        # 24bb0 <fwp_heap+0x13f0>
    592e:	73 07                	jae    5937 <fwp_mem_free+0x1a7>
    5930:	4c 89 0d 79 f2 01 00 	mov    %r9,0x1f279(%rip)        # 24bb0 <fwp_heap+0x13f0>
    5937:	4c 3b 0d 6a f2 01 00 	cmp    0x1f26a(%rip),%r9        # 24ba8 <fwp_heap+0x13e8>
    593e:	0f 83 b0 fe ff ff    	jae    57f4 <fwp_mem_free+0x64>
    5944:	4c 89 0d 5d f2 01 00 	mov    %r9,0x1f25d(%rip)        # 24ba8 <fwp_heap+0x13e8>
    594b:	e9 a4 fe ff ff       	jmp    57f4 <fwp_mem_free+0x64>
    5950:	48 89 d1             	mov    %rdx,%rcx
    5953:	83 e2 01             	and    $0x1,%edx
    5956:	66 0f ef c0          	pxor   %xmm0,%xmm0
    595a:	48 d1 e9             	shr    $1,%rcx
    595d:	48 09 d1             	or     %rdx,%rcx
    5960:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5965:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5969:	e9 46 ff ff ff       	jmp    58b4 <fwp_mem_free+0x124>
    596e:	66 90                	xchg   %ax,%ax
    5970:	4c 89 d7             	mov    %r10,%rdi
    5973:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5978:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    597d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5982:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5986:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    598b:	e8 c0 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    5990:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5995:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    599a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    599f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    59a4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    59a9:	e9 7e fe ff ff       	jmp    582c <fwp_mem_free+0x9c>
    59ae:	66 90                	xchg   %ax,%ax
    59b0:	c3                   	ret
    59b1:	48 89 d7             	mov    %rdx,%rdi
    59b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    59b9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    59be:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    59c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    59c8:	e8 83 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    59cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    59d2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    59d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    59dc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    59e1:	e9 f0 fe ff ff       	jmp    58d6 <fwp_mem_free+0x146>
    59e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    59ed:	00 00 00 

00000000000059f0 <fwp_heap_alloc_big>:
    59f0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    59f7:	00 00 40 
    59fa:	41 57                	push   %r15
    59fc:	41 56                	push   %r14
    59fe:	41 55                	push   %r13
    5a00:	41 54                	push   %r12
    5a02:	55                   	push   %rbp
    5a03:	53                   	push   %rbx
    5a04:	48 83 ec 08          	sub    $0x8,%rsp
    5a08:	48 39 f8             	cmp    %rdi,%rax
    5a0b:	0f 82 fa 00 00 00    	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5a11:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a18:	49 89 fd             	mov    %rdi,%r13
    5a1b:	41 89 f6             	mov    %esi,%r14d
    5a1e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a22:	48 89 ef             	mov    %rbp,%rdi
    5a25:	e8 56 e5 ff ff       	call   3f80 <fwp_heap_chunks>
    5a2a:	be 01 00 00 00       	mov    $0x1,%esi
    5a2f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a33:	49 89 c4             	mov    %rax,%r12
    5a36:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a3d:	00 
    5a3e:	48 03 3d 73 f1 01 00 	add    0x1f173(%rip),%rdi        # 24bb8 <fwp_heap+0x13f8>
    5a45:	c6 07 02             	movb   $0x2,(%rdi)
    5a48:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5a4c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5a4f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5a53:	e8 88 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a58:	48 83 fd 01          	cmp    $0x1,%rbp
    5a5c:	76 47                	jbe    5aa5 <fwp_heap_alloc_big+0xb5>
    5a5e:	4c 01 e5             	add    %r12,%rbp
    5a61:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5a68:	00 
    5a69:	4c 8d 3d 50 dd 01 00 	lea    0x1dd50(%rip),%r15        # 237c0 <fwp_heap>
    5a70:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5a75:	49 c1 e6 03          	shl    $0x3,%r14
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5a87:	31 f6                	xor    %esi,%esi
    5a89:	48 01 dd             	add    %rbx,%rbp
    5a8c:	48 83 c3 28          	add    $0x28,%rbx
    5a90:	48 89 ef             	mov    %rbp,%rdi
    5a93:	e8 48 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a98:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5a9c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5aa0:	49 39 de             	cmp    %rbx,%r14
    5aa3:	75 db                	jne    5a80 <fwp_heap_alloc_big+0x90>
    5aa5:	49 c1 e4 10          	shl    $0x10,%r12
    5aa9:	4c 03 25 c0 f0 01 00 	add    0x1f0c0(%rip),%r12        # 24b70 <fwp_heap+0x13b0>
    5ab0:	4c 89 ea             	mov    %r13,%rdx
    5ab3:	31 f6                	xor    %esi,%esi
    5ab5:	4c 89 e7             	mov    %r12,%rdi
    5ab8:	e8 03 da ff ff       	call   34c0 <memset@plt>
    5abd:	4c 89 e8             	mov    %r13,%rax
    5ac0:	48 03 05 19 f1 01 00 	add    0x1f119(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5ac7:	72 42                	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5ac9:	48 39 05 18 f1 01 00 	cmp    %rax,0x1f118(%rip)        # 24be8 <fwp_heap+0x1428>
    5ad0:	48 89 05 09 f1 01 00 	mov    %rax,0x1f109(%rip)        # 24be0 <fwp_heap+0x1420>
    5ad7:	73 07                	jae    5ae0 <fwp_heap_alloc_big+0xf0>
    5ad9:	48 89 05 08 f1 01 00 	mov    %rax,0x1f108(%rip)        # 24be8 <fwp_heap+0x1428>
    5ae0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ae4:	4c 89 e0             	mov    %r12,%rax
    5ae7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5aec:	f2 0f 58 05 04 f1 01 	addsd  0x1f104(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5af3:	00 
    5af4:	f2 0f 11 05 fc f0 01 	movsd  %xmm0,0x1f0fc(%rip)        # 24bf8 <fwp_heap+0x1438>
    5afb:	00 
    5afc:	48 83 c4 08          	add    $0x8,%rsp
    5b00:	5b                   	pop    %rbx
    5b01:	5d                   	pop    %rbp
    5b02:	41 5c                	pop    %r12
    5b04:	41 5d                	pop    %r13
    5b06:	41 5e                	pop    %r14
    5b08:	41 5f                	pop    %r15
    5b0a:	c3                   	ret
    5b0b:	e8 a0 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b10 <fwp_heap_alloc_slow>:
    5b10:	53                   	push   %rbx
    5b11:	48 89 f9             	mov    %rdi,%rcx
    5b14:	41 89 f1             	mov    %esi,%r9d
    5b17:	48 83 ec 10          	sub    $0x10,%rsp
    5b1b:	8b 05 43 f0 01 00    	mov    0x1f043(%rip),%eax        # 24b64 <fwp_heap+0x13a4>
    5b21:	85 c0                	test   %eax,%eax
    5b23:	0f 84 c7 00 00 00    	je     5bf0 <fwp_heap_alloc_slow+0xe0>
    5b29:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b30:	0f 87 dd 00 00 00    	ja     5c13 <fwp_heap_alloc_slow+0x103>
    5b36:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b3a:	48 8d 3d 7f dc 01 00 	lea    0x1dc7f(%rip),%rdi        # 237c0 <fwp_heap>
    5b41:	49 63 f1             	movslq %r9d,%rsi
    5b44:	48 c1 e8 04          	shr    $0x4,%rax
    5b48:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5b4f:	00 00 
    5b51:	41 0f b6 c2          	movzbl %r10b,%eax
    5b55:	4c 89 d2             	mov    %r10,%rdx
    5b58:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5b5c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5b63:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5b6a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5b6e:	48 01 f8             	add    %rdi,%rax
    5b71:	4c 8b 00             	mov    (%rax),%r8
    5b74:	4d 85 c0             	test   %r8,%r8
    5b77:	0f 84 ab 00 00 00    	je     5c28 <fwp_heap_alloc_slow+0x118>
    5b7d:	49 8b 10             	mov    (%r8),%rdx
    5b80:	48 f7 d2             	not    %rdx
    5b83:	48 89 10             	mov    %rdx,(%rax)
    5b86:	41 83 f9 01          	cmp    $0x1,%r9d
    5b8a:	4c 89 c7             	mov    %r8,%rdi
    5b8d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5b91:	31 f6                	xor    %esi,%esi
    5b93:	48 89 ca             	mov    %rcx,%rdx
    5b96:	e8 25 d9 ff ff       	call   34c0 <memset@plt>
    5b9b:	49 89 c0             	mov    %rax,%r8
    5b9e:	48 89 d8             	mov    %rbx,%rax
    5ba1:	48 03 05 38 f0 01 00 	add    0x1f038(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5ba8:	0f 82 d9 00 00 00    	jb     5c87 <fwp_heap_alloc_slow+0x177>
    5bae:	48 39 05 33 f0 01 00 	cmp    %rax,0x1f033(%rip)        # 24be8 <fwp_heap+0x1428>
    5bb5:	48 89 05 24 f0 01 00 	mov    %rax,0x1f024(%rip)        # 24be0 <fwp_heap+0x1420>
    5bbc:	73 07                	jae    5bc5 <fwp_heap_alloc_slow+0xb5>
    5bbe:	48 89 05 23 f0 01 00 	mov    %rax,0x1f023(%rip)        # 24be8 <fwp_heap+0x1428>
    5bc5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bc9:	4c 89 c0             	mov    %r8,%rax
    5bcc:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5bd1:	f2 0f 58 05 1f f0 01 	addsd  0x1f01f(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5bd8:	00 
    5bd9:	f2 0f 11 05 17 f0 01 	movsd  %xmm0,0x1f017(%rip)        # 24bf8 <fwp_heap+0x1438>
    5be0:	00 
    5be1:	48 83 c4 10          	add    $0x10,%rsp
    5be5:	5b                   	pop    %rbx
    5be6:	c3                   	ret
    5be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bee:	00 00 
    5bf0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5bf4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5bf8:	e8 73 f1 ff ff       	call   4d70 <fwp_heap_init>
    5bfd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c01:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c06:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c0d:	0f 86 23 ff ff ff    	jbe    5b36 <fwp_heap_alloc_slow+0x26>
    5c13:	48 83 c4 10          	add    $0x10,%rsp
    5c17:	44 89 ce             	mov    %r9d,%esi
    5c1a:	48 89 cf             	mov    %rcx,%rdi
    5c1d:	5b                   	pop    %rbx
    5c1e:	e9 cd fd ff ff       	jmp    59f0 <fwp_heap_alloc_big>
    5c23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c28:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c2c:	4d 85 c0             	test   %r8,%r8
    5c2f:	74 1f                	je     5c50 <fwp_heap_alloc_slow+0x140>
    5c31:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c35:	4d 29 c3             	sub    %r8,%r11
    5c38:	49 39 db             	cmp    %rbx,%r11
    5c3b:	72 13                	jb     5c50 <fwp_heap_alloc_slow+0x140>
    5c3d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5c41:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c45:	e9 3c ff ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c50:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5c57:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5c5b:	44 89 ca             	mov    %r9d,%edx
    5c5e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5c63:	44 89 0c 24          	mov    %r9d,(%rsp)
    5c67:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5c6b:	44 89 d6             	mov    %r10d,%esi
    5c6e:	48 01 c7             	add    %rax,%rdi
    5c71:	e8 6a fa ff ff       	call   56e0 <fwp_heap_refill>
    5c76:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5c7b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5c7f:	49 89 c0             	mov    %rax,%r8
    5c82:	e9 ff fe ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c87:	e8 24 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005c90 <fwp_heap_alloc>:
    5c90:	8b 05 ce ee 01 00    	mov    0x1eece(%rip),%eax        # 24b64 <fwp_heap+0x13a4>
    5c96:	48 89 fa             	mov    %rdi,%rdx
    5c99:	89 f7                	mov    %esi,%edi
    5c9b:	85 c0                	test   %eax,%eax
    5c9d:	0f 84 f5 00 00 00    	je     5d98 <fwp_heap_alloc+0x108>
    5ca3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5caa:	0f 87 e8 00 00 00    	ja     5d98 <fwp_heap_alloc+0x108>
    5cb0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5cb4:	48 8d 05 05 db 01 00 	lea    0x1db05(%rip),%rax        # 237c0 <fwp_heap>
    5cbb:	48 83 ec 18          	sub    $0x18,%rsp
    5cbf:	41 89 f0             	mov    %esi,%r8d
    5cc2:	48 c1 e9 04          	shr    $0x4,%rcx
    5cc6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5ccd:	00 
    5cce:	48 63 cf             	movslq %edi,%rcx
    5cd1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5cd8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5cdf:	00 
    5ce0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5ce4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5ce8:	48 01 c8             	add    %rcx,%rax
    5ceb:	48 8b 08             	mov    (%rax),%rcx
    5cee:	48 85 c9             	test   %rcx,%rcx
    5cf1:	74 6d                	je     5d60 <fwp_heap_alloc+0xd0>
    5cf3:	48 8b 31             	mov    (%rcx),%rsi
    5cf6:	48 f7 d6             	not    %rsi
    5cf9:	48 89 30             	mov    %rsi,(%rax)
    5cfc:	41 83 f8 01          	cmp    $0x1,%r8d
    5d00:	48 89 cf             	mov    %rcx,%rdi
    5d03:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d08:	49 0f 45 d1          	cmovne %r9,%rdx
    5d0c:	31 f6                	xor    %esi,%esi
    5d0e:	e8 ad d7 ff ff       	call   34c0 <memset@plt>
    5d13:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d18:	48 89 c1             	mov    %rax,%rcx
    5d1b:	4c 89 c8             	mov    %r9,%rax
    5d1e:	48 03 05 bb ee 01 00 	add    0x1eebb(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5d25:	72 7b                	jb     5da2 <fwp_heap_alloc+0x112>
    5d27:	48 39 05 ba ee 01 00 	cmp    %rax,0x1eeba(%rip)        # 24be8 <fwp_heap+0x1428>
    5d2e:	48 89 05 ab ee 01 00 	mov    %rax,0x1eeab(%rip)        # 24be0 <fwp_heap+0x1420>
    5d35:	73 07                	jae    5d3e <fwp_heap_alloc+0xae>
    5d37:	48 89 05 aa ee 01 00 	mov    %rax,0x1eeaa(%rip)        # 24be8 <fwp_heap+0x1428>
    5d3e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d42:	48 89 c8             	mov    %rcx,%rax
    5d45:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5d4a:	f2 0f 58 05 a6 ee 01 	addsd  0x1eea6(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5d51:	00 
    5d52:	f2 0f 11 05 9e ee 01 	movsd  %xmm0,0x1ee9e(%rip)        # 24bf8 <fwp_heap+0x1438>
    5d59:	00 
    5d5a:	48 83 c4 18          	add    $0x18,%rsp
    5d5e:	c3                   	ret
    5d5f:	90                   	nop
    5d60:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5d64:	48 85 c9             	test   %rcx,%rcx
    5d67:	74 0c                	je     5d75 <fwp_heap_alloc+0xe5>
    5d69:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5d6d:	48 29 ce             	sub    %rcx,%rsi
    5d70:	4c 39 ce             	cmp    %r9,%rsi
    5d73:	73 13                	jae    5d88 <fwp_heap_alloc+0xf8>
    5d75:	89 fe                	mov    %edi,%esi
    5d77:	48 83 c4 18          	add    $0x18,%rsp
    5d7b:	48 89 d7             	mov    %rdx,%rdi
    5d7e:	e9 8d fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5d83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d88:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5d8c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5d90:	e9 67 ff ff ff       	jmp    5cfc <fwp_heap_alloc+0x6c>
    5d95:	0f 1f 00             	nopl   (%rax)
    5d98:	89 fe                	mov    %edi,%esi
    5d9a:	48 89 d7             	mov    %rdx,%rdi
    5d9d:	e9 6e fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5da2:	e8 09 df ff ff       	call   3cb0 <fwp_heap_oom>
    5da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5dae:	00 00 

0000000000005db0 <fwp_data.part.0.constprop.0>:
    5db0:	41 56                	push   %r14
    5db2:	41 89 fe             	mov    %edi,%r14d
    5db5:	41 54                	push   %r12
    5db7:	49 89 f4             	mov    %rsi,%r12
    5dba:	55                   	push   %rbp
    5dbb:	53                   	push   %rbx
    5dbc:	48 83 ec 08          	sub    $0x8,%rsp
    5dc0:	8b 05 9e ed 01 00    	mov    0x1ed9e(%rip),%eax        # 24b64 <fwp_heap+0x13a4>
    5dc6:	85 c0                	test   %eax,%eax
    5dc8:	0f 84 fa 00 00 00    	je     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5dce:	0f b6 05 8d e9 01 00 	movzbl 0x1e98d(%rip),%eax        # 24762 <fwp_heap+0xfa2>
    5dd5:	48 8d 15 e4 d9 01 00 	lea    0x1d9e4(%rip),%rdx        # 237c0 <fwp_heap>
    5ddc:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5de3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5de7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5deb:	48 8b 18             	mov    (%rax),%rbx
    5dee:	48 85 db             	test   %rbx,%rbx
    5df1:	0f 84 a9 00 00 00    	je     5ea0 <fwp_data.part.0.constprop.0+0xf0>
    5df7:	48 8b 13             	mov    (%rbx),%rdx
    5dfa:	48 f7 d2             	not    %rdx
    5dfd:	48 89 10             	mov    %rdx,(%rax)
    5e00:	48 83 fd 18          	cmp    $0x18,%rbp
    5e04:	76 1b                	jbe    5e21 <fwp_data.part.0.constprop.0+0x71>
    5e06:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5e0a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5e0e:	31 f6                	xor    %esi,%esi
    5e10:	48 c1 e8 03          	shr    $0x3,%rax
    5e14:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5e1b:	00 
    5e1c:	e8 9f d6 ff ff       	call   34c0 <memset@plt>
    5e21:	48 89 e8             	mov    %rbp,%rax
    5e24:	48 03 05 b5 ed 01 00 	add    0x1edb5(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5e2b:	0f 82 a8 00 00 00    	jb     5ed9 <fwp_data.part.0.constprop.0+0x129>
    5e31:	48 39 05 b0 ed 01 00 	cmp    %rax,0x1edb0(%rip)        # 24be8 <fwp_heap+0x1428>
    5e38:	48 89 05 a1 ed 01 00 	mov    %rax,0x1eda1(%rip)        # 24be0 <fwp_heap+0x1420>
    5e3f:	73 07                	jae    5e48 <fwp_data.part.0.constprop.0+0x98>
    5e41:	48 89 05 a0 ed 01 00 	mov    %rax,0x1eda0(%rip)        # 24be8 <fwp_heap+0x1428>
    5e48:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e4c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5e51:	f2 0f 58 05 9f ed 01 	addsd  0x1ed9f(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 97 ed 01 	movsd  %xmm0,0x1ed97(%rip)        # 24bf8 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	b8 02 00 00 00       	mov    $0x2,%eax
    5e66:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5e6b:	66 0f 6e c8          	movd   %eax,%xmm1
    5e6f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5e73:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5e77:	49 8b 04 24          	mov    (%r12),%rax
    5e7b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5e7f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5e84:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5e88:	48 83 c4 08          	add    $0x8,%rsp
    5e8c:	48 89 d8             	mov    %rbx,%rax
    5e8f:	5b                   	pop    %rbx
    5e90:	5d                   	pop    %rbp
    5e91:	41 5c                	pop    %r12
    5e93:	41 5e                	pop    %r14
    5e95:	c3                   	ret
    5e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5e9d:	00 00 00 
    5ea0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5ea4:	48 85 db             	test   %rbx,%rbx
    5ea7:	74 1f                	je     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5ea9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5ead:	48 29 da             	sub    %rbx,%rdx
    5eb0:	48 39 ea             	cmp    %rbp,%rdx
    5eb3:	72 13                	jb     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5eb5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5eb9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ebd:	e9 3e ff ff ff       	jmp    5e00 <fwp_data.part.0.constprop.0+0x50>
    5ec2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ec8:	31 f6                	xor    %esi,%esi
    5eca:	bf 18 00 00 00       	mov    $0x18,%edi
    5ecf:	e8 bc fd ff ff       	call   5c90 <fwp_heap_alloc>
    5ed4:	48 89 c3             	mov    %rax,%rbx
    5ed7:	eb 88                	jmp    5e61 <fwp_data.part.0.constprop.0+0xb1>
    5ed9:	e8 d2 dd ff ff       	call   3cb0 <fwp_heap_oom>
    5ede:	66 90                	xchg   %ax,%ax

0000000000005ee0 <fwp_p_ad_push>:
    5ee0:	41 57                	push   %r15
    5ee2:	41 56                	push   %r14
    5ee4:	41 55                	push   %r13
    5ee6:	49 89 d5             	mov    %rdx,%r13
    5ee9:	41 54                	push   %r12
    5eeb:	49 89 fc             	mov    %rdi,%r12
    5eee:	55                   	push   %rbp
    5eef:	53                   	push   %rbx
    5ef0:	48 83 ec 38          	sub    $0x38,%rsp
    5ef4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5ef9:	48 85 ff             	test   %rdi,%rdi
    5efc:	79 09                	jns    5f07 <fwp_p_ad_push+0x27>
    5efe:	48 85 d2             	test   %rdx,%rdx
    5f01:	0f 88 a9 01 00 00    	js     60b0 <fwp_p_ad_push+0x1d0>
    5f07:	48 89 f8             	mov    %rdi,%rax
    5f0a:	48 89 0c 24          	mov    %rcx,(%rsp)
    5f0e:	48 09 d0             	or     %rdx,%rax
    5f11:	0f 89 79 01 00 00    	jns    6090 <fwp_p_ad_push+0x1b0>
    5f17:	48 89 f8             	mov    %rdi,%rax
    5f1a:	48 c1 f8 20          	sar    $0x20,%rax
    5f1e:	48 85 ff             	test   %rdi,%rdi
    5f21:	79 24                	jns    5f47 <fwp_p_ad_push+0x67>
    5f23:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5f28:	48 89 d0             	mov    %rdx,%rax
    5f2b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5f32:	00 
    5f33:	49 89 d4             	mov    %rdx,%r12
    5f36:	48 c1 f8 20          	sar    $0x20,%rax
    5f3a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5f41:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5f47:	48 89 c7             	mov    %rax,%rdi
    5f4a:	e8 81 e7 ff ff       	call   46d0 <fwp_tape_of>
    5f4f:	48 89 c3             	mov    %rax,%rbx
    5f52:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5f57:	0f 85 76 02 00 00    	jne    61d3 <fwp_p_ad_push+0x2f3>
    5f5d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    5f61:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    5f68:	0f 8f 59 02 00 00    	jg     61c7 <fwp_p_ad_push+0x2e7>
    5f6e:	44 89 e0             	mov    %r12d,%eax
    5f71:	4c 39 f8             	cmp    %r15,%rax
    5f74:	0f 8d 41 02 00 00    	jge    61bb <fwp_p_ad_push+0x2db>
    5f7a:	4d 85 ed             	test   %r13,%r13
    5f7d:	78 0c                	js     5f8b <fwp_p_ad_push+0xab>
    5f7f:	44 89 e8             	mov    %r13d,%eax
    5f82:	4c 39 f8             	cmp    %r15,%rax
    5f85:	0f 8d 30 02 00 00    	jge    61bb <fwp_p_ad_push+0x2db>
    5f8b:	4d 89 fe             	mov    %r15,%r14
    5f8e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5f92:	49 8d 46 01          	lea    0x1(%r14),%rax
    5f96:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5f9c:	0f 87 25 02 00 00    	ja     61c7 <fwp_p_ad_push+0x2e7>
    5fa2:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5fa6:	48 39 e8             	cmp    %rbp,%rax
    5fa9:	0f 8e 31 01 00 00    	jle    60e0 <fwp_p_ad_push+0x200>
    5faf:	48 85 ed             	test   %rbp,%rbp
    5fb2:	b9 40 00 00 00       	mov    $0x40,%ecx
    5fb7:	48 0f 44 e9          	cmove  %rcx,%rbp
    5fbb:	48 39 e8             	cmp    %rbp,%rax
    5fbe:	7e 20                	jle    5fe0 <fwp_p_ad_push+0x100>
    5fc0:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5fc7:	0f 8f 03 01 00 00    	jg     60d0 <fwp_p_ad_push+0x1f0>
    5fcd:	48 01 ed             	add    %rbp,%rbp
    5fd0:	48 39 e8             	cmp    %rbp,%rax
    5fd3:	7f eb                	jg     5fc0 <fwp_p_ad_push+0xe0>
    5fd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5fdc:	00 00 00 00 
    5fe0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5fe7:	00 
    5fe8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5fec:	48 89 c6             	mov    %rax,%rsi
    5fef:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    5ff4:	e8 d7 d5 ff ff       	call   35d0 <realloc@plt>
    5ff9:	48 85 c0             	test   %rax,%rax
    5ffc:	0f 84 dd 01 00 00    	je     61df <fwp_p_ad_push+0x2ff>
    6002:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    6006:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    600a:	48 89 43 20          	mov    %rax,0x20(%rbx)
    600e:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    6012:	48 89 e9             	mov    %rbp,%rcx
    6015:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6019:	48 c1 e1 04          	shl    $0x4,%rcx
    601d:	48 89 ce             	mov    %rcx,%rsi
    6020:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6025:	e8 a6 d5 ff ff       	call   35d0 <realloc@plt>
    602a:	48 85 c0             	test   %rax,%rax
    602d:	0f 84 ac 01 00 00    	je     61df <fwp_p_ad_push+0x2ff>
    6033:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    6037:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    603c:	4d 85 f6             	test   %r14,%r14
    603f:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6043:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6048:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    604f:	00 
    6050:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    6057:	00 
    6058:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    605c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    6063:	00 
    6064:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6068:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    606c:	0f 85 e2 00 00 00    	jne    6154 <fwp_p_ad_push+0x274>
    6072:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6076:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    607a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    607e:	49 01 c8             	add    %rcx,%r8
    6081:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    6085:	eb 79                	jmp    6100 <fwp_p_ad_push+0x220>
    6087:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    608e:	00 00 
    6090:	48 89 d0             	mov    %rdx,%rax
    6093:	48 c1 ff 20          	sar    $0x20,%rdi
    6097:	48 c1 f8 20          	sar    $0x20,%rax
    609b:	48 39 c7             	cmp    %rax,%rdi
    609e:	0f 84 a3 fe ff ff    	je     5f47 <fwp_p_ad_push+0x67>
    60a4:	48 8d 3d 0d 98 00 00 	lea    0x980d(%rip),%rdi        # f8b8 <_IO_stdin_used+0x8b8>
    60ab:	e8 40 e3 ff ff       	call   43f0 <fwp_trap>
    60b0:	48 83 c4 38          	add    $0x38,%rsp
    60b4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    60bb:	5b                   	pop    %rbx
    60bc:	5d                   	pop    %rbp
    60bd:	41 5c                	pop    %r12
    60bf:	41 5d                	pop    %r13
    60c1:	41 5e                	pop    %r14
    60c3:	41 5f                	pop    %r15
    60c5:	c3                   	ret
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    60d5:	e9 06 ff ff ff       	jmp    5fe0 <fwp_p_ad_push+0x100>
    60da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    60e0:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    60e4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    60e8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    60ef:	00 
    60f0:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    60f7:	00 
    60f8:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    60fc:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6100:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6106:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    610a:	4d 85 ed             	test   %r13,%r13
    610d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6112:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6118:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    611f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6123:	49 8d 47 01          	lea    0x1(%r15),%rax
    6127:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    612b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6131:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6135:	48 83 c4 38          	add    $0x38,%rsp
    6139:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6140:	ff ff ff 
    6143:	4c 21 e0             	and    %r12,%rax
    6146:	5b                   	pop    %rbx
    6147:	5d                   	pop    %rbp
    6148:	4c 09 f8             	or     %r15,%rax
    614b:	41 5c                	pop    %r12
    614d:	41 5d                	pop    %r13
    614f:	41 5e                	pop    %r14
    6151:	41 5f                	pop    %r15
    6153:	c3                   	ret
    6154:	48 39 ca             	cmp    %rcx,%rdx
    6157:	49 89 d6             	mov    %rdx,%r14
    615a:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    615f:	48 0f 43 ca          	cmovae %rdx,%rcx
    6163:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    6168:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    616d:	48 29 d1             	sub    %rdx,%rcx
    6170:	4c 89 ca             	mov    %r9,%rdx
    6173:	e8 e8 d3 ff ff       	call   3560 <__memmove_chk@plt>
    6178:	4c 03 73 30          	add    0x30(%rbx),%r14
    617c:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    6181:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6185:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    618a:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    618e:	48 03 7b 20          	add    0x20(%rbx),%rdi
    6192:	4c 89 d2             	mov    %r10,%rdx
    6195:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    619a:	e8 71 d4 ff ff       	call   3610 <memmove@plt>
    619f:	48 8b 43 30          	mov    0x30(%rbx),%rax
    61a3:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    61a7:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    61ac:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    61b1:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    61b6:	e9 bb fe ff ff       	jmp    6076 <fwp_p_ad_push+0x196>
    61bb:	48 8d 3d a5 8f 00 00 	lea    0x8fa5(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    61c2:	e8 29 e2 ff ff       	call   43f0 <fwp_trap>
    61c7:	48 8d 3d 7e 8f 00 00 	lea    0x8f7e(%rip),%rdi        # f14c <_IO_stdin_used+0x14c>
    61ce:	e8 1d e2 ff ff       	call   43f0 <fwp_trap>
    61d3:	48 8d 3d 26 97 00 00 	lea    0x9726(%rip),%rdi        # f900 <_IO_stdin_used+0x900>
    61da:	e8 11 e2 ff ff       	call   43f0 <fwp_trap>
    61df:	48 89 df             	mov    %rbx,%rdi
    61e2:	e8 19 da ff ff       	call   3c00 <fwp_tape_unlink_scope>
    61e7:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    61eb:	e8 d0 d1 ff ff       	call   33c0 <free@plt>
    61f0:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    61f4:	e8 c7 d1 ff ff       	call   33c0 <free@plt>
    61f9:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    61fd:	e8 be d1 ff ff       	call   33c0 <free@plt>
    6202:	31 c9                	xor    %ecx,%ecx
    6204:	31 c0                	xor    %eax,%eax
    6206:	31 d2                	xor    %edx,%edx
    6208:	89 53 04             	mov    %edx,0x4(%rbx)
    620b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    620f:	ba 13 00 00 00       	mov    $0x13,%edx
    6214:	be 01 00 00 00       	mov    $0x1,%esi
    6219:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    621d:	48 8d 3d e4 8d 00 00 	lea    0x8de4(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    6224:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6228:	48 8b 0d 11 ce 00 00 	mov    0xce11(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    622f:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6233:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    6237:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    623b:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    623f:	e8 3c d4 ff ff       	call   3680 <fwrite@plt>
    6244:	31 ff                	xor    %edi,%edi
    6246:	e8 75 d3 ff ff       	call   35c0 <fflush@plt>
    624b:	bf 66 00 00 00       	mov    $0x66,%edi
    6250:	e8 4b d4 ff ff       	call   36a0 <_Exit@plt>
    6255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    625c:	00 00 00 00 

0000000000006260 <w120>:
    6260:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6264:	41 55                	push   %r13
    6266:	48 89 fa             	mov    %rdi,%rdx
    6269:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    626d:	41 54                	push   %r12
    626f:	49 89 fc             	mov    %rdi,%r12
    6272:	55                   	push   %rbp
    6273:	53                   	push   %rbx
    6274:	48 89 f3             	mov    %rsi,%rbx
    6277:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    627c:	48 89 f1             	mov    %rsi,%rcx
    627f:	48 83 ec 28          	sub    $0x28,%rsp
    6283:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6289:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    628f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6295:	e8 46 fc ff ff       	call   5ee0 <fwp_p_ad_push>
    629a:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    62a0:	48 89 da             	mov    %rbx,%rdx
    62a3:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    62a9:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    62b0:	00 f0 3f 
    62b3:	48 89 c7             	mov    %rax,%rdi
    62b6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    62bd:	00 f0 bf 
    62c0:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    62c5:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    62cb:	e8 10 fc ff ff       	call   5ee0 <fwp_p_ad_push>
    62d0:	f2 0f 10 05 c0 98 00 	movsd  0x98c0(%rip),%xmm0        # fb98 <msg.4+0x28>
    62d7:	00 
    62d8:	4c 89 e7             	mov    %r12,%rdi
    62db:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    62e1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    62e8:	00 f0 3f 
    62eb:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    62f2:	49 89 c5             	mov    %rax,%r13
    62f5:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    62fc:	00 f0 bf 
    62ff:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    6304:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    630a:	e8 d1 fb ff ff       	call   5ee0 <fwp_p_ad_push>
    630f:	48 89 e9             	mov    %rbp,%rcx
    6312:	4c 89 ea             	mov    %r13,%rdx
    6315:	48 89 ee             	mov    %rbp,%rsi
    6318:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    631e:	4c 89 ef             	mov    %r13,%rdi
    6321:	49 89 c4             	mov    %rax,%r12
    6324:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6328:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    632e:	e8 ad fb ff ff       	call   5ee0 <fwp_p_ad_push>
    6333:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6339:	f2 0f 59 1d 5f 98 00 	mulsd  0x985f(%rip),%xmm3        # fba0 <msg.4+0x30>
    6340:	00 
    6341:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6348:	00 59 40 
    634b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6350:	48 89 c2             	mov    %rax,%rdx
    6353:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    635a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6360:	e8 7b fb ff ff       	call   5ee0 <fwp_p_ad_push>
    6365:	48 89 d9             	mov    %rbx,%rcx
    6368:	4c 89 e2             	mov    %r12,%rdx
    636b:	48 89 de             	mov    %rbx,%rsi
    636e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6374:	4c 89 e7             	mov    %r12,%rdi
    6377:	48 89 c5             	mov    %rax,%rbp
    637a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    637e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6384:	e8 57 fb ff ff       	call   5ee0 <fwp_p_ad_push>
    6389:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    638f:	48 89 ea             	mov    %rbp,%rdx
    6392:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6398:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    639f:	00 f0 3f 
    63a2:	48 89 c7             	mov    %rax,%rdi
    63a5:	48 89 ce             	mov    %rcx,%rsi
    63a8:	66 48 0f 7e db       	movq   %xmm3,%rbx
    63ad:	e8 2e fb ff ff       	call   5ee0 <fwp_p_ad_push>
    63b2:	48 83 c4 28          	add    $0x28,%rsp
    63b6:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    63bb:	5b                   	pop    %rbx
    63bc:	5d                   	pop    %rbp
    63bd:	41 5c                	pop    %r12
    63bf:	41 5d                	pop    %r13
    63c1:	c3                   	ret
    63c2:	0f 1f 00             	nopl   (%rax)
    63c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    63cc:	00 00 00 00 

00000000000063d0 <fwp_rc_share>:
    63d0:	48 8b 05 c1 e7 01 00 	mov    0x1e7c1(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    63d7:	48 2b 3d 92 e7 01 00 	sub    0x1e792(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    63de:	48 c1 e0 10          	shl    $0x10,%rax
    63e2:	48 39 c7             	cmp    %rax,%rdi
    63e5:	73 4a                	jae    6431 <fwp_rc_share+0x61>
    63e7:	48 89 f8             	mov    %rdi,%rax
    63ea:	48 c1 e8 10          	shr    $0x10,%rax
    63ee:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    63f2:	48 8b 05 bf e7 01 00 	mov    0x1e7bf(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    63f9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    63fd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6401:	48 85 d2             	test   %rdx,%rdx
    6404:	74 2b                	je     6431 <fwp_rc_share+0x61>
    6406:	0f b6 08             	movzbl (%rax),%ecx
    6409:	80 f9 02             	cmp    $0x2,%cl
    640c:	74 2a                	je     6438 <fwp_rc_share+0x68>
    640e:	80 f9 01             	cmp    $0x1,%cl
    6411:	75 1e                	jne    6431 <fwp_rc_share+0x61>
    6413:	8b 48 18             	mov    0x18(%rax),%ecx
    6416:	0f b7 ff             	movzwl %di,%edi
    6419:	8b 40 1c             	mov    0x1c(%rax),%eax
    641c:	48 0f af f9          	imul   %rcx,%rdi
    6420:	48 c1 ef 20          	shr    $0x20,%rdi
    6424:	48 39 c7             	cmp    %rax,%rdi
    6427:	73 08                	jae    6431 <fwp_rc_share+0x61>
    6429:	48 01 fa             	add    %rdi,%rdx
    642c:	80 3a 00             	cmpb   $0x0,(%rdx)
    642f:	75 0d                	jne    643e <fwp_rc_share+0x6e>
    6431:	c3                   	ret
    6432:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6438:	66 85 ff             	test   %di,%di
    643b:	74 ef                	je     642c <fwp_rc_share+0x5c>
    643d:	c3                   	ret
    643e:	50                   	push   %rax
    643f:	48 8d 3d ea 94 00 00 	lea    0x94ea(%rip),%rdi        # f930 <_IO_stdin_used+0x930>
    6446:	e8 a5 df ff ff       	call   43f0 <fwp_trap>
    644b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006450 <fwp_rc_fresh>:
    6450:	48 8b 15 41 e7 01 00 	mov    0x1e741(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    6457:	48 89 f8             	mov    %rdi,%rax
    645a:	48 89 fe             	mov    %rdi,%rsi
    645d:	48 2b 05 0c e7 01 00 	sub    0x1e70c(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6464:	48 c1 e2 10          	shl    $0x10,%rdx
    6468:	48 39 d0             	cmp    %rdx,%rax
    646b:	73 4f                	jae    64bc <fwp_rc_fresh+0x6c>
    646d:	48 89 c2             	mov    %rax,%rdx
    6470:	48 c1 ea 10          	shr    $0x10,%rdx
    6474:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6478:	48 8b 15 39 e7 01 00 	mov    0x1e739(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    647f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6483:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6487:	48 85 d2             	test   %rdx,%rdx
    648a:	74 30                	je     64bc <fwp_rc_fresh+0x6c>
    648c:	0f b6 39             	movzbl (%rcx),%edi
    648f:	40 80 ff 02          	cmp    $0x2,%dil
    6493:	74 2b                	je     64c0 <fwp_rc_fresh+0x70>
    6495:	40 80 ff 01          	cmp    $0x1,%dil
    6499:	75 21                	jne    64bc <fwp_rc_fresh+0x6c>
    649b:	8b 79 18             	mov    0x18(%rcx),%edi
    649e:	0f b7 c0             	movzwl %ax,%eax
    64a1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    64a4:	48 0f af c7          	imul   %rdi,%rax
    64a8:	48 c1 e8 20          	shr    $0x20,%rax
    64ac:	48 39 c8             	cmp    %rcx,%rax
    64af:	73 0b                	jae    64bc <fwp_rc_fresh+0x6c>
    64b1:	48 01 c2             	add    %rax,%rdx
    64b4:	80 3a ff             	cmpb   $0xff,(%rdx)
    64b7:	74 17                	je     64d0 <fwp_rc_fresh+0x80>
    64b9:	c6 02 01             	movb   $0x1,(%rdx)
    64bc:	48 89 f0             	mov    %rsi,%rax
    64bf:	c3                   	ret
    64c0:	66 85 c0             	test   %ax,%ax
    64c3:	74 ef                	je     64b4 <fwp_rc_fresh+0x64>
    64c5:	48 89 f0             	mov    %rsi,%rax
    64c8:	c3                   	ret
    64c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    64d0:	48 83 ec 18          	sub    $0x18,%rsp
    64d4:	48 89 d7             	mov    %rdx,%rdi
    64d7:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    64dc:	48 89 14 24          	mov    %rdx,(%rsp)
    64e0:	e8 6b f0 ff ff       	call   5550 <fwp_rc_forget_slot>
    64e5:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    64ea:	48 8b 14 24          	mov    (%rsp),%rdx
    64ee:	48 89 f0             	mov    %rsi,%rax
    64f1:	c6 02 01             	movb   $0x1,(%rdx)
    64f4:	48 83 c4 18          	add    $0x18,%rsp
    64f8:	c3                   	ret
    64f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006500 <fwp_rc_free_obj>:
    6500:	48 8b 15 91 e6 01 00 	mov    0x1e691(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    6507:	48 89 f8             	mov    %rdi,%rax
    650a:	48 2b 05 5f e6 01 00 	sub    0x1e65f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6511:	48 c1 e2 10          	shl    $0x10,%rdx
    6515:	48 39 d0             	cmp    %rdx,%rax
    6518:	73 5b                	jae    6575 <fwp_rc_free_obj+0x75>
    651a:	48 89 c2             	mov    %rax,%rdx
    651d:	48 c1 ea 10          	shr    $0x10,%rdx
    6521:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6525:	48 8b 15 8c e6 01 00 	mov    0x1e68c(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    652c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6530:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6534:	48 85 c9             	test   %rcx,%rcx
    6537:	74 3c                	je     6575 <fwp_rc_free_obj+0x75>
    6539:	0f b6 32             	movzbl (%rdx),%esi
    653c:	40 80 fe 02          	cmp    $0x2,%sil
    6540:	74 2e                	je     6570 <fwp_rc_free_obj+0x70>
    6542:	40 80 fe 01          	cmp    $0x1,%sil
    6546:	75 2d                	jne    6575 <fwp_rc_free_obj+0x75>
    6548:	8b 72 18             	mov    0x18(%rdx),%esi
    654b:	0f b7 c0             	movzwl %ax,%eax
    654e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6551:	48 0f af c6          	imul   %rsi,%rax
    6555:	48 c1 e8 20          	shr    $0x20,%rax
    6559:	48 39 d0             	cmp    %rdx,%rax
    655c:	73 17                	jae    6575 <fwp_rc_free_obj+0x75>
    655e:	48 01 c1             	add    %rax,%rcx
    6561:	80 39 01             	cmpb   $0x1,(%rcx)
    6564:	75 0f                	jne    6575 <fwp_rc_free_obj+0x75>
    6566:	e9 25 f2 ff ff       	jmp    5790 <fwp_mem_free>
    656b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6570:	66 85 c0             	test   %ax,%ax
    6573:	74 ec                	je     6561 <fwp_rc_free_obj+0x61>
    6575:	c3                   	ret
    6576:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    657d:	00 00 00 

0000000000006580 <fwp_rc_dup>:
    6580:	f3 0f 1e fa          	endbr64
    6584:	48 8b 05 0d e6 01 00 	mov    0x1e60d(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    658b:	48 2b 3d de e5 01 00 	sub    0x1e5de(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    6592:	48 c1 e0 10          	shl    $0x10,%rax
    6596:	48 39 c7             	cmp    %rax,%rdi
    6599:	73 56                	jae    65f1 <fwp_rc_dup+0x71>
    659b:	48 89 f8             	mov    %rdi,%rax
    659e:	48 c1 e8 10          	shr    $0x10,%rax
    65a2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    65a6:	48 8b 05 0b e6 01 00 	mov    0x1e60b(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    65ad:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    65b1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    65b5:	48 85 c0             	test   %rax,%rax
    65b8:	74 37                	je     65f1 <fwp_rc_dup+0x71>
    65ba:	0f b6 0a             	movzbl (%rdx),%ecx
    65bd:	80 f9 02             	cmp    $0x2,%cl
    65c0:	74 36                	je     65f8 <fwp_rc_dup+0x78>
    65c2:	80 f9 01             	cmp    $0x1,%cl
    65c5:	75 2a                	jne    65f1 <fwp_rc_dup+0x71>
    65c7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    65ca:	0f b7 ff             	movzwl %di,%edi
    65cd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    65d0:	48 0f af f9          	imul   %rcx,%rdi
    65d4:	48 c1 ef 20          	shr    $0x20,%rdi
    65d8:	48 39 d7             	cmp    %rdx,%rdi
    65db:	73 14                	jae    65f1 <fwp_rc_dup+0x71>
    65dd:	48 01 f8             	add    %rdi,%rax
    65e0:	0f b6 10             	movzbl (%rax),%edx
    65e3:	84 d2                	test   %dl,%dl
    65e5:	74 0a                	je     65f1 <fwp_rc_dup+0x71>
    65e7:	80 fa fd             	cmp    $0xfd,%dl
    65ea:	77 14                	ja     6600 <fwp_rc_dup+0x80>
    65ec:	83 c2 01             	add    $0x1,%edx
    65ef:	88 10                	mov    %dl,(%rax)
    65f1:	c3                   	ret
    65f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    65f8:	66 85 ff             	test   %di,%di
    65fb:	74 e3                	je     65e0 <fwp_rc_dup+0x60>
    65fd:	c3                   	ret
    65fe:	66 90                	xchg   %ax,%ax
    6600:	48 89 c7             	mov    %rax,%rdi
    6603:	e9 28 ee ff ff       	jmp    5430 <fwp_rc_wide_dup>
    6608:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    660f:	00 

0000000000006610 <fwp_owned_entry173>:
    6610:	f3 0f 1e fa          	endbr64
    6614:	48 83 ec 38          	sub    $0x38,%rsp
    6618:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    661d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6624:	00 00 
    6626:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    662b:	31 c0                	xor    %eax,%eax
    662d:	48 8b 07             	mov    (%rdi),%rax
    6630:	48 03 47 10          	add    0x10(%rdi),%rax
    6634:	0f 80 c2 00 00 00    	jo     66fc <fwp_owned_entry173+0xec>
    663a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    663f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6644:	31 ff                	xor    %edi,%edi
    6646:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    664a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    664f:	e8 5c f7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    6654:	48 8b 15 3d e5 01 00 	mov    0x1e53d(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    665b:	48 89 c6             	mov    %rax,%rsi
    665e:	48 2b 05 0b e5 01 00 	sub    0x1e50b(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6665:	48 c1 e2 10          	shl    $0x10,%rdx
    6669:	48 39 d0             	cmp    %rdx,%rax
    666c:	73 4f                	jae    66bd <fwp_owned_entry173+0xad>
    666e:	48 89 c2             	mov    %rax,%rdx
    6671:	48 c1 ea 10          	shr    $0x10,%rdx
    6675:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6679:	48 8b 15 38 e5 01 00 	mov    0x1e538(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    6680:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6684:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6688:	48 85 d2             	test   %rdx,%rdx
    668b:	74 30                	je     66bd <fwp_owned_entry173+0xad>
    668d:	0f b6 39             	movzbl (%rcx),%edi
    6690:	40 80 ff 02          	cmp    $0x2,%dil
    6694:	74 42                	je     66d8 <fwp_owned_entry173+0xc8>
    6696:	40 80 ff 01          	cmp    $0x1,%dil
    669a:	75 21                	jne    66bd <fwp_owned_entry173+0xad>
    669c:	8b 79 18             	mov    0x18(%rcx),%edi
    669f:	0f b7 c0             	movzwl %ax,%eax
    66a2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    66a5:	48 0f af c7          	imul   %rdi,%rax
    66a9:	48 c1 e8 20          	shr    $0x20,%rax
    66ad:	48 39 c8             	cmp    %rcx,%rax
    66b0:	73 0b                	jae    66bd <fwp_owned_entry173+0xad>
    66b2:	48 01 c2             	add    %rax,%rdx
    66b5:	80 3a ff             	cmpb   $0xff,(%rdx)
    66b8:	74 26                	je     66e0 <fwp_owned_entry173+0xd0>
    66ba:	c6 02 01             	movb   $0x1,(%rdx)
    66bd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    66c2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    66c9:	00 00 
    66cb:	75 34                	jne    6701 <fwp_owned_entry173+0xf1>
    66cd:	48 89 f0             	mov    %rsi,%rax
    66d0:	48 83 c4 38          	add    $0x38,%rsp
    66d4:	c3                   	ret
    66d5:	0f 1f 00             	nopl   (%rax)
    66d8:	66 85 c0             	test   %ax,%ax
    66db:	75 e0                	jne    66bd <fwp_owned_entry173+0xad>
    66dd:	eb d6                	jmp    66b5 <fwp_owned_entry173+0xa5>
    66df:	90                   	nop
    66e0:	48 89 d7             	mov    %rdx,%rdi
    66e3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    66e8:	48 89 14 24          	mov    %rdx,(%rsp)
    66ec:	e8 5f ee ff ff       	call   5550 <fwp_rc_forget_slot>
    66f1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    66f6:	48 8b 14 24          	mov    (%rsp),%rdx
    66fa:	eb be                	jmp    66ba <fwp_owned_entry173+0xaa>
    66fc:	e8 ff cf ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6701:	e8 5a cd ff ff       	call   3460 <__stack_chk_fail@plt>
    6706:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    670d:	00 00 00 

0000000000006710 <e173>:
    6710:	f3 0f 1e fa          	endbr64
    6714:	53                   	push   %rbx
    6715:	48 83 ec 30          	sub    $0x30,%rsp
    6719:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    671e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6725:	00 00 
    6727:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    672c:	31 c0                	xor    %eax,%eax
    672e:	48 8b 07             	mov    (%rdi),%rax
    6731:	48 03 47 10          	add    0x10(%rdi),%rax
    6735:	0f 80 c9 00 00 00    	jo     6804 <e173+0xf4>
    673b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6740:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6745:	31 ff                	xor    %edi,%edi
    6747:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    674b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6750:	e8 5b f6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    6755:	48 8b 15 3c e4 01 00 	mov    0x1e43c(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    675c:	48 89 c3             	mov    %rax,%rbx
    675f:	48 2b 05 0a e4 01 00 	sub    0x1e40a(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6766:	48 c1 e2 10          	shl    $0x10,%rdx
    676a:	48 39 d0             	cmp    %rdx,%rax
    676d:	73 4f                	jae    67be <e173+0xae>
    676f:	48 89 c2             	mov    %rax,%rdx
    6772:	48 c1 ea 10          	shr    $0x10,%rdx
    6776:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    677a:	48 8b 15 37 e4 01 00 	mov    0x1e437(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    6781:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6785:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6789:	48 85 d2             	test   %rdx,%rdx
    678c:	74 30                	je     67be <e173+0xae>
    678e:	0f b6 31             	movzbl (%rcx),%esi
    6791:	40 80 fe 02          	cmp    $0x2,%sil
    6795:	74 49                	je     67e0 <e173+0xd0>
    6797:	40 80 fe 01          	cmp    $0x1,%sil
    679b:	75 21                	jne    67be <e173+0xae>
    679d:	8b 71 18             	mov    0x18(%rcx),%esi
    67a0:	0f b7 c0             	movzwl %ax,%eax
    67a3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    67a6:	48 0f af c6          	imul   %rsi,%rax
    67aa:	48 c1 e8 20          	shr    $0x20,%rax
    67ae:	48 39 c8             	cmp    %rcx,%rax
    67b1:	73 0b                	jae    67be <e173+0xae>
    67b3:	48 01 c2             	add    %rax,%rdx
    67b6:	80 3a ff             	cmpb   $0xff,(%rdx)
    67b9:	74 35                	je     67f0 <e173+0xe0>
    67bb:	c6 02 01             	movb   $0x1,(%rdx)
    67be:	48 89 df             	mov    %rbx,%rdi
    67c1:	e8 0a fc ff ff       	call   63d0 <fwp_rc_share>
    67c6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    67cb:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    67d2:	00 00 
    67d4:	75 33                	jne    6809 <e173+0xf9>
    67d6:	48 83 c4 30          	add    $0x30,%rsp
    67da:	48 89 d8             	mov    %rbx,%rax
    67dd:	5b                   	pop    %rbx
    67de:	c3                   	ret
    67df:	90                   	nop
    67e0:	66 85 c0             	test   %ax,%ax
    67e3:	75 d9                	jne    67be <e173+0xae>
    67e5:	eb cf                	jmp    67b6 <e173+0xa6>
    67e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    67ee:	00 00 
    67f0:	48 89 d7             	mov    %rdx,%rdi
    67f3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    67f8:	e8 53 ed ff ff       	call   5550 <fwp_rc_forget_slot>
    67fd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6802:	eb b7                	jmp    67bb <e173+0xab>
    6804:	e8 f7 ce ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6809:	e8 52 cc ff ff       	call   3460 <__stack_chk_fail@plt>
    680e:	66 90                	xchg   %ax,%ax

0000000000006810 <fwp_closure_drop>:
    6810:	48 8b 15 81 e3 01 00 	mov    0x1e381(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    6817:	48 89 f8             	mov    %rdi,%rax
    681a:	48 2b 05 4f e3 01 00 	sub    0x1e34f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6821:	48 c1 e2 10          	shl    $0x10,%rdx
    6825:	48 39 d0             	cmp    %rdx,%rax
    6828:	73 6b                	jae    6895 <fwp_closure_drop+0x85>
    682a:	48 89 c2             	mov    %rax,%rdx
    682d:	48 c1 ea 10          	shr    $0x10,%rdx
    6831:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6835:	48 8b 15 7c e3 01 00 	mov    0x1e37c(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    683c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6840:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6844:	48 85 d2             	test   %rdx,%rdx
    6847:	74 4c                	je     6895 <fwp_closure_drop+0x85>
    6849:	0f b6 31             	movzbl (%rcx),%esi
    684c:	40 80 fe 02          	cmp    $0x2,%sil
    6850:	74 3e                	je     6890 <fwp_closure_drop+0x80>
    6852:	40 80 fe 01          	cmp    $0x1,%sil
    6856:	75 3d                	jne    6895 <fwp_closure_drop+0x85>
    6858:	8b 71 18             	mov    0x18(%rcx),%esi
    685b:	0f b7 c0             	movzwl %ax,%eax
    685e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6861:	48 0f af c6          	imul   %rsi,%rax
    6865:	48 c1 e8 20          	shr    $0x20,%rax
    6869:	48 39 c8             	cmp    %rcx,%rax
    686c:	73 27                	jae    6895 <fwp_closure_drop+0x85>
    686e:	48 01 c2             	add    %rax,%rdx
    6871:	0f b6 02             	movzbl (%rdx),%eax
    6874:	84 c0                	test   %al,%al
    6876:	74 1d                	je     6895 <fwp_closure_drop+0x85>
    6878:	3c 01                	cmp    $0x1,%al
    687a:	74 24                	je     68a0 <fwp_closure_drop+0x90>
    687c:	3c ff                	cmp    $0xff,%al
    687e:	74 48                	je     68c8 <fwp_closure_drop+0xb8>
    6880:	83 e8 01             	sub    $0x1,%eax
    6883:	88 02                	mov    %al,(%rdx)
    6885:	c3                   	ret
    6886:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    688d:	00 00 00 
    6890:	66 85 c0             	test   %ax,%ax
    6893:	74 dc                	je     6871 <fwp_closure_drop+0x61>
    6895:	c3                   	ret
    6896:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    689d:	00 00 00 
    68a0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    68a7:	ff ff 
    68a9:	48 85 c0             	test   %rax,%rax
    68ac:	74 12                	je     68c0 <fwp_closure_drop+0xb0>
    68ae:	48 89 fe             	mov    %rdi,%rsi
    68b1:	48 89 c7             	mov    %rax,%rdi
    68b4:	e9 97 db ff ff       	jmp    4450 <fwp_closure_drop_push>
    68b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    68c0:	e9 3b dd ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    68c5:	0f 1f 00             	nopl   (%rax)
    68c8:	48 89 d0             	mov    %rdx,%rax
    68cb:	48 8d 35 ee ce 01 00 	lea    0x1ceee(%rip),%rsi        # 237c0 <fwp_heap>
    68d2:	48 83 ec 18          	sub    $0x18,%rsp
    68d6:	48 c1 e8 11          	shr    $0x11,%rax
    68da:	48 31 d0             	xor    %rdx,%rax
    68dd:	48 89 c1             	mov    %rax,%rcx
    68e0:	48 c1 e9 09          	shr    $0x9,%rcx
    68e4:	48 31 c8             	xor    %rcx,%rax
    68e7:	0f b6 c8             	movzbl %al,%ecx
    68ea:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    68f1:	00 
    68f2:	48 85 c0             	test   %rax,%rax
    68f5:	75 12                	jne    6909 <fwp_closure_drop+0xf9>
    68f7:	eb 49                	jmp    6942 <fwp_closure_drop+0x132>
    68f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6900:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6904:	48 85 c0             	test   %rax,%rax
    6907:	74 39                	je     6942 <fwp_closure_drop+0x132>
    6909:	48 89 c1             	mov    %rax,%rcx
    690c:	48 39 10             	cmp    %rdx,(%rax)
    690f:	75 ef                	jne    6900 <fwp_closure_drop+0xf0>
    6911:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6915:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6919:	48 89 48 08          	mov    %rcx,0x8(%rax)
    691d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6924:	74 05                	je     692b <fwp_closure_drop+0x11b>
    6926:	48 83 c4 18          	add    $0x18,%rsp
    692a:	c3                   	ret
    692b:	48 89 d7             	mov    %rdx,%rdi
    692e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6933:	e8 18 ec ff ff       	call   5550 <fwp_rc_forget_slot>
    6938:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    693d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6940:	eb e4                	jmp    6926 <fwp_closure_drop+0x116>
    6942:	48 8d 3d 47 8f 00 00 	lea    0x8f47(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    6949:	e8 a2 da ff ff       	call   43f0 <fwp_trap>
    694e:	66 90                	xchg   %ax,%ax

0000000000006950 <fwp_owned_tape_release>:
    6950:	48 85 ff             	test   %rdi,%rdi
    6953:	0f 84 f7 00 00 00    	je     6a50 <fwp_owned_tape_release+0x100>
    6959:	41 54                	push   %r12
    695b:	55                   	push   %rbp
    695c:	53                   	push   %rbx
    695d:	48 8b 07             	mov    (%rdi),%rax
    6960:	48 85 c0             	test   %rax,%rax
    6963:	74 08                	je     696d <fwp_owned_tape_release+0x1d>
    6965:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6969:	48 89 50 08          	mov    %rdx,0x8(%rax)
    696d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6971:	48 85 d2             	test   %rdx,%rdx
    6974:	74 03                	je     6979 <fwp_owned_tape_release+0x29>
    6976:	48 89 02             	mov    %rax,(%rdx)
    6979:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    697d:	48 89 fb             	mov    %rdi,%rbx
    6980:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6984:	48 85 c0             	test   %rax,%rax
    6987:	0f 84 89 00 00 00    	je     6a16 <fwp_owned_tape_release+0xc6>
    698d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6991:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6995:	7e 47                	jle    69de <fwp_owned_tape_release+0x8e>
    6997:	31 ed                	xor    %ebp,%ebp
    6999:	eb 0d                	jmp    69a8 <fwp_owned_tape_release+0x58>
    699b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    69a0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    69a4:	48 8b 40 68          	mov    0x68(%rax),%rax
    69a8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    69ac:	49 89 ec             	mov    %rbp,%r12
    69af:	48 83 c5 01          	add    $0x1,%rbp
    69b3:	49 c1 e4 04          	shl    $0x4,%r12
    69b7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    69bb:	ff d0                	call   *%rax
    69bd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    69c1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    69c6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    69ca:	ff 50 68             	call   *0x68(%rax)
    69cd:	48 8b 43 58          	mov    0x58(%rbx),%rax
    69d1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    69d5:	48 39 e8             	cmp    %rbp,%rax
    69d8:	7f c6                	jg     69a0 <fwp_owned_tape_release+0x50>
    69da:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    69de:	31 ed                	xor    %ebp,%ebp
    69e0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    69e5:	7e 28                	jle    6a0f <fwp_owned_tape_release+0xbf>
    69e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    69ee:	00 00 
    69f0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    69f4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    69f8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    69fc:	74 07                	je     6a05 <fwp_owned_tape_release+0xb5>
    69fe:	ff 52 68             	call   *0x68(%rdx)
    6a01:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6a05:	48 83 c5 01          	add    $0x1,%rbp
    6a09:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6a0d:	7f e1                	jg     69f0 <fwp_owned_tape_release+0xa0>
    6a0f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6a13:	ff 52 68             	call   *0x68(%rdx)
    6a16:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6a1a:	e8 f1 fd ff ff       	call   6810 <fwp_closure_drop>
    6a1f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6a23:	e8 e8 fd ff ff       	call   6810 <fwp_closure_drop>
    6a28:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6a2c:	e8 df fd ff ff       	call   6810 <fwp_closure_drop>
    6a31:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6a35:	e8 56 ed ff ff       	call   5790 <fwp_mem_free>
    6a3a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6a3e:	e8 4d ed ff ff       	call   5790 <fwp_mem_free>
    6a43:	48 89 df             	mov    %rbx,%rdi
    6a46:	5b                   	pop    %rbx
    6a47:	5d                   	pop    %rbp
    6a48:	41 5c                	pop    %r12
    6a4a:	e9 41 ed ff ff       	jmp    5790 <fwp_mem_free>
    6a4f:	90                   	nop
    6a50:	c3                   	ret
    6a51:	0f 1f 40 00          	nopl   0x0(%rax)
    6a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6a5c:	00 00 00 00 

0000000000006a60 <fwp_tape_finish>:
    6a60:	f3 0f 1e fa          	endbr64
    6a64:	41 56                	push   %r14
    6a66:	48 8d 3d 33 c6 01 00 	lea    0x1c633(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    6a6d:	41 55                	push   %r13
    6a6f:	41 54                	push   %r12
    6a71:	55                   	push   %rbp
    6a72:	53                   	push   %rbx
    6a73:	e8 98 d6 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    6a78:	48 83 3d 68 c6 01 00 	cmpq   $0x0,0x1c668(%rip)        # 230e8 <fwp_ntapes>
    6a7f:	00 
    6a80:	48 c7 05 fd c5 01 00 	movq   $0x0,0x1c5fd(%rip)        # 23088 <fwp_tape_cached_bytes>
    6a87:	00 00 00 00 
    6a8b:	7e 68                	jle    6af5 <fwp_tape_finish+0x95>
    6a8d:	45 31 e4             	xor    %r12d,%r12d
    6a90:	31 ed                	xor    %ebp,%ebp
    6a92:	0f 1f 00             	nopl   (%rax)
    6a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6a9c:	00 00 00 00 
    6aa0:	48 8b 1d 49 c6 01 00 	mov    0x1c649(%rip),%rbx        # 230f0 <fwp_tapes>
    6aa7:	48 83 c5 01          	add    $0x1,%rbp
    6aab:	4c 01 e3             	add    %r12,%rbx
    6aae:	49 83 c4 68          	add    $0x68,%r12
    6ab2:	48 89 df             	mov    %rbx,%rdi
    6ab5:	e8 46 d1 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6aba:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6abe:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6ac2:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6ac6:	e8 f5 c8 ff ff       	call   33c0 <free@plt>
    6acb:	4c 89 f7             	mov    %r14,%rdi
    6ace:	e8 ed c8 ff ff       	call   33c0 <free@plt>
    6ad3:	4c 89 ef             	mov    %r13,%rdi
    6ad6:	e8 e5 c8 ff ff       	call   33c0 <free@plt>
    6adb:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6adf:	e8 6c fe ff ff       	call   6950 <fwp_owned_tape_release>
    6ae4:	48 39 2d fd c5 01 00 	cmp    %rbp,0x1c5fd(%rip)        # 230e8 <fwp_ntapes>
    6aeb:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6af2:	00 
    6af3:	7f ab                	jg     6aa0 <fwp_tape_finish+0x40>
    6af5:	48 8b 3d f4 c5 01 00 	mov    0x1c5f4(%rip),%rdi        # 230f0 <fwp_tapes>
    6afc:	e8 bf c8 ff ff       	call   33c0 <free@plt>
    6b01:	5b                   	pop    %rbx
    6b02:	5d                   	pop    %rbp
    6b03:	48 c7 05 e2 c5 01 00 	movq   $0x0,0x1c5e2(%rip)        # 230f0 <fwp_tapes>
    6b0a:	00 00 00 00 
    6b0e:	48 c7 05 c7 c5 01 00 	movq   $0x0,0x1c5c7(%rip)        # 230e0 <fwp_tapes_cap>
    6b15:	00 00 00 00 
    6b19:	41 5c                	pop    %r12
    6b1b:	48 c7 05 c2 c5 01 00 	movq   $0x0,0x1c5c2(%rip)        # 230e8 <fwp_ntapes>
    6b22:	00 00 00 00 
    6b26:	41 5d                	pop    %r13
    6b28:	48 c7 05 a5 c5 01 00 	movq   $0x0,0x1c5a5(%rip)        # 230d8 <fwp_tape_next_slot>
    6b2f:	00 00 00 00 
    6b33:	41 5e                	pop    %r14
    6b35:	c3                   	ret
    6b36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b3d:	00 00 00 

0000000000006b40 <fwp_tape_scope_release>:
    6b40:	f3 0f 1e fa          	endbr64
    6b44:	41 55                	push   %r13
    6b46:	41 54                	push   %r12
    6b48:	55                   	push   %rbp
    6b49:	53                   	push   %rbx
    6b4a:	48 83 ec 58          	sub    $0x58,%rsp
    6b4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6b55:	00 00 
    6b57:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6b5c:	48 63 07             	movslq (%rdi),%rax
    6b5f:	85 c0                	test   %eax,%eax
    6b61:	0f 88 05 01 00 00    	js     6c6c <fwp_tape_scope_release+0x12c>
    6b67:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6b6e:	ec c4 4e 
    6b71:	48 89 fb             	mov    %rdi,%rbx
    6b74:	eb 3c                	jmp    6bb2 <fwp_tape_scope_release+0x72>
    6b76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b7d:	00 00 00 
    6b80:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6b85:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6b89:	e8 32 c8 ff ff       	call   33c0 <free@plt>
    6b8e:	48 8b 3c 24          	mov    (%rsp),%rdi
    6b92:	e8 29 c8 ff ff       	call   33c0 <free@plt>
    6b97:	4c 89 ef             	mov    %r13,%rdi
    6b9a:	e8 21 c8 ff ff       	call   33c0 <free@plt>
    6b9f:	4c 89 e7             	mov    %r12,%rdi
    6ba2:	e8 a9 fd ff ff       	call   6950 <fwp_owned_tape_release>
    6ba7:	48 63 03             	movslq (%rbx),%rax
    6baa:	85 c0                	test   %eax,%eax
    6bac:	0f 88 ba 00 00 00    	js     6c6c <fwp_tape_scope_release+0x12c>
    6bb2:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6bb6:	48 8b 35 33 c5 01 00 	mov    0x1c533(%rip),%rsi        # 230f0 <fwp_tapes>
    6bbd:	4c 01 c6             	add    %r8,%rsi
    6bc0:	48 89 f7             	mov    %rsi,%rdi
    6bc3:	e8 38 d0 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6bc8:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6bcd:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6bd2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6bd9:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6bdd:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6be1:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6be8:	00 
    6be9:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6bee:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6bf2:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6bf7:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6bfb:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6c00:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6c07:	00 
    6c08:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6c0f:	00 
    6c10:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6c17:	00 
    6c18:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6c1d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6c22:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6c26:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6c2a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6c2e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6c34:	77 18                	ja     6c4e <fwp_tape_scope_release+0x10e>
    6c36:	49 c1 f8 03          	sar    $0x3,%r8
    6c3a:	4c 0f af c5          	imul   %rbp,%r8
    6c3e:	4c 3b 05 93 c4 01 00 	cmp    0x1c493(%rip),%r8        # 230d8 <fwp_tape_next_slot>
    6c45:	7d 07                	jge    6c4e <fwp_tape_scope_release+0x10e>
    6c47:	4c 89 05 8a c4 01 00 	mov    %r8,0x1c48a(%rip)        # 230d8 <fwp_tape_next_slot>
    6c4e:	4d 85 e4             	test   %r12,%r12
    6c51:	0f 85 29 ff ff ff    	jne    6b80 <fwp_tape_scope_release+0x40>
    6c57:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6c5c:	e8 0f e4 ff ff       	call   5070 <fwp_tape_buffers_release>
    6c61:	48 63 03             	movslq (%rbx),%rax
    6c64:	85 c0                	test   %eax,%eax
    6c66:	0f 89 46 ff ff ff    	jns    6bb2 <fwp_tape_scope_release+0x72>
    6c6c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6c71:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6c78:	00 00 
    6c7a:	75 0b                	jne    6c87 <fwp_tape_scope_release+0x147>
    6c7c:	48 83 c4 58          	add    $0x58,%rsp
    6c80:	5b                   	pop    %rbx
    6c81:	5d                   	pop    %rbp
    6c82:	41 5c                	pop    %r12
    6c84:	41 5d                	pop    %r13
    6c86:	c3                   	ret
    6c87:	e8 d4 c7 ff ff       	call   3460 <__stack_chk_fail@plt>
    6c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006c90 <fwp_drop4>:
    6c90:	48 8b 0d 01 df 01 00 	mov    0x1df01(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    6c97:	48 89 f8             	mov    %rdi,%rax
    6c9a:	48 2b 05 cf de 01 00 	sub    0x1decf(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6ca1:	48 c1 e1 10          	shl    $0x10,%rcx
    6ca5:	48 39 c8             	cmp    %rcx,%rax
    6ca8:	0f 83 42 01 00 00    	jae    6df0 <fwp_drop4+0x160>
    6cae:	48 83 ec 18          	sub    $0x18,%rsp
    6cb2:	48 89 fa             	mov    %rdi,%rdx
    6cb5:	4c 8d 05 04 cb 01 00 	lea    0x1cb04(%rip),%r8        # 237c0 <fwp_heap>
    6cbc:	48 89 c1             	mov    %rax,%rcx
    6cbf:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    6cc6:	48 c1 e9 10          	shr    $0x10,%rcx
    6cca:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6cce:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6cd2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6cd6:	48 85 c9             	test   %rcx,%rcx
    6cd9:	74 40                	je     6d1b <fwp_drop4+0x8b>
    6cdb:	0f b6 3e             	movzbl (%rsi),%edi
    6cde:	40 80 ff 02          	cmp    $0x2,%dil
    6ce2:	74 3c                	je     6d20 <fwp_drop4+0x90>
    6ce4:	40 80 ff 01          	cmp    $0x1,%dil
    6ce8:	75 31                	jne    6d1b <fwp_drop4+0x8b>
    6cea:	8b 7e 18             	mov    0x18(%rsi),%edi
    6ced:	0f b7 c0             	movzwl %ax,%eax
    6cf0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6cf3:	48 0f af c7          	imul   %rdi,%rax
    6cf7:	48 c1 e8 20          	shr    $0x20,%rax
    6cfb:	48 39 f0             	cmp    %rsi,%rax
    6cfe:	73 1b                	jae    6d1b <fwp_drop4+0x8b>
    6d00:	48 01 c1             	add    %rax,%rcx
    6d03:	0f b6 01             	movzbl (%rcx),%eax
    6d06:	84 c0                	test   %al,%al
    6d08:	74 11                	je     6d1b <fwp_drop4+0x8b>
    6d0a:	3c 01                	cmp    $0x1,%al
    6d0c:	74 22                	je     6d30 <fwp_drop4+0xa0>
    6d0e:	3c ff                	cmp    $0xff,%al
    6d10:	0f 84 0a 01 00 00    	je     6e20 <fwp_drop4+0x190>
    6d16:	83 e8 01             	sub    $0x1,%eax
    6d19:	88 01                	mov    %al,(%rcx)
    6d1b:	48 83 c4 18          	add    $0x18,%rsp
    6d1f:	c3                   	ret
    6d20:	66 85 c0             	test   %ax,%ax
    6d23:	74 de                	je     6d03 <fwp_drop4+0x73>
    6d25:	48 83 c4 18          	add    $0x18,%rsp
    6d29:	c3                   	ret
    6d2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d30:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6d34:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    6d3b:	48 89 f8             	mov    %rdi,%rax
    6d3e:	48 c1 e1 10          	shl    $0x10,%rcx
    6d42:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6d49:	48 39 c8             	cmp    %rcx,%rax
    6d4c:	73 62                	jae    6db0 <fwp_drop4+0x120>
    6d4e:	48 89 c1             	mov    %rax,%rcx
    6d51:	48 c1 e9 10          	shr    $0x10,%rcx
    6d55:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6d59:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6d5d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6d61:	48 85 c9             	test   %rcx,%rcx
    6d64:	74 4a                	je     6db0 <fwp_drop4+0x120>
    6d66:	44 0f b6 0e          	movzbl (%rsi),%r9d
    6d6a:	41 80 f9 02          	cmp    $0x2,%r9b
    6d6e:	0f 84 9c 00 00 00    	je     6e10 <fwp_drop4+0x180>
    6d74:	41 80 f9 01          	cmp    $0x1,%r9b
    6d78:	75 36                	jne    6db0 <fwp_drop4+0x120>
    6d7a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    6d7e:	0f b7 c0             	movzwl %ax,%eax
    6d81:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6d84:	49 0f af c1          	imul   %r9,%rax
    6d88:	48 c1 e8 20          	shr    $0x20,%rax
    6d8c:	48 39 f0             	cmp    %rsi,%rax
    6d8f:	73 1f                	jae    6db0 <fwp_drop4+0x120>
    6d91:	48 01 c1             	add    %rax,%rcx
    6d94:	0f b6 01             	movzbl (%rcx),%eax
    6d97:	84 c0                	test   %al,%al
    6d99:	74 15                	je     6db0 <fwp_drop4+0x120>
    6d9b:	3c 01                	cmp    $0x1,%al
    6d9d:	74 59                	je     6df8 <fwp_drop4+0x168>
    6d9f:	3c ff                	cmp    $0xff,%al
    6da1:	0f 84 ff 00 00 00    	je     6ea6 <fwp_drop4+0x216>
    6da7:	83 e8 01             	sub    $0x1,%eax
    6daa:	88 01                	mov    %al,(%rcx)
    6dac:	0f 1f 40 00          	nopl   0x0(%rax)
    6db0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    6db4:	48 89 d7             	mov    %rdx,%rdi
    6db7:	48 89 0c 24          	mov    %rcx,(%rsp)
    6dbb:	e8 40 f7 ff ff       	call   6500 <fwp_rc_free_obj>
    6dc0:	4c 8d 05 f9 c9 01 00 	lea    0x1c9f9(%rip),%r8        # 237c0 <fwp_heap>
    6dc7:	48 8b 04 24          	mov    (%rsp),%rax
    6dcb:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6dd2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6dd9:	48 c1 e2 10          	shl    $0x10,%rdx
    6ddd:	48 39 d0             	cmp    %rdx,%rax
    6de0:	0f 83 35 ff ff ff    	jae    6d1b <fwp_drop4+0x8b>
    6de6:	48 8b 14 24          	mov    (%rsp),%rdx
    6dea:	e9 cd fe ff ff       	jmp    6cbc <fwp_drop4+0x2c>
    6def:	90                   	nop
    6df0:	c3                   	ret
    6df1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6df8:	48 89 14 24          	mov    %rdx,(%rsp)
    6dfc:	e8 ff f6 ff ff       	call   6500 <fwp_rc_free_obj>
    6e01:	48 8b 14 24          	mov    (%rsp),%rdx
    6e05:	eb a9                	jmp    6db0 <fwp_drop4+0x120>
    6e07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6e0e:	00 00 
    6e10:	66 85 c0             	test   %ax,%ax
    6e13:	75 9b                	jne    6db0 <fwp_drop4+0x120>
    6e15:	e9 7a ff ff ff       	jmp    6d94 <fwp_drop4+0x104>
    6e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6e20:	48 89 c8             	mov    %rcx,%rax
    6e23:	48 c1 e8 11          	shr    $0x11,%rax
    6e27:	48 31 c8             	xor    %rcx,%rax
    6e2a:	48 89 c2             	mov    %rax,%rdx
    6e2d:	48 c1 ea 09          	shr    $0x9,%rdx
    6e31:	48 31 d0             	xor    %rdx,%rax
    6e34:	0f b6 d0             	movzbl %al,%edx
    6e37:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    6e3e:	00 
    6e3f:	48 85 c0             	test   %rax,%rax
    6e42:	75 29                	jne    6e6d <fwp_drop4+0x1dd>
    6e44:	e9 e3 00 00 00       	jmp    6f2c <fwp_drop4+0x29c>
    6e49:	90                   	nop
    6e4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e51:	00 00 00 00 
    6e55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e5c:	00 00 00 00 
    6e60:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6e64:	48 85 c0             	test   %rax,%rax
    6e67:	0f 84 bf 00 00 00    	je     6f2c <fwp_drop4+0x29c>
    6e6d:	48 89 c2             	mov    %rax,%rdx
    6e70:	48 39 08             	cmp    %rcx,(%rax)
    6e73:	75 eb                	jne    6e60 <fwp_drop4+0x1d0>
    6e75:	48 8b 50 08          	mov    0x8(%rax),%rdx
    6e79:	48 83 ea 01          	sub    $0x1,%rdx
    6e7d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6e81:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6e88:	0f 85 8d fe ff ff    	jne    6d1b <fwp_drop4+0x8b>
    6e8e:	48 89 cf             	mov    %rcx,%rdi
    6e91:	48 89 0c 24          	mov    %rcx,(%rsp)
    6e95:	e8 b6 e6 ff ff       	call   5550 <fwp_rc_forget_slot>
    6e9a:	48 8b 0c 24          	mov    (%rsp),%rcx
    6e9e:	c6 01 fe             	movb   $0xfe,(%rcx)
    6ea1:	e9 75 fe ff ff       	jmp    6d1b <fwp_drop4+0x8b>
    6ea6:	48 89 ce             	mov    %rcx,%rsi
    6ea9:	48 c1 ee 11          	shr    $0x11,%rsi
    6ead:	48 31 ce             	xor    %rcx,%rsi
    6eb0:	48 89 f0             	mov    %rsi,%rax
    6eb3:	48 c1 e8 09          	shr    $0x9,%rax
    6eb7:	48 31 c6             	xor    %rax,%rsi
    6eba:	40 0f b6 f6          	movzbl %sil,%esi
    6ebe:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    6ec5:	00 
    6ec6:	48 85 c0             	test   %rax,%rax
    6ec9:	75 1e                	jne    6ee9 <fwp_drop4+0x259>
    6ecb:	eb 5f                	jmp    6f2c <fwp_drop4+0x29c>
    6ecd:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6ed4:	00 
    6ed5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6edc:	00 00 00 00 
    6ee0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    6ee4:	48 85 c0             	test   %rax,%rax
    6ee7:	74 43                	je     6f2c <fwp_drop4+0x29c>
    6ee9:	48 89 c6             	mov    %rax,%rsi
    6eec:	48 39 08             	cmp    %rcx,(%rax)
    6eef:	75 ef                	jne    6ee0 <fwp_drop4+0x250>
    6ef1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6ef5:	48 83 ee 01          	sub    $0x1,%rsi
    6ef9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    6efd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    6f04:	0f 85 a6 fe ff ff    	jne    6db0 <fwp_drop4+0x120>
    6f0a:	48 89 cf             	mov    %rcx,%rdi
    6f0d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6f12:	48 89 0c 24          	mov    %rcx,(%rsp)
    6f16:	e8 35 e6 ff ff       	call   5550 <fwp_rc_forget_slot>
    6f1b:	48 8b 0c 24          	mov    (%rsp),%rcx
    6f1f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6f24:	c6 01 fe             	movb   $0xfe,(%rcx)
    6f27:	e9 84 fe ff ff       	jmp    6db0 <fwp_drop4+0x120>
    6f2c:	48 8d 3d 5d 89 00 00 	lea    0x895d(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    6f33:	e8 b8 d4 ff ff       	call   43f0 <fwp_trap>
    6f38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6f3f:	00 

0000000000006f40 <fwp_arg_drop37>:
    6f40:	f3 0f 1e fa          	endbr64
    6f44:	85 f6                	test   %esi,%esi
    6f46:	75 04                	jne    6f4c <fwp_arg_drop37+0xc>
    6f48:	85 d2                	test   %edx,%edx
    6f4a:	75 04                	jne    6f50 <fwp_arg_drop37+0x10>
    6f4c:	c3                   	ret
    6f4d:	0f 1f 00             	nopl   (%rax)
    6f50:	48 8b 3f             	mov    (%rdi),%rdi
    6f53:	e9 38 fd ff ff       	jmp    6c90 <fwp_drop4>
    6f58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6f5f:	00 

0000000000006f60 <fwp_task_dispose>:
    6f60:	53                   	push   %rbx
    6f61:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6f65:	0f 84 db c7 ff ff    	je     3746 <fwp_task_dispose.cold>
    6f6b:	48 89 fb             	mov    %rdi,%rbx
    6f6e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6f73:	0f 85 cd c7 ff ff    	jne    3746 <fwp_task_dispose.cold>
    6f79:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6f7d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6f84:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6f8b:	00 
    6f8c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6f90:	48 85 ff             	test   %rdi,%rdi
    6f93:	74 07                	je     6f9c <fwp_task_dispose+0x3c>
    6f95:	48 85 c0             	test   %rax,%rax
    6f98:	74 02                	je     6f9c <fwp_task_dispose+0x3c>
    6f9a:	ff d0                	call   *%rax
    6f9c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    6fa3:	e8 e8 e7 ff ff       	call   5790 <fwp_mem_free>
    6fa8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    6faf:	00 00 00 00 
    6fb3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    6fb7:	74 6f                	je     7028 <fwp_task_dispose+0xc8>
    6fb9:	48 8b 15 d8 db 01 00 	mov    0x1dbd8(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    6fc0:	48 89 d8             	mov    %rbx,%rax
    6fc3:	48 2b 05 a6 db 01 00 	sub    0x1dba6(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6fca:	48 c1 e2 10          	shl    $0x10,%rdx
    6fce:	48 39 d0             	cmp    %rdx,%rax
    6fd1:	73 4c                	jae    701f <fwp_task_dispose+0xbf>
    6fd3:	48 89 c2             	mov    %rax,%rdx
    6fd6:	48 c1 ea 10          	shr    $0x10,%rdx
    6fda:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6fde:	48 8b 15 d3 db 01 00 	mov    0x1dbd3(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    6fe5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6fe9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6fed:	48 85 c9             	test   %rcx,%rcx
    6ff0:	74 2d                	je     701f <fwp_task_dispose+0xbf>
    6ff2:	0f b6 32             	movzbl (%rdx),%esi
    6ff5:	40 80 fe 02          	cmp    $0x2,%sil
    6ff9:	74 3d                	je     7038 <fwp_task_dispose+0xd8>
    6ffb:	40 80 fe 01          	cmp    $0x1,%sil
    6fff:	75 1e                	jne    701f <fwp_task_dispose+0xbf>
    7001:	8b 72 18             	mov    0x18(%rdx),%esi
    7004:	0f b7 c0             	movzwl %ax,%eax
    7007:	8b 52 1c             	mov    0x1c(%rdx),%edx
    700a:	48 0f af c6          	imul   %rsi,%rax
    700e:	48 c1 e8 20          	shr    $0x20,%rax
    7012:	48 39 d0             	cmp    %rdx,%rax
    7015:	73 08                	jae    701f <fwp_task_dispose+0xbf>
    7017:	48 01 c1             	add    %rax,%rcx
    701a:	80 39 01             	cmpb   $0x1,(%rcx)
    701d:	74 09                	je     7028 <fwp_task_dispose+0xc8>
    701f:	5b                   	pop    %rbx
    7020:	c3                   	ret
    7021:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7028:	48 89 df             	mov    %rbx,%rdi
    702b:	5b                   	pop    %rbx
    702c:	e9 5f e7 ff ff       	jmp    5790 <fwp_mem_free>
    7031:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7038:	66 85 c0             	test   %ax,%ax
    703b:	74 dd                	je     701a <fwp_task_dispose+0xba>
    703d:	5b                   	pop    %rbx
    703e:	c3                   	ret
    703f:	90                   	nop

0000000000007040 <fwp_free_zombie>:
    7040:	48 8b 15 49 c7 01 00 	mov    0x1c749(%rip),%rdx        # 23790 <fwp_zombie>
    7047:	48 85 d2             	test   %rdx,%rdx
    704a:	0f 84 98 00 00 00    	je     70e8 <fwp_free_zombie+0xa8>
    7050:	48 3b 15 49 c7 01 00 	cmp    0x1c749(%rip),%rdx        # 237a0 <fwp_cur>
    7057:	0f 84 8b 00 00 00    	je     70e8 <fwp_free_zombie+0xa8>
    705d:	48 83 ec 18          	sub    $0x18,%rsp
    7061:	48 63 05 fc c0 01 00 	movslq 0x1c0fc(%rip),%rax        # 23164 <fwp_stack_pool_n>
    7068:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    706c:	83 f8 3f             	cmp    $0x3f,%eax
    706f:	7f 7f                	jg     70f0 <fwp_free_zombie+0xb0>
    7071:	8d 48 01             	lea    0x1(%rax),%ecx
    7074:	89 0d ea c0 01 00    	mov    %ecx,0x1c0ea(%rip)        # 23164 <fwp_stack_pool_n>
    707a:	48 8d 0d ff c0 01 00 	lea    0x1c0ff(%rip),%rcx        # 23180 <fwp_stack_pool>
    7081:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7085:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    708c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7090:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7097:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    709b:	48 85 c9             	test   %rcx,%rcx
    709e:	0f 84 fc 00 00 00    	je     71a0 <fwp_free_zombie+0x160>
    70a4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    70ab:	48 85 c0             	test   %rax,%rax
    70ae:	74 07                	je     70b7 <fwp_free_zombie+0x77>
    70b0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    70b7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    70ba:	66 0f ef c0          	pxor   %xmm0,%xmm0
    70be:	48 c7 05 c7 c6 01 00 	movq   $0x0,0x1c6c7(%rip)        # 23790 <fwp_zombie>
    70c5:	00 00 00 00 
    70c9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    70d0:	85 c0                	test   %eax,%eax
    70d2:	74 34                	je     7108 <fwp_free_zombie+0xc8>
    70d4:	83 f8 01             	cmp    $0x1,%eax
    70d7:	0f 84 b3 00 00 00    	je     7190 <fwp_free_zombie+0x150>
    70dd:	48 83 c4 18          	add    $0x18,%rsp
    70e1:	c3                   	ret
    70e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    70e8:	c3                   	ret
    70e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    70f0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    70f4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    70f9:	e8 e2 c4 ff ff       	call   35e0 <munmap@plt>
    70fe:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7103:	eb 80                	jmp    7085 <fwp_free_zombie+0x45>
    7105:	0f 1f 00             	nopl   (%rax)
    7108:	48 8b 0d 89 da 01 00 	mov    0x1da89(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    710f:	48 89 d0             	mov    %rdx,%rax
    7112:	48 2b 05 57 da 01 00 	sub    0x1da57(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7119:	48 c1 e1 10          	shl    $0x10,%rcx
    711d:	48 39 c8             	cmp    %rcx,%rax
    7120:	73 bb                	jae    70dd <fwp_free_zombie+0x9d>
    7122:	48 89 c1             	mov    %rax,%rcx
    7125:	48 c1 e9 10          	shr    $0x10,%rcx
    7129:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    712d:	48 8b 0d 84 da 01 00 	mov    0x1da84(%rip),%rcx        # 24bb8 <fwp_heap+0x13f8>
    7134:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7138:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    713c:	48 85 c9             	test   %rcx,%rcx
    713f:	74 9c                	je     70dd <fwp_free_zombie+0x9d>
    7141:	0f b6 3e             	movzbl (%rsi),%edi
    7144:	40 80 ff 02          	cmp    $0x2,%dil
    7148:	74 66                	je     71b0 <fwp_free_zombie+0x170>
    714a:	40 80 ff 01          	cmp    $0x1,%dil
    714e:	75 8d                	jne    70dd <fwp_free_zombie+0x9d>
    7150:	8b 7e 18             	mov    0x18(%rsi),%edi
    7153:	0f b7 c0             	movzwl %ax,%eax
    7156:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7159:	48 0f af c7          	imul   %rdi,%rax
    715d:	48 c1 e8 20          	shr    $0x20,%rax
    7161:	48 39 f0             	cmp    %rsi,%rax
    7164:	0f 83 73 ff ff ff    	jae    70dd <fwp_free_zombie+0x9d>
    716a:	48 01 c1             	add    %rax,%rcx
    716d:	0f b6 01             	movzbl (%rcx),%eax
    7170:	84 c0                	test   %al,%al
    7172:	0f 84 65 ff ff ff    	je     70dd <fwp_free_zombie+0x9d>
    7178:	3c 01                	cmp    $0x1,%al
    717a:	74 14                	je     7190 <fwp_free_zombie+0x150>
    717c:	3c ff                	cmp    $0xff,%al
    717e:	74 3b                	je     71bb <fwp_free_zombie+0x17b>
    7180:	83 e8 01             	sub    $0x1,%eax
    7183:	88 01                	mov    %al,(%rcx)
    7185:	e9 53 ff ff ff       	jmp    70dd <fwp_free_zombie+0x9d>
    718a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7190:	48 89 d7             	mov    %rdx,%rdi
    7193:	48 83 c4 18          	add    $0x18,%rsp
    7197:	e9 c4 fd ff ff       	jmp    6f60 <fwp_task_dispose>
    719c:	0f 1f 40 00          	nopl   0x0(%rax)
    71a0:	48 89 05 c1 c5 01 00 	mov    %rax,0x1c5c1(%rip)        # 23768 <fwp_tasks_active>
    71a7:	e9 ff fe ff ff       	jmp    70ab <fwp_free_zombie+0x6b>
    71ac:	0f 1f 40 00          	nopl   0x0(%rax)
    71b0:	66 85 c0             	test   %ax,%ax
    71b3:	0f 85 24 ff ff ff    	jne    70dd <fwp_free_zombie+0x9d>
    71b9:	eb b2                	jmp    716d <fwp_free_zombie+0x12d>
    71bb:	48 89 ca             	mov    %rcx,%rdx
    71be:	48 8d 35 fb c5 01 00 	lea    0x1c5fb(%rip),%rsi        # 237c0 <fwp_heap>
    71c5:	48 c1 ea 11          	shr    $0x11,%rdx
    71c9:	48 31 ca             	xor    %rcx,%rdx
    71cc:	48 89 d0             	mov    %rdx,%rax
    71cf:	48 c1 e8 09          	shr    $0x9,%rax
    71d3:	48 31 c2             	xor    %rax,%rdx
    71d6:	0f b6 d2             	movzbl %dl,%edx
    71d9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    71e0:	00 
    71e1:	48 85 c0             	test   %rax,%rax
    71e4:	75 23                	jne    7209 <fwp_free_zombie+0x1c9>
    71e6:	eb 5c                	jmp    7244 <fwp_free_zombie+0x204>
    71e8:	66 90                	xchg   %ax,%ax
    71ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    71f1:	00 00 00 00 
    71f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    71fc:	00 00 00 00 
    7200:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7204:	48 85 c0             	test   %rax,%rax
    7207:	74 3b                	je     7244 <fwp_free_zombie+0x204>
    7209:	48 89 c2             	mov    %rax,%rdx
    720c:	48 39 08             	cmp    %rcx,(%rax)
    720f:	75 ef                	jne    7200 <fwp_free_zombie+0x1c0>
    7211:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7215:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7219:	48 89 50 08          	mov    %rdx,0x8(%rax)
    721d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7224:	0f 85 b3 fe ff ff    	jne    70dd <fwp_free_zombie+0x9d>
    722a:	48 89 cf             	mov    %rcx,%rdi
    722d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7232:	e8 19 e3 ff ff       	call   5550 <fwp_rc_forget_slot>
    7237:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    723c:	c6 01 fe             	movb   $0xfe,(%rcx)
    723f:	e9 99 fe ff ff       	jmp    70dd <fwp_free_zombie+0x9d>
    7244:	48 8d 3d 45 86 00 00 	lea    0x8645(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    724b:	e8 a0 d1 ff ff       	call   43f0 <fwp_trap>

0000000000007250 <fwp_block>:
    7250:	48 83 ec 08          	sub    $0x8,%rsp
    7254:	48 8b 05 2d c5 01 00 	mov    0x1c52d(%rip),%rax        # 23788 <fwp_ready_head>
    725b:	48 85 c0             	test   %rax,%rax
    725e:	0f 84 1c 01 00 00    	je     7380 <fwp_block+0x130>
    7264:	90                   	nop
    7265:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    726c:	00 00 00 00 
    7270:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7277:	48 89 15 0a c5 01 00 	mov    %rdx,0x1c50a(%rip)        # 23788 <fwp_ready_head>
    727e:	48 85 d2             	test   %rdx,%rdx
    7281:	0f 84 19 01 00 00    	je     73a0 <fwp_block+0x150>
    7287:	48 8b 15 12 c5 01 00 	mov    0x1c512(%rip),%rdx        # 237a0 <fwp_cur>
    728e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7292:	48 39 c2             	cmp    %rax,%rdx
    7295:	0f 84 d5 00 00 00    	je     7370 <fwp_block+0x120>
    729b:	48 8b 0d 86 e1 01 00 	mov    0x1e186(%rip),%rcx        # 25428 <fwp_state_owners>
    72a2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    72a6:	48 89 05 f3 c4 01 00 	mov    %rax,0x1c4f3(%rip)        # 237a0 <fwp_cur>
    72ad:	f3 0f 7e 05 9b e1 01 	movq   0x1e19b(%rip),%xmm0        # 25450 <fwp_foreign_callbacks>
    72b4:	00 
    72b5:	0f 16 05 84 e1 01 00 	movhps 0x1e184(%rip),%xmm0        # 25440 <fwp_state>
    72bc:	f3 0f 7e 0d 84 e1 01 	movq   0x1e184(%rip),%xmm1        # 25448 <fwp_handlers>
    72c3:	00 
    72c4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    72cb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    72d2:	0f 16 0d 7f e1 01 00 	movhps 0x1e17f(%rip),%xmm1        # 25458 <fwp_cleanups>
    72d9:	f3 0f 7e 05 57 e1 01 	movq   0x1e157(%rip),%xmm0        # 25438 <fwp_state_len>
    72e0:	00 
    72e1:	0f 16 05 48 e1 01 00 	movhps 0x1e148(%rip),%xmm0        # 25430 <fwp_state_cap>
    72e8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    72ef:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    72f6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    72fa:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7301:	48 89 0d 40 e1 01 00 	mov    %rcx,0x1e140(%rip)        # 25448 <fwp_handlers>
    7308:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    730f:	48 89 0d 42 e1 01 00 	mov    %rcx,0x1e142(%rip)        # 25458 <fwp_cleanups>
    7316:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    731d:	48 89 0d 2c e1 01 00 	mov    %rcx,0x1e12c(%rip)        # 25450 <fwp_foreign_callbacks>
    7324:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    732b:	48 89 0d 0e e1 01 00 	mov    %rcx,0x1e10e(%rip)        # 25440 <fwp_state>
    7332:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7339:	48 89 0d f8 e0 01 00 	mov    %rcx,0x1e0f8(%rip)        # 25438 <fwp_state_len>
    7340:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7347:	48 89 0d e2 e0 01 00 	mov    %rcx,0x1e0e2(%rip)        # 25430 <fwp_state_cap>
    734e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7355:	48 89 0d cc e0 01 00 	mov    %rcx,0x1e0cc(%rip)        # 25428 <fwp_state_owners>
    735c:	e8 2f c1 ff ff       	call   3490 <swapcontext@plt>
    7361:	f3 0f 1e fa          	endbr64
    7365:	e8 d6 fc ff ff       	call   7040 <fwp_free_zombie>
    736a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7370:	8b 05 ea bd 01 00    	mov    0x1bdea(%rip),%eax        # 23160 <fwp_slice>
    7376:	85 c0                	test   %eax,%eax
    7378:	74 36                	je     73b0 <fwp_block+0x160>
    737a:	48 83 c4 08          	add    $0x8,%rsp
    737e:	c3                   	ret
    737f:	90                   	nop
    7380:	e8 1b de ff ff       	call   51a0 <fwp_poll_events>
    7385:	48 8b 05 fc c3 01 00 	mov    0x1c3fc(%rip),%rax        # 23788 <fwp_ready_head>
    738c:	48 85 c0             	test   %rax,%rax
    738f:	0f 85 db fe ff ff    	jne    7270 <fwp_block+0x20>
    7395:	eb e9                	jmp    7380 <fwp_block+0x130>
    7397:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    739e:	00 00 
    73a0:	48 c7 05 d5 c3 01 00 	movq   $0x0,0x1c3d5(%rip)        # 23780 <fwp_ready_tail>
    73a7:	00 00 00 00 
    73ab:	e9 d7 fe ff ff       	jmp    7287 <fwp_block+0x37>
    73b0:	48 8d 3d cd 7d 00 00 	lea    0x7dcd(%rip),%rdi        # f184 <_IO_stdin_used+0x184>
    73b7:	e8 e4 bf ff ff       	call   33a0 <getenv@plt>
    73bc:	ba 10 27 00 00       	mov    $0x2710,%edx
    73c1:	48 85 c0             	test   %rax,%rax
    73c4:	74 05                	je     73cb <fwp_block+0x17b>
    73c6:	80 38 00             	cmpb   $0x0,(%rax)
    73c9:	75 0b                	jne    73d6 <fwp_block+0x186>
    73cb:	89 15 8f bd 01 00    	mov    %edx,0x1bd8f(%rip)        # 23160 <fwp_slice>
    73d1:	48 83 c4 08          	add    $0x8,%rsp
    73d5:	c3                   	ret
    73d6:	ba 0a 00 00 00       	mov    $0xa,%edx
    73db:	31 f6                	xor    %esi,%esi
    73dd:	48 89 c7             	mov    %rax,%rdi
    73e0:	e8 6b c1 ff ff       	call   3550 <strtoll@plt>
    73e5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    73e9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    73f0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    73f5:	0f 46 d0             	cmovbe %eax,%edx
    73f8:	eb d1                	jmp    73cb <fwp_block+0x17b>
    73fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007400 <fwp_caps173>:
    7400:	f3 0f 1e fa          	endbr64
    7404:	85 f6                	test   %esi,%esi
    7406:	74 08                	je     7410 <fwp_caps173+0x10>
    7408:	c3                   	ret
    7409:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7410:	48 8b 15 81 d7 01 00 	mov    0x1d781(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7417:	48 89 f8             	mov    %rdi,%rax
    741a:	48 2b 05 4f d7 01 00 	sub    0x1d74f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7421:	48 c1 e2 10          	shl    $0x10,%rdx
    7425:	48 39 d0             	cmp    %rdx,%rax
    7428:	73 de                	jae    7408 <fwp_caps173+0x8>
    742a:	48 89 c2             	mov    %rax,%rdx
    742d:	48 c1 ea 10          	shr    $0x10,%rdx
    7431:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7435:	48 8b 15 7c d7 01 00 	mov    0x1d77c(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    743c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7440:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7444:	48 85 c9             	test   %rcx,%rcx
    7447:	74 bf                	je     7408 <fwp_caps173+0x8>
    7449:	0f b6 32             	movzbl (%rdx),%esi
    744c:	40 80 fe 02          	cmp    $0x2,%sil
    7450:	74 2e                	je     7480 <fwp_caps173+0x80>
    7452:	40 80 fe 01          	cmp    $0x1,%sil
    7456:	75 b0                	jne    7408 <fwp_caps173+0x8>
    7458:	8b 72 18             	mov    0x18(%rdx),%esi
    745b:	0f b7 c0             	movzwl %ax,%eax
    745e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7461:	48 0f af c6          	imul   %rsi,%rax
    7465:	48 c1 e8 20          	shr    $0x20,%rax
    7469:	48 39 d0             	cmp    %rdx,%rax
    746c:	73 9a                	jae    7408 <fwp_caps173+0x8>
    746e:	48 01 c1             	add    %rax,%rcx
    7471:	80 39 01             	cmpb   $0x1,(%rcx)
    7474:	75 92                	jne    7408 <fwp_caps173+0x8>
    7476:	e9 15 e3 ff ff       	jmp    5790 <fwp_mem_free>
    747b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7480:	66 85 c0             	test   %ax,%ax
    7483:	74 ec                	je     7471 <fwp_caps173+0x71>
    7485:	c3                   	ret
    7486:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    748d:	00 00 00 

0000000000007490 <fwp_args37>:
    7490:	f3 0f 1e fa          	endbr64
    7494:	85 d2                	test   %edx,%edx
    7496:	74 04                	je     749c <fwp_args37+0xc>
    7498:	85 f6                	test   %esi,%esi
    749a:	74 04                	je     74a0 <fwp_args37+0x10>
    749c:	c3                   	ret
    749d:	0f 1f 00             	nopl   (%rax)
    74a0:	48 8b 15 f1 d6 01 00 	mov    0x1d6f1(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    74a7:	48 8b 07             	mov    (%rdi),%rax
    74aa:	48 2b 05 bf d6 01 00 	sub    0x1d6bf(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    74b1:	48 c1 e2 10          	shl    $0x10,%rdx
    74b5:	48 39 d0             	cmp    %rdx,%rax
    74b8:	73 e2                	jae    749c <fwp_args37+0xc>
    74ba:	48 89 c2             	mov    %rax,%rdx
    74bd:	48 c1 ea 10          	shr    $0x10,%rdx
    74c1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    74c5:	48 8b 15 ec d6 01 00 	mov    0x1d6ec(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    74cc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    74d0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    74d4:	48 85 ff             	test   %rdi,%rdi
    74d7:	74 c3                	je     749c <fwp_args37+0xc>
    74d9:	0f b6 0a             	movzbl (%rdx),%ecx
    74dc:	80 f9 02             	cmp    $0x2,%cl
    74df:	74 2f                	je     7510 <fwp_args37+0x80>
    74e1:	80 f9 01             	cmp    $0x1,%cl
    74e4:	75 b6                	jne    749c <fwp_args37+0xc>
    74e6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    74e9:	0f b7 c0             	movzwl %ax,%eax
    74ec:	8b 52 1c             	mov    0x1c(%rdx),%edx
    74ef:	48 0f af c1          	imul   %rcx,%rax
    74f3:	48 c1 e8 20          	shr    $0x20,%rax
    74f7:	48 39 d0             	cmp    %rdx,%rax
    74fa:	73 a0                	jae    749c <fwp_args37+0xc>
    74fc:	48 01 c7             	add    %rax,%rdi
    74ff:	0f b6 07             	movzbl (%rdi),%eax
    7502:	84 c0                	test   %al,%al
    7504:	74 96                	je     749c <fwp_args37+0xc>
    7506:	3c fd                	cmp    $0xfd,%al
    7508:	77 0c                	ja     7516 <fwp_args37+0x86>
    750a:	83 c0 01             	add    $0x1,%eax
    750d:	88 07                	mov    %al,(%rdi)
    750f:	c3                   	ret
    7510:	66 85 c0             	test   %ax,%ax
    7513:	74 ea                	je     74ff <fwp_args37+0x6f>
    7515:	c3                   	ret
    7516:	e9 15 df ff ff       	jmp    5430 <fwp_rc_wide_dup>
    751b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007520 <fwp_caps37>:
    7520:	f3 0f 1e fa          	endbr64
    7524:	48 83 ec 18          	sub    $0x18,%rsp
    7528:	8b 57 04             	mov    0x4(%rdi),%edx
    752b:	48 89 f8             	mov    %rdi,%rax
    752e:	85 d2                	test   %edx,%edx
    7530:	0f 84 9a 00 00 00    	je     75d0 <fwp_caps37+0xb0>
    7536:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    753a:	85 f6                	test   %esi,%esi
    753c:	0f 85 9e 00 00 00    	jne    75e0 <fwp_caps37+0xc0>
    7542:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7547:	e8 44 f7 ff ff       	call   6c90 <fwp_drop4>
    754c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7551:	48 8b 0d 40 d6 01 00 	mov    0x1d640(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    7558:	48 89 c2             	mov    %rax,%rdx
    755b:	48 2b 15 0e d6 01 00 	sub    0x1d60e(%rip),%rdx        # 24b70 <fwp_heap+0x13b0>
    7562:	48 c1 e1 10          	shl    $0x10,%rcx
    7566:	48 39 ca             	cmp    %rcx,%rdx
    7569:	73 6d                	jae    75d8 <fwp_caps37+0xb8>
    756b:	48 89 d1             	mov    %rdx,%rcx
    756e:	48 c1 e9 10          	shr    $0x10,%rcx
    7572:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7576:	48 8b 0d 3b d6 01 00 	mov    0x1d63b(%rip),%rcx        # 24bb8 <fwp_heap+0x13f8>
    757d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7581:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7585:	48 85 f6             	test   %rsi,%rsi
    7588:	74 4e                	je     75d8 <fwp_caps37+0xb8>
    758a:	0f b6 39             	movzbl (%rcx),%edi
    758d:	40 80 ff 02          	cmp    $0x2,%dil
    7591:	0f 84 b9 00 00 00    	je     7650 <fwp_caps37+0x130>
    7597:	40 80 ff 01          	cmp    $0x1,%dil
    759b:	75 3b                	jne    75d8 <fwp_caps37+0xb8>
    759d:	8b 79 18             	mov    0x18(%rcx),%edi
    75a0:	0f b7 d2             	movzwl %dx,%edx
    75a3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    75a6:	48 0f af d7          	imul   %rdi,%rdx
    75aa:	48 c1 ea 20          	shr    $0x20,%rdx
    75ae:	48 39 ca             	cmp    %rcx,%rdx
    75b1:	73 25                	jae    75d8 <fwp_caps37+0xb8>
    75b3:	48 01 d6             	add    %rdx,%rsi
    75b6:	80 3e 01             	cmpb   $0x1,(%rsi)
    75b9:	75 1d                	jne    75d8 <fwp_caps37+0xb8>
    75bb:	48 89 c7             	mov    %rax,%rdi
    75be:	48 83 c4 18          	add    $0x18,%rsp
    75c2:	e9 c9 e1 ff ff       	jmp    5790 <fwp_mem_free>
    75c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    75ce:	00 00 
    75d0:	85 f6                	test   %esi,%esi
    75d2:	0f 84 79 ff ff ff    	je     7551 <fwp_caps37+0x31>
    75d8:	48 83 c4 18          	add    $0x18,%rsp
    75dc:	c3                   	ret
    75dd:	0f 1f 00             	nopl   (%rax)
    75e0:	48 8b 05 b1 d5 01 00 	mov    0x1d5b1(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    75e7:	48 2b 3d 82 d5 01 00 	sub    0x1d582(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    75ee:	48 c1 e0 10          	shl    $0x10,%rax
    75f2:	48 39 c7             	cmp    %rax,%rdi
    75f5:	73 e1                	jae    75d8 <fwp_caps37+0xb8>
    75f7:	48 89 f8             	mov    %rdi,%rax
    75fa:	48 c1 e8 10          	shr    $0x10,%rax
    75fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7602:	48 8b 05 af d5 01 00 	mov    0x1d5af(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    7609:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    760d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7611:	48 85 c0             	test   %rax,%rax
    7614:	74 c2                	je     75d8 <fwp_caps37+0xb8>
    7616:	0f b6 0a             	movzbl (%rdx),%ecx
    7619:	80 f9 02             	cmp    $0x2,%cl
    761c:	74 42                	je     7660 <fwp_caps37+0x140>
    761e:	80 f9 01             	cmp    $0x1,%cl
    7621:	75 b5                	jne    75d8 <fwp_caps37+0xb8>
    7623:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7626:	0f b7 ff             	movzwl %di,%edi
    7629:	8b 52 1c             	mov    0x1c(%rdx),%edx
    762c:	48 0f af f9          	imul   %rcx,%rdi
    7630:	48 c1 ef 20          	shr    $0x20,%rdi
    7634:	48 39 d7             	cmp    %rdx,%rdi
    7637:	73 9f                	jae    75d8 <fwp_caps37+0xb8>
    7639:	48 01 f8             	add    %rdi,%rax
    763c:	0f b6 10             	movzbl (%rax),%edx
    763f:	84 d2                	test   %dl,%dl
    7641:	74 95                	je     75d8 <fwp_caps37+0xb8>
    7643:	80 fa fd             	cmp    $0xfd,%dl
    7646:	77 23                	ja     766b <fwp_caps37+0x14b>
    7648:	83 c2 01             	add    $0x1,%edx
    764b:	88 10                	mov    %dl,(%rax)
    764d:	eb 89                	jmp    75d8 <fwp_caps37+0xb8>
    764f:	90                   	nop
    7650:	66 85 d2             	test   %dx,%dx
    7653:	0f 85 7f ff ff ff    	jne    75d8 <fwp_caps37+0xb8>
    7659:	e9 58 ff ff ff       	jmp    75b6 <fwp_caps37+0x96>
    765e:	66 90                	xchg   %ax,%ax
    7660:	66 85 ff             	test   %di,%di
    7663:	0f 85 6f ff ff ff    	jne    75d8 <fwp_caps37+0xb8>
    7669:	eb d1                	jmp    763c <fwp_caps37+0x11c>
    766b:	48 89 c7             	mov    %rax,%rdi
    766e:	48 83 c4 18          	add    $0x18,%rsp
    7672:	e9 b9 dd ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7677:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    767e:	00 00 

0000000000007680 <fwp_drop0>:
    7680:	f3 0f 1e fa          	endbr64
    7684:	48 8b 15 0d d5 01 00 	mov    0x1d50d(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    768b:	48 89 f8             	mov    %rdi,%rax
    768e:	48 2b 05 db d4 01 00 	sub    0x1d4db(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7695:	48 c1 e2 10          	shl    $0x10,%rdx
    7699:	48 39 d0             	cmp    %rdx,%rax
    769c:	0f 83 36 01 00 00    	jae    77d8 <fwp_drop0+0x158>
    76a2:	48 83 ec 18          	sub    $0x18,%rsp
    76a6:	48 8d 35 13 c1 01 00 	lea    0x1c113(%rip),%rsi        # 237c0 <fwp_heap>
    76ad:	48 89 c2             	mov    %rax,%rdx
    76b0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    76b7:	48 c1 ea 10          	shr    $0x10,%rdx
    76bb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    76bf:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    76c3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    76c7:	48 85 d2             	test   %rdx,%rdx
    76ca:	74 42                	je     770e <fwp_drop0+0x8e>
    76cc:	44 0f b6 01          	movzbl (%rcx),%r8d
    76d0:	41 80 f8 02          	cmp    $0x2,%r8b
    76d4:	74 42                	je     7718 <fwp_drop0+0x98>
    76d6:	41 80 f8 01          	cmp    $0x1,%r8b
    76da:	75 32                	jne    770e <fwp_drop0+0x8e>
    76dc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    76e0:	0f b7 c0             	movzwl %ax,%eax
    76e3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    76e6:	49 0f af c0          	imul   %r8,%rax
    76ea:	48 c1 e8 20          	shr    $0x20,%rax
    76ee:	48 39 c8             	cmp    %rcx,%rax
    76f1:	73 1b                	jae    770e <fwp_drop0+0x8e>
    76f3:	48 01 c2             	add    %rax,%rdx
    76f6:	0f b6 02             	movzbl (%rdx),%eax
    76f9:	84 c0                	test   %al,%al
    76fb:	74 11                	je     770e <fwp_drop0+0x8e>
    76fd:	3c 01                	cmp    $0x1,%al
    76ff:	74 27                	je     7728 <fwp_drop0+0xa8>
    7701:	3c ff                	cmp    $0xff,%al
    7703:	0f 84 e7 00 00 00    	je     77f0 <fwp_drop0+0x170>
    7709:	83 e8 01             	sub    $0x1,%eax
    770c:	88 02                	mov    %al,(%rdx)
    770e:	48 83 c4 18          	add    $0x18,%rsp
    7712:	c3                   	ret
    7713:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7718:	66 85 c0             	test   %ax,%ax
    771b:	74 d9                	je     76f6 <fwp_drop0+0x76>
    771d:	48 83 c4 18          	add    $0x18,%rsp
    7721:	c3                   	ret
    7722:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7728:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    772f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7736:	48 89 f8             	mov    %rdi,%rax
    7739:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    773d:	48 29 c8             	sub    %rcx,%rax
    7740:	48 c1 e2 10          	shl    $0x10,%rdx
    7744:	48 39 d0             	cmp    %rdx,%rax
    7747:	73 71                	jae    77ba <fwp_drop0+0x13a>
    7749:	49 89 c2             	mov    %rax,%r10
    774c:	49 c1 ea 10          	shr    $0x10,%r10
    7750:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7754:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7758:	4d 8b 51 20          	mov    0x20(%r9),%r10
    775c:	4d 85 d2             	test   %r10,%r10
    775f:	74 59                	je     77ba <fwp_drop0+0x13a>
    7761:	45 0f b6 19          	movzbl (%r9),%r11d
    7765:	41 80 fb 02          	cmp    $0x2,%r11b
    7769:	74 75                	je     77e0 <fwp_drop0+0x160>
    776b:	41 80 fb 01          	cmp    $0x1,%r11b
    776f:	75 49                	jne    77ba <fwp_drop0+0x13a>
    7771:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7775:	0f b7 c0             	movzwl %ax,%eax
    7778:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    777c:	49 0f af c3          	imul   %r11,%rax
    7780:	48 c1 e8 20          	shr    $0x20,%rax
    7784:	4c 39 c8             	cmp    %r9,%rax
    7787:	73 31                	jae    77ba <fwp_drop0+0x13a>
    7789:	49 01 c2             	add    %rax,%r10
    778c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7790:	75 28                	jne    77ba <fwp_drop0+0x13a>
    7792:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7797:	e8 f4 df ff ff       	call   5790 <fwp_mem_free>
    779c:	48 8d 35 1d c0 01 00 	lea    0x1c01d(%rip),%rsi        # 237c0 <fwp_heap>
    77a3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    77a8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    77af:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    77b6:	48 c1 e2 10          	shl    $0x10,%rdx
    77ba:	4c 89 c0             	mov    %r8,%rax
    77bd:	48 29 c8             	sub    %rcx,%rax
    77c0:	48 39 d0             	cmp    %rdx,%rax
    77c3:	0f 83 45 ff ff ff    	jae    770e <fwp_drop0+0x8e>
    77c9:	4c 89 c7             	mov    %r8,%rdi
    77cc:	e9 dc fe ff ff       	jmp    76ad <fwp_drop0+0x2d>
    77d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    77d8:	c3                   	ret
    77d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    77e0:	66 85 c0             	test   %ax,%ax
    77e3:	75 d5                	jne    77ba <fwp_drop0+0x13a>
    77e5:	eb a5                	jmp    778c <fwp_drop0+0x10c>
    77e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    77ee:	00 00 
    77f0:	48 89 d0             	mov    %rdx,%rax
    77f3:	48 c1 e8 11          	shr    $0x11,%rax
    77f7:	48 31 d0             	xor    %rdx,%rax
    77fa:	48 89 c1             	mov    %rax,%rcx
    77fd:	48 c1 e9 09          	shr    $0x9,%rcx
    7801:	48 31 c8             	xor    %rcx,%rax
    7804:	0f b6 c8             	movzbl %al,%ecx
    7807:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    780e:	00 
    780f:	48 85 c0             	test   %rax,%rax
    7812:	75 15                	jne    7829 <fwp_drop0+0x1a9>
    7814:	eb 4e                	jmp    7864 <fwp_drop0+0x1e4>
    7816:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    781d:	00 00 00 
    7820:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7824:	48 85 c0             	test   %rax,%rax
    7827:	74 3b                	je     7864 <fwp_drop0+0x1e4>
    7829:	48 89 c1             	mov    %rax,%rcx
    782c:	48 39 10             	cmp    %rdx,(%rax)
    782f:	75 ef                	jne    7820 <fwp_drop0+0x1a0>
    7831:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7835:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7839:	48 89 48 08          	mov    %rcx,0x8(%rax)
    783d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7844:	0f 85 c4 fe ff ff    	jne    770e <fwp_drop0+0x8e>
    784a:	48 89 d7             	mov    %rdx,%rdi
    784d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7852:	e8 f9 dc ff ff       	call   5550 <fwp_rc_forget_slot>
    7857:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    785c:	c6 02 fe             	movb   $0xfe,(%rdx)
    785f:	e9 aa fe ff ff       	jmp    770e <fwp_drop0+0x8e>
    7864:	48 8d 3d 25 80 00 00 	lea    0x8025(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    786b:	e8 80 cb ff ff       	call   43f0 <fwp_trap>

0000000000007870 <fwp_drop1>:
    7870:	f3 0f 1e fa          	endbr64
    7874:	48 8b 15 1d d3 01 00 	mov    0x1d31d(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    787b:	48 89 f8             	mov    %rdi,%rax
    787e:	48 2b 05 eb d2 01 00 	sub    0x1d2eb(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7885:	48 c1 e2 10          	shl    $0x10,%rdx
    7889:	48 39 d0             	cmp    %rdx,%rax
    788c:	0f 83 36 01 00 00    	jae    79c8 <fwp_drop1+0x158>
    7892:	48 83 ec 18          	sub    $0x18,%rsp
    7896:	48 8d 35 23 bf 01 00 	lea    0x1bf23(%rip),%rsi        # 237c0 <fwp_heap>
    789d:	48 89 c2             	mov    %rax,%rdx
    78a0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    78a7:	48 c1 ea 10          	shr    $0x10,%rdx
    78ab:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    78af:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    78b3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    78b7:	48 85 d2             	test   %rdx,%rdx
    78ba:	74 42                	je     78fe <fwp_drop1+0x8e>
    78bc:	44 0f b6 01          	movzbl (%rcx),%r8d
    78c0:	41 80 f8 02          	cmp    $0x2,%r8b
    78c4:	74 42                	je     7908 <fwp_drop1+0x98>
    78c6:	41 80 f8 01          	cmp    $0x1,%r8b
    78ca:	75 32                	jne    78fe <fwp_drop1+0x8e>
    78cc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    78d0:	0f b7 c0             	movzwl %ax,%eax
    78d3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    78d6:	49 0f af c0          	imul   %r8,%rax
    78da:	48 c1 e8 20          	shr    $0x20,%rax
    78de:	48 39 c8             	cmp    %rcx,%rax
    78e1:	73 1b                	jae    78fe <fwp_drop1+0x8e>
    78e3:	48 01 c2             	add    %rax,%rdx
    78e6:	0f b6 02             	movzbl (%rdx),%eax
    78e9:	84 c0                	test   %al,%al
    78eb:	74 11                	je     78fe <fwp_drop1+0x8e>
    78ed:	3c 01                	cmp    $0x1,%al
    78ef:	74 27                	je     7918 <fwp_drop1+0xa8>
    78f1:	3c ff                	cmp    $0xff,%al
    78f3:	0f 84 e7 00 00 00    	je     79e0 <fwp_drop1+0x170>
    78f9:	83 e8 01             	sub    $0x1,%eax
    78fc:	88 02                	mov    %al,(%rdx)
    78fe:	48 83 c4 18          	add    $0x18,%rsp
    7902:	c3                   	ret
    7903:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7908:	66 85 c0             	test   %ax,%ax
    790b:	74 d9                	je     78e6 <fwp_drop1+0x76>
    790d:	48 83 c4 18          	add    $0x18,%rsp
    7911:	c3                   	ret
    7912:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7918:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    791f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7926:	48 89 f8             	mov    %rdi,%rax
    7929:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    792d:	48 29 c8             	sub    %rcx,%rax
    7930:	48 c1 e2 10          	shl    $0x10,%rdx
    7934:	48 39 d0             	cmp    %rdx,%rax
    7937:	73 71                	jae    79aa <fwp_drop1+0x13a>
    7939:	49 89 c2             	mov    %rax,%r10
    793c:	49 c1 ea 10          	shr    $0x10,%r10
    7940:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7944:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7948:	4d 8b 51 20          	mov    0x20(%r9),%r10
    794c:	4d 85 d2             	test   %r10,%r10
    794f:	74 59                	je     79aa <fwp_drop1+0x13a>
    7951:	45 0f b6 19          	movzbl (%r9),%r11d
    7955:	41 80 fb 02          	cmp    $0x2,%r11b
    7959:	74 75                	je     79d0 <fwp_drop1+0x160>
    795b:	41 80 fb 01          	cmp    $0x1,%r11b
    795f:	75 49                	jne    79aa <fwp_drop1+0x13a>
    7961:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7965:	0f b7 c0             	movzwl %ax,%eax
    7968:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    796c:	49 0f af c3          	imul   %r11,%rax
    7970:	48 c1 e8 20          	shr    $0x20,%rax
    7974:	4c 39 c8             	cmp    %r9,%rax
    7977:	73 31                	jae    79aa <fwp_drop1+0x13a>
    7979:	49 01 c2             	add    %rax,%r10
    797c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7980:	75 28                	jne    79aa <fwp_drop1+0x13a>
    7982:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7987:	e8 04 de ff ff       	call   5790 <fwp_mem_free>
    798c:	48 8d 35 2d be 01 00 	lea    0x1be2d(%rip),%rsi        # 237c0 <fwp_heap>
    7993:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7998:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    799f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    79a6:	48 c1 e2 10          	shl    $0x10,%rdx
    79aa:	4c 89 c0             	mov    %r8,%rax
    79ad:	48 29 c8             	sub    %rcx,%rax
    79b0:	48 39 d0             	cmp    %rdx,%rax
    79b3:	0f 83 45 ff ff ff    	jae    78fe <fwp_drop1+0x8e>
    79b9:	4c 89 c7             	mov    %r8,%rdi
    79bc:	e9 dc fe ff ff       	jmp    789d <fwp_drop1+0x2d>
    79c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    79c8:	c3                   	ret
    79c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    79d0:	66 85 c0             	test   %ax,%ax
    79d3:	75 d5                	jne    79aa <fwp_drop1+0x13a>
    79d5:	eb a5                	jmp    797c <fwp_drop1+0x10c>
    79d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    79de:	00 00 
    79e0:	48 89 d0             	mov    %rdx,%rax
    79e3:	48 c1 e8 11          	shr    $0x11,%rax
    79e7:	48 31 d0             	xor    %rdx,%rax
    79ea:	48 89 c1             	mov    %rax,%rcx
    79ed:	48 c1 e9 09          	shr    $0x9,%rcx
    79f1:	48 31 c8             	xor    %rcx,%rax
    79f4:	0f b6 c8             	movzbl %al,%ecx
    79f7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    79fe:	00 
    79ff:	48 85 c0             	test   %rax,%rax
    7a02:	75 25                	jne    7a29 <fwp_drop1+0x1b9>
    7a04:	eb 5e                	jmp    7a64 <fwp_drop1+0x1f4>
    7a06:	0f 1f 40 00          	nopl   0x0(%rax)
    7a0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7a11:	00 00 00 00 
    7a15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7a1c:	00 00 00 00 
    7a20:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7a24:	48 85 c0             	test   %rax,%rax
    7a27:	74 3b                	je     7a64 <fwp_drop1+0x1f4>
    7a29:	48 89 c1             	mov    %rax,%rcx
    7a2c:	48 39 10             	cmp    %rdx,(%rax)
    7a2f:	75 ef                	jne    7a20 <fwp_drop1+0x1b0>
    7a31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7a35:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7a39:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7a3d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7a44:	0f 85 b4 fe ff ff    	jne    78fe <fwp_drop1+0x8e>
    7a4a:	48 89 d7             	mov    %rdx,%rdi
    7a4d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7a52:	e8 f9 da ff ff       	call   5550 <fwp_rc_forget_slot>
    7a57:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7a5c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7a5f:	e9 9a fe ff ff       	jmp    78fe <fwp_drop1+0x8e>
    7a64:	48 8d 3d 25 7e 00 00 	lea    0x7e25(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    7a6b:	e8 80 c9 ff ff       	call   43f0 <fwp_trap>

0000000000007a70 <fwp_drop10>:
    7a70:	48 8b 0d 21 d1 01 00 	mov    0x1d121(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    7a77:	48 89 f8             	mov    %rdi,%rax
    7a7a:	48 2b 05 ef d0 01 00 	sub    0x1d0ef(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7a81:	48 c1 e1 10          	shl    $0x10,%rcx
    7a85:	48 39 c8             	cmp    %rcx,%rax
    7a88:	0f 83 c2 01 00 00    	jae    7c50 <fwp_drop10+0x1e0>
    7a8e:	48 83 ec 18          	sub    $0x18,%rsp
    7a92:	48 89 fa             	mov    %rdi,%rdx
    7a95:	48 8d 35 24 bd 01 00 	lea    0x1bd24(%rip),%rsi        # 237c0 <fwp_heap>
    7a9c:	48 89 c1             	mov    %rax,%rcx
    7a9f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7aa6:	48 c1 e9 10          	shr    $0x10,%rcx
    7aaa:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7aae:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7ab2:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7ab6:	48 85 c9             	test   %rcx,%rcx
    7ab9:	74 46                	je     7b01 <fwp_drop10+0x91>
    7abb:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7abf:	41 80 f9 02          	cmp    $0x2,%r9b
    7ac3:	0f 84 d7 00 00 00    	je     7ba0 <fwp_drop10+0x130>
    7ac9:	41 80 f9 01          	cmp    $0x1,%r9b
    7acd:	75 32                	jne    7b01 <fwp_drop10+0x91>
    7acf:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7ad3:	0f b7 c0             	movzwl %ax,%eax
    7ad6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7ad9:	49 0f af c1          	imul   %r9,%rax
    7add:	48 c1 e8 20          	shr    $0x20,%rax
    7ae1:	48 39 f8             	cmp    %rdi,%rax
    7ae4:	73 1b                	jae    7b01 <fwp_drop10+0x91>
    7ae6:	48 01 c1             	add    %rax,%rcx
    7ae9:	0f b6 01             	movzbl (%rcx),%eax
    7aec:	84 c0                	test   %al,%al
    7aee:	74 11                	je     7b01 <fwp_drop10+0x91>
    7af0:	3c 01                	cmp    $0x1,%al
    7af2:	74 1c                	je     7b10 <fwp_drop10+0xa0>
    7af4:	3c ff                	cmp    $0xff,%al
    7af6:	0f 84 5c 01 00 00    	je     7c58 <fwp_drop10+0x1e8>
    7afc:	83 e8 01             	sub    $0x1,%eax
    7aff:	88 01                	mov    %al,(%rcx)
    7b01:	48 83 c4 18          	add    $0x18,%rsp
    7b05:	c3                   	ret
    7b06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7b0d:	00 00 00 
    7b10:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7b17:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7b1e:	48 89 d0             	mov    %rdx,%rax
    7b21:	49 89 d1             	mov    %rdx,%r9
    7b24:	48 c1 e1 10          	shl    $0x10,%rcx
    7b28:	48 29 f8             	sub    %rdi,%rax
    7b2b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7b2f:	78 7f                	js     7bb0 <fwp_drop10+0x140>
    7b31:	48 39 c8             	cmp    %rcx,%rax
    7b34:	73 cb                	jae    7b01 <fwp_drop10+0x91>
    7b36:	48 89 c1             	mov    %rax,%rcx
    7b39:	48 c1 e9 10          	shr    $0x10,%rcx
    7b3d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7b41:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7b45:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7b49:	48 85 f6             	test   %rsi,%rsi
    7b4c:	74 b3                	je     7b01 <fwp_drop10+0x91>
    7b4e:	0f b6 39             	movzbl (%rcx),%edi
    7b51:	40 80 ff 02          	cmp    $0x2,%dil
    7b55:	74 39                	je     7b90 <fwp_drop10+0x120>
    7b57:	40 80 ff 01          	cmp    $0x1,%dil
    7b5b:	75 a4                	jne    7b01 <fwp_drop10+0x91>
    7b5d:	8b 79 18             	mov    0x18(%rcx),%edi
    7b60:	0f b7 c0             	movzwl %ax,%eax
    7b63:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7b66:	48 0f af c7          	imul   %rdi,%rax
    7b6a:	48 c1 e8 20          	shr    $0x20,%rax
    7b6e:	48 39 c8             	cmp    %rcx,%rax
    7b71:	73 8e                	jae    7b01 <fwp_drop10+0x91>
    7b73:	48 01 c6             	add    %rax,%rsi
    7b76:	80 3e 01             	cmpb   $0x1,(%rsi)
    7b79:	75 86                	jne    7b01 <fwp_drop10+0x91>
    7b7b:	48 89 d7             	mov    %rdx,%rdi
    7b7e:	48 83 c4 18          	add    $0x18,%rsp
    7b82:	e9 09 dc ff ff       	jmp    5790 <fwp_mem_free>
    7b87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7b8e:	00 00 
    7b90:	66 85 c0             	test   %ax,%ax
    7b93:	74 e1                	je     7b76 <fwp_drop10+0x106>
    7b95:	48 83 c4 18          	add    $0x18,%rsp
    7b99:	c3                   	ret
    7b9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ba0:	66 85 c0             	test   %ax,%ax
    7ba3:	0f 84 40 ff ff ff    	je     7ae9 <fwp_drop10+0x79>
    7ba9:	48 83 c4 18          	add    $0x18,%rsp
    7bad:	c3                   	ret
    7bae:	66 90                	xchg   %ax,%ax
    7bb0:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7bb4:	48 39 c8             	cmp    %rcx,%rax
    7bb7:	73 74                	jae    7c2d <fwp_drop10+0x1bd>
    7bb9:	49 89 c2             	mov    %rax,%r10
    7bbc:	49 c1 ea 10          	shr    $0x10,%r10
    7bc0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7bc4:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7bc8:	4d 8b 50 20          	mov    0x20(%r8),%r10
    7bcc:	4d 85 d2             	test   %r10,%r10
    7bcf:	74 5c                	je     7c2d <fwp_drop10+0x1bd>
    7bd1:	45 0f b6 18          	movzbl (%r8),%r11d
    7bd5:	41 80 fb 02          	cmp    $0x2,%r11b
    7bd9:	74 6d                	je     7c48 <fwp_drop10+0x1d8>
    7bdb:	41 80 fb 01          	cmp    $0x1,%r11b
    7bdf:	75 4c                	jne    7c2d <fwp_drop10+0x1bd>
    7be1:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7be5:	0f b7 c0             	movzwl %ax,%eax
    7be8:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    7bec:	49 0f af c3          	imul   %r11,%rax
    7bf0:	48 c1 e8 20          	shr    $0x20,%rax
    7bf4:	4c 39 c0             	cmp    %r8,%rax
    7bf7:	73 34                	jae    7c2d <fwp_drop10+0x1bd>
    7bf9:	49 01 c2             	add    %rax,%r10
    7bfc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7c00:	75 2b                	jne    7c2d <fwp_drop10+0x1bd>
    7c02:	4c 89 cf             	mov    %r9,%rdi
    7c05:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7c0a:	e8 81 db ff ff       	call   5790 <fwp_mem_free>
    7c0f:	48 8d 35 aa bb 01 00 	lea    0x1bbaa(%rip),%rsi        # 237c0 <fwp_heap>
    7c16:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7c1b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7c22:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7c29:	48 c1 e1 10          	shl    $0x10,%rcx
    7c2d:	48 89 d0             	mov    %rdx,%rax
    7c30:	48 29 f8             	sub    %rdi,%rax
    7c33:	48 39 c8             	cmp    %rcx,%rax
    7c36:	0f 82 60 fe ff ff    	jb     7a9c <fwp_drop10+0x2c>
    7c3c:	e9 c0 fe ff ff       	jmp    7b01 <fwp_drop10+0x91>
    7c41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c48:	66 85 c0             	test   %ax,%ax
    7c4b:	75 e0                	jne    7c2d <fwp_drop10+0x1bd>
    7c4d:	eb ad                	jmp    7bfc <fwp_drop10+0x18c>
    7c4f:	90                   	nop
    7c50:	c3                   	ret
    7c51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c58:	48 89 c8             	mov    %rcx,%rax
    7c5b:	48 c1 e8 11          	shr    $0x11,%rax
    7c5f:	48 31 c8             	xor    %rcx,%rax
    7c62:	48 89 c2             	mov    %rax,%rdx
    7c65:	48 c1 ea 09          	shr    $0x9,%rdx
    7c69:	48 31 d0             	xor    %rdx,%rax
    7c6c:	0f b6 d0             	movzbl %al,%edx
    7c6f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7c76:	00 
    7c77:	48 85 c0             	test   %rax,%rax
    7c7a:	75 0d                	jne    7c89 <fwp_drop10+0x219>
    7c7c:	eb 46                	jmp    7cc4 <fwp_drop10+0x254>
    7c7e:	66 90                	xchg   %ax,%ax
    7c80:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7c84:	48 85 c0             	test   %rax,%rax
    7c87:	74 3b                	je     7cc4 <fwp_drop10+0x254>
    7c89:	48 89 c2             	mov    %rax,%rdx
    7c8c:	48 39 08             	cmp    %rcx,(%rax)
    7c8f:	75 ef                	jne    7c80 <fwp_drop10+0x210>
    7c91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7c95:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7c99:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7c9d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7ca4:	0f 85 57 fe ff ff    	jne    7b01 <fwp_drop10+0x91>
    7caa:	48 89 cf             	mov    %rcx,%rdi
    7cad:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7cb2:	e8 99 d8 ff ff       	call   5550 <fwp_rc_forget_slot>
    7cb7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7cbc:	c6 01 fe             	movb   $0xfe,(%rcx)
    7cbf:	e9 3d fe ff ff       	jmp    7b01 <fwp_drop10+0x91>
    7cc4:	48 8d 3d c5 7b 00 00 	lea    0x7bc5(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    7ccb:	e8 20 c7 ff ff       	call   43f0 <fwp_trap>

0000000000007cd0 <f37>:
    7cd0:	41 57                	push   %r15
    7cd2:	41 56                	push   %r14
    7cd4:	41 55                	push   %r13
    7cd6:	41 54                	push   %r12
    7cd8:	55                   	push   %rbp
    7cd9:	53                   	push   %rbx
    7cda:	48 83 ec 38          	sub    $0x38,%rsp
    7cde:	48 8b 15 b3 ce 01 00 	mov    0x1ceb3(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7ce5:	48 8b 0d 84 ce 01 00 	mov    0x1ce84(%rip),%rcx        # 24b70 <fwp_heap+0x13b0>
    7cec:	64 4c 8b 2c 25 28 00 	mov    %fs:0x28,%r13
    7cf3:	00 00 
    7cf5:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
    7cfa:	49 89 fd             	mov    %rdi,%r13
    7cfd:	48 c1 e2 10          	shl    $0x10,%rdx
    7d01:	48 85 ff             	test   %rdi,%rdi
    7d04:	0f 84 0c 03 00 00    	je     8016 <f37+0x346>
    7d0a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    7d0e:	48 89 d8             	mov    %rbx,%rax
    7d11:	48 29 c8             	sub    %rcx,%rax
    7d14:	48 39 d0             	cmp    %rdx,%rax
    7d17:	0f 83 c3 03 00 00    	jae    80e0 <f37+0x410>
    7d1d:	48 89 c2             	mov    %rax,%rdx
    7d20:	48 c1 ea 10          	shr    $0x10,%rdx
    7d24:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d28:	48 8b 15 89 ce 01 00 	mov    0x1ce89(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    7d2f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d33:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d37:	48 85 ff             	test   %rdi,%rdi
    7d3a:	0f 84 a0 03 00 00    	je     80e0 <f37+0x410>
    7d40:	0f b6 0a             	movzbl (%rdx),%ecx
    7d43:	80 f9 02             	cmp    $0x2,%cl
    7d46:	0f 84 a4 02 00 00    	je     7ff0 <f37+0x320>
    7d4c:	80 f9 01             	cmp    $0x1,%cl
    7d4f:	75 24                	jne    7d75 <f37+0xa5>
    7d51:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d54:	0f b7 c0             	movzwl %ax,%eax
    7d57:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d5a:	48 0f af c1          	imul   %rcx,%rax
    7d5e:	48 c1 e8 20          	shr    $0x20,%rax
    7d62:	48 39 d0             	cmp    %rdx,%rax
    7d65:	73 0e                	jae    7d75 <f37+0xa5>
    7d67:	48 01 c7             	add    %rax,%rdi
    7d6a:	0f b6 07             	movzbl (%rdi),%eax
    7d6d:	84 c0                	test   %al,%al
    7d6f:	0f 85 1b 03 00 00    	jne    8090 <f37+0x3c0>
    7d75:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7d7a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    7d7e:	ba 01 00 00 00       	mov    $0x1,%edx
    7d83:	48 85 db             	test   %rbx,%rbx
    7d86:	74 15                	je     7d9d <f37+0xcd>
    7d88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7d8f:	00 
    7d90:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7d94:	48 83 c2 01          	add    $0x1,%rdx
    7d98:	48 85 db             	test   %rbx,%rbx
    7d9b:	75 f3                	jne    7d90 <f37+0xc0>
    7d9d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7da2:	48 85 c0             	test   %rax,%rax
    7da5:	0f 84 65 03 00 00    	je     8110 <f37+0x440>
    7dab:	31 db                	xor    %ebx,%ebx
    7dad:	0f 1f 00             	nopl   (%rax)
    7db0:	48 8b 40 10          	mov    0x10(%rax),%rax
    7db4:	48 83 c3 01          	add    $0x1,%rbx
    7db8:	48 85 c0             	test   %rax,%rax
    7dbb:	75 f3                	jne    7db0 <f37+0xe0>
    7dbd:	48 39 d3             	cmp    %rdx,%rbx
    7dc0:	48 0f 47 da          	cmova  %rdx,%rbx
    7dc4:	48 89 d8             	mov    %rbx,%rax
    7dc7:	48 c1 e8 3c          	shr    $0x3c,%rax
    7dcb:	0f 85 e3 03 00 00    	jne    81b4 <f37+0x4e4>
    7dd1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7dd5:	be 02 00 00 00       	mov    $0x2,%esi
    7dda:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7de1:	00 
    7de2:	e8 a9 de ff ff       	call   5c90 <fwp_heap_alloc>
    7de7:	48 89 28             	mov    %rbp,(%rax)
    7dea:	48 8b 15 a7 cd 01 00 	mov    0x1cda7(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7df1:	49 89 c4             	mov    %rax,%r12
    7df4:	48 2b 05 75 cd 01 00 	sub    0x1cd75(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7dfb:	48 c1 e2 10          	shl    $0x10,%rdx
    7dff:	48 39 d0             	cmp    %rdx,%rax
    7e02:	73 57                	jae    7e5b <f37+0x18b>
    7e04:	48 89 c2             	mov    %rax,%rdx
    7e07:	48 c1 ea 10          	shr    $0x10,%rdx
    7e0b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e0f:	48 8b 15 a2 cd 01 00 	mov    0x1cda2(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    7e16:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e1a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7e1e:	48 85 ed             	test   %rbp,%rbp
    7e21:	74 38                	je     7e5b <f37+0x18b>
    7e23:	0f b6 0a             	movzbl (%rdx),%ecx
    7e26:	80 f9 02             	cmp    $0x2,%cl
    7e29:	0f 84 a1 02 00 00    	je     80d0 <f37+0x400>
    7e2f:	80 f9 01             	cmp    $0x1,%cl
    7e32:	75 27                	jne    7e5b <f37+0x18b>
    7e34:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7e37:	0f b7 c0             	movzwl %ax,%eax
    7e3a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e3d:	48 0f af c1          	imul   %rcx,%rax
    7e41:	48 c1 e8 20          	shr    $0x20,%rax
    7e45:	48 39 d0             	cmp    %rdx,%rax
    7e48:	73 11                	jae    7e5b <f37+0x18b>
    7e4a:	48 01 c5             	add    %rax,%rbp
    7e4d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7e51:	0f 84 29 03 00 00    	je     8180 <f37+0x4b0>
    7e57:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7e5b:	48 85 db             	test   %rbx,%rbx
    7e5e:	74 5d                	je     7ebd <f37+0x1ed>
    7e60:	48 c1 e3 04          	shl    $0x4,%rbx
    7e64:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    7e69:	4c 89 e5             	mov    %r12,%rbp
    7e6c:	4d 89 ee             	mov    %r13,%r14
    7e6f:	4c 01 e3             	add    %r12,%rbx
    7e72:	0f 1f 00             	nopl   (%rax)
    7e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e7c:	00 00 00 00 
    7e80:	49 8b 46 08          	mov    0x8(%r14),%rax
    7e84:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    7e88:	48 83 c5 10          	add    $0x10,%rbp
    7e8c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    7e91:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    7e95:	48 8b 78 10          	mov    0x10(%rax),%rdi
    7e99:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    7e9e:	e8 bd e3 ff ff       	call   6260 <w120>
    7ea3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    7ea8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    7eac:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    7eb0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    7eb4:	4d 8b 76 10          	mov    0x10(%r14),%r14
    7eb8:	48 39 eb             	cmp    %rbp,%rbx
    7ebb:	75 c3                	jne    7e80 <f37+0x1b0>
    7ebd:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7ec2:	31 db                	xor    %ebx,%ebx
    7ec4:	e8 c7 ed ff ff       	call   6c90 <fwp_drop4>
    7ec9:	4c 89 ef             	mov    %r13,%rdi
    7ecc:	e8 bf ed ff ff       	call   6c90 <fwp_drop4>
    7ed1:	4d 8b 2c 24          	mov    (%r12),%r13
    7ed5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7ed9:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    7ee0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    7ee7:	4d 85 ed             	test   %r13,%r13
    7eea:	74 3f                	je     7f2b <f37+0x25b>
    7eec:	0f 1f 40 00          	nopl   0x0(%rax)
    7ef0:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    7ef7:	49 8b 54 dc 10       	mov    0x10(%r12,%rbx,8),%rdx
    7efc:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    7f03:	00 f0 3f 
    7f06:	48 83 c3 02          	add    $0x2,%rbx
    7f0a:	48 89 ce             	mov    %rcx,%rsi
    7f0d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    7f13:	e8 c8 df ff ff       	call   5ee0 <fwp_p_ad_push>
    7f18:	4c 39 eb             	cmp    %r13,%rbx
    7f1b:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    7f21:	48 89 c7             	mov    %rax,%rdi
    7f24:	72 ca                	jb     7ef0 <f37+0x220>
    7f26:	66 49 0f 7e c5       	movq   %xmm0,%r13
    7f2b:	4c 89 e7             	mov    %r12,%rdi
    7f2e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7f33:	e8 38 fb ff ff       	call   7a70 <fwp_drop10>
    7f38:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7f3d:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7f42:	31 ff                	xor    %edi,%edi
    7f44:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    7f49:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    7f4e:	e8 5d de ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    7f53:	48 8b 15 3e cc 01 00 	mov    0x1cc3e(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7f5a:	48 89 c5             	mov    %rax,%rbp
    7f5d:	48 2b 05 0c cc 01 00 	sub    0x1cc0c(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7f64:	48 c1 e2 10          	shl    $0x10,%rdx
    7f68:	48 39 d0             	cmp    %rdx,%rax
    7f6b:	73 55                	jae    7fc2 <f37+0x2f2>
    7f6d:	48 89 c2             	mov    %rax,%rdx
    7f70:	48 c1 ea 10          	shr    $0x10,%rdx
    7f74:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7f78:	48 8b 15 39 cc 01 00 	mov    0x1cc39(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    7f7f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7f83:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    7f87:	48 85 db             	test   %rbx,%rbx
    7f8a:	74 36                	je     7fc2 <f37+0x2f2>
    7f8c:	0f b6 0a             	movzbl (%rdx),%ecx
    7f8f:	80 f9 02             	cmp    $0x2,%cl
    7f92:	0f 84 20 01 00 00    	je     80b8 <f37+0x3e8>
    7f98:	80 f9 01             	cmp    $0x1,%cl
    7f9b:	75 25                	jne    7fc2 <f37+0x2f2>
    7f9d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7fa0:	0f b7 c0             	movzwl %ax,%eax
    7fa3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7fa6:	48 0f af c1          	imul   %rcx,%rax
    7faa:	48 c1 e8 20          	shr    $0x20,%rax
    7fae:	48 39 d0             	cmp    %rdx,%rax
    7fb1:	73 0f                	jae    7fc2 <f37+0x2f2>
    7fb3:	48 01 c3             	add    %rax,%rbx
    7fb6:	80 3b ff             	cmpb   $0xff,(%rbx)
    7fb9:	0f 84 b4 01 00 00    	je     8173 <f37+0x4a3>
    7fbf:	c6 03 01             	movb   $0x1,(%rbx)
    7fc2:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7fc7:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7fce:	00 00 
    7fd0:	0f 85 d9 01 00 00    	jne    81af <f37+0x4df>
    7fd6:	48 83 c4 38          	add    $0x38,%rsp
    7fda:	48 89 e8             	mov    %rbp,%rax
    7fdd:	5b                   	pop    %rbx
    7fde:	5d                   	pop    %rbp
    7fdf:	41 5c                	pop    %r12
    7fe1:	41 5d                	pop    %r13
    7fe3:	41 5e                	pop    %r14
    7fe5:	41 5f                	pop    %r15
    7fe7:	c3                   	ret
    7fe8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7fef:	00 
    7ff0:	66 85 c0             	test   %ax,%ax
    7ff3:	0f 85 7c fd ff ff    	jne    7d75 <f37+0xa5>
    7ff9:	0f b6 07             	movzbl (%rdi),%eax
    7ffc:	84 c0                	test   %al,%al
    7ffe:	0f 84 71 fd ff ff    	je     7d75 <f37+0xa5>
    8004:	3c fd                	cmp    $0xfd,%al
    8006:	0f 87 99 01 00 00    	ja     81a5 <f37+0x4d5>
    800c:	83 c0 01             	add    $0x1,%eax
    800f:	88 07                	mov    %al,(%rdi)
    8011:	e9 5f fd ff ff       	jmp    7d75 <f37+0xa5>
    8016:	48 f7 d9             	neg    %rcx
    8019:	48 39 d1             	cmp    %rdx,%rcx
    801c:	0f 83 ee 00 00 00    	jae    8110 <f37+0x440>
    8022:	48 89 c8             	mov    %rcx,%rax
    8025:	48 c1 e8 10          	shr    $0x10,%rax
    8029:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    802d:	48 8b 05 84 cb 01 00 	mov    0x1cb84(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    8034:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8038:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    803c:	48 85 ff             	test   %rdi,%rdi
    803f:	0f 84 cb 00 00 00    	je     8110 <f37+0x440>
    8045:	0f b6 02             	movzbl (%rdx),%eax
    8048:	3c 02                	cmp    $0x2,%al
    804a:	0f 84 9a 00 00 00    	je     80ea <f37+0x41a>
    8050:	3c 01                	cmp    $0x1,%al
    8052:	0f 85 b8 00 00 00    	jne    8110 <f37+0x440>
    8058:	0f b7 c1             	movzwl %cx,%eax
    805b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    805e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8061:	48 0f af c1          	imul   %rcx,%rax
    8065:	48 c1 e8 20          	shr    $0x20,%rax
    8069:	48 39 d0             	cmp    %rdx,%rax
    806c:	0f 83 9e 00 00 00    	jae    8110 <f37+0x440>
    8072:	48 01 c7             	add    %rax,%rdi
    8075:	0f b6 07             	movzbl (%rdi),%eax
    8078:	84 c0                	test   %al,%al
    807a:	0f 84 90 00 00 00    	je     8110 <f37+0x440>
    8080:	31 db                	xor    %ebx,%ebx
    8082:	0f 1f 00             	nopl   (%rax)
    8085:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    808c:	00 00 00 00 
    8090:	3c fd                	cmp    $0xfd,%al
    8092:	0f 87 f5 00 00 00    	ja     818d <f37+0x4bd>
    8098:	83 c0 01             	add    $0x1,%eax
    809b:	88 07                	mov    %al,(%rdi)
    809d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    80a2:	31 d2                	xor    %edx,%edx
    80a4:	4d 85 ed             	test   %r13,%r13
    80a7:	0f 85 cd fc ff ff    	jne    7d7a <f37+0xaa>
    80ad:	e9 eb fc ff ff       	jmp    7d9d <f37+0xcd>
    80b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    80b8:	66 85 c0             	test   %ax,%ax
    80bb:	0f 85 01 ff ff ff    	jne    7fc2 <f37+0x2f2>
    80c1:	e9 f0 fe ff ff       	jmp    7fb6 <f37+0x2e6>
    80c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    80cd:	00 00 00 
    80d0:	66 85 c0             	test   %ax,%ax
    80d3:	0f 85 82 fd ff ff    	jne    7e5b <f37+0x18b>
    80d9:	e9 6f fd ff ff       	jmp    7e4d <f37+0x17d>
    80de:	66 90                	xchg   %ax,%ax
    80e0:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    80e5:	e9 94 fc ff ff       	jmp    7d7e <f37+0xae>
    80ea:	66 85 c9             	test   %cx,%cx
    80ed:	75 21                	jne    8110 <f37+0x440>
    80ef:	0f b6 07             	movzbl (%rdi),%eax
    80f2:	84 c0                	test   %al,%al
    80f4:	74 1a                	je     8110 <f37+0x440>
    80f6:	3c fd                	cmp    $0xfd,%al
    80f8:	0f 87 c2 00 00 00    	ja     81c0 <f37+0x4f0>
    80fe:	83 c0 01             	add    $0x1,%eax
    8101:	88 07                	mov    %al,(%rdi)
    8103:	66 90                	xchg   %ax,%ax
    8105:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    810c:	00 00 00 00 
    8110:	be 02 00 00 00       	mov    $0x2,%esi
    8115:	bf 08 00 00 00       	mov    $0x8,%edi
    811a:	e8 71 db ff ff       	call   5c90 <fwp_heap_alloc>
    811f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8126:	48 8b 15 6b ca 01 00 	mov    0x1ca6b(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    812d:	49 89 c4             	mov    %rax,%r12
    8130:	48 2b 05 39 ca 01 00 	sub    0x1ca39(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    8137:	48 c1 e2 10          	shl    $0x10,%rdx
    813b:	48 39 d0             	cmp    %rdx,%rax
    813e:	73 57                	jae    8197 <f37+0x4c7>
    8140:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8147:	00 00 
    8149:	48 89 c2             	mov    %rax,%rdx
    814c:	48 c1 ea 10          	shr    $0x10,%rdx
    8150:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8154:	48 8b 15 5d ca 01 00 	mov    0x1ca5d(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    815b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    815f:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    8163:	48 85 ed             	test   %rbp,%rbp
    8166:	0f 84 51 fd ff ff    	je     7ebd <f37+0x1ed>
    816c:	31 db                	xor    %ebx,%ebx
    816e:	e9 b0 fc ff ff       	jmp    7e23 <f37+0x153>
    8173:	48 89 df             	mov    %rbx,%rdi
    8176:	e8 d5 d3 ff ff       	call   5550 <fwp_rc_forget_slot>
    817b:	e9 3f fe ff ff       	jmp    7fbf <f37+0x2ef>
    8180:	48 89 ef             	mov    %rbp,%rdi
    8183:	e8 c8 d3 ff ff       	call   5550 <fwp_rc_forget_slot>
    8188:	e9 ca fc ff ff       	jmp    7e57 <f37+0x187>
    818d:	e8 9e d2 ff ff       	call   5430 <fwp_rc_wide_dup>
    8192:	e9 06 ff ff ff       	jmp    809d <f37+0x3cd>
    8197:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    819e:	00 00 
    81a0:	e9 18 fd ff ff       	jmp    7ebd <f37+0x1ed>
    81a5:	e8 86 d2 ff ff       	call   5430 <fwp_rc_wide_dup>
    81aa:	e9 c6 fb ff ff       	jmp    7d75 <f37+0xa5>
    81af:	e8 ac b2 ff ff       	call   3460 <__stack_chk_fail@plt>
    81b4:	48 8d 3d d5 6f 00 00 	lea    0x6fd5(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    81bb:	e8 30 c2 ff ff       	call   43f0 <fwp_trap>
    81c0:	e8 6b d2 ff ff       	call   5430 <fwp_rc_wide_dup>
    81c5:	e9 46 ff ff ff       	jmp    8110 <f37+0x440>
    81ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000081d0 <fwp_owned_entry37>:
    81d0:	f3 0f 1e fa          	endbr64
    81d4:	48 8b 3f             	mov    (%rdi),%rdi
    81d7:	e9 f4 fa ff ff       	jmp    7cd0 <f37>
    81dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000081e0 <e37>:
    81e0:	f3 0f 1e fa          	endbr64
    81e4:	53                   	push   %rbx
    81e5:	48 8b 1f             	mov    (%rdi),%rbx
    81e8:	48 89 df             	mov    %rbx,%rdi
    81eb:	e8 e0 e1 ff ff       	call   63d0 <fwp_rc_share>
    81f0:	48 89 df             	mov    %rbx,%rdi
    81f3:	e8 d8 fa ff ff       	call   7cd0 <f37>
    81f8:	48 89 c3             	mov    %rax,%rbx
    81fb:	48 89 c7             	mov    %rax,%rdi
    81fe:	e8 cd e1 ff ff       	call   63d0 <fwp_rc_share>
    8203:	48 89 d8             	mov    %rbx,%rax
    8206:	5b                   	pop    %rbx
    8207:	c3                   	ret
    8208:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    820f:	00 

0000000000008210 <fwp_write>:
    8210:	41 57                	push   %r15
    8212:	41 56                	push   %r14
    8214:	41 55                	push   %r13
    8216:	41 54                	push   %r12
    8218:	55                   	push   %rbp
    8219:	53                   	push   %rbx
    821a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8221:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8228:	00 00 
    822a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8231:	00 
    8232:	49 89 d4             	mov    %rdx,%r12
    8235:	8b 12                	mov    (%rdx),%edx
    8237:	83 fa 19             	cmp    $0x19,%edx
    823a:	77 6a                	ja     82a6 <fwp_write+0x96>
    823c:	48 89 f5             	mov    %rsi,%rbp
    823f:	89 d0                	mov    %edx,%eax
    8241:	89 ce                	mov    %ecx,%esi
    8243:	48 89 fb             	mov    %rdi,%rbx
    8246:	48 8d 0d b3 78 00 00 	lea    0x78b3(%rip),%rcx        # fb00 <_IO_stdin_used+0xb00>
    824d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8251:	48 01 c8             	add    %rcx,%rax
    8254:	3e ff e0             	notrack jmp *%rax
    8257:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    825e:	00 00 
    8260:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8264:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8268:	48 89 ca             	mov    %rcx,%rdx
    826b:	48 85 c9             	test   %rcx,%rcx
    826e:	0f 88 9c 0c 00 00    	js     8f10 <fwp_write+0xd00>
    8274:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    827b:	00 
    827c:	48 89 c6             	mov    %rax,%rsi
    827f:	4c 89 e7             	mov    %r12,%rdi
    8282:	e8 b9 b7 ff ff       	call   3a40 <fwp_fmt_u128>
    8287:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    828e:	00 00 
    8290:	4c 89 e7             	mov    %r12,%rdi
    8293:	e8 b8 b1 ff ff       	call   3450 <strlen@plt>
    8298:	4c 89 e6             	mov    %r12,%rsi
    829b:	48 89 df             	mov    %rbx,%rdi
    829e:	48 89 c2             	mov    %rax,%rdx
    82a1:	e8 6a bf ff ff       	call   4210 <buf_put>
    82a6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    82ad:	00 
    82ae:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    82b5:	00 00 
    82b7:	0f 85 28 04 00 00    	jne    86e5 <fwp_write+0x4d5>
    82bd:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    82c4:	5b                   	pop    %rbx
    82c5:	5d                   	pop    %rbp
    82c6:	41 5c                	pop    %r12
    82c8:	41 5d                	pop    %r13
    82ca:	41 5e                	pop    %r14
    82cc:	41 5f                	pop    %r15
    82ce:	c3                   	ret
    82cf:	90                   	nop
    82d0:	49 89 e9             	mov    %rbp,%r9
    82d3:	4c 8d 05 9b 6d 00 00 	lea    0x6d9b(%rip),%r8        # f075 <_IO_stdin_used+0x75>
    82da:	b9 00 02 00 00       	mov    $0x200,%ecx
    82df:	ba 02 00 00 00       	mov    $0x2,%edx
    82e4:	be 00 02 00 00       	mov    $0x200,%esi
    82e9:	31 c0                	xor    %eax,%eax
    82eb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    82f2:	00 
    82f3:	e8 b8 b0 ff ff       	call   33b0 <__snprintf_chk@plt>
    82f8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    82ff:	00 
    8300:	e8 4b b1 ff ff       	call   3450 <strlen@plt>
    8305:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    830c:	00 
    830d:	48 89 df             	mov    %rbx,%rdi
    8310:	48 89 c2             	mov    %rax,%rdx
    8313:	e8 f8 be ff ff       	call   4210 <buf_put>
    8318:	eb 8c                	jmp    82a6 <fwp_write+0x96>
    831a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8320:	49 89 e9             	mov    %rbp,%r9
    8323:	4c 8d 05 8b 6e 00 00 	lea    0x6e8b(%rip),%r8        # f1b5 <_IO_stdin_used+0x1b5>
    832a:	eb ae                	jmp    82da <fwp_write+0xca>
    832c:	0f 1f 40 00          	nopl   0x0(%rax)
    8330:	83 fa 13             	cmp    $0x13,%edx
    8333:	48 8d 05 71 6e 00 00 	lea    0x6e71(%rip),%rax        # f1ab <_IO_stdin_used+0x1ab>
    833a:	48 8d 35 6f 6e 00 00 	lea    0x6e6f(%rip),%rsi        # f1b0 <_IO_stdin_used+0x1b0>
    8341:	ba 04 00 00 00       	mov    $0x4,%edx
    8346:	48 0f 44 f0          	cmove  %rax,%rsi
    834a:	45 31 ed             	xor    %r13d,%r13d
    834d:	e8 be be ff ff       	call   4210 <buf_put>
    8352:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8357:	0f 84 a3 08 00 00    	je     8c00 <fwp_write+0x9f0>
    835d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8362:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8367:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    836c:	48 89 df             	mov    %rbx,%rdi
    836f:	49 0f 44 c5          	cmove  %r13,%rax
    8373:	31 c9                	xor    %ecx,%ecx
    8375:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    837a:	e8 91 fe ff ff       	call   8210 <fwp_write>
    837f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8384:	0f 84 6e 09 00 00    	je     8cf8 <fwp_write+0xae8>
    838a:	49 83 c5 01          	add    $0x1,%r13
    838e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8392:	0f 83 68 08 00 00    	jae    8c00 <fwp_write+0x9f0>
    8398:	ba 02 00 00 00       	mov    $0x2,%edx
    839d:	48 8d 35 51 6e 00 00 	lea    0x6e51(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    83a4:	48 89 df             	mov    %rbx,%rdi
    83a7:	e8 64 be ff ff       	call   4210 <buf_put>
    83ac:	eb af                	jmp    835d <fwp_write+0x14d>
    83ae:	66 90                	xchg   %ax,%ax
    83b0:	ba 06 00 00 00       	mov    $0x6,%edx
    83b5:	48 8d 35 12 6e 00 00 	lea    0x6e12(%rip),%rsi        # f1ce <_IO_stdin_used+0x1ce>
    83bc:	48 83 c5 10          	add    $0x10,%rbp
    83c0:	e8 4b be ff ff       	call   4210 <buf_put>
    83c5:	48 89 ef             	mov    %rbp,%rdi
    83c8:	e8 83 b0 ff ff       	call   3450 <strlen@plt>
    83cd:	48 89 ee             	mov    %rbp,%rsi
    83d0:	48 89 df             	mov    %rbx,%rdi
    83d3:	48 89 c2             	mov    %rax,%rdx
    83d6:	e8 35 be ff ff       	call   4210 <buf_put>
    83db:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    83e0:	ba 01 00 00 00       	mov    $0x1,%edx
    83e5:	48 89 df             	mov    %rbx,%rdi
    83e8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    83ed:	e8 1e be ff ff       	call   4210 <buf_put>
    83f2:	e9 af fe ff ff       	jmp    82a6 <fwp_write+0x96>
    83f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    83fe:	00 00 
    8400:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8407:	00 
    8408:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    840f:	00 00 
    8411:	0f 85 ce 02 00 00    	jne    86e5 <fwp_write+0x4d5>
    8417:	ba 0a 00 00 00       	mov    $0xa,%edx
    841c:	48 8d 35 97 6d 00 00 	lea    0x6d97(%rip),%rsi        # f1ba <_IO_stdin_used+0x1ba>
    8423:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    842a:	48 89 df             	mov    %rbx,%rdi
    842d:	5b                   	pop    %rbx
    842e:	5d                   	pop    %rbp
    842f:	41 5c                	pop    %r12
    8431:	41 5d                	pop    %r13
    8433:	41 5e                	pop    %r14
    8435:	41 5f                	pop    %r15
    8437:	e9 d4 bd ff ff       	jmp    4210 <buf_put>
    843c:	0f 1f 40 00          	nopl   0x0(%rax)
    8440:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8445:	4d 85 ed             	test   %r13,%r13
    8448:	0f 84 02 0c 00 00    	je     9050 <fwp_write+0xe40>
    844e:	48 8d 35 ad 6d 00 00 	lea    0x6dad(%rip),%rsi        # f202 <_IO_stdin_used+0x202>
    8455:	4c 89 ef             	mov    %r13,%rdi
    8458:	e8 d3 b0 ff ff       	call   3530 <strcmp@plt>
    845d:	41 89 c1             	mov    %eax,%r9d
    8460:	85 c0                	test   %eax,%eax
    8462:	0f 84 6c 0c 00 00    	je     90d4 <fwp_write+0xec4>
    8468:	4c 89 ef             	mov    %r13,%rdi
    846b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8470:	e8 db af ff ff       	call   3450 <strlen@plt>
    8475:	4c 89 ee             	mov    %r13,%rsi
    8478:	48 89 df             	mov    %rbx,%rdi
    847b:	48 89 c2             	mov    %rax,%rdx
    847e:	e8 8d bd ff ff       	call   4210 <buf_put>
    8483:	ba 01 00 00 00       	mov    $0x1,%edx
    8488:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    848d:	48 89 df             	mov    %rbx,%rdi
    8490:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8495:	e8 76 bd ff ff       	call   4210 <buf_put>
    849a:	ba 01 00 00 00       	mov    $0x1,%edx
    849f:	4c 89 fe             	mov    %r15,%rsi
    84a2:	48 89 df             	mov    %rbx,%rdi
    84a5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    84aa:	e8 61 bd ff ff       	call   4210 <buf_put>
    84af:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    84b4:	45 31 f6             	xor    %r14d,%r14d
    84b7:	85 d2                	test   %edx,%edx
    84b9:	0f 8e 81 0a 00 00    	jle    8f40 <fwp_write+0xd30>
    84bf:	45 31 ed             	xor    %r13d,%r13d
    84c2:	4d 85 ed             	test   %r13,%r13
    84c5:	0f 85 75 07 00 00    	jne    8c40 <fwp_write+0xa30>
    84cb:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    84d2:	00 
    84d3:	45 85 f6             	test   %r14d,%r14d
    84d6:	0f 84 84 07 00 00    	je     8c60 <fwp_write+0xa50>
    84dc:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    84e1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    84e6:	48 89 df             	mov    %rbx,%rdi
    84e9:	49 83 c5 01          	add    $0x1,%r13
    84ed:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    84f1:	31 c9                	xor    %ecx,%ecx
    84f3:	e8 18 fd ff ff       	call   8210 <fwp_write>
    84f8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    84fd:	7f c3                	jg     84c2 <fwp_write+0x2b2>
    84ff:	45 85 f6             	test   %r14d,%r14d
    8502:	0f 84 38 0a 00 00    	je     8f40 <fwp_write+0xd30>
    8508:	b8 29 00 00 00       	mov    $0x29,%eax
    850d:	ba 01 00 00 00       	mov    $0x1,%edx
    8512:	4c 89 fe             	mov    %r15,%rsi
    8515:	48 89 df             	mov    %rbx,%rdi
    8518:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    851c:	e8 ef bc ff ff       	call   4210 <buf_put>
    8521:	e9 80 fd ff ff       	jmp    82a6 <fwp_write+0x96>
    8526:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    852d:	00 00 00 
    8530:	ba 01 00 00 00       	mov    $0x1,%edx
    8535:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    853a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    853f:	e8 cc bc ff ff       	call   4210 <buf_put>
    8544:	48 85 ed             	test   %rbp,%rbp
    8547:	0f 84 93 06 00 00    	je     8be0 <fwp_write+0x9d0>
    854d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8551:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8556:	31 c9                	xor    %ecx,%ecx
    8558:	48 89 df             	mov    %rbx,%rdi
    855b:	e8 b0 fc ff ff       	call   8210 <fwp_write>
    8560:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8564:	48 85 ed             	test   %rbp,%rbp
    8567:	0f 84 73 06 00 00    	je     8be0 <fwp_write+0x9d0>
    856d:	ba 02 00 00 00       	mov    $0x2,%edx
    8572:	48 8d 35 7c 6c 00 00 	lea    0x6c7c(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8579:	48 89 df             	mov    %rbx,%rdi
    857c:	e8 8f bc ff ff       	call   4210 <buf_put>
    8581:	eb ca                	jmp    854d <fwp_write+0x33d>
    8583:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8588:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    858c:	85 f6                	test   %esi,%esi
    858e:	0f 84 fc 07 00 00    	je     8d90 <fwp_write+0xb80>
    8594:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    859b:	00 
    859c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    85a3:	00 00 
    85a5:	0f 85 3a 01 00 00    	jne    86e5 <fwp_write+0x4d5>
    85ab:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    85af:	4c 89 ea             	mov    %r13,%rdx
    85b2:	e9 6c fe ff ff       	jmp    8423 <fwp_write+0x213>
    85b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    85be:	00 00 
    85c0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    85c5:	ba 01 00 00 00       	mov    $0x1,%edx
    85ca:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    85cf:	48 89 ee             	mov    %rbp,%rsi
    85d2:	e8 39 bc ff ff       	call   4210 <buf_put>
    85d7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    85dc:	4c 89 e7             	mov    %r12,%rdi
    85df:	e8 6c ae ff ff       	call   3450 <strlen@plt>
    85e4:	4c 89 e6             	mov    %r12,%rsi
    85e7:	48 89 df             	mov    %rbx,%rdi
    85ea:	48 89 c2             	mov    %rax,%rdx
    85ed:	e8 1e bc ff ff       	call   4210 <buf_put>
    85f2:	ba 01 00 00 00       	mov    $0x1,%edx
    85f7:	48 89 ee             	mov    %rbp,%rsi
    85fa:	48 89 df             	mov    %rbx,%rdi
    85fd:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8602:	e8 09 bc ff ff       	call   4210 <buf_put>
    8607:	e9 9a fc ff ff       	jmp    82a6 <fwp_write+0x96>
    860c:	0f 1f 40 00          	nopl   0x0(%rax)
    8610:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8615:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8619:	0f 8a 8e 0b 00 00    	jp     91ad <fwp_write+0xf9d>
    861f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8623:	66 0f 54 05 05 76 00 	andpd  0x7605(%rip),%xmm0        # fc30 <msg.4+0xc0>
    862a:	00 
    862b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8630:	66 0f 2e 05 70 75 00 	ucomisd 0x7570(%rip),%xmm0        # fba8 <msg.4+0x38>
    8637:	00 
    8638:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    863f:	00 
    8640:	0f 87 b2 09 00 00    	ja     8ff8 <fwp_write+0xde8>
    8646:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    864d:	00 00 00 
    8650:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8654:	89 ee                	mov    %ebp,%esi
    8656:	4c 89 e7             	mov    %r12,%rdi
    8659:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    865e:	e8 ad c0 ff ff       	call   4710 <fwp_format_g.constprop.0>
    8663:	31 f6                	xor    %esi,%esi
    8665:	4c 89 e7             	mov    %r12,%rdi
    8668:	e8 a3 ad ff ff       	call   3410 <strtod@plt>
    866d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8672:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8676:	7a 06                	jp     867e <fwp_write+0x46e>
    8678:	0f 84 e9 01 00 00    	je     8867 <fwp_write+0x657>
    867e:	83 c5 01             	add    $0x1,%ebp
    8681:	83 fd 12             	cmp    $0x12,%ebp
    8684:	75 ca                	jne    8650 <fwp_write+0x440>
    8686:	be 11 00 00 00       	mov    $0x11,%esi
    868b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    868f:	4c 89 e7             	mov    %r12,%rdi
    8692:	e8 79 c0 ff ff       	call   4710 <fwp_format_g.constprop.0>
    8697:	e9 cb 01 00 00       	jmp    8867 <fwp_write+0x657>
    869c:	0f 1f 40 00          	nopl   0x0(%rax)
    86a0:	48 83 fd 01          	cmp    $0x1,%rbp
    86a4:	0f 84 e6 08 00 00    	je     8f90 <fwp_write+0xd80>
    86aa:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    86ae:	b8 02 00 00 00       	mov    $0x2,%eax
    86b3:	ba 01 00 00 00       	mov    $0x1,%edx
    86b8:	48 0f 44 d0          	cmove  %rax,%rdx
    86bc:	48 8d 35 e0 6a 00 00 	lea    0x6ae0(%rip),%rsi        # f1a3 <_IO_stdin_used+0x1a3>
    86c3:	48 8d 05 de 6a 00 00 	lea    0x6ade(%rip),%rax        # f1a8 <_IO_stdin_used+0x1a8>
    86ca:	48 0f 44 f0          	cmove  %rax,%rsi
    86ce:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    86d5:	00 
    86d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    86dd:	00 00 
    86df:	0f 84 3e fd ff ff    	je     8423 <fwp_write+0x213>
    86e5:	e8 76 ad ff ff       	call   3460 <__stack_chk_fail@plt>
    86ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    86f0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    86f5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    86fa:	e8 51 ba ff ff       	call   4150 <buf_grow>
    86ff:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8703:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8709:	4c 03 0b             	add    (%rbx),%r9
    870c:	66 45 89 11          	mov    %r10w,(%r9)
    8710:	45 85 e4             	test   %r12d,%r12d
    8713:	0f 8e 07 05 00 00    	jle    8c20 <fwp_write+0xa10>
    8719:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8720:	55 55 55 
    8723:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8728:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    872f:	aa aa aa 
    8732:	49 83 c1 01          	add    $0x1,%r9
    8736:	eb 45                	jmp    877d <fwp_write+0x56d>
    8738:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    873f:	00 
    8740:	be 01 00 00 00       	mov    $0x1,%esi
    8745:	b8 2d 00 00 00       	mov    $0x2d,%eax
    874a:	88 07                	mov    %al,(%rdi)
    874c:	48 89 e8             	mov    %rbp,%rax
    874f:	49 f7 e8             	imul   %r8
    8752:	48 89 e8             	mov    %rbp,%rax
    8755:	48 c1 f8 3f          	sar    $0x3f,%rax
    8759:	48 29 c2             	sub    %rax,%rdx
    875c:	48 85 c9             	test   %rcx,%rcx
    875f:	0f 95 c0             	setne  %al
    8762:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8766:	48 83 ef 01          	sub    $0x1,%rdi
    876a:	48 21 c5             	and    %rax,%rbp
    876d:	48 29 ea             	sub    %rbp,%rdx
    8770:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8774:	49 39 f9             	cmp    %rdi,%r9
    8777:	0f 84 a3 04 00 00    	je     8c20 <fwp_write+0xa10>
    877d:	48 89 e8             	mov    %rbp,%rax
    8780:	49 f7 e8             	imul   %r8
    8783:	48 89 e8             	mov    %rbp,%rax
    8786:	48 c1 f8 3f          	sar    $0x3f,%rax
    878a:	48 89 d1             	mov    %rdx,%rcx
    878d:	48 29 c1             	sub    %rax,%rcx
    8790:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8794:	48 89 e9             	mov    %rbp,%rcx
    8797:	48 29 c1             	sub    %rax,%rcx
    879a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    879e:	49 f7 e2             	mul    %r10
    87a1:	b8 30 00 00 00       	mov    $0x30,%eax
    87a6:	48 89 d6             	mov    %rdx,%rsi
    87a9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    87ad:	48 d1 ee             	shr    $1,%rsi
    87b0:	48 01 f2             	add    %rsi,%rdx
    87b3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    87b7:	48 29 d6             	sub    %rdx,%rsi
    87ba:	74 8e                	je     874a <fwp_write+0x53a>
    87bc:	48 83 fe 01          	cmp    $0x1,%rsi
    87c0:	0f 85 7a ff ff ff    	jne    8740 <fwp_write+0x530>
    87c6:	31 f6                	xor    %esi,%esi
    87c8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    87cd:	e9 78 ff ff ff       	jmp    874a <fwp_write+0x53a>
    87d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    87d8:	66 0f 6e cd          	movd   %ebp,%xmm1
    87dc:	0f 2e c9             	ucomiss %xmm1,%xmm1
    87df:	0f 8a c8 09 00 00    	jp     91ad <fwp_write+0xf9d>
    87e5:	0f 28 c1             	movaps %xmm1,%xmm0
    87e8:	0f 54 05 31 74 00 00 	andps  0x7431(%rip),%xmm0        # fc20 <msg.4+0xb0>
    87ef:	0f 2e 05 0e 68 00 00 	ucomiss 0x680e(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    87f6:	0f 87 24 08 00 00    	ja     9020 <fwp_write+0xe10>
    87fc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8800:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8806:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    880d:	00 
    880e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8812:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8817:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    881e:	00 00 
    8820:	44 89 ee             	mov    %r13d,%esi
    8823:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8828:	4c 89 e7             	mov    %r12,%rdi
    882b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8830:	e8 db be ff ff       	call   4710 <fwp_format_g.constprop.0>
    8835:	31 f6                	xor    %esi,%esi
    8837:	4c 89 e7             	mov    %r12,%rdi
    883a:	e8 71 ac ff ff       	call   34b0 <strtof@plt>
    883f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8844:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8847:	7a 02                	jp     884b <fwp_write+0x63b>
    8849:	74 1c                	je     8867 <fwp_write+0x657>
    884b:	41 83 c5 01          	add    $0x1,%r13d
    884f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8853:	75 cb                	jne    8820 <fwp_write+0x610>
    8855:	be 09 00 00 00       	mov    $0x9,%esi
    885a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    885f:	4c 89 e7             	mov    %r12,%rdi
    8862:	e8 a9 be ff ff       	call   4710 <fwp_format_g.constprop.0>
    8867:	4c 89 e7             	mov    %r12,%rdi
    886a:	e8 11 bb ff ff       	call   4380 <fwp_finish_float>
    886f:	e9 1c fa ff ff       	jmp    8290 <fwp_write+0x80>
    8874:	0f 1f 40 00          	nopl   0x0(%rax)
    8878:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    887c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8880:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8887:	00 
    8888:	48 89 ef             	mov    %rbp,%rdi
    888b:	e8 b0 b1 ff ff       	call   3a40 <fwp_fmt_u128>
    8890:	48 89 ef             	mov    %rbp,%rdi
    8893:	e8 b8 ab ff ff       	call   3450 <strlen@plt>
    8898:	48 89 ee             	mov    %rbp,%rsi
    889b:	48 89 df             	mov    %rbx,%rdi
    889e:	48 89 c2             	mov    %rax,%rdx
    88a1:	e8 6a b9 ff ff       	call   4210 <buf_put>
    88a6:	e9 fb f9 ff ff       	jmp    82a6 <fwp_write+0x96>
    88ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    88b0:	ba 06 00 00 00       	mov    $0x6,%edx
    88b5:	48 8d 35 3c 69 00 00 	lea    0x693c(%rip),%rsi        # f1f8 <_IO_stdin_used+0x1f8>
    88bc:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    88c2:	e8 49 b9 ff ff       	call   4210 <buf_put>
    88c7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    88ce:	ff ff 7f 
    88d1:	48 23 55 00          	and    0x0(%rbp),%rdx
    88d5:	0f 84 86 02 00 00    	je     8b61 <fwp_write+0x951>
    88db:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    88e0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    88e4:	48 85 d2             	test   %rdx,%rdx
    88e7:	0f 84 ae 00 00 00    	je     899b <fwp_write+0x78b>
    88ed:	8b 0a                	mov    (%rdx),%ecx
    88ef:	83 f9 1c             	cmp    $0x1c,%ecx
    88f2:	0f 84 58 06 00 00    	je     8f50 <fwp_write+0xd40>
    88f8:	83 f9 1b             	cmp    $0x1b,%ecx
    88fb:	0f 87 9a 00 00 00    	ja     899b <fwp_write+0x78b>
    8901:	be 01 00 00 00       	mov    $0x1,%esi
    8906:	48 d3 e6             	shl    %cl,%rsi
    8909:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    890f:	0f 85 4b 04 00 00    	jne    8d60 <fwp_write+0xb50>
    8915:	f7 c6 84 04 00 00    	test   $0x484,%esi
    891b:	0f 85 0f 04 00 00    	jne    8d30 <fwp_write+0xb20>
    8921:	83 e6 21             	and    $0x21,%esi
    8924:	74 75                	je     899b <fwp_write+0x78b>
    8926:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    892b:	48 85 ff             	test   %rdi,%rdi
    892e:	79 07                	jns    8937 <fwp_write+0x727>
    8930:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8934:	4c 01 ee             	add    %r13,%rsi
    8937:	48 0f be 3e          	movsbq (%rsi),%rdi
    893b:	85 c9                	test   %ecx,%ecx
    893d:	40 0f b6 f7          	movzbl %dil,%esi
    8941:	48 0f 44 f7          	cmove  %rdi,%rsi
    8945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    894c:	00 00 00 00 
    8950:	31 c9                	xor    %ecx,%ecx
    8952:	48 89 df             	mov    %rbx,%rdi
    8955:	49 83 c5 01          	add    $0x1,%r13
    8959:	e8 b2 f8 ff ff       	call   8210 <fwp_write>
    895e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8965:	ff ff 7f 
    8968:	48 23 55 00          	and    0x0(%rbp),%rdx
    896c:	49 39 d5             	cmp    %rdx,%r13
    896f:	0f 83 ec 01 00 00    	jae    8b61 <fwp_write+0x951>
    8975:	ba 02 00 00 00       	mov    $0x2,%edx
    897a:	48 89 df             	mov    %rbx,%rdi
    897d:	48 8d 35 71 68 00 00 	lea    0x6871(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8984:	e8 87 b8 ff ff       	call   4210 <buf_put>
    8989:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    898e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8992:	48 85 d2             	test   %rdx,%rdx
    8995:	0f 85 52 ff ff ff    	jne    88ed <fwp_write+0x6dd>
    899b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    89a0:	48 85 ff             	test   %rdi,%rdi
    89a3:	0f 88 cf 05 00 00    	js     8f78 <fwp_write+0xd68>
    89a9:	48 8b 31             	mov    (%rcx),%rsi
    89ac:	eb a2                	jmp    8950 <fwp_write+0x740>
    89ae:	66 90                	xchg   %ax,%ax
    89b0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    89b7:	00 
    89b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    89bf:	00 00 
    89c1:	0f 85 1e fd ff ff    	jne    86e5 <fwp_write+0x4d5>
    89c7:	ba 08 00 00 00       	mov    $0x8,%edx
    89cc:	48 8d 35 f2 67 00 00 	lea    0x67f2(%rip),%rsi        # f1c5 <_IO_stdin_used+0x1c5>
    89d3:	e9 4b fa ff ff       	jmp    8423 <fwp_write+0x213>
    89d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    89df:	00 
    89e0:	89 e8                	mov    %ebp,%eax
    89e2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    89e9:	76 03                	jbe    89ee <fwp_write+0x7de>
    89eb:	8b 45 00             	mov    0x0(%rbp),%eax
    89ee:	41 89 c6             	mov    %eax,%r14d
    89f1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    89f6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    89fb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    89ff:	4c 89 ef             	mov    %r13,%rdi
    8a02:	e8 49 aa ff ff       	call   3450 <strlen@plt>
    8a07:	4c 89 ee             	mov    %r13,%rsi
    8a0a:	48 89 df             	mov    %rbx,%rdi
    8a0d:	48 89 c2             	mov    %rax,%rdx
    8a10:	e8 fb b7 ff ff       	call   4210 <buf_put>
    8a15:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8a1a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8a1e:	85 f6                	test   %esi,%esi
    8a20:	0f 8e 80 f8 ff ff    	jle    82a6 <fwp_write+0x96>
    8a26:	45 31 ed             	xor    %r13d,%r13d
    8a29:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8a2e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8a33:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8a38:	ba 01 00 00 00       	mov    $0x1,%edx
    8a3d:	4c 89 fe             	mov    %r15,%rsi
    8a40:	48 89 04 24          	mov    %rax,(%rsp)
    8a44:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8a49:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8a4d:	48 89 df             	mov    %rbx,%rdi
    8a50:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8a54:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8a59:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8a5e:	e8 ad b7 ff ff       	call   4210 <buf_put>
    8a63:	41 8b 06             	mov    (%r14),%eax
    8a66:	83 f8 0e             	cmp    $0xe,%eax
    8a69:	0f 84 71 02 00 00    	je     8ce0 <fwp_write+0xad0>
    8a6f:	83 f8 10             	cmp    $0x10,%eax
    8a72:	0f 84 38 02 00 00    	je     8cb0 <fwp_write+0xaa0>
    8a78:	83 f8 0a             	cmp    $0xa,%eax
    8a7b:	0f 84 7f 04 00 00    	je     8f00 <fwp_write+0xcf0>
    8a81:	0f 8f f9 00 00 00    	jg     8b80 <fwp_write+0x970>
    8a87:	83 f8 03             	cmp    $0x3,%eax
    8a8a:	0f 8f 50 04 00 00    	jg     8ee0 <fwp_write+0xcd0>
    8a90:	85 c0                	test   %eax,%eax
    8a92:	78 10                	js     8aa4 <fwp_write+0x894>
    8a94:	48 8b 04 24          	mov    (%rsp),%rax
    8a98:	48 c1 e8 3f          	shr    $0x3f,%rax
    8a9c:	85 c0                	test   %eax,%eax
    8a9e:	0f 85 f9 00 00 00    	jne    8b9d <fwp_write+0x98d>
    8aa4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8aa9:	48 8b 34 24          	mov    (%rsp),%rsi
    8aad:	31 c9                	xor    %ecx,%ecx
    8aaf:	48 89 df             	mov    %rbx,%rdi
    8ab2:	e8 59 f7 ff ff       	call   8210 <fwp_write>
    8ab7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8abc:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8ac1:	49 83 c5 01          	add    $0x1,%r13
    8ac5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8ac9:	0f 8f 5f ff ff ff    	jg     8a2e <fwp_write+0x81e>
    8acf:	e9 d2 f7 ff ff       	jmp    82a6 <fwp_write+0x96>
    8ad4:	0f 1f 40 00          	nopl   0x0(%rax)
    8ad8:	ba 06 00 00 00       	mov    $0x6,%edx
    8add:	48 8d 35 07 67 00 00 	lea    0x6707(%rip),%rsi        # f1eb <_IO_stdin_used+0x1eb>
    8ae4:	45 31 ed             	xor    %r13d,%r13d
    8ae7:	e8 24 b7 ff ff       	call   4210 <buf_put>
    8aec:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8af1:	75 19                	jne    8b0c <fwp_write+0x8fc>
    8af3:	eb 6c                	jmp    8b61 <fwp_write+0x951>
    8af5:	0f 1f 00             	nopl   (%rax)
    8af8:	ba 02 00 00 00       	mov    $0x2,%edx
    8afd:	48 8d 35 f1 66 00 00 	lea    0x66f1(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8b04:	48 89 df             	mov    %rbx,%rdi
    8b07:	e8 04 b7 ff ff       	call   4210 <buf_put>
    8b0c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8b12:	b9 00 02 00 00       	mov    $0x200,%ecx
    8b17:	31 c0                	xor    %eax,%eax
    8b19:	49 83 c5 01          	add    $0x1,%r13
    8b1d:	4c 8d 05 ce 66 00 00 	lea    0x66ce(%rip),%r8        # f1f2 <_IO_stdin_used+0x1f2>
    8b24:	ba 02 00 00 00       	mov    $0x2,%edx
    8b29:	be 00 02 00 00       	mov    $0x200,%esi
    8b2e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8b35:	00 
    8b36:	e8 75 a8 ff ff       	call   33b0 <__snprintf_chk@plt>
    8b3b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8b42:	00 
    8b43:	e8 08 a9 ff ff       	call   3450 <strlen@plt>
    8b48:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8b4f:	00 
    8b50:	48 89 df             	mov    %rbx,%rdi
    8b53:	48 89 c2             	mov    %rax,%rdx
    8b56:	e8 b5 b6 ff ff       	call   4210 <buf_put>
    8b5b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8b5f:	72 97                	jb     8af8 <fwp_write+0x8e8>
    8b61:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8b66:	ba 01 00 00 00       	mov    $0x1,%edx
    8b6b:	48 89 df             	mov    %rbx,%rdi
    8b6e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8b73:	e8 98 b6 ff ff       	call   4210 <buf_put>
    8b78:	e9 29 f7 ff ff       	jmp    82a6 <fwp_write+0x96>
    8b7d:	0f 1f 00             	nopl   (%rax)
    8b80:	83 f8 0b             	cmp    $0xb,%eax
    8b83:	0f 85 1b ff ff ff    	jne    8aa4 <fwp_write+0x894>
    8b89:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8b8e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8b92:	83 e0 01             	and    $0x1,%eax
    8b95:	85 c0                	test   %eax,%eax
    8b97:	0f 84 07 ff ff ff    	je     8aa4 <fwp_write+0x894>
    8b9d:	4c 89 fe             	mov    %r15,%rsi
    8ba0:	48 89 df             	mov    %rbx,%rdi
    8ba3:	ba 01 00 00 00       	mov    $0x1,%edx
    8ba8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8bad:	e8 5e b6 ff ff       	call   4210 <buf_put>
    8bb2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8bb7:	48 8b 34 24          	mov    (%rsp),%rsi
    8bbb:	31 c9                	xor    %ecx,%ecx
    8bbd:	48 89 df             	mov    %rbx,%rdi
    8bc0:	e8 4b f6 ff ff       	call   8210 <fwp_write>
    8bc5:	ba 01 00 00 00       	mov    $0x1,%edx
    8bca:	4c 89 fe             	mov    %r15,%rsi
    8bcd:	48 89 df             	mov    %rbx,%rdi
    8bd0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8bd5:	e8 36 b6 ff ff       	call   4210 <buf_put>
    8bda:	e9 d8 fe ff ff       	jmp    8ab7 <fwp_write+0x8a7>
    8bdf:	90                   	nop
    8be0:	ba 01 00 00 00       	mov    $0x1,%edx
    8be5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8bea:	48 89 df             	mov    %rbx,%rdi
    8bed:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8bf2:	e8 19 b6 ff ff       	call   4210 <buf_put>
    8bf7:	e9 aa f6 ff ff       	jmp    82a6 <fwp_write+0x96>
    8bfc:	0f 1f 40 00          	nopl   0x0(%rax)
    8c00:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8c05:	ba 01 00 00 00       	mov    $0x1,%edx
    8c0a:	48 89 df             	mov    %rbx,%rdi
    8c0d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8c12:	e8 f9 b5 ff ff       	call   4210 <buf_put>
    8c17:	e9 8a f6 ff ff       	jmp    82a6 <fwp_write+0x96>
    8c1c:	0f 1f 40 00          	nopl   0x0(%rax)
    8c20:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8c24:	48 8b 13             	mov    (%rbx),%rdx
    8c27:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    8c2c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8c30:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8c34:	e9 6d f6 ff ff       	jmp    82a6 <fwp_write+0x96>
    8c39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8c40:	ba 02 00 00 00       	mov    $0x2,%edx
    8c45:	48 8d 35 a9 65 00 00 	lea    0x65a9(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8c4c:	48 89 df             	mov    %rbx,%rdi
    8c4f:	e8 bc b5 ff ff       	call   4210 <buf_put>
    8c54:	e9 72 f8 ff ff       	jmp    84cb <fwp_write+0x2bb>
    8c59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8c60:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8c65:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8c6a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    8c6e:	48 89 f7             	mov    %rsi,%rdi
    8c71:	48 89 34 24          	mov    %rsi,(%rsp)
    8c75:	e8 d6 a7 ff ff       	call   3450 <strlen@plt>
    8c7a:	48 8b 34 24          	mov    (%rsp),%rsi
    8c7e:	48 89 df             	mov    %rbx,%rdi
    8c81:	48 89 c2             	mov    %rax,%rdx
    8c84:	e8 87 b5 ff ff       	call   4210 <buf_put>
    8c89:	ba 03 00 00 00       	mov    $0x3,%edx
    8c8e:	48 8d 35 83 65 00 00 	lea    0x6583(%rip),%rsi        # f218 <_IO_stdin_used+0x218>
    8c95:	48 89 df             	mov    %rbx,%rdi
    8c98:	e8 73 b5 ff ff       	call   4210 <buf_put>
    8c9d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    8ca2:	e9 35 f8 ff ff       	jmp    84dc <fwp_write+0x2cc>
    8ca7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8cae:	00 00 
    8cb0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8cb5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    8cb9:	48 85 ff             	test   %rdi,%rdi
    8cbc:	0f 84 e2 fd ff ff    	je     8aa4 <fwp_write+0x894>
    8cc2:	48 8d 35 39 65 00 00 	lea    0x6539(%rip),%rsi        # f202 <_IO_stdin_used+0x202>
    8cc9:	e8 62 a8 ff ff       	call   3530 <strcmp@plt>
    8cce:	85 c0                	test   %eax,%eax
    8cd0:	0f 95 c0             	setne  %al
    8cd3:	0f b6 c0             	movzbl %al,%eax
    8cd6:	e9 c1 fd ff ff       	jmp    8a9c <fwp_write+0x88c>
    8cdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8ce0:	31 c0                	xor    %eax,%eax
    8ce2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    8ce9:	00 
    8cea:	0f 97 c0             	seta   %al
    8ced:	e9 aa fd ff ff       	jmp    8a9c <fwp_write+0x88c>
    8cf2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8cf8:	48 89 df             	mov    %rbx,%rdi
    8cfb:	ba 02 00 00 00       	mov    $0x2,%edx
    8d00:	48 8d 35 f8 64 00 00 	lea    0x64f8(%rip),%rsi        # f1ff <_IO_stdin_used+0x1ff>
    8d07:	e8 04 b5 ff ff       	call   4210 <buf_put>
    8d0c:	4c 89 e8             	mov    %r13,%rax
    8d0f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    8d14:	31 c9                	xor    %ecx,%ecx
    8d16:	48 c1 e0 04          	shl    $0x4,%rax
    8d1a:	48 89 df             	mov    %rbx,%rdi
    8d1d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    8d22:	e8 e9 f4 ff ff       	call   8210 <fwp_write>
    8d27:	e9 5e f6 ff ff       	jmp    838a <fwp_write+0x17a>
    8d2c:	0f 1f 40 00          	nopl   0x0(%rax)
    8d30:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    8d35:	48 85 ff             	test   %rdi,%rdi
    8d38:	79 0c                	jns    8d46 <fwp_write+0xb36>
    8d3a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    8d41:	00 
    8d42:	48 03 75 10          	add    0x10(%rbp),%rsi
    8d46:	48 63 3e             	movslq (%rsi),%rdi
    8d49:	83 f9 02             	cmp    $0x2,%ecx
    8d4c:	89 fe                	mov    %edi,%esi
    8d4e:	48 0f 44 f7          	cmove  %rdi,%rsi
    8d52:	e9 f9 fb ff ff       	jmp    8950 <fwp_write+0x740>
    8d57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8d5e:	00 00 
    8d60:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    8d65:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    8d6a:	48 85 ff             	test   %rdi,%rdi
    8d6d:	0f 88 0f 03 00 00    	js     9082 <fwp_write+0xe72>
    8d73:	49 0f bf 38          	movswq (%r8),%rdi
    8d77:	83 f9 01             	cmp    $0x1,%ecx
    8d7a:	0f b7 f7             	movzwl %di,%esi
    8d7d:	48 0f 44 f7          	cmove  %rdi,%rsi
    8d81:	e9 ca fb ff ff       	jmp    8950 <fwp_write+0x740>
    8d86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8d8d:	00 00 00 
    8d90:	ba 01 00 00 00       	mov    $0x1,%edx
    8d95:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8d9a:	48 83 c5 08          	add    $0x8,%rbp
    8d9e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8da3:	e8 68 b4 ff ff       	call   4210 <buf_put>
    8da8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8dad:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    8db2:	4d 85 ed             	test   %r13,%r13
    8db5:	75 46                	jne    8dfd <fwp_write+0xbed>
    8db7:	e9 04 01 00 00       	jmp    8ec0 <fwp_write+0xcb0>
    8dbc:	0f 1f 40 00          	nopl   0x0(%rax)
    8dc0:	41 80 f9 09          	cmp    $0x9,%r9b
    8dc4:	0f 84 d6 00 00 00    	je     8ea0 <fwp_write+0xc90>
    8dca:	41 80 f9 0a          	cmp    $0xa,%r9b
    8dce:	0f 85 9c 00 00 00    	jne    8e70 <fwp_write+0xc60>
    8dd4:	ba 02 00 00 00       	mov    $0x2,%edx
    8dd9:	48 8d 35 fb 63 00 00 	lea    0x63fb(%rip),%rsi        # f1db <_IO_stdin_used+0x1db>
    8de0:	48 89 df             	mov    %rbx,%rdi
    8de3:	e8 28 b4 ff ff       	call   4210 <buf_put>
    8de8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8def:	00 
    8df0:	48 83 c5 01          	add    $0x1,%rbp
    8df4:	49 39 ec             	cmp    %rbp,%r12
    8df7:	0f 84 c3 00 00 00    	je     8ec0 <fwp_write+0xcb0>
    8dfd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    8e02:	41 80 f9 0d          	cmp    $0xd,%r9b
    8e06:	74 28                	je     8e30 <fwp_write+0xc20>
    8e08:	7e b6                	jle    8dc0 <fwp_write+0xbb0>
    8e0a:	41 80 f9 22          	cmp    $0x22,%r9b
    8e0e:	74 40                	je     8e50 <fwp_write+0xc40>
    8e10:	41 80 f9 5c          	cmp    $0x5c,%r9b
    8e14:	75 5a                	jne    8e70 <fwp_write+0xc60>
    8e16:	ba 02 00 00 00       	mov    $0x2,%edx
    8e1b:	48 8d 35 b6 63 00 00 	lea    0x63b6(%rip),%rsi        # f1d8 <_IO_stdin_used+0x1d8>
    8e22:	48 89 df             	mov    %rbx,%rdi
    8e25:	e8 e6 b3 ff ff       	call   4210 <buf_put>
    8e2a:	eb c4                	jmp    8df0 <fwp_write+0xbe0>
    8e2c:	0f 1f 40 00          	nopl   0x0(%rax)
    8e30:	ba 02 00 00 00       	mov    $0x2,%edx
    8e35:	48 8d 35 a5 63 00 00 	lea    0x63a5(%rip),%rsi        # f1e1 <_IO_stdin_used+0x1e1>
    8e3c:	48 89 df             	mov    %rbx,%rdi
    8e3f:	e8 cc b3 ff ff       	call   4210 <buf_put>
    8e44:	eb aa                	jmp    8df0 <fwp_write+0xbe0>
    8e46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8e4d:	00 00 00 
    8e50:	ba 02 00 00 00       	mov    $0x2,%edx
    8e55:	48 8d 35 79 63 00 00 	lea    0x6379(%rip),%rsi        # f1d5 <_IO_stdin_used+0x1d5>
    8e5c:	48 89 df             	mov    %rbx,%rdi
    8e5f:	e8 ac b3 ff ff       	call   4210 <buf_put>
    8e64:	eb 8a                	jmp    8df0 <fwp_write+0xbe0>
    8e66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8e6d:	00 00 00 
    8e70:	41 80 f9 1f          	cmp    $0x1f,%r9b
    8e74:	0f 86 2e 01 00 00    	jbe    8fa8 <fwp_write+0xd98>
    8e7a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    8e7e:	0f 84 24 01 00 00    	je     8fa8 <fwp_write+0xd98>
    8e84:	ba 01 00 00 00       	mov    $0x1,%edx
    8e89:	4c 89 fe             	mov    %r15,%rsi
    8e8c:	48 89 df             	mov    %rbx,%rdi
    8e8f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    8e94:	e8 77 b3 ff ff       	call   4210 <buf_put>
    8e99:	e9 52 ff ff ff       	jmp    8df0 <fwp_write+0xbe0>
    8e9e:	66 90                	xchg   %ax,%ax
    8ea0:	ba 02 00 00 00       	mov    $0x2,%edx
    8ea5:	48 8d 35 32 63 00 00 	lea    0x6332(%rip),%rsi        # f1de <_IO_stdin_used+0x1de>
    8eac:	48 89 df             	mov    %rbx,%rdi
    8eaf:	e8 5c b3 ff ff       	call   4210 <buf_put>
    8eb4:	e9 37 ff ff ff       	jmp    8df0 <fwp_write+0xbe0>
    8eb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ec0:	ba 01 00 00 00       	mov    $0x1,%edx
    8ec5:	4c 89 fe             	mov    %r15,%rsi
    8ec8:	48 89 df             	mov    %rbx,%rdi
    8ecb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8ed0:	e8 3b b3 ff ff       	call   4210 <buf_put>
    8ed5:	e9 cc f3 ff ff       	jmp    82a6 <fwp_write+0x96>
    8eda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ee0:	83 f8 04             	cmp    $0x4,%eax
    8ee3:	0f 85 bb fb ff ff    	jne    8aa4 <fwp_write+0x894>
    8ee9:	48 8b 04 24          	mov    (%rsp),%rax
    8eed:	48 8b 40 08          	mov    0x8(%rax),%rax
    8ef1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8ef6:	48 c1 e8 3f          	shr    $0x3f,%rax
    8efa:	e9 96 fc ff ff       	jmp    8b95 <fwp_write+0x985>
    8eff:	90                   	nop
    8f00:	8b 0c 24             	mov    (%rsp),%ecx
    8f03:	31 c0                	xor    %eax,%eax
    8f05:	85 c9                	test   %ecx,%ecx
    8f07:	0f 98 c0             	sets   %al
    8f0a:	e9 86 fc ff ff       	jmp    8b95 <fwp_write+0x985>
    8f0f:	90                   	nop
    8f10:	48 f7 d8             	neg    %rax
    8f13:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    8f1a:	00 
    8f1b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    8f22:	2d 
    8f23:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8f2a:	00 
    8f2b:	48 83 d2 00          	adc    $0x0,%rdx
    8f2f:	48 89 c6             	mov    %rax,%rsi
    8f32:	48 f7 da             	neg    %rdx
    8f35:	e8 06 ab ff ff       	call   3a40 <fwp_fmt_u128>
    8f3a:	e9 51 f3 ff ff       	jmp    8290 <fwp_write+0x80>
    8f3f:	90                   	nop
    8f40:	b8 7d 00 00 00       	mov    $0x7d,%eax
    8f45:	e9 c3 f5 ff ff       	jmp    850d <fwp_write+0x2fd>
    8f4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8f50:	4c 89 e9             	mov    %r13,%rcx
    8f53:	48 c1 e1 04          	shl    $0x4,%rcx
    8f57:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    8f5c:	48 85 ff             	test   %rdi,%rdi
    8f5f:	0f 89 eb f9 ff ff    	jns    8950 <fwp_write+0x740>
    8f65:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8f69:	48 89 ce             	mov    %rcx,%rsi
    8f6c:	e9 df f9 ff ff       	jmp    8950 <fwp_write+0x740>
    8f71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8f78:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8f7f:	00 
    8f80:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8f84:	e9 20 fa ff ff       	jmp    89a9 <fwp_write+0x799>
    8f89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8f90:	ba 02 00 00 00       	mov    $0x2,%edx
    8f95:	48 8d 35 09 62 00 00 	lea    0x6209(%rip),%rsi        # f1a5 <_IO_stdin_used+0x1a5>
    8f9c:	e9 2d f7 ff ff       	jmp    86ce <fwp_write+0x4be>
    8fa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8fa8:	4c 8d 05 35 62 00 00 	lea    0x6235(%rip),%r8        # f1e4 <_IO_stdin_used+0x1e4>
    8faf:	b9 10 00 00 00       	mov    $0x10,%ecx
    8fb4:	31 c0                	xor    %eax,%eax
    8fb6:	ba 02 00 00 00       	mov    $0x2,%edx
    8fbb:	be 10 00 00 00       	mov    $0x10,%esi
    8fc0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8fc7:	00 
    8fc8:	e8 e3 a3 ff ff       	call   33b0 <__snprintf_chk@plt>
    8fcd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8fd4:	00 
    8fd5:	e8 76 a4 ff ff       	call   3450 <strlen@plt>
    8fda:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8fe1:	00 
    8fe2:	48 89 df             	mov    %rbx,%rdi
    8fe5:	48 89 c2             	mov    %rax,%rdx
    8fe8:	e8 23 b2 ff ff       	call   4210 <buf_put>
    8fed:	e9 fe fd ff ff       	jmp    8df0 <fwp_write+0xbe0>
    8ff2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ff8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8ffc:	48 8d 35 9c 61 00 00 	lea    0x619c(%rip),%rsi        # f19f <_IO_stdin_used+0x19f>
    9003:	48 8d 05 94 61 00 00 	lea    0x6194(%rip),%rax        # f19e <_IO_stdin_used+0x19e>
    900a:	4c 89 e7             	mov    %r12,%rdi
    900d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9011:	48 0f 46 f0          	cmovbe %rax,%rsi
    9015:	e8 d6 a3 ff ff       	call   33f0 <strcpy@plt>
    901a:	e9 71 f2 ff ff       	jmp    8290 <fwp_write+0x80>
    901f:	90                   	nop
    9020:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9024:	48 8d 35 74 61 00 00 	lea    0x6174(%rip),%rsi        # f19f <_IO_stdin_used+0x19f>
    902b:	48 8d 05 6c 61 00 00 	lea    0x616c(%rip),%rax        # f19e <_IO_stdin_used+0x19e>
    9032:	0f 2f c8             	comiss %xmm0,%xmm1
    9035:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    903c:	00 
    903d:	4c 89 e7             	mov    %r12,%rdi
    9040:	48 0f 46 f0          	cmovbe %rax,%rsi
    9044:	e8 a7 a3 ff ff       	call   33f0 <strcpy@plt>
    9049:	e9 42 f2 ff ff       	jmp    8290 <fwp_write+0x80>
    904e:	66 90                	xchg   %ax,%ax
    9050:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9055:	45 85 c0             	test   %r8d,%r8d
    9058:	75 34                	jne    908e <fwp_write+0xe7e>
    905a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9061:	00 
    9062:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9069:	00 00 
    906b:	0f 85 74 f6 ff ff    	jne    86e5 <fwp_write+0x4d5>
    9071:	ba 02 00 00 00       	mov    $0x2,%edx
    9076:	48 8d 35 98 61 00 00 	lea    0x6198(%rip),%rsi        # f215 <_IO_stdin_used+0x215>
    907d:	e9 a1 f3 ff ff       	jmp    8423 <fwp_write+0x213>
    9082:	48 03 75 10          	add    0x10(%rbp),%rsi
    9086:	49 89 f0             	mov    %rsi,%r8
    9089:	e9 e5 fc ff ff       	jmp    8d73 <fwp_write+0xb63>
    908e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9093:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9098:	85 ff                	test   %edi,%edi
    909a:	0f 84 fa f3 ff ff    	je     849a <fwp_write+0x28a>
    90a0:	ba 01 00 00 00       	mov    $0x1,%edx
    90a5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    90aa:	48 89 df             	mov    %rbx,%rdi
    90ad:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    90b2:	e8 59 b1 ff ff       	call   4210 <buf_put>
    90b7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    90bc:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    90c1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    90c7:	85 c0                	test   %eax,%eax
    90c9:	0f 8f f0 f3 ff ff    	jg     84bf <fwp_write+0x2af>
    90cf:	e9 34 f4 ff ff       	jmp    8508 <fwp_write+0x2f8>
    90d4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    90d8:	49 89 c5             	mov    %rax,%r13
    90db:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    90e0:	49 89 c4             	mov    %rax,%r12
    90e3:	49 c1 fd 3f          	sar    $0x3f,%r13
    90e7:	4c 09 e8             	or     %r13,%rax
    90ea:	0f 84 a7 00 00 00    	je     9197 <fwp_write+0xf87>
    90f0:	48 8d 2d a9 81 00 00 	lea    0x81a9(%rip),%rbp        # 112a0 <units.0>
    90f7:	4d 89 e7             	mov    %r12,%r15
    90fa:	48 8b 45 08          	mov    0x8(%rbp),%rax
    90fe:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9103:	4c 89 ff             	mov    %r15,%rdi
    9106:	4c 89 ee             	mov    %r13,%rsi
    9109:	44 89 0c 24          	mov    %r9d,(%rsp)
    910d:	48 99                	cqto
    910f:	48 89 d1             	mov    %rdx,%rcx
    9112:	48 89 c2             	mov    %rax,%rdx
    9115:	e8 96 4e 00 00       	call   dfb0 <__divmodti4>
    911a:	44 8b 0c 24          	mov    (%rsp),%r9d
    911e:	48 89 c1             	mov    %rax,%rcx
    9121:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9126:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    912b:	0f 84 94 00 00 00    	je     91c5 <fwp_write+0xfb5>
    9131:	41 83 c1 01          	add    $0x1,%r9d
    9135:	48 83 c5 10          	add    $0x10,%rbp
    9139:	41 83 f9 05          	cmp    $0x5,%r9d
    913d:	75 bb                	jne    90fa <fwp_write+0xeea>
    913f:	4d 85 ed             	test   %r13,%r13
    9142:	79 53                	jns    9197 <fwp_write+0xf87>
    9144:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9149:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    914e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9153:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9158:	48 99                	cqto
    915a:	48 f7 d8             	neg    %rax
    915d:	48 83 d2 00          	adc    $0x0,%rdx
    9161:	48 89 c6             	mov    %rax,%rsi
    9164:	48 f7 da             	neg    %rdx
    9167:	e8 d4 a8 ff ff       	call   3a40 <fwp_fmt_u128>
    916c:	49 89 e8             	mov    %rbp,%r8
    916f:	ba 00 02 00 00       	mov    $0x200,%edx
    9174:	be 02 00 00 00       	mov    $0x2,%esi
    9179:	31 c0                	xor    %eax,%eax
    917b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9182:	00 
    9183:	48 8d 0d 86 60 00 00 	lea    0x6086(%rip),%rcx        # f210 <_IO_stdin_used+0x210>
    918a:	4c 89 e7             	mov    %r12,%rdi
    918d:	e8 4e a5 ff ff       	call   36e0 <__sprintf_chk@plt>
    9192:	e9 f9 f0 ff ff       	jmp    8290 <fwp_write+0x80>
    9197:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    919c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    91a1:	31 d2                	xor    %edx,%edx
    91a3:	48 89 ef             	mov    %rbp,%rdi
    91a6:	e8 95 a8 ff ff       	call   3a40 <fwp_fmt_u128>
    91ab:	eb bf                	jmp    916c <fwp_write+0xf5c>
    91ad:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    91b4:	4e 61 4e 00 
    91b8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    91bf:	00 
    91c0:	e9 cb f0 ff ff       	jmp    8290 <fwp_write+0x80>
    91c5:	44 89 0c 24          	mov    %r9d,(%rsp)
    91c9:	48 89 c8             	mov    %rcx,%rax
    91cc:	48 85 d2             	test   %rdx,%rdx
    91cf:	78 51                	js     9222 <fwp_write+0x1012>
    91d1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    91d6:	48 89 c6             	mov    %rax,%rsi
    91d9:	48 89 ef             	mov    %rbp,%rdi
    91dc:	e8 5f a8 ff ff       	call   3a40 <fwp_fmt_u128>
    91e1:	44 8b 0c 24          	mov    (%rsp),%r9d
    91e5:	49 63 c1             	movslq %r9d,%rax
    91e8:	49 89 e8             	mov    %rbp,%r8
    91eb:	ba 00 02 00 00       	mov    $0x200,%edx
    91f0:	be 02 00 00 00       	mov    $0x2,%esi
    91f5:	48 c1 e0 04          	shl    $0x4,%rax
    91f9:	48 8d 3d a0 80 00 00 	lea    0x80a0(%rip),%rdi        # 112a0 <units.0>
    9200:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9207:	00 
    9208:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    920c:	48 8d 0d f8 5f 00 00 	lea    0x5ff8(%rip),%rcx        # f20b <_IO_stdin_used+0x20b>
    9213:	4c 89 e7             	mov    %r12,%rdi
    9216:	31 c0                	xor    %eax,%eax
    9218:	e8 c3 a4 ff ff       	call   36e0 <__sprintf_chk@plt>
    921d:	e9 6e f0 ff ff       	jmp    8290 <fwp_write+0x80>
    9222:	48 f7 d8             	neg    %rax
    9225:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    922a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    922f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9234:	48 83 d2 00          	adc    $0x0,%rdx
    9238:	48 89 c6             	mov    %rax,%rsi
    923b:	48 f7 da             	neg    %rdx
    923e:	e8 fd a7 ff ff       	call   3a40 <fwp_fmt_u128>
    9243:	44 8b 0c 24          	mov    (%rsp),%r9d
    9247:	eb 9c                	jmp    91e5 <fwp_write+0xfd5>
    9249:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009250 <fwp_hof0.constprop.0>:
    9250:	41 57                	push   %r15
    9252:	41 56                	push   %r14
    9254:	41 55                	push   %r13
    9256:	41 54                	push   %r12
    9258:	55                   	push   %rbp
    9259:	53                   	push   %rbx
    925a:	48 81 ec 18 01 00 00 	sub    $0x118,%rsp
    9261:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9268:	00 00 
    926a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    9271:	00 
    9272:	31 c0                	xor    %eax,%eax
    9274:	48 85 f6             	test   %rsi,%rsi
    9277:	0f 84 1a 0f 00 00    	je     a197 <fwp_hof0.constprop.0+0xf47>
    927d:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
    9282:	48 8d 1d 37 a5 01 00 	lea    0x1a537(%rip),%rbx        # 237c0 <fwp_heap>
    9289:	48 89 7c 24 50       	mov    %rdi,0x50(%rsp)
    928e:	66 90                	xchg   %ax,%ax
    9290:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9297:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    929c:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    92a3:	48 c1 e2 10          	shl    $0x10,%rdx
    92a7:	48 39 d0             	cmp    %rdx,%rax
    92aa:	73 5d                	jae    9309 <fwp_hof0.constprop.0+0xb9>
    92ac:	48 89 c2             	mov    %rax,%rdx
    92af:	48 c1 ea 10          	shr    $0x10,%rdx
    92b3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    92b7:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    92be:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    92c2:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    92c6:	48 85 ff             	test   %rdi,%rdi
    92c9:	74 3e                	je     9309 <fwp_hof0.constprop.0+0xb9>
    92cb:	0f b6 0a             	movzbl (%rdx),%ecx
    92ce:	80 f9 02             	cmp    $0x2,%cl
    92d1:	0f 84 19 15 00 00    	je     a7f0 <fwp_hof0.constprop.0+0x15a0>
    92d7:	80 f9 01             	cmp    $0x1,%cl
    92da:	75 2d                	jne    9309 <fwp_hof0.constprop.0+0xb9>
    92dc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    92df:	0f b7 c0             	movzwl %ax,%eax
    92e2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    92e5:	48 0f af c1          	imul   %rcx,%rax
    92e9:	48 c1 e8 20          	shr    $0x20,%rax
    92ed:	48 39 d0             	cmp    %rdx,%rax
    92f0:	73 17                	jae    9309 <fwp_hof0.constprop.0+0xb9>
    92f2:	48 01 c7             	add    %rax,%rdi
    92f5:	0f b6 07             	movzbl (%rdi),%eax
    92f8:	84 c0                	test   %al,%al
    92fa:	74 0d                	je     9309 <fwp_hof0.constprop.0+0xb9>
    92fc:	3c fd                	cmp    $0xfd,%al
    92fe:	0f 87 18 17 00 00    	ja     aa1c <fwp_hof0.constprop.0+0x17cc>
    9304:	83 c0 01             	add    $0x1,%eax
    9307:	88 07                	mov    %al,(%rdi)
    9309:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    930e:	45 31 c0             	xor    %r8d,%r8d
    9311:	48 c7 44 24 38 c6 00 	movq   $0xc6,0x38(%rsp)
    9318:	00 00 
    931a:	48 89 04 24          	mov    %rax,(%rsp)
    931e:	4d 89 c5             	mov    %r8,%r13
    9321:	4d 85 c0             	test   %r8,%r8
    9324:	0f 85 26 a4 ff ff    	jne    3750 <fwp_hof0.constprop.0.cold+0x5>
    932a:	48 8b 05 27 c1 01 00 	mov    0x1c127(%rip),%rax        # 25458 <fwp_cleanups>
    9331:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9338:	4c 8d 3d 01 d8 ff ff 	lea    -0x27ff(%rip),%r15        # 6b40 <fwp_tape_scope_release>
    933f:	c7 44 24 6c ff ff ff 	movl   $0xffffffff,0x6c(%rsp)
    9346:	ff 
    9347:	4c 89 7c 24 78       	mov    %r15,0x78(%rsp)
    934c:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    9351:	48 8d 44 24 6c       	lea    0x6c(%rsp),%rax
    9356:	48 c1 e2 10          	shl    $0x10,%rdx
    935a:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    935f:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9366:	00 
    9367:	48 8d 44 24 70       	lea    0x70(%rsp),%rax
    936c:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    9371:	48 89 05 e0 c0 01 00 	mov    %rax,0x1c0e0(%rip)        # 25458 <fwp_cleanups>
    9378:	48 8d 05 91 9c 00 00 	lea    0x9c91(%rip),%rax        # 13010 <fc37>
    937f:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9386:	48 39 d0             	cmp    %rdx,%rax
    9389:	73 5d                	jae    93e8 <fwp_hof0.constprop.0+0x198>
    938b:	48 89 c2             	mov    %rax,%rdx
    938e:	48 c1 ea 10          	shr    $0x10,%rdx
    9392:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9396:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    939d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    93a1:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    93a5:	48 85 ff             	test   %rdi,%rdi
    93a8:	74 3e                	je     93e8 <fwp_hof0.constprop.0+0x198>
    93aa:	0f b6 0a             	movzbl (%rdx),%ecx
    93ad:	80 f9 02             	cmp    $0x2,%cl
    93b0:	0f 84 da 12 00 00    	je     a690 <fwp_hof0.constprop.0+0x1440>
    93b6:	80 f9 01             	cmp    $0x1,%cl
    93b9:	75 2d                	jne    93e8 <fwp_hof0.constprop.0+0x198>
    93bb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    93be:	0f b7 c0             	movzwl %ax,%eax
    93c1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    93c4:	48 0f af c1          	imul   %rcx,%rax
    93c8:	48 c1 e8 20          	shr    $0x20,%rax
    93cc:	48 39 d0             	cmp    %rdx,%rax
    93cf:	73 17                	jae    93e8 <fwp_hof0.constprop.0+0x198>
    93d1:	48 01 c7             	add    %rax,%rdi
    93d4:	0f b6 07             	movzbl (%rdi),%eax
    93d7:	84 c0                	test   %al,%al
    93d9:	74 0d                	je     93e8 <fwp_hof0.constprop.0+0x198>
    93db:	3c fd                	cmp    $0xfd,%al
    93dd:	0f 87 78 15 00 00    	ja     a95b <fwp_hof0.constprop.0+0x170b>
    93e3:	83 c0 01             	add    $0x1,%eax
    93e6:	88 07                	mov    %al,(%rdi)
    93e8:	48 8d 3d 21 9c 00 00 	lea    0x9c21(%rip),%rdi        # 13010 <fc37>
    93ef:	e8 1c d4 ff ff       	call   6810 <fwp_closure_drop>
    93f4:	48 8b 04 24          	mov    (%rsp),%rax
    93f8:	48 85 c0             	test   %rax,%rax
    93fb:	0f 84 5f 14 00 00    	je     a860 <fwp_hof0.constprop.0+0x1610>
    9401:	31 ed                	xor    %ebp,%ebp
    9403:	66 90                	xchg   %ax,%ax
    9405:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    940c:	00 00 00 00 
    9410:	48 8b 40 10          	mov    0x10(%rax),%rax
    9414:	48 83 c5 01          	add    $0x1,%rbp
    9418:	48 85 c0             	test   %rax,%rax
    941b:	75 f3                	jne    9410 <fwp_hof0.constprop.0+0x1c0>
    941d:	31 ff                	xor    %edi,%edi
    941f:	e8 2c ae ff ff       	call   4250 <descent_phase_step>
    9424:	48 81 fd ff ff ff 7f 	cmp    $0x7fffffff,%rbp
    942b:	0f 87 29 16 00 00    	ja     aa5a <fwp_hof0.constprop.0+0x180a>
    9431:	66 48 0f 6e c5       	movq   %rbp,%xmm0
    9436:	8b 35 24 9c 00 00    	mov    0x9c24(%rip),%esi        # 13060 <registered_finish.1>
    943c:	85 f6                	test   %esi,%esi
    943e:	0f 84 04 12 00 00    	je     a648 <fwp_hof0.constprop.0+0x13f8>
    9444:	48 8b 15 8d 9c 01 00 	mov    0x19c8d(%rip),%rdx        # 230d8 <fwp_tape_next_slot>
    944b:	48 8b 2d 96 9c 01 00 	mov    0x19c96(%rip),%rbp        # 230e8 <fwp_ntapes>
    9452:	48 39 d5             	cmp    %rdx,%rbp
    9455:	0f 8e c5 10 00 00    	jle    a520 <fwp_hof0.constprop.0+0x12d0>
    945b:	48 6b c2 68          	imul   $0x68,%rdx,%rax
    945f:	48 03 05 8a 9c 01 00 	add    0x19c8a(%rip),%rax        # 230f0 <fwp_tapes>
    9466:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    946d:	00 00 00 
    9470:	8b 48 04             	mov    0x4(%rax),%ecx
    9473:	85 c9                	test   %ecx,%ecx
    9475:	75 0c                	jne    9483 <fwp_hof0.constprop.0+0x233>
    9477:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    947d:	0f 86 9d 10 00 00    	jbe    a520 <fwp_hof0.constprop.0+0x12d0>
    9483:	48 83 c2 01          	add    $0x1,%rdx
    9487:	48 83 c0 68          	add    $0x68,%rax
    948b:	48 39 d5             	cmp    %rdx,%rbp
    948e:	75 e0                	jne    9470 <fwp_hof0.constprop.0+0x220>
    9490:	48 81 fd fe ff 00 00 	cmp    $0xfffe,%rbp
    9497:	0f 8f 3f 16 00 00    	jg     aadc <fwp_hof0.constprop.0+0x188c>
    949d:	48 39 2d 3c 9c 01 00 	cmp    %rbp,0x19c3c(%rip)        # 230e0 <fwp_tapes_cap>
    94a4:	4c 8b 0d 45 9c 01 00 	mov    0x19c45(%rip),%r9        # 230f0 <fwp_tapes>
    94ab:	75 4c                	jne    94f9 <fwp_hof0.constprop.0+0x2a9>
    94ad:	48 85 ed             	test   %rbp,%rbp
    94b0:	0f 84 9a 13 00 00    	je     a850 <fwp_hof0.constprop.0+0x1600>
    94b6:	4c 8d 64 2d 00       	lea    0x0(%rbp,%rbp,1),%r12
    94bb:	b8 ff ff 00 00       	mov    $0xffff,%eax
    94c0:	49 39 c4             	cmp    %rax,%r12
    94c3:	4c 0f 4f e0          	cmovg  %rax,%r12
    94c7:	49 6b f4 68          	imul   $0x68,%r12,%rsi
    94cb:	4c 89 cf             	mov    %r9,%rdi
    94ce:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    94d4:	e8 f7 a0 ff ff       	call   35d0 <realloc@plt>
    94d9:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    94df:	48 85 c0             	test   %rax,%rax
    94e2:	49 89 c1             	mov    %rax,%r9
    94e5:	0f 84 fd 15 00 00    	je     aae8 <fwp_hof0.constprop.0+0x1898>
    94eb:	48 89 05 fe 9b 01 00 	mov    %rax,0x19bfe(%rip)        # 230f0 <fwp_tapes>
    94f2:	4c 89 25 e7 9b 01 00 	mov    %r12,0x19be7(%rip)        # 230e0 <fwp_tapes_cap>
    94f9:	48 6b cd 68          	imul   $0x68,%rbp,%rcx
    94fd:	31 c0                	xor    %eax,%eax
    94ff:	4c 8d 65 01          	lea    0x1(%rbp),%r12
    9503:	4c 01 c9             	add    %r9,%rcx
    9506:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    950a:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    9511:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    9515:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    951c:	00 
    951d:	48 29 f9             	sub    %rdi,%rcx
    9520:	83 c1 68             	add    $0x68,%ecx
    9523:	c1 e9 03             	shr    $0x3,%ecx
    9526:	f3 48 ab             	rep stos %rax,(%rdi)
    9529:	4c 89 25 b8 9b 01 00 	mov    %r12,0x19bb8(%rip)        # 230e8 <fwp_ntapes>
    9530:	48 6b cd 68          	imul   $0x68,%rbp,%rcx
    9534:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    9538:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    953d:	48 8d 3d de 5b 00 00 	lea    0x5bde(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    9544:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    9549:	4c 01 c9             	add    %r9,%rcx
    954c:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    9553:	00 
    9554:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    9559:	e8 42 9e ff ff       	call   33a0 <getenv@plt>
    955e:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9563:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    9568:	48 85 c0             	test   %rax,%rax
    956b:	66 0f 6f 44 24 20    	movdqa 0x20(%rsp),%xmm0
    9571:	0f 84 f9 0c 00 00    	je     a270 <fwp_hof0.constprop.0+0x1020>
    9577:	80 38 30             	cmpb   $0x30,(%rax)
    957a:	0f 85 f0 0c 00 00    	jne    a270 <fwp_hof0.constprop.0+0x1020>
    9580:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9584:	0f 85 e6 0c 00 00    	jne    a270 <fwp_hof0.constprop.0+0x1020>
    958a:	8b 01                	mov    (%rcx),%eax
    958c:	c7 41 04 01 00 00 00 	movl   $0x1,0x4(%rcx)
    9593:	4c 89 25 3e 9b 01 00 	mov    %r12,0x19b3e(%rip)        # 230d8 <fwp_tape_next_slot>
    959a:	44 8d 70 01          	lea    0x1(%rax),%r14d
    959e:	48 8b 05 eb 65 00 00 	mov    0x65eb(%rip),%rax        # fb90 <msg.4+0x20>
    95a5:	48 c7 41 50 00 00 00 	movq   $0x0,0x50(%rcx)
    95ac:	00 
    95ad:	44 89 31             	mov    %r14d,(%rcx)
    95b0:	48 89 41 58          	mov    %rax,0x58(%rcx)
    95b4:	48 8b 05 9d be 01 00 	mov    0x1be9d(%rip),%rax        # 25458 <fwp_cleanups>
    95bb:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
    95bf:	48 85 c0             	test   %rax,%rax
    95c2:	75 18                	jne    95dc <fwp_hof0.constprop.0+0x38c>
    95c4:	e9 b7 14 00 00       	jmp    aa80 <fwp_hof0.constprop.0+0x1830>
    95c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    95d0:	48 8b 00             	mov    (%rax),%rax
    95d3:	48 85 c0             	test   %rax,%rax
    95d6:	0f 84 a4 14 00 00    	je     aa80 <fwp_hof0.constprop.0+0x1830>
    95dc:	4c 39 78 08          	cmp    %r15,0x8(%rax)
    95e0:	75 ee                	jne    95d0 <fwp_hof0.constprop.0+0x380>
    95e2:	48 8b 78 10          	mov    0x10(%rax),%rdi
    95e6:	89 ee                	mov    %ebp,%esi
    95e8:	48 63 07             	movslq (%rdi),%rax
    95eb:	48 89 79 50          	mov    %rdi,0x50(%rcx)
    95ef:	89 41 5c             	mov    %eax,0x5c(%rcx)
    95f2:	85 c0                	test   %eax,%eax
    95f4:	78 09                	js     95ff <fwp_hof0.constprop.0+0x3af>
    95f6:	48 6b c0 68          	imul   $0x68,%rax,%rax
    95fa:	41 89 6c 01 58       	mov    %ebp,0x58(%r9,%rax,1)
    95ff:	89 37                	mov    %esi,(%rdi)
    9601:	bf 01 00 00 00       	mov    $0x1,%edi
    9606:	31 ed                	xor    %ebp,%ebp
    9608:	e8 43 ac ff ff       	call   4250 <descent_phase_step>
    960d:	48 8b 3c 24          	mov    (%rsp),%rdi
    9611:	48 89 f8             	mov    %rdi,%rax
    9614:	48 85 ff             	test   %rdi,%rdi
    9617:	0f 84 b3 0d 00 00    	je     a3d0 <fwp_hof0.constprop.0+0x1180>
    961d:	0f 1f 00             	nopl   (%rax)
    9620:	48 8b 40 10          	mov    0x10(%rax),%rax
    9624:	48 83 c5 01          	add    $0x1,%rbp
    9628:	48 85 c0             	test   %rax,%rax
    962b:	75 f3                	jne    9620 <fwp_hof0.constprop.0+0x3d0>
    962d:	48 8b 0c 24          	mov    (%rsp),%rcx
    9631:	0f 1f 40 00          	nopl   0x0(%rax)
    9635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    963c:	00 00 00 00 
    9640:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9644:	48 83 c0 01          	add    $0x1,%rax
    9648:	48 85 c9             	test   %rcx,%rcx
    964b:	75 f3                	jne    9640 <fwp_hof0.constprop.0+0x3f0>
    964d:	48 b9 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rcx
    9654:	ff ff 1f 
    9657:	48 39 c1             	cmp    %rax,%rcx
    965a:	0f 82 12 14 00 00    	jb     aa72 <fwp_hof0.constprop.0+0x1822>
    9660:	48 85 ed             	test   %rbp,%rbp
    9663:	0f 8e 67 0d 00 00    	jle    a3d0 <fwp_hof0.constprop.0+0x1180>
    9669:	48 39 c5             	cmp    %rax,%rbp
    966c:	48 0f 47 e8          	cmova  %rax,%rbp
    9670:	48 89 e8             	mov    %rbp,%rax
    9673:	48 c1 e8 3c          	shr    $0x3c,%rax
    9677:	0f 85 f5 13 00 00    	jne    aa72 <fwp_hof0.constprop.0+0x1822>
    967d:	44 89 f2             	mov    %r14d,%edx
    9680:	4c 8d 7c 2d 00       	lea    0x0(%rbp,%rbp,1),%r15
    9685:	be 02 00 00 00       	mov    $0x2,%esi
    968a:	48 c1 e2 10          	shl    $0x10,%rdx
    968e:	4a 8d 3c fd 08 00 00 	lea    0x8(,%r15,8),%rdi
    9695:	00 
    9696:	4c 09 e2             	or     %r12,%rdx
    9699:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    969e:	e8 ed c5 ff ff       	call   5c90 <fwp_heap_alloc>
    96a3:	4c 89 38             	mov    %r15,(%rax)
    96a6:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    96ad:	49 89 c6             	mov    %rax,%r14
    96b0:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    96b7:	48 c1 e2 10          	shl    $0x10,%rdx
    96bb:	48 39 d0             	cmp    %rdx,%rax
    96be:	0f 83 fc 10 00 00    	jae    a7c0 <fwp_hof0.constprop.0+0x1570>
    96c4:	48 89 c2             	mov    %rax,%rdx
    96c7:	48 c1 ea 10          	shr    $0x10,%rdx
    96cb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    96cf:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    96d6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    96da:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    96de:	4d 85 ff             	test   %r15,%r15
    96e1:	74 38                	je     971b <fwp_hof0.constprop.0+0x4cb>
    96e3:	0f b6 0a             	movzbl (%rdx),%ecx
    96e6:	80 f9 02             	cmp    $0x2,%cl
    96e9:	0f 84 55 0d 00 00    	je     a444 <fwp_hof0.constprop.0+0x11f4>
    96ef:	80 f9 01             	cmp    $0x1,%cl
    96f2:	75 27                	jne    971b <fwp_hof0.constprop.0+0x4cb>
    96f4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    96f7:	0f b7 c0             	movzwl %ax,%eax
    96fa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    96fd:	48 0f af c1          	imul   %rcx,%rax
    9701:	48 c1 e8 20          	shr    $0x20,%rax
    9705:	48 39 d0             	cmp    %rdx,%rax
    9708:	73 11                	jae    971b <fwp_hof0.constprop.0+0x4cb>
    970a:	49 01 c7             	add    %rax,%r15
    970d:	41 80 3f ff          	cmpb   $0xff,(%r15)
    9711:	0f 84 40 0d 00 00    	je     a457 <fwp_hof0.constprop.0+0x1207>
    9717:	41 c6 07 01          	movb   $0x1,(%r15)
    971b:	48 85 ed             	test   %rbp,%rbp
    971e:	74 54                	je     9774 <fwp_hof0.constprop.0+0x524>
    9720:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9725:	48 8b 14 24          	mov    (%rsp),%rdx
    9729:	31 c0                	xor    %eax,%eax
    972b:	48 c1 e1 20          	shl    $0x20,%rcx
    972f:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9735:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    973c:	00 00 00 00 
    9740:	48 89 c6             	mov    %rax,%rsi
    9743:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    9748:	48 01 ce             	add    %rcx,%rsi
    974b:	0f 80 ff 9f ff ff    	jo     3750 <fwp_hof0.constprop.0.cold+0x5>
    9751:	66 48 0f 6e de       	movq   %rsi,%xmm3
    9756:	48 89 c6             	mov    %rax,%rsi
    9759:	48 83 c0 01          	add    $0x1,%rax
    975d:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    9761:	48 c1 e6 04          	shl    $0x4,%rsi
    9765:	41 0f 11 44 36 08    	movups %xmm0,0x8(%r14,%rsi,1)
    976b:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    976f:	48 39 e8             	cmp    %rbp,%rax
    9772:	72 cc                	jb     9740 <fwp_hof0.constprop.0+0x4f0>
    9774:	49 8b 06             	mov    (%r14),%rax
    9777:	48 d1 e8             	shr    $1,%rax
    977a:	0f 85 00 0d 00 00    	jne    a480 <fwp_hof0.constprop.0+0x1230>
    9780:	49 c7 06 00 00 00 00 	movq   $0x0,(%r14)
    9787:	49 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%r9
    978e:	66 90                	xchg   %ax,%ax
    9790:	4c 89 f7             	mov    %r14,%rdi
    9793:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    9798:	e8 d3 e2 ff ff       	call   7a70 <fwp_drop10>
    979d:	bf 02 00 00 00       	mov    $0x2,%edi
    97a2:	e8 a9 aa ff ff       	call   4250 <descent_phase_step>
    97a7:	4c 63 7c 24 08       	movslq 0x8(%rsp),%r15
    97ac:	4c 89 ff             	mov    %r15,%rdi
    97af:	e8 1c af ff ff       	call   46d0 <fwp_tape_of>
    97b4:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    97b9:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    97be:	48 89 c6             	mov    %rax,%rsi
    97c1:	0f 85 4f 13 00 00    	jne    ab16 <fwp_hof0.constprop.0+0x18c6>
    97c7:	48 89 c7             	mov    %rax,%rdi
    97ca:	e8 31 a4 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    97cf:	f3 0f 6f 76 20       	movdqu 0x20(%rsi),%xmm6
    97d4:	48 8b 6e 48          	mov    0x48(%rsi),%rbp
    97d8:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    97df:	f3 0f 6f 7e 30       	movdqu 0x30(%rsi),%xmm7
    97e4:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    97e9:	0f 29 74 24 20       	movaps %xmm6,0x20(%rsp)
    97ee:	66 48 0f 6e f5       	movq   %rbp,%xmm6
    97f3:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    97f7:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    97fb:	48 8b 4e 40          	mov    0x40(%rsi),%rcx
    97ff:	0f 29 7c 24 10       	movaps %xmm7,0x10(%rsp)
    9804:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    9808:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    980e:	77 1a                	ja     982a <fwp_hof0.constprop.0+0x5da>
    9810:	0f b7 44 24 08       	movzwl 0x8(%rsp),%eax
    9815:	83 e8 01             	sub    $0x1,%eax
    9818:	48 98                	cltq
    981a:	48 3b 05 b7 98 01 00 	cmp    0x198b7(%rip),%rax        # 230d8 <fwp_tape_next_slot>
    9821:	7d 07                	jge    982a <fwp_hof0.constprop.0+0x5da>
    9823:	48 89 05 ae 98 01 00 	mov    %rax,0x198ae(%rip)        # 230d8 <fwp_tape_next_slot>
    982a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    982e:	48 8b 05 23 bc 01 00 	mov    0x1bc23(%rip),%rax        # 25458 <fwp_cleanups>
    9835:	66 0f 6f 7c 24 20    	movdqa 0x20(%rsp),%xmm7
    983b:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    9842:	00 
    9843:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    9847:	66 0f 6f 74 24 10    	movdqa 0x10(%rsp),%xmm6
    984d:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    9854:	00 
    9855:	48 8d 05 14 b8 ff ff 	lea    -0x47ec(%rip),%rax        # 5070 <fwp_tape_buffers_release>
    985c:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    9863:	00 
    9864:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
    986b:	00 
    986c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    9871:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    9878:	00 
    9879:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    9880:	00 
    9881:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    9888:	00 
    9889:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    9890:	00 
    9891:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    9895:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    9899:	48 89 05 b8 bb 01 00 	mov    %rax,0x1bbb8(%rip)        # 25458 <fwp_cleanups>
    98a0:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
    98a7:	00 
    98a8:	0f 29 bc 24 b0 00 00 	movaps %xmm7,0xb0(%rsp)
    98af:	00 
    98b0:	0f 29 b4 24 c0 00 00 	movaps %xmm6,0xc0(%rsp)
    98b7:	00 
    98b8:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
    98bf:	00 
    98c0:	4d 85 c9             	test   %r9,%r9
    98c3:	0f 88 d7 0d 00 00    	js     a6a0 <fwp_hof0.constprop.0+0x1450>
    98c9:	4c 89 c8             	mov    %r9,%rax
    98cc:	48 c1 f8 20          	sar    $0x20,%rax
    98d0:	49 39 c7             	cmp    %rax,%r15
    98d3:	0f 85 55 11 00 00    	jne    aa2e <fwp_hof0.constprop.0+0x17de>
    98d9:	45 89 cb             	mov    %r9d,%r11d
    98dc:	4d 89 df             	mov    %r11,%r15
    98df:	4c 39 da             	cmp    %r11,%rdx
    98e2:	0f 8e 52 11 00 00    	jle    aa3a <fwp_hof0.constprop.0+0x17ea>
    98e8:	4d 39 de             	cmp    %r11,%r14
    98eb:	0f 8e 6f 0c 00 00    	jle    a560 <fwp_hof0.constprop.0+0x1310>
    98f1:	49 39 ee             	cmp    %rbp,%r14
    98f4:	0f 8f a6 0c 00 00    	jg     a5a0 <fwp_hof0.constprop.0+0x1350>
    98fa:	48 85 c9             	test   %rcx,%rcx
    98fd:	0f 84 92 11 00 00    	je     aa95 <fwp_hof0.constprop.0+0x1845>
    9903:	48 89 cf             	mov    %rcx,%rdi
    9906:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    990d:	00 
    990e:	31 f6                	xor    %esi,%esi
    9910:	31 ed                	xor    %ebp,%ebp
    9912:	4c 89 5c 24 08       	mov    %r11,0x8(%rsp)
    9917:	4d 8d 7e ff          	lea    -0x1(%r14),%r15
    991b:	e8 a0 9b ff ff       	call   34c0 <memset@plt>
    9920:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    9925:	48 89 c1             	mov    %rax,%rcx
    9928:	f2 0f 10 05 68 62 00 	movsd  0x6268(%rip),%xmm0        # fb98 <msg.4+0x28>
    992f:	00 
    9930:	f2 42 0f 58 04 d9    	addsd  (%rcx,%r11,8),%xmm0
    9936:	f2 42 0f 11 04 d9    	movsd  %xmm0,(%rcx,%r11,8)
    993c:	bf 03 00 00 00       	mov    $0x3,%edi
    9941:	4c 01 35 b8 97 01 00 	add    %r14,0x197b8(%rip)        # 23100 <descent_inputs>
    9948:	48 01 2d b9 97 01 00 	add    %rbp,0x197b9(%rip)        # 23108 <descent_nodes>
    994f:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    9954:	e8 f7 a8 ff ff       	call   4250 <descent_phase_step>
    9959:	4d 39 f7             	cmp    %r14,%r15
    995c:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9961:	0f 8c 8b 00 00 00    	jl     99f2 <fwp_hof0.constprop.0+0x7a2>
    9967:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    996c:	4d 29 f7             	sub    %r14,%r15
    996f:	4a 8d 2c f1          	lea    (%rcx,%r14,8),%rbp
    9973:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9977:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    997c:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
    9981:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    9986:	4b 8d 14 fb          	lea    (%r11,%r15,8),%rdx
    998a:	4c 29 dd             	sub    %r11,%rbp
    998d:	4a 8d 04 bf          	lea    (%rdi,%r15,4),%rax
    9991:	48 29 fe             	sub    %rdi,%rsi
    9994:	4d 29 d9             	sub    %r11,%r9
    9997:	eb 0b                	jmp    99a4 <fwp_hof0.constprop.0+0x754>
    9999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    99a0:	48 83 e8 04          	sub    $0x4,%rax
    99a4:	f2 0f 10 44 15 00    	movsd  0x0(%rbp,%rdx,1),%xmm0
    99aa:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    99ae:	7a 02                	jp     99b2 <fwp_hof0.constprop.0+0x762>
    99b0:	74 37                	je     99e9 <fwp_hof0.constprop.0+0x799>
    99b2:	4c 63 04 06          	movslq (%rsi,%rax,1),%r8
    99b6:	45 85 c0             	test   %r8d,%r8d
    99b9:	78 16                	js     99d1 <fwp_hof0.constprop.0+0x781>
    99bb:	f2 41 0f 10 0c 11    	movsd  (%r9,%rdx,1),%xmm1
    99c1:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    99c5:	f2 42 0f 58 0c c1    	addsd  (%rcx,%r8,8),%xmm1
    99cb:	f2 42 0f 11 0c c1    	movsd  %xmm1,(%rcx,%r8,8)
    99d1:	4c 63 00             	movslq (%rax),%r8
    99d4:	45 85 c0             	test   %r8d,%r8d
    99d7:	78 10                	js     99e9 <fwp_hof0.constprop.0+0x799>
    99d9:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    99dd:	f2 42 0f 58 04 c1    	addsd  (%rcx,%r8,8),%xmm0
    99e3:	f2 42 0f 11 04 c1    	movsd  %xmm0,(%rcx,%r8,8)
    99e9:	48 83 ea 08          	sub    $0x8,%rdx
    99ed:	48 39 c7             	cmp    %rax,%rdi
    99f0:	75 ae                	jne    99a0 <fwp_hof0.constprop.0+0x750>
    99f2:	bf 04 00 00 00       	mov    $0x4,%edi
    99f7:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    99fc:	e8 4f a8 ff ff       	call   4250 <descent_phase_step>
    9a01:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9a08:	ff ff 1f 
    9a0b:	4c 39 f0             	cmp    %r14,%rax
    9a0e:	0f 82 52 10 00 00    	jb     aa66 <fwp_hof0.constprop.0+0x1816>
    9a14:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    9a1b:	00 
    9a1c:	be 02 00 00 00       	mov    $0x2,%esi
    9a21:	e8 6a c2 ff ff       	call   5c90 <fwp_heap_alloc>
    9a26:	4d 85 f6             	test   %r14,%r14
    9a29:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9a2e:	4c 89 30             	mov    %r14,(%rax)
    9a31:	49 89 c7             	mov    %rax,%r15
    9a34:	74 1c                	je     9a52 <fwp_hof0.constprop.0+0x802>
    9a36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9a3d:	00 00 00 
    9a40:	4a 8b 04 e9          	mov    (%rcx,%r13,8),%rax
    9a44:	4b 89 44 ef 08       	mov    %rax,0x8(%r15,%r13,8)
    9a49:	49 83 c5 01          	add    $0x1,%r13
    9a4d:	4d 39 ee             	cmp    %r13,%r14
    9a50:	75 ee                	jne    9a40 <fwp_hof0.constprop.0+0x7f0>
    9a52:	bf 05 00 00 00       	mov    $0x5,%edi
    9a57:	e8 f4 a7 ff ff       	call   4250 <descent_phase_step>
    9a5c:	4c 8b a4 24 90 00 00 	mov    0x90(%rsp),%r12
    9a63:	00 
    9a64:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    9a69:	4c 89 25 e8 b9 01 00 	mov    %r12,0x1b9e8(%rip)        # 25458 <fwp_cleanups>
    9a70:	e8 fb b5 ff ff       	call   5070 <fwp_tape_buffers_release>
    9a75:	bf 06 00 00 00       	mov    $0x6,%edi
    9a7a:	e8 d1 a7 ff ff       	call   4250 <descent_phase_step>
    9a7f:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9a86:	4c 89 f8             	mov    %r15,%rax
    9a89:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9a90:	48 c1 e2 10          	shl    $0x10,%rdx
    9a94:	48 39 d0             	cmp    %rdx,%rax
    9a97:	73 57                	jae    9af0 <fwp_hof0.constprop.0+0x8a0>
    9a99:	48 89 c2             	mov    %rax,%rdx
    9a9c:	48 c1 ea 10          	shr    $0x10,%rdx
    9aa0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9aa4:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    9aab:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9aaf:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9ab3:	48 85 ed             	test   %rbp,%rbp
    9ab6:	74 38                	je     9af0 <fwp_hof0.constprop.0+0x8a0>
    9ab8:	0f b6 0a             	movzbl (%rdx),%ecx
    9abb:	80 f9 02             	cmp    $0x2,%cl
    9abe:	0f 84 0c 0c 00 00    	je     a6d0 <fwp_hof0.constprop.0+0x1480>
    9ac4:	80 f9 01             	cmp    $0x1,%cl
    9ac7:	75 27                	jne    9af0 <fwp_hof0.constprop.0+0x8a0>
    9ac9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9acc:	0f b7 c0             	movzwl %ax,%eax
    9acf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9ad2:	48 0f af c1          	imul   %rcx,%rax
    9ad6:	48 c1 e8 20          	shr    $0x20,%rax
    9ada:	48 39 d0             	cmp    %rdx,%rax
    9add:	73 11                	jae    9af0 <fwp_hof0.constprop.0+0x8a0>
    9adf:	48 01 c5             	add    %rax,%rbp
    9ae2:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9ae6:	0f 84 f7 0b 00 00    	je     a6e3 <fwp_hof0.constprop.0+0x1493>
    9aec:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    9af0:	4c 3b 64 24 48       	cmp    0x48(%rsp),%r12
    9af5:	0f 85 50 9c ff ff    	jne    374b <fwp_hof0.constprop.0.cold>
    9afb:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    9b00:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    9b05:	48 89 05 4c b9 01 00 	mov    %rax,0x1b94c(%rip)        # 25458 <fwp_cleanups>
    9b0c:	e8 2f d0 ff ff       	call   6b40 <fwp_tape_scope_release>
    9b11:	49 8b 07             	mov    (%r15),%rax
    9b14:	49 89 c6             	mov    %rax,%r14
    9b17:	49 0f ba f6 3f       	btr    $0x3f,%r14
    9b1c:	48 85 c0             	test   %rax,%rax
    9b1f:	0f 88 db 07 00 00    	js     a300 <fwp_hof0.constprop.0+0x10b0>
    9b25:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9b2c:	4c 89 f8             	mov    %r15,%rax
    9b2f:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9b36:	48 c1 e2 10          	shl    $0x10,%rdx
    9b3a:	48 39 d0             	cmp    %rdx,%rax
    9b3d:	0f 83 bd 07 00 00    	jae    a300 <fwp_hof0.constprop.0+0x10b0>
    9b43:	48 89 c2             	mov    %rax,%rdx
    9b46:	48 c1 ea 10          	shr    $0x10,%rdx
    9b4a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9b4e:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    9b55:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9b59:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    9b5d:	48 85 c9             	test   %rcx,%rcx
    9b60:	0f 84 9a 07 00 00    	je     a300 <fwp_hof0.constprop.0+0x10b0>
    9b66:	0f b6 32             	movzbl (%rdx),%esi
    9b69:	40 80 fe 02          	cmp    $0x2,%sil
    9b6d:	0f 84 7d 07 00 00    	je     a2f0 <fwp_hof0.constprop.0+0x10a0>
    9b73:	40 80 fe 01          	cmp    $0x1,%sil
    9b77:	0f 85 83 07 00 00    	jne    a300 <fwp_hof0.constprop.0+0x10b0>
    9b7d:	8b 72 18             	mov    0x18(%rdx),%esi
    9b80:	0f b7 c0             	movzwl %ax,%eax
    9b83:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9b86:	48 0f af c6          	imul   %rsi,%rax
    9b8a:	48 c1 e8 20          	shr    $0x20,%rax
    9b8e:	48 39 d0             	cmp    %rdx,%rax
    9b91:	0f 83 69 07 00 00    	jae    a300 <fwp_hof0.constprop.0+0x10b0>
    9b97:	48 01 c1             	add    %rax,%rcx
    9b9a:	80 39 01             	cmpb   $0x1,(%rcx)
    9b9d:	0f 85 5d 07 00 00    	jne    a300 <fwp_hof0.constprop.0+0x10b0>
    9ba3:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
    9ba8:	4d 89 fc             	mov    %r15,%r12
    9bab:	31 ff                	xor    %edi,%edi
    9bad:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9bb2:	48 8d 50 08          	lea    0x8(%rax),%rdx
    9bb6:	31 c0                	xor    %eax,%eax
    9bb8:	4d 85 f6             	test   %r14,%r14
    9bbb:	75 2d                	jne    9bea <fwp_hof0.constprop.0+0x99a>
    9bbd:	eb 41                	jmp    9c00 <fwp_hof0.constprop.0+0x9b0>
    9bbf:	90                   	nop
    9bc0:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    9bc5:	0f 88 7b 0e 00 00    	js     aa46 <fwp_hof0.constprop.0+0x17f6>
    9bcb:	f2 0f 10 05 dd 5f 00 	movsd  0x5fdd(%rip),%xmm0        # fbb0 <msg.4+0x40>
    9bd2:	00 
    9bd3:	f2 0f 59 04 c1       	mulsd  (%rcx,%rax,8),%xmm0
    9bd8:	48 83 c0 01          	add    $0x1,%rax
    9bdc:	48 83 c2 08          	add    $0x8,%rdx
    9be0:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    9be5:	49 39 c6             	cmp    %rax,%r14
    9be8:	74 16                	je     9c00 <fwp_hof0.constprop.0+0x9b0>
    9bea:	49 8d 4f 08          	lea    0x8(%r15),%rcx
    9bee:	49 83 3f 00          	cmpq   $0x0,(%r15)
    9bf2:	79 cc                	jns    9bc0 <fwp_hof0.constprop.0+0x970>
    9bf4:	49 8b 4f 10          	mov    0x10(%r15),%rcx
    9bf8:	eb c6                	jmp    9bc0 <fwp_hof0.constprop.0+0x970>
    9bfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9c00:	e8 6b de ff ff       	call   7a70 <fwp_drop10>
    9c05:	48 8b 3c 24          	mov    (%rsp),%rdi
    9c09:	31 d2                	xor    %edx,%edx
    9c0b:	48 89 f8             	mov    %rdi,%rax
    9c0e:	48 85 ff             	test   %rdi,%rdi
    9c11:	0f 84 59 0c 00 00    	je     a870 <fwp_hof0.constprop.0+0x1620>
    9c17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9c1e:	00 00 
    9c20:	48 8b 40 10          	mov    0x10(%rax),%rax
    9c24:	48 83 c2 01          	add    $0x1,%rdx
    9c28:	48 85 c0             	test   %rax,%rax
    9c2b:	75 f3                	jne    9c20 <fwp_hof0.constprop.0+0x9d0>
    9c2d:	49 8b 04 24          	mov    (%r12),%rax
    9c31:	49 89 c7             	mov    %rax,%r15
    9c34:	49 0f ba f7 3f       	btr    $0x3f,%r15
    9c39:	48 85 c0             	test   %rax,%rax
    9c3c:	0f 88 9a 05 00 00    	js     a1dc <fwp_hof0.constprop.0+0xf8c>
    9c42:	48 8b 83 d8 13 00 00 	mov    0x13d8(%rbx),%rax
    9c49:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9c4e:	48 2b 8b b0 13 00 00 	sub    0x13b0(%rbx),%rcx
    9c55:	48 c1 e0 10          	shl    $0x10,%rax
    9c59:	48 39 c1             	cmp    %rax,%rcx
    9c5c:	0f 83 7a 05 00 00    	jae    a1dc <fwp_hof0.constprop.0+0xf8c>
    9c62:	48 89 c8             	mov    %rcx,%rax
    9c65:	48 c1 e8 10          	shr    $0x10,%rax
    9c69:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    9c6d:	48 8b 83 f8 13 00 00 	mov    0x13f8(%rbx),%rax
    9c74:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    9c78:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9c7c:	48 85 ff             	test   %rdi,%rdi
    9c7f:	0f 84 57 05 00 00    	je     a1dc <fwp_hof0.constprop.0+0xf8c>
    9c85:	0f b6 06             	movzbl (%rsi),%eax
    9c88:	3c 02                	cmp    $0x2,%al
    9c8a:	0f 84 38 05 00 00    	je     a1c8 <fwp_hof0.constprop.0+0xf78>
    9c90:	3c 01                	cmp    $0x1,%al
    9c92:	0f 85 39 05 00 00    	jne    a1d1 <fwp_hof0.constprop.0+0xf81>
    9c98:	8b 46 18             	mov    0x18(%rsi),%eax
    9c9b:	0f b7 c9             	movzwl %cx,%ecx
    9c9e:	48 0f af c8          	imul   %rax,%rcx
    9ca2:	8b 46 1c             	mov    0x1c(%rsi),%eax
    9ca5:	48 c1 e9 20          	shr    $0x20,%rcx
    9ca9:	48 39 c1             	cmp    %rax,%rcx
    9cac:	0f 83 1f 05 00 00    	jae    a1d1 <fwp_hof0.constprop.0+0xf81>
    9cb2:	48 01 cf             	add    %rcx,%rdi
    9cb5:	80 3f 01             	cmpb   $0x1,(%rdi)
    9cb8:	0f 85 13 05 00 00    	jne    a1d1 <fwp_hof0.constprop.0+0xf81>
    9cbe:	49 39 d7             	cmp    %rdx,%r15
    9cc1:	48 89 d0             	mov    %rdx,%rax
    9cc4:	49 0f 46 c7          	cmovbe %r15,%rax
    9cc8:	48 85 c0             	test   %rax,%rax
    9ccb:	0f 84 81 0d 00 00    	je     aa52 <fwp_hof0.constprop.0+0x1802>
    9cd1:	c7 44 24 10 01 00 00 	movl   $0x1,0x10(%rsp)
    9cd8:	00 
    9cd9:	4d 8d 6c 24 08       	lea    0x8(%r12),%r13
    9cde:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    9ce3:	48 8b 0c 24          	mov    (%rsp),%rcx
    9ce7:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    9cee:	00 
    9cef:	31 d2                	xor    %edx,%edx
    9cf1:	49 8d 78 08          	lea    0x8(%r8),%rdi
    9cf5:	eb 27                	jmp    9d1e <fwp_hof0.constprop.0+0xace>
    9cf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9cfe:	00 00 
    9d00:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9d05:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    9d0a:	f2 41 0f 11 44 15 00 	movsd  %xmm0,0x0(%r13,%rdx,1)
    9d11:	48 83 c2 08          	add    $0x8,%rdx
    9d15:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9d19:	49 39 d1             	cmp    %rdx,%r9
    9d1c:	74 12                	je     9d30 <fwp_hof0.constprop.0+0xae0>
    9d1e:	48 89 fe             	mov    %rdi,%rsi
    9d21:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    9d26:	79 d8                	jns    9d00 <fwp_hof0.constprop.0+0xab0>
    9d28:	49 8b 70 10          	mov    0x10(%r8),%rsi
    9d2c:	eb d2                	jmp    9d00 <fwp_hof0.constprop.0+0xab0>
    9d2e:	66 90                	xchg   %ax,%ax
    9d30:	48 8b 0c 24          	mov    (%rsp),%rcx
    9d34:	48 85 c9             	test   %rcx,%rcx
    9d37:	0f 84 e9 0c 00 00    	je     aa26 <fwp_hof0.constprop.0+0x17d6>
    9d3d:	4c 8b 8b d8 13 00 00 	mov    0x13d8(%rbx),%r9
    9d44:	4c 8b 93 b0 13 00 00 	mov    0x13b0(%rbx),%r10
    9d4b:	45 31 ff             	xor    %r15d,%r15d
    9d4e:	4c 8b 9b f8 13 00 00 	mov    0x13f8(%rbx),%r11
    9d55:	49 c1 e1 10          	shl    $0x10,%r9
    9d59:	eb 1b                	jmp    9d76 <fwp_hof0.constprop.0+0xb26>
    9d5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9d60:	49 83 c7 01          	add    $0x1,%r15
    9d64:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9d68:	49 39 c7             	cmp    %rax,%r15
    9d6b:	0f 83 5f 01 00 00    	jae    9ed0 <fwp_hof0.constprop.0+0xc80>
    9d71:	48 85 c9             	test   %rcx,%rcx
    9d74:	74 56                	je     9dcc <fwp_hof0.constprop.0+0xb7c>
    9d76:	48 89 ca             	mov    %rcx,%rdx
    9d79:	4c 29 d2             	sub    %r10,%rdx
    9d7c:	4c 39 ca             	cmp    %r9,%rdx
    9d7f:	73 4b                	jae    9dcc <fwp_hof0.constprop.0+0xb7c>
    9d81:	48 89 d6             	mov    %rdx,%rsi
    9d84:	48 c1 ee 10          	shr    $0x10,%rsi
    9d88:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    9d8c:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    9d90:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9d94:	48 85 ff             	test   %rdi,%rdi
    9d97:	74 33                	je     9dcc <fwp_hof0.constprop.0+0xb7c>
    9d99:	44 0f b6 06          	movzbl (%rsi),%r8d
    9d9d:	41 80 f8 02          	cmp    $0x2,%r8b
    9da1:	0f 84 11 01 00 00    	je     9eb8 <fwp_hof0.constprop.0+0xc68>
    9da7:	41 80 f8 01          	cmp    $0x1,%r8b
    9dab:	75 1f                	jne    9dcc <fwp_hof0.constprop.0+0xb7c>
    9dad:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    9db1:	0f b7 d2             	movzwl %dx,%edx
    9db4:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9db7:	49 0f af d0          	imul   %r8,%rdx
    9dbb:	48 c1 ea 20          	shr    $0x20,%rdx
    9dbf:	48 39 f2             	cmp    %rsi,%rdx
    9dc2:	73 08                	jae    9dcc <fwp_hof0.constprop.0+0xb7c>
    9dc4:	48 01 d7             	add    %rdx,%rdi
    9dc7:	80 3f 01             	cmpb   $0x1,(%rdi)
    9dca:	74 94                	je     9d60 <fwp_hof0.constprop.0+0xb10>
    9dcc:	49 39 c7             	cmp    %rax,%r15
    9dcf:	0f 83 fb 00 00 00    	jae    9ed0 <fwp_hof0.constprop.0+0xc80>
    9dd5:	48 89 c5             	mov    %rax,%rbp
    9dd8:	45 31 f6             	xor    %r14d,%r14d
    9ddb:	eb 37                	jmp    9e14 <fwp_hof0.constprop.0+0xbc4>
    9ddd:	0f 1f 00             	nopl   (%rax)
    9de0:	40 80 fe 01          	cmp    $0x1,%sil
    9de4:	75 25                	jne    9e0b <fwp_hof0.constprop.0+0xbbb>
    9de6:	8b 71 18             	mov    0x18(%rcx),%esi
    9de9:	0f b7 c0             	movzwl %ax,%eax
    9dec:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9def:	48 0f af c6          	imul   %rsi,%rax
    9df3:	48 c1 e8 20          	shr    $0x20,%rax
    9df7:	48 39 c8             	cmp    %rcx,%rax
    9dfa:	73 0f                	jae    9e0b <fwp_hof0.constprop.0+0xbbb>
    9dfc:	48 01 c2             	add    %rax,%rdx
    9dff:	80 3a ff             	cmpb   $0xff,(%rdx)
    9e02:	0f 84 a8 05 00 00    	je     a3b0 <fwp_hof0.constprop.0+0x1160>
    9e08:	c6 02 01             	movb   $0x1,(%rdx)
    9e0b:	49 39 ef             	cmp    %rbp,%r15
    9e0e:	0f 83 8c 00 00 00    	jae    9ea0 <fwp_hof0.constprop.0+0xc50>
    9e14:	48 83 ed 01          	sub    $0x1,%rbp
    9e18:	66 49 0f 6e ee       	movq   %r14,%xmm5
    9e1d:	bf 01 00 00 00       	mov    $0x1,%edi
    9e22:	f3 41 0f 7e 44 ed 00 	movq   0x0(%r13,%rbp,8),%xmm0
    9e29:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    9e30:	00 
    9e31:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    9e35:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
    9e3c:	00 
    9e3d:	e8 6e bf ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    9e42:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9e49:	49 89 c6             	mov    %rax,%r14
    9e4c:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9e53:	48 c1 e2 10          	shl    $0x10,%rdx
    9e57:	48 39 d0             	cmp    %rdx,%rax
    9e5a:	73 af                	jae    9e0b <fwp_hof0.constprop.0+0xbbb>
    9e5c:	48 89 c2             	mov    %rax,%rdx
    9e5f:	48 c1 ea 10          	shr    $0x10,%rdx
    9e63:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9e67:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    9e6e:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    9e72:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    9e76:	48 85 d2             	test   %rdx,%rdx
    9e79:	74 90                	je     9e0b <fwp_hof0.constprop.0+0xbbb>
    9e7b:	0f b6 31             	movzbl (%rcx),%esi
    9e7e:	40 80 fe 02          	cmp    $0x2,%sil
    9e82:	0f 85 58 ff ff ff    	jne    9de0 <fwp_hof0.constprop.0+0xb90>
    9e88:	66 85 c0             	test   %ax,%ax
    9e8b:	0f 84 6e ff ff ff    	je     9dff <fwp_hof0.constprop.0+0xbaf>
    9e91:	49 39 ef             	cmp    %rbp,%r15
    9e94:	0f 82 7a ff ff ff    	jb     9e14 <fwp_hof0.constprop.0+0xbc4>
    9e9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ea0:	4d 85 ff             	test   %r15,%r15
    9ea3:	75 2e                	jne    9ed3 <fwp_hof0.constprop.0+0xc83>
    9ea5:	8b 44 24 10          	mov    0x10(%rsp),%eax
    9ea9:	85 c0                	test   %eax,%eax
    9eab:	4d 0f 45 ef          	cmovne %r15,%r13
    9eaf:	eb 61                	jmp    9f12 <fwp_hof0.constprop.0+0xcc2>
    9eb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9eb8:	66 85 d2             	test   %dx,%dx
    9ebb:	0f 84 06 ff ff ff    	je     9dc7 <fwp_hof0.constprop.0+0xb77>
    9ec1:	49 39 c7             	cmp    %rax,%r15
    9ec4:	0f 82 0b ff ff ff    	jb     9dd5 <fwp_hof0.constprop.0+0xb85>
    9eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ed0:	45 31 f6             	xor    %r14d,%r14d
    9ed3:	48 8b 04 24          	mov    (%rsp),%rax
    9ed7:	4c 89 ea             	mov    %r13,%rdx
    9eda:	4f 8d 4c fd 00       	lea    0x0(%r13,%r15,8),%r9
    9edf:	90                   	nop
    9ee0:	48 8b 0a             	mov    (%rdx),%rcx
    9ee3:	48 83 c2 08          	add    $0x8,%rdx
    9ee7:	48 89 c7             	mov    %rax,%rdi
    9eea:	48 89 48 08          	mov    %rcx,0x8(%rax)
    9eee:	48 8b 40 10          	mov    0x10(%rax),%rax
    9ef2:	4c 39 ca             	cmp    %r9,%rdx
    9ef5:	75 e9                	jne    9ee0 <fwp_hof0.constprop.0+0xc90>
    9ef7:	8b 54 24 10          	mov    0x10(%rsp),%edx
    9efb:	4c 89 77 10          	mov    %r14,0x10(%rdi)
    9eff:	85 d2                	test   %edx,%edx
    9f01:	0f 84 e9 07 00 00    	je     a6f0 <fwp_hof0.constprop.0+0x14a0>
    9f07:	4c 8b 34 24          	mov    (%rsp),%r14
    9f0b:	48 89 04 24          	mov    %rax,(%rsp)
    9f0f:	45 31 ed             	xor    %r13d,%r13d
    9f12:	4c 89 ef             	mov    %r13,%rdi
    9f15:	e8 76 b8 ff ff       	call   5790 <fwp_mem_free>
    9f1a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9f1f:	e8 4c db ff ff       	call   7a70 <fwp_drop10>
    9f24:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9f2b:	48 8b 04 24          	mov    (%rsp),%rax
    9f2f:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9f36:	48 c1 e2 10          	shl    $0x10,%rdx
    9f3a:	48 39 d0             	cmp    %rdx,%rax
    9f3d:	73 71                	jae    9fb0 <fwp_hof0.constprop.0+0xd60>
    9f3f:	48 89 c2             	mov    %rax,%rdx
    9f42:	48 8b b3 f8 13 00 00 	mov    0x13f8(%rbx),%rsi
    9f49:	48 c1 ea 10          	shr    $0x10,%rdx
    9f4d:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    9f51:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    9f55:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9f59:	48 85 ed             	test   %rbp,%rbp
    9f5c:	74 52                	je     9fb0 <fwp_hof0.constprop.0+0xd60>
    9f5e:	0f b6 0a             	movzbl (%rdx),%ecx
    9f61:	80 f9 02             	cmp    $0x2,%cl
    9f64:	0f 84 16 07 00 00    	je     a680 <fwp_hof0.constprop.0+0x1430>
    9f6a:	80 f9 01             	cmp    $0x1,%cl
    9f6d:	75 41                	jne    9fb0 <fwp_hof0.constprop.0+0xd60>
    9f6f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9f72:	0f b7 c0             	movzwl %ax,%eax
    9f75:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f78:	48 0f af c1          	imul   %rcx,%rax
    9f7c:	48 c1 e8 20          	shr    $0x20,%rax
    9f80:	48 39 d0             	cmp    %rdx,%rax
    9f83:	73 2b                	jae    9fb0 <fwp_hof0.constprop.0+0xd60>
    9f85:	48 01 c5             	add    %rax,%rbp
    9f88:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    9f8c:	84 c0                	test   %al,%al
    9f8e:	74 20                	je     9fb0 <fwp_hof0.constprop.0+0xd60>
    9f90:	3c 01                	cmp    $0x1,%al
    9f92:	0f 84 68 07 00 00    	je     a700 <fwp_hof0.constprop.0+0x14b0>
    9f98:	3c ff                	cmp    $0xff,%al
    9f9a:	0f 84 3b 09 00 00    	je     a8db <fwp_hof0.constprop.0+0x168b>
    9fa0:	83 e8 01             	sub    $0x1,%eax
    9fa3:	88 45 00             	mov    %al,0x0(%rbp)
    9fa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9fad:	00 00 00 
    9fb0:	48 83 7c 24 38 00    	cmpq   $0x0,0x38(%rsp)
    9fb6:	0f 85 84 05 00 00    	jne    a540 <fwp_hof0.constprop.0+0x12f0>
    9fbc:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    9fc1:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9fc5:	4c 89 f6             	mov    %r14,%rsi
    9fc8:	4d 89 f4             	mov    %r14,%r12
    9fcb:	b9 01 00 00 00       	mov    $0x1,%ecx
    9fd0:	48 8d 15 a9 8b 00 00 	lea    0x8ba9(%rip),%rdx        # 12b80 <d0>
    9fd7:	48 c7 84 24 c0 00 00 	movq   $0x0,0xc0(%rsp)
    9fde:	00 00 00 00 00 
    9fe3:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
    9fea:	00 
    9feb:	e8 20 e2 ff ff       	call   8210 <fwp_write>
    9ff0:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
    9ff7:	00 
    9ff8:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
    9fff:	00 
    a000:	48 8d 05 8a 50 00 00 	lea    0x508a(%rip),%rax        # f091 <_IO_stdin_used+0x91>
    a007:	48 85 c9             	test   %rcx,%rcx
    a00a:	48 0f 44 c8          	cmove  %rax,%rcx
    a00e:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    a012:	0f 87 0f 0b 00 00    	ja     ab27 <fwp_hof0.constprop.0+0x18d7>
    a018:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    a01c:	be 01 00 00 00       	mov    $0x1,%esi
    a021:	48 89 0c 24          	mov    %rcx,(%rsp)
    a025:	e8 66 bc ff ff       	call   5c90 <fwp_heap_alloc>
    a02a:	48 8b 34 24          	mov    (%rsp),%rsi
    a02e:	4c 89 fa             	mov    %r15,%rdx
    a031:	4c 89 38             	mov    %r15,(%rax)
    a034:	4c 8d 70 08          	lea    0x8(%rax),%r14
    a038:	48 89 c5             	mov    %rax,%rbp
    a03b:	4c 89 f7             	mov    %r14,%rdi
    a03e:	e8 5d 95 ff ff       	call   35a0 <memcpy@plt>
    a043:	42 c6 44 3d 08 00    	movb   $0x0,0x8(%rbp,%r15,1)
    a049:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
    a050:	00 
    a051:	e8 6a 93 ff ff       	call   33c0 <free@plt>
    a056:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a05d:	48 89 e8             	mov    %rbp,%rax
    a060:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a067:	48 c1 e2 10          	shl    $0x10,%rdx
    a06b:	48 39 d0             	cmp    %rdx,%rax
    a06e:	73 57                	jae    a0c7 <fwp_hof0.constprop.0+0xe77>
    a070:	48 89 c2             	mov    %rax,%rdx
    a073:	48 c1 ea 10          	shr    $0x10,%rdx
    a077:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a07b:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    a082:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a086:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a08a:	4d 85 ff             	test   %r15,%r15
    a08d:	74 38                	je     a0c7 <fwp_hof0.constprop.0+0xe77>
    a08f:	0f b6 0a             	movzbl (%rdx),%ecx
    a092:	80 f9 02             	cmp    $0x2,%cl
    a095:	0f 84 65 07 00 00    	je     a800 <fwp_hof0.constprop.0+0x15b0>
    a09b:	80 f9 01             	cmp    $0x1,%cl
    a09e:	75 27                	jne    a0c7 <fwp_hof0.constprop.0+0xe77>
    a0a0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a0a3:	0f b7 c0             	movzwl %ax,%eax
    a0a6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a0a9:	48 0f af c1          	imul   %rcx,%rax
    a0ad:	48 c1 e8 20          	shr    $0x20,%rax
    a0b1:	48 39 d0             	cmp    %rdx,%rax
    a0b4:	73 11                	jae    a0c7 <fwp_hof0.constprop.0+0xe77>
    a0b6:	49 01 c7             	add    %rax,%r15
    a0b9:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a0bd:	0f 84 50 07 00 00    	je     a813 <fwp_hof0.constprop.0+0x15c3>
    a0c3:	41 c6 07 01          	movb   $0x1,(%r15)
    a0c7:	4c 89 e7             	mov    %r12,%rdi
    a0ca:	e8 b1 d5 ff ff       	call   7680 <fwp_drop0>
    a0cf:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    a0d3:	be 01 00 00 00       	mov    $0x1,%esi
    a0d8:	4c 89 f7             	mov    %r14,%rdi
    a0db:	48 8b 0d 3e b3 01 00 	mov    0x1b33e(%rip),%rcx        # 25420 <fwp_prog_out>
    a0e2:	e8 99 95 ff ff       	call   3680 <fwrite@plt>
    a0e7:	48 8b 35 32 b3 01 00 	mov    0x1b332(%rip),%rsi        # 25420 <fwp_prog_out>
    a0ee:	bf 0a 00 00 00       	mov    $0xa,%edi
    a0f3:	e8 e8 93 ff ff       	call   34e0 <fputc@plt>
    a0f8:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a0ff:	48 89 e8             	mov    %rbp,%rax
    a102:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a109:	48 c1 e2 10          	shl    $0x10,%rdx
    a10d:	48 39 d0             	cmp    %rdx,%rax
    a110:	73 6e                	jae    a180 <fwp_hof0.constprop.0+0xf30>
    a112:	48 89 c2             	mov    %rax,%rdx
    a115:	48 c1 ea 10          	shr    $0x10,%rdx
    a119:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a11d:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    a124:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a128:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a12c:	4d 85 e4             	test   %r12,%r12
    a12f:	74 4f                	je     a180 <fwp_hof0.constprop.0+0xf30>
    a131:	0f b6 0a             	movzbl (%rdx),%ecx
    a134:	80 f9 02             	cmp    $0x2,%cl
    a137:	0f 84 e3 06 00 00    	je     a820 <fwp_hof0.constprop.0+0x15d0>
    a13d:	80 f9 01             	cmp    $0x1,%cl
    a140:	75 3e                	jne    a180 <fwp_hof0.constprop.0+0xf30>
    a142:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a145:	0f b7 c0             	movzwl %ax,%eax
    a148:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a14b:	48 0f af c1          	imul   %rcx,%rax
    a14f:	48 c1 e8 20          	shr    $0x20,%rax
    a153:	48 39 d0             	cmp    %rdx,%rax
    a156:	73 28                	jae    a180 <fwp_hof0.constprop.0+0xf30>
    a158:	49 01 c4             	add    %rax,%r12
    a15b:	41 0f b6 04 24       	movzbl (%r12),%eax
    a160:	84 c0                	test   %al,%al
    a162:	74 1c                	je     a180 <fwp_hof0.constprop.0+0xf30>
    a164:	3c 01                	cmp    $0x1,%al
    a166:	0f 84 d2 06 00 00    	je     a83e <fwp_hof0.constprop.0+0x15ee>
    a16c:	3c ff                	cmp    $0xff,%al
    a16e:	0f 84 f1 07 00 00    	je     a965 <fwp_hof0.constprop.0+0x1715>
    a174:	83 e8 01             	sub    $0x1,%eax
    a177:	41 88 04 24          	mov    %al,(%r12)
    a17b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a180:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    a185:	48 8b 40 10          	mov    0x10(%rax),%rax
    a189:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    a18e:	48 85 c0             	test   %rax,%rax
    a191:	0f 85 f9 f0 ff ff    	jne    9290 <fwp_hof0.constprop.0+0x40>
    a197:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    a19e:	00 
    a19f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a1a6:	00 00 
    a1a8:	0f 85 74 09 00 00    	jne    ab22 <fwp_hof0.constprop.0+0x18d2>
    a1ae:	48 81 c4 18 01 00 00 	add    $0x118,%rsp
    a1b5:	31 c0                	xor    %eax,%eax
    a1b7:	5b                   	pop    %rbx
    a1b8:	5d                   	pop    %rbp
    a1b9:	41 5c                	pop    %r12
    a1bb:	41 5d                	pop    %r13
    a1bd:	41 5e                	pop    %r14
    a1bf:	41 5f                	pop    %r15
    a1c1:	c3                   	ret
    a1c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a1c8:	66 85 c9             	test   %cx,%cx
    a1cb:	0f 84 e4 fa ff ff    	je     9cb5 <fwp_hof0.constprop.0+0xa65>
    a1d1:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
    a1d6:	0f 84 88 02 00 00    	je     a464 <fwp_hof0.constprop.0+0x1214>
    a1dc:	48 8b 04 24          	mov    (%rsp),%rax
    a1e0:	45 31 f6             	xor    %r14d,%r14d
    a1e3:	66 90                	xchg   %ax,%ax
    a1e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a1ec:	00 00 00 00 
    a1f0:	48 8b 40 10          	mov    0x10(%rax),%rax
    a1f4:	4c 89 f2             	mov    %r14,%rdx
    a1f7:	49 83 c6 01          	add    $0x1,%r14
    a1fb:	48 85 c0             	test   %rax,%rax
    a1fe:	75 f0                	jne    a1f0 <fwp_hof0.constprop.0+0xfa0>
    a200:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a207:	ff ff 1f 
    a20a:	4c 39 f0             	cmp    %r14,%rax
    a20d:	0f 82 5f 08 00 00    	jb     aa72 <fwp_hof0.constprop.0+0x1822>
    a213:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    a21a:	00 
    a21b:	be 02 00 00 00       	mov    $0x2,%esi
    a220:	e8 6b ba ff ff       	call   5c90 <fwp_heap_alloc>
    a225:	4d 39 f7             	cmp    %r14,%r15
    a228:	48 8b 14 24          	mov    (%rsp),%rdx
    a22c:	49 89 c5             	mov    %rax,%r13
    a22f:	4c 89 f0             	mov    %r14,%rax
    a232:	49 0f 46 c7          	cmovbe %r15,%rax
    a236:	4c 89 e9             	mov    %r13,%rcx
    a239:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a240:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    a244:	48 83 c1 08          	add    $0x8,%rcx
    a248:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    a24c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a250:	48 85 d2             	test   %rdx,%rdx
    a253:	75 eb                	jne    a240 <fwp_hof0.constprop.0+0xff0>
    a255:	48 85 c0             	test   %rax,%rax
    a258:	0f 84 18 02 00 00    	je     a476 <fwp_hof0.constprop.0+0x1226>
    a25e:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
    a265:	00 
    a266:	e9 73 fa ff ff       	jmp    9cde <fwp_hof0.constprop.0+0xa8e>
    a26b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a270:	48 83 3d 10 8e 01 00 	cmpq   $0x0,0x18e10(%rip)        # 23088 <fwp_tape_cached_bytes>
    a277:	00 
    a278:	0f 84 0c f3 ff ff    	je     958a <fwp_hof0.constprop.0+0x33a>
    a27e:	66 0f 6f 0d 1a 8e 01 	movdqa 0x18e1a(%rip),%xmm1        # 230a0 <fwp_tape_workspace>
    a285:	00 
    a286:	48 c7 05 f7 8d 01 00 	movq   $0x0,0x18df7(%rip)        # 23088 <fwp_tape_cached_bytes>
    a28d:	00 00 00 00 
    a291:	0f 11 49 20          	movups %xmm1,0x20(%rcx)
    a295:	48 8b 05 24 8e 01 00 	mov    0x18e24(%rip),%rax        # 230c0 <fwp_tape_workspace+0x20>
    a29c:	66 0f 6f 0d 0c 8e 01 	movdqa 0x18e0c(%rip),%xmm1        # 230b0 <fwp_tape_workspace+0x10>
    a2a3:	00 
    a2a4:	48 89 41 40          	mov    %rax,0x40(%rcx)
    a2a8:	48 8b 05 19 8e 01 00 	mov    0x18e19(%rip),%rax        # 230c8 <fwp_tape_workspace+0x28>
    a2af:	0f 11 49 30          	movups %xmm1,0x30(%rcx)
    a2b3:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a2b7:	48 89 41 18          	mov    %rax,0x18(%rcx)
    a2bb:	48 8b 05 0e 8e 01 00 	mov    0x18e0e(%rip),%rax        # 230d0 <fwp_tape_workspace+0x30>
    a2c2:	0f 29 0d d7 8d 01 00 	movaps %xmm1,0x18dd7(%rip)        # 230a0 <fwp_tape_workspace>
    a2c9:	48 89 41 48          	mov    %rax,0x48(%rcx)
    a2cd:	0f 29 0d dc 8d 01 00 	movaps %xmm1,0x18ddc(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    a2d4:	48 c7 05 f1 8d 01 00 	movq   $0x0,0x18df1(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    a2db:	00 00 00 00 
    a2df:	0f 29 0d da 8d 01 00 	movaps %xmm1,0x18dda(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    a2e6:	e9 9f f2 ff ff       	jmp    958a <fwp_hof0.constprop.0+0x33a>
    a2eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a2f0:	66 85 c0             	test   %ax,%ax
    a2f3:	0f 84 a1 f8 ff ff    	je     9b9a <fwp_hof0.constprop.0+0x94a>
    a2f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a300:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a307:	ff ff 1f 
    a30a:	4c 39 f0             	cmp    %r14,%rax
    a30d:	0f 82 53 07 00 00    	jb     aa66 <fwp_hof0.constprop.0+0x1816>
    a313:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    a31a:	00 
    a31b:	be 01 00 00 00       	mov    $0x1,%esi
    a320:	e8 6b b9 ff ff       	call   5c90 <fwp_heap_alloc>
    a325:	4c 89 30             	mov    %r14,(%rax)
    a328:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a32f:	49 89 c4             	mov    %rax,%r12
    a332:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a337:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a33e:	48 c1 e2 10          	shl    $0x10,%rdx
    a342:	48 39 d0             	cmp    %rdx,%rax
    a345:	73 59                	jae    a3a0 <fwp_hof0.constprop.0+0x1150>
    a347:	48 89 c2             	mov    %rax,%rdx
    a34a:	48 c1 ea 10          	shr    $0x10,%rdx
    a34e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a352:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    a359:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a35d:	48 8b 69 20          	mov    0x20(%rcx),%rbp
    a361:	48 85 ed             	test   %rbp,%rbp
    a364:	74 3a                	je     a3a0 <fwp_hof0.constprop.0+0x1150>
    a366:	0f b6 31             	movzbl (%rcx),%esi
    a369:	40 80 fe 02          	cmp    $0x2,%sil
    a36d:	0f 84 2d 04 00 00    	je     a7a0 <fwp_hof0.constprop.0+0x1550>
    a373:	40 80 fe 01          	cmp    $0x1,%sil
    a377:	75 27                	jne    a3a0 <fwp_hof0.constprop.0+0x1150>
    a379:	8b 71 18             	mov    0x18(%rcx),%esi
    a37c:	0f b7 c0             	movzwl %ax,%eax
    a37f:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a382:	48 0f af c6          	imul   %rsi,%rax
    a386:	48 c1 e8 20          	shr    $0x20,%rax
    a38a:	48 39 c8             	cmp    %rcx,%rax
    a38d:	73 11                	jae    a3a0 <fwp_hof0.constprop.0+0x1150>
    a38f:	48 01 c5             	add    %rax,%rbp
    a392:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    a396:	0f 84 17 04 00 00    	je     a7b3 <fwp_hof0.constprop.0+0x1563>
    a39c:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    a3a0:	4c 89 ff             	mov    %r15,%rdi
    a3a3:	e9 05 f8 ff ff       	jmp    9bad <fwp_hof0.constprop.0+0x95d>
    a3a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a3af:	00 
    a3b0:	48 89 d7             	mov    %rdx,%rdi
    a3b3:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    a3b8:	e8 93 b1 ff ff       	call   5550 <fwp_rc_forget_slot>
    a3bd:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    a3c2:	e9 41 fa ff ff       	jmp    9e08 <fwp_hof0.constprop.0+0xbb8>
    a3c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a3ce:	00 00 
    a3d0:	44 89 f2             	mov    %r14d,%edx
    a3d3:	be 02 00 00 00       	mov    $0x2,%esi
    a3d8:	bf 08 00 00 00       	mov    $0x8,%edi
    a3dd:	48 c1 e2 10          	shl    $0x10,%rdx
    a3e1:	4c 09 e2             	or     %r12,%rdx
    a3e4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    a3e9:	e8 a2 b8 ff ff       	call   5c90 <fwp_heap_alloc>
    a3ee:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a3f5:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a3fc:	49 89 c6             	mov    %rax,%r14
    a3ff:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a406:	48 c1 e2 10          	shl    $0x10,%rdx
    a40a:	48 39 d0             	cmp    %rdx,%rax
    a40d:	0f 83 6d f3 ff ff    	jae    9780 <fwp_hof0.constprop.0+0x530>
    a413:	48 89 c2             	mov    %rax,%rdx
    a416:	48 c1 ea 10          	shr    $0x10,%rdx
    a41a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a41e:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    a425:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a429:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a42d:	4d 85 ff             	test   %r15,%r15
    a430:	0f 84 3e f3 ff ff    	je     9774 <fwp_hof0.constprop.0+0x524>
    a436:	0f b6 0a             	movzbl (%rdx),%ecx
    a439:	31 ed                	xor    %ebp,%ebp
    a43b:	80 f9 02             	cmp    $0x2,%cl
    a43e:	0f 85 ab f2 ff ff    	jne    96ef <fwp_hof0.constprop.0+0x49f>
    a444:	66 85 c0             	test   %ax,%ax
    a447:	0f 85 ce f2 ff ff    	jne    971b <fwp_hof0.constprop.0+0x4cb>
    a44d:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a451:	0f 85 c0 f2 ff ff    	jne    9717 <fwp_hof0.constprop.0+0x4c7>
    a457:	4c 89 ff             	mov    %r15,%rdi
    a45a:	e8 f1 b0 ff ff       	call   5550 <fwp_rc_forget_slot>
    a45f:	e9 b3 f2 ff ff       	jmp    9717 <fwp_hof0.constprop.0+0x4c7>
    a464:	be 02 00 00 00       	mov    $0x2,%esi
    a469:	bf 08 00 00 00       	mov    $0x8,%edi
    a46e:	e8 1d b8 ff ff       	call   5c90 <fwp_heap_alloc>
    a473:	49 89 c5             	mov    %rax,%r13
    a476:	45 31 f6             	xor    %r14d,%r14d
    a479:	e9 94 fa ff ff       	jmp    9f12 <fwp_hof0.constprop.0+0xcc2>
    a47e:	66 90                	xchg   %ax,%ax
    a480:	48 8d 68 ff          	lea    -0x1(%rax),%rbp
    a484:	48 89 ef             	mov    %rbp,%rdi
    a487:	48 c1 ef 3c          	shr    $0x3c,%rdi
    a48b:	0f 85 e1 05 00 00    	jne    aa72 <fwp_hof0.constprop.0+0x1822>
    a491:	48 85 ed             	test   %rbp,%rbp
    a494:	0f 84 e6 f2 ff ff    	je     9780 <fwp_hof0.constprop.0+0x530>
    a49a:	48 c1 e0 04          	shl    $0x4,%rax
    a49e:	48 01 ed             	add    %rbp,%rbp
    a4a1:	4d 8d 66 08          	lea    0x8(%r14),%r12
    a4a5:	4d 8d 7c 06 f8       	lea    -0x8(%r14,%rax,1),%r15
    a4aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a4b0:	f2 41 0f 10 04 24    	movsd  (%r12),%xmm0
    a4b6:	49 8b 74 24 18       	mov    0x18(%r12),%rsi
    a4bb:	49 83 c4 10          	add    $0x10,%r12
    a4bf:	49 8b 7c 24 f8       	mov    -0x8(%r12),%rdi
    a4c4:	f2 41 0f 10 0c 24    	movsd  (%r12),%xmm1
    a4ca:	e8 91 bd ff ff       	call   6260 <w120>
    a4cf:	66 48 0f 6e e0       	movq   %rax,%xmm4
    a4d4:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    a4d8:	41 0f 11 44 24 f0    	movups %xmm0,-0x10(%r12)
    a4de:	4d 39 e7             	cmp    %r12,%r15
    a4e1:	75 cd                	jne    a4b0 <fwp_hof0.constprop.0+0x1260>
    a4e3:	49 89 2e             	mov    %rbp,(%r14)
    a4e6:	45 31 ff             	xor    %r15d,%r15d
    a4e9:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    a4f0:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    a4f7:	00 f0 3f 
    a4fa:	4b 8b 54 fe 10       	mov    0x10(%r14,%r15,8),%rdx
    a4ff:	49 83 c7 02          	add    $0x2,%r15
    a503:	48 89 ce             	mov    %rcx,%rsi
    a506:	e8 d5 b9 ff ff       	call   5ee0 <fwp_p_ad_push>
    a50b:	48 89 c7             	mov    %rax,%rdi
    a50e:	49 39 ef             	cmp    %rbp,%r15
    a511:	72 dd                	jb     a4f0 <fwp_hof0.constprop.0+0x12a0>
    a513:	49 89 c1             	mov    %rax,%r9
    a516:	e9 75 f2 ff ff       	jmp    9790 <fwp_hof0.constprop.0+0x540>
    a51b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a520:	48 39 d5             	cmp    %rdx,%rbp
    a523:	0f 84 67 ef ff ff    	je     9490 <fwp_hof0.constprop.0+0x240>
    a529:	4c 8b 0d c0 8b 01 00 	mov    0x18bc0(%rip),%r9        # 230f0 <fwp_tapes>
    a530:	48 89 d5             	mov    %rdx,%rbp
    a533:	4c 8d 62 01          	lea    0x1(%rdx),%r12
    a537:	e9 f4 ef ff ff       	jmp    9530 <fwp_hof0.constprop.0+0x2e0>
    a53c:	0f 1f 40 00          	nopl   0x0(%rax)
    a540:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    a545:	45 31 c0             	xor    %r8d,%r8d
    a548:	4c 89 34 24          	mov    %r14,(%rsp)
    a54c:	48 83 e8 01          	sub    $0x1,%rax
    a550:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    a555:	41 0f 90 c0          	seto   %r8b
    a559:	e9 c0 ed ff ff       	jmp    931e <fwp_hof0.constprop.0+0xce>
    a55e:	66 90                	xchg   %ax,%ax
    a560:	4d 8d 63 01          	lea    0x1(%r11),%r12
    a564:	4c 39 e5             	cmp    %r12,%rbp
    a567:	7c 3a                	jl     a5a3 <fwp_hof0.constprop.0+0x1353>
    a569:	48 85 c9             	test   %rcx,%rcx
    a56c:	0f 84 23 05 00 00    	je     aa95 <fwp_hof0.constprop.0+0x1845>
    a572:	48 89 cf             	mov    %rcx,%rdi
    a575:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    a57c:	00 
    a57d:	31 f6                	xor    %esi,%esi
    a57f:	4c 89 e5             	mov    %r12,%rbp
    a582:	4c 89 5c 24 08       	mov    %r11,0x8(%rsp)
    a587:	4c 29 f5             	sub    %r14,%rbp
    a58a:	e8 31 8f ff ff       	call   34c0 <memset@plt>
    a58f:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    a594:	48 89 c1             	mov    %rax,%rcx
    a597:	e9 8c f3 ff ff       	jmp    9928 <fwp_hof0.constprop.0+0x6d8>
    a59c:	0f 1f 40 00          	nopl   0x0(%rax)
    a5a0:	4d 89 f4             	mov    %r14,%r12
    a5a3:	48 85 ed             	test   %rbp,%rbp
    a5a6:	49 0f 44 ec          	cmove  %r12,%rbp
    a5aa:	eb 2a                	jmp    a5d6 <fwp_hof0.constprop.0+0x1386>
    a5ac:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a5b3:	00 00 
    a5b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a5bc:	00 00 00 00 
    a5c0:	48 8d 54 2d 00       	lea    0x0(%rbp,%rbp,1),%rdx
    a5c5:	48 81 fd 00 00 00 40 	cmp    $0x40000000,%rbp
    a5cc:	4c 89 e0             	mov    %r12,%rax
    a5cf:	48 0f 4c c2          	cmovl  %rdx,%rax
    a5d3:	48 89 c5             	mov    %rax,%rbp
    a5d6:	4c 39 e5             	cmp    %r12,%rbp
    a5d9:	7c e5                	jl     a5c0 <fwp_hof0.constprop.0+0x1370>
    a5db:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    a5e0:	48 85 c9             	test   %rcx,%rcx
    a5e3:	0f 84 e7 01 00 00    	je     a7d0 <fwp_hof0.constprop.0+0x1580>
    a5e9:	48 89 cf             	mov    %rcx,%rdi
    a5ec:	48 8d 34 ed 00 00 00 	lea    0x0(,%rbp,8),%rsi
    a5f3:	00 
    a5f4:	e8 d7 8f ff ff       	call   35d0 <realloc@plt>
    a5f9:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    a5fe:	48 89 c1             	mov    %rax,%rcx
    a601:	48 85 c9             	test   %rcx,%rcx
    a604:	0f 84 82 04 00 00    	je     aa8c <fwp_hof0.constprop.0+0x183c>
    a60a:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
    a611:	00 
    a612:	48 89 ac 24 e0 00 00 	mov    %rbp,0xe0(%rsp)
    a619:	00 
    a61a:	4d 85 e4             	test   %r12,%r12
    a61d:	0f 85 75 03 00 00    	jne    a998 <fwp_hof0.constprop.0+0x1748>
    a623:	4c 89 f5             	mov    %r14,%rbp
    a626:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    a62d:	48 f7 dd             	neg    %rbp
    a630:	4d 85 c9             	test   %r9,%r9
    a633:	0f 88 03 f3 ff ff    	js     993c <fwp_hof0.constprop.0+0x6ec>
    a639:	45 89 cb             	mov    %r9d,%r11d
    a63c:	e9 e7 f2 ff ff       	jmp    9928 <fwp_hof0.constprop.0+0x6d8>
    a641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a648:	48 8d 3d 11 c4 ff ff 	lea    -0x3bef(%rip),%rdi        # 6a60 <fwp_tape_finish>
    a64f:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    a655:	e8 66 3b 00 00       	call   e1c0 <atexit>
    a65a:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    a660:	85 c0                	test   %eax,%eax
    a662:	0f 85 cb 04 00 00    	jne    ab33 <fwp_hof0.constprop.0+0x18e3>
    a668:	c7 05 ee 89 00 00 01 	movl   $0x1,0x89ee(%rip)        # 13060 <registered_finish.1>
    a66f:	00 00 00 
    a672:	e9 cd ed ff ff       	jmp    9444 <fwp_hof0.constprop.0+0x1f4>
    a677:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a67e:	00 00 
    a680:	66 85 c0             	test   %ax,%ax
    a683:	0f 85 27 f9 ff ff    	jne    9fb0 <fwp_hof0.constprop.0+0xd60>
    a689:	e9 fa f8 ff ff       	jmp    9f88 <fwp_hof0.constprop.0+0xd38>
    a68e:	66 90                	xchg   %ax,%ax
    a690:	66 85 c0             	test   %ax,%ax
    a693:	0f 85 4f ed ff ff    	jne    93e8 <fwp_hof0.constprop.0+0x198>
    a699:	e9 36 ed ff ff       	jmp    93d4 <fwp_hof0.constprop.0+0x184>
    a69e:	66 90                	xchg   %ax,%ax
    a6a0:	49 39 ee             	cmp    %rbp,%r14
    a6a3:	0f 8f f7 fe ff ff    	jg     a5a0 <fwp_hof0.constprop.0+0x1350>
    a6a9:	4d 85 f6             	test   %r14,%r14
    a6ac:	74 12                	je     a6c0 <fwp_hof0.constprop.0+0x1470>
    a6ae:	48 85 c9             	test   %rcx,%rcx
    a6b1:	0f 84 de 03 00 00    	je     aa95 <fwp_hof0.constprop.0+0x1845>
    a6b7:	4d 85 f6             	test   %r14,%r14
    a6ba:	0f 85 d5 02 00 00    	jne    a995 <fwp_hof0.constprop.0+0x1745>
    a6c0:	31 ed                	xor    %ebp,%ebp
    a6c2:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    a6c9:	e9 6e f2 ff ff       	jmp    993c <fwp_hof0.constprop.0+0x6ec>
    a6ce:	66 90                	xchg   %ax,%ax
    a6d0:	66 85 c0             	test   %ax,%ax
    a6d3:	0f 85 17 f4 ff ff    	jne    9af0 <fwp_hof0.constprop.0+0x8a0>
    a6d9:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    a6dd:	0f 85 09 f4 ff ff    	jne    9aec <fwp_hof0.constprop.0+0x89c>
    a6e3:	48 89 ef             	mov    %rbp,%rdi
    a6e6:	e8 65 ae ff ff       	call   5550 <fwp_rc_forget_slot>
    a6eb:	e9 fc f3 ff ff       	jmp    9aec <fwp_hof0.constprop.0+0x89c>
    a6f0:	4c 8b 34 24          	mov    (%rsp),%r14
    a6f4:	48 89 04 24          	mov    %rax,(%rsp)
    a6f8:	e9 15 f8 ff ff       	jmp    9f12 <fwp_hof0.constprop.0+0xcc2>
    a6fd:	0f 1f 00             	nopl   (%rax)
    a700:	48 8b 04 24          	mov    (%rsp),%rax
    a704:	48 8b 8b b0 13 00 00 	mov    0x13b0(%rbx),%rcx
    a70b:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a712:	48 8b 68 10          	mov    0x10(%rax),%rbp
    a716:	48 29 c8             	sub    %rcx,%rax
    a719:	48 c1 e2 10          	shl    $0x10,%rdx
    a71d:	48 39 d0             	cmp    %rdx,%rax
    a720:	73 66                	jae    a788 <fwp_hof0.constprop.0+0x1538>
    a722:	48 89 c7             	mov    %rax,%rdi
    a725:	48 c1 ef 10          	shr    $0x10,%rdi
    a729:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    a72d:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a731:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a735:	48 85 ff             	test   %rdi,%rdi
    a738:	74 4e                	je     a788 <fwp_hof0.constprop.0+0x1538>
    a73a:	44 0f b6 06          	movzbl (%rsi),%r8d
    a73e:	41 80 f8 02          	cmp    $0x2,%r8b
    a742:	0f 84 85 01 00 00    	je     a8cd <fwp_hof0.constprop.0+0x167d>
    a748:	41 80 f8 01          	cmp    $0x1,%r8b
    a74c:	75 3a                	jne    a788 <fwp_hof0.constprop.0+0x1538>
    a74e:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a752:	0f b7 c0             	movzwl %ax,%eax
    a755:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a758:	49 0f af c0          	imul   %r8,%rax
    a75c:	48 c1 e8 20          	shr    $0x20,%rax
    a760:	48 39 f0             	cmp    %rsi,%rax
    a763:	73 23                	jae    a788 <fwp_hof0.constprop.0+0x1538>
    a765:	48 01 c7             	add    %rax,%rdi
    a768:	80 3f 01             	cmpb   $0x1,(%rdi)
    a76b:	75 1b                	jne    a788 <fwp_hof0.constprop.0+0x1538>
    a76d:	48 8b 3c 24          	mov    (%rsp),%rdi
    a771:	e8 1a b0 ff ff       	call   5790 <fwp_mem_free>
    a776:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a77d:	48 8b 8b b0 13 00 00 	mov    0x13b0(%rbx),%rcx
    a784:	48 c1 e2 10          	shl    $0x10,%rdx
    a788:	48 89 e8             	mov    %rbp,%rax
    a78b:	48 29 c8             	sub    %rcx,%rax
    a78e:	48 39 d0             	cmp    %rdx,%rax
    a791:	0f 83 19 f8 ff ff    	jae    9fb0 <fwp_hof0.constprop.0+0xd60>
    a797:	48 89 2c 24          	mov    %rbp,(%rsp)
    a79b:	e9 9f f7 ff ff       	jmp    9f3f <fwp_hof0.constprop.0+0xcef>
    a7a0:	66 85 c0             	test   %ax,%ax
    a7a3:	0f 85 f7 fb ff ff    	jne    a3a0 <fwp_hof0.constprop.0+0x1150>
    a7a9:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    a7ad:	0f 85 e9 fb ff ff    	jne    a39c <fwp_hof0.constprop.0+0x114c>
    a7b3:	48 89 ef             	mov    %rbp,%rdi
    a7b6:	e8 95 ad ff ff       	call   5550 <fwp_rc_forget_slot>
    a7bb:	e9 dc fb ff ff       	jmp    a39c <fwp_hof0.constprop.0+0x114c>
    a7c0:	48 85 ed             	test   %rbp,%rbp
    a7c3:	0f 85 57 ef ff ff    	jne    9720 <fwp_hof0.constprop.0+0x4d0>
    a7c9:	e9 b2 ef ff ff       	jmp    9780 <fwp_hof0.constprop.0+0x530>
    a7ce:	66 90                	xchg   %ax,%ax
    a7d0:	be 08 00 00 00       	mov    $0x8,%esi
    a7d5:	48 89 ef             	mov    %rbp,%rdi
    a7d8:	e8 43 8d ff ff       	call   3520 <calloc@plt>
    a7dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    a7e2:	48 89 c1             	mov    %rax,%rcx
    a7e5:	e9 17 fe ff ff       	jmp    a601 <fwp_hof0.constprop.0+0x13b1>
    a7ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a7f0:	66 85 c0             	test   %ax,%ax
    a7f3:	0f 85 10 eb ff ff    	jne    9309 <fwp_hof0.constprop.0+0xb9>
    a7f9:	e9 f7 ea ff ff       	jmp    92f5 <fwp_hof0.constprop.0+0xa5>
    a7fe:	66 90                	xchg   %ax,%ax
    a800:	66 85 c0             	test   %ax,%ax
    a803:	0f 85 be f8 ff ff    	jne    a0c7 <fwp_hof0.constprop.0+0xe77>
    a809:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a80d:	0f 85 b0 f8 ff ff    	jne    a0c3 <fwp_hof0.constprop.0+0xe73>
    a813:	4c 89 ff             	mov    %r15,%rdi
    a816:	e8 35 ad ff ff       	call   5550 <fwp_rc_forget_slot>
    a81b:	e9 a3 f8 ff ff       	jmp    a0c3 <fwp_hof0.constprop.0+0xe73>
    a820:	66 85 c0             	test   %ax,%ax
    a823:	0f 85 57 f9 ff ff    	jne    a180 <fwp_hof0.constprop.0+0xf30>
    a829:	41 0f b6 04 24       	movzbl (%r12),%eax
    a82e:	84 c0                	test   %al,%al
    a830:	0f 84 4a f9 ff ff    	je     a180 <fwp_hof0.constprop.0+0xf30>
    a836:	3c 01                	cmp    $0x1,%al
    a838:	0f 85 2e f9 ff ff    	jne    a16c <fwp_hof0.constprop.0+0xf1c>
    a83e:	48 89 ef             	mov    %rbp,%rdi
    a841:	e8 4a af ff ff       	call   5790 <fwp_mem_free>
    a846:	e9 35 f9 ff ff       	jmp    a180 <fwp_hof0.constprop.0+0xf30>
    a84b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a850:	be 68 00 00 00       	mov    $0x68,%esi
    a855:	41 bc 01 00 00 00    	mov    $0x1,%r12d
    a85b:	e9 6b ec ff ff       	jmp    94cb <fwp_hof0.constprop.0+0x27b>
    a860:	31 ff                	xor    %edi,%edi
    a862:	e8 e9 99 ff ff       	call   4250 <descent_phase_step>
    a867:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a86b:	e9 c6 eb ff ff       	jmp    9436 <fwp_hof0.constprop.0+0x1e6>
    a870:	49 8b 04 24          	mov    (%r12),%rax
    a874:	48 85 c0             	test   %rax,%rax
    a877:	0f 88 e7 fb ff ff    	js     a464 <fwp_hof0.constprop.0+0x1214>
    a87d:	48 8b b3 d8 13 00 00 	mov    0x13d8(%rbx),%rsi
    a884:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a889:	48 2b 8b b0 13 00 00 	sub    0x13b0(%rbx),%rcx
    a890:	48 c1 e6 10          	shl    $0x10,%rsi
    a894:	48 39 f1             	cmp    %rsi,%rcx
    a897:	0f 83 c7 fb ff ff    	jae    a464 <fwp_hof0.constprop.0+0x1214>
    a89d:	48 89 ce             	mov    %rcx,%rsi
    a8a0:	48 c1 ee 10          	shr    $0x10,%rsi
    a8a4:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a8a8:	48 8b b3 f8 13 00 00 	mov    0x13f8(%rbx),%rsi
    a8af:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a8b3:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a8b7:	48 85 ff             	test   %rdi,%rdi
    a8ba:	0f 84 a4 fb ff ff    	je     a464 <fwp_hof0.constprop.0+0x1214>
    a8c0:	48 0f ba f0 3f       	btr    $0x3f,%rax
    a8c5:	49 89 c7             	mov    %rax,%r15
    a8c8:	e9 b8 f3 ff ff       	jmp    9c85 <fwp_hof0.constprop.0+0xa35>
    a8cd:	66 85 c0             	test   %ax,%ax
    a8d0:	0f 85 b2 fe ff ff    	jne    a788 <fwp_hof0.constprop.0+0x1538>
    a8d6:	e9 8d fe ff ff       	jmp    a768 <fwp_hof0.constprop.0+0x1518>
    a8db:	48 89 ea             	mov    %rbp,%rdx
    a8de:	48 c1 ea 11          	shr    $0x11,%rdx
    a8e2:	48 31 ea             	xor    %rbp,%rdx
    a8e5:	48 89 d0             	mov    %rdx,%rax
    a8e8:	48 c1 e8 09          	shr    $0x9,%rax
    a8ec:	48 31 c2             	xor    %rax,%rdx
    a8ef:	0f b6 d2             	movzbl %dl,%edx
    a8f2:	48 8b 84 d3 48 14 00 	mov    0x1448(%rbx,%rdx,8),%rax
    a8f9:	00 
    a8fa:	48 85 c0             	test   %rax,%rax
    a8fd:	75 2a                	jne    a929 <fwp_hof0.constprop.0+0x16d9>
    a8ff:	e9 85 00 00 00       	jmp    a989 <fwp_hof0.constprop.0+0x1739>
    a904:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a90a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a911:	00 00 00 00 
    a915:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a91c:	00 00 00 00 
    a920:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a924:	48 85 c0             	test   %rax,%rax
    a927:	74 60                	je     a989 <fwp_hof0.constprop.0+0x1739>
    a929:	48 89 c2             	mov    %rax,%rdx
    a92c:	48 39 28             	cmp    %rbp,(%rax)
    a92f:	75 ef                	jne    a920 <fwp_hof0.constprop.0+0x16d0>
    a931:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a935:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    a939:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a93d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    a944:	0f 85 66 f6 ff ff    	jne    9fb0 <fwp_hof0.constprop.0+0xd60>
    a94a:	48 89 ef             	mov    %rbp,%rdi
    a94d:	e8 fe ab ff ff       	call   5550 <fwp_rc_forget_slot>
    a952:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    a956:	e9 55 f6 ff ff       	jmp    9fb0 <fwp_hof0.constprop.0+0xd60>
    a95b:	e8 d0 aa ff ff       	call   5430 <fwp_rc_wide_dup>
    a960:	e9 83 ea ff ff       	jmp    93e8 <fwp_hof0.constprop.0+0x198>
    a965:	4c 89 e0             	mov    %r12,%rax
    a968:	48 c1 e8 11          	shr    $0x11,%rax
    a96c:	4c 31 e0             	xor    %r12,%rax
    a96f:	48 89 c2             	mov    %rax,%rdx
    a972:	48 c1 ea 09          	shr    $0x9,%rdx
    a976:	48 31 d0             	xor    %rdx,%rax
    a979:	0f b6 d0             	movzbl %al,%edx
    a97c:	48 8b 84 d3 48 14 00 	mov    0x1448(%rbx,%rdx,8),%rax
    a983:	00 
    a984:	48 85 c0             	test   %rax,%rax
    a987:	75 60                	jne    a9e9 <fwp_hof0.constprop.0+0x1799>
    a989:	48 8d 3d 00 4f 00 00 	lea    0x4f00(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    a990:	e8 5b 9a ff ff       	call   43f0 <fwp_trap>
    a995:	4d 89 f4             	mov    %r14,%r12
    a998:	48 89 cf             	mov    %rcx,%rdi
    a99b:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    a9a2:	00 
    a9a3:	31 f6                	xor    %esi,%esi
    a9a5:	4c 89 e5             	mov    %r12,%rbp
    a9a8:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    a9ad:	4d 8d 7c 24 ff       	lea    -0x1(%r12),%r15
    a9b2:	4c 29 f5             	sub    %r14,%rbp
    a9b5:	e8 06 8b ff ff       	call   34c0 <memset@plt>
    a9ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    a9bf:	48 89 c1             	mov    %rax,%rcx
    a9c2:	e9 69 fc ff ff       	jmp    a630 <fwp_hof0.constprop.0+0x13e0>
    a9c7:	0f 1f 00             	nopl   (%rax)
    a9ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a9d1:	00 00 00 00 
    a9d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a9dc:	00 00 00 00 
    a9e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a9e4:	48 85 c0             	test   %rax,%rax
    a9e7:	74 a0                	je     a989 <fwp_hof0.constprop.0+0x1739>
    a9e9:	48 89 c2             	mov    %rax,%rdx
    a9ec:	4c 3b 20             	cmp    (%rax),%r12
    a9ef:	75 ef                	jne    a9e0 <fwp_hof0.constprop.0+0x1790>
    a9f1:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a9f5:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    a9f9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a9fd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    aa04:	0f 85 76 f7 ff ff    	jne    a180 <fwp_hof0.constprop.0+0xf30>
    aa0a:	4c 89 e7             	mov    %r12,%rdi
    aa0d:	e8 3e ab ff ff       	call   5550 <fwp_rc_forget_slot>
    aa12:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    aa17:	e9 64 f7 ff ff       	jmp    a180 <fwp_hof0.constprop.0+0xf30>
    aa1c:	e8 0f aa ff ff       	call   5430 <fwp_rc_wide_dup>
    aa21:	e9 e3 e8 ff ff       	jmp    9309 <fwp_hof0.constprop.0+0xb9>
    aa26:	45 31 ff             	xor    %r15d,%r15d
    aa29:	e9 a7 f3 ff ff       	jmp    9dd5 <fwp_hof0.constprop.0+0xb85>
    aa2e:	48 8d 3d 83 4e 00 00 	lea    0x4e83(%rip),%rdi        # f8b8 <_IO_stdin_used+0x8b8>
    aa35:	e8 b6 99 ff ff       	call   43f0 <fwp_trap>
    aa3a:	48 8d 3d 26 47 00 00 	lea    0x4726(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    aa41:	e8 aa 99 ff ff       	call   43f0 <fwp_trap>
    aa46:	48 8d 3d 43 4f 00 00 	lea    0x4f43(%rip),%rdi        # f990 <_IO_stdin_used+0x990>
    aa4d:	e8 9e 99 ff ff       	call   43f0 <fwp_trap>
    aa52:	45 31 ed             	xor    %r13d,%r13d
    aa55:	e9 1c fa ff ff       	jmp    a476 <fwp_hof0.constprop.0+0x1226>
    aa5a:	48 8d 3d bb 47 00 00 	lea    0x47bb(%rip),%rdi        # f21c <_IO_stdin_used+0x21c>
    aa61:	e8 8a 99 ff ff       	call   43f0 <fwp_trap>
    aa66:	48 8d 3d c9 47 00 00 	lea    0x47c9(%rip),%rdi        # f236 <_IO_stdin_used+0x236>
    aa6d:	e8 7e 99 ff ff       	call   43f0 <fwp_trap>
    aa72:	48 8d 3d 17 47 00 00 	lea    0x4717(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    aa79:	e8 72 99 ff ff       	call   43f0 <fwp_trap>
    aa7e:	66 90                	xchg   %ax,%ax
    aa80:	48 8d 3d 31 4f 00 00 	lea    0x4f31(%rip),%rdi        # f9b8 <_IO_stdin_used+0x9b8>
    aa87:	e8 64 99 ff ff       	call   43f0 <fwp_trap>
    aa8c:	4d 85 e4             	test   %r12,%r12
    aa8f:	0f 84 8e fb ff ff    	je     a623 <fwp_hof0.constprop.0+0x13d3>
    aa95:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
    aa9c:	00 
    aa9d:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    aaa2:	48 89 05 af a9 01 00 	mov    %rax,0x1a9af(%rip)        # 25458 <fwp_cleanups>
    aaa9:	e8 c2 a5 ff ff       	call   5070 <fwp_tape_buffers_release>
    aaae:	ba 13 00 00 00       	mov    $0x13,%edx
    aab3:	48 8b 0d 86 85 00 00 	mov    0x8586(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    aaba:	be 01 00 00 00       	mov    $0x1,%esi
    aabf:	48 8d 3d 42 45 00 00 	lea    0x4542(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    aac6:	e8 b5 8b ff ff       	call   3680 <fwrite@plt>
    aacb:	31 ff                	xor    %edi,%edi
    aacd:	e8 ee 8a ff ff       	call   35c0 <fflush@plt>
    aad2:	bf 66 00 00 00       	mov    $0x66,%edi
    aad7:	e8 c4 8b ff ff       	call   36a0 <_Exit@plt>
    aadc:	48 8d 3d 7d 4e 00 00 	lea    0x4e7d(%rip),%rdi        # f960 <_IO_stdin_used+0x960>
    aae3:	e8 08 99 ff ff       	call   43f0 <fwp_trap>
    aae8:	48 8b 0d 51 85 00 00 	mov    0x8551(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    aaef:	ba 13 00 00 00       	mov    $0x13,%edx
    aaf4:	be 01 00 00 00       	mov    $0x1,%esi
    aaf9:	48 8d 3d 08 45 00 00 	lea    0x4508(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    ab00:	e8 7b 8b ff ff       	call   3680 <fwrite@plt>
    ab05:	31 ff                	xor    %edi,%edi
    ab07:	e8 b4 8a ff ff       	call   35c0 <fflush@plt>
    ab0c:	bf 66 00 00 00       	mov    $0x66,%edi
    ab11:	e8 8a 8b ff ff       	call   36a0 <_Exit@plt>
    ab16:	48 8d 3d e3 4d 00 00 	lea    0x4de3(%rip),%rdi        # f900 <_IO_stdin_used+0x900>
    ab1d:	e8 ce 98 ff ff       	call   43f0 <fwp_trap>
    ab22:	e8 39 89 ff ff       	call   3460 <__stack_chk_fail@plt>
    ab27:	48 8d 3d 18 47 00 00 	lea    0x4718(%rip),%rdi        # f246 <_IO_stdin_used+0x246>
    ab2e:	e8 bd 98 ff ff       	call   43f0 <fwp_trap>
    ab33:	48 8b 0d 06 85 00 00 	mov    0x8506(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    ab3a:	ba 13 00 00 00       	mov    $0x13,%edx
    ab3f:	be 01 00 00 00       	mov    $0x1,%esi
    ab44:	48 8d 3d bd 44 00 00 	lea    0x44bd(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    ab4b:	e8 30 8b ff ff       	call   3680 <fwrite@plt>
    ab50:	31 ff                	xor    %edi,%edi
    ab52:	e8 69 8a ff ff       	call   35c0 <fflush@plt>
    ab57:	bf 66 00 00 00       	mov    $0x66,%edi
    ab5c:	e8 3f 8b ff ff       	call   36a0 <_Exit@plt>
    ab61:	0f 1f 40 00          	nopl   0x0(%rax)
    ab65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ab6c:	00 00 00 00 

000000000000ab70 <f0>:
    ab70:	41 56                	push   %r14
    ab72:	4c 8d 35 47 8c 01 00 	lea    0x18c47(%rip),%r14        # 237c0 <fwp_heap>
    ab79:	41 55                	push   %r13
    ab7b:	41 54                	push   %r12
    ab7d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    ab83:	55                   	push   %rbp
    ab84:	53                   	push   %rbx
    ab85:	31 db                	xor    %ebx,%ebx
    ab87:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    ab8e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    ab95:	00 00 
    ab97:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    ab9e:	00 
    ab9f:	31 c0                	xor    %eax,%eax
    aba1:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    aba8:	00 
    aba9:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    abb0:	00 00 
    abb2:	66 48 0f 6e c0       	movq   %rax,%xmm0
    abb7:	48 8d 05 b2 cc ff ff 	lea    -0x334e(%rip),%rax        # 7870 <fwp_drop1>
    abbe:	66 48 0f 6e c8       	movq   %rax,%xmm1
    abc3:	48 8b 05 8e a8 01 00 	mov    0x1a88e(%rip),%rax        # 25458 <fwp_cleanups>
    abca:	48 89 25 87 a8 01 00 	mov    %rsp,0x1a887(%rip)        # 25458 <fwp_cleanups>
    abd1:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    abd5:	48 89 04 24          	mov    %rax,(%rsp)
    abd9:	48 8d 05 f0 8f ff ff 	lea    -0x7010(%rip),%rax        # 3bd0 <fwp_range_release>
    abe0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    abe5:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    abea:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    abef:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    abf4:	eb 47                	jmp    ac3d <f0+0xcd>
    abf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    abfd:	00 00 00 
    ac00:	80 f9 01             	cmp    $0x1,%cl
    ac03:	75 29                	jne    ac2e <f0+0xbe>
    ac05:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ac08:	0f b7 c0             	movzwl %ax,%eax
    ac0b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ac0e:	48 0f af c1          	imul   %rcx,%rax
    ac12:	48 c1 e8 20          	shr    $0x20,%rax
    ac16:	48 39 d0             	cmp    %rdx,%rax
    ac19:	73 13                	jae    ac2e <f0+0xbe>
    ac1b:	49 01 c5             	add    %rax,%r13
    ac1e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    ac23:	0f 84 c7 27 00 00    	je     d3f0 <f0+0x2880>
    ac29:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    ac2e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    ac33:	49 83 ec 01          	sub    $0x1,%r12
    ac37:	0f 82 83 00 00 00    	jb     acc0 <f0+0x150>
    ac3d:	48 89 ee             	mov    %rbp,%rsi
    ac40:	bf 01 00 00 00       	mov    $0x1,%edi
    ac45:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    ac4c:	00 
    ac4d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    ac52:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    ac59:	00 
    ac5a:	e8 51 b1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ac5f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    ac66:	48 89 c3             	mov    %rax,%rbx
    ac69:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    ac70:	48 c1 e2 10          	shl    $0x10,%rdx
    ac74:	48 39 d0             	cmp    %rdx,%rax
    ac77:	73 b5                	jae    ac2e <f0+0xbe>
    ac79:	48 89 c2             	mov    %rax,%rdx
    ac7c:	48 c1 ea 10          	shr    $0x10,%rdx
    ac80:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ac84:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    ac8b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ac8f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    ac93:	4d 85 ed             	test   %r13,%r13
    ac96:	74 96                	je     ac2e <f0+0xbe>
    ac98:	0f b6 0a             	movzbl (%rdx),%ecx
    ac9b:	80 f9 02             	cmp    $0x2,%cl
    ac9e:	0f 85 5c ff ff ff    	jne    ac00 <f0+0x90>
    aca4:	66 85 c0             	test   %ax,%ax
    aca7:	0f 84 71 ff ff ff    	je     ac1e <f0+0xae>
    acad:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    acb2:	49 83 ec 01          	sub    $0x1,%r12
    acb6:	73 85                	jae    ac3d <f0+0xcd>
    acb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    acbf:	00 
    acc0:	48 8b 04 24          	mov    (%rsp),%rax
    acc4:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    acc9:	bf 01 00 00 00       	mov    $0x1,%edi
    acce:	66 0f 6f 05 6a 4f 00 	movdqa 0x4f6a(%rip),%xmm0        # fc40 <msg.4+0xd0>
    acd5:	00 
    acd6:	48 89 05 7b a7 01 00 	mov    %rax,0x1a77b(%rip)        # 25458 <fwp_cleanups>
    acdd:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    ace2:	e8 c9 b0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ace7:	48 8b 15 aa 9e 01 00 	mov    0x19eaa(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    acee:	49 89 c5             	mov    %rax,%r13
    acf1:	48 2b 05 78 9e 01 00 	sub    0x19e78(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    acf8:	48 c1 e2 10          	shl    $0x10,%rdx
    acfc:	48 39 d0             	cmp    %rdx,%rax
    acff:	73 59                	jae    ad5a <f0+0x1ea>
    ad01:	48 89 c2             	mov    %rax,%rdx
    ad04:	48 c1 ea 10          	shr    $0x10,%rdx
    ad08:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ad0c:	48 8b 15 a5 9e 01 00 	mov    0x19ea5(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    ad13:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ad17:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ad1b:	4d 85 e4             	test   %r12,%r12
    ad1e:	74 3a                	je     ad5a <f0+0x1ea>
    ad20:	0f b6 0a             	movzbl (%rdx),%ecx
    ad23:	80 f9 02             	cmp    $0x2,%cl
    ad26:	0f 84 74 27 00 00    	je     d4a0 <f0+0x2930>
    ad2c:	80 f9 01             	cmp    $0x1,%cl
    ad2f:	75 29                	jne    ad5a <f0+0x1ea>
    ad31:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ad34:	0f b7 c0             	movzwl %ax,%eax
    ad37:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ad3a:	48 0f af c1          	imul   %rcx,%rax
    ad3e:	48 c1 e8 20          	shr    $0x20,%rax
    ad42:	48 39 d0             	cmp    %rdx,%rax
    ad45:	73 13                	jae    ad5a <f0+0x1ea>
    ad47:	49 01 c4             	add    %rax,%r12
    ad4a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ad4f:	0f 84 26 29 00 00    	je     d67b <f0+0x2b0b>
    ad55:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ad5a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    ad5f:	bf 01 00 00 00       	mov    $0x1,%edi
    ad64:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    ad69:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ad70:	00 f0 3f 
    ad73:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    ad78:	e8 33 b0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ad7d:	48 8b 15 14 9e 01 00 	mov    0x19e14(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    ad84:	49 89 c5             	mov    %rax,%r13
    ad87:	48 2b 05 e2 9d 01 00 	sub    0x19de2(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ad8e:	48 c1 e2 10          	shl    $0x10,%rdx
    ad92:	48 39 d0             	cmp    %rdx,%rax
    ad95:	73 59                	jae    adf0 <f0+0x280>
    ad97:	48 89 c2             	mov    %rax,%rdx
    ad9a:	48 c1 ea 10          	shr    $0x10,%rdx
    ad9e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ada2:	48 8b 15 0f 9e 01 00 	mov    0x19e0f(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    ada9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    adad:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    adb1:	4d 85 e4             	test   %r12,%r12
    adb4:	74 3a                	je     adf0 <f0+0x280>
    adb6:	0f b6 0a             	movzbl (%rdx),%ecx
    adb9:	80 f9 02             	cmp    $0x2,%cl
    adbc:	0f 84 ce 26 00 00    	je     d490 <f0+0x2920>
    adc2:	80 f9 01             	cmp    $0x1,%cl
    adc5:	75 29                	jne    adf0 <f0+0x280>
    adc7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    adca:	0f b7 c0             	movzwl %ax,%eax
    adcd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    add0:	48 0f af c1          	imul   %rcx,%rax
    add4:	48 c1 e8 20          	shr    $0x20,%rax
    add8:	48 39 d0             	cmp    %rdx,%rax
    addb:	73 13                	jae    adf0 <f0+0x280>
    addd:	49 01 c4             	add    %rax,%r12
    ade0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ade5:	0f 84 9d 28 00 00    	je     d688 <f0+0x2b18>
    adeb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    adf0:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    adf5:	bf 01 00 00 00       	mov    $0x1,%edi
    adfa:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    adff:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ae06:	33 f3 bf 
    ae09:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    ae0e:	e8 9d af ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ae13:	48 8b 15 7e 9d 01 00 	mov    0x19d7e(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    ae1a:	49 89 c5             	mov    %rax,%r13
    ae1d:	48 2b 05 4c 9d 01 00 	sub    0x19d4c(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ae24:	48 c1 e2 10          	shl    $0x10,%rdx
    ae28:	48 39 d0             	cmp    %rdx,%rax
    ae2b:	73 59                	jae    ae86 <f0+0x316>
    ae2d:	48 89 c2             	mov    %rax,%rdx
    ae30:	48 c1 ea 10          	shr    $0x10,%rdx
    ae34:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ae38:	48 8b 15 79 9d 01 00 	mov    0x19d79(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    ae3f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ae43:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ae47:	4d 85 e4             	test   %r12,%r12
    ae4a:	74 3a                	je     ae86 <f0+0x316>
    ae4c:	0f b6 0a             	movzbl (%rdx),%ecx
    ae4f:	80 f9 02             	cmp    $0x2,%cl
    ae52:	0f 84 28 26 00 00    	je     d480 <f0+0x2910>
    ae58:	80 f9 01             	cmp    $0x1,%cl
    ae5b:	75 29                	jne    ae86 <f0+0x316>
    ae5d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ae60:	0f b7 c0             	movzwl %ax,%eax
    ae63:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ae66:	48 0f af c1          	imul   %rcx,%rax
    ae6a:	48 c1 e8 20          	shr    $0x20,%rax
    ae6e:	48 39 d0             	cmp    %rdx,%rax
    ae71:	73 13                	jae    ae86 <f0+0x316>
    ae73:	49 01 c4             	add    %rax,%r12
    ae76:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ae7b:	0f 84 14 28 00 00    	je     d695 <f0+0x2b25>
    ae81:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ae86:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    ae8b:	bf 01 00 00 00       	mov    $0x1,%edi
    ae90:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    ae95:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ae9c:	00 f0 3f 
    ae9f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    aea4:	e8 07 af ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    aea9:	48 8b 15 e8 9c 01 00 	mov    0x19ce8(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    aeb0:	49 89 c5             	mov    %rax,%r13
    aeb3:	48 2b 05 b6 9c 01 00 	sub    0x19cb6(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    aeba:	48 c1 e2 10          	shl    $0x10,%rdx
    aebe:	48 39 d0             	cmp    %rdx,%rax
    aec1:	73 59                	jae    af1c <f0+0x3ac>
    aec3:	48 89 c2             	mov    %rax,%rdx
    aec6:	48 c1 ea 10          	shr    $0x10,%rdx
    aeca:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aece:	48 8b 15 e3 9c 01 00 	mov    0x19ce3(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    aed5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aed9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    aedd:	4d 85 e4             	test   %r12,%r12
    aee0:	74 3a                	je     af1c <f0+0x3ac>
    aee2:	0f b6 0a             	movzbl (%rdx),%ecx
    aee5:	80 f9 02             	cmp    $0x2,%cl
    aee8:	0f 84 f2 25 00 00    	je     d4e0 <f0+0x2970>
    aeee:	80 f9 01             	cmp    $0x1,%cl
    aef1:	75 29                	jne    af1c <f0+0x3ac>
    aef3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aef6:	0f b7 c0             	movzwl %ax,%eax
    aef9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aefc:	48 0f af c1          	imul   %rcx,%rax
    af00:	48 c1 e8 20          	shr    $0x20,%rax
    af04:	48 39 d0             	cmp    %rdx,%rax
    af07:	73 13                	jae    af1c <f0+0x3ac>
    af09:	49 01 c4             	add    %rax,%r12
    af0c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    af11:	0f 84 8b 27 00 00    	je     d6a2 <f0+0x2b32>
    af17:	41 c6 04 24 01       	movb   $0x1,(%r12)
    af1c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    af23:	33 f3 bf 
    af26:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    af2d:	00 
    af2e:	bf 01 00 00 00       	mov    $0x1,%edi
    af33:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    af3a:	00 
    af3b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    af42:	00 
    af43:	e8 68 ae ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    af48:	48 8b 15 49 9c 01 00 	mov    0x19c49(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    af4f:	49 89 c5             	mov    %rax,%r13
    af52:	48 2b 05 17 9c 01 00 	sub    0x19c17(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    af59:	48 c1 e2 10          	shl    $0x10,%rdx
    af5d:	48 39 d0             	cmp    %rdx,%rax
    af60:	73 59                	jae    afbb <f0+0x44b>
    af62:	48 89 c2             	mov    %rax,%rdx
    af65:	48 c1 ea 10          	shr    $0x10,%rdx
    af69:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    af6d:	48 8b 15 44 9c 01 00 	mov    0x19c44(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    af74:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    af78:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    af7c:	4d 85 e4             	test   %r12,%r12
    af7f:	74 3a                	je     afbb <f0+0x44b>
    af81:	0f b6 0a             	movzbl (%rdx),%ecx
    af84:	80 f9 02             	cmp    $0x2,%cl
    af87:	0f 84 43 25 00 00    	je     d4d0 <f0+0x2960>
    af8d:	80 f9 01             	cmp    $0x1,%cl
    af90:	75 29                	jne    afbb <f0+0x44b>
    af92:	8b 4a 18             	mov    0x18(%rdx),%ecx
    af95:	0f b7 c0             	movzwl %ax,%eax
    af98:	8b 52 1c             	mov    0x1c(%rdx),%edx
    af9b:	48 0f af c1          	imul   %rcx,%rax
    af9f:	48 c1 e8 20          	shr    $0x20,%rax
    afa3:	48 39 d0             	cmp    %rdx,%rax
    afa6:	73 13                	jae    afbb <f0+0x44b>
    afa8:	49 01 c4             	add    %rax,%r12
    afab:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    afb0:	0f 84 f9 26 00 00    	je     d6af <f0+0x2b3f>
    afb6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    afbb:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    afc2:	00 f0 3f 
    afc5:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    afcc:	00 
    afcd:	bf 01 00 00 00       	mov    $0x1,%edi
    afd2:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    afd9:	00 
    afda:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    afe1:	00 
    afe2:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    afe9:	33 f3 bf 
    afec:	e8 bf ad ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    aff1:	48 89 c7             	mov    %rax,%rdi
    aff4:	e8 57 b4 ff ff       	call   6450 <fwp_rc_fresh>
    aff9:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    b000:	00 
    b001:	bf 01 00 00 00       	mov    $0x1,%edi
    b006:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    b00d:	00 
    b00e:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    b015:	00 
    b016:	e8 95 ad ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b01b:	48 89 c7             	mov    %rax,%rdi
    b01e:	e8 2d b4 ff ff       	call   6450 <fwp_rc_fresh>
    b023:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    b02a:	00 
    b02b:	bf 01 00 00 00       	mov    $0x1,%edi
    b030:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    b037:	00 
    b038:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    b03f:	00 
    b040:	e8 6b ad ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b045:	48 89 c7             	mov    %rax,%rdi
    b048:	e8 03 b4 ff ff       	call   6450 <fwp_rc_fresh>
    b04d:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    b054:	00 
    b055:	bf 01 00 00 00       	mov    $0x1,%edi
    b05a:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    b061:	00 
    b062:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    b069:	00 
    b06a:	e8 41 ad ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b06f:	48 89 c7             	mov    %rax,%rdi
    b072:	e8 d9 b3 ff ff       	call   6450 <fwp_rc_fresh>
    b077:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    b07e:	00 
    b07f:	bf 01 00 00 00       	mov    $0x1,%edi
    b084:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    b08b:	00 
    b08c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    b093:	00 
    b094:	e8 17 ad ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b099:	48 89 c7             	mov    %rax,%rdi
    b09c:	e8 af b3 ff ff       	call   6450 <fwp_rc_fresh>
    b0a1:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    b0a8:	00 
    b0a9:	bf 01 00 00 00       	mov    $0x1,%edi
    b0ae:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    b0b5:	00 
    b0b6:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    b0bd:	00 
    b0be:	e8 ed ac ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b0c3:	48 89 c7             	mov    %rax,%rdi
    b0c6:	e8 85 b3 ff ff       	call   6450 <fwp_rc_fresh>
    b0cb:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    b0d2:	00 
    b0d3:	bf 01 00 00 00       	mov    $0x1,%edi
    b0d8:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    b0df:	00 
    b0e0:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    b0e7:	00 
    b0e8:	e8 c3 ac ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b0ed:	48 89 c7             	mov    %rax,%rdi
    b0f0:	e8 5b b3 ff ff       	call   6450 <fwp_rc_fresh>
    b0f5:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    b0fc:	00 
    b0fd:	bf 01 00 00 00       	mov    $0x1,%edi
    b102:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    b109:	00 
    b10a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    b111:	00 
    b112:	e8 99 ac ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b117:	48 89 c7             	mov    %rax,%rdi
    b11a:	e8 31 b3 ff ff       	call   6450 <fwp_rc_fresh>
    b11f:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    b126:	00 
    b127:	bf 01 00 00 00       	mov    $0x1,%edi
    b12c:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    b133:	00 
    b134:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    b13b:	00 
    b13c:	e8 6f ac ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b141:	48 89 c7             	mov    %rax,%rdi
    b144:	e8 07 b3 ff ff       	call   6450 <fwp_rc_fresh>
    b149:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    b150:	00 
    b151:	bf 01 00 00 00       	mov    $0x1,%edi
    b156:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    b15d:	00 
    b15e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    b165:	00 
    b166:	e8 45 ac ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b16b:	48 89 c7             	mov    %rax,%rdi
    b16e:	e8 dd b2 ff ff       	call   6450 <fwp_rc_fresh>
    b173:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    b17a:	00 
    b17b:	bf 01 00 00 00       	mov    $0x1,%edi
    b180:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    b187:	00 
    b188:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    b18f:	00 
    b190:	e8 1b ac ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b195:	48 89 c7             	mov    %rax,%rdi
    b198:	e8 b3 b2 ff ff       	call   6450 <fwp_rc_fresh>
    b19d:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    b1a4:	00 
    b1a5:	bf 01 00 00 00       	mov    $0x1,%edi
    b1aa:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    b1b1:	00 
    b1b2:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    b1b9:	00 
    b1ba:	e8 f1 ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b1bf:	48 89 c7             	mov    %rax,%rdi
    b1c2:	e8 89 b2 ff ff       	call   6450 <fwp_rc_fresh>
    b1c7:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    b1ce:	00 
    b1cf:	bf 01 00 00 00       	mov    $0x1,%edi
    b1d4:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    b1db:	00 
    b1dc:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    b1e3:	00 
    b1e4:	e8 c7 ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b1e9:	48 89 c7             	mov    %rax,%rdi
    b1ec:	e8 5f b2 ff ff       	call   6450 <fwp_rc_fresh>
    b1f1:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    b1f8:	00 
    b1f9:	bf 01 00 00 00       	mov    $0x1,%edi
    b1fe:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    b205:	00 
    b206:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    b20d:	00 
    b20e:	e8 9d ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b213:	48 89 c7             	mov    %rax,%rdi
    b216:	e8 35 b2 ff ff       	call   6450 <fwp_rc_fresh>
    b21b:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    b222:	00 
    b223:	bf 01 00 00 00       	mov    $0x1,%edi
    b228:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    b22f:	00 
    b230:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    b237:	00 
    b238:	e8 73 ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b23d:	48 89 c7             	mov    %rax,%rdi
    b240:	e8 0b b2 ff ff       	call   6450 <fwp_rc_fresh>
    b245:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    b24c:	00 
    b24d:	bf 01 00 00 00       	mov    $0x1,%edi
    b252:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    b259:	00 
    b25a:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    b261:	00 
    b262:	e8 49 ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b267:	48 89 c7             	mov    %rax,%rdi
    b26a:	e8 e1 b1 ff ff       	call   6450 <fwp_rc_fresh>
    b26f:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    b276:	00 
    b277:	bf 01 00 00 00       	mov    $0x1,%edi
    b27c:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    b283:	00 
    b284:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    b28b:	00 
    b28c:	e8 1f ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b291:	48 89 c7             	mov    %rax,%rdi
    b294:	e8 b7 b1 ff ff       	call   6450 <fwp_rc_fresh>
    b299:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    b2a0:	00 
    b2a1:	bf 01 00 00 00       	mov    $0x1,%edi
    b2a6:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    b2ad:	00 
    b2ae:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    b2b5:	00 
    b2b6:	e8 f5 aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b2bb:	48 89 c7             	mov    %rax,%rdi
    b2be:	e8 8d b1 ff ff       	call   6450 <fwp_rc_fresh>
    b2c3:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    b2ca:	00 
    b2cb:	bf 01 00 00 00       	mov    $0x1,%edi
    b2d0:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    b2d7:	00 
    b2d8:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    b2df:	00 
    b2e0:	e8 cb aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b2e5:	48 89 c7             	mov    %rax,%rdi
    b2e8:	e8 63 b1 ff ff       	call   6450 <fwp_rc_fresh>
    b2ed:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    b2f4:	00 
    b2f5:	bf 01 00 00 00       	mov    $0x1,%edi
    b2fa:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    b301:	00 
    b302:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    b309:	00 
    b30a:	e8 a1 aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b30f:	48 89 c7             	mov    %rax,%rdi
    b312:	e8 39 b1 ff ff       	call   6450 <fwp_rc_fresh>
    b317:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    b31e:	00 
    b31f:	bf 01 00 00 00       	mov    $0x1,%edi
    b324:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    b32b:	00 
    b32c:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    b333:	00 
    b334:	e8 77 aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b339:	48 89 c7             	mov    %rax,%rdi
    b33c:	e8 0f b1 ff ff       	call   6450 <fwp_rc_fresh>
    b341:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    b348:	00 
    b349:	bf 01 00 00 00       	mov    $0x1,%edi
    b34e:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    b355:	00 
    b356:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    b35d:	00 
    b35e:	e8 4d aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b363:	48 89 c7             	mov    %rax,%rdi
    b366:	e8 e5 b0 ff ff       	call   6450 <fwp_rc_fresh>
    b36b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    b372:	00 
    b373:	bf 01 00 00 00       	mov    $0x1,%edi
    b378:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    b37f:	00 
    b380:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    b387:	00 
    b388:	e8 23 aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b38d:	48 89 c7             	mov    %rax,%rdi
    b390:	e8 bb b0 ff ff       	call   6450 <fwp_rc_fresh>
    b395:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    b39c:	00 
    b39d:	bf 01 00 00 00       	mov    $0x1,%edi
    b3a2:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    b3a9:	00 
    b3aa:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    b3b1:	00 
    b3b2:	e8 f9 a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b3b7:	48 89 c7             	mov    %rax,%rdi
    b3ba:	e8 91 b0 ff ff       	call   6450 <fwp_rc_fresh>
    b3bf:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    b3c6:	00 
    b3c7:	bf 01 00 00 00       	mov    $0x1,%edi
    b3cc:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    b3d3:	00 
    b3d4:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    b3db:	00 
    b3dc:	e8 cf a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b3e1:	48 89 c7             	mov    %rax,%rdi
    b3e4:	e8 67 b0 ff ff       	call   6450 <fwp_rc_fresh>
    b3e9:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    b3f0:	00 
    b3f1:	bf 01 00 00 00       	mov    $0x1,%edi
    b3f6:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    b3fd:	00 
    b3fe:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    b405:	00 
    b406:	e8 a5 a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b40b:	48 89 c7             	mov    %rax,%rdi
    b40e:	e8 3d b0 ff ff       	call   6450 <fwp_rc_fresh>
    b413:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    b41a:	00 
    b41b:	bf 01 00 00 00       	mov    $0x1,%edi
    b420:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    b427:	00 
    b428:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    b42f:	00 
    b430:	e8 7b a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b435:	48 89 c7             	mov    %rax,%rdi
    b438:	e8 13 b0 ff ff       	call   6450 <fwp_rc_fresh>
    b43d:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    b444:	00 
    b445:	bf 01 00 00 00       	mov    $0x1,%edi
    b44a:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    b451:	00 
    b452:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    b459:	00 
    b45a:	e8 51 a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b45f:	48 89 c7             	mov    %rax,%rdi
    b462:	e8 e9 af ff ff       	call   6450 <fwp_rc_fresh>
    b467:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    b46e:	00 
    b46f:	bf 01 00 00 00       	mov    $0x1,%edi
    b474:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    b47b:	00 
    b47c:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    b483:	00 
    b484:	e8 27 a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b489:	48 89 c7             	mov    %rax,%rdi
    b48c:	e8 bf af ff ff       	call   6450 <fwp_rc_fresh>
    b491:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    b498:	00 
    b499:	bf 01 00 00 00       	mov    $0x1,%edi
    b49e:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    b4a5:	00 
    b4a6:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    b4ad:	00 
    b4ae:	e8 fd a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b4b3:	48 89 c7             	mov    %rax,%rdi
    b4b6:	e8 95 af ff ff       	call   6450 <fwp_rc_fresh>
    b4bb:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    b4c2:	00 
    b4c3:	bf 01 00 00 00       	mov    $0x1,%edi
    b4c8:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    b4cf:	00 
    b4d0:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    b4d7:	00 
    b4d8:	e8 d3 a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b4dd:	48 89 c7             	mov    %rax,%rdi
    b4e0:	e8 6b af ff ff       	call   6450 <fwp_rc_fresh>
    b4e5:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    b4ec:	00 
    b4ed:	bf 01 00 00 00       	mov    $0x1,%edi
    b4f2:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    b4f9:	00 
    b4fa:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    b501:	00 
    b502:	e8 a9 a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b507:	48 89 c7             	mov    %rax,%rdi
    b50a:	e8 41 af ff ff       	call   6450 <fwp_rc_fresh>
    b50f:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    b516:	00 
    b517:	bf 01 00 00 00       	mov    $0x1,%edi
    b51c:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    b523:	00 
    b524:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    b52b:	00 
    b52c:	e8 7f a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b531:	48 89 c7             	mov    %rax,%rdi
    b534:	e8 17 af ff ff       	call   6450 <fwp_rc_fresh>
    b539:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    b540:	00 
    b541:	bf 01 00 00 00       	mov    $0x1,%edi
    b546:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    b54d:	00 
    b54e:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    b555:	00 
    b556:	e8 55 a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b55b:	48 89 c7             	mov    %rax,%rdi
    b55e:	e8 ed ae ff ff       	call   6450 <fwp_rc_fresh>
    b563:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    b56a:	00 
    b56b:	bf 01 00 00 00       	mov    $0x1,%edi
    b570:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    b577:	00 
    b578:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    b57f:	00 
    b580:	e8 2b a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b585:	48 89 c7             	mov    %rax,%rdi
    b588:	e8 c3 ae ff ff       	call   6450 <fwp_rc_fresh>
    b58d:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    b594:	00 
    b595:	bf 01 00 00 00       	mov    $0x1,%edi
    b59a:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    b5a1:	00 
    b5a2:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    b5a9:	00 
    b5aa:	e8 01 a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b5af:	48 89 c7             	mov    %rax,%rdi
    b5b2:	e8 99 ae ff ff       	call   6450 <fwp_rc_fresh>
    b5b7:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    b5be:	00 
    b5bf:	bf 01 00 00 00       	mov    $0x1,%edi
    b5c4:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    b5cb:	00 
    b5cc:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    b5d3:	00 
    b5d4:	e8 d7 a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b5d9:	48 89 c7             	mov    %rax,%rdi
    b5dc:	e8 6f ae ff ff       	call   6450 <fwp_rc_fresh>
    b5e1:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    b5e8:	00 
    b5e9:	bf 01 00 00 00       	mov    $0x1,%edi
    b5ee:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    b5f5:	00 
    b5f6:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    b5fd:	00 
    b5fe:	e8 ad a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b603:	48 89 c7             	mov    %rax,%rdi
    b606:	e8 45 ae ff ff       	call   6450 <fwp_rc_fresh>
    b60b:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    b612:	00 
    b613:	bf 01 00 00 00       	mov    $0x1,%edi
    b618:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    b61f:	00 
    b620:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    b627:	00 
    b628:	e8 83 a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b62d:	48 89 c7             	mov    %rax,%rdi
    b630:	e8 1b ae ff ff       	call   6450 <fwp_rc_fresh>
    b635:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    b63c:	00 
    b63d:	bf 01 00 00 00       	mov    $0x1,%edi
    b642:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    b649:	00 
    b64a:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    b651:	00 
    b652:	e8 59 a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b657:	48 89 c7             	mov    %rax,%rdi
    b65a:	e8 f1 ad ff ff       	call   6450 <fwp_rc_fresh>
    b65f:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    b666:	00 
    b667:	bf 01 00 00 00       	mov    $0x1,%edi
    b66c:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    b673:	00 
    b674:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    b67b:	00 
    b67c:	e8 2f a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b681:	48 89 c7             	mov    %rax,%rdi
    b684:	e8 c7 ad ff ff       	call   6450 <fwp_rc_fresh>
    b689:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    b690:	00 
    b691:	bf 01 00 00 00       	mov    $0x1,%edi
    b696:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    b69d:	00 
    b69e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    b6a5:	00 
    b6a6:	e8 05 a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b6ab:	48 89 c7             	mov    %rax,%rdi
    b6ae:	e8 9d ad ff ff       	call   6450 <fwp_rc_fresh>
    b6b3:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    b6ba:	00 
    b6bb:	bf 01 00 00 00       	mov    $0x1,%edi
    b6c0:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    b6c7:	00 
    b6c8:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    b6cf:	00 
    b6d0:	e8 db a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b6d5:	48 89 c7             	mov    %rax,%rdi
    b6d8:	e8 73 ad ff ff       	call   6450 <fwp_rc_fresh>
    b6dd:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    b6e4:	00 
    b6e5:	bf 01 00 00 00       	mov    $0x1,%edi
    b6ea:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    b6f1:	00 
    b6f2:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    b6f9:	00 
    b6fa:	e8 b1 a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b6ff:	48 89 c7             	mov    %rax,%rdi
    b702:	e8 49 ad ff ff       	call   6450 <fwp_rc_fresh>
    b707:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    b70e:	00 
    b70f:	bf 01 00 00 00       	mov    $0x1,%edi
    b714:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    b71b:	00 
    b71c:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    b723:	00 
    b724:	e8 87 a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b729:	48 89 c7             	mov    %rax,%rdi
    b72c:	e8 1f ad ff ff       	call   6450 <fwp_rc_fresh>
    b731:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    b738:	00 
    b739:	bf 01 00 00 00       	mov    $0x1,%edi
    b73e:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    b745:	00 
    b746:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    b74d:	00 
    b74e:	e8 5d a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b753:	48 89 c7             	mov    %rax,%rdi
    b756:	e8 f5 ac ff ff       	call   6450 <fwp_rc_fresh>
    b75b:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    b762:	00 
    b763:	bf 01 00 00 00       	mov    $0x1,%edi
    b768:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    b76f:	00 
    b770:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    b777:	00 
    b778:	e8 33 a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b77d:	48 89 c7             	mov    %rax,%rdi
    b780:	e8 cb ac ff ff       	call   6450 <fwp_rc_fresh>
    b785:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    b78c:	00 
    b78d:	bf 01 00 00 00       	mov    $0x1,%edi
    b792:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    b799:	00 
    b79a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    b7a1:	00 
    b7a2:	e8 09 a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b7a7:	48 89 c7             	mov    %rax,%rdi
    b7aa:	e8 a1 ac ff ff       	call   6450 <fwp_rc_fresh>
    b7af:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    b7b6:	00 
    b7b7:	bf 01 00 00 00       	mov    $0x1,%edi
    b7bc:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    b7c3:	00 
    b7c4:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    b7cb:	00 
    b7cc:	e8 df a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b7d1:	48 89 c7             	mov    %rax,%rdi
    b7d4:	e8 77 ac ff ff       	call   6450 <fwp_rc_fresh>
    b7d9:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    b7e0:	00 
    b7e1:	bf 01 00 00 00       	mov    $0x1,%edi
    b7e6:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    b7ed:	00 
    b7ee:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    b7f5:	00 
    b7f6:	e8 b5 a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b7fb:	48 89 c7             	mov    %rax,%rdi
    b7fe:	e8 4d ac ff ff       	call   6450 <fwp_rc_fresh>
    b803:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    b80a:	00 
    b80b:	bf 01 00 00 00       	mov    $0x1,%edi
    b810:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    b817:	00 
    b818:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    b81f:	00 
    b820:	e8 8b a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b825:	48 89 c7             	mov    %rax,%rdi
    b828:	e8 23 ac ff ff       	call   6450 <fwp_rc_fresh>
    b82d:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    b834:	00 
    b835:	bf 01 00 00 00       	mov    $0x1,%edi
    b83a:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    b841:	00 
    b842:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    b849:	00 
    b84a:	e8 61 a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b84f:	48 89 c7             	mov    %rax,%rdi
    b852:	e8 f9 ab ff ff       	call   6450 <fwp_rc_fresh>
    b857:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    b85e:	00 
    b85f:	bf 01 00 00 00       	mov    $0x1,%edi
    b864:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    b86b:	00 
    b86c:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    b873:	00 
    b874:	e8 37 a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b879:	48 89 c7             	mov    %rax,%rdi
    b87c:	e8 cf ab ff ff       	call   6450 <fwp_rc_fresh>
    b881:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    b888:	00 
    b889:	bf 01 00 00 00       	mov    $0x1,%edi
    b88e:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    b895:	00 
    b896:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    b89d:	00 
    b89e:	e8 0d a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b8a3:	48 89 c7             	mov    %rax,%rdi
    b8a6:	e8 a5 ab ff ff       	call   6450 <fwp_rc_fresh>
    b8ab:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    b8b2:	00 
    b8b3:	bf 01 00 00 00       	mov    $0x1,%edi
    b8b8:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    b8bf:	00 
    b8c0:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    b8c7:	00 
    b8c8:	e8 e3 a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b8cd:	48 89 c7             	mov    %rax,%rdi
    b8d0:	e8 7b ab ff ff       	call   6450 <fwp_rc_fresh>
    b8d5:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    b8dc:	00 
    b8dd:	bf 01 00 00 00       	mov    $0x1,%edi
    b8e2:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    b8e9:	00 
    b8ea:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    b8f1:	00 
    b8f2:	e8 b9 a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b8f7:	48 89 c7             	mov    %rax,%rdi
    b8fa:	e8 51 ab ff ff       	call   6450 <fwp_rc_fresh>
    b8ff:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    b906:	00 
    b907:	bf 01 00 00 00       	mov    $0x1,%edi
    b90c:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    b913:	00 
    b914:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    b91b:	00 
    b91c:	e8 8f a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b921:	48 89 c7             	mov    %rax,%rdi
    b924:	e8 27 ab ff ff       	call   6450 <fwp_rc_fresh>
    b929:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    b930:	00 
    b931:	bf 01 00 00 00       	mov    $0x1,%edi
    b936:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    b93d:	00 
    b93e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    b945:	00 
    b946:	e8 65 a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b94b:	48 89 c7             	mov    %rax,%rdi
    b94e:	e8 fd aa ff ff       	call   6450 <fwp_rc_fresh>
    b953:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    b95a:	00 
    b95b:	bf 01 00 00 00       	mov    $0x1,%edi
    b960:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    b967:	00 
    b968:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    b96f:	00 
    b970:	e8 3b a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b975:	48 89 c7             	mov    %rax,%rdi
    b978:	e8 d3 aa ff ff       	call   6450 <fwp_rc_fresh>
    b97d:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    b984:	00 
    b985:	bf 01 00 00 00       	mov    $0x1,%edi
    b98a:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    b991:	00 
    b992:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    b999:	00 
    b99a:	e8 11 a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b99f:	48 89 c7             	mov    %rax,%rdi
    b9a2:	e8 a9 aa ff ff       	call   6450 <fwp_rc_fresh>
    b9a7:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    b9ae:	00 
    b9af:	bf 01 00 00 00       	mov    $0x1,%edi
    b9b4:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    b9bb:	00 
    b9bc:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    b9c3:	00 
    b9c4:	e8 e7 a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b9c9:	48 89 c7             	mov    %rax,%rdi
    b9cc:	e8 7f aa ff ff       	call   6450 <fwp_rc_fresh>
    b9d1:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    b9d8:	00 
    b9d9:	bf 01 00 00 00       	mov    $0x1,%edi
    b9de:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    b9e5:	00 
    b9e6:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    b9ed:	00 
    b9ee:	e8 bd a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b9f3:	48 89 c7             	mov    %rax,%rdi
    b9f6:	e8 55 aa ff ff       	call   6450 <fwp_rc_fresh>
    b9fb:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    ba02:	00 
    ba03:	bf 01 00 00 00       	mov    $0x1,%edi
    ba08:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    ba0f:	00 
    ba10:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    ba17:	00 
    ba18:	e8 93 a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ba1d:	48 89 c7             	mov    %rax,%rdi
    ba20:	e8 2b aa ff ff       	call   6450 <fwp_rc_fresh>
    ba25:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    ba2c:	00 
    ba2d:	bf 01 00 00 00       	mov    $0x1,%edi
    ba32:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    ba39:	00 
    ba3a:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    ba41:	00 
    ba42:	e8 69 a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ba47:	48 89 c7             	mov    %rax,%rdi
    ba4a:	e8 01 aa ff ff       	call   6450 <fwp_rc_fresh>
    ba4f:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    ba56:	00 
    ba57:	bf 01 00 00 00       	mov    $0x1,%edi
    ba5c:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    ba63:	00 
    ba64:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    ba6b:	00 
    ba6c:	e8 3f a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ba71:	48 89 c7             	mov    %rax,%rdi
    ba74:	e8 d7 a9 ff ff       	call   6450 <fwp_rc_fresh>
    ba79:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    ba80:	00 
    ba81:	bf 01 00 00 00       	mov    $0x1,%edi
    ba86:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    ba8d:	00 
    ba8e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    ba95:	00 
    ba96:	e8 15 a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ba9b:	48 89 c7             	mov    %rax,%rdi
    ba9e:	e8 ad a9 ff ff       	call   6450 <fwp_rc_fresh>
    baa3:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    baaa:	00 
    baab:	bf 01 00 00 00       	mov    $0x1,%edi
    bab0:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    bab7:	00 
    bab8:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    babf:	00 
    bac0:	e8 eb a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bac5:	48 89 c7             	mov    %rax,%rdi
    bac8:	e8 83 a9 ff ff       	call   6450 <fwp_rc_fresh>
    bacd:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    bad4:	00 
    bad5:	bf 01 00 00 00       	mov    $0x1,%edi
    bada:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    bae1:	00 
    bae2:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    bae9:	00 
    baea:	e8 c1 a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    baef:	48 89 c7             	mov    %rax,%rdi
    baf2:	e8 59 a9 ff ff       	call   6450 <fwp_rc_fresh>
    baf7:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    bafe:	00 
    baff:	bf 01 00 00 00       	mov    $0x1,%edi
    bb04:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    bb0b:	00 
    bb0c:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    bb13:	00 
    bb14:	e8 97 a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bb19:	48 89 c7             	mov    %rax,%rdi
    bb1c:	e8 2f a9 ff ff       	call   6450 <fwp_rc_fresh>
    bb21:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    bb28:	00 
    bb29:	bf 01 00 00 00       	mov    $0x1,%edi
    bb2e:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    bb35:	00 
    bb36:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    bb3d:	00 
    bb3e:	e8 6d a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bb43:	48 89 c7             	mov    %rax,%rdi
    bb46:	e8 05 a9 ff ff       	call   6450 <fwp_rc_fresh>
    bb4b:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    bb52:	00 
    bb53:	bf 01 00 00 00       	mov    $0x1,%edi
    bb58:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    bb5f:	00 
    bb60:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    bb67:	00 
    bb68:	e8 43 a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bb6d:	48 89 c7             	mov    %rax,%rdi
    bb70:	e8 db a8 ff ff       	call   6450 <fwp_rc_fresh>
    bb75:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    bb7c:	00 
    bb7d:	bf 01 00 00 00       	mov    $0x1,%edi
    bb82:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    bb89:	00 
    bb8a:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    bb91:	00 
    bb92:	e8 19 a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bb97:	48 89 c7             	mov    %rax,%rdi
    bb9a:	e8 b1 a8 ff ff       	call   6450 <fwp_rc_fresh>
    bb9f:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    bba6:	00 
    bba7:	bf 01 00 00 00       	mov    $0x1,%edi
    bbac:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    bbb3:	00 
    bbb4:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    bbbb:	00 
    bbbc:	e8 ef a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bbc1:	48 89 c7             	mov    %rax,%rdi
    bbc4:	e8 87 a8 ff ff       	call   6450 <fwp_rc_fresh>
    bbc9:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    bbd0:	00 
    bbd1:	bf 01 00 00 00       	mov    $0x1,%edi
    bbd6:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    bbdd:	00 
    bbde:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    bbe5:	00 
    bbe6:	e8 c5 a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bbeb:	48 89 c7             	mov    %rax,%rdi
    bbee:	e8 5d a8 ff ff       	call   6450 <fwp_rc_fresh>
    bbf3:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    bbfa:	00 
    bbfb:	bf 01 00 00 00       	mov    $0x1,%edi
    bc00:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    bc07:	00 
    bc08:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    bc0f:	00 
    bc10:	e8 9b a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bc15:	48 89 c7             	mov    %rax,%rdi
    bc18:	e8 33 a8 ff ff       	call   6450 <fwp_rc_fresh>
    bc1d:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    bc24:	00 
    bc25:	bf 01 00 00 00       	mov    $0x1,%edi
    bc2a:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    bc31:	00 
    bc32:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    bc39:	00 
    bc3a:	e8 71 a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bc3f:	48 89 c7             	mov    %rax,%rdi
    bc42:	e8 09 a8 ff ff       	call   6450 <fwp_rc_fresh>
    bc47:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    bc4e:	00 
    bc4f:	bf 01 00 00 00       	mov    $0x1,%edi
    bc54:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    bc5b:	00 
    bc5c:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    bc63:	00 
    bc64:	e8 47 a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bc69:	48 89 c7             	mov    %rax,%rdi
    bc6c:	e8 df a7 ff ff       	call   6450 <fwp_rc_fresh>
    bc71:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    bc78:	00 
    bc79:	bf 01 00 00 00       	mov    $0x1,%edi
    bc7e:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    bc85:	00 
    bc86:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    bc8d:	00 
    bc8e:	e8 1d a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bc93:	48 89 c7             	mov    %rax,%rdi
    bc96:	e8 b5 a7 ff ff       	call   6450 <fwp_rc_fresh>
    bc9b:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    bca2:	00 
    bca3:	bf 01 00 00 00       	mov    $0x1,%edi
    bca8:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    bcaf:	00 
    bcb0:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    bcb7:	00 
    bcb8:	e8 f3 a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bcbd:	48 89 c7             	mov    %rax,%rdi
    bcc0:	e8 8b a7 ff ff       	call   6450 <fwp_rc_fresh>
    bcc5:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    bccc:	00 
    bccd:	bf 01 00 00 00       	mov    $0x1,%edi
    bcd2:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    bcd9:	00 
    bcda:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    bce1:	00 
    bce2:	e8 c9 a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bce7:	48 89 c7             	mov    %rax,%rdi
    bcea:	e8 61 a7 ff ff       	call   6450 <fwp_rc_fresh>
    bcef:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    bcf6:	00 
    bcf7:	bf 01 00 00 00       	mov    $0x1,%edi
    bcfc:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    bd03:	00 
    bd04:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    bd0b:	00 
    bd0c:	e8 9f a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bd11:	48 89 c7             	mov    %rax,%rdi
    bd14:	e8 37 a7 ff ff       	call   6450 <fwp_rc_fresh>
    bd19:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    bd20:	00 
    bd21:	bf 01 00 00 00       	mov    $0x1,%edi
    bd26:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    bd2d:	00 
    bd2e:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    bd35:	00 
    bd36:	e8 75 a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bd3b:	48 89 c7             	mov    %rax,%rdi
    bd3e:	e8 0d a7 ff ff       	call   6450 <fwp_rc_fresh>
    bd43:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    bd4a:	00 
    bd4b:	bf 01 00 00 00       	mov    $0x1,%edi
    bd50:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    bd57:	00 
    bd58:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    bd5f:	00 
    bd60:	e8 4b a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bd65:	48 89 c7             	mov    %rax,%rdi
    bd68:	e8 e3 a6 ff ff       	call   6450 <fwp_rc_fresh>
    bd6d:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    bd74:	00 
    bd75:	bf 01 00 00 00       	mov    $0x1,%edi
    bd7a:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    bd81:	00 
    bd82:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    bd89:	00 
    bd8a:	e8 21 a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bd8f:	48 89 c7             	mov    %rax,%rdi
    bd92:	e8 b9 a6 ff ff       	call   6450 <fwp_rc_fresh>
    bd97:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    bd9e:	00 
    bd9f:	bf 01 00 00 00       	mov    $0x1,%edi
    bda4:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    bdab:	00 
    bdac:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    bdb3:	00 
    bdb4:	e8 f7 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bdb9:	48 89 c7             	mov    %rax,%rdi
    bdbc:	e8 8f a6 ff ff       	call   6450 <fwp_rc_fresh>
    bdc1:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    bdc8:	00 
    bdc9:	bf 01 00 00 00       	mov    $0x1,%edi
    bdce:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    bdd5:	00 
    bdd6:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    bddd:	00 
    bdde:	e8 cd 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bde3:	48 89 c7             	mov    %rax,%rdi
    bde6:	e8 65 a6 ff ff       	call   6450 <fwp_rc_fresh>
    bdeb:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    bdf2:	00 
    bdf3:	bf 01 00 00 00       	mov    $0x1,%edi
    bdf8:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    bdff:	00 
    be00:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    be07:	00 
    be08:	e8 a3 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    be0d:	48 89 c7             	mov    %rax,%rdi
    be10:	e8 3b a6 ff ff       	call   6450 <fwp_rc_fresh>
    be15:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    be1c:	00 
    be1d:	bf 01 00 00 00       	mov    $0x1,%edi
    be22:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    be29:	00 
    be2a:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    be31:	00 
    be32:	e8 79 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    be37:	48 89 c7             	mov    %rax,%rdi
    be3a:	e8 11 a6 ff ff       	call   6450 <fwp_rc_fresh>
    be3f:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    be46:	00 
    be47:	bf 01 00 00 00       	mov    $0x1,%edi
    be4c:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    be53:	00 
    be54:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    be5b:	00 
    be5c:	e8 4f 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    be61:	48 89 c7             	mov    %rax,%rdi
    be64:	e8 e7 a5 ff ff       	call   6450 <fwp_rc_fresh>
    be69:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    be70:	00 
    be71:	bf 01 00 00 00       	mov    $0x1,%edi
    be76:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    be7d:	00 
    be7e:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    be85:	00 
    be86:	e8 25 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    be8b:	48 89 c7             	mov    %rax,%rdi
    be8e:	e8 bd a5 ff ff       	call   6450 <fwp_rc_fresh>
    be93:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    be9a:	00 
    be9b:	bf 01 00 00 00       	mov    $0x1,%edi
    bea0:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    bea7:	00 
    bea8:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    beaf:	00 
    beb0:	e8 fb 9e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    beb5:	48 8b 15 dc 8c 01 00 	mov    0x18cdc(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    bebc:	49 89 c5             	mov    %rax,%r13
    bebf:	48 2b 05 aa 8c 01 00 	sub    0x18caa(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    bec6:	48 c1 e2 10          	shl    $0x10,%rdx
    beca:	48 39 d0             	cmp    %rdx,%rax
    becd:	73 59                	jae    bf28 <f0+0x13b8>
    becf:	48 89 c2             	mov    %rax,%rdx
    bed2:	48 c1 ea 10          	shr    $0x10,%rdx
    bed6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    beda:	48 8b 15 d7 8c 01 00 	mov    0x18cd7(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    bee1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bee5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bee9:	4d 85 e4             	test   %r12,%r12
    beec:	74 3a                	je     bf28 <f0+0x13b8>
    beee:	0f b6 0a             	movzbl (%rdx),%ecx
    bef1:	80 f9 02             	cmp    $0x2,%cl
    bef4:	0f 84 c6 15 00 00    	je     d4c0 <f0+0x2950>
    befa:	80 f9 01             	cmp    $0x1,%cl
    befd:	75 29                	jne    bf28 <f0+0x13b8>
    beff:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bf02:	0f b7 c0             	movzwl %ax,%eax
    bf05:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bf08:	48 0f af c1          	imul   %rcx,%rax
    bf0c:	48 c1 e8 20          	shr    $0x20,%rax
    bf10:	48 39 d0             	cmp    %rdx,%rax
    bf13:	73 13                	jae    bf28 <f0+0x13b8>
    bf15:	49 01 c4             	add    %rax,%r12
    bf18:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bf1d:	0f 84 99 17 00 00    	je     d6bc <f0+0x2b4c>
    bf23:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bf28:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    bf2f:	33 f3 bf 
    bf32:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    bf39:	00 
    bf3a:	bf 01 00 00 00       	mov    $0x1,%edi
    bf3f:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    bf46:	00 
    bf47:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    bf4e:	00 
    bf4f:	e8 5c 9e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bf54:	48 8b 15 3d 8c 01 00 	mov    0x18c3d(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    bf5b:	49 89 c5             	mov    %rax,%r13
    bf5e:	48 2b 05 0b 8c 01 00 	sub    0x18c0b(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    bf65:	48 c1 e2 10          	shl    $0x10,%rdx
    bf69:	48 39 d0             	cmp    %rdx,%rax
    bf6c:	73 59                	jae    bfc7 <f0+0x1457>
    bf6e:	48 89 c2             	mov    %rax,%rdx
    bf71:	48 c1 ea 10          	shr    $0x10,%rdx
    bf75:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bf79:	48 8b 15 38 8c 01 00 	mov    0x18c38(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    bf80:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bf84:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bf88:	4d 85 e4             	test   %r12,%r12
    bf8b:	74 3a                	je     bfc7 <f0+0x1457>
    bf8d:	0f b6 0a             	movzbl (%rdx),%ecx
    bf90:	80 f9 02             	cmp    $0x2,%cl
    bf93:	0f 84 17 15 00 00    	je     d4b0 <f0+0x2940>
    bf99:	80 f9 01             	cmp    $0x1,%cl
    bf9c:	75 29                	jne    bfc7 <f0+0x1457>
    bf9e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bfa1:	0f b7 c0             	movzwl %ax,%eax
    bfa4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bfa7:	48 0f af c1          	imul   %rcx,%rax
    bfab:	48 c1 e8 20          	shr    $0x20,%rax
    bfaf:	48 39 d0             	cmp    %rdx,%rax
    bfb2:	73 13                	jae    bfc7 <f0+0x1457>
    bfb4:	49 01 c4             	add    %rax,%r12
    bfb7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bfbc:	0f 84 07 17 00 00    	je     d6c9 <f0+0x2b59>
    bfc2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bfc7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    bfce:	00 f0 3f 
    bfd1:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    bfd8:	00 
    bfd9:	bf 01 00 00 00       	mov    $0x1,%edi
    bfde:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    bfe5:	00 
    bfe6:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    bfed:	00 
    bfee:	e8 bd 9d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bff3:	48 8b 15 9e 8b 01 00 	mov    0x18b9e(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    bffa:	49 89 c5             	mov    %rax,%r13
    bffd:	48 2b 05 6c 8b 01 00 	sub    0x18b6c(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c004:	48 c1 e2 10          	shl    $0x10,%rdx
    c008:	48 39 d0             	cmp    %rdx,%rax
    c00b:	73 59                	jae    c066 <f0+0x14f6>
    c00d:	48 89 c2             	mov    %rax,%rdx
    c010:	48 c1 ea 10          	shr    $0x10,%rdx
    c014:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c018:	48 8b 15 99 8b 01 00 	mov    0x18b99(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c01f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c023:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c027:	4d 85 e4             	test   %r12,%r12
    c02a:	74 3a                	je     c066 <f0+0x14f6>
    c02c:	0f b6 0a             	movzbl (%rdx),%ecx
    c02f:	80 f9 02             	cmp    $0x2,%cl
    c032:	0f 84 28 15 00 00    	je     d560 <f0+0x29f0>
    c038:	80 f9 01             	cmp    $0x1,%cl
    c03b:	75 29                	jne    c066 <f0+0x14f6>
    c03d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c040:	0f b7 c0             	movzwl %ax,%eax
    c043:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c046:	48 0f af c1          	imul   %rcx,%rax
    c04a:	48 c1 e8 20          	shr    $0x20,%rax
    c04e:	48 39 d0             	cmp    %rdx,%rax
    c051:	73 13                	jae    c066 <f0+0x14f6>
    c053:	49 01 c4             	add    %rax,%r12
    c056:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c05b:	0f 84 75 16 00 00    	je     d6d6 <f0+0x2b66>
    c061:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c066:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c06d:	33 f3 bf 
    c070:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    c077:	00 
    c078:	bf 01 00 00 00       	mov    $0x1,%edi
    c07d:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    c084:	00 
    c085:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    c08c:	00 
    c08d:	e8 1e 9d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c092:	48 8b 15 ff 8a 01 00 	mov    0x18aff(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c099:	49 89 c5             	mov    %rax,%r13
    c09c:	48 2b 05 cd 8a 01 00 	sub    0x18acd(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c0a3:	48 c1 e2 10          	shl    $0x10,%rdx
    c0a7:	48 39 d0             	cmp    %rdx,%rax
    c0aa:	73 59                	jae    c105 <f0+0x1595>
    c0ac:	48 89 c2             	mov    %rax,%rdx
    c0af:	48 c1 ea 10          	shr    $0x10,%rdx
    c0b3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c0b7:	48 8b 15 fa 8a 01 00 	mov    0x18afa(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c0be:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c0c2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c0c6:	4d 85 e4             	test   %r12,%r12
    c0c9:	74 3a                	je     c105 <f0+0x1595>
    c0cb:	0f b6 0a             	movzbl (%rdx),%ecx
    c0ce:	80 f9 02             	cmp    $0x2,%cl
    c0d1:	0f 84 79 14 00 00    	je     d550 <f0+0x29e0>
    c0d7:	80 f9 01             	cmp    $0x1,%cl
    c0da:	75 29                	jne    c105 <f0+0x1595>
    c0dc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c0df:	0f b7 c0             	movzwl %ax,%eax
    c0e2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c0e5:	48 0f af c1          	imul   %rcx,%rax
    c0e9:	48 c1 e8 20          	shr    $0x20,%rax
    c0ed:	48 39 d0             	cmp    %rdx,%rax
    c0f0:	73 13                	jae    c105 <f0+0x1595>
    c0f2:	49 01 c4             	add    %rax,%r12
    c0f5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c0fa:	0f 84 e3 15 00 00    	je     d6e3 <f0+0x2b73>
    c100:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c105:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c10c:	00 f0 3f 
    c10f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    c116:	00 
    c117:	bf 01 00 00 00       	mov    $0x1,%edi
    c11c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    c123:	00 
    c124:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    c12b:	00 
    c12c:	e8 7f 9c ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c131:	48 8b 15 60 8a 01 00 	mov    0x18a60(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c138:	49 89 c5             	mov    %rax,%r13
    c13b:	48 2b 05 2e 8a 01 00 	sub    0x18a2e(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c142:	48 c1 e2 10          	shl    $0x10,%rdx
    c146:	48 39 d0             	cmp    %rdx,%rax
    c149:	73 59                	jae    c1a4 <f0+0x1634>
    c14b:	48 89 c2             	mov    %rax,%rdx
    c14e:	48 c1 ea 10          	shr    $0x10,%rdx
    c152:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c156:	48 8b 15 5b 8a 01 00 	mov    0x18a5b(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c15d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c161:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c165:	4d 85 e4             	test   %r12,%r12
    c168:	74 3a                	je     c1a4 <f0+0x1634>
    c16a:	0f b6 0a             	movzbl (%rdx),%ecx
    c16d:	80 f9 02             	cmp    $0x2,%cl
    c170:	0f 84 ca 13 00 00    	je     d540 <f0+0x29d0>
    c176:	80 f9 01             	cmp    $0x1,%cl
    c179:	75 29                	jne    c1a4 <f0+0x1634>
    c17b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c17e:	0f b7 c0             	movzwl %ax,%eax
    c181:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c184:	48 0f af c1          	imul   %rcx,%rax
    c188:	48 c1 e8 20          	shr    $0x20,%rax
    c18c:	48 39 d0             	cmp    %rdx,%rax
    c18f:	73 13                	jae    c1a4 <f0+0x1634>
    c191:	49 01 c4             	add    %rax,%r12
    c194:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c199:	0f 84 51 15 00 00    	je     d6f0 <f0+0x2b80>
    c19f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c1a4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c1ab:	33 f3 bf 
    c1ae:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    c1b5:	00 
    c1b6:	bf 01 00 00 00       	mov    $0x1,%edi
    c1bb:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    c1c2:	00 
    c1c3:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    c1ca:	00 
    c1cb:	e8 e0 9b ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c1d0:	48 8b 15 c1 89 01 00 	mov    0x189c1(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c1d7:	49 89 c5             	mov    %rax,%r13
    c1da:	48 2b 05 8f 89 01 00 	sub    0x1898f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c1e1:	48 c1 e2 10          	shl    $0x10,%rdx
    c1e5:	48 39 d0             	cmp    %rdx,%rax
    c1e8:	73 59                	jae    c243 <f0+0x16d3>
    c1ea:	48 89 c2             	mov    %rax,%rdx
    c1ed:	48 c1 ea 10          	shr    $0x10,%rdx
    c1f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c1f5:	48 8b 15 bc 89 01 00 	mov    0x189bc(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c1fc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c200:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c204:	4d 85 e4             	test   %r12,%r12
    c207:	74 3a                	je     c243 <f0+0x16d3>
    c209:	0f b6 0a             	movzbl (%rdx),%ecx
    c20c:	80 f9 02             	cmp    $0x2,%cl
    c20f:	0f 84 1b 13 00 00    	je     d530 <f0+0x29c0>
    c215:	80 f9 01             	cmp    $0x1,%cl
    c218:	75 29                	jne    c243 <f0+0x16d3>
    c21a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c21d:	0f b7 c0             	movzwl %ax,%eax
    c220:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c223:	48 0f af c1          	imul   %rcx,%rax
    c227:	48 c1 e8 20          	shr    $0x20,%rax
    c22b:	48 39 d0             	cmp    %rdx,%rax
    c22e:	73 13                	jae    c243 <f0+0x16d3>
    c230:	49 01 c4             	add    %rax,%r12
    c233:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c238:	0f 84 bf 14 00 00    	je     d6fd <f0+0x2b8d>
    c23e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c243:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c24a:	00 f0 3f 
    c24d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    c254:	00 
    c255:	bf 01 00 00 00       	mov    $0x1,%edi
    c25a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    c261:	00 
    c262:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    c269:	00 
    c26a:	e8 41 9b ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c26f:	48 8b 15 22 89 01 00 	mov    0x18922(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c276:	49 89 c5             	mov    %rax,%r13
    c279:	48 2b 05 f0 88 01 00 	sub    0x188f0(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c280:	48 c1 e2 10          	shl    $0x10,%rdx
    c284:	48 39 d0             	cmp    %rdx,%rax
    c287:	73 59                	jae    c2e2 <f0+0x1772>
    c289:	48 89 c2             	mov    %rax,%rdx
    c28c:	48 c1 ea 10          	shr    $0x10,%rdx
    c290:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c294:	48 8b 15 1d 89 01 00 	mov    0x1891d(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c29b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c29f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c2a3:	4d 85 e4             	test   %r12,%r12
    c2a6:	74 3a                	je     c2e2 <f0+0x1772>
    c2a8:	0f b6 0a             	movzbl (%rdx),%ecx
    c2ab:	80 f9 02             	cmp    $0x2,%cl
    c2ae:	0f 84 6c 12 00 00    	je     d520 <f0+0x29b0>
    c2b4:	80 f9 01             	cmp    $0x1,%cl
    c2b7:	75 29                	jne    c2e2 <f0+0x1772>
    c2b9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c2bc:	0f b7 c0             	movzwl %ax,%eax
    c2bf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c2c2:	48 0f af c1          	imul   %rcx,%rax
    c2c6:	48 c1 e8 20          	shr    $0x20,%rax
    c2ca:	48 39 d0             	cmp    %rdx,%rax
    c2cd:	73 13                	jae    c2e2 <f0+0x1772>
    c2cf:	49 01 c4             	add    %rax,%r12
    c2d2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c2d7:	0f 84 2d 14 00 00    	je     d70a <f0+0x2b9a>
    c2dd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c2e2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c2e9:	33 f3 bf 
    c2ec:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    c2f3:	00 
    c2f4:	bf 01 00 00 00       	mov    $0x1,%edi
    c2f9:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    c300:	00 
    c301:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    c308:	00 
    c309:	e8 a2 9a ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c30e:	48 8b 15 83 88 01 00 	mov    0x18883(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c315:	49 89 c5             	mov    %rax,%r13
    c318:	48 2b 05 51 88 01 00 	sub    0x18851(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c31f:	48 c1 e2 10          	shl    $0x10,%rdx
    c323:	48 39 d0             	cmp    %rdx,%rax
    c326:	73 59                	jae    c381 <f0+0x1811>
    c328:	48 89 c2             	mov    %rax,%rdx
    c32b:	48 c1 ea 10          	shr    $0x10,%rdx
    c32f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c333:	48 8b 15 7e 88 01 00 	mov    0x1887e(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c33a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c33e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c342:	4d 85 e4             	test   %r12,%r12
    c345:	74 3a                	je     c381 <f0+0x1811>
    c347:	0f b6 0a             	movzbl (%rdx),%ecx
    c34a:	80 f9 02             	cmp    $0x2,%cl
    c34d:	0f 84 bd 11 00 00    	je     d510 <f0+0x29a0>
    c353:	80 f9 01             	cmp    $0x1,%cl
    c356:	75 29                	jne    c381 <f0+0x1811>
    c358:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c35b:	0f b7 c0             	movzwl %ax,%eax
    c35e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c361:	48 0f af c1          	imul   %rcx,%rax
    c365:	48 c1 e8 20          	shr    $0x20,%rax
    c369:	48 39 d0             	cmp    %rdx,%rax
    c36c:	73 13                	jae    c381 <f0+0x1811>
    c36e:	49 01 c4             	add    %rax,%r12
    c371:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c376:	0f 84 9b 13 00 00    	je     d717 <f0+0x2ba7>
    c37c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c381:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c388:	00 f0 3f 
    c38b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    c392:	00 
    c393:	bf 01 00 00 00       	mov    $0x1,%edi
    c398:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    c39f:	00 
    c3a0:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    c3a7:	00 
    c3a8:	e8 03 9a ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c3ad:	48 8b 15 e4 87 01 00 	mov    0x187e4(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c3b4:	49 89 c5             	mov    %rax,%r13
    c3b7:	48 2b 05 b2 87 01 00 	sub    0x187b2(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c3be:	48 c1 e2 10          	shl    $0x10,%rdx
    c3c2:	48 39 d0             	cmp    %rdx,%rax
    c3c5:	73 59                	jae    c420 <f0+0x18b0>
    c3c7:	48 89 c2             	mov    %rax,%rdx
    c3ca:	48 c1 ea 10          	shr    $0x10,%rdx
    c3ce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c3d2:	48 8b 15 df 87 01 00 	mov    0x187df(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c3d9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c3dd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c3e1:	4d 85 e4             	test   %r12,%r12
    c3e4:	74 3a                	je     c420 <f0+0x18b0>
    c3e6:	0f b6 0a             	movzbl (%rdx),%ecx
    c3e9:	80 f9 02             	cmp    $0x2,%cl
    c3ec:	0f 84 0e 11 00 00    	je     d500 <f0+0x2990>
    c3f2:	80 f9 01             	cmp    $0x1,%cl
    c3f5:	75 29                	jne    c420 <f0+0x18b0>
    c3f7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c3fa:	0f b7 c0             	movzwl %ax,%eax
    c3fd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c400:	48 0f af c1          	imul   %rcx,%rax
    c404:	48 c1 e8 20          	shr    $0x20,%rax
    c408:	48 39 d0             	cmp    %rdx,%rax
    c40b:	73 13                	jae    c420 <f0+0x18b0>
    c40d:	49 01 c4             	add    %rax,%r12
    c410:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c415:	0f 84 09 13 00 00    	je     d724 <f0+0x2bb4>
    c41b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c420:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c427:	33 f3 bf 
    c42a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    c431:	00 
    c432:	bf 01 00 00 00       	mov    $0x1,%edi
    c437:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    c43e:	00 
    c43f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    c446:	00 
    c447:	e8 64 99 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c44c:	48 8b 15 45 87 01 00 	mov    0x18745(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c453:	49 89 c5             	mov    %rax,%r13
    c456:	48 2b 05 13 87 01 00 	sub    0x18713(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c45d:	48 c1 e2 10          	shl    $0x10,%rdx
    c461:	48 39 d0             	cmp    %rdx,%rax
    c464:	73 59                	jae    c4bf <f0+0x194f>
    c466:	48 89 c2             	mov    %rax,%rdx
    c469:	48 c1 ea 10          	shr    $0x10,%rdx
    c46d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c471:	48 8b 15 40 87 01 00 	mov    0x18740(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c478:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c47c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c480:	4d 85 e4             	test   %r12,%r12
    c483:	74 3a                	je     c4bf <f0+0x194f>
    c485:	0f b6 0a             	movzbl (%rdx),%ecx
    c488:	80 f9 02             	cmp    $0x2,%cl
    c48b:	0f 84 5f 10 00 00    	je     d4f0 <f0+0x2980>
    c491:	80 f9 01             	cmp    $0x1,%cl
    c494:	75 29                	jne    c4bf <f0+0x194f>
    c496:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c499:	0f b7 c0             	movzwl %ax,%eax
    c49c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c49f:	48 0f af c1          	imul   %rcx,%rax
    c4a3:	48 c1 e8 20          	shr    $0x20,%rax
    c4a7:	48 39 d0             	cmp    %rdx,%rax
    c4aa:	73 13                	jae    c4bf <f0+0x194f>
    c4ac:	49 01 c4             	add    %rax,%r12
    c4af:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c4b4:	0f 84 77 12 00 00    	je     d731 <f0+0x2bc1>
    c4ba:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c4bf:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c4c6:	00 f0 3f 
    c4c9:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    c4d0:	00 
    c4d1:	bf 01 00 00 00       	mov    $0x1,%edi
    c4d6:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    c4dd:	00 
    c4de:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    c4e5:	00 
    c4e6:	e8 c5 98 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c4eb:	48 8b 15 a6 86 01 00 	mov    0x186a6(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c4f2:	49 89 c5             	mov    %rax,%r13
    c4f5:	48 2b 05 74 86 01 00 	sub    0x18674(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c4fc:	48 c1 e2 10          	shl    $0x10,%rdx
    c500:	48 39 d0             	cmp    %rdx,%rax
    c503:	73 59                	jae    c55e <f0+0x19ee>
    c505:	48 89 c2             	mov    %rax,%rdx
    c508:	48 c1 ea 10          	shr    $0x10,%rdx
    c50c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c510:	48 8b 15 a1 86 01 00 	mov    0x186a1(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c517:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c51b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c51f:	4d 85 e4             	test   %r12,%r12
    c522:	74 3a                	je     c55e <f0+0x19ee>
    c524:	0f b6 0a             	movzbl (%rdx),%ecx
    c527:	80 f9 02             	cmp    $0x2,%cl
    c52a:	0f 84 40 0f 00 00    	je     d470 <f0+0x2900>
    c530:	80 f9 01             	cmp    $0x1,%cl
    c533:	75 29                	jne    c55e <f0+0x19ee>
    c535:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c538:	0f b7 c0             	movzwl %ax,%eax
    c53b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c53e:	48 0f af c1          	imul   %rcx,%rax
    c542:	48 c1 e8 20          	shr    $0x20,%rax
    c546:	48 39 d0             	cmp    %rdx,%rax
    c549:	73 13                	jae    c55e <f0+0x19ee>
    c54b:	49 01 c4             	add    %rax,%r12
    c54e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c553:	0f 84 e5 11 00 00    	je     d73e <f0+0x2bce>
    c559:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c55e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c565:	33 f3 bf 
    c568:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    c56f:	00 
    c570:	bf 01 00 00 00       	mov    $0x1,%edi
    c575:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    c57c:	00 
    c57d:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    c584:	00 
    c585:	e8 26 98 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c58a:	48 8b 15 07 86 01 00 	mov    0x18607(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c591:	49 89 c5             	mov    %rax,%r13
    c594:	48 2b 05 d5 85 01 00 	sub    0x185d5(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c59b:	48 c1 e2 10          	shl    $0x10,%rdx
    c59f:	48 39 d0             	cmp    %rdx,%rax
    c5a2:	73 59                	jae    c5fd <f0+0x1a8d>
    c5a4:	48 89 c2             	mov    %rax,%rdx
    c5a7:	48 c1 ea 10          	shr    $0x10,%rdx
    c5ab:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c5af:	48 8b 15 02 86 01 00 	mov    0x18602(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c5b6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c5ba:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c5be:	4d 85 e4             	test   %r12,%r12
    c5c1:	74 3a                	je     c5fd <f0+0x1a8d>
    c5c3:	0f b6 0a             	movzbl (%rdx),%ecx
    c5c6:	80 f9 02             	cmp    $0x2,%cl
    c5c9:	0f 84 91 0e 00 00    	je     d460 <f0+0x28f0>
    c5cf:	80 f9 01             	cmp    $0x1,%cl
    c5d2:	75 29                	jne    c5fd <f0+0x1a8d>
    c5d4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c5d7:	0f b7 c0             	movzwl %ax,%eax
    c5da:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c5dd:	48 0f af c1          	imul   %rcx,%rax
    c5e1:	48 c1 e8 20          	shr    $0x20,%rax
    c5e5:	48 39 d0             	cmp    %rdx,%rax
    c5e8:	73 13                	jae    c5fd <f0+0x1a8d>
    c5ea:	49 01 c4             	add    %rax,%r12
    c5ed:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c5f2:	0f 84 53 11 00 00    	je     d74b <f0+0x2bdb>
    c5f8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c5fd:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c604:	00 f0 3f 
    c607:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    c60e:	00 
    c60f:	bf 01 00 00 00       	mov    $0x1,%edi
    c614:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    c61b:	00 
    c61c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    c623:	00 
    c624:	e8 87 97 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c629:	48 8b 15 68 85 01 00 	mov    0x18568(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c630:	49 89 c5             	mov    %rax,%r13
    c633:	48 2b 05 36 85 01 00 	sub    0x18536(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c63a:	48 c1 e2 10          	shl    $0x10,%rdx
    c63e:	48 39 d0             	cmp    %rdx,%rax
    c641:	73 59                	jae    c69c <f0+0x1b2c>
    c643:	48 89 c2             	mov    %rax,%rdx
    c646:	48 c1 ea 10          	shr    $0x10,%rdx
    c64a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c64e:	48 8b 15 63 85 01 00 	mov    0x18563(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c655:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c659:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c65d:	4d 85 e4             	test   %r12,%r12
    c660:	74 3a                	je     c69c <f0+0x1b2c>
    c662:	0f b6 0a             	movzbl (%rdx),%ecx
    c665:	80 f9 02             	cmp    $0x2,%cl
    c668:	0f 84 e2 0d 00 00    	je     d450 <f0+0x28e0>
    c66e:	80 f9 01             	cmp    $0x1,%cl
    c671:	75 29                	jne    c69c <f0+0x1b2c>
    c673:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c676:	0f b7 c0             	movzwl %ax,%eax
    c679:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c67c:	48 0f af c1          	imul   %rcx,%rax
    c680:	48 c1 e8 20          	shr    $0x20,%rax
    c684:	48 39 d0             	cmp    %rdx,%rax
    c687:	73 13                	jae    c69c <f0+0x1b2c>
    c689:	49 01 c4             	add    %rax,%r12
    c68c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c691:	0f 84 c1 10 00 00    	je     d758 <f0+0x2be8>
    c697:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c69c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c6a3:	33 f3 bf 
    c6a6:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    c6ad:	00 
    c6ae:	bf 01 00 00 00       	mov    $0x1,%edi
    c6b3:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    c6ba:	00 
    c6bb:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    c6c2:	00 
    c6c3:	e8 e8 96 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c6c8:	48 8b 15 c9 84 01 00 	mov    0x184c9(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c6cf:	49 89 c5             	mov    %rax,%r13
    c6d2:	48 2b 05 97 84 01 00 	sub    0x18497(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c6d9:	48 c1 e2 10          	shl    $0x10,%rdx
    c6dd:	48 39 d0             	cmp    %rdx,%rax
    c6e0:	73 59                	jae    c73b <f0+0x1bcb>
    c6e2:	48 89 c2             	mov    %rax,%rdx
    c6e5:	48 c1 ea 10          	shr    $0x10,%rdx
    c6e9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c6ed:	48 8b 15 c4 84 01 00 	mov    0x184c4(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c6f4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c6f8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c6fc:	4d 85 e4             	test   %r12,%r12
    c6ff:	74 3a                	je     c73b <f0+0x1bcb>
    c701:	0f b6 0a             	movzbl (%rdx),%ecx
    c704:	80 f9 02             	cmp    $0x2,%cl
    c707:	0f 84 33 0d 00 00    	je     d440 <f0+0x28d0>
    c70d:	80 f9 01             	cmp    $0x1,%cl
    c710:	75 29                	jne    c73b <f0+0x1bcb>
    c712:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c715:	0f b7 c0             	movzwl %ax,%eax
    c718:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c71b:	48 0f af c1          	imul   %rcx,%rax
    c71f:	48 c1 e8 20          	shr    $0x20,%rax
    c723:	48 39 d0             	cmp    %rdx,%rax
    c726:	73 13                	jae    c73b <f0+0x1bcb>
    c728:	49 01 c4             	add    %rax,%r12
    c72b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c730:	0f 84 2f 10 00 00    	je     d765 <f0+0x2bf5>
    c736:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c73b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c742:	00 f0 3f 
    c745:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    c74c:	00 
    c74d:	bf 01 00 00 00       	mov    $0x1,%edi
    c752:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    c759:	00 
    c75a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    c761:	00 
    c762:	e8 49 96 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c767:	48 8b 15 2a 84 01 00 	mov    0x1842a(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c76e:	49 89 c5             	mov    %rax,%r13
    c771:	48 2b 05 f8 83 01 00 	sub    0x183f8(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c778:	48 c1 e2 10          	shl    $0x10,%rdx
    c77c:	48 39 d0             	cmp    %rdx,%rax
    c77f:	73 59                	jae    c7da <f0+0x1c6a>
    c781:	48 89 c2             	mov    %rax,%rdx
    c784:	48 c1 ea 10          	shr    $0x10,%rdx
    c788:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c78c:	48 8b 15 25 84 01 00 	mov    0x18425(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c793:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c797:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c79b:	4d 85 e4             	test   %r12,%r12
    c79e:	74 3a                	je     c7da <f0+0x1c6a>
    c7a0:	0f b6 0a             	movzbl (%rdx),%ecx
    c7a3:	80 f9 02             	cmp    $0x2,%cl
    c7a6:	0f 84 84 0c 00 00    	je     d430 <f0+0x28c0>
    c7ac:	80 f9 01             	cmp    $0x1,%cl
    c7af:	75 29                	jne    c7da <f0+0x1c6a>
    c7b1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c7b4:	0f b7 c0             	movzwl %ax,%eax
    c7b7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c7ba:	48 0f af c1          	imul   %rcx,%rax
    c7be:	48 c1 e8 20          	shr    $0x20,%rax
    c7c2:	48 39 d0             	cmp    %rdx,%rax
    c7c5:	73 13                	jae    c7da <f0+0x1c6a>
    c7c7:	49 01 c4             	add    %rax,%r12
    c7ca:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c7cf:	0f 84 9d 0f 00 00    	je     d772 <f0+0x2c02>
    c7d5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c7da:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c7e1:	33 f3 bf 
    c7e4:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    c7eb:	00 
    c7ec:	bf 01 00 00 00       	mov    $0x1,%edi
    c7f1:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    c7f8:	00 
    c7f9:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    c800:	00 
    c801:	e8 aa 95 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c806:	48 8b 15 8b 83 01 00 	mov    0x1838b(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c80d:	49 89 c5             	mov    %rax,%r13
    c810:	48 2b 05 59 83 01 00 	sub    0x18359(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c817:	48 c1 e2 10          	shl    $0x10,%rdx
    c81b:	48 39 d0             	cmp    %rdx,%rax
    c81e:	73 59                	jae    c879 <f0+0x1d09>
    c820:	48 89 c2             	mov    %rax,%rdx
    c823:	48 c1 ea 10          	shr    $0x10,%rdx
    c827:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c82b:	48 8b 15 86 83 01 00 	mov    0x18386(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c832:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c836:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c83a:	4d 85 e4             	test   %r12,%r12
    c83d:	74 3a                	je     c879 <f0+0x1d09>
    c83f:	0f b6 0a             	movzbl (%rdx),%ecx
    c842:	80 f9 02             	cmp    $0x2,%cl
    c845:	0f 84 d5 0b 00 00    	je     d420 <f0+0x28b0>
    c84b:	80 f9 01             	cmp    $0x1,%cl
    c84e:	75 29                	jne    c879 <f0+0x1d09>
    c850:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c853:	0f b7 c0             	movzwl %ax,%eax
    c856:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c859:	48 0f af c1          	imul   %rcx,%rax
    c85d:	48 c1 e8 20          	shr    $0x20,%rax
    c861:	48 39 d0             	cmp    %rdx,%rax
    c864:	73 13                	jae    c879 <f0+0x1d09>
    c866:	49 01 c4             	add    %rax,%r12
    c869:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c86e:	0f 84 0b 0f 00 00    	je     d77f <f0+0x2c0f>
    c874:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c879:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c880:	00 f0 3f 
    c883:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    c88a:	00 
    c88b:	bf 01 00 00 00       	mov    $0x1,%edi
    c890:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    c897:	00 
    c898:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    c89f:	00 
    c8a0:	e8 0b 95 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c8a5:	48 8b 15 ec 82 01 00 	mov    0x182ec(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c8ac:	49 89 c5             	mov    %rax,%r13
    c8af:	48 2b 05 ba 82 01 00 	sub    0x182ba(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c8b6:	48 c1 e2 10          	shl    $0x10,%rdx
    c8ba:	48 39 d0             	cmp    %rdx,%rax
    c8bd:	73 59                	jae    c918 <f0+0x1da8>
    c8bf:	48 89 c2             	mov    %rax,%rdx
    c8c2:	48 c1 ea 10          	shr    $0x10,%rdx
    c8c6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c8ca:	48 8b 15 e7 82 01 00 	mov    0x182e7(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c8d1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c8d5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c8d9:	4d 85 e4             	test   %r12,%r12
    c8dc:	74 3a                	je     c918 <f0+0x1da8>
    c8de:	0f b6 0a             	movzbl (%rdx),%ecx
    c8e1:	80 f9 02             	cmp    $0x2,%cl
    c8e4:	0f 84 26 0b 00 00    	je     d410 <f0+0x28a0>
    c8ea:	80 f9 01             	cmp    $0x1,%cl
    c8ed:	75 29                	jne    c918 <f0+0x1da8>
    c8ef:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c8f2:	0f b7 c0             	movzwl %ax,%eax
    c8f5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c8f8:	48 0f af c1          	imul   %rcx,%rax
    c8fc:	48 c1 e8 20          	shr    $0x20,%rax
    c900:	48 39 d0             	cmp    %rdx,%rax
    c903:	73 13                	jae    c918 <f0+0x1da8>
    c905:	49 01 c4             	add    %rax,%r12
    c908:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c90d:	0f 84 79 0e 00 00    	je     d78c <f0+0x2c1c>
    c913:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c918:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c91f:	33 f3 bf 
    c922:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    c929:	00 
    c92a:	bf 01 00 00 00       	mov    $0x1,%edi
    c92f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    c936:	00 
    c937:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    c93e:	00 
    c93f:	e8 6c 94 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c944:	48 8b 15 4d 82 01 00 	mov    0x1824d(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c94b:	49 89 c5             	mov    %rax,%r13
    c94e:	48 2b 05 1b 82 01 00 	sub    0x1821b(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c955:	48 c1 e2 10          	shl    $0x10,%rdx
    c959:	48 39 d0             	cmp    %rdx,%rax
    c95c:	73 59                	jae    c9b7 <f0+0x1e47>
    c95e:	48 89 c2             	mov    %rax,%rdx
    c961:	48 c1 ea 10          	shr    $0x10,%rdx
    c965:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c969:	48 8b 15 48 82 01 00 	mov    0x18248(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c970:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c974:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c978:	4d 85 e4             	test   %r12,%r12
    c97b:	74 3a                	je     c9b7 <f0+0x1e47>
    c97d:	0f b6 0a             	movzbl (%rdx),%ecx
    c980:	80 f9 02             	cmp    $0x2,%cl
    c983:	0f 84 77 0a 00 00    	je     d400 <f0+0x2890>
    c989:	80 f9 01             	cmp    $0x1,%cl
    c98c:	75 29                	jne    c9b7 <f0+0x1e47>
    c98e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c991:	0f b7 c0             	movzwl %ax,%eax
    c994:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c997:	48 0f af c1          	imul   %rcx,%rax
    c99b:	48 c1 e8 20          	shr    $0x20,%rax
    c99f:	48 39 d0             	cmp    %rdx,%rax
    c9a2:	73 13                	jae    c9b7 <f0+0x1e47>
    c9a4:	49 01 c4             	add    %rax,%r12
    c9a7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c9ac:	0f 84 e7 0d 00 00    	je     d799 <f0+0x2c29>
    c9b2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c9b7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c9be:	00 f0 3f 
    c9c1:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    c9c8:	00 
    c9c9:	bf 01 00 00 00       	mov    $0x1,%edi
    c9ce:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    c9d5:	00 
    c9d6:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    c9dd:	00 
    c9de:	e8 cd 93 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c9e3:	48 8b 15 ae 81 01 00 	mov    0x181ae(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c9ea:	49 89 c5             	mov    %rax,%r13
    c9ed:	48 2b 05 7c 81 01 00 	sub    0x1817c(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c9f4:	48 c1 e2 10          	shl    $0x10,%rdx
    c9f8:	48 39 d0             	cmp    %rdx,%rax
    c9fb:	73 59                	jae    ca56 <f0+0x1ee6>
    c9fd:	48 89 c2             	mov    %rax,%rdx
    ca00:	48 c1 ea 10          	shr    $0x10,%rdx
    ca04:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca08:	48 8b 15 a9 81 01 00 	mov    0x181a9(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    ca0f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca13:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca17:	4d 85 e4             	test   %r12,%r12
    ca1a:	74 3a                	je     ca56 <f0+0x1ee6>
    ca1c:	0f b6 0a             	movzbl (%rdx),%ecx
    ca1f:	80 f9 02             	cmp    $0x2,%cl
    ca22:	0f 84 38 0c 00 00    	je     d660 <f0+0x2af0>
    ca28:	80 f9 01             	cmp    $0x1,%cl
    ca2b:	75 29                	jne    ca56 <f0+0x1ee6>
    ca2d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca30:	0f b7 c0             	movzwl %ax,%eax
    ca33:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca36:	48 0f af c1          	imul   %rcx,%rax
    ca3a:	48 c1 e8 20          	shr    $0x20,%rax
    ca3e:	48 39 d0             	cmp    %rdx,%rax
    ca41:	73 13                	jae    ca56 <f0+0x1ee6>
    ca43:	49 01 c4             	add    %rax,%r12
    ca46:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca4b:	0f 84 55 0d 00 00    	je     d7a6 <f0+0x2c36>
    ca51:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca56:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ca5d:	33 f3 bf 
    ca60:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    ca67:	00 
    ca68:	bf 01 00 00 00       	mov    $0x1,%edi
    ca6d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    ca74:	00 
    ca75:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    ca7c:	00 
    ca7d:	e8 2e 93 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ca82:	48 8b 15 0f 81 01 00 	mov    0x1810f(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    ca89:	49 89 c5             	mov    %rax,%r13
    ca8c:	48 2b 05 dd 80 01 00 	sub    0x180dd(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ca93:	48 c1 e2 10          	shl    $0x10,%rdx
    ca97:	48 39 d0             	cmp    %rdx,%rax
    ca9a:	73 59                	jae    caf5 <f0+0x1f85>
    ca9c:	48 89 c2             	mov    %rax,%rdx
    ca9f:	48 c1 ea 10          	shr    $0x10,%rdx
    caa3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    caa7:	48 8b 15 0a 81 01 00 	mov    0x1810a(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    caae:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cab2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cab6:	4d 85 e4             	test   %r12,%r12
    cab9:	74 3a                	je     caf5 <f0+0x1f85>
    cabb:	0f b6 0a             	movzbl (%rdx),%ecx
    cabe:	80 f9 02             	cmp    $0x2,%cl
    cac1:	0f 84 89 0b 00 00    	je     d650 <f0+0x2ae0>
    cac7:	80 f9 01             	cmp    $0x1,%cl
    caca:	75 29                	jne    caf5 <f0+0x1f85>
    cacc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cacf:	0f b7 c0             	movzwl %ax,%eax
    cad2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cad5:	48 0f af c1          	imul   %rcx,%rax
    cad9:	48 c1 e8 20          	shr    $0x20,%rax
    cadd:	48 39 d0             	cmp    %rdx,%rax
    cae0:	73 13                	jae    caf5 <f0+0x1f85>
    cae2:	49 01 c4             	add    %rax,%r12
    cae5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    caea:	0f 84 c3 0c 00 00    	je     d7b3 <f0+0x2c43>
    caf0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    caf5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cafc:	00 f0 3f 
    caff:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    cb06:	00 
    cb07:	bf 01 00 00 00       	mov    $0x1,%edi
    cb0c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    cb13:	00 
    cb14:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    cb1b:	00 
    cb1c:	e8 8f 92 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cb21:	48 8b 15 70 80 01 00 	mov    0x18070(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cb28:	49 89 c5             	mov    %rax,%r13
    cb2b:	48 2b 05 3e 80 01 00 	sub    0x1803e(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cb32:	48 c1 e2 10          	shl    $0x10,%rdx
    cb36:	48 39 d0             	cmp    %rdx,%rax
    cb39:	73 59                	jae    cb94 <f0+0x2024>
    cb3b:	48 89 c2             	mov    %rax,%rdx
    cb3e:	48 c1 ea 10          	shr    $0x10,%rdx
    cb42:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb46:	48 8b 15 6b 80 01 00 	mov    0x1806b(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cb4d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb51:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb55:	4d 85 e4             	test   %r12,%r12
    cb58:	74 3a                	je     cb94 <f0+0x2024>
    cb5a:	0f b6 0a             	movzbl (%rdx),%ecx
    cb5d:	80 f9 02             	cmp    $0x2,%cl
    cb60:	0f 84 da 0a 00 00    	je     d640 <f0+0x2ad0>
    cb66:	80 f9 01             	cmp    $0x1,%cl
    cb69:	75 29                	jne    cb94 <f0+0x2024>
    cb6b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb6e:	0f b7 c0             	movzwl %ax,%eax
    cb71:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb74:	48 0f af c1          	imul   %rcx,%rax
    cb78:	48 c1 e8 20          	shr    $0x20,%rax
    cb7c:	48 39 d0             	cmp    %rdx,%rax
    cb7f:	73 13                	jae    cb94 <f0+0x2024>
    cb81:	49 01 c4             	add    %rax,%r12
    cb84:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb89:	0f 84 31 0c 00 00    	je     d7c0 <f0+0x2c50>
    cb8f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb94:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cb9b:	33 f3 bf 
    cb9e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    cba5:	00 
    cba6:	bf 01 00 00 00       	mov    $0x1,%edi
    cbab:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    cbb2:	00 
    cbb3:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    cbba:	00 
    cbbb:	e8 f0 91 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cbc0:	48 8b 15 d1 7f 01 00 	mov    0x17fd1(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cbc7:	49 89 c5             	mov    %rax,%r13
    cbca:	48 2b 05 9f 7f 01 00 	sub    0x17f9f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cbd1:	48 c1 e2 10          	shl    $0x10,%rdx
    cbd5:	48 39 d0             	cmp    %rdx,%rax
    cbd8:	73 59                	jae    cc33 <f0+0x20c3>
    cbda:	48 89 c2             	mov    %rax,%rdx
    cbdd:	48 c1 ea 10          	shr    $0x10,%rdx
    cbe1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cbe5:	48 8b 15 cc 7f 01 00 	mov    0x17fcc(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cbec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cbf0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cbf4:	4d 85 e4             	test   %r12,%r12
    cbf7:	74 3a                	je     cc33 <f0+0x20c3>
    cbf9:	0f b6 0a             	movzbl (%rdx),%ecx
    cbfc:	80 f9 02             	cmp    $0x2,%cl
    cbff:	0f 84 2b 0a 00 00    	je     d630 <f0+0x2ac0>
    cc05:	80 f9 01             	cmp    $0x1,%cl
    cc08:	75 29                	jne    cc33 <f0+0x20c3>
    cc0a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc0d:	0f b7 c0             	movzwl %ax,%eax
    cc10:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc13:	48 0f af c1          	imul   %rcx,%rax
    cc17:	48 c1 e8 20          	shr    $0x20,%rax
    cc1b:	48 39 d0             	cmp    %rdx,%rax
    cc1e:	73 13                	jae    cc33 <f0+0x20c3>
    cc20:	49 01 c4             	add    %rax,%r12
    cc23:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc28:	0f 84 9f 0b 00 00    	je     d7cd <f0+0x2c5d>
    cc2e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc33:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc3a:	00 f0 3f 
    cc3d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    cc44:	00 
    cc45:	bf 01 00 00 00       	mov    $0x1,%edi
    cc4a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    cc51:	00 
    cc52:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    cc59:	00 
    cc5a:	e8 51 91 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cc5f:	48 8b 15 32 7f 01 00 	mov    0x17f32(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cc66:	49 89 c5             	mov    %rax,%r13
    cc69:	48 2b 05 00 7f 01 00 	sub    0x17f00(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cc70:	48 c1 e2 10          	shl    $0x10,%rdx
    cc74:	48 39 d0             	cmp    %rdx,%rax
    cc77:	73 59                	jae    ccd2 <f0+0x2162>
    cc79:	48 89 c2             	mov    %rax,%rdx
    cc7c:	48 c1 ea 10          	shr    $0x10,%rdx
    cc80:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc84:	48 8b 15 2d 7f 01 00 	mov    0x17f2d(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cc8b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc8f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc93:	4d 85 e4             	test   %r12,%r12
    cc96:	74 3a                	je     ccd2 <f0+0x2162>
    cc98:	0f b6 0a             	movzbl (%rdx),%ecx
    cc9b:	80 f9 02             	cmp    $0x2,%cl
    cc9e:	0f 84 7c 09 00 00    	je     d620 <f0+0x2ab0>
    cca4:	80 f9 01             	cmp    $0x1,%cl
    cca7:	75 29                	jne    ccd2 <f0+0x2162>
    cca9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ccac:	0f b7 c0             	movzwl %ax,%eax
    ccaf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ccb2:	48 0f af c1          	imul   %rcx,%rax
    ccb6:	48 c1 e8 20          	shr    $0x20,%rax
    ccba:	48 39 d0             	cmp    %rdx,%rax
    ccbd:	73 13                	jae    ccd2 <f0+0x2162>
    ccbf:	49 01 c4             	add    %rax,%r12
    ccc2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ccc7:	0f 84 0d 0b 00 00    	je     d7da <f0+0x2c6a>
    cccd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ccd2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ccd9:	33 f3 bf 
    ccdc:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    cce3:	00 
    cce4:	bf 01 00 00 00       	mov    $0x1,%edi
    cce9:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    ccf0:	00 
    ccf1:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    ccf8:	00 
    ccf9:	e8 b2 90 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ccfe:	48 8b 15 93 7e 01 00 	mov    0x17e93(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cd05:	49 89 c5             	mov    %rax,%r13
    cd08:	48 2b 05 61 7e 01 00 	sub    0x17e61(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cd0f:	48 c1 e2 10          	shl    $0x10,%rdx
    cd13:	48 39 d0             	cmp    %rdx,%rax
    cd16:	73 59                	jae    cd71 <f0+0x2201>
    cd18:	48 89 c2             	mov    %rax,%rdx
    cd1b:	48 c1 ea 10          	shr    $0x10,%rdx
    cd1f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd23:	48 8b 15 8e 7e 01 00 	mov    0x17e8e(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cd2a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd2e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd32:	4d 85 e4             	test   %r12,%r12
    cd35:	74 3a                	je     cd71 <f0+0x2201>
    cd37:	0f b6 0a             	movzbl (%rdx),%ecx
    cd3a:	80 f9 02             	cmp    $0x2,%cl
    cd3d:	0f 84 cd 08 00 00    	je     d610 <f0+0x2aa0>
    cd43:	80 f9 01             	cmp    $0x1,%cl
    cd46:	75 29                	jne    cd71 <f0+0x2201>
    cd48:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd4b:	0f b7 c0             	movzwl %ax,%eax
    cd4e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd51:	48 0f af c1          	imul   %rcx,%rax
    cd55:	48 c1 e8 20          	shr    $0x20,%rax
    cd59:	48 39 d0             	cmp    %rdx,%rax
    cd5c:	73 13                	jae    cd71 <f0+0x2201>
    cd5e:	49 01 c4             	add    %rax,%r12
    cd61:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd66:	0f 84 7b 0a 00 00    	je     d7e7 <f0+0x2c77>
    cd6c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd71:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cd78:	00 f0 3f 
    cd7b:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    cd82:	00 
    cd83:	bf 01 00 00 00       	mov    $0x1,%edi
    cd88:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    cd8f:	00 
    cd90:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    cd97:	00 
    cd98:	e8 13 90 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cd9d:	48 8b 15 f4 7d 01 00 	mov    0x17df4(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cda4:	49 89 c5             	mov    %rax,%r13
    cda7:	48 2b 05 c2 7d 01 00 	sub    0x17dc2(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cdae:	48 c1 e2 10          	shl    $0x10,%rdx
    cdb2:	48 39 d0             	cmp    %rdx,%rax
    cdb5:	73 59                	jae    ce10 <f0+0x22a0>
    cdb7:	48 89 c2             	mov    %rax,%rdx
    cdba:	48 c1 ea 10          	shr    $0x10,%rdx
    cdbe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cdc2:	48 8b 15 ef 7d 01 00 	mov    0x17def(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cdc9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cdcd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cdd1:	4d 85 e4             	test   %r12,%r12
    cdd4:	74 3a                	je     ce10 <f0+0x22a0>
    cdd6:	0f b6 0a             	movzbl (%rdx),%ecx
    cdd9:	80 f9 02             	cmp    $0x2,%cl
    cddc:	0f 84 1e 08 00 00    	je     d600 <f0+0x2a90>
    cde2:	80 f9 01             	cmp    $0x1,%cl
    cde5:	75 29                	jne    ce10 <f0+0x22a0>
    cde7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cdea:	0f b7 c0             	movzwl %ax,%eax
    cded:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cdf0:	48 0f af c1          	imul   %rcx,%rax
    cdf4:	48 c1 e8 20          	shr    $0x20,%rax
    cdf8:	48 39 d0             	cmp    %rdx,%rax
    cdfb:	73 13                	jae    ce10 <f0+0x22a0>
    cdfd:	49 01 c4             	add    %rax,%r12
    ce00:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce05:	0f 84 e9 09 00 00    	je     d7f4 <f0+0x2c84>
    ce0b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce10:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ce17:	33 f3 bf 
    ce1a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    ce21:	00 
    ce22:	bf 01 00 00 00       	mov    $0x1,%edi
    ce27:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    ce2e:	00 
    ce2f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    ce36:	00 
    ce37:	e8 74 8f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ce3c:	48 8b 15 55 7d 01 00 	mov    0x17d55(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    ce43:	49 89 c5             	mov    %rax,%r13
    ce46:	48 2b 05 23 7d 01 00 	sub    0x17d23(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ce4d:	48 c1 e2 10          	shl    $0x10,%rdx
    ce51:	48 39 d0             	cmp    %rdx,%rax
    ce54:	73 59                	jae    ceaf <f0+0x233f>
    ce56:	48 89 c2             	mov    %rax,%rdx
    ce59:	48 c1 ea 10          	shr    $0x10,%rdx
    ce5d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce61:	48 8b 15 50 7d 01 00 	mov    0x17d50(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    ce68:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce6c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce70:	4d 85 e4             	test   %r12,%r12
    ce73:	74 3a                	je     ceaf <f0+0x233f>
    ce75:	0f b6 0a             	movzbl (%rdx),%ecx
    ce78:	80 f9 02             	cmp    $0x2,%cl
    ce7b:	0f 84 6f 07 00 00    	je     d5f0 <f0+0x2a80>
    ce81:	80 f9 01             	cmp    $0x1,%cl
    ce84:	75 29                	jne    ceaf <f0+0x233f>
    ce86:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce89:	0f b7 c0             	movzwl %ax,%eax
    ce8c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce8f:	48 0f af c1          	imul   %rcx,%rax
    ce93:	48 c1 e8 20          	shr    $0x20,%rax
    ce97:	48 39 d0             	cmp    %rdx,%rax
    ce9a:	73 13                	jae    ceaf <f0+0x233f>
    ce9c:	49 01 c4             	add    %rax,%r12
    ce9f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cea4:	0f 84 57 09 00 00    	je     d801 <f0+0x2c91>
    ceaa:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ceaf:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ceb6:	00 f0 3f 
    ceb9:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    cec0:	00 
    cec1:	bf 01 00 00 00       	mov    $0x1,%edi
    cec6:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    cecd:	00 
    cece:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    ced5:	00 
    ced6:	e8 d5 8e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cedb:	48 8b 15 b6 7c 01 00 	mov    0x17cb6(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cee2:	49 89 c5             	mov    %rax,%r13
    cee5:	48 2b 05 84 7c 01 00 	sub    0x17c84(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ceec:	48 c1 e2 10          	shl    $0x10,%rdx
    cef0:	48 39 d0             	cmp    %rdx,%rax
    cef3:	73 59                	jae    cf4e <f0+0x23de>
    cef5:	48 89 c2             	mov    %rax,%rdx
    cef8:	48 c1 ea 10          	shr    $0x10,%rdx
    cefc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf00:	48 8b 15 b1 7c 01 00 	mov    0x17cb1(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cf07:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf0b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf0f:	4d 85 e4             	test   %r12,%r12
    cf12:	74 3a                	je     cf4e <f0+0x23de>
    cf14:	0f b6 0a             	movzbl (%rdx),%ecx
    cf17:	80 f9 02             	cmp    $0x2,%cl
    cf1a:	0f 84 c0 06 00 00    	je     d5e0 <f0+0x2a70>
    cf20:	80 f9 01             	cmp    $0x1,%cl
    cf23:	75 29                	jne    cf4e <f0+0x23de>
    cf25:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf28:	0f b7 c0             	movzwl %ax,%eax
    cf2b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf2e:	48 0f af c1          	imul   %rcx,%rax
    cf32:	48 c1 e8 20          	shr    $0x20,%rax
    cf36:	48 39 d0             	cmp    %rdx,%rax
    cf39:	73 13                	jae    cf4e <f0+0x23de>
    cf3b:	49 01 c4             	add    %rax,%r12
    cf3e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf43:	0f 84 c5 08 00 00    	je     d80e <f0+0x2c9e>
    cf49:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf4e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cf55:	33 f3 bf 
    cf58:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    cf5f:	00 
    cf60:	bf 01 00 00 00       	mov    $0x1,%edi
    cf65:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    cf6c:	00 
    cf6d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    cf74:	00 
    cf75:	e8 36 8e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cf7a:	48 8b 15 17 7c 01 00 	mov    0x17c17(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cf81:	49 89 c5             	mov    %rax,%r13
    cf84:	48 2b 05 e5 7b 01 00 	sub    0x17be5(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cf8b:	48 c1 e2 10          	shl    $0x10,%rdx
    cf8f:	48 39 d0             	cmp    %rdx,%rax
    cf92:	73 59                	jae    cfed <f0+0x247d>
    cf94:	48 89 c2             	mov    %rax,%rdx
    cf97:	48 c1 ea 10          	shr    $0x10,%rdx
    cf9b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf9f:	48 8b 15 12 7c 01 00 	mov    0x17c12(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cfa6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cfaa:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cfae:	4d 85 e4             	test   %r12,%r12
    cfb1:	74 3a                	je     cfed <f0+0x247d>
    cfb3:	0f b6 0a             	movzbl (%rdx),%ecx
    cfb6:	80 f9 02             	cmp    $0x2,%cl
    cfb9:	0f 84 11 06 00 00    	je     d5d0 <f0+0x2a60>
    cfbf:	80 f9 01             	cmp    $0x1,%cl
    cfc2:	75 29                	jne    cfed <f0+0x247d>
    cfc4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfc7:	0f b7 c0             	movzwl %ax,%eax
    cfca:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cfcd:	48 0f af c1          	imul   %rcx,%rax
    cfd1:	48 c1 e8 20          	shr    $0x20,%rax
    cfd5:	48 39 d0             	cmp    %rdx,%rax
    cfd8:	73 13                	jae    cfed <f0+0x247d>
    cfda:	49 01 c4             	add    %rax,%r12
    cfdd:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cfe2:	0f 84 33 08 00 00    	je     d81b <f0+0x2cab>
    cfe8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cfed:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cff4:	00 f0 3f 
    cff7:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    cffe:	00 
    cfff:	bf 01 00 00 00       	mov    $0x1,%edi
    d004:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    d00b:	00 
    d00c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    d013:	00 
    d014:	e8 97 8d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d019:	48 8b 15 78 7b 01 00 	mov    0x17b78(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d020:	49 89 c5             	mov    %rax,%r13
    d023:	48 2b 05 46 7b 01 00 	sub    0x17b46(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d02a:	48 c1 e2 10          	shl    $0x10,%rdx
    d02e:	48 39 d0             	cmp    %rdx,%rax
    d031:	73 59                	jae    d08c <f0+0x251c>
    d033:	48 89 c2             	mov    %rax,%rdx
    d036:	48 c1 ea 10          	shr    $0x10,%rdx
    d03a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d03e:	48 8b 15 73 7b 01 00 	mov    0x17b73(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d045:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d049:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d04d:	4d 85 e4             	test   %r12,%r12
    d050:	74 3a                	je     d08c <f0+0x251c>
    d052:	0f b6 0a             	movzbl (%rdx),%ecx
    d055:	80 f9 02             	cmp    $0x2,%cl
    d058:	0f 84 62 05 00 00    	je     d5c0 <f0+0x2a50>
    d05e:	80 f9 01             	cmp    $0x1,%cl
    d061:	75 29                	jne    d08c <f0+0x251c>
    d063:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d066:	0f b7 c0             	movzwl %ax,%eax
    d069:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d06c:	48 0f af c1          	imul   %rcx,%rax
    d070:	48 c1 e8 20          	shr    $0x20,%rax
    d074:	48 39 d0             	cmp    %rdx,%rax
    d077:	73 13                	jae    d08c <f0+0x251c>
    d079:	49 01 c4             	add    %rax,%r12
    d07c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d081:	0f 84 a1 07 00 00    	je     d828 <f0+0x2cb8>
    d087:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d08c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d093:	33 f3 bf 
    d096:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    d09d:	00 
    d09e:	bf 01 00 00 00       	mov    $0x1,%edi
    d0a3:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    d0aa:	00 
    d0ab:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    d0b2:	00 
    d0b3:	e8 f8 8c ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d0b8:	48 8b 15 d9 7a 01 00 	mov    0x17ad9(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d0bf:	49 89 c5             	mov    %rax,%r13
    d0c2:	48 2b 05 a7 7a 01 00 	sub    0x17aa7(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d0c9:	48 c1 e2 10          	shl    $0x10,%rdx
    d0cd:	48 39 d0             	cmp    %rdx,%rax
    d0d0:	73 59                	jae    d12b <f0+0x25bb>
    d0d2:	48 89 c2             	mov    %rax,%rdx
    d0d5:	48 c1 ea 10          	shr    $0x10,%rdx
    d0d9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0dd:	48 8b 15 d4 7a 01 00 	mov    0x17ad4(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d0e4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d0e8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d0ec:	4d 85 e4             	test   %r12,%r12
    d0ef:	74 3a                	je     d12b <f0+0x25bb>
    d0f1:	0f b6 0a             	movzbl (%rdx),%ecx
    d0f4:	80 f9 02             	cmp    $0x2,%cl
    d0f7:	0f 84 b3 04 00 00    	je     d5b0 <f0+0x2a40>
    d0fd:	80 f9 01             	cmp    $0x1,%cl
    d100:	75 29                	jne    d12b <f0+0x25bb>
    d102:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d105:	0f b7 c0             	movzwl %ax,%eax
    d108:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d10b:	48 0f af c1          	imul   %rcx,%rax
    d10f:	48 c1 e8 20          	shr    $0x20,%rax
    d113:	48 39 d0             	cmp    %rdx,%rax
    d116:	73 13                	jae    d12b <f0+0x25bb>
    d118:	49 01 c4             	add    %rax,%r12
    d11b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d120:	0f 84 0f 07 00 00    	je     d835 <f0+0x2cc5>
    d126:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d12b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d132:	00 f0 3f 
    d135:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    d13c:	00 
    d13d:	bf 01 00 00 00       	mov    $0x1,%edi
    d142:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    d149:	00 
    d14a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    d151:	00 
    d152:	e8 59 8c ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d157:	48 8b 15 3a 7a 01 00 	mov    0x17a3a(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d15e:	49 89 c5             	mov    %rax,%r13
    d161:	48 2b 05 08 7a 01 00 	sub    0x17a08(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d168:	48 c1 e2 10          	shl    $0x10,%rdx
    d16c:	48 39 d0             	cmp    %rdx,%rax
    d16f:	73 59                	jae    d1ca <f0+0x265a>
    d171:	48 89 c2             	mov    %rax,%rdx
    d174:	48 c1 ea 10          	shr    $0x10,%rdx
    d178:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d17c:	48 8b 15 35 7a 01 00 	mov    0x17a35(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d183:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d187:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d18b:	4d 85 e4             	test   %r12,%r12
    d18e:	74 3a                	je     d1ca <f0+0x265a>
    d190:	0f b6 0a             	movzbl (%rdx),%ecx
    d193:	80 f9 02             	cmp    $0x2,%cl
    d196:	0f 84 04 04 00 00    	je     d5a0 <f0+0x2a30>
    d19c:	80 f9 01             	cmp    $0x1,%cl
    d19f:	75 29                	jne    d1ca <f0+0x265a>
    d1a1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d1a4:	0f b7 c0             	movzwl %ax,%eax
    d1a7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d1aa:	48 0f af c1          	imul   %rcx,%rax
    d1ae:	48 c1 e8 20          	shr    $0x20,%rax
    d1b2:	48 39 d0             	cmp    %rdx,%rax
    d1b5:	73 13                	jae    d1ca <f0+0x265a>
    d1b7:	49 01 c4             	add    %rax,%r12
    d1ba:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d1bf:	0f 84 7d 06 00 00    	je     d842 <f0+0x2cd2>
    d1c5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d1ca:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d1d1:	33 f3 bf 
    d1d4:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    d1db:	00 
    d1dc:	bf 01 00 00 00       	mov    $0x1,%edi
    d1e1:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    d1e8:	00 
    d1e9:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    d1f0:	00 
    d1f1:	e8 ba 8b ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d1f6:	48 8b 15 9b 79 01 00 	mov    0x1799b(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d1fd:	49 89 c5             	mov    %rax,%r13
    d200:	48 2b 05 69 79 01 00 	sub    0x17969(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d207:	48 c1 e2 10          	shl    $0x10,%rdx
    d20b:	48 39 d0             	cmp    %rdx,%rax
    d20e:	73 59                	jae    d269 <f0+0x26f9>
    d210:	48 89 c2             	mov    %rax,%rdx
    d213:	48 c1 ea 10          	shr    $0x10,%rdx
    d217:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d21b:	48 8b 15 96 79 01 00 	mov    0x17996(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d222:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d226:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d22a:	4d 85 e4             	test   %r12,%r12
    d22d:	74 3a                	je     d269 <f0+0x26f9>
    d22f:	0f b6 0a             	movzbl (%rdx),%ecx
    d232:	80 f9 02             	cmp    $0x2,%cl
    d235:	0f 84 55 03 00 00    	je     d590 <f0+0x2a20>
    d23b:	80 f9 01             	cmp    $0x1,%cl
    d23e:	75 29                	jne    d269 <f0+0x26f9>
    d240:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d243:	0f b7 c0             	movzwl %ax,%eax
    d246:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d249:	48 0f af c1          	imul   %rcx,%rax
    d24d:	48 c1 e8 20          	shr    $0x20,%rax
    d251:	48 39 d0             	cmp    %rdx,%rax
    d254:	73 13                	jae    d269 <f0+0x26f9>
    d256:	49 01 c4             	add    %rax,%r12
    d259:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d25e:	0f 84 eb 05 00 00    	je     d84f <f0+0x2cdf>
    d264:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d269:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d270:	00 f0 3f 
    d273:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    d27a:	00 
    d27b:	bf 01 00 00 00       	mov    $0x1,%edi
    d280:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    d287:	00 
    d288:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    d28f:	00 
    d290:	e8 1b 8b ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d295:	48 8b 15 fc 78 01 00 	mov    0x178fc(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d29c:	49 89 c5             	mov    %rax,%r13
    d29f:	48 2b 05 ca 78 01 00 	sub    0x178ca(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d2a6:	48 c1 e2 10          	shl    $0x10,%rdx
    d2aa:	48 39 d0             	cmp    %rdx,%rax
    d2ad:	73 59                	jae    d308 <f0+0x2798>
    d2af:	48 89 c2             	mov    %rax,%rdx
    d2b2:	48 c1 ea 10          	shr    $0x10,%rdx
    d2b6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d2ba:	48 8b 15 f7 78 01 00 	mov    0x178f7(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d2c1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d2c5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d2c9:	4d 85 e4             	test   %r12,%r12
    d2cc:	74 3a                	je     d308 <f0+0x2798>
    d2ce:	0f b6 0a             	movzbl (%rdx),%ecx
    d2d1:	80 f9 02             	cmp    $0x2,%cl
    d2d4:	0f 84 a6 02 00 00    	je     d580 <f0+0x2a10>
    d2da:	80 f9 01             	cmp    $0x1,%cl
    d2dd:	75 29                	jne    d308 <f0+0x2798>
    d2df:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2e2:	0f b7 c0             	movzwl %ax,%eax
    d2e5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d2e8:	48 0f af c1          	imul   %rcx,%rax
    d2ec:	48 c1 e8 20          	shr    $0x20,%rax
    d2f0:	48 39 d0             	cmp    %rdx,%rax
    d2f3:	73 13                	jae    d308 <f0+0x2798>
    d2f5:	49 01 c4             	add    %rax,%r12
    d2f8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d2fd:	0f 84 59 05 00 00    	je     d85c <f0+0x2cec>
    d303:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d308:	48 89 ee             	mov    %rbp,%rsi
    d30b:	bf 01 00 00 00       	mov    $0x1,%edi
    d310:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d317:	33 f3 bf 
    d31a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    d321:	00 
    d322:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    d329:	00 
    d32a:	e8 81 8a ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d32f:	48 8b 15 62 78 01 00 	mov    0x17862(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d336:	48 89 c5             	mov    %rax,%rbp
    d339:	48 2b 05 30 78 01 00 	sub    0x17830(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d340:	48 c1 e2 10          	shl    $0x10,%rdx
    d344:	48 39 d0             	cmp    %rdx,%rax
    d347:	73 59                	jae    d3a2 <f0+0x2832>
    d349:	48 89 c2             	mov    %rax,%rdx
    d34c:	48 c1 ea 10          	shr    $0x10,%rdx
    d350:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d354:	48 8b 15 5d 78 01 00 	mov    0x1785d(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d35b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d35f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d363:	4d 85 e4             	test   %r12,%r12
    d366:	74 3a                	je     d3a2 <f0+0x2832>
    d368:	0f b6 0a             	movzbl (%rdx),%ecx
    d36b:	80 f9 02             	cmp    $0x2,%cl
    d36e:	0f 84 fc 01 00 00    	je     d570 <f0+0x2a00>
    d374:	80 f9 01             	cmp    $0x1,%cl
    d377:	75 29                	jne    d3a2 <f0+0x2832>
    d379:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d37c:	0f b7 c0             	movzwl %ax,%eax
    d37f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d382:	48 0f af c1          	imul   %rcx,%rax
    d386:	48 c1 e8 20          	shr    $0x20,%rax
    d38a:	48 39 d0             	cmp    %rdx,%rax
    d38d:	73 13                	jae    d3a2 <f0+0x2832>
    d38f:	49 01 c4             	add    %rax,%r12
    d392:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d397:	0f 84 d1 02 00 00    	je     d66e <f0+0x2afe>
    d39d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d3a2:	48 89 de             	mov    %rbx,%rsi
    d3a5:	48 89 ef             	mov    %rbp,%rdi
    d3a8:	e8 a3 be ff ff       	call   9250 <fwp_hof0.constprop.0>
    d3ad:	48 89 ef             	mov    %rbp,%rdi
    d3b0:	e8 cb a2 ff ff       	call   7680 <fwp_drop0>
    d3b5:	48 89 df             	mov    %rbx,%rdi
    d3b8:	e8 c3 a2 ff ff       	call   7680 <fwp_drop0>
    d3bd:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    d3c4:	00 
    d3c5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    d3cc:	00 00 
    d3ce:	0f 85 95 04 00 00    	jne    d869 <f0+0x2cf9>
    d3d4:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    d3db:	31 c0                	xor    %eax,%eax
    d3dd:	5b                   	pop    %rbx
    d3de:	5d                   	pop    %rbp
    d3df:	41 5c                	pop    %r12
    d3e1:	41 5d                	pop    %r13
    d3e3:	41 5e                	pop    %r14
    d3e5:	c3                   	ret
    d3e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    d3ed:	00 00 00 
    d3f0:	4c 89 ef             	mov    %r13,%rdi
    d3f3:	e8 58 81 ff ff       	call   5550 <fwp_rc_forget_slot>
    d3f8:	e9 2c d8 ff ff       	jmp    ac29 <f0+0xb9>
    d3fd:	0f 1f 00             	nopl   (%rax)
    d400:	66 85 c0             	test   %ax,%ax
    d403:	0f 85 ae f5 ff ff    	jne    c9b7 <f0+0x1e47>
    d409:	e9 99 f5 ff ff       	jmp    c9a7 <f0+0x1e37>
    d40e:	66 90                	xchg   %ax,%ax
    d410:	66 85 c0             	test   %ax,%ax
    d413:	0f 85 ff f4 ff ff    	jne    c918 <f0+0x1da8>
    d419:	e9 ea f4 ff ff       	jmp    c908 <f0+0x1d98>
    d41e:	66 90                	xchg   %ax,%ax
    d420:	66 85 c0             	test   %ax,%ax
    d423:	0f 85 50 f4 ff ff    	jne    c879 <f0+0x1d09>
    d429:	e9 3b f4 ff ff       	jmp    c869 <f0+0x1cf9>
    d42e:	66 90                	xchg   %ax,%ax
    d430:	66 85 c0             	test   %ax,%ax
    d433:	0f 85 a1 f3 ff ff    	jne    c7da <f0+0x1c6a>
    d439:	e9 8c f3 ff ff       	jmp    c7ca <f0+0x1c5a>
    d43e:	66 90                	xchg   %ax,%ax
    d440:	66 85 c0             	test   %ax,%ax
    d443:	0f 85 f2 f2 ff ff    	jne    c73b <f0+0x1bcb>
    d449:	e9 dd f2 ff ff       	jmp    c72b <f0+0x1bbb>
    d44e:	66 90                	xchg   %ax,%ax
    d450:	66 85 c0             	test   %ax,%ax
    d453:	0f 85 43 f2 ff ff    	jne    c69c <f0+0x1b2c>
    d459:	e9 2e f2 ff ff       	jmp    c68c <f0+0x1b1c>
    d45e:	66 90                	xchg   %ax,%ax
    d460:	66 85 c0             	test   %ax,%ax
    d463:	0f 85 94 f1 ff ff    	jne    c5fd <f0+0x1a8d>
    d469:	e9 7f f1 ff ff       	jmp    c5ed <f0+0x1a7d>
    d46e:	66 90                	xchg   %ax,%ax
    d470:	66 85 c0             	test   %ax,%ax
    d473:	0f 85 e5 f0 ff ff    	jne    c55e <f0+0x19ee>
    d479:	e9 d0 f0 ff ff       	jmp    c54e <f0+0x19de>
    d47e:	66 90                	xchg   %ax,%ax
    d480:	66 85 c0             	test   %ax,%ax
    d483:	0f 85 fd d9 ff ff    	jne    ae86 <f0+0x316>
    d489:	e9 e8 d9 ff ff       	jmp    ae76 <f0+0x306>
    d48e:	66 90                	xchg   %ax,%ax
    d490:	66 85 c0             	test   %ax,%ax
    d493:	0f 85 57 d9 ff ff    	jne    adf0 <f0+0x280>
    d499:	e9 42 d9 ff ff       	jmp    ade0 <f0+0x270>
    d49e:	66 90                	xchg   %ax,%ax
    d4a0:	66 85 c0             	test   %ax,%ax
    d4a3:	0f 85 b1 d8 ff ff    	jne    ad5a <f0+0x1ea>
    d4a9:	e9 9c d8 ff ff       	jmp    ad4a <f0+0x1da>
    d4ae:	66 90                	xchg   %ax,%ax
    d4b0:	66 85 c0             	test   %ax,%ax
    d4b3:	0f 85 0e eb ff ff    	jne    bfc7 <f0+0x1457>
    d4b9:	e9 f9 ea ff ff       	jmp    bfb7 <f0+0x1447>
    d4be:	66 90                	xchg   %ax,%ax
    d4c0:	66 85 c0             	test   %ax,%ax
    d4c3:	0f 85 5f ea ff ff    	jne    bf28 <f0+0x13b8>
    d4c9:	e9 4a ea ff ff       	jmp    bf18 <f0+0x13a8>
    d4ce:	66 90                	xchg   %ax,%ax
    d4d0:	66 85 c0             	test   %ax,%ax
    d4d3:	0f 85 e2 da ff ff    	jne    afbb <f0+0x44b>
    d4d9:	e9 cd da ff ff       	jmp    afab <f0+0x43b>
    d4de:	66 90                	xchg   %ax,%ax
    d4e0:	66 85 c0             	test   %ax,%ax
    d4e3:	0f 85 33 da ff ff    	jne    af1c <f0+0x3ac>
    d4e9:	e9 1e da ff ff       	jmp    af0c <f0+0x39c>
    d4ee:	66 90                	xchg   %ax,%ax
    d4f0:	66 85 c0             	test   %ax,%ax
    d4f3:	0f 85 c6 ef ff ff    	jne    c4bf <f0+0x194f>
    d4f9:	e9 b1 ef ff ff       	jmp    c4af <f0+0x193f>
    d4fe:	66 90                	xchg   %ax,%ax
    d500:	66 85 c0             	test   %ax,%ax
    d503:	0f 85 17 ef ff ff    	jne    c420 <f0+0x18b0>
    d509:	e9 02 ef ff ff       	jmp    c410 <f0+0x18a0>
    d50e:	66 90                	xchg   %ax,%ax
    d510:	66 85 c0             	test   %ax,%ax
    d513:	0f 85 68 ee ff ff    	jne    c381 <f0+0x1811>
    d519:	e9 53 ee ff ff       	jmp    c371 <f0+0x1801>
    d51e:	66 90                	xchg   %ax,%ax
    d520:	66 85 c0             	test   %ax,%ax
    d523:	0f 85 b9 ed ff ff    	jne    c2e2 <f0+0x1772>
    d529:	e9 a4 ed ff ff       	jmp    c2d2 <f0+0x1762>
    d52e:	66 90                	xchg   %ax,%ax
    d530:	66 85 c0             	test   %ax,%ax
    d533:	0f 85 0a ed ff ff    	jne    c243 <f0+0x16d3>
    d539:	e9 f5 ec ff ff       	jmp    c233 <f0+0x16c3>
    d53e:	66 90                	xchg   %ax,%ax
    d540:	66 85 c0             	test   %ax,%ax
    d543:	0f 85 5b ec ff ff    	jne    c1a4 <f0+0x1634>
    d549:	e9 46 ec ff ff       	jmp    c194 <f0+0x1624>
    d54e:	66 90                	xchg   %ax,%ax
    d550:	66 85 c0             	test   %ax,%ax
    d553:	0f 85 ac eb ff ff    	jne    c105 <f0+0x1595>
    d559:	e9 97 eb ff ff       	jmp    c0f5 <f0+0x1585>
    d55e:	66 90                	xchg   %ax,%ax
    d560:	66 85 c0             	test   %ax,%ax
    d563:	0f 85 fd ea ff ff    	jne    c066 <f0+0x14f6>
    d569:	e9 e8 ea ff ff       	jmp    c056 <f0+0x14e6>
    d56e:	66 90                	xchg   %ax,%ax
    d570:	66 85 c0             	test   %ax,%ax
    d573:	0f 85 29 fe ff ff    	jne    d3a2 <f0+0x2832>
    d579:	e9 14 fe ff ff       	jmp    d392 <f0+0x2822>
    d57e:	66 90                	xchg   %ax,%ax
    d580:	66 85 c0             	test   %ax,%ax
    d583:	0f 85 7f fd ff ff    	jne    d308 <f0+0x2798>
    d589:	e9 6a fd ff ff       	jmp    d2f8 <f0+0x2788>
    d58e:	66 90                	xchg   %ax,%ax
    d590:	66 85 c0             	test   %ax,%ax
    d593:	0f 85 d0 fc ff ff    	jne    d269 <f0+0x26f9>
    d599:	e9 bb fc ff ff       	jmp    d259 <f0+0x26e9>
    d59e:	66 90                	xchg   %ax,%ax
    d5a0:	66 85 c0             	test   %ax,%ax
    d5a3:	0f 85 21 fc ff ff    	jne    d1ca <f0+0x265a>
    d5a9:	e9 0c fc ff ff       	jmp    d1ba <f0+0x264a>
    d5ae:	66 90                	xchg   %ax,%ax
    d5b0:	66 85 c0             	test   %ax,%ax
    d5b3:	0f 85 72 fb ff ff    	jne    d12b <f0+0x25bb>
    d5b9:	e9 5d fb ff ff       	jmp    d11b <f0+0x25ab>
    d5be:	66 90                	xchg   %ax,%ax
    d5c0:	66 85 c0             	test   %ax,%ax
    d5c3:	0f 85 c3 fa ff ff    	jne    d08c <f0+0x251c>
    d5c9:	e9 ae fa ff ff       	jmp    d07c <f0+0x250c>
    d5ce:	66 90                	xchg   %ax,%ax
    d5d0:	66 85 c0             	test   %ax,%ax
    d5d3:	0f 85 14 fa ff ff    	jne    cfed <f0+0x247d>
    d5d9:	e9 ff f9 ff ff       	jmp    cfdd <f0+0x246d>
    d5de:	66 90                	xchg   %ax,%ax
    d5e0:	66 85 c0             	test   %ax,%ax
    d5e3:	0f 85 65 f9 ff ff    	jne    cf4e <f0+0x23de>
    d5e9:	e9 50 f9 ff ff       	jmp    cf3e <f0+0x23ce>
    d5ee:	66 90                	xchg   %ax,%ax
    d5f0:	66 85 c0             	test   %ax,%ax
    d5f3:	0f 85 b6 f8 ff ff    	jne    ceaf <f0+0x233f>
    d5f9:	e9 a1 f8 ff ff       	jmp    ce9f <f0+0x232f>
    d5fe:	66 90                	xchg   %ax,%ax
    d600:	66 85 c0             	test   %ax,%ax
    d603:	0f 85 07 f8 ff ff    	jne    ce10 <f0+0x22a0>
    d609:	e9 f2 f7 ff ff       	jmp    ce00 <f0+0x2290>
    d60e:	66 90                	xchg   %ax,%ax
    d610:	66 85 c0             	test   %ax,%ax
    d613:	0f 85 58 f7 ff ff    	jne    cd71 <f0+0x2201>
    d619:	e9 43 f7 ff ff       	jmp    cd61 <f0+0x21f1>
    d61e:	66 90                	xchg   %ax,%ax
    d620:	66 85 c0             	test   %ax,%ax
    d623:	0f 85 a9 f6 ff ff    	jne    ccd2 <f0+0x2162>
    d629:	e9 94 f6 ff ff       	jmp    ccc2 <f0+0x2152>
    d62e:	66 90                	xchg   %ax,%ax
    d630:	66 85 c0             	test   %ax,%ax
    d633:	0f 85 fa f5 ff ff    	jne    cc33 <f0+0x20c3>
    d639:	e9 e5 f5 ff ff       	jmp    cc23 <f0+0x20b3>
    d63e:	66 90                	xchg   %ax,%ax
    d640:	66 85 c0             	test   %ax,%ax
    d643:	0f 85 4b f5 ff ff    	jne    cb94 <f0+0x2024>
    d649:	e9 36 f5 ff ff       	jmp    cb84 <f0+0x2014>
    d64e:	66 90                	xchg   %ax,%ax
    d650:	66 85 c0             	test   %ax,%ax
    d653:	0f 85 9c f4 ff ff    	jne    caf5 <f0+0x1f85>
    d659:	e9 87 f4 ff ff       	jmp    cae5 <f0+0x1f75>
    d65e:	66 90                	xchg   %ax,%ax
    d660:	66 85 c0             	test   %ax,%ax
    d663:	0f 85 ed f3 ff ff    	jne    ca56 <f0+0x1ee6>
    d669:	e9 d8 f3 ff ff       	jmp    ca46 <f0+0x1ed6>
    d66e:	4c 89 e7             	mov    %r12,%rdi
    d671:	e8 da 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d676:	e9 22 fd ff ff       	jmp    d39d <f0+0x282d>
    d67b:	4c 89 e7             	mov    %r12,%rdi
    d67e:	e8 cd 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d683:	e9 cd d6 ff ff       	jmp    ad55 <f0+0x1e5>
    d688:	4c 89 e7             	mov    %r12,%rdi
    d68b:	e8 c0 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d690:	e9 56 d7 ff ff       	jmp    adeb <f0+0x27b>
    d695:	4c 89 e7             	mov    %r12,%rdi
    d698:	e8 b3 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d69d:	e9 df d7 ff ff       	jmp    ae81 <f0+0x311>
    d6a2:	4c 89 e7             	mov    %r12,%rdi
    d6a5:	e8 a6 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d6aa:	e9 68 d8 ff ff       	jmp    af17 <f0+0x3a7>
    d6af:	4c 89 e7             	mov    %r12,%rdi
    d6b2:	e8 99 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d6b7:	e9 fa d8 ff ff       	jmp    afb6 <f0+0x446>
    d6bc:	4c 89 e7             	mov    %r12,%rdi
    d6bf:	e8 8c 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d6c4:	e9 5a e8 ff ff       	jmp    bf23 <f0+0x13b3>
    d6c9:	4c 89 e7             	mov    %r12,%rdi
    d6cc:	e8 7f 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d6d1:	e9 ec e8 ff ff       	jmp    bfc2 <f0+0x1452>
    d6d6:	4c 89 e7             	mov    %r12,%rdi
    d6d9:	e8 72 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d6de:	e9 7e e9 ff ff       	jmp    c061 <f0+0x14f1>
    d6e3:	4c 89 e7             	mov    %r12,%rdi
    d6e6:	e8 65 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d6eb:	e9 10 ea ff ff       	jmp    c100 <f0+0x1590>
    d6f0:	4c 89 e7             	mov    %r12,%rdi
    d6f3:	e8 58 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d6f8:	e9 a2 ea ff ff       	jmp    c19f <f0+0x162f>
    d6fd:	4c 89 e7             	mov    %r12,%rdi
    d700:	e8 4b 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d705:	e9 34 eb ff ff       	jmp    c23e <f0+0x16ce>
    d70a:	4c 89 e7             	mov    %r12,%rdi
    d70d:	e8 3e 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d712:	e9 c6 eb ff ff       	jmp    c2dd <f0+0x176d>
    d717:	4c 89 e7             	mov    %r12,%rdi
    d71a:	e8 31 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d71f:	e9 58 ec ff ff       	jmp    c37c <f0+0x180c>
    d724:	4c 89 e7             	mov    %r12,%rdi
    d727:	e8 24 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d72c:	e9 ea ec ff ff       	jmp    c41b <f0+0x18ab>
    d731:	4c 89 e7             	mov    %r12,%rdi
    d734:	e8 17 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d739:	e9 7c ed ff ff       	jmp    c4ba <f0+0x194a>
    d73e:	4c 89 e7             	mov    %r12,%rdi
    d741:	e8 0a 7e ff ff       	call   5550 <fwp_rc_forget_slot>
    d746:	e9 0e ee ff ff       	jmp    c559 <f0+0x19e9>
    d74b:	4c 89 e7             	mov    %r12,%rdi
    d74e:	e8 fd 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d753:	e9 a0 ee ff ff       	jmp    c5f8 <f0+0x1a88>
    d758:	4c 89 e7             	mov    %r12,%rdi
    d75b:	e8 f0 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d760:	e9 32 ef ff ff       	jmp    c697 <f0+0x1b27>
    d765:	4c 89 e7             	mov    %r12,%rdi
    d768:	e8 e3 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d76d:	e9 c4 ef ff ff       	jmp    c736 <f0+0x1bc6>
    d772:	4c 89 e7             	mov    %r12,%rdi
    d775:	e8 d6 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d77a:	e9 56 f0 ff ff       	jmp    c7d5 <f0+0x1c65>
    d77f:	4c 89 e7             	mov    %r12,%rdi
    d782:	e8 c9 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d787:	e9 e8 f0 ff ff       	jmp    c874 <f0+0x1d04>
    d78c:	4c 89 e7             	mov    %r12,%rdi
    d78f:	e8 bc 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d794:	e9 7a f1 ff ff       	jmp    c913 <f0+0x1da3>
    d799:	4c 89 e7             	mov    %r12,%rdi
    d79c:	e8 af 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d7a1:	e9 0c f2 ff ff       	jmp    c9b2 <f0+0x1e42>
    d7a6:	4c 89 e7             	mov    %r12,%rdi
    d7a9:	e8 a2 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d7ae:	e9 9e f2 ff ff       	jmp    ca51 <f0+0x1ee1>
    d7b3:	4c 89 e7             	mov    %r12,%rdi
    d7b6:	e8 95 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d7bb:	e9 30 f3 ff ff       	jmp    caf0 <f0+0x1f80>
    d7c0:	4c 89 e7             	mov    %r12,%rdi
    d7c3:	e8 88 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d7c8:	e9 c2 f3 ff ff       	jmp    cb8f <f0+0x201f>
    d7cd:	4c 89 e7             	mov    %r12,%rdi
    d7d0:	e8 7b 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d7d5:	e9 54 f4 ff ff       	jmp    cc2e <f0+0x20be>
    d7da:	4c 89 e7             	mov    %r12,%rdi
    d7dd:	e8 6e 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d7e2:	e9 e6 f4 ff ff       	jmp    cccd <f0+0x215d>
    d7e7:	4c 89 e7             	mov    %r12,%rdi
    d7ea:	e8 61 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d7ef:	e9 78 f5 ff ff       	jmp    cd6c <f0+0x21fc>
    d7f4:	4c 89 e7             	mov    %r12,%rdi
    d7f7:	e8 54 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d7fc:	e9 0a f6 ff ff       	jmp    ce0b <f0+0x229b>
    d801:	4c 89 e7             	mov    %r12,%rdi
    d804:	e8 47 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d809:	e9 9c f6 ff ff       	jmp    ceaa <f0+0x233a>
    d80e:	4c 89 e7             	mov    %r12,%rdi
    d811:	e8 3a 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d816:	e9 2e f7 ff ff       	jmp    cf49 <f0+0x23d9>
    d81b:	4c 89 e7             	mov    %r12,%rdi
    d81e:	e8 2d 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d823:	e9 c0 f7 ff ff       	jmp    cfe8 <f0+0x2478>
    d828:	4c 89 e7             	mov    %r12,%rdi
    d82b:	e8 20 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d830:	e9 52 f8 ff ff       	jmp    d087 <f0+0x2517>
    d835:	4c 89 e7             	mov    %r12,%rdi
    d838:	e8 13 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d83d:	e9 e4 f8 ff ff       	jmp    d126 <f0+0x25b6>
    d842:	4c 89 e7             	mov    %r12,%rdi
    d845:	e8 06 7d ff ff       	call   5550 <fwp_rc_forget_slot>
    d84a:	e9 76 f9 ff ff       	jmp    d1c5 <f0+0x2655>
    d84f:	4c 89 e7             	mov    %r12,%rdi
    d852:	e8 f9 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d857:	e9 08 fa ff ff       	jmp    d264 <f0+0x26f4>
    d85c:	4c 89 e7             	mov    %r12,%rdi
    d85f:	e8 ec 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d864:	e9 9a fa ff ff       	jmp    d303 <f0+0x2793>
    d869:	e8 f2 5b ff ff       	call   3460 <__stack_chk_fail@plt>
    d86e:	66 90                	xchg   %ax,%ax

000000000000d870 <fwp_main_thread>:
    d870:	f3 0f 1e fa          	endbr64
    d874:	41 54                	push   %r12
    d876:	55                   	push   %rbp
    d877:	53                   	push   %rbx
    d878:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    d87f:	8b 35 df 72 01 00    	mov    0x172df(%rip),%esi        # 24b64 <fwp_heap+0x13a4>
    d885:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    d88c:	00 00 
    d88e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    d895:	00 
    d896:	31 c0                	xor    %eax,%eax
    d898:	85 f6                	test   %esi,%esi
    d89a:	0f 84 a8 06 00 00    	je     df48 <fwp_main_thread+0x6d8>
    d8a0:	8b 0d c2 72 01 00    	mov    0x172c2(%rip),%ecx        # 24b68 <fwp_heap+0x13a8>
    d8a6:	85 c9                	test   %ecx,%ecx
    d8a8:	0f 85 82 06 00 00    	jne    df30 <fwp_main_thread+0x6c0>
    d8ae:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    d8b3:	31 f6                	xor    %esi,%esi
    d8b5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    d8ba:	48 c7 05 8b 58 01 00 	movq   $0x40000000,0x1588b(%rip)        # 23150 <fwp_main_stack_size>
    d8c1:	00 00 00 40 
    d8c5:	48 89 05 8c 58 01 00 	mov    %rax,0x1588c(%rip)        # 23158 <fwp_main_stack_top>
    d8cc:	48 8d 05 ad 57 00 00 	lea    0x57ad(%rip),%rax        # 13080 <alt.5>
    d8d3:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    d8d8:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    d8df:	01 00 
    d8e1:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    d8e8:	00 
    d8e9:	e8 d2 5d ff ff       	call   36c0 <sigaltstack@plt>
    d8ee:	85 c0                	test   %eax,%eax
    d8f0:	0f 85 8a 06 00 00    	jne    df80 <fwp_main_thread+0x710>
    d8f6:	31 c0                	xor    %eax,%eax
    d8f8:	b9 12 00 00 00       	mov    $0x12,%ecx
    d8fd:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    d902:	f3 48 ab             	rep stos %rax,(%rdi)
    d905:	48 8d 05 e4 63 ff ff 	lea    -0x9c1c(%rip),%rax        # 3cf0 <fwp_segv>
    d90c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    d911:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    d918:	04 00 00 08 
    d91c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    d921:	e8 5a 5c ff ff       	call   3580 <sigemptyset@plt>
    d926:	85 c0                	test   %eax,%eax
    d928:	0f 85 52 06 00 00    	jne    df80 <fwp_main_thread+0x710>
    d92e:	31 d2                	xor    %edx,%edx
    d930:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    d935:	bf 0b 00 00 00       	mov    $0xb,%edi
    d93a:	e8 c1 5a ff ff       	call   3400 <sigaction@plt>
    d93f:	85 c0                	test   %eax,%eax
    d941:	0f 85 39 06 00 00    	jne    df80 <fwp_main_thread+0x710>
    d947:	31 d2                	xor    %edx,%edx
    d949:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    d94e:	bf 07 00 00 00       	mov    $0x7,%edi
    d953:	e8 a8 5a ff ff       	call   3400 <sigaction@plt>
    d958:	85 c0                	test   %eax,%eax
    d95a:	0f 85 20 06 00 00    	jne    df80 <fwp_main_thread+0x710>
    d960:	8b 15 92 57 01 00    	mov    0x15792(%rip),%edx        # 230f8 <descent_registered>
    d966:	85 d2                	test   %edx,%edx
    d968:	0f 84 72 05 00 00    	je     dee0 <fwp_main_thread+0x670>
    d96e:	8b 05 fc 56 00 00    	mov    0x56fc(%rip),%eax        # 13070 <st.3>
    d974:	85 c0                	test   %eax,%eax
    d976:	0f 84 90 05 00 00    	je     df0c <fwp_main_thread+0x69c>
    d97c:	48 8b 2d 1d 5e 01 00 	mov    0x15e1d(%rip),%rbp        # 237a0 <fwp_cur>
    d983:	48 85 ed             	test   %rbp,%rbp
    d986:	0f 84 74 03 00 00    	je     dd00 <fwp_main_thread+0x490>
    d98c:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    d991:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    d995:	48 89 eb             	mov    %rbp,%rbx
    d998:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    d99d:	0f 84 41 01 00 00    	je     dae4 <fwp_main_thread+0x274>
    d9a3:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    d9a8:	0f 84 82 02 00 00    	je     dc30 <fwp_main_thread+0x3c0>
    d9ae:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    d9b2:	0f 84 68 02 00 00    	je     dc20 <fwp_main_thread+0x3b0>
    d9b8:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    d9bc:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    d9c0:	0f 85 ea 02 00 00    	jne    dcb0 <fwp_main_thread+0x440>
    d9c6:	48 8b 43 60          	mov    0x60(%rbx),%rax
    d9ca:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    d9d1:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    d9d5:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    d9dc:	00 00 00 00 
    d9e0:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    d9e7:	48 85 d2             	test   %rdx,%rdx
    d9ea:	74 07                	je     d9f3 <fwp_main_thread+0x183>
    d9ec:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    d9f3:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    d9f7:	48 85 c0             	test   %rax,%rax
    d9fa:	74 34                	je     da30 <fwp_main_thread+0x1c0>
    d9fc:	48 89 43 68          	mov    %rax,0x68(%rbx)
    da00:	48 8b 05 71 5d 01 00 	mov    0x15d71(%rip),%rax        # 23778 <fwp_timers>
    da07:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    da0b:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    da12:	00 00 00 00 
    da16:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    da1d:	48 85 c0             	test   %rax,%rax
    da20:	74 07                	je     da29 <fwp_main_thread+0x1b9>
    da22:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    da29:	48 89 1d 48 5d 01 00 	mov    %rbx,0x15d48(%rip)        # 23778 <fwp_timers>
    da30:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    da34:	e8 17 98 ff ff       	call   7250 <fwp_block>
    da39:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    da40:	48 85 c9             	test   %rcx,%rcx
    da43:	74 47                	je     da8c <fwp_main_thread+0x21c>
    da45:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    da4c:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    da53:	48 85 d2             	test   %rdx,%rdx
    da56:	0f 84 94 02 00 00    	je     dcf0 <fwp_main_thread+0x480>
    da5c:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    da63:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    da6a:	48 85 c0             	test   %rax,%rax
    da6d:	74 07                	je     da76 <fwp_main_thread+0x206>
    da6f:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    da76:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    da7d:	00 00 00 00 
    da81:	66 0f ef c0          	pxor   %xmm0,%xmm0
    da85:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    da8c:	48 8b 0d 0d 5d 01 00 	mov    0x15d0d(%rip),%rcx        # 237a0 <fwp_cur>
    da93:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    da97:	0f 84 03 02 00 00    	je     dca0 <fwp_main_thread+0x430>
    da9d:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    daa4:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    daab:	48 85 d2             	test   %rdx,%rdx
    daae:	0f 84 fc 03 00 00    	je     deb0 <fwp_main_thread+0x640>
    dab4:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    dabb:	48 85 c0             	test   %rax,%rax
    dabe:	74 07                	je     dac7 <fwp_main_thread+0x257>
    dac0:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    dac7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    dacb:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    dacf:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    dad6:	48 89 cb             	mov    %rcx,%rbx
    dad9:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    dade:	0f 85 bf fe ff ff    	jne    d9a3 <fwp_main_thread+0x133>
    dae4:	48 83 3d 4c 79 01 00 	cmpq   $0x0,0x1794c(%rip)        # 25438 <fwp_state_len>
    daeb:	00 
    daec:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    daf0:	0f 84 bc 00 00 00    	je     dbb2 <fwp_main_thread+0x342>
    daf6:	48 39 1d 9b 5c 01 00 	cmp    %rbx,0x15c9b(%rip)        # 23798 <fwp_root>
    dafd:	c7 05 79 55 01 00 00 	movl   $0x0,0x15579(%rip)        # 23080 <fwp_exit_code>
    db04:	00 00 00 
    db07:	0f 85 91 04 00 00    	jne    df9e <fwp_main_thread+0x72e>
    db0d:	48 85 db             	test   %rbx,%rbx
    db10:	0f 84 10 02 00 00    	je     dd26 <fwp_main_thread+0x4b6>
    db16:	48 8b 15 4b 5c 01 00 	mov    0x15c4b(%rip),%rdx        # 23768 <fwp_tasks_active>
    db1d:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    db21:	48 85 d2             	test   %rdx,%rdx
    db24:	0f 84 fc 01 00 00    	je     dd26 <fwp_main_thread+0x4b6>
    db2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    db30:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    db34:	75 08                	jne    db3e <fwp_main_thread+0x2ce>
    db36:	48 89 d7             	mov    %rdx,%rdi
    db39:	e8 c2 67 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    db3e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    db45:	48 85 d2             	test   %rdx,%rdx
    db48:	75 e6                	jne    db30 <fwp_main_thread+0x2c0>
    db4a:	eb 31                	jmp    db7d <fwp_main_thread+0x30d>
    db4c:	0f 1f 40 00          	nopl   0x0(%rax)
    db50:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    db57:	48 89 1d 22 5c 01 00 	mov    %rbx,0x15c22(%rip)        # 23780 <fwp_ready_tail>
    db5e:	e8 ed 96 ff ff       	call   7250 <fwp_block>
    db63:	e8 d8 94 ff ff       	call   7040 <fwp_free_zombie>
    db68:	48 83 3d f8 5b 01 00 	cmpq   $0x0,0x15bf8(%rip)        # 23768 <fwp_tasks_active>
    db6f:	00 
    db70:	0f 84 b0 01 00 00    	je     dd26 <fwp_main_thread+0x4b6>
    db76:	48 8b 1d 1b 5c 01 00 	mov    0x15c1b(%rip),%rbx        # 23798 <fwp_root>
    db7d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    db81:	75 db                	jne    db5e <fwp_main_thread+0x2ee>
    db83:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    db87:	75 d5                	jne    db5e <fwp_main_thread+0x2ee>
    db89:	48 8b 05 f0 5b 01 00 	mov    0x15bf0(%rip),%rax        # 23780 <fwp_ready_tail>
    db90:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    db94:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    db9b:	00 00 00 00 
    db9f:	48 85 c0             	test   %rax,%rax
    dba2:	75 ac                	jne    db50 <fwp_main_thread+0x2e0>
    dba4:	48 89 1d dd 5b 01 00 	mov    %rbx,0x15bdd(%rip)        # 23788 <fwp_ready_head>
    dbab:	eb aa                	jmp    db57 <fwp_main_thread+0x2e7>
    dbad:	0f 1f 00             	nopl   (%rax)
    dbb0:	31 db                	xor    %ebx,%ebx
    dbb2:	48 83 3d 6e 78 01 00 	cmpq   $0x0,0x1786e(%rip)        # 25428 <fwp_state_owners>
    dbb9:	00 
    dbba:	0f 85 36 ff ff ff    	jne    daf6 <fwp_main_thread+0x286>
    dbc0:	48 8b 3d 79 78 01 00 	mov    0x17879(%rip),%rdi        # 25440 <fwp_state>
    dbc7:	e8 c4 7b ff ff       	call   5790 <fwp_mem_free>
    dbcc:	48 c7 05 69 78 01 00 	movq   $0x0,0x17869(%rip)        # 25440 <fwp_state>
    dbd3:	00 00 00 00 
    dbd7:	48 c7 05 4e 78 01 00 	movq   $0x0,0x1784e(%rip)        # 25430 <fwp_state_cap>
    dbde:	00 00 00 00 
    dbe2:	48 85 db             	test   %rbx,%rbx
    dbe5:	0f 84 76 03 00 00    	je     df61 <fwp_main_thread+0x6f1>
    dbeb:	48 39 1d a6 5b 01 00 	cmp    %rbx,0x15ba6(%rip)        # 23798 <fwp_root>
    dbf2:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    dbf9:	00 00 00 00 
    dbfd:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    dc04:	00 00 00 00 
    dc08:	c7 05 6e 54 01 00 00 	movl   $0x0,0x1546e(%rip)        # 23080 <fwp_exit_code>
    dc0f:	00 00 00 
    dc12:	0f 84 fe fe ff ff    	je     db16 <fwp_main_thread+0x2a6>
    dc18:	e9 38 5b ff ff       	jmp    3755 <fwp_main_thread.cold>
    dc1d:	0f 1f 00             	nopl   (%rax)
    dc20:	e8 3b 69 ff ff       	call   4560 <fwp_now_ns>
    dc25:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    dc29:	0f 8d 91 02 00 00    	jge    dec0 <fwp_main_thread+0x650>
    dc2f:	90                   	nop
    dc30:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    dc34:	0f 85 7e fd ff ff    	jne    d9b8 <fwp_main_thread+0x148>
    dc3a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    dc3e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    dc42:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    dc46:	0f 85 7e fd ff ff    	jne    d9ca <fwp_main_thread+0x15a>
    dc4c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    dc50:	48 85 c9             	test   %rcx,%rcx
    dc53:	0f 84 71 fd ff ff    	je     d9ca <fwp_main_thread+0x15a>
    dc59:	48 85 c0             	test   %rax,%rax
    dc5c:	0f 84 2f 03 00 00    	je     df91 <fwp_main_thread+0x721>
    dc62:	48 39 c8             	cmp    %rcx,%rax
    dc65:	48 0f 4f c1          	cmovg  %rcx,%rax
    dc69:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    dc70:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    dc74:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    dc7b:	00 00 00 00 
    dc7f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    dc86:	48 85 d2             	test   %rdx,%rdx
    dc89:	74 07                	je     dc92 <fwp_main_thread+0x422>
    dc8b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    dc92:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    dc96:	e9 61 fd ff ff       	jmp    d9fc <fwp_main_thread+0x18c>
    dc9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    dca0:	48 89 cb             	mov    %rcx,%rbx
    dca3:	e9 f0 fc ff ff       	jmp    d998 <fwp_main_thread+0x128>
    dca8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    dcaf:	00 
    dcb0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    dcb4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    dcbb:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    dcc2:	00 00 00 00 
    dcc6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    dccd:	48 85 c0             	test   %rax,%rax
    dcd0:	0f 84 82 02 00 00    	je     df58 <fwp_main_thread+0x6e8>
    dcd6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    dcdd:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    dce1:	e9 4a fd ff ff       	jmp    da30 <fwp_main_thread+0x1c0>
    dce6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    dced:	00 00 00 
    dcf0:	48 89 01             	mov    %rax,(%rcx)
    dcf3:	e9 72 fd ff ff       	jmp    da6a <fwp_main_thread+0x1fa>
    dcf8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    dcff:	00 
    dd00:	48 83 3d 30 77 01 00 	cmpq   $0x0,0x17730(%rip)        # 25438 <fwp_state_len>
    dd07:	00 
    dd08:	0f 84 a2 fe ff ff    	je     dbb0 <fwp_main_thread+0x340>
    dd0e:	48 83 3d 82 5a 01 00 	cmpq   $0x0,0x15a82(%rip)        # 23798 <fwp_root>
    dd15:	00 
    dd16:	c7 05 60 53 01 00 00 	movl   $0x0,0x15360(%rip)        # 23080 <fwp_exit_code>
    dd1d:	00 00 00 
    dd20:	0f 85 7d 02 00 00    	jne    dfa3 <fwp_main_thread+0x733>
    dd26:	e8 15 93 ff ff       	call   7040 <fwp_free_zombie>
    dd2b:	48 83 3d 55 5a 01 00 	cmpq   $0x0,0x15a55(%rip)        # 23788 <fwp_ready_head>
    dd32:	00 
    dd33:	0f 85 1c 5a ff ff    	jne    3755 <fwp_main_thread.cold>
    dd39:	48 83 3d 37 5a 01 00 	cmpq   $0x0,0x15a37(%rip)        # 23778 <fwp_timers>
    dd40:	00 
    dd41:	0f 85 0e 5a ff ff    	jne    3755 <fwp_main_thread.cold>
    dd47:	8b 1d 17 54 01 00    	mov    0x15417(%rip),%ebx        # 23164 <fwp_stack_pool_n>
    dd4d:	85 db                	test   %ebx,%ebx
    dd4f:	74 36                	je     dd87 <fwp_main_thread+0x517>
    dd51:	83 eb 01             	sub    $0x1,%ebx
    dd54:	48 8d 05 25 54 01 00 	lea    0x15425(%rip),%rax        # 23180 <fwp_stack_pool>
    dd5b:	48 63 d3             	movslq %ebx,%rdx
    dd5e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    dd62:	eb 07                	jmp    dd6b <fwp_main_thread+0x4fb>
    dd64:	0f 1f 40 00          	nopl   0x0(%rax)
    dd68:	83 eb 01             	sub    $0x1,%ebx
    dd6b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    dd6f:	be 00 00 00 10       	mov    $0x10000000,%esi
    dd74:	89 1d ea 53 01 00    	mov    %ebx,0x153ea(%rip)        # 23164 <fwp_stack_pool_n>
    dd7a:	48 83 ed 08          	sub    $0x8,%rbp
    dd7e:	e8 5d 58 ff ff       	call   35e0 <munmap@plt>
    dd83:	85 db                	test   %ebx,%ebx
    dd85:	75 e1                	jne    dd68 <fwp_main_thread+0x4f8>
    dd87:	8b 3d 8f 52 00 00    	mov    0x528f(%rip),%edi        # 1301c <fwp_epfd>
    dd8d:	85 ff                	test   %edi,%edi
    dd8f:	78 05                	js     dd96 <fwp_main_thread+0x526>
    dd91:	e8 3a 57 ff ff       	call   34d0 <close@plt>
    dd96:	4c 8b 25 e3 55 01 00 	mov    0x155e3(%rip),%r12        # 23380 <fwp_nfdws>
    dd9d:	48 8b 2d e4 55 01 00 	mov    0x155e4(%rip),%rbp        # 23388 <fwp_fdws>
    dda4:	31 db                	xor    %ebx,%ebx
    dda6:	c7 05 6c 52 00 00 ff 	movl   $0xffffffff,0x526c(%rip)        # 1301c <fwp_epfd>
    ddad:	ff ff ff 
    ddb0:	4d 85 e4             	test   %r12,%r12
    ddb3:	74 38                	je     dded <fwp_main_thread+0x57d>
    ddb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ddbc:	00 00 00 00 
    ddc0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    ddc5:	48 85 ff             	test   %rdi,%rdi
    ddc8:	74 1a                	je     dde4 <fwp_main_thread+0x574>
    ddca:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    ddce:	0f 85 81 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    ddd4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    ddd9:	0f 85 76 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    dddf:	e8 ac 79 ff ff       	call   5790 <fwp_mem_free>
    dde4:	48 83 c3 01          	add    $0x1,%rbx
    dde8:	4c 39 e3             	cmp    %r12,%rbx
    ddeb:	75 d3                	jne    ddc0 <fwp_main_thread+0x550>
    dded:	48 89 ef             	mov    %rbp,%rdi
    ddf0:	e8 9b 79 ff ff       	call   5790 <fwp_mem_free>
    ddf5:	48 8b 15 9c 59 01 00 	mov    0x1599c(%rip),%rdx        # 23798 <fwp_root>
    ddfc:	48 c7 05 81 55 01 00 	movq   $0x0,0x15581(%rip)        # 23388 <fwp_fdws>
    de03:	00 00 00 00 
    de07:	48 c7 05 6e 55 01 00 	movq   $0x0,0x1556e(%rip)        # 23380 <fwp_nfdws>
    de0e:	00 00 00 00 
    de12:	48 85 d2             	test   %rdx,%rdx
    de15:	74 4e                	je     de65 <fwp_main_thread+0x5f5>
    de17:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    de1c:	0f 85 33 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    de22:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    de29:	00 
    de2a:	0f 85 25 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    de30:	48 83 3d 00 76 01 00 	cmpq   $0x0,0x17600(%rip)        # 25438 <fwp_state_len>
    de37:	00 
    de38:	0f 85 17 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    de3e:	48 83 3d e2 75 01 00 	cmpq   $0x0,0x175e2(%rip)        # 25428 <fwp_state_owners>
    de45:	00 
    de46:	0f 85 09 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    de4c:	b9 79 00 00 00       	mov    $0x79,%ecx
    de51:	31 c0                	xor    %eax,%eax
    de53:	48 8d 3d 46 55 01 00 	lea    0x15546(%rip),%rdi        # 233a0 <fwp_root_context>
    de5a:	f3 48 ab             	rep stos %rax,(%rdi)
    de5d:	48 89 d7             	mov    %rdx,%rdi
    de60:	e8 2b 79 ff ff       	call   5790 <fwp_mem_free>
    de65:	48 8b 3d b4 51 00 00 	mov    0x51b4(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    de6c:	48 c7 05 29 59 01 00 	movq   $0x0,0x15929(%rip)        # 237a0 <fwp_cur>
    de73:	00 00 00 00 
    de77:	48 c7 05 16 59 01 00 	movq   $0x0,0x15916(%rip)        # 23798 <fwp_root>
    de7e:	00 00 00 00 
    de82:	e8 39 57 ff ff       	call   35c0 <fflush@plt>
    de87:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    de8e:	00 
    de8f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    de96:	00 00 
    de98:	0f 85 fb 00 00 00    	jne    df99 <fwp_main_thread+0x729>
    de9e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    dea5:	31 c0                	xor    %eax,%eax
    dea7:	5b                   	pop    %rbx
    dea8:	5d                   	pop    %rbp
    dea9:	41 5c                	pop    %r12
    deab:	c3                   	ret
    deac:	0f 1f 40 00          	nopl   0x0(%rax)
    deb0:	48 89 05 c1 58 01 00 	mov    %rax,0x158c1(%rip)        # 23778 <fwp_timers>
    deb7:	e9 ff fb ff ff       	jmp    dabb <fwp_main_thread+0x24b>
    debc:	0f 1f 40 00          	nopl   0x0(%rax)
    dec0:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    dec4:	0f 85 66 fd ff ff    	jne    dc30 <fwp_main_thread+0x3c0>
    deca:	48 89 ef             	mov    %rbp,%rdi
    decd:	e8 2e 64 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    ded2:	e9 59 fd ff ff       	jmp    dc30 <fwp_main_thread+0x3c0>
    ded7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    dede:	00 00 
    dee0:	48 8d 3d 29 5f ff ff 	lea    -0xa0d7(%rip),%rdi        # 3e10 <descent_phase_report>
    dee7:	e8 d4 02 00 00       	call   e1c0 <atexit>
    deec:	85 c0                	test   %eax,%eax
    deee:	0f 85 98 00 00 00    	jne    df8c <fwp_main_thread+0x71c>
    def4:	c7 05 fa 51 01 00 01 	movl   $0x1,0x151fa(%rip)        # 230f8 <descent_registered>
    defb:	00 00 00 
    defe:	8b 05 6c 51 00 00    	mov    0x516c(%rip),%eax        # 13070 <st.3>
    df04:	85 c0                	test   %eax,%eax
    df06:	0f 85 70 fa ff ff    	jne    d97c <fwp_main_thread+0x10c>
    df0c:	e8 5f cc ff ff       	call   ab70 <f0>
    df11:	48 c7 05 4c 51 00 00 	movq   $0x0,0x514c(%rip)        # 13068 <v.2>
    df18:	00 00 00 00 
    df1c:	c7 05 4a 51 00 00 01 	movl   $0x1,0x514a(%rip)        # 13070 <st.3>
    df23:	00 00 00 
    df26:	e9 51 fa ff ff       	jmp    d97c <fwp_main_thread+0x10c>
    df2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    df30:	48 8d 3d 29 6d ff ff 	lea    -0x92d7(%rip),%rdi        # 4c60 <fwp_heap_report>
    df37:	e8 84 02 00 00       	call   e1c0 <atexit>
    df3c:	e9 6d f9 ff ff       	jmp    d8ae <fwp_main_thread+0x3e>
    df41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    df48:	e8 23 6e ff ff       	call   4d70 <fwp_heap_init>
    df4d:	e9 4e f9 ff ff       	jmp    d8a0 <fwp_main_thread+0x30>
    df52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    df58:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    df5c:	e9 cf fa ff ff       	jmp    da30 <fwp_main_thread+0x1c0>
    df61:	48 83 3d 2f 58 01 00 	cmpq   $0x0,0x1582f(%rip)        # 23798 <fwp_root>
    df68:	00 
    df69:	c7 05 0d 51 01 00 00 	movl   $0x0,0x1510d(%rip)        # 23080 <fwp_exit_code>
    df70:	00 00 00 
    df73:	0f 84 ad fd ff ff    	je     dd26 <fwp_main_thread+0x4b6>
    df79:	e9 d7 57 ff ff       	jmp    3755 <fwp_main_thread.cold>
    df7e:	66 90                	xchg   %ax,%ax
    df80:	48 8d 3d 61 1a 00 00 	lea    0x1a61(%rip),%rdi        # f9e8 <_IO_stdin_used+0x9e8>
    df87:	e8 64 64 ff ff       	call   43f0 <fwp_trap>
    df8c:	e8 4f 5e ff ff       	call   3de0 <descent_phase_fail>
    df91:	48 89 c8             	mov    %rcx,%rax
    df94:	e9 d0 fc ff ff       	jmp    dc69 <fwp_main_thread+0x3f9>
    df99:	e8 c2 54 ff ff       	call   3460 <__stack_chk_fail@plt>
    df9e:	e9 b2 57 ff ff       	jmp    3755 <fwp_main_thread.cold>
    dfa3:	e9 ad 57 ff ff       	jmp    3755 <fwp_main_thread.cold>
    dfa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    dfaf:	00 

000000000000dfb0 <__divmodti4>:
    dfb0:	f3 0f 1e fa          	endbr64
    dfb4:	55                   	push   %rbp
    dfb5:	49 89 f1             	mov    %rsi,%r9
    dfb8:	49 89 d2             	mov    %rdx,%r10
    dfbb:	48 89 fe             	mov    %rdi,%rsi
    dfbe:	49 89 cb             	mov    %rcx,%r11
    dfc1:	48 89 e5             	mov    %rsp,%rbp
    dfc4:	41 57                	push   %r15
    dfc6:	41 56                	push   %r14
    dfc8:	41 55                	push   %r13
    dfca:	41 54                	push   %r12
    dfcc:	53                   	push   %rbx
    dfcd:	4c 89 c3             	mov    %r8,%rbx
    dfd0:	45 31 c0             	xor    %r8d,%r8d
    dfd3:	4d 85 c9             	test   %r9,%r9
    dfd6:	79 12                	jns    dfea <__divmodti4+0x3a>
    dfd8:	31 ff                	xor    %edi,%edi
    dfda:	48 f7 de             	neg    %rsi
    dfdd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    dfe4:	4c 19 cf             	sbb    %r9,%rdi
    dfe7:	49 89 f9             	mov    %rdi,%r9
    dfea:	4c 89 d8             	mov    %r11,%rax
    dfed:	4d 85 db             	test   %r11,%r11
    dff0:	0f 88 1a 01 00 00    	js     e110 <__divmodti4+0x160>
    dff6:	4c 89 d9             	mov    %r11,%rcx
    dff9:	49 89 f3             	mov    %rsi,%r11
    dffc:	75 62                	jne    e060 <__divmodti4+0xb0>
    dffe:	4d 89 c4             	mov    %r8,%r12
    e001:	4d 39 d1             	cmp    %r10,%r9
    e004:	0f 83 46 01 00 00    	jae    e150 <__divmodti4+0x1a0>
    e00a:	4c 89 d8             	mov    %r11,%rax
    e00d:	4c 89 ca             	mov    %r9,%rdx
    e010:	49 f7 f2             	div    %r10
    e013:	49 89 c3             	mov    %rax,%r11
    e016:	31 c0                	xor    %eax,%eax
    e018:	48 89 d6             	mov    %rdx,%rsi
    e01b:	31 ff                	xor    %edi,%edi
    e01d:	4c 89 d9             	mov    %r11,%rcx
    e020:	48 89 c2             	mov    %rax,%rdx
    e023:	48 89 c8             	mov    %rcx,%rax
    e026:	4d 85 e4             	test   %r12,%r12
    e029:	74 0a                	je     e035 <__divmodti4+0x85>
    e02b:	48 f7 d8             	neg    %rax
    e02e:	48 83 d2 00          	adc    $0x0,%rdx
    e032:	48 f7 da             	neg    %rdx
    e035:	4d 85 c0             	test   %r8,%r8
    e038:	74 0a                	je     e044 <__divmodti4+0x94>
    e03a:	48 f7 de             	neg    %rsi
    e03d:	48 83 d7 00          	adc    $0x0,%rdi
    e041:	48 f7 df             	neg    %rdi
    e044:	48 89 33             	mov    %rsi,(%rbx)
    e047:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    e04b:	5b                   	pop    %rbx
    e04c:	41 5c                	pop    %r12
    e04e:	41 5d                	pop    %r13
    e050:	41 5e                	pop    %r14
    e052:	41 5f                	pop    %r15
    e054:	5d                   	pop    %rbp
    e055:	c3                   	ret
    e056:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e05d:	00 00 00 
    e060:	4d 89 c4             	mov    %r8,%r12
    e063:	49 39 c1             	cmp    %rax,%r9
    e066:	0f 82 ce 00 00 00    	jb     e13a <__divmodti4+0x18a>
    e06c:	31 ff                	xor    %edi,%edi
    e06e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    e073:	48 63 c7             	movslq %edi,%rax
    e076:	be 40 00 00 00       	mov    $0x40,%esi
    e07b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    e080:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    e085:	48 29 c6             	sub    %rax,%rsi
    e088:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    e08d:	48 09 c8             	or     %rcx,%rax
    e090:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    e095:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    e09a:	49 89 c6             	mov    %rax,%r14
    e09d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    e0a1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    e0a6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    e0ab:	49 09 c1             	or     %rax,%r9
    e0ae:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    e0b2:	4c 89 c8             	mov    %r9,%rax
    e0b5:	49 f7 f6             	div    %r14
    e0b8:	48 89 d1             	mov    %rdx,%rcx
    e0bb:	49 89 c3             	mov    %rax,%r11
    e0be:	49 89 c1             	mov    %rax,%r9
    e0c1:	49 f7 e2             	mul    %r10
    e0c4:	49 89 c6             	mov    %rax,%r14
    e0c7:	49 89 d2             	mov    %rdx,%r10
    e0ca:	48 39 d1             	cmp    %rdx,%rcx
    e0cd:	72 07                	jb     e0d6 <__divmodti4+0x126>
    e0cf:	75 17                	jne    e0e8 <__divmodti4+0x138>
    e0d1:	49 39 c7             	cmp    %rax,%r15
    e0d4:	73 12                	jae    e0e8 <__divmodti4+0x138>
    e0d6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    e0da:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    e0de:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    e0e2:	49 89 d2             	mov    %rdx,%r10
    e0e5:	49 89 c6             	mov    %rax,%r14
    e0e8:	4c 89 f8             	mov    %r15,%rax
    e0eb:	4c 29 f0             	sub    %r14,%rax
    e0ee:	4c 19 d1             	sbb    %r10,%rcx
    e0f1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    e0f6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    e0fb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    e100:	48 09 c6             	or     %rax,%rsi
    e103:	48 89 cf             	mov    %rcx,%rdi
    e106:	31 c0                	xor    %eax,%eax
    e108:	4c 89 c9             	mov    %r9,%rcx
    e10b:	e9 10 ff ff ff       	jmp    e020 <__divmodti4+0x70>
    e110:	4c 89 d0             	mov    %r10,%rax
    e113:	4c 89 da             	mov    %r11,%rdx
    e116:	4d 89 c4             	mov    %r8,%r12
    e119:	49 89 f3             	mov    %rsi,%r11
    e11c:	48 f7 d8             	neg    %rax
    e11f:	49 f7 d4             	not    %r12
    e122:	48 83 d2 00          	adc    $0x0,%rdx
    e126:	49 89 c2             	mov    %rax,%r10
    e129:	48 f7 da             	neg    %rdx
    e12c:	48 89 d1             	mov    %rdx,%rcx
    e12f:	0f 84 cc fe ff ff    	je     e001 <__divmodti4+0x51>
    e135:	49 39 d1             	cmp    %rdx,%r9
    e138:	73 46                	jae    e180 <__divmodti4+0x1d0>
    e13a:	4c 89 cf             	mov    %r9,%rdi
    e13d:	31 c0                	xor    %eax,%eax
    e13f:	31 c9                	xor    %ecx,%ecx
    e141:	e9 da fe ff ff       	jmp    e020 <__divmodti4+0x70>
    e146:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e14d:	00 00 00 
    e150:	4d 85 d2             	test   %r10,%r10
    e153:	75 0d                	jne    e162 <__divmodti4+0x1b2>
    e155:	b8 01 00 00 00       	mov    $0x1,%eax
    e15a:	31 d2                	xor    %edx,%edx
    e15c:	49 f7 f2             	div    %r10
    e15f:	49 89 c2             	mov    %rax,%r10
    e162:	4c 89 c8             	mov    %r9,%rax
    e165:	31 d2                	xor    %edx,%edx
    e167:	49 f7 f2             	div    %r10
    e16a:	49 89 c1             	mov    %rax,%r9
    e16d:	4c 89 d8             	mov    %r11,%rax
    e170:	49 f7 f2             	div    %r10
    e173:	49 89 c3             	mov    %rax,%r11
    e176:	4c 89 c8             	mov    %r9,%rax
    e179:	e9 9a fe ff ff       	jmp    e018 <__divmodti4+0x68>
    e17e:	66 90                	xchg   %ax,%ax
    e180:	45 31 f6             	xor    %r14d,%r14d
    e183:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    e188:	44 89 f7             	mov    %r14d,%edi
    e18b:	45 85 f6             	test   %r14d,%r14d
    e18e:	0f 85 df fe ff ff    	jne    e073 <__divmodti4+0xc3>
    e194:	4c 39 ca             	cmp    %r9,%rdx
    e197:	72 17                	jb     e1b0 <__divmodti4+0x200>
    e199:	31 c9                	xor    %ecx,%ecx
    e19b:	48 39 c6             	cmp    %rax,%rsi
    e19e:	73 10                	jae    e1b0 <__divmodti4+0x200>
    e1a0:	4c 89 cf             	mov    %r9,%rdi
    e1a3:	31 c0                	xor    %eax,%eax
    e1a5:	e9 76 fe ff ff       	jmp    e020 <__divmodti4+0x70>
    e1aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e1b0:	4c 89 de             	mov    %r11,%rsi
    e1b3:	b9 01 00 00 00       	mov    $0x1,%ecx
    e1b8:	48 29 c6             	sub    %rax,%rsi
    e1bb:	49 19 d1             	sbb    %rdx,%r9
    e1be:	eb e0                	jmp    e1a0 <__divmodti4+0x1f0>

000000000000e1c0 <atexit>:
    e1c0:	f3 0f 1e fa          	endbr64
    e1c4:	48 8b 15 3d 4e 00 00 	mov    0x4e3d(%rip),%rdx        # 13008 <__dso_handle>
    e1cb:	31 f6                	xor    %esi,%esi
    e1cd:	e9 8e 54 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000e1d4 <_fini>:
    e1d4:	f3 0f 1e fa          	endbr64
    e1d8:	48 83 ec 08          	sub    $0x8,%rsp
    e1dc:	48 83 c4 08          	add    $0x8,%rsp
    e1e0:	c3                   	ret
