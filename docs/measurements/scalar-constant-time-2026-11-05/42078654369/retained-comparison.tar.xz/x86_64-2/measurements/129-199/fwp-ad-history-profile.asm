
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 0f 01 00 	mov    0x10fd1(%rip),%rax        # 13fe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 0d 01 00    	push   0x10df2(%rip)        # 13e18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 0d 01 00    	jmp    *0x10df4(%rip)        # 13e20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 0c 01 00    	jmp    *0x10c66(%rip)        # 13ff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e 0a 01 00    	jmp    *0x10a8e(%rip)        # 13e28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 0a 01 00    	jmp    *0x10a86(%rip)        # 13e30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e 0a 01 00    	jmp    *0x10a7e(%rip)        # 13e38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 0a 01 00    	jmp    *0x10a76(%rip)        # 13e40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e 0a 01 00    	jmp    *0x10a6e(%rip)        # 13e48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 0a 01 00    	jmp    *0x10a66(%rip)        # 13e50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e 0a 01 00    	jmp    *0x10a5e(%rip)        # 13e58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 0a 01 00    	jmp    *0x10a56(%rip)        # 13e60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e 0a 01 00    	jmp    *0x10a4e(%rip)        # 13e68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 0a 01 00    	jmp    *0x10a46(%rip)        # 13e70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e 0a 01 00    	jmp    *0x10a3e(%rip)        # 13e78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 0a 01 00    	jmp    *0x10a36(%rip)        # 13e80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e 0a 01 00    	jmp    *0x10a2e(%rip)        # 13e88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 0a 01 00    	jmp    *0x10a26(%rip)        # 13e90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e 0a 01 00    	jmp    *0x10a1e(%rip)        # 13e98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 0a 01 00    	jmp    *0x10a16(%rip)        # 13ea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e 0a 01 00    	jmp    *0x10a0e(%rip)        # 13ea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 0a 01 00    	jmp    *0x10a06(%rip)        # 13eb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe 09 01 00    	jmp    *0x109fe(%rip)        # 13eb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 09 01 00    	jmp    *0x109f6(%rip)        # 13ec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee 09 01 00    	jmp    *0x109ee(%rip)        # 13ec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 09 01 00    	jmp    *0x109e6(%rip)        # 13ed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de 09 01 00    	jmp    *0x109de(%rip)        # 13ed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 09 01 00    	jmp    *0x109d6(%rip)        # 13ee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce 09 01 00    	jmp    *0x109ce(%rip)        # 13ee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 09 01 00    	jmp    *0x109c6(%rip)        # 13ef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be 09 01 00    	jmp    *0x109be(%rip)        # 13ef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 09 01 00    	jmp    *0x109b6(%rip)        # 13f00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae 09 01 00    	jmp    *0x109ae(%rip)        # 13f08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 09 01 00    	jmp    *0x109a6(%rip)        # 13f10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e 09 01 00    	jmp    *0x1099e(%rip)        # 13f18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 09 01 00    	jmp    *0x10996(%rip)        # 13f20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e 09 01 00    	jmp    *0x1098e(%rip)        # 13f28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 09 01 00    	jmp    *0x10986(%rip)        # 13f30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e 09 01 00    	jmp    *0x1097e(%rip)        # 13f38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 09 01 00    	jmp    *0x10976(%rip)        # 13f40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e 09 01 00    	jmp    *0x1096e(%rip)        # 13f48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 09 01 00    	jmp    *0x10966(%rip)        # 13f50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e 09 01 00    	jmp    *0x1095e(%rip)        # 13f58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 09 01 00    	jmp    *0x10956(%rip)        # 13f60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e 09 01 00    	jmp    *0x1094e(%rip)        # 13f68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 09 01 00    	jmp    *0x10946(%rip)        # 13f70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e 09 01 00    	jmp    *0x1093e(%rip)        # 13f78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 09 01 00    	jmp    *0x10936(%rip)        # 13f80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e 09 01 00    	jmp    *0x1092e(%rip)        # 13f88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 09 01 00    	jmp    *0x10926(%rip)        # 13f90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e 09 01 00    	jmp    *0x1091e(%rip)        # 13f98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 09 01 00    	jmp    *0x10916(%rip)        # 13fa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e 09 01 00    	jmp    *0x1090e(%rip)        # 13fa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 09 01 00    	jmp    *0x10906(%rip)        # 13fb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe 08 01 00    	jmp    *0x108fe(%rip)        # 13fb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 08 01 00    	jmp    *0x108f6(%rip)        # 13fc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee 08 01 00    	jmp    *0x108ee(%rip)        # 13fc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 c9 00 00 	lea    0xc9b8(%rip),%r9        # 100cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 c9 00 00 	lea    0xc9b5(%rip),%r8        # 100d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 6b fc ff ff       	call   33c0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 66 fc ff ff       	call   33c0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 ed 00 00 	lea    0xed01(%rip),%rax        # 12480 <fwp_fn_table>
    377f:	48 89 05 12 ad 06 00 	mov    %rax,0x6ad12(%rip)        # 6e498 <fwp_fns>
    3786:	48 8b 05 b3 08 01 00 	mov    0x108b3(%rip),%rax        # 14040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 0c ad 06 00 	mov    %rax,0x6ad0c(%rip)        # 6e4a0 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e cb 00 00 	lea    0xcb4e(%rip),%rdi        # 102ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 08 01 00 	mov    0x10838(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 ff af 00 00 	lea    0xafff(%rip),%rdx        # e860 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 07 01 00 	mov    0x107a3(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 f8 07 02 00    	mov    0x207f8(%rip),%eax        # 240a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe c9 00 00 	lea    0xc9fe(%rip),%rdi        # 102f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 46 d3 00 00 	lea    0xd346(%rip),%rdi        # 10c50 <_IO_stdin_used+0xc50>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 00 d3 00 00 	lea    0xd300(%rip),%rdi        # 10c28 <_IO_stdin_used+0xc28>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d c4 d2 00 00 	lea    0xd2c4(%rip),%rdi        # 10bf8 <_IO_stdin_used+0xbf8>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d 90 d2 00 00 	lea    0xd290(%rip),%rdi        # 10bd0 <_IO_stdin_used+0xbd0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b 06 01 00    	call   *0x1065b(%rip)        # 13fd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 06 01 00 	lea    0x106a1(%rip),%rdi        # 14028 <__TMC_END__>
    3987:	48 8d 05 9a 06 01 00 	lea    0x1069a(%rip),%rax        # 14028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e 06 01 00 	mov    0x1063e(%rip),%rax        # 13fd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 06 01 00 	lea    0x10671(%rip),%rdi        # 14028 <__TMC_END__>
    39b7:	48 8d 35 6a 06 01 00 	lea    0x1066a(%rip),%rsi        # 14028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d 06 01 00 	mov    0x1060d(%rip),%rax        # 13fe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d 06 01 00 00 	cmpb   $0x0,0x1066d(%rip)        # 14068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea 05 01 00 	cmpq   $0x0,0x105ea(%rip)        # 13ff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 05 01 00 	mov    0x105f6(%rip),%rdi        # 14008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 06 01 00 01 	movb   $0x1,0x10645(%rip)        # 14068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 b7 05 05 00 	lea    0x505b7(%rip),%r8        # 541c0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 5b 05 05 00 	lea    0x5055b(%rip),%rcx        # 54180 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 2f 05 05 00 	lea    0x5052f(%rip),%rcx        # 54160 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 61 05 05 00 	lea    0x50561(%rip),%rcx        # 541a0 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 70 05 05 	movdqa 0x50570(%rip),%xmm0        # 541d0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 58 05 05 	paddq  0x50558(%rip),%xmm0        # 541c0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 bf 04 05 00 	cmp    %rax,0x504bf(%rip)        # 54140 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 b5 04 05 	movq   %xmm0,0x504b5(%rip)        # 54140 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 5e 04 02 00 	add    0x2045e(%rip),%rdx        # 24110 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 4c 04 02 00 	add    0x2044c(%rip),%rax        # 24110 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args161>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 99 a7 06 00 	mov    0x6a799(%rip),%rdi        # 6e4a0 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 24 03 01 00 	mov    0x10324(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d 11 03 01 00 	mov    0x10311(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 d1 8a 06 00 	mov    0x68ad1(%rip),%rax        # 6c820 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 19 84 06 00 	mov    0x68419(%rip),%rax        # 6c1e8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 05 84 06 00 	sub    0x68405(%rip),%rax        # 6c1e0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 1d cf 00 00 	lea    0xcf1d(%rip),%rsi        # 10d30 <msg.4>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 c1 00 00 	lea    0xc1c5(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d 12 02 01 00 	mov    0x10212(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 ab 9d 06 00 	mov    0x69dab(%rip),%rax        # 6dc30 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 a4 9d 06 00 	lea    0x69da4(%rip),%r8        # 6dc30 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 85 9d 06 00 	mov    0x69d85(%rip),%rbx        # 6dc18 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 95 9d 06 00 	mov    0x69d95(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 31 9d 06 00 	mov    0x69d31(%rip),%rdi        # 6dc20 <fwp_heap+0x13e0>
    3eef:	48 29 35 7a 9d 06 00 	sub    %rsi,0x69d7a(%rip)        # 6dc70 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 0a 9d 06 00 	mov    0x69d0a(%rip),%rax        # 6dc10 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d c0 9c 06 00 	add    0x69cc0(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ce 9c 06 00 	mov    0x69cce(%rip),%rsi        # 6dc20 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 dc 9c 06 00 	mov    0x69cdc(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 8b 9c 06 00 	mov    %r12,0x69c8b(%rip)        # 6dc20 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 79 9c 06 00 	mov    %rbp,0x69c79(%rip)        # 6dc18 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 5e 9c 06 00 	cmp    %rdi,0x69c5e(%rip)        # 6dc08 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 55 9c 06 00 	mov    %rdi,0x69c55(%rip)        # 6dc08 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 99 9c 06 00 	sub    %rdi,0x69c99(%rip)        # 6dc70 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 41 9c 06 00 	mov    0x69c41(%rip),%rax        # 6dc28 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 3a 9c 06 00 	lea    0x69c3a(%rip),%r8        # 6dc28 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ef c6 00 00 	lea    0xc6ef(%rip),%rdx        # 106f8 <_IO_stdin_used+0x6f8>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 42 00 01 00 	mov    0x10042(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 9d ff 00 00 	mov    0xff9d(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 bf 00 00 	lea    0xbf34(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d e9 86 06 00 	cmp    0x686e9(%rip),%rdi        # 6c820 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 af 86 06 00 	mov    0x686af(%rip),%rax        # 6c800 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 8d 86 06 00 	mov    %rdi,0x6868d(%rip)        # 6c800 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 69 86 06 00 	mov    %rdi,0x68669(%rip)        # 6c808 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 5f c0 00 00 	lea    0xc05f(%rip),%rsi        # 10240 <_IO_stdin_used+0x240>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 be 00 00 	lea    0xbe27(%rip),%rsi        # 1001c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 96 ff 04 	movdqa 0x4ff96(%rip),%xmm0        # 541d0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 7e ff 04 	paddq  0x4ff7e(%rip),%xmm0        # 541c0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 a4 fe 01 00 	mov    0x1fea4(%rip),%r8        # 24118 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d be fe 04 00 	mov    0x4febe(%rip),%rcx        # 54140 <ad_raw_total_peak>
    4282:	48 8b 3d d7 fd 00 00 	mov    0xfdd7(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 b5 c4 00 00 	lea    0xc4b5(%rip),%rdx        # 10748 <_IO_stdin_used+0x748>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d 01 ff 04 00 	lea    0x4ff01(%rip),%r15        # 541a0 <ad_raw_peak>
    429f:	4c 8d 35 ba fe 04 00 	lea    0x4feba(%rip),%r14        # 54160 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 bd 00 00 	lea    0xbd79(%rip),%rax        # 1002b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 f9 00 	movq   0xf956(%rip),%xmm0        # 13c10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d bf fe 04 00 	lea    0x4febf(%rip),%r13        # 54180 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f bd 00 00 	lea    0xbd6f(%rip),%rax        # 1003c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 f9 00 	movq   0xf936(%rip),%xmm0        # 13c18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 53 fd 00 00 	mov    0xfd53(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c bd 00 00 	lea    0xbd0c(%rip),%rcx        # 10020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 8d c4 00 00 	lea    0xc48d(%rip),%rdx        # 107a8 <_IO_stdin_used+0x7a8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 24 fd 00 00 	mov    0xfd24(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 bc 00 00 	lea    0xbcf8(%rip),%rdi        # 10045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d c6 fd 01 00 	cmpq   $0x0,0x1fdc6(%rip)        # 24120 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 dd fd 01 00 	mov    0x1fddd(%rip),%r8        # 24140 <ad_raw_checkpoints>
    4363:	4c 8b 0d de fd 01 00 	mov    0x1fdde(%rip),%r9        # 24148 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d cf fd 01 00 	lea    0x1fdcf(%rip),%rbx        # 24140 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 bc 00 00 	lea    0xbcf4(%rip),%rcx        # 1006c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 d1 fd 01 00 	mov    0x1fdd1(%rip),%rax        # 24150 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a bc 00 00 	lea    0xbc9a(%rip),%r12        # 10020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d a9 fc 00 00 	mov    0xfca9(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 29 c4 00 00 	lea    0xc429(%rip),%rdx        # 107e8 <_IO_stdin_used+0x7e8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 53 fd 01 00 	cmp    0x1fd53(%rip),%rbp        # 24120 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 78 fc 00 00 	mov    0xfc78(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b bc 00 00 	lea    0xbc5b(%rip),%rdi        # 10059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 43 fc 00 00 	mov    0xfc43(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 84 c3 00 00 	lea    0xc384(%rip),%rdx        # 107a8 <_IO_stdin_used+0x7a8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 bc 00 00 	lea    0xbc40(%rip),%rcx        # 1006c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d da c2 00 00 	lea    0xc2da(%rip),%rdi        # 10720 <_IO_stdin_used+0x720>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d e8 fb 00 00 	mov    0xfbe8(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df bb 00 00 	lea    0xbbdf(%rip),%rdx        # 1005e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d d0 fb 00 00 	mov    0xfbd0(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d e1 fa 00 00 	mov    0xfae1(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 ba 00 00 	lea    0xba78(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 ba 00 00 	lea    0xbac0(%rip),%rdi        # 1006d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 ba 00 00 	lea    0xba48(%rip),%rdi        # 10087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d d8 c1 00 00 	lea    0xc1d8(%rip),%rdi        # 10828 <_IO_stdin_used+0x828>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 e0 c6 00 	movdqa 0xc6e0(%rip),%xmm0        # 10d50 <msg.4+0x20>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 ca 9d 06 00 	add    0x69dca(%rip),%rax        # 6e498 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 2c c1 00 00 	lea    0xc12c(%rip),%rdi        # 10850 <_IO_stdin_used+0x850>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 c5 f9 01 00 	cmp    %rax,0x1f9c5(%rip)        # 24108 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 c0 f9 01 00 	add    0x1f9c0(%rip),%rax        # 24110 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 15 c1 00 00 	lea    0xc115(%rip),%rdi        # 10880 <_IO_stdin_used+0x880>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 b9 00 00 	lea    0xb920(%rip),%r8        # 100a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 b7 00 00 	lea    0xb775(%rip),%r8        # 100b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 b6 00 00 	lea    0xb612(%rip),%r8        # 100a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea b3 00 00 	lea    0xb3ea(%rip),%rdi        # 100b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 9a b5 00 00 	lea    0xb59a(%rip),%rsi        # 10288 <_IO_stdin_used+0x288>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d a5 8e 06 00 	mov    0x68ea5(%rip),%r9        # 6dc08 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 fe 8e 06 00 	mov    0x68efe(%rip),%r8        # 6dc68 <fwp_heap+0x1428>
    4d6a:	48 8d 15 5f bb 00 00 	lea    0xbb5f(%rip),%rdx        # 108d0 <_IO_stdin_used+0x8d0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d e6 8e 06 00 	mov    0x68ee6(%rip),%rcx        # 6dc60 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d f4 8e 06 	movsd  0x68ef4(%rip),%xmm1        # 6dc80 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 e4 8e 06 	movsd  0x68ee4(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d c5 f2 00 00 	mov    0xf2c5(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 88 bf 00 	movdqa 0xbf88(%rip),%xmm0        # 10d60 <msg.4+0x30>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 9f 89 06 00 	lea    0x6899f(%rip),%rax        # 6d780 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 b1 bf 00 	movdqa 0xbfb1(%rip),%xmm2        # 10da0 <msg.4+0x70>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 45 89 06 00 	movaps %xmm0,0x68945(%rip)        # 6d740 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 6d bf 00 	movdqa 0xbf6d(%rip),%xmm0        # 10d70 <msg.4+0x40>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 d3 8d 06 00 01 	movl   $0x1,0x68dd3(%rip)        # 6dbe4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 33 89 06 00 	movaps %xmm0,0x68933(%rip)        # 6d750 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 5b bf 00 	movdqa 0xbf5b(%rip),%xmm0        # 10d80 <msg.4+0x50>
    4e24:	00 
    4e25:	0f 29 05 34 89 06 00 	movaps %xmm0,0x68934(%rip)        # 6d760 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 5c bf 00 	movdqa 0xbf5c(%rip),%xmm0        # 10d90 <msg.4+0x60>
    4e33:	00 
    4e34:	0f 29 05 35 89 06 00 	movaps %xmm0,0x68935(%rip)        # 6d770 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 b5 79 06 00 	lea    0x679b5(%rip),%r8        # 6c840 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 d0 8c 06 00 	mov    %rax,0x68cd0(%rip)        # 6dbf8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 ae 8c 06 00 	mov    %r12,0x68cae(%rip)        # 6dc00 <fwp_heap+0x13c0>
    4f52:	48 89 05 97 8c 06 00 	mov    %rax,0x68c97(%rip)        # 6dbf0 <fwp_heap+0x13b0>
    4f59:	48 89 1d b0 8c 06 00 	mov    %rbx,0x68cb0(%rip)        # 6dc10 <fwp_heap+0x13d0>
    4f60:	48 89 35 d9 8c 06 00 	mov    %rsi,0x68cd9(%rip)        # 6dc40 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 b1 00 00 	lea    0xb174(%rip),%rdi        # 100ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 b8 8c 06 00 	mov    %rax,0x68cb8(%rip)        # 6dc38 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 3c 8c 06 00    	mov    %eax,0x68c3c(%rip)        # 6dbe8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 2c 78 06 00 	mov    0x6782c(%rip),%r8        # 6c800 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d 5c 77 06 00 	mov    %rbx,0x6775c(%rip)        # 6c808 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 48 77 06 00 	mov    %r8,0x67748(%rip)        # 6c800 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <ad_raw_free.part.0>:
    50d0:	48 8d 0d 09 f1 04 00 	lea    0x4f109(%rip),%rcx        # 541e0 <ad_raw_blocks>
    50d7:	31 c0                	xor    %eax,%eax
    50d9:	48 89 ca             	mov    %rcx,%rdx
    50dc:	eb 12                	jmp    50f0 <ad_raw_free.part.0+0x20>
    50de:	66 90                	xchg   %ax,%ax
    50e0:	48 83 c0 01          	add    $0x1,%rax
    50e4:	48 83 c2 18          	add    $0x18,%rdx
    50e8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ee:	74 40                	je     5130 <ad_raw_free.part.0+0x60>
    50f0:	48 3b 3a             	cmp    (%rdx),%rdi
    50f3:	75 eb                	jne    50e0 <ad_raw_free.part.0+0x10>
    50f5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50f9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5101:	48 8d 0d b8 f0 04 00 	lea    0x4f0b8(%rip),%rcx        # 541c0 <ad_raw_live>
    5108:	8b 70 10             	mov    0x10(%rax),%esi
    510b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5112:	00 
    5113:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5117:	48 2b 50 08          	sub    0x8(%rax),%rdx
    511b:	0f 11 00             	movups %xmm0,(%rax)
    511e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5122:	e9 89 e2 ff ff       	jmp    33b0 <free@plt>
    5127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    512e:	00 00 
    5130:	48 83 ec 08          	sub    $0x8,%rsp
    5134:	48 8d 3d c2 af 00 00 	lea    0xafc2(%rip),%rdi        # 100fd <_IO_stdin_used+0xfd>
    513b:	e8 c0 ee ff ff       	call   4000 <ad_raw_fail>

0000000000005140 <fwp_tape_buffers_dispose>:
    5140:	53                   	push   %rbx
    5141:	48 89 fb             	mov    %rdi,%rbx
    5144:	48 8b 3f             	mov    (%rdi),%rdi
    5147:	48 85 ff             	test   %rdi,%rdi
    514a:	74 05                	je     5151 <fwp_tape_buffers_dispose+0x11>
    514c:	e8 7f ff ff ff       	call   50d0 <ad_raw_free.part.0>
    5151:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5155:	48 85 ff             	test   %rdi,%rdi
    5158:	74 05                	je     515f <fwp_tape_buffers_dispose+0x1f>
    515a:	e8 71 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    515f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5163:	48 85 ff             	test   %rdi,%rdi
    5166:	74 05                	je     516d <fwp_tape_buffers_dispose+0x2d>
    5168:	e8 63 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    516d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5171:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5178:	00 
    5179:	0f 11 03             	movups %xmm0,(%rbx)
    517c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5180:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5184:	5b                   	pop    %rbx
    5185:	c3                   	ret
    5186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    518d:	00 00 00 

0000000000005190 <ad_raw_realloc>:
    5190:	41 55                	push   %r13
    5192:	41 54                	push   %r12
    5194:	55                   	push   %rbp
    5195:	53                   	push   %rbx
    5196:	48 83 ec 08          	sub    $0x8,%rsp
    519a:	48 85 f6             	test   %rsi,%rsi
    519d:	0f 84 a6 00 00 00    	je     5249 <ad_raw_realloc+0xb9>
    51a3:	4c 8d 25 36 f0 04 00 	lea    0x4f036(%rip),%r12        # 541e0 <ad_raw_blocks>
    51aa:	48 89 f5             	mov    %rsi,%rbp
    51ad:	41 89 d5             	mov    %edx,%r13d
    51b0:	31 db                	xor    %ebx,%ebx
    51b2:	4c 89 e0             	mov    %r12,%rax
    51b5:	eb 1a                	jmp    51d1 <ad_raw_realloc+0x41>
    51b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51be:	00 00 
    51c0:	48 83 c3 01          	add    $0x1,%rbx
    51c4:	48 83 c0 18          	add    $0x18,%rax
    51c8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51cf:	74 4f                	je     5220 <ad_raw_realloc+0x90>
    51d1:	48 3b 38             	cmp    (%rax),%rdi
    51d4:	75 ea                	jne    51c0 <ad_raw_realloc+0x30>
    51d6:	48 85 ff             	test   %rdi,%rdi
    51d9:	74 0b                	je     51e6 <ad_raw_realloc+0x56>
    51db:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51df:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51e4:	75 57                	jne    523d <ad_raw_realloc+0xad>
    51e6:	48 89 ee             	mov    %rbp,%rsi
    51e9:	e8 c2 e3 ff ff       	call   35b0 <realloc@plt>
    51ee:	49 89 c2             	mov    %rax,%r10
    51f1:	48 85 c0             	test   %rax,%rax
    51f4:	74 16                	je     520c <ad_raw_realloc+0x7c>
    51f6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51fa:	44 89 e9             	mov    %r13d,%ecx
    51fd:	48 89 ea             	mov    %rbp,%rdx
    5200:	4c 89 d6             	mov    %r10,%rsi
    5203:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5207:	e8 f4 e9 ff ff       	call   3c00 <ad_raw_record>
    520c:	48 83 c4 08          	add    $0x8,%rsp
    5210:	4c 89 d0             	mov    %r10,%rax
    5213:	5b                   	pop    %rbx
    5214:	5d                   	pop    %rbp
    5215:	41 5c                	pop    %r12
    5217:	41 5d                	pop    %r13
    5219:	c3                   	ret
    521a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5220:	48 85 ff             	test   %rdi,%rdi
    5223:	48 8d 05 e8 ae 00 00 	lea    0xaee8(%rip),%rax        # 10112 <_IO_stdin_used+0x112>
    522a:	48 8d 15 cc ae 00 00 	lea    0xaecc(%rip),%rdx        # 100fd <_IO_stdin_used+0xfd>
    5231:	48 0f 45 c2          	cmovne %rdx,%rax
    5235:	48 89 c7             	mov    %rax,%rdi
    5238:	e8 c3 ed ff ff       	call   4000 <ad_raw_fail>
    523d:	48 8d 3d 04 af 00 00 	lea    0xaf04(%rip),%rdi        # 10148 <_IO_stdin_used+0x148>
    5244:	e8 b7 ed ff ff       	call   4000 <ad_raw_fail>
    5249:	48 8d 3d dd ae 00 00 	lea    0xaedd(%rip),%rdi        # 1012d <_IO_stdin_used+0x12d>
    5250:	e8 ab ed ff ff       	call   4000 <ad_raw_fail>
    5255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    525c:	00 00 00 00 

0000000000005260 <fwp_tape_buffers_release>:
    5260:	f3 0f 1e fa          	endbr64
    5264:	53                   	push   %rbx
    5265:	48 89 fb             	mov    %rdi,%rbx
    5268:	48 83 ec 10          	sub    $0x10,%rsp
    526c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5270:	48 85 c0             	test   %rax,%rax
    5273:	0f 88 d7 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5279:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    527d:	48 85 d2             	test   %rdx,%rdx
    5280:	0f 88 ca 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5286:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    528c:	0f 87 be 00 00 00    	ja     5350 <fwp_tape_buffers_release+0xf0>
    5292:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5296:	b8 00 00 08 00       	mov    $0x80000,%eax
    529b:	48 c1 e1 03          	shl    $0x3,%rcx
    529f:	48 29 c8             	sub    %rcx,%rax
    52a2:	48 c1 e8 03          	shr    $0x3,%rax
    52a6:	48 39 d0             	cmp    %rdx,%rax
    52a9:	0f 82 a1 00 00 00    	jb     5350 <fwp_tape_buffers_release+0xf0>
    52af:	48 8d 3d aa ae 00 00 	lea    0xaeaa(%rip),%rdi        # 10160 <_IO_stdin_used+0x160>
    52b6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52bb:	48 89 14 24          	mov    %rdx,(%rsp)
    52bf:	e8 cc e0 ff ff       	call   3390 <getenv@plt>
    52c4:	48 8b 14 24          	mov    (%rsp),%rdx
    52c8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 09                	je     52db <fwp_tape_buffers_release+0x7b>
    52d2:	80 38 30             	cmpb   $0x30,(%rax)
    52d5:	0f 84 05 01 00 00    	je     53e0 <fwp_tape_buffers_release+0x180>
    52db:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52df:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52e3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52e9:	77 71                	ja     535c <fwp_tape_buffers_release+0xfc>
    52eb:	48 8d 3d ce ed 01 00 	lea    0x1edce(%rip),%rdi        # 240c0 <fwp_tape_workspace>
    52f2:	48 89 34 24          	mov    %rsi,(%rsp)
    52f6:	e8 45 fe ff ff       	call   5140 <fwp_tape_buffers_dispose>
    52fb:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52ff:	48 8b 34 24          	mov    (%rsp),%rsi
    5303:	0f 29 05 b6 ed 01 00 	movaps %xmm0,0x1edb6(%rip)        # 240c0 <fwp_tape_workspace>
    530a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    530f:	48 89 35 92 ed 01 00 	mov    %rsi,0x1ed92(%rip)        # 240a8 <fwp_tape_cached_bytes>
    5316:	0f 29 05 b3 ed 01 00 	movaps %xmm0,0x1edb3(%rip)        # 240d0 <fwp_tape_workspace+0x10>
    531d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5322:	0f 29 05 b7 ed 01 00 	movaps %xmm0,0x1edb7(%rip)        # 240e0 <fwp_tape_workspace+0x20>
    5329:	48 8b 43 30          	mov    0x30(%rbx),%rax
    532d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5331:	48 89 05 b8 ed 01 00 	mov    %rax,0x1edb8(%rip)        # 240f0 <fwp_tape_workspace+0x30>
    5338:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    533f:	00 
    5340:	0f 11 03             	movups %xmm0,(%rbx)
    5343:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5347:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    534b:	eb 1e                	jmp    536b <fwp_tape_buffers_release+0x10b>
    534d:	0f 1f 00             	nopl   (%rax)
    5350:	48 8d 3d 09 ae 00 00 	lea    0xae09(%rip),%rdi        # 10160 <_IO_stdin_used+0x160>
    5357:	e8 34 e0 ff ff       	call   3390 <getenv@plt>
    535c:	48 89 df             	mov    %rbx,%rdi
    535f:	e8 dc fd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    5364:	48 8b 35 3d ed 01 00 	mov    0x1ed3d(%rip),%rsi        # 240a8 <fwp_tape_cached_bytes>
    536b:	48 6b 15 8d ed 01 00 	imul   $0x68,0x1ed8d(%rip),%rdx        # 24100 <fwp_tapes_cap>
    5372:	68 
    5373:	48 3b 15 46 ee 04 00 	cmp    0x4ee46(%rip),%rdx        # 541c0 <ad_raw_live>
    537a:	75 73                	jne    53ef <fwp_tape_buffers_release+0x18f>
    537c:	48 8b 05 45 ee 04 00 	mov    0x4ee45(%rip),%rax        # 541c8 <ad_raw_live+0x8>
    5383:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5387:	48 01 d0             	add    %rdx,%rax
    538a:	48 03 05 3f ee 04 00 	add    0x4ee3f(%rip),%rax        # 541d0 <ad_raw_live+0x10>
    5391:	48 03 05 40 ee 04 00 	add    0x4ee40(%rip),%rax        # 541d8 <ad_raw_live+0x18>
    5398:	48 39 c8             	cmp    %rcx,%rax
    539b:	72 52                	jb     53ef <fwp_tape_buffers_release+0x18f>
    539d:	48 8b 0d 7c ed 01 00 	mov    0x1ed7c(%rip),%rcx        # 24120 <ad_raw_checkpoint_count>
    53a4:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    53ab:	74 4e                	je     53fb <fwp_tape_buffers_release+0x19b>
    53ad:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    53b1:	48 29 d0             	sub    %rdx,%rax
    53b4:	48 89 3d 65 ed 01 00 	mov    %rdi,0x1ed65(%rip)        # 24120 <ad_raw_checkpoint_count>
    53bb:	48 29 f0             	sub    %rsi,%rax
    53be:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53c2:	48 8d 0d 77 ed 01 00 	lea    0x1ed77(%rip),%rcx        # 24140 <ad_raw_checkpoints>
    53c9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53cd:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53d2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53d7:	48 83 c4 10          	add    $0x10,%rsp
    53db:	5b                   	pop    %rbx
    53dc:	c3                   	ret
    53dd:	0f 1f 00             	nopl   (%rax)
    53e0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53e4:	0f 84 72 ff ff ff    	je     535c <fwp_tape_buffers_release+0xfc>
    53ea:	e9 ec fe ff ff       	jmp    52db <fwp_tape_buffers_release+0x7b>
    53ef:	48 8d 3d 62 b5 00 00 	lea    0xb562(%rip),%rdi        # 10958 <_IO_stdin_used+0x958>
    53f6:	e8 05 ec ff ff       	call   4000 <ad_raw_fail>
    53fb:	48 8d 3d 6f ad 00 00 	lea    0xad6f(%rip),%rdi        # 10171 <_IO_stdin_used+0x171>
    5402:	e8 f9 eb ff ff       	call   4000 <ad_raw_fail>
    5407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    540e:	00 00 

0000000000005410 <fwp_poll_events>:
    5410:	53                   	push   %rbx
    5411:	48 83 ec 20          	sub    $0x20,%rsp
    5415:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    541c:	00 00 
    541e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5423:	31 c0                	xor    %eax,%eax
    5425:	e8 96 f1 ff ff       	call   45c0 <fwp_now_ns>
    542a:	48 8b 1d c7 73 06 00 	mov    0x673c7(%rip),%rbx        # 6c7f8 <fwp_timers>
    5431:	48 85 db             	test   %rbx,%rbx
    5434:	0f 84 e6 00 00 00    	je     5520 <fwp_poll_events+0x110>
    543a:	48 89 c6             	mov    %rax,%rsi
    543d:	48 89 da             	mov    %rbx,%rdx
    5440:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5447:	eb 26                	jmp    546f <fwp_poll_events+0x5f>
    5449:	90                   	nop
    544a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5451:	00 00 00 00 
    5455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    545c:	00 00 00 00 
    5460:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5467:	48 89 c8             	mov    %rcx,%rax
    546a:	48 85 d2             	test   %rdx,%rdx
    546d:	74 31                	je     54a0 <fwp_poll_events+0x90>
    546f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5473:	48 85 c0             	test   %rax,%rax
    5476:	78 e8                	js     5460 <fwp_poll_events+0x50>
    5478:	48 39 c1             	cmp    %rax,%rcx
    547b:	7c e3                	jl     5460 <fwp_poll_events+0x50>
    547d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 1c                	je     54a5 <fwp_poll_events+0x95>
    5489:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    548d:	48 39 c1             	cmp    %rax,%rcx
    5490:	7c ce                	jl     5460 <fwp_poll_events+0x50>
    5492:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5499:	48 85 d2             	test   %rdx,%rdx
    549c:	75 d1                	jne    546f <fwp_poll_events+0x5f>
    549e:	66 90                	xchg   %ax,%ax
    54a0:	48 85 c0             	test   %rax,%rax
    54a3:	78 7b                	js     5520 <fwp_poll_events+0x110>
    54a5:	48 29 f0             	sub    %rsi,%rax
    54a8:	48 89 c1             	mov    %rax,%rcx
    54ab:	48 85 c0             	test   %rax,%rax
    54ae:	0f 8e 9c 00 00 00    	jle    5550 <fwp_poll_events+0x140>
    54b4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    54bb:	de 1b 43 
    54be:	48 f7 ea             	imul   %rdx
    54c1:	48 89 c8             	mov    %rcx,%rax
    54c4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54c8:	48 c1 fa 12          	sar    $0x12,%rdx
    54cc:	48 29 c2             	sub    %rax,%rdx
    54cf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54d6:	48 39 c1             	cmp    %rax,%rcx
    54d9:	0f 95 c0             	setne  %al
    54dc:	0f b6 c0             	movzbl %al,%eax
    54df:	48 01 d0             	add    %rdx,%rax
    54e2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54e8:	0f 8f 32 01 00 00    	jg     5620 <fwp_poll_events+0x210>
    54ee:	48 85 c0             	test   %rax,%rax
    54f1:	74 5d                	je     5550 <fwp_poll_events+0x140>
    54f3:	89 c1                	mov    %eax,%ecx
    54f5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54fc:	48 c1 e9 26          	shr    $0x26,%rcx
    5500:	48 63 d1             	movslq %ecx,%rdx
    5503:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5509:	29 c8                	sub    %ecx,%eax
    550b:	48 98                	cltq
    550d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5514:	e9 11 01 00 00       	jmp    562a <fwp_poll_events+0x21a>
    5519:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5520:	e8 db e7 ff ff       	call   3d00 <fwp_flush>
    5525:	ba 2b 00 00 00       	mov    $0x2b,%edx
    552a:	be 01 00 00 00       	mov    $0x1,%esi
    552f:	48 8b 0d 2a eb 00 00 	mov    0xeb2a(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    5536:	48 8d 3d 4b b4 00 00 	lea    0xb44b(%rip),%rdi        # 10988 <_IO_stdin_used+0x988>
    553d:	e8 1e e1 ff ff       	call   3660 <fwrite@plt>
    5542:	bf 65 00 00 00       	mov    $0x65,%edi
    5547:	e8 04 e1 ff ff       	call   3650 <exit@plt>
    554c:	0f 1f 40 00          	nopl   0x0(%rax)
    5550:	e8 6b f0 ff ff       	call   45c0 <fwp_now_ns>
    5555:	48 89 c1             	mov    %rax,%rcx
    5558:	66 0f ef c0          	pxor   %xmm0,%xmm0
    555c:	eb 44                	jmp    55a2 <fwp_poll_events+0x192>
    555e:	66 90                	xchg   %ax,%ax
    5560:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5564:	75 33                	jne    5599 <fwp_poll_events+0x189>
    5566:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    556a:	75 2d                	jne    5599 <fwp_poll_events+0x189>
    556c:	48 8b 05 8d 72 06 00 	mov    0x6728d(%rip),%rax        # 6c800 <fwp_ready_tail>
    5573:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5577:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    557e:	00 00 00 00 
    5582:	48 85 c0             	test   %rax,%rax
    5585:	0f 84 05 01 00 00    	je     5690 <fwp_poll_events+0x280>
    558b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5592:	48 89 15 67 72 06 00 	mov    %rdx,0x67267(%rip)        # 6c800 <fwp_ready_tail>
    5599:	48 85 db             	test   %rbx,%rbx
    559c:	0f 84 be 00 00 00    	je     5660 <fwp_poll_events+0x250>
    55a2:	48 89 da             	mov    %rbx,%rdx
    55a5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    55ac:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    55b0:	7f e7                	jg     5599 <fwp_poll_events+0x189>
    55b2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    55b6:	74 2e                	je     55e6 <fwp_poll_events+0x1d6>
    55b8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    55bf:	48 85 c0             	test   %rax,%rax
    55c2:	0f 84 b8 00 00 00    	je     5680 <fwp_poll_events+0x270>
    55c8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55cf:	48 85 db             	test   %rbx,%rbx
    55d2:	74 07                	je     55db <fwp_poll_events+0x1cb>
    55d4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55db:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55df:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55e6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ea:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ee:	48 85 c0             	test   %rax,%rax
    55f1:	0f 84 69 ff ff ff    	je     5560 <fwp_poll_events+0x150>
    55f7:	48 39 c8             	cmp    %rcx,%rax
    55fa:	0f 8f 60 ff ff ff    	jg     5560 <fwp_poll_events+0x150>
    5600:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5604:	0f 85 56 ff ff ff    	jne    5560 <fwp_poll_events+0x150>
    560a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    560e:	75 89                	jne    5599 <fwp_poll_events+0x189>
    5610:	48 89 d7             	mov    %rdx,%rdi
    5613:	e8 18 eb ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5618:	e9 43 ff ff ff       	jmp    5560 <fwp_poll_events+0x150>
    561d:	0f 1f 00             	nopl   (%rax)
    5620:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5625:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    562a:	48 89 e7             	mov    %rsp,%rdi
    562d:	31 f6                	xor    %esi,%esi
    562f:	48 89 14 24          	mov    %rdx,(%rsp)
    5633:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5638:	e8 53 de ff ff       	call   3490 <nanosleep@plt>
    563d:	48 8b 1d b4 71 06 00 	mov    0x671b4(%rip),%rbx        # 6c7f8 <fwp_timers>
    5644:	e8 77 ef ff ff       	call   45c0 <fwp_now_ns>
    5649:	48 89 c1             	mov    %rax,%rcx
    564c:	48 85 db             	test   %rbx,%rbx
    564f:	0f 85 03 ff ff ff    	jne    5558 <fwp_poll_events+0x148>
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5665:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    566c:	00 00 
    566e:	75 2c                	jne    569c <fwp_poll_events+0x28c>
    5670:	48 83 c4 20          	add    $0x20,%rsp
    5674:	5b                   	pop    %rbx
    5675:	c3                   	ret
    5676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    567d:	00 00 00 
    5680:	48 89 1d 71 71 06 00 	mov    %rbx,0x67171(%rip)        # 6c7f8 <fwp_timers>
    5687:	e9 43 ff ff ff       	jmp    55cf <fwp_poll_events+0x1bf>
    568c:	0f 1f 40 00          	nopl   0x0(%rax)
    5690:	48 89 15 71 71 06 00 	mov    %rdx,0x67171(%rip)        # 6c808 <fwp_ready_head>
    5697:	e9 f6 fe ff ff       	jmp    5592 <fwp_poll_events+0x182>
    569c:	e8 af dd ff ff       	call   3450 <__stack_chk_fail@plt>
    56a1:	0f 1f 40 00          	nopl   0x0(%rax)
    56a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ac:	00 00 00 00 

00000000000056b0 <fwp_rc_wide_dup>:
    56b0:	48 89 fa             	mov    %rdi,%rdx
    56b3:	48 8d 35 86 71 06 00 	lea    0x67186(%rip),%rsi        # 6c840 <fwp_heap>
    56ba:	48 83 ec 18          	sub    $0x18,%rsp
    56be:	48 89 f9             	mov    %rdi,%rcx
    56c1:	48 c1 ea 11          	shr    $0x11,%rdx
    56c5:	48 31 fa             	xor    %rdi,%rdx
    56c8:	48 89 d0             	mov    %rdx,%rax
    56cb:	48 c1 e8 09          	shr    $0x9,%rax
    56cf:	48 31 c2             	xor    %rax,%rdx
    56d2:	0f b6 d2             	movzbl %dl,%edx
    56d5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56dc:	00 
    56dd:	49 8b 00             	mov    (%r8),%rax
    56e0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56e7:	00 00 
    56e9:	75 21                	jne    570c <fwp_rc_wide_dup+0x5c>
    56eb:	e9 98 00 00 00       	jmp    5788 <fwp_rc_wide_dup+0xd8>
    56f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56fc:	00 00 00 00 
    5700:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5704:	48 85 d2             	test   %rdx,%rdx
    5707:	74 2f                	je     5738 <fwp_rc_wide_dup+0x88>
    5709:	48 89 d0             	mov    %rdx,%rax
    570c:	48 3b 08             	cmp    (%rax),%rcx
    570f:	75 ef                	jne    5700 <fwp_rc_wide_dup+0x50>
    5711:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5714:	74 7c                	je     5792 <fwp_rc_wide_dup+0xe2>
    5716:	48 8b 50 08          	mov    0x8(%rax),%rdx
    571a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    571e:	0f 84 91 00 00 00    	je     57b5 <fwp_rc_wide_dup+0x105>
    5724:	48 83 c2 01          	add    $0x1,%rdx
    5728:	48 89 50 08          	mov    %rdx,0x8(%rax)
    572c:	48 83 c4 18          	add    $0x18,%rsp
    5730:	c3                   	ret
    5731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5738:	4c 8d 40 10          	lea    0x10(%rax),%r8
    573c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    573f:	75 68                	jne    57a9 <fwp_rc_wide_dup+0xf9>
    5741:	bf 18 00 00 00       	mov    $0x18,%edi
    5746:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    574b:	4c 89 04 24          	mov    %r8,(%rsp)
    574f:	e8 3c de ff ff       	call   3590 <malloc@plt>
    5754:	4c 8b 04 24          	mov    (%rsp),%r8
    5758:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    575d:	48 85 c0             	test   %rax,%rax
    5760:	74 5f                	je     57c1 <fwp_rc_wide_dup+0x111>
    5762:	48 89 08             	mov    %rcx,(%rax)
    5765:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    576c:	00 
    576d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5774:	00 
    5775:	49 89 00             	mov    %rax,(%r8)
    5778:	c6 01 ff             	movb   $0xff,(%rcx)
    577b:	48 83 05 05 8d 06 00 	addq   $0x1,0x68d05(%rip)        # 6e488 <fwp_heap+0x1c48>
    5782:	01 
    5783:	48 83 c4 18          	add    $0x18,%rsp
    5787:	c3                   	ret
    5788:	80 3f fe             	cmpb   $0xfe,(%rdi)
    578b:	75 13                	jne    57a0 <fwp_rc_wide_dup+0xf0>
    578d:	48 85 c0             	test   %rax,%rax
    5790:	74 af                	je     5741 <fwp_rc_wide_dup+0x91>
    5792:	48 8d 3d 1f b2 00 00 	lea    0xb21f(%rip),%rdi        # 109b8 <_IO_stdin_used+0x9b8>
    5799:	e8 b2 ec ff ff       	call   4450 <fwp_trap>
    579e:	66 90                	xchg   %ax,%ax
    57a0:	48 85 c0             	test   %rax,%rax
    57a3:	0f 85 6d ff ff ff    	jne    5716 <fwp_rc_wide_dup+0x66>
    57a9:	48 8d 3d 30 b2 00 00 	lea    0xb230(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    57b0:	e8 9b ec ff ff       	call   4450 <fwp_trap>
    57b5:	48 8d 3d d2 a9 00 00 	lea    0xa9d2(%rip),%rdi        # 1018e <_IO_stdin_used+0x18e>
    57bc:	e8 8f ec ff ff       	call   4450 <fwp_trap>
    57c1:	e8 6a e6 ff ff       	call   3e30 <fwp_heap_oom>
    57c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57cd:	00 00 00 

00000000000057d0 <fwp_rc_forget_slot>:
    57d0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57d3:	74 0b                	je     57e0 <fwp_rc_forget_slot+0x10>
    57d5:	c3                   	ret
    57d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57dd:	00 00 00 
    57e0:	48 89 f8             	mov    %rdi,%rax
    57e3:	48 83 ec 08          	sub    $0x8,%rsp
    57e7:	48 89 fa             	mov    %rdi,%rdx
    57ea:	48 c1 e8 11          	shr    $0x11,%rax
    57ee:	48 31 f8             	xor    %rdi,%rax
    57f1:	48 89 c1             	mov    %rax,%rcx
    57f4:	48 c1 e9 09          	shr    $0x9,%rcx
    57f8:	48 31 c8             	xor    %rcx,%rax
    57fb:	48 8d 0d 3e 70 06 00 	lea    0x6703e(%rip),%rcx        # 6c840 <fwp_heap>
    5802:	0f b6 c0             	movzbl %al,%eax
    5805:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    580c:	00 
    580d:	48 85 ff             	test   %rdi,%rdi
    5810:	74 3c                	je     584e <fwp_rc_forget_slot+0x7e>
    5812:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5819:	00 
    581a:	48 8b 01             	mov    (%rcx),%rax
    581d:	eb 11                	jmp    5830 <fwp_rc_forget_slot+0x60>
    581f:	90                   	nop
    5820:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5824:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5828:	48 85 ff             	test   %rdi,%rdi
    582b:	74 21                	je     584e <fwp_rc_forget_slot+0x7e>
    582d:	48 89 f8             	mov    %rdi,%rax
    5830:	48 3b 10             	cmp    (%rax),%rdx
    5833:	75 eb                	jne    5820 <fwp_rc_forget_slot+0x50>
    5835:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5839:	48 89 01             	mov    %rax,(%rcx)
    583c:	e8 6f db ff ff       	call   33b0 <free@plt>
    5841:	48 83 2d 3f 8c 06 00 	subq   $0x1,0x68c3f(%rip)        # 6e488 <fwp_heap+0x1c48>
    5848:	01 
    5849:	48 83 c4 08          	add    $0x8,%rsp
    584d:	c3                   	ret
    584e:	48 8d 3d 8b b1 00 00 	lea    0xb18b(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    5855:	e8 f6 eb ff ff       	call   4450 <fwp_trap>
    585a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005860 <fwp_rc_prepare_chunk>:
    5860:	48 83 3d 20 8c 06 00 	cmpq   $0x0,0x68c20(%rip)        # 6e488 <fwp_heap+0x1c48>
    5867:	00 
    5868:	41 54                	push   %r12
    586a:	49 89 f4             	mov    %rsi,%r12
    586d:	55                   	push   %rbp
    586e:	48 89 fd             	mov    %rdi,%rbp
    5871:	53                   	push   %rbx
    5872:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5875:	0f 84 7d 00 00 00    	je     58f8 <fwp_rc_prepare_chunk+0x98>
    587b:	31 db                	xor    %ebx,%ebx
    587d:	85 c0                	test   %eax,%eax
    587f:	75 5f                	jne    58e0 <fwp_rc_prepare_chunk+0x80>
    5881:	48 85 f6             	test   %rsi,%rsi
    5884:	74 7c                	je     5902 <fwp_rc_prepare_chunk+0xa2>
    5886:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    588a:	e8 21 db ff ff       	call   33b0 <free@plt>
    588f:	90                   	nop
    5890:	be 01 00 00 00       	mov    $0x1,%esi
    5895:	4c 89 e7             	mov    %r12,%rdi
    5898:	e8 73 dc ff ff       	call   3510 <calloc@plt>
    589d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    58a1:	48 85 c0             	test   %rax,%rax
    58a4:	0f 85 87 00 00 00    	jne    5931 <fwp_rc_prepare_chunk+0xd1>
    58aa:	e8 81 e5 ff ff       	call   3e30 <fwp_heap_oom>
    58af:	90                   	nop
    58b0:	e8 1b ff ff ff       	call   57d0 <fwp_rc_forget_slot>
    58b5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58b8:	48 83 c3 01          	add    $0x1,%rbx
    58bc:	48 39 c3             	cmp    %rax,%rbx
    58bf:	73 37                	jae    58f8 <fwp_rc_prepare_chunk+0x98>
    58c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58c8:	00 00 
    58ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58d1:	00 00 00 00 
    58d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58dc:	00 00 00 00 
    58e0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58e4:	48 01 df             	add    %rbx,%rdi
    58e7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ea:	74 c4                	je     58b0 <fwp_rc_prepare_chunk+0x50>
    58ec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58ef:	48 83 c3 01          	add    $0x1,%rbx
    58f3:	48 39 c3             	cmp    %rax,%rbx
    58f6:	72 e8                	jb     58e0 <fwp_rc_prepare_chunk+0x80>
    58f8:	49 39 c4             	cmp    %rax,%r12
    58fb:	75 13                	jne    5910 <fwp_rc_prepare_chunk+0xb0>
    58fd:	4d 85 e4             	test   %r12,%r12
    5900:	75 46                	jne    5948 <fwp_rc_prepare_chunk+0xe8>
    5902:	5b                   	pop    %rbx
    5903:	5d                   	pop    %rbp
    5904:	41 5c                	pop    %r12
    5906:	c3                   	ret
    5907:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    590e:	00 00 
    5910:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5914:	48 29 05 75 8b 06 00 	sub    %rax,0x68b75(%rip)        # 6e490 <fwp_heap+0x1c50>
    591b:	e8 90 da ff ff       	call   33b0 <free@plt>
    5920:	4d 85 e4             	test   %r12,%r12
    5923:	0f 85 67 ff ff ff    	jne    5890 <fwp_rc_prepare_chunk+0x30>
    5929:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5930:	00 
    5931:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5935:	5b                   	pop    %rbx
    5936:	4c 01 25 53 8b 06 00 	add    %r12,0x68b53(%rip)        # 6e490 <fwp_heap+0x1c50>
    593d:	5d                   	pop    %rbp
    593e:	41 5c                	pop    %r12
    5940:	c3                   	ret
    5941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5948:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    594c:	5b                   	pop    %rbx
    594d:	4c 89 e2             	mov    %r12,%rdx
    5950:	31 f6                	xor    %esi,%esi
    5952:	5d                   	pop    %rbp
    5953:	41 5c                	pop    %r12
    5955:	e9 56 db ff ff       	jmp    34b0 <memset@plt>
    595a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005960 <fwp_heap_refill>:
    5960:	41 56                	push   %r14
    5962:	41 89 d6             	mov    %edx,%r14d
    5965:	41 55                	push   %r13
    5967:	41 89 f5             	mov    %esi,%r13d
    596a:	41 54                	push   %r12
    596c:	49 89 fc             	mov    %rdi,%r12
    596f:	bf 01 00 00 00       	mov    $0x1,%edi
    5974:	55                   	push   %rbp
    5975:	53                   	push   %rbx
    5976:	e8 f5 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    597b:	48 89 c3             	mov    %rax,%rbx
    597e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5982:	48 8b 05 af 82 06 00 	mov    0x682af(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    5989:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    598d:	48 8d 05 ac 6e 06 00 	lea    0x66eac(%rip),%rax        # 6c840 <fwp_heap>
    5994:	31 d2                	xor    %edx,%edx
    5996:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    599a:	48 89 ef             	mov    %rbp,%rdi
    599d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    59a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    59a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    59ac:	00 
    59ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    59b2:	f7 f1                	div    %ecx
    59b4:	31 d2                	xor    %edx,%edx
    59b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    59ba:	66 0f 6e c8          	movd   %eax,%xmm1
    59be:	89 c6                	mov    %eax,%esi
    59c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59c5:	48 01 c8             	add    %rcx,%rax
    59c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59cc:	48 f7 f1             	div    %rcx
    59cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59d4:	89 45 18             	mov    %eax,0x18(%rbp)
    59d7:	e8 84 fe ff ff       	call   5860 <fwp_rc_prepare_chunk>
    59dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59df:	48 89 d8             	mov    %rbx,%rax
    59e2:	48 c1 e0 10          	shl    $0x10,%rax
    59e6:	48 03 05 03 82 06 00 	add    0x68203(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    59ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59f6:	8b 55 08             	mov    0x8(%rbp),%edx
    59f9:	48 0f af d1          	imul   %rcx,%rdx
    59fd:	48 01 c2             	add    %rax,%rdx
    5a00:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a05:	5b                   	pop    %rbx
    5a06:	5d                   	pop    %rbp
    5a07:	41 5c                	pop    %r12
    5a09:	41 5d                	pop    %r13
    5a0b:	41 5e                	pop    %r14
    5a0d:	c3                   	ret
    5a0e:	66 90                	xchg   %ax,%ax

0000000000005a10 <fwp_mem_free>:
    5a10:	48 85 ff             	test   %rdi,%rdi
    5a13:	0f 84 17 02 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a19:	48 8b 35 d0 81 06 00 	mov    0x681d0(%rip),%rsi        # 6dbf0 <fwp_heap+0x13b0>
    5a20:	48 8b 05 f1 81 06 00 	mov    0x681f1(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    5a27:	48 89 fa             	mov    %rdi,%rdx
    5a2a:	48 29 f2             	sub    %rsi,%rdx
    5a2d:	48 c1 e0 10          	shl    $0x10,%rax
    5a31:	48 39 c2             	cmp    %rax,%rdx
    5a34:	0f 83 f6 01 00 00    	jae    5c30 <fwp_mem_free+0x220>
    5a3a:	49 89 d1             	mov    %rdx,%r9
    5a3d:	49 c1 e9 10          	shr    $0x10,%r9
    5a41:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a45:	48 c1 e0 03          	shl    $0x3,%rax
    5a49:	49 89 c0             	mov    %rax,%r8
    5a4c:	4c 03 05 e5 81 06 00 	add    0x681e5(%rip),%r8        # 6dc38 <fwp_heap+0x13f8>
    5a53:	0f 84 d7 01 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a59:	48 83 ec 38          	sub    $0x38,%rsp
    5a5d:	48 89 f9             	mov    %rdi,%rcx
    5a60:	41 0f b6 38          	movzbl (%r8),%edi
    5a64:	40 80 ff 01          	cmp    $0x1,%dil
    5a68:	74 16                	je     5a80 <fwp_mem_free+0x70>
    5a6a:	40 80 ff 02          	cmp    $0x2,%dil
    5a6e:	0f 84 94 00 00 00    	je     5b08 <fwp_mem_free+0xf8>
    5a74:	48 83 c4 38          	add    $0x38,%rsp
    5a78:	c3                   	ret
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a84:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a89:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a8e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a92:	4d 85 d2             	test   %r10,%r10
    5a95:	74 1d                	je     5ab4 <fwp_mem_free+0xa4>
    5a97:	0f b7 c1             	movzwl %cx,%eax
    5a9a:	31 d2                	xor    %edx,%edx
    5a9c:	48 f7 f7             	div    %rdi
    5a9f:	49 01 c2             	add    %rax,%r10
    5aa2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5aa6:	0f 84 44 01 00 00    	je     5bf0 <fwp_mem_free+0x1e0>
    5aac:	41 c6 02 00          	movb   $0x0,(%r10)
    5ab0:	41 8b 78 04          	mov    0x4(%r8),%edi
    5ab4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5abb:	49 63 c1             	movslq %r9d,%rax
    5abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ac2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ac6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5acb:	f2 0f 58 05 ad 81 06 	addsd  0x681ad(%rip),%xmm0        # 6dc80 <fwp_heap+0x1440>
    5ad2:	00 
    5ad3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ad7:	48 8d 05 62 6d 06 00 	lea    0x66d62(%rip),%rax        # 6c840 <fwp_heap>
    5ade:	48 01 d0             	add    %rdx,%rax
    5ae1:	48 8b 10             	mov    (%rax),%rdx
    5ae4:	48 f7 d2             	not    %rdx
    5ae7:	48 89 11             	mov    %rdx,(%rcx)
    5aea:	48 89 08             	mov    %rcx,(%rax)
    5aed:	48 29 3d 6c 81 06 00 	sub    %rdi,0x6816c(%rip)        # 6dc60 <fwp_heap+0x1420>
    5af4:	f2 0f 11 05 84 81 06 	movsd  %xmm0,0x68184(%rip)        # 6dc80 <fwp_heap+0x1440>
    5afb:	00 
    5afc:	48 83 c4 38          	add    $0x38,%rsp
    5b00:	c3                   	ret
    5b01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b08:	66 31 d2             	xor    %dx,%dx
    5b0b:	48 01 d6             	add    %rdx,%rsi
    5b0e:	48 39 f1             	cmp    %rsi,%rcx
    5b11:	0f 85 5d ff ff ff    	jne    5a74 <fwp_mem_free+0x64>
    5b17:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b1b:	48 29 15 3e 81 06 00 	sub    %rdx,0x6813e(%rip)        # 6dc60 <fwp_heap+0x1420>
    5b22:	48 85 d2             	test   %rdx,%rdx
    5b25:	0f 88 a5 00 00 00    	js     5bd0 <fwp_mem_free+0x1c0>
    5b2b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b2f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b34:	f2 0f 58 05 44 81 06 	addsd  0x68144(%rip),%xmm0        # 6dc80 <fwp_heap+0x1440>
    5b3b:	00 
    5b3c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b40:	f2 0f 11 05 38 81 06 	movsd  %xmm0,0x68138(%rip)        # 6dc80 <fwp_heap+0x1440>
    5b47:	00 
    5b48:	48 85 d2             	test   %rdx,%rdx
    5b4b:	74 0c                	je     5b59 <fwp_mem_free+0x149>
    5b4d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b50:	0f 84 db 00 00 00    	je     5c31 <fwp_mem_free+0x221>
    5b56:	c6 02 00             	movb   $0x0,(%rdx)
    5b59:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b5d:	48 85 c9             	test   %rcx,%rcx
    5b60:	74 3e                	je     5ba0 <fwp_mem_free+0x190>
    5b62:	48 8b 15 cf 80 06 00 	mov    0x680cf(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    5b69:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b6d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b71:	48 01 d0             	add    %rdx,%rax
    5b74:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b78:	48 89 d6             	mov    %rdx,%rsi
    5b7b:	48 29 c6             	sub    %rax,%rsi
    5b7e:	83 e6 08             	and    $0x8,%esi
    5b81:	74 0d                	je     5b90 <fwp_mem_free+0x180>
    5b83:	c6 00 00             	movb   $0x0,(%rax)
    5b86:	48 83 c0 28          	add    $0x28,%rax
    5b8a:	48 39 c2             	cmp    %rax,%rdx
    5b8d:	74 11                	je     5ba0 <fwp_mem_free+0x190>
    5b8f:	90                   	nop
    5b90:	c6 00 00             	movb   $0x0,(%rax)
    5b93:	48 83 c0 50          	add    $0x50,%rax
    5b97:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b9b:	48 39 c2             	cmp    %rax,%rdx
    5b9e:	75 f0                	jne    5b90 <fwp_mem_free+0x180>
    5ba0:	48 01 0d c9 80 06 00 	add    %rcx,0x680c9(%rip)        # 6dc70 <fwp_heap+0x1430>
    5ba7:	4c 3b 0d 82 80 06 00 	cmp    0x68082(%rip),%r9        # 6dc30 <fwp_heap+0x13f0>
    5bae:	73 07                	jae    5bb7 <fwp_mem_free+0x1a7>
    5bb0:	4c 89 0d 79 80 06 00 	mov    %r9,0x68079(%rip)        # 6dc30 <fwp_heap+0x13f0>
    5bb7:	4c 3b 0d 6a 80 06 00 	cmp    0x6806a(%rip),%r9        # 6dc28 <fwp_heap+0x13e8>
    5bbe:	0f 83 b0 fe ff ff    	jae    5a74 <fwp_mem_free+0x64>
    5bc4:	4c 89 0d 5d 80 06 00 	mov    %r9,0x6805d(%rip)        # 6dc28 <fwp_heap+0x13e8>
    5bcb:	e9 a4 fe ff ff       	jmp    5a74 <fwp_mem_free+0x64>
    5bd0:	48 89 d1             	mov    %rdx,%rcx
    5bd3:	83 e2 01             	and    $0x1,%edx
    5bd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bda:	48 d1 e9             	shr    $1,%rcx
    5bdd:	48 09 d1             	or     %rdx,%rcx
    5be0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5be5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5be9:	e9 46 ff ff ff       	jmp    5b34 <fwp_mem_free+0x124>
    5bee:	66 90                	xchg   %ax,%ax
    5bf0:	4c 89 d7             	mov    %r10,%rdi
    5bf3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bf8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bfd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c02:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c06:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c0b:	e8 c0 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c10:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c15:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c1a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c1f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c24:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c29:	e9 7e fe ff ff       	jmp    5aac <fwp_mem_free+0x9c>
    5c2e:	66 90                	xchg   %ax,%ax
    5c30:	c3                   	ret
    5c31:	48 89 d7             	mov    %rdx,%rdi
    5c34:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c39:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c3e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c48:	e8 83 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c4d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c52:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c57:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c5c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c61:	e9 f0 fe ff ff       	jmp    5b56 <fwp_mem_free+0x146>
    5c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c6d:	00 00 00 

0000000000005c70 <fwp_heap_alloc_big>:
    5c70:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c77:	00 00 40 
    5c7a:	41 57                	push   %r15
    5c7c:	41 56                	push   %r14
    5c7e:	41 55                	push   %r13
    5c80:	41 54                	push   %r12
    5c82:	55                   	push   %rbp
    5c83:	53                   	push   %rbx
    5c84:	48 83 ec 08          	sub    $0x8,%rsp
    5c88:	48 39 f8             	cmp    %rdi,%rax
    5c8b:	0f 82 fa 00 00 00    	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5c91:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c98:	49 89 fd             	mov    %rdi,%r13
    5c9b:	41 89 f6             	mov    %esi,%r14d
    5c9e:	48 c1 ed 10          	shr    $0x10,%rbp
    5ca2:	48 89 ef             	mov    %rbp,%rdi
    5ca5:	e8 c6 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5caa:	be 01 00 00 00       	mov    $0x1,%esi
    5caf:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5cb3:	49 89 c4             	mov    %rax,%r12
    5cb6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5cbd:	00 
    5cbe:	48 03 3d 73 7f 06 00 	add    0x67f73(%rip),%rdi        # 6dc38 <fwp_heap+0x13f8>
    5cc5:	c6 07 02             	movb   $0x2,(%rdi)
    5cc8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5ccc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5ccf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cd3:	e8 88 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5cd8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cdc:	76 47                	jbe    5d25 <fwp_heap_alloc_big+0xb5>
    5cde:	4c 01 e5             	add    %r12,%rbp
    5ce1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ce8:	00 
    5ce9:	4c 8d 3d 50 6b 06 00 	lea    0x66b50(%rip),%r15        # 6c840 <fwp_heap>
    5cf0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cf5:	49 c1 e6 03          	shl    $0x3,%r14
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d00:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d07:	31 f6                	xor    %esi,%esi
    5d09:	48 01 dd             	add    %rbx,%rbp
    5d0c:	48 83 c3 28          	add    $0x28,%rbx
    5d10:	48 89 ef             	mov    %rbp,%rdi
    5d13:	e8 48 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5d18:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d1c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d20:	49 39 de             	cmp    %rbx,%r14
    5d23:	75 db                	jne    5d00 <fwp_heap_alloc_big+0x90>
    5d25:	49 c1 e4 10          	shl    $0x10,%r12
    5d29:	4c 03 25 c0 7e 06 00 	add    0x67ec0(%rip),%r12        # 6dbf0 <fwp_heap+0x13b0>
    5d30:	4c 89 ea             	mov    %r13,%rdx
    5d33:	31 f6                	xor    %esi,%esi
    5d35:	4c 89 e7             	mov    %r12,%rdi
    5d38:	e8 73 d7 ff ff       	call   34b0 <memset@plt>
    5d3d:	4c 89 e8             	mov    %r13,%rax
    5d40:	48 03 05 19 7f 06 00 	add    0x67f19(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    5d47:	72 42                	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5d49:	48 39 05 18 7f 06 00 	cmp    %rax,0x67f18(%rip)        # 6dc68 <fwp_heap+0x1428>
    5d50:	48 89 05 09 7f 06 00 	mov    %rax,0x67f09(%rip)        # 6dc60 <fwp_heap+0x1420>
    5d57:	73 07                	jae    5d60 <fwp_heap_alloc_big+0xf0>
    5d59:	48 89 05 08 7f 06 00 	mov    %rax,0x67f08(%rip)        # 6dc68 <fwp_heap+0x1428>
    5d60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d64:	4c 89 e0             	mov    %r12,%rax
    5d67:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d6c:	f2 0f 58 05 04 7f 06 	addsd  0x67f04(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    5d73:	00 
    5d74:	f2 0f 11 05 fc 7e 06 	movsd  %xmm0,0x67efc(%rip)        # 6dc78 <fwp_heap+0x1438>
    5d7b:	00 
    5d7c:	48 83 c4 08          	add    $0x8,%rsp
    5d80:	5b                   	pop    %rbx
    5d81:	5d                   	pop    %rbp
    5d82:	41 5c                	pop    %r12
    5d84:	41 5d                	pop    %r13
    5d86:	41 5e                	pop    %r14
    5d88:	41 5f                	pop    %r15
    5d8a:	c3                   	ret
    5d8b:	e8 a0 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005d90 <fwp_heap_alloc_slow>:
    5d90:	53                   	push   %rbx
    5d91:	48 89 f9             	mov    %rdi,%rcx
    5d94:	41 89 f1             	mov    %esi,%r9d
    5d97:	48 83 ec 10          	sub    $0x10,%rsp
    5d9b:	8b 05 43 7e 06 00    	mov    0x67e43(%rip),%eax        # 6dbe4 <fwp_heap+0x13a4>
    5da1:	85 c0                	test   %eax,%eax
    5da3:	0f 84 c7 00 00 00    	je     5e70 <fwp_heap_alloc_slow+0xe0>
    5da9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5db0:	0f 87 dd 00 00 00    	ja     5e93 <fwp_heap_alloc_slow+0x103>
    5db6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5dba:	48 8d 3d 7f 6a 06 00 	lea    0x66a7f(%rip),%rdi        # 6c840 <fwp_heap>
    5dc1:	49 63 f1             	movslq %r9d,%rsi
    5dc4:	48 c1 e8 04          	shr    $0x4,%rax
    5dc8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5dcf:	00 00 
    5dd1:	41 0f b6 c2          	movzbl %r10b,%eax
    5dd5:	4c 89 d2             	mov    %r10,%rdx
    5dd8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5ddc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5de3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dee:	48 01 f8             	add    %rdi,%rax
    5df1:	4c 8b 00             	mov    (%rax),%r8
    5df4:	4d 85 c0             	test   %r8,%r8
    5df7:	0f 84 ab 00 00 00    	je     5ea8 <fwp_heap_alloc_slow+0x118>
    5dfd:	49 8b 10             	mov    (%r8),%rdx
    5e00:	48 f7 d2             	not    %rdx
    5e03:	48 89 10             	mov    %rdx,(%rax)
    5e06:	41 83 f9 01          	cmp    $0x1,%r9d
    5e0a:	4c 89 c7             	mov    %r8,%rdi
    5e0d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e11:	31 f6                	xor    %esi,%esi
    5e13:	48 89 ca             	mov    %rcx,%rdx
    5e16:	e8 95 d6 ff ff       	call   34b0 <memset@plt>
    5e1b:	49 89 c0             	mov    %rax,%r8
    5e1e:	48 89 d8             	mov    %rbx,%rax
    5e21:	48 03 05 38 7e 06 00 	add    0x67e38(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    5e28:	0f 82 d9 00 00 00    	jb     5f07 <fwp_heap_alloc_slow+0x177>
    5e2e:	48 39 05 33 7e 06 00 	cmp    %rax,0x67e33(%rip)        # 6dc68 <fwp_heap+0x1428>
    5e35:	48 89 05 24 7e 06 00 	mov    %rax,0x67e24(%rip)        # 6dc60 <fwp_heap+0x1420>
    5e3c:	73 07                	jae    5e45 <fwp_heap_alloc_slow+0xb5>
    5e3e:	48 89 05 23 7e 06 00 	mov    %rax,0x67e23(%rip)        # 6dc68 <fwp_heap+0x1428>
    5e45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e49:	4c 89 c0             	mov    %r8,%rax
    5e4c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e51:	f2 0f 58 05 1f 7e 06 	addsd  0x67e1f(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 17 7e 06 	movsd  %xmm0,0x67e17(%rip)        # 6dc78 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	48 83 c4 10          	add    $0x10,%rsp
    5e65:	5b                   	pop    %rbx
    5e66:	c3                   	ret
    5e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e6e:	00 00 
    5e70:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e74:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e78:	e8 53 ef ff ff       	call   4dd0 <fwp_heap_init>
    5e7d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e81:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e86:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e8d:	0f 86 23 ff ff ff    	jbe    5db6 <fwp_heap_alloc_slow+0x26>
    5e93:	48 83 c4 10          	add    $0x10,%rsp
    5e97:	44 89 ce             	mov    %r9d,%esi
    5e9a:	48 89 cf             	mov    %rcx,%rdi
    5e9d:	5b                   	pop    %rbx
    5e9e:	e9 cd fd ff ff       	jmp    5c70 <fwp_heap_alloc_big>
    5ea3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ea8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5eac:	4d 85 c0             	test   %r8,%r8
    5eaf:	74 1f                	je     5ed0 <fwp_heap_alloc_slow+0x140>
    5eb1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5eb5:	4d 29 c3             	sub    %r8,%r11
    5eb8:	49 39 db             	cmp    %rbx,%r11
    5ebb:	72 13                	jb     5ed0 <fwp_heap_alloc_slow+0x140>
    5ebd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ec1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ec5:	e9 3c ff ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ed0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5ed7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5edb:	44 89 ca             	mov    %r9d,%edx
    5ede:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ee3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ee7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5eeb:	44 89 d6             	mov    %r10d,%esi
    5eee:	48 01 c7             	add    %rax,%rdi
    5ef1:	e8 6a fa ff ff       	call   5960 <fwp_heap_refill>
    5ef6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5efb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5eff:	49 89 c0             	mov    %rax,%r8
    5f02:	e9 ff fe ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5f07:	e8 24 df ff ff       	call   3e30 <fwp_heap_oom>
    5f0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f10 <fwp_heap_alloc>:
    5f10:	53                   	push   %rbx
    5f11:	48 89 fa             	mov    %rdi,%rdx
    5f14:	48 83 ec 10          	sub    $0x10,%rsp
    5f18:	8b 1d ea 85 06 00    	mov    0x685ea(%rip),%ebx        # 6e508 <iteration_active>
    5f1e:	8b 05 c0 7c 06 00    	mov    0x67cc0(%rip),%eax        # 6dbe4 <fwp_heap+0x13a4>
    5f24:	85 db                	test   %ebx,%ebx
    5f26:	0f 85 04 01 00 00    	jne    6030 <fwp_heap_alloc+0x120>
    5f2c:	85 c0                	test   %eax,%eax
    5f2e:	0f 84 ac 01 00 00    	je     60e0 <fwp_heap_alloc+0x1d0>
    5f34:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f3b:	0f 87 9f 01 00 00    	ja     60e0 <fwp_heap_alloc+0x1d0>
    5f41:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f45:	48 8d 05 f4 68 06 00 	lea    0x668f4(%rip),%rax        # 6c840 <fwp_heap>
    5f4c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f50:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f57:	00 
    5f58:	48 63 ce             	movslq %esi,%rcx
    5f5b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f62:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f69:	00 
    5f6a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f6e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f72:	48 01 c8             	add    %rcx,%rax
    5f75:	48 8b 08             	mov    (%rax),%rcx
    5f78:	48 85 c9             	test   %rcx,%rcx
    5f7b:	0f 84 ff 00 00 00    	je     6080 <fwp_heap_alloc+0x170>
    5f81:	48 8b 39             	mov    (%rcx),%rdi
    5f84:	48 f7 d7             	not    %rdi
    5f87:	48 89 38             	mov    %rdi,(%rax)
    5f8a:	83 fe 01             	cmp    $0x1,%esi
    5f8d:	48 89 cf             	mov    %rcx,%rdi
    5f90:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f95:	49 0f 45 d0          	cmovne %r8,%rdx
    5f99:	31 f6                	xor    %esi,%esi
    5f9b:	e8 10 d5 ff ff       	call   34b0 <memset@plt>
    5fa0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5fa5:	48 89 c1             	mov    %rax,%rcx
    5fa8:	4c 89 c0             	mov    %r8,%rax
    5fab:	48 03 05 ae 7c 06 00 	add    0x67cae(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    5fb2:	0f 82 35 01 00 00    	jb     60ed <fwp_heap_alloc+0x1dd>
    5fb8:	48 39 05 a9 7c 06 00 	cmp    %rax,0x67ca9(%rip)        # 6dc68 <fwp_heap+0x1428>
    5fbf:	48 89 05 9a 7c 06 00 	mov    %rax,0x67c9a(%rip)        # 6dc60 <fwp_heap+0x1420>
    5fc6:	73 07                	jae    5fcf <fwp_heap_alloc+0xbf>
    5fc8:	48 89 05 99 7c 06 00 	mov    %rax,0x67c99(%rip)        # 6dc68 <fwp_heap+0x1428>
    5fcf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fd3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fd8:	f2 0f 58 05 98 7c 06 	addsd  0x67c98(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    5fdf:	00 
    5fe0:	f2 0f 11 05 90 7c 06 	movsd  %xmm0,0x67c90(%rip)        # 6dc78 <fwp_heap+0x1438>
    5fe7:	00 
    5fe8:	85 db                	test   %ebx,%ebx
    5fea:	74 33                	je     601f <fwp_heap_alloc+0x10f>
    5fec:	48 8b 05 6d 7c 06 00 	mov    0x67c6d(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    5ff3:	48 85 c0             	test   %rax,%rax
    5ff6:	0f 88 ac 00 00 00    	js     60a8 <fwp_heap_alloc+0x198>
    5ffc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6000:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6005:	f2 0f 5c 05 db 84 06 	subsd  0x684db(%rip),%xmm0        # 6e4e8 <iteration_start_charge>
    600c:	00 
    600d:	66 0f 2f 05 cb 84 06 	comisd 0x684cb(%rip),%xmm0        # 6e4e0 <iteration_peak>
    6014:	00 
    6015:	76 08                	jbe    601f <fwp_heap_alloc+0x10f>
    6017:	f2 0f 11 05 c1 84 06 	movsd  %xmm0,0x684c1(%rip)        # 6e4e0 <iteration_peak>
    601e:	00 
    601f:	48 83 c4 10          	add    $0x10,%rsp
    6023:	48 89 c8             	mov    %rcx,%rax
    6026:	5b                   	pop    %rbx
    6027:	c3                   	ret
    6028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    602f:	00 
    6030:	85 f6                	test   %esi,%esi
    6032:	74 34                	je     6068 <fwp_heap_alloc+0x158>
    6034:	48 83 05 c4 84 06 00 	addq   $0x1,0x684c4(%rip)        # 6e500 <iteration_requests>
    603b:	01 
    603c:	48 01 3d b5 84 06 00 	add    %rdi,0x684b5(%rip)        # 6e4f8 <iteration_bytes>
    6043:	85 c0                	test   %eax,%eax
    6045:	74 0d                	je     6054 <fwp_heap_alloc+0x144>
    6047:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    604e:	0f 86 ed fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6054:	48 89 d7             	mov    %rdx,%rdi
    6057:	e8 34 fd ff ff       	call   5d90 <fwp_heap_alloc_slow>
    605c:	48 89 c1             	mov    %rax,%rcx
    605f:	eb 8b                	jmp    5fec <fwp_heap_alloc+0xdc>
    6061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6068:	85 c0                	test   %eax,%eax
    606a:	74 0d                	je     6079 <fwp_heap_alloc+0x169>
    606c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6073:	0f 86 c8 fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6079:	31 f6                	xor    %esi,%esi
    607b:	eb d7                	jmp    6054 <fwp_heap_alloc+0x144>
    607d:	0f 1f 00             	nopl   (%rax)
    6080:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6084:	48 85 c9             	test   %rcx,%rcx
    6087:	74 0c                	je     6095 <fwp_heap_alloc+0x185>
    6089:	48 8b 78 10          	mov    0x10(%rax),%rdi
    608d:	48 29 cf             	sub    %rcx,%rdi
    6090:	4c 39 c7             	cmp    %r8,%rdi
    6093:	73 3b                	jae    60d0 <fwp_heap_alloc+0x1c0>
    6095:	48 89 d7             	mov    %rdx,%rdi
    6098:	e8 f3 fc ff ff       	call   5d90 <fwp_heap_alloc_slow>
    609d:	48 89 c1             	mov    %rax,%rcx
    60a0:	e9 43 ff ff ff       	jmp    5fe8 <fwp_heap_alloc+0xd8>
    60a5:	0f 1f 00             	nopl   (%rax)
    60a8:	48 89 c2             	mov    %rax,%rdx
    60ab:	83 e0 01             	and    $0x1,%eax
    60ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60b2:	48 d1 ea             	shr    $1,%rdx
    60b5:	48 09 c2             	or     %rax,%rdx
    60b8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    60bd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60c1:	e9 3f ff ff ff       	jmp    6005 <fwp_heap_alloc+0xf5>
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60d4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60d8:	e9 ad fe ff ff       	jmp    5f8a <fwp_heap_alloc+0x7a>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 83 c4 10          	add    $0x10,%rsp
    60e4:	48 89 d7             	mov    %rdx,%rdi
    60e7:	5b                   	pop    %rbx
    60e8:	e9 a3 fc ff ff       	jmp    5d90 <fwp_heap_alloc_slow>
    60ed:	e8 3e dd ff ff       	call   3e30 <fwp_heap_oom>
    60f2:	0f 1f 00             	nopl   (%rax)
    60f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60fc:	00 00 00 00 

0000000000006100 <fwp_apply>:
    6100:	55                   	push   %rbp
    6101:	48 89 f9             	mov    %rdi,%rcx
    6104:	48 89 e5             	mov    %rsp,%rbp
    6107:	41 57                	push   %r15
    6109:	41 56                	push   %r14
    610b:	41 55                	push   %r13
    610d:	41 89 f5             	mov    %esi,%r13d
    6110:	41 54                	push   %r12
    6112:	53                   	push   %rbx
    6113:	48 83 ec 28          	sub    $0x28,%rsp
    6117:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    611e:	00 00 
    6120:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    6124:	49 89 d6             	mov    %rdx,%r14
    6127:	44 8b 09             	mov    (%rcx),%r9d
    612a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    612e:	49 89 e0             	mov    %rsp,%r8
    6131:	49 c1 e1 05          	shl    $0x5,%r9
    6135:	4c 03 0d 5c 83 06 00 	add    0x6835c(%rip),%r9        # 6e498 <fwp_fns>
    613c:	41 8b 19             	mov    (%r9),%ebx
    613f:	45 85 e4             	test   %r12d,%r12d
    6142:	75 2c                	jne    6170 <fwp_apply+0x70>
    6144:	41 39 dd             	cmp    %ebx,%r13d
    6147:	72 27                	jb     6170 <fwp_apply+0x70>
    6149:	85 db                	test   %ebx,%ebx
    614b:	0f 84 b7 01 00 00    	je     6308 <fwp_apply+0x208>
    6151:	4c 89 f7             	mov    %r14,%rdi
    6154:	41 ff 51 08          	call   *0x8(%r9)
    6158:	48 89 c1             	mov    %rax,%rcx
    615b:	41 39 dd             	cmp    %ebx,%r13d
    615e:	0f 84 7c 01 00 00    	je     62e0 <fwp_apply+0x1e0>
    6164:	89 d8                	mov    %ebx,%eax
    6166:	41 29 dd             	sub    %ebx,%r13d
    6169:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    616d:	eb b8                	jmp    6127 <fwp_apply+0x27>
    616f:	90                   	nop
    6170:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    6175:	41 39 df             	cmp    %ebx,%r15d
    6178:	0f 82 dc 00 00 00    	jb     625a <fwp_apply+0x15a>
    617e:	41 89 df             	mov    %ebx,%r15d
    6181:	b8 01 00 00 00       	mov    $0x1,%eax
    6186:	48 89 e2             	mov    %rsp,%rdx
    6189:	45 29 e7             	sub    %r12d,%r15d
    618c:	85 db                	test   %ebx,%ebx
    618e:	0f 45 c3             	cmovne %ebx,%eax
    6191:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    6198:	00 
    6199:	48 c1 e8 04          	shr    $0x4,%rax
    619d:	48 c1 e0 04          	shl    $0x4,%rax
    61a1:	48 89 c6             	mov    %rax,%rsi
    61a4:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    61ab:	48 29 f2             	sub    %rsi,%rdx
    61ae:	48 39 d4             	cmp    %rdx,%rsp
    61b1:	74 15                	je     61c8 <fwp_apply+0xc8>
    61b3:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    61ba:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    61c1:	00 00 
    61c3:	48 39 d4             	cmp    %rdx,%rsp
    61c6:	75 eb                	jne    61b3 <fwp_apply+0xb3>
    61c8:	25 ff 0f 00 00       	and    $0xfff,%eax
    61cd:	48 29 c4             	sub    %rax,%rsp
    61d0:	48 85 c0             	test   %rax,%rax
    61d3:	0f 85 59 01 00 00    	jne    6332 <fwp_apply+0x232>
    61d9:	45 89 e2             	mov    %r12d,%r10d
    61dc:	48 89 e6             	mov    %rsp,%rsi
    61df:	48 89 e7             	mov    %rsp,%rdi
    61e2:	31 c0                	xor    %eax,%eax
    61e4:	49 c1 e2 03          	shl    $0x3,%r10
    61e8:	45 85 e4             	test   %r12d,%r12d
    61eb:	74 25                	je     6212 <fwp_apply+0x112>
    61ed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    61f4:	00 
    61f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    61fc:	00 00 00 00 
    6200:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    6205:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    6209:	48 83 c0 08          	add    $0x8,%rax
    620d:	4c 39 d0             	cmp    %r10,%rax
    6210:	75 ee                	jne    6200 <fwp_apply+0x100>
    6212:	45 85 ff             	test   %r15d,%r15d
    6215:	0f 84 f4 00 00 00    	je     630f <fwp_apply+0x20f>
    621b:	44 89 fa             	mov    %r15d,%edx
    621e:	4c 89 f0             	mov    %r14,%rax
    6221:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    6225:	44 89 e2             	mov    %r12d,%edx
    6228:	66 90                	xchg   %ax,%ax
    622a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6231:	00 00 00 00 
    6235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    623c:	00 00 00 00 
    6240:	4c 8b 10             	mov    (%rax),%r10
    6243:	89 d1                	mov    %edx,%ecx
    6245:	48 83 c0 08          	add    $0x8,%rax
    6249:	83 c2 01             	add    $0x1,%edx
    624c:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    6250:	4c 39 d8             	cmp    %r11,%rax
    6253:	75 eb                	jne    6240 <fwp_apply+0x140>
    6255:	e9 b5 00 00 00       	jmp    630f <fwp_apply+0x20f>
    625a:	41 8d 7f 01          	lea    0x1(%r15),%edi
    625e:	be 02 00 00 00       	mov    $0x2,%esi
    6263:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    6267:	48 c1 e7 03          	shl    $0x3,%rdi
    626b:	e8 a0 fc ff ff       	call   5f10 <fwp_heap_alloc>
    6270:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    6274:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    6279:	48 89 c3             	mov    %rax,%rbx
    627c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    6280:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6284:	66 0f d6 00          	movq   %xmm0,(%rax)
    6288:	45 85 e4             	test   %r12d,%r12d
    628b:	74 14                	je     62a1 <fwp_apply+0x1a1>
    628d:	44 89 e2             	mov    %r12d,%edx
    6290:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    6294:	48 8d 78 08          	lea    0x8(%rax),%rdi
    6298:	48 c1 e2 03          	shl    $0x3,%rdx
    629c:	e8 4f d3 ff ff       	call   35f0 <memmove@plt>
    62a1:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    62a5:	45 85 ed             	test   %r13d,%r13d
    62a8:	74 2e                	je     62d8 <fwp_apply+0x1d8>
    62aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62b1:	00 00 00 00 
    62b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62bc:	00 00 00 00 
    62c0:	49 8b 16             	mov    (%r14),%rdx
    62c3:	44 89 e0             	mov    %r12d,%eax
    62c6:	49 83 c6 08          	add    $0x8,%r14
    62ca:	41 83 c4 01          	add    $0x1,%r12d
    62ce:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    62d3:	49 39 ce             	cmp    %rcx,%r14
    62d6:	75 e8                	jne    62c0 <fwp_apply+0x1c0>
    62d8:	48 89 d9             	mov    %rbx,%rcx
    62db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    62e0:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    62e4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    62eb:	00 00 
    62ed:	75 4e                	jne    633d <fwp_apply+0x23d>
    62ef:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    62f3:	48 89 c8             	mov    %rcx,%rax
    62f6:	5b                   	pop    %rbx
    62f7:	41 5c                	pop    %r12
    62f9:	41 5d                	pop    %r13
    62fb:	41 5e                	pop    %r14
    62fd:	41 5f                	pop    %r15
    62ff:	5d                   	pop    %rbp
    6300:	c3                   	ret
    6301:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6308:	45 31 ff             	xor    %r15d,%r15d
    630b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    630f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    6313:	41 ff 51 08          	call   *0x8(%r9)
    6317:	48 89 c1             	mov    %rax,%rcx
    631a:	45 39 fd             	cmp    %r15d,%r13d
    631d:	74 c1                	je     62e0 <fwp_apply+0x1e0>
    631f:	45 01 e5             	add    %r12d,%r13d
    6322:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    6326:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    632a:	41 29 dd             	sub    %ebx,%r13d
    632d:	e9 f5 fd ff ff       	jmp    6127 <fwp_apply+0x27>
    6332:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    6338:	e9 9c fe ff ff       	jmp    61d9 <fwp_apply+0xd9>
    633d:	e8 0e d1 ff ff       	call   3450 <__stack_chk_fail@plt>
    6342:	0f 1f 00             	nopl   (%rax)
    6345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    634c:	00 00 00 00 

0000000000006350 <fwp_p_ad_push>:
    6350:	41 57                	push   %r15
    6352:	41 56                	push   %r14
    6354:	41 55                	push   %r13
    6356:	49 89 d5             	mov    %rdx,%r13
    6359:	41 54                	push   %r12
    635b:	49 89 fc             	mov    %rdi,%r12
    635e:	55                   	push   %rbp
    635f:	53                   	push   %rbx
    6360:	48 83 ec 38          	sub    $0x38,%rsp
    6364:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6369:	48 85 ff             	test   %rdi,%rdi
    636c:	79 09                	jns    6377 <fwp_p_ad_push+0x27>
    636e:	48 85 d2             	test   %rdx,%rdx
    6371:	0f 88 a9 01 00 00    	js     6520 <fwp_p_ad_push+0x1d0>
    6377:	48 89 f8             	mov    %rdi,%rax
    637a:	48 89 0c 24          	mov    %rcx,(%rsp)
    637e:	48 09 d0             	or     %rdx,%rax
    6381:	0f 89 71 01 00 00    	jns    64f8 <fwp_p_ad_push+0x1a8>
    6387:	48 89 f8             	mov    %rdi,%rax
    638a:	48 c1 f8 20          	sar    $0x20,%rax
    638e:	48 85 ff             	test   %rdi,%rdi
    6391:	79 24                	jns    63b7 <fwp_p_ad_push+0x67>
    6393:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6398:	48 89 d0             	mov    %rdx,%rax
    639b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    63a2:	00 
    63a3:	49 89 d4             	mov    %rdx,%r12
    63a6:	48 c1 f8 20          	sar    $0x20,%rax
    63aa:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    63b1:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    63b7:	48 89 c7             	mov    %rax,%rdi
    63ba:	e8 71 e3 ff ff       	call   4730 <fwp_tape_of>
    63bf:	48 89 c3             	mov    %rax,%rbx
    63c2:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    63c7:	0f 85 6e 02 00 00    	jne    663b <fwp_p_ad_push+0x2eb>
    63cd:	4c 8b 78 10          	mov    0x10(%rax),%r15
    63d1:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    63d8:	0f 8f 51 02 00 00    	jg     662f <fwp_p_ad_push+0x2df>
    63de:	44 89 e0             	mov    %r12d,%eax
    63e1:	4c 39 f8             	cmp    %r15,%rax
    63e4:	0f 8d 39 02 00 00    	jge    6623 <fwp_p_ad_push+0x2d3>
    63ea:	4d 85 ed             	test   %r13,%r13
    63ed:	78 0c                	js     63fb <fwp_p_ad_push+0xab>
    63ef:	44 89 e8             	mov    %r13d,%eax
    63f2:	4c 39 f8             	cmp    %r15,%rax
    63f5:	0f 8d 28 02 00 00    	jge    6623 <fwp_p_ad_push+0x2d3>
    63fb:	4d 89 fe             	mov    %r15,%r14
    63fe:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6402:	49 8d 46 01          	lea    0x1(%r14),%rax
    6406:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    640c:	0f 87 1d 02 00 00    	ja     662f <fwp_p_ad_push+0x2df>
    6412:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    6416:	48 39 e8             	cmp    %rbp,%rax
    6419:	0f 8e 31 01 00 00    	jle    6550 <fwp_p_ad_push+0x200>
    641f:	48 85 ed             	test   %rbp,%rbp
    6422:	ba 40 00 00 00       	mov    $0x40,%edx
    6427:	48 0f 44 ea          	cmove  %rdx,%rbp
    642b:	48 39 e8             	cmp    %rbp,%rax
    642e:	7e 20                	jle    6450 <fwp_p_ad_push+0x100>
    6430:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    6437:	0f 8f 03 01 00 00    	jg     6540 <fwp_p_ad_push+0x1f0>
    643d:	48 01 ed             	add    %rbp,%rbp
    6440:	48 39 e8             	cmp    %rbp,%rax
    6443:	7f eb                	jg     6430 <fwp_p_ad_push+0xe0>
    6445:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    644c:	00 00 00 00 
    6450:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6457:	00 
    6458:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    645c:	ba 01 00 00 00       	mov    $0x1,%edx
    6461:	48 89 c6             	mov    %rax,%rsi
    6464:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6469:	e8 22 ed ff ff       	call   5190 <ad_raw_realloc>
    646e:	48 85 c0             	test   %rax,%rax
    6471:	0f 84 d0 01 00 00    	je     6647 <fwp_p_ad_push+0x2f7>
    6477:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    647b:	48 89 ee             	mov    %rbp,%rsi
    647e:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6482:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6486:	48 c1 e6 04          	shl    $0x4,%rsi
    648a:	48 8d 04 90          	lea    (%rax,%rdx,4),%rax
    648e:	ba 02 00 00 00       	mov    $0x2,%edx
    6493:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6497:	e8 f4 ec ff ff       	call   5190 <ad_raw_realloc>
    649c:	48 85 c0             	test   %rax,%rax
    649f:	0f 84 a2 01 00 00    	je     6647 <fwp_p_ad_push+0x2f7>
    64a5:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    64a9:	48 89 43 30          	mov    %rax,0x30(%rbx)
    64ad:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    64b4:	00 
    64b5:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    64bc:	00 
    64bd:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
    64c4:	00 
    64c5:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    64c9:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    64ce:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    64d2:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    64d6:	4d 85 f6             	test   %r14,%r14
    64d9:	0f 85 e5 00 00 00    	jne    65c4 <fwp_p_ad_push+0x274>
    64df:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    64e3:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    64e7:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    64eb:	48 01 d1             	add    %rdx,%rcx
    64ee:	48 89 4b 28          	mov    %rcx,0x28(%rbx)
    64f2:	eb 7c                	jmp    6570 <fwp_p_ad_push+0x220>
    64f4:	0f 1f 40 00          	nopl   0x0(%rax)
    64f8:	48 89 d0             	mov    %rdx,%rax
    64fb:	48 c1 ff 20          	sar    $0x20,%rdi
    64ff:	48 c1 f8 20          	sar    $0x20,%rax
    6503:	48 39 c7             	cmp    %rax,%rdi
    6506:	0f 84 ab fe ff ff    	je     63b7 <fwp_p_ad_push+0x67>
    650c:	48 8d 3d f5 a4 00 00 	lea    0xa4f5(%rip),%rdi        # 10a08 <_IO_stdin_used+0xa08>
    6513:	e8 38 df ff ff       	call   4450 <fwp_trap>
    6518:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    651f:	00 
    6520:	48 83 c4 38          	add    $0x38,%rsp
    6524:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    652b:	5b                   	pop    %rbx
    652c:	5d                   	pop    %rbp
    652d:	41 5c                	pop    %r12
    652f:	41 5d                	pop    %r13
    6531:	41 5e                	pop    %r14
    6533:	41 5f                	pop    %r15
    6535:	c3                   	ret
    6536:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    653d:	00 00 00 
    6540:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    6545:	e9 06 ff ff ff       	jmp    6450 <fwp_p_ad_push+0x100>
    654a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6550:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    6554:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6558:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    655f:	00 
    6560:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6567:	00 
    6568:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
    656c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6570:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6576:	46 89 24 12          	mov    %r12d,(%rdx,%r10,1)
    657a:	4d 85 ed             	test   %r13,%r13
    657d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6582:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6588:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    658f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6593:	49 8d 47 01          	lea    0x1(%r15),%rax
    6597:	46 89 2c 11          	mov    %r13d,(%rcx,%r10,1)
    659b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    65a1:	48 89 43 10          	mov    %rax,0x10(%rbx)
    65a5:	48 83 c4 38          	add    $0x38,%rsp
    65a9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    65b0:	ff ff ff 
    65b3:	4c 21 e0             	and    %r12,%rax
    65b6:	5b                   	pop    %rbx
    65b7:	5d                   	pop    %rbp
    65b8:	4c 09 f8             	or     %r15,%rax
    65bb:	41 5c                	pop    %r12
    65bd:	41 5d                	pop    %r13
    65bf:	41 5e                	pop    %r14
    65c1:	41 5f                	pop    %r15
    65c3:	c3                   	ret
    65c4:	4c 89 ca             	mov    %r9,%rdx
    65c7:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    65cc:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    65d1:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    65d6:	e8 15 d0 ff ff       	call   35f0 <memmove@plt>
    65db:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    65e0:	4c 03 73 30          	add    0x30(%rbx),%r14
    65e4:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    65e9:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    65ed:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    65f1:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    65f6:	48 03 7b 20          	add    0x20(%rbx),%rdi
    65fa:	4c 89 d2             	mov    %r10,%rdx
    65fd:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    6602:	e8 e9 cf ff ff       	call   35f0 <memmove@plt>
    6607:	48 8b 43 30          	mov    0x30(%rbx),%rax
    660b:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    660f:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    6614:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6619:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    661e:	e9 c0 fe ff ff       	jmp    64e3 <fwp_p_ad_push+0x193>
    6623:	48 8d 3d 98 9b 00 00 	lea    0x9b98(%rip),%rdi        # 101c2 <_IO_stdin_used+0x1c2>
    662a:	e8 21 de ff ff       	call   4450 <fwp_trap>
    662f:	48 8d 3d 71 9b 00 00 	lea    0x9b71(%rip),%rdi        # 101a7 <_IO_stdin_used+0x1a7>
    6636:	e8 15 de ff ff       	call   4450 <fwp_trap>
    663b:	48 8d 3d 0e a4 00 00 	lea    0xa40e(%rip),%rdi        # 10a50 <_IO_stdin_used+0xa50>
    6642:	e8 09 de ff ff       	call   4450 <fwp_trap>
    6647:	48 89 df             	mov    %rbx,%rdi
    664a:	e8 41 d6 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    664f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6653:	48 85 ff             	test   %rdi,%rdi
    6656:	74 05                	je     665d <fwp_p_ad_push+0x30d>
    6658:	e8 73 ea ff ff       	call   50d0 <ad_raw_free.part.0>
    665d:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6661:	48 85 ff             	test   %rdi,%rdi
    6664:	74 05                	je     666b <fwp_p_ad_push+0x31b>
    6666:	e8 65 ea ff ff       	call   50d0 <ad_raw_free.part.0>
    666b:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    666f:	48 85 ff             	test   %rdi,%rdi
    6672:	74 05                	je     6679 <fwp_p_ad_push+0x329>
    6674:	e8 57 ea ff ff       	call   50d0 <ad_raw_free.part.0>
    6679:	31 c9                	xor    %ecx,%ecx
    667b:	31 c0                	xor    %eax,%eax
    667d:	31 d2                	xor    %edx,%edx
    667f:	be 01 00 00 00       	mov    $0x1,%esi
    6684:	89 53 04             	mov    %edx,0x4(%rbx)
    6687:	66 0f ef c0          	pxor   %xmm0,%xmm0
    668b:	ba 13 00 00 00       	mov    $0x13,%edx
    6690:	48 8d 3d 71 99 00 00 	lea    0x9971(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    6697:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    669b:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    669f:	48 8b 0d ba d9 00 00 	mov    0xd9ba(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    66a6:	48 89 43 40          	mov    %rax,0x40(%rbx)
    66aa:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    66ae:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    66b2:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    66b6:	e8 a5 cf ff ff       	call   3660 <fwrite@plt>
    66bb:	31 ff                	xor    %edi,%edi
    66bd:	e8 de ce ff ff       	call   35a0 <fflush@plt>
    66c2:	bf 66 00 00 00       	mov    $0x66,%edi
    66c7:	e8 b4 cf ff ff       	call   3680 <_Exit@plt>
    66cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000066d0 <w107>:
    66d0:	66 0f 28 e0          	movapd %xmm0,%xmm4
    66d4:	41 55                	push   %r13
    66d6:	48 89 fa             	mov    %rdi,%rdx
    66d9:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    66dd:	41 54                	push   %r12
    66df:	49 89 fc             	mov    %rdi,%r12
    66e2:	55                   	push   %rbp
    66e3:	53                   	push   %rbx
    66e4:	48 89 f3             	mov    %rsi,%rbx
    66e7:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    66ec:	48 89 f1             	mov    %rsi,%rcx
    66ef:	48 83 ec 28          	sub    $0x28,%rsp
    66f3:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    66f9:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    66ff:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6705:	e8 46 fc ff ff       	call   6350 <fwp_p_ad_push>
    670a:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6710:	48 89 da             	mov    %rbx,%rdx
    6713:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6719:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6720:	00 f0 3f 
    6723:	48 89 c7             	mov    %rax,%rdi
    6726:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    672d:	00 f0 bf 
    6730:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6735:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    673b:	e8 10 fc ff ff       	call   6350 <fwp_p_ad_push>
    6740:	f2 0f 10 05 98 a6 00 	movsd  0xa698(%rip),%xmm0        # 10de0 <msg.4+0xb0>
    6747:	00 
    6748:	4c 89 e7             	mov    %r12,%rdi
    674b:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    6751:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6758:	00 f0 3f 
    675b:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6762:	49 89 c5             	mov    %rax,%r13
    6765:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    676c:	00 f0 bf 
    676f:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    6774:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    677a:	e8 d1 fb ff ff       	call   6350 <fwp_p_ad_push>
    677f:	48 89 e9             	mov    %rbp,%rcx
    6782:	4c 89 ea             	mov    %r13,%rdx
    6785:	48 89 ee             	mov    %rbp,%rsi
    6788:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    678e:	4c 89 ef             	mov    %r13,%rdi
    6791:	49 89 c4             	mov    %rax,%r12
    6794:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6798:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    679e:	e8 ad fb ff ff       	call   6350 <fwp_p_ad_push>
    67a3:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    67a9:	f2 0f 59 1d 37 a6 00 	mulsd  0xa637(%rip),%xmm3        # 10de8 <msg.4+0xb8>
    67b0:	00 
    67b1:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    67b8:	00 59 40 
    67bb:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    67c0:	48 89 c2             	mov    %rax,%rdx
    67c3:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    67ca:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    67d0:	e8 7b fb ff ff       	call   6350 <fwp_p_ad_push>
    67d5:	48 89 d9             	mov    %rbx,%rcx
    67d8:	4c 89 e2             	mov    %r12,%rdx
    67db:	48 89 de             	mov    %rbx,%rsi
    67de:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    67e4:	4c 89 e7             	mov    %r12,%rdi
    67e7:	48 89 c5             	mov    %rax,%rbp
    67ea:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    67ee:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    67f4:	e8 57 fb ff ff       	call   6350 <fwp_p_ad_push>
    67f9:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    67ff:	48 89 ea             	mov    %rbp,%rdx
    6802:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6808:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    680f:	00 f0 3f 
    6812:	48 89 c7             	mov    %rax,%rdi
    6815:	48 89 ce             	mov    %rcx,%rsi
    6818:	66 48 0f 7e db       	movq   %xmm3,%rbx
    681d:	e8 2e fb ff ff       	call   6350 <fwp_p_ad_push>
    6822:	48 83 c4 28          	add    $0x28,%rsp
    6826:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    682b:	5b                   	pop    %rbx
    682c:	5d                   	pop    %rbp
    682d:	41 5c                	pop    %r12
    682f:	41 5d                	pop    %r13
    6831:	c3                   	ret
    6832:	0f 1f 00             	nopl   (%rax)
    6835:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    683c:	00 00 00 00 

0000000000006840 <fwp_data.part.0.constprop.0>:
    6840:	41 56                	push   %r14
    6842:	8b 05 9c 73 06 00    	mov    0x6739c(%rip),%eax        # 6dbe4 <fwp_heap+0x13a4>
    6848:	41 89 fe             	mov    %edi,%r14d
    684b:	41 55                	push   %r13
    684d:	44 8b 2d b4 7c 06 00 	mov    0x67cb4(%rip),%r13d        # 6e508 <iteration_active>
    6854:	41 54                	push   %r12
    6856:	49 89 f4             	mov    %rsi,%r12
    6859:	55                   	push   %rbp
    685a:	53                   	push   %rbx
    685b:	45 85 ed             	test   %r13d,%r13d
    685e:	0f 84 1c 01 00 00    	je     6980 <fwp_data.part.0.constprop.0+0x140>
    6864:	48 83 05 94 7c 06 00 	addq   $0x1,0x67c94(%rip)        # 6e500 <iteration_requests>
    686b:	01 
    686c:	48 83 05 84 7c 06 00 	addq   $0x18,0x67c84(%rip)        # 6e4f8 <iteration_bytes>
    6873:	18 
    6874:	85 c0                	test   %eax,%eax
    6876:	0f 84 8c 01 00 00    	je     6a08 <fwp_data.part.0.constprop.0+0x1c8>
    687c:	0f b6 05 5f 6f 06 00 	movzbl 0x66f5f(%rip),%eax        # 6d7e2 <fwp_heap+0xfa2>
    6883:	48 8d 15 b6 5f 06 00 	lea    0x65fb6(%rip),%rdx        # 6c840 <fwp_heap>
    688a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6891:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6895:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6899:	48 8b 18             	mov    (%rax),%rbx
    689c:	48 85 db             	test   %rbx,%rbx
    689f:	0f 84 fb 00 00 00    	je     69a0 <fwp_data.part.0.constprop.0+0x160>
    68a5:	48 8b 13             	mov    (%rbx),%rdx
    68a8:	48 f7 d2             	not    %rdx
    68ab:	48 89 10             	mov    %rdx,(%rax)
    68ae:	48 83 fd 18          	cmp    $0x18,%rbp
    68b2:	76 1b                	jbe    68cf <fwp_data.part.0.constprop.0+0x8f>
    68b4:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    68b8:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    68bc:	31 f6                	xor    %esi,%esi
    68be:	48 c1 e8 03          	shr    $0x3,%rax
    68c2:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    68c9:	00 
    68ca:	e8 e1 cb ff ff       	call   34b0 <memset@plt>
    68cf:	48 89 e8             	mov    %rbp,%rax
    68d2:	48 03 05 87 73 06 00 	add    0x67387(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    68d9:	0f 82 3d 01 00 00    	jb     6a1c <fwp_data.part.0.constprop.0+0x1dc>
    68df:	48 39 05 82 73 06 00 	cmp    %rax,0x67382(%rip)        # 6dc68 <fwp_heap+0x1428>
    68e6:	48 89 05 73 73 06 00 	mov    %rax,0x67373(%rip)        # 6dc60 <fwp_heap+0x1420>
    68ed:	73 07                	jae    68f6 <fwp_data.part.0.constprop.0+0xb6>
    68ef:	48 89 05 72 73 06 00 	mov    %rax,0x67372(%rip)        # 6dc68 <fwp_heap+0x1428>
    68f6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    68fa:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    68ff:	f2 0f 58 05 71 73 06 	addsd  0x67371(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    6906:	00 
    6907:	f2 0f 11 05 69 73 06 	movsd  %xmm0,0x67369(%rip)        # 6dc78 <fwp_heap+0x1438>
    690e:	00 
    690f:	45 85 ed             	test   %r13d,%r13d
    6912:	74 33                	je     6947 <fwp_data.part.0.constprop.0+0x107>
    6914:	48 8b 05 45 73 06 00 	mov    0x67345(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    691b:	48 85 c0             	test   %rax,%rax
    691e:	0f 88 a4 00 00 00    	js     69c8 <fwp_data.part.0.constprop.0+0x188>
    6924:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6928:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    692d:	f2 0f 5c 05 b3 7b 06 	subsd  0x67bb3(%rip),%xmm0        # 6e4e8 <iteration_start_charge>
    6934:	00 
    6935:	66 0f 2f 05 a3 7b 06 	comisd 0x67ba3(%rip),%xmm0        # 6e4e0 <iteration_peak>
    693c:	00 
    693d:	76 08                	jbe    6947 <fwp_data.part.0.constprop.0+0x107>
    693f:	f2 0f 11 05 99 7b 06 	movsd  %xmm0,0x67b99(%rip)        # 6e4e0 <iteration_peak>
    6946:	00 
    6947:	b8 02 00 00 00       	mov    $0x2,%eax
    694c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6951:	66 0f 6e c8          	movd   %eax,%xmm1
    6955:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6959:	66 0f d6 03          	movq   %xmm0,(%rbx)
    695d:	49 8b 04 24          	mov    (%r12),%rax
    6961:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6965:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    696a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    696e:	48 89 d8             	mov    %rbx,%rax
    6971:	5b                   	pop    %rbx
    6972:	5d                   	pop    %rbp
    6973:	41 5c                	pop    %r12
    6975:	41 5d                	pop    %r13
    6977:	41 5e                	pop    %r14
    6979:	c3                   	ret
    697a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6980:	85 c0                	test   %eax,%eax
    6982:	0f 85 f4 fe ff ff    	jne    687c <fwp_data.part.0.constprop.0+0x3c>
    6988:	31 f6                	xor    %esi,%esi
    698a:	bf 18 00 00 00       	mov    $0x18,%edi
    698f:	e8 7c f5 ff ff       	call   5f10 <fwp_heap_alloc>
    6994:	48 89 c3             	mov    %rax,%rbx
    6997:	eb ae                	jmp    6947 <fwp_data.part.0.constprop.0+0x107>
    6999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    69a0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    69a4:	48 85 db             	test   %rbx,%rbx
    69a7:	74 47                	je     69f0 <fwp_data.part.0.constprop.0+0x1b0>
    69a9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    69ad:	48 29 da             	sub    %rbx,%rdx
    69b0:	48 39 ea             	cmp    %rbp,%rdx
    69b3:	72 3b                	jb     69f0 <fwp_data.part.0.constprop.0+0x1b0>
    69b5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    69b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    69bd:	e9 ec fe ff ff       	jmp    68ae <fwp_data.part.0.constprop.0+0x6e>
    69c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    69c8:	48 89 c2             	mov    %rax,%rdx
    69cb:	83 e0 01             	and    $0x1,%eax
    69ce:	66 0f ef c0          	pxor   %xmm0,%xmm0
    69d2:	48 d1 ea             	shr    $1,%rdx
    69d5:	48 09 c2             	or     %rax,%rdx
    69d8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    69dd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    69e1:	e9 47 ff ff ff       	jmp    692d <fwp_data.part.0.constprop.0+0xed>
    69e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    69ed:	00 00 00 
    69f0:	31 f6                	xor    %esi,%esi
    69f2:	bf 18 00 00 00       	mov    $0x18,%edi
    69f7:	e8 14 f5 ff ff       	call   5f10 <fwp_heap_alloc>
    69fc:	48 89 c3             	mov    %rax,%rbx
    69ff:	e9 0b ff ff ff       	jmp    690f <fwp_data.part.0.constprop.0+0xcf>
    6a04:	0f 1f 40 00          	nopl   0x0(%rax)
    6a08:	31 f6                	xor    %esi,%esi
    6a0a:	bf 18 00 00 00       	mov    $0x18,%edi
    6a0f:	e8 fc f4 ff ff       	call   5f10 <fwp_heap_alloc>
    6a14:	48 89 c3             	mov    %rax,%rbx
    6a17:	e9 f8 fe ff ff       	jmp    6914 <fwp_data.part.0.constprop.0+0xd4>
    6a1c:	e8 0f d4 ff ff       	call   3e30 <fwp_heap_oom>
    6a21:	0f 1f 40 00          	nopl   0x0(%rax)
    6a25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6a2c:	00 00 00 00 

0000000000006a30 <fwp_rc_share>:
    6a30:	48 8b 05 e1 71 06 00 	mov    0x671e1(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    6a37:	48 2b 3d b2 71 06 00 	sub    0x671b2(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    6a3e:	48 c1 e0 10          	shl    $0x10,%rax
    6a42:	48 39 c7             	cmp    %rax,%rdi
    6a45:	73 4a                	jae    6a91 <fwp_rc_share+0x61>
    6a47:	48 89 f8             	mov    %rdi,%rax
    6a4a:	48 c1 e8 10          	shr    $0x10,%rax
    6a4e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6a52:	48 8b 05 df 71 06 00 	mov    0x671df(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    6a59:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6a5d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6a61:	48 85 d2             	test   %rdx,%rdx
    6a64:	74 2b                	je     6a91 <fwp_rc_share+0x61>
    6a66:	0f b6 08             	movzbl (%rax),%ecx
    6a69:	80 f9 02             	cmp    $0x2,%cl
    6a6c:	74 2a                	je     6a98 <fwp_rc_share+0x68>
    6a6e:	80 f9 01             	cmp    $0x1,%cl
    6a71:	75 1e                	jne    6a91 <fwp_rc_share+0x61>
    6a73:	8b 48 18             	mov    0x18(%rax),%ecx
    6a76:	0f b7 ff             	movzwl %di,%edi
    6a79:	8b 40 1c             	mov    0x1c(%rax),%eax
    6a7c:	48 0f af f9          	imul   %rcx,%rdi
    6a80:	48 c1 ef 20          	shr    $0x20,%rdi
    6a84:	48 39 c7             	cmp    %rax,%rdi
    6a87:	73 08                	jae    6a91 <fwp_rc_share+0x61>
    6a89:	48 01 fa             	add    %rdi,%rdx
    6a8c:	80 3a 00             	cmpb   $0x0,(%rdx)
    6a8f:	75 0d                	jne    6a9e <fwp_rc_share+0x6e>
    6a91:	c3                   	ret
    6a92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a98:	66 85 ff             	test   %di,%di
    6a9b:	74 ef                	je     6a8c <fwp_rc_share+0x5c>
    6a9d:	c3                   	ret
    6a9e:	50                   	push   %rax
    6a9f:	48 8d 3d da 9f 00 00 	lea    0x9fda(%rip),%rdi        # 10a80 <_IO_stdin_used+0xa80>
    6aa6:	e8 a5 d9 ff ff       	call   4450 <fwp_trap>
    6aab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006ab0 <fwp_rc_fresh>:
    6ab0:	48 8b 15 61 71 06 00 	mov    0x67161(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    6ab7:	48 89 f8             	mov    %rdi,%rax
    6aba:	48 89 fe             	mov    %rdi,%rsi
    6abd:	48 2b 05 2c 71 06 00 	sub    0x6712c(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    6ac4:	48 c1 e2 10          	shl    $0x10,%rdx
    6ac8:	48 39 d0             	cmp    %rdx,%rax
    6acb:	73 4f                	jae    6b1c <fwp_rc_fresh+0x6c>
    6acd:	48 89 c2             	mov    %rax,%rdx
    6ad0:	48 c1 ea 10          	shr    $0x10,%rdx
    6ad4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ad8:	48 8b 15 59 71 06 00 	mov    0x67159(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    6adf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ae3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ae7:	48 85 d2             	test   %rdx,%rdx
    6aea:	74 30                	je     6b1c <fwp_rc_fresh+0x6c>
    6aec:	0f b6 39             	movzbl (%rcx),%edi
    6aef:	40 80 ff 02          	cmp    $0x2,%dil
    6af3:	74 2b                	je     6b20 <fwp_rc_fresh+0x70>
    6af5:	40 80 ff 01          	cmp    $0x1,%dil
    6af9:	75 21                	jne    6b1c <fwp_rc_fresh+0x6c>
    6afb:	8b 79 18             	mov    0x18(%rcx),%edi
    6afe:	0f b7 c0             	movzwl %ax,%eax
    6b01:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6b04:	48 0f af c7          	imul   %rdi,%rax
    6b08:	48 c1 e8 20          	shr    $0x20,%rax
    6b0c:	48 39 c8             	cmp    %rcx,%rax
    6b0f:	73 0b                	jae    6b1c <fwp_rc_fresh+0x6c>
    6b11:	48 01 c2             	add    %rax,%rdx
    6b14:	80 3a ff             	cmpb   $0xff,(%rdx)
    6b17:	74 17                	je     6b30 <fwp_rc_fresh+0x80>
    6b19:	c6 02 01             	movb   $0x1,(%rdx)
    6b1c:	48 89 f0             	mov    %rsi,%rax
    6b1f:	c3                   	ret
    6b20:	66 85 c0             	test   %ax,%ax
    6b23:	74 ef                	je     6b14 <fwp_rc_fresh+0x64>
    6b25:	48 89 f0             	mov    %rsi,%rax
    6b28:	c3                   	ret
    6b29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b30:	48 83 ec 18          	sub    $0x18,%rsp
    6b34:	48 89 d7             	mov    %rdx,%rdi
    6b37:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6b3c:	48 89 14 24          	mov    %rdx,(%rsp)
    6b40:	e8 8b ec ff ff       	call   57d0 <fwp_rc_forget_slot>
    6b45:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6b4a:	48 8b 14 24          	mov    (%rsp),%rdx
    6b4e:	48 89 f0             	mov    %rsi,%rax
    6b51:	c6 02 01             	movb   $0x1,(%rdx)
    6b54:	48 83 c4 18          	add    $0x18,%rsp
    6b58:	c3                   	ret
    6b59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006b60 <fwp_rc_free_arr>:
    6b60:	48 8b 15 b1 70 06 00 	mov    0x670b1(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    6b67:	48 89 f8             	mov    %rdi,%rax
    6b6a:	48 2b 05 7f 70 06 00 	sub    0x6707f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    6b71:	48 c1 e2 10          	shl    $0x10,%rdx
    6b75:	48 39 d0             	cmp    %rdx,%rax
    6b78:	73 5b                	jae    6bd5 <fwp_rc_free_arr+0x75>
    6b7a:	48 89 c2             	mov    %rax,%rdx
    6b7d:	48 c1 ea 10          	shr    $0x10,%rdx
    6b81:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b85:	48 8b 15 ac 70 06 00 	mov    0x670ac(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    6b8c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6b90:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6b94:	48 85 c9             	test   %rcx,%rcx
    6b97:	74 3c                	je     6bd5 <fwp_rc_free_arr+0x75>
    6b99:	0f b6 32             	movzbl (%rdx),%esi
    6b9c:	40 80 fe 02          	cmp    $0x2,%sil
    6ba0:	74 2e                	je     6bd0 <fwp_rc_free_arr+0x70>
    6ba2:	40 80 fe 01          	cmp    $0x1,%sil
    6ba6:	75 2d                	jne    6bd5 <fwp_rc_free_arr+0x75>
    6ba8:	8b 72 18             	mov    0x18(%rdx),%esi
    6bab:	0f b7 c0             	movzwl %ax,%eax
    6bae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6bb1:	48 0f af c6          	imul   %rsi,%rax
    6bb5:	48 c1 e8 20          	shr    $0x20,%rax
    6bb9:	48 39 d0             	cmp    %rdx,%rax
    6bbc:	73 17                	jae    6bd5 <fwp_rc_free_arr+0x75>
    6bbe:	48 01 c1             	add    %rax,%rcx
    6bc1:	80 39 01             	cmpb   $0x1,(%rcx)
    6bc4:	75 0f                	jne    6bd5 <fwp_rc_free_arr+0x75>
    6bc6:	e9 45 ee ff ff       	jmp    5a10 <fwp_mem_free>
    6bcb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6bd0:	66 85 c0             	test   %ax,%ax
    6bd3:	74 ec                	je     6bc1 <fwp_rc_free_arr+0x61>
    6bd5:	c3                   	ret
    6bd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bdd:	00 00 00 

0000000000006be0 <fwp_rc_dup>:
    6be0:	f3 0f 1e fa          	endbr64
    6be4:	48 8b 05 2d 70 06 00 	mov    0x6702d(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    6beb:	48 2b 3d fe 6f 06 00 	sub    0x66ffe(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    6bf2:	48 c1 e0 10          	shl    $0x10,%rax
    6bf6:	48 39 c7             	cmp    %rax,%rdi
    6bf9:	73 60                	jae    6c5b <fwp_rc_dup+0x7b>
    6bfb:	48 89 f8             	mov    %rdi,%rax
    6bfe:	48 c1 e8 10          	shr    $0x10,%rax
    6c02:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6c06:	48 8b 05 2b 70 06 00 	mov    0x6702b(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    6c0d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6c11:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6c15:	48 85 c0             	test   %rax,%rax
    6c18:	74 41                	je     6c5b <fwp_rc_dup+0x7b>
    6c1a:	0f b6 0a             	movzbl (%rdx),%ecx
    6c1d:	80 f9 02             	cmp    $0x2,%cl
    6c20:	74 3e                	je     6c60 <fwp_rc_dup+0x80>
    6c22:	80 f9 01             	cmp    $0x1,%cl
    6c25:	75 34                	jne    6c5b <fwp_rc_dup+0x7b>
    6c27:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6c2a:	0f b7 ff             	movzwl %di,%edi
    6c2d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6c30:	48 0f af f9          	imul   %rcx,%rdi
    6c34:	48 c1 ef 20          	shr    $0x20,%rdi
    6c38:	48 39 d7             	cmp    %rdx,%rdi
    6c3b:	73 1e                	jae    6c5b <fwp_rc_dup+0x7b>
    6c3d:	48 01 f8             	add    %rdi,%rax
    6c40:	0f b6 10             	movzbl (%rax),%edx
    6c43:	84 d2                	test   %dl,%dl
    6c45:	74 14                	je     6c5b <fwp_rc_dup+0x7b>
    6c47:	8b 0d bb 78 06 00    	mov    0x678bb(%rip),%ecx        # 6e508 <iteration_active>
    6c4d:	85 c9                	test   %ecx,%ecx
    6c4f:	75 1f                	jne    6c70 <fwp_rc_dup+0x90>
    6c51:	80 fa fd             	cmp    $0xfd,%dl
    6c54:	77 2a                	ja     6c80 <fwp_rc_dup+0xa0>
    6c56:	83 c2 01             	add    $0x1,%edx
    6c59:	88 10                	mov    %dl,(%rax)
    6c5b:	c3                   	ret
    6c5c:	0f 1f 40 00          	nopl   0x0(%rax)
    6c60:	66 85 ff             	test   %di,%di
    6c63:	74 db                	je     6c40 <fwp_rc_dup+0x60>
    6c65:	c3                   	ret
    6c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c6d:	00 00 00 
    6c70:	48 83 05 78 78 06 00 	addq   $0x1,0x67878(%rip)        # 6e4f0 <iteration_retains>
    6c77:	01 
    6c78:	eb d7                	jmp    6c51 <fwp_rc_dup+0x71>
    6c7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c80:	48 89 c7             	mov    %rax,%rdi
    6c83:	e9 28 ea ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    6c88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6c8f:	00 

0000000000006c90 <fwp_owned_entry161>:
    6c90:	f3 0f 1e fa          	endbr64
    6c94:	48 83 ec 38          	sub    $0x38,%rsp
    6c98:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6c9d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6ca4:	00 00 
    6ca6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6cab:	31 c0                	xor    %eax,%eax
    6cad:	48 8b 07             	mov    (%rdi),%rax
    6cb0:	48 03 47 10          	add    0x10(%rdi),%rax
    6cb4:	0f 80 c2 00 00 00    	jo     6d7c <fwp_owned_entry161+0xec>
    6cba:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6cbf:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6cc4:	31 ff                	xor    %edi,%edi
    6cc6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6cca:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6ccf:	e8 6c fb ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    6cd4:	48 8b 15 3d 6f 06 00 	mov    0x66f3d(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    6cdb:	48 89 c6             	mov    %rax,%rsi
    6cde:	48 2b 05 0b 6f 06 00 	sub    0x66f0b(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    6ce5:	48 c1 e2 10          	shl    $0x10,%rdx
    6ce9:	48 39 d0             	cmp    %rdx,%rax
    6cec:	73 4f                	jae    6d3d <fwp_owned_entry161+0xad>
    6cee:	48 89 c2             	mov    %rax,%rdx
    6cf1:	48 c1 ea 10          	shr    $0x10,%rdx
    6cf5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6cf9:	48 8b 15 38 6f 06 00 	mov    0x66f38(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    6d00:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6d04:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d08:	48 85 d2             	test   %rdx,%rdx
    6d0b:	74 30                	je     6d3d <fwp_owned_entry161+0xad>
    6d0d:	0f b6 39             	movzbl (%rcx),%edi
    6d10:	40 80 ff 02          	cmp    $0x2,%dil
    6d14:	74 42                	je     6d58 <fwp_owned_entry161+0xc8>
    6d16:	40 80 ff 01          	cmp    $0x1,%dil
    6d1a:	75 21                	jne    6d3d <fwp_owned_entry161+0xad>
    6d1c:	8b 79 18             	mov    0x18(%rcx),%edi
    6d1f:	0f b7 c0             	movzwl %ax,%eax
    6d22:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6d25:	48 0f af c7          	imul   %rdi,%rax
    6d29:	48 c1 e8 20          	shr    $0x20,%rax
    6d2d:	48 39 c8             	cmp    %rcx,%rax
    6d30:	73 0b                	jae    6d3d <fwp_owned_entry161+0xad>
    6d32:	48 01 c2             	add    %rax,%rdx
    6d35:	80 3a ff             	cmpb   $0xff,(%rdx)
    6d38:	74 26                	je     6d60 <fwp_owned_entry161+0xd0>
    6d3a:	c6 02 01             	movb   $0x1,(%rdx)
    6d3d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6d42:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6d49:	00 00 
    6d4b:	75 34                	jne    6d81 <fwp_owned_entry161+0xf1>
    6d4d:	48 89 f0             	mov    %rsi,%rax
    6d50:	48 83 c4 38          	add    $0x38,%rsp
    6d54:	c3                   	ret
    6d55:	0f 1f 00             	nopl   (%rax)
    6d58:	66 85 c0             	test   %ax,%ax
    6d5b:	75 e0                	jne    6d3d <fwp_owned_entry161+0xad>
    6d5d:	eb d6                	jmp    6d35 <fwp_owned_entry161+0xa5>
    6d5f:	90                   	nop
    6d60:	48 89 d7             	mov    %rdx,%rdi
    6d63:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6d68:	48 89 14 24          	mov    %rdx,(%rsp)
    6d6c:	e8 5f ea ff ff       	call   57d0 <fwp_rc_forget_slot>
    6d71:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6d76:	48 8b 14 24          	mov    (%rsp),%rdx
    6d7a:	eb be                	jmp    6d3a <fwp_owned_entry161+0xaa>
    6d7c:	e8 7f c9 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6d81:	e8 ca c6 ff ff       	call   3450 <__stack_chk_fail@plt>
    6d86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d8d:	00 00 00 

0000000000006d90 <e161>:
    6d90:	f3 0f 1e fa          	endbr64
    6d94:	53                   	push   %rbx
    6d95:	48 83 ec 30          	sub    $0x30,%rsp
    6d99:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6d9e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6da5:	00 00 
    6da7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6dac:	31 c0                	xor    %eax,%eax
    6dae:	48 8b 07             	mov    (%rdi),%rax
    6db1:	48 03 47 10          	add    0x10(%rdi),%rax
    6db5:	0f 80 c9 00 00 00    	jo     6e84 <e161+0xf4>
    6dbb:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6dc0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6dc5:	31 ff                	xor    %edi,%edi
    6dc7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6dcb:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6dd0:	e8 6b fa ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    6dd5:	48 8b 15 3c 6e 06 00 	mov    0x66e3c(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    6ddc:	48 89 c3             	mov    %rax,%rbx
    6ddf:	48 2b 05 0a 6e 06 00 	sub    0x66e0a(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    6de6:	48 c1 e2 10          	shl    $0x10,%rdx
    6dea:	48 39 d0             	cmp    %rdx,%rax
    6ded:	73 4f                	jae    6e3e <e161+0xae>
    6def:	48 89 c2             	mov    %rax,%rdx
    6df2:	48 c1 ea 10          	shr    $0x10,%rdx
    6df6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6dfa:	48 8b 15 37 6e 06 00 	mov    0x66e37(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    6e01:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6e05:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6e09:	48 85 d2             	test   %rdx,%rdx
    6e0c:	74 30                	je     6e3e <e161+0xae>
    6e0e:	0f b6 31             	movzbl (%rcx),%esi
    6e11:	40 80 fe 02          	cmp    $0x2,%sil
    6e15:	74 49                	je     6e60 <e161+0xd0>
    6e17:	40 80 fe 01          	cmp    $0x1,%sil
    6e1b:	75 21                	jne    6e3e <e161+0xae>
    6e1d:	8b 71 18             	mov    0x18(%rcx),%esi
    6e20:	0f b7 c0             	movzwl %ax,%eax
    6e23:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6e26:	48 0f af c6          	imul   %rsi,%rax
    6e2a:	48 c1 e8 20          	shr    $0x20,%rax
    6e2e:	48 39 c8             	cmp    %rcx,%rax
    6e31:	73 0b                	jae    6e3e <e161+0xae>
    6e33:	48 01 c2             	add    %rax,%rdx
    6e36:	80 3a ff             	cmpb   $0xff,(%rdx)
    6e39:	74 35                	je     6e70 <e161+0xe0>
    6e3b:	c6 02 01             	movb   $0x1,(%rdx)
    6e3e:	48 89 df             	mov    %rbx,%rdi
    6e41:	e8 ea fb ff ff       	call   6a30 <fwp_rc_share>
    6e46:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6e4b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6e52:	00 00 
    6e54:	75 33                	jne    6e89 <e161+0xf9>
    6e56:	48 83 c4 30          	add    $0x30,%rsp
    6e5a:	48 89 d8             	mov    %rbx,%rax
    6e5d:	5b                   	pop    %rbx
    6e5e:	c3                   	ret
    6e5f:	90                   	nop
    6e60:	66 85 c0             	test   %ax,%ax
    6e63:	75 d9                	jne    6e3e <e161+0xae>
    6e65:	eb cf                	jmp    6e36 <e161+0xa6>
    6e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6e6e:	00 00 
    6e70:	48 89 d7             	mov    %rdx,%rdi
    6e73:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6e78:	e8 53 e9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    6e7d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6e82:	eb b7                	jmp    6e3b <e161+0xab>
    6e84:	e8 77 c8 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6e89:	e8 c2 c5 ff ff       	call   3450 <__stack_chk_fail@plt>
    6e8e:	66 90                	xchg   %ax,%ax

0000000000006e90 <fwp_drop0>:
    6e90:	f3 0f 1e fa          	endbr64
    6e94:	48 8b 15 7d 6d 06 00 	mov    0x66d7d(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    6e9b:	48 89 f8             	mov    %rdi,%rax
    6e9e:	48 2b 05 4b 6d 06 00 	sub    0x66d4b(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    6ea5:	48 c1 e2 10          	shl    $0x10,%rdx
    6ea9:	48 39 d0             	cmp    %rdx,%rax
    6eac:	0f 83 be 00 00 00    	jae    6f70 <fwp_drop0+0xe0>
    6eb2:	48 83 ec 18          	sub    $0x18,%rsp
    6eb6:	4c 8d 05 83 59 06 00 	lea    0x65983(%rip),%r8        # 6c840 <fwp_heap>
    6ebd:	48 89 c2             	mov    %rax,%rdx
    6ec0:	48 c1 ea 10          	shr    $0x10,%rdx
    6ec4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ec8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6ecf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ed3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ed7:	48 85 d2             	test   %rdx,%rdx
    6eda:	74 3c                	je     6f18 <fwp_drop0+0x88>
    6edc:	0f b6 31             	movzbl (%rcx),%esi
    6edf:	40 80 fe 02          	cmp    $0x2,%sil
    6ee3:	74 3b                	je     6f20 <fwp_drop0+0x90>
    6ee5:	40 80 fe 01          	cmp    $0x1,%sil
    6ee9:	75 2d                	jne    6f18 <fwp_drop0+0x88>
    6eeb:	8b 71 18             	mov    0x18(%rcx),%esi
    6eee:	0f b7 c0             	movzwl %ax,%eax
    6ef1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ef4:	48 0f af c6          	imul   %rsi,%rax
    6ef8:	48 c1 e8 20          	shr    $0x20,%rax
    6efc:	48 39 c8             	cmp    %rcx,%rax
    6eff:	73 17                	jae    6f18 <fwp_drop0+0x88>
    6f01:	48 01 c2             	add    %rax,%rdx
    6f04:	0f b6 02             	movzbl (%rdx),%eax
    6f07:	84 c0                	test   %al,%al
    6f09:	74 0d                	je     6f18 <fwp_drop0+0x88>
    6f0b:	3c 01                	cmp    $0x1,%al
    6f0d:	74 21                	je     6f30 <fwp_drop0+0xa0>
    6f0f:	3c ff                	cmp    $0xff,%al
    6f11:	74 65                	je     6f78 <fwp_drop0+0xe8>
    6f13:	83 e8 01             	sub    $0x1,%eax
    6f16:	88 02                	mov    %al,(%rdx)
    6f18:	48 83 c4 18          	add    $0x18,%rsp
    6f1c:	c3                   	ret
    6f1d:	0f 1f 00             	nopl   (%rax)
    6f20:	66 85 c0             	test   %ax,%ax
    6f23:	74 df                	je     6f04 <fwp_drop0+0x74>
    6f25:	48 83 c4 18          	add    $0x18,%rsp
    6f29:	c3                   	ret
    6f2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f30:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6f34:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6f39:	e8 22 fc ff ff       	call   6b60 <fwp_rc_free_arr>
    6f3e:	4c 8d 05 fb 58 06 00 	lea    0x658fb(%rip),%r8        # 6c840 <fwp_heap>
    6f45:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6f4a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6f51:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6f58:	48 c1 e2 10          	shl    $0x10,%rdx
    6f5c:	48 39 d0             	cmp    %rdx,%rax
    6f5f:	73 b7                	jae    6f18 <fwp_drop0+0x88>
    6f61:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6f66:	e9 52 ff ff ff       	jmp    6ebd <fwp_drop0+0x2d>
    6f6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6f70:	c3                   	ret
    6f71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f78:	48 89 d0             	mov    %rdx,%rax
    6f7b:	48 c1 e8 11          	shr    $0x11,%rax
    6f7f:	48 31 d0             	xor    %rdx,%rax
    6f82:	48 89 c1             	mov    %rax,%rcx
    6f85:	48 c1 e9 09          	shr    $0x9,%rcx
    6f89:	48 31 c8             	xor    %rcx,%rax
    6f8c:	0f b6 c8             	movzbl %al,%ecx
    6f8f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6f96:	00 
    6f97:	48 85 c0             	test   %rax,%rax
    6f9a:	75 0d                	jne    6fa9 <fwp_drop0+0x119>
    6f9c:	eb 46                	jmp    6fe4 <fwp_drop0+0x154>
    6f9e:	66 90                	xchg   %ax,%ax
    6fa0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6fa4:	48 85 c0             	test   %rax,%rax
    6fa7:	74 3b                	je     6fe4 <fwp_drop0+0x154>
    6fa9:	48 89 c1             	mov    %rax,%rcx
    6fac:	48 39 10             	cmp    %rdx,(%rax)
    6faf:	75 ef                	jne    6fa0 <fwp_drop0+0x110>
    6fb1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6fb5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6fb9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6fbd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6fc4:	0f 85 4e ff ff ff    	jne    6f18 <fwp_drop0+0x88>
    6fca:	48 89 d7             	mov    %rdx,%rdi
    6fcd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6fd2:	e8 f9 e7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    6fd7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6fdc:	c6 02 fe             	movb   $0xfe,(%rdx)
    6fdf:	e9 34 ff ff ff       	jmp    6f18 <fwp_drop0+0x88>
    6fe4:	48 8d 3d f5 99 00 00 	lea    0x99f5(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    6feb:	e8 60 d4 ff ff       	call   4450 <fwp_trap>

0000000000006ff0 <fwp_arg_drop12>:
    6ff0:	f3 0f 1e fa          	endbr64
    6ff4:	85 f6                	test   %esi,%esi
    6ff6:	75 04                	jne    6ffc <fwp_arg_drop12+0xc>
    6ff8:	85 d2                	test   %edx,%edx
    6ffa:	75 04                	jne    7000 <fwp_arg_drop12+0x10>
    6ffc:	c3                   	ret
    6ffd:	0f 1f 00             	nopl   (%rax)
    7000:	48 8b 3f             	mov    (%rdi),%rdi
    7003:	e9 88 fe ff ff       	jmp    6e90 <fwp_drop0>
    7008:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    700f:	00 

0000000000007010 <fwp_drop1>:
    7010:	f3 0f 1e fa          	endbr64
    7014:	48 8b 15 fd 6b 06 00 	mov    0x66bfd(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    701b:	48 89 f8             	mov    %rdi,%rax
    701e:	48 2b 05 cb 6b 06 00 	sub    0x66bcb(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7025:	48 c1 e2 10          	shl    $0x10,%rdx
    7029:	48 39 d0             	cmp    %rdx,%rax
    702c:	0f 83 be 00 00 00    	jae    70f0 <fwp_drop1+0xe0>
    7032:	48 83 ec 18          	sub    $0x18,%rsp
    7036:	4c 8d 05 03 58 06 00 	lea    0x65803(%rip),%r8        # 6c840 <fwp_heap>
    703d:	48 89 c2             	mov    %rax,%rdx
    7040:	48 c1 ea 10          	shr    $0x10,%rdx
    7044:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7048:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    704f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7053:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7057:	48 85 d2             	test   %rdx,%rdx
    705a:	74 3c                	je     7098 <fwp_drop1+0x88>
    705c:	0f b6 31             	movzbl (%rcx),%esi
    705f:	40 80 fe 02          	cmp    $0x2,%sil
    7063:	74 3b                	je     70a0 <fwp_drop1+0x90>
    7065:	40 80 fe 01          	cmp    $0x1,%sil
    7069:	75 2d                	jne    7098 <fwp_drop1+0x88>
    706b:	8b 71 18             	mov    0x18(%rcx),%esi
    706e:	0f b7 c0             	movzwl %ax,%eax
    7071:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7074:	48 0f af c6          	imul   %rsi,%rax
    7078:	48 c1 e8 20          	shr    $0x20,%rax
    707c:	48 39 c8             	cmp    %rcx,%rax
    707f:	73 17                	jae    7098 <fwp_drop1+0x88>
    7081:	48 01 c2             	add    %rax,%rdx
    7084:	0f b6 02             	movzbl (%rdx),%eax
    7087:	84 c0                	test   %al,%al
    7089:	74 0d                	je     7098 <fwp_drop1+0x88>
    708b:	3c 01                	cmp    $0x1,%al
    708d:	74 21                	je     70b0 <fwp_drop1+0xa0>
    708f:	3c ff                	cmp    $0xff,%al
    7091:	74 65                	je     70f8 <fwp_drop1+0xe8>
    7093:	83 e8 01             	sub    $0x1,%eax
    7096:	88 02                	mov    %al,(%rdx)
    7098:	48 83 c4 18          	add    $0x18,%rsp
    709c:	c3                   	ret
    709d:	0f 1f 00             	nopl   (%rax)
    70a0:	66 85 c0             	test   %ax,%ax
    70a3:	74 df                	je     7084 <fwp_drop1+0x74>
    70a5:	48 83 c4 18          	add    $0x18,%rsp
    70a9:	c3                   	ret
    70aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    70b0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    70b4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    70b9:	e8 a2 fa ff ff       	call   6b60 <fwp_rc_free_arr>
    70be:	4c 8d 05 7b 57 06 00 	lea    0x6577b(%rip),%r8        # 6c840 <fwp_heap>
    70c5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    70ca:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    70d1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    70d8:	48 c1 e2 10          	shl    $0x10,%rdx
    70dc:	48 39 d0             	cmp    %rdx,%rax
    70df:	73 b7                	jae    7098 <fwp_drop1+0x88>
    70e1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    70e6:	e9 52 ff ff ff       	jmp    703d <fwp_drop1+0x2d>
    70eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    70f0:	c3                   	ret
    70f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    70f8:	48 89 d0             	mov    %rdx,%rax
    70fb:	48 c1 e8 11          	shr    $0x11,%rax
    70ff:	48 31 d0             	xor    %rdx,%rax
    7102:	48 89 c1             	mov    %rax,%rcx
    7105:	48 c1 e9 09          	shr    $0x9,%rcx
    7109:	48 31 c8             	xor    %rcx,%rax
    710c:	0f b6 c8             	movzbl %al,%ecx
    710f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7116:	00 
    7117:	48 85 c0             	test   %rax,%rax
    711a:	75 0d                	jne    7129 <fwp_drop1+0x119>
    711c:	eb 46                	jmp    7164 <fwp_drop1+0x154>
    711e:	66 90                	xchg   %ax,%ax
    7120:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7124:	48 85 c0             	test   %rax,%rax
    7127:	74 3b                	je     7164 <fwp_drop1+0x154>
    7129:	48 89 c1             	mov    %rax,%rcx
    712c:	48 39 10             	cmp    %rdx,(%rax)
    712f:	75 ef                	jne    7120 <fwp_drop1+0x110>
    7131:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7135:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7139:	48 89 48 08          	mov    %rcx,0x8(%rax)
    713d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7144:	0f 85 4e ff ff ff    	jne    7098 <fwp_drop1+0x88>
    714a:	48 89 d7             	mov    %rdx,%rdi
    714d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7152:	e8 79 e6 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7157:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    715c:	c6 02 fe             	movb   $0xfe,(%rdx)
    715f:	e9 34 ff ff ff       	jmp    7098 <fwp_drop1+0x88>
    7164:	48 8d 3d 75 98 00 00 	lea    0x9875(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    716b:	e8 e0 d2 ff ff       	call   4450 <fwp_trap>

0000000000007170 <fwp_closure_drop>:
    7170:	48 8b 15 a1 6a 06 00 	mov    0x66aa1(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    7177:	48 89 f8             	mov    %rdi,%rax
    717a:	48 2b 05 6f 6a 06 00 	sub    0x66a6f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7181:	48 c1 e2 10          	shl    $0x10,%rdx
    7185:	48 39 d0             	cmp    %rdx,%rax
    7188:	73 6b                	jae    71f5 <fwp_closure_drop+0x85>
    718a:	48 89 c2             	mov    %rax,%rdx
    718d:	48 c1 ea 10          	shr    $0x10,%rdx
    7191:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7195:	48 8b 15 9c 6a 06 00 	mov    0x66a9c(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    719c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    71a0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    71a4:	48 85 d2             	test   %rdx,%rdx
    71a7:	74 4c                	je     71f5 <fwp_closure_drop+0x85>
    71a9:	0f b6 31             	movzbl (%rcx),%esi
    71ac:	40 80 fe 02          	cmp    $0x2,%sil
    71b0:	74 3e                	je     71f0 <fwp_closure_drop+0x80>
    71b2:	40 80 fe 01          	cmp    $0x1,%sil
    71b6:	75 3d                	jne    71f5 <fwp_closure_drop+0x85>
    71b8:	8b 71 18             	mov    0x18(%rcx),%esi
    71bb:	0f b7 c0             	movzwl %ax,%eax
    71be:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    71c1:	48 0f af c6          	imul   %rsi,%rax
    71c5:	48 c1 e8 20          	shr    $0x20,%rax
    71c9:	48 39 c8             	cmp    %rcx,%rax
    71cc:	73 27                	jae    71f5 <fwp_closure_drop+0x85>
    71ce:	48 01 c2             	add    %rax,%rdx
    71d1:	0f b6 02             	movzbl (%rdx),%eax
    71d4:	84 c0                	test   %al,%al
    71d6:	74 1d                	je     71f5 <fwp_closure_drop+0x85>
    71d8:	3c 01                	cmp    $0x1,%al
    71da:	74 24                	je     7200 <fwp_closure_drop+0x90>
    71dc:	3c ff                	cmp    $0xff,%al
    71de:	74 48                	je     7228 <fwp_closure_drop+0xb8>
    71e0:	83 e8 01             	sub    $0x1,%eax
    71e3:	88 02                	mov    %al,(%rdx)
    71e5:	c3                   	ret
    71e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    71ed:	00 00 00 
    71f0:	66 85 c0             	test   %ax,%ax
    71f3:	74 dc                	je     71d1 <fwp_closure_drop+0x61>
    71f5:	c3                   	ret
    71f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    71fd:	00 00 00 
    7200:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    7207:	ff ff 
    7209:	48 85 c0             	test   %rax,%rax
    720c:	74 12                	je     7220 <fwp_closure_drop+0xb0>
    720e:	48 89 fe             	mov    %rdi,%rsi
    7211:	48 89 c7             	mov    %rax,%rdi
    7214:	e9 97 d2 ff ff       	jmp    44b0 <fwp_closure_drop_push>
    7219:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7220:	e9 3b d4 ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    7225:	0f 1f 00             	nopl   (%rax)
    7228:	48 89 d0             	mov    %rdx,%rax
    722b:	48 8d 35 0e 56 06 00 	lea    0x6560e(%rip),%rsi        # 6c840 <fwp_heap>
    7232:	48 83 ec 18          	sub    $0x18,%rsp
    7236:	48 c1 e8 11          	shr    $0x11,%rax
    723a:	48 31 d0             	xor    %rdx,%rax
    723d:	48 89 c1             	mov    %rax,%rcx
    7240:	48 c1 e9 09          	shr    $0x9,%rcx
    7244:	48 31 c8             	xor    %rcx,%rax
    7247:	0f b6 c8             	movzbl %al,%ecx
    724a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7251:	00 
    7252:	48 85 c0             	test   %rax,%rax
    7255:	75 12                	jne    7269 <fwp_closure_drop+0xf9>
    7257:	eb 49                	jmp    72a2 <fwp_closure_drop+0x132>
    7259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7260:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7264:	48 85 c0             	test   %rax,%rax
    7267:	74 39                	je     72a2 <fwp_closure_drop+0x132>
    7269:	48 89 c1             	mov    %rax,%rcx
    726c:	48 39 10             	cmp    %rdx,(%rax)
    726f:	75 ef                	jne    7260 <fwp_closure_drop+0xf0>
    7271:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7275:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7279:	48 89 48 08          	mov    %rcx,0x8(%rax)
    727d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7284:	74 05                	je     728b <fwp_closure_drop+0x11b>
    7286:	48 83 c4 18          	add    $0x18,%rsp
    728a:	c3                   	ret
    728b:	48 89 d7             	mov    %rdx,%rdi
    728e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7293:	e8 38 e5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7298:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    729d:	c6 02 fe             	movb   $0xfe,(%rdx)
    72a0:	eb e4                	jmp    7286 <fwp_closure_drop+0x116>
    72a2:	48 8d 3d 37 97 00 00 	lea    0x9737(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    72a9:	e8 a2 d1 ff ff       	call   4450 <fwp_trap>
    72ae:	66 90                	xchg   %ax,%ax

00000000000072b0 <fwp_owned_tape_release>:
    72b0:	48 85 ff             	test   %rdi,%rdi
    72b3:	0f 84 f7 00 00 00    	je     73b0 <fwp_owned_tape_release+0x100>
    72b9:	41 54                	push   %r12
    72bb:	55                   	push   %rbp
    72bc:	53                   	push   %rbx
    72bd:	48 8b 07             	mov    (%rdi),%rax
    72c0:	48 85 c0             	test   %rax,%rax
    72c3:	74 08                	je     72cd <fwp_owned_tape_release+0x1d>
    72c5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    72c9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    72cd:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    72d1:	48 85 d2             	test   %rdx,%rdx
    72d4:	74 03                	je     72d9 <fwp_owned_tape_release+0x29>
    72d6:	48 89 02             	mov    %rax,(%rdx)
    72d9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    72dd:	48 89 fb             	mov    %rdi,%rbx
    72e0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    72e4:	48 85 c0             	test   %rax,%rax
    72e7:	0f 84 89 00 00 00    	je     7376 <fwp_owned_tape_release+0xc6>
    72ed:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    72f1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    72f5:	7e 47                	jle    733e <fwp_owned_tape_release+0x8e>
    72f7:	31 ed                	xor    %ebp,%ebp
    72f9:	eb 0d                	jmp    7308 <fwp_owned_tape_release+0x58>
    72fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7300:	48 8b 43 10          	mov    0x10(%rbx),%rax
    7304:	48 8b 40 68          	mov    0x68(%rax),%rax
    7308:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    730c:	49 89 ec             	mov    %rbp,%r12
    730f:	48 83 c5 01          	add    $0x1,%rbp
    7313:	49 c1 e4 04          	shl    $0x4,%r12
    7317:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    731b:	ff d0                	call   *%rax
    731d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    7321:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    7326:	48 8b 43 10          	mov    0x10(%rbx),%rax
    732a:	ff 50 68             	call   *0x68(%rax)
    732d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    7331:	48 2b 43 50          	sub    0x50(%rbx),%rax
    7335:	48 39 e8             	cmp    %rbp,%rax
    7338:	7f c6                	jg     7300 <fwp_owned_tape_release+0x50>
    733a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    733e:	31 ed                	xor    %ebp,%ebp
    7340:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    7345:	7e 28                	jle    736f <fwp_owned_tape_release+0xbf>
    7347:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    734e:	00 00 
    7350:	48 8b 43 48          	mov    0x48(%rbx),%rax
    7354:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    7358:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    735c:	74 07                	je     7365 <fwp_owned_tape_release+0xb5>
    735e:	ff 52 68             	call   *0x68(%rdx)
    7361:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    7365:	48 83 c5 01          	add    $0x1,%rbp
    7369:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    736d:	7f e1                	jg     7350 <fwp_owned_tape_release+0xa0>
    736f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7373:	ff 52 68             	call   *0x68(%rdx)
    7376:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    737a:	e8 f1 fd ff ff       	call   7170 <fwp_closure_drop>
    737f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    7383:	e8 e8 fd ff ff       	call   7170 <fwp_closure_drop>
    7388:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    738c:	e8 df fd ff ff       	call   7170 <fwp_closure_drop>
    7391:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    7395:	e8 76 e6 ff ff       	call   5a10 <fwp_mem_free>
    739a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    739e:	e8 6d e6 ff ff       	call   5a10 <fwp_mem_free>
    73a3:	48 89 df             	mov    %rbx,%rdi
    73a6:	5b                   	pop    %rbx
    73a7:	5d                   	pop    %rbp
    73a8:	41 5c                	pop    %r12
    73aa:	e9 61 e6 ff ff       	jmp    5a10 <fwp_mem_free>
    73af:	90                   	nop
    73b0:	c3                   	ret
    73b1:	0f 1f 40 00          	nopl   0x0(%rax)
    73b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    73bc:	00 00 00 00 

00000000000073c0 <fwp_tape_finish>:
    73c0:	f3 0f 1e fa          	endbr64
    73c4:	41 55                	push   %r13
    73c6:	41 54                	push   %r12
    73c8:	55                   	push   %rbp
    73c9:	53                   	push   %rbx
    73ca:	48 83 ec 48          	sub    $0x48,%rsp
    73ce:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    73d5:	00 00 
    73d7:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    73dc:	48 8d 3d dd cc 01 00 	lea    0x1ccdd(%rip),%rdi        # 240c0 <fwp_tape_workspace>
    73e3:	e8 58 dd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    73e8:	48 83 3d 18 cd 01 00 	cmpq   $0x0,0x1cd18(%rip)        # 24108 <fwp_ntapes>
    73ef:	00 
    73f0:	48 c7 05 ad cc 01 00 	movq   $0x0,0x1ccad(%rip)        # 240a8 <fwp_tape_cached_bytes>
    73f7:	00 00 00 00 
    73fb:	7e 79                	jle    7476 <fwp_tape_finish+0xb6>
    73fd:	45 31 e4             	xor    %r12d,%r12d
    7400:	31 ed                	xor    %ebp,%ebp
    7402:	0f 1f 00             	nopl   (%rax)
    7405:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    740c:	00 00 00 00 
    7410:	48 8b 1d f9 cc 01 00 	mov    0x1ccf9(%rip),%rbx        # 24110 <fwp_tapes>
    7417:	48 83 c5 01          	add    $0x1,%rbp
    741b:	4c 01 e3             	add    %r12,%rbx
    741e:	49 83 c4 68          	add    $0x68,%r12
    7422:	48 89 df             	mov    %rbx,%rdi
    7425:	e8 66 c8 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    742a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    742f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    7434:	48 89 e7             	mov    %rsp,%rdi
    7437:	48 8b 43 40          	mov    0x40(%rbx),%rax
    743b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    743f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    7444:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7449:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    744e:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    7452:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7457:	e8 e4 dc ff ff       	call   5140 <fwp_tape_buffers_dispose>
    745c:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    7460:	e8 4b fe ff ff       	call   72b0 <fwp_owned_tape_release>
    7465:	48 39 2d 9c cc 01 00 	cmp    %rbp,0x1cc9c(%rip)        # 24108 <fwp_ntapes>
    746c:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    7473:	00 
    7474:	7f 9a                	jg     7410 <fwp_tape_finish+0x50>
    7476:	48 8b 3d 93 cc 01 00 	mov    0x1cc93(%rip),%rdi        # 24110 <fwp_tapes>
    747d:	48 85 ff             	test   %rdi,%rdi
    7480:	74 05                	je     7487 <fwp_tape_finish+0xc7>
    7482:	e8 49 dc ff ff       	call   50d0 <ad_raw_free.part.0>
    7487:	48 c7 05 7e cc 01 00 	movq   $0x0,0x1cc7e(%rip)        # 24110 <fwp_tapes>
    748e:	00 00 00 00 
    7492:	48 c7 05 63 cc 01 00 	movq   $0x0,0x1cc63(%rip)        # 24100 <fwp_tapes_cap>
    7499:	00 00 00 00 
    749d:	48 c7 05 60 cc 01 00 	movq   $0x0,0x1cc60(%rip)        # 24108 <fwp_ntapes>
    74a4:	00 00 00 00 
    74a8:	48 c7 05 45 cc 01 00 	movq   $0x0,0x1cc45(%rip)        # 240f8 <fwp_tape_next_slot>
    74af:	00 00 00 00 
    74b3:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    74b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    74bf:	00 00 
    74c1:	75 0b                	jne    74ce <fwp_tape_finish+0x10e>
    74c3:	48 83 c4 48          	add    $0x48,%rsp
    74c7:	5b                   	pop    %rbx
    74c8:	5d                   	pop    %rbp
    74c9:	41 5c                	pop    %r12
    74cb:	41 5d                	pop    %r13
    74cd:	c3                   	ret
    74ce:	e8 7d bf ff ff       	call   3450 <__stack_chk_fail@plt>
    74d3:	66 90                	xchg   %ax,%ax
    74d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74dc:	00 00 00 00 

00000000000074e0 <fwp_tape_scope_release>:
    74e0:	f3 0f 1e fa          	endbr64
    74e4:	41 55                	push   %r13
    74e6:	41 54                	push   %r12
    74e8:	55                   	push   %rbp
    74e9:	53                   	push   %rbx
    74ea:	48 83 ec 48          	sub    $0x48,%rsp
    74ee:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    74f5:	00 00 
    74f7:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    74fc:	48 63 07             	movslq (%rdi),%rax
    74ff:	85 c0                	test   %eax,%eax
    7501:	0f 88 e8 00 00 00    	js     75ef <fwp_tape_scope_release+0x10f>
    7507:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    750e:	ec c4 4e 
    7511:	48 89 fb             	mov    %rdi,%rbx
    7514:	48 89 e5             	mov    %rsp,%rbp
    7517:	eb 1f                	jmp    7538 <fwp_tape_scope_release+0x58>
    7519:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7520:	e8 1b dc ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7525:	4c 89 ef             	mov    %r13,%rdi
    7528:	e8 83 fd ff ff       	call   72b0 <fwp_owned_tape_release>
    752d:	48 63 03             	movslq (%rbx),%rax
    7530:	85 c0                	test   %eax,%eax
    7532:	0f 88 b7 00 00 00    	js     75ef <fwp_tape_scope_release+0x10f>
    7538:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    753c:	48 8b 35 cd cb 01 00 	mov    0x1cbcd(%rip),%rsi        # 24110 <fwp_tapes>
    7543:	4c 01 c6             	add    %r8,%rsi
    7546:	48 89 f7             	mov    %rsi,%rdi
    7549:	e8 42 c7 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    754e:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7553:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    7558:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    755f:	48 8b 46 40          	mov    0x40(%rsi),%rax
    7563:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    7567:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    756e:	00 
    756f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7574:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    7579:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    757d:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7582:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7586:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    758b:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7592:	00 
    7593:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    759a:	00 
    759b:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    75a2:	00 
    75a3:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    75a7:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    75ab:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    75af:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    75b3:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    75b9:	77 18                	ja     75d3 <fwp_tape_scope_release+0xf3>
    75bb:	49 c1 f8 03          	sar    $0x3,%r8
    75bf:	4d 0f af c4          	imul   %r12,%r8
    75c3:	4c 3b 05 2e cb 01 00 	cmp    0x1cb2e(%rip),%r8        # 240f8 <fwp_tape_next_slot>
    75ca:	7d 07                	jge    75d3 <fwp_tape_scope_release+0xf3>
    75cc:	4c 89 05 25 cb 01 00 	mov    %r8,0x1cb25(%rip)        # 240f8 <fwp_tape_next_slot>
    75d3:	48 89 ef             	mov    %rbp,%rdi
    75d6:	4d 85 ed             	test   %r13,%r13
    75d9:	0f 85 41 ff ff ff    	jne    7520 <fwp_tape_scope_release+0x40>
    75df:	e8 7c dc ff ff       	call   5260 <fwp_tape_buffers_release>
    75e4:	48 63 03             	movslq (%rbx),%rax
    75e7:	85 c0                	test   %eax,%eax
    75e9:	0f 89 49 ff ff ff    	jns    7538 <fwp_tape_scope_release+0x58>
    75ef:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    75f4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    75fb:	00 00 
    75fd:	75 0b                	jne    760a <fwp_tape_scope_release+0x12a>
    75ff:	48 83 c4 48          	add    $0x48,%rsp
    7603:	5b                   	pop    %rbx
    7604:	5d                   	pop    %rbp
    7605:	41 5c                	pop    %r12
    7607:	41 5d                	pop    %r13
    7609:	c3                   	ret
    760a:	e8 41 be ff ff       	call   3450 <__stack_chk_fail@plt>
    760f:	90                   	nop

0000000000007610 <fwp_task_dispose>:
    7610:	53                   	push   %rbx
    7611:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7615:	0f 84 2b c1 ff ff    	je     3746 <fwp_task_dispose.cold>
    761b:	48 89 fb             	mov    %rdi,%rbx
    761e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7623:	0f 85 1d c1 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7629:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    762d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7634:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    763b:	00 
    763c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7640:	48 85 ff             	test   %rdi,%rdi
    7643:	74 07                	je     764c <fwp_task_dispose+0x3c>
    7645:	48 85 c0             	test   %rax,%rax
    7648:	74 02                	je     764c <fwp_task_dispose+0x3c>
    764a:	ff d0                	call   *%rax
    764c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7653:	e8 b8 e3 ff ff       	call   5a10 <fwp_mem_free>
    7658:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    765f:	00 00 00 00 
    7663:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7667:	74 6f                	je     76d8 <fwp_task_dispose+0xc8>
    7669:	48 8b 15 a8 65 06 00 	mov    0x665a8(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    7670:	48 89 d8             	mov    %rbx,%rax
    7673:	48 2b 05 76 65 06 00 	sub    0x66576(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    767a:	48 c1 e2 10          	shl    $0x10,%rdx
    767e:	48 39 d0             	cmp    %rdx,%rax
    7681:	73 4c                	jae    76cf <fwp_task_dispose+0xbf>
    7683:	48 89 c2             	mov    %rax,%rdx
    7686:	48 c1 ea 10          	shr    $0x10,%rdx
    768a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    768e:	48 8b 15 a3 65 06 00 	mov    0x665a3(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    7695:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7699:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    769d:	48 85 c9             	test   %rcx,%rcx
    76a0:	74 2d                	je     76cf <fwp_task_dispose+0xbf>
    76a2:	0f b6 32             	movzbl (%rdx),%esi
    76a5:	40 80 fe 02          	cmp    $0x2,%sil
    76a9:	74 3d                	je     76e8 <fwp_task_dispose+0xd8>
    76ab:	40 80 fe 01          	cmp    $0x1,%sil
    76af:	75 1e                	jne    76cf <fwp_task_dispose+0xbf>
    76b1:	8b 72 18             	mov    0x18(%rdx),%esi
    76b4:	0f b7 c0             	movzwl %ax,%eax
    76b7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    76ba:	48 0f af c6          	imul   %rsi,%rax
    76be:	48 c1 e8 20          	shr    $0x20,%rax
    76c2:	48 39 d0             	cmp    %rdx,%rax
    76c5:	73 08                	jae    76cf <fwp_task_dispose+0xbf>
    76c7:	48 01 c1             	add    %rax,%rcx
    76ca:	80 39 01             	cmpb   $0x1,(%rcx)
    76cd:	74 09                	je     76d8 <fwp_task_dispose+0xc8>
    76cf:	5b                   	pop    %rbx
    76d0:	c3                   	ret
    76d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76d8:	48 89 df             	mov    %rbx,%rdi
    76db:	5b                   	pop    %rbx
    76dc:	e9 2f e3 ff ff       	jmp    5a10 <fwp_mem_free>
    76e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76e8:	66 85 c0             	test   %ax,%ax
    76eb:	74 dd                	je     76ca <fwp_task_dispose+0xba>
    76ed:	5b                   	pop    %rbx
    76ee:	c3                   	ret
    76ef:	90                   	nop

00000000000076f0 <fwp_free_zombie>:
    76f0:	48 8b 15 19 51 06 00 	mov    0x65119(%rip),%rdx        # 6c810 <fwp_zombie>
    76f7:	48 85 d2             	test   %rdx,%rdx
    76fa:	0f 84 98 00 00 00    	je     7798 <fwp_free_zombie+0xa8>
    7700:	48 3b 15 19 51 06 00 	cmp    0x65119(%rip),%rdx        # 6c820 <fwp_cur>
    7707:	0f 84 8b 00 00 00    	je     7798 <fwp_free_zombie+0xa8>
    770d:	48 83 ec 18          	sub    $0x18,%rsp
    7711:	48 63 05 dc 4a 06 00 	movslq 0x64adc(%rip),%rax        # 6c1f4 <fwp_stack_pool_n>
    7718:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    771c:	83 f8 3f             	cmp    $0x3f,%eax
    771f:	7f 7f                	jg     77a0 <fwp_free_zombie+0xb0>
    7721:	8d 48 01             	lea    0x1(%rax),%ecx
    7724:	89 0d ca 4a 06 00    	mov    %ecx,0x64aca(%rip)        # 6c1f4 <fwp_stack_pool_n>
    772a:	48 8d 0d cf 4a 06 00 	lea    0x64acf(%rip),%rcx        # 6c200 <fwp_stack_pool>
    7731:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7735:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    773c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7740:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7747:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    774b:	48 85 c9             	test   %rcx,%rcx
    774e:	0f 84 fc 00 00 00    	je     7850 <fwp_free_zombie+0x160>
    7754:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    775b:	48 85 c0             	test   %rax,%rax
    775e:	74 07                	je     7767 <fwp_free_zombie+0x77>
    7760:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7767:	8b 42 5c             	mov    0x5c(%rdx),%eax
    776a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    776e:	48 c7 05 97 50 06 00 	movq   $0x0,0x65097(%rip)        # 6c810 <fwp_zombie>
    7775:	00 00 00 00 
    7779:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7780:	85 c0                	test   %eax,%eax
    7782:	74 34                	je     77b8 <fwp_free_zombie+0xc8>
    7784:	83 f8 01             	cmp    $0x1,%eax
    7787:	0f 84 b3 00 00 00    	je     7840 <fwp_free_zombie+0x150>
    778d:	48 83 c4 18          	add    $0x18,%rsp
    7791:	c3                   	ret
    7792:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7798:	c3                   	ret
    7799:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    77a0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    77a4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    77a9:	e8 12 be ff ff       	call   35c0 <munmap@plt>
    77ae:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    77b3:	eb 80                	jmp    7735 <fwp_free_zombie+0x45>
    77b5:	0f 1f 00             	nopl   (%rax)
    77b8:	48 8b 0d 59 64 06 00 	mov    0x66459(%rip),%rcx        # 6dc18 <fwp_heap+0x13d8>
    77bf:	48 89 d0             	mov    %rdx,%rax
    77c2:	48 2b 05 27 64 06 00 	sub    0x66427(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    77c9:	48 c1 e1 10          	shl    $0x10,%rcx
    77cd:	48 39 c8             	cmp    %rcx,%rax
    77d0:	73 bb                	jae    778d <fwp_free_zombie+0x9d>
    77d2:	48 89 c1             	mov    %rax,%rcx
    77d5:	48 c1 e9 10          	shr    $0x10,%rcx
    77d9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    77dd:	48 8b 0d 54 64 06 00 	mov    0x66454(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    77e4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    77e8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    77ec:	48 85 c9             	test   %rcx,%rcx
    77ef:	74 9c                	je     778d <fwp_free_zombie+0x9d>
    77f1:	0f b6 3e             	movzbl (%rsi),%edi
    77f4:	40 80 ff 02          	cmp    $0x2,%dil
    77f8:	74 66                	je     7860 <fwp_free_zombie+0x170>
    77fa:	40 80 ff 01          	cmp    $0x1,%dil
    77fe:	75 8d                	jne    778d <fwp_free_zombie+0x9d>
    7800:	8b 7e 18             	mov    0x18(%rsi),%edi
    7803:	0f b7 c0             	movzwl %ax,%eax
    7806:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7809:	48 0f af c7          	imul   %rdi,%rax
    780d:	48 c1 e8 20          	shr    $0x20,%rax
    7811:	48 39 f0             	cmp    %rsi,%rax
    7814:	0f 83 73 ff ff ff    	jae    778d <fwp_free_zombie+0x9d>
    781a:	48 01 c1             	add    %rax,%rcx
    781d:	0f b6 01             	movzbl (%rcx),%eax
    7820:	84 c0                	test   %al,%al
    7822:	0f 84 65 ff ff ff    	je     778d <fwp_free_zombie+0x9d>
    7828:	3c 01                	cmp    $0x1,%al
    782a:	74 14                	je     7840 <fwp_free_zombie+0x150>
    782c:	3c ff                	cmp    $0xff,%al
    782e:	74 3b                	je     786b <fwp_free_zombie+0x17b>
    7830:	83 e8 01             	sub    $0x1,%eax
    7833:	88 01                	mov    %al,(%rcx)
    7835:	e9 53 ff ff ff       	jmp    778d <fwp_free_zombie+0x9d>
    783a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7840:	48 89 d7             	mov    %rdx,%rdi
    7843:	48 83 c4 18          	add    $0x18,%rsp
    7847:	e9 c4 fd ff ff       	jmp    7610 <fwp_task_dispose>
    784c:	0f 1f 40 00          	nopl   0x0(%rax)
    7850:	48 89 05 91 4f 06 00 	mov    %rax,0x64f91(%rip)        # 6c7e8 <fwp_tasks_active>
    7857:	e9 ff fe ff ff       	jmp    775b <fwp_free_zombie+0x6b>
    785c:	0f 1f 40 00          	nopl   0x0(%rax)
    7860:	66 85 c0             	test   %ax,%ax
    7863:	0f 85 24 ff ff ff    	jne    778d <fwp_free_zombie+0x9d>
    7869:	eb b2                	jmp    781d <fwp_free_zombie+0x12d>
    786b:	48 89 ca             	mov    %rcx,%rdx
    786e:	48 8d 35 cb 4f 06 00 	lea    0x64fcb(%rip),%rsi        # 6c840 <fwp_heap>
    7875:	48 c1 ea 11          	shr    $0x11,%rdx
    7879:	48 31 ca             	xor    %rcx,%rdx
    787c:	48 89 d0             	mov    %rdx,%rax
    787f:	48 c1 e8 09          	shr    $0x9,%rax
    7883:	48 31 c2             	xor    %rax,%rdx
    7886:	0f b6 d2             	movzbl %dl,%edx
    7889:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7890:	00 
    7891:	48 85 c0             	test   %rax,%rax
    7894:	75 13                	jne    78a9 <fwp_free_zombie+0x1b9>
    7896:	eb 4c                	jmp    78e4 <fwp_free_zombie+0x1f4>
    7898:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    789f:	00 
    78a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    78a4:	48 85 c0             	test   %rax,%rax
    78a7:	74 3b                	je     78e4 <fwp_free_zombie+0x1f4>
    78a9:	48 89 c2             	mov    %rax,%rdx
    78ac:	48 39 08             	cmp    %rcx,(%rax)
    78af:	75 ef                	jne    78a0 <fwp_free_zombie+0x1b0>
    78b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    78b5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    78b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    78bd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    78c4:	0f 85 c3 fe ff ff    	jne    778d <fwp_free_zombie+0x9d>
    78ca:	48 89 cf             	mov    %rcx,%rdi
    78cd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    78d2:	e8 f9 de ff ff       	call   57d0 <fwp_rc_forget_slot>
    78d7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    78dc:	c6 01 fe             	movb   $0xfe,(%rcx)
    78df:	e9 a9 fe ff ff       	jmp    778d <fwp_free_zombie+0x9d>
    78e4:	48 8d 3d f5 90 00 00 	lea    0x90f5(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    78eb:	e8 60 cb ff ff       	call   4450 <fwp_trap>

00000000000078f0 <fwp_block>:
    78f0:	48 83 ec 08          	sub    $0x8,%rsp
    78f4:	48 8b 05 0d 4f 06 00 	mov    0x64f0d(%rip),%rax        # 6c808 <fwp_ready_head>
    78fb:	48 85 c0             	test   %rax,%rax
    78fe:	0f 84 1c 01 00 00    	je     7a20 <fwp_block+0x130>
    7904:	90                   	nop
    7905:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    790c:	00 00 00 00 
    7910:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7917:	48 89 15 ea 4e 06 00 	mov    %rdx,0x64eea(%rip)        # 6c808 <fwp_ready_head>
    791e:	48 85 d2             	test   %rdx,%rdx
    7921:	0f 84 19 01 00 00    	je     7a40 <fwp_block+0x150>
    7927:	48 8b 15 f2 4e 06 00 	mov    0x64ef2(%rip),%rdx        # 6c820 <fwp_cur>
    792e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7932:	48 39 c2             	cmp    %rax,%rdx
    7935:	0f 84 d5 00 00 00    	je     7a10 <fwp_block+0x120>
    793b:	48 8b 0d 66 6b 06 00 	mov    0x66b66(%rip),%rcx        # 6e4a8 <fwp_state_owners>
    7942:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7946:	48 89 05 d3 4e 06 00 	mov    %rax,0x64ed3(%rip)        # 6c820 <fwp_cur>
    794d:	f3 0f 7e 05 7b 6b 06 	movq   0x66b7b(%rip),%xmm0        # 6e4d0 <fwp_foreign_callbacks>
    7954:	00 
    7955:	0f 16 05 64 6b 06 00 	movhps 0x66b64(%rip),%xmm0        # 6e4c0 <fwp_state>
    795c:	f3 0f 7e 0d 64 6b 06 	movq   0x66b64(%rip),%xmm1        # 6e4c8 <fwp_handlers>
    7963:	00 
    7964:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    796b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7972:	0f 16 0d 5f 6b 06 00 	movhps 0x66b5f(%rip),%xmm1        # 6e4d8 <fwp_cleanups>
    7979:	f3 0f 7e 05 37 6b 06 	movq   0x66b37(%rip),%xmm0        # 6e4b8 <fwp_state_len>
    7980:	00 
    7981:	0f 16 05 28 6b 06 00 	movhps 0x66b28(%rip),%xmm0        # 6e4b0 <fwp_state_cap>
    7988:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    798f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7996:	48 8b 70 08          	mov    0x8(%rax),%rsi
    799a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    79a1:	48 89 0d 20 6b 06 00 	mov    %rcx,0x66b20(%rip)        # 6e4c8 <fwp_handlers>
    79a8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    79af:	48 89 0d 22 6b 06 00 	mov    %rcx,0x66b22(%rip)        # 6e4d8 <fwp_cleanups>
    79b6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    79bd:	48 89 0d 0c 6b 06 00 	mov    %rcx,0x66b0c(%rip)        # 6e4d0 <fwp_foreign_callbacks>
    79c4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    79cb:	48 89 0d ee 6a 06 00 	mov    %rcx,0x66aee(%rip)        # 6e4c0 <fwp_state>
    79d2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    79d9:	48 89 0d d8 6a 06 00 	mov    %rcx,0x66ad8(%rip)        # 6e4b8 <fwp_state_len>
    79e0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    79e7:	48 89 0d c2 6a 06 00 	mov    %rcx,0x66ac2(%rip)        # 6e4b0 <fwp_state_cap>
    79ee:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    79f5:	48 89 0d ac 6a 06 00 	mov    %rcx,0x66aac(%rip)        # 6e4a8 <fwp_state_owners>
    79fc:	e8 7f ba ff ff       	call   3480 <swapcontext@plt>
    7a01:	f3 0f 1e fa          	endbr64
    7a05:	e8 e6 fc ff ff       	call   76f0 <fwp_free_zombie>
    7a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a10:	8b 05 da 47 06 00    	mov    0x647da(%rip),%eax        # 6c1f0 <fwp_slice>
    7a16:	85 c0                	test   %eax,%eax
    7a18:	74 36                	je     7a50 <fwp_block+0x160>
    7a1a:	48 83 c4 08          	add    $0x8,%rsp
    7a1e:	c3                   	ret
    7a1f:	90                   	nop
    7a20:	e8 eb d9 ff ff       	call   5410 <fwp_poll_events>
    7a25:	48 8b 05 dc 4d 06 00 	mov    0x64ddc(%rip),%rax        # 6c808 <fwp_ready_head>
    7a2c:	48 85 c0             	test   %rax,%rax
    7a2f:	0f 85 db fe ff ff    	jne    7910 <fwp_block+0x20>
    7a35:	eb e9                	jmp    7a20 <fwp_block+0x130>
    7a37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a3e:	00 00 
    7a40:	48 c7 05 b5 4d 06 00 	movq   $0x0,0x64db5(%rip)        # 6c800 <fwp_ready_tail>
    7a47:	00 00 00 00 
    7a4b:	e9 d7 fe ff ff       	jmp    7927 <fwp_block+0x37>
    7a50:	48 8d 3d 88 87 00 00 	lea    0x8788(%rip),%rdi        # 101df <_IO_stdin_used+0x1df>
    7a57:	e8 34 b9 ff ff       	call   3390 <getenv@plt>
    7a5c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7a61:	48 85 c0             	test   %rax,%rax
    7a64:	74 05                	je     7a6b <fwp_block+0x17b>
    7a66:	80 38 00             	cmpb   $0x0,(%rax)
    7a69:	75 0b                	jne    7a76 <fwp_block+0x186>
    7a6b:	89 15 7f 47 06 00    	mov    %edx,0x6477f(%rip)        # 6c1f0 <fwp_slice>
    7a71:	48 83 c4 08          	add    $0x8,%rsp
    7a75:	c3                   	ret
    7a76:	ba 0a 00 00 00       	mov    $0xa,%edx
    7a7b:	31 f6                	xor    %esi,%esi
    7a7d:	48 89 c7             	mov    %rax,%rdi
    7a80:	e8 bb ba ff ff       	call   3540 <strtoll@plt>
    7a85:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7a89:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7a90:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7a95:	0f 46 d0             	cmovbe %eax,%edx
    7a98:	eb d1                	jmp    7a6b <fwp_block+0x17b>
    7a9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007aa0 <fwp_drop4>:
    7aa0:	48 8b 15 71 61 06 00 	mov    0x66171(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    7aa7:	48 89 f8             	mov    %rdi,%rax
    7aaa:	48 2b 05 3f 61 06 00 	sub    0x6613f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7ab1:	48 c1 e2 10          	shl    $0x10,%rdx
    7ab5:	48 39 d0             	cmp    %rdx,%rax
    7ab8:	0f 83 52 01 00 00    	jae    7c10 <fwp_drop4+0x170>
    7abe:	48 83 ec 18          	sub    $0x18,%rsp
    7ac2:	4c 8d 05 77 4d 06 00 	lea    0x64d77(%rip),%r8        # 6c840 <fwp_heap>
    7ac9:	48 89 c2             	mov    %rax,%rdx
    7acc:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7ad3:	48 c1 ea 10          	shr    $0x10,%rdx
    7ad7:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7adb:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    7adf:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7ae3:	48 85 d2             	test   %rdx,%rdx
    7ae6:	74 46                	je     7b2e <fwp_drop4+0x8e>
    7ae8:	44 0f b6 09          	movzbl (%rcx),%r9d
    7aec:	41 80 f9 02          	cmp    $0x2,%r9b
    7af0:	0f 84 ca 00 00 00    	je     7bc0 <fwp_drop4+0x120>
    7af6:	41 80 f9 01          	cmp    $0x1,%r9b
    7afa:	75 32                	jne    7b2e <fwp_drop4+0x8e>
    7afc:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7b00:	0f b7 c0             	movzwl %ax,%eax
    7b03:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7b06:	49 0f af c1          	imul   %r9,%rax
    7b0a:	48 c1 e8 20          	shr    $0x20,%rax
    7b0e:	48 39 c8             	cmp    %rcx,%rax
    7b11:	73 1b                	jae    7b2e <fwp_drop4+0x8e>
    7b13:	48 01 c2             	add    %rax,%rdx
    7b16:	0f b6 02             	movzbl (%rdx),%eax
    7b19:	84 c0                	test   %al,%al
    7b1b:	74 11                	je     7b2e <fwp_drop4+0x8e>
    7b1d:	3c 01                	cmp    $0x1,%al
    7b1f:	74 17                	je     7b38 <fwp_drop4+0x98>
    7b21:	3c ff                	cmp    $0xff,%al
    7b23:	0f 84 ef 00 00 00    	je     7c18 <fwp_drop4+0x178>
    7b29:	83 e8 01             	sub    $0x1,%eax
    7b2c:	88 02                	mov    %al,(%rdx)
    7b2e:	48 83 c4 18          	add    $0x18,%rsp
    7b32:	c3                   	ret
    7b33:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7b38:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    7b3c:	0f 88 8e 00 00 00    	js     7bd0 <fwp_drop4+0x130>
    7b42:	48 8b 15 cf 60 06 00 	mov    0x660cf(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    7b49:	48 89 f8             	mov    %rdi,%rax
    7b4c:	48 2b 05 9d 60 06 00 	sub    0x6609d(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7b53:	48 c1 e2 10          	shl    $0x10,%rdx
    7b57:	48 39 d0             	cmp    %rdx,%rax
    7b5a:	73 d2                	jae    7b2e <fwp_drop4+0x8e>
    7b5c:	48 89 c2             	mov    %rax,%rdx
    7b5f:	48 c1 ea 10          	shr    $0x10,%rdx
    7b63:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7b67:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    7b6b:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7b6f:	48 85 c9             	test   %rcx,%rcx
    7b72:	74 ba                	je     7b2e <fwp_drop4+0x8e>
    7b74:	0f b6 32             	movzbl (%rdx),%esi
    7b77:	40 80 fe 02          	cmp    $0x2,%sil
    7b7b:	74 33                	je     7bb0 <fwp_drop4+0x110>
    7b7d:	40 80 fe 01          	cmp    $0x1,%sil
    7b81:	75 ab                	jne    7b2e <fwp_drop4+0x8e>
    7b83:	8b 72 18             	mov    0x18(%rdx),%esi
    7b86:	0f b7 c0             	movzwl %ax,%eax
    7b89:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b8c:	48 0f af c6          	imul   %rsi,%rax
    7b90:	48 c1 e8 20          	shr    $0x20,%rax
    7b94:	48 39 d0             	cmp    %rdx,%rax
    7b97:	73 95                	jae    7b2e <fwp_drop4+0x8e>
    7b99:	48 01 c1             	add    %rax,%rcx
    7b9c:	80 39 01             	cmpb   $0x1,(%rcx)
    7b9f:	75 8d                	jne    7b2e <fwp_drop4+0x8e>
    7ba1:	48 83 c4 18          	add    $0x18,%rsp
    7ba5:	e9 66 de ff ff       	jmp    5a10 <fwp_mem_free>
    7baa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7bb0:	66 85 c0             	test   %ax,%ax
    7bb3:	74 e7                	je     7b9c <fwp_drop4+0xfc>
    7bb5:	48 83 c4 18          	add    $0x18,%rsp
    7bb9:	c3                   	ret
    7bba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7bc0:	66 85 c0             	test   %ax,%ax
    7bc3:	0f 84 4d ff ff ff    	je     7b16 <fwp_drop4+0x76>
    7bc9:	48 83 c4 18          	add    $0x18,%rsp
    7bcd:	c3                   	ret
    7bce:	66 90                	xchg   %ax,%ax
    7bd0:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7bd4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7bd9:	e8 82 ef ff ff       	call   6b60 <fwp_rc_free_arr>
    7bde:	4c 8d 05 5b 4c 06 00 	lea    0x64c5b(%rip),%r8        # 6c840 <fwp_heap>
    7be5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7bea:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7bf1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7bf8:	48 c1 e2 10          	shl    $0x10,%rdx
    7bfc:	48 39 d0             	cmp    %rdx,%rax
    7bff:	0f 83 29 ff ff ff    	jae    7b2e <fwp_drop4+0x8e>
    7c05:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7c0a:	e9 ba fe ff ff       	jmp    7ac9 <fwp_drop4+0x29>
    7c0f:	90                   	nop
    7c10:	c3                   	ret
    7c11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c18:	48 89 d0             	mov    %rdx,%rax
    7c1b:	48 c1 e8 11          	shr    $0x11,%rax
    7c1f:	48 31 d0             	xor    %rdx,%rax
    7c22:	48 89 c1             	mov    %rax,%rcx
    7c25:	48 c1 e9 09          	shr    $0x9,%rcx
    7c29:	48 31 c8             	xor    %rcx,%rax
    7c2c:	0f b6 c8             	movzbl %al,%ecx
    7c2f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7c36:	00 
    7c37:	48 85 c0             	test   %rax,%rax
    7c3a:	75 0d                	jne    7c49 <fwp_drop4+0x1a9>
    7c3c:	eb 46                	jmp    7c84 <fwp_drop4+0x1e4>
    7c3e:	66 90                	xchg   %ax,%ax
    7c40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7c44:	48 85 c0             	test   %rax,%rax
    7c47:	74 3b                	je     7c84 <fwp_drop4+0x1e4>
    7c49:	48 89 c1             	mov    %rax,%rcx
    7c4c:	48 39 10             	cmp    %rdx,(%rax)
    7c4f:	75 ef                	jne    7c40 <fwp_drop4+0x1a0>
    7c51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7c55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7c59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7c5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7c64:	0f 85 c4 fe ff ff    	jne    7b2e <fwp_drop4+0x8e>
    7c6a:	48 89 d7             	mov    %rdx,%rdi
    7c6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7c72:	e8 59 db ff ff       	call   57d0 <fwp_rc_forget_slot>
    7c77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7c7c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7c7f:	e9 aa fe ff ff       	jmp    7b2e <fwp_drop4+0x8e>
    7c84:	48 8d 3d 55 8d 00 00 	lea    0x8d55(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    7c8b:	e8 c0 c7 ff ff       	call   4450 <fwp_trap>

0000000000007c90 <fwp_caps161>:
    7c90:	f3 0f 1e fa          	endbr64
    7c94:	85 f6                	test   %esi,%esi
    7c96:	74 08                	je     7ca0 <fwp_caps161+0x10>
    7c98:	c3                   	ret
    7c99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ca0:	48 8b 15 71 5f 06 00 	mov    0x65f71(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    7ca7:	48 89 f8             	mov    %rdi,%rax
    7caa:	48 2b 05 3f 5f 06 00 	sub    0x65f3f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7cb1:	48 c1 e2 10          	shl    $0x10,%rdx
    7cb5:	48 39 d0             	cmp    %rdx,%rax
    7cb8:	73 de                	jae    7c98 <fwp_caps161+0x8>
    7cba:	48 89 c2             	mov    %rax,%rdx
    7cbd:	48 c1 ea 10          	shr    $0x10,%rdx
    7cc1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7cc5:	48 8b 15 6c 5f 06 00 	mov    0x65f6c(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    7ccc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7cd0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7cd4:	48 85 c9             	test   %rcx,%rcx
    7cd7:	74 bf                	je     7c98 <fwp_caps161+0x8>
    7cd9:	0f b6 32             	movzbl (%rdx),%esi
    7cdc:	40 80 fe 02          	cmp    $0x2,%sil
    7ce0:	74 2e                	je     7d10 <fwp_caps161+0x80>
    7ce2:	40 80 fe 01          	cmp    $0x1,%sil
    7ce6:	75 b0                	jne    7c98 <fwp_caps161+0x8>
    7ce8:	8b 72 18             	mov    0x18(%rdx),%esi
    7ceb:	0f b7 c0             	movzwl %ax,%eax
    7cee:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7cf1:	48 0f af c6          	imul   %rsi,%rax
    7cf5:	48 c1 e8 20          	shr    $0x20,%rax
    7cf9:	48 39 d0             	cmp    %rdx,%rax
    7cfc:	73 9a                	jae    7c98 <fwp_caps161+0x8>
    7cfe:	48 01 c1             	add    %rax,%rcx
    7d01:	80 39 01             	cmpb   $0x1,(%rcx)
    7d04:	75 92                	jne    7c98 <fwp_caps161+0x8>
    7d06:	e9 05 dd ff ff       	jmp    5a10 <fwp_mem_free>
    7d0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7d10:	66 85 c0             	test   %ax,%ax
    7d13:	74 ec                	je     7d01 <fwp_caps161+0x71>
    7d15:	c3                   	ret
    7d16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7d1d:	00 00 00 

0000000000007d20 <fwp_drop2>:
    7d20:	48 8b 0d f1 5e 06 00 	mov    0x65ef1(%rip),%rcx        # 6dc18 <fwp_heap+0x13d8>
    7d27:	48 89 f8             	mov    %rdi,%rax
    7d2a:	48 2b 05 bf 5e 06 00 	sub    0x65ebf(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7d31:	48 c1 e1 10          	shl    $0x10,%rcx
    7d35:	48 39 c8             	cmp    %rcx,%rax
    7d38:	0f 83 42 01 00 00    	jae    7e80 <fwp_drop2+0x160>
    7d3e:	48 83 ec 18          	sub    $0x18,%rsp
    7d42:	48 89 fa             	mov    %rdi,%rdx
    7d45:	4c 8d 05 f4 4a 06 00 	lea    0x64af4(%rip),%r8        # 6c840 <fwp_heap>
    7d4c:	48 89 c1             	mov    %rax,%rcx
    7d4f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7d56:	48 c1 e9 10          	shr    $0x10,%rcx
    7d5a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7d5e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7d62:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7d66:	48 85 c9             	test   %rcx,%rcx
    7d69:	74 40                	je     7dab <fwp_drop2+0x8b>
    7d6b:	0f b6 3e             	movzbl (%rsi),%edi
    7d6e:	40 80 ff 02          	cmp    $0x2,%dil
    7d72:	74 3c                	je     7db0 <fwp_drop2+0x90>
    7d74:	40 80 ff 01          	cmp    $0x1,%dil
    7d78:	75 31                	jne    7dab <fwp_drop2+0x8b>
    7d7a:	8b 7e 18             	mov    0x18(%rsi),%edi
    7d7d:	0f b7 c0             	movzwl %ax,%eax
    7d80:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7d83:	48 0f af c7          	imul   %rdi,%rax
    7d87:	48 c1 e8 20          	shr    $0x20,%rax
    7d8b:	48 39 f0             	cmp    %rsi,%rax
    7d8e:	73 1b                	jae    7dab <fwp_drop2+0x8b>
    7d90:	48 01 c1             	add    %rax,%rcx
    7d93:	0f b6 01             	movzbl (%rcx),%eax
    7d96:	84 c0                	test   %al,%al
    7d98:	74 11                	je     7dab <fwp_drop2+0x8b>
    7d9a:	3c 01                	cmp    $0x1,%al
    7d9c:	74 22                	je     7dc0 <fwp_drop2+0xa0>
    7d9e:	3c ff                	cmp    $0xff,%al
    7da0:	0f 84 0a 01 00 00    	je     7eb0 <fwp_drop2+0x190>
    7da6:	83 e8 01             	sub    $0x1,%eax
    7da9:	88 01                	mov    %al,(%rcx)
    7dab:	48 83 c4 18          	add    $0x18,%rsp
    7daf:	c3                   	ret
    7db0:	66 85 c0             	test   %ax,%ax
    7db3:	74 de                	je     7d93 <fwp_drop2+0x73>
    7db5:	48 83 c4 18          	add    $0x18,%rsp
    7db9:	c3                   	ret
    7dba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7dc0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7dc4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    7dcb:	48 89 f8             	mov    %rdi,%rax
    7dce:	48 c1 e1 10          	shl    $0x10,%rcx
    7dd2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7dd9:	48 39 c8             	cmp    %rcx,%rax
    7ddc:	73 62                	jae    7e40 <fwp_drop2+0x120>
    7dde:	48 89 c1             	mov    %rax,%rcx
    7de1:	48 c1 e9 10          	shr    $0x10,%rcx
    7de5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7de9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7ded:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7df1:	48 85 c9             	test   %rcx,%rcx
    7df4:	74 4a                	je     7e40 <fwp_drop2+0x120>
    7df6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    7dfa:	41 80 f9 02          	cmp    $0x2,%r9b
    7dfe:	0f 84 9c 00 00 00    	je     7ea0 <fwp_drop2+0x180>
    7e04:	41 80 f9 01          	cmp    $0x1,%r9b
    7e08:	75 36                	jne    7e40 <fwp_drop2+0x120>
    7e0a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    7e0e:	0f b7 c0             	movzwl %ax,%eax
    7e11:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7e14:	49 0f af c1          	imul   %r9,%rax
    7e18:	48 c1 e8 20          	shr    $0x20,%rax
    7e1c:	48 39 f0             	cmp    %rsi,%rax
    7e1f:	73 1f                	jae    7e40 <fwp_drop2+0x120>
    7e21:	48 01 c1             	add    %rax,%rcx
    7e24:	0f b6 01             	movzbl (%rcx),%eax
    7e27:	84 c0                	test   %al,%al
    7e29:	74 15                	je     7e40 <fwp_drop2+0x120>
    7e2b:	3c 01                	cmp    $0x1,%al
    7e2d:	74 59                	je     7e88 <fwp_drop2+0x168>
    7e2f:	3c ff                	cmp    $0xff,%al
    7e31:	0f 84 ef 00 00 00    	je     7f26 <fwp_drop2+0x206>
    7e37:	83 e8 01             	sub    $0x1,%eax
    7e3a:	88 01                	mov    %al,(%rcx)
    7e3c:	0f 1f 40 00          	nopl   0x0(%rax)
    7e40:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7e44:	48 89 d7             	mov    %rdx,%rdi
    7e47:	48 89 0c 24          	mov    %rcx,(%rsp)
    7e4b:	e8 10 ed ff ff       	call   6b60 <fwp_rc_free_arr>
    7e50:	4c 8d 05 e9 49 06 00 	lea    0x649e9(%rip),%r8        # 6c840 <fwp_heap>
    7e57:	48 8b 04 24          	mov    (%rsp),%rax
    7e5b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7e62:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7e69:	48 c1 e2 10          	shl    $0x10,%rdx
    7e6d:	48 39 d0             	cmp    %rdx,%rax
    7e70:	0f 83 35 ff ff ff    	jae    7dab <fwp_drop2+0x8b>
    7e76:	48 8b 14 24          	mov    (%rsp),%rdx
    7e7a:	e9 cd fe ff ff       	jmp    7d4c <fwp_drop2+0x2c>
    7e7f:	90                   	nop
    7e80:	c3                   	ret
    7e81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e88:	48 89 14 24          	mov    %rdx,(%rsp)
    7e8c:	e8 cf ec ff ff       	call   6b60 <fwp_rc_free_arr>
    7e91:	48 8b 14 24          	mov    (%rsp),%rdx
    7e95:	eb a9                	jmp    7e40 <fwp_drop2+0x120>
    7e97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7e9e:	00 00 
    7ea0:	66 85 c0             	test   %ax,%ax
    7ea3:	75 9b                	jne    7e40 <fwp_drop2+0x120>
    7ea5:	e9 7a ff ff ff       	jmp    7e24 <fwp_drop2+0x104>
    7eaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7eb0:	48 89 c8             	mov    %rcx,%rax
    7eb3:	48 c1 e8 11          	shr    $0x11,%rax
    7eb7:	48 31 c8             	xor    %rcx,%rax
    7eba:	48 89 c2             	mov    %rax,%rdx
    7ebd:	48 c1 ea 09          	shr    $0x9,%rdx
    7ec1:	48 31 d0             	xor    %rdx,%rax
    7ec4:	0f b6 d0             	movzbl %al,%edx
    7ec7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    7ece:	00 
    7ecf:	48 85 c0             	test   %rax,%rax
    7ed2:	75 19                	jne    7eed <fwp_drop2+0x1cd>
    7ed4:	e9 d3 00 00 00       	jmp    7fac <fwp_drop2+0x28c>
    7ed9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ee0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7ee4:	48 85 c0             	test   %rax,%rax
    7ee7:	0f 84 bf 00 00 00    	je     7fac <fwp_drop2+0x28c>
    7eed:	48 89 c2             	mov    %rax,%rdx
    7ef0:	48 39 08             	cmp    %rcx,(%rax)
    7ef3:	75 eb                	jne    7ee0 <fwp_drop2+0x1c0>
    7ef5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7ef9:	48 83 ea 01          	sub    $0x1,%rdx
    7efd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7f01:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7f08:	0f 85 9d fe ff ff    	jne    7dab <fwp_drop2+0x8b>
    7f0e:	48 89 cf             	mov    %rcx,%rdi
    7f11:	48 89 0c 24          	mov    %rcx,(%rsp)
    7f15:	e8 b6 d8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7f1a:	48 8b 0c 24          	mov    (%rsp),%rcx
    7f1e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7f21:	e9 85 fe ff ff       	jmp    7dab <fwp_drop2+0x8b>
    7f26:	48 89 ce             	mov    %rcx,%rsi
    7f29:	48 c1 ee 11          	shr    $0x11,%rsi
    7f2d:	48 31 ce             	xor    %rcx,%rsi
    7f30:	48 89 f0             	mov    %rsi,%rax
    7f33:	48 c1 e8 09          	shr    $0x9,%rax
    7f37:	48 31 c6             	xor    %rax,%rsi
    7f3a:	40 0f b6 f6          	movzbl %sil,%esi
    7f3e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7f45:	00 
    7f46:	48 85 c0             	test   %rax,%rax
    7f49:	75 1e                	jne    7f69 <fwp_drop2+0x249>
    7f4b:	eb 5f                	jmp    7fac <fwp_drop2+0x28c>
    7f4d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7f54:	00 
    7f55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7f5c:	00 00 00 00 
    7f60:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7f64:	48 85 c0             	test   %rax,%rax
    7f67:	74 43                	je     7fac <fwp_drop2+0x28c>
    7f69:	48 89 c6             	mov    %rax,%rsi
    7f6c:	48 39 08             	cmp    %rcx,(%rax)
    7f6f:	75 ef                	jne    7f60 <fwp_drop2+0x240>
    7f71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7f75:	48 83 ee 01          	sub    $0x1,%rsi
    7f79:	48 89 70 08          	mov    %rsi,0x8(%rax)
    7f7d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7f84:	0f 85 b6 fe ff ff    	jne    7e40 <fwp_drop2+0x120>
    7f8a:	48 89 cf             	mov    %rcx,%rdi
    7f8d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7f92:	48 89 0c 24          	mov    %rcx,(%rsp)
    7f96:	e8 35 d8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7f9b:	48 8b 0c 24          	mov    (%rsp),%rcx
    7f9f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7fa4:	c6 01 fe             	movb   $0xfe,(%rcx)
    7fa7:	e9 94 fe ff ff       	jmp    7e40 <fwp_drop2+0x120>
    7fac:	48 8d 3d 2d 8a 00 00 	lea    0x8a2d(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    7fb3:	e8 98 c4 ff ff       	call   4450 <fwp_trap>
    7fb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7fbf:	00 

0000000000007fc0 <fwp_arg_drop23>:
    7fc0:	f3 0f 1e fa          	endbr64
    7fc4:	85 f6                	test   %esi,%esi
    7fc6:	75 04                	jne    7fcc <fwp_arg_drop23+0xc>
    7fc8:	85 d2                	test   %edx,%edx
    7fca:	75 04                	jne    7fd0 <fwp_arg_drop23+0x10>
    7fcc:	c3                   	ret
    7fcd:	0f 1f 00             	nopl   (%rax)
    7fd0:	48 8b 3f             	mov    (%rdi),%rdi
    7fd3:	e9 48 fd ff ff       	jmp    7d20 <fwp_drop2>
    7fd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7fdf:	00 

0000000000007fe0 <fwp_args12>:
    7fe0:	f3 0f 1e fa          	endbr64
    7fe4:	85 d2                	test   %edx,%edx
    7fe6:	74 04                	je     7fec <fwp_args12+0xc>
    7fe8:	85 f6                	test   %esi,%esi
    7fea:	74 04                	je     7ff0 <fwp_args12+0x10>
    7fec:	c3                   	ret
    7fed:	0f 1f 00             	nopl   (%rax)
    7ff0:	48 8b 15 21 5c 06 00 	mov    0x65c21(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    7ff7:	48 8b 07             	mov    (%rdi),%rax
    7ffa:	48 2b 05 ef 5b 06 00 	sub    0x65bef(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8001:	48 c1 e2 10          	shl    $0x10,%rdx
    8005:	48 39 d0             	cmp    %rdx,%rax
    8008:	73 e2                	jae    7fec <fwp_args12+0xc>
    800a:	48 89 c2             	mov    %rax,%rdx
    800d:	48 c1 ea 10          	shr    $0x10,%rdx
    8011:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8015:	48 8b 15 1c 5c 06 00 	mov    0x65c1c(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    801c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8020:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8024:	48 85 ff             	test   %rdi,%rdi
    8027:	74 c3                	je     7fec <fwp_args12+0xc>
    8029:	0f b6 0a             	movzbl (%rdx),%ecx
    802c:	80 f9 02             	cmp    $0x2,%cl
    802f:	74 4f                	je     8080 <fwp_args12+0xa0>
    8031:	80 f9 01             	cmp    $0x1,%cl
    8034:	75 b6                	jne    7fec <fwp_args12+0xc>
    8036:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8039:	0f b7 c0             	movzwl %ax,%eax
    803c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    803f:	48 0f af c1          	imul   %rcx,%rax
    8043:	48 c1 e8 20          	shr    $0x20,%rax
    8047:	48 39 d0             	cmp    %rdx,%rax
    804a:	73 a0                	jae    7fec <fwp_args12+0xc>
    804c:	48 01 c7             	add    %rax,%rdi
    804f:	0f b6 07             	movzbl (%rdi),%eax
    8052:	84 c0                	test   %al,%al
    8054:	74 96                	je     7fec <fwp_args12+0xc>
    8056:	8b 15 ac 64 06 00    	mov    0x664ac(%rip),%edx        # 6e508 <iteration_active>
    805c:	85 d2                	test   %edx,%edx
    805e:	75 10                	jne    8070 <fwp_args12+0x90>
    8060:	3c fd                	cmp    $0xfd,%al
    8062:	77 22                	ja     8086 <fwp_args12+0xa6>
    8064:	83 c0 01             	add    $0x1,%eax
    8067:	88 07                	mov    %al,(%rdi)
    8069:	c3                   	ret
    806a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8070:	48 83 05 78 64 06 00 	addq   $0x1,0x66478(%rip)        # 6e4f0 <iteration_retains>
    8077:	01 
    8078:	eb e6                	jmp    8060 <fwp_args12+0x80>
    807a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8080:	66 85 c0             	test   %ax,%ax
    8083:	74 ca                	je     804f <fwp_args12+0x6f>
    8085:	c3                   	ret
    8086:	e9 25 d6 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    808b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000008090 <fwp_args23>:
    8090:	f3 0f 1e fa          	endbr64
    8094:	85 d2                	test   %edx,%edx
    8096:	74 04                	je     809c <fwp_args23+0xc>
    8098:	85 f6                	test   %esi,%esi
    809a:	74 04                	je     80a0 <fwp_args23+0x10>
    809c:	c3                   	ret
    809d:	0f 1f 00             	nopl   (%rax)
    80a0:	48 8b 15 71 5b 06 00 	mov    0x65b71(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    80a7:	48 8b 07             	mov    (%rdi),%rax
    80aa:	48 2b 05 3f 5b 06 00 	sub    0x65b3f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    80b1:	48 c1 e2 10          	shl    $0x10,%rdx
    80b5:	48 39 d0             	cmp    %rdx,%rax
    80b8:	73 e2                	jae    809c <fwp_args23+0xc>
    80ba:	48 89 c2             	mov    %rax,%rdx
    80bd:	48 c1 ea 10          	shr    $0x10,%rdx
    80c1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    80c5:	48 8b 15 6c 5b 06 00 	mov    0x65b6c(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    80cc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    80d0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    80d4:	48 85 ff             	test   %rdi,%rdi
    80d7:	74 c3                	je     809c <fwp_args23+0xc>
    80d9:	0f b6 0a             	movzbl (%rdx),%ecx
    80dc:	80 f9 02             	cmp    $0x2,%cl
    80df:	74 4f                	je     8130 <fwp_args23+0xa0>
    80e1:	80 f9 01             	cmp    $0x1,%cl
    80e4:	75 b6                	jne    809c <fwp_args23+0xc>
    80e6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    80e9:	0f b7 c0             	movzwl %ax,%eax
    80ec:	8b 52 1c             	mov    0x1c(%rdx),%edx
    80ef:	48 0f af c1          	imul   %rcx,%rax
    80f3:	48 c1 e8 20          	shr    $0x20,%rax
    80f7:	48 39 d0             	cmp    %rdx,%rax
    80fa:	73 a0                	jae    809c <fwp_args23+0xc>
    80fc:	48 01 c7             	add    %rax,%rdi
    80ff:	0f b6 07             	movzbl (%rdi),%eax
    8102:	84 c0                	test   %al,%al
    8104:	74 96                	je     809c <fwp_args23+0xc>
    8106:	8b 15 fc 63 06 00    	mov    0x663fc(%rip),%edx        # 6e508 <iteration_active>
    810c:	85 d2                	test   %edx,%edx
    810e:	75 10                	jne    8120 <fwp_args23+0x90>
    8110:	3c fd                	cmp    $0xfd,%al
    8112:	77 22                	ja     8136 <fwp_args23+0xa6>
    8114:	83 c0 01             	add    $0x1,%eax
    8117:	88 07                	mov    %al,(%rdi)
    8119:	c3                   	ret
    811a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8120:	48 83 05 c8 63 06 00 	addq   $0x1,0x663c8(%rip)        # 6e4f0 <iteration_retains>
    8127:	01 
    8128:	eb e6                	jmp    8110 <fwp_args23+0x80>
    812a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8130:	66 85 c0             	test   %ax,%ax
    8133:	74 ca                	je     80ff <fwp_args23+0x6f>
    8135:	c3                   	ret
    8136:	e9 75 d5 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    813b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000008140 <fwp_caps12>:
    8140:	f3 0f 1e fa          	endbr64
    8144:	48 83 ec 18          	sub    $0x18,%rsp
    8148:	48 89 f8             	mov    %rdi,%rax
    814b:	8b 7f 04             	mov    0x4(%rdi),%edi
    814e:	85 ff                	test   %edi,%edi
    8150:	0f 84 9a 00 00 00    	je     81f0 <fwp_caps12+0xb0>
    8156:	48 8b 78 08          	mov    0x8(%rax),%rdi
    815a:	85 f6                	test   %esi,%esi
    815c:	0f 85 9e 00 00 00    	jne    8200 <fwp_caps12+0xc0>
    8162:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8167:	e8 24 ed ff ff       	call   6e90 <fwp_drop0>
    816c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8171:	48 8b 0d a0 5a 06 00 	mov    0x65aa0(%rip),%rcx        # 6dc18 <fwp_heap+0x13d8>
    8178:	48 89 c2             	mov    %rax,%rdx
    817b:	48 2b 15 6e 5a 06 00 	sub    0x65a6e(%rip),%rdx        # 6dbf0 <fwp_heap+0x13b0>
    8182:	48 c1 e1 10          	shl    $0x10,%rcx
    8186:	48 39 ca             	cmp    %rcx,%rdx
    8189:	73 6d                	jae    81f8 <fwp_caps12+0xb8>
    818b:	48 89 d1             	mov    %rdx,%rcx
    818e:	48 c1 e9 10          	shr    $0x10,%rcx
    8192:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    8196:	48 8b 0d 9b 5a 06 00 	mov    0x65a9b(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    819d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    81a1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    81a5:	48 85 f6             	test   %rsi,%rsi
    81a8:	74 4e                	je     81f8 <fwp_caps12+0xb8>
    81aa:	0f b6 39             	movzbl (%rcx),%edi
    81ad:	40 80 ff 02          	cmp    $0x2,%dil
    81b1:	0f 84 c9 00 00 00    	je     8280 <fwp_caps12+0x140>
    81b7:	40 80 ff 01          	cmp    $0x1,%dil
    81bb:	75 3b                	jne    81f8 <fwp_caps12+0xb8>
    81bd:	8b 79 18             	mov    0x18(%rcx),%edi
    81c0:	0f b7 d2             	movzwl %dx,%edx
    81c3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    81c6:	48 0f af d7          	imul   %rdi,%rdx
    81ca:	48 c1 ea 20          	shr    $0x20,%rdx
    81ce:	48 39 ca             	cmp    %rcx,%rdx
    81d1:	73 25                	jae    81f8 <fwp_caps12+0xb8>
    81d3:	48 01 d6             	add    %rdx,%rsi
    81d6:	80 3e 01             	cmpb   $0x1,(%rsi)
    81d9:	75 1d                	jne    81f8 <fwp_caps12+0xb8>
    81db:	48 89 c7             	mov    %rax,%rdi
    81de:	48 83 c4 18          	add    $0x18,%rsp
    81e2:	e9 29 d8 ff ff       	jmp    5a10 <fwp_mem_free>
    81e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    81ee:	00 00 
    81f0:	85 f6                	test   %esi,%esi
    81f2:	0f 84 79 ff ff ff    	je     8171 <fwp_caps12+0x31>
    81f8:	48 83 c4 18          	add    $0x18,%rsp
    81fc:	c3                   	ret
    81fd:	0f 1f 00             	nopl   (%rax)
    8200:	48 8b 05 11 5a 06 00 	mov    0x65a11(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    8207:	48 2b 3d e2 59 06 00 	sub    0x659e2(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    820e:	48 c1 e0 10          	shl    $0x10,%rax
    8212:	48 39 c7             	cmp    %rax,%rdi
    8215:	73 e1                	jae    81f8 <fwp_caps12+0xb8>
    8217:	48 89 f8             	mov    %rdi,%rax
    821a:	48 c1 e8 10          	shr    $0x10,%rax
    821e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8222:	48 8b 05 0f 5a 06 00 	mov    0x65a0f(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    8229:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    822d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    8231:	48 85 c0             	test   %rax,%rax
    8234:	74 c2                	je     81f8 <fwp_caps12+0xb8>
    8236:	0f b6 0a             	movzbl (%rdx),%ecx
    8239:	80 f9 02             	cmp    $0x2,%cl
    823c:	74 52                	je     8290 <fwp_caps12+0x150>
    823e:	80 f9 01             	cmp    $0x1,%cl
    8241:	75 b5                	jne    81f8 <fwp_caps12+0xb8>
    8243:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8246:	0f b7 ff             	movzwl %di,%edi
    8249:	8b 52 1c             	mov    0x1c(%rdx),%edx
    824c:	48 0f af f9          	imul   %rcx,%rdi
    8250:	48 c1 ef 20          	shr    $0x20,%rdi
    8254:	48 39 d7             	cmp    %rdx,%rdi
    8257:	73 9f                	jae    81f8 <fwp_caps12+0xb8>
    8259:	48 01 f8             	add    %rdi,%rax
    825c:	0f b6 10             	movzbl (%rax),%edx
    825f:	84 d2                	test   %dl,%dl
    8261:	74 95                	je     81f8 <fwp_caps12+0xb8>
    8263:	8b 0d 9f 62 06 00    	mov    0x6629f(%rip),%ecx        # 6e508 <iteration_active>
    8269:	85 c9                	test   %ecx,%ecx
    826b:	75 33                	jne    82a0 <fwp_caps12+0x160>
    826d:	80 fa fd             	cmp    $0xfd,%dl
    8270:	77 38                	ja     82aa <fwp_caps12+0x16a>
    8272:	83 c2 01             	add    $0x1,%edx
    8275:	88 10                	mov    %dl,(%rax)
    8277:	e9 7c ff ff ff       	jmp    81f8 <fwp_caps12+0xb8>
    827c:	0f 1f 40 00          	nopl   0x0(%rax)
    8280:	66 85 d2             	test   %dx,%dx
    8283:	0f 85 6f ff ff ff    	jne    81f8 <fwp_caps12+0xb8>
    8289:	e9 48 ff ff ff       	jmp    81d6 <fwp_caps12+0x96>
    828e:	66 90                	xchg   %ax,%ax
    8290:	66 85 ff             	test   %di,%di
    8293:	0f 85 5f ff ff ff    	jne    81f8 <fwp_caps12+0xb8>
    8299:	eb c1                	jmp    825c <fwp_caps12+0x11c>
    829b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    82a0:	48 83 05 48 62 06 00 	addq   $0x1,0x66248(%rip)        # 6e4f0 <iteration_retains>
    82a7:	01 
    82a8:	eb c3                	jmp    826d <fwp_caps12+0x12d>
    82aa:	48 89 c7             	mov    %rax,%rdi
    82ad:	48 83 c4 18          	add    $0x18,%rsp
    82b1:	e9 fa d3 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    82b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    82bd:	00 00 00 

00000000000082c0 <fwp_caps23>:
    82c0:	f3 0f 1e fa          	endbr64
    82c4:	48 83 ec 18          	sub    $0x18,%rsp
    82c8:	48 89 f8             	mov    %rdi,%rax
    82cb:	8b 7f 04             	mov    0x4(%rdi),%edi
    82ce:	85 ff                	test   %edi,%edi
    82d0:	0f 84 9a 00 00 00    	je     8370 <fwp_caps23+0xb0>
    82d6:	48 8b 78 08          	mov    0x8(%rax),%rdi
    82da:	85 f6                	test   %esi,%esi
    82dc:	0f 85 9e 00 00 00    	jne    8380 <fwp_caps23+0xc0>
    82e2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    82e7:	e8 34 fa ff ff       	call   7d20 <fwp_drop2>
    82ec:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    82f1:	48 8b 0d 20 59 06 00 	mov    0x65920(%rip),%rcx        # 6dc18 <fwp_heap+0x13d8>
    82f8:	48 89 c2             	mov    %rax,%rdx
    82fb:	48 2b 15 ee 58 06 00 	sub    0x658ee(%rip),%rdx        # 6dbf0 <fwp_heap+0x13b0>
    8302:	48 c1 e1 10          	shl    $0x10,%rcx
    8306:	48 39 ca             	cmp    %rcx,%rdx
    8309:	73 6d                	jae    8378 <fwp_caps23+0xb8>
    830b:	48 89 d1             	mov    %rdx,%rcx
    830e:	48 c1 e9 10          	shr    $0x10,%rcx
    8312:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    8316:	48 8b 0d 1b 59 06 00 	mov    0x6591b(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    831d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    8321:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8325:	48 85 f6             	test   %rsi,%rsi
    8328:	74 4e                	je     8378 <fwp_caps23+0xb8>
    832a:	0f b6 39             	movzbl (%rcx),%edi
    832d:	40 80 ff 02          	cmp    $0x2,%dil
    8331:	0f 84 c9 00 00 00    	je     8400 <fwp_caps23+0x140>
    8337:	40 80 ff 01          	cmp    $0x1,%dil
    833b:	75 3b                	jne    8378 <fwp_caps23+0xb8>
    833d:	8b 79 18             	mov    0x18(%rcx),%edi
    8340:	0f b7 d2             	movzwl %dx,%edx
    8343:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8346:	48 0f af d7          	imul   %rdi,%rdx
    834a:	48 c1 ea 20          	shr    $0x20,%rdx
    834e:	48 39 ca             	cmp    %rcx,%rdx
    8351:	73 25                	jae    8378 <fwp_caps23+0xb8>
    8353:	48 01 d6             	add    %rdx,%rsi
    8356:	80 3e 01             	cmpb   $0x1,(%rsi)
    8359:	75 1d                	jne    8378 <fwp_caps23+0xb8>
    835b:	48 89 c7             	mov    %rax,%rdi
    835e:	48 83 c4 18          	add    $0x18,%rsp
    8362:	e9 a9 d6 ff ff       	jmp    5a10 <fwp_mem_free>
    8367:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    836e:	00 00 
    8370:	85 f6                	test   %esi,%esi
    8372:	0f 84 79 ff ff ff    	je     82f1 <fwp_caps23+0x31>
    8378:	48 83 c4 18          	add    $0x18,%rsp
    837c:	c3                   	ret
    837d:	0f 1f 00             	nopl   (%rax)
    8380:	48 8b 05 91 58 06 00 	mov    0x65891(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    8387:	48 2b 3d 62 58 06 00 	sub    0x65862(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    838e:	48 c1 e0 10          	shl    $0x10,%rax
    8392:	48 39 c7             	cmp    %rax,%rdi
    8395:	73 e1                	jae    8378 <fwp_caps23+0xb8>
    8397:	48 89 f8             	mov    %rdi,%rax
    839a:	48 c1 e8 10          	shr    $0x10,%rax
    839e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    83a2:	48 8b 05 8f 58 06 00 	mov    0x6588f(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    83a9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    83ad:	48 8b 42 20          	mov    0x20(%rdx),%rax
    83b1:	48 85 c0             	test   %rax,%rax
    83b4:	74 c2                	je     8378 <fwp_caps23+0xb8>
    83b6:	0f b6 0a             	movzbl (%rdx),%ecx
    83b9:	80 f9 02             	cmp    $0x2,%cl
    83bc:	74 52                	je     8410 <fwp_caps23+0x150>
    83be:	80 f9 01             	cmp    $0x1,%cl
    83c1:	75 b5                	jne    8378 <fwp_caps23+0xb8>
    83c3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    83c6:	0f b7 ff             	movzwl %di,%edi
    83c9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    83cc:	48 0f af f9          	imul   %rcx,%rdi
    83d0:	48 c1 ef 20          	shr    $0x20,%rdi
    83d4:	48 39 d7             	cmp    %rdx,%rdi
    83d7:	73 9f                	jae    8378 <fwp_caps23+0xb8>
    83d9:	48 01 f8             	add    %rdi,%rax
    83dc:	0f b6 10             	movzbl (%rax),%edx
    83df:	84 d2                	test   %dl,%dl
    83e1:	74 95                	je     8378 <fwp_caps23+0xb8>
    83e3:	8b 0d 1f 61 06 00    	mov    0x6611f(%rip),%ecx        # 6e508 <iteration_active>
    83e9:	85 c9                	test   %ecx,%ecx
    83eb:	75 33                	jne    8420 <fwp_caps23+0x160>
    83ed:	80 fa fd             	cmp    $0xfd,%dl
    83f0:	77 38                	ja     842a <fwp_caps23+0x16a>
    83f2:	83 c2 01             	add    $0x1,%edx
    83f5:	88 10                	mov    %dl,(%rax)
    83f7:	e9 7c ff ff ff       	jmp    8378 <fwp_caps23+0xb8>
    83fc:	0f 1f 40 00          	nopl   0x0(%rax)
    8400:	66 85 d2             	test   %dx,%dx
    8403:	0f 85 6f ff ff ff    	jne    8378 <fwp_caps23+0xb8>
    8409:	e9 48 ff ff ff       	jmp    8356 <fwp_caps23+0x96>
    840e:	66 90                	xchg   %ax,%ax
    8410:	66 85 ff             	test   %di,%di
    8413:	0f 85 5f ff ff ff    	jne    8378 <fwp_caps23+0xb8>
    8419:	eb c1                	jmp    83dc <fwp_caps23+0x11c>
    841b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8420:	48 83 05 c8 60 06 00 	addq   $0x1,0x660c8(%rip)        # 6e4f0 <iteration_retains>
    8427:	01 
    8428:	eb c3                	jmp    83ed <fwp_caps23+0x12d>
    842a:	48 89 c7             	mov    %rax,%rdi
    842d:	48 83 c4 18          	add    $0x18,%rsp
    8431:	e9 7a d2 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    8436:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    843d:	00 00 00 

0000000000008440 <f23>:
    8440:	41 57                	push   %r15
    8442:	41 56                	push   %r14
    8444:	41 55                	push   %r13
    8446:	41 54                	push   %r12
    8448:	55                   	push   %rbp
    8449:	53                   	push   %rbx
    844a:	48 83 ec 38          	sub    $0x38,%rsp
    844e:	48 8b 15 c3 57 06 00 	mov    0x657c3(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    8455:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    845a:	48 c1 e2 10          	shl    $0x10,%rdx
    845e:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    8465:	00 00 
    8467:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    846c:	48 8b 0d 7d 57 06 00 	mov    0x6577d(%rip),%rcx        # 6dbf0 <fwp_heap+0x13b0>
    8473:	48 85 ff             	test   %rdi,%rdi
    8476:	0f 84 6e 03 00 00    	je     87ea <f23+0x3aa>
    847c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8481:	4c 8b 68 10          	mov    0x10(%rax),%r13
    8485:	4c 89 e8             	mov    %r13,%rax
    8488:	48 29 c8             	sub    %rcx,%rax
    848b:	48 39 d0             	cmp    %rdx,%rax
    848e:	0f 83 3c 03 00 00    	jae    87d0 <f23+0x390>
    8494:	48 89 c2             	mov    %rax,%rdx
    8497:	48 c1 ea 10          	shr    $0x10,%rdx
    849b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    849f:	48 8b 15 92 57 06 00 	mov    0x65792(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    84a6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    84aa:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    84ae:	48 85 ff             	test   %rdi,%rdi
    84b1:	0f 84 19 03 00 00    	je     87d0 <f23+0x390>
    84b7:	0f b6 0a             	movzbl (%rdx),%ecx
    84ba:	80 f9 02             	cmp    $0x2,%cl
    84bd:	0f 84 9d 02 00 00    	je     8760 <f23+0x320>
    84c3:	80 f9 01             	cmp    $0x1,%cl
    84c6:	75 24                	jne    84ec <f23+0xac>
    84c8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    84cb:	0f b7 c0             	movzwl %ax,%eax
    84ce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    84d1:	48 0f af c1          	imul   %rcx,%rax
    84d5:	48 c1 e8 20          	shr    $0x20,%rax
    84d9:	48 39 d0             	cmp    %rdx,%rax
    84dc:	73 0e                	jae    84ec <f23+0xac>
    84de:	48 01 c7             	add    %rax,%rdi
    84e1:	0f b6 07             	movzbl (%rdi),%eax
    84e4:	84 c0                	test   %al,%al
    84e6:	0f 85 94 02 00 00    	jne    8780 <f23+0x340>
    84ec:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    84f1:	48 8b 40 10          	mov    0x10(%rax),%rax
    84f5:	ba 01 00 00 00       	mov    $0x1,%edx
    84fa:	48 85 c0             	test   %rax,%rax
    84fd:	74 0e                	je     850d <f23+0xcd>
    84ff:	90                   	nop
    8500:	48 8b 40 10          	mov    0x10(%rax),%rax
    8504:	48 83 c2 01          	add    $0x1,%rdx
    8508:	48 85 c0             	test   %rax,%rax
    850b:	75 f3                	jne    8500 <f23+0xc0>
    850d:	4d 85 ed             	test   %r13,%r13
    8510:	0f 84 ea 02 00 00    	je     8800 <f23+0x3c0>
    8516:	4c 89 e8             	mov    %r13,%rax
    8519:	31 db                	xor    %ebx,%ebx
    851b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8520:	48 8b 40 10          	mov    0x10(%rax),%rax
    8524:	48 83 c3 01          	add    $0x1,%rbx
    8528:	48 85 c0             	test   %rax,%rax
    852b:	75 f3                	jne    8520 <f23+0xe0>
    852d:	48 39 d3             	cmp    %rdx,%rbx
    8530:	48 0f 47 da          	cmova  %rdx,%rbx
    8534:	48 89 d8             	mov    %rbx,%rax
    8537:	48 c1 e8 3c          	shr    $0x3c,%rax
    853b:	0f 85 cd 03 00 00    	jne    890e <f23+0x4ce>
    8541:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8545:	be 02 00 00 00       	mov    $0x2,%esi
    854a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8551:	00 
    8552:	e8 b9 d9 ff ff       	call   5f10 <fwp_heap_alloc>
    8557:	48 89 28             	mov    %rbp,(%rax)
    855a:	48 8b 15 b7 56 06 00 	mov    0x656b7(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    8561:	49 89 c4             	mov    %rax,%r12
    8564:	48 2b 05 85 56 06 00 	sub    0x65685(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    856b:	48 c1 e2 10          	shl    $0x10,%rdx
    856f:	48 39 d0             	cmp    %rdx,%rax
    8572:	73 57                	jae    85cb <f23+0x18b>
    8574:	48 89 c2             	mov    %rax,%rdx
    8577:	48 c1 ea 10          	shr    $0x10,%rdx
    857b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    857f:	48 8b 15 b2 56 06 00 	mov    0x656b2(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    8586:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    858a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    858e:	48 85 ed             	test   %rbp,%rbp
    8591:	74 38                	je     85cb <f23+0x18b>
    8593:	0f b6 0a             	movzbl (%rdx),%ecx
    8596:	80 f9 02             	cmp    $0x2,%cl
    8599:	0f 84 21 02 00 00    	je     87c0 <f23+0x380>
    859f:	80 f9 01             	cmp    $0x1,%cl
    85a2:	75 27                	jne    85cb <f23+0x18b>
    85a4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    85a7:	0f b7 c0             	movzwl %ax,%eax
    85aa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    85ad:	48 0f af c1          	imul   %rcx,%rax
    85b1:	48 c1 e8 20          	shr    $0x20,%rax
    85b5:	48 39 d0             	cmp    %rdx,%rax
    85b8:	73 11                	jae    85cb <f23+0x18b>
    85ba:	48 01 c5             	add    %rax,%rbp
    85bd:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    85c1:	0f 84 a7 02 00 00    	je     886e <f23+0x42e>
    85c7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    85cb:	48 85 db             	test   %rbx,%rbx
    85ce:	74 5d                	je     862d <f23+0x1ed>
    85d0:	48 c1 e3 04          	shl    $0x4,%rbx
    85d4:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    85d9:	4c 89 e5             	mov    %r12,%rbp
    85dc:	4d 89 ef             	mov    %r13,%r15
    85df:	4c 01 e3             	add    %r12,%rbx
    85e2:	0f 1f 00             	nopl   (%rax)
    85e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    85ec:	00 00 00 00 
    85f0:	49 8b 46 08          	mov    0x8(%r14),%rax
    85f4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    85f8:	48 83 c5 10          	add    $0x10,%rbp
    85fc:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8601:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8605:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8609:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    860e:	e8 bd e0 ff ff       	call   66d0 <w107>
    8613:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8618:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    861c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8620:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8624:	4d 8b 76 10          	mov    0x10(%r14),%r14
    8628:	48 39 eb             	cmp    %rbp,%rbx
    862b:	75 c3                	jne    85f0 <f23+0x1b0>
    862d:	4c 89 ef             	mov    %r13,%rdi
    8630:	31 db                	xor    %ebx,%ebx
    8632:	e8 e9 f6 ff ff       	call   7d20 <fwp_drop2>
    8637:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    863c:	e8 df f6 ff ff       	call   7d20 <fwp_drop2>
    8641:	4d 8b 2c 24          	mov    (%r12),%r13
    8645:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8649:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    8650:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    8657:	4d 85 ed             	test   %r13,%r13
    865a:	74 3f                	je     869b <f23+0x25b>
    865c:	0f 1f 40 00          	nopl   0x0(%rax)
    8660:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    8667:	49 8b 54 dc 10       	mov    0x10(%r12,%rbx,8),%rdx
    866c:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    8673:	00 f0 3f 
    8676:	48 83 c3 02          	add    $0x2,%rbx
    867a:	48 89 ce             	mov    %rcx,%rsi
    867d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8683:	e8 c8 dc ff ff       	call   6350 <fwp_p_ad_push>
    8688:	4c 39 eb             	cmp    %r13,%rbx
    868b:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    8691:	48 89 c7             	mov    %rax,%rdi
    8694:	72 ca                	jb     8660 <f23+0x220>
    8696:	66 49 0f 7e c5       	movq   %xmm0,%r13
    869b:	4c 89 e7             	mov    %r12,%rdi
    869e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    86a3:	e8 f8 f3 ff ff       	call   7aa0 <fwp_drop4>
    86a8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    86ad:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    86b2:	31 ff                	xor    %edi,%edi
    86b4:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    86b9:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    86be:	e8 7d e1 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    86c3:	48 8b 15 4e 55 06 00 	mov    0x6554e(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    86ca:	48 89 c5             	mov    %rax,%rbp
    86cd:	48 2b 05 1c 55 06 00 	sub    0x6551c(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    86d4:	48 c1 e2 10          	shl    $0x10,%rdx
    86d8:	48 39 d0             	cmp    %rdx,%rax
    86db:	73 55                	jae    8732 <f23+0x2f2>
    86dd:	48 89 c2             	mov    %rax,%rdx
    86e0:	48 c1 ea 10          	shr    $0x10,%rdx
    86e4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    86e8:	48 8b 15 49 55 06 00 	mov    0x65549(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    86ef:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    86f3:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    86f7:	48 85 db             	test   %rbx,%rbx
    86fa:	74 36                	je     8732 <f23+0x2f2>
    86fc:	0f b6 0a             	movzbl (%rdx),%ecx
    86ff:	80 f9 02             	cmp    $0x2,%cl
    8702:	0f 84 a8 00 00 00    	je     87b0 <f23+0x370>
    8708:	80 f9 01             	cmp    $0x1,%cl
    870b:	75 25                	jne    8732 <f23+0x2f2>
    870d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8710:	0f b7 c0             	movzwl %ax,%eax
    8713:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8716:	48 0f af c1          	imul   %rcx,%rax
    871a:	48 c1 e8 20          	shr    $0x20,%rax
    871e:	48 39 d0             	cmp    %rdx,%rax
    8721:	73 0f                	jae    8732 <f23+0x2f2>
    8723:	48 01 c3             	add    %rax,%rbx
    8726:	80 3b ff             	cmpb   $0xff,(%rbx)
    8729:	0f 84 32 01 00 00    	je     8861 <f23+0x421>
    872f:	c6 03 01             	movb   $0x1,(%rbx)
    8732:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    8737:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    873e:	00 00 
    8740:	0f 85 d4 01 00 00    	jne    891a <f23+0x4da>
    8746:	48 83 c4 38          	add    $0x38,%rsp
    874a:	48 89 e8             	mov    %rbp,%rax
    874d:	5b                   	pop    %rbx
    874e:	5d                   	pop    %rbp
    874f:	41 5c                	pop    %r12
    8751:	41 5d                	pop    %r13
    8753:	41 5e                	pop    %r14
    8755:	41 5f                	pop    %r15
    8757:	c3                   	ret
    8758:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    875f:	00 
    8760:	66 85 c0             	test   %ax,%ax
    8763:	0f 85 83 fd ff ff    	jne    84ec <f23+0xac>
    8769:	0f b6 07             	movzbl (%rdi),%eax
    876c:	84 c0                	test   %al,%al
    876e:	0f 84 78 fd ff ff    	je     84ec <f23+0xac>
    8774:	90                   	nop
    8775:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    877c:	00 00 00 00 
    8780:	8b 15 82 5d 06 00    	mov    0x65d82(%rip),%edx        # 6e508 <iteration_active>
    8786:	85 d2                	test   %edx,%edx
    8788:	75 56                	jne    87e0 <f23+0x3a0>
    878a:	3c fd                	cmp    $0xfd,%al
    878c:	0f 87 4b 01 00 00    	ja     88dd <f23+0x49d>
    8792:	83 c0 01             	add    $0x1,%eax
    8795:	88 07                	mov    %al,(%rdi)
    8797:	31 d2                	xor    %edx,%edx
    8799:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    879f:	0f 85 47 fd ff ff    	jne    84ec <f23+0xac>
    87a5:	e9 63 fd ff ff       	jmp    850d <f23+0xcd>
    87aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    87b0:	66 85 c0             	test   %ax,%ax
    87b3:	0f 85 79 ff ff ff    	jne    8732 <f23+0x2f2>
    87b9:	e9 68 ff ff ff       	jmp    8726 <f23+0x2e6>
    87be:	66 90                	xchg   %ax,%ax
    87c0:	66 85 c0             	test   %ax,%ax
    87c3:	0f 85 02 fe ff ff    	jne    85cb <f23+0x18b>
    87c9:	e9 ef fd ff ff       	jmp    85bd <f23+0x17d>
    87ce:	66 90                	xchg   %ax,%ax
    87d0:	4c 89 e8             	mov    %r13,%rax
    87d3:	e9 1d fd ff ff       	jmp    84f5 <f23+0xb5>
    87d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    87df:	00 
    87e0:	48 83 05 08 5d 06 00 	addq   $0x1,0x65d08(%rip)        # 6e4f0 <iteration_retains>
    87e7:	01 
    87e8:	eb a0                	jmp    878a <f23+0x34a>
    87ea:	48 f7 d9             	neg    %rcx
    87ed:	48 39 d1             	cmp    %rdx,%rcx
    87f0:	0f 82 85 00 00 00    	jb     887b <f23+0x43b>
    87f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    87fd:	00 00 00 
    8800:	be 02 00 00 00       	mov    $0x2,%esi
    8805:	bf 08 00 00 00       	mov    $0x8,%edi
    880a:	e8 01 d7 ff ff       	call   5f10 <fwp_heap_alloc>
    880f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8816:	48 8b 15 fb 53 06 00 	mov    0x653fb(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    881d:	49 89 c4             	mov    %rax,%r12
    8820:	48 2b 05 c9 53 06 00 	sub    0x653c9(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8827:	48 c1 e2 10          	shl    $0x10,%rdx
    882b:	48 39 d0             	cmp    %rdx,%rax
    882e:	0f 83 b3 00 00 00    	jae    88e7 <f23+0x4a7>
    8834:	48 89 c2             	mov    %rax,%rdx
    8837:	45 31 ed             	xor    %r13d,%r13d
    883a:	48 c1 ea 10          	shr    $0x10,%rdx
    883e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8842:	48 8b 15 ef 53 06 00 	mov    0x653ef(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    8849:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    884d:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    8851:	48 85 ed             	test   %rbp,%rbp
    8854:	0f 84 d3 fd ff ff    	je     862d <f23+0x1ed>
    885a:	31 db                	xor    %ebx,%ebx
    885c:	e9 32 fd ff ff       	jmp    8593 <f23+0x153>
    8861:	48 89 df             	mov    %rbx,%rdi
    8864:	e8 67 cf ff ff       	call   57d0 <fwp_rc_forget_slot>
    8869:	e9 c1 fe ff ff       	jmp    872f <f23+0x2ef>
    886e:	48 89 ef             	mov    %rbp,%rdi
    8871:	e8 5a cf ff ff       	call   57d0 <fwp_rc_forget_slot>
    8876:	e9 4c fd ff ff       	jmp    85c7 <f23+0x187>
    887b:	48 89 c8             	mov    %rcx,%rax
    887e:	48 c1 e8 10          	shr    $0x10,%rax
    8882:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8886:	48 8b 05 ab 53 06 00 	mov    0x653ab(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    888d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8891:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8895:	48 85 ff             	test   %rdi,%rdi
    8898:	0f 84 62 ff ff ff    	je     8800 <f23+0x3c0>
    889e:	0f b6 02             	movzbl (%rdx),%eax
    88a1:	3c 02                	cmp    $0x2,%al
    88a3:	74 4a                	je     88ef <f23+0x4af>
    88a5:	3c 01                	cmp    $0x1,%al
    88a7:	0f 85 53 ff ff ff    	jne    8800 <f23+0x3c0>
    88ad:	0f b7 c1             	movzwl %cx,%eax
    88b0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    88b3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    88b6:	48 0f af c1          	imul   %rcx,%rax
    88ba:	48 c1 e8 20          	shr    $0x20,%rax
    88be:	48 39 d0             	cmp    %rdx,%rax
    88c1:	0f 83 39 ff ff ff    	jae    8800 <f23+0x3c0>
    88c7:	48 01 c7             	add    %rax,%rdi
    88ca:	0f b6 07             	movzbl (%rdi),%eax
    88cd:	84 c0                	test   %al,%al
    88cf:	0f 84 2b ff ff ff    	je     8800 <f23+0x3c0>
    88d5:	45 31 ed             	xor    %r13d,%r13d
    88d8:	e9 a3 fe ff ff       	jmp    8780 <f23+0x340>
    88dd:	e8 ce cd ff ff       	call   56b0 <fwp_rc_wide_dup>
    88e2:	e9 b0 fe ff ff       	jmp    8797 <f23+0x357>
    88e7:	45 31 ed             	xor    %r13d,%r13d
    88ea:	e9 3e fd ff ff       	jmp    862d <f23+0x1ed>
    88ef:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    88f5:	49 89 cd             	mov    %rcx,%r13
    88f8:	0f 85 02 ff ff ff    	jne    8800 <f23+0x3c0>
    88fe:	0f b6 07             	movzbl (%rdi),%eax
    8901:	84 c0                	test   %al,%al
    8903:	0f 85 77 fe ff ff    	jne    8780 <f23+0x340>
    8909:	e9 f2 fe ff ff       	jmp    8800 <f23+0x3c0>
    890e:	48 8d 3d d6 78 00 00 	lea    0x78d6(%rip),%rdi        # 101eb <_IO_stdin_used+0x1eb>
    8915:	e8 36 bb ff ff       	call   4450 <fwp_trap>
    891a:	e8 31 ab ff ff       	call   3450 <__stack_chk_fail@plt>
    891f:	90                   	nop

0000000000008920 <fwp_owned_entry23>:
    8920:	f3 0f 1e fa          	endbr64
    8924:	48 8b 3f             	mov    (%rdi),%rdi
    8927:	e9 14 fb ff ff       	jmp    8440 <f23>
    892c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008930 <e23>:
    8930:	f3 0f 1e fa          	endbr64
    8934:	53                   	push   %rbx
    8935:	48 8b 1f             	mov    (%rdi),%rbx
    8938:	48 89 df             	mov    %rbx,%rdi
    893b:	e8 f0 e0 ff ff       	call   6a30 <fwp_rc_share>
    8940:	48 89 df             	mov    %rbx,%rdi
    8943:	e8 f8 fa ff ff       	call   8440 <f23>
    8948:	48 89 c3             	mov    %rax,%rbx
    894b:	48 89 c7             	mov    %rax,%rdi
    894e:	e8 dd e0 ff ff       	call   6a30 <fwp_rc_share>
    8953:	48 89 d8             	mov    %rbx,%rax
    8956:	5b                   	pop    %rbx
    8957:	c3                   	ret
    8958:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    895f:	00 

0000000000008960 <f12>:
    8960:	41 57                	push   %r15
    8962:	41 56                	push   %r14
    8964:	41 55                	push   %r13
    8966:	41 54                	push   %r12
    8968:	4c 8d 25 71 eb ff ff 	lea    -0x148f(%rip),%r12        # 74e0 <fwp_tape_scope_release>
    896f:	55                   	push   %rbp
    8970:	53                   	push   %rbx
    8971:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
    8978:	48 8b 05 59 5b 06 00 	mov    0x65b59(%rip),%rax        # 6e4d8 <fwp_cleanups>
    897f:	48 8b 15 92 52 06 00 	mov    0x65292(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    8986:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    898d:	00 00 
    898f:	48 89 ac 24 f8 00 00 	mov    %rbp,0xf8(%rsp)
    8996:	00 
    8997:	48 89 fd             	mov    %rdi,%rbp
    899a:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    89a1:	ff 
    89a2:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    89a7:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    89ac:	48 c1 e2 10          	shl    $0x10,%rdx
    89b0:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    89b5:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    89ba:	48 8d 44 24 60       	lea    0x60(%rsp),%rax
    89bf:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    89c4:	48 89 05 0d 5b 06 00 	mov    %rax,0x65b0d(%rip)        # 6e4d8 <fwp_cleanups>
    89cb:	48 8d 05 3e b6 00 00 	lea    0xb63e(%rip),%rax        # 14010 <fc23>
    89d2:	48 2b 05 17 52 06 00 	sub    0x65217(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    89d9:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    89de:	48 39 d0             	cmp    %rdx,%rax
    89e1:	73 6d                	jae    8a50 <f12+0xf0>
    89e3:	48 89 c2             	mov    %rax,%rdx
    89e6:	48 c1 ea 10          	shr    $0x10,%rdx
    89ea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    89ee:	48 8b 15 43 52 06 00 	mov    0x65243(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    89f5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    89f9:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    89fd:	48 85 ff             	test   %rdi,%rdi
    8a00:	74 4e                	je     8a50 <f12+0xf0>
    8a02:	0f b6 0a             	movzbl (%rdx),%ecx
    8a05:	80 f9 02             	cmp    $0x2,%cl
    8a08:	0f 84 22 0f 00 00    	je     9930 <f12+0xfd0>
    8a0e:	80 f9 01             	cmp    $0x1,%cl
    8a11:	75 3d                	jne    8a50 <f12+0xf0>
    8a13:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8a16:	0f b7 c0             	movzwl %ax,%eax
    8a19:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8a1c:	48 0f af c1          	imul   %rcx,%rax
    8a20:	48 c1 e8 20          	shr    $0x20,%rax
    8a24:	48 39 d0             	cmp    %rdx,%rax
    8a27:	73 27                	jae    8a50 <f12+0xf0>
    8a29:	48 01 c7             	add    %rax,%rdi
    8a2c:	0f b6 07             	movzbl (%rdi),%eax
    8a2f:	84 c0                	test   %al,%al
    8a31:	74 1d                	je     8a50 <f12+0xf0>
    8a33:	44 8b 05 ce 5a 06 00 	mov    0x65ace(%rip),%r8d        # 6e508 <iteration_active>
    8a3a:	45 85 c0             	test   %r8d,%r8d
    8a3d:	0f 85 ed 0f 00 00    	jne    9a30 <f12+0x10d0>
    8a43:	3c fd                	cmp    $0xfd,%al
    8a45:	0f 87 a2 11 00 00    	ja     9bed <f12+0x128d>
    8a4b:	83 c0 01             	add    $0x1,%eax
    8a4e:	88 07                	mov    %al,(%rdi)
    8a50:	48 8d 3d b9 b5 00 00 	lea    0xb5b9(%rip),%rdi        # 14010 <fc23>
    8a57:	e8 14 e7 ff ff       	call   7170 <fwp_closure_drop>
    8a5c:	48 85 ed             	test   %rbp,%rbp
    8a5f:	0f 84 ec 10 00 00    	je     9b51 <f12+0x11f1>
    8a65:	48 89 e8             	mov    %rbp,%rax
    8a68:	31 d2                	xor    %edx,%edx
    8a6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8a70:	48 8b 40 10          	mov    0x10(%rax),%rax
    8a74:	48 83 c2 01          	add    $0x1,%rdx
    8a78:	48 85 c0             	test   %rax,%rax
    8a7b:	75 f3                	jne    8a70 <f12+0x110>
    8a7d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    8a84:	0f 87 ea 11 00 00    	ja     9c74 <f12+0x1314>
    8a8a:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    8a8f:	8b 35 eb b5 00 00    	mov    0xb5eb(%rip),%esi        # 14080 <registered_finish.0>
    8a95:	85 f6                	test   %esi,%esi
    8a97:	0f 84 63 0e 00 00    	je     9900 <f12+0xfa0>
    8a9d:	48 8b 1d 54 b6 01 00 	mov    0x1b654(%rip),%rbx        # 240f8 <fwp_tape_next_slot>
    8aa4:	4c 8b 2d 5d b6 01 00 	mov    0x1b65d(%rip),%r13        # 24108 <fwp_ntapes>
    8aab:	4c 39 eb             	cmp    %r13,%rbx
    8aae:	0f 8d d4 00 00 00    	jge    8b88 <f12+0x228>
    8ab4:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    8ab8:	48 03 05 51 b6 01 00 	add    0x1b651(%rip),%rax        # 24110 <fwp_tapes>
    8abf:	90                   	nop
    8ac0:	8b 48 04             	mov    0x4(%rax),%ecx
    8ac3:	85 c9                	test   %ecx,%ecx
    8ac5:	75 0c                	jne    8ad3 <f12+0x173>
    8ac7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    8acd:	0f 86 b5 00 00 00    	jbe    8b88 <f12+0x228>
    8ad3:	48 83 c3 01          	add    $0x1,%rbx
    8ad7:	48 83 c0 68          	add    $0x68,%rax
    8adb:	4c 39 eb             	cmp    %r13,%rbx
    8ade:	75 e0                	jne    8ac0 <f12+0x160>
    8ae0:	49 81 fd fe ff 00 00 	cmp    $0xfffe,%r13
    8ae7:	0f 8f 09 12 00 00    	jg     9cf6 <f12+0x1396>
    8aed:	4c 39 2d 0c b6 01 00 	cmp    %r13,0x1b60c(%rip)        # 24100 <fwp_tapes_cap>
    8af4:	4c 8b 3d 15 b6 01 00 	mov    0x1b615(%rip),%r15        # 24110 <fwp_tapes>
    8afb:	75 4c                	jne    8b49 <f12+0x1e9>
    8afd:	4d 85 ed             	test   %r13,%r13
    8b00:	0f 84 b1 10 00 00    	je     9bb7 <f12+0x1257>
    8b06:	4b 8d 5c 2d 00       	lea    0x0(%r13,%r13,1),%rbx
    8b0b:	b8 ff ff 00 00       	mov    $0xffff,%eax
    8b10:	48 39 c3             	cmp    %rax,%rbx
    8b13:	48 0f 4f d8          	cmovg  %rax,%rbx
    8b17:	48 6b f3 68          	imul   $0x68,%rbx,%rsi
    8b1b:	31 d2                	xor    %edx,%edx
    8b1d:	4c 89 ff             	mov    %r15,%rdi
    8b20:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8b25:	e8 66 c6 ff ff       	call   5190 <ad_raw_realloc>
    8b2a:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8b2f:	48 85 c0             	test   %rax,%rax
    8b32:	49 89 c7             	mov    %rax,%r15
    8b35:	0f 84 5d 11 00 00    	je     9c98 <f12+0x1338>
    8b3b:	48 89 05 ce b5 01 00 	mov    %rax,0x1b5ce(%rip)        # 24110 <fwp_tapes>
    8b42:	48 89 1d b7 b5 01 00 	mov    %rbx,0x1b5b7(%rip)        # 24100 <fwp_tapes_cap>
    8b49:	49 6b c5 68          	imul   $0x68,%r13,%rax
    8b4d:	4c 89 eb             	mov    %r13,%rbx
    8b50:	4c 01 f8             	add    %r15,%rax
    8b53:	48 8d 78 08          	lea    0x8(%rax),%rdi
    8b57:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8b5e:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    8b62:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    8b69:	00 
    8b6a:	48 29 f8             	sub    %rdi,%rax
    8b6d:	8d 48 68             	lea    0x68(%rax),%ecx
    8b70:	31 c0                	xor    %eax,%eax
    8b72:	c1 e9 03             	shr    $0x3,%ecx
    8b75:	f3 48 ab             	rep stos %rax,(%rdi)
    8b78:	49 8d 45 01          	lea    0x1(%r13),%rax
    8b7c:	48 89 05 85 b5 01 00 	mov    %rax,0x1b585(%rip)        # 24108 <fwp_ntapes>
    8b83:	eb 13                	jmp    8b98 <f12+0x238>
    8b85:	0f 1f 00             	nopl   (%rax)
    8b88:	49 39 dd             	cmp    %rbx,%r13
    8b8b:	0f 84 4f ff ff ff    	je     8ae0 <f12+0x180>
    8b91:	4c 8b 3d 78 b5 01 00 	mov    0x1b578(%rip),%r15        # 24110 <fwp_tapes>
    8b98:	4c 6b f3 68          	imul   $0x68,%rbx,%r14
    8b9c:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    8ba0:	48 8d 3d b9 75 00 00 	lea    0x75b9(%rip),%rdi        # 10160 <_IO_stdin_used+0x160>
    8ba7:	0f 29 04 24          	movaps %xmm0,(%rsp)
    8bab:	4d 01 fe             	add    %r15,%r14
    8bae:	49 c7 46 60 00 00 00 	movq   $0x0,0x60(%r14)
    8bb5:	00 
    8bb6:	e8 d5 a7 ff ff       	call   3390 <getenv@plt>
    8bbb:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    8bc0:	48 85 c0             	test   %rax,%rax
    8bc3:	74 09                	je     8bce <f12+0x26e>
    8bc5:	80 38 30             	cmpb   $0x30,(%rax)
    8bc8:	0f 84 8a 06 00 00    	je     9258 <f12+0x8f8>
    8bce:	48 83 3d d2 b4 01 00 	cmpq   $0x0,0x1b4d2(%rip)        # 240a8 <fwp_tape_cached_bytes>
    8bd5:	00 
    8bd6:	0f 85 b4 0d 00 00    	jne    9990 <f12+0x1030>
    8bdc:	41 8b 06             	mov    (%r14),%eax
    8bdf:	4c 8d 6b 01          	lea    0x1(%rbx),%r13
    8be3:	41 c7 46 04 01 00 00 	movl   $0x1,0x4(%r14)
    8bea:	00 
    8beb:	4c 89 2d 06 b5 01 00 	mov    %r13,0x1b506(%rip)        # 240f8 <fwp_tape_next_slot>
    8bf2:	8d 70 01             	lea    0x1(%rax),%esi
    8bf5:	48 8b 05 dc 58 06 00 	mov    0x658dc(%rip),%rax        # 6e4d8 <fwp_cleanups>
    8bfc:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
    8c01:	41 89 36             	mov    %esi,(%r14)
    8c04:	49 c7 46 50 00 00 00 	movq   $0x0,0x50(%r14)
    8c0b:	00 
    8c0c:	49 c7 46 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%r14)
    8c13:	ff 
    8c14:	48 85 c0             	test   %rax,%rax
    8c17:	75 13                	jne    8c2c <f12+0x2cc>
    8c19:	e9 e9 10 00 00       	jmp    9d07 <f12+0x13a7>
    8c1e:	66 90                	xchg   %ax,%ax
    8c20:	48 8b 00             	mov    (%rax),%rax
    8c23:	48 85 c0             	test   %rax,%rax
    8c26:	0f 84 db 10 00 00    	je     9d07 <f12+0x13a7>
    8c2c:	4c 39 60 08          	cmp    %r12,0x8(%rax)
    8c30:	75 ee                	jne    8c20 <f12+0x2c0>
    8c32:	48 8b 50 10          	mov    0x10(%rax),%rdx
    8c36:	89 d9                	mov    %ebx,%ecx
    8c38:	48 63 02             	movslq (%rdx),%rax
    8c3b:	49 89 56 50          	mov    %rdx,0x50(%r14)
    8c3f:	41 89 46 5c          	mov    %eax,0x5c(%r14)
    8c43:	85 c0                	test   %eax,%eax
    8c45:	78 09                	js     8c50 <f12+0x2f0>
    8c47:	48 6b c0 68          	imul   $0x68,%rax,%rax
    8c4b:	41 89 5c 07 58       	mov    %ebx,0x58(%r15,%rax,1)
    8c50:	89 0a                	mov    %ecx,(%rdx)
    8c52:	48 89 e8             	mov    %rbp,%rax
    8c55:	31 c9                	xor    %ecx,%ecx
    8c57:	48 85 ed             	test   %rbp,%rbp
    8c5a:	0f 84 10 0b 00 00    	je     9770 <f12+0xe10>
    8c60:	48 8b 40 10          	mov    0x10(%rax),%rax
    8c64:	48 83 c1 01          	add    $0x1,%rcx
    8c68:	48 85 c0             	test   %rax,%rax
    8c6b:	75 f3                	jne    8c60 <f12+0x300>
    8c6d:	48 89 ea             	mov    %rbp,%rdx
    8c70:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8c74:	48 83 c0 01          	add    $0x1,%rax
    8c78:	48 85 d2             	test   %rdx,%rdx
    8c7b:	75 f3                	jne    8c70 <f12+0x310>
    8c7d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    8c84:	ff ff 1f 
    8c87:	48 39 c2             	cmp    %rax,%rdx
    8c8a:	0f 82 36 10 00 00    	jb     9cc6 <f12+0x1366>
    8c90:	48 85 c9             	test   %rcx,%rcx
    8c93:	0f 8e d7 0a 00 00    	jle    9770 <f12+0xe10>
    8c99:	48 39 c1             	cmp    %rax,%rcx
    8c9c:	48 0f 46 c1          	cmovbe %rcx,%rax
    8ca0:	49 89 c4             	mov    %rax,%r12
    8ca3:	48 c1 e8 3c          	shr    $0x3c,%rax
    8ca7:	0f 85 19 10 00 00    	jne    9cc6 <f12+0x1366>
    8cad:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    8cb1:	48 c1 e6 10          	shl    $0x10,%rsi
    8cb5:	49 09 f5             	or     %rsi,%r13
    8cb8:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8cbf:	00 
    8cc0:	be 02 00 00 00       	mov    $0x2,%esi
    8cc5:	e8 46 d2 ff ff       	call   5f10 <fwp_heap_alloc>
    8cca:	4c 89 30             	mov    %r14,(%rax)
    8ccd:	48 8b 15 44 4f 06 00 	mov    0x64f44(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    8cd4:	48 89 c3             	mov    %rax,%rbx
    8cd7:	48 2b 05 12 4f 06 00 	sub    0x64f12(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8cde:	48 c1 e2 10          	shl    $0x10,%rdx
    8ce2:	48 39 d0             	cmp    %rdx,%rax
    8ce5:	0f 83 85 0d 00 00    	jae    9a70 <f12+0x1110>
    8ceb:	48 89 c2             	mov    %rax,%rdx
    8cee:	48 c1 ea 10          	shr    $0x10,%rdx
    8cf2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8cf6:	48 8b 15 3b 4f 06 00 	mov    0x64f3b(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    8cfd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8d01:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8d05:	4d 85 f6             	test   %r14,%r14
    8d08:	74 38                	je     8d42 <f12+0x3e2>
    8d0a:	0f b6 0a             	movzbl (%rdx),%ecx
    8d0d:	80 f9 02             	cmp    $0x2,%cl
    8d10:	0f 84 c7 0a 00 00    	je     97dd <f12+0xe7d>
    8d16:	80 f9 01             	cmp    $0x1,%cl
    8d19:	75 27                	jne    8d42 <f12+0x3e2>
    8d1b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8d1e:	0f b7 c0             	movzwl %ax,%eax
    8d21:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8d24:	48 0f af c1          	imul   %rcx,%rax
    8d28:	48 c1 e8 20          	shr    $0x20,%rax
    8d2c:	48 39 d0             	cmp    %rdx,%rax
    8d2f:	73 11                	jae    8d42 <f12+0x3e2>
    8d31:	49 01 c6             	add    %rax,%r14
    8d34:	41 80 3e ff          	cmpb   $0xff,(%r14)
    8d38:	0f 84 88 0e 00 00    	je     9bc6 <f12+0x1266>
    8d3e:	41 c6 06 01          	movb   $0x1,(%r14)
    8d42:	4d 85 e4             	test   %r12,%r12
    8d45:	74 6c                	je     8db3 <f12+0x453>
    8d47:	4c 89 e9             	mov    %r13,%rcx
    8d4a:	48 89 ea             	mov    %rbp,%rdx
    8d4d:	31 c0                	xor    %eax,%eax
    8d4f:	48 c1 e1 20          	shl    $0x20,%rcx
    8d53:	90                   	nop
    8d54:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d5b:	00 00 00 00 
    8d5f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d66:	00 00 00 00 
    8d6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d71:	00 00 00 00 
    8d75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d7c:	00 00 00 00 
    8d80:	48 89 c6             	mov    %rax,%rsi
    8d83:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8d88:	48 01 ce             	add    %rcx,%rsi
    8d8b:	0f 80 ca 0e 00 00    	jo     9c5b <f12+0x12fb>
    8d91:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    8d96:	48 89 c6             	mov    %rax,%rsi
    8d99:	48 83 c0 01          	add    $0x1,%rax
    8d9d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    8da1:	48 c1 e6 04          	shl    $0x4,%rsi
    8da5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    8daa:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8dae:	4c 39 e0             	cmp    %r12,%rax
    8db1:	72 cd                	jb     8d80 <f12+0x420>
    8db3:	48 8b 03             	mov    (%rbx),%rax
    8db6:	48 d1 e8             	shr    $1,%rax
    8db9:	0f 85 49 0a 00 00    	jne    9808 <f12+0xea8>
    8dbf:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
    8dc6:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    8dcd:	0f 1f 00             	nopl   (%rax)
    8dd0:	48 89 df             	mov    %rbx,%rdi
    8dd3:	4d 63 e5             	movslq %r13d,%r12
    8dd6:	e8 c5 ec ff ff       	call   7aa0 <fwp_drop4>
    8ddb:	4c 89 e7             	mov    %r12,%rdi
    8dde:	e8 4d b9 ff ff       	call   4730 <fwp_tape_of>
    8de3:	48 89 c6             	mov    %rax,%rsi
    8de6:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    8deb:	0f 85 f9 0e 00 00    	jne    9cea <f12+0x138a>
    8df1:	48 89 c7             	mov    %rax,%rdi
    8df4:	e8 97 ae ff ff       	call   3c90 <fwp_tape_unlink_scope>
    8df9:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    8dfd:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    8e02:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    8e09:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
    8e0d:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    8e11:	66 49 0f 6e fe       	movq   %r14,%xmm7
    8e16:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    8e1b:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    8e20:	4c 8b 46 40          	mov    0x40(%rsi),%r8
    8e24:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    8e28:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    8e2e:	77 19                	ja     8e49 <f12+0x4e9>
    8e30:	41 0f b7 c5          	movzwl %r13w,%eax
    8e34:	83 e8 01             	sub    $0x1,%eax
    8e37:	48 98                	cltq
    8e39:	48 3b 05 b8 b2 01 00 	cmp    0x1b2b8(%rip),%rax        # 240f8 <fwp_tape_next_slot>
    8e40:	7d 07                	jge    8e49 <f12+0x4e9>
    8e42:	48 89 05 af b2 01 00 	mov    %rax,0x1b2af(%rip)        # 240f8 <fwp_tape_next_slot>
    8e49:	48 8b 05 88 56 06 00 	mov    0x65688(%rip),%rax        # 6e4d8 <fwp_cleanups>
    8e50:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8e54:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    8e5b:	00 
    8e5c:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8e60:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    8e67:	00 
    8e68:	48 8d 05 f1 c3 ff ff 	lea    -0x3c0f(%rip),%rax        # 5260 <fwp_tape_buffers_release>
    8e6f:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    8e76:	00 
    8e77:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    8e7e:	00 
    8e7f:	48 89 04 24          	mov    %rax,(%rsp)
    8e83:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    8e8a:	00 
    8e8b:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    8e92:	00 
    8e93:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    8e97:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    8e9b:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    8ea2:	00 
    8ea3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    8eaa:	00 
    8eab:	4c 89 84 24 c0 00 00 	mov    %r8,0xc0(%rsp)
    8eb2:	00 
    8eb3:	48 89 05 1e 56 06 00 	mov    %rax,0x6561e(%rip)        # 6e4d8 <fwp_cleanups>
    8eba:	0f 29 9c 24 a0 00 00 	movaps %xmm3,0xa0(%rsp)
    8ec1:	00 
    8ec2:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    8ec9:	00 
    8eca:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    8ed1:	00 
    8ed2:	4d 85 ff             	test   %r15,%r15
    8ed5:	0f 88 65 0a 00 00    	js     9940 <f12+0xfe0>
    8edb:	4c 89 f8             	mov    %r15,%rax
    8ede:	48 c1 f8 20          	sar    $0x20,%rax
    8ee2:	49 39 c4             	cmp    %rax,%r12
    8ee5:	0f 85 64 0d 00 00    	jne    9c4f <f12+0x12ef>
    8eeb:	44 89 f9             	mov    %r15d,%ecx
    8eee:	49 89 cd             	mov    %rcx,%r13
    8ef1:	48 39 ca             	cmp    %rcx,%rdx
    8ef4:	0f 8e 49 0d 00 00    	jle    9c43 <f12+0x12e3>
    8efa:	48 39 cb             	cmp    %rcx,%rbx
    8efd:	0f 8e ad 09 00 00    	jle    98b0 <f12+0xf50>
    8f03:	4c 39 f3             	cmp    %r14,%rbx
    8f06:	0f 8e f4 0a 00 00    	jle    9a00 <f12+0x10a0>
    8f0c:	49 89 dc             	mov    %rbx,%r12
    8f0f:	4d 85 f6             	test   %r14,%r14
    8f12:	4d 0f 44 f4          	cmove  %r12,%r14
    8f16:	eb 1d                	jmp    8f35 <f12+0x5d5>
    8f18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8f1f:	00 
    8f20:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
    8f24:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    8f2b:	4c 89 e0             	mov    %r12,%rax
    8f2e:	48 0f 4c c2          	cmovl  %rdx,%rax
    8f32:	49 89 c6             	mov    %rax,%r14
    8f35:	4d 39 f4             	cmp    %r14,%r12
    8f38:	7f e6                	jg     8f20 <f12+0x5c0>
    8f3a:	4d 85 c0             	test   %r8,%r8
    8f3d:	0f 84 3d 0b 00 00    	je     9a80 <f12+0x1120>
    8f43:	4c 89 c7             	mov    %r8,%rdi
    8f46:	ba 03 00 00 00       	mov    $0x3,%edx
    8f4b:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8f50:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    8f57:	00 
    8f58:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8f5d:	e8 2e c2 ff ff       	call   5190 <ad_raw_realloc>
    8f62:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8f68:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    8f6e:	48 85 c0             	test   %rax,%rax
    8f71:	49 89 c0             	mov    %rax,%r8
    8f74:	0f 84 c6 0b 00 00    	je     9b40 <f12+0x11e0>
    8f7a:	4c 89 84 24 c0 00 00 	mov    %r8,0xc0(%rsp)
    8f81:	00 
    8f82:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    8f89:	00 
    8f8a:	4d 85 e4             	test   %r12,%r12
    8f8d:	0f 85 67 0c 00 00    	jne    9bfa <f12+0x129a>
    8f93:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    8f9a:	4d 85 ff             	test   %r15,%r15
    8f9d:	78 17                	js     8fb6 <f12+0x656>
    8f9f:	44 89 f9             	mov    %r15d,%ecx
    8fa2:	f2 0f 10 05 36 7e 00 	movsd  0x7e36(%rip),%xmm0        # 10de0 <msg.4+0xb0>
    8fa9:	00 
    8faa:	f2 41 0f 58 04 c8    	addsd  (%r8,%rcx,8),%xmm0
    8fb0:	f2 41 0f 11 04 c8    	movsd  %xmm0,(%r8,%rcx,8)
    8fb6:	4c 39 eb             	cmp    %r13,%rbx
    8fb9:	0f 8f 92 00 00 00    	jg     9051 <f12+0x6f1>
    8fbf:	0f 12 fb             	movhlps %xmm3,%xmm7
    8fc2:	66 49 0f 7e d2       	movq   %xmm2,%r10
    8fc7:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    8fcc:	49 29 dd             	sub    %rbx,%r13
    8fcf:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    8fd4:	0f 12 fa             	movhlps %xmm2,%xmm7
    8fd7:	49 8d 3c d8          	lea    (%r8,%rbx,8),%rdi
    8fdb:	66 49 0f 7e fb       	movq   %xmm7,%r11
    8fe0:	4a 8d 04 ae          	lea    (%rsi,%r13,4),%rax
    8fe4:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8fe8:	48 29 f1             	sub    %rsi,%rcx
    8feb:	4b 8d 14 eb          	lea    (%r11,%r13,8),%rdx
    8fef:	4c 29 df             	sub    %r11,%rdi
    8ff2:	4d 29 da             	sub    %r11,%r10
    8ff5:	eb 0d                	jmp    9004 <f12+0x6a4>
    8ff7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8ffe:	00 00 
    9000:	48 83 e8 04          	sub    $0x4,%rax
    9004:	f2 0f 10 04 17       	movsd  (%rdi,%rdx,1),%xmm0
    9009:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    900d:	7a 02                	jp     9011 <f12+0x6b1>
    900f:	74 37                	je     9048 <f12+0x6e8>
    9011:	4c 63 1c 01          	movslq (%rcx,%rax,1),%r11
    9015:	45 85 db             	test   %r11d,%r11d
    9018:	78 16                	js     9030 <f12+0x6d0>
    901a:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    9020:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    9024:	f2 43 0f 58 0c d8    	addsd  (%r8,%r11,8),%xmm1
    902a:	f2 43 0f 11 0c d8    	movsd  %xmm1,(%r8,%r11,8)
    9030:	4c 63 18             	movslq (%rax),%r11
    9033:	45 85 db             	test   %r11d,%r11d
    9036:	78 10                	js     9048 <f12+0x6e8>
    9038:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    903c:	f2 43 0f 58 04 d8    	addsd  (%r8,%r11,8),%xmm0
    9042:	f2 43 0f 11 04 d8    	movsd  %xmm0,(%r8,%r11,8)
    9048:	48 83 ea 08          	sub    $0x8,%rdx
    904c:	48 39 c6             	cmp    %rax,%rsi
    904f:	75 af                	jne    9000 <f12+0x6a0>
    9051:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9058:	ff ff 1f 
    905b:	48 39 d8             	cmp    %rbx,%rax
    905e:	0f 82 6e 0c 00 00    	jb     9cd2 <f12+0x1372>
    9064:	48 8d 3c dd 08 00 00 	lea    0x8(,%rbx,8),%rdi
    906b:	00 
    906c:	be 02 00 00 00       	mov    $0x2,%esi
    9071:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    9076:	e8 95 ce ff ff       	call   5f10 <fwp_heap_alloc>
    907b:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    9080:	48 89 18             	mov    %rbx,(%rax)
    9083:	49 89 c4             	mov    %rax,%r12
    9086:	31 c0                	xor    %eax,%eax
    9088:	48 85 db             	test   %rbx,%rbx
    908b:	74 25                	je     90b2 <f12+0x752>
    908d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9094:	00 
    9095:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    909c:	00 00 00 00 
    90a0:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    90a4:	49 89 54 c4 08       	mov    %rdx,0x8(%r12,%rax,8)
    90a9:	48 83 c0 01          	add    $0x1,%rax
    90ad:	48 39 c3             	cmp    %rax,%rbx
    90b0:	75 ee                	jne    90a0 <f12+0x740>
    90b2:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
    90b9:	00 
    90ba:	48 8b 3c 24          	mov    (%rsp),%rdi
    90be:	4c 89 2d 13 54 06 00 	mov    %r13,0x65413(%rip)        # 6e4d8 <fwp_cleanups>
    90c5:	e8 96 c1 ff ff       	call   5260 <fwp_tape_buffers_release>
    90ca:	48 8b 15 47 4b 06 00 	mov    0x64b47(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    90d1:	4c 89 e0             	mov    %r12,%rax
    90d4:	48 2b 05 15 4b 06 00 	sub    0x64b15(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    90db:	48 c1 e2 10          	shl    $0x10,%rdx
    90df:	48 39 d0             	cmp    %rdx,%rax
    90e2:	73 55                	jae    9139 <f12+0x7d9>
    90e4:	48 89 c2             	mov    %rax,%rdx
    90e7:	48 c1 ea 10          	shr    $0x10,%rdx
    90eb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    90ef:	48 8b 15 42 4b 06 00 	mov    0x64b42(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    90f6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    90fa:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    90fe:	48 85 db             	test   %rbx,%rbx
    9101:	74 36                	je     9139 <f12+0x7d9>
    9103:	0f b6 0a             	movzbl (%rdx),%ecx
    9106:	80 f9 02             	cmp    $0x2,%cl
    9109:	0f 84 61 08 00 00    	je     9970 <f12+0x1010>
    910f:	80 f9 01             	cmp    $0x1,%cl
    9112:	75 25                	jne    9139 <f12+0x7d9>
    9114:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9117:	0f b7 c0             	movzwl %ax,%eax
    911a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    911d:	48 0f af c1          	imul   %rcx,%rax
    9121:	48 c1 e8 20          	shr    $0x20,%rax
    9125:	48 39 d0             	cmp    %rdx,%rax
    9128:	73 0f                	jae    9139 <f12+0x7d9>
    912a:	48 01 c3             	add    %rax,%rbx
    912d:	80 3b ff             	cmpb   $0xff,(%rbx)
    9130:	0f 84 9d 0a 00 00    	je     9bd3 <f12+0x1273>
    9136:	c6 03 01             	movb   $0x1,(%rbx)
    9139:	4c 3b 6c 24 40       	cmp    0x40(%rsp),%r13
    913e:	0f 85 07 a6 ff ff    	jne    374b <f12.cold>
    9144:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    9149:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    914e:	48 89 05 83 53 06 00 	mov    %rax,0x65383(%rip)        # 6e4d8 <fwp_cleanups>
    9155:	e8 86 e3 ff ff       	call   74e0 <fwp_tape_scope_release>
    915a:	49 8b 04 24          	mov    (%r12),%rax
    915e:	49 89 c6             	mov    %rax,%r14
    9161:	49 0f ba f6 3f       	btr    $0x3f,%r14
    9166:	48 85 c0             	test   %rax,%rax
    9169:	0f 88 51 05 00 00    	js     96c0 <f12+0xd60>
    916f:	48 8b 15 a2 4a 06 00 	mov    0x64aa2(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    9176:	4c 89 e0             	mov    %r12,%rax
    9179:	48 2b 05 70 4a 06 00 	sub    0x64a70(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    9180:	48 c1 e2 10          	shl    $0x10,%rdx
    9184:	48 39 d0             	cmp    %rdx,%rax
    9187:	0f 83 33 05 00 00    	jae    96c0 <f12+0xd60>
    918d:	48 89 c2             	mov    %rax,%rdx
    9190:	48 c1 ea 10          	shr    $0x10,%rdx
    9194:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9198:	48 8b 15 99 4a 06 00 	mov    0x64a99(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    919f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    91a3:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    91a7:	48 85 c9             	test   %rcx,%rcx
    91aa:	0f 84 10 05 00 00    	je     96c0 <f12+0xd60>
    91b0:	0f b6 32             	movzbl (%rdx),%esi
    91b3:	40 80 fe 02          	cmp    $0x2,%sil
    91b7:	0f 84 f3 04 00 00    	je     96b0 <f12+0xd50>
    91bd:	40 80 fe 01          	cmp    $0x1,%sil
    91c1:	0f 85 f9 04 00 00    	jne    96c0 <f12+0xd60>
    91c7:	8b 72 18             	mov    0x18(%rdx),%esi
    91ca:	0f b7 c0             	movzwl %ax,%eax
    91cd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    91d0:	48 0f af c6          	imul   %rsi,%rax
    91d4:	48 c1 e8 20          	shr    $0x20,%rax
    91d8:	48 39 d0             	cmp    %rdx,%rax
    91db:	0f 83 df 04 00 00    	jae    96c0 <f12+0xd60>
    91e1:	48 01 c1             	add    %rax,%rcx
    91e4:	80 39 01             	cmpb   $0x1,(%rcx)
    91e7:	0f 85 d3 04 00 00    	jne    96c0 <f12+0xd60>
    91ed:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
    91f2:	4d 89 e5             	mov    %r12,%r13
    91f5:	31 ff                	xor    %edi,%edi
    91f7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    91fc:	f2 0f 10 0d ec 7b 00 	movsd  0x7bec(%rip),%xmm1        # 10df0 <msg.4+0xc0>
    9203:	00 
    9204:	48 8d 50 08          	lea    0x8(%rax),%rdx
    9208:	31 c0                	xor    %eax,%eax
    920a:	4d 85 f6             	test   %r14,%r14
    920d:	75 2f                	jne    923e <f12+0x8de>
    920f:	eb 5f                	jmp    9270 <f12+0x910>
    9211:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9218:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    921d:	0f 88 3d 0a 00 00    	js     9c60 <f12+0x1300>
    9223:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    9228:	48 83 c0 01          	add    $0x1,%rax
    922c:	48 83 c2 08          	add    $0x8,%rdx
    9230:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    9234:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    9239:	49 39 c6             	cmp    %rax,%r14
    923c:	74 32                	je     9270 <f12+0x910>
    923e:	49 8d 4c 24 08       	lea    0x8(%r12),%rcx
    9243:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    9248:	79 ce                	jns    9218 <f12+0x8b8>
    924a:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
    924f:	eb c7                	jmp    9218 <f12+0x8b8>
    9251:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9258:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    925c:	0f 84 7a f9 ff ff    	je     8bdc <f12+0x27c>
    9262:	e9 67 f9 ff ff       	jmp    8bce <f12+0x26e>
    9267:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    926e:	00 00 
    9270:	e8 2b e8 ff ff       	call   7aa0 <fwp_drop4>
    9275:	48 89 e8             	mov    %rbp,%rax
    9278:	31 d2                	xor    %edx,%edx
    927a:	48 85 ed             	test   %rbp,%rbp
    927d:	0f 84 d7 08 00 00    	je     9b5a <f12+0x11fa>
    9283:	66 90                	xchg   %ax,%ax
    9285:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    928c:	00 00 00 00 
    9290:	48 8b 40 10          	mov    0x10(%rax),%rax
    9294:	48 83 c2 01          	add    $0x1,%rdx
    9298:	48 85 c0             	test   %rax,%rax
    929b:	75 f3                	jne    9290 <f12+0x930>
    929d:	49 8b 45 00          	mov    0x0(%r13),%rax
    92a1:	49 89 c7             	mov    %rax,%r15
    92a4:	49 0f ba f7 3f       	btr    $0x3f,%r15
    92a9:	48 85 c0             	test   %rax,%rax
    92ac:	0f 88 60 03 00 00    	js     9612 <f12+0xcb2>
    92b2:	48 8b 05 5f 49 06 00 	mov    0x6495f(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    92b9:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    92be:	48 2b 0d 2b 49 06 00 	sub    0x6492b(%rip),%rcx        # 6dbf0 <fwp_heap+0x13b0>
    92c5:	48 c1 e0 10          	shl    $0x10,%rax
    92c9:	48 39 c1             	cmp    %rax,%rcx
    92cc:	0f 83 40 03 00 00    	jae    9612 <f12+0xcb2>
    92d2:	48 89 c8             	mov    %rcx,%rax
    92d5:	48 c1 e8 10          	shr    $0x10,%rax
    92d9:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    92dd:	48 8b 05 54 49 06 00 	mov    0x64954(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    92e4:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    92e8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    92ec:	48 85 ff             	test   %rdi,%rdi
    92ef:	0f 84 1d 03 00 00    	je     9612 <f12+0xcb2>
    92f5:	0f b6 06             	movzbl (%rsi),%eax
    92f8:	3c 02                	cmp    $0x2,%al
    92fa:	0f 84 00 03 00 00    	je     9600 <f12+0xca0>
    9300:	3c 01                	cmp    $0x1,%al
    9302:	0f 85 01 03 00 00    	jne    9609 <f12+0xca9>
    9308:	8b 46 18             	mov    0x18(%rsi),%eax
    930b:	0f b7 c9             	movzwl %cx,%ecx
    930e:	48 0f af c8          	imul   %rax,%rcx
    9312:	8b 46 1c             	mov    0x1c(%rsi),%eax
    9315:	48 c1 e9 20          	shr    $0x20,%rcx
    9319:	48 39 c1             	cmp    %rax,%rcx
    931c:	0f 83 e7 02 00 00    	jae    9609 <f12+0xca9>
    9322:	48 01 cf             	add    %rcx,%rdi
    9325:	80 3f 01             	cmpb   $0x1,(%rdi)
    9328:	0f 85 db 02 00 00    	jne    9609 <f12+0xca9>
    932e:	49 39 d7             	cmp    %rdx,%r15
    9331:	48 89 d0             	mov    %rdx,%rax
    9334:	49 0f 46 c7          	cmovbe %r15,%rax
    9338:	48 85 c0             	test   %rax,%rax
    933b:	0f 84 2b 09 00 00    	je     9c6c <f12+0x130c>
    9341:	c7 44 24 40 01 00 00 	movl   $0x1,0x40(%rsp)
    9348:	00 
    9349:	4d 8d 75 08          	lea    0x8(%r13),%r14
    934d:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    9352:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    9359:	00 
    935a:	48 89 e9             	mov    %rbp,%rcx
    935d:	31 d2                	xor    %edx,%edx
    935f:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    9363:	eb 38                	jmp    939d <f12+0xa3d>
    9365:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    936a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9371:	00 00 00 00 
    9375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    937c:	00 00 00 00 
    9380:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9385:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    938a:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    9390:	48 83 c2 08          	add    $0x8,%rdx
    9394:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9398:	49 39 d0             	cmp    %rdx,%r8
    939b:	74 1b                	je     93b8 <f12+0xa58>
    939d:	48 89 fe             	mov    %rdi,%rsi
    93a0:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    93a5:	79 d9                	jns    9380 <f12+0xa20>
    93a7:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    93ac:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    93b0:	eb ce                	jmp    9380 <f12+0xa20>
    93b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    93b8:	48 85 ed             	test   %rbp,%rbp
    93bb:	0f 84 7a 08 00 00    	je     9c3b <f12+0x12db>
    93c1:	4c 8b 05 50 48 06 00 	mov    0x64850(%rip),%r8        # 6dc18 <fwp_heap+0x13d8>
    93c8:	4c 8b 0d 21 48 06 00 	mov    0x64821(%rip),%r9        # 6dbf0 <fwp_heap+0x13b0>
    93cf:	48 89 e9             	mov    %rbp,%rcx
    93d2:	45 31 ed             	xor    %r13d,%r13d
    93d5:	4c 8b 15 5c 48 06 00 	mov    0x6485c(%rip),%r10        # 6dc38 <fwp_heap+0x13f8>
    93dc:	49 c1 e0 10          	shl    $0x10,%r8
    93e0:	eb 1c                	jmp    93fe <f12+0xa9e>
    93e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    93e8:	49 83 c5 01          	add    $0x1,%r13
    93ec:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    93f0:	49 39 c5             	cmp    %rax,%r13
    93f3:	0f 83 67 01 00 00    	jae    9560 <f12+0xc00>
    93f9:	48 85 c9             	test   %rcx,%rcx
    93fc:	74 56                	je     9454 <f12+0xaf4>
    93fe:	48 89 ca             	mov    %rcx,%rdx
    9401:	4c 29 ca             	sub    %r9,%rdx
    9404:	4c 39 c2             	cmp    %r8,%rdx
    9407:	73 4b                	jae    9454 <f12+0xaf4>
    9409:	48 89 d6             	mov    %rdx,%rsi
    940c:	48 c1 ee 10          	shr    $0x10,%rsi
    9410:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    9414:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    9418:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    941c:	48 85 ff             	test   %rdi,%rdi
    941f:	74 33                	je     9454 <f12+0xaf4>
    9421:	44 0f b6 1e          	movzbl (%rsi),%r11d
    9425:	41 80 fb 02          	cmp    $0x2,%r11b
    9429:	0f 84 19 01 00 00    	je     9548 <f12+0xbe8>
    942f:	41 80 fb 01          	cmp    $0x1,%r11b
    9433:	75 1f                	jne    9454 <f12+0xaf4>
    9435:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    9439:	0f b7 d2             	movzwl %dx,%edx
    943c:	8b 76 1c             	mov    0x1c(%rsi),%esi
    943f:	49 0f af d3          	imul   %r11,%rdx
    9443:	48 c1 ea 20          	shr    $0x20,%rdx
    9447:	48 39 f2             	cmp    %rsi,%rdx
    944a:	73 08                	jae    9454 <f12+0xaf4>
    944c:	48 01 d7             	add    %rdx,%rdi
    944f:	80 3f 01             	cmpb   $0x1,(%rdi)
    9452:	74 94                	je     93e8 <f12+0xa88>
    9454:	49 39 c5             	cmp    %rax,%r13
    9457:	0f 83 03 01 00 00    	jae    9560 <f12+0xc00>
    945d:	49 89 c7             	mov    %rax,%r15
    9460:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
    9467:	00 
    9468:	45 31 e4             	xor    %r12d,%r12d
    946b:	48 89 04 24          	mov    %rax,(%rsp)
    946f:	48 8d 1d ca 33 06 00 	lea    0x633ca(%rip),%rbx        # 6c840 <fwp_heap>
    9476:	eb 3a                	jmp    94b2 <f12+0xb52>
    9478:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    947f:	00 
    9480:	41 80 f9 01          	cmp    $0x1,%r9b
    9484:	75 27                	jne    94ad <f12+0xb4d>
    9486:	45 8b 48 18          	mov    0x18(%r8),%r9d
    948a:	0f b7 c0             	movzwl %ax,%eax
    948d:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    9491:	49 0f af c1          	imul   %r9,%rax
    9495:	48 c1 e8 20          	shr    $0x20,%rax
    9499:	4c 39 c0             	cmp    %r8,%rax
    949c:	73 0f                	jae    94ad <f12+0xb4d>
    949e:	48 01 c7             	add    %rax,%rdi
    94a1:	80 3f ff             	cmpb   $0xff,(%rdi)
    94a4:	0f 84 46 03 00 00    	je     97f0 <f12+0xe90>
    94aa:	c6 07 01             	movb   $0x1,(%rdi)
    94ad:	4d 39 fd             	cmp    %r15,%r13
    94b0:	73 7e                	jae    9530 <f12+0xbd0>
    94b2:	49 83 ef 01          	sub    $0x1,%r15
    94b6:	66 49 0f 6e f4       	movq   %r12,%xmm6
    94bb:	48 8b 34 24          	mov    (%rsp),%rsi
    94bf:	bf 01 00 00 00       	mov    $0x1,%edi
    94c4:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    94ca:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    94ce:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    94d5:	00 
    94d6:	e8 65 d3 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    94db:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    94e2:	49 89 c4             	mov    %rax,%r12
    94e5:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    94ec:	48 c1 e7 10          	shl    $0x10,%rdi
    94f0:	48 39 f8             	cmp    %rdi,%rax
    94f3:	73 b8                	jae    94ad <f12+0xb4d>
    94f5:	48 89 c7             	mov    %rax,%rdi
    94f8:	48 c1 ef 10          	shr    $0x10,%rdi
    94fc:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    9500:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    9507:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    950b:	49 8b 78 20          	mov    0x20(%r8),%rdi
    950f:	48 85 ff             	test   %rdi,%rdi
    9512:	74 99                	je     94ad <f12+0xb4d>
    9514:	45 0f b6 08          	movzbl (%r8),%r9d
    9518:	41 80 f9 02          	cmp    $0x2,%r9b
    951c:	0f 85 5e ff ff ff    	jne    9480 <f12+0xb20>
    9522:	66 85 c0             	test   %ax,%ax
    9525:	0f 84 76 ff ff ff    	je     94a1 <f12+0xb41>
    952b:	4d 39 fd             	cmp    %r15,%r13
    952e:	72 82                	jb     94b2 <f12+0xb52>
    9530:	4d 85 ed             	test   %r13,%r13
    9533:	75 2e                	jne    9563 <f12+0xc03>
    9535:	8b 44 24 40          	mov    0x40(%rsp),%eax
    9539:	85 c0                	test   %eax,%eax
    953b:	4d 0f 45 f5          	cmovne %r13,%r14
    953f:	eb 6f                	jmp    95b0 <f12+0xc50>
    9541:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9548:	66 85 d2             	test   %dx,%dx
    954b:	0f 84 fe fe ff ff    	je     944f <f12+0xaef>
    9551:	49 39 c5             	cmp    %rax,%r13
    9554:	0f 82 03 ff ff ff    	jb     945d <f12+0xafd>
    955a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9560:	45 31 e4             	xor    %r12d,%r12d
    9563:	4c 89 f2             	mov    %r14,%rdx
    9566:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    956a:	48 89 e8             	mov    %rbp,%rax
    956d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9574:	00 
    9575:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    957c:	00 00 00 00 
    9580:	48 8b 0a             	mov    (%rdx),%rcx
    9583:	48 83 c2 08          	add    $0x8,%rdx
    9587:	48 89 c7             	mov    %rax,%rdi
    958a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    958e:	48 8b 40 10          	mov    0x10(%rax),%rax
    9592:	49 39 d0             	cmp    %rdx,%r8
    9595:	75 e9                	jne    9580 <f12+0xc20>
    9597:	8b 54 24 40          	mov    0x40(%rsp),%edx
    959b:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    959f:	85 d2                	test   %edx,%edx
    95a1:	0f 84 d9 03 00 00    	je     9980 <f12+0x1020>
    95a7:	49 89 ec             	mov    %rbp,%r12
    95aa:	45 31 f6             	xor    %r14d,%r14d
    95ad:	48 89 c5             	mov    %rax,%rbp
    95b0:	4c 89 f7             	mov    %r14,%rdi
    95b3:	e8 58 c4 ff ff       	call   5a10 <fwp_mem_free>
    95b8:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    95bd:	e8 de e4 ff ff       	call   7aa0 <fwp_drop4>
    95c2:	48 89 ef             	mov    %rbp,%rdi
    95c5:	e8 c6 d8 ff ff       	call   6e90 <fwp_drop0>
    95ca:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
    95d1:	00 
    95d2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    95d9:	00 00 
    95db:	0f 85 21 07 00 00    	jne    9d02 <f12+0x13a2>
    95e1:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
    95e8:	4c 89 e0             	mov    %r12,%rax
    95eb:	5b                   	pop    %rbx
    95ec:	5d                   	pop    %rbp
    95ed:	41 5c                	pop    %r12
    95ef:	41 5d                	pop    %r13
    95f1:	41 5e                	pop    %r14
    95f3:	41 5f                	pop    %r15
    95f5:	c3                   	ret
    95f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    95fd:	00 00 00 
    9600:	66 85 c9             	test   %cx,%cx
    9603:	0f 84 1c fd ff ff    	je     9325 <f12+0x9c5>
    9609:	48 85 ed             	test   %rbp,%rbp
    960c:	0f 84 2b 04 00 00    	je     9a3d <f12+0x10dd>
    9612:	48 89 e8             	mov    %rbp,%rax
    9615:	45 31 e4             	xor    %r12d,%r12d
    9618:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    961f:	00 
    9620:	48 8b 40 10          	mov    0x10(%rax),%rax
    9624:	4c 89 e2             	mov    %r12,%rdx
    9627:	49 83 c4 01          	add    $0x1,%r12
    962b:	48 85 c0             	test   %rax,%rax
    962e:	75 f0                	jne    9620 <f12+0xcc0>
    9630:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9637:	ff ff 1f 
    963a:	4c 39 e0             	cmp    %r12,%rax
    963d:	0f 82 83 06 00 00    	jb     9cc6 <f12+0x1366>
    9643:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    964a:	00 
    964b:	be 02 00 00 00       	mov    $0x2,%esi
    9650:	e8 bb c8 ff ff       	call   5f10 <fwp_heap_alloc>
    9655:	4d 39 e7             	cmp    %r12,%r15
    9658:	48 89 ea             	mov    %rbp,%rdx
    965b:	49 89 c6             	mov    %rax,%r14
    965e:	4c 89 e0             	mov    %r12,%rax
    9661:	49 0f 46 c7          	cmovbe %r15,%rax
    9665:	4c 89 f1             	mov    %r14,%rcx
    9668:	66 90                	xchg   %ax,%ax
    966a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9671:	00 00 00 00 
    9675:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    967c:	00 00 00 00 
    9680:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    9684:	48 83 c1 08          	add    $0x8,%rcx
    9688:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    968c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9690:	48 85 d2             	test   %rdx,%rdx
    9693:	75 eb                	jne    9680 <f12+0xd20>
    9695:	48 85 c0             	test   %rax,%rax
    9698:	0f 84 b1 03 00 00    	je     9a4f <f12+0x10ef>
    969e:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
    96a5:	00 
    96a6:	e9 a2 fc ff ff       	jmp    934d <f12+0x9ed>
    96ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    96b0:	66 85 c0             	test   %ax,%ax
    96b3:	0f 84 2b fb ff ff    	je     91e4 <f12+0x884>
    96b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    96c0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    96c7:	ff ff 1f 
    96ca:	4c 39 f0             	cmp    %r14,%rax
    96cd:	0f 82 ff 05 00 00    	jb     9cd2 <f12+0x1372>
    96d3:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    96da:	00 
    96db:	be 01 00 00 00       	mov    $0x1,%esi
    96e0:	e8 2b c8 ff ff       	call   5f10 <fwp_heap_alloc>
    96e5:	4c 89 30             	mov    %r14,(%rax)
    96e8:	48 8b 15 29 45 06 00 	mov    0x64529(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    96ef:	49 89 c5             	mov    %rax,%r13
    96f2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    96f7:	48 2b 05 f2 44 06 00 	sub    0x644f2(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    96fe:	48 c1 e2 10          	shl    $0x10,%rdx
    9702:	48 39 d0             	cmp    %rdx,%rax
    9705:	73 57                	jae    975e <f12+0xdfe>
    9707:	48 89 c2             	mov    %rax,%rdx
    970a:	48 c1 ea 10          	shr    $0x10,%rdx
    970e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9712:	48 8b 15 1f 45 06 00 	mov    0x6451f(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    9719:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    971d:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    9721:	4d 85 ff             	test   %r15,%r15
    9724:	74 38                	je     975e <f12+0xdfe>
    9726:	0f b6 0a             	movzbl (%rdx),%ecx
    9729:	80 f9 02             	cmp    $0x2,%cl
    972c:	0f 84 2e 03 00 00    	je     9a60 <f12+0x1100>
    9732:	80 f9 01             	cmp    $0x1,%cl
    9735:	75 27                	jne    975e <f12+0xdfe>
    9737:	8b 4a 18             	mov    0x18(%rdx),%ecx
    973a:	0f b7 c0             	movzwl %ax,%eax
    973d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9740:	48 0f af c1          	imul   %rcx,%rax
    9744:	48 c1 e8 20          	shr    $0x20,%rax
    9748:	48 39 d0             	cmp    %rdx,%rax
    974b:	73 11                	jae    975e <f12+0xdfe>
    974d:	49 01 c7             	add    %rax,%r15
    9750:	41 80 3f ff          	cmpb   $0xff,(%r15)
    9754:	0f 84 86 04 00 00    	je     9be0 <f12+0x1280>
    975a:	41 c6 07 01          	movb   $0x1,(%r15)
    975e:	4c 89 e7             	mov    %r12,%rdi
    9761:	e9 91 fa ff ff       	jmp    91f7 <f12+0x897>
    9766:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    976d:	00 00 00 
    9770:	48 c1 e6 10          	shl    $0x10,%rsi
    9774:	bf 08 00 00 00       	mov    $0x8,%edi
    9779:	49 09 f5             	or     %rsi,%r13
    977c:	be 02 00 00 00       	mov    $0x2,%esi
    9781:	e8 8a c7 ff ff       	call   5f10 <fwp_heap_alloc>
    9786:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    978d:	48 8b 15 84 44 06 00 	mov    0x64484(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    9794:	48 89 c3             	mov    %rax,%rbx
    9797:	48 2b 05 52 44 06 00 	sub    0x64452(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    979e:	48 c1 e2 10          	shl    $0x10,%rdx
    97a2:	48 39 d0             	cmp    %rdx,%rax
    97a5:	0f 83 14 f6 ff ff    	jae    8dbf <f12+0x45f>
    97ab:	48 89 c2             	mov    %rax,%rdx
    97ae:	48 c1 ea 10          	shr    $0x10,%rdx
    97b2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    97b6:	48 8b 15 7b 44 06 00 	mov    0x6447b(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    97bd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    97c1:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    97c5:	4d 85 f6             	test   %r14,%r14
    97c8:	0f 84 e5 f5 ff ff    	je     8db3 <f12+0x453>
    97ce:	0f b6 0a             	movzbl (%rdx),%ecx
    97d1:	45 31 e4             	xor    %r12d,%r12d
    97d4:	80 f9 02             	cmp    $0x2,%cl
    97d7:	0f 85 39 f5 ff ff    	jne    8d16 <f12+0x3b6>
    97dd:	66 85 c0             	test   %ax,%ax
    97e0:	0f 85 5c f5 ff ff    	jne    8d42 <f12+0x3e2>
    97e6:	e9 49 f5 ff ff       	jmp    8d34 <f12+0x3d4>
    97eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    97f0:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
    97f5:	e8 d6 bf ff ff       	call   57d0 <fwp_rc_forget_slot>
    97fa:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    97ff:	e9 a6 fc ff ff       	jmp    94aa <f12+0xb4a>
    9804:	0f 1f 40 00          	nopl   0x0(%rax)
    9808:	4c 8d 60 ff          	lea    -0x1(%rax),%r12
    980c:	4c 89 e1             	mov    %r12,%rcx
    980f:	48 c1 e9 3c          	shr    $0x3c,%rcx
    9813:	0f 85 ad 04 00 00    	jne    9cc6 <f12+0x1366>
    9819:	4d 85 e4             	test   %r12,%r12
    981c:	0f 84 9d f5 ff ff    	je     8dbf <f12+0x45f>
    9822:	48 c1 e0 04          	shl    $0x4,%rax
    9826:	4d 01 e4             	add    %r12,%r12
    9829:	4c 8d 7b 08          	lea    0x8(%rbx),%r15
    982d:	4c 8d 74 03 f8       	lea    -0x8(%rbx,%rax,1),%r14
    9832:	0f 1f 00             	nopl   (%rax)
    9835:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    983c:	00 00 00 00 
    9840:	f2 41 0f 10 07       	movsd  (%r15),%xmm0
    9845:	49 8b 77 18          	mov    0x18(%r15),%rsi
    9849:	49 83 c7 10          	add    $0x10,%r15
    984d:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
    9851:	f2 41 0f 10 0f       	movsd  (%r15),%xmm1
    9856:	e8 75 ce ff ff       	call   66d0 <w107>
    985b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    9860:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    9864:	41 0f 11 47 f0       	movups %xmm0,-0x10(%r15)
    9869:	4d 39 fe             	cmp    %r15,%r14
    986c:	75 d2                	jne    9840 <f12+0xee0>
    986e:	4c 89 23             	mov    %r12,(%rbx)
    9871:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    9878:	45 31 f6             	xor    %r14d,%r14d
    987b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9880:	4a 8b 54 f3 10       	mov    0x10(%rbx,%r14,8),%rdx
    9885:	4c 89 ff             	mov    %r15,%rdi
    9888:	49 83 c6 02          	add    $0x2,%r14
    988c:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    9893:	00 f0 3f 
    9896:	48 89 ce             	mov    %rcx,%rsi
    9899:	e8 b2 ca ff ff       	call   6350 <fwp_p_ad_push>
    989e:	49 89 c7             	mov    %rax,%r15
    98a1:	4d 39 e6             	cmp    %r12,%r14
    98a4:	72 da                	jb     9880 <f12+0xf20>
    98a6:	e9 25 f5 ff ff       	jmp    8dd0 <f12+0x470>
    98ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    98b0:	4c 8d 61 01          	lea    0x1(%rcx),%r12
    98b4:	4d 39 e6             	cmp    %r12,%r14
    98b7:	0f 8c 52 f6 ff ff    	jl     8f0f <f12+0x5af>
    98bd:	4d 85 c0             	test   %r8,%r8
    98c0:	0f 84 ba 03 00 00    	je     9c80 <f12+0x1320>
    98c6:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
    98cb:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    98d2:	00 
    98d3:	31 f6                	xor    %esi,%esi
    98d5:	4c 89 c7             	mov    %r8,%rdi
    98d8:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    98dd:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    98e2:	e8 c9 9b ff ff       	call   34b0 <memset@plt>
    98e7:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    98ed:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    98f3:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
    98f8:	49 89 c0             	mov    %rax,%r8
    98fb:	e9 a2 f6 ff ff       	jmp    8fa2 <f12+0x642>
    9900:	48 8d 3d b9 da ff ff 	lea    -0x2547(%rip),%rdi        # 73c0 <fwp_tape_finish>
    9907:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    990c:	e8 7f 59 00 00       	call   f290 <atexit>
    9911:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    9916:	85 c0                	test   %eax,%eax
    9918:	0f 85 7a 03 00 00    	jne    9c98 <f12+0x1338>
    991e:	c7 05 58 a7 00 00 01 	movl   $0x1,0xa758(%rip)        # 14080 <registered_finish.0>
    9925:	00 00 00 
    9928:	e9 70 f1 ff ff       	jmp    8a9d <f12+0x13d>
    992d:	0f 1f 00             	nopl   (%rax)
    9930:	66 85 c0             	test   %ax,%ax
    9933:	0f 85 17 f1 ff ff    	jne    8a50 <f12+0xf0>
    9939:	e9 ee f0 ff ff       	jmp    8a2c <f12+0xcc>
    993e:	66 90                	xchg   %ax,%ax
    9940:	4c 39 f3             	cmp    %r14,%rbx
    9943:	0f 8f c3 f5 ff ff    	jg     8f0c <f12+0x5ac>
    9949:	48 85 db             	test   %rbx,%rbx
    994c:	74 12                	je     9960 <f12+0x1000>
    994e:	4d 85 c0             	test   %r8,%r8
    9951:	0f 84 29 03 00 00    	je     9c80 <f12+0x1320>
    9957:	48 85 db             	test   %rbx,%rbx
    995a:	0f 85 97 02 00 00    	jne    9bf7 <f12+0x1297>
    9960:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    9967:	e9 4a f6 ff ff       	jmp    8fb6 <f12+0x656>
    996c:	0f 1f 40 00          	nopl   0x0(%rax)
    9970:	66 85 c0             	test   %ax,%ax
    9973:	0f 85 c0 f7 ff ff    	jne    9139 <f12+0x7d9>
    9979:	e9 af f7 ff ff       	jmp    912d <f12+0x7cd>
    997e:	66 90                	xchg   %ax,%ax
    9980:	49 89 ec             	mov    %rbp,%r12
    9983:	48 89 c5             	mov    %rax,%rbp
    9986:	e9 25 fc ff ff       	jmp    95b0 <f12+0xc50>
    998b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9990:	66 0f 6f 0d 28 a7 01 	movdqa 0x1a728(%rip),%xmm1        # 240c0 <fwp_tape_workspace>
    9997:	00 
    9998:	48 c7 05 05 a7 01 00 	movq   $0x0,0x1a705(%rip)        # 240a8 <fwp_tape_cached_bytes>
    999f:	00 00 00 00 
    99a3:	41 0f 11 4e 20       	movups %xmm1,0x20(%r14)
    99a8:	48 8b 05 31 a7 01 00 	mov    0x1a731(%rip),%rax        # 240e0 <fwp_tape_workspace+0x20>
    99af:	66 0f 6f 0d 19 a7 01 	movdqa 0x1a719(%rip),%xmm1        # 240d0 <fwp_tape_workspace+0x10>
    99b6:	00 
    99b7:	49 89 46 40          	mov    %rax,0x40(%r14)
    99bb:	48 8b 05 26 a7 01 00 	mov    0x1a726(%rip),%rax        # 240e8 <fwp_tape_workspace+0x28>
    99c2:	41 0f 11 4e 30       	movups %xmm1,0x30(%r14)
    99c7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    99cb:	49 89 46 18          	mov    %rax,0x18(%r14)
    99cf:	48 8b 05 1a a7 01 00 	mov    0x1a71a(%rip),%rax        # 240f0 <fwp_tape_workspace+0x30>
    99d6:	0f 29 0d e3 a6 01 00 	movaps %xmm1,0x1a6e3(%rip)        # 240c0 <fwp_tape_workspace>
    99dd:	49 89 46 48          	mov    %rax,0x48(%r14)
    99e1:	0f 29 0d e8 a6 01 00 	movaps %xmm1,0x1a6e8(%rip)        # 240d0 <fwp_tape_workspace+0x10>
    99e8:	48 c7 05 fd a6 01 00 	movq   $0x0,0x1a6fd(%rip)        # 240f0 <fwp_tape_workspace+0x30>
    99ef:	00 00 00 00 
    99f3:	0f 29 0d e6 a6 01 00 	movaps %xmm1,0x1a6e6(%rip)        # 240e0 <fwp_tape_workspace+0x20>
    99fa:	e9 dd f1 ff ff       	jmp    8bdc <f12+0x27c>
    99ff:	90                   	nop
    9a00:	4d 85 c0             	test   %r8,%r8
    9a03:	0f 84 77 02 00 00    	je     9c80 <f12+0x1320>
    9a09:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
    9a0e:	4c 8d 6b ff          	lea    -0x1(%rbx),%r13
    9a12:	31 f6                	xor    %esi,%esi
    9a14:	4c 89 c7             	mov    %r8,%rdi
    9a17:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    9a1c:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    9a23:	00 
    9a24:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    9a29:	e9 b4 fe ff ff       	jmp    98e2 <f12+0xf82>
    9a2e:	66 90                	xchg   %ax,%ax
    9a30:	48 83 05 b8 4a 06 00 	addq   $0x1,0x64ab8(%rip)        # 6e4f0 <iteration_retains>
    9a37:	01 
    9a38:	e9 06 f0 ff ff       	jmp    8a43 <f12+0xe3>
    9a3d:	be 02 00 00 00       	mov    $0x2,%esi
    9a42:	bf 08 00 00 00       	mov    $0x8,%edi
    9a47:	e8 c4 c4 ff ff       	call   5f10 <fwp_heap_alloc>
    9a4c:	49 89 c6             	mov    %rax,%r14
    9a4f:	45 31 e4             	xor    %r12d,%r12d
    9a52:	e9 59 fb ff ff       	jmp    95b0 <f12+0xc50>
    9a57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9a5e:	00 00 
    9a60:	66 85 c0             	test   %ax,%ax
    9a63:	0f 85 f5 fc ff ff    	jne    975e <f12+0xdfe>
    9a69:	e9 e2 fc ff ff       	jmp    9750 <f12+0xdf0>
    9a6e:	66 90                	xchg   %ax,%ax
    9a70:	4d 85 e4             	test   %r12,%r12
    9a73:	0f 85 ce f2 ff ff    	jne    8d47 <f12+0x3e7>
    9a79:	e9 41 f3 ff ff       	jmp    8dbf <f12+0x45f>
    9a7e:	66 90                	xchg   %ax,%ax
    9a80:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    9a87:	ff ff 1f 
    9a8a:	49 8d 46 ff          	lea    -0x1(%r14),%rax
    9a8e:	48 39 c2             	cmp    %rax,%rdx
    9a91:	0f 82 47 02 00 00    	jb     9cde <f12+0x137e>
    9a97:	48 8d 05 42 a7 04 00 	lea    0x4a742(%rip),%rax        # 541e0 <ad_raw_blocks>
    9a9e:	45 31 ed             	xor    %r13d,%r13d
    9aa1:	eb 32                	jmp    9ad5 <f12+0x1175>
    9aa3:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9aaa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9ab1:	00 00 00 00 
    9ab5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9abc:	00 00 00 00 
    9ac0:	49 83 c5 01          	add    $0x1,%r13
    9ac4:	48 83 c0 18          	add    $0x18,%rax
    9ac8:	49 81 fd 00 10 00 00 	cmp    $0x1000,%r13
    9acf:	0f 84 5a 01 00 00    	je     9c2f <f12+0x12cf>
    9ad5:	48 83 38 00          	cmpq   $0x0,(%rax)
    9ad9:	75 e5                	jne    9ac0 <f12+0x1160>
    9adb:	be 08 00 00 00       	mov    $0x8,%esi
    9ae0:	4c 89 f7             	mov    %r14,%rdi
    9ae3:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    9ae8:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    9aed:	e8 1e 9a ff ff       	call   3510 <calloc@plt>
    9af2:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    9af8:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    9afe:	48 8d 15 db a6 04 00 	lea    0x4a6db(%rip),%rdx        # 541e0 <ad_raw_blocks>
    9b05:	48 85 c0             	test   %rax,%rax
    9b08:	74 36                	je     9b40 <f12+0x11e0>
    9b0a:	4b 8d 4c 6d 00       	lea    0x0(%r13,%r13,2),%rcx
    9b0f:	48 89 c6             	mov    %rax,%rsi
    9b12:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9b17:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    9b1b:	b9 03 00 00 00       	mov    $0x3,%ecx
    9b20:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    9b27:	00 
    9b28:	e8 d3 a0 ff ff       	call   3c00 <ad_raw_record>
    9b2d:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    9b32:	e9 43 f4 ff ff       	jmp    8f7a <f12+0x61a>
    9b37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9b3e:	00 00 
    9b40:	4d 85 e4             	test   %r12,%r12
    9b43:	0f 85 37 01 00 00    	jne    9c80 <f12+0x1320>
    9b49:	45 31 c0             	xor    %r8d,%r8d
    9b4c:	e9 42 f4 ff ff       	jmp    8f93 <f12+0x633>
    9b51:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9b55:	e9 35 ef ff ff       	jmp    8a8f <f12+0x12f>
    9b5a:	49 8b 45 00          	mov    0x0(%r13),%rax
    9b5e:	48 85 c0             	test   %rax,%rax
    9b61:	0f 88 d6 fe ff ff    	js     9a3d <f12+0x10dd>
    9b67:	48 8b 35 aa 40 06 00 	mov    0x640aa(%rip),%rsi        # 6dc18 <fwp_heap+0x13d8>
    9b6e:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    9b73:	48 2b 0d 76 40 06 00 	sub    0x64076(%rip),%rcx        # 6dbf0 <fwp_heap+0x13b0>
    9b7a:	48 c1 e6 10          	shl    $0x10,%rsi
    9b7e:	48 39 f1             	cmp    %rsi,%rcx
    9b81:	0f 83 b6 fe ff ff    	jae    9a3d <f12+0x10dd>
    9b87:	48 89 ce             	mov    %rcx,%rsi
    9b8a:	48 c1 ee 10          	shr    $0x10,%rsi
    9b8e:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9b92:	48 8b 35 9f 40 06 00 	mov    0x6409f(%rip),%rsi        # 6dc38 <fwp_heap+0x13f8>
    9b99:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9b9d:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9ba1:	48 85 ff             	test   %rdi,%rdi
    9ba4:	0f 84 93 fe ff ff    	je     9a3d <f12+0x10dd>
    9baa:	48 0f ba f0 3f       	btr    $0x3f,%rax
    9baf:	49 89 c7             	mov    %rax,%r15
    9bb2:	e9 3e f7 ff ff       	jmp    92f5 <f12+0x995>
    9bb7:	be 68 00 00 00       	mov    $0x68,%esi
    9bbc:	bb 01 00 00 00       	mov    $0x1,%ebx
    9bc1:	e9 55 ef ff ff       	jmp    8b1b <f12+0x1bb>
    9bc6:	4c 89 f7             	mov    %r14,%rdi
    9bc9:	e8 02 bc ff ff       	call   57d0 <fwp_rc_forget_slot>
    9bce:	e9 6b f1 ff ff       	jmp    8d3e <f12+0x3de>
    9bd3:	48 89 df             	mov    %rbx,%rdi
    9bd6:	e8 f5 bb ff ff       	call   57d0 <fwp_rc_forget_slot>
    9bdb:	e9 56 f5 ff ff       	jmp    9136 <f12+0x7d6>
    9be0:	4c 89 ff             	mov    %r15,%rdi
    9be3:	e8 e8 bb ff ff       	call   57d0 <fwp_rc_forget_slot>
    9be8:	e9 6d fb ff ff       	jmp    975a <f12+0xdfa>
    9bed:	e8 be ba ff ff       	call   56b0 <fwp_rc_wide_dup>
    9bf2:	e9 59 ee ff ff       	jmp    8a50 <f12+0xf0>
    9bf7:	49 89 dc             	mov    %rbx,%r12
    9bfa:	4c 89 c7             	mov    %r8,%rdi
    9bfd:	31 f6                	xor    %esi,%esi
    9bff:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    9c04:	4d 8d 6c 24 ff       	lea    -0x1(%r12),%r13
    9c09:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    9c10:	00 
    9c11:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    9c16:	e8 95 98 ff ff       	call   34b0 <memset@plt>
    9c1b:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    9c21:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    9c27:	49 89 c0             	mov    %rax,%r8
    9c2a:	e9 6b f3 ff ff       	jmp    8f9a <f12+0x63a>
    9c2f:	48 8d 3d dc 64 00 00 	lea    0x64dc(%rip),%rdi        # 10112 <_IO_stdin_used+0x112>
    9c36:	e8 c5 a3 ff ff       	call   4000 <ad_raw_fail>
    9c3b:	45 31 ed             	xor    %r13d,%r13d
    9c3e:	e9 1a f8 ff ff       	jmp    945d <f12+0xafd>
    9c43:	48 8d 3d 78 65 00 00 	lea    0x6578(%rip),%rdi        # 101c2 <_IO_stdin_used+0x1c2>
    9c4a:	e8 01 a8 ff ff       	call   4450 <fwp_trap>
    9c4f:	48 8d 3d b2 6d 00 00 	lea    0x6db2(%rip),%rdi        # 10a08 <_IO_stdin_used+0xa08>
    9c56:	e8 f5 a7 ff ff       	call   4450 <fwp_trap>
    9c5b:	e8 a0 9a ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9c60:	48 8d 3d a9 6e 00 00 	lea    0x6ea9(%rip),%rdi        # 10b10 <_IO_stdin_used+0xb10>
    9c67:	e8 e4 a7 ff ff       	call   4450 <fwp_trap>
    9c6c:	45 31 f6             	xor    %r14d,%r14d
    9c6f:	e9 db fd ff ff       	jmp    9a4f <f12+0x10ef>
    9c74:	48 8d 3d 7e 65 00 00 	lea    0x657e(%rip),%rdi        # 101f9 <_IO_stdin_used+0x1f9>
    9c7b:	e8 d0 a7 ff ff       	call   4450 <fwp_trap>
    9c80:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    9c87:	00 
    9c88:	48 8b 3c 24          	mov    (%rsp),%rdi
    9c8c:	48 89 05 45 48 06 00 	mov    %rax,0x64845(%rip)        # 6e4d8 <fwp_cleanups>
    9c93:	e8 c8 b5 ff ff       	call   5260 <fwp_tape_buffers_release>
    9c98:	48 8b 0d c1 a3 00 00 	mov    0xa3c1(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    9c9f:	ba 13 00 00 00       	mov    $0x13,%edx
    9ca4:	be 01 00 00 00       	mov    $0x1,%esi
    9ca9:	48 8d 3d 58 63 00 00 	lea    0x6358(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    9cb0:	e8 ab 99 ff ff       	call   3660 <fwrite@plt>
    9cb5:	31 ff                	xor    %edi,%edi
    9cb7:	e8 e4 98 ff ff       	call   35a0 <fflush@plt>
    9cbc:	bf 66 00 00 00       	mov    $0x66,%edi
    9cc1:	e8 ba 99 ff ff       	call   3680 <_Exit@plt>
    9cc6:	48 8d 3d 1e 65 00 00 	lea    0x651e(%rip),%rdi        # 101eb <_IO_stdin_used+0x1eb>
    9ccd:	e8 7e a7 ff ff       	call   4450 <fwp_trap>
    9cd2:	48 8d 3d 56 65 00 00 	lea    0x6556(%rip),%rdi        # 1022f <_IO_stdin_used+0x22f>
    9cd9:	e8 72 a7 ff ff       	call   4450 <fwp_trap>
    9cde:	48 8d 3d 2e 65 00 00 	lea    0x652e(%rip),%rdi        # 10213 <_IO_stdin_used+0x213>
    9ce5:	e8 16 a3 ff ff       	call   4000 <ad_raw_fail>
    9cea:	48 8d 3d 5f 6d 00 00 	lea    0x6d5f(%rip),%rdi        # 10a50 <_IO_stdin_used+0xa50>
    9cf1:	e8 5a a7 ff ff       	call   4450 <fwp_trap>
    9cf6:	48 8d 3d b3 6d 00 00 	lea    0x6db3(%rip),%rdi        # 10ab0 <_IO_stdin_used+0xab0>
    9cfd:	e8 4e a7 ff ff       	call   4450 <fwp_trap>
    9d02:	e8 49 97 ff ff       	call   3450 <__stack_chk_fail@plt>
    9d07:	48 8d 3d d2 6d 00 00 	lea    0x6dd2(%rip),%rdi        # 10ae0 <_IO_stdin_used+0xae0>
    9d0e:	e8 3d a7 ff ff       	call   4450 <fwp_trap>
    9d13:	66 90                	xchg   %ax,%ax
    9d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9d1c:	00 00 00 00 

0000000000009d20 <fwp_owned_entry12>:
    9d20:	f3 0f 1e fa          	endbr64
    9d24:	48 8b 3f             	mov    (%rdi),%rdi
    9d27:	e9 34 ec ff ff       	jmp    8960 <f12>
    9d2c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009d30 <e12>:
    9d30:	f3 0f 1e fa          	endbr64
    9d34:	53                   	push   %rbx
    9d35:	48 8b 1f             	mov    (%rdi),%rbx
    9d38:	48 89 df             	mov    %rbx,%rdi
    9d3b:	e8 f0 cc ff ff       	call   6a30 <fwp_rc_share>
    9d40:	48 89 df             	mov    %rbx,%rdi
    9d43:	e8 18 ec ff ff       	call   8960 <f12>
    9d48:	48 89 c3             	mov    %rax,%rbx
    9d4b:	48 89 c7             	mov    %rax,%rdi
    9d4e:	e8 dd cc ff ff       	call   6a30 <fwp_rc_share>
    9d53:	48 89 d8             	mov    %rbx,%rax
    9d56:	5b                   	pop    %rbx
    9d57:	c3                   	ret
    9d58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9d5f:	00 

0000000000009d60 <fwp_write>:
    9d60:	41 57                	push   %r15
    9d62:	41 56                	push   %r14
    9d64:	41 55                	push   %r13
    9d66:	41 54                	push   %r12
    9d68:	55                   	push   %rbp
    9d69:	53                   	push   %rbx
    9d6a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9d71:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9d78:	00 00 
    9d7a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9d81:	00 
    9d82:	49 89 d4             	mov    %rdx,%r12
    9d85:	8b 12                	mov    (%rdx),%edx
    9d87:	83 fa 19             	cmp    $0x19,%edx
    9d8a:	77 6a                	ja     9df6 <fwp_write+0x96>
    9d8c:	48 89 f5             	mov    %rsi,%rbp
    9d8f:	89 d0                	mov    %edx,%eax
    9d91:	89 ce                	mov    %ecx,%esi
    9d93:	48 89 fb             	mov    %rdi,%rbx
    9d96:	48 8d 0d 23 6f 00 00 	lea    0x6f23(%rip),%rcx        # 10cc0 <_IO_stdin_used+0xcc0>
    9d9d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9da1:	48 01 c8             	add    %rcx,%rax
    9da4:	3e ff e0             	notrack jmp *%rax
    9da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9dae:	00 00 
    9db0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9db4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9db8:	48 89 ca             	mov    %rcx,%rdx
    9dbb:	48 85 c9             	test   %rcx,%rcx
    9dbe:	0f 88 9c 0c 00 00    	js     aa60 <fwp_write+0xd00>
    9dc4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9dcb:	00 
    9dcc:	48 89 c6             	mov    %rax,%rsi
    9dcf:	4c 89 e7             	mov    %r12,%rdi
    9dd2:	e8 69 9c ff ff       	call   3a40 <fwp_fmt_u128>
    9dd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9dde:	00 00 
    9de0:	4c 89 e7             	mov    %r12,%rdi
    9de3:	e8 58 96 ff ff       	call   3440 <strlen@plt>
    9de8:	4c 89 e6             	mov    %r12,%rsi
    9deb:	48 89 df             	mov    %rbx,%rdi
    9dee:	48 89 c2             	mov    %rax,%rdx
    9df1:	e8 fa a2 ff ff       	call   40f0 <buf_put>
    9df6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9dfd:	00 
    9dfe:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9e05:	00 00 
    9e07:	0f 85 28 04 00 00    	jne    a235 <fwp_write+0x4d5>
    9e0d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9e14:	5b                   	pop    %rbx
    9e15:	5d                   	pop    %rbp
    9e16:	41 5c                	pop    %r12
    9e18:	41 5d                	pop    %r13
    9e1a:	41 5e                	pop    %r14
    9e1c:	41 5f                	pop    %r15
    9e1e:	c3                   	ret
    9e1f:	90                   	nop
    9e20:	49 89 e9             	mov    %rbp,%r9
    9e23:	4c 8d 05 31 64 00 00 	lea    0x6431(%rip),%r8        # 1025b <_IO_stdin_used+0x25b>
    9e2a:	b9 00 02 00 00       	mov    $0x200,%ecx
    9e2f:	ba 02 00 00 00       	mov    $0x2,%edx
    9e34:	be 00 02 00 00       	mov    $0x200,%esi
    9e39:	31 c0                	xor    %eax,%eax
    9e3b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9e42:	00 
    9e43:	e8 58 95 ff ff       	call   33a0 <__snprintf_chk@plt>
    9e48:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9e4f:	00 
    9e50:	e8 eb 95 ff ff       	call   3440 <strlen@plt>
    9e55:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9e5c:	00 
    9e5d:	48 89 df             	mov    %rbx,%rdi
    9e60:	48 89 c2             	mov    %rax,%rdx
    9e63:	e8 88 a2 ff ff       	call   40f0 <buf_put>
    9e68:	eb 8c                	jmp    9df6 <fwp_write+0x96>
    9e6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9e70:	49 89 e9             	mov    %rbp,%r9
    9e73:	4c 8d 05 dc 63 00 00 	lea    0x63dc(%rip),%r8        # 10256 <_IO_stdin_used+0x256>
    9e7a:	eb ae                	jmp    9e2a <fwp_write+0xca>
    9e7c:	0f 1f 40 00          	nopl   0x0(%rax)
    9e80:	83 fa 13             	cmp    $0x13,%edx
    9e83:	48 8d 05 c2 63 00 00 	lea    0x63c2(%rip),%rax        # 1024c <_IO_stdin_used+0x24c>
    9e8a:	48 8d 35 c0 63 00 00 	lea    0x63c0(%rip),%rsi        # 10251 <_IO_stdin_used+0x251>
    9e91:	ba 04 00 00 00       	mov    $0x4,%edx
    9e96:	48 0f 44 f0          	cmove  %rax,%rsi
    9e9a:	45 31 ed             	xor    %r13d,%r13d
    9e9d:	e8 4e a2 ff ff       	call   40f0 <buf_put>
    9ea2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9ea7:	0f 84 a3 08 00 00    	je     a750 <fwp_write+0x9f0>
    9ead:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9eb2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9eb7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9ebc:	48 89 df             	mov    %rbx,%rdi
    9ebf:	49 0f 44 c5          	cmove  %r13,%rax
    9ec3:	31 c9                	xor    %ecx,%ecx
    9ec5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    9eca:	e8 91 fe ff ff       	call   9d60 <fwp_write>
    9ecf:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9ed4:	0f 84 6e 09 00 00    	je     a848 <fwp_write+0xae8>
    9eda:	49 83 c5 01          	add    $0x1,%r13
    9ede:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9ee2:	0f 83 68 08 00 00    	jae    a750 <fwp_write+0x9f0>
    9ee8:	ba 02 00 00 00       	mov    $0x2,%edx
    9eed:	48 8d 35 a7 63 00 00 	lea    0x63a7(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    9ef4:	48 89 df             	mov    %rbx,%rdi
    9ef7:	e8 f4 a1 ff ff       	call   40f0 <buf_put>
    9efc:	eb af                	jmp    9ead <fwp_write+0x14d>
    9efe:	66 90                	xchg   %ax,%ax
    9f00:	ba 06 00 00 00       	mov    $0x6,%edx
    9f05:	48 8d 35 68 63 00 00 	lea    0x6368(%rip),%rsi        # 10274 <_IO_stdin_used+0x274>
    9f0c:	48 83 c5 10          	add    $0x10,%rbp
    9f10:	e8 db a1 ff ff       	call   40f0 <buf_put>
    9f15:	48 89 ef             	mov    %rbp,%rdi
    9f18:	e8 23 95 ff ff       	call   3440 <strlen@plt>
    9f1d:	48 89 ee             	mov    %rbp,%rsi
    9f20:	48 89 df             	mov    %rbx,%rdi
    9f23:	48 89 c2             	mov    %rax,%rdx
    9f26:	e8 c5 a1 ff ff       	call   40f0 <buf_put>
    9f2b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9f30:	ba 01 00 00 00       	mov    $0x1,%edx
    9f35:	48 89 df             	mov    %rbx,%rdi
    9f38:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9f3d:	e8 ae a1 ff ff       	call   40f0 <buf_put>
    9f42:	e9 af fe ff ff       	jmp    9df6 <fwp_write+0x96>
    9f47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9f4e:	00 00 
    9f50:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9f57:	00 
    9f58:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9f5f:	00 00 
    9f61:	0f 85 ce 02 00 00    	jne    a235 <fwp_write+0x4d5>
    9f67:	ba 0a 00 00 00       	mov    $0xa,%edx
    9f6c:	48 8d 35 ed 62 00 00 	lea    0x62ed(%rip),%rsi        # 10260 <_IO_stdin_used+0x260>
    9f73:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9f7a:	48 89 df             	mov    %rbx,%rdi
    9f7d:	5b                   	pop    %rbx
    9f7e:	5d                   	pop    %rbp
    9f7f:	41 5c                	pop    %r12
    9f81:	41 5d                	pop    %r13
    9f83:	41 5e                	pop    %r14
    9f85:	41 5f                	pop    %r15
    9f87:	e9 64 a1 ff ff       	jmp    40f0 <buf_put>
    9f8c:	0f 1f 40 00          	nopl   0x0(%rax)
    9f90:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    9f95:	4d 85 ed             	test   %r13,%r13
    9f98:	0f 84 02 0c 00 00    	je     aba0 <fwp_write+0xe40>
    9f9e:	48 8d 35 03 63 00 00 	lea    0x6303(%rip),%rsi        # 102a8 <_IO_stdin_used+0x2a8>
    9fa5:	4c 89 ef             	mov    %r13,%rdi
    9fa8:	e8 73 95 ff ff       	call   3520 <strcmp@plt>
    9fad:	41 89 c1             	mov    %eax,%r9d
    9fb0:	85 c0                	test   %eax,%eax
    9fb2:	0f 84 6c 0c 00 00    	je     ac24 <fwp_write+0xec4>
    9fb8:	4c 89 ef             	mov    %r13,%rdi
    9fbb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9fc0:	e8 7b 94 ff ff       	call   3440 <strlen@plt>
    9fc5:	4c 89 ee             	mov    %r13,%rsi
    9fc8:	48 89 df             	mov    %rbx,%rdi
    9fcb:	48 89 c2             	mov    %rax,%rdx
    9fce:	e8 1d a1 ff ff       	call   40f0 <buf_put>
    9fd3:	ba 01 00 00 00       	mov    $0x1,%edx
    9fd8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9fdd:	48 89 df             	mov    %rbx,%rdi
    9fe0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9fe5:	e8 06 a1 ff ff       	call   40f0 <buf_put>
    9fea:	ba 01 00 00 00       	mov    $0x1,%edx
    9fef:	4c 89 fe             	mov    %r15,%rsi
    9ff2:	48 89 df             	mov    %rbx,%rdi
    9ff5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    9ffa:	e8 f1 a0 ff ff       	call   40f0 <buf_put>
    9fff:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    a004:	45 31 f6             	xor    %r14d,%r14d
    a007:	85 d2                	test   %edx,%edx
    a009:	0f 8e 81 0a 00 00    	jle    aa90 <fwp_write+0xd30>
    a00f:	45 31 ed             	xor    %r13d,%r13d
    a012:	4d 85 ed             	test   %r13,%r13
    a015:	0f 85 75 07 00 00    	jne    a790 <fwp_write+0xa30>
    a01b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a022:	00 
    a023:	45 85 f6             	test   %r14d,%r14d
    a026:	0f 84 84 07 00 00    	je     a7b0 <fwp_write+0xa50>
    a02c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    a031:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    a036:	48 89 df             	mov    %rbx,%rdi
    a039:	49 83 c5 01          	add    $0x1,%r13
    a03d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    a041:	31 c9                	xor    %ecx,%ecx
    a043:	e8 18 fd ff ff       	call   9d60 <fwp_write>
    a048:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    a04d:	7f c3                	jg     a012 <fwp_write+0x2b2>
    a04f:	45 85 f6             	test   %r14d,%r14d
    a052:	0f 84 38 0a 00 00    	je     aa90 <fwp_write+0xd30>
    a058:	b8 29 00 00 00       	mov    $0x29,%eax
    a05d:	ba 01 00 00 00       	mov    $0x1,%edx
    a062:	4c 89 fe             	mov    %r15,%rsi
    a065:	48 89 df             	mov    %rbx,%rdi
    a068:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    a06c:	e8 7f a0 ff ff       	call   40f0 <buf_put>
    a071:	e9 80 fd ff ff       	jmp    9df6 <fwp_write+0x96>
    a076:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a07d:	00 00 00 
    a080:	ba 01 00 00 00       	mov    $0x1,%edx
    a085:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a08a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    a08f:	e8 5c a0 ff ff       	call   40f0 <buf_put>
    a094:	48 85 ed             	test   %rbp,%rbp
    a097:	0f 84 93 06 00 00    	je     a730 <fwp_write+0x9d0>
    a09d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    a0a1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a0a6:	31 c9                	xor    %ecx,%ecx
    a0a8:	48 89 df             	mov    %rbx,%rdi
    a0ab:	e8 b0 fc ff ff       	call   9d60 <fwp_write>
    a0b0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    a0b4:	48 85 ed             	test   %rbp,%rbp
    a0b7:	0f 84 73 06 00 00    	je     a730 <fwp_write+0x9d0>
    a0bd:	ba 02 00 00 00       	mov    $0x2,%edx
    a0c2:	48 8d 35 d2 61 00 00 	lea    0x61d2(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a0c9:	48 89 df             	mov    %rbx,%rdi
    a0cc:	e8 1f a0 ff ff       	call   40f0 <buf_put>
    a0d1:	eb ca                	jmp    a09d <fwp_write+0x33d>
    a0d3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a0d8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    a0dc:	85 f6                	test   %esi,%esi
    a0de:	0f 84 fc 07 00 00    	je     a8e0 <fwp_write+0xb80>
    a0e4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a0eb:	00 
    a0ec:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a0f3:	00 00 
    a0f5:	0f 85 3a 01 00 00    	jne    a235 <fwp_write+0x4d5>
    a0fb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    a0ff:	4c 89 ea             	mov    %r13,%rdx
    a102:	e9 6c fe ff ff       	jmp    9f73 <fwp_write+0x213>
    a107:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a10e:	00 00 
    a110:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    a115:	ba 01 00 00 00       	mov    $0x1,%edx
    a11a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    a11f:	48 89 ee             	mov    %rbp,%rsi
    a122:	e8 c9 9f ff ff       	call   40f0 <buf_put>
    a127:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    a12c:	4c 89 e7             	mov    %r12,%rdi
    a12f:	e8 0c 93 ff ff       	call   3440 <strlen@plt>
    a134:	4c 89 e6             	mov    %r12,%rsi
    a137:	48 89 df             	mov    %rbx,%rdi
    a13a:	48 89 c2             	mov    %rax,%rdx
    a13d:	e8 ae 9f ff ff       	call   40f0 <buf_put>
    a142:	ba 01 00 00 00       	mov    $0x1,%edx
    a147:	48 89 ee             	mov    %rbp,%rsi
    a14a:	48 89 df             	mov    %rbx,%rdi
    a14d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a152:	e8 99 9f ff ff       	call   40f0 <buf_put>
    a157:	e9 9a fc ff ff       	jmp    9df6 <fwp_write+0x96>
    a15c:	0f 1f 40 00          	nopl   0x0(%rax)
    a160:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    a165:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    a169:	0f 8a 8e 0b 00 00    	jp     acfd <fwp_write+0xf9d>
    a16f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a173:	66 0f 54 05 45 6c 00 	andpd  0x6c45(%rip),%xmm0        # 10dc0 <msg.4+0x90>
    a17a:	00 
    a17b:	bd 01 00 00 00       	mov    $0x1,%ebp
    a180:	66 0f 2e 05 70 6c 00 	ucomisd 0x6c70(%rip),%xmm0        # 10df8 <msg.4+0xc8>
    a187:	00 
    a188:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a18f:	00 
    a190:	0f 87 b2 09 00 00    	ja     ab48 <fwp_write+0xde8>
    a196:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a19d:	00 00 00 
    a1a0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a1a4:	89 ee                	mov    %ebp,%esi
    a1a6:	4c 89 e7             	mov    %r12,%rdi
    a1a9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    a1ae:	e8 bd a5 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a1b3:	31 f6                	xor    %esi,%esi
    a1b5:	4c 89 e7             	mov    %r12,%rdi
    a1b8:	e8 43 92 ff ff       	call   3400 <strtod@plt>
    a1bd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    a1c2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    a1c6:	7a 06                	jp     a1ce <fwp_write+0x46e>
    a1c8:	0f 84 e9 01 00 00    	je     a3b7 <fwp_write+0x657>
    a1ce:	83 c5 01             	add    $0x1,%ebp
    a1d1:	83 fd 12             	cmp    $0x12,%ebp
    a1d4:	75 ca                	jne    a1a0 <fwp_write+0x440>
    a1d6:	be 11 00 00 00       	mov    $0x11,%esi
    a1db:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a1df:	4c 89 e7             	mov    %r12,%rdi
    a1e2:	e8 89 a5 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a1e7:	e9 cb 01 00 00       	jmp    a3b7 <fwp_write+0x657>
    a1ec:	0f 1f 40 00          	nopl   0x0(%rax)
    a1f0:	48 83 fd 01          	cmp    $0x1,%rbp
    a1f4:	0f 84 e6 08 00 00    	je     aae0 <fwp_write+0xd80>
    a1fa:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    a1fe:	b8 02 00 00 00       	mov    $0x2,%eax
    a203:	ba 01 00 00 00       	mov    $0x1,%edx
    a208:	48 0f 44 d0          	cmove  %rax,%rdx
    a20c:	48 8d 35 31 60 00 00 	lea    0x6031(%rip),%rsi        # 10244 <_IO_stdin_used+0x244>
    a213:	48 8d 05 2f 60 00 00 	lea    0x602f(%rip),%rax        # 10249 <_IO_stdin_used+0x249>
    a21a:	48 0f 44 f0          	cmove  %rax,%rsi
    a21e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a225:	00 
    a226:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a22d:	00 00 
    a22f:	0f 84 3e fd ff ff    	je     9f73 <fwp_write+0x213>
    a235:	e8 16 92 ff ff       	call   3450 <__stack_chk_fail@plt>
    a23a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a240:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    a245:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    a24a:	e8 e1 9d ff ff       	call   4030 <buf_grow>
    a24f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    a253:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    a259:	4c 03 0b             	add    (%rbx),%r9
    a25c:	66 45 89 11          	mov    %r10w,(%r9)
    a260:	45 85 e4             	test   %r12d,%r12d
    a263:	0f 8e 07 05 00 00    	jle    a770 <fwp_write+0xa10>
    a269:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    a270:	55 55 55 
    a273:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    a278:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    a27f:	aa aa aa 
    a282:	49 83 c1 01          	add    $0x1,%r9
    a286:	eb 45                	jmp    a2cd <fwp_write+0x56d>
    a288:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a28f:	00 
    a290:	be 01 00 00 00       	mov    $0x1,%esi
    a295:	b8 2d 00 00 00       	mov    $0x2d,%eax
    a29a:	88 07                	mov    %al,(%rdi)
    a29c:	48 89 e8             	mov    %rbp,%rax
    a29f:	49 f7 e8             	imul   %r8
    a2a2:	48 89 e8             	mov    %rbp,%rax
    a2a5:	48 c1 f8 3f          	sar    $0x3f,%rax
    a2a9:	48 29 c2             	sub    %rax,%rdx
    a2ac:	48 85 c9             	test   %rcx,%rcx
    a2af:	0f 95 c0             	setne  %al
    a2b2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    a2b6:	48 83 ef 01          	sub    $0x1,%rdi
    a2ba:	48 21 c5             	and    %rax,%rbp
    a2bd:	48 29 ea             	sub    %rbp,%rdx
    a2c0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    a2c4:	49 39 f9             	cmp    %rdi,%r9
    a2c7:	0f 84 a3 04 00 00    	je     a770 <fwp_write+0xa10>
    a2cd:	48 89 e8             	mov    %rbp,%rax
    a2d0:	49 f7 e8             	imul   %r8
    a2d3:	48 89 e8             	mov    %rbp,%rax
    a2d6:	48 c1 f8 3f          	sar    $0x3f,%rax
    a2da:	48 89 d1             	mov    %rdx,%rcx
    a2dd:	48 29 c1             	sub    %rax,%rcx
    a2e0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a2e4:	48 89 e9             	mov    %rbp,%rcx
    a2e7:	48 29 c1             	sub    %rax,%rcx
    a2ea:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a2ee:	49 f7 e2             	mul    %r10
    a2f1:	b8 30 00 00 00       	mov    $0x30,%eax
    a2f6:	48 89 d6             	mov    %rdx,%rsi
    a2f9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a2fd:	48 d1 ee             	shr    $1,%rsi
    a300:	48 01 f2             	add    %rsi,%rdx
    a303:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a307:	48 29 d6             	sub    %rdx,%rsi
    a30a:	74 8e                	je     a29a <fwp_write+0x53a>
    a30c:	48 83 fe 01          	cmp    $0x1,%rsi
    a310:	0f 85 7a ff ff ff    	jne    a290 <fwp_write+0x530>
    a316:	31 f6                	xor    %esi,%esi
    a318:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a31d:	e9 78 ff ff ff       	jmp    a29a <fwp_write+0x53a>
    a322:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a328:	66 0f 6e cd          	movd   %ebp,%xmm1
    a32c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a32f:	0f 8a c8 09 00 00    	jp     acfd <fwp_write+0xf9d>
    a335:	0f 28 c1             	movaps %xmm1,%xmm0
    a338:	0f 54 05 71 6a 00 00 	andps  0x6a71(%rip),%xmm0        # 10db0 <msg.4+0x80>
    a33f:	0f 2e 05 be 5c 00 00 	ucomiss 0x5cbe(%rip),%xmm0        # 10004 <_IO_stdin_used+0x4>
    a346:	0f 87 24 08 00 00    	ja     ab70 <fwp_write+0xe10>
    a34c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a350:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a356:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a35d:	00 
    a35e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a362:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a367:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a36e:	00 00 
    a370:	44 89 ee             	mov    %r13d,%esi
    a373:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a378:	4c 89 e7             	mov    %r12,%rdi
    a37b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a380:	e8 eb a3 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a385:	31 f6                	xor    %esi,%esi
    a387:	4c 89 e7             	mov    %r12,%rdi
    a38a:	e8 11 91 ff ff       	call   34a0 <strtof@plt>
    a38f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a394:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a397:	7a 02                	jp     a39b <fwp_write+0x63b>
    a399:	74 1c                	je     a3b7 <fwp_write+0x657>
    a39b:	41 83 c5 01          	add    $0x1,%r13d
    a39f:	41 83 fd 0a          	cmp    $0xa,%r13d
    a3a3:	75 cb                	jne    a370 <fwp_write+0x610>
    a3a5:	be 09 00 00 00       	mov    $0x9,%esi
    a3aa:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a3af:	4c 89 e7             	mov    %r12,%rdi
    a3b2:	e8 b9 a3 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a3b7:	4c 89 e7             	mov    %r12,%rdi
    a3ba:	e8 f1 9d ff ff       	call   41b0 <fwp_finish_float>
    a3bf:	e9 1c fa ff ff       	jmp    9de0 <fwp_write+0x80>
    a3c4:	0f 1f 40 00          	nopl   0x0(%rax)
    a3c8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a3cc:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a3d0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a3d7:	00 
    a3d8:	48 89 ef             	mov    %rbp,%rdi
    a3db:	e8 60 96 ff ff       	call   3a40 <fwp_fmt_u128>
    a3e0:	48 89 ef             	mov    %rbp,%rdi
    a3e3:	e8 58 90 ff ff       	call   3440 <strlen@plt>
    a3e8:	48 89 ee             	mov    %rbp,%rsi
    a3eb:	48 89 df             	mov    %rbx,%rdi
    a3ee:	48 89 c2             	mov    %rax,%rdx
    a3f1:	e8 fa 9c ff ff       	call   40f0 <buf_put>
    a3f6:	e9 fb f9 ff ff       	jmp    9df6 <fwp_write+0x96>
    a3fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a400:	ba 06 00 00 00       	mov    $0x6,%edx
    a405:	48 8d 35 92 5e 00 00 	lea    0x5e92(%rip),%rsi        # 1029e <_IO_stdin_used+0x29e>
    a40c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a412:	e8 d9 9c ff ff       	call   40f0 <buf_put>
    a417:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a41e:	ff ff 7f 
    a421:	48 23 55 00          	and    0x0(%rbp),%rdx
    a425:	0f 84 86 02 00 00    	je     a6b1 <fwp_write+0x951>
    a42b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a430:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a434:	48 85 d2             	test   %rdx,%rdx
    a437:	0f 84 ae 00 00 00    	je     a4eb <fwp_write+0x78b>
    a43d:	8b 0a                	mov    (%rdx),%ecx
    a43f:	83 f9 1c             	cmp    $0x1c,%ecx
    a442:	0f 84 58 06 00 00    	je     aaa0 <fwp_write+0xd40>
    a448:	83 f9 1b             	cmp    $0x1b,%ecx
    a44b:	0f 87 9a 00 00 00    	ja     a4eb <fwp_write+0x78b>
    a451:	be 01 00 00 00       	mov    $0x1,%esi
    a456:	48 d3 e6             	shl    %cl,%rsi
    a459:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a45f:	0f 85 4b 04 00 00    	jne    a8b0 <fwp_write+0xb50>
    a465:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a46b:	0f 85 0f 04 00 00    	jne    a880 <fwp_write+0xb20>
    a471:	83 e6 21             	and    $0x21,%esi
    a474:	74 75                	je     a4eb <fwp_write+0x78b>
    a476:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a47b:	48 85 ff             	test   %rdi,%rdi
    a47e:	79 07                	jns    a487 <fwp_write+0x727>
    a480:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a484:	4c 01 ee             	add    %r13,%rsi
    a487:	48 0f be 3e          	movsbq (%rsi),%rdi
    a48b:	85 c9                	test   %ecx,%ecx
    a48d:	40 0f b6 f7          	movzbl %dil,%esi
    a491:	48 0f 44 f7          	cmove  %rdi,%rsi
    a495:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a49c:	00 00 00 00 
    a4a0:	31 c9                	xor    %ecx,%ecx
    a4a2:	48 89 df             	mov    %rbx,%rdi
    a4a5:	49 83 c5 01          	add    $0x1,%r13
    a4a9:	e8 b2 f8 ff ff       	call   9d60 <fwp_write>
    a4ae:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a4b5:	ff ff 7f 
    a4b8:	48 23 55 00          	and    0x0(%rbp),%rdx
    a4bc:	49 39 d5             	cmp    %rdx,%r13
    a4bf:	0f 83 ec 01 00 00    	jae    a6b1 <fwp_write+0x951>
    a4c5:	ba 02 00 00 00       	mov    $0x2,%edx
    a4ca:	48 89 df             	mov    %rbx,%rdi
    a4cd:	48 8d 35 c7 5d 00 00 	lea    0x5dc7(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a4d4:	e8 17 9c ff ff       	call   40f0 <buf_put>
    a4d9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a4de:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a4e2:	48 85 d2             	test   %rdx,%rdx
    a4e5:	0f 85 52 ff ff ff    	jne    a43d <fwp_write+0x6dd>
    a4eb:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a4f0:	48 85 ff             	test   %rdi,%rdi
    a4f3:	0f 88 cf 05 00 00    	js     aac8 <fwp_write+0xd68>
    a4f9:	48 8b 31             	mov    (%rcx),%rsi
    a4fc:	eb a2                	jmp    a4a0 <fwp_write+0x740>
    a4fe:	66 90                	xchg   %ax,%ax
    a500:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a507:	00 
    a508:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a50f:	00 00 
    a511:	0f 85 1e fd ff ff    	jne    a235 <fwp_write+0x4d5>
    a517:	ba 08 00 00 00       	mov    $0x8,%edx
    a51c:	48 8d 35 48 5d 00 00 	lea    0x5d48(%rip),%rsi        # 1026b <_IO_stdin_used+0x26b>
    a523:	e9 4b fa ff ff       	jmp    9f73 <fwp_write+0x213>
    a528:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a52f:	00 
    a530:	89 e8                	mov    %ebp,%eax
    a532:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a539:	76 03                	jbe    a53e <fwp_write+0x7de>
    a53b:	8b 45 00             	mov    0x0(%rbp),%eax
    a53e:	41 89 c6             	mov    %eax,%r14d
    a541:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a546:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a54b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a54f:	4c 89 ef             	mov    %r13,%rdi
    a552:	e8 e9 8e ff ff       	call   3440 <strlen@plt>
    a557:	4c 89 ee             	mov    %r13,%rsi
    a55a:	48 89 df             	mov    %rbx,%rdi
    a55d:	48 89 c2             	mov    %rax,%rdx
    a560:	e8 8b 9b ff ff       	call   40f0 <buf_put>
    a565:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a56a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a56e:	85 f6                	test   %esi,%esi
    a570:	0f 8e 80 f8 ff ff    	jle    9df6 <fwp_write+0x96>
    a576:	45 31 ed             	xor    %r13d,%r13d
    a579:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a57e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a583:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a588:	ba 01 00 00 00       	mov    $0x1,%edx
    a58d:	4c 89 fe             	mov    %r15,%rsi
    a590:	48 89 04 24          	mov    %rax,(%rsp)
    a594:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a599:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a59d:	48 89 df             	mov    %rbx,%rdi
    a5a0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a5a4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a5a9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a5ae:	e8 3d 9b ff ff       	call   40f0 <buf_put>
    a5b3:	41 8b 06             	mov    (%r14),%eax
    a5b6:	83 f8 0e             	cmp    $0xe,%eax
    a5b9:	0f 84 71 02 00 00    	je     a830 <fwp_write+0xad0>
    a5bf:	83 f8 10             	cmp    $0x10,%eax
    a5c2:	0f 84 38 02 00 00    	je     a800 <fwp_write+0xaa0>
    a5c8:	83 f8 0a             	cmp    $0xa,%eax
    a5cb:	0f 84 7f 04 00 00    	je     aa50 <fwp_write+0xcf0>
    a5d1:	0f 8f f9 00 00 00    	jg     a6d0 <fwp_write+0x970>
    a5d7:	83 f8 03             	cmp    $0x3,%eax
    a5da:	0f 8f 50 04 00 00    	jg     aa30 <fwp_write+0xcd0>
    a5e0:	85 c0                	test   %eax,%eax
    a5e2:	78 10                	js     a5f4 <fwp_write+0x894>
    a5e4:	48 8b 04 24          	mov    (%rsp),%rax
    a5e8:	48 c1 e8 3f          	shr    $0x3f,%rax
    a5ec:	85 c0                	test   %eax,%eax
    a5ee:	0f 85 f9 00 00 00    	jne    a6ed <fwp_write+0x98d>
    a5f4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a5f9:	48 8b 34 24          	mov    (%rsp),%rsi
    a5fd:	31 c9                	xor    %ecx,%ecx
    a5ff:	48 89 df             	mov    %rbx,%rdi
    a602:	e8 59 f7 ff ff       	call   9d60 <fwp_write>
    a607:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a60c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a611:	49 83 c5 01          	add    $0x1,%r13
    a615:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a619:	0f 8f 5f ff ff ff    	jg     a57e <fwp_write+0x81e>
    a61f:	e9 d2 f7 ff ff       	jmp    9df6 <fwp_write+0x96>
    a624:	0f 1f 40 00          	nopl   0x0(%rax)
    a628:	ba 06 00 00 00       	mov    $0x6,%edx
    a62d:	48 8d 35 5d 5c 00 00 	lea    0x5c5d(%rip),%rsi        # 10291 <_IO_stdin_used+0x291>
    a634:	45 31 ed             	xor    %r13d,%r13d
    a637:	e8 b4 9a ff ff       	call   40f0 <buf_put>
    a63c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a641:	75 19                	jne    a65c <fwp_write+0x8fc>
    a643:	eb 6c                	jmp    a6b1 <fwp_write+0x951>
    a645:	0f 1f 00             	nopl   (%rax)
    a648:	ba 02 00 00 00       	mov    $0x2,%edx
    a64d:	48 8d 35 47 5c 00 00 	lea    0x5c47(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a654:	48 89 df             	mov    %rbx,%rdi
    a657:	e8 94 9a ff ff       	call   40f0 <buf_put>
    a65c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a662:	b9 00 02 00 00       	mov    $0x200,%ecx
    a667:	31 c0                	xor    %eax,%eax
    a669:	49 83 c5 01          	add    $0x1,%r13
    a66d:	4c 8d 05 24 5c 00 00 	lea    0x5c24(%rip),%r8        # 10298 <_IO_stdin_used+0x298>
    a674:	ba 02 00 00 00       	mov    $0x2,%edx
    a679:	be 00 02 00 00       	mov    $0x200,%esi
    a67e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a685:	00 
    a686:	e8 15 8d ff ff       	call   33a0 <__snprintf_chk@plt>
    a68b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a692:	00 
    a693:	e8 a8 8d ff ff       	call   3440 <strlen@plt>
    a698:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a69f:	00 
    a6a0:	48 89 df             	mov    %rbx,%rdi
    a6a3:	48 89 c2             	mov    %rax,%rdx
    a6a6:	e8 45 9a ff ff       	call   40f0 <buf_put>
    a6ab:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a6af:	72 97                	jb     a648 <fwp_write+0x8e8>
    a6b1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a6b6:	ba 01 00 00 00       	mov    $0x1,%edx
    a6bb:	48 89 df             	mov    %rbx,%rdi
    a6be:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a6c3:	e8 28 9a ff ff       	call   40f0 <buf_put>
    a6c8:	e9 29 f7 ff ff       	jmp    9df6 <fwp_write+0x96>
    a6cd:	0f 1f 00             	nopl   (%rax)
    a6d0:	83 f8 0b             	cmp    $0xb,%eax
    a6d3:	0f 85 1b ff ff ff    	jne    a5f4 <fwp_write+0x894>
    a6d9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a6de:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a6e2:	83 e0 01             	and    $0x1,%eax
    a6e5:	85 c0                	test   %eax,%eax
    a6e7:	0f 84 07 ff ff ff    	je     a5f4 <fwp_write+0x894>
    a6ed:	4c 89 fe             	mov    %r15,%rsi
    a6f0:	48 89 df             	mov    %rbx,%rdi
    a6f3:	ba 01 00 00 00       	mov    $0x1,%edx
    a6f8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a6fd:	e8 ee 99 ff ff       	call   40f0 <buf_put>
    a702:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a707:	48 8b 34 24          	mov    (%rsp),%rsi
    a70b:	31 c9                	xor    %ecx,%ecx
    a70d:	48 89 df             	mov    %rbx,%rdi
    a710:	e8 4b f6 ff ff       	call   9d60 <fwp_write>
    a715:	ba 01 00 00 00       	mov    $0x1,%edx
    a71a:	4c 89 fe             	mov    %r15,%rsi
    a71d:	48 89 df             	mov    %rbx,%rdi
    a720:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a725:	e8 c6 99 ff ff       	call   40f0 <buf_put>
    a72a:	e9 d8 fe ff ff       	jmp    a607 <fwp_write+0x8a7>
    a72f:	90                   	nop
    a730:	ba 01 00 00 00       	mov    $0x1,%edx
    a735:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a73a:	48 89 df             	mov    %rbx,%rdi
    a73d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a742:	e8 a9 99 ff ff       	call   40f0 <buf_put>
    a747:	e9 aa f6 ff ff       	jmp    9df6 <fwp_write+0x96>
    a74c:	0f 1f 40 00          	nopl   0x0(%rax)
    a750:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a755:	ba 01 00 00 00       	mov    $0x1,%edx
    a75a:	48 89 df             	mov    %rbx,%rdi
    a75d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a762:	e8 89 99 ff ff       	call   40f0 <buf_put>
    a767:	e9 8a f6 ff ff       	jmp    9df6 <fwp_write+0x96>
    a76c:	0f 1f 40 00          	nopl   0x0(%rax)
    a770:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a774:	48 8b 13             	mov    (%rbx),%rdx
    a777:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a77c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a780:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a784:	e9 6d f6 ff ff       	jmp    9df6 <fwp_write+0x96>
    a789:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a790:	ba 02 00 00 00       	mov    $0x2,%edx
    a795:	48 8d 35 ff 5a 00 00 	lea    0x5aff(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a79c:	48 89 df             	mov    %rbx,%rdi
    a79f:	e8 4c 99 ff ff       	call   40f0 <buf_put>
    a7a4:	e9 72 f8 ff ff       	jmp    a01b <fwp_write+0x2bb>
    a7a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a7b0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a7b5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a7ba:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a7be:	48 89 f7             	mov    %rsi,%rdi
    a7c1:	48 89 34 24          	mov    %rsi,(%rsp)
    a7c5:	e8 76 8c ff ff       	call   3440 <strlen@plt>
    a7ca:	48 8b 34 24          	mov    (%rsp),%rsi
    a7ce:	48 89 df             	mov    %rbx,%rdi
    a7d1:	48 89 c2             	mov    %rax,%rdx
    a7d4:	e8 17 99 ff ff       	call   40f0 <buf_put>
    a7d9:	ba 03 00 00 00       	mov    $0x3,%edx
    a7de:	48 8d 35 d9 5a 00 00 	lea    0x5ad9(%rip),%rsi        # 102be <_IO_stdin_used+0x2be>
    a7e5:	48 89 df             	mov    %rbx,%rdi
    a7e8:	e8 03 99 ff ff       	call   40f0 <buf_put>
    a7ed:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a7f2:	e9 35 f8 ff ff       	jmp    a02c <fwp_write+0x2cc>
    a7f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a7fe:	00 00 
    a800:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a805:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a809:	48 85 ff             	test   %rdi,%rdi
    a80c:	0f 84 e2 fd ff ff    	je     a5f4 <fwp_write+0x894>
    a812:	48 8d 35 8f 5a 00 00 	lea    0x5a8f(%rip),%rsi        # 102a8 <_IO_stdin_used+0x2a8>
    a819:	e8 02 8d ff ff       	call   3520 <strcmp@plt>
    a81e:	85 c0                	test   %eax,%eax
    a820:	0f 95 c0             	setne  %al
    a823:	0f b6 c0             	movzbl %al,%eax
    a826:	e9 c1 fd ff ff       	jmp    a5ec <fwp_write+0x88c>
    a82b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a830:	31 c0                	xor    %eax,%eax
    a832:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a839:	00 
    a83a:	0f 97 c0             	seta   %al
    a83d:	e9 aa fd ff ff       	jmp    a5ec <fwp_write+0x88c>
    a842:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a848:	48 89 df             	mov    %rbx,%rdi
    a84b:	ba 02 00 00 00       	mov    $0x2,%edx
    a850:	48 8d 35 4e 5a 00 00 	lea    0x5a4e(%rip),%rsi        # 102a5 <_IO_stdin_used+0x2a5>
    a857:	e8 94 98 ff ff       	call   40f0 <buf_put>
    a85c:	4c 89 e8             	mov    %r13,%rax
    a85f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a864:	31 c9                	xor    %ecx,%ecx
    a866:	48 c1 e0 04          	shl    $0x4,%rax
    a86a:	48 89 df             	mov    %rbx,%rdi
    a86d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a872:	e8 e9 f4 ff ff       	call   9d60 <fwp_write>
    a877:	e9 5e f6 ff ff       	jmp    9eda <fwp_write+0x17a>
    a87c:	0f 1f 40 00          	nopl   0x0(%rax)
    a880:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a885:	48 85 ff             	test   %rdi,%rdi
    a888:	79 0c                	jns    a896 <fwp_write+0xb36>
    a88a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a891:	00 
    a892:	48 03 75 10          	add    0x10(%rbp),%rsi
    a896:	48 63 3e             	movslq (%rsi),%rdi
    a899:	83 f9 02             	cmp    $0x2,%ecx
    a89c:	89 fe                	mov    %edi,%esi
    a89e:	48 0f 44 f7          	cmove  %rdi,%rsi
    a8a2:	e9 f9 fb ff ff       	jmp    a4a0 <fwp_write+0x740>
    a8a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a8ae:	00 00 
    a8b0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a8b5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a8ba:	48 85 ff             	test   %rdi,%rdi
    a8bd:	0f 88 0f 03 00 00    	js     abd2 <fwp_write+0xe72>
    a8c3:	49 0f bf 38          	movswq (%r8),%rdi
    a8c7:	83 f9 01             	cmp    $0x1,%ecx
    a8ca:	0f b7 f7             	movzwl %di,%esi
    a8cd:	48 0f 44 f7          	cmove  %rdi,%rsi
    a8d1:	e9 ca fb ff ff       	jmp    a4a0 <fwp_write+0x740>
    a8d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a8dd:	00 00 00 
    a8e0:	ba 01 00 00 00       	mov    $0x1,%edx
    a8e5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a8ea:	48 83 c5 08          	add    $0x8,%rbp
    a8ee:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a8f3:	e8 f8 97 ff ff       	call   40f0 <buf_put>
    a8f8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a8fd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a902:	4d 85 ed             	test   %r13,%r13
    a905:	75 46                	jne    a94d <fwp_write+0xbed>
    a907:	e9 04 01 00 00       	jmp    aa10 <fwp_write+0xcb0>
    a90c:	0f 1f 40 00          	nopl   0x0(%rax)
    a910:	41 80 f9 09          	cmp    $0x9,%r9b
    a914:	0f 84 d6 00 00 00    	je     a9f0 <fwp_write+0xc90>
    a91a:	41 80 f9 0a          	cmp    $0xa,%r9b
    a91e:	0f 85 9c 00 00 00    	jne    a9c0 <fwp_write+0xc60>
    a924:	ba 02 00 00 00       	mov    $0x2,%edx
    a929:	48 8d 35 51 59 00 00 	lea    0x5951(%rip),%rsi        # 10281 <_IO_stdin_used+0x281>
    a930:	48 89 df             	mov    %rbx,%rdi
    a933:	e8 b8 97 ff ff       	call   40f0 <buf_put>
    a938:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a93f:	00 
    a940:	48 83 c5 01          	add    $0x1,%rbp
    a944:	49 39 ec             	cmp    %rbp,%r12
    a947:	0f 84 c3 00 00 00    	je     aa10 <fwp_write+0xcb0>
    a94d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a952:	41 80 f9 0d          	cmp    $0xd,%r9b
    a956:	74 28                	je     a980 <fwp_write+0xc20>
    a958:	7e b6                	jle    a910 <fwp_write+0xbb0>
    a95a:	41 80 f9 22          	cmp    $0x22,%r9b
    a95e:	74 40                	je     a9a0 <fwp_write+0xc40>
    a960:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a964:	75 5a                	jne    a9c0 <fwp_write+0xc60>
    a966:	ba 02 00 00 00       	mov    $0x2,%edx
    a96b:	48 8d 35 0c 59 00 00 	lea    0x590c(%rip),%rsi        # 1027e <_IO_stdin_used+0x27e>
    a972:	48 89 df             	mov    %rbx,%rdi
    a975:	e8 76 97 ff ff       	call   40f0 <buf_put>
    a97a:	eb c4                	jmp    a940 <fwp_write+0xbe0>
    a97c:	0f 1f 40 00          	nopl   0x0(%rax)
    a980:	ba 02 00 00 00       	mov    $0x2,%edx
    a985:	48 8d 35 fb 58 00 00 	lea    0x58fb(%rip),%rsi        # 10287 <_IO_stdin_used+0x287>
    a98c:	48 89 df             	mov    %rbx,%rdi
    a98f:	e8 5c 97 ff ff       	call   40f0 <buf_put>
    a994:	eb aa                	jmp    a940 <fwp_write+0xbe0>
    a996:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a99d:	00 00 00 
    a9a0:	ba 02 00 00 00       	mov    $0x2,%edx
    a9a5:	48 8d 35 cf 58 00 00 	lea    0x58cf(%rip),%rsi        # 1027b <_IO_stdin_used+0x27b>
    a9ac:	48 89 df             	mov    %rbx,%rdi
    a9af:	e8 3c 97 ff ff       	call   40f0 <buf_put>
    a9b4:	eb 8a                	jmp    a940 <fwp_write+0xbe0>
    a9b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a9bd:	00 00 00 
    a9c0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a9c4:	0f 86 2e 01 00 00    	jbe    aaf8 <fwp_write+0xd98>
    a9ca:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a9ce:	0f 84 24 01 00 00    	je     aaf8 <fwp_write+0xd98>
    a9d4:	ba 01 00 00 00       	mov    $0x1,%edx
    a9d9:	4c 89 fe             	mov    %r15,%rsi
    a9dc:	48 89 df             	mov    %rbx,%rdi
    a9df:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a9e4:	e8 07 97 ff ff       	call   40f0 <buf_put>
    a9e9:	e9 52 ff ff ff       	jmp    a940 <fwp_write+0xbe0>
    a9ee:	66 90                	xchg   %ax,%ax
    a9f0:	ba 02 00 00 00       	mov    $0x2,%edx
    a9f5:	48 8d 35 88 58 00 00 	lea    0x5888(%rip),%rsi        # 10284 <_IO_stdin_used+0x284>
    a9fc:	48 89 df             	mov    %rbx,%rdi
    a9ff:	e8 ec 96 ff ff       	call   40f0 <buf_put>
    aa04:	e9 37 ff ff ff       	jmp    a940 <fwp_write+0xbe0>
    aa09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa10:	ba 01 00 00 00       	mov    $0x1,%edx
    aa15:	4c 89 fe             	mov    %r15,%rsi
    aa18:	48 89 df             	mov    %rbx,%rdi
    aa1b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    aa20:	e8 cb 96 ff ff       	call   40f0 <buf_put>
    aa25:	e9 cc f3 ff ff       	jmp    9df6 <fwp_write+0x96>
    aa2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aa30:	83 f8 04             	cmp    $0x4,%eax
    aa33:	0f 85 bb fb ff ff    	jne    a5f4 <fwp_write+0x894>
    aa39:	48 8b 04 24          	mov    (%rsp),%rax
    aa3d:	48 8b 40 08          	mov    0x8(%rax),%rax
    aa41:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    aa46:	48 c1 e8 3f          	shr    $0x3f,%rax
    aa4a:	e9 96 fc ff ff       	jmp    a6e5 <fwp_write+0x985>
    aa4f:	90                   	nop
    aa50:	8b 0c 24             	mov    (%rsp),%ecx
    aa53:	31 c0                	xor    %eax,%eax
    aa55:	85 c9                	test   %ecx,%ecx
    aa57:	0f 98 c0             	sets   %al
    aa5a:	e9 86 fc ff ff       	jmp    a6e5 <fwp_write+0x985>
    aa5f:	90                   	nop
    aa60:	48 f7 d8             	neg    %rax
    aa63:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    aa6a:	00 
    aa6b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    aa72:	2d 
    aa73:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    aa7a:	00 
    aa7b:	48 83 d2 00          	adc    $0x0,%rdx
    aa7f:	48 89 c6             	mov    %rax,%rsi
    aa82:	48 f7 da             	neg    %rdx
    aa85:	e8 b6 8f ff ff       	call   3a40 <fwp_fmt_u128>
    aa8a:	e9 51 f3 ff ff       	jmp    9de0 <fwp_write+0x80>
    aa8f:	90                   	nop
    aa90:	b8 7d 00 00 00       	mov    $0x7d,%eax
    aa95:	e9 c3 f5 ff ff       	jmp    a05d <fwp_write+0x2fd>
    aa9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aaa0:	4c 89 e9             	mov    %r13,%rcx
    aaa3:	48 c1 e1 04          	shl    $0x4,%rcx
    aaa7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    aaac:	48 85 ff             	test   %rdi,%rdi
    aaaf:	0f 89 eb f9 ff ff    	jns    a4a0 <fwp_write+0x740>
    aab5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    aab9:	48 89 ce             	mov    %rcx,%rsi
    aabc:	e9 df f9 ff ff       	jmp    a4a0 <fwp_write+0x740>
    aac1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aac8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    aacf:	00 
    aad0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    aad4:	e9 20 fa ff ff       	jmp    a4f9 <fwp_write+0x799>
    aad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aae0:	ba 02 00 00 00       	mov    $0x2,%edx
    aae5:	48 8d 35 5a 57 00 00 	lea    0x575a(%rip),%rsi        # 10246 <_IO_stdin_used+0x246>
    aaec:	e9 2d f7 ff ff       	jmp    a21e <fwp_write+0x4be>
    aaf1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aaf8:	4c 8d 05 8b 57 00 00 	lea    0x578b(%rip),%r8        # 1028a <_IO_stdin_used+0x28a>
    aaff:	b9 10 00 00 00       	mov    $0x10,%ecx
    ab04:	31 c0                	xor    %eax,%eax
    ab06:	ba 02 00 00 00       	mov    $0x2,%edx
    ab0b:	be 10 00 00 00       	mov    $0x10,%esi
    ab10:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    ab17:	00 
    ab18:	e8 83 88 ff ff       	call   33a0 <__snprintf_chk@plt>
    ab1d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    ab24:	00 
    ab25:	e8 16 89 ff ff       	call   3440 <strlen@plt>
    ab2a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    ab31:	00 
    ab32:	48 89 df             	mov    %rbx,%rdi
    ab35:	48 89 c2             	mov    %rax,%rdx
    ab38:	e8 b3 95 ff ff       	call   40f0 <buf_put>
    ab3d:	e9 fe fd ff ff       	jmp    a940 <fwp_write+0xbe0>
    ab42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ab48:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ab4c:	48 8d 35 ed 56 00 00 	lea    0x56ed(%rip),%rsi        # 10240 <_IO_stdin_used+0x240>
    ab53:	48 8d 05 e5 56 00 00 	lea    0x56e5(%rip),%rax        # 1023f <_IO_stdin_used+0x23f>
    ab5a:	4c 89 e7             	mov    %r12,%rdi
    ab5d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    ab61:	48 0f 46 f0          	cmovbe %rax,%rsi
    ab65:	e8 76 88 ff ff       	call   33e0 <strcpy@plt>
    ab6a:	e9 71 f2 ff ff       	jmp    9de0 <fwp_write+0x80>
    ab6f:	90                   	nop
    ab70:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ab74:	48 8d 35 c5 56 00 00 	lea    0x56c5(%rip),%rsi        # 10240 <_IO_stdin_used+0x240>
    ab7b:	48 8d 05 bd 56 00 00 	lea    0x56bd(%rip),%rax        # 1023f <_IO_stdin_used+0x23f>
    ab82:	0f 2f c8             	comiss %xmm0,%xmm1
    ab85:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ab8c:	00 
    ab8d:	4c 89 e7             	mov    %r12,%rdi
    ab90:	48 0f 46 f0          	cmovbe %rax,%rsi
    ab94:	e8 47 88 ff ff       	call   33e0 <strcpy@plt>
    ab99:	e9 42 f2 ff ff       	jmp    9de0 <fwp_write+0x80>
    ab9e:	66 90                	xchg   %ax,%ax
    aba0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    aba5:	45 85 c0             	test   %r8d,%r8d
    aba8:	75 34                	jne    abde <fwp_write+0xe7e>
    abaa:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    abb1:	00 
    abb2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    abb9:	00 00 
    abbb:	0f 85 74 f6 ff ff    	jne    a235 <fwp_write+0x4d5>
    abc1:	ba 02 00 00 00       	mov    $0x2,%edx
    abc6:	48 8d 35 ee 56 00 00 	lea    0x56ee(%rip),%rsi        # 102bb <_IO_stdin_used+0x2bb>
    abcd:	e9 a1 f3 ff ff       	jmp    9f73 <fwp_write+0x213>
    abd2:	48 03 75 10          	add    0x10(%rbp),%rsi
    abd6:	49 89 f0             	mov    %rsi,%r8
    abd9:	e9 e5 fc ff ff       	jmp    a8c3 <fwp_write+0xb63>
    abde:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    abe3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    abe8:	85 ff                	test   %edi,%edi
    abea:	0f 84 fa f3 ff ff    	je     9fea <fwp_write+0x28a>
    abf0:	ba 01 00 00 00       	mov    $0x1,%edx
    abf5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    abfa:	48 89 df             	mov    %rbx,%rdi
    abfd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    ac02:	e8 e9 94 ff ff       	call   40f0 <buf_put>
    ac07:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    ac0c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ac11:	41 be 01 00 00 00    	mov    $0x1,%r14d
    ac17:	85 c0                	test   %eax,%eax
    ac19:	0f 8f f0 f3 ff ff    	jg     a00f <fwp_write+0x2af>
    ac1f:	e9 34 f4 ff ff       	jmp    a058 <fwp_write+0x2f8>
    ac24:	48 8b 45 08          	mov    0x8(%rbp),%rax
    ac28:	49 89 c5             	mov    %rax,%r13
    ac2b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ac30:	49 89 c4             	mov    %rax,%r12
    ac33:	49 c1 fd 3f          	sar    $0x3f,%r13
    ac37:	4c 09 e8             	or     %r13,%rax
    ac3a:	0f 84 a7 00 00 00    	je     ace7 <fwp_write+0xf87>
    ac40:	48 8d 2d d9 77 00 00 	lea    0x77d9(%rip),%rbp        # 12420 <units.1>
    ac47:	4d 89 e7             	mov    %r12,%r15
    ac4a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    ac4e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    ac53:	4c 89 ff             	mov    %r15,%rdi
    ac56:	4c 89 ee             	mov    %r13,%rsi
    ac59:	44 89 0c 24          	mov    %r9d,(%rsp)
    ac5d:	48 99                	cqto
    ac5f:	48 89 d1             	mov    %rdx,%rcx
    ac62:	48 89 c2             	mov    %rax,%rdx
    ac65:	e8 16 44 00 00       	call   f080 <__divmodti4>
    ac6a:	44 8b 0c 24          	mov    (%rsp),%r9d
    ac6e:	48 89 c1             	mov    %rax,%rcx
    ac71:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    ac76:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    ac7b:	0f 84 94 00 00 00    	je     ad15 <fwp_write+0xfb5>
    ac81:	41 83 c1 01          	add    $0x1,%r9d
    ac85:	48 83 c5 10          	add    $0x10,%rbp
    ac89:	41 83 f9 05          	cmp    $0x5,%r9d
    ac8d:	75 bb                	jne    ac4a <fwp_write+0xeea>
    ac8f:	4d 85 ed             	test   %r13,%r13
    ac92:	79 53                	jns    ace7 <fwp_write+0xf87>
    ac94:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    ac99:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    ac9e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    aca3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    aca8:	48 99                	cqto
    acaa:	48 f7 d8             	neg    %rax
    acad:	48 83 d2 00          	adc    $0x0,%rdx
    acb1:	48 89 c6             	mov    %rax,%rsi
    acb4:	48 f7 da             	neg    %rdx
    acb7:	e8 84 8d ff ff       	call   3a40 <fwp_fmt_u128>
    acbc:	49 89 e8             	mov    %rbp,%r8
    acbf:	ba 00 02 00 00       	mov    $0x200,%edx
    acc4:	be 02 00 00 00       	mov    $0x2,%esi
    acc9:	31 c0                	xor    %eax,%eax
    accb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    acd2:	00 
    acd3:	48 8d 0d dc 55 00 00 	lea    0x55dc(%rip),%rcx        # 102b6 <_IO_stdin_used+0x2b6>
    acda:	4c 89 e7             	mov    %r12,%rdi
    acdd:	e8 de 89 ff ff       	call   36c0 <__sprintf_chk@plt>
    ace2:	e9 f9 f0 ff ff       	jmp    9de0 <fwp_write+0x80>
    ace7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    acec:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    acf1:	31 d2                	xor    %edx,%edx
    acf3:	48 89 ef             	mov    %rbp,%rdi
    acf6:	e8 45 8d ff ff       	call   3a40 <fwp_fmt_u128>
    acfb:	eb bf                	jmp    acbc <fwp_write+0xf5c>
    acfd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    ad04:	4e 61 4e 00 
    ad08:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ad0f:	00 
    ad10:	e9 cb f0 ff ff       	jmp    9de0 <fwp_write+0x80>
    ad15:	44 89 0c 24          	mov    %r9d,(%rsp)
    ad19:	48 89 c8             	mov    %rcx,%rax
    ad1c:	48 85 d2             	test   %rdx,%rdx
    ad1f:	78 51                	js     ad72 <fwp_write+0x1012>
    ad21:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ad26:	48 89 c6             	mov    %rax,%rsi
    ad29:	48 89 ef             	mov    %rbp,%rdi
    ad2c:	e8 0f 8d ff ff       	call   3a40 <fwp_fmt_u128>
    ad31:	44 8b 0c 24          	mov    (%rsp),%r9d
    ad35:	49 63 c1             	movslq %r9d,%rax
    ad38:	49 89 e8             	mov    %rbp,%r8
    ad3b:	ba 00 02 00 00       	mov    $0x200,%edx
    ad40:	be 02 00 00 00       	mov    $0x2,%esi
    ad45:	48 c1 e0 04          	shl    $0x4,%rax
    ad49:	48 8d 3d d0 76 00 00 	lea    0x76d0(%rip),%rdi        # 12420 <units.1>
    ad50:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ad57:	00 
    ad58:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    ad5c:	48 8d 0d 4e 55 00 00 	lea    0x554e(%rip),%rcx        # 102b1 <_IO_stdin_used+0x2b1>
    ad63:	4c 89 e7             	mov    %r12,%rdi
    ad66:	31 c0                	xor    %eax,%eax
    ad68:	e8 53 89 ff ff       	call   36c0 <__sprintf_chk@plt>
    ad6d:	e9 6e f0 ff ff       	jmp    9de0 <fwp_write+0x80>
    ad72:	48 f7 d8             	neg    %rax
    ad75:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    ad7a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    ad7f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ad84:	48 83 d2 00          	adc    $0x0,%rdx
    ad88:	48 89 c6             	mov    %rax,%rsi
    ad8b:	48 f7 da             	neg    %rdx
    ad8e:	e8 ad 8c ff ff       	call   3a40 <fwp_fmt_u128>
    ad93:	44 8b 0c 24          	mov    (%rsp),%r9d
    ad97:	eb 9c                	jmp    ad35 <fwp_write+0xfd5>
    ad99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000ada0 <fwp_hof0.constprop.0>:
    ada0:	55                   	push   %rbp
    ada1:	48 89 e5             	mov    %rsp,%rbp
    ada4:	41 57                	push   %r15
    ada6:	41 56                	push   %r14
    ada8:	41 55                	push   %r13
    adaa:	41 54                	push   %r12
    adac:	53                   	push   %rbx
    adad:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    adb4:	48 89 bd 58 ff ff ff 	mov    %rdi,-0xa8(%rbp)
    adbb:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    adc2:	00 00 
    adc4:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    adc8:	31 c0                	xor    %eax,%eax
    adca:	48 85 f6             	test   %rsi,%rsi
    adcd:	0f 84 cc 06 00 00    	je     b49f <fwp_hof0.constprop.0+0x6ff>
    add3:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
    add7:	49 89 f7             	mov    %rsi,%r15
    adda:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
    ade1:	48 8d 35 58 1a 06 00 	lea    0x61a58(%rip),%rsi        # 6c840 <fwp_heap>
    ade8:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    adef:	48 8b be d8 13 00 00 	mov    0x13d8(%rsi),%rdi
    adf6:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    adfd:	48 89 fa             	mov    %rdi,%rdx
    ae00:	48 89 7d a8          	mov    %rdi,-0x58(%rbp)
    ae04:	48 c1 e2 10          	shl    $0x10,%rdx
    ae08:	48 39 d0             	cmp    %rdx,%rax
    ae0b:	73 6b                	jae    ae78 <fwp_hof0.constprop.0+0xd8>
    ae0d:	48 89 c2             	mov    %rax,%rdx
    ae10:	48 c1 ea 10          	shr    $0x10,%rdx
    ae14:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ae18:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    ae1f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ae23:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    ae27:	48 85 ff             	test   %rdi,%rdi
    ae2a:	74 4c                	je     ae78 <fwp_hof0.constprop.0+0xd8>
    ae2c:	0f b6 0a             	movzbl (%rdx),%ecx
    ae2f:	80 f9 02             	cmp    $0x2,%cl
    ae32:	0f 84 11 0c 00 00    	je     ba49 <fwp_hof0.constprop.0+0xca9>
    ae38:	80 f9 01             	cmp    $0x1,%cl
    ae3b:	75 3b                	jne    ae78 <fwp_hof0.constprop.0+0xd8>
    ae3d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ae40:	0f b7 c0             	movzwl %ax,%eax
    ae43:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ae46:	48 0f af c1          	imul   %rcx,%rax
    ae4a:	48 c1 e8 20          	shr    $0x20,%rax
    ae4e:	48 39 d0             	cmp    %rdx,%rax
    ae51:	73 25                	jae    ae78 <fwp_hof0.constprop.0+0xd8>
    ae53:	48 01 c7             	add    %rax,%rdi
    ae56:	0f b6 07             	movzbl (%rdi),%eax
    ae59:	84 c0                	test   %al,%al
    ae5b:	74 1b                	je     ae78 <fwp_hof0.constprop.0+0xd8>
    ae5d:	8b 35 a5 36 06 00    	mov    0x636a5(%rip),%esi        # 6e508 <iteration_active>
    ae63:	85 f6                	test   %esi,%esi
    ae65:	0f 85 ec 0b 00 00    	jne    ba57 <fwp_hof0.constprop.0+0xcb7>
    ae6b:	3c fd                	cmp    $0xfd,%al
    ae6d:	0f 87 cd 0c 00 00    	ja     bb40 <fwp_hof0.constprop.0+0xda0>
    ae73:	83 c0 01             	add    $0x1,%eax
    ae76:	88 07                	mov    %al,(%rdi)
    ae78:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    ae7f:	4c 89 bd 50 ff ff ff 	mov    %r15,-0xb0(%rbp)
    ae86:	48 c7 85 60 ff ff ff 	movq   $0xc7,-0xa0(%rbp)
    ae8d:	c7 00 00 00 
    ae91:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    ae95:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    ae99:	48 8b 15 f8 35 06 00 	mov    0x635f8(%rip),%rdx        # 6e498 <fwp_fns>
    aea0:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
    aea4:	48 8d 05 6d 91 00 00 	lea    0x916d(%rip),%rax        # 14018 <fc12>
    aeab:	44 8b 20             	mov    (%rax),%r12d
    aeae:	49 c1 e4 05          	shl    $0x5,%r12
    aeb2:	49 01 d4             	add    %rdx,%r12
    aeb5:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
    aeba:	48 85 c9             	test   %rcx,%rcx
    aebd:	0f 84 53 0b 00 00    	je     ba16 <fwp_hof0.constprop.0+0xc76>
    aec3:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    aec8:	0f 84 2a 09 00 00    	je     b7f8 <fwp_hof0.constprop.0+0xa58>
    aece:	48 8d 1d 6b 19 06 00 	lea    0x6196b(%rip),%rbx        # 6c840 <fwp_heap>
    aed5:	48 8d 05 3c 91 00 00 	lea    0x913c(%rip),%rax        # 14018 <fc12>
    aedc:	48 8b b3 d8 13 00 00 	mov    0x13d8(%rbx),%rsi
    aee3:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    aeea:	48 89 f1             	mov    %rsi,%rcx
    aeed:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
    aef1:	48 c1 e1 10          	shl    $0x10,%rcx
    aef5:	48 39 c8             	cmp    %rcx,%rax
    aef8:	73 71                	jae    af6b <fwp_hof0.constprop.0+0x1cb>
    aefa:	48 89 c1             	mov    %rax,%rcx
    aefd:	48 c1 e9 10          	shr    $0x10,%rcx
    af01:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    af05:	48 8b 8b f8 13 00 00 	mov    0x13f8(%rbx),%rcx
    af0c:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    af10:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    af14:	48 85 ff             	test   %rdi,%rdi
    af17:	74 52                	je     af6b <fwp_hof0.constprop.0+0x1cb>
    af19:	0f b6 31             	movzbl (%rcx),%esi
    af1c:	40 80 fe 02          	cmp    $0x2,%sil
    af20:	0f 84 ed 09 00 00    	je     b913 <fwp_hof0.constprop.0+0xb73>
    af26:	40 80 fe 01          	cmp    $0x1,%sil
    af2a:	75 3f                	jne    af6b <fwp_hof0.constprop.0+0x1cb>
    af2c:	8b 71 18             	mov    0x18(%rcx),%esi
    af2f:	0f b7 c0             	movzwl %ax,%eax
    af32:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    af35:	48 0f af c6          	imul   %rsi,%rax
    af39:	48 c1 e8 20          	shr    $0x20,%rax
    af3d:	48 39 c8             	cmp    %rcx,%rax
    af40:	73 29                	jae    af6b <fwp_hof0.constprop.0+0x1cb>
    af42:	48 01 c7             	add    %rax,%rdi
    af45:	0f b6 07             	movzbl (%rdi),%eax
    af48:	84 c0                	test   %al,%al
    af4a:	74 1f                	je     af6b <fwp_hof0.constprop.0+0x1cb>
    af4c:	8b 0d b6 35 06 00    	mov    0x635b6(%rip),%ecx        # 6e508 <iteration_active>
    af52:	85 c9                	test   %ecx,%ecx
    af54:	74 08                	je     af5e <fwp_hof0.constprop.0+0x1be>
    af56:	48 83 05 92 35 06 00 	addq   $0x1,0x63592(%rip)        # 6e4f0 <iteration_retains>
    af5d:	01 
    af5e:	3c fd                	cmp    $0xfd,%al
    af60:	0f 87 8a 0a 00 00    	ja     b9f0 <fwp_hof0.constprop.0+0xc50>
    af66:	83 c0 01             	add    $0x1,%eax
    af69:	88 07                	mov    %al,(%rdi)
    af6b:	48 8d 05 a6 90 00 00 	lea    0x90a6(%rip),%rax        # 14018 <fc12>
    af72:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    af79:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    af7d:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    af84:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    af88:	48 8d 05 89 90 00 00 	lea    0x9089(%rip),%rax        # 14018 <fc12>
    af8f:	41 8b 0c 24          	mov    (%r12),%ecx
    af93:	2b 48 04             	sub    0x4(%rax),%ecx
    af96:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    af9a:	44 8b 6d 94          	mov    -0x6c(%rbp),%r13d
    af9e:	89 4d 90             	mov    %ecx,-0x70(%rbp)
    afa1:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    afa5:	49 89 c1             	mov    %rax,%r9
    afa8:	8b 00                	mov    (%rax),%eax
    afaa:	44 39 e9             	cmp    %r13d,%ecx
    afad:	44 0f 46 e9          	cmovbe %ecx,%r13d
    afb1:	4c 89 cb             	mov    %r9,%rbx
    afb4:	48 c1 e0 05          	shl    $0x5,%rax
    afb8:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    afbc:	44 89 ad 7c ff ff ff 	mov    %r13d,-0x84(%rbp)
    afc3:	4d 8b 50 18          	mov    0x18(%r8),%r10
    afc7:	4d 85 d2             	test   %r10,%r10
    afca:	75 5c                	jne    b028 <fwp_hof0.constprop.0+0x288>
    afcc:	e9 12 02 00 00       	jmp    b1e3 <fwp_hof0.constprop.0+0x443>
    afd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    afd8:	85 db                	test   %ebx,%ebx
    afda:	74 6a                	je     b046 <fwp_hof0.constprop.0+0x2a6>
    afdc:	4c 89 e7             	mov    %r12,%rdi
    afdf:	41 ff 12             	call   *(%r10)
    afe2:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    afe6:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
    afea:	e8 81 c1 ff ff       	call   7170 <fwp_closure_drop>
    afef:	45 39 ee             	cmp    %r13d,%r14d
    aff2:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    aff6:	0f 84 ec 07 00 00    	je     b7e8 <fwp_hof0.constprop.0+0xa48>
    affc:	44 8b 00             	mov    (%rax),%r8d
    afff:	41 29 df             	sub    %ebx,%r15d
    b002:	4f 8d 24 f4          	lea    (%r12,%r14,8),%r12
    b006:	49 89 c1             	mov    %rax,%r9
    b009:	45 89 fd             	mov    %r15d,%r13d
    b00c:	49 c1 e0 05          	shl    $0x5,%r8
    b010:	4c 03 05 81 34 06 00 	add    0x63481(%rip),%r8        # 6e498 <fwp_fns>
    b017:	4d 8b 50 18          	mov    0x18(%r8),%r10
    b01b:	4d 85 d2             	test   %r10,%r10
    b01e:	0f 84 bc 01 00 00    	je     b1e0 <fwp_hof0.constprop.0+0x440>
    b024:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b028:	41 8b 49 04          	mov    0x4(%r9),%ecx
    b02c:	41 8b 18             	mov    (%r8),%ebx
    b02f:	46 8d 3c 29          	lea    (%rcx,%r13,1),%r15d
    b033:	41 39 df             	cmp    %ebx,%r15d
    b036:	0f 82 8c 04 00 00    	jb     b4c8 <fwp_hof0.constprop.0+0x728>
    b03c:	41 89 de             	mov    %ebx,%r14d
    b03f:	41 29 ce             	sub    %ecx,%r14d
    b042:	85 c9                	test   %ecx,%ecx
    b044:	74 92                	je     afd8 <fwp_hof0.constprop.0+0x238>
    b046:	85 db                	test   %ebx,%ebx
    b048:	b8 01 00 00 00       	mov    $0x1,%eax
    b04d:	48 89 e6             	mov    %rsp,%rsi
    b050:	48 89 65 a0          	mov    %rsp,-0x60(%rbp)
    b054:	0f 45 c3             	cmovne %ebx,%eax
    b057:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    b05e:	00 
    b05f:	48 c1 e8 04          	shr    $0x4,%rax
    b063:	48 c1 e0 04          	shl    $0x4,%rax
    b067:	48 89 c7             	mov    %rax,%rdi
    b06a:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    b071:	48 29 fe             	sub    %rdi,%rsi
    b074:	48 39 f4             	cmp    %rsi,%rsp
    b077:	74 15                	je     b08e <fwp_hof0.constprop.0+0x2ee>
    b079:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    b080:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    b087:	00 00 
    b089:	48 39 f4             	cmp    %rsi,%rsp
    b08c:	75 eb                	jne    b079 <fwp_hof0.constprop.0+0x2d9>
    b08e:	25 ff 0f 00 00       	and    $0xfff,%eax
    b093:	48 29 c4             	sub    %rax,%rsp
    b096:	48 85 c0             	test   %rax,%rax
    b099:	74 06                	je     b0a1 <fwp_hof0.constprop.0+0x301>
    b09b:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    b0a1:	89 cf                	mov    %ecx,%edi
    b0a3:	49 89 e3             	mov    %rsp,%r11
    b0a6:	31 c0                	xor    %eax,%eax
    b0a8:	48 c1 e7 03          	shl    $0x3,%rdi
    b0ac:	85 c9                	test   %ecx,%ecx
    b0ae:	74 22                	je     b0d2 <fwp_hof0.constprop.0+0x332>
    b0b0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b0b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b0bc:	00 00 00 00 
    b0c0:	49 8b 54 01 08       	mov    0x8(%r9,%rax,1),%rdx
    b0c5:	49 89 14 03          	mov    %rdx,(%r11,%rax,1)
    b0c9:	48 83 c0 08          	add    $0x8,%rax
    b0cd:	48 39 c7             	cmp    %rax,%rdi
    b0d0:	75 ee                	jne    b0c0 <fwp_hof0.constprop.0+0x320>
    b0d2:	45 85 f6             	test   %r14d,%r14d
    b0d5:	74 3e                	je     b115 <fwp_hof0.constprop.0+0x375>
    b0d7:	44 89 f6             	mov    %r14d,%esi
    b0da:	4c 89 e0             	mov    %r12,%rax
    b0dd:	49 8d 3c f4          	lea    (%r12,%rsi,8),%rdi
    b0e1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b0e8:	00 00 
    b0ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b0f1:	00 00 00 00 
    b0f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b0fc:	00 00 00 00 
    b100:	48 8b 30             	mov    (%rax),%rsi
    b103:	89 ca                	mov    %ecx,%edx
    b105:	48 83 c0 08          	add    $0x8,%rax
    b109:	83 c1 01             	add    $0x1,%ecx
    b10c:	49 89 34 d3          	mov    %rsi,(%r11,%rdx,8)
    b110:	48 39 c7             	cmp    %rax,%rdi
    b113:	75 eb                	jne    b100 <fwp_hof0.constprop.0+0x360>
    b115:	48 8d 15 24 17 06 00 	lea    0x61724(%rip),%rdx        # 6c840 <fwp_heap>
    b11c:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b120:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    b127:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    b12e:	48 89 f1             	mov    %rsi,%rcx
    b131:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
    b135:	48 c1 e1 10          	shl    $0x10,%rcx
    b139:	48 39 c8             	cmp    %rcx,%rax
    b13c:	73 4c                	jae    b18a <fwp_hof0.constprop.0+0x3ea>
    b13e:	48 89 c1             	mov    %rax,%rcx
    b141:	48 c1 e9 10          	shr    $0x10,%rcx
    b145:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b149:	48 8b 0d e8 2a 06 00 	mov    0x62ae8(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    b150:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b154:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    b158:	48 85 f6             	test   %rsi,%rsi
    b15b:	74 2d                	je     b18a <fwp_hof0.constprop.0+0x3ea>
    b15d:	0f b6 39             	movzbl (%rcx),%edi
    b160:	40 80 ff 02          	cmp    $0x2,%dil
    b164:	74 6a                	je     b1d0 <fwp_hof0.constprop.0+0x430>
    b166:	40 80 ff 01          	cmp    $0x1,%dil
    b16a:	75 1e                	jne    b18a <fwp_hof0.constprop.0+0x3ea>
    b16c:	8b 79 18             	mov    0x18(%rcx),%edi
    b16f:	0f b7 c0             	movzwl %ax,%eax
    b172:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b175:	48 0f af c7          	imul   %rdi,%rax
    b179:	48 c1 e8 20          	shr    $0x20,%rax
    b17d:	48 39 c8             	cmp    %rcx,%rax
    b180:	73 08                	jae    b18a <fwp_hof0.constprop.0+0x3ea>
    b182:	48 01 c6             	add    %rax,%rsi
    b185:	80 3e 01             	cmpb   $0x1,(%rsi)
    b188:	74 36                	je     b1c0 <fwp_hof0.constprop.0+0x420>
    b18a:	4c 89 45 80          	mov    %r8,-0x80(%rbp)
    b18e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b192:	be 01 00 00 00       	mov    $0x1,%esi
    b197:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
    b19b:	41 ff 52 08          	call   *0x8(%r10)
    b19f:	4c 8b 5d 98          	mov    -0x68(%rbp),%r11
    b1a3:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
    b1a7:	49 8b 40 18          	mov    0x18(%r8),%rax
    b1ab:	4c 89 df             	mov    %r11,%rdi
    b1ae:	ff 10                	call   *(%rax)
    b1b0:	48 8b 65 a0          	mov    -0x60(%rbp),%rsp
    b1b4:	e9 29 fe ff ff       	jmp    afe2 <fwp_hof0.constprop.0+0x242>
    b1b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b1c0:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    b1c7:	00 
    b1c8:	eb dd                	jmp    b1a7 <fwp_hof0.constprop.0+0x407>
    b1ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b1d0:	66 85 c0             	test   %ax,%ax
    b1d3:	75 b5                	jne    b18a <fwp_hof0.constprop.0+0x3ea>
    b1d5:	eb ae                	jmp    b185 <fwp_hof0.constprop.0+0x3e5>
    b1d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b1de:	00 00 
    b1e0:	48 89 c3             	mov    %rax,%rbx
    b1e3:	48 89 df             	mov    %rbx,%rdi
    b1e6:	e8 45 b8 ff ff       	call   6a30 <fwp_rc_share>
    b1eb:	45 85 ed             	test   %r13d,%r13d
    b1ee:	74 21                	je     b211 <fwp_hof0.constprop.0+0x471>
    b1f0:	44 89 ea             	mov    %r13d,%edx
    b1f3:	4d 89 e7             	mov    %r12,%r15
    b1f6:	4d 8d 34 d4          	lea    (%r12,%rdx,8),%r14
    b1fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b200:	49 8b 3f             	mov    (%r15),%rdi
    b203:	49 83 c7 08          	add    $0x8,%r15
    b207:	e8 24 b8 ff ff       	call   6a30 <fwp_rc_share>
    b20c:	4d 39 f7             	cmp    %r14,%r15
    b20f:	75 ef                	jne    b200 <fwp_hof0.constprop.0+0x460>
    b211:	4c 89 e2             	mov    %r12,%rdx
    b214:	44 89 ee             	mov    %r13d,%esi
    b217:	48 89 df             	mov    %rbx,%rdi
    b21a:	e8 e1 ae ff ff       	call   6100 <fwp_apply>
    b21f:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b223:	8b 75 94             	mov    -0x6c(%rbp),%esi
    b226:	39 75 90             	cmp    %esi,-0x70(%rbp)
    b229:	0f 83 87 00 00 00    	jae    b2b6 <fwp_hof0.constprop.0+0x516>
    b22f:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    b235:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    b239:	48 89 c3             	mov    %rax,%rbx
    b23c:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    b240:	48 8b 15 51 32 06 00 	mov    0x63251(%rip),%rdx        # 6e498 <fwp_fns>
    b247:	29 de                	sub    %ebx,%esi
    b249:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b24d:	89 75 94             	mov    %esi,-0x6c(%rbp)
    b250:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    b254:	44 8b 26             	mov    (%rsi),%r12d
    b257:	48 89 f0             	mov    %rsi,%rax
    b25a:	49 c1 e4 05          	shl    $0x5,%r12
    b25e:	49 01 d4             	add    %rdx,%r12
    b261:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
    b267:	0f 85 22 fd ff ff    	jne    af8f <fwp_hof0.constprop.0+0x1ef>
    b26d:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b271:	e8 ba b7 ff ff       	call   6a30 <fwp_rc_share>
    b276:	44 8b 75 94          	mov    -0x6c(%rbp),%r14d
    b27a:	45 85 f6             	test   %r14d,%r14d
    b27d:	74 23                	je     b2a2 <fwp_hof0.constprop.0+0x502>
    b27f:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    b283:	31 db                	xor    %ebx,%ebx
    b285:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b28c:	00 00 00 00 
    b290:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b294:	48 83 c3 01          	add    $0x1,%rbx
    b298:	e8 93 b7 ff ff       	call   6a30 <fwp_rc_share>
    b29d:	44 39 f3             	cmp    %r14d,%ebx
    b2a0:	72 ee                	jb     b290 <fwp_hof0.constprop.0+0x4f0>
    b2a2:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    b2a6:	8b 75 94             	mov    -0x6c(%rbp),%esi
    b2a9:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b2ad:	e8 4e ae ff ff       	call   6100 <fwp_apply>
    b2b2:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b2b6:	48 83 ad 60 ff ff ff 	subq   $0x1,-0xa0(%rbp)
    b2bd:	01 
    b2be:	0f 85 d1 fb ff ff    	jne    ae95 <fwp_hof0.constprop.0+0xf5>
    b2c4:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    b2c8:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    b2cf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b2d3:	b9 01 00 00 00       	mov    $0x1,%ecx
    b2d8:	48 8d 15 c1 88 00 00 	lea    0x88c1(%rip),%rdx        # 13ba0 <d0>
    b2df:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
    b2e6:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
    b2ed:	00 
    b2ee:	0f 29 45 b0          	movaps %xmm0,-0x50(%rbp)
    b2f2:	e8 69 ea ff ff       	call   9d60 <fwp_write>
    b2f7:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
    b2fb:	4c 8b 75 b8          	mov    -0x48(%rbp),%r14
    b2ff:	48 8d 05 66 4d 00 00 	lea    0x4d66(%rip),%rax        # 1006c <_IO_stdin_used+0x6c>
    b306:	48 85 c9             	test   %rcx,%rcx
    b309:	48 0f 44 c8          	cmove  %rax,%rcx
    b30d:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    b311:	0f 87 15 08 00 00    	ja     bb2c <fwp_hof0.constprop.0+0xd8c>
    b317:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    b31b:	be 01 00 00 00       	mov    $0x1,%esi
    b320:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    b324:	e8 e7 ab ff ff       	call   5f10 <fwp_heap_alloc>
    b329:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
    b32d:	4c 89 f2             	mov    %r14,%rdx
    b330:	4c 89 30             	mov    %r14,(%rax)
    b333:	4c 8d 60 08          	lea    0x8(%rax),%r12
    b337:	48 89 c3             	mov    %rax,%rbx
    b33a:	4c 89 e7             	mov    %r12,%rdi
    b33d:	e8 3e 82 ff ff       	call   3580 <memcpy@plt>
    b342:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    b348:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
    b34c:	e8 5f 80 ff ff       	call   33b0 <free@plt>
    b351:	48 8d 35 e8 14 06 00 	lea    0x614e8(%rip),%rsi        # 6c840 <fwp_heap>
    b358:	48 89 d8             	mov    %rbx,%rax
    b35b:	48 8b be d8 13 00 00 	mov    0x13d8(%rsi),%rdi
    b362:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b369:	48 89 fa             	mov    %rdi,%rdx
    b36c:	48 89 7d a0          	mov    %rdi,-0x60(%rbp)
    b370:	48 c1 e2 10          	shl    $0x10,%rdx
    b374:	48 39 d0             	cmp    %rdx,%rax
    b377:	73 57                	jae    b3d0 <fwp_hof0.constprop.0+0x630>
    b379:	48 89 c2             	mov    %rax,%rdx
    b37c:	48 c1 ea 10          	shr    $0x10,%rdx
    b380:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b384:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b38b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b38f:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b393:	4d 85 f6             	test   %r14,%r14
    b396:	74 38                	je     b3d0 <fwp_hof0.constprop.0+0x630>
    b398:	0f b6 0a             	movzbl (%rdx),%ecx
    b39b:	80 f9 02             	cmp    $0x2,%cl
    b39e:	0f 84 da 06 00 00    	je     ba7e <fwp_hof0.constprop.0+0xcde>
    b3a4:	80 f9 01             	cmp    $0x1,%cl
    b3a7:	75 27                	jne    b3d0 <fwp_hof0.constprop.0+0x630>
    b3a9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b3ac:	0f b7 c0             	movzwl %ax,%eax
    b3af:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b3b2:	48 0f af c1          	imul   %rcx,%rax
    b3b6:	48 c1 e8 20          	shr    $0x20,%rax
    b3ba:	48 39 d0             	cmp    %rdx,%rax
    b3bd:	73 11                	jae    b3d0 <fwp_hof0.constprop.0+0x630>
    b3bf:	49 01 c6             	add    %rax,%r14
    b3c2:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b3c6:	0f 84 84 07 00 00    	je     bb50 <fwp_hof0.constprop.0+0xdb0>
    b3cc:	41 c6 06 01          	movb   $0x1,(%r14)
    b3d0:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b3d4:	e8 b7 ba ff ff       	call   6e90 <fwp_drop0>
    b3d9:	48 8b 13             	mov    (%rbx),%rdx
    b3dc:	be 01 00 00 00       	mov    $0x1,%esi
    b3e1:	4c 89 e7             	mov    %r12,%rdi
    b3e4:	48 8b 0d b5 30 06 00 	mov    0x630b5(%rip),%rcx        # 6e4a0 <fwp_prog_out>
    b3eb:	e8 70 82 ff ff       	call   3660 <fwrite@plt>
    b3f0:	48 8b 35 a9 30 06 00 	mov    0x630a9(%rip),%rsi        # 6e4a0 <fwp_prog_out>
    b3f7:	bf 0a 00 00 00       	mov    $0xa,%edi
    b3fc:	e8 cf 80 ff ff       	call   34d0 <fputc@plt>
    b401:	48 8d 35 38 14 06 00 	lea    0x61438(%rip),%rsi        # 6c840 <fwp_heap>
    b408:	48 89 d8             	mov    %rbx,%rax
    b40b:	48 8b be d8 13 00 00 	mov    0x13d8(%rsi),%rdi
    b412:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b419:	48 89 fa             	mov    %rdi,%rdx
    b41c:	48 89 7d a8          	mov    %rdi,-0x58(%rbp)
    b420:	48 c1 e2 10          	shl    $0x10,%rdx
    b424:	48 39 d0             	cmp    %rdx,%rax
    b427:	73 69                	jae    b492 <fwp_hof0.constprop.0+0x6f2>
    b429:	48 89 c2             	mov    %rax,%rdx
    b42c:	48 c1 ea 10          	shr    $0x10,%rdx
    b430:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b434:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b43b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b43f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b443:	4d 85 e4             	test   %r12,%r12
    b446:	74 4a                	je     b492 <fwp_hof0.constprop.0+0x6f2>
    b448:	0f b6 0a             	movzbl (%rdx),%ecx
    b44b:	80 f9 02             	cmp    $0x2,%cl
    b44e:	0f 84 38 06 00 00    	je     ba8c <fwp_hof0.constprop.0+0xcec>
    b454:	80 f9 01             	cmp    $0x1,%cl
    b457:	75 39                	jne    b492 <fwp_hof0.constprop.0+0x6f2>
    b459:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b45c:	0f b7 c0             	movzwl %ax,%eax
    b45f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b462:	48 0f af c1          	imul   %rcx,%rax
    b466:	48 c1 e8 20          	shr    $0x20,%rax
    b46a:	48 39 d0             	cmp    %rdx,%rax
    b46d:	73 23                	jae    b492 <fwp_hof0.constprop.0+0x6f2>
    b46f:	49 01 c4             	add    %rax,%r12
    b472:	41 0f b6 04 24       	movzbl (%r12),%eax
    b477:	84 c0                	test   %al,%al
    b479:	74 17                	je     b492 <fwp_hof0.constprop.0+0x6f2>
    b47b:	3c 01                	cmp    $0x1,%al
    b47d:	0f 84 e1 05 00 00    	je     ba64 <fwp_hof0.constprop.0+0xcc4>
    b483:	3c ff                	cmp    $0xff,%al
    b485:	0f 84 0f 06 00 00    	je     ba9a <fwp_hof0.constprop.0+0xcfa>
    b48b:	83 e8 01             	sub    $0x1,%eax
    b48e:	41 88 04 24          	mov    %al,(%r12)
    b492:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    b496:	4d 85 ff             	test   %r15,%r15
    b499:	0f 85 42 f9 ff ff    	jne    ade1 <fwp_hof0.constprop.0+0x41>
    b49f:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    b4a3:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b4aa:	00 00 
    b4ac:	0f 85 98 06 00 00    	jne    bb4a <fwp_hof0.constprop.0+0xdaa>
    b4b2:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    b4b6:	31 c0                	xor    %eax,%eax
    b4b8:	5b                   	pop    %rbx
    b4b9:	41 5c                	pop    %r12
    b4bb:	41 5d                	pop    %r13
    b4bd:	41 5e                	pop    %r14
    b4bf:	41 5f                	pop    %r15
    b4c1:	5d                   	pop    %rbp
    b4c2:	c3                   	ret
    b4c3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b4c8:	44 8b 1d 39 30 06 00 	mov    0x63039(%rip),%r11d        # 6e508 <iteration_active>
    b4cf:	41 8d 77 01          	lea    0x1(%r15),%esi
    b4d3:	8b 05 0b 27 06 00    	mov    0x6270b(%rip),%eax        # 6dbe4 <fwp_heap+0x13a4>
    b4d9:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    b4e0:	00 
    b4e1:	45 85 db             	test   %r11d,%r11d
    b4e4:	0f 84 f3 03 00 00    	je     b8dd <fwp_hof0.constprop.0+0xb3d>
    b4ea:	48 83 05 0e 30 06 00 	addq   $0x1,0x6300e(%rip)        # 6e500 <iteration_requests>
    b4f1:	01 
    b4f2:	48 01 3d ff 2f 06 00 	add    %rdi,0x62fff(%rip)        # 6e4f8 <iteration_bytes>
    b4f9:	85 c0                	test   %eax,%eax
    b4fb:	0f 84 ca 04 00 00    	je     b9cb <fwp_hof0.constprop.0+0xc2b>
    b501:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    b508:	0f 87 bd 04 00 00    	ja     b9cb <fwp_hof0.constprop.0+0xc2b>
    b50e:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    b512:	48 8d 1d 27 13 06 00 	lea    0x61327(%rip),%rbx        # 6c840 <fwp_heap>
    b519:	48 c1 e8 04          	shr    $0x4,%rax
    b51d:	0f b6 94 03 a0 0f 00 	movzbl 0xfa0(%rbx,%rax,1),%edx
    b524:	00 
    b525:	8b 84 93 00 0f 00 00 	mov    0xf00(%rbx,%rdx,4),%eax
    b52c:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    b530:	48 8d 14 d3          	lea    (%rbx,%rdx,8),%rdx
    b534:	4c 8b 12             	mov    (%rdx),%r10
    b537:	4d 85 d2             	test   %r10,%r10
    b53a:	0f 84 e1 03 00 00    	je     b921 <fwp_hof0.constprop.0+0xb81>
    b540:	49 8b 1a             	mov    (%r10),%rbx
    b543:	48 f7 d3             	not    %rbx
    b546:	48 89 1a             	mov    %rbx,(%rdx)
    b549:	48 39 c7             	cmp    %rax,%rdi
    b54c:	73 6c                	jae    b5ba <fwp_hof0.constprop.0+0x81a>
    b54e:	48 89 fa             	mov    %rdi,%rdx
    b551:	48 83 c7 08          	add    $0x8,%rdi
    b555:	49 c7 04 f2 00 00 00 	movq   $0x0,(%r10,%rsi,8)
    b55c:	00 
    b55d:	48 f7 d2             	not    %rdx
    b560:	48 01 c2             	add    %rax,%rdx
    b563:	48 c1 ea 03          	shr    $0x3,%rdx
    b567:	48 39 c7             	cmp    %rax,%rdi
    b56a:	73 4e                	jae    b5ba <fwp_hof0.constprop.0+0x81a>
    b56c:	83 e2 01             	and    $0x1,%edx
    b56f:	74 2f                	je     b5a0 <fwp_hof0.constprop.0+0x800>
    b571:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    b578:	00 
    b579:	48 83 c7 08          	add    $0x8,%rdi
    b57d:	48 39 c7             	cmp    %rax,%rdi
    b580:	73 38                	jae    b5ba <fwp_hof0.constprop.0+0x81a>
    b582:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b589:	00 
    b58a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b591:	00 00 00 00 
    b595:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b59c:	00 00 00 00 
    b5a0:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    b5a7:	00 
    b5a8:	49 c7 44 3a 08 00 00 	movq   $0x0,0x8(%r10,%rdi,1)
    b5af:	00 00 
    b5b1:	48 83 c7 10          	add    $0x10,%rdi
    b5b5:	48 39 c7             	cmp    %rax,%rdi
    b5b8:	72 e6                	jb     b5a0 <fwp_hof0.constprop.0+0x800>
    b5ba:	48 8d 3d 7f 12 06 00 	lea    0x6127f(%rip),%rdi        # 6c840 <fwp_heap>
    b5c1:	48 89 c2             	mov    %rax,%rdx
    b5c4:	48 03 97 20 14 00 00 	add    0x1420(%rdi),%rdx
    b5cb:	0f 82 4a 05 00 00    	jb     bb1b <fwp_hof0.constprop.0+0xd7b>
    b5d1:	48 89 97 20 14 00 00 	mov    %rdx,0x1420(%rdi)
    b5d8:	48 39 97 28 14 00 00 	cmp    %rdx,0x1428(%rdi)
    b5df:	73 07                	jae    b5e8 <fwp_hof0.constprop.0+0x848>
    b5e1:	48 89 15 80 26 06 00 	mov    %rdx,0x62680(%rip)        # 6dc68 <fwp_heap+0x1428>
    b5e8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b5ec:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    b5f1:	f2 0f 58 05 7f 26 06 	addsd  0x6267f(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    b5f8:	00 
    b5f9:	f2 0f 11 05 77 26 06 	movsd  %xmm0,0x62677(%rip)        # 6dc78 <fwp_heap+0x1438>
    b600:	00 
    b601:	45 85 db             	test   %r11d,%r11d
    b604:	74 33                	je     b639 <fwp_hof0.constprop.0+0x899>
    b606:	48 8b 05 53 26 06 00 	mov    0x62653(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    b60d:	48 85 c0             	test   %rax,%rax
    b610:	0f 88 64 03 00 00    	js     b97a <fwp_hof0.constprop.0+0xbda>
    b616:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b61a:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    b61f:	f2 0f 5c 05 c1 2e 06 	subsd  0x62ec1(%rip),%xmm0        # 6e4e8 <iteration_start_charge>
    b626:	00 
    b627:	66 0f 2f 05 b1 2e 06 	comisd 0x62eb1(%rip),%xmm0        # 6e4e0 <iteration_peak>
    b62e:	00 
    b62f:	76 08                	jbe    b639 <fwp_hof0.constprop.0+0x899>
    b631:	f2 0f 11 05 a7 2e 06 	movsd  %xmm0,0x62ea7(%rip)        # 6e4e0 <iteration_peak>
    b638:	00 
    b639:	66 41 0f 6e 01       	movd   (%r9),%xmm0
    b63e:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    b643:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    b647:	66 41 0f d6 02       	movq   %xmm0,(%r10)
    b64c:	85 c9                	test   %ecx,%ecx
    b64e:	74 37                	je     b687 <fwp_hof0.constprop.0+0x8e7>
    b650:	89 ca                	mov    %ecx,%edx
    b652:	49 8d 71 08          	lea    0x8(%r9),%rsi
    b656:	49 8d 7a 08          	lea    0x8(%r10),%rdi
    b65a:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b65d:	48 c1 e2 03          	shl    $0x3,%rdx
    b661:	4c 89 85 68 ff ff ff 	mov    %r8,-0x98(%rbp)
    b668:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
    b66c:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b670:	e8 7b 7f ff ff       	call   35f0 <memmove@plt>
    b675:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b679:	4c 8b 4d 98          	mov    -0x68(%rbp),%r9
    b67d:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b680:	4c 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%r8
    b687:	45 85 ed             	test   %r13d,%r13d
    b68a:	74 2b                	je     b6b7 <fwp_hof0.constprop.0+0x917>
    b68c:	45 89 ed             	mov    %r13d,%r13d
    b68f:	4b 8d 34 ec          	lea    (%r12,%r13,8),%rsi
    b693:	66 90                	xchg   %ax,%ax
    b695:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b69c:	00 00 00 00 
    b6a0:	49 8b 14 24          	mov    (%r12),%rdx
    b6a4:	89 c8                	mov    %ecx,%eax
    b6a6:	49 83 c4 08          	add    $0x8,%r12
    b6aa:	83 c1 01             	add    $0x1,%ecx
    b6ad:	49 89 54 c2 08       	mov    %rdx,0x8(%r10,%rax,8)
    b6b2:	4c 39 e6             	cmp    %r12,%rsi
    b6b5:	75 e9                	jne    b6a0 <fwp_hof0.constprop.0+0x900>
    b6b7:	48 8d 15 82 11 06 00 	lea    0x61182(%rip),%rdx        # 6c840 <fwp_heap>
    b6be:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b6c2:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    b6c9:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    b6d0:	48 89 f2             	mov    %rsi,%rdx
    b6d3:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
    b6d7:	48 c1 e2 10          	shl    $0x10,%rdx
    b6db:	48 39 d0             	cmp    %rdx,%rax
    b6de:	73 54                	jae    b734 <fwp_hof0.constprop.0+0x994>
    b6e0:	48 89 c2             	mov    %rax,%rdx
    b6e3:	48 c1 ea 10          	shr    $0x10,%rdx
    b6e7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b6eb:	48 8b 15 46 25 06 00 	mov    0x62546(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    b6f2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b6f6:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    b6fa:	48 85 c9             	test   %rcx,%rcx
    b6fd:	74 35                	je     b734 <fwp_hof0.constprop.0+0x994>
    b6ff:	0f b6 32             	movzbl (%rdx),%esi
    b702:	40 80 fe 02          	cmp    $0x2,%sil
    b706:	0f 84 37 02 00 00    	je     b943 <fwp_hof0.constprop.0+0xba3>
    b70c:	40 80 fe 01          	cmp    $0x1,%sil
    b710:	75 22                	jne    b734 <fwp_hof0.constprop.0+0x994>
    b712:	8b 72 18             	mov    0x18(%rdx),%esi
    b715:	0f b7 c0             	movzwl %ax,%eax
    b718:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b71b:	48 0f af c6          	imul   %rsi,%rax
    b71f:	48 c1 e8 20          	shr    $0x20,%rax
    b723:	48 39 d0             	cmp    %rdx,%rax
    b726:	73 0c                	jae    b734 <fwp_hof0.constprop.0+0x994>
    b728:	48 01 c1             	add    %rax,%rcx
    b72b:	80 39 01             	cmpb   $0x1,(%rcx)
    b72e:	0f 84 9c 01 00 00    	je     b8d0 <fwp_hof0.constprop.0+0xb30>
    b734:	49 8b 40 18          	mov    0x18(%r8),%rax
    b738:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b73c:	be 01 00 00 00       	mov    $0x1,%esi
    b741:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b745:	ff 50 08             	call   *0x8(%rax)
    b748:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b74c:	48 8d 35 ed 10 06 00 	lea    0x610ed(%rip),%rsi        # 6c840 <fwp_heap>
    b753:	4c 89 d0             	mov    %r10,%rax
    b756:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b75d:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b764:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    b768:	48 c1 e2 10          	shl    $0x10,%rdx
    b76c:	48 39 d0             	cmp    %rdx,%rax
    b76f:	73 59                	jae    b7ca <fwp_hof0.constprop.0+0xa2a>
    b771:	48 89 c2             	mov    %rax,%rdx
    b774:	48 c1 ea 10          	shr    $0x10,%rdx
    b778:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b77c:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b783:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b787:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b78b:	4d 85 e4             	test   %r12,%r12
    b78e:	74 3a                	je     b7ca <fwp_hof0.constprop.0+0xa2a>
    b790:	0f b6 0a             	movzbl (%rdx),%ecx
    b793:	80 f9 02             	cmp    $0x2,%cl
    b796:	0f 84 b5 01 00 00    	je     b951 <fwp_hof0.constprop.0+0xbb1>
    b79c:	80 f9 01             	cmp    $0x1,%cl
    b79f:	75 29                	jne    b7ca <fwp_hof0.constprop.0+0xa2a>
    b7a1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b7a4:	0f b7 c0             	movzwl %ax,%eax
    b7a7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b7aa:	48 0f af c1          	imul   %rcx,%rax
    b7ae:	48 c1 e8 20          	shr    $0x20,%rax
    b7b2:	48 39 d0             	cmp    %rdx,%rax
    b7b5:	73 13                	jae    b7ca <fwp_hof0.constprop.0+0xa2a>
    b7b7:	49 01 c4             	add    %rax,%r12
    b7ba:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b7bf:	0f 84 a0 01 00 00    	je     b965 <fwp_hof0.constprop.0+0xbc5>
    b7c5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b7ca:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b7ce:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b7d2:	e8 99 b9 ff ff       	call   7170 <fwp_closure_drop>
    b7d7:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b7db:	4c 89 55 a8          	mov    %r10,-0x58(%rbp)
    b7df:	e9 3f fa ff ff       	jmp    b223 <fwp_hof0.constprop.0+0x483>
    b7e4:	0f 1f 40 00          	nopl   0x0(%rax)
    b7e8:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b7ec:	e9 32 fa ff ff       	jmp    b223 <fwp_hof0.constprop.0+0x483>
    b7f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b7f8:	41 8b 34 24          	mov    (%r12),%esi
    b7fc:	8b 05 1a 88 00 00    	mov    0x881a(%rip),%eax        # 1401c <fc12+0x4>
    b802:	89 f7                	mov    %esi,%edi
    b804:	29 c7                	sub    %eax,%edi
    b806:	83 ff 01             	cmp    $0x1,%edi
    b809:	0f 85 bf f6 ff ff    	jne    aece <fwp_hof0.constprop.0+0x12e>
    b80f:	48 89 e3             	mov    %rsp,%rbx
    b812:	85 c0                	test   %eax,%eax
    b814:	0f 84 e7 01 00 00    	je     ba01 <fwp_hof0.constprop.0+0xc61>
    b81a:	89 f1                	mov    %esi,%ecx
    b81c:	ba 08 00 00 00       	mov    $0x8,%edx
    b821:	48 c1 e1 03          	shl    $0x3,%rcx
    b825:	85 f6                	test   %esi,%esi
    b827:	48 89 e6             	mov    %rsp,%rsi
    b82a:	48 0f 45 d1          	cmovne %rcx,%rdx
    b82e:	49 89 d7             	mov    %rdx,%r15
    b831:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    b835:	48 c1 ea 04          	shr    $0x4,%rdx
    b839:	48 c1 e2 04          	shl    $0x4,%rdx
    b83d:	48 89 d7             	mov    %rdx,%rdi
    b840:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    b847:	48 29 fe             	sub    %rdi,%rsi
    b84a:	48 39 f4             	cmp    %rsi,%rsp
    b84d:	74 15                	je     b864 <fwp_hof0.constprop.0+0xac4>
    b84f:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    b856:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    b85d:	00 00 
    b85f:	48 39 f4             	cmp    %rsi,%rsp
    b862:	75 eb                	jne    b84f <fwp_hof0.constprop.0+0xaaf>
    b864:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    b86a:	48 29 d4             	sub    %rdx,%rsp
    b86d:	48 85 d2             	test   %rdx,%rdx
    b870:	74 06                	je     b878 <fwp_hof0.constprop.0+0xad8>
    b872:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    b878:	4c 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%r14
    b87f:	00 
    b880:	4c 89 f9             	mov    %r15,%rcx
    b883:	48 8d 35 96 87 00 00 	lea    0x8796(%rip),%rsi        # 14020 <fwp_epfd>
    b88a:	48 89 e7             	mov    %rsp,%rdi
    b88d:	4c 89 f2             	mov    %r14,%rdx
    b890:	e8 bb 7c ff ff       	call   3550 <__memcpy_chk@plt>
    b895:	4d 39 f7             	cmp    %r14,%r15
    b898:	4c 89 f9             	mov    %r15,%rcx
    b89b:	4a 8d 3c 34          	lea    (%rsp,%r14,1),%rdi
    b89f:	49 0f 42 ce          	cmovb  %r14,%rcx
    b8a3:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
    b8aa:	ba 08 00 00 00       	mov    $0x8,%edx
    b8af:	4c 29 f1             	sub    %r14,%rcx
    b8b2:	e8 99 7c ff ff       	call   3550 <__memcpy_chk@plt>
    b8b7:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    b8bc:	48 89 e7             	mov    %rsp,%rdi
    b8bf:	ff 10                	call   *(%rax)
    b8c1:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b8c5:	e9 44 01 00 00       	jmp    ba0e <fwp_hof0.constprop.0+0xc6e>
    b8ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b8d0:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    b8d7:	00 
    b8d8:	e9 6f fe ff ff       	jmp    b74c <fwp_hof0.constprop.0+0x9ac>
    b8dd:	85 c0                	test   %eax,%eax
    b8df:	74 0d                	je     b8ee <fwp_hof0.constprop.0+0xb4e>
    b8e1:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    b8e8:	0f 86 20 fc ff ff    	jbe    b50e <fwp_hof0.constprop.0+0x76e>
    b8ee:	31 f6                	xor    %esi,%esi
    b8f0:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b8f3:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    b8f7:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    b8fb:	e8 10 a6 ff ff       	call   5f10 <fwp_heap_alloc>
    b900:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    b904:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    b908:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b90b:	49 89 c2             	mov    %rax,%r10
    b90e:	e9 26 fd ff ff       	jmp    b639 <fwp_hof0.constprop.0+0x899>
    b913:	66 85 c0             	test   %ax,%ax
    b916:	0f 85 4f f6 ff ff    	jne    af6b <fwp_hof0.constprop.0+0x1cb>
    b91c:	e9 24 f6 ff ff       	jmp    af45 <fwp_hof0.constprop.0+0x1a5>
    b921:	4c 8b 52 08          	mov    0x8(%rdx),%r10
    b925:	4d 85 d2             	test   %r10,%r10
    b928:	74 6e                	je     b998 <fwp_hof0.constprop.0+0xbf8>
    b92a:	48 8b 5a 10          	mov    0x10(%rdx),%rbx
    b92e:	4c 29 d3             	sub    %r10,%rbx
    b931:	48 39 c3             	cmp    %rax,%rbx
    b934:	72 62                	jb     b998 <fwp_hof0.constprop.0+0xbf8>
    b936:	49 8d 1c 02          	lea    (%r10,%rax,1),%rbx
    b93a:	48 89 5a 08          	mov    %rbx,0x8(%rdx)
    b93e:	e9 06 fc ff ff       	jmp    b549 <fwp_hof0.constprop.0+0x7a9>
    b943:	66 85 c0             	test   %ax,%ax
    b946:	0f 85 e8 fd ff ff    	jne    b734 <fwp_hof0.constprop.0+0x994>
    b94c:	e9 da fd ff ff       	jmp    b72b <fwp_hof0.constprop.0+0x98b>
    b951:	66 85 c0             	test   %ax,%ax
    b954:	0f 85 70 fe ff ff    	jne    b7ca <fwp_hof0.constprop.0+0xa2a>
    b95a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b95f:	0f 85 60 fe ff ff    	jne    b7c5 <fwp_hof0.constprop.0+0xa25>
    b965:	4c 89 e7             	mov    %r12,%rdi
    b968:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b96c:	e8 5f 9e ff ff       	call   57d0 <fwp_rc_forget_slot>
    b971:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b975:	e9 4b fe ff ff       	jmp    b7c5 <fwp_hof0.constprop.0+0xa25>
    b97a:	48 89 c2             	mov    %rax,%rdx
    b97d:	83 e0 01             	and    $0x1,%eax
    b980:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b984:	48 d1 ea             	shr    $1,%rdx
    b987:	48 09 c2             	or     %rax,%rdx
    b98a:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    b98f:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    b993:	e9 87 fc ff ff       	jmp    b61f <fwp_hof0.constprop.0+0x87f>
    b998:	31 f6                	xor    %esi,%esi
    b99a:	89 8d 68 ff ff ff    	mov    %ecx,-0x98(%rbp)
    b9a0:	44 89 5d 80          	mov    %r11d,-0x80(%rbp)
    b9a4:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    b9a8:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    b9ac:	e8 5f a5 ff ff       	call   5f10 <fwp_heap_alloc>
    b9b1:	8b 8d 68 ff ff ff    	mov    -0x98(%rbp),%ecx
    b9b7:	44 8b 5d 80          	mov    -0x80(%rbp),%r11d
    b9bb:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    b9bf:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    b9c3:	49 89 c2             	mov    %rax,%r10
    b9c6:	e9 36 fc ff ff       	jmp    b601 <fwp_hof0.constprop.0+0x861>
    b9cb:	31 f6                	xor    %esi,%esi
    b9cd:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b9d0:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    b9d4:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    b9d8:	e8 33 a5 ff ff       	call   5f10 <fwp_heap_alloc>
    b9dd:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    b9e1:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    b9e5:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b9e8:	49 89 c2             	mov    %rax,%r10
    b9eb:	e9 16 fc ff ff       	jmp    b606 <fwp_hof0.constprop.0+0x866>
    b9f0:	e8 bb 9c ff ff       	call   56b0 <fwp_rc_wide_dup>
    b9f5:	48 8b 15 9c 2a 06 00 	mov    0x62a9c(%rip),%rdx        # 6e498 <fwp_fns>
    b9fc:	e9 6a f5 ff ff       	jmp    af6b <fwp_hof0.constprop.0+0x1cb>
    ba01:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    ba08:	ff 11                	call   *(%rcx)
    ba0a:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    ba0e:	48 89 dc             	mov    %rbx,%rsp
    ba11:	e9 a0 f8 ff ff       	jmp    b2b6 <fwp_hof0.constprop.0+0x516>
    ba16:	48 89 c7             	mov    %rax,%rdi
    ba19:	e8 12 b0 ff ff       	call   6a30 <fwp_rc_share>
    ba1e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ba22:	e8 09 b0 ff ff       	call   6a30 <fwp_rc_share>
    ba27:	48 8d 05 ea 85 00 00 	lea    0x85ea(%rip),%rax        # 14018 <fc12>
    ba2e:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    ba35:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    ba39:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    ba40:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    ba44:	e9 59 f8 ff ff       	jmp    b2a2 <fwp_hof0.constprop.0+0x502>
    ba49:	66 85 c0             	test   %ax,%ax
    ba4c:	0f 85 26 f4 ff ff    	jne    ae78 <fwp_hof0.constprop.0+0xd8>
    ba52:	e9 ff f3 ff ff       	jmp    ae56 <fwp_hof0.constprop.0+0xb6>
    ba57:	48 83 05 91 2a 06 00 	addq   $0x1,0x62a91(%rip)        # 6e4f0 <iteration_retains>
    ba5e:	01 
    ba5f:	e9 07 f4 ff ff       	jmp    ae6b <fwp_hof0.constprop.0+0xcb>
    ba64:	48 89 df             	mov    %rbx,%rdi
    ba67:	e8 f4 b0 ff ff       	call   6b60 <fwp_rc_free_arr>
    ba6c:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    ba70:	4d 85 ff             	test   %r15,%r15
    ba73:	0f 85 68 f3 ff ff    	jne    ade1 <fwp_hof0.constprop.0+0x41>
    ba79:	e9 21 fa ff ff       	jmp    b49f <fwp_hof0.constprop.0+0x6ff>
    ba7e:	66 85 c0             	test   %ax,%ax
    ba81:	0f 85 49 f9 ff ff    	jne    b3d0 <fwp_hof0.constprop.0+0x630>
    ba87:	e9 36 f9 ff ff       	jmp    b3c2 <fwp_hof0.constprop.0+0x622>
    ba8c:	66 85 c0             	test   %ax,%ax
    ba8f:	0f 85 fd f9 ff ff    	jne    b492 <fwp_hof0.constprop.0+0x6f2>
    ba95:	e9 d8 f9 ff ff       	jmp    b472 <fwp_hof0.constprop.0+0x6d2>
    ba9a:	4c 89 e0             	mov    %r12,%rax
    ba9d:	48 8d 35 9c 0d 06 00 	lea    0x60d9c(%rip),%rsi        # 6c840 <fwp_heap>
    baa4:	48 c1 e8 11          	shr    $0x11,%rax
    baa8:	4c 31 e0             	xor    %r12,%rax
    baab:	48 89 c2             	mov    %rax,%rdx
    baae:	48 c1 ea 09          	shr    $0x9,%rdx
    bab2:	48 31 d0             	xor    %rdx,%rax
    bab5:	0f b6 c0             	movzbl %al,%eax
    bab8:	48 8b 94 c6 48 14 00 	mov    0x1448(%rsi,%rax,8),%rdx
    babf:	00 
    bac0:	48 85 d2             	test   %rdx,%rdx
    bac3:	75 24                	jne    bae9 <fwp_hof0.constprop.0+0xd49>
    bac5:	eb 59                	jmp    bb20 <fwp_hof0.constprop.0+0xd80>
    bac7:	0f 1f 00             	nopl   (%rax)
    baca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bad1:	00 00 00 00 
    bad5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    badc:	00 00 00 00 
    bae0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    bae4:	48 85 d2             	test   %rdx,%rdx
    bae7:	74 37                	je     bb20 <fwp_hof0.constprop.0+0xd80>
    bae9:	48 89 d0             	mov    %rdx,%rax
    baec:	4c 3b 22             	cmp    (%rdx),%r12
    baef:	75 ef                	jne    bae0 <fwp_hof0.constprop.0+0xd40>
    baf1:	48 8b 42 08          	mov    0x8(%rdx),%rax
    baf5:	48 83 e8 01          	sub    $0x1,%rax
    baf9:	48 89 42 08          	mov    %rax,0x8(%rdx)
    bafd:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    bb03:	0f 85 89 f9 ff ff    	jne    b492 <fwp_hof0.constprop.0+0x6f2>
    bb09:	4c 89 e7             	mov    %r12,%rdi
    bb0c:	e8 bf 9c ff ff       	call   57d0 <fwp_rc_forget_slot>
    bb11:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    bb16:	e9 77 f9 ff ff       	jmp    b492 <fwp_hof0.constprop.0+0x6f2>
    bb1b:	e8 10 83 ff ff       	call   3e30 <fwp_heap_oom>
    bb20:	48 8d 3d b9 4e 00 00 	lea    0x4eb9(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    bb27:	e8 24 89 ff ff       	call   4450 <fwp_trap>
    bb2c:	48 8d 3d 8f 47 00 00 	lea    0x478f(%rip),%rdi        # 102c2 <_IO_stdin_used+0x2c2>
    bb33:	e8 18 89 ff ff       	call   4450 <fwp_trap>
    bb38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    bb3f:	00 
    bb40:	e8 6b 9b ff ff       	call   56b0 <fwp_rc_wide_dup>
    bb45:	e9 2e f3 ff ff       	jmp    ae78 <fwp_hof0.constprop.0+0xd8>
    bb4a:	e8 01 79 ff ff       	call   3450 <__stack_chk_fail@plt>
    bb4f:	90                   	nop
    bb50:	4c 89 f7             	mov    %r14,%rdi
    bb53:	e8 78 9c ff ff       	call   57d0 <fwp_rc_forget_slot>
    bb58:	e9 6f f8 ff ff       	jmp    b3cc <fwp_hof0.constprop.0+0x62c>
    bb5d:	0f 1f 00             	nopl   (%rax)

000000000000bb60 <f0>:
    bb60:	41 56                	push   %r14
    bb62:	4c 8d 35 d7 0c 06 00 	lea    0x60cd7(%rip),%r14        # 6c840 <fwp_heap>
    bb69:	41 55                	push   %r13
    bb6b:	41 54                	push   %r12
    bb6d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    bb73:	55                   	push   %rbp
    bb74:	53                   	push   %rbx
    bb75:	31 db                	xor    %ebx,%ebx
    bb77:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    bb7e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    bb85:	00 00 
    bb87:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    bb8e:	00 
    bb8f:	31 c0                	xor    %eax,%eax
    bb91:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    bb98:	00 
    bb99:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    bba0:	00 00 
    bba2:	66 48 0f 6e c0       	movq   %rax,%xmm0
    bba7:	48 8d 05 62 b4 ff ff 	lea    -0x4b9e(%rip),%rax        # 7010 <fwp_drop1>
    bbae:	66 48 0f 6e c8       	movq   %rax,%xmm1
    bbb3:	48 8b 05 1e 29 06 00 	mov    0x6291e(%rip),%rax        # 6e4d8 <fwp_cleanups>
    bbba:	48 89 25 17 29 06 00 	mov    %rsp,0x62917(%rip)        # 6e4d8 <fwp_cleanups>
    bbc1:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    bbc5:	48 89 04 24          	mov    %rax,(%rsp)
    bbc9:	48 8d 05 00 80 ff ff 	lea    -0x8000(%rip),%rax        # 3bd0 <fwp_range_release>
    bbd0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    bbd5:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    bbda:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    bbdf:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    bbe4:	eb 47                	jmp    bc2d <f0+0xcd>
    bbe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bbed:	00 00 00 
    bbf0:	80 f9 01             	cmp    $0x1,%cl
    bbf3:	75 29                	jne    bc1e <f0+0xbe>
    bbf5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bbf8:	0f b7 c0             	movzwl %ax,%eax
    bbfb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bbfe:	48 0f af c1          	imul   %rcx,%rax
    bc02:	48 c1 e8 20          	shr    $0x20,%rax
    bc06:	48 39 d0             	cmp    %rdx,%rax
    bc09:	73 13                	jae    bc1e <f0+0xbe>
    bc0b:	49 01 c5             	add    %rax,%r13
    bc0e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    bc13:	0f 84 c7 27 00 00    	je     e3e0 <f0+0x2880>
    bc19:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    bc1e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    bc23:	49 83 ec 01          	sub    $0x1,%r12
    bc27:	0f 82 83 00 00 00    	jb     bcb0 <f0+0x150>
    bc2d:	48 89 ee             	mov    %rbp,%rsi
    bc30:	bf 01 00 00 00       	mov    $0x1,%edi
    bc35:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    bc3c:	00 
    bc3d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    bc42:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    bc49:	00 
    bc4a:	e8 f1 ab ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    bc4f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    bc56:	48 89 c3             	mov    %rax,%rbx
    bc59:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    bc60:	48 c1 e2 10          	shl    $0x10,%rdx
    bc64:	48 39 d0             	cmp    %rdx,%rax
    bc67:	73 b5                	jae    bc1e <f0+0xbe>
    bc69:	48 89 c2             	mov    %rax,%rdx
    bc6c:	48 c1 ea 10          	shr    $0x10,%rdx
    bc70:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bc74:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    bc7b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bc7f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    bc83:	4d 85 ed             	test   %r13,%r13
    bc86:	74 96                	je     bc1e <f0+0xbe>
    bc88:	0f b6 0a             	movzbl (%rdx),%ecx
    bc8b:	80 f9 02             	cmp    $0x2,%cl
    bc8e:	0f 85 5c ff ff ff    	jne    bbf0 <f0+0x90>
    bc94:	66 85 c0             	test   %ax,%ax
    bc97:	0f 84 71 ff ff ff    	je     bc0e <f0+0xae>
    bc9d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    bca2:	49 83 ec 01          	sub    $0x1,%r12
    bca6:	73 85                	jae    bc2d <f0+0xcd>
    bca8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    bcaf:	00 
    bcb0:	48 8b 04 24          	mov    (%rsp),%rax
    bcb4:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    bcb9:	bf 01 00 00 00       	mov    $0x1,%edi
    bcbe:	66 0f 6f 05 0a 51 00 	movdqa 0x510a(%rip),%xmm0        # 10dd0 <msg.4+0xa0>
    bcc5:	00 
    bcc6:	48 89 05 0b 28 06 00 	mov    %rax,0x6280b(%rip)        # 6e4d8 <fwp_cleanups>
    bccd:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    bcd2:	e8 69 ab ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    bcd7:	48 8b 15 3a 1f 06 00 	mov    0x61f3a(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    bcde:	49 89 c5             	mov    %rax,%r13
    bce1:	48 2b 05 08 1f 06 00 	sub    0x61f08(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    bce8:	48 c1 e2 10          	shl    $0x10,%rdx
    bcec:	48 39 d0             	cmp    %rdx,%rax
    bcef:	73 59                	jae    bd4a <f0+0x1ea>
    bcf1:	48 89 c2             	mov    %rax,%rdx
    bcf4:	48 c1 ea 10          	shr    $0x10,%rdx
    bcf8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bcfc:	48 8b 15 35 1f 06 00 	mov    0x61f35(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    bd03:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bd07:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bd0b:	4d 85 e4             	test   %r12,%r12
    bd0e:	74 3a                	je     bd4a <f0+0x1ea>
    bd10:	0f b6 0a             	movzbl (%rdx),%ecx
    bd13:	80 f9 02             	cmp    $0x2,%cl
    bd16:	0f 84 74 27 00 00    	je     e490 <f0+0x2930>
    bd1c:	80 f9 01             	cmp    $0x1,%cl
    bd1f:	75 29                	jne    bd4a <f0+0x1ea>
    bd21:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bd24:	0f b7 c0             	movzwl %ax,%eax
    bd27:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bd2a:	48 0f af c1          	imul   %rcx,%rax
    bd2e:	48 c1 e8 20          	shr    $0x20,%rax
    bd32:	48 39 d0             	cmp    %rdx,%rax
    bd35:	73 13                	jae    bd4a <f0+0x1ea>
    bd37:	49 01 c4             	add    %rax,%r12
    bd3a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bd3f:	0f 84 26 29 00 00    	je     e66b <f0+0x2b0b>
    bd45:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bd4a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    bd4f:	bf 01 00 00 00       	mov    $0x1,%edi
    bd54:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    bd59:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    bd60:	00 f0 3f 
    bd63:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    bd68:	e8 d3 aa ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    bd6d:	48 8b 15 a4 1e 06 00 	mov    0x61ea4(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    bd74:	49 89 c5             	mov    %rax,%r13
    bd77:	48 2b 05 72 1e 06 00 	sub    0x61e72(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    bd7e:	48 c1 e2 10          	shl    $0x10,%rdx
    bd82:	48 39 d0             	cmp    %rdx,%rax
    bd85:	73 59                	jae    bde0 <f0+0x280>
    bd87:	48 89 c2             	mov    %rax,%rdx
    bd8a:	48 c1 ea 10          	shr    $0x10,%rdx
    bd8e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bd92:	48 8b 15 9f 1e 06 00 	mov    0x61e9f(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    bd99:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bd9d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bda1:	4d 85 e4             	test   %r12,%r12
    bda4:	74 3a                	je     bde0 <f0+0x280>
    bda6:	0f b6 0a             	movzbl (%rdx),%ecx
    bda9:	80 f9 02             	cmp    $0x2,%cl
    bdac:	0f 84 ce 26 00 00    	je     e480 <f0+0x2920>
    bdb2:	80 f9 01             	cmp    $0x1,%cl
    bdb5:	75 29                	jne    bde0 <f0+0x280>
    bdb7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bdba:	0f b7 c0             	movzwl %ax,%eax
    bdbd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bdc0:	48 0f af c1          	imul   %rcx,%rax
    bdc4:	48 c1 e8 20          	shr    $0x20,%rax
    bdc8:	48 39 d0             	cmp    %rdx,%rax
    bdcb:	73 13                	jae    bde0 <f0+0x280>
    bdcd:	49 01 c4             	add    %rax,%r12
    bdd0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bdd5:	0f 84 9d 28 00 00    	je     e678 <f0+0x2b18>
    bddb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bde0:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    bde5:	bf 01 00 00 00       	mov    $0x1,%edi
    bdea:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    bdef:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    bdf6:	33 f3 bf 
    bdf9:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    bdfe:	e8 3d aa ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    be03:	48 8b 15 0e 1e 06 00 	mov    0x61e0e(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    be0a:	49 89 c5             	mov    %rax,%r13
    be0d:	48 2b 05 dc 1d 06 00 	sub    0x61ddc(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    be14:	48 c1 e2 10          	shl    $0x10,%rdx
    be18:	48 39 d0             	cmp    %rdx,%rax
    be1b:	73 59                	jae    be76 <f0+0x316>
    be1d:	48 89 c2             	mov    %rax,%rdx
    be20:	48 c1 ea 10          	shr    $0x10,%rdx
    be24:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    be28:	48 8b 15 09 1e 06 00 	mov    0x61e09(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    be2f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    be33:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    be37:	4d 85 e4             	test   %r12,%r12
    be3a:	74 3a                	je     be76 <f0+0x316>
    be3c:	0f b6 0a             	movzbl (%rdx),%ecx
    be3f:	80 f9 02             	cmp    $0x2,%cl
    be42:	0f 84 28 26 00 00    	je     e470 <f0+0x2910>
    be48:	80 f9 01             	cmp    $0x1,%cl
    be4b:	75 29                	jne    be76 <f0+0x316>
    be4d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    be50:	0f b7 c0             	movzwl %ax,%eax
    be53:	8b 52 1c             	mov    0x1c(%rdx),%edx
    be56:	48 0f af c1          	imul   %rcx,%rax
    be5a:	48 c1 e8 20          	shr    $0x20,%rax
    be5e:	48 39 d0             	cmp    %rdx,%rax
    be61:	73 13                	jae    be76 <f0+0x316>
    be63:	49 01 c4             	add    %rax,%r12
    be66:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    be6b:	0f 84 14 28 00 00    	je     e685 <f0+0x2b25>
    be71:	41 c6 04 24 01       	movb   $0x1,(%r12)
    be76:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    be7b:	bf 01 00 00 00       	mov    $0x1,%edi
    be80:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    be85:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    be8c:	00 f0 3f 
    be8f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    be94:	e8 a7 a9 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    be99:	48 8b 15 78 1d 06 00 	mov    0x61d78(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    bea0:	49 89 c5             	mov    %rax,%r13
    bea3:	48 2b 05 46 1d 06 00 	sub    0x61d46(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    beaa:	48 c1 e2 10          	shl    $0x10,%rdx
    beae:	48 39 d0             	cmp    %rdx,%rax
    beb1:	73 59                	jae    bf0c <f0+0x3ac>
    beb3:	48 89 c2             	mov    %rax,%rdx
    beb6:	48 c1 ea 10          	shr    $0x10,%rdx
    beba:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bebe:	48 8b 15 73 1d 06 00 	mov    0x61d73(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    bec5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bec9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    becd:	4d 85 e4             	test   %r12,%r12
    bed0:	74 3a                	je     bf0c <f0+0x3ac>
    bed2:	0f b6 0a             	movzbl (%rdx),%ecx
    bed5:	80 f9 02             	cmp    $0x2,%cl
    bed8:	0f 84 f2 25 00 00    	je     e4d0 <f0+0x2970>
    bede:	80 f9 01             	cmp    $0x1,%cl
    bee1:	75 29                	jne    bf0c <f0+0x3ac>
    bee3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bee6:	0f b7 c0             	movzwl %ax,%eax
    bee9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    beec:	48 0f af c1          	imul   %rcx,%rax
    bef0:	48 c1 e8 20          	shr    $0x20,%rax
    bef4:	48 39 d0             	cmp    %rdx,%rax
    bef7:	73 13                	jae    bf0c <f0+0x3ac>
    bef9:	49 01 c4             	add    %rax,%r12
    befc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bf01:	0f 84 8b 27 00 00    	je     e692 <f0+0x2b32>
    bf07:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bf0c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    bf13:	33 f3 bf 
    bf16:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    bf1d:	00 
    bf1e:	bf 01 00 00 00       	mov    $0x1,%edi
    bf23:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    bf2a:	00 
    bf2b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    bf32:	00 
    bf33:	e8 08 a9 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    bf38:	48 8b 15 d9 1c 06 00 	mov    0x61cd9(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    bf3f:	49 89 c5             	mov    %rax,%r13
    bf42:	48 2b 05 a7 1c 06 00 	sub    0x61ca7(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    bf49:	48 c1 e2 10          	shl    $0x10,%rdx
    bf4d:	48 39 d0             	cmp    %rdx,%rax
    bf50:	73 59                	jae    bfab <f0+0x44b>
    bf52:	48 89 c2             	mov    %rax,%rdx
    bf55:	48 c1 ea 10          	shr    $0x10,%rdx
    bf59:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bf5d:	48 8b 15 d4 1c 06 00 	mov    0x61cd4(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    bf64:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bf68:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bf6c:	4d 85 e4             	test   %r12,%r12
    bf6f:	74 3a                	je     bfab <f0+0x44b>
    bf71:	0f b6 0a             	movzbl (%rdx),%ecx
    bf74:	80 f9 02             	cmp    $0x2,%cl
    bf77:	0f 84 43 25 00 00    	je     e4c0 <f0+0x2960>
    bf7d:	80 f9 01             	cmp    $0x1,%cl
    bf80:	75 29                	jne    bfab <f0+0x44b>
    bf82:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bf85:	0f b7 c0             	movzwl %ax,%eax
    bf88:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bf8b:	48 0f af c1          	imul   %rcx,%rax
    bf8f:	48 c1 e8 20          	shr    $0x20,%rax
    bf93:	48 39 d0             	cmp    %rdx,%rax
    bf96:	73 13                	jae    bfab <f0+0x44b>
    bf98:	49 01 c4             	add    %rax,%r12
    bf9b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bfa0:	0f 84 f9 26 00 00    	je     e69f <f0+0x2b3f>
    bfa6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bfab:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    bfb2:	00 f0 3f 
    bfb5:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    bfbc:	00 
    bfbd:	bf 01 00 00 00       	mov    $0x1,%edi
    bfc2:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    bfc9:	00 
    bfca:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    bfd1:	00 
    bfd2:	e8 69 a8 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    bfd7:	48 8b 15 3a 1c 06 00 	mov    0x61c3a(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    bfde:	49 89 c5             	mov    %rax,%r13
    bfe1:	48 2b 05 08 1c 06 00 	sub    0x61c08(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    bfe8:	48 c1 e2 10          	shl    $0x10,%rdx
    bfec:	48 39 d0             	cmp    %rdx,%rax
    bfef:	73 59                	jae    c04a <f0+0x4ea>
    bff1:	48 89 c2             	mov    %rax,%rdx
    bff4:	48 c1 ea 10          	shr    $0x10,%rdx
    bff8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bffc:	48 8b 15 35 1c 06 00 	mov    0x61c35(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    c003:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c007:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c00b:	4d 85 e4             	test   %r12,%r12
    c00e:	74 3a                	je     c04a <f0+0x4ea>
    c010:	0f b6 0a             	movzbl (%rdx),%ecx
    c013:	80 f9 02             	cmp    $0x2,%cl
    c016:	0f 84 94 24 00 00    	je     e4b0 <f0+0x2950>
    c01c:	80 f9 01             	cmp    $0x1,%cl
    c01f:	75 29                	jne    c04a <f0+0x4ea>
    c021:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c024:	0f b7 c0             	movzwl %ax,%eax
    c027:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c02a:	48 0f af c1          	imul   %rcx,%rax
    c02e:	48 c1 e8 20          	shr    $0x20,%rax
    c032:	48 39 d0             	cmp    %rdx,%rax
    c035:	73 13                	jae    c04a <f0+0x4ea>
    c037:	49 01 c4             	add    %rax,%r12
    c03a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c03f:	0f 84 67 26 00 00    	je     e6ac <f0+0x2b4c>
    c045:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c04a:	49 bc 33 33 33 33 33 	movabs $0xbff3333333333333,%r12
    c051:	33 f3 bf 
    c054:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    c05b:	00 
    c05c:	bf 01 00 00 00       	mov    $0x1,%edi
    c061:	4c 89 ac 24 a8 00 00 	mov    %r13,0xa8(%rsp)
    c068:	00 
    c069:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
    c070:	00 
    c071:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
    c078:	00 f0 3f 
    c07b:	e8 c0 a7 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c080:	48 89 c7             	mov    %rax,%rdi
    c083:	e8 28 aa ff ff       	call   6ab0 <fwp_rc_fresh>
    c088:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    c08f:	00 
    c090:	bf 01 00 00 00       	mov    $0x1,%edi
    c095:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
    c09c:	00 
    c09d:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    c0a4:	00 
    c0a5:	e8 96 a7 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c0aa:	48 89 c7             	mov    %rax,%rdi
    c0ad:	e8 fe a9 ff ff       	call   6ab0 <fwp_rc_fresh>
    c0b2:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    c0b9:	00 
    c0ba:	bf 01 00 00 00       	mov    $0x1,%edi
    c0bf:	4c 89 a4 24 c0 00 00 	mov    %r12,0xc0(%rsp)
    c0c6:	00 
    c0c7:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    c0ce:	00 
    c0cf:	e8 6c a7 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c0d4:	48 89 c7             	mov    %rax,%rdi
    c0d7:	e8 d4 a9 ff ff       	call   6ab0 <fwp_rc_fresh>
    c0dc:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    c0e3:	00 
    c0e4:	bf 01 00 00 00       	mov    $0x1,%edi
    c0e9:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
    c0f0:	00 
    c0f1:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    c0f8:	00 
    c0f9:	e8 42 a7 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c0fe:	48 89 c7             	mov    %rax,%rdi
    c101:	e8 aa a9 ff ff       	call   6ab0 <fwp_rc_fresh>
    c106:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    c10d:	00 
    c10e:	bf 01 00 00 00       	mov    $0x1,%edi
    c113:	4c 89 a4 24 e0 00 00 	mov    %r12,0xe0(%rsp)
    c11a:	00 
    c11b:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    c122:	00 
    c123:	e8 18 a7 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c128:	48 89 c7             	mov    %rax,%rdi
    c12b:	e8 80 a9 ff ff       	call   6ab0 <fwp_rc_fresh>
    c130:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    c137:	00 
    c138:	bf 01 00 00 00       	mov    $0x1,%edi
    c13d:	4c 89 ac 24 f0 00 00 	mov    %r13,0xf0(%rsp)
    c144:	00 
    c145:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    c14c:	00 
    c14d:	e8 ee a6 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c152:	48 89 c7             	mov    %rax,%rdi
    c155:	e8 56 a9 ff ff       	call   6ab0 <fwp_rc_fresh>
    c15a:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    c161:	00 
    c162:	bf 01 00 00 00       	mov    $0x1,%edi
    c167:	4c 89 a4 24 00 01 00 	mov    %r12,0x100(%rsp)
    c16e:	00 
    c16f:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    c176:	00 
    c177:	e8 c4 a6 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c17c:	48 89 c7             	mov    %rax,%rdi
    c17f:	e8 2c a9 ff ff       	call   6ab0 <fwp_rc_fresh>
    c184:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    c18b:	00 
    c18c:	bf 01 00 00 00       	mov    $0x1,%edi
    c191:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
    c198:	00 
    c199:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    c1a0:	00 
    c1a1:	e8 9a a6 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c1a6:	48 89 c7             	mov    %rax,%rdi
    c1a9:	e8 02 a9 ff ff       	call   6ab0 <fwp_rc_fresh>
    c1ae:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    c1b5:	00 
    c1b6:	bf 01 00 00 00       	mov    $0x1,%edi
    c1bb:	4c 89 a4 24 20 01 00 	mov    %r12,0x120(%rsp)
    c1c2:	00 
    c1c3:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    c1ca:	00 
    c1cb:	e8 70 a6 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c1d0:	48 89 c7             	mov    %rax,%rdi
    c1d3:	e8 d8 a8 ff ff       	call   6ab0 <fwp_rc_fresh>
    c1d8:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    c1df:	00 
    c1e0:	bf 01 00 00 00       	mov    $0x1,%edi
    c1e5:	4c 89 ac 24 30 01 00 	mov    %r13,0x130(%rsp)
    c1ec:	00 
    c1ed:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    c1f4:	00 
    c1f5:	e8 46 a6 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c1fa:	48 89 c7             	mov    %rax,%rdi
    c1fd:	e8 ae a8 ff ff       	call   6ab0 <fwp_rc_fresh>
    c202:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    c209:	00 
    c20a:	bf 01 00 00 00       	mov    $0x1,%edi
    c20f:	4c 89 a4 24 40 01 00 	mov    %r12,0x140(%rsp)
    c216:	00 
    c217:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    c21e:	00 
    c21f:	e8 1c a6 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c224:	48 89 c7             	mov    %rax,%rdi
    c227:	e8 84 a8 ff ff       	call   6ab0 <fwp_rc_fresh>
    c22c:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    c233:	00 
    c234:	bf 01 00 00 00       	mov    $0x1,%edi
    c239:	4c 89 ac 24 50 01 00 	mov    %r13,0x150(%rsp)
    c240:	00 
    c241:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    c248:	00 
    c249:	e8 f2 a5 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c24e:	48 89 c7             	mov    %rax,%rdi
    c251:	e8 5a a8 ff ff       	call   6ab0 <fwp_rc_fresh>
    c256:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    c25d:	00 
    c25e:	bf 01 00 00 00       	mov    $0x1,%edi
    c263:	4c 89 a4 24 60 01 00 	mov    %r12,0x160(%rsp)
    c26a:	00 
    c26b:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    c272:	00 
    c273:	e8 c8 a5 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c278:	48 89 c7             	mov    %rax,%rdi
    c27b:	e8 30 a8 ff ff       	call   6ab0 <fwp_rc_fresh>
    c280:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    c287:	00 
    c288:	bf 01 00 00 00       	mov    $0x1,%edi
    c28d:	4c 89 ac 24 70 01 00 	mov    %r13,0x170(%rsp)
    c294:	00 
    c295:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    c29c:	00 
    c29d:	e8 9e a5 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c2a2:	48 89 c7             	mov    %rax,%rdi
    c2a5:	e8 06 a8 ff ff       	call   6ab0 <fwp_rc_fresh>
    c2aa:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    c2b1:	00 
    c2b2:	bf 01 00 00 00       	mov    $0x1,%edi
    c2b7:	4c 89 a4 24 80 01 00 	mov    %r12,0x180(%rsp)
    c2be:	00 
    c2bf:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    c2c6:	00 
    c2c7:	e8 74 a5 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c2cc:	48 89 c7             	mov    %rax,%rdi
    c2cf:	e8 dc a7 ff ff       	call   6ab0 <fwp_rc_fresh>
    c2d4:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    c2db:	00 
    c2dc:	bf 01 00 00 00       	mov    $0x1,%edi
    c2e1:	4c 89 ac 24 90 01 00 	mov    %r13,0x190(%rsp)
    c2e8:	00 
    c2e9:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    c2f0:	00 
    c2f1:	e8 4a a5 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c2f6:	48 89 c7             	mov    %rax,%rdi
    c2f9:	e8 b2 a7 ff ff       	call   6ab0 <fwp_rc_fresh>
    c2fe:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    c305:	00 
    c306:	bf 01 00 00 00       	mov    $0x1,%edi
    c30b:	4c 89 a4 24 a0 01 00 	mov    %r12,0x1a0(%rsp)
    c312:	00 
    c313:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    c31a:	00 
    c31b:	e8 20 a5 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c320:	48 89 c7             	mov    %rax,%rdi
    c323:	e8 88 a7 ff ff       	call   6ab0 <fwp_rc_fresh>
    c328:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    c32f:	00 
    c330:	bf 01 00 00 00       	mov    $0x1,%edi
    c335:	4c 89 ac 24 b0 01 00 	mov    %r13,0x1b0(%rsp)
    c33c:	00 
    c33d:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    c344:	00 
    c345:	e8 f6 a4 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c34a:	48 89 c7             	mov    %rax,%rdi
    c34d:	e8 5e a7 ff ff       	call   6ab0 <fwp_rc_fresh>
    c352:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    c359:	00 
    c35a:	bf 01 00 00 00       	mov    $0x1,%edi
    c35f:	4c 89 a4 24 c0 01 00 	mov    %r12,0x1c0(%rsp)
    c366:	00 
    c367:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    c36e:	00 
    c36f:	e8 cc a4 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c374:	48 89 c7             	mov    %rax,%rdi
    c377:	e8 34 a7 ff ff       	call   6ab0 <fwp_rc_fresh>
    c37c:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    c383:	00 
    c384:	bf 01 00 00 00       	mov    $0x1,%edi
    c389:	4c 89 ac 24 d0 01 00 	mov    %r13,0x1d0(%rsp)
    c390:	00 
    c391:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    c398:	00 
    c399:	e8 a2 a4 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c39e:	48 89 c7             	mov    %rax,%rdi
    c3a1:	e8 0a a7 ff ff       	call   6ab0 <fwp_rc_fresh>
    c3a6:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    c3ad:	00 
    c3ae:	bf 01 00 00 00       	mov    $0x1,%edi
    c3b3:	4c 89 a4 24 e0 01 00 	mov    %r12,0x1e0(%rsp)
    c3ba:	00 
    c3bb:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    c3c2:	00 
    c3c3:	e8 78 a4 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c3c8:	48 89 c7             	mov    %rax,%rdi
    c3cb:	e8 e0 a6 ff ff       	call   6ab0 <fwp_rc_fresh>
    c3d0:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    c3d7:	00 
    c3d8:	bf 01 00 00 00       	mov    $0x1,%edi
    c3dd:	4c 89 ac 24 f0 01 00 	mov    %r13,0x1f0(%rsp)
    c3e4:	00 
    c3e5:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    c3ec:	00 
    c3ed:	e8 4e a4 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c3f2:	48 89 c7             	mov    %rax,%rdi
    c3f5:	e8 b6 a6 ff ff       	call   6ab0 <fwp_rc_fresh>
    c3fa:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    c401:	00 
    c402:	bf 01 00 00 00       	mov    $0x1,%edi
    c407:	4c 89 a4 24 00 02 00 	mov    %r12,0x200(%rsp)
    c40e:	00 
    c40f:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    c416:	00 
    c417:	e8 24 a4 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c41c:	48 89 c7             	mov    %rax,%rdi
    c41f:	e8 8c a6 ff ff       	call   6ab0 <fwp_rc_fresh>
    c424:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    c42b:	00 
    c42c:	bf 01 00 00 00       	mov    $0x1,%edi
    c431:	4c 89 ac 24 10 02 00 	mov    %r13,0x210(%rsp)
    c438:	00 
    c439:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    c440:	00 
    c441:	e8 fa a3 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c446:	48 89 c7             	mov    %rax,%rdi
    c449:	e8 62 a6 ff ff       	call   6ab0 <fwp_rc_fresh>
    c44e:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    c455:	00 
    c456:	bf 01 00 00 00       	mov    $0x1,%edi
    c45b:	4c 89 a4 24 20 02 00 	mov    %r12,0x220(%rsp)
    c462:	00 
    c463:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    c46a:	00 
    c46b:	e8 d0 a3 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c470:	48 89 c7             	mov    %rax,%rdi
    c473:	e8 38 a6 ff ff       	call   6ab0 <fwp_rc_fresh>
    c478:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    c47f:	00 
    c480:	bf 01 00 00 00       	mov    $0x1,%edi
    c485:	4c 89 ac 24 30 02 00 	mov    %r13,0x230(%rsp)
    c48c:	00 
    c48d:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    c494:	00 
    c495:	e8 a6 a3 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c49a:	48 89 c7             	mov    %rax,%rdi
    c49d:	e8 0e a6 ff ff       	call   6ab0 <fwp_rc_fresh>
    c4a2:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    c4a9:	00 
    c4aa:	bf 01 00 00 00       	mov    $0x1,%edi
    c4af:	4c 89 a4 24 40 02 00 	mov    %r12,0x240(%rsp)
    c4b6:	00 
    c4b7:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    c4be:	00 
    c4bf:	e8 7c a3 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c4c4:	48 89 c7             	mov    %rax,%rdi
    c4c7:	e8 e4 a5 ff ff       	call   6ab0 <fwp_rc_fresh>
    c4cc:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    c4d3:	00 
    c4d4:	bf 01 00 00 00       	mov    $0x1,%edi
    c4d9:	4c 89 ac 24 50 02 00 	mov    %r13,0x250(%rsp)
    c4e0:	00 
    c4e1:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    c4e8:	00 
    c4e9:	e8 52 a3 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c4ee:	48 89 c7             	mov    %rax,%rdi
    c4f1:	e8 ba a5 ff ff       	call   6ab0 <fwp_rc_fresh>
    c4f6:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    c4fd:	00 
    c4fe:	bf 01 00 00 00       	mov    $0x1,%edi
    c503:	4c 89 a4 24 60 02 00 	mov    %r12,0x260(%rsp)
    c50a:	00 
    c50b:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    c512:	00 
    c513:	e8 28 a3 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c518:	48 89 c7             	mov    %rax,%rdi
    c51b:	e8 90 a5 ff ff       	call   6ab0 <fwp_rc_fresh>
    c520:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    c527:	00 
    c528:	bf 01 00 00 00       	mov    $0x1,%edi
    c52d:	4c 89 ac 24 70 02 00 	mov    %r13,0x270(%rsp)
    c534:	00 
    c535:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    c53c:	00 
    c53d:	e8 fe a2 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c542:	48 89 c7             	mov    %rax,%rdi
    c545:	e8 66 a5 ff ff       	call   6ab0 <fwp_rc_fresh>
    c54a:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    c551:	00 
    c552:	bf 01 00 00 00       	mov    $0x1,%edi
    c557:	4c 89 a4 24 80 02 00 	mov    %r12,0x280(%rsp)
    c55e:	00 
    c55f:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    c566:	00 
    c567:	e8 d4 a2 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c56c:	48 89 c7             	mov    %rax,%rdi
    c56f:	e8 3c a5 ff ff       	call   6ab0 <fwp_rc_fresh>
    c574:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    c57b:	00 
    c57c:	bf 01 00 00 00       	mov    $0x1,%edi
    c581:	4c 89 ac 24 90 02 00 	mov    %r13,0x290(%rsp)
    c588:	00 
    c589:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    c590:	00 
    c591:	e8 aa a2 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c596:	48 89 c7             	mov    %rax,%rdi
    c599:	e8 12 a5 ff ff       	call   6ab0 <fwp_rc_fresh>
    c59e:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    c5a5:	00 
    c5a6:	bf 01 00 00 00       	mov    $0x1,%edi
    c5ab:	4c 89 a4 24 a0 02 00 	mov    %r12,0x2a0(%rsp)
    c5b2:	00 
    c5b3:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    c5ba:	00 
    c5bb:	e8 80 a2 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c5c0:	48 89 c7             	mov    %rax,%rdi
    c5c3:	e8 e8 a4 ff ff       	call   6ab0 <fwp_rc_fresh>
    c5c8:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    c5cf:	00 
    c5d0:	bf 01 00 00 00       	mov    $0x1,%edi
    c5d5:	4c 89 ac 24 b0 02 00 	mov    %r13,0x2b0(%rsp)
    c5dc:	00 
    c5dd:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    c5e4:	00 
    c5e5:	e8 56 a2 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c5ea:	48 89 c7             	mov    %rax,%rdi
    c5ed:	e8 be a4 ff ff       	call   6ab0 <fwp_rc_fresh>
    c5f2:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    c5f9:	00 
    c5fa:	bf 01 00 00 00       	mov    $0x1,%edi
    c5ff:	4c 89 a4 24 c0 02 00 	mov    %r12,0x2c0(%rsp)
    c606:	00 
    c607:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    c60e:	00 
    c60f:	e8 2c a2 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c614:	48 89 c7             	mov    %rax,%rdi
    c617:	e8 94 a4 ff ff       	call   6ab0 <fwp_rc_fresh>
    c61c:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    c623:	00 
    c624:	bf 01 00 00 00       	mov    $0x1,%edi
    c629:	4c 89 ac 24 d0 02 00 	mov    %r13,0x2d0(%rsp)
    c630:	00 
    c631:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    c638:	00 
    c639:	e8 02 a2 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c63e:	48 89 c7             	mov    %rax,%rdi
    c641:	e8 6a a4 ff ff       	call   6ab0 <fwp_rc_fresh>
    c646:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    c64d:	00 
    c64e:	bf 01 00 00 00       	mov    $0x1,%edi
    c653:	4c 89 a4 24 e0 02 00 	mov    %r12,0x2e0(%rsp)
    c65a:	00 
    c65b:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    c662:	00 
    c663:	e8 d8 a1 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c668:	48 89 c7             	mov    %rax,%rdi
    c66b:	e8 40 a4 ff ff       	call   6ab0 <fwp_rc_fresh>
    c670:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    c677:	00 
    c678:	bf 01 00 00 00       	mov    $0x1,%edi
    c67d:	4c 89 ac 24 f0 02 00 	mov    %r13,0x2f0(%rsp)
    c684:	00 
    c685:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    c68c:	00 
    c68d:	e8 ae a1 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c692:	48 89 c7             	mov    %rax,%rdi
    c695:	e8 16 a4 ff ff       	call   6ab0 <fwp_rc_fresh>
    c69a:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    c6a1:	00 
    c6a2:	bf 01 00 00 00       	mov    $0x1,%edi
    c6a7:	4c 89 a4 24 00 03 00 	mov    %r12,0x300(%rsp)
    c6ae:	00 
    c6af:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    c6b6:	00 
    c6b7:	e8 84 a1 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c6bc:	48 89 c7             	mov    %rax,%rdi
    c6bf:	e8 ec a3 ff ff       	call   6ab0 <fwp_rc_fresh>
    c6c4:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    c6cb:	00 
    c6cc:	bf 01 00 00 00       	mov    $0x1,%edi
    c6d1:	4c 89 ac 24 10 03 00 	mov    %r13,0x310(%rsp)
    c6d8:	00 
    c6d9:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    c6e0:	00 
    c6e1:	e8 5a a1 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c6e6:	48 89 c7             	mov    %rax,%rdi
    c6e9:	e8 c2 a3 ff ff       	call   6ab0 <fwp_rc_fresh>
    c6ee:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    c6f5:	00 
    c6f6:	bf 01 00 00 00       	mov    $0x1,%edi
    c6fb:	4c 89 a4 24 20 03 00 	mov    %r12,0x320(%rsp)
    c702:	00 
    c703:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    c70a:	00 
    c70b:	e8 30 a1 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c710:	48 89 c7             	mov    %rax,%rdi
    c713:	e8 98 a3 ff ff       	call   6ab0 <fwp_rc_fresh>
    c718:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    c71f:	00 
    c720:	bf 01 00 00 00       	mov    $0x1,%edi
    c725:	4c 89 ac 24 30 03 00 	mov    %r13,0x330(%rsp)
    c72c:	00 
    c72d:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    c734:	00 
    c735:	e8 06 a1 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c73a:	48 89 c7             	mov    %rax,%rdi
    c73d:	e8 6e a3 ff ff       	call   6ab0 <fwp_rc_fresh>
    c742:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    c749:	00 
    c74a:	bf 01 00 00 00       	mov    $0x1,%edi
    c74f:	4c 89 a4 24 40 03 00 	mov    %r12,0x340(%rsp)
    c756:	00 
    c757:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    c75e:	00 
    c75f:	e8 dc a0 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c764:	48 89 c7             	mov    %rax,%rdi
    c767:	e8 44 a3 ff ff       	call   6ab0 <fwp_rc_fresh>
    c76c:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    c773:	00 
    c774:	bf 01 00 00 00       	mov    $0x1,%edi
    c779:	4c 89 ac 24 50 03 00 	mov    %r13,0x350(%rsp)
    c780:	00 
    c781:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    c788:	00 
    c789:	e8 b2 a0 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c78e:	48 89 c7             	mov    %rax,%rdi
    c791:	e8 1a a3 ff ff       	call   6ab0 <fwp_rc_fresh>
    c796:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    c79d:	00 
    c79e:	bf 01 00 00 00       	mov    $0x1,%edi
    c7a3:	4c 89 a4 24 60 03 00 	mov    %r12,0x360(%rsp)
    c7aa:	00 
    c7ab:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    c7b2:	00 
    c7b3:	e8 88 a0 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c7b8:	48 89 c7             	mov    %rax,%rdi
    c7bb:	e8 f0 a2 ff ff       	call   6ab0 <fwp_rc_fresh>
    c7c0:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    c7c7:	00 
    c7c8:	bf 01 00 00 00       	mov    $0x1,%edi
    c7cd:	4c 89 ac 24 70 03 00 	mov    %r13,0x370(%rsp)
    c7d4:	00 
    c7d5:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    c7dc:	00 
    c7dd:	e8 5e a0 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c7e2:	48 89 c7             	mov    %rax,%rdi
    c7e5:	e8 c6 a2 ff ff       	call   6ab0 <fwp_rc_fresh>
    c7ea:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    c7f1:	00 
    c7f2:	bf 01 00 00 00       	mov    $0x1,%edi
    c7f7:	4c 89 a4 24 80 03 00 	mov    %r12,0x380(%rsp)
    c7fe:	00 
    c7ff:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    c806:	00 
    c807:	e8 34 a0 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c80c:	48 89 c7             	mov    %rax,%rdi
    c80f:	e8 9c a2 ff ff       	call   6ab0 <fwp_rc_fresh>
    c814:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    c81b:	00 
    c81c:	bf 01 00 00 00       	mov    $0x1,%edi
    c821:	4c 89 ac 24 90 03 00 	mov    %r13,0x390(%rsp)
    c828:	00 
    c829:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    c830:	00 
    c831:	e8 0a a0 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c836:	48 89 c7             	mov    %rax,%rdi
    c839:	e8 72 a2 ff ff       	call   6ab0 <fwp_rc_fresh>
    c83e:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    c845:	00 
    c846:	bf 01 00 00 00       	mov    $0x1,%edi
    c84b:	4c 89 a4 24 a0 03 00 	mov    %r12,0x3a0(%rsp)
    c852:	00 
    c853:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    c85a:	00 
    c85b:	e8 e0 9f ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c860:	48 89 c7             	mov    %rax,%rdi
    c863:	e8 48 a2 ff ff       	call   6ab0 <fwp_rc_fresh>
    c868:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    c86f:	00 
    c870:	bf 01 00 00 00       	mov    $0x1,%edi
    c875:	4c 89 ac 24 b0 03 00 	mov    %r13,0x3b0(%rsp)
    c87c:	00 
    c87d:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    c884:	00 
    c885:	e8 b6 9f ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c88a:	48 89 c7             	mov    %rax,%rdi
    c88d:	e8 1e a2 ff ff       	call   6ab0 <fwp_rc_fresh>
    c892:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    c899:	00 
    c89a:	bf 01 00 00 00       	mov    $0x1,%edi
    c89f:	4c 89 a4 24 c0 03 00 	mov    %r12,0x3c0(%rsp)
    c8a6:	00 
    c8a7:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    c8ae:	00 
    c8af:	e8 8c 9f ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c8b4:	48 89 c7             	mov    %rax,%rdi
    c8b7:	e8 f4 a1 ff ff       	call   6ab0 <fwp_rc_fresh>
    c8bc:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    c8c3:	00 
    c8c4:	bf 01 00 00 00       	mov    $0x1,%edi
    c8c9:	4c 89 ac 24 d0 03 00 	mov    %r13,0x3d0(%rsp)
    c8d0:	00 
    c8d1:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    c8d8:	00 
    c8d9:	e8 62 9f ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c8de:	48 89 c7             	mov    %rax,%rdi
    c8e1:	e8 ca a1 ff ff       	call   6ab0 <fwp_rc_fresh>
    c8e6:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    c8ed:	00 
    c8ee:	bf 01 00 00 00       	mov    $0x1,%edi
    c8f3:	4c 89 a4 24 e0 03 00 	mov    %r12,0x3e0(%rsp)
    c8fa:	00 
    c8fb:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    c902:	00 
    c903:	e8 38 9f ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c908:	48 89 c7             	mov    %rax,%rdi
    c90b:	e8 a0 a1 ff ff       	call   6ab0 <fwp_rc_fresh>
    c910:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    c917:	00 
    c918:	bf 01 00 00 00       	mov    $0x1,%edi
    c91d:	4c 89 ac 24 f0 03 00 	mov    %r13,0x3f0(%rsp)
    c924:	00 
    c925:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    c92c:	00 
    c92d:	e8 0e 9f ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c932:	48 89 c7             	mov    %rax,%rdi
    c935:	e8 76 a1 ff ff       	call   6ab0 <fwp_rc_fresh>
    c93a:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    c941:	00 
    c942:	bf 01 00 00 00       	mov    $0x1,%edi
    c947:	4c 89 a4 24 00 04 00 	mov    %r12,0x400(%rsp)
    c94e:	00 
    c94f:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    c956:	00 
    c957:	e8 e4 9e ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c95c:	48 89 c7             	mov    %rax,%rdi
    c95f:	e8 4c a1 ff ff       	call   6ab0 <fwp_rc_fresh>
    c964:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    c96b:	00 
    c96c:	bf 01 00 00 00       	mov    $0x1,%edi
    c971:	4c 89 ac 24 10 04 00 	mov    %r13,0x410(%rsp)
    c978:	00 
    c979:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    c980:	00 
    c981:	e8 ba 9e ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c986:	48 89 c7             	mov    %rax,%rdi
    c989:	e8 22 a1 ff ff       	call   6ab0 <fwp_rc_fresh>
    c98e:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    c995:	00 
    c996:	bf 01 00 00 00       	mov    $0x1,%edi
    c99b:	4c 89 a4 24 20 04 00 	mov    %r12,0x420(%rsp)
    c9a2:	00 
    c9a3:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    c9aa:	00 
    c9ab:	e8 90 9e ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c9b0:	48 89 c7             	mov    %rax,%rdi
    c9b3:	e8 f8 a0 ff ff       	call   6ab0 <fwp_rc_fresh>
    c9b8:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    c9bf:	00 
    c9c0:	bf 01 00 00 00       	mov    $0x1,%edi
    c9c5:	4c 89 ac 24 30 04 00 	mov    %r13,0x430(%rsp)
    c9cc:	00 
    c9cd:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    c9d4:	00 
    c9d5:	e8 66 9e ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    c9da:	48 89 c7             	mov    %rax,%rdi
    c9dd:	e8 ce a0 ff ff       	call   6ab0 <fwp_rc_fresh>
    c9e2:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    c9e9:	00 
    c9ea:	bf 01 00 00 00       	mov    $0x1,%edi
    c9ef:	4c 89 a4 24 40 04 00 	mov    %r12,0x440(%rsp)
    c9f6:	00 
    c9f7:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    c9fe:	00 
    c9ff:	e8 3c 9e ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    ca04:	48 89 c7             	mov    %rax,%rdi
    ca07:	e8 a4 a0 ff ff       	call   6ab0 <fwp_rc_fresh>
    ca0c:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    ca13:	00 
    ca14:	bf 01 00 00 00       	mov    $0x1,%edi
    ca19:	4c 89 ac 24 50 04 00 	mov    %r13,0x450(%rsp)
    ca20:	00 
    ca21:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    ca28:	00 
    ca29:	e8 12 9e ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    ca2e:	48 89 c7             	mov    %rax,%rdi
    ca31:	e8 7a a0 ff ff       	call   6ab0 <fwp_rc_fresh>
    ca36:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    ca3d:	00 
    ca3e:	bf 01 00 00 00       	mov    $0x1,%edi
    ca43:	4c 89 a4 24 60 04 00 	mov    %r12,0x460(%rsp)
    ca4a:	00 
    ca4b:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    ca52:	00 
    ca53:	e8 e8 9d ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    ca58:	48 89 c7             	mov    %rax,%rdi
    ca5b:	e8 50 a0 ff ff       	call   6ab0 <fwp_rc_fresh>
    ca60:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    ca67:	00 
    ca68:	bf 01 00 00 00       	mov    $0x1,%edi
    ca6d:	4c 89 ac 24 70 04 00 	mov    %r13,0x470(%rsp)
    ca74:	00 
    ca75:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    ca7c:	00 
    ca7d:	e8 be 9d ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    ca82:	48 89 c7             	mov    %rax,%rdi
    ca85:	e8 26 a0 ff ff       	call   6ab0 <fwp_rc_fresh>
    ca8a:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    ca91:	00 
    ca92:	bf 01 00 00 00       	mov    $0x1,%edi
    ca97:	4c 89 a4 24 80 04 00 	mov    %r12,0x480(%rsp)
    ca9e:	00 
    ca9f:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    caa6:	00 
    caa7:	e8 94 9d ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    caac:	48 89 c7             	mov    %rax,%rdi
    caaf:	e8 fc 9f ff ff       	call   6ab0 <fwp_rc_fresh>
    cab4:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    cabb:	00 
    cabc:	bf 01 00 00 00       	mov    $0x1,%edi
    cac1:	4c 89 ac 24 90 04 00 	mov    %r13,0x490(%rsp)
    cac8:	00 
    cac9:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    cad0:	00 
    cad1:	e8 6a 9d ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cad6:	48 89 c7             	mov    %rax,%rdi
    cad9:	e8 d2 9f ff ff       	call   6ab0 <fwp_rc_fresh>
    cade:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    cae5:	00 
    cae6:	bf 01 00 00 00       	mov    $0x1,%edi
    caeb:	4c 89 a4 24 a0 04 00 	mov    %r12,0x4a0(%rsp)
    caf2:	00 
    caf3:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    cafa:	00 
    cafb:	e8 40 9d ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cb00:	48 89 c7             	mov    %rax,%rdi
    cb03:	e8 a8 9f ff ff       	call   6ab0 <fwp_rc_fresh>
    cb08:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    cb0f:	00 
    cb10:	bf 01 00 00 00       	mov    $0x1,%edi
    cb15:	4c 89 ac 24 b0 04 00 	mov    %r13,0x4b0(%rsp)
    cb1c:	00 
    cb1d:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    cb24:	00 
    cb25:	e8 16 9d ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cb2a:	48 89 c7             	mov    %rax,%rdi
    cb2d:	e8 7e 9f ff ff       	call   6ab0 <fwp_rc_fresh>
    cb32:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    cb39:	00 
    cb3a:	bf 01 00 00 00       	mov    $0x1,%edi
    cb3f:	4c 89 a4 24 c0 04 00 	mov    %r12,0x4c0(%rsp)
    cb46:	00 
    cb47:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    cb4e:	00 
    cb4f:	e8 ec 9c ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cb54:	48 89 c7             	mov    %rax,%rdi
    cb57:	e8 54 9f ff ff       	call   6ab0 <fwp_rc_fresh>
    cb5c:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    cb63:	00 
    cb64:	bf 01 00 00 00       	mov    $0x1,%edi
    cb69:	4c 89 ac 24 d0 04 00 	mov    %r13,0x4d0(%rsp)
    cb70:	00 
    cb71:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    cb78:	00 
    cb79:	e8 c2 9c ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cb7e:	48 89 c7             	mov    %rax,%rdi
    cb81:	e8 2a 9f ff ff       	call   6ab0 <fwp_rc_fresh>
    cb86:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    cb8d:	00 
    cb8e:	bf 01 00 00 00       	mov    $0x1,%edi
    cb93:	4c 89 a4 24 e0 04 00 	mov    %r12,0x4e0(%rsp)
    cb9a:	00 
    cb9b:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    cba2:	00 
    cba3:	e8 98 9c ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cba8:	48 89 c7             	mov    %rax,%rdi
    cbab:	e8 00 9f ff ff       	call   6ab0 <fwp_rc_fresh>
    cbb0:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    cbb7:	00 
    cbb8:	bf 01 00 00 00       	mov    $0x1,%edi
    cbbd:	4c 89 ac 24 f0 04 00 	mov    %r13,0x4f0(%rsp)
    cbc4:	00 
    cbc5:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    cbcc:	00 
    cbcd:	e8 6e 9c ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cbd2:	48 89 c7             	mov    %rax,%rdi
    cbd5:	e8 d6 9e ff ff       	call   6ab0 <fwp_rc_fresh>
    cbda:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    cbe1:	00 
    cbe2:	bf 01 00 00 00       	mov    $0x1,%edi
    cbe7:	4c 89 a4 24 00 05 00 	mov    %r12,0x500(%rsp)
    cbee:	00 
    cbef:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    cbf6:	00 
    cbf7:	e8 44 9c ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cbfc:	48 89 c7             	mov    %rax,%rdi
    cbff:	e8 ac 9e ff ff       	call   6ab0 <fwp_rc_fresh>
    cc04:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    cc0b:	00 
    cc0c:	bf 01 00 00 00       	mov    $0x1,%edi
    cc11:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
    cc18:	00 
    cc19:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    cc20:	00 
    cc21:	e8 1a 9c ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cc26:	48 89 c7             	mov    %rax,%rdi
    cc29:	e8 82 9e ff ff       	call   6ab0 <fwp_rc_fresh>
    cc2e:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    cc35:	00 
    cc36:	bf 01 00 00 00       	mov    $0x1,%edi
    cc3b:	4c 89 a4 24 20 05 00 	mov    %r12,0x520(%rsp)
    cc42:	00 
    cc43:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    cc4a:	00 
    cc4b:	e8 f0 9b ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cc50:	48 89 c7             	mov    %rax,%rdi
    cc53:	e8 58 9e ff ff       	call   6ab0 <fwp_rc_fresh>
    cc58:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    cc5f:	00 
    cc60:	bf 01 00 00 00       	mov    $0x1,%edi
    cc65:	4c 89 ac 24 30 05 00 	mov    %r13,0x530(%rsp)
    cc6c:	00 
    cc6d:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    cc74:	00 
    cc75:	e8 c6 9b ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cc7a:	48 89 c7             	mov    %rax,%rdi
    cc7d:	e8 2e 9e ff ff       	call   6ab0 <fwp_rc_fresh>
    cc82:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    cc89:	00 
    cc8a:	bf 01 00 00 00       	mov    $0x1,%edi
    cc8f:	4c 89 a4 24 40 05 00 	mov    %r12,0x540(%rsp)
    cc96:	00 
    cc97:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    cc9e:	00 
    cc9f:	e8 9c 9b ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cca4:	48 89 c7             	mov    %rax,%rdi
    cca7:	e8 04 9e ff ff       	call   6ab0 <fwp_rc_fresh>
    ccac:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    ccb3:	00 
    ccb4:	bf 01 00 00 00       	mov    $0x1,%edi
    ccb9:	4c 89 ac 24 50 05 00 	mov    %r13,0x550(%rsp)
    ccc0:	00 
    ccc1:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    ccc8:	00 
    ccc9:	e8 72 9b ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    ccce:	48 89 c7             	mov    %rax,%rdi
    ccd1:	e8 da 9d ff ff       	call   6ab0 <fwp_rc_fresh>
    ccd6:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    ccdd:	00 
    ccde:	bf 01 00 00 00       	mov    $0x1,%edi
    cce3:	4c 89 a4 24 60 05 00 	mov    %r12,0x560(%rsp)
    ccea:	00 
    cceb:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    ccf2:	00 
    ccf3:	e8 48 9b ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    ccf8:	48 89 c7             	mov    %rax,%rdi
    ccfb:	e8 b0 9d ff ff       	call   6ab0 <fwp_rc_fresh>
    cd00:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    cd07:	00 
    cd08:	bf 01 00 00 00       	mov    $0x1,%edi
    cd0d:	4c 89 ac 24 70 05 00 	mov    %r13,0x570(%rsp)
    cd14:	00 
    cd15:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    cd1c:	00 
    cd1d:	e8 1e 9b ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cd22:	48 89 c7             	mov    %rax,%rdi
    cd25:	e8 86 9d ff ff       	call   6ab0 <fwp_rc_fresh>
    cd2a:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    cd31:	00 
    cd32:	bf 01 00 00 00       	mov    $0x1,%edi
    cd37:	4c 89 a4 24 80 05 00 	mov    %r12,0x580(%rsp)
    cd3e:	00 
    cd3f:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    cd46:	00 
    cd47:	e8 f4 9a ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cd4c:	48 89 c7             	mov    %rax,%rdi
    cd4f:	e8 5c 9d ff ff       	call   6ab0 <fwp_rc_fresh>
    cd54:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    cd5b:	00 
    cd5c:	bf 01 00 00 00       	mov    $0x1,%edi
    cd61:	4c 89 ac 24 90 05 00 	mov    %r13,0x590(%rsp)
    cd68:	00 
    cd69:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    cd70:	00 
    cd71:	e8 ca 9a ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cd76:	48 89 c7             	mov    %rax,%rdi
    cd79:	e8 32 9d ff ff       	call   6ab0 <fwp_rc_fresh>
    cd7e:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    cd85:	00 
    cd86:	bf 01 00 00 00       	mov    $0x1,%edi
    cd8b:	4c 89 a4 24 a0 05 00 	mov    %r12,0x5a0(%rsp)
    cd92:	00 
    cd93:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    cd9a:	00 
    cd9b:	e8 a0 9a ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cda0:	48 89 c7             	mov    %rax,%rdi
    cda3:	e8 08 9d ff ff       	call   6ab0 <fwp_rc_fresh>
    cda8:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    cdaf:	00 
    cdb0:	bf 01 00 00 00       	mov    $0x1,%edi
    cdb5:	4c 89 ac 24 b0 05 00 	mov    %r13,0x5b0(%rsp)
    cdbc:	00 
    cdbd:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    cdc4:	00 
    cdc5:	e8 76 9a ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cdca:	48 89 c7             	mov    %rax,%rdi
    cdcd:	e8 de 9c ff ff       	call   6ab0 <fwp_rc_fresh>
    cdd2:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    cdd9:	00 
    cdda:	bf 01 00 00 00       	mov    $0x1,%edi
    cddf:	4c 89 a4 24 c0 05 00 	mov    %r12,0x5c0(%rsp)
    cde6:	00 
    cde7:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    cdee:	00 
    cdef:	e8 4c 9a ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cdf4:	48 89 c7             	mov    %rax,%rdi
    cdf7:	e8 b4 9c ff ff       	call   6ab0 <fwp_rc_fresh>
    cdfc:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    ce03:	00 
    ce04:	bf 01 00 00 00       	mov    $0x1,%edi
    ce09:	4c 89 ac 24 d0 05 00 	mov    %r13,0x5d0(%rsp)
    ce10:	00 
    ce11:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    ce18:	00 
    ce19:	e8 22 9a ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    ce1e:	48 89 c7             	mov    %rax,%rdi
    ce21:	e8 8a 9c ff ff       	call   6ab0 <fwp_rc_fresh>
    ce26:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    ce2d:	00 
    ce2e:	bf 01 00 00 00       	mov    $0x1,%edi
    ce33:	4c 89 a4 24 e0 05 00 	mov    %r12,0x5e0(%rsp)
    ce3a:	00 
    ce3b:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    ce42:	00 
    ce43:	e8 f8 99 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    ce48:	48 89 c7             	mov    %rax,%rdi
    ce4b:	e8 60 9c ff ff       	call   6ab0 <fwp_rc_fresh>
    ce50:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    ce57:	00 
    ce58:	bf 01 00 00 00       	mov    $0x1,%edi
    ce5d:	4c 89 ac 24 f0 05 00 	mov    %r13,0x5f0(%rsp)
    ce64:	00 
    ce65:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    ce6c:	00 
    ce6d:	e8 ce 99 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    ce72:	48 89 c7             	mov    %rax,%rdi
    ce75:	e8 36 9c ff ff       	call   6ab0 <fwp_rc_fresh>
    ce7a:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    ce81:	00 
    ce82:	bf 01 00 00 00       	mov    $0x1,%edi
    ce87:	4c 89 a4 24 00 06 00 	mov    %r12,0x600(%rsp)
    ce8e:	00 
    ce8f:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    ce96:	00 
    ce97:	e8 a4 99 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    ce9c:	48 89 c7             	mov    %rax,%rdi
    ce9f:	e8 0c 9c ff ff       	call   6ab0 <fwp_rc_fresh>
    cea4:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    ceab:	00 
    ceac:	bf 01 00 00 00       	mov    $0x1,%edi
    ceb1:	4c 89 ac 24 10 06 00 	mov    %r13,0x610(%rsp)
    ceb8:	00 
    ceb9:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    cec0:	00 
    cec1:	e8 7a 99 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cec6:	48 89 c7             	mov    %rax,%rdi
    cec9:	e8 e2 9b ff ff       	call   6ab0 <fwp_rc_fresh>
    cece:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    ced5:	00 
    ced6:	bf 01 00 00 00       	mov    $0x1,%edi
    cedb:	4c 89 a4 24 20 06 00 	mov    %r12,0x620(%rsp)
    cee2:	00 
    cee3:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    ceea:	00 
    ceeb:	e8 50 99 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cef0:	48 89 c7             	mov    %rax,%rdi
    cef3:	e8 b8 9b ff ff       	call   6ab0 <fwp_rc_fresh>
    cef8:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    ceff:	00 
    cf00:	bf 01 00 00 00       	mov    $0x1,%edi
    cf05:	4c 89 ac 24 30 06 00 	mov    %r13,0x630(%rsp)
    cf0c:	00 
    cf0d:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    cf14:	00 
    cf15:	e8 26 99 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cf1a:	48 89 c7             	mov    %rax,%rdi
    cf1d:	e8 8e 9b ff ff       	call   6ab0 <fwp_rc_fresh>
    cf22:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    cf29:	00 
    cf2a:	bf 01 00 00 00       	mov    $0x1,%edi
    cf2f:	4c 89 a4 24 40 06 00 	mov    %r12,0x640(%rsp)
    cf36:	00 
    cf37:	48 89 84 24 48 06 00 	mov    %rax,0x648(%rsp)
    cf3e:	00 
    cf3f:	e8 fc 98 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cf44:	48 8b 15 cd 0c 06 00 	mov    0x60ccd(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    cf4b:	49 89 c5             	mov    %rax,%r13
    cf4e:	48 2b 05 9b 0c 06 00 	sub    0x60c9b(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    cf55:	48 c1 e2 10          	shl    $0x10,%rdx
    cf59:	48 39 d0             	cmp    %rdx,%rax
    cf5c:	73 59                	jae    cfb7 <f0+0x1457>
    cf5e:	48 89 c2             	mov    %rax,%rdx
    cf61:	48 c1 ea 10          	shr    $0x10,%rdx
    cf65:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf69:	48 8b 15 c8 0c 06 00 	mov    0x60cc8(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    cf70:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf74:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf78:	4d 85 e4             	test   %r12,%r12
    cf7b:	74 3a                	je     cfb7 <f0+0x1457>
    cf7d:	0f b6 0a             	movzbl (%rdx),%ecx
    cf80:	80 f9 02             	cmp    $0x2,%cl
    cf83:	0f 84 17 15 00 00    	je     e4a0 <f0+0x2940>
    cf89:	80 f9 01             	cmp    $0x1,%cl
    cf8c:	75 29                	jne    cfb7 <f0+0x1457>
    cf8e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf91:	0f b7 c0             	movzwl %ax,%eax
    cf94:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf97:	48 0f af c1          	imul   %rcx,%rax
    cf9b:	48 c1 e8 20          	shr    $0x20,%rax
    cf9f:	48 39 d0             	cmp    %rdx,%rax
    cfa2:	73 13                	jae    cfb7 <f0+0x1457>
    cfa4:	49 01 c4             	add    %rax,%r12
    cfa7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cfac:	0f 84 07 17 00 00    	je     e6b9 <f0+0x2b59>
    cfb2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cfb7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cfbe:	00 f0 3f 
    cfc1:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    cfc8:	00 
    cfc9:	bf 01 00 00 00       	mov    $0x1,%edi
    cfce:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    cfd5:	00 
    cfd6:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    cfdd:	00 
    cfde:	e8 5d 98 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    cfe3:	48 8b 15 2e 0c 06 00 	mov    0x60c2e(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    cfea:	49 89 c5             	mov    %rax,%r13
    cfed:	48 2b 05 fc 0b 06 00 	sub    0x60bfc(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    cff4:	48 c1 e2 10          	shl    $0x10,%rdx
    cff8:	48 39 d0             	cmp    %rdx,%rax
    cffb:	73 59                	jae    d056 <f0+0x14f6>
    cffd:	48 89 c2             	mov    %rax,%rdx
    d000:	48 c1 ea 10          	shr    $0x10,%rdx
    d004:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d008:	48 8b 15 29 0c 06 00 	mov    0x60c29(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d00f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d013:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d017:	4d 85 e4             	test   %r12,%r12
    d01a:	74 3a                	je     d056 <f0+0x14f6>
    d01c:	0f b6 0a             	movzbl (%rdx),%ecx
    d01f:	80 f9 02             	cmp    $0x2,%cl
    d022:	0f 84 28 15 00 00    	je     e550 <f0+0x29f0>
    d028:	80 f9 01             	cmp    $0x1,%cl
    d02b:	75 29                	jne    d056 <f0+0x14f6>
    d02d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d030:	0f b7 c0             	movzwl %ax,%eax
    d033:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d036:	48 0f af c1          	imul   %rcx,%rax
    d03a:	48 c1 e8 20          	shr    $0x20,%rax
    d03e:	48 39 d0             	cmp    %rdx,%rax
    d041:	73 13                	jae    d056 <f0+0x14f6>
    d043:	49 01 c4             	add    %rax,%r12
    d046:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d04b:	0f 84 75 16 00 00    	je     e6c6 <f0+0x2b66>
    d051:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d056:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d05d:	33 f3 bf 
    d060:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    d067:	00 
    d068:	bf 01 00 00 00       	mov    $0x1,%edi
    d06d:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    d074:	00 
    d075:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    d07c:	00 
    d07d:	e8 be 97 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    d082:	48 8b 15 8f 0b 06 00 	mov    0x60b8f(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d089:	49 89 c5             	mov    %rax,%r13
    d08c:	48 2b 05 5d 0b 06 00 	sub    0x60b5d(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d093:	48 c1 e2 10          	shl    $0x10,%rdx
    d097:	48 39 d0             	cmp    %rdx,%rax
    d09a:	73 59                	jae    d0f5 <f0+0x1595>
    d09c:	48 89 c2             	mov    %rax,%rdx
    d09f:	48 c1 ea 10          	shr    $0x10,%rdx
    d0a3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0a7:	48 8b 15 8a 0b 06 00 	mov    0x60b8a(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d0ae:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d0b2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d0b6:	4d 85 e4             	test   %r12,%r12
    d0b9:	74 3a                	je     d0f5 <f0+0x1595>
    d0bb:	0f b6 0a             	movzbl (%rdx),%ecx
    d0be:	80 f9 02             	cmp    $0x2,%cl
    d0c1:	0f 84 79 14 00 00    	je     e540 <f0+0x29e0>
    d0c7:	80 f9 01             	cmp    $0x1,%cl
    d0ca:	75 29                	jne    d0f5 <f0+0x1595>
    d0cc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d0cf:	0f b7 c0             	movzwl %ax,%eax
    d0d2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d0d5:	48 0f af c1          	imul   %rcx,%rax
    d0d9:	48 c1 e8 20          	shr    $0x20,%rax
    d0dd:	48 39 d0             	cmp    %rdx,%rax
    d0e0:	73 13                	jae    d0f5 <f0+0x1595>
    d0e2:	49 01 c4             	add    %rax,%r12
    d0e5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d0ea:	0f 84 e3 15 00 00    	je     e6d3 <f0+0x2b73>
    d0f0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0f5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d0fc:	00 f0 3f 
    d0ff:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    d106:	00 
    d107:	bf 01 00 00 00       	mov    $0x1,%edi
    d10c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    d113:	00 
    d114:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    d11b:	00 
    d11c:	e8 1f 97 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    d121:	48 8b 15 f0 0a 06 00 	mov    0x60af0(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d128:	49 89 c5             	mov    %rax,%r13
    d12b:	48 2b 05 be 0a 06 00 	sub    0x60abe(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d132:	48 c1 e2 10          	shl    $0x10,%rdx
    d136:	48 39 d0             	cmp    %rdx,%rax
    d139:	73 59                	jae    d194 <f0+0x1634>
    d13b:	48 89 c2             	mov    %rax,%rdx
    d13e:	48 c1 ea 10          	shr    $0x10,%rdx
    d142:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d146:	48 8b 15 eb 0a 06 00 	mov    0x60aeb(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d14d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d151:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d155:	4d 85 e4             	test   %r12,%r12
    d158:	74 3a                	je     d194 <f0+0x1634>
    d15a:	0f b6 0a             	movzbl (%rdx),%ecx
    d15d:	80 f9 02             	cmp    $0x2,%cl
    d160:	0f 84 ca 13 00 00    	je     e530 <f0+0x29d0>
    d166:	80 f9 01             	cmp    $0x1,%cl
    d169:	75 29                	jne    d194 <f0+0x1634>
    d16b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d16e:	0f b7 c0             	movzwl %ax,%eax
    d171:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d174:	48 0f af c1          	imul   %rcx,%rax
    d178:	48 c1 e8 20          	shr    $0x20,%rax
    d17c:	48 39 d0             	cmp    %rdx,%rax
    d17f:	73 13                	jae    d194 <f0+0x1634>
    d181:	49 01 c4             	add    %rax,%r12
    d184:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d189:	0f 84 51 15 00 00    	je     e6e0 <f0+0x2b80>
    d18f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d194:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d19b:	33 f3 bf 
    d19e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    d1a5:	00 
    d1a6:	bf 01 00 00 00       	mov    $0x1,%edi
    d1ab:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    d1b2:	00 
    d1b3:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    d1ba:	00 
    d1bb:	e8 80 96 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    d1c0:	48 8b 15 51 0a 06 00 	mov    0x60a51(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d1c7:	49 89 c5             	mov    %rax,%r13
    d1ca:	48 2b 05 1f 0a 06 00 	sub    0x60a1f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d1d1:	48 c1 e2 10          	shl    $0x10,%rdx
    d1d5:	48 39 d0             	cmp    %rdx,%rax
    d1d8:	73 59                	jae    d233 <f0+0x16d3>
    d1da:	48 89 c2             	mov    %rax,%rdx
    d1dd:	48 c1 ea 10          	shr    $0x10,%rdx
    d1e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d1e5:	48 8b 15 4c 0a 06 00 	mov    0x60a4c(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d1ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d1f0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d1f4:	4d 85 e4             	test   %r12,%r12
    d1f7:	74 3a                	je     d233 <f0+0x16d3>
    d1f9:	0f b6 0a             	movzbl (%rdx),%ecx
    d1fc:	80 f9 02             	cmp    $0x2,%cl
    d1ff:	0f 84 1b 13 00 00    	je     e520 <f0+0x29c0>
    d205:	80 f9 01             	cmp    $0x1,%cl
    d208:	75 29                	jne    d233 <f0+0x16d3>
    d20a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d20d:	0f b7 c0             	movzwl %ax,%eax
    d210:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d213:	48 0f af c1          	imul   %rcx,%rax
    d217:	48 c1 e8 20          	shr    $0x20,%rax
    d21b:	48 39 d0             	cmp    %rdx,%rax
    d21e:	73 13                	jae    d233 <f0+0x16d3>
    d220:	49 01 c4             	add    %rax,%r12
    d223:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d228:	0f 84 bf 14 00 00    	je     e6ed <f0+0x2b8d>
    d22e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d233:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d23a:	00 f0 3f 
    d23d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    d244:	00 
    d245:	bf 01 00 00 00       	mov    $0x1,%edi
    d24a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    d251:	00 
    d252:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    d259:	00 
    d25a:	e8 e1 95 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    d25f:	48 8b 15 b2 09 06 00 	mov    0x609b2(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d266:	49 89 c5             	mov    %rax,%r13
    d269:	48 2b 05 80 09 06 00 	sub    0x60980(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d270:	48 c1 e2 10          	shl    $0x10,%rdx
    d274:	48 39 d0             	cmp    %rdx,%rax
    d277:	73 59                	jae    d2d2 <f0+0x1772>
    d279:	48 89 c2             	mov    %rax,%rdx
    d27c:	48 c1 ea 10          	shr    $0x10,%rdx
    d280:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d284:	48 8b 15 ad 09 06 00 	mov    0x609ad(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d28b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d28f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d293:	4d 85 e4             	test   %r12,%r12
    d296:	74 3a                	je     d2d2 <f0+0x1772>
    d298:	0f b6 0a             	movzbl (%rdx),%ecx
    d29b:	80 f9 02             	cmp    $0x2,%cl
    d29e:	0f 84 6c 12 00 00    	je     e510 <f0+0x29b0>
    d2a4:	80 f9 01             	cmp    $0x1,%cl
    d2a7:	75 29                	jne    d2d2 <f0+0x1772>
    d2a9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2ac:	0f b7 c0             	movzwl %ax,%eax
    d2af:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d2b2:	48 0f af c1          	imul   %rcx,%rax
    d2b6:	48 c1 e8 20          	shr    $0x20,%rax
    d2ba:	48 39 d0             	cmp    %rdx,%rax
    d2bd:	73 13                	jae    d2d2 <f0+0x1772>
    d2bf:	49 01 c4             	add    %rax,%r12
    d2c2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d2c7:	0f 84 2d 14 00 00    	je     e6fa <f0+0x2b9a>
    d2cd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d2d2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d2d9:	33 f3 bf 
    d2dc:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    d2e3:	00 
    d2e4:	bf 01 00 00 00       	mov    $0x1,%edi
    d2e9:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    d2f0:	00 
    d2f1:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    d2f8:	00 
    d2f9:	e8 42 95 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    d2fe:	48 8b 15 13 09 06 00 	mov    0x60913(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d305:	49 89 c5             	mov    %rax,%r13
    d308:	48 2b 05 e1 08 06 00 	sub    0x608e1(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d30f:	48 c1 e2 10          	shl    $0x10,%rdx
    d313:	48 39 d0             	cmp    %rdx,%rax
    d316:	73 59                	jae    d371 <f0+0x1811>
    d318:	48 89 c2             	mov    %rax,%rdx
    d31b:	48 c1 ea 10          	shr    $0x10,%rdx
    d31f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d323:	48 8b 15 0e 09 06 00 	mov    0x6090e(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d32a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d32e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d332:	4d 85 e4             	test   %r12,%r12
    d335:	74 3a                	je     d371 <f0+0x1811>
    d337:	0f b6 0a             	movzbl (%rdx),%ecx
    d33a:	80 f9 02             	cmp    $0x2,%cl
    d33d:	0f 84 bd 11 00 00    	je     e500 <f0+0x29a0>
    d343:	80 f9 01             	cmp    $0x1,%cl
    d346:	75 29                	jne    d371 <f0+0x1811>
    d348:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d34b:	0f b7 c0             	movzwl %ax,%eax
    d34e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d351:	48 0f af c1          	imul   %rcx,%rax
    d355:	48 c1 e8 20          	shr    $0x20,%rax
    d359:	48 39 d0             	cmp    %rdx,%rax
    d35c:	73 13                	jae    d371 <f0+0x1811>
    d35e:	49 01 c4             	add    %rax,%r12
    d361:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d366:	0f 84 9b 13 00 00    	je     e707 <f0+0x2ba7>
    d36c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d371:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d378:	00 f0 3f 
    d37b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    d382:	00 
    d383:	bf 01 00 00 00       	mov    $0x1,%edi
    d388:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    d38f:	00 
    d390:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    d397:	00 
    d398:	e8 a3 94 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    d39d:	48 8b 15 74 08 06 00 	mov    0x60874(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d3a4:	49 89 c5             	mov    %rax,%r13
    d3a7:	48 2b 05 42 08 06 00 	sub    0x60842(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d3ae:	48 c1 e2 10          	shl    $0x10,%rdx
    d3b2:	48 39 d0             	cmp    %rdx,%rax
    d3b5:	73 59                	jae    d410 <f0+0x18b0>
    d3b7:	48 89 c2             	mov    %rax,%rdx
    d3ba:	48 c1 ea 10          	shr    $0x10,%rdx
    d3be:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d3c2:	48 8b 15 6f 08 06 00 	mov    0x6086f(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d3c9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d3cd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d3d1:	4d 85 e4             	test   %r12,%r12
    d3d4:	74 3a                	je     d410 <f0+0x18b0>
    d3d6:	0f b6 0a             	movzbl (%rdx),%ecx
    d3d9:	80 f9 02             	cmp    $0x2,%cl
    d3dc:	0f 84 0e 11 00 00    	je     e4f0 <f0+0x2990>
    d3e2:	80 f9 01             	cmp    $0x1,%cl
    d3e5:	75 29                	jne    d410 <f0+0x18b0>
    d3e7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d3ea:	0f b7 c0             	movzwl %ax,%eax
    d3ed:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d3f0:	48 0f af c1          	imul   %rcx,%rax
    d3f4:	48 c1 e8 20          	shr    $0x20,%rax
    d3f8:	48 39 d0             	cmp    %rdx,%rax
    d3fb:	73 13                	jae    d410 <f0+0x18b0>
    d3fd:	49 01 c4             	add    %rax,%r12
    d400:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d405:	0f 84 09 13 00 00    	je     e714 <f0+0x2bb4>
    d40b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d410:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d417:	33 f3 bf 
    d41a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    d421:	00 
    d422:	bf 01 00 00 00       	mov    $0x1,%edi
    d427:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    d42e:	00 
    d42f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    d436:	00 
    d437:	e8 04 94 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    d43c:	48 8b 15 d5 07 06 00 	mov    0x607d5(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d443:	49 89 c5             	mov    %rax,%r13
    d446:	48 2b 05 a3 07 06 00 	sub    0x607a3(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d44d:	48 c1 e2 10          	shl    $0x10,%rdx
    d451:	48 39 d0             	cmp    %rdx,%rax
    d454:	73 59                	jae    d4af <f0+0x194f>
    d456:	48 89 c2             	mov    %rax,%rdx
    d459:	48 c1 ea 10          	shr    $0x10,%rdx
    d45d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d461:	48 8b 15 d0 07 06 00 	mov    0x607d0(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d468:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d46c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d470:	4d 85 e4             	test   %r12,%r12
    d473:	74 3a                	je     d4af <f0+0x194f>
    d475:	0f b6 0a             	movzbl (%rdx),%ecx
    d478:	80 f9 02             	cmp    $0x2,%cl
    d47b:	0f 84 5f 10 00 00    	je     e4e0 <f0+0x2980>
    d481:	80 f9 01             	cmp    $0x1,%cl
    d484:	75 29                	jne    d4af <f0+0x194f>
    d486:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d489:	0f b7 c0             	movzwl %ax,%eax
    d48c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d48f:	48 0f af c1          	imul   %rcx,%rax
    d493:	48 c1 e8 20          	shr    $0x20,%rax
    d497:	48 39 d0             	cmp    %rdx,%rax
    d49a:	73 13                	jae    d4af <f0+0x194f>
    d49c:	49 01 c4             	add    %rax,%r12
    d49f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d4a4:	0f 84 77 12 00 00    	je     e721 <f0+0x2bc1>
    d4aa:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d4af:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d4b6:	00 f0 3f 
    d4b9:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    d4c0:	00 
    d4c1:	bf 01 00 00 00       	mov    $0x1,%edi
    d4c6:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    d4cd:	00 
    d4ce:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    d4d5:	00 
    d4d6:	e8 65 93 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    d4db:	48 8b 15 36 07 06 00 	mov    0x60736(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d4e2:	49 89 c5             	mov    %rax,%r13
    d4e5:	48 2b 05 04 07 06 00 	sub    0x60704(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d4ec:	48 c1 e2 10          	shl    $0x10,%rdx
    d4f0:	48 39 d0             	cmp    %rdx,%rax
    d4f3:	73 59                	jae    d54e <f0+0x19ee>
    d4f5:	48 89 c2             	mov    %rax,%rdx
    d4f8:	48 c1 ea 10          	shr    $0x10,%rdx
    d4fc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d500:	48 8b 15 31 07 06 00 	mov    0x60731(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d507:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d50b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d50f:	4d 85 e4             	test   %r12,%r12
    d512:	74 3a                	je     d54e <f0+0x19ee>
    d514:	0f b6 0a             	movzbl (%rdx),%ecx
    d517:	80 f9 02             	cmp    $0x2,%cl
    d51a:	0f 84 40 0f 00 00    	je     e460 <f0+0x2900>
    d520:	80 f9 01             	cmp    $0x1,%cl
    d523:	75 29                	jne    d54e <f0+0x19ee>
    d525:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d528:	0f b7 c0             	movzwl %ax,%eax
    d52b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d52e:	48 0f af c1          	imul   %rcx,%rax
    d532:	48 c1 e8 20          	shr    $0x20,%rax
    d536:	48 39 d0             	cmp    %rdx,%rax
    d539:	73 13                	jae    d54e <f0+0x19ee>
    d53b:	49 01 c4             	add    %rax,%r12
    d53e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d543:	0f 84 e5 11 00 00    	je     e72e <f0+0x2bce>
    d549:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d54e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d555:	33 f3 bf 
    d558:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    d55f:	00 
    d560:	bf 01 00 00 00       	mov    $0x1,%edi
    d565:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    d56c:	00 
    d56d:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    d574:	00 
    d575:	e8 c6 92 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    d57a:	48 8b 15 97 06 06 00 	mov    0x60697(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d581:	49 89 c5             	mov    %rax,%r13
    d584:	48 2b 05 65 06 06 00 	sub    0x60665(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d58b:	48 c1 e2 10          	shl    $0x10,%rdx
    d58f:	48 39 d0             	cmp    %rdx,%rax
    d592:	73 59                	jae    d5ed <f0+0x1a8d>
    d594:	48 89 c2             	mov    %rax,%rdx
    d597:	48 c1 ea 10          	shr    $0x10,%rdx
    d59b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d59f:	48 8b 15 92 06 06 00 	mov    0x60692(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d5a6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d5aa:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d5ae:	4d 85 e4             	test   %r12,%r12
    d5b1:	74 3a                	je     d5ed <f0+0x1a8d>
    d5b3:	0f b6 0a             	movzbl (%rdx),%ecx
    d5b6:	80 f9 02             	cmp    $0x2,%cl
    d5b9:	0f 84 91 0e 00 00    	je     e450 <f0+0x28f0>
    d5bf:	80 f9 01             	cmp    $0x1,%cl
    d5c2:	75 29                	jne    d5ed <f0+0x1a8d>
    d5c4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d5c7:	0f b7 c0             	movzwl %ax,%eax
    d5ca:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d5cd:	48 0f af c1          	imul   %rcx,%rax
    d5d1:	48 c1 e8 20          	shr    $0x20,%rax
    d5d5:	48 39 d0             	cmp    %rdx,%rax
    d5d8:	73 13                	jae    d5ed <f0+0x1a8d>
    d5da:	49 01 c4             	add    %rax,%r12
    d5dd:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d5e2:	0f 84 53 11 00 00    	je     e73b <f0+0x2bdb>
    d5e8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d5ed:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d5f4:	00 f0 3f 
    d5f7:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    d5fe:	00 
    d5ff:	bf 01 00 00 00       	mov    $0x1,%edi
    d604:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    d60b:	00 
    d60c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    d613:	00 
    d614:	e8 27 92 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    d619:	48 8b 15 f8 05 06 00 	mov    0x605f8(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d620:	49 89 c5             	mov    %rax,%r13
    d623:	48 2b 05 c6 05 06 00 	sub    0x605c6(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d62a:	48 c1 e2 10          	shl    $0x10,%rdx
    d62e:	48 39 d0             	cmp    %rdx,%rax
    d631:	73 59                	jae    d68c <f0+0x1b2c>
    d633:	48 89 c2             	mov    %rax,%rdx
    d636:	48 c1 ea 10          	shr    $0x10,%rdx
    d63a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d63e:	48 8b 15 f3 05 06 00 	mov    0x605f3(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d645:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d649:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d64d:	4d 85 e4             	test   %r12,%r12
    d650:	74 3a                	je     d68c <f0+0x1b2c>
    d652:	0f b6 0a             	movzbl (%rdx),%ecx
    d655:	80 f9 02             	cmp    $0x2,%cl
    d658:	0f 84 e2 0d 00 00    	je     e440 <f0+0x28e0>
    d65e:	80 f9 01             	cmp    $0x1,%cl
    d661:	75 29                	jne    d68c <f0+0x1b2c>
    d663:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d666:	0f b7 c0             	movzwl %ax,%eax
    d669:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d66c:	48 0f af c1          	imul   %rcx,%rax
    d670:	48 c1 e8 20          	shr    $0x20,%rax
    d674:	48 39 d0             	cmp    %rdx,%rax
    d677:	73 13                	jae    d68c <f0+0x1b2c>
    d679:	49 01 c4             	add    %rax,%r12
    d67c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d681:	0f 84 c1 10 00 00    	je     e748 <f0+0x2be8>
    d687:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d68c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d693:	33 f3 bf 
    d696:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    d69d:	00 
    d69e:	bf 01 00 00 00       	mov    $0x1,%edi
    d6a3:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    d6aa:	00 
    d6ab:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    d6b2:	00 
    d6b3:	e8 88 91 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    d6b8:	48 8b 15 59 05 06 00 	mov    0x60559(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d6bf:	49 89 c5             	mov    %rax,%r13
    d6c2:	48 2b 05 27 05 06 00 	sub    0x60527(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d6c9:	48 c1 e2 10          	shl    $0x10,%rdx
    d6cd:	48 39 d0             	cmp    %rdx,%rax
    d6d0:	73 59                	jae    d72b <f0+0x1bcb>
    d6d2:	48 89 c2             	mov    %rax,%rdx
    d6d5:	48 c1 ea 10          	shr    $0x10,%rdx
    d6d9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d6dd:	48 8b 15 54 05 06 00 	mov    0x60554(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d6e4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d6e8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d6ec:	4d 85 e4             	test   %r12,%r12
    d6ef:	74 3a                	je     d72b <f0+0x1bcb>
    d6f1:	0f b6 0a             	movzbl (%rdx),%ecx
    d6f4:	80 f9 02             	cmp    $0x2,%cl
    d6f7:	0f 84 33 0d 00 00    	je     e430 <f0+0x28d0>
    d6fd:	80 f9 01             	cmp    $0x1,%cl
    d700:	75 29                	jne    d72b <f0+0x1bcb>
    d702:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d705:	0f b7 c0             	movzwl %ax,%eax
    d708:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d70b:	48 0f af c1          	imul   %rcx,%rax
    d70f:	48 c1 e8 20          	shr    $0x20,%rax
    d713:	48 39 d0             	cmp    %rdx,%rax
    d716:	73 13                	jae    d72b <f0+0x1bcb>
    d718:	49 01 c4             	add    %rax,%r12
    d71b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d720:	0f 84 2f 10 00 00    	je     e755 <f0+0x2bf5>
    d726:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d72b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d732:	00 f0 3f 
    d735:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    d73c:	00 
    d73d:	bf 01 00 00 00       	mov    $0x1,%edi
    d742:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    d749:	00 
    d74a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    d751:	00 
    d752:	e8 e9 90 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    d757:	48 8b 15 ba 04 06 00 	mov    0x604ba(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d75e:	49 89 c5             	mov    %rax,%r13
    d761:	48 2b 05 88 04 06 00 	sub    0x60488(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d768:	48 c1 e2 10          	shl    $0x10,%rdx
    d76c:	48 39 d0             	cmp    %rdx,%rax
    d76f:	73 59                	jae    d7ca <f0+0x1c6a>
    d771:	48 89 c2             	mov    %rax,%rdx
    d774:	48 c1 ea 10          	shr    $0x10,%rdx
    d778:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d77c:	48 8b 15 b5 04 06 00 	mov    0x604b5(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d783:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d787:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d78b:	4d 85 e4             	test   %r12,%r12
    d78e:	74 3a                	je     d7ca <f0+0x1c6a>
    d790:	0f b6 0a             	movzbl (%rdx),%ecx
    d793:	80 f9 02             	cmp    $0x2,%cl
    d796:	0f 84 84 0c 00 00    	je     e420 <f0+0x28c0>
    d79c:	80 f9 01             	cmp    $0x1,%cl
    d79f:	75 29                	jne    d7ca <f0+0x1c6a>
    d7a1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d7a4:	0f b7 c0             	movzwl %ax,%eax
    d7a7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d7aa:	48 0f af c1          	imul   %rcx,%rax
    d7ae:	48 c1 e8 20          	shr    $0x20,%rax
    d7b2:	48 39 d0             	cmp    %rdx,%rax
    d7b5:	73 13                	jae    d7ca <f0+0x1c6a>
    d7b7:	49 01 c4             	add    %rax,%r12
    d7ba:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d7bf:	0f 84 9d 0f 00 00    	je     e762 <f0+0x2c02>
    d7c5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d7ca:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d7d1:	33 f3 bf 
    d7d4:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    d7db:	00 
    d7dc:	bf 01 00 00 00       	mov    $0x1,%edi
    d7e1:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    d7e8:	00 
    d7e9:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    d7f0:	00 
    d7f1:	e8 4a 90 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    d7f6:	48 8b 15 1b 04 06 00 	mov    0x6041b(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d7fd:	49 89 c5             	mov    %rax,%r13
    d800:	48 2b 05 e9 03 06 00 	sub    0x603e9(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d807:	48 c1 e2 10          	shl    $0x10,%rdx
    d80b:	48 39 d0             	cmp    %rdx,%rax
    d80e:	73 59                	jae    d869 <f0+0x1d09>
    d810:	48 89 c2             	mov    %rax,%rdx
    d813:	48 c1 ea 10          	shr    $0x10,%rdx
    d817:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d81b:	48 8b 15 16 04 06 00 	mov    0x60416(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d822:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d826:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d82a:	4d 85 e4             	test   %r12,%r12
    d82d:	74 3a                	je     d869 <f0+0x1d09>
    d82f:	0f b6 0a             	movzbl (%rdx),%ecx
    d832:	80 f9 02             	cmp    $0x2,%cl
    d835:	0f 84 d5 0b 00 00    	je     e410 <f0+0x28b0>
    d83b:	80 f9 01             	cmp    $0x1,%cl
    d83e:	75 29                	jne    d869 <f0+0x1d09>
    d840:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d843:	0f b7 c0             	movzwl %ax,%eax
    d846:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d849:	48 0f af c1          	imul   %rcx,%rax
    d84d:	48 c1 e8 20          	shr    $0x20,%rax
    d851:	48 39 d0             	cmp    %rdx,%rax
    d854:	73 13                	jae    d869 <f0+0x1d09>
    d856:	49 01 c4             	add    %rax,%r12
    d859:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d85e:	0f 84 0b 0f 00 00    	je     e76f <f0+0x2c0f>
    d864:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d869:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d870:	00 f0 3f 
    d873:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    d87a:	00 
    d87b:	bf 01 00 00 00       	mov    $0x1,%edi
    d880:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    d887:	00 
    d888:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    d88f:	00 
    d890:	e8 ab 8f ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    d895:	48 8b 15 7c 03 06 00 	mov    0x6037c(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d89c:	49 89 c5             	mov    %rax,%r13
    d89f:	48 2b 05 4a 03 06 00 	sub    0x6034a(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d8a6:	48 c1 e2 10          	shl    $0x10,%rdx
    d8aa:	48 39 d0             	cmp    %rdx,%rax
    d8ad:	73 59                	jae    d908 <f0+0x1da8>
    d8af:	48 89 c2             	mov    %rax,%rdx
    d8b2:	48 c1 ea 10          	shr    $0x10,%rdx
    d8b6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d8ba:	48 8b 15 77 03 06 00 	mov    0x60377(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d8c1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d8c5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d8c9:	4d 85 e4             	test   %r12,%r12
    d8cc:	74 3a                	je     d908 <f0+0x1da8>
    d8ce:	0f b6 0a             	movzbl (%rdx),%ecx
    d8d1:	80 f9 02             	cmp    $0x2,%cl
    d8d4:	0f 84 26 0b 00 00    	je     e400 <f0+0x28a0>
    d8da:	80 f9 01             	cmp    $0x1,%cl
    d8dd:	75 29                	jne    d908 <f0+0x1da8>
    d8df:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d8e2:	0f b7 c0             	movzwl %ax,%eax
    d8e5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d8e8:	48 0f af c1          	imul   %rcx,%rax
    d8ec:	48 c1 e8 20          	shr    $0x20,%rax
    d8f0:	48 39 d0             	cmp    %rdx,%rax
    d8f3:	73 13                	jae    d908 <f0+0x1da8>
    d8f5:	49 01 c4             	add    %rax,%r12
    d8f8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d8fd:	0f 84 79 0e 00 00    	je     e77c <f0+0x2c1c>
    d903:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d908:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d90f:	33 f3 bf 
    d912:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    d919:	00 
    d91a:	bf 01 00 00 00       	mov    $0x1,%edi
    d91f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    d926:	00 
    d927:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    d92e:	00 
    d92f:	e8 0c 8f ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    d934:	48 8b 15 dd 02 06 00 	mov    0x602dd(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d93b:	49 89 c5             	mov    %rax,%r13
    d93e:	48 2b 05 ab 02 06 00 	sub    0x602ab(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d945:	48 c1 e2 10          	shl    $0x10,%rdx
    d949:	48 39 d0             	cmp    %rdx,%rax
    d94c:	73 59                	jae    d9a7 <f0+0x1e47>
    d94e:	48 89 c2             	mov    %rax,%rdx
    d951:	48 c1 ea 10          	shr    $0x10,%rdx
    d955:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d959:	48 8b 15 d8 02 06 00 	mov    0x602d8(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d960:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d964:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d968:	4d 85 e4             	test   %r12,%r12
    d96b:	74 3a                	je     d9a7 <f0+0x1e47>
    d96d:	0f b6 0a             	movzbl (%rdx),%ecx
    d970:	80 f9 02             	cmp    $0x2,%cl
    d973:	0f 84 77 0a 00 00    	je     e3f0 <f0+0x2890>
    d979:	80 f9 01             	cmp    $0x1,%cl
    d97c:	75 29                	jne    d9a7 <f0+0x1e47>
    d97e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d981:	0f b7 c0             	movzwl %ax,%eax
    d984:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d987:	48 0f af c1          	imul   %rcx,%rax
    d98b:	48 c1 e8 20          	shr    $0x20,%rax
    d98f:	48 39 d0             	cmp    %rdx,%rax
    d992:	73 13                	jae    d9a7 <f0+0x1e47>
    d994:	49 01 c4             	add    %rax,%r12
    d997:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d99c:	0f 84 e7 0d 00 00    	je     e789 <f0+0x2c29>
    d9a2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d9a7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d9ae:	00 f0 3f 
    d9b1:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    d9b8:	00 
    d9b9:	bf 01 00 00 00       	mov    $0x1,%edi
    d9be:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    d9c5:	00 
    d9c6:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    d9cd:	00 
    d9ce:	e8 6d 8e ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    d9d3:	48 8b 15 3e 02 06 00 	mov    0x6023e(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d9da:	49 89 c5             	mov    %rax,%r13
    d9dd:	48 2b 05 0c 02 06 00 	sub    0x6020c(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d9e4:	48 c1 e2 10          	shl    $0x10,%rdx
    d9e8:	48 39 d0             	cmp    %rdx,%rax
    d9eb:	73 59                	jae    da46 <f0+0x1ee6>
    d9ed:	48 89 c2             	mov    %rax,%rdx
    d9f0:	48 c1 ea 10          	shr    $0x10,%rdx
    d9f4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d9f8:	48 8b 15 39 02 06 00 	mov    0x60239(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d9ff:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    da03:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    da07:	4d 85 e4             	test   %r12,%r12
    da0a:	74 3a                	je     da46 <f0+0x1ee6>
    da0c:	0f b6 0a             	movzbl (%rdx),%ecx
    da0f:	80 f9 02             	cmp    $0x2,%cl
    da12:	0f 84 38 0c 00 00    	je     e650 <f0+0x2af0>
    da18:	80 f9 01             	cmp    $0x1,%cl
    da1b:	75 29                	jne    da46 <f0+0x1ee6>
    da1d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    da20:	0f b7 c0             	movzwl %ax,%eax
    da23:	8b 52 1c             	mov    0x1c(%rdx),%edx
    da26:	48 0f af c1          	imul   %rcx,%rax
    da2a:	48 c1 e8 20          	shr    $0x20,%rax
    da2e:	48 39 d0             	cmp    %rdx,%rax
    da31:	73 13                	jae    da46 <f0+0x1ee6>
    da33:	49 01 c4             	add    %rax,%r12
    da36:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    da3b:	0f 84 55 0d 00 00    	je     e796 <f0+0x2c36>
    da41:	41 c6 04 24 01       	movb   $0x1,(%r12)
    da46:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    da4d:	33 f3 bf 
    da50:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    da57:	00 
    da58:	bf 01 00 00 00       	mov    $0x1,%edi
    da5d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    da64:	00 
    da65:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    da6c:	00 
    da6d:	e8 ce 8d ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    da72:	48 8b 15 9f 01 06 00 	mov    0x6019f(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    da79:	49 89 c5             	mov    %rax,%r13
    da7c:	48 2b 05 6d 01 06 00 	sub    0x6016d(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    da83:	48 c1 e2 10          	shl    $0x10,%rdx
    da87:	48 39 d0             	cmp    %rdx,%rax
    da8a:	73 59                	jae    dae5 <f0+0x1f85>
    da8c:	48 89 c2             	mov    %rax,%rdx
    da8f:	48 c1 ea 10          	shr    $0x10,%rdx
    da93:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    da97:	48 8b 15 9a 01 06 00 	mov    0x6019a(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    da9e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    daa2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    daa6:	4d 85 e4             	test   %r12,%r12
    daa9:	74 3a                	je     dae5 <f0+0x1f85>
    daab:	0f b6 0a             	movzbl (%rdx),%ecx
    daae:	80 f9 02             	cmp    $0x2,%cl
    dab1:	0f 84 89 0b 00 00    	je     e640 <f0+0x2ae0>
    dab7:	80 f9 01             	cmp    $0x1,%cl
    daba:	75 29                	jne    dae5 <f0+0x1f85>
    dabc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dabf:	0f b7 c0             	movzwl %ax,%eax
    dac2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dac5:	48 0f af c1          	imul   %rcx,%rax
    dac9:	48 c1 e8 20          	shr    $0x20,%rax
    dacd:	48 39 d0             	cmp    %rdx,%rax
    dad0:	73 13                	jae    dae5 <f0+0x1f85>
    dad2:	49 01 c4             	add    %rax,%r12
    dad5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dada:	0f 84 c3 0c 00 00    	je     e7a3 <f0+0x2c43>
    dae0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dae5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    daec:	00 f0 3f 
    daef:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    daf6:	00 
    daf7:	bf 01 00 00 00       	mov    $0x1,%edi
    dafc:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    db03:	00 
    db04:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    db0b:	00 
    db0c:	e8 2f 8d ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    db11:	48 8b 15 00 01 06 00 	mov    0x60100(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    db18:	49 89 c5             	mov    %rax,%r13
    db1b:	48 2b 05 ce 00 06 00 	sub    0x600ce(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    db22:	48 c1 e2 10          	shl    $0x10,%rdx
    db26:	48 39 d0             	cmp    %rdx,%rax
    db29:	73 59                	jae    db84 <f0+0x2024>
    db2b:	48 89 c2             	mov    %rax,%rdx
    db2e:	48 c1 ea 10          	shr    $0x10,%rdx
    db32:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    db36:	48 8b 15 fb 00 06 00 	mov    0x600fb(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    db3d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    db41:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    db45:	4d 85 e4             	test   %r12,%r12
    db48:	74 3a                	je     db84 <f0+0x2024>
    db4a:	0f b6 0a             	movzbl (%rdx),%ecx
    db4d:	80 f9 02             	cmp    $0x2,%cl
    db50:	0f 84 da 0a 00 00    	je     e630 <f0+0x2ad0>
    db56:	80 f9 01             	cmp    $0x1,%cl
    db59:	75 29                	jne    db84 <f0+0x2024>
    db5b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    db5e:	0f b7 c0             	movzwl %ax,%eax
    db61:	8b 52 1c             	mov    0x1c(%rdx),%edx
    db64:	48 0f af c1          	imul   %rcx,%rax
    db68:	48 c1 e8 20          	shr    $0x20,%rax
    db6c:	48 39 d0             	cmp    %rdx,%rax
    db6f:	73 13                	jae    db84 <f0+0x2024>
    db71:	49 01 c4             	add    %rax,%r12
    db74:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    db79:	0f 84 31 0c 00 00    	je     e7b0 <f0+0x2c50>
    db7f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    db84:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    db8b:	33 f3 bf 
    db8e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    db95:	00 
    db96:	bf 01 00 00 00       	mov    $0x1,%edi
    db9b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    dba2:	00 
    dba3:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    dbaa:	00 
    dbab:	e8 90 8c ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    dbb0:	48 8b 15 61 00 06 00 	mov    0x60061(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    dbb7:	49 89 c5             	mov    %rax,%r13
    dbba:	48 2b 05 2f 00 06 00 	sub    0x6002f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dbc1:	48 c1 e2 10          	shl    $0x10,%rdx
    dbc5:	48 39 d0             	cmp    %rdx,%rax
    dbc8:	73 59                	jae    dc23 <f0+0x20c3>
    dbca:	48 89 c2             	mov    %rax,%rdx
    dbcd:	48 c1 ea 10          	shr    $0x10,%rdx
    dbd1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dbd5:	48 8b 15 5c 00 06 00 	mov    0x6005c(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    dbdc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dbe0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dbe4:	4d 85 e4             	test   %r12,%r12
    dbe7:	74 3a                	je     dc23 <f0+0x20c3>
    dbe9:	0f b6 0a             	movzbl (%rdx),%ecx
    dbec:	80 f9 02             	cmp    $0x2,%cl
    dbef:	0f 84 2b 0a 00 00    	je     e620 <f0+0x2ac0>
    dbf5:	80 f9 01             	cmp    $0x1,%cl
    dbf8:	75 29                	jne    dc23 <f0+0x20c3>
    dbfa:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dbfd:	0f b7 c0             	movzwl %ax,%eax
    dc00:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dc03:	48 0f af c1          	imul   %rcx,%rax
    dc07:	48 c1 e8 20          	shr    $0x20,%rax
    dc0b:	48 39 d0             	cmp    %rdx,%rax
    dc0e:	73 13                	jae    dc23 <f0+0x20c3>
    dc10:	49 01 c4             	add    %rax,%r12
    dc13:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dc18:	0f 84 9f 0b 00 00    	je     e7bd <f0+0x2c5d>
    dc1e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dc23:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dc2a:	00 f0 3f 
    dc2d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    dc34:	00 
    dc35:	bf 01 00 00 00       	mov    $0x1,%edi
    dc3a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    dc41:	00 
    dc42:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    dc49:	00 
    dc4a:	e8 f1 8b ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    dc4f:	48 8b 15 c2 ff 05 00 	mov    0x5ffc2(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    dc56:	49 89 c5             	mov    %rax,%r13
    dc59:	48 2b 05 90 ff 05 00 	sub    0x5ff90(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dc60:	48 c1 e2 10          	shl    $0x10,%rdx
    dc64:	48 39 d0             	cmp    %rdx,%rax
    dc67:	73 59                	jae    dcc2 <f0+0x2162>
    dc69:	48 89 c2             	mov    %rax,%rdx
    dc6c:	48 c1 ea 10          	shr    $0x10,%rdx
    dc70:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dc74:	48 8b 15 bd ff 05 00 	mov    0x5ffbd(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    dc7b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dc7f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dc83:	4d 85 e4             	test   %r12,%r12
    dc86:	74 3a                	je     dcc2 <f0+0x2162>
    dc88:	0f b6 0a             	movzbl (%rdx),%ecx
    dc8b:	80 f9 02             	cmp    $0x2,%cl
    dc8e:	0f 84 7c 09 00 00    	je     e610 <f0+0x2ab0>
    dc94:	80 f9 01             	cmp    $0x1,%cl
    dc97:	75 29                	jne    dcc2 <f0+0x2162>
    dc99:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dc9c:	0f b7 c0             	movzwl %ax,%eax
    dc9f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dca2:	48 0f af c1          	imul   %rcx,%rax
    dca6:	48 c1 e8 20          	shr    $0x20,%rax
    dcaa:	48 39 d0             	cmp    %rdx,%rax
    dcad:	73 13                	jae    dcc2 <f0+0x2162>
    dcaf:	49 01 c4             	add    %rax,%r12
    dcb2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dcb7:	0f 84 0d 0b 00 00    	je     e7ca <f0+0x2c6a>
    dcbd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dcc2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dcc9:	33 f3 bf 
    dccc:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    dcd3:	00 
    dcd4:	bf 01 00 00 00       	mov    $0x1,%edi
    dcd9:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    dce0:	00 
    dce1:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    dce8:	00 
    dce9:	e8 52 8b ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    dcee:	48 8b 15 23 ff 05 00 	mov    0x5ff23(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    dcf5:	49 89 c5             	mov    %rax,%r13
    dcf8:	48 2b 05 f1 fe 05 00 	sub    0x5fef1(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dcff:	48 c1 e2 10          	shl    $0x10,%rdx
    dd03:	48 39 d0             	cmp    %rdx,%rax
    dd06:	73 59                	jae    dd61 <f0+0x2201>
    dd08:	48 89 c2             	mov    %rax,%rdx
    dd0b:	48 c1 ea 10          	shr    $0x10,%rdx
    dd0f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dd13:	48 8b 15 1e ff 05 00 	mov    0x5ff1e(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    dd1a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dd1e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dd22:	4d 85 e4             	test   %r12,%r12
    dd25:	74 3a                	je     dd61 <f0+0x2201>
    dd27:	0f b6 0a             	movzbl (%rdx),%ecx
    dd2a:	80 f9 02             	cmp    $0x2,%cl
    dd2d:	0f 84 cd 08 00 00    	je     e600 <f0+0x2aa0>
    dd33:	80 f9 01             	cmp    $0x1,%cl
    dd36:	75 29                	jne    dd61 <f0+0x2201>
    dd38:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dd3b:	0f b7 c0             	movzwl %ax,%eax
    dd3e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dd41:	48 0f af c1          	imul   %rcx,%rax
    dd45:	48 c1 e8 20          	shr    $0x20,%rax
    dd49:	48 39 d0             	cmp    %rdx,%rax
    dd4c:	73 13                	jae    dd61 <f0+0x2201>
    dd4e:	49 01 c4             	add    %rax,%r12
    dd51:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dd56:	0f 84 7b 0a 00 00    	je     e7d7 <f0+0x2c77>
    dd5c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dd61:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dd68:	00 f0 3f 
    dd6b:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    dd72:	00 
    dd73:	bf 01 00 00 00       	mov    $0x1,%edi
    dd78:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    dd7f:	00 
    dd80:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    dd87:	00 
    dd88:	e8 b3 8a ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    dd8d:	48 8b 15 84 fe 05 00 	mov    0x5fe84(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    dd94:	49 89 c5             	mov    %rax,%r13
    dd97:	48 2b 05 52 fe 05 00 	sub    0x5fe52(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dd9e:	48 c1 e2 10          	shl    $0x10,%rdx
    dda2:	48 39 d0             	cmp    %rdx,%rax
    dda5:	73 59                	jae    de00 <f0+0x22a0>
    dda7:	48 89 c2             	mov    %rax,%rdx
    ddaa:	48 c1 ea 10          	shr    $0x10,%rdx
    ddae:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ddb2:	48 8b 15 7f fe 05 00 	mov    0x5fe7f(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    ddb9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ddbd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ddc1:	4d 85 e4             	test   %r12,%r12
    ddc4:	74 3a                	je     de00 <f0+0x22a0>
    ddc6:	0f b6 0a             	movzbl (%rdx),%ecx
    ddc9:	80 f9 02             	cmp    $0x2,%cl
    ddcc:	0f 84 1e 08 00 00    	je     e5f0 <f0+0x2a90>
    ddd2:	80 f9 01             	cmp    $0x1,%cl
    ddd5:	75 29                	jne    de00 <f0+0x22a0>
    ddd7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ddda:	0f b7 c0             	movzwl %ax,%eax
    dddd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dde0:	48 0f af c1          	imul   %rcx,%rax
    dde4:	48 c1 e8 20          	shr    $0x20,%rax
    dde8:	48 39 d0             	cmp    %rdx,%rax
    ddeb:	73 13                	jae    de00 <f0+0x22a0>
    dded:	49 01 c4             	add    %rax,%r12
    ddf0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ddf5:	0f 84 e9 09 00 00    	je     e7e4 <f0+0x2c84>
    ddfb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    de00:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    de07:	33 f3 bf 
    de0a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    de11:	00 
    de12:	bf 01 00 00 00       	mov    $0x1,%edi
    de17:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    de1e:	00 
    de1f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    de26:	00 
    de27:	e8 14 8a ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    de2c:	48 8b 15 e5 fd 05 00 	mov    0x5fde5(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    de33:	49 89 c5             	mov    %rax,%r13
    de36:	48 2b 05 b3 fd 05 00 	sub    0x5fdb3(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    de3d:	48 c1 e2 10          	shl    $0x10,%rdx
    de41:	48 39 d0             	cmp    %rdx,%rax
    de44:	73 59                	jae    de9f <f0+0x233f>
    de46:	48 89 c2             	mov    %rax,%rdx
    de49:	48 c1 ea 10          	shr    $0x10,%rdx
    de4d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    de51:	48 8b 15 e0 fd 05 00 	mov    0x5fde0(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    de58:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    de5c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    de60:	4d 85 e4             	test   %r12,%r12
    de63:	74 3a                	je     de9f <f0+0x233f>
    de65:	0f b6 0a             	movzbl (%rdx),%ecx
    de68:	80 f9 02             	cmp    $0x2,%cl
    de6b:	0f 84 6f 07 00 00    	je     e5e0 <f0+0x2a80>
    de71:	80 f9 01             	cmp    $0x1,%cl
    de74:	75 29                	jne    de9f <f0+0x233f>
    de76:	8b 4a 18             	mov    0x18(%rdx),%ecx
    de79:	0f b7 c0             	movzwl %ax,%eax
    de7c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    de7f:	48 0f af c1          	imul   %rcx,%rax
    de83:	48 c1 e8 20          	shr    $0x20,%rax
    de87:	48 39 d0             	cmp    %rdx,%rax
    de8a:	73 13                	jae    de9f <f0+0x233f>
    de8c:	49 01 c4             	add    %rax,%r12
    de8f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    de94:	0f 84 57 09 00 00    	je     e7f1 <f0+0x2c91>
    de9a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    de9f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dea6:	00 f0 3f 
    dea9:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    deb0:	00 
    deb1:	bf 01 00 00 00       	mov    $0x1,%edi
    deb6:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    debd:	00 
    debe:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    dec5:	00 
    dec6:	e8 75 89 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    decb:	48 8b 15 46 fd 05 00 	mov    0x5fd46(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    ded2:	49 89 c5             	mov    %rax,%r13
    ded5:	48 2b 05 14 fd 05 00 	sub    0x5fd14(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dedc:	48 c1 e2 10          	shl    $0x10,%rdx
    dee0:	48 39 d0             	cmp    %rdx,%rax
    dee3:	73 59                	jae    df3e <f0+0x23de>
    dee5:	48 89 c2             	mov    %rax,%rdx
    dee8:	48 c1 ea 10          	shr    $0x10,%rdx
    deec:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    def0:	48 8b 15 41 fd 05 00 	mov    0x5fd41(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    def7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    defb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    deff:	4d 85 e4             	test   %r12,%r12
    df02:	74 3a                	je     df3e <f0+0x23de>
    df04:	0f b6 0a             	movzbl (%rdx),%ecx
    df07:	80 f9 02             	cmp    $0x2,%cl
    df0a:	0f 84 c0 06 00 00    	je     e5d0 <f0+0x2a70>
    df10:	80 f9 01             	cmp    $0x1,%cl
    df13:	75 29                	jne    df3e <f0+0x23de>
    df15:	8b 4a 18             	mov    0x18(%rdx),%ecx
    df18:	0f b7 c0             	movzwl %ax,%eax
    df1b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    df1e:	48 0f af c1          	imul   %rcx,%rax
    df22:	48 c1 e8 20          	shr    $0x20,%rax
    df26:	48 39 d0             	cmp    %rdx,%rax
    df29:	73 13                	jae    df3e <f0+0x23de>
    df2b:	49 01 c4             	add    %rax,%r12
    df2e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    df33:	0f 84 c5 08 00 00    	je     e7fe <f0+0x2c9e>
    df39:	41 c6 04 24 01       	movb   $0x1,(%r12)
    df3e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    df45:	33 f3 bf 
    df48:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    df4f:	00 
    df50:	bf 01 00 00 00       	mov    $0x1,%edi
    df55:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    df5c:	00 
    df5d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    df64:	00 
    df65:	e8 d6 88 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    df6a:	48 8b 15 a7 fc 05 00 	mov    0x5fca7(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    df71:	49 89 c5             	mov    %rax,%r13
    df74:	48 2b 05 75 fc 05 00 	sub    0x5fc75(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    df7b:	48 c1 e2 10          	shl    $0x10,%rdx
    df7f:	48 39 d0             	cmp    %rdx,%rax
    df82:	73 59                	jae    dfdd <f0+0x247d>
    df84:	48 89 c2             	mov    %rax,%rdx
    df87:	48 c1 ea 10          	shr    $0x10,%rdx
    df8b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    df8f:	48 8b 15 a2 fc 05 00 	mov    0x5fca2(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    df96:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    df9a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    df9e:	4d 85 e4             	test   %r12,%r12
    dfa1:	74 3a                	je     dfdd <f0+0x247d>
    dfa3:	0f b6 0a             	movzbl (%rdx),%ecx
    dfa6:	80 f9 02             	cmp    $0x2,%cl
    dfa9:	0f 84 11 06 00 00    	je     e5c0 <f0+0x2a60>
    dfaf:	80 f9 01             	cmp    $0x1,%cl
    dfb2:	75 29                	jne    dfdd <f0+0x247d>
    dfb4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dfb7:	0f b7 c0             	movzwl %ax,%eax
    dfba:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dfbd:	48 0f af c1          	imul   %rcx,%rax
    dfc1:	48 c1 e8 20          	shr    $0x20,%rax
    dfc5:	48 39 d0             	cmp    %rdx,%rax
    dfc8:	73 13                	jae    dfdd <f0+0x247d>
    dfca:	49 01 c4             	add    %rax,%r12
    dfcd:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dfd2:	0f 84 33 08 00 00    	je     e80b <f0+0x2cab>
    dfd8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dfdd:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dfe4:	00 f0 3f 
    dfe7:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    dfee:	00 
    dfef:	bf 01 00 00 00       	mov    $0x1,%edi
    dff4:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    dffb:	00 
    dffc:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    e003:	00 
    e004:	e8 37 88 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    e009:	48 8b 15 08 fc 05 00 	mov    0x5fc08(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e010:	49 89 c5             	mov    %rax,%r13
    e013:	48 2b 05 d6 fb 05 00 	sub    0x5fbd6(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e01a:	48 c1 e2 10          	shl    $0x10,%rdx
    e01e:	48 39 d0             	cmp    %rdx,%rax
    e021:	73 59                	jae    e07c <f0+0x251c>
    e023:	48 89 c2             	mov    %rax,%rdx
    e026:	48 c1 ea 10          	shr    $0x10,%rdx
    e02a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e02e:	48 8b 15 03 fc 05 00 	mov    0x5fc03(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e035:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e039:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e03d:	4d 85 e4             	test   %r12,%r12
    e040:	74 3a                	je     e07c <f0+0x251c>
    e042:	0f b6 0a             	movzbl (%rdx),%ecx
    e045:	80 f9 02             	cmp    $0x2,%cl
    e048:	0f 84 62 05 00 00    	je     e5b0 <f0+0x2a50>
    e04e:	80 f9 01             	cmp    $0x1,%cl
    e051:	75 29                	jne    e07c <f0+0x251c>
    e053:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e056:	0f b7 c0             	movzwl %ax,%eax
    e059:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e05c:	48 0f af c1          	imul   %rcx,%rax
    e060:	48 c1 e8 20          	shr    $0x20,%rax
    e064:	48 39 d0             	cmp    %rdx,%rax
    e067:	73 13                	jae    e07c <f0+0x251c>
    e069:	49 01 c4             	add    %rax,%r12
    e06c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e071:	0f 84 a1 07 00 00    	je     e818 <f0+0x2cb8>
    e077:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e07c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e083:	33 f3 bf 
    e086:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    e08d:	00 
    e08e:	bf 01 00 00 00       	mov    $0x1,%edi
    e093:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    e09a:	00 
    e09b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    e0a2:	00 
    e0a3:	e8 98 87 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    e0a8:	48 8b 15 69 fb 05 00 	mov    0x5fb69(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e0af:	49 89 c5             	mov    %rax,%r13
    e0b2:	48 2b 05 37 fb 05 00 	sub    0x5fb37(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e0b9:	48 c1 e2 10          	shl    $0x10,%rdx
    e0bd:	48 39 d0             	cmp    %rdx,%rax
    e0c0:	73 59                	jae    e11b <f0+0x25bb>
    e0c2:	48 89 c2             	mov    %rax,%rdx
    e0c5:	48 c1 ea 10          	shr    $0x10,%rdx
    e0c9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e0cd:	48 8b 15 64 fb 05 00 	mov    0x5fb64(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e0d4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e0d8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e0dc:	4d 85 e4             	test   %r12,%r12
    e0df:	74 3a                	je     e11b <f0+0x25bb>
    e0e1:	0f b6 0a             	movzbl (%rdx),%ecx
    e0e4:	80 f9 02             	cmp    $0x2,%cl
    e0e7:	0f 84 b3 04 00 00    	je     e5a0 <f0+0x2a40>
    e0ed:	80 f9 01             	cmp    $0x1,%cl
    e0f0:	75 29                	jne    e11b <f0+0x25bb>
    e0f2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e0f5:	0f b7 c0             	movzwl %ax,%eax
    e0f8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e0fb:	48 0f af c1          	imul   %rcx,%rax
    e0ff:	48 c1 e8 20          	shr    $0x20,%rax
    e103:	48 39 d0             	cmp    %rdx,%rax
    e106:	73 13                	jae    e11b <f0+0x25bb>
    e108:	49 01 c4             	add    %rax,%r12
    e10b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e110:	0f 84 0f 07 00 00    	je     e825 <f0+0x2cc5>
    e116:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e11b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    e122:	00 f0 3f 
    e125:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    e12c:	00 
    e12d:	bf 01 00 00 00       	mov    $0x1,%edi
    e132:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    e139:	00 
    e13a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    e141:	00 
    e142:	e8 f9 86 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    e147:	48 8b 15 ca fa 05 00 	mov    0x5faca(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e14e:	49 89 c5             	mov    %rax,%r13
    e151:	48 2b 05 98 fa 05 00 	sub    0x5fa98(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e158:	48 c1 e2 10          	shl    $0x10,%rdx
    e15c:	48 39 d0             	cmp    %rdx,%rax
    e15f:	73 59                	jae    e1ba <f0+0x265a>
    e161:	48 89 c2             	mov    %rax,%rdx
    e164:	48 c1 ea 10          	shr    $0x10,%rdx
    e168:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e16c:	48 8b 15 c5 fa 05 00 	mov    0x5fac5(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e173:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e177:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e17b:	4d 85 e4             	test   %r12,%r12
    e17e:	74 3a                	je     e1ba <f0+0x265a>
    e180:	0f b6 0a             	movzbl (%rdx),%ecx
    e183:	80 f9 02             	cmp    $0x2,%cl
    e186:	0f 84 04 04 00 00    	je     e590 <f0+0x2a30>
    e18c:	80 f9 01             	cmp    $0x1,%cl
    e18f:	75 29                	jne    e1ba <f0+0x265a>
    e191:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e194:	0f b7 c0             	movzwl %ax,%eax
    e197:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e19a:	48 0f af c1          	imul   %rcx,%rax
    e19e:	48 c1 e8 20          	shr    $0x20,%rax
    e1a2:	48 39 d0             	cmp    %rdx,%rax
    e1a5:	73 13                	jae    e1ba <f0+0x265a>
    e1a7:	49 01 c4             	add    %rax,%r12
    e1aa:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e1af:	0f 84 7d 06 00 00    	je     e832 <f0+0x2cd2>
    e1b5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e1ba:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e1c1:	33 f3 bf 
    e1c4:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    e1cb:	00 
    e1cc:	bf 01 00 00 00       	mov    $0x1,%edi
    e1d1:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    e1d8:	00 
    e1d9:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    e1e0:	00 
    e1e1:	e8 5a 86 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    e1e6:	48 8b 15 2b fa 05 00 	mov    0x5fa2b(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e1ed:	49 89 c5             	mov    %rax,%r13
    e1f0:	48 2b 05 f9 f9 05 00 	sub    0x5f9f9(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e1f7:	48 c1 e2 10          	shl    $0x10,%rdx
    e1fb:	48 39 d0             	cmp    %rdx,%rax
    e1fe:	73 59                	jae    e259 <f0+0x26f9>
    e200:	48 89 c2             	mov    %rax,%rdx
    e203:	48 c1 ea 10          	shr    $0x10,%rdx
    e207:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e20b:	48 8b 15 26 fa 05 00 	mov    0x5fa26(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e212:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e216:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e21a:	4d 85 e4             	test   %r12,%r12
    e21d:	74 3a                	je     e259 <f0+0x26f9>
    e21f:	0f b6 0a             	movzbl (%rdx),%ecx
    e222:	80 f9 02             	cmp    $0x2,%cl
    e225:	0f 84 55 03 00 00    	je     e580 <f0+0x2a20>
    e22b:	80 f9 01             	cmp    $0x1,%cl
    e22e:	75 29                	jne    e259 <f0+0x26f9>
    e230:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e233:	0f b7 c0             	movzwl %ax,%eax
    e236:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e239:	48 0f af c1          	imul   %rcx,%rax
    e23d:	48 c1 e8 20          	shr    $0x20,%rax
    e241:	48 39 d0             	cmp    %rdx,%rax
    e244:	73 13                	jae    e259 <f0+0x26f9>
    e246:	49 01 c4             	add    %rax,%r12
    e249:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e24e:	0f 84 eb 05 00 00    	je     e83f <f0+0x2cdf>
    e254:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e259:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    e260:	00 f0 3f 
    e263:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    e26a:	00 
    e26b:	bf 01 00 00 00       	mov    $0x1,%edi
    e270:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    e277:	00 
    e278:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    e27f:	00 
    e280:	e8 bb 85 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    e285:	48 8b 15 8c f9 05 00 	mov    0x5f98c(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e28c:	49 89 c5             	mov    %rax,%r13
    e28f:	48 2b 05 5a f9 05 00 	sub    0x5f95a(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e296:	48 c1 e2 10          	shl    $0x10,%rdx
    e29a:	48 39 d0             	cmp    %rdx,%rax
    e29d:	73 59                	jae    e2f8 <f0+0x2798>
    e29f:	48 89 c2             	mov    %rax,%rdx
    e2a2:	48 c1 ea 10          	shr    $0x10,%rdx
    e2a6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e2aa:	48 8b 15 87 f9 05 00 	mov    0x5f987(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e2b1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e2b5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e2b9:	4d 85 e4             	test   %r12,%r12
    e2bc:	74 3a                	je     e2f8 <f0+0x2798>
    e2be:	0f b6 0a             	movzbl (%rdx),%ecx
    e2c1:	80 f9 02             	cmp    $0x2,%cl
    e2c4:	0f 84 a6 02 00 00    	je     e570 <f0+0x2a10>
    e2ca:	80 f9 01             	cmp    $0x1,%cl
    e2cd:	75 29                	jne    e2f8 <f0+0x2798>
    e2cf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e2d2:	0f b7 c0             	movzwl %ax,%eax
    e2d5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e2d8:	48 0f af c1          	imul   %rcx,%rax
    e2dc:	48 c1 e8 20          	shr    $0x20,%rax
    e2e0:	48 39 d0             	cmp    %rdx,%rax
    e2e3:	73 13                	jae    e2f8 <f0+0x2798>
    e2e5:	49 01 c4             	add    %rax,%r12
    e2e8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e2ed:	0f 84 59 05 00 00    	je     e84c <f0+0x2cec>
    e2f3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e2f8:	48 89 ee             	mov    %rbp,%rsi
    e2fb:	bf 01 00 00 00       	mov    $0x1,%edi
    e300:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e307:	33 f3 bf 
    e30a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    e311:	00 
    e312:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    e319:	00 
    e31a:	e8 21 85 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    e31f:	48 8b 15 f2 f8 05 00 	mov    0x5f8f2(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e326:	48 89 c5             	mov    %rax,%rbp
    e329:	48 2b 05 c0 f8 05 00 	sub    0x5f8c0(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e330:	48 c1 e2 10          	shl    $0x10,%rdx
    e334:	48 39 d0             	cmp    %rdx,%rax
    e337:	73 59                	jae    e392 <f0+0x2832>
    e339:	48 89 c2             	mov    %rax,%rdx
    e33c:	48 c1 ea 10          	shr    $0x10,%rdx
    e340:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e344:	48 8b 15 ed f8 05 00 	mov    0x5f8ed(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e34b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e34f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e353:	4d 85 e4             	test   %r12,%r12
    e356:	74 3a                	je     e392 <f0+0x2832>
    e358:	0f b6 0a             	movzbl (%rdx),%ecx
    e35b:	80 f9 02             	cmp    $0x2,%cl
    e35e:	0f 84 fc 01 00 00    	je     e560 <f0+0x2a00>
    e364:	80 f9 01             	cmp    $0x1,%cl
    e367:	75 29                	jne    e392 <f0+0x2832>
    e369:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e36c:	0f b7 c0             	movzwl %ax,%eax
    e36f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e372:	48 0f af c1          	imul   %rcx,%rax
    e376:	48 c1 e8 20          	shr    $0x20,%rax
    e37a:	48 39 d0             	cmp    %rdx,%rax
    e37d:	73 13                	jae    e392 <f0+0x2832>
    e37f:	49 01 c4             	add    %rax,%r12
    e382:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e387:	0f 84 d1 02 00 00    	je     e65e <f0+0x2afe>
    e38d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e392:	48 89 de             	mov    %rbx,%rsi
    e395:	48 89 ef             	mov    %rbp,%rdi
    e398:	e8 03 ca ff ff       	call   ada0 <fwp_hof0.constprop.0>
    e39d:	48 89 ef             	mov    %rbp,%rdi
    e3a0:	e8 eb 8a ff ff       	call   6e90 <fwp_drop0>
    e3a5:	48 89 df             	mov    %rbx,%rdi
    e3a8:	e8 e3 8a ff ff       	call   6e90 <fwp_drop0>
    e3ad:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    e3b4:	00 
    e3b5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e3bc:	00 00 
    e3be:	0f 85 95 04 00 00    	jne    e859 <f0+0x2cf9>
    e3c4:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    e3cb:	31 c0                	xor    %eax,%eax
    e3cd:	5b                   	pop    %rbx
    e3ce:	5d                   	pop    %rbp
    e3cf:	41 5c                	pop    %r12
    e3d1:	41 5d                	pop    %r13
    e3d3:	41 5e                	pop    %r14
    e3d5:	c3                   	ret
    e3d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e3dd:	00 00 00 
    e3e0:	4c 89 ef             	mov    %r13,%rdi
    e3e3:	e8 e8 73 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e3e8:	e9 2c d8 ff ff       	jmp    bc19 <f0+0xb9>
    e3ed:	0f 1f 00             	nopl   (%rax)
    e3f0:	66 85 c0             	test   %ax,%ax
    e3f3:	0f 85 ae f5 ff ff    	jne    d9a7 <f0+0x1e47>
    e3f9:	e9 99 f5 ff ff       	jmp    d997 <f0+0x1e37>
    e3fe:	66 90                	xchg   %ax,%ax
    e400:	66 85 c0             	test   %ax,%ax
    e403:	0f 85 ff f4 ff ff    	jne    d908 <f0+0x1da8>
    e409:	e9 ea f4 ff ff       	jmp    d8f8 <f0+0x1d98>
    e40e:	66 90                	xchg   %ax,%ax
    e410:	66 85 c0             	test   %ax,%ax
    e413:	0f 85 50 f4 ff ff    	jne    d869 <f0+0x1d09>
    e419:	e9 3b f4 ff ff       	jmp    d859 <f0+0x1cf9>
    e41e:	66 90                	xchg   %ax,%ax
    e420:	66 85 c0             	test   %ax,%ax
    e423:	0f 85 a1 f3 ff ff    	jne    d7ca <f0+0x1c6a>
    e429:	e9 8c f3 ff ff       	jmp    d7ba <f0+0x1c5a>
    e42e:	66 90                	xchg   %ax,%ax
    e430:	66 85 c0             	test   %ax,%ax
    e433:	0f 85 f2 f2 ff ff    	jne    d72b <f0+0x1bcb>
    e439:	e9 dd f2 ff ff       	jmp    d71b <f0+0x1bbb>
    e43e:	66 90                	xchg   %ax,%ax
    e440:	66 85 c0             	test   %ax,%ax
    e443:	0f 85 43 f2 ff ff    	jne    d68c <f0+0x1b2c>
    e449:	e9 2e f2 ff ff       	jmp    d67c <f0+0x1b1c>
    e44e:	66 90                	xchg   %ax,%ax
    e450:	66 85 c0             	test   %ax,%ax
    e453:	0f 85 94 f1 ff ff    	jne    d5ed <f0+0x1a8d>
    e459:	e9 7f f1 ff ff       	jmp    d5dd <f0+0x1a7d>
    e45e:	66 90                	xchg   %ax,%ax
    e460:	66 85 c0             	test   %ax,%ax
    e463:	0f 85 e5 f0 ff ff    	jne    d54e <f0+0x19ee>
    e469:	e9 d0 f0 ff ff       	jmp    d53e <f0+0x19de>
    e46e:	66 90                	xchg   %ax,%ax
    e470:	66 85 c0             	test   %ax,%ax
    e473:	0f 85 fd d9 ff ff    	jne    be76 <f0+0x316>
    e479:	e9 e8 d9 ff ff       	jmp    be66 <f0+0x306>
    e47e:	66 90                	xchg   %ax,%ax
    e480:	66 85 c0             	test   %ax,%ax
    e483:	0f 85 57 d9 ff ff    	jne    bde0 <f0+0x280>
    e489:	e9 42 d9 ff ff       	jmp    bdd0 <f0+0x270>
    e48e:	66 90                	xchg   %ax,%ax
    e490:	66 85 c0             	test   %ax,%ax
    e493:	0f 85 b1 d8 ff ff    	jne    bd4a <f0+0x1ea>
    e499:	e9 9c d8 ff ff       	jmp    bd3a <f0+0x1da>
    e49e:	66 90                	xchg   %ax,%ax
    e4a0:	66 85 c0             	test   %ax,%ax
    e4a3:	0f 85 0e eb ff ff    	jne    cfb7 <f0+0x1457>
    e4a9:	e9 f9 ea ff ff       	jmp    cfa7 <f0+0x1447>
    e4ae:	66 90                	xchg   %ax,%ax
    e4b0:	66 85 c0             	test   %ax,%ax
    e4b3:	0f 85 91 db ff ff    	jne    c04a <f0+0x4ea>
    e4b9:	e9 7c db ff ff       	jmp    c03a <f0+0x4da>
    e4be:	66 90                	xchg   %ax,%ax
    e4c0:	66 85 c0             	test   %ax,%ax
    e4c3:	0f 85 e2 da ff ff    	jne    bfab <f0+0x44b>
    e4c9:	e9 cd da ff ff       	jmp    bf9b <f0+0x43b>
    e4ce:	66 90                	xchg   %ax,%ax
    e4d0:	66 85 c0             	test   %ax,%ax
    e4d3:	0f 85 33 da ff ff    	jne    bf0c <f0+0x3ac>
    e4d9:	e9 1e da ff ff       	jmp    befc <f0+0x39c>
    e4de:	66 90                	xchg   %ax,%ax
    e4e0:	66 85 c0             	test   %ax,%ax
    e4e3:	0f 85 c6 ef ff ff    	jne    d4af <f0+0x194f>
    e4e9:	e9 b1 ef ff ff       	jmp    d49f <f0+0x193f>
    e4ee:	66 90                	xchg   %ax,%ax
    e4f0:	66 85 c0             	test   %ax,%ax
    e4f3:	0f 85 17 ef ff ff    	jne    d410 <f0+0x18b0>
    e4f9:	e9 02 ef ff ff       	jmp    d400 <f0+0x18a0>
    e4fe:	66 90                	xchg   %ax,%ax
    e500:	66 85 c0             	test   %ax,%ax
    e503:	0f 85 68 ee ff ff    	jne    d371 <f0+0x1811>
    e509:	e9 53 ee ff ff       	jmp    d361 <f0+0x1801>
    e50e:	66 90                	xchg   %ax,%ax
    e510:	66 85 c0             	test   %ax,%ax
    e513:	0f 85 b9 ed ff ff    	jne    d2d2 <f0+0x1772>
    e519:	e9 a4 ed ff ff       	jmp    d2c2 <f0+0x1762>
    e51e:	66 90                	xchg   %ax,%ax
    e520:	66 85 c0             	test   %ax,%ax
    e523:	0f 85 0a ed ff ff    	jne    d233 <f0+0x16d3>
    e529:	e9 f5 ec ff ff       	jmp    d223 <f0+0x16c3>
    e52e:	66 90                	xchg   %ax,%ax
    e530:	66 85 c0             	test   %ax,%ax
    e533:	0f 85 5b ec ff ff    	jne    d194 <f0+0x1634>
    e539:	e9 46 ec ff ff       	jmp    d184 <f0+0x1624>
    e53e:	66 90                	xchg   %ax,%ax
    e540:	66 85 c0             	test   %ax,%ax
    e543:	0f 85 ac eb ff ff    	jne    d0f5 <f0+0x1595>
    e549:	e9 97 eb ff ff       	jmp    d0e5 <f0+0x1585>
    e54e:	66 90                	xchg   %ax,%ax
    e550:	66 85 c0             	test   %ax,%ax
    e553:	0f 85 fd ea ff ff    	jne    d056 <f0+0x14f6>
    e559:	e9 e8 ea ff ff       	jmp    d046 <f0+0x14e6>
    e55e:	66 90                	xchg   %ax,%ax
    e560:	66 85 c0             	test   %ax,%ax
    e563:	0f 85 29 fe ff ff    	jne    e392 <f0+0x2832>
    e569:	e9 14 fe ff ff       	jmp    e382 <f0+0x2822>
    e56e:	66 90                	xchg   %ax,%ax
    e570:	66 85 c0             	test   %ax,%ax
    e573:	0f 85 7f fd ff ff    	jne    e2f8 <f0+0x2798>
    e579:	e9 6a fd ff ff       	jmp    e2e8 <f0+0x2788>
    e57e:	66 90                	xchg   %ax,%ax
    e580:	66 85 c0             	test   %ax,%ax
    e583:	0f 85 d0 fc ff ff    	jne    e259 <f0+0x26f9>
    e589:	e9 bb fc ff ff       	jmp    e249 <f0+0x26e9>
    e58e:	66 90                	xchg   %ax,%ax
    e590:	66 85 c0             	test   %ax,%ax
    e593:	0f 85 21 fc ff ff    	jne    e1ba <f0+0x265a>
    e599:	e9 0c fc ff ff       	jmp    e1aa <f0+0x264a>
    e59e:	66 90                	xchg   %ax,%ax
    e5a0:	66 85 c0             	test   %ax,%ax
    e5a3:	0f 85 72 fb ff ff    	jne    e11b <f0+0x25bb>
    e5a9:	e9 5d fb ff ff       	jmp    e10b <f0+0x25ab>
    e5ae:	66 90                	xchg   %ax,%ax
    e5b0:	66 85 c0             	test   %ax,%ax
    e5b3:	0f 85 c3 fa ff ff    	jne    e07c <f0+0x251c>
    e5b9:	e9 ae fa ff ff       	jmp    e06c <f0+0x250c>
    e5be:	66 90                	xchg   %ax,%ax
    e5c0:	66 85 c0             	test   %ax,%ax
    e5c3:	0f 85 14 fa ff ff    	jne    dfdd <f0+0x247d>
    e5c9:	e9 ff f9 ff ff       	jmp    dfcd <f0+0x246d>
    e5ce:	66 90                	xchg   %ax,%ax
    e5d0:	66 85 c0             	test   %ax,%ax
    e5d3:	0f 85 65 f9 ff ff    	jne    df3e <f0+0x23de>
    e5d9:	e9 50 f9 ff ff       	jmp    df2e <f0+0x23ce>
    e5de:	66 90                	xchg   %ax,%ax
    e5e0:	66 85 c0             	test   %ax,%ax
    e5e3:	0f 85 b6 f8 ff ff    	jne    de9f <f0+0x233f>
    e5e9:	e9 a1 f8 ff ff       	jmp    de8f <f0+0x232f>
    e5ee:	66 90                	xchg   %ax,%ax
    e5f0:	66 85 c0             	test   %ax,%ax
    e5f3:	0f 85 07 f8 ff ff    	jne    de00 <f0+0x22a0>
    e5f9:	e9 f2 f7 ff ff       	jmp    ddf0 <f0+0x2290>
    e5fe:	66 90                	xchg   %ax,%ax
    e600:	66 85 c0             	test   %ax,%ax
    e603:	0f 85 58 f7 ff ff    	jne    dd61 <f0+0x2201>
    e609:	e9 43 f7 ff ff       	jmp    dd51 <f0+0x21f1>
    e60e:	66 90                	xchg   %ax,%ax
    e610:	66 85 c0             	test   %ax,%ax
    e613:	0f 85 a9 f6 ff ff    	jne    dcc2 <f0+0x2162>
    e619:	e9 94 f6 ff ff       	jmp    dcb2 <f0+0x2152>
    e61e:	66 90                	xchg   %ax,%ax
    e620:	66 85 c0             	test   %ax,%ax
    e623:	0f 85 fa f5 ff ff    	jne    dc23 <f0+0x20c3>
    e629:	e9 e5 f5 ff ff       	jmp    dc13 <f0+0x20b3>
    e62e:	66 90                	xchg   %ax,%ax
    e630:	66 85 c0             	test   %ax,%ax
    e633:	0f 85 4b f5 ff ff    	jne    db84 <f0+0x2024>
    e639:	e9 36 f5 ff ff       	jmp    db74 <f0+0x2014>
    e63e:	66 90                	xchg   %ax,%ax
    e640:	66 85 c0             	test   %ax,%ax
    e643:	0f 85 9c f4 ff ff    	jne    dae5 <f0+0x1f85>
    e649:	e9 87 f4 ff ff       	jmp    dad5 <f0+0x1f75>
    e64e:	66 90                	xchg   %ax,%ax
    e650:	66 85 c0             	test   %ax,%ax
    e653:	0f 85 ed f3 ff ff    	jne    da46 <f0+0x1ee6>
    e659:	e9 d8 f3 ff ff       	jmp    da36 <f0+0x1ed6>
    e65e:	4c 89 e7             	mov    %r12,%rdi
    e661:	e8 6a 71 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e666:	e9 22 fd ff ff       	jmp    e38d <f0+0x282d>
    e66b:	4c 89 e7             	mov    %r12,%rdi
    e66e:	e8 5d 71 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e673:	e9 cd d6 ff ff       	jmp    bd45 <f0+0x1e5>
    e678:	4c 89 e7             	mov    %r12,%rdi
    e67b:	e8 50 71 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e680:	e9 56 d7 ff ff       	jmp    bddb <f0+0x27b>
    e685:	4c 89 e7             	mov    %r12,%rdi
    e688:	e8 43 71 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e68d:	e9 df d7 ff ff       	jmp    be71 <f0+0x311>
    e692:	4c 89 e7             	mov    %r12,%rdi
    e695:	e8 36 71 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e69a:	e9 68 d8 ff ff       	jmp    bf07 <f0+0x3a7>
    e69f:	4c 89 e7             	mov    %r12,%rdi
    e6a2:	e8 29 71 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e6a7:	e9 fa d8 ff ff       	jmp    bfa6 <f0+0x446>
    e6ac:	4c 89 e7             	mov    %r12,%rdi
    e6af:	e8 1c 71 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e6b4:	e9 8c d9 ff ff       	jmp    c045 <f0+0x4e5>
    e6b9:	4c 89 e7             	mov    %r12,%rdi
    e6bc:	e8 0f 71 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e6c1:	e9 ec e8 ff ff       	jmp    cfb2 <f0+0x1452>
    e6c6:	4c 89 e7             	mov    %r12,%rdi
    e6c9:	e8 02 71 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e6ce:	e9 7e e9 ff ff       	jmp    d051 <f0+0x14f1>
    e6d3:	4c 89 e7             	mov    %r12,%rdi
    e6d6:	e8 f5 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e6db:	e9 10 ea ff ff       	jmp    d0f0 <f0+0x1590>
    e6e0:	4c 89 e7             	mov    %r12,%rdi
    e6e3:	e8 e8 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e6e8:	e9 a2 ea ff ff       	jmp    d18f <f0+0x162f>
    e6ed:	4c 89 e7             	mov    %r12,%rdi
    e6f0:	e8 db 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e6f5:	e9 34 eb ff ff       	jmp    d22e <f0+0x16ce>
    e6fa:	4c 89 e7             	mov    %r12,%rdi
    e6fd:	e8 ce 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e702:	e9 c6 eb ff ff       	jmp    d2cd <f0+0x176d>
    e707:	4c 89 e7             	mov    %r12,%rdi
    e70a:	e8 c1 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e70f:	e9 58 ec ff ff       	jmp    d36c <f0+0x180c>
    e714:	4c 89 e7             	mov    %r12,%rdi
    e717:	e8 b4 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e71c:	e9 ea ec ff ff       	jmp    d40b <f0+0x18ab>
    e721:	4c 89 e7             	mov    %r12,%rdi
    e724:	e8 a7 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e729:	e9 7c ed ff ff       	jmp    d4aa <f0+0x194a>
    e72e:	4c 89 e7             	mov    %r12,%rdi
    e731:	e8 9a 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e736:	e9 0e ee ff ff       	jmp    d549 <f0+0x19e9>
    e73b:	4c 89 e7             	mov    %r12,%rdi
    e73e:	e8 8d 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e743:	e9 a0 ee ff ff       	jmp    d5e8 <f0+0x1a88>
    e748:	4c 89 e7             	mov    %r12,%rdi
    e74b:	e8 80 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e750:	e9 32 ef ff ff       	jmp    d687 <f0+0x1b27>
    e755:	4c 89 e7             	mov    %r12,%rdi
    e758:	e8 73 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e75d:	e9 c4 ef ff ff       	jmp    d726 <f0+0x1bc6>
    e762:	4c 89 e7             	mov    %r12,%rdi
    e765:	e8 66 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e76a:	e9 56 f0 ff ff       	jmp    d7c5 <f0+0x1c65>
    e76f:	4c 89 e7             	mov    %r12,%rdi
    e772:	e8 59 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e777:	e9 e8 f0 ff ff       	jmp    d864 <f0+0x1d04>
    e77c:	4c 89 e7             	mov    %r12,%rdi
    e77f:	e8 4c 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e784:	e9 7a f1 ff ff       	jmp    d903 <f0+0x1da3>
    e789:	4c 89 e7             	mov    %r12,%rdi
    e78c:	e8 3f 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e791:	e9 0c f2 ff ff       	jmp    d9a2 <f0+0x1e42>
    e796:	4c 89 e7             	mov    %r12,%rdi
    e799:	e8 32 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e79e:	e9 9e f2 ff ff       	jmp    da41 <f0+0x1ee1>
    e7a3:	4c 89 e7             	mov    %r12,%rdi
    e7a6:	e8 25 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e7ab:	e9 30 f3 ff ff       	jmp    dae0 <f0+0x1f80>
    e7b0:	4c 89 e7             	mov    %r12,%rdi
    e7b3:	e8 18 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e7b8:	e9 c2 f3 ff ff       	jmp    db7f <f0+0x201f>
    e7bd:	4c 89 e7             	mov    %r12,%rdi
    e7c0:	e8 0b 70 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e7c5:	e9 54 f4 ff ff       	jmp    dc1e <f0+0x20be>
    e7ca:	4c 89 e7             	mov    %r12,%rdi
    e7cd:	e8 fe 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e7d2:	e9 e6 f4 ff ff       	jmp    dcbd <f0+0x215d>
    e7d7:	4c 89 e7             	mov    %r12,%rdi
    e7da:	e8 f1 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e7df:	e9 78 f5 ff ff       	jmp    dd5c <f0+0x21fc>
    e7e4:	4c 89 e7             	mov    %r12,%rdi
    e7e7:	e8 e4 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e7ec:	e9 0a f6 ff ff       	jmp    ddfb <f0+0x229b>
    e7f1:	4c 89 e7             	mov    %r12,%rdi
    e7f4:	e8 d7 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e7f9:	e9 9c f6 ff ff       	jmp    de9a <f0+0x233a>
    e7fe:	4c 89 e7             	mov    %r12,%rdi
    e801:	e8 ca 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e806:	e9 2e f7 ff ff       	jmp    df39 <f0+0x23d9>
    e80b:	4c 89 e7             	mov    %r12,%rdi
    e80e:	e8 bd 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e813:	e9 c0 f7 ff ff       	jmp    dfd8 <f0+0x2478>
    e818:	4c 89 e7             	mov    %r12,%rdi
    e81b:	e8 b0 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e820:	e9 52 f8 ff ff       	jmp    e077 <f0+0x2517>
    e825:	4c 89 e7             	mov    %r12,%rdi
    e828:	e8 a3 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e82d:	e9 e4 f8 ff ff       	jmp    e116 <f0+0x25b6>
    e832:	4c 89 e7             	mov    %r12,%rdi
    e835:	e8 96 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e83a:	e9 76 f9 ff ff       	jmp    e1b5 <f0+0x2655>
    e83f:	4c 89 e7             	mov    %r12,%rdi
    e842:	e8 89 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e847:	e9 08 fa ff ff       	jmp    e254 <f0+0x26f4>
    e84c:	4c 89 e7             	mov    %r12,%rdi
    e84f:	e8 7c 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e854:	e9 9a fa ff ff       	jmp    e2f3 <f0+0x2793>
    e859:	e8 f2 4b ff ff       	call   3450 <__stack_chk_fail@plt>
    e85e:	66 90                	xchg   %ax,%ax

000000000000e860 <fwp_main_thread>:
    e860:	f3 0f 1e fa          	endbr64
    e864:	41 54                	push   %r12
    e866:	55                   	push   %rbp
    e867:	53                   	push   %rbx
    e868:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    e86f:	8b 0d 6f f3 05 00    	mov    0x5f36f(%rip),%ecx        # 6dbe4 <fwp_heap+0x13a4>
    e875:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    e87c:	00 00 
    e87e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    e885:	00 
    e886:	31 c0                	xor    %eax,%eax
    e888:	85 c9                	test   %ecx,%ecx
    e88a:	0f 84 58 07 00 00    	je     efe8 <fwp_main_thread+0x788>
    e890:	8b 15 52 f3 05 00    	mov    0x5f352(%rip),%edx        # 6dbe8 <fwp_heap+0x13a8>
    e896:	85 d2                	test   %edx,%edx
    e898:	0f 85 32 07 00 00    	jne    efd0 <fwp_main_thread+0x770>
    e89e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    e8a3:	31 f6                	xor    %esi,%esi
    e8a5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    e8aa:	48 c7 05 2b d9 05 00 	movq   $0x40000000,0x5d92b(%rip)        # 6c1e0 <fwp_main_stack_size>
    e8b1:	00 00 00 40 
    e8b5:	48 89 05 2c d9 05 00 	mov    %rax,0x5d92c(%rip)        # 6c1e8 <fwp_main_stack_top>
    e8bc:	48 8d 05 dd 57 00 00 	lea    0x57dd(%rip),%rax        # 140a0 <alt.5>
    e8c3:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    e8c8:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    e8cf:	01 00 
    e8d1:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    e8d8:	00 
    e8d9:	e8 c2 4d ff ff       	call   36a0 <sigaltstack@plt>
    e8de:	85 c0                	test   %eax,%eax
    e8e0:	0f 85 6a 07 00 00    	jne    f050 <fwp_main_thread+0x7f0>
    e8e6:	31 c0                	xor    %eax,%eax
    e8e8:	b9 12 00 00 00       	mov    $0x12,%ecx
    e8ed:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e8f2:	f3 48 ab             	rep stos %rax,(%rdi)
    e8f5:	48 8d 05 44 54 ff ff 	lea    -0xabbc(%rip),%rax        # 3d40 <fwp_segv>
    e8fc:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e901:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    e908:	04 00 00 08 
    e90c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    e911:	e8 4a 4c ff ff       	call   3560 <sigemptyset@plt>
    e916:	85 c0                	test   %eax,%eax
    e918:	0f 85 32 07 00 00    	jne    f050 <fwp_main_thread+0x7f0>
    e91e:	31 d2                	xor    %edx,%edx
    e920:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e925:	bf 0b 00 00 00       	mov    $0xb,%edi
    e92a:	e8 c1 4a ff ff       	call   33f0 <sigaction@plt>
    e92f:	85 c0                	test   %eax,%eax
    e931:	0f 85 19 07 00 00    	jne    f050 <fwp_main_thread+0x7f0>
    e937:	31 d2                	xor    %edx,%edx
    e939:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e93e:	bf 07 00 00 00       	mov    $0x7,%edi
    e943:	e8 a8 4a ff ff       	call   33f0 <sigaction@plt>
    e948:	85 c0                	test   %eax,%eax
    e94a:	0f 85 00 07 00 00    	jne    f050 <fwp_main_thread+0x7f0>
    e950:	48 8b 05 09 f3 05 00 	mov    0x5f309(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    e957:	48 85 c0             	test   %rax,%rax
    e95a:	0f 88 50 06 00 00    	js     efb0 <fwp_main_thread+0x750>
    e960:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e964:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    e969:	48 8d 3d b0 58 ff ff 	lea    -0xa750(%rip),%rdi        # 4220 <ad_raw_report>
    e970:	f2 0f 11 05 70 fb 05 	movsd  %xmm0,0x5fb70(%rip)        # 6e4e8 <iteration_start_charge>
    e977:	00 
    e978:	c7 05 86 fb 05 00 01 	movl   $0x1,0x5fb86(%rip)        # 6e508 <iteration_active>
    e97f:	00 00 00 
    e982:	e8 09 09 00 00       	call   f290 <atexit>
    e987:	85 c0                	test   %eax,%eax
    e989:	0f 85 cd 06 00 00    	jne    f05c <fwp_main_thread+0x7fc>
    e98f:	8b 05 fb 56 00 00    	mov    0x56fb(%rip),%eax        # 14090 <st.3>
    e995:	85 c0                	test   %eax,%eax
    e997:	0f 84 5b 06 00 00    	je     eff8 <fwp_main_thread+0x798>
    e99d:	48 8b 2d 7c de 05 00 	mov    0x5de7c(%rip),%rbp        # 6c820 <fwp_cur>
    e9a4:	48 85 ed             	test   %rbp,%rbp
    e9a7:	0f 84 03 03 00 00    	je     ecb0 <fwp_main_thread+0x450>
    e9ad:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    e9b2:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    e9b6:	48 89 eb             	mov    %rbp,%rbx
    e9b9:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e9be:	0f 84 41 01 00 00    	je     eb05 <fwp_main_thread+0x2a5>
    e9c4:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    e9c9:	0f 84 11 02 00 00    	je     ebe0 <fwp_main_thread+0x380>
    e9cf:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e9d3:	0f 84 f7 01 00 00    	je     ebd0 <fwp_main_thread+0x370>
    e9d9:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e9dd:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e9e1:	0f 85 79 02 00 00    	jne    ec60 <fwp_main_thread+0x400>
    e9e7:	48 8b 43 60          	mov    0x60(%rbx),%rax
    e9eb:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e9f2:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e9f6:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e9fd:	00 00 00 00 
    ea01:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    ea08:	48 85 d2             	test   %rdx,%rdx
    ea0b:	74 07                	je     ea14 <fwp_main_thread+0x1b4>
    ea0d:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    ea14:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ea18:	48 85 c0             	test   %rax,%rax
    ea1b:	74 34                	je     ea51 <fwp_main_thread+0x1f1>
    ea1d:	48 89 43 68          	mov    %rax,0x68(%rbx)
    ea21:	48 8b 05 d0 dd 05 00 	mov    0x5ddd0(%rip),%rax        # 6c7f8 <fwp_timers>
    ea28:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    ea2c:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    ea33:	00 00 00 00 
    ea37:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    ea3e:	48 85 c0             	test   %rax,%rax
    ea41:	74 07                	je     ea4a <fwp_main_thread+0x1ea>
    ea43:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    ea4a:	48 89 1d a7 dd 05 00 	mov    %rbx,0x5dda7(%rip)        # 6c7f8 <fwp_timers>
    ea51:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    ea55:	e8 96 8e ff ff       	call   78f0 <fwp_block>
    ea5a:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    ea61:	48 85 c9             	test   %rcx,%rcx
    ea64:	74 47                	je     eaad <fwp_main_thread+0x24d>
    ea66:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    ea6d:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    ea74:	48 85 d2             	test   %rdx,%rdx
    ea77:	0f 84 23 02 00 00    	je     eca0 <fwp_main_thread+0x440>
    ea7d:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    ea84:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    ea8b:	48 85 c0             	test   %rax,%rax
    ea8e:	74 07                	je     ea97 <fwp_main_thread+0x237>
    ea90:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    ea97:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    ea9e:	00 00 00 00 
    eaa2:	66 0f ef d2          	pxor   %xmm2,%xmm2
    eaa6:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    eaad:	48 8b 0d 6c dd 05 00 	mov    0x5dd6c(%rip),%rcx        # 6c820 <fwp_cur>
    eab4:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    eab8:	0f 84 92 01 00 00    	je     ec50 <fwp_main_thread+0x3f0>
    eabe:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    eac5:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    eacc:	48 85 d2             	test   %rdx,%rdx
    eacf:	0f 84 1b 04 00 00    	je     eef0 <fwp_main_thread+0x690>
    ead5:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    eadc:	48 85 c0             	test   %rax,%rax
    eadf:	74 07                	je     eae8 <fwp_main_thread+0x288>
    eae1:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    eae8:	66 0f ef db          	pxor   %xmm3,%xmm3
    eaec:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    eaf0:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    eaf7:	48 89 cb             	mov    %rcx,%rbx
    eafa:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    eaff:	0f 85 bf fe ff ff    	jne    e9c4 <fwp_main_thread+0x164>
    eb05:	48 83 3d ab f9 05 00 	cmpq   $0x0,0x5f9ab(%rip)        # 6e4b8 <fwp_state_len>
    eb0c:	00 
    eb0d:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    eb11:	0f 84 0b 04 00 00    	je     ef22 <fwp_main_thread+0x6c2>
    eb17:	48 3b 1d fa dc 05 00 	cmp    0x5dcfa(%rip),%rbx        # 6c818 <fwp_root>
    eb1e:	c7 05 78 55 01 00 00 	movl   $0x0,0x15578(%rip)        # 240a0 <fwp_exit_code>
    eb25:	00 00 00 
    eb28:	0f 85 4c 05 00 00    	jne    f07a <fwp_main_thread+0x81a>
    eb2e:	48 85 db             	test   %rbx,%rbx
    eb31:	0f 84 9f 01 00 00    	je     ecd6 <fwp_main_thread+0x476>
    eb37:	48 8b 15 aa dc 05 00 	mov    0x5dcaa(%rip),%rdx        # 6c7e8 <fwp_tasks_active>
    eb3e:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    eb42:	48 85 d2             	test   %rdx,%rdx
    eb45:	0f 84 8b 01 00 00    	je     ecd6 <fwp_main_thread+0x476>
    eb4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    eb50:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    eb54:	75 08                	jne    eb5e <fwp_main_thread+0x2fe>
    eb56:	48 89 d7             	mov    %rdx,%rdi
    eb59:	e8 d2 55 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    eb5e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    eb65:	48 85 d2             	test   %rdx,%rdx
    eb68:	75 e6                	jne    eb50 <fwp_main_thread+0x2f0>
    eb6a:	eb 31                	jmp    eb9d <fwp_main_thread+0x33d>
    eb6c:	0f 1f 40 00          	nopl   0x0(%rax)
    eb70:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    eb77:	48 89 1d 82 dc 05 00 	mov    %rbx,0x5dc82(%rip)        # 6c800 <fwp_ready_tail>
    eb7e:	e8 6d 8d ff ff       	call   78f0 <fwp_block>
    eb83:	e8 68 8b ff ff       	call   76f0 <fwp_free_zombie>
    eb88:	48 83 3d 58 dc 05 00 	cmpq   $0x0,0x5dc58(%rip)        # 6c7e8 <fwp_tasks_active>
    eb8f:	00 
    eb90:	0f 84 40 01 00 00    	je     ecd6 <fwp_main_thread+0x476>
    eb96:	48 8b 1d 7b dc 05 00 	mov    0x5dc7b(%rip),%rbx        # 6c818 <fwp_root>
    eb9d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    eba1:	75 db                	jne    eb7e <fwp_main_thread+0x31e>
    eba3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    eba7:	75 d5                	jne    eb7e <fwp_main_thread+0x31e>
    eba9:	48 8b 05 50 dc 05 00 	mov    0x5dc50(%rip),%rax        # 6c800 <fwp_ready_tail>
    ebb0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    ebb4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    ebbb:	00 00 00 00 
    ebbf:	48 85 c0             	test   %rax,%rax
    ebc2:	75 ac                	jne    eb70 <fwp_main_thread+0x310>
    ebc4:	48 89 1d 3d dc 05 00 	mov    %rbx,0x5dc3d(%rip)        # 6c808 <fwp_ready_head>
    ebcb:	eb aa                	jmp    eb77 <fwp_main_thread+0x317>
    ebcd:	0f 1f 00             	nopl   (%rax)
    ebd0:	e8 eb 59 ff ff       	call   45c0 <fwp_now_ns>
    ebd5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    ebd9:	0f 8d 21 03 00 00    	jge    ef00 <fwp_main_thread+0x6a0>
    ebdf:	90                   	nop
    ebe0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    ebe4:	0f 85 ef fd ff ff    	jne    e9d9 <fwp_main_thread+0x179>
    ebea:	48 8b 45 60          	mov    0x60(%rbp),%rax
    ebee:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    ebf2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    ebf6:	0f 85 ef fd ff ff    	jne    e9eb <fwp_main_thread+0x18b>
    ebfc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    ec00:	48 85 c9             	test   %rcx,%rcx
    ec03:	0f 84 e2 fd ff ff    	je     e9eb <fwp_main_thread+0x18b>
    ec09:	48 85 c0             	test   %rax,%rax
    ec0c:	0f 84 5b 04 00 00    	je     f06d <fwp_main_thread+0x80d>
    ec12:	48 39 c8             	cmp    %rcx,%rax
    ec15:	48 0f 4f c1          	cmovg  %rcx,%rax
    ec19:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    ec20:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    ec24:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ec2b:	00 00 00 00 
    ec2f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    ec36:	48 85 d2             	test   %rdx,%rdx
    ec39:	74 07                	je     ec42 <fwp_main_thread+0x3e2>
    ec3b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    ec42:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ec46:	e9 d2 fd ff ff       	jmp    ea1d <fwp_main_thread+0x1bd>
    ec4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ec50:	48 89 cb             	mov    %rcx,%rbx
    ec53:	e9 61 fd ff ff       	jmp    e9b9 <fwp_main_thread+0x159>
    ec58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ec5f:	00 
    ec60:	48 8b 45 40          	mov    0x40(%rbp),%rax
    ec64:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    ec6b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ec72:	00 00 00 00 
    ec76:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    ec7d:	48 85 c0             	test   %rax,%rax
    ec80:	0f 84 9a 03 00 00    	je     f020 <fwp_main_thread+0x7c0>
    ec86:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    ec8d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ec91:	e9 bb fd ff ff       	jmp    ea51 <fwp_main_thread+0x1f1>
    ec96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ec9d:	00 00 00 
    eca0:	48 89 01             	mov    %rax,(%rcx)
    eca3:	e9 e3 fd ff ff       	jmp    ea8b <fwp_main_thread+0x22b>
    eca8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ecaf:	00 
    ecb0:	48 83 3d 00 f8 05 00 	cmpq   $0x0,0x5f800(%rip)        # 6e4b8 <fwp_state_len>
    ecb7:	00 
    ecb8:	0f 84 62 02 00 00    	je     ef20 <fwp_main_thread+0x6c0>
    ecbe:	48 83 3d 52 db 05 00 	cmpq   $0x0,0x5db52(%rip)        # 6c818 <fwp_root>
    ecc5:	00 
    ecc6:	c7 05 d0 53 01 00 00 	movl   $0x0,0x153d0(%rip)        # 240a0 <fwp_exit_code>
    eccd:	00 00 00 
    ecd0:	0f 85 9f 03 00 00    	jne    f075 <fwp_main_thread+0x815>
    ecd6:	e8 15 8a ff ff       	call   76f0 <fwp_free_zombie>
    ecdb:	48 83 3d 25 db 05 00 	cmpq   $0x0,0x5db25(%rip)        # 6c808 <fwp_ready_head>
    ece2:	00 
    ece3:	0f 85 67 4a ff ff    	jne    3750 <fwp_main_thread.cold>
    ece9:	48 83 3d 07 db 05 00 	cmpq   $0x0,0x5db07(%rip)        # 6c7f8 <fwp_timers>
    ecf0:	00 
    ecf1:	0f 85 59 4a ff ff    	jne    3750 <fwp_main_thread.cold>
    ecf7:	8b 1d f7 d4 05 00    	mov    0x5d4f7(%rip),%ebx        # 6c1f4 <fwp_stack_pool_n>
    ecfd:	85 db                	test   %ebx,%ebx
    ecff:	74 36                	je     ed37 <fwp_main_thread+0x4d7>
    ed01:	83 eb 01             	sub    $0x1,%ebx
    ed04:	48 8d 05 f5 d4 05 00 	lea    0x5d4f5(%rip),%rax        # 6c200 <fwp_stack_pool>
    ed0b:	48 63 d3             	movslq %ebx,%rdx
    ed0e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    ed12:	eb 07                	jmp    ed1b <fwp_main_thread+0x4bb>
    ed14:	0f 1f 40 00          	nopl   0x0(%rax)
    ed18:	83 eb 01             	sub    $0x1,%ebx
    ed1b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    ed1f:	be 00 00 00 10       	mov    $0x10000000,%esi
    ed24:	89 1d ca d4 05 00    	mov    %ebx,0x5d4ca(%rip)        # 6c1f4 <fwp_stack_pool_n>
    ed2a:	48 83 ed 08          	sub    $0x8,%rbp
    ed2e:	e8 8d 48 ff ff       	call   35c0 <munmap@plt>
    ed33:	85 db                	test   %ebx,%ebx
    ed35:	75 e1                	jne    ed18 <fwp_main_thread+0x4b8>
    ed37:	8b 3d e3 52 00 00    	mov    0x52e3(%rip),%edi        # 14020 <fwp_epfd>
    ed3d:	85 ff                	test   %edi,%edi
    ed3f:	78 05                	js     ed46 <fwp_main_thread+0x4e6>
    ed41:	e8 7a 47 ff ff       	call   34c0 <close@plt>
    ed46:	4c 8b 25 b3 d6 05 00 	mov    0x5d6b3(%rip),%r12        # 6c400 <fwp_nfdws>
    ed4d:	48 8b 2d b4 d6 05 00 	mov    0x5d6b4(%rip),%rbp        # 6c408 <fwp_fdws>
    ed54:	31 db                	xor    %ebx,%ebx
    ed56:	c7 05 c0 52 00 00 ff 	movl   $0xffffffff,0x52c0(%rip)        # 14020 <fwp_epfd>
    ed5d:	ff ff ff 
    ed60:	4d 85 e4             	test   %r12,%r12
    ed63:	74 38                	je     ed9d <fwp_main_thread+0x53d>
    ed65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ed6c:	00 00 00 00 
    ed70:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    ed75:	48 85 ff             	test   %rdi,%rdi
    ed78:	74 1a                	je     ed94 <fwp_main_thread+0x534>
    ed7a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    ed7e:	0f 85 cc 49 ff ff    	jne    3750 <fwp_main_thread.cold>
    ed84:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    ed89:	0f 85 c1 49 ff ff    	jne    3750 <fwp_main_thread.cold>
    ed8f:	e8 7c 6c ff ff       	call   5a10 <fwp_mem_free>
    ed94:	48 83 c3 01          	add    $0x1,%rbx
    ed98:	49 39 dc             	cmp    %rbx,%r12
    ed9b:	75 d3                	jne    ed70 <fwp_main_thread+0x510>
    ed9d:	48 89 ef             	mov    %rbp,%rdi
    eda0:	e8 6b 6c ff ff       	call   5a10 <fwp_mem_free>
    eda5:	48 8b 15 6c da 05 00 	mov    0x5da6c(%rip),%rdx        # 6c818 <fwp_root>
    edac:	48 c7 05 51 d6 05 00 	movq   $0x0,0x5d651(%rip)        # 6c408 <fwp_fdws>
    edb3:	00 00 00 00 
    edb7:	48 c7 05 3e d6 05 00 	movq   $0x0,0x5d63e(%rip)        # 6c400 <fwp_nfdws>
    edbe:	00 00 00 00 
    edc2:	48 85 d2             	test   %rdx,%rdx
    edc5:	74 4e                	je     ee15 <fwp_main_thread+0x5b5>
    edc7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    edcc:	0f 85 7e 49 ff ff    	jne    3750 <fwp_main_thread.cold>
    edd2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    edd9:	00 
    edda:	0f 85 70 49 ff ff    	jne    3750 <fwp_main_thread.cold>
    ede0:	48 83 3d d0 f6 05 00 	cmpq   $0x0,0x5f6d0(%rip)        # 6e4b8 <fwp_state_len>
    ede7:	00 
    ede8:	0f 85 62 49 ff ff    	jne    3750 <fwp_main_thread.cold>
    edee:	48 83 3d b2 f6 05 00 	cmpq   $0x0,0x5f6b2(%rip)        # 6e4a8 <fwp_state_owners>
    edf5:	00 
    edf6:	0f 85 54 49 ff ff    	jne    3750 <fwp_main_thread.cold>
    edfc:	b9 79 00 00 00       	mov    $0x79,%ecx
    ee01:	31 c0                	xor    %eax,%eax
    ee03:	48 8d 3d 16 d6 05 00 	lea    0x5d616(%rip),%rdi        # 6c420 <fwp_root_context>
    ee0a:	f3 48 ab             	rep stos %rax,(%rdi)
    ee0d:	48 89 d7             	mov    %rdx,%rdi
    ee10:	e8 fb 6b ff ff       	call   5a10 <fwp_mem_free>
    ee15:	66 0f 6f 05 b3 53 04 	movdqa 0x453b3(%rip),%xmm0        # 541d0 <ad_raw_live+0x10>
    ee1c:	00 
    ee1d:	66 0f d4 05 9b 53 04 	paddq  0x4539b(%rip),%xmm0        # 541c0 <ad_raw_live>
    ee24:	00 
    ee25:	48 c7 05 f0 d9 05 00 	movq   $0x0,0x5d9f0(%rip)        # 6c820 <fwp_cur>
    ee2c:	00 00 00 00 
    ee30:	48 8b 05 29 ee 05 00 	mov    0x5ee29(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    ee37:	48 c7 05 d6 d9 05 00 	movq   $0x0,0x5d9d6(%rip)        # 6c818 <fwp_root>
    ee3e:	00 00 00 00 
    ee42:	c7 05 bc f6 05 00 00 	movl   $0x0,0x5f6bc(%rip)        # 6e508 <iteration_active>
    ee49:	00 00 00 
    ee4c:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    ee50:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    ee55:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    ee59:	66 0f d6 05 b7 52 01 	movq   %xmm0,0x152b7(%rip)        # 24118 <ad_raw_before_shutdown>
    ee60:	00 
    ee61:	48 85 c0             	test   %rax,%rax
    ee64:	0f 88 26 01 00 00    	js     ef90 <fwp_main_thread+0x730>
    ee6a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    ee6e:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    ee73:	f2 0f 5c 0d 6d f6 05 	subsd  0x5f66d(%rip),%xmm1        # 6e4e8 <iteration_start_charge>
    ee7a:	00 
    ee7b:	48 8b 3d de 51 00 00 	mov    0x51de(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    ee82:	48 8d 15 d7 1c 00 00 	lea    0x1cd7(%rip),%rdx        # 10b60 <_IO_stdin_used+0xb60>
    ee89:	be 02 00 00 00       	mov    $0x2,%esi
    ee8e:	f2 0f 10 05 4a f6 05 	movsd  0x5f64a(%rip),%xmm0        # 6e4e0 <iteration_peak>
    ee95:	00 
    ee96:	4c 8b 0d 53 f6 05 00 	mov    0x5f653(%rip),%r9        # 6e4f0 <iteration_retains>
    ee9d:	b8 02 00 00 00       	mov    $0x2,%eax
    eea2:	4c 8b 05 4f f6 05 00 	mov    0x5f64f(%rip),%r8        # 6e4f8 <iteration_bytes>
    eea9:	48 8b 0d 50 f6 05 00 	mov    0x5f650(%rip),%rcx        # 6e500 <iteration_requests>
    eeb0:	e8 bb 47 ff ff       	call   3670 <__fprintf_chk@plt>
    eeb5:	48 8b 3d 84 51 00 00 	mov    0x5184(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    eebc:	e8 df 46 ff ff       	call   35a0 <fflush@plt>
    eec1:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    eec8:	00 
    eec9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    eed0:	00 00 
    eed2:	0f 85 90 01 00 00    	jne    f068 <fwp_main_thread+0x808>
    eed8:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    eedf:	31 c0                	xor    %eax,%eax
    eee1:	5b                   	pop    %rbx
    eee2:	5d                   	pop    %rbp
    eee3:	41 5c                	pop    %r12
    eee5:	c3                   	ret
    eee6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    eeed:	00 00 00 
    eef0:	48 89 05 01 d9 05 00 	mov    %rax,0x5d901(%rip)        # 6c7f8 <fwp_timers>
    eef7:	e9 e0 fb ff ff       	jmp    eadc <fwp_main_thread+0x27c>
    eefc:	0f 1f 40 00          	nopl   0x0(%rax)
    ef00:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    ef04:	0f 85 d6 fc ff ff    	jne    ebe0 <fwp_main_thread+0x380>
    ef0a:	48 89 ef             	mov    %rbp,%rdi
    ef0d:	e8 1e 52 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    ef12:	e9 c9 fc ff ff       	jmp    ebe0 <fwp_main_thread+0x380>
    ef17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ef1e:	00 00 
    ef20:	31 db                	xor    %ebx,%ebx
    ef22:	48 83 3d 7e f5 05 00 	cmpq   $0x0,0x5f57e(%rip)        # 6e4a8 <fwp_state_owners>
    ef29:	00 
    ef2a:	0f 85 e7 fb ff ff    	jne    eb17 <fwp_main_thread+0x2b7>
    ef30:	48 8b 3d 89 f5 05 00 	mov    0x5f589(%rip),%rdi        # 6e4c0 <fwp_state>
    ef37:	e8 d4 6a ff ff       	call   5a10 <fwp_mem_free>
    ef3c:	48 c7 05 79 f5 05 00 	movq   $0x0,0x5f579(%rip)        # 6e4c0 <fwp_state>
    ef43:	00 00 00 00 
    ef47:	48 c7 05 5e f5 05 00 	movq   $0x0,0x5f55e(%rip)        # 6e4b0 <fwp_state_cap>
    ef4e:	00 00 00 00 
    ef52:	48 85 db             	test   %rbx,%rbx
    ef55:	0f 84 ce 00 00 00    	je     f029 <fwp_main_thread+0x7c9>
    ef5b:	48 39 1d b6 d8 05 00 	cmp    %rbx,0x5d8b6(%rip)        # 6c818 <fwp_root>
    ef62:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    ef69:	00 00 00 00 
    ef6d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    ef74:	00 00 00 00 
    ef78:	c7 05 1e 51 01 00 00 	movl   $0x0,0x1511e(%rip)        # 240a0 <fwp_exit_code>
    ef7f:	00 00 00 
    ef82:	0f 84 af fb ff ff    	je     eb37 <fwp_main_thread+0x2d7>
    ef88:	e9 c3 47 ff ff       	jmp    3750 <fwp_main_thread.cold>
    ef8d:	0f 1f 00             	nopl   (%rax)
    ef90:	48 89 c2             	mov    %rax,%rdx
    ef93:	83 e0 01             	and    $0x1,%eax
    ef96:	66 0f ef c9          	pxor   %xmm1,%xmm1
    ef9a:	48 d1 ea             	shr    $1,%rdx
    ef9d:	48 09 c2             	or     %rax,%rdx
    efa0:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    efa5:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    efa9:	e9 c5 fe ff ff       	jmp    ee73 <fwp_main_thread+0x613>
    efae:	66 90                	xchg   %ax,%ax
    efb0:	48 89 c2             	mov    %rax,%rdx
    efb3:	83 e0 01             	and    $0x1,%eax
    efb6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    efba:	48 d1 ea             	shr    $1,%rdx
    efbd:	48 09 c2             	or     %rax,%rdx
    efc0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    efc5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    efc9:	e9 9b f9 ff ff       	jmp    e969 <fwp_main_thread+0x109>
    efce:	66 90                	xchg   %ax,%ax
    efd0:	48 8d 3d e9 5c ff ff 	lea    -0xa317(%rip),%rdi        # 4cc0 <fwp_heap_report>
    efd7:	e8 b4 02 00 00       	call   f290 <atexit>
    efdc:	e9 bd f8 ff ff       	jmp    e89e <fwp_main_thread+0x3e>
    efe1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    efe8:	e8 e3 5d ff ff       	call   4dd0 <fwp_heap_init>
    efed:	e9 9e f8 ff ff       	jmp    e890 <fwp_main_thread+0x30>
    eff2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    eff8:	e8 63 cb ff ff       	call   bb60 <f0>
    effd:	48 c7 05 80 50 00 00 	movq   $0x0,0x5080(%rip)        # 14088 <v.2>
    f004:	00 00 00 00 
    f008:	c7 05 7e 50 00 00 01 	movl   $0x1,0x507e(%rip)        # 14090 <st.3>
    f00f:	00 00 00 
    f012:	e9 86 f9 ff ff       	jmp    e99d <fwp_main_thread+0x13d>
    f017:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    f01e:	00 00 
    f020:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    f024:	e9 28 fa ff ff       	jmp    ea51 <fwp_main_thread+0x1f1>
    f029:	48 83 3d e7 d7 05 00 	cmpq   $0x0,0x5d7e7(%rip)        # 6c818 <fwp_root>
    f030:	00 
    f031:	c7 05 65 50 01 00 00 	movl   $0x0,0x15065(%rip)        # 240a0 <fwp_exit_code>
    f038:	00 00 00 
    f03b:	0f 84 95 fc ff ff    	je     ecd6 <fwp_main_thread+0x476>
    f041:	e9 0a 47 ff ff       	jmp    3750 <fwp_main_thread.cold>
    f046:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    f04d:	00 00 00 
    f050:	48 8d 3d e1 1a 00 00 	lea    0x1ae1(%rip),%rdi        # 10b38 <_IO_stdin_used+0xb38>
    f057:	e8 f4 53 ff ff       	call   4450 <fwp_trap>
    f05c:	48 8d 3d 70 12 00 00 	lea    0x1270(%rip),%rdi        # 102d3 <_IO_stdin_used+0x2d3>
    f063:	e8 98 4f ff ff       	call   4000 <ad_raw_fail>
    f068:	e8 e3 43 ff ff       	call   3450 <__stack_chk_fail@plt>
    f06d:	48 89 c8             	mov    %rcx,%rax
    f070:	e9 a4 fb ff ff       	jmp    ec19 <fwp_main_thread+0x3b9>
    f075:	e9 d6 46 ff ff       	jmp    3750 <fwp_main_thread.cold>
    f07a:	e9 d1 46 ff ff       	jmp    3750 <fwp_main_thread.cold>
    f07f:	90                   	nop

000000000000f080 <__divmodti4>:
    f080:	f3 0f 1e fa          	endbr64
    f084:	55                   	push   %rbp
    f085:	49 89 f1             	mov    %rsi,%r9
    f088:	49 89 d2             	mov    %rdx,%r10
    f08b:	48 89 fe             	mov    %rdi,%rsi
    f08e:	49 89 cb             	mov    %rcx,%r11
    f091:	48 89 e5             	mov    %rsp,%rbp
    f094:	41 57                	push   %r15
    f096:	41 56                	push   %r14
    f098:	41 55                	push   %r13
    f09a:	41 54                	push   %r12
    f09c:	53                   	push   %rbx
    f09d:	4c 89 c3             	mov    %r8,%rbx
    f0a0:	45 31 c0             	xor    %r8d,%r8d
    f0a3:	4d 85 c9             	test   %r9,%r9
    f0a6:	79 12                	jns    f0ba <__divmodti4+0x3a>
    f0a8:	31 ff                	xor    %edi,%edi
    f0aa:	48 f7 de             	neg    %rsi
    f0ad:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    f0b4:	4c 19 cf             	sbb    %r9,%rdi
    f0b7:	49 89 f9             	mov    %rdi,%r9
    f0ba:	4c 89 d8             	mov    %r11,%rax
    f0bd:	4d 85 db             	test   %r11,%r11
    f0c0:	0f 88 1a 01 00 00    	js     f1e0 <__divmodti4+0x160>
    f0c6:	4c 89 d9             	mov    %r11,%rcx
    f0c9:	49 89 f3             	mov    %rsi,%r11
    f0cc:	75 62                	jne    f130 <__divmodti4+0xb0>
    f0ce:	4d 89 c4             	mov    %r8,%r12
    f0d1:	4d 39 d1             	cmp    %r10,%r9
    f0d4:	0f 83 46 01 00 00    	jae    f220 <__divmodti4+0x1a0>
    f0da:	4c 89 d8             	mov    %r11,%rax
    f0dd:	4c 89 ca             	mov    %r9,%rdx
    f0e0:	49 f7 f2             	div    %r10
    f0e3:	49 89 c3             	mov    %rax,%r11
    f0e6:	31 c0                	xor    %eax,%eax
    f0e8:	48 89 d6             	mov    %rdx,%rsi
    f0eb:	31 ff                	xor    %edi,%edi
    f0ed:	4c 89 d9             	mov    %r11,%rcx
    f0f0:	48 89 c2             	mov    %rax,%rdx
    f0f3:	48 89 c8             	mov    %rcx,%rax
    f0f6:	4d 85 e4             	test   %r12,%r12
    f0f9:	74 0a                	je     f105 <__divmodti4+0x85>
    f0fb:	48 f7 d8             	neg    %rax
    f0fe:	48 83 d2 00          	adc    $0x0,%rdx
    f102:	48 f7 da             	neg    %rdx
    f105:	4d 85 c0             	test   %r8,%r8
    f108:	74 0a                	je     f114 <__divmodti4+0x94>
    f10a:	48 f7 de             	neg    %rsi
    f10d:	48 83 d7 00          	adc    $0x0,%rdi
    f111:	48 f7 df             	neg    %rdi
    f114:	48 89 33             	mov    %rsi,(%rbx)
    f117:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    f11b:	5b                   	pop    %rbx
    f11c:	41 5c                	pop    %r12
    f11e:	41 5d                	pop    %r13
    f120:	41 5e                	pop    %r14
    f122:	41 5f                	pop    %r15
    f124:	5d                   	pop    %rbp
    f125:	c3                   	ret
    f126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    f12d:	00 00 00 
    f130:	4d 89 c4             	mov    %r8,%r12
    f133:	49 39 c1             	cmp    %rax,%r9
    f136:	0f 82 ce 00 00 00    	jb     f20a <__divmodti4+0x18a>
    f13c:	31 ff                	xor    %edi,%edi
    f13e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    f143:	48 63 c7             	movslq %edi,%rax
    f146:	be 40 00 00 00       	mov    $0x40,%esi
    f14b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    f150:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    f155:	48 29 c6             	sub    %rax,%rsi
    f158:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    f15d:	48 09 c8             	or     %rcx,%rax
    f160:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    f165:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    f16a:	49 89 c6             	mov    %rax,%r14
    f16d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    f171:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    f176:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    f17b:	49 09 c1             	or     %rax,%r9
    f17e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    f182:	4c 89 c8             	mov    %r9,%rax
    f185:	49 f7 f6             	div    %r14
    f188:	48 89 d1             	mov    %rdx,%rcx
    f18b:	49 89 c3             	mov    %rax,%r11
    f18e:	49 89 c1             	mov    %rax,%r9
    f191:	49 f7 e2             	mul    %r10
    f194:	49 89 c6             	mov    %rax,%r14
    f197:	49 89 d2             	mov    %rdx,%r10
    f19a:	48 39 d1             	cmp    %rdx,%rcx
    f19d:	72 07                	jb     f1a6 <__divmodti4+0x126>
    f19f:	75 17                	jne    f1b8 <__divmodti4+0x138>
    f1a1:	49 39 c7             	cmp    %rax,%r15
    f1a4:	73 12                	jae    f1b8 <__divmodti4+0x138>
    f1a6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    f1aa:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    f1ae:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    f1b2:	49 89 d2             	mov    %rdx,%r10
    f1b5:	49 89 c6             	mov    %rax,%r14
    f1b8:	4c 89 f8             	mov    %r15,%rax
    f1bb:	4c 29 f0             	sub    %r14,%rax
    f1be:	4c 19 d1             	sbb    %r10,%rcx
    f1c1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    f1c6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    f1cb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    f1d0:	48 09 c6             	or     %rax,%rsi
    f1d3:	48 89 cf             	mov    %rcx,%rdi
    f1d6:	31 c0                	xor    %eax,%eax
    f1d8:	4c 89 c9             	mov    %r9,%rcx
    f1db:	e9 10 ff ff ff       	jmp    f0f0 <__divmodti4+0x70>
    f1e0:	4c 89 d0             	mov    %r10,%rax
    f1e3:	4c 89 da             	mov    %r11,%rdx
    f1e6:	4d 89 c4             	mov    %r8,%r12
    f1e9:	49 89 f3             	mov    %rsi,%r11
    f1ec:	48 f7 d8             	neg    %rax
    f1ef:	49 f7 d4             	not    %r12
    f1f2:	48 83 d2 00          	adc    $0x0,%rdx
    f1f6:	49 89 c2             	mov    %rax,%r10
    f1f9:	48 f7 da             	neg    %rdx
    f1fc:	48 89 d1             	mov    %rdx,%rcx
    f1ff:	0f 84 cc fe ff ff    	je     f0d1 <__divmodti4+0x51>
    f205:	49 39 d1             	cmp    %rdx,%r9
    f208:	73 46                	jae    f250 <__divmodti4+0x1d0>
    f20a:	4c 89 cf             	mov    %r9,%rdi
    f20d:	31 c0                	xor    %eax,%eax
    f20f:	31 c9                	xor    %ecx,%ecx
    f211:	e9 da fe ff ff       	jmp    f0f0 <__divmodti4+0x70>
    f216:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    f21d:	00 00 00 
    f220:	4d 85 d2             	test   %r10,%r10
    f223:	75 0d                	jne    f232 <__divmodti4+0x1b2>
    f225:	b8 01 00 00 00       	mov    $0x1,%eax
    f22a:	31 d2                	xor    %edx,%edx
    f22c:	49 f7 f2             	div    %r10
    f22f:	49 89 c2             	mov    %rax,%r10
    f232:	4c 89 c8             	mov    %r9,%rax
    f235:	31 d2                	xor    %edx,%edx
    f237:	49 f7 f2             	div    %r10
    f23a:	49 89 c1             	mov    %rax,%r9
    f23d:	4c 89 d8             	mov    %r11,%rax
    f240:	49 f7 f2             	div    %r10
    f243:	49 89 c3             	mov    %rax,%r11
    f246:	4c 89 c8             	mov    %r9,%rax
    f249:	e9 9a fe ff ff       	jmp    f0e8 <__divmodti4+0x68>
    f24e:	66 90                	xchg   %ax,%ax
    f250:	45 31 f6             	xor    %r14d,%r14d
    f253:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    f258:	44 89 f7             	mov    %r14d,%edi
    f25b:	45 85 f6             	test   %r14d,%r14d
    f25e:	0f 85 df fe ff ff    	jne    f143 <__divmodti4+0xc3>
    f264:	4c 39 ca             	cmp    %r9,%rdx
    f267:	72 17                	jb     f280 <__divmodti4+0x200>
    f269:	31 c9                	xor    %ecx,%ecx
    f26b:	48 39 c6             	cmp    %rax,%rsi
    f26e:	73 10                	jae    f280 <__divmodti4+0x200>
    f270:	4c 89 cf             	mov    %r9,%rdi
    f273:	31 c0                	xor    %eax,%eax
    f275:	e9 76 fe ff ff       	jmp    f0f0 <__divmodti4+0x70>
    f27a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    f280:	4c 89 de             	mov    %r11,%rsi
    f283:	b9 01 00 00 00       	mov    $0x1,%ecx
    f288:	48 29 c6             	sub    %rax,%rsi
    f28b:	49 19 d1             	sbb    %rdx,%r9
    f28e:	eb e0                	jmp    f270 <__divmodti4+0x1f0>

000000000000f290 <atexit>:
    f290:	f3 0f 1e fa          	endbr64
    f294:	48 8b 15 6d 4d 00 00 	mov    0x4d6d(%rip),%rdx        # 14008 <__dso_handle>
    f29b:	31 f6                	xor    %esi,%esi
    f29d:	e9 9e 43 ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000f2a4 <_fini>:
    f2a4:	f3 0f 1e fa          	endbr64
    f2a8:	48 83 ec 08          	sub    $0x8,%rsp
    f2ac:	48 83 c4 08          	add    $0x8,%rsp
    f2b0:	c3                   	ret
