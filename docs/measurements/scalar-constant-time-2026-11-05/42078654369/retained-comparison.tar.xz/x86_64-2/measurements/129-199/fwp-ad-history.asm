
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 ff 00 00 	mov    0xffc9(%rip),%rax        # 12fd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 fd 00 00    	push   0xfde2(%rip)        # 12e08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 fd 00 00    	jmp    *0xfde4(%rip)        # 12e10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e fc 00 00    	jmp    *0xfc4e(%rip)        # 12fe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e fa 00 00    	jmp    *0xfa6e(%rip)        # 12e18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12e70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12e78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12e80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12e88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12e90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12e98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12ea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12ea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12eb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12eb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12ec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12ec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12ed0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12ed8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12ee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12ee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12ef0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12ef8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12f00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12f08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12f70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12f78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12f80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12f88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12f90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12f98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 f8 00 00    	jmp    *0xf8e6(%rip)        # 12fa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de f8 00 00    	jmp    *0xf8de(%rip)        # 12fa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 f8 00 00    	jmp    *0xf8d6(%rip)        # 12fb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce f8 00 00    	jmp    *0xf8ce(%rip)        # 12fb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 f8 00 00    	jmp    *0xf8c6(%rip)        # 12fc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a b9 00 00 	lea    0xb97a(%rip),%r9        # f091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 b9 00 00 	lea    0xb977(%rip),%r8        # f095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 dd 00 00 	lea    0xdd01(%rip),%rax        # 11480 <fwp_fn_table>
    377f:	48 89 05 52 1c 02 00 	mov    %rax,0x21c52(%rip)        # 253d8 <fwp_fns>
    3786:	48 8b 05 b3 f8 00 00 	mov    0xf8b3(%rip),%rax        # 13040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 4c 1c 02 00 	mov    %rax,0x21c4c(%rip)        # 253e0 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 59 ba 00 00 	lea    0xba59(%rip),%rdi        # f1f9 <_IO_stdin_used+0x1f9>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 f8 00 00 	mov    0xf838(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 bf a6 00 00 	lea    0xa6bf(%rip),%rdx        # df20 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 f7 00 00 	mov    0xf7a3(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 f8 f7 01 00    	mov    0x1f7f8(%rip),%eax        # 230a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 09 b9 00 00 	lea    0xb909(%rip),%rdi        # f202 <_IO_stdin_used+0x202>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 8e c0 00 00 	lea    0xc08e(%rip),%rdi        # f998 <_IO_stdin_used+0x998>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 48 c0 00 00 	lea    0xc048(%rip),%rdi        # f970 <_IO_stdin_used+0x970>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 0c c0 00 00 	lea    0xc00c(%rip),%rdi        # f940 <_IO_stdin_used+0x940>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d d8 bf 00 00 	lea    0xbfd8(%rip),%rdi        # f918 <_IO_stdin_used+0x918>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 f6 00 00    	call   *0xf653(%rip)        # 12fc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 f6 00 00 	lea    0xf6a1(%rip),%rdi        # 13028 <__TMC_END__>
    3987:	48 8d 05 9a f6 00 00 	lea    0xf69a(%rip),%rax        # 13028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 f6 00 00 	mov    0xf636(%rip),%rax        # 12fd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 f6 00 00 	lea    0xf671(%rip),%rdi        # 13028 <__TMC_END__>
    39b7:	48 8d 35 6a f6 00 00 	lea    0xf66a(%rip),%rsi        # 13028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 f6 00 00 	mov    0xf605(%rip),%rax        # 12fe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d f6 00 00 00 	cmpb   $0x0,0xf66d(%rip)        # 13068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 f5 00 00 	cmpq   $0x0,0xf5e2(%rip)        # 12fe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 f6 00 00 01 	movb   $0x1,0xf645(%rip)        # 13068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ee f4 01 00 	add    0x1f4ee(%rip),%rdx        # 23110 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 dc f4 01 00 	add    0x1f4dc(%rip),%rax        # 23110 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 69 17 02 00 	mov    0x21769(%rip),%rdi        # 253e0 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d b4 f3 00 00 	mov    0xf3b4(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d a1 f3 00 00 	mov    0xf3a1(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 b3 00 00 	lea    0xb345(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 92 f3 00 00 	mov    0xf392(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 61 fa 01 00 	mov    0x1fa61(%rip),%rax        # 23760 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 a1 f3 01 00 	mov    0x1f3a1(%rip),%rax        # 23120 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 8d f3 01 00 	sub    0x1f38d(%rip),%rax        # 23118 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 bd bc 00 00 	lea    0xbcbd(%rip),%rsi        # fa80 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 7b 0d 02 00 	mov    0x20d7b(%rip),%rax        # 24b70 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 74 0d 02 00 	lea    0x20d74(%rip),%r8        # 24b70 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 55 0d 02 00 	mov    0x20d55(%rip),%rbx        # 24b58 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 65 0d 02 00 	mov    0x20d65(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d 01 0d 02 00 	mov    0x20d01(%rip),%rdi        # 24b60 <fwp_heap+0x13e0>
    3e5f:	48 29 35 4a 0d 02 00 	sub    %rsi,0x20d4a(%rip)        # 24bb0 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 da 0c 02 00 	mov    0x20cda(%rip),%rax        # 24b50 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d 90 0c 02 00 	add    0x20c90(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 9e 0c 02 00 	mov    0x20c9e(%rip),%rsi        # 24b60 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 ac 0c 02 00 	mov    0x20cac(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 5b 0c 02 00 	mov    %r12,0x20c5b(%rip)        # 24b60 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 49 0c 02 00 	mov    %rbp,0x20c49(%rip)        # 24b58 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 2e 0c 02 00 	cmp    %rdi,0x20c2e(%rip)        # 24b48 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 25 0c 02 00 	mov    %rdi,0x20c25(%rip)        # 24b48 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 69 0c 02 00 	sub    %rdi,0x20c69(%rip)        # 24bb0 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 11 0c 02 00 	mov    0x20c11(%rip),%rax        # 24b68 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 0a 0c 02 00 	lea    0x20c0a(%rip),%r8        # 24b68 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d 1d f0 00 00 	mov    0xf01d(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 af 00 00 	lea    0xafb4(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d a9 f6 01 00 	cmp    0x1f6a9(%rip),%rdi        # 23760 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 6f f6 01 00 	mov    0x1f66f(%rip),%rax        # 23740 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 4d f6 01 00 	mov    %rdi,0x1f64d(%rip)        # 23740 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 29 f6 01 00 	mov    %rdi,0x1f629(%rip)        # 23748 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 05 b0 00 00 	lea    0xb005(%rip),%rsi        # f166 <_IO_stdin_used+0x166>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 ae 00 00 	lea    0xaea7(%rip),%rsi        # f01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 98 ee 00 00 	mov    0xee98(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 ae 00 00 	lea    0xae51(%rip),%rdx        # f020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 80 ee 00 00 	mov    0xee80(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 91 ed 00 00 	mov    0xed91(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 ad 00 00 	lea    0xad28(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 ad 00 00 	lea    0xad32(%rip),%rdi        # f02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba ac 00 00 	lea    0xacba(%rip),%rdi        # f049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 68 b2 00 00 	lea    0xb268(%rip),%rdi        # f608 <_IO_stdin_used+0x608>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 e0 b6 00 	movdqa 0xb6e0(%rip),%xmm0        # faa0 <msg.4+0x20>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 ba 0f 02 00 	add    0x20fba(%rip),%rax        # 253d8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d c4 b1 00 00 	lea    0xb1c4(%rip),%rdi        # f638 <_IO_stdin_used+0x638>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 75 ec 01 00 	cmp    %rax,0x1ec75(%rip)        # 23108 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 70 ec 01 00 	add    0x1ec70(%rip),%rax        # 23110 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d ad b1 00 00 	lea    0xb1ad(%rip),%rdi        # f668 <_IO_stdin_used+0x668>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 ab 00 00 	lea    0xab92(%rip),%r8        # f065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 a9 00 00 	lea    0xa9e7(%rip),%r8        # f074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 a8 00 00 	lea    0xa874(%rip),%r8        # f06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c a6 00 00 	lea    0xa64c(%rip),%rdi        # f079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 60 a7 00 00 	lea    0xa760(%rip),%rsi        # f1ae <_IO_stdin_used+0x1ae>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d 85 00 02 00 	mov    0x20085(%rip),%r9        # 24b48 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 de 00 02 00 	mov    0x200de(%rip),%r8        # 24ba8 <fwp_heap+0x1428>
    4aca:	48 8d 15 e7 ab 00 00 	lea    0xabe7(%rip),%rdx        # f6b8 <_IO_stdin_used+0x6b8>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d c6 00 02 00 	mov    0x200c6(%rip),%rcx        # 24ba0 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d d4 00 02 	movsd  0x200d4(%rip),%xmm1        # 24bc0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 c4 00 02 	movsd  0x200c4(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 65 e5 00 00 	mov    0xe565(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 78 af 00 	movdqa 0xaf78(%rip),%xmm0        # fab0 <msg.4+0x30>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 7f fb 01 00 	lea    0x1fb7f(%rip),%rax        # 246c0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 a1 af 00 	movdqa 0xafa1(%rip),%xmm2        # faf0 <msg.4+0x70>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 25 fb 01 00 	movaps %xmm0,0x1fb25(%rip)        # 24680 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 5d af 00 	movdqa 0xaf5d(%rip),%xmm0        # fac0 <msg.4+0x40>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 b3 ff 01 00 01 	movl   $0x1,0x1ffb3(%rip)        # 24b24 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 13 fb 01 00 	movaps %xmm0,0x1fb13(%rip)        # 24690 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 4b af 00 	movdqa 0xaf4b(%rip),%xmm0        # fad0 <msg.4+0x50>
    4b84:	00 
    4b85:	0f 29 05 14 fb 01 00 	movaps %xmm0,0x1fb14(%rip)        # 246a0 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 4c af 00 	movdqa 0xaf4c(%rip),%xmm0        # fae0 <msg.4+0x60>
    4b93:	00 
    4b94:	0f 29 05 15 fb 01 00 	movaps %xmm0,0x1fb15(%rip)        # 246b0 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 95 eb 01 00 	lea    0x1eb95(%rip),%r8        # 23780 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 b0 fe 01 00 	mov    %rax,0x1feb0(%rip)        # 24b38 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 8e fe 01 00 	mov    %r12,0x1fe8e(%rip)        # 24b40 <fwp_heap+0x13c0>
    4cb2:	48 89 05 77 fe 01 00 	mov    %rax,0x1fe77(%rip)        # 24b30 <fwp_heap+0x13b0>
    4cb9:	48 89 1d 90 fe 01 00 	mov    %rbx,0x1fe90(%rip)        # 24b50 <fwp_heap+0x13d0>
    4cc0:	48 89 35 b9 fe 01 00 	mov    %rsi,0x1feb9(%rip)        # 24b80 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 a3 00 00 	lea    0xa3d6(%rip),%rdi        # f0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 98 fe 01 00 	mov    %rax,0x1fe98(%rip)        # 24b78 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 1c fe 01 00    	mov    %eax,0x1fe1c(%rip)        # 24b28 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <fwp_wake_io>:
    4d20:	48 8b 07             	mov    (%rdi),%rax
    4d23:	48 85 c0             	test   %rax,%rax
    4d26:	0f 84 f4 00 00 00    	je     4e20 <fwp_wake_io+0x100>
    4d2c:	53                   	push   %rbx
    4d2d:	4c 8b 05 0c ea 01 00 	mov    0x1ea0c(%rip),%r8        # 23740 <fwp_ready_tail>
    4d34:	49 89 f9             	mov    %rdi,%r9
    4d37:	48 89 c2             	mov    %rax,%rdx
    4d3a:	45 31 db             	xor    %r11d,%r11d
    4d3d:	45 31 d2             	xor    %r10d,%r10d
    4d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d44:	eb 71                	jmp    4db7 <fwp_wake_io+0x97>
    4d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4d4d:	00 00 00 
    4d50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4d57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d5e:	48 85 c9             	test   %rcx,%rcx
    4d61:	74 07                	je     4d6a <fwp_wake_io+0x4a>
    4d63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4d6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4d71:	00 00 00 00 
    4d75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4d7c:	49 8b 01             	mov    (%r9),%rax
    4d7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4d83:	75 2a                	jne    4daf <fwp_wake_io+0x8f>
    4d85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4d89:	75 24                	jne    4daf <fwp_wake_io+0x8f>
    4d8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4d8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4d96:	00 00 00 00 
    4d9a:	4d 85 c0             	test   %r8,%r8
    4d9d:	74 51                	je     4df0 <fwp_wake_io+0xd0>
    4d9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4da6:	49 89 d0             	mov    %rdx,%r8
    4da9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4daf:	48 89 c2             	mov    %rax,%rdx
    4db2:	48 85 c0             	test   %rax,%rax
    4db5:	74 49                	je     4e00 <fwp_wake_io+0xe0>
    4db7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4dbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4dc2:	48 85 ff             	test   %rdi,%rdi
    4dc5:	74 b8                	je     4d7f <fwp_wake_io+0x5f>
    4dc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4dce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dd5:	48 85 f6             	test   %rsi,%rsi
    4dd8:	0f 85 72 ff ff ff    	jne    4d50 <fwp_wake_io+0x30>
    4dde:	48 89 0f             	mov    %rcx,(%rdi)
    4de1:	e9 78 ff ff ff       	jmp    4d5e <fwp_wake_io+0x3e>
    4de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4ded:	00 00 00 
    4df0:	48 89 d3             	mov    %rdx,%rbx
    4df3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4df9:	eb ab                	jmp    4da6 <fwp_wake_io+0x86>
    4dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e00:	45 84 db             	test   %r11b,%r11b
    4e03:	74 07                	je     4e0c <fwp_wake_io+0xec>
    4e05:	48 89 1d 3c e9 01 00 	mov    %rbx,0x1e93c(%rip)        # 23748 <fwp_ready_head>
    4e0c:	45 84 d2             	test   %r10b,%r10b
    4e0f:	74 07                	je     4e18 <fwp_wake_io+0xf8>
    4e11:	4c 89 05 28 e9 01 00 	mov    %r8,0x1e928(%rip)        # 23740 <fwp_ready_tail>
    4e18:	5b                   	pop    %rbx
    4e19:	c3                   	ret
    4e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e20:	c3                   	ret
    4e21:	0f 1f 40 00          	nopl   0x0(%rax)
    4e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e2c:	00 00 00 00 

0000000000004e30 <fwp_tape_buffers_release>:
    4e30:	f3 0f 1e fa          	endbr64
    4e34:	53                   	push   %rbx
    4e35:	48 89 fb             	mov    %rdi,%rbx
    4e38:	48 83 ec 10          	sub    $0x10,%rsp
    4e3c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4e40:	48 85 c0             	test   %rax,%rax
    4e43:	0f 88 df 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e49:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4e4d:	48 85 d2             	test   %rdx,%rdx
    4e50:	0f 88 d2 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e56:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4e5c:	0f 87 c6 00 00 00    	ja     4f28 <fwp_tape_buffers_release+0xf8>
    4e62:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4e66:	b8 00 00 08 00       	mov    $0x80000,%eax
    4e6b:	48 c1 e1 03          	shl    $0x3,%rcx
    4e6f:	48 29 c8             	sub    %rcx,%rax
    4e72:	48 c1 e8 03          	shr    $0x3,%rax
    4e76:	48 39 d0             	cmp    %rdx,%rax
    4e79:	0f 82 a9 00 00 00    	jb     4f28 <fwp_tape_buffers_release+0xf8>
    4e7f:	48 8d 3d 39 a2 00 00 	lea    0xa239(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    4e86:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e8b:	48 89 14 24          	mov    %rdx,(%rsp)
    4e8f:	e8 0c e5 ff ff       	call   33a0 <getenv@plt>
    4e94:	48 8b 14 24          	mov    (%rsp),%rdx
    4e98:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e9d:	48 85 c0             	test   %rax,%rax
    4ea0:	74 09                	je     4eab <fwp_tape_buffers_release+0x7b>
    4ea2:	80 38 30             	cmpb   $0x30,(%rax)
    4ea5:	0f 84 9d 00 00 00    	je     4f48 <fwp_tape_buffers_release+0x118>
    4eab:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4eaf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4eb3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4eba:	77 78                	ja     4f34 <fwp_tape_buffers_release+0x104>
    4ebc:	48 8d 3d fd e1 01 00 	lea    0x1e1fd(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    4ec3:	48 89 04 24          	mov    %rax,(%rsp)
    4ec7:	e8 a4 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4ecc:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4ed0:	48 8b 04 24          	mov    (%rsp),%rax
    4ed4:	0f 29 05 e5 e1 01 00 	movaps %xmm0,0x1e1e5(%rip)        # 230c0 <fwp_tape_workspace>
    4edb:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4ee0:	48 89 05 c1 e1 01 00 	mov    %rax,0x1e1c1(%rip)        # 230a8 <fwp_tape_cached_bytes>
    4ee7:	0f 29 05 e2 e1 01 00 	movaps %xmm0,0x1e1e2(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    4eee:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4ef3:	0f 29 05 e6 e1 01 00 	movaps %xmm0,0x1e1e6(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    4efa:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4efe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f02:	48 89 15 e7 e1 01 00 	mov    %rdx,0x1e1e7(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    4f09:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f10:	00 
    4f11:	0f 11 03             	movups %xmm0,(%rbx)
    4f14:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f18:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f1c:	48 83 c4 10          	add    $0x10,%rsp
    4f20:	5b                   	pop    %rbx
    4f21:	c3                   	ret
    4f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f28:	48 8d 3d 90 a1 00 00 	lea    0xa190(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    4f2f:	e8 6c e4 ff ff       	call   33a0 <getenv@plt>
    4f34:	48 83 c4 10          	add    $0x10,%rsp
    4f38:	48 89 df             	mov    %rbx,%rdi
    4f3b:	5b                   	pop    %rbx
    4f3c:	e9 2f f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f48:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4f4c:	0f 85 59 ff ff ff    	jne    4eab <fwp_tape_buffers_release+0x7b>
    4f52:	48 83 c4 10          	add    $0x10,%rsp
    4f56:	48 89 df             	mov    %rbx,%rdi
    4f59:	5b                   	pop    %rbx
    4f5a:	e9 11 f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f5f:	90                   	nop

0000000000004f60 <fwp_poll_events>:
    4f60:	53                   	push   %rbx
    4f61:	48 83 ec 20          	sub    $0x20,%rsp
    4f65:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4f6c:	00 00 
    4f6e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4f73:	31 c0                	xor    %eax,%eax
    4f75:	e8 96 f3 ff ff       	call   4310 <fwp_now_ns>
    4f7a:	48 8b 1d b7 e7 01 00 	mov    0x1e7b7(%rip),%rbx        # 23738 <fwp_timers>
    4f81:	48 85 db             	test   %rbx,%rbx
    4f84:	0f 84 d6 00 00 00    	je     5060 <fwp_poll_events+0x100>
    4f8a:	48 89 c6             	mov    %rax,%rsi
    4f8d:	48 89 da             	mov    %rbx,%rdx
    4f90:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4f97:	eb 16                	jmp    4faf <fwp_poll_events+0x4f>
    4f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fa7:	48 89 c8             	mov    %rcx,%rax
    4faa:	48 85 d2             	test   %rdx,%rdx
    4fad:	74 31                	je     4fe0 <fwp_poll_events+0x80>
    4faf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fb3:	48 85 c0             	test   %rax,%rax
    4fb6:	78 e8                	js     4fa0 <fwp_poll_events+0x40>
    4fb8:	48 39 c1             	cmp    %rax,%rcx
    4fbb:	7c e3                	jl     4fa0 <fwp_poll_events+0x40>
    4fbd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fc4:	48 85 d2             	test   %rdx,%rdx
    4fc7:	74 1c                	je     4fe5 <fwp_poll_events+0x85>
    4fc9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fcd:	48 39 c1             	cmp    %rax,%rcx
    4fd0:	7c ce                	jl     4fa0 <fwp_poll_events+0x40>
    4fd2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fd9:	48 85 d2             	test   %rdx,%rdx
    4fdc:	75 d1                	jne    4faf <fwp_poll_events+0x4f>
    4fde:	66 90                	xchg   %ax,%ax
    4fe0:	48 85 c0             	test   %rax,%rax
    4fe3:	78 7b                	js     5060 <fwp_poll_events+0x100>
    4fe5:	48 29 f0             	sub    %rsi,%rax
    4fe8:	48 89 c1             	mov    %rax,%rcx
    4feb:	48 85 c0             	test   %rax,%rax
    4fee:	0f 8e 9c 00 00 00    	jle    5090 <fwp_poll_events+0x130>
    4ff4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    4ffb:	de 1b 43 
    4ffe:	48 f7 ea             	imul   %rdx
    5001:	48 89 c8             	mov    %rcx,%rax
    5004:	48 c1 f8 3f          	sar    $0x3f,%rax
    5008:	48 c1 fa 12          	sar    $0x12,%rdx
    500c:	48 29 c2             	sub    %rax,%rdx
    500f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5016:	48 39 c1             	cmp    %rax,%rcx
    5019:	0f 95 c0             	setne  %al
    501c:	0f b6 c0             	movzbl %al,%eax
    501f:	48 01 d0             	add    %rdx,%rax
    5022:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5028:	0f 8f 32 01 00 00    	jg     5160 <fwp_poll_events+0x200>
    502e:	48 85 c0             	test   %rax,%rax
    5031:	74 5d                	je     5090 <fwp_poll_events+0x130>
    5033:	89 c1                	mov    %eax,%ecx
    5035:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    503c:	48 c1 e9 26          	shr    $0x26,%rcx
    5040:	48 63 d1             	movslq %ecx,%rdx
    5043:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5049:	29 c8                	sub    %ecx,%eax
    504b:	48 98                	cltq
    504d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5054:	e9 11 01 00 00       	jmp    516a <fwp_poll_events+0x20a>
    5059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5060:	e8 0b ec ff ff       	call   3c70 <fwp_flush>
    5065:	ba 2b 00 00 00       	mov    $0x2b,%edx
    506a:	be 01 00 00 00       	mov    $0x1,%esi
    506f:	48 8b 0d ea df 00 00 	mov    0xdfea(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    5076:	48 8d 3d c3 a6 00 00 	lea    0xa6c3(%rip),%rdi        # f740 <_IO_stdin_used+0x740>
    507d:	e8 fe e5 ff ff       	call   3680 <fwrite@plt>
    5082:	bf 65 00 00 00       	mov    $0x65,%edi
    5087:	e8 e4 e5 ff ff       	call   3670 <exit@plt>
    508c:	0f 1f 40 00          	nopl   0x0(%rax)
    5090:	e8 7b f2 ff ff       	call   4310 <fwp_now_ns>
    5095:	48 89 c1             	mov    %rax,%rcx
    5098:	66 0f ef c0          	pxor   %xmm0,%xmm0
    509c:	eb 44                	jmp    50e2 <fwp_poll_events+0x182>
    509e:	66 90                	xchg   %ax,%ax
    50a0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    50a4:	75 33                	jne    50d9 <fwp_poll_events+0x179>
    50a6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    50aa:	75 2d                	jne    50d9 <fwp_poll_events+0x179>
    50ac:	48 8b 05 8d e6 01 00 	mov    0x1e68d(%rip),%rax        # 23740 <fwp_ready_tail>
    50b3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    50b7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    50be:	00 00 00 00 
    50c2:	48 85 c0             	test   %rax,%rax
    50c5:	0f 84 05 01 00 00    	je     51d0 <fwp_poll_events+0x270>
    50cb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    50d2:	48 89 15 67 e6 01 00 	mov    %rdx,0x1e667(%rip)        # 23740 <fwp_ready_tail>
    50d9:	48 85 db             	test   %rbx,%rbx
    50dc:	0f 84 be 00 00 00    	je     51a0 <fwp_poll_events+0x240>
    50e2:	48 89 da             	mov    %rbx,%rdx
    50e5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    50ec:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    50f0:	7f e7                	jg     50d9 <fwp_poll_events+0x179>
    50f2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    50f6:	74 2e                	je     5126 <fwp_poll_events+0x1c6>
    50f8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    50ff:	48 85 c0             	test   %rax,%rax
    5102:	0f 84 b8 00 00 00    	je     51c0 <fwp_poll_events+0x260>
    5108:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    510f:	48 85 db             	test   %rbx,%rbx
    5112:	74 07                	je     511b <fwp_poll_events+0x1bb>
    5114:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    511b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    511f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5126:	48 8b 42 60          	mov    0x60(%rdx),%rax
    512a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    512e:	48 85 c0             	test   %rax,%rax
    5131:	0f 84 69 ff ff ff    	je     50a0 <fwp_poll_events+0x140>
    5137:	48 39 c8             	cmp    %rcx,%rax
    513a:	0f 8f 60 ff ff ff    	jg     50a0 <fwp_poll_events+0x140>
    5140:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5144:	0f 85 56 ff ff ff    	jne    50a0 <fwp_poll_events+0x140>
    514a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    514e:	75 89                	jne    50d9 <fwp_poll_events+0x179>
    5150:	48 89 d7             	mov    %rdx,%rdi
    5153:	e8 58 ef ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    5158:	e9 43 ff ff ff       	jmp    50a0 <fwp_poll_events+0x140>
    515d:	0f 1f 00             	nopl   (%rax)
    5160:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5165:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    516a:	48 89 e7             	mov    %rsp,%rdi
    516d:	31 f6                	xor    %esi,%esi
    516f:	48 89 14 24          	mov    %rdx,(%rsp)
    5173:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5178:	e8 23 e3 ff ff       	call   34a0 <nanosleep@plt>
    517d:	48 8b 1d b4 e5 01 00 	mov    0x1e5b4(%rip),%rbx        # 23738 <fwp_timers>
    5184:	e8 87 f1 ff ff       	call   4310 <fwp_now_ns>
    5189:	48 89 c1             	mov    %rax,%rcx
    518c:	48 85 db             	test   %rbx,%rbx
    518f:	0f 85 03 ff ff ff    	jne    5098 <fwp_poll_events+0x138>
    5195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    519c:	00 00 00 00 
    51a0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    51a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	75 2c                	jne    51dc <fwp_poll_events+0x27c>
    51b0:	48 83 c4 20          	add    $0x20,%rsp
    51b4:	5b                   	pop    %rbx
    51b5:	c3                   	ret
    51b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51bd:	00 00 00 
    51c0:	48 89 1d 71 e5 01 00 	mov    %rbx,0x1e571(%rip)        # 23738 <fwp_timers>
    51c7:	e9 43 ff ff ff       	jmp    510f <fwp_poll_events+0x1af>
    51cc:	0f 1f 40 00          	nopl   0x0(%rax)
    51d0:	48 89 15 71 e5 01 00 	mov    %rdx,0x1e571(%rip)        # 23748 <fwp_ready_head>
    51d7:	e9 f6 fe ff ff       	jmp    50d2 <fwp_poll_events+0x172>
    51dc:	e8 7f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    51e1:	0f 1f 40 00          	nopl   0x0(%rax)
    51e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51ec:	00 00 00 00 

00000000000051f0 <fwp_rc_wide_dup>:
    51f0:	48 89 fa             	mov    %rdi,%rdx
    51f3:	48 8d 35 86 e5 01 00 	lea    0x1e586(%rip),%rsi        # 23780 <fwp_heap>
    51fa:	48 83 ec 18          	sub    $0x18,%rsp
    51fe:	48 89 f9             	mov    %rdi,%rcx
    5201:	48 c1 ea 11          	shr    $0x11,%rdx
    5205:	48 31 fa             	xor    %rdi,%rdx
    5208:	48 89 d0             	mov    %rdx,%rax
    520b:	48 c1 e8 09          	shr    $0x9,%rax
    520f:	48 31 c2             	xor    %rax,%rdx
    5212:	0f b6 d2             	movzbl %dl,%edx
    5215:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    521c:	00 
    521d:	49 8b 00             	mov    (%r8),%rax
    5220:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5227:	00 00 
    5229:	75 21                	jne    524c <fwp_rc_wide_dup+0x5c>
    522b:	e9 98 00 00 00       	jmp    52c8 <fwp_rc_wide_dup+0xd8>
    5230:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 
    5240:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5244:	48 85 d2             	test   %rdx,%rdx
    5247:	74 2f                	je     5278 <fwp_rc_wide_dup+0x88>
    5249:	48 89 d0             	mov    %rdx,%rax
    524c:	48 3b 08             	cmp    (%rax),%rcx
    524f:	75 ef                	jne    5240 <fwp_rc_wide_dup+0x50>
    5251:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5254:	74 7c                	je     52d2 <fwp_rc_wide_dup+0xe2>
    5256:	48 8b 50 08          	mov    0x8(%rax),%rdx
    525a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    525e:	0f 84 91 00 00 00    	je     52f5 <fwp_rc_wide_dup+0x105>
    5264:	48 83 c2 01          	add    $0x1,%rdx
    5268:	48 89 50 08          	mov    %rdx,0x8(%rax)
    526c:	48 83 c4 18          	add    $0x18,%rsp
    5270:	c3                   	ret
    5271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5278:	4c 8d 40 10          	lea    0x10(%rax),%r8
    527c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    527f:	75 68                	jne    52e9 <fwp_rc_wide_dup+0xf9>
    5281:	bf 18 00 00 00       	mov    $0x18,%edi
    5286:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    528b:	4c 89 04 24          	mov    %r8,(%rsp)
    528f:	e8 1c e3 ff ff       	call   35b0 <malloc@plt>
    5294:	4c 8b 04 24          	mov    (%rsp),%r8
    5298:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    529d:	48 85 c0             	test   %rax,%rax
    52a0:	74 5f                	je     5301 <fwp_rc_wide_dup+0x111>
    52a2:	48 89 08             	mov    %rcx,(%rax)
    52a5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    52ac:	00 
    52ad:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    52b4:	00 
    52b5:	49 89 00             	mov    %rax,(%r8)
    52b8:	c6 01 ff             	movb   $0xff,(%rcx)
    52bb:	48 83 05 05 01 02 00 	addq   $0x1,0x20105(%rip)        # 253c8 <fwp_heap+0x1c48>
    52c2:	01 
    52c3:	48 83 c4 18          	add    $0x18,%rsp
    52c7:	c3                   	ret
    52c8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    52cb:	75 13                	jne    52e0 <fwp_rc_wide_dup+0xf0>
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 af                	je     5281 <fwp_rc_wide_dup+0x91>
    52d2:	48 8d 3d 97 a4 00 00 	lea    0xa497(%rip),%rdi        # f770 <_IO_stdin_used+0x770>
    52d9:	e8 c2 ee ff ff       	call   41a0 <fwp_trap>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	48 85 c0             	test   %rax,%rax
    52e3:	0f 85 6d ff ff ff    	jne    5256 <fwp_rc_wide_dup+0x66>
    52e9:	48 8d 3d a8 a4 00 00 	lea    0xa4a8(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    52f0:	e8 ab ee ff ff       	call   41a0 <fwp_trap>
    52f5:	48 8d 3d d4 9d 00 00 	lea    0x9dd4(%rip),%rdi        # f0d0 <_IO_stdin_used+0xd0>
    52fc:	e8 9f ee ff ff       	call   41a0 <fwp_trap>
    5301:	e8 aa e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    530d:	00 00 00 

0000000000005310 <fwp_rc_forget_slot>:
    5310:	80 3f ff             	cmpb   $0xff,(%rdi)
    5313:	74 0b                	je     5320 <fwp_rc_forget_slot+0x10>
    5315:	c3                   	ret
    5316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    531d:	00 00 00 
    5320:	48 89 f8             	mov    %rdi,%rax
    5323:	48 83 ec 08          	sub    $0x8,%rsp
    5327:	48 89 fa             	mov    %rdi,%rdx
    532a:	48 c1 e8 11          	shr    $0x11,%rax
    532e:	48 31 f8             	xor    %rdi,%rax
    5331:	48 89 c1             	mov    %rax,%rcx
    5334:	48 c1 e9 09          	shr    $0x9,%rcx
    5338:	48 31 c8             	xor    %rcx,%rax
    533b:	48 8d 0d 3e e4 01 00 	lea    0x1e43e(%rip),%rcx        # 23780 <fwp_heap>
    5342:	0f b6 c0             	movzbl %al,%eax
    5345:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    534c:	00 
    534d:	48 85 ff             	test   %rdi,%rdi
    5350:	74 3c                	je     538e <fwp_rc_forget_slot+0x7e>
    5352:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5359:	00 
    535a:	48 8b 01             	mov    (%rcx),%rax
    535d:	eb 11                	jmp    5370 <fwp_rc_forget_slot+0x60>
    535f:	90                   	nop
    5360:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5364:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5368:	48 85 ff             	test   %rdi,%rdi
    536b:	74 21                	je     538e <fwp_rc_forget_slot+0x7e>
    536d:	48 89 f8             	mov    %rdi,%rax
    5370:	48 3b 10             	cmp    (%rax),%rdx
    5373:	75 eb                	jne    5360 <fwp_rc_forget_slot+0x50>
    5375:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5379:	48 89 01             	mov    %rax,(%rcx)
    537c:	e8 3f e0 ff ff       	call   33c0 <free@plt>
    5381:	48 83 2d 3f 00 02 00 	subq   $0x1,0x2003f(%rip)        # 253c8 <fwp_heap+0x1c48>
    5388:	01 
    5389:	48 83 c4 08          	add    $0x8,%rsp
    538d:	c3                   	ret
    538e:	48 8d 3d 03 a4 00 00 	lea    0xa403(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    5395:	e8 06 ee ff ff       	call   41a0 <fwp_trap>
    539a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000053a0 <fwp_rc_prepare_chunk>:
    53a0:	48 83 3d 20 00 02 00 	cmpq   $0x0,0x20020(%rip)        # 253c8 <fwp_heap+0x1c48>
    53a7:	00 
    53a8:	41 54                	push   %r12
    53aa:	49 89 f4             	mov    %rsi,%r12
    53ad:	55                   	push   %rbp
    53ae:	48 89 fd             	mov    %rdi,%rbp
    53b1:	53                   	push   %rbx
    53b2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    53b5:	0f 84 7d 00 00 00    	je     5438 <fwp_rc_prepare_chunk+0x98>
    53bb:	31 db                	xor    %ebx,%ebx
    53bd:	85 c0                	test   %eax,%eax
    53bf:	75 5f                	jne    5420 <fwp_rc_prepare_chunk+0x80>
    53c1:	48 85 f6             	test   %rsi,%rsi
    53c4:	74 7c                	je     5442 <fwp_rc_prepare_chunk+0xa2>
    53c6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    53ca:	e8 f1 df ff ff       	call   33c0 <free@plt>
    53cf:	90                   	nop
    53d0:	be 01 00 00 00       	mov    $0x1,%esi
    53d5:	4c 89 e7             	mov    %r12,%rdi
    53d8:	e8 43 e1 ff ff       	call   3520 <calloc@plt>
    53dd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    53e1:	48 85 c0             	test   %rax,%rax
    53e4:	0f 85 87 00 00 00    	jne    5471 <fwp_rc_prepare_chunk+0xd1>
    53ea:	e8 c1 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    53ef:	90                   	nop
    53f0:	e8 1b ff ff ff       	call   5310 <fwp_rc_forget_slot>
    53f5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53f8:	48 83 c3 01          	add    $0x1,%rbx
    53fc:	48 39 c3             	cmp    %rax,%rbx
    53ff:	73 37                	jae    5438 <fwp_rc_prepare_chunk+0x98>
    5401:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5408:	00 00 
    540a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5411:	00 00 00 00 
    5415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    541c:	00 00 00 00 
    5420:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5424:	48 01 df             	add    %rbx,%rdi
    5427:	80 3f ff             	cmpb   $0xff,(%rdi)
    542a:	74 c4                	je     53f0 <fwp_rc_prepare_chunk+0x50>
    542c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    542f:	48 83 c3 01          	add    $0x1,%rbx
    5433:	48 39 c3             	cmp    %rax,%rbx
    5436:	72 e8                	jb     5420 <fwp_rc_prepare_chunk+0x80>
    5438:	49 39 c4             	cmp    %rax,%r12
    543b:	75 13                	jne    5450 <fwp_rc_prepare_chunk+0xb0>
    543d:	4d 85 e4             	test   %r12,%r12
    5440:	75 46                	jne    5488 <fwp_rc_prepare_chunk+0xe8>
    5442:	5b                   	pop    %rbx
    5443:	5d                   	pop    %rbp
    5444:	41 5c                	pop    %r12
    5446:	c3                   	ret
    5447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    544e:	00 00 
    5450:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5454:	48 29 05 75 ff 01 00 	sub    %rax,0x1ff75(%rip)        # 253d0 <fwp_heap+0x1c50>
    545b:	e8 60 df ff ff       	call   33c0 <free@plt>
    5460:	4d 85 e4             	test   %r12,%r12
    5463:	0f 85 67 ff ff ff    	jne    53d0 <fwp_rc_prepare_chunk+0x30>
    5469:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5470:	00 
    5471:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5475:	5b                   	pop    %rbx
    5476:	4c 01 25 53 ff 01 00 	add    %r12,0x1ff53(%rip)        # 253d0 <fwp_heap+0x1c50>
    547d:	5d                   	pop    %rbp
    547e:	41 5c                	pop    %r12
    5480:	c3                   	ret
    5481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5488:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    548c:	5b                   	pop    %rbx
    548d:	4c 89 e2             	mov    %r12,%rdx
    5490:	31 f6                	xor    %esi,%esi
    5492:	5d                   	pop    %rbp
    5493:	41 5c                	pop    %r12
    5495:	e9 26 e0 ff ff       	jmp    34c0 <memset@plt>
    549a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000054a0 <fwp_heap_refill>:
    54a0:	41 56                	push   %r14
    54a2:	41 89 d6             	mov    %edx,%r14d
    54a5:	41 55                	push   %r13
    54a7:	41 89 f5             	mov    %esi,%r13d
    54aa:	41 54                	push   %r12
    54ac:	49 89 fc             	mov    %rdi,%r12
    54af:	bf 01 00 00 00       	mov    $0x1,%edi
    54b4:	55                   	push   %rbp
    54b5:	53                   	push   %rbx
    54b6:	e8 25 e9 ff ff       	call   3de0 <fwp_heap_chunks>
    54bb:	48 89 c3             	mov    %rax,%rbx
    54be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    54c2:	48 8b 05 af f6 01 00 	mov    0x1f6af(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    54c9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    54cd:	48 8d 05 ac e2 01 00 	lea    0x1e2ac(%rip),%rax        # 23780 <fwp_heap>
    54d4:	31 d2                	xor    %edx,%edx
    54d6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    54da:	48 89 ef             	mov    %rbp,%rdi
    54dd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    54e1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    54e5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    54ec:	00 
    54ed:	b8 00 00 01 00       	mov    $0x10000,%eax
    54f2:	f7 f1                	div    %ecx
    54f4:	31 d2                	xor    %edx,%edx
    54f6:	66 0f 6e c1          	movd   %ecx,%xmm0
    54fa:	66 0f 6e c8          	movd   %eax,%xmm1
    54fe:	89 c6                	mov    %eax,%esi
    5500:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5505:	48 01 c8             	add    %rcx,%rax
    5508:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    550c:	48 f7 f1             	div    %rcx
    550f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5514:	89 45 18             	mov    %eax,0x18(%rbp)
    5517:	e8 84 fe ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    551c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    551f:	48 89 d8             	mov    %rbx,%rax
    5522:	48 c1 e0 10          	shl    $0x10,%rax
    5526:	48 03 05 03 f6 01 00 	add    0x1f603(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    552d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5531:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5536:	8b 55 08             	mov    0x8(%rbp),%edx
    5539:	48 0f af d1          	imul   %rcx,%rdx
    553d:	48 01 c2             	add    %rax,%rdx
    5540:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5545:	5b                   	pop    %rbx
    5546:	5d                   	pop    %rbp
    5547:	41 5c                	pop    %r12
    5549:	41 5d                	pop    %r13
    554b:	41 5e                	pop    %r14
    554d:	c3                   	ret
    554e:	66 90                	xchg   %ax,%ax

0000000000005550 <fwp_mem_free>:
    5550:	48 85 ff             	test   %rdi,%rdi
    5553:	0f 84 17 02 00 00    	je     5770 <fwp_mem_free+0x220>
    5559:	48 8b 35 d0 f5 01 00 	mov    0x1f5d0(%rip),%rsi        # 24b30 <fwp_heap+0x13b0>
    5560:	48 8b 05 f1 f5 01 00 	mov    0x1f5f1(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 29 f2             	sub    %rsi,%rdx
    556d:	48 c1 e0 10          	shl    $0x10,%rax
    5571:	48 39 c2             	cmp    %rax,%rdx
    5574:	0f 83 f6 01 00 00    	jae    5770 <fwp_mem_free+0x220>
    557a:	49 89 d1             	mov    %rdx,%r9
    557d:	49 c1 e9 10          	shr    $0x10,%r9
    5581:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5585:	48 c1 e0 03          	shl    $0x3,%rax
    5589:	49 89 c0             	mov    %rax,%r8
    558c:	4c 03 05 e5 f5 01 00 	add    0x1f5e5(%rip),%r8        # 24b78 <fwp_heap+0x13f8>
    5593:	0f 84 d7 01 00 00    	je     5770 <fwp_mem_free+0x220>
    5599:	48 83 ec 38          	sub    $0x38,%rsp
    559d:	48 89 f9             	mov    %rdi,%rcx
    55a0:	41 0f b6 38          	movzbl (%r8),%edi
    55a4:	40 80 ff 01          	cmp    $0x1,%dil
    55a8:	74 16                	je     55c0 <fwp_mem_free+0x70>
    55aa:	40 80 ff 02          	cmp    $0x2,%dil
    55ae:	0f 84 94 00 00 00    	je     5648 <fwp_mem_free+0xf8>
    55b4:	48 83 c4 38          	add    $0x38,%rsp
    55b8:	c3                   	ret
    55b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    55c0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    55c4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    55c9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    55ce:	41 8b 78 04          	mov    0x4(%r8),%edi
    55d2:	4d 85 d2             	test   %r10,%r10
    55d5:	74 1d                	je     55f4 <fwp_mem_free+0xa4>
    55d7:	0f b7 c1             	movzwl %cx,%eax
    55da:	31 d2                	xor    %edx,%edx
    55dc:	48 f7 f7             	div    %rdi
    55df:	49 01 c2             	add    %rax,%r10
    55e2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    55e6:	0f 84 44 01 00 00    	je     5730 <fwp_mem_free+0x1e0>
    55ec:	41 c6 02 00          	movb   $0x0,(%r10)
    55f0:	41 8b 78 04          	mov    0x4(%r8),%edi
    55f4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    55fb:	49 63 c1             	movslq %r9d,%rax
    55fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5602:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5606:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    560b:	f2 0f 58 05 ad f5 01 	addsd  0x1f5ad(%rip),%xmm0        # 24bc0 <fwp_heap+0x1440>
    5612:	00 
    5613:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5617:	48 8d 05 62 e1 01 00 	lea    0x1e162(%rip),%rax        # 23780 <fwp_heap>
    561e:	48 01 d0             	add    %rdx,%rax
    5621:	48 8b 10             	mov    (%rax),%rdx
    5624:	48 f7 d2             	not    %rdx
    5627:	48 89 11             	mov    %rdx,(%rcx)
    562a:	48 89 08             	mov    %rcx,(%rax)
    562d:	48 29 3d 6c f5 01 00 	sub    %rdi,0x1f56c(%rip)        # 24ba0 <fwp_heap+0x1420>
    5634:	f2 0f 11 05 84 f5 01 	movsd  %xmm0,0x1f584(%rip)        # 24bc0 <fwp_heap+0x1440>
    563b:	00 
    563c:	48 83 c4 38          	add    $0x38,%rsp
    5640:	c3                   	ret
    5641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5648:	66 31 d2             	xor    %dx,%dx
    564b:	48 01 d6             	add    %rdx,%rsi
    564e:	48 39 f1             	cmp    %rsi,%rcx
    5651:	0f 85 5d ff ff ff    	jne    55b4 <fwp_mem_free+0x64>
    5657:	49 8b 50 10          	mov    0x10(%r8),%rdx
    565b:	48 29 15 3e f5 01 00 	sub    %rdx,0x1f53e(%rip)        # 24ba0 <fwp_heap+0x1420>
    5662:	48 85 d2             	test   %rdx,%rdx
    5665:	0f 88 a5 00 00 00    	js     5710 <fwp_mem_free+0x1c0>
    566b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    566f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5674:	f2 0f 58 05 44 f5 01 	addsd  0x1f544(%rip),%xmm0        # 24bc0 <fwp_heap+0x1440>
    567b:	00 
    567c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5680:	f2 0f 11 05 38 f5 01 	movsd  %xmm0,0x1f538(%rip)        # 24bc0 <fwp_heap+0x1440>
    5687:	00 
    5688:	48 85 d2             	test   %rdx,%rdx
    568b:	74 0c                	je     5699 <fwp_mem_free+0x149>
    568d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5690:	0f 84 db 00 00 00    	je     5771 <fwp_mem_free+0x221>
    5696:	c6 02 00             	movb   $0x0,(%rdx)
    5699:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    569d:	48 85 c9             	test   %rcx,%rcx
    56a0:	74 3e                	je     56e0 <fwp_mem_free+0x190>
    56a2:	48 8b 15 cf f4 01 00 	mov    0x1f4cf(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    56a9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    56ad:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    56b1:	48 01 d0             	add    %rdx,%rax
    56b4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    56b8:	48 89 d6             	mov    %rdx,%rsi
    56bb:	48 29 c6             	sub    %rax,%rsi
    56be:	83 e6 08             	and    $0x8,%esi
    56c1:	74 0d                	je     56d0 <fwp_mem_free+0x180>
    56c3:	c6 00 00             	movb   $0x0,(%rax)
    56c6:	48 83 c0 28          	add    $0x28,%rax
    56ca:	48 39 c2             	cmp    %rax,%rdx
    56cd:	74 11                	je     56e0 <fwp_mem_free+0x190>
    56cf:	90                   	nop
    56d0:	c6 00 00             	movb   $0x0,(%rax)
    56d3:	48 83 c0 50          	add    $0x50,%rax
    56d7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    56db:	48 39 c2             	cmp    %rax,%rdx
    56de:	75 f0                	jne    56d0 <fwp_mem_free+0x180>
    56e0:	48 01 0d c9 f4 01 00 	add    %rcx,0x1f4c9(%rip)        # 24bb0 <fwp_heap+0x1430>
    56e7:	4c 3b 0d 82 f4 01 00 	cmp    0x1f482(%rip),%r9        # 24b70 <fwp_heap+0x13f0>
    56ee:	73 07                	jae    56f7 <fwp_mem_free+0x1a7>
    56f0:	4c 89 0d 79 f4 01 00 	mov    %r9,0x1f479(%rip)        # 24b70 <fwp_heap+0x13f0>
    56f7:	4c 3b 0d 6a f4 01 00 	cmp    0x1f46a(%rip),%r9        # 24b68 <fwp_heap+0x13e8>
    56fe:	0f 83 b0 fe ff ff    	jae    55b4 <fwp_mem_free+0x64>
    5704:	4c 89 0d 5d f4 01 00 	mov    %r9,0x1f45d(%rip)        # 24b68 <fwp_heap+0x13e8>
    570b:	e9 a4 fe ff ff       	jmp    55b4 <fwp_mem_free+0x64>
    5710:	48 89 d1             	mov    %rdx,%rcx
    5713:	83 e2 01             	and    $0x1,%edx
    5716:	66 0f ef c0          	pxor   %xmm0,%xmm0
    571a:	48 d1 e9             	shr    $1,%rcx
    571d:	48 09 d1             	or     %rdx,%rcx
    5720:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5725:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5729:	e9 46 ff ff ff       	jmp    5674 <fwp_mem_free+0x124>
    572e:	66 90                	xchg   %ax,%ax
    5730:	4c 89 d7             	mov    %r10,%rdi
    5733:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5738:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    573d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5742:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5746:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    574b:	e8 c0 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    5750:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5755:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    575a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    575f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5764:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5769:	e9 7e fe ff ff       	jmp    55ec <fwp_mem_free+0x9c>
    576e:	66 90                	xchg   %ax,%ax
    5770:	c3                   	ret
    5771:	48 89 d7             	mov    %rdx,%rdi
    5774:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5779:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    577e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5783:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5788:	e8 83 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    578d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5792:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5797:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    579c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    57a1:	e9 f0 fe ff ff       	jmp    5696 <fwp_mem_free+0x146>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_heap_alloc_big>:
    57b0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    57b7:	00 00 40 
    57ba:	41 57                	push   %r15
    57bc:	41 56                	push   %r14
    57be:	41 55                	push   %r13
    57c0:	41 54                	push   %r12
    57c2:	55                   	push   %rbp
    57c3:	53                   	push   %rbx
    57c4:	48 83 ec 08          	sub    $0x8,%rsp
    57c8:	48 39 f8             	cmp    %rdi,%rax
    57cb:	0f 82 fa 00 00 00    	jb     58cb <fwp_heap_alloc_big+0x11b>
    57d1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    57d8:	49 89 fd             	mov    %rdi,%r13
    57db:	41 89 f6             	mov    %esi,%r14d
    57de:	48 c1 ed 10          	shr    $0x10,%rbp
    57e2:	48 89 ef             	mov    %rbp,%rdi
    57e5:	e8 f6 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    57ea:	be 01 00 00 00       	mov    $0x1,%esi
    57ef:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    57f3:	49 89 c4             	mov    %rax,%r12
    57f6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    57fd:	00 
    57fe:	48 03 3d 73 f3 01 00 	add    0x1f373(%rip),%rdi        # 24b78 <fwp_heap+0x13f8>
    5805:	c6 07 02             	movb   $0x2,(%rdi)
    5808:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    580c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    580f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5813:	e8 88 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5818:	48 83 fd 01          	cmp    $0x1,%rbp
    581c:	76 47                	jbe    5865 <fwp_heap_alloc_big+0xb5>
    581e:	4c 01 e5             	add    %r12,%rbp
    5821:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5828:	00 
    5829:	4c 8d 3d 50 df 01 00 	lea    0x1df50(%rip),%r15        # 23780 <fwp_heap>
    5830:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5835:	49 c1 e6 03          	shl    $0x3,%r14
    5839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5840:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5847:	31 f6                	xor    %esi,%esi
    5849:	48 01 dd             	add    %rbx,%rbp
    584c:	48 83 c3 28          	add    $0x28,%rbx
    5850:	48 89 ef             	mov    %rbp,%rdi
    5853:	e8 48 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5858:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    585c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5860:	49 39 de             	cmp    %rbx,%r14
    5863:	75 db                	jne    5840 <fwp_heap_alloc_big+0x90>
    5865:	49 c1 e4 10          	shl    $0x10,%r12
    5869:	4c 03 25 c0 f2 01 00 	add    0x1f2c0(%rip),%r12        # 24b30 <fwp_heap+0x13b0>
    5870:	4c 89 ea             	mov    %r13,%rdx
    5873:	31 f6                	xor    %esi,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 43 dc ff ff       	call   34c0 <memset@plt>
    587d:	4c 89 e8             	mov    %r13,%rax
    5880:	48 03 05 19 f3 01 00 	add    0x1f319(%rip),%rax        # 24ba0 <fwp_heap+0x1420>
    5887:	72 42                	jb     58cb <fwp_heap_alloc_big+0x11b>
    5889:	48 39 05 18 f3 01 00 	cmp    %rax,0x1f318(%rip)        # 24ba8 <fwp_heap+0x1428>
    5890:	48 89 05 09 f3 01 00 	mov    %rax,0x1f309(%rip)        # 24ba0 <fwp_heap+0x1420>
    5897:	73 07                	jae    58a0 <fwp_heap_alloc_big+0xf0>
    5899:	48 89 05 08 f3 01 00 	mov    %rax,0x1f308(%rip)        # 24ba8 <fwp_heap+0x1428>
    58a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a4:	4c 89 e0             	mov    %r12,%rax
    58a7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    58ac:	f2 0f 58 05 04 f3 01 	addsd  0x1f304(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    58b3:	00 
    58b4:	f2 0f 11 05 fc f2 01 	movsd  %xmm0,0x1f2fc(%rip)        # 24bb8 <fwp_heap+0x1438>
    58bb:	00 
    58bc:	48 83 c4 08          	add    $0x8,%rsp
    58c0:	5b                   	pop    %rbx
    58c1:	5d                   	pop    %rbp
    58c2:	41 5c                	pop    %r12
    58c4:	41 5d                	pop    %r13
    58c6:	41 5e                	pop    %r14
    58c8:	41 5f                	pop    %r15
    58ca:	c3                   	ret
    58cb:	e8 e0 e3 ff ff       	call   3cb0 <fwp_heap_oom>

00000000000058d0 <fwp_heap_alloc_slow>:
    58d0:	53                   	push   %rbx
    58d1:	48 89 f9             	mov    %rdi,%rcx
    58d4:	41 89 f1             	mov    %esi,%r9d
    58d7:	48 83 ec 10          	sub    $0x10,%rsp
    58db:	8b 05 43 f2 01 00    	mov    0x1f243(%rip),%eax        # 24b24 <fwp_heap+0x13a4>
    58e1:	85 c0                	test   %eax,%eax
    58e3:	0f 84 c7 00 00 00    	je     59b0 <fwp_heap_alloc_slow+0xe0>
    58e9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    58f0:	0f 87 dd 00 00 00    	ja     59d3 <fwp_heap_alloc_slow+0x103>
    58f6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    58fa:	48 8d 3d 7f de 01 00 	lea    0x1de7f(%rip),%rdi        # 23780 <fwp_heap>
    5901:	49 63 f1             	movslq %r9d,%rsi
    5904:	48 c1 e8 04          	shr    $0x4,%rax
    5908:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    590f:	00 00 
    5911:	41 0f b6 c2          	movzbl %r10b,%eax
    5915:	4c 89 d2             	mov    %r10,%rdx
    5918:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    591c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5923:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    592a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    592e:	48 01 f8             	add    %rdi,%rax
    5931:	4c 8b 00             	mov    (%rax),%r8
    5934:	4d 85 c0             	test   %r8,%r8
    5937:	0f 84 ab 00 00 00    	je     59e8 <fwp_heap_alloc_slow+0x118>
    593d:	49 8b 10             	mov    (%r8),%rdx
    5940:	48 f7 d2             	not    %rdx
    5943:	48 89 10             	mov    %rdx,(%rax)
    5946:	41 83 f9 01          	cmp    $0x1,%r9d
    594a:	4c 89 c7             	mov    %r8,%rdi
    594d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5951:	31 f6                	xor    %esi,%esi
    5953:	48 89 ca             	mov    %rcx,%rdx
    5956:	e8 65 db ff ff       	call   34c0 <memset@plt>
    595b:	49 89 c0             	mov    %rax,%r8
    595e:	48 89 d8             	mov    %rbx,%rax
    5961:	48 03 05 38 f2 01 00 	add    0x1f238(%rip),%rax        # 24ba0 <fwp_heap+0x1420>
    5968:	0f 82 d9 00 00 00    	jb     5a47 <fwp_heap_alloc_slow+0x177>
    596e:	48 39 05 33 f2 01 00 	cmp    %rax,0x1f233(%rip)        # 24ba8 <fwp_heap+0x1428>
    5975:	48 89 05 24 f2 01 00 	mov    %rax,0x1f224(%rip)        # 24ba0 <fwp_heap+0x1420>
    597c:	73 07                	jae    5985 <fwp_heap_alloc_slow+0xb5>
    597e:	48 89 05 23 f2 01 00 	mov    %rax,0x1f223(%rip)        # 24ba8 <fwp_heap+0x1428>
    5985:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5989:	4c 89 c0             	mov    %r8,%rax
    598c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5991:	f2 0f 58 05 1f f2 01 	addsd  0x1f21f(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    5998:	00 
    5999:	f2 0f 11 05 17 f2 01 	movsd  %xmm0,0x1f217(%rip)        # 24bb8 <fwp_heap+0x1438>
    59a0:	00 
    59a1:	48 83 c4 10          	add    $0x10,%rsp
    59a5:	5b                   	pop    %rbx
    59a6:	c3                   	ret
    59a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    59ae:	00 00 
    59b0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    59b4:	48 89 3c 24          	mov    %rdi,(%rsp)
    59b8:	e8 73 f1 ff ff       	call   4b30 <fwp_heap_init>
    59bd:	48 8b 0c 24          	mov    (%rsp),%rcx
    59c1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    59c6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    59cd:	0f 86 23 ff ff ff    	jbe    58f6 <fwp_heap_alloc_slow+0x26>
    59d3:	48 83 c4 10          	add    $0x10,%rsp
    59d7:	44 89 ce             	mov    %r9d,%esi
    59da:	48 89 cf             	mov    %rcx,%rdi
    59dd:	5b                   	pop    %rbx
    59de:	e9 cd fd ff ff       	jmp    57b0 <fwp_heap_alloc_big>
    59e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    59e8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    59ec:	4d 85 c0             	test   %r8,%r8
    59ef:	74 1f                	je     5a10 <fwp_heap_alloc_slow+0x140>
    59f1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    59f5:	4d 29 c3             	sub    %r8,%r11
    59f8:	49 39 db             	cmp    %rbx,%r11
    59fb:	72 13                	jb     5a10 <fwp_heap_alloc_slow+0x140>
    59fd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a01:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a05:	e9 3c ff ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a10:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a17:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a1b:	44 89 ca             	mov    %r9d,%edx
    5a1e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a23:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a27:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a2b:	44 89 d6             	mov    %r10d,%esi
    5a2e:	48 01 c7             	add    %rax,%rdi
    5a31:	e8 6a fa ff ff       	call   54a0 <fwp_heap_refill>
    5a36:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a3b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a3f:	49 89 c0             	mov    %rax,%r8
    5a42:	e9 ff fe ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a47:	e8 64 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5a4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005a50 <fwp_heap_alloc>:
    5a50:	8b 05 ce f0 01 00    	mov    0x1f0ce(%rip),%eax        # 24b24 <fwp_heap+0x13a4>
    5a56:	48 89 fa             	mov    %rdi,%rdx
    5a59:	89 f7                	mov    %esi,%edi
    5a5b:	85 c0                	test   %eax,%eax
    5a5d:	0f 84 f5 00 00 00    	je     5b58 <fwp_heap_alloc+0x108>
    5a63:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5a6a:	0f 87 e8 00 00 00    	ja     5b58 <fwp_heap_alloc+0x108>
    5a70:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5a74:	48 8d 05 05 dd 01 00 	lea    0x1dd05(%rip),%rax        # 23780 <fwp_heap>
    5a7b:	48 83 ec 18          	sub    $0x18,%rsp
    5a7f:	41 89 f0             	mov    %esi,%r8d
    5a82:	48 c1 e9 04          	shr    $0x4,%rcx
    5a86:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5a8d:	00 
    5a8e:	48 63 cf             	movslq %edi,%rcx
    5a91:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5a98:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5a9f:	00 
    5aa0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5aa4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5aa8:	48 01 c8             	add    %rcx,%rax
    5aab:	48 8b 08             	mov    (%rax),%rcx
    5aae:	48 85 c9             	test   %rcx,%rcx
    5ab1:	74 6d                	je     5b20 <fwp_heap_alloc+0xd0>
    5ab3:	48 8b 31             	mov    (%rcx),%rsi
    5ab6:	48 f7 d6             	not    %rsi
    5ab9:	48 89 30             	mov    %rsi,(%rax)
    5abc:	41 83 f8 01          	cmp    $0x1,%r8d
    5ac0:	48 89 cf             	mov    %rcx,%rdi
    5ac3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5ac8:	49 0f 45 d1          	cmovne %r9,%rdx
    5acc:	31 f6                	xor    %esi,%esi
    5ace:	e8 ed d9 ff ff       	call   34c0 <memset@plt>
    5ad3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5ad8:	48 89 c1             	mov    %rax,%rcx
    5adb:	4c 89 c8             	mov    %r9,%rax
    5ade:	48 03 05 bb f0 01 00 	add    0x1f0bb(%rip),%rax        # 24ba0 <fwp_heap+0x1420>
    5ae5:	72 7b                	jb     5b62 <fwp_heap_alloc+0x112>
    5ae7:	48 39 05 ba f0 01 00 	cmp    %rax,0x1f0ba(%rip)        # 24ba8 <fwp_heap+0x1428>
    5aee:	48 89 05 ab f0 01 00 	mov    %rax,0x1f0ab(%rip)        # 24ba0 <fwp_heap+0x1420>
    5af5:	73 07                	jae    5afe <fwp_heap_alloc+0xae>
    5af7:	48 89 05 aa f0 01 00 	mov    %rax,0x1f0aa(%rip)        # 24ba8 <fwp_heap+0x1428>
    5afe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b02:	48 89 c8             	mov    %rcx,%rax
    5b05:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b0a:	f2 0f 58 05 a6 f0 01 	addsd  0x1f0a6(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    5b11:	00 
    5b12:	f2 0f 11 05 9e f0 01 	movsd  %xmm0,0x1f09e(%rip)        # 24bb8 <fwp_heap+0x1438>
    5b19:	00 
    5b1a:	48 83 c4 18          	add    $0x18,%rsp
    5b1e:	c3                   	ret
    5b1f:	90                   	nop
    5b20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b24:	48 85 c9             	test   %rcx,%rcx
    5b27:	74 0c                	je     5b35 <fwp_heap_alloc+0xe5>
    5b29:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b2d:	48 29 ce             	sub    %rcx,%rsi
    5b30:	4c 39 ce             	cmp    %r9,%rsi
    5b33:	73 13                	jae    5b48 <fwp_heap_alloc+0xf8>
    5b35:	89 fe                	mov    %edi,%esi
    5b37:	48 83 c4 18          	add    $0x18,%rsp
    5b3b:	48 89 d7             	mov    %rdx,%rdi
    5b3e:	e9 8d fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b48:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5b50:	e9 67 ff ff ff       	jmp    5abc <fwp_heap_alloc+0x6c>
    5b55:	0f 1f 00             	nopl   (%rax)
    5b58:	89 fe                	mov    %edi,%esi
    5b5a:	48 89 d7             	mov    %rdx,%rdi
    5b5d:	e9 6e fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b62:	e8 49 e1 ff ff       	call   3cb0 <fwp_heap_oom>
    5b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b6e:	00 00 

0000000000005b70 <fwp_apply>:
    5b70:	55                   	push   %rbp
    5b71:	48 89 f9             	mov    %rdi,%rcx
    5b74:	48 89 e5             	mov    %rsp,%rbp
    5b77:	41 57                	push   %r15
    5b79:	41 56                	push   %r14
    5b7b:	41 55                	push   %r13
    5b7d:	41 89 f5             	mov    %esi,%r13d
    5b80:	41 54                	push   %r12
    5b82:	53                   	push   %rbx
    5b83:	48 83 ec 28          	sub    $0x28,%rsp
    5b87:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5b8e:	00 00 
    5b90:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5b94:	49 89 d6             	mov    %rdx,%r14
    5b97:	44 8b 09             	mov    (%rcx),%r9d
    5b9a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5b9e:	49 89 e0             	mov    %rsp,%r8
    5ba1:	49 c1 e1 05          	shl    $0x5,%r9
    5ba5:	4c 03 0d 2c f8 01 00 	add    0x1f82c(%rip),%r9        # 253d8 <fwp_fns>
    5bac:	41 8b 19             	mov    (%r9),%ebx
    5baf:	45 85 e4             	test   %r12d,%r12d
    5bb2:	75 2c                	jne    5be0 <fwp_apply+0x70>
    5bb4:	41 39 dd             	cmp    %ebx,%r13d
    5bb7:	72 27                	jb     5be0 <fwp_apply+0x70>
    5bb9:	85 db                	test   %ebx,%ebx
    5bbb:	0f 84 a7 01 00 00    	je     5d68 <fwp_apply+0x1f8>
    5bc1:	4c 89 f7             	mov    %r14,%rdi
    5bc4:	41 ff 51 08          	call   *0x8(%r9)
    5bc8:	48 89 c1             	mov    %rax,%rcx
    5bcb:	41 39 dd             	cmp    %ebx,%r13d
    5bce:	0f 84 6c 01 00 00    	je     5d40 <fwp_apply+0x1d0>
    5bd4:	89 d8                	mov    %ebx,%eax
    5bd6:	41 29 dd             	sub    %ebx,%r13d
    5bd9:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5bdd:	eb b8                	jmp    5b97 <fwp_apply+0x27>
    5bdf:	90                   	nop
    5be0:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5be5:	41 39 df             	cmp    %ebx,%r15d
    5be8:	0f 82 cc 00 00 00    	jb     5cba <fwp_apply+0x14a>
    5bee:	41 89 df             	mov    %ebx,%r15d
    5bf1:	b8 01 00 00 00       	mov    $0x1,%eax
    5bf6:	48 89 e2             	mov    %rsp,%rdx
    5bf9:	45 29 e7             	sub    %r12d,%r15d
    5bfc:	85 db                	test   %ebx,%ebx
    5bfe:	0f 45 c3             	cmovne %ebx,%eax
    5c01:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5c08:	00 
    5c09:	48 c1 e8 04          	shr    $0x4,%rax
    5c0d:	48 c1 e0 04          	shl    $0x4,%rax
    5c11:	48 89 c6             	mov    %rax,%rsi
    5c14:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5c1b:	48 29 f2             	sub    %rsi,%rdx
    5c1e:	48 39 d4             	cmp    %rdx,%rsp
    5c21:	74 15                	je     5c38 <fwp_apply+0xc8>
    5c23:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5c2a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5c31:	00 00 
    5c33:	48 39 d4             	cmp    %rdx,%rsp
    5c36:	75 eb                	jne    5c23 <fwp_apply+0xb3>
    5c38:	25 ff 0f 00 00       	and    $0xfff,%eax
    5c3d:	48 29 c4             	sub    %rax,%rsp
    5c40:	48 85 c0             	test   %rax,%rax
    5c43:	0f 85 49 01 00 00    	jne    5d92 <fwp_apply+0x222>
    5c49:	45 89 e2             	mov    %r12d,%r10d
    5c4c:	48 89 e6             	mov    %rsp,%rsi
    5c4f:	48 89 e7             	mov    %rsp,%rdi
    5c52:	31 c0                	xor    %eax,%eax
    5c54:	49 c1 e2 03          	shl    $0x3,%r10
    5c58:	45 85 e4             	test   %r12d,%r12d
    5c5b:	74 15                	je     5c72 <fwp_apply+0x102>
    5c5d:	0f 1f 00             	nopl   (%rax)
    5c60:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5c65:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5c69:	48 83 c0 08          	add    $0x8,%rax
    5c6d:	4c 39 d0             	cmp    %r10,%rax
    5c70:	75 ee                	jne    5c60 <fwp_apply+0xf0>
    5c72:	45 85 ff             	test   %r15d,%r15d
    5c75:	0f 84 f4 00 00 00    	je     5d6f <fwp_apply+0x1ff>
    5c7b:	44 89 fa             	mov    %r15d,%edx
    5c7e:	4c 89 f0             	mov    %r14,%rax
    5c81:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5c85:	44 89 e2             	mov    %r12d,%edx
    5c88:	66 90                	xchg   %ax,%ax
    5c8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c91:	00 00 00 00 
    5c95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c9c:	00 00 00 00 
    5ca0:	4c 8b 10             	mov    (%rax),%r10
    5ca3:	89 d1                	mov    %edx,%ecx
    5ca5:	48 83 c0 08          	add    $0x8,%rax
    5ca9:	83 c2 01             	add    $0x1,%edx
    5cac:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5cb0:	4c 39 d8             	cmp    %r11,%rax
    5cb3:	75 eb                	jne    5ca0 <fwp_apply+0x130>
    5cb5:	e9 b5 00 00 00       	jmp    5d6f <fwp_apply+0x1ff>
    5cba:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5cbe:	be 02 00 00 00       	mov    $0x2,%esi
    5cc3:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5cc7:	48 c1 e7 03          	shl    $0x3,%rdi
    5ccb:	e8 80 fd ff ff       	call   5a50 <fwp_heap_alloc>
    5cd0:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5cd4:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5cd9:	48 89 c3             	mov    %rax,%rbx
    5cdc:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5ce0:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5ce4:	66 0f d6 00          	movq   %xmm0,(%rax)
    5ce8:	45 85 e4             	test   %r12d,%r12d
    5ceb:	74 14                	je     5d01 <fwp_apply+0x191>
    5ced:	44 89 e2             	mov    %r12d,%edx
    5cf0:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5cf4:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5cf8:	48 c1 e2 03          	shl    $0x3,%rdx
    5cfc:	e8 0f d9 ff ff       	call   3610 <memmove@plt>
    5d01:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5d05:	45 85 ed             	test   %r13d,%r13d
    5d08:	74 2e                	je     5d38 <fwp_apply+0x1c8>
    5d0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d11:	00 00 00 00 
    5d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d1c:	00 00 00 00 
    5d20:	49 8b 16             	mov    (%r14),%rdx
    5d23:	44 89 e0             	mov    %r12d,%eax
    5d26:	49 83 c6 08          	add    $0x8,%r14
    5d2a:	41 83 c4 01          	add    $0x1,%r12d
    5d2e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5d33:	49 39 ce             	cmp    %rcx,%r14
    5d36:	75 e8                	jne    5d20 <fwp_apply+0x1b0>
    5d38:	48 89 d9             	mov    %rbx,%rcx
    5d3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d40:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5d44:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5d4b:	00 00 
    5d4d:	75 4e                	jne    5d9d <fwp_apply+0x22d>
    5d4f:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5d53:	48 89 c8             	mov    %rcx,%rax
    5d56:	5b                   	pop    %rbx
    5d57:	41 5c                	pop    %r12
    5d59:	41 5d                	pop    %r13
    5d5b:	41 5e                	pop    %r14
    5d5d:	41 5f                	pop    %r15
    5d5f:	5d                   	pop    %rbp
    5d60:	c3                   	ret
    5d61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d68:	45 31 ff             	xor    %r15d,%r15d
    5d6b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    5d6f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    5d73:	41 ff 51 08          	call   *0x8(%r9)
    5d77:	48 89 c1             	mov    %rax,%rcx
    5d7a:	45 39 fd             	cmp    %r15d,%r13d
    5d7d:	74 c1                	je     5d40 <fwp_apply+0x1d0>
    5d7f:	45 01 e5             	add    %r12d,%r13d
    5d82:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    5d86:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    5d8a:	41 29 dd             	sub    %ebx,%r13d
    5d8d:	e9 05 fe ff ff       	jmp    5b97 <fwp_apply+0x27>
    5d92:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    5d98:	e9 ac fe ff ff       	jmp    5c49 <fwp_apply+0xd9>
    5d9d:	e8 be d6 ff ff       	call   3460 <__stack_chk_fail@plt>
    5da2:	0f 1f 00             	nopl   (%rax)
    5da5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5dac:	00 00 00 00 

0000000000005db0 <fwp_p_ad_push>:
    5db0:	41 57                	push   %r15
    5db2:	41 56                	push   %r14
    5db4:	41 55                	push   %r13
    5db6:	49 89 d5             	mov    %rdx,%r13
    5db9:	41 54                	push   %r12
    5dbb:	49 89 fc             	mov    %rdi,%r12
    5dbe:	55                   	push   %rbp
    5dbf:	53                   	push   %rbx
    5dc0:	48 83 ec 38          	sub    $0x38,%rsp
    5dc4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5dc9:	48 85 ff             	test   %rdi,%rdi
    5dcc:	79 09                	jns    5dd7 <fwp_p_ad_push+0x27>
    5dce:	48 85 d2             	test   %rdx,%rdx
    5dd1:	0f 88 a9 01 00 00    	js     5f80 <fwp_p_ad_push+0x1d0>
    5dd7:	48 89 f8             	mov    %rdi,%rax
    5dda:	48 89 0c 24          	mov    %rcx,(%rsp)
    5dde:	48 09 d0             	or     %rdx,%rax
    5de1:	0f 89 79 01 00 00    	jns    5f60 <fwp_p_ad_push+0x1b0>
    5de7:	48 89 f8             	mov    %rdi,%rax
    5dea:	48 c1 f8 20          	sar    $0x20,%rax
    5dee:	48 85 ff             	test   %rdi,%rdi
    5df1:	79 24                	jns    5e17 <fwp_p_ad_push+0x67>
    5df3:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5df8:	48 89 d0             	mov    %rdx,%rax
    5dfb:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5e02:	00 
    5e03:	49 89 d4             	mov    %rdx,%r12
    5e06:	48 c1 f8 20          	sar    $0x20,%rax
    5e0a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5e11:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5e17:	48 89 c7             	mov    %rax,%rdi
    5e1a:	e8 61 e6 ff ff       	call   4480 <fwp_tape_of>
    5e1f:	48 89 c3             	mov    %rax,%rbx
    5e22:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5e27:	0f 85 76 02 00 00    	jne    60a3 <fwp_p_ad_push+0x2f3>
    5e2d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    5e31:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    5e38:	0f 8f 59 02 00 00    	jg     6097 <fwp_p_ad_push+0x2e7>
    5e3e:	44 89 e0             	mov    %r12d,%eax
    5e41:	4c 39 f8             	cmp    %r15,%rax
    5e44:	0f 8d 41 02 00 00    	jge    608b <fwp_p_ad_push+0x2db>
    5e4a:	4d 85 ed             	test   %r13,%r13
    5e4d:	78 0c                	js     5e5b <fwp_p_ad_push+0xab>
    5e4f:	44 89 e8             	mov    %r13d,%eax
    5e52:	4c 39 f8             	cmp    %r15,%rax
    5e55:	0f 8d 30 02 00 00    	jge    608b <fwp_p_ad_push+0x2db>
    5e5b:	4d 89 fe             	mov    %r15,%r14
    5e5e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5e62:	49 8d 46 01          	lea    0x1(%r14),%rax
    5e66:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5e6c:	0f 87 25 02 00 00    	ja     6097 <fwp_p_ad_push+0x2e7>
    5e72:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5e76:	48 39 e8             	cmp    %rbp,%rax
    5e79:	0f 8e 31 01 00 00    	jle    5fb0 <fwp_p_ad_push+0x200>
    5e7f:	48 85 ed             	test   %rbp,%rbp
    5e82:	b9 40 00 00 00       	mov    $0x40,%ecx
    5e87:	48 0f 44 e9          	cmove  %rcx,%rbp
    5e8b:	48 39 e8             	cmp    %rbp,%rax
    5e8e:	7e 20                	jle    5eb0 <fwp_p_ad_push+0x100>
    5e90:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5e97:	0f 8f 03 01 00 00    	jg     5fa0 <fwp_p_ad_push+0x1f0>
    5e9d:	48 01 ed             	add    %rbp,%rbp
    5ea0:	48 39 e8             	cmp    %rbp,%rax
    5ea3:	7f eb                	jg     5e90 <fwp_p_ad_push+0xe0>
    5ea5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5eac:	00 00 00 00 
    5eb0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5eb7:	00 
    5eb8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5ebc:	48 89 c6             	mov    %rax,%rsi
    5ebf:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    5ec4:	e8 07 d7 ff ff       	call   35d0 <realloc@plt>
    5ec9:	48 85 c0             	test   %rax,%rax
    5ecc:	0f 84 dd 01 00 00    	je     60af <fwp_p_ad_push+0x2ff>
    5ed2:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    5ed6:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    5eda:	48 89 43 20          	mov    %rax,0x20(%rbx)
    5ede:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    5ee2:	48 89 e9             	mov    %rbp,%rcx
    5ee5:	48 89 43 28          	mov    %rax,0x28(%rbx)
    5ee9:	48 c1 e1 04          	shl    $0x4,%rcx
    5eed:	48 89 ce             	mov    %rcx,%rsi
    5ef0:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    5ef5:	e8 d6 d6 ff ff       	call   35d0 <realloc@plt>
    5efa:	48 85 c0             	test   %rax,%rax
    5efd:	0f 84 ac 01 00 00    	je     60af <fwp_p_ad_push+0x2ff>
    5f03:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    5f07:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5f0c:	4d 85 f6             	test   %r14,%r14
    5f0f:	48 89 43 30          	mov    %rax,0x30(%rbx)
    5f13:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    5f18:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5f1f:	00 
    5f20:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5f27:	00 
    5f28:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    5f2c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    5f33:	00 
    5f34:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    5f38:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    5f3c:	0f 85 e2 00 00 00    	jne    6024 <fwp_p_ad_push+0x274>
    5f42:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    5f46:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5f4a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    5f4e:	49 01 c8             	add    %rcx,%r8
    5f51:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    5f55:	eb 79                	jmp    5fd0 <fwp_p_ad_push+0x220>
    5f57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5f5e:	00 00 
    5f60:	48 89 d0             	mov    %rdx,%rax
    5f63:	48 c1 ff 20          	sar    $0x20,%rdi
    5f67:	48 c1 f8 20          	sar    $0x20,%rax
    5f6b:	48 39 c7             	cmp    %rax,%rdi
    5f6e:	0f 84 a3 fe ff ff    	je     5e17 <fwp_p_ad_push+0x67>
    5f74:	48 8d 3d 45 98 00 00 	lea    0x9845(%rip),%rdi        # f7c0 <_IO_stdin_used+0x7c0>
    5f7b:	e8 20 e2 ff ff       	call   41a0 <fwp_trap>
    5f80:	48 83 c4 38          	add    $0x38,%rsp
    5f84:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5f8b:	5b                   	pop    %rbx
    5f8c:	5d                   	pop    %rbp
    5f8d:	41 5c                	pop    %r12
    5f8f:	41 5d                	pop    %r13
    5f91:	41 5e                	pop    %r14
    5f93:	41 5f                	pop    %r15
    5f95:	c3                   	ret
    5f96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5f9d:	00 00 00 
    5fa0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    5fa5:	e9 06 ff ff ff       	jmp    5eb0 <fwp_p_ad_push+0x100>
    5faa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5fb0:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5fb4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    5fb8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5fbf:	00 
    5fc0:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5fc7:	00 
    5fc8:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    5fcc:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5fd0:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    5fd6:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    5fda:	4d 85 ed             	test   %r13,%r13
    5fdd:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    5fe2:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    5fe8:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5fef:	4c 0f 48 e8          	cmovs  %rax,%r13
    5ff3:	49 8d 47 01          	lea    0x1(%r15),%rax
    5ff7:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    5ffb:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6001:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6005:	48 83 c4 38          	add    $0x38,%rsp
    6009:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6010:	ff ff ff 
    6013:	4c 21 e0             	and    %r12,%rax
    6016:	5b                   	pop    %rbx
    6017:	5d                   	pop    %rbp
    6018:	4c 09 f8             	or     %r15,%rax
    601b:	41 5c                	pop    %r12
    601d:	41 5d                	pop    %r13
    601f:	41 5e                	pop    %r14
    6021:	41 5f                	pop    %r15
    6023:	c3                   	ret
    6024:	48 39 ca             	cmp    %rcx,%rdx
    6027:	49 89 d6             	mov    %rdx,%r14
    602a:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    602f:	48 0f 43 ca          	cmovae %rdx,%rcx
    6033:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    6038:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    603d:	48 29 d1             	sub    %rdx,%rcx
    6040:	4c 89 ca             	mov    %r9,%rdx
    6043:	e8 18 d5 ff ff       	call   3560 <__memmove_chk@plt>
    6048:	4c 03 73 30          	add    0x30(%rbx),%r14
    604c:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    6051:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6055:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    605a:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    605e:	48 03 7b 20          	add    0x20(%rbx),%rdi
    6062:	4c 89 d2             	mov    %r10,%rdx
    6065:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    606a:	e8 a1 d5 ff ff       	call   3610 <memmove@plt>
    606f:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6073:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6077:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    607c:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    6081:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    6086:	e9 bb fe ff ff       	jmp    5f46 <fwp_p_ad_push+0x196>
    608b:	48 8d 3d 72 90 00 00 	lea    0x9072(%rip),%rdi        # f104 <_IO_stdin_used+0x104>
    6092:	e8 09 e1 ff ff       	call   41a0 <fwp_trap>
    6097:	48 8d 3d 4b 90 00 00 	lea    0x904b(%rip),%rdi        # f0e9 <_IO_stdin_used+0xe9>
    609e:	e8 fd e0 ff ff       	call   41a0 <fwp_trap>
    60a3:	48 8d 3d 5e 97 00 00 	lea    0x975e(%rip),%rdi        # f808 <_IO_stdin_used+0x808>
    60aa:	e8 f1 e0 ff ff       	call   41a0 <fwp_trap>
    60af:	48 89 df             	mov    %rbx,%rdi
    60b2:	e8 49 db ff ff       	call   3c00 <fwp_tape_unlink_scope>
    60b7:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    60bb:	e8 00 d3 ff ff       	call   33c0 <free@plt>
    60c0:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    60c4:	e8 f7 d2 ff ff       	call   33c0 <free@plt>
    60c9:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    60cd:	e8 ee d2 ff ff       	call   33c0 <free@plt>
    60d2:	31 c9                	xor    %ecx,%ecx
    60d4:	31 c0                	xor    %eax,%eax
    60d6:	31 d2                	xor    %edx,%edx
    60d8:	89 53 04             	mov    %edx,0x4(%rbx)
    60db:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60df:	ba 13 00 00 00       	mov    $0x13,%edx
    60e4:	be 01 00 00 00       	mov    $0x1,%esi
    60e9:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    60ed:	48 8d 3d 14 8f 00 00 	lea    0x8f14(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    60f4:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    60f8:	48 8b 0d 61 cf 00 00 	mov    0xcf61(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    60ff:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6103:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    6107:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    610b:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    610f:	e8 6c d5 ff ff       	call   3680 <fwrite@plt>
    6114:	31 ff                	xor    %edi,%edi
    6116:	e8 a5 d4 ff ff       	call   35c0 <fflush@plt>
    611b:	bf 66 00 00 00       	mov    $0x66,%edi
    6120:	e8 7b d5 ff ff       	call   36a0 <_Exit@plt>
    6125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    612c:	00 00 00 00 

0000000000006130 <w107>:
    6130:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6134:	41 55                	push   %r13
    6136:	48 89 fa             	mov    %rdi,%rdx
    6139:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    613d:	41 54                	push   %r12
    613f:	49 89 fc             	mov    %rdi,%r12
    6142:	55                   	push   %rbp
    6143:	53                   	push   %rbx
    6144:	48 89 f3             	mov    %rsi,%rbx
    6147:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    614c:	48 89 f1             	mov    %rsi,%rcx
    614f:	48 83 ec 28          	sub    $0x28,%rsp
    6153:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6159:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    615f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6165:	e8 46 fc ff ff       	call   5db0 <fwp_p_ad_push>
    616a:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6170:	48 89 da             	mov    %rbx,%rdx
    6173:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6179:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6180:	00 f0 3f 
    6183:	48 89 c7             	mov    %rax,%rdi
    6186:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    618d:	00 f0 bf 
    6190:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6195:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    619b:	e8 10 fc ff ff       	call   5db0 <fwp_p_ad_push>
    61a0:	f2 0f 10 05 88 99 00 	movsd  0x9988(%rip),%xmm0        # fb30 <msg.4+0xb0>
    61a7:	00 
    61a8:	4c 89 e7             	mov    %r12,%rdi
    61ab:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    61b1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    61b8:	00 f0 3f 
    61bb:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    61c2:	49 89 c5             	mov    %rax,%r13
    61c5:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    61cc:	00 f0 bf 
    61cf:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    61d4:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    61da:	e8 d1 fb ff ff       	call   5db0 <fwp_p_ad_push>
    61df:	48 89 e9             	mov    %rbp,%rcx
    61e2:	4c 89 ea             	mov    %r13,%rdx
    61e5:	48 89 ee             	mov    %rbp,%rsi
    61e8:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    61ee:	4c 89 ef             	mov    %r13,%rdi
    61f1:	49 89 c4             	mov    %rax,%r12
    61f4:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    61f8:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    61fe:	e8 ad fb ff ff       	call   5db0 <fwp_p_ad_push>
    6203:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6209:	f2 0f 59 1d 27 99 00 	mulsd  0x9927(%rip),%xmm3        # fb38 <msg.4+0xb8>
    6210:	00 
    6211:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6218:	00 59 40 
    621b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6220:	48 89 c2             	mov    %rax,%rdx
    6223:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    622a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6230:	e8 7b fb ff ff       	call   5db0 <fwp_p_ad_push>
    6235:	48 89 d9             	mov    %rbx,%rcx
    6238:	4c 89 e2             	mov    %r12,%rdx
    623b:	48 89 de             	mov    %rbx,%rsi
    623e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6244:	4c 89 e7             	mov    %r12,%rdi
    6247:	48 89 c5             	mov    %rax,%rbp
    624a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    624e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6254:	e8 57 fb ff ff       	call   5db0 <fwp_p_ad_push>
    6259:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    625f:	48 89 ea             	mov    %rbp,%rdx
    6262:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6268:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    626f:	00 f0 3f 
    6272:	48 89 c7             	mov    %rax,%rdi
    6275:	48 89 ce             	mov    %rcx,%rsi
    6278:	66 48 0f 7e db       	movq   %xmm3,%rbx
    627d:	e8 2e fb ff ff       	call   5db0 <fwp_p_ad_push>
    6282:	48 83 c4 28          	add    $0x28,%rsp
    6286:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    628b:	5b                   	pop    %rbx
    628c:	5d                   	pop    %rbp
    628d:	41 5c                	pop    %r12
    628f:	41 5d                	pop    %r13
    6291:	c3                   	ret
    6292:	0f 1f 00             	nopl   (%rax)
    6295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    629c:	00 00 00 00 

00000000000062a0 <fwp_data.part.0.constprop.0>:
    62a0:	41 56                	push   %r14
    62a2:	41 89 fe             	mov    %edi,%r14d
    62a5:	41 54                	push   %r12
    62a7:	49 89 f4             	mov    %rsi,%r12
    62aa:	55                   	push   %rbp
    62ab:	53                   	push   %rbx
    62ac:	48 83 ec 08          	sub    $0x8,%rsp
    62b0:	8b 05 6e e8 01 00    	mov    0x1e86e(%rip),%eax        # 24b24 <fwp_heap+0x13a4>
    62b6:	85 c0                	test   %eax,%eax
    62b8:	0f 84 fa 00 00 00    	je     63b8 <fwp_data.part.0.constprop.0+0x118>
    62be:	0f b6 05 5d e4 01 00 	movzbl 0x1e45d(%rip),%eax        # 24722 <fwp_heap+0xfa2>
    62c5:	48 8d 15 b4 d4 01 00 	lea    0x1d4b4(%rip),%rdx        # 23780 <fwp_heap>
    62cc:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    62d3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    62d7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    62db:	48 8b 18             	mov    (%rax),%rbx
    62de:	48 85 db             	test   %rbx,%rbx
    62e1:	0f 84 a9 00 00 00    	je     6390 <fwp_data.part.0.constprop.0+0xf0>
    62e7:	48 8b 13             	mov    (%rbx),%rdx
    62ea:	48 f7 d2             	not    %rdx
    62ed:	48 89 10             	mov    %rdx,(%rax)
    62f0:	48 83 fd 18          	cmp    $0x18,%rbp
    62f4:	76 1b                	jbe    6311 <fwp_data.part.0.constprop.0+0x71>
    62f6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    62fa:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    62fe:	31 f6                	xor    %esi,%esi
    6300:	48 c1 e8 03          	shr    $0x3,%rax
    6304:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    630b:	00 
    630c:	e8 af d1 ff ff       	call   34c0 <memset@plt>
    6311:	48 89 e8             	mov    %rbp,%rax
    6314:	48 03 05 85 e8 01 00 	add    0x1e885(%rip),%rax        # 24ba0 <fwp_heap+0x1420>
    631b:	0f 82 a8 00 00 00    	jb     63c9 <fwp_data.part.0.constprop.0+0x129>
    6321:	48 39 05 80 e8 01 00 	cmp    %rax,0x1e880(%rip)        # 24ba8 <fwp_heap+0x1428>
    6328:	48 89 05 71 e8 01 00 	mov    %rax,0x1e871(%rip)        # 24ba0 <fwp_heap+0x1420>
    632f:	73 07                	jae    6338 <fwp_data.part.0.constprop.0+0x98>
    6331:	48 89 05 70 e8 01 00 	mov    %rax,0x1e870(%rip)        # 24ba8 <fwp_heap+0x1428>
    6338:	66 0f ef c0          	pxor   %xmm0,%xmm0
    633c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6341:	f2 0f 58 05 6f e8 01 	addsd  0x1e86f(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    6348:	00 
    6349:	f2 0f 11 05 67 e8 01 	movsd  %xmm0,0x1e867(%rip)        # 24bb8 <fwp_heap+0x1438>
    6350:	00 
    6351:	b8 02 00 00 00       	mov    $0x2,%eax
    6356:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    635b:	66 0f 6e c8          	movd   %eax,%xmm1
    635f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6363:	66 0f d6 03          	movq   %xmm0,(%rbx)
    6367:	49 8b 04 24          	mov    (%r12),%rax
    636b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    636f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6374:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6378:	48 83 c4 08          	add    $0x8,%rsp
    637c:	48 89 d8             	mov    %rbx,%rax
    637f:	5b                   	pop    %rbx
    6380:	5d                   	pop    %rbp
    6381:	41 5c                	pop    %r12
    6383:	41 5e                	pop    %r14
    6385:	c3                   	ret
    6386:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    638d:	00 00 00 
    6390:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6394:	48 85 db             	test   %rbx,%rbx
    6397:	74 1f                	je     63b8 <fwp_data.part.0.constprop.0+0x118>
    6399:	48 8b 50 10          	mov    0x10(%rax),%rdx
    639d:	48 29 da             	sub    %rbx,%rdx
    63a0:	48 39 ea             	cmp    %rbp,%rdx
    63a3:	72 13                	jb     63b8 <fwp_data.part.0.constprop.0+0x118>
    63a5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    63a9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    63ad:	e9 3e ff ff ff       	jmp    62f0 <fwp_data.part.0.constprop.0+0x50>
    63b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    63b8:	31 f6                	xor    %esi,%esi
    63ba:	bf 18 00 00 00       	mov    $0x18,%edi
    63bf:	e8 8c f6 ff ff       	call   5a50 <fwp_heap_alloc>
    63c4:	48 89 c3             	mov    %rax,%rbx
    63c7:	eb 88                	jmp    6351 <fwp_data.part.0.constprop.0+0xb1>
    63c9:	e8 e2 d8 ff ff       	call   3cb0 <fwp_heap_oom>
    63ce:	66 90                	xchg   %ax,%ax

00000000000063d0 <fwp_rc_share>:
    63d0:	48 8b 05 81 e7 01 00 	mov    0x1e781(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    63d7:	48 2b 3d 52 e7 01 00 	sub    0x1e752(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    63de:	48 c1 e0 10          	shl    $0x10,%rax
    63e2:	48 39 c7             	cmp    %rax,%rdi
    63e5:	73 4a                	jae    6431 <fwp_rc_share+0x61>
    63e7:	48 89 f8             	mov    %rdi,%rax
    63ea:	48 c1 e8 10          	shr    $0x10,%rax
    63ee:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    63f2:	48 8b 05 7f e7 01 00 	mov    0x1e77f(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    63f9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    63fd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6401:	48 85 d2             	test   %rdx,%rdx
    6404:	74 2b                	je     6431 <fwp_rc_share+0x61>
    6406:	0f b6 08             	movzbl (%rax),%ecx
    6409:	80 f9 02             	cmp    $0x2,%cl
    640c:	74 2a                	je     6438 <fwp_rc_share+0x68>
    640e:	80 f9 01             	cmp    $0x1,%cl
    6411:	75 1e                	jne    6431 <fwp_rc_share+0x61>
    6413:	8b 48 18             	mov    0x18(%rax),%ecx
    6416:	0f b7 ff             	movzwl %di,%edi
    6419:	8b 40 1c             	mov    0x1c(%rax),%eax
    641c:	48 0f af f9          	imul   %rcx,%rdi
    6420:	48 c1 ef 20          	shr    $0x20,%rdi
    6424:	48 39 c7             	cmp    %rax,%rdi
    6427:	73 08                	jae    6431 <fwp_rc_share+0x61>
    6429:	48 01 fa             	add    %rdi,%rdx
    642c:	80 3a 00             	cmpb   $0x0,(%rdx)
    642f:	75 0d                	jne    643e <fwp_rc_share+0x6e>
    6431:	c3                   	ret
    6432:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6438:	66 85 ff             	test   %di,%di
    643b:	74 ef                	je     642c <fwp_rc_share+0x5c>
    643d:	c3                   	ret
    643e:	50                   	push   %rax
    643f:	48 8d 3d f2 93 00 00 	lea    0x93f2(%rip),%rdi        # f838 <_IO_stdin_used+0x838>
    6446:	e8 55 dd ff ff       	call   41a0 <fwp_trap>
    644b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006450 <fwp_rc_fresh>:
    6450:	48 8b 15 01 e7 01 00 	mov    0x1e701(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    6457:	48 89 f8             	mov    %rdi,%rax
    645a:	48 89 fe             	mov    %rdi,%rsi
    645d:	48 2b 05 cc e6 01 00 	sub    0x1e6cc(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6464:	48 c1 e2 10          	shl    $0x10,%rdx
    6468:	48 39 d0             	cmp    %rdx,%rax
    646b:	73 4f                	jae    64bc <fwp_rc_fresh+0x6c>
    646d:	48 89 c2             	mov    %rax,%rdx
    6470:	48 c1 ea 10          	shr    $0x10,%rdx
    6474:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6478:	48 8b 15 f9 e6 01 00 	mov    0x1e6f9(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    647f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6483:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6487:	48 85 d2             	test   %rdx,%rdx
    648a:	74 30                	je     64bc <fwp_rc_fresh+0x6c>
    648c:	0f b6 39             	movzbl (%rcx),%edi
    648f:	40 80 ff 02          	cmp    $0x2,%dil
    6493:	74 2b                	je     64c0 <fwp_rc_fresh+0x70>
    6495:	40 80 ff 01          	cmp    $0x1,%dil
    6499:	75 21                	jne    64bc <fwp_rc_fresh+0x6c>
    649b:	8b 79 18             	mov    0x18(%rcx),%edi
    649e:	0f b7 c0             	movzwl %ax,%eax
    64a1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    64a4:	48 0f af c7          	imul   %rdi,%rax
    64a8:	48 c1 e8 20          	shr    $0x20,%rax
    64ac:	48 39 c8             	cmp    %rcx,%rax
    64af:	73 0b                	jae    64bc <fwp_rc_fresh+0x6c>
    64b1:	48 01 c2             	add    %rax,%rdx
    64b4:	80 3a ff             	cmpb   $0xff,(%rdx)
    64b7:	74 17                	je     64d0 <fwp_rc_fresh+0x80>
    64b9:	c6 02 01             	movb   $0x1,(%rdx)
    64bc:	48 89 f0             	mov    %rsi,%rax
    64bf:	c3                   	ret
    64c0:	66 85 c0             	test   %ax,%ax
    64c3:	74 ef                	je     64b4 <fwp_rc_fresh+0x64>
    64c5:	48 89 f0             	mov    %rsi,%rax
    64c8:	c3                   	ret
    64c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    64d0:	48 83 ec 18          	sub    $0x18,%rsp
    64d4:	48 89 d7             	mov    %rdx,%rdi
    64d7:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    64dc:	48 89 14 24          	mov    %rdx,(%rsp)
    64e0:	e8 2b ee ff ff       	call   5310 <fwp_rc_forget_slot>
    64e5:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    64ea:	48 8b 14 24          	mov    (%rsp),%rdx
    64ee:	48 89 f0             	mov    %rsi,%rax
    64f1:	c6 02 01             	movb   $0x1,(%rdx)
    64f4:	48 83 c4 18          	add    $0x18,%rsp
    64f8:	c3                   	ret
    64f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006500 <fwp_rc_free_arr>:
    6500:	48 8b 15 51 e6 01 00 	mov    0x1e651(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    6507:	48 89 f8             	mov    %rdi,%rax
    650a:	48 2b 05 1f e6 01 00 	sub    0x1e61f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6511:	48 c1 e2 10          	shl    $0x10,%rdx
    6515:	48 39 d0             	cmp    %rdx,%rax
    6518:	73 5b                	jae    6575 <fwp_rc_free_arr+0x75>
    651a:	48 89 c2             	mov    %rax,%rdx
    651d:	48 c1 ea 10          	shr    $0x10,%rdx
    6521:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6525:	48 8b 15 4c e6 01 00 	mov    0x1e64c(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    652c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6530:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6534:	48 85 c9             	test   %rcx,%rcx
    6537:	74 3c                	je     6575 <fwp_rc_free_arr+0x75>
    6539:	0f b6 32             	movzbl (%rdx),%esi
    653c:	40 80 fe 02          	cmp    $0x2,%sil
    6540:	74 2e                	je     6570 <fwp_rc_free_arr+0x70>
    6542:	40 80 fe 01          	cmp    $0x1,%sil
    6546:	75 2d                	jne    6575 <fwp_rc_free_arr+0x75>
    6548:	8b 72 18             	mov    0x18(%rdx),%esi
    654b:	0f b7 c0             	movzwl %ax,%eax
    654e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6551:	48 0f af c6          	imul   %rsi,%rax
    6555:	48 c1 e8 20          	shr    $0x20,%rax
    6559:	48 39 d0             	cmp    %rdx,%rax
    655c:	73 17                	jae    6575 <fwp_rc_free_arr+0x75>
    655e:	48 01 c1             	add    %rax,%rcx
    6561:	80 39 01             	cmpb   $0x1,(%rcx)
    6564:	75 0f                	jne    6575 <fwp_rc_free_arr+0x75>
    6566:	e9 e5 ef ff ff       	jmp    5550 <fwp_mem_free>
    656b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6570:	66 85 c0             	test   %ax,%ax
    6573:	74 ec                	je     6561 <fwp_rc_free_arr+0x61>
    6575:	c3                   	ret
    6576:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    657d:	00 00 00 

0000000000006580 <fwp_rc_dup>:
    6580:	f3 0f 1e fa          	endbr64
    6584:	48 8b 05 cd e5 01 00 	mov    0x1e5cd(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    658b:	48 2b 3d 9e e5 01 00 	sub    0x1e59e(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    6592:	48 c1 e0 10          	shl    $0x10,%rax
    6596:	48 39 c7             	cmp    %rax,%rdi
    6599:	73 56                	jae    65f1 <fwp_rc_dup+0x71>
    659b:	48 89 f8             	mov    %rdi,%rax
    659e:	48 c1 e8 10          	shr    $0x10,%rax
    65a2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    65a6:	48 8b 05 cb e5 01 00 	mov    0x1e5cb(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    65ad:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    65b1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    65b5:	48 85 c0             	test   %rax,%rax
    65b8:	74 37                	je     65f1 <fwp_rc_dup+0x71>
    65ba:	0f b6 0a             	movzbl (%rdx),%ecx
    65bd:	80 f9 02             	cmp    $0x2,%cl
    65c0:	74 36                	je     65f8 <fwp_rc_dup+0x78>
    65c2:	80 f9 01             	cmp    $0x1,%cl
    65c5:	75 2a                	jne    65f1 <fwp_rc_dup+0x71>
    65c7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    65ca:	0f b7 ff             	movzwl %di,%edi
    65cd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    65d0:	48 0f af f9          	imul   %rcx,%rdi
    65d4:	48 c1 ef 20          	shr    $0x20,%rdi
    65d8:	48 39 d7             	cmp    %rdx,%rdi
    65db:	73 14                	jae    65f1 <fwp_rc_dup+0x71>
    65dd:	48 01 f8             	add    %rdi,%rax
    65e0:	0f b6 10             	movzbl (%rax),%edx
    65e3:	84 d2                	test   %dl,%dl
    65e5:	74 0a                	je     65f1 <fwp_rc_dup+0x71>
    65e7:	80 fa fd             	cmp    $0xfd,%dl
    65ea:	77 14                	ja     6600 <fwp_rc_dup+0x80>
    65ec:	83 c2 01             	add    $0x1,%edx
    65ef:	88 10                	mov    %dl,(%rax)
    65f1:	c3                   	ret
    65f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    65f8:	66 85 ff             	test   %di,%di
    65fb:	74 e3                	je     65e0 <fwp_rc_dup+0x60>
    65fd:	c3                   	ret
    65fe:	66 90                	xchg   %ax,%ax
    6600:	48 89 c7             	mov    %rax,%rdi
    6603:	e9 e8 eb ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    6608:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    660f:	00 

0000000000006610 <fwp_owned_entry161>:
    6610:	f3 0f 1e fa          	endbr64
    6614:	48 83 ec 38          	sub    $0x38,%rsp
    6618:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    661d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6624:	00 00 
    6626:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    662b:	31 c0                	xor    %eax,%eax
    662d:	48 8b 07             	mov    (%rdi),%rax
    6630:	48 03 47 10          	add    0x10(%rdi),%rax
    6634:	0f 80 c2 00 00 00    	jo     66fc <fwp_owned_entry161+0xec>
    663a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    663f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6644:	31 ff                	xor    %edi,%edi
    6646:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    664a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    664f:	e8 4c fc ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    6654:	48 8b 15 fd e4 01 00 	mov    0x1e4fd(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    665b:	48 89 c6             	mov    %rax,%rsi
    665e:	48 2b 05 cb e4 01 00 	sub    0x1e4cb(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6665:	48 c1 e2 10          	shl    $0x10,%rdx
    6669:	48 39 d0             	cmp    %rdx,%rax
    666c:	73 4f                	jae    66bd <fwp_owned_entry161+0xad>
    666e:	48 89 c2             	mov    %rax,%rdx
    6671:	48 c1 ea 10          	shr    $0x10,%rdx
    6675:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6679:	48 8b 15 f8 e4 01 00 	mov    0x1e4f8(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    6680:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6684:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6688:	48 85 d2             	test   %rdx,%rdx
    668b:	74 30                	je     66bd <fwp_owned_entry161+0xad>
    668d:	0f b6 39             	movzbl (%rcx),%edi
    6690:	40 80 ff 02          	cmp    $0x2,%dil
    6694:	74 42                	je     66d8 <fwp_owned_entry161+0xc8>
    6696:	40 80 ff 01          	cmp    $0x1,%dil
    669a:	75 21                	jne    66bd <fwp_owned_entry161+0xad>
    669c:	8b 79 18             	mov    0x18(%rcx),%edi
    669f:	0f b7 c0             	movzwl %ax,%eax
    66a2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    66a5:	48 0f af c7          	imul   %rdi,%rax
    66a9:	48 c1 e8 20          	shr    $0x20,%rax
    66ad:	48 39 c8             	cmp    %rcx,%rax
    66b0:	73 0b                	jae    66bd <fwp_owned_entry161+0xad>
    66b2:	48 01 c2             	add    %rax,%rdx
    66b5:	80 3a ff             	cmpb   $0xff,(%rdx)
    66b8:	74 26                	je     66e0 <fwp_owned_entry161+0xd0>
    66ba:	c6 02 01             	movb   $0x1,(%rdx)
    66bd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    66c2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    66c9:	00 00 
    66cb:	75 34                	jne    6701 <fwp_owned_entry161+0xf1>
    66cd:	48 89 f0             	mov    %rsi,%rax
    66d0:	48 83 c4 38          	add    $0x38,%rsp
    66d4:	c3                   	ret
    66d5:	0f 1f 00             	nopl   (%rax)
    66d8:	66 85 c0             	test   %ax,%ax
    66db:	75 e0                	jne    66bd <fwp_owned_entry161+0xad>
    66dd:	eb d6                	jmp    66b5 <fwp_owned_entry161+0xa5>
    66df:	90                   	nop
    66e0:	48 89 d7             	mov    %rdx,%rdi
    66e3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    66e8:	48 89 14 24          	mov    %rdx,(%rsp)
    66ec:	e8 1f ec ff ff       	call   5310 <fwp_rc_forget_slot>
    66f1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    66f6:	48 8b 14 24          	mov    (%rsp),%rdx
    66fa:	eb be                	jmp    66ba <fwp_owned_entry161+0xaa>
    66fc:	e8 ff cf ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6701:	e8 5a cd ff ff       	call   3460 <__stack_chk_fail@plt>
    6706:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    670d:	00 00 00 

0000000000006710 <e161>:
    6710:	f3 0f 1e fa          	endbr64
    6714:	53                   	push   %rbx
    6715:	48 83 ec 30          	sub    $0x30,%rsp
    6719:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    671e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6725:	00 00 
    6727:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    672c:	31 c0                	xor    %eax,%eax
    672e:	48 8b 07             	mov    (%rdi),%rax
    6731:	48 03 47 10          	add    0x10(%rdi),%rax
    6735:	0f 80 c9 00 00 00    	jo     6804 <e161+0xf4>
    673b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6740:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6745:	31 ff                	xor    %edi,%edi
    6747:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    674b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6750:	e8 4b fb ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    6755:	48 8b 15 fc e3 01 00 	mov    0x1e3fc(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    675c:	48 89 c3             	mov    %rax,%rbx
    675f:	48 2b 05 ca e3 01 00 	sub    0x1e3ca(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6766:	48 c1 e2 10          	shl    $0x10,%rdx
    676a:	48 39 d0             	cmp    %rdx,%rax
    676d:	73 4f                	jae    67be <e161+0xae>
    676f:	48 89 c2             	mov    %rax,%rdx
    6772:	48 c1 ea 10          	shr    $0x10,%rdx
    6776:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    677a:	48 8b 15 f7 e3 01 00 	mov    0x1e3f7(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    6781:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6785:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6789:	48 85 d2             	test   %rdx,%rdx
    678c:	74 30                	je     67be <e161+0xae>
    678e:	0f b6 31             	movzbl (%rcx),%esi
    6791:	40 80 fe 02          	cmp    $0x2,%sil
    6795:	74 49                	je     67e0 <e161+0xd0>
    6797:	40 80 fe 01          	cmp    $0x1,%sil
    679b:	75 21                	jne    67be <e161+0xae>
    679d:	8b 71 18             	mov    0x18(%rcx),%esi
    67a0:	0f b7 c0             	movzwl %ax,%eax
    67a3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    67a6:	48 0f af c6          	imul   %rsi,%rax
    67aa:	48 c1 e8 20          	shr    $0x20,%rax
    67ae:	48 39 c8             	cmp    %rcx,%rax
    67b1:	73 0b                	jae    67be <e161+0xae>
    67b3:	48 01 c2             	add    %rax,%rdx
    67b6:	80 3a ff             	cmpb   $0xff,(%rdx)
    67b9:	74 35                	je     67f0 <e161+0xe0>
    67bb:	c6 02 01             	movb   $0x1,(%rdx)
    67be:	48 89 df             	mov    %rbx,%rdi
    67c1:	e8 0a fc ff ff       	call   63d0 <fwp_rc_share>
    67c6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    67cb:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    67d2:	00 00 
    67d4:	75 33                	jne    6809 <e161+0xf9>
    67d6:	48 83 c4 30          	add    $0x30,%rsp
    67da:	48 89 d8             	mov    %rbx,%rax
    67dd:	5b                   	pop    %rbx
    67de:	c3                   	ret
    67df:	90                   	nop
    67e0:	66 85 c0             	test   %ax,%ax
    67e3:	75 d9                	jne    67be <e161+0xae>
    67e5:	eb cf                	jmp    67b6 <e161+0xa6>
    67e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    67ee:	00 00 
    67f0:	48 89 d7             	mov    %rdx,%rdi
    67f3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    67f8:	e8 13 eb ff ff       	call   5310 <fwp_rc_forget_slot>
    67fd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6802:	eb b7                	jmp    67bb <e161+0xab>
    6804:	e8 f7 ce ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6809:	e8 52 cc ff ff       	call   3460 <__stack_chk_fail@plt>
    680e:	66 90                	xchg   %ax,%ax

0000000000006810 <fwp_drop0>:
    6810:	f3 0f 1e fa          	endbr64
    6814:	48 8b 15 3d e3 01 00 	mov    0x1e33d(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    681b:	48 89 f8             	mov    %rdi,%rax
    681e:	48 2b 05 0b e3 01 00 	sub    0x1e30b(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6825:	48 c1 e2 10          	shl    $0x10,%rdx
    6829:	48 39 d0             	cmp    %rdx,%rax
    682c:	0f 83 be 00 00 00    	jae    68f0 <fwp_drop0+0xe0>
    6832:	48 83 ec 18          	sub    $0x18,%rsp
    6836:	4c 8d 05 43 cf 01 00 	lea    0x1cf43(%rip),%r8        # 23780 <fwp_heap>
    683d:	48 89 c2             	mov    %rax,%rdx
    6840:	48 c1 ea 10          	shr    $0x10,%rdx
    6844:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6848:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    684f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6853:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6857:	48 85 d2             	test   %rdx,%rdx
    685a:	74 3c                	je     6898 <fwp_drop0+0x88>
    685c:	0f b6 31             	movzbl (%rcx),%esi
    685f:	40 80 fe 02          	cmp    $0x2,%sil
    6863:	74 3b                	je     68a0 <fwp_drop0+0x90>
    6865:	40 80 fe 01          	cmp    $0x1,%sil
    6869:	75 2d                	jne    6898 <fwp_drop0+0x88>
    686b:	8b 71 18             	mov    0x18(%rcx),%esi
    686e:	0f b7 c0             	movzwl %ax,%eax
    6871:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6874:	48 0f af c6          	imul   %rsi,%rax
    6878:	48 c1 e8 20          	shr    $0x20,%rax
    687c:	48 39 c8             	cmp    %rcx,%rax
    687f:	73 17                	jae    6898 <fwp_drop0+0x88>
    6881:	48 01 c2             	add    %rax,%rdx
    6884:	0f b6 02             	movzbl (%rdx),%eax
    6887:	84 c0                	test   %al,%al
    6889:	74 0d                	je     6898 <fwp_drop0+0x88>
    688b:	3c 01                	cmp    $0x1,%al
    688d:	74 21                	je     68b0 <fwp_drop0+0xa0>
    688f:	3c ff                	cmp    $0xff,%al
    6891:	74 65                	je     68f8 <fwp_drop0+0xe8>
    6893:	83 e8 01             	sub    $0x1,%eax
    6896:	88 02                	mov    %al,(%rdx)
    6898:	48 83 c4 18          	add    $0x18,%rsp
    689c:	c3                   	ret
    689d:	0f 1f 00             	nopl   (%rax)
    68a0:	66 85 c0             	test   %ax,%ax
    68a3:	74 df                	je     6884 <fwp_drop0+0x74>
    68a5:	48 83 c4 18          	add    $0x18,%rsp
    68a9:	c3                   	ret
    68aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68b0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    68b4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    68b9:	e8 42 fc ff ff       	call   6500 <fwp_rc_free_arr>
    68be:	4c 8d 05 bb ce 01 00 	lea    0x1cebb(%rip),%r8        # 23780 <fwp_heap>
    68c5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    68ca:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    68d1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    68d8:	48 c1 e2 10          	shl    $0x10,%rdx
    68dc:	48 39 d0             	cmp    %rdx,%rax
    68df:	73 b7                	jae    6898 <fwp_drop0+0x88>
    68e1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    68e6:	e9 52 ff ff ff       	jmp    683d <fwp_drop0+0x2d>
    68eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    68f0:	c3                   	ret
    68f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    68f8:	48 89 d0             	mov    %rdx,%rax
    68fb:	48 c1 e8 11          	shr    $0x11,%rax
    68ff:	48 31 d0             	xor    %rdx,%rax
    6902:	48 89 c1             	mov    %rax,%rcx
    6905:	48 c1 e9 09          	shr    $0x9,%rcx
    6909:	48 31 c8             	xor    %rcx,%rax
    690c:	0f b6 c8             	movzbl %al,%ecx
    690f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6916:	00 
    6917:	48 85 c0             	test   %rax,%rax
    691a:	75 0d                	jne    6929 <fwp_drop0+0x119>
    691c:	eb 46                	jmp    6964 <fwp_drop0+0x154>
    691e:	66 90                	xchg   %ax,%ax
    6920:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6924:	48 85 c0             	test   %rax,%rax
    6927:	74 3b                	je     6964 <fwp_drop0+0x154>
    6929:	48 89 c1             	mov    %rax,%rcx
    692c:	48 39 10             	cmp    %rdx,(%rax)
    692f:	75 ef                	jne    6920 <fwp_drop0+0x110>
    6931:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6935:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6939:	48 89 48 08          	mov    %rcx,0x8(%rax)
    693d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6944:	0f 85 4e ff ff ff    	jne    6898 <fwp_drop0+0x88>
    694a:	48 89 d7             	mov    %rdx,%rdi
    694d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6952:	e8 b9 e9 ff ff       	call   5310 <fwp_rc_forget_slot>
    6957:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    695c:	c6 02 fe             	movb   $0xfe,(%rdx)
    695f:	e9 34 ff ff ff       	jmp    6898 <fwp_drop0+0x88>
    6964:	48 8d 3d 2d 8e 00 00 	lea    0x8e2d(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    696b:	e8 30 d8 ff ff       	call   41a0 <fwp_trap>

0000000000006970 <fwp_arg_drop12>:
    6970:	f3 0f 1e fa          	endbr64
    6974:	85 f6                	test   %esi,%esi
    6976:	75 04                	jne    697c <fwp_arg_drop12+0xc>
    6978:	85 d2                	test   %edx,%edx
    697a:	75 04                	jne    6980 <fwp_arg_drop12+0x10>
    697c:	c3                   	ret
    697d:	0f 1f 00             	nopl   (%rax)
    6980:	48 8b 3f             	mov    (%rdi),%rdi
    6983:	e9 88 fe ff ff       	jmp    6810 <fwp_drop0>
    6988:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    698f:	00 

0000000000006990 <fwp_drop1>:
    6990:	f3 0f 1e fa          	endbr64
    6994:	48 8b 15 bd e1 01 00 	mov    0x1e1bd(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    699b:	48 89 f8             	mov    %rdi,%rax
    699e:	48 2b 05 8b e1 01 00 	sub    0x1e18b(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    69a5:	48 c1 e2 10          	shl    $0x10,%rdx
    69a9:	48 39 d0             	cmp    %rdx,%rax
    69ac:	0f 83 be 00 00 00    	jae    6a70 <fwp_drop1+0xe0>
    69b2:	48 83 ec 18          	sub    $0x18,%rsp
    69b6:	4c 8d 05 c3 cd 01 00 	lea    0x1cdc3(%rip),%r8        # 23780 <fwp_heap>
    69bd:	48 89 c2             	mov    %rax,%rdx
    69c0:	48 c1 ea 10          	shr    $0x10,%rdx
    69c4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    69c8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    69cf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    69d3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    69d7:	48 85 d2             	test   %rdx,%rdx
    69da:	74 3c                	je     6a18 <fwp_drop1+0x88>
    69dc:	0f b6 31             	movzbl (%rcx),%esi
    69df:	40 80 fe 02          	cmp    $0x2,%sil
    69e3:	74 3b                	je     6a20 <fwp_drop1+0x90>
    69e5:	40 80 fe 01          	cmp    $0x1,%sil
    69e9:	75 2d                	jne    6a18 <fwp_drop1+0x88>
    69eb:	8b 71 18             	mov    0x18(%rcx),%esi
    69ee:	0f b7 c0             	movzwl %ax,%eax
    69f1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    69f4:	48 0f af c6          	imul   %rsi,%rax
    69f8:	48 c1 e8 20          	shr    $0x20,%rax
    69fc:	48 39 c8             	cmp    %rcx,%rax
    69ff:	73 17                	jae    6a18 <fwp_drop1+0x88>
    6a01:	48 01 c2             	add    %rax,%rdx
    6a04:	0f b6 02             	movzbl (%rdx),%eax
    6a07:	84 c0                	test   %al,%al
    6a09:	74 0d                	je     6a18 <fwp_drop1+0x88>
    6a0b:	3c 01                	cmp    $0x1,%al
    6a0d:	74 21                	je     6a30 <fwp_drop1+0xa0>
    6a0f:	3c ff                	cmp    $0xff,%al
    6a11:	74 65                	je     6a78 <fwp_drop1+0xe8>
    6a13:	83 e8 01             	sub    $0x1,%eax
    6a16:	88 02                	mov    %al,(%rdx)
    6a18:	48 83 c4 18          	add    $0x18,%rsp
    6a1c:	c3                   	ret
    6a1d:	0f 1f 00             	nopl   (%rax)
    6a20:	66 85 c0             	test   %ax,%ax
    6a23:	74 df                	je     6a04 <fwp_drop1+0x74>
    6a25:	48 83 c4 18          	add    $0x18,%rsp
    6a29:	c3                   	ret
    6a2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a30:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6a34:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6a39:	e8 c2 fa ff ff       	call   6500 <fwp_rc_free_arr>
    6a3e:	4c 8d 05 3b cd 01 00 	lea    0x1cd3b(%rip),%r8        # 23780 <fwp_heap>
    6a45:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6a4a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6a51:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6a58:	48 c1 e2 10          	shl    $0x10,%rdx
    6a5c:	48 39 d0             	cmp    %rdx,%rax
    6a5f:	73 b7                	jae    6a18 <fwp_drop1+0x88>
    6a61:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6a66:	e9 52 ff ff ff       	jmp    69bd <fwp_drop1+0x2d>
    6a6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6a70:	c3                   	ret
    6a71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6a78:	48 89 d0             	mov    %rdx,%rax
    6a7b:	48 c1 e8 11          	shr    $0x11,%rax
    6a7f:	48 31 d0             	xor    %rdx,%rax
    6a82:	48 89 c1             	mov    %rax,%rcx
    6a85:	48 c1 e9 09          	shr    $0x9,%rcx
    6a89:	48 31 c8             	xor    %rcx,%rax
    6a8c:	0f b6 c8             	movzbl %al,%ecx
    6a8f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6a96:	00 
    6a97:	48 85 c0             	test   %rax,%rax
    6a9a:	75 0d                	jne    6aa9 <fwp_drop1+0x119>
    6a9c:	eb 46                	jmp    6ae4 <fwp_drop1+0x154>
    6a9e:	66 90                	xchg   %ax,%ax
    6aa0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6aa4:	48 85 c0             	test   %rax,%rax
    6aa7:	74 3b                	je     6ae4 <fwp_drop1+0x154>
    6aa9:	48 89 c1             	mov    %rax,%rcx
    6aac:	48 39 10             	cmp    %rdx,(%rax)
    6aaf:	75 ef                	jne    6aa0 <fwp_drop1+0x110>
    6ab1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6ab5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6ab9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6abd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6ac4:	0f 85 4e ff ff ff    	jne    6a18 <fwp_drop1+0x88>
    6aca:	48 89 d7             	mov    %rdx,%rdi
    6acd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6ad2:	e8 39 e8 ff ff       	call   5310 <fwp_rc_forget_slot>
    6ad7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6adc:	c6 02 fe             	movb   $0xfe,(%rdx)
    6adf:	e9 34 ff ff ff       	jmp    6a18 <fwp_drop1+0x88>
    6ae4:	48 8d 3d ad 8c 00 00 	lea    0x8cad(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    6aeb:	e8 b0 d6 ff ff       	call   41a0 <fwp_trap>

0000000000006af0 <fwp_closure_drop>:
    6af0:	48 8b 15 61 e0 01 00 	mov    0x1e061(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    6af7:	48 89 f8             	mov    %rdi,%rax
    6afa:	48 2b 05 2f e0 01 00 	sub    0x1e02f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6b01:	48 c1 e2 10          	shl    $0x10,%rdx
    6b05:	48 39 d0             	cmp    %rdx,%rax
    6b08:	73 6b                	jae    6b75 <fwp_closure_drop+0x85>
    6b0a:	48 89 c2             	mov    %rax,%rdx
    6b0d:	48 c1 ea 10          	shr    $0x10,%rdx
    6b11:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b15:	48 8b 15 5c e0 01 00 	mov    0x1e05c(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    6b1c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6b20:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6b24:	48 85 d2             	test   %rdx,%rdx
    6b27:	74 4c                	je     6b75 <fwp_closure_drop+0x85>
    6b29:	0f b6 31             	movzbl (%rcx),%esi
    6b2c:	40 80 fe 02          	cmp    $0x2,%sil
    6b30:	74 3e                	je     6b70 <fwp_closure_drop+0x80>
    6b32:	40 80 fe 01          	cmp    $0x1,%sil
    6b36:	75 3d                	jne    6b75 <fwp_closure_drop+0x85>
    6b38:	8b 71 18             	mov    0x18(%rcx),%esi
    6b3b:	0f b7 c0             	movzwl %ax,%eax
    6b3e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6b41:	48 0f af c6          	imul   %rsi,%rax
    6b45:	48 c1 e8 20          	shr    $0x20,%rax
    6b49:	48 39 c8             	cmp    %rcx,%rax
    6b4c:	73 27                	jae    6b75 <fwp_closure_drop+0x85>
    6b4e:	48 01 c2             	add    %rax,%rdx
    6b51:	0f b6 02             	movzbl (%rdx),%eax
    6b54:	84 c0                	test   %al,%al
    6b56:	74 1d                	je     6b75 <fwp_closure_drop+0x85>
    6b58:	3c 01                	cmp    $0x1,%al
    6b5a:	74 24                	je     6b80 <fwp_closure_drop+0x90>
    6b5c:	3c ff                	cmp    $0xff,%al
    6b5e:	74 48                	je     6ba8 <fwp_closure_drop+0xb8>
    6b60:	83 e8 01             	sub    $0x1,%eax
    6b63:	88 02                	mov    %al,(%rdx)
    6b65:	c3                   	ret
    6b66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b6d:	00 00 00 
    6b70:	66 85 c0             	test   %ax,%ax
    6b73:	74 dc                	je     6b51 <fwp_closure_drop+0x61>
    6b75:	c3                   	ret
    6b76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b7d:	00 00 00 
    6b80:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6b87:	ff ff 
    6b89:	48 85 c0             	test   %rax,%rax
    6b8c:	74 12                	je     6ba0 <fwp_closure_drop+0xb0>
    6b8e:	48 89 fe             	mov    %rdi,%rsi
    6b91:	48 89 c7             	mov    %rax,%rdi
    6b94:	e9 67 d6 ff ff       	jmp    4200 <fwp_closure_drop_push>
    6b99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6ba0:	e9 0b d8 ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    6ba5:	0f 1f 00             	nopl   (%rax)
    6ba8:	48 89 d0             	mov    %rdx,%rax
    6bab:	48 8d 35 ce cb 01 00 	lea    0x1cbce(%rip),%rsi        # 23780 <fwp_heap>
    6bb2:	48 83 ec 18          	sub    $0x18,%rsp
    6bb6:	48 c1 e8 11          	shr    $0x11,%rax
    6bba:	48 31 d0             	xor    %rdx,%rax
    6bbd:	48 89 c1             	mov    %rax,%rcx
    6bc0:	48 c1 e9 09          	shr    $0x9,%rcx
    6bc4:	48 31 c8             	xor    %rcx,%rax
    6bc7:	0f b6 c8             	movzbl %al,%ecx
    6bca:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6bd1:	00 
    6bd2:	48 85 c0             	test   %rax,%rax
    6bd5:	75 12                	jne    6be9 <fwp_closure_drop+0xf9>
    6bd7:	eb 49                	jmp    6c22 <fwp_closure_drop+0x132>
    6bd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6be0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6be4:	48 85 c0             	test   %rax,%rax
    6be7:	74 39                	je     6c22 <fwp_closure_drop+0x132>
    6be9:	48 89 c1             	mov    %rax,%rcx
    6bec:	48 39 10             	cmp    %rdx,(%rax)
    6bef:	75 ef                	jne    6be0 <fwp_closure_drop+0xf0>
    6bf1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6bf5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6bf9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6bfd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6c04:	74 05                	je     6c0b <fwp_closure_drop+0x11b>
    6c06:	48 83 c4 18          	add    $0x18,%rsp
    6c0a:	c3                   	ret
    6c0b:	48 89 d7             	mov    %rdx,%rdi
    6c0e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6c13:	e8 f8 e6 ff ff       	call   5310 <fwp_rc_forget_slot>
    6c18:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6c1d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6c20:	eb e4                	jmp    6c06 <fwp_closure_drop+0x116>
    6c22:	48 8d 3d 6f 8b 00 00 	lea    0x8b6f(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    6c29:	e8 72 d5 ff ff       	call   41a0 <fwp_trap>
    6c2e:	66 90                	xchg   %ax,%ax

0000000000006c30 <fwp_owned_tape_release>:
    6c30:	48 85 ff             	test   %rdi,%rdi
    6c33:	0f 84 f7 00 00 00    	je     6d30 <fwp_owned_tape_release+0x100>
    6c39:	41 54                	push   %r12
    6c3b:	55                   	push   %rbp
    6c3c:	53                   	push   %rbx
    6c3d:	48 8b 07             	mov    (%rdi),%rax
    6c40:	48 85 c0             	test   %rax,%rax
    6c43:	74 08                	je     6c4d <fwp_owned_tape_release+0x1d>
    6c45:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6c49:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6c4d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6c51:	48 85 d2             	test   %rdx,%rdx
    6c54:	74 03                	je     6c59 <fwp_owned_tape_release+0x29>
    6c56:	48 89 02             	mov    %rax,(%rdx)
    6c59:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6c5d:	48 89 fb             	mov    %rdi,%rbx
    6c60:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6c64:	48 85 c0             	test   %rax,%rax
    6c67:	0f 84 89 00 00 00    	je     6cf6 <fwp_owned_tape_release+0xc6>
    6c6d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6c71:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6c75:	7e 47                	jle    6cbe <fwp_owned_tape_release+0x8e>
    6c77:	31 ed                	xor    %ebp,%ebp
    6c79:	eb 0d                	jmp    6c88 <fwp_owned_tape_release+0x58>
    6c7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6c80:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6c84:	48 8b 40 68          	mov    0x68(%rax),%rax
    6c88:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6c8c:	49 89 ec             	mov    %rbp,%r12
    6c8f:	48 83 c5 01          	add    $0x1,%rbp
    6c93:	49 c1 e4 04          	shl    $0x4,%r12
    6c97:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6c9b:	ff d0                	call   *%rax
    6c9d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6ca1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6ca6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6caa:	ff 50 68             	call   *0x68(%rax)
    6cad:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6cb1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6cb5:	48 39 e8             	cmp    %rbp,%rax
    6cb8:	7f c6                	jg     6c80 <fwp_owned_tape_release+0x50>
    6cba:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6cbe:	31 ed                	xor    %ebp,%ebp
    6cc0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6cc5:	7e 28                	jle    6cef <fwp_owned_tape_release+0xbf>
    6cc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6cce:	00 00 
    6cd0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6cd4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6cd8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6cdc:	74 07                	je     6ce5 <fwp_owned_tape_release+0xb5>
    6cde:	ff 52 68             	call   *0x68(%rdx)
    6ce1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6ce5:	48 83 c5 01          	add    $0x1,%rbp
    6ce9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6ced:	7f e1                	jg     6cd0 <fwp_owned_tape_release+0xa0>
    6cef:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6cf3:	ff 52 68             	call   *0x68(%rdx)
    6cf6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6cfa:	e8 f1 fd ff ff       	call   6af0 <fwp_closure_drop>
    6cff:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6d03:	e8 e8 fd ff ff       	call   6af0 <fwp_closure_drop>
    6d08:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6d0c:	e8 df fd ff ff       	call   6af0 <fwp_closure_drop>
    6d11:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6d15:	e8 36 e8 ff ff       	call   5550 <fwp_mem_free>
    6d1a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6d1e:	e8 2d e8 ff ff       	call   5550 <fwp_mem_free>
    6d23:	48 89 df             	mov    %rbx,%rdi
    6d26:	5b                   	pop    %rbx
    6d27:	5d                   	pop    %rbp
    6d28:	41 5c                	pop    %r12
    6d2a:	e9 21 e8 ff ff       	jmp    5550 <fwp_mem_free>
    6d2f:	90                   	nop
    6d30:	c3                   	ret
    6d31:	0f 1f 40 00          	nopl   0x0(%rax)
    6d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d3c:	00 00 00 00 

0000000000006d40 <fwp_tape_finish>:
    6d40:	f3 0f 1e fa          	endbr64
    6d44:	41 56                	push   %r14
    6d46:	48 8d 3d 73 c3 01 00 	lea    0x1c373(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    6d4d:	41 55                	push   %r13
    6d4f:	41 54                	push   %r12
    6d51:	55                   	push   %rbp
    6d52:	53                   	push   %rbx
    6d53:	e8 18 d2 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    6d58:	48 83 3d a8 c3 01 00 	cmpq   $0x0,0x1c3a8(%rip)        # 23108 <fwp_ntapes>
    6d5f:	00 
    6d60:	48 c7 05 3d c3 01 00 	movq   $0x0,0x1c33d(%rip)        # 230a8 <fwp_tape_cached_bytes>
    6d67:	00 00 00 00 
    6d6b:	7e 68                	jle    6dd5 <fwp_tape_finish+0x95>
    6d6d:	45 31 e4             	xor    %r12d,%r12d
    6d70:	31 ed                	xor    %ebp,%ebp
    6d72:	0f 1f 00             	nopl   (%rax)
    6d75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d7c:	00 00 00 00 
    6d80:	48 8b 1d 89 c3 01 00 	mov    0x1c389(%rip),%rbx        # 23110 <fwp_tapes>
    6d87:	48 83 c5 01          	add    $0x1,%rbp
    6d8b:	4c 01 e3             	add    %r12,%rbx
    6d8e:	49 83 c4 68          	add    $0x68,%r12
    6d92:	48 89 df             	mov    %rbx,%rdi
    6d95:	e8 66 ce ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6d9a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6d9e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6da2:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6da6:	e8 15 c6 ff ff       	call   33c0 <free@plt>
    6dab:	4c 89 f7             	mov    %r14,%rdi
    6dae:	e8 0d c6 ff ff       	call   33c0 <free@plt>
    6db3:	4c 89 ef             	mov    %r13,%rdi
    6db6:	e8 05 c6 ff ff       	call   33c0 <free@plt>
    6dbb:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6dbf:	e8 6c fe ff ff       	call   6c30 <fwp_owned_tape_release>
    6dc4:	48 39 2d 3d c3 01 00 	cmp    %rbp,0x1c33d(%rip)        # 23108 <fwp_ntapes>
    6dcb:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6dd2:	00 
    6dd3:	7f ab                	jg     6d80 <fwp_tape_finish+0x40>
    6dd5:	48 8b 3d 34 c3 01 00 	mov    0x1c334(%rip),%rdi        # 23110 <fwp_tapes>
    6ddc:	e8 df c5 ff ff       	call   33c0 <free@plt>
    6de1:	5b                   	pop    %rbx
    6de2:	5d                   	pop    %rbp
    6de3:	48 c7 05 22 c3 01 00 	movq   $0x0,0x1c322(%rip)        # 23110 <fwp_tapes>
    6dea:	00 00 00 00 
    6dee:	48 c7 05 07 c3 01 00 	movq   $0x0,0x1c307(%rip)        # 23100 <fwp_tapes_cap>
    6df5:	00 00 00 00 
    6df9:	41 5c                	pop    %r12
    6dfb:	48 c7 05 02 c3 01 00 	movq   $0x0,0x1c302(%rip)        # 23108 <fwp_ntapes>
    6e02:	00 00 00 00 
    6e06:	41 5d                	pop    %r13
    6e08:	48 c7 05 e5 c2 01 00 	movq   $0x0,0x1c2e5(%rip)        # 230f8 <fwp_tape_next_slot>
    6e0f:	00 00 00 00 
    6e13:	41 5e                	pop    %r14
    6e15:	c3                   	ret
    6e16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e1d:	00 00 00 

0000000000006e20 <fwp_tape_scope_release>:
    6e20:	f3 0f 1e fa          	endbr64
    6e24:	41 55                	push   %r13
    6e26:	41 54                	push   %r12
    6e28:	55                   	push   %rbp
    6e29:	53                   	push   %rbx
    6e2a:	48 83 ec 58          	sub    $0x58,%rsp
    6e2e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6e35:	00 00 
    6e37:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6e3c:	48 63 07             	movslq (%rdi),%rax
    6e3f:	85 c0                	test   %eax,%eax
    6e41:	0f 88 05 01 00 00    	js     6f4c <fwp_tape_scope_release+0x12c>
    6e47:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6e4e:	ec c4 4e 
    6e51:	48 89 fb             	mov    %rdi,%rbx
    6e54:	eb 3c                	jmp    6e92 <fwp_tape_scope_release+0x72>
    6e56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e5d:	00 00 00 
    6e60:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6e65:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6e69:	e8 52 c5 ff ff       	call   33c0 <free@plt>
    6e6e:	48 8b 3c 24          	mov    (%rsp),%rdi
    6e72:	e8 49 c5 ff ff       	call   33c0 <free@plt>
    6e77:	4c 89 ef             	mov    %r13,%rdi
    6e7a:	e8 41 c5 ff ff       	call   33c0 <free@plt>
    6e7f:	4c 89 e7             	mov    %r12,%rdi
    6e82:	e8 a9 fd ff ff       	call   6c30 <fwp_owned_tape_release>
    6e87:	48 63 03             	movslq (%rbx),%rax
    6e8a:	85 c0                	test   %eax,%eax
    6e8c:	0f 88 ba 00 00 00    	js     6f4c <fwp_tape_scope_release+0x12c>
    6e92:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6e96:	48 8b 35 73 c2 01 00 	mov    0x1c273(%rip),%rsi        # 23110 <fwp_tapes>
    6e9d:	4c 01 c6             	add    %r8,%rsi
    6ea0:	48 89 f7             	mov    %rsi,%rdi
    6ea3:	e8 58 cd ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6ea8:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6ead:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6eb2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6eb9:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6ebd:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6ec1:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6ec8:	00 
    6ec9:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6ece:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6ed2:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6ed7:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6edb:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6ee0:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6ee7:	00 
    6ee8:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6eef:	00 
    6ef0:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6ef7:	00 
    6ef8:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6efd:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6f02:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6f06:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6f0a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6f0e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6f14:	77 18                	ja     6f2e <fwp_tape_scope_release+0x10e>
    6f16:	49 c1 f8 03          	sar    $0x3,%r8
    6f1a:	4c 0f af c5          	imul   %rbp,%r8
    6f1e:	4c 3b 05 d3 c1 01 00 	cmp    0x1c1d3(%rip),%r8        # 230f8 <fwp_tape_next_slot>
    6f25:	7d 07                	jge    6f2e <fwp_tape_scope_release+0x10e>
    6f27:	4c 89 05 ca c1 01 00 	mov    %r8,0x1c1ca(%rip)        # 230f8 <fwp_tape_next_slot>
    6f2e:	4d 85 e4             	test   %r12,%r12
    6f31:	0f 85 29 ff ff ff    	jne    6e60 <fwp_tape_scope_release+0x40>
    6f37:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6f3c:	e8 ef de ff ff       	call   4e30 <fwp_tape_buffers_release>
    6f41:	48 63 03             	movslq (%rbx),%rax
    6f44:	85 c0                	test   %eax,%eax
    6f46:	0f 89 46 ff ff ff    	jns    6e92 <fwp_tape_scope_release+0x72>
    6f4c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6f51:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6f58:	00 00 
    6f5a:	75 0b                	jne    6f67 <fwp_tape_scope_release+0x147>
    6f5c:	48 83 c4 58          	add    $0x58,%rsp
    6f60:	5b                   	pop    %rbx
    6f61:	5d                   	pop    %rbp
    6f62:	41 5c                	pop    %r12
    6f64:	41 5d                	pop    %r13
    6f66:	c3                   	ret
    6f67:	e8 f4 c4 ff ff       	call   3460 <__stack_chk_fail@plt>
    6f6c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006f70 <fwp_task_dispose>:
    6f70:	53                   	push   %rbx
    6f71:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6f75:	0f 84 cb c7 ff ff    	je     3746 <fwp_task_dispose.cold>
    6f7b:	48 89 fb             	mov    %rdi,%rbx
    6f7e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6f83:	0f 85 bd c7 ff ff    	jne    3746 <fwp_task_dispose.cold>
    6f89:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6f8d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6f94:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6f9b:	00 
    6f9c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6fa0:	48 85 ff             	test   %rdi,%rdi
    6fa3:	74 07                	je     6fac <fwp_task_dispose+0x3c>
    6fa5:	48 85 c0             	test   %rax,%rax
    6fa8:	74 02                	je     6fac <fwp_task_dispose+0x3c>
    6faa:	ff d0                	call   *%rax
    6fac:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    6fb3:	e8 98 e5 ff ff       	call   5550 <fwp_mem_free>
    6fb8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    6fbf:	00 00 00 00 
    6fc3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    6fc7:	74 6f                	je     7038 <fwp_task_dispose+0xc8>
    6fc9:	48 8b 15 88 db 01 00 	mov    0x1db88(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    6fd0:	48 89 d8             	mov    %rbx,%rax
    6fd3:	48 2b 05 56 db 01 00 	sub    0x1db56(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6fda:	48 c1 e2 10          	shl    $0x10,%rdx
    6fde:	48 39 d0             	cmp    %rdx,%rax
    6fe1:	73 4c                	jae    702f <fwp_task_dispose+0xbf>
    6fe3:	48 89 c2             	mov    %rax,%rdx
    6fe6:	48 c1 ea 10          	shr    $0x10,%rdx
    6fea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6fee:	48 8b 15 83 db 01 00 	mov    0x1db83(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    6ff5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6ff9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6ffd:	48 85 c9             	test   %rcx,%rcx
    7000:	74 2d                	je     702f <fwp_task_dispose+0xbf>
    7002:	0f b6 32             	movzbl (%rdx),%esi
    7005:	40 80 fe 02          	cmp    $0x2,%sil
    7009:	74 3d                	je     7048 <fwp_task_dispose+0xd8>
    700b:	40 80 fe 01          	cmp    $0x1,%sil
    700f:	75 1e                	jne    702f <fwp_task_dispose+0xbf>
    7011:	8b 72 18             	mov    0x18(%rdx),%esi
    7014:	0f b7 c0             	movzwl %ax,%eax
    7017:	8b 52 1c             	mov    0x1c(%rdx),%edx
    701a:	48 0f af c6          	imul   %rsi,%rax
    701e:	48 c1 e8 20          	shr    $0x20,%rax
    7022:	48 39 d0             	cmp    %rdx,%rax
    7025:	73 08                	jae    702f <fwp_task_dispose+0xbf>
    7027:	48 01 c1             	add    %rax,%rcx
    702a:	80 39 01             	cmpb   $0x1,(%rcx)
    702d:	74 09                	je     7038 <fwp_task_dispose+0xc8>
    702f:	5b                   	pop    %rbx
    7030:	c3                   	ret
    7031:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7038:	48 89 df             	mov    %rbx,%rdi
    703b:	5b                   	pop    %rbx
    703c:	e9 0f e5 ff ff       	jmp    5550 <fwp_mem_free>
    7041:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7048:	66 85 c0             	test   %ax,%ax
    704b:	74 dd                	je     702a <fwp_task_dispose+0xba>
    704d:	5b                   	pop    %rbx
    704e:	c3                   	ret
    704f:	90                   	nop

0000000000007050 <fwp_free_zombie>:
    7050:	48 8b 15 f9 c6 01 00 	mov    0x1c6f9(%rip),%rdx        # 23750 <fwp_zombie>
    7057:	48 85 d2             	test   %rdx,%rdx
    705a:	0f 84 98 00 00 00    	je     70f8 <fwp_free_zombie+0xa8>
    7060:	48 3b 15 f9 c6 01 00 	cmp    0x1c6f9(%rip),%rdx        # 23760 <fwp_cur>
    7067:	0f 84 8b 00 00 00    	je     70f8 <fwp_free_zombie+0xa8>
    706d:	48 83 ec 18          	sub    $0x18,%rsp
    7071:	48 63 05 b4 c0 01 00 	movslq 0x1c0b4(%rip),%rax        # 2312c <fwp_stack_pool_n>
    7078:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    707c:	83 f8 3f             	cmp    $0x3f,%eax
    707f:	7f 7f                	jg     7100 <fwp_free_zombie+0xb0>
    7081:	8d 48 01             	lea    0x1(%rax),%ecx
    7084:	89 0d a2 c0 01 00    	mov    %ecx,0x1c0a2(%rip)        # 2312c <fwp_stack_pool_n>
    708a:	48 8d 0d af c0 01 00 	lea    0x1c0af(%rip),%rcx        # 23140 <fwp_stack_pool>
    7091:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7095:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    709c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    70a0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    70a7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    70ab:	48 85 c9             	test   %rcx,%rcx
    70ae:	0f 84 fc 00 00 00    	je     71b0 <fwp_free_zombie+0x160>
    70b4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    70bb:	48 85 c0             	test   %rax,%rax
    70be:	74 07                	je     70c7 <fwp_free_zombie+0x77>
    70c0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    70c7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    70ca:	66 0f ef c0          	pxor   %xmm0,%xmm0
    70ce:	48 c7 05 77 c6 01 00 	movq   $0x0,0x1c677(%rip)        # 23750 <fwp_zombie>
    70d5:	00 00 00 00 
    70d9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    70e0:	85 c0                	test   %eax,%eax
    70e2:	74 34                	je     7118 <fwp_free_zombie+0xc8>
    70e4:	83 f8 01             	cmp    $0x1,%eax
    70e7:	0f 84 b3 00 00 00    	je     71a0 <fwp_free_zombie+0x150>
    70ed:	48 83 c4 18          	add    $0x18,%rsp
    70f1:	c3                   	ret
    70f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    70f8:	c3                   	ret
    70f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7100:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7104:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7109:	e8 d2 c4 ff ff       	call   35e0 <munmap@plt>
    710e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7113:	eb 80                	jmp    7095 <fwp_free_zombie+0x45>
    7115:	0f 1f 00             	nopl   (%rax)
    7118:	48 8b 0d 39 da 01 00 	mov    0x1da39(%rip),%rcx        # 24b58 <fwp_heap+0x13d8>
    711f:	48 89 d0             	mov    %rdx,%rax
    7122:	48 2b 05 07 da 01 00 	sub    0x1da07(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7129:	48 c1 e1 10          	shl    $0x10,%rcx
    712d:	48 39 c8             	cmp    %rcx,%rax
    7130:	73 bb                	jae    70ed <fwp_free_zombie+0x9d>
    7132:	48 89 c1             	mov    %rax,%rcx
    7135:	48 c1 e9 10          	shr    $0x10,%rcx
    7139:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    713d:	48 8b 0d 34 da 01 00 	mov    0x1da34(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    7144:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7148:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    714c:	48 85 c9             	test   %rcx,%rcx
    714f:	74 9c                	je     70ed <fwp_free_zombie+0x9d>
    7151:	0f b6 3e             	movzbl (%rsi),%edi
    7154:	40 80 ff 02          	cmp    $0x2,%dil
    7158:	74 66                	je     71c0 <fwp_free_zombie+0x170>
    715a:	40 80 ff 01          	cmp    $0x1,%dil
    715e:	75 8d                	jne    70ed <fwp_free_zombie+0x9d>
    7160:	8b 7e 18             	mov    0x18(%rsi),%edi
    7163:	0f b7 c0             	movzwl %ax,%eax
    7166:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7169:	48 0f af c7          	imul   %rdi,%rax
    716d:	48 c1 e8 20          	shr    $0x20,%rax
    7171:	48 39 f0             	cmp    %rsi,%rax
    7174:	0f 83 73 ff ff ff    	jae    70ed <fwp_free_zombie+0x9d>
    717a:	48 01 c1             	add    %rax,%rcx
    717d:	0f b6 01             	movzbl (%rcx),%eax
    7180:	84 c0                	test   %al,%al
    7182:	0f 84 65 ff ff ff    	je     70ed <fwp_free_zombie+0x9d>
    7188:	3c 01                	cmp    $0x1,%al
    718a:	74 14                	je     71a0 <fwp_free_zombie+0x150>
    718c:	3c ff                	cmp    $0xff,%al
    718e:	74 3b                	je     71cb <fwp_free_zombie+0x17b>
    7190:	83 e8 01             	sub    $0x1,%eax
    7193:	88 01                	mov    %al,(%rcx)
    7195:	e9 53 ff ff ff       	jmp    70ed <fwp_free_zombie+0x9d>
    719a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    71a0:	48 89 d7             	mov    %rdx,%rdi
    71a3:	48 83 c4 18          	add    $0x18,%rsp
    71a7:	e9 c4 fd ff ff       	jmp    6f70 <fwp_task_dispose>
    71ac:	0f 1f 40 00          	nopl   0x0(%rax)
    71b0:	48 89 05 71 c5 01 00 	mov    %rax,0x1c571(%rip)        # 23728 <fwp_tasks_active>
    71b7:	e9 ff fe ff ff       	jmp    70bb <fwp_free_zombie+0x6b>
    71bc:	0f 1f 40 00          	nopl   0x0(%rax)
    71c0:	66 85 c0             	test   %ax,%ax
    71c3:	0f 85 24 ff ff ff    	jne    70ed <fwp_free_zombie+0x9d>
    71c9:	eb b2                	jmp    717d <fwp_free_zombie+0x12d>
    71cb:	48 89 ca             	mov    %rcx,%rdx
    71ce:	48 8d 35 ab c5 01 00 	lea    0x1c5ab(%rip),%rsi        # 23780 <fwp_heap>
    71d5:	48 c1 ea 11          	shr    $0x11,%rdx
    71d9:	48 31 ca             	xor    %rcx,%rdx
    71dc:	48 89 d0             	mov    %rdx,%rax
    71df:	48 c1 e8 09          	shr    $0x9,%rax
    71e3:	48 31 c2             	xor    %rax,%rdx
    71e6:	0f b6 d2             	movzbl %dl,%edx
    71e9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    71f0:	00 
    71f1:	48 85 c0             	test   %rax,%rax
    71f4:	75 13                	jne    7209 <fwp_free_zombie+0x1b9>
    71f6:	eb 4c                	jmp    7244 <fwp_free_zombie+0x1f4>
    71f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    71ff:	00 
    7200:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7204:	48 85 c0             	test   %rax,%rax
    7207:	74 3b                	je     7244 <fwp_free_zombie+0x1f4>
    7209:	48 89 c2             	mov    %rax,%rdx
    720c:	48 39 08             	cmp    %rcx,(%rax)
    720f:	75 ef                	jne    7200 <fwp_free_zombie+0x1b0>
    7211:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7215:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7219:	48 89 50 08          	mov    %rdx,0x8(%rax)
    721d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7224:	0f 85 c3 fe ff ff    	jne    70ed <fwp_free_zombie+0x9d>
    722a:	48 89 cf             	mov    %rcx,%rdi
    722d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7232:	e8 d9 e0 ff ff       	call   5310 <fwp_rc_forget_slot>
    7237:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    723c:	c6 01 fe             	movb   $0xfe,(%rcx)
    723f:	e9 a9 fe ff ff       	jmp    70ed <fwp_free_zombie+0x9d>
    7244:	48 8d 3d 4d 85 00 00 	lea    0x854d(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    724b:	e8 50 cf ff ff       	call   41a0 <fwp_trap>

0000000000007250 <fwp_block>:
    7250:	48 83 ec 08          	sub    $0x8,%rsp
    7254:	48 8b 05 ed c4 01 00 	mov    0x1c4ed(%rip),%rax        # 23748 <fwp_ready_head>
    725b:	48 85 c0             	test   %rax,%rax
    725e:	0f 84 1c 01 00 00    	je     7380 <fwp_block+0x130>
    7264:	90                   	nop
    7265:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    726c:	00 00 00 00 
    7270:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7277:	48 89 15 ca c4 01 00 	mov    %rdx,0x1c4ca(%rip)        # 23748 <fwp_ready_head>
    727e:	48 85 d2             	test   %rdx,%rdx
    7281:	0f 84 19 01 00 00    	je     73a0 <fwp_block+0x150>
    7287:	48 8b 15 d2 c4 01 00 	mov    0x1c4d2(%rip),%rdx        # 23760 <fwp_cur>
    728e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7292:	48 39 c2             	cmp    %rax,%rdx
    7295:	0f 84 d5 00 00 00    	je     7370 <fwp_block+0x120>
    729b:	48 8b 0d 46 e1 01 00 	mov    0x1e146(%rip),%rcx        # 253e8 <fwp_state_owners>
    72a2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    72a6:	48 89 05 b3 c4 01 00 	mov    %rax,0x1c4b3(%rip)        # 23760 <fwp_cur>
    72ad:	f3 0f 7e 05 5b e1 01 	movq   0x1e15b(%rip),%xmm0        # 25410 <fwp_foreign_callbacks>
    72b4:	00 
    72b5:	0f 16 05 44 e1 01 00 	movhps 0x1e144(%rip),%xmm0        # 25400 <fwp_state>
    72bc:	f3 0f 7e 0d 44 e1 01 	movq   0x1e144(%rip),%xmm1        # 25408 <fwp_handlers>
    72c3:	00 
    72c4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    72cb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    72d2:	0f 16 0d 3f e1 01 00 	movhps 0x1e13f(%rip),%xmm1        # 25418 <fwp_cleanups>
    72d9:	f3 0f 7e 05 17 e1 01 	movq   0x1e117(%rip),%xmm0        # 253f8 <fwp_state_len>
    72e0:	00 
    72e1:	0f 16 05 08 e1 01 00 	movhps 0x1e108(%rip),%xmm0        # 253f0 <fwp_state_cap>
    72e8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    72ef:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    72f6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    72fa:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7301:	48 89 0d 00 e1 01 00 	mov    %rcx,0x1e100(%rip)        # 25408 <fwp_handlers>
    7308:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    730f:	48 89 0d 02 e1 01 00 	mov    %rcx,0x1e102(%rip)        # 25418 <fwp_cleanups>
    7316:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    731d:	48 89 0d ec e0 01 00 	mov    %rcx,0x1e0ec(%rip)        # 25410 <fwp_foreign_callbacks>
    7324:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    732b:	48 89 0d ce e0 01 00 	mov    %rcx,0x1e0ce(%rip)        # 25400 <fwp_state>
    7332:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7339:	48 89 0d b8 e0 01 00 	mov    %rcx,0x1e0b8(%rip)        # 253f8 <fwp_state_len>
    7340:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7347:	48 89 0d a2 e0 01 00 	mov    %rcx,0x1e0a2(%rip)        # 253f0 <fwp_state_cap>
    734e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7355:	48 89 0d 8c e0 01 00 	mov    %rcx,0x1e08c(%rip)        # 253e8 <fwp_state_owners>
    735c:	e8 2f c1 ff ff       	call   3490 <swapcontext@plt>
    7361:	f3 0f 1e fa          	endbr64
    7365:	e8 e6 fc ff ff       	call   7050 <fwp_free_zombie>
    736a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7370:	8b 05 b2 bd 01 00    	mov    0x1bdb2(%rip),%eax        # 23128 <fwp_slice>
    7376:	85 c0                	test   %eax,%eax
    7378:	74 36                	je     73b0 <fwp_block+0x160>
    737a:	48 83 c4 08          	add    $0x8,%rsp
    737e:	c3                   	ret
    737f:	90                   	nop
    7380:	e8 db db ff ff       	call   4f60 <fwp_poll_events>
    7385:	48 8b 05 bc c3 01 00 	mov    0x1c3bc(%rip),%rax        # 23748 <fwp_ready_head>
    738c:	48 85 c0             	test   %rax,%rax
    738f:	0f 85 db fe ff ff    	jne    7270 <fwp_block+0x20>
    7395:	eb e9                	jmp    7380 <fwp_block+0x130>
    7397:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    739e:	00 00 
    73a0:	48 c7 05 95 c3 01 00 	movq   $0x0,0x1c395(%rip)        # 23740 <fwp_ready_tail>
    73a7:	00 00 00 00 
    73ab:	e9 d7 fe ff ff       	jmp    7287 <fwp_block+0x37>
    73b0:	48 8d 3d 6a 7d 00 00 	lea    0x7d6a(%rip),%rdi        # f121 <_IO_stdin_used+0x121>
    73b7:	e8 e4 bf ff ff       	call   33a0 <getenv@plt>
    73bc:	ba 10 27 00 00       	mov    $0x2710,%edx
    73c1:	48 85 c0             	test   %rax,%rax
    73c4:	74 05                	je     73cb <fwp_block+0x17b>
    73c6:	80 38 00             	cmpb   $0x0,(%rax)
    73c9:	75 0b                	jne    73d6 <fwp_block+0x186>
    73cb:	89 15 57 bd 01 00    	mov    %edx,0x1bd57(%rip)        # 23128 <fwp_slice>
    73d1:	48 83 c4 08          	add    $0x8,%rsp
    73d5:	c3                   	ret
    73d6:	ba 0a 00 00 00       	mov    $0xa,%edx
    73db:	31 f6                	xor    %esi,%esi
    73dd:	48 89 c7             	mov    %rax,%rdi
    73e0:	e8 6b c1 ff ff       	call   3550 <strtoll@plt>
    73e5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    73e9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    73f0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    73f5:	0f 46 d0             	cmovbe %eax,%edx
    73f8:	eb d1                	jmp    73cb <fwp_block+0x17b>
    73fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007400 <fwp_drop4>:
    7400:	48 8b 15 51 d7 01 00 	mov    0x1d751(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7407:	48 89 f8             	mov    %rdi,%rax
    740a:	48 2b 05 1f d7 01 00 	sub    0x1d71f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7411:	48 c1 e2 10          	shl    $0x10,%rdx
    7415:	48 39 d0             	cmp    %rdx,%rax
    7418:	0f 83 52 01 00 00    	jae    7570 <fwp_drop4+0x170>
    741e:	48 83 ec 18          	sub    $0x18,%rsp
    7422:	4c 8d 05 57 c3 01 00 	lea    0x1c357(%rip),%r8        # 23780 <fwp_heap>
    7429:	48 89 c2             	mov    %rax,%rdx
    742c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7433:	48 c1 ea 10          	shr    $0x10,%rdx
    7437:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    743b:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    743f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7443:	48 85 d2             	test   %rdx,%rdx
    7446:	74 46                	je     748e <fwp_drop4+0x8e>
    7448:	44 0f b6 09          	movzbl (%rcx),%r9d
    744c:	41 80 f9 02          	cmp    $0x2,%r9b
    7450:	0f 84 ca 00 00 00    	je     7520 <fwp_drop4+0x120>
    7456:	41 80 f9 01          	cmp    $0x1,%r9b
    745a:	75 32                	jne    748e <fwp_drop4+0x8e>
    745c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7460:	0f b7 c0             	movzwl %ax,%eax
    7463:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7466:	49 0f af c1          	imul   %r9,%rax
    746a:	48 c1 e8 20          	shr    $0x20,%rax
    746e:	48 39 c8             	cmp    %rcx,%rax
    7471:	73 1b                	jae    748e <fwp_drop4+0x8e>
    7473:	48 01 c2             	add    %rax,%rdx
    7476:	0f b6 02             	movzbl (%rdx),%eax
    7479:	84 c0                	test   %al,%al
    747b:	74 11                	je     748e <fwp_drop4+0x8e>
    747d:	3c 01                	cmp    $0x1,%al
    747f:	74 17                	je     7498 <fwp_drop4+0x98>
    7481:	3c ff                	cmp    $0xff,%al
    7483:	0f 84 ef 00 00 00    	je     7578 <fwp_drop4+0x178>
    7489:	83 e8 01             	sub    $0x1,%eax
    748c:	88 02                	mov    %al,(%rdx)
    748e:	48 83 c4 18          	add    $0x18,%rsp
    7492:	c3                   	ret
    7493:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7498:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    749c:	0f 88 8e 00 00 00    	js     7530 <fwp_drop4+0x130>
    74a2:	48 8b 15 af d6 01 00 	mov    0x1d6af(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    74a9:	48 89 f8             	mov    %rdi,%rax
    74ac:	48 2b 05 7d d6 01 00 	sub    0x1d67d(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    74b3:	48 c1 e2 10          	shl    $0x10,%rdx
    74b7:	48 39 d0             	cmp    %rdx,%rax
    74ba:	73 d2                	jae    748e <fwp_drop4+0x8e>
    74bc:	48 89 c2             	mov    %rax,%rdx
    74bf:	48 c1 ea 10          	shr    $0x10,%rdx
    74c3:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    74c7:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    74cb:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    74cf:	48 85 c9             	test   %rcx,%rcx
    74d2:	74 ba                	je     748e <fwp_drop4+0x8e>
    74d4:	0f b6 32             	movzbl (%rdx),%esi
    74d7:	40 80 fe 02          	cmp    $0x2,%sil
    74db:	74 33                	je     7510 <fwp_drop4+0x110>
    74dd:	40 80 fe 01          	cmp    $0x1,%sil
    74e1:	75 ab                	jne    748e <fwp_drop4+0x8e>
    74e3:	8b 72 18             	mov    0x18(%rdx),%esi
    74e6:	0f b7 c0             	movzwl %ax,%eax
    74e9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    74ec:	48 0f af c6          	imul   %rsi,%rax
    74f0:	48 c1 e8 20          	shr    $0x20,%rax
    74f4:	48 39 d0             	cmp    %rdx,%rax
    74f7:	73 95                	jae    748e <fwp_drop4+0x8e>
    74f9:	48 01 c1             	add    %rax,%rcx
    74fc:	80 39 01             	cmpb   $0x1,(%rcx)
    74ff:	75 8d                	jne    748e <fwp_drop4+0x8e>
    7501:	48 83 c4 18          	add    $0x18,%rsp
    7505:	e9 46 e0 ff ff       	jmp    5550 <fwp_mem_free>
    750a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7510:	66 85 c0             	test   %ax,%ax
    7513:	74 e7                	je     74fc <fwp_drop4+0xfc>
    7515:	48 83 c4 18          	add    $0x18,%rsp
    7519:	c3                   	ret
    751a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7520:	66 85 c0             	test   %ax,%ax
    7523:	0f 84 4d ff ff ff    	je     7476 <fwp_drop4+0x76>
    7529:	48 83 c4 18          	add    $0x18,%rsp
    752d:	c3                   	ret
    752e:	66 90                	xchg   %ax,%ax
    7530:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7534:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7539:	e8 c2 ef ff ff       	call   6500 <fwp_rc_free_arr>
    753e:	4c 8d 05 3b c2 01 00 	lea    0x1c23b(%rip),%r8        # 23780 <fwp_heap>
    7545:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    754a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7551:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7558:	48 c1 e2 10          	shl    $0x10,%rdx
    755c:	48 39 d0             	cmp    %rdx,%rax
    755f:	0f 83 29 ff ff ff    	jae    748e <fwp_drop4+0x8e>
    7565:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    756a:	e9 ba fe ff ff       	jmp    7429 <fwp_drop4+0x29>
    756f:	90                   	nop
    7570:	c3                   	ret
    7571:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7578:	48 89 d0             	mov    %rdx,%rax
    757b:	48 c1 e8 11          	shr    $0x11,%rax
    757f:	48 31 d0             	xor    %rdx,%rax
    7582:	48 89 c1             	mov    %rax,%rcx
    7585:	48 c1 e9 09          	shr    $0x9,%rcx
    7589:	48 31 c8             	xor    %rcx,%rax
    758c:	0f b6 c8             	movzbl %al,%ecx
    758f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7596:	00 
    7597:	48 85 c0             	test   %rax,%rax
    759a:	75 0d                	jne    75a9 <fwp_drop4+0x1a9>
    759c:	eb 46                	jmp    75e4 <fwp_drop4+0x1e4>
    759e:	66 90                	xchg   %ax,%ax
    75a0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    75a4:	48 85 c0             	test   %rax,%rax
    75a7:	74 3b                	je     75e4 <fwp_drop4+0x1e4>
    75a9:	48 89 c1             	mov    %rax,%rcx
    75ac:	48 39 10             	cmp    %rdx,(%rax)
    75af:	75 ef                	jne    75a0 <fwp_drop4+0x1a0>
    75b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    75b5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    75b9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    75bd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    75c4:	0f 85 c4 fe ff ff    	jne    748e <fwp_drop4+0x8e>
    75ca:	48 89 d7             	mov    %rdx,%rdi
    75cd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    75d2:	e8 39 dd ff ff       	call   5310 <fwp_rc_forget_slot>
    75d7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    75dc:	c6 02 fe             	movb   $0xfe,(%rdx)
    75df:	e9 aa fe ff ff       	jmp    748e <fwp_drop4+0x8e>
    75e4:	48 8d 3d ad 81 00 00 	lea    0x81ad(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    75eb:	e8 b0 cb ff ff       	call   41a0 <fwp_trap>

00000000000075f0 <fwp_caps161>:
    75f0:	f3 0f 1e fa          	endbr64
    75f4:	85 f6                	test   %esi,%esi
    75f6:	74 08                	je     7600 <fwp_caps161+0x10>
    75f8:	c3                   	ret
    75f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7600:	48 8b 15 51 d5 01 00 	mov    0x1d551(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7607:	48 89 f8             	mov    %rdi,%rax
    760a:	48 2b 05 1f d5 01 00 	sub    0x1d51f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7611:	48 c1 e2 10          	shl    $0x10,%rdx
    7615:	48 39 d0             	cmp    %rdx,%rax
    7618:	73 de                	jae    75f8 <fwp_caps161+0x8>
    761a:	48 89 c2             	mov    %rax,%rdx
    761d:	48 c1 ea 10          	shr    $0x10,%rdx
    7621:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7625:	48 8b 15 4c d5 01 00 	mov    0x1d54c(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    762c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7630:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7634:	48 85 c9             	test   %rcx,%rcx
    7637:	74 bf                	je     75f8 <fwp_caps161+0x8>
    7639:	0f b6 32             	movzbl (%rdx),%esi
    763c:	40 80 fe 02          	cmp    $0x2,%sil
    7640:	74 2e                	je     7670 <fwp_caps161+0x80>
    7642:	40 80 fe 01          	cmp    $0x1,%sil
    7646:	75 b0                	jne    75f8 <fwp_caps161+0x8>
    7648:	8b 72 18             	mov    0x18(%rdx),%esi
    764b:	0f b7 c0             	movzwl %ax,%eax
    764e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7651:	48 0f af c6          	imul   %rsi,%rax
    7655:	48 c1 e8 20          	shr    $0x20,%rax
    7659:	48 39 d0             	cmp    %rdx,%rax
    765c:	73 9a                	jae    75f8 <fwp_caps161+0x8>
    765e:	48 01 c1             	add    %rax,%rcx
    7661:	80 39 01             	cmpb   $0x1,(%rcx)
    7664:	75 92                	jne    75f8 <fwp_caps161+0x8>
    7666:	e9 e5 de ff ff       	jmp    5550 <fwp_mem_free>
    766b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7670:	66 85 c0             	test   %ax,%ax
    7673:	74 ec                	je     7661 <fwp_caps161+0x71>
    7675:	c3                   	ret
    7676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    767d:	00 00 00 

0000000000007680 <fwp_args12>:
    7680:	f3 0f 1e fa          	endbr64
    7684:	85 d2                	test   %edx,%edx
    7686:	74 04                	je     768c <fwp_args12+0xc>
    7688:	85 f6                	test   %esi,%esi
    768a:	74 04                	je     7690 <fwp_args12+0x10>
    768c:	c3                   	ret
    768d:	0f 1f 00             	nopl   (%rax)
    7690:	48 8b 15 c1 d4 01 00 	mov    0x1d4c1(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7697:	48 8b 07             	mov    (%rdi),%rax
    769a:	48 2b 05 8f d4 01 00 	sub    0x1d48f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    76a1:	48 c1 e2 10          	shl    $0x10,%rdx
    76a5:	48 39 d0             	cmp    %rdx,%rax
    76a8:	73 e2                	jae    768c <fwp_args12+0xc>
    76aa:	48 89 c2             	mov    %rax,%rdx
    76ad:	48 c1 ea 10          	shr    $0x10,%rdx
    76b1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    76b5:	48 8b 15 bc d4 01 00 	mov    0x1d4bc(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    76bc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    76c0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    76c4:	48 85 ff             	test   %rdi,%rdi
    76c7:	74 c3                	je     768c <fwp_args12+0xc>
    76c9:	0f b6 0a             	movzbl (%rdx),%ecx
    76cc:	80 f9 02             	cmp    $0x2,%cl
    76cf:	74 2f                	je     7700 <fwp_args12+0x80>
    76d1:	80 f9 01             	cmp    $0x1,%cl
    76d4:	75 b6                	jne    768c <fwp_args12+0xc>
    76d6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    76d9:	0f b7 c0             	movzwl %ax,%eax
    76dc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    76df:	48 0f af c1          	imul   %rcx,%rax
    76e3:	48 c1 e8 20          	shr    $0x20,%rax
    76e7:	48 39 d0             	cmp    %rdx,%rax
    76ea:	73 a0                	jae    768c <fwp_args12+0xc>
    76ec:	48 01 c7             	add    %rax,%rdi
    76ef:	0f b6 07             	movzbl (%rdi),%eax
    76f2:	84 c0                	test   %al,%al
    76f4:	74 96                	je     768c <fwp_args12+0xc>
    76f6:	3c fd                	cmp    $0xfd,%al
    76f8:	77 0c                	ja     7706 <fwp_args12+0x86>
    76fa:	83 c0 01             	add    $0x1,%eax
    76fd:	88 07                	mov    %al,(%rdi)
    76ff:	c3                   	ret
    7700:	66 85 c0             	test   %ax,%ax
    7703:	74 ea                	je     76ef <fwp_args12+0x6f>
    7705:	c3                   	ret
    7706:	e9 e5 da ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    770b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007710 <fwp_args23>:
    7710:	f3 0f 1e fa          	endbr64
    7714:	85 d2                	test   %edx,%edx
    7716:	74 04                	je     771c <fwp_args23+0xc>
    7718:	85 f6                	test   %esi,%esi
    771a:	74 04                	je     7720 <fwp_args23+0x10>
    771c:	c3                   	ret
    771d:	0f 1f 00             	nopl   (%rax)
    7720:	48 8b 15 31 d4 01 00 	mov    0x1d431(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7727:	48 8b 07             	mov    (%rdi),%rax
    772a:	48 2b 05 ff d3 01 00 	sub    0x1d3ff(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7731:	48 c1 e2 10          	shl    $0x10,%rdx
    7735:	48 39 d0             	cmp    %rdx,%rax
    7738:	73 e2                	jae    771c <fwp_args23+0xc>
    773a:	48 89 c2             	mov    %rax,%rdx
    773d:	48 c1 ea 10          	shr    $0x10,%rdx
    7741:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7745:	48 8b 15 2c d4 01 00 	mov    0x1d42c(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    774c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7750:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7754:	48 85 ff             	test   %rdi,%rdi
    7757:	74 c3                	je     771c <fwp_args23+0xc>
    7759:	0f b6 0a             	movzbl (%rdx),%ecx
    775c:	80 f9 02             	cmp    $0x2,%cl
    775f:	74 2f                	je     7790 <fwp_args23+0x80>
    7761:	80 f9 01             	cmp    $0x1,%cl
    7764:	75 b6                	jne    771c <fwp_args23+0xc>
    7766:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7769:	0f b7 c0             	movzwl %ax,%eax
    776c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    776f:	48 0f af c1          	imul   %rcx,%rax
    7773:	48 c1 e8 20          	shr    $0x20,%rax
    7777:	48 39 d0             	cmp    %rdx,%rax
    777a:	73 a0                	jae    771c <fwp_args23+0xc>
    777c:	48 01 c7             	add    %rax,%rdi
    777f:	0f b6 07             	movzbl (%rdi),%eax
    7782:	84 c0                	test   %al,%al
    7784:	74 96                	je     771c <fwp_args23+0xc>
    7786:	3c fd                	cmp    $0xfd,%al
    7788:	77 0c                	ja     7796 <fwp_args23+0x86>
    778a:	83 c0 01             	add    $0x1,%eax
    778d:	88 07                	mov    %al,(%rdi)
    778f:	c3                   	ret
    7790:	66 85 c0             	test   %ax,%ax
    7793:	74 ea                	je     777f <fwp_args23+0x6f>
    7795:	c3                   	ret
    7796:	e9 55 da ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    779b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000077a0 <fwp_caps12>:
    77a0:	f3 0f 1e fa          	endbr64
    77a4:	48 83 ec 18          	sub    $0x18,%rsp
    77a8:	8b 57 04             	mov    0x4(%rdi),%edx
    77ab:	48 89 f8             	mov    %rdi,%rax
    77ae:	85 d2                	test   %edx,%edx
    77b0:	0f 84 9a 00 00 00    	je     7850 <fwp_caps12+0xb0>
    77b6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    77ba:	85 f6                	test   %esi,%esi
    77bc:	0f 85 9e 00 00 00    	jne    7860 <fwp_caps12+0xc0>
    77c2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    77c7:	e8 44 f0 ff ff       	call   6810 <fwp_drop0>
    77cc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    77d1:	48 8b 0d 80 d3 01 00 	mov    0x1d380(%rip),%rcx        # 24b58 <fwp_heap+0x13d8>
    77d8:	48 89 c2             	mov    %rax,%rdx
    77db:	48 2b 15 4e d3 01 00 	sub    0x1d34e(%rip),%rdx        # 24b30 <fwp_heap+0x13b0>
    77e2:	48 c1 e1 10          	shl    $0x10,%rcx
    77e6:	48 39 ca             	cmp    %rcx,%rdx
    77e9:	73 6d                	jae    7858 <fwp_caps12+0xb8>
    77eb:	48 89 d1             	mov    %rdx,%rcx
    77ee:	48 c1 e9 10          	shr    $0x10,%rcx
    77f2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    77f6:	48 8b 0d 7b d3 01 00 	mov    0x1d37b(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    77fd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7801:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7805:	48 85 f6             	test   %rsi,%rsi
    7808:	74 4e                	je     7858 <fwp_caps12+0xb8>
    780a:	0f b6 39             	movzbl (%rcx),%edi
    780d:	40 80 ff 02          	cmp    $0x2,%dil
    7811:	0f 84 b9 00 00 00    	je     78d0 <fwp_caps12+0x130>
    7817:	40 80 ff 01          	cmp    $0x1,%dil
    781b:	75 3b                	jne    7858 <fwp_caps12+0xb8>
    781d:	8b 79 18             	mov    0x18(%rcx),%edi
    7820:	0f b7 d2             	movzwl %dx,%edx
    7823:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7826:	48 0f af d7          	imul   %rdi,%rdx
    782a:	48 c1 ea 20          	shr    $0x20,%rdx
    782e:	48 39 ca             	cmp    %rcx,%rdx
    7831:	73 25                	jae    7858 <fwp_caps12+0xb8>
    7833:	48 01 d6             	add    %rdx,%rsi
    7836:	80 3e 01             	cmpb   $0x1,(%rsi)
    7839:	75 1d                	jne    7858 <fwp_caps12+0xb8>
    783b:	48 89 c7             	mov    %rax,%rdi
    783e:	48 83 c4 18          	add    $0x18,%rsp
    7842:	e9 09 dd ff ff       	jmp    5550 <fwp_mem_free>
    7847:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    784e:	00 00 
    7850:	85 f6                	test   %esi,%esi
    7852:	0f 84 79 ff ff ff    	je     77d1 <fwp_caps12+0x31>
    7858:	48 83 c4 18          	add    $0x18,%rsp
    785c:	c3                   	ret
    785d:	0f 1f 00             	nopl   (%rax)
    7860:	48 8b 05 f1 d2 01 00 	mov    0x1d2f1(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    7867:	48 2b 3d c2 d2 01 00 	sub    0x1d2c2(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    786e:	48 c1 e0 10          	shl    $0x10,%rax
    7872:	48 39 c7             	cmp    %rax,%rdi
    7875:	73 e1                	jae    7858 <fwp_caps12+0xb8>
    7877:	48 89 f8             	mov    %rdi,%rax
    787a:	48 c1 e8 10          	shr    $0x10,%rax
    787e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7882:	48 8b 05 ef d2 01 00 	mov    0x1d2ef(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    7889:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    788d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7891:	48 85 c0             	test   %rax,%rax
    7894:	74 c2                	je     7858 <fwp_caps12+0xb8>
    7896:	0f b6 0a             	movzbl (%rdx),%ecx
    7899:	80 f9 02             	cmp    $0x2,%cl
    789c:	74 42                	je     78e0 <fwp_caps12+0x140>
    789e:	80 f9 01             	cmp    $0x1,%cl
    78a1:	75 b5                	jne    7858 <fwp_caps12+0xb8>
    78a3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    78a6:	0f b7 ff             	movzwl %di,%edi
    78a9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    78ac:	48 0f af f9          	imul   %rcx,%rdi
    78b0:	48 c1 ef 20          	shr    $0x20,%rdi
    78b4:	48 39 d7             	cmp    %rdx,%rdi
    78b7:	73 9f                	jae    7858 <fwp_caps12+0xb8>
    78b9:	48 01 f8             	add    %rdi,%rax
    78bc:	0f b6 10             	movzbl (%rax),%edx
    78bf:	84 d2                	test   %dl,%dl
    78c1:	74 95                	je     7858 <fwp_caps12+0xb8>
    78c3:	80 fa fd             	cmp    $0xfd,%dl
    78c6:	77 23                	ja     78eb <fwp_caps12+0x14b>
    78c8:	83 c2 01             	add    $0x1,%edx
    78cb:	88 10                	mov    %dl,(%rax)
    78cd:	eb 89                	jmp    7858 <fwp_caps12+0xb8>
    78cf:	90                   	nop
    78d0:	66 85 d2             	test   %dx,%dx
    78d3:	0f 85 7f ff ff ff    	jne    7858 <fwp_caps12+0xb8>
    78d9:	e9 58 ff ff ff       	jmp    7836 <fwp_caps12+0x96>
    78de:	66 90                	xchg   %ax,%ax
    78e0:	66 85 ff             	test   %di,%di
    78e3:	0f 85 6f ff ff ff    	jne    7858 <fwp_caps12+0xb8>
    78e9:	eb d1                	jmp    78bc <fwp_caps12+0x11c>
    78eb:	48 89 c7             	mov    %rax,%rdi
    78ee:	48 83 c4 18          	add    $0x18,%rsp
    78f2:	e9 f9 d8 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    78f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    78fe:	00 00 

0000000000007900 <fwp_drop2>:
    7900:	48 8b 0d 51 d2 01 00 	mov    0x1d251(%rip),%rcx        # 24b58 <fwp_heap+0x13d8>
    7907:	48 89 f8             	mov    %rdi,%rax
    790a:	48 2b 05 1f d2 01 00 	sub    0x1d21f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7911:	48 c1 e1 10          	shl    $0x10,%rcx
    7915:	48 39 c8             	cmp    %rcx,%rax
    7918:	0f 83 42 01 00 00    	jae    7a60 <fwp_drop2+0x160>
    791e:	48 83 ec 18          	sub    $0x18,%rsp
    7922:	48 89 fa             	mov    %rdi,%rdx
    7925:	4c 8d 05 54 be 01 00 	lea    0x1be54(%rip),%r8        # 23780 <fwp_heap>
    792c:	48 89 c1             	mov    %rax,%rcx
    792f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7936:	48 c1 e9 10          	shr    $0x10,%rcx
    793a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    793e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7942:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7946:	48 85 c9             	test   %rcx,%rcx
    7949:	74 40                	je     798b <fwp_drop2+0x8b>
    794b:	0f b6 3e             	movzbl (%rsi),%edi
    794e:	40 80 ff 02          	cmp    $0x2,%dil
    7952:	74 3c                	je     7990 <fwp_drop2+0x90>
    7954:	40 80 ff 01          	cmp    $0x1,%dil
    7958:	75 31                	jne    798b <fwp_drop2+0x8b>
    795a:	8b 7e 18             	mov    0x18(%rsi),%edi
    795d:	0f b7 c0             	movzwl %ax,%eax
    7960:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7963:	48 0f af c7          	imul   %rdi,%rax
    7967:	48 c1 e8 20          	shr    $0x20,%rax
    796b:	48 39 f0             	cmp    %rsi,%rax
    796e:	73 1b                	jae    798b <fwp_drop2+0x8b>
    7970:	48 01 c1             	add    %rax,%rcx
    7973:	0f b6 01             	movzbl (%rcx),%eax
    7976:	84 c0                	test   %al,%al
    7978:	74 11                	je     798b <fwp_drop2+0x8b>
    797a:	3c 01                	cmp    $0x1,%al
    797c:	74 22                	je     79a0 <fwp_drop2+0xa0>
    797e:	3c ff                	cmp    $0xff,%al
    7980:	0f 84 0a 01 00 00    	je     7a90 <fwp_drop2+0x190>
    7986:	83 e8 01             	sub    $0x1,%eax
    7989:	88 01                	mov    %al,(%rcx)
    798b:	48 83 c4 18          	add    $0x18,%rsp
    798f:	c3                   	ret
    7990:	66 85 c0             	test   %ax,%ax
    7993:	74 de                	je     7973 <fwp_drop2+0x73>
    7995:	48 83 c4 18          	add    $0x18,%rsp
    7999:	c3                   	ret
    799a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    79a0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    79a4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    79ab:	48 89 f8             	mov    %rdi,%rax
    79ae:	48 c1 e1 10          	shl    $0x10,%rcx
    79b2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    79b9:	48 39 c8             	cmp    %rcx,%rax
    79bc:	73 62                	jae    7a20 <fwp_drop2+0x120>
    79be:	48 89 c1             	mov    %rax,%rcx
    79c1:	48 c1 e9 10          	shr    $0x10,%rcx
    79c5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    79c9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    79cd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    79d1:	48 85 c9             	test   %rcx,%rcx
    79d4:	74 4a                	je     7a20 <fwp_drop2+0x120>
    79d6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    79da:	41 80 f9 02          	cmp    $0x2,%r9b
    79de:	0f 84 9c 00 00 00    	je     7a80 <fwp_drop2+0x180>
    79e4:	41 80 f9 01          	cmp    $0x1,%r9b
    79e8:	75 36                	jne    7a20 <fwp_drop2+0x120>
    79ea:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    79ee:	0f b7 c0             	movzwl %ax,%eax
    79f1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    79f4:	49 0f af c1          	imul   %r9,%rax
    79f8:	48 c1 e8 20          	shr    $0x20,%rax
    79fc:	48 39 f0             	cmp    %rsi,%rax
    79ff:	73 1f                	jae    7a20 <fwp_drop2+0x120>
    7a01:	48 01 c1             	add    %rax,%rcx
    7a04:	0f b6 01             	movzbl (%rcx),%eax
    7a07:	84 c0                	test   %al,%al
    7a09:	74 15                	je     7a20 <fwp_drop2+0x120>
    7a0b:	3c 01                	cmp    $0x1,%al
    7a0d:	74 59                	je     7a68 <fwp_drop2+0x168>
    7a0f:	3c ff                	cmp    $0xff,%al
    7a11:	0f 84 ef 00 00 00    	je     7b06 <fwp_drop2+0x206>
    7a17:	83 e8 01             	sub    $0x1,%eax
    7a1a:	88 01                	mov    %al,(%rcx)
    7a1c:	0f 1f 40 00          	nopl   0x0(%rax)
    7a20:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7a24:	48 89 d7             	mov    %rdx,%rdi
    7a27:	48 89 0c 24          	mov    %rcx,(%rsp)
    7a2b:	e8 d0 ea ff ff       	call   6500 <fwp_rc_free_arr>
    7a30:	4c 8d 05 49 bd 01 00 	lea    0x1bd49(%rip),%r8        # 23780 <fwp_heap>
    7a37:	48 8b 04 24          	mov    (%rsp),%rax
    7a3b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7a42:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7a49:	48 c1 e2 10          	shl    $0x10,%rdx
    7a4d:	48 39 d0             	cmp    %rdx,%rax
    7a50:	0f 83 35 ff ff ff    	jae    798b <fwp_drop2+0x8b>
    7a56:	48 8b 14 24          	mov    (%rsp),%rdx
    7a5a:	e9 cd fe ff ff       	jmp    792c <fwp_drop2+0x2c>
    7a5f:	90                   	nop
    7a60:	c3                   	ret
    7a61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a68:	48 89 14 24          	mov    %rdx,(%rsp)
    7a6c:	e8 8f ea ff ff       	call   6500 <fwp_rc_free_arr>
    7a71:	48 8b 14 24          	mov    (%rsp),%rdx
    7a75:	eb a9                	jmp    7a20 <fwp_drop2+0x120>
    7a77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a7e:	00 00 
    7a80:	66 85 c0             	test   %ax,%ax
    7a83:	75 9b                	jne    7a20 <fwp_drop2+0x120>
    7a85:	e9 7a ff ff ff       	jmp    7a04 <fwp_drop2+0x104>
    7a8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a90:	48 89 c8             	mov    %rcx,%rax
    7a93:	48 c1 e8 11          	shr    $0x11,%rax
    7a97:	48 31 c8             	xor    %rcx,%rax
    7a9a:	48 89 c2             	mov    %rax,%rdx
    7a9d:	48 c1 ea 09          	shr    $0x9,%rdx
    7aa1:	48 31 d0             	xor    %rdx,%rax
    7aa4:	0f b6 d0             	movzbl %al,%edx
    7aa7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    7aae:	00 
    7aaf:	48 85 c0             	test   %rax,%rax
    7ab2:	75 19                	jne    7acd <fwp_drop2+0x1cd>
    7ab4:	e9 d3 00 00 00       	jmp    7b8c <fwp_drop2+0x28c>
    7ab9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ac0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7ac4:	48 85 c0             	test   %rax,%rax
    7ac7:	0f 84 bf 00 00 00    	je     7b8c <fwp_drop2+0x28c>
    7acd:	48 89 c2             	mov    %rax,%rdx
    7ad0:	48 39 08             	cmp    %rcx,(%rax)
    7ad3:	75 eb                	jne    7ac0 <fwp_drop2+0x1c0>
    7ad5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7ad9:	48 83 ea 01          	sub    $0x1,%rdx
    7add:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7ae1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7ae8:	0f 85 9d fe ff ff    	jne    798b <fwp_drop2+0x8b>
    7aee:	48 89 cf             	mov    %rcx,%rdi
    7af1:	48 89 0c 24          	mov    %rcx,(%rsp)
    7af5:	e8 16 d8 ff ff       	call   5310 <fwp_rc_forget_slot>
    7afa:	48 8b 0c 24          	mov    (%rsp),%rcx
    7afe:	c6 01 fe             	movb   $0xfe,(%rcx)
    7b01:	e9 85 fe ff ff       	jmp    798b <fwp_drop2+0x8b>
    7b06:	48 89 ce             	mov    %rcx,%rsi
    7b09:	48 c1 ee 11          	shr    $0x11,%rsi
    7b0d:	48 31 ce             	xor    %rcx,%rsi
    7b10:	48 89 f0             	mov    %rsi,%rax
    7b13:	48 c1 e8 09          	shr    $0x9,%rax
    7b17:	48 31 c6             	xor    %rax,%rsi
    7b1a:	40 0f b6 f6          	movzbl %sil,%esi
    7b1e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7b25:	00 
    7b26:	48 85 c0             	test   %rax,%rax
    7b29:	75 1e                	jne    7b49 <fwp_drop2+0x249>
    7b2b:	eb 5f                	jmp    7b8c <fwp_drop2+0x28c>
    7b2d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7b34:	00 
    7b35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7b3c:	00 00 00 00 
    7b40:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7b44:	48 85 c0             	test   %rax,%rax
    7b47:	74 43                	je     7b8c <fwp_drop2+0x28c>
    7b49:	48 89 c6             	mov    %rax,%rsi
    7b4c:	48 39 08             	cmp    %rcx,(%rax)
    7b4f:	75 ef                	jne    7b40 <fwp_drop2+0x240>
    7b51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7b55:	48 83 ee 01          	sub    $0x1,%rsi
    7b59:	48 89 70 08          	mov    %rsi,0x8(%rax)
    7b5d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7b64:	0f 85 b6 fe ff ff    	jne    7a20 <fwp_drop2+0x120>
    7b6a:	48 89 cf             	mov    %rcx,%rdi
    7b6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7b72:	48 89 0c 24          	mov    %rcx,(%rsp)
    7b76:	e8 95 d7 ff ff       	call   5310 <fwp_rc_forget_slot>
    7b7b:	48 8b 0c 24          	mov    (%rsp),%rcx
    7b7f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7b84:	c6 01 fe             	movb   $0xfe,(%rcx)
    7b87:	e9 94 fe ff ff       	jmp    7a20 <fwp_drop2+0x120>
    7b8c:	48 8d 3d 05 7c 00 00 	lea    0x7c05(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    7b93:	e8 08 c6 ff ff       	call   41a0 <fwp_trap>
    7b98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7b9f:	00 

0000000000007ba0 <fwp_arg_drop23>:
    7ba0:	f3 0f 1e fa          	endbr64
    7ba4:	85 f6                	test   %esi,%esi
    7ba6:	75 04                	jne    7bac <fwp_arg_drop23+0xc>
    7ba8:	85 d2                	test   %edx,%edx
    7baa:	75 04                	jne    7bb0 <fwp_arg_drop23+0x10>
    7bac:	c3                   	ret
    7bad:	0f 1f 00             	nopl   (%rax)
    7bb0:	48 8b 3f             	mov    (%rdi),%rdi
    7bb3:	e9 48 fd ff ff       	jmp    7900 <fwp_drop2>
    7bb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7bbf:	00 

0000000000007bc0 <fwp_caps23>:
    7bc0:	f3 0f 1e fa          	endbr64
    7bc4:	48 83 ec 18          	sub    $0x18,%rsp
    7bc8:	8b 57 04             	mov    0x4(%rdi),%edx
    7bcb:	48 89 f8             	mov    %rdi,%rax
    7bce:	85 d2                	test   %edx,%edx
    7bd0:	0f 84 9a 00 00 00    	je     7c70 <fwp_caps23+0xb0>
    7bd6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7bda:	85 f6                	test   %esi,%esi
    7bdc:	0f 85 9e 00 00 00    	jne    7c80 <fwp_caps23+0xc0>
    7be2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7be7:	e8 14 fd ff ff       	call   7900 <fwp_drop2>
    7bec:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7bf1:	48 8b 0d 60 cf 01 00 	mov    0x1cf60(%rip),%rcx        # 24b58 <fwp_heap+0x13d8>
    7bf8:	48 89 c2             	mov    %rax,%rdx
    7bfb:	48 2b 15 2e cf 01 00 	sub    0x1cf2e(%rip),%rdx        # 24b30 <fwp_heap+0x13b0>
    7c02:	48 c1 e1 10          	shl    $0x10,%rcx
    7c06:	48 39 ca             	cmp    %rcx,%rdx
    7c09:	73 6d                	jae    7c78 <fwp_caps23+0xb8>
    7c0b:	48 89 d1             	mov    %rdx,%rcx
    7c0e:	48 c1 e9 10          	shr    $0x10,%rcx
    7c12:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7c16:	48 8b 0d 5b cf 01 00 	mov    0x1cf5b(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    7c1d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7c21:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7c25:	48 85 f6             	test   %rsi,%rsi
    7c28:	74 4e                	je     7c78 <fwp_caps23+0xb8>
    7c2a:	0f b6 39             	movzbl (%rcx),%edi
    7c2d:	40 80 ff 02          	cmp    $0x2,%dil
    7c31:	0f 84 b9 00 00 00    	je     7cf0 <fwp_caps23+0x130>
    7c37:	40 80 ff 01          	cmp    $0x1,%dil
    7c3b:	75 3b                	jne    7c78 <fwp_caps23+0xb8>
    7c3d:	8b 79 18             	mov    0x18(%rcx),%edi
    7c40:	0f b7 d2             	movzwl %dx,%edx
    7c43:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7c46:	48 0f af d7          	imul   %rdi,%rdx
    7c4a:	48 c1 ea 20          	shr    $0x20,%rdx
    7c4e:	48 39 ca             	cmp    %rcx,%rdx
    7c51:	73 25                	jae    7c78 <fwp_caps23+0xb8>
    7c53:	48 01 d6             	add    %rdx,%rsi
    7c56:	80 3e 01             	cmpb   $0x1,(%rsi)
    7c59:	75 1d                	jne    7c78 <fwp_caps23+0xb8>
    7c5b:	48 89 c7             	mov    %rax,%rdi
    7c5e:	48 83 c4 18          	add    $0x18,%rsp
    7c62:	e9 e9 d8 ff ff       	jmp    5550 <fwp_mem_free>
    7c67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c6e:	00 00 
    7c70:	85 f6                	test   %esi,%esi
    7c72:	0f 84 79 ff ff ff    	je     7bf1 <fwp_caps23+0x31>
    7c78:	48 83 c4 18          	add    $0x18,%rsp
    7c7c:	c3                   	ret
    7c7d:	0f 1f 00             	nopl   (%rax)
    7c80:	48 8b 05 d1 ce 01 00 	mov    0x1ced1(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    7c87:	48 2b 3d a2 ce 01 00 	sub    0x1cea2(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    7c8e:	48 c1 e0 10          	shl    $0x10,%rax
    7c92:	48 39 c7             	cmp    %rax,%rdi
    7c95:	73 e1                	jae    7c78 <fwp_caps23+0xb8>
    7c97:	48 89 f8             	mov    %rdi,%rax
    7c9a:	48 c1 e8 10          	shr    $0x10,%rax
    7c9e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7ca2:	48 8b 05 cf ce 01 00 	mov    0x1cecf(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    7ca9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7cad:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7cb1:	48 85 c0             	test   %rax,%rax
    7cb4:	74 c2                	je     7c78 <fwp_caps23+0xb8>
    7cb6:	0f b6 0a             	movzbl (%rdx),%ecx
    7cb9:	80 f9 02             	cmp    $0x2,%cl
    7cbc:	74 42                	je     7d00 <fwp_caps23+0x140>
    7cbe:	80 f9 01             	cmp    $0x1,%cl
    7cc1:	75 b5                	jne    7c78 <fwp_caps23+0xb8>
    7cc3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7cc6:	0f b7 ff             	movzwl %di,%edi
    7cc9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7ccc:	48 0f af f9          	imul   %rcx,%rdi
    7cd0:	48 c1 ef 20          	shr    $0x20,%rdi
    7cd4:	48 39 d7             	cmp    %rdx,%rdi
    7cd7:	73 9f                	jae    7c78 <fwp_caps23+0xb8>
    7cd9:	48 01 f8             	add    %rdi,%rax
    7cdc:	0f b6 10             	movzbl (%rax),%edx
    7cdf:	84 d2                	test   %dl,%dl
    7ce1:	74 95                	je     7c78 <fwp_caps23+0xb8>
    7ce3:	80 fa fd             	cmp    $0xfd,%dl
    7ce6:	77 23                	ja     7d0b <fwp_caps23+0x14b>
    7ce8:	83 c2 01             	add    $0x1,%edx
    7ceb:	88 10                	mov    %dl,(%rax)
    7ced:	eb 89                	jmp    7c78 <fwp_caps23+0xb8>
    7cef:	90                   	nop
    7cf0:	66 85 d2             	test   %dx,%dx
    7cf3:	0f 85 7f ff ff ff    	jne    7c78 <fwp_caps23+0xb8>
    7cf9:	e9 58 ff ff ff       	jmp    7c56 <fwp_caps23+0x96>
    7cfe:	66 90                	xchg   %ax,%ax
    7d00:	66 85 ff             	test   %di,%di
    7d03:	0f 85 6f ff ff ff    	jne    7c78 <fwp_caps23+0xb8>
    7d09:	eb d1                	jmp    7cdc <fwp_caps23+0x11c>
    7d0b:	48 89 c7             	mov    %rax,%rdi
    7d0e:	48 83 c4 18          	add    $0x18,%rsp
    7d12:	e9 d9 d4 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7d17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7d1e:	00 00 

0000000000007d20 <f23>:
    7d20:	41 57                	push   %r15
    7d22:	41 56                	push   %r14
    7d24:	41 55                	push   %r13
    7d26:	41 54                	push   %r12
    7d28:	55                   	push   %rbp
    7d29:	53                   	push   %rbx
    7d2a:	48 83 ec 38          	sub    $0x38,%rsp
    7d2e:	48 8b 15 23 ce 01 00 	mov    0x1ce23(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7d35:	48 8b 0d f4 cd 01 00 	mov    0x1cdf4(%rip),%rcx        # 24b30 <fwp_heap+0x13b0>
    7d3c:	64 4c 8b 2c 25 28 00 	mov    %fs:0x28,%r13
    7d43:	00 00 
    7d45:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
    7d4a:	49 89 fd             	mov    %rdi,%r13
    7d4d:	48 c1 e2 10          	shl    $0x10,%rdx
    7d51:	48 85 ff             	test   %rdi,%rdi
    7d54:	0f 84 0c 03 00 00    	je     8066 <f23+0x346>
    7d5a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    7d5e:	48 89 d8             	mov    %rbx,%rax
    7d61:	48 29 c8             	sub    %rcx,%rax
    7d64:	48 39 d0             	cmp    %rdx,%rax
    7d67:	0f 83 c3 03 00 00    	jae    8130 <f23+0x410>
    7d6d:	48 89 c2             	mov    %rax,%rdx
    7d70:	48 c1 ea 10          	shr    $0x10,%rdx
    7d74:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d78:	48 8b 15 f9 cd 01 00 	mov    0x1cdf9(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    7d7f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d83:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d87:	48 85 ff             	test   %rdi,%rdi
    7d8a:	0f 84 a0 03 00 00    	je     8130 <f23+0x410>
    7d90:	0f b6 0a             	movzbl (%rdx),%ecx
    7d93:	80 f9 02             	cmp    $0x2,%cl
    7d96:	0f 84 a4 02 00 00    	je     8040 <f23+0x320>
    7d9c:	80 f9 01             	cmp    $0x1,%cl
    7d9f:	75 24                	jne    7dc5 <f23+0xa5>
    7da1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7da4:	0f b7 c0             	movzwl %ax,%eax
    7da7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7daa:	48 0f af c1          	imul   %rcx,%rax
    7dae:	48 c1 e8 20          	shr    $0x20,%rax
    7db2:	48 39 d0             	cmp    %rdx,%rax
    7db5:	73 0e                	jae    7dc5 <f23+0xa5>
    7db7:	48 01 c7             	add    %rax,%rdi
    7dba:	0f b6 07             	movzbl (%rdi),%eax
    7dbd:	84 c0                	test   %al,%al
    7dbf:	0f 85 1b 03 00 00    	jne    80e0 <f23+0x3c0>
    7dc5:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7dca:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    7dce:	ba 01 00 00 00       	mov    $0x1,%edx
    7dd3:	48 85 db             	test   %rbx,%rbx
    7dd6:	74 15                	je     7ded <f23+0xcd>
    7dd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7ddf:	00 
    7de0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7de4:	48 83 c2 01          	add    $0x1,%rdx
    7de8:	48 85 db             	test   %rbx,%rbx
    7deb:	75 f3                	jne    7de0 <f23+0xc0>
    7ded:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7df2:	48 85 c0             	test   %rax,%rax
    7df5:	0f 84 65 03 00 00    	je     8160 <f23+0x440>
    7dfb:	31 db                	xor    %ebx,%ebx
    7dfd:	0f 1f 00             	nopl   (%rax)
    7e00:	48 8b 40 10          	mov    0x10(%rax),%rax
    7e04:	48 83 c3 01          	add    $0x1,%rbx
    7e08:	48 85 c0             	test   %rax,%rax
    7e0b:	75 f3                	jne    7e00 <f23+0xe0>
    7e0d:	48 39 d3             	cmp    %rdx,%rbx
    7e10:	48 0f 47 da          	cmova  %rdx,%rbx
    7e14:	48 89 d8             	mov    %rbx,%rax
    7e17:	48 c1 e8 3c          	shr    $0x3c,%rax
    7e1b:	0f 85 e3 03 00 00    	jne    8204 <f23+0x4e4>
    7e21:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7e25:	be 02 00 00 00       	mov    $0x2,%esi
    7e2a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7e31:	00 
    7e32:	e8 19 dc ff ff       	call   5a50 <fwp_heap_alloc>
    7e37:	48 89 28             	mov    %rbp,(%rax)
    7e3a:	48 8b 15 17 cd 01 00 	mov    0x1cd17(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7e41:	49 89 c4             	mov    %rax,%r12
    7e44:	48 2b 05 e5 cc 01 00 	sub    0x1cce5(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7e4b:	48 c1 e2 10          	shl    $0x10,%rdx
    7e4f:	48 39 d0             	cmp    %rdx,%rax
    7e52:	73 57                	jae    7eab <f23+0x18b>
    7e54:	48 89 c2             	mov    %rax,%rdx
    7e57:	48 c1 ea 10          	shr    $0x10,%rdx
    7e5b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e5f:	48 8b 15 12 cd 01 00 	mov    0x1cd12(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    7e66:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e6a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7e6e:	48 85 ed             	test   %rbp,%rbp
    7e71:	74 38                	je     7eab <f23+0x18b>
    7e73:	0f b6 0a             	movzbl (%rdx),%ecx
    7e76:	80 f9 02             	cmp    $0x2,%cl
    7e79:	0f 84 a1 02 00 00    	je     8120 <f23+0x400>
    7e7f:	80 f9 01             	cmp    $0x1,%cl
    7e82:	75 27                	jne    7eab <f23+0x18b>
    7e84:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7e87:	0f b7 c0             	movzwl %ax,%eax
    7e8a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e8d:	48 0f af c1          	imul   %rcx,%rax
    7e91:	48 c1 e8 20          	shr    $0x20,%rax
    7e95:	48 39 d0             	cmp    %rdx,%rax
    7e98:	73 11                	jae    7eab <f23+0x18b>
    7e9a:	48 01 c5             	add    %rax,%rbp
    7e9d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7ea1:	0f 84 29 03 00 00    	je     81d0 <f23+0x4b0>
    7ea7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7eab:	48 85 db             	test   %rbx,%rbx
    7eae:	74 5d                	je     7f0d <f23+0x1ed>
    7eb0:	48 c1 e3 04          	shl    $0x4,%rbx
    7eb4:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    7eb9:	4c 89 e5             	mov    %r12,%rbp
    7ebc:	4d 89 ee             	mov    %r13,%r14
    7ebf:	4c 01 e3             	add    %r12,%rbx
    7ec2:	0f 1f 00             	nopl   (%rax)
    7ec5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7ecc:	00 00 00 00 
    7ed0:	49 8b 46 08          	mov    0x8(%r14),%rax
    7ed4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    7ed8:	48 83 c5 10          	add    $0x10,%rbp
    7edc:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    7ee1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    7ee5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    7ee9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    7eee:	e8 3d e2 ff ff       	call   6130 <w107>
    7ef3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    7ef8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    7efc:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    7f00:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    7f04:	4d 8b 76 10          	mov    0x10(%r14),%r14
    7f08:	48 39 eb             	cmp    %rbp,%rbx
    7f0b:	75 c3                	jne    7ed0 <f23+0x1b0>
    7f0d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7f12:	31 db                	xor    %ebx,%ebx
    7f14:	e8 e7 f9 ff ff       	call   7900 <fwp_drop2>
    7f19:	4c 89 ef             	mov    %r13,%rdi
    7f1c:	e8 df f9 ff ff       	call   7900 <fwp_drop2>
    7f21:	4d 8b 2c 24          	mov    (%r12),%r13
    7f25:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7f29:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    7f30:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    7f37:	4d 85 ed             	test   %r13,%r13
    7f3a:	74 3f                	je     7f7b <f23+0x25b>
    7f3c:	0f 1f 40 00          	nopl   0x0(%rax)
    7f40:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    7f47:	49 8b 54 dc 10       	mov    0x10(%r12,%rbx,8),%rdx
    7f4c:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    7f53:	00 f0 3f 
    7f56:	48 83 c3 02          	add    $0x2,%rbx
    7f5a:	48 89 ce             	mov    %rcx,%rsi
    7f5d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    7f63:	e8 48 de ff ff       	call   5db0 <fwp_p_ad_push>
    7f68:	4c 39 eb             	cmp    %r13,%rbx
    7f6b:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    7f71:	48 89 c7             	mov    %rax,%rdi
    7f74:	72 ca                	jb     7f40 <f23+0x220>
    7f76:	66 49 0f 7e c5       	movq   %xmm0,%r13
    7f7b:	4c 89 e7             	mov    %r12,%rdi
    7f7e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7f83:	e8 78 f4 ff ff       	call   7400 <fwp_drop4>
    7f88:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7f8d:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7f92:	31 ff                	xor    %edi,%edi
    7f94:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    7f99:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    7f9e:	e8 fd e2 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    7fa3:	48 8b 15 ae cb 01 00 	mov    0x1cbae(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7faa:	48 89 c5             	mov    %rax,%rbp
    7fad:	48 2b 05 7c cb 01 00 	sub    0x1cb7c(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7fb4:	48 c1 e2 10          	shl    $0x10,%rdx
    7fb8:	48 39 d0             	cmp    %rdx,%rax
    7fbb:	73 55                	jae    8012 <f23+0x2f2>
    7fbd:	48 89 c2             	mov    %rax,%rdx
    7fc0:	48 c1 ea 10          	shr    $0x10,%rdx
    7fc4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7fc8:	48 8b 15 a9 cb 01 00 	mov    0x1cba9(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    7fcf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7fd3:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    7fd7:	48 85 db             	test   %rbx,%rbx
    7fda:	74 36                	je     8012 <f23+0x2f2>
    7fdc:	0f b6 0a             	movzbl (%rdx),%ecx
    7fdf:	80 f9 02             	cmp    $0x2,%cl
    7fe2:	0f 84 20 01 00 00    	je     8108 <f23+0x3e8>
    7fe8:	80 f9 01             	cmp    $0x1,%cl
    7feb:	75 25                	jne    8012 <f23+0x2f2>
    7fed:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ff0:	0f b7 c0             	movzwl %ax,%eax
    7ff3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7ff6:	48 0f af c1          	imul   %rcx,%rax
    7ffa:	48 c1 e8 20          	shr    $0x20,%rax
    7ffe:	48 39 d0             	cmp    %rdx,%rax
    8001:	73 0f                	jae    8012 <f23+0x2f2>
    8003:	48 01 c3             	add    %rax,%rbx
    8006:	80 3b ff             	cmpb   $0xff,(%rbx)
    8009:	0f 84 b4 01 00 00    	je     81c3 <f23+0x4a3>
    800f:	c6 03 01             	movb   $0x1,(%rbx)
    8012:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    8017:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    801e:	00 00 
    8020:	0f 85 d9 01 00 00    	jne    81ff <f23+0x4df>
    8026:	48 83 c4 38          	add    $0x38,%rsp
    802a:	48 89 e8             	mov    %rbp,%rax
    802d:	5b                   	pop    %rbx
    802e:	5d                   	pop    %rbp
    802f:	41 5c                	pop    %r12
    8031:	41 5d                	pop    %r13
    8033:	41 5e                	pop    %r14
    8035:	41 5f                	pop    %r15
    8037:	c3                   	ret
    8038:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    803f:	00 
    8040:	66 85 c0             	test   %ax,%ax
    8043:	0f 85 7c fd ff ff    	jne    7dc5 <f23+0xa5>
    8049:	0f b6 07             	movzbl (%rdi),%eax
    804c:	84 c0                	test   %al,%al
    804e:	0f 84 71 fd ff ff    	je     7dc5 <f23+0xa5>
    8054:	3c fd                	cmp    $0xfd,%al
    8056:	0f 87 99 01 00 00    	ja     81f5 <f23+0x4d5>
    805c:	83 c0 01             	add    $0x1,%eax
    805f:	88 07                	mov    %al,(%rdi)
    8061:	e9 5f fd ff ff       	jmp    7dc5 <f23+0xa5>
    8066:	48 f7 d9             	neg    %rcx
    8069:	48 39 d1             	cmp    %rdx,%rcx
    806c:	0f 83 ee 00 00 00    	jae    8160 <f23+0x440>
    8072:	48 89 c8             	mov    %rcx,%rax
    8075:	48 c1 e8 10          	shr    $0x10,%rax
    8079:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    807d:	48 8b 05 f4 ca 01 00 	mov    0x1caf4(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    8084:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8088:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    808c:	48 85 ff             	test   %rdi,%rdi
    808f:	0f 84 cb 00 00 00    	je     8160 <f23+0x440>
    8095:	0f b6 02             	movzbl (%rdx),%eax
    8098:	3c 02                	cmp    $0x2,%al
    809a:	0f 84 9a 00 00 00    	je     813a <f23+0x41a>
    80a0:	3c 01                	cmp    $0x1,%al
    80a2:	0f 85 b8 00 00 00    	jne    8160 <f23+0x440>
    80a8:	0f b7 c1             	movzwl %cx,%eax
    80ab:	8b 4a 18             	mov    0x18(%rdx),%ecx
    80ae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    80b1:	48 0f af c1          	imul   %rcx,%rax
    80b5:	48 c1 e8 20          	shr    $0x20,%rax
    80b9:	48 39 d0             	cmp    %rdx,%rax
    80bc:	0f 83 9e 00 00 00    	jae    8160 <f23+0x440>
    80c2:	48 01 c7             	add    %rax,%rdi
    80c5:	0f b6 07             	movzbl (%rdi),%eax
    80c8:	84 c0                	test   %al,%al
    80ca:	0f 84 90 00 00 00    	je     8160 <f23+0x440>
    80d0:	31 db                	xor    %ebx,%ebx
    80d2:	0f 1f 00             	nopl   (%rax)
    80d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    80dc:	00 00 00 00 
    80e0:	3c fd                	cmp    $0xfd,%al
    80e2:	0f 87 f5 00 00 00    	ja     81dd <f23+0x4bd>
    80e8:	83 c0 01             	add    $0x1,%eax
    80eb:	88 07                	mov    %al,(%rdi)
    80ed:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    80f2:	31 d2                	xor    %edx,%edx
    80f4:	4d 85 ed             	test   %r13,%r13
    80f7:	0f 85 cd fc ff ff    	jne    7dca <f23+0xaa>
    80fd:	e9 eb fc ff ff       	jmp    7ded <f23+0xcd>
    8102:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8108:	66 85 c0             	test   %ax,%ax
    810b:	0f 85 01 ff ff ff    	jne    8012 <f23+0x2f2>
    8111:	e9 f0 fe ff ff       	jmp    8006 <f23+0x2e6>
    8116:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    811d:	00 00 00 
    8120:	66 85 c0             	test   %ax,%ax
    8123:	0f 85 82 fd ff ff    	jne    7eab <f23+0x18b>
    8129:	e9 6f fd ff ff       	jmp    7e9d <f23+0x17d>
    812e:	66 90                	xchg   %ax,%ax
    8130:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8135:	e9 94 fc ff ff       	jmp    7dce <f23+0xae>
    813a:	66 85 c9             	test   %cx,%cx
    813d:	75 21                	jne    8160 <f23+0x440>
    813f:	0f b6 07             	movzbl (%rdi),%eax
    8142:	84 c0                	test   %al,%al
    8144:	74 1a                	je     8160 <f23+0x440>
    8146:	3c fd                	cmp    $0xfd,%al
    8148:	0f 87 c2 00 00 00    	ja     8210 <f23+0x4f0>
    814e:	83 c0 01             	add    $0x1,%eax
    8151:	88 07                	mov    %al,(%rdi)
    8153:	66 90                	xchg   %ax,%ax
    8155:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    815c:	00 00 00 00 
    8160:	be 02 00 00 00       	mov    $0x2,%esi
    8165:	bf 08 00 00 00       	mov    $0x8,%edi
    816a:	e8 e1 d8 ff ff       	call   5a50 <fwp_heap_alloc>
    816f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8176:	48 8b 15 db c9 01 00 	mov    0x1c9db(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    817d:	49 89 c4             	mov    %rax,%r12
    8180:	48 2b 05 a9 c9 01 00 	sub    0x1c9a9(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    8187:	48 c1 e2 10          	shl    $0x10,%rdx
    818b:	48 39 d0             	cmp    %rdx,%rax
    818e:	73 57                	jae    81e7 <f23+0x4c7>
    8190:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8197:	00 00 
    8199:	48 89 c2             	mov    %rax,%rdx
    819c:	48 c1 ea 10          	shr    $0x10,%rdx
    81a0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    81a4:	48 8b 15 cd c9 01 00 	mov    0x1c9cd(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    81ab:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    81af:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    81b3:	48 85 ed             	test   %rbp,%rbp
    81b6:	0f 84 51 fd ff ff    	je     7f0d <f23+0x1ed>
    81bc:	31 db                	xor    %ebx,%ebx
    81be:	e9 b0 fc ff ff       	jmp    7e73 <f23+0x153>
    81c3:	48 89 df             	mov    %rbx,%rdi
    81c6:	e8 45 d1 ff ff       	call   5310 <fwp_rc_forget_slot>
    81cb:	e9 3f fe ff ff       	jmp    800f <f23+0x2ef>
    81d0:	48 89 ef             	mov    %rbp,%rdi
    81d3:	e8 38 d1 ff ff       	call   5310 <fwp_rc_forget_slot>
    81d8:	e9 ca fc ff ff       	jmp    7ea7 <f23+0x187>
    81dd:	e8 0e d0 ff ff       	call   51f0 <fwp_rc_wide_dup>
    81e2:	e9 06 ff ff ff       	jmp    80ed <f23+0x3cd>
    81e7:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    81ee:	00 00 
    81f0:	e9 18 fd ff ff       	jmp    7f0d <f23+0x1ed>
    81f5:	e8 f6 cf ff ff       	call   51f0 <fwp_rc_wide_dup>
    81fa:	e9 c6 fb ff ff       	jmp    7dc5 <f23+0xa5>
    81ff:	e8 5c b2 ff ff       	call   3460 <__stack_chk_fail@plt>
    8204:	48 8d 3d 22 6f 00 00 	lea    0x6f22(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    820b:	e8 90 bf ff ff       	call   41a0 <fwp_trap>
    8210:	e8 db cf ff ff       	call   51f0 <fwp_rc_wide_dup>
    8215:	e9 46 ff ff ff       	jmp    8160 <f23+0x440>
    821a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000008220 <fwp_owned_entry23>:
    8220:	f3 0f 1e fa          	endbr64
    8224:	48 8b 3f             	mov    (%rdi),%rdi
    8227:	e9 f4 fa ff ff       	jmp    7d20 <f23>
    822c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008230 <e23>:
    8230:	f3 0f 1e fa          	endbr64
    8234:	53                   	push   %rbx
    8235:	48 8b 1f             	mov    (%rdi),%rbx
    8238:	48 89 df             	mov    %rbx,%rdi
    823b:	e8 90 e1 ff ff       	call   63d0 <fwp_rc_share>
    8240:	48 89 df             	mov    %rbx,%rdi
    8243:	e8 d8 fa ff ff       	call   7d20 <f23>
    8248:	48 89 c3             	mov    %rax,%rbx
    824b:	48 89 c7             	mov    %rax,%rdi
    824e:	e8 7d e1 ff ff       	call   63d0 <fwp_rc_share>
    8253:	48 89 d8             	mov    %rbx,%rax
    8256:	5b                   	pop    %rbx
    8257:	c3                   	ret
    8258:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    825f:	00 

0000000000008260 <f12>:
    8260:	41 57                	push   %r15
    8262:	41 56                	push   %r14
    8264:	41 55                	push   %r13
    8266:	41 54                	push   %r12
    8268:	4c 8d 25 b1 eb ff ff 	lea    -0x144f(%rip),%r12        # 6e20 <fwp_tape_scope_release>
    826f:	55                   	push   %rbp
    8270:	53                   	push   %rbx
    8271:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
    8278:	48 8b 05 99 d1 01 00 	mov    0x1d199(%rip),%rax        # 25418 <fwp_cleanups>
    827f:	48 8b 15 d2 c8 01 00 	mov    0x1c8d2(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    8286:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    828d:	00 00 
    828f:	48 89 ac 24 f8 00 00 	mov    %rbp,0xf8(%rsp)
    8296:	00 
    8297:	48 89 fd             	mov    %rdi,%rbp
    829a:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    82a1:	ff 
    82a2:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    82a7:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    82ac:	48 c1 e2 10          	shl    $0x10,%rdx
    82b0:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    82b5:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    82ba:	48 8d 44 24 60       	lea    0x60(%rsp),%rax
    82bf:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    82c4:	48 89 05 4d d1 01 00 	mov    %rax,0x1d14d(%rip)        # 25418 <fwp_cleanups>
    82cb:	48 8d 05 3e ad 00 00 	lea    0xad3e(%rip),%rax        # 13010 <fc23>
    82d2:	48 2b 05 57 c8 01 00 	sub    0x1c857(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    82d9:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    82de:	48 39 d0             	cmp    %rdx,%rax
    82e1:	73 5d                	jae    8340 <f12+0xe0>
    82e3:	48 89 c2             	mov    %rax,%rdx
    82e6:	48 c1 ea 10          	shr    $0x10,%rdx
    82ea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    82ee:	48 8b 15 83 c8 01 00 	mov    0x1c883(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    82f5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    82f9:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    82fd:	48 85 ff             	test   %rdi,%rdi
    8300:	74 3e                	je     8340 <f12+0xe0>
    8302:	0f b6 0a             	movzbl (%rdx),%ecx
    8305:	80 f9 02             	cmp    $0x2,%cl
    8308:	0f 84 22 0f 00 00    	je     9230 <f12+0xfd0>
    830e:	80 f9 01             	cmp    $0x1,%cl
    8311:	75 2d                	jne    8340 <f12+0xe0>
    8313:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8316:	0f b7 c0             	movzwl %ax,%eax
    8319:	8b 52 1c             	mov    0x1c(%rdx),%edx
    831c:	48 0f af c1          	imul   %rcx,%rax
    8320:	48 c1 e8 20          	shr    $0x20,%rax
    8324:	48 39 d0             	cmp    %rdx,%rax
    8327:	73 17                	jae    8340 <f12+0xe0>
    8329:	48 01 c7             	add    %rax,%rdi
    832c:	0f b6 07             	movzbl (%rdi),%eax
    832f:	84 c0                	test   %al,%al
    8331:	74 0d                	je     8340 <f12+0xe0>
    8333:	3c fd                	cmp    $0xfd,%al
    8335:	0f 87 ef 10 00 00    	ja     942a <f12+0x11ca>
    833b:	83 c0 01             	add    $0x1,%eax
    833e:	88 07                	mov    %al,(%rdi)
    8340:	48 8d 3d c9 ac 00 00 	lea    0xacc9(%rip),%rdi        # 13010 <fc23>
    8347:	e8 a4 e7 ff ff       	call   6af0 <fwp_closure_drop>
    834c:	48 85 ed             	test   %rbp,%rbp
    834f:	0f 84 3c 10 00 00    	je     9391 <f12+0x1131>
    8355:	48 89 e8             	mov    %rbp,%rax
    8358:	31 d2                	xor    %edx,%edx
    835a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8360:	48 8b 40 10          	mov    0x10(%rax),%rax
    8364:	48 83 c2 01          	add    $0x1,%rdx
    8368:	48 85 c0             	test   %rax,%rax
    836b:	75 f3                	jne    8360 <f12+0x100>
    836d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    8374:	0f 87 2a 11 00 00    	ja     94a4 <f12+0x1244>
    837a:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    837f:	8b 35 fb ac 00 00    	mov    0xacfb(%rip),%esi        # 13080 <registered_finish.0>
    8385:	85 f6                	test   %esi,%esi
    8387:	0f 84 73 0e 00 00    	je     9200 <f12+0xfa0>
    838d:	48 8b 1d 64 ad 01 00 	mov    0x1ad64(%rip),%rbx        # 230f8 <fwp_tape_next_slot>
    8394:	4c 8b 2d 6d ad 01 00 	mov    0x1ad6d(%rip),%r13        # 23108 <fwp_ntapes>
    839b:	4c 39 eb             	cmp    %r13,%rbx
    839e:	0f 8d cc 00 00 00    	jge    8470 <f12+0x210>
    83a4:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    83a8:	48 03 05 61 ad 01 00 	add    0x1ad61(%rip),%rax        # 23110 <fwp_tapes>
    83af:	90                   	nop
    83b0:	8b 48 04             	mov    0x4(%rax),%ecx
    83b3:	85 c9                	test   %ecx,%ecx
    83b5:	75 0c                	jne    83c3 <f12+0x163>
    83b7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    83bd:	0f 86 ad 00 00 00    	jbe    8470 <f12+0x210>
    83c3:	48 83 c3 01          	add    $0x1,%rbx
    83c7:	48 83 c0 68          	add    $0x68,%rax
    83cb:	4c 39 eb             	cmp    %r13,%rbx
    83ce:	75 e0                	jne    83b0 <f12+0x150>
    83d0:	49 81 fd fe ff 00 00 	cmp    $0xfffe,%r13
    83d7:	0f 8f 46 11 00 00    	jg     9523 <f12+0x12c3>
    83dd:	4c 39 2d 1c ad 01 00 	cmp    %r13,0x1ad1c(%rip)        # 23100 <fwp_tapes_cap>
    83e4:	4c 8b 3d 25 ad 01 00 	mov    0x1ad25(%rip),%r15        # 23110 <fwp_tapes>
    83eb:	75 4a                	jne    8437 <f12+0x1d7>
    83ed:	4d 85 ed             	test   %r13,%r13
    83f0:	0f 84 fd 0f 00 00    	je     93f3 <f12+0x1193>
    83f6:	4f 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%r14
    83fb:	b8 ff ff 00 00       	mov    $0xffff,%eax
    8400:	49 39 c6             	cmp    %rax,%r14
    8403:	4c 0f 4f f0          	cmovg  %rax,%r14
    8407:	49 6b f6 68          	imul   $0x68,%r14,%rsi
    840b:	4c 89 ff             	mov    %r15,%rdi
    840e:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8413:	e8 b8 b1 ff ff       	call   35d0 <realloc@plt>
    8418:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    841d:	48 85 c0             	test   %rax,%rax
    8420:	49 89 c7             	mov    %rax,%r15
    8423:	0f 84 c0 10 00 00    	je     94e9 <f12+0x1289>
    8429:	48 89 05 e0 ac 01 00 	mov    %rax,0x1ace0(%rip)        # 23110 <fwp_tapes>
    8430:	4c 89 35 c9 ac 01 00 	mov    %r14,0x1acc9(%rip)        # 23100 <fwp_tapes_cap>
    8437:	49 6b c5 68          	imul   $0x68,%r13,%rax
    843b:	49 83 c5 01          	add    $0x1,%r13
    843f:	4c 01 f8             	add    %r15,%rax
    8442:	48 8d 78 08          	lea    0x8(%rax),%rdi
    8446:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    844d:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    8451:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    8458:	00 
    8459:	48 29 f8             	sub    %rdi,%rax
    845c:	8d 48 68             	lea    0x68(%rax),%ecx
    845f:	31 c0                	xor    %eax,%eax
    8461:	c1 e9 03             	shr    $0x3,%ecx
    8464:	f3 48 ab             	rep stos %rax,(%rdi)
    8467:	4c 89 2d 9a ac 01 00 	mov    %r13,0x1ac9a(%rip)        # 23108 <fwp_ntapes>
    846e:	eb 10                	jmp    8480 <f12+0x220>
    8470:	4c 39 eb             	cmp    %r13,%rbx
    8473:	0f 84 57 ff ff ff    	je     83d0 <f12+0x170>
    8479:	4c 8b 3d 90 ac 01 00 	mov    0x1ac90(%rip),%r15        # 23110 <fwp_tapes>
    8480:	4c 6b f3 68          	imul   $0x68,%rbx,%r14
    8484:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    8488:	48 8d 3d 30 6c 00 00 	lea    0x6c30(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    848f:	0f 29 04 24          	movaps %xmm0,(%rsp)
    8493:	4d 01 fe             	add    %r15,%r14
    8496:	49 c7 46 60 00 00 00 	movq   $0x0,0x60(%r14)
    849d:	00 
    849e:	e8 fd ae ff ff       	call   33a0 <getenv@plt>
    84a3:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    84a8:	48 85 c0             	test   %rax,%rax
    84ab:	74 09                	je     84b6 <f12+0x256>
    84ad:	80 38 30             	cmpb   $0x30,(%rax)
    84b0:	0f 84 a2 06 00 00    	je     8b58 <f12+0x8f8>
    84b6:	48 83 3d ea ab 01 00 	cmpq   $0x0,0x1abea(%rip)        # 230a8 <fwp_tape_cached_bytes>
    84bd:	00 
    84be:	0f 85 cc 0d 00 00    	jne    9290 <f12+0x1030>
    84c4:	41 8b 06             	mov    (%r14),%eax
    84c7:	4c 8d 6b 01          	lea    0x1(%rbx),%r13
    84cb:	41 c7 46 04 01 00 00 	movl   $0x1,0x4(%r14)
    84d2:	00 
    84d3:	4c 89 2d 1e ac 01 00 	mov    %r13,0x1ac1e(%rip)        # 230f8 <fwp_tape_next_slot>
    84da:	8d 70 01             	lea    0x1(%rax),%esi
    84dd:	48 8b 05 34 cf 01 00 	mov    0x1cf34(%rip),%rax        # 25418 <fwp_cleanups>
    84e4:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
    84e9:	41 89 36             	mov    %esi,(%r14)
    84ec:	49 c7 46 50 00 00 00 	movq   $0x0,0x50(%r14)
    84f3:	00 
    84f4:	49 c7 46 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%r14)
    84fb:	ff 
    84fc:	48 85 c0             	test   %rax,%rax
    84ff:	75 1b                	jne    851c <f12+0x2bc>
    8501:	e9 11 10 00 00       	jmp    9517 <f12+0x12b7>
    8506:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    850d:	00 00 00 
    8510:	48 8b 00             	mov    (%rax),%rax
    8513:	48 85 c0             	test   %rax,%rax
    8516:	0f 84 fb 0f 00 00    	je     9517 <f12+0x12b7>
    851c:	4c 39 60 08          	cmp    %r12,0x8(%rax)
    8520:	75 ee                	jne    8510 <f12+0x2b0>
    8522:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8526:	89 df                	mov    %ebx,%edi
    8528:	48 63 01             	movslq (%rcx),%rax
    852b:	49 89 4e 50          	mov    %rcx,0x50(%r14)
    852f:	41 89 46 5c          	mov    %eax,0x5c(%r14)
    8533:	85 c0                	test   %eax,%eax
    8535:	78 09                	js     8540 <f12+0x2e0>
    8537:	48 6b c0 68          	imul   $0x68,%rax,%rax
    853b:	41 89 5c 07 58       	mov    %ebx,0x58(%r15,%rax,1)
    8540:	89 39                	mov    %edi,(%rcx)
    8542:	48 89 e8             	mov    %rbp,%rax
    8545:	31 c9                	xor    %ecx,%ecx
    8547:	48 85 ed             	test   %rbp,%rbp
    854a:	0f 84 38 0b 00 00    	je     9088 <f12+0xe28>
    8550:	48 8b 40 10          	mov    0x10(%rax),%rax
    8554:	48 83 c1 01          	add    $0x1,%rcx
    8558:	48 85 c0             	test   %rax,%rax
    855b:	75 f3                	jne    8550 <f12+0x2f0>
    855d:	48 89 ea             	mov    %rbp,%rdx
    8560:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8564:	48 83 c0 01          	add    $0x1,%rax
    8568:	48 85 d2             	test   %rdx,%rdx
    856b:	75 f3                	jne    8560 <f12+0x300>
    856d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    8574:	ff ff 1f 
    8577:	48 39 c2             	cmp    %rax,%rdx
    857a:	0f 82 30 0f 00 00    	jb     94b0 <f12+0x1250>
    8580:	48 85 c9             	test   %rcx,%rcx
    8583:	0f 8e ff 0a 00 00    	jle    9088 <f12+0xe28>
    8589:	48 39 c1             	cmp    %rax,%rcx
    858c:	48 0f 46 c1          	cmovbe %rcx,%rax
    8590:	49 89 c4             	mov    %rax,%r12
    8593:	48 c1 e8 3c          	shr    $0x3c,%rax
    8597:	0f 85 13 0f 00 00    	jne    94b0 <f12+0x1250>
    859d:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    85a1:	48 c1 e6 10          	shl    $0x10,%rsi
    85a5:	49 09 f5             	or     %rsi,%r13
    85a8:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    85af:	00 
    85b0:	be 02 00 00 00       	mov    $0x2,%esi
    85b5:	e8 96 d4 ff ff       	call   5a50 <fwp_heap_alloc>
    85ba:	4c 89 30             	mov    %r14,(%rax)
    85bd:	48 8b 15 94 c5 01 00 	mov    0x1c594(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    85c4:	48 89 c3             	mov    %rax,%rbx
    85c7:	48 2b 05 62 c5 01 00 	sub    0x1c562(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    85ce:	48 c1 e2 10          	shl    $0x10,%rdx
    85d2:	48 39 d0             	cmp    %rdx,%rax
    85d5:	0f 83 85 0d 00 00    	jae    9360 <f12+0x1100>
    85db:	48 89 c2             	mov    %rax,%rdx
    85de:	48 c1 ea 10          	shr    $0x10,%rdx
    85e2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    85e6:	48 8b 15 8b c5 01 00 	mov    0x1c58b(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    85ed:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    85f1:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    85f5:	4d 85 f6             	test   %r14,%r14
    85f8:	74 38                	je     8632 <f12+0x3d2>
    85fa:	0f b6 0a             	movzbl (%rdx),%ecx
    85fd:	80 f9 02             	cmp    $0x2,%cl
    8600:	0f 84 ef 0a 00 00    	je     90f5 <f12+0xe95>
    8606:	80 f9 01             	cmp    $0x1,%cl
    8609:	75 27                	jne    8632 <f12+0x3d2>
    860b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    860e:	0f b7 c0             	movzwl %ax,%eax
    8611:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8614:	48 0f af c1          	imul   %rcx,%rax
    8618:	48 c1 e8 20          	shr    $0x20,%rax
    861c:	48 39 d0             	cmp    %rdx,%rax
    861f:	73 11                	jae    8632 <f12+0x3d2>
    8621:	49 01 c6             	add    %rax,%r14
    8624:	41 80 3e ff          	cmpb   $0xff,(%r14)
    8628:	0f 84 d5 0d 00 00    	je     9403 <f12+0x11a3>
    862e:	41 c6 06 01          	movb   $0x1,(%r14)
    8632:	4d 85 e4             	test   %r12,%r12
    8635:	74 7c                	je     86b3 <f12+0x453>
    8637:	4c 89 e9             	mov    %r13,%rcx
    863a:	48 89 ea             	mov    %rbp,%rdx
    863d:	31 c0                	xor    %eax,%eax
    863f:	48 c1 e1 20          	shl    $0x20,%rcx
    8643:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8649:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8650:	00 00 00 00 
    8654:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    865b:	00 00 00 00 
    865f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8666:	00 00 00 00 
    866a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8671:	00 00 00 00 
    8675:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    867c:	00 00 00 00 
    8680:	48 89 c6             	mov    %rax,%rsi
    8683:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8688:	48 01 ce             	add    %rcx,%rsi
    868b:	0f 80 fa 0d 00 00    	jo     948b <f12+0x122b>
    8691:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    8696:	48 89 c6             	mov    %rax,%rsi
    8699:	48 83 c0 01          	add    $0x1,%rax
    869d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    86a1:	48 c1 e6 04          	shl    $0x4,%rsi
    86a5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    86aa:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    86ae:	4c 39 e0             	cmp    %r12,%rax
    86b1:	72 cd                	jb     8680 <f12+0x420>
    86b3:	48 8b 03             	mov    (%rbx),%rax
    86b6:	48 d1 e8             	shr    $1,%rax
    86b9:	0f 85 49 0a 00 00    	jne    9108 <f12+0xea8>
    86bf:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
    86c6:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    86cd:	0f 1f 00             	nopl   (%rax)
    86d0:	48 89 df             	mov    %rbx,%rdi
    86d3:	4d 63 e5             	movslq %r13d,%r12
    86d6:	e8 25 ed ff ff       	call   7400 <fwp_drop4>
    86db:	4c 89 e7             	mov    %r12,%rdi
    86de:	e8 9d bd ff ff       	call   4480 <fwp_tape_of>
    86e3:	48 89 c6             	mov    %rax,%rsi
    86e6:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    86eb:	0f 85 43 0e 00 00    	jne    9534 <f12+0x12d4>
    86f1:	48 89 c7             	mov    %rax,%rdi
    86f4:	e8 07 b5 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    86f9:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    86fd:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    8702:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    8709:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
    870d:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    8711:	66 49 0f 6e fe       	movq   %r14,%xmm7
    8716:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    871b:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    8720:	48 8b 4e 40          	mov    0x40(%rsi),%rcx
    8724:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    8728:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    872e:	77 19                	ja     8749 <f12+0x4e9>
    8730:	41 0f b7 c5          	movzwl %r13w,%eax
    8734:	83 e8 01             	sub    $0x1,%eax
    8737:	48 98                	cltq
    8739:	48 3b 05 b8 a9 01 00 	cmp    0x1a9b8(%rip),%rax        # 230f8 <fwp_tape_next_slot>
    8740:	7d 07                	jge    8749 <f12+0x4e9>
    8742:	48 89 05 af a9 01 00 	mov    %rax,0x1a9af(%rip)        # 230f8 <fwp_tape_next_slot>
    8749:	48 8b 05 c8 cc 01 00 	mov    0x1ccc8(%rip),%rax        # 25418 <fwp_cleanups>
    8750:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8754:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    875b:	00 
    875c:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8760:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    8767:	00 
    8768:	48 8d 05 c1 c6 ff ff 	lea    -0x393f(%rip),%rax        # 4e30 <fwp_tape_buffers_release>
    876f:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    8776:	00 
    8777:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    877e:	00 
    877f:	48 89 04 24          	mov    %rax,(%rsp)
    8783:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    878a:	00 
    878b:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    8792:	00 
    8793:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    8797:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    879b:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    87a2:	00 
    87a3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    87aa:	00 
    87ab:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
    87b2:	00 
    87b3:	48 89 05 5e cc 01 00 	mov    %rax,0x1cc5e(%rip)        # 25418 <fwp_cleanups>
    87ba:	0f 29 9c 24 a0 00 00 	movaps %xmm3,0xa0(%rsp)
    87c1:	00 
    87c2:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    87c9:	00 
    87ca:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    87d1:	00 
    87d2:	4d 85 ff             	test   %r15,%r15
    87d5:	0f 88 65 0a 00 00    	js     9240 <f12+0xfe0>
    87db:	4c 89 f8             	mov    %r15,%rax
    87de:	48 c1 f8 20          	sar    $0x20,%rax
    87e2:	49 39 c4             	cmp    %rax,%r12
    87e5:	0f 85 94 0c 00 00    	jne    947f <f12+0x121f>
    87eb:	45 89 fa             	mov    %r15d,%r10d
    87ee:	4d 89 d4             	mov    %r10,%r12
    87f1:	4c 39 d2             	cmp    %r10,%rdx
    87f4:	0f 8e 79 0c 00 00    	jle    9473 <f12+0x1213>
    87fa:	4c 39 d3             	cmp    %r10,%rbx
    87fd:	0f 8e ad 09 00 00    	jle    91b0 <f12+0xf50>
    8803:	4c 39 f3             	cmp    %r14,%rbx
    8806:	0f 8e f4 0a 00 00    	jle    9300 <f12+0x10a0>
    880c:	49 89 dd             	mov    %rbx,%r13
    880f:	4d 85 f6             	test   %r14,%r14
    8812:	4d 0f 44 f5          	cmove  %r13,%r14
    8816:	eb 1d                	jmp    8835 <f12+0x5d5>
    8818:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    881f:	00 
    8820:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
    8824:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    882b:	4c 89 e8             	mov    %r13,%rax
    882e:	48 0f 4c c2          	cmovl  %rdx,%rax
    8832:	49 89 c6             	mov    %rax,%r14
    8835:	4d 39 ee             	cmp    %r13,%r14
    8838:	7c e6                	jl     8820 <f12+0x5c0>
    883a:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    883f:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8844:	48 85 c9             	test   %rcx,%rcx
    8847:	0f 84 23 0b 00 00    	je     9370 <f12+0x1110>
    884d:	48 89 cf             	mov    %rcx,%rdi
    8850:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    8857:	00 
    8858:	e8 73 ad ff ff       	call   35d0 <realloc@plt>
    885d:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8863:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    8869:	48 89 c1             	mov    %rax,%rcx
    886c:	48 85 c9             	test   %rcx,%rcx
    886f:	0f 84 53 0c 00 00    	je     94c8 <f12+0x1268>
    8875:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
    887c:	00 
    887d:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    8884:	00 
    8885:	4d 85 ed             	test   %r13,%r13
    8888:	0f 85 a9 0b 00 00    	jne    9437 <f12+0x11d7>
    888e:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    8895:	4d 85 ff             	test   %r15,%r15
    8898:	78 17                	js     88b1 <f12+0x651>
    889a:	45 89 fa             	mov    %r15d,%r10d
    889d:	f2 0f 10 05 8b 72 00 	movsd  0x728b(%rip),%xmm0        # fb30 <msg.4+0xb0>
    88a4:	00 
    88a5:	f2 42 0f 58 04 d1    	addsd  (%rcx,%r10,8),%xmm0
    88ab:	f2 42 0f 11 04 d1    	movsd  %xmm0,(%rcx,%r10,8)
    88b1:	4c 39 e3             	cmp    %r12,%rbx
    88b4:	0f 8f 90 00 00 00    	jg     894a <f12+0x6ea>
    88ba:	0f 12 fb             	movhlps %xmm3,%xmm7
    88bd:	66 49 0f 7e d2       	movq   %xmm2,%r10
    88c2:	66 48 0f 7e de       	movq   %xmm3,%rsi
    88c7:	49 29 dc             	sub    %rbx,%r12
    88ca:	66 48 0f 7e ff       	movq   %xmm7,%rdi
    88cf:	0f 12 fa             	movhlps %xmm2,%xmm7
    88d2:	4c 8d 04 d9          	lea    (%rcx,%rbx,8),%r8
    88d6:	66 49 0f 7e fb       	movq   %xmm7,%r11
    88db:	4a 8d 04 a7          	lea    (%rdi,%r12,4),%rax
    88df:	66 0f ef d2          	pxor   %xmm2,%xmm2
    88e3:	48 29 fe             	sub    %rdi,%rsi
    88e6:	4b 8d 14 e3          	lea    (%r11,%r12,8),%rdx
    88ea:	4d 29 d8             	sub    %r11,%r8
    88ed:	4d 29 da             	sub    %r11,%r10
    88f0:	eb 0a                	jmp    88fc <f12+0x69c>
    88f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    88f8:	48 83 e8 04          	sub    $0x4,%rax
    88fc:	f2 41 0f 10 04 10    	movsd  (%r8,%rdx,1),%xmm0
    8902:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    8906:	7a 02                	jp     890a <f12+0x6aa>
    8908:	74 37                	je     8941 <f12+0x6e1>
    890a:	4c 63 1c 06          	movslq (%rsi,%rax,1),%r11
    890e:	45 85 db             	test   %r11d,%r11d
    8911:	78 16                	js     8929 <f12+0x6c9>
    8913:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    8919:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    891d:	f2 42 0f 58 0c d9    	addsd  (%rcx,%r11,8),%xmm1
    8923:	f2 42 0f 11 0c d9    	movsd  %xmm1,(%rcx,%r11,8)
    8929:	4c 63 18             	movslq (%rax),%r11
    892c:	45 85 db             	test   %r11d,%r11d
    892f:	78 10                	js     8941 <f12+0x6e1>
    8931:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    8935:	f2 42 0f 58 04 d9    	addsd  (%rcx,%r11,8),%xmm0
    893b:	f2 42 0f 11 04 d9    	movsd  %xmm0,(%rcx,%r11,8)
    8941:	48 83 ea 08          	sub    $0x8,%rdx
    8945:	48 39 c7             	cmp    %rax,%rdi
    8948:	75 ae                	jne    88f8 <f12+0x698>
    894a:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8951:	ff ff 1f 
    8954:	48 39 d8             	cmp    %rbx,%rax
    8957:	0f 82 5f 0b 00 00    	jb     94bc <f12+0x125c>
    895d:	48 8d 3c dd 08 00 00 	lea    0x8(,%rbx,8),%rdi
    8964:	00 
    8965:	be 02 00 00 00       	mov    $0x2,%esi
    896a:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    896f:	e8 dc d0 ff ff       	call   5a50 <fwp_heap_alloc>
    8974:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    8979:	48 89 18             	mov    %rbx,(%rax)
    897c:	49 89 c4             	mov    %rax,%r12
    897f:	31 c0                	xor    %eax,%eax
    8981:	48 85 db             	test   %rbx,%rbx
    8984:	74 2c                	je     89b2 <f12+0x752>
    8986:	0f 1f 40 00          	nopl   0x0(%rax)
    898a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8991:	00 00 00 00 
    8995:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    899c:	00 00 00 00 
    89a0:	48 8b 14 c1          	mov    (%rcx,%rax,8),%rdx
    89a4:	49 89 54 c4 08       	mov    %rdx,0x8(%r12,%rax,8)
    89a9:	48 83 c0 01          	add    $0x1,%rax
    89ad:	48 39 c3             	cmp    %rax,%rbx
    89b0:	75 ee                	jne    89a0 <f12+0x740>
    89b2:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
    89b9:	00 
    89ba:	48 8b 3c 24          	mov    (%rsp),%rdi
    89be:	4c 89 2d 53 ca 01 00 	mov    %r13,0x1ca53(%rip)        # 25418 <fwp_cleanups>
    89c5:	e8 66 c4 ff ff       	call   4e30 <fwp_tape_buffers_release>
    89ca:	48 8b 15 87 c1 01 00 	mov    0x1c187(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    89d1:	4c 89 e0             	mov    %r12,%rax
    89d4:	48 2b 05 55 c1 01 00 	sub    0x1c155(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    89db:	48 c1 e2 10          	shl    $0x10,%rdx
    89df:	48 39 d0             	cmp    %rdx,%rax
    89e2:	73 55                	jae    8a39 <f12+0x7d9>
    89e4:	48 89 c2             	mov    %rax,%rdx
    89e7:	48 c1 ea 10          	shr    $0x10,%rdx
    89eb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    89ef:	48 8b 15 82 c1 01 00 	mov    0x1c182(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    89f6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    89fa:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    89fe:	48 85 db             	test   %rbx,%rbx
    8a01:	74 36                	je     8a39 <f12+0x7d9>
    8a03:	0f b6 0a             	movzbl (%rdx),%ecx
    8a06:	80 f9 02             	cmp    $0x2,%cl
    8a09:	0f 84 61 08 00 00    	je     9270 <f12+0x1010>
    8a0f:	80 f9 01             	cmp    $0x1,%cl
    8a12:	75 25                	jne    8a39 <f12+0x7d9>
    8a14:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8a17:	0f b7 c0             	movzwl %ax,%eax
    8a1a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8a1d:	48 0f af c1          	imul   %rcx,%rax
    8a21:	48 c1 e8 20          	shr    $0x20,%rax
    8a25:	48 39 d0             	cmp    %rdx,%rax
    8a28:	73 0f                	jae    8a39 <f12+0x7d9>
    8a2a:	48 01 c3             	add    %rax,%rbx
    8a2d:	80 3b ff             	cmpb   $0xff,(%rbx)
    8a30:	0f 84 da 09 00 00    	je     9410 <f12+0x11b0>
    8a36:	c6 03 01             	movb   $0x1,(%rbx)
    8a39:	4c 3b 6c 24 40       	cmp    0x40(%rsp),%r13
    8a3e:	0f 85 07 ad ff ff    	jne    374b <f12.cold>
    8a44:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    8a49:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    8a4e:	48 89 05 c3 c9 01 00 	mov    %rax,0x1c9c3(%rip)        # 25418 <fwp_cleanups>
    8a55:	e8 c6 e3 ff ff       	call   6e20 <fwp_tape_scope_release>
    8a5a:	49 8b 04 24          	mov    (%r12),%rax
    8a5e:	49 89 c6             	mov    %rax,%r14
    8a61:	49 0f ba f6 3f       	btr    $0x3f,%r14
    8a66:	48 85 c0             	test   %rax,%rax
    8a69:	0f 88 51 05 00 00    	js     8fc0 <f12+0xd60>
    8a6f:	48 8b 15 e2 c0 01 00 	mov    0x1c0e2(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    8a76:	4c 89 e0             	mov    %r12,%rax
    8a79:	48 2b 05 b0 c0 01 00 	sub    0x1c0b0(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    8a80:	48 c1 e2 10          	shl    $0x10,%rdx
    8a84:	48 39 d0             	cmp    %rdx,%rax
    8a87:	0f 83 33 05 00 00    	jae    8fc0 <f12+0xd60>
    8a8d:	48 89 c2             	mov    %rax,%rdx
    8a90:	48 c1 ea 10          	shr    $0x10,%rdx
    8a94:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8a98:	48 8b 15 d9 c0 01 00 	mov    0x1c0d9(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    8a9f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8aa3:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    8aa7:	48 85 c9             	test   %rcx,%rcx
    8aaa:	0f 84 10 05 00 00    	je     8fc0 <f12+0xd60>
    8ab0:	0f b6 32             	movzbl (%rdx),%esi
    8ab3:	40 80 fe 02          	cmp    $0x2,%sil
    8ab7:	0f 84 f3 04 00 00    	je     8fb0 <f12+0xd50>
    8abd:	40 80 fe 01          	cmp    $0x1,%sil
    8ac1:	0f 85 f9 04 00 00    	jne    8fc0 <f12+0xd60>
    8ac7:	8b 72 18             	mov    0x18(%rdx),%esi
    8aca:	0f b7 c0             	movzwl %ax,%eax
    8acd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8ad0:	48 0f af c6          	imul   %rsi,%rax
    8ad4:	48 c1 e8 20          	shr    $0x20,%rax
    8ad8:	48 39 d0             	cmp    %rdx,%rax
    8adb:	0f 83 df 04 00 00    	jae    8fc0 <f12+0xd60>
    8ae1:	48 01 c1             	add    %rax,%rcx
    8ae4:	80 39 01             	cmpb   $0x1,(%rcx)
    8ae7:	0f 85 d3 04 00 00    	jne    8fc0 <f12+0xd60>
    8aed:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
    8af2:	4d 89 e5             	mov    %r12,%r13
    8af5:	31 ff                	xor    %edi,%edi
    8af7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    8afc:	f2 0f 10 0d 3c 70 00 	movsd  0x703c(%rip),%xmm1        # fb40 <msg.4+0xc0>
    8b03:	00 
    8b04:	48 8d 50 08          	lea    0x8(%rax),%rdx
    8b08:	31 c0                	xor    %eax,%eax
    8b0a:	4d 85 f6             	test   %r14,%r14
    8b0d:	75 2f                	jne    8b3e <f12+0x8de>
    8b0f:	eb 5f                	jmp    8b70 <f12+0x910>
    8b11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8b18:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    8b1d:	0f 88 6d 09 00 00    	js     9490 <f12+0x1230>
    8b23:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    8b28:	48 83 c0 01          	add    $0x1,%rax
    8b2c:	48 83 c2 08          	add    $0x8,%rdx
    8b30:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    8b34:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8b39:	49 39 c6             	cmp    %rax,%r14
    8b3c:	74 32                	je     8b70 <f12+0x910>
    8b3e:	49 8d 4c 24 08       	lea    0x8(%r12),%rcx
    8b43:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    8b48:	79 ce                	jns    8b18 <f12+0x8b8>
    8b4a:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
    8b4f:	eb c7                	jmp    8b18 <f12+0x8b8>
    8b51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8b58:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    8b5c:	0f 84 62 f9 ff ff    	je     84c4 <f12+0x264>
    8b62:	e9 4f f9 ff ff       	jmp    84b6 <f12+0x256>
    8b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8b6e:	00 00 
    8b70:	e8 8b e8 ff ff       	call   7400 <fwp_drop4>
    8b75:	48 89 e8             	mov    %rbp,%rax
    8b78:	31 d2                	xor    %edx,%edx
    8b7a:	48 85 ed             	test   %rbp,%rbp
    8b7d:	0f 84 17 08 00 00    	je     939a <f12+0x113a>
    8b83:	66 90                	xchg   %ax,%ax
    8b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8b8c:	00 00 00 00 
    8b90:	48 8b 40 10          	mov    0x10(%rax),%rax
    8b94:	48 83 c2 01          	add    $0x1,%rdx
    8b98:	48 85 c0             	test   %rax,%rax
    8b9b:	75 f3                	jne    8b90 <f12+0x930>
    8b9d:	49 8b 45 00          	mov    0x0(%r13),%rax
    8ba1:	49 89 c7             	mov    %rax,%r15
    8ba4:	49 0f ba f7 3f       	btr    $0x3f,%r15
    8ba9:	48 85 c0             	test   %rax,%rax
    8bac:	0f 88 60 03 00 00    	js     8f12 <f12+0xcb2>
    8bb2:	48 8b 05 9f bf 01 00 	mov    0x1bf9f(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    8bb9:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    8bbe:	48 2b 0d 6b bf 01 00 	sub    0x1bf6b(%rip),%rcx        # 24b30 <fwp_heap+0x13b0>
    8bc5:	48 c1 e0 10          	shl    $0x10,%rax
    8bc9:	48 39 c1             	cmp    %rax,%rcx
    8bcc:	0f 83 40 03 00 00    	jae    8f12 <f12+0xcb2>
    8bd2:	48 89 c8             	mov    %rcx,%rax
    8bd5:	48 c1 e8 10          	shr    $0x10,%rax
    8bd9:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    8bdd:	48 8b 05 94 bf 01 00 	mov    0x1bf94(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    8be4:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    8be8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8bec:	48 85 ff             	test   %rdi,%rdi
    8bef:	0f 84 1d 03 00 00    	je     8f12 <f12+0xcb2>
    8bf5:	0f b6 06             	movzbl (%rsi),%eax
    8bf8:	3c 02                	cmp    $0x2,%al
    8bfa:	0f 84 00 03 00 00    	je     8f00 <f12+0xca0>
    8c00:	3c 01                	cmp    $0x1,%al
    8c02:	0f 85 01 03 00 00    	jne    8f09 <f12+0xca9>
    8c08:	8b 46 18             	mov    0x18(%rsi),%eax
    8c0b:	0f b7 c9             	movzwl %cx,%ecx
    8c0e:	48 0f af c8          	imul   %rax,%rcx
    8c12:	8b 46 1c             	mov    0x1c(%rsi),%eax
    8c15:	48 c1 e9 20          	shr    $0x20,%rcx
    8c19:	48 39 c1             	cmp    %rax,%rcx
    8c1c:	0f 83 e7 02 00 00    	jae    8f09 <f12+0xca9>
    8c22:	48 01 cf             	add    %rcx,%rdi
    8c25:	80 3f 01             	cmpb   $0x1,(%rdi)
    8c28:	0f 85 db 02 00 00    	jne    8f09 <f12+0xca9>
    8c2e:	49 39 d7             	cmp    %rdx,%r15
    8c31:	48 89 d0             	mov    %rdx,%rax
    8c34:	49 0f 46 c7          	cmovbe %r15,%rax
    8c38:	48 85 c0             	test   %rax,%rax
    8c3b:	0f 84 5b 08 00 00    	je     949c <f12+0x123c>
    8c41:	c7 44 24 40 01 00 00 	movl   $0x1,0x40(%rsp)
    8c48:	00 
    8c49:	4d 8d 75 08          	lea    0x8(%r13),%r14
    8c4d:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    8c52:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    8c59:	00 
    8c5a:	48 89 e9             	mov    %rbp,%rcx
    8c5d:	31 d2                	xor    %edx,%edx
    8c5f:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    8c63:	eb 38                	jmp    8c9d <f12+0xa3d>
    8c65:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8c6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8c71:	00 00 00 00 
    8c75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8c7c:	00 00 00 00 
    8c80:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    8c85:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    8c8a:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    8c90:	48 83 c2 08          	add    $0x8,%rdx
    8c94:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    8c98:	49 39 d0             	cmp    %rdx,%r8
    8c9b:	74 1b                	je     8cb8 <f12+0xa58>
    8c9d:	48 89 fe             	mov    %rdi,%rsi
    8ca0:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    8ca5:	79 d9                	jns    8c80 <f12+0xa20>
    8ca7:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    8cac:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    8cb0:	eb ce                	jmp    8c80 <f12+0xa20>
    8cb2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8cb8:	48 85 ed             	test   %rbp,%rbp
    8cbb:	0f 84 aa 07 00 00    	je     946b <f12+0x120b>
    8cc1:	4c 8b 05 90 be 01 00 	mov    0x1be90(%rip),%r8        # 24b58 <fwp_heap+0x13d8>
    8cc8:	4c 8b 0d 61 be 01 00 	mov    0x1be61(%rip),%r9        # 24b30 <fwp_heap+0x13b0>
    8ccf:	48 89 e9             	mov    %rbp,%rcx
    8cd2:	45 31 ed             	xor    %r13d,%r13d
    8cd5:	4c 8b 15 9c be 01 00 	mov    0x1be9c(%rip),%r10        # 24b78 <fwp_heap+0x13f8>
    8cdc:	49 c1 e0 10          	shl    $0x10,%r8
    8ce0:	eb 1c                	jmp    8cfe <f12+0xa9e>
    8ce2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ce8:	49 83 c5 01          	add    $0x1,%r13
    8cec:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    8cf0:	49 39 c5             	cmp    %rax,%r13
    8cf3:	0f 83 67 01 00 00    	jae    8e60 <f12+0xc00>
    8cf9:	48 85 c9             	test   %rcx,%rcx
    8cfc:	74 56                	je     8d54 <f12+0xaf4>
    8cfe:	48 89 ca             	mov    %rcx,%rdx
    8d01:	4c 29 ca             	sub    %r9,%rdx
    8d04:	4c 39 c2             	cmp    %r8,%rdx
    8d07:	73 4b                	jae    8d54 <f12+0xaf4>
    8d09:	48 89 d6             	mov    %rdx,%rsi
    8d0c:	48 c1 ee 10          	shr    $0x10,%rsi
    8d10:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    8d14:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    8d18:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8d1c:	48 85 ff             	test   %rdi,%rdi
    8d1f:	74 33                	je     8d54 <f12+0xaf4>
    8d21:	44 0f b6 1e          	movzbl (%rsi),%r11d
    8d25:	41 80 fb 02          	cmp    $0x2,%r11b
    8d29:	0f 84 19 01 00 00    	je     8e48 <f12+0xbe8>
    8d2f:	41 80 fb 01          	cmp    $0x1,%r11b
    8d33:	75 1f                	jne    8d54 <f12+0xaf4>
    8d35:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    8d39:	0f b7 d2             	movzwl %dx,%edx
    8d3c:	8b 76 1c             	mov    0x1c(%rsi),%esi
    8d3f:	49 0f af d3          	imul   %r11,%rdx
    8d43:	48 c1 ea 20          	shr    $0x20,%rdx
    8d47:	48 39 f2             	cmp    %rsi,%rdx
    8d4a:	73 08                	jae    8d54 <f12+0xaf4>
    8d4c:	48 01 d7             	add    %rdx,%rdi
    8d4f:	80 3f 01             	cmpb   $0x1,(%rdi)
    8d52:	74 94                	je     8ce8 <f12+0xa88>
    8d54:	49 39 c5             	cmp    %rax,%r13
    8d57:	0f 83 03 01 00 00    	jae    8e60 <f12+0xc00>
    8d5d:	49 89 c7             	mov    %rax,%r15
    8d60:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
    8d67:	00 
    8d68:	45 31 e4             	xor    %r12d,%r12d
    8d6b:	48 89 04 24          	mov    %rax,(%rsp)
    8d6f:	48 8d 1d 0a aa 01 00 	lea    0x1aa0a(%rip),%rbx        # 23780 <fwp_heap>
    8d76:	eb 3a                	jmp    8db2 <f12+0xb52>
    8d78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8d7f:	00 
    8d80:	41 80 f9 01          	cmp    $0x1,%r9b
    8d84:	75 27                	jne    8dad <f12+0xb4d>
    8d86:	45 8b 48 18          	mov    0x18(%r8),%r9d
    8d8a:	0f b7 c0             	movzwl %ax,%eax
    8d8d:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    8d91:	49 0f af c1          	imul   %r9,%rax
    8d95:	48 c1 e8 20          	shr    $0x20,%rax
    8d99:	4c 39 c0             	cmp    %r8,%rax
    8d9c:	73 0f                	jae    8dad <f12+0xb4d>
    8d9e:	48 01 c7             	add    %rax,%rdi
    8da1:	80 3f ff             	cmpb   $0xff,(%rdi)
    8da4:	0f 84 c6 02 00 00    	je     9070 <f12+0xe10>
    8daa:	c6 07 01             	movb   $0x1,(%rdi)
    8dad:	4d 39 fd             	cmp    %r15,%r13
    8db0:	73 7e                	jae    8e30 <f12+0xbd0>
    8db2:	49 83 ef 01          	sub    $0x1,%r15
    8db6:	66 49 0f 6e f4       	movq   %r12,%xmm6
    8dbb:	48 8b 34 24          	mov    (%rsp),%rsi
    8dbf:	bf 01 00 00 00       	mov    $0x1,%edi
    8dc4:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    8dca:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    8dce:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    8dd5:	00 
    8dd6:	e8 c5 d4 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    8ddb:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    8de2:	49 89 c4             	mov    %rax,%r12
    8de5:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    8dec:	48 c1 e7 10          	shl    $0x10,%rdi
    8df0:	48 39 f8             	cmp    %rdi,%rax
    8df3:	73 b8                	jae    8dad <f12+0xb4d>
    8df5:	48 89 c7             	mov    %rax,%rdi
    8df8:	48 c1 ef 10          	shr    $0x10,%rdi
    8dfc:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    8e00:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    8e07:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    8e0b:	49 8b 78 20          	mov    0x20(%r8),%rdi
    8e0f:	48 85 ff             	test   %rdi,%rdi
    8e12:	74 99                	je     8dad <f12+0xb4d>
    8e14:	45 0f b6 08          	movzbl (%r8),%r9d
    8e18:	41 80 f9 02          	cmp    $0x2,%r9b
    8e1c:	0f 85 5e ff ff ff    	jne    8d80 <f12+0xb20>
    8e22:	66 85 c0             	test   %ax,%ax
    8e25:	0f 84 76 ff ff ff    	je     8da1 <f12+0xb41>
    8e2b:	4d 39 fd             	cmp    %r15,%r13
    8e2e:	72 82                	jb     8db2 <f12+0xb52>
    8e30:	4d 85 ed             	test   %r13,%r13
    8e33:	75 2e                	jne    8e63 <f12+0xc03>
    8e35:	8b 44 24 40          	mov    0x40(%rsp),%eax
    8e39:	85 c0                	test   %eax,%eax
    8e3b:	4d 0f 45 f5          	cmovne %r13,%r14
    8e3f:	eb 6f                	jmp    8eb0 <f12+0xc50>
    8e41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8e48:	66 85 d2             	test   %dx,%dx
    8e4b:	0f 84 fe fe ff ff    	je     8d4f <f12+0xaef>
    8e51:	49 39 c5             	cmp    %rax,%r13
    8e54:	0f 82 03 ff ff ff    	jb     8d5d <f12+0xafd>
    8e5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8e60:	45 31 e4             	xor    %r12d,%r12d
    8e63:	4c 89 f2             	mov    %r14,%rdx
    8e66:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    8e6a:	48 89 e8             	mov    %rbp,%rax
    8e6d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8e74:	00 
    8e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e7c:	00 00 00 00 
    8e80:	48 8b 0a             	mov    (%rdx),%rcx
    8e83:	48 83 c2 08          	add    $0x8,%rdx
    8e87:	48 89 c7             	mov    %rax,%rdi
    8e8a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    8e8e:	48 8b 40 10          	mov    0x10(%rax),%rax
    8e92:	4c 39 c2             	cmp    %r8,%rdx
    8e95:	75 e9                	jne    8e80 <f12+0xc20>
    8e97:	8b 54 24 40          	mov    0x40(%rsp),%edx
    8e9b:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    8e9f:	85 d2                	test   %edx,%edx
    8ea1:	0f 84 d9 03 00 00    	je     9280 <f12+0x1020>
    8ea7:	49 89 ec             	mov    %rbp,%r12
    8eaa:	45 31 f6             	xor    %r14d,%r14d
    8ead:	48 89 c5             	mov    %rax,%rbp
    8eb0:	4c 89 f7             	mov    %r14,%rdi
    8eb3:	e8 98 c6 ff ff       	call   5550 <fwp_mem_free>
    8eb8:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    8ebd:	e8 3e e5 ff ff       	call   7400 <fwp_drop4>
    8ec2:	48 89 ef             	mov    %rbp,%rdi
    8ec5:	e8 46 d9 ff ff       	call   6810 <fwp_drop0>
    8eca:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
    8ed1:	00 
    8ed2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8ed9:	00 00 
    8edb:	0f 85 4e 06 00 00    	jne    952f <f12+0x12cf>
    8ee1:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
    8ee8:	4c 89 e0             	mov    %r12,%rax
    8eeb:	5b                   	pop    %rbx
    8eec:	5d                   	pop    %rbp
    8eed:	41 5c                	pop    %r12
    8eef:	41 5d                	pop    %r13
    8ef1:	41 5e                	pop    %r14
    8ef3:	41 5f                	pop    %r15
    8ef5:	c3                   	ret
    8ef6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8efd:	00 00 00 
    8f00:	66 85 c9             	test   %cx,%cx
    8f03:	0f 84 1c fd ff ff    	je     8c25 <f12+0x9c5>
    8f09:	48 85 ed             	test   %rbp,%rbp
    8f0c:	0f 84 1c 04 00 00    	je     932e <f12+0x10ce>
    8f12:	48 89 e8             	mov    %rbp,%rax
    8f15:	45 31 e4             	xor    %r12d,%r12d
    8f18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8f1f:	00 
    8f20:	48 8b 40 10          	mov    0x10(%rax),%rax
    8f24:	4c 89 e2             	mov    %r12,%rdx
    8f27:	49 83 c4 01          	add    $0x1,%r12
    8f2b:	48 85 c0             	test   %rax,%rax
    8f2e:	75 f0                	jne    8f20 <f12+0xcc0>
    8f30:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8f37:	ff ff 1f 
    8f3a:	4c 39 e0             	cmp    %r12,%rax
    8f3d:	0f 82 6d 05 00 00    	jb     94b0 <f12+0x1250>
    8f43:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    8f4a:	00 
    8f4b:	be 02 00 00 00       	mov    $0x2,%esi
    8f50:	e8 fb ca ff ff       	call   5a50 <fwp_heap_alloc>
    8f55:	4d 39 e7             	cmp    %r12,%r15
    8f58:	48 89 ea             	mov    %rbp,%rdx
    8f5b:	49 89 c6             	mov    %rax,%r14
    8f5e:	4c 89 e0             	mov    %r12,%rax
    8f61:	49 0f 46 c7          	cmovbe %r15,%rax
    8f65:	4c 89 f1             	mov    %r14,%rcx
    8f68:	66 90                	xchg   %ax,%ax
    8f6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8f71:	00 00 00 00 
    8f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8f7c:	00 00 00 00 
    8f80:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    8f84:	48 83 c1 08          	add    $0x8,%rcx
    8f88:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    8f8c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8f90:	48 85 d2             	test   %rdx,%rdx
    8f93:	75 eb                	jne    8f80 <f12+0xd20>
    8f95:	48 85 c0             	test   %rax,%rax
    8f98:	0f 84 a2 03 00 00    	je     9340 <f12+0x10e0>
    8f9e:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
    8fa5:	00 
    8fa6:	e9 a2 fc ff ff       	jmp    8c4d <f12+0x9ed>
    8fab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8fb0:	66 85 c0             	test   %ax,%ax
    8fb3:	0f 84 2b fb ff ff    	je     8ae4 <f12+0x884>
    8fb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8fc0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8fc7:	ff ff 1f 
    8fca:	4c 39 f0             	cmp    %r14,%rax
    8fcd:	0f 82 e9 04 00 00    	jb     94bc <f12+0x125c>
    8fd3:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8fda:	00 
    8fdb:	be 01 00 00 00       	mov    $0x1,%esi
    8fe0:	e8 6b ca ff ff       	call   5a50 <fwp_heap_alloc>
    8fe5:	4c 89 30             	mov    %r14,(%rax)
    8fe8:	48 8b 15 69 bb 01 00 	mov    0x1bb69(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    8fef:	49 89 c5             	mov    %rax,%r13
    8ff2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8ff7:	48 2b 05 32 bb 01 00 	sub    0x1bb32(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    8ffe:	48 c1 e2 10          	shl    $0x10,%rdx
    9002:	48 39 d0             	cmp    %rdx,%rax
    9005:	73 57                	jae    905e <f12+0xdfe>
    9007:	48 89 c2             	mov    %rax,%rdx
    900a:	48 c1 ea 10          	shr    $0x10,%rdx
    900e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9012:	48 8b 15 5f bb 01 00 	mov    0x1bb5f(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    9019:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    901d:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    9021:	4d 85 ff             	test   %r15,%r15
    9024:	74 38                	je     905e <f12+0xdfe>
    9026:	0f b6 0a             	movzbl (%rdx),%ecx
    9029:	80 f9 02             	cmp    $0x2,%cl
    902c:	0f 84 1e 03 00 00    	je     9350 <f12+0x10f0>
    9032:	80 f9 01             	cmp    $0x1,%cl
    9035:	75 27                	jne    905e <f12+0xdfe>
    9037:	8b 4a 18             	mov    0x18(%rdx),%ecx
    903a:	0f b7 c0             	movzwl %ax,%eax
    903d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9040:	48 0f af c1          	imul   %rcx,%rax
    9044:	48 c1 e8 20          	shr    $0x20,%rax
    9048:	48 39 d0             	cmp    %rdx,%rax
    904b:	73 11                	jae    905e <f12+0xdfe>
    904d:	49 01 c7             	add    %rax,%r15
    9050:	41 80 3f ff          	cmpb   $0xff,(%r15)
    9054:	0f 84 c3 03 00 00    	je     941d <f12+0x11bd>
    905a:	41 c6 07 01          	movb   $0x1,(%r15)
    905e:	4c 89 e7             	mov    %r12,%rdi
    9061:	e9 91 fa ff ff       	jmp    8af7 <f12+0x897>
    9066:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    906d:	00 00 00 
    9070:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
    9075:	e8 96 c2 ff ff       	call   5310 <fwp_rc_forget_slot>
    907a:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    907f:	e9 26 fd ff ff       	jmp    8daa <f12+0xb4a>
    9084:	0f 1f 40 00          	nopl   0x0(%rax)
    9088:	48 c1 e6 10          	shl    $0x10,%rsi
    908c:	bf 08 00 00 00       	mov    $0x8,%edi
    9091:	49 09 f5             	or     %rsi,%r13
    9094:	be 02 00 00 00       	mov    $0x2,%esi
    9099:	e8 b2 c9 ff ff       	call   5a50 <fwp_heap_alloc>
    909e:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    90a5:	48 8b 15 ac ba 01 00 	mov    0x1baac(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    90ac:	48 89 c3             	mov    %rax,%rbx
    90af:	48 2b 05 7a ba 01 00 	sub    0x1ba7a(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    90b6:	48 c1 e2 10          	shl    $0x10,%rdx
    90ba:	48 39 d0             	cmp    %rdx,%rax
    90bd:	0f 83 fc f5 ff ff    	jae    86bf <f12+0x45f>
    90c3:	48 89 c2             	mov    %rax,%rdx
    90c6:	48 c1 ea 10          	shr    $0x10,%rdx
    90ca:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    90ce:	48 8b 15 a3 ba 01 00 	mov    0x1baa3(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    90d5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    90d9:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    90dd:	4d 85 f6             	test   %r14,%r14
    90e0:	0f 84 cd f5 ff ff    	je     86b3 <f12+0x453>
    90e6:	0f b6 0a             	movzbl (%rdx),%ecx
    90e9:	45 31 e4             	xor    %r12d,%r12d
    90ec:	80 f9 02             	cmp    $0x2,%cl
    90ef:	0f 85 11 f5 ff ff    	jne    8606 <f12+0x3a6>
    90f5:	66 85 c0             	test   %ax,%ax
    90f8:	0f 85 34 f5 ff ff    	jne    8632 <f12+0x3d2>
    90fe:	e9 21 f5 ff ff       	jmp    8624 <f12+0x3c4>
    9103:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9108:	4c 8d 60 ff          	lea    -0x1(%rax),%r12
    910c:	4c 89 e1             	mov    %r12,%rcx
    910f:	48 c1 e9 3c          	shr    $0x3c,%rcx
    9113:	0f 85 97 03 00 00    	jne    94b0 <f12+0x1250>
    9119:	4d 85 e4             	test   %r12,%r12
    911c:	0f 84 9d f5 ff ff    	je     86bf <f12+0x45f>
    9122:	48 c1 e0 04          	shl    $0x4,%rax
    9126:	4d 01 e4             	add    %r12,%r12
    9129:	4c 8d 7b 08          	lea    0x8(%rbx),%r15
    912d:	4c 8d 74 03 f8       	lea    -0x8(%rbx,%rax,1),%r14
    9132:	0f 1f 00             	nopl   (%rax)
    9135:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    913c:	00 00 00 00 
    9140:	f2 41 0f 10 07       	movsd  (%r15),%xmm0
    9145:	49 8b 77 18          	mov    0x18(%r15),%rsi
    9149:	49 83 c7 10          	add    $0x10,%r15
    914d:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
    9151:	f2 41 0f 10 0f       	movsd  (%r15),%xmm1
    9156:	e8 d5 cf ff ff       	call   6130 <w107>
    915b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    9160:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    9164:	41 0f 11 47 f0       	movups %xmm0,-0x10(%r15)
    9169:	4d 39 fe             	cmp    %r15,%r14
    916c:	75 d2                	jne    9140 <f12+0xee0>
    916e:	4c 89 23             	mov    %r12,(%rbx)
    9171:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    9178:	45 31 f6             	xor    %r14d,%r14d
    917b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9180:	4a 8b 54 f3 10       	mov    0x10(%rbx,%r14,8),%rdx
    9185:	4c 89 ff             	mov    %r15,%rdi
    9188:	49 83 c6 02          	add    $0x2,%r14
    918c:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    9193:	00 f0 3f 
    9196:	48 89 ce             	mov    %rcx,%rsi
    9199:	e8 12 cc ff ff       	call   5db0 <fwp_p_ad_push>
    919e:	49 89 c7             	mov    %rax,%r15
    91a1:	4d 39 e6             	cmp    %r12,%r14
    91a4:	72 da                	jb     9180 <f12+0xf20>
    91a6:	e9 25 f5 ff ff       	jmp    86d0 <f12+0x470>
    91ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    91b0:	4d 8d 6a 01          	lea    0x1(%r10),%r13
    91b4:	4d 39 ee             	cmp    %r13,%r14
    91b7:	0f 8c 52 f6 ff ff    	jl     880f <f12+0x5af>
    91bd:	48 85 c9             	test   %rcx,%rcx
    91c0:	0f 84 0b 03 00 00    	je     94d1 <f12+0x1271>
    91c6:	4c 89 54 24 48       	mov    %r10,0x48(%rsp)
    91cb:	4a 8d 14 ed 00 00 00 	lea    0x0(,%r13,8),%rdx
    91d2:	00 
    91d3:	31 f6                	xor    %esi,%esi
    91d5:	48 89 cf             	mov    %rcx,%rdi
    91d8:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    91dd:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    91e2:	e8 d9 a2 ff ff       	call   34c0 <memset@plt>
    91e7:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    91ed:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    91f3:	4c 8b 54 24 48       	mov    0x48(%rsp),%r10
    91f8:	48 89 c1             	mov    %rax,%rcx
    91fb:	e9 9d f6 ff ff       	jmp    889d <f12+0x63d>
    9200:	48 8d 3d 39 db ff ff 	lea    -0x24c7(%rip),%rdi        # 6d40 <fwp_tape_finish>
    9207:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    920c:	e8 1f 56 00 00       	call   e830 <atexit>
    9211:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    9216:	85 c0                	test   %eax,%eax
    9218:	0f 85 cb 02 00 00    	jne    94e9 <f12+0x1289>
    921e:	c7 05 58 9e 00 00 01 	movl   $0x1,0x9e58(%rip)        # 13080 <registered_finish.0>
    9225:	00 00 00 
    9228:	e9 60 f1 ff ff       	jmp    838d <f12+0x12d>
    922d:	0f 1f 00             	nopl   (%rax)
    9230:	66 85 c0             	test   %ax,%ax
    9233:	0f 85 07 f1 ff ff    	jne    8340 <f12+0xe0>
    9239:	e9 ee f0 ff ff       	jmp    832c <f12+0xcc>
    923e:	66 90                	xchg   %ax,%ax
    9240:	4c 39 f3             	cmp    %r14,%rbx
    9243:	0f 8f c3 f5 ff ff    	jg     880c <f12+0x5ac>
    9249:	48 85 db             	test   %rbx,%rbx
    924c:	74 12                	je     9260 <f12+0x1000>
    924e:	48 85 c9             	test   %rcx,%rcx
    9251:	0f 84 7a 02 00 00    	je     94d1 <f12+0x1271>
    9257:	48 85 db             	test   %rbx,%rbx
    925a:	0f 85 d4 01 00 00    	jne    9434 <f12+0x11d4>
    9260:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    9267:	e9 45 f6 ff ff       	jmp    88b1 <f12+0x651>
    926c:	0f 1f 40 00          	nopl   0x0(%rax)
    9270:	66 85 c0             	test   %ax,%ax
    9273:	0f 85 c0 f7 ff ff    	jne    8a39 <f12+0x7d9>
    9279:	e9 af f7 ff ff       	jmp    8a2d <f12+0x7cd>
    927e:	66 90                	xchg   %ax,%ax
    9280:	49 89 ec             	mov    %rbp,%r12
    9283:	48 89 c5             	mov    %rax,%rbp
    9286:	e9 25 fc ff ff       	jmp    8eb0 <f12+0xc50>
    928b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9290:	66 0f 6f 0d 28 9e 01 	movdqa 0x19e28(%rip),%xmm1        # 230c0 <fwp_tape_workspace>
    9297:	00 
    9298:	48 c7 05 05 9e 01 00 	movq   $0x0,0x19e05(%rip)        # 230a8 <fwp_tape_cached_bytes>
    929f:	00 00 00 00 
    92a3:	41 0f 11 4e 20       	movups %xmm1,0x20(%r14)
    92a8:	48 8b 05 31 9e 01 00 	mov    0x19e31(%rip),%rax        # 230e0 <fwp_tape_workspace+0x20>
    92af:	66 0f 6f 0d 19 9e 01 	movdqa 0x19e19(%rip),%xmm1        # 230d0 <fwp_tape_workspace+0x10>
    92b6:	00 
    92b7:	49 89 46 40          	mov    %rax,0x40(%r14)
    92bb:	48 8b 05 26 9e 01 00 	mov    0x19e26(%rip),%rax        # 230e8 <fwp_tape_workspace+0x28>
    92c2:	41 0f 11 4e 30       	movups %xmm1,0x30(%r14)
    92c7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    92cb:	49 89 46 18          	mov    %rax,0x18(%r14)
    92cf:	48 8b 05 1a 9e 01 00 	mov    0x19e1a(%rip),%rax        # 230f0 <fwp_tape_workspace+0x30>
    92d6:	0f 29 0d e3 9d 01 00 	movaps %xmm1,0x19de3(%rip)        # 230c0 <fwp_tape_workspace>
    92dd:	49 89 46 48          	mov    %rax,0x48(%r14)
    92e1:	0f 29 0d e8 9d 01 00 	movaps %xmm1,0x19de8(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    92e8:	48 c7 05 fd 9d 01 00 	movq   $0x0,0x19dfd(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    92ef:	00 00 00 00 
    92f3:	0f 29 0d e6 9d 01 00 	movaps %xmm1,0x19de6(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    92fa:	e9 c5 f1 ff ff       	jmp    84c4 <f12+0x264>
    92ff:	90                   	nop
    9300:	48 85 c9             	test   %rcx,%rcx
    9303:	0f 84 c8 01 00 00    	je     94d1 <f12+0x1271>
    9309:	4c 89 54 24 48       	mov    %r10,0x48(%rsp)
    930e:	4c 8d 63 ff          	lea    -0x1(%rbx),%r12
    9312:	31 f6                	xor    %esi,%esi
    9314:	48 89 cf             	mov    %rcx,%rdi
    9317:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    931c:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    9323:	00 
    9324:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    9329:	e9 b4 fe ff ff       	jmp    91e2 <f12+0xf82>
    932e:	be 02 00 00 00       	mov    $0x2,%esi
    9333:	bf 08 00 00 00       	mov    $0x8,%edi
    9338:	e8 13 c7 ff ff       	call   5a50 <fwp_heap_alloc>
    933d:	49 89 c6             	mov    %rax,%r14
    9340:	45 31 e4             	xor    %r12d,%r12d
    9343:	e9 68 fb ff ff       	jmp    8eb0 <f12+0xc50>
    9348:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    934f:	00 
    9350:	66 85 c0             	test   %ax,%ax
    9353:	0f 85 05 fd ff ff    	jne    905e <f12+0xdfe>
    9359:	e9 f2 fc ff ff       	jmp    9050 <f12+0xdf0>
    935e:	66 90                	xchg   %ax,%ax
    9360:	4d 85 e4             	test   %r12,%r12
    9363:	0f 85 ce f2 ff ff    	jne    8637 <f12+0x3d7>
    9369:	e9 51 f3 ff ff       	jmp    86bf <f12+0x45f>
    936e:	66 90                	xchg   %ax,%ax
    9370:	be 08 00 00 00       	mov    $0x8,%esi
    9375:	4c 89 f7             	mov    %r14,%rdi
    9378:	e8 a3 a1 ff ff       	call   3520 <calloc@plt>
    937d:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    9383:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    9389:	48 89 c1             	mov    %rax,%rcx
    938c:	e9 db f4 ff ff       	jmp    886c <f12+0x60c>
    9391:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9395:	e9 e5 ef ff ff       	jmp    837f <f12+0x11f>
    939a:	49 8b 45 00          	mov    0x0(%r13),%rax
    939e:	48 85 c0             	test   %rax,%rax
    93a1:	78 8b                	js     932e <f12+0x10ce>
    93a3:	48 8b 35 ae b7 01 00 	mov    0x1b7ae(%rip),%rsi        # 24b58 <fwp_heap+0x13d8>
    93aa:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    93af:	48 2b 0d 7a b7 01 00 	sub    0x1b77a(%rip),%rcx        # 24b30 <fwp_heap+0x13b0>
    93b6:	48 c1 e6 10          	shl    $0x10,%rsi
    93ba:	48 39 f1             	cmp    %rsi,%rcx
    93bd:	0f 83 6b ff ff ff    	jae    932e <f12+0x10ce>
    93c3:	48 89 ce             	mov    %rcx,%rsi
    93c6:	48 c1 ee 10          	shr    $0x10,%rsi
    93ca:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    93ce:	48 8b 35 a3 b7 01 00 	mov    0x1b7a3(%rip),%rsi        # 24b78 <fwp_heap+0x13f8>
    93d5:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    93d9:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    93dd:	48 85 ff             	test   %rdi,%rdi
    93e0:	0f 84 48 ff ff ff    	je     932e <f12+0x10ce>
    93e6:	48 0f ba f0 3f       	btr    $0x3f,%rax
    93eb:	49 89 c7             	mov    %rax,%r15
    93ee:	e9 02 f8 ff ff       	jmp    8bf5 <f12+0x995>
    93f3:	be 68 00 00 00       	mov    $0x68,%esi
    93f8:	41 be 01 00 00 00    	mov    $0x1,%r14d
    93fe:	e9 08 f0 ff ff       	jmp    840b <f12+0x1ab>
    9403:	4c 89 f7             	mov    %r14,%rdi
    9406:	e8 05 bf ff ff       	call   5310 <fwp_rc_forget_slot>
    940b:	e9 1e f2 ff ff       	jmp    862e <f12+0x3ce>
    9410:	48 89 df             	mov    %rbx,%rdi
    9413:	e8 f8 be ff ff       	call   5310 <fwp_rc_forget_slot>
    9418:	e9 19 f6 ff ff       	jmp    8a36 <f12+0x7d6>
    941d:	4c 89 ff             	mov    %r15,%rdi
    9420:	e8 eb be ff ff       	call   5310 <fwp_rc_forget_slot>
    9425:	e9 30 fc ff ff       	jmp    905a <f12+0xdfa>
    942a:	e8 c1 bd ff ff       	call   51f0 <fwp_rc_wide_dup>
    942f:	e9 0c ef ff ff       	jmp    8340 <f12+0xe0>
    9434:	49 89 dd             	mov    %rbx,%r13
    9437:	48 89 cf             	mov    %rcx,%rdi
    943a:	31 f6                	xor    %esi,%esi
    943c:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    9441:	4d 8d 65 ff          	lea    -0x1(%r13),%r12
    9445:	4a 8d 14 ed 00 00 00 	lea    0x0(,%r13,8),%rdx
    944c:	00 
    944d:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    9452:	e8 69 a0 ff ff       	call   34c0 <memset@plt>
    9457:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    945d:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    9463:	48 89 c1             	mov    %rax,%rcx
    9466:	e9 2a f4 ff ff       	jmp    8895 <f12+0x635>
    946b:	45 31 ed             	xor    %r13d,%r13d
    946e:	e9 ea f8 ff ff       	jmp    8d5d <f12+0xafd>
    9473:	48 8d 3d 8a 5c 00 00 	lea    0x5c8a(%rip),%rdi        # f104 <_IO_stdin_used+0x104>
    947a:	e8 21 ad ff ff       	call   41a0 <fwp_trap>
    947f:	48 8d 3d 3a 63 00 00 	lea    0x633a(%rip),%rdi        # f7c0 <_IO_stdin_used+0x7c0>
    9486:	e8 15 ad ff ff       	call   41a0 <fwp_trap>
    948b:	e8 70 a2 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9490:	48 8d 3d 31 64 00 00 	lea    0x6431(%rip),%rdi        # f8c8 <_IO_stdin_used+0x8c8>
    9497:	e8 04 ad ff ff       	call   41a0 <fwp_trap>
    949c:	45 31 f6             	xor    %r14d,%r14d
    949f:	e9 9c fe ff ff       	jmp    9340 <f12+0x10e0>
    94a4:	48 8d 3d 90 5c 00 00 	lea    0x5c90(%rip),%rdi        # f13b <_IO_stdin_used+0x13b>
    94ab:	e8 f0 ac ff ff       	call   41a0 <fwp_trap>
    94b0:	48 8d 3d 76 5c 00 00 	lea    0x5c76(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    94b7:	e8 e4 ac ff ff       	call   41a0 <fwp_trap>
    94bc:	48 8d 3d 92 5c 00 00 	lea    0x5c92(%rip),%rdi        # f155 <_IO_stdin_used+0x155>
    94c3:	e8 d8 ac ff ff       	call   41a0 <fwp_trap>
    94c8:	4d 85 ed             	test   %r13,%r13
    94cb:	0f 84 bd f3 ff ff    	je     888e <f12+0x62e>
    94d1:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    94d8:	00 
    94d9:	48 8b 3c 24          	mov    (%rsp),%rdi
    94dd:	48 89 05 34 bf 01 00 	mov    %rax,0x1bf34(%rip)        # 25418 <fwp_cleanups>
    94e4:	e8 47 b9 ff ff       	call   4e30 <fwp_tape_buffers_release>
    94e9:	48 8b 0d 70 9b 00 00 	mov    0x9b70(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    94f0:	ba 13 00 00 00       	mov    $0x13,%edx
    94f5:	be 01 00 00 00       	mov    $0x1,%esi
    94fa:	48 8d 3d 07 5b 00 00 	lea    0x5b07(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    9501:	e8 7a a1 ff ff       	call   3680 <fwrite@plt>
    9506:	31 ff                	xor    %edi,%edi
    9508:	e8 b3 a0 ff ff       	call   35c0 <fflush@plt>
    950d:	bf 66 00 00 00       	mov    $0x66,%edi
    9512:	e8 89 a1 ff ff       	call   36a0 <_Exit@plt>
    9517:	48 8d 3d 7a 63 00 00 	lea    0x637a(%rip),%rdi        # f898 <_IO_stdin_used+0x898>
    951e:	e8 7d ac ff ff       	call   41a0 <fwp_trap>
    9523:	48 8d 3d 3e 63 00 00 	lea    0x633e(%rip),%rdi        # f868 <_IO_stdin_used+0x868>
    952a:	e8 71 ac ff ff       	call   41a0 <fwp_trap>
    952f:	e8 2c 9f ff ff       	call   3460 <__stack_chk_fail@plt>
    9534:	48 8d 3d cd 62 00 00 	lea    0x62cd(%rip),%rdi        # f808 <_IO_stdin_used+0x808>
    953b:	e8 60 ac ff ff       	call   41a0 <fwp_trap>

0000000000009540 <fwp_owned_entry12>:
    9540:	f3 0f 1e fa          	endbr64
    9544:	48 8b 3f             	mov    (%rdi),%rdi
    9547:	e9 14 ed ff ff       	jmp    8260 <f12>
    954c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009550 <e12>:
    9550:	f3 0f 1e fa          	endbr64
    9554:	53                   	push   %rbx
    9555:	48 8b 1f             	mov    (%rdi),%rbx
    9558:	48 89 df             	mov    %rbx,%rdi
    955b:	e8 70 ce ff ff       	call   63d0 <fwp_rc_share>
    9560:	48 89 df             	mov    %rbx,%rdi
    9563:	e8 f8 ec ff ff       	call   8260 <f12>
    9568:	48 89 c3             	mov    %rax,%rbx
    956b:	48 89 c7             	mov    %rax,%rdi
    956e:	e8 5d ce ff ff       	call   63d0 <fwp_rc_share>
    9573:	48 89 d8             	mov    %rbx,%rax
    9576:	5b                   	pop    %rbx
    9577:	c3                   	ret
    9578:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    957f:	00 

0000000000009580 <fwp_write>:
    9580:	41 57                	push   %r15
    9582:	41 56                	push   %r14
    9584:	41 55                	push   %r13
    9586:	41 54                	push   %r12
    9588:	55                   	push   %rbp
    9589:	53                   	push   %rbx
    958a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9591:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9598:	00 00 
    959a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    95a1:	00 
    95a2:	49 89 d4             	mov    %rdx,%r12
    95a5:	8b 12                	mov    (%rdx),%edx
    95a7:	83 fa 19             	cmp    $0x19,%edx
    95aa:	77 6a                	ja     9616 <fwp_write+0x96>
    95ac:	48 89 f5             	mov    %rsi,%rbp
    95af:	89 d0                	mov    %edx,%eax
    95b1:	89 ce                	mov    %ecx,%esi
    95b3:	48 89 fb             	mov    %rdi,%rbx
    95b6:	48 8d 0d 53 64 00 00 	lea    0x6453(%rip),%rcx        # fa10 <_IO_stdin_used+0xa10>
    95bd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    95c1:	48 01 c8             	add    %rcx,%rax
    95c4:	3e ff e0             	notrack jmp *%rax
    95c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    95ce:	00 00 
    95d0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    95d4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    95d8:	48 89 ca             	mov    %rcx,%rdx
    95db:	48 85 c9             	test   %rcx,%rcx
    95de:	0f 88 9c 0c 00 00    	js     a280 <fwp_write+0xd00>
    95e4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    95eb:	00 
    95ec:	48 89 c6             	mov    %rax,%rsi
    95ef:	4c 89 e7             	mov    %r12,%rdi
    95f2:	e8 49 a4 ff ff       	call   3a40 <fwp_fmt_u128>
    95f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    95fe:	00 00 
    9600:	4c 89 e7             	mov    %r12,%rdi
    9603:	e8 48 9e ff ff       	call   3450 <strlen@plt>
    9608:	4c 89 e6             	mov    %r12,%rsi
    960b:	48 89 df             	mov    %rbx,%rdi
    960e:	48 89 c2             	mov    %rax,%rdx
    9611:	e8 5a aa ff ff       	call   4070 <buf_put>
    9616:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    961d:	00 
    961e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9625:	00 00 
    9627:	0f 85 28 04 00 00    	jne    9a55 <fwp_write+0x4d5>
    962d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9634:	5b                   	pop    %rbx
    9635:	5d                   	pop    %rbp
    9636:	41 5c                	pop    %r12
    9638:	41 5d                	pop    %r13
    963a:	41 5e                	pop    %r14
    963c:	41 5f                	pop    %r15
    963e:	c3                   	ret
    963f:	90                   	nop
    9640:	49 89 e9             	mov    %rbp,%r9
    9643:	4c 8d 05 37 5b 00 00 	lea    0x5b37(%rip),%r8        # f181 <_IO_stdin_used+0x181>
    964a:	b9 00 02 00 00       	mov    $0x200,%ecx
    964f:	ba 02 00 00 00       	mov    $0x2,%edx
    9654:	be 00 02 00 00       	mov    $0x200,%esi
    9659:	31 c0                	xor    %eax,%eax
    965b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9662:	00 
    9663:	e8 48 9d ff ff       	call   33b0 <__snprintf_chk@plt>
    9668:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    966f:	00 
    9670:	e8 db 9d ff ff       	call   3450 <strlen@plt>
    9675:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    967c:	00 
    967d:	48 89 df             	mov    %rbx,%rdi
    9680:	48 89 c2             	mov    %rax,%rdx
    9683:	e8 e8 a9 ff ff       	call   4070 <buf_put>
    9688:	eb 8c                	jmp    9616 <fwp_write+0x96>
    968a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9690:	49 89 e9             	mov    %rbp,%r9
    9693:	4c 8d 05 e2 5a 00 00 	lea    0x5ae2(%rip),%r8        # f17c <_IO_stdin_used+0x17c>
    969a:	eb ae                	jmp    964a <fwp_write+0xca>
    969c:	0f 1f 40 00          	nopl   0x0(%rax)
    96a0:	83 fa 13             	cmp    $0x13,%edx
    96a3:	48 8d 05 c8 5a 00 00 	lea    0x5ac8(%rip),%rax        # f172 <_IO_stdin_used+0x172>
    96aa:	48 8d 35 c6 5a 00 00 	lea    0x5ac6(%rip),%rsi        # f177 <_IO_stdin_used+0x177>
    96b1:	ba 04 00 00 00       	mov    $0x4,%edx
    96b6:	48 0f 44 f0          	cmove  %rax,%rsi
    96ba:	45 31 ed             	xor    %r13d,%r13d
    96bd:	e8 ae a9 ff ff       	call   4070 <buf_put>
    96c2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    96c7:	0f 84 a3 08 00 00    	je     9f70 <fwp_write+0x9f0>
    96cd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    96d2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    96d7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    96dc:	48 89 df             	mov    %rbx,%rdi
    96df:	49 0f 44 c5          	cmove  %r13,%rax
    96e3:	31 c9                	xor    %ecx,%ecx
    96e5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    96ea:	e8 91 fe ff ff       	call   9580 <fwp_write>
    96ef:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    96f4:	0f 84 6e 09 00 00    	je     a068 <fwp_write+0xae8>
    96fa:	49 83 c5 01          	add    $0x1,%r13
    96fe:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9702:	0f 83 68 08 00 00    	jae    9f70 <fwp_write+0x9f0>
    9708:	ba 02 00 00 00       	mov    $0x2,%edx
    970d:	48 8d 35 ad 5a 00 00 	lea    0x5aad(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    9714:	48 89 df             	mov    %rbx,%rdi
    9717:	e8 54 a9 ff ff       	call   4070 <buf_put>
    971c:	eb af                	jmp    96cd <fwp_write+0x14d>
    971e:	66 90                	xchg   %ax,%ax
    9720:	ba 06 00 00 00       	mov    $0x6,%edx
    9725:	48 8d 35 6e 5a 00 00 	lea    0x5a6e(%rip),%rsi        # f19a <_IO_stdin_used+0x19a>
    972c:	48 83 c5 10          	add    $0x10,%rbp
    9730:	e8 3b a9 ff ff       	call   4070 <buf_put>
    9735:	48 89 ef             	mov    %rbp,%rdi
    9738:	e8 13 9d ff ff       	call   3450 <strlen@plt>
    973d:	48 89 ee             	mov    %rbp,%rsi
    9740:	48 89 df             	mov    %rbx,%rdi
    9743:	48 89 c2             	mov    %rax,%rdx
    9746:	e8 25 a9 ff ff       	call   4070 <buf_put>
    974b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9750:	ba 01 00 00 00       	mov    $0x1,%edx
    9755:	48 89 df             	mov    %rbx,%rdi
    9758:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    975d:	e8 0e a9 ff ff       	call   4070 <buf_put>
    9762:	e9 af fe ff ff       	jmp    9616 <fwp_write+0x96>
    9767:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    976e:	00 00 
    9770:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9777:	00 
    9778:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    977f:	00 00 
    9781:	0f 85 ce 02 00 00    	jne    9a55 <fwp_write+0x4d5>
    9787:	ba 0a 00 00 00       	mov    $0xa,%edx
    978c:	48 8d 35 f3 59 00 00 	lea    0x59f3(%rip),%rsi        # f186 <_IO_stdin_used+0x186>
    9793:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    979a:	48 89 df             	mov    %rbx,%rdi
    979d:	5b                   	pop    %rbx
    979e:	5d                   	pop    %rbp
    979f:	41 5c                	pop    %r12
    97a1:	41 5d                	pop    %r13
    97a3:	41 5e                	pop    %r14
    97a5:	41 5f                	pop    %r15
    97a7:	e9 c4 a8 ff ff       	jmp    4070 <buf_put>
    97ac:	0f 1f 40 00          	nopl   0x0(%rax)
    97b0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    97b5:	4d 85 ed             	test   %r13,%r13
    97b8:	0f 84 02 0c 00 00    	je     a3c0 <fwp_write+0xe40>
    97be:	48 8d 35 09 5a 00 00 	lea    0x5a09(%rip),%rsi        # f1ce <_IO_stdin_used+0x1ce>
    97c5:	4c 89 ef             	mov    %r13,%rdi
    97c8:	e8 63 9d ff ff       	call   3530 <strcmp@plt>
    97cd:	41 89 c1             	mov    %eax,%r9d
    97d0:	85 c0                	test   %eax,%eax
    97d2:	0f 84 6c 0c 00 00    	je     a444 <fwp_write+0xec4>
    97d8:	4c 89 ef             	mov    %r13,%rdi
    97db:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    97e0:	e8 6b 9c ff ff       	call   3450 <strlen@plt>
    97e5:	4c 89 ee             	mov    %r13,%rsi
    97e8:	48 89 df             	mov    %rbx,%rdi
    97eb:	48 89 c2             	mov    %rax,%rdx
    97ee:	e8 7d a8 ff ff       	call   4070 <buf_put>
    97f3:	ba 01 00 00 00       	mov    $0x1,%edx
    97f8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    97fd:	48 89 df             	mov    %rbx,%rdi
    9800:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9805:	e8 66 a8 ff ff       	call   4070 <buf_put>
    980a:	ba 01 00 00 00       	mov    $0x1,%edx
    980f:	4c 89 fe             	mov    %r15,%rsi
    9812:	48 89 df             	mov    %rbx,%rdi
    9815:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    981a:	e8 51 a8 ff ff       	call   4070 <buf_put>
    981f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9824:	45 31 f6             	xor    %r14d,%r14d
    9827:	85 d2                	test   %edx,%edx
    9829:	0f 8e 81 0a 00 00    	jle    a2b0 <fwp_write+0xd30>
    982f:	45 31 ed             	xor    %r13d,%r13d
    9832:	4d 85 ed             	test   %r13,%r13
    9835:	0f 85 75 07 00 00    	jne    9fb0 <fwp_write+0xa30>
    983b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9842:	00 
    9843:	45 85 f6             	test   %r14d,%r14d
    9846:	0f 84 84 07 00 00    	je     9fd0 <fwp_write+0xa50>
    984c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    9851:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    9856:	48 89 df             	mov    %rbx,%rdi
    9859:	49 83 c5 01          	add    $0x1,%r13
    985d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    9861:	31 c9                	xor    %ecx,%ecx
    9863:	e8 18 fd ff ff       	call   9580 <fwp_write>
    9868:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    986d:	7f c3                	jg     9832 <fwp_write+0x2b2>
    986f:	45 85 f6             	test   %r14d,%r14d
    9872:	0f 84 38 0a 00 00    	je     a2b0 <fwp_write+0xd30>
    9878:	b8 29 00 00 00       	mov    $0x29,%eax
    987d:	ba 01 00 00 00       	mov    $0x1,%edx
    9882:	4c 89 fe             	mov    %r15,%rsi
    9885:	48 89 df             	mov    %rbx,%rdi
    9888:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    988c:	e8 df a7 ff ff       	call   4070 <buf_put>
    9891:	e9 80 fd ff ff       	jmp    9616 <fwp_write+0x96>
    9896:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    989d:	00 00 00 
    98a0:	ba 01 00 00 00       	mov    $0x1,%edx
    98a5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    98aa:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    98af:	e8 bc a7 ff ff       	call   4070 <buf_put>
    98b4:	48 85 ed             	test   %rbp,%rbp
    98b7:	0f 84 93 06 00 00    	je     9f50 <fwp_write+0x9d0>
    98bd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    98c1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    98c6:	31 c9                	xor    %ecx,%ecx
    98c8:	48 89 df             	mov    %rbx,%rdi
    98cb:	e8 b0 fc ff ff       	call   9580 <fwp_write>
    98d0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    98d4:	48 85 ed             	test   %rbp,%rbp
    98d7:	0f 84 73 06 00 00    	je     9f50 <fwp_write+0x9d0>
    98dd:	ba 02 00 00 00       	mov    $0x2,%edx
    98e2:	48 8d 35 d8 58 00 00 	lea    0x58d8(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    98e9:	48 89 df             	mov    %rbx,%rdi
    98ec:	e8 7f a7 ff ff       	call   4070 <buf_put>
    98f1:	eb ca                	jmp    98bd <fwp_write+0x33d>
    98f3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    98f8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    98fc:	85 f6                	test   %esi,%esi
    98fe:	0f 84 fc 07 00 00    	je     a100 <fwp_write+0xb80>
    9904:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    990b:	00 
    990c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9913:	00 00 
    9915:	0f 85 3a 01 00 00    	jne    9a55 <fwp_write+0x4d5>
    991b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    991f:	4c 89 ea             	mov    %r13,%rdx
    9922:	e9 6c fe ff ff       	jmp    9793 <fwp_write+0x213>
    9927:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    992e:	00 00 
    9930:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    9935:	ba 01 00 00 00       	mov    $0x1,%edx
    993a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    993f:	48 89 ee             	mov    %rbp,%rsi
    9942:	e8 29 a7 ff ff       	call   4070 <buf_put>
    9947:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    994c:	4c 89 e7             	mov    %r12,%rdi
    994f:	e8 fc 9a ff ff       	call   3450 <strlen@plt>
    9954:	4c 89 e6             	mov    %r12,%rsi
    9957:	48 89 df             	mov    %rbx,%rdi
    995a:	48 89 c2             	mov    %rax,%rdx
    995d:	e8 0e a7 ff ff       	call   4070 <buf_put>
    9962:	ba 01 00 00 00       	mov    $0x1,%edx
    9967:	48 89 ee             	mov    %rbp,%rsi
    996a:	48 89 df             	mov    %rbx,%rdi
    996d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9972:	e8 f9 a6 ff ff       	call   4070 <buf_put>
    9977:	e9 9a fc ff ff       	jmp    9616 <fwp_write+0x96>
    997c:	0f 1f 40 00          	nopl   0x0(%rax)
    9980:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    9985:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    9989:	0f 8a 8e 0b 00 00    	jp     a51d <fwp_write+0xf9d>
    998f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9993:	66 0f 54 05 75 61 00 	andpd  0x6175(%rip),%xmm0        # fb10 <msg.4+0x90>
    999a:	00 
    999b:	bd 01 00 00 00       	mov    $0x1,%ebp
    99a0:	66 0f 2e 05 a0 61 00 	ucomisd 0x61a0(%rip),%xmm0        # fb48 <msg.4+0xc8>
    99a7:	00 
    99a8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    99af:	00 
    99b0:	0f 87 b2 09 00 00    	ja     a368 <fwp_write+0xde8>
    99b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    99bd:	00 00 00 
    99c0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    99c4:	89 ee                	mov    %ebp,%esi
    99c6:	4c 89 e7             	mov    %r12,%rdi
    99c9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    99ce:	e8 ed aa ff ff       	call   44c0 <fwp_format_g.constprop.0>
    99d3:	31 f6                	xor    %esi,%esi
    99d5:	4c 89 e7             	mov    %r12,%rdi
    99d8:	e8 33 9a ff ff       	call   3410 <strtod@plt>
    99dd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    99e2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    99e6:	7a 06                	jp     99ee <fwp_write+0x46e>
    99e8:	0f 84 e9 01 00 00    	je     9bd7 <fwp_write+0x657>
    99ee:	83 c5 01             	add    $0x1,%ebp
    99f1:	83 fd 12             	cmp    $0x12,%ebp
    99f4:	75 ca                	jne    99c0 <fwp_write+0x440>
    99f6:	be 11 00 00 00       	mov    $0x11,%esi
    99fb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    99ff:	4c 89 e7             	mov    %r12,%rdi
    9a02:	e8 b9 aa ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9a07:	e9 cb 01 00 00       	jmp    9bd7 <fwp_write+0x657>
    9a0c:	0f 1f 40 00          	nopl   0x0(%rax)
    9a10:	48 83 fd 01          	cmp    $0x1,%rbp
    9a14:	0f 84 e6 08 00 00    	je     a300 <fwp_write+0xd80>
    9a1a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    9a1e:	b8 02 00 00 00       	mov    $0x2,%eax
    9a23:	ba 01 00 00 00       	mov    $0x1,%edx
    9a28:	48 0f 44 d0          	cmove  %rax,%rdx
    9a2c:	48 8d 35 37 57 00 00 	lea    0x5737(%rip),%rsi        # f16a <_IO_stdin_used+0x16a>
    9a33:	48 8d 05 35 57 00 00 	lea    0x5735(%rip),%rax        # f16f <_IO_stdin_used+0x16f>
    9a3a:	48 0f 44 f0          	cmove  %rax,%rsi
    9a3e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9a45:	00 
    9a46:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9a4d:	00 00 
    9a4f:	0f 84 3e fd ff ff    	je     9793 <fwp_write+0x213>
    9a55:	e8 06 9a ff ff       	call   3460 <__stack_chk_fail@plt>
    9a5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9a60:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    9a65:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    9a6a:	e8 41 a5 ff ff       	call   3fb0 <buf_grow>
    9a6f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    9a73:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    9a79:	4c 03 0b             	add    (%rbx),%r9
    9a7c:	66 45 89 11          	mov    %r10w,(%r9)
    9a80:	45 85 e4             	test   %r12d,%r12d
    9a83:	0f 8e 07 05 00 00    	jle    9f90 <fwp_write+0xa10>
    9a89:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    9a90:	55 55 55 
    9a93:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    9a98:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    9a9f:	aa aa aa 
    9aa2:	49 83 c1 01          	add    $0x1,%r9
    9aa6:	eb 45                	jmp    9aed <fwp_write+0x56d>
    9aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9aaf:	00 
    9ab0:	be 01 00 00 00       	mov    $0x1,%esi
    9ab5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    9aba:	88 07                	mov    %al,(%rdi)
    9abc:	48 89 e8             	mov    %rbp,%rax
    9abf:	49 f7 e8             	imul   %r8
    9ac2:	48 89 e8             	mov    %rbp,%rax
    9ac5:	48 c1 f8 3f          	sar    $0x3f,%rax
    9ac9:	48 29 c2             	sub    %rax,%rdx
    9acc:	48 85 c9             	test   %rcx,%rcx
    9acf:	0f 95 c0             	setne  %al
    9ad2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    9ad6:	48 83 ef 01          	sub    $0x1,%rdi
    9ada:	48 21 c5             	and    %rax,%rbp
    9add:	48 29 ea             	sub    %rbp,%rdx
    9ae0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    9ae4:	49 39 f9             	cmp    %rdi,%r9
    9ae7:	0f 84 a3 04 00 00    	je     9f90 <fwp_write+0xa10>
    9aed:	48 89 e8             	mov    %rbp,%rax
    9af0:	49 f7 e8             	imul   %r8
    9af3:	48 89 e8             	mov    %rbp,%rax
    9af6:	48 c1 f8 3f          	sar    $0x3f,%rax
    9afa:	48 89 d1             	mov    %rdx,%rcx
    9afd:	48 29 c1             	sub    %rax,%rcx
    9b00:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    9b04:	48 89 e9             	mov    %rbp,%rcx
    9b07:	48 29 c1             	sub    %rax,%rcx
    9b0a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    9b0e:	49 f7 e2             	mul    %r10
    9b11:	b8 30 00 00 00       	mov    $0x30,%eax
    9b16:	48 89 d6             	mov    %rdx,%rsi
    9b19:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    9b1d:	48 d1 ee             	shr    $1,%rsi
    9b20:	48 01 f2             	add    %rsi,%rdx
    9b23:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    9b27:	48 29 d6             	sub    %rdx,%rsi
    9b2a:	74 8e                	je     9aba <fwp_write+0x53a>
    9b2c:	48 83 fe 01          	cmp    $0x1,%rsi
    9b30:	0f 85 7a ff ff ff    	jne    9ab0 <fwp_write+0x530>
    9b36:	31 f6                	xor    %esi,%esi
    9b38:	b8 2b 00 00 00       	mov    $0x2b,%eax
    9b3d:	e9 78 ff ff ff       	jmp    9aba <fwp_write+0x53a>
    9b42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9b48:	66 0f 6e cd          	movd   %ebp,%xmm1
    9b4c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    9b4f:	0f 8a c8 09 00 00    	jp     a51d <fwp_write+0xf9d>
    9b55:	0f 28 c1             	movaps %xmm1,%xmm0
    9b58:	0f 54 05 a1 5f 00 00 	andps  0x5fa1(%rip),%xmm0        # fb00 <msg.4+0x80>
    9b5f:	0f 2e 05 9e 54 00 00 	ucomiss 0x549e(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    9b66:	0f 87 24 08 00 00    	ja     a390 <fwp_write+0xe10>
    9b6c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9b70:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    9b76:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9b7d:	00 
    9b7e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    9b82:	66 49 0f 7e d7       	movq   %xmm2,%r15
    9b87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9b8e:	00 00 
    9b90:	44 89 ee             	mov    %r13d,%esi
    9b93:	66 49 0f 6e c7       	movq   %r15,%xmm0
    9b98:	4c 89 e7             	mov    %r12,%rdi
    9b9b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    9ba0:	e8 1b a9 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9ba5:	31 f6                	xor    %esi,%esi
    9ba7:	4c 89 e7             	mov    %r12,%rdi
    9baa:	e8 01 99 ff ff       	call   34b0 <strtof@plt>
    9baf:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    9bb4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    9bb7:	7a 02                	jp     9bbb <fwp_write+0x63b>
    9bb9:	74 1c                	je     9bd7 <fwp_write+0x657>
    9bbb:	41 83 c5 01          	add    $0x1,%r13d
    9bbf:	41 83 fd 0a          	cmp    $0xa,%r13d
    9bc3:	75 cb                	jne    9b90 <fwp_write+0x610>
    9bc5:	be 09 00 00 00       	mov    $0x9,%esi
    9bca:	66 49 0f 6e c7       	movq   %r15,%xmm0
    9bcf:	4c 89 e7             	mov    %r12,%rdi
    9bd2:	e8 e9 a8 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9bd7:	4c 89 e7             	mov    %r12,%rdi
    9bda:	e8 51 a5 ff ff       	call   4130 <fwp_finish_float>
    9bdf:	e9 1c fa ff ff       	jmp    9600 <fwp_write+0x80>
    9be4:	0f 1f 40 00          	nopl   0x0(%rax)
    9be8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    9bec:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    9bf0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    9bf7:	00 
    9bf8:	48 89 ef             	mov    %rbp,%rdi
    9bfb:	e8 40 9e ff ff       	call   3a40 <fwp_fmt_u128>
    9c00:	48 89 ef             	mov    %rbp,%rdi
    9c03:	e8 48 98 ff ff       	call   3450 <strlen@plt>
    9c08:	48 89 ee             	mov    %rbp,%rsi
    9c0b:	48 89 df             	mov    %rbx,%rdi
    9c0e:	48 89 c2             	mov    %rax,%rdx
    9c11:	e8 5a a4 ff ff       	call   4070 <buf_put>
    9c16:	e9 fb f9 ff ff       	jmp    9616 <fwp_write+0x96>
    9c1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9c20:	ba 06 00 00 00       	mov    $0x6,%edx
    9c25:	48 8d 35 98 55 00 00 	lea    0x5598(%rip),%rsi        # f1c4 <_IO_stdin_used+0x1c4>
    9c2c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    9c32:	e8 39 a4 ff ff       	call   4070 <buf_put>
    9c37:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    9c3e:	ff ff 7f 
    9c41:	48 23 55 00          	and    0x0(%rbp),%rdx
    9c45:	0f 84 86 02 00 00    	je     9ed1 <fwp_write+0x951>
    9c4b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9c50:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9c54:	48 85 d2             	test   %rdx,%rdx
    9c57:	0f 84 ae 00 00 00    	je     9d0b <fwp_write+0x78b>
    9c5d:	8b 0a                	mov    (%rdx),%ecx
    9c5f:	83 f9 1c             	cmp    $0x1c,%ecx
    9c62:	0f 84 58 06 00 00    	je     a2c0 <fwp_write+0xd40>
    9c68:	83 f9 1b             	cmp    $0x1b,%ecx
    9c6b:	0f 87 9a 00 00 00    	ja     9d0b <fwp_write+0x78b>
    9c71:	be 01 00 00 00       	mov    $0x1,%esi
    9c76:	48 d3 e6             	shl    %cl,%rsi
    9c79:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    9c7f:	0f 85 4b 04 00 00    	jne    a0d0 <fwp_write+0xb50>
    9c85:	f7 c6 84 04 00 00    	test   $0x484,%esi
    9c8b:	0f 85 0f 04 00 00    	jne    a0a0 <fwp_write+0xb20>
    9c91:	83 e6 21             	and    $0x21,%esi
    9c94:	74 75                	je     9d0b <fwp_write+0x78b>
    9c96:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    9c9b:	48 85 ff             	test   %rdi,%rdi
    9c9e:	79 07                	jns    9ca7 <fwp_write+0x727>
    9ca0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    9ca4:	4c 01 ee             	add    %r13,%rsi
    9ca7:	48 0f be 3e          	movsbq (%rsi),%rdi
    9cab:	85 c9                	test   %ecx,%ecx
    9cad:	40 0f b6 f7          	movzbl %dil,%esi
    9cb1:	48 0f 44 f7          	cmove  %rdi,%rsi
    9cb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9cbc:	00 00 00 00 
    9cc0:	31 c9                	xor    %ecx,%ecx
    9cc2:	48 89 df             	mov    %rbx,%rdi
    9cc5:	49 83 c5 01          	add    $0x1,%r13
    9cc9:	e8 b2 f8 ff ff       	call   9580 <fwp_write>
    9cce:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    9cd5:	ff ff 7f 
    9cd8:	48 23 55 00          	and    0x0(%rbp),%rdx
    9cdc:	49 39 d5             	cmp    %rdx,%r13
    9cdf:	0f 83 ec 01 00 00    	jae    9ed1 <fwp_write+0x951>
    9ce5:	ba 02 00 00 00       	mov    $0x2,%edx
    9cea:	48 89 df             	mov    %rbx,%rdi
    9ced:	48 8d 35 cd 54 00 00 	lea    0x54cd(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    9cf4:	e8 77 a3 ff ff       	call   4070 <buf_put>
    9cf9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9cfe:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9d02:	48 85 d2             	test   %rdx,%rdx
    9d05:	0f 85 52 ff ff ff    	jne    9c5d <fwp_write+0x6dd>
    9d0b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    9d10:	48 85 ff             	test   %rdi,%rdi
    9d13:	0f 88 cf 05 00 00    	js     a2e8 <fwp_write+0xd68>
    9d19:	48 8b 31             	mov    (%rcx),%rsi
    9d1c:	eb a2                	jmp    9cc0 <fwp_write+0x740>
    9d1e:	66 90                	xchg   %ax,%ax
    9d20:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9d27:	00 
    9d28:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9d2f:	00 00 
    9d31:	0f 85 1e fd ff ff    	jne    9a55 <fwp_write+0x4d5>
    9d37:	ba 08 00 00 00       	mov    $0x8,%edx
    9d3c:	48 8d 35 4e 54 00 00 	lea    0x544e(%rip),%rsi        # f191 <_IO_stdin_used+0x191>
    9d43:	e9 4b fa ff ff       	jmp    9793 <fwp_write+0x213>
    9d48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9d4f:	00 
    9d50:	89 e8                	mov    %ebp,%eax
    9d52:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    9d59:	76 03                	jbe    9d5e <fwp_write+0x7de>
    9d5b:	8b 45 00             	mov    0x0(%rbp),%eax
    9d5e:	41 89 c6             	mov    %eax,%r14d
    9d61:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9d66:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    9d6b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    9d6f:	4c 89 ef             	mov    %r13,%rdi
    9d72:	e8 d9 96 ff ff       	call   3450 <strlen@plt>
    9d77:	4c 89 ee             	mov    %r13,%rsi
    9d7a:	48 89 df             	mov    %rbx,%rdi
    9d7d:	48 89 c2             	mov    %rax,%rdx
    9d80:	e8 eb a2 ff ff       	call   4070 <buf_put>
    9d85:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    9d8a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    9d8e:	85 f6                	test   %esi,%esi
    9d90:	0f 8e 80 f8 ff ff    	jle    9616 <fwp_write+0x96>
    9d96:	45 31 ed             	xor    %r13d,%r13d
    9d99:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9d9e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    9da3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9da8:	ba 01 00 00 00       	mov    $0x1,%edx
    9dad:	4c 89 fe             	mov    %r15,%rsi
    9db0:	48 89 04 24          	mov    %rax,(%rsp)
    9db4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    9db9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    9dbd:	48 89 df             	mov    %rbx,%rdi
    9dc0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    9dc4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9dc9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    9dce:	e8 9d a2 ff ff       	call   4070 <buf_put>
    9dd3:	41 8b 06             	mov    (%r14),%eax
    9dd6:	83 f8 0e             	cmp    $0xe,%eax
    9dd9:	0f 84 71 02 00 00    	je     a050 <fwp_write+0xad0>
    9ddf:	83 f8 10             	cmp    $0x10,%eax
    9de2:	0f 84 38 02 00 00    	je     a020 <fwp_write+0xaa0>
    9de8:	83 f8 0a             	cmp    $0xa,%eax
    9deb:	0f 84 7f 04 00 00    	je     a270 <fwp_write+0xcf0>
    9df1:	0f 8f f9 00 00 00    	jg     9ef0 <fwp_write+0x970>
    9df7:	83 f8 03             	cmp    $0x3,%eax
    9dfa:	0f 8f 50 04 00 00    	jg     a250 <fwp_write+0xcd0>
    9e00:	85 c0                	test   %eax,%eax
    9e02:	78 10                	js     9e14 <fwp_write+0x894>
    9e04:	48 8b 04 24          	mov    (%rsp),%rax
    9e08:	48 c1 e8 3f          	shr    $0x3f,%rax
    9e0c:	85 c0                	test   %eax,%eax
    9e0e:	0f 85 f9 00 00 00    	jne    9f0d <fwp_write+0x98d>
    9e14:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9e19:	48 8b 34 24          	mov    (%rsp),%rsi
    9e1d:	31 c9                	xor    %ecx,%ecx
    9e1f:	48 89 df             	mov    %rbx,%rdi
    9e22:	e8 59 f7 ff ff       	call   9580 <fwp_write>
    9e27:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    9e2c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9e31:	49 83 c5 01          	add    $0x1,%r13
    9e35:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    9e39:	0f 8f 5f ff ff ff    	jg     9d9e <fwp_write+0x81e>
    9e3f:	e9 d2 f7 ff ff       	jmp    9616 <fwp_write+0x96>
    9e44:	0f 1f 40 00          	nopl   0x0(%rax)
    9e48:	ba 06 00 00 00       	mov    $0x6,%edx
    9e4d:	48 8d 35 63 53 00 00 	lea    0x5363(%rip),%rsi        # f1b7 <_IO_stdin_used+0x1b7>
    9e54:	45 31 ed             	xor    %r13d,%r13d
    9e57:	e8 14 a2 ff ff       	call   4070 <buf_put>
    9e5c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9e61:	75 19                	jne    9e7c <fwp_write+0x8fc>
    9e63:	eb 6c                	jmp    9ed1 <fwp_write+0x951>
    9e65:	0f 1f 00             	nopl   (%rax)
    9e68:	ba 02 00 00 00       	mov    $0x2,%edx
    9e6d:	48 8d 35 4d 53 00 00 	lea    0x534d(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    9e74:	48 89 df             	mov    %rbx,%rdi
    9e77:	e8 f4 a1 ff ff       	call   4070 <buf_put>
    9e7c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    9e82:	b9 00 02 00 00       	mov    $0x200,%ecx
    9e87:	31 c0                	xor    %eax,%eax
    9e89:	49 83 c5 01          	add    $0x1,%r13
    9e8d:	4c 8d 05 2a 53 00 00 	lea    0x532a(%rip),%r8        # f1be <_IO_stdin_used+0x1be>
    9e94:	ba 02 00 00 00       	mov    $0x2,%edx
    9e99:	be 00 02 00 00       	mov    $0x200,%esi
    9e9e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9ea5:	00 
    9ea6:	e8 05 95 ff ff       	call   33b0 <__snprintf_chk@plt>
    9eab:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9eb2:	00 
    9eb3:	e8 98 95 ff ff       	call   3450 <strlen@plt>
    9eb8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9ebf:	00 
    9ec0:	48 89 df             	mov    %rbx,%rdi
    9ec3:	48 89 c2             	mov    %rax,%rdx
    9ec6:	e8 a5 a1 ff ff       	call   4070 <buf_put>
    9ecb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9ecf:	72 97                	jb     9e68 <fwp_write+0x8e8>
    9ed1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9ed6:	ba 01 00 00 00       	mov    $0x1,%edx
    9edb:	48 89 df             	mov    %rbx,%rdi
    9ede:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9ee3:	e8 88 a1 ff ff       	call   4070 <buf_put>
    9ee8:	e9 29 f7 ff ff       	jmp    9616 <fwp_write+0x96>
    9eed:	0f 1f 00             	nopl   (%rax)
    9ef0:	83 f8 0b             	cmp    $0xb,%eax
    9ef3:	0f 85 1b ff ff ff    	jne    9e14 <fwp_write+0x894>
    9ef9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    9efe:	66 0f 50 c3          	movmskpd %xmm3,%eax
    9f02:	83 e0 01             	and    $0x1,%eax
    9f05:	85 c0                	test   %eax,%eax
    9f07:	0f 84 07 ff ff ff    	je     9e14 <fwp_write+0x894>
    9f0d:	4c 89 fe             	mov    %r15,%rsi
    9f10:	48 89 df             	mov    %rbx,%rdi
    9f13:	ba 01 00 00 00       	mov    $0x1,%edx
    9f18:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9f1d:	e8 4e a1 ff ff       	call   4070 <buf_put>
    9f22:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9f27:	48 8b 34 24          	mov    (%rsp),%rsi
    9f2b:	31 c9                	xor    %ecx,%ecx
    9f2d:	48 89 df             	mov    %rbx,%rdi
    9f30:	e8 4b f6 ff ff       	call   9580 <fwp_write>
    9f35:	ba 01 00 00 00       	mov    $0x1,%edx
    9f3a:	4c 89 fe             	mov    %r15,%rsi
    9f3d:	48 89 df             	mov    %rbx,%rdi
    9f40:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    9f45:	e8 26 a1 ff ff       	call   4070 <buf_put>
    9f4a:	e9 d8 fe ff ff       	jmp    9e27 <fwp_write+0x8a7>
    9f4f:	90                   	nop
    9f50:	ba 01 00 00 00       	mov    $0x1,%edx
    9f55:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9f5a:	48 89 df             	mov    %rbx,%rdi
    9f5d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9f62:	e8 09 a1 ff ff       	call   4070 <buf_put>
    9f67:	e9 aa f6 ff ff       	jmp    9616 <fwp_write+0x96>
    9f6c:	0f 1f 40 00          	nopl   0x0(%rax)
    9f70:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9f75:	ba 01 00 00 00       	mov    $0x1,%edx
    9f7a:	48 89 df             	mov    %rbx,%rdi
    9f7d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    9f82:	e8 e9 a0 ff ff       	call   4070 <buf_put>
    9f87:	e9 8a f6 ff ff       	jmp    9616 <fwp_write+0x96>
    9f8c:	0f 1f 40 00          	nopl   0x0(%rax)
    9f90:	48 8b 43 08          	mov    0x8(%rbx),%rax
    9f94:	48 8b 13             	mov    (%rbx),%rdx
    9f97:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    9f9c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    9fa0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    9fa4:	e9 6d f6 ff ff       	jmp    9616 <fwp_write+0x96>
    9fa9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9fb0:	ba 02 00 00 00       	mov    $0x2,%edx
    9fb5:	48 8d 35 05 52 00 00 	lea    0x5205(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    9fbc:	48 89 df             	mov    %rbx,%rdi
    9fbf:	e8 ac a0 ff ff       	call   4070 <buf_put>
    9fc4:	e9 72 f8 ff ff       	jmp    983b <fwp_write+0x2bb>
    9fc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9fd0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9fd5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    9fda:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    9fde:	48 89 f7             	mov    %rsi,%rdi
    9fe1:	48 89 34 24          	mov    %rsi,(%rsp)
    9fe5:	e8 66 94 ff ff       	call   3450 <strlen@plt>
    9fea:	48 8b 34 24          	mov    (%rsp),%rsi
    9fee:	48 89 df             	mov    %rbx,%rdi
    9ff1:	48 89 c2             	mov    %rax,%rdx
    9ff4:	e8 77 a0 ff ff       	call   4070 <buf_put>
    9ff9:	ba 03 00 00 00       	mov    $0x3,%edx
    9ffe:	48 8d 35 df 51 00 00 	lea    0x51df(%rip),%rsi        # f1e4 <_IO_stdin_used+0x1e4>
    a005:	48 89 df             	mov    %rbx,%rdi
    a008:	e8 63 a0 ff ff       	call   4070 <buf_put>
    a00d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a012:	e9 35 f8 ff ff       	jmp    984c <fwp_write+0x2cc>
    a017:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a01e:	00 00 
    a020:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a025:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a029:	48 85 ff             	test   %rdi,%rdi
    a02c:	0f 84 e2 fd ff ff    	je     9e14 <fwp_write+0x894>
    a032:	48 8d 35 95 51 00 00 	lea    0x5195(%rip),%rsi        # f1ce <_IO_stdin_used+0x1ce>
    a039:	e8 f2 94 ff ff       	call   3530 <strcmp@plt>
    a03e:	85 c0                	test   %eax,%eax
    a040:	0f 95 c0             	setne  %al
    a043:	0f b6 c0             	movzbl %al,%eax
    a046:	e9 c1 fd ff ff       	jmp    9e0c <fwp_write+0x88c>
    a04b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a050:	31 c0                	xor    %eax,%eax
    a052:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a059:	00 
    a05a:	0f 97 c0             	seta   %al
    a05d:	e9 aa fd ff ff       	jmp    9e0c <fwp_write+0x88c>
    a062:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a068:	48 89 df             	mov    %rbx,%rdi
    a06b:	ba 02 00 00 00       	mov    $0x2,%edx
    a070:	48 8d 35 54 51 00 00 	lea    0x5154(%rip),%rsi        # f1cb <_IO_stdin_used+0x1cb>
    a077:	e8 f4 9f ff ff       	call   4070 <buf_put>
    a07c:	4c 89 e8             	mov    %r13,%rax
    a07f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a084:	31 c9                	xor    %ecx,%ecx
    a086:	48 c1 e0 04          	shl    $0x4,%rax
    a08a:	48 89 df             	mov    %rbx,%rdi
    a08d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a092:	e8 e9 f4 ff ff       	call   9580 <fwp_write>
    a097:	e9 5e f6 ff ff       	jmp    96fa <fwp_write+0x17a>
    a09c:	0f 1f 40 00          	nopl   0x0(%rax)
    a0a0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a0a5:	48 85 ff             	test   %rdi,%rdi
    a0a8:	79 0c                	jns    a0b6 <fwp_write+0xb36>
    a0aa:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a0b1:	00 
    a0b2:	48 03 75 10          	add    0x10(%rbp),%rsi
    a0b6:	48 63 3e             	movslq (%rsi),%rdi
    a0b9:	83 f9 02             	cmp    $0x2,%ecx
    a0bc:	89 fe                	mov    %edi,%esi
    a0be:	48 0f 44 f7          	cmove  %rdi,%rsi
    a0c2:	e9 f9 fb ff ff       	jmp    9cc0 <fwp_write+0x740>
    a0c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a0ce:	00 00 
    a0d0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a0d5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a0da:	48 85 ff             	test   %rdi,%rdi
    a0dd:	0f 88 0f 03 00 00    	js     a3f2 <fwp_write+0xe72>
    a0e3:	49 0f bf 38          	movswq (%r8),%rdi
    a0e7:	83 f9 01             	cmp    $0x1,%ecx
    a0ea:	0f b7 f7             	movzwl %di,%esi
    a0ed:	48 0f 44 f7          	cmove  %rdi,%rsi
    a0f1:	e9 ca fb ff ff       	jmp    9cc0 <fwp_write+0x740>
    a0f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a0fd:	00 00 00 
    a100:	ba 01 00 00 00       	mov    $0x1,%edx
    a105:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a10a:	48 83 c5 08          	add    $0x8,%rbp
    a10e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a113:	e8 58 9f ff ff       	call   4070 <buf_put>
    a118:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a11d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a122:	4d 85 ed             	test   %r13,%r13
    a125:	75 46                	jne    a16d <fwp_write+0xbed>
    a127:	e9 04 01 00 00       	jmp    a230 <fwp_write+0xcb0>
    a12c:	0f 1f 40 00          	nopl   0x0(%rax)
    a130:	41 80 f9 09          	cmp    $0x9,%r9b
    a134:	0f 84 d6 00 00 00    	je     a210 <fwp_write+0xc90>
    a13a:	41 80 f9 0a          	cmp    $0xa,%r9b
    a13e:	0f 85 9c 00 00 00    	jne    a1e0 <fwp_write+0xc60>
    a144:	ba 02 00 00 00       	mov    $0x2,%edx
    a149:	48 8d 35 57 50 00 00 	lea    0x5057(%rip),%rsi        # f1a7 <_IO_stdin_used+0x1a7>
    a150:	48 89 df             	mov    %rbx,%rdi
    a153:	e8 18 9f ff ff       	call   4070 <buf_put>
    a158:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a15f:	00 
    a160:	48 83 c5 01          	add    $0x1,%rbp
    a164:	49 39 ec             	cmp    %rbp,%r12
    a167:	0f 84 c3 00 00 00    	je     a230 <fwp_write+0xcb0>
    a16d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a172:	41 80 f9 0d          	cmp    $0xd,%r9b
    a176:	74 28                	je     a1a0 <fwp_write+0xc20>
    a178:	7e b6                	jle    a130 <fwp_write+0xbb0>
    a17a:	41 80 f9 22          	cmp    $0x22,%r9b
    a17e:	74 40                	je     a1c0 <fwp_write+0xc40>
    a180:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a184:	75 5a                	jne    a1e0 <fwp_write+0xc60>
    a186:	ba 02 00 00 00       	mov    $0x2,%edx
    a18b:	48 8d 35 12 50 00 00 	lea    0x5012(%rip),%rsi        # f1a4 <_IO_stdin_used+0x1a4>
    a192:	48 89 df             	mov    %rbx,%rdi
    a195:	e8 d6 9e ff ff       	call   4070 <buf_put>
    a19a:	eb c4                	jmp    a160 <fwp_write+0xbe0>
    a19c:	0f 1f 40 00          	nopl   0x0(%rax)
    a1a0:	ba 02 00 00 00       	mov    $0x2,%edx
    a1a5:	48 8d 35 01 50 00 00 	lea    0x5001(%rip),%rsi        # f1ad <_IO_stdin_used+0x1ad>
    a1ac:	48 89 df             	mov    %rbx,%rdi
    a1af:	e8 bc 9e ff ff       	call   4070 <buf_put>
    a1b4:	eb aa                	jmp    a160 <fwp_write+0xbe0>
    a1b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a1bd:	00 00 00 
    a1c0:	ba 02 00 00 00       	mov    $0x2,%edx
    a1c5:	48 8d 35 d5 4f 00 00 	lea    0x4fd5(%rip),%rsi        # f1a1 <_IO_stdin_used+0x1a1>
    a1cc:	48 89 df             	mov    %rbx,%rdi
    a1cf:	e8 9c 9e ff ff       	call   4070 <buf_put>
    a1d4:	eb 8a                	jmp    a160 <fwp_write+0xbe0>
    a1d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a1dd:	00 00 00 
    a1e0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a1e4:	0f 86 2e 01 00 00    	jbe    a318 <fwp_write+0xd98>
    a1ea:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a1ee:	0f 84 24 01 00 00    	je     a318 <fwp_write+0xd98>
    a1f4:	ba 01 00 00 00       	mov    $0x1,%edx
    a1f9:	4c 89 fe             	mov    %r15,%rsi
    a1fc:	48 89 df             	mov    %rbx,%rdi
    a1ff:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a204:	e8 67 9e ff ff       	call   4070 <buf_put>
    a209:	e9 52 ff ff ff       	jmp    a160 <fwp_write+0xbe0>
    a20e:	66 90                	xchg   %ax,%ax
    a210:	ba 02 00 00 00       	mov    $0x2,%edx
    a215:	48 8d 35 8e 4f 00 00 	lea    0x4f8e(%rip),%rsi        # f1aa <_IO_stdin_used+0x1aa>
    a21c:	48 89 df             	mov    %rbx,%rdi
    a21f:	e8 4c 9e ff ff       	call   4070 <buf_put>
    a224:	e9 37 ff ff ff       	jmp    a160 <fwp_write+0xbe0>
    a229:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a230:	ba 01 00 00 00       	mov    $0x1,%edx
    a235:	4c 89 fe             	mov    %r15,%rsi
    a238:	48 89 df             	mov    %rbx,%rdi
    a23b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a240:	e8 2b 9e ff ff       	call   4070 <buf_put>
    a245:	e9 cc f3 ff ff       	jmp    9616 <fwp_write+0x96>
    a24a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a250:	83 f8 04             	cmp    $0x4,%eax
    a253:	0f 85 bb fb ff ff    	jne    9e14 <fwp_write+0x894>
    a259:	48 8b 04 24          	mov    (%rsp),%rax
    a25d:	48 8b 40 08          	mov    0x8(%rax),%rax
    a261:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    a266:	48 c1 e8 3f          	shr    $0x3f,%rax
    a26a:	e9 96 fc ff ff       	jmp    9f05 <fwp_write+0x985>
    a26f:	90                   	nop
    a270:	8b 0c 24             	mov    (%rsp),%ecx
    a273:	31 c0                	xor    %eax,%eax
    a275:	85 c9                	test   %ecx,%ecx
    a277:	0f 98 c0             	sets   %al
    a27a:	e9 86 fc ff ff       	jmp    9f05 <fwp_write+0x985>
    a27f:	90                   	nop
    a280:	48 f7 d8             	neg    %rax
    a283:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    a28a:	00 
    a28b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    a292:	2d 
    a293:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a29a:	00 
    a29b:	48 83 d2 00          	adc    $0x0,%rdx
    a29f:	48 89 c6             	mov    %rax,%rsi
    a2a2:	48 f7 da             	neg    %rdx
    a2a5:	e8 96 97 ff ff       	call   3a40 <fwp_fmt_u128>
    a2aa:	e9 51 f3 ff ff       	jmp    9600 <fwp_write+0x80>
    a2af:	90                   	nop
    a2b0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    a2b5:	e9 c3 f5 ff ff       	jmp    987d <fwp_write+0x2fd>
    a2ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a2c0:	4c 89 e9             	mov    %r13,%rcx
    a2c3:	48 c1 e1 04          	shl    $0x4,%rcx
    a2c7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    a2cc:	48 85 ff             	test   %rdi,%rdi
    a2cf:	0f 89 eb f9 ff ff    	jns    9cc0 <fwp_write+0x740>
    a2d5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a2d9:	48 89 ce             	mov    %rcx,%rsi
    a2dc:	e9 df f9 ff ff       	jmp    9cc0 <fwp_write+0x740>
    a2e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a2e8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a2ef:	00 
    a2f0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a2f4:	e9 20 fa ff ff       	jmp    9d19 <fwp_write+0x799>
    a2f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a300:	ba 02 00 00 00       	mov    $0x2,%edx
    a305:	48 8d 35 60 4e 00 00 	lea    0x4e60(%rip),%rsi        # f16c <_IO_stdin_used+0x16c>
    a30c:	e9 2d f7 ff ff       	jmp    9a3e <fwp_write+0x4be>
    a311:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a318:	4c 8d 05 91 4e 00 00 	lea    0x4e91(%rip),%r8        # f1b0 <_IO_stdin_used+0x1b0>
    a31f:	b9 10 00 00 00       	mov    $0x10,%ecx
    a324:	31 c0                	xor    %eax,%eax
    a326:	ba 02 00 00 00       	mov    $0x2,%edx
    a32b:	be 10 00 00 00       	mov    $0x10,%esi
    a330:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a337:	00 
    a338:	e8 73 90 ff ff       	call   33b0 <__snprintf_chk@plt>
    a33d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a344:	00 
    a345:	e8 06 91 ff ff       	call   3450 <strlen@plt>
    a34a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a351:	00 
    a352:	48 89 df             	mov    %rbx,%rdi
    a355:	48 89 c2             	mov    %rax,%rdx
    a358:	e8 13 9d ff ff       	call   4070 <buf_put>
    a35d:	e9 fe fd ff ff       	jmp    a160 <fwp_write+0xbe0>
    a362:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a368:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a36c:	48 8d 35 f3 4d 00 00 	lea    0x4df3(%rip),%rsi        # f166 <_IO_stdin_used+0x166>
    a373:	48 8d 05 eb 4d 00 00 	lea    0x4deb(%rip),%rax        # f165 <_IO_stdin_used+0x165>
    a37a:	4c 89 e7             	mov    %r12,%rdi
    a37d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    a381:	48 0f 46 f0          	cmovbe %rax,%rsi
    a385:	e8 66 90 ff ff       	call   33f0 <strcpy@plt>
    a38a:	e9 71 f2 ff ff       	jmp    9600 <fwp_write+0x80>
    a38f:	90                   	nop
    a390:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a394:	48 8d 35 cb 4d 00 00 	lea    0x4dcb(%rip),%rsi        # f166 <_IO_stdin_used+0x166>
    a39b:	48 8d 05 c3 4d 00 00 	lea    0x4dc3(%rip),%rax        # f165 <_IO_stdin_used+0x165>
    a3a2:	0f 2f c8             	comiss %xmm0,%xmm1
    a3a5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a3ac:	00 
    a3ad:	4c 89 e7             	mov    %r12,%rdi
    a3b0:	48 0f 46 f0          	cmovbe %rax,%rsi
    a3b4:	e8 37 90 ff ff       	call   33f0 <strcpy@plt>
    a3b9:	e9 42 f2 ff ff       	jmp    9600 <fwp_write+0x80>
    a3be:	66 90                	xchg   %ax,%ax
    a3c0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    a3c5:	45 85 c0             	test   %r8d,%r8d
    a3c8:	75 34                	jne    a3fe <fwp_write+0xe7e>
    a3ca:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a3d1:	00 
    a3d2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a3d9:	00 00 
    a3db:	0f 85 74 f6 ff ff    	jne    9a55 <fwp_write+0x4d5>
    a3e1:	ba 02 00 00 00       	mov    $0x2,%edx
    a3e6:	48 8d 35 f4 4d 00 00 	lea    0x4df4(%rip),%rsi        # f1e1 <_IO_stdin_used+0x1e1>
    a3ed:	e9 a1 f3 ff ff       	jmp    9793 <fwp_write+0x213>
    a3f2:	48 03 75 10          	add    0x10(%rbp),%rsi
    a3f6:	49 89 f0             	mov    %rsi,%r8
    a3f9:	e9 e5 fc ff ff       	jmp    a0e3 <fwp_write+0xb63>
    a3fe:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    a403:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a408:	85 ff                	test   %edi,%edi
    a40a:	0f 84 fa f3 ff ff    	je     980a <fwp_write+0x28a>
    a410:	ba 01 00 00 00       	mov    $0x1,%edx
    a415:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a41a:	48 89 df             	mov    %rbx,%rdi
    a41d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a422:	e8 49 9c ff ff       	call   4070 <buf_put>
    a427:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    a42c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a431:	41 be 01 00 00 00    	mov    $0x1,%r14d
    a437:	85 c0                	test   %eax,%eax
    a439:	0f 8f f0 f3 ff ff    	jg     982f <fwp_write+0x2af>
    a43f:	e9 34 f4 ff ff       	jmp    9878 <fwp_write+0x2f8>
    a444:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a448:	49 89 c5             	mov    %rax,%r13
    a44b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a450:	49 89 c4             	mov    %rax,%r12
    a453:	49 c1 fd 3f          	sar    $0x3f,%r13
    a457:	4c 09 e8             	or     %r13,%rax
    a45a:	0f 84 a7 00 00 00    	je     a507 <fwp_write+0xf87>
    a460:	48 8d 2d b9 6f 00 00 	lea    0x6fb9(%rip),%rbp        # 11420 <units.1>
    a467:	4d 89 e7             	mov    %r12,%r15
    a46a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a46e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    a473:	4c 89 ff             	mov    %r15,%rdi
    a476:	4c 89 ee             	mov    %r13,%rsi
    a479:	44 89 0c 24          	mov    %r9d,(%rsp)
    a47d:	48 99                	cqto
    a47f:	48 89 d1             	mov    %rdx,%rcx
    a482:	48 89 c2             	mov    %rax,%rdx
    a485:	e8 96 41 00 00       	call   e620 <__divmodti4>
    a48a:	44 8b 0c 24          	mov    (%rsp),%r9d
    a48e:	48 89 c1             	mov    %rax,%rcx
    a491:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a496:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    a49b:	0f 84 94 00 00 00    	je     a535 <fwp_write+0xfb5>
    a4a1:	41 83 c1 01          	add    $0x1,%r9d
    a4a5:	48 83 c5 10          	add    $0x10,%rbp
    a4a9:	41 83 f9 05          	cmp    $0x5,%r9d
    a4ad:	75 bb                	jne    a46a <fwp_write+0xeea>
    a4af:	4d 85 ed             	test   %r13,%r13
    a4b2:	79 53                	jns    a507 <fwp_write+0xf87>
    a4b4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a4b9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a4be:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a4c3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a4c8:	48 99                	cqto
    a4ca:	48 f7 d8             	neg    %rax
    a4cd:	48 83 d2 00          	adc    $0x0,%rdx
    a4d1:	48 89 c6             	mov    %rax,%rsi
    a4d4:	48 f7 da             	neg    %rdx
    a4d7:	e8 64 95 ff ff       	call   3a40 <fwp_fmt_u128>
    a4dc:	49 89 e8             	mov    %rbp,%r8
    a4df:	ba 00 02 00 00       	mov    $0x200,%edx
    a4e4:	be 02 00 00 00       	mov    $0x2,%esi
    a4e9:	31 c0                	xor    %eax,%eax
    a4eb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a4f2:	00 
    a4f3:	48 8d 0d e2 4c 00 00 	lea    0x4ce2(%rip),%rcx        # f1dc <_IO_stdin_used+0x1dc>
    a4fa:	4c 89 e7             	mov    %r12,%rdi
    a4fd:	e8 de 91 ff ff       	call   36e0 <__sprintf_chk@plt>
    a502:	e9 f9 f0 ff ff       	jmp    9600 <fwp_write+0x80>
    a507:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a50c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a511:	31 d2                	xor    %edx,%edx
    a513:	48 89 ef             	mov    %rbp,%rdi
    a516:	e8 25 95 ff ff       	call   3a40 <fwp_fmt_u128>
    a51b:	eb bf                	jmp    a4dc <fwp_write+0xf5c>
    a51d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    a524:	4e 61 4e 00 
    a528:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a52f:	00 
    a530:	e9 cb f0 ff ff       	jmp    9600 <fwp_write+0x80>
    a535:	44 89 0c 24          	mov    %r9d,(%rsp)
    a539:	48 89 c8             	mov    %rcx,%rax
    a53c:	48 85 d2             	test   %rdx,%rdx
    a53f:	78 51                	js     a592 <fwp_write+0x1012>
    a541:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a546:	48 89 c6             	mov    %rax,%rsi
    a549:	48 89 ef             	mov    %rbp,%rdi
    a54c:	e8 ef 94 ff ff       	call   3a40 <fwp_fmt_u128>
    a551:	44 8b 0c 24          	mov    (%rsp),%r9d
    a555:	49 63 c1             	movslq %r9d,%rax
    a558:	49 89 e8             	mov    %rbp,%r8
    a55b:	ba 00 02 00 00       	mov    $0x200,%edx
    a560:	be 02 00 00 00       	mov    $0x2,%esi
    a565:	48 c1 e0 04          	shl    $0x4,%rax
    a569:	48 8d 3d b0 6e 00 00 	lea    0x6eb0(%rip),%rdi        # 11420 <units.1>
    a570:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a577:	00 
    a578:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    a57c:	48 8d 0d 54 4c 00 00 	lea    0x4c54(%rip),%rcx        # f1d7 <_IO_stdin_used+0x1d7>
    a583:	4c 89 e7             	mov    %r12,%rdi
    a586:	31 c0                	xor    %eax,%eax
    a588:	e8 53 91 ff ff       	call   36e0 <__sprintf_chk@plt>
    a58d:	e9 6e f0 ff ff       	jmp    9600 <fwp_write+0x80>
    a592:	48 f7 d8             	neg    %rax
    a595:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a59a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a59f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a5a4:	48 83 d2 00          	adc    $0x0,%rdx
    a5a8:	48 89 c6             	mov    %rax,%rsi
    a5ab:	48 f7 da             	neg    %rdx
    a5ae:	e8 8d 94 ff ff       	call   3a40 <fwp_fmt_u128>
    a5b3:	44 8b 0c 24          	mov    (%rsp),%r9d
    a5b7:	eb 9c                	jmp    a555 <fwp_write+0xfd5>
    a5b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000a5c0 <fwp_hof0.constprop.0>:
    a5c0:	55                   	push   %rbp
    a5c1:	48 89 e5             	mov    %rsp,%rbp
    a5c4:	41 57                	push   %r15
    a5c6:	41 56                	push   %r14
    a5c8:	41 55                	push   %r13
    a5ca:	41 54                	push   %r12
    a5cc:	53                   	push   %rbx
    a5cd:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    a5d4:	48 89 bd 58 ff ff ff 	mov    %rdi,-0xa8(%rbp)
    a5db:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    a5e2:	00 00 
    a5e4:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    a5e8:	31 c0                	xor    %eax,%eax
    a5ea:	48 85 f6             	test   %rsi,%rsi
    a5ed:	0f 84 86 06 00 00    	je     ac79 <fwp_hof0.constprop.0+0x6b9>
    a5f3:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
    a5f7:	49 89 f7             	mov    %rsi,%r15
    a5fa:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
    a601:	48 8d 35 78 91 01 00 	lea    0x19178(%rip),%rsi        # 23780 <fwp_heap>
    a608:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    a60f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    a616:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    a61d:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    a621:	48 c1 e2 10          	shl    $0x10,%rdx
    a625:	48 39 d0             	cmp    %rdx,%rax
    a628:	73 5d                	jae    a687 <fwp_hof0.constprop.0+0xc7>
    a62a:	48 89 c2             	mov    %rax,%rdx
    a62d:	48 c1 ea 10          	shr    $0x10,%rdx
    a631:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a635:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    a63c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a640:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a644:	48 85 ff             	test   %rdi,%rdi
    a647:	74 3e                	je     a687 <fwp_hof0.constprop.0+0xc7>
    a649:	0f b6 0a             	movzbl (%rdx),%ecx
    a64c:	80 f9 02             	cmp    $0x2,%cl
    a64f:	0f 84 cd 0a 00 00    	je     b122 <fwp_hof0.constprop.0+0xb62>
    a655:	80 f9 01             	cmp    $0x1,%cl
    a658:	75 2d                	jne    a687 <fwp_hof0.constprop.0+0xc7>
    a65a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a65d:	0f b7 c0             	movzwl %ax,%eax
    a660:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a663:	48 0f af c1          	imul   %rcx,%rax
    a667:	48 c1 e8 20          	shr    $0x20,%rax
    a66b:	48 39 d0             	cmp    %rdx,%rax
    a66e:	73 17                	jae    a687 <fwp_hof0.constprop.0+0xc7>
    a670:	48 01 c7             	add    %rax,%rdi
    a673:	0f b6 07             	movzbl (%rdi),%eax
    a676:	84 c0                	test   %al,%al
    a678:	74 0d                	je     a687 <fwp_hof0.constprop.0+0xc7>
    a67a:	3c fd                	cmp    $0xfd,%al
    a67c:	0f 87 7e 0b 00 00    	ja     b200 <fwp_hof0.constprop.0+0xc40>
    a682:	83 c0 01             	add    $0x1,%eax
    a685:	88 07                	mov    %al,(%rdi)
    a687:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    a68e:	4c 89 bd 50 ff ff ff 	mov    %r15,-0xb0(%rbp)
    a695:	48 c7 85 60 ff ff ff 	movq   $0xc7,-0xa0(%rbp)
    a69c:	c7 00 00 00 
    a6a0:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    a6a4:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    a6a8:	48 8b 15 29 ad 01 00 	mov    0x1ad29(%rip),%rdx        # 253d8 <fwp_fns>
    a6af:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
    a6b3:	48 8d 05 5e 89 00 00 	lea    0x895e(%rip),%rax        # 13018 <fc12>
    a6ba:	44 8b 20             	mov    (%rax),%r12d
    a6bd:	49 c1 e4 05          	shl    $0x5,%r12
    a6c1:	49 01 d4             	add    %rdx,%r12
    a6c4:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
    a6c9:	48 85 c9             	test   %rcx,%rcx
    a6cc:	0f 84 1d 0a 00 00    	je     b0ef <fwp_hof0.constprop.0+0xb2f>
    a6d2:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    a6d7:	0f 84 7b 08 00 00    	je     af58 <fwp_hof0.constprop.0+0x998>
    a6dd:	48 8d 3d 9c 90 01 00 	lea    0x1909c(%rip),%rdi        # 23780 <fwp_heap>
    a6e4:	48 8d 05 2d 89 00 00 	lea    0x892d(%rip),%rax        # 13018 <fc12>
    a6eb:	48 8b b7 d8 13 00 00 	mov    0x13d8(%rdi),%rsi
    a6f2:	48 2b 87 b0 13 00 00 	sub    0x13b0(%rdi),%rax
    a6f9:	48 89 f1             	mov    %rsi,%rcx
    a6fc:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
    a700:	48 c1 e1 10          	shl    $0x10,%rcx
    a704:	48 39 c8             	cmp    %rcx,%rax
    a707:	73 5f                	jae    a768 <fwp_hof0.constprop.0+0x1a8>
    a709:	48 89 c1             	mov    %rax,%rcx
    a70c:	48 c1 e9 10          	shr    $0x10,%rcx
    a710:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    a714:	48 8b 8f f8 13 00 00 	mov    0x13f8(%rdi),%rcx
    a71b:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    a71f:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    a723:	48 85 ff             	test   %rdi,%rdi
    a726:	74 40                	je     a768 <fwp_hof0.constprop.0+0x1a8>
    a728:	0f b6 31             	movzbl (%rcx),%esi
    a72b:	40 80 fe 02          	cmp    $0x2,%sil
    a72f:	0f 84 08 09 00 00    	je     b03d <fwp_hof0.constprop.0+0xa7d>
    a735:	40 80 fe 01          	cmp    $0x1,%sil
    a739:	75 2d                	jne    a768 <fwp_hof0.constprop.0+0x1a8>
    a73b:	8b 71 18             	mov    0x18(%rcx),%esi
    a73e:	0f b7 c0             	movzwl %ax,%eax
    a741:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a744:	48 0f af c6          	imul   %rsi,%rax
    a748:	48 c1 e8 20          	shr    $0x20,%rax
    a74c:	48 39 c8             	cmp    %rcx,%rax
    a74f:	73 17                	jae    a768 <fwp_hof0.constprop.0+0x1a8>
    a751:	48 01 c7             	add    %rax,%rdi
    a754:	0f b6 07             	movzbl (%rdi),%eax
    a757:	84 c0                	test   %al,%al
    a759:	74 0d                	je     a768 <fwp_hof0.constprop.0+0x1a8>
    a75b:	3c fd                	cmp    $0xfd,%al
    a75d:	0f 87 66 09 00 00    	ja     b0c9 <fwp_hof0.constprop.0+0xb09>
    a763:	83 c0 01             	add    $0x1,%eax
    a766:	88 07                	mov    %al,(%rdi)
    a768:	48 8d 05 a9 88 00 00 	lea    0x88a9(%rip),%rax        # 13018 <fc12>
    a76f:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    a776:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    a77a:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    a781:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    a785:	48 8d 05 8c 88 00 00 	lea    0x888c(%rip),%rax        # 13018 <fc12>
    a78c:	41 8b 0c 24          	mov    (%r12),%ecx
    a790:	2b 48 04             	sub    0x4(%rax),%ecx
    a793:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    a797:	44 8b 6d 94          	mov    -0x6c(%rbp),%r13d
    a79b:	89 4d 90             	mov    %ecx,-0x70(%rbp)
    a79e:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    a7a2:	49 89 c1             	mov    %rax,%r9
    a7a5:	8b 00                	mov    (%rax),%eax
    a7a7:	44 39 e9             	cmp    %r13d,%ecx
    a7aa:	44 0f 46 e9          	cmovbe %ecx,%r13d
    a7ae:	4d 89 cf             	mov    %r9,%r15
    a7b1:	48 c1 e0 05          	shl    $0x5,%rax
    a7b5:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    a7b9:	44 89 ad 7c ff ff ff 	mov    %r13d,-0x84(%rbp)
    a7c0:	4d 8b 50 18          	mov    0x18(%r8),%r10
    a7c4:	4d 85 d2             	test   %r10,%r10
    a7c7:	75 58                	jne    a821 <fwp_hof0.constprop.0+0x261>
    a7c9:	e9 f5 01 00 00       	jmp    a9c3 <fwp_hof0.constprop.0+0x403>
    a7ce:	66 90                	xchg   %ax,%ax
    a7d0:	45 85 ff             	test   %r15d,%r15d
    a7d3:	74 69                	je     a83e <fwp_hof0.constprop.0+0x27e>
    a7d5:	4c 89 e7             	mov    %r12,%rdi
    a7d8:	41 ff 12             	call   *(%r10)
    a7db:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    a7df:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
    a7e3:	e8 08 c3 ff ff       	call   6af0 <fwp_closure_drop>
    a7e8:	44 39 eb             	cmp    %r13d,%ebx
    a7eb:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    a7ef:	0f 84 53 07 00 00    	je     af48 <fwp_hof0.constprop.0+0x988>
    a7f5:	44 8b 00             	mov    (%rax),%r8d
    a7f8:	45 29 fe             	sub    %r15d,%r14d
    a7fb:	4d 8d 24 dc          	lea    (%r12,%rbx,8),%r12
    a7ff:	49 89 c1             	mov    %rax,%r9
    a802:	45 89 f5             	mov    %r14d,%r13d
    a805:	49 c1 e0 05          	shl    $0x5,%r8
    a809:	4c 03 05 c8 ab 01 00 	add    0x1abc8(%rip),%r8        # 253d8 <fwp_fns>
    a810:	4d 8b 50 18          	mov    0x18(%r8),%r10
    a814:	4d 85 d2             	test   %r10,%r10
    a817:	0f 84 a3 01 00 00    	je     a9c0 <fwp_hof0.constprop.0+0x400>
    a81d:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    a821:	41 8b 49 04          	mov    0x4(%r9),%ecx
    a825:	45 8b 38             	mov    (%r8),%r15d
    a828:	46 8d 34 29          	lea    (%rcx,%r13,1),%r14d
    a82c:	45 39 fe             	cmp    %r15d,%r14d
    a82f:	0f 82 6b 04 00 00    	jb     aca0 <fwp_hof0.constprop.0+0x6e0>
    a835:	44 89 fb             	mov    %r15d,%ebx
    a838:	29 cb                	sub    %ecx,%ebx
    a83a:	85 c9                	test   %ecx,%ecx
    a83c:	74 92                	je     a7d0 <fwp_hof0.constprop.0+0x210>
    a83e:	45 85 ff             	test   %r15d,%r15d
    a841:	b8 01 00 00 00       	mov    $0x1,%eax
    a846:	48 89 e6             	mov    %rsp,%rsi
    a849:	48 89 65 a0          	mov    %rsp,-0x60(%rbp)
    a84d:	41 0f 45 c7          	cmovne %r15d,%eax
    a851:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    a858:	00 
    a859:	48 c1 e8 04          	shr    $0x4,%rax
    a85d:	48 c1 e0 04          	shl    $0x4,%rax
    a861:	48 89 c7             	mov    %rax,%rdi
    a864:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    a86b:	48 29 fe             	sub    %rdi,%rsi
    a86e:	48 39 f4             	cmp    %rsi,%rsp
    a871:	74 15                	je     a888 <fwp_hof0.constprop.0+0x2c8>
    a873:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    a87a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    a881:	00 00 
    a883:	48 39 f4             	cmp    %rsi,%rsp
    a886:	75 eb                	jne    a873 <fwp_hof0.constprop.0+0x2b3>
    a888:	25 ff 0f 00 00       	and    $0xfff,%eax
    a88d:	48 29 c4             	sub    %rax,%rsp
    a890:	48 85 c0             	test   %rax,%rax
    a893:	74 06                	je     a89b <fwp_hof0.constprop.0+0x2db>
    a895:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    a89b:	89 cf                	mov    %ecx,%edi
    a89d:	49 89 e3             	mov    %rsp,%r11
    a8a0:	31 c0                	xor    %eax,%eax
    a8a2:	48 c1 e7 03          	shl    $0x3,%rdi
    a8a6:	85 c9                	test   %ecx,%ecx
    a8a8:	74 28                	je     a8d2 <fwp_hof0.constprop.0+0x312>
    a8aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a8b1:	00 00 00 00 
    a8b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a8bc:	00 00 00 00 
    a8c0:	49 8b 54 01 08       	mov    0x8(%r9,%rax,1),%rdx
    a8c5:	49 89 14 03          	mov    %rdx,(%r11,%rax,1)
    a8c9:	48 83 c0 08          	add    $0x8,%rax
    a8cd:	48 39 c7             	cmp    %rax,%rdi
    a8d0:	75 ee                	jne    a8c0 <fwp_hof0.constprop.0+0x300>
    a8d2:	85 db                	test   %ebx,%ebx
    a8d4:	74 1f                	je     a8f5 <fwp_hof0.constprop.0+0x335>
    a8d6:	89 de                	mov    %ebx,%esi
    a8d8:	4c 89 e0             	mov    %r12,%rax
    a8db:	49 8d 3c f4          	lea    (%r12,%rsi,8),%rdi
    a8df:	90                   	nop
    a8e0:	48 8b 30             	mov    (%rax),%rsi
    a8e3:	89 ca                	mov    %ecx,%edx
    a8e5:	48 83 c0 08          	add    $0x8,%rax
    a8e9:	83 c1 01             	add    $0x1,%ecx
    a8ec:	49 89 34 d3          	mov    %rsi,(%r11,%rdx,8)
    a8f0:	48 39 c7             	cmp    %rax,%rdi
    a8f3:	75 eb                	jne    a8e0 <fwp_hof0.constprop.0+0x320>
    a8f5:	48 8d 15 84 8e 01 00 	lea    0x18e84(%rip),%rdx        # 23780 <fwp_heap>
    a8fc:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    a900:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    a907:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    a90e:	48 89 f1             	mov    %rsi,%rcx
    a911:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
    a915:	48 c1 e1 10          	shl    $0x10,%rcx
    a919:	48 39 c8             	cmp    %rcx,%rax
    a91c:	73 4c                	jae    a96a <fwp_hof0.constprop.0+0x3aa>
    a91e:	48 89 c1             	mov    %rax,%rcx
    a921:	48 c1 e9 10          	shr    $0x10,%rcx
    a925:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    a929:	48 8b 0d 48 a2 01 00 	mov    0x1a248(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    a930:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    a934:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    a938:	48 85 f6             	test   %rsi,%rsi
    a93b:	74 2d                	je     a96a <fwp_hof0.constprop.0+0x3aa>
    a93d:	0f b6 39             	movzbl (%rcx),%edi
    a940:	40 80 ff 02          	cmp    $0x2,%dil
    a944:	74 6a                	je     a9b0 <fwp_hof0.constprop.0+0x3f0>
    a946:	40 80 ff 01          	cmp    $0x1,%dil
    a94a:	75 1e                	jne    a96a <fwp_hof0.constprop.0+0x3aa>
    a94c:	8b 79 18             	mov    0x18(%rcx),%edi
    a94f:	0f b7 c0             	movzwl %ax,%eax
    a952:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a955:	48 0f af c7          	imul   %rdi,%rax
    a959:	48 c1 e8 20          	shr    $0x20,%rax
    a95d:	48 39 c8             	cmp    %rcx,%rax
    a960:	73 08                	jae    a96a <fwp_hof0.constprop.0+0x3aa>
    a962:	48 01 c6             	add    %rax,%rsi
    a965:	80 3e 01             	cmpb   $0x1,(%rsi)
    a968:	74 36                	je     a9a0 <fwp_hof0.constprop.0+0x3e0>
    a96a:	4c 89 45 80          	mov    %r8,-0x80(%rbp)
    a96e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    a972:	be 01 00 00 00       	mov    $0x1,%esi
    a977:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
    a97b:	41 ff 52 08          	call   *0x8(%r10)
    a97f:	4c 8b 5d 98          	mov    -0x68(%rbp),%r11
    a983:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
    a987:	49 8b 40 18          	mov    0x18(%r8),%rax
    a98b:	4c 89 df             	mov    %r11,%rdi
    a98e:	ff 10                	call   *(%rax)
    a990:	48 8b 65 a0          	mov    -0x60(%rbp),%rsp
    a994:	e9 42 fe ff ff       	jmp    a7db <fwp_hof0.constprop.0+0x21b>
    a999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a9a0:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    a9a7:	00 
    a9a8:	eb dd                	jmp    a987 <fwp_hof0.constprop.0+0x3c7>
    a9aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a9b0:	66 85 c0             	test   %ax,%ax
    a9b3:	75 b5                	jne    a96a <fwp_hof0.constprop.0+0x3aa>
    a9b5:	eb ae                	jmp    a965 <fwp_hof0.constprop.0+0x3a5>
    a9b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a9be:	00 00 
    a9c0:	49 89 c7             	mov    %rax,%r15
    a9c3:	4c 89 ff             	mov    %r15,%rdi
    a9c6:	e8 05 ba ff ff       	call   63d0 <fwp_rc_share>
    a9cb:	45 85 ed             	test   %r13d,%r13d
    a9ce:	74 21                	je     a9f1 <fwp_hof0.constprop.0+0x431>
    a9d0:	44 89 ea             	mov    %r13d,%edx
    a9d3:	4c 89 e3             	mov    %r12,%rbx
    a9d6:	4d 8d 34 d4          	lea    (%r12,%rdx,8),%r14
    a9da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a9e0:	48 8b 3b             	mov    (%rbx),%rdi
    a9e3:	48 83 c3 08          	add    $0x8,%rbx
    a9e7:	e8 e4 b9 ff ff       	call   63d0 <fwp_rc_share>
    a9ec:	4c 39 f3             	cmp    %r14,%rbx
    a9ef:	75 ef                	jne    a9e0 <fwp_hof0.constprop.0+0x420>
    a9f1:	4c 89 e2             	mov    %r12,%rdx
    a9f4:	44 89 ee             	mov    %r13d,%esi
    a9f7:	4c 89 ff             	mov    %r15,%rdi
    a9fa:	e8 71 b1 ff ff       	call   5b70 <fwp_apply>
    a9ff:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    aa03:	8b 75 94             	mov    -0x6c(%rbp),%esi
    aa06:	39 75 90             	cmp    %esi,-0x70(%rbp)
    aa09:	0f 83 87 00 00 00    	jae    aa96 <fwp_hof0.constprop.0+0x4d6>
    aa0f:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    aa15:	48 8b 7d 88          	mov    -0x78(%rbp),%rdi
    aa19:	48 89 c2             	mov    %rax,%rdx
    aa1c:	48 8d 04 c7          	lea    (%rdi,%rax,8),%rax
    aa20:	29 d6                	sub    %edx,%esi
    aa22:	48 8b 15 af a9 01 00 	mov    0x1a9af(%rip),%rdx        # 253d8 <fwp_fns>
    aa29:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    aa2d:	89 75 94             	mov    %esi,-0x6c(%rbp)
    aa30:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    aa34:	44 8b 26             	mov    (%rsi),%r12d
    aa37:	48 89 f0             	mov    %rsi,%rax
    aa3a:	49 c1 e4 05          	shl    $0x5,%r12
    aa3e:	49 01 d4             	add    %rdx,%r12
    aa41:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
    aa47:	0f 85 3f fd ff ff    	jne    a78c <fwp_hof0.constprop.0+0x1cc>
    aa4d:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    aa51:	e8 7a b9 ff ff       	call   63d0 <fwp_rc_share>
    aa56:	44 8b 75 94          	mov    -0x6c(%rbp),%r14d
    aa5a:	45 85 f6             	test   %r14d,%r14d
    aa5d:	74 23                	je     aa82 <fwp_hof0.constprop.0+0x4c2>
    aa5f:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    aa63:	31 db                	xor    %ebx,%ebx
    aa65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aa6c:	00 00 00 00 
    aa70:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    aa74:	48 83 c3 01          	add    $0x1,%rbx
    aa78:	e8 53 b9 ff ff       	call   63d0 <fwp_rc_share>
    aa7d:	44 39 f3             	cmp    %r14d,%ebx
    aa80:	72 ee                	jb     aa70 <fwp_hof0.constprop.0+0x4b0>
    aa82:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    aa86:	8b 75 94             	mov    -0x6c(%rbp),%esi
    aa89:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    aa8d:	e8 de b0 ff ff       	call   5b70 <fwp_apply>
    aa92:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    aa96:	48 83 ad 60 ff ff ff 	subq   $0x1,-0xa0(%rbp)
    aa9d:	01 
    aa9e:	0f 85 00 fc ff ff    	jne    a6a4 <fwp_hof0.constprop.0+0xe4>
    aaa4:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    aaa8:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    aaaf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    aab3:	b9 01 00 00 00       	mov    $0x1,%ecx
    aab8:	48 8d 15 e1 80 00 00 	lea    0x80e1(%rip),%rdx        # 12ba0 <d0>
    aabf:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
    aac6:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
    aacd:	00 
    aace:	0f 29 45 b0          	movaps %xmm0,-0x50(%rbp)
    aad2:	e8 a9 ea ff ff       	call   9580 <fwp_write>
    aad7:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
    aadb:	4c 8b 75 b8          	mov    -0x48(%rbp),%r14
    aadf:	48 8d 05 48 45 00 00 	lea    0x4548(%rip),%rax        # f02e <_IO_stdin_used+0x2e>
    aae6:	48 85 c9             	test   %rcx,%rcx
    aae9:	48 0f 44 c8          	cmove  %rax,%rcx
    aaed:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    aaf1:	0f 87 f5 06 00 00    	ja     b1ec <fwp_hof0.constprop.0+0xc2c>
    aaf7:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    aafb:	be 01 00 00 00       	mov    $0x1,%esi
    ab00:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    ab04:	e8 47 af ff ff       	call   5a50 <fwp_heap_alloc>
    ab09:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
    ab0d:	4c 89 f2             	mov    %r14,%rdx
    ab10:	4c 89 30             	mov    %r14,(%rax)
    ab13:	4c 8d 60 08          	lea    0x8(%rax),%r12
    ab17:	48 89 c3             	mov    %rax,%rbx
    ab1a:	4c 89 e7             	mov    %r12,%rdi
    ab1d:	e8 7e 8a ff ff       	call   35a0 <memcpy@plt>
    ab22:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    ab28:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
    ab2c:	e8 8f 88 ff ff       	call   33c0 <free@plt>
    ab31:	48 8d 35 48 8c 01 00 	lea    0x18c48(%rip),%rsi        # 23780 <fwp_heap>
    ab38:	48 89 d8             	mov    %rbx,%rax
    ab3b:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    ab42:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    ab49:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    ab4d:	48 c1 e2 10          	shl    $0x10,%rdx
    ab51:	48 39 d0             	cmp    %rdx,%rax
    ab54:	73 57                	jae    abad <fwp_hof0.constprop.0+0x5ed>
    ab56:	48 89 c2             	mov    %rax,%rdx
    ab59:	48 c1 ea 10          	shr    $0x10,%rdx
    ab5d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ab61:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    ab68:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ab6c:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    ab70:	4d 85 f6             	test   %r14,%r14
    ab73:	74 38                	je     abad <fwp_hof0.constprop.0+0x5ed>
    ab75:	0f b6 0a             	movzbl (%rdx),%ecx
    ab78:	80 f9 02             	cmp    $0x2,%cl
    ab7b:	0f 84 c9 05 00 00    	je     b14a <fwp_hof0.constprop.0+0xb8a>
    ab81:	80 f9 01             	cmp    $0x1,%cl
    ab84:	75 27                	jne    abad <fwp_hof0.constprop.0+0x5ed>
    ab86:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ab89:	0f b7 c0             	movzwl %ax,%eax
    ab8c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ab8f:	48 0f af c1          	imul   %rcx,%rax
    ab93:	48 c1 e8 20          	shr    $0x20,%rax
    ab97:	48 39 d0             	cmp    %rdx,%rax
    ab9a:	73 11                	jae    abad <fwp_hof0.constprop.0+0x5ed>
    ab9c:	49 01 c6             	add    %rax,%r14
    ab9f:	41 80 3e ff          	cmpb   $0xff,(%r14)
    aba3:	0f 84 67 06 00 00    	je     b210 <fwp_hof0.constprop.0+0xc50>
    aba9:	41 c6 06 01          	movb   $0x1,(%r14)
    abad:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    abb1:	e8 5a bc ff ff       	call   6810 <fwp_drop0>
    abb6:	48 8b 13             	mov    (%rbx),%rdx
    abb9:	be 01 00 00 00       	mov    $0x1,%esi
    abbe:	4c 89 e7             	mov    %r12,%rdi
    abc1:	48 8b 0d 18 a8 01 00 	mov    0x1a818(%rip),%rcx        # 253e0 <fwp_prog_out>
    abc8:	e8 b3 8a ff ff       	call   3680 <fwrite@plt>
    abcd:	48 8b 35 0c a8 01 00 	mov    0x1a80c(%rip),%rsi        # 253e0 <fwp_prog_out>
    abd4:	bf 0a 00 00 00       	mov    $0xa,%edi
    abd9:	e8 02 89 ff ff       	call   34e0 <fputc@plt>
    abde:	48 8d 35 9b 8b 01 00 	lea    0x18b9b(%rip),%rsi        # 23780 <fwp_heap>
    abe5:	48 89 d8             	mov    %rbx,%rax
    abe8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    abef:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    abf6:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    abfa:	48 c1 e2 10          	shl    $0x10,%rdx
    abfe:	48 39 d0             	cmp    %rdx,%rax
    ac01:	73 69                	jae    ac6c <fwp_hof0.constprop.0+0x6ac>
    ac03:	48 89 c2             	mov    %rax,%rdx
    ac06:	48 c1 ea 10          	shr    $0x10,%rdx
    ac0a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ac0e:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    ac15:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ac19:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ac1d:	4d 85 e4             	test   %r12,%r12
    ac20:	74 4a                	je     ac6c <fwp_hof0.constprop.0+0x6ac>
    ac22:	0f b6 0a             	movzbl (%rdx),%ecx
    ac25:	80 f9 02             	cmp    $0x2,%cl
    ac28:	0f 84 2a 05 00 00    	je     b158 <fwp_hof0.constprop.0+0xb98>
    ac2e:	80 f9 01             	cmp    $0x1,%cl
    ac31:	75 39                	jne    ac6c <fwp_hof0.constprop.0+0x6ac>
    ac33:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ac36:	0f b7 c0             	movzwl %ax,%eax
    ac39:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ac3c:	48 0f af c1          	imul   %rcx,%rax
    ac40:	48 c1 e8 20          	shr    $0x20,%rax
    ac44:	48 39 d0             	cmp    %rdx,%rax
    ac47:	73 23                	jae    ac6c <fwp_hof0.constprop.0+0x6ac>
    ac49:	49 01 c4             	add    %rax,%r12
    ac4c:	41 0f b6 04 24       	movzbl (%r12),%eax
    ac51:	84 c0                	test   %al,%al
    ac53:	74 17                	je     ac6c <fwp_hof0.constprop.0+0x6ac>
    ac55:	3c 01                	cmp    $0x1,%al
    ac57:	0f 84 d3 04 00 00    	je     b130 <fwp_hof0.constprop.0+0xb70>
    ac5d:	3c ff                	cmp    $0xff,%al
    ac5f:	0f 84 01 05 00 00    	je     b166 <fwp_hof0.constprop.0+0xba6>
    ac65:	83 e8 01             	sub    $0x1,%eax
    ac68:	41 88 04 24          	mov    %al,(%r12)
    ac6c:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    ac70:	4d 85 ff             	test   %r15,%r15
    ac73:	0f 85 88 f9 ff ff    	jne    a601 <fwp_hof0.constprop.0+0x41>
    ac79:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    ac7d:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    ac84:	00 00 
    ac86:	0f 85 7e 05 00 00    	jne    b20a <fwp_hof0.constprop.0+0xc4a>
    ac8c:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    ac90:	31 c0                	xor    %eax,%eax
    ac92:	5b                   	pop    %rbx
    ac93:	41 5c                	pop    %r12
    ac95:	41 5d                	pop    %r13
    ac97:	41 5e                	pop    %r14
    ac99:	41 5f                	pop    %r15
    ac9b:	5d                   	pop    %rbp
    ac9c:	c3                   	ret
    ac9d:	0f 1f 00             	nopl   (%rax)
    aca0:	48 8d 1d d9 8a 01 00 	lea    0x18ad9(%rip),%rbx        # 23780 <fwp_heap>
    aca7:	41 8d 76 01          	lea    0x1(%r14),%esi
    acab:	45 89 f7             	mov    %r14d,%r15d
    acae:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    acb4:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    acbb:	00 
    acbc:	85 c0                	test   %eax,%eax
    acbe:	0f 84 a9 03 00 00    	je     b06d <fwp_hof0.constprop.0+0xaad>
    acc4:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    accb:	0f 87 9c 03 00 00    	ja     b06d <fwp_hof0.constprop.0+0xaad>
    acd1:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    acd5:	48 c1 e8 04          	shr    $0x4,%rax
    acd9:	0f b6 94 03 a0 0f 00 	movzbl 0xfa0(%rbx,%rax,1),%edx
    ace0:	00 
    ace1:	8b 84 93 00 0f 00 00 	mov    0xf00(%rbx,%rdx,4),%eax
    ace8:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    acec:	48 8d 14 d3          	lea    (%rbx,%rdx,8),%rdx
    acf0:	4c 8b 12             	mov    (%rdx),%r10
    acf3:	4d 85 d2             	test   %r10,%r10
    acf6:	0f 84 4f 03 00 00    	je     b04b <fwp_hof0.constprop.0+0xa8b>
    acfc:	4d 8b 1a             	mov    (%r10),%r11
    acff:	49 f7 d3             	not    %r11
    ad02:	4c 89 1a             	mov    %r11,(%rdx)
    ad05:	48 39 c7             	cmp    %rax,%rdi
    ad08:	73 50                	jae    ad5a <fwp_hof0.constprop.0+0x79a>
    ad0a:	48 89 fa             	mov    %rdi,%rdx
    ad0d:	48 83 c7 08          	add    $0x8,%rdi
    ad11:	49 c7 04 f2 00 00 00 	movq   $0x0,(%r10,%rsi,8)
    ad18:	00 
    ad19:	48 f7 d2             	not    %rdx
    ad1c:	48 01 c2             	add    %rax,%rdx
    ad1f:	48 c1 ea 03          	shr    $0x3,%rdx
    ad23:	48 39 c7             	cmp    %rax,%rdi
    ad26:	73 32                	jae    ad5a <fwp_hof0.constprop.0+0x79a>
    ad28:	83 e2 01             	and    $0x1,%edx
    ad2b:	74 13                	je     ad40 <fwp_hof0.constprop.0+0x780>
    ad2d:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    ad34:	00 
    ad35:	48 83 c7 08          	add    $0x8,%rdi
    ad39:	48 39 c7             	cmp    %rax,%rdi
    ad3c:	73 1c                	jae    ad5a <fwp_hof0.constprop.0+0x79a>
    ad3e:	66 90                	xchg   %ax,%ax
    ad40:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    ad47:	00 
    ad48:	49 c7 44 3a 08 00 00 	movq   $0x0,0x8(%r10,%rdi,1)
    ad4f:	00 00 
    ad51:	48 83 c7 10          	add    $0x10,%rdi
    ad55:	48 39 c7             	cmp    %rax,%rdi
    ad58:	72 e6                	jb     ad40 <fwp_hof0.constprop.0+0x780>
    ad5a:	48 8d 35 1f 8a 01 00 	lea    0x18a1f(%rip),%rsi        # 23780 <fwp_heap>
    ad61:	48 89 c2             	mov    %rax,%rdx
    ad64:	48 03 96 20 14 00 00 	add    0x1420(%rsi),%rdx
    ad6b:	0f 82 6a 04 00 00    	jb     b1db <fwp_hof0.constprop.0+0xc1b>
    ad71:	48 89 96 20 14 00 00 	mov    %rdx,0x1420(%rsi)
    ad78:	48 39 96 28 14 00 00 	cmp    %rdx,0x1428(%rsi)
    ad7f:	73 07                	jae    ad88 <fwp_hof0.constprop.0+0x7c8>
    ad81:	48 89 15 20 9e 01 00 	mov    %rdx,0x19e20(%rip)        # 24ba8 <fwp_heap+0x1428>
    ad88:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ad8c:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    ad91:	f2 0f 58 05 1f 9e 01 	addsd  0x19e1f(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    ad98:	00 
    ad99:	f2 0f 11 05 17 9e 01 	movsd  %xmm0,0x19e17(%rip)        # 24bb8 <fwp_heap+0x1438>
    ada0:	00 
    ada1:	66 41 0f 6e 01       	movd   (%r9),%xmm0
    ada6:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    adab:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    adaf:	66 41 0f d6 02       	movq   %xmm0,(%r10)
    adb4:	85 c9                	test   %ecx,%ecx
    adb6:	74 37                	je     adef <fwp_hof0.constprop.0+0x82f>
    adb8:	89 ca                	mov    %ecx,%edx
    adba:	49 8d 71 08          	lea    0x8(%r9),%rsi
    adbe:	49 8d 7a 08          	lea    0x8(%r10),%rdi
    adc2:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    adc5:	48 c1 e2 03          	shl    $0x3,%rdx
    adc9:	4c 89 85 68 ff ff ff 	mov    %r8,-0x98(%rbp)
    add0:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
    add4:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    add8:	e8 33 88 ff ff       	call   3610 <memmove@plt>
    addd:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    ade1:	4c 8b 4d 98          	mov    -0x68(%rbp),%r9
    ade5:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    ade8:	4c 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%r8
    adef:	45 85 ed             	test   %r13d,%r13d
    adf2:	74 23                	je     ae17 <fwp_hof0.constprop.0+0x857>
    adf4:	45 89 ed             	mov    %r13d,%r13d
    adf7:	4b 8d 34 ec          	lea    (%r12,%r13,8),%rsi
    adfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ae00:	49 8b 14 24          	mov    (%r12),%rdx
    ae04:	89 c8                	mov    %ecx,%eax
    ae06:	49 83 c4 08          	add    $0x8,%r12
    ae0a:	83 c1 01             	add    $0x1,%ecx
    ae0d:	49 89 54 c2 08       	mov    %rdx,0x8(%r10,%rax,8)
    ae12:	4c 39 e6             	cmp    %r12,%rsi
    ae15:	75 e9                	jne    ae00 <fwp_hof0.constprop.0+0x840>
    ae17:	48 8d 35 62 89 01 00 	lea    0x18962(%rip),%rsi        # 23780 <fwp_heap>
    ae1e:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    ae22:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    ae29:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    ae30:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    ae34:	48 c1 e2 10          	shl    $0x10,%rdx
    ae38:	48 39 d0             	cmp    %rdx,%rax
    ae3b:	73 54                	jae    ae91 <fwp_hof0.constprop.0+0x8d1>
    ae3d:	48 89 c2             	mov    %rax,%rdx
    ae40:	48 c1 ea 10          	shr    $0x10,%rdx
    ae44:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ae48:	48 8b 15 29 9d 01 00 	mov    0x19d29(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    ae4f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ae53:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    ae57:	48 85 c9             	test   %rcx,%rcx
    ae5a:	74 35                	je     ae91 <fwp_hof0.constprop.0+0x8d1>
    ae5c:	0f b6 32             	movzbl (%rdx),%esi
    ae5f:	40 80 fe 02          	cmp    $0x2,%sil
    ae63:	0f 84 52 02 00 00    	je     b0bb <fwp_hof0.constprop.0+0xafb>
    ae69:	40 80 fe 01          	cmp    $0x1,%sil
    ae6d:	75 22                	jne    ae91 <fwp_hof0.constprop.0+0x8d1>
    ae6f:	8b 72 18             	mov    0x18(%rdx),%esi
    ae72:	0f b7 c0             	movzwl %ax,%eax
    ae75:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ae78:	48 0f af c6          	imul   %rsi,%rax
    ae7c:	48 c1 e8 20          	shr    $0x20,%rax
    ae80:	48 39 d0             	cmp    %rdx,%rax
    ae83:	73 0c                	jae    ae91 <fwp_hof0.constprop.0+0x8d1>
    ae85:	48 01 c1             	add    %rax,%rcx
    ae88:	80 39 01             	cmpb   $0x1,(%rcx)
    ae8b:	0f 84 9f 01 00 00    	je     b030 <fwp_hof0.constprop.0+0xa70>
    ae91:	49 8b 40 18          	mov    0x18(%r8),%rax
    ae95:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    ae99:	be 01 00 00 00       	mov    $0x1,%esi
    ae9e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    aea2:	ff 50 08             	call   *0x8(%rax)
    aea5:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    aea9:	48 8d 35 d0 88 01 00 	lea    0x188d0(%rip),%rsi        # 23780 <fwp_heap>
    aeb0:	4c 89 d0             	mov    %r10,%rax
    aeb3:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    aeba:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    aec1:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    aec5:	48 c1 e2 10          	shl    $0x10,%rdx
    aec9:	48 39 d0             	cmp    %rdx,%rax
    aecc:	73 59                	jae    af27 <fwp_hof0.constprop.0+0x967>
    aece:	48 89 c2             	mov    %rax,%rdx
    aed1:	48 c1 ea 10          	shr    $0x10,%rdx
    aed5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aed9:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    aee0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aee4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    aee8:	4d 85 e4             	test   %r12,%r12
    aeeb:	74 3a                	je     af27 <fwp_hof0.constprop.0+0x967>
    aeed:	0f b6 0a             	movzbl (%rdx),%ecx
    aef0:	80 f9 02             	cmp    $0x2,%cl
    aef3:	0f 84 99 01 00 00    	je     b092 <fwp_hof0.constprop.0+0xad2>
    aef9:	80 f9 01             	cmp    $0x1,%cl
    aefc:	75 29                	jne    af27 <fwp_hof0.constprop.0+0x967>
    aefe:	8b 4a 18             	mov    0x18(%rdx),%ecx
    af01:	0f b7 c0             	movzwl %ax,%eax
    af04:	8b 52 1c             	mov    0x1c(%rdx),%edx
    af07:	48 0f af c1          	imul   %rcx,%rax
    af0b:	48 c1 e8 20          	shr    $0x20,%rax
    af0f:	48 39 d0             	cmp    %rdx,%rax
    af12:	73 13                	jae    af27 <fwp_hof0.constprop.0+0x967>
    af14:	49 01 c4             	add    %rax,%r12
    af17:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    af1c:	0f 84 84 01 00 00    	je     b0a6 <fwp_hof0.constprop.0+0xae6>
    af22:	41 c6 04 24 01       	movb   $0x1,(%r12)
    af27:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    af2b:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    af2f:	e8 bc bb ff ff       	call   6af0 <fwp_closure_drop>
    af34:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    af38:	4c 89 55 a8          	mov    %r10,-0x58(%rbp)
    af3c:	e9 c2 fa ff ff       	jmp    aa03 <fwp_hof0.constprop.0+0x443>
    af41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    af48:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    af4c:	e9 b2 fa ff ff       	jmp    aa03 <fwp_hof0.constprop.0+0x443>
    af51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    af58:	41 8b 34 24          	mov    (%r12),%esi
    af5c:	8b 05 ba 80 00 00    	mov    0x80ba(%rip),%eax        # 1301c <fc12+0x4>
    af62:	89 f7                	mov    %esi,%edi
    af64:	29 c7                	sub    %eax,%edi
    af66:	83 ff 01             	cmp    $0x1,%edi
    af69:	0f 85 6e f7 ff ff    	jne    a6dd <fwp_hof0.constprop.0+0x11d>
    af6f:	48 89 e3             	mov    %rsp,%rbx
    af72:	85 c0                	test   %eax,%eax
    af74:	0f 84 60 01 00 00    	je     b0da <fwp_hof0.constprop.0+0xb1a>
    af7a:	89 f1                	mov    %esi,%ecx
    af7c:	ba 08 00 00 00       	mov    $0x8,%edx
    af81:	48 c1 e1 03          	shl    $0x3,%rcx
    af85:	85 f6                	test   %esi,%esi
    af87:	48 89 e6             	mov    %rsp,%rsi
    af8a:	48 0f 45 d1          	cmovne %rcx,%rdx
    af8e:	49 89 d7             	mov    %rdx,%r15
    af91:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    af95:	48 c1 ea 04          	shr    $0x4,%rdx
    af99:	48 c1 e2 04          	shl    $0x4,%rdx
    af9d:	48 89 d7             	mov    %rdx,%rdi
    afa0:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    afa7:	48 29 fe             	sub    %rdi,%rsi
    afaa:	48 39 f4             	cmp    %rsi,%rsp
    afad:	74 15                	je     afc4 <fwp_hof0.constprop.0+0xa04>
    afaf:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    afb6:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    afbd:	00 00 
    afbf:	48 39 f4             	cmp    %rsi,%rsp
    afc2:	75 eb                	jne    afaf <fwp_hof0.constprop.0+0x9ef>
    afc4:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    afca:	48 29 d4             	sub    %rdx,%rsp
    afcd:	48 85 d2             	test   %rdx,%rdx
    afd0:	74 06                	je     afd8 <fwp_hof0.constprop.0+0xa18>
    afd2:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    afd8:	4c 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%r14
    afdf:	00 
    afe0:	4c 89 f9             	mov    %r15,%rcx
    afe3:	48 8d 35 36 80 00 00 	lea    0x8036(%rip),%rsi        # 13020 <fwp_epfd>
    afea:	48 89 e7             	mov    %rsp,%rdi
    afed:	4c 89 f2             	mov    %r14,%rdx
    aff0:	e8 7b 85 ff ff       	call   3570 <__memcpy_chk@plt>
    aff5:	4d 39 f7             	cmp    %r14,%r15
    aff8:	4c 89 f9             	mov    %r15,%rcx
    affb:	4a 8d 3c 34          	lea    (%rsp,%r14,1),%rdi
    afff:	49 0f 42 ce          	cmovb  %r14,%rcx
    b003:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
    b00a:	ba 08 00 00 00       	mov    $0x8,%edx
    b00f:	4c 29 f1             	sub    %r14,%rcx
    b012:	e8 59 85 ff ff       	call   3570 <__memcpy_chk@plt>
    b017:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    b01c:	48 89 e7             	mov    %rsp,%rdi
    b01f:	ff 10                	call   *(%rax)
    b021:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b025:	e9 bd 00 00 00       	jmp    b0e7 <fwp_hof0.constprop.0+0xb27>
    b02a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b030:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    b037:	00 
    b038:	e9 6c fe ff ff       	jmp    aea9 <fwp_hof0.constprop.0+0x8e9>
    b03d:	66 85 c0             	test   %ax,%ax
    b040:	0f 85 22 f7 ff ff    	jne    a768 <fwp_hof0.constprop.0+0x1a8>
    b046:	e9 09 f7 ff ff       	jmp    a754 <fwp_hof0.constprop.0+0x194>
    b04b:	4c 8b 52 08          	mov    0x8(%rdx),%r10
    b04f:	4d 85 d2             	test   %r10,%r10
    b052:	74 19                	je     b06d <fwp_hof0.constprop.0+0xaad>
    b054:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
    b058:	4d 29 d3             	sub    %r10,%r11
    b05b:	49 39 c3             	cmp    %rax,%r11
    b05e:	72 0d                	jb     b06d <fwp_hof0.constprop.0+0xaad>
    b060:	4d 8d 1c 02          	lea    (%r10,%rax,1),%r11
    b064:	4c 89 5a 08          	mov    %r11,0x8(%rdx)
    b068:	e9 98 fc ff ff       	jmp    ad05 <fwp_hof0.constprop.0+0x745>
    b06d:	31 f6                	xor    %esi,%esi
    b06f:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b072:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    b076:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    b07a:	e8 d1 a9 ff ff       	call   5a50 <fwp_heap_alloc>
    b07f:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b082:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    b086:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    b08a:	49 89 c2             	mov    %rax,%r10
    b08d:	e9 0f fd ff ff       	jmp    ada1 <fwp_hof0.constprop.0+0x7e1>
    b092:	66 85 c0             	test   %ax,%ax
    b095:	0f 85 8c fe ff ff    	jne    af27 <fwp_hof0.constprop.0+0x967>
    b09b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b0a0:	0f 85 7c fe ff ff    	jne    af22 <fwp_hof0.constprop.0+0x962>
    b0a6:	4c 89 e7             	mov    %r12,%rdi
    b0a9:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b0ad:	e8 5e a2 ff ff       	call   5310 <fwp_rc_forget_slot>
    b0b2:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b0b6:	e9 67 fe ff ff       	jmp    af22 <fwp_hof0.constprop.0+0x962>
    b0bb:	66 85 c0             	test   %ax,%ax
    b0be:	0f 85 cd fd ff ff    	jne    ae91 <fwp_hof0.constprop.0+0x8d1>
    b0c4:	e9 bf fd ff ff       	jmp    ae88 <fwp_hof0.constprop.0+0x8c8>
    b0c9:	e8 22 a1 ff ff       	call   51f0 <fwp_rc_wide_dup>
    b0ce:	48 8b 15 03 a3 01 00 	mov    0x1a303(%rip),%rdx        # 253d8 <fwp_fns>
    b0d5:	e9 8e f6 ff ff       	jmp    a768 <fwp_hof0.constprop.0+0x1a8>
    b0da:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    b0e1:	ff 11                	call   *(%rcx)
    b0e3:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b0e7:	48 89 dc             	mov    %rbx,%rsp
    b0ea:	e9 a7 f9 ff ff       	jmp    aa96 <fwp_hof0.constprop.0+0x4d6>
    b0ef:	48 89 c7             	mov    %rax,%rdi
    b0f2:	e8 d9 b2 ff ff       	call   63d0 <fwp_rc_share>
    b0f7:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b0fb:	e8 d0 b2 ff ff       	call   63d0 <fwp_rc_share>
    b100:	48 8d 05 11 7f 00 00 	lea    0x7f11(%rip),%rax        # 13018 <fc12>
    b107:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    b10e:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b112:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    b119:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b11d:	e9 60 f9 ff ff       	jmp    aa82 <fwp_hof0.constprop.0+0x4c2>
    b122:	66 85 c0             	test   %ax,%ax
    b125:	0f 85 5c f5 ff ff    	jne    a687 <fwp_hof0.constprop.0+0xc7>
    b12b:	e9 43 f5 ff ff       	jmp    a673 <fwp_hof0.constprop.0+0xb3>
    b130:	48 89 df             	mov    %rbx,%rdi
    b133:	e8 c8 b3 ff ff       	call   6500 <fwp_rc_free_arr>
    b138:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    b13c:	4d 85 ff             	test   %r15,%r15
    b13f:	0f 85 bc f4 ff ff    	jne    a601 <fwp_hof0.constprop.0+0x41>
    b145:	e9 2f fb ff ff       	jmp    ac79 <fwp_hof0.constprop.0+0x6b9>
    b14a:	66 85 c0             	test   %ax,%ax
    b14d:	0f 85 5a fa ff ff    	jne    abad <fwp_hof0.constprop.0+0x5ed>
    b153:	e9 47 fa ff ff       	jmp    ab9f <fwp_hof0.constprop.0+0x5df>
    b158:	66 85 c0             	test   %ax,%ax
    b15b:	0f 85 0b fb ff ff    	jne    ac6c <fwp_hof0.constprop.0+0x6ac>
    b161:	e9 e6 fa ff ff       	jmp    ac4c <fwp_hof0.constprop.0+0x68c>
    b166:	4c 89 e0             	mov    %r12,%rax
    b169:	48 8d 35 10 86 01 00 	lea    0x18610(%rip),%rsi        # 23780 <fwp_heap>
    b170:	48 c1 e8 11          	shr    $0x11,%rax
    b174:	4c 31 e0             	xor    %r12,%rax
    b177:	48 89 c2             	mov    %rax,%rdx
    b17a:	48 c1 ea 09          	shr    $0x9,%rdx
    b17e:	48 31 d0             	xor    %rdx,%rax
    b181:	0f b6 c0             	movzbl %al,%eax
    b184:	48 8b 94 c6 48 14 00 	mov    0x1448(%rsi,%rax,8),%rdx
    b18b:	00 
    b18c:	48 85 d2             	test   %rdx,%rdx
    b18f:	75 18                	jne    b1a9 <fwp_hof0.constprop.0+0xbe9>
    b191:	eb 4d                	jmp    b1e0 <fwp_hof0.constprop.0+0xc20>
    b193:	66 90                	xchg   %ax,%ax
    b195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b19c:	00 00 00 00 
    b1a0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b1a4:	48 85 d2             	test   %rdx,%rdx
    b1a7:	74 37                	je     b1e0 <fwp_hof0.constprop.0+0xc20>
    b1a9:	48 89 d0             	mov    %rdx,%rax
    b1ac:	4c 39 22             	cmp    %r12,(%rdx)
    b1af:	75 ef                	jne    b1a0 <fwp_hof0.constprop.0+0xbe0>
    b1b1:	48 8b 42 08          	mov    0x8(%rdx),%rax
    b1b5:	48 83 e8 01          	sub    $0x1,%rax
    b1b9:	48 89 42 08          	mov    %rax,0x8(%rdx)
    b1bd:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    b1c3:	0f 85 a3 fa ff ff    	jne    ac6c <fwp_hof0.constprop.0+0x6ac>
    b1c9:	4c 89 e7             	mov    %r12,%rdi
    b1cc:	e8 3f a1 ff ff       	call   5310 <fwp_rc_forget_slot>
    b1d1:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b1d6:	e9 91 fa ff ff       	jmp    ac6c <fwp_hof0.constprop.0+0x6ac>
    b1db:	e8 d0 8a ff ff       	call   3cb0 <fwp_heap_oom>
    b1e0:	48 8d 3d b1 45 00 00 	lea    0x45b1(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    b1e7:	e8 b4 8f ff ff       	call   41a0 <fwp_trap>
    b1ec:	48 8d 3d f5 3f 00 00 	lea    0x3ff5(%rip),%rdi        # f1e8 <_IO_stdin_used+0x1e8>
    b1f3:	e8 a8 8f ff ff       	call   41a0 <fwp_trap>
    b1f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b1ff:	00 
    b200:	e8 eb 9f ff ff       	call   51f0 <fwp_rc_wide_dup>
    b205:	e9 7d f4 ff ff       	jmp    a687 <fwp_hof0.constprop.0+0xc7>
    b20a:	e8 51 82 ff ff       	call   3460 <__stack_chk_fail@plt>
    b20f:	90                   	nop
    b210:	4c 89 f7             	mov    %r14,%rdi
    b213:	e8 f8 a0 ff ff       	call   5310 <fwp_rc_forget_slot>
    b218:	e9 8c f9 ff ff       	jmp    aba9 <fwp_hof0.constprop.0+0x5e9>
    b21d:	0f 1f 00             	nopl   (%rax)

000000000000b220 <f0>:
    b220:	41 56                	push   %r14
    b222:	4c 8d 35 57 85 01 00 	lea    0x18557(%rip),%r14        # 23780 <fwp_heap>
    b229:	41 55                	push   %r13
    b22b:	41 54                	push   %r12
    b22d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    b233:	55                   	push   %rbp
    b234:	53                   	push   %rbx
    b235:	31 db                	xor    %ebx,%ebx
    b237:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    b23e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b245:	00 00 
    b247:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    b24e:	00 
    b24f:	31 c0                	xor    %eax,%eax
    b251:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    b258:	00 
    b259:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    b260:	00 00 
    b262:	66 48 0f 6e c0       	movq   %rax,%xmm0
    b267:	48 8d 05 22 b7 ff ff 	lea    -0x48de(%rip),%rax        # 6990 <fwp_drop1>
    b26e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    b273:	48 8b 05 9e a1 01 00 	mov    0x1a19e(%rip),%rax        # 25418 <fwp_cleanups>
    b27a:	48 89 25 97 a1 01 00 	mov    %rsp,0x1a197(%rip)        # 25418 <fwp_cleanups>
    b281:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    b285:	48 89 04 24          	mov    %rax,(%rsp)
    b289:	48 8d 05 40 89 ff ff 	lea    -0x76c0(%rip),%rax        # 3bd0 <fwp_range_release>
    b290:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b295:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    b29a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b29f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    b2a4:	eb 47                	jmp    b2ed <f0+0xcd>
    b2a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b2ad:	00 00 00 
    b2b0:	80 f9 01             	cmp    $0x1,%cl
    b2b3:	75 29                	jne    b2de <f0+0xbe>
    b2b5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b2b8:	0f b7 c0             	movzwl %ax,%eax
    b2bb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b2be:	48 0f af c1          	imul   %rcx,%rax
    b2c2:	48 c1 e8 20          	shr    $0x20,%rax
    b2c6:	48 39 d0             	cmp    %rdx,%rax
    b2c9:	73 13                	jae    b2de <f0+0xbe>
    b2cb:	49 01 c5             	add    %rax,%r13
    b2ce:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b2d3:	0f 84 c7 27 00 00    	je     daa0 <f0+0x2880>
    b2d9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b2de:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b2e3:	49 83 ec 01          	sub    $0x1,%r12
    b2e7:	0f 82 83 00 00 00    	jb     b370 <f0+0x150>
    b2ed:	48 89 ee             	mov    %rbp,%rsi
    b2f0:	bf 01 00 00 00       	mov    $0x1,%edi
    b2f5:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    b2fc:	00 
    b2fd:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    b302:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    b309:	00 
    b30a:	e8 91 af ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b30f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b316:	48 89 c3             	mov    %rax,%rbx
    b319:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b320:	48 c1 e2 10          	shl    $0x10,%rdx
    b324:	48 39 d0             	cmp    %rdx,%rax
    b327:	73 b5                	jae    b2de <f0+0xbe>
    b329:	48 89 c2             	mov    %rax,%rdx
    b32c:	48 c1 ea 10          	shr    $0x10,%rdx
    b330:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b334:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b33b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b33f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b343:	4d 85 ed             	test   %r13,%r13
    b346:	74 96                	je     b2de <f0+0xbe>
    b348:	0f b6 0a             	movzbl (%rdx),%ecx
    b34b:	80 f9 02             	cmp    $0x2,%cl
    b34e:	0f 85 5c ff ff ff    	jne    b2b0 <f0+0x90>
    b354:	66 85 c0             	test   %ax,%ax
    b357:	0f 84 71 ff ff ff    	je     b2ce <f0+0xae>
    b35d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b362:	49 83 ec 01          	sub    $0x1,%r12
    b366:	73 85                	jae    b2ed <f0+0xcd>
    b368:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b36f:	00 
    b370:	48 8b 04 24          	mov    (%rsp),%rax
    b374:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    b379:	bf 01 00 00 00       	mov    $0x1,%edi
    b37e:	66 0f 6f 05 9a 47 00 	movdqa 0x479a(%rip),%xmm0        # fb20 <msg.4+0xa0>
    b385:	00 
    b386:	48 89 05 8b a0 01 00 	mov    %rax,0x1a08b(%rip)        # 25418 <fwp_cleanups>
    b38d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b392:	e8 09 af ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b397:	48 8b 15 ba 97 01 00 	mov    0x197ba(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    b39e:	49 89 c5             	mov    %rax,%r13
    b3a1:	48 2b 05 88 97 01 00 	sub    0x19788(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    b3a8:	48 c1 e2 10          	shl    $0x10,%rdx
    b3ac:	48 39 d0             	cmp    %rdx,%rax
    b3af:	73 59                	jae    b40a <f0+0x1ea>
    b3b1:	48 89 c2             	mov    %rax,%rdx
    b3b4:	48 c1 ea 10          	shr    $0x10,%rdx
    b3b8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b3bc:	48 8b 15 b5 97 01 00 	mov    0x197b5(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b3c3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b3c7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b3cb:	4d 85 e4             	test   %r12,%r12
    b3ce:	74 3a                	je     b40a <f0+0x1ea>
    b3d0:	0f b6 0a             	movzbl (%rdx),%ecx
    b3d3:	80 f9 02             	cmp    $0x2,%cl
    b3d6:	0f 84 74 27 00 00    	je     db50 <f0+0x2930>
    b3dc:	80 f9 01             	cmp    $0x1,%cl
    b3df:	75 29                	jne    b40a <f0+0x1ea>
    b3e1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b3e4:	0f b7 c0             	movzwl %ax,%eax
    b3e7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b3ea:	48 0f af c1          	imul   %rcx,%rax
    b3ee:	48 c1 e8 20          	shr    $0x20,%rax
    b3f2:	48 39 d0             	cmp    %rdx,%rax
    b3f5:	73 13                	jae    b40a <f0+0x1ea>
    b3f7:	49 01 c4             	add    %rax,%r12
    b3fa:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b3ff:	0f 84 26 29 00 00    	je     dd2b <f0+0x2b0b>
    b405:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b40a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    b40f:	bf 01 00 00 00       	mov    $0x1,%edi
    b414:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    b419:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b420:	00 f0 3f 
    b423:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    b428:	e8 73 ae ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b42d:	48 8b 15 24 97 01 00 	mov    0x19724(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    b434:	49 89 c5             	mov    %rax,%r13
    b437:	48 2b 05 f2 96 01 00 	sub    0x196f2(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    b43e:	48 c1 e2 10          	shl    $0x10,%rdx
    b442:	48 39 d0             	cmp    %rdx,%rax
    b445:	73 59                	jae    b4a0 <f0+0x280>
    b447:	48 89 c2             	mov    %rax,%rdx
    b44a:	48 c1 ea 10          	shr    $0x10,%rdx
    b44e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b452:	48 8b 15 1f 97 01 00 	mov    0x1971f(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b459:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b45d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b461:	4d 85 e4             	test   %r12,%r12
    b464:	74 3a                	je     b4a0 <f0+0x280>
    b466:	0f b6 0a             	movzbl (%rdx),%ecx
    b469:	80 f9 02             	cmp    $0x2,%cl
    b46c:	0f 84 ce 26 00 00    	je     db40 <f0+0x2920>
    b472:	80 f9 01             	cmp    $0x1,%cl
    b475:	75 29                	jne    b4a0 <f0+0x280>
    b477:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b47a:	0f b7 c0             	movzwl %ax,%eax
    b47d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b480:	48 0f af c1          	imul   %rcx,%rax
    b484:	48 c1 e8 20          	shr    $0x20,%rax
    b488:	48 39 d0             	cmp    %rdx,%rax
    b48b:	73 13                	jae    b4a0 <f0+0x280>
    b48d:	49 01 c4             	add    %rax,%r12
    b490:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b495:	0f 84 9d 28 00 00    	je     dd38 <f0+0x2b18>
    b49b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b4a0:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b4a5:	bf 01 00 00 00       	mov    $0x1,%edi
    b4aa:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    b4af:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b4b6:	33 f3 bf 
    b4b9:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b4be:	e8 dd ad ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b4c3:	48 8b 15 8e 96 01 00 	mov    0x1968e(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    b4ca:	49 89 c5             	mov    %rax,%r13
    b4cd:	48 2b 05 5c 96 01 00 	sub    0x1965c(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    b4d4:	48 c1 e2 10          	shl    $0x10,%rdx
    b4d8:	48 39 d0             	cmp    %rdx,%rax
    b4db:	73 59                	jae    b536 <f0+0x316>
    b4dd:	48 89 c2             	mov    %rax,%rdx
    b4e0:	48 c1 ea 10          	shr    $0x10,%rdx
    b4e4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b4e8:	48 8b 15 89 96 01 00 	mov    0x19689(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b4ef:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b4f3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b4f7:	4d 85 e4             	test   %r12,%r12
    b4fa:	74 3a                	je     b536 <f0+0x316>
    b4fc:	0f b6 0a             	movzbl (%rdx),%ecx
    b4ff:	80 f9 02             	cmp    $0x2,%cl
    b502:	0f 84 28 26 00 00    	je     db30 <f0+0x2910>
    b508:	80 f9 01             	cmp    $0x1,%cl
    b50b:	75 29                	jne    b536 <f0+0x316>
    b50d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b510:	0f b7 c0             	movzwl %ax,%eax
    b513:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b516:	48 0f af c1          	imul   %rcx,%rax
    b51a:	48 c1 e8 20          	shr    $0x20,%rax
    b51e:	48 39 d0             	cmp    %rdx,%rax
    b521:	73 13                	jae    b536 <f0+0x316>
    b523:	49 01 c4             	add    %rax,%r12
    b526:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b52b:	0f 84 14 28 00 00    	je     dd45 <f0+0x2b25>
    b531:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b536:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b53b:	bf 01 00 00 00       	mov    $0x1,%edi
    b540:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    b545:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b54c:	00 f0 3f 
    b54f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b554:	e8 47 ad ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b559:	48 8b 15 f8 95 01 00 	mov    0x195f8(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    b560:	49 89 c5             	mov    %rax,%r13
    b563:	48 2b 05 c6 95 01 00 	sub    0x195c6(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    b56a:	48 c1 e2 10          	shl    $0x10,%rdx
    b56e:	48 39 d0             	cmp    %rdx,%rax
    b571:	73 59                	jae    b5cc <f0+0x3ac>
    b573:	48 89 c2             	mov    %rax,%rdx
    b576:	48 c1 ea 10          	shr    $0x10,%rdx
    b57a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b57e:	48 8b 15 f3 95 01 00 	mov    0x195f3(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b585:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b589:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b58d:	4d 85 e4             	test   %r12,%r12
    b590:	74 3a                	je     b5cc <f0+0x3ac>
    b592:	0f b6 0a             	movzbl (%rdx),%ecx
    b595:	80 f9 02             	cmp    $0x2,%cl
    b598:	0f 84 f2 25 00 00    	je     db90 <f0+0x2970>
    b59e:	80 f9 01             	cmp    $0x1,%cl
    b5a1:	75 29                	jne    b5cc <f0+0x3ac>
    b5a3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b5a6:	0f b7 c0             	movzwl %ax,%eax
    b5a9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b5ac:	48 0f af c1          	imul   %rcx,%rax
    b5b0:	48 c1 e8 20          	shr    $0x20,%rax
    b5b4:	48 39 d0             	cmp    %rdx,%rax
    b5b7:	73 13                	jae    b5cc <f0+0x3ac>
    b5b9:	49 01 c4             	add    %rax,%r12
    b5bc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b5c1:	0f 84 8b 27 00 00    	je     dd52 <f0+0x2b32>
    b5c7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b5cc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b5d3:	33 f3 bf 
    b5d6:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    b5dd:	00 
    b5de:	bf 01 00 00 00       	mov    $0x1,%edi
    b5e3:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    b5ea:	00 
    b5eb:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    b5f2:	00 
    b5f3:	e8 a8 ac ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b5f8:	48 8b 15 59 95 01 00 	mov    0x19559(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    b5ff:	49 89 c5             	mov    %rax,%r13
    b602:	48 2b 05 27 95 01 00 	sub    0x19527(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    b609:	48 c1 e2 10          	shl    $0x10,%rdx
    b60d:	48 39 d0             	cmp    %rdx,%rax
    b610:	73 59                	jae    b66b <f0+0x44b>
    b612:	48 89 c2             	mov    %rax,%rdx
    b615:	48 c1 ea 10          	shr    $0x10,%rdx
    b619:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b61d:	48 8b 15 54 95 01 00 	mov    0x19554(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b624:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b628:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b62c:	4d 85 e4             	test   %r12,%r12
    b62f:	74 3a                	je     b66b <f0+0x44b>
    b631:	0f b6 0a             	movzbl (%rdx),%ecx
    b634:	80 f9 02             	cmp    $0x2,%cl
    b637:	0f 84 43 25 00 00    	je     db80 <f0+0x2960>
    b63d:	80 f9 01             	cmp    $0x1,%cl
    b640:	75 29                	jne    b66b <f0+0x44b>
    b642:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b645:	0f b7 c0             	movzwl %ax,%eax
    b648:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b64b:	48 0f af c1          	imul   %rcx,%rax
    b64f:	48 c1 e8 20          	shr    $0x20,%rax
    b653:	48 39 d0             	cmp    %rdx,%rax
    b656:	73 13                	jae    b66b <f0+0x44b>
    b658:	49 01 c4             	add    %rax,%r12
    b65b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b660:	0f 84 f9 26 00 00    	je     dd5f <f0+0x2b3f>
    b666:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b66b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    b672:	00 f0 3f 
    b675:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    b67c:	00 
    b67d:	bf 01 00 00 00       	mov    $0x1,%edi
    b682:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    b689:	00 
    b68a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    b691:	00 
    b692:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    b699:	33 f3 bf 
    b69c:	e8 ff ab ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b6a1:	48 89 c7             	mov    %rax,%rdi
    b6a4:	e8 a7 ad ff ff       	call   6450 <fwp_rc_fresh>
    b6a9:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    b6b0:	00 
    b6b1:	bf 01 00 00 00       	mov    $0x1,%edi
    b6b6:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    b6bd:	00 
    b6be:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    b6c5:	00 
    b6c6:	e8 d5 ab ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b6cb:	48 89 c7             	mov    %rax,%rdi
    b6ce:	e8 7d ad ff ff       	call   6450 <fwp_rc_fresh>
    b6d3:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    b6da:	00 
    b6db:	bf 01 00 00 00       	mov    $0x1,%edi
    b6e0:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    b6e7:	00 
    b6e8:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    b6ef:	00 
    b6f0:	e8 ab ab ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b6f5:	48 89 c7             	mov    %rax,%rdi
    b6f8:	e8 53 ad ff ff       	call   6450 <fwp_rc_fresh>
    b6fd:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    b704:	00 
    b705:	bf 01 00 00 00       	mov    $0x1,%edi
    b70a:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    b711:	00 
    b712:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    b719:	00 
    b71a:	e8 81 ab ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b71f:	48 89 c7             	mov    %rax,%rdi
    b722:	e8 29 ad ff ff       	call   6450 <fwp_rc_fresh>
    b727:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    b72e:	00 
    b72f:	bf 01 00 00 00       	mov    $0x1,%edi
    b734:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    b73b:	00 
    b73c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    b743:	00 
    b744:	e8 57 ab ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b749:	48 89 c7             	mov    %rax,%rdi
    b74c:	e8 ff ac ff ff       	call   6450 <fwp_rc_fresh>
    b751:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    b758:	00 
    b759:	bf 01 00 00 00       	mov    $0x1,%edi
    b75e:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    b765:	00 
    b766:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    b76d:	00 
    b76e:	e8 2d ab ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b773:	48 89 c7             	mov    %rax,%rdi
    b776:	e8 d5 ac ff ff       	call   6450 <fwp_rc_fresh>
    b77b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    b782:	00 
    b783:	bf 01 00 00 00       	mov    $0x1,%edi
    b788:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    b78f:	00 
    b790:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    b797:	00 
    b798:	e8 03 ab ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b79d:	48 89 c7             	mov    %rax,%rdi
    b7a0:	e8 ab ac ff ff       	call   6450 <fwp_rc_fresh>
    b7a5:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    b7ac:	00 
    b7ad:	bf 01 00 00 00       	mov    $0x1,%edi
    b7b2:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    b7b9:	00 
    b7ba:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    b7c1:	00 
    b7c2:	e8 d9 aa ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b7c7:	48 89 c7             	mov    %rax,%rdi
    b7ca:	e8 81 ac ff ff       	call   6450 <fwp_rc_fresh>
    b7cf:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    b7d6:	00 
    b7d7:	bf 01 00 00 00       	mov    $0x1,%edi
    b7dc:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    b7e3:	00 
    b7e4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    b7eb:	00 
    b7ec:	e8 af aa ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b7f1:	48 89 c7             	mov    %rax,%rdi
    b7f4:	e8 57 ac ff ff       	call   6450 <fwp_rc_fresh>
    b7f9:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    b800:	00 
    b801:	bf 01 00 00 00       	mov    $0x1,%edi
    b806:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    b80d:	00 
    b80e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    b815:	00 
    b816:	e8 85 aa ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b81b:	48 89 c7             	mov    %rax,%rdi
    b81e:	e8 2d ac ff ff       	call   6450 <fwp_rc_fresh>
    b823:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    b82a:	00 
    b82b:	bf 01 00 00 00       	mov    $0x1,%edi
    b830:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    b837:	00 
    b838:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    b83f:	00 
    b840:	e8 5b aa ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b845:	48 89 c7             	mov    %rax,%rdi
    b848:	e8 03 ac ff ff       	call   6450 <fwp_rc_fresh>
    b84d:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    b854:	00 
    b855:	bf 01 00 00 00       	mov    $0x1,%edi
    b85a:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    b861:	00 
    b862:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    b869:	00 
    b86a:	e8 31 aa ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b86f:	48 89 c7             	mov    %rax,%rdi
    b872:	e8 d9 ab ff ff       	call   6450 <fwp_rc_fresh>
    b877:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    b87e:	00 
    b87f:	bf 01 00 00 00       	mov    $0x1,%edi
    b884:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    b88b:	00 
    b88c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    b893:	00 
    b894:	e8 07 aa ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b899:	48 89 c7             	mov    %rax,%rdi
    b89c:	e8 af ab ff ff       	call   6450 <fwp_rc_fresh>
    b8a1:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    b8a8:	00 
    b8a9:	bf 01 00 00 00       	mov    $0x1,%edi
    b8ae:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    b8b5:	00 
    b8b6:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    b8bd:	00 
    b8be:	e8 dd a9 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b8c3:	48 89 c7             	mov    %rax,%rdi
    b8c6:	e8 85 ab ff ff       	call   6450 <fwp_rc_fresh>
    b8cb:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    b8d2:	00 
    b8d3:	bf 01 00 00 00       	mov    $0x1,%edi
    b8d8:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    b8df:	00 
    b8e0:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    b8e7:	00 
    b8e8:	e8 b3 a9 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b8ed:	48 89 c7             	mov    %rax,%rdi
    b8f0:	e8 5b ab ff ff       	call   6450 <fwp_rc_fresh>
    b8f5:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    b8fc:	00 
    b8fd:	bf 01 00 00 00       	mov    $0x1,%edi
    b902:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    b909:	00 
    b90a:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    b911:	00 
    b912:	e8 89 a9 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b917:	48 89 c7             	mov    %rax,%rdi
    b91a:	e8 31 ab ff ff       	call   6450 <fwp_rc_fresh>
    b91f:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    b926:	00 
    b927:	bf 01 00 00 00       	mov    $0x1,%edi
    b92c:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    b933:	00 
    b934:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    b93b:	00 
    b93c:	e8 5f a9 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b941:	48 89 c7             	mov    %rax,%rdi
    b944:	e8 07 ab ff ff       	call   6450 <fwp_rc_fresh>
    b949:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    b950:	00 
    b951:	bf 01 00 00 00       	mov    $0x1,%edi
    b956:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    b95d:	00 
    b95e:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    b965:	00 
    b966:	e8 35 a9 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b96b:	48 89 c7             	mov    %rax,%rdi
    b96e:	e8 dd aa ff ff       	call   6450 <fwp_rc_fresh>
    b973:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    b97a:	00 
    b97b:	bf 01 00 00 00       	mov    $0x1,%edi
    b980:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    b987:	00 
    b988:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    b98f:	00 
    b990:	e8 0b a9 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b995:	48 89 c7             	mov    %rax,%rdi
    b998:	e8 b3 aa ff ff       	call   6450 <fwp_rc_fresh>
    b99d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    b9a4:	00 
    b9a5:	bf 01 00 00 00       	mov    $0x1,%edi
    b9aa:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    b9b1:	00 
    b9b2:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    b9b9:	00 
    b9ba:	e8 e1 a8 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b9bf:	48 89 c7             	mov    %rax,%rdi
    b9c2:	e8 89 aa ff ff       	call   6450 <fwp_rc_fresh>
    b9c7:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    b9ce:	00 
    b9cf:	bf 01 00 00 00       	mov    $0x1,%edi
    b9d4:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    b9db:	00 
    b9dc:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    b9e3:	00 
    b9e4:	e8 b7 a8 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    b9e9:	48 89 c7             	mov    %rax,%rdi
    b9ec:	e8 5f aa ff ff       	call   6450 <fwp_rc_fresh>
    b9f1:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    b9f8:	00 
    b9f9:	bf 01 00 00 00       	mov    $0x1,%edi
    b9fe:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    ba05:	00 
    ba06:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    ba0d:	00 
    ba0e:	e8 8d a8 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    ba13:	48 89 c7             	mov    %rax,%rdi
    ba16:	e8 35 aa ff ff       	call   6450 <fwp_rc_fresh>
    ba1b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    ba22:	00 
    ba23:	bf 01 00 00 00       	mov    $0x1,%edi
    ba28:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    ba2f:	00 
    ba30:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    ba37:	00 
    ba38:	e8 63 a8 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    ba3d:	48 89 c7             	mov    %rax,%rdi
    ba40:	e8 0b aa ff ff       	call   6450 <fwp_rc_fresh>
    ba45:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    ba4c:	00 
    ba4d:	bf 01 00 00 00       	mov    $0x1,%edi
    ba52:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    ba59:	00 
    ba5a:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    ba61:	00 
    ba62:	e8 39 a8 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    ba67:	48 89 c7             	mov    %rax,%rdi
    ba6a:	e8 e1 a9 ff ff       	call   6450 <fwp_rc_fresh>
    ba6f:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    ba76:	00 
    ba77:	bf 01 00 00 00       	mov    $0x1,%edi
    ba7c:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    ba83:	00 
    ba84:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    ba8b:	00 
    ba8c:	e8 0f a8 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    ba91:	48 89 c7             	mov    %rax,%rdi
    ba94:	e8 b7 a9 ff ff       	call   6450 <fwp_rc_fresh>
    ba99:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    baa0:	00 
    baa1:	bf 01 00 00 00       	mov    $0x1,%edi
    baa6:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    baad:	00 
    baae:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    bab5:	00 
    bab6:	e8 e5 a7 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    babb:	48 89 c7             	mov    %rax,%rdi
    babe:	e8 8d a9 ff ff       	call   6450 <fwp_rc_fresh>
    bac3:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    baca:	00 
    bacb:	bf 01 00 00 00       	mov    $0x1,%edi
    bad0:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    bad7:	00 
    bad8:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    badf:	00 
    bae0:	e8 bb a7 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bae5:	48 89 c7             	mov    %rax,%rdi
    bae8:	e8 63 a9 ff ff       	call   6450 <fwp_rc_fresh>
    baed:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    baf4:	00 
    baf5:	bf 01 00 00 00       	mov    $0x1,%edi
    bafa:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    bb01:	00 
    bb02:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    bb09:	00 
    bb0a:	e8 91 a7 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bb0f:	48 89 c7             	mov    %rax,%rdi
    bb12:	e8 39 a9 ff ff       	call   6450 <fwp_rc_fresh>
    bb17:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    bb1e:	00 
    bb1f:	bf 01 00 00 00       	mov    $0x1,%edi
    bb24:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    bb2b:	00 
    bb2c:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    bb33:	00 
    bb34:	e8 67 a7 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bb39:	48 89 c7             	mov    %rax,%rdi
    bb3c:	e8 0f a9 ff ff       	call   6450 <fwp_rc_fresh>
    bb41:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    bb48:	00 
    bb49:	bf 01 00 00 00       	mov    $0x1,%edi
    bb4e:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    bb55:	00 
    bb56:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    bb5d:	00 
    bb5e:	e8 3d a7 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bb63:	48 89 c7             	mov    %rax,%rdi
    bb66:	e8 e5 a8 ff ff       	call   6450 <fwp_rc_fresh>
    bb6b:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    bb72:	00 
    bb73:	bf 01 00 00 00       	mov    $0x1,%edi
    bb78:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    bb7f:	00 
    bb80:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    bb87:	00 
    bb88:	e8 13 a7 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bb8d:	48 89 c7             	mov    %rax,%rdi
    bb90:	e8 bb a8 ff ff       	call   6450 <fwp_rc_fresh>
    bb95:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    bb9c:	00 
    bb9d:	bf 01 00 00 00       	mov    $0x1,%edi
    bba2:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    bba9:	00 
    bbaa:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    bbb1:	00 
    bbb2:	e8 e9 a6 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bbb7:	48 89 c7             	mov    %rax,%rdi
    bbba:	e8 91 a8 ff ff       	call   6450 <fwp_rc_fresh>
    bbbf:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    bbc6:	00 
    bbc7:	bf 01 00 00 00       	mov    $0x1,%edi
    bbcc:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    bbd3:	00 
    bbd4:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    bbdb:	00 
    bbdc:	e8 bf a6 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bbe1:	48 89 c7             	mov    %rax,%rdi
    bbe4:	e8 67 a8 ff ff       	call   6450 <fwp_rc_fresh>
    bbe9:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    bbf0:	00 
    bbf1:	bf 01 00 00 00       	mov    $0x1,%edi
    bbf6:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    bbfd:	00 
    bbfe:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    bc05:	00 
    bc06:	e8 95 a6 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bc0b:	48 89 c7             	mov    %rax,%rdi
    bc0e:	e8 3d a8 ff ff       	call   6450 <fwp_rc_fresh>
    bc13:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    bc1a:	00 
    bc1b:	bf 01 00 00 00       	mov    $0x1,%edi
    bc20:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    bc27:	00 
    bc28:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    bc2f:	00 
    bc30:	e8 6b a6 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bc35:	48 89 c7             	mov    %rax,%rdi
    bc38:	e8 13 a8 ff ff       	call   6450 <fwp_rc_fresh>
    bc3d:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    bc44:	00 
    bc45:	bf 01 00 00 00       	mov    $0x1,%edi
    bc4a:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    bc51:	00 
    bc52:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    bc59:	00 
    bc5a:	e8 41 a6 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bc5f:	48 89 c7             	mov    %rax,%rdi
    bc62:	e8 e9 a7 ff ff       	call   6450 <fwp_rc_fresh>
    bc67:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    bc6e:	00 
    bc6f:	bf 01 00 00 00       	mov    $0x1,%edi
    bc74:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    bc7b:	00 
    bc7c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    bc83:	00 
    bc84:	e8 17 a6 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bc89:	48 89 c7             	mov    %rax,%rdi
    bc8c:	e8 bf a7 ff ff       	call   6450 <fwp_rc_fresh>
    bc91:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    bc98:	00 
    bc99:	bf 01 00 00 00       	mov    $0x1,%edi
    bc9e:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    bca5:	00 
    bca6:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    bcad:	00 
    bcae:	e8 ed a5 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bcb3:	48 89 c7             	mov    %rax,%rdi
    bcb6:	e8 95 a7 ff ff       	call   6450 <fwp_rc_fresh>
    bcbb:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    bcc2:	00 
    bcc3:	bf 01 00 00 00       	mov    $0x1,%edi
    bcc8:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    bccf:	00 
    bcd0:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    bcd7:	00 
    bcd8:	e8 c3 a5 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bcdd:	48 89 c7             	mov    %rax,%rdi
    bce0:	e8 6b a7 ff ff       	call   6450 <fwp_rc_fresh>
    bce5:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    bcec:	00 
    bced:	bf 01 00 00 00       	mov    $0x1,%edi
    bcf2:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    bcf9:	00 
    bcfa:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    bd01:	00 
    bd02:	e8 99 a5 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bd07:	48 89 c7             	mov    %rax,%rdi
    bd0a:	e8 41 a7 ff ff       	call   6450 <fwp_rc_fresh>
    bd0f:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    bd16:	00 
    bd17:	bf 01 00 00 00       	mov    $0x1,%edi
    bd1c:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    bd23:	00 
    bd24:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    bd2b:	00 
    bd2c:	e8 6f a5 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bd31:	48 89 c7             	mov    %rax,%rdi
    bd34:	e8 17 a7 ff ff       	call   6450 <fwp_rc_fresh>
    bd39:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    bd40:	00 
    bd41:	bf 01 00 00 00       	mov    $0x1,%edi
    bd46:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    bd4d:	00 
    bd4e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    bd55:	00 
    bd56:	e8 45 a5 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bd5b:	48 89 c7             	mov    %rax,%rdi
    bd5e:	e8 ed a6 ff ff       	call   6450 <fwp_rc_fresh>
    bd63:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    bd6a:	00 
    bd6b:	bf 01 00 00 00       	mov    $0x1,%edi
    bd70:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    bd77:	00 
    bd78:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    bd7f:	00 
    bd80:	e8 1b a5 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bd85:	48 89 c7             	mov    %rax,%rdi
    bd88:	e8 c3 a6 ff ff       	call   6450 <fwp_rc_fresh>
    bd8d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    bd94:	00 
    bd95:	bf 01 00 00 00       	mov    $0x1,%edi
    bd9a:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    bda1:	00 
    bda2:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    bda9:	00 
    bdaa:	e8 f1 a4 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bdaf:	48 89 c7             	mov    %rax,%rdi
    bdb2:	e8 99 a6 ff ff       	call   6450 <fwp_rc_fresh>
    bdb7:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    bdbe:	00 
    bdbf:	bf 01 00 00 00       	mov    $0x1,%edi
    bdc4:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    bdcb:	00 
    bdcc:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    bdd3:	00 
    bdd4:	e8 c7 a4 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bdd9:	48 89 c7             	mov    %rax,%rdi
    bddc:	e8 6f a6 ff ff       	call   6450 <fwp_rc_fresh>
    bde1:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    bde8:	00 
    bde9:	bf 01 00 00 00       	mov    $0x1,%edi
    bdee:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    bdf5:	00 
    bdf6:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    bdfd:	00 
    bdfe:	e8 9d a4 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    be03:	48 89 c7             	mov    %rax,%rdi
    be06:	e8 45 a6 ff ff       	call   6450 <fwp_rc_fresh>
    be0b:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    be12:	00 
    be13:	bf 01 00 00 00       	mov    $0x1,%edi
    be18:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    be1f:	00 
    be20:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    be27:	00 
    be28:	e8 73 a4 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    be2d:	48 89 c7             	mov    %rax,%rdi
    be30:	e8 1b a6 ff ff       	call   6450 <fwp_rc_fresh>
    be35:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    be3c:	00 
    be3d:	bf 01 00 00 00       	mov    $0x1,%edi
    be42:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    be49:	00 
    be4a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    be51:	00 
    be52:	e8 49 a4 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    be57:	48 89 c7             	mov    %rax,%rdi
    be5a:	e8 f1 a5 ff ff       	call   6450 <fwp_rc_fresh>
    be5f:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    be66:	00 
    be67:	bf 01 00 00 00       	mov    $0x1,%edi
    be6c:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    be73:	00 
    be74:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    be7b:	00 
    be7c:	e8 1f a4 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    be81:	48 89 c7             	mov    %rax,%rdi
    be84:	e8 c7 a5 ff ff       	call   6450 <fwp_rc_fresh>
    be89:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    be90:	00 
    be91:	bf 01 00 00 00       	mov    $0x1,%edi
    be96:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    be9d:	00 
    be9e:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    bea5:	00 
    bea6:	e8 f5 a3 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    beab:	48 89 c7             	mov    %rax,%rdi
    beae:	e8 9d a5 ff ff       	call   6450 <fwp_rc_fresh>
    beb3:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    beba:	00 
    bebb:	bf 01 00 00 00       	mov    $0x1,%edi
    bec0:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    bec7:	00 
    bec8:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    becf:	00 
    bed0:	e8 cb a3 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bed5:	48 89 c7             	mov    %rax,%rdi
    bed8:	e8 73 a5 ff ff       	call   6450 <fwp_rc_fresh>
    bedd:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    bee4:	00 
    bee5:	bf 01 00 00 00       	mov    $0x1,%edi
    beea:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    bef1:	00 
    bef2:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    bef9:	00 
    befa:	e8 a1 a3 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    beff:	48 89 c7             	mov    %rax,%rdi
    bf02:	e8 49 a5 ff ff       	call   6450 <fwp_rc_fresh>
    bf07:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    bf0e:	00 
    bf0f:	bf 01 00 00 00       	mov    $0x1,%edi
    bf14:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    bf1b:	00 
    bf1c:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    bf23:	00 
    bf24:	e8 77 a3 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bf29:	48 89 c7             	mov    %rax,%rdi
    bf2c:	e8 1f a5 ff ff       	call   6450 <fwp_rc_fresh>
    bf31:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    bf38:	00 
    bf39:	bf 01 00 00 00       	mov    $0x1,%edi
    bf3e:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    bf45:	00 
    bf46:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    bf4d:	00 
    bf4e:	e8 4d a3 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bf53:	48 89 c7             	mov    %rax,%rdi
    bf56:	e8 f5 a4 ff ff       	call   6450 <fwp_rc_fresh>
    bf5b:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    bf62:	00 
    bf63:	bf 01 00 00 00       	mov    $0x1,%edi
    bf68:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    bf6f:	00 
    bf70:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    bf77:	00 
    bf78:	e8 23 a3 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bf7d:	48 89 c7             	mov    %rax,%rdi
    bf80:	e8 cb a4 ff ff       	call   6450 <fwp_rc_fresh>
    bf85:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    bf8c:	00 
    bf8d:	bf 01 00 00 00       	mov    $0x1,%edi
    bf92:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    bf99:	00 
    bf9a:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    bfa1:	00 
    bfa2:	e8 f9 a2 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bfa7:	48 89 c7             	mov    %rax,%rdi
    bfaa:	e8 a1 a4 ff ff       	call   6450 <fwp_rc_fresh>
    bfaf:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    bfb6:	00 
    bfb7:	bf 01 00 00 00       	mov    $0x1,%edi
    bfbc:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    bfc3:	00 
    bfc4:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    bfcb:	00 
    bfcc:	e8 cf a2 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bfd1:	48 89 c7             	mov    %rax,%rdi
    bfd4:	e8 77 a4 ff ff       	call   6450 <fwp_rc_fresh>
    bfd9:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    bfe0:	00 
    bfe1:	bf 01 00 00 00       	mov    $0x1,%edi
    bfe6:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    bfed:	00 
    bfee:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    bff5:	00 
    bff6:	e8 a5 a2 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    bffb:	48 89 c7             	mov    %rax,%rdi
    bffe:	e8 4d a4 ff ff       	call   6450 <fwp_rc_fresh>
    c003:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    c00a:	00 
    c00b:	bf 01 00 00 00       	mov    $0x1,%edi
    c010:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    c017:	00 
    c018:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    c01f:	00 
    c020:	e8 7b a2 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c025:	48 89 c7             	mov    %rax,%rdi
    c028:	e8 23 a4 ff ff       	call   6450 <fwp_rc_fresh>
    c02d:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    c034:	00 
    c035:	bf 01 00 00 00       	mov    $0x1,%edi
    c03a:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    c041:	00 
    c042:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    c049:	00 
    c04a:	e8 51 a2 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c04f:	48 89 c7             	mov    %rax,%rdi
    c052:	e8 f9 a3 ff ff       	call   6450 <fwp_rc_fresh>
    c057:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    c05e:	00 
    c05f:	bf 01 00 00 00       	mov    $0x1,%edi
    c064:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    c06b:	00 
    c06c:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    c073:	00 
    c074:	e8 27 a2 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c079:	48 89 c7             	mov    %rax,%rdi
    c07c:	e8 cf a3 ff ff       	call   6450 <fwp_rc_fresh>
    c081:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    c088:	00 
    c089:	bf 01 00 00 00       	mov    $0x1,%edi
    c08e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    c095:	00 
    c096:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    c09d:	00 
    c09e:	e8 fd a1 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c0a3:	48 89 c7             	mov    %rax,%rdi
    c0a6:	e8 a5 a3 ff ff       	call   6450 <fwp_rc_fresh>
    c0ab:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    c0b2:	00 
    c0b3:	bf 01 00 00 00       	mov    $0x1,%edi
    c0b8:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    c0bf:	00 
    c0c0:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    c0c7:	00 
    c0c8:	e8 d3 a1 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c0cd:	48 89 c7             	mov    %rax,%rdi
    c0d0:	e8 7b a3 ff ff       	call   6450 <fwp_rc_fresh>
    c0d5:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    c0dc:	00 
    c0dd:	bf 01 00 00 00       	mov    $0x1,%edi
    c0e2:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    c0e9:	00 
    c0ea:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    c0f1:	00 
    c0f2:	e8 a9 a1 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c0f7:	48 89 c7             	mov    %rax,%rdi
    c0fa:	e8 51 a3 ff ff       	call   6450 <fwp_rc_fresh>
    c0ff:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    c106:	00 
    c107:	bf 01 00 00 00       	mov    $0x1,%edi
    c10c:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    c113:	00 
    c114:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    c11b:	00 
    c11c:	e8 7f a1 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c121:	48 89 c7             	mov    %rax,%rdi
    c124:	e8 27 a3 ff ff       	call   6450 <fwp_rc_fresh>
    c129:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    c130:	00 
    c131:	bf 01 00 00 00       	mov    $0x1,%edi
    c136:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    c13d:	00 
    c13e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    c145:	00 
    c146:	e8 55 a1 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c14b:	48 89 c7             	mov    %rax,%rdi
    c14e:	e8 fd a2 ff ff       	call   6450 <fwp_rc_fresh>
    c153:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    c15a:	00 
    c15b:	bf 01 00 00 00       	mov    $0x1,%edi
    c160:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    c167:	00 
    c168:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    c16f:	00 
    c170:	e8 2b a1 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c175:	48 89 c7             	mov    %rax,%rdi
    c178:	e8 d3 a2 ff ff       	call   6450 <fwp_rc_fresh>
    c17d:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    c184:	00 
    c185:	bf 01 00 00 00       	mov    $0x1,%edi
    c18a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    c191:	00 
    c192:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    c199:	00 
    c19a:	e8 01 a1 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c19f:	48 89 c7             	mov    %rax,%rdi
    c1a2:	e8 a9 a2 ff ff       	call   6450 <fwp_rc_fresh>
    c1a7:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    c1ae:	00 
    c1af:	bf 01 00 00 00       	mov    $0x1,%edi
    c1b4:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    c1bb:	00 
    c1bc:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    c1c3:	00 
    c1c4:	e8 d7 a0 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c1c9:	48 89 c7             	mov    %rax,%rdi
    c1cc:	e8 7f a2 ff ff       	call   6450 <fwp_rc_fresh>
    c1d1:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    c1d8:	00 
    c1d9:	bf 01 00 00 00       	mov    $0x1,%edi
    c1de:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    c1e5:	00 
    c1e6:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    c1ed:	00 
    c1ee:	e8 ad a0 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c1f3:	48 89 c7             	mov    %rax,%rdi
    c1f6:	e8 55 a2 ff ff       	call   6450 <fwp_rc_fresh>
    c1fb:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    c202:	00 
    c203:	bf 01 00 00 00       	mov    $0x1,%edi
    c208:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    c20f:	00 
    c210:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    c217:	00 
    c218:	e8 83 a0 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c21d:	48 89 c7             	mov    %rax,%rdi
    c220:	e8 2b a2 ff ff       	call   6450 <fwp_rc_fresh>
    c225:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    c22c:	00 
    c22d:	bf 01 00 00 00       	mov    $0x1,%edi
    c232:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    c239:	00 
    c23a:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    c241:	00 
    c242:	e8 59 a0 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c247:	48 89 c7             	mov    %rax,%rdi
    c24a:	e8 01 a2 ff ff       	call   6450 <fwp_rc_fresh>
    c24f:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    c256:	00 
    c257:	bf 01 00 00 00       	mov    $0x1,%edi
    c25c:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    c263:	00 
    c264:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    c26b:	00 
    c26c:	e8 2f a0 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c271:	48 89 c7             	mov    %rax,%rdi
    c274:	e8 d7 a1 ff ff       	call   6450 <fwp_rc_fresh>
    c279:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    c280:	00 
    c281:	bf 01 00 00 00       	mov    $0x1,%edi
    c286:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    c28d:	00 
    c28e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    c295:	00 
    c296:	e8 05 a0 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c29b:	48 89 c7             	mov    %rax,%rdi
    c29e:	e8 ad a1 ff ff       	call   6450 <fwp_rc_fresh>
    c2a3:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    c2aa:	00 
    c2ab:	bf 01 00 00 00       	mov    $0x1,%edi
    c2b0:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    c2b7:	00 
    c2b8:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    c2bf:	00 
    c2c0:	e8 db 9f ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c2c5:	48 89 c7             	mov    %rax,%rdi
    c2c8:	e8 83 a1 ff ff       	call   6450 <fwp_rc_fresh>
    c2cd:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    c2d4:	00 
    c2d5:	bf 01 00 00 00       	mov    $0x1,%edi
    c2da:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    c2e1:	00 
    c2e2:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    c2e9:	00 
    c2ea:	e8 b1 9f ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c2ef:	48 89 c7             	mov    %rax,%rdi
    c2f2:	e8 59 a1 ff ff       	call   6450 <fwp_rc_fresh>
    c2f7:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    c2fe:	00 
    c2ff:	bf 01 00 00 00       	mov    $0x1,%edi
    c304:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    c30b:	00 
    c30c:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    c313:	00 
    c314:	e8 87 9f ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c319:	48 89 c7             	mov    %rax,%rdi
    c31c:	e8 2f a1 ff ff       	call   6450 <fwp_rc_fresh>
    c321:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    c328:	00 
    c329:	bf 01 00 00 00       	mov    $0x1,%edi
    c32e:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    c335:	00 
    c336:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    c33d:	00 
    c33e:	e8 5d 9f ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c343:	48 89 c7             	mov    %rax,%rdi
    c346:	e8 05 a1 ff ff       	call   6450 <fwp_rc_fresh>
    c34b:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    c352:	00 
    c353:	bf 01 00 00 00       	mov    $0x1,%edi
    c358:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    c35f:	00 
    c360:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    c367:	00 
    c368:	e8 33 9f ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c36d:	48 89 c7             	mov    %rax,%rdi
    c370:	e8 db a0 ff ff       	call   6450 <fwp_rc_fresh>
    c375:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    c37c:	00 
    c37d:	bf 01 00 00 00       	mov    $0x1,%edi
    c382:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    c389:	00 
    c38a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    c391:	00 
    c392:	e8 09 9f ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c397:	48 89 c7             	mov    %rax,%rdi
    c39a:	e8 b1 a0 ff ff       	call   6450 <fwp_rc_fresh>
    c39f:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    c3a6:	00 
    c3a7:	bf 01 00 00 00       	mov    $0x1,%edi
    c3ac:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    c3b3:	00 
    c3b4:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    c3bb:	00 
    c3bc:	e8 df 9e ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c3c1:	48 89 c7             	mov    %rax,%rdi
    c3c4:	e8 87 a0 ff ff       	call   6450 <fwp_rc_fresh>
    c3c9:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    c3d0:	00 
    c3d1:	bf 01 00 00 00       	mov    $0x1,%edi
    c3d6:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    c3dd:	00 
    c3de:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    c3e5:	00 
    c3e6:	e8 b5 9e ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c3eb:	48 89 c7             	mov    %rax,%rdi
    c3ee:	e8 5d a0 ff ff       	call   6450 <fwp_rc_fresh>
    c3f3:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    c3fa:	00 
    c3fb:	bf 01 00 00 00       	mov    $0x1,%edi
    c400:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    c407:	00 
    c408:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    c40f:	00 
    c410:	e8 8b 9e ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c415:	48 89 c7             	mov    %rax,%rdi
    c418:	e8 33 a0 ff ff       	call   6450 <fwp_rc_fresh>
    c41d:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    c424:	00 
    c425:	bf 01 00 00 00       	mov    $0x1,%edi
    c42a:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    c431:	00 
    c432:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    c439:	00 
    c43a:	e8 61 9e ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c43f:	48 89 c7             	mov    %rax,%rdi
    c442:	e8 09 a0 ff ff       	call   6450 <fwp_rc_fresh>
    c447:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    c44e:	00 
    c44f:	bf 01 00 00 00       	mov    $0x1,%edi
    c454:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    c45b:	00 
    c45c:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    c463:	00 
    c464:	e8 37 9e ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c469:	48 89 c7             	mov    %rax,%rdi
    c46c:	e8 df 9f ff ff       	call   6450 <fwp_rc_fresh>
    c471:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    c478:	00 
    c479:	bf 01 00 00 00       	mov    $0x1,%edi
    c47e:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    c485:	00 
    c486:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    c48d:	00 
    c48e:	e8 0d 9e ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c493:	48 89 c7             	mov    %rax,%rdi
    c496:	e8 b5 9f ff ff       	call   6450 <fwp_rc_fresh>
    c49b:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    c4a2:	00 
    c4a3:	bf 01 00 00 00       	mov    $0x1,%edi
    c4a8:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    c4af:	00 
    c4b0:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    c4b7:	00 
    c4b8:	e8 e3 9d ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c4bd:	48 89 c7             	mov    %rax,%rdi
    c4c0:	e8 8b 9f ff ff       	call   6450 <fwp_rc_fresh>
    c4c5:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    c4cc:	00 
    c4cd:	bf 01 00 00 00       	mov    $0x1,%edi
    c4d2:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    c4d9:	00 
    c4da:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    c4e1:	00 
    c4e2:	e8 b9 9d ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c4e7:	48 89 c7             	mov    %rax,%rdi
    c4ea:	e8 61 9f ff ff       	call   6450 <fwp_rc_fresh>
    c4ef:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    c4f6:	00 
    c4f7:	bf 01 00 00 00       	mov    $0x1,%edi
    c4fc:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    c503:	00 
    c504:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    c50b:	00 
    c50c:	e8 8f 9d ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c511:	48 89 c7             	mov    %rax,%rdi
    c514:	e8 37 9f ff ff       	call   6450 <fwp_rc_fresh>
    c519:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c520:	00 
    c521:	bf 01 00 00 00       	mov    $0x1,%edi
    c526:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c52d:	00 
    c52e:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c535:	00 
    c536:	e8 65 9d ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c53b:	48 89 c7             	mov    %rax,%rdi
    c53e:	e8 0d 9f ff ff       	call   6450 <fwp_rc_fresh>
    c543:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    c54a:	00 
    c54b:	bf 01 00 00 00       	mov    $0x1,%edi
    c550:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    c557:	00 
    c558:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    c55f:	00 
    c560:	e8 3b 9d ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c565:	48 8b 15 ec 85 01 00 	mov    0x185ec(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c56c:	49 89 c5             	mov    %rax,%r13
    c56f:	48 2b 05 ba 85 01 00 	sub    0x185ba(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c576:	48 c1 e2 10          	shl    $0x10,%rdx
    c57a:	48 39 d0             	cmp    %rdx,%rax
    c57d:	73 59                	jae    c5d8 <f0+0x13b8>
    c57f:	48 89 c2             	mov    %rax,%rdx
    c582:	48 c1 ea 10          	shr    $0x10,%rdx
    c586:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c58a:	48 8b 15 e7 85 01 00 	mov    0x185e7(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c591:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c595:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c599:	4d 85 e4             	test   %r12,%r12
    c59c:	74 3a                	je     c5d8 <f0+0x13b8>
    c59e:	0f b6 0a             	movzbl (%rdx),%ecx
    c5a1:	80 f9 02             	cmp    $0x2,%cl
    c5a4:	0f 84 c6 15 00 00    	je     db70 <f0+0x2950>
    c5aa:	80 f9 01             	cmp    $0x1,%cl
    c5ad:	75 29                	jne    c5d8 <f0+0x13b8>
    c5af:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c5b2:	0f b7 c0             	movzwl %ax,%eax
    c5b5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c5b8:	48 0f af c1          	imul   %rcx,%rax
    c5bc:	48 c1 e8 20          	shr    $0x20,%rax
    c5c0:	48 39 d0             	cmp    %rdx,%rax
    c5c3:	73 13                	jae    c5d8 <f0+0x13b8>
    c5c5:	49 01 c4             	add    %rax,%r12
    c5c8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c5cd:	0f 84 99 17 00 00    	je     dd6c <f0+0x2b4c>
    c5d3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c5d8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c5df:	33 f3 bf 
    c5e2:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    c5e9:	00 
    c5ea:	bf 01 00 00 00       	mov    $0x1,%edi
    c5ef:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    c5f6:	00 
    c5f7:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    c5fe:	00 
    c5ff:	e8 9c 9c ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c604:	48 8b 15 4d 85 01 00 	mov    0x1854d(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c60b:	49 89 c5             	mov    %rax,%r13
    c60e:	48 2b 05 1b 85 01 00 	sub    0x1851b(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c615:	48 c1 e2 10          	shl    $0x10,%rdx
    c619:	48 39 d0             	cmp    %rdx,%rax
    c61c:	73 59                	jae    c677 <f0+0x1457>
    c61e:	48 89 c2             	mov    %rax,%rdx
    c621:	48 c1 ea 10          	shr    $0x10,%rdx
    c625:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c629:	48 8b 15 48 85 01 00 	mov    0x18548(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c630:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c634:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c638:	4d 85 e4             	test   %r12,%r12
    c63b:	74 3a                	je     c677 <f0+0x1457>
    c63d:	0f b6 0a             	movzbl (%rdx),%ecx
    c640:	80 f9 02             	cmp    $0x2,%cl
    c643:	0f 84 17 15 00 00    	je     db60 <f0+0x2940>
    c649:	80 f9 01             	cmp    $0x1,%cl
    c64c:	75 29                	jne    c677 <f0+0x1457>
    c64e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c651:	0f b7 c0             	movzwl %ax,%eax
    c654:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c657:	48 0f af c1          	imul   %rcx,%rax
    c65b:	48 c1 e8 20          	shr    $0x20,%rax
    c65f:	48 39 d0             	cmp    %rdx,%rax
    c662:	73 13                	jae    c677 <f0+0x1457>
    c664:	49 01 c4             	add    %rax,%r12
    c667:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c66c:	0f 84 07 17 00 00    	je     dd79 <f0+0x2b59>
    c672:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c677:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c67e:	00 f0 3f 
    c681:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    c688:	00 
    c689:	bf 01 00 00 00       	mov    $0x1,%edi
    c68e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    c695:	00 
    c696:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    c69d:	00 
    c69e:	e8 fd 9b ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c6a3:	48 8b 15 ae 84 01 00 	mov    0x184ae(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c6aa:	49 89 c5             	mov    %rax,%r13
    c6ad:	48 2b 05 7c 84 01 00 	sub    0x1847c(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c6b4:	48 c1 e2 10          	shl    $0x10,%rdx
    c6b8:	48 39 d0             	cmp    %rdx,%rax
    c6bb:	73 59                	jae    c716 <f0+0x14f6>
    c6bd:	48 89 c2             	mov    %rax,%rdx
    c6c0:	48 c1 ea 10          	shr    $0x10,%rdx
    c6c4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c6c8:	48 8b 15 a9 84 01 00 	mov    0x184a9(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c6cf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c6d3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c6d7:	4d 85 e4             	test   %r12,%r12
    c6da:	74 3a                	je     c716 <f0+0x14f6>
    c6dc:	0f b6 0a             	movzbl (%rdx),%ecx
    c6df:	80 f9 02             	cmp    $0x2,%cl
    c6e2:	0f 84 28 15 00 00    	je     dc10 <f0+0x29f0>
    c6e8:	80 f9 01             	cmp    $0x1,%cl
    c6eb:	75 29                	jne    c716 <f0+0x14f6>
    c6ed:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c6f0:	0f b7 c0             	movzwl %ax,%eax
    c6f3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c6f6:	48 0f af c1          	imul   %rcx,%rax
    c6fa:	48 c1 e8 20          	shr    $0x20,%rax
    c6fe:	48 39 d0             	cmp    %rdx,%rax
    c701:	73 13                	jae    c716 <f0+0x14f6>
    c703:	49 01 c4             	add    %rax,%r12
    c706:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c70b:	0f 84 75 16 00 00    	je     dd86 <f0+0x2b66>
    c711:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c716:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c71d:	33 f3 bf 
    c720:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    c727:	00 
    c728:	bf 01 00 00 00       	mov    $0x1,%edi
    c72d:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    c734:	00 
    c735:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    c73c:	00 
    c73d:	e8 5e 9b ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c742:	48 8b 15 0f 84 01 00 	mov    0x1840f(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c749:	49 89 c5             	mov    %rax,%r13
    c74c:	48 2b 05 dd 83 01 00 	sub    0x183dd(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c753:	48 c1 e2 10          	shl    $0x10,%rdx
    c757:	48 39 d0             	cmp    %rdx,%rax
    c75a:	73 59                	jae    c7b5 <f0+0x1595>
    c75c:	48 89 c2             	mov    %rax,%rdx
    c75f:	48 c1 ea 10          	shr    $0x10,%rdx
    c763:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c767:	48 8b 15 0a 84 01 00 	mov    0x1840a(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c76e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c772:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c776:	4d 85 e4             	test   %r12,%r12
    c779:	74 3a                	je     c7b5 <f0+0x1595>
    c77b:	0f b6 0a             	movzbl (%rdx),%ecx
    c77e:	80 f9 02             	cmp    $0x2,%cl
    c781:	0f 84 79 14 00 00    	je     dc00 <f0+0x29e0>
    c787:	80 f9 01             	cmp    $0x1,%cl
    c78a:	75 29                	jne    c7b5 <f0+0x1595>
    c78c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c78f:	0f b7 c0             	movzwl %ax,%eax
    c792:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c795:	48 0f af c1          	imul   %rcx,%rax
    c799:	48 c1 e8 20          	shr    $0x20,%rax
    c79d:	48 39 d0             	cmp    %rdx,%rax
    c7a0:	73 13                	jae    c7b5 <f0+0x1595>
    c7a2:	49 01 c4             	add    %rax,%r12
    c7a5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c7aa:	0f 84 e3 15 00 00    	je     dd93 <f0+0x2b73>
    c7b0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c7b5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c7bc:	00 f0 3f 
    c7bf:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    c7c6:	00 
    c7c7:	bf 01 00 00 00       	mov    $0x1,%edi
    c7cc:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    c7d3:	00 
    c7d4:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    c7db:	00 
    c7dc:	e8 bf 9a ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c7e1:	48 8b 15 70 83 01 00 	mov    0x18370(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c7e8:	49 89 c5             	mov    %rax,%r13
    c7eb:	48 2b 05 3e 83 01 00 	sub    0x1833e(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c7f2:	48 c1 e2 10          	shl    $0x10,%rdx
    c7f6:	48 39 d0             	cmp    %rdx,%rax
    c7f9:	73 59                	jae    c854 <f0+0x1634>
    c7fb:	48 89 c2             	mov    %rax,%rdx
    c7fe:	48 c1 ea 10          	shr    $0x10,%rdx
    c802:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c806:	48 8b 15 6b 83 01 00 	mov    0x1836b(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c80d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c811:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c815:	4d 85 e4             	test   %r12,%r12
    c818:	74 3a                	je     c854 <f0+0x1634>
    c81a:	0f b6 0a             	movzbl (%rdx),%ecx
    c81d:	80 f9 02             	cmp    $0x2,%cl
    c820:	0f 84 ca 13 00 00    	je     dbf0 <f0+0x29d0>
    c826:	80 f9 01             	cmp    $0x1,%cl
    c829:	75 29                	jne    c854 <f0+0x1634>
    c82b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c82e:	0f b7 c0             	movzwl %ax,%eax
    c831:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c834:	48 0f af c1          	imul   %rcx,%rax
    c838:	48 c1 e8 20          	shr    $0x20,%rax
    c83c:	48 39 d0             	cmp    %rdx,%rax
    c83f:	73 13                	jae    c854 <f0+0x1634>
    c841:	49 01 c4             	add    %rax,%r12
    c844:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c849:	0f 84 51 15 00 00    	je     dda0 <f0+0x2b80>
    c84f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c854:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c85b:	33 f3 bf 
    c85e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    c865:	00 
    c866:	bf 01 00 00 00       	mov    $0x1,%edi
    c86b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    c872:	00 
    c873:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    c87a:	00 
    c87b:	e8 20 9a ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c880:	48 8b 15 d1 82 01 00 	mov    0x182d1(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c887:	49 89 c5             	mov    %rax,%r13
    c88a:	48 2b 05 9f 82 01 00 	sub    0x1829f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c891:	48 c1 e2 10          	shl    $0x10,%rdx
    c895:	48 39 d0             	cmp    %rdx,%rax
    c898:	73 59                	jae    c8f3 <f0+0x16d3>
    c89a:	48 89 c2             	mov    %rax,%rdx
    c89d:	48 c1 ea 10          	shr    $0x10,%rdx
    c8a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c8a5:	48 8b 15 cc 82 01 00 	mov    0x182cc(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c8ac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c8b0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c8b4:	4d 85 e4             	test   %r12,%r12
    c8b7:	74 3a                	je     c8f3 <f0+0x16d3>
    c8b9:	0f b6 0a             	movzbl (%rdx),%ecx
    c8bc:	80 f9 02             	cmp    $0x2,%cl
    c8bf:	0f 84 1b 13 00 00    	je     dbe0 <f0+0x29c0>
    c8c5:	80 f9 01             	cmp    $0x1,%cl
    c8c8:	75 29                	jne    c8f3 <f0+0x16d3>
    c8ca:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c8cd:	0f b7 c0             	movzwl %ax,%eax
    c8d0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c8d3:	48 0f af c1          	imul   %rcx,%rax
    c8d7:	48 c1 e8 20          	shr    $0x20,%rax
    c8db:	48 39 d0             	cmp    %rdx,%rax
    c8de:	73 13                	jae    c8f3 <f0+0x16d3>
    c8e0:	49 01 c4             	add    %rax,%r12
    c8e3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c8e8:	0f 84 bf 14 00 00    	je     ddad <f0+0x2b8d>
    c8ee:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c8f3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c8fa:	00 f0 3f 
    c8fd:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    c904:	00 
    c905:	bf 01 00 00 00       	mov    $0x1,%edi
    c90a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    c911:	00 
    c912:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    c919:	00 
    c91a:	e8 81 99 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c91f:	48 8b 15 32 82 01 00 	mov    0x18232(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c926:	49 89 c5             	mov    %rax,%r13
    c929:	48 2b 05 00 82 01 00 	sub    0x18200(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c930:	48 c1 e2 10          	shl    $0x10,%rdx
    c934:	48 39 d0             	cmp    %rdx,%rax
    c937:	73 59                	jae    c992 <f0+0x1772>
    c939:	48 89 c2             	mov    %rax,%rdx
    c93c:	48 c1 ea 10          	shr    $0x10,%rdx
    c940:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c944:	48 8b 15 2d 82 01 00 	mov    0x1822d(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c94b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c94f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c953:	4d 85 e4             	test   %r12,%r12
    c956:	74 3a                	je     c992 <f0+0x1772>
    c958:	0f b6 0a             	movzbl (%rdx),%ecx
    c95b:	80 f9 02             	cmp    $0x2,%cl
    c95e:	0f 84 6c 12 00 00    	je     dbd0 <f0+0x29b0>
    c964:	80 f9 01             	cmp    $0x1,%cl
    c967:	75 29                	jne    c992 <f0+0x1772>
    c969:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c96c:	0f b7 c0             	movzwl %ax,%eax
    c96f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c972:	48 0f af c1          	imul   %rcx,%rax
    c976:	48 c1 e8 20          	shr    $0x20,%rax
    c97a:	48 39 d0             	cmp    %rdx,%rax
    c97d:	73 13                	jae    c992 <f0+0x1772>
    c97f:	49 01 c4             	add    %rax,%r12
    c982:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c987:	0f 84 2d 14 00 00    	je     ddba <f0+0x2b9a>
    c98d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c992:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c999:	33 f3 bf 
    c99c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    c9a3:	00 
    c9a4:	bf 01 00 00 00       	mov    $0x1,%edi
    c9a9:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    c9b0:	00 
    c9b1:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    c9b8:	00 
    c9b9:	e8 e2 98 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    c9be:	48 8b 15 93 81 01 00 	mov    0x18193(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c9c5:	49 89 c5             	mov    %rax,%r13
    c9c8:	48 2b 05 61 81 01 00 	sub    0x18161(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c9cf:	48 c1 e2 10          	shl    $0x10,%rdx
    c9d3:	48 39 d0             	cmp    %rdx,%rax
    c9d6:	73 59                	jae    ca31 <f0+0x1811>
    c9d8:	48 89 c2             	mov    %rax,%rdx
    c9db:	48 c1 ea 10          	shr    $0x10,%rdx
    c9df:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c9e3:	48 8b 15 8e 81 01 00 	mov    0x1818e(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c9ea:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c9ee:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c9f2:	4d 85 e4             	test   %r12,%r12
    c9f5:	74 3a                	je     ca31 <f0+0x1811>
    c9f7:	0f b6 0a             	movzbl (%rdx),%ecx
    c9fa:	80 f9 02             	cmp    $0x2,%cl
    c9fd:	0f 84 bd 11 00 00    	je     dbc0 <f0+0x29a0>
    ca03:	80 f9 01             	cmp    $0x1,%cl
    ca06:	75 29                	jne    ca31 <f0+0x1811>
    ca08:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca0b:	0f b7 c0             	movzwl %ax,%eax
    ca0e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca11:	48 0f af c1          	imul   %rcx,%rax
    ca15:	48 c1 e8 20          	shr    $0x20,%rax
    ca19:	48 39 d0             	cmp    %rdx,%rax
    ca1c:	73 13                	jae    ca31 <f0+0x1811>
    ca1e:	49 01 c4             	add    %rax,%r12
    ca21:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca26:	0f 84 9b 13 00 00    	je     ddc7 <f0+0x2ba7>
    ca2c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca31:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ca38:	00 f0 3f 
    ca3b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    ca42:	00 
    ca43:	bf 01 00 00 00       	mov    $0x1,%edi
    ca48:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    ca4f:	00 
    ca50:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    ca57:	00 
    ca58:	e8 43 98 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    ca5d:	48 8b 15 f4 80 01 00 	mov    0x180f4(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    ca64:	49 89 c5             	mov    %rax,%r13
    ca67:	48 2b 05 c2 80 01 00 	sub    0x180c2(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    ca6e:	48 c1 e2 10          	shl    $0x10,%rdx
    ca72:	48 39 d0             	cmp    %rdx,%rax
    ca75:	73 59                	jae    cad0 <f0+0x18b0>
    ca77:	48 89 c2             	mov    %rax,%rdx
    ca7a:	48 c1 ea 10          	shr    $0x10,%rdx
    ca7e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca82:	48 8b 15 ef 80 01 00 	mov    0x180ef(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    ca89:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca8d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca91:	4d 85 e4             	test   %r12,%r12
    ca94:	74 3a                	je     cad0 <f0+0x18b0>
    ca96:	0f b6 0a             	movzbl (%rdx),%ecx
    ca99:	80 f9 02             	cmp    $0x2,%cl
    ca9c:	0f 84 0e 11 00 00    	je     dbb0 <f0+0x2990>
    caa2:	80 f9 01             	cmp    $0x1,%cl
    caa5:	75 29                	jne    cad0 <f0+0x18b0>
    caa7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    caaa:	0f b7 c0             	movzwl %ax,%eax
    caad:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cab0:	48 0f af c1          	imul   %rcx,%rax
    cab4:	48 c1 e8 20          	shr    $0x20,%rax
    cab8:	48 39 d0             	cmp    %rdx,%rax
    cabb:	73 13                	jae    cad0 <f0+0x18b0>
    cabd:	49 01 c4             	add    %rax,%r12
    cac0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cac5:	0f 84 09 13 00 00    	je     ddd4 <f0+0x2bb4>
    cacb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cad0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cad7:	33 f3 bf 
    cada:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    cae1:	00 
    cae2:	bf 01 00 00 00       	mov    $0x1,%edi
    cae7:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    caee:	00 
    caef:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    caf6:	00 
    caf7:	e8 a4 97 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    cafc:	48 8b 15 55 80 01 00 	mov    0x18055(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cb03:	49 89 c5             	mov    %rax,%r13
    cb06:	48 2b 05 23 80 01 00 	sub    0x18023(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cb0d:	48 c1 e2 10          	shl    $0x10,%rdx
    cb11:	48 39 d0             	cmp    %rdx,%rax
    cb14:	73 59                	jae    cb6f <f0+0x194f>
    cb16:	48 89 c2             	mov    %rax,%rdx
    cb19:	48 c1 ea 10          	shr    $0x10,%rdx
    cb1d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb21:	48 8b 15 50 80 01 00 	mov    0x18050(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cb28:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb2c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb30:	4d 85 e4             	test   %r12,%r12
    cb33:	74 3a                	je     cb6f <f0+0x194f>
    cb35:	0f b6 0a             	movzbl (%rdx),%ecx
    cb38:	80 f9 02             	cmp    $0x2,%cl
    cb3b:	0f 84 5f 10 00 00    	je     dba0 <f0+0x2980>
    cb41:	80 f9 01             	cmp    $0x1,%cl
    cb44:	75 29                	jne    cb6f <f0+0x194f>
    cb46:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb49:	0f b7 c0             	movzwl %ax,%eax
    cb4c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb4f:	48 0f af c1          	imul   %rcx,%rax
    cb53:	48 c1 e8 20          	shr    $0x20,%rax
    cb57:	48 39 d0             	cmp    %rdx,%rax
    cb5a:	73 13                	jae    cb6f <f0+0x194f>
    cb5c:	49 01 c4             	add    %rax,%r12
    cb5f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb64:	0f 84 77 12 00 00    	je     dde1 <f0+0x2bc1>
    cb6a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb6f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cb76:	00 f0 3f 
    cb79:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    cb80:	00 
    cb81:	bf 01 00 00 00       	mov    $0x1,%edi
    cb86:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    cb8d:	00 
    cb8e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    cb95:	00 
    cb96:	e8 05 97 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    cb9b:	48 8b 15 b6 7f 01 00 	mov    0x17fb6(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cba2:	49 89 c5             	mov    %rax,%r13
    cba5:	48 2b 05 84 7f 01 00 	sub    0x17f84(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cbac:	48 c1 e2 10          	shl    $0x10,%rdx
    cbb0:	48 39 d0             	cmp    %rdx,%rax
    cbb3:	73 59                	jae    cc0e <f0+0x19ee>
    cbb5:	48 89 c2             	mov    %rax,%rdx
    cbb8:	48 c1 ea 10          	shr    $0x10,%rdx
    cbbc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cbc0:	48 8b 15 b1 7f 01 00 	mov    0x17fb1(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cbc7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cbcb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cbcf:	4d 85 e4             	test   %r12,%r12
    cbd2:	74 3a                	je     cc0e <f0+0x19ee>
    cbd4:	0f b6 0a             	movzbl (%rdx),%ecx
    cbd7:	80 f9 02             	cmp    $0x2,%cl
    cbda:	0f 84 40 0f 00 00    	je     db20 <f0+0x2900>
    cbe0:	80 f9 01             	cmp    $0x1,%cl
    cbe3:	75 29                	jne    cc0e <f0+0x19ee>
    cbe5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cbe8:	0f b7 c0             	movzwl %ax,%eax
    cbeb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cbee:	48 0f af c1          	imul   %rcx,%rax
    cbf2:	48 c1 e8 20          	shr    $0x20,%rax
    cbf6:	48 39 d0             	cmp    %rdx,%rax
    cbf9:	73 13                	jae    cc0e <f0+0x19ee>
    cbfb:	49 01 c4             	add    %rax,%r12
    cbfe:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc03:	0f 84 e5 11 00 00    	je     ddee <f0+0x2bce>
    cc09:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc0e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cc15:	33 f3 bf 
    cc18:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    cc1f:	00 
    cc20:	bf 01 00 00 00       	mov    $0x1,%edi
    cc25:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    cc2c:	00 
    cc2d:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    cc34:	00 
    cc35:	e8 66 96 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    cc3a:	48 8b 15 17 7f 01 00 	mov    0x17f17(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cc41:	49 89 c5             	mov    %rax,%r13
    cc44:	48 2b 05 e5 7e 01 00 	sub    0x17ee5(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cc4b:	48 c1 e2 10          	shl    $0x10,%rdx
    cc4f:	48 39 d0             	cmp    %rdx,%rax
    cc52:	73 59                	jae    ccad <f0+0x1a8d>
    cc54:	48 89 c2             	mov    %rax,%rdx
    cc57:	48 c1 ea 10          	shr    $0x10,%rdx
    cc5b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc5f:	48 8b 15 12 7f 01 00 	mov    0x17f12(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cc66:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc6a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc6e:	4d 85 e4             	test   %r12,%r12
    cc71:	74 3a                	je     ccad <f0+0x1a8d>
    cc73:	0f b6 0a             	movzbl (%rdx),%ecx
    cc76:	80 f9 02             	cmp    $0x2,%cl
    cc79:	0f 84 91 0e 00 00    	je     db10 <f0+0x28f0>
    cc7f:	80 f9 01             	cmp    $0x1,%cl
    cc82:	75 29                	jne    ccad <f0+0x1a8d>
    cc84:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc87:	0f b7 c0             	movzwl %ax,%eax
    cc8a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc8d:	48 0f af c1          	imul   %rcx,%rax
    cc91:	48 c1 e8 20          	shr    $0x20,%rax
    cc95:	48 39 d0             	cmp    %rdx,%rax
    cc98:	73 13                	jae    ccad <f0+0x1a8d>
    cc9a:	49 01 c4             	add    %rax,%r12
    cc9d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cca2:	0f 84 53 11 00 00    	je     ddfb <f0+0x2bdb>
    cca8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ccad:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ccb4:	00 f0 3f 
    ccb7:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    ccbe:	00 
    ccbf:	bf 01 00 00 00       	mov    $0x1,%edi
    ccc4:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    cccb:	00 
    cccc:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    ccd3:	00 
    ccd4:	e8 c7 95 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    ccd9:	48 8b 15 78 7e 01 00 	mov    0x17e78(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cce0:	49 89 c5             	mov    %rax,%r13
    cce3:	48 2b 05 46 7e 01 00 	sub    0x17e46(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    ccea:	48 c1 e2 10          	shl    $0x10,%rdx
    ccee:	48 39 d0             	cmp    %rdx,%rax
    ccf1:	73 59                	jae    cd4c <f0+0x1b2c>
    ccf3:	48 89 c2             	mov    %rax,%rdx
    ccf6:	48 c1 ea 10          	shr    $0x10,%rdx
    ccfa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ccfe:	48 8b 15 73 7e 01 00 	mov    0x17e73(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cd05:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd09:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd0d:	4d 85 e4             	test   %r12,%r12
    cd10:	74 3a                	je     cd4c <f0+0x1b2c>
    cd12:	0f b6 0a             	movzbl (%rdx),%ecx
    cd15:	80 f9 02             	cmp    $0x2,%cl
    cd18:	0f 84 e2 0d 00 00    	je     db00 <f0+0x28e0>
    cd1e:	80 f9 01             	cmp    $0x1,%cl
    cd21:	75 29                	jne    cd4c <f0+0x1b2c>
    cd23:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd26:	0f b7 c0             	movzwl %ax,%eax
    cd29:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd2c:	48 0f af c1          	imul   %rcx,%rax
    cd30:	48 c1 e8 20          	shr    $0x20,%rax
    cd34:	48 39 d0             	cmp    %rdx,%rax
    cd37:	73 13                	jae    cd4c <f0+0x1b2c>
    cd39:	49 01 c4             	add    %rax,%r12
    cd3c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd41:	0f 84 c1 10 00 00    	je     de08 <f0+0x2be8>
    cd47:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd4c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cd53:	33 f3 bf 
    cd56:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    cd5d:	00 
    cd5e:	bf 01 00 00 00       	mov    $0x1,%edi
    cd63:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    cd6a:	00 
    cd6b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    cd72:	00 
    cd73:	e8 28 95 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    cd78:	48 8b 15 d9 7d 01 00 	mov    0x17dd9(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cd7f:	49 89 c5             	mov    %rax,%r13
    cd82:	48 2b 05 a7 7d 01 00 	sub    0x17da7(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cd89:	48 c1 e2 10          	shl    $0x10,%rdx
    cd8d:	48 39 d0             	cmp    %rdx,%rax
    cd90:	73 59                	jae    cdeb <f0+0x1bcb>
    cd92:	48 89 c2             	mov    %rax,%rdx
    cd95:	48 c1 ea 10          	shr    $0x10,%rdx
    cd99:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd9d:	48 8b 15 d4 7d 01 00 	mov    0x17dd4(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cda4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cda8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cdac:	4d 85 e4             	test   %r12,%r12
    cdaf:	74 3a                	je     cdeb <f0+0x1bcb>
    cdb1:	0f b6 0a             	movzbl (%rdx),%ecx
    cdb4:	80 f9 02             	cmp    $0x2,%cl
    cdb7:	0f 84 33 0d 00 00    	je     daf0 <f0+0x28d0>
    cdbd:	80 f9 01             	cmp    $0x1,%cl
    cdc0:	75 29                	jne    cdeb <f0+0x1bcb>
    cdc2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cdc5:	0f b7 c0             	movzwl %ax,%eax
    cdc8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cdcb:	48 0f af c1          	imul   %rcx,%rax
    cdcf:	48 c1 e8 20          	shr    $0x20,%rax
    cdd3:	48 39 d0             	cmp    %rdx,%rax
    cdd6:	73 13                	jae    cdeb <f0+0x1bcb>
    cdd8:	49 01 c4             	add    %rax,%r12
    cddb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cde0:	0f 84 2f 10 00 00    	je     de15 <f0+0x2bf5>
    cde6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cdeb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cdf2:	00 f0 3f 
    cdf5:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    cdfc:	00 
    cdfd:	bf 01 00 00 00       	mov    $0x1,%edi
    ce02:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    ce09:	00 
    ce0a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    ce11:	00 
    ce12:	e8 89 94 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    ce17:	48 8b 15 3a 7d 01 00 	mov    0x17d3a(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    ce1e:	49 89 c5             	mov    %rax,%r13
    ce21:	48 2b 05 08 7d 01 00 	sub    0x17d08(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    ce28:	48 c1 e2 10          	shl    $0x10,%rdx
    ce2c:	48 39 d0             	cmp    %rdx,%rax
    ce2f:	73 59                	jae    ce8a <f0+0x1c6a>
    ce31:	48 89 c2             	mov    %rax,%rdx
    ce34:	48 c1 ea 10          	shr    $0x10,%rdx
    ce38:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce3c:	48 8b 15 35 7d 01 00 	mov    0x17d35(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    ce43:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce47:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce4b:	4d 85 e4             	test   %r12,%r12
    ce4e:	74 3a                	je     ce8a <f0+0x1c6a>
    ce50:	0f b6 0a             	movzbl (%rdx),%ecx
    ce53:	80 f9 02             	cmp    $0x2,%cl
    ce56:	0f 84 84 0c 00 00    	je     dae0 <f0+0x28c0>
    ce5c:	80 f9 01             	cmp    $0x1,%cl
    ce5f:	75 29                	jne    ce8a <f0+0x1c6a>
    ce61:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce64:	0f b7 c0             	movzwl %ax,%eax
    ce67:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce6a:	48 0f af c1          	imul   %rcx,%rax
    ce6e:	48 c1 e8 20          	shr    $0x20,%rax
    ce72:	48 39 d0             	cmp    %rdx,%rax
    ce75:	73 13                	jae    ce8a <f0+0x1c6a>
    ce77:	49 01 c4             	add    %rax,%r12
    ce7a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce7f:	0f 84 9d 0f 00 00    	je     de22 <f0+0x2c02>
    ce85:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce8a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ce91:	33 f3 bf 
    ce94:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    ce9b:	00 
    ce9c:	bf 01 00 00 00       	mov    $0x1,%edi
    cea1:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    cea8:	00 
    cea9:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    ceb0:	00 
    ceb1:	e8 ea 93 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    ceb6:	48 8b 15 9b 7c 01 00 	mov    0x17c9b(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cebd:	49 89 c5             	mov    %rax,%r13
    cec0:	48 2b 05 69 7c 01 00 	sub    0x17c69(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cec7:	48 c1 e2 10          	shl    $0x10,%rdx
    cecb:	48 39 d0             	cmp    %rdx,%rax
    cece:	73 59                	jae    cf29 <f0+0x1d09>
    ced0:	48 89 c2             	mov    %rax,%rdx
    ced3:	48 c1 ea 10          	shr    $0x10,%rdx
    ced7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cedb:	48 8b 15 96 7c 01 00 	mov    0x17c96(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cee2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cee6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ceea:	4d 85 e4             	test   %r12,%r12
    ceed:	74 3a                	je     cf29 <f0+0x1d09>
    ceef:	0f b6 0a             	movzbl (%rdx),%ecx
    cef2:	80 f9 02             	cmp    $0x2,%cl
    cef5:	0f 84 d5 0b 00 00    	je     dad0 <f0+0x28b0>
    cefb:	80 f9 01             	cmp    $0x1,%cl
    cefe:	75 29                	jne    cf29 <f0+0x1d09>
    cf00:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf03:	0f b7 c0             	movzwl %ax,%eax
    cf06:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf09:	48 0f af c1          	imul   %rcx,%rax
    cf0d:	48 c1 e8 20          	shr    $0x20,%rax
    cf11:	48 39 d0             	cmp    %rdx,%rax
    cf14:	73 13                	jae    cf29 <f0+0x1d09>
    cf16:	49 01 c4             	add    %rax,%r12
    cf19:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf1e:	0f 84 0b 0f 00 00    	je     de2f <f0+0x2c0f>
    cf24:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf29:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cf30:	00 f0 3f 
    cf33:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    cf3a:	00 
    cf3b:	bf 01 00 00 00       	mov    $0x1,%edi
    cf40:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    cf47:	00 
    cf48:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    cf4f:	00 
    cf50:	e8 4b 93 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    cf55:	48 8b 15 fc 7b 01 00 	mov    0x17bfc(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cf5c:	49 89 c5             	mov    %rax,%r13
    cf5f:	48 2b 05 ca 7b 01 00 	sub    0x17bca(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cf66:	48 c1 e2 10          	shl    $0x10,%rdx
    cf6a:	48 39 d0             	cmp    %rdx,%rax
    cf6d:	73 59                	jae    cfc8 <f0+0x1da8>
    cf6f:	48 89 c2             	mov    %rax,%rdx
    cf72:	48 c1 ea 10          	shr    $0x10,%rdx
    cf76:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf7a:	48 8b 15 f7 7b 01 00 	mov    0x17bf7(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cf81:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf85:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf89:	4d 85 e4             	test   %r12,%r12
    cf8c:	74 3a                	je     cfc8 <f0+0x1da8>
    cf8e:	0f b6 0a             	movzbl (%rdx),%ecx
    cf91:	80 f9 02             	cmp    $0x2,%cl
    cf94:	0f 84 26 0b 00 00    	je     dac0 <f0+0x28a0>
    cf9a:	80 f9 01             	cmp    $0x1,%cl
    cf9d:	75 29                	jne    cfc8 <f0+0x1da8>
    cf9f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfa2:	0f b7 c0             	movzwl %ax,%eax
    cfa5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cfa8:	48 0f af c1          	imul   %rcx,%rax
    cfac:	48 c1 e8 20          	shr    $0x20,%rax
    cfb0:	48 39 d0             	cmp    %rdx,%rax
    cfb3:	73 13                	jae    cfc8 <f0+0x1da8>
    cfb5:	49 01 c4             	add    %rax,%r12
    cfb8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cfbd:	0f 84 79 0e 00 00    	je     de3c <f0+0x2c1c>
    cfc3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cfc8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cfcf:	33 f3 bf 
    cfd2:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    cfd9:	00 
    cfda:	bf 01 00 00 00       	mov    $0x1,%edi
    cfdf:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    cfe6:	00 
    cfe7:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    cfee:	00 
    cfef:	e8 ac 92 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    cff4:	48 8b 15 5d 7b 01 00 	mov    0x17b5d(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cffb:	49 89 c5             	mov    %rax,%r13
    cffe:	48 2b 05 2b 7b 01 00 	sub    0x17b2b(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d005:	48 c1 e2 10          	shl    $0x10,%rdx
    d009:	48 39 d0             	cmp    %rdx,%rax
    d00c:	73 59                	jae    d067 <f0+0x1e47>
    d00e:	48 89 c2             	mov    %rax,%rdx
    d011:	48 c1 ea 10          	shr    $0x10,%rdx
    d015:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d019:	48 8b 15 58 7b 01 00 	mov    0x17b58(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d020:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d024:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d028:	4d 85 e4             	test   %r12,%r12
    d02b:	74 3a                	je     d067 <f0+0x1e47>
    d02d:	0f b6 0a             	movzbl (%rdx),%ecx
    d030:	80 f9 02             	cmp    $0x2,%cl
    d033:	0f 84 77 0a 00 00    	je     dab0 <f0+0x2890>
    d039:	80 f9 01             	cmp    $0x1,%cl
    d03c:	75 29                	jne    d067 <f0+0x1e47>
    d03e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d041:	0f b7 c0             	movzwl %ax,%eax
    d044:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d047:	48 0f af c1          	imul   %rcx,%rax
    d04b:	48 c1 e8 20          	shr    $0x20,%rax
    d04f:	48 39 d0             	cmp    %rdx,%rax
    d052:	73 13                	jae    d067 <f0+0x1e47>
    d054:	49 01 c4             	add    %rax,%r12
    d057:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d05c:	0f 84 e7 0d 00 00    	je     de49 <f0+0x2c29>
    d062:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d067:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d06e:	00 f0 3f 
    d071:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    d078:	00 
    d079:	bf 01 00 00 00       	mov    $0x1,%edi
    d07e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    d085:	00 
    d086:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    d08d:	00 
    d08e:	e8 0d 92 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    d093:	48 8b 15 be 7a 01 00 	mov    0x17abe(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d09a:	49 89 c5             	mov    %rax,%r13
    d09d:	48 2b 05 8c 7a 01 00 	sub    0x17a8c(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d0a4:	48 c1 e2 10          	shl    $0x10,%rdx
    d0a8:	48 39 d0             	cmp    %rdx,%rax
    d0ab:	73 59                	jae    d106 <f0+0x1ee6>
    d0ad:	48 89 c2             	mov    %rax,%rdx
    d0b0:	48 c1 ea 10          	shr    $0x10,%rdx
    d0b4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0b8:	48 8b 15 b9 7a 01 00 	mov    0x17ab9(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d0bf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d0c3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d0c7:	4d 85 e4             	test   %r12,%r12
    d0ca:	74 3a                	je     d106 <f0+0x1ee6>
    d0cc:	0f b6 0a             	movzbl (%rdx),%ecx
    d0cf:	80 f9 02             	cmp    $0x2,%cl
    d0d2:	0f 84 38 0c 00 00    	je     dd10 <f0+0x2af0>
    d0d8:	80 f9 01             	cmp    $0x1,%cl
    d0db:	75 29                	jne    d106 <f0+0x1ee6>
    d0dd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d0e0:	0f b7 c0             	movzwl %ax,%eax
    d0e3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d0e6:	48 0f af c1          	imul   %rcx,%rax
    d0ea:	48 c1 e8 20          	shr    $0x20,%rax
    d0ee:	48 39 d0             	cmp    %rdx,%rax
    d0f1:	73 13                	jae    d106 <f0+0x1ee6>
    d0f3:	49 01 c4             	add    %rax,%r12
    d0f6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d0fb:	0f 84 55 0d 00 00    	je     de56 <f0+0x2c36>
    d101:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d106:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d10d:	33 f3 bf 
    d110:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    d117:	00 
    d118:	bf 01 00 00 00       	mov    $0x1,%edi
    d11d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    d124:	00 
    d125:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    d12c:	00 
    d12d:	e8 6e 91 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    d132:	48 8b 15 1f 7a 01 00 	mov    0x17a1f(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d139:	49 89 c5             	mov    %rax,%r13
    d13c:	48 2b 05 ed 79 01 00 	sub    0x179ed(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d143:	48 c1 e2 10          	shl    $0x10,%rdx
    d147:	48 39 d0             	cmp    %rdx,%rax
    d14a:	73 59                	jae    d1a5 <f0+0x1f85>
    d14c:	48 89 c2             	mov    %rax,%rdx
    d14f:	48 c1 ea 10          	shr    $0x10,%rdx
    d153:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d157:	48 8b 15 1a 7a 01 00 	mov    0x17a1a(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d15e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d162:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d166:	4d 85 e4             	test   %r12,%r12
    d169:	74 3a                	je     d1a5 <f0+0x1f85>
    d16b:	0f b6 0a             	movzbl (%rdx),%ecx
    d16e:	80 f9 02             	cmp    $0x2,%cl
    d171:	0f 84 89 0b 00 00    	je     dd00 <f0+0x2ae0>
    d177:	80 f9 01             	cmp    $0x1,%cl
    d17a:	75 29                	jne    d1a5 <f0+0x1f85>
    d17c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d17f:	0f b7 c0             	movzwl %ax,%eax
    d182:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d185:	48 0f af c1          	imul   %rcx,%rax
    d189:	48 c1 e8 20          	shr    $0x20,%rax
    d18d:	48 39 d0             	cmp    %rdx,%rax
    d190:	73 13                	jae    d1a5 <f0+0x1f85>
    d192:	49 01 c4             	add    %rax,%r12
    d195:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d19a:	0f 84 c3 0c 00 00    	je     de63 <f0+0x2c43>
    d1a0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d1a5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d1ac:	00 f0 3f 
    d1af:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    d1b6:	00 
    d1b7:	bf 01 00 00 00       	mov    $0x1,%edi
    d1bc:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    d1c3:	00 
    d1c4:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    d1cb:	00 
    d1cc:	e8 cf 90 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    d1d1:	48 8b 15 80 79 01 00 	mov    0x17980(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d1d8:	49 89 c5             	mov    %rax,%r13
    d1db:	48 2b 05 4e 79 01 00 	sub    0x1794e(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d1e2:	48 c1 e2 10          	shl    $0x10,%rdx
    d1e6:	48 39 d0             	cmp    %rdx,%rax
    d1e9:	73 59                	jae    d244 <f0+0x2024>
    d1eb:	48 89 c2             	mov    %rax,%rdx
    d1ee:	48 c1 ea 10          	shr    $0x10,%rdx
    d1f2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d1f6:	48 8b 15 7b 79 01 00 	mov    0x1797b(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d1fd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d201:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d205:	4d 85 e4             	test   %r12,%r12
    d208:	74 3a                	je     d244 <f0+0x2024>
    d20a:	0f b6 0a             	movzbl (%rdx),%ecx
    d20d:	80 f9 02             	cmp    $0x2,%cl
    d210:	0f 84 da 0a 00 00    	je     dcf0 <f0+0x2ad0>
    d216:	80 f9 01             	cmp    $0x1,%cl
    d219:	75 29                	jne    d244 <f0+0x2024>
    d21b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d21e:	0f b7 c0             	movzwl %ax,%eax
    d221:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d224:	48 0f af c1          	imul   %rcx,%rax
    d228:	48 c1 e8 20          	shr    $0x20,%rax
    d22c:	48 39 d0             	cmp    %rdx,%rax
    d22f:	73 13                	jae    d244 <f0+0x2024>
    d231:	49 01 c4             	add    %rax,%r12
    d234:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d239:	0f 84 31 0c 00 00    	je     de70 <f0+0x2c50>
    d23f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d244:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d24b:	33 f3 bf 
    d24e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    d255:	00 
    d256:	bf 01 00 00 00       	mov    $0x1,%edi
    d25b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    d262:	00 
    d263:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    d26a:	00 
    d26b:	e8 30 90 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    d270:	48 8b 15 e1 78 01 00 	mov    0x178e1(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d277:	49 89 c5             	mov    %rax,%r13
    d27a:	48 2b 05 af 78 01 00 	sub    0x178af(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d281:	48 c1 e2 10          	shl    $0x10,%rdx
    d285:	48 39 d0             	cmp    %rdx,%rax
    d288:	73 59                	jae    d2e3 <f0+0x20c3>
    d28a:	48 89 c2             	mov    %rax,%rdx
    d28d:	48 c1 ea 10          	shr    $0x10,%rdx
    d291:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d295:	48 8b 15 dc 78 01 00 	mov    0x178dc(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d29c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d2a0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d2a4:	4d 85 e4             	test   %r12,%r12
    d2a7:	74 3a                	je     d2e3 <f0+0x20c3>
    d2a9:	0f b6 0a             	movzbl (%rdx),%ecx
    d2ac:	80 f9 02             	cmp    $0x2,%cl
    d2af:	0f 84 2b 0a 00 00    	je     dce0 <f0+0x2ac0>
    d2b5:	80 f9 01             	cmp    $0x1,%cl
    d2b8:	75 29                	jne    d2e3 <f0+0x20c3>
    d2ba:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2bd:	0f b7 c0             	movzwl %ax,%eax
    d2c0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d2c3:	48 0f af c1          	imul   %rcx,%rax
    d2c7:	48 c1 e8 20          	shr    $0x20,%rax
    d2cb:	48 39 d0             	cmp    %rdx,%rax
    d2ce:	73 13                	jae    d2e3 <f0+0x20c3>
    d2d0:	49 01 c4             	add    %rax,%r12
    d2d3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d2d8:	0f 84 9f 0b 00 00    	je     de7d <f0+0x2c5d>
    d2de:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d2e3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d2ea:	00 f0 3f 
    d2ed:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    d2f4:	00 
    d2f5:	bf 01 00 00 00       	mov    $0x1,%edi
    d2fa:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    d301:	00 
    d302:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    d309:	00 
    d30a:	e8 91 8f ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    d30f:	48 8b 15 42 78 01 00 	mov    0x17842(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d316:	49 89 c5             	mov    %rax,%r13
    d319:	48 2b 05 10 78 01 00 	sub    0x17810(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d320:	48 c1 e2 10          	shl    $0x10,%rdx
    d324:	48 39 d0             	cmp    %rdx,%rax
    d327:	73 59                	jae    d382 <f0+0x2162>
    d329:	48 89 c2             	mov    %rax,%rdx
    d32c:	48 c1 ea 10          	shr    $0x10,%rdx
    d330:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d334:	48 8b 15 3d 78 01 00 	mov    0x1783d(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d33b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d33f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d343:	4d 85 e4             	test   %r12,%r12
    d346:	74 3a                	je     d382 <f0+0x2162>
    d348:	0f b6 0a             	movzbl (%rdx),%ecx
    d34b:	80 f9 02             	cmp    $0x2,%cl
    d34e:	0f 84 7c 09 00 00    	je     dcd0 <f0+0x2ab0>
    d354:	80 f9 01             	cmp    $0x1,%cl
    d357:	75 29                	jne    d382 <f0+0x2162>
    d359:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d35c:	0f b7 c0             	movzwl %ax,%eax
    d35f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d362:	48 0f af c1          	imul   %rcx,%rax
    d366:	48 c1 e8 20          	shr    $0x20,%rax
    d36a:	48 39 d0             	cmp    %rdx,%rax
    d36d:	73 13                	jae    d382 <f0+0x2162>
    d36f:	49 01 c4             	add    %rax,%r12
    d372:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d377:	0f 84 0d 0b 00 00    	je     de8a <f0+0x2c6a>
    d37d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d382:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d389:	33 f3 bf 
    d38c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    d393:	00 
    d394:	bf 01 00 00 00       	mov    $0x1,%edi
    d399:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    d3a0:	00 
    d3a1:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    d3a8:	00 
    d3a9:	e8 f2 8e ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    d3ae:	48 8b 15 a3 77 01 00 	mov    0x177a3(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d3b5:	49 89 c5             	mov    %rax,%r13
    d3b8:	48 2b 05 71 77 01 00 	sub    0x17771(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d3bf:	48 c1 e2 10          	shl    $0x10,%rdx
    d3c3:	48 39 d0             	cmp    %rdx,%rax
    d3c6:	73 59                	jae    d421 <f0+0x2201>
    d3c8:	48 89 c2             	mov    %rax,%rdx
    d3cb:	48 c1 ea 10          	shr    $0x10,%rdx
    d3cf:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d3d3:	48 8b 15 9e 77 01 00 	mov    0x1779e(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d3da:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d3de:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d3e2:	4d 85 e4             	test   %r12,%r12
    d3e5:	74 3a                	je     d421 <f0+0x2201>
    d3e7:	0f b6 0a             	movzbl (%rdx),%ecx
    d3ea:	80 f9 02             	cmp    $0x2,%cl
    d3ed:	0f 84 cd 08 00 00    	je     dcc0 <f0+0x2aa0>
    d3f3:	80 f9 01             	cmp    $0x1,%cl
    d3f6:	75 29                	jne    d421 <f0+0x2201>
    d3f8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d3fb:	0f b7 c0             	movzwl %ax,%eax
    d3fe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d401:	48 0f af c1          	imul   %rcx,%rax
    d405:	48 c1 e8 20          	shr    $0x20,%rax
    d409:	48 39 d0             	cmp    %rdx,%rax
    d40c:	73 13                	jae    d421 <f0+0x2201>
    d40e:	49 01 c4             	add    %rax,%r12
    d411:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d416:	0f 84 7b 0a 00 00    	je     de97 <f0+0x2c77>
    d41c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d421:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d428:	00 f0 3f 
    d42b:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    d432:	00 
    d433:	bf 01 00 00 00       	mov    $0x1,%edi
    d438:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    d43f:	00 
    d440:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    d447:	00 
    d448:	e8 53 8e ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    d44d:	48 8b 15 04 77 01 00 	mov    0x17704(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d454:	49 89 c5             	mov    %rax,%r13
    d457:	48 2b 05 d2 76 01 00 	sub    0x176d2(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d45e:	48 c1 e2 10          	shl    $0x10,%rdx
    d462:	48 39 d0             	cmp    %rdx,%rax
    d465:	73 59                	jae    d4c0 <f0+0x22a0>
    d467:	48 89 c2             	mov    %rax,%rdx
    d46a:	48 c1 ea 10          	shr    $0x10,%rdx
    d46e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d472:	48 8b 15 ff 76 01 00 	mov    0x176ff(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d479:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d47d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d481:	4d 85 e4             	test   %r12,%r12
    d484:	74 3a                	je     d4c0 <f0+0x22a0>
    d486:	0f b6 0a             	movzbl (%rdx),%ecx
    d489:	80 f9 02             	cmp    $0x2,%cl
    d48c:	0f 84 1e 08 00 00    	je     dcb0 <f0+0x2a90>
    d492:	80 f9 01             	cmp    $0x1,%cl
    d495:	75 29                	jne    d4c0 <f0+0x22a0>
    d497:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d49a:	0f b7 c0             	movzwl %ax,%eax
    d49d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d4a0:	48 0f af c1          	imul   %rcx,%rax
    d4a4:	48 c1 e8 20          	shr    $0x20,%rax
    d4a8:	48 39 d0             	cmp    %rdx,%rax
    d4ab:	73 13                	jae    d4c0 <f0+0x22a0>
    d4ad:	49 01 c4             	add    %rax,%r12
    d4b0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d4b5:	0f 84 e9 09 00 00    	je     dea4 <f0+0x2c84>
    d4bb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d4c0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d4c7:	33 f3 bf 
    d4ca:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    d4d1:	00 
    d4d2:	bf 01 00 00 00       	mov    $0x1,%edi
    d4d7:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    d4de:	00 
    d4df:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    d4e6:	00 
    d4e7:	e8 b4 8d ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    d4ec:	48 8b 15 65 76 01 00 	mov    0x17665(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d4f3:	49 89 c5             	mov    %rax,%r13
    d4f6:	48 2b 05 33 76 01 00 	sub    0x17633(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d4fd:	48 c1 e2 10          	shl    $0x10,%rdx
    d501:	48 39 d0             	cmp    %rdx,%rax
    d504:	73 59                	jae    d55f <f0+0x233f>
    d506:	48 89 c2             	mov    %rax,%rdx
    d509:	48 c1 ea 10          	shr    $0x10,%rdx
    d50d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d511:	48 8b 15 60 76 01 00 	mov    0x17660(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d518:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d51c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d520:	4d 85 e4             	test   %r12,%r12
    d523:	74 3a                	je     d55f <f0+0x233f>
    d525:	0f b6 0a             	movzbl (%rdx),%ecx
    d528:	80 f9 02             	cmp    $0x2,%cl
    d52b:	0f 84 6f 07 00 00    	je     dca0 <f0+0x2a80>
    d531:	80 f9 01             	cmp    $0x1,%cl
    d534:	75 29                	jne    d55f <f0+0x233f>
    d536:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d539:	0f b7 c0             	movzwl %ax,%eax
    d53c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d53f:	48 0f af c1          	imul   %rcx,%rax
    d543:	48 c1 e8 20          	shr    $0x20,%rax
    d547:	48 39 d0             	cmp    %rdx,%rax
    d54a:	73 13                	jae    d55f <f0+0x233f>
    d54c:	49 01 c4             	add    %rax,%r12
    d54f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d554:	0f 84 57 09 00 00    	je     deb1 <f0+0x2c91>
    d55a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d55f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d566:	00 f0 3f 
    d569:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    d570:	00 
    d571:	bf 01 00 00 00       	mov    $0x1,%edi
    d576:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    d57d:	00 
    d57e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    d585:	00 
    d586:	e8 15 8d ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    d58b:	48 8b 15 c6 75 01 00 	mov    0x175c6(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d592:	49 89 c5             	mov    %rax,%r13
    d595:	48 2b 05 94 75 01 00 	sub    0x17594(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d59c:	48 c1 e2 10          	shl    $0x10,%rdx
    d5a0:	48 39 d0             	cmp    %rdx,%rax
    d5a3:	73 59                	jae    d5fe <f0+0x23de>
    d5a5:	48 89 c2             	mov    %rax,%rdx
    d5a8:	48 c1 ea 10          	shr    $0x10,%rdx
    d5ac:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d5b0:	48 8b 15 c1 75 01 00 	mov    0x175c1(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d5b7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d5bb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d5bf:	4d 85 e4             	test   %r12,%r12
    d5c2:	74 3a                	je     d5fe <f0+0x23de>
    d5c4:	0f b6 0a             	movzbl (%rdx),%ecx
    d5c7:	80 f9 02             	cmp    $0x2,%cl
    d5ca:	0f 84 c0 06 00 00    	je     dc90 <f0+0x2a70>
    d5d0:	80 f9 01             	cmp    $0x1,%cl
    d5d3:	75 29                	jne    d5fe <f0+0x23de>
    d5d5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d5d8:	0f b7 c0             	movzwl %ax,%eax
    d5db:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d5de:	48 0f af c1          	imul   %rcx,%rax
    d5e2:	48 c1 e8 20          	shr    $0x20,%rax
    d5e6:	48 39 d0             	cmp    %rdx,%rax
    d5e9:	73 13                	jae    d5fe <f0+0x23de>
    d5eb:	49 01 c4             	add    %rax,%r12
    d5ee:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d5f3:	0f 84 c5 08 00 00    	je     debe <f0+0x2c9e>
    d5f9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d5fe:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d605:	33 f3 bf 
    d608:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    d60f:	00 
    d610:	bf 01 00 00 00       	mov    $0x1,%edi
    d615:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    d61c:	00 
    d61d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    d624:	00 
    d625:	e8 76 8c ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    d62a:	48 8b 15 27 75 01 00 	mov    0x17527(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d631:	49 89 c5             	mov    %rax,%r13
    d634:	48 2b 05 f5 74 01 00 	sub    0x174f5(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d63b:	48 c1 e2 10          	shl    $0x10,%rdx
    d63f:	48 39 d0             	cmp    %rdx,%rax
    d642:	73 59                	jae    d69d <f0+0x247d>
    d644:	48 89 c2             	mov    %rax,%rdx
    d647:	48 c1 ea 10          	shr    $0x10,%rdx
    d64b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d64f:	48 8b 15 22 75 01 00 	mov    0x17522(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d656:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d65a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d65e:	4d 85 e4             	test   %r12,%r12
    d661:	74 3a                	je     d69d <f0+0x247d>
    d663:	0f b6 0a             	movzbl (%rdx),%ecx
    d666:	80 f9 02             	cmp    $0x2,%cl
    d669:	0f 84 11 06 00 00    	je     dc80 <f0+0x2a60>
    d66f:	80 f9 01             	cmp    $0x1,%cl
    d672:	75 29                	jne    d69d <f0+0x247d>
    d674:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d677:	0f b7 c0             	movzwl %ax,%eax
    d67a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d67d:	48 0f af c1          	imul   %rcx,%rax
    d681:	48 c1 e8 20          	shr    $0x20,%rax
    d685:	48 39 d0             	cmp    %rdx,%rax
    d688:	73 13                	jae    d69d <f0+0x247d>
    d68a:	49 01 c4             	add    %rax,%r12
    d68d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d692:	0f 84 33 08 00 00    	je     decb <f0+0x2cab>
    d698:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d69d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d6a4:	00 f0 3f 
    d6a7:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    d6ae:	00 
    d6af:	bf 01 00 00 00       	mov    $0x1,%edi
    d6b4:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    d6bb:	00 
    d6bc:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    d6c3:	00 
    d6c4:	e8 d7 8b ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    d6c9:	48 8b 15 88 74 01 00 	mov    0x17488(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d6d0:	49 89 c5             	mov    %rax,%r13
    d6d3:	48 2b 05 56 74 01 00 	sub    0x17456(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d6da:	48 c1 e2 10          	shl    $0x10,%rdx
    d6de:	48 39 d0             	cmp    %rdx,%rax
    d6e1:	73 59                	jae    d73c <f0+0x251c>
    d6e3:	48 89 c2             	mov    %rax,%rdx
    d6e6:	48 c1 ea 10          	shr    $0x10,%rdx
    d6ea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d6ee:	48 8b 15 83 74 01 00 	mov    0x17483(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d6f5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d6f9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d6fd:	4d 85 e4             	test   %r12,%r12
    d700:	74 3a                	je     d73c <f0+0x251c>
    d702:	0f b6 0a             	movzbl (%rdx),%ecx
    d705:	80 f9 02             	cmp    $0x2,%cl
    d708:	0f 84 62 05 00 00    	je     dc70 <f0+0x2a50>
    d70e:	80 f9 01             	cmp    $0x1,%cl
    d711:	75 29                	jne    d73c <f0+0x251c>
    d713:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d716:	0f b7 c0             	movzwl %ax,%eax
    d719:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d71c:	48 0f af c1          	imul   %rcx,%rax
    d720:	48 c1 e8 20          	shr    $0x20,%rax
    d724:	48 39 d0             	cmp    %rdx,%rax
    d727:	73 13                	jae    d73c <f0+0x251c>
    d729:	49 01 c4             	add    %rax,%r12
    d72c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d731:	0f 84 a1 07 00 00    	je     ded8 <f0+0x2cb8>
    d737:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d73c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d743:	33 f3 bf 
    d746:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    d74d:	00 
    d74e:	bf 01 00 00 00       	mov    $0x1,%edi
    d753:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    d75a:	00 
    d75b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    d762:	00 
    d763:	e8 38 8b ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    d768:	48 8b 15 e9 73 01 00 	mov    0x173e9(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d76f:	49 89 c5             	mov    %rax,%r13
    d772:	48 2b 05 b7 73 01 00 	sub    0x173b7(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d779:	48 c1 e2 10          	shl    $0x10,%rdx
    d77d:	48 39 d0             	cmp    %rdx,%rax
    d780:	73 59                	jae    d7db <f0+0x25bb>
    d782:	48 89 c2             	mov    %rax,%rdx
    d785:	48 c1 ea 10          	shr    $0x10,%rdx
    d789:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d78d:	48 8b 15 e4 73 01 00 	mov    0x173e4(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d794:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d798:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d79c:	4d 85 e4             	test   %r12,%r12
    d79f:	74 3a                	je     d7db <f0+0x25bb>
    d7a1:	0f b6 0a             	movzbl (%rdx),%ecx
    d7a4:	80 f9 02             	cmp    $0x2,%cl
    d7a7:	0f 84 b3 04 00 00    	je     dc60 <f0+0x2a40>
    d7ad:	80 f9 01             	cmp    $0x1,%cl
    d7b0:	75 29                	jne    d7db <f0+0x25bb>
    d7b2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d7b5:	0f b7 c0             	movzwl %ax,%eax
    d7b8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d7bb:	48 0f af c1          	imul   %rcx,%rax
    d7bf:	48 c1 e8 20          	shr    $0x20,%rax
    d7c3:	48 39 d0             	cmp    %rdx,%rax
    d7c6:	73 13                	jae    d7db <f0+0x25bb>
    d7c8:	49 01 c4             	add    %rax,%r12
    d7cb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d7d0:	0f 84 0f 07 00 00    	je     dee5 <f0+0x2cc5>
    d7d6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d7db:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d7e2:	00 f0 3f 
    d7e5:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    d7ec:	00 
    d7ed:	bf 01 00 00 00       	mov    $0x1,%edi
    d7f2:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    d7f9:	00 
    d7fa:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    d801:	00 
    d802:	e8 99 8a ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    d807:	48 8b 15 4a 73 01 00 	mov    0x1734a(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d80e:	49 89 c5             	mov    %rax,%r13
    d811:	48 2b 05 18 73 01 00 	sub    0x17318(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d818:	48 c1 e2 10          	shl    $0x10,%rdx
    d81c:	48 39 d0             	cmp    %rdx,%rax
    d81f:	73 59                	jae    d87a <f0+0x265a>
    d821:	48 89 c2             	mov    %rax,%rdx
    d824:	48 c1 ea 10          	shr    $0x10,%rdx
    d828:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d82c:	48 8b 15 45 73 01 00 	mov    0x17345(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d833:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d837:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d83b:	4d 85 e4             	test   %r12,%r12
    d83e:	74 3a                	je     d87a <f0+0x265a>
    d840:	0f b6 0a             	movzbl (%rdx),%ecx
    d843:	80 f9 02             	cmp    $0x2,%cl
    d846:	0f 84 04 04 00 00    	je     dc50 <f0+0x2a30>
    d84c:	80 f9 01             	cmp    $0x1,%cl
    d84f:	75 29                	jne    d87a <f0+0x265a>
    d851:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d854:	0f b7 c0             	movzwl %ax,%eax
    d857:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d85a:	48 0f af c1          	imul   %rcx,%rax
    d85e:	48 c1 e8 20          	shr    $0x20,%rax
    d862:	48 39 d0             	cmp    %rdx,%rax
    d865:	73 13                	jae    d87a <f0+0x265a>
    d867:	49 01 c4             	add    %rax,%r12
    d86a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d86f:	0f 84 7d 06 00 00    	je     def2 <f0+0x2cd2>
    d875:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d87a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d881:	33 f3 bf 
    d884:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    d88b:	00 
    d88c:	bf 01 00 00 00       	mov    $0x1,%edi
    d891:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    d898:	00 
    d899:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    d8a0:	00 
    d8a1:	e8 fa 89 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    d8a6:	48 8b 15 ab 72 01 00 	mov    0x172ab(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d8ad:	49 89 c5             	mov    %rax,%r13
    d8b0:	48 2b 05 79 72 01 00 	sub    0x17279(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d8b7:	48 c1 e2 10          	shl    $0x10,%rdx
    d8bb:	48 39 d0             	cmp    %rdx,%rax
    d8be:	73 59                	jae    d919 <f0+0x26f9>
    d8c0:	48 89 c2             	mov    %rax,%rdx
    d8c3:	48 c1 ea 10          	shr    $0x10,%rdx
    d8c7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d8cb:	48 8b 15 a6 72 01 00 	mov    0x172a6(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d8d2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d8d6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d8da:	4d 85 e4             	test   %r12,%r12
    d8dd:	74 3a                	je     d919 <f0+0x26f9>
    d8df:	0f b6 0a             	movzbl (%rdx),%ecx
    d8e2:	80 f9 02             	cmp    $0x2,%cl
    d8e5:	0f 84 55 03 00 00    	je     dc40 <f0+0x2a20>
    d8eb:	80 f9 01             	cmp    $0x1,%cl
    d8ee:	75 29                	jne    d919 <f0+0x26f9>
    d8f0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d8f3:	0f b7 c0             	movzwl %ax,%eax
    d8f6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d8f9:	48 0f af c1          	imul   %rcx,%rax
    d8fd:	48 c1 e8 20          	shr    $0x20,%rax
    d901:	48 39 d0             	cmp    %rdx,%rax
    d904:	73 13                	jae    d919 <f0+0x26f9>
    d906:	49 01 c4             	add    %rax,%r12
    d909:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d90e:	0f 84 eb 05 00 00    	je     deff <f0+0x2cdf>
    d914:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d919:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d920:	00 f0 3f 
    d923:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    d92a:	00 
    d92b:	bf 01 00 00 00       	mov    $0x1,%edi
    d930:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    d937:	00 
    d938:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    d93f:	00 
    d940:	e8 5b 89 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    d945:	48 8b 15 0c 72 01 00 	mov    0x1720c(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d94c:	49 89 c5             	mov    %rax,%r13
    d94f:	48 2b 05 da 71 01 00 	sub    0x171da(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d956:	48 c1 e2 10          	shl    $0x10,%rdx
    d95a:	48 39 d0             	cmp    %rdx,%rax
    d95d:	73 59                	jae    d9b8 <f0+0x2798>
    d95f:	48 89 c2             	mov    %rax,%rdx
    d962:	48 c1 ea 10          	shr    $0x10,%rdx
    d966:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d96a:	48 8b 15 07 72 01 00 	mov    0x17207(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d971:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d975:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d979:	4d 85 e4             	test   %r12,%r12
    d97c:	74 3a                	je     d9b8 <f0+0x2798>
    d97e:	0f b6 0a             	movzbl (%rdx),%ecx
    d981:	80 f9 02             	cmp    $0x2,%cl
    d984:	0f 84 a6 02 00 00    	je     dc30 <f0+0x2a10>
    d98a:	80 f9 01             	cmp    $0x1,%cl
    d98d:	75 29                	jne    d9b8 <f0+0x2798>
    d98f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d992:	0f b7 c0             	movzwl %ax,%eax
    d995:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d998:	48 0f af c1          	imul   %rcx,%rax
    d99c:	48 c1 e8 20          	shr    $0x20,%rax
    d9a0:	48 39 d0             	cmp    %rdx,%rax
    d9a3:	73 13                	jae    d9b8 <f0+0x2798>
    d9a5:	49 01 c4             	add    %rax,%r12
    d9a8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d9ad:	0f 84 59 05 00 00    	je     df0c <f0+0x2cec>
    d9b3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d9b8:	48 89 ee             	mov    %rbp,%rsi
    d9bb:	bf 01 00 00 00       	mov    $0x1,%edi
    d9c0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d9c7:	33 f3 bf 
    d9ca:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    d9d1:	00 
    d9d2:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    d9d9:	00 
    d9da:	e8 c1 88 ff ff       	call   62a0 <fwp_data.part.0.constprop.0>
    d9df:	48 8b 15 72 71 01 00 	mov    0x17172(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d9e6:	48 89 c5             	mov    %rax,%rbp
    d9e9:	48 2b 05 40 71 01 00 	sub    0x17140(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d9f0:	48 c1 e2 10          	shl    $0x10,%rdx
    d9f4:	48 39 d0             	cmp    %rdx,%rax
    d9f7:	73 59                	jae    da52 <f0+0x2832>
    d9f9:	48 89 c2             	mov    %rax,%rdx
    d9fc:	48 c1 ea 10          	shr    $0x10,%rdx
    da00:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    da04:	48 8b 15 6d 71 01 00 	mov    0x1716d(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    da0b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    da0f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    da13:	4d 85 e4             	test   %r12,%r12
    da16:	74 3a                	je     da52 <f0+0x2832>
    da18:	0f b6 0a             	movzbl (%rdx),%ecx
    da1b:	80 f9 02             	cmp    $0x2,%cl
    da1e:	0f 84 fc 01 00 00    	je     dc20 <f0+0x2a00>
    da24:	80 f9 01             	cmp    $0x1,%cl
    da27:	75 29                	jne    da52 <f0+0x2832>
    da29:	8b 4a 18             	mov    0x18(%rdx),%ecx
    da2c:	0f b7 c0             	movzwl %ax,%eax
    da2f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    da32:	48 0f af c1          	imul   %rcx,%rax
    da36:	48 c1 e8 20          	shr    $0x20,%rax
    da3a:	48 39 d0             	cmp    %rdx,%rax
    da3d:	73 13                	jae    da52 <f0+0x2832>
    da3f:	49 01 c4             	add    %rax,%r12
    da42:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    da47:	0f 84 d1 02 00 00    	je     dd1e <f0+0x2afe>
    da4d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    da52:	48 89 de             	mov    %rbx,%rsi
    da55:	48 89 ef             	mov    %rbp,%rdi
    da58:	e8 63 cb ff ff       	call   a5c0 <fwp_hof0.constprop.0>
    da5d:	48 89 ef             	mov    %rbp,%rdi
    da60:	e8 ab 8d ff ff       	call   6810 <fwp_drop0>
    da65:	48 89 df             	mov    %rbx,%rdi
    da68:	e8 a3 8d ff ff       	call   6810 <fwp_drop0>
    da6d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    da74:	00 
    da75:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    da7c:	00 00 
    da7e:	0f 85 95 04 00 00    	jne    df19 <f0+0x2cf9>
    da84:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    da8b:	31 c0                	xor    %eax,%eax
    da8d:	5b                   	pop    %rbx
    da8e:	5d                   	pop    %rbp
    da8f:	41 5c                	pop    %r12
    da91:	41 5d                	pop    %r13
    da93:	41 5e                	pop    %r14
    da95:	c3                   	ret
    da96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    da9d:	00 00 00 
    daa0:	4c 89 ef             	mov    %r13,%rdi
    daa3:	e8 68 78 ff ff       	call   5310 <fwp_rc_forget_slot>
    daa8:	e9 2c d8 ff ff       	jmp    b2d9 <f0+0xb9>
    daad:	0f 1f 00             	nopl   (%rax)
    dab0:	66 85 c0             	test   %ax,%ax
    dab3:	0f 85 ae f5 ff ff    	jne    d067 <f0+0x1e47>
    dab9:	e9 99 f5 ff ff       	jmp    d057 <f0+0x1e37>
    dabe:	66 90                	xchg   %ax,%ax
    dac0:	66 85 c0             	test   %ax,%ax
    dac3:	0f 85 ff f4 ff ff    	jne    cfc8 <f0+0x1da8>
    dac9:	e9 ea f4 ff ff       	jmp    cfb8 <f0+0x1d98>
    dace:	66 90                	xchg   %ax,%ax
    dad0:	66 85 c0             	test   %ax,%ax
    dad3:	0f 85 50 f4 ff ff    	jne    cf29 <f0+0x1d09>
    dad9:	e9 3b f4 ff ff       	jmp    cf19 <f0+0x1cf9>
    dade:	66 90                	xchg   %ax,%ax
    dae0:	66 85 c0             	test   %ax,%ax
    dae3:	0f 85 a1 f3 ff ff    	jne    ce8a <f0+0x1c6a>
    dae9:	e9 8c f3 ff ff       	jmp    ce7a <f0+0x1c5a>
    daee:	66 90                	xchg   %ax,%ax
    daf0:	66 85 c0             	test   %ax,%ax
    daf3:	0f 85 f2 f2 ff ff    	jne    cdeb <f0+0x1bcb>
    daf9:	e9 dd f2 ff ff       	jmp    cddb <f0+0x1bbb>
    dafe:	66 90                	xchg   %ax,%ax
    db00:	66 85 c0             	test   %ax,%ax
    db03:	0f 85 43 f2 ff ff    	jne    cd4c <f0+0x1b2c>
    db09:	e9 2e f2 ff ff       	jmp    cd3c <f0+0x1b1c>
    db0e:	66 90                	xchg   %ax,%ax
    db10:	66 85 c0             	test   %ax,%ax
    db13:	0f 85 94 f1 ff ff    	jne    ccad <f0+0x1a8d>
    db19:	e9 7f f1 ff ff       	jmp    cc9d <f0+0x1a7d>
    db1e:	66 90                	xchg   %ax,%ax
    db20:	66 85 c0             	test   %ax,%ax
    db23:	0f 85 e5 f0 ff ff    	jne    cc0e <f0+0x19ee>
    db29:	e9 d0 f0 ff ff       	jmp    cbfe <f0+0x19de>
    db2e:	66 90                	xchg   %ax,%ax
    db30:	66 85 c0             	test   %ax,%ax
    db33:	0f 85 fd d9 ff ff    	jne    b536 <f0+0x316>
    db39:	e9 e8 d9 ff ff       	jmp    b526 <f0+0x306>
    db3e:	66 90                	xchg   %ax,%ax
    db40:	66 85 c0             	test   %ax,%ax
    db43:	0f 85 57 d9 ff ff    	jne    b4a0 <f0+0x280>
    db49:	e9 42 d9 ff ff       	jmp    b490 <f0+0x270>
    db4e:	66 90                	xchg   %ax,%ax
    db50:	66 85 c0             	test   %ax,%ax
    db53:	0f 85 b1 d8 ff ff    	jne    b40a <f0+0x1ea>
    db59:	e9 9c d8 ff ff       	jmp    b3fa <f0+0x1da>
    db5e:	66 90                	xchg   %ax,%ax
    db60:	66 85 c0             	test   %ax,%ax
    db63:	0f 85 0e eb ff ff    	jne    c677 <f0+0x1457>
    db69:	e9 f9 ea ff ff       	jmp    c667 <f0+0x1447>
    db6e:	66 90                	xchg   %ax,%ax
    db70:	66 85 c0             	test   %ax,%ax
    db73:	0f 85 5f ea ff ff    	jne    c5d8 <f0+0x13b8>
    db79:	e9 4a ea ff ff       	jmp    c5c8 <f0+0x13a8>
    db7e:	66 90                	xchg   %ax,%ax
    db80:	66 85 c0             	test   %ax,%ax
    db83:	0f 85 e2 da ff ff    	jne    b66b <f0+0x44b>
    db89:	e9 cd da ff ff       	jmp    b65b <f0+0x43b>
    db8e:	66 90                	xchg   %ax,%ax
    db90:	66 85 c0             	test   %ax,%ax
    db93:	0f 85 33 da ff ff    	jne    b5cc <f0+0x3ac>
    db99:	e9 1e da ff ff       	jmp    b5bc <f0+0x39c>
    db9e:	66 90                	xchg   %ax,%ax
    dba0:	66 85 c0             	test   %ax,%ax
    dba3:	0f 85 c6 ef ff ff    	jne    cb6f <f0+0x194f>
    dba9:	e9 b1 ef ff ff       	jmp    cb5f <f0+0x193f>
    dbae:	66 90                	xchg   %ax,%ax
    dbb0:	66 85 c0             	test   %ax,%ax
    dbb3:	0f 85 17 ef ff ff    	jne    cad0 <f0+0x18b0>
    dbb9:	e9 02 ef ff ff       	jmp    cac0 <f0+0x18a0>
    dbbe:	66 90                	xchg   %ax,%ax
    dbc0:	66 85 c0             	test   %ax,%ax
    dbc3:	0f 85 68 ee ff ff    	jne    ca31 <f0+0x1811>
    dbc9:	e9 53 ee ff ff       	jmp    ca21 <f0+0x1801>
    dbce:	66 90                	xchg   %ax,%ax
    dbd0:	66 85 c0             	test   %ax,%ax
    dbd3:	0f 85 b9 ed ff ff    	jne    c992 <f0+0x1772>
    dbd9:	e9 a4 ed ff ff       	jmp    c982 <f0+0x1762>
    dbde:	66 90                	xchg   %ax,%ax
    dbe0:	66 85 c0             	test   %ax,%ax
    dbe3:	0f 85 0a ed ff ff    	jne    c8f3 <f0+0x16d3>
    dbe9:	e9 f5 ec ff ff       	jmp    c8e3 <f0+0x16c3>
    dbee:	66 90                	xchg   %ax,%ax
    dbf0:	66 85 c0             	test   %ax,%ax
    dbf3:	0f 85 5b ec ff ff    	jne    c854 <f0+0x1634>
    dbf9:	e9 46 ec ff ff       	jmp    c844 <f0+0x1624>
    dbfe:	66 90                	xchg   %ax,%ax
    dc00:	66 85 c0             	test   %ax,%ax
    dc03:	0f 85 ac eb ff ff    	jne    c7b5 <f0+0x1595>
    dc09:	e9 97 eb ff ff       	jmp    c7a5 <f0+0x1585>
    dc0e:	66 90                	xchg   %ax,%ax
    dc10:	66 85 c0             	test   %ax,%ax
    dc13:	0f 85 fd ea ff ff    	jne    c716 <f0+0x14f6>
    dc19:	e9 e8 ea ff ff       	jmp    c706 <f0+0x14e6>
    dc1e:	66 90                	xchg   %ax,%ax
    dc20:	66 85 c0             	test   %ax,%ax
    dc23:	0f 85 29 fe ff ff    	jne    da52 <f0+0x2832>
    dc29:	e9 14 fe ff ff       	jmp    da42 <f0+0x2822>
    dc2e:	66 90                	xchg   %ax,%ax
    dc30:	66 85 c0             	test   %ax,%ax
    dc33:	0f 85 7f fd ff ff    	jne    d9b8 <f0+0x2798>
    dc39:	e9 6a fd ff ff       	jmp    d9a8 <f0+0x2788>
    dc3e:	66 90                	xchg   %ax,%ax
    dc40:	66 85 c0             	test   %ax,%ax
    dc43:	0f 85 d0 fc ff ff    	jne    d919 <f0+0x26f9>
    dc49:	e9 bb fc ff ff       	jmp    d909 <f0+0x26e9>
    dc4e:	66 90                	xchg   %ax,%ax
    dc50:	66 85 c0             	test   %ax,%ax
    dc53:	0f 85 21 fc ff ff    	jne    d87a <f0+0x265a>
    dc59:	e9 0c fc ff ff       	jmp    d86a <f0+0x264a>
    dc5e:	66 90                	xchg   %ax,%ax
    dc60:	66 85 c0             	test   %ax,%ax
    dc63:	0f 85 72 fb ff ff    	jne    d7db <f0+0x25bb>
    dc69:	e9 5d fb ff ff       	jmp    d7cb <f0+0x25ab>
    dc6e:	66 90                	xchg   %ax,%ax
    dc70:	66 85 c0             	test   %ax,%ax
    dc73:	0f 85 c3 fa ff ff    	jne    d73c <f0+0x251c>
    dc79:	e9 ae fa ff ff       	jmp    d72c <f0+0x250c>
    dc7e:	66 90                	xchg   %ax,%ax
    dc80:	66 85 c0             	test   %ax,%ax
    dc83:	0f 85 14 fa ff ff    	jne    d69d <f0+0x247d>
    dc89:	e9 ff f9 ff ff       	jmp    d68d <f0+0x246d>
    dc8e:	66 90                	xchg   %ax,%ax
    dc90:	66 85 c0             	test   %ax,%ax
    dc93:	0f 85 65 f9 ff ff    	jne    d5fe <f0+0x23de>
    dc99:	e9 50 f9 ff ff       	jmp    d5ee <f0+0x23ce>
    dc9e:	66 90                	xchg   %ax,%ax
    dca0:	66 85 c0             	test   %ax,%ax
    dca3:	0f 85 b6 f8 ff ff    	jne    d55f <f0+0x233f>
    dca9:	e9 a1 f8 ff ff       	jmp    d54f <f0+0x232f>
    dcae:	66 90                	xchg   %ax,%ax
    dcb0:	66 85 c0             	test   %ax,%ax
    dcb3:	0f 85 07 f8 ff ff    	jne    d4c0 <f0+0x22a0>
    dcb9:	e9 f2 f7 ff ff       	jmp    d4b0 <f0+0x2290>
    dcbe:	66 90                	xchg   %ax,%ax
    dcc0:	66 85 c0             	test   %ax,%ax
    dcc3:	0f 85 58 f7 ff ff    	jne    d421 <f0+0x2201>
    dcc9:	e9 43 f7 ff ff       	jmp    d411 <f0+0x21f1>
    dcce:	66 90                	xchg   %ax,%ax
    dcd0:	66 85 c0             	test   %ax,%ax
    dcd3:	0f 85 a9 f6 ff ff    	jne    d382 <f0+0x2162>
    dcd9:	e9 94 f6 ff ff       	jmp    d372 <f0+0x2152>
    dcde:	66 90                	xchg   %ax,%ax
    dce0:	66 85 c0             	test   %ax,%ax
    dce3:	0f 85 fa f5 ff ff    	jne    d2e3 <f0+0x20c3>
    dce9:	e9 e5 f5 ff ff       	jmp    d2d3 <f0+0x20b3>
    dcee:	66 90                	xchg   %ax,%ax
    dcf0:	66 85 c0             	test   %ax,%ax
    dcf3:	0f 85 4b f5 ff ff    	jne    d244 <f0+0x2024>
    dcf9:	e9 36 f5 ff ff       	jmp    d234 <f0+0x2014>
    dcfe:	66 90                	xchg   %ax,%ax
    dd00:	66 85 c0             	test   %ax,%ax
    dd03:	0f 85 9c f4 ff ff    	jne    d1a5 <f0+0x1f85>
    dd09:	e9 87 f4 ff ff       	jmp    d195 <f0+0x1f75>
    dd0e:	66 90                	xchg   %ax,%ax
    dd10:	66 85 c0             	test   %ax,%ax
    dd13:	0f 85 ed f3 ff ff    	jne    d106 <f0+0x1ee6>
    dd19:	e9 d8 f3 ff ff       	jmp    d0f6 <f0+0x1ed6>
    dd1e:	4c 89 e7             	mov    %r12,%rdi
    dd21:	e8 ea 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dd26:	e9 22 fd ff ff       	jmp    da4d <f0+0x282d>
    dd2b:	4c 89 e7             	mov    %r12,%rdi
    dd2e:	e8 dd 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dd33:	e9 cd d6 ff ff       	jmp    b405 <f0+0x1e5>
    dd38:	4c 89 e7             	mov    %r12,%rdi
    dd3b:	e8 d0 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dd40:	e9 56 d7 ff ff       	jmp    b49b <f0+0x27b>
    dd45:	4c 89 e7             	mov    %r12,%rdi
    dd48:	e8 c3 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dd4d:	e9 df d7 ff ff       	jmp    b531 <f0+0x311>
    dd52:	4c 89 e7             	mov    %r12,%rdi
    dd55:	e8 b6 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dd5a:	e9 68 d8 ff ff       	jmp    b5c7 <f0+0x3a7>
    dd5f:	4c 89 e7             	mov    %r12,%rdi
    dd62:	e8 a9 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dd67:	e9 fa d8 ff ff       	jmp    b666 <f0+0x446>
    dd6c:	4c 89 e7             	mov    %r12,%rdi
    dd6f:	e8 9c 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dd74:	e9 5a e8 ff ff       	jmp    c5d3 <f0+0x13b3>
    dd79:	4c 89 e7             	mov    %r12,%rdi
    dd7c:	e8 8f 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dd81:	e9 ec e8 ff ff       	jmp    c672 <f0+0x1452>
    dd86:	4c 89 e7             	mov    %r12,%rdi
    dd89:	e8 82 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dd8e:	e9 7e e9 ff ff       	jmp    c711 <f0+0x14f1>
    dd93:	4c 89 e7             	mov    %r12,%rdi
    dd96:	e8 75 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dd9b:	e9 10 ea ff ff       	jmp    c7b0 <f0+0x1590>
    dda0:	4c 89 e7             	mov    %r12,%rdi
    dda3:	e8 68 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dda8:	e9 a2 ea ff ff       	jmp    c84f <f0+0x162f>
    ddad:	4c 89 e7             	mov    %r12,%rdi
    ddb0:	e8 5b 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    ddb5:	e9 34 eb ff ff       	jmp    c8ee <f0+0x16ce>
    ddba:	4c 89 e7             	mov    %r12,%rdi
    ddbd:	e8 4e 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    ddc2:	e9 c6 eb ff ff       	jmp    c98d <f0+0x176d>
    ddc7:	4c 89 e7             	mov    %r12,%rdi
    ddca:	e8 41 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    ddcf:	e9 58 ec ff ff       	jmp    ca2c <f0+0x180c>
    ddd4:	4c 89 e7             	mov    %r12,%rdi
    ddd7:	e8 34 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dddc:	e9 ea ec ff ff       	jmp    cacb <f0+0x18ab>
    dde1:	4c 89 e7             	mov    %r12,%rdi
    dde4:	e8 27 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    dde9:	e9 7c ed ff ff       	jmp    cb6a <f0+0x194a>
    ddee:	4c 89 e7             	mov    %r12,%rdi
    ddf1:	e8 1a 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    ddf6:	e9 0e ee ff ff       	jmp    cc09 <f0+0x19e9>
    ddfb:	4c 89 e7             	mov    %r12,%rdi
    ddfe:	e8 0d 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    de03:	e9 a0 ee ff ff       	jmp    cca8 <f0+0x1a88>
    de08:	4c 89 e7             	mov    %r12,%rdi
    de0b:	e8 00 75 ff ff       	call   5310 <fwp_rc_forget_slot>
    de10:	e9 32 ef ff ff       	jmp    cd47 <f0+0x1b27>
    de15:	4c 89 e7             	mov    %r12,%rdi
    de18:	e8 f3 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de1d:	e9 c4 ef ff ff       	jmp    cde6 <f0+0x1bc6>
    de22:	4c 89 e7             	mov    %r12,%rdi
    de25:	e8 e6 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de2a:	e9 56 f0 ff ff       	jmp    ce85 <f0+0x1c65>
    de2f:	4c 89 e7             	mov    %r12,%rdi
    de32:	e8 d9 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de37:	e9 e8 f0 ff ff       	jmp    cf24 <f0+0x1d04>
    de3c:	4c 89 e7             	mov    %r12,%rdi
    de3f:	e8 cc 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de44:	e9 7a f1 ff ff       	jmp    cfc3 <f0+0x1da3>
    de49:	4c 89 e7             	mov    %r12,%rdi
    de4c:	e8 bf 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de51:	e9 0c f2 ff ff       	jmp    d062 <f0+0x1e42>
    de56:	4c 89 e7             	mov    %r12,%rdi
    de59:	e8 b2 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de5e:	e9 9e f2 ff ff       	jmp    d101 <f0+0x1ee1>
    de63:	4c 89 e7             	mov    %r12,%rdi
    de66:	e8 a5 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de6b:	e9 30 f3 ff ff       	jmp    d1a0 <f0+0x1f80>
    de70:	4c 89 e7             	mov    %r12,%rdi
    de73:	e8 98 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de78:	e9 c2 f3 ff ff       	jmp    d23f <f0+0x201f>
    de7d:	4c 89 e7             	mov    %r12,%rdi
    de80:	e8 8b 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de85:	e9 54 f4 ff ff       	jmp    d2de <f0+0x20be>
    de8a:	4c 89 e7             	mov    %r12,%rdi
    de8d:	e8 7e 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de92:	e9 e6 f4 ff ff       	jmp    d37d <f0+0x215d>
    de97:	4c 89 e7             	mov    %r12,%rdi
    de9a:	e8 71 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    de9f:	e9 78 f5 ff ff       	jmp    d41c <f0+0x21fc>
    dea4:	4c 89 e7             	mov    %r12,%rdi
    dea7:	e8 64 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    deac:	e9 0a f6 ff ff       	jmp    d4bb <f0+0x229b>
    deb1:	4c 89 e7             	mov    %r12,%rdi
    deb4:	e8 57 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    deb9:	e9 9c f6 ff ff       	jmp    d55a <f0+0x233a>
    debe:	4c 89 e7             	mov    %r12,%rdi
    dec1:	e8 4a 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    dec6:	e9 2e f7 ff ff       	jmp    d5f9 <f0+0x23d9>
    decb:	4c 89 e7             	mov    %r12,%rdi
    dece:	e8 3d 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    ded3:	e9 c0 f7 ff ff       	jmp    d698 <f0+0x2478>
    ded8:	4c 89 e7             	mov    %r12,%rdi
    dedb:	e8 30 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    dee0:	e9 52 f8 ff ff       	jmp    d737 <f0+0x2517>
    dee5:	4c 89 e7             	mov    %r12,%rdi
    dee8:	e8 23 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    deed:	e9 e4 f8 ff ff       	jmp    d7d6 <f0+0x25b6>
    def2:	4c 89 e7             	mov    %r12,%rdi
    def5:	e8 16 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    defa:	e9 76 f9 ff ff       	jmp    d875 <f0+0x2655>
    deff:	4c 89 e7             	mov    %r12,%rdi
    df02:	e8 09 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    df07:	e9 08 fa ff ff       	jmp    d914 <f0+0x26f4>
    df0c:	4c 89 e7             	mov    %r12,%rdi
    df0f:	e8 fc 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    df14:	e9 9a fa ff ff       	jmp    d9b3 <f0+0x2793>
    df19:	e8 42 55 ff ff       	call   3460 <__stack_chk_fail@plt>
    df1e:	66 90                	xchg   %ax,%ax

000000000000df20 <fwp_main_thread>:
    df20:	f3 0f 1e fa          	endbr64
    df24:	41 54                	push   %r12
    df26:	55                   	push   %rbp
    df27:	53                   	push   %rbx
    df28:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    df2f:	8b 0d ef 6b 01 00    	mov    0x16bef(%rip),%ecx        # 24b24 <fwp_heap+0x13a4>
    df35:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    df3c:	00 00 
    df3e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    df45:	00 
    df46:	31 c0                	xor    %eax,%eax
    df48:	85 c9                	test   %ecx,%ecx
    df4a:	0f 84 68 06 00 00    	je     e5b8 <fwp_main_thread+0x698>
    df50:	8b 15 d2 6b 01 00    	mov    0x16bd2(%rip),%edx        # 24b28 <fwp_heap+0x13a8>
    df56:	85 d2                	test   %edx,%edx
    df58:	0f 85 42 06 00 00    	jne    e5a0 <fwp_main_thread+0x680>
    df5e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    df63:	31 f6                	xor    %esi,%esi
    df65:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    df6a:	48 c7 05 a3 51 01 00 	movq   $0x40000000,0x151a3(%rip)        # 23118 <fwp_main_stack_size>
    df71:	00 00 00 40 
    df75:	48 89 05 a4 51 01 00 	mov    %rax,0x151a4(%rip)        # 23120 <fwp_main_stack_top>
    df7c:	48 8d 05 1d 51 00 00 	lea    0x511d(%rip),%rax        # 130a0 <alt.5>
    df83:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    df88:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    df8f:	01 00 
    df91:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    df98:	00 
    df99:	e8 22 57 ff ff       	call   36c0 <sigaltstack@plt>
    df9e:	85 c0                	test   %eax,%eax
    dfa0:	0f 85 4a 06 00 00    	jne    e5f0 <fwp_main_thread+0x6d0>
    dfa6:	31 c0                	xor    %eax,%eax
    dfa8:	b9 12 00 00 00       	mov    $0x12,%ecx
    dfad:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    dfb2:	f3 48 ab             	rep stos %rax,(%rdi)
    dfb5:	48 8d 05 34 5d ff ff 	lea    -0xa2cc(%rip),%rax        # 3cf0 <fwp_segv>
    dfbc:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    dfc1:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    dfc8:	04 00 00 08 
    dfcc:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    dfd1:	e8 aa 55 ff ff       	call   3580 <sigemptyset@plt>
    dfd6:	85 c0                	test   %eax,%eax
    dfd8:	0f 85 12 06 00 00    	jne    e5f0 <fwp_main_thread+0x6d0>
    dfde:	31 d2                	xor    %edx,%edx
    dfe0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    dfe5:	bf 0b 00 00 00       	mov    $0xb,%edi
    dfea:	e8 11 54 ff ff       	call   3400 <sigaction@plt>
    dfef:	85 c0                	test   %eax,%eax
    dff1:	0f 85 f9 05 00 00    	jne    e5f0 <fwp_main_thread+0x6d0>
    dff7:	31 d2                	xor    %edx,%edx
    dff9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    dffe:	bf 07 00 00 00       	mov    $0x7,%edi
    e003:	e8 f8 53 ff ff       	call   3400 <sigaction@plt>
    e008:	85 c0                	test   %eax,%eax
    e00a:	0f 85 e0 05 00 00    	jne    e5f0 <fwp_main_thread+0x6d0>
    e010:	8b 05 7a 50 00 00    	mov    0x507a(%rip),%eax        # 13090 <st.3>
    e016:	85 c0                	test   %eax,%eax
    e018:	0f 84 62 05 00 00    	je     e580 <fwp_main_thread+0x660>
    e01e:	48 8b 2d 3b 57 01 00 	mov    0x1573b(%rip),%rbp        # 23760 <fwp_cur>
    e025:	48 85 ed             	test   %rbp,%rbp
    e028:	0f 84 72 03 00 00    	je     e3a0 <fwp_main_thread+0x480>
    e02e:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    e033:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    e037:	48 89 eb             	mov    %rbp,%rbx
    e03a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e03f:	0f 84 41 01 00 00    	je     e186 <fwp_main_thread+0x266>
    e045:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    e04a:	0f 84 80 02 00 00    	je     e2d0 <fwp_main_thread+0x3b0>
    e050:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e054:	0f 84 66 02 00 00    	je     e2c0 <fwp_main_thread+0x3a0>
    e05a:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e05e:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e062:	0f 85 e8 02 00 00    	jne    e350 <fwp_main_thread+0x430>
    e068:	48 8b 43 60          	mov    0x60(%rbx),%rax
    e06c:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e073:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e077:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e07e:	00 00 00 00 
    e082:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e089:	48 85 d2             	test   %rdx,%rdx
    e08c:	74 07                	je     e095 <fwp_main_thread+0x175>
    e08e:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e095:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e099:	48 85 c0             	test   %rax,%rax
    e09c:	74 34                	je     e0d2 <fwp_main_thread+0x1b2>
    e09e:	48 89 43 68          	mov    %rax,0x68(%rbx)
    e0a2:	48 8b 05 8f 56 01 00 	mov    0x1568f(%rip),%rax        # 23738 <fwp_timers>
    e0a9:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    e0ad:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    e0b4:	00 00 00 00 
    e0b8:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    e0bf:	48 85 c0             	test   %rax,%rax
    e0c2:	74 07                	je     e0cb <fwp_main_thread+0x1ab>
    e0c4:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    e0cb:	48 89 1d 66 56 01 00 	mov    %rbx,0x15666(%rip)        # 23738 <fwp_timers>
    e0d2:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    e0d6:	e8 75 91 ff ff       	call   7250 <fwp_block>
    e0db:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    e0e2:	48 85 c9             	test   %rcx,%rcx
    e0e5:	74 47                	je     e12e <fwp_main_thread+0x20e>
    e0e7:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    e0ee:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e0f5:	48 85 d2             	test   %rdx,%rdx
    e0f8:	0f 84 92 02 00 00    	je     e390 <fwp_main_thread+0x470>
    e0fe:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    e105:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e10c:	48 85 c0             	test   %rax,%rax
    e10f:	74 07                	je     e118 <fwp_main_thread+0x1f8>
    e111:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    e118:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    e11f:	00 00 00 00 
    e123:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e127:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    e12e:	48 8b 0d 2b 56 01 00 	mov    0x1562b(%rip),%rcx        # 23760 <fwp_cur>
    e135:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    e139:	0f 84 01 02 00 00    	je     e340 <fwp_main_thread+0x420>
    e13f:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    e146:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    e14d:	48 85 d2             	test   %rdx,%rdx
    e150:	0f 84 fa 03 00 00    	je     e550 <fwp_main_thread+0x630>
    e156:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    e15d:	48 85 c0             	test   %rax,%rax
    e160:	74 07                	je     e169 <fwp_main_thread+0x249>
    e162:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    e169:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e16d:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    e171:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    e178:	48 89 cb             	mov    %rcx,%rbx
    e17b:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e180:	0f 85 bf fe ff ff    	jne    e045 <fwp_main_thread+0x125>
    e186:	48 83 3d 6a 72 01 00 	cmpq   $0x0,0x1726a(%rip)        # 253f8 <fwp_state_len>
    e18d:	00 
    e18e:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    e192:	0f 84 ba 00 00 00    	je     e252 <fwp_main_thread+0x332>
    e198:	48 39 1d b9 55 01 00 	cmp    %rbx,0x155b9(%rip)        # 23758 <fwp_root>
    e19f:	c7 05 f7 4e 01 00 00 	movl   $0x0,0x14ef7(%rip)        # 230a0 <fwp_exit_code>
    e1a6:	00 00 00 
    e1a9:	0f 85 5f 04 00 00    	jne    e60e <fwp_main_thread+0x6ee>
    e1af:	48 85 db             	test   %rbx,%rbx
    e1b2:	0f 84 0e 02 00 00    	je     e3c6 <fwp_main_thread+0x4a6>
    e1b8:	48 8b 15 69 55 01 00 	mov    0x15569(%rip),%rdx        # 23728 <fwp_tasks_active>
    e1bf:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    e1c3:	48 85 d2             	test   %rdx,%rdx
    e1c6:	0f 84 fa 01 00 00    	je     e3c6 <fwp_main_thread+0x4a6>
    e1cc:	0f 1f 40 00          	nopl   0x0(%rax)
    e1d0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    e1d4:	75 08                	jne    e1de <fwp_main_thread+0x2be>
    e1d6:	48 89 d7             	mov    %rdx,%rdi
    e1d9:	e8 d2 5e ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    e1de:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    e1e5:	48 85 d2             	test   %rdx,%rdx
    e1e8:	75 e6                	jne    e1d0 <fwp_main_thread+0x2b0>
    e1ea:	eb 31                	jmp    e21d <fwp_main_thread+0x2fd>
    e1ec:	0f 1f 40 00          	nopl   0x0(%rax)
    e1f0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    e1f7:	48 89 1d 42 55 01 00 	mov    %rbx,0x15542(%rip)        # 23740 <fwp_ready_tail>
    e1fe:	e8 4d 90 ff ff       	call   7250 <fwp_block>
    e203:	e8 48 8e ff ff       	call   7050 <fwp_free_zombie>
    e208:	48 83 3d 18 55 01 00 	cmpq   $0x0,0x15518(%rip)        # 23728 <fwp_tasks_active>
    e20f:	00 
    e210:	0f 84 b0 01 00 00    	je     e3c6 <fwp_main_thread+0x4a6>
    e216:	48 8b 1d 3b 55 01 00 	mov    0x1553b(%rip),%rbx        # 23758 <fwp_root>
    e21d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    e221:	75 db                	jne    e1fe <fwp_main_thread+0x2de>
    e223:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    e227:	75 d5                	jne    e1fe <fwp_main_thread+0x2de>
    e229:	48 8b 05 10 55 01 00 	mov    0x15510(%rip),%rax        # 23740 <fwp_ready_tail>
    e230:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    e234:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    e23b:	00 00 00 00 
    e23f:	48 85 c0             	test   %rax,%rax
    e242:	75 ac                	jne    e1f0 <fwp_main_thread+0x2d0>
    e244:	48 89 1d fd 54 01 00 	mov    %rbx,0x154fd(%rip)        # 23748 <fwp_ready_head>
    e24b:	eb aa                	jmp    e1f7 <fwp_main_thread+0x2d7>
    e24d:	0f 1f 00             	nopl   (%rax)
    e250:	31 db                	xor    %ebx,%ebx
    e252:	48 83 3d 8e 71 01 00 	cmpq   $0x0,0x1718e(%rip)        # 253e8 <fwp_state_owners>
    e259:	00 
    e25a:	0f 85 38 ff ff ff    	jne    e198 <fwp_main_thread+0x278>
    e260:	48 8b 3d 99 71 01 00 	mov    0x17199(%rip),%rdi        # 25400 <fwp_state>
    e267:	e8 e4 72 ff ff       	call   5550 <fwp_mem_free>
    e26c:	48 c7 05 89 71 01 00 	movq   $0x0,0x17189(%rip)        # 25400 <fwp_state>
    e273:	00 00 00 00 
    e277:	48 c7 05 6e 71 01 00 	movq   $0x0,0x1716e(%rip)        # 253f0 <fwp_state_cap>
    e27e:	00 00 00 00 
    e282:	48 85 db             	test   %rbx,%rbx
    e285:	0f 84 46 03 00 00    	je     e5d1 <fwp_main_thread+0x6b1>
    e28b:	48 39 1d c6 54 01 00 	cmp    %rbx,0x154c6(%rip)        # 23758 <fwp_root>
    e292:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    e299:	00 00 00 00 
    e29d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    e2a4:	00 00 00 00 
    e2a8:	c7 05 ee 4d 01 00 00 	movl   $0x0,0x14dee(%rip)        # 230a0 <fwp_exit_code>
    e2af:	00 00 00 
    e2b2:	0f 84 00 ff ff ff    	je     e1b8 <fwp_main_thread+0x298>
    e2b8:	e9 93 54 ff ff       	jmp    3750 <fwp_main_thread.cold>
    e2bd:	0f 1f 00             	nopl   (%rax)
    e2c0:	e8 4b 60 ff ff       	call   4310 <fwp_now_ns>
    e2c5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    e2c9:	0f 8d 91 02 00 00    	jge    e560 <fwp_main_thread+0x640>
    e2cf:	90                   	nop
    e2d0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e2d4:	0f 85 80 fd ff ff    	jne    e05a <fwp_main_thread+0x13a>
    e2da:	48 8b 45 60          	mov    0x60(%rbp),%rax
    e2de:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e2e2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e2e6:	0f 85 80 fd ff ff    	jne    e06c <fwp_main_thread+0x14c>
    e2ec:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    e2f0:	48 85 c9             	test   %rcx,%rcx
    e2f3:	0f 84 73 fd ff ff    	je     e06c <fwp_main_thread+0x14c>
    e2f9:	48 85 c0             	test   %rax,%rax
    e2fc:	0f 84 ff 02 00 00    	je     e601 <fwp_main_thread+0x6e1>
    e302:	48 39 c8             	cmp    %rcx,%rax
    e305:	48 0f 4f c1          	cmovg  %rcx,%rax
    e309:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e310:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e314:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e31b:	00 00 00 00 
    e31f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e326:	48 85 d2             	test   %rdx,%rdx
    e329:	74 07                	je     e332 <fwp_main_thread+0x412>
    e32b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e332:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e336:	e9 63 fd ff ff       	jmp    e09e <fwp_main_thread+0x17e>
    e33b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e340:	48 89 cb             	mov    %rcx,%rbx
    e343:	e9 f2 fc ff ff       	jmp    e03a <fwp_main_thread+0x11a>
    e348:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e34f:	00 
    e350:	48 8b 45 40          	mov    0x40(%rbp),%rax
    e354:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e35b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e362:	00 00 00 00 
    e366:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    e36d:	48 85 c0             	test   %rax,%rax
    e370:	0f 84 52 02 00 00    	je     e5c8 <fwp_main_thread+0x6a8>
    e376:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    e37d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e381:	e9 4c fd ff ff       	jmp    e0d2 <fwp_main_thread+0x1b2>
    e386:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e38d:	00 00 00 
    e390:	48 89 01             	mov    %rax,(%rcx)
    e393:	e9 74 fd ff ff       	jmp    e10c <fwp_main_thread+0x1ec>
    e398:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e39f:	00 
    e3a0:	48 83 3d 50 70 01 00 	cmpq   $0x0,0x17050(%rip)        # 253f8 <fwp_state_len>
    e3a7:	00 
    e3a8:	0f 84 a2 fe ff ff    	je     e250 <fwp_main_thread+0x330>
    e3ae:	48 83 3d a2 53 01 00 	cmpq   $0x0,0x153a2(%rip)        # 23758 <fwp_root>
    e3b5:	00 
    e3b6:	c7 05 e0 4c 01 00 00 	movl   $0x0,0x14ce0(%rip)        # 230a0 <fwp_exit_code>
    e3bd:	00 00 00 
    e3c0:	0f 85 43 02 00 00    	jne    e609 <fwp_main_thread+0x6e9>
    e3c6:	e8 85 8c ff ff       	call   7050 <fwp_free_zombie>
    e3cb:	48 83 3d 75 53 01 00 	cmpq   $0x0,0x15375(%rip)        # 23748 <fwp_ready_head>
    e3d2:	00 
    e3d3:	0f 85 77 53 ff ff    	jne    3750 <fwp_main_thread.cold>
    e3d9:	48 83 3d 57 53 01 00 	cmpq   $0x0,0x15357(%rip)        # 23738 <fwp_timers>
    e3e0:	00 
    e3e1:	0f 85 69 53 ff ff    	jne    3750 <fwp_main_thread.cold>
    e3e7:	8b 1d 3f 4d 01 00    	mov    0x14d3f(%rip),%ebx        # 2312c <fwp_stack_pool_n>
    e3ed:	85 db                	test   %ebx,%ebx
    e3ef:	74 36                	je     e427 <fwp_main_thread+0x507>
    e3f1:	83 eb 01             	sub    $0x1,%ebx
    e3f4:	48 8d 05 45 4d 01 00 	lea    0x14d45(%rip),%rax        # 23140 <fwp_stack_pool>
    e3fb:	48 63 d3             	movslq %ebx,%rdx
    e3fe:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    e402:	eb 07                	jmp    e40b <fwp_main_thread+0x4eb>
    e404:	0f 1f 40 00          	nopl   0x0(%rax)
    e408:	83 eb 01             	sub    $0x1,%ebx
    e40b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    e40f:	be 00 00 00 10       	mov    $0x10000000,%esi
    e414:	89 1d 12 4d 01 00    	mov    %ebx,0x14d12(%rip)        # 2312c <fwp_stack_pool_n>
    e41a:	48 83 ed 08          	sub    $0x8,%rbp
    e41e:	e8 bd 51 ff ff       	call   35e0 <munmap@plt>
    e423:	85 db                	test   %ebx,%ebx
    e425:	75 e1                	jne    e408 <fwp_main_thread+0x4e8>
    e427:	8b 3d f3 4b 00 00    	mov    0x4bf3(%rip),%edi        # 13020 <fwp_epfd>
    e42d:	85 ff                	test   %edi,%edi
    e42f:	78 05                	js     e436 <fwp_main_thread+0x516>
    e431:	e8 9a 50 ff ff       	call   34d0 <close@plt>
    e436:	4c 8b 25 03 4f 01 00 	mov    0x14f03(%rip),%r12        # 23340 <fwp_nfdws>
    e43d:	48 8b 2d 04 4f 01 00 	mov    0x14f04(%rip),%rbp        # 23348 <fwp_fdws>
    e444:	31 db                	xor    %ebx,%ebx
    e446:	c7 05 d0 4b 00 00 ff 	movl   $0xffffffff,0x4bd0(%rip)        # 13020 <fwp_epfd>
    e44d:	ff ff ff 
    e450:	4d 85 e4             	test   %r12,%r12
    e453:	74 38                	je     e48d <fwp_main_thread+0x56d>
    e455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    e45c:	00 00 00 00 
    e460:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    e465:	48 85 ff             	test   %rdi,%rdi
    e468:	74 1a                	je     e484 <fwp_main_thread+0x564>
    e46a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    e46e:	0f 85 dc 52 ff ff    	jne    3750 <fwp_main_thread.cold>
    e474:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    e479:	0f 85 d1 52 ff ff    	jne    3750 <fwp_main_thread.cold>
    e47f:	e8 cc 70 ff ff       	call   5550 <fwp_mem_free>
    e484:	48 83 c3 01          	add    $0x1,%rbx
    e488:	4c 39 e3             	cmp    %r12,%rbx
    e48b:	75 d3                	jne    e460 <fwp_main_thread+0x540>
    e48d:	48 89 ef             	mov    %rbp,%rdi
    e490:	e8 bb 70 ff ff       	call   5550 <fwp_mem_free>
    e495:	48 8b 15 bc 52 01 00 	mov    0x152bc(%rip),%rdx        # 23758 <fwp_root>
    e49c:	48 c7 05 a1 4e 01 00 	movq   $0x0,0x14ea1(%rip)        # 23348 <fwp_fdws>
    e4a3:	00 00 00 00 
    e4a7:	48 c7 05 8e 4e 01 00 	movq   $0x0,0x14e8e(%rip)        # 23340 <fwp_nfdws>
    e4ae:	00 00 00 00 
    e4b2:	48 85 d2             	test   %rdx,%rdx
    e4b5:	74 4e                	je     e505 <fwp_main_thread+0x5e5>
    e4b7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    e4bc:	0f 85 8e 52 ff ff    	jne    3750 <fwp_main_thread.cold>
    e4c2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    e4c9:	00 
    e4ca:	0f 85 80 52 ff ff    	jne    3750 <fwp_main_thread.cold>
    e4d0:	48 83 3d 20 6f 01 00 	cmpq   $0x0,0x16f20(%rip)        # 253f8 <fwp_state_len>
    e4d7:	00 
    e4d8:	0f 85 72 52 ff ff    	jne    3750 <fwp_main_thread.cold>
    e4de:	48 83 3d 02 6f 01 00 	cmpq   $0x0,0x16f02(%rip)        # 253e8 <fwp_state_owners>
    e4e5:	00 
    e4e6:	0f 85 64 52 ff ff    	jne    3750 <fwp_main_thread.cold>
    e4ec:	b9 79 00 00 00       	mov    $0x79,%ecx
    e4f1:	31 c0                	xor    %eax,%eax
    e4f3:	48 8d 3d 66 4e 01 00 	lea    0x14e66(%rip),%rdi        # 23360 <fwp_root_context>
    e4fa:	f3 48 ab             	rep stos %rax,(%rdi)
    e4fd:	48 89 d7             	mov    %rdx,%rdi
    e500:	e8 4b 70 ff ff       	call   5550 <fwp_mem_free>
    e505:	48 8b 3d 34 4b 00 00 	mov    0x4b34(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    e50c:	48 c7 05 49 52 01 00 	movq   $0x0,0x15249(%rip)        # 23760 <fwp_cur>
    e513:	00 00 00 00 
    e517:	48 c7 05 36 52 01 00 	movq   $0x0,0x15236(%rip)        # 23758 <fwp_root>
    e51e:	00 00 00 00 
    e522:	e8 99 50 ff ff       	call   35c0 <fflush@plt>
    e527:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    e52e:	00 
    e52f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e536:	00 00 
    e538:	0f 85 be 00 00 00    	jne    e5fc <fwp_main_thread+0x6dc>
    e53e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    e545:	31 c0                	xor    %eax,%eax
    e547:	5b                   	pop    %rbx
    e548:	5d                   	pop    %rbp
    e549:	41 5c                	pop    %r12
    e54b:	c3                   	ret
    e54c:	0f 1f 40 00          	nopl   0x0(%rax)
    e550:	48 89 05 e1 51 01 00 	mov    %rax,0x151e1(%rip)        # 23738 <fwp_timers>
    e557:	e9 01 fc ff ff       	jmp    e15d <fwp_main_thread+0x23d>
    e55c:	0f 1f 40 00          	nopl   0x0(%rax)
    e560:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    e564:	0f 85 66 fd ff ff    	jne    e2d0 <fwp_main_thread+0x3b0>
    e56a:	48 89 ef             	mov    %rbp,%rdi
    e56d:	e8 3e 5b ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    e572:	e9 59 fd ff ff       	jmp    e2d0 <fwp_main_thread+0x3b0>
    e577:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e57e:	00 00 
    e580:	e8 9b cc ff ff       	call   b220 <f0>
    e585:	48 c7 05 f8 4a 00 00 	movq   $0x0,0x4af8(%rip)        # 13088 <v.2>
    e58c:	00 00 00 00 
    e590:	c7 05 f6 4a 00 00 01 	movl   $0x1,0x4af6(%rip)        # 13090 <st.3>
    e597:	00 00 00 
    e59a:	e9 7f fa ff ff       	jmp    e01e <fwp_main_thread+0xfe>
    e59f:	90                   	nop
    e5a0:	48 8d 3d 79 64 ff ff 	lea    -0x9b87(%rip),%rdi        # 4a20 <fwp_heap_report>
    e5a7:	e8 84 02 00 00       	call   e830 <atexit>
    e5ac:	e9 ad f9 ff ff       	jmp    df5e <fwp_main_thread+0x3e>
    e5b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    e5b8:	e8 73 65 ff ff       	call   4b30 <fwp_heap_init>
    e5bd:	e9 8e f9 ff ff       	jmp    df50 <fwp_main_thread+0x30>
    e5c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e5c8:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e5cc:	e9 01 fb ff ff       	jmp    e0d2 <fwp_main_thread+0x1b2>
    e5d1:	48 83 3d 7f 51 01 00 	cmpq   $0x0,0x1517f(%rip)        # 23758 <fwp_root>
    e5d8:	00 
    e5d9:	c7 05 bd 4a 01 00 00 	movl   $0x0,0x14abd(%rip)        # 230a0 <fwp_exit_code>
    e5e0:	00 00 00 
    e5e3:	0f 84 dd fd ff ff    	je     e3c6 <fwp_main_thread+0x4a6>
    e5e9:	e9 62 51 ff ff       	jmp    3750 <fwp_main_thread.cold>
    e5ee:	66 90                	xchg   %ax,%ax
    e5f0:	48 8d 3d f9 12 00 00 	lea    0x12f9(%rip),%rdi        # f8f0 <_IO_stdin_used+0x8f0>
    e5f7:	e8 a4 5b ff ff       	call   41a0 <fwp_trap>
    e5fc:	e8 5f 4e ff ff       	call   3460 <__stack_chk_fail@plt>
    e601:	48 89 c8             	mov    %rcx,%rax
    e604:	e9 00 fd ff ff       	jmp    e309 <fwp_main_thread+0x3e9>
    e609:	e9 42 51 ff ff       	jmp    3750 <fwp_main_thread.cold>
    e60e:	e9 3d 51 ff ff       	jmp    3750 <fwp_main_thread.cold>
    e613:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e61a:	00 00 00 
    e61d:	0f 1f 00             	nopl   (%rax)

000000000000e620 <__divmodti4>:
    e620:	f3 0f 1e fa          	endbr64
    e624:	55                   	push   %rbp
    e625:	49 89 f1             	mov    %rsi,%r9
    e628:	49 89 d2             	mov    %rdx,%r10
    e62b:	48 89 fe             	mov    %rdi,%rsi
    e62e:	49 89 cb             	mov    %rcx,%r11
    e631:	48 89 e5             	mov    %rsp,%rbp
    e634:	41 57                	push   %r15
    e636:	41 56                	push   %r14
    e638:	41 55                	push   %r13
    e63a:	41 54                	push   %r12
    e63c:	53                   	push   %rbx
    e63d:	4c 89 c3             	mov    %r8,%rbx
    e640:	45 31 c0             	xor    %r8d,%r8d
    e643:	4d 85 c9             	test   %r9,%r9
    e646:	79 12                	jns    e65a <__divmodti4+0x3a>
    e648:	31 ff                	xor    %edi,%edi
    e64a:	48 f7 de             	neg    %rsi
    e64d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    e654:	4c 19 cf             	sbb    %r9,%rdi
    e657:	49 89 f9             	mov    %rdi,%r9
    e65a:	4c 89 d8             	mov    %r11,%rax
    e65d:	4d 85 db             	test   %r11,%r11
    e660:	0f 88 1a 01 00 00    	js     e780 <__divmodti4+0x160>
    e666:	4c 89 d9             	mov    %r11,%rcx
    e669:	49 89 f3             	mov    %rsi,%r11
    e66c:	75 62                	jne    e6d0 <__divmodti4+0xb0>
    e66e:	4d 89 c4             	mov    %r8,%r12
    e671:	4d 39 d1             	cmp    %r10,%r9
    e674:	0f 83 46 01 00 00    	jae    e7c0 <__divmodti4+0x1a0>
    e67a:	4c 89 d8             	mov    %r11,%rax
    e67d:	4c 89 ca             	mov    %r9,%rdx
    e680:	49 f7 f2             	div    %r10
    e683:	49 89 c3             	mov    %rax,%r11
    e686:	31 c0                	xor    %eax,%eax
    e688:	48 89 d6             	mov    %rdx,%rsi
    e68b:	31 ff                	xor    %edi,%edi
    e68d:	4c 89 d9             	mov    %r11,%rcx
    e690:	48 89 c2             	mov    %rax,%rdx
    e693:	48 89 c8             	mov    %rcx,%rax
    e696:	4d 85 e4             	test   %r12,%r12
    e699:	74 0a                	je     e6a5 <__divmodti4+0x85>
    e69b:	48 f7 d8             	neg    %rax
    e69e:	48 83 d2 00          	adc    $0x0,%rdx
    e6a2:	48 f7 da             	neg    %rdx
    e6a5:	4d 85 c0             	test   %r8,%r8
    e6a8:	74 0a                	je     e6b4 <__divmodti4+0x94>
    e6aa:	48 f7 de             	neg    %rsi
    e6ad:	48 83 d7 00          	adc    $0x0,%rdi
    e6b1:	48 f7 df             	neg    %rdi
    e6b4:	48 89 33             	mov    %rsi,(%rbx)
    e6b7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    e6bb:	5b                   	pop    %rbx
    e6bc:	41 5c                	pop    %r12
    e6be:	41 5d                	pop    %r13
    e6c0:	41 5e                	pop    %r14
    e6c2:	41 5f                	pop    %r15
    e6c4:	5d                   	pop    %rbp
    e6c5:	c3                   	ret
    e6c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e6cd:	00 00 00 
    e6d0:	4d 89 c4             	mov    %r8,%r12
    e6d3:	49 39 c1             	cmp    %rax,%r9
    e6d6:	0f 82 ce 00 00 00    	jb     e7aa <__divmodti4+0x18a>
    e6dc:	31 ff                	xor    %edi,%edi
    e6de:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    e6e3:	48 63 c7             	movslq %edi,%rax
    e6e6:	be 40 00 00 00       	mov    $0x40,%esi
    e6eb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    e6f0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    e6f5:	48 29 c6             	sub    %rax,%rsi
    e6f8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    e6fd:	48 09 c8             	or     %rcx,%rax
    e700:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    e705:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    e70a:	49 89 c6             	mov    %rax,%r14
    e70d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    e711:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    e716:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    e71b:	49 09 c1             	or     %rax,%r9
    e71e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    e722:	4c 89 c8             	mov    %r9,%rax
    e725:	49 f7 f6             	div    %r14
    e728:	48 89 d1             	mov    %rdx,%rcx
    e72b:	49 89 c3             	mov    %rax,%r11
    e72e:	49 89 c1             	mov    %rax,%r9
    e731:	49 f7 e2             	mul    %r10
    e734:	49 89 c6             	mov    %rax,%r14
    e737:	49 89 d2             	mov    %rdx,%r10
    e73a:	48 39 d1             	cmp    %rdx,%rcx
    e73d:	72 07                	jb     e746 <__divmodti4+0x126>
    e73f:	75 17                	jne    e758 <__divmodti4+0x138>
    e741:	49 39 c7             	cmp    %rax,%r15
    e744:	73 12                	jae    e758 <__divmodti4+0x138>
    e746:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    e74a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    e74e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    e752:	49 89 d2             	mov    %rdx,%r10
    e755:	49 89 c6             	mov    %rax,%r14
    e758:	4c 89 f8             	mov    %r15,%rax
    e75b:	4c 29 f0             	sub    %r14,%rax
    e75e:	4c 19 d1             	sbb    %r10,%rcx
    e761:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    e766:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    e76b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    e770:	48 09 c6             	or     %rax,%rsi
    e773:	48 89 cf             	mov    %rcx,%rdi
    e776:	31 c0                	xor    %eax,%eax
    e778:	4c 89 c9             	mov    %r9,%rcx
    e77b:	e9 10 ff ff ff       	jmp    e690 <__divmodti4+0x70>
    e780:	4c 89 d0             	mov    %r10,%rax
    e783:	4c 89 da             	mov    %r11,%rdx
    e786:	4d 89 c4             	mov    %r8,%r12
    e789:	49 89 f3             	mov    %rsi,%r11
    e78c:	48 f7 d8             	neg    %rax
    e78f:	49 f7 d4             	not    %r12
    e792:	48 83 d2 00          	adc    $0x0,%rdx
    e796:	49 89 c2             	mov    %rax,%r10
    e799:	48 f7 da             	neg    %rdx
    e79c:	48 89 d1             	mov    %rdx,%rcx
    e79f:	0f 84 cc fe ff ff    	je     e671 <__divmodti4+0x51>
    e7a5:	49 39 d1             	cmp    %rdx,%r9
    e7a8:	73 46                	jae    e7f0 <__divmodti4+0x1d0>
    e7aa:	4c 89 cf             	mov    %r9,%rdi
    e7ad:	31 c0                	xor    %eax,%eax
    e7af:	31 c9                	xor    %ecx,%ecx
    e7b1:	e9 da fe ff ff       	jmp    e690 <__divmodti4+0x70>
    e7b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e7bd:	00 00 00 
    e7c0:	4d 85 d2             	test   %r10,%r10
    e7c3:	75 0d                	jne    e7d2 <__divmodti4+0x1b2>
    e7c5:	b8 01 00 00 00       	mov    $0x1,%eax
    e7ca:	31 d2                	xor    %edx,%edx
    e7cc:	49 f7 f2             	div    %r10
    e7cf:	49 89 c2             	mov    %rax,%r10
    e7d2:	4c 89 c8             	mov    %r9,%rax
    e7d5:	31 d2                	xor    %edx,%edx
    e7d7:	49 f7 f2             	div    %r10
    e7da:	49 89 c1             	mov    %rax,%r9
    e7dd:	4c 89 d8             	mov    %r11,%rax
    e7e0:	49 f7 f2             	div    %r10
    e7e3:	49 89 c3             	mov    %rax,%r11
    e7e6:	4c 89 c8             	mov    %r9,%rax
    e7e9:	e9 9a fe ff ff       	jmp    e688 <__divmodti4+0x68>
    e7ee:	66 90                	xchg   %ax,%ax
    e7f0:	45 31 f6             	xor    %r14d,%r14d
    e7f3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    e7f8:	44 89 f7             	mov    %r14d,%edi
    e7fb:	45 85 f6             	test   %r14d,%r14d
    e7fe:	0f 85 df fe ff ff    	jne    e6e3 <__divmodti4+0xc3>
    e804:	4c 39 ca             	cmp    %r9,%rdx
    e807:	72 17                	jb     e820 <__divmodti4+0x200>
    e809:	31 c9                	xor    %ecx,%ecx
    e80b:	48 39 c6             	cmp    %rax,%rsi
    e80e:	73 10                	jae    e820 <__divmodti4+0x200>
    e810:	4c 89 cf             	mov    %r9,%rdi
    e813:	31 c0                	xor    %eax,%eax
    e815:	e9 76 fe ff ff       	jmp    e690 <__divmodti4+0x70>
    e81a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e820:	4c 89 de             	mov    %r11,%rsi
    e823:	b9 01 00 00 00       	mov    $0x1,%ecx
    e828:	48 29 c6             	sub    %rax,%rsi
    e82b:	49 19 d1             	sbb    %rdx,%r9
    e82e:	eb e0                	jmp    e810 <__divmodti4+0x1f0>

000000000000e830 <atexit>:
    e830:	f3 0f 1e fa          	endbr64
    e834:	48 8b 15 cd 47 00 00 	mov    0x47cd(%rip),%rdx        # 13008 <__dso_handle>
    e83b:	31 f6                	xor    %esi,%esi
    e83d:	e9 1e 4e ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000e844 <_fini>:
    e844:	f3 0f 1e fa          	endbr64
    e848:	48 83 ec 08          	sub    $0x8,%rsp
    e84c:	48 83 c4 08          	add    $0x8,%rsp
    e850:	c3                   	ret
