
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 ff 00 00 	mov    0xffd1(%rip),%rax        # 12fe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 fd 00 00    	push   0xfdf2(%rip)        # 12e18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 fd 00 00    	jmp    *0xfdf4(%rip)        # 12e20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 fc 00 00    	jmp    *0xfc66(%rip)        # 12ff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e fa 00 00    	jmp    *0xfa8e(%rip)        # 12e28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 fa 00 00    	jmp    *0xfa86(%rip)        # 12e30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e fa 00 00    	jmp    *0xfa7e(%rip)        # 12e38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 fa 00 00    	jmp    *0xfa76(%rip)        # 12e40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e fa 00 00    	jmp    *0xfa6e(%rip)        # 12e48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12ea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12ea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12eb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12eb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12ec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12ec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12ed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12ed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12ee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12ee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12ef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12ef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12f00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12f08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12f10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12f18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12f20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12f28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12f30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12f38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12fa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12fa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12fb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12fb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12fc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12fc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 b9 00 00 	lea    0xb9b8(%rip),%r9        # f0cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 b9 00 00 	lea    0xb9b5(%rip),%r8        # f0d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <fwp_hof0.constprop.0.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>
    3750:	e8 ab ff ff ff       	call   3700 <fwp_trap_overflow.constprop.0>

0000000000003755 <fwp_main_thread.cold>:
    3755:	e8 66 fc ff ff       	call   33c0 <abort@plt>

000000000000375a <main.cold>:
    375a:	e8 61 fc ff ff       	call   33c0 <abort@plt>
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 db 00 00 	lea    0xdba1(%rip),%rax        # 11320 <fwp_fn_table>
    377f:	48 89 05 f2 9c 06 00 	mov    %rax,0x69cf2(%rip)        # 6d478 <fwp_fns>
    3786:	48 8b 05 93 f8 00 00 	mov    0xf893(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ec 9c 06 00 	mov    %rax,0x69cec(%rip)        # 6d480 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e bb 00 00 	lea    0xbb4e(%rip),%rdi        # f2ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 f8 00 00 	mov    0xf818(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 3f a5 00 00 	lea    0xa53f(%rip),%rdx        # dda0 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 e0 fe ff ff    	jne    375a <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 c4 fe ff ff    	jne    375a <main.cold>
    3896:	48 8b 3d 83 f7 00 00 	mov    0xf783(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 d8 f7 01 00    	mov    0x1f7d8(%rip),%eax        # 23080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe b9 00 00 	lea    0xb9fe(%rip),%rdi        # f2f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 56 c3 00 00 	lea    0xc356(%rip),%rdi        # fc60 <_IO_stdin_used+0xc60>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 39 fe ff ff    	jne    375a <main.cold>
    3921:	48 8d 3d 10 c3 00 00 	lea    0xc310(%rip),%rdi        # fc38 <_IO_stdin_used+0xc38>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d d4 c2 00 00 	lea    0xc2d4(%rip),%rdi        # fc08 <_IO_stdin_used+0xc08>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d a0 c2 00 00 	lea    0xc2a0(%rip),%rdi        # fbe0 <_IO_stdin_used+0xbe0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b f6 00 00    	call   *0xf65b(%rip)        # 12fd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 f6 00 00 	lea    0xf699(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 f6 00 00 	lea    0xf692(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e f6 00 00 	mov    0xf63e(%rip),%rax        # 12fd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 f6 00 00 	lea    0xf669(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 f6 00 00 	lea    0xf662(%rip),%rsi        # 13020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d f6 00 00 	mov    0xf60d(%rip),%rax        # 12fe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d f6 00 00 00 	cmpb   $0x0,0xf64d(%rip)        # 13048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea f5 00 00 	cmpq   $0x0,0xf5ea(%rip)        # 12ff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 f6 00 00 01 	movb   $0x1,0xf625(%rip)        # 13048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 97 f5 04 00 	lea    0x4f597(%rip),%r8        # 531a0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 3b f5 04 00 	lea    0x4f53b(%rip),%rcx        # 53160 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 0f f5 04 00 	lea    0x4f50f(%rip),%rcx        # 53140 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 41 f5 04 00 	lea    0x4f541(%rip),%rcx        # 53180 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 50 f5 04 	movdqa 0x4f550(%rip),%xmm0        # 531b0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 38 f5 04 	paddq  0x4f538(%rip),%xmm0        # 531a0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 9f f4 04 00 	cmp    %rax,0x4f49f(%rip)        # 53120 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 95 f4 04 	movq   %xmm0,0x4f495(%rip)        # 53120 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 3e f4 01 00 	add    0x1f43e(%rip),%rdx        # 230f0 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 2c f4 01 00 	add    0x1f42c(%rip),%rax        # 230f0 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args173>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 79 97 06 00 	mov    0x69779(%rip),%rdi        # 6d480 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 04 f3 00 00 	mov    0xf304(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d f1 f2 00 00 	mov    0xf2f1(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 b1 7a 06 00 	mov    0x67ab1(%rip),%rax        # 6b800 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 f9 73 06 00 	mov    0x673f9(%rip),%rax        # 6b1c8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 e5 73 06 00 	sub    0x673e5(%rip),%rax        # 6b1c0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 2d bf 00 00 	lea    0xbf2d(%rip),%rsi        # fd40 <msg.4>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 b1 00 00 	lea    0xb1c5(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d f2 f1 00 00 	mov    0xf1f2(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 8b 8d 06 00 	mov    0x68d8b(%rip),%rax        # 6cc10 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 84 8d 06 00 	lea    0x68d84(%rip),%r8        # 6cc10 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 65 8d 06 00 	mov    0x68d65(%rip),%rbx        # 6cbf8 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 75 8d 06 00 	mov    0x68d75(%rip),%rcx        # 6cc18 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 11 8d 06 00 	mov    0x68d11(%rip),%rdi        # 6cc00 <fwp_heap+0x13e0>
    3eef:	48 29 35 5a 8d 06 00 	sub    %rsi,0x68d5a(%rip)        # 6cc50 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 ea 8c 06 00 	mov    0x68cea(%rip),%rax        # 6cbf0 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d a0 8c 06 00 	add    0x68ca0(%rip),%rdi        # 6cbd0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ae 8c 06 00 	mov    0x68cae(%rip),%rsi        # 6cc00 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 bc 8c 06 00 	mov    0x68cbc(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 6b 8c 06 00 	mov    %r12,0x68c6b(%rip)        # 6cc00 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 59 8c 06 00 	mov    %rbp,0x68c59(%rip)        # 6cbf8 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 3e 8c 06 00 	cmp    %rdi,0x68c3e(%rip)        # 6cbe8 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 35 8c 06 00 	mov    %rdi,0x68c35(%rip)        # 6cbe8 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 79 8c 06 00 	sub    %rdi,0x68c79(%rip)        # 6cc50 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 21 8c 06 00 	mov    0x68c21(%rip),%rax        # 6cc08 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 1a 8c 06 00 	lea    0x68c1a(%rip),%r8        # 6cc08 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ff b6 00 00 	lea    0xb6ff(%rip),%rdx        # f708 <_IO_stdin_used+0x708>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 22 f0 00 00 	mov    0xf022(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 7d ef 00 00 	mov    0xef7d(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 af 00 00 	lea    0xaf34(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d c9 76 06 00 	cmp    0x676c9(%rip),%rdi        # 6b800 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 8f 76 06 00 	mov    0x6768f(%rip),%rax        # 6b7e0 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 6d 76 06 00 	mov    %rdi,0x6766d(%rip)        # 6b7e0 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 49 76 06 00 	mov    %rdi,0x67649(%rip)        # 6b7e8 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 19 b0 00 00 	lea    0xb019(%rip),%rsi        # f1fa <_IO_stdin_used+0x1fa>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 ae 00 00 	lea    0xae27(%rip),%rsi        # f01c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 76 ef 04 	movdqa 0x4ef76(%rip),%xmm0        # 531b0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 5e ef 04 	paddq  0x4ef5e(%rip),%xmm0        # 531a0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 84 ee 01 00 	mov    0x1ee84(%rip),%r8        # 230f8 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d 9e ee 04 00 	mov    0x4ee9e(%rip),%rcx        # 53120 <ad_raw_total_peak>
    4282:	48 8b 3d b7 ed 00 00 	mov    0xedb7(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 c5 b4 00 00 	lea    0xb4c5(%rip),%rdx        # f758 <_IO_stdin_used+0x758>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d e1 ee 04 00 	lea    0x4eee1(%rip),%r15        # 53180 <ad_raw_peak>
    429f:	4c 8d 35 9a ee 04 00 	lea    0x4ee9a(%rip),%r14        # 53140 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 ad 00 00 	lea    0xad79(%rip),%rax        # f02b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 e9 00 	movq   0xe956(%rip),%xmm0        # 12c10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d 9f ee 04 00 	lea    0x4ee9f(%rip),%r13        # 53160 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f ad 00 00 	lea    0xad6f(%rip),%rax        # f03c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 e9 00 	movq   0xe936(%rip),%xmm0        # 12c18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 33 ed 00 00 	mov    0xed33(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c ad 00 00 	lea    0xad0c(%rip),%rcx        # f020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 9d b4 00 00 	lea    0xb49d(%rip),%rdx        # f7b8 <_IO_stdin_used+0x7b8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 04 ed 00 00 	mov    0xed04(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 ac 00 00 	lea    0xacf8(%rip),%rdi        # f045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d a6 ed 01 00 	cmpq   $0x0,0x1eda6(%rip)        # 23100 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 bd ed 01 00 	mov    0x1edbd(%rip),%r8        # 23120 <ad_raw_checkpoints>
    4363:	4c 8b 0d be ed 01 00 	mov    0x1edbe(%rip),%r9        # 23128 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d af ed 01 00 	lea    0x1edaf(%rip),%rbx        # 23120 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 ac 00 00 	lea    0xacf4(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 b1 ed 01 00 	mov    0x1edb1(%rip),%rax        # 23130 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a ac 00 00 	lea    0xac9a(%rip),%r12        # f020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d 89 ec 00 00 	mov    0xec89(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 39 b4 00 00 	lea    0xb439(%rip),%rdx        # f7f8 <_IO_stdin_used+0x7f8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 33 ed 01 00 	cmp    0x1ed33(%rip),%rbp        # 23100 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 58 ec 00 00 	mov    0xec58(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b ac 00 00 	lea    0xac5b(%rip),%rdi        # f059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 23 ec 00 00 	mov    0xec23(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 94 b3 00 00 	lea    0xb394(%rip),%rdx        # f7b8 <_IO_stdin_used+0x7b8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 ac 00 00 	lea    0xac40(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d ea b2 00 00 	lea    0xb2ea(%rip),%rdi        # f730 <_IO_stdin_used+0x730>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d c8 eb 00 00 	mov    0xebc8(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df ab 00 00 	lea    0xabdf(%rip),%rdx        # f05e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d b0 eb 00 00 	mov    0xebb0(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d c1 ea 00 00 	mov    0xeac1(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 aa 00 00 	lea    0xaa78(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 aa 00 00 	lea    0xaac0(%rip),%rdi        # f06d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 aa 00 00 	lea    0xaa48(%rip),%rdi        # f087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d e8 b1 00 00 	lea    0xb1e8(%rip),%rdi        # f838 <_IO_stdin_used+0x838>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 20 b7 00 	movdqa 0xb720(%rip),%xmm0        # fd90 <msg.4+0x50>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 aa 8d 06 00 	add    0x68daa(%rip),%rax        # 6d478 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 3c b1 00 00 	lea    0xb13c(%rip),%rdi        # f860 <_IO_stdin_used+0x860>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 a5 e9 01 00 	cmp    %rax,0x1e9a5(%rip)        # 230e8 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 a0 e9 01 00 	add    0x1e9a0(%rip),%rax        # 230f0 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 25 b1 00 00 	lea    0xb125(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 a9 00 00 	lea    0xa920(%rip),%r8        # f0a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 a7 00 00 	lea    0xa775(%rip),%r8        # f0b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 a6 00 00 	lea    0xa612(%rip),%r8        # f0a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea a3 00 00 	lea    0xa3ea(%rip),%rdi        # f0b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 54 a5 00 00 	lea    0xa554(%rip),%rsi        # f242 <_IO_stdin_used+0x242>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d 85 7e 06 00 	mov    0x67e85(%rip),%r9        # 6cbe8 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 de 7e 06 00 	mov    0x67ede(%rip),%r8        # 6cc48 <fwp_heap+0x1428>
    4d6a:	48 8d 15 6f ab 00 00 	lea    0xab6f(%rip),%rdx        # f8e0 <_IO_stdin_used+0x8e0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d c6 7e 06 00 	mov    0x67ec6(%rip),%rcx        # 6cc40 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d d4 7e 06 	movsd  0x67ed4(%rip),%xmm1        # 6cc60 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 c4 7e 06 	movsd  0x67ec4(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d a5 e2 00 00 	mov    0xe2a5(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 c8 af 00 	movdqa 0xafc8(%rip),%xmm0        # fda0 <msg.4+0x60>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 7f 79 06 00 	lea    0x6797f(%rip),%rax        # 6c760 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 f1 af 00 	movdqa 0xaff1(%rip),%xmm2        # fde0 <msg.4+0xa0>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 25 79 06 00 	movaps %xmm0,0x67925(%rip)        # 6c720 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 ad af 00 	movdqa 0xafad(%rip),%xmm0        # fdb0 <msg.4+0x70>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 b3 7d 06 00 01 	movl   $0x1,0x67db3(%rip)        # 6cbc4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 13 79 06 00 	movaps %xmm0,0x67913(%rip)        # 6c730 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 9b af 00 	movdqa 0xaf9b(%rip),%xmm0        # fdc0 <msg.4+0x80>
    4e24:	00 
    4e25:	0f 29 05 14 79 06 00 	movaps %xmm0,0x67914(%rip)        # 6c740 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 9c af 00 	movdqa 0xaf9c(%rip),%xmm0        # fdd0 <msg.4+0x90>
    4e33:	00 
    4e34:	0f 29 05 15 79 06 00 	movaps %xmm0,0x67915(%rip)        # 6c750 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 95 69 06 00 	lea    0x66995(%rip),%r8        # 6b820 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 b0 7c 06 00 	mov    %rax,0x67cb0(%rip)        # 6cbd8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 8e 7c 06 00 	mov    %r12,0x67c8e(%rip)        # 6cbe0 <fwp_heap+0x13c0>
    4f52:	48 89 05 77 7c 06 00 	mov    %rax,0x67c77(%rip)        # 6cbd0 <fwp_heap+0x13b0>
    4f59:	48 89 1d 90 7c 06 00 	mov    %rbx,0x67c90(%rip)        # 6cbf0 <fwp_heap+0x13d0>
    4f60:	48 89 35 b9 7c 06 00 	mov    %rsi,0x67cb9(%rip)        # 6cc20 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 a1 00 00 	lea    0xa174(%rip),%rdi        # f0ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 98 7c 06 00 	mov    %rax,0x67c98(%rip)        # 6cc18 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 1c 7c 06 00    	mov    %eax,0x67c1c(%rip)        # 6cbc8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 0c 68 06 00 	mov    0x6680c(%rip),%r8        # 6b7e0 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d 3c 67 06 00 	mov    %rbx,0x6673c(%rip)        # 6b7e8 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 28 67 06 00 	mov    %r8,0x66728(%rip)        # 6b7e0 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <ad_raw_free.part.0>:
    50d0:	48 8d 0d e9 e0 04 00 	lea    0x4e0e9(%rip),%rcx        # 531c0 <ad_raw_blocks>
    50d7:	31 c0                	xor    %eax,%eax
    50d9:	48 89 ca             	mov    %rcx,%rdx
    50dc:	eb 12                	jmp    50f0 <ad_raw_free.part.0+0x20>
    50de:	66 90                	xchg   %ax,%ax
    50e0:	48 83 c0 01          	add    $0x1,%rax
    50e4:	48 83 c2 18          	add    $0x18,%rdx
    50e8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ee:	74 40                	je     5130 <ad_raw_free.part.0+0x60>
    50f0:	48 3b 3a             	cmp    (%rdx),%rdi
    50f3:	75 eb                	jne    50e0 <ad_raw_free.part.0+0x10>
    50f5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50f9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5101:	48 8d 0d 98 e0 04 00 	lea    0x4e098(%rip),%rcx        # 531a0 <ad_raw_live>
    5108:	8b 70 10             	mov    0x10(%rax),%esi
    510b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5112:	00 
    5113:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5117:	48 2b 50 08          	sub    0x8(%rax),%rdx
    511b:	0f 11 00             	movups %xmm0,(%rax)
    511e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5122:	e9 89 e2 ff ff       	jmp    33b0 <free@plt>
    5127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    512e:	00 00 
    5130:	48 83 ec 08          	sub    $0x8,%rsp
    5134:	48 8d 3d c2 9f 00 00 	lea    0x9fc2(%rip),%rdi        # f0fd <_IO_stdin_used+0xfd>
    513b:	e8 c0 ee ff ff       	call   4000 <ad_raw_fail>

0000000000005140 <fwp_tape_buffers_dispose>:
    5140:	53                   	push   %rbx
    5141:	48 89 fb             	mov    %rdi,%rbx
    5144:	48 8b 3f             	mov    (%rdi),%rdi
    5147:	48 85 ff             	test   %rdi,%rdi
    514a:	74 05                	je     5151 <fwp_tape_buffers_dispose+0x11>
    514c:	e8 7f ff ff ff       	call   50d0 <ad_raw_free.part.0>
    5151:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5155:	48 85 ff             	test   %rdi,%rdi
    5158:	74 05                	je     515f <fwp_tape_buffers_dispose+0x1f>
    515a:	e8 71 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    515f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5163:	48 85 ff             	test   %rdi,%rdi
    5166:	74 05                	je     516d <fwp_tape_buffers_dispose+0x2d>
    5168:	e8 63 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    516d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5171:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5178:	00 
    5179:	0f 11 03             	movups %xmm0,(%rbx)
    517c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5180:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5184:	5b                   	pop    %rbx
    5185:	c3                   	ret
    5186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    518d:	00 00 00 

0000000000005190 <ad_raw_realloc>:
    5190:	41 55                	push   %r13
    5192:	41 54                	push   %r12
    5194:	55                   	push   %rbp
    5195:	53                   	push   %rbx
    5196:	48 83 ec 08          	sub    $0x8,%rsp
    519a:	48 85 f6             	test   %rsi,%rsi
    519d:	0f 84 a6 00 00 00    	je     5249 <ad_raw_realloc+0xb9>
    51a3:	4c 8d 25 16 e0 04 00 	lea    0x4e016(%rip),%r12        # 531c0 <ad_raw_blocks>
    51aa:	48 89 f5             	mov    %rsi,%rbp
    51ad:	41 89 d5             	mov    %edx,%r13d
    51b0:	31 db                	xor    %ebx,%ebx
    51b2:	4c 89 e0             	mov    %r12,%rax
    51b5:	eb 1a                	jmp    51d1 <ad_raw_realloc+0x41>
    51b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51be:	00 00 
    51c0:	48 83 c3 01          	add    $0x1,%rbx
    51c4:	48 83 c0 18          	add    $0x18,%rax
    51c8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51cf:	74 4f                	je     5220 <ad_raw_realloc+0x90>
    51d1:	48 3b 38             	cmp    (%rax),%rdi
    51d4:	75 ea                	jne    51c0 <ad_raw_realloc+0x30>
    51d6:	48 85 ff             	test   %rdi,%rdi
    51d9:	74 0b                	je     51e6 <ad_raw_realloc+0x56>
    51db:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51df:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51e4:	75 57                	jne    523d <ad_raw_realloc+0xad>
    51e6:	48 89 ee             	mov    %rbp,%rsi
    51e9:	e8 c2 e3 ff ff       	call   35b0 <realloc@plt>
    51ee:	49 89 c2             	mov    %rax,%r10
    51f1:	48 85 c0             	test   %rax,%rax
    51f4:	74 16                	je     520c <ad_raw_realloc+0x7c>
    51f6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51fa:	44 89 e9             	mov    %r13d,%ecx
    51fd:	48 89 ea             	mov    %rbp,%rdx
    5200:	4c 89 d6             	mov    %r10,%rsi
    5203:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5207:	e8 f4 e9 ff ff       	call   3c00 <ad_raw_record>
    520c:	48 83 c4 08          	add    $0x8,%rsp
    5210:	4c 89 d0             	mov    %r10,%rax
    5213:	5b                   	pop    %rbx
    5214:	5d                   	pop    %rbp
    5215:	41 5c                	pop    %r12
    5217:	41 5d                	pop    %r13
    5219:	c3                   	ret
    521a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5220:	48 85 ff             	test   %rdi,%rdi
    5223:	48 8d 05 e8 9e 00 00 	lea    0x9ee8(%rip),%rax        # f112 <_IO_stdin_used+0x112>
    522a:	48 8d 15 cc 9e 00 00 	lea    0x9ecc(%rip),%rdx        # f0fd <_IO_stdin_used+0xfd>
    5231:	48 0f 45 c2          	cmovne %rdx,%rax
    5235:	48 89 c7             	mov    %rax,%rdi
    5238:	e8 c3 ed ff ff       	call   4000 <ad_raw_fail>
    523d:	48 8d 3d 04 9f 00 00 	lea    0x9f04(%rip),%rdi        # f148 <_IO_stdin_used+0x148>
    5244:	e8 b7 ed ff ff       	call   4000 <ad_raw_fail>
    5249:	48 8d 3d dd 9e 00 00 	lea    0x9edd(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    5250:	e8 ab ed ff ff       	call   4000 <ad_raw_fail>
    5255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    525c:	00 00 00 00 

0000000000005260 <fwp_tape_buffers_release>:
    5260:	f3 0f 1e fa          	endbr64
    5264:	53                   	push   %rbx
    5265:	48 89 fb             	mov    %rdi,%rbx
    5268:	48 83 ec 10          	sub    $0x10,%rsp
    526c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5270:	48 85 c0             	test   %rax,%rax
    5273:	0f 88 d7 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5279:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    527d:	48 85 d2             	test   %rdx,%rdx
    5280:	0f 88 ca 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5286:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    528c:	0f 87 be 00 00 00    	ja     5350 <fwp_tape_buffers_release+0xf0>
    5292:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5296:	b8 00 00 08 00       	mov    $0x80000,%eax
    529b:	48 c1 e1 03          	shl    $0x3,%rcx
    529f:	48 29 c8             	sub    %rcx,%rax
    52a2:	48 c1 e8 03          	shr    $0x3,%rax
    52a6:	48 39 d0             	cmp    %rdx,%rax
    52a9:	0f 82 a1 00 00 00    	jb     5350 <fwp_tape_buffers_release+0xf0>
    52af:	48 8d 3d aa 9e 00 00 	lea    0x9eaa(%rip),%rdi        # f160 <_IO_stdin_used+0x160>
    52b6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52bb:	48 89 14 24          	mov    %rdx,(%rsp)
    52bf:	e8 cc e0 ff ff       	call   3390 <getenv@plt>
    52c4:	48 8b 14 24          	mov    (%rsp),%rdx
    52c8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 09                	je     52db <fwp_tape_buffers_release+0x7b>
    52d2:	80 38 30             	cmpb   $0x30,(%rax)
    52d5:	0f 84 05 01 00 00    	je     53e0 <fwp_tape_buffers_release+0x180>
    52db:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52df:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52e3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52e9:	77 71                	ja     535c <fwp_tape_buffers_release+0xfc>
    52eb:	48 8d 3d ae dd 01 00 	lea    0x1ddae(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    52f2:	48 89 34 24          	mov    %rsi,(%rsp)
    52f6:	e8 45 fe ff ff       	call   5140 <fwp_tape_buffers_dispose>
    52fb:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52ff:	48 8b 34 24          	mov    (%rsp),%rsi
    5303:	0f 29 05 96 dd 01 00 	movaps %xmm0,0x1dd96(%rip)        # 230a0 <fwp_tape_workspace>
    530a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    530f:	48 89 35 72 dd 01 00 	mov    %rsi,0x1dd72(%rip)        # 23088 <fwp_tape_cached_bytes>
    5316:	0f 29 05 93 dd 01 00 	movaps %xmm0,0x1dd93(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    531d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5322:	0f 29 05 97 dd 01 00 	movaps %xmm0,0x1dd97(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    5329:	48 8b 43 30          	mov    0x30(%rbx),%rax
    532d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5331:	48 89 05 98 dd 01 00 	mov    %rax,0x1dd98(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    5338:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    533f:	00 
    5340:	0f 11 03             	movups %xmm0,(%rbx)
    5343:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5347:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    534b:	eb 1e                	jmp    536b <fwp_tape_buffers_release+0x10b>
    534d:	0f 1f 00             	nopl   (%rax)
    5350:	48 8d 3d 09 9e 00 00 	lea    0x9e09(%rip),%rdi        # f160 <_IO_stdin_used+0x160>
    5357:	e8 34 e0 ff ff       	call   3390 <getenv@plt>
    535c:	48 89 df             	mov    %rbx,%rdi
    535f:	e8 dc fd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    5364:	48 8b 35 1d dd 01 00 	mov    0x1dd1d(%rip),%rsi        # 23088 <fwp_tape_cached_bytes>
    536b:	48 6b 15 6d dd 01 00 	imul   $0x68,0x1dd6d(%rip),%rdx        # 230e0 <fwp_tapes_cap>
    5372:	68 
    5373:	48 3b 15 26 de 04 00 	cmp    0x4de26(%rip),%rdx        # 531a0 <ad_raw_live>
    537a:	75 73                	jne    53ef <fwp_tape_buffers_release+0x18f>
    537c:	48 8b 05 25 de 04 00 	mov    0x4de25(%rip),%rax        # 531a8 <ad_raw_live+0x8>
    5383:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5387:	48 01 d0             	add    %rdx,%rax
    538a:	48 03 05 1f de 04 00 	add    0x4de1f(%rip),%rax        # 531b0 <ad_raw_live+0x10>
    5391:	48 03 05 20 de 04 00 	add    0x4de20(%rip),%rax        # 531b8 <ad_raw_live+0x18>
    5398:	48 39 c8             	cmp    %rcx,%rax
    539b:	72 52                	jb     53ef <fwp_tape_buffers_release+0x18f>
    539d:	48 8b 0d 5c dd 01 00 	mov    0x1dd5c(%rip),%rcx        # 23100 <ad_raw_checkpoint_count>
    53a4:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    53ab:	74 4e                	je     53fb <fwp_tape_buffers_release+0x19b>
    53ad:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    53b1:	48 29 d0             	sub    %rdx,%rax
    53b4:	48 89 3d 45 dd 01 00 	mov    %rdi,0x1dd45(%rip)        # 23100 <ad_raw_checkpoint_count>
    53bb:	48 29 f0             	sub    %rsi,%rax
    53be:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53c2:	48 8d 0d 57 dd 01 00 	lea    0x1dd57(%rip),%rcx        # 23120 <ad_raw_checkpoints>
    53c9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53cd:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53d2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53d7:	48 83 c4 10          	add    $0x10,%rsp
    53db:	5b                   	pop    %rbx
    53dc:	c3                   	ret
    53dd:	0f 1f 00             	nopl   (%rax)
    53e0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53e4:	0f 84 72 ff ff ff    	je     535c <fwp_tape_buffers_release+0xfc>
    53ea:	e9 ec fe ff ff       	jmp    52db <fwp_tape_buffers_release+0x7b>
    53ef:	48 8d 3d 72 a5 00 00 	lea    0xa572(%rip),%rdi        # f968 <_IO_stdin_used+0x968>
    53f6:	e8 05 ec ff ff       	call   4000 <ad_raw_fail>
    53fb:	48 8d 3d 6f 9d 00 00 	lea    0x9d6f(%rip),%rdi        # f171 <_IO_stdin_used+0x171>
    5402:	e8 f9 eb ff ff       	call   4000 <ad_raw_fail>
    5407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    540e:	00 00 

0000000000005410 <fwp_poll_events>:
    5410:	53                   	push   %rbx
    5411:	48 83 ec 20          	sub    $0x20,%rsp
    5415:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    541c:	00 00 
    541e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5423:	31 c0                	xor    %eax,%eax
    5425:	e8 96 f1 ff ff       	call   45c0 <fwp_now_ns>
    542a:	48 8b 1d a7 63 06 00 	mov    0x663a7(%rip),%rbx        # 6b7d8 <fwp_timers>
    5431:	48 85 db             	test   %rbx,%rbx
    5434:	0f 84 e6 00 00 00    	je     5520 <fwp_poll_events+0x110>
    543a:	48 89 c6             	mov    %rax,%rsi
    543d:	48 89 da             	mov    %rbx,%rdx
    5440:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5447:	eb 26                	jmp    546f <fwp_poll_events+0x5f>
    5449:	90                   	nop
    544a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5451:	00 00 00 00 
    5455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    545c:	00 00 00 00 
    5460:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5467:	48 89 c8             	mov    %rcx,%rax
    546a:	48 85 d2             	test   %rdx,%rdx
    546d:	74 31                	je     54a0 <fwp_poll_events+0x90>
    546f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5473:	48 85 c0             	test   %rax,%rax
    5476:	78 e8                	js     5460 <fwp_poll_events+0x50>
    5478:	48 39 c1             	cmp    %rax,%rcx
    547b:	7c e3                	jl     5460 <fwp_poll_events+0x50>
    547d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 1c                	je     54a5 <fwp_poll_events+0x95>
    5489:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    548d:	48 39 c1             	cmp    %rax,%rcx
    5490:	7c ce                	jl     5460 <fwp_poll_events+0x50>
    5492:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5499:	48 85 d2             	test   %rdx,%rdx
    549c:	75 d1                	jne    546f <fwp_poll_events+0x5f>
    549e:	66 90                	xchg   %ax,%ax
    54a0:	48 85 c0             	test   %rax,%rax
    54a3:	78 7b                	js     5520 <fwp_poll_events+0x110>
    54a5:	48 29 f0             	sub    %rsi,%rax
    54a8:	48 89 c1             	mov    %rax,%rcx
    54ab:	48 85 c0             	test   %rax,%rax
    54ae:	0f 8e 9c 00 00 00    	jle    5550 <fwp_poll_events+0x140>
    54b4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    54bb:	de 1b 43 
    54be:	48 f7 ea             	imul   %rdx
    54c1:	48 89 c8             	mov    %rcx,%rax
    54c4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54c8:	48 c1 fa 12          	sar    $0x12,%rdx
    54cc:	48 29 c2             	sub    %rax,%rdx
    54cf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54d6:	48 39 c1             	cmp    %rax,%rcx
    54d9:	0f 95 c0             	setne  %al
    54dc:	0f b6 c0             	movzbl %al,%eax
    54df:	48 01 d0             	add    %rdx,%rax
    54e2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54e8:	0f 8f 32 01 00 00    	jg     5620 <fwp_poll_events+0x210>
    54ee:	48 85 c0             	test   %rax,%rax
    54f1:	74 5d                	je     5550 <fwp_poll_events+0x140>
    54f3:	89 c1                	mov    %eax,%ecx
    54f5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54fc:	48 c1 e9 26          	shr    $0x26,%rcx
    5500:	48 63 d1             	movslq %ecx,%rdx
    5503:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5509:	29 c8                	sub    %ecx,%eax
    550b:	48 98                	cltq
    550d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5514:	e9 11 01 00 00       	jmp    562a <fwp_poll_events+0x21a>
    5519:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5520:	e8 db e7 ff ff       	call   3d00 <fwp_flush>
    5525:	ba 2b 00 00 00       	mov    $0x2b,%edx
    552a:	be 01 00 00 00       	mov    $0x1,%esi
    552f:	48 8b 0d 0a db 00 00 	mov    0xdb0a(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    5536:	48 8d 3d 5b a4 00 00 	lea    0xa45b(%rip),%rdi        # f998 <_IO_stdin_used+0x998>
    553d:	e8 1e e1 ff ff       	call   3660 <fwrite@plt>
    5542:	bf 65 00 00 00       	mov    $0x65,%edi
    5547:	e8 04 e1 ff ff       	call   3650 <exit@plt>
    554c:	0f 1f 40 00          	nopl   0x0(%rax)
    5550:	e8 6b f0 ff ff       	call   45c0 <fwp_now_ns>
    5555:	48 89 c1             	mov    %rax,%rcx
    5558:	66 0f ef c0          	pxor   %xmm0,%xmm0
    555c:	eb 44                	jmp    55a2 <fwp_poll_events+0x192>
    555e:	66 90                	xchg   %ax,%ax
    5560:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5564:	75 33                	jne    5599 <fwp_poll_events+0x189>
    5566:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    556a:	75 2d                	jne    5599 <fwp_poll_events+0x189>
    556c:	48 8b 05 6d 62 06 00 	mov    0x6626d(%rip),%rax        # 6b7e0 <fwp_ready_tail>
    5573:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5577:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    557e:	00 00 00 00 
    5582:	48 85 c0             	test   %rax,%rax
    5585:	0f 84 05 01 00 00    	je     5690 <fwp_poll_events+0x280>
    558b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5592:	48 89 15 47 62 06 00 	mov    %rdx,0x66247(%rip)        # 6b7e0 <fwp_ready_tail>
    5599:	48 85 db             	test   %rbx,%rbx
    559c:	0f 84 be 00 00 00    	je     5660 <fwp_poll_events+0x250>
    55a2:	48 89 da             	mov    %rbx,%rdx
    55a5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    55ac:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    55b0:	7f e7                	jg     5599 <fwp_poll_events+0x189>
    55b2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    55b6:	74 2e                	je     55e6 <fwp_poll_events+0x1d6>
    55b8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    55bf:	48 85 c0             	test   %rax,%rax
    55c2:	0f 84 b8 00 00 00    	je     5680 <fwp_poll_events+0x270>
    55c8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55cf:	48 85 db             	test   %rbx,%rbx
    55d2:	74 07                	je     55db <fwp_poll_events+0x1cb>
    55d4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55db:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55df:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55e6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ea:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ee:	48 85 c0             	test   %rax,%rax
    55f1:	0f 84 69 ff ff ff    	je     5560 <fwp_poll_events+0x150>
    55f7:	48 39 c8             	cmp    %rcx,%rax
    55fa:	0f 8f 60 ff ff ff    	jg     5560 <fwp_poll_events+0x150>
    5600:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5604:	0f 85 56 ff ff ff    	jne    5560 <fwp_poll_events+0x150>
    560a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    560e:	75 89                	jne    5599 <fwp_poll_events+0x189>
    5610:	48 89 d7             	mov    %rdx,%rdi
    5613:	e8 18 eb ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5618:	e9 43 ff ff ff       	jmp    5560 <fwp_poll_events+0x150>
    561d:	0f 1f 00             	nopl   (%rax)
    5620:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5625:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    562a:	48 89 e7             	mov    %rsp,%rdi
    562d:	31 f6                	xor    %esi,%esi
    562f:	48 89 14 24          	mov    %rdx,(%rsp)
    5633:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5638:	e8 53 de ff ff       	call   3490 <nanosleep@plt>
    563d:	48 8b 1d 94 61 06 00 	mov    0x66194(%rip),%rbx        # 6b7d8 <fwp_timers>
    5644:	e8 77 ef ff ff       	call   45c0 <fwp_now_ns>
    5649:	48 89 c1             	mov    %rax,%rcx
    564c:	48 85 db             	test   %rbx,%rbx
    564f:	0f 85 03 ff ff ff    	jne    5558 <fwp_poll_events+0x148>
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5665:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    566c:	00 00 
    566e:	75 2c                	jne    569c <fwp_poll_events+0x28c>
    5670:	48 83 c4 20          	add    $0x20,%rsp
    5674:	5b                   	pop    %rbx
    5675:	c3                   	ret
    5676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    567d:	00 00 00 
    5680:	48 89 1d 51 61 06 00 	mov    %rbx,0x66151(%rip)        # 6b7d8 <fwp_timers>
    5687:	e9 43 ff ff ff       	jmp    55cf <fwp_poll_events+0x1bf>
    568c:	0f 1f 40 00          	nopl   0x0(%rax)
    5690:	48 89 15 51 61 06 00 	mov    %rdx,0x66151(%rip)        # 6b7e8 <fwp_ready_head>
    5697:	e9 f6 fe ff ff       	jmp    5592 <fwp_poll_events+0x182>
    569c:	e8 af dd ff ff       	call   3450 <__stack_chk_fail@plt>
    56a1:	0f 1f 40 00          	nopl   0x0(%rax)
    56a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ac:	00 00 00 00 

00000000000056b0 <fwp_rc_wide_dup>:
    56b0:	48 89 fa             	mov    %rdi,%rdx
    56b3:	48 8d 35 66 61 06 00 	lea    0x66166(%rip),%rsi        # 6b820 <fwp_heap>
    56ba:	48 83 ec 18          	sub    $0x18,%rsp
    56be:	48 89 f9             	mov    %rdi,%rcx
    56c1:	48 c1 ea 11          	shr    $0x11,%rdx
    56c5:	48 31 fa             	xor    %rdi,%rdx
    56c8:	48 89 d0             	mov    %rdx,%rax
    56cb:	48 c1 e8 09          	shr    $0x9,%rax
    56cf:	48 31 c2             	xor    %rax,%rdx
    56d2:	0f b6 d2             	movzbl %dl,%edx
    56d5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56dc:	00 
    56dd:	49 8b 00             	mov    (%r8),%rax
    56e0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56e7:	00 00 
    56e9:	75 21                	jne    570c <fwp_rc_wide_dup+0x5c>
    56eb:	e9 98 00 00 00       	jmp    5788 <fwp_rc_wide_dup+0xd8>
    56f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56fc:	00 00 00 00 
    5700:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5704:	48 85 d2             	test   %rdx,%rdx
    5707:	74 2f                	je     5738 <fwp_rc_wide_dup+0x88>
    5709:	48 89 d0             	mov    %rdx,%rax
    570c:	48 3b 08             	cmp    (%rax),%rcx
    570f:	75 ef                	jne    5700 <fwp_rc_wide_dup+0x50>
    5711:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5714:	74 7c                	je     5792 <fwp_rc_wide_dup+0xe2>
    5716:	48 8b 50 08          	mov    0x8(%rax),%rdx
    571a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    571e:	0f 84 91 00 00 00    	je     57b5 <fwp_rc_wide_dup+0x105>
    5724:	48 83 c2 01          	add    $0x1,%rdx
    5728:	48 89 50 08          	mov    %rdx,0x8(%rax)
    572c:	48 83 c4 18          	add    $0x18,%rsp
    5730:	c3                   	ret
    5731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5738:	4c 8d 40 10          	lea    0x10(%rax),%r8
    573c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    573f:	75 68                	jne    57a9 <fwp_rc_wide_dup+0xf9>
    5741:	bf 18 00 00 00       	mov    $0x18,%edi
    5746:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    574b:	4c 89 04 24          	mov    %r8,(%rsp)
    574f:	e8 3c de ff ff       	call   3590 <malloc@plt>
    5754:	4c 8b 04 24          	mov    (%rsp),%r8
    5758:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    575d:	48 85 c0             	test   %rax,%rax
    5760:	74 5f                	je     57c1 <fwp_rc_wide_dup+0x111>
    5762:	48 89 08             	mov    %rcx,(%rax)
    5765:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    576c:	00 
    576d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5774:	00 
    5775:	49 89 00             	mov    %rax,(%r8)
    5778:	c6 01 ff             	movb   $0xff,(%rcx)
    577b:	48 83 05 e5 7c 06 00 	addq   $0x1,0x67ce5(%rip)        # 6d468 <fwp_heap+0x1c48>
    5782:	01 
    5783:	48 83 c4 18          	add    $0x18,%rsp
    5787:	c3                   	ret
    5788:	80 3f fe             	cmpb   $0xfe,(%rdi)
    578b:	75 13                	jne    57a0 <fwp_rc_wide_dup+0xf0>
    578d:	48 85 c0             	test   %rax,%rax
    5790:	74 af                	je     5741 <fwp_rc_wide_dup+0x91>
    5792:	48 8d 3d 2f a2 00 00 	lea    0xa22f(%rip),%rdi        # f9c8 <_IO_stdin_used+0x9c8>
    5799:	e8 b2 ec ff ff       	call   4450 <fwp_trap>
    579e:	66 90                	xchg   %ax,%ax
    57a0:	48 85 c0             	test   %rax,%rax
    57a3:	0f 85 6d ff ff ff    	jne    5716 <fwp_rc_wide_dup+0x66>
    57a9:	48 8d 3d 40 a2 00 00 	lea    0xa240(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    57b0:	e8 9b ec ff ff       	call   4450 <fwp_trap>
    57b5:	48 8d 3d d2 99 00 00 	lea    0x99d2(%rip),%rdi        # f18e <_IO_stdin_used+0x18e>
    57bc:	e8 8f ec ff ff       	call   4450 <fwp_trap>
    57c1:	e8 6a e6 ff ff       	call   3e30 <fwp_heap_oom>
    57c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57cd:	00 00 00 

00000000000057d0 <fwp_rc_forget_slot>:
    57d0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57d3:	74 0b                	je     57e0 <fwp_rc_forget_slot+0x10>
    57d5:	c3                   	ret
    57d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57dd:	00 00 00 
    57e0:	48 89 f8             	mov    %rdi,%rax
    57e3:	48 83 ec 08          	sub    $0x8,%rsp
    57e7:	48 89 fa             	mov    %rdi,%rdx
    57ea:	48 c1 e8 11          	shr    $0x11,%rax
    57ee:	48 31 f8             	xor    %rdi,%rax
    57f1:	48 89 c1             	mov    %rax,%rcx
    57f4:	48 c1 e9 09          	shr    $0x9,%rcx
    57f8:	48 31 c8             	xor    %rcx,%rax
    57fb:	48 8d 0d 1e 60 06 00 	lea    0x6601e(%rip),%rcx        # 6b820 <fwp_heap>
    5802:	0f b6 c0             	movzbl %al,%eax
    5805:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    580c:	00 
    580d:	48 85 ff             	test   %rdi,%rdi
    5810:	74 3c                	je     584e <fwp_rc_forget_slot+0x7e>
    5812:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5819:	00 
    581a:	48 8b 01             	mov    (%rcx),%rax
    581d:	eb 11                	jmp    5830 <fwp_rc_forget_slot+0x60>
    581f:	90                   	nop
    5820:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5824:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5828:	48 85 ff             	test   %rdi,%rdi
    582b:	74 21                	je     584e <fwp_rc_forget_slot+0x7e>
    582d:	48 89 f8             	mov    %rdi,%rax
    5830:	48 3b 10             	cmp    (%rax),%rdx
    5833:	75 eb                	jne    5820 <fwp_rc_forget_slot+0x50>
    5835:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5839:	48 89 01             	mov    %rax,(%rcx)
    583c:	e8 6f db ff ff       	call   33b0 <free@plt>
    5841:	48 83 2d 1f 7c 06 00 	subq   $0x1,0x67c1f(%rip)        # 6d468 <fwp_heap+0x1c48>
    5848:	01 
    5849:	48 83 c4 08          	add    $0x8,%rsp
    584d:	c3                   	ret
    584e:	48 8d 3d 9b a1 00 00 	lea    0xa19b(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    5855:	e8 f6 eb ff ff       	call   4450 <fwp_trap>
    585a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005860 <fwp_rc_prepare_chunk>:
    5860:	48 83 3d 00 7c 06 00 	cmpq   $0x0,0x67c00(%rip)        # 6d468 <fwp_heap+0x1c48>
    5867:	00 
    5868:	41 54                	push   %r12
    586a:	49 89 f4             	mov    %rsi,%r12
    586d:	55                   	push   %rbp
    586e:	48 89 fd             	mov    %rdi,%rbp
    5871:	53                   	push   %rbx
    5872:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5875:	0f 84 7d 00 00 00    	je     58f8 <fwp_rc_prepare_chunk+0x98>
    587b:	31 db                	xor    %ebx,%ebx
    587d:	85 c0                	test   %eax,%eax
    587f:	75 5f                	jne    58e0 <fwp_rc_prepare_chunk+0x80>
    5881:	48 85 f6             	test   %rsi,%rsi
    5884:	74 7c                	je     5902 <fwp_rc_prepare_chunk+0xa2>
    5886:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    588a:	e8 21 db ff ff       	call   33b0 <free@plt>
    588f:	90                   	nop
    5890:	be 01 00 00 00       	mov    $0x1,%esi
    5895:	4c 89 e7             	mov    %r12,%rdi
    5898:	e8 73 dc ff ff       	call   3510 <calloc@plt>
    589d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    58a1:	48 85 c0             	test   %rax,%rax
    58a4:	0f 85 87 00 00 00    	jne    5931 <fwp_rc_prepare_chunk+0xd1>
    58aa:	e8 81 e5 ff ff       	call   3e30 <fwp_heap_oom>
    58af:	90                   	nop
    58b0:	e8 1b ff ff ff       	call   57d0 <fwp_rc_forget_slot>
    58b5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58b8:	48 83 c3 01          	add    $0x1,%rbx
    58bc:	48 39 c3             	cmp    %rax,%rbx
    58bf:	73 37                	jae    58f8 <fwp_rc_prepare_chunk+0x98>
    58c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58c8:	00 00 
    58ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58d1:	00 00 00 00 
    58d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58dc:	00 00 00 00 
    58e0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58e4:	48 01 df             	add    %rbx,%rdi
    58e7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ea:	74 c4                	je     58b0 <fwp_rc_prepare_chunk+0x50>
    58ec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58ef:	48 83 c3 01          	add    $0x1,%rbx
    58f3:	48 39 c3             	cmp    %rax,%rbx
    58f6:	72 e8                	jb     58e0 <fwp_rc_prepare_chunk+0x80>
    58f8:	49 39 c4             	cmp    %rax,%r12
    58fb:	75 13                	jne    5910 <fwp_rc_prepare_chunk+0xb0>
    58fd:	4d 85 e4             	test   %r12,%r12
    5900:	75 46                	jne    5948 <fwp_rc_prepare_chunk+0xe8>
    5902:	5b                   	pop    %rbx
    5903:	5d                   	pop    %rbp
    5904:	41 5c                	pop    %r12
    5906:	c3                   	ret
    5907:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    590e:	00 00 
    5910:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5914:	48 29 05 55 7b 06 00 	sub    %rax,0x67b55(%rip)        # 6d470 <fwp_heap+0x1c50>
    591b:	e8 90 da ff ff       	call   33b0 <free@plt>
    5920:	4d 85 e4             	test   %r12,%r12
    5923:	0f 85 67 ff ff ff    	jne    5890 <fwp_rc_prepare_chunk+0x30>
    5929:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5930:	00 
    5931:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5935:	5b                   	pop    %rbx
    5936:	4c 01 25 33 7b 06 00 	add    %r12,0x67b33(%rip)        # 6d470 <fwp_heap+0x1c50>
    593d:	5d                   	pop    %rbp
    593e:	41 5c                	pop    %r12
    5940:	c3                   	ret
    5941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5948:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    594c:	5b                   	pop    %rbx
    594d:	4c 89 e2             	mov    %r12,%rdx
    5950:	31 f6                	xor    %esi,%esi
    5952:	5d                   	pop    %rbp
    5953:	41 5c                	pop    %r12
    5955:	e9 56 db ff ff       	jmp    34b0 <memset@plt>
    595a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005960 <fwp_heap_refill>:
    5960:	41 56                	push   %r14
    5962:	41 89 d6             	mov    %edx,%r14d
    5965:	41 55                	push   %r13
    5967:	41 89 f5             	mov    %esi,%r13d
    596a:	41 54                	push   %r12
    596c:	49 89 fc             	mov    %rdi,%r12
    596f:	bf 01 00 00 00       	mov    $0x1,%edi
    5974:	55                   	push   %rbp
    5975:	53                   	push   %rbx
    5976:	e8 f5 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    597b:	48 89 c3             	mov    %rax,%rbx
    597e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5982:	48 8b 05 8f 72 06 00 	mov    0x6728f(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    5989:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    598d:	48 8d 05 8c 5e 06 00 	lea    0x65e8c(%rip),%rax        # 6b820 <fwp_heap>
    5994:	31 d2                	xor    %edx,%edx
    5996:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    599a:	48 89 ef             	mov    %rbp,%rdi
    599d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    59a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    59a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    59ac:	00 
    59ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    59b2:	f7 f1                	div    %ecx
    59b4:	31 d2                	xor    %edx,%edx
    59b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    59ba:	66 0f 6e c8          	movd   %eax,%xmm1
    59be:	89 c6                	mov    %eax,%esi
    59c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59c5:	48 01 c8             	add    %rcx,%rax
    59c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59cc:	48 f7 f1             	div    %rcx
    59cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59d4:	89 45 18             	mov    %eax,0x18(%rbp)
    59d7:	e8 84 fe ff ff       	call   5860 <fwp_rc_prepare_chunk>
    59dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59df:	48 89 d8             	mov    %rbx,%rax
    59e2:	48 c1 e0 10          	shl    $0x10,%rax
    59e6:	48 03 05 e3 71 06 00 	add    0x671e3(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    59ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59f6:	8b 55 08             	mov    0x8(%rbp),%edx
    59f9:	48 0f af d1          	imul   %rcx,%rdx
    59fd:	48 01 c2             	add    %rax,%rdx
    5a00:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a05:	5b                   	pop    %rbx
    5a06:	5d                   	pop    %rbp
    5a07:	41 5c                	pop    %r12
    5a09:	41 5d                	pop    %r13
    5a0b:	41 5e                	pop    %r14
    5a0d:	c3                   	ret
    5a0e:	66 90                	xchg   %ax,%ax

0000000000005a10 <fwp_mem_free>:
    5a10:	48 85 ff             	test   %rdi,%rdi
    5a13:	0f 84 17 02 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a19:	48 8b 35 b0 71 06 00 	mov    0x671b0(%rip),%rsi        # 6cbd0 <fwp_heap+0x13b0>
    5a20:	48 8b 05 d1 71 06 00 	mov    0x671d1(%rip),%rax        # 6cbf8 <fwp_heap+0x13d8>
    5a27:	48 89 fa             	mov    %rdi,%rdx
    5a2a:	48 29 f2             	sub    %rsi,%rdx
    5a2d:	48 c1 e0 10          	shl    $0x10,%rax
    5a31:	48 39 c2             	cmp    %rax,%rdx
    5a34:	0f 83 f6 01 00 00    	jae    5c30 <fwp_mem_free+0x220>
    5a3a:	49 89 d1             	mov    %rdx,%r9
    5a3d:	49 c1 e9 10          	shr    $0x10,%r9
    5a41:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a45:	48 c1 e0 03          	shl    $0x3,%rax
    5a49:	49 89 c0             	mov    %rax,%r8
    5a4c:	4c 03 05 c5 71 06 00 	add    0x671c5(%rip),%r8        # 6cc18 <fwp_heap+0x13f8>
    5a53:	0f 84 d7 01 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a59:	48 83 ec 38          	sub    $0x38,%rsp
    5a5d:	48 89 f9             	mov    %rdi,%rcx
    5a60:	41 0f b6 38          	movzbl (%r8),%edi
    5a64:	40 80 ff 01          	cmp    $0x1,%dil
    5a68:	74 16                	je     5a80 <fwp_mem_free+0x70>
    5a6a:	40 80 ff 02          	cmp    $0x2,%dil
    5a6e:	0f 84 94 00 00 00    	je     5b08 <fwp_mem_free+0xf8>
    5a74:	48 83 c4 38          	add    $0x38,%rsp
    5a78:	c3                   	ret
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a84:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a89:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a8e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a92:	4d 85 d2             	test   %r10,%r10
    5a95:	74 1d                	je     5ab4 <fwp_mem_free+0xa4>
    5a97:	0f b7 c1             	movzwl %cx,%eax
    5a9a:	31 d2                	xor    %edx,%edx
    5a9c:	48 f7 f7             	div    %rdi
    5a9f:	49 01 c2             	add    %rax,%r10
    5aa2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5aa6:	0f 84 44 01 00 00    	je     5bf0 <fwp_mem_free+0x1e0>
    5aac:	41 c6 02 00          	movb   $0x0,(%r10)
    5ab0:	41 8b 78 04          	mov    0x4(%r8),%edi
    5ab4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5abb:	49 63 c1             	movslq %r9d,%rax
    5abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ac2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ac6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5acb:	f2 0f 58 05 8d 71 06 	addsd  0x6718d(%rip),%xmm0        # 6cc60 <fwp_heap+0x1440>
    5ad2:	00 
    5ad3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ad7:	48 8d 05 42 5d 06 00 	lea    0x65d42(%rip),%rax        # 6b820 <fwp_heap>
    5ade:	48 01 d0             	add    %rdx,%rax
    5ae1:	48 8b 10             	mov    (%rax),%rdx
    5ae4:	48 f7 d2             	not    %rdx
    5ae7:	48 89 11             	mov    %rdx,(%rcx)
    5aea:	48 89 08             	mov    %rcx,(%rax)
    5aed:	48 29 3d 4c 71 06 00 	sub    %rdi,0x6714c(%rip)        # 6cc40 <fwp_heap+0x1420>
    5af4:	f2 0f 11 05 64 71 06 	movsd  %xmm0,0x67164(%rip)        # 6cc60 <fwp_heap+0x1440>
    5afb:	00 
    5afc:	48 83 c4 38          	add    $0x38,%rsp
    5b00:	c3                   	ret
    5b01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b08:	66 31 d2             	xor    %dx,%dx
    5b0b:	48 01 d6             	add    %rdx,%rsi
    5b0e:	48 39 f1             	cmp    %rsi,%rcx
    5b11:	0f 85 5d ff ff ff    	jne    5a74 <fwp_mem_free+0x64>
    5b17:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b1b:	48 29 15 1e 71 06 00 	sub    %rdx,0x6711e(%rip)        # 6cc40 <fwp_heap+0x1420>
    5b22:	48 85 d2             	test   %rdx,%rdx
    5b25:	0f 88 a5 00 00 00    	js     5bd0 <fwp_mem_free+0x1c0>
    5b2b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b2f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b34:	f2 0f 58 05 24 71 06 	addsd  0x67124(%rip),%xmm0        # 6cc60 <fwp_heap+0x1440>
    5b3b:	00 
    5b3c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b40:	f2 0f 11 05 18 71 06 	movsd  %xmm0,0x67118(%rip)        # 6cc60 <fwp_heap+0x1440>
    5b47:	00 
    5b48:	48 85 d2             	test   %rdx,%rdx
    5b4b:	74 0c                	je     5b59 <fwp_mem_free+0x149>
    5b4d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b50:	0f 84 db 00 00 00    	je     5c31 <fwp_mem_free+0x221>
    5b56:	c6 02 00             	movb   $0x0,(%rdx)
    5b59:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b5d:	48 85 c9             	test   %rcx,%rcx
    5b60:	74 3e                	je     5ba0 <fwp_mem_free+0x190>
    5b62:	48 8b 15 af 70 06 00 	mov    0x670af(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    5b69:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b6d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b71:	48 01 d0             	add    %rdx,%rax
    5b74:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b78:	48 89 d6             	mov    %rdx,%rsi
    5b7b:	48 29 c6             	sub    %rax,%rsi
    5b7e:	83 e6 08             	and    $0x8,%esi
    5b81:	74 0d                	je     5b90 <fwp_mem_free+0x180>
    5b83:	c6 00 00             	movb   $0x0,(%rax)
    5b86:	48 83 c0 28          	add    $0x28,%rax
    5b8a:	48 39 c2             	cmp    %rax,%rdx
    5b8d:	74 11                	je     5ba0 <fwp_mem_free+0x190>
    5b8f:	90                   	nop
    5b90:	c6 00 00             	movb   $0x0,(%rax)
    5b93:	48 83 c0 50          	add    $0x50,%rax
    5b97:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b9b:	48 39 c2             	cmp    %rax,%rdx
    5b9e:	75 f0                	jne    5b90 <fwp_mem_free+0x180>
    5ba0:	48 01 0d a9 70 06 00 	add    %rcx,0x670a9(%rip)        # 6cc50 <fwp_heap+0x1430>
    5ba7:	4c 3b 0d 62 70 06 00 	cmp    0x67062(%rip),%r9        # 6cc10 <fwp_heap+0x13f0>
    5bae:	73 07                	jae    5bb7 <fwp_mem_free+0x1a7>
    5bb0:	4c 89 0d 59 70 06 00 	mov    %r9,0x67059(%rip)        # 6cc10 <fwp_heap+0x13f0>
    5bb7:	4c 3b 0d 4a 70 06 00 	cmp    0x6704a(%rip),%r9        # 6cc08 <fwp_heap+0x13e8>
    5bbe:	0f 83 b0 fe ff ff    	jae    5a74 <fwp_mem_free+0x64>
    5bc4:	4c 89 0d 3d 70 06 00 	mov    %r9,0x6703d(%rip)        # 6cc08 <fwp_heap+0x13e8>
    5bcb:	e9 a4 fe ff ff       	jmp    5a74 <fwp_mem_free+0x64>
    5bd0:	48 89 d1             	mov    %rdx,%rcx
    5bd3:	83 e2 01             	and    $0x1,%edx
    5bd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bda:	48 d1 e9             	shr    $1,%rcx
    5bdd:	48 09 d1             	or     %rdx,%rcx
    5be0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5be5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5be9:	e9 46 ff ff ff       	jmp    5b34 <fwp_mem_free+0x124>
    5bee:	66 90                	xchg   %ax,%ax
    5bf0:	4c 89 d7             	mov    %r10,%rdi
    5bf3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bf8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bfd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c02:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c06:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c0b:	e8 c0 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c10:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c15:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c1a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c1f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c24:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c29:	e9 7e fe ff ff       	jmp    5aac <fwp_mem_free+0x9c>
    5c2e:	66 90                	xchg   %ax,%ax
    5c30:	c3                   	ret
    5c31:	48 89 d7             	mov    %rdx,%rdi
    5c34:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c39:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c3e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c48:	e8 83 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c4d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c52:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c57:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c5c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c61:	e9 f0 fe ff ff       	jmp    5b56 <fwp_mem_free+0x146>
    5c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c6d:	00 00 00 

0000000000005c70 <fwp_heap_alloc_big>:
    5c70:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c77:	00 00 40 
    5c7a:	41 57                	push   %r15
    5c7c:	41 56                	push   %r14
    5c7e:	41 55                	push   %r13
    5c80:	41 54                	push   %r12
    5c82:	55                   	push   %rbp
    5c83:	53                   	push   %rbx
    5c84:	48 83 ec 08          	sub    $0x8,%rsp
    5c88:	48 39 f8             	cmp    %rdi,%rax
    5c8b:	0f 82 fa 00 00 00    	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5c91:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c98:	49 89 fd             	mov    %rdi,%r13
    5c9b:	41 89 f6             	mov    %esi,%r14d
    5c9e:	48 c1 ed 10          	shr    $0x10,%rbp
    5ca2:	48 89 ef             	mov    %rbp,%rdi
    5ca5:	e8 c6 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5caa:	be 01 00 00 00       	mov    $0x1,%esi
    5caf:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5cb3:	49 89 c4             	mov    %rax,%r12
    5cb6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5cbd:	00 
    5cbe:	48 03 3d 53 6f 06 00 	add    0x66f53(%rip),%rdi        # 6cc18 <fwp_heap+0x13f8>
    5cc5:	c6 07 02             	movb   $0x2,(%rdi)
    5cc8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5ccc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5ccf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cd3:	e8 88 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5cd8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cdc:	76 47                	jbe    5d25 <fwp_heap_alloc_big+0xb5>
    5cde:	4c 01 e5             	add    %r12,%rbp
    5ce1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ce8:	00 
    5ce9:	4c 8d 3d 30 5b 06 00 	lea    0x65b30(%rip),%r15        # 6b820 <fwp_heap>
    5cf0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cf5:	49 c1 e6 03          	shl    $0x3,%r14
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d00:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d07:	31 f6                	xor    %esi,%esi
    5d09:	48 01 dd             	add    %rbx,%rbp
    5d0c:	48 83 c3 28          	add    $0x28,%rbx
    5d10:	48 89 ef             	mov    %rbp,%rdi
    5d13:	e8 48 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5d18:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d1c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d20:	49 39 de             	cmp    %rbx,%r14
    5d23:	75 db                	jne    5d00 <fwp_heap_alloc_big+0x90>
    5d25:	49 c1 e4 10          	shl    $0x10,%r12
    5d29:	4c 03 25 a0 6e 06 00 	add    0x66ea0(%rip),%r12        # 6cbd0 <fwp_heap+0x13b0>
    5d30:	4c 89 ea             	mov    %r13,%rdx
    5d33:	31 f6                	xor    %esi,%esi
    5d35:	4c 89 e7             	mov    %r12,%rdi
    5d38:	e8 73 d7 ff ff       	call   34b0 <memset@plt>
    5d3d:	4c 89 e8             	mov    %r13,%rax
    5d40:	48 03 05 f9 6e 06 00 	add    0x66ef9(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    5d47:	72 42                	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5d49:	48 39 05 f8 6e 06 00 	cmp    %rax,0x66ef8(%rip)        # 6cc48 <fwp_heap+0x1428>
    5d50:	48 89 05 e9 6e 06 00 	mov    %rax,0x66ee9(%rip)        # 6cc40 <fwp_heap+0x1420>
    5d57:	73 07                	jae    5d60 <fwp_heap_alloc_big+0xf0>
    5d59:	48 89 05 e8 6e 06 00 	mov    %rax,0x66ee8(%rip)        # 6cc48 <fwp_heap+0x1428>
    5d60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d64:	4c 89 e0             	mov    %r12,%rax
    5d67:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d6c:	f2 0f 58 05 e4 6e 06 	addsd  0x66ee4(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    5d73:	00 
    5d74:	f2 0f 11 05 dc 6e 06 	movsd  %xmm0,0x66edc(%rip)        # 6cc58 <fwp_heap+0x1438>
    5d7b:	00 
    5d7c:	48 83 c4 08          	add    $0x8,%rsp
    5d80:	5b                   	pop    %rbx
    5d81:	5d                   	pop    %rbp
    5d82:	41 5c                	pop    %r12
    5d84:	41 5d                	pop    %r13
    5d86:	41 5e                	pop    %r14
    5d88:	41 5f                	pop    %r15
    5d8a:	c3                   	ret
    5d8b:	e8 a0 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005d90 <fwp_heap_alloc_slow>:
    5d90:	53                   	push   %rbx
    5d91:	48 89 f9             	mov    %rdi,%rcx
    5d94:	41 89 f1             	mov    %esi,%r9d
    5d97:	48 83 ec 10          	sub    $0x10,%rsp
    5d9b:	8b 05 23 6e 06 00    	mov    0x66e23(%rip),%eax        # 6cbc4 <fwp_heap+0x13a4>
    5da1:	85 c0                	test   %eax,%eax
    5da3:	0f 84 c7 00 00 00    	je     5e70 <fwp_heap_alloc_slow+0xe0>
    5da9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5db0:	0f 87 dd 00 00 00    	ja     5e93 <fwp_heap_alloc_slow+0x103>
    5db6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5dba:	48 8d 3d 5f 5a 06 00 	lea    0x65a5f(%rip),%rdi        # 6b820 <fwp_heap>
    5dc1:	49 63 f1             	movslq %r9d,%rsi
    5dc4:	48 c1 e8 04          	shr    $0x4,%rax
    5dc8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5dcf:	00 00 
    5dd1:	41 0f b6 c2          	movzbl %r10b,%eax
    5dd5:	4c 89 d2             	mov    %r10,%rdx
    5dd8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5ddc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5de3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dee:	48 01 f8             	add    %rdi,%rax
    5df1:	4c 8b 00             	mov    (%rax),%r8
    5df4:	4d 85 c0             	test   %r8,%r8
    5df7:	0f 84 ab 00 00 00    	je     5ea8 <fwp_heap_alloc_slow+0x118>
    5dfd:	49 8b 10             	mov    (%r8),%rdx
    5e00:	48 f7 d2             	not    %rdx
    5e03:	48 89 10             	mov    %rdx,(%rax)
    5e06:	41 83 f9 01          	cmp    $0x1,%r9d
    5e0a:	4c 89 c7             	mov    %r8,%rdi
    5e0d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e11:	31 f6                	xor    %esi,%esi
    5e13:	48 89 ca             	mov    %rcx,%rdx
    5e16:	e8 95 d6 ff ff       	call   34b0 <memset@plt>
    5e1b:	49 89 c0             	mov    %rax,%r8
    5e1e:	48 89 d8             	mov    %rbx,%rax
    5e21:	48 03 05 18 6e 06 00 	add    0x66e18(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    5e28:	0f 82 d9 00 00 00    	jb     5f07 <fwp_heap_alloc_slow+0x177>
    5e2e:	48 39 05 13 6e 06 00 	cmp    %rax,0x66e13(%rip)        # 6cc48 <fwp_heap+0x1428>
    5e35:	48 89 05 04 6e 06 00 	mov    %rax,0x66e04(%rip)        # 6cc40 <fwp_heap+0x1420>
    5e3c:	73 07                	jae    5e45 <fwp_heap_alloc_slow+0xb5>
    5e3e:	48 89 05 03 6e 06 00 	mov    %rax,0x66e03(%rip)        # 6cc48 <fwp_heap+0x1428>
    5e45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e49:	4c 89 c0             	mov    %r8,%rax
    5e4c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e51:	f2 0f 58 05 ff 6d 06 	addsd  0x66dff(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 f7 6d 06 	movsd  %xmm0,0x66df7(%rip)        # 6cc58 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	48 83 c4 10          	add    $0x10,%rsp
    5e65:	5b                   	pop    %rbx
    5e66:	c3                   	ret
    5e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e6e:	00 00 
    5e70:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e74:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e78:	e8 53 ef ff ff       	call   4dd0 <fwp_heap_init>
    5e7d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e81:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e86:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e8d:	0f 86 23 ff ff ff    	jbe    5db6 <fwp_heap_alloc_slow+0x26>
    5e93:	48 83 c4 10          	add    $0x10,%rsp
    5e97:	44 89 ce             	mov    %r9d,%esi
    5e9a:	48 89 cf             	mov    %rcx,%rdi
    5e9d:	5b                   	pop    %rbx
    5e9e:	e9 cd fd ff ff       	jmp    5c70 <fwp_heap_alloc_big>
    5ea3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ea8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5eac:	4d 85 c0             	test   %r8,%r8
    5eaf:	74 1f                	je     5ed0 <fwp_heap_alloc_slow+0x140>
    5eb1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5eb5:	4d 29 c3             	sub    %r8,%r11
    5eb8:	49 39 db             	cmp    %rbx,%r11
    5ebb:	72 13                	jb     5ed0 <fwp_heap_alloc_slow+0x140>
    5ebd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ec1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ec5:	e9 3c ff ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ed0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5ed7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5edb:	44 89 ca             	mov    %r9d,%edx
    5ede:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ee3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ee7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5eeb:	44 89 d6             	mov    %r10d,%esi
    5eee:	48 01 c7             	add    %rax,%rdi
    5ef1:	e8 6a fa ff ff       	call   5960 <fwp_heap_refill>
    5ef6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5efb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5eff:	49 89 c0             	mov    %rax,%r8
    5f02:	e9 ff fe ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5f07:	e8 24 df ff ff       	call   3e30 <fwp_heap_oom>
    5f0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f10 <fwp_heap_alloc>:
    5f10:	53                   	push   %rbx
    5f11:	48 89 fa             	mov    %rdi,%rdx
    5f14:	48 83 ec 10          	sub    $0x10,%rsp
    5f18:	8b 1d ca 75 06 00    	mov    0x675ca(%rip),%ebx        # 6d4e8 <iteration_active>
    5f1e:	8b 05 a0 6c 06 00    	mov    0x66ca0(%rip),%eax        # 6cbc4 <fwp_heap+0x13a4>
    5f24:	85 db                	test   %ebx,%ebx
    5f26:	0f 85 04 01 00 00    	jne    6030 <fwp_heap_alloc+0x120>
    5f2c:	85 c0                	test   %eax,%eax
    5f2e:	0f 84 ac 01 00 00    	je     60e0 <fwp_heap_alloc+0x1d0>
    5f34:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f3b:	0f 87 9f 01 00 00    	ja     60e0 <fwp_heap_alloc+0x1d0>
    5f41:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f45:	48 8d 05 d4 58 06 00 	lea    0x658d4(%rip),%rax        # 6b820 <fwp_heap>
    5f4c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f50:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f57:	00 
    5f58:	48 63 ce             	movslq %esi,%rcx
    5f5b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f62:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f69:	00 
    5f6a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f6e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f72:	48 01 c8             	add    %rcx,%rax
    5f75:	48 8b 08             	mov    (%rax),%rcx
    5f78:	48 85 c9             	test   %rcx,%rcx
    5f7b:	0f 84 ff 00 00 00    	je     6080 <fwp_heap_alloc+0x170>
    5f81:	48 8b 39             	mov    (%rcx),%rdi
    5f84:	48 f7 d7             	not    %rdi
    5f87:	48 89 38             	mov    %rdi,(%rax)
    5f8a:	83 fe 01             	cmp    $0x1,%esi
    5f8d:	48 89 cf             	mov    %rcx,%rdi
    5f90:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f95:	49 0f 45 d0          	cmovne %r8,%rdx
    5f99:	31 f6                	xor    %esi,%esi
    5f9b:	e8 10 d5 ff ff       	call   34b0 <memset@plt>
    5fa0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5fa5:	48 89 c1             	mov    %rax,%rcx
    5fa8:	4c 89 c0             	mov    %r8,%rax
    5fab:	48 03 05 8e 6c 06 00 	add    0x66c8e(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    5fb2:	0f 82 35 01 00 00    	jb     60ed <fwp_heap_alloc+0x1dd>
    5fb8:	48 39 05 89 6c 06 00 	cmp    %rax,0x66c89(%rip)        # 6cc48 <fwp_heap+0x1428>
    5fbf:	48 89 05 7a 6c 06 00 	mov    %rax,0x66c7a(%rip)        # 6cc40 <fwp_heap+0x1420>
    5fc6:	73 07                	jae    5fcf <fwp_heap_alloc+0xbf>
    5fc8:	48 89 05 79 6c 06 00 	mov    %rax,0x66c79(%rip)        # 6cc48 <fwp_heap+0x1428>
    5fcf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fd3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fd8:	f2 0f 58 05 78 6c 06 	addsd  0x66c78(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    5fdf:	00 
    5fe0:	f2 0f 11 05 70 6c 06 	movsd  %xmm0,0x66c70(%rip)        # 6cc58 <fwp_heap+0x1438>
    5fe7:	00 
    5fe8:	85 db                	test   %ebx,%ebx
    5fea:	74 33                	je     601f <fwp_heap_alloc+0x10f>
    5fec:	48 8b 05 4d 6c 06 00 	mov    0x66c4d(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    5ff3:	48 85 c0             	test   %rax,%rax
    5ff6:	0f 88 ac 00 00 00    	js     60a8 <fwp_heap_alloc+0x198>
    5ffc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6000:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6005:	f2 0f 5c 05 bb 74 06 	subsd  0x674bb(%rip),%xmm0        # 6d4c8 <iteration_start_charge>
    600c:	00 
    600d:	66 0f 2f 05 ab 74 06 	comisd 0x674ab(%rip),%xmm0        # 6d4c0 <iteration_peak>
    6014:	00 
    6015:	76 08                	jbe    601f <fwp_heap_alloc+0x10f>
    6017:	f2 0f 11 05 a1 74 06 	movsd  %xmm0,0x674a1(%rip)        # 6d4c0 <iteration_peak>
    601e:	00 
    601f:	48 83 c4 10          	add    $0x10,%rsp
    6023:	48 89 c8             	mov    %rcx,%rax
    6026:	5b                   	pop    %rbx
    6027:	c3                   	ret
    6028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    602f:	00 
    6030:	85 f6                	test   %esi,%esi
    6032:	74 34                	je     6068 <fwp_heap_alloc+0x158>
    6034:	48 83 05 a4 74 06 00 	addq   $0x1,0x674a4(%rip)        # 6d4e0 <iteration_requests>
    603b:	01 
    603c:	48 01 3d 95 74 06 00 	add    %rdi,0x67495(%rip)        # 6d4d8 <iteration_bytes>
    6043:	85 c0                	test   %eax,%eax
    6045:	74 0d                	je     6054 <fwp_heap_alloc+0x144>
    6047:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    604e:	0f 86 ed fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6054:	48 89 d7             	mov    %rdx,%rdi
    6057:	e8 34 fd ff ff       	call   5d90 <fwp_heap_alloc_slow>
    605c:	48 89 c1             	mov    %rax,%rcx
    605f:	eb 8b                	jmp    5fec <fwp_heap_alloc+0xdc>
    6061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6068:	85 c0                	test   %eax,%eax
    606a:	74 0d                	je     6079 <fwp_heap_alloc+0x169>
    606c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6073:	0f 86 c8 fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6079:	31 f6                	xor    %esi,%esi
    607b:	eb d7                	jmp    6054 <fwp_heap_alloc+0x144>
    607d:	0f 1f 00             	nopl   (%rax)
    6080:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6084:	48 85 c9             	test   %rcx,%rcx
    6087:	74 0c                	je     6095 <fwp_heap_alloc+0x185>
    6089:	48 8b 78 10          	mov    0x10(%rax),%rdi
    608d:	48 29 cf             	sub    %rcx,%rdi
    6090:	4c 39 c7             	cmp    %r8,%rdi
    6093:	73 3b                	jae    60d0 <fwp_heap_alloc+0x1c0>
    6095:	48 89 d7             	mov    %rdx,%rdi
    6098:	e8 f3 fc ff ff       	call   5d90 <fwp_heap_alloc_slow>
    609d:	48 89 c1             	mov    %rax,%rcx
    60a0:	e9 43 ff ff ff       	jmp    5fe8 <fwp_heap_alloc+0xd8>
    60a5:	0f 1f 00             	nopl   (%rax)
    60a8:	48 89 c2             	mov    %rax,%rdx
    60ab:	83 e0 01             	and    $0x1,%eax
    60ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60b2:	48 d1 ea             	shr    $1,%rdx
    60b5:	48 09 c2             	or     %rax,%rdx
    60b8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    60bd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60c1:	e9 3f ff ff ff       	jmp    6005 <fwp_heap_alloc+0xf5>
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60d4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60d8:	e9 ad fe ff ff       	jmp    5f8a <fwp_heap_alloc+0x7a>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 83 c4 10          	add    $0x10,%rsp
    60e4:	48 89 d7             	mov    %rdx,%rdi
    60e7:	5b                   	pop    %rbx
    60e8:	e9 a3 fc ff ff       	jmp    5d90 <fwp_heap_alloc_slow>
    60ed:	e8 3e dd ff ff       	call   3e30 <fwp_heap_oom>
    60f2:	0f 1f 00             	nopl   (%rax)
    60f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60fc:	00 00 00 00 

0000000000006100 <fwp_data.part.0.constprop.0>:
    6100:	41 56                	push   %r14
    6102:	8b 05 bc 6a 06 00    	mov    0x66abc(%rip),%eax        # 6cbc4 <fwp_heap+0x13a4>
    6108:	41 89 fe             	mov    %edi,%r14d
    610b:	41 55                	push   %r13
    610d:	44 8b 2d d4 73 06 00 	mov    0x673d4(%rip),%r13d        # 6d4e8 <iteration_active>
    6114:	41 54                	push   %r12
    6116:	49 89 f4             	mov    %rsi,%r12
    6119:	55                   	push   %rbp
    611a:	53                   	push   %rbx
    611b:	45 85 ed             	test   %r13d,%r13d
    611e:	0f 84 1c 01 00 00    	je     6240 <fwp_data.part.0.constprop.0+0x140>
    6124:	48 83 05 b4 73 06 00 	addq   $0x1,0x673b4(%rip)        # 6d4e0 <iteration_requests>
    612b:	01 
    612c:	48 83 05 a4 73 06 00 	addq   $0x18,0x673a4(%rip)        # 6d4d8 <iteration_bytes>
    6133:	18 
    6134:	85 c0                	test   %eax,%eax
    6136:	0f 84 8c 01 00 00    	je     62c8 <fwp_data.part.0.constprop.0+0x1c8>
    613c:	0f b6 05 7f 66 06 00 	movzbl 0x6667f(%rip),%eax        # 6c7c2 <fwp_heap+0xfa2>
    6143:	48 8d 15 d6 56 06 00 	lea    0x656d6(%rip),%rdx        # 6b820 <fwp_heap>
    614a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6151:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6155:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6159:	48 8b 18             	mov    (%rax),%rbx
    615c:	48 85 db             	test   %rbx,%rbx
    615f:	0f 84 fb 00 00 00    	je     6260 <fwp_data.part.0.constprop.0+0x160>
    6165:	48 8b 13             	mov    (%rbx),%rdx
    6168:	48 f7 d2             	not    %rdx
    616b:	48 89 10             	mov    %rdx,(%rax)
    616e:	48 83 fd 18          	cmp    $0x18,%rbp
    6172:	76 1b                	jbe    618f <fwp_data.part.0.constprop.0+0x8f>
    6174:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6178:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    617c:	31 f6                	xor    %esi,%esi
    617e:	48 c1 e8 03          	shr    $0x3,%rax
    6182:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6189:	00 
    618a:	e8 21 d3 ff ff       	call   34b0 <memset@plt>
    618f:	48 89 e8             	mov    %rbp,%rax
    6192:	48 03 05 a7 6a 06 00 	add    0x66aa7(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    6199:	0f 82 3d 01 00 00    	jb     62dc <fwp_data.part.0.constprop.0+0x1dc>
    619f:	48 39 05 a2 6a 06 00 	cmp    %rax,0x66aa2(%rip)        # 6cc48 <fwp_heap+0x1428>
    61a6:	48 89 05 93 6a 06 00 	mov    %rax,0x66a93(%rip)        # 6cc40 <fwp_heap+0x1420>
    61ad:	73 07                	jae    61b6 <fwp_data.part.0.constprop.0+0xb6>
    61af:	48 89 05 92 6a 06 00 	mov    %rax,0x66a92(%rip)        # 6cc48 <fwp_heap+0x1428>
    61b6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61ba:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    61bf:	f2 0f 58 05 91 6a 06 	addsd  0x66a91(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    61c6:	00 
    61c7:	f2 0f 11 05 89 6a 06 	movsd  %xmm0,0x66a89(%rip)        # 6cc58 <fwp_heap+0x1438>
    61ce:	00 
    61cf:	45 85 ed             	test   %r13d,%r13d
    61d2:	74 33                	je     6207 <fwp_data.part.0.constprop.0+0x107>
    61d4:	48 8b 05 65 6a 06 00 	mov    0x66a65(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    61db:	48 85 c0             	test   %rax,%rax
    61de:	0f 88 a4 00 00 00    	js     6288 <fwp_data.part.0.constprop.0+0x188>
    61e4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61e8:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    61ed:	f2 0f 5c 05 d3 72 06 	subsd  0x672d3(%rip),%xmm0        # 6d4c8 <iteration_start_charge>
    61f4:	00 
    61f5:	66 0f 2f 05 c3 72 06 	comisd 0x672c3(%rip),%xmm0        # 6d4c0 <iteration_peak>
    61fc:	00 
    61fd:	76 08                	jbe    6207 <fwp_data.part.0.constprop.0+0x107>
    61ff:	f2 0f 11 05 b9 72 06 	movsd  %xmm0,0x672b9(%rip)        # 6d4c0 <iteration_peak>
    6206:	00 
    6207:	b8 02 00 00 00       	mov    $0x2,%eax
    620c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6211:	66 0f 6e c8          	movd   %eax,%xmm1
    6215:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6219:	66 0f d6 03          	movq   %xmm0,(%rbx)
    621d:	49 8b 04 24          	mov    (%r12),%rax
    6221:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6225:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    622a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    622e:	48 89 d8             	mov    %rbx,%rax
    6231:	5b                   	pop    %rbx
    6232:	5d                   	pop    %rbp
    6233:	41 5c                	pop    %r12
    6235:	41 5d                	pop    %r13
    6237:	41 5e                	pop    %r14
    6239:	c3                   	ret
    623a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6240:	85 c0                	test   %eax,%eax
    6242:	0f 85 f4 fe ff ff    	jne    613c <fwp_data.part.0.constprop.0+0x3c>
    6248:	31 f6                	xor    %esi,%esi
    624a:	bf 18 00 00 00       	mov    $0x18,%edi
    624f:	e8 bc fc ff ff       	call   5f10 <fwp_heap_alloc>
    6254:	48 89 c3             	mov    %rax,%rbx
    6257:	eb ae                	jmp    6207 <fwp_data.part.0.constprop.0+0x107>
    6259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6260:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6264:	48 85 db             	test   %rbx,%rbx
    6267:	74 47                	je     62b0 <fwp_data.part.0.constprop.0+0x1b0>
    6269:	48 8b 50 10          	mov    0x10(%rax),%rdx
    626d:	48 29 da             	sub    %rbx,%rdx
    6270:	48 39 ea             	cmp    %rbp,%rdx
    6273:	72 3b                	jb     62b0 <fwp_data.part.0.constprop.0+0x1b0>
    6275:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6279:	48 89 50 08          	mov    %rdx,0x8(%rax)
    627d:	e9 ec fe ff ff       	jmp    616e <fwp_data.part.0.constprop.0+0x6e>
    6282:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6288:	48 89 c2             	mov    %rax,%rdx
    628b:	83 e0 01             	and    $0x1,%eax
    628e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6292:	48 d1 ea             	shr    $1,%rdx
    6295:	48 09 c2             	or     %rax,%rdx
    6298:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    629d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    62a1:	e9 47 ff ff ff       	jmp    61ed <fwp_data.part.0.constprop.0+0xed>
    62a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    62ad:	00 00 00 
    62b0:	31 f6                	xor    %esi,%esi
    62b2:	bf 18 00 00 00       	mov    $0x18,%edi
    62b7:	e8 54 fc ff ff       	call   5f10 <fwp_heap_alloc>
    62bc:	48 89 c3             	mov    %rax,%rbx
    62bf:	e9 0b ff ff ff       	jmp    61cf <fwp_data.part.0.constprop.0+0xcf>
    62c4:	0f 1f 40 00          	nopl   0x0(%rax)
    62c8:	31 f6                	xor    %esi,%esi
    62ca:	bf 18 00 00 00       	mov    $0x18,%edi
    62cf:	e8 3c fc ff ff       	call   5f10 <fwp_heap_alloc>
    62d4:	48 89 c3             	mov    %rax,%rbx
    62d7:	e9 f8 fe ff ff       	jmp    61d4 <fwp_data.part.0.constprop.0+0xd4>
    62dc:	e8 4f db ff ff       	call   3e30 <fwp_heap_oom>
    62e1:	0f 1f 40 00          	nopl   0x0(%rax)
    62e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62ec:	00 00 00 00 

00000000000062f0 <fwp_p_ad_push>:
    62f0:	41 57                	push   %r15
    62f2:	41 56                	push   %r14
    62f4:	41 55                	push   %r13
    62f6:	49 89 d5             	mov    %rdx,%r13
    62f9:	41 54                	push   %r12
    62fb:	49 89 fc             	mov    %rdi,%r12
    62fe:	55                   	push   %rbp
    62ff:	53                   	push   %rbx
    6300:	48 83 ec 38          	sub    $0x38,%rsp
    6304:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6309:	48 85 ff             	test   %rdi,%rdi
    630c:	79 09                	jns    6317 <fwp_p_ad_push+0x27>
    630e:	48 85 d2             	test   %rdx,%rdx
    6311:	0f 88 a9 01 00 00    	js     64c0 <fwp_p_ad_push+0x1d0>
    6317:	48 89 f8             	mov    %rdi,%rax
    631a:	48 89 0c 24          	mov    %rcx,(%rsp)
    631e:	48 09 d0             	or     %rdx,%rax
    6321:	0f 89 71 01 00 00    	jns    6498 <fwp_p_ad_push+0x1a8>
    6327:	48 89 f8             	mov    %rdi,%rax
    632a:	48 c1 f8 20          	sar    $0x20,%rax
    632e:	48 85 ff             	test   %rdi,%rdi
    6331:	79 24                	jns    6357 <fwp_p_ad_push+0x67>
    6333:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6338:	48 89 d0             	mov    %rdx,%rax
    633b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    6342:	00 
    6343:	49 89 d4             	mov    %rdx,%r12
    6346:	48 c1 f8 20          	sar    $0x20,%rax
    634a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    6351:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6357:	48 89 c7             	mov    %rax,%rdi
    635a:	e8 d1 e3 ff ff       	call   4730 <fwp_tape_of>
    635f:	48 89 c3             	mov    %rax,%rbx
    6362:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6367:	0f 85 6e 02 00 00    	jne    65db <fwp_p_ad_push+0x2eb>
    636d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    6371:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6378:	0f 8f 51 02 00 00    	jg     65cf <fwp_p_ad_push+0x2df>
    637e:	44 89 e0             	mov    %r12d,%eax
    6381:	4c 39 f8             	cmp    %r15,%rax
    6384:	0f 8d 39 02 00 00    	jge    65c3 <fwp_p_ad_push+0x2d3>
    638a:	4d 85 ed             	test   %r13,%r13
    638d:	78 0c                	js     639b <fwp_p_ad_push+0xab>
    638f:	44 89 e8             	mov    %r13d,%eax
    6392:	4c 39 f8             	cmp    %r15,%rax
    6395:	0f 8d 28 02 00 00    	jge    65c3 <fwp_p_ad_push+0x2d3>
    639b:	4d 89 fe             	mov    %r15,%r14
    639e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    63a2:	49 8d 46 01          	lea    0x1(%r14),%rax
    63a6:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    63ac:	0f 87 1d 02 00 00    	ja     65cf <fwp_p_ad_push+0x2df>
    63b2:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    63b6:	48 39 e8             	cmp    %rbp,%rax
    63b9:	0f 8e 31 01 00 00    	jle    64f0 <fwp_p_ad_push+0x200>
    63bf:	48 85 ed             	test   %rbp,%rbp
    63c2:	ba 40 00 00 00       	mov    $0x40,%edx
    63c7:	48 0f 44 ea          	cmove  %rdx,%rbp
    63cb:	48 39 e8             	cmp    %rbp,%rax
    63ce:	7e 20                	jle    63f0 <fwp_p_ad_push+0x100>
    63d0:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    63d7:	0f 8f 03 01 00 00    	jg     64e0 <fwp_p_ad_push+0x1f0>
    63dd:	48 01 ed             	add    %rbp,%rbp
    63e0:	48 39 e8             	cmp    %rbp,%rax
    63e3:	7f eb                	jg     63d0 <fwp_p_ad_push+0xe0>
    63e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    63ec:	00 00 00 00 
    63f0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    63f7:	00 
    63f8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    63fc:	ba 01 00 00 00       	mov    $0x1,%edx
    6401:	48 89 c6             	mov    %rax,%rsi
    6404:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6409:	e8 82 ed ff ff       	call   5190 <ad_raw_realloc>
    640e:	48 85 c0             	test   %rax,%rax
    6411:	0f 84 d0 01 00 00    	je     65e7 <fwp_p_ad_push+0x2f7>
    6417:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    641b:	48 89 ee             	mov    %rbp,%rsi
    641e:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6422:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6426:	48 c1 e6 04          	shl    $0x4,%rsi
    642a:	48 8d 04 90          	lea    (%rax,%rdx,4),%rax
    642e:	ba 02 00 00 00       	mov    $0x2,%edx
    6433:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6437:	e8 54 ed ff ff       	call   5190 <ad_raw_realloc>
    643c:	48 85 c0             	test   %rax,%rax
    643f:	0f 84 a2 01 00 00    	je     65e7 <fwp_p_ad_push+0x2f7>
    6445:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    6449:	48 89 43 30          	mov    %rax,0x30(%rbx)
    644d:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6454:	00 
    6455:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    645c:	00 
    645d:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
    6464:	00 
    6465:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    6469:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    646e:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6472:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    6476:	4d 85 f6             	test   %r14,%r14
    6479:	0f 85 e5 00 00 00    	jne    6564 <fwp_p_ad_push+0x274>
    647f:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6483:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    6487:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    648b:	48 01 d1             	add    %rdx,%rcx
    648e:	48 89 4b 28          	mov    %rcx,0x28(%rbx)
    6492:	eb 7c                	jmp    6510 <fwp_p_ad_push+0x220>
    6494:	0f 1f 40 00          	nopl   0x0(%rax)
    6498:	48 89 d0             	mov    %rdx,%rax
    649b:	48 c1 ff 20          	sar    $0x20,%rdi
    649f:	48 c1 f8 20          	sar    $0x20,%rax
    64a3:	48 39 c7             	cmp    %rax,%rdi
    64a6:	0f 84 ab fe ff ff    	je     6357 <fwp_p_ad_push+0x67>
    64ac:	48 8d 3d 65 95 00 00 	lea    0x9565(%rip),%rdi        # fa18 <_IO_stdin_used+0xa18>
    64b3:	e8 98 df ff ff       	call   4450 <fwp_trap>
    64b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    64bf:	00 
    64c0:	48 83 c4 38          	add    $0x38,%rsp
    64c4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    64cb:	5b                   	pop    %rbx
    64cc:	5d                   	pop    %rbp
    64cd:	41 5c                	pop    %r12
    64cf:	41 5d                	pop    %r13
    64d1:	41 5e                	pop    %r14
    64d3:	41 5f                	pop    %r15
    64d5:	c3                   	ret
    64d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    64dd:	00 00 00 
    64e0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    64e5:	e9 06 ff ff ff       	jmp    63f0 <fwp_p_ad_push+0x100>
    64ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    64f0:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    64f4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    64f8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    64ff:	00 
    6500:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6507:	00 
    6508:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
    650c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6510:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6516:	46 89 24 12          	mov    %r12d,(%rdx,%r10,1)
    651a:	4d 85 ed             	test   %r13,%r13
    651d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6522:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6528:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    652f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6533:	49 8d 47 01          	lea    0x1(%r15),%rax
    6537:	46 89 2c 11          	mov    %r13d,(%rcx,%r10,1)
    653b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6541:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6545:	48 83 c4 38          	add    $0x38,%rsp
    6549:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6550:	ff ff ff 
    6553:	4c 21 e0             	and    %r12,%rax
    6556:	5b                   	pop    %rbx
    6557:	5d                   	pop    %rbp
    6558:	4c 09 f8             	or     %r15,%rax
    655b:	41 5c                	pop    %r12
    655d:	41 5d                	pop    %r13
    655f:	41 5e                	pop    %r14
    6561:	41 5f                	pop    %r15
    6563:	c3                   	ret
    6564:	4c 89 ca             	mov    %r9,%rdx
    6567:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    656c:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    6571:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    6576:	e8 75 d0 ff ff       	call   35f0 <memmove@plt>
    657b:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    6580:	4c 03 73 30          	add    0x30(%rbx),%r14
    6584:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    6589:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    658d:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6591:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    6596:	48 03 7b 20          	add    0x20(%rbx),%rdi
    659a:	4c 89 d2             	mov    %r10,%rdx
    659d:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    65a2:	e8 49 d0 ff ff       	call   35f0 <memmove@plt>
    65a7:	48 8b 43 30          	mov    0x30(%rbx),%rax
    65ab:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    65af:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    65b4:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    65b9:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    65be:	e9 c0 fe ff ff       	jmp    6483 <fwp_p_ad_push+0x193>
    65c3:	48 8d 3d f8 8b 00 00 	lea    0x8bf8(%rip),%rdi        # f1c2 <_IO_stdin_used+0x1c2>
    65ca:	e8 81 de ff ff       	call   4450 <fwp_trap>
    65cf:	48 8d 3d d1 8b 00 00 	lea    0x8bd1(%rip),%rdi        # f1a7 <_IO_stdin_used+0x1a7>
    65d6:	e8 75 de ff ff       	call   4450 <fwp_trap>
    65db:	48 8d 3d 7e 94 00 00 	lea    0x947e(%rip),%rdi        # fa60 <_IO_stdin_used+0xa60>
    65e2:	e8 69 de ff ff       	call   4450 <fwp_trap>
    65e7:	48 89 df             	mov    %rbx,%rdi
    65ea:	e8 a1 d6 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    65ef:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    65f3:	48 85 ff             	test   %rdi,%rdi
    65f6:	74 05                	je     65fd <fwp_p_ad_push+0x30d>
    65f8:	e8 d3 ea ff ff       	call   50d0 <ad_raw_free.part.0>
    65fd:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6601:	48 85 ff             	test   %rdi,%rdi
    6604:	74 05                	je     660b <fwp_p_ad_push+0x31b>
    6606:	e8 c5 ea ff ff       	call   50d0 <ad_raw_free.part.0>
    660b:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    660f:	48 85 ff             	test   %rdi,%rdi
    6612:	74 05                	je     6619 <fwp_p_ad_push+0x329>
    6614:	e8 b7 ea ff ff       	call   50d0 <ad_raw_free.part.0>
    6619:	31 c9                	xor    %ecx,%ecx
    661b:	31 c0                	xor    %eax,%eax
    661d:	31 d2                	xor    %edx,%edx
    661f:	be 01 00 00 00       	mov    $0x1,%esi
    6624:	89 53 04             	mov    %edx,0x4(%rbx)
    6627:	66 0f ef c0          	pxor   %xmm0,%xmm0
    662b:	ba 13 00 00 00       	mov    $0x13,%edx
    6630:	48 8d 3d d1 89 00 00 	lea    0x89d1(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    6637:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    663b:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    663f:	48 8b 0d fa c9 00 00 	mov    0xc9fa(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    6646:	48 89 43 40          	mov    %rax,0x40(%rbx)
    664a:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    664e:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    6652:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    6656:	e8 05 d0 ff ff       	call   3660 <fwrite@plt>
    665b:	31 ff                	xor    %edi,%edi
    665d:	e8 3e cf ff ff       	call   35a0 <fflush@plt>
    6662:	bf 66 00 00 00       	mov    $0x66,%edi
    6667:	e8 14 d0 ff ff       	call   3680 <_Exit@plt>
    666c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006670 <w120>:
    6670:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6674:	41 55                	push   %r13
    6676:	48 89 fa             	mov    %rdi,%rdx
    6679:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    667d:	41 54                	push   %r12
    667f:	49 89 fc             	mov    %rdi,%r12
    6682:	55                   	push   %rbp
    6683:	53                   	push   %rbx
    6684:	48 89 f3             	mov    %rsi,%rbx
    6687:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    668c:	48 89 f1             	mov    %rsi,%rcx
    668f:	48 83 ec 28          	sub    $0x28,%rsp
    6693:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6699:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    669f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    66a5:	e8 46 fc ff ff       	call   62f0 <fwp_p_ad_push>
    66aa:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    66b0:	48 89 da             	mov    %rbx,%rdx
    66b3:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    66b9:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    66c0:	00 f0 3f 
    66c3:	48 89 c7             	mov    %rax,%rdi
    66c6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    66cd:	00 f0 bf 
    66d0:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    66d5:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    66db:	e8 10 fc ff ff       	call   62f0 <fwp_p_ad_push>
    66e0:	f2 0f 10 05 80 96 00 	movsd  0x9680(%rip),%xmm0        # fd68 <msg.4+0x28>
    66e7:	00 
    66e8:	4c 89 e7             	mov    %r12,%rdi
    66eb:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    66f1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    66f8:	00 f0 3f 
    66fb:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6702:	49 89 c5             	mov    %rax,%r13
    6705:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    670c:	00 f0 bf 
    670f:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    6714:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    671a:	e8 d1 fb ff ff       	call   62f0 <fwp_p_ad_push>
    671f:	48 89 e9             	mov    %rbp,%rcx
    6722:	4c 89 ea             	mov    %r13,%rdx
    6725:	48 89 ee             	mov    %rbp,%rsi
    6728:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    672e:	4c 89 ef             	mov    %r13,%rdi
    6731:	49 89 c4             	mov    %rax,%r12
    6734:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6738:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    673e:	e8 ad fb ff ff       	call   62f0 <fwp_p_ad_push>
    6743:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6749:	f2 0f 59 1d 1f 96 00 	mulsd  0x961f(%rip),%xmm3        # fd70 <msg.4+0x30>
    6750:	00 
    6751:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6758:	00 59 40 
    675b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6760:	48 89 c2             	mov    %rax,%rdx
    6763:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    676a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6770:	e8 7b fb ff ff       	call   62f0 <fwp_p_ad_push>
    6775:	48 89 d9             	mov    %rbx,%rcx
    6778:	4c 89 e2             	mov    %r12,%rdx
    677b:	48 89 de             	mov    %rbx,%rsi
    677e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6784:	4c 89 e7             	mov    %r12,%rdi
    6787:	48 89 c5             	mov    %rax,%rbp
    678a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    678e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6794:	e8 57 fb ff ff       	call   62f0 <fwp_p_ad_push>
    6799:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    679f:	48 89 ea             	mov    %rbp,%rdx
    67a2:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    67a8:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    67af:	00 f0 3f 
    67b2:	48 89 c7             	mov    %rax,%rdi
    67b5:	48 89 ce             	mov    %rcx,%rsi
    67b8:	66 48 0f 7e db       	movq   %xmm3,%rbx
    67bd:	e8 2e fb ff ff       	call   62f0 <fwp_p_ad_push>
    67c2:	48 83 c4 28          	add    $0x28,%rsp
    67c6:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    67cb:	5b                   	pop    %rbx
    67cc:	5d                   	pop    %rbp
    67cd:	41 5c                	pop    %r12
    67cf:	41 5d                	pop    %r13
    67d1:	c3                   	ret
    67d2:	0f 1f 00             	nopl   (%rax)
    67d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    67dc:	00 00 00 00 

00000000000067e0 <fwp_rc_share>:
    67e0:	48 8b 05 11 64 06 00 	mov    0x66411(%rip),%rax        # 6cbf8 <fwp_heap+0x13d8>
    67e7:	48 2b 3d e2 63 06 00 	sub    0x663e2(%rip),%rdi        # 6cbd0 <fwp_heap+0x13b0>
    67ee:	48 c1 e0 10          	shl    $0x10,%rax
    67f2:	48 39 c7             	cmp    %rax,%rdi
    67f5:	73 4a                	jae    6841 <fwp_rc_share+0x61>
    67f7:	48 89 f8             	mov    %rdi,%rax
    67fa:	48 c1 e8 10          	shr    $0x10,%rax
    67fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6802:	48 8b 05 0f 64 06 00 	mov    0x6640f(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    6809:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    680d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6811:	48 85 d2             	test   %rdx,%rdx
    6814:	74 2b                	je     6841 <fwp_rc_share+0x61>
    6816:	0f b6 08             	movzbl (%rax),%ecx
    6819:	80 f9 02             	cmp    $0x2,%cl
    681c:	74 2a                	je     6848 <fwp_rc_share+0x68>
    681e:	80 f9 01             	cmp    $0x1,%cl
    6821:	75 1e                	jne    6841 <fwp_rc_share+0x61>
    6823:	8b 48 18             	mov    0x18(%rax),%ecx
    6826:	0f b7 ff             	movzwl %di,%edi
    6829:	8b 40 1c             	mov    0x1c(%rax),%eax
    682c:	48 0f af f9          	imul   %rcx,%rdi
    6830:	48 c1 ef 20          	shr    $0x20,%rdi
    6834:	48 39 c7             	cmp    %rax,%rdi
    6837:	73 08                	jae    6841 <fwp_rc_share+0x61>
    6839:	48 01 fa             	add    %rdi,%rdx
    683c:	80 3a 00             	cmpb   $0x0,(%rdx)
    683f:	75 0d                	jne    684e <fwp_rc_share+0x6e>
    6841:	c3                   	ret
    6842:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6848:	66 85 ff             	test   %di,%di
    684b:	74 ef                	je     683c <fwp_rc_share+0x5c>
    684d:	c3                   	ret
    684e:	50                   	push   %rax
    684f:	48 8d 3d 3a 92 00 00 	lea    0x923a(%rip),%rdi        # fa90 <_IO_stdin_used+0xa90>
    6856:	e8 f5 db ff ff       	call   4450 <fwp_trap>
    685b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006860 <fwp_rc_fresh>:
    6860:	48 8b 15 91 63 06 00 	mov    0x66391(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    6867:	48 89 f8             	mov    %rdi,%rax
    686a:	48 89 fe             	mov    %rdi,%rsi
    686d:	48 2b 05 5c 63 06 00 	sub    0x6635c(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    6874:	48 c1 e2 10          	shl    $0x10,%rdx
    6878:	48 39 d0             	cmp    %rdx,%rax
    687b:	73 4f                	jae    68cc <fwp_rc_fresh+0x6c>
    687d:	48 89 c2             	mov    %rax,%rdx
    6880:	48 c1 ea 10          	shr    $0x10,%rdx
    6884:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6888:	48 8b 15 89 63 06 00 	mov    0x66389(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    688f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6893:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6897:	48 85 d2             	test   %rdx,%rdx
    689a:	74 30                	je     68cc <fwp_rc_fresh+0x6c>
    689c:	0f b6 39             	movzbl (%rcx),%edi
    689f:	40 80 ff 02          	cmp    $0x2,%dil
    68a3:	74 2b                	je     68d0 <fwp_rc_fresh+0x70>
    68a5:	40 80 ff 01          	cmp    $0x1,%dil
    68a9:	75 21                	jne    68cc <fwp_rc_fresh+0x6c>
    68ab:	8b 79 18             	mov    0x18(%rcx),%edi
    68ae:	0f b7 c0             	movzwl %ax,%eax
    68b1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    68b4:	48 0f af c7          	imul   %rdi,%rax
    68b8:	48 c1 e8 20          	shr    $0x20,%rax
    68bc:	48 39 c8             	cmp    %rcx,%rax
    68bf:	73 0b                	jae    68cc <fwp_rc_fresh+0x6c>
    68c1:	48 01 c2             	add    %rax,%rdx
    68c4:	80 3a ff             	cmpb   $0xff,(%rdx)
    68c7:	74 17                	je     68e0 <fwp_rc_fresh+0x80>
    68c9:	c6 02 01             	movb   $0x1,(%rdx)
    68cc:	48 89 f0             	mov    %rsi,%rax
    68cf:	c3                   	ret
    68d0:	66 85 c0             	test   %ax,%ax
    68d3:	74 ef                	je     68c4 <fwp_rc_fresh+0x64>
    68d5:	48 89 f0             	mov    %rsi,%rax
    68d8:	c3                   	ret
    68d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    68e0:	48 83 ec 18          	sub    $0x18,%rsp
    68e4:	48 89 d7             	mov    %rdx,%rdi
    68e7:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    68ec:	48 89 14 24          	mov    %rdx,(%rsp)
    68f0:	e8 db ee ff ff       	call   57d0 <fwp_rc_forget_slot>
    68f5:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    68fa:	48 8b 14 24          	mov    (%rsp),%rdx
    68fe:	48 89 f0             	mov    %rsi,%rax
    6901:	c6 02 01             	movb   $0x1,(%rdx)
    6904:	48 83 c4 18          	add    $0x18,%rsp
    6908:	c3                   	ret
    6909:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006910 <fwp_rc_free_obj>:
    6910:	48 8b 15 e1 62 06 00 	mov    0x662e1(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    6917:	48 89 f8             	mov    %rdi,%rax
    691a:	48 2b 05 af 62 06 00 	sub    0x662af(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    6921:	48 c1 e2 10          	shl    $0x10,%rdx
    6925:	48 39 d0             	cmp    %rdx,%rax
    6928:	73 5b                	jae    6985 <fwp_rc_free_obj+0x75>
    692a:	48 89 c2             	mov    %rax,%rdx
    692d:	48 c1 ea 10          	shr    $0x10,%rdx
    6931:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6935:	48 8b 15 dc 62 06 00 	mov    0x662dc(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    693c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6940:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6944:	48 85 c9             	test   %rcx,%rcx
    6947:	74 3c                	je     6985 <fwp_rc_free_obj+0x75>
    6949:	0f b6 32             	movzbl (%rdx),%esi
    694c:	40 80 fe 02          	cmp    $0x2,%sil
    6950:	74 2e                	je     6980 <fwp_rc_free_obj+0x70>
    6952:	40 80 fe 01          	cmp    $0x1,%sil
    6956:	75 2d                	jne    6985 <fwp_rc_free_obj+0x75>
    6958:	8b 72 18             	mov    0x18(%rdx),%esi
    695b:	0f b7 c0             	movzwl %ax,%eax
    695e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6961:	48 0f af c6          	imul   %rsi,%rax
    6965:	48 c1 e8 20          	shr    $0x20,%rax
    6969:	48 39 d0             	cmp    %rdx,%rax
    696c:	73 17                	jae    6985 <fwp_rc_free_obj+0x75>
    696e:	48 01 c1             	add    %rax,%rcx
    6971:	80 39 01             	cmpb   $0x1,(%rcx)
    6974:	75 0f                	jne    6985 <fwp_rc_free_obj+0x75>
    6976:	e9 95 f0 ff ff       	jmp    5a10 <fwp_mem_free>
    697b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6980:	66 85 c0             	test   %ax,%ax
    6983:	74 ec                	je     6971 <fwp_rc_free_obj+0x61>
    6985:	c3                   	ret
    6986:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    698d:	00 00 00 

0000000000006990 <fwp_rc_dup>:
    6990:	f3 0f 1e fa          	endbr64
    6994:	48 8b 05 5d 62 06 00 	mov    0x6625d(%rip),%rax        # 6cbf8 <fwp_heap+0x13d8>
    699b:	48 2b 3d 2e 62 06 00 	sub    0x6622e(%rip),%rdi        # 6cbd0 <fwp_heap+0x13b0>
    69a2:	48 c1 e0 10          	shl    $0x10,%rax
    69a6:	48 39 c7             	cmp    %rax,%rdi
    69a9:	73 60                	jae    6a0b <fwp_rc_dup+0x7b>
    69ab:	48 89 f8             	mov    %rdi,%rax
    69ae:	48 c1 e8 10          	shr    $0x10,%rax
    69b2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    69b6:	48 8b 05 5b 62 06 00 	mov    0x6625b(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    69bd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    69c1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    69c5:	48 85 c0             	test   %rax,%rax
    69c8:	74 41                	je     6a0b <fwp_rc_dup+0x7b>
    69ca:	0f b6 0a             	movzbl (%rdx),%ecx
    69cd:	80 f9 02             	cmp    $0x2,%cl
    69d0:	74 3e                	je     6a10 <fwp_rc_dup+0x80>
    69d2:	80 f9 01             	cmp    $0x1,%cl
    69d5:	75 34                	jne    6a0b <fwp_rc_dup+0x7b>
    69d7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    69da:	0f b7 ff             	movzwl %di,%edi
    69dd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    69e0:	48 0f af f9          	imul   %rcx,%rdi
    69e4:	48 c1 ef 20          	shr    $0x20,%rdi
    69e8:	48 39 d7             	cmp    %rdx,%rdi
    69eb:	73 1e                	jae    6a0b <fwp_rc_dup+0x7b>
    69ed:	48 01 f8             	add    %rdi,%rax
    69f0:	0f b6 10             	movzbl (%rax),%edx
    69f3:	84 d2                	test   %dl,%dl
    69f5:	74 14                	je     6a0b <fwp_rc_dup+0x7b>
    69f7:	8b 0d eb 6a 06 00    	mov    0x66aeb(%rip),%ecx        # 6d4e8 <iteration_active>
    69fd:	85 c9                	test   %ecx,%ecx
    69ff:	75 1f                	jne    6a20 <fwp_rc_dup+0x90>
    6a01:	80 fa fd             	cmp    $0xfd,%dl
    6a04:	77 2a                	ja     6a30 <fwp_rc_dup+0xa0>
    6a06:	83 c2 01             	add    $0x1,%edx
    6a09:	88 10                	mov    %dl,(%rax)
    6a0b:	c3                   	ret
    6a0c:	0f 1f 40 00          	nopl   0x0(%rax)
    6a10:	66 85 ff             	test   %di,%di
    6a13:	74 db                	je     69f0 <fwp_rc_dup+0x60>
    6a15:	c3                   	ret
    6a16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a1d:	00 00 00 
    6a20:	48 83 05 a8 6a 06 00 	addq   $0x1,0x66aa8(%rip)        # 6d4d0 <iteration_retains>
    6a27:	01 
    6a28:	eb d7                	jmp    6a01 <fwp_rc_dup+0x71>
    6a2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a30:	48 89 c7             	mov    %rax,%rdi
    6a33:	e9 78 ec ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    6a38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6a3f:	00 

0000000000006a40 <fwp_owned_entry173>:
    6a40:	f3 0f 1e fa          	endbr64
    6a44:	48 83 ec 38          	sub    $0x38,%rsp
    6a48:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6a4d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6a54:	00 00 
    6a56:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6a5b:	31 c0                	xor    %eax,%eax
    6a5d:	48 8b 07             	mov    (%rdi),%rax
    6a60:	48 03 47 10          	add    0x10(%rdi),%rax
    6a64:	0f 80 c2 00 00 00    	jo     6b2c <fwp_owned_entry173+0xec>
    6a6a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6a6f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6a74:	31 ff                	xor    %edi,%edi
    6a76:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6a7a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6a7f:	e8 7c f6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    6a84:	48 8b 15 6d 61 06 00 	mov    0x6616d(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    6a8b:	48 89 c6             	mov    %rax,%rsi
    6a8e:	48 2b 05 3b 61 06 00 	sub    0x6613b(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    6a95:	48 c1 e2 10          	shl    $0x10,%rdx
    6a99:	48 39 d0             	cmp    %rdx,%rax
    6a9c:	73 4f                	jae    6aed <fwp_owned_entry173+0xad>
    6a9e:	48 89 c2             	mov    %rax,%rdx
    6aa1:	48 c1 ea 10          	shr    $0x10,%rdx
    6aa5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6aa9:	48 8b 15 68 61 06 00 	mov    0x66168(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    6ab0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ab4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ab8:	48 85 d2             	test   %rdx,%rdx
    6abb:	74 30                	je     6aed <fwp_owned_entry173+0xad>
    6abd:	0f b6 39             	movzbl (%rcx),%edi
    6ac0:	40 80 ff 02          	cmp    $0x2,%dil
    6ac4:	74 42                	je     6b08 <fwp_owned_entry173+0xc8>
    6ac6:	40 80 ff 01          	cmp    $0x1,%dil
    6aca:	75 21                	jne    6aed <fwp_owned_entry173+0xad>
    6acc:	8b 79 18             	mov    0x18(%rcx),%edi
    6acf:	0f b7 c0             	movzwl %ax,%eax
    6ad2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ad5:	48 0f af c7          	imul   %rdi,%rax
    6ad9:	48 c1 e8 20          	shr    $0x20,%rax
    6add:	48 39 c8             	cmp    %rcx,%rax
    6ae0:	73 0b                	jae    6aed <fwp_owned_entry173+0xad>
    6ae2:	48 01 c2             	add    %rax,%rdx
    6ae5:	80 3a ff             	cmpb   $0xff,(%rdx)
    6ae8:	74 26                	je     6b10 <fwp_owned_entry173+0xd0>
    6aea:	c6 02 01             	movb   $0x1,(%rdx)
    6aed:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6af2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6af9:	00 00 
    6afb:	75 34                	jne    6b31 <fwp_owned_entry173+0xf1>
    6afd:	48 89 f0             	mov    %rsi,%rax
    6b00:	48 83 c4 38          	add    $0x38,%rsp
    6b04:	c3                   	ret
    6b05:	0f 1f 00             	nopl   (%rax)
    6b08:	66 85 c0             	test   %ax,%ax
    6b0b:	75 e0                	jne    6aed <fwp_owned_entry173+0xad>
    6b0d:	eb d6                	jmp    6ae5 <fwp_owned_entry173+0xa5>
    6b0f:	90                   	nop
    6b10:	48 89 d7             	mov    %rdx,%rdi
    6b13:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6b18:	48 89 14 24          	mov    %rdx,(%rsp)
    6b1c:	e8 af ec ff ff       	call   57d0 <fwp_rc_forget_slot>
    6b21:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6b26:	48 8b 14 24          	mov    (%rsp),%rdx
    6b2a:	eb be                	jmp    6aea <fwp_owned_entry173+0xaa>
    6b2c:	e8 cf cb ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6b31:	e8 1a c9 ff ff       	call   3450 <__stack_chk_fail@plt>
    6b36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b3d:	00 00 00 

0000000000006b40 <e173>:
    6b40:	f3 0f 1e fa          	endbr64
    6b44:	53                   	push   %rbx
    6b45:	48 83 ec 30          	sub    $0x30,%rsp
    6b49:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6b4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6b55:	00 00 
    6b57:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6b5c:	31 c0                	xor    %eax,%eax
    6b5e:	48 8b 07             	mov    (%rdi),%rax
    6b61:	48 03 47 10          	add    0x10(%rdi),%rax
    6b65:	0f 80 c9 00 00 00    	jo     6c34 <e173+0xf4>
    6b6b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6b70:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6b75:	31 ff                	xor    %edi,%edi
    6b77:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6b7b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6b80:	e8 7b f5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    6b85:	48 8b 15 6c 60 06 00 	mov    0x6606c(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    6b8c:	48 89 c3             	mov    %rax,%rbx
    6b8f:	48 2b 05 3a 60 06 00 	sub    0x6603a(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    6b96:	48 c1 e2 10          	shl    $0x10,%rdx
    6b9a:	48 39 d0             	cmp    %rdx,%rax
    6b9d:	73 4f                	jae    6bee <e173+0xae>
    6b9f:	48 89 c2             	mov    %rax,%rdx
    6ba2:	48 c1 ea 10          	shr    $0x10,%rdx
    6ba6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6baa:	48 8b 15 67 60 06 00 	mov    0x66067(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    6bb1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6bb5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6bb9:	48 85 d2             	test   %rdx,%rdx
    6bbc:	74 30                	je     6bee <e173+0xae>
    6bbe:	0f b6 31             	movzbl (%rcx),%esi
    6bc1:	40 80 fe 02          	cmp    $0x2,%sil
    6bc5:	74 49                	je     6c10 <e173+0xd0>
    6bc7:	40 80 fe 01          	cmp    $0x1,%sil
    6bcb:	75 21                	jne    6bee <e173+0xae>
    6bcd:	8b 71 18             	mov    0x18(%rcx),%esi
    6bd0:	0f b7 c0             	movzwl %ax,%eax
    6bd3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6bd6:	48 0f af c6          	imul   %rsi,%rax
    6bda:	48 c1 e8 20          	shr    $0x20,%rax
    6bde:	48 39 c8             	cmp    %rcx,%rax
    6be1:	73 0b                	jae    6bee <e173+0xae>
    6be3:	48 01 c2             	add    %rax,%rdx
    6be6:	80 3a ff             	cmpb   $0xff,(%rdx)
    6be9:	74 35                	je     6c20 <e173+0xe0>
    6beb:	c6 02 01             	movb   $0x1,(%rdx)
    6bee:	48 89 df             	mov    %rbx,%rdi
    6bf1:	e8 ea fb ff ff       	call   67e0 <fwp_rc_share>
    6bf6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6bfb:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6c02:	00 00 
    6c04:	75 33                	jne    6c39 <e173+0xf9>
    6c06:	48 83 c4 30          	add    $0x30,%rsp
    6c0a:	48 89 d8             	mov    %rbx,%rax
    6c0d:	5b                   	pop    %rbx
    6c0e:	c3                   	ret
    6c0f:	90                   	nop
    6c10:	66 85 c0             	test   %ax,%ax
    6c13:	75 d9                	jne    6bee <e173+0xae>
    6c15:	eb cf                	jmp    6be6 <e173+0xa6>
    6c17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c1e:	00 00 
    6c20:	48 89 d7             	mov    %rdx,%rdi
    6c23:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6c28:	e8 a3 eb ff ff       	call   57d0 <fwp_rc_forget_slot>
    6c2d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6c32:	eb b7                	jmp    6beb <e173+0xab>
    6c34:	e8 c7 ca ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6c39:	e8 12 c8 ff ff       	call   3450 <__stack_chk_fail@plt>
    6c3e:	66 90                	xchg   %ax,%ax

0000000000006c40 <fwp_closure_drop>:
    6c40:	48 8b 15 b1 5f 06 00 	mov    0x65fb1(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    6c47:	48 89 f8             	mov    %rdi,%rax
    6c4a:	48 2b 05 7f 5f 06 00 	sub    0x65f7f(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    6c51:	48 c1 e2 10          	shl    $0x10,%rdx
    6c55:	48 39 d0             	cmp    %rdx,%rax
    6c58:	73 6b                	jae    6cc5 <fwp_closure_drop+0x85>
    6c5a:	48 89 c2             	mov    %rax,%rdx
    6c5d:	48 c1 ea 10          	shr    $0x10,%rdx
    6c61:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c65:	48 8b 15 ac 5f 06 00 	mov    0x65fac(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    6c6c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c70:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c74:	48 85 d2             	test   %rdx,%rdx
    6c77:	74 4c                	je     6cc5 <fwp_closure_drop+0x85>
    6c79:	0f b6 31             	movzbl (%rcx),%esi
    6c7c:	40 80 fe 02          	cmp    $0x2,%sil
    6c80:	74 3e                	je     6cc0 <fwp_closure_drop+0x80>
    6c82:	40 80 fe 01          	cmp    $0x1,%sil
    6c86:	75 3d                	jne    6cc5 <fwp_closure_drop+0x85>
    6c88:	8b 71 18             	mov    0x18(%rcx),%esi
    6c8b:	0f b7 c0             	movzwl %ax,%eax
    6c8e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c91:	48 0f af c6          	imul   %rsi,%rax
    6c95:	48 c1 e8 20          	shr    $0x20,%rax
    6c99:	48 39 c8             	cmp    %rcx,%rax
    6c9c:	73 27                	jae    6cc5 <fwp_closure_drop+0x85>
    6c9e:	48 01 c2             	add    %rax,%rdx
    6ca1:	0f b6 02             	movzbl (%rdx),%eax
    6ca4:	84 c0                	test   %al,%al
    6ca6:	74 1d                	je     6cc5 <fwp_closure_drop+0x85>
    6ca8:	3c 01                	cmp    $0x1,%al
    6caa:	74 24                	je     6cd0 <fwp_closure_drop+0x90>
    6cac:	3c ff                	cmp    $0xff,%al
    6cae:	74 48                	je     6cf8 <fwp_closure_drop+0xb8>
    6cb0:	83 e8 01             	sub    $0x1,%eax
    6cb3:	88 02                	mov    %al,(%rdx)
    6cb5:	c3                   	ret
    6cb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6cbd:	00 00 00 
    6cc0:	66 85 c0             	test   %ax,%ax
    6cc3:	74 dc                	je     6ca1 <fwp_closure_drop+0x61>
    6cc5:	c3                   	ret
    6cc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6ccd:	00 00 00 
    6cd0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6cd7:	ff ff 
    6cd9:	48 85 c0             	test   %rax,%rax
    6cdc:	74 12                	je     6cf0 <fwp_closure_drop+0xb0>
    6cde:	48 89 fe             	mov    %rdi,%rsi
    6ce1:	48 89 c7             	mov    %rax,%rdi
    6ce4:	e9 c7 d7 ff ff       	jmp    44b0 <fwp_closure_drop_push>
    6ce9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6cf0:	e9 6b d9 ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    6cf5:	0f 1f 00             	nopl   (%rax)
    6cf8:	48 89 d0             	mov    %rdx,%rax
    6cfb:	48 8d 35 1e 4b 06 00 	lea    0x64b1e(%rip),%rsi        # 6b820 <fwp_heap>
    6d02:	48 83 ec 18          	sub    $0x18,%rsp
    6d06:	48 c1 e8 11          	shr    $0x11,%rax
    6d0a:	48 31 d0             	xor    %rdx,%rax
    6d0d:	48 89 c1             	mov    %rax,%rcx
    6d10:	48 c1 e9 09          	shr    $0x9,%rcx
    6d14:	48 31 c8             	xor    %rcx,%rax
    6d17:	0f b6 c8             	movzbl %al,%ecx
    6d1a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6d21:	00 
    6d22:	48 85 c0             	test   %rax,%rax
    6d25:	75 22                	jne    6d49 <fwp_closure_drop+0x109>
    6d27:	eb 59                	jmp    6d82 <fwp_closure_drop+0x142>
    6d29:	90                   	nop
    6d2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d31:	00 00 00 00 
    6d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d3c:	00 00 00 00 
    6d40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6d44:	48 85 c0             	test   %rax,%rax
    6d47:	74 39                	je     6d82 <fwp_closure_drop+0x142>
    6d49:	48 89 c1             	mov    %rax,%rcx
    6d4c:	48 39 10             	cmp    %rdx,(%rax)
    6d4f:	75 ef                	jne    6d40 <fwp_closure_drop+0x100>
    6d51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6d55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6d59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6d5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6d64:	74 05                	je     6d6b <fwp_closure_drop+0x12b>
    6d66:	48 83 c4 18          	add    $0x18,%rsp
    6d6a:	c3                   	ret
    6d6b:	48 89 d7             	mov    %rdx,%rdi
    6d6e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6d73:	e8 58 ea ff ff       	call   57d0 <fwp_rc_forget_slot>
    6d78:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6d7d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6d80:	eb e4                	jmp    6d66 <fwp_closure_drop+0x126>
    6d82:	48 8d 3d 67 8c 00 00 	lea    0x8c67(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    6d89:	e8 c2 d6 ff ff       	call   4450 <fwp_trap>
    6d8e:	66 90                	xchg   %ax,%ax

0000000000006d90 <fwp_owned_tape_release>:
    6d90:	48 85 ff             	test   %rdi,%rdi
    6d93:	0f 84 f7 00 00 00    	je     6e90 <fwp_owned_tape_release+0x100>
    6d99:	41 54                	push   %r12
    6d9b:	55                   	push   %rbp
    6d9c:	53                   	push   %rbx
    6d9d:	48 8b 07             	mov    (%rdi),%rax
    6da0:	48 85 c0             	test   %rax,%rax
    6da3:	74 08                	je     6dad <fwp_owned_tape_release+0x1d>
    6da5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6da9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6dad:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6db1:	48 85 d2             	test   %rdx,%rdx
    6db4:	74 03                	je     6db9 <fwp_owned_tape_release+0x29>
    6db6:	48 89 02             	mov    %rax,(%rdx)
    6db9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6dbd:	48 89 fb             	mov    %rdi,%rbx
    6dc0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6dc4:	48 85 c0             	test   %rax,%rax
    6dc7:	0f 84 89 00 00 00    	je     6e56 <fwp_owned_tape_release+0xc6>
    6dcd:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6dd1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6dd5:	7e 47                	jle    6e1e <fwp_owned_tape_release+0x8e>
    6dd7:	31 ed                	xor    %ebp,%ebp
    6dd9:	eb 0d                	jmp    6de8 <fwp_owned_tape_release+0x58>
    6ddb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6de0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6de4:	48 8b 40 68          	mov    0x68(%rax),%rax
    6de8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6dec:	49 89 ec             	mov    %rbp,%r12
    6def:	48 83 c5 01          	add    $0x1,%rbp
    6df3:	49 c1 e4 04          	shl    $0x4,%r12
    6df7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6dfb:	ff d0                	call   *%rax
    6dfd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6e01:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6e06:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6e0a:	ff 50 68             	call   *0x68(%rax)
    6e0d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6e11:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6e15:	48 39 e8             	cmp    %rbp,%rax
    6e18:	7f c6                	jg     6de0 <fwp_owned_tape_release+0x50>
    6e1a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6e1e:	31 ed                	xor    %ebp,%ebp
    6e20:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6e25:	7e 28                	jle    6e4f <fwp_owned_tape_release+0xbf>
    6e27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6e2e:	00 00 
    6e30:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6e34:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6e38:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6e3c:	74 07                	je     6e45 <fwp_owned_tape_release+0xb5>
    6e3e:	ff 52 68             	call   *0x68(%rdx)
    6e41:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6e45:	48 83 c5 01          	add    $0x1,%rbp
    6e49:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6e4d:	7f e1                	jg     6e30 <fwp_owned_tape_release+0xa0>
    6e4f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6e53:	ff 52 68             	call   *0x68(%rdx)
    6e56:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6e5a:	e8 e1 fd ff ff       	call   6c40 <fwp_closure_drop>
    6e5f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6e63:	e8 d8 fd ff ff       	call   6c40 <fwp_closure_drop>
    6e68:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6e6c:	e8 cf fd ff ff       	call   6c40 <fwp_closure_drop>
    6e71:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6e75:	e8 96 eb ff ff       	call   5a10 <fwp_mem_free>
    6e7a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6e7e:	e8 8d eb ff ff       	call   5a10 <fwp_mem_free>
    6e83:	48 89 df             	mov    %rbx,%rdi
    6e86:	5b                   	pop    %rbx
    6e87:	5d                   	pop    %rbp
    6e88:	41 5c                	pop    %r12
    6e8a:	e9 81 eb ff ff       	jmp    5a10 <fwp_mem_free>
    6e8f:	90                   	nop
    6e90:	c3                   	ret
    6e91:	0f 1f 40 00          	nopl   0x0(%rax)
    6e95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e9c:	00 00 00 00 

0000000000006ea0 <fwp_tape_finish>:
    6ea0:	f3 0f 1e fa          	endbr64
    6ea4:	41 55                	push   %r13
    6ea6:	41 54                	push   %r12
    6ea8:	55                   	push   %rbp
    6ea9:	53                   	push   %rbx
    6eaa:	48 83 ec 48          	sub    $0x48,%rsp
    6eae:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    6eb5:	00 00 
    6eb7:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    6ebc:	48 8d 3d dd c1 01 00 	lea    0x1c1dd(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    6ec3:	e8 78 e2 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    6ec8:	48 83 3d 18 c2 01 00 	cmpq   $0x0,0x1c218(%rip)        # 230e8 <fwp_ntapes>
    6ecf:	00 
    6ed0:	48 c7 05 ad c1 01 00 	movq   $0x0,0x1c1ad(%rip)        # 23088 <fwp_tape_cached_bytes>
    6ed7:	00 00 00 00 
    6edb:	7e 79                	jle    6f56 <fwp_tape_finish+0xb6>
    6edd:	45 31 e4             	xor    %r12d,%r12d
    6ee0:	31 ed                	xor    %ebp,%ebp
    6ee2:	0f 1f 00             	nopl   (%rax)
    6ee5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6eec:	00 00 00 00 
    6ef0:	48 8b 1d f9 c1 01 00 	mov    0x1c1f9(%rip),%rbx        # 230f0 <fwp_tapes>
    6ef7:	48 83 c5 01          	add    $0x1,%rbp
    6efb:	4c 01 e3             	add    %r12,%rbx
    6efe:	49 83 c4 68          	add    $0x68,%r12
    6f02:	48 89 df             	mov    %rbx,%rdi
    6f05:	e8 86 cd ff ff       	call   3c90 <fwp_tape_unlink_scope>
    6f0a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    6f0f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    6f14:	48 89 e7             	mov    %rsp,%rdi
    6f17:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6f1b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    6f1f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6f24:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6f29:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    6f2e:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    6f32:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    6f37:	e8 04 e2 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    6f3c:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6f40:	e8 4b fe ff ff       	call   6d90 <fwp_owned_tape_release>
    6f45:	48 39 2d 9c c1 01 00 	cmp    %rbp,0x1c19c(%rip)        # 230e8 <fwp_ntapes>
    6f4c:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6f53:	00 
    6f54:	7f 9a                	jg     6ef0 <fwp_tape_finish+0x50>
    6f56:	48 8b 3d 93 c1 01 00 	mov    0x1c193(%rip),%rdi        # 230f0 <fwp_tapes>
    6f5d:	48 85 ff             	test   %rdi,%rdi
    6f60:	74 05                	je     6f67 <fwp_tape_finish+0xc7>
    6f62:	e8 69 e1 ff ff       	call   50d0 <ad_raw_free.part.0>
    6f67:	48 c7 05 7e c1 01 00 	movq   $0x0,0x1c17e(%rip)        # 230f0 <fwp_tapes>
    6f6e:	00 00 00 00 
    6f72:	48 c7 05 63 c1 01 00 	movq   $0x0,0x1c163(%rip)        # 230e0 <fwp_tapes_cap>
    6f79:	00 00 00 00 
    6f7d:	48 c7 05 60 c1 01 00 	movq   $0x0,0x1c160(%rip)        # 230e8 <fwp_ntapes>
    6f84:	00 00 00 00 
    6f88:	48 c7 05 45 c1 01 00 	movq   $0x0,0x1c145(%rip)        # 230d8 <fwp_tape_next_slot>
    6f8f:	00 00 00 00 
    6f93:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    6f98:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6f9f:	00 00 
    6fa1:	75 0b                	jne    6fae <fwp_tape_finish+0x10e>
    6fa3:	48 83 c4 48          	add    $0x48,%rsp
    6fa7:	5b                   	pop    %rbx
    6fa8:	5d                   	pop    %rbp
    6fa9:	41 5c                	pop    %r12
    6fab:	41 5d                	pop    %r13
    6fad:	c3                   	ret
    6fae:	e8 9d c4 ff ff       	call   3450 <__stack_chk_fail@plt>
    6fb3:	66 90                	xchg   %ax,%ax
    6fb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6fbc:	00 00 00 00 

0000000000006fc0 <fwp_tape_scope_release>:
    6fc0:	f3 0f 1e fa          	endbr64
    6fc4:	41 55                	push   %r13
    6fc6:	41 54                	push   %r12
    6fc8:	55                   	push   %rbp
    6fc9:	53                   	push   %rbx
    6fca:	48 83 ec 48          	sub    $0x48,%rsp
    6fce:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6fd5:	00 00 
    6fd7:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    6fdc:	48 63 07             	movslq (%rdi),%rax
    6fdf:	85 c0                	test   %eax,%eax
    6fe1:	0f 88 e8 00 00 00    	js     70cf <fwp_tape_scope_release+0x10f>
    6fe7:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    6fee:	ec c4 4e 
    6ff1:	48 89 fb             	mov    %rdi,%rbx
    6ff4:	48 89 e5             	mov    %rsp,%rbp
    6ff7:	eb 1f                	jmp    7018 <fwp_tape_scope_release+0x58>
    6ff9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7000:	e8 3b e1 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7005:	4c 89 ef             	mov    %r13,%rdi
    7008:	e8 83 fd ff ff       	call   6d90 <fwp_owned_tape_release>
    700d:	48 63 03             	movslq (%rbx),%rax
    7010:	85 c0                	test   %eax,%eax
    7012:	0f 88 b7 00 00 00    	js     70cf <fwp_tape_scope_release+0x10f>
    7018:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    701c:	48 8b 35 cd c0 01 00 	mov    0x1c0cd(%rip),%rsi        # 230f0 <fwp_tapes>
    7023:	4c 01 c6             	add    %r8,%rsi
    7026:	48 89 f7             	mov    %rsi,%rdi
    7029:	e8 62 cc ff ff       	call   3c90 <fwp_tape_unlink_scope>
    702e:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7033:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    7038:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    703f:	48 8b 46 40          	mov    0x40(%rsi),%rax
    7043:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    7047:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    704e:	00 
    704f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7054:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    7059:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    705d:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7062:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7066:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    706b:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7072:	00 
    7073:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    707a:	00 
    707b:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7082:	00 
    7083:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    7087:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    708b:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    708f:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    7093:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7099:	77 18                	ja     70b3 <fwp_tape_scope_release+0xf3>
    709b:	49 c1 f8 03          	sar    $0x3,%r8
    709f:	4d 0f af c4          	imul   %r12,%r8
    70a3:	4c 3b 05 2e c0 01 00 	cmp    0x1c02e(%rip),%r8        # 230d8 <fwp_tape_next_slot>
    70aa:	7d 07                	jge    70b3 <fwp_tape_scope_release+0xf3>
    70ac:	4c 89 05 25 c0 01 00 	mov    %r8,0x1c025(%rip)        # 230d8 <fwp_tape_next_slot>
    70b3:	48 89 ef             	mov    %rbp,%rdi
    70b6:	4d 85 ed             	test   %r13,%r13
    70b9:	0f 85 41 ff ff ff    	jne    7000 <fwp_tape_scope_release+0x40>
    70bf:	e8 9c e1 ff ff       	call   5260 <fwp_tape_buffers_release>
    70c4:	48 63 03             	movslq (%rbx),%rax
    70c7:	85 c0                	test   %eax,%eax
    70c9:	0f 89 49 ff ff ff    	jns    7018 <fwp_tape_scope_release+0x58>
    70cf:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    70d4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    70db:	00 00 
    70dd:	75 0b                	jne    70ea <fwp_tape_scope_release+0x12a>
    70df:	48 83 c4 48          	add    $0x48,%rsp
    70e3:	5b                   	pop    %rbx
    70e4:	5d                   	pop    %rbp
    70e5:	41 5c                	pop    %r12
    70e7:	41 5d                	pop    %r13
    70e9:	c3                   	ret
    70ea:	e8 61 c3 ff ff       	call   3450 <__stack_chk_fail@plt>
    70ef:	90                   	nop

00000000000070f0 <fwp_drop4>:
    70f0:	48 8b 0d 01 5b 06 00 	mov    0x65b01(%rip),%rcx        # 6cbf8 <fwp_heap+0x13d8>
    70f7:	48 89 f8             	mov    %rdi,%rax
    70fa:	48 2b 05 cf 5a 06 00 	sub    0x65acf(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7101:	48 c1 e1 10          	shl    $0x10,%rcx
    7105:	48 39 c8             	cmp    %rcx,%rax
    7108:	0f 83 42 01 00 00    	jae    7250 <fwp_drop4+0x160>
    710e:	48 83 ec 18          	sub    $0x18,%rsp
    7112:	48 89 fa             	mov    %rdi,%rdx
    7115:	4c 8d 05 04 47 06 00 	lea    0x64704(%rip),%r8        # 6b820 <fwp_heap>
    711c:	48 89 c1             	mov    %rax,%rcx
    711f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7126:	48 c1 e9 10          	shr    $0x10,%rcx
    712a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    712e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7132:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7136:	48 85 c9             	test   %rcx,%rcx
    7139:	74 40                	je     717b <fwp_drop4+0x8b>
    713b:	0f b6 3e             	movzbl (%rsi),%edi
    713e:	40 80 ff 02          	cmp    $0x2,%dil
    7142:	74 3c                	je     7180 <fwp_drop4+0x90>
    7144:	40 80 ff 01          	cmp    $0x1,%dil
    7148:	75 31                	jne    717b <fwp_drop4+0x8b>
    714a:	8b 7e 18             	mov    0x18(%rsi),%edi
    714d:	0f b7 c0             	movzwl %ax,%eax
    7150:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7153:	48 0f af c7          	imul   %rdi,%rax
    7157:	48 c1 e8 20          	shr    $0x20,%rax
    715b:	48 39 f0             	cmp    %rsi,%rax
    715e:	73 1b                	jae    717b <fwp_drop4+0x8b>
    7160:	48 01 c1             	add    %rax,%rcx
    7163:	0f b6 01             	movzbl (%rcx),%eax
    7166:	84 c0                	test   %al,%al
    7168:	74 11                	je     717b <fwp_drop4+0x8b>
    716a:	3c 01                	cmp    $0x1,%al
    716c:	74 22                	je     7190 <fwp_drop4+0xa0>
    716e:	3c ff                	cmp    $0xff,%al
    7170:	0f 84 0a 01 00 00    	je     7280 <fwp_drop4+0x190>
    7176:	83 e8 01             	sub    $0x1,%eax
    7179:	88 01                	mov    %al,(%rcx)
    717b:	48 83 c4 18          	add    $0x18,%rsp
    717f:	c3                   	ret
    7180:	66 85 c0             	test   %ax,%ax
    7183:	74 de                	je     7163 <fwp_drop4+0x73>
    7185:	48 83 c4 18          	add    $0x18,%rsp
    7189:	c3                   	ret
    718a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7190:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7194:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    719b:	48 89 f8             	mov    %rdi,%rax
    719e:	48 c1 e1 10          	shl    $0x10,%rcx
    71a2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    71a9:	48 39 c8             	cmp    %rcx,%rax
    71ac:	73 62                	jae    7210 <fwp_drop4+0x120>
    71ae:	48 89 c1             	mov    %rax,%rcx
    71b1:	48 c1 e9 10          	shr    $0x10,%rcx
    71b5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    71b9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    71bd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    71c1:	48 85 c9             	test   %rcx,%rcx
    71c4:	74 4a                	je     7210 <fwp_drop4+0x120>
    71c6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    71ca:	41 80 f9 02          	cmp    $0x2,%r9b
    71ce:	0f 84 9c 00 00 00    	je     7270 <fwp_drop4+0x180>
    71d4:	41 80 f9 01          	cmp    $0x1,%r9b
    71d8:	75 36                	jne    7210 <fwp_drop4+0x120>
    71da:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    71de:	0f b7 c0             	movzwl %ax,%eax
    71e1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    71e4:	49 0f af c1          	imul   %r9,%rax
    71e8:	48 c1 e8 20          	shr    $0x20,%rax
    71ec:	48 39 f0             	cmp    %rsi,%rax
    71ef:	73 1f                	jae    7210 <fwp_drop4+0x120>
    71f1:	48 01 c1             	add    %rax,%rcx
    71f4:	0f b6 01             	movzbl (%rcx),%eax
    71f7:	84 c0                	test   %al,%al
    71f9:	74 15                	je     7210 <fwp_drop4+0x120>
    71fb:	3c 01                	cmp    $0x1,%al
    71fd:	74 59                	je     7258 <fwp_drop4+0x168>
    71ff:	3c ff                	cmp    $0xff,%al
    7201:	0f 84 ff 00 00 00    	je     7306 <fwp_drop4+0x216>
    7207:	83 e8 01             	sub    $0x1,%eax
    720a:	88 01                	mov    %al,(%rcx)
    720c:	0f 1f 40 00          	nopl   0x0(%rax)
    7210:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7214:	48 89 d7             	mov    %rdx,%rdi
    7217:	48 89 0c 24          	mov    %rcx,(%rsp)
    721b:	e8 f0 f6 ff ff       	call   6910 <fwp_rc_free_obj>
    7220:	4c 8d 05 f9 45 06 00 	lea    0x645f9(%rip),%r8        # 6b820 <fwp_heap>
    7227:	48 8b 04 24          	mov    (%rsp),%rax
    722b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7232:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7239:	48 c1 e2 10          	shl    $0x10,%rdx
    723d:	48 39 d0             	cmp    %rdx,%rax
    7240:	0f 83 35 ff ff ff    	jae    717b <fwp_drop4+0x8b>
    7246:	48 8b 14 24          	mov    (%rsp),%rdx
    724a:	e9 cd fe ff ff       	jmp    711c <fwp_drop4+0x2c>
    724f:	90                   	nop
    7250:	c3                   	ret
    7251:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7258:	48 89 14 24          	mov    %rdx,(%rsp)
    725c:	e8 af f6 ff ff       	call   6910 <fwp_rc_free_obj>
    7261:	48 8b 14 24          	mov    (%rsp),%rdx
    7265:	eb a9                	jmp    7210 <fwp_drop4+0x120>
    7267:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    726e:	00 00 
    7270:	66 85 c0             	test   %ax,%ax
    7273:	75 9b                	jne    7210 <fwp_drop4+0x120>
    7275:	e9 7a ff ff ff       	jmp    71f4 <fwp_drop4+0x104>
    727a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7280:	48 89 c8             	mov    %rcx,%rax
    7283:	48 c1 e8 11          	shr    $0x11,%rax
    7287:	48 31 c8             	xor    %rcx,%rax
    728a:	48 89 c2             	mov    %rax,%rdx
    728d:	48 c1 ea 09          	shr    $0x9,%rdx
    7291:	48 31 d0             	xor    %rdx,%rax
    7294:	0f b6 d0             	movzbl %al,%edx
    7297:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    729e:	00 
    729f:	48 85 c0             	test   %rax,%rax
    72a2:	75 29                	jne    72cd <fwp_drop4+0x1dd>
    72a4:	e9 e3 00 00 00       	jmp    738c <fwp_drop4+0x29c>
    72a9:	90                   	nop
    72aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    72b1:	00 00 00 00 
    72b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    72bc:	00 00 00 00 
    72c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    72c4:	48 85 c0             	test   %rax,%rax
    72c7:	0f 84 bf 00 00 00    	je     738c <fwp_drop4+0x29c>
    72cd:	48 89 c2             	mov    %rax,%rdx
    72d0:	48 39 08             	cmp    %rcx,(%rax)
    72d3:	75 eb                	jne    72c0 <fwp_drop4+0x1d0>
    72d5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    72d9:	48 83 ea 01          	sub    $0x1,%rdx
    72dd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    72e1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    72e8:	0f 85 8d fe ff ff    	jne    717b <fwp_drop4+0x8b>
    72ee:	48 89 cf             	mov    %rcx,%rdi
    72f1:	48 89 0c 24          	mov    %rcx,(%rsp)
    72f5:	e8 d6 e4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    72fa:	48 8b 0c 24          	mov    (%rsp),%rcx
    72fe:	c6 01 fe             	movb   $0xfe,(%rcx)
    7301:	e9 75 fe ff ff       	jmp    717b <fwp_drop4+0x8b>
    7306:	48 89 ce             	mov    %rcx,%rsi
    7309:	48 c1 ee 11          	shr    $0x11,%rsi
    730d:	48 31 ce             	xor    %rcx,%rsi
    7310:	48 89 f0             	mov    %rsi,%rax
    7313:	48 c1 e8 09          	shr    $0x9,%rax
    7317:	48 31 c6             	xor    %rax,%rsi
    731a:	40 0f b6 f6          	movzbl %sil,%esi
    731e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7325:	00 
    7326:	48 85 c0             	test   %rax,%rax
    7329:	75 1e                	jne    7349 <fwp_drop4+0x259>
    732b:	eb 5f                	jmp    738c <fwp_drop4+0x29c>
    732d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7334:	00 
    7335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    733c:	00 00 00 00 
    7340:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7344:	48 85 c0             	test   %rax,%rax
    7347:	74 43                	je     738c <fwp_drop4+0x29c>
    7349:	48 89 c6             	mov    %rax,%rsi
    734c:	48 39 08             	cmp    %rcx,(%rax)
    734f:	75 ef                	jne    7340 <fwp_drop4+0x250>
    7351:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7355:	48 83 ee 01          	sub    $0x1,%rsi
    7359:	48 89 70 08          	mov    %rsi,0x8(%rax)
    735d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7364:	0f 85 a6 fe ff ff    	jne    7210 <fwp_drop4+0x120>
    736a:	48 89 cf             	mov    %rcx,%rdi
    736d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7372:	48 89 0c 24          	mov    %rcx,(%rsp)
    7376:	e8 55 e4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    737b:	48 8b 0c 24          	mov    (%rsp),%rcx
    737f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7384:	c6 01 fe             	movb   $0xfe,(%rcx)
    7387:	e9 84 fe ff ff       	jmp    7210 <fwp_drop4+0x120>
    738c:	48 8d 3d 5d 86 00 00 	lea    0x865d(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    7393:	e8 b8 d0 ff ff       	call   4450 <fwp_trap>
    7398:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    739f:	00 

00000000000073a0 <fwp_arg_drop37>:
    73a0:	f3 0f 1e fa          	endbr64
    73a4:	85 f6                	test   %esi,%esi
    73a6:	75 04                	jne    73ac <fwp_arg_drop37+0xc>
    73a8:	85 d2                	test   %edx,%edx
    73aa:	75 04                	jne    73b0 <fwp_arg_drop37+0x10>
    73ac:	c3                   	ret
    73ad:	0f 1f 00             	nopl   (%rax)
    73b0:	48 8b 3f             	mov    (%rdi),%rdi
    73b3:	e9 38 fd ff ff       	jmp    70f0 <fwp_drop4>
    73b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    73bf:	00 

00000000000073c0 <fwp_task_dispose>:
    73c0:	53                   	push   %rbx
    73c1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    73c5:	0f 84 7b c3 ff ff    	je     3746 <fwp_task_dispose.cold>
    73cb:	48 89 fb             	mov    %rdi,%rbx
    73ce:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    73d3:	0f 85 6d c3 ff ff    	jne    3746 <fwp_task_dispose.cold>
    73d9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    73dd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    73e4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    73eb:	00 
    73ec:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    73f0:	48 85 ff             	test   %rdi,%rdi
    73f3:	74 07                	je     73fc <fwp_task_dispose+0x3c>
    73f5:	48 85 c0             	test   %rax,%rax
    73f8:	74 02                	je     73fc <fwp_task_dispose+0x3c>
    73fa:	ff d0                	call   *%rax
    73fc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7403:	e8 08 e6 ff ff       	call   5a10 <fwp_mem_free>
    7408:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    740f:	00 00 00 00 
    7413:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7417:	74 6f                	je     7488 <fwp_task_dispose+0xc8>
    7419:	48 8b 15 d8 57 06 00 	mov    0x657d8(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    7420:	48 89 d8             	mov    %rbx,%rax
    7423:	48 2b 05 a6 57 06 00 	sub    0x657a6(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    742a:	48 c1 e2 10          	shl    $0x10,%rdx
    742e:	48 39 d0             	cmp    %rdx,%rax
    7431:	73 4c                	jae    747f <fwp_task_dispose+0xbf>
    7433:	48 89 c2             	mov    %rax,%rdx
    7436:	48 c1 ea 10          	shr    $0x10,%rdx
    743a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    743e:	48 8b 15 d3 57 06 00 	mov    0x657d3(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    7445:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7449:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    744d:	48 85 c9             	test   %rcx,%rcx
    7450:	74 2d                	je     747f <fwp_task_dispose+0xbf>
    7452:	0f b6 32             	movzbl (%rdx),%esi
    7455:	40 80 fe 02          	cmp    $0x2,%sil
    7459:	74 3d                	je     7498 <fwp_task_dispose+0xd8>
    745b:	40 80 fe 01          	cmp    $0x1,%sil
    745f:	75 1e                	jne    747f <fwp_task_dispose+0xbf>
    7461:	8b 72 18             	mov    0x18(%rdx),%esi
    7464:	0f b7 c0             	movzwl %ax,%eax
    7467:	8b 52 1c             	mov    0x1c(%rdx),%edx
    746a:	48 0f af c6          	imul   %rsi,%rax
    746e:	48 c1 e8 20          	shr    $0x20,%rax
    7472:	48 39 d0             	cmp    %rdx,%rax
    7475:	73 08                	jae    747f <fwp_task_dispose+0xbf>
    7477:	48 01 c1             	add    %rax,%rcx
    747a:	80 39 01             	cmpb   $0x1,(%rcx)
    747d:	74 09                	je     7488 <fwp_task_dispose+0xc8>
    747f:	5b                   	pop    %rbx
    7480:	c3                   	ret
    7481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7488:	48 89 df             	mov    %rbx,%rdi
    748b:	5b                   	pop    %rbx
    748c:	e9 7f e5 ff ff       	jmp    5a10 <fwp_mem_free>
    7491:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7498:	66 85 c0             	test   %ax,%ax
    749b:	74 dd                	je     747a <fwp_task_dispose+0xba>
    749d:	5b                   	pop    %rbx
    749e:	c3                   	ret
    749f:	90                   	nop

00000000000074a0 <fwp_free_zombie>:
    74a0:	48 8b 15 49 43 06 00 	mov    0x64349(%rip),%rdx        # 6b7f0 <fwp_zombie>
    74a7:	48 85 d2             	test   %rdx,%rdx
    74aa:	0f 84 98 00 00 00    	je     7548 <fwp_free_zombie+0xa8>
    74b0:	48 3b 15 49 43 06 00 	cmp    0x64349(%rip),%rdx        # 6b800 <fwp_cur>
    74b7:	0f 84 8b 00 00 00    	je     7548 <fwp_free_zombie+0xa8>
    74bd:	48 83 ec 18          	sub    $0x18,%rsp
    74c1:	48 63 05 0c 3d 06 00 	movslq 0x63d0c(%rip),%rax        # 6b1d4 <fwp_stack_pool_n>
    74c8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    74cc:	83 f8 3f             	cmp    $0x3f,%eax
    74cf:	7f 7f                	jg     7550 <fwp_free_zombie+0xb0>
    74d1:	8d 48 01             	lea    0x1(%rax),%ecx
    74d4:	89 0d fa 3c 06 00    	mov    %ecx,0x63cfa(%rip)        # 6b1d4 <fwp_stack_pool_n>
    74da:	48 8d 0d ff 3c 06 00 	lea    0x63cff(%rip),%rcx        # 6b1e0 <fwp_stack_pool>
    74e1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    74e5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    74ec:	66 0f ef c0          	pxor   %xmm0,%xmm0
    74f0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    74f7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    74fb:	48 85 c9             	test   %rcx,%rcx
    74fe:	0f 84 fc 00 00 00    	je     7600 <fwp_free_zombie+0x160>
    7504:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    750b:	48 85 c0             	test   %rax,%rax
    750e:	74 07                	je     7517 <fwp_free_zombie+0x77>
    7510:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7517:	8b 42 5c             	mov    0x5c(%rdx),%eax
    751a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    751e:	48 c7 05 c7 42 06 00 	movq   $0x0,0x642c7(%rip)        # 6b7f0 <fwp_zombie>
    7525:	00 00 00 00 
    7529:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7530:	85 c0                	test   %eax,%eax
    7532:	74 34                	je     7568 <fwp_free_zombie+0xc8>
    7534:	83 f8 01             	cmp    $0x1,%eax
    7537:	0f 84 b3 00 00 00    	je     75f0 <fwp_free_zombie+0x150>
    753d:	48 83 c4 18          	add    $0x18,%rsp
    7541:	c3                   	ret
    7542:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7548:	c3                   	ret
    7549:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7550:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7554:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7559:	e8 62 c0 ff ff       	call   35c0 <munmap@plt>
    755e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7563:	eb 80                	jmp    74e5 <fwp_free_zombie+0x45>
    7565:	0f 1f 00             	nopl   (%rax)
    7568:	48 8b 0d 89 56 06 00 	mov    0x65689(%rip),%rcx        # 6cbf8 <fwp_heap+0x13d8>
    756f:	48 89 d0             	mov    %rdx,%rax
    7572:	48 2b 05 57 56 06 00 	sub    0x65657(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7579:	48 c1 e1 10          	shl    $0x10,%rcx
    757d:	48 39 c8             	cmp    %rcx,%rax
    7580:	73 bb                	jae    753d <fwp_free_zombie+0x9d>
    7582:	48 89 c1             	mov    %rax,%rcx
    7585:	48 c1 e9 10          	shr    $0x10,%rcx
    7589:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    758d:	48 8b 0d 84 56 06 00 	mov    0x65684(%rip),%rcx        # 6cc18 <fwp_heap+0x13f8>
    7594:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7598:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    759c:	48 85 c9             	test   %rcx,%rcx
    759f:	74 9c                	je     753d <fwp_free_zombie+0x9d>
    75a1:	0f b6 3e             	movzbl (%rsi),%edi
    75a4:	40 80 ff 02          	cmp    $0x2,%dil
    75a8:	74 66                	je     7610 <fwp_free_zombie+0x170>
    75aa:	40 80 ff 01          	cmp    $0x1,%dil
    75ae:	75 8d                	jne    753d <fwp_free_zombie+0x9d>
    75b0:	8b 7e 18             	mov    0x18(%rsi),%edi
    75b3:	0f b7 c0             	movzwl %ax,%eax
    75b6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    75b9:	48 0f af c7          	imul   %rdi,%rax
    75bd:	48 c1 e8 20          	shr    $0x20,%rax
    75c1:	48 39 f0             	cmp    %rsi,%rax
    75c4:	0f 83 73 ff ff ff    	jae    753d <fwp_free_zombie+0x9d>
    75ca:	48 01 c1             	add    %rax,%rcx
    75cd:	0f b6 01             	movzbl (%rcx),%eax
    75d0:	84 c0                	test   %al,%al
    75d2:	0f 84 65 ff ff ff    	je     753d <fwp_free_zombie+0x9d>
    75d8:	3c 01                	cmp    $0x1,%al
    75da:	74 14                	je     75f0 <fwp_free_zombie+0x150>
    75dc:	3c ff                	cmp    $0xff,%al
    75de:	74 3b                	je     761b <fwp_free_zombie+0x17b>
    75e0:	83 e8 01             	sub    $0x1,%eax
    75e3:	88 01                	mov    %al,(%rcx)
    75e5:	e9 53 ff ff ff       	jmp    753d <fwp_free_zombie+0x9d>
    75ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75f0:	48 89 d7             	mov    %rdx,%rdi
    75f3:	48 83 c4 18          	add    $0x18,%rsp
    75f7:	e9 c4 fd ff ff       	jmp    73c0 <fwp_task_dispose>
    75fc:	0f 1f 40 00          	nopl   0x0(%rax)
    7600:	48 89 05 c1 41 06 00 	mov    %rax,0x641c1(%rip)        # 6b7c8 <fwp_tasks_active>
    7607:	e9 ff fe ff ff       	jmp    750b <fwp_free_zombie+0x6b>
    760c:	0f 1f 40 00          	nopl   0x0(%rax)
    7610:	66 85 c0             	test   %ax,%ax
    7613:	0f 85 24 ff ff ff    	jne    753d <fwp_free_zombie+0x9d>
    7619:	eb b2                	jmp    75cd <fwp_free_zombie+0x12d>
    761b:	48 89 ca             	mov    %rcx,%rdx
    761e:	48 8d 35 fb 41 06 00 	lea    0x641fb(%rip),%rsi        # 6b820 <fwp_heap>
    7625:	48 c1 ea 11          	shr    $0x11,%rdx
    7629:	48 31 ca             	xor    %rcx,%rdx
    762c:	48 89 d0             	mov    %rdx,%rax
    762f:	48 c1 e8 09          	shr    $0x9,%rax
    7633:	48 31 c2             	xor    %rax,%rdx
    7636:	0f b6 d2             	movzbl %dl,%edx
    7639:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7640:	00 
    7641:	48 85 c0             	test   %rax,%rax
    7644:	75 23                	jne    7669 <fwp_free_zombie+0x1c9>
    7646:	eb 5c                	jmp    76a4 <fwp_free_zombie+0x204>
    7648:	66 90                	xchg   %ax,%ax
    764a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7651:	00 00 00 00 
    7655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    765c:	00 00 00 00 
    7660:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7664:	48 85 c0             	test   %rax,%rax
    7667:	74 3b                	je     76a4 <fwp_free_zombie+0x204>
    7669:	48 89 c2             	mov    %rax,%rdx
    766c:	48 39 08             	cmp    %rcx,(%rax)
    766f:	75 ef                	jne    7660 <fwp_free_zombie+0x1c0>
    7671:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7675:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7679:	48 89 50 08          	mov    %rdx,0x8(%rax)
    767d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7684:	0f 85 b3 fe ff ff    	jne    753d <fwp_free_zombie+0x9d>
    768a:	48 89 cf             	mov    %rcx,%rdi
    768d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7692:	e8 39 e1 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7697:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    769c:	c6 01 fe             	movb   $0xfe,(%rcx)
    769f:	e9 99 fe ff ff       	jmp    753d <fwp_free_zombie+0x9d>
    76a4:	48 8d 3d 45 83 00 00 	lea    0x8345(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    76ab:	e8 a0 cd ff ff       	call   4450 <fwp_trap>

00000000000076b0 <fwp_block>:
    76b0:	48 83 ec 08          	sub    $0x8,%rsp
    76b4:	48 8b 05 2d 41 06 00 	mov    0x6412d(%rip),%rax        # 6b7e8 <fwp_ready_head>
    76bb:	48 85 c0             	test   %rax,%rax
    76be:	0f 84 1c 01 00 00    	je     77e0 <fwp_block+0x130>
    76c4:	90                   	nop
    76c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    76cc:	00 00 00 00 
    76d0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    76d7:	48 89 15 0a 41 06 00 	mov    %rdx,0x6410a(%rip)        # 6b7e8 <fwp_ready_head>
    76de:	48 85 d2             	test   %rdx,%rdx
    76e1:	0f 84 19 01 00 00    	je     7800 <fwp_block+0x150>
    76e7:	48 8b 15 12 41 06 00 	mov    0x64112(%rip),%rdx        # 6b800 <fwp_cur>
    76ee:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    76f2:	48 39 c2             	cmp    %rax,%rdx
    76f5:	0f 84 d5 00 00 00    	je     77d0 <fwp_block+0x120>
    76fb:	48 8b 0d 86 5d 06 00 	mov    0x65d86(%rip),%rcx        # 6d488 <fwp_state_owners>
    7702:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7706:	48 89 05 f3 40 06 00 	mov    %rax,0x640f3(%rip)        # 6b800 <fwp_cur>
    770d:	f3 0f 7e 05 9b 5d 06 	movq   0x65d9b(%rip),%xmm0        # 6d4b0 <fwp_foreign_callbacks>
    7714:	00 
    7715:	0f 16 05 84 5d 06 00 	movhps 0x65d84(%rip),%xmm0        # 6d4a0 <fwp_state>
    771c:	f3 0f 7e 0d 84 5d 06 	movq   0x65d84(%rip),%xmm1        # 6d4a8 <fwp_handlers>
    7723:	00 
    7724:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    772b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7732:	0f 16 0d 7f 5d 06 00 	movhps 0x65d7f(%rip),%xmm1        # 6d4b8 <fwp_cleanups>
    7739:	f3 0f 7e 05 57 5d 06 	movq   0x65d57(%rip),%xmm0        # 6d498 <fwp_state_len>
    7740:	00 
    7741:	0f 16 05 48 5d 06 00 	movhps 0x65d48(%rip),%xmm0        # 6d490 <fwp_state_cap>
    7748:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    774f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7756:	48 8b 70 08          	mov    0x8(%rax),%rsi
    775a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7761:	48 89 0d 40 5d 06 00 	mov    %rcx,0x65d40(%rip)        # 6d4a8 <fwp_handlers>
    7768:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    776f:	48 89 0d 42 5d 06 00 	mov    %rcx,0x65d42(%rip)        # 6d4b8 <fwp_cleanups>
    7776:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    777d:	48 89 0d 2c 5d 06 00 	mov    %rcx,0x65d2c(%rip)        # 6d4b0 <fwp_foreign_callbacks>
    7784:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    778b:	48 89 0d 0e 5d 06 00 	mov    %rcx,0x65d0e(%rip)        # 6d4a0 <fwp_state>
    7792:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7799:	48 89 0d f8 5c 06 00 	mov    %rcx,0x65cf8(%rip)        # 6d498 <fwp_state_len>
    77a0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    77a7:	48 89 0d e2 5c 06 00 	mov    %rcx,0x65ce2(%rip)        # 6d490 <fwp_state_cap>
    77ae:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    77b5:	48 89 0d cc 5c 06 00 	mov    %rcx,0x65ccc(%rip)        # 6d488 <fwp_state_owners>
    77bc:	e8 bf bc ff ff       	call   3480 <swapcontext@plt>
    77c1:	f3 0f 1e fa          	endbr64
    77c5:	e8 d6 fc ff ff       	call   74a0 <fwp_free_zombie>
    77ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    77d0:	8b 05 fa 39 06 00    	mov    0x639fa(%rip),%eax        # 6b1d0 <fwp_slice>
    77d6:	85 c0                	test   %eax,%eax
    77d8:	74 36                	je     7810 <fwp_block+0x160>
    77da:	48 83 c4 08          	add    $0x8,%rsp
    77de:	c3                   	ret
    77df:	90                   	nop
    77e0:	e8 2b dc ff ff       	call   5410 <fwp_poll_events>
    77e5:	48 8b 05 fc 3f 06 00 	mov    0x63ffc(%rip),%rax        # 6b7e8 <fwp_ready_head>
    77ec:	48 85 c0             	test   %rax,%rax
    77ef:	0f 85 db fe ff ff    	jne    76d0 <fwp_block+0x20>
    77f5:	eb e9                	jmp    77e0 <fwp_block+0x130>
    77f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    77fe:	00 00 
    7800:	48 c7 05 d5 3f 06 00 	movq   $0x0,0x63fd5(%rip)        # 6b7e0 <fwp_ready_tail>
    7807:	00 00 00 00 
    780b:	e9 d7 fe ff ff       	jmp    76e7 <fwp_block+0x37>
    7810:	48 8d 3d c8 79 00 00 	lea    0x79c8(%rip),%rdi        # f1df <_IO_stdin_used+0x1df>
    7817:	e8 74 bb ff ff       	call   3390 <getenv@plt>
    781c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7821:	48 85 c0             	test   %rax,%rax
    7824:	74 05                	je     782b <fwp_block+0x17b>
    7826:	80 38 00             	cmpb   $0x0,(%rax)
    7829:	75 0b                	jne    7836 <fwp_block+0x186>
    782b:	89 15 9f 39 06 00    	mov    %edx,0x6399f(%rip)        # 6b1d0 <fwp_slice>
    7831:	48 83 c4 08          	add    $0x8,%rsp
    7835:	c3                   	ret
    7836:	ba 0a 00 00 00       	mov    $0xa,%edx
    783b:	31 f6                	xor    %esi,%esi
    783d:	48 89 c7             	mov    %rax,%rdi
    7840:	e8 fb bc ff ff       	call   3540 <strtoll@plt>
    7845:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7849:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7850:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7855:	0f 46 d0             	cmovbe %eax,%edx
    7858:	eb d1                	jmp    782b <fwp_block+0x17b>
    785a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007860 <fwp_caps173>:
    7860:	f3 0f 1e fa          	endbr64
    7864:	85 f6                	test   %esi,%esi
    7866:	74 08                	je     7870 <fwp_caps173+0x10>
    7868:	c3                   	ret
    7869:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7870:	48 8b 15 81 53 06 00 	mov    0x65381(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    7877:	48 89 f8             	mov    %rdi,%rax
    787a:	48 2b 05 4f 53 06 00 	sub    0x6534f(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7881:	48 c1 e2 10          	shl    $0x10,%rdx
    7885:	48 39 d0             	cmp    %rdx,%rax
    7888:	73 de                	jae    7868 <fwp_caps173+0x8>
    788a:	48 89 c2             	mov    %rax,%rdx
    788d:	48 c1 ea 10          	shr    $0x10,%rdx
    7891:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7895:	48 8b 15 7c 53 06 00 	mov    0x6537c(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    789c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    78a0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    78a4:	48 85 c9             	test   %rcx,%rcx
    78a7:	74 bf                	je     7868 <fwp_caps173+0x8>
    78a9:	0f b6 32             	movzbl (%rdx),%esi
    78ac:	40 80 fe 02          	cmp    $0x2,%sil
    78b0:	74 2e                	je     78e0 <fwp_caps173+0x80>
    78b2:	40 80 fe 01          	cmp    $0x1,%sil
    78b6:	75 b0                	jne    7868 <fwp_caps173+0x8>
    78b8:	8b 72 18             	mov    0x18(%rdx),%esi
    78bb:	0f b7 c0             	movzwl %ax,%eax
    78be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    78c1:	48 0f af c6          	imul   %rsi,%rax
    78c5:	48 c1 e8 20          	shr    $0x20,%rax
    78c9:	48 39 d0             	cmp    %rdx,%rax
    78cc:	73 9a                	jae    7868 <fwp_caps173+0x8>
    78ce:	48 01 c1             	add    %rax,%rcx
    78d1:	80 39 01             	cmpb   $0x1,(%rcx)
    78d4:	75 92                	jne    7868 <fwp_caps173+0x8>
    78d6:	e9 35 e1 ff ff       	jmp    5a10 <fwp_mem_free>
    78db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    78e0:	66 85 c0             	test   %ax,%ax
    78e3:	74 ec                	je     78d1 <fwp_caps173+0x71>
    78e5:	c3                   	ret
    78e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    78ed:	00 00 00 

00000000000078f0 <fwp_args37>:
    78f0:	f3 0f 1e fa          	endbr64
    78f4:	85 d2                	test   %edx,%edx
    78f6:	74 04                	je     78fc <fwp_args37+0xc>
    78f8:	85 f6                	test   %esi,%esi
    78fa:	74 04                	je     7900 <fwp_args37+0x10>
    78fc:	c3                   	ret
    78fd:	0f 1f 00             	nopl   (%rax)
    7900:	48 8b 15 f1 52 06 00 	mov    0x652f1(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    7907:	48 8b 07             	mov    (%rdi),%rax
    790a:	48 2b 05 bf 52 06 00 	sub    0x652bf(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7911:	48 c1 e2 10          	shl    $0x10,%rdx
    7915:	48 39 d0             	cmp    %rdx,%rax
    7918:	73 e2                	jae    78fc <fwp_args37+0xc>
    791a:	48 89 c2             	mov    %rax,%rdx
    791d:	48 c1 ea 10          	shr    $0x10,%rdx
    7921:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7925:	48 8b 15 ec 52 06 00 	mov    0x652ec(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    792c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7930:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7934:	48 85 ff             	test   %rdi,%rdi
    7937:	74 c3                	je     78fc <fwp_args37+0xc>
    7939:	0f b6 0a             	movzbl (%rdx),%ecx
    793c:	80 f9 02             	cmp    $0x2,%cl
    793f:	74 4f                	je     7990 <fwp_args37+0xa0>
    7941:	80 f9 01             	cmp    $0x1,%cl
    7944:	75 b6                	jne    78fc <fwp_args37+0xc>
    7946:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7949:	0f b7 c0             	movzwl %ax,%eax
    794c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    794f:	48 0f af c1          	imul   %rcx,%rax
    7953:	48 c1 e8 20          	shr    $0x20,%rax
    7957:	48 39 d0             	cmp    %rdx,%rax
    795a:	73 a0                	jae    78fc <fwp_args37+0xc>
    795c:	48 01 c7             	add    %rax,%rdi
    795f:	0f b6 07             	movzbl (%rdi),%eax
    7962:	84 c0                	test   %al,%al
    7964:	74 96                	je     78fc <fwp_args37+0xc>
    7966:	8b 15 7c 5b 06 00    	mov    0x65b7c(%rip),%edx        # 6d4e8 <iteration_active>
    796c:	85 d2                	test   %edx,%edx
    796e:	75 10                	jne    7980 <fwp_args37+0x90>
    7970:	3c fd                	cmp    $0xfd,%al
    7972:	77 22                	ja     7996 <fwp_args37+0xa6>
    7974:	83 c0 01             	add    $0x1,%eax
    7977:	88 07                	mov    %al,(%rdi)
    7979:	c3                   	ret
    797a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7980:	48 83 05 48 5b 06 00 	addq   $0x1,0x65b48(%rip)        # 6d4d0 <iteration_retains>
    7987:	01 
    7988:	eb e6                	jmp    7970 <fwp_args37+0x80>
    798a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7990:	66 85 c0             	test   %ax,%ax
    7993:	74 ca                	je     795f <fwp_args37+0x6f>
    7995:	c3                   	ret
    7996:	e9 15 dd ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    799b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000079a0 <fwp_caps37>:
    79a0:	f3 0f 1e fa          	endbr64
    79a4:	48 83 ec 18          	sub    $0x18,%rsp
    79a8:	48 89 f8             	mov    %rdi,%rax
    79ab:	8b 7f 04             	mov    0x4(%rdi),%edi
    79ae:	85 ff                	test   %edi,%edi
    79b0:	0f 84 9a 00 00 00    	je     7a50 <fwp_caps37+0xb0>
    79b6:	48 8b 78 08          	mov    0x8(%rax),%rdi
    79ba:	85 f6                	test   %esi,%esi
    79bc:	0f 85 9e 00 00 00    	jne    7a60 <fwp_caps37+0xc0>
    79c2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    79c7:	e8 24 f7 ff ff       	call   70f0 <fwp_drop4>
    79cc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    79d1:	48 8b 0d 20 52 06 00 	mov    0x65220(%rip),%rcx        # 6cbf8 <fwp_heap+0x13d8>
    79d8:	48 89 c2             	mov    %rax,%rdx
    79db:	48 2b 15 ee 51 06 00 	sub    0x651ee(%rip),%rdx        # 6cbd0 <fwp_heap+0x13b0>
    79e2:	48 c1 e1 10          	shl    $0x10,%rcx
    79e6:	48 39 ca             	cmp    %rcx,%rdx
    79e9:	73 6d                	jae    7a58 <fwp_caps37+0xb8>
    79eb:	48 89 d1             	mov    %rdx,%rcx
    79ee:	48 c1 e9 10          	shr    $0x10,%rcx
    79f2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    79f6:	48 8b 0d 1b 52 06 00 	mov    0x6521b(%rip),%rcx        # 6cc18 <fwp_heap+0x13f8>
    79fd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7a01:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7a05:	48 85 f6             	test   %rsi,%rsi
    7a08:	74 4e                	je     7a58 <fwp_caps37+0xb8>
    7a0a:	0f b6 39             	movzbl (%rcx),%edi
    7a0d:	40 80 ff 02          	cmp    $0x2,%dil
    7a11:	0f 84 c9 00 00 00    	je     7ae0 <fwp_caps37+0x140>
    7a17:	40 80 ff 01          	cmp    $0x1,%dil
    7a1b:	75 3b                	jne    7a58 <fwp_caps37+0xb8>
    7a1d:	8b 79 18             	mov    0x18(%rcx),%edi
    7a20:	0f b7 d2             	movzwl %dx,%edx
    7a23:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7a26:	48 0f af d7          	imul   %rdi,%rdx
    7a2a:	48 c1 ea 20          	shr    $0x20,%rdx
    7a2e:	48 39 ca             	cmp    %rcx,%rdx
    7a31:	73 25                	jae    7a58 <fwp_caps37+0xb8>
    7a33:	48 01 d6             	add    %rdx,%rsi
    7a36:	80 3e 01             	cmpb   $0x1,(%rsi)
    7a39:	75 1d                	jne    7a58 <fwp_caps37+0xb8>
    7a3b:	48 89 c7             	mov    %rax,%rdi
    7a3e:	48 83 c4 18          	add    $0x18,%rsp
    7a42:	e9 c9 df ff ff       	jmp    5a10 <fwp_mem_free>
    7a47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a4e:	00 00 
    7a50:	85 f6                	test   %esi,%esi
    7a52:	0f 84 79 ff ff ff    	je     79d1 <fwp_caps37+0x31>
    7a58:	48 83 c4 18          	add    $0x18,%rsp
    7a5c:	c3                   	ret
    7a5d:	0f 1f 00             	nopl   (%rax)
    7a60:	48 8b 05 91 51 06 00 	mov    0x65191(%rip),%rax        # 6cbf8 <fwp_heap+0x13d8>
    7a67:	48 2b 3d 62 51 06 00 	sub    0x65162(%rip),%rdi        # 6cbd0 <fwp_heap+0x13b0>
    7a6e:	48 c1 e0 10          	shl    $0x10,%rax
    7a72:	48 39 c7             	cmp    %rax,%rdi
    7a75:	73 e1                	jae    7a58 <fwp_caps37+0xb8>
    7a77:	48 89 f8             	mov    %rdi,%rax
    7a7a:	48 c1 e8 10          	shr    $0x10,%rax
    7a7e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7a82:	48 8b 05 8f 51 06 00 	mov    0x6518f(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    7a89:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7a8d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7a91:	48 85 c0             	test   %rax,%rax
    7a94:	74 c2                	je     7a58 <fwp_caps37+0xb8>
    7a96:	0f b6 0a             	movzbl (%rdx),%ecx
    7a99:	80 f9 02             	cmp    $0x2,%cl
    7a9c:	74 52                	je     7af0 <fwp_caps37+0x150>
    7a9e:	80 f9 01             	cmp    $0x1,%cl
    7aa1:	75 b5                	jne    7a58 <fwp_caps37+0xb8>
    7aa3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7aa6:	0f b7 ff             	movzwl %di,%edi
    7aa9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7aac:	48 0f af f9          	imul   %rcx,%rdi
    7ab0:	48 c1 ef 20          	shr    $0x20,%rdi
    7ab4:	48 39 d7             	cmp    %rdx,%rdi
    7ab7:	73 9f                	jae    7a58 <fwp_caps37+0xb8>
    7ab9:	48 01 f8             	add    %rdi,%rax
    7abc:	0f b6 10             	movzbl (%rax),%edx
    7abf:	84 d2                	test   %dl,%dl
    7ac1:	74 95                	je     7a58 <fwp_caps37+0xb8>
    7ac3:	8b 0d 1f 5a 06 00    	mov    0x65a1f(%rip),%ecx        # 6d4e8 <iteration_active>
    7ac9:	85 c9                	test   %ecx,%ecx
    7acb:	75 33                	jne    7b00 <fwp_caps37+0x160>
    7acd:	80 fa fd             	cmp    $0xfd,%dl
    7ad0:	77 38                	ja     7b0a <fwp_caps37+0x16a>
    7ad2:	83 c2 01             	add    $0x1,%edx
    7ad5:	88 10                	mov    %dl,(%rax)
    7ad7:	e9 7c ff ff ff       	jmp    7a58 <fwp_caps37+0xb8>
    7adc:	0f 1f 40 00          	nopl   0x0(%rax)
    7ae0:	66 85 d2             	test   %dx,%dx
    7ae3:	0f 85 6f ff ff ff    	jne    7a58 <fwp_caps37+0xb8>
    7ae9:	e9 48 ff ff ff       	jmp    7a36 <fwp_caps37+0x96>
    7aee:	66 90                	xchg   %ax,%ax
    7af0:	66 85 ff             	test   %di,%di
    7af3:	0f 85 5f ff ff ff    	jne    7a58 <fwp_caps37+0xb8>
    7af9:	eb c1                	jmp    7abc <fwp_caps37+0x11c>
    7afb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7b00:	48 83 05 c8 59 06 00 	addq   $0x1,0x659c8(%rip)        # 6d4d0 <iteration_retains>
    7b07:	01 
    7b08:	eb c3                	jmp    7acd <fwp_caps37+0x12d>
    7b0a:	48 89 c7             	mov    %rax,%rdi
    7b0d:	48 83 c4 18          	add    $0x18,%rsp
    7b11:	e9 9a db ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    7b16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7b1d:	00 00 00 

0000000000007b20 <fwp_drop0>:
    7b20:	f3 0f 1e fa          	endbr64
    7b24:	48 8b 15 cd 50 06 00 	mov    0x650cd(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    7b2b:	48 89 f8             	mov    %rdi,%rax
    7b2e:	48 2b 05 9b 50 06 00 	sub    0x6509b(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7b35:	48 c1 e2 10          	shl    $0x10,%rdx
    7b39:	48 39 d0             	cmp    %rdx,%rax
    7b3c:	0f 83 36 01 00 00    	jae    7c78 <fwp_drop0+0x158>
    7b42:	48 83 ec 18          	sub    $0x18,%rsp
    7b46:	48 8d 35 d3 3c 06 00 	lea    0x63cd3(%rip),%rsi        # 6b820 <fwp_heap>
    7b4d:	48 89 c2             	mov    %rax,%rdx
    7b50:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7b57:	48 c1 ea 10          	shr    $0x10,%rdx
    7b5b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7b5f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7b63:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7b67:	48 85 d2             	test   %rdx,%rdx
    7b6a:	74 42                	je     7bae <fwp_drop0+0x8e>
    7b6c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7b70:	41 80 f8 02          	cmp    $0x2,%r8b
    7b74:	74 42                	je     7bb8 <fwp_drop0+0x98>
    7b76:	41 80 f8 01          	cmp    $0x1,%r8b
    7b7a:	75 32                	jne    7bae <fwp_drop0+0x8e>
    7b7c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7b80:	0f b7 c0             	movzwl %ax,%eax
    7b83:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7b86:	49 0f af c0          	imul   %r8,%rax
    7b8a:	48 c1 e8 20          	shr    $0x20,%rax
    7b8e:	48 39 c8             	cmp    %rcx,%rax
    7b91:	73 1b                	jae    7bae <fwp_drop0+0x8e>
    7b93:	48 01 c2             	add    %rax,%rdx
    7b96:	0f b6 02             	movzbl (%rdx),%eax
    7b99:	84 c0                	test   %al,%al
    7b9b:	74 11                	je     7bae <fwp_drop0+0x8e>
    7b9d:	3c 01                	cmp    $0x1,%al
    7b9f:	74 27                	je     7bc8 <fwp_drop0+0xa8>
    7ba1:	3c ff                	cmp    $0xff,%al
    7ba3:	0f 84 e7 00 00 00    	je     7c90 <fwp_drop0+0x170>
    7ba9:	83 e8 01             	sub    $0x1,%eax
    7bac:	88 02                	mov    %al,(%rdx)
    7bae:	48 83 c4 18          	add    $0x18,%rsp
    7bb2:	c3                   	ret
    7bb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7bb8:	66 85 c0             	test   %ax,%ax
    7bbb:	74 d9                	je     7b96 <fwp_drop0+0x76>
    7bbd:	48 83 c4 18          	add    $0x18,%rsp
    7bc1:	c3                   	ret
    7bc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7bc8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7bcf:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7bd6:	48 89 f8             	mov    %rdi,%rax
    7bd9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7bdd:	48 29 c8             	sub    %rcx,%rax
    7be0:	48 c1 e2 10          	shl    $0x10,%rdx
    7be4:	48 39 d0             	cmp    %rdx,%rax
    7be7:	73 71                	jae    7c5a <fwp_drop0+0x13a>
    7be9:	49 89 c2             	mov    %rax,%r10
    7bec:	49 c1 ea 10          	shr    $0x10,%r10
    7bf0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7bf4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7bf8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7bfc:	4d 85 d2             	test   %r10,%r10
    7bff:	74 59                	je     7c5a <fwp_drop0+0x13a>
    7c01:	45 0f b6 19          	movzbl (%r9),%r11d
    7c05:	41 80 fb 02          	cmp    $0x2,%r11b
    7c09:	74 75                	je     7c80 <fwp_drop0+0x160>
    7c0b:	41 80 fb 01          	cmp    $0x1,%r11b
    7c0f:	75 49                	jne    7c5a <fwp_drop0+0x13a>
    7c11:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7c15:	0f b7 c0             	movzwl %ax,%eax
    7c18:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7c1c:	49 0f af c3          	imul   %r11,%rax
    7c20:	48 c1 e8 20          	shr    $0x20,%rax
    7c24:	4c 39 c8             	cmp    %r9,%rax
    7c27:	73 31                	jae    7c5a <fwp_drop0+0x13a>
    7c29:	49 01 c2             	add    %rax,%r10
    7c2c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7c30:	75 28                	jne    7c5a <fwp_drop0+0x13a>
    7c32:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7c37:	e8 d4 dd ff ff       	call   5a10 <fwp_mem_free>
    7c3c:	48 8d 35 dd 3b 06 00 	lea    0x63bdd(%rip),%rsi        # 6b820 <fwp_heap>
    7c43:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7c48:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7c4f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7c56:	48 c1 e2 10          	shl    $0x10,%rdx
    7c5a:	4c 89 c0             	mov    %r8,%rax
    7c5d:	48 29 c8             	sub    %rcx,%rax
    7c60:	48 39 d0             	cmp    %rdx,%rax
    7c63:	0f 83 45 ff ff ff    	jae    7bae <fwp_drop0+0x8e>
    7c69:	4c 89 c7             	mov    %r8,%rdi
    7c6c:	e9 dc fe ff ff       	jmp    7b4d <fwp_drop0+0x2d>
    7c71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c78:	c3                   	ret
    7c79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c80:	66 85 c0             	test   %ax,%ax
    7c83:	75 d5                	jne    7c5a <fwp_drop0+0x13a>
    7c85:	eb a5                	jmp    7c2c <fwp_drop0+0x10c>
    7c87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c8e:	00 00 
    7c90:	48 89 d0             	mov    %rdx,%rax
    7c93:	48 c1 e8 11          	shr    $0x11,%rax
    7c97:	48 31 d0             	xor    %rdx,%rax
    7c9a:	48 89 c1             	mov    %rax,%rcx
    7c9d:	48 c1 e9 09          	shr    $0x9,%rcx
    7ca1:	48 31 c8             	xor    %rcx,%rax
    7ca4:	0f b6 c8             	movzbl %al,%ecx
    7ca7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7cae:	00 
    7caf:	48 85 c0             	test   %rax,%rax
    7cb2:	75 15                	jne    7cc9 <fwp_drop0+0x1a9>
    7cb4:	eb 4e                	jmp    7d04 <fwp_drop0+0x1e4>
    7cb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7cbd:	00 00 00 
    7cc0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7cc4:	48 85 c0             	test   %rax,%rax
    7cc7:	74 3b                	je     7d04 <fwp_drop0+0x1e4>
    7cc9:	48 89 c1             	mov    %rax,%rcx
    7ccc:	48 39 10             	cmp    %rdx,(%rax)
    7ccf:	75 ef                	jne    7cc0 <fwp_drop0+0x1a0>
    7cd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7cd5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7cd9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7cdd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7ce4:	0f 85 c4 fe ff ff    	jne    7bae <fwp_drop0+0x8e>
    7cea:	48 89 d7             	mov    %rdx,%rdi
    7ced:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7cf2:	e8 d9 da ff ff       	call   57d0 <fwp_rc_forget_slot>
    7cf7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7cfc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7cff:	e9 aa fe ff ff       	jmp    7bae <fwp_drop0+0x8e>
    7d04:	48 8d 3d e5 7c 00 00 	lea    0x7ce5(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    7d0b:	e8 40 c7 ff ff       	call   4450 <fwp_trap>

0000000000007d10 <fwp_drop1>:
    7d10:	f3 0f 1e fa          	endbr64
    7d14:	48 8b 15 dd 4e 06 00 	mov    0x64edd(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    7d1b:	48 89 f8             	mov    %rdi,%rax
    7d1e:	48 2b 05 ab 4e 06 00 	sub    0x64eab(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7d25:	48 c1 e2 10          	shl    $0x10,%rdx
    7d29:	48 39 d0             	cmp    %rdx,%rax
    7d2c:	0f 83 36 01 00 00    	jae    7e68 <fwp_drop1+0x158>
    7d32:	48 83 ec 18          	sub    $0x18,%rsp
    7d36:	48 8d 35 e3 3a 06 00 	lea    0x63ae3(%rip),%rsi        # 6b820 <fwp_heap>
    7d3d:	48 89 c2             	mov    %rax,%rdx
    7d40:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7d47:	48 c1 ea 10          	shr    $0x10,%rdx
    7d4b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7d4f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7d53:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7d57:	48 85 d2             	test   %rdx,%rdx
    7d5a:	74 42                	je     7d9e <fwp_drop1+0x8e>
    7d5c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7d60:	41 80 f8 02          	cmp    $0x2,%r8b
    7d64:	74 42                	je     7da8 <fwp_drop1+0x98>
    7d66:	41 80 f8 01          	cmp    $0x1,%r8b
    7d6a:	75 32                	jne    7d9e <fwp_drop1+0x8e>
    7d6c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7d70:	0f b7 c0             	movzwl %ax,%eax
    7d73:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7d76:	49 0f af c0          	imul   %r8,%rax
    7d7a:	48 c1 e8 20          	shr    $0x20,%rax
    7d7e:	48 39 c8             	cmp    %rcx,%rax
    7d81:	73 1b                	jae    7d9e <fwp_drop1+0x8e>
    7d83:	48 01 c2             	add    %rax,%rdx
    7d86:	0f b6 02             	movzbl (%rdx),%eax
    7d89:	84 c0                	test   %al,%al
    7d8b:	74 11                	je     7d9e <fwp_drop1+0x8e>
    7d8d:	3c 01                	cmp    $0x1,%al
    7d8f:	74 27                	je     7db8 <fwp_drop1+0xa8>
    7d91:	3c ff                	cmp    $0xff,%al
    7d93:	0f 84 e7 00 00 00    	je     7e80 <fwp_drop1+0x170>
    7d99:	83 e8 01             	sub    $0x1,%eax
    7d9c:	88 02                	mov    %al,(%rdx)
    7d9e:	48 83 c4 18          	add    $0x18,%rsp
    7da2:	c3                   	ret
    7da3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7da8:	66 85 c0             	test   %ax,%ax
    7dab:	74 d9                	je     7d86 <fwp_drop1+0x76>
    7dad:	48 83 c4 18          	add    $0x18,%rsp
    7db1:	c3                   	ret
    7db2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7db8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7dbf:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7dc6:	48 89 f8             	mov    %rdi,%rax
    7dc9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7dcd:	48 29 c8             	sub    %rcx,%rax
    7dd0:	48 c1 e2 10          	shl    $0x10,%rdx
    7dd4:	48 39 d0             	cmp    %rdx,%rax
    7dd7:	73 71                	jae    7e4a <fwp_drop1+0x13a>
    7dd9:	49 89 c2             	mov    %rax,%r10
    7ddc:	49 c1 ea 10          	shr    $0x10,%r10
    7de0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7de4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7de8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7dec:	4d 85 d2             	test   %r10,%r10
    7def:	74 59                	je     7e4a <fwp_drop1+0x13a>
    7df1:	45 0f b6 19          	movzbl (%r9),%r11d
    7df5:	41 80 fb 02          	cmp    $0x2,%r11b
    7df9:	74 75                	je     7e70 <fwp_drop1+0x160>
    7dfb:	41 80 fb 01          	cmp    $0x1,%r11b
    7dff:	75 49                	jne    7e4a <fwp_drop1+0x13a>
    7e01:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7e05:	0f b7 c0             	movzwl %ax,%eax
    7e08:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7e0c:	49 0f af c3          	imul   %r11,%rax
    7e10:	48 c1 e8 20          	shr    $0x20,%rax
    7e14:	4c 39 c8             	cmp    %r9,%rax
    7e17:	73 31                	jae    7e4a <fwp_drop1+0x13a>
    7e19:	49 01 c2             	add    %rax,%r10
    7e1c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7e20:	75 28                	jne    7e4a <fwp_drop1+0x13a>
    7e22:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7e27:	e8 e4 db ff ff       	call   5a10 <fwp_mem_free>
    7e2c:	48 8d 35 ed 39 06 00 	lea    0x639ed(%rip),%rsi        # 6b820 <fwp_heap>
    7e33:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7e38:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7e3f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7e46:	48 c1 e2 10          	shl    $0x10,%rdx
    7e4a:	4c 89 c0             	mov    %r8,%rax
    7e4d:	48 29 c8             	sub    %rcx,%rax
    7e50:	48 39 d0             	cmp    %rdx,%rax
    7e53:	0f 83 45 ff ff ff    	jae    7d9e <fwp_drop1+0x8e>
    7e59:	4c 89 c7             	mov    %r8,%rdi
    7e5c:	e9 dc fe ff ff       	jmp    7d3d <fwp_drop1+0x2d>
    7e61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e68:	c3                   	ret
    7e69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e70:	66 85 c0             	test   %ax,%ax
    7e73:	75 d5                	jne    7e4a <fwp_drop1+0x13a>
    7e75:	eb a5                	jmp    7e1c <fwp_drop1+0x10c>
    7e77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7e7e:	00 00 
    7e80:	48 89 d0             	mov    %rdx,%rax
    7e83:	48 c1 e8 11          	shr    $0x11,%rax
    7e87:	48 31 d0             	xor    %rdx,%rax
    7e8a:	48 89 c1             	mov    %rax,%rcx
    7e8d:	48 c1 e9 09          	shr    $0x9,%rcx
    7e91:	48 31 c8             	xor    %rcx,%rax
    7e94:	0f b6 c8             	movzbl %al,%ecx
    7e97:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7e9e:	00 
    7e9f:	48 85 c0             	test   %rax,%rax
    7ea2:	75 25                	jne    7ec9 <fwp_drop1+0x1b9>
    7ea4:	eb 5e                	jmp    7f04 <fwp_drop1+0x1f4>
    7ea6:	0f 1f 40 00          	nopl   0x0(%rax)
    7eaa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7eb1:	00 00 00 00 
    7eb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7ebc:	00 00 00 00 
    7ec0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7ec4:	48 85 c0             	test   %rax,%rax
    7ec7:	74 3b                	je     7f04 <fwp_drop1+0x1f4>
    7ec9:	48 89 c1             	mov    %rax,%rcx
    7ecc:	48 39 10             	cmp    %rdx,(%rax)
    7ecf:	75 ef                	jne    7ec0 <fwp_drop1+0x1b0>
    7ed1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7ed5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7ed9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7edd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7ee4:	0f 85 b4 fe ff ff    	jne    7d9e <fwp_drop1+0x8e>
    7eea:	48 89 d7             	mov    %rdx,%rdi
    7eed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7ef2:	e8 d9 d8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7ef7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7efc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7eff:	e9 9a fe ff ff       	jmp    7d9e <fwp_drop1+0x8e>
    7f04:	48 8d 3d e5 7a 00 00 	lea    0x7ae5(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    7f0b:	e8 40 c5 ff ff       	call   4450 <fwp_trap>

0000000000007f10 <fwp_drop10>:
    7f10:	48 8b 0d e1 4c 06 00 	mov    0x64ce1(%rip),%rcx        # 6cbf8 <fwp_heap+0x13d8>
    7f17:	48 89 f8             	mov    %rdi,%rax
    7f1a:	48 2b 05 af 4c 06 00 	sub    0x64caf(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7f21:	48 c1 e1 10          	shl    $0x10,%rcx
    7f25:	48 39 c8             	cmp    %rcx,%rax
    7f28:	0f 83 c2 01 00 00    	jae    80f0 <fwp_drop10+0x1e0>
    7f2e:	48 83 ec 18          	sub    $0x18,%rsp
    7f32:	48 89 fa             	mov    %rdi,%rdx
    7f35:	48 8d 35 e4 38 06 00 	lea    0x638e4(%rip),%rsi        # 6b820 <fwp_heap>
    7f3c:	48 89 c1             	mov    %rax,%rcx
    7f3f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7f46:	48 c1 e9 10          	shr    $0x10,%rcx
    7f4a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7f4e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7f52:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7f56:	48 85 c9             	test   %rcx,%rcx
    7f59:	74 46                	je     7fa1 <fwp_drop10+0x91>
    7f5b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7f5f:	41 80 f9 02          	cmp    $0x2,%r9b
    7f63:	0f 84 d7 00 00 00    	je     8040 <fwp_drop10+0x130>
    7f69:	41 80 f9 01          	cmp    $0x1,%r9b
    7f6d:	75 32                	jne    7fa1 <fwp_drop10+0x91>
    7f6f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7f73:	0f b7 c0             	movzwl %ax,%eax
    7f76:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7f79:	49 0f af c1          	imul   %r9,%rax
    7f7d:	48 c1 e8 20          	shr    $0x20,%rax
    7f81:	48 39 f8             	cmp    %rdi,%rax
    7f84:	73 1b                	jae    7fa1 <fwp_drop10+0x91>
    7f86:	48 01 c1             	add    %rax,%rcx
    7f89:	0f b6 01             	movzbl (%rcx),%eax
    7f8c:	84 c0                	test   %al,%al
    7f8e:	74 11                	je     7fa1 <fwp_drop10+0x91>
    7f90:	3c 01                	cmp    $0x1,%al
    7f92:	74 1c                	je     7fb0 <fwp_drop10+0xa0>
    7f94:	3c ff                	cmp    $0xff,%al
    7f96:	0f 84 5c 01 00 00    	je     80f8 <fwp_drop10+0x1e8>
    7f9c:	83 e8 01             	sub    $0x1,%eax
    7f9f:	88 01                	mov    %al,(%rcx)
    7fa1:	48 83 c4 18          	add    $0x18,%rsp
    7fa5:	c3                   	ret
    7fa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7fad:	00 00 00 
    7fb0:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7fb7:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7fbe:	48 89 d0             	mov    %rdx,%rax
    7fc1:	49 89 d1             	mov    %rdx,%r9
    7fc4:	48 c1 e1 10          	shl    $0x10,%rcx
    7fc8:	48 29 f8             	sub    %rdi,%rax
    7fcb:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7fcf:	78 7f                	js     8050 <fwp_drop10+0x140>
    7fd1:	48 39 c8             	cmp    %rcx,%rax
    7fd4:	73 cb                	jae    7fa1 <fwp_drop10+0x91>
    7fd6:	48 89 c1             	mov    %rax,%rcx
    7fd9:	48 c1 e9 10          	shr    $0x10,%rcx
    7fdd:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7fe1:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7fe5:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7fe9:	48 85 f6             	test   %rsi,%rsi
    7fec:	74 b3                	je     7fa1 <fwp_drop10+0x91>
    7fee:	0f b6 39             	movzbl (%rcx),%edi
    7ff1:	40 80 ff 02          	cmp    $0x2,%dil
    7ff5:	74 39                	je     8030 <fwp_drop10+0x120>
    7ff7:	40 80 ff 01          	cmp    $0x1,%dil
    7ffb:	75 a4                	jne    7fa1 <fwp_drop10+0x91>
    7ffd:	8b 79 18             	mov    0x18(%rcx),%edi
    8000:	0f b7 c0             	movzwl %ax,%eax
    8003:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8006:	48 0f af c7          	imul   %rdi,%rax
    800a:	48 c1 e8 20          	shr    $0x20,%rax
    800e:	48 39 c8             	cmp    %rcx,%rax
    8011:	73 8e                	jae    7fa1 <fwp_drop10+0x91>
    8013:	48 01 c6             	add    %rax,%rsi
    8016:	80 3e 01             	cmpb   $0x1,(%rsi)
    8019:	75 86                	jne    7fa1 <fwp_drop10+0x91>
    801b:	48 89 d7             	mov    %rdx,%rdi
    801e:	48 83 c4 18          	add    $0x18,%rsp
    8022:	e9 e9 d9 ff ff       	jmp    5a10 <fwp_mem_free>
    8027:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    802e:	00 00 
    8030:	66 85 c0             	test   %ax,%ax
    8033:	74 e1                	je     8016 <fwp_drop10+0x106>
    8035:	48 83 c4 18          	add    $0x18,%rsp
    8039:	c3                   	ret
    803a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8040:	66 85 c0             	test   %ax,%ax
    8043:	0f 84 40 ff ff ff    	je     7f89 <fwp_drop10+0x79>
    8049:	48 83 c4 18          	add    $0x18,%rsp
    804d:	c3                   	ret
    804e:	66 90                	xchg   %ax,%ax
    8050:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    8054:	48 39 c8             	cmp    %rcx,%rax
    8057:	73 74                	jae    80cd <fwp_drop10+0x1bd>
    8059:	49 89 c2             	mov    %rax,%r10
    805c:	49 c1 ea 10          	shr    $0x10,%r10
    8060:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    8064:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    8068:	4d 8b 50 20          	mov    0x20(%r8),%r10
    806c:	4d 85 d2             	test   %r10,%r10
    806f:	74 5c                	je     80cd <fwp_drop10+0x1bd>
    8071:	45 0f b6 18          	movzbl (%r8),%r11d
    8075:	41 80 fb 02          	cmp    $0x2,%r11b
    8079:	74 6d                	je     80e8 <fwp_drop10+0x1d8>
    807b:	41 80 fb 01          	cmp    $0x1,%r11b
    807f:	75 4c                	jne    80cd <fwp_drop10+0x1bd>
    8081:	45 8b 58 18          	mov    0x18(%r8),%r11d
    8085:	0f b7 c0             	movzwl %ax,%eax
    8088:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    808c:	49 0f af c3          	imul   %r11,%rax
    8090:	48 c1 e8 20          	shr    $0x20,%rax
    8094:	4c 39 c0             	cmp    %r8,%rax
    8097:	73 34                	jae    80cd <fwp_drop10+0x1bd>
    8099:	49 01 c2             	add    %rax,%r10
    809c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    80a0:	75 2b                	jne    80cd <fwp_drop10+0x1bd>
    80a2:	4c 89 cf             	mov    %r9,%rdi
    80a5:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    80aa:	e8 61 d9 ff ff       	call   5a10 <fwp_mem_free>
    80af:	48 8d 35 6a 37 06 00 	lea    0x6376a(%rip),%rsi        # 6b820 <fwp_heap>
    80b6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    80bb:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    80c2:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    80c9:	48 c1 e1 10          	shl    $0x10,%rcx
    80cd:	48 89 d0             	mov    %rdx,%rax
    80d0:	48 29 f8             	sub    %rdi,%rax
    80d3:	48 39 c8             	cmp    %rcx,%rax
    80d6:	0f 82 60 fe ff ff    	jb     7f3c <fwp_drop10+0x2c>
    80dc:	e9 c0 fe ff ff       	jmp    7fa1 <fwp_drop10+0x91>
    80e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    80e8:	66 85 c0             	test   %ax,%ax
    80eb:	75 e0                	jne    80cd <fwp_drop10+0x1bd>
    80ed:	eb ad                	jmp    809c <fwp_drop10+0x18c>
    80ef:	90                   	nop
    80f0:	c3                   	ret
    80f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    80f8:	48 89 c8             	mov    %rcx,%rax
    80fb:	48 c1 e8 11          	shr    $0x11,%rax
    80ff:	48 31 c8             	xor    %rcx,%rax
    8102:	48 89 c2             	mov    %rax,%rdx
    8105:	48 c1 ea 09          	shr    $0x9,%rdx
    8109:	48 31 d0             	xor    %rdx,%rax
    810c:	0f b6 d0             	movzbl %al,%edx
    810f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    8116:	00 
    8117:	48 85 c0             	test   %rax,%rax
    811a:	75 0d                	jne    8129 <fwp_drop10+0x219>
    811c:	eb 46                	jmp    8164 <fwp_drop10+0x254>
    811e:	66 90                	xchg   %ax,%ax
    8120:	48 8b 42 10          	mov    0x10(%rdx),%rax
    8124:	48 85 c0             	test   %rax,%rax
    8127:	74 3b                	je     8164 <fwp_drop10+0x254>
    8129:	48 89 c2             	mov    %rax,%rdx
    812c:	48 39 08             	cmp    %rcx,(%rax)
    812f:	75 ef                	jne    8120 <fwp_drop10+0x210>
    8131:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8135:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    8139:	48 89 50 08          	mov    %rdx,0x8(%rax)
    813d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    8144:	0f 85 57 fe ff ff    	jne    7fa1 <fwp_drop10+0x91>
    814a:	48 89 cf             	mov    %rcx,%rdi
    814d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8152:	e8 79 d6 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8157:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    815c:	c6 01 fe             	movb   $0xfe,(%rcx)
    815f:	e9 3d fe ff ff       	jmp    7fa1 <fwp_drop10+0x91>
    8164:	48 8d 3d 85 78 00 00 	lea    0x7885(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    816b:	e8 e0 c2 ff ff       	call   4450 <fwp_trap>

0000000000008170 <f37>:
    8170:	41 57                	push   %r15
    8172:	41 56                	push   %r14
    8174:	41 55                	push   %r13
    8176:	41 54                	push   %r12
    8178:	55                   	push   %rbp
    8179:	53                   	push   %rbx
    817a:	48 83 ec 38          	sub    $0x38,%rsp
    817e:	48 8b 15 73 4a 06 00 	mov    0x64a73(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    8185:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    818a:	48 c1 e2 10          	shl    $0x10,%rdx
    818e:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    8195:	00 00 
    8197:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    819c:	48 8b 0d 2d 4a 06 00 	mov    0x64a2d(%rip),%rcx        # 6cbd0 <fwp_heap+0x13b0>
    81a3:	48 85 ff             	test   %rdi,%rdi
    81a6:	0f 84 6e 03 00 00    	je     851a <f37+0x3aa>
    81ac:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    81b1:	4c 8b 68 10          	mov    0x10(%rax),%r13
    81b5:	4c 89 e8             	mov    %r13,%rax
    81b8:	48 29 c8             	sub    %rcx,%rax
    81bb:	48 39 d0             	cmp    %rdx,%rax
    81be:	0f 83 3c 03 00 00    	jae    8500 <f37+0x390>
    81c4:	48 89 c2             	mov    %rax,%rdx
    81c7:	48 c1 ea 10          	shr    $0x10,%rdx
    81cb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    81cf:	48 8b 15 42 4a 06 00 	mov    0x64a42(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    81d6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    81da:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    81de:	48 85 ff             	test   %rdi,%rdi
    81e1:	0f 84 19 03 00 00    	je     8500 <f37+0x390>
    81e7:	0f b6 0a             	movzbl (%rdx),%ecx
    81ea:	80 f9 02             	cmp    $0x2,%cl
    81ed:	0f 84 9d 02 00 00    	je     8490 <f37+0x320>
    81f3:	80 f9 01             	cmp    $0x1,%cl
    81f6:	75 24                	jne    821c <f37+0xac>
    81f8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    81fb:	0f b7 c0             	movzwl %ax,%eax
    81fe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8201:	48 0f af c1          	imul   %rcx,%rax
    8205:	48 c1 e8 20          	shr    $0x20,%rax
    8209:	48 39 d0             	cmp    %rdx,%rax
    820c:	73 0e                	jae    821c <f37+0xac>
    820e:	48 01 c7             	add    %rax,%rdi
    8211:	0f b6 07             	movzbl (%rdi),%eax
    8214:	84 c0                	test   %al,%al
    8216:	0f 85 94 02 00 00    	jne    84b0 <f37+0x340>
    821c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8221:	48 8b 40 10          	mov    0x10(%rax),%rax
    8225:	ba 01 00 00 00       	mov    $0x1,%edx
    822a:	48 85 c0             	test   %rax,%rax
    822d:	74 0e                	je     823d <f37+0xcd>
    822f:	90                   	nop
    8230:	48 8b 40 10          	mov    0x10(%rax),%rax
    8234:	48 83 c2 01          	add    $0x1,%rdx
    8238:	48 85 c0             	test   %rax,%rax
    823b:	75 f3                	jne    8230 <f37+0xc0>
    823d:	4d 85 ed             	test   %r13,%r13
    8240:	0f 84 ea 02 00 00    	je     8530 <f37+0x3c0>
    8246:	4c 89 e8             	mov    %r13,%rax
    8249:	31 db                	xor    %ebx,%ebx
    824b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8250:	48 8b 40 10          	mov    0x10(%rax),%rax
    8254:	48 83 c3 01          	add    $0x1,%rbx
    8258:	48 85 c0             	test   %rax,%rax
    825b:	75 f3                	jne    8250 <f37+0xe0>
    825d:	48 39 d3             	cmp    %rdx,%rbx
    8260:	48 0f 47 da          	cmova  %rdx,%rbx
    8264:	48 89 d8             	mov    %rbx,%rax
    8267:	48 c1 e8 3c          	shr    $0x3c,%rax
    826b:	0f 85 cd 03 00 00    	jne    863e <f37+0x4ce>
    8271:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8275:	be 02 00 00 00       	mov    $0x2,%esi
    827a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8281:	00 
    8282:	e8 89 dc ff ff       	call   5f10 <fwp_heap_alloc>
    8287:	48 89 28             	mov    %rbp,(%rax)
    828a:	48 8b 15 67 49 06 00 	mov    0x64967(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    8291:	49 89 c4             	mov    %rax,%r12
    8294:	48 2b 05 35 49 06 00 	sub    0x64935(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    829b:	48 c1 e2 10          	shl    $0x10,%rdx
    829f:	48 39 d0             	cmp    %rdx,%rax
    82a2:	73 57                	jae    82fb <f37+0x18b>
    82a4:	48 89 c2             	mov    %rax,%rdx
    82a7:	48 c1 ea 10          	shr    $0x10,%rdx
    82ab:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    82af:	48 8b 15 62 49 06 00 	mov    0x64962(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    82b6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    82ba:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    82be:	48 85 ed             	test   %rbp,%rbp
    82c1:	74 38                	je     82fb <f37+0x18b>
    82c3:	0f b6 0a             	movzbl (%rdx),%ecx
    82c6:	80 f9 02             	cmp    $0x2,%cl
    82c9:	0f 84 21 02 00 00    	je     84f0 <f37+0x380>
    82cf:	80 f9 01             	cmp    $0x1,%cl
    82d2:	75 27                	jne    82fb <f37+0x18b>
    82d4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    82d7:	0f b7 c0             	movzwl %ax,%eax
    82da:	8b 52 1c             	mov    0x1c(%rdx),%edx
    82dd:	48 0f af c1          	imul   %rcx,%rax
    82e1:	48 c1 e8 20          	shr    $0x20,%rax
    82e5:	48 39 d0             	cmp    %rdx,%rax
    82e8:	73 11                	jae    82fb <f37+0x18b>
    82ea:	48 01 c5             	add    %rax,%rbp
    82ed:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    82f1:	0f 84 a7 02 00 00    	je     859e <f37+0x42e>
    82f7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    82fb:	48 85 db             	test   %rbx,%rbx
    82fe:	74 5d                	je     835d <f37+0x1ed>
    8300:	48 c1 e3 04          	shl    $0x4,%rbx
    8304:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8309:	4c 89 e5             	mov    %r12,%rbp
    830c:	4d 89 ef             	mov    %r13,%r15
    830f:	4c 01 e3             	add    %r12,%rbx
    8312:	0f 1f 00             	nopl   (%rax)
    8315:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    831c:	00 00 00 00 
    8320:	49 8b 46 08          	mov    0x8(%r14),%rax
    8324:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8328:	48 83 c5 10          	add    $0x10,%rbp
    832c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8331:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8335:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8339:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    833e:	e8 2d e3 ff ff       	call   6670 <w120>
    8343:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8348:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    834c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8350:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8354:	4d 8b 76 10          	mov    0x10(%r14),%r14
    8358:	48 39 eb             	cmp    %rbp,%rbx
    835b:	75 c3                	jne    8320 <f37+0x1b0>
    835d:	4c 89 ef             	mov    %r13,%rdi
    8360:	31 db                	xor    %ebx,%ebx
    8362:	e8 89 ed ff ff       	call   70f0 <fwp_drop4>
    8367:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    836c:	e8 7f ed ff ff       	call   70f0 <fwp_drop4>
    8371:	4d 8b 2c 24          	mov    (%r12),%r13
    8375:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8379:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    8380:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    8387:	4d 85 ed             	test   %r13,%r13
    838a:	74 3f                	je     83cb <f37+0x25b>
    838c:	0f 1f 40 00          	nopl   0x0(%rax)
    8390:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    8397:	49 8b 54 dc 10       	mov    0x10(%r12,%rbx,8),%rdx
    839c:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    83a3:	00 f0 3f 
    83a6:	48 83 c3 02          	add    $0x2,%rbx
    83aa:	48 89 ce             	mov    %rcx,%rsi
    83ad:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    83b3:	e8 38 df ff ff       	call   62f0 <fwp_p_ad_push>
    83b8:	4c 39 eb             	cmp    %r13,%rbx
    83bb:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    83c1:	48 89 c7             	mov    %rax,%rdi
    83c4:	72 ca                	jb     8390 <f37+0x220>
    83c6:	66 49 0f 7e c5       	movq   %xmm0,%r13
    83cb:	4c 89 e7             	mov    %r12,%rdi
    83ce:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    83d3:	e8 38 fb ff ff       	call   7f10 <fwp_drop10>
    83d8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    83dd:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    83e2:	31 ff                	xor    %edi,%edi
    83e4:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    83e9:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    83ee:	e8 0d dd ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    83f3:	48 8b 15 fe 47 06 00 	mov    0x647fe(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    83fa:	48 89 c5             	mov    %rax,%rbp
    83fd:	48 2b 05 cc 47 06 00 	sub    0x647cc(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    8404:	48 c1 e2 10          	shl    $0x10,%rdx
    8408:	48 39 d0             	cmp    %rdx,%rax
    840b:	73 55                	jae    8462 <f37+0x2f2>
    840d:	48 89 c2             	mov    %rax,%rdx
    8410:	48 c1 ea 10          	shr    $0x10,%rdx
    8414:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8418:	48 8b 15 f9 47 06 00 	mov    0x647f9(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    841f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8423:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    8427:	48 85 db             	test   %rbx,%rbx
    842a:	74 36                	je     8462 <f37+0x2f2>
    842c:	0f b6 0a             	movzbl (%rdx),%ecx
    842f:	80 f9 02             	cmp    $0x2,%cl
    8432:	0f 84 a8 00 00 00    	je     84e0 <f37+0x370>
    8438:	80 f9 01             	cmp    $0x1,%cl
    843b:	75 25                	jne    8462 <f37+0x2f2>
    843d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8440:	0f b7 c0             	movzwl %ax,%eax
    8443:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8446:	48 0f af c1          	imul   %rcx,%rax
    844a:	48 c1 e8 20          	shr    $0x20,%rax
    844e:	48 39 d0             	cmp    %rdx,%rax
    8451:	73 0f                	jae    8462 <f37+0x2f2>
    8453:	48 01 c3             	add    %rax,%rbx
    8456:	80 3b ff             	cmpb   $0xff,(%rbx)
    8459:	0f 84 32 01 00 00    	je     8591 <f37+0x421>
    845f:	c6 03 01             	movb   $0x1,(%rbx)
    8462:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    8467:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    846e:	00 00 
    8470:	0f 85 d4 01 00 00    	jne    864a <f37+0x4da>
    8476:	48 83 c4 38          	add    $0x38,%rsp
    847a:	48 89 e8             	mov    %rbp,%rax
    847d:	5b                   	pop    %rbx
    847e:	5d                   	pop    %rbp
    847f:	41 5c                	pop    %r12
    8481:	41 5d                	pop    %r13
    8483:	41 5e                	pop    %r14
    8485:	41 5f                	pop    %r15
    8487:	c3                   	ret
    8488:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    848f:	00 
    8490:	66 85 c0             	test   %ax,%ax
    8493:	0f 85 83 fd ff ff    	jne    821c <f37+0xac>
    8499:	0f b6 07             	movzbl (%rdi),%eax
    849c:	84 c0                	test   %al,%al
    849e:	0f 84 78 fd ff ff    	je     821c <f37+0xac>
    84a4:	90                   	nop
    84a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    84ac:	00 00 00 00 
    84b0:	8b 15 32 50 06 00    	mov    0x65032(%rip),%edx        # 6d4e8 <iteration_active>
    84b6:	85 d2                	test   %edx,%edx
    84b8:	75 56                	jne    8510 <f37+0x3a0>
    84ba:	3c fd                	cmp    $0xfd,%al
    84bc:	0f 87 4b 01 00 00    	ja     860d <f37+0x49d>
    84c2:	83 c0 01             	add    $0x1,%eax
    84c5:	88 07                	mov    %al,(%rdi)
    84c7:	31 d2                	xor    %edx,%edx
    84c9:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    84cf:	0f 85 47 fd ff ff    	jne    821c <f37+0xac>
    84d5:	e9 63 fd ff ff       	jmp    823d <f37+0xcd>
    84da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    84e0:	66 85 c0             	test   %ax,%ax
    84e3:	0f 85 79 ff ff ff    	jne    8462 <f37+0x2f2>
    84e9:	e9 68 ff ff ff       	jmp    8456 <f37+0x2e6>
    84ee:	66 90                	xchg   %ax,%ax
    84f0:	66 85 c0             	test   %ax,%ax
    84f3:	0f 85 02 fe ff ff    	jne    82fb <f37+0x18b>
    84f9:	e9 ef fd ff ff       	jmp    82ed <f37+0x17d>
    84fe:	66 90                	xchg   %ax,%ax
    8500:	4c 89 e8             	mov    %r13,%rax
    8503:	e9 1d fd ff ff       	jmp    8225 <f37+0xb5>
    8508:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    850f:	00 
    8510:	48 83 05 b8 4f 06 00 	addq   $0x1,0x64fb8(%rip)        # 6d4d0 <iteration_retains>
    8517:	01 
    8518:	eb a0                	jmp    84ba <f37+0x34a>
    851a:	48 f7 d9             	neg    %rcx
    851d:	48 39 d1             	cmp    %rdx,%rcx
    8520:	0f 82 85 00 00 00    	jb     85ab <f37+0x43b>
    8526:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    852d:	00 00 00 
    8530:	be 02 00 00 00       	mov    $0x2,%esi
    8535:	bf 08 00 00 00       	mov    $0x8,%edi
    853a:	e8 d1 d9 ff ff       	call   5f10 <fwp_heap_alloc>
    853f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8546:	48 8b 15 ab 46 06 00 	mov    0x646ab(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    854d:	49 89 c4             	mov    %rax,%r12
    8550:	48 2b 05 79 46 06 00 	sub    0x64679(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    8557:	48 c1 e2 10          	shl    $0x10,%rdx
    855b:	48 39 d0             	cmp    %rdx,%rax
    855e:	0f 83 b3 00 00 00    	jae    8617 <f37+0x4a7>
    8564:	48 89 c2             	mov    %rax,%rdx
    8567:	45 31 ed             	xor    %r13d,%r13d
    856a:	48 c1 ea 10          	shr    $0x10,%rdx
    856e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8572:	48 8b 15 9f 46 06 00 	mov    0x6469f(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    8579:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    857d:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    8581:	48 85 ed             	test   %rbp,%rbp
    8584:	0f 84 d3 fd ff ff    	je     835d <f37+0x1ed>
    858a:	31 db                	xor    %ebx,%ebx
    858c:	e9 32 fd ff ff       	jmp    82c3 <f37+0x153>
    8591:	48 89 df             	mov    %rbx,%rdi
    8594:	e8 37 d2 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8599:	e9 c1 fe ff ff       	jmp    845f <f37+0x2ef>
    859e:	48 89 ef             	mov    %rbp,%rdi
    85a1:	e8 2a d2 ff ff       	call   57d0 <fwp_rc_forget_slot>
    85a6:	e9 4c fd ff ff       	jmp    82f7 <f37+0x187>
    85ab:	48 89 c8             	mov    %rcx,%rax
    85ae:	48 c1 e8 10          	shr    $0x10,%rax
    85b2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    85b6:	48 8b 05 5b 46 06 00 	mov    0x6465b(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    85bd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    85c1:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    85c5:	48 85 ff             	test   %rdi,%rdi
    85c8:	0f 84 62 ff ff ff    	je     8530 <f37+0x3c0>
    85ce:	0f b6 02             	movzbl (%rdx),%eax
    85d1:	3c 02                	cmp    $0x2,%al
    85d3:	74 4a                	je     861f <f37+0x4af>
    85d5:	3c 01                	cmp    $0x1,%al
    85d7:	0f 85 53 ff ff ff    	jne    8530 <f37+0x3c0>
    85dd:	0f b7 c1             	movzwl %cx,%eax
    85e0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    85e3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    85e6:	48 0f af c1          	imul   %rcx,%rax
    85ea:	48 c1 e8 20          	shr    $0x20,%rax
    85ee:	48 39 d0             	cmp    %rdx,%rax
    85f1:	0f 83 39 ff ff ff    	jae    8530 <f37+0x3c0>
    85f7:	48 01 c7             	add    %rax,%rdi
    85fa:	0f b6 07             	movzbl (%rdi),%eax
    85fd:	84 c0                	test   %al,%al
    85ff:	0f 84 2b ff ff ff    	je     8530 <f37+0x3c0>
    8605:	45 31 ed             	xor    %r13d,%r13d
    8608:	e9 a3 fe ff ff       	jmp    84b0 <f37+0x340>
    860d:	e8 9e d0 ff ff       	call   56b0 <fwp_rc_wide_dup>
    8612:	e9 b0 fe ff ff       	jmp    84c7 <f37+0x357>
    8617:	45 31 ed             	xor    %r13d,%r13d
    861a:	e9 3e fd ff ff       	jmp    835d <f37+0x1ed>
    861f:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    8625:	49 89 cd             	mov    %rcx,%r13
    8628:	0f 85 02 ff ff ff    	jne    8530 <f37+0x3c0>
    862e:	0f b6 07             	movzbl (%rdi),%eax
    8631:	84 c0                	test   %al,%al
    8633:	0f 85 77 fe ff ff    	jne    84b0 <f37+0x340>
    8639:	e9 f2 fe ff ff       	jmp    8530 <f37+0x3c0>
    863e:	48 8d 3d a6 6b 00 00 	lea    0x6ba6(%rip),%rdi        # f1eb <_IO_stdin_used+0x1eb>
    8645:	e8 06 be ff ff       	call   4450 <fwp_trap>
    864a:	e8 01 ae ff ff       	call   3450 <__stack_chk_fail@plt>
    864f:	90                   	nop

0000000000008650 <fwp_owned_entry37>:
    8650:	f3 0f 1e fa          	endbr64
    8654:	48 8b 3f             	mov    (%rdi),%rdi
    8657:	e9 14 fb ff ff       	jmp    8170 <f37>
    865c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008660 <e37>:
    8660:	f3 0f 1e fa          	endbr64
    8664:	53                   	push   %rbx
    8665:	48 8b 1f             	mov    (%rdi),%rbx
    8668:	48 89 df             	mov    %rbx,%rdi
    866b:	e8 70 e1 ff ff       	call   67e0 <fwp_rc_share>
    8670:	48 89 df             	mov    %rbx,%rdi
    8673:	e8 f8 fa ff ff       	call   8170 <f37>
    8678:	48 89 c3             	mov    %rax,%rbx
    867b:	48 89 c7             	mov    %rax,%rdi
    867e:	e8 5d e1 ff ff       	call   67e0 <fwp_rc_share>
    8683:	48 89 d8             	mov    %rbx,%rax
    8686:	5b                   	pop    %rbx
    8687:	c3                   	ret
    8688:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    868f:	00 

0000000000008690 <fwp_write>:
    8690:	41 57                	push   %r15
    8692:	41 56                	push   %r14
    8694:	41 55                	push   %r13
    8696:	41 54                	push   %r12
    8698:	55                   	push   %rbp
    8699:	53                   	push   %rbx
    869a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    86a1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    86a8:	00 00 
    86aa:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    86b1:	00 
    86b2:	49 89 d4             	mov    %rdx,%r12
    86b5:	8b 12                	mov    (%rdx),%edx
    86b7:	83 fa 19             	cmp    $0x19,%edx
    86ba:	77 6a                	ja     8726 <fwp_write+0x96>
    86bc:	48 89 f5             	mov    %rsi,%rbp
    86bf:	89 d0                	mov    %edx,%eax
    86c1:	89 ce                	mov    %ecx,%esi
    86c3:	48 89 fb             	mov    %rdi,%rbx
    86c6:	48 8d 0d 03 76 00 00 	lea    0x7603(%rip),%rcx        # fcd0 <_IO_stdin_used+0xcd0>
    86cd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    86d1:	48 01 c8             	add    %rcx,%rax
    86d4:	3e ff e0             	notrack jmp *%rax
    86d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    86de:	00 00 
    86e0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    86e4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    86e8:	48 89 ca             	mov    %rcx,%rdx
    86eb:	48 85 c9             	test   %rcx,%rcx
    86ee:	0f 88 9c 0c 00 00    	js     9390 <fwp_write+0xd00>
    86f4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    86fb:	00 
    86fc:	48 89 c6             	mov    %rax,%rsi
    86ff:	4c 89 e7             	mov    %r12,%rdi
    8702:	e8 39 b3 ff ff       	call   3a40 <fwp_fmt_u128>
    8707:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    870e:	00 00 
    8710:	4c 89 e7             	mov    %r12,%rdi
    8713:	e8 28 ad ff ff       	call   3440 <strlen@plt>
    8718:	4c 89 e6             	mov    %r12,%rsi
    871b:	48 89 df             	mov    %rbx,%rdi
    871e:	48 89 c2             	mov    %rax,%rdx
    8721:	e8 ca b9 ff ff       	call   40f0 <buf_put>
    8726:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    872d:	00 
    872e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8735:	00 00 
    8737:	0f 85 28 04 00 00    	jne    8b65 <fwp_write+0x4d5>
    873d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8744:	5b                   	pop    %rbx
    8745:	5d                   	pop    %rbp
    8746:	41 5c                	pop    %r12
    8748:	41 5d                	pop    %r13
    874a:	41 5e                	pop    %r14
    874c:	41 5f                	pop    %r15
    874e:	c3                   	ret
    874f:	90                   	nop
    8750:	49 89 e9             	mov    %rbp,%r9
    8753:	4c 8d 05 bb 6a 00 00 	lea    0x6abb(%rip),%r8        # f215 <_IO_stdin_used+0x215>
    875a:	b9 00 02 00 00       	mov    $0x200,%ecx
    875f:	ba 02 00 00 00       	mov    $0x2,%edx
    8764:	be 00 02 00 00       	mov    $0x200,%esi
    8769:	31 c0                	xor    %eax,%eax
    876b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8772:	00 
    8773:	e8 28 ac ff ff       	call   33a0 <__snprintf_chk@plt>
    8778:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    877f:	00 
    8780:	e8 bb ac ff ff       	call   3440 <strlen@plt>
    8785:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    878c:	00 
    878d:	48 89 df             	mov    %rbx,%rdi
    8790:	48 89 c2             	mov    %rax,%rdx
    8793:	e8 58 b9 ff ff       	call   40f0 <buf_put>
    8798:	eb 8c                	jmp    8726 <fwp_write+0x96>
    879a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    87a0:	49 89 e9             	mov    %rbp,%r9
    87a3:	4c 8d 05 66 6a 00 00 	lea    0x6a66(%rip),%r8        # f210 <_IO_stdin_used+0x210>
    87aa:	eb ae                	jmp    875a <fwp_write+0xca>
    87ac:	0f 1f 40 00          	nopl   0x0(%rax)
    87b0:	83 fa 13             	cmp    $0x13,%edx
    87b3:	48 8d 05 4c 6a 00 00 	lea    0x6a4c(%rip),%rax        # f206 <_IO_stdin_used+0x206>
    87ba:	48 8d 35 4a 6a 00 00 	lea    0x6a4a(%rip),%rsi        # f20b <_IO_stdin_used+0x20b>
    87c1:	ba 04 00 00 00       	mov    $0x4,%edx
    87c6:	48 0f 44 f0          	cmove  %rax,%rsi
    87ca:	45 31 ed             	xor    %r13d,%r13d
    87cd:	e8 1e b9 ff ff       	call   40f0 <buf_put>
    87d2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    87d7:	0f 84 a3 08 00 00    	je     9080 <fwp_write+0x9f0>
    87dd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    87e2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    87e7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    87ec:	48 89 df             	mov    %rbx,%rdi
    87ef:	49 0f 44 c5          	cmove  %r13,%rax
    87f3:	31 c9                	xor    %ecx,%ecx
    87f5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    87fa:	e8 91 fe ff ff       	call   8690 <fwp_write>
    87ff:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8804:	0f 84 6e 09 00 00    	je     9178 <fwp_write+0xae8>
    880a:	49 83 c5 01          	add    $0x1,%r13
    880e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8812:	0f 83 68 08 00 00    	jae    9080 <fwp_write+0x9f0>
    8818:	ba 02 00 00 00       	mov    $0x2,%edx
    881d:	48 8d 35 31 6a 00 00 	lea    0x6a31(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    8824:	48 89 df             	mov    %rbx,%rdi
    8827:	e8 c4 b8 ff ff       	call   40f0 <buf_put>
    882c:	eb af                	jmp    87dd <fwp_write+0x14d>
    882e:	66 90                	xchg   %ax,%ax
    8830:	ba 06 00 00 00       	mov    $0x6,%edx
    8835:	48 8d 35 f2 69 00 00 	lea    0x69f2(%rip),%rsi        # f22e <_IO_stdin_used+0x22e>
    883c:	48 83 c5 10          	add    $0x10,%rbp
    8840:	e8 ab b8 ff ff       	call   40f0 <buf_put>
    8845:	48 89 ef             	mov    %rbp,%rdi
    8848:	e8 f3 ab ff ff       	call   3440 <strlen@plt>
    884d:	48 89 ee             	mov    %rbp,%rsi
    8850:	48 89 df             	mov    %rbx,%rdi
    8853:	48 89 c2             	mov    %rax,%rdx
    8856:	e8 95 b8 ff ff       	call   40f0 <buf_put>
    885b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8860:	ba 01 00 00 00       	mov    $0x1,%edx
    8865:	48 89 df             	mov    %rbx,%rdi
    8868:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    886d:	e8 7e b8 ff ff       	call   40f0 <buf_put>
    8872:	e9 af fe ff ff       	jmp    8726 <fwp_write+0x96>
    8877:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    887e:	00 00 
    8880:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8887:	00 
    8888:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    888f:	00 00 
    8891:	0f 85 ce 02 00 00    	jne    8b65 <fwp_write+0x4d5>
    8897:	ba 0a 00 00 00       	mov    $0xa,%edx
    889c:	48 8d 35 77 69 00 00 	lea    0x6977(%rip),%rsi        # f21a <_IO_stdin_used+0x21a>
    88a3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    88aa:	48 89 df             	mov    %rbx,%rdi
    88ad:	5b                   	pop    %rbx
    88ae:	5d                   	pop    %rbp
    88af:	41 5c                	pop    %r12
    88b1:	41 5d                	pop    %r13
    88b3:	41 5e                	pop    %r14
    88b5:	41 5f                	pop    %r15
    88b7:	e9 34 b8 ff ff       	jmp    40f0 <buf_put>
    88bc:	0f 1f 40 00          	nopl   0x0(%rax)
    88c0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    88c5:	4d 85 ed             	test   %r13,%r13
    88c8:	0f 84 02 0c 00 00    	je     94d0 <fwp_write+0xe40>
    88ce:	48 8d 35 8d 69 00 00 	lea    0x698d(%rip),%rsi        # f262 <_IO_stdin_used+0x262>
    88d5:	4c 89 ef             	mov    %r13,%rdi
    88d8:	e8 43 ac ff ff       	call   3520 <strcmp@plt>
    88dd:	41 89 c1             	mov    %eax,%r9d
    88e0:	85 c0                	test   %eax,%eax
    88e2:	0f 84 6c 0c 00 00    	je     9554 <fwp_write+0xec4>
    88e8:	4c 89 ef             	mov    %r13,%rdi
    88eb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    88f0:	e8 4b ab ff ff       	call   3440 <strlen@plt>
    88f5:	4c 89 ee             	mov    %r13,%rsi
    88f8:	48 89 df             	mov    %rbx,%rdi
    88fb:	48 89 c2             	mov    %rax,%rdx
    88fe:	e8 ed b7 ff ff       	call   40f0 <buf_put>
    8903:	ba 01 00 00 00       	mov    $0x1,%edx
    8908:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    890d:	48 89 df             	mov    %rbx,%rdi
    8910:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8915:	e8 d6 b7 ff ff       	call   40f0 <buf_put>
    891a:	ba 01 00 00 00       	mov    $0x1,%edx
    891f:	4c 89 fe             	mov    %r15,%rsi
    8922:	48 89 df             	mov    %rbx,%rdi
    8925:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    892a:	e8 c1 b7 ff ff       	call   40f0 <buf_put>
    892f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8934:	45 31 f6             	xor    %r14d,%r14d
    8937:	85 d2                	test   %edx,%edx
    8939:	0f 8e 81 0a 00 00    	jle    93c0 <fwp_write+0xd30>
    893f:	45 31 ed             	xor    %r13d,%r13d
    8942:	4d 85 ed             	test   %r13,%r13
    8945:	0f 85 75 07 00 00    	jne    90c0 <fwp_write+0xa30>
    894b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8952:	00 
    8953:	45 85 f6             	test   %r14d,%r14d
    8956:	0f 84 84 07 00 00    	je     90e0 <fwp_write+0xa50>
    895c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8961:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8966:	48 89 df             	mov    %rbx,%rdi
    8969:	49 83 c5 01          	add    $0x1,%r13
    896d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8971:	31 c9                	xor    %ecx,%ecx
    8973:	e8 18 fd ff ff       	call   8690 <fwp_write>
    8978:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    897d:	7f c3                	jg     8942 <fwp_write+0x2b2>
    897f:	45 85 f6             	test   %r14d,%r14d
    8982:	0f 84 38 0a 00 00    	je     93c0 <fwp_write+0xd30>
    8988:	b8 29 00 00 00       	mov    $0x29,%eax
    898d:	ba 01 00 00 00       	mov    $0x1,%edx
    8992:	4c 89 fe             	mov    %r15,%rsi
    8995:	48 89 df             	mov    %rbx,%rdi
    8998:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    899c:	e8 4f b7 ff ff       	call   40f0 <buf_put>
    89a1:	e9 80 fd ff ff       	jmp    8726 <fwp_write+0x96>
    89a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    89ad:	00 00 00 
    89b0:	ba 01 00 00 00       	mov    $0x1,%edx
    89b5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    89ba:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    89bf:	e8 2c b7 ff ff       	call   40f0 <buf_put>
    89c4:	48 85 ed             	test   %rbp,%rbp
    89c7:	0f 84 93 06 00 00    	je     9060 <fwp_write+0x9d0>
    89cd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    89d1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    89d6:	31 c9                	xor    %ecx,%ecx
    89d8:	48 89 df             	mov    %rbx,%rdi
    89db:	e8 b0 fc ff ff       	call   8690 <fwp_write>
    89e0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    89e4:	48 85 ed             	test   %rbp,%rbp
    89e7:	0f 84 73 06 00 00    	je     9060 <fwp_write+0x9d0>
    89ed:	ba 02 00 00 00       	mov    $0x2,%edx
    89f2:	48 8d 35 5c 68 00 00 	lea    0x685c(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    89f9:	48 89 df             	mov    %rbx,%rdi
    89fc:	e8 ef b6 ff ff       	call   40f0 <buf_put>
    8a01:	eb ca                	jmp    89cd <fwp_write+0x33d>
    8a03:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8a08:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    8a0c:	85 f6                	test   %esi,%esi
    8a0e:	0f 84 fc 07 00 00    	je     9210 <fwp_write+0xb80>
    8a14:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8a1b:	00 
    8a1c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8a23:	00 00 
    8a25:	0f 85 3a 01 00 00    	jne    8b65 <fwp_write+0x4d5>
    8a2b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    8a2f:	4c 89 ea             	mov    %r13,%rdx
    8a32:	e9 6c fe ff ff       	jmp    88a3 <fwp_write+0x213>
    8a37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8a3e:	00 00 
    8a40:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8a45:	ba 01 00 00 00       	mov    $0x1,%edx
    8a4a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    8a4f:	48 89 ee             	mov    %rbp,%rsi
    8a52:	e8 99 b6 ff ff       	call   40f0 <buf_put>
    8a57:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    8a5c:	4c 89 e7             	mov    %r12,%rdi
    8a5f:	e8 dc a9 ff ff       	call   3440 <strlen@plt>
    8a64:	4c 89 e6             	mov    %r12,%rsi
    8a67:	48 89 df             	mov    %rbx,%rdi
    8a6a:	48 89 c2             	mov    %rax,%rdx
    8a6d:	e8 7e b6 ff ff       	call   40f0 <buf_put>
    8a72:	ba 01 00 00 00       	mov    $0x1,%edx
    8a77:	48 89 ee             	mov    %rbp,%rsi
    8a7a:	48 89 df             	mov    %rbx,%rdi
    8a7d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8a82:	e8 69 b6 ff ff       	call   40f0 <buf_put>
    8a87:	e9 9a fc ff ff       	jmp    8726 <fwp_write+0x96>
    8a8c:	0f 1f 40 00          	nopl   0x0(%rax)
    8a90:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8a95:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8a99:	0f 8a 8e 0b 00 00    	jp     962d <fwp_write+0xf9d>
    8a9f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8aa3:	66 0f 54 05 55 73 00 	andpd  0x7355(%rip),%xmm0        # fe00 <msg.4+0xc0>
    8aaa:	00 
    8aab:	bd 01 00 00 00       	mov    $0x1,%ebp
    8ab0:	66 0f 2e 05 c0 72 00 	ucomisd 0x72c0(%rip),%xmm0        # fd78 <msg.4+0x38>
    8ab7:	00 
    8ab8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8abf:	00 
    8ac0:	0f 87 b2 09 00 00    	ja     9478 <fwp_write+0xde8>
    8ac6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8acd:	00 00 00 
    8ad0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8ad4:	89 ee                	mov    %ebp,%esi
    8ad6:	4c 89 e7             	mov    %r12,%rdi
    8ad9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    8ade:	e8 8d bc ff ff       	call   4770 <fwp_format_g.constprop.0>
    8ae3:	31 f6                	xor    %esi,%esi
    8ae5:	4c 89 e7             	mov    %r12,%rdi
    8ae8:	e8 13 a9 ff ff       	call   3400 <strtod@plt>
    8aed:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8af2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8af6:	7a 06                	jp     8afe <fwp_write+0x46e>
    8af8:	0f 84 e9 01 00 00    	je     8ce7 <fwp_write+0x657>
    8afe:	83 c5 01             	add    $0x1,%ebp
    8b01:	83 fd 12             	cmp    $0x12,%ebp
    8b04:	75 ca                	jne    8ad0 <fwp_write+0x440>
    8b06:	be 11 00 00 00       	mov    $0x11,%esi
    8b0b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8b0f:	4c 89 e7             	mov    %r12,%rdi
    8b12:	e8 59 bc ff ff       	call   4770 <fwp_format_g.constprop.0>
    8b17:	e9 cb 01 00 00       	jmp    8ce7 <fwp_write+0x657>
    8b1c:	0f 1f 40 00          	nopl   0x0(%rax)
    8b20:	48 83 fd 01          	cmp    $0x1,%rbp
    8b24:	0f 84 e6 08 00 00    	je     9410 <fwp_write+0xd80>
    8b2a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8b2e:	b8 02 00 00 00       	mov    $0x2,%eax
    8b33:	ba 01 00 00 00       	mov    $0x1,%edx
    8b38:	48 0f 44 d0          	cmove  %rax,%rdx
    8b3c:	48 8d 35 bb 66 00 00 	lea    0x66bb(%rip),%rsi        # f1fe <_IO_stdin_used+0x1fe>
    8b43:	48 8d 05 b9 66 00 00 	lea    0x66b9(%rip),%rax        # f203 <_IO_stdin_used+0x203>
    8b4a:	48 0f 44 f0          	cmove  %rax,%rsi
    8b4e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8b55:	00 
    8b56:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8b5d:	00 00 
    8b5f:	0f 84 3e fd ff ff    	je     88a3 <fwp_write+0x213>
    8b65:	e8 e6 a8 ff ff       	call   3450 <__stack_chk_fail@plt>
    8b6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8b70:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8b75:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8b7a:	e8 b1 b4 ff ff       	call   4030 <buf_grow>
    8b7f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8b83:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8b89:	4c 03 0b             	add    (%rbx),%r9
    8b8c:	66 45 89 11          	mov    %r10w,(%r9)
    8b90:	45 85 e4             	test   %r12d,%r12d
    8b93:	0f 8e 07 05 00 00    	jle    90a0 <fwp_write+0xa10>
    8b99:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8ba0:	55 55 55 
    8ba3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8ba8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8baf:	aa aa aa 
    8bb2:	49 83 c1 01          	add    $0x1,%r9
    8bb6:	eb 45                	jmp    8bfd <fwp_write+0x56d>
    8bb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8bbf:	00 
    8bc0:	be 01 00 00 00       	mov    $0x1,%esi
    8bc5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    8bca:	88 07                	mov    %al,(%rdi)
    8bcc:	48 89 e8             	mov    %rbp,%rax
    8bcf:	49 f7 e8             	imul   %r8
    8bd2:	48 89 e8             	mov    %rbp,%rax
    8bd5:	48 c1 f8 3f          	sar    $0x3f,%rax
    8bd9:	48 29 c2             	sub    %rax,%rdx
    8bdc:	48 85 c9             	test   %rcx,%rcx
    8bdf:	0f 95 c0             	setne  %al
    8be2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8be6:	48 83 ef 01          	sub    $0x1,%rdi
    8bea:	48 21 c5             	and    %rax,%rbp
    8bed:	48 29 ea             	sub    %rbp,%rdx
    8bf0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8bf4:	49 39 f9             	cmp    %rdi,%r9
    8bf7:	0f 84 a3 04 00 00    	je     90a0 <fwp_write+0xa10>
    8bfd:	48 89 e8             	mov    %rbp,%rax
    8c00:	49 f7 e8             	imul   %r8
    8c03:	48 89 e8             	mov    %rbp,%rax
    8c06:	48 c1 f8 3f          	sar    $0x3f,%rax
    8c0a:	48 89 d1             	mov    %rdx,%rcx
    8c0d:	48 29 c1             	sub    %rax,%rcx
    8c10:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8c14:	48 89 e9             	mov    %rbp,%rcx
    8c17:	48 29 c1             	sub    %rax,%rcx
    8c1a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    8c1e:	49 f7 e2             	mul    %r10
    8c21:	b8 30 00 00 00       	mov    $0x30,%eax
    8c26:	48 89 d6             	mov    %rdx,%rsi
    8c29:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    8c2d:	48 d1 ee             	shr    $1,%rsi
    8c30:	48 01 f2             	add    %rsi,%rdx
    8c33:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8c37:	48 29 d6             	sub    %rdx,%rsi
    8c3a:	74 8e                	je     8bca <fwp_write+0x53a>
    8c3c:	48 83 fe 01          	cmp    $0x1,%rsi
    8c40:	0f 85 7a ff ff ff    	jne    8bc0 <fwp_write+0x530>
    8c46:	31 f6                	xor    %esi,%esi
    8c48:	b8 2b 00 00 00       	mov    $0x2b,%eax
    8c4d:	e9 78 ff ff ff       	jmp    8bca <fwp_write+0x53a>
    8c52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8c58:	66 0f 6e cd          	movd   %ebp,%xmm1
    8c5c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    8c5f:	0f 8a c8 09 00 00    	jp     962d <fwp_write+0xf9d>
    8c65:	0f 28 c1             	movaps %xmm1,%xmm0
    8c68:	0f 54 05 81 71 00 00 	andps  0x7181(%rip),%xmm0        # fdf0 <msg.4+0xb0>
    8c6f:	0f 2e 05 8e 63 00 00 	ucomiss 0x638e(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    8c76:	0f 87 24 08 00 00    	ja     94a0 <fwp_write+0xe10>
    8c7c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8c80:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8c86:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8c8d:	00 
    8c8e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8c92:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8c97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8c9e:	00 00 
    8ca0:	44 89 ee             	mov    %r13d,%esi
    8ca3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8ca8:	4c 89 e7             	mov    %r12,%rdi
    8cab:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8cb0:	e8 bb ba ff ff       	call   4770 <fwp_format_g.constprop.0>
    8cb5:	31 f6                	xor    %esi,%esi
    8cb7:	4c 89 e7             	mov    %r12,%rdi
    8cba:	e8 e1 a7 ff ff       	call   34a0 <strtof@plt>
    8cbf:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8cc4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8cc7:	7a 02                	jp     8ccb <fwp_write+0x63b>
    8cc9:	74 1c                	je     8ce7 <fwp_write+0x657>
    8ccb:	41 83 c5 01          	add    $0x1,%r13d
    8ccf:	41 83 fd 0a          	cmp    $0xa,%r13d
    8cd3:	75 cb                	jne    8ca0 <fwp_write+0x610>
    8cd5:	be 09 00 00 00       	mov    $0x9,%esi
    8cda:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8cdf:	4c 89 e7             	mov    %r12,%rdi
    8ce2:	e8 89 ba ff ff       	call   4770 <fwp_format_g.constprop.0>
    8ce7:	4c 89 e7             	mov    %r12,%rdi
    8cea:	e8 c1 b4 ff ff       	call   41b0 <fwp_finish_float>
    8cef:	e9 1c fa ff ff       	jmp    8710 <fwp_write+0x80>
    8cf4:	0f 1f 40 00          	nopl   0x0(%rax)
    8cf8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8cfc:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8d00:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8d07:	00 
    8d08:	48 89 ef             	mov    %rbp,%rdi
    8d0b:	e8 30 ad ff ff       	call   3a40 <fwp_fmt_u128>
    8d10:	48 89 ef             	mov    %rbp,%rdi
    8d13:	e8 28 a7 ff ff       	call   3440 <strlen@plt>
    8d18:	48 89 ee             	mov    %rbp,%rsi
    8d1b:	48 89 df             	mov    %rbx,%rdi
    8d1e:	48 89 c2             	mov    %rax,%rdx
    8d21:	e8 ca b3 ff ff       	call   40f0 <buf_put>
    8d26:	e9 fb f9 ff ff       	jmp    8726 <fwp_write+0x96>
    8d2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8d30:	ba 06 00 00 00       	mov    $0x6,%edx
    8d35:	48 8d 35 1c 65 00 00 	lea    0x651c(%rip),%rsi        # f258 <_IO_stdin_used+0x258>
    8d3c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8d42:	e8 a9 b3 ff ff       	call   40f0 <buf_put>
    8d47:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8d4e:	ff ff 7f 
    8d51:	48 23 55 00          	and    0x0(%rbp),%rdx
    8d55:	0f 84 86 02 00 00    	je     8fe1 <fwp_write+0x951>
    8d5b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8d60:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8d64:	48 85 d2             	test   %rdx,%rdx
    8d67:	0f 84 ae 00 00 00    	je     8e1b <fwp_write+0x78b>
    8d6d:	8b 0a                	mov    (%rdx),%ecx
    8d6f:	83 f9 1c             	cmp    $0x1c,%ecx
    8d72:	0f 84 58 06 00 00    	je     93d0 <fwp_write+0xd40>
    8d78:	83 f9 1b             	cmp    $0x1b,%ecx
    8d7b:	0f 87 9a 00 00 00    	ja     8e1b <fwp_write+0x78b>
    8d81:	be 01 00 00 00       	mov    $0x1,%esi
    8d86:	48 d3 e6             	shl    %cl,%rsi
    8d89:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8d8f:	0f 85 4b 04 00 00    	jne    91e0 <fwp_write+0xb50>
    8d95:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8d9b:	0f 85 0f 04 00 00    	jne    91b0 <fwp_write+0xb20>
    8da1:	83 e6 21             	and    $0x21,%esi
    8da4:	74 75                	je     8e1b <fwp_write+0x78b>
    8da6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8dab:	48 85 ff             	test   %rdi,%rdi
    8dae:	79 07                	jns    8db7 <fwp_write+0x727>
    8db0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8db4:	4c 01 ee             	add    %r13,%rsi
    8db7:	48 0f be 3e          	movsbq (%rsi),%rdi
    8dbb:	85 c9                	test   %ecx,%ecx
    8dbd:	40 0f b6 f7          	movzbl %dil,%esi
    8dc1:	48 0f 44 f7          	cmove  %rdi,%rsi
    8dc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8dcc:	00 00 00 00 
    8dd0:	31 c9                	xor    %ecx,%ecx
    8dd2:	48 89 df             	mov    %rbx,%rdi
    8dd5:	49 83 c5 01          	add    $0x1,%r13
    8dd9:	e8 b2 f8 ff ff       	call   8690 <fwp_write>
    8dde:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8de5:	ff ff 7f 
    8de8:	48 23 55 00          	and    0x0(%rbp),%rdx
    8dec:	49 39 d5             	cmp    %rdx,%r13
    8def:	0f 83 ec 01 00 00    	jae    8fe1 <fwp_write+0x951>
    8df5:	ba 02 00 00 00       	mov    $0x2,%edx
    8dfa:	48 89 df             	mov    %rbx,%rdi
    8dfd:	48 8d 35 51 64 00 00 	lea    0x6451(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    8e04:	e8 e7 b2 ff ff       	call   40f0 <buf_put>
    8e09:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8e0e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8e12:	48 85 d2             	test   %rdx,%rdx
    8e15:	0f 85 52 ff ff ff    	jne    8d6d <fwp_write+0x6dd>
    8e1b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8e20:	48 85 ff             	test   %rdi,%rdi
    8e23:	0f 88 cf 05 00 00    	js     93f8 <fwp_write+0xd68>
    8e29:	48 8b 31             	mov    (%rcx),%rsi
    8e2c:	eb a2                	jmp    8dd0 <fwp_write+0x740>
    8e2e:	66 90                	xchg   %ax,%ax
    8e30:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8e37:	00 
    8e38:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8e3f:	00 00 
    8e41:	0f 85 1e fd ff ff    	jne    8b65 <fwp_write+0x4d5>
    8e47:	ba 08 00 00 00       	mov    $0x8,%edx
    8e4c:	48 8d 35 d2 63 00 00 	lea    0x63d2(%rip),%rsi        # f225 <_IO_stdin_used+0x225>
    8e53:	e9 4b fa ff ff       	jmp    88a3 <fwp_write+0x213>
    8e58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8e5f:	00 
    8e60:	89 e8                	mov    %ebp,%eax
    8e62:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8e69:	76 03                	jbe    8e6e <fwp_write+0x7de>
    8e6b:	8b 45 00             	mov    0x0(%rbp),%eax
    8e6e:	41 89 c6             	mov    %eax,%r14d
    8e71:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8e76:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8e7b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8e7f:	4c 89 ef             	mov    %r13,%rdi
    8e82:	e8 b9 a5 ff ff       	call   3440 <strlen@plt>
    8e87:	4c 89 ee             	mov    %r13,%rsi
    8e8a:	48 89 df             	mov    %rbx,%rdi
    8e8d:	48 89 c2             	mov    %rax,%rdx
    8e90:	e8 5b b2 ff ff       	call   40f0 <buf_put>
    8e95:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8e9a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8e9e:	85 f6                	test   %esi,%esi
    8ea0:	0f 8e 80 f8 ff ff    	jle    8726 <fwp_write+0x96>
    8ea6:	45 31 ed             	xor    %r13d,%r13d
    8ea9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8eae:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8eb3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8eb8:	ba 01 00 00 00       	mov    $0x1,%edx
    8ebd:	4c 89 fe             	mov    %r15,%rsi
    8ec0:	48 89 04 24          	mov    %rax,(%rsp)
    8ec4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8ec9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8ecd:	48 89 df             	mov    %rbx,%rdi
    8ed0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8ed4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8ed9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8ede:	e8 0d b2 ff ff       	call   40f0 <buf_put>
    8ee3:	41 8b 06             	mov    (%r14),%eax
    8ee6:	83 f8 0e             	cmp    $0xe,%eax
    8ee9:	0f 84 71 02 00 00    	je     9160 <fwp_write+0xad0>
    8eef:	83 f8 10             	cmp    $0x10,%eax
    8ef2:	0f 84 38 02 00 00    	je     9130 <fwp_write+0xaa0>
    8ef8:	83 f8 0a             	cmp    $0xa,%eax
    8efb:	0f 84 7f 04 00 00    	je     9380 <fwp_write+0xcf0>
    8f01:	0f 8f f9 00 00 00    	jg     9000 <fwp_write+0x970>
    8f07:	83 f8 03             	cmp    $0x3,%eax
    8f0a:	0f 8f 50 04 00 00    	jg     9360 <fwp_write+0xcd0>
    8f10:	85 c0                	test   %eax,%eax
    8f12:	78 10                	js     8f24 <fwp_write+0x894>
    8f14:	48 8b 04 24          	mov    (%rsp),%rax
    8f18:	48 c1 e8 3f          	shr    $0x3f,%rax
    8f1c:	85 c0                	test   %eax,%eax
    8f1e:	0f 85 f9 00 00 00    	jne    901d <fwp_write+0x98d>
    8f24:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8f29:	48 8b 34 24          	mov    (%rsp),%rsi
    8f2d:	31 c9                	xor    %ecx,%ecx
    8f2f:	48 89 df             	mov    %rbx,%rdi
    8f32:	e8 59 f7 ff ff       	call   8690 <fwp_write>
    8f37:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8f3c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8f41:	49 83 c5 01          	add    $0x1,%r13
    8f45:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8f49:	0f 8f 5f ff ff ff    	jg     8eae <fwp_write+0x81e>
    8f4f:	e9 d2 f7 ff ff       	jmp    8726 <fwp_write+0x96>
    8f54:	0f 1f 40 00          	nopl   0x0(%rax)
    8f58:	ba 06 00 00 00       	mov    $0x6,%edx
    8f5d:	48 8d 35 e7 62 00 00 	lea    0x62e7(%rip),%rsi        # f24b <_IO_stdin_used+0x24b>
    8f64:	45 31 ed             	xor    %r13d,%r13d
    8f67:	e8 84 b1 ff ff       	call   40f0 <buf_put>
    8f6c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8f71:	75 19                	jne    8f8c <fwp_write+0x8fc>
    8f73:	eb 6c                	jmp    8fe1 <fwp_write+0x951>
    8f75:	0f 1f 00             	nopl   (%rax)
    8f78:	ba 02 00 00 00       	mov    $0x2,%edx
    8f7d:	48 8d 35 d1 62 00 00 	lea    0x62d1(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    8f84:	48 89 df             	mov    %rbx,%rdi
    8f87:	e8 64 b1 ff ff       	call   40f0 <buf_put>
    8f8c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8f92:	b9 00 02 00 00       	mov    $0x200,%ecx
    8f97:	31 c0                	xor    %eax,%eax
    8f99:	49 83 c5 01          	add    $0x1,%r13
    8f9d:	4c 8d 05 ae 62 00 00 	lea    0x62ae(%rip),%r8        # f252 <_IO_stdin_used+0x252>
    8fa4:	ba 02 00 00 00       	mov    $0x2,%edx
    8fa9:	be 00 02 00 00       	mov    $0x200,%esi
    8fae:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8fb5:	00 
    8fb6:	e8 e5 a3 ff ff       	call   33a0 <__snprintf_chk@plt>
    8fbb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8fc2:	00 
    8fc3:	e8 78 a4 ff ff       	call   3440 <strlen@plt>
    8fc8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8fcf:	00 
    8fd0:	48 89 df             	mov    %rbx,%rdi
    8fd3:	48 89 c2             	mov    %rax,%rdx
    8fd6:	e8 15 b1 ff ff       	call   40f0 <buf_put>
    8fdb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8fdf:	72 97                	jb     8f78 <fwp_write+0x8e8>
    8fe1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8fe6:	ba 01 00 00 00       	mov    $0x1,%edx
    8feb:	48 89 df             	mov    %rbx,%rdi
    8fee:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8ff3:	e8 f8 b0 ff ff       	call   40f0 <buf_put>
    8ff8:	e9 29 f7 ff ff       	jmp    8726 <fwp_write+0x96>
    8ffd:	0f 1f 00             	nopl   (%rax)
    9000:	83 f8 0b             	cmp    $0xb,%eax
    9003:	0f 85 1b ff ff ff    	jne    8f24 <fwp_write+0x894>
    9009:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    900e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    9012:	83 e0 01             	and    $0x1,%eax
    9015:	85 c0                	test   %eax,%eax
    9017:	0f 84 07 ff ff ff    	je     8f24 <fwp_write+0x894>
    901d:	4c 89 fe             	mov    %r15,%rsi
    9020:	48 89 df             	mov    %rbx,%rdi
    9023:	ba 01 00 00 00       	mov    $0x1,%edx
    9028:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    902d:	e8 be b0 ff ff       	call   40f0 <buf_put>
    9032:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9037:	48 8b 34 24          	mov    (%rsp),%rsi
    903b:	31 c9                	xor    %ecx,%ecx
    903d:	48 89 df             	mov    %rbx,%rdi
    9040:	e8 4b f6 ff ff       	call   8690 <fwp_write>
    9045:	ba 01 00 00 00       	mov    $0x1,%edx
    904a:	4c 89 fe             	mov    %r15,%rsi
    904d:	48 89 df             	mov    %rbx,%rdi
    9050:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    9055:	e8 96 b0 ff ff       	call   40f0 <buf_put>
    905a:	e9 d8 fe ff ff       	jmp    8f37 <fwp_write+0x8a7>
    905f:	90                   	nop
    9060:	ba 01 00 00 00       	mov    $0x1,%edx
    9065:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    906a:	48 89 df             	mov    %rbx,%rdi
    906d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9072:	e8 79 b0 ff ff       	call   40f0 <buf_put>
    9077:	e9 aa f6 ff ff       	jmp    8726 <fwp_write+0x96>
    907c:	0f 1f 40 00          	nopl   0x0(%rax)
    9080:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9085:	ba 01 00 00 00       	mov    $0x1,%edx
    908a:	48 89 df             	mov    %rbx,%rdi
    908d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    9092:	e8 59 b0 ff ff       	call   40f0 <buf_put>
    9097:	e9 8a f6 ff ff       	jmp    8726 <fwp_write+0x96>
    909c:	0f 1f 40 00          	nopl   0x0(%rax)
    90a0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    90a4:	48 8b 13             	mov    (%rbx),%rdx
    90a7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    90ac:	48 89 43 08          	mov    %rax,0x8(%rbx)
    90b0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    90b4:	e9 6d f6 ff ff       	jmp    8726 <fwp_write+0x96>
    90b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    90c0:	ba 02 00 00 00       	mov    $0x2,%edx
    90c5:	48 8d 35 89 61 00 00 	lea    0x6189(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    90cc:	48 89 df             	mov    %rbx,%rdi
    90cf:	e8 1c b0 ff ff       	call   40f0 <buf_put>
    90d4:	e9 72 f8 ff ff       	jmp    894b <fwp_write+0x2bb>
    90d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    90e0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    90e5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    90ea:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    90ee:	48 89 f7             	mov    %rsi,%rdi
    90f1:	48 89 34 24          	mov    %rsi,(%rsp)
    90f5:	e8 46 a3 ff ff       	call   3440 <strlen@plt>
    90fa:	48 8b 34 24          	mov    (%rsp),%rsi
    90fe:	48 89 df             	mov    %rbx,%rdi
    9101:	48 89 c2             	mov    %rax,%rdx
    9104:	e8 e7 af ff ff       	call   40f0 <buf_put>
    9109:	ba 03 00 00 00       	mov    $0x3,%edx
    910e:	48 8d 35 63 61 00 00 	lea    0x6163(%rip),%rsi        # f278 <_IO_stdin_used+0x278>
    9115:	48 89 df             	mov    %rbx,%rdi
    9118:	e8 d3 af ff ff       	call   40f0 <buf_put>
    911d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9122:	e9 35 f8 ff ff       	jmp    895c <fwp_write+0x2cc>
    9127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    912e:	00 00 
    9130:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9135:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9139:	48 85 ff             	test   %rdi,%rdi
    913c:	0f 84 e2 fd ff ff    	je     8f24 <fwp_write+0x894>
    9142:	48 8d 35 19 61 00 00 	lea    0x6119(%rip),%rsi        # f262 <_IO_stdin_used+0x262>
    9149:	e8 d2 a3 ff ff       	call   3520 <strcmp@plt>
    914e:	85 c0                	test   %eax,%eax
    9150:	0f 95 c0             	setne  %al
    9153:	0f b6 c0             	movzbl %al,%eax
    9156:	e9 c1 fd ff ff       	jmp    8f1c <fwp_write+0x88c>
    915b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9160:	31 c0                	xor    %eax,%eax
    9162:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    9169:	00 
    916a:	0f 97 c0             	seta   %al
    916d:	e9 aa fd ff ff       	jmp    8f1c <fwp_write+0x88c>
    9172:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9178:	48 89 df             	mov    %rbx,%rdi
    917b:	ba 02 00 00 00       	mov    $0x2,%edx
    9180:	48 8d 35 d8 60 00 00 	lea    0x60d8(%rip),%rsi        # f25f <_IO_stdin_used+0x25f>
    9187:	e8 64 af ff ff       	call   40f0 <buf_put>
    918c:	4c 89 e8             	mov    %r13,%rax
    918f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    9194:	31 c9                	xor    %ecx,%ecx
    9196:	48 c1 e0 04          	shl    $0x4,%rax
    919a:	48 89 df             	mov    %rbx,%rdi
    919d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    91a2:	e8 e9 f4 ff ff       	call   8690 <fwp_write>
    91a7:	e9 5e f6 ff ff       	jmp    880a <fwp_write+0x17a>
    91ac:	0f 1f 40 00          	nopl   0x0(%rax)
    91b0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    91b5:	48 85 ff             	test   %rdi,%rdi
    91b8:	79 0c                	jns    91c6 <fwp_write+0xb36>
    91ba:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    91c1:	00 
    91c2:	48 03 75 10          	add    0x10(%rbp),%rsi
    91c6:	48 63 3e             	movslq (%rsi),%rdi
    91c9:	83 f9 02             	cmp    $0x2,%ecx
    91cc:	89 fe                	mov    %edi,%esi
    91ce:	48 0f 44 f7          	cmove  %rdi,%rsi
    91d2:	e9 f9 fb ff ff       	jmp    8dd0 <fwp_write+0x740>
    91d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    91de:	00 00 
    91e0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    91e5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    91ea:	48 85 ff             	test   %rdi,%rdi
    91ed:	0f 88 0f 03 00 00    	js     9502 <fwp_write+0xe72>
    91f3:	49 0f bf 38          	movswq (%r8),%rdi
    91f7:	83 f9 01             	cmp    $0x1,%ecx
    91fa:	0f b7 f7             	movzwl %di,%esi
    91fd:	48 0f 44 f7          	cmove  %rdi,%rsi
    9201:	e9 ca fb ff ff       	jmp    8dd0 <fwp_write+0x740>
    9206:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    920d:	00 00 00 
    9210:	ba 01 00 00 00       	mov    $0x1,%edx
    9215:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    921a:	48 83 c5 08          	add    $0x8,%rbp
    921e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9223:	e8 c8 ae ff ff       	call   40f0 <buf_put>
    9228:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    922d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    9232:	4d 85 ed             	test   %r13,%r13
    9235:	75 46                	jne    927d <fwp_write+0xbed>
    9237:	e9 04 01 00 00       	jmp    9340 <fwp_write+0xcb0>
    923c:	0f 1f 40 00          	nopl   0x0(%rax)
    9240:	41 80 f9 09          	cmp    $0x9,%r9b
    9244:	0f 84 d6 00 00 00    	je     9320 <fwp_write+0xc90>
    924a:	41 80 f9 0a          	cmp    $0xa,%r9b
    924e:	0f 85 9c 00 00 00    	jne    92f0 <fwp_write+0xc60>
    9254:	ba 02 00 00 00       	mov    $0x2,%edx
    9259:	48 8d 35 db 5f 00 00 	lea    0x5fdb(%rip),%rsi        # f23b <_IO_stdin_used+0x23b>
    9260:	48 89 df             	mov    %rbx,%rdi
    9263:	e8 88 ae ff ff       	call   40f0 <buf_put>
    9268:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    926f:	00 
    9270:	48 83 c5 01          	add    $0x1,%rbp
    9274:	49 39 ec             	cmp    %rbp,%r12
    9277:	0f 84 c3 00 00 00    	je     9340 <fwp_write+0xcb0>
    927d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    9282:	41 80 f9 0d          	cmp    $0xd,%r9b
    9286:	74 28                	je     92b0 <fwp_write+0xc20>
    9288:	7e b6                	jle    9240 <fwp_write+0xbb0>
    928a:	41 80 f9 22          	cmp    $0x22,%r9b
    928e:	74 40                	je     92d0 <fwp_write+0xc40>
    9290:	41 80 f9 5c          	cmp    $0x5c,%r9b
    9294:	75 5a                	jne    92f0 <fwp_write+0xc60>
    9296:	ba 02 00 00 00       	mov    $0x2,%edx
    929b:	48 8d 35 96 5f 00 00 	lea    0x5f96(%rip),%rsi        # f238 <_IO_stdin_used+0x238>
    92a2:	48 89 df             	mov    %rbx,%rdi
    92a5:	e8 46 ae ff ff       	call   40f0 <buf_put>
    92aa:	eb c4                	jmp    9270 <fwp_write+0xbe0>
    92ac:	0f 1f 40 00          	nopl   0x0(%rax)
    92b0:	ba 02 00 00 00       	mov    $0x2,%edx
    92b5:	48 8d 35 85 5f 00 00 	lea    0x5f85(%rip),%rsi        # f241 <_IO_stdin_used+0x241>
    92bc:	48 89 df             	mov    %rbx,%rdi
    92bf:	e8 2c ae ff ff       	call   40f0 <buf_put>
    92c4:	eb aa                	jmp    9270 <fwp_write+0xbe0>
    92c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    92cd:	00 00 00 
    92d0:	ba 02 00 00 00       	mov    $0x2,%edx
    92d5:	48 8d 35 59 5f 00 00 	lea    0x5f59(%rip),%rsi        # f235 <_IO_stdin_used+0x235>
    92dc:	48 89 df             	mov    %rbx,%rdi
    92df:	e8 0c ae ff ff       	call   40f0 <buf_put>
    92e4:	eb 8a                	jmp    9270 <fwp_write+0xbe0>
    92e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    92ed:	00 00 00 
    92f0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    92f4:	0f 86 2e 01 00 00    	jbe    9428 <fwp_write+0xd98>
    92fa:	41 80 f9 7f          	cmp    $0x7f,%r9b
    92fe:	0f 84 24 01 00 00    	je     9428 <fwp_write+0xd98>
    9304:	ba 01 00 00 00       	mov    $0x1,%edx
    9309:	4c 89 fe             	mov    %r15,%rsi
    930c:	48 89 df             	mov    %rbx,%rdi
    930f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    9314:	e8 d7 ad ff ff       	call   40f0 <buf_put>
    9319:	e9 52 ff ff ff       	jmp    9270 <fwp_write+0xbe0>
    931e:	66 90                	xchg   %ax,%ax
    9320:	ba 02 00 00 00       	mov    $0x2,%edx
    9325:	48 8d 35 12 5f 00 00 	lea    0x5f12(%rip),%rsi        # f23e <_IO_stdin_used+0x23e>
    932c:	48 89 df             	mov    %rbx,%rdi
    932f:	e8 bc ad ff ff       	call   40f0 <buf_put>
    9334:	e9 37 ff ff ff       	jmp    9270 <fwp_write+0xbe0>
    9339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9340:	ba 01 00 00 00       	mov    $0x1,%edx
    9345:	4c 89 fe             	mov    %r15,%rsi
    9348:	48 89 df             	mov    %rbx,%rdi
    934b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9350:	e8 9b ad ff ff       	call   40f0 <buf_put>
    9355:	e9 cc f3 ff ff       	jmp    8726 <fwp_write+0x96>
    935a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9360:	83 f8 04             	cmp    $0x4,%eax
    9363:	0f 85 bb fb ff ff    	jne    8f24 <fwp_write+0x894>
    9369:	48 8b 04 24          	mov    (%rsp),%rax
    936d:	48 8b 40 08          	mov    0x8(%rax),%rax
    9371:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9376:	48 c1 e8 3f          	shr    $0x3f,%rax
    937a:	e9 96 fc ff ff       	jmp    9015 <fwp_write+0x985>
    937f:	90                   	nop
    9380:	8b 0c 24             	mov    (%rsp),%ecx
    9383:	31 c0                	xor    %eax,%eax
    9385:	85 c9                	test   %ecx,%ecx
    9387:	0f 98 c0             	sets   %al
    938a:	e9 86 fc ff ff       	jmp    9015 <fwp_write+0x985>
    938f:	90                   	nop
    9390:	48 f7 d8             	neg    %rax
    9393:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    939a:	00 
    939b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    93a2:	2d 
    93a3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    93aa:	00 
    93ab:	48 83 d2 00          	adc    $0x0,%rdx
    93af:	48 89 c6             	mov    %rax,%rsi
    93b2:	48 f7 da             	neg    %rdx
    93b5:	e8 86 a6 ff ff       	call   3a40 <fwp_fmt_u128>
    93ba:	e9 51 f3 ff ff       	jmp    8710 <fwp_write+0x80>
    93bf:	90                   	nop
    93c0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    93c5:	e9 c3 f5 ff ff       	jmp    898d <fwp_write+0x2fd>
    93ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    93d0:	4c 89 e9             	mov    %r13,%rcx
    93d3:	48 c1 e1 04          	shl    $0x4,%rcx
    93d7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    93dc:	48 85 ff             	test   %rdi,%rdi
    93df:	0f 89 eb f9 ff ff    	jns    8dd0 <fwp_write+0x740>
    93e5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    93e9:	48 89 ce             	mov    %rcx,%rsi
    93ec:	e9 df f9 ff ff       	jmp    8dd0 <fwp_write+0x740>
    93f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    93f8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    93ff:	00 
    9400:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9404:	e9 20 fa ff ff       	jmp    8e29 <fwp_write+0x799>
    9409:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9410:	ba 02 00 00 00       	mov    $0x2,%edx
    9415:	48 8d 35 e4 5d 00 00 	lea    0x5de4(%rip),%rsi        # f200 <_IO_stdin_used+0x200>
    941c:	e9 2d f7 ff ff       	jmp    8b4e <fwp_write+0x4be>
    9421:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9428:	4c 8d 05 15 5e 00 00 	lea    0x5e15(%rip),%r8        # f244 <_IO_stdin_used+0x244>
    942f:	b9 10 00 00 00       	mov    $0x10,%ecx
    9434:	31 c0                	xor    %eax,%eax
    9436:	ba 02 00 00 00       	mov    $0x2,%edx
    943b:	be 10 00 00 00       	mov    $0x10,%esi
    9440:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9447:	00 
    9448:	e8 53 9f ff ff       	call   33a0 <__snprintf_chk@plt>
    944d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9454:	00 
    9455:	e8 e6 9f ff ff       	call   3440 <strlen@plt>
    945a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9461:	00 
    9462:	48 89 df             	mov    %rbx,%rdi
    9465:	48 89 c2             	mov    %rax,%rdx
    9468:	e8 83 ac ff ff       	call   40f0 <buf_put>
    946d:	e9 fe fd ff ff       	jmp    9270 <fwp_write+0xbe0>
    9472:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9478:	66 0f ef c0          	pxor   %xmm0,%xmm0
    947c:	48 8d 35 77 5d 00 00 	lea    0x5d77(%rip),%rsi        # f1fa <_IO_stdin_used+0x1fa>
    9483:	48 8d 05 6f 5d 00 00 	lea    0x5d6f(%rip),%rax        # f1f9 <_IO_stdin_used+0x1f9>
    948a:	4c 89 e7             	mov    %r12,%rdi
    948d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9491:	48 0f 46 f0          	cmovbe %rax,%rsi
    9495:	e8 46 9f ff ff       	call   33e0 <strcpy@plt>
    949a:	e9 71 f2 ff ff       	jmp    8710 <fwp_write+0x80>
    949f:	90                   	nop
    94a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    94a4:	48 8d 35 4f 5d 00 00 	lea    0x5d4f(%rip),%rsi        # f1fa <_IO_stdin_used+0x1fa>
    94ab:	48 8d 05 47 5d 00 00 	lea    0x5d47(%rip),%rax        # f1f9 <_IO_stdin_used+0x1f9>
    94b2:	0f 2f c8             	comiss %xmm0,%xmm1
    94b5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    94bc:	00 
    94bd:	4c 89 e7             	mov    %r12,%rdi
    94c0:	48 0f 46 f0          	cmovbe %rax,%rsi
    94c4:	e8 17 9f ff ff       	call   33e0 <strcpy@plt>
    94c9:	e9 42 f2 ff ff       	jmp    8710 <fwp_write+0x80>
    94ce:	66 90                	xchg   %ax,%ax
    94d0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    94d5:	45 85 c0             	test   %r8d,%r8d
    94d8:	75 34                	jne    950e <fwp_write+0xe7e>
    94da:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    94e1:	00 
    94e2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    94e9:	00 00 
    94eb:	0f 85 74 f6 ff ff    	jne    8b65 <fwp_write+0x4d5>
    94f1:	ba 02 00 00 00       	mov    $0x2,%edx
    94f6:	48 8d 35 78 5d 00 00 	lea    0x5d78(%rip),%rsi        # f275 <_IO_stdin_used+0x275>
    94fd:	e9 a1 f3 ff ff       	jmp    88a3 <fwp_write+0x213>
    9502:	48 03 75 10          	add    0x10(%rbp),%rsi
    9506:	49 89 f0             	mov    %rsi,%r8
    9509:	e9 e5 fc ff ff       	jmp    91f3 <fwp_write+0xb63>
    950e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9513:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9518:	85 ff                	test   %edi,%edi
    951a:	0f 84 fa f3 ff ff    	je     891a <fwp_write+0x28a>
    9520:	ba 01 00 00 00       	mov    $0x1,%edx
    9525:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    952a:	48 89 df             	mov    %rbx,%rdi
    952d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9532:	e8 b9 ab ff ff       	call   40f0 <buf_put>
    9537:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    953c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9541:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9547:	85 c0                	test   %eax,%eax
    9549:	0f 8f f0 f3 ff ff    	jg     893f <fwp_write+0x2af>
    954f:	e9 34 f4 ff ff       	jmp    8988 <fwp_write+0x2f8>
    9554:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9558:	49 89 c5             	mov    %rax,%r13
    955b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9560:	49 89 c4             	mov    %rax,%r12
    9563:	49 c1 fd 3f          	sar    $0x3f,%r13
    9567:	4c 09 e8             	or     %r13,%rax
    956a:	0f 84 a7 00 00 00    	je     9617 <fwp_write+0xf87>
    9570:	48 8d 2d 49 7d 00 00 	lea    0x7d49(%rip),%rbp        # 112c0 <units.0>
    9577:	4d 89 e7             	mov    %r12,%r15
    957a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    957e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9583:	4c 89 ff             	mov    %r15,%rdi
    9586:	4c 89 ee             	mov    %r13,%rsi
    9589:	44 89 0c 24          	mov    %r9d,(%rsp)
    958d:	48 99                	cqto
    958f:	48 89 d1             	mov    %rdx,%rcx
    9592:	48 89 c2             	mov    %rax,%rdx
    9595:	e8 26 50 00 00       	call   e5c0 <__divmodti4>
    959a:	44 8b 0c 24          	mov    (%rsp),%r9d
    959e:	48 89 c1             	mov    %rax,%rcx
    95a1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    95a6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    95ab:	0f 84 94 00 00 00    	je     9645 <fwp_write+0xfb5>
    95b1:	41 83 c1 01          	add    $0x1,%r9d
    95b5:	48 83 c5 10          	add    $0x10,%rbp
    95b9:	41 83 f9 05          	cmp    $0x5,%r9d
    95bd:	75 bb                	jne    957a <fwp_write+0xeea>
    95bf:	4d 85 ed             	test   %r13,%r13
    95c2:	79 53                	jns    9617 <fwp_write+0xf87>
    95c4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    95c9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    95ce:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    95d3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    95d8:	48 99                	cqto
    95da:	48 f7 d8             	neg    %rax
    95dd:	48 83 d2 00          	adc    $0x0,%rdx
    95e1:	48 89 c6             	mov    %rax,%rsi
    95e4:	48 f7 da             	neg    %rdx
    95e7:	e8 54 a4 ff ff       	call   3a40 <fwp_fmt_u128>
    95ec:	49 89 e8             	mov    %rbp,%r8
    95ef:	ba 00 02 00 00       	mov    $0x200,%edx
    95f4:	be 02 00 00 00       	mov    $0x2,%esi
    95f9:	31 c0                	xor    %eax,%eax
    95fb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9602:	00 
    9603:	48 8d 0d 66 5c 00 00 	lea    0x5c66(%rip),%rcx        # f270 <_IO_stdin_used+0x270>
    960a:	4c 89 e7             	mov    %r12,%rdi
    960d:	e8 ae a0 ff ff       	call   36c0 <__sprintf_chk@plt>
    9612:	e9 f9 f0 ff ff       	jmp    8710 <fwp_write+0x80>
    9617:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    961c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9621:	31 d2                	xor    %edx,%edx
    9623:	48 89 ef             	mov    %rbp,%rdi
    9626:	e8 15 a4 ff ff       	call   3a40 <fwp_fmt_u128>
    962b:	eb bf                	jmp    95ec <fwp_write+0xf5c>
    962d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9634:	4e 61 4e 00 
    9638:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    963f:	00 
    9640:	e9 cb f0 ff ff       	jmp    8710 <fwp_write+0x80>
    9645:	44 89 0c 24          	mov    %r9d,(%rsp)
    9649:	48 89 c8             	mov    %rcx,%rax
    964c:	48 85 d2             	test   %rdx,%rdx
    964f:	78 51                	js     96a2 <fwp_write+0x1012>
    9651:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9656:	48 89 c6             	mov    %rax,%rsi
    9659:	48 89 ef             	mov    %rbp,%rdi
    965c:	e8 df a3 ff ff       	call   3a40 <fwp_fmt_u128>
    9661:	44 8b 0c 24          	mov    (%rsp),%r9d
    9665:	49 63 c1             	movslq %r9d,%rax
    9668:	49 89 e8             	mov    %rbp,%r8
    966b:	ba 00 02 00 00       	mov    $0x200,%edx
    9670:	be 02 00 00 00       	mov    $0x2,%esi
    9675:	48 c1 e0 04          	shl    $0x4,%rax
    9679:	48 8d 3d 40 7c 00 00 	lea    0x7c40(%rip),%rdi        # 112c0 <units.0>
    9680:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9687:	00 
    9688:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    968c:	48 8d 0d d8 5b 00 00 	lea    0x5bd8(%rip),%rcx        # f26b <_IO_stdin_used+0x26b>
    9693:	4c 89 e7             	mov    %r12,%rdi
    9696:	31 c0                	xor    %eax,%eax
    9698:	e8 23 a0 ff ff       	call   36c0 <__sprintf_chk@plt>
    969d:	e9 6e f0 ff ff       	jmp    8710 <fwp_write+0x80>
    96a2:	48 f7 d8             	neg    %rax
    96a5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    96aa:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    96af:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    96b4:	48 83 d2 00          	adc    $0x0,%rdx
    96b8:	48 89 c6             	mov    %rax,%rsi
    96bb:	48 f7 da             	neg    %rdx
    96be:	e8 7d a3 ff ff       	call   3a40 <fwp_fmt_u128>
    96c3:	44 8b 0c 24          	mov    (%rsp),%r9d
    96c7:	eb 9c                	jmp    9665 <fwp_write+0xfd5>
    96c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000096d0 <fwp_hof0.constprop.0>:
    96d0:	41 57                	push   %r15
    96d2:	41 56                	push   %r14
    96d4:	41 55                	push   %r13
    96d6:	41 54                	push   %r12
    96d8:	55                   	push   %rbp
    96d9:	53                   	push   %rbx
    96da:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    96e1:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    96e8:	00 00 
    96ea:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    96f1:	00 
    96f2:	31 c0                	xor    %eax,%eax
    96f4:	48 85 f6             	test   %rsi,%rsi
    96f7:	0f 84 1a 0f 00 00    	je     a617 <fwp_hof0.constprop.0+0xf47>
    96fd:	48 89 74 24 48       	mov    %rsi,0x48(%rsp)
    9702:	48 8d 2d 17 21 06 00 	lea    0x62117(%rip),%rbp        # 6b820 <fwp_heap>
    9709:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
    970e:	66 90                	xchg   %ax,%ax
    9710:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9717:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    971c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9723:	48 c1 e2 10          	shl    $0x10,%rdx
    9727:	48 39 d0             	cmp    %rdx,%rax
    972a:	73 71                	jae    979d <fwp_hof0.constprop.0+0xcd>
    972c:	48 89 c2             	mov    %rax,%rdx
    972f:	48 c1 ea 10          	shr    $0x10,%rdx
    9733:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9737:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    973e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9742:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9746:	48 85 ff             	test   %rdi,%rdi
    9749:	74 52                	je     979d <fwp_hof0.constprop.0+0xcd>
    974b:	0f b6 0a             	movzbl (%rdx),%ecx
    974e:	80 f9 02             	cmp    $0x2,%cl
    9751:	0f 84 b1 15 00 00    	je     ad08 <fwp_hof0.constprop.0+0x1638>
    9757:	80 f9 01             	cmp    $0x1,%cl
    975a:	75 41                	jne    979d <fwp_hof0.constprop.0+0xcd>
    975c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    975f:	0f b7 c0             	movzwl %ax,%eax
    9762:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9765:	48 0f af c1          	imul   %rcx,%rax
    9769:	48 c1 e8 20          	shr    $0x20,%rax
    976d:	48 39 d0             	cmp    %rdx,%rax
    9770:	73 2b                	jae    979d <fwp_hof0.constprop.0+0xcd>
    9772:	48 01 c7             	add    %rax,%rdi
    9775:	0f b6 07             	movzbl (%rdi),%eax
    9778:	84 c0                	test   %al,%al
    977a:	74 21                	je     979d <fwp_hof0.constprop.0+0xcd>
    977c:	44 8b 0d 65 3d 06 00 	mov    0x63d65(%rip),%r9d        # 6d4e8 <iteration_active>
    9783:	45 85 c9             	test   %r9d,%r9d
    9786:	74 08                	je     9790 <fwp_hof0.constprop.0+0xc0>
    9788:	48 83 05 40 3d 06 00 	addq   $0x1,0x63d40(%rip)        # 6d4d0 <iteration_retains>
    978f:	01 
    9790:	3c fd                	cmp    $0xfd,%al
    9792:	0f 87 46 17 00 00    	ja     aede <fwp_hof0.constprop.0+0x180e>
    9798:	83 c0 01             	add    $0x1,%eax
    979b:	88 07                	mov    %al,(%rdi)
    979d:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    97a2:	45 31 c0             	xor    %r8d,%r8d
    97a5:	48 c7 44 24 28 c6 00 	movq   $0xc6,0x28(%rsp)
    97ac:	00 00 
    97ae:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    97b3:	4d 89 c5             	mov    %r8,%r13
    97b6:	4d 85 c0             	test   %r8,%r8
    97b9:	0f 85 91 9f ff ff    	jne    3750 <fwp_hof0.constprop.0.cold+0x5>
    97bf:	48 8b 05 f2 3c 06 00 	mov    0x63cf2(%rip),%rax        # 6d4b8 <fwp_cleanups>
    97c6:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    97cd:	4c 8d 3d ec d7 ff ff 	lea    -0x2814(%rip),%r15        # 6fc0 <fwp_tape_scope_release>
    97d4:	c7 44 24 7c ff ff ff 	movl   $0xffffffff,0x7c(%rsp)
    97db:	ff 
    97dc:	4c 89 bc 24 88 00 00 	mov    %r15,0x88(%rsp)
    97e3:	00 
    97e4:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    97eb:	00 
    97ec:	48 8d 44 24 7c       	lea    0x7c(%rsp),%rax
    97f1:	48 c1 e2 10          	shl    $0x10,%rdx
    97f5:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    97fa:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    9801:	00 
    9802:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    9809:	00 
    980a:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    980f:	48 89 05 a2 3c 06 00 	mov    %rax,0x63ca2(%rip)        # 6d4b8 <fwp_cleanups>
    9816:	48 8d 05 f3 97 00 00 	lea    0x97f3(%rip),%rax        # 13010 <fc37>
    981d:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9824:	48 39 d0             	cmp    %rdx,%rax
    9827:	73 71                	jae    989a <fwp_hof0.constprop.0+0x1ca>
    9829:	48 89 c2             	mov    %rax,%rdx
    982c:	48 c1 ea 10          	shr    $0x10,%rdx
    9830:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9834:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    983b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    983f:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9843:	48 85 ff             	test   %rdi,%rdi
    9846:	74 52                	je     989a <fwp_hof0.constprop.0+0x1ca>
    9848:	0f b6 0a             	movzbl (%rdx),%ecx
    984b:	80 f9 02             	cmp    $0x2,%cl
    984e:	0f 84 ac 12 00 00    	je     ab00 <fwp_hof0.constprop.0+0x1430>
    9854:	80 f9 01             	cmp    $0x1,%cl
    9857:	75 41                	jne    989a <fwp_hof0.constprop.0+0x1ca>
    9859:	8b 4a 18             	mov    0x18(%rdx),%ecx
    985c:	0f b7 c0             	movzwl %ax,%eax
    985f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9862:	48 0f af c1          	imul   %rcx,%rax
    9866:	48 c1 e8 20          	shr    $0x20,%rax
    986a:	48 39 d0             	cmp    %rdx,%rax
    986d:	73 2b                	jae    989a <fwp_hof0.constprop.0+0x1ca>
    986f:	48 01 c7             	add    %rax,%rdi
    9872:	0f b6 07             	movzbl (%rdi),%eax
    9875:	84 c0                	test   %al,%al
    9877:	74 21                	je     989a <fwp_hof0.constprop.0+0x1ca>
    9879:	44 8b 05 68 3c 06 00 	mov    0x63c68(%rip),%r8d        # 6d4e8 <iteration_active>
    9880:	45 85 c0             	test   %r8d,%r8d
    9883:	74 08                	je     988d <fwp_hof0.constprop.0+0x1bd>
    9885:	48 83 05 43 3c 06 00 	addq   $0x1,0x63c43(%rip)        # 6d4d0 <iteration_retains>
    988c:	01 
    988d:	3c fd                	cmp    $0xfd,%al
    988f:	0f 87 e5 15 00 00    	ja     ae7a <fwp_hof0.constprop.0+0x17aa>
    9895:	83 c0 01             	add    $0x1,%eax
    9898:	88 07                	mov    %al,(%rdi)
    989a:	48 8d 3d 6f 97 00 00 	lea    0x976f(%rip),%rdi        # 13010 <fc37>
    98a1:	e8 9a d3 ff ff       	call   6c40 <fwp_closure_drop>
    98a6:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    98ab:	48 85 c0             	test   %rax,%rax
    98ae:	0f 84 d7 14 00 00    	je     ad8b <fwp_hof0.constprop.0+0x16bb>
    98b4:	31 d2                	xor    %edx,%edx
    98b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    98bd:	00 00 00 
    98c0:	48 8b 40 10          	mov    0x10(%rax),%rax
    98c4:	48 83 c2 01          	add    $0x1,%rdx
    98c8:	48 85 c0             	test   %rax,%rax
    98cb:	75 f3                	jne    98c0 <fwp_hof0.constprop.0+0x1f0>
    98cd:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    98d4:	0f 87 c6 16 00 00    	ja     afa0 <fwp_hof0.constprop.0+0x18d0>
    98da:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    98df:	8b 35 7b 97 00 00    	mov    0x977b(%rip),%esi        # 13060 <registered_finish.1>
    98e5:	85 f6                	test   %esi,%esi
    98e7:	0f 84 d3 11 00 00    	je     aac0 <fwp_hof0.constprop.0+0x13f0>
    98ed:	4c 8b 35 e4 97 01 00 	mov    0x197e4(%rip),%r14        # 230d8 <fwp_tape_next_slot>
    98f4:	48 8b 1d ed 97 01 00 	mov    0x197ed(%rip),%rbx        # 230e8 <fwp_ntapes>
    98fb:	49 39 de             	cmp    %rbx,%r14
    98fe:	0f 8d ec 0d 00 00    	jge    a6f0 <fwp_hof0.constprop.0+0x1020>
    9904:	49 6b c6 68          	imul   $0x68,%r14,%rax
    9908:	48 03 05 e1 97 01 00 	add    0x197e1(%rip),%rax        # 230f0 <fwp_tapes>
    990f:	90                   	nop
    9910:	8b 48 04             	mov    0x4(%rax),%ecx
    9913:	85 c9                	test   %ecx,%ecx
    9915:	75 0c                	jne    9923 <fwp_hof0.constprop.0+0x253>
    9917:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    991d:	0f 86 cd 0d 00 00    	jbe    a6f0 <fwp_hof0.constprop.0+0x1020>
    9923:	49 83 c6 01          	add    $0x1,%r14
    9927:	48 83 c0 68          	add    $0x68,%rax
    992b:	49 39 de             	cmp    %rbx,%r14
    992e:	75 e0                	jne    9910 <fwp_hof0.constprop.0+0x240>
    9930:	48 81 fb fe ff 00 00 	cmp    $0xfffe,%rbx
    9937:	0f 8f 7b 16 00 00    	jg     afb8 <fwp_hof0.constprop.0+0x18e8>
    993d:	48 3b 1d 9c 97 01 00 	cmp    0x1979c(%rip),%rbx        # 230e0 <fwp_tapes_cap>
    9944:	4c 8b 25 a5 97 01 00 	mov    0x197a5(%rip),%r12        # 230f0 <fwp_tapes>
    994b:	75 4d                	jne    999a <fwp_hof0.constprop.0+0x2ca>
    994d:	48 85 db             	test   %rbx,%rbx
    9950:	0f 84 9b 14 00 00    	je     adf1 <fwp_hof0.constprop.0+0x1721>
    9956:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    995a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    995f:	49 39 c6             	cmp    %rax,%r14
    9962:	4c 0f 4f f0          	cmovg  %rax,%r14
    9966:	49 6b f6 68          	imul   $0x68,%r14,%rsi
    996a:	31 d2                	xor    %edx,%edx
    996c:	4c 89 e7             	mov    %r12,%rdi
    996f:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    9975:	e8 16 b8 ff ff       	call   5190 <ad_raw_realloc>
    997a:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    9980:	48 85 c0             	test   %rax,%rax
    9983:	49 89 c4             	mov    %rax,%r12
    9986:	0f 84 80 16 00 00    	je     b00c <fwp_hof0.constprop.0+0x193c>
    998c:	48 89 05 5d 97 01 00 	mov    %rax,0x1975d(%rip)        # 230f0 <fwp_tapes>
    9993:	4c 89 35 46 97 01 00 	mov    %r14,0x19746(%rip)        # 230e0 <fwp_tapes_cap>
    999a:	48 6b cb 68          	imul   $0x68,%rbx,%rcx
    999e:	31 c0                	xor    %eax,%eax
    99a0:	49 89 de             	mov    %rbx,%r14
    99a3:	4c 01 e1             	add    %r12,%rcx
    99a6:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    99aa:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    99b1:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    99b5:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    99bc:	00 
    99bd:	48 29 f9             	sub    %rdi,%rcx
    99c0:	83 c1 68             	add    $0x68,%ecx
    99c3:	c1 e9 03             	shr    $0x3,%ecx
    99c6:	f3 48 ab             	rep stos %rax,(%rdi)
    99c9:	48 8d 43 01          	lea    0x1(%rbx),%rax
    99cd:	48 89 05 14 97 01 00 	mov    %rax,0x19714(%rip)        # 230e8 <fwp_ntapes>
    99d4:	49 6b de 68          	imul   $0x68,%r14,%rbx
    99d8:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    99dc:	48 8d 3d 7d 57 00 00 	lea    0x577d(%rip),%rdi        # f160 <_IO_stdin_used+0x160>
    99e3:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    99e8:	4c 01 e3             	add    %r12,%rbx
    99eb:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    99f2:	00 
    99f3:	e8 98 99 ff ff       	call   3390 <getenv@plt>
    99f8:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    99fe:	48 85 c0             	test   %rax,%rax
    9a01:	0f 84 01 0d 00 00    	je     a708 <fwp_hof0.constprop.0+0x1038>
    9a07:	80 38 30             	cmpb   $0x30,(%rax)
    9a0a:	0f 85 f8 0c 00 00    	jne    a708 <fwp_hof0.constprop.0+0x1038>
    9a10:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9a14:	0f 85 ee 0c 00 00    	jne    a708 <fwp_hof0.constprop.0+0x1038>
    9a1a:	8b 03                	mov    (%rbx),%eax
    9a1c:	49 8d 76 01          	lea    0x1(%r14),%rsi
    9a20:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    9a24:	c7 43 04 01 00 00 00 	movl   $0x1,0x4(%rbx)
    9a2b:	8d 48 01             	lea    0x1(%rax),%ecx
    9a2e:	48 8b 05 2b 63 00 00 	mov    0x632b(%rip),%rax        # fd60 <msg.4+0x20>
    9a35:	48 89 35 9c 96 01 00 	mov    %rsi,0x1969c(%rip)        # 230d8 <fwp_tape_next_slot>
    9a3c:	89 0b                	mov    %ecx,(%rbx)
    9a3e:	48 89 43 58          	mov    %rax,0x58(%rbx)
    9a42:	48 8b 05 6f 3a 06 00 	mov    0x63a6f(%rip),%rax        # 6d4b8 <fwp_cleanups>
    9a49:	48 c7 43 50 00 00 00 	movq   $0x0,0x50(%rbx)
    9a50:	00 
    9a51:	48 85 c0             	test   %rax,%rax
    9a54:	75 16                	jne    9a6c <fwp_hof0.constprop.0+0x39c>
    9a56:	e9 a5 15 00 00       	jmp    b000 <fwp_hof0.constprop.0+0x1930>
    9a5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9a60:	48 8b 00             	mov    (%rax),%rax
    9a63:	48 85 c0             	test   %rax,%rax
    9a66:	0f 84 94 15 00 00    	je     b000 <fwp_hof0.constprop.0+0x1930>
    9a6c:	4c 39 78 08          	cmp    %r15,0x8(%rax)
    9a70:	75 ee                	jne    9a60 <fwp_hof0.constprop.0+0x390>
    9a72:	4c 8b 48 10          	mov    0x10(%rax),%r9
    9a76:	44 89 f7             	mov    %r14d,%edi
    9a79:	49 63 01             	movslq (%r9),%rax
    9a7c:	4c 89 4b 50          	mov    %r9,0x50(%rbx)
    9a80:	89 43 5c             	mov    %eax,0x5c(%rbx)
    9a83:	85 c0                	test   %eax,%eax
    9a85:	78 09                	js     9a90 <fwp_hof0.constprop.0+0x3c0>
    9a87:	48 6b c0 68          	imul   $0x68,%rax,%rax
    9a8b:	45 89 74 04 58       	mov    %r14d,0x58(%r12,%rax,1)
    9a90:	41 89 39             	mov    %edi,(%r9)
    9a93:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9a98:	31 db                	xor    %ebx,%ebx
    9a9a:	48 89 f8             	mov    %rdi,%rax
    9a9d:	48 85 ff             	test   %rdi,%rdi
    9aa0:	0f 84 aa 0d 00 00    	je     a850 <fwp_hof0.constprop.0+0x1180>
    9aa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9aad:	00 00 00 
    9ab0:	48 8b 40 10          	mov    0x10(%rax),%rax
    9ab4:	48 83 c3 01          	add    $0x1,%rbx
    9ab8:	48 85 c0             	test   %rax,%rax
    9abb:	75 f3                	jne    9ab0 <fwp_hof0.constprop.0+0x3e0>
    9abd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9ac2:	0f 1f 00             	nopl   (%rax)
    9ac5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9acc:	00 00 00 00 
    9ad0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9ad4:	48 83 c0 01          	add    $0x1,%rax
    9ad8:	48 85 d2             	test   %rdx,%rdx
    9adb:	75 f3                	jne    9ad0 <fwp_hof0.constprop.0+0x400>
    9add:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    9ae4:	ff ff 1f 
    9ae7:	48 39 c2             	cmp    %rax,%rdx
    9aea:	0f 82 a4 14 00 00    	jb     af94 <fwp_hof0.constprop.0+0x18c4>
    9af0:	48 85 db             	test   %rbx,%rbx
    9af3:	0f 8e 57 0d 00 00    	jle    a850 <fwp_hof0.constprop.0+0x1180>
    9af9:	48 39 c3             	cmp    %rax,%rbx
    9afc:	48 0f 47 d8          	cmova  %rax,%rbx
    9b00:	48 89 d8             	mov    %rbx,%rax
    9b03:	48 c1 e8 3c          	shr    $0x3c,%rax
    9b07:	0f 85 87 14 00 00    	jne    af94 <fwp_hof0.constprop.0+0x18c4>
    9b0d:	4c 8d 3c 1b          	lea    (%rbx,%rbx,1),%r15
    9b11:	48 c1 e1 10          	shl    $0x10,%rcx
    9b15:	48 09 f1             	or     %rsi,%rcx
    9b18:	4a 8d 3c fd 08 00 00 	lea    0x8(,%r15,8),%rdi
    9b1f:	00 
    9b20:	be 02 00 00 00       	mov    $0x2,%esi
    9b25:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    9b2a:	e8 e1 c3 ff ff       	call   5f10 <fwp_heap_alloc>
    9b2f:	4c 89 38             	mov    %r15,(%rax)
    9b32:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9b39:	49 89 c6             	mov    %rax,%r14
    9b3c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9b43:	48 c1 e2 10          	shl    $0x10,%rdx
    9b47:	48 39 d0             	cmp    %rdx,%rax
    9b4a:	0f 83 f0 10 00 00    	jae    ac40 <fwp_hof0.constprop.0+0x1570>
    9b50:	48 89 c2             	mov    %rax,%rdx
    9b53:	48 c1 ea 10          	shr    $0x10,%rdx
    9b57:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9b5b:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9b62:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9b66:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    9b6a:	4d 85 ff             	test   %r15,%r15
    9b6d:	74 38                	je     9ba7 <fwp_hof0.constprop.0+0x4d7>
    9b6f:	0f b6 0a             	movzbl (%rdx),%ecx
    9b72:	80 f9 02             	cmp    $0x2,%cl
    9b75:	0f 84 46 0d 00 00    	je     a8c1 <fwp_hof0.constprop.0+0x11f1>
    9b7b:	80 f9 01             	cmp    $0x1,%cl
    9b7e:	75 27                	jne    9ba7 <fwp_hof0.constprop.0+0x4d7>
    9b80:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9b83:	0f b7 c0             	movzwl %ax,%eax
    9b86:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9b89:	48 0f af c1          	imul   %rcx,%rax
    9b8d:	48 c1 e8 20          	shr    $0x20,%rax
    9b91:	48 39 d0             	cmp    %rdx,%rax
    9b94:	73 11                	jae    9ba7 <fwp_hof0.constprop.0+0x4d7>
    9b96:	49 01 c7             	add    %rax,%r15
    9b99:	41 80 3f ff          	cmpb   $0xff,(%r15)
    9b9d:	0f 84 31 0d 00 00    	je     a8d4 <fwp_hof0.constprop.0+0x1204>
    9ba3:	41 c6 07 01          	movb   $0x1,(%r15)
    9ba7:	48 85 db             	test   %rbx,%rbx
    9baa:	74 48                	je     9bf4 <fwp_hof0.constprop.0+0x524>
    9bac:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    9bb1:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9bb6:	31 c0                	xor    %eax,%eax
    9bb8:	48 c1 e1 20          	shl    $0x20,%rcx
    9bbc:	0f 1f 40 00          	nopl   0x0(%rax)
    9bc0:	48 89 c6             	mov    %rax,%rsi
    9bc3:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    9bc8:	48 01 ce             	add    %rcx,%rsi
    9bcb:	0f 80 7f 9b ff ff    	jo     3750 <fwp_hof0.constprop.0.cold+0x5>
    9bd1:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    9bd6:	48 89 c6             	mov    %rax,%rsi
    9bd9:	48 83 c0 01          	add    $0x1,%rax
    9bdd:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    9be1:	48 c1 e6 04          	shl    $0x4,%rsi
    9be5:	41 0f 11 44 36 08    	movups %xmm0,0x8(%r14,%rsi,1)
    9beb:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9bef:	48 39 d8             	cmp    %rbx,%rax
    9bf2:	72 cc                	jb     9bc0 <fwp_hof0.constprop.0+0x4f0>
    9bf4:	49 8b 06             	mov    (%r14),%rax
    9bf7:	48 d1 e8             	shr    $1,%rax
    9bfa:	0f 85 00 0d 00 00    	jne    a900 <fwp_hof0.constprop.0+0x1230>
    9c00:	49 c7 06 00 00 00 00 	movq   $0x0,(%r14)
    9c07:	49 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%r9
    9c0e:	66 90                	xchg   %ax,%ax
    9c10:	4c 89 f7             	mov    %r14,%rdi
    9c13:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    9c18:	e8 f3 e2 ff ff       	call   7f10 <fwp_drop10>
    9c1d:	4c 63 7c 24 10       	movslq 0x10(%rsp),%r15
    9c22:	4c 89 ff             	mov    %r15,%rdi
    9c25:	e8 06 ab ff ff       	call   4730 <fwp_tape_of>
    9c2a:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    9c2f:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    9c34:	48 89 c6             	mov    %rax,%rsi
    9c37:	0f 85 44 14 00 00    	jne    b081 <fwp_hof0.constprop.0+0x19b1>
    9c3d:	48 89 c7             	mov    %rax,%rdi
    9c40:	e8 4b a0 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    9c45:	48 8b 5e 48          	mov    0x48(%rsi),%rbx
    9c49:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    9c4e:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    9c55:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    9c59:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    9c5d:	66 48 0f 6e fb       	movq   %rbx,%xmm7
    9c62:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    9c67:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    9c6c:	4c 8b 56 40          	mov    0x40(%rsi),%r10
    9c70:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    9c74:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    9c7a:	77 1a                	ja     9c96 <fwp_hof0.constprop.0+0x5c6>
    9c7c:	0f b7 44 24 10       	movzwl 0x10(%rsp),%eax
    9c81:	83 e8 01             	sub    $0x1,%eax
    9c84:	48 98                	cltq
    9c86:	48 3b 05 4b 94 01 00 	cmp    0x1944b(%rip),%rax        # 230d8 <fwp_tape_next_slot>
    9c8d:	7d 07                	jge    9c96 <fwp_hof0.constprop.0+0x5c6>
    9c8f:	48 89 05 42 94 01 00 	mov    %rax,0x19442(%rip)        # 230d8 <fwp_tape_next_slot>
    9c96:	48 8b 05 1b 38 06 00 	mov    0x6381b(%rip),%rax        # 6d4b8 <fwp_cleanups>
    9c9d:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9ca1:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    9ca8:	00 
    9ca9:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    9cad:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    9cb4:	00 
    9cb5:	48 8d 05 a4 b5 ff ff 	lea    -0x4a5c(%rip),%rax        # 5260 <fwp_tape_buffers_release>
    9cbc:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    9cc3:	00 
    9cc4:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
    9ccb:	00 
    9ccc:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9cd1:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    9cd8:	00 
    9cd9:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    9ce0:	00 
    9ce1:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    9ce8:	00 
    9ce9:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    9cf0:	00 
    9cf1:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    9cf5:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    9cf9:	48 89 05 b8 37 06 00 	mov    %rax,0x637b8(%rip)        # 6d4b8 <fwp_cleanups>
    9d00:	4c 89 94 24 e0 00 00 	mov    %r10,0xe0(%rsp)
    9d07:	00 
    9d08:	0f 29 9c 24 c0 00 00 	movaps %xmm3,0xc0(%rsp)
    9d0f:	00 
    9d10:	0f 29 94 24 d0 00 00 	movaps %xmm2,0xd0(%rsp)
    9d17:	00 
    9d18:	0f 11 84 24 e8 00 00 	movups %xmm0,0xe8(%rsp)
    9d1f:	00 
    9d20:	4d 85 c9             	test   %r9,%r9
    9d23:	0f 88 e7 0d 00 00    	js     ab10 <fwp_hof0.constprop.0+0x1440>
    9d29:	4c 89 c8             	mov    %r9,%rax
    9d2c:	48 c1 f8 20          	sar    $0x20,%rax
    9d30:	49 39 c7             	cmp    %rax,%r15
    9d33:	0f 85 2f 12 00 00    	jne    af68 <fwp_hof0.constprop.0+0x1898>
    9d39:	44 89 c9             	mov    %r9d,%ecx
    9d3c:	49 89 cf             	mov    %rcx,%r15
    9d3f:	48 39 ca             	cmp    %rcx,%rdx
    9d42:	0f 8e 2c 12 00 00    	jle    af74 <fwp_hof0.constprop.0+0x18a4>
    9d48:	49 39 ce             	cmp    %rcx,%r14
    9d4b:	0f 8e 67 0c 00 00    	jle    a9b8 <fwp_hof0.constprop.0+0x12e8>
    9d51:	49 39 de             	cmp    %rbx,%r14
    9d54:	0f 8f 96 0c 00 00    	jg     a9f0 <fwp_hof0.constprop.0+0x1320>
    9d5a:	4d 85 d2             	test   %r10,%r10
    9d5d:	0f 84 d7 12 00 00    	je     b03a <fwp_hof0.constprop.0+0x196a>
    9d63:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
    9d68:	4d 8d 7e ff          	lea    -0x1(%r14),%r15
    9d6c:	31 f6                	xor    %esi,%esi
    9d6e:	4c 89 d7             	mov    %r10,%rdi
    9d71:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    9d76:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    9d7d:	00 
    9d7e:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    9d83:	e8 28 97 ff ff       	call   34b0 <memset@plt>
    9d88:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    9d8e:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    9d94:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
    9d99:	49 89 c2             	mov    %rax,%r10
    9d9c:	f2 0f 10 05 c4 5f 00 	movsd  0x5fc4(%rip),%xmm0        # fd68 <msg.4+0x28>
    9da3:	00 
    9da4:	f2 41 0f 58 04 ca    	addsd  (%r10,%rcx,8),%xmm0
    9daa:	f2 41 0f 11 04 ca    	movsd  %xmm0,(%r10,%rcx,8)
    9db0:	4d 39 fe             	cmp    %r15,%r14
    9db3:	0f 8f 8f 00 00 00    	jg     9e48 <fwp_hof0.constprop.0+0x778>
    9db9:	0f 12 fb             	movhlps %xmm3,%xmm7
    9dbc:	66 48 0f 7e d7       	movq   %xmm2,%rdi
    9dc1:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    9dc6:	4d 29 f7             	sub    %r14,%r15
    9dc9:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    9dce:	0f 12 fa             	movhlps %xmm2,%xmm7
    9dd1:	4b 8d 1c f2          	lea    (%r10,%r14,8),%rbx
    9dd5:	66 49 0f 7e f9       	movq   %xmm7,%r9
    9dda:	4a 8d 04 be          	lea    (%rsi,%r15,4),%rax
    9dde:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9de2:	48 29 f1             	sub    %rsi,%rcx
    9de5:	4b 8d 14 f9          	lea    (%r9,%r15,8),%rdx
    9de9:	4c 29 cb             	sub    %r9,%rbx
    9dec:	4c 29 cf             	sub    %r9,%rdi
    9def:	eb 0b                	jmp    9dfc <fwp_hof0.constprop.0+0x72c>
    9df1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9df8:	48 83 e8 04          	sub    $0x4,%rax
    9dfc:	f2 0f 10 04 13       	movsd  (%rbx,%rdx,1),%xmm0
    9e01:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    9e05:	7a 02                	jp     9e09 <fwp_hof0.constprop.0+0x739>
    9e07:	74 36                	je     9e3f <fwp_hof0.constprop.0+0x76f>
    9e09:	4c 63 04 01          	movslq (%rcx,%rax,1),%r8
    9e0d:	45 85 c0             	test   %r8d,%r8d
    9e10:	78 15                	js     9e27 <fwp_hof0.constprop.0+0x757>
    9e12:	f2 0f 10 0c 17       	movsd  (%rdi,%rdx,1),%xmm1
    9e17:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    9e1b:	f2 43 0f 58 0c c2    	addsd  (%r10,%r8,8),%xmm1
    9e21:	f2 43 0f 11 0c c2    	movsd  %xmm1,(%r10,%r8,8)
    9e27:	4c 63 00             	movslq (%rax),%r8
    9e2a:	45 85 c0             	test   %r8d,%r8d
    9e2d:	78 10                	js     9e3f <fwp_hof0.constprop.0+0x76f>
    9e2f:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    9e33:	f2 43 0f 58 04 c2    	addsd  (%r10,%r8,8),%xmm0
    9e39:	f2 43 0f 11 04 c2    	movsd  %xmm0,(%r10,%r8,8)
    9e3f:	48 83 ea 08          	sub    $0x8,%rdx
    9e43:	48 39 c6             	cmp    %rax,%rsi
    9e46:	75 b0                	jne    9df8 <fwp_hof0.constprop.0+0x728>
    9e48:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9e4f:	ff ff 1f 
    9e52:	4c 39 f0             	cmp    %r14,%rax
    9e55:	0f 82 51 11 00 00    	jb     afac <fwp_hof0.constprop.0+0x18dc>
    9e5b:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    9e62:	00 
    9e63:	be 02 00 00 00       	mov    $0x2,%esi
    9e68:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    9e6d:	e8 9e c0 ff ff       	call   5f10 <fwp_heap_alloc>
    9e72:	4d 85 f6             	test   %r14,%r14
    9e75:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    9e7a:	4c 89 30             	mov    %r14,(%rax)
    9e7d:	49 89 c7             	mov    %rax,%r15
    9e80:	74 30                	je     9eb2 <fwp_hof0.constprop.0+0x7e2>
    9e82:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9e89:	00 
    9e8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9e91:	00 00 00 00 
    9e95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9e9c:	00 00 00 00 
    9ea0:	4b 8b 04 ea          	mov    (%r10,%r13,8),%rax
    9ea4:	4b 89 44 ef 08       	mov    %rax,0x8(%r15,%r13,8)
    9ea9:	49 83 c5 01          	add    $0x1,%r13
    9ead:	4d 39 ee             	cmp    %r13,%r14
    9eb0:	75 ee                	jne    9ea0 <fwp_hof0.constprop.0+0x7d0>
    9eb2:	4c 8b a4 24 a0 00 00 	mov    0xa0(%rsp),%r12
    9eb9:	00 
    9eba:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    9ebf:	4c 89 25 f2 35 06 00 	mov    %r12,0x635f2(%rip)        # 6d4b8 <fwp_cleanups>
    9ec6:	e8 95 b3 ff ff       	call   5260 <fwp_tape_buffers_release>
    9ecb:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9ed2:	4c 89 f8             	mov    %r15,%rax
    9ed5:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9edc:	48 c1 e2 10          	shl    $0x10,%rdx
    9ee0:	48 39 d0             	cmp    %rdx,%rax
    9ee3:	73 55                	jae    9f3a <fwp_hof0.constprop.0+0x86a>
    9ee5:	48 89 c2             	mov    %rax,%rdx
    9ee8:	48 c1 ea 10          	shr    $0x10,%rdx
    9eec:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ef0:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9ef7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9efb:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9eff:	48 85 db             	test   %rbx,%rbx
    9f02:	74 36                	je     9f3a <fwp_hof0.constprop.0+0x86a>
    9f04:	0f b6 0a             	movzbl (%rdx),%ecx
    9f07:	80 f9 02             	cmp    $0x2,%cl
    9f0a:	0f 84 30 0c 00 00    	je     ab40 <fwp_hof0.constprop.0+0x1470>
    9f10:	80 f9 01             	cmp    $0x1,%cl
    9f13:	75 25                	jne    9f3a <fwp_hof0.constprop.0+0x86a>
    9f15:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9f18:	0f b7 c0             	movzwl %ax,%eax
    9f1b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f1e:	48 0f af c1          	imul   %rcx,%rax
    9f22:	48 c1 e8 20          	shr    $0x20,%rax
    9f26:	48 39 d0             	cmp    %rdx,%rax
    9f29:	73 0f                	jae    9f3a <fwp_hof0.constprop.0+0x86a>
    9f2b:	48 01 c3             	add    %rax,%rbx
    9f2e:	80 3b ff             	cmpb   $0xff,(%rbx)
    9f31:	0f 84 1b 0c 00 00    	je     ab52 <fwp_hof0.constprop.0+0x1482>
    9f37:	c6 03 01             	movb   $0x1,(%rbx)
    9f3a:	4c 3b 64 24 38       	cmp    0x38(%rsp),%r12
    9f3f:	0f 85 06 98 ff ff    	jne    374b <fwp_hof0.constprop.0.cold>
    9f45:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    9f4c:	00 
    9f4d:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    9f52:	48 89 05 5f 35 06 00 	mov    %rax,0x6355f(%rip)        # 6d4b8 <fwp_cleanups>
    9f59:	e8 62 d0 ff ff       	call   6fc0 <fwp_tape_scope_release>
    9f5e:	49 8b 07             	mov    (%r15),%rax
    9f61:	49 89 c6             	mov    %rax,%r14
    9f64:	49 0f ba f6 3f       	btr    $0x3f,%r14
    9f69:	48 85 c0             	test   %rax,%rax
    9f6c:	0f 88 2e 08 00 00    	js     a7a0 <fwp_hof0.constprop.0+0x10d0>
    9f72:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9f79:	4c 89 f8             	mov    %r15,%rax
    9f7c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9f83:	48 c1 e2 10          	shl    $0x10,%rdx
    9f87:	48 39 d0             	cmp    %rdx,%rax
    9f8a:	0f 83 10 08 00 00    	jae    a7a0 <fwp_hof0.constprop.0+0x10d0>
    9f90:	48 89 c2             	mov    %rax,%rdx
    9f93:	48 c1 ea 10          	shr    $0x10,%rdx
    9f97:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f9b:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9fa2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9fa6:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    9faa:	48 85 c9             	test   %rcx,%rcx
    9fad:	0f 84 ed 07 00 00    	je     a7a0 <fwp_hof0.constprop.0+0x10d0>
    9fb3:	0f b6 32             	movzbl (%rdx),%esi
    9fb6:	40 80 fe 02          	cmp    $0x2,%sil
    9fba:	0f 84 c8 07 00 00    	je     a788 <fwp_hof0.constprop.0+0x10b8>
    9fc0:	40 80 fe 01          	cmp    $0x1,%sil
    9fc4:	0f 85 d6 07 00 00    	jne    a7a0 <fwp_hof0.constprop.0+0x10d0>
    9fca:	8b 72 18             	mov    0x18(%rdx),%esi
    9fcd:	0f b7 c0             	movzwl %ax,%eax
    9fd0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9fd3:	48 0f af c6          	imul   %rsi,%rax
    9fd7:	48 c1 e8 20          	shr    $0x20,%rax
    9fdb:	48 39 d0             	cmp    %rdx,%rax
    9fde:	0f 83 bc 07 00 00    	jae    a7a0 <fwp_hof0.constprop.0+0x10d0>
    9fe4:	48 01 c1             	add    %rax,%rcx
    9fe7:	80 39 01             	cmpb   $0x1,(%rcx)
    9fea:	0f 85 b0 07 00 00    	jne    a7a0 <fwp_hof0.constprop.0+0x10d0>
    9ff0:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
    9ff5:	4d 89 fc             	mov    %r15,%r12
    9ff8:	31 ff                	xor    %edi,%edi
    9ffa:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9fff:	48 8d 50 08          	lea    0x8(%rax),%rdx
    a003:	31 c0                	xor    %eax,%eax
    a005:	4d 85 f6             	test   %r14,%r14
    a008:	75 30                	jne    a03a <fwp_hof0.constprop.0+0x96a>
    a00a:	eb 44                	jmp    a050 <fwp_hof0.constprop.0+0x980>
    a00c:	0f 1f 40 00          	nopl   0x0(%rax)
    a010:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    a015:	0f 88 65 0f 00 00    	js     af80 <fwp_hof0.constprop.0+0x18b0>
    a01b:	f2 0f 10 05 5d 5d 00 	movsd  0x5d5d(%rip),%xmm0        # fd80 <msg.4+0x40>
    a022:	00 
    a023:	f2 0f 59 04 c1       	mulsd  (%rcx,%rax,8),%xmm0
    a028:	48 83 c0 01          	add    $0x1,%rax
    a02c:	48 83 c2 08          	add    $0x8,%rdx
    a030:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    a035:	49 39 c6             	cmp    %rax,%r14
    a038:	74 16                	je     a050 <fwp_hof0.constprop.0+0x980>
    a03a:	49 8d 4f 08          	lea    0x8(%r15),%rcx
    a03e:	49 83 3f 00          	cmpq   $0x0,(%r15)
    a042:	79 cc                	jns    a010 <fwp_hof0.constprop.0+0x940>
    a044:	49 8b 4f 10          	mov    0x10(%r15),%rcx
    a048:	eb c6                	jmp    a010 <fwp_hof0.constprop.0+0x940>
    a04a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a050:	e8 bb de ff ff       	call   7f10 <fwp_drop10>
    a055:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a05a:	31 d2                	xor    %edx,%edx
    a05c:	48 89 f8             	mov    %rdi,%rax
    a05f:	48 85 ff             	test   %rdi,%rdi
    a062:	0f 84 2c 0d 00 00    	je     ad94 <fwp_hof0.constprop.0+0x16c4>
    a068:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a06f:	00 
    a070:	48 8b 40 10          	mov    0x10(%rax),%rax
    a074:	48 83 c2 01          	add    $0x1,%rdx
    a078:	48 85 c0             	test   %rax,%rax
    a07b:	75 f3                	jne    a070 <fwp_hof0.constprop.0+0x9a0>
    a07d:	49 8b 04 24          	mov    (%r12),%rax
    a081:	49 89 c7             	mov    %rax,%r15
    a084:	49 0f ba f7 3f       	btr    $0x3f,%r15
    a089:	48 85 c0             	test   %rax,%rax
    a08c:	0f 88 cb 05 00 00    	js     a65d <fwp_hof0.constprop.0+0xf8d>
    a092:	48 8b 85 d8 13 00 00 	mov    0x13d8(%rbp),%rax
    a099:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    a09e:	48 2b 8d b0 13 00 00 	sub    0x13b0(%rbp),%rcx
    a0a5:	48 c1 e0 10          	shl    $0x10,%rax
    a0a9:	48 39 c1             	cmp    %rax,%rcx
    a0ac:	0f 83 ab 05 00 00    	jae    a65d <fwp_hof0.constprop.0+0xf8d>
    a0b2:	48 89 c8             	mov    %rcx,%rax
    a0b5:	48 c1 e8 10          	shr    $0x10,%rax
    a0b9:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    a0bd:	48 8b 85 f8 13 00 00 	mov    0x13f8(%rbp),%rax
    a0c4:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    a0c8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a0cc:	48 85 ff             	test   %rdi,%rdi
    a0cf:	0f 84 88 05 00 00    	je     a65d <fwp_hof0.constprop.0+0xf8d>
    a0d5:	0f b6 06             	movzbl (%rsi),%eax
    a0d8:	3c 02                	cmp    $0x2,%al
    a0da:	0f 84 68 05 00 00    	je     a648 <fwp_hof0.constprop.0+0xf78>
    a0e0:	3c 01                	cmp    $0x1,%al
    a0e2:	0f 85 69 05 00 00    	jne    a651 <fwp_hof0.constprop.0+0xf81>
    a0e8:	8b 46 18             	mov    0x18(%rsi),%eax
    a0eb:	0f b7 c9             	movzwl %cx,%ecx
    a0ee:	48 0f af c8          	imul   %rax,%rcx
    a0f2:	8b 46 1c             	mov    0x1c(%rsi),%eax
    a0f5:	48 c1 e9 20          	shr    $0x20,%rcx
    a0f9:	48 39 c1             	cmp    %rax,%rcx
    a0fc:	0f 83 4f 05 00 00    	jae    a651 <fwp_hof0.constprop.0+0xf81>
    a102:	48 01 cf             	add    %rcx,%rdi
    a105:	80 3f 01             	cmpb   $0x1,(%rdi)
    a108:	0f 85 43 05 00 00    	jne    a651 <fwp_hof0.constprop.0+0xf81>
    a10e:	49 39 d7             	cmp    %rdx,%r15
    a111:	48 89 d0             	mov    %rdx,%rax
    a114:	49 0f 46 c7          	cmovbe %r15,%rax
    a118:	48 85 c0             	test   %rax,%rax
    a11b:	0f 84 6b 0e 00 00    	je     af8c <fwp_hof0.constprop.0+0x18bc>
    a121:	c7 44 24 30 01 00 00 	movl   $0x1,0x30(%rsp)
    a128:	00 
    a129:	4d 8d 6c 24 08       	lea    0x8(%r12),%r13
    a12e:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    a133:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a138:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    a13f:	00 
    a140:	31 d2                	xor    %edx,%edx
    a142:	49 8d 78 08          	lea    0x8(%r8),%rdi
    a146:	eb 56                	jmp    a19e <fwp_hof0.constprop.0+0xace>
    a148:	90                   	nop
    a149:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a150:	00 00 00 00 
    a154:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a15b:	00 00 00 00 
    a15f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a166:	00 00 00 00 
    a16a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a171:	00 00 00 00 
    a175:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a17c:	00 00 00 00 
    a180:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    a185:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    a18a:	f2 41 0f 11 44 15 00 	movsd  %xmm0,0x0(%r13,%rdx,1)
    a191:	48 83 c2 08          	add    $0x8,%rdx
    a195:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a199:	49 39 d1             	cmp    %rdx,%r9
    a19c:	74 12                	je     a1b0 <fwp_hof0.constprop.0+0xae0>
    a19e:	48 89 fe             	mov    %rdi,%rsi
    a1a1:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    a1a6:	79 d8                	jns    a180 <fwp_hof0.constprop.0+0xab0>
    a1a8:	49 8b 70 10          	mov    0x10(%r8),%rsi
    a1ac:	eb d2                	jmp    a180 <fwp_hof0.constprop.0+0xab0>
    a1ae:	66 90                	xchg   %ax,%ax
    a1b0:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a1b5:	48 85 c9             	test   %rcx,%rcx
    a1b8:	0f 84 a2 0d 00 00    	je     af60 <fwp_hof0.constprop.0+0x1890>
    a1be:	4c 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%r9
    a1c5:	4c 8b 95 b0 13 00 00 	mov    0x13b0(%rbp),%r10
    a1cc:	45 31 ff             	xor    %r15d,%r15d
    a1cf:	4c 8b 9d f8 13 00 00 	mov    0x13f8(%rbp),%r11
    a1d6:	49 c1 e1 10          	shl    $0x10,%r9
    a1da:	eb 1a                	jmp    a1f6 <fwp_hof0.constprop.0+0xb26>
    a1dc:	0f 1f 40 00          	nopl   0x0(%rax)
    a1e0:	49 83 c7 01          	add    $0x1,%r15
    a1e4:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a1e8:	49 39 c7             	cmp    %rax,%r15
    a1eb:	0f 83 5f 01 00 00    	jae    a350 <fwp_hof0.constprop.0+0xc80>
    a1f1:	48 85 c9             	test   %rcx,%rcx
    a1f4:	74 56                	je     a24c <fwp_hof0.constprop.0+0xb7c>
    a1f6:	48 89 ca             	mov    %rcx,%rdx
    a1f9:	4c 29 d2             	sub    %r10,%rdx
    a1fc:	4c 39 ca             	cmp    %r9,%rdx
    a1ff:	73 4b                	jae    a24c <fwp_hof0.constprop.0+0xb7c>
    a201:	48 89 d6             	mov    %rdx,%rsi
    a204:	48 c1 ee 10          	shr    $0x10,%rsi
    a208:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    a20c:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    a210:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a214:	48 85 ff             	test   %rdi,%rdi
    a217:	74 33                	je     a24c <fwp_hof0.constprop.0+0xb7c>
    a219:	44 0f b6 06          	movzbl (%rsi),%r8d
    a21d:	41 80 f8 02          	cmp    $0x2,%r8b
    a221:	0f 84 11 01 00 00    	je     a338 <fwp_hof0.constprop.0+0xc68>
    a227:	41 80 f8 01          	cmp    $0x1,%r8b
    a22b:	75 1f                	jne    a24c <fwp_hof0.constprop.0+0xb7c>
    a22d:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a231:	0f b7 d2             	movzwl %dx,%edx
    a234:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a237:	49 0f af d0          	imul   %r8,%rdx
    a23b:	48 c1 ea 20          	shr    $0x20,%rdx
    a23f:	48 39 f2             	cmp    %rsi,%rdx
    a242:	73 08                	jae    a24c <fwp_hof0.constprop.0+0xb7c>
    a244:	48 01 d7             	add    %rdx,%rdi
    a247:	80 3f 01             	cmpb   $0x1,(%rdi)
    a24a:	74 94                	je     a1e0 <fwp_hof0.constprop.0+0xb10>
    a24c:	49 39 c7             	cmp    %rax,%r15
    a24f:	0f 83 fb 00 00 00    	jae    a350 <fwp_hof0.constprop.0+0xc80>
    a255:	48 89 c3             	mov    %rax,%rbx
    a258:	45 31 f6             	xor    %r14d,%r14d
    a25b:	eb 37                	jmp    a294 <fwp_hof0.constprop.0+0xbc4>
    a25d:	0f 1f 00             	nopl   (%rax)
    a260:	40 80 fe 01          	cmp    $0x1,%sil
    a264:	75 25                	jne    a28b <fwp_hof0.constprop.0+0xbbb>
    a266:	8b 71 18             	mov    0x18(%rcx),%esi
    a269:	0f b7 c0             	movzwl %ax,%eax
    a26c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a26f:	48 0f af c6          	imul   %rsi,%rax
    a273:	48 c1 e8 20          	shr    $0x20,%rax
    a277:	48 39 c8             	cmp    %rcx,%rax
    a27a:	73 0f                	jae    a28b <fwp_hof0.constprop.0+0xbbb>
    a27c:	48 01 c2             	add    %rax,%rdx
    a27f:	80 3a ff             	cmpb   $0xff,(%rdx)
    a282:	0f 84 60 06 00 00    	je     a8e8 <fwp_hof0.constprop.0+0x1218>
    a288:	c6 02 01             	movb   $0x1,(%rdx)
    a28b:	49 39 df             	cmp    %rbx,%r15
    a28e:	0f 83 8c 00 00 00    	jae    a320 <fwp_hof0.constprop.0+0xc50>
    a294:	48 83 eb 01          	sub    $0x1,%rbx
    a298:	66 49 0f 6e f6       	movq   %r14,%xmm6
    a29d:	bf 01 00 00 00       	mov    $0x1,%edi
    a2a2:	f3 41 0f 7e 44 dd 00 	movq   0x0(%r13,%rbx,8),%xmm0
    a2a9:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    a2b0:	00 
    a2b1:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    a2b5:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
    a2bc:	00 
    a2bd:	e8 3e be ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    a2c2:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a2c9:	49 89 c6             	mov    %rax,%r14
    a2cc:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a2d3:	48 c1 e2 10          	shl    $0x10,%rdx
    a2d7:	48 39 d0             	cmp    %rdx,%rax
    a2da:	73 af                	jae    a28b <fwp_hof0.constprop.0+0xbbb>
    a2dc:	48 89 c2             	mov    %rax,%rdx
    a2df:	48 c1 ea 10          	shr    $0x10,%rdx
    a2e3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a2e7:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a2ee:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a2f2:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    a2f6:	48 85 d2             	test   %rdx,%rdx
    a2f9:	74 90                	je     a28b <fwp_hof0.constprop.0+0xbbb>
    a2fb:	0f b6 31             	movzbl (%rcx),%esi
    a2fe:	40 80 fe 02          	cmp    $0x2,%sil
    a302:	0f 85 58 ff ff ff    	jne    a260 <fwp_hof0.constprop.0+0xb90>
    a308:	66 85 c0             	test   %ax,%ax
    a30b:	0f 84 6e ff ff ff    	je     a27f <fwp_hof0.constprop.0+0xbaf>
    a311:	49 39 df             	cmp    %rbx,%r15
    a314:	0f 82 7a ff ff ff    	jb     a294 <fwp_hof0.constprop.0+0xbc4>
    a31a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a320:	4d 85 ff             	test   %r15,%r15
    a323:	75 2e                	jne    a353 <fwp_hof0.constprop.0+0xc83>
    a325:	8b 44 24 30          	mov    0x30(%rsp),%eax
    a329:	85 c0                	test   %eax,%eax
    a32b:	4d 0f 45 ef          	cmovne %r15,%r13
    a32f:	eb 63                	jmp    a394 <fwp_hof0.constprop.0+0xcc4>
    a331:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a338:	66 85 d2             	test   %dx,%dx
    a33b:	0f 84 06 ff ff ff    	je     a247 <fwp_hof0.constprop.0+0xb77>
    a341:	49 39 c7             	cmp    %rax,%r15
    a344:	0f 82 0b ff ff ff    	jb     a255 <fwp_hof0.constprop.0+0xb85>
    a34a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a350:	45 31 f6             	xor    %r14d,%r14d
    a353:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a358:	4c 89 ea             	mov    %r13,%rdx
    a35b:	4f 8d 4c fd 00       	lea    0x0(%r13,%r15,8),%r9
    a360:	48 8b 0a             	mov    (%rdx),%rcx
    a363:	48 83 c2 08          	add    $0x8,%rdx
    a367:	48 89 c7             	mov    %rax,%rdi
    a36a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    a36e:	48 8b 40 10          	mov    0x10(%rax),%rax
    a372:	49 39 d1             	cmp    %rdx,%r9
    a375:	75 e9                	jne    a360 <fwp_hof0.constprop.0+0xc90>
    a377:	8b 54 24 30          	mov    0x30(%rsp),%edx
    a37b:	4c 89 77 10          	mov    %r14,0x10(%rdi)
    a37f:	85 d2                	test   %edx,%edx
    a381:	0f 84 d9 07 00 00    	je     ab60 <fwp_hof0.constprop.0+0x1490>
    a387:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    a38c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a391:	45 31 ed             	xor    %r13d,%r13d
    a394:	4c 89 ef             	mov    %r13,%rdi
    a397:	e8 74 b6 ff ff       	call   5a10 <fwp_mem_free>
    a39c:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    a3a1:	e8 6a db ff ff       	call   7f10 <fwp_drop10>
    a3a6:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a3ad:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a3b2:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a3b9:	48 c1 e2 10          	shl    $0x10,%rdx
    a3bd:	48 39 d0             	cmp    %rdx,%rax
    a3c0:	73 6e                	jae    a430 <fwp_hof0.constprop.0+0xd60>
    a3c2:	48 89 c2             	mov    %rax,%rdx
    a3c5:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    a3cc:	48 c1 ea 10          	shr    $0x10,%rdx
    a3d0:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    a3d4:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    a3d8:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    a3dc:	48 85 db             	test   %rbx,%rbx
    a3df:	74 4f                	je     a430 <fwp_hof0.constprop.0+0xd60>
    a3e1:	0f b6 0a             	movzbl (%rdx),%ecx
    a3e4:	80 f9 02             	cmp    $0x2,%cl
    a3e7:	0f 84 03 07 00 00    	je     aaf0 <fwp_hof0.constprop.0+0x1420>
    a3ed:	80 f9 01             	cmp    $0x1,%cl
    a3f0:	75 3e                	jne    a430 <fwp_hof0.constprop.0+0xd60>
    a3f2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a3f5:	0f b7 c0             	movzwl %ax,%eax
    a3f8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a3fb:	48 0f af c1          	imul   %rcx,%rax
    a3ff:	48 c1 e8 20          	shr    $0x20,%rax
    a403:	48 39 d0             	cmp    %rdx,%rax
    a406:	73 28                	jae    a430 <fwp_hof0.constprop.0+0xd60>
    a408:	48 01 c3             	add    %rax,%rbx
    a40b:	0f b6 03             	movzbl (%rbx),%eax
    a40e:	84 c0                	test   %al,%al
    a410:	74 1e                	je     a430 <fwp_hof0.constprop.0+0xd60>
    a412:	3c 01                	cmp    $0x1,%al
    a414:	0f 84 56 07 00 00    	je     ab70 <fwp_hof0.constprop.0+0x14a0>
    a41a:	3c ff                	cmp    $0xff,%al
    a41c:	0f 84 ed 09 00 00    	je     ae0f <fwp_hof0.constprop.0+0x173f>
    a422:	83 e8 01             	sub    $0x1,%eax
    a425:	88 03                	mov    %al,(%rbx)
    a427:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a42e:	00 00 
    a430:	48 83 7c 24 28 00    	cmpq   $0x0,0x28(%rsp)
    a436:	0f 85 5c 06 00 00    	jne    aa98 <fwp_hof0.constprop.0+0x13c8>
    a43c:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    a441:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a445:	4c 89 f6             	mov    %r14,%rsi
    a448:	4d 89 f4             	mov    %r14,%r12
    a44b:	b9 01 00 00 00       	mov    $0x1,%ecx
    a450:	48 8d 15 49 87 00 00 	lea    0x8749(%rip),%rdx        # 12ba0 <d0>
    a457:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
    a45e:	00 00 00 00 00 
    a463:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
    a46a:	00 
    a46b:	e8 20 e2 ff ff       	call   8690 <fwp_write>
    a470:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
    a477:	00 
    a478:	4c 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%r15
    a47f:	00 
    a480:	48 8d 05 e5 4b 00 00 	lea    0x4be5(%rip),%rax        # f06c <_IO_stdin_used+0x6c>
    a487:	48 85 c9             	test   %rcx,%rcx
    a48a:	48 0f 44 c8          	cmove  %rax,%rcx
    a48e:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    a492:	0f 87 5a 0b 00 00    	ja     aff2 <fwp_hof0.constprop.0+0x1922>
    a498:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    a49c:	be 01 00 00 00       	mov    $0x1,%esi
    a4a1:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a4a6:	e8 65 ba ff ff       	call   5f10 <fwp_heap_alloc>
    a4ab:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a4b0:	4c 89 fa             	mov    %r15,%rdx
    a4b3:	4c 89 38             	mov    %r15,(%rax)
    a4b6:	4c 8d 68 08          	lea    0x8(%rax),%r13
    a4ba:	48 89 c3             	mov    %rax,%rbx
    a4bd:	4c 89 ef             	mov    %r13,%rdi
    a4c0:	e8 bb 90 ff ff       	call   3580 <memcpy@plt>
    a4c5:	42 c6 44 3b 08 00    	movb   $0x0,0x8(%rbx,%r15,1)
    a4cb:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
    a4d2:	00 
    a4d3:	e8 d8 8e ff ff       	call   33b0 <free@plt>
    a4d8:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a4df:	48 89 d8             	mov    %rbx,%rax
    a4e2:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a4e9:	48 c1 e2 10          	shl    $0x10,%rdx
    a4ed:	48 39 d0             	cmp    %rdx,%rax
    a4f0:	73 57                	jae    a549 <fwp_hof0.constprop.0+0xe79>
    a4f2:	48 89 c2             	mov    %rax,%rdx
    a4f5:	48 c1 ea 10          	shr    $0x10,%rdx
    a4f9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a4fd:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a504:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a508:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a50c:	4d 85 ff             	test   %r15,%r15
    a50f:	74 38                	je     a549 <fwp_hof0.constprop.0+0xe79>
    a511:	0f b6 0a             	movzbl (%rdx),%ecx
    a514:	80 f9 02             	cmp    $0x2,%cl
    a517:	0f 84 1b 08 00 00    	je     ad38 <fwp_hof0.constprop.0+0x1668>
    a51d:	80 f9 01             	cmp    $0x1,%cl
    a520:	75 27                	jne    a549 <fwp_hof0.constprop.0+0xe79>
    a522:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a525:	0f b7 c0             	movzwl %ax,%eax
    a528:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a52b:	48 0f af c1          	imul   %rcx,%rax
    a52f:	48 c1 e8 20          	shr    $0x20,%rax
    a533:	48 39 d0             	cmp    %rdx,%rax
    a536:	73 11                	jae    a549 <fwp_hof0.constprop.0+0xe79>
    a538:	49 01 c7             	add    %rax,%r15
    a53b:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a53f:	0f 84 06 08 00 00    	je     ad4b <fwp_hof0.constprop.0+0x167b>
    a545:	41 c6 07 01          	movb   $0x1,(%r15)
    a549:	4c 89 e7             	mov    %r12,%rdi
    a54c:	e8 cf d5 ff ff       	call   7b20 <fwp_drop0>
    a551:	48 8b 13             	mov    (%rbx),%rdx
    a554:	be 01 00 00 00       	mov    $0x1,%esi
    a559:	4c 89 ef             	mov    %r13,%rdi
    a55c:	48 8b 0d 1d 2f 06 00 	mov    0x62f1d(%rip),%rcx        # 6d480 <fwp_prog_out>
    a563:	e8 f8 90 ff ff       	call   3660 <fwrite@plt>
    a568:	48 8b 35 11 2f 06 00 	mov    0x62f11(%rip),%rsi        # 6d480 <fwp_prog_out>
    a56f:	bf 0a 00 00 00       	mov    $0xa,%edi
    a574:	e8 57 8f ff ff       	call   34d0 <fputc@plt>
    a579:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a580:	48 89 d8             	mov    %rbx,%rax
    a583:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a58a:	48 c1 e2 10          	shl    $0x10,%rdx
    a58e:	48 39 d0             	cmp    %rdx,%rax
    a591:	73 6d                	jae    a600 <fwp_hof0.constprop.0+0xf30>
    a593:	48 89 c2             	mov    %rax,%rdx
    a596:	48 c1 ea 10          	shr    $0x10,%rdx
    a59a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a59e:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a5a5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a5a9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a5ad:	4d 85 e4             	test   %r12,%r12
    a5b0:	74 4e                	je     a600 <fwp_hof0.constprop.0+0xf30>
    a5b2:	0f b6 0a             	movzbl (%rdx),%ecx
    a5b5:	80 f9 02             	cmp    $0x2,%cl
    a5b8:	0f 84 a2 07 00 00    	je     ad60 <fwp_hof0.constprop.0+0x1690>
    a5be:	80 f9 01             	cmp    $0x1,%cl
    a5c1:	75 3d                	jne    a600 <fwp_hof0.constprop.0+0xf30>
    a5c3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a5c6:	0f b7 c0             	movzwl %ax,%eax
    a5c9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a5cc:	48 0f af c1          	imul   %rcx,%rax
    a5d0:	48 c1 e8 20          	shr    $0x20,%rax
    a5d4:	48 39 d0             	cmp    %rdx,%rax
    a5d7:	73 27                	jae    a600 <fwp_hof0.constprop.0+0xf30>
    a5d9:	49 01 c4             	add    %rax,%r12
    a5dc:	41 0f b6 04 24       	movzbl (%r12),%eax
    a5e1:	84 c0                	test   %al,%al
    a5e3:	74 1b                	je     a600 <fwp_hof0.constprop.0+0xf30>
    a5e5:	3c 01                	cmp    $0x1,%al
    a5e7:	0f 84 91 07 00 00    	je     ad7e <fwp_hof0.constprop.0+0x16ae>
    a5ed:	3c ff                	cmp    $0xff,%al
    a5ef:	0f 84 f3 08 00 00    	je     aee8 <fwp_hof0.constprop.0+0x1818>
    a5f5:	83 e8 01             	sub    $0x1,%eax
    a5f8:	41 88 04 24          	mov    %al,(%r12)
    a5fc:	0f 1f 40 00          	nopl   0x0(%rax)
    a600:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    a605:	48 8b 40 10          	mov    0x10(%rax),%rax
    a609:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    a60e:	48 85 c0             	test   %rax,%rax
    a611:	0f 85 f9 f0 ff ff    	jne    9710 <fwp_hof0.constprop.0+0x40>
    a617:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    a61e:	00 
    a61f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a626:	00 00 
    a628:	0f 85 6b 0a 00 00    	jne    b099 <fwp_hof0.constprop.0+0x19c9>
    a62e:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    a635:	31 c0                	xor    %eax,%eax
    a637:	5b                   	pop    %rbx
    a638:	5d                   	pop    %rbp
    a639:	41 5c                	pop    %r12
    a63b:	41 5d                	pop    %r13
    a63d:	41 5e                	pop    %r14
    a63f:	41 5f                	pop    %r15
    a641:	c3                   	ret
    a642:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a648:	66 85 c9             	test   %cx,%cx
    a64b:	0f 84 b4 fa ff ff    	je     a105 <fwp_hof0.constprop.0+0xa35>
    a651:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    a657:	0f 84 3e 03 00 00    	je     a99b <fwp_hof0.constprop.0+0x12cb>
    a65d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a662:	45 31 f6             	xor    %r14d,%r14d
    a665:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a66c:	00 00 00 00 
    a670:	48 8b 40 10          	mov    0x10(%rax),%rax
    a674:	4c 89 f2             	mov    %r14,%rdx
    a677:	49 83 c6 01          	add    $0x1,%r14
    a67b:	48 85 c0             	test   %rax,%rax
    a67e:	75 f0                	jne    a670 <fwp_hof0.constprop.0+0xfa0>
    a680:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a687:	ff ff 1f 
    a68a:	4c 39 f0             	cmp    %r14,%rax
    a68d:	0f 82 01 09 00 00    	jb     af94 <fwp_hof0.constprop.0+0x18c4>
    a693:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    a69a:	00 
    a69b:	be 02 00 00 00       	mov    $0x2,%esi
    a6a0:	e8 6b b8 ff ff       	call   5f10 <fwp_heap_alloc>
    a6a5:	4d 39 fe             	cmp    %r15,%r14
    a6a8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    a6ad:	49 89 c5             	mov    %rax,%r13
    a6b0:	4c 89 f8             	mov    %r15,%rax
    a6b3:	49 0f 46 c6          	cmovbe %r14,%rax
    a6b7:	4c 89 e9             	mov    %r13,%rcx
    a6ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a6c0:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    a6c4:	48 83 c1 08          	add    $0x8,%rcx
    a6c8:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    a6cc:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a6d0:	48 85 d2             	test   %rdx,%rdx
    a6d3:	75 eb                	jne    a6c0 <fwp_hof0.constprop.0+0xff0>
    a6d5:	48 85 c0             	test   %rax,%rax
    a6d8:	0f 84 cf 02 00 00    	je     a9ad <fwp_hof0.constprop.0+0x12dd>
    a6de:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
    a6e5:	00 
    a6e6:	e9 43 fa ff ff       	jmp    a12e <fwp_hof0.constprop.0+0xa5e>
    a6eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a6f0:	4c 39 f3             	cmp    %r14,%rbx
    a6f3:	0f 84 37 f2 ff ff    	je     9930 <fwp_hof0.constprop.0+0x260>
    a6f9:	4c 8b 25 f0 89 01 00 	mov    0x189f0(%rip),%r12        # 230f0 <fwp_tapes>
    a700:	e9 cf f2 ff ff       	jmp    99d4 <fwp_hof0.constprop.0+0x304>
    a705:	0f 1f 00             	nopl   (%rax)
    a708:	48 83 3d 78 89 01 00 	cmpq   $0x0,0x18978(%rip)        # 23088 <fwp_tape_cached_bytes>
    a70f:	00 
    a710:	0f 84 04 f3 ff ff    	je     9a1a <fwp_hof0.constprop.0+0x34a>
    a716:	66 0f 6f 0d 82 89 01 	movdqa 0x18982(%rip),%xmm1        # 230a0 <fwp_tape_workspace>
    a71d:	00 
    a71e:	48 c7 05 5f 89 01 00 	movq   $0x0,0x1895f(%rip)        # 23088 <fwp_tape_cached_bytes>
    a725:	00 00 00 00 
    a729:	0f 11 4b 20          	movups %xmm1,0x20(%rbx)
    a72d:	48 8b 05 8c 89 01 00 	mov    0x1898c(%rip),%rax        # 230c0 <fwp_tape_workspace+0x20>
    a734:	66 0f 6f 0d 74 89 01 	movdqa 0x18974(%rip),%xmm1        # 230b0 <fwp_tape_workspace+0x10>
    a73b:	00 
    a73c:	48 89 43 40          	mov    %rax,0x40(%rbx)
    a740:	48 8b 05 81 89 01 00 	mov    0x18981(%rip),%rax        # 230c8 <fwp_tape_workspace+0x28>
    a747:	0f 11 4b 30          	movups %xmm1,0x30(%rbx)
    a74b:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a74f:	48 89 43 18          	mov    %rax,0x18(%rbx)
    a753:	48 8b 05 76 89 01 00 	mov    0x18976(%rip),%rax        # 230d0 <fwp_tape_workspace+0x30>
    a75a:	0f 29 0d 3f 89 01 00 	movaps %xmm1,0x1893f(%rip)        # 230a0 <fwp_tape_workspace>
    a761:	48 89 43 48          	mov    %rax,0x48(%rbx)
    a765:	0f 29 0d 44 89 01 00 	movaps %xmm1,0x18944(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    a76c:	48 c7 05 59 89 01 00 	movq   $0x0,0x18959(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    a773:	00 00 00 00 
    a777:	0f 29 0d 42 89 01 00 	movaps %xmm1,0x18942(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    a77e:	e9 97 f2 ff ff       	jmp    9a1a <fwp_hof0.constprop.0+0x34a>
    a783:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a788:	66 85 c0             	test   %ax,%ax
    a78b:	0f 84 56 f8 ff ff    	je     9fe7 <fwp_hof0.constprop.0+0x917>
    a791:	0f 1f 40 00          	nopl   0x0(%rax)
    a795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a79c:	00 00 00 00 
    a7a0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a7a7:	ff ff 1f 
    a7aa:	4c 39 f0             	cmp    %r14,%rax
    a7ad:	0f 82 f9 07 00 00    	jb     afac <fwp_hof0.constprop.0+0x18dc>
    a7b3:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    a7ba:	00 
    a7bb:	be 01 00 00 00       	mov    $0x1,%esi
    a7c0:	e8 4b b7 ff ff       	call   5f10 <fwp_heap_alloc>
    a7c5:	4c 89 30             	mov    %r14,(%rax)
    a7c8:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a7cf:	49 89 c4             	mov    %rax,%r12
    a7d2:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    a7d7:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a7de:	48 c1 e2 10          	shl    $0x10,%rdx
    a7e2:	48 39 d0             	cmp    %rdx,%rax
    a7e5:	73 57                	jae    a83e <fwp_hof0.constprop.0+0x116e>
    a7e7:	48 89 c2             	mov    %rax,%rdx
    a7ea:	48 c1 ea 10          	shr    $0x10,%rdx
    a7ee:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a7f2:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a7f9:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a7fd:	48 8b 59 20          	mov    0x20(%rcx),%rbx
    a801:	48 85 db             	test   %rbx,%rbx
    a804:	74 38                	je     a83e <fwp_hof0.constprop.0+0x116e>
    a806:	0f b6 31             	movzbl (%rcx),%esi
    a809:	40 80 fe 02          	cmp    $0x2,%sil
    a80d:	0f 84 05 04 00 00    	je     ac18 <fwp_hof0.constprop.0+0x1548>
    a813:	40 80 fe 01          	cmp    $0x1,%sil
    a817:	75 25                	jne    a83e <fwp_hof0.constprop.0+0x116e>
    a819:	8b 71 18             	mov    0x18(%rcx),%esi
    a81c:	0f b7 c0             	movzwl %ax,%eax
    a81f:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a822:	48 0f af c6          	imul   %rsi,%rax
    a826:	48 c1 e8 20          	shr    $0x20,%rax
    a82a:	48 39 c8             	cmp    %rcx,%rax
    a82d:	73 0f                	jae    a83e <fwp_hof0.constprop.0+0x116e>
    a82f:	48 01 c3             	add    %rax,%rbx
    a832:	80 3b ff             	cmpb   $0xff,(%rbx)
    a835:	0f 84 ef 03 00 00    	je     ac2a <fwp_hof0.constprop.0+0x155a>
    a83b:	c6 03 01             	movb   $0x1,(%rbx)
    a83e:	4c 89 ff             	mov    %r15,%rdi
    a841:	e9 b4 f7 ff ff       	jmp    9ffa <fwp_hof0.constprop.0+0x92a>
    a846:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a84d:	00 00 00 
    a850:	48 c1 e1 10          	shl    $0x10,%rcx
    a854:	bf 08 00 00 00       	mov    $0x8,%edi
    a859:	48 09 f1             	or     %rsi,%rcx
    a85c:	be 02 00 00 00       	mov    $0x2,%esi
    a861:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a866:	e8 a5 b6 ff ff       	call   5f10 <fwp_heap_alloc>
    a86b:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a872:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a879:	49 89 c6             	mov    %rax,%r14
    a87c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a883:	48 c1 e2 10          	shl    $0x10,%rdx
    a887:	48 39 d0             	cmp    %rdx,%rax
    a88a:	0f 83 70 f3 ff ff    	jae    9c00 <fwp_hof0.constprop.0+0x530>
    a890:	48 89 c2             	mov    %rax,%rdx
    a893:	48 c1 ea 10          	shr    $0x10,%rdx
    a897:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a89b:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a8a2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a8a6:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a8aa:	4d 85 ff             	test   %r15,%r15
    a8ad:	0f 84 41 f3 ff ff    	je     9bf4 <fwp_hof0.constprop.0+0x524>
    a8b3:	0f b6 0a             	movzbl (%rdx),%ecx
    a8b6:	31 db                	xor    %ebx,%ebx
    a8b8:	80 f9 02             	cmp    $0x2,%cl
    a8bb:	0f 85 ba f2 ff ff    	jne    9b7b <fwp_hof0.constprop.0+0x4ab>
    a8c1:	66 85 c0             	test   %ax,%ax
    a8c4:	0f 85 dd f2 ff ff    	jne    9ba7 <fwp_hof0.constprop.0+0x4d7>
    a8ca:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a8ce:	0f 85 cf f2 ff ff    	jne    9ba3 <fwp_hof0.constprop.0+0x4d3>
    a8d4:	4c 89 ff             	mov    %r15,%rdi
    a8d7:	e8 f4 ae ff ff       	call   57d0 <fwp_rc_forget_slot>
    a8dc:	e9 c2 f2 ff ff       	jmp    9ba3 <fwp_hof0.constprop.0+0x4d3>
    a8e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a8e8:	48 89 d7             	mov    %rdx,%rdi
    a8eb:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    a8f0:	e8 db ae ff ff       	call   57d0 <fwp_rc_forget_slot>
    a8f5:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    a8fa:	e9 89 f9 ff ff       	jmp    a288 <fwp_hof0.constprop.0+0xbb8>
    a8ff:	90                   	nop
    a900:	48 8d 58 ff          	lea    -0x1(%rax),%rbx
    a904:	48 89 df             	mov    %rbx,%rdi
    a907:	48 c1 ef 3c          	shr    $0x3c,%rdi
    a90b:	0f 85 83 06 00 00    	jne    af94 <fwp_hof0.constprop.0+0x18c4>
    a911:	48 85 db             	test   %rbx,%rbx
    a914:	0f 84 e6 f2 ff ff    	je     9c00 <fwp_hof0.constprop.0+0x530>
    a91a:	48 c1 e0 04          	shl    $0x4,%rax
    a91e:	48 01 db             	add    %rbx,%rbx
    a921:	4d 8d 66 08          	lea    0x8(%r14),%r12
    a925:	4d 8d 7c 06 f8       	lea    -0x8(%r14,%rax,1),%r15
    a92a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a930:	f2 41 0f 10 04 24    	movsd  (%r12),%xmm0
    a936:	49 8b 74 24 18       	mov    0x18(%r12),%rsi
    a93b:	49 83 c4 10          	add    $0x10,%r12
    a93f:	49 8b 7c 24 f8       	mov    -0x8(%r12),%rdi
    a944:	f2 41 0f 10 0c 24    	movsd  (%r12),%xmm1
    a94a:	e8 21 bd ff ff       	call   6670 <w120>
    a94f:	66 48 0f 6e e8       	movq   %rax,%xmm5
    a954:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    a958:	41 0f 11 44 24 f0    	movups %xmm0,-0x10(%r12)
    a95e:	4d 39 e7             	cmp    %r12,%r15
    a961:	75 cd                	jne    a930 <fwp_hof0.constprop.0+0x1260>
    a963:	49 89 1e             	mov    %rbx,(%r14)
    a966:	45 31 ff             	xor    %r15d,%r15d
    a969:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    a970:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    a977:	00 f0 3f 
    a97a:	4b 8b 54 fe 10       	mov    0x10(%r14,%r15,8),%rdx
    a97f:	49 83 c7 02          	add    $0x2,%r15
    a983:	48 89 ce             	mov    %rcx,%rsi
    a986:	e8 65 b9 ff ff       	call   62f0 <fwp_p_ad_push>
    a98b:	48 89 c7             	mov    %rax,%rdi
    a98e:	49 39 df             	cmp    %rbx,%r15
    a991:	72 dd                	jb     a970 <fwp_hof0.constprop.0+0x12a0>
    a993:	49 89 c1             	mov    %rax,%r9
    a996:	e9 75 f2 ff ff       	jmp    9c10 <fwp_hof0.constprop.0+0x540>
    a99b:	be 02 00 00 00       	mov    $0x2,%esi
    a9a0:	bf 08 00 00 00       	mov    $0x8,%edi
    a9a5:	e8 66 b5 ff ff       	call   5f10 <fwp_heap_alloc>
    a9aa:	49 89 c5             	mov    %rax,%r13
    a9ad:	45 31 f6             	xor    %r14d,%r14d
    a9b0:	e9 df f9 ff ff       	jmp    a394 <fwp_hof0.constprop.0+0xcc4>
    a9b5:	0f 1f 00             	nopl   (%rax)
    a9b8:	4c 8d 61 01          	lea    0x1(%rcx),%r12
    a9bc:	4c 39 e3             	cmp    %r12,%rbx
    a9bf:	7c 32                	jl     a9f3 <fwp_hof0.constprop.0+0x1323>
    a9c1:	4d 85 d2             	test   %r10,%r10
    a9c4:	0f 84 70 06 00 00    	je     b03a <fwp_hof0.constprop.0+0x196a>
    a9ca:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
    a9cf:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    a9d6:	00 
    a9d7:	31 f6                	xor    %esi,%esi
    a9d9:	4c 89 d7             	mov    %r10,%rdi
    a9dc:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    a9e1:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    a9e6:	e9 98 f3 ff ff       	jmp    9d83 <fwp_hof0.constprop.0+0x6b3>
    a9eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a9f0:	4d 89 f4             	mov    %r14,%r12
    a9f3:	48 85 db             	test   %rbx,%rbx
    a9f6:	49 0f 44 dc          	cmove  %r12,%rbx
    a9fa:	eb 19                	jmp    aa15 <fwp_hof0.constprop.0+0x1345>
    a9fc:	0f 1f 40 00          	nopl   0x0(%rax)
    aa00:	48 8d 14 1b          	lea    (%rbx,%rbx,1),%rdx
    aa04:	48 81 fb 00 00 00 40 	cmp    $0x40000000,%rbx
    aa0b:	4c 89 e0             	mov    %r12,%rax
    aa0e:	48 0f 4c c2          	cmovl  %rdx,%rax
    aa12:	48 89 c3             	mov    %rax,%rbx
    aa15:	4c 39 e3             	cmp    %r12,%rbx
    aa18:	7c e6                	jl     aa00 <fwp_hof0.constprop.0+0x1330>
    aa1a:	4d 85 d2             	test   %r10,%r10
    aa1d:	0f 84 2d 02 00 00    	je     ac50 <fwp_hof0.constprop.0+0x1580>
    aa23:	4c 89 d7             	mov    %r10,%rdi
    aa26:	ba 03 00 00 00       	mov    $0x3,%edx
    aa2b:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    aa30:	48 8d 34 dd 00 00 00 	lea    0x0(,%rbx,8),%rsi
    aa37:	00 
    aa38:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    aa3d:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
    aa42:	e8 49 a7 ff ff       	call   5190 <ad_raw_realloc>
    aa47:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    aa4c:	66 0f 6f 54 24 50    	movdqa 0x50(%rsp),%xmm2
    aa52:	48 85 c0             	test   %rax,%rax
    aa55:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    aa5b:	49 89 c2             	mov    %rax,%r10
    aa5e:	0f 84 bc 02 00 00    	je     ad20 <fwp_hof0.constprop.0+0x1650>
    aa64:	4c 89 94 24 e0 00 00 	mov    %r10,0xe0(%rsp)
    aa6b:	00 
    aa6c:	48 89 9c 24 f0 00 00 	mov    %rbx,0xf0(%rsp)
    aa73:	00 
    aa74:	4d 85 e4             	test   %r12,%r12
    aa77:	0f 85 16 04 00 00    	jne    ae93 <fwp_hof0.constprop.0+0x17c3>
    aa7d:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    aa84:	4d 85 c9             	test   %r9,%r9
    aa87:	0f 88 23 f3 ff ff    	js     9db0 <fwp_hof0.constprop.0+0x6e0>
    aa8d:	44 89 c9             	mov    %r9d,%ecx
    aa90:	e9 07 f3 ff ff       	jmp    9d9c <fwp_hof0.constprop.0+0x6cc>
    aa95:	0f 1f 00             	nopl   (%rax)
    aa98:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    aa9d:	45 31 c0             	xor    %r8d,%r8d
    aaa0:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    aaa5:	48 83 e8 01          	sub    $0x1,%rax
    aaa9:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    aaae:	41 0f 90 c0          	seto   %r8b
    aab2:	e9 fc ec ff ff       	jmp    97b3 <fwp_hof0.constprop.0+0xe3>
    aab7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    aabe:	00 00 
    aac0:	48 8d 3d d9 c3 ff ff 	lea    -0x3c27(%rip),%rdi        # 6ea0 <fwp_tape_finish>
    aac7:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    aacd:	e8 fe 3c 00 00       	call   e7d0 <atexit>
    aad2:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    aad8:	85 c0                	test   %eax,%eax
    aada:	0f 85 e4 04 00 00    	jne    afc4 <fwp_hof0.constprop.0+0x18f4>
    aae0:	c7 05 76 85 00 00 01 	movl   $0x1,0x8576(%rip)        # 13060 <registered_finish.1>
    aae7:	00 00 00 
    aaea:	e9 fe ed ff ff       	jmp    98ed <fwp_hof0.constprop.0+0x21d>
    aaef:	90                   	nop
    aaf0:	66 85 c0             	test   %ax,%ax
    aaf3:	0f 85 37 f9 ff ff    	jne    a430 <fwp_hof0.constprop.0+0xd60>
    aaf9:	e9 0d f9 ff ff       	jmp    a40b <fwp_hof0.constprop.0+0xd3b>
    aafe:	66 90                	xchg   %ax,%ax
    ab00:	66 85 c0             	test   %ax,%ax
    ab03:	0f 85 91 ed ff ff    	jne    989a <fwp_hof0.constprop.0+0x1ca>
    ab09:	e9 64 ed ff ff       	jmp    9872 <fwp_hof0.constprop.0+0x1a2>
    ab0e:	66 90                	xchg   %ax,%ax
    ab10:	49 39 de             	cmp    %rbx,%r14
    ab13:	0f 8f d7 fe ff ff    	jg     a9f0 <fwp_hof0.constprop.0+0x1320>
    ab19:	4d 85 f6             	test   %r14,%r14
    ab1c:	74 12                	je     ab30 <fwp_hof0.constprop.0+0x1460>
    ab1e:	4d 85 d2             	test   %r10,%r10
    ab21:	0f 84 13 05 00 00    	je     b03a <fwp_hof0.constprop.0+0x196a>
    ab27:	4d 85 f6             	test   %r14,%r14
    ab2a:	0f 85 60 03 00 00    	jne    ae90 <fwp_hof0.constprop.0+0x17c0>
    ab30:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    ab37:	e9 74 f2 ff ff       	jmp    9db0 <fwp_hof0.constprop.0+0x6e0>
    ab3c:	0f 1f 40 00          	nopl   0x0(%rax)
    ab40:	66 85 c0             	test   %ax,%ax
    ab43:	0f 85 f1 f3 ff ff    	jne    9f3a <fwp_hof0.constprop.0+0x86a>
    ab49:	80 3b ff             	cmpb   $0xff,(%rbx)
    ab4c:	0f 85 e5 f3 ff ff    	jne    9f37 <fwp_hof0.constprop.0+0x867>
    ab52:	48 89 df             	mov    %rbx,%rdi
    ab55:	e8 76 ac ff ff       	call   57d0 <fwp_rc_forget_slot>
    ab5a:	e9 d8 f3 ff ff       	jmp    9f37 <fwp_hof0.constprop.0+0x867>
    ab5f:	90                   	nop
    ab60:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    ab65:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ab6a:	e9 25 f8 ff ff       	jmp    a394 <fwp_hof0.constprop.0+0xcc4>
    ab6f:	90                   	nop
    ab70:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    ab75:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    ab7c:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ab83:	48 8b 58 10          	mov    0x10(%rax),%rbx
    ab87:	48 29 c8             	sub    %rcx,%rax
    ab8a:	48 c1 e2 10          	shl    $0x10,%rdx
    ab8e:	48 39 d0             	cmp    %rdx,%rax
    ab91:	73 67                	jae    abfa <fwp_hof0.constprop.0+0x152a>
    ab93:	48 89 c7             	mov    %rax,%rdi
    ab96:	48 c1 ef 10          	shr    $0x10,%rdi
    ab9a:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    ab9e:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    aba2:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    aba6:	48 85 ff             	test   %rdi,%rdi
    aba9:	74 4f                	je     abfa <fwp_hof0.constprop.0+0x152a>
    abab:	44 0f b6 06          	movzbl (%rsi),%r8d
    abaf:	41 80 f8 02          	cmp    $0x2,%r8b
    abb3:	0f 84 48 02 00 00    	je     ae01 <fwp_hof0.constprop.0+0x1731>
    abb9:	41 80 f8 01          	cmp    $0x1,%r8b
    abbd:	75 3b                	jne    abfa <fwp_hof0.constprop.0+0x152a>
    abbf:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    abc3:	0f b7 c0             	movzwl %ax,%eax
    abc6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    abc9:	49 0f af c0          	imul   %r8,%rax
    abcd:	48 c1 e8 20          	shr    $0x20,%rax
    abd1:	48 39 f0             	cmp    %rsi,%rax
    abd4:	73 24                	jae    abfa <fwp_hof0.constprop.0+0x152a>
    abd6:	48 01 c7             	add    %rax,%rdi
    abd9:	80 3f 01             	cmpb   $0x1,(%rdi)
    abdc:	75 1c                	jne    abfa <fwp_hof0.constprop.0+0x152a>
    abde:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    abe3:	e8 28 ae ff ff       	call   5a10 <fwp_mem_free>
    abe8:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    abef:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    abf6:	48 c1 e2 10          	shl    $0x10,%rdx
    abfa:	48 89 d8             	mov    %rbx,%rax
    abfd:	48 29 c8             	sub    %rcx,%rax
    ac00:	48 39 d0             	cmp    %rdx,%rax
    ac03:	0f 83 27 f8 ff ff    	jae    a430 <fwp_hof0.constprop.0+0xd60>
    ac09:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    ac0e:	e9 af f7 ff ff       	jmp    a3c2 <fwp_hof0.constprop.0+0xcf2>
    ac13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ac18:	66 85 c0             	test   %ax,%ax
    ac1b:	0f 85 1d fc ff ff    	jne    a83e <fwp_hof0.constprop.0+0x116e>
    ac21:	80 3b ff             	cmpb   $0xff,(%rbx)
    ac24:	0f 85 11 fc ff ff    	jne    a83b <fwp_hof0.constprop.0+0x116b>
    ac2a:	48 89 df             	mov    %rbx,%rdi
    ac2d:	e8 9e ab ff ff       	call   57d0 <fwp_rc_forget_slot>
    ac32:	e9 04 fc ff ff       	jmp    a83b <fwp_hof0.constprop.0+0x116b>
    ac37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ac3e:	00 00 
    ac40:	48 85 db             	test   %rbx,%rbx
    ac43:	0f 85 63 ef ff ff    	jne    9bac <fwp_hof0.constprop.0+0x4dc>
    ac49:	e9 b2 ef ff ff       	jmp    9c00 <fwp_hof0.constprop.0+0x530>
    ac4e:	66 90                	xchg   %ax,%ax
    ac50:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    ac57:	ff ff 1f 
    ac5a:	48 8d 43 ff          	lea    -0x1(%rbx),%rax
    ac5e:	48 39 c2             	cmp    %rax,%rdx
    ac61:	0f 82 26 04 00 00    	jb     b08d <fwp_hof0.constprop.0+0x19bd>
    ac67:	48 8d 05 52 85 04 00 	lea    0x48552(%rip),%rax        # 531c0 <ad_raw_blocks>
    ac6e:	45 31 ff             	xor    %r15d,%r15d
    ac71:	eb 22                	jmp    ac95 <fwp_hof0.constprop.0+0x15c5>
    ac73:	66 90                	xchg   %ax,%ax
    ac75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ac7c:	00 00 00 00 
    ac80:	49 83 c7 01          	add    $0x1,%r15
    ac84:	48 83 c0 18          	add    $0x18,%rax
    ac88:	49 81 ff 00 10 00 00 	cmp    $0x1000,%r15
    ac8f:	0f 84 3d 02 00 00    	je     aed2 <fwp_hof0.constprop.0+0x1802>
    ac95:	48 83 38 00          	cmpq   $0x0,(%rax)
    ac99:	75 e5                	jne    ac80 <fwp_hof0.constprop.0+0x15b0>
    ac9b:	be 08 00 00 00       	mov    $0x8,%esi
    aca0:	48 89 df             	mov    %rbx,%rdi
    aca3:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    aca8:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    acad:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
    acb2:	e8 59 88 ff ff       	call   3510 <calloc@plt>
    acb7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    acbc:	66 0f 6f 54 24 50    	movdqa 0x50(%rsp),%xmm2
    acc2:	48 8d 15 f7 84 04 00 	lea    0x484f7(%rip),%rdx        # 531c0 <ad_raw_blocks>
    acc9:	48 85 c0             	test   %rax,%rax
    accc:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    acd2:	49 89 c2             	mov    %rax,%r10
    acd5:	74 49                	je     ad20 <fwp_hof0.constprop.0+0x1650>
    acd7:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
    acdb:	48 89 c6             	mov    %rax,%rsi
    acde:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    ace3:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    ace7:	b9 03 00 00 00       	mov    $0x3,%ecx
    acec:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    acf3:	00 
    acf4:	e8 07 8f ff ff       	call   3c00 <ad_raw_record>
    acf9:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    acfe:	e9 61 fd ff ff       	jmp    aa64 <fwp_hof0.constprop.0+0x1394>
    ad03:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ad08:	66 85 c0             	test   %ax,%ax
    ad0b:	0f 85 8c ea ff ff    	jne    979d <fwp_hof0.constprop.0+0xcd>
    ad11:	e9 5f ea ff ff       	jmp    9775 <fwp_hof0.constprop.0+0xa5>
    ad16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ad1d:	00 00 00 
    ad20:	4d 85 e4             	test   %r12,%r12
    ad23:	0f 85 11 03 00 00    	jne    b03a <fwp_hof0.constprop.0+0x196a>
    ad29:	45 31 d2             	xor    %r10d,%r10d
    ad2c:	e9 4c fd ff ff       	jmp    aa7d <fwp_hof0.constprop.0+0x13ad>
    ad31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ad38:	66 85 c0             	test   %ax,%ax
    ad3b:	0f 85 08 f8 ff ff    	jne    a549 <fwp_hof0.constprop.0+0xe79>
    ad41:	41 80 3f ff          	cmpb   $0xff,(%r15)
    ad45:	0f 85 fa f7 ff ff    	jne    a545 <fwp_hof0.constprop.0+0xe75>
    ad4b:	4c 89 ff             	mov    %r15,%rdi
    ad4e:	e8 7d aa ff ff       	call   57d0 <fwp_rc_forget_slot>
    ad53:	e9 ed f7 ff ff       	jmp    a545 <fwp_hof0.constprop.0+0xe75>
    ad58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ad5f:	00 
    ad60:	66 85 c0             	test   %ax,%ax
    ad63:	0f 85 97 f8 ff ff    	jne    a600 <fwp_hof0.constprop.0+0xf30>
    ad69:	41 0f b6 04 24       	movzbl (%r12),%eax
    ad6e:	84 c0                	test   %al,%al
    ad70:	0f 84 8a f8 ff ff    	je     a600 <fwp_hof0.constprop.0+0xf30>
    ad76:	3c 01                	cmp    $0x1,%al
    ad78:	0f 85 6f f8 ff ff    	jne    a5ed <fwp_hof0.constprop.0+0xf1d>
    ad7e:	48 89 df             	mov    %rbx,%rdi
    ad81:	e8 8a ac ff ff       	call   5a10 <fwp_mem_free>
    ad86:	e9 75 f8 ff ff       	jmp    a600 <fwp_hof0.constprop.0+0xf30>
    ad8b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ad8f:	e9 4b eb ff ff       	jmp    98df <fwp_hof0.constprop.0+0x20f>
    ad94:	49 8b 04 24          	mov    (%r12),%rax
    ad98:	48 85 c0             	test   %rax,%rax
    ad9b:	0f 88 fa fb ff ff    	js     a99b <fwp_hof0.constprop.0+0x12cb>
    ada1:	48 8b b5 d8 13 00 00 	mov    0x13d8(%rbp),%rsi
    ada8:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    adad:	48 2b 8d b0 13 00 00 	sub    0x13b0(%rbp),%rcx
    adb4:	48 c1 e6 10          	shl    $0x10,%rsi
    adb8:	48 39 f1             	cmp    %rsi,%rcx
    adbb:	0f 83 da fb ff ff    	jae    a99b <fwp_hof0.constprop.0+0x12cb>
    adc1:	48 89 ce             	mov    %rcx,%rsi
    adc4:	48 c1 ee 10          	shr    $0x10,%rsi
    adc8:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    adcc:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    add3:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    add7:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    addb:	48 85 ff             	test   %rdi,%rdi
    adde:	0f 84 b7 fb ff ff    	je     a99b <fwp_hof0.constprop.0+0x12cb>
    ade4:	48 0f ba f0 3f       	btr    $0x3f,%rax
    ade9:	49 89 c7             	mov    %rax,%r15
    adec:	e9 e4 f2 ff ff       	jmp    a0d5 <fwp_hof0.constprop.0+0xa05>
    adf1:	be 68 00 00 00       	mov    $0x68,%esi
    adf6:	41 be 01 00 00 00    	mov    $0x1,%r14d
    adfc:	e9 69 eb ff ff       	jmp    996a <fwp_hof0.constprop.0+0x29a>
    ae01:	66 85 c0             	test   %ax,%ax
    ae04:	0f 85 f0 fd ff ff    	jne    abfa <fwp_hof0.constprop.0+0x152a>
    ae0a:	e9 ca fd ff ff       	jmp    abd9 <fwp_hof0.constprop.0+0x1509>
    ae0f:	48 89 da             	mov    %rbx,%rdx
    ae12:	48 c1 ea 11          	shr    $0x11,%rdx
    ae16:	48 31 da             	xor    %rbx,%rdx
    ae19:	48 89 d0             	mov    %rdx,%rax
    ae1c:	48 c1 e8 09          	shr    $0x9,%rax
    ae20:	48 31 c2             	xor    %rax,%rdx
    ae23:	0f b6 d2             	movzbl %dl,%edx
    ae26:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    ae2d:	00 
    ae2e:	48 85 c0             	test   %rax,%rax
    ae31:	75 16                	jne    ae49 <fwp_hof0.constprop.0+0x1779>
    ae33:	eb 4f                	jmp    ae84 <fwp_hof0.constprop.0+0x17b4>
    ae35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ae3c:	00 00 00 00 
    ae40:	48 8b 42 10          	mov    0x10(%rdx),%rax
    ae44:	48 85 c0             	test   %rax,%rax
    ae47:	74 3b                	je     ae84 <fwp_hof0.constprop.0+0x17b4>
    ae49:	48 89 c2             	mov    %rax,%rdx
    ae4c:	48 3b 18             	cmp    (%rax),%rbx
    ae4f:	75 ef                	jne    ae40 <fwp_hof0.constprop.0+0x1770>
    ae51:	48 8b 78 08          	mov    0x8(%rax),%rdi
    ae55:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    ae59:	48 89 50 08          	mov    %rdx,0x8(%rax)
    ae5d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    ae64:	0f 85 c6 f5 ff ff    	jne    a430 <fwp_hof0.constprop.0+0xd60>
    ae6a:	48 89 df             	mov    %rbx,%rdi
    ae6d:	e8 5e a9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    ae72:	c6 03 fe             	movb   $0xfe,(%rbx)
    ae75:	e9 b6 f5 ff ff       	jmp    a430 <fwp_hof0.constprop.0+0xd60>
    ae7a:	e8 31 a8 ff ff       	call   56b0 <fwp_rc_wide_dup>
    ae7f:	e9 16 ea ff ff       	jmp    989a <fwp_hof0.constprop.0+0x1ca>
    ae84:	48 8d 3d 65 4b 00 00 	lea    0x4b65(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    ae8b:	e8 c0 95 ff ff       	call   4450 <fwp_trap>
    ae90:	4d 89 f4             	mov    %r14,%r12
    ae93:	4c 89 d7             	mov    %r10,%rdi
    ae96:	31 f6                	xor    %esi,%esi
    ae98:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    ae9d:	4d 8d 7c 24 ff       	lea    -0x1(%r12),%r15
    aea2:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    aea9:	00 
    aeaa:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    aeaf:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
    aeb4:	e8 f7 85 ff ff       	call   34b0 <memset@plt>
    aeb9:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    aebe:	66 0f 6f 54 24 50    	movdqa 0x50(%rsp),%xmm2
    aec4:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    aeca:	49 89 c2             	mov    %rax,%r10
    aecd:	e9 b2 fb ff ff       	jmp    aa84 <fwp_hof0.constprop.0+0x13b4>
    aed2:	48 8d 3d 39 42 00 00 	lea    0x4239(%rip),%rdi        # f112 <_IO_stdin_used+0x112>
    aed9:	e8 22 91 ff ff       	call   4000 <ad_raw_fail>
    aede:	e8 cd a7 ff ff       	call   56b0 <fwp_rc_wide_dup>
    aee3:	e9 b5 e8 ff ff       	jmp    979d <fwp_hof0.constprop.0+0xcd>
    aee8:	4c 89 e0             	mov    %r12,%rax
    aeeb:	48 c1 e8 11          	shr    $0x11,%rax
    aeef:	4c 31 e0             	xor    %r12,%rax
    aef2:	48 89 c2             	mov    %rax,%rdx
    aef5:	48 c1 ea 09          	shr    $0x9,%rdx
    aef9:	48 31 d0             	xor    %rdx,%rax
    aefc:	0f b6 d0             	movzbl %al,%edx
    aeff:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    af06:	00 
    af07:	48 85 c0             	test   %rax,%rax
    af0a:	75 21                	jne    af2d <fwp_hof0.constprop.0+0x185d>
    af0c:	e9 73 ff ff ff       	jmp    ae84 <fwp_hof0.constprop.0+0x17b4>
    af11:	0f 1f 40 00          	nopl   0x0(%rax)
    af15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    af1c:	00 00 00 00 
    af20:	48 8b 42 10          	mov    0x10(%rdx),%rax
    af24:	48 85 c0             	test   %rax,%rax
    af27:	0f 84 57 ff ff ff    	je     ae84 <fwp_hof0.constprop.0+0x17b4>
    af2d:	48 89 c2             	mov    %rax,%rdx
    af30:	4c 3b 20             	cmp    (%rax),%r12
    af33:	75 eb                	jne    af20 <fwp_hof0.constprop.0+0x1850>
    af35:	48 8b 78 08          	mov    0x8(%rax),%rdi
    af39:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    af3d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    af41:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    af48:	0f 85 b2 f6 ff ff    	jne    a600 <fwp_hof0.constprop.0+0xf30>
    af4e:	4c 89 e7             	mov    %r12,%rdi
    af51:	e8 7a a8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    af56:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    af5b:	e9 a0 f6 ff ff       	jmp    a600 <fwp_hof0.constprop.0+0xf30>
    af60:	45 31 ff             	xor    %r15d,%r15d
    af63:	e9 ed f2 ff ff       	jmp    a255 <fwp_hof0.constprop.0+0xb85>
    af68:	48 8d 3d a9 4a 00 00 	lea    0x4aa9(%rip),%rdi        # fa18 <_IO_stdin_used+0xa18>
    af6f:	e8 dc 94 ff ff       	call   4450 <fwp_trap>
    af74:	48 8d 3d 47 42 00 00 	lea    0x4247(%rip),%rdi        # f1c2 <_IO_stdin_used+0x1c2>
    af7b:	e8 d0 94 ff ff       	call   4450 <fwp_trap>
    af80:	48 8d 3d 69 4b 00 00 	lea    0x4b69(%rip),%rdi        # faf0 <_IO_stdin_used+0xaf0>
    af87:	e8 c4 94 ff ff       	call   4450 <fwp_trap>
    af8c:	45 31 ed             	xor    %r13d,%r13d
    af8f:	e9 19 fa ff ff       	jmp    a9ad <fwp_hof0.constprop.0+0x12dd>
    af94:	48 8d 3d 50 42 00 00 	lea    0x4250(%rip),%rdi        # f1eb <_IO_stdin_used+0x1eb>
    af9b:	e8 b0 94 ff ff       	call   4450 <fwp_trap>
    afa0:	48 8d 3d d5 42 00 00 	lea    0x42d5(%rip),%rdi        # f27c <_IO_stdin_used+0x27c>
    afa7:	e8 a4 94 ff ff       	call   4450 <fwp_trap>
    afac:	48 8d 3d ff 42 00 00 	lea    0x42ff(%rip),%rdi        # f2b2 <_IO_stdin_used+0x2b2>
    afb3:	e8 98 94 ff ff       	call   4450 <fwp_trap>
    afb8:	48 8d 3d 01 4b 00 00 	lea    0x4b01(%rip),%rdi        # fac0 <_IO_stdin_used+0xac0>
    afbf:	e8 8c 94 ff ff       	call   4450 <fwp_trap>
    afc4:	48 8b 0d 75 80 00 00 	mov    0x8075(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    afcb:	ba 13 00 00 00       	mov    $0x13,%edx
    afd0:	be 01 00 00 00       	mov    $0x1,%esi
    afd5:	48 8d 3d 2c 40 00 00 	lea    0x402c(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    afdc:	e8 7f 86 ff ff       	call   3660 <fwrite@plt>
    afe1:	31 ff                	xor    %edi,%edi
    afe3:	e8 b8 85 ff ff       	call   35a0 <fflush@plt>
    afe8:	bf 66 00 00 00       	mov    $0x66,%edi
    afed:	e8 8e 86 ff ff       	call   3680 <_Exit@plt>
    aff2:	48 8d 3d c9 42 00 00 	lea    0x42c9(%rip),%rdi        # f2c2 <_IO_stdin_used+0x2c2>
    aff9:	e8 52 94 ff ff       	call   4450 <fwp_trap>
    affe:	66 90                	xchg   %ax,%ax
    b000:	48 8d 3d 11 4b 00 00 	lea    0x4b11(%rip),%rdi        # fb18 <_IO_stdin_used+0xb18>
    b007:	e8 44 94 ff ff       	call   4450 <fwp_trap>
    b00c:	48 8b 0d 2d 80 00 00 	mov    0x802d(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b013:	ba 13 00 00 00       	mov    $0x13,%edx
    b018:	be 01 00 00 00       	mov    $0x1,%esi
    b01d:	48 8d 3d e4 3f 00 00 	lea    0x3fe4(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b024:	e8 37 86 ff ff       	call   3660 <fwrite@plt>
    b029:	31 ff                	xor    %edi,%edi
    b02b:	e8 70 85 ff ff       	call   35a0 <fflush@plt>
    b030:	bf 66 00 00 00       	mov    $0x66,%edi
    b035:	e8 46 86 ff ff       	call   3680 <_Exit@plt>
    b03a:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    b041:	00 
    b042:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    b047:	48 89 05 6a 24 06 00 	mov    %rax,0x6246a(%rip)        # 6d4b8 <fwp_cleanups>
    b04e:	e8 0d a2 ff ff       	call   5260 <fwp_tape_buffers_release>
    b053:	ba 13 00 00 00       	mov    $0x13,%edx
    b058:	48 8b 0d e1 7f 00 00 	mov    0x7fe1(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b05f:	be 01 00 00 00       	mov    $0x1,%esi
    b064:	48 8d 3d 9d 3f 00 00 	lea    0x3f9d(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b06b:	e8 f0 85 ff ff       	call   3660 <fwrite@plt>
    b070:	31 ff                	xor    %edi,%edi
    b072:	e8 29 85 ff ff       	call   35a0 <fflush@plt>
    b077:	bf 66 00 00 00       	mov    $0x66,%edi
    b07c:	e8 ff 85 ff ff       	call   3680 <_Exit@plt>
    b081:	48 8d 3d d8 49 00 00 	lea    0x49d8(%rip),%rdi        # fa60 <_IO_stdin_used+0xa60>
    b088:	e8 c3 93 ff ff       	call   4450 <fwp_trap>
    b08d:	48 8d 3d 02 42 00 00 	lea    0x4202(%rip),%rdi        # f296 <_IO_stdin_used+0x296>
    b094:	e8 67 8f ff ff       	call   4000 <ad_raw_fail>
    b099:	e8 b2 83 ff ff       	call   3450 <__stack_chk_fail@plt>
    b09e:	66 90                	xchg   %ax,%ax

000000000000b0a0 <f0>:
    b0a0:	41 56                	push   %r14
    b0a2:	4c 8d 35 77 07 06 00 	lea    0x60777(%rip),%r14        # 6b820 <fwp_heap>
    b0a9:	41 55                	push   %r13
    b0ab:	41 54                	push   %r12
    b0ad:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    b0b3:	55                   	push   %rbp
    b0b4:	53                   	push   %rbx
    b0b5:	31 db                	xor    %ebx,%ebx
    b0b7:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    b0be:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b0c5:	00 00 
    b0c7:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    b0ce:	00 
    b0cf:	31 c0                	xor    %eax,%eax
    b0d1:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    b0d8:	00 
    b0d9:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    b0e0:	00 00 
    b0e2:	66 48 0f 6e c0       	movq   %rax,%xmm0
    b0e7:	48 8d 05 22 cc ff ff 	lea    -0x33de(%rip),%rax        # 7d10 <fwp_drop1>
    b0ee:	66 48 0f 6e c8       	movq   %rax,%xmm1
    b0f3:	48 8b 05 be 23 06 00 	mov    0x623be(%rip),%rax        # 6d4b8 <fwp_cleanups>
    b0fa:	48 89 25 b7 23 06 00 	mov    %rsp,0x623b7(%rip)        # 6d4b8 <fwp_cleanups>
    b101:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    b105:	48 89 04 24          	mov    %rax,(%rsp)
    b109:	48 8d 05 c0 8a ff ff 	lea    -0x7540(%rip),%rax        # 3bd0 <fwp_range_release>
    b110:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b115:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    b11a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b11f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    b124:	eb 47                	jmp    b16d <f0+0xcd>
    b126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b12d:	00 00 00 
    b130:	80 f9 01             	cmp    $0x1,%cl
    b133:	75 29                	jne    b15e <f0+0xbe>
    b135:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b138:	0f b7 c0             	movzwl %ax,%eax
    b13b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b13e:	48 0f af c1          	imul   %rcx,%rax
    b142:	48 c1 e8 20          	shr    $0x20,%rax
    b146:	48 39 d0             	cmp    %rdx,%rax
    b149:	73 13                	jae    b15e <f0+0xbe>
    b14b:	49 01 c5             	add    %rax,%r13
    b14e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b153:	0f 84 c7 27 00 00    	je     d920 <f0+0x2880>
    b159:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b15e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b163:	49 83 ec 01          	sub    $0x1,%r12
    b167:	0f 82 83 00 00 00    	jb     b1f0 <f0+0x150>
    b16d:	48 89 ee             	mov    %rbp,%rsi
    b170:	bf 01 00 00 00       	mov    $0x1,%edi
    b175:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    b17c:	00 
    b17d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    b182:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    b189:	00 
    b18a:	e8 71 af ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b18f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b196:	48 89 c3             	mov    %rax,%rbx
    b199:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b1a0:	48 c1 e2 10          	shl    $0x10,%rdx
    b1a4:	48 39 d0             	cmp    %rdx,%rax
    b1a7:	73 b5                	jae    b15e <f0+0xbe>
    b1a9:	48 89 c2             	mov    %rax,%rdx
    b1ac:	48 c1 ea 10          	shr    $0x10,%rdx
    b1b0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b1b4:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b1bb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b1bf:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b1c3:	4d 85 ed             	test   %r13,%r13
    b1c6:	74 96                	je     b15e <f0+0xbe>
    b1c8:	0f b6 0a             	movzbl (%rdx),%ecx
    b1cb:	80 f9 02             	cmp    $0x2,%cl
    b1ce:	0f 85 5c ff ff ff    	jne    b130 <f0+0x90>
    b1d4:	66 85 c0             	test   %ax,%ax
    b1d7:	0f 84 71 ff ff ff    	je     b14e <f0+0xae>
    b1dd:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b1e2:	49 83 ec 01          	sub    $0x1,%r12
    b1e6:	73 85                	jae    b16d <f0+0xcd>
    b1e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b1ef:	00 
    b1f0:	48 8b 04 24          	mov    (%rsp),%rax
    b1f4:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    b1f9:	bf 01 00 00 00       	mov    $0x1,%edi
    b1fe:	66 0f 6f 05 0a 4c 00 	movdqa 0x4c0a(%rip),%xmm0        # fe10 <msg.4+0xd0>
    b205:	00 
    b206:	48 89 05 ab 22 06 00 	mov    %rax,0x622ab(%rip)        # 6d4b8 <fwp_cleanups>
    b20d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b212:	e8 e9 ae ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b217:	48 8b 15 da 19 06 00 	mov    0x619da(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b21e:	49 89 c5             	mov    %rax,%r13
    b221:	48 2b 05 a8 19 06 00 	sub    0x619a8(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b228:	48 c1 e2 10          	shl    $0x10,%rdx
    b22c:	48 39 d0             	cmp    %rdx,%rax
    b22f:	73 59                	jae    b28a <f0+0x1ea>
    b231:	48 89 c2             	mov    %rax,%rdx
    b234:	48 c1 ea 10          	shr    $0x10,%rdx
    b238:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b23c:	48 8b 15 d5 19 06 00 	mov    0x619d5(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b243:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b247:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b24b:	4d 85 e4             	test   %r12,%r12
    b24e:	74 3a                	je     b28a <f0+0x1ea>
    b250:	0f b6 0a             	movzbl (%rdx),%ecx
    b253:	80 f9 02             	cmp    $0x2,%cl
    b256:	0f 84 74 27 00 00    	je     d9d0 <f0+0x2930>
    b25c:	80 f9 01             	cmp    $0x1,%cl
    b25f:	75 29                	jne    b28a <f0+0x1ea>
    b261:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b264:	0f b7 c0             	movzwl %ax,%eax
    b267:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b26a:	48 0f af c1          	imul   %rcx,%rax
    b26e:	48 c1 e8 20          	shr    $0x20,%rax
    b272:	48 39 d0             	cmp    %rdx,%rax
    b275:	73 13                	jae    b28a <f0+0x1ea>
    b277:	49 01 c4             	add    %rax,%r12
    b27a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b27f:	0f 84 26 29 00 00    	je     dbab <f0+0x2b0b>
    b285:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b28a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    b28f:	bf 01 00 00 00       	mov    $0x1,%edi
    b294:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    b299:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b2a0:	00 f0 3f 
    b2a3:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    b2a8:	e8 53 ae ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b2ad:	48 8b 15 44 19 06 00 	mov    0x61944(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b2b4:	49 89 c5             	mov    %rax,%r13
    b2b7:	48 2b 05 12 19 06 00 	sub    0x61912(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b2be:	48 c1 e2 10          	shl    $0x10,%rdx
    b2c2:	48 39 d0             	cmp    %rdx,%rax
    b2c5:	73 59                	jae    b320 <f0+0x280>
    b2c7:	48 89 c2             	mov    %rax,%rdx
    b2ca:	48 c1 ea 10          	shr    $0x10,%rdx
    b2ce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b2d2:	48 8b 15 3f 19 06 00 	mov    0x6193f(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b2d9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b2dd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b2e1:	4d 85 e4             	test   %r12,%r12
    b2e4:	74 3a                	je     b320 <f0+0x280>
    b2e6:	0f b6 0a             	movzbl (%rdx),%ecx
    b2e9:	80 f9 02             	cmp    $0x2,%cl
    b2ec:	0f 84 ce 26 00 00    	je     d9c0 <f0+0x2920>
    b2f2:	80 f9 01             	cmp    $0x1,%cl
    b2f5:	75 29                	jne    b320 <f0+0x280>
    b2f7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b2fa:	0f b7 c0             	movzwl %ax,%eax
    b2fd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b300:	48 0f af c1          	imul   %rcx,%rax
    b304:	48 c1 e8 20          	shr    $0x20,%rax
    b308:	48 39 d0             	cmp    %rdx,%rax
    b30b:	73 13                	jae    b320 <f0+0x280>
    b30d:	49 01 c4             	add    %rax,%r12
    b310:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b315:	0f 84 9d 28 00 00    	je     dbb8 <f0+0x2b18>
    b31b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b320:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b325:	bf 01 00 00 00       	mov    $0x1,%edi
    b32a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    b32f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b336:	33 f3 bf 
    b339:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b33e:	e8 bd ad ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b343:	48 8b 15 ae 18 06 00 	mov    0x618ae(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b34a:	49 89 c5             	mov    %rax,%r13
    b34d:	48 2b 05 7c 18 06 00 	sub    0x6187c(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b354:	48 c1 e2 10          	shl    $0x10,%rdx
    b358:	48 39 d0             	cmp    %rdx,%rax
    b35b:	73 59                	jae    b3b6 <f0+0x316>
    b35d:	48 89 c2             	mov    %rax,%rdx
    b360:	48 c1 ea 10          	shr    $0x10,%rdx
    b364:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b368:	48 8b 15 a9 18 06 00 	mov    0x618a9(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b36f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b373:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b377:	4d 85 e4             	test   %r12,%r12
    b37a:	74 3a                	je     b3b6 <f0+0x316>
    b37c:	0f b6 0a             	movzbl (%rdx),%ecx
    b37f:	80 f9 02             	cmp    $0x2,%cl
    b382:	0f 84 28 26 00 00    	je     d9b0 <f0+0x2910>
    b388:	80 f9 01             	cmp    $0x1,%cl
    b38b:	75 29                	jne    b3b6 <f0+0x316>
    b38d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b390:	0f b7 c0             	movzwl %ax,%eax
    b393:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b396:	48 0f af c1          	imul   %rcx,%rax
    b39a:	48 c1 e8 20          	shr    $0x20,%rax
    b39e:	48 39 d0             	cmp    %rdx,%rax
    b3a1:	73 13                	jae    b3b6 <f0+0x316>
    b3a3:	49 01 c4             	add    %rax,%r12
    b3a6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b3ab:	0f 84 14 28 00 00    	je     dbc5 <f0+0x2b25>
    b3b1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b3b6:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b3bb:	bf 01 00 00 00       	mov    $0x1,%edi
    b3c0:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    b3c5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b3cc:	00 f0 3f 
    b3cf:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b3d4:	e8 27 ad ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b3d9:	48 8b 15 18 18 06 00 	mov    0x61818(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b3e0:	49 89 c5             	mov    %rax,%r13
    b3e3:	48 2b 05 e6 17 06 00 	sub    0x617e6(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b3ea:	48 c1 e2 10          	shl    $0x10,%rdx
    b3ee:	48 39 d0             	cmp    %rdx,%rax
    b3f1:	73 59                	jae    b44c <f0+0x3ac>
    b3f3:	48 89 c2             	mov    %rax,%rdx
    b3f6:	48 c1 ea 10          	shr    $0x10,%rdx
    b3fa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b3fe:	48 8b 15 13 18 06 00 	mov    0x61813(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b405:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b409:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b40d:	4d 85 e4             	test   %r12,%r12
    b410:	74 3a                	je     b44c <f0+0x3ac>
    b412:	0f b6 0a             	movzbl (%rdx),%ecx
    b415:	80 f9 02             	cmp    $0x2,%cl
    b418:	0f 84 f2 25 00 00    	je     da10 <f0+0x2970>
    b41e:	80 f9 01             	cmp    $0x1,%cl
    b421:	75 29                	jne    b44c <f0+0x3ac>
    b423:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b426:	0f b7 c0             	movzwl %ax,%eax
    b429:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b42c:	48 0f af c1          	imul   %rcx,%rax
    b430:	48 c1 e8 20          	shr    $0x20,%rax
    b434:	48 39 d0             	cmp    %rdx,%rax
    b437:	73 13                	jae    b44c <f0+0x3ac>
    b439:	49 01 c4             	add    %rax,%r12
    b43c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b441:	0f 84 8b 27 00 00    	je     dbd2 <f0+0x2b32>
    b447:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b44c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b453:	33 f3 bf 
    b456:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    b45d:	00 
    b45e:	bf 01 00 00 00       	mov    $0x1,%edi
    b463:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    b46a:	00 
    b46b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    b472:	00 
    b473:	e8 88 ac ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b478:	48 8b 15 79 17 06 00 	mov    0x61779(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b47f:	49 89 c5             	mov    %rax,%r13
    b482:	48 2b 05 47 17 06 00 	sub    0x61747(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b489:	48 c1 e2 10          	shl    $0x10,%rdx
    b48d:	48 39 d0             	cmp    %rdx,%rax
    b490:	73 59                	jae    b4eb <f0+0x44b>
    b492:	48 89 c2             	mov    %rax,%rdx
    b495:	48 c1 ea 10          	shr    $0x10,%rdx
    b499:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b49d:	48 8b 15 74 17 06 00 	mov    0x61774(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b4a4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b4a8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b4ac:	4d 85 e4             	test   %r12,%r12
    b4af:	74 3a                	je     b4eb <f0+0x44b>
    b4b1:	0f b6 0a             	movzbl (%rdx),%ecx
    b4b4:	80 f9 02             	cmp    $0x2,%cl
    b4b7:	0f 84 43 25 00 00    	je     da00 <f0+0x2960>
    b4bd:	80 f9 01             	cmp    $0x1,%cl
    b4c0:	75 29                	jne    b4eb <f0+0x44b>
    b4c2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b4c5:	0f b7 c0             	movzwl %ax,%eax
    b4c8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b4cb:	48 0f af c1          	imul   %rcx,%rax
    b4cf:	48 c1 e8 20          	shr    $0x20,%rax
    b4d3:	48 39 d0             	cmp    %rdx,%rax
    b4d6:	73 13                	jae    b4eb <f0+0x44b>
    b4d8:	49 01 c4             	add    %rax,%r12
    b4db:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b4e0:	0f 84 f9 26 00 00    	je     dbdf <f0+0x2b3f>
    b4e6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b4eb:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    b4f2:	00 f0 3f 
    b4f5:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    b4fc:	00 
    b4fd:	bf 01 00 00 00       	mov    $0x1,%edi
    b502:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    b509:	00 
    b50a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    b511:	00 
    b512:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    b519:	33 f3 bf 
    b51c:	e8 df ab ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b521:	48 89 c7             	mov    %rax,%rdi
    b524:	e8 37 b3 ff ff       	call   6860 <fwp_rc_fresh>
    b529:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    b530:	00 
    b531:	bf 01 00 00 00       	mov    $0x1,%edi
    b536:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    b53d:	00 
    b53e:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    b545:	00 
    b546:	e8 b5 ab ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b54b:	48 89 c7             	mov    %rax,%rdi
    b54e:	e8 0d b3 ff ff       	call   6860 <fwp_rc_fresh>
    b553:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    b55a:	00 
    b55b:	bf 01 00 00 00       	mov    $0x1,%edi
    b560:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    b567:	00 
    b568:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    b56f:	00 
    b570:	e8 8b ab ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b575:	48 89 c7             	mov    %rax,%rdi
    b578:	e8 e3 b2 ff ff       	call   6860 <fwp_rc_fresh>
    b57d:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    b584:	00 
    b585:	bf 01 00 00 00       	mov    $0x1,%edi
    b58a:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    b591:	00 
    b592:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    b599:	00 
    b59a:	e8 61 ab ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b59f:	48 89 c7             	mov    %rax,%rdi
    b5a2:	e8 b9 b2 ff ff       	call   6860 <fwp_rc_fresh>
    b5a7:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    b5ae:	00 
    b5af:	bf 01 00 00 00       	mov    $0x1,%edi
    b5b4:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    b5bb:	00 
    b5bc:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    b5c3:	00 
    b5c4:	e8 37 ab ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b5c9:	48 89 c7             	mov    %rax,%rdi
    b5cc:	e8 8f b2 ff ff       	call   6860 <fwp_rc_fresh>
    b5d1:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    b5d8:	00 
    b5d9:	bf 01 00 00 00       	mov    $0x1,%edi
    b5de:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    b5e5:	00 
    b5e6:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    b5ed:	00 
    b5ee:	e8 0d ab ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b5f3:	48 89 c7             	mov    %rax,%rdi
    b5f6:	e8 65 b2 ff ff       	call   6860 <fwp_rc_fresh>
    b5fb:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    b602:	00 
    b603:	bf 01 00 00 00       	mov    $0x1,%edi
    b608:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    b60f:	00 
    b610:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    b617:	00 
    b618:	e8 e3 aa ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b61d:	48 89 c7             	mov    %rax,%rdi
    b620:	e8 3b b2 ff ff       	call   6860 <fwp_rc_fresh>
    b625:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    b62c:	00 
    b62d:	bf 01 00 00 00       	mov    $0x1,%edi
    b632:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    b639:	00 
    b63a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    b641:	00 
    b642:	e8 b9 aa ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b647:	48 89 c7             	mov    %rax,%rdi
    b64a:	e8 11 b2 ff ff       	call   6860 <fwp_rc_fresh>
    b64f:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    b656:	00 
    b657:	bf 01 00 00 00       	mov    $0x1,%edi
    b65c:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    b663:	00 
    b664:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    b66b:	00 
    b66c:	e8 8f aa ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b671:	48 89 c7             	mov    %rax,%rdi
    b674:	e8 e7 b1 ff ff       	call   6860 <fwp_rc_fresh>
    b679:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    b680:	00 
    b681:	bf 01 00 00 00       	mov    $0x1,%edi
    b686:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    b68d:	00 
    b68e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    b695:	00 
    b696:	e8 65 aa ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b69b:	48 89 c7             	mov    %rax,%rdi
    b69e:	e8 bd b1 ff ff       	call   6860 <fwp_rc_fresh>
    b6a3:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    b6aa:	00 
    b6ab:	bf 01 00 00 00       	mov    $0x1,%edi
    b6b0:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    b6b7:	00 
    b6b8:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    b6bf:	00 
    b6c0:	e8 3b aa ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b6c5:	48 89 c7             	mov    %rax,%rdi
    b6c8:	e8 93 b1 ff ff       	call   6860 <fwp_rc_fresh>
    b6cd:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    b6d4:	00 
    b6d5:	bf 01 00 00 00       	mov    $0x1,%edi
    b6da:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    b6e1:	00 
    b6e2:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    b6e9:	00 
    b6ea:	e8 11 aa ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b6ef:	48 89 c7             	mov    %rax,%rdi
    b6f2:	e8 69 b1 ff ff       	call   6860 <fwp_rc_fresh>
    b6f7:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    b6fe:	00 
    b6ff:	bf 01 00 00 00       	mov    $0x1,%edi
    b704:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    b70b:	00 
    b70c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    b713:	00 
    b714:	e8 e7 a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b719:	48 89 c7             	mov    %rax,%rdi
    b71c:	e8 3f b1 ff ff       	call   6860 <fwp_rc_fresh>
    b721:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    b728:	00 
    b729:	bf 01 00 00 00       	mov    $0x1,%edi
    b72e:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    b735:	00 
    b736:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    b73d:	00 
    b73e:	e8 bd a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b743:	48 89 c7             	mov    %rax,%rdi
    b746:	e8 15 b1 ff ff       	call   6860 <fwp_rc_fresh>
    b74b:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    b752:	00 
    b753:	bf 01 00 00 00       	mov    $0x1,%edi
    b758:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    b75f:	00 
    b760:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    b767:	00 
    b768:	e8 93 a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b76d:	48 89 c7             	mov    %rax,%rdi
    b770:	e8 eb b0 ff ff       	call   6860 <fwp_rc_fresh>
    b775:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    b77c:	00 
    b77d:	bf 01 00 00 00       	mov    $0x1,%edi
    b782:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    b789:	00 
    b78a:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    b791:	00 
    b792:	e8 69 a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b797:	48 89 c7             	mov    %rax,%rdi
    b79a:	e8 c1 b0 ff ff       	call   6860 <fwp_rc_fresh>
    b79f:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    b7a6:	00 
    b7a7:	bf 01 00 00 00       	mov    $0x1,%edi
    b7ac:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    b7b3:	00 
    b7b4:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    b7bb:	00 
    b7bc:	e8 3f a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b7c1:	48 89 c7             	mov    %rax,%rdi
    b7c4:	e8 97 b0 ff ff       	call   6860 <fwp_rc_fresh>
    b7c9:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    b7d0:	00 
    b7d1:	bf 01 00 00 00       	mov    $0x1,%edi
    b7d6:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    b7dd:	00 
    b7de:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    b7e5:	00 
    b7e6:	e8 15 a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b7eb:	48 89 c7             	mov    %rax,%rdi
    b7ee:	e8 6d b0 ff ff       	call   6860 <fwp_rc_fresh>
    b7f3:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    b7fa:	00 
    b7fb:	bf 01 00 00 00       	mov    $0x1,%edi
    b800:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    b807:	00 
    b808:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    b80f:	00 
    b810:	e8 eb a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b815:	48 89 c7             	mov    %rax,%rdi
    b818:	e8 43 b0 ff ff       	call   6860 <fwp_rc_fresh>
    b81d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    b824:	00 
    b825:	bf 01 00 00 00       	mov    $0x1,%edi
    b82a:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    b831:	00 
    b832:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    b839:	00 
    b83a:	e8 c1 a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b83f:	48 89 c7             	mov    %rax,%rdi
    b842:	e8 19 b0 ff ff       	call   6860 <fwp_rc_fresh>
    b847:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    b84e:	00 
    b84f:	bf 01 00 00 00       	mov    $0x1,%edi
    b854:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    b85b:	00 
    b85c:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    b863:	00 
    b864:	e8 97 a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b869:	48 89 c7             	mov    %rax,%rdi
    b86c:	e8 ef af ff ff       	call   6860 <fwp_rc_fresh>
    b871:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    b878:	00 
    b879:	bf 01 00 00 00       	mov    $0x1,%edi
    b87e:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    b885:	00 
    b886:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    b88d:	00 
    b88e:	e8 6d a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b893:	48 89 c7             	mov    %rax,%rdi
    b896:	e8 c5 af ff ff       	call   6860 <fwp_rc_fresh>
    b89b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    b8a2:	00 
    b8a3:	bf 01 00 00 00       	mov    $0x1,%edi
    b8a8:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    b8af:	00 
    b8b0:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    b8b7:	00 
    b8b8:	e8 43 a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b8bd:	48 89 c7             	mov    %rax,%rdi
    b8c0:	e8 9b af ff ff       	call   6860 <fwp_rc_fresh>
    b8c5:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    b8cc:	00 
    b8cd:	bf 01 00 00 00       	mov    $0x1,%edi
    b8d2:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    b8d9:	00 
    b8da:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    b8e1:	00 
    b8e2:	e8 19 a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b8e7:	48 89 c7             	mov    %rax,%rdi
    b8ea:	e8 71 af ff ff       	call   6860 <fwp_rc_fresh>
    b8ef:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    b8f6:	00 
    b8f7:	bf 01 00 00 00       	mov    $0x1,%edi
    b8fc:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    b903:	00 
    b904:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    b90b:	00 
    b90c:	e8 ef a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b911:	48 89 c7             	mov    %rax,%rdi
    b914:	e8 47 af ff ff       	call   6860 <fwp_rc_fresh>
    b919:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    b920:	00 
    b921:	bf 01 00 00 00       	mov    $0x1,%edi
    b926:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    b92d:	00 
    b92e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    b935:	00 
    b936:	e8 c5 a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b93b:	48 89 c7             	mov    %rax,%rdi
    b93e:	e8 1d af ff ff       	call   6860 <fwp_rc_fresh>
    b943:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    b94a:	00 
    b94b:	bf 01 00 00 00       	mov    $0x1,%edi
    b950:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    b957:	00 
    b958:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    b95f:	00 
    b960:	e8 9b a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b965:	48 89 c7             	mov    %rax,%rdi
    b968:	e8 f3 ae ff ff       	call   6860 <fwp_rc_fresh>
    b96d:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    b974:	00 
    b975:	bf 01 00 00 00       	mov    $0x1,%edi
    b97a:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    b981:	00 
    b982:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    b989:	00 
    b98a:	e8 71 a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b98f:	48 89 c7             	mov    %rax,%rdi
    b992:	e8 c9 ae ff ff       	call   6860 <fwp_rc_fresh>
    b997:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    b99e:	00 
    b99f:	bf 01 00 00 00       	mov    $0x1,%edi
    b9a4:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    b9ab:	00 
    b9ac:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    b9b3:	00 
    b9b4:	e8 47 a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b9b9:	48 89 c7             	mov    %rax,%rdi
    b9bc:	e8 9f ae ff ff       	call   6860 <fwp_rc_fresh>
    b9c1:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    b9c8:	00 
    b9c9:	bf 01 00 00 00       	mov    $0x1,%edi
    b9ce:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    b9d5:	00 
    b9d6:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    b9dd:	00 
    b9de:	e8 1d a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b9e3:	48 89 c7             	mov    %rax,%rdi
    b9e6:	e8 75 ae ff ff       	call   6860 <fwp_rc_fresh>
    b9eb:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    b9f2:	00 
    b9f3:	bf 01 00 00 00       	mov    $0x1,%edi
    b9f8:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    b9ff:	00 
    ba00:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    ba07:	00 
    ba08:	e8 f3 a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ba0d:	48 89 c7             	mov    %rax,%rdi
    ba10:	e8 4b ae ff ff       	call   6860 <fwp_rc_fresh>
    ba15:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    ba1c:	00 
    ba1d:	bf 01 00 00 00       	mov    $0x1,%edi
    ba22:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    ba29:	00 
    ba2a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    ba31:	00 
    ba32:	e8 c9 a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ba37:	48 89 c7             	mov    %rax,%rdi
    ba3a:	e8 21 ae ff ff       	call   6860 <fwp_rc_fresh>
    ba3f:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    ba46:	00 
    ba47:	bf 01 00 00 00       	mov    $0x1,%edi
    ba4c:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    ba53:	00 
    ba54:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    ba5b:	00 
    ba5c:	e8 9f a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ba61:	48 89 c7             	mov    %rax,%rdi
    ba64:	e8 f7 ad ff ff       	call   6860 <fwp_rc_fresh>
    ba69:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    ba70:	00 
    ba71:	bf 01 00 00 00       	mov    $0x1,%edi
    ba76:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    ba7d:	00 
    ba7e:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    ba85:	00 
    ba86:	e8 75 a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ba8b:	48 89 c7             	mov    %rax,%rdi
    ba8e:	e8 cd ad ff ff       	call   6860 <fwp_rc_fresh>
    ba93:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    ba9a:	00 
    ba9b:	bf 01 00 00 00       	mov    $0x1,%edi
    baa0:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    baa7:	00 
    baa8:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    baaf:	00 
    bab0:	e8 4b a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bab5:	48 89 c7             	mov    %rax,%rdi
    bab8:	e8 a3 ad ff ff       	call   6860 <fwp_rc_fresh>
    babd:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    bac4:	00 
    bac5:	bf 01 00 00 00       	mov    $0x1,%edi
    baca:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    bad1:	00 
    bad2:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    bad9:	00 
    bada:	e8 21 a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    badf:	48 89 c7             	mov    %rax,%rdi
    bae2:	e8 79 ad ff ff       	call   6860 <fwp_rc_fresh>
    bae7:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    baee:	00 
    baef:	bf 01 00 00 00       	mov    $0x1,%edi
    baf4:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    bafb:	00 
    bafc:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    bb03:	00 
    bb04:	e8 f7 a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bb09:	48 89 c7             	mov    %rax,%rdi
    bb0c:	e8 4f ad ff ff       	call   6860 <fwp_rc_fresh>
    bb11:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    bb18:	00 
    bb19:	bf 01 00 00 00       	mov    $0x1,%edi
    bb1e:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    bb25:	00 
    bb26:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    bb2d:	00 
    bb2e:	e8 cd a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bb33:	48 89 c7             	mov    %rax,%rdi
    bb36:	e8 25 ad ff ff       	call   6860 <fwp_rc_fresh>
    bb3b:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    bb42:	00 
    bb43:	bf 01 00 00 00       	mov    $0x1,%edi
    bb48:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    bb4f:	00 
    bb50:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    bb57:	00 
    bb58:	e8 a3 a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bb5d:	48 89 c7             	mov    %rax,%rdi
    bb60:	e8 fb ac ff ff       	call   6860 <fwp_rc_fresh>
    bb65:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    bb6c:	00 
    bb6d:	bf 01 00 00 00       	mov    $0x1,%edi
    bb72:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    bb79:	00 
    bb7a:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    bb81:	00 
    bb82:	e8 79 a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bb87:	48 89 c7             	mov    %rax,%rdi
    bb8a:	e8 d1 ac ff ff       	call   6860 <fwp_rc_fresh>
    bb8f:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    bb96:	00 
    bb97:	bf 01 00 00 00       	mov    $0x1,%edi
    bb9c:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    bba3:	00 
    bba4:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    bbab:	00 
    bbac:	e8 4f a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bbb1:	48 89 c7             	mov    %rax,%rdi
    bbb4:	e8 a7 ac ff ff       	call   6860 <fwp_rc_fresh>
    bbb9:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    bbc0:	00 
    bbc1:	bf 01 00 00 00       	mov    $0x1,%edi
    bbc6:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    bbcd:	00 
    bbce:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    bbd5:	00 
    bbd6:	e8 25 a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bbdb:	48 89 c7             	mov    %rax,%rdi
    bbde:	e8 7d ac ff ff       	call   6860 <fwp_rc_fresh>
    bbe3:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    bbea:	00 
    bbeb:	bf 01 00 00 00       	mov    $0x1,%edi
    bbf0:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    bbf7:	00 
    bbf8:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    bbff:	00 
    bc00:	e8 fb a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bc05:	48 89 c7             	mov    %rax,%rdi
    bc08:	e8 53 ac ff ff       	call   6860 <fwp_rc_fresh>
    bc0d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    bc14:	00 
    bc15:	bf 01 00 00 00       	mov    $0x1,%edi
    bc1a:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    bc21:	00 
    bc22:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    bc29:	00 
    bc2a:	e8 d1 a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bc2f:	48 89 c7             	mov    %rax,%rdi
    bc32:	e8 29 ac ff ff       	call   6860 <fwp_rc_fresh>
    bc37:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    bc3e:	00 
    bc3f:	bf 01 00 00 00       	mov    $0x1,%edi
    bc44:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    bc4b:	00 
    bc4c:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    bc53:	00 
    bc54:	e8 a7 a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bc59:	48 89 c7             	mov    %rax,%rdi
    bc5c:	e8 ff ab ff ff       	call   6860 <fwp_rc_fresh>
    bc61:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    bc68:	00 
    bc69:	bf 01 00 00 00       	mov    $0x1,%edi
    bc6e:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    bc75:	00 
    bc76:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    bc7d:	00 
    bc7e:	e8 7d a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bc83:	48 89 c7             	mov    %rax,%rdi
    bc86:	e8 d5 ab ff ff       	call   6860 <fwp_rc_fresh>
    bc8b:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    bc92:	00 
    bc93:	bf 01 00 00 00       	mov    $0x1,%edi
    bc98:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    bc9f:	00 
    bca0:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    bca7:	00 
    bca8:	e8 53 a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bcad:	48 89 c7             	mov    %rax,%rdi
    bcb0:	e8 ab ab ff ff       	call   6860 <fwp_rc_fresh>
    bcb5:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    bcbc:	00 
    bcbd:	bf 01 00 00 00       	mov    $0x1,%edi
    bcc2:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    bcc9:	00 
    bcca:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    bcd1:	00 
    bcd2:	e8 29 a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bcd7:	48 89 c7             	mov    %rax,%rdi
    bcda:	e8 81 ab ff ff       	call   6860 <fwp_rc_fresh>
    bcdf:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    bce6:	00 
    bce7:	bf 01 00 00 00       	mov    $0x1,%edi
    bcec:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    bcf3:	00 
    bcf4:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    bcfb:	00 
    bcfc:	e8 ff a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bd01:	48 89 c7             	mov    %rax,%rdi
    bd04:	e8 57 ab ff ff       	call   6860 <fwp_rc_fresh>
    bd09:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    bd10:	00 
    bd11:	bf 01 00 00 00       	mov    $0x1,%edi
    bd16:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    bd1d:	00 
    bd1e:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    bd25:	00 
    bd26:	e8 d5 a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bd2b:	48 89 c7             	mov    %rax,%rdi
    bd2e:	e8 2d ab ff ff       	call   6860 <fwp_rc_fresh>
    bd33:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    bd3a:	00 
    bd3b:	bf 01 00 00 00       	mov    $0x1,%edi
    bd40:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    bd47:	00 
    bd48:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    bd4f:	00 
    bd50:	e8 ab a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bd55:	48 89 c7             	mov    %rax,%rdi
    bd58:	e8 03 ab ff ff       	call   6860 <fwp_rc_fresh>
    bd5d:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    bd64:	00 
    bd65:	bf 01 00 00 00       	mov    $0x1,%edi
    bd6a:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    bd71:	00 
    bd72:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    bd79:	00 
    bd7a:	e8 81 a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bd7f:	48 89 c7             	mov    %rax,%rdi
    bd82:	e8 d9 aa ff ff       	call   6860 <fwp_rc_fresh>
    bd87:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    bd8e:	00 
    bd8f:	bf 01 00 00 00       	mov    $0x1,%edi
    bd94:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    bd9b:	00 
    bd9c:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    bda3:	00 
    bda4:	e8 57 a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bda9:	48 89 c7             	mov    %rax,%rdi
    bdac:	e8 af aa ff ff       	call   6860 <fwp_rc_fresh>
    bdb1:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    bdb8:	00 
    bdb9:	bf 01 00 00 00       	mov    $0x1,%edi
    bdbe:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    bdc5:	00 
    bdc6:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    bdcd:	00 
    bdce:	e8 2d a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bdd3:	48 89 c7             	mov    %rax,%rdi
    bdd6:	e8 85 aa ff ff       	call   6860 <fwp_rc_fresh>
    bddb:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    bde2:	00 
    bde3:	bf 01 00 00 00       	mov    $0x1,%edi
    bde8:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    bdef:	00 
    bdf0:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    bdf7:	00 
    bdf8:	e8 03 a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bdfd:	48 89 c7             	mov    %rax,%rdi
    be00:	e8 5b aa ff ff       	call   6860 <fwp_rc_fresh>
    be05:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    be0c:	00 
    be0d:	bf 01 00 00 00       	mov    $0x1,%edi
    be12:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    be19:	00 
    be1a:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    be21:	00 
    be22:	e8 d9 a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    be27:	48 89 c7             	mov    %rax,%rdi
    be2a:	e8 31 aa ff ff       	call   6860 <fwp_rc_fresh>
    be2f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    be36:	00 
    be37:	bf 01 00 00 00       	mov    $0x1,%edi
    be3c:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    be43:	00 
    be44:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    be4b:	00 
    be4c:	e8 af a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    be51:	48 89 c7             	mov    %rax,%rdi
    be54:	e8 07 aa ff ff       	call   6860 <fwp_rc_fresh>
    be59:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    be60:	00 
    be61:	bf 01 00 00 00       	mov    $0x1,%edi
    be66:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    be6d:	00 
    be6e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    be75:	00 
    be76:	e8 85 a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    be7b:	48 89 c7             	mov    %rax,%rdi
    be7e:	e8 dd a9 ff ff       	call   6860 <fwp_rc_fresh>
    be83:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    be8a:	00 
    be8b:	bf 01 00 00 00       	mov    $0x1,%edi
    be90:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    be97:	00 
    be98:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    be9f:	00 
    bea0:	e8 5b a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bea5:	48 89 c7             	mov    %rax,%rdi
    bea8:	e8 b3 a9 ff ff       	call   6860 <fwp_rc_fresh>
    bead:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    beb4:	00 
    beb5:	bf 01 00 00 00       	mov    $0x1,%edi
    beba:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    bec1:	00 
    bec2:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    bec9:	00 
    beca:	e8 31 a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    becf:	48 89 c7             	mov    %rax,%rdi
    bed2:	e8 89 a9 ff ff       	call   6860 <fwp_rc_fresh>
    bed7:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    bede:	00 
    bedf:	bf 01 00 00 00       	mov    $0x1,%edi
    bee4:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    beeb:	00 
    beec:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    bef3:	00 
    bef4:	e8 07 a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bef9:	48 89 c7             	mov    %rax,%rdi
    befc:	e8 5f a9 ff ff       	call   6860 <fwp_rc_fresh>
    bf01:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    bf08:	00 
    bf09:	bf 01 00 00 00       	mov    $0x1,%edi
    bf0e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    bf15:	00 
    bf16:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    bf1d:	00 
    bf1e:	e8 dd a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bf23:	48 89 c7             	mov    %rax,%rdi
    bf26:	e8 35 a9 ff ff       	call   6860 <fwp_rc_fresh>
    bf2b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    bf32:	00 
    bf33:	bf 01 00 00 00       	mov    $0x1,%edi
    bf38:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    bf3f:	00 
    bf40:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    bf47:	00 
    bf48:	e8 b3 a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bf4d:	48 89 c7             	mov    %rax,%rdi
    bf50:	e8 0b a9 ff ff       	call   6860 <fwp_rc_fresh>
    bf55:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    bf5c:	00 
    bf5d:	bf 01 00 00 00       	mov    $0x1,%edi
    bf62:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    bf69:	00 
    bf6a:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    bf71:	00 
    bf72:	e8 89 a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bf77:	48 89 c7             	mov    %rax,%rdi
    bf7a:	e8 e1 a8 ff ff       	call   6860 <fwp_rc_fresh>
    bf7f:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    bf86:	00 
    bf87:	bf 01 00 00 00       	mov    $0x1,%edi
    bf8c:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    bf93:	00 
    bf94:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    bf9b:	00 
    bf9c:	e8 5f a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bfa1:	48 89 c7             	mov    %rax,%rdi
    bfa4:	e8 b7 a8 ff ff       	call   6860 <fwp_rc_fresh>
    bfa9:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    bfb0:	00 
    bfb1:	bf 01 00 00 00       	mov    $0x1,%edi
    bfb6:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    bfbd:	00 
    bfbe:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    bfc5:	00 
    bfc6:	e8 35 a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bfcb:	48 89 c7             	mov    %rax,%rdi
    bfce:	e8 8d a8 ff ff       	call   6860 <fwp_rc_fresh>
    bfd3:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    bfda:	00 
    bfdb:	bf 01 00 00 00       	mov    $0x1,%edi
    bfe0:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    bfe7:	00 
    bfe8:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    bfef:	00 
    bff0:	e8 0b a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bff5:	48 89 c7             	mov    %rax,%rdi
    bff8:	e8 63 a8 ff ff       	call   6860 <fwp_rc_fresh>
    bffd:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    c004:	00 
    c005:	bf 01 00 00 00       	mov    $0x1,%edi
    c00a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    c011:	00 
    c012:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    c019:	00 
    c01a:	e8 e1 a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c01f:	48 89 c7             	mov    %rax,%rdi
    c022:	e8 39 a8 ff ff       	call   6860 <fwp_rc_fresh>
    c027:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    c02e:	00 
    c02f:	bf 01 00 00 00       	mov    $0x1,%edi
    c034:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    c03b:	00 
    c03c:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    c043:	00 
    c044:	e8 b7 a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c049:	48 89 c7             	mov    %rax,%rdi
    c04c:	e8 0f a8 ff ff       	call   6860 <fwp_rc_fresh>
    c051:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    c058:	00 
    c059:	bf 01 00 00 00       	mov    $0x1,%edi
    c05e:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    c065:	00 
    c066:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    c06d:	00 
    c06e:	e8 8d a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c073:	48 89 c7             	mov    %rax,%rdi
    c076:	e8 e5 a7 ff ff       	call   6860 <fwp_rc_fresh>
    c07b:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    c082:	00 
    c083:	bf 01 00 00 00       	mov    $0x1,%edi
    c088:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    c08f:	00 
    c090:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    c097:	00 
    c098:	e8 63 a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c09d:	48 89 c7             	mov    %rax,%rdi
    c0a0:	e8 bb a7 ff ff       	call   6860 <fwp_rc_fresh>
    c0a5:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    c0ac:	00 
    c0ad:	bf 01 00 00 00       	mov    $0x1,%edi
    c0b2:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    c0b9:	00 
    c0ba:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    c0c1:	00 
    c0c2:	e8 39 a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c0c7:	48 89 c7             	mov    %rax,%rdi
    c0ca:	e8 91 a7 ff ff       	call   6860 <fwp_rc_fresh>
    c0cf:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    c0d6:	00 
    c0d7:	bf 01 00 00 00       	mov    $0x1,%edi
    c0dc:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    c0e3:	00 
    c0e4:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    c0eb:	00 
    c0ec:	e8 0f a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c0f1:	48 89 c7             	mov    %rax,%rdi
    c0f4:	e8 67 a7 ff ff       	call   6860 <fwp_rc_fresh>
    c0f9:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    c100:	00 
    c101:	bf 01 00 00 00       	mov    $0x1,%edi
    c106:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    c10d:	00 
    c10e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    c115:	00 
    c116:	e8 e5 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c11b:	48 89 c7             	mov    %rax,%rdi
    c11e:	e8 3d a7 ff ff       	call   6860 <fwp_rc_fresh>
    c123:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    c12a:	00 
    c12b:	bf 01 00 00 00       	mov    $0x1,%edi
    c130:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    c137:	00 
    c138:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    c13f:	00 
    c140:	e8 bb 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c145:	48 89 c7             	mov    %rax,%rdi
    c148:	e8 13 a7 ff ff       	call   6860 <fwp_rc_fresh>
    c14d:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    c154:	00 
    c155:	bf 01 00 00 00       	mov    $0x1,%edi
    c15a:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    c161:	00 
    c162:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    c169:	00 
    c16a:	e8 91 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c16f:	48 89 c7             	mov    %rax,%rdi
    c172:	e8 e9 a6 ff ff       	call   6860 <fwp_rc_fresh>
    c177:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    c17e:	00 
    c17f:	bf 01 00 00 00       	mov    $0x1,%edi
    c184:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    c18b:	00 
    c18c:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    c193:	00 
    c194:	e8 67 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c199:	48 89 c7             	mov    %rax,%rdi
    c19c:	e8 bf a6 ff ff       	call   6860 <fwp_rc_fresh>
    c1a1:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    c1a8:	00 
    c1a9:	bf 01 00 00 00       	mov    $0x1,%edi
    c1ae:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    c1b5:	00 
    c1b6:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    c1bd:	00 
    c1be:	e8 3d 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c1c3:	48 89 c7             	mov    %rax,%rdi
    c1c6:	e8 95 a6 ff ff       	call   6860 <fwp_rc_fresh>
    c1cb:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    c1d2:	00 
    c1d3:	bf 01 00 00 00       	mov    $0x1,%edi
    c1d8:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    c1df:	00 
    c1e0:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    c1e7:	00 
    c1e8:	e8 13 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c1ed:	48 89 c7             	mov    %rax,%rdi
    c1f0:	e8 6b a6 ff ff       	call   6860 <fwp_rc_fresh>
    c1f5:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    c1fc:	00 
    c1fd:	bf 01 00 00 00       	mov    $0x1,%edi
    c202:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    c209:	00 
    c20a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    c211:	00 
    c212:	e8 e9 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c217:	48 89 c7             	mov    %rax,%rdi
    c21a:	e8 41 a6 ff ff       	call   6860 <fwp_rc_fresh>
    c21f:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    c226:	00 
    c227:	bf 01 00 00 00       	mov    $0x1,%edi
    c22c:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    c233:	00 
    c234:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    c23b:	00 
    c23c:	e8 bf 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c241:	48 89 c7             	mov    %rax,%rdi
    c244:	e8 17 a6 ff ff       	call   6860 <fwp_rc_fresh>
    c249:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    c250:	00 
    c251:	bf 01 00 00 00       	mov    $0x1,%edi
    c256:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    c25d:	00 
    c25e:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    c265:	00 
    c266:	e8 95 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c26b:	48 89 c7             	mov    %rax,%rdi
    c26e:	e8 ed a5 ff ff       	call   6860 <fwp_rc_fresh>
    c273:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    c27a:	00 
    c27b:	bf 01 00 00 00       	mov    $0x1,%edi
    c280:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    c287:	00 
    c288:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    c28f:	00 
    c290:	e8 6b 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c295:	48 89 c7             	mov    %rax,%rdi
    c298:	e8 c3 a5 ff ff       	call   6860 <fwp_rc_fresh>
    c29d:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    c2a4:	00 
    c2a5:	bf 01 00 00 00       	mov    $0x1,%edi
    c2aa:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    c2b1:	00 
    c2b2:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    c2b9:	00 
    c2ba:	e8 41 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c2bf:	48 89 c7             	mov    %rax,%rdi
    c2c2:	e8 99 a5 ff ff       	call   6860 <fwp_rc_fresh>
    c2c7:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    c2ce:	00 
    c2cf:	bf 01 00 00 00       	mov    $0x1,%edi
    c2d4:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    c2db:	00 
    c2dc:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    c2e3:	00 
    c2e4:	e8 17 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c2e9:	48 89 c7             	mov    %rax,%rdi
    c2ec:	e8 6f a5 ff ff       	call   6860 <fwp_rc_fresh>
    c2f1:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    c2f8:	00 
    c2f9:	bf 01 00 00 00       	mov    $0x1,%edi
    c2fe:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    c305:	00 
    c306:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    c30d:	00 
    c30e:	e8 ed 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c313:	48 89 c7             	mov    %rax,%rdi
    c316:	e8 45 a5 ff ff       	call   6860 <fwp_rc_fresh>
    c31b:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    c322:	00 
    c323:	bf 01 00 00 00       	mov    $0x1,%edi
    c328:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    c32f:	00 
    c330:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    c337:	00 
    c338:	e8 c3 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c33d:	48 89 c7             	mov    %rax,%rdi
    c340:	e8 1b a5 ff ff       	call   6860 <fwp_rc_fresh>
    c345:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    c34c:	00 
    c34d:	bf 01 00 00 00       	mov    $0x1,%edi
    c352:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    c359:	00 
    c35a:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    c361:	00 
    c362:	e8 99 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c367:	48 89 c7             	mov    %rax,%rdi
    c36a:	e8 f1 a4 ff ff       	call   6860 <fwp_rc_fresh>
    c36f:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    c376:	00 
    c377:	bf 01 00 00 00       	mov    $0x1,%edi
    c37c:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    c383:	00 
    c384:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    c38b:	00 
    c38c:	e8 6f 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c391:	48 89 c7             	mov    %rax,%rdi
    c394:	e8 c7 a4 ff ff       	call   6860 <fwp_rc_fresh>
    c399:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c3a0:	00 
    c3a1:	bf 01 00 00 00       	mov    $0x1,%edi
    c3a6:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c3ad:	00 
    c3ae:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c3b5:	00 
    c3b6:	e8 45 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c3bb:	48 89 c7             	mov    %rax,%rdi
    c3be:	e8 9d a4 ff ff       	call   6860 <fwp_rc_fresh>
    c3c3:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    c3ca:	00 
    c3cb:	bf 01 00 00 00       	mov    $0x1,%edi
    c3d0:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    c3d7:	00 
    c3d8:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    c3df:	00 
    c3e0:	e8 1b 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c3e5:	48 8b 15 0c 08 06 00 	mov    0x6080c(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c3ec:	49 89 c5             	mov    %rax,%r13
    c3ef:	48 2b 05 da 07 06 00 	sub    0x607da(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c3f6:	48 c1 e2 10          	shl    $0x10,%rdx
    c3fa:	48 39 d0             	cmp    %rdx,%rax
    c3fd:	73 59                	jae    c458 <f0+0x13b8>
    c3ff:	48 89 c2             	mov    %rax,%rdx
    c402:	48 c1 ea 10          	shr    $0x10,%rdx
    c406:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c40a:	48 8b 15 07 08 06 00 	mov    0x60807(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c411:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c415:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c419:	4d 85 e4             	test   %r12,%r12
    c41c:	74 3a                	je     c458 <f0+0x13b8>
    c41e:	0f b6 0a             	movzbl (%rdx),%ecx
    c421:	80 f9 02             	cmp    $0x2,%cl
    c424:	0f 84 c6 15 00 00    	je     d9f0 <f0+0x2950>
    c42a:	80 f9 01             	cmp    $0x1,%cl
    c42d:	75 29                	jne    c458 <f0+0x13b8>
    c42f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c432:	0f b7 c0             	movzwl %ax,%eax
    c435:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c438:	48 0f af c1          	imul   %rcx,%rax
    c43c:	48 c1 e8 20          	shr    $0x20,%rax
    c440:	48 39 d0             	cmp    %rdx,%rax
    c443:	73 13                	jae    c458 <f0+0x13b8>
    c445:	49 01 c4             	add    %rax,%r12
    c448:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c44d:	0f 84 99 17 00 00    	je     dbec <f0+0x2b4c>
    c453:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c458:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c45f:	33 f3 bf 
    c462:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    c469:	00 
    c46a:	bf 01 00 00 00       	mov    $0x1,%edi
    c46f:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    c476:	00 
    c477:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    c47e:	00 
    c47f:	e8 7c 9c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c484:	48 8b 15 6d 07 06 00 	mov    0x6076d(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c48b:	49 89 c5             	mov    %rax,%r13
    c48e:	48 2b 05 3b 07 06 00 	sub    0x6073b(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c495:	48 c1 e2 10          	shl    $0x10,%rdx
    c499:	48 39 d0             	cmp    %rdx,%rax
    c49c:	73 59                	jae    c4f7 <f0+0x1457>
    c49e:	48 89 c2             	mov    %rax,%rdx
    c4a1:	48 c1 ea 10          	shr    $0x10,%rdx
    c4a5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c4a9:	48 8b 15 68 07 06 00 	mov    0x60768(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c4b0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c4b4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c4b8:	4d 85 e4             	test   %r12,%r12
    c4bb:	74 3a                	je     c4f7 <f0+0x1457>
    c4bd:	0f b6 0a             	movzbl (%rdx),%ecx
    c4c0:	80 f9 02             	cmp    $0x2,%cl
    c4c3:	0f 84 17 15 00 00    	je     d9e0 <f0+0x2940>
    c4c9:	80 f9 01             	cmp    $0x1,%cl
    c4cc:	75 29                	jne    c4f7 <f0+0x1457>
    c4ce:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c4d1:	0f b7 c0             	movzwl %ax,%eax
    c4d4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c4d7:	48 0f af c1          	imul   %rcx,%rax
    c4db:	48 c1 e8 20          	shr    $0x20,%rax
    c4df:	48 39 d0             	cmp    %rdx,%rax
    c4e2:	73 13                	jae    c4f7 <f0+0x1457>
    c4e4:	49 01 c4             	add    %rax,%r12
    c4e7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c4ec:	0f 84 07 17 00 00    	je     dbf9 <f0+0x2b59>
    c4f2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c4f7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c4fe:	00 f0 3f 
    c501:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    c508:	00 
    c509:	bf 01 00 00 00       	mov    $0x1,%edi
    c50e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    c515:	00 
    c516:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    c51d:	00 
    c51e:	e8 dd 9b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c523:	48 8b 15 ce 06 06 00 	mov    0x606ce(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c52a:	49 89 c5             	mov    %rax,%r13
    c52d:	48 2b 05 9c 06 06 00 	sub    0x6069c(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c534:	48 c1 e2 10          	shl    $0x10,%rdx
    c538:	48 39 d0             	cmp    %rdx,%rax
    c53b:	73 59                	jae    c596 <f0+0x14f6>
    c53d:	48 89 c2             	mov    %rax,%rdx
    c540:	48 c1 ea 10          	shr    $0x10,%rdx
    c544:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c548:	48 8b 15 c9 06 06 00 	mov    0x606c9(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c54f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c553:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c557:	4d 85 e4             	test   %r12,%r12
    c55a:	74 3a                	je     c596 <f0+0x14f6>
    c55c:	0f b6 0a             	movzbl (%rdx),%ecx
    c55f:	80 f9 02             	cmp    $0x2,%cl
    c562:	0f 84 28 15 00 00    	je     da90 <f0+0x29f0>
    c568:	80 f9 01             	cmp    $0x1,%cl
    c56b:	75 29                	jne    c596 <f0+0x14f6>
    c56d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c570:	0f b7 c0             	movzwl %ax,%eax
    c573:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c576:	48 0f af c1          	imul   %rcx,%rax
    c57a:	48 c1 e8 20          	shr    $0x20,%rax
    c57e:	48 39 d0             	cmp    %rdx,%rax
    c581:	73 13                	jae    c596 <f0+0x14f6>
    c583:	49 01 c4             	add    %rax,%r12
    c586:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c58b:	0f 84 75 16 00 00    	je     dc06 <f0+0x2b66>
    c591:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c596:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c59d:	33 f3 bf 
    c5a0:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    c5a7:	00 
    c5a8:	bf 01 00 00 00       	mov    $0x1,%edi
    c5ad:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    c5b4:	00 
    c5b5:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    c5bc:	00 
    c5bd:	e8 3e 9b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c5c2:	48 8b 15 2f 06 06 00 	mov    0x6062f(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c5c9:	49 89 c5             	mov    %rax,%r13
    c5cc:	48 2b 05 fd 05 06 00 	sub    0x605fd(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c5d3:	48 c1 e2 10          	shl    $0x10,%rdx
    c5d7:	48 39 d0             	cmp    %rdx,%rax
    c5da:	73 59                	jae    c635 <f0+0x1595>
    c5dc:	48 89 c2             	mov    %rax,%rdx
    c5df:	48 c1 ea 10          	shr    $0x10,%rdx
    c5e3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c5e7:	48 8b 15 2a 06 06 00 	mov    0x6062a(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c5ee:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c5f2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c5f6:	4d 85 e4             	test   %r12,%r12
    c5f9:	74 3a                	je     c635 <f0+0x1595>
    c5fb:	0f b6 0a             	movzbl (%rdx),%ecx
    c5fe:	80 f9 02             	cmp    $0x2,%cl
    c601:	0f 84 79 14 00 00    	je     da80 <f0+0x29e0>
    c607:	80 f9 01             	cmp    $0x1,%cl
    c60a:	75 29                	jne    c635 <f0+0x1595>
    c60c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c60f:	0f b7 c0             	movzwl %ax,%eax
    c612:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c615:	48 0f af c1          	imul   %rcx,%rax
    c619:	48 c1 e8 20          	shr    $0x20,%rax
    c61d:	48 39 d0             	cmp    %rdx,%rax
    c620:	73 13                	jae    c635 <f0+0x1595>
    c622:	49 01 c4             	add    %rax,%r12
    c625:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c62a:	0f 84 e3 15 00 00    	je     dc13 <f0+0x2b73>
    c630:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c635:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c63c:	00 f0 3f 
    c63f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    c646:	00 
    c647:	bf 01 00 00 00       	mov    $0x1,%edi
    c64c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    c653:	00 
    c654:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    c65b:	00 
    c65c:	e8 9f 9a ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c661:	48 8b 15 90 05 06 00 	mov    0x60590(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c668:	49 89 c5             	mov    %rax,%r13
    c66b:	48 2b 05 5e 05 06 00 	sub    0x6055e(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c672:	48 c1 e2 10          	shl    $0x10,%rdx
    c676:	48 39 d0             	cmp    %rdx,%rax
    c679:	73 59                	jae    c6d4 <f0+0x1634>
    c67b:	48 89 c2             	mov    %rax,%rdx
    c67e:	48 c1 ea 10          	shr    $0x10,%rdx
    c682:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c686:	48 8b 15 8b 05 06 00 	mov    0x6058b(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c68d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c691:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c695:	4d 85 e4             	test   %r12,%r12
    c698:	74 3a                	je     c6d4 <f0+0x1634>
    c69a:	0f b6 0a             	movzbl (%rdx),%ecx
    c69d:	80 f9 02             	cmp    $0x2,%cl
    c6a0:	0f 84 ca 13 00 00    	je     da70 <f0+0x29d0>
    c6a6:	80 f9 01             	cmp    $0x1,%cl
    c6a9:	75 29                	jne    c6d4 <f0+0x1634>
    c6ab:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c6ae:	0f b7 c0             	movzwl %ax,%eax
    c6b1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c6b4:	48 0f af c1          	imul   %rcx,%rax
    c6b8:	48 c1 e8 20          	shr    $0x20,%rax
    c6bc:	48 39 d0             	cmp    %rdx,%rax
    c6bf:	73 13                	jae    c6d4 <f0+0x1634>
    c6c1:	49 01 c4             	add    %rax,%r12
    c6c4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c6c9:	0f 84 51 15 00 00    	je     dc20 <f0+0x2b80>
    c6cf:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c6d4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c6db:	33 f3 bf 
    c6de:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    c6e5:	00 
    c6e6:	bf 01 00 00 00       	mov    $0x1,%edi
    c6eb:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    c6f2:	00 
    c6f3:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    c6fa:	00 
    c6fb:	e8 00 9a ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c700:	48 8b 15 f1 04 06 00 	mov    0x604f1(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c707:	49 89 c5             	mov    %rax,%r13
    c70a:	48 2b 05 bf 04 06 00 	sub    0x604bf(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c711:	48 c1 e2 10          	shl    $0x10,%rdx
    c715:	48 39 d0             	cmp    %rdx,%rax
    c718:	73 59                	jae    c773 <f0+0x16d3>
    c71a:	48 89 c2             	mov    %rax,%rdx
    c71d:	48 c1 ea 10          	shr    $0x10,%rdx
    c721:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c725:	48 8b 15 ec 04 06 00 	mov    0x604ec(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c72c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c730:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c734:	4d 85 e4             	test   %r12,%r12
    c737:	74 3a                	je     c773 <f0+0x16d3>
    c739:	0f b6 0a             	movzbl (%rdx),%ecx
    c73c:	80 f9 02             	cmp    $0x2,%cl
    c73f:	0f 84 1b 13 00 00    	je     da60 <f0+0x29c0>
    c745:	80 f9 01             	cmp    $0x1,%cl
    c748:	75 29                	jne    c773 <f0+0x16d3>
    c74a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c74d:	0f b7 c0             	movzwl %ax,%eax
    c750:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c753:	48 0f af c1          	imul   %rcx,%rax
    c757:	48 c1 e8 20          	shr    $0x20,%rax
    c75b:	48 39 d0             	cmp    %rdx,%rax
    c75e:	73 13                	jae    c773 <f0+0x16d3>
    c760:	49 01 c4             	add    %rax,%r12
    c763:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c768:	0f 84 bf 14 00 00    	je     dc2d <f0+0x2b8d>
    c76e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c773:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c77a:	00 f0 3f 
    c77d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    c784:	00 
    c785:	bf 01 00 00 00       	mov    $0x1,%edi
    c78a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    c791:	00 
    c792:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    c799:	00 
    c79a:	e8 61 99 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c79f:	48 8b 15 52 04 06 00 	mov    0x60452(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c7a6:	49 89 c5             	mov    %rax,%r13
    c7a9:	48 2b 05 20 04 06 00 	sub    0x60420(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c7b0:	48 c1 e2 10          	shl    $0x10,%rdx
    c7b4:	48 39 d0             	cmp    %rdx,%rax
    c7b7:	73 59                	jae    c812 <f0+0x1772>
    c7b9:	48 89 c2             	mov    %rax,%rdx
    c7bc:	48 c1 ea 10          	shr    $0x10,%rdx
    c7c0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c7c4:	48 8b 15 4d 04 06 00 	mov    0x6044d(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c7cb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c7cf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c7d3:	4d 85 e4             	test   %r12,%r12
    c7d6:	74 3a                	je     c812 <f0+0x1772>
    c7d8:	0f b6 0a             	movzbl (%rdx),%ecx
    c7db:	80 f9 02             	cmp    $0x2,%cl
    c7de:	0f 84 6c 12 00 00    	je     da50 <f0+0x29b0>
    c7e4:	80 f9 01             	cmp    $0x1,%cl
    c7e7:	75 29                	jne    c812 <f0+0x1772>
    c7e9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c7ec:	0f b7 c0             	movzwl %ax,%eax
    c7ef:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c7f2:	48 0f af c1          	imul   %rcx,%rax
    c7f6:	48 c1 e8 20          	shr    $0x20,%rax
    c7fa:	48 39 d0             	cmp    %rdx,%rax
    c7fd:	73 13                	jae    c812 <f0+0x1772>
    c7ff:	49 01 c4             	add    %rax,%r12
    c802:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c807:	0f 84 2d 14 00 00    	je     dc3a <f0+0x2b9a>
    c80d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c812:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c819:	33 f3 bf 
    c81c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    c823:	00 
    c824:	bf 01 00 00 00       	mov    $0x1,%edi
    c829:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    c830:	00 
    c831:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    c838:	00 
    c839:	e8 c2 98 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c83e:	48 8b 15 b3 03 06 00 	mov    0x603b3(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c845:	49 89 c5             	mov    %rax,%r13
    c848:	48 2b 05 81 03 06 00 	sub    0x60381(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c84f:	48 c1 e2 10          	shl    $0x10,%rdx
    c853:	48 39 d0             	cmp    %rdx,%rax
    c856:	73 59                	jae    c8b1 <f0+0x1811>
    c858:	48 89 c2             	mov    %rax,%rdx
    c85b:	48 c1 ea 10          	shr    $0x10,%rdx
    c85f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c863:	48 8b 15 ae 03 06 00 	mov    0x603ae(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c86a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c86e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c872:	4d 85 e4             	test   %r12,%r12
    c875:	74 3a                	je     c8b1 <f0+0x1811>
    c877:	0f b6 0a             	movzbl (%rdx),%ecx
    c87a:	80 f9 02             	cmp    $0x2,%cl
    c87d:	0f 84 bd 11 00 00    	je     da40 <f0+0x29a0>
    c883:	80 f9 01             	cmp    $0x1,%cl
    c886:	75 29                	jne    c8b1 <f0+0x1811>
    c888:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c88b:	0f b7 c0             	movzwl %ax,%eax
    c88e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c891:	48 0f af c1          	imul   %rcx,%rax
    c895:	48 c1 e8 20          	shr    $0x20,%rax
    c899:	48 39 d0             	cmp    %rdx,%rax
    c89c:	73 13                	jae    c8b1 <f0+0x1811>
    c89e:	49 01 c4             	add    %rax,%r12
    c8a1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c8a6:	0f 84 9b 13 00 00    	je     dc47 <f0+0x2ba7>
    c8ac:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c8b1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c8b8:	00 f0 3f 
    c8bb:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    c8c2:	00 
    c8c3:	bf 01 00 00 00       	mov    $0x1,%edi
    c8c8:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    c8cf:	00 
    c8d0:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    c8d7:	00 
    c8d8:	e8 23 98 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c8dd:	48 8b 15 14 03 06 00 	mov    0x60314(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c8e4:	49 89 c5             	mov    %rax,%r13
    c8e7:	48 2b 05 e2 02 06 00 	sub    0x602e2(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c8ee:	48 c1 e2 10          	shl    $0x10,%rdx
    c8f2:	48 39 d0             	cmp    %rdx,%rax
    c8f5:	73 59                	jae    c950 <f0+0x18b0>
    c8f7:	48 89 c2             	mov    %rax,%rdx
    c8fa:	48 c1 ea 10          	shr    $0x10,%rdx
    c8fe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c902:	48 8b 15 0f 03 06 00 	mov    0x6030f(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c909:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c90d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c911:	4d 85 e4             	test   %r12,%r12
    c914:	74 3a                	je     c950 <f0+0x18b0>
    c916:	0f b6 0a             	movzbl (%rdx),%ecx
    c919:	80 f9 02             	cmp    $0x2,%cl
    c91c:	0f 84 0e 11 00 00    	je     da30 <f0+0x2990>
    c922:	80 f9 01             	cmp    $0x1,%cl
    c925:	75 29                	jne    c950 <f0+0x18b0>
    c927:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c92a:	0f b7 c0             	movzwl %ax,%eax
    c92d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c930:	48 0f af c1          	imul   %rcx,%rax
    c934:	48 c1 e8 20          	shr    $0x20,%rax
    c938:	48 39 d0             	cmp    %rdx,%rax
    c93b:	73 13                	jae    c950 <f0+0x18b0>
    c93d:	49 01 c4             	add    %rax,%r12
    c940:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c945:	0f 84 09 13 00 00    	je     dc54 <f0+0x2bb4>
    c94b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c950:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c957:	33 f3 bf 
    c95a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    c961:	00 
    c962:	bf 01 00 00 00       	mov    $0x1,%edi
    c967:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    c96e:	00 
    c96f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    c976:	00 
    c977:	e8 84 97 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c97c:	48 8b 15 75 02 06 00 	mov    0x60275(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c983:	49 89 c5             	mov    %rax,%r13
    c986:	48 2b 05 43 02 06 00 	sub    0x60243(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c98d:	48 c1 e2 10          	shl    $0x10,%rdx
    c991:	48 39 d0             	cmp    %rdx,%rax
    c994:	73 59                	jae    c9ef <f0+0x194f>
    c996:	48 89 c2             	mov    %rax,%rdx
    c999:	48 c1 ea 10          	shr    $0x10,%rdx
    c99d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c9a1:	48 8b 15 70 02 06 00 	mov    0x60270(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c9a8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c9ac:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c9b0:	4d 85 e4             	test   %r12,%r12
    c9b3:	74 3a                	je     c9ef <f0+0x194f>
    c9b5:	0f b6 0a             	movzbl (%rdx),%ecx
    c9b8:	80 f9 02             	cmp    $0x2,%cl
    c9bb:	0f 84 5f 10 00 00    	je     da20 <f0+0x2980>
    c9c1:	80 f9 01             	cmp    $0x1,%cl
    c9c4:	75 29                	jne    c9ef <f0+0x194f>
    c9c6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c9c9:	0f b7 c0             	movzwl %ax,%eax
    c9cc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c9cf:	48 0f af c1          	imul   %rcx,%rax
    c9d3:	48 c1 e8 20          	shr    $0x20,%rax
    c9d7:	48 39 d0             	cmp    %rdx,%rax
    c9da:	73 13                	jae    c9ef <f0+0x194f>
    c9dc:	49 01 c4             	add    %rax,%r12
    c9df:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c9e4:	0f 84 77 12 00 00    	je     dc61 <f0+0x2bc1>
    c9ea:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c9ef:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c9f6:	00 f0 3f 
    c9f9:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    ca00:	00 
    ca01:	bf 01 00 00 00       	mov    $0x1,%edi
    ca06:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    ca0d:	00 
    ca0e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    ca15:	00 
    ca16:	e8 e5 96 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ca1b:	48 8b 15 d6 01 06 00 	mov    0x601d6(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    ca22:	49 89 c5             	mov    %rax,%r13
    ca25:	48 2b 05 a4 01 06 00 	sub    0x601a4(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    ca2c:	48 c1 e2 10          	shl    $0x10,%rdx
    ca30:	48 39 d0             	cmp    %rdx,%rax
    ca33:	73 59                	jae    ca8e <f0+0x19ee>
    ca35:	48 89 c2             	mov    %rax,%rdx
    ca38:	48 c1 ea 10          	shr    $0x10,%rdx
    ca3c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca40:	48 8b 15 d1 01 06 00 	mov    0x601d1(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    ca47:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca4b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca4f:	4d 85 e4             	test   %r12,%r12
    ca52:	74 3a                	je     ca8e <f0+0x19ee>
    ca54:	0f b6 0a             	movzbl (%rdx),%ecx
    ca57:	80 f9 02             	cmp    $0x2,%cl
    ca5a:	0f 84 40 0f 00 00    	je     d9a0 <f0+0x2900>
    ca60:	80 f9 01             	cmp    $0x1,%cl
    ca63:	75 29                	jne    ca8e <f0+0x19ee>
    ca65:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca68:	0f b7 c0             	movzwl %ax,%eax
    ca6b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca6e:	48 0f af c1          	imul   %rcx,%rax
    ca72:	48 c1 e8 20          	shr    $0x20,%rax
    ca76:	48 39 d0             	cmp    %rdx,%rax
    ca79:	73 13                	jae    ca8e <f0+0x19ee>
    ca7b:	49 01 c4             	add    %rax,%r12
    ca7e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca83:	0f 84 e5 11 00 00    	je     dc6e <f0+0x2bce>
    ca89:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca8e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ca95:	33 f3 bf 
    ca98:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    ca9f:	00 
    caa0:	bf 01 00 00 00       	mov    $0x1,%edi
    caa5:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    caac:	00 
    caad:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    cab4:	00 
    cab5:	e8 46 96 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    caba:	48 8b 15 37 01 06 00 	mov    0x60137(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cac1:	49 89 c5             	mov    %rax,%r13
    cac4:	48 2b 05 05 01 06 00 	sub    0x60105(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cacb:	48 c1 e2 10          	shl    $0x10,%rdx
    cacf:	48 39 d0             	cmp    %rdx,%rax
    cad2:	73 59                	jae    cb2d <f0+0x1a8d>
    cad4:	48 89 c2             	mov    %rax,%rdx
    cad7:	48 c1 ea 10          	shr    $0x10,%rdx
    cadb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cadf:	48 8b 15 32 01 06 00 	mov    0x60132(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cae6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    caea:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    caee:	4d 85 e4             	test   %r12,%r12
    caf1:	74 3a                	je     cb2d <f0+0x1a8d>
    caf3:	0f b6 0a             	movzbl (%rdx),%ecx
    caf6:	80 f9 02             	cmp    $0x2,%cl
    caf9:	0f 84 91 0e 00 00    	je     d990 <f0+0x28f0>
    caff:	80 f9 01             	cmp    $0x1,%cl
    cb02:	75 29                	jne    cb2d <f0+0x1a8d>
    cb04:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb07:	0f b7 c0             	movzwl %ax,%eax
    cb0a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb0d:	48 0f af c1          	imul   %rcx,%rax
    cb11:	48 c1 e8 20          	shr    $0x20,%rax
    cb15:	48 39 d0             	cmp    %rdx,%rax
    cb18:	73 13                	jae    cb2d <f0+0x1a8d>
    cb1a:	49 01 c4             	add    %rax,%r12
    cb1d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb22:	0f 84 53 11 00 00    	je     dc7b <f0+0x2bdb>
    cb28:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb2d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cb34:	00 f0 3f 
    cb37:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    cb3e:	00 
    cb3f:	bf 01 00 00 00       	mov    $0x1,%edi
    cb44:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    cb4b:	00 
    cb4c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    cb53:	00 
    cb54:	e8 a7 95 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cb59:	48 8b 15 98 00 06 00 	mov    0x60098(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cb60:	49 89 c5             	mov    %rax,%r13
    cb63:	48 2b 05 66 00 06 00 	sub    0x60066(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cb6a:	48 c1 e2 10          	shl    $0x10,%rdx
    cb6e:	48 39 d0             	cmp    %rdx,%rax
    cb71:	73 59                	jae    cbcc <f0+0x1b2c>
    cb73:	48 89 c2             	mov    %rax,%rdx
    cb76:	48 c1 ea 10          	shr    $0x10,%rdx
    cb7a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb7e:	48 8b 15 93 00 06 00 	mov    0x60093(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cb85:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb89:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb8d:	4d 85 e4             	test   %r12,%r12
    cb90:	74 3a                	je     cbcc <f0+0x1b2c>
    cb92:	0f b6 0a             	movzbl (%rdx),%ecx
    cb95:	80 f9 02             	cmp    $0x2,%cl
    cb98:	0f 84 e2 0d 00 00    	je     d980 <f0+0x28e0>
    cb9e:	80 f9 01             	cmp    $0x1,%cl
    cba1:	75 29                	jne    cbcc <f0+0x1b2c>
    cba3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cba6:	0f b7 c0             	movzwl %ax,%eax
    cba9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cbac:	48 0f af c1          	imul   %rcx,%rax
    cbb0:	48 c1 e8 20          	shr    $0x20,%rax
    cbb4:	48 39 d0             	cmp    %rdx,%rax
    cbb7:	73 13                	jae    cbcc <f0+0x1b2c>
    cbb9:	49 01 c4             	add    %rax,%r12
    cbbc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cbc1:	0f 84 c1 10 00 00    	je     dc88 <f0+0x2be8>
    cbc7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cbcc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cbd3:	33 f3 bf 
    cbd6:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    cbdd:	00 
    cbde:	bf 01 00 00 00       	mov    $0x1,%edi
    cbe3:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    cbea:	00 
    cbeb:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    cbf2:	00 
    cbf3:	e8 08 95 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cbf8:	48 8b 15 f9 ff 05 00 	mov    0x5fff9(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cbff:	49 89 c5             	mov    %rax,%r13
    cc02:	48 2b 05 c7 ff 05 00 	sub    0x5ffc7(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cc09:	48 c1 e2 10          	shl    $0x10,%rdx
    cc0d:	48 39 d0             	cmp    %rdx,%rax
    cc10:	73 59                	jae    cc6b <f0+0x1bcb>
    cc12:	48 89 c2             	mov    %rax,%rdx
    cc15:	48 c1 ea 10          	shr    $0x10,%rdx
    cc19:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc1d:	48 8b 15 f4 ff 05 00 	mov    0x5fff4(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cc24:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc28:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc2c:	4d 85 e4             	test   %r12,%r12
    cc2f:	74 3a                	je     cc6b <f0+0x1bcb>
    cc31:	0f b6 0a             	movzbl (%rdx),%ecx
    cc34:	80 f9 02             	cmp    $0x2,%cl
    cc37:	0f 84 33 0d 00 00    	je     d970 <f0+0x28d0>
    cc3d:	80 f9 01             	cmp    $0x1,%cl
    cc40:	75 29                	jne    cc6b <f0+0x1bcb>
    cc42:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc45:	0f b7 c0             	movzwl %ax,%eax
    cc48:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc4b:	48 0f af c1          	imul   %rcx,%rax
    cc4f:	48 c1 e8 20          	shr    $0x20,%rax
    cc53:	48 39 d0             	cmp    %rdx,%rax
    cc56:	73 13                	jae    cc6b <f0+0x1bcb>
    cc58:	49 01 c4             	add    %rax,%r12
    cc5b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc60:	0f 84 2f 10 00 00    	je     dc95 <f0+0x2bf5>
    cc66:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc6b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc72:	00 f0 3f 
    cc75:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    cc7c:	00 
    cc7d:	bf 01 00 00 00       	mov    $0x1,%edi
    cc82:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    cc89:	00 
    cc8a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    cc91:	00 
    cc92:	e8 69 94 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cc97:	48 8b 15 5a ff 05 00 	mov    0x5ff5a(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cc9e:	49 89 c5             	mov    %rax,%r13
    cca1:	48 2b 05 28 ff 05 00 	sub    0x5ff28(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cca8:	48 c1 e2 10          	shl    $0x10,%rdx
    ccac:	48 39 d0             	cmp    %rdx,%rax
    ccaf:	73 59                	jae    cd0a <f0+0x1c6a>
    ccb1:	48 89 c2             	mov    %rax,%rdx
    ccb4:	48 c1 ea 10          	shr    $0x10,%rdx
    ccb8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ccbc:	48 8b 15 55 ff 05 00 	mov    0x5ff55(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    ccc3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ccc7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cccb:	4d 85 e4             	test   %r12,%r12
    ccce:	74 3a                	je     cd0a <f0+0x1c6a>
    ccd0:	0f b6 0a             	movzbl (%rdx),%ecx
    ccd3:	80 f9 02             	cmp    $0x2,%cl
    ccd6:	0f 84 84 0c 00 00    	je     d960 <f0+0x28c0>
    ccdc:	80 f9 01             	cmp    $0x1,%cl
    ccdf:	75 29                	jne    cd0a <f0+0x1c6a>
    cce1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cce4:	0f b7 c0             	movzwl %ax,%eax
    cce7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ccea:	48 0f af c1          	imul   %rcx,%rax
    ccee:	48 c1 e8 20          	shr    $0x20,%rax
    ccf2:	48 39 d0             	cmp    %rdx,%rax
    ccf5:	73 13                	jae    cd0a <f0+0x1c6a>
    ccf7:	49 01 c4             	add    %rax,%r12
    ccfa:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ccff:	0f 84 9d 0f 00 00    	je     dca2 <f0+0x2c02>
    cd05:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd0a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cd11:	33 f3 bf 
    cd14:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    cd1b:	00 
    cd1c:	bf 01 00 00 00       	mov    $0x1,%edi
    cd21:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    cd28:	00 
    cd29:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    cd30:	00 
    cd31:	e8 ca 93 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cd36:	48 8b 15 bb fe 05 00 	mov    0x5febb(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cd3d:	49 89 c5             	mov    %rax,%r13
    cd40:	48 2b 05 89 fe 05 00 	sub    0x5fe89(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cd47:	48 c1 e2 10          	shl    $0x10,%rdx
    cd4b:	48 39 d0             	cmp    %rdx,%rax
    cd4e:	73 59                	jae    cda9 <f0+0x1d09>
    cd50:	48 89 c2             	mov    %rax,%rdx
    cd53:	48 c1 ea 10          	shr    $0x10,%rdx
    cd57:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd5b:	48 8b 15 b6 fe 05 00 	mov    0x5feb6(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cd62:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd66:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd6a:	4d 85 e4             	test   %r12,%r12
    cd6d:	74 3a                	je     cda9 <f0+0x1d09>
    cd6f:	0f b6 0a             	movzbl (%rdx),%ecx
    cd72:	80 f9 02             	cmp    $0x2,%cl
    cd75:	0f 84 d5 0b 00 00    	je     d950 <f0+0x28b0>
    cd7b:	80 f9 01             	cmp    $0x1,%cl
    cd7e:	75 29                	jne    cda9 <f0+0x1d09>
    cd80:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd83:	0f b7 c0             	movzwl %ax,%eax
    cd86:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd89:	48 0f af c1          	imul   %rcx,%rax
    cd8d:	48 c1 e8 20          	shr    $0x20,%rax
    cd91:	48 39 d0             	cmp    %rdx,%rax
    cd94:	73 13                	jae    cda9 <f0+0x1d09>
    cd96:	49 01 c4             	add    %rax,%r12
    cd99:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd9e:	0f 84 0b 0f 00 00    	je     dcaf <f0+0x2c0f>
    cda4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cda9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cdb0:	00 f0 3f 
    cdb3:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    cdba:	00 
    cdbb:	bf 01 00 00 00       	mov    $0x1,%edi
    cdc0:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    cdc7:	00 
    cdc8:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    cdcf:	00 
    cdd0:	e8 2b 93 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cdd5:	48 8b 15 1c fe 05 00 	mov    0x5fe1c(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cddc:	49 89 c5             	mov    %rax,%r13
    cddf:	48 2b 05 ea fd 05 00 	sub    0x5fdea(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cde6:	48 c1 e2 10          	shl    $0x10,%rdx
    cdea:	48 39 d0             	cmp    %rdx,%rax
    cded:	73 59                	jae    ce48 <f0+0x1da8>
    cdef:	48 89 c2             	mov    %rax,%rdx
    cdf2:	48 c1 ea 10          	shr    $0x10,%rdx
    cdf6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cdfa:	48 8b 15 17 fe 05 00 	mov    0x5fe17(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    ce01:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce05:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce09:	4d 85 e4             	test   %r12,%r12
    ce0c:	74 3a                	je     ce48 <f0+0x1da8>
    ce0e:	0f b6 0a             	movzbl (%rdx),%ecx
    ce11:	80 f9 02             	cmp    $0x2,%cl
    ce14:	0f 84 26 0b 00 00    	je     d940 <f0+0x28a0>
    ce1a:	80 f9 01             	cmp    $0x1,%cl
    ce1d:	75 29                	jne    ce48 <f0+0x1da8>
    ce1f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce22:	0f b7 c0             	movzwl %ax,%eax
    ce25:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce28:	48 0f af c1          	imul   %rcx,%rax
    ce2c:	48 c1 e8 20          	shr    $0x20,%rax
    ce30:	48 39 d0             	cmp    %rdx,%rax
    ce33:	73 13                	jae    ce48 <f0+0x1da8>
    ce35:	49 01 c4             	add    %rax,%r12
    ce38:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce3d:	0f 84 79 0e 00 00    	je     dcbc <f0+0x2c1c>
    ce43:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce48:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ce4f:	33 f3 bf 
    ce52:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    ce59:	00 
    ce5a:	bf 01 00 00 00       	mov    $0x1,%edi
    ce5f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    ce66:	00 
    ce67:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    ce6e:	00 
    ce6f:	e8 8c 92 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ce74:	48 8b 15 7d fd 05 00 	mov    0x5fd7d(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    ce7b:	49 89 c5             	mov    %rax,%r13
    ce7e:	48 2b 05 4b fd 05 00 	sub    0x5fd4b(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    ce85:	48 c1 e2 10          	shl    $0x10,%rdx
    ce89:	48 39 d0             	cmp    %rdx,%rax
    ce8c:	73 59                	jae    cee7 <f0+0x1e47>
    ce8e:	48 89 c2             	mov    %rax,%rdx
    ce91:	48 c1 ea 10          	shr    $0x10,%rdx
    ce95:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce99:	48 8b 15 78 fd 05 00 	mov    0x5fd78(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cea0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cea4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cea8:	4d 85 e4             	test   %r12,%r12
    ceab:	74 3a                	je     cee7 <f0+0x1e47>
    cead:	0f b6 0a             	movzbl (%rdx),%ecx
    ceb0:	80 f9 02             	cmp    $0x2,%cl
    ceb3:	0f 84 77 0a 00 00    	je     d930 <f0+0x2890>
    ceb9:	80 f9 01             	cmp    $0x1,%cl
    cebc:	75 29                	jne    cee7 <f0+0x1e47>
    cebe:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cec1:	0f b7 c0             	movzwl %ax,%eax
    cec4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cec7:	48 0f af c1          	imul   %rcx,%rax
    cecb:	48 c1 e8 20          	shr    $0x20,%rax
    cecf:	48 39 d0             	cmp    %rdx,%rax
    ced2:	73 13                	jae    cee7 <f0+0x1e47>
    ced4:	49 01 c4             	add    %rax,%r12
    ced7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cedc:	0f 84 e7 0d 00 00    	je     dcc9 <f0+0x2c29>
    cee2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cee7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ceee:	00 f0 3f 
    cef1:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    cef8:	00 
    cef9:	bf 01 00 00 00       	mov    $0x1,%edi
    cefe:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    cf05:	00 
    cf06:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    cf0d:	00 
    cf0e:	e8 ed 91 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cf13:	48 8b 15 de fc 05 00 	mov    0x5fcde(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cf1a:	49 89 c5             	mov    %rax,%r13
    cf1d:	48 2b 05 ac fc 05 00 	sub    0x5fcac(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cf24:	48 c1 e2 10          	shl    $0x10,%rdx
    cf28:	48 39 d0             	cmp    %rdx,%rax
    cf2b:	73 59                	jae    cf86 <f0+0x1ee6>
    cf2d:	48 89 c2             	mov    %rax,%rdx
    cf30:	48 c1 ea 10          	shr    $0x10,%rdx
    cf34:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf38:	48 8b 15 d9 fc 05 00 	mov    0x5fcd9(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cf3f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf43:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf47:	4d 85 e4             	test   %r12,%r12
    cf4a:	74 3a                	je     cf86 <f0+0x1ee6>
    cf4c:	0f b6 0a             	movzbl (%rdx),%ecx
    cf4f:	80 f9 02             	cmp    $0x2,%cl
    cf52:	0f 84 38 0c 00 00    	je     db90 <f0+0x2af0>
    cf58:	80 f9 01             	cmp    $0x1,%cl
    cf5b:	75 29                	jne    cf86 <f0+0x1ee6>
    cf5d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf60:	0f b7 c0             	movzwl %ax,%eax
    cf63:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf66:	48 0f af c1          	imul   %rcx,%rax
    cf6a:	48 c1 e8 20          	shr    $0x20,%rax
    cf6e:	48 39 d0             	cmp    %rdx,%rax
    cf71:	73 13                	jae    cf86 <f0+0x1ee6>
    cf73:	49 01 c4             	add    %rax,%r12
    cf76:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf7b:	0f 84 55 0d 00 00    	je     dcd6 <f0+0x2c36>
    cf81:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf86:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cf8d:	33 f3 bf 
    cf90:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    cf97:	00 
    cf98:	bf 01 00 00 00       	mov    $0x1,%edi
    cf9d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    cfa4:	00 
    cfa5:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    cfac:	00 
    cfad:	e8 4e 91 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cfb2:	48 8b 15 3f fc 05 00 	mov    0x5fc3f(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cfb9:	49 89 c5             	mov    %rax,%r13
    cfbc:	48 2b 05 0d fc 05 00 	sub    0x5fc0d(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cfc3:	48 c1 e2 10          	shl    $0x10,%rdx
    cfc7:	48 39 d0             	cmp    %rdx,%rax
    cfca:	73 59                	jae    d025 <f0+0x1f85>
    cfcc:	48 89 c2             	mov    %rax,%rdx
    cfcf:	48 c1 ea 10          	shr    $0x10,%rdx
    cfd3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cfd7:	48 8b 15 3a fc 05 00 	mov    0x5fc3a(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cfde:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cfe2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cfe6:	4d 85 e4             	test   %r12,%r12
    cfe9:	74 3a                	je     d025 <f0+0x1f85>
    cfeb:	0f b6 0a             	movzbl (%rdx),%ecx
    cfee:	80 f9 02             	cmp    $0x2,%cl
    cff1:	0f 84 89 0b 00 00    	je     db80 <f0+0x2ae0>
    cff7:	80 f9 01             	cmp    $0x1,%cl
    cffa:	75 29                	jne    d025 <f0+0x1f85>
    cffc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfff:	0f b7 c0             	movzwl %ax,%eax
    d002:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d005:	48 0f af c1          	imul   %rcx,%rax
    d009:	48 c1 e8 20          	shr    $0x20,%rax
    d00d:	48 39 d0             	cmp    %rdx,%rax
    d010:	73 13                	jae    d025 <f0+0x1f85>
    d012:	49 01 c4             	add    %rax,%r12
    d015:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d01a:	0f 84 c3 0c 00 00    	je     dce3 <f0+0x2c43>
    d020:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d025:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d02c:	00 f0 3f 
    d02f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    d036:	00 
    d037:	bf 01 00 00 00       	mov    $0x1,%edi
    d03c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    d043:	00 
    d044:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    d04b:	00 
    d04c:	e8 af 90 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d051:	48 8b 15 a0 fb 05 00 	mov    0x5fba0(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d058:	49 89 c5             	mov    %rax,%r13
    d05b:	48 2b 05 6e fb 05 00 	sub    0x5fb6e(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d062:	48 c1 e2 10          	shl    $0x10,%rdx
    d066:	48 39 d0             	cmp    %rdx,%rax
    d069:	73 59                	jae    d0c4 <f0+0x2024>
    d06b:	48 89 c2             	mov    %rax,%rdx
    d06e:	48 c1 ea 10          	shr    $0x10,%rdx
    d072:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d076:	48 8b 15 9b fb 05 00 	mov    0x5fb9b(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d07d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d081:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d085:	4d 85 e4             	test   %r12,%r12
    d088:	74 3a                	je     d0c4 <f0+0x2024>
    d08a:	0f b6 0a             	movzbl (%rdx),%ecx
    d08d:	80 f9 02             	cmp    $0x2,%cl
    d090:	0f 84 da 0a 00 00    	je     db70 <f0+0x2ad0>
    d096:	80 f9 01             	cmp    $0x1,%cl
    d099:	75 29                	jne    d0c4 <f0+0x2024>
    d09b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d09e:	0f b7 c0             	movzwl %ax,%eax
    d0a1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d0a4:	48 0f af c1          	imul   %rcx,%rax
    d0a8:	48 c1 e8 20          	shr    $0x20,%rax
    d0ac:	48 39 d0             	cmp    %rdx,%rax
    d0af:	73 13                	jae    d0c4 <f0+0x2024>
    d0b1:	49 01 c4             	add    %rax,%r12
    d0b4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d0b9:	0f 84 31 0c 00 00    	je     dcf0 <f0+0x2c50>
    d0bf:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0c4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d0cb:	33 f3 bf 
    d0ce:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    d0d5:	00 
    d0d6:	bf 01 00 00 00       	mov    $0x1,%edi
    d0db:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    d0e2:	00 
    d0e3:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    d0ea:	00 
    d0eb:	e8 10 90 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d0f0:	48 8b 15 01 fb 05 00 	mov    0x5fb01(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d0f7:	49 89 c5             	mov    %rax,%r13
    d0fa:	48 2b 05 cf fa 05 00 	sub    0x5facf(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d101:	48 c1 e2 10          	shl    $0x10,%rdx
    d105:	48 39 d0             	cmp    %rdx,%rax
    d108:	73 59                	jae    d163 <f0+0x20c3>
    d10a:	48 89 c2             	mov    %rax,%rdx
    d10d:	48 c1 ea 10          	shr    $0x10,%rdx
    d111:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d115:	48 8b 15 fc fa 05 00 	mov    0x5fafc(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d11c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d120:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d124:	4d 85 e4             	test   %r12,%r12
    d127:	74 3a                	je     d163 <f0+0x20c3>
    d129:	0f b6 0a             	movzbl (%rdx),%ecx
    d12c:	80 f9 02             	cmp    $0x2,%cl
    d12f:	0f 84 2b 0a 00 00    	je     db60 <f0+0x2ac0>
    d135:	80 f9 01             	cmp    $0x1,%cl
    d138:	75 29                	jne    d163 <f0+0x20c3>
    d13a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d13d:	0f b7 c0             	movzwl %ax,%eax
    d140:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d143:	48 0f af c1          	imul   %rcx,%rax
    d147:	48 c1 e8 20          	shr    $0x20,%rax
    d14b:	48 39 d0             	cmp    %rdx,%rax
    d14e:	73 13                	jae    d163 <f0+0x20c3>
    d150:	49 01 c4             	add    %rax,%r12
    d153:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d158:	0f 84 9f 0b 00 00    	je     dcfd <f0+0x2c5d>
    d15e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d163:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d16a:	00 f0 3f 
    d16d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    d174:	00 
    d175:	bf 01 00 00 00       	mov    $0x1,%edi
    d17a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    d181:	00 
    d182:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    d189:	00 
    d18a:	e8 71 8f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d18f:	48 8b 15 62 fa 05 00 	mov    0x5fa62(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d196:	49 89 c5             	mov    %rax,%r13
    d199:	48 2b 05 30 fa 05 00 	sub    0x5fa30(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d1a0:	48 c1 e2 10          	shl    $0x10,%rdx
    d1a4:	48 39 d0             	cmp    %rdx,%rax
    d1a7:	73 59                	jae    d202 <f0+0x2162>
    d1a9:	48 89 c2             	mov    %rax,%rdx
    d1ac:	48 c1 ea 10          	shr    $0x10,%rdx
    d1b0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d1b4:	48 8b 15 5d fa 05 00 	mov    0x5fa5d(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d1bb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d1bf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d1c3:	4d 85 e4             	test   %r12,%r12
    d1c6:	74 3a                	je     d202 <f0+0x2162>
    d1c8:	0f b6 0a             	movzbl (%rdx),%ecx
    d1cb:	80 f9 02             	cmp    $0x2,%cl
    d1ce:	0f 84 7c 09 00 00    	je     db50 <f0+0x2ab0>
    d1d4:	80 f9 01             	cmp    $0x1,%cl
    d1d7:	75 29                	jne    d202 <f0+0x2162>
    d1d9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d1dc:	0f b7 c0             	movzwl %ax,%eax
    d1df:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d1e2:	48 0f af c1          	imul   %rcx,%rax
    d1e6:	48 c1 e8 20          	shr    $0x20,%rax
    d1ea:	48 39 d0             	cmp    %rdx,%rax
    d1ed:	73 13                	jae    d202 <f0+0x2162>
    d1ef:	49 01 c4             	add    %rax,%r12
    d1f2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d1f7:	0f 84 0d 0b 00 00    	je     dd0a <f0+0x2c6a>
    d1fd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d202:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d209:	33 f3 bf 
    d20c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    d213:	00 
    d214:	bf 01 00 00 00       	mov    $0x1,%edi
    d219:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    d220:	00 
    d221:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    d228:	00 
    d229:	e8 d2 8e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d22e:	48 8b 15 c3 f9 05 00 	mov    0x5f9c3(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d235:	49 89 c5             	mov    %rax,%r13
    d238:	48 2b 05 91 f9 05 00 	sub    0x5f991(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d23f:	48 c1 e2 10          	shl    $0x10,%rdx
    d243:	48 39 d0             	cmp    %rdx,%rax
    d246:	73 59                	jae    d2a1 <f0+0x2201>
    d248:	48 89 c2             	mov    %rax,%rdx
    d24b:	48 c1 ea 10          	shr    $0x10,%rdx
    d24f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d253:	48 8b 15 be f9 05 00 	mov    0x5f9be(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d25a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d25e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d262:	4d 85 e4             	test   %r12,%r12
    d265:	74 3a                	je     d2a1 <f0+0x2201>
    d267:	0f b6 0a             	movzbl (%rdx),%ecx
    d26a:	80 f9 02             	cmp    $0x2,%cl
    d26d:	0f 84 cd 08 00 00    	je     db40 <f0+0x2aa0>
    d273:	80 f9 01             	cmp    $0x1,%cl
    d276:	75 29                	jne    d2a1 <f0+0x2201>
    d278:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d27b:	0f b7 c0             	movzwl %ax,%eax
    d27e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d281:	48 0f af c1          	imul   %rcx,%rax
    d285:	48 c1 e8 20          	shr    $0x20,%rax
    d289:	48 39 d0             	cmp    %rdx,%rax
    d28c:	73 13                	jae    d2a1 <f0+0x2201>
    d28e:	49 01 c4             	add    %rax,%r12
    d291:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d296:	0f 84 7b 0a 00 00    	je     dd17 <f0+0x2c77>
    d29c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d2a1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d2a8:	00 f0 3f 
    d2ab:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    d2b2:	00 
    d2b3:	bf 01 00 00 00       	mov    $0x1,%edi
    d2b8:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    d2bf:	00 
    d2c0:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    d2c7:	00 
    d2c8:	e8 33 8e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d2cd:	48 8b 15 24 f9 05 00 	mov    0x5f924(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d2d4:	49 89 c5             	mov    %rax,%r13
    d2d7:	48 2b 05 f2 f8 05 00 	sub    0x5f8f2(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d2de:	48 c1 e2 10          	shl    $0x10,%rdx
    d2e2:	48 39 d0             	cmp    %rdx,%rax
    d2e5:	73 59                	jae    d340 <f0+0x22a0>
    d2e7:	48 89 c2             	mov    %rax,%rdx
    d2ea:	48 c1 ea 10          	shr    $0x10,%rdx
    d2ee:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d2f2:	48 8b 15 1f f9 05 00 	mov    0x5f91f(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d2f9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d2fd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d301:	4d 85 e4             	test   %r12,%r12
    d304:	74 3a                	je     d340 <f0+0x22a0>
    d306:	0f b6 0a             	movzbl (%rdx),%ecx
    d309:	80 f9 02             	cmp    $0x2,%cl
    d30c:	0f 84 1e 08 00 00    	je     db30 <f0+0x2a90>
    d312:	80 f9 01             	cmp    $0x1,%cl
    d315:	75 29                	jne    d340 <f0+0x22a0>
    d317:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d31a:	0f b7 c0             	movzwl %ax,%eax
    d31d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d320:	48 0f af c1          	imul   %rcx,%rax
    d324:	48 c1 e8 20          	shr    $0x20,%rax
    d328:	48 39 d0             	cmp    %rdx,%rax
    d32b:	73 13                	jae    d340 <f0+0x22a0>
    d32d:	49 01 c4             	add    %rax,%r12
    d330:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d335:	0f 84 e9 09 00 00    	je     dd24 <f0+0x2c84>
    d33b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d340:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d347:	33 f3 bf 
    d34a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    d351:	00 
    d352:	bf 01 00 00 00       	mov    $0x1,%edi
    d357:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    d35e:	00 
    d35f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    d366:	00 
    d367:	e8 94 8d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d36c:	48 8b 15 85 f8 05 00 	mov    0x5f885(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d373:	49 89 c5             	mov    %rax,%r13
    d376:	48 2b 05 53 f8 05 00 	sub    0x5f853(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d37d:	48 c1 e2 10          	shl    $0x10,%rdx
    d381:	48 39 d0             	cmp    %rdx,%rax
    d384:	73 59                	jae    d3df <f0+0x233f>
    d386:	48 89 c2             	mov    %rax,%rdx
    d389:	48 c1 ea 10          	shr    $0x10,%rdx
    d38d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d391:	48 8b 15 80 f8 05 00 	mov    0x5f880(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d398:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d39c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d3a0:	4d 85 e4             	test   %r12,%r12
    d3a3:	74 3a                	je     d3df <f0+0x233f>
    d3a5:	0f b6 0a             	movzbl (%rdx),%ecx
    d3a8:	80 f9 02             	cmp    $0x2,%cl
    d3ab:	0f 84 6f 07 00 00    	je     db20 <f0+0x2a80>
    d3b1:	80 f9 01             	cmp    $0x1,%cl
    d3b4:	75 29                	jne    d3df <f0+0x233f>
    d3b6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d3b9:	0f b7 c0             	movzwl %ax,%eax
    d3bc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d3bf:	48 0f af c1          	imul   %rcx,%rax
    d3c3:	48 c1 e8 20          	shr    $0x20,%rax
    d3c7:	48 39 d0             	cmp    %rdx,%rax
    d3ca:	73 13                	jae    d3df <f0+0x233f>
    d3cc:	49 01 c4             	add    %rax,%r12
    d3cf:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d3d4:	0f 84 57 09 00 00    	je     dd31 <f0+0x2c91>
    d3da:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d3df:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d3e6:	00 f0 3f 
    d3e9:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    d3f0:	00 
    d3f1:	bf 01 00 00 00       	mov    $0x1,%edi
    d3f6:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    d3fd:	00 
    d3fe:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    d405:	00 
    d406:	e8 f5 8c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d40b:	48 8b 15 e6 f7 05 00 	mov    0x5f7e6(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d412:	49 89 c5             	mov    %rax,%r13
    d415:	48 2b 05 b4 f7 05 00 	sub    0x5f7b4(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d41c:	48 c1 e2 10          	shl    $0x10,%rdx
    d420:	48 39 d0             	cmp    %rdx,%rax
    d423:	73 59                	jae    d47e <f0+0x23de>
    d425:	48 89 c2             	mov    %rax,%rdx
    d428:	48 c1 ea 10          	shr    $0x10,%rdx
    d42c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d430:	48 8b 15 e1 f7 05 00 	mov    0x5f7e1(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d437:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d43b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d43f:	4d 85 e4             	test   %r12,%r12
    d442:	74 3a                	je     d47e <f0+0x23de>
    d444:	0f b6 0a             	movzbl (%rdx),%ecx
    d447:	80 f9 02             	cmp    $0x2,%cl
    d44a:	0f 84 c0 06 00 00    	je     db10 <f0+0x2a70>
    d450:	80 f9 01             	cmp    $0x1,%cl
    d453:	75 29                	jne    d47e <f0+0x23de>
    d455:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d458:	0f b7 c0             	movzwl %ax,%eax
    d45b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d45e:	48 0f af c1          	imul   %rcx,%rax
    d462:	48 c1 e8 20          	shr    $0x20,%rax
    d466:	48 39 d0             	cmp    %rdx,%rax
    d469:	73 13                	jae    d47e <f0+0x23de>
    d46b:	49 01 c4             	add    %rax,%r12
    d46e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d473:	0f 84 c5 08 00 00    	je     dd3e <f0+0x2c9e>
    d479:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d47e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d485:	33 f3 bf 
    d488:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    d48f:	00 
    d490:	bf 01 00 00 00       	mov    $0x1,%edi
    d495:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    d49c:	00 
    d49d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    d4a4:	00 
    d4a5:	e8 56 8c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d4aa:	48 8b 15 47 f7 05 00 	mov    0x5f747(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d4b1:	49 89 c5             	mov    %rax,%r13
    d4b4:	48 2b 05 15 f7 05 00 	sub    0x5f715(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d4bb:	48 c1 e2 10          	shl    $0x10,%rdx
    d4bf:	48 39 d0             	cmp    %rdx,%rax
    d4c2:	73 59                	jae    d51d <f0+0x247d>
    d4c4:	48 89 c2             	mov    %rax,%rdx
    d4c7:	48 c1 ea 10          	shr    $0x10,%rdx
    d4cb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d4cf:	48 8b 15 42 f7 05 00 	mov    0x5f742(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d4d6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d4da:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d4de:	4d 85 e4             	test   %r12,%r12
    d4e1:	74 3a                	je     d51d <f0+0x247d>
    d4e3:	0f b6 0a             	movzbl (%rdx),%ecx
    d4e6:	80 f9 02             	cmp    $0x2,%cl
    d4e9:	0f 84 11 06 00 00    	je     db00 <f0+0x2a60>
    d4ef:	80 f9 01             	cmp    $0x1,%cl
    d4f2:	75 29                	jne    d51d <f0+0x247d>
    d4f4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d4f7:	0f b7 c0             	movzwl %ax,%eax
    d4fa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d4fd:	48 0f af c1          	imul   %rcx,%rax
    d501:	48 c1 e8 20          	shr    $0x20,%rax
    d505:	48 39 d0             	cmp    %rdx,%rax
    d508:	73 13                	jae    d51d <f0+0x247d>
    d50a:	49 01 c4             	add    %rax,%r12
    d50d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d512:	0f 84 33 08 00 00    	je     dd4b <f0+0x2cab>
    d518:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d51d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d524:	00 f0 3f 
    d527:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    d52e:	00 
    d52f:	bf 01 00 00 00       	mov    $0x1,%edi
    d534:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    d53b:	00 
    d53c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    d543:	00 
    d544:	e8 b7 8b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d549:	48 8b 15 a8 f6 05 00 	mov    0x5f6a8(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d550:	49 89 c5             	mov    %rax,%r13
    d553:	48 2b 05 76 f6 05 00 	sub    0x5f676(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d55a:	48 c1 e2 10          	shl    $0x10,%rdx
    d55e:	48 39 d0             	cmp    %rdx,%rax
    d561:	73 59                	jae    d5bc <f0+0x251c>
    d563:	48 89 c2             	mov    %rax,%rdx
    d566:	48 c1 ea 10          	shr    $0x10,%rdx
    d56a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d56e:	48 8b 15 a3 f6 05 00 	mov    0x5f6a3(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d575:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d579:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d57d:	4d 85 e4             	test   %r12,%r12
    d580:	74 3a                	je     d5bc <f0+0x251c>
    d582:	0f b6 0a             	movzbl (%rdx),%ecx
    d585:	80 f9 02             	cmp    $0x2,%cl
    d588:	0f 84 62 05 00 00    	je     daf0 <f0+0x2a50>
    d58e:	80 f9 01             	cmp    $0x1,%cl
    d591:	75 29                	jne    d5bc <f0+0x251c>
    d593:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d596:	0f b7 c0             	movzwl %ax,%eax
    d599:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d59c:	48 0f af c1          	imul   %rcx,%rax
    d5a0:	48 c1 e8 20          	shr    $0x20,%rax
    d5a4:	48 39 d0             	cmp    %rdx,%rax
    d5a7:	73 13                	jae    d5bc <f0+0x251c>
    d5a9:	49 01 c4             	add    %rax,%r12
    d5ac:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d5b1:	0f 84 a1 07 00 00    	je     dd58 <f0+0x2cb8>
    d5b7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d5bc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d5c3:	33 f3 bf 
    d5c6:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    d5cd:	00 
    d5ce:	bf 01 00 00 00       	mov    $0x1,%edi
    d5d3:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    d5da:	00 
    d5db:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    d5e2:	00 
    d5e3:	e8 18 8b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d5e8:	48 8b 15 09 f6 05 00 	mov    0x5f609(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d5ef:	49 89 c5             	mov    %rax,%r13
    d5f2:	48 2b 05 d7 f5 05 00 	sub    0x5f5d7(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d5f9:	48 c1 e2 10          	shl    $0x10,%rdx
    d5fd:	48 39 d0             	cmp    %rdx,%rax
    d600:	73 59                	jae    d65b <f0+0x25bb>
    d602:	48 89 c2             	mov    %rax,%rdx
    d605:	48 c1 ea 10          	shr    $0x10,%rdx
    d609:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d60d:	48 8b 15 04 f6 05 00 	mov    0x5f604(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d614:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d618:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d61c:	4d 85 e4             	test   %r12,%r12
    d61f:	74 3a                	je     d65b <f0+0x25bb>
    d621:	0f b6 0a             	movzbl (%rdx),%ecx
    d624:	80 f9 02             	cmp    $0x2,%cl
    d627:	0f 84 b3 04 00 00    	je     dae0 <f0+0x2a40>
    d62d:	80 f9 01             	cmp    $0x1,%cl
    d630:	75 29                	jne    d65b <f0+0x25bb>
    d632:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d635:	0f b7 c0             	movzwl %ax,%eax
    d638:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d63b:	48 0f af c1          	imul   %rcx,%rax
    d63f:	48 c1 e8 20          	shr    $0x20,%rax
    d643:	48 39 d0             	cmp    %rdx,%rax
    d646:	73 13                	jae    d65b <f0+0x25bb>
    d648:	49 01 c4             	add    %rax,%r12
    d64b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d650:	0f 84 0f 07 00 00    	je     dd65 <f0+0x2cc5>
    d656:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d65b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d662:	00 f0 3f 
    d665:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    d66c:	00 
    d66d:	bf 01 00 00 00       	mov    $0x1,%edi
    d672:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    d679:	00 
    d67a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    d681:	00 
    d682:	e8 79 8a ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d687:	48 8b 15 6a f5 05 00 	mov    0x5f56a(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d68e:	49 89 c5             	mov    %rax,%r13
    d691:	48 2b 05 38 f5 05 00 	sub    0x5f538(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d698:	48 c1 e2 10          	shl    $0x10,%rdx
    d69c:	48 39 d0             	cmp    %rdx,%rax
    d69f:	73 59                	jae    d6fa <f0+0x265a>
    d6a1:	48 89 c2             	mov    %rax,%rdx
    d6a4:	48 c1 ea 10          	shr    $0x10,%rdx
    d6a8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d6ac:	48 8b 15 65 f5 05 00 	mov    0x5f565(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d6b3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d6b7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d6bb:	4d 85 e4             	test   %r12,%r12
    d6be:	74 3a                	je     d6fa <f0+0x265a>
    d6c0:	0f b6 0a             	movzbl (%rdx),%ecx
    d6c3:	80 f9 02             	cmp    $0x2,%cl
    d6c6:	0f 84 04 04 00 00    	je     dad0 <f0+0x2a30>
    d6cc:	80 f9 01             	cmp    $0x1,%cl
    d6cf:	75 29                	jne    d6fa <f0+0x265a>
    d6d1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d6d4:	0f b7 c0             	movzwl %ax,%eax
    d6d7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d6da:	48 0f af c1          	imul   %rcx,%rax
    d6de:	48 c1 e8 20          	shr    $0x20,%rax
    d6e2:	48 39 d0             	cmp    %rdx,%rax
    d6e5:	73 13                	jae    d6fa <f0+0x265a>
    d6e7:	49 01 c4             	add    %rax,%r12
    d6ea:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d6ef:	0f 84 7d 06 00 00    	je     dd72 <f0+0x2cd2>
    d6f5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d6fa:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d701:	33 f3 bf 
    d704:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    d70b:	00 
    d70c:	bf 01 00 00 00       	mov    $0x1,%edi
    d711:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    d718:	00 
    d719:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    d720:	00 
    d721:	e8 da 89 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d726:	48 8b 15 cb f4 05 00 	mov    0x5f4cb(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d72d:	49 89 c5             	mov    %rax,%r13
    d730:	48 2b 05 99 f4 05 00 	sub    0x5f499(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d737:	48 c1 e2 10          	shl    $0x10,%rdx
    d73b:	48 39 d0             	cmp    %rdx,%rax
    d73e:	73 59                	jae    d799 <f0+0x26f9>
    d740:	48 89 c2             	mov    %rax,%rdx
    d743:	48 c1 ea 10          	shr    $0x10,%rdx
    d747:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d74b:	48 8b 15 c6 f4 05 00 	mov    0x5f4c6(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d752:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d756:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d75a:	4d 85 e4             	test   %r12,%r12
    d75d:	74 3a                	je     d799 <f0+0x26f9>
    d75f:	0f b6 0a             	movzbl (%rdx),%ecx
    d762:	80 f9 02             	cmp    $0x2,%cl
    d765:	0f 84 55 03 00 00    	je     dac0 <f0+0x2a20>
    d76b:	80 f9 01             	cmp    $0x1,%cl
    d76e:	75 29                	jne    d799 <f0+0x26f9>
    d770:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d773:	0f b7 c0             	movzwl %ax,%eax
    d776:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d779:	48 0f af c1          	imul   %rcx,%rax
    d77d:	48 c1 e8 20          	shr    $0x20,%rax
    d781:	48 39 d0             	cmp    %rdx,%rax
    d784:	73 13                	jae    d799 <f0+0x26f9>
    d786:	49 01 c4             	add    %rax,%r12
    d789:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d78e:	0f 84 eb 05 00 00    	je     dd7f <f0+0x2cdf>
    d794:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d799:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d7a0:	00 f0 3f 
    d7a3:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    d7aa:	00 
    d7ab:	bf 01 00 00 00       	mov    $0x1,%edi
    d7b0:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    d7b7:	00 
    d7b8:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    d7bf:	00 
    d7c0:	e8 3b 89 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d7c5:	48 8b 15 2c f4 05 00 	mov    0x5f42c(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d7cc:	49 89 c5             	mov    %rax,%r13
    d7cf:	48 2b 05 fa f3 05 00 	sub    0x5f3fa(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d7d6:	48 c1 e2 10          	shl    $0x10,%rdx
    d7da:	48 39 d0             	cmp    %rdx,%rax
    d7dd:	73 59                	jae    d838 <f0+0x2798>
    d7df:	48 89 c2             	mov    %rax,%rdx
    d7e2:	48 c1 ea 10          	shr    $0x10,%rdx
    d7e6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d7ea:	48 8b 15 27 f4 05 00 	mov    0x5f427(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d7f1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d7f5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d7f9:	4d 85 e4             	test   %r12,%r12
    d7fc:	74 3a                	je     d838 <f0+0x2798>
    d7fe:	0f b6 0a             	movzbl (%rdx),%ecx
    d801:	80 f9 02             	cmp    $0x2,%cl
    d804:	0f 84 a6 02 00 00    	je     dab0 <f0+0x2a10>
    d80a:	80 f9 01             	cmp    $0x1,%cl
    d80d:	75 29                	jne    d838 <f0+0x2798>
    d80f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d812:	0f b7 c0             	movzwl %ax,%eax
    d815:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d818:	48 0f af c1          	imul   %rcx,%rax
    d81c:	48 c1 e8 20          	shr    $0x20,%rax
    d820:	48 39 d0             	cmp    %rdx,%rax
    d823:	73 13                	jae    d838 <f0+0x2798>
    d825:	49 01 c4             	add    %rax,%r12
    d828:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d82d:	0f 84 59 05 00 00    	je     dd8c <f0+0x2cec>
    d833:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d838:	48 89 ee             	mov    %rbp,%rsi
    d83b:	bf 01 00 00 00       	mov    $0x1,%edi
    d840:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d847:	33 f3 bf 
    d84a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    d851:	00 
    d852:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    d859:	00 
    d85a:	e8 a1 88 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d85f:	48 8b 15 92 f3 05 00 	mov    0x5f392(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d866:	48 89 c5             	mov    %rax,%rbp
    d869:	48 2b 05 60 f3 05 00 	sub    0x5f360(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d870:	48 c1 e2 10          	shl    $0x10,%rdx
    d874:	48 39 d0             	cmp    %rdx,%rax
    d877:	73 59                	jae    d8d2 <f0+0x2832>
    d879:	48 89 c2             	mov    %rax,%rdx
    d87c:	48 c1 ea 10          	shr    $0x10,%rdx
    d880:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d884:	48 8b 15 8d f3 05 00 	mov    0x5f38d(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d88b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d88f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d893:	4d 85 e4             	test   %r12,%r12
    d896:	74 3a                	je     d8d2 <f0+0x2832>
    d898:	0f b6 0a             	movzbl (%rdx),%ecx
    d89b:	80 f9 02             	cmp    $0x2,%cl
    d89e:	0f 84 fc 01 00 00    	je     daa0 <f0+0x2a00>
    d8a4:	80 f9 01             	cmp    $0x1,%cl
    d8a7:	75 29                	jne    d8d2 <f0+0x2832>
    d8a9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d8ac:	0f b7 c0             	movzwl %ax,%eax
    d8af:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d8b2:	48 0f af c1          	imul   %rcx,%rax
    d8b6:	48 c1 e8 20          	shr    $0x20,%rax
    d8ba:	48 39 d0             	cmp    %rdx,%rax
    d8bd:	73 13                	jae    d8d2 <f0+0x2832>
    d8bf:	49 01 c4             	add    %rax,%r12
    d8c2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d8c7:	0f 84 d1 02 00 00    	je     db9e <f0+0x2afe>
    d8cd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d8d2:	48 89 de             	mov    %rbx,%rsi
    d8d5:	48 89 ef             	mov    %rbp,%rdi
    d8d8:	e8 f3 bd ff ff       	call   96d0 <fwp_hof0.constprop.0>
    d8dd:	48 89 ef             	mov    %rbp,%rdi
    d8e0:	e8 3b a2 ff ff       	call   7b20 <fwp_drop0>
    d8e5:	48 89 df             	mov    %rbx,%rdi
    d8e8:	e8 33 a2 ff ff       	call   7b20 <fwp_drop0>
    d8ed:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    d8f4:	00 
    d8f5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    d8fc:	00 00 
    d8fe:	0f 85 95 04 00 00    	jne    dd99 <f0+0x2cf9>
    d904:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    d90b:	31 c0                	xor    %eax,%eax
    d90d:	5b                   	pop    %rbx
    d90e:	5d                   	pop    %rbp
    d90f:	41 5c                	pop    %r12
    d911:	41 5d                	pop    %r13
    d913:	41 5e                	pop    %r14
    d915:	c3                   	ret
    d916:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    d91d:	00 00 00 
    d920:	4c 89 ef             	mov    %r13,%rdi
    d923:	e8 a8 7e ff ff       	call   57d0 <fwp_rc_forget_slot>
    d928:	e9 2c d8 ff ff       	jmp    b159 <f0+0xb9>
    d92d:	0f 1f 00             	nopl   (%rax)
    d930:	66 85 c0             	test   %ax,%ax
    d933:	0f 85 ae f5 ff ff    	jne    cee7 <f0+0x1e47>
    d939:	e9 99 f5 ff ff       	jmp    ced7 <f0+0x1e37>
    d93e:	66 90                	xchg   %ax,%ax
    d940:	66 85 c0             	test   %ax,%ax
    d943:	0f 85 ff f4 ff ff    	jne    ce48 <f0+0x1da8>
    d949:	e9 ea f4 ff ff       	jmp    ce38 <f0+0x1d98>
    d94e:	66 90                	xchg   %ax,%ax
    d950:	66 85 c0             	test   %ax,%ax
    d953:	0f 85 50 f4 ff ff    	jne    cda9 <f0+0x1d09>
    d959:	e9 3b f4 ff ff       	jmp    cd99 <f0+0x1cf9>
    d95e:	66 90                	xchg   %ax,%ax
    d960:	66 85 c0             	test   %ax,%ax
    d963:	0f 85 a1 f3 ff ff    	jne    cd0a <f0+0x1c6a>
    d969:	e9 8c f3 ff ff       	jmp    ccfa <f0+0x1c5a>
    d96e:	66 90                	xchg   %ax,%ax
    d970:	66 85 c0             	test   %ax,%ax
    d973:	0f 85 f2 f2 ff ff    	jne    cc6b <f0+0x1bcb>
    d979:	e9 dd f2 ff ff       	jmp    cc5b <f0+0x1bbb>
    d97e:	66 90                	xchg   %ax,%ax
    d980:	66 85 c0             	test   %ax,%ax
    d983:	0f 85 43 f2 ff ff    	jne    cbcc <f0+0x1b2c>
    d989:	e9 2e f2 ff ff       	jmp    cbbc <f0+0x1b1c>
    d98e:	66 90                	xchg   %ax,%ax
    d990:	66 85 c0             	test   %ax,%ax
    d993:	0f 85 94 f1 ff ff    	jne    cb2d <f0+0x1a8d>
    d999:	e9 7f f1 ff ff       	jmp    cb1d <f0+0x1a7d>
    d99e:	66 90                	xchg   %ax,%ax
    d9a0:	66 85 c0             	test   %ax,%ax
    d9a3:	0f 85 e5 f0 ff ff    	jne    ca8e <f0+0x19ee>
    d9a9:	e9 d0 f0 ff ff       	jmp    ca7e <f0+0x19de>
    d9ae:	66 90                	xchg   %ax,%ax
    d9b0:	66 85 c0             	test   %ax,%ax
    d9b3:	0f 85 fd d9 ff ff    	jne    b3b6 <f0+0x316>
    d9b9:	e9 e8 d9 ff ff       	jmp    b3a6 <f0+0x306>
    d9be:	66 90                	xchg   %ax,%ax
    d9c0:	66 85 c0             	test   %ax,%ax
    d9c3:	0f 85 57 d9 ff ff    	jne    b320 <f0+0x280>
    d9c9:	e9 42 d9 ff ff       	jmp    b310 <f0+0x270>
    d9ce:	66 90                	xchg   %ax,%ax
    d9d0:	66 85 c0             	test   %ax,%ax
    d9d3:	0f 85 b1 d8 ff ff    	jne    b28a <f0+0x1ea>
    d9d9:	e9 9c d8 ff ff       	jmp    b27a <f0+0x1da>
    d9de:	66 90                	xchg   %ax,%ax
    d9e0:	66 85 c0             	test   %ax,%ax
    d9e3:	0f 85 0e eb ff ff    	jne    c4f7 <f0+0x1457>
    d9e9:	e9 f9 ea ff ff       	jmp    c4e7 <f0+0x1447>
    d9ee:	66 90                	xchg   %ax,%ax
    d9f0:	66 85 c0             	test   %ax,%ax
    d9f3:	0f 85 5f ea ff ff    	jne    c458 <f0+0x13b8>
    d9f9:	e9 4a ea ff ff       	jmp    c448 <f0+0x13a8>
    d9fe:	66 90                	xchg   %ax,%ax
    da00:	66 85 c0             	test   %ax,%ax
    da03:	0f 85 e2 da ff ff    	jne    b4eb <f0+0x44b>
    da09:	e9 cd da ff ff       	jmp    b4db <f0+0x43b>
    da0e:	66 90                	xchg   %ax,%ax
    da10:	66 85 c0             	test   %ax,%ax
    da13:	0f 85 33 da ff ff    	jne    b44c <f0+0x3ac>
    da19:	e9 1e da ff ff       	jmp    b43c <f0+0x39c>
    da1e:	66 90                	xchg   %ax,%ax
    da20:	66 85 c0             	test   %ax,%ax
    da23:	0f 85 c6 ef ff ff    	jne    c9ef <f0+0x194f>
    da29:	e9 b1 ef ff ff       	jmp    c9df <f0+0x193f>
    da2e:	66 90                	xchg   %ax,%ax
    da30:	66 85 c0             	test   %ax,%ax
    da33:	0f 85 17 ef ff ff    	jne    c950 <f0+0x18b0>
    da39:	e9 02 ef ff ff       	jmp    c940 <f0+0x18a0>
    da3e:	66 90                	xchg   %ax,%ax
    da40:	66 85 c0             	test   %ax,%ax
    da43:	0f 85 68 ee ff ff    	jne    c8b1 <f0+0x1811>
    da49:	e9 53 ee ff ff       	jmp    c8a1 <f0+0x1801>
    da4e:	66 90                	xchg   %ax,%ax
    da50:	66 85 c0             	test   %ax,%ax
    da53:	0f 85 b9 ed ff ff    	jne    c812 <f0+0x1772>
    da59:	e9 a4 ed ff ff       	jmp    c802 <f0+0x1762>
    da5e:	66 90                	xchg   %ax,%ax
    da60:	66 85 c0             	test   %ax,%ax
    da63:	0f 85 0a ed ff ff    	jne    c773 <f0+0x16d3>
    da69:	e9 f5 ec ff ff       	jmp    c763 <f0+0x16c3>
    da6e:	66 90                	xchg   %ax,%ax
    da70:	66 85 c0             	test   %ax,%ax
    da73:	0f 85 5b ec ff ff    	jne    c6d4 <f0+0x1634>
    da79:	e9 46 ec ff ff       	jmp    c6c4 <f0+0x1624>
    da7e:	66 90                	xchg   %ax,%ax
    da80:	66 85 c0             	test   %ax,%ax
    da83:	0f 85 ac eb ff ff    	jne    c635 <f0+0x1595>
    da89:	e9 97 eb ff ff       	jmp    c625 <f0+0x1585>
    da8e:	66 90                	xchg   %ax,%ax
    da90:	66 85 c0             	test   %ax,%ax
    da93:	0f 85 fd ea ff ff    	jne    c596 <f0+0x14f6>
    da99:	e9 e8 ea ff ff       	jmp    c586 <f0+0x14e6>
    da9e:	66 90                	xchg   %ax,%ax
    daa0:	66 85 c0             	test   %ax,%ax
    daa3:	0f 85 29 fe ff ff    	jne    d8d2 <f0+0x2832>
    daa9:	e9 14 fe ff ff       	jmp    d8c2 <f0+0x2822>
    daae:	66 90                	xchg   %ax,%ax
    dab0:	66 85 c0             	test   %ax,%ax
    dab3:	0f 85 7f fd ff ff    	jne    d838 <f0+0x2798>
    dab9:	e9 6a fd ff ff       	jmp    d828 <f0+0x2788>
    dabe:	66 90                	xchg   %ax,%ax
    dac0:	66 85 c0             	test   %ax,%ax
    dac3:	0f 85 d0 fc ff ff    	jne    d799 <f0+0x26f9>
    dac9:	e9 bb fc ff ff       	jmp    d789 <f0+0x26e9>
    dace:	66 90                	xchg   %ax,%ax
    dad0:	66 85 c0             	test   %ax,%ax
    dad3:	0f 85 21 fc ff ff    	jne    d6fa <f0+0x265a>
    dad9:	e9 0c fc ff ff       	jmp    d6ea <f0+0x264a>
    dade:	66 90                	xchg   %ax,%ax
    dae0:	66 85 c0             	test   %ax,%ax
    dae3:	0f 85 72 fb ff ff    	jne    d65b <f0+0x25bb>
    dae9:	e9 5d fb ff ff       	jmp    d64b <f0+0x25ab>
    daee:	66 90                	xchg   %ax,%ax
    daf0:	66 85 c0             	test   %ax,%ax
    daf3:	0f 85 c3 fa ff ff    	jne    d5bc <f0+0x251c>
    daf9:	e9 ae fa ff ff       	jmp    d5ac <f0+0x250c>
    dafe:	66 90                	xchg   %ax,%ax
    db00:	66 85 c0             	test   %ax,%ax
    db03:	0f 85 14 fa ff ff    	jne    d51d <f0+0x247d>
    db09:	e9 ff f9 ff ff       	jmp    d50d <f0+0x246d>
    db0e:	66 90                	xchg   %ax,%ax
    db10:	66 85 c0             	test   %ax,%ax
    db13:	0f 85 65 f9 ff ff    	jne    d47e <f0+0x23de>
    db19:	e9 50 f9 ff ff       	jmp    d46e <f0+0x23ce>
    db1e:	66 90                	xchg   %ax,%ax
    db20:	66 85 c0             	test   %ax,%ax
    db23:	0f 85 b6 f8 ff ff    	jne    d3df <f0+0x233f>
    db29:	e9 a1 f8 ff ff       	jmp    d3cf <f0+0x232f>
    db2e:	66 90                	xchg   %ax,%ax
    db30:	66 85 c0             	test   %ax,%ax
    db33:	0f 85 07 f8 ff ff    	jne    d340 <f0+0x22a0>
    db39:	e9 f2 f7 ff ff       	jmp    d330 <f0+0x2290>
    db3e:	66 90                	xchg   %ax,%ax
    db40:	66 85 c0             	test   %ax,%ax
    db43:	0f 85 58 f7 ff ff    	jne    d2a1 <f0+0x2201>
    db49:	e9 43 f7 ff ff       	jmp    d291 <f0+0x21f1>
    db4e:	66 90                	xchg   %ax,%ax
    db50:	66 85 c0             	test   %ax,%ax
    db53:	0f 85 a9 f6 ff ff    	jne    d202 <f0+0x2162>
    db59:	e9 94 f6 ff ff       	jmp    d1f2 <f0+0x2152>
    db5e:	66 90                	xchg   %ax,%ax
    db60:	66 85 c0             	test   %ax,%ax
    db63:	0f 85 fa f5 ff ff    	jne    d163 <f0+0x20c3>
    db69:	e9 e5 f5 ff ff       	jmp    d153 <f0+0x20b3>
    db6e:	66 90                	xchg   %ax,%ax
    db70:	66 85 c0             	test   %ax,%ax
    db73:	0f 85 4b f5 ff ff    	jne    d0c4 <f0+0x2024>
    db79:	e9 36 f5 ff ff       	jmp    d0b4 <f0+0x2014>
    db7e:	66 90                	xchg   %ax,%ax
    db80:	66 85 c0             	test   %ax,%ax
    db83:	0f 85 9c f4 ff ff    	jne    d025 <f0+0x1f85>
    db89:	e9 87 f4 ff ff       	jmp    d015 <f0+0x1f75>
    db8e:	66 90                	xchg   %ax,%ax
    db90:	66 85 c0             	test   %ax,%ax
    db93:	0f 85 ed f3 ff ff    	jne    cf86 <f0+0x1ee6>
    db99:	e9 d8 f3 ff ff       	jmp    cf76 <f0+0x1ed6>
    db9e:	4c 89 e7             	mov    %r12,%rdi
    dba1:	e8 2a 7c ff ff       	call   57d0 <fwp_rc_forget_slot>
    dba6:	e9 22 fd ff ff       	jmp    d8cd <f0+0x282d>
    dbab:	4c 89 e7             	mov    %r12,%rdi
    dbae:	e8 1d 7c ff ff       	call   57d0 <fwp_rc_forget_slot>
    dbb3:	e9 cd d6 ff ff       	jmp    b285 <f0+0x1e5>
    dbb8:	4c 89 e7             	mov    %r12,%rdi
    dbbb:	e8 10 7c ff ff       	call   57d0 <fwp_rc_forget_slot>
    dbc0:	e9 56 d7 ff ff       	jmp    b31b <f0+0x27b>
    dbc5:	4c 89 e7             	mov    %r12,%rdi
    dbc8:	e8 03 7c ff ff       	call   57d0 <fwp_rc_forget_slot>
    dbcd:	e9 df d7 ff ff       	jmp    b3b1 <f0+0x311>
    dbd2:	4c 89 e7             	mov    %r12,%rdi
    dbd5:	e8 f6 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dbda:	e9 68 d8 ff ff       	jmp    b447 <f0+0x3a7>
    dbdf:	4c 89 e7             	mov    %r12,%rdi
    dbe2:	e8 e9 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dbe7:	e9 fa d8 ff ff       	jmp    b4e6 <f0+0x446>
    dbec:	4c 89 e7             	mov    %r12,%rdi
    dbef:	e8 dc 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dbf4:	e9 5a e8 ff ff       	jmp    c453 <f0+0x13b3>
    dbf9:	4c 89 e7             	mov    %r12,%rdi
    dbfc:	e8 cf 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc01:	e9 ec e8 ff ff       	jmp    c4f2 <f0+0x1452>
    dc06:	4c 89 e7             	mov    %r12,%rdi
    dc09:	e8 c2 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc0e:	e9 7e e9 ff ff       	jmp    c591 <f0+0x14f1>
    dc13:	4c 89 e7             	mov    %r12,%rdi
    dc16:	e8 b5 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc1b:	e9 10 ea ff ff       	jmp    c630 <f0+0x1590>
    dc20:	4c 89 e7             	mov    %r12,%rdi
    dc23:	e8 a8 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc28:	e9 a2 ea ff ff       	jmp    c6cf <f0+0x162f>
    dc2d:	4c 89 e7             	mov    %r12,%rdi
    dc30:	e8 9b 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc35:	e9 34 eb ff ff       	jmp    c76e <f0+0x16ce>
    dc3a:	4c 89 e7             	mov    %r12,%rdi
    dc3d:	e8 8e 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc42:	e9 c6 eb ff ff       	jmp    c80d <f0+0x176d>
    dc47:	4c 89 e7             	mov    %r12,%rdi
    dc4a:	e8 81 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc4f:	e9 58 ec ff ff       	jmp    c8ac <f0+0x180c>
    dc54:	4c 89 e7             	mov    %r12,%rdi
    dc57:	e8 74 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc5c:	e9 ea ec ff ff       	jmp    c94b <f0+0x18ab>
    dc61:	4c 89 e7             	mov    %r12,%rdi
    dc64:	e8 67 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc69:	e9 7c ed ff ff       	jmp    c9ea <f0+0x194a>
    dc6e:	4c 89 e7             	mov    %r12,%rdi
    dc71:	e8 5a 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc76:	e9 0e ee ff ff       	jmp    ca89 <f0+0x19e9>
    dc7b:	4c 89 e7             	mov    %r12,%rdi
    dc7e:	e8 4d 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc83:	e9 a0 ee ff ff       	jmp    cb28 <f0+0x1a88>
    dc88:	4c 89 e7             	mov    %r12,%rdi
    dc8b:	e8 40 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc90:	e9 32 ef ff ff       	jmp    cbc7 <f0+0x1b27>
    dc95:	4c 89 e7             	mov    %r12,%rdi
    dc98:	e8 33 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dc9d:	e9 c4 ef ff ff       	jmp    cc66 <f0+0x1bc6>
    dca2:	4c 89 e7             	mov    %r12,%rdi
    dca5:	e8 26 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dcaa:	e9 56 f0 ff ff       	jmp    cd05 <f0+0x1c65>
    dcaf:	4c 89 e7             	mov    %r12,%rdi
    dcb2:	e8 19 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dcb7:	e9 e8 f0 ff ff       	jmp    cda4 <f0+0x1d04>
    dcbc:	4c 89 e7             	mov    %r12,%rdi
    dcbf:	e8 0c 7b ff ff       	call   57d0 <fwp_rc_forget_slot>
    dcc4:	e9 7a f1 ff ff       	jmp    ce43 <f0+0x1da3>
    dcc9:	4c 89 e7             	mov    %r12,%rdi
    dccc:	e8 ff 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dcd1:	e9 0c f2 ff ff       	jmp    cee2 <f0+0x1e42>
    dcd6:	4c 89 e7             	mov    %r12,%rdi
    dcd9:	e8 f2 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dcde:	e9 9e f2 ff ff       	jmp    cf81 <f0+0x1ee1>
    dce3:	4c 89 e7             	mov    %r12,%rdi
    dce6:	e8 e5 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dceb:	e9 30 f3 ff ff       	jmp    d020 <f0+0x1f80>
    dcf0:	4c 89 e7             	mov    %r12,%rdi
    dcf3:	e8 d8 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dcf8:	e9 c2 f3 ff ff       	jmp    d0bf <f0+0x201f>
    dcfd:	4c 89 e7             	mov    %r12,%rdi
    dd00:	e8 cb 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd05:	e9 54 f4 ff ff       	jmp    d15e <f0+0x20be>
    dd0a:	4c 89 e7             	mov    %r12,%rdi
    dd0d:	e8 be 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd12:	e9 e6 f4 ff ff       	jmp    d1fd <f0+0x215d>
    dd17:	4c 89 e7             	mov    %r12,%rdi
    dd1a:	e8 b1 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd1f:	e9 78 f5 ff ff       	jmp    d29c <f0+0x21fc>
    dd24:	4c 89 e7             	mov    %r12,%rdi
    dd27:	e8 a4 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd2c:	e9 0a f6 ff ff       	jmp    d33b <f0+0x229b>
    dd31:	4c 89 e7             	mov    %r12,%rdi
    dd34:	e8 97 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd39:	e9 9c f6 ff ff       	jmp    d3da <f0+0x233a>
    dd3e:	4c 89 e7             	mov    %r12,%rdi
    dd41:	e8 8a 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd46:	e9 2e f7 ff ff       	jmp    d479 <f0+0x23d9>
    dd4b:	4c 89 e7             	mov    %r12,%rdi
    dd4e:	e8 7d 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd53:	e9 c0 f7 ff ff       	jmp    d518 <f0+0x2478>
    dd58:	4c 89 e7             	mov    %r12,%rdi
    dd5b:	e8 70 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd60:	e9 52 f8 ff ff       	jmp    d5b7 <f0+0x2517>
    dd65:	4c 89 e7             	mov    %r12,%rdi
    dd68:	e8 63 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd6d:	e9 e4 f8 ff ff       	jmp    d656 <f0+0x25b6>
    dd72:	4c 89 e7             	mov    %r12,%rdi
    dd75:	e8 56 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd7a:	e9 76 f9 ff ff       	jmp    d6f5 <f0+0x2655>
    dd7f:	4c 89 e7             	mov    %r12,%rdi
    dd82:	e8 49 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd87:	e9 08 fa ff ff       	jmp    d794 <f0+0x26f4>
    dd8c:	4c 89 e7             	mov    %r12,%rdi
    dd8f:	e8 3c 7a ff ff       	call   57d0 <fwp_rc_forget_slot>
    dd94:	e9 9a fa ff ff       	jmp    d833 <f0+0x2793>
    dd99:	e8 b2 56 ff ff       	call   3450 <__stack_chk_fail@plt>
    dd9e:	66 90                	xchg   %ax,%ax

000000000000dda0 <fwp_main_thread>:
    dda0:	f3 0f 1e fa          	endbr64
    dda4:	41 54                	push   %r12
    dda6:	55                   	push   %rbp
    dda7:	53                   	push   %rbx
    dda8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    ddaf:	8b 0d 0f ee 05 00    	mov    0x5ee0f(%rip),%ecx        # 6cbc4 <fwp_heap+0x13a4>
    ddb5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    ddbc:	00 00 
    ddbe:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    ddc5:	00 
    ddc6:	31 c0                	xor    %eax,%eax
    ddc8:	85 c9                	test   %ecx,%ecx
    ddca:	0f 84 58 07 00 00    	je     e528 <fwp_main_thread+0x788>
    ddd0:	8b 15 f2 ed 05 00    	mov    0x5edf2(%rip),%edx        # 6cbc8 <fwp_heap+0x13a8>
    ddd6:	85 d2                	test   %edx,%edx
    ddd8:	0f 85 32 07 00 00    	jne    e510 <fwp_main_thread+0x770>
    ddde:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    dde3:	31 f6                	xor    %esi,%esi
    dde5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    ddea:	48 c7 05 cb d3 05 00 	movq   $0x40000000,0x5d3cb(%rip)        # 6b1c0 <fwp_main_stack_size>
    ddf1:	00 00 00 40 
    ddf5:	48 89 05 cc d3 05 00 	mov    %rax,0x5d3cc(%rip)        # 6b1c8 <fwp_main_stack_top>
    ddfc:	48 8d 05 7d 52 00 00 	lea    0x527d(%rip),%rax        # 13080 <alt.5>
    de03:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    de08:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    de0f:	01 00 
    de11:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    de18:	00 
    de19:	e8 82 58 ff ff       	call   36a0 <sigaltstack@plt>
    de1e:	85 c0                	test   %eax,%eax
    de20:	0f 85 6a 07 00 00    	jne    e590 <fwp_main_thread+0x7f0>
    de26:	31 c0                	xor    %eax,%eax
    de28:	b9 12 00 00 00       	mov    $0x12,%ecx
    de2d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    de32:	f3 48 ab             	rep stos %rax,(%rdi)
    de35:	48 8d 05 04 5f ff ff 	lea    -0xa0fc(%rip),%rax        # 3d40 <fwp_segv>
    de3c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    de41:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    de48:	04 00 00 08 
    de4c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    de51:	e8 0a 57 ff ff       	call   3560 <sigemptyset@plt>
    de56:	85 c0                	test   %eax,%eax
    de58:	0f 85 32 07 00 00    	jne    e590 <fwp_main_thread+0x7f0>
    de5e:	31 d2                	xor    %edx,%edx
    de60:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    de65:	bf 0b 00 00 00       	mov    $0xb,%edi
    de6a:	e8 81 55 ff ff       	call   33f0 <sigaction@plt>
    de6f:	85 c0                	test   %eax,%eax
    de71:	0f 85 19 07 00 00    	jne    e590 <fwp_main_thread+0x7f0>
    de77:	31 d2                	xor    %edx,%edx
    de79:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    de7e:	bf 07 00 00 00       	mov    $0x7,%edi
    de83:	e8 68 55 ff ff       	call   33f0 <sigaction@plt>
    de88:	85 c0                	test   %eax,%eax
    de8a:	0f 85 00 07 00 00    	jne    e590 <fwp_main_thread+0x7f0>
    de90:	48 8b 05 a9 ed 05 00 	mov    0x5eda9(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    de97:	48 85 c0             	test   %rax,%rax
    de9a:	0f 88 50 06 00 00    	js     e4f0 <fwp_main_thread+0x750>
    dea0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    dea4:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    dea9:	48 8d 3d 70 63 ff ff 	lea    -0x9c90(%rip),%rdi        # 4220 <ad_raw_report>
    deb0:	f2 0f 11 05 10 f6 05 	movsd  %xmm0,0x5f610(%rip)        # 6d4c8 <iteration_start_charge>
    deb7:	00 
    deb8:	c7 05 26 f6 05 00 01 	movl   $0x1,0x5f626(%rip)        # 6d4e8 <iteration_active>
    debf:	00 00 00 
    dec2:	e8 09 09 00 00       	call   e7d0 <atexit>
    dec7:	85 c0                	test   %eax,%eax
    dec9:	0f 85 cd 06 00 00    	jne    e59c <fwp_main_thread+0x7fc>
    decf:	8b 05 9b 51 00 00    	mov    0x519b(%rip),%eax        # 13070 <st.3>
    ded5:	85 c0                	test   %eax,%eax
    ded7:	0f 84 5b 06 00 00    	je     e538 <fwp_main_thread+0x798>
    dedd:	48 8b 2d 1c d9 05 00 	mov    0x5d91c(%rip),%rbp        # 6b800 <fwp_cur>
    dee4:	48 85 ed             	test   %rbp,%rbp
    dee7:	0f 84 03 03 00 00    	je     e1f0 <fwp_main_thread+0x450>
    deed:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    def2:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    def6:	48 89 eb             	mov    %rbp,%rbx
    def9:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    defe:	0f 84 41 01 00 00    	je     e045 <fwp_main_thread+0x2a5>
    df04:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    df09:	0f 84 11 02 00 00    	je     e120 <fwp_main_thread+0x380>
    df0f:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    df13:	0f 84 f7 01 00 00    	je     e110 <fwp_main_thread+0x370>
    df19:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    df1d:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    df21:	0f 85 79 02 00 00    	jne    e1a0 <fwp_main_thread+0x400>
    df27:	48 8b 43 60          	mov    0x60(%rbx),%rax
    df2b:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    df32:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    df36:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    df3d:	00 00 00 00 
    df41:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    df48:	48 85 d2             	test   %rdx,%rdx
    df4b:	74 07                	je     df54 <fwp_main_thread+0x1b4>
    df4d:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    df54:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    df58:	48 85 c0             	test   %rax,%rax
    df5b:	74 34                	je     df91 <fwp_main_thread+0x1f1>
    df5d:	48 89 43 68          	mov    %rax,0x68(%rbx)
    df61:	48 8b 05 70 d8 05 00 	mov    0x5d870(%rip),%rax        # 6b7d8 <fwp_timers>
    df68:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    df6c:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    df73:	00 00 00 00 
    df77:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    df7e:	48 85 c0             	test   %rax,%rax
    df81:	74 07                	je     df8a <fwp_main_thread+0x1ea>
    df83:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    df8a:	48 89 1d 47 d8 05 00 	mov    %rbx,0x5d847(%rip)        # 6b7d8 <fwp_timers>
    df91:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    df95:	e8 16 97 ff ff       	call   76b0 <fwp_block>
    df9a:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    dfa1:	48 85 c9             	test   %rcx,%rcx
    dfa4:	74 47                	je     dfed <fwp_main_thread+0x24d>
    dfa6:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    dfad:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    dfb4:	48 85 d2             	test   %rdx,%rdx
    dfb7:	0f 84 23 02 00 00    	je     e1e0 <fwp_main_thread+0x440>
    dfbd:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    dfc4:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    dfcb:	48 85 c0             	test   %rax,%rax
    dfce:	74 07                	je     dfd7 <fwp_main_thread+0x237>
    dfd0:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    dfd7:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    dfde:	00 00 00 00 
    dfe2:	66 0f ef d2          	pxor   %xmm2,%xmm2
    dfe6:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    dfed:	48 8b 0d 0c d8 05 00 	mov    0x5d80c(%rip),%rcx        # 6b800 <fwp_cur>
    dff4:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    dff8:	0f 84 92 01 00 00    	je     e190 <fwp_main_thread+0x3f0>
    dffe:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    e005:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    e00c:	48 85 d2             	test   %rdx,%rdx
    e00f:	0f 84 1b 04 00 00    	je     e430 <fwp_main_thread+0x690>
    e015:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    e01c:	48 85 c0             	test   %rax,%rax
    e01f:	74 07                	je     e028 <fwp_main_thread+0x288>
    e021:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    e028:	66 0f ef db          	pxor   %xmm3,%xmm3
    e02c:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    e030:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    e037:	48 89 cb             	mov    %rcx,%rbx
    e03a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e03f:	0f 85 bf fe ff ff    	jne    df04 <fwp_main_thread+0x164>
    e045:	48 83 3d 4b f4 05 00 	cmpq   $0x0,0x5f44b(%rip)        # 6d498 <fwp_state_len>
    e04c:	00 
    e04d:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    e051:	0f 84 0b 04 00 00    	je     e462 <fwp_main_thread+0x6c2>
    e057:	48 3b 1d 9a d7 05 00 	cmp    0x5d79a(%rip),%rbx        # 6b7f8 <fwp_root>
    e05e:	c7 05 18 50 01 00 00 	movl   $0x0,0x15018(%rip)        # 23080 <fwp_exit_code>
    e065:	00 00 00 
    e068:	0f 85 4c 05 00 00    	jne    e5ba <fwp_main_thread+0x81a>
    e06e:	48 85 db             	test   %rbx,%rbx
    e071:	0f 84 9f 01 00 00    	je     e216 <fwp_main_thread+0x476>
    e077:	48 8b 15 4a d7 05 00 	mov    0x5d74a(%rip),%rdx        # 6b7c8 <fwp_tasks_active>
    e07e:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    e082:	48 85 d2             	test   %rdx,%rdx
    e085:	0f 84 8b 01 00 00    	je     e216 <fwp_main_thread+0x476>
    e08b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e090:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    e094:	75 08                	jne    e09e <fwp_main_thread+0x2fe>
    e096:	48 89 d7             	mov    %rdx,%rdi
    e099:	e8 92 60 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    e09e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    e0a5:	48 85 d2             	test   %rdx,%rdx
    e0a8:	75 e6                	jne    e090 <fwp_main_thread+0x2f0>
    e0aa:	eb 31                	jmp    e0dd <fwp_main_thread+0x33d>
    e0ac:	0f 1f 40 00          	nopl   0x0(%rax)
    e0b0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    e0b7:	48 89 1d 22 d7 05 00 	mov    %rbx,0x5d722(%rip)        # 6b7e0 <fwp_ready_tail>
    e0be:	e8 ed 95 ff ff       	call   76b0 <fwp_block>
    e0c3:	e8 d8 93 ff ff       	call   74a0 <fwp_free_zombie>
    e0c8:	48 83 3d f8 d6 05 00 	cmpq   $0x0,0x5d6f8(%rip)        # 6b7c8 <fwp_tasks_active>
    e0cf:	00 
    e0d0:	0f 84 40 01 00 00    	je     e216 <fwp_main_thread+0x476>
    e0d6:	48 8b 1d 1b d7 05 00 	mov    0x5d71b(%rip),%rbx        # 6b7f8 <fwp_root>
    e0dd:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    e0e1:	75 db                	jne    e0be <fwp_main_thread+0x31e>
    e0e3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    e0e7:	75 d5                	jne    e0be <fwp_main_thread+0x31e>
    e0e9:	48 8b 05 f0 d6 05 00 	mov    0x5d6f0(%rip),%rax        # 6b7e0 <fwp_ready_tail>
    e0f0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    e0f4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    e0fb:	00 00 00 00 
    e0ff:	48 85 c0             	test   %rax,%rax
    e102:	75 ac                	jne    e0b0 <fwp_main_thread+0x310>
    e104:	48 89 1d dd d6 05 00 	mov    %rbx,0x5d6dd(%rip)        # 6b7e8 <fwp_ready_head>
    e10b:	eb aa                	jmp    e0b7 <fwp_main_thread+0x317>
    e10d:	0f 1f 00             	nopl   (%rax)
    e110:	e8 ab 64 ff ff       	call   45c0 <fwp_now_ns>
    e115:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    e119:	0f 8d 21 03 00 00    	jge    e440 <fwp_main_thread+0x6a0>
    e11f:	90                   	nop
    e120:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e124:	0f 85 ef fd ff ff    	jne    df19 <fwp_main_thread+0x179>
    e12a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    e12e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e132:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e136:	0f 85 ef fd ff ff    	jne    df2b <fwp_main_thread+0x18b>
    e13c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    e140:	48 85 c9             	test   %rcx,%rcx
    e143:	0f 84 e2 fd ff ff    	je     df2b <fwp_main_thread+0x18b>
    e149:	48 85 c0             	test   %rax,%rax
    e14c:	0f 84 5b 04 00 00    	je     e5ad <fwp_main_thread+0x80d>
    e152:	48 39 c8             	cmp    %rcx,%rax
    e155:	48 0f 4f c1          	cmovg  %rcx,%rax
    e159:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e160:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e164:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e16b:	00 00 00 00 
    e16f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e176:	48 85 d2             	test   %rdx,%rdx
    e179:	74 07                	je     e182 <fwp_main_thread+0x3e2>
    e17b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e182:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e186:	e9 d2 fd ff ff       	jmp    df5d <fwp_main_thread+0x1bd>
    e18b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e190:	48 89 cb             	mov    %rcx,%rbx
    e193:	e9 61 fd ff ff       	jmp    def9 <fwp_main_thread+0x159>
    e198:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e19f:	00 
    e1a0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    e1a4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e1ab:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e1b2:	00 00 00 00 
    e1b6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    e1bd:	48 85 c0             	test   %rax,%rax
    e1c0:	0f 84 9a 03 00 00    	je     e560 <fwp_main_thread+0x7c0>
    e1c6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    e1cd:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e1d1:	e9 bb fd ff ff       	jmp    df91 <fwp_main_thread+0x1f1>
    e1d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e1dd:	00 00 00 
    e1e0:	48 89 01             	mov    %rax,(%rcx)
    e1e3:	e9 e3 fd ff ff       	jmp    dfcb <fwp_main_thread+0x22b>
    e1e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e1ef:	00 
    e1f0:	48 83 3d a0 f2 05 00 	cmpq   $0x0,0x5f2a0(%rip)        # 6d498 <fwp_state_len>
    e1f7:	00 
    e1f8:	0f 84 62 02 00 00    	je     e460 <fwp_main_thread+0x6c0>
    e1fe:	48 83 3d f2 d5 05 00 	cmpq   $0x0,0x5d5f2(%rip)        # 6b7f8 <fwp_root>
    e205:	00 
    e206:	c7 05 70 4e 01 00 00 	movl   $0x0,0x14e70(%rip)        # 23080 <fwp_exit_code>
    e20d:	00 00 00 
    e210:	0f 85 9f 03 00 00    	jne    e5b5 <fwp_main_thread+0x815>
    e216:	e8 85 92 ff ff       	call   74a0 <fwp_free_zombie>
    e21b:	48 83 3d c5 d5 05 00 	cmpq   $0x0,0x5d5c5(%rip)        # 6b7e8 <fwp_ready_head>
    e222:	00 
    e223:	0f 85 2c 55 ff ff    	jne    3755 <fwp_main_thread.cold>
    e229:	48 83 3d a7 d5 05 00 	cmpq   $0x0,0x5d5a7(%rip)        # 6b7d8 <fwp_timers>
    e230:	00 
    e231:	0f 85 1e 55 ff ff    	jne    3755 <fwp_main_thread.cold>
    e237:	8b 1d 97 cf 05 00    	mov    0x5cf97(%rip),%ebx        # 6b1d4 <fwp_stack_pool_n>
    e23d:	85 db                	test   %ebx,%ebx
    e23f:	74 36                	je     e277 <fwp_main_thread+0x4d7>
    e241:	83 eb 01             	sub    $0x1,%ebx
    e244:	48 8d 05 95 cf 05 00 	lea    0x5cf95(%rip),%rax        # 6b1e0 <fwp_stack_pool>
    e24b:	48 63 d3             	movslq %ebx,%rdx
    e24e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    e252:	eb 07                	jmp    e25b <fwp_main_thread+0x4bb>
    e254:	0f 1f 40 00          	nopl   0x0(%rax)
    e258:	83 eb 01             	sub    $0x1,%ebx
    e25b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    e25f:	be 00 00 00 10       	mov    $0x10000000,%esi
    e264:	89 1d 6a cf 05 00    	mov    %ebx,0x5cf6a(%rip)        # 6b1d4 <fwp_stack_pool_n>
    e26a:	48 83 ed 08          	sub    $0x8,%rbp
    e26e:	e8 4d 53 ff ff       	call   35c0 <munmap@plt>
    e273:	85 db                	test   %ebx,%ebx
    e275:	75 e1                	jne    e258 <fwp_main_thread+0x4b8>
    e277:	8b 3d 9b 4d 00 00    	mov    0x4d9b(%rip),%edi        # 13018 <fwp_epfd>
    e27d:	85 ff                	test   %edi,%edi
    e27f:	78 05                	js     e286 <fwp_main_thread+0x4e6>
    e281:	e8 3a 52 ff ff       	call   34c0 <close@plt>
    e286:	4c 8b 25 53 d1 05 00 	mov    0x5d153(%rip),%r12        # 6b3e0 <fwp_nfdws>
    e28d:	48 8b 2d 54 d1 05 00 	mov    0x5d154(%rip),%rbp        # 6b3e8 <fwp_fdws>
    e294:	31 db                	xor    %ebx,%ebx
    e296:	c7 05 78 4d 00 00 ff 	movl   $0xffffffff,0x4d78(%rip)        # 13018 <fwp_epfd>
    e29d:	ff ff ff 
    e2a0:	4d 85 e4             	test   %r12,%r12
    e2a3:	74 38                	je     e2dd <fwp_main_thread+0x53d>
    e2a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    e2ac:	00 00 00 00 
    e2b0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    e2b5:	48 85 ff             	test   %rdi,%rdi
    e2b8:	74 1a                	je     e2d4 <fwp_main_thread+0x534>
    e2ba:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    e2be:	0f 85 91 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e2c4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    e2c9:	0f 85 86 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e2cf:	e8 3c 77 ff ff       	call   5a10 <fwp_mem_free>
    e2d4:	48 83 c3 01          	add    $0x1,%rbx
    e2d8:	49 39 dc             	cmp    %rbx,%r12
    e2db:	75 d3                	jne    e2b0 <fwp_main_thread+0x510>
    e2dd:	48 89 ef             	mov    %rbp,%rdi
    e2e0:	e8 2b 77 ff ff       	call   5a10 <fwp_mem_free>
    e2e5:	48 8b 15 0c d5 05 00 	mov    0x5d50c(%rip),%rdx        # 6b7f8 <fwp_root>
    e2ec:	48 c7 05 f1 d0 05 00 	movq   $0x0,0x5d0f1(%rip)        # 6b3e8 <fwp_fdws>
    e2f3:	00 00 00 00 
    e2f7:	48 c7 05 de d0 05 00 	movq   $0x0,0x5d0de(%rip)        # 6b3e0 <fwp_nfdws>
    e2fe:	00 00 00 00 
    e302:	48 85 d2             	test   %rdx,%rdx
    e305:	74 4e                	je     e355 <fwp_main_thread+0x5b5>
    e307:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    e30c:	0f 85 43 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e312:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    e319:	00 
    e31a:	0f 85 35 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e320:	48 83 3d 70 f1 05 00 	cmpq   $0x0,0x5f170(%rip)        # 6d498 <fwp_state_len>
    e327:	00 
    e328:	0f 85 27 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e32e:	48 83 3d 52 f1 05 00 	cmpq   $0x0,0x5f152(%rip)        # 6d488 <fwp_state_owners>
    e335:	00 
    e336:	0f 85 19 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e33c:	b9 79 00 00 00       	mov    $0x79,%ecx
    e341:	31 c0                	xor    %eax,%eax
    e343:	48 8d 3d b6 d0 05 00 	lea    0x5d0b6(%rip),%rdi        # 6b400 <fwp_root_context>
    e34a:	f3 48 ab             	rep stos %rax,(%rdi)
    e34d:	48 89 d7             	mov    %rdx,%rdi
    e350:	e8 bb 76 ff ff       	call   5a10 <fwp_mem_free>
    e355:	66 0f 6f 05 53 4e 04 	movdqa 0x44e53(%rip),%xmm0        # 531b0 <ad_raw_live+0x10>
    e35c:	00 
    e35d:	66 0f d4 05 3b 4e 04 	paddq  0x44e3b(%rip),%xmm0        # 531a0 <ad_raw_live>
    e364:	00 
    e365:	48 c7 05 90 d4 05 00 	movq   $0x0,0x5d490(%rip)        # 6b800 <fwp_cur>
    e36c:	00 00 00 00 
    e370:	48 8b 05 c9 e8 05 00 	mov    0x5e8c9(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    e377:	48 c7 05 76 d4 05 00 	movq   $0x0,0x5d476(%rip)        # 6b7f8 <fwp_root>
    e37e:	00 00 00 00 
    e382:	c7 05 5c f1 05 00 00 	movl   $0x0,0x5f15c(%rip)        # 6d4e8 <iteration_active>
    e389:	00 00 00 
    e38c:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    e390:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    e395:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    e399:	66 0f d6 05 57 4d 01 	movq   %xmm0,0x14d57(%rip)        # 230f8 <ad_raw_before_shutdown>
    e3a0:	00 
    e3a1:	48 85 c0             	test   %rax,%rax
    e3a4:	0f 88 26 01 00 00    	js     e4d0 <fwp_main_thread+0x730>
    e3aa:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e3ae:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    e3b3:	f2 0f 5c 0d 0d f1 05 	subsd  0x5f10d(%rip),%xmm1        # 6d4c8 <iteration_start_charge>
    e3ba:	00 
    e3bb:	48 8b 3d 7e 4c 00 00 	mov    0x4c7e(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    e3c2:	48 8d 15 a7 17 00 00 	lea    0x17a7(%rip),%rdx        # fb70 <_IO_stdin_used+0xb70>
    e3c9:	be 02 00 00 00       	mov    $0x2,%esi
    e3ce:	f2 0f 10 05 ea f0 05 	movsd  0x5f0ea(%rip),%xmm0        # 6d4c0 <iteration_peak>
    e3d5:	00 
    e3d6:	4c 8b 0d f3 f0 05 00 	mov    0x5f0f3(%rip),%r9        # 6d4d0 <iteration_retains>
    e3dd:	b8 02 00 00 00       	mov    $0x2,%eax
    e3e2:	4c 8b 05 ef f0 05 00 	mov    0x5f0ef(%rip),%r8        # 6d4d8 <iteration_bytes>
    e3e9:	48 8b 0d f0 f0 05 00 	mov    0x5f0f0(%rip),%rcx        # 6d4e0 <iteration_requests>
    e3f0:	e8 7b 52 ff ff       	call   3670 <__fprintf_chk@plt>
    e3f5:	48 8b 3d 24 4c 00 00 	mov    0x4c24(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    e3fc:	e8 9f 51 ff ff       	call   35a0 <fflush@plt>
    e401:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    e408:	00 
    e409:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e410:	00 00 
    e412:	0f 85 90 01 00 00    	jne    e5a8 <fwp_main_thread+0x808>
    e418:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    e41f:	31 c0                	xor    %eax,%eax
    e421:	5b                   	pop    %rbx
    e422:	5d                   	pop    %rbp
    e423:	41 5c                	pop    %r12
    e425:	c3                   	ret
    e426:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e42d:	00 00 00 
    e430:	48 89 05 a1 d3 05 00 	mov    %rax,0x5d3a1(%rip)        # 6b7d8 <fwp_timers>
    e437:	e9 e0 fb ff ff       	jmp    e01c <fwp_main_thread+0x27c>
    e43c:	0f 1f 40 00          	nopl   0x0(%rax)
    e440:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    e444:	0f 85 d6 fc ff ff    	jne    e120 <fwp_main_thread+0x380>
    e44a:	48 89 ef             	mov    %rbp,%rdi
    e44d:	e8 de 5c ff ff       	call   4130 <fwp_cancel_tree.part.0>
    e452:	e9 c9 fc ff ff       	jmp    e120 <fwp_main_thread+0x380>
    e457:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e45e:	00 00 
    e460:	31 db                	xor    %ebx,%ebx
    e462:	48 83 3d 1e f0 05 00 	cmpq   $0x0,0x5f01e(%rip)        # 6d488 <fwp_state_owners>
    e469:	00 
    e46a:	0f 85 e7 fb ff ff    	jne    e057 <fwp_main_thread+0x2b7>
    e470:	48 8b 3d 29 f0 05 00 	mov    0x5f029(%rip),%rdi        # 6d4a0 <fwp_state>
    e477:	e8 94 75 ff ff       	call   5a10 <fwp_mem_free>
    e47c:	48 c7 05 19 f0 05 00 	movq   $0x0,0x5f019(%rip)        # 6d4a0 <fwp_state>
    e483:	00 00 00 00 
    e487:	48 c7 05 fe ef 05 00 	movq   $0x0,0x5effe(%rip)        # 6d490 <fwp_state_cap>
    e48e:	00 00 00 00 
    e492:	48 85 db             	test   %rbx,%rbx
    e495:	0f 84 ce 00 00 00    	je     e569 <fwp_main_thread+0x7c9>
    e49b:	48 39 1d 56 d3 05 00 	cmp    %rbx,0x5d356(%rip)        # 6b7f8 <fwp_root>
    e4a2:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    e4a9:	00 00 00 00 
    e4ad:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    e4b4:	00 00 00 00 
    e4b8:	c7 05 be 4b 01 00 00 	movl   $0x0,0x14bbe(%rip)        # 23080 <fwp_exit_code>
    e4bf:	00 00 00 
    e4c2:	0f 84 af fb ff ff    	je     e077 <fwp_main_thread+0x2d7>
    e4c8:	e9 88 52 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e4cd:	0f 1f 00             	nopl   (%rax)
    e4d0:	48 89 c2             	mov    %rax,%rdx
    e4d3:	83 e0 01             	and    $0x1,%eax
    e4d6:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e4da:	48 d1 ea             	shr    $1,%rdx
    e4dd:	48 09 c2             	or     %rax,%rdx
    e4e0:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    e4e5:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    e4e9:	e9 c5 fe ff ff       	jmp    e3b3 <fwp_main_thread+0x613>
    e4ee:	66 90                	xchg   %ax,%ax
    e4f0:	48 89 c2             	mov    %rax,%rdx
    e4f3:	83 e0 01             	and    $0x1,%eax
    e4f6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e4fa:	48 d1 ea             	shr    $1,%rdx
    e4fd:	48 09 c2             	or     %rax,%rdx
    e500:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    e505:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    e509:	e9 9b f9 ff ff       	jmp    dea9 <fwp_main_thread+0x109>
    e50e:	66 90                	xchg   %ax,%ax
    e510:	48 8d 3d a9 67 ff ff 	lea    -0x9857(%rip),%rdi        # 4cc0 <fwp_heap_report>
    e517:	e8 b4 02 00 00       	call   e7d0 <atexit>
    e51c:	e9 bd f8 ff ff       	jmp    ddde <fwp_main_thread+0x3e>
    e521:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    e528:	e8 a3 68 ff ff       	call   4dd0 <fwp_heap_init>
    e52d:	e9 9e f8 ff ff       	jmp    ddd0 <fwp_main_thread+0x30>
    e532:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e538:	e8 63 cb ff ff       	call   b0a0 <f0>
    e53d:	48 c7 05 20 4b 00 00 	movq   $0x0,0x4b20(%rip)        # 13068 <v.2>
    e544:	00 00 00 00 
    e548:	c7 05 1e 4b 00 00 01 	movl   $0x1,0x4b1e(%rip)        # 13070 <st.3>
    e54f:	00 00 00 
    e552:	e9 86 f9 ff ff       	jmp    dedd <fwp_main_thread+0x13d>
    e557:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e55e:	00 00 
    e560:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e564:	e9 28 fa ff ff       	jmp    df91 <fwp_main_thread+0x1f1>
    e569:	48 83 3d 87 d2 05 00 	cmpq   $0x0,0x5d287(%rip)        # 6b7f8 <fwp_root>
    e570:	00 
    e571:	c7 05 05 4b 01 00 00 	movl   $0x0,0x14b05(%rip)        # 23080 <fwp_exit_code>
    e578:	00 00 00 
    e57b:	0f 84 95 fc ff ff    	je     e216 <fwp_main_thread+0x476>
    e581:	e9 cf 51 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e586:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e58d:	00 00 00 
    e590:	48 8d 3d b1 15 00 00 	lea    0x15b1(%rip),%rdi        # fb48 <_IO_stdin_used+0xb48>
    e597:	e8 b4 5e ff ff       	call   4450 <fwp_trap>
    e59c:	48 8d 3d 30 0d 00 00 	lea    0xd30(%rip),%rdi        # f2d3 <_IO_stdin_used+0x2d3>
    e5a3:	e8 58 5a ff ff       	call   4000 <ad_raw_fail>
    e5a8:	e8 a3 4e ff ff       	call   3450 <__stack_chk_fail@plt>
    e5ad:	48 89 c8             	mov    %rcx,%rax
    e5b0:	e9 a4 fb ff ff       	jmp    e159 <fwp_main_thread+0x3b9>
    e5b5:	e9 9b 51 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e5ba:	e9 96 51 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e5bf:	90                   	nop

000000000000e5c0 <__divmodti4>:
    e5c0:	f3 0f 1e fa          	endbr64
    e5c4:	55                   	push   %rbp
    e5c5:	49 89 f1             	mov    %rsi,%r9
    e5c8:	49 89 d2             	mov    %rdx,%r10
    e5cb:	48 89 fe             	mov    %rdi,%rsi
    e5ce:	49 89 cb             	mov    %rcx,%r11
    e5d1:	48 89 e5             	mov    %rsp,%rbp
    e5d4:	41 57                	push   %r15
    e5d6:	41 56                	push   %r14
    e5d8:	41 55                	push   %r13
    e5da:	41 54                	push   %r12
    e5dc:	53                   	push   %rbx
    e5dd:	4c 89 c3             	mov    %r8,%rbx
    e5e0:	45 31 c0             	xor    %r8d,%r8d
    e5e3:	4d 85 c9             	test   %r9,%r9
    e5e6:	79 12                	jns    e5fa <__divmodti4+0x3a>
    e5e8:	31 ff                	xor    %edi,%edi
    e5ea:	48 f7 de             	neg    %rsi
    e5ed:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    e5f4:	4c 19 cf             	sbb    %r9,%rdi
    e5f7:	49 89 f9             	mov    %rdi,%r9
    e5fa:	4c 89 d8             	mov    %r11,%rax
    e5fd:	4d 85 db             	test   %r11,%r11
    e600:	0f 88 1a 01 00 00    	js     e720 <__divmodti4+0x160>
    e606:	4c 89 d9             	mov    %r11,%rcx
    e609:	49 89 f3             	mov    %rsi,%r11
    e60c:	75 62                	jne    e670 <__divmodti4+0xb0>
    e60e:	4d 89 c4             	mov    %r8,%r12
    e611:	4d 39 d1             	cmp    %r10,%r9
    e614:	0f 83 46 01 00 00    	jae    e760 <__divmodti4+0x1a0>
    e61a:	4c 89 d8             	mov    %r11,%rax
    e61d:	4c 89 ca             	mov    %r9,%rdx
    e620:	49 f7 f2             	div    %r10
    e623:	49 89 c3             	mov    %rax,%r11
    e626:	31 c0                	xor    %eax,%eax
    e628:	48 89 d6             	mov    %rdx,%rsi
    e62b:	31 ff                	xor    %edi,%edi
    e62d:	4c 89 d9             	mov    %r11,%rcx
    e630:	48 89 c2             	mov    %rax,%rdx
    e633:	48 89 c8             	mov    %rcx,%rax
    e636:	4d 85 e4             	test   %r12,%r12
    e639:	74 0a                	je     e645 <__divmodti4+0x85>
    e63b:	48 f7 d8             	neg    %rax
    e63e:	48 83 d2 00          	adc    $0x0,%rdx
    e642:	48 f7 da             	neg    %rdx
    e645:	4d 85 c0             	test   %r8,%r8
    e648:	74 0a                	je     e654 <__divmodti4+0x94>
    e64a:	48 f7 de             	neg    %rsi
    e64d:	48 83 d7 00          	adc    $0x0,%rdi
    e651:	48 f7 df             	neg    %rdi
    e654:	48 89 33             	mov    %rsi,(%rbx)
    e657:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    e65b:	5b                   	pop    %rbx
    e65c:	41 5c                	pop    %r12
    e65e:	41 5d                	pop    %r13
    e660:	41 5e                	pop    %r14
    e662:	41 5f                	pop    %r15
    e664:	5d                   	pop    %rbp
    e665:	c3                   	ret
    e666:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e66d:	00 00 00 
    e670:	4d 89 c4             	mov    %r8,%r12
    e673:	49 39 c1             	cmp    %rax,%r9
    e676:	0f 82 ce 00 00 00    	jb     e74a <__divmodti4+0x18a>
    e67c:	31 ff                	xor    %edi,%edi
    e67e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    e683:	48 63 c7             	movslq %edi,%rax
    e686:	be 40 00 00 00       	mov    $0x40,%esi
    e68b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    e690:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    e695:	48 29 c6             	sub    %rax,%rsi
    e698:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    e69d:	48 09 c8             	or     %rcx,%rax
    e6a0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    e6a5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    e6aa:	49 89 c6             	mov    %rax,%r14
    e6ad:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    e6b1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    e6b6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    e6bb:	49 09 c1             	or     %rax,%r9
    e6be:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    e6c2:	4c 89 c8             	mov    %r9,%rax
    e6c5:	49 f7 f6             	div    %r14
    e6c8:	48 89 d1             	mov    %rdx,%rcx
    e6cb:	49 89 c3             	mov    %rax,%r11
    e6ce:	49 89 c1             	mov    %rax,%r9
    e6d1:	49 f7 e2             	mul    %r10
    e6d4:	49 89 c6             	mov    %rax,%r14
    e6d7:	49 89 d2             	mov    %rdx,%r10
    e6da:	48 39 d1             	cmp    %rdx,%rcx
    e6dd:	72 07                	jb     e6e6 <__divmodti4+0x126>
    e6df:	75 17                	jne    e6f8 <__divmodti4+0x138>
    e6e1:	49 39 c7             	cmp    %rax,%r15
    e6e4:	73 12                	jae    e6f8 <__divmodti4+0x138>
    e6e6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    e6ea:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    e6ee:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    e6f2:	49 89 d2             	mov    %rdx,%r10
    e6f5:	49 89 c6             	mov    %rax,%r14
    e6f8:	4c 89 f8             	mov    %r15,%rax
    e6fb:	4c 29 f0             	sub    %r14,%rax
    e6fe:	4c 19 d1             	sbb    %r10,%rcx
    e701:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    e706:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    e70b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    e710:	48 09 c6             	or     %rax,%rsi
    e713:	48 89 cf             	mov    %rcx,%rdi
    e716:	31 c0                	xor    %eax,%eax
    e718:	4c 89 c9             	mov    %r9,%rcx
    e71b:	e9 10 ff ff ff       	jmp    e630 <__divmodti4+0x70>
    e720:	4c 89 d0             	mov    %r10,%rax
    e723:	4c 89 da             	mov    %r11,%rdx
    e726:	4d 89 c4             	mov    %r8,%r12
    e729:	49 89 f3             	mov    %rsi,%r11
    e72c:	48 f7 d8             	neg    %rax
    e72f:	49 f7 d4             	not    %r12
    e732:	48 83 d2 00          	adc    $0x0,%rdx
    e736:	49 89 c2             	mov    %rax,%r10
    e739:	48 f7 da             	neg    %rdx
    e73c:	48 89 d1             	mov    %rdx,%rcx
    e73f:	0f 84 cc fe ff ff    	je     e611 <__divmodti4+0x51>
    e745:	49 39 d1             	cmp    %rdx,%r9
    e748:	73 46                	jae    e790 <__divmodti4+0x1d0>
    e74a:	4c 89 cf             	mov    %r9,%rdi
    e74d:	31 c0                	xor    %eax,%eax
    e74f:	31 c9                	xor    %ecx,%ecx
    e751:	e9 da fe ff ff       	jmp    e630 <__divmodti4+0x70>
    e756:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e75d:	00 00 00 
    e760:	4d 85 d2             	test   %r10,%r10
    e763:	75 0d                	jne    e772 <__divmodti4+0x1b2>
    e765:	b8 01 00 00 00       	mov    $0x1,%eax
    e76a:	31 d2                	xor    %edx,%edx
    e76c:	49 f7 f2             	div    %r10
    e76f:	49 89 c2             	mov    %rax,%r10
    e772:	4c 89 c8             	mov    %r9,%rax
    e775:	31 d2                	xor    %edx,%edx
    e777:	49 f7 f2             	div    %r10
    e77a:	49 89 c1             	mov    %rax,%r9
    e77d:	4c 89 d8             	mov    %r11,%rax
    e780:	49 f7 f2             	div    %r10
    e783:	49 89 c3             	mov    %rax,%r11
    e786:	4c 89 c8             	mov    %r9,%rax
    e789:	e9 9a fe ff ff       	jmp    e628 <__divmodti4+0x68>
    e78e:	66 90                	xchg   %ax,%ax
    e790:	45 31 f6             	xor    %r14d,%r14d
    e793:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    e798:	44 89 f7             	mov    %r14d,%edi
    e79b:	45 85 f6             	test   %r14d,%r14d
    e79e:	0f 85 df fe ff ff    	jne    e683 <__divmodti4+0xc3>
    e7a4:	4c 39 ca             	cmp    %r9,%rdx
    e7a7:	72 17                	jb     e7c0 <__divmodti4+0x200>
    e7a9:	31 c9                	xor    %ecx,%ecx
    e7ab:	48 39 c6             	cmp    %rax,%rsi
    e7ae:	73 10                	jae    e7c0 <__divmodti4+0x200>
    e7b0:	4c 89 cf             	mov    %r9,%rdi
    e7b3:	31 c0                	xor    %eax,%eax
    e7b5:	e9 76 fe ff ff       	jmp    e630 <__divmodti4+0x70>
    e7ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e7c0:	4c 89 de             	mov    %r11,%rsi
    e7c3:	b9 01 00 00 00       	mov    $0x1,%ecx
    e7c8:	48 29 c6             	sub    %rax,%rsi
    e7cb:	49 19 d1             	sbb    %rdx,%r9
    e7ce:	eb e0                	jmp    e7b0 <__divmodti4+0x1f0>

000000000000e7d0 <atexit>:
    e7d0:	f3 0f 1e fa          	endbr64
    e7d4:	48 8b 15 2d 48 00 00 	mov    0x482d(%rip),%rdx        # 13008 <__dso_handle>
    e7db:	31 f6                	xor    %esi,%esi
    e7dd:	e9 5e 4e ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000e7e4 <_fini>:
    e7e4:	f3 0f 1e fa          	endbr64
    e7e8:	48 83 ec 08          	sub    $0x8,%rsp
    e7ec:	48 83 c4 08          	add    $0x8,%rsp
    e7f0:	c3                   	ret
