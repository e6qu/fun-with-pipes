
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-reference-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 ff 00 00 	mov    0xffc1(%rip),%rax        # 12fd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da fd 00 00    	push   0xfdda(%rip)        # 12e00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc fd 00 00    	jmp    *0xfddc(%rip)        # 12e08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 fc 00 00    	jmp    *0xfc46(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12e60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12e68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12e70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12e78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12e80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12e88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12e90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12e98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12ea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12ea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12eb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12eb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12ec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12ec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12ed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12ed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12ee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12ee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12ef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12ef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12f60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12f68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12f70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12f78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12f80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12f88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 f8 00 00    	jmp    *0xf8e6(%rip)        # 12f90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de f8 00 00    	jmp    *0xf8de(%rip)        # 12f98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 f8 00 00    	jmp    *0xf8d6(%rip)        # 12fa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce f8 00 00    	jmp    *0xf8ce(%rip)        # 12fa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 f8 00 00    	jmp    *0xf8c6(%rip)        # 12fb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be f8 00 00    	jmp    *0xf8be(%rip)        # 12fb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd b9 00 00 	lea    0xb9dd(%rip),%r9        # f0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da b9 00 00 	lea    0xb9da(%rip),%r8        # f0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_hof0.constprop.0.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>
    3750:	e8 ab ff ff ff       	call   3700 <fwp_trap_overflow.constprop.0>

0000000000003755 <fwp_main_thread.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>

000000000000375a <main.cold>:
    375a:	e8 71 fc ff ff       	call   33d0 <abort@plt>
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 81 db 00 00 	lea    0xdb81(%rip),%rax        # 11300 <fwp_fn_table>
    377f:	48 89 05 b2 1c 02 00 	mov    %rax,0x21cb2(%rip)        # 25438 <fwp_fns>
    3786:	48 8b 05 93 f8 00 00 	mov    0xf893(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ac 1c 02 00 	mov    %rax,0x21cac(%rip)        # 25440 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d b7 ba 00 00 	lea    0xbab7(%rip),%rdi        # f257 <_IO_stdin_used+0x257>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 f8 00 00 	mov    0xf818(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 6f a0 00 00 	lea    0xa06f(%rip),%rdx        # d8d0 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 e0 fe ff ff    	jne    375a <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 c4 fe ff ff    	jne    375a <main.cold>
    3896:	48 8b 3d 83 f7 00 00 	mov    0xf783(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 f8 f7 01 00    	mov    0x1f7f8(%rip),%eax        # 230a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 67 b9 00 00 	lea    0xb967(%rip),%rdi        # f260 <_IO_stdin_used+0x260>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 86 c1 00 00 	lea    0xc186(%rip),%rdi        # fa90 <_IO_stdin_used+0xa90>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 39 fe ff ff    	jne    375a <main.cold>
    3921:	48 8d 3d 40 c1 00 00 	lea    0xc140(%rip),%rdi        # fa68 <_IO_stdin_used+0xa68>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d 04 c1 00 00 	lea    0xc104(%rip),%rdi        # fa38 <_IO_stdin_used+0xa38>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d d0 c0 00 00 	lea    0xc0d0(%rip),%rdi        # fa10 <_IO_stdin_used+0xa10>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b f6 00 00    	call   *0xf64b(%rip)        # 12fc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 f6 00 00 	lea    0xf699(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 f6 00 00 	lea    0xf692(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e f6 00 00 	mov    0xf62e(%rip),%rax        # 12fc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 f6 00 00 	lea    0xf669(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 f6 00 00 	lea    0xf662(%rip),%rsi        # 13020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd f5 00 00 	mov    0xf5fd(%rip),%rax        # 12fd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d f6 00 00 00 	cmpb   $0x0,0xf64d(%rip)        # 13048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da f5 00 00 	cmpq   $0x0,0xf5da(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 f6 00 00 01 	movb   $0x1,0xf625(%rip)        # 13048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ee f4 01 00 	add    0x1f4ee(%rip),%rdx        # 23110 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 dc f4 01 00 	add    0x1f4dc(%rip),%rax        # 23110 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d c9 17 02 00 	mov    0x217c9(%rip),%rdi        # 25440 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 f3 00 00 	mov    0xf394(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 f3 00 00 	mov    0xf381(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 b3 00 00 	lea    0xb345(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 f3 00 00 	mov    0xf372(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 c1 fa 01 00 	mov    0x1fac1(%rip),%rax        # 237c0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 f9 f3 01 00 	mov    0x1f3f9(%rip),%rax        # 23178 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 e5 f3 01 00 	sub    0x1f3e5(%rip),%rax        # 23170 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 ad bd 00 00 	lea    0xbdad(%rip),%rsi        # fb70 <msg.8>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 87 b8 00 00 	lea    0xb887(%rip),%rdi        # f670 <_IO_stdin_used+0x670>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 42 f2 00 00 	mov    0xf242(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d e5 f1 00 00 ff 	cmpl   $0xffffffff,0xf1e5(%rip)        # 13018 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 b1 00 00 	lea    0xb1e2(%rip),%rax        # f022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d e1 f2 01 00 	mov    0x1f2e1(%rip),%r9        # 23128 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f ed 00 	movq   0xed9f(%rip),%xmm0        # 12bf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 b1 00 00 	lea    0xb1e7(%rip),%rax        # f044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 bc f2 01 00 	mov    0x1f2bc(%rip),%r8        # 23120 <descent_inputs>
    3e64:	48 8b 0d c5 f2 01 00 	mov    0x1f2c5(%rip),%rcx        # 23130 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d c2 f1 00 00 	mov    0xf1c2(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 b1 00 00 	lea    0xb1d8(%rip),%rax        # f061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 ed 00 	movq   0xed67(%rip),%xmm0        # 12bf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 20 b8 00 00 	lea    0xb820(%rip),%rdx        # f6b8 <_IO_stdin_used+0x6b8>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 91 f2 01 00 	lea    0x1f291(%rip),%r12        # 23140 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 ed 00 	movq   0xed44(%rip),%xmm0        # 12c00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 5b f1 00 00 	mov    0xf15b(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 b1 00 00 	lea    0xb175(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 b1 00 00 	lea    0xb170(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 20 f1 00 00 	mov    0xf120(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 b1 00 00 	lea    0xb144(%rip),%rdi        # f07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d f9 f0 00 00 	mov    0xf0f9(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 b1 00 00 	lea    0xb143(%rip),%rcx        # f091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 b1 00 00 	lea    0xb119(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 3b 0c 02 00 	mov    0x20c3b(%rip),%rax        # 24bd0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 34 0c 02 00 	lea    0x20c34(%rip),%r8        # 24bd0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d 15 0c 02 00 	mov    0x20c15(%rip),%rbx        # 24bb8 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 25 0c 02 00 	mov    0x20c25(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d c1 0b 02 00 	mov    0x20bc1(%rip),%rdi        # 24bc0 <fwp_heap+0x13e0>
    3fff:	48 29 35 0a 0c 02 00 	sub    %rsi,0x20c0a(%rip)        # 24c10 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 9a 0b 02 00 	mov    0x20b9a(%rip),%rax        # 24bb0 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 50 0b 02 00 	add    0x20b50(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 5e 0b 02 00 	mov    0x20b5e(%rip),%rsi        # 24bc0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 6c 0b 02 00 	mov    0x20b6c(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 1b 0b 02 00 	mov    %r12,0x20b1b(%rip)        # 24bc0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d 09 0b 02 00 	mov    %rbp,0x20b09(%rip)        # 24bb8 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d ee 0a 02 00 	cmp    %rdi,0x20aee(%rip)        # 24ba8 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d e5 0a 02 00 	mov    %rdi,0x20ae5(%rip)        # 24ba8 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 29 0b 02 00 	sub    %rdi,0x20b29(%rip)        # 24c10 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 d1 0a 02 00 	mov    0x20ad1(%rip),%rax        # 24bc8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 ca 0a 02 00 	lea    0x20aca(%rip),%r8        # 24bc8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 5d ee 00 00 	mov    0xee5d(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 ae 00 00 	lea    0xae14(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d ad ed 00 00 	movslq 0xedad(%rip),%rbp        # 13018 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 9a ee 01 00 	mov    0x1ee9a(%rip),%rsi        # 23138 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d 96 ee 01 00 	lea    0x1ee96(%rip),%rcx        # 23140 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 6b ee 01 00 	addq   $0x1,0x1ee6b(%rip)        # 23130 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 48 ed 00 00    	mov    %ebx,0xed48(%rip)        # 13018 <descent_active_phase>
    42d0:	48 89 05 61 ee 01 00 	mov    %rax,0x1ee61(%rip)        # 23138 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d b9 f4 01 00 	cmp    0x1f4b9(%rip),%rdi        # 237c0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 7f f4 01 00 	mov    0x1f47f(%rip),%rax        # 237a0 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 5d f4 01 00 	mov    %rdi,0x1f45d(%rip)        # 237a0 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 39 f4 01 00 	mov    %rdi,0x1f439(%rip)        # 237a8 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 ee ad 00 00 	lea    0xadee(%rip),%rsi        # f19f <_IO_stdin_used+0x19f>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba ac 00 00 	lea    0xacba(%rip),%rsi        # f07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 28 ec 00 00 	mov    0xec28(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 ac 00 00 	lea    0xac64(%rip),%rdx        # f083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 10 ec 00 00 	mov    0xec10(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 21 eb 00 00 	mov    0xeb21(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 aa 00 00 	lea    0xaad8(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 ab 00 00 	lea    0xab45(%rip),%rdi        # f092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd aa 00 00 	lea    0xaacd(%rip),%rdi        # f0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d 18 b1 00 00 	lea    0xb118(%rip),%rdi        # f708 <_IO_stdin_used+0x708>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 b0 b5 00 	movdqa 0xb5b0(%rip),%xmm0        # fbc0 <msg.8+0x50>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 ca 0d 02 00 	add    0x20dca(%rip),%rax        # 25438 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 6c b0 00 00 	lea    0xb06c(%rip),%rdi        # f730 <_IO_stdin_used+0x730>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 25 ea 01 00 	cmp    %rax,0x1ea25(%rip)        # 23108 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 20 ea 01 00 	add    0x1ea20(%rip),%rax        # 23110 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 55 b0 00 00 	lea    0xb055(%rip),%rdi        # f760 <_IO_stdin_used+0x760>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 a9 00 00 	lea    0xa9a5(%rip),%r8        # f0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa a7 00 00 	lea    0xa7fa(%rip),%r8        # f0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 a6 00 00 	lea    0xa697(%rip),%r8        # f0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f a4 00 00 	lea    0xa46f(%rip),%rdi        # f0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 54 a5 00 00 	lea    0xa554(%rip),%rsi        # f1e2 <_IO_stdin_used+0x1e2>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d a5 fe 01 00 	mov    0x1fea5(%rip),%r9        # 24ba8 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 fe fe 01 00 	mov    0x1fefe(%rip),%r8        # 24c08 <fwp_heap+0x1428>
    4d0a:	48 8d 15 9f aa 00 00 	lea    0xaa9f(%rip),%rdx        # f7b0 <_IO_stdin_used+0x7b0>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d e6 fe 01 00 	mov    0x1fee6(%rip),%rcx        # 24c00 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d f4 fe 01 	movsd  0x1fef4(%rip),%xmm1        # 24c20 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 e4 fe 01 	movsd  0x1fee4(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 05 e3 00 00 	mov    0xe305(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 58 ae 00 	movdqa 0xae58(%rip),%xmm0        # fbd0 <msg.8+0x60>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 9f f9 01 00 	lea    0x1f99f(%rip),%rax        # 24720 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 81 ae 00 	movdqa 0xae81(%rip),%xmm2        # fc10 <msg.8+0xa0>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 45 f9 01 00 	movaps %xmm0,0x1f945(%rip)        # 246e0 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 3d ae 00 	movdqa 0xae3d(%rip),%xmm0        # fbe0 <msg.8+0x70>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 d3 fd 01 00 01 	movl   $0x1,0x1fdd3(%rip)        # 24b84 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 33 f9 01 00 	movaps %xmm0,0x1f933(%rip)        # 246f0 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 2b ae 00 	movdqa 0xae2b(%rip),%xmm0        # fbf0 <msg.8+0x80>
    4dc4:	00 
    4dc5:	0f 29 05 34 f9 01 00 	movaps %xmm0,0x1f934(%rip)        # 24700 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 2c ae 00 	movdqa 0xae2c(%rip),%xmm0        # fc00 <msg.8+0x90>
    4dd3:	00 
    4dd4:	0f 29 05 35 f9 01 00 	movaps %xmm0,0x1f935(%rip)        # 24710 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 b5 e9 01 00 	lea    0x1e9b5(%rip),%r8        # 237e0 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 d0 fc 01 00 	mov    %rax,0x1fcd0(%rip)        # 24b98 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 ae fc 01 00 	mov    %r12,0x1fcae(%rip)        # 24ba0 <fwp_heap+0x13c0>
    4ef2:	48 89 05 97 fc 01 00 	mov    %rax,0x1fc97(%rip)        # 24b90 <fwp_heap+0x13b0>
    4ef9:	48 89 1d b0 fc 01 00 	mov    %rbx,0x1fcb0(%rip)        # 24bb0 <fwp_heap+0x13d0>
    4f00:	48 89 35 d9 fc 01 00 	mov    %rsi,0x1fcd9(%rip)        # 24be0 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 a1 00 00 	lea    0xa1f9(%rip),%rdi        # f112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 b8 fc 01 00 	mov    %rax,0x1fcb8(%rip)        # 24bd8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 3c fc 01 00    	mov    %eax,0x1fc3c(%rip)        # 24b88 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <caf75>:
    4f60:	8b 15 12 e1 00 00    	mov    0xe112(%rip),%edx        # 13078 <st.4>
    4f66:	85 d2                	test   %edx,%edx
    4f68:	74 0e                	je     4f78 <caf75+0x18>
    4f6a:	48 8b 05 ff e0 00 00 	mov    0xe0ff(%rip),%rax        # 13070 <v.3>
    4f71:	c3                   	ret
    4f72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f78:	8b 05 ea e0 00 00    	mov    0xe0ea(%rip),%eax        # 13068 <st.2>
    4f7e:	85 c0                	test   %eax,%eax
    4f80:	74 1e                	je     4fa0 <caf75+0x40>
    4f82:	48 8b 05 d7 e0 00 00 	mov    0xe0d7(%rip),%rax        # 13060 <v.1>
    4f89:	48 89 05 e0 e0 00 00 	mov    %rax,0xe0e0(%rip)        # 13070 <v.3>
    4f90:	c7 05 de e0 00 00 01 	movl   $0x1,0xe0de(%rip)        # 13078 <st.4>
    4f97:	00 00 00 
    4f9a:	c3                   	ret
    4f9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4fa0:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    4fa7:	00 f0 3f 
    4faa:	c7 05 b4 e0 00 00 01 	movl   $0x1,0xe0b4(%rip)        # 13068 <st.2>
    4fb1:	00 00 00 
    4fb4:	48 89 05 a5 e0 00 00 	mov    %rax,0xe0a5(%rip)        # 13060 <v.1>
    4fbb:	eb cc                	jmp    4f89 <caf75+0x29>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 cc e7 01 00 	mov    0x1e7cc(%rip),%r8        # 237a0 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d fc e6 01 00 	mov    %rbx,0x1e6fc(%rip)        # 237a8 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 e8 e6 01 00 	mov    %r8,0x1e6e8(%rip)        # 237a0 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <fwp_tape_buffers_release>:
    50d0:	f3 0f 1e fa          	endbr64
    50d4:	53                   	push   %rbx
    50d5:	48 89 fb             	mov    %rdi,%rbx
    50d8:	48 83 ec 10          	sub    $0x10,%rsp
    50dc:	48 8b 47 28          	mov    0x28(%rdi),%rax
    50e0:	48 85 c0             	test   %rax,%rax
    50e3:	0f 88 df 00 00 00    	js     51c8 <fwp_tape_buffers_release+0xf8>
    50e9:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    50ed:	48 85 d2             	test   %rdx,%rdx
    50f0:	0f 88 d2 00 00 00    	js     51c8 <fwp_tape_buffers_release+0xf8>
    50f6:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    50fc:	0f 87 c6 00 00 00    	ja     51c8 <fwp_tape_buffers_release+0xf8>
    5102:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5106:	b8 00 00 08 00       	mov    $0x80000,%eax
    510b:	48 c1 e1 03          	shl    $0x3,%rcx
    510f:	48 29 c8             	sub    %rcx,%rax
    5112:	48 c1 e8 03          	shr    $0x3,%rax
    5116:	48 39 d0             	cmp    %rdx,%rax
    5119:	0f 82 a9 00 00 00    	jb     51c8 <fwp_tape_buffers_release+0xf8>
    511f:	48 8d 3d fc 9f 00 00 	lea    0x9ffc(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    5126:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    512b:	48 89 14 24          	mov    %rdx,(%rsp)
    512f:	e8 6c e2 ff ff       	call   33a0 <getenv@plt>
    5134:	48 8b 14 24          	mov    (%rsp),%rdx
    5138:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    513d:	48 85 c0             	test   %rax,%rax
    5140:	74 09                	je     514b <fwp_tape_buffers_release+0x7b>
    5142:	80 38 30             	cmpb   $0x30,(%rax)
    5145:	0f 84 9d 00 00 00    	je     51e8 <fwp_tape_buffers_release+0x118>
    514b:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    514f:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    5153:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    515a:	77 78                	ja     51d4 <fwp_tape_buffers_release+0x104>
    515c:	48 8d 3d 5d df 01 00 	lea    0x1df5d(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    5163:	48 89 04 24          	mov    %rax,(%rsp)
    5167:	e8 a4 ef ff ff       	call   4110 <fwp_tape_buffers_dispose>
    516c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5170:	48 8b 04 24          	mov    (%rsp),%rax
    5174:	0f 29 05 45 df 01 00 	movaps %xmm0,0x1df45(%rip)        # 230c0 <fwp_tape_workspace>
    517b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5180:	48 89 05 21 df 01 00 	mov    %rax,0x1df21(%rip)        # 230a8 <fwp_tape_cached_bytes>
    5187:	0f 29 05 42 df 01 00 	movaps %xmm0,0x1df42(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    518e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5193:	0f 29 05 46 df 01 00 	movaps %xmm0,0x1df46(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    519a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    519e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    51a2:	48 89 15 47 df 01 00 	mov    %rdx,0x1df47(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    51a9:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    51b0:	00 
    51b1:	0f 11 03             	movups %xmm0,(%rbx)
    51b4:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    51b8:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    51bc:	48 83 c4 10          	add    $0x10,%rsp
    51c0:	5b                   	pop    %rbx
    51c1:	c3                   	ret
    51c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    51c8:	48 8d 3d 53 9f 00 00 	lea    0x9f53(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    51cf:	e8 cc e1 ff ff       	call   33a0 <getenv@plt>
    51d4:	48 83 c4 10          	add    $0x10,%rsp
    51d8:	48 89 df             	mov    %rbx,%rdi
    51db:	5b                   	pop    %rbx
    51dc:	e9 2f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    51e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e8:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    51ec:	0f 85 59 ff ff ff    	jne    514b <fwp_tape_buffers_release+0x7b>
    51f2:	48 83 c4 10          	add    $0x10,%rsp
    51f6:	48 89 df             	mov    %rbx,%rdi
    51f9:	5b                   	pop    %rbx
    51fa:	e9 11 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    51ff:	90                   	nop

0000000000005200 <fwp_poll_events>:
    5200:	53                   	push   %rbx
    5201:	48 83 ec 20          	sub    $0x20,%rsp
    5205:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    520c:	00 00 
    520e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5213:	31 c0                	xor    %eax,%eax
    5215:	e8 46 f3 ff ff       	call   4560 <fwp_now_ns>
    521a:	48 8b 1d 77 e5 01 00 	mov    0x1e577(%rip),%rbx        # 23798 <fwp_timers>
    5221:	48 85 db             	test   %rbx,%rbx
    5224:	0f 84 d6 00 00 00    	je     5300 <fwp_poll_events+0x100>
    522a:	48 89 c6             	mov    %rax,%rsi
    522d:	48 89 da             	mov    %rbx,%rdx
    5230:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5237:	eb 16                	jmp    524f <fwp_poll_events+0x4f>
    5239:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5240:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5247:	48 89 c8             	mov    %rcx,%rax
    524a:	48 85 d2             	test   %rdx,%rdx
    524d:	74 31                	je     5280 <fwp_poll_events+0x80>
    524f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5253:	48 85 c0             	test   %rax,%rax
    5256:	78 e8                	js     5240 <fwp_poll_events+0x40>
    5258:	48 39 c1             	cmp    %rax,%rcx
    525b:	7c e3                	jl     5240 <fwp_poll_events+0x40>
    525d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5264:	48 85 d2             	test   %rdx,%rdx
    5267:	74 1c                	je     5285 <fwp_poll_events+0x85>
    5269:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    526d:	48 39 c1             	cmp    %rax,%rcx
    5270:	7c ce                	jl     5240 <fwp_poll_events+0x40>
    5272:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5279:	48 85 d2             	test   %rdx,%rdx
    527c:	75 d1                	jne    524f <fwp_poll_events+0x4f>
    527e:	66 90                	xchg   %ax,%ax
    5280:	48 85 c0             	test   %rax,%rax
    5283:	78 7b                	js     5300 <fwp_poll_events+0x100>
    5285:	48 29 f0             	sub    %rsi,%rax
    5288:	48 89 c1             	mov    %rax,%rcx
    528b:	48 85 c0             	test   %rax,%rax
    528e:	0f 8e 9c 00 00 00    	jle    5330 <fwp_poll_events+0x130>
    5294:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    529b:	de 1b 43 
    529e:	48 f7 ea             	imul   %rdx
    52a1:	48 89 c8             	mov    %rcx,%rax
    52a4:	48 c1 f8 3f          	sar    $0x3f,%rax
    52a8:	48 c1 fa 12          	sar    $0x12,%rdx
    52ac:	48 29 c2             	sub    %rax,%rdx
    52af:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    52b6:	48 39 c1             	cmp    %rax,%rcx
    52b9:	0f 95 c0             	setne  %al
    52bc:	0f b6 c0             	movzbl %al,%eax
    52bf:	48 01 d0             	add    %rdx,%rax
    52c2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    52c8:	0f 8f 32 01 00 00    	jg     5400 <fwp_poll_events+0x200>
    52ce:	48 85 c0             	test   %rax,%rax
    52d1:	74 5d                	je     5330 <fwp_poll_events+0x130>
    52d3:	89 c1                	mov    %eax,%ecx
    52d5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    52dc:	48 c1 e9 26          	shr    $0x26,%rcx
    52e0:	48 63 d1             	movslq %ecx,%rdx
    52e3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    52e9:	29 c8                	sub    %ecx,%eax
    52eb:	48 98                	cltq
    52ed:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    52f4:	e9 11 01 00 00       	jmp    540a <fwp_poll_events+0x20a>
    52f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5300:	e8 6b e9 ff ff       	call   3c70 <fwp_flush>
    5305:	ba 2b 00 00 00       	mov    $0x2b,%edx
    530a:	be 01 00 00 00       	mov    $0x1,%esi
    530f:	48 8b 0d 2a dd 00 00 	mov    0xdd2a(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    5316:	48 8d 3d 1b a5 00 00 	lea    0xa51b(%rip),%rdi        # f838 <_IO_stdin_used+0x838>
    531d:	e8 5e e3 ff ff       	call   3680 <fwrite@plt>
    5322:	bf 65 00 00 00       	mov    $0x65,%edi
    5327:	e8 44 e3 ff ff       	call   3670 <exit@plt>
    532c:	0f 1f 40 00          	nopl   0x0(%rax)
    5330:	e8 2b f2 ff ff       	call   4560 <fwp_now_ns>
    5335:	48 89 c1             	mov    %rax,%rcx
    5338:	66 0f ef c0          	pxor   %xmm0,%xmm0
    533c:	eb 44                	jmp    5382 <fwp_poll_events+0x182>
    533e:	66 90                	xchg   %ax,%ax
    5340:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5344:	75 33                	jne    5379 <fwp_poll_events+0x179>
    5346:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    534a:	75 2d                	jne    5379 <fwp_poll_events+0x179>
    534c:	48 8b 05 4d e4 01 00 	mov    0x1e44d(%rip),%rax        # 237a0 <fwp_ready_tail>
    5353:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5357:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    535e:	00 00 00 00 
    5362:	48 85 c0             	test   %rax,%rax
    5365:	0f 84 05 01 00 00    	je     5470 <fwp_poll_events+0x270>
    536b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5372:	48 89 15 27 e4 01 00 	mov    %rdx,0x1e427(%rip)        # 237a0 <fwp_ready_tail>
    5379:	48 85 db             	test   %rbx,%rbx
    537c:	0f 84 be 00 00 00    	je     5440 <fwp_poll_events+0x240>
    5382:	48 89 da             	mov    %rbx,%rdx
    5385:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    538c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5390:	7f e7                	jg     5379 <fwp_poll_events+0x179>
    5392:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5396:	74 2e                	je     53c6 <fwp_poll_events+0x1c6>
    5398:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    539f:	48 85 c0             	test   %rax,%rax
    53a2:	0f 84 b8 00 00 00    	je     5460 <fwp_poll_events+0x260>
    53a8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    53af:	48 85 db             	test   %rbx,%rbx
    53b2:	74 07                	je     53bb <fwp_poll_events+0x1bb>
    53b4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    53bb:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    53bf:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    53c6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    53ca:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    53ce:	48 85 c0             	test   %rax,%rax
    53d1:	0f 84 69 ff ff ff    	je     5340 <fwp_poll_events+0x140>
    53d7:	48 39 c8             	cmp    %rcx,%rax
    53da:	0f 8f 60 ff ff ff    	jg     5340 <fwp_poll_events+0x140>
    53e0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    53e4:	0f 85 56 ff ff ff    	jne    5340 <fwp_poll_events+0x140>
    53ea:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    53ee:	75 89                	jne    5379 <fwp_poll_events+0x179>
    53f0:	48 89 d7             	mov    %rdx,%rdi
    53f3:	e8 08 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    53f8:	e9 43 ff ff ff       	jmp    5340 <fwp_poll_events+0x140>
    53fd:	0f 1f 00             	nopl   (%rax)
    5400:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5405:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    540a:	48 89 e7             	mov    %rsp,%rdi
    540d:	31 f6                	xor    %esi,%esi
    540f:	48 89 14 24          	mov    %rdx,(%rsp)
    5413:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5418:	e8 83 e0 ff ff       	call   34a0 <nanosleep@plt>
    541d:	48 8b 1d 74 e3 01 00 	mov    0x1e374(%rip),%rbx        # 23798 <fwp_timers>
    5424:	e8 37 f1 ff ff       	call   4560 <fwp_now_ns>
    5429:	48 89 c1             	mov    %rax,%rcx
    542c:	48 85 db             	test   %rbx,%rbx
    542f:	0f 85 03 ff ff ff    	jne    5338 <fwp_poll_events+0x138>
    5435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    543c:	00 00 00 00 
    5440:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5445:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    544c:	00 00 
    544e:	75 2c                	jne    547c <fwp_poll_events+0x27c>
    5450:	48 83 c4 20          	add    $0x20,%rsp
    5454:	5b                   	pop    %rbx
    5455:	c3                   	ret
    5456:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    545d:	00 00 00 
    5460:	48 89 1d 31 e3 01 00 	mov    %rbx,0x1e331(%rip)        # 23798 <fwp_timers>
    5467:	e9 43 ff ff ff       	jmp    53af <fwp_poll_events+0x1af>
    546c:	0f 1f 40 00          	nopl   0x0(%rax)
    5470:	48 89 15 31 e3 01 00 	mov    %rdx,0x1e331(%rip)        # 237a8 <fwp_ready_head>
    5477:	e9 f6 fe ff ff       	jmp    5372 <fwp_poll_events+0x172>
    547c:	e8 df df ff ff       	call   3460 <__stack_chk_fail@plt>
    5481:	0f 1f 40 00          	nopl   0x0(%rax)
    5485:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    548c:	00 00 00 00 

0000000000005490 <fwp_rc_wide_dup>:
    5490:	48 89 fa             	mov    %rdi,%rdx
    5493:	48 8d 35 46 e3 01 00 	lea    0x1e346(%rip),%rsi        # 237e0 <fwp_heap>
    549a:	48 83 ec 18          	sub    $0x18,%rsp
    549e:	48 89 f9             	mov    %rdi,%rcx
    54a1:	48 c1 ea 11          	shr    $0x11,%rdx
    54a5:	48 31 fa             	xor    %rdi,%rdx
    54a8:	48 89 d0             	mov    %rdx,%rax
    54ab:	48 c1 e8 09          	shr    $0x9,%rax
    54af:	48 31 c2             	xor    %rax,%rdx
    54b2:	0f b6 d2             	movzbl %dl,%edx
    54b5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    54bc:	00 
    54bd:	49 8b 00             	mov    (%r8),%rax
    54c0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    54c7:	00 00 
    54c9:	75 21                	jne    54ec <fwp_rc_wide_dup+0x5c>
    54cb:	e9 98 00 00 00       	jmp    5568 <fwp_rc_wide_dup+0xd8>
    54d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    54d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    54dc:	00 00 00 00 
    54e0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    54e4:	48 85 d2             	test   %rdx,%rdx
    54e7:	74 2f                	je     5518 <fwp_rc_wide_dup+0x88>
    54e9:	48 89 d0             	mov    %rdx,%rax
    54ec:	48 3b 08             	cmp    (%rax),%rcx
    54ef:	75 ef                	jne    54e0 <fwp_rc_wide_dup+0x50>
    54f1:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54f4:	74 7c                	je     5572 <fwp_rc_wide_dup+0xe2>
    54f6:	48 8b 50 08          	mov    0x8(%rax),%rdx
    54fa:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    54fe:	0f 84 91 00 00 00    	je     5595 <fwp_rc_wide_dup+0x105>
    5504:	48 83 c2 01          	add    $0x1,%rdx
    5508:	48 89 50 08          	mov    %rdx,0x8(%rax)
    550c:	48 83 c4 18          	add    $0x18,%rsp
    5510:	c3                   	ret
    5511:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5518:	4c 8d 40 10          	lea    0x10(%rax),%r8
    551c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    551f:	75 68                	jne    5589 <fwp_rc_wide_dup+0xf9>
    5521:	bf 18 00 00 00       	mov    $0x18,%edi
    5526:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    552b:	4c 89 04 24          	mov    %r8,(%rsp)
    552f:	e8 7c e0 ff ff       	call   35b0 <malloc@plt>
    5534:	4c 8b 04 24          	mov    (%rsp),%r8
    5538:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    553d:	48 85 c0             	test   %rax,%rax
    5540:	74 5f                	je     55a1 <fwp_rc_wide_dup+0x111>
    5542:	48 89 08             	mov    %rcx,(%rax)
    5545:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    554c:	00 
    554d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5554:	00 
    5555:	49 89 00             	mov    %rax,(%r8)
    5558:	c6 01 ff             	movb   $0xff,(%rcx)
    555b:	48 83 05 c5 fe 01 00 	addq   $0x1,0x1fec5(%rip)        # 25428 <fwp_heap+0x1c48>
    5562:	01 
    5563:	48 83 c4 18          	add    $0x18,%rsp
    5567:	c3                   	ret
    5568:	80 3f fe             	cmpb   $0xfe,(%rdi)
    556b:	75 13                	jne    5580 <fwp_rc_wide_dup+0xf0>
    556d:	48 85 c0             	test   %rax,%rax
    5570:	74 af                	je     5521 <fwp_rc_wide_dup+0x91>
    5572:	48 8d 3d ef a2 00 00 	lea    0xa2ef(%rip),%rdi        # f868 <_IO_stdin_used+0x868>
    5579:	e8 72 ee ff ff       	call   43f0 <fwp_trap>
    557e:	66 90                	xchg   %ax,%ax
    5580:	48 85 c0             	test   %rax,%rax
    5583:	0f 85 6d ff ff ff    	jne    54f6 <fwp_rc_wide_dup+0x66>
    5589:	48 8d 3d 00 a3 00 00 	lea    0xa300(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    5590:	e8 5b ee ff ff       	call   43f0 <fwp_trap>
    5595:	48 8d 3d 97 9b 00 00 	lea    0x9b97(%rip),%rdi        # f133 <_IO_stdin_used+0x133>
    559c:	e8 4f ee ff ff       	call   43f0 <fwp_trap>
    55a1:	e8 0a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    55a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    55ad:	00 00 00 

00000000000055b0 <fwp_rc_forget_slot>:
    55b0:	80 3f ff             	cmpb   $0xff,(%rdi)
    55b3:	74 0b                	je     55c0 <fwp_rc_forget_slot+0x10>
    55b5:	c3                   	ret
    55b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    55bd:	00 00 00 
    55c0:	48 89 f8             	mov    %rdi,%rax
    55c3:	48 83 ec 08          	sub    $0x8,%rsp
    55c7:	48 89 fa             	mov    %rdi,%rdx
    55ca:	48 c1 e8 11          	shr    $0x11,%rax
    55ce:	48 31 f8             	xor    %rdi,%rax
    55d1:	48 89 c1             	mov    %rax,%rcx
    55d4:	48 c1 e9 09          	shr    $0x9,%rcx
    55d8:	48 31 c8             	xor    %rcx,%rax
    55db:	48 8d 0d fe e1 01 00 	lea    0x1e1fe(%rip),%rcx        # 237e0 <fwp_heap>
    55e2:	0f b6 c0             	movzbl %al,%eax
    55e5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    55ec:	00 
    55ed:	48 85 ff             	test   %rdi,%rdi
    55f0:	74 3c                	je     562e <fwp_rc_forget_slot+0x7e>
    55f2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    55f9:	00 
    55fa:	48 8b 01             	mov    (%rcx),%rax
    55fd:	eb 11                	jmp    5610 <fwp_rc_forget_slot+0x60>
    55ff:	90                   	nop
    5600:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5604:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5608:	48 85 ff             	test   %rdi,%rdi
    560b:	74 21                	je     562e <fwp_rc_forget_slot+0x7e>
    560d:	48 89 f8             	mov    %rdi,%rax
    5610:	48 3b 10             	cmp    (%rax),%rdx
    5613:	75 eb                	jne    5600 <fwp_rc_forget_slot+0x50>
    5615:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5619:	48 89 01             	mov    %rax,(%rcx)
    561c:	e8 9f dd ff ff       	call   33c0 <free@plt>
    5621:	48 83 2d ff fd 01 00 	subq   $0x1,0x1fdff(%rip)        # 25428 <fwp_heap+0x1c48>
    5628:	01 
    5629:	48 83 c4 08          	add    $0x8,%rsp
    562d:	c3                   	ret
    562e:	48 8d 3d 5b a2 00 00 	lea    0xa25b(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    5635:	e8 b6 ed ff ff       	call   43f0 <fwp_trap>
    563a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005640 <fwp_rc_prepare_chunk>:
    5640:	48 83 3d e0 fd 01 00 	cmpq   $0x0,0x1fde0(%rip)        # 25428 <fwp_heap+0x1c48>
    5647:	00 
    5648:	41 54                	push   %r12
    564a:	49 89 f4             	mov    %rsi,%r12
    564d:	55                   	push   %rbp
    564e:	48 89 fd             	mov    %rdi,%rbp
    5651:	53                   	push   %rbx
    5652:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5655:	0f 84 7d 00 00 00    	je     56d8 <fwp_rc_prepare_chunk+0x98>
    565b:	31 db                	xor    %ebx,%ebx
    565d:	85 c0                	test   %eax,%eax
    565f:	75 5f                	jne    56c0 <fwp_rc_prepare_chunk+0x80>
    5661:	48 85 f6             	test   %rsi,%rsi
    5664:	74 7c                	je     56e2 <fwp_rc_prepare_chunk+0xa2>
    5666:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    566a:	e8 51 dd ff ff       	call   33c0 <free@plt>
    566f:	90                   	nop
    5670:	be 01 00 00 00       	mov    $0x1,%esi
    5675:	4c 89 e7             	mov    %r12,%rdi
    5678:	e8 a3 de ff ff       	call   3520 <calloc@plt>
    567d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5681:	48 85 c0             	test   %rax,%rax
    5684:	0f 85 87 00 00 00    	jne    5711 <fwp_rc_prepare_chunk+0xd1>
    568a:	e8 21 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    568f:	90                   	nop
    5690:	e8 1b ff ff ff       	call   55b0 <fwp_rc_forget_slot>
    5695:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5698:	48 83 c3 01          	add    $0x1,%rbx
    569c:	48 39 c3             	cmp    %rax,%rbx
    569f:	73 37                	jae    56d8 <fwp_rc_prepare_chunk+0x98>
    56a1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    56a8:	00 00 
    56aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56b1:	00 00 00 00 
    56b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56bc:	00 00 00 00 
    56c0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56c4:	48 01 df             	add    %rbx,%rdi
    56c7:	80 3f ff             	cmpb   $0xff,(%rdi)
    56ca:	74 c4                	je     5690 <fwp_rc_prepare_chunk+0x50>
    56cc:	8b 45 1c             	mov    0x1c(%rbp),%eax
    56cf:	48 83 c3 01          	add    $0x1,%rbx
    56d3:	48 39 c3             	cmp    %rax,%rbx
    56d6:	72 e8                	jb     56c0 <fwp_rc_prepare_chunk+0x80>
    56d8:	49 39 c4             	cmp    %rax,%r12
    56db:	75 13                	jne    56f0 <fwp_rc_prepare_chunk+0xb0>
    56dd:	4d 85 e4             	test   %r12,%r12
    56e0:	75 46                	jne    5728 <fwp_rc_prepare_chunk+0xe8>
    56e2:	5b                   	pop    %rbx
    56e3:	5d                   	pop    %rbp
    56e4:	41 5c                	pop    %r12
    56e6:	c3                   	ret
    56e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    56ee:	00 00 
    56f0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56f4:	48 29 05 35 fd 01 00 	sub    %rax,0x1fd35(%rip)        # 25430 <fwp_heap+0x1c50>
    56fb:	e8 c0 dc ff ff       	call   33c0 <free@plt>
    5700:	4d 85 e4             	test   %r12,%r12
    5703:	0f 85 67 ff ff ff    	jne    5670 <fwp_rc_prepare_chunk+0x30>
    5709:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5710:	00 
    5711:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5715:	5b                   	pop    %rbx
    5716:	4c 01 25 13 fd 01 00 	add    %r12,0x1fd13(%rip)        # 25430 <fwp_heap+0x1c50>
    571d:	5d                   	pop    %rbp
    571e:	41 5c                	pop    %r12
    5720:	c3                   	ret
    5721:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5728:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    572c:	5b                   	pop    %rbx
    572d:	4c 89 e2             	mov    %r12,%rdx
    5730:	31 f6                	xor    %esi,%esi
    5732:	5d                   	pop    %rbp
    5733:	41 5c                	pop    %r12
    5735:	e9 86 dd ff ff       	jmp    34c0 <memset@plt>
    573a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005740 <fwp_heap_refill>:
    5740:	41 56                	push   %r14
    5742:	41 89 d6             	mov    %edx,%r14d
    5745:	41 55                	push   %r13
    5747:	41 89 f5             	mov    %esi,%r13d
    574a:	41 54                	push   %r12
    574c:	49 89 fc             	mov    %rdi,%r12
    574f:	bf 01 00 00 00       	mov    $0x1,%edi
    5754:	55                   	push   %rbp
    5755:	53                   	push   %rbx
    5756:	e8 25 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    575b:	48 89 c3             	mov    %rax,%rbx
    575e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5762:	48 8b 05 6f f4 01 00 	mov    0x1f46f(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    5769:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    576d:	48 8d 05 6c e0 01 00 	lea    0x1e06c(%rip),%rax        # 237e0 <fwp_heap>
    5774:	31 d2                	xor    %edx,%edx
    5776:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    577a:	48 89 ef             	mov    %rbp,%rdi
    577d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5781:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5785:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    578c:	00 
    578d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5792:	f7 f1                	div    %ecx
    5794:	31 d2                	xor    %edx,%edx
    5796:	66 0f 6e c1          	movd   %ecx,%xmm0
    579a:	66 0f 6e c8          	movd   %eax,%xmm1
    579e:	89 c6                	mov    %eax,%esi
    57a0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    57a5:	48 01 c8             	add    %rcx,%rax
    57a8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    57ac:	48 f7 f1             	div    %rcx
    57af:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    57b4:	89 45 18             	mov    %eax,0x18(%rbp)
    57b7:	e8 84 fe ff ff       	call   5640 <fwp_rc_prepare_chunk>
    57bc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    57bf:	48 89 d8             	mov    %rbx,%rax
    57c2:	48 c1 e0 10          	shl    $0x10,%rax
    57c6:	48 03 05 c3 f3 01 00 	add    0x1f3c3(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    57cd:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    57d1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    57d6:	8b 55 08             	mov    0x8(%rbp),%edx
    57d9:	48 0f af d1          	imul   %rcx,%rdx
    57dd:	48 01 c2             	add    %rax,%rdx
    57e0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    57e5:	5b                   	pop    %rbx
    57e6:	5d                   	pop    %rbp
    57e7:	41 5c                	pop    %r12
    57e9:	41 5d                	pop    %r13
    57eb:	41 5e                	pop    %r14
    57ed:	c3                   	ret
    57ee:	66 90                	xchg   %ax,%ax

00000000000057f0 <fwp_mem_free>:
    57f0:	48 85 ff             	test   %rdi,%rdi
    57f3:	0f 84 17 02 00 00    	je     5a10 <fwp_mem_free+0x220>
    57f9:	48 8b 35 90 f3 01 00 	mov    0x1f390(%rip),%rsi        # 24b90 <fwp_heap+0x13b0>
    5800:	48 8b 05 b1 f3 01 00 	mov    0x1f3b1(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    5807:	48 89 fa             	mov    %rdi,%rdx
    580a:	48 29 f2             	sub    %rsi,%rdx
    580d:	48 c1 e0 10          	shl    $0x10,%rax
    5811:	48 39 c2             	cmp    %rax,%rdx
    5814:	0f 83 f6 01 00 00    	jae    5a10 <fwp_mem_free+0x220>
    581a:	49 89 d1             	mov    %rdx,%r9
    581d:	49 c1 e9 10          	shr    $0x10,%r9
    5821:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5825:	48 c1 e0 03          	shl    $0x3,%rax
    5829:	49 89 c0             	mov    %rax,%r8
    582c:	4c 03 05 a5 f3 01 00 	add    0x1f3a5(%rip),%r8        # 24bd8 <fwp_heap+0x13f8>
    5833:	0f 84 d7 01 00 00    	je     5a10 <fwp_mem_free+0x220>
    5839:	48 83 ec 38          	sub    $0x38,%rsp
    583d:	48 89 f9             	mov    %rdi,%rcx
    5840:	41 0f b6 38          	movzbl (%r8),%edi
    5844:	40 80 ff 01          	cmp    $0x1,%dil
    5848:	74 16                	je     5860 <fwp_mem_free+0x70>
    584a:	40 80 ff 02          	cmp    $0x2,%dil
    584e:	0f 84 94 00 00 00    	je     58e8 <fwp_mem_free+0xf8>
    5854:	48 83 c4 38          	add    $0x38,%rsp
    5858:	c3                   	ret
    5859:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5860:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5864:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5869:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    586e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5872:	4d 85 d2             	test   %r10,%r10
    5875:	74 1d                	je     5894 <fwp_mem_free+0xa4>
    5877:	0f b7 c1             	movzwl %cx,%eax
    587a:	31 d2                	xor    %edx,%edx
    587c:	48 f7 f7             	div    %rdi
    587f:	49 01 c2             	add    %rax,%r10
    5882:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5886:	0f 84 44 01 00 00    	je     59d0 <fwp_mem_free+0x1e0>
    588c:	41 c6 02 00          	movb   $0x0,(%r10)
    5890:	41 8b 78 04          	mov    0x4(%r8),%edi
    5894:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    589b:	49 63 c1             	movslq %r9d,%rax
    589e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    58a6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    58ab:	f2 0f 58 05 6d f3 01 	addsd  0x1f36d(%rip),%xmm0        # 24c20 <fwp_heap+0x1440>
    58b2:	00 
    58b3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    58b7:	48 8d 05 22 df 01 00 	lea    0x1df22(%rip),%rax        # 237e0 <fwp_heap>
    58be:	48 01 d0             	add    %rdx,%rax
    58c1:	48 8b 10             	mov    (%rax),%rdx
    58c4:	48 f7 d2             	not    %rdx
    58c7:	48 89 11             	mov    %rdx,(%rcx)
    58ca:	48 89 08             	mov    %rcx,(%rax)
    58cd:	48 29 3d 2c f3 01 00 	sub    %rdi,0x1f32c(%rip)        # 24c00 <fwp_heap+0x1420>
    58d4:	f2 0f 11 05 44 f3 01 	movsd  %xmm0,0x1f344(%rip)        # 24c20 <fwp_heap+0x1440>
    58db:	00 
    58dc:	48 83 c4 38          	add    $0x38,%rsp
    58e0:	c3                   	ret
    58e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    58e8:	66 31 d2             	xor    %dx,%dx
    58eb:	48 01 d6             	add    %rdx,%rsi
    58ee:	48 39 f1             	cmp    %rsi,%rcx
    58f1:	0f 85 5d ff ff ff    	jne    5854 <fwp_mem_free+0x64>
    58f7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    58fb:	48 29 15 fe f2 01 00 	sub    %rdx,0x1f2fe(%rip)        # 24c00 <fwp_heap+0x1420>
    5902:	48 85 d2             	test   %rdx,%rdx
    5905:	0f 88 a5 00 00 00    	js     59b0 <fwp_mem_free+0x1c0>
    590b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    590f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5914:	f2 0f 58 05 04 f3 01 	addsd  0x1f304(%rip),%xmm0        # 24c20 <fwp_heap+0x1440>
    591b:	00 
    591c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5920:	f2 0f 11 05 f8 f2 01 	movsd  %xmm0,0x1f2f8(%rip)        # 24c20 <fwp_heap+0x1440>
    5927:	00 
    5928:	48 85 d2             	test   %rdx,%rdx
    592b:	74 0c                	je     5939 <fwp_mem_free+0x149>
    592d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5930:	0f 84 db 00 00 00    	je     5a11 <fwp_mem_free+0x221>
    5936:	c6 02 00             	movb   $0x0,(%rdx)
    5939:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    593d:	48 85 c9             	test   %rcx,%rcx
    5940:	74 3e                	je     5980 <fwp_mem_free+0x190>
    5942:	48 8b 15 8f f2 01 00 	mov    0x1f28f(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    5949:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    594d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5951:	48 01 d0             	add    %rdx,%rax
    5954:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5958:	48 89 d6             	mov    %rdx,%rsi
    595b:	48 29 c6             	sub    %rax,%rsi
    595e:	83 e6 08             	and    $0x8,%esi
    5961:	74 0d                	je     5970 <fwp_mem_free+0x180>
    5963:	c6 00 00             	movb   $0x0,(%rax)
    5966:	48 83 c0 28          	add    $0x28,%rax
    596a:	48 39 c2             	cmp    %rax,%rdx
    596d:	74 11                	je     5980 <fwp_mem_free+0x190>
    596f:	90                   	nop
    5970:	c6 00 00             	movb   $0x0,(%rax)
    5973:	48 83 c0 50          	add    $0x50,%rax
    5977:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    597b:	48 39 c2             	cmp    %rax,%rdx
    597e:	75 f0                	jne    5970 <fwp_mem_free+0x180>
    5980:	48 01 0d 89 f2 01 00 	add    %rcx,0x1f289(%rip)        # 24c10 <fwp_heap+0x1430>
    5987:	4c 3b 0d 42 f2 01 00 	cmp    0x1f242(%rip),%r9        # 24bd0 <fwp_heap+0x13f0>
    598e:	73 07                	jae    5997 <fwp_mem_free+0x1a7>
    5990:	4c 89 0d 39 f2 01 00 	mov    %r9,0x1f239(%rip)        # 24bd0 <fwp_heap+0x13f0>
    5997:	4c 3b 0d 2a f2 01 00 	cmp    0x1f22a(%rip),%r9        # 24bc8 <fwp_heap+0x13e8>
    599e:	0f 83 b0 fe ff ff    	jae    5854 <fwp_mem_free+0x64>
    59a4:	4c 89 0d 1d f2 01 00 	mov    %r9,0x1f21d(%rip)        # 24bc8 <fwp_heap+0x13e8>
    59ab:	e9 a4 fe ff ff       	jmp    5854 <fwp_mem_free+0x64>
    59b0:	48 89 d1             	mov    %rdx,%rcx
    59b3:	83 e2 01             	and    $0x1,%edx
    59b6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    59ba:	48 d1 e9             	shr    $1,%rcx
    59bd:	48 09 d1             	or     %rdx,%rcx
    59c0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    59c5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    59c9:	e9 46 ff ff ff       	jmp    5914 <fwp_mem_free+0x124>
    59ce:	66 90                	xchg   %ax,%ax
    59d0:	4c 89 d7             	mov    %r10,%rdi
    59d3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    59d8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    59dd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    59e2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    59e6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    59eb:	e8 c0 fb ff ff       	call   55b0 <fwp_rc_forget_slot>
    59f0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    59f5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    59fa:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    59ff:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5a04:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5a09:	e9 7e fe ff ff       	jmp    588c <fwp_mem_free+0x9c>
    5a0e:	66 90                	xchg   %ax,%ax
    5a10:	c3                   	ret
    5a11:	48 89 d7             	mov    %rdx,%rdi
    5a14:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5a19:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5a1e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5a23:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5a28:	e8 83 fb ff ff       	call   55b0 <fwp_rc_forget_slot>
    5a2d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5a32:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5a37:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5a3c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5a41:	e9 f0 fe ff ff       	jmp    5936 <fwp_mem_free+0x146>
    5a46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5a4d:	00 00 00 

0000000000005a50 <fwp_heap_alloc_big>:
    5a50:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5a57:	00 00 40 
    5a5a:	41 57                	push   %r15
    5a5c:	41 56                	push   %r14
    5a5e:	41 55                	push   %r13
    5a60:	41 54                	push   %r12
    5a62:	55                   	push   %rbp
    5a63:	53                   	push   %rbx
    5a64:	48 83 ec 08          	sub    $0x8,%rsp
    5a68:	48 39 f8             	cmp    %rdi,%rax
    5a6b:	0f 82 fa 00 00 00    	jb     5b6b <fwp_heap_alloc_big+0x11b>
    5a71:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a78:	49 89 fd             	mov    %rdi,%r13
    5a7b:	41 89 f6             	mov    %esi,%r14d
    5a7e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a82:	48 89 ef             	mov    %rbp,%rdi
    5a85:	e8 f6 e4 ff ff       	call   3f80 <fwp_heap_chunks>
    5a8a:	be 01 00 00 00       	mov    $0x1,%esi
    5a8f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a93:	49 89 c4             	mov    %rax,%r12
    5a96:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a9d:	00 
    5a9e:	48 03 3d 33 f1 01 00 	add    0x1f133(%rip),%rdi        # 24bd8 <fwp_heap+0x13f8>
    5aa5:	c6 07 02             	movb   $0x2,(%rdi)
    5aa8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5aac:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5aaf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5ab3:	e8 88 fb ff ff       	call   5640 <fwp_rc_prepare_chunk>
    5ab8:	48 83 fd 01          	cmp    $0x1,%rbp
    5abc:	76 47                	jbe    5b05 <fwp_heap_alloc_big+0xb5>
    5abe:	4c 01 e5             	add    %r12,%rbp
    5ac1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ac8:	00 
    5ac9:	4c 8d 3d 10 dd 01 00 	lea    0x1dd10(%rip),%r15        # 237e0 <fwp_heap>
    5ad0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5ad5:	49 c1 e6 03          	shl    $0x3,%r14
    5ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ae0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5ae7:	31 f6                	xor    %esi,%esi
    5ae9:	48 01 dd             	add    %rbx,%rbp
    5aec:	48 83 c3 28          	add    $0x28,%rbx
    5af0:	48 89 ef             	mov    %rbp,%rdi
    5af3:	e8 48 fb ff ff       	call   5640 <fwp_rc_prepare_chunk>
    5af8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5afc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5b00:	49 39 de             	cmp    %rbx,%r14
    5b03:	75 db                	jne    5ae0 <fwp_heap_alloc_big+0x90>
    5b05:	49 c1 e4 10          	shl    $0x10,%r12
    5b09:	4c 03 25 80 f0 01 00 	add    0x1f080(%rip),%r12        # 24b90 <fwp_heap+0x13b0>
    5b10:	4c 89 ea             	mov    %r13,%rdx
    5b13:	31 f6                	xor    %esi,%esi
    5b15:	4c 89 e7             	mov    %r12,%rdi
    5b18:	e8 a3 d9 ff ff       	call   34c0 <memset@plt>
    5b1d:	4c 89 e8             	mov    %r13,%rax
    5b20:	48 03 05 d9 f0 01 00 	add    0x1f0d9(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    5b27:	72 42                	jb     5b6b <fwp_heap_alloc_big+0x11b>
    5b29:	48 39 05 d8 f0 01 00 	cmp    %rax,0x1f0d8(%rip)        # 24c08 <fwp_heap+0x1428>
    5b30:	48 89 05 c9 f0 01 00 	mov    %rax,0x1f0c9(%rip)        # 24c00 <fwp_heap+0x1420>
    5b37:	73 07                	jae    5b40 <fwp_heap_alloc_big+0xf0>
    5b39:	48 89 05 c8 f0 01 00 	mov    %rax,0x1f0c8(%rip)        # 24c08 <fwp_heap+0x1428>
    5b40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b44:	4c 89 e0             	mov    %r12,%rax
    5b47:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5b4c:	f2 0f 58 05 c4 f0 01 	addsd  0x1f0c4(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    5b53:	00 
    5b54:	f2 0f 11 05 bc f0 01 	movsd  %xmm0,0x1f0bc(%rip)        # 24c18 <fwp_heap+0x1438>
    5b5b:	00 
    5b5c:	48 83 c4 08          	add    $0x8,%rsp
    5b60:	5b                   	pop    %rbx
    5b61:	5d                   	pop    %rbp
    5b62:	41 5c                	pop    %r12
    5b64:	41 5d                	pop    %r13
    5b66:	41 5e                	pop    %r14
    5b68:	41 5f                	pop    %r15
    5b6a:	c3                   	ret
    5b6b:	e8 40 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b70 <fwp_heap_alloc_slow>:
    5b70:	53                   	push   %rbx
    5b71:	48 89 f9             	mov    %rdi,%rcx
    5b74:	41 89 f1             	mov    %esi,%r9d
    5b77:	48 83 ec 10          	sub    $0x10,%rsp
    5b7b:	8b 05 03 f0 01 00    	mov    0x1f003(%rip),%eax        # 24b84 <fwp_heap+0x13a4>
    5b81:	85 c0                	test   %eax,%eax
    5b83:	0f 84 c7 00 00 00    	je     5c50 <fwp_heap_alloc_slow+0xe0>
    5b89:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b90:	0f 87 dd 00 00 00    	ja     5c73 <fwp_heap_alloc_slow+0x103>
    5b96:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b9a:	48 8d 3d 3f dc 01 00 	lea    0x1dc3f(%rip),%rdi        # 237e0 <fwp_heap>
    5ba1:	49 63 f1             	movslq %r9d,%rsi
    5ba4:	48 c1 e8 04          	shr    $0x4,%rax
    5ba8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5baf:	00 00 
    5bb1:	41 0f b6 c2          	movzbl %r10b,%eax
    5bb5:	4c 89 d2             	mov    %r10,%rdx
    5bb8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5bbc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5bc3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5bca:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5bce:	48 01 f8             	add    %rdi,%rax
    5bd1:	4c 8b 00             	mov    (%rax),%r8
    5bd4:	4d 85 c0             	test   %r8,%r8
    5bd7:	0f 84 ab 00 00 00    	je     5c88 <fwp_heap_alloc_slow+0x118>
    5bdd:	49 8b 10             	mov    (%r8),%rdx
    5be0:	48 f7 d2             	not    %rdx
    5be3:	48 89 10             	mov    %rdx,(%rax)
    5be6:	41 83 f9 01          	cmp    $0x1,%r9d
    5bea:	4c 89 c7             	mov    %r8,%rdi
    5bed:	48 0f 45 cb          	cmovne %rbx,%rcx
    5bf1:	31 f6                	xor    %esi,%esi
    5bf3:	48 89 ca             	mov    %rcx,%rdx
    5bf6:	e8 c5 d8 ff ff       	call   34c0 <memset@plt>
    5bfb:	49 89 c0             	mov    %rax,%r8
    5bfe:	48 89 d8             	mov    %rbx,%rax
    5c01:	48 03 05 f8 ef 01 00 	add    0x1eff8(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    5c08:	0f 82 d9 00 00 00    	jb     5ce7 <fwp_heap_alloc_slow+0x177>
    5c0e:	48 39 05 f3 ef 01 00 	cmp    %rax,0x1eff3(%rip)        # 24c08 <fwp_heap+0x1428>
    5c15:	48 89 05 e4 ef 01 00 	mov    %rax,0x1efe4(%rip)        # 24c00 <fwp_heap+0x1420>
    5c1c:	73 07                	jae    5c25 <fwp_heap_alloc_slow+0xb5>
    5c1e:	48 89 05 e3 ef 01 00 	mov    %rax,0x1efe3(%rip)        # 24c08 <fwp_heap+0x1428>
    5c25:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c29:	4c 89 c0             	mov    %r8,%rax
    5c2c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5c31:	f2 0f 58 05 df ef 01 	addsd  0x1efdf(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    5c38:	00 
    5c39:	f2 0f 11 05 d7 ef 01 	movsd  %xmm0,0x1efd7(%rip)        # 24c18 <fwp_heap+0x1438>
    5c40:	00 
    5c41:	48 83 c4 10          	add    $0x10,%rsp
    5c45:	5b                   	pop    %rbx
    5c46:	c3                   	ret
    5c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5c4e:	00 00 
    5c50:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5c54:	48 89 3c 24          	mov    %rdi,(%rsp)
    5c58:	e8 13 f1 ff ff       	call   4d70 <fwp_heap_init>
    5c5d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c61:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c66:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c6d:	0f 86 23 ff ff ff    	jbe    5b96 <fwp_heap_alloc_slow+0x26>
    5c73:	48 83 c4 10          	add    $0x10,%rsp
    5c77:	44 89 ce             	mov    %r9d,%esi
    5c7a:	48 89 cf             	mov    %rcx,%rdi
    5c7d:	5b                   	pop    %rbx
    5c7e:	e9 cd fd ff ff       	jmp    5a50 <fwp_heap_alloc_big>
    5c83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c88:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c8c:	4d 85 c0             	test   %r8,%r8
    5c8f:	74 1f                	je     5cb0 <fwp_heap_alloc_slow+0x140>
    5c91:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c95:	4d 29 c3             	sub    %r8,%r11
    5c98:	49 39 db             	cmp    %rbx,%r11
    5c9b:	72 13                	jb     5cb0 <fwp_heap_alloc_slow+0x140>
    5c9d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ca1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ca5:	e9 3c ff ff ff       	jmp    5be6 <fwp_heap_alloc_slow+0x76>
    5caa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5cb0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5cb7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5cbb:	44 89 ca             	mov    %r9d,%edx
    5cbe:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5cc3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5cc7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5ccb:	44 89 d6             	mov    %r10d,%esi
    5cce:	48 01 c7             	add    %rax,%rdi
    5cd1:	e8 6a fa ff ff       	call   5740 <fwp_heap_refill>
    5cd6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5cdb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5cdf:	49 89 c0             	mov    %rax,%r8
    5ce2:	e9 ff fe ff ff       	jmp    5be6 <fwp_heap_alloc_slow+0x76>
    5ce7:	e8 c4 df ff ff       	call   3cb0 <fwp_heap_oom>
    5cec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005cf0 <fwp_heap_alloc>:
    5cf0:	8b 05 8e ee 01 00    	mov    0x1ee8e(%rip),%eax        # 24b84 <fwp_heap+0x13a4>
    5cf6:	48 89 fa             	mov    %rdi,%rdx
    5cf9:	89 f7                	mov    %esi,%edi
    5cfb:	85 c0                	test   %eax,%eax
    5cfd:	0f 84 f5 00 00 00    	je     5df8 <fwp_heap_alloc+0x108>
    5d03:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5d0a:	0f 87 e8 00 00 00    	ja     5df8 <fwp_heap_alloc+0x108>
    5d10:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5d14:	48 8d 05 c5 da 01 00 	lea    0x1dac5(%rip),%rax        # 237e0 <fwp_heap>
    5d1b:	48 83 ec 18          	sub    $0x18,%rsp
    5d1f:	41 89 f0             	mov    %esi,%r8d
    5d22:	48 c1 e9 04          	shr    $0x4,%rcx
    5d26:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5d2d:	00 
    5d2e:	48 63 cf             	movslq %edi,%rcx
    5d31:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5d38:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5d3f:	00 
    5d40:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5d44:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5d48:	48 01 c8             	add    %rcx,%rax
    5d4b:	48 8b 08             	mov    (%rax),%rcx
    5d4e:	48 85 c9             	test   %rcx,%rcx
    5d51:	74 6d                	je     5dc0 <fwp_heap_alloc+0xd0>
    5d53:	48 8b 31             	mov    (%rcx),%rsi
    5d56:	48 f7 d6             	not    %rsi
    5d59:	48 89 30             	mov    %rsi,(%rax)
    5d5c:	41 83 f8 01          	cmp    $0x1,%r8d
    5d60:	48 89 cf             	mov    %rcx,%rdi
    5d63:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d68:	49 0f 45 d1          	cmovne %r9,%rdx
    5d6c:	31 f6                	xor    %esi,%esi
    5d6e:	e8 4d d7 ff ff       	call   34c0 <memset@plt>
    5d73:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d78:	48 89 c1             	mov    %rax,%rcx
    5d7b:	4c 89 c8             	mov    %r9,%rax
    5d7e:	48 03 05 7b ee 01 00 	add    0x1ee7b(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    5d85:	72 7b                	jb     5e02 <fwp_heap_alloc+0x112>
    5d87:	48 39 05 7a ee 01 00 	cmp    %rax,0x1ee7a(%rip)        # 24c08 <fwp_heap+0x1428>
    5d8e:	48 89 05 6b ee 01 00 	mov    %rax,0x1ee6b(%rip)        # 24c00 <fwp_heap+0x1420>
    5d95:	73 07                	jae    5d9e <fwp_heap_alloc+0xae>
    5d97:	48 89 05 6a ee 01 00 	mov    %rax,0x1ee6a(%rip)        # 24c08 <fwp_heap+0x1428>
    5d9e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5da2:	48 89 c8             	mov    %rcx,%rax
    5da5:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5daa:	f2 0f 58 05 66 ee 01 	addsd  0x1ee66(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    5db1:	00 
    5db2:	f2 0f 11 05 5e ee 01 	movsd  %xmm0,0x1ee5e(%rip)        # 24c18 <fwp_heap+0x1438>
    5db9:	00 
    5dba:	48 83 c4 18          	add    $0x18,%rsp
    5dbe:	c3                   	ret
    5dbf:	90                   	nop
    5dc0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5dc4:	48 85 c9             	test   %rcx,%rcx
    5dc7:	74 0c                	je     5dd5 <fwp_heap_alloc+0xe5>
    5dc9:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5dcd:	48 29 ce             	sub    %rcx,%rsi
    5dd0:	4c 39 ce             	cmp    %r9,%rsi
    5dd3:	73 13                	jae    5de8 <fwp_heap_alloc+0xf8>
    5dd5:	89 fe                	mov    %edi,%esi
    5dd7:	48 83 c4 18          	add    $0x18,%rsp
    5ddb:	48 89 d7             	mov    %rdx,%rdi
    5dde:	e9 8d fd ff ff       	jmp    5b70 <fwp_heap_alloc_slow>
    5de3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5de8:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5dec:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5df0:	e9 67 ff ff ff       	jmp    5d5c <fwp_heap_alloc+0x6c>
    5df5:	0f 1f 00             	nopl   (%rax)
    5df8:	89 fe                	mov    %edi,%esi
    5dfa:	48 89 d7             	mov    %rdx,%rdi
    5dfd:	e9 6e fd ff ff       	jmp    5b70 <fwp_heap_alloc_slow>
    5e02:	e8 a9 de ff ff       	call   3cb0 <fwp_heap_oom>
    5e07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e0e:	00 00 

0000000000005e10 <fwp_data.part.0.constprop.0>:
    5e10:	41 56                	push   %r14
    5e12:	41 89 fe             	mov    %edi,%r14d
    5e15:	41 54                	push   %r12
    5e17:	49 89 f4             	mov    %rsi,%r12
    5e1a:	55                   	push   %rbp
    5e1b:	53                   	push   %rbx
    5e1c:	48 83 ec 08          	sub    $0x8,%rsp
    5e20:	8b 05 5e ed 01 00    	mov    0x1ed5e(%rip),%eax        # 24b84 <fwp_heap+0x13a4>
    5e26:	85 c0                	test   %eax,%eax
    5e28:	0f 84 fa 00 00 00    	je     5f28 <fwp_data.part.0.constprop.0+0x118>
    5e2e:	0f b6 05 4d e9 01 00 	movzbl 0x1e94d(%rip),%eax        # 24782 <fwp_heap+0xfa2>
    5e35:	48 8d 15 a4 d9 01 00 	lea    0x1d9a4(%rip),%rdx        # 237e0 <fwp_heap>
    5e3c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5e43:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5e47:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5e4b:	48 8b 18             	mov    (%rax),%rbx
    5e4e:	48 85 db             	test   %rbx,%rbx
    5e51:	0f 84 a9 00 00 00    	je     5f00 <fwp_data.part.0.constprop.0+0xf0>
    5e57:	48 8b 13             	mov    (%rbx),%rdx
    5e5a:	48 f7 d2             	not    %rdx
    5e5d:	48 89 10             	mov    %rdx,(%rax)
    5e60:	48 83 fd 18          	cmp    $0x18,%rbp
    5e64:	76 1b                	jbe    5e81 <fwp_data.part.0.constprop.0+0x71>
    5e66:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5e6a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5e6e:	31 f6                	xor    %esi,%esi
    5e70:	48 c1 e8 03          	shr    $0x3,%rax
    5e74:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5e7b:	00 
    5e7c:	e8 3f d6 ff ff       	call   34c0 <memset@plt>
    5e81:	48 89 e8             	mov    %rbp,%rax
    5e84:	48 03 05 75 ed 01 00 	add    0x1ed75(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    5e8b:	0f 82 a8 00 00 00    	jb     5f39 <fwp_data.part.0.constprop.0+0x129>
    5e91:	48 39 05 70 ed 01 00 	cmp    %rax,0x1ed70(%rip)        # 24c08 <fwp_heap+0x1428>
    5e98:	48 89 05 61 ed 01 00 	mov    %rax,0x1ed61(%rip)        # 24c00 <fwp_heap+0x1420>
    5e9f:	73 07                	jae    5ea8 <fwp_data.part.0.constprop.0+0x98>
    5ea1:	48 89 05 60 ed 01 00 	mov    %rax,0x1ed60(%rip)        # 24c08 <fwp_heap+0x1428>
    5ea8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5eac:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5eb1:	f2 0f 58 05 5f ed 01 	addsd  0x1ed5f(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    5eb8:	00 
    5eb9:	f2 0f 11 05 57 ed 01 	movsd  %xmm0,0x1ed57(%rip)        # 24c18 <fwp_heap+0x1438>
    5ec0:	00 
    5ec1:	b8 02 00 00 00       	mov    $0x2,%eax
    5ec6:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5ecb:	66 0f 6e c8          	movd   %eax,%xmm1
    5ecf:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5ed3:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5ed7:	49 8b 04 24          	mov    (%r12),%rax
    5edb:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5edf:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5ee4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5ee8:	48 83 c4 08          	add    $0x8,%rsp
    5eec:	48 89 d8             	mov    %rbx,%rax
    5eef:	5b                   	pop    %rbx
    5ef0:	5d                   	pop    %rbp
    5ef1:	41 5c                	pop    %r12
    5ef3:	41 5e                	pop    %r14
    5ef5:	c3                   	ret
    5ef6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5efd:	00 00 00 
    5f00:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5f04:	48 85 db             	test   %rbx,%rbx
    5f07:	74 1f                	je     5f28 <fwp_data.part.0.constprop.0+0x118>
    5f09:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5f0d:	48 29 da             	sub    %rbx,%rdx
    5f10:	48 39 ea             	cmp    %rbp,%rdx
    5f13:	72 13                	jb     5f28 <fwp_data.part.0.constprop.0+0x118>
    5f15:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5f19:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5f1d:	e9 3e ff ff ff       	jmp    5e60 <fwp_data.part.0.constprop.0+0x50>
    5f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5f28:	31 f6                	xor    %esi,%esi
    5f2a:	bf 18 00 00 00       	mov    $0x18,%edi
    5f2f:	e8 bc fd ff ff       	call   5cf0 <fwp_heap_alloc>
    5f34:	48 89 c3             	mov    %rax,%rbx
    5f37:	eb 88                	jmp    5ec1 <fwp_data.part.0.constprop.0+0xb1>
    5f39:	e8 72 dd ff ff       	call   3cb0 <fwp_heap_oom>
    5f3e:	66 90                	xchg   %ax,%ax

0000000000005f40 <fwp_p_ad_push>:
    5f40:	41 57                	push   %r15
    5f42:	41 56                	push   %r14
    5f44:	41 55                	push   %r13
    5f46:	49 89 d5             	mov    %rdx,%r13
    5f49:	41 54                	push   %r12
    5f4b:	49 89 fc             	mov    %rdi,%r12
    5f4e:	55                   	push   %rbp
    5f4f:	53                   	push   %rbx
    5f50:	48 83 ec 38          	sub    $0x38,%rsp
    5f54:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5f59:	48 85 ff             	test   %rdi,%rdi
    5f5c:	79 09                	jns    5f67 <fwp_p_ad_push+0x27>
    5f5e:	48 85 d2             	test   %rdx,%rdx
    5f61:	0f 88 a9 01 00 00    	js     6110 <fwp_p_ad_push+0x1d0>
    5f67:	48 89 f8             	mov    %rdi,%rax
    5f6a:	48 89 0c 24          	mov    %rcx,(%rsp)
    5f6e:	48 09 d0             	or     %rdx,%rax
    5f71:	0f 89 79 01 00 00    	jns    60f0 <fwp_p_ad_push+0x1b0>
    5f77:	48 89 f8             	mov    %rdi,%rax
    5f7a:	48 c1 f8 20          	sar    $0x20,%rax
    5f7e:	48 85 ff             	test   %rdi,%rdi
    5f81:	79 24                	jns    5fa7 <fwp_p_ad_push+0x67>
    5f83:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5f88:	48 89 d0             	mov    %rdx,%rax
    5f8b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5f92:	00 
    5f93:	49 89 d4             	mov    %rdx,%r12
    5f96:	48 c1 f8 20          	sar    $0x20,%rax
    5f9a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5fa1:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5fa7:	48 89 c7             	mov    %rax,%rdi
    5faa:	e8 21 e7 ff ff       	call   46d0 <fwp_tape_of>
    5faf:	48 89 c3             	mov    %rax,%rbx
    5fb2:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5fb7:	0f 85 76 02 00 00    	jne    6233 <fwp_p_ad_push+0x2f3>
    5fbd:	4c 8b 78 10          	mov    0x10(%rax),%r15
    5fc1:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    5fc8:	0f 8f 59 02 00 00    	jg     6227 <fwp_p_ad_push+0x2e7>
    5fce:	44 89 e0             	mov    %r12d,%eax
    5fd1:	4c 39 f8             	cmp    %r15,%rax
    5fd4:	0f 8d 41 02 00 00    	jge    621b <fwp_p_ad_push+0x2db>
    5fda:	4d 85 ed             	test   %r13,%r13
    5fdd:	78 0c                	js     5feb <fwp_p_ad_push+0xab>
    5fdf:	44 89 e8             	mov    %r13d,%eax
    5fe2:	4c 39 f8             	cmp    %r15,%rax
    5fe5:	0f 8d 30 02 00 00    	jge    621b <fwp_p_ad_push+0x2db>
    5feb:	4d 89 fe             	mov    %r15,%r14
    5fee:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5ff2:	49 8d 46 01          	lea    0x1(%r14),%rax
    5ff6:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5ffc:	0f 87 25 02 00 00    	ja     6227 <fwp_p_ad_push+0x2e7>
    6002:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    6006:	48 39 e8             	cmp    %rbp,%rax
    6009:	0f 8e 31 01 00 00    	jle    6140 <fwp_p_ad_push+0x200>
    600f:	48 85 ed             	test   %rbp,%rbp
    6012:	b9 40 00 00 00       	mov    $0x40,%ecx
    6017:	48 0f 44 e9          	cmove  %rcx,%rbp
    601b:	48 39 e8             	cmp    %rbp,%rax
    601e:	7e 20                	jle    6040 <fwp_p_ad_push+0x100>
    6020:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    6027:	0f 8f 03 01 00 00    	jg     6130 <fwp_p_ad_push+0x1f0>
    602d:	48 01 ed             	add    %rbp,%rbp
    6030:	48 39 e8             	cmp    %rbp,%rax
    6033:	7f eb                	jg     6020 <fwp_p_ad_push+0xe0>
    6035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    603c:	00 00 00 00 
    6040:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6047:	00 
    6048:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    604c:	48 89 c6             	mov    %rax,%rsi
    604f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6054:	e8 77 d5 ff ff       	call   35d0 <realloc@plt>
    6059:	48 85 c0             	test   %rax,%rax
    605c:	0f 84 dd 01 00 00    	je     623f <fwp_p_ad_push+0x2ff>
    6062:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    6066:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    606a:	48 89 43 20          	mov    %rax,0x20(%rbx)
    606e:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    6072:	48 89 e9             	mov    %rbp,%rcx
    6075:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6079:	48 c1 e1 04          	shl    $0x4,%rcx
    607d:	48 89 ce             	mov    %rcx,%rsi
    6080:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6085:	e8 46 d5 ff ff       	call   35d0 <realloc@plt>
    608a:	48 85 c0             	test   %rax,%rax
    608d:	0f 84 ac 01 00 00    	je     623f <fwp_p_ad_push+0x2ff>
    6093:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    6097:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    609c:	4d 85 f6             	test   %r14,%r14
    609f:	48 89 43 30          	mov    %rax,0x30(%rbx)
    60a3:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    60a8:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    60af:	00 
    60b0:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    60b7:	00 
    60b8:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    60bc:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    60c3:	00 
    60c4:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    60c8:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    60cc:	0f 85 e2 00 00 00    	jne    61b4 <fwp_p_ad_push+0x274>
    60d2:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    60d6:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    60da:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    60de:	49 01 c8             	add    %rcx,%r8
    60e1:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    60e5:	eb 79                	jmp    6160 <fwp_p_ad_push+0x220>
    60e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    60ee:	00 00 
    60f0:	48 89 d0             	mov    %rdx,%rax
    60f3:	48 c1 ff 20          	sar    $0x20,%rdi
    60f7:	48 c1 f8 20          	sar    $0x20,%rax
    60fb:	48 39 c7             	cmp    %rax,%rdi
    60fe:	0f 84 a3 fe ff ff    	je     5fa7 <fwp_p_ad_push+0x67>
    6104:	48 8d 3d ad 97 00 00 	lea    0x97ad(%rip),%rdi        # f8b8 <_IO_stdin_used+0x8b8>
    610b:	e8 e0 e2 ff ff       	call   43f0 <fwp_trap>
    6110:	48 83 c4 38          	add    $0x38,%rsp
    6114:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    611b:	5b                   	pop    %rbx
    611c:	5d                   	pop    %rbp
    611d:	41 5c                	pop    %r12
    611f:	41 5d                	pop    %r13
    6121:	41 5e                	pop    %r14
    6123:	41 5f                	pop    %r15
    6125:	c3                   	ret
    6126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    612d:	00 00 00 
    6130:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    6135:	e9 06 ff ff ff       	jmp    6040 <fwp_p_ad_push+0x100>
    613a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6140:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    6144:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6148:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    614f:	00 
    6150:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6157:	00 
    6158:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    615c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6160:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6166:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    616a:	4d 85 ed             	test   %r13,%r13
    616d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6172:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6178:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    617f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6183:	49 8d 47 01          	lea    0x1(%r15),%rax
    6187:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    618b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6191:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6195:	48 83 c4 38          	add    $0x38,%rsp
    6199:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    61a0:	ff ff ff 
    61a3:	4c 21 e0             	and    %r12,%rax
    61a6:	5b                   	pop    %rbx
    61a7:	5d                   	pop    %rbp
    61a8:	4c 09 f8             	or     %r15,%rax
    61ab:	41 5c                	pop    %r12
    61ad:	41 5d                	pop    %r13
    61af:	41 5e                	pop    %r14
    61b1:	41 5f                	pop    %r15
    61b3:	c3                   	ret
    61b4:	48 39 ca             	cmp    %rcx,%rdx
    61b7:	49 89 d6             	mov    %rdx,%r14
    61ba:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    61bf:	48 0f 43 ca          	cmovae %rdx,%rcx
    61c3:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    61c8:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    61cd:	48 29 d1             	sub    %rdx,%rcx
    61d0:	4c 89 ca             	mov    %r9,%rdx
    61d3:	e8 88 d3 ff ff       	call   3560 <__memmove_chk@plt>
    61d8:	4c 03 73 30          	add    0x30(%rbx),%r14
    61dc:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    61e1:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    61e5:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    61ea:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    61ee:	48 03 7b 20          	add    0x20(%rbx),%rdi
    61f2:	4c 89 d2             	mov    %r10,%rdx
    61f5:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    61fa:	e8 11 d4 ff ff       	call   3610 <memmove@plt>
    61ff:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6203:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6207:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    620c:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    6211:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    6216:	e9 bb fe ff ff       	jmp    60d6 <fwp_p_ad_push+0x196>
    621b:	48 8d 3d 45 8f 00 00 	lea    0x8f45(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    6222:	e8 c9 e1 ff ff       	call   43f0 <fwp_trap>
    6227:	48 8d 3d 1e 8f 00 00 	lea    0x8f1e(%rip),%rdi        # f14c <_IO_stdin_used+0x14c>
    622e:	e8 bd e1 ff ff       	call   43f0 <fwp_trap>
    6233:	48 8d 3d c6 96 00 00 	lea    0x96c6(%rip),%rdi        # f900 <_IO_stdin_used+0x900>
    623a:	e8 b1 e1 ff ff       	call   43f0 <fwp_trap>
    623f:	48 89 df             	mov    %rbx,%rdi
    6242:	e8 b9 d9 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6247:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    624b:	e8 70 d1 ff ff       	call   33c0 <free@plt>
    6250:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6254:	e8 67 d1 ff ff       	call   33c0 <free@plt>
    6259:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    625d:	e8 5e d1 ff ff       	call   33c0 <free@plt>
    6262:	31 c9                	xor    %ecx,%ecx
    6264:	31 c0                	xor    %eax,%eax
    6266:	31 d2                	xor    %edx,%edx
    6268:	89 53 04             	mov    %edx,0x4(%rbx)
    626b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    626f:	ba 13 00 00 00       	mov    $0x13,%edx
    6274:	be 01 00 00 00       	mov    $0x1,%esi
    6279:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    627d:	48 8d 3d 84 8d 00 00 	lea    0x8d84(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    6284:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6288:	48 8b 0d b1 cd 00 00 	mov    0xcdb1(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    628f:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6293:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    6297:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    629b:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    629f:	e8 dc d3 ff ff       	call   3680 <fwrite@plt>
    62a4:	31 ff                	xor    %edi,%edi
    62a6:	e8 15 d3 ff ff       	call   35c0 <fflush@plt>
    62ab:	bf 66 00 00 00       	mov    $0x66,%edi
    62b0:	e8 eb d3 ff ff       	call   36a0 <_Exit@plt>
    62b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62bc:	00 00 00 00 

00000000000062c0 <w120>:
    62c0:	66 0f 28 e0          	movapd %xmm0,%xmm4
    62c4:	41 55                	push   %r13
    62c6:	48 89 fa             	mov    %rdi,%rdx
    62c9:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    62cd:	41 54                	push   %r12
    62cf:	49 89 fc             	mov    %rdi,%r12
    62d2:	55                   	push   %rbp
    62d3:	53                   	push   %rbx
    62d4:	48 89 f3             	mov    %rsi,%rbx
    62d7:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    62dc:	48 89 f1             	mov    %rsi,%rcx
    62df:	48 83 ec 28          	sub    $0x28,%rsp
    62e3:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    62e9:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    62ef:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    62f5:	e8 46 fc ff ff       	call   5f40 <fwp_p_ad_push>
    62fa:	48 89 c7             	mov    %rax,%rdi
    62fd:	e8 5e ec ff ff       	call   4f60 <caf75>
    6302:	66 48 0f 6e c0       	movq   %rax,%xmm0
    6307:	e8 54 ec ff ff       	call   4f60 <caf75>
    630c:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6312:	66 0f 57 05 06 99 00 	xorpd  0x9906(%rip),%xmm0        # fc20 <msg.8+0xb0>
    6319:	00 
    631a:	48 89 da             	mov    %rbx,%rdx
    631d:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6323:	48 89 c1             	mov    %rax,%rcx
    6326:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    632b:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6330:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6336:	e8 05 fc ff ff       	call   5f40 <fwp_p_ad_push>
    633b:	4c 89 e7             	mov    %r12,%rdi
    633e:	49 89 c5             	mov    %rax,%r13
    6341:	e8 1a ec ff ff       	call   4f60 <caf75>
    6346:	48 89 c6             	mov    %rax,%rsi
    6349:	e8 12 ec ff ff       	call   4f60 <caf75>
    634e:	66 48 0f 6e d6       	movq   %rsi,%xmm2
    6353:	f2 0f 10 05 3d 98 00 	movsd  0x983d(%rip),%xmm0        # fb98 <msg.8+0x28>
    635a:	00 
    635b:	66 0f 57 15 bd 98 00 	xorpd  0x98bd(%rip),%xmm2        # fc20 <msg.8+0xb0>
    6362:	00 
    6363:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    6369:	48 89 c1             	mov    %rax,%rcx
    636c:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6373:	66 48 0f 7e d6       	movq   %xmm2,%rsi
    6378:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    637d:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6383:	e8 b8 fb ff ff       	call   5f40 <fwp_p_ad_push>
    6388:	48 89 e9             	mov    %rbp,%rcx
    638b:	4c 89 ea             	mov    %r13,%rdx
    638e:	48 89 ee             	mov    %rbp,%rsi
    6391:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6397:	4c 89 ef             	mov    %r13,%rdi
    639a:	49 89 c4             	mov    %rax,%r12
    639d:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    63a1:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    63a7:	e8 94 fb ff ff       	call   5f40 <fwp_p_ad_push>
    63ac:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    63b2:	f2 0f 59 1d e6 97 00 	mulsd  0x97e6(%rip),%xmm3        # fba0 <msg.8+0x30>
    63b9:	00 
    63ba:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    63c1:	00 59 40 
    63c4:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    63c9:	48 89 c2             	mov    %rax,%rdx
    63cc:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    63d3:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    63d9:	e8 62 fb ff ff       	call   5f40 <fwp_p_ad_push>
    63de:	4c 89 e2             	mov    %r12,%rdx
    63e1:	48 89 d9             	mov    %rbx,%rcx
    63e4:	48 89 de             	mov    %rbx,%rsi
    63e7:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    63ed:	4c 89 e7             	mov    %r12,%rdi
    63f0:	48 89 c5             	mov    %rax,%rbp
    63f3:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    63f7:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    63fd:	e8 3e fb ff ff       	call   5f40 <fwp_p_ad_push>
    6402:	48 89 c7             	mov    %rax,%rdi
    6405:	e8 56 eb ff ff       	call   4f60 <caf75>
    640a:	48 89 c6             	mov    %rax,%rsi
    640d:	e8 4e eb ff ff       	call   4f60 <caf75>
    6412:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6418:	48 89 ea             	mov    %rbp,%rdx
    641b:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6421:	48 89 c1             	mov    %rax,%rcx
    6424:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6429:	e8 12 fb ff ff       	call   5f40 <fwp_p_ad_push>
    642e:	48 83 c4 28          	add    $0x28,%rsp
    6432:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    6437:	5b                   	pop    %rbx
    6438:	5d                   	pop    %rbp
    6439:	41 5c                	pop    %r12
    643b:	41 5d                	pop    %r13
    643d:	c3                   	ret
    643e:	66 90                	xchg   %ax,%ax

0000000000006440 <w176.constprop.0>:
    6440:	41 54                	push   %r12
    6442:	55                   	push   %rbp
    6443:	53                   	push   %rbx
    6444:	48 83 ec 10          	sub    $0x10,%rsp
    6448:	4c 8b 27             	mov    (%rdi),%r12
    644b:	4d 85 e4             	test   %r12,%r12
    644e:	74 78                	je     64c8 <w176.constprop.0+0x88>
    6450:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    6457:	00 00 
    6459:	48 89 fd             	mov    %rdi,%rbp
    645c:	31 db                	xor    %ebx,%ebx
    645e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6465:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    646c:	00 00 00 00 
    6470:	4c 8b 44 dd 10       	mov    0x10(%rbp,%rbx,8),%r8
    6475:	f2 0f 10 44 dd 08    	movsd  0x8(%rbp,%rbx,8),%xmm0
    647b:	48 83 c3 02          	add    $0x2,%rbx
    647f:	e8 dc ea ff ff       	call   4f60 <caf75>
    6484:	48 89 c6             	mov    %rax,%rsi
    6487:	e8 d4 ea ff ff       	call   4f60 <caf75>
    648c:	f2 0f 58 44 24 08    	addsd  0x8(%rsp),%xmm0
    6492:	4c 89 c2             	mov    %r8,%rdx
    6495:	48 89 c1             	mov    %rax,%rcx
    6498:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    649e:	e8 9d fa ff ff       	call   5f40 <fwp_p_ad_push>
    64a3:	48 89 c7             	mov    %rax,%rdi
    64a6:	4c 39 e3             	cmp    %r12,%rbx
    64a9:	72 c5                	jb     6470 <w176.constprop.0+0x30>
    64ab:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    64b0:	48 83 c4 10          	add    $0x10,%rsp
    64b4:	5b                   	pop    %rbx
    64b5:	5d                   	pop    %rbp
    64b6:	66 48 0f 6e c0       	movq   %rax,%xmm0
    64bb:	41 5c                	pop    %r12
    64bd:	48 89 f8             	mov    %rdi,%rax
    64c0:	c3                   	ret
    64c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    64c8:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    64cf:	00 00 
    64d1:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    64d8:	eb d1                	jmp    64ab <w176.constprop.0+0x6b>
    64da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000064e0 <fwp_rc_share>:
    64e0:	48 8b 05 d1 e6 01 00 	mov    0x1e6d1(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    64e7:	48 2b 3d a2 e6 01 00 	sub    0x1e6a2(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    64ee:	48 c1 e0 10          	shl    $0x10,%rax
    64f2:	48 39 c7             	cmp    %rax,%rdi
    64f5:	73 4a                	jae    6541 <fwp_rc_share+0x61>
    64f7:	48 89 f8             	mov    %rdi,%rax
    64fa:	48 c1 e8 10          	shr    $0x10,%rax
    64fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6502:	48 8b 05 cf e6 01 00 	mov    0x1e6cf(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    6509:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    650d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6511:	48 85 d2             	test   %rdx,%rdx
    6514:	74 2b                	je     6541 <fwp_rc_share+0x61>
    6516:	0f b6 08             	movzbl (%rax),%ecx
    6519:	80 f9 02             	cmp    $0x2,%cl
    651c:	74 2a                	je     6548 <fwp_rc_share+0x68>
    651e:	80 f9 01             	cmp    $0x1,%cl
    6521:	75 1e                	jne    6541 <fwp_rc_share+0x61>
    6523:	8b 48 18             	mov    0x18(%rax),%ecx
    6526:	0f b7 ff             	movzwl %di,%edi
    6529:	8b 40 1c             	mov    0x1c(%rax),%eax
    652c:	48 0f af f9          	imul   %rcx,%rdi
    6530:	48 c1 ef 20          	shr    $0x20,%rdi
    6534:	48 39 c7             	cmp    %rax,%rdi
    6537:	73 08                	jae    6541 <fwp_rc_share+0x61>
    6539:	48 01 fa             	add    %rdi,%rdx
    653c:	80 3a 00             	cmpb   $0x0,(%rdx)
    653f:	75 0d                	jne    654e <fwp_rc_share+0x6e>
    6541:	c3                   	ret
    6542:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6548:	66 85 ff             	test   %di,%di
    654b:	74 ef                	je     653c <fwp_rc_share+0x5c>
    654d:	c3                   	ret
    654e:	50                   	push   %rax
    654f:	48 8d 3d da 93 00 00 	lea    0x93da(%rip),%rdi        # f930 <_IO_stdin_used+0x930>
    6556:	e8 95 de ff ff       	call   43f0 <fwp_trap>
    655b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006560 <fwp_rc_fresh>:
    6560:	48 8b 15 51 e6 01 00 	mov    0x1e651(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6567:	48 89 f8             	mov    %rdi,%rax
    656a:	48 89 fe             	mov    %rdi,%rsi
    656d:	48 2b 05 1c e6 01 00 	sub    0x1e61c(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6574:	48 c1 e2 10          	shl    $0x10,%rdx
    6578:	48 39 d0             	cmp    %rdx,%rax
    657b:	73 4f                	jae    65cc <fwp_rc_fresh+0x6c>
    657d:	48 89 c2             	mov    %rax,%rdx
    6580:	48 c1 ea 10          	shr    $0x10,%rdx
    6584:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6588:	48 8b 15 49 e6 01 00 	mov    0x1e649(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    658f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6593:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6597:	48 85 d2             	test   %rdx,%rdx
    659a:	74 30                	je     65cc <fwp_rc_fresh+0x6c>
    659c:	0f b6 39             	movzbl (%rcx),%edi
    659f:	40 80 ff 02          	cmp    $0x2,%dil
    65a3:	74 2b                	je     65d0 <fwp_rc_fresh+0x70>
    65a5:	40 80 ff 01          	cmp    $0x1,%dil
    65a9:	75 21                	jne    65cc <fwp_rc_fresh+0x6c>
    65ab:	8b 79 18             	mov    0x18(%rcx),%edi
    65ae:	0f b7 c0             	movzwl %ax,%eax
    65b1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    65b4:	48 0f af c7          	imul   %rdi,%rax
    65b8:	48 c1 e8 20          	shr    $0x20,%rax
    65bc:	48 39 c8             	cmp    %rcx,%rax
    65bf:	73 0b                	jae    65cc <fwp_rc_fresh+0x6c>
    65c1:	48 01 c2             	add    %rax,%rdx
    65c4:	80 3a ff             	cmpb   $0xff,(%rdx)
    65c7:	74 17                	je     65e0 <fwp_rc_fresh+0x80>
    65c9:	c6 02 01             	movb   $0x1,(%rdx)
    65cc:	48 89 f0             	mov    %rsi,%rax
    65cf:	c3                   	ret
    65d0:	66 85 c0             	test   %ax,%ax
    65d3:	74 ef                	je     65c4 <fwp_rc_fresh+0x64>
    65d5:	48 89 f0             	mov    %rsi,%rax
    65d8:	c3                   	ret
    65d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    65e0:	48 83 ec 18          	sub    $0x18,%rsp
    65e4:	48 89 d7             	mov    %rdx,%rdi
    65e7:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    65ec:	48 89 14 24          	mov    %rdx,(%rsp)
    65f0:	e8 bb ef ff ff       	call   55b0 <fwp_rc_forget_slot>
    65f5:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    65fa:	48 8b 14 24          	mov    (%rsp),%rdx
    65fe:	48 89 f0             	mov    %rsi,%rax
    6601:	c6 02 01             	movb   $0x1,(%rdx)
    6604:	48 83 c4 18          	add    $0x18,%rsp
    6608:	c3                   	ret
    6609:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006610 <fwp_rc_free_obj>:
    6610:	48 8b 15 a1 e5 01 00 	mov    0x1e5a1(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6617:	48 89 f8             	mov    %rdi,%rax
    661a:	48 2b 05 6f e5 01 00 	sub    0x1e56f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6621:	48 c1 e2 10          	shl    $0x10,%rdx
    6625:	48 39 d0             	cmp    %rdx,%rax
    6628:	73 5b                	jae    6685 <fwp_rc_free_obj+0x75>
    662a:	48 89 c2             	mov    %rax,%rdx
    662d:	48 c1 ea 10          	shr    $0x10,%rdx
    6631:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6635:	48 8b 15 9c e5 01 00 	mov    0x1e59c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    663c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6640:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6644:	48 85 c9             	test   %rcx,%rcx
    6647:	74 3c                	je     6685 <fwp_rc_free_obj+0x75>
    6649:	0f b6 32             	movzbl (%rdx),%esi
    664c:	40 80 fe 02          	cmp    $0x2,%sil
    6650:	74 2e                	je     6680 <fwp_rc_free_obj+0x70>
    6652:	40 80 fe 01          	cmp    $0x1,%sil
    6656:	75 2d                	jne    6685 <fwp_rc_free_obj+0x75>
    6658:	8b 72 18             	mov    0x18(%rdx),%esi
    665b:	0f b7 c0             	movzwl %ax,%eax
    665e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6661:	48 0f af c6          	imul   %rsi,%rax
    6665:	48 c1 e8 20          	shr    $0x20,%rax
    6669:	48 39 d0             	cmp    %rdx,%rax
    666c:	73 17                	jae    6685 <fwp_rc_free_obj+0x75>
    666e:	48 01 c1             	add    %rax,%rcx
    6671:	80 39 01             	cmpb   $0x1,(%rcx)
    6674:	75 0f                	jne    6685 <fwp_rc_free_obj+0x75>
    6676:	e9 75 f1 ff ff       	jmp    57f0 <fwp_mem_free>
    667b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6680:	66 85 c0             	test   %ax,%ax
    6683:	74 ec                	je     6671 <fwp_rc_free_obj+0x61>
    6685:	c3                   	ret
    6686:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    668d:	00 00 00 

0000000000006690 <fwp_rc_dup>:
    6690:	f3 0f 1e fa          	endbr64
    6694:	48 8b 05 1d e5 01 00 	mov    0x1e51d(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    669b:	48 2b 3d ee e4 01 00 	sub    0x1e4ee(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    66a2:	48 c1 e0 10          	shl    $0x10,%rax
    66a6:	48 39 c7             	cmp    %rax,%rdi
    66a9:	73 56                	jae    6701 <fwp_rc_dup+0x71>
    66ab:	48 89 f8             	mov    %rdi,%rax
    66ae:	48 c1 e8 10          	shr    $0x10,%rax
    66b2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    66b6:	48 8b 05 1b e5 01 00 	mov    0x1e51b(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    66bd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    66c1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    66c5:	48 85 c0             	test   %rax,%rax
    66c8:	74 37                	je     6701 <fwp_rc_dup+0x71>
    66ca:	0f b6 0a             	movzbl (%rdx),%ecx
    66cd:	80 f9 02             	cmp    $0x2,%cl
    66d0:	74 36                	je     6708 <fwp_rc_dup+0x78>
    66d2:	80 f9 01             	cmp    $0x1,%cl
    66d5:	75 2a                	jne    6701 <fwp_rc_dup+0x71>
    66d7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    66da:	0f b7 ff             	movzwl %di,%edi
    66dd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    66e0:	48 0f af f9          	imul   %rcx,%rdi
    66e4:	48 c1 ef 20          	shr    $0x20,%rdi
    66e8:	48 39 d7             	cmp    %rdx,%rdi
    66eb:	73 14                	jae    6701 <fwp_rc_dup+0x71>
    66ed:	48 01 f8             	add    %rdi,%rax
    66f0:	0f b6 10             	movzbl (%rax),%edx
    66f3:	84 d2                	test   %dl,%dl
    66f5:	74 0a                	je     6701 <fwp_rc_dup+0x71>
    66f7:	80 fa fd             	cmp    $0xfd,%dl
    66fa:	77 14                	ja     6710 <fwp_rc_dup+0x80>
    66fc:	83 c2 01             	add    $0x1,%edx
    66ff:	88 10                	mov    %dl,(%rax)
    6701:	c3                   	ret
    6702:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6708:	66 85 ff             	test   %di,%di
    670b:	74 e3                	je     66f0 <fwp_rc_dup+0x60>
    670d:	c3                   	ret
    670e:	66 90                	xchg   %ax,%ax
    6710:	48 89 c7             	mov    %rax,%rdi
    6713:	e9 78 ed ff ff       	jmp    5490 <fwp_rc_wide_dup>
    6718:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    671f:	00 

0000000000006720 <fwp_owned_entry173>:
    6720:	f3 0f 1e fa          	endbr64
    6724:	48 83 ec 38          	sub    $0x38,%rsp
    6728:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    672d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6734:	00 00 
    6736:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    673b:	31 c0                	xor    %eax,%eax
    673d:	48 8b 07             	mov    (%rdi),%rax
    6740:	48 03 47 10          	add    0x10(%rdi),%rax
    6744:	0f 80 c2 00 00 00    	jo     680c <fwp_owned_entry173+0xec>
    674a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    674f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6754:	31 ff                	xor    %edi,%edi
    6756:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    675a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    675f:	e8 ac f6 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    6764:	48 8b 15 4d e4 01 00 	mov    0x1e44d(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    676b:	48 89 c6             	mov    %rax,%rsi
    676e:	48 2b 05 1b e4 01 00 	sub    0x1e41b(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6775:	48 c1 e2 10          	shl    $0x10,%rdx
    6779:	48 39 d0             	cmp    %rdx,%rax
    677c:	73 4f                	jae    67cd <fwp_owned_entry173+0xad>
    677e:	48 89 c2             	mov    %rax,%rdx
    6781:	48 c1 ea 10          	shr    $0x10,%rdx
    6785:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6789:	48 8b 15 48 e4 01 00 	mov    0x1e448(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    6790:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6794:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6798:	48 85 d2             	test   %rdx,%rdx
    679b:	74 30                	je     67cd <fwp_owned_entry173+0xad>
    679d:	0f b6 39             	movzbl (%rcx),%edi
    67a0:	40 80 ff 02          	cmp    $0x2,%dil
    67a4:	74 42                	je     67e8 <fwp_owned_entry173+0xc8>
    67a6:	40 80 ff 01          	cmp    $0x1,%dil
    67aa:	75 21                	jne    67cd <fwp_owned_entry173+0xad>
    67ac:	8b 79 18             	mov    0x18(%rcx),%edi
    67af:	0f b7 c0             	movzwl %ax,%eax
    67b2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    67b5:	48 0f af c7          	imul   %rdi,%rax
    67b9:	48 c1 e8 20          	shr    $0x20,%rax
    67bd:	48 39 c8             	cmp    %rcx,%rax
    67c0:	73 0b                	jae    67cd <fwp_owned_entry173+0xad>
    67c2:	48 01 c2             	add    %rax,%rdx
    67c5:	80 3a ff             	cmpb   $0xff,(%rdx)
    67c8:	74 26                	je     67f0 <fwp_owned_entry173+0xd0>
    67ca:	c6 02 01             	movb   $0x1,(%rdx)
    67cd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    67d2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    67d9:	00 00 
    67db:	75 34                	jne    6811 <fwp_owned_entry173+0xf1>
    67dd:	48 89 f0             	mov    %rsi,%rax
    67e0:	48 83 c4 38          	add    $0x38,%rsp
    67e4:	c3                   	ret
    67e5:	0f 1f 00             	nopl   (%rax)
    67e8:	66 85 c0             	test   %ax,%ax
    67eb:	75 e0                	jne    67cd <fwp_owned_entry173+0xad>
    67ed:	eb d6                	jmp    67c5 <fwp_owned_entry173+0xa5>
    67ef:	90                   	nop
    67f0:	48 89 d7             	mov    %rdx,%rdi
    67f3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    67f8:	48 89 14 24          	mov    %rdx,(%rsp)
    67fc:	e8 af ed ff ff       	call   55b0 <fwp_rc_forget_slot>
    6801:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6806:	48 8b 14 24          	mov    (%rsp),%rdx
    680a:	eb be                	jmp    67ca <fwp_owned_entry173+0xaa>
    680c:	e8 ef ce ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6811:	e8 4a cc ff ff       	call   3460 <__stack_chk_fail@plt>
    6816:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    681d:	00 00 00 

0000000000006820 <e173>:
    6820:	f3 0f 1e fa          	endbr64
    6824:	53                   	push   %rbx
    6825:	48 83 ec 30          	sub    $0x30,%rsp
    6829:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    682e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6835:	00 00 
    6837:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    683c:	31 c0                	xor    %eax,%eax
    683e:	48 8b 07             	mov    (%rdi),%rax
    6841:	48 03 47 10          	add    0x10(%rdi),%rax
    6845:	0f 80 c9 00 00 00    	jo     6914 <e173+0xf4>
    684b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6850:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6855:	31 ff                	xor    %edi,%edi
    6857:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    685b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6860:	e8 ab f5 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    6865:	48 8b 15 4c e3 01 00 	mov    0x1e34c(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    686c:	48 89 c3             	mov    %rax,%rbx
    686f:	48 2b 05 1a e3 01 00 	sub    0x1e31a(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6876:	48 c1 e2 10          	shl    $0x10,%rdx
    687a:	48 39 d0             	cmp    %rdx,%rax
    687d:	73 4f                	jae    68ce <e173+0xae>
    687f:	48 89 c2             	mov    %rax,%rdx
    6882:	48 c1 ea 10          	shr    $0x10,%rdx
    6886:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    688a:	48 8b 15 47 e3 01 00 	mov    0x1e347(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    6891:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6895:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6899:	48 85 d2             	test   %rdx,%rdx
    689c:	74 30                	je     68ce <e173+0xae>
    689e:	0f b6 31             	movzbl (%rcx),%esi
    68a1:	40 80 fe 02          	cmp    $0x2,%sil
    68a5:	74 49                	je     68f0 <e173+0xd0>
    68a7:	40 80 fe 01          	cmp    $0x1,%sil
    68ab:	75 21                	jne    68ce <e173+0xae>
    68ad:	8b 71 18             	mov    0x18(%rcx),%esi
    68b0:	0f b7 c0             	movzwl %ax,%eax
    68b3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    68b6:	48 0f af c6          	imul   %rsi,%rax
    68ba:	48 c1 e8 20          	shr    $0x20,%rax
    68be:	48 39 c8             	cmp    %rcx,%rax
    68c1:	73 0b                	jae    68ce <e173+0xae>
    68c3:	48 01 c2             	add    %rax,%rdx
    68c6:	80 3a ff             	cmpb   $0xff,(%rdx)
    68c9:	74 35                	je     6900 <e173+0xe0>
    68cb:	c6 02 01             	movb   $0x1,(%rdx)
    68ce:	48 89 df             	mov    %rbx,%rdi
    68d1:	e8 0a fc ff ff       	call   64e0 <fwp_rc_share>
    68d6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    68db:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    68e2:	00 00 
    68e4:	75 33                	jne    6919 <e173+0xf9>
    68e6:	48 83 c4 30          	add    $0x30,%rsp
    68ea:	48 89 d8             	mov    %rbx,%rax
    68ed:	5b                   	pop    %rbx
    68ee:	c3                   	ret
    68ef:	90                   	nop
    68f0:	66 85 c0             	test   %ax,%ax
    68f3:	75 d9                	jne    68ce <e173+0xae>
    68f5:	eb cf                	jmp    68c6 <e173+0xa6>
    68f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    68fe:	00 00 
    6900:	48 89 d7             	mov    %rdx,%rdi
    6903:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6908:	e8 a3 ec ff ff       	call   55b0 <fwp_rc_forget_slot>
    690d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6912:	eb b7                	jmp    68cb <e173+0xab>
    6914:	e8 e7 cd ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6919:	e8 42 cb ff ff       	call   3460 <__stack_chk_fail@plt>
    691e:	66 90                	xchg   %ax,%ax

0000000000006920 <fwp_closure_drop>:
    6920:	48 8b 15 91 e2 01 00 	mov    0x1e291(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6927:	48 89 f8             	mov    %rdi,%rax
    692a:	48 2b 05 5f e2 01 00 	sub    0x1e25f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6931:	48 c1 e2 10          	shl    $0x10,%rdx
    6935:	48 39 d0             	cmp    %rdx,%rax
    6938:	73 6b                	jae    69a5 <fwp_closure_drop+0x85>
    693a:	48 89 c2             	mov    %rax,%rdx
    693d:	48 c1 ea 10          	shr    $0x10,%rdx
    6941:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6945:	48 8b 15 8c e2 01 00 	mov    0x1e28c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    694c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6950:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6954:	48 85 d2             	test   %rdx,%rdx
    6957:	74 4c                	je     69a5 <fwp_closure_drop+0x85>
    6959:	0f b6 31             	movzbl (%rcx),%esi
    695c:	40 80 fe 02          	cmp    $0x2,%sil
    6960:	74 3e                	je     69a0 <fwp_closure_drop+0x80>
    6962:	40 80 fe 01          	cmp    $0x1,%sil
    6966:	75 3d                	jne    69a5 <fwp_closure_drop+0x85>
    6968:	8b 71 18             	mov    0x18(%rcx),%esi
    696b:	0f b7 c0             	movzwl %ax,%eax
    696e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6971:	48 0f af c6          	imul   %rsi,%rax
    6975:	48 c1 e8 20          	shr    $0x20,%rax
    6979:	48 39 c8             	cmp    %rcx,%rax
    697c:	73 27                	jae    69a5 <fwp_closure_drop+0x85>
    697e:	48 01 c2             	add    %rax,%rdx
    6981:	0f b6 02             	movzbl (%rdx),%eax
    6984:	84 c0                	test   %al,%al
    6986:	74 1d                	je     69a5 <fwp_closure_drop+0x85>
    6988:	3c 01                	cmp    $0x1,%al
    698a:	74 24                	je     69b0 <fwp_closure_drop+0x90>
    698c:	3c ff                	cmp    $0xff,%al
    698e:	74 48                	je     69d8 <fwp_closure_drop+0xb8>
    6990:	83 e8 01             	sub    $0x1,%eax
    6993:	88 02                	mov    %al,(%rdx)
    6995:	c3                   	ret
    6996:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    699d:	00 00 00 
    69a0:	66 85 c0             	test   %ax,%ax
    69a3:	74 dc                	je     6981 <fwp_closure_drop+0x61>
    69a5:	c3                   	ret
    69a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    69ad:	00 00 00 
    69b0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    69b7:	ff ff 
    69b9:	48 85 c0             	test   %rax,%rax
    69bc:	74 12                	je     69d0 <fwp_closure_drop+0xb0>
    69be:	48 89 fe             	mov    %rdi,%rsi
    69c1:	48 89 c7             	mov    %rax,%rdi
    69c4:	e9 87 da ff ff       	jmp    4450 <fwp_closure_drop_push>
    69c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    69d0:	e9 2b dc ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    69d5:	0f 1f 00             	nopl   (%rax)
    69d8:	48 89 d0             	mov    %rdx,%rax
    69db:	48 8d 35 fe cd 01 00 	lea    0x1cdfe(%rip),%rsi        # 237e0 <fwp_heap>
    69e2:	48 83 ec 18          	sub    $0x18,%rsp
    69e6:	48 c1 e8 11          	shr    $0x11,%rax
    69ea:	48 31 d0             	xor    %rdx,%rax
    69ed:	48 89 c1             	mov    %rax,%rcx
    69f0:	48 c1 e9 09          	shr    $0x9,%rcx
    69f4:	48 31 c8             	xor    %rcx,%rax
    69f7:	0f b6 c8             	movzbl %al,%ecx
    69fa:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6a01:	00 
    6a02:	48 85 c0             	test   %rax,%rax
    6a05:	75 22                	jne    6a29 <fwp_closure_drop+0x109>
    6a07:	eb 59                	jmp    6a62 <fwp_closure_drop+0x142>
    6a09:	90                   	nop
    6a0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6a11:	00 00 00 00 
    6a15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6a1c:	00 00 00 00 
    6a20:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6a24:	48 85 c0             	test   %rax,%rax
    6a27:	74 39                	je     6a62 <fwp_closure_drop+0x142>
    6a29:	48 89 c1             	mov    %rax,%rcx
    6a2c:	48 39 10             	cmp    %rdx,(%rax)
    6a2f:	75 ef                	jne    6a20 <fwp_closure_drop+0x100>
    6a31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6a35:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6a39:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6a3d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6a44:	74 05                	je     6a4b <fwp_closure_drop+0x12b>
    6a46:	48 83 c4 18          	add    $0x18,%rsp
    6a4a:	c3                   	ret
    6a4b:	48 89 d7             	mov    %rdx,%rdi
    6a4e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6a53:	e8 58 eb ff ff       	call   55b0 <fwp_rc_forget_slot>
    6a58:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6a5d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6a60:	eb e4                	jmp    6a46 <fwp_closure_drop+0x126>
    6a62:	48 8d 3d 27 8e 00 00 	lea    0x8e27(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    6a69:	e8 82 d9 ff ff       	call   43f0 <fwp_trap>
    6a6e:	66 90                	xchg   %ax,%ax

0000000000006a70 <fwp_owned_tape_release>:
    6a70:	48 85 ff             	test   %rdi,%rdi
    6a73:	0f 84 f7 00 00 00    	je     6b70 <fwp_owned_tape_release+0x100>
    6a79:	41 54                	push   %r12
    6a7b:	55                   	push   %rbp
    6a7c:	53                   	push   %rbx
    6a7d:	48 8b 07             	mov    (%rdi),%rax
    6a80:	48 85 c0             	test   %rax,%rax
    6a83:	74 08                	je     6a8d <fwp_owned_tape_release+0x1d>
    6a85:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6a89:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6a8d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6a91:	48 85 d2             	test   %rdx,%rdx
    6a94:	74 03                	je     6a99 <fwp_owned_tape_release+0x29>
    6a96:	48 89 02             	mov    %rax,(%rdx)
    6a99:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6a9d:	48 89 fb             	mov    %rdi,%rbx
    6aa0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6aa4:	48 85 c0             	test   %rax,%rax
    6aa7:	0f 84 89 00 00 00    	je     6b36 <fwp_owned_tape_release+0xc6>
    6aad:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6ab1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6ab5:	7e 47                	jle    6afe <fwp_owned_tape_release+0x8e>
    6ab7:	31 ed                	xor    %ebp,%ebp
    6ab9:	eb 0d                	jmp    6ac8 <fwp_owned_tape_release+0x58>
    6abb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6ac0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6ac4:	48 8b 40 68          	mov    0x68(%rax),%rax
    6ac8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6acc:	49 89 ec             	mov    %rbp,%r12
    6acf:	48 83 c5 01          	add    $0x1,%rbp
    6ad3:	49 c1 e4 04          	shl    $0x4,%r12
    6ad7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6adb:	ff d0                	call   *%rax
    6add:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6ae1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6ae6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6aea:	ff 50 68             	call   *0x68(%rax)
    6aed:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6af1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6af5:	48 39 e8             	cmp    %rbp,%rax
    6af8:	7f c6                	jg     6ac0 <fwp_owned_tape_release+0x50>
    6afa:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6afe:	31 ed                	xor    %ebp,%ebp
    6b00:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6b05:	7e 28                	jle    6b2f <fwp_owned_tape_release+0xbf>
    6b07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6b0e:	00 00 
    6b10:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6b14:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6b18:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6b1c:	74 07                	je     6b25 <fwp_owned_tape_release+0xb5>
    6b1e:	ff 52 68             	call   *0x68(%rdx)
    6b21:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6b25:	48 83 c5 01          	add    $0x1,%rbp
    6b29:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6b2d:	7f e1                	jg     6b10 <fwp_owned_tape_release+0xa0>
    6b2f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6b33:	ff 52 68             	call   *0x68(%rdx)
    6b36:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6b3a:	e8 e1 fd ff ff       	call   6920 <fwp_closure_drop>
    6b3f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6b43:	e8 d8 fd ff ff       	call   6920 <fwp_closure_drop>
    6b48:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6b4c:	e8 cf fd ff ff       	call   6920 <fwp_closure_drop>
    6b51:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6b55:	e8 96 ec ff ff       	call   57f0 <fwp_mem_free>
    6b5a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6b5e:	e8 8d ec ff ff       	call   57f0 <fwp_mem_free>
    6b63:	48 89 df             	mov    %rbx,%rdi
    6b66:	5b                   	pop    %rbx
    6b67:	5d                   	pop    %rbp
    6b68:	41 5c                	pop    %r12
    6b6a:	e9 81 ec ff ff       	jmp    57f0 <fwp_mem_free>
    6b6f:	90                   	nop
    6b70:	c3                   	ret
    6b71:	0f 1f 40 00          	nopl   0x0(%rax)
    6b75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6b7c:	00 00 00 00 

0000000000006b80 <fwp_tape_finish>:
    6b80:	f3 0f 1e fa          	endbr64
    6b84:	41 56                	push   %r14
    6b86:	48 8d 3d 33 c5 01 00 	lea    0x1c533(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    6b8d:	41 55                	push   %r13
    6b8f:	41 54                	push   %r12
    6b91:	55                   	push   %rbp
    6b92:	53                   	push   %rbx
    6b93:	e8 78 d5 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    6b98:	48 83 3d 68 c5 01 00 	cmpq   $0x0,0x1c568(%rip)        # 23108 <fwp_ntapes>
    6b9f:	00 
    6ba0:	48 c7 05 fd c4 01 00 	movq   $0x0,0x1c4fd(%rip)        # 230a8 <fwp_tape_cached_bytes>
    6ba7:	00 00 00 00 
    6bab:	7e 68                	jle    6c15 <fwp_tape_finish+0x95>
    6bad:	45 31 e4             	xor    %r12d,%r12d
    6bb0:	31 ed                	xor    %ebp,%ebp
    6bb2:	0f 1f 00             	nopl   (%rax)
    6bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6bbc:	00 00 00 00 
    6bc0:	48 8b 1d 49 c5 01 00 	mov    0x1c549(%rip),%rbx        # 23110 <fwp_tapes>
    6bc7:	48 83 c5 01          	add    $0x1,%rbp
    6bcb:	4c 01 e3             	add    %r12,%rbx
    6bce:	49 83 c4 68          	add    $0x68,%r12
    6bd2:	48 89 df             	mov    %rbx,%rdi
    6bd5:	e8 26 d0 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6bda:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6bde:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6be2:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6be6:	e8 d5 c7 ff ff       	call   33c0 <free@plt>
    6beb:	4c 89 f7             	mov    %r14,%rdi
    6bee:	e8 cd c7 ff ff       	call   33c0 <free@plt>
    6bf3:	4c 89 ef             	mov    %r13,%rdi
    6bf6:	e8 c5 c7 ff ff       	call   33c0 <free@plt>
    6bfb:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6bff:	e8 6c fe ff ff       	call   6a70 <fwp_owned_tape_release>
    6c04:	48 39 2d fd c4 01 00 	cmp    %rbp,0x1c4fd(%rip)        # 23108 <fwp_ntapes>
    6c0b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6c12:	00 
    6c13:	7f ab                	jg     6bc0 <fwp_tape_finish+0x40>
    6c15:	48 8b 3d f4 c4 01 00 	mov    0x1c4f4(%rip),%rdi        # 23110 <fwp_tapes>
    6c1c:	e8 9f c7 ff ff       	call   33c0 <free@plt>
    6c21:	5b                   	pop    %rbx
    6c22:	5d                   	pop    %rbp
    6c23:	48 c7 05 e2 c4 01 00 	movq   $0x0,0x1c4e2(%rip)        # 23110 <fwp_tapes>
    6c2a:	00 00 00 00 
    6c2e:	48 c7 05 c7 c4 01 00 	movq   $0x0,0x1c4c7(%rip)        # 23100 <fwp_tapes_cap>
    6c35:	00 00 00 00 
    6c39:	41 5c                	pop    %r12
    6c3b:	48 c7 05 c2 c4 01 00 	movq   $0x0,0x1c4c2(%rip)        # 23108 <fwp_ntapes>
    6c42:	00 00 00 00 
    6c46:	41 5d                	pop    %r13
    6c48:	48 c7 05 a5 c4 01 00 	movq   $0x0,0x1c4a5(%rip)        # 230f8 <fwp_tape_next_slot>
    6c4f:	00 00 00 00 
    6c53:	41 5e                	pop    %r14
    6c55:	c3                   	ret
    6c56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c5d:	00 00 00 

0000000000006c60 <fwp_tape_scope_release>:
    6c60:	f3 0f 1e fa          	endbr64
    6c64:	41 55                	push   %r13
    6c66:	41 54                	push   %r12
    6c68:	55                   	push   %rbp
    6c69:	53                   	push   %rbx
    6c6a:	48 83 ec 58          	sub    $0x58,%rsp
    6c6e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6c75:	00 00 
    6c77:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6c7c:	48 63 07             	movslq (%rdi),%rax
    6c7f:	85 c0                	test   %eax,%eax
    6c81:	0f 88 05 01 00 00    	js     6d8c <fwp_tape_scope_release+0x12c>
    6c87:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6c8e:	ec c4 4e 
    6c91:	48 89 fb             	mov    %rdi,%rbx
    6c94:	eb 3c                	jmp    6cd2 <fwp_tape_scope_release+0x72>
    6c96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c9d:	00 00 00 
    6ca0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6ca5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6ca9:	e8 12 c7 ff ff       	call   33c0 <free@plt>
    6cae:	48 8b 3c 24          	mov    (%rsp),%rdi
    6cb2:	e8 09 c7 ff ff       	call   33c0 <free@plt>
    6cb7:	4c 89 ef             	mov    %r13,%rdi
    6cba:	e8 01 c7 ff ff       	call   33c0 <free@plt>
    6cbf:	4c 89 e7             	mov    %r12,%rdi
    6cc2:	e8 a9 fd ff ff       	call   6a70 <fwp_owned_tape_release>
    6cc7:	48 63 03             	movslq (%rbx),%rax
    6cca:	85 c0                	test   %eax,%eax
    6ccc:	0f 88 ba 00 00 00    	js     6d8c <fwp_tape_scope_release+0x12c>
    6cd2:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6cd6:	48 8b 35 33 c4 01 00 	mov    0x1c433(%rip),%rsi        # 23110 <fwp_tapes>
    6cdd:	4c 01 c6             	add    %r8,%rsi
    6ce0:	48 89 f7             	mov    %rsi,%rdi
    6ce3:	e8 18 cf ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6ce8:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6ced:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6cf2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6cf9:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6cfd:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6d01:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6d08:	00 
    6d09:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6d0e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6d12:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6d17:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6d1b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6d20:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6d27:	00 
    6d28:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6d2f:	00 
    6d30:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6d37:	00 
    6d38:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6d3d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6d42:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6d46:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6d4a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6d4e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6d54:	77 18                	ja     6d6e <fwp_tape_scope_release+0x10e>
    6d56:	49 c1 f8 03          	sar    $0x3,%r8
    6d5a:	4c 0f af c5          	imul   %rbp,%r8
    6d5e:	4c 3b 05 93 c3 01 00 	cmp    0x1c393(%rip),%r8        # 230f8 <fwp_tape_next_slot>
    6d65:	7d 07                	jge    6d6e <fwp_tape_scope_release+0x10e>
    6d67:	4c 89 05 8a c3 01 00 	mov    %r8,0x1c38a(%rip)        # 230f8 <fwp_tape_next_slot>
    6d6e:	4d 85 e4             	test   %r12,%r12
    6d71:	0f 85 29 ff ff ff    	jne    6ca0 <fwp_tape_scope_release+0x40>
    6d77:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6d7c:	e8 4f e3 ff ff       	call   50d0 <fwp_tape_buffers_release>
    6d81:	48 63 03             	movslq (%rbx),%rax
    6d84:	85 c0                	test   %eax,%eax
    6d86:	0f 89 46 ff ff ff    	jns    6cd2 <fwp_tape_scope_release+0x72>
    6d8c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6d91:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6d98:	00 00 
    6d9a:	75 0b                	jne    6da7 <fwp_tape_scope_release+0x147>
    6d9c:	48 83 c4 58          	add    $0x58,%rsp
    6da0:	5b                   	pop    %rbx
    6da1:	5d                   	pop    %rbp
    6da2:	41 5c                	pop    %r12
    6da4:	41 5d                	pop    %r13
    6da6:	c3                   	ret
    6da7:	e8 b4 c6 ff ff       	call   3460 <__stack_chk_fail@plt>
    6dac:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006db0 <fwp_drop4>:
    6db0:	48 8b 0d 01 de 01 00 	mov    0x1de01(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    6db7:	48 89 f8             	mov    %rdi,%rax
    6dba:	48 2b 05 cf dd 01 00 	sub    0x1ddcf(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6dc1:	48 c1 e1 10          	shl    $0x10,%rcx
    6dc5:	48 39 c8             	cmp    %rcx,%rax
    6dc8:	0f 83 42 01 00 00    	jae    6f10 <fwp_drop4+0x160>
    6dce:	48 83 ec 18          	sub    $0x18,%rsp
    6dd2:	48 89 fa             	mov    %rdi,%rdx
    6dd5:	4c 8d 05 04 ca 01 00 	lea    0x1ca04(%rip),%r8        # 237e0 <fwp_heap>
    6ddc:	48 89 c1             	mov    %rax,%rcx
    6ddf:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    6de6:	48 c1 e9 10          	shr    $0x10,%rcx
    6dea:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6dee:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6df2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6df6:	48 85 c9             	test   %rcx,%rcx
    6df9:	74 40                	je     6e3b <fwp_drop4+0x8b>
    6dfb:	0f b6 3e             	movzbl (%rsi),%edi
    6dfe:	40 80 ff 02          	cmp    $0x2,%dil
    6e02:	74 3c                	je     6e40 <fwp_drop4+0x90>
    6e04:	40 80 ff 01          	cmp    $0x1,%dil
    6e08:	75 31                	jne    6e3b <fwp_drop4+0x8b>
    6e0a:	8b 7e 18             	mov    0x18(%rsi),%edi
    6e0d:	0f b7 c0             	movzwl %ax,%eax
    6e10:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6e13:	48 0f af c7          	imul   %rdi,%rax
    6e17:	48 c1 e8 20          	shr    $0x20,%rax
    6e1b:	48 39 f0             	cmp    %rsi,%rax
    6e1e:	73 1b                	jae    6e3b <fwp_drop4+0x8b>
    6e20:	48 01 c1             	add    %rax,%rcx
    6e23:	0f b6 01             	movzbl (%rcx),%eax
    6e26:	84 c0                	test   %al,%al
    6e28:	74 11                	je     6e3b <fwp_drop4+0x8b>
    6e2a:	3c 01                	cmp    $0x1,%al
    6e2c:	74 22                	je     6e50 <fwp_drop4+0xa0>
    6e2e:	3c ff                	cmp    $0xff,%al
    6e30:	0f 84 0a 01 00 00    	je     6f40 <fwp_drop4+0x190>
    6e36:	83 e8 01             	sub    $0x1,%eax
    6e39:	88 01                	mov    %al,(%rcx)
    6e3b:	48 83 c4 18          	add    $0x18,%rsp
    6e3f:	c3                   	ret
    6e40:	66 85 c0             	test   %ax,%ax
    6e43:	74 de                	je     6e23 <fwp_drop4+0x73>
    6e45:	48 83 c4 18          	add    $0x18,%rsp
    6e49:	c3                   	ret
    6e4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6e50:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6e54:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    6e5b:	48 89 f8             	mov    %rdi,%rax
    6e5e:	48 c1 e1 10          	shl    $0x10,%rcx
    6e62:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6e69:	48 39 c8             	cmp    %rcx,%rax
    6e6c:	73 62                	jae    6ed0 <fwp_drop4+0x120>
    6e6e:	48 89 c1             	mov    %rax,%rcx
    6e71:	48 c1 e9 10          	shr    $0x10,%rcx
    6e75:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6e79:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6e7d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6e81:	48 85 c9             	test   %rcx,%rcx
    6e84:	74 4a                	je     6ed0 <fwp_drop4+0x120>
    6e86:	44 0f b6 0e          	movzbl (%rsi),%r9d
    6e8a:	41 80 f9 02          	cmp    $0x2,%r9b
    6e8e:	0f 84 9c 00 00 00    	je     6f30 <fwp_drop4+0x180>
    6e94:	41 80 f9 01          	cmp    $0x1,%r9b
    6e98:	75 36                	jne    6ed0 <fwp_drop4+0x120>
    6e9a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    6e9e:	0f b7 c0             	movzwl %ax,%eax
    6ea1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6ea4:	49 0f af c1          	imul   %r9,%rax
    6ea8:	48 c1 e8 20          	shr    $0x20,%rax
    6eac:	48 39 f0             	cmp    %rsi,%rax
    6eaf:	73 1f                	jae    6ed0 <fwp_drop4+0x120>
    6eb1:	48 01 c1             	add    %rax,%rcx
    6eb4:	0f b6 01             	movzbl (%rcx),%eax
    6eb7:	84 c0                	test   %al,%al
    6eb9:	74 15                	je     6ed0 <fwp_drop4+0x120>
    6ebb:	3c 01                	cmp    $0x1,%al
    6ebd:	74 59                	je     6f18 <fwp_drop4+0x168>
    6ebf:	3c ff                	cmp    $0xff,%al
    6ec1:	0f 84 ff 00 00 00    	je     6fc6 <fwp_drop4+0x216>
    6ec7:	83 e8 01             	sub    $0x1,%eax
    6eca:	88 01                	mov    %al,(%rcx)
    6ecc:	0f 1f 40 00          	nopl   0x0(%rax)
    6ed0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    6ed4:	48 89 d7             	mov    %rdx,%rdi
    6ed7:	48 89 0c 24          	mov    %rcx,(%rsp)
    6edb:	e8 30 f7 ff ff       	call   6610 <fwp_rc_free_obj>
    6ee0:	4c 8d 05 f9 c8 01 00 	lea    0x1c8f9(%rip),%r8        # 237e0 <fwp_heap>
    6ee7:	48 8b 04 24          	mov    (%rsp),%rax
    6eeb:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6ef2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6ef9:	48 c1 e2 10          	shl    $0x10,%rdx
    6efd:	48 39 d0             	cmp    %rdx,%rax
    6f00:	0f 83 35 ff ff ff    	jae    6e3b <fwp_drop4+0x8b>
    6f06:	48 8b 14 24          	mov    (%rsp),%rdx
    6f0a:	e9 cd fe ff ff       	jmp    6ddc <fwp_drop4+0x2c>
    6f0f:	90                   	nop
    6f10:	c3                   	ret
    6f11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f18:	48 89 14 24          	mov    %rdx,(%rsp)
    6f1c:	e8 ef f6 ff ff       	call   6610 <fwp_rc_free_obj>
    6f21:	48 8b 14 24          	mov    (%rsp),%rdx
    6f25:	eb a9                	jmp    6ed0 <fwp_drop4+0x120>
    6f27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6f2e:	00 00 
    6f30:	66 85 c0             	test   %ax,%ax
    6f33:	75 9b                	jne    6ed0 <fwp_drop4+0x120>
    6f35:	e9 7a ff ff ff       	jmp    6eb4 <fwp_drop4+0x104>
    6f3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f40:	48 89 c8             	mov    %rcx,%rax
    6f43:	48 c1 e8 11          	shr    $0x11,%rax
    6f47:	48 31 c8             	xor    %rcx,%rax
    6f4a:	48 89 c2             	mov    %rax,%rdx
    6f4d:	48 c1 ea 09          	shr    $0x9,%rdx
    6f51:	48 31 d0             	xor    %rdx,%rax
    6f54:	0f b6 d0             	movzbl %al,%edx
    6f57:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    6f5e:	00 
    6f5f:	48 85 c0             	test   %rax,%rax
    6f62:	75 29                	jne    6f8d <fwp_drop4+0x1dd>
    6f64:	e9 e3 00 00 00       	jmp    704c <fwp_drop4+0x29c>
    6f69:	90                   	nop
    6f6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f71:	00 00 00 00 
    6f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f7c:	00 00 00 00 
    6f80:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6f84:	48 85 c0             	test   %rax,%rax
    6f87:	0f 84 bf 00 00 00    	je     704c <fwp_drop4+0x29c>
    6f8d:	48 89 c2             	mov    %rax,%rdx
    6f90:	48 39 08             	cmp    %rcx,(%rax)
    6f93:	75 eb                	jne    6f80 <fwp_drop4+0x1d0>
    6f95:	48 8b 50 08          	mov    0x8(%rax),%rdx
    6f99:	48 83 ea 01          	sub    $0x1,%rdx
    6f9d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6fa1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6fa8:	0f 85 8d fe ff ff    	jne    6e3b <fwp_drop4+0x8b>
    6fae:	48 89 cf             	mov    %rcx,%rdi
    6fb1:	48 89 0c 24          	mov    %rcx,(%rsp)
    6fb5:	e8 f6 e5 ff ff       	call   55b0 <fwp_rc_forget_slot>
    6fba:	48 8b 0c 24          	mov    (%rsp),%rcx
    6fbe:	c6 01 fe             	movb   $0xfe,(%rcx)
    6fc1:	e9 75 fe ff ff       	jmp    6e3b <fwp_drop4+0x8b>
    6fc6:	48 89 ce             	mov    %rcx,%rsi
    6fc9:	48 c1 ee 11          	shr    $0x11,%rsi
    6fcd:	48 31 ce             	xor    %rcx,%rsi
    6fd0:	48 89 f0             	mov    %rsi,%rax
    6fd3:	48 c1 e8 09          	shr    $0x9,%rax
    6fd7:	48 31 c6             	xor    %rax,%rsi
    6fda:	40 0f b6 f6          	movzbl %sil,%esi
    6fde:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    6fe5:	00 
    6fe6:	48 85 c0             	test   %rax,%rax
    6fe9:	75 1e                	jne    7009 <fwp_drop4+0x259>
    6feb:	eb 5f                	jmp    704c <fwp_drop4+0x29c>
    6fed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6ff4:	00 
    6ff5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6ffc:	00 00 00 00 
    7000:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7004:	48 85 c0             	test   %rax,%rax
    7007:	74 43                	je     704c <fwp_drop4+0x29c>
    7009:	48 89 c6             	mov    %rax,%rsi
    700c:	48 39 08             	cmp    %rcx,(%rax)
    700f:	75 ef                	jne    7000 <fwp_drop4+0x250>
    7011:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7015:	48 83 ee 01          	sub    $0x1,%rsi
    7019:	48 89 70 08          	mov    %rsi,0x8(%rax)
    701d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7024:	0f 85 a6 fe ff ff    	jne    6ed0 <fwp_drop4+0x120>
    702a:	48 89 cf             	mov    %rcx,%rdi
    702d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7032:	48 89 0c 24          	mov    %rcx,(%rsp)
    7036:	e8 75 e5 ff ff       	call   55b0 <fwp_rc_forget_slot>
    703b:	48 8b 0c 24          	mov    (%rsp),%rcx
    703f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7044:	c6 01 fe             	movb   $0xfe,(%rcx)
    7047:	e9 84 fe ff ff       	jmp    6ed0 <fwp_drop4+0x120>
    704c:	48 8d 3d 3d 88 00 00 	lea    0x883d(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    7053:	e8 98 d3 ff ff       	call   43f0 <fwp_trap>
    7058:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    705f:	00 

0000000000007060 <fwp_arg_drop37>:
    7060:	f3 0f 1e fa          	endbr64
    7064:	85 f6                	test   %esi,%esi
    7066:	75 04                	jne    706c <fwp_arg_drop37+0xc>
    7068:	85 d2                	test   %edx,%edx
    706a:	75 04                	jne    7070 <fwp_arg_drop37+0x10>
    706c:	c3                   	ret
    706d:	0f 1f 00             	nopl   (%rax)
    7070:	48 8b 3f             	mov    (%rdi),%rdi
    7073:	e9 38 fd ff ff       	jmp    6db0 <fwp_drop4>
    7078:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    707f:	00 

0000000000007080 <fwp_task_dispose>:
    7080:	53                   	push   %rbx
    7081:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7085:	0f 84 bb c6 ff ff    	je     3746 <fwp_task_dispose.cold>
    708b:	48 89 fb             	mov    %rdi,%rbx
    708e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7093:	0f 85 ad c6 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7099:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    709d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    70a4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    70ab:	00 
    70ac:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    70b0:	48 85 ff             	test   %rdi,%rdi
    70b3:	74 07                	je     70bc <fwp_task_dispose+0x3c>
    70b5:	48 85 c0             	test   %rax,%rax
    70b8:	74 02                	je     70bc <fwp_task_dispose+0x3c>
    70ba:	ff d0                	call   *%rax
    70bc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    70c3:	e8 28 e7 ff ff       	call   57f0 <fwp_mem_free>
    70c8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    70cf:	00 00 00 00 
    70d3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    70d7:	74 6f                	je     7148 <fwp_task_dispose+0xc8>
    70d9:	48 8b 15 d8 da 01 00 	mov    0x1dad8(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    70e0:	48 89 d8             	mov    %rbx,%rax
    70e3:	48 2b 05 a6 da 01 00 	sub    0x1daa6(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    70ea:	48 c1 e2 10          	shl    $0x10,%rdx
    70ee:	48 39 d0             	cmp    %rdx,%rax
    70f1:	73 4c                	jae    713f <fwp_task_dispose+0xbf>
    70f3:	48 89 c2             	mov    %rax,%rdx
    70f6:	48 c1 ea 10          	shr    $0x10,%rdx
    70fa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    70fe:	48 8b 15 d3 da 01 00 	mov    0x1dad3(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    7105:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7109:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    710d:	48 85 c9             	test   %rcx,%rcx
    7110:	74 2d                	je     713f <fwp_task_dispose+0xbf>
    7112:	0f b6 32             	movzbl (%rdx),%esi
    7115:	40 80 fe 02          	cmp    $0x2,%sil
    7119:	74 3d                	je     7158 <fwp_task_dispose+0xd8>
    711b:	40 80 fe 01          	cmp    $0x1,%sil
    711f:	75 1e                	jne    713f <fwp_task_dispose+0xbf>
    7121:	8b 72 18             	mov    0x18(%rdx),%esi
    7124:	0f b7 c0             	movzwl %ax,%eax
    7127:	8b 52 1c             	mov    0x1c(%rdx),%edx
    712a:	48 0f af c6          	imul   %rsi,%rax
    712e:	48 c1 e8 20          	shr    $0x20,%rax
    7132:	48 39 d0             	cmp    %rdx,%rax
    7135:	73 08                	jae    713f <fwp_task_dispose+0xbf>
    7137:	48 01 c1             	add    %rax,%rcx
    713a:	80 39 01             	cmpb   $0x1,(%rcx)
    713d:	74 09                	je     7148 <fwp_task_dispose+0xc8>
    713f:	5b                   	pop    %rbx
    7140:	c3                   	ret
    7141:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7148:	48 89 df             	mov    %rbx,%rdi
    714b:	5b                   	pop    %rbx
    714c:	e9 9f e6 ff ff       	jmp    57f0 <fwp_mem_free>
    7151:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7158:	66 85 c0             	test   %ax,%ax
    715b:	74 dd                	je     713a <fwp_task_dispose+0xba>
    715d:	5b                   	pop    %rbx
    715e:	c3                   	ret
    715f:	90                   	nop

0000000000007160 <fwp_free_zombie>:
    7160:	48 8b 15 49 c6 01 00 	mov    0x1c649(%rip),%rdx        # 237b0 <fwp_zombie>
    7167:	48 85 d2             	test   %rdx,%rdx
    716a:	0f 84 98 00 00 00    	je     7208 <fwp_free_zombie+0xa8>
    7170:	48 3b 15 49 c6 01 00 	cmp    0x1c649(%rip),%rdx        # 237c0 <fwp_cur>
    7177:	0f 84 8b 00 00 00    	je     7208 <fwp_free_zombie+0xa8>
    717d:	48 83 ec 18          	sub    $0x18,%rsp
    7181:	48 63 05 fc bf 01 00 	movslq 0x1bffc(%rip),%rax        # 23184 <fwp_stack_pool_n>
    7188:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    718c:	83 f8 3f             	cmp    $0x3f,%eax
    718f:	7f 7f                	jg     7210 <fwp_free_zombie+0xb0>
    7191:	8d 48 01             	lea    0x1(%rax),%ecx
    7194:	89 0d ea bf 01 00    	mov    %ecx,0x1bfea(%rip)        # 23184 <fwp_stack_pool_n>
    719a:	48 8d 0d ff bf 01 00 	lea    0x1bfff(%rip),%rcx        # 231a0 <fwp_stack_pool>
    71a1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    71a5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    71ac:	66 0f ef c0          	pxor   %xmm0,%xmm0
    71b0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    71b7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    71bb:	48 85 c9             	test   %rcx,%rcx
    71be:	0f 84 fc 00 00 00    	je     72c0 <fwp_free_zombie+0x160>
    71c4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    71cb:	48 85 c0             	test   %rax,%rax
    71ce:	74 07                	je     71d7 <fwp_free_zombie+0x77>
    71d0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    71d7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    71da:	66 0f ef c0          	pxor   %xmm0,%xmm0
    71de:	48 c7 05 c7 c5 01 00 	movq   $0x0,0x1c5c7(%rip)        # 237b0 <fwp_zombie>
    71e5:	00 00 00 00 
    71e9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    71f0:	85 c0                	test   %eax,%eax
    71f2:	74 34                	je     7228 <fwp_free_zombie+0xc8>
    71f4:	83 f8 01             	cmp    $0x1,%eax
    71f7:	0f 84 b3 00 00 00    	je     72b0 <fwp_free_zombie+0x150>
    71fd:	48 83 c4 18          	add    $0x18,%rsp
    7201:	c3                   	ret
    7202:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7208:	c3                   	ret
    7209:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7210:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7214:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7219:	e8 c2 c3 ff ff       	call   35e0 <munmap@plt>
    721e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7223:	eb 80                	jmp    71a5 <fwp_free_zombie+0x45>
    7225:	0f 1f 00             	nopl   (%rax)
    7228:	48 8b 0d 89 d9 01 00 	mov    0x1d989(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    722f:	48 89 d0             	mov    %rdx,%rax
    7232:	48 2b 05 57 d9 01 00 	sub    0x1d957(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7239:	48 c1 e1 10          	shl    $0x10,%rcx
    723d:	48 39 c8             	cmp    %rcx,%rax
    7240:	73 bb                	jae    71fd <fwp_free_zombie+0x9d>
    7242:	48 89 c1             	mov    %rax,%rcx
    7245:	48 c1 e9 10          	shr    $0x10,%rcx
    7249:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    724d:	48 8b 0d 84 d9 01 00 	mov    0x1d984(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    7254:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7258:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    725c:	48 85 c9             	test   %rcx,%rcx
    725f:	74 9c                	je     71fd <fwp_free_zombie+0x9d>
    7261:	0f b6 3e             	movzbl (%rsi),%edi
    7264:	40 80 ff 02          	cmp    $0x2,%dil
    7268:	74 66                	je     72d0 <fwp_free_zombie+0x170>
    726a:	40 80 ff 01          	cmp    $0x1,%dil
    726e:	75 8d                	jne    71fd <fwp_free_zombie+0x9d>
    7270:	8b 7e 18             	mov    0x18(%rsi),%edi
    7273:	0f b7 c0             	movzwl %ax,%eax
    7276:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7279:	48 0f af c7          	imul   %rdi,%rax
    727d:	48 c1 e8 20          	shr    $0x20,%rax
    7281:	48 39 f0             	cmp    %rsi,%rax
    7284:	0f 83 73 ff ff ff    	jae    71fd <fwp_free_zombie+0x9d>
    728a:	48 01 c1             	add    %rax,%rcx
    728d:	0f b6 01             	movzbl (%rcx),%eax
    7290:	84 c0                	test   %al,%al
    7292:	0f 84 65 ff ff ff    	je     71fd <fwp_free_zombie+0x9d>
    7298:	3c 01                	cmp    $0x1,%al
    729a:	74 14                	je     72b0 <fwp_free_zombie+0x150>
    729c:	3c ff                	cmp    $0xff,%al
    729e:	74 3b                	je     72db <fwp_free_zombie+0x17b>
    72a0:	83 e8 01             	sub    $0x1,%eax
    72a3:	88 01                	mov    %al,(%rcx)
    72a5:	e9 53 ff ff ff       	jmp    71fd <fwp_free_zombie+0x9d>
    72aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    72b0:	48 89 d7             	mov    %rdx,%rdi
    72b3:	48 83 c4 18          	add    $0x18,%rsp
    72b7:	e9 c4 fd ff ff       	jmp    7080 <fwp_task_dispose>
    72bc:	0f 1f 40 00          	nopl   0x0(%rax)
    72c0:	48 89 05 c1 c4 01 00 	mov    %rax,0x1c4c1(%rip)        # 23788 <fwp_tasks_active>
    72c7:	e9 ff fe ff ff       	jmp    71cb <fwp_free_zombie+0x6b>
    72cc:	0f 1f 40 00          	nopl   0x0(%rax)
    72d0:	66 85 c0             	test   %ax,%ax
    72d3:	0f 85 24 ff ff ff    	jne    71fd <fwp_free_zombie+0x9d>
    72d9:	eb b2                	jmp    728d <fwp_free_zombie+0x12d>
    72db:	48 89 ca             	mov    %rcx,%rdx
    72de:	48 8d 35 fb c4 01 00 	lea    0x1c4fb(%rip),%rsi        # 237e0 <fwp_heap>
    72e5:	48 c1 ea 11          	shr    $0x11,%rdx
    72e9:	48 31 ca             	xor    %rcx,%rdx
    72ec:	48 89 d0             	mov    %rdx,%rax
    72ef:	48 c1 e8 09          	shr    $0x9,%rax
    72f3:	48 31 c2             	xor    %rax,%rdx
    72f6:	0f b6 d2             	movzbl %dl,%edx
    72f9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7300:	00 
    7301:	48 85 c0             	test   %rax,%rax
    7304:	75 23                	jne    7329 <fwp_free_zombie+0x1c9>
    7306:	eb 5c                	jmp    7364 <fwp_free_zombie+0x204>
    7308:	66 90                	xchg   %ax,%ax
    730a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7311:	00 00 00 00 
    7315:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    731c:	00 00 00 00 
    7320:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7324:	48 85 c0             	test   %rax,%rax
    7327:	74 3b                	je     7364 <fwp_free_zombie+0x204>
    7329:	48 89 c2             	mov    %rax,%rdx
    732c:	48 39 08             	cmp    %rcx,(%rax)
    732f:	75 ef                	jne    7320 <fwp_free_zombie+0x1c0>
    7331:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7335:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7339:	48 89 50 08          	mov    %rdx,0x8(%rax)
    733d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7344:	0f 85 b3 fe ff ff    	jne    71fd <fwp_free_zombie+0x9d>
    734a:	48 89 cf             	mov    %rcx,%rdi
    734d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7352:	e8 59 e2 ff ff       	call   55b0 <fwp_rc_forget_slot>
    7357:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    735c:	c6 01 fe             	movb   $0xfe,(%rcx)
    735f:	e9 99 fe ff ff       	jmp    71fd <fwp_free_zombie+0x9d>
    7364:	48 8d 3d 25 85 00 00 	lea    0x8525(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    736b:	e8 80 d0 ff ff       	call   43f0 <fwp_trap>

0000000000007370 <fwp_block>:
    7370:	48 83 ec 08          	sub    $0x8,%rsp
    7374:	48 8b 05 2d c4 01 00 	mov    0x1c42d(%rip),%rax        # 237a8 <fwp_ready_head>
    737b:	48 85 c0             	test   %rax,%rax
    737e:	0f 84 1c 01 00 00    	je     74a0 <fwp_block+0x130>
    7384:	90                   	nop
    7385:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    738c:	00 00 00 00 
    7390:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7397:	48 89 15 0a c4 01 00 	mov    %rdx,0x1c40a(%rip)        # 237a8 <fwp_ready_head>
    739e:	48 85 d2             	test   %rdx,%rdx
    73a1:	0f 84 19 01 00 00    	je     74c0 <fwp_block+0x150>
    73a7:	48 8b 15 12 c4 01 00 	mov    0x1c412(%rip),%rdx        # 237c0 <fwp_cur>
    73ae:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    73b2:	48 39 c2             	cmp    %rax,%rdx
    73b5:	0f 84 d5 00 00 00    	je     7490 <fwp_block+0x120>
    73bb:	48 8b 0d 86 e0 01 00 	mov    0x1e086(%rip),%rcx        # 25448 <fwp_state_owners>
    73c2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    73c6:	48 89 05 f3 c3 01 00 	mov    %rax,0x1c3f3(%rip)        # 237c0 <fwp_cur>
    73cd:	f3 0f 7e 05 9b e0 01 	movq   0x1e09b(%rip),%xmm0        # 25470 <fwp_foreign_callbacks>
    73d4:	00 
    73d5:	0f 16 05 84 e0 01 00 	movhps 0x1e084(%rip),%xmm0        # 25460 <fwp_state>
    73dc:	f3 0f 7e 0d 84 e0 01 	movq   0x1e084(%rip),%xmm1        # 25468 <fwp_handlers>
    73e3:	00 
    73e4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    73eb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    73f2:	0f 16 0d 7f e0 01 00 	movhps 0x1e07f(%rip),%xmm1        # 25478 <fwp_cleanups>
    73f9:	f3 0f 7e 05 57 e0 01 	movq   0x1e057(%rip),%xmm0        # 25458 <fwp_state_len>
    7400:	00 
    7401:	0f 16 05 48 e0 01 00 	movhps 0x1e048(%rip),%xmm0        # 25450 <fwp_state_cap>
    7408:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    740f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7416:	48 8b 70 08          	mov    0x8(%rax),%rsi
    741a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7421:	48 89 0d 40 e0 01 00 	mov    %rcx,0x1e040(%rip)        # 25468 <fwp_handlers>
    7428:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    742f:	48 89 0d 42 e0 01 00 	mov    %rcx,0x1e042(%rip)        # 25478 <fwp_cleanups>
    7436:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    743d:	48 89 0d 2c e0 01 00 	mov    %rcx,0x1e02c(%rip)        # 25470 <fwp_foreign_callbacks>
    7444:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    744b:	48 89 0d 0e e0 01 00 	mov    %rcx,0x1e00e(%rip)        # 25460 <fwp_state>
    7452:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7459:	48 89 0d f8 df 01 00 	mov    %rcx,0x1dff8(%rip)        # 25458 <fwp_state_len>
    7460:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7467:	48 89 0d e2 df 01 00 	mov    %rcx,0x1dfe2(%rip)        # 25450 <fwp_state_cap>
    746e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7475:	48 89 0d cc df 01 00 	mov    %rcx,0x1dfcc(%rip)        # 25448 <fwp_state_owners>
    747c:	e8 0f c0 ff ff       	call   3490 <swapcontext@plt>
    7481:	f3 0f 1e fa          	endbr64
    7485:	e8 d6 fc ff ff       	call   7160 <fwp_free_zombie>
    748a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7490:	8b 05 ea bc 01 00    	mov    0x1bcea(%rip),%eax        # 23180 <fwp_slice>
    7496:	85 c0                	test   %eax,%eax
    7498:	74 36                	je     74d0 <fwp_block+0x160>
    749a:	48 83 c4 08          	add    $0x8,%rsp
    749e:	c3                   	ret
    749f:	90                   	nop
    74a0:	e8 5b dd ff ff       	call   5200 <fwp_poll_events>
    74a5:	48 8b 05 fc c2 01 00 	mov    0x1c2fc(%rip),%rax        # 237a8 <fwp_ready_head>
    74ac:	48 85 c0             	test   %rax,%rax
    74af:	0f 85 db fe ff ff    	jne    7390 <fwp_block+0x20>
    74b5:	eb e9                	jmp    74a0 <fwp_block+0x130>
    74b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    74be:	00 00 
    74c0:	48 c7 05 d5 c2 01 00 	movq   $0x0,0x1c2d5(%rip)        # 237a0 <fwp_ready_tail>
    74c7:	00 00 00 00 
    74cb:	e9 d7 fe ff ff       	jmp    73a7 <fwp_block+0x37>
    74d0:	48 8d 3d ad 7c 00 00 	lea    0x7cad(%rip),%rdi        # f184 <_IO_stdin_used+0x184>
    74d7:	e8 c4 be ff ff       	call   33a0 <getenv@plt>
    74dc:	ba 10 27 00 00       	mov    $0x2710,%edx
    74e1:	48 85 c0             	test   %rax,%rax
    74e4:	74 05                	je     74eb <fwp_block+0x17b>
    74e6:	80 38 00             	cmpb   $0x0,(%rax)
    74e9:	75 0b                	jne    74f6 <fwp_block+0x186>
    74eb:	89 15 8f bc 01 00    	mov    %edx,0x1bc8f(%rip)        # 23180 <fwp_slice>
    74f1:	48 83 c4 08          	add    $0x8,%rsp
    74f5:	c3                   	ret
    74f6:	ba 0a 00 00 00       	mov    $0xa,%edx
    74fb:	31 f6                	xor    %esi,%esi
    74fd:	48 89 c7             	mov    %rax,%rdi
    7500:	e8 4b c0 ff ff       	call   3550 <strtoll@plt>
    7505:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7509:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7510:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7515:	0f 46 d0             	cmovbe %eax,%edx
    7518:	eb d1                	jmp    74eb <fwp_block+0x17b>
    751a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007520 <fwp_caps173>:
    7520:	f3 0f 1e fa          	endbr64
    7524:	85 f6                	test   %esi,%esi
    7526:	74 08                	je     7530 <fwp_caps173+0x10>
    7528:	c3                   	ret
    7529:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7530:	48 8b 15 81 d6 01 00 	mov    0x1d681(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7537:	48 89 f8             	mov    %rdi,%rax
    753a:	48 2b 05 4f d6 01 00 	sub    0x1d64f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7541:	48 c1 e2 10          	shl    $0x10,%rdx
    7545:	48 39 d0             	cmp    %rdx,%rax
    7548:	73 de                	jae    7528 <fwp_caps173+0x8>
    754a:	48 89 c2             	mov    %rax,%rdx
    754d:	48 c1 ea 10          	shr    $0x10,%rdx
    7551:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7555:	48 8b 15 7c d6 01 00 	mov    0x1d67c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    755c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7560:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7564:	48 85 c9             	test   %rcx,%rcx
    7567:	74 bf                	je     7528 <fwp_caps173+0x8>
    7569:	0f b6 32             	movzbl (%rdx),%esi
    756c:	40 80 fe 02          	cmp    $0x2,%sil
    7570:	74 2e                	je     75a0 <fwp_caps173+0x80>
    7572:	40 80 fe 01          	cmp    $0x1,%sil
    7576:	75 b0                	jne    7528 <fwp_caps173+0x8>
    7578:	8b 72 18             	mov    0x18(%rdx),%esi
    757b:	0f b7 c0             	movzwl %ax,%eax
    757e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7581:	48 0f af c6          	imul   %rsi,%rax
    7585:	48 c1 e8 20          	shr    $0x20,%rax
    7589:	48 39 d0             	cmp    %rdx,%rax
    758c:	73 9a                	jae    7528 <fwp_caps173+0x8>
    758e:	48 01 c1             	add    %rax,%rcx
    7591:	80 39 01             	cmpb   $0x1,(%rcx)
    7594:	75 92                	jne    7528 <fwp_caps173+0x8>
    7596:	e9 55 e2 ff ff       	jmp    57f0 <fwp_mem_free>
    759b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    75a0:	66 85 c0             	test   %ax,%ax
    75a3:	74 ec                	je     7591 <fwp_caps173+0x71>
    75a5:	c3                   	ret
    75a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    75ad:	00 00 00 

00000000000075b0 <fwp_args37>:
    75b0:	f3 0f 1e fa          	endbr64
    75b4:	85 d2                	test   %edx,%edx
    75b6:	74 04                	je     75bc <fwp_args37+0xc>
    75b8:	85 f6                	test   %esi,%esi
    75ba:	74 04                	je     75c0 <fwp_args37+0x10>
    75bc:	c3                   	ret
    75bd:	0f 1f 00             	nopl   (%rax)
    75c0:	48 8b 15 f1 d5 01 00 	mov    0x1d5f1(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    75c7:	48 8b 07             	mov    (%rdi),%rax
    75ca:	48 2b 05 bf d5 01 00 	sub    0x1d5bf(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    75d1:	48 c1 e2 10          	shl    $0x10,%rdx
    75d5:	48 39 d0             	cmp    %rdx,%rax
    75d8:	73 e2                	jae    75bc <fwp_args37+0xc>
    75da:	48 89 c2             	mov    %rax,%rdx
    75dd:	48 c1 ea 10          	shr    $0x10,%rdx
    75e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    75e5:	48 8b 15 ec d5 01 00 	mov    0x1d5ec(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    75ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    75f0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    75f4:	48 85 ff             	test   %rdi,%rdi
    75f7:	74 c3                	je     75bc <fwp_args37+0xc>
    75f9:	0f b6 0a             	movzbl (%rdx),%ecx
    75fc:	80 f9 02             	cmp    $0x2,%cl
    75ff:	74 2f                	je     7630 <fwp_args37+0x80>
    7601:	80 f9 01             	cmp    $0x1,%cl
    7604:	75 b6                	jne    75bc <fwp_args37+0xc>
    7606:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7609:	0f b7 c0             	movzwl %ax,%eax
    760c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    760f:	48 0f af c1          	imul   %rcx,%rax
    7613:	48 c1 e8 20          	shr    $0x20,%rax
    7617:	48 39 d0             	cmp    %rdx,%rax
    761a:	73 a0                	jae    75bc <fwp_args37+0xc>
    761c:	48 01 c7             	add    %rax,%rdi
    761f:	0f b6 07             	movzbl (%rdi),%eax
    7622:	84 c0                	test   %al,%al
    7624:	74 96                	je     75bc <fwp_args37+0xc>
    7626:	3c fd                	cmp    $0xfd,%al
    7628:	77 0c                	ja     7636 <fwp_args37+0x86>
    762a:	83 c0 01             	add    $0x1,%eax
    762d:	88 07                	mov    %al,(%rdi)
    762f:	c3                   	ret
    7630:	66 85 c0             	test   %ax,%ax
    7633:	74 ea                	je     761f <fwp_args37+0x6f>
    7635:	c3                   	ret
    7636:	e9 55 de ff ff       	jmp    5490 <fwp_rc_wide_dup>
    763b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007640 <fwp_caps37>:
    7640:	f3 0f 1e fa          	endbr64
    7644:	48 83 ec 18          	sub    $0x18,%rsp
    7648:	8b 57 04             	mov    0x4(%rdi),%edx
    764b:	48 89 f8             	mov    %rdi,%rax
    764e:	85 d2                	test   %edx,%edx
    7650:	0f 84 9a 00 00 00    	je     76f0 <fwp_caps37+0xb0>
    7656:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    765a:	85 f6                	test   %esi,%esi
    765c:	0f 85 9e 00 00 00    	jne    7700 <fwp_caps37+0xc0>
    7662:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7667:	e8 44 f7 ff ff       	call   6db0 <fwp_drop4>
    766c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7671:	48 8b 0d 40 d5 01 00 	mov    0x1d540(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    7678:	48 89 c2             	mov    %rax,%rdx
    767b:	48 2b 15 0e d5 01 00 	sub    0x1d50e(%rip),%rdx        # 24b90 <fwp_heap+0x13b0>
    7682:	48 c1 e1 10          	shl    $0x10,%rcx
    7686:	48 39 ca             	cmp    %rcx,%rdx
    7689:	73 6d                	jae    76f8 <fwp_caps37+0xb8>
    768b:	48 89 d1             	mov    %rdx,%rcx
    768e:	48 c1 e9 10          	shr    $0x10,%rcx
    7692:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7696:	48 8b 0d 3b d5 01 00 	mov    0x1d53b(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    769d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    76a1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    76a5:	48 85 f6             	test   %rsi,%rsi
    76a8:	74 4e                	je     76f8 <fwp_caps37+0xb8>
    76aa:	0f b6 39             	movzbl (%rcx),%edi
    76ad:	40 80 ff 02          	cmp    $0x2,%dil
    76b1:	0f 84 b9 00 00 00    	je     7770 <fwp_caps37+0x130>
    76b7:	40 80 ff 01          	cmp    $0x1,%dil
    76bb:	75 3b                	jne    76f8 <fwp_caps37+0xb8>
    76bd:	8b 79 18             	mov    0x18(%rcx),%edi
    76c0:	0f b7 d2             	movzwl %dx,%edx
    76c3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    76c6:	48 0f af d7          	imul   %rdi,%rdx
    76ca:	48 c1 ea 20          	shr    $0x20,%rdx
    76ce:	48 39 ca             	cmp    %rcx,%rdx
    76d1:	73 25                	jae    76f8 <fwp_caps37+0xb8>
    76d3:	48 01 d6             	add    %rdx,%rsi
    76d6:	80 3e 01             	cmpb   $0x1,(%rsi)
    76d9:	75 1d                	jne    76f8 <fwp_caps37+0xb8>
    76db:	48 89 c7             	mov    %rax,%rdi
    76de:	48 83 c4 18          	add    $0x18,%rsp
    76e2:	e9 09 e1 ff ff       	jmp    57f0 <fwp_mem_free>
    76e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    76ee:	00 00 
    76f0:	85 f6                	test   %esi,%esi
    76f2:	0f 84 79 ff ff ff    	je     7671 <fwp_caps37+0x31>
    76f8:	48 83 c4 18          	add    $0x18,%rsp
    76fc:	c3                   	ret
    76fd:	0f 1f 00             	nopl   (%rax)
    7700:	48 8b 05 b1 d4 01 00 	mov    0x1d4b1(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    7707:	48 2b 3d 82 d4 01 00 	sub    0x1d482(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    770e:	48 c1 e0 10          	shl    $0x10,%rax
    7712:	48 39 c7             	cmp    %rax,%rdi
    7715:	73 e1                	jae    76f8 <fwp_caps37+0xb8>
    7717:	48 89 f8             	mov    %rdi,%rax
    771a:	48 c1 e8 10          	shr    $0x10,%rax
    771e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7722:	48 8b 05 af d4 01 00 	mov    0x1d4af(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    7729:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    772d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7731:	48 85 c0             	test   %rax,%rax
    7734:	74 c2                	je     76f8 <fwp_caps37+0xb8>
    7736:	0f b6 0a             	movzbl (%rdx),%ecx
    7739:	80 f9 02             	cmp    $0x2,%cl
    773c:	74 42                	je     7780 <fwp_caps37+0x140>
    773e:	80 f9 01             	cmp    $0x1,%cl
    7741:	75 b5                	jne    76f8 <fwp_caps37+0xb8>
    7743:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7746:	0f b7 ff             	movzwl %di,%edi
    7749:	8b 52 1c             	mov    0x1c(%rdx),%edx
    774c:	48 0f af f9          	imul   %rcx,%rdi
    7750:	48 c1 ef 20          	shr    $0x20,%rdi
    7754:	48 39 d7             	cmp    %rdx,%rdi
    7757:	73 9f                	jae    76f8 <fwp_caps37+0xb8>
    7759:	48 01 f8             	add    %rdi,%rax
    775c:	0f b6 10             	movzbl (%rax),%edx
    775f:	84 d2                	test   %dl,%dl
    7761:	74 95                	je     76f8 <fwp_caps37+0xb8>
    7763:	80 fa fd             	cmp    $0xfd,%dl
    7766:	77 23                	ja     778b <fwp_caps37+0x14b>
    7768:	83 c2 01             	add    $0x1,%edx
    776b:	88 10                	mov    %dl,(%rax)
    776d:	eb 89                	jmp    76f8 <fwp_caps37+0xb8>
    776f:	90                   	nop
    7770:	66 85 d2             	test   %dx,%dx
    7773:	0f 85 7f ff ff ff    	jne    76f8 <fwp_caps37+0xb8>
    7779:	e9 58 ff ff ff       	jmp    76d6 <fwp_caps37+0x96>
    777e:	66 90                	xchg   %ax,%ax
    7780:	66 85 ff             	test   %di,%di
    7783:	0f 85 6f ff ff ff    	jne    76f8 <fwp_caps37+0xb8>
    7789:	eb d1                	jmp    775c <fwp_caps37+0x11c>
    778b:	48 89 c7             	mov    %rax,%rdi
    778e:	48 83 c4 18          	add    $0x18,%rsp
    7792:	e9 f9 dc ff ff       	jmp    5490 <fwp_rc_wide_dup>
    7797:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    779e:	00 00 

00000000000077a0 <fwp_drop0>:
    77a0:	f3 0f 1e fa          	endbr64
    77a4:	48 8b 15 0d d4 01 00 	mov    0x1d40d(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    77ab:	48 89 f8             	mov    %rdi,%rax
    77ae:	48 2b 05 db d3 01 00 	sub    0x1d3db(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    77b5:	48 c1 e2 10          	shl    $0x10,%rdx
    77b9:	48 39 d0             	cmp    %rdx,%rax
    77bc:	0f 83 36 01 00 00    	jae    78f8 <fwp_drop0+0x158>
    77c2:	48 83 ec 18          	sub    $0x18,%rsp
    77c6:	48 8d 35 13 c0 01 00 	lea    0x1c013(%rip),%rsi        # 237e0 <fwp_heap>
    77cd:	48 89 c2             	mov    %rax,%rdx
    77d0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    77d7:	48 c1 ea 10          	shr    $0x10,%rdx
    77db:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    77df:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    77e3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    77e7:	48 85 d2             	test   %rdx,%rdx
    77ea:	74 42                	je     782e <fwp_drop0+0x8e>
    77ec:	44 0f b6 01          	movzbl (%rcx),%r8d
    77f0:	41 80 f8 02          	cmp    $0x2,%r8b
    77f4:	74 42                	je     7838 <fwp_drop0+0x98>
    77f6:	41 80 f8 01          	cmp    $0x1,%r8b
    77fa:	75 32                	jne    782e <fwp_drop0+0x8e>
    77fc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7800:	0f b7 c0             	movzwl %ax,%eax
    7803:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7806:	49 0f af c0          	imul   %r8,%rax
    780a:	48 c1 e8 20          	shr    $0x20,%rax
    780e:	48 39 c8             	cmp    %rcx,%rax
    7811:	73 1b                	jae    782e <fwp_drop0+0x8e>
    7813:	48 01 c2             	add    %rax,%rdx
    7816:	0f b6 02             	movzbl (%rdx),%eax
    7819:	84 c0                	test   %al,%al
    781b:	74 11                	je     782e <fwp_drop0+0x8e>
    781d:	3c 01                	cmp    $0x1,%al
    781f:	74 27                	je     7848 <fwp_drop0+0xa8>
    7821:	3c ff                	cmp    $0xff,%al
    7823:	0f 84 e7 00 00 00    	je     7910 <fwp_drop0+0x170>
    7829:	83 e8 01             	sub    $0x1,%eax
    782c:	88 02                	mov    %al,(%rdx)
    782e:	48 83 c4 18          	add    $0x18,%rsp
    7832:	c3                   	ret
    7833:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7838:	66 85 c0             	test   %ax,%ax
    783b:	74 d9                	je     7816 <fwp_drop0+0x76>
    783d:	48 83 c4 18          	add    $0x18,%rsp
    7841:	c3                   	ret
    7842:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7848:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    784f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7856:	48 89 f8             	mov    %rdi,%rax
    7859:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    785d:	48 29 c8             	sub    %rcx,%rax
    7860:	48 c1 e2 10          	shl    $0x10,%rdx
    7864:	48 39 d0             	cmp    %rdx,%rax
    7867:	73 71                	jae    78da <fwp_drop0+0x13a>
    7869:	49 89 c2             	mov    %rax,%r10
    786c:	49 c1 ea 10          	shr    $0x10,%r10
    7870:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7874:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7878:	4d 8b 51 20          	mov    0x20(%r9),%r10
    787c:	4d 85 d2             	test   %r10,%r10
    787f:	74 59                	je     78da <fwp_drop0+0x13a>
    7881:	45 0f b6 19          	movzbl (%r9),%r11d
    7885:	41 80 fb 02          	cmp    $0x2,%r11b
    7889:	74 75                	je     7900 <fwp_drop0+0x160>
    788b:	41 80 fb 01          	cmp    $0x1,%r11b
    788f:	75 49                	jne    78da <fwp_drop0+0x13a>
    7891:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7895:	0f b7 c0             	movzwl %ax,%eax
    7898:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    789c:	49 0f af c3          	imul   %r11,%rax
    78a0:	48 c1 e8 20          	shr    $0x20,%rax
    78a4:	4c 39 c8             	cmp    %r9,%rax
    78a7:	73 31                	jae    78da <fwp_drop0+0x13a>
    78a9:	49 01 c2             	add    %rax,%r10
    78ac:	41 80 3a 01          	cmpb   $0x1,(%r10)
    78b0:	75 28                	jne    78da <fwp_drop0+0x13a>
    78b2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    78b7:	e8 34 df ff ff       	call   57f0 <fwp_mem_free>
    78bc:	48 8d 35 1d bf 01 00 	lea    0x1bf1d(%rip),%rsi        # 237e0 <fwp_heap>
    78c3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    78c8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    78cf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    78d6:	48 c1 e2 10          	shl    $0x10,%rdx
    78da:	4c 89 c0             	mov    %r8,%rax
    78dd:	48 29 c8             	sub    %rcx,%rax
    78e0:	48 39 d0             	cmp    %rdx,%rax
    78e3:	0f 83 45 ff ff ff    	jae    782e <fwp_drop0+0x8e>
    78e9:	4c 89 c7             	mov    %r8,%rdi
    78ec:	e9 dc fe ff ff       	jmp    77cd <fwp_drop0+0x2d>
    78f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    78f8:	c3                   	ret
    78f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7900:	66 85 c0             	test   %ax,%ax
    7903:	75 d5                	jne    78da <fwp_drop0+0x13a>
    7905:	eb a5                	jmp    78ac <fwp_drop0+0x10c>
    7907:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    790e:	00 00 
    7910:	48 89 d0             	mov    %rdx,%rax
    7913:	48 c1 e8 11          	shr    $0x11,%rax
    7917:	48 31 d0             	xor    %rdx,%rax
    791a:	48 89 c1             	mov    %rax,%rcx
    791d:	48 c1 e9 09          	shr    $0x9,%rcx
    7921:	48 31 c8             	xor    %rcx,%rax
    7924:	0f b6 c8             	movzbl %al,%ecx
    7927:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    792e:	00 
    792f:	48 85 c0             	test   %rax,%rax
    7932:	75 15                	jne    7949 <fwp_drop0+0x1a9>
    7934:	eb 4e                	jmp    7984 <fwp_drop0+0x1e4>
    7936:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    793d:	00 00 00 
    7940:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7944:	48 85 c0             	test   %rax,%rax
    7947:	74 3b                	je     7984 <fwp_drop0+0x1e4>
    7949:	48 89 c1             	mov    %rax,%rcx
    794c:	48 39 10             	cmp    %rdx,(%rax)
    794f:	75 ef                	jne    7940 <fwp_drop0+0x1a0>
    7951:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7955:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7959:	48 89 48 08          	mov    %rcx,0x8(%rax)
    795d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7964:	0f 85 c4 fe ff ff    	jne    782e <fwp_drop0+0x8e>
    796a:	48 89 d7             	mov    %rdx,%rdi
    796d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7972:	e8 39 dc ff ff       	call   55b0 <fwp_rc_forget_slot>
    7977:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    797c:	c6 02 fe             	movb   $0xfe,(%rdx)
    797f:	e9 aa fe ff ff       	jmp    782e <fwp_drop0+0x8e>
    7984:	48 8d 3d 05 7f 00 00 	lea    0x7f05(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    798b:	e8 60 ca ff ff       	call   43f0 <fwp_trap>

0000000000007990 <fwp_drop1>:
    7990:	f3 0f 1e fa          	endbr64
    7994:	48 8b 15 1d d2 01 00 	mov    0x1d21d(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    799b:	48 89 f8             	mov    %rdi,%rax
    799e:	48 2b 05 eb d1 01 00 	sub    0x1d1eb(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    79a5:	48 c1 e2 10          	shl    $0x10,%rdx
    79a9:	48 39 d0             	cmp    %rdx,%rax
    79ac:	0f 83 36 01 00 00    	jae    7ae8 <fwp_drop1+0x158>
    79b2:	48 83 ec 18          	sub    $0x18,%rsp
    79b6:	48 8d 35 23 be 01 00 	lea    0x1be23(%rip),%rsi        # 237e0 <fwp_heap>
    79bd:	48 89 c2             	mov    %rax,%rdx
    79c0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    79c7:	48 c1 ea 10          	shr    $0x10,%rdx
    79cb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    79cf:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    79d3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    79d7:	48 85 d2             	test   %rdx,%rdx
    79da:	74 42                	je     7a1e <fwp_drop1+0x8e>
    79dc:	44 0f b6 01          	movzbl (%rcx),%r8d
    79e0:	41 80 f8 02          	cmp    $0x2,%r8b
    79e4:	74 42                	je     7a28 <fwp_drop1+0x98>
    79e6:	41 80 f8 01          	cmp    $0x1,%r8b
    79ea:	75 32                	jne    7a1e <fwp_drop1+0x8e>
    79ec:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    79f0:	0f b7 c0             	movzwl %ax,%eax
    79f3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    79f6:	49 0f af c0          	imul   %r8,%rax
    79fa:	48 c1 e8 20          	shr    $0x20,%rax
    79fe:	48 39 c8             	cmp    %rcx,%rax
    7a01:	73 1b                	jae    7a1e <fwp_drop1+0x8e>
    7a03:	48 01 c2             	add    %rax,%rdx
    7a06:	0f b6 02             	movzbl (%rdx),%eax
    7a09:	84 c0                	test   %al,%al
    7a0b:	74 11                	je     7a1e <fwp_drop1+0x8e>
    7a0d:	3c 01                	cmp    $0x1,%al
    7a0f:	74 27                	je     7a38 <fwp_drop1+0xa8>
    7a11:	3c ff                	cmp    $0xff,%al
    7a13:	0f 84 e7 00 00 00    	je     7b00 <fwp_drop1+0x170>
    7a19:	83 e8 01             	sub    $0x1,%eax
    7a1c:	88 02                	mov    %al,(%rdx)
    7a1e:	48 83 c4 18          	add    $0x18,%rsp
    7a22:	c3                   	ret
    7a23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7a28:	66 85 c0             	test   %ax,%ax
    7a2b:	74 d9                	je     7a06 <fwp_drop1+0x76>
    7a2d:	48 83 c4 18          	add    $0x18,%rsp
    7a31:	c3                   	ret
    7a32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a38:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7a3f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7a46:	48 89 f8             	mov    %rdi,%rax
    7a49:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7a4d:	48 29 c8             	sub    %rcx,%rax
    7a50:	48 c1 e2 10          	shl    $0x10,%rdx
    7a54:	48 39 d0             	cmp    %rdx,%rax
    7a57:	73 71                	jae    7aca <fwp_drop1+0x13a>
    7a59:	49 89 c2             	mov    %rax,%r10
    7a5c:	49 c1 ea 10          	shr    $0x10,%r10
    7a60:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7a64:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7a68:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7a6c:	4d 85 d2             	test   %r10,%r10
    7a6f:	74 59                	je     7aca <fwp_drop1+0x13a>
    7a71:	45 0f b6 19          	movzbl (%r9),%r11d
    7a75:	41 80 fb 02          	cmp    $0x2,%r11b
    7a79:	74 75                	je     7af0 <fwp_drop1+0x160>
    7a7b:	41 80 fb 01          	cmp    $0x1,%r11b
    7a7f:	75 49                	jne    7aca <fwp_drop1+0x13a>
    7a81:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7a85:	0f b7 c0             	movzwl %ax,%eax
    7a88:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7a8c:	49 0f af c3          	imul   %r11,%rax
    7a90:	48 c1 e8 20          	shr    $0x20,%rax
    7a94:	4c 39 c8             	cmp    %r9,%rax
    7a97:	73 31                	jae    7aca <fwp_drop1+0x13a>
    7a99:	49 01 c2             	add    %rax,%r10
    7a9c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7aa0:	75 28                	jne    7aca <fwp_drop1+0x13a>
    7aa2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7aa7:	e8 44 dd ff ff       	call   57f0 <fwp_mem_free>
    7aac:	48 8d 35 2d bd 01 00 	lea    0x1bd2d(%rip),%rsi        # 237e0 <fwp_heap>
    7ab3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7ab8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7abf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7ac6:	48 c1 e2 10          	shl    $0x10,%rdx
    7aca:	4c 89 c0             	mov    %r8,%rax
    7acd:	48 29 c8             	sub    %rcx,%rax
    7ad0:	48 39 d0             	cmp    %rdx,%rax
    7ad3:	0f 83 45 ff ff ff    	jae    7a1e <fwp_drop1+0x8e>
    7ad9:	4c 89 c7             	mov    %r8,%rdi
    7adc:	e9 dc fe ff ff       	jmp    79bd <fwp_drop1+0x2d>
    7ae1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ae8:	c3                   	ret
    7ae9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7af0:	66 85 c0             	test   %ax,%ax
    7af3:	75 d5                	jne    7aca <fwp_drop1+0x13a>
    7af5:	eb a5                	jmp    7a9c <fwp_drop1+0x10c>
    7af7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7afe:	00 00 
    7b00:	48 89 d0             	mov    %rdx,%rax
    7b03:	48 c1 e8 11          	shr    $0x11,%rax
    7b07:	48 31 d0             	xor    %rdx,%rax
    7b0a:	48 89 c1             	mov    %rax,%rcx
    7b0d:	48 c1 e9 09          	shr    $0x9,%rcx
    7b11:	48 31 c8             	xor    %rcx,%rax
    7b14:	0f b6 c8             	movzbl %al,%ecx
    7b17:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7b1e:	00 
    7b1f:	48 85 c0             	test   %rax,%rax
    7b22:	75 25                	jne    7b49 <fwp_drop1+0x1b9>
    7b24:	eb 5e                	jmp    7b84 <fwp_drop1+0x1f4>
    7b26:	0f 1f 40 00          	nopl   0x0(%rax)
    7b2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7b31:	00 00 00 00 
    7b35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7b3c:	00 00 00 00 
    7b40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7b44:	48 85 c0             	test   %rax,%rax
    7b47:	74 3b                	je     7b84 <fwp_drop1+0x1f4>
    7b49:	48 89 c1             	mov    %rax,%rcx
    7b4c:	48 39 10             	cmp    %rdx,(%rax)
    7b4f:	75 ef                	jne    7b40 <fwp_drop1+0x1b0>
    7b51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7b55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7b59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7b5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7b64:	0f 85 b4 fe ff ff    	jne    7a1e <fwp_drop1+0x8e>
    7b6a:	48 89 d7             	mov    %rdx,%rdi
    7b6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7b72:	e8 39 da ff ff       	call   55b0 <fwp_rc_forget_slot>
    7b77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7b7c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7b7f:	e9 9a fe ff ff       	jmp    7a1e <fwp_drop1+0x8e>
    7b84:	48 8d 3d 05 7d 00 00 	lea    0x7d05(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    7b8b:	e8 60 c8 ff ff       	call   43f0 <fwp_trap>

0000000000007b90 <fwp_drop10>:
    7b90:	48 8b 0d 21 d0 01 00 	mov    0x1d021(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    7b97:	48 89 f8             	mov    %rdi,%rax
    7b9a:	48 2b 05 ef cf 01 00 	sub    0x1cfef(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7ba1:	48 c1 e1 10          	shl    $0x10,%rcx
    7ba5:	48 39 c8             	cmp    %rcx,%rax
    7ba8:	0f 83 c2 01 00 00    	jae    7d70 <fwp_drop10+0x1e0>
    7bae:	48 83 ec 18          	sub    $0x18,%rsp
    7bb2:	48 89 fa             	mov    %rdi,%rdx
    7bb5:	48 8d 35 24 bc 01 00 	lea    0x1bc24(%rip),%rsi        # 237e0 <fwp_heap>
    7bbc:	48 89 c1             	mov    %rax,%rcx
    7bbf:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7bc6:	48 c1 e9 10          	shr    $0x10,%rcx
    7bca:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7bce:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7bd2:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7bd6:	48 85 c9             	test   %rcx,%rcx
    7bd9:	74 46                	je     7c21 <fwp_drop10+0x91>
    7bdb:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7bdf:	41 80 f9 02          	cmp    $0x2,%r9b
    7be3:	0f 84 d7 00 00 00    	je     7cc0 <fwp_drop10+0x130>
    7be9:	41 80 f9 01          	cmp    $0x1,%r9b
    7bed:	75 32                	jne    7c21 <fwp_drop10+0x91>
    7bef:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7bf3:	0f b7 c0             	movzwl %ax,%eax
    7bf6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7bf9:	49 0f af c1          	imul   %r9,%rax
    7bfd:	48 c1 e8 20          	shr    $0x20,%rax
    7c01:	48 39 f8             	cmp    %rdi,%rax
    7c04:	73 1b                	jae    7c21 <fwp_drop10+0x91>
    7c06:	48 01 c1             	add    %rax,%rcx
    7c09:	0f b6 01             	movzbl (%rcx),%eax
    7c0c:	84 c0                	test   %al,%al
    7c0e:	74 11                	je     7c21 <fwp_drop10+0x91>
    7c10:	3c 01                	cmp    $0x1,%al
    7c12:	74 1c                	je     7c30 <fwp_drop10+0xa0>
    7c14:	3c ff                	cmp    $0xff,%al
    7c16:	0f 84 5c 01 00 00    	je     7d78 <fwp_drop10+0x1e8>
    7c1c:	83 e8 01             	sub    $0x1,%eax
    7c1f:	88 01                	mov    %al,(%rcx)
    7c21:	48 83 c4 18          	add    $0x18,%rsp
    7c25:	c3                   	ret
    7c26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7c2d:	00 00 00 
    7c30:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7c37:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7c3e:	48 89 d0             	mov    %rdx,%rax
    7c41:	49 89 d1             	mov    %rdx,%r9
    7c44:	48 c1 e1 10          	shl    $0x10,%rcx
    7c48:	48 29 f8             	sub    %rdi,%rax
    7c4b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7c4f:	78 7f                	js     7cd0 <fwp_drop10+0x140>
    7c51:	48 39 c8             	cmp    %rcx,%rax
    7c54:	73 cb                	jae    7c21 <fwp_drop10+0x91>
    7c56:	48 89 c1             	mov    %rax,%rcx
    7c59:	48 c1 e9 10          	shr    $0x10,%rcx
    7c5d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7c61:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7c65:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7c69:	48 85 f6             	test   %rsi,%rsi
    7c6c:	74 b3                	je     7c21 <fwp_drop10+0x91>
    7c6e:	0f b6 39             	movzbl (%rcx),%edi
    7c71:	40 80 ff 02          	cmp    $0x2,%dil
    7c75:	74 39                	je     7cb0 <fwp_drop10+0x120>
    7c77:	40 80 ff 01          	cmp    $0x1,%dil
    7c7b:	75 a4                	jne    7c21 <fwp_drop10+0x91>
    7c7d:	8b 79 18             	mov    0x18(%rcx),%edi
    7c80:	0f b7 c0             	movzwl %ax,%eax
    7c83:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7c86:	48 0f af c7          	imul   %rdi,%rax
    7c8a:	48 c1 e8 20          	shr    $0x20,%rax
    7c8e:	48 39 c8             	cmp    %rcx,%rax
    7c91:	73 8e                	jae    7c21 <fwp_drop10+0x91>
    7c93:	48 01 c6             	add    %rax,%rsi
    7c96:	80 3e 01             	cmpb   $0x1,(%rsi)
    7c99:	75 86                	jne    7c21 <fwp_drop10+0x91>
    7c9b:	48 89 d7             	mov    %rdx,%rdi
    7c9e:	48 83 c4 18          	add    $0x18,%rsp
    7ca2:	e9 49 db ff ff       	jmp    57f0 <fwp_mem_free>
    7ca7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7cae:	00 00 
    7cb0:	66 85 c0             	test   %ax,%ax
    7cb3:	74 e1                	je     7c96 <fwp_drop10+0x106>
    7cb5:	48 83 c4 18          	add    $0x18,%rsp
    7cb9:	c3                   	ret
    7cba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7cc0:	66 85 c0             	test   %ax,%ax
    7cc3:	0f 84 40 ff ff ff    	je     7c09 <fwp_drop10+0x79>
    7cc9:	48 83 c4 18          	add    $0x18,%rsp
    7ccd:	c3                   	ret
    7cce:	66 90                	xchg   %ax,%ax
    7cd0:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7cd4:	48 39 c8             	cmp    %rcx,%rax
    7cd7:	73 74                	jae    7d4d <fwp_drop10+0x1bd>
    7cd9:	49 89 c2             	mov    %rax,%r10
    7cdc:	49 c1 ea 10          	shr    $0x10,%r10
    7ce0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7ce4:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7ce8:	4d 8b 50 20          	mov    0x20(%r8),%r10
    7cec:	4d 85 d2             	test   %r10,%r10
    7cef:	74 5c                	je     7d4d <fwp_drop10+0x1bd>
    7cf1:	45 0f b6 18          	movzbl (%r8),%r11d
    7cf5:	41 80 fb 02          	cmp    $0x2,%r11b
    7cf9:	74 6d                	je     7d68 <fwp_drop10+0x1d8>
    7cfb:	41 80 fb 01          	cmp    $0x1,%r11b
    7cff:	75 4c                	jne    7d4d <fwp_drop10+0x1bd>
    7d01:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7d05:	0f b7 c0             	movzwl %ax,%eax
    7d08:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    7d0c:	49 0f af c3          	imul   %r11,%rax
    7d10:	48 c1 e8 20          	shr    $0x20,%rax
    7d14:	4c 39 c0             	cmp    %r8,%rax
    7d17:	73 34                	jae    7d4d <fwp_drop10+0x1bd>
    7d19:	49 01 c2             	add    %rax,%r10
    7d1c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7d20:	75 2b                	jne    7d4d <fwp_drop10+0x1bd>
    7d22:	4c 89 cf             	mov    %r9,%rdi
    7d25:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7d2a:	e8 c1 da ff ff       	call   57f0 <fwp_mem_free>
    7d2f:	48 8d 35 aa ba 01 00 	lea    0x1baaa(%rip),%rsi        # 237e0 <fwp_heap>
    7d36:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7d3b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7d42:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7d49:	48 c1 e1 10          	shl    $0x10,%rcx
    7d4d:	48 89 d0             	mov    %rdx,%rax
    7d50:	48 29 f8             	sub    %rdi,%rax
    7d53:	48 39 c8             	cmp    %rcx,%rax
    7d56:	0f 82 60 fe ff ff    	jb     7bbc <fwp_drop10+0x2c>
    7d5c:	e9 c0 fe ff ff       	jmp    7c21 <fwp_drop10+0x91>
    7d61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7d68:	66 85 c0             	test   %ax,%ax
    7d6b:	75 e0                	jne    7d4d <fwp_drop10+0x1bd>
    7d6d:	eb ad                	jmp    7d1c <fwp_drop10+0x18c>
    7d6f:	90                   	nop
    7d70:	c3                   	ret
    7d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7d78:	48 89 c8             	mov    %rcx,%rax
    7d7b:	48 c1 e8 11          	shr    $0x11,%rax
    7d7f:	48 31 c8             	xor    %rcx,%rax
    7d82:	48 89 c2             	mov    %rax,%rdx
    7d85:	48 c1 ea 09          	shr    $0x9,%rdx
    7d89:	48 31 d0             	xor    %rdx,%rax
    7d8c:	0f b6 d0             	movzbl %al,%edx
    7d8f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7d96:	00 
    7d97:	48 85 c0             	test   %rax,%rax
    7d9a:	75 0d                	jne    7da9 <fwp_drop10+0x219>
    7d9c:	eb 46                	jmp    7de4 <fwp_drop10+0x254>
    7d9e:	66 90                	xchg   %ax,%ax
    7da0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7da4:	48 85 c0             	test   %rax,%rax
    7da7:	74 3b                	je     7de4 <fwp_drop10+0x254>
    7da9:	48 89 c2             	mov    %rax,%rdx
    7dac:	48 39 08             	cmp    %rcx,(%rax)
    7daf:	75 ef                	jne    7da0 <fwp_drop10+0x210>
    7db1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7db5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7db9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7dbd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7dc4:	0f 85 57 fe ff ff    	jne    7c21 <fwp_drop10+0x91>
    7dca:	48 89 cf             	mov    %rcx,%rdi
    7dcd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7dd2:	e8 d9 d7 ff ff       	call   55b0 <fwp_rc_forget_slot>
    7dd7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7ddc:	c6 01 fe             	movb   $0xfe,(%rcx)
    7ddf:	e9 3d fe ff ff       	jmp    7c21 <fwp_drop10+0x91>
    7de4:	48 8d 3d a5 7a 00 00 	lea    0x7aa5(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    7deb:	e8 00 c6 ff ff       	call   43f0 <fwp_trap>

0000000000007df0 <f37>:
    7df0:	41 57                	push   %r15
    7df2:	41 56                	push   %r14
    7df4:	41 55                	push   %r13
    7df6:	41 54                	push   %r12
    7df8:	55                   	push   %rbp
    7df9:	53                   	push   %rbx
    7dfa:	48 83 ec 38          	sub    $0x38,%rsp
    7dfe:	48 8b 15 b3 cd 01 00 	mov    0x1cdb3(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7e05:	48 8b 0d 84 cd 01 00 	mov    0x1cd84(%rip),%rcx        # 24b90 <fwp_heap+0x13b0>
    7e0c:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7e13:	00 00 
    7e15:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7e1a:	49 89 fc             	mov    %rdi,%r12
    7e1d:	48 c1 e2 10          	shl    $0x10,%rdx
    7e21:	48 85 ff             	test   %rdi,%rdi
    7e24:	0f 84 bc 02 00 00    	je     80e6 <f37+0x2f6>
    7e2a:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7e2f:	48 89 d8             	mov    %rbx,%rax
    7e32:	48 29 c8             	sub    %rcx,%rax
    7e35:	48 39 d0             	cmp    %rdx,%rax
    7e38:	0f 83 72 03 00 00    	jae    81b0 <f37+0x3c0>
    7e3e:	48 89 c2             	mov    %rax,%rdx
    7e41:	48 c1 ea 10          	shr    $0x10,%rdx
    7e45:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e49:	48 8b 15 88 cd 01 00 	mov    0x1cd88(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    7e50:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e54:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7e58:	48 85 ff             	test   %rdi,%rdi
    7e5b:	0f 84 4f 03 00 00    	je     81b0 <f37+0x3c0>
    7e61:	0f b6 0a             	movzbl (%rdx),%ecx
    7e64:	80 f9 02             	cmp    $0x2,%cl
    7e67:	0f 84 53 02 00 00    	je     80c0 <f37+0x2d0>
    7e6d:	80 f9 01             	cmp    $0x1,%cl
    7e70:	75 24                	jne    7e96 <f37+0xa6>
    7e72:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7e75:	0f b7 c0             	movzwl %ax,%eax
    7e78:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e7b:	48 0f af c1          	imul   %rcx,%rax
    7e7f:	48 c1 e8 20          	shr    $0x20,%rax
    7e83:	48 39 d0             	cmp    %rdx,%rax
    7e86:	73 0e                	jae    7e96 <f37+0xa6>
    7e88:	48 01 c7             	add    %rax,%rdi
    7e8b:	0f b6 07             	movzbl (%rdi),%eax
    7e8e:	84 c0                	test   %al,%al
    7e90:	0f 85 ca 02 00 00    	jne    8160 <f37+0x370>
    7e96:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7e9b:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7ea0:	ba 01 00 00 00       	mov    $0x1,%edx
    7ea5:	48 85 db             	test   %rbx,%rbx
    7ea8:	74 13                	je     7ebd <f37+0xcd>
    7eaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7eb0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7eb4:	48 83 c2 01          	add    $0x1,%rdx
    7eb8:	48 85 db             	test   %rbx,%rbx
    7ebb:	75 f3                	jne    7eb0 <f37+0xc0>
    7ebd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7ec2:	48 85 c0             	test   %rax,%rax
    7ec5:	0f 84 15 03 00 00    	je     81e0 <f37+0x3f0>
    7ecb:	31 db                	xor    %ebx,%ebx
    7ecd:	0f 1f 00             	nopl   (%rax)
    7ed0:	48 8b 40 10          	mov    0x10(%rax),%rax
    7ed4:	48 83 c3 01          	add    $0x1,%rbx
    7ed8:	48 85 c0             	test   %rax,%rax
    7edb:	75 f3                	jne    7ed0 <f37+0xe0>
    7edd:	48 39 d3             	cmp    %rdx,%rbx
    7ee0:	48 0f 47 da          	cmova  %rdx,%rbx
    7ee4:	48 89 d8             	mov    %rbx,%rax
    7ee7:	48 c1 e8 3c          	shr    $0x3c,%rax
    7eeb:	0f 85 8f 03 00 00    	jne    8280 <f37+0x490>
    7ef1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7ef5:	be 02 00 00 00       	mov    $0x2,%esi
    7efa:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7f01:	00 
    7f02:	e8 e9 dd ff ff       	call   5cf0 <fwp_heap_alloc>
    7f07:	48 89 28             	mov    %rbp,(%rax)
    7f0a:	48 8b 15 a7 cc 01 00 	mov    0x1cca7(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7f11:	49 89 c6             	mov    %rax,%r14
    7f14:	48 2b 05 75 cc 01 00 	sub    0x1cc75(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7f1b:	48 c1 e2 10          	shl    $0x10,%rdx
    7f1f:	48 39 d0             	cmp    %rdx,%rax
    7f22:	73 57                	jae    7f7b <f37+0x18b>
    7f24:	48 89 c2             	mov    %rax,%rdx
    7f27:	48 c1 ea 10          	shr    $0x10,%rdx
    7f2b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7f2f:	48 8b 15 a2 cc 01 00 	mov    0x1cca2(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    7f36:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7f3a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7f3e:	48 85 ed             	test   %rbp,%rbp
    7f41:	74 38                	je     7f7b <f37+0x18b>
    7f43:	0f b6 0a             	movzbl (%rdx),%ecx
    7f46:	80 f9 02             	cmp    $0x2,%cl
    7f49:	0f 84 51 02 00 00    	je     81a0 <f37+0x3b0>
    7f4f:	80 f9 01             	cmp    $0x1,%cl
    7f52:	75 27                	jne    7f7b <f37+0x18b>
    7f54:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7f57:	0f b7 c0             	movzwl %ax,%eax
    7f5a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7f5d:	48 0f af c1          	imul   %rcx,%rax
    7f61:	48 c1 e8 20          	shr    $0x20,%rax
    7f65:	48 39 d0             	cmp    %rdx,%rax
    7f68:	73 11                	jae    7f7b <f37+0x18b>
    7f6a:	48 01 c5             	add    %rax,%rbp
    7f6d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7f71:	0f 84 d5 02 00 00    	je     824c <f37+0x45c>
    7f77:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7f7b:	48 85 db             	test   %rbx,%rbx
    7f7e:	74 5d                	je     7fdd <f37+0x1ed>
    7f80:	48 c1 e3 04          	shl    $0x4,%rbx
    7f84:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    7f89:	4c 89 f5             	mov    %r14,%rbp
    7f8c:	4d 89 e5             	mov    %r12,%r13
    7f8f:	4c 01 f3             	add    %r14,%rbx
    7f92:	0f 1f 00             	nopl   (%rax)
    7f95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7f9c:	00 00 00 00 
    7fa0:	49 8b 45 08          	mov    0x8(%r13),%rax
    7fa4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    7fa8:	48 83 c5 10          	add    $0x10,%rbp
    7fac:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    7fb1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    7fb5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    7fb9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    7fbe:	e8 fd e2 ff ff       	call   62c0 <w120>
    7fc3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    7fc8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    7fcc:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    7fd0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    7fd4:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    7fd8:	48 39 dd             	cmp    %rbx,%rbp
    7fdb:	75 c3                	jne    7fa0 <f37+0x1b0>
    7fdd:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7fe2:	e8 c9 ed ff ff       	call   6db0 <fwp_drop4>
    7fe7:	4c 89 e7             	mov    %r12,%rdi
    7fea:	e8 c1 ed ff ff       	call   6db0 <fwp_drop4>
    7fef:	4c 89 f7             	mov    %r14,%rdi
    7ff2:	e8 49 e4 ff ff       	call   6440 <w176.constprop.0>
    7ff7:	4c 89 f7             	mov    %r14,%rdi
    7ffa:	48 89 c3             	mov    %rax,%rbx
    7ffd:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8003:	e8 88 fb ff ff       	call   7b90 <fwp_drop10>
    8008:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    800e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    8013:	31 ff                	xor    %edi,%edi
    8015:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    801a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    801e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    8023:	e8 e8 dd ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    8028:	48 8b 15 89 cb 01 00 	mov    0x1cb89(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    802f:	48 89 c5             	mov    %rax,%rbp
    8032:	48 2b 05 57 cb 01 00 	sub    0x1cb57(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8039:	48 c1 e2 10          	shl    $0x10,%rdx
    803d:	48 39 d0             	cmp    %rdx,%rax
    8040:	73 55                	jae    8097 <f37+0x2a7>
    8042:	48 89 c2             	mov    %rax,%rdx
    8045:	48 c1 ea 10          	shr    $0x10,%rdx
    8049:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    804d:	48 8b 15 84 cb 01 00 	mov    0x1cb84(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8054:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8058:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    805c:	48 85 db             	test   %rbx,%rbx
    805f:	74 36                	je     8097 <f37+0x2a7>
    8061:	0f b6 0a             	movzbl (%rdx),%ecx
    8064:	80 f9 02             	cmp    $0x2,%cl
    8067:	0f 84 1b 01 00 00    	je     8188 <f37+0x398>
    806d:	80 f9 01             	cmp    $0x1,%cl
    8070:	75 25                	jne    8097 <f37+0x2a7>
    8072:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8075:	0f b7 c0             	movzwl %ax,%eax
    8078:	8b 52 1c             	mov    0x1c(%rdx),%edx
    807b:	48 0f af c1          	imul   %rcx,%rax
    807f:	48 c1 e8 20          	shr    $0x20,%rax
    8083:	48 39 d0             	cmp    %rdx,%rax
    8086:	73 0f                	jae    8097 <f37+0x2a7>
    8088:	48 01 c3             	add    %rax,%rbx
    808b:	80 3b ff             	cmpb   $0xff,(%rbx)
    808e:	0f 84 ab 01 00 00    	je     823f <f37+0x44f>
    8094:	c6 03 01             	movb   $0x1,(%rbx)
    8097:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    809c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    80a3:	00 00 
    80a5:	0f 85 d0 01 00 00    	jne    827b <f37+0x48b>
    80ab:	48 83 c4 38          	add    $0x38,%rsp
    80af:	48 89 e8             	mov    %rbp,%rax
    80b2:	5b                   	pop    %rbx
    80b3:	5d                   	pop    %rbp
    80b4:	41 5c                	pop    %r12
    80b6:	41 5d                	pop    %r13
    80b8:	41 5e                	pop    %r14
    80ba:	41 5f                	pop    %r15
    80bc:	c3                   	ret
    80bd:	0f 1f 00             	nopl   (%rax)
    80c0:	66 85 c0             	test   %ax,%ax
    80c3:	0f 85 cd fd ff ff    	jne    7e96 <f37+0xa6>
    80c9:	0f b6 07             	movzbl (%rdi),%eax
    80cc:	84 c0                	test   %al,%al
    80ce:	0f 84 c2 fd ff ff    	je     7e96 <f37+0xa6>
    80d4:	3c fd                	cmp    $0xfd,%al
    80d6:	0f 87 95 01 00 00    	ja     8271 <f37+0x481>
    80dc:	83 c0 01             	add    $0x1,%eax
    80df:	88 07                	mov    %al,(%rdi)
    80e1:	e9 b0 fd ff ff       	jmp    7e96 <f37+0xa6>
    80e6:	48 f7 d9             	neg    %rcx
    80e9:	48 39 d1             	cmp    %rdx,%rcx
    80ec:	0f 83 ee 00 00 00    	jae    81e0 <f37+0x3f0>
    80f2:	48 89 c8             	mov    %rcx,%rax
    80f5:	48 c1 e8 10          	shr    $0x10,%rax
    80f9:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    80fd:	48 8b 05 d4 ca 01 00 	mov    0x1cad4(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    8104:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8108:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    810c:	48 85 ff             	test   %rdi,%rdi
    810f:	0f 84 cb 00 00 00    	je     81e0 <f37+0x3f0>
    8115:	0f b6 02             	movzbl (%rdx),%eax
    8118:	3c 02                	cmp    $0x2,%al
    811a:	0f 84 9a 00 00 00    	je     81ba <f37+0x3ca>
    8120:	3c 01                	cmp    $0x1,%al
    8122:	0f 85 b8 00 00 00    	jne    81e0 <f37+0x3f0>
    8128:	0f b7 c1             	movzwl %cx,%eax
    812b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    812e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8131:	48 0f af c1          	imul   %rcx,%rax
    8135:	48 c1 e8 20          	shr    $0x20,%rax
    8139:	48 39 d0             	cmp    %rdx,%rax
    813c:	0f 83 9e 00 00 00    	jae    81e0 <f37+0x3f0>
    8142:	48 01 c7             	add    %rax,%rdi
    8145:	0f b6 07             	movzbl (%rdi),%eax
    8148:	84 c0                	test   %al,%al
    814a:	0f 84 90 00 00 00    	je     81e0 <f37+0x3f0>
    8150:	31 db                	xor    %ebx,%ebx
    8152:	0f 1f 00             	nopl   (%rax)
    8155:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    815c:	00 00 00 00 
    8160:	3c fd                	cmp    $0xfd,%al
    8162:	0f 87 f1 00 00 00    	ja     8259 <f37+0x469>
    8168:	83 c0 01             	add    $0x1,%eax
    816b:	88 07                	mov    %al,(%rdi)
    816d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8172:	31 d2                	xor    %edx,%edx
    8174:	4d 85 e4             	test   %r12,%r12
    8177:	0f 85 1e fd ff ff    	jne    7e9b <f37+0xab>
    817d:	e9 3b fd ff ff       	jmp    7ebd <f37+0xcd>
    8182:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8188:	66 85 c0             	test   %ax,%ax
    818b:	0f 85 06 ff ff ff    	jne    8097 <f37+0x2a7>
    8191:	e9 f5 fe ff ff       	jmp    808b <f37+0x29b>
    8196:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    819d:	00 00 00 
    81a0:	66 85 c0             	test   %ax,%ax
    81a3:	0f 85 d2 fd ff ff    	jne    7f7b <f37+0x18b>
    81a9:	e9 bf fd ff ff       	jmp    7f6d <f37+0x17d>
    81ae:	66 90                	xchg   %ax,%ax
    81b0:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    81b5:	e9 e6 fc ff ff       	jmp    7ea0 <f37+0xb0>
    81ba:	66 85 c9             	test   %cx,%cx
    81bd:	75 21                	jne    81e0 <f37+0x3f0>
    81bf:	0f b6 07             	movzbl (%rdi),%eax
    81c2:	84 c0                	test   %al,%al
    81c4:	74 1a                	je     81e0 <f37+0x3f0>
    81c6:	3c fd                	cmp    $0xfd,%al
    81c8:	0f 87 be 00 00 00    	ja     828c <f37+0x49c>
    81ce:	83 c0 01             	add    $0x1,%eax
    81d1:	88 07                	mov    %al,(%rdi)
    81d3:	66 90                	xchg   %ax,%ax
    81d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    81dc:	00 00 00 00 
    81e0:	be 02 00 00 00       	mov    $0x2,%esi
    81e5:	bf 08 00 00 00       	mov    $0x8,%edi
    81ea:	e8 01 db ff ff       	call   5cf0 <fwp_heap_alloc>
    81ef:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    81f6:	48 8b 15 bb c9 01 00 	mov    0x1c9bb(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    81fd:	49 89 c6             	mov    %rax,%r14
    8200:	48 2b 05 89 c9 01 00 	sub    0x1c989(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8207:	48 c1 e2 10          	shl    $0x10,%rdx
    820b:	48 39 d0             	cmp    %rdx,%rax
    820e:	73 53                	jae    8263 <f37+0x473>
    8210:	48 89 c2             	mov    %rax,%rdx
    8213:	48 c1 ea 10          	shr    $0x10,%rdx
    8217:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    821b:	48 8b 15 b6 c9 01 00 	mov    0x1c9b6(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8222:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8226:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    822a:	48 85 ed             	test   %rbp,%rbp
    822d:	74 34                	je     8263 <f37+0x473>
    822f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8236:	00 00 
    8238:	31 db                	xor    %ebx,%ebx
    823a:	e9 04 fd ff ff       	jmp    7f43 <f37+0x153>
    823f:	48 89 df             	mov    %rbx,%rdi
    8242:	e8 69 d3 ff ff       	call   55b0 <fwp_rc_forget_slot>
    8247:	e9 48 fe ff ff       	jmp    8094 <f37+0x2a4>
    824c:	48 89 ef             	mov    %rbp,%rdi
    824f:	e8 5c d3 ff ff       	call   55b0 <fwp_rc_forget_slot>
    8254:	e9 1e fd ff ff       	jmp    7f77 <f37+0x187>
    8259:	e8 32 d2 ff ff       	call   5490 <fwp_rc_wide_dup>
    825e:	e9 0a ff ff ff       	jmp    816d <f37+0x37d>
    8263:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    826a:	00 00 
    826c:	e9 6c fd ff ff       	jmp    7fdd <f37+0x1ed>
    8271:	e8 1a d2 ff ff       	call   5490 <fwp_rc_wide_dup>
    8276:	e9 1b fc ff ff       	jmp    7e96 <f37+0xa6>
    827b:	e8 e0 b1 ff ff       	call   3460 <__stack_chk_fail@plt>
    8280:	48 8d 3d 09 6f 00 00 	lea    0x6f09(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    8287:	e8 64 c1 ff ff       	call   43f0 <fwp_trap>
    828c:	e8 ff d1 ff ff       	call   5490 <fwp_rc_wide_dup>
    8291:	e9 4a ff ff ff       	jmp    81e0 <f37+0x3f0>
    8296:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    829d:	00 00 00 

00000000000082a0 <fwp_owned_entry37>:
    82a0:	f3 0f 1e fa          	endbr64
    82a4:	48 8b 3f             	mov    (%rdi),%rdi
    82a7:	e9 44 fb ff ff       	jmp    7df0 <f37>
    82ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000082b0 <e37>:
    82b0:	f3 0f 1e fa          	endbr64
    82b4:	53                   	push   %rbx
    82b5:	48 8b 1f             	mov    (%rdi),%rbx
    82b8:	48 89 df             	mov    %rbx,%rdi
    82bb:	e8 20 e2 ff ff       	call   64e0 <fwp_rc_share>
    82c0:	48 89 df             	mov    %rbx,%rdi
    82c3:	e8 28 fb ff ff       	call   7df0 <f37>
    82c8:	48 89 c3             	mov    %rax,%rbx
    82cb:	48 89 c7             	mov    %rax,%rdi
    82ce:	e8 0d e2 ff ff       	call   64e0 <fwp_rc_share>
    82d3:	48 89 d8             	mov    %rbx,%rax
    82d6:	5b                   	pop    %rbx
    82d7:	c3                   	ret
    82d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    82df:	00 

00000000000082e0 <fwp_write>:
    82e0:	41 57                	push   %r15
    82e2:	41 56                	push   %r14
    82e4:	41 55                	push   %r13
    82e6:	41 54                	push   %r12
    82e8:	55                   	push   %rbp
    82e9:	53                   	push   %rbx
    82ea:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    82f1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    82f8:	00 00 
    82fa:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8301:	00 
    8302:	49 89 d4             	mov    %rdx,%r12
    8305:	8b 12                	mov    (%rdx),%edx
    8307:	83 fa 19             	cmp    $0x19,%edx
    830a:	77 6a                	ja     8376 <fwp_write+0x96>
    830c:	48 89 f5             	mov    %rsi,%rbp
    830f:	89 d0                	mov    %edx,%eax
    8311:	89 ce                	mov    %ecx,%esi
    8313:	48 89 fb             	mov    %rdi,%rbx
    8316:	48 8d 0d e3 77 00 00 	lea    0x77e3(%rip),%rcx        # fb00 <_IO_stdin_used+0xb00>
    831d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8321:	48 01 c8             	add    %rcx,%rax
    8324:	3e ff e0             	notrack jmp *%rax
    8327:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    832e:	00 00 
    8330:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8334:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8338:	48 89 ca             	mov    %rcx,%rdx
    833b:	48 85 c9             	test   %rcx,%rcx
    833e:	0f 88 9c 0c 00 00    	js     8fe0 <fwp_write+0xd00>
    8344:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    834b:	00 
    834c:	48 89 c6             	mov    %rax,%rsi
    834f:	4c 89 e7             	mov    %r12,%rdi
    8352:	e8 e9 b6 ff ff       	call   3a40 <fwp_fmt_u128>
    8357:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    835e:	00 00 
    8360:	4c 89 e7             	mov    %r12,%rdi
    8363:	e8 e8 b0 ff ff       	call   3450 <strlen@plt>
    8368:	4c 89 e6             	mov    %r12,%rsi
    836b:	48 89 df             	mov    %rbx,%rdi
    836e:	48 89 c2             	mov    %rax,%rdx
    8371:	e8 9a be ff ff       	call   4210 <buf_put>
    8376:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    837d:	00 
    837e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8385:	00 00 
    8387:	0f 85 28 04 00 00    	jne    87b5 <fwp_write+0x4d5>
    838d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8394:	5b                   	pop    %rbx
    8395:	5d                   	pop    %rbp
    8396:	41 5c                	pop    %r12
    8398:	41 5d                	pop    %r13
    839a:	41 5e                	pop    %r14
    839c:	41 5f                	pop    %r15
    839e:	c3                   	ret
    839f:	90                   	nop
    83a0:	49 89 e9             	mov    %rbp,%r9
    83a3:	4c 8d 05 cb 6c 00 00 	lea    0x6ccb(%rip),%r8        # f075 <_IO_stdin_used+0x75>
    83aa:	b9 00 02 00 00       	mov    $0x200,%ecx
    83af:	ba 02 00 00 00       	mov    $0x2,%edx
    83b4:	be 00 02 00 00       	mov    $0x200,%esi
    83b9:	31 c0                	xor    %eax,%eax
    83bb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    83c2:	00 
    83c3:	e8 e8 af ff ff       	call   33b0 <__snprintf_chk@plt>
    83c8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    83cf:	00 
    83d0:	e8 7b b0 ff ff       	call   3450 <strlen@plt>
    83d5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    83dc:	00 
    83dd:	48 89 df             	mov    %rbx,%rdi
    83e0:	48 89 c2             	mov    %rax,%rdx
    83e3:	e8 28 be ff ff       	call   4210 <buf_put>
    83e8:	eb 8c                	jmp    8376 <fwp_write+0x96>
    83ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    83f0:	49 89 e9             	mov    %rbp,%r9
    83f3:	4c 8d 05 bb 6d 00 00 	lea    0x6dbb(%rip),%r8        # f1b5 <_IO_stdin_used+0x1b5>
    83fa:	eb ae                	jmp    83aa <fwp_write+0xca>
    83fc:	0f 1f 40 00          	nopl   0x0(%rax)
    8400:	83 fa 13             	cmp    $0x13,%edx
    8403:	48 8d 05 a1 6d 00 00 	lea    0x6da1(%rip),%rax        # f1ab <_IO_stdin_used+0x1ab>
    840a:	48 8d 35 9f 6d 00 00 	lea    0x6d9f(%rip),%rsi        # f1b0 <_IO_stdin_used+0x1b0>
    8411:	ba 04 00 00 00       	mov    $0x4,%edx
    8416:	48 0f 44 f0          	cmove  %rax,%rsi
    841a:	45 31 ed             	xor    %r13d,%r13d
    841d:	e8 ee bd ff ff       	call   4210 <buf_put>
    8422:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8427:	0f 84 a3 08 00 00    	je     8cd0 <fwp_write+0x9f0>
    842d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8432:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8437:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    843c:	48 89 df             	mov    %rbx,%rdi
    843f:	49 0f 44 c5          	cmove  %r13,%rax
    8443:	31 c9                	xor    %ecx,%ecx
    8445:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    844a:	e8 91 fe ff ff       	call   82e0 <fwp_write>
    844f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8454:	0f 84 6e 09 00 00    	je     8dc8 <fwp_write+0xae8>
    845a:	49 83 c5 01          	add    $0x1,%r13
    845e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8462:	0f 83 68 08 00 00    	jae    8cd0 <fwp_write+0x9f0>
    8468:	ba 02 00 00 00       	mov    $0x2,%edx
    846d:	48 8d 35 81 6d 00 00 	lea    0x6d81(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8474:	48 89 df             	mov    %rbx,%rdi
    8477:	e8 94 bd ff ff       	call   4210 <buf_put>
    847c:	eb af                	jmp    842d <fwp_write+0x14d>
    847e:	66 90                	xchg   %ax,%ax
    8480:	ba 06 00 00 00       	mov    $0x6,%edx
    8485:	48 8d 35 42 6d 00 00 	lea    0x6d42(%rip),%rsi        # f1ce <_IO_stdin_used+0x1ce>
    848c:	48 83 c5 10          	add    $0x10,%rbp
    8490:	e8 7b bd ff ff       	call   4210 <buf_put>
    8495:	48 89 ef             	mov    %rbp,%rdi
    8498:	e8 b3 af ff ff       	call   3450 <strlen@plt>
    849d:	48 89 ee             	mov    %rbp,%rsi
    84a0:	48 89 df             	mov    %rbx,%rdi
    84a3:	48 89 c2             	mov    %rax,%rdx
    84a6:	e8 65 bd ff ff       	call   4210 <buf_put>
    84ab:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    84b0:	ba 01 00 00 00       	mov    $0x1,%edx
    84b5:	48 89 df             	mov    %rbx,%rdi
    84b8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    84bd:	e8 4e bd ff ff       	call   4210 <buf_put>
    84c2:	e9 af fe ff ff       	jmp    8376 <fwp_write+0x96>
    84c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    84ce:	00 00 
    84d0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    84d7:	00 
    84d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    84df:	00 00 
    84e1:	0f 85 ce 02 00 00    	jne    87b5 <fwp_write+0x4d5>
    84e7:	ba 0a 00 00 00       	mov    $0xa,%edx
    84ec:	48 8d 35 c7 6c 00 00 	lea    0x6cc7(%rip),%rsi        # f1ba <_IO_stdin_used+0x1ba>
    84f3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    84fa:	48 89 df             	mov    %rbx,%rdi
    84fd:	5b                   	pop    %rbx
    84fe:	5d                   	pop    %rbp
    84ff:	41 5c                	pop    %r12
    8501:	41 5d                	pop    %r13
    8503:	41 5e                	pop    %r14
    8505:	41 5f                	pop    %r15
    8507:	e9 04 bd ff ff       	jmp    4210 <buf_put>
    850c:	0f 1f 40 00          	nopl   0x0(%rax)
    8510:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8515:	4d 85 ed             	test   %r13,%r13
    8518:	0f 84 02 0c 00 00    	je     9120 <fwp_write+0xe40>
    851e:	48 8d 35 dd 6c 00 00 	lea    0x6cdd(%rip),%rsi        # f202 <_IO_stdin_used+0x202>
    8525:	4c 89 ef             	mov    %r13,%rdi
    8528:	e8 03 b0 ff ff       	call   3530 <strcmp@plt>
    852d:	41 89 c1             	mov    %eax,%r9d
    8530:	85 c0                	test   %eax,%eax
    8532:	0f 84 6c 0c 00 00    	je     91a4 <fwp_write+0xec4>
    8538:	4c 89 ef             	mov    %r13,%rdi
    853b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8540:	e8 0b af ff ff       	call   3450 <strlen@plt>
    8545:	4c 89 ee             	mov    %r13,%rsi
    8548:	48 89 df             	mov    %rbx,%rdi
    854b:	48 89 c2             	mov    %rax,%rdx
    854e:	e8 bd bc ff ff       	call   4210 <buf_put>
    8553:	ba 01 00 00 00       	mov    $0x1,%edx
    8558:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    855d:	48 89 df             	mov    %rbx,%rdi
    8560:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8565:	e8 a6 bc ff ff       	call   4210 <buf_put>
    856a:	ba 01 00 00 00       	mov    $0x1,%edx
    856f:	4c 89 fe             	mov    %r15,%rsi
    8572:	48 89 df             	mov    %rbx,%rdi
    8575:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    857a:	e8 91 bc ff ff       	call   4210 <buf_put>
    857f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8584:	45 31 f6             	xor    %r14d,%r14d
    8587:	85 d2                	test   %edx,%edx
    8589:	0f 8e 81 0a 00 00    	jle    9010 <fwp_write+0xd30>
    858f:	45 31 ed             	xor    %r13d,%r13d
    8592:	4d 85 ed             	test   %r13,%r13
    8595:	0f 85 75 07 00 00    	jne    8d10 <fwp_write+0xa30>
    859b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    85a2:	00 
    85a3:	45 85 f6             	test   %r14d,%r14d
    85a6:	0f 84 84 07 00 00    	je     8d30 <fwp_write+0xa50>
    85ac:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    85b1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    85b6:	48 89 df             	mov    %rbx,%rdi
    85b9:	49 83 c5 01          	add    $0x1,%r13
    85bd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    85c1:	31 c9                	xor    %ecx,%ecx
    85c3:	e8 18 fd ff ff       	call   82e0 <fwp_write>
    85c8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    85cd:	7f c3                	jg     8592 <fwp_write+0x2b2>
    85cf:	45 85 f6             	test   %r14d,%r14d
    85d2:	0f 84 38 0a 00 00    	je     9010 <fwp_write+0xd30>
    85d8:	b8 29 00 00 00       	mov    $0x29,%eax
    85dd:	ba 01 00 00 00       	mov    $0x1,%edx
    85e2:	4c 89 fe             	mov    %r15,%rsi
    85e5:	48 89 df             	mov    %rbx,%rdi
    85e8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    85ec:	e8 1f bc ff ff       	call   4210 <buf_put>
    85f1:	e9 80 fd ff ff       	jmp    8376 <fwp_write+0x96>
    85f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    85fd:	00 00 00 
    8600:	ba 01 00 00 00       	mov    $0x1,%edx
    8605:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    860a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    860f:	e8 fc bb ff ff       	call   4210 <buf_put>
    8614:	48 85 ed             	test   %rbp,%rbp
    8617:	0f 84 93 06 00 00    	je     8cb0 <fwp_write+0x9d0>
    861d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8621:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8626:	31 c9                	xor    %ecx,%ecx
    8628:	48 89 df             	mov    %rbx,%rdi
    862b:	e8 b0 fc ff ff       	call   82e0 <fwp_write>
    8630:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8634:	48 85 ed             	test   %rbp,%rbp
    8637:	0f 84 73 06 00 00    	je     8cb0 <fwp_write+0x9d0>
    863d:	ba 02 00 00 00       	mov    $0x2,%edx
    8642:	48 8d 35 ac 6b 00 00 	lea    0x6bac(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8649:	48 89 df             	mov    %rbx,%rdi
    864c:	e8 bf bb ff ff       	call   4210 <buf_put>
    8651:	eb ca                	jmp    861d <fwp_write+0x33d>
    8653:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8658:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    865c:	85 f6                	test   %esi,%esi
    865e:	0f 84 fc 07 00 00    	je     8e60 <fwp_write+0xb80>
    8664:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    866b:	00 
    866c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8673:	00 00 
    8675:	0f 85 3a 01 00 00    	jne    87b5 <fwp_write+0x4d5>
    867b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    867f:	4c 89 ea             	mov    %r13,%rdx
    8682:	e9 6c fe ff ff       	jmp    84f3 <fwp_write+0x213>
    8687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    868e:	00 00 
    8690:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8695:	ba 01 00 00 00       	mov    $0x1,%edx
    869a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    869f:	48 89 ee             	mov    %rbp,%rsi
    86a2:	e8 69 bb ff ff       	call   4210 <buf_put>
    86a7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    86ac:	4c 89 e7             	mov    %r12,%rdi
    86af:	e8 9c ad ff ff       	call   3450 <strlen@plt>
    86b4:	4c 89 e6             	mov    %r12,%rsi
    86b7:	48 89 df             	mov    %rbx,%rdi
    86ba:	48 89 c2             	mov    %rax,%rdx
    86bd:	e8 4e bb ff ff       	call   4210 <buf_put>
    86c2:	ba 01 00 00 00       	mov    $0x1,%edx
    86c7:	48 89 ee             	mov    %rbp,%rsi
    86ca:	48 89 df             	mov    %rbx,%rdi
    86cd:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    86d2:	e8 39 bb ff ff       	call   4210 <buf_put>
    86d7:	e9 9a fc ff ff       	jmp    8376 <fwp_write+0x96>
    86dc:	0f 1f 40 00          	nopl   0x0(%rax)
    86e0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    86e5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    86e9:	0f 8a 8e 0b 00 00    	jp     927d <fwp_write+0xf9d>
    86ef:	66 0f 28 c1          	movapd %xmm1,%xmm0
    86f3:	66 0f 54 05 45 75 00 	andpd  0x7545(%rip),%xmm0        # fc40 <msg.8+0xd0>
    86fa:	00 
    86fb:	bd 01 00 00 00       	mov    $0x1,%ebp
    8700:	66 0f 2e 05 a0 74 00 	ucomisd 0x74a0(%rip),%xmm0        # fba8 <msg.8+0x38>
    8707:	00 
    8708:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    870f:	00 
    8710:	0f 87 b2 09 00 00    	ja     90c8 <fwp_write+0xde8>
    8716:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    871d:	00 00 00 
    8720:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8724:	89 ee                	mov    %ebp,%esi
    8726:	4c 89 e7             	mov    %r12,%rdi
    8729:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    872e:	e8 dd bf ff ff       	call   4710 <fwp_format_g.constprop.0>
    8733:	31 f6                	xor    %esi,%esi
    8735:	4c 89 e7             	mov    %r12,%rdi
    8738:	e8 d3 ac ff ff       	call   3410 <strtod@plt>
    873d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8742:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8746:	7a 06                	jp     874e <fwp_write+0x46e>
    8748:	0f 84 e9 01 00 00    	je     8937 <fwp_write+0x657>
    874e:	83 c5 01             	add    $0x1,%ebp
    8751:	83 fd 12             	cmp    $0x12,%ebp
    8754:	75 ca                	jne    8720 <fwp_write+0x440>
    8756:	be 11 00 00 00       	mov    $0x11,%esi
    875b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    875f:	4c 89 e7             	mov    %r12,%rdi
    8762:	e8 a9 bf ff ff       	call   4710 <fwp_format_g.constprop.0>
    8767:	e9 cb 01 00 00       	jmp    8937 <fwp_write+0x657>
    876c:	0f 1f 40 00          	nopl   0x0(%rax)
    8770:	48 83 fd 01          	cmp    $0x1,%rbp
    8774:	0f 84 e6 08 00 00    	je     9060 <fwp_write+0xd80>
    877a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    877e:	b8 02 00 00 00       	mov    $0x2,%eax
    8783:	ba 01 00 00 00       	mov    $0x1,%edx
    8788:	48 0f 44 d0          	cmove  %rax,%rdx
    878c:	48 8d 35 10 6a 00 00 	lea    0x6a10(%rip),%rsi        # f1a3 <_IO_stdin_used+0x1a3>
    8793:	48 8d 05 0e 6a 00 00 	lea    0x6a0e(%rip),%rax        # f1a8 <_IO_stdin_used+0x1a8>
    879a:	48 0f 44 f0          	cmove  %rax,%rsi
    879e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    87a5:	00 
    87a6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    87ad:	00 00 
    87af:	0f 84 3e fd ff ff    	je     84f3 <fwp_write+0x213>
    87b5:	e8 a6 ac ff ff       	call   3460 <__stack_chk_fail@plt>
    87ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    87c0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    87c5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    87ca:	e8 81 b9 ff ff       	call   4150 <buf_grow>
    87cf:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    87d3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    87d9:	4c 03 0b             	add    (%rbx),%r9
    87dc:	66 45 89 11          	mov    %r10w,(%r9)
    87e0:	45 85 e4             	test   %r12d,%r12d
    87e3:	0f 8e 07 05 00 00    	jle    8cf0 <fwp_write+0xa10>
    87e9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    87f0:	55 55 55 
    87f3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    87f8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    87ff:	aa aa aa 
    8802:	49 83 c1 01          	add    $0x1,%r9
    8806:	eb 45                	jmp    884d <fwp_write+0x56d>
    8808:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    880f:	00 
    8810:	be 01 00 00 00       	mov    $0x1,%esi
    8815:	b8 2d 00 00 00       	mov    $0x2d,%eax
    881a:	88 07                	mov    %al,(%rdi)
    881c:	48 89 e8             	mov    %rbp,%rax
    881f:	49 f7 e8             	imul   %r8
    8822:	48 89 e8             	mov    %rbp,%rax
    8825:	48 c1 f8 3f          	sar    $0x3f,%rax
    8829:	48 29 c2             	sub    %rax,%rdx
    882c:	48 85 c9             	test   %rcx,%rcx
    882f:	0f 95 c0             	setne  %al
    8832:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8836:	48 83 ef 01          	sub    $0x1,%rdi
    883a:	48 21 c5             	and    %rax,%rbp
    883d:	48 29 ea             	sub    %rbp,%rdx
    8840:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8844:	49 39 f9             	cmp    %rdi,%r9
    8847:	0f 84 a3 04 00 00    	je     8cf0 <fwp_write+0xa10>
    884d:	48 89 e8             	mov    %rbp,%rax
    8850:	49 f7 e8             	imul   %r8
    8853:	48 89 e8             	mov    %rbp,%rax
    8856:	48 c1 f8 3f          	sar    $0x3f,%rax
    885a:	48 89 d1             	mov    %rdx,%rcx
    885d:	48 29 c1             	sub    %rax,%rcx
    8860:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8864:	48 89 e9             	mov    %rbp,%rcx
    8867:	48 29 c1             	sub    %rax,%rcx
    886a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    886e:	49 f7 e2             	mul    %r10
    8871:	b8 30 00 00 00       	mov    $0x30,%eax
    8876:	48 89 d6             	mov    %rdx,%rsi
    8879:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    887d:	48 d1 ee             	shr    $1,%rsi
    8880:	48 01 f2             	add    %rsi,%rdx
    8883:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8887:	48 29 d6             	sub    %rdx,%rsi
    888a:	74 8e                	je     881a <fwp_write+0x53a>
    888c:	48 83 fe 01          	cmp    $0x1,%rsi
    8890:	0f 85 7a ff ff ff    	jne    8810 <fwp_write+0x530>
    8896:	31 f6                	xor    %esi,%esi
    8898:	b8 2b 00 00 00       	mov    $0x2b,%eax
    889d:	e9 78 ff ff ff       	jmp    881a <fwp_write+0x53a>
    88a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    88a8:	66 0f 6e cd          	movd   %ebp,%xmm1
    88ac:	0f 2e c9             	ucomiss %xmm1,%xmm1
    88af:	0f 8a c8 09 00 00    	jp     927d <fwp_write+0xf9d>
    88b5:	0f 28 c1             	movaps %xmm1,%xmm0
    88b8:	0f 54 05 71 73 00 00 	andps  0x7371(%rip),%xmm0        # fc30 <msg.8+0xc0>
    88bf:	0f 2e 05 3e 67 00 00 	ucomiss 0x673e(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    88c6:	0f 87 24 08 00 00    	ja     90f0 <fwp_write+0xe10>
    88cc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    88d0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    88d6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    88dd:	00 
    88de:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    88e2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    88e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    88ee:	00 00 
    88f0:	44 89 ee             	mov    %r13d,%esi
    88f3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    88f8:	4c 89 e7             	mov    %r12,%rdi
    88fb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8900:	e8 0b be ff ff       	call   4710 <fwp_format_g.constprop.0>
    8905:	31 f6                	xor    %esi,%esi
    8907:	4c 89 e7             	mov    %r12,%rdi
    890a:	e8 a1 ab ff ff       	call   34b0 <strtof@plt>
    890f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8914:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8917:	7a 02                	jp     891b <fwp_write+0x63b>
    8919:	74 1c                	je     8937 <fwp_write+0x657>
    891b:	41 83 c5 01          	add    $0x1,%r13d
    891f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8923:	75 cb                	jne    88f0 <fwp_write+0x610>
    8925:	be 09 00 00 00       	mov    $0x9,%esi
    892a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    892f:	4c 89 e7             	mov    %r12,%rdi
    8932:	e8 d9 bd ff ff       	call   4710 <fwp_format_g.constprop.0>
    8937:	4c 89 e7             	mov    %r12,%rdi
    893a:	e8 41 ba ff ff       	call   4380 <fwp_finish_float>
    893f:	e9 1c fa ff ff       	jmp    8360 <fwp_write+0x80>
    8944:	0f 1f 40 00          	nopl   0x0(%rax)
    8948:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    894c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8950:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8957:	00 
    8958:	48 89 ef             	mov    %rbp,%rdi
    895b:	e8 e0 b0 ff ff       	call   3a40 <fwp_fmt_u128>
    8960:	48 89 ef             	mov    %rbp,%rdi
    8963:	e8 e8 aa ff ff       	call   3450 <strlen@plt>
    8968:	48 89 ee             	mov    %rbp,%rsi
    896b:	48 89 df             	mov    %rbx,%rdi
    896e:	48 89 c2             	mov    %rax,%rdx
    8971:	e8 9a b8 ff ff       	call   4210 <buf_put>
    8976:	e9 fb f9 ff ff       	jmp    8376 <fwp_write+0x96>
    897b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8980:	ba 06 00 00 00       	mov    $0x6,%edx
    8985:	48 8d 35 6c 68 00 00 	lea    0x686c(%rip),%rsi        # f1f8 <_IO_stdin_used+0x1f8>
    898c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8992:	e8 79 b8 ff ff       	call   4210 <buf_put>
    8997:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    899e:	ff ff 7f 
    89a1:	48 23 55 00          	and    0x0(%rbp),%rdx
    89a5:	0f 84 86 02 00 00    	je     8c31 <fwp_write+0x951>
    89ab:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    89b0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    89b4:	48 85 d2             	test   %rdx,%rdx
    89b7:	0f 84 ae 00 00 00    	je     8a6b <fwp_write+0x78b>
    89bd:	8b 0a                	mov    (%rdx),%ecx
    89bf:	83 f9 1c             	cmp    $0x1c,%ecx
    89c2:	0f 84 58 06 00 00    	je     9020 <fwp_write+0xd40>
    89c8:	83 f9 1b             	cmp    $0x1b,%ecx
    89cb:	0f 87 9a 00 00 00    	ja     8a6b <fwp_write+0x78b>
    89d1:	be 01 00 00 00       	mov    $0x1,%esi
    89d6:	48 d3 e6             	shl    %cl,%rsi
    89d9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    89df:	0f 85 4b 04 00 00    	jne    8e30 <fwp_write+0xb50>
    89e5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    89eb:	0f 85 0f 04 00 00    	jne    8e00 <fwp_write+0xb20>
    89f1:	83 e6 21             	and    $0x21,%esi
    89f4:	74 75                	je     8a6b <fwp_write+0x78b>
    89f6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    89fb:	48 85 ff             	test   %rdi,%rdi
    89fe:	79 07                	jns    8a07 <fwp_write+0x727>
    8a00:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8a04:	4c 01 ee             	add    %r13,%rsi
    8a07:	48 0f be 3e          	movsbq (%rsi),%rdi
    8a0b:	85 c9                	test   %ecx,%ecx
    8a0d:	40 0f b6 f7          	movzbl %dil,%esi
    8a11:	48 0f 44 f7          	cmove  %rdi,%rsi
    8a15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8a1c:	00 00 00 00 
    8a20:	31 c9                	xor    %ecx,%ecx
    8a22:	48 89 df             	mov    %rbx,%rdi
    8a25:	49 83 c5 01          	add    $0x1,%r13
    8a29:	e8 b2 f8 ff ff       	call   82e0 <fwp_write>
    8a2e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8a35:	ff ff 7f 
    8a38:	48 23 55 00          	and    0x0(%rbp),%rdx
    8a3c:	49 39 d5             	cmp    %rdx,%r13
    8a3f:	0f 83 ec 01 00 00    	jae    8c31 <fwp_write+0x951>
    8a45:	ba 02 00 00 00       	mov    $0x2,%edx
    8a4a:	48 89 df             	mov    %rbx,%rdi
    8a4d:	48 8d 35 a1 67 00 00 	lea    0x67a1(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8a54:	e8 b7 b7 ff ff       	call   4210 <buf_put>
    8a59:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8a5e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8a62:	48 85 d2             	test   %rdx,%rdx
    8a65:	0f 85 52 ff ff ff    	jne    89bd <fwp_write+0x6dd>
    8a6b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8a70:	48 85 ff             	test   %rdi,%rdi
    8a73:	0f 88 cf 05 00 00    	js     9048 <fwp_write+0xd68>
    8a79:	48 8b 31             	mov    (%rcx),%rsi
    8a7c:	eb a2                	jmp    8a20 <fwp_write+0x740>
    8a7e:	66 90                	xchg   %ax,%ax
    8a80:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8a87:	00 
    8a88:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8a8f:	00 00 
    8a91:	0f 85 1e fd ff ff    	jne    87b5 <fwp_write+0x4d5>
    8a97:	ba 08 00 00 00       	mov    $0x8,%edx
    8a9c:	48 8d 35 22 67 00 00 	lea    0x6722(%rip),%rsi        # f1c5 <_IO_stdin_used+0x1c5>
    8aa3:	e9 4b fa ff ff       	jmp    84f3 <fwp_write+0x213>
    8aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8aaf:	00 
    8ab0:	89 e8                	mov    %ebp,%eax
    8ab2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8ab9:	76 03                	jbe    8abe <fwp_write+0x7de>
    8abb:	8b 45 00             	mov    0x0(%rbp),%eax
    8abe:	41 89 c6             	mov    %eax,%r14d
    8ac1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8ac6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8acb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8acf:	4c 89 ef             	mov    %r13,%rdi
    8ad2:	e8 79 a9 ff ff       	call   3450 <strlen@plt>
    8ad7:	4c 89 ee             	mov    %r13,%rsi
    8ada:	48 89 df             	mov    %rbx,%rdi
    8add:	48 89 c2             	mov    %rax,%rdx
    8ae0:	e8 2b b7 ff ff       	call   4210 <buf_put>
    8ae5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8aea:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8aee:	85 f6                	test   %esi,%esi
    8af0:	0f 8e 80 f8 ff ff    	jle    8376 <fwp_write+0x96>
    8af6:	45 31 ed             	xor    %r13d,%r13d
    8af9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8afe:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8b03:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8b08:	ba 01 00 00 00       	mov    $0x1,%edx
    8b0d:	4c 89 fe             	mov    %r15,%rsi
    8b10:	48 89 04 24          	mov    %rax,(%rsp)
    8b14:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8b19:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8b1d:	48 89 df             	mov    %rbx,%rdi
    8b20:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8b24:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8b29:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8b2e:	e8 dd b6 ff ff       	call   4210 <buf_put>
    8b33:	41 8b 06             	mov    (%r14),%eax
    8b36:	83 f8 0e             	cmp    $0xe,%eax
    8b39:	0f 84 71 02 00 00    	je     8db0 <fwp_write+0xad0>
    8b3f:	83 f8 10             	cmp    $0x10,%eax
    8b42:	0f 84 38 02 00 00    	je     8d80 <fwp_write+0xaa0>
    8b48:	83 f8 0a             	cmp    $0xa,%eax
    8b4b:	0f 84 7f 04 00 00    	je     8fd0 <fwp_write+0xcf0>
    8b51:	0f 8f f9 00 00 00    	jg     8c50 <fwp_write+0x970>
    8b57:	83 f8 03             	cmp    $0x3,%eax
    8b5a:	0f 8f 50 04 00 00    	jg     8fb0 <fwp_write+0xcd0>
    8b60:	85 c0                	test   %eax,%eax
    8b62:	78 10                	js     8b74 <fwp_write+0x894>
    8b64:	48 8b 04 24          	mov    (%rsp),%rax
    8b68:	48 c1 e8 3f          	shr    $0x3f,%rax
    8b6c:	85 c0                	test   %eax,%eax
    8b6e:	0f 85 f9 00 00 00    	jne    8c6d <fwp_write+0x98d>
    8b74:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8b79:	48 8b 34 24          	mov    (%rsp),%rsi
    8b7d:	31 c9                	xor    %ecx,%ecx
    8b7f:	48 89 df             	mov    %rbx,%rdi
    8b82:	e8 59 f7 ff ff       	call   82e0 <fwp_write>
    8b87:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8b8c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8b91:	49 83 c5 01          	add    $0x1,%r13
    8b95:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8b99:	0f 8f 5f ff ff ff    	jg     8afe <fwp_write+0x81e>
    8b9f:	e9 d2 f7 ff ff       	jmp    8376 <fwp_write+0x96>
    8ba4:	0f 1f 40 00          	nopl   0x0(%rax)
    8ba8:	ba 06 00 00 00       	mov    $0x6,%edx
    8bad:	48 8d 35 37 66 00 00 	lea    0x6637(%rip),%rsi        # f1eb <_IO_stdin_used+0x1eb>
    8bb4:	45 31 ed             	xor    %r13d,%r13d
    8bb7:	e8 54 b6 ff ff       	call   4210 <buf_put>
    8bbc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8bc1:	75 19                	jne    8bdc <fwp_write+0x8fc>
    8bc3:	eb 6c                	jmp    8c31 <fwp_write+0x951>
    8bc5:	0f 1f 00             	nopl   (%rax)
    8bc8:	ba 02 00 00 00       	mov    $0x2,%edx
    8bcd:	48 8d 35 21 66 00 00 	lea    0x6621(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8bd4:	48 89 df             	mov    %rbx,%rdi
    8bd7:	e8 34 b6 ff ff       	call   4210 <buf_put>
    8bdc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8be2:	b9 00 02 00 00       	mov    $0x200,%ecx
    8be7:	31 c0                	xor    %eax,%eax
    8be9:	49 83 c5 01          	add    $0x1,%r13
    8bed:	4c 8d 05 fe 65 00 00 	lea    0x65fe(%rip),%r8        # f1f2 <_IO_stdin_used+0x1f2>
    8bf4:	ba 02 00 00 00       	mov    $0x2,%edx
    8bf9:	be 00 02 00 00       	mov    $0x200,%esi
    8bfe:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8c05:	00 
    8c06:	e8 a5 a7 ff ff       	call   33b0 <__snprintf_chk@plt>
    8c0b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8c12:	00 
    8c13:	e8 38 a8 ff ff       	call   3450 <strlen@plt>
    8c18:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8c1f:	00 
    8c20:	48 89 df             	mov    %rbx,%rdi
    8c23:	48 89 c2             	mov    %rax,%rdx
    8c26:	e8 e5 b5 ff ff       	call   4210 <buf_put>
    8c2b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8c2f:	72 97                	jb     8bc8 <fwp_write+0x8e8>
    8c31:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8c36:	ba 01 00 00 00       	mov    $0x1,%edx
    8c3b:	48 89 df             	mov    %rbx,%rdi
    8c3e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8c43:	e8 c8 b5 ff ff       	call   4210 <buf_put>
    8c48:	e9 29 f7 ff ff       	jmp    8376 <fwp_write+0x96>
    8c4d:	0f 1f 00             	nopl   (%rax)
    8c50:	83 f8 0b             	cmp    $0xb,%eax
    8c53:	0f 85 1b ff ff ff    	jne    8b74 <fwp_write+0x894>
    8c59:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8c5e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8c62:	83 e0 01             	and    $0x1,%eax
    8c65:	85 c0                	test   %eax,%eax
    8c67:	0f 84 07 ff ff ff    	je     8b74 <fwp_write+0x894>
    8c6d:	4c 89 fe             	mov    %r15,%rsi
    8c70:	48 89 df             	mov    %rbx,%rdi
    8c73:	ba 01 00 00 00       	mov    $0x1,%edx
    8c78:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8c7d:	e8 8e b5 ff ff       	call   4210 <buf_put>
    8c82:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8c87:	48 8b 34 24          	mov    (%rsp),%rsi
    8c8b:	31 c9                	xor    %ecx,%ecx
    8c8d:	48 89 df             	mov    %rbx,%rdi
    8c90:	e8 4b f6 ff ff       	call   82e0 <fwp_write>
    8c95:	ba 01 00 00 00       	mov    $0x1,%edx
    8c9a:	4c 89 fe             	mov    %r15,%rsi
    8c9d:	48 89 df             	mov    %rbx,%rdi
    8ca0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8ca5:	e8 66 b5 ff ff       	call   4210 <buf_put>
    8caa:	e9 d8 fe ff ff       	jmp    8b87 <fwp_write+0x8a7>
    8caf:	90                   	nop
    8cb0:	ba 01 00 00 00       	mov    $0x1,%edx
    8cb5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8cba:	48 89 df             	mov    %rbx,%rdi
    8cbd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8cc2:	e8 49 b5 ff ff       	call   4210 <buf_put>
    8cc7:	e9 aa f6 ff ff       	jmp    8376 <fwp_write+0x96>
    8ccc:	0f 1f 40 00          	nopl   0x0(%rax)
    8cd0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8cd5:	ba 01 00 00 00       	mov    $0x1,%edx
    8cda:	48 89 df             	mov    %rbx,%rdi
    8cdd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8ce2:	e8 29 b5 ff ff       	call   4210 <buf_put>
    8ce7:	e9 8a f6 ff ff       	jmp    8376 <fwp_write+0x96>
    8cec:	0f 1f 40 00          	nopl   0x0(%rax)
    8cf0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8cf4:	48 8b 13             	mov    (%rbx),%rdx
    8cf7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    8cfc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8d00:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8d04:	e9 6d f6 ff ff       	jmp    8376 <fwp_write+0x96>
    8d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8d10:	ba 02 00 00 00       	mov    $0x2,%edx
    8d15:	48 8d 35 d9 64 00 00 	lea    0x64d9(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8d1c:	48 89 df             	mov    %rbx,%rdi
    8d1f:	e8 ec b4 ff ff       	call   4210 <buf_put>
    8d24:	e9 72 f8 ff ff       	jmp    859b <fwp_write+0x2bb>
    8d29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8d30:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8d35:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8d3a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    8d3e:	48 89 f7             	mov    %rsi,%rdi
    8d41:	48 89 34 24          	mov    %rsi,(%rsp)
    8d45:	e8 06 a7 ff ff       	call   3450 <strlen@plt>
    8d4a:	48 8b 34 24          	mov    (%rsp),%rsi
    8d4e:	48 89 df             	mov    %rbx,%rdi
    8d51:	48 89 c2             	mov    %rax,%rdx
    8d54:	e8 b7 b4 ff ff       	call   4210 <buf_put>
    8d59:	ba 03 00 00 00       	mov    $0x3,%edx
    8d5e:	48 8d 35 b3 64 00 00 	lea    0x64b3(%rip),%rsi        # f218 <_IO_stdin_used+0x218>
    8d65:	48 89 df             	mov    %rbx,%rdi
    8d68:	e8 a3 b4 ff ff       	call   4210 <buf_put>
    8d6d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    8d72:	e9 35 f8 ff ff       	jmp    85ac <fwp_write+0x2cc>
    8d77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8d7e:	00 00 
    8d80:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8d85:	48 8b 78 08          	mov    0x8(%rax),%rdi
    8d89:	48 85 ff             	test   %rdi,%rdi
    8d8c:	0f 84 e2 fd ff ff    	je     8b74 <fwp_write+0x894>
    8d92:	48 8d 35 69 64 00 00 	lea    0x6469(%rip),%rsi        # f202 <_IO_stdin_used+0x202>
    8d99:	e8 92 a7 ff ff       	call   3530 <strcmp@plt>
    8d9e:	85 c0                	test   %eax,%eax
    8da0:	0f 95 c0             	setne  %al
    8da3:	0f b6 c0             	movzbl %al,%eax
    8da6:	e9 c1 fd ff ff       	jmp    8b6c <fwp_write+0x88c>
    8dab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8db0:	31 c0                	xor    %eax,%eax
    8db2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    8db9:	00 
    8dba:	0f 97 c0             	seta   %al
    8dbd:	e9 aa fd ff ff       	jmp    8b6c <fwp_write+0x88c>
    8dc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8dc8:	48 89 df             	mov    %rbx,%rdi
    8dcb:	ba 02 00 00 00       	mov    $0x2,%edx
    8dd0:	48 8d 35 28 64 00 00 	lea    0x6428(%rip),%rsi        # f1ff <_IO_stdin_used+0x1ff>
    8dd7:	e8 34 b4 ff ff       	call   4210 <buf_put>
    8ddc:	4c 89 e8             	mov    %r13,%rax
    8ddf:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    8de4:	31 c9                	xor    %ecx,%ecx
    8de6:	48 c1 e0 04          	shl    $0x4,%rax
    8dea:	48 89 df             	mov    %rbx,%rdi
    8ded:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    8df2:	e8 e9 f4 ff ff       	call   82e0 <fwp_write>
    8df7:	e9 5e f6 ff ff       	jmp    845a <fwp_write+0x17a>
    8dfc:	0f 1f 40 00          	nopl   0x0(%rax)
    8e00:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    8e05:	48 85 ff             	test   %rdi,%rdi
    8e08:	79 0c                	jns    8e16 <fwp_write+0xb36>
    8e0a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    8e11:	00 
    8e12:	48 03 75 10          	add    0x10(%rbp),%rsi
    8e16:	48 63 3e             	movslq (%rsi),%rdi
    8e19:	83 f9 02             	cmp    $0x2,%ecx
    8e1c:	89 fe                	mov    %edi,%esi
    8e1e:	48 0f 44 f7          	cmove  %rdi,%rsi
    8e22:	e9 f9 fb ff ff       	jmp    8a20 <fwp_write+0x740>
    8e27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8e2e:	00 00 
    8e30:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    8e35:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    8e3a:	48 85 ff             	test   %rdi,%rdi
    8e3d:	0f 88 0f 03 00 00    	js     9152 <fwp_write+0xe72>
    8e43:	49 0f bf 38          	movswq (%r8),%rdi
    8e47:	83 f9 01             	cmp    $0x1,%ecx
    8e4a:	0f b7 f7             	movzwl %di,%esi
    8e4d:	48 0f 44 f7          	cmove  %rdi,%rsi
    8e51:	e9 ca fb ff ff       	jmp    8a20 <fwp_write+0x740>
    8e56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8e5d:	00 00 00 
    8e60:	ba 01 00 00 00       	mov    $0x1,%edx
    8e65:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8e6a:	48 83 c5 08          	add    $0x8,%rbp
    8e6e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8e73:	e8 98 b3 ff ff       	call   4210 <buf_put>
    8e78:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8e7d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    8e82:	4d 85 ed             	test   %r13,%r13
    8e85:	75 46                	jne    8ecd <fwp_write+0xbed>
    8e87:	e9 04 01 00 00       	jmp    8f90 <fwp_write+0xcb0>
    8e8c:	0f 1f 40 00          	nopl   0x0(%rax)
    8e90:	41 80 f9 09          	cmp    $0x9,%r9b
    8e94:	0f 84 d6 00 00 00    	je     8f70 <fwp_write+0xc90>
    8e9a:	41 80 f9 0a          	cmp    $0xa,%r9b
    8e9e:	0f 85 9c 00 00 00    	jne    8f40 <fwp_write+0xc60>
    8ea4:	ba 02 00 00 00       	mov    $0x2,%edx
    8ea9:	48 8d 35 2b 63 00 00 	lea    0x632b(%rip),%rsi        # f1db <_IO_stdin_used+0x1db>
    8eb0:	48 89 df             	mov    %rbx,%rdi
    8eb3:	e8 58 b3 ff ff       	call   4210 <buf_put>
    8eb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8ebf:	00 
    8ec0:	48 83 c5 01          	add    $0x1,%rbp
    8ec4:	49 39 ec             	cmp    %rbp,%r12
    8ec7:	0f 84 c3 00 00 00    	je     8f90 <fwp_write+0xcb0>
    8ecd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    8ed2:	41 80 f9 0d          	cmp    $0xd,%r9b
    8ed6:	74 28                	je     8f00 <fwp_write+0xc20>
    8ed8:	7e b6                	jle    8e90 <fwp_write+0xbb0>
    8eda:	41 80 f9 22          	cmp    $0x22,%r9b
    8ede:	74 40                	je     8f20 <fwp_write+0xc40>
    8ee0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    8ee4:	75 5a                	jne    8f40 <fwp_write+0xc60>
    8ee6:	ba 02 00 00 00       	mov    $0x2,%edx
    8eeb:	48 8d 35 e6 62 00 00 	lea    0x62e6(%rip),%rsi        # f1d8 <_IO_stdin_used+0x1d8>
    8ef2:	48 89 df             	mov    %rbx,%rdi
    8ef5:	e8 16 b3 ff ff       	call   4210 <buf_put>
    8efa:	eb c4                	jmp    8ec0 <fwp_write+0xbe0>
    8efc:	0f 1f 40 00          	nopl   0x0(%rax)
    8f00:	ba 02 00 00 00       	mov    $0x2,%edx
    8f05:	48 8d 35 d5 62 00 00 	lea    0x62d5(%rip),%rsi        # f1e1 <_IO_stdin_used+0x1e1>
    8f0c:	48 89 df             	mov    %rbx,%rdi
    8f0f:	e8 fc b2 ff ff       	call   4210 <buf_put>
    8f14:	eb aa                	jmp    8ec0 <fwp_write+0xbe0>
    8f16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8f1d:	00 00 00 
    8f20:	ba 02 00 00 00       	mov    $0x2,%edx
    8f25:	48 8d 35 a9 62 00 00 	lea    0x62a9(%rip),%rsi        # f1d5 <_IO_stdin_used+0x1d5>
    8f2c:	48 89 df             	mov    %rbx,%rdi
    8f2f:	e8 dc b2 ff ff       	call   4210 <buf_put>
    8f34:	eb 8a                	jmp    8ec0 <fwp_write+0xbe0>
    8f36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8f3d:	00 00 00 
    8f40:	41 80 f9 1f          	cmp    $0x1f,%r9b
    8f44:	0f 86 2e 01 00 00    	jbe    9078 <fwp_write+0xd98>
    8f4a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    8f4e:	0f 84 24 01 00 00    	je     9078 <fwp_write+0xd98>
    8f54:	ba 01 00 00 00       	mov    $0x1,%edx
    8f59:	4c 89 fe             	mov    %r15,%rsi
    8f5c:	48 89 df             	mov    %rbx,%rdi
    8f5f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    8f64:	e8 a7 b2 ff ff       	call   4210 <buf_put>
    8f69:	e9 52 ff ff ff       	jmp    8ec0 <fwp_write+0xbe0>
    8f6e:	66 90                	xchg   %ax,%ax
    8f70:	ba 02 00 00 00       	mov    $0x2,%edx
    8f75:	48 8d 35 62 62 00 00 	lea    0x6262(%rip),%rsi        # f1de <_IO_stdin_used+0x1de>
    8f7c:	48 89 df             	mov    %rbx,%rdi
    8f7f:	e8 8c b2 ff ff       	call   4210 <buf_put>
    8f84:	e9 37 ff ff ff       	jmp    8ec0 <fwp_write+0xbe0>
    8f89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8f90:	ba 01 00 00 00       	mov    $0x1,%edx
    8f95:	4c 89 fe             	mov    %r15,%rsi
    8f98:	48 89 df             	mov    %rbx,%rdi
    8f9b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8fa0:	e8 6b b2 ff ff       	call   4210 <buf_put>
    8fa5:	e9 cc f3 ff ff       	jmp    8376 <fwp_write+0x96>
    8faa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8fb0:	83 f8 04             	cmp    $0x4,%eax
    8fb3:	0f 85 bb fb ff ff    	jne    8b74 <fwp_write+0x894>
    8fb9:	48 8b 04 24          	mov    (%rsp),%rax
    8fbd:	48 8b 40 08          	mov    0x8(%rax),%rax
    8fc1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8fc6:	48 c1 e8 3f          	shr    $0x3f,%rax
    8fca:	e9 96 fc ff ff       	jmp    8c65 <fwp_write+0x985>
    8fcf:	90                   	nop
    8fd0:	8b 0c 24             	mov    (%rsp),%ecx
    8fd3:	31 c0                	xor    %eax,%eax
    8fd5:	85 c9                	test   %ecx,%ecx
    8fd7:	0f 98 c0             	sets   %al
    8fda:	e9 86 fc ff ff       	jmp    8c65 <fwp_write+0x985>
    8fdf:	90                   	nop
    8fe0:	48 f7 d8             	neg    %rax
    8fe3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    8fea:	00 
    8feb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    8ff2:	2d 
    8ff3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8ffa:	00 
    8ffb:	48 83 d2 00          	adc    $0x0,%rdx
    8fff:	48 89 c6             	mov    %rax,%rsi
    9002:	48 f7 da             	neg    %rdx
    9005:	e8 36 aa ff ff       	call   3a40 <fwp_fmt_u128>
    900a:	e9 51 f3 ff ff       	jmp    8360 <fwp_write+0x80>
    900f:	90                   	nop
    9010:	b8 7d 00 00 00       	mov    $0x7d,%eax
    9015:	e9 c3 f5 ff ff       	jmp    85dd <fwp_write+0x2fd>
    901a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9020:	4c 89 e9             	mov    %r13,%rcx
    9023:	48 c1 e1 04          	shl    $0x4,%rcx
    9027:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    902c:	48 85 ff             	test   %rdi,%rdi
    902f:	0f 89 eb f9 ff ff    	jns    8a20 <fwp_write+0x740>
    9035:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9039:	48 89 ce             	mov    %rcx,%rsi
    903c:	e9 df f9 ff ff       	jmp    8a20 <fwp_write+0x740>
    9041:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9048:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    904f:	00 
    9050:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9054:	e9 20 fa ff ff       	jmp    8a79 <fwp_write+0x799>
    9059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9060:	ba 02 00 00 00       	mov    $0x2,%edx
    9065:	48 8d 35 39 61 00 00 	lea    0x6139(%rip),%rsi        # f1a5 <_IO_stdin_used+0x1a5>
    906c:	e9 2d f7 ff ff       	jmp    879e <fwp_write+0x4be>
    9071:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9078:	4c 8d 05 65 61 00 00 	lea    0x6165(%rip),%r8        # f1e4 <_IO_stdin_used+0x1e4>
    907f:	b9 10 00 00 00       	mov    $0x10,%ecx
    9084:	31 c0                	xor    %eax,%eax
    9086:	ba 02 00 00 00       	mov    $0x2,%edx
    908b:	be 10 00 00 00       	mov    $0x10,%esi
    9090:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9097:	00 
    9098:	e8 13 a3 ff ff       	call   33b0 <__snprintf_chk@plt>
    909d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    90a4:	00 
    90a5:	e8 a6 a3 ff ff       	call   3450 <strlen@plt>
    90aa:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    90b1:	00 
    90b2:	48 89 df             	mov    %rbx,%rdi
    90b5:	48 89 c2             	mov    %rax,%rdx
    90b8:	e8 53 b1 ff ff       	call   4210 <buf_put>
    90bd:	e9 fe fd ff ff       	jmp    8ec0 <fwp_write+0xbe0>
    90c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    90c8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    90cc:	48 8d 35 cc 60 00 00 	lea    0x60cc(%rip),%rsi        # f19f <_IO_stdin_used+0x19f>
    90d3:	48 8d 05 c4 60 00 00 	lea    0x60c4(%rip),%rax        # f19e <_IO_stdin_used+0x19e>
    90da:	4c 89 e7             	mov    %r12,%rdi
    90dd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    90e1:	48 0f 46 f0          	cmovbe %rax,%rsi
    90e5:	e8 06 a3 ff ff       	call   33f0 <strcpy@plt>
    90ea:	e9 71 f2 ff ff       	jmp    8360 <fwp_write+0x80>
    90ef:	90                   	nop
    90f0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    90f4:	48 8d 35 a4 60 00 00 	lea    0x60a4(%rip),%rsi        # f19f <_IO_stdin_used+0x19f>
    90fb:	48 8d 05 9c 60 00 00 	lea    0x609c(%rip),%rax        # f19e <_IO_stdin_used+0x19e>
    9102:	0f 2f c8             	comiss %xmm0,%xmm1
    9105:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    910c:	00 
    910d:	4c 89 e7             	mov    %r12,%rdi
    9110:	48 0f 46 f0          	cmovbe %rax,%rsi
    9114:	e8 d7 a2 ff ff       	call   33f0 <strcpy@plt>
    9119:	e9 42 f2 ff ff       	jmp    8360 <fwp_write+0x80>
    911e:	66 90                	xchg   %ax,%ax
    9120:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9125:	45 85 c0             	test   %r8d,%r8d
    9128:	75 34                	jne    915e <fwp_write+0xe7e>
    912a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9131:	00 
    9132:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9139:	00 00 
    913b:	0f 85 74 f6 ff ff    	jne    87b5 <fwp_write+0x4d5>
    9141:	ba 02 00 00 00       	mov    $0x2,%edx
    9146:	48 8d 35 c8 60 00 00 	lea    0x60c8(%rip),%rsi        # f215 <_IO_stdin_used+0x215>
    914d:	e9 a1 f3 ff ff       	jmp    84f3 <fwp_write+0x213>
    9152:	48 03 75 10          	add    0x10(%rbp),%rsi
    9156:	49 89 f0             	mov    %rsi,%r8
    9159:	e9 e5 fc ff ff       	jmp    8e43 <fwp_write+0xb63>
    915e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9163:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9168:	85 ff                	test   %edi,%edi
    916a:	0f 84 fa f3 ff ff    	je     856a <fwp_write+0x28a>
    9170:	ba 01 00 00 00       	mov    $0x1,%edx
    9175:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    917a:	48 89 df             	mov    %rbx,%rdi
    917d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9182:	e8 89 b0 ff ff       	call   4210 <buf_put>
    9187:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    918c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9191:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9197:	85 c0                	test   %eax,%eax
    9199:	0f 8f f0 f3 ff ff    	jg     858f <fwp_write+0x2af>
    919f:	e9 34 f4 ff ff       	jmp    85d8 <fwp_write+0x2f8>
    91a4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    91a8:	49 89 c5             	mov    %rax,%r13
    91ab:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    91b0:	49 89 c4             	mov    %rax,%r12
    91b3:	49 c1 fd 3f          	sar    $0x3f,%r13
    91b7:	4c 09 e8             	or     %r13,%rax
    91ba:	0f 84 a7 00 00 00    	je     9267 <fwp_write+0xf87>
    91c0:	48 8d 2d d9 80 00 00 	lea    0x80d9(%rip),%rbp        # 112a0 <units.0>
    91c7:	4d 89 e7             	mov    %r12,%r15
    91ca:	48 8b 45 08          	mov    0x8(%rbp),%rax
    91ce:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    91d3:	4c 89 ff             	mov    %r15,%rdi
    91d6:	4c 89 ee             	mov    %r13,%rsi
    91d9:	44 89 0c 24          	mov    %r9d,(%rsp)
    91dd:	48 99                	cqto
    91df:	48 89 d1             	mov    %rdx,%rcx
    91e2:	48 89 c2             	mov    %rax,%rdx
    91e5:	e8 26 4e 00 00       	call   e010 <__divmodti4>
    91ea:	44 8b 0c 24          	mov    (%rsp),%r9d
    91ee:	48 89 c1             	mov    %rax,%rcx
    91f1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    91f6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    91fb:	0f 84 94 00 00 00    	je     9295 <fwp_write+0xfb5>
    9201:	41 83 c1 01          	add    $0x1,%r9d
    9205:	48 83 c5 10          	add    $0x10,%rbp
    9209:	41 83 f9 05          	cmp    $0x5,%r9d
    920d:	75 bb                	jne    91ca <fwp_write+0xeea>
    920f:	4d 85 ed             	test   %r13,%r13
    9212:	79 53                	jns    9267 <fwp_write+0xf87>
    9214:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9219:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    921e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9223:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9228:	48 99                	cqto
    922a:	48 f7 d8             	neg    %rax
    922d:	48 83 d2 00          	adc    $0x0,%rdx
    9231:	48 89 c6             	mov    %rax,%rsi
    9234:	48 f7 da             	neg    %rdx
    9237:	e8 04 a8 ff ff       	call   3a40 <fwp_fmt_u128>
    923c:	49 89 e8             	mov    %rbp,%r8
    923f:	ba 00 02 00 00       	mov    $0x200,%edx
    9244:	be 02 00 00 00       	mov    $0x2,%esi
    9249:	31 c0                	xor    %eax,%eax
    924b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9252:	00 
    9253:	48 8d 0d b6 5f 00 00 	lea    0x5fb6(%rip),%rcx        # f210 <_IO_stdin_used+0x210>
    925a:	4c 89 e7             	mov    %r12,%rdi
    925d:	e8 7e a4 ff ff       	call   36e0 <__sprintf_chk@plt>
    9262:	e9 f9 f0 ff ff       	jmp    8360 <fwp_write+0x80>
    9267:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    926c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9271:	31 d2                	xor    %edx,%edx
    9273:	48 89 ef             	mov    %rbp,%rdi
    9276:	e8 c5 a7 ff ff       	call   3a40 <fwp_fmt_u128>
    927b:	eb bf                	jmp    923c <fwp_write+0xf5c>
    927d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9284:	4e 61 4e 00 
    9288:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    928f:	00 
    9290:	e9 cb f0 ff ff       	jmp    8360 <fwp_write+0x80>
    9295:	44 89 0c 24          	mov    %r9d,(%rsp)
    9299:	48 89 c8             	mov    %rcx,%rax
    929c:	48 85 d2             	test   %rdx,%rdx
    929f:	78 51                	js     92f2 <fwp_write+0x1012>
    92a1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    92a6:	48 89 c6             	mov    %rax,%rsi
    92a9:	48 89 ef             	mov    %rbp,%rdi
    92ac:	e8 8f a7 ff ff       	call   3a40 <fwp_fmt_u128>
    92b1:	44 8b 0c 24          	mov    (%rsp),%r9d
    92b5:	49 63 c1             	movslq %r9d,%rax
    92b8:	49 89 e8             	mov    %rbp,%r8
    92bb:	ba 00 02 00 00       	mov    $0x200,%edx
    92c0:	be 02 00 00 00       	mov    $0x2,%esi
    92c5:	48 c1 e0 04          	shl    $0x4,%rax
    92c9:	48 8d 3d d0 7f 00 00 	lea    0x7fd0(%rip),%rdi        # 112a0 <units.0>
    92d0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    92d7:	00 
    92d8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    92dc:	48 8d 0d 28 5f 00 00 	lea    0x5f28(%rip),%rcx        # f20b <_IO_stdin_used+0x20b>
    92e3:	4c 89 e7             	mov    %r12,%rdi
    92e6:	31 c0                	xor    %eax,%eax
    92e8:	e8 f3 a3 ff ff       	call   36e0 <__sprintf_chk@plt>
    92ed:	e9 6e f0 ff ff       	jmp    8360 <fwp_write+0x80>
    92f2:	48 f7 d8             	neg    %rax
    92f5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    92fa:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    92ff:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9304:	48 83 d2 00          	adc    $0x0,%rdx
    9308:	48 89 c6             	mov    %rax,%rsi
    930b:	48 f7 da             	neg    %rdx
    930e:	e8 2d a7 ff ff       	call   3a40 <fwp_fmt_u128>
    9313:	44 8b 0c 24          	mov    (%rsp),%r9d
    9317:	eb 9c                	jmp    92b5 <fwp_write+0xfd5>
    9319:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009320 <fwp_hof0.constprop.0>:
    9320:	41 57                	push   %r15
    9322:	41 56                	push   %r14
    9324:	41 55                	push   %r13
    9326:	41 54                	push   %r12
    9328:	55                   	push   %rbp
    9329:	53                   	push   %rbx
    932a:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    9331:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9338:	00 00 
    933a:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    9341:	00 
    9342:	31 c0                	xor    %eax,%eax
    9344:	48 85 f6             	test   %rsi,%rsi
    9347:	0f 84 4a 0f 00 00    	je     a297 <fwp_hof0.constprop.0+0xf77>
    934d:	48 89 74 24 68       	mov    %rsi,0x68(%rsp)
    9352:	4c 8d 2d 87 a4 01 00 	lea    0x1a487(%rip),%r13        # 237e0 <fwp_heap>
    9359:	48 89 7c 24 60       	mov    %rdi,0x60(%rsp)
    935e:	66 90                	xchg   %ax,%ax
    9360:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9367:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    936c:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9373:	48 c1 e2 10          	shl    $0x10,%rdx
    9377:	48 39 d0             	cmp    %rdx,%rax
    937a:	73 5d                	jae    93d9 <fwp_hof0.constprop.0+0xb9>
    937c:	48 89 c2             	mov    %rax,%rdx
    937f:	48 c1 ea 10          	shr    $0x10,%rdx
    9383:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9387:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    938e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9392:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9396:	48 85 ff             	test   %rdi,%rdi
    9399:	74 3e                	je     93d9 <fwp_hof0.constprop.0+0xb9>
    939b:	0f b6 0a             	movzbl (%rdx),%ecx
    939e:	80 f9 02             	cmp    $0x2,%cl
    93a1:	0f 84 b9 14 00 00    	je     a860 <fwp_hof0.constprop.0+0x1540>
    93a7:	80 f9 01             	cmp    $0x1,%cl
    93aa:	75 2d                	jne    93d9 <fwp_hof0.constprop.0+0xb9>
    93ac:	8b 4a 18             	mov    0x18(%rdx),%ecx
    93af:	0f b7 c0             	movzwl %ax,%eax
    93b2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    93b5:	48 0f af c1          	imul   %rcx,%rax
    93b9:	48 c1 e8 20          	shr    $0x20,%rax
    93bd:	48 39 d0             	cmp    %rdx,%rax
    93c0:	73 17                	jae    93d9 <fwp_hof0.constprop.0+0xb9>
    93c2:	48 01 c7             	add    %rax,%rdi
    93c5:	0f b6 07             	movzbl (%rdi),%eax
    93c8:	84 c0                	test   %al,%al
    93ca:	74 0d                	je     93d9 <fwp_hof0.constprop.0+0xb9>
    93cc:	3c fd                	cmp    $0xfd,%al
    93ce:	0f 87 a7 16 00 00    	ja     aa7b <fwp_hof0.constprop.0+0x175b>
    93d4:	83 c0 01             	add    $0x1,%eax
    93d7:	88 07                	mov    %al,(%rdi)
    93d9:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    93de:	45 31 c0             	xor    %r8d,%r8d
    93e1:	48 c7 44 24 40 c6 00 	movq   $0xc6,0x40(%rsp)
    93e8:	00 00 
    93ea:	48 89 04 24          	mov    %rax,(%rsp)
    93ee:	4d 89 c6             	mov    %r8,%r14
    93f1:	4d 85 c0             	test   %r8,%r8
    93f4:	0f 85 56 a3 ff ff    	jne    3750 <fwp_hof0.constprop.0.cold+0x5>
    93fa:	48 8b 05 77 c0 01 00 	mov    0x1c077(%rip),%rax        # 25478 <fwp_cleanups>
    9401:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9408:	4c 8d 3d 51 d8 ff ff 	lea    -0x27af(%rip),%r15        # 6c60 <fwp_tape_scope_release>
    940f:	c7 44 24 7c ff ff ff 	movl   $0xffffffff,0x7c(%rsp)
    9416:	ff 
    9417:	4c 89 bc 24 88 00 00 	mov    %r15,0x88(%rsp)
    941e:	00 
    941f:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9426:	00 
    9427:	48 8d 44 24 7c       	lea    0x7c(%rsp),%rax
    942c:	48 c1 e2 10          	shl    $0x10,%rdx
    9430:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    9435:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    943c:	00 
    943d:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    9444:	00 
    9445:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    944a:	48 89 05 27 c0 01 00 	mov    %rax,0x1c027(%rip)        # 25478 <fwp_cleanups>
    9451:	48 8d 05 b8 9b 00 00 	lea    0x9bb8(%rip),%rax        # 13010 <fc37>
    9458:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    945f:	48 39 d0             	cmp    %rdx,%rax
    9462:	73 5d                	jae    94c1 <fwp_hof0.constprop.0+0x1a1>
    9464:	48 89 c2             	mov    %rax,%rdx
    9467:	48 c1 ea 10          	shr    $0x10,%rdx
    946b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    946f:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9476:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    947a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    947e:	48 85 ff             	test   %rdi,%rdi
    9481:	74 3e                	je     94c1 <fwp_hof0.constprop.0+0x1a1>
    9483:	0f b6 0a             	movzbl (%rdx),%ecx
    9486:	80 f9 02             	cmp    $0x2,%cl
    9489:	0f 84 81 12 00 00    	je     a710 <fwp_hof0.constprop.0+0x13f0>
    948f:	80 f9 01             	cmp    $0x1,%cl
    9492:	75 2d                	jne    94c1 <fwp_hof0.constprop.0+0x1a1>
    9494:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9497:	0f b7 c0             	movzwl %ax,%eax
    949a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    949d:	48 0f af c1          	imul   %rcx,%rax
    94a1:	48 c1 e8 20          	shr    $0x20,%rax
    94a5:	48 39 d0             	cmp    %rdx,%rax
    94a8:	73 17                	jae    94c1 <fwp_hof0.constprop.0+0x1a1>
    94aa:	48 01 c7             	add    %rax,%rdi
    94ad:	0f b6 07             	movzbl (%rdi),%eax
    94b0:	84 c0                	test   %al,%al
    94b2:	74 0d                	je     94c1 <fwp_hof0.constprop.0+0x1a1>
    94b4:	3c fd                	cmp    $0xfd,%al
    94b6:	0f 87 ff 14 00 00    	ja     a9bb <fwp_hof0.constprop.0+0x169b>
    94bc:	83 c0 01             	add    $0x1,%eax
    94bf:	88 07                	mov    %al,(%rdi)
    94c1:	48 8d 3d 48 9b 00 00 	lea    0x9b48(%rip),%rdi        # 13010 <fc37>
    94c8:	e8 53 d4 ff ff       	call   6920 <fwp_closure_drop>
    94cd:	48 8b 04 24          	mov    (%rsp),%rax
    94d1:	48 85 c0             	test   %rax,%rax
    94d4:	0f 84 f5 13 00 00    	je     a8cf <fwp_hof0.constprop.0+0x15af>
    94da:	31 ed                	xor    %ebp,%ebp
    94dc:	0f 1f 40 00          	nopl   0x0(%rax)
    94e0:	48 8b 40 10          	mov    0x10(%rax),%rax
    94e4:	48 83 c5 01          	add    $0x1,%rbp
    94e8:	48 85 c0             	test   %rax,%rax
    94eb:	75 f3                	jne    94e0 <fwp_hof0.constprop.0+0x1c0>
    94ed:	31 ff                	xor    %edi,%edi
    94ef:	e8 5c ad ff ff       	call   4250 <descent_phase_step>
    94f4:	48 81 fd ff ff ff 7f 	cmp    $0x7fffffff,%rbp
    94fb:	0f 87 b8 15 00 00    	ja     aab9 <fwp_hof0.constprop.0+0x1799>
    9501:	66 48 0f 6e c5       	movq   %rbp,%xmm0
    9506:	8b 35 70 9b 00 00    	mov    0x9b70(%rip),%esi        # 1307c <registered_finish.5>
    950c:	85 f6                	test   %esi,%esi
    950e:	0f 84 b4 11 00 00    	je     a6c8 <fwp_hof0.constprop.0+0x13a8>
    9514:	48 8b 15 dd 9b 01 00 	mov    0x19bdd(%rip),%rdx        # 230f8 <fwp_tape_next_slot>
    951b:	4c 8b 25 e6 9b 01 00 	mov    0x19be6(%rip),%r12        # 23108 <fwp_ntapes>
    9522:	49 39 d4             	cmp    %rdx,%r12
    9525:	0f 8e 75 10 00 00    	jle    a5a0 <fwp_hof0.constprop.0+0x1280>
    952b:	48 6b c2 68          	imul   $0x68,%rdx,%rax
    952f:	48 03 05 da 9b 01 00 	add    0x19bda(%rip),%rax        # 23110 <fwp_tapes>
    9536:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    953d:	00 00 00 
    9540:	8b 48 04             	mov    0x4(%rax),%ecx
    9543:	85 c9                	test   %ecx,%ecx
    9545:	75 0c                	jne    9553 <fwp_hof0.constprop.0+0x233>
    9547:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    954d:	0f 86 4d 10 00 00    	jbe    a5a0 <fwp_hof0.constprop.0+0x1280>
    9553:	48 83 c2 01          	add    $0x1,%rdx
    9557:	48 83 c0 68          	add    $0x68,%rax
    955b:	49 39 d4             	cmp    %rdx,%r12
    955e:	75 e0                	jne    9540 <fwp_hof0.constprop.0+0x220>
    9560:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    9567:	0f 8f cf 15 00 00    	jg     ab3c <fwp_hof0.constprop.0+0x181c>
    956d:	4c 3b 25 8c 9b 01 00 	cmp    0x19b8c(%rip),%r12        # 23100 <fwp_tapes_cap>
    9574:	48 8b 1d 95 9b 01 00 	mov    0x19b95(%rip),%rbx        # 23110 <fwp_tapes>
    957b:	75 4b                	jne    95c8 <fwp_hof0.constprop.0+0x2a8>
    957d:	4d 85 e4             	test   %r12,%r12
    9580:	0f 84 3a 13 00 00    	je     a8c0 <fwp_hof0.constprop.0+0x15a0>
    9586:	4b 8d 2c 24          	lea    (%r12,%r12,1),%rbp
    958a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    958f:	48 39 c5             	cmp    %rax,%rbp
    9592:	48 0f 4f e8          	cmovg  %rax,%rbp
    9596:	48 6b f5 68          	imul   $0x68,%rbp,%rsi
    959a:	48 89 df             	mov    %rbx,%rdi
    959d:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    95a3:	e8 28 a0 ff ff       	call   35d0 <realloc@plt>
    95a8:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    95ae:	48 85 c0             	test   %rax,%rax
    95b1:	48 89 c3             	mov    %rax,%rbx
    95b4:	0f 84 8e 15 00 00    	je     ab48 <fwp_hof0.constprop.0+0x1828>
    95ba:	48 89 05 4f 9b 01 00 	mov    %rax,0x19b4f(%rip)        # 23110 <fwp_tapes>
    95c1:	48 89 2d 38 9b 01 00 	mov    %rbp,0x19b38(%rip)        # 23100 <fwp_tapes_cap>
    95c8:	49 6b cc 68          	imul   $0x68,%r12,%rcx
    95cc:	31 c0                	xor    %eax,%eax
    95ce:	49 8d 6c 24 01       	lea    0x1(%r12),%rbp
    95d3:	48 01 d9             	add    %rbx,%rcx
    95d6:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    95da:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    95e1:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    95e5:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    95ec:	00 
    95ed:	48 29 f9             	sub    %rdi,%rcx
    95f0:	83 c1 68             	add    $0x68,%ecx
    95f3:	c1 e9 03             	shr    $0x3,%ecx
    95f6:	f3 48 ab             	rep stos %rax,(%rdi)
    95f9:	48 89 2d 08 9b 01 00 	mov    %rbp,0x19b08(%rip)        # 23108 <fwp_ntapes>
    9600:	49 6b cc 68          	imul   $0x68,%r12,%rcx
    9604:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    9608:	48 8d 3d 13 5b 00 00 	lea    0x5b13(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    960f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    9614:	48 01 d9             	add    %rbx,%rcx
    9617:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    961e:	00 
    961f:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    9624:	e8 77 9d ff ff       	call   33a0 <getenv@plt>
    9629:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    962e:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    9634:	48 85 c0             	test   %rax,%rax
    9637:	0f 84 33 0d 00 00    	je     a370 <fwp_hof0.constprop.0+0x1050>
    963d:	80 38 30             	cmpb   $0x30,(%rax)
    9640:	0f 85 2a 0d 00 00    	jne    a370 <fwp_hof0.constprop.0+0x1050>
    9646:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    964a:	0f 85 20 0d 00 00    	jne    a370 <fwp_hof0.constprop.0+0x1050>
    9650:	8b 01                	mov    (%rcx),%eax
    9652:	c7 41 04 01 00 00 00 	movl   $0x1,0x4(%rcx)
    9659:	48 89 2d 98 9a 01 00 	mov    %rbp,0x19a98(%rip)        # 230f8 <fwp_tape_next_slot>
    9660:	8d 50 01             	lea    0x1(%rax),%edx
    9663:	48 8b 05 26 65 00 00 	mov    0x6526(%rip),%rax        # fb90 <msg.8+0x20>
    966a:	48 c7 41 50 00 00 00 	movq   $0x0,0x50(%rcx)
    9671:	00 
    9672:	89 11                	mov    %edx,(%rcx)
    9674:	48 89 41 58          	mov    %rax,0x58(%rcx)
    9678:	48 8b 05 f9 bd 01 00 	mov    0x1bdf9(%rip),%rax        # 25478 <fwp_cleanups>
    967f:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
    9683:	48 85 c0             	test   %rax,%rax
    9686:	75 14                	jne    969c <fwp_hof0.constprop.0+0x37c>
    9688:	e9 53 14 00 00       	jmp    aae0 <fwp_hof0.constprop.0+0x17c0>
    968d:	0f 1f 00             	nopl   (%rax)
    9690:	48 8b 00             	mov    (%rax),%rax
    9693:	48 85 c0             	test   %rax,%rax
    9696:	0f 84 44 14 00 00    	je     aae0 <fwp_hof0.constprop.0+0x17c0>
    969c:	4c 39 78 08          	cmp    %r15,0x8(%rax)
    96a0:	75 ee                	jne    9690 <fwp_hof0.constprop.0+0x370>
    96a2:	48 8b 78 10          	mov    0x10(%rax),%rdi
    96a6:	44 89 e6             	mov    %r12d,%esi
    96a9:	48 63 07             	movslq (%rdi),%rax
    96ac:	48 89 79 50          	mov    %rdi,0x50(%rcx)
    96b0:	89 41 5c             	mov    %eax,0x5c(%rcx)
    96b3:	85 c0                	test   %eax,%eax
    96b5:	78 09                	js     96c0 <fwp_hof0.constprop.0+0x3a0>
    96b7:	48 6b c0 68          	imul   $0x68,%rax,%rax
    96bb:	44 89 64 03 58       	mov    %r12d,0x58(%rbx,%rax,1)
    96c0:	89 37                	mov    %esi,(%rdi)
    96c2:	bf 01 00 00 00       	mov    $0x1,%edi
    96c7:	45 31 e4             	xor    %r12d,%r12d
    96ca:	89 54 24 08          	mov    %edx,0x8(%rsp)
    96ce:	e8 7d ab ff ff       	call   4250 <descent_phase_step>
    96d3:	48 8b 1c 24          	mov    (%rsp),%rbx
    96d7:	8b 54 24 08          	mov    0x8(%rsp),%edx
    96db:	48 85 db             	test   %rbx,%rbx
    96de:	48 89 d8             	mov    %rbx,%rax
    96e1:	0f 84 e9 0d 00 00    	je     a4d0 <fwp_hof0.constprop.0+0x11b0>
    96e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    96ee:	00 00 
    96f0:	48 8b 40 10          	mov    0x10(%rax),%rax
    96f4:	49 83 c4 01          	add    $0x1,%r12
    96f8:	48 85 c0             	test   %rax,%rax
    96fb:	75 f3                	jne    96f0 <fwp_hof0.constprop.0+0x3d0>
    96fd:	48 8b 0c 24          	mov    (%rsp),%rcx
    9701:	0f 1f 40 00          	nopl   0x0(%rax)
    9705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    970c:	00 00 00 00 
    9710:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9714:	48 83 c0 01          	add    $0x1,%rax
    9718:	48 85 c9             	test   %rcx,%rcx
    971b:	75 f3                	jne    9710 <fwp_hof0.constprop.0+0x3f0>
    971d:	48 b9 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rcx
    9724:	ff ff 1f 
    9727:	48 39 c1             	cmp    %rax,%rcx
    972a:	0f 82 a1 13 00 00    	jb     aad1 <fwp_hof0.constprop.0+0x17b1>
    9730:	4d 85 e4             	test   %r12,%r12
    9733:	0f 8e 97 0d 00 00    	jle    a4d0 <fwp_hof0.constprop.0+0x11b0>
    9739:	49 39 c4             	cmp    %rax,%r12
    973c:	4c 0f 47 e0          	cmova  %rax,%r12
    9740:	4c 89 e0             	mov    %r12,%rax
    9743:	48 c1 e8 3c          	shr    $0x3c,%rax
    9747:	0f 85 84 13 00 00    	jne    aad1 <fwp_hof0.constprop.0+0x17b1>
    974d:	4f 8d 3c 24          	lea    (%r12,%r12,1),%r15
    9751:	48 c1 e2 10          	shl    $0x10,%rdx
    9755:	be 02 00 00 00       	mov    $0x2,%esi
    975a:	48 09 ea             	or     %rbp,%rdx
    975d:	4a 8d 3c fd 08 00 00 	lea    0x8(,%r15,8),%rdi
    9764:	00 
    9765:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    976a:	e8 81 c5 ff ff       	call   5cf0 <fwp_heap_alloc>
    976f:	4c 89 38             	mov    %r15,(%rax)
    9772:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9779:	48 89 c5             	mov    %rax,%rbp
    977c:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9783:	48 c1 e2 10          	shl    $0x10,%rdx
    9787:	48 39 d0             	cmp    %rdx,%rax
    978a:	0f 83 f0 0d 00 00    	jae    a580 <fwp_hof0.constprop.0+0x1260>
    9790:	48 89 c2             	mov    %rax,%rdx
    9793:	48 c1 ea 10          	shr    $0x10,%rdx
    9797:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    979b:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    97a2:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    97a6:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    97aa:	4d 85 ff             	test   %r15,%r15
    97ad:	74 3a                	je     97e9 <fwp_hof0.constprop.0+0x4c9>
    97af:	0f b6 32             	movzbl (%rdx),%esi
    97b2:	40 80 fe 02          	cmp    $0x2,%sil
    97b6:	0f 84 87 0d 00 00    	je     a543 <fwp_hof0.constprop.0+0x1223>
    97bc:	40 80 fe 01          	cmp    $0x1,%sil
    97c0:	75 27                	jne    97e9 <fwp_hof0.constprop.0+0x4c9>
    97c2:	8b 72 18             	mov    0x18(%rdx),%esi
    97c5:	0f b7 c0             	movzwl %ax,%eax
    97c8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    97cb:	48 0f af c6          	imul   %rsi,%rax
    97cf:	48 c1 e8 20          	shr    $0x20,%rax
    97d3:	48 39 d0             	cmp    %rdx,%rax
    97d6:	73 11                	jae    97e9 <fwp_hof0.constprop.0+0x4c9>
    97d8:	49 01 c7             	add    %rax,%r15
    97db:	41 80 3f ff          	cmpb   $0xff,(%r15)
    97df:	0f 84 71 0d 00 00    	je     a556 <fwp_hof0.constprop.0+0x1236>
    97e5:	41 c6 07 01          	movb   $0x1,(%r15)
    97e9:	4d 85 e4             	test   %r12,%r12
    97ec:	74 45                	je     9833 <fwp_hof0.constprop.0+0x513>
    97ee:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    97f3:	48 8b 14 24          	mov    (%rsp),%rdx
    97f7:	31 c0                	xor    %eax,%eax
    97f9:	48 c1 e6 20          	shl    $0x20,%rsi
    97fd:	0f 1f 00             	nopl   (%rax)
    9800:	48 89 c1             	mov    %rax,%rcx
    9803:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    9808:	48 01 f1             	add    %rsi,%rcx
    980b:	0f 80 3f 9f ff ff    	jo     3750 <fwp_hof0.constprop.0.cold+0x5>
    9811:	66 48 0f 6e d9       	movq   %rcx,%xmm3
    9816:	48 89 c1             	mov    %rax,%rcx
    9819:	48 83 c0 01          	add    $0x1,%rax
    981d:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    9821:	48 c1 e1 04          	shl    $0x4,%rcx
    9825:	0f 11 44 0d 08       	movups %xmm0,0x8(%rbp,%rcx,1)
    982a:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    982e:	4c 39 e0             	cmp    %r12,%rax
    9831:	72 cd                	jb     9800 <fwp_hof0.constprop.0+0x4e0>
    9833:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9837:	48 d1 e8             	shr    $1,%rax
    983a:	0f 84 50 0d 00 00    	je     a590 <fwp_hof0.constprop.0+0x1270>
    9840:	48 8d 70 ff          	lea    -0x1(%rax),%rsi
    9844:	48 89 f3             	mov    %rsi,%rbx
    9847:	48 c1 eb 3c          	shr    $0x3c,%rbx
    984b:	0f 85 80 12 00 00    	jne    aad1 <fwp_hof0.constprop.0+0x17b1>
    9851:	48 8d 1c 36          	lea    (%rsi,%rsi,1),%rbx
    9855:	48 85 f6             	test   %rsi,%rsi
    9858:	74 44                	je     989e <fwp_hof0.constprop.0+0x57e>
    985a:	48 c1 e0 04          	shl    $0x4,%rax
    985e:	4c 8d 7d 08          	lea    0x8(%rbp),%r15
    9862:	4c 8d 64 05 f8       	lea    -0x8(%rbp,%rax,1),%r12
    9867:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    986e:	00 00 
    9870:	f2 41 0f 10 07       	movsd  (%r15),%xmm0
    9875:	49 8b 77 18          	mov    0x18(%r15),%rsi
    9879:	49 83 c7 10          	add    $0x10,%r15
    987d:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
    9881:	f2 41 0f 10 0f       	movsd  (%r15),%xmm1
    9886:	e8 35 ca ff ff       	call   62c0 <w120>
    988b:	66 48 0f 6e e0       	movq   %rax,%xmm4
    9890:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    9894:	41 0f 11 47 f0       	movups %xmm0,-0x10(%r15)
    9899:	4d 39 fc             	cmp    %r15,%r12
    989c:	75 d2                	jne    9870 <fwp_hof0.constprop.0+0x550>
    989e:	48 89 5d 00          	mov    %rbx,0x0(%rbp)
    98a2:	48 89 ef             	mov    %rbp,%rdi
    98a5:	e8 96 cb ff ff       	call   6440 <w176.constprop.0>
    98aa:	48 89 ef             	mov    %rbp,%rdi
    98ad:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    98b2:	e8 d9 e2 ff ff       	call   7b90 <fwp_drop10>
    98b7:	bf 02 00 00 00       	mov    $0x2,%edi
    98bc:	e8 9f b6 ff ff       	call   4f60 <caf75>
    98c1:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    98c6:	e8 85 a9 ff ff       	call   4250 <descent_phase_step>
    98cb:	4c 63 7c 24 08       	movslq 0x8(%rsp),%r15
    98d0:	4c 89 ff             	mov    %r15,%rdi
    98d3:	e8 f8 ad ff ff       	call   46d0 <fwp_tape_of>
    98d8:	48 89 c6             	mov    %rax,%rsi
    98db:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    98e0:	0f 85 90 12 00 00    	jne    ab76 <fwp_hof0.constprop.0+0x1856>
    98e6:	48 89 c7             	mov    %rax,%rdi
    98e9:	e8 12 a3 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    98ee:	f3 0f 6f 76 20       	movdqu 0x20(%rsi),%xmm6
    98f3:	48 8b 56 48          	mov    0x48(%rsi),%rdx
    98f7:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    98fe:	f3 0f 6f 7e 30       	movdqu 0x30(%rsi),%xmm7
    9903:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    9908:	0f 29 74 24 20       	movaps %xmm6,0x20(%rsp)
    990d:	66 48 0f 6e f2       	movq   %rdx,%xmm6
    9912:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
    9916:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
    991a:	4c 8b 66 40          	mov    0x40(%rsi),%r12
    991e:	0f 29 7c 24 10       	movaps %xmm7,0x10(%rsp)
    9923:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    9927:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    992d:	77 1a                	ja     9949 <fwp_hof0.constprop.0+0x629>
    992f:	0f b7 44 24 08       	movzwl 0x8(%rsp),%eax
    9934:	83 e8 01             	sub    $0x1,%eax
    9937:	48 98                	cltq
    9939:	48 3b 05 b8 97 01 00 	cmp    0x197b8(%rip),%rax        # 230f8 <fwp_tape_next_slot>
    9940:	7d 07                	jge    9949 <fwp_hof0.constprop.0+0x629>
    9942:	48 89 05 af 97 01 00 	mov    %rax,0x197af(%rip)        # 230f8 <fwp_tape_next_slot>
    9949:	48 8b 05 28 bb 01 00 	mov    0x1bb28(%rip),%rax        # 25478 <fwp_cleanups>
    9950:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9954:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    995b:	00 
    995c:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    9960:	66 0f 6f 7c 24 20    	movdqa 0x20(%rsp),%xmm7
    9966:	66 0f 6f 74 24 10    	movdqa 0x10(%rsp),%xmm6
    996c:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    9973:	00 
    9974:	48 8d 05 55 b7 ff ff 	lea    -0x48ab(%rip),%rax        # 50d0 <fwp_tape_buffers_release>
    997b:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    9982:	00 
    9983:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    998a:	00 
    998b:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    998f:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    9993:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
    9998:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    999f:	00 
    99a0:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
    99a7:	00 
    99a8:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    99ad:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    99b4:	00 
    99b5:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    99bc:	00 
    99bd:	4c 89 a4 24 e0 00 00 	mov    %r12,0xe0(%rsp)
    99c4:	00 
    99c5:	48 89 05 ac ba 01 00 	mov    %rax,0x1baac(%rip)        # 25478 <fwp_cleanups>
    99cc:	0f 29 bc 24 c0 00 00 	movaps %xmm7,0xc0(%rsp)
    99d3:	00 
    99d4:	0f 29 b4 24 d0 00 00 	movaps %xmm6,0xd0(%rsp)
    99db:	00 
    99dc:	0f 11 84 24 e8 00 00 	movups %xmm0,0xe8(%rsp)
    99e3:	00 
    99e4:	48 85 f6             	test   %rsi,%rsi
    99e7:	0f 88 33 0d 00 00    	js     a720 <fwp_hof0.constprop.0+0x1400>
    99ed:	48 89 f0             	mov    %rsi,%rax
    99f0:	48 c1 f8 20          	sar    $0x20,%rax
    99f4:	49 39 c7             	cmp    %rax,%r15
    99f7:	0f 85 90 10 00 00    	jne    aa8d <fwp_hof0.constprop.0+0x176d>
    99fd:	41 89 f2             	mov    %esi,%r10d
    9a00:	4d 89 d7             	mov    %r10,%r15
    9a03:	4c 39 d7             	cmp    %r10,%rdi
    9a06:	0f 8e 8d 10 00 00    	jle    aa99 <fwp_hof0.constprop.0+0x1779>
    9a0c:	4c 39 d3             	cmp    %r10,%rbx
    9a0f:	0f 8e cb 0b 00 00    	jle    a5e0 <fwp_hof0.constprop.0+0x12c0>
    9a15:	48 39 d3             	cmp    %rdx,%rbx
    9a18:	0f 8f 0a 0c 00 00    	jg     a628 <fwp_hof0.constprop.0+0x1308>
    9a1e:	4d 85 e4             	test   %r12,%r12
    9a21:	0f 84 ce 10 00 00    	je     aaf5 <fwp_hof0.constprop.0+0x17d5>
    9a27:	31 f6                	xor    %esi,%esi
    9a29:	4c 89 e7             	mov    %r12,%rdi
    9a2c:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    9a31:	4c 8d 7b ff          	lea    -0x1(%rbx),%r15
    9a35:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    9a3c:	00 
    9a3d:	e8 7e 9a ff ff       	call   34c0 <memset@plt>
    9a42:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    9a47:	45 31 db             	xor    %r11d,%r11d
    9a4a:	f2 0f 10 44 24 58    	movsd  0x58(%rsp),%xmm0
    9a50:	f2 43 0f 58 04 d4    	addsd  (%r12,%r10,8),%xmm0
    9a56:	f2 43 0f 11 04 d4    	movsd  %xmm0,(%r12,%r10,8)
    9a5c:	bf 03 00 00 00       	mov    $0x3,%edi
    9a61:	48 01 1d b8 96 01 00 	add    %rbx,0x196b8(%rip)        # 23120 <descent_inputs>
    9a68:	4c 01 1d b9 96 01 00 	add    %r11,0x196b9(%rip)        # 23128 <descent_nodes>
    9a6f:	e8 dc a7 ff ff       	call   4250 <descent_phase_step>
    9a74:	49 39 df             	cmp    %rbx,%r15
    9a77:	0f 8c 83 00 00 00    	jl     9b00 <fwp_hof0.constprop.0+0x7e0>
    9a7d:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    9a82:	49 29 df             	sub    %rbx,%r15
    9a85:	49 8d 2c dc          	lea    (%r12,%rbx,8),%rbp
    9a89:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9a8d:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    9a92:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
    9a97:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    9a9c:	4b 8d 14 fb          	lea    (%r11,%r15,8),%rdx
    9aa0:	4c 29 dd             	sub    %r11,%rbp
    9aa3:	4a 8d 04 bf          	lea    (%rdi,%r15,4),%rax
    9aa7:	48 29 fe             	sub    %rdi,%rsi
    9aaa:	4d 29 da             	sub    %r11,%r10
    9aad:	eb 05                	jmp    9ab4 <fwp_hof0.constprop.0+0x794>
    9aaf:	90                   	nop
    9ab0:	48 83 e8 04          	sub    $0x4,%rax
    9ab4:	f2 0f 10 44 15 00    	movsd  0x0(%rbp,%rdx,1),%xmm0
    9aba:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    9abe:	7a 02                	jp     9ac2 <fwp_hof0.constprop.0+0x7a2>
    9ac0:	74 35                	je     9af7 <fwp_hof0.constprop.0+0x7d7>
    9ac2:	48 63 0c 06          	movslq (%rsi,%rax,1),%rcx
    9ac6:	85 c9                	test   %ecx,%ecx
    9ac8:	78 16                	js     9ae0 <fwp_hof0.constprop.0+0x7c0>
    9aca:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    9ad0:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    9ad4:	f2 41 0f 58 0c cc    	addsd  (%r12,%rcx,8),%xmm1
    9ada:	f2 41 0f 11 0c cc    	movsd  %xmm1,(%r12,%rcx,8)
    9ae0:	48 63 08             	movslq (%rax),%rcx
    9ae3:	85 c9                	test   %ecx,%ecx
    9ae5:	78 10                	js     9af7 <fwp_hof0.constprop.0+0x7d7>
    9ae7:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    9aeb:	f2 41 0f 58 04 cc    	addsd  (%r12,%rcx,8),%xmm0
    9af1:	f2 41 0f 11 04 cc    	movsd  %xmm0,(%r12,%rcx,8)
    9af7:	48 83 ea 08          	sub    $0x8,%rdx
    9afb:	48 39 c7             	cmp    %rax,%rdi
    9afe:	75 b0                	jne    9ab0 <fwp_hof0.constprop.0+0x790>
    9b00:	bf 04 00 00 00       	mov    $0x4,%edi
    9b05:	e8 46 a7 ff ff       	call   4250 <descent_phase_step>
    9b0a:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9b11:	ff ff 1f 
    9b14:	48 39 d8             	cmp    %rbx,%rax
    9b17:	0f 82 a8 0f 00 00    	jb     aac5 <fwp_hof0.constprop.0+0x17a5>
    9b1d:	48 8d 3c dd 08 00 00 	lea    0x8(,%rbx,8),%rdi
    9b24:	00 
    9b25:	be 02 00 00 00       	mov    $0x2,%esi
    9b2a:	e8 c1 c1 ff ff       	call   5cf0 <fwp_heap_alloc>
    9b2f:	48 89 18             	mov    %rbx,(%rax)
    9b32:	49 89 c7             	mov    %rax,%r15
    9b35:	48 85 db             	test   %rbx,%rbx
    9b38:	74 18                	je     9b52 <fwp_hof0.constprop.0+0x832>
    9b3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9b40:	4b 8b 04 f4          	mov    (%r12,%r14,8),%rax
    9b44:	4b 89 44 f7 08       	mov    %rax,0x8(%r15,%r14,8)
    9b49:	49 83 c6 01          	add    $0x1,%r14
    9b4d:	4c 39 f3             	cmp    %r14,%rbx
    9b50:	75 ee                	jne    9b40 <fwp_hof0.constprop.0+0x820>
    9b52:	bf 05 00 00 00       	mov    $0x5,%edi
    9b57:	e8 f4 a6 ff ff       	call   4250 <descent_phase_step>
    9b5c:	4c 8b a4 24 a0 00 00 	mov    0xa0(%rsp),%r12
    9b63:	00 
    9b64:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    9b69:	4c 89 25 08 b9 01 00 	mov    %r12,0x1b908(%rip)        # 25478 <fwp_cleanups>
    9b70:	e8 5b b5 ff ff       	call   50d0 <fwp_tape_buffers_release>
    9b75:	bf 06 00 00 00       	mov    $0x6,%edi
    9b7a:	e8 d1 a6 ff ff       	call   4250 <descent_phase_step>
    9b7f:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9b86:	4c 89 f8             	mov    %r15,%rax
    9b89:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9b90:	48 c1 e2 10          	shl    $0x10,%rdx
    9b94:	48 39 d0             	cmp    %rdx,%rax
    9b97:	73 57                	jae    9bf0 <fwp_hof0.constprop.0+0x8d0>
    9b99:	48 89 c2             	mov    %rax,%rdx
    9b9c:	48 c1 ea 10          	shr    $0x10,%rdx
    9ba0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ba4:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9bab:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9baf:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9bb3:	48 85 ed             	test   %rbp,%rbp
    9bb6:	74 38                	je     9bf0 <fwp_hof0.constprop.0+0x8d0>
    9bb8:	0f b6 0a             	movzbl (%rdx),%ecx
    9bbb:	80 f9 02             	cmp    $0x2,%cl
    9bbe:	0f 84 8c 0b 00 00    	je     a750 <fwp_hof0.constprop.0+0x1430>
    9bc4:	80 f9 01             	cmp    $0x1,%cl
    9bc7:	75 27                	jne    9bf0 <fwp_hof0.constprop.0+0x8d0>
    9bc9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9bcc:	0f b7 c0             	movzwl %ax,%eax
    9bcf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9bd2:	48 0f af c1          	imul   %rcx,%rax
    9bd6:	48 c1 e8 20          	shr    $0x20,%rax
    9bda:	48 39 d0             	cmp    %rdx,%rax
    9bdd:	73 11                	jae    9bf0 <fwp_hof0.constprop.0+0x8d0>
    9bdf:	48 01 c5             	add    %rax,%rbp
    9be2:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9be6:	0f 84 77 0b 00 00    	je     a763 <fwp_hof0.constprop.0+0x1443>
    9bec:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    9bf0:	4c 3b 64 24 50       	cmp    0x50(%rsp),%r12
    9bf5:	0f 85 50 9b ff ff    	jne    374b <fwp_hof0.constprop.0.cold>
    9bfb:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    9c02:	00 
    9c03:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
    9c08:	48 89 05 69 b8 01 00 	mov    %rax,0x1b869(%rip)        # 25478 <fwp_cleanups>
    9c0f:	e8 4c d0 ff ff       	call   6c60 <fwp_tape_scope_release>
    9c14:	49 8b 07             	mov    (%r15),%rax
    9c17:	49 89 c6             	mov    %rax,%r14
    9c1a:	49 0f ba f6 3f       	btr    $0x3f,%r14
    9c1f:	48 85 c0             	test   %rax,%rax
    9c22:	0f 88 d8 07 00 00    	js     a400 <fwp_hof0.constprop.0+0x10e0>
    9c28:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9c2f:	4c 89 f8             	mov    %r15,%rax
    9c32:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9c39:	48 c1 e2 10          	shl    $0x10,%rdx
    9c3d:	48 39 d0             	cmp    %rdx,%rax
    9c40:	0f 83 ba 07 00 00    	jae    a400 <fwp_hof0.constprop.0+0x10e0>
    9c46:	48 89 c2             	mov    %rax,%rdx
    9c49:	48 c1 ea 10          	shr    $0x10,%rdx
    9c4d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9c51:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9c58:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9c5c:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    9c60:	48 85 c9             	test   %rcx,%rcx
    9c63:	0f 84 97 07 00 00    	je     a400 <fwp_hof0.constprop.0+0x10e0>
    9c69:	0f b6 32             	movzbl (%rdx),%esi
    9c6c:	40 80 fe 02          	cmp    $0x2,%sil
    9c70:	0f 84 7a 07 00 00    	je     a3f0 <fwp_hof0.constprop.0+0x10d0>
    9c76:	40 80 fe 01          	cmp    $0x1,%sil
    9c7a:	0f 85 80 07 00 00    	jne    a400 <fwp_hof0.constprop.0+0x10e0>
    9c80:	8b 72 18             	mov    0x18(%rdx),%esi
    9c83:	0f b7 c0             	movzwl %ax,%eax
    9c86:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9c89:	48 0f af c6          	imul   %rsi,%rax
    9c8d:	48 c1 e8 20          	shr    $0x20,%rax
    9c91:	48 39 d0             	cmp    %rdx,%rax
    9c94:	0f 83 66 07 00 00    	jae    a400 <fwp_hof0.constprop.0+0x10e0>
    9c9a:	48 01 c1             	add    %rax,%rcx
    9c9d:	80 39 01             	cmpb   $0x1,(%rcx)
    9ca0:	0f 85 5a 07 00 00    	jne    a400 <fwp_hof0.constprop.0+0x10e0>
    9ca6:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
    9cab:	4c 89 fd             	mov    %r15,%rbp
    9cae:	31 ff                	xor    %edi,%edi
    9cb0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9cb5:	48 8d 50 08          	lea    0x8(%rax),%rdx
    9cb9:	31 c0                	xor    %eax,%eax
    9cbb:	4d 85 f6             	test   %r14,%r14
    9cbe:	75 32                	jne    9cf2 <fwp_hof0.constprop.0+0x9d2>
    9cc0:	eb 46                	jmp    9d08 <fwp_hof0.constprop.0+0x9e8>
    9cc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9cc8:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9ccd:	0f 88 d2 0d 00 00    	js     aaa5 <fwp_hof0.constprop.0+0x1785>
    9cd3:	f2 0f 10 05 d5 5e 00 	movsd  0x5ed5(%rip),%xmm0        # fbb0 <msg.8+0x40>
    9cda:	00 
    9cdb:	f2 0f 59 04 c1       	mulsd  (%rcx,%rax,8),%xmm0
    9ce0:	48 83 c0 01          	add    $0x1,%rax
    9ce4:	48 83 c2 08          	add    $0x8,%rdx
    9ce8:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    9ced:	49 39 c6             	cmp    %rax,%r14
    9cf0:	74 16                	je     9d08 <fwp_hof0.constprop.0+0x9e8>
    9cf2:	49 8d 4f 08          	lea    0x8(%r15),%rcx
    9cf6:	49 83 3f 00          	cmpq   $0x0,(%r15)
    9cfa:	79 cc                	jns    9cc8 <fwp_hof0.constprop.0+0x9a8>
    9cfc:	49 8b 4f 10          	mov    0x10(%r15),%rcx
    9d00:	eb c6                	jmp    9cc8 <fwp_hof0.constprop.0+0x9a8>
    9d02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9d08:	e8 83 de ff ff       	call   7b90 <fwp_drop10>
    9d0d:	48 8b 1c 24          	mov    (%rsp),%rbx
    9d11:	31 d2                	xor    %edx,%edx
    9d13:	48 89 d8             	mov    %rbx,%rax
    9d16:	48 85 db             	test   %rbx,%rbx
    9d19:	0f 84 c0 0b 00 00    	je     a8df <fwp_hof0.constprop.0+0x15bf>
    9d1f:	90                   	nop
    9d20:	48 8b 40 10          	mov    0x10(%rax),%rax
    9d24:	48 83 c2 01          	add    $0x1,%rdx
    9d28:	48 85 c0             	test   %rax,%rax
    9d2b:	75 f3                	jne    9d20 <fwp_hof0.constprop.0+0xa00>
    9d2d:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9d31:	49 89 c7             	mov    %rax,%r15
    9d34:	49 0f ba f7 3f       	btr    $0x3f,%r15
    9d39:	48 85 c0             	test   %rax,%rax
    9d3c:	0f 88 9a 05 00 00    	js     a2dc <fwp_hof0.constprop.0+0xfbc>
    9d42:	49 8b 85 d8 13 00 00 	mov    0x13d8(%r13),%rax
    9d49:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9d4e:	49 2b 8d b0 13 00 00 	sub    0x13b0(%r13),%rcx
    9d55:	48 c1 e0 10          	shl    $0x10,%rax
    9d59:	48 39 c1             	cmp    %rax,%rcx
    9d5c:	0f 83 7a 05 00 00    	jae    a2dc <fwp_hof0.constprop.0+0xfbc>
    9d62:	48 89 c8             	mov    %rcx,%rax
    9d65:	48 c1 e8 10          	shr    $0x10,%rax
    9d69:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    9d6d:	49 8b 85 f8 13 00 00 	mov    0x13f8(%r13),%rax
    9d74:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    9d78:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9d7c:	48 85 ff             	test   %rdi,%rdi
    9d7f:	0f 84 57 05 00 00    	je     a2dc <fwp_hof0.constprop.0+0xfbc>
    9d85:	0f b6 06             	movzbl (%rsi),%eax
    9d88:	3c 02                	cmp    $0x2,%al
    9d8a:	0f 84 38 05 00 00    	je     a2c8 <fwp_hof0.constprop.0+0xfa8>
    9d90:	3c 01                	cmp    $0x1,%al
    9d92:	0f 85 39 05 00 00    	jne    a2d1 <fwp_hof0.constprop.0+0xfb1>
    9d98:	8b 46 18             	mov    0x18(%rsi),%eax
    9d9b:	0f b7 c9             	movzwl %cx,%ecx
    9d9e:	48 0f af c8          	imul   %rax,%rcx
    9da2:	8b 46 1c             	mov    0x1c(%rsi),%eax
    9da5:	48 c1 e9 20          	shr    $0x20,%rcx
    9da9:	48 39 c1             	cmp    %rax,%rcx
    9dac:	0f 83 1f 05 00 00    	jae    a2d1 <fwp_hof0.constprop.0+0xfb1>
    9db2:	48 01 cf             	add    %rcx,%rdi
    9db5:	80 3f 01             	cmpb   $0x1,(%rdi)
    9db8:	0f 85 13 05 00 00    	jne    a2d1 <fwp_hof0.constprop.0+0xfb1>
    9dbe:	49 39 d7             	cmp    %rdx,%r15
    9dc1:	48 89 d0             	mov    %rdx,%rax
    9dc4:	49 0f 46 c7          	cmovbe %r15,%rax
    9dc8:	48 85 c0             	test   %rax,%rax
    9dcb:	0f 84 e0 0c 00 00    	je     aab1 <fwp_hof0.constprop.0+0x1791>
    9dd1:	c7 44 24 10 01 00 00 	movl   $0x1,0x10(%rsp)
    9dd8:	00 
    9dd9:	4c 8d 65 08          	lea    0x8(%rbp),%r12
    9ddd:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    9de2:	48 8b 0c 24          	mov    (%rsp),%rcx
    9de6:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    9ded:	00 
    9dee:	31 d2                	xor    %edx,%edx
    9df0:	49 8d 78 08          	lea    0x8(%r8),%rdi
    9df4:	eb 27                	jmp    9e1d <fwp_hof0.constprop.0+0xafd>
    9df6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9dfd:	00 00 00 
    9e00:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9e05:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    9e0a:	f2 41 0f 11 04 14    	movsd  %xmm0,(%r12,%rdx,1)
    9e10:	48 83 c2 08          	add    $0x8,%rdx
    9e14:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9e18:	49 39 d1             	cmp    %rdx,%r9
    9e1b:	74 13                	je     9e30 <fwp_hof0.constprop.0+0xb10>
    9e1d:	48 89 fe             	mov    %rdi,%rsi
    9e20:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9e25:	79 d9                	jns    9e00 <fwp_hof0.constprop.0+0xae0>
    9e27:	49 8b 70 10          	mov    0x10(%r8),%rsi
    9e2b:	eb d3                	jmp    9e00 <fwp_hof0.constprop.0+0xae0>
    9e2d:	0f 1f 00             	nopl   (%rax)
    9e30:	48 8b 0c 24          	mov    (%rsp),%rcx
    9e34:	48 85 c9             	test   %rcx,%rcx
    9e37:	0f 84 48 0c 00 00    	je     aa85 <fwp_hof0.constprop.0+0x1765>
    9e3d:	4d 8b 8d d8 13 00 00 	mov    0x13d8(%r13),%r9
    9e44:	4d 8b 95 b0 13 00 00 	mov    0x13b0(%r13),%r10
    9e4b:	45 31 ff             	xor    %r15d,%r15d
    9e4e:	4d 8b 9d f8 13 00 00 	mov    0x13f8(%r13),%r11
    9e55:	49 c1 e1 10          	shl    $0x10,%r9
    9e59:	eb 1b                	jmp    9e76 <fwp_hof0.constprop.0+0xb56>
    9e5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9e60:	49 83 c7 01          	add    $0x1,%r15
    9e64:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9e68:	49 39 c7             	cmp    %rax,%r15
    9e6b:	0f 83 5f 01 00 00    	jae    9fd0 <fwp_hof0.constprop.0+0xcb0>
    9e71:	48 85 c9             	test   %rcx,%rcx
    9e74:	74 56                	je     9ecc <fwp_hof0.constprop.0+0xbac>
    9e76:	48 89 ca             	mov    %rcx,%rdx
    9e79:	4c 29 d2             	sub    %r10,%rdx
    9e7c:	4c 39 ca             	cmp    %r9,%rdx
    9e7f:	73 4b                	jae    9ecc <fwp_hof0.constprop.0+0xbac>
    9e81:	48 89 d6             	mov    %rdx,%rsi
    9e84:	48 c1 ee 10          	shr    $0x10,%rsi
    9e88:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    9e8c:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    9e90:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9e94:	48 85 ff             	test   %rdi,%rdi
    9e97:	74 33                	je     9ecc <fwp_hof0.constprop.0+0xbac>
    9e99:	44 0f b6 06          	movzbl (%rsi),%r8d
    9e9d:	41 80 f8 02          	cmp    $0x2,%r8b
    9ea1:	0f 84 11 01 00 00    	je     9fb8 <fwp_hof0.constprop.0+0xc98>
    9ea7:	41 80 f8 01          	cmp    $0x1,%r8b
    9eab:	75 1f                	jne    9ecc <fwp_hof0.constprop.0+0xbac>
    9ead:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    9eb1:	0f b7 d2             	movzwl %dx,%edx
    9eb4:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9eb7:	49 0f af d0          	imul   %r8,%rdx
    9ebb:	48 c1 ea 20          	shr    $0x20,%rdx
    9ebf:	48 39 f2             	cmp    %rsi,%rdx
    9ec2:	73 08                	jae    9ecc <fwp_hof0.constprop.0+0xbac>
    9ec4:	48 01 d7             	add    %rdx,%rdi
    9ec7:	80 3f 01             	cmpb   $0x1,(%rdi)
    9eca:	74 94                	je     9e60 <fwp_hof0.constprop.0+0xb40>
    9ecc:	49 39 c7             	cmp    %rax,%r15
    9ecf:	0f 83 fb 00 00 00    	jae    9fd0 <fwp_hof0.constprop.0+0xcb0>
    9ed5:	48 89 c3             	mov    %rax,%rbx
    9ed8:	45 31 f6             	xor    %r14d,%r14d
    9edb:	48 8d ac 24 00 01 00 	lea    0x100(%rsp),%rbp
    9ee2:	00 
    9ee3:	eb 37                	jmp    9f1c <fwp_hof0.constprop.0+0xbfc>
    9ee5:	0f 1f 00             	nopl   (%rax)
    9ee8:	40 80 fe 01          	cmp    $0x1,%sil
    9eec:	75 25                	jne    9f13 <fwp_hof0.constprop.0+0xbf3>
    9eee:	8b 71 18             	mov    0x18(%rcx),%esi
    9ef1:	0f b7 c0             	movzwl %ax,%eax
    9ef4:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9ef7:	48 0f af c6          	imul   %rsi,%rax
    9efb:	48 c1 e8 20          	shr    $0x20,%rax
    9eff:	48 39 c8             	cmp    %rcx,%rax
    9f02:	73 0f                	jae    9f13 <fwp_hof0.constprop.0+0xbf3>
    9f04:	48 01 c2             	add    %rax,%rdx
    9f07:	80 3a ff             	cmpb   $0xff,(%rdx)
    9f0a:	0f 84 a0 05 00 00    	je     a4b0 <fwp_hof0.constprop.0+0x1190>
    9f10:	c6 02 01             	movb   $0x1,(%rdx)
    9f13:	49 39 df             	cmp    %rbx,%r15
    9f16:	0f 83 84 00 00 00    	jae    9fa0 <fwp_hof0.constprop.0+0xc80>
    9f1c:	48 83 eb 01          	sub    $0x1,%rbx
    9f20:	66 49 0f 6e ee       	movq   %r14,%xmm5
    9f25:	48 89 ee             	mov    %rbp,%rsi
    9f28:	bf 01 00 00 00       	mov    $0x1,%edi
    9f2d:	f3 41 0f 7e 04 dc    	movq   (%r12,%rbx,8),%xmm0
    9f33:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    9f37:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
    9f3e:	00 
    9f3f:	e8 cc be ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    9f44:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    9f4b:	49 89 c6             	mov    %rax,%r14
    9f4e:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    9f55:	48 c1 e2 10          	shl    $0x10,%rdx
    9f59:	48 39 d0             	cmp    %rdx,%rax
    9f5c:	73 b5                	jae    9f13 <fwp_hof0.constprop.0+0xbf3>
    9f5e:	48 89 c2             	mov    %rax,%rdx
    9f61:	48 c1 ea 10          	shr    $0x10,%rdx
    9f65:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f69:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    9f70:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    9f74:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    9f78:	48 85 d2             	test   %rdx,%rdx
    9f7b:	74 96                	je     9f13 <fwp_hof0.constprop.0+0xbf3>
    9f7d:	0f b6 31             	movzbl (%rcx),%esi
    9f80:	40 80 fe 02          	cmp    $0x2,%sil
    9f84:	0f 85 5e ff ff ff    	jne    9ee8 <fwp_hof0.constprop.0+0xbc8>
    9f8a:	66 85 c0             	test   %ax,%ax
    9f8d:	0f 84 74 ff ff ff    	je     9f07 <fwp_hof0.constprop.0+0xbe7>
    9f93:	49 39 df             	cmp    %rbx,%r15
    9f96:	72 84                	jb     9f1c <fwp_hof0.constprop.0+0xbfc>
    9f98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9f9f:	00 
    9fa0:	4d 85 ff             	test   %r15,%r15
    9fa3:	75 2e                	jne    9fd3 <fwp_hof0.constprop.0+0xcb3>
    9fa5:	8b 44 24 10          	mov    0x10(%rsp),%eax
    9fa9:	85 c0                	test   %eax,%eax
    9fab:	4d 0f 45 e7          	cmovne %r15,%r12
    9faf:	eb 61                	jmp    a012 <fwp_hof0.constprop.0+0xcf2>
    9fb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9fb8:	66 85 d2             	test   %dx,%dx
    9fbb:	0f 84 06 ff ff ff    	je     9ec7 <fwp_hof0.constprop.0+0xba7>
    9fc1:	49 39 c7             	cmp    %rax,%r15
    9fc4:	0f 82 0b ff ff ff    	jb     9ed5 <fwp_hof0.constprop.0+0xbb5>
    9fca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9fd0:	45 31 f6             	xor    %r14d,%r14d
    9fd3:	48 8b 04 24          	mov    (%rsp),%rax
    9fd7:	4c 89 e2             	mov    %r12,%rdx
    9fda:	4f 8d 0c fc          	lea    (%r12,%r15,8),%r9
    9fde:	66 90                	xchg   %ax,%ax
    9fe0:	48 8b 0a             	mov    (%rdx),%rcx
    9fe3:	48 83 c2 08          	add    $0x8,%rdx
    9fe7:	48 89 c7             	mov    %rax,%rdi
    9fea:	48 89 48 08          	mov    %rcx,0x8(%rax)
    9fee:	48 8b 40 10          	mov    0x10(%rax),%rax
    9ff2:	4c 39 ca             	cmp    %r9,%rdx
    9ff5:	75 e9                	jne    9fe0 <fwp_hof0.constprop.0+0xcc0>
    9ff7:	8b 54 24 10          	mov    0x10(%rsp),%edx
    9ffb:	4c 89 77 10          	mov    %r14,0x10(%rdi)
    9fff:	85 d2                	test   %edx,%edx
    a001:	0f 84 69 07 00 00    	je     a770 <fwp_hof0.constprop.0+0x1450>
    a007:	4c 8b 34 24          	mov    (%rsp),%r14
    a00b:	48 89 04 24          	mov    %rax,(%rsp)
    a00f:	45 31 e4             	xor    %r12d,%r12d
    a012:	4c 89 e7             	mov    %r12,%rdi
    a015:	e8 d6 b7 ff ff       	call   57f0 <fwp_mem_free>
    a01a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a01f:	e8 6c db ff ff       	call   7b90 <fwp_drop10>
    a024:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a02b:	48 8b 04 24          	mov    (%rsp),%rax
    a02f:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a036:	48 c1 e2 10          	shl    $0x10,%rdx
    a03a:	48 39 d0             	cmp    %rdx,%rax
    a03d:	73 71                	jae    a0b0 <fwp_hof0.constprop.0+0xd90>
    a03f:	48 89 c2             	mov    %rax,%rdx
    a042:	49 8b b5 f8 13 00 00 	mov    0x13f8(%r13),%rsi
    a049:	48 c1 ea 10          	shr    $0x10,%rdx
    a04d:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    a051:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    a055:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    a059:	48 85 ed             	test   %rbp,%rbp
    a05c:	74 52                	je     a0b0 <fwp_hof0.constprop.0+0xd90>
    a05e:	0f b6 0a             	movzbl (%rdx),%ecx
    a061:	80 f9 02             	cmp    $0x2,%cl
    a064:	0f 84 96 06 00 00    	je     a700 <fwp_hof0.constprop.0+0x13e0>
    a06a:	80 f9 01             	cmp    $0x1,%cl
    a06d:	75 41                	jne    a0b0 <fwp_hof0.constprop.0+0xd90>
    a06f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a072:	0f b7 c0             	movzwl %ax,%eax
    a075:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a078:	48 0f af c1          	imul   %rcx,%rax
    a07c:	48 c1 e8 20          	shr    $0x20,%rax
    a080:	48 39 d0             	cmp    %rdx,%rax
    a083:	73 2b                	jae    a0b0 <fwp_hof0.constprop.0+0xd90>
    a085:	48 01 c5             	add    %rax,%rbp
    a088:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    a08c:	84 c0                	test   %al,%al
    a08e:	74 20                	je     a0b0 <fwp_hof0.constprop.0+0xd90>
    a090:	3c 01                	cmp    $0x1,%al
    a092:	0f 84 e8 06 00 00    	je     a780 <fwp_hof0.constprop.0+0x1460>
    a098:	3c ff                	cmp    $0xff,%al
    a09a:	0f 84 aa 08 00 00    	je     a94a <fwp_hof0.constprop.0+0x162a>
    a0a0:	83 e8 01             	sub    $0x1,%eax
    a0a3:	88 45 00             	mov    %al,0x0(%rbp)
    a0a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a0ad:	00 00 00 
    a0b0:	48 83 7c 24 40 00    	cmpq   $0x0,0x40(%rsp)
    a0b6:	0f 85 04 05 00 00    	jne    a5c0 <fwp_hof0.constprop.0+0x12a0>
    a0bc:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    a0c1:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a0c5:	4c 89 f6             	mov    %r14,%rsi
    a0c8:	4c 89 f5             	mov    %r14,%rbp
    a0cb:	b9 01 00 00 00       	mov    $0x1,%ecx
    a0d0:	48 8d 15 a9 8a 00 00 	lea    0x8aa9(%rip),%rdx        # 12b80 <d0>
    a0d7:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
    a0de:	00 00 00 00 00 
    a0e3:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
    a0ea:	00 
    a0eb:	e8 f0 e1 ff ff       	call   82e0 <fwp_write>
    a0f0:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
    a0f7:	00 
    a0f8:	4c 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%r15
    a0ff:	00 
    a100:	48 8d 05 8a 4f 00 00 	lea    0x4f8a(%rip),%rax        # f091 <_IO_stdin_used+0x91>
    a107:	48 85 c9             	test   %rcx,%rcx
    a10a:	48 0f 44 c8          	cmove  %rax,%rcx
    a10e:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    a112:	0f 87 6f 0a 00 00    	ja     ab87 <fwp_hof0.constprop.0+0x1867>
    a118:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    a11c:	be 01 00 00 00       	mov    $0x1,%esi
    a121:	48 89 0c 24          	mov    %rcx,(%rsp)
    a125:	e8 c6 bb ff ff       	call   5cf0 <fwp_heap_alloc>
    a12a:	48 8b 34 24          	mov    (%rsp),%rsi
    a12e:	4c 89 fa             	mov    %r15,%rdx
    a131:	4c 89 38             	mov    %r15,(%rax)
    a134:	4c 8d 70 08          	lea    0x8(%rax),%r14
    a138:	48 89 c3             	mov    %rax,%rbx
    a13b:	4c 89 f7             	mov    %r14,%rdi
    a13e:	e8 5d 94 ff ff       	call   35a0 <memcpy@plt>
    a143:	42 c6 44 3b 08 00    	movb   $0x0,0x8(%rbx,%r15,1)
    a149:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
    a150:	00 
    a151:	e8 6a 92 ff ff       	call   33c0 <free@plt>
    a156:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a15d:	48 89 d8             	mov    %rbx,%rax
    a160:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a167:	48 c1 e2 10          	shl    $0x10,%rdx
    a16b:	48 39 d0             	cmp    %rdx,%rax
    a16e:	73 57                	jae    a1c7 <fwp_hof0.constprop.0+0xea7>
    a170:	48 89 c2             	mov    %rax,%rdx
    a173:	48 c1 ea 10          	shr    $0x10,%rdx
    a177:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a17b:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a182:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a186:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a18a:	4d 85 ff             	test   %r15,%r15
    a18d:	74 38                	je     a1c7 <fwp_hof0.constprop.0+0xea7>
    a18f:	0f b6 0a             	movzbl (%rdx),%ecx
    a192:	80 f9 02             	cmp    $0x2,%cl
    a195:	0f 84 d5 06 00 00    	je     a870 <fwp_hof0.constprop.0+0x1550>
    a19b:	80 f9 01             	cmp    $0x1,%cl
    a19e:	75 27                	jne    a1c7 <fwp_hof0.constprop.0+0xea7>
    a1a0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a1a3:	0f b7 c0             	movzwl %ax,%eax
    a1a6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a1a9:	48 0f af c1          	imul   %rcx,%rax
    a1ad:	48 c1 e8 20          	shr    $0x20,%rax
    a1b1:	48 39 d0             	cmp    %rdx,%rax
    a1b4:	73 11                	jae    a1c7 <fwp_hof0.constprop.0+0xea7>
    a1b6:	49 01 c7             	add    %rax,%r15
    a1b9:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a1bd:	0f 84 c0 06 00 00    	je     a883 <fwp_hof0.constprop.0+0x1563>
    a1c3:	41 c6 07 01          	movb   $0x1,(%r15)
    a1c7:	48 89 ef             	mov    %rbp,%rdi
    a1ca:	e8 d1 d5 ff ff       	call   77a0 <fwp_drop0>
    a1cf:	48 8b 13             	mov    (%rbx),%rdx
    a1d2:	be 01 00 00 00       	mov    $0x1,%esi
    a1d7:	4c 89 f7             	mov    %r14,%rdi
    a1da:	48 8b 0d 5f b2 01 00 	mov    0x1b25f(%rip),%rcx        # 25440 <fwp_prog_out>
    a1e1:	e8 9a 94 ff ff       	call   3680 <fwrite@plt>
    a1e6:	48 8b 35 53 b2 01 00 	mov    0x1b253(%rip),%rsi        # 25440 <fwp_prog_out>
    a1ed:	bf 0a 00 00 00       	mov    $0xa,%edi
    a1f2:	e8 e9 92 ff ff       	call   34e0 <fputc@plt>
    a1f7:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a1fe:	48 89 d8             	mov    %rbx,%rax
    a201:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a208:	48 c1 e2 10          	shl    $0x10,%rdx
    a20c:	48 39 d0             	cmp    %rdx,%rax
    a20f:	73 6f                	jae    a280 <fwp_hof0.constprop.0+0xf60>
    a211:	48 89 c2             	mov    %rax,%rdx
    a214:	48 c1 ea 10          	shr    $0x10,%rdx
    a218:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a21c:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a223:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a227:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    a22b:	48 85 ed             	test   %rbp,%rbp
    a22e:	74 50                	je     a280 <fwp_hof0.constprop.0+0xf60>
    a230:	0f b6 0a             	movzbl (%rdx),%ecx
    a233:	80 f9 02             	cmp    $0x2,%cl
    a236:	0f 84 54 06 00 00    	je     a890 <fwp_hof0.constprop.0+0x1570>
    a23c:	80 f9 01             	cmp    $0x1,%cl
    a23f:	75 3f                	jne    a280 <fwp_hof0.constprop.0+0xf60>
    a241:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a244:	0f b7 c0             	movzwl %ax,%eax
    a247:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a24a:	48 0f af c1          	imul   %rcx,%rax
    a24e:	48 c1 e8 20          	shr    $0x20,%rax
    a252:	48 39 d0             	cmp    %rdx,%rax
    a255:	73 29                	jae    a280 <fwp_hof0.constprop.0+0xf60>
    a257:	48 01 c5             	add    %rax,%rbp
    a25a:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    a25e:	84 c0                	test   %al,%al
    a260:	74 1e                	je     a280 <fwp_hof0.constprop.0+0xf60>
    a262:	3c 01                	cmp    $0x1,%al
    a264:	0f 84 43 06 00 00    	je     a8ad <fwp_hof0.constprop.0+0x158d>
    a26a:	3c ff                	cmp    $0xff,%al
    a26c:	0f 84 53 07 00 00    	je     a9c5 <fwp_hof0.constprop.0+0x16a5>
    a272:	83 e8 01             	sub    $0x1,%eax
    a275:	88 45 00             	mov    %al,0x0(%rbp)
    a278:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a27f:	00 
    a280:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
    a285:	48 8b 40 10          	mov    0x10(%rax),%rax
    a289:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    a28e:	48 85 c0             	test   %rax,%rax
    a291:	0f 85 c9 f0 ff ff    	jne    9360 <fwp_hof0.constprop.0+0x40>
    a297:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    a29e:	00 
    a29f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a2a6:	00 00 
    a2a8:	0f 85 d4 08 00 00    	jne    ab82 <fwp_hof0.constprop.0+0x1862>
    a2ae:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    a2b5:	31 c0                	xor    %eax,%eax
    a2b7:	5b                   	pop    %rbx
    a2b8:	5d                   	pop    %rbp
    a2b9:	41 5c                	pop    %r12
    a2bb:	41 5d                	pop    %r13
    a2bd:	41 5e                	pop    %r14
    a2bf:	41 5f                	pop    %r15
    a2c1:	c3                   	ret
    a2c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a2c8:	66 85 c9             	test   %cx,%cx
    a2cb:	0f 84 e4 fa ff ff    	je     9db5 <fwp_hof0.constprop.0+0xa95>
    a2d1:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
    a2d6:	0f 84 87 02 00 00    	je     a563 <fwp_hof0.constprop.0+0x1243>
    a2dc:	48 8b 04 24          	mov    (%rsp),%rax
    a2e0:	45 31 f6             	xor    %r14d,%r14d
    a2e3:	66 90                	xchg   %ax,%ax
    a2e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a2ec:	00 00 00 00 
    a2f0:	48 8b 40 10          	mov    0x10(%rax),%rax
    a2f4:	4c 89 f2             	mov    %r14,%rdx
    a2f7:	49 83 c6 01          	add    $0x1,%r14
    a2fb:	48 85 c0             	test   %rax,%rax
    a2fe:	75 f0                	jne    a2f0 <fwp_hof0.constprop.0+0xfd0>
    a300:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a307:	ff ff 1f 
    a30a:	4c 39 f0             	cmp    %r14,%rax
    a30d:	0f 82 be 07 00 00    	jb     aad1 <fwp_hof0.constprop.0+0x17b1>
    a313:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    a31a:	00 
    a31b:	be 02 00 00 00       	mov    $0x2,%esi
    a320:	e8 cb b9 ff ff       	call   5cf0 <fwp_heap_alloc>
    a325:	4d 39 f7             	cmp    %r14,%r15
    a328:	48 8b 14 24          	mov    (%rsp),%rdx
    a32c:	49 89 c4             	mov    %rax,%r12
    a32f:	4c 89 f0             	mov    %r14,%rax
    a332:	49 0f 46 c7          	cmovbe %r15,%rax
    a336:	4c 89 e1             	mov    %r12,%rcx
    a339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a340:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    a344:	48 83 c1 08          	add    $0x8,%rcx
    a348:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    a34c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a350:	48 85 d2             	test   %rdx,%rdx
    a353:	75 eb                	jne    a340 <fwp_hof0.constprop.0+0x1020>
    a355:	48 85 c0             	test   %rax,%rax
    a358:	0f 84 17 02 00 00    	je     a575 <fwp_hof0.constprop.0+0x1255>
    a35e:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
    a365:	00 
    a366:	e9 72 fa ff ff       	jmp    9ddd <fwp_hof0.constprop.0+0xabd>
    a36b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a370:	48 83 3d 30 8d 01 00 	cmpq   $0x0,0x18d30(%rip)        # 230a8 <fwp_tape_cached_bytes>
    a377:	00 
    a378:	0f 84 d2 f2 ff ff    	je     9650 <fwp_hof0.constprop.0+0x330>
    a37e:	66 0f 6f 0d 3a 8d 01 	movdqa 0x18d3a(%rip),%xmm1        # 230c0 <fwp_tape_workspace>
    a385:	00 
    a386:	48 c7 05 17 8d 01 00 	movq   $0x0,0x18d17(%rip)        # 230a8 <fwp_tape_cached_bytes>
    a38d:	00 00 00 00 
    a391:	0f 11 49 20          	movups %xmm1,0x20(%rcx)
    a395:	48 8b 05 44 8d 01 00 	mov    0x18d44(%rip),%rax        # 230e0 <fwp_tape_workspace+0x20>
    a39c:	66 0f 6f 0d 2c 8d 01 	movdqa 0x18d2c(%rip),%xmm1        # 230d0 <fwp_tape_workspace+0x10>
    a3a3:	00 
    a3a4:	48 89 41 40          	mov    %rax,0x40(%rcx)
    a3a8:	48 8b 05 39 8d 01 00 	mov    0x18d39(%rip),%rax        # 230e8 <fwp_tape_workspace+0x28>
    a3af:	0f 11 49 30          	movups %xmm1,0x30(%rcx)
    a3b3:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a3b7:	48 89 41 18          	mov    %rax,0x18(%rcx)
    a3bb:	48 8b 05 2e 8d 01 00 	mov    0x18d2e(%rip),%rax        # 230f0 <fwp_tape_workspace+0x30>
    a3c2:	0f 29 0d f7 8c 01 00 	movaps %xmm1,0x18cf7(%rip)        # 230c0 <fwp_tape_workspace>
    a3c9:	48 89 41 48          	mov    %rax,0x48(%rcx)
    a3cd:	0f 29 0d fc 8c 01 00 	movaps %xmm1,0x18cfc(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    a3d4:	48 c7 05 11 8d 01 00 	movq   $0x0,0x18d11(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    a3db:	00 00 00 00 
    a3df:	0f 29 0d fa 8c 01 00 	movaps %xmm1,0x18cfa(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    a3e6:	e9 65 f2 ff ff       	jmp    9650 <fwp_hof0.constprop.0+0x330>
    a3eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a3f0:	66 85 c0             	test   %ax,%ax
    a3f3:	0f 84 a4 f8 ff ff    	je     9c9d <fwp_hof0.constprop.0+0x97d>
    a3f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a400:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a407:	ff ff 1f 
    a40a:	4c 39 f0             	cmp    %r14,%rax
    a40d:	0f 82 b2 06 00 00    	jb     aac5 <fwp_hof0.constprop.0+0x17a5>
    a413:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    a41a:	00 
    a41b:	be 01 00 00 00       	mov    $0x1,%esi
    a420:	e8 cb b8 ff ff       	call   5cf0 <fwp_heap_alloc>
    a425:	4c 89 30             	mov    %r14,(%rax)
    a428:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a42f:	48 89 c5             	mov    %rax,%rbp
    a432:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a437:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a43e:	48 c1 e2 10          	shl    $0x10,%rdx
    a442:	48 39 d0             	cmp    %rdx,%rax
    a445:	73 57                	jae    a49e <fwp_hof0.constprop.0+0x117e>
    a447:	48 89 c2             	mov    %rax,%rdx
    a44a:	48 c1 ea 10          	shr    $0x10,%rdx
    a44e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a452:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a459:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a45d:	48 8b 59 20          	mov    0x20(%rcx),%rbx
    a461:	48 85 db             	test   %rbx,%rbx
    a464:	74 38                	je     a49e <fwp_hof0.constprop.0+0x117e>
    a466:	0f b6 31             	movzbl (%rcx),%esi
    a469:	40 80 fe 02          	cmp    $0x2,%sil
    a46d:	0f 84 ad 03 00 00    	je     a820 <fwp_hof0.constprop.0+0x1500>
    a473:	40 80 fe 01          	cmp    $0x1,%sil
    a477:	75 25                	jne    a49e <fwp_hof0.constprop.0+0x117e>
    a479:	8b 71 18             	mov    0x18(%rcx),%esi
    a47c:	0f b7 c0             	movzwl %ax,%eax
    a47f:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a482:	48 0f af c6          	imul   %rsi,%rax
    a486:	48 c1 e8 20          	shr    $0x20,%rax
    a48a:	48 39 c8             	cmp    %rcx,%rax
    a48d:	73 0f                	jae    a49e <fwp_hof0.constprop.0+0x117e>
    a48f:	48 01 c3             	add    %rax,%rbx
    a492:	80 3b ff             	cmpb   $0xff,(%rbx)
    a495:	0f 84 97 03 00 00    	je     a832 <fwp_hof0.constprop.0+0x1512>
    a49b:	c6 03 01             	movb   $0x1,(%rbx)
    a49e:	4c 89 ff             	mov    %r15,%rdi
    a4a1:	e9 0a f8 ff ff       	jmp    9cb0 <fwp_hof0.constprop.0+0x990>
    a4a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a4ad:	00 00 00 
    a4b0:	48 89 d7             	mov    %rdx,%rdi
    a4b3:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    a4b8:	e8 f3 b0 ff ff       	call   55b0 <fwp_rc_forget_slot>
    a4bd:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    a4c2:	e9 49 fa ff ff       	jmp    9f10 <fwp_hof0.constprop.0+0xbf0>
    a4c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a4ce:	00 00 
    a4d0:	48 c1 e2 10          	shl    $0x10,%rdx
    a4d4:	be 02 00 00 00       	mov    $0x2,%esi
    a4d9:	bf 08 00 00 00       	mov    $0x8,%edi
    a4de:	48 09 ea             	or     %rbp,%rdx
    a4e1:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    a4e6:	e8 05 b8 ff ff       	call   5cf0 <fwp_heap_alloc>
    a4eb:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a4f2:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a4f9:	48 89 c5             	mov    %rax,%rbp
    a4fc:	49 2b 85 b0 13 00 00 	sub    0x13b0(%r13),%rax
    a503:	48 c1 e2 10          	shl    $0x10,%rdx
    a507:	48 39 d0             	cmp    %rdx,%rax
    a50a:	0f 83 80 00 00 00    	jae    a590 <fwp_hof0.constprop.0+0x1270>
    a510:	48 89 c2             	mov    %rax,%rdx
    a513:	48 c1 ea 10          	shr    $0x10,%rdx
    a517:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    a51b:	49 8b 95 f8 13 00 00 	mov    0x13f8(%r13),%rdx
    a522:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    a526:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a52a:	4d 85 ff             	test   %r15,%r15
    a52d:	0f 84 00 f3 ff ff    	je     9833 <fwp_hof0.constprop.0+0x513>
    a533:	0f b6 32             	movzbl (%rdx),%esi
    a536:	45 31 e4             	xor    %r12d,%r12d
    a539:	40 80 fe 02          	cmp    $0x2,%sil
    a53d:	0f 85 79 f2 ff ff    	jne    97bc <fwp_hof0.constprop.0+0x49c>
    a543:	66 85 c0             	test   %ax,%ax
    a546:	0f 85 9d f2 ff ff    	jne    97e9 <fwp_hof0.constprop.0+0x4c9>
    a54c:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a550:	0f 85 8f f2 ff ff    	jne    97e5 <fwp_hof0.constprop.0+0x4c5>
    a556:	4c 89 ff             	mov    %r15,%rdi
    a559:	e8 52 b0 ff ff       	call   55b0 <fwp_rc_forget_slot>
    a55e:	e9 82 f2 ff ff       	jmp    97e5 <fwp_hof0.constprop.0+0x4c5>
    a563:	be 02 00 00 00       	mov    $0x2,%esi
    a568:	bf 08 00 00 00       	mov    $0x8,%edi
    a56d:	e8 7e b7 ff ff       	call   5cf0 <fwp_heap_alloc>
    a572:	49 89 c4             	mov    %rax,%r12
    a575:	45 31 f6             	xor    %r14d,%r14d
    a578:	e9 95 fa ff ff       	jmp    a012 <fwp_hof0.constprop.0+0xcf2>
    a57d:	0f 1f 00             	nopl   (%rax)
    a580:	4d 85 e4             	test   %r12,%r12
    a583:	0f 85 65 f2 ff ff    	jne    97ee <fwp_hof0.constprop.0+0x4ce>
    a589:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a590:	31 db                	xor    %ebx,%ebx
    a592:	e9 07 f3 ff ff       	jmp    989e <fwp_hof0.constprop.0+0x57e>
    a597:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a59e:	00 00 
    a5a0:	49 39 d4             	cmp    %rdx,%r12
    a5a3:	0f 84 b7 ef ff ff    	je     9560 <fwp_hof0.constprop.0+0x240>
    a5a9:	48 8b 1d 60 8b 01 00 	mov    0x18b60(%rip),%rbx        # 23110 <fwp_tapes>
    a5b0:	49 89 d4             	mov    %rdx,%r12
    a5b3:	48 8d 6a 01          	lea    0x1(%rdx),%rbp
    a5b7:	e9 44 f0 ff ff       	jmp    9600 <fwp_hof0.constprop.0+0x2e0>
    a5bc:	0f 1f 40 00          	nopl   0x0(%rax)
    a5c0:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    a5c5:	45 31 c0             	xor    %r8d,%r8d
    a5c8:	4c 89 34 24          	mov    %r14,(%rsp)
    a5cc:	48 83 e8 01          	sub    $0x1,%rax
    a5d0:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    a5d5:	41 0f 90 c0          	seto   %r8b
    a5d9:	e9 10 ee ff ff       	jmp    93ee <fwp_hof0.constprop.0+0xce>
    a5de:	66 90                	xchg   %ax,%ax
    a5e0:	49 8d 6a 01          	lea    0x1(%r10),%rbp
    a5e4:	48 39 ea             	cmp    %rbp,%rdx
    a5e7:	7c 42                	jl     a62b <fwp_hof0.constprop.0+0x130b>
    a5e9:	4d 85 e4             	test   %r12,%r12
    a5ec:	0f 84 03 05 00 00    	je     aaf5 <fwp_hof0.constprop.0+0x17d5>
    a5f2:	49 89 eb             	mov    %rbp,%r11
    a5f5:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    a5fc:	00 
    a5fd:	31 f6                	xor    %esi,%esi
    a5ff:	4c 89 e7             	mov    %r12,%rdi
    a602:	49 29 db             	sub    %rbx,%r11
    a605:	4c 89 54 24 30       	mov    %r10,0x30(%rsp)
    a60a:	4c 89 5c 24 08       	mov    %r11,0x8(%rsp)
    a60f:	e8 ac 8e ff ff       	call   34c0 <memset@plt>
    a614:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    a619:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
    a61e:	e9 27 f4 ff ff       	jmp    9a4a <fwp_hof0.constprop.0+0x72a>
    a623:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a628:	48 89 dd             	mov    %rbx,%rbp
    a62b:	48 85 d2             	test   %rdx,%rdx
    a62e:	48 0f 44 d5          	cmove  %rbp,%rdx
    a632:	eb 21                	jmp    a655 <fwp_hof0.constprop.0+0x1335>
    a634:	90                   	nop
    a635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a63c:	00 00 00 00 
    a640:	48 8d 0c 12          	lea    (%rdx,%rdx,1),%rcx
    a644:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
    a64b:	48 89 e8             	mov    %rbp,%rax
    a64e:	48 0f 4c c1          	cmovl  %rcx,%rax
    a652:	48 89 c2             	mov    %rax,%rdx
    a655:	48 39 ea             	cmp    %rbp,%rdx
    a658:	7c e6                	jl     a640 <fwp_hof0.constprop.0+0x1320>
    a65a:	4d 85 e4             	test   %r12,%r12
    a65d:	0f 84 dd 01 00 00    	je     a840 <fwp_hof0.constprop.0+0x1520>
    a663:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
    a66a:	00 
    a66b:	4c 89 e7             	mov    %r12,%rdi
    a66e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    a673:	e8 58 8f ff ff       	call   35d0 <realloc@plt>
    a678:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    a67d:	49 89 c4             	mov    %rax,%r12
    a680:	4d 85 e4             	test   %r12,%r12
    a683:	0f 84 63 04 00 00    	je     aaec <fwp_hof0.constprop.0+0x17cc>
    a689:	4c 89 a4 24 e0 00 00 	mov    %r12,0xe0(%rsp)
    a690:	00 
    a691:	48 89 94 24 f0 00 00 	mov    %rdx,0xf0(%rsp)
    a698:	00 
    a699:	48 85 ed             	test   %rbp,%rbp
    a69c:	0f 85 56 03 00 00    	jne    a9f8 <fwp_hof0.constprop.0+0x16d8>
    a6a2:	49 89 db             	mov    %rbx,%r11
    a6a5:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    a6ac:	49 f7 db             	neg    %r11
    a6af:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    a6b4:	48 85 c0             	test   %rax,%rax
    a6b7:	0f 88 9f f3 ff ff    	js     9a5c <fwp_hof0.constprop.0+0x73c>
    a6bd:	41 89 c2             	mov    %eax,%r10d
    a6c0:	e9 85 f3 ff ff       	jmp    9a4a <fwp_hof0.constprop.0+0x72a>
    a6c5:	0f 1f 00             	nopl   (%rax)
    a6c8:	48 8d 3d b1 c4 ff ff 	lea    -0x3b4f(%rip),%rdi        # 6b80 <fwp_tape_finish>
    a6cf:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    a6d5:	e8 46 3b 00 00       	call   e220 <atexit>
    a6da:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    a6e0:	85 c0                	test   %eax,%eax
    a6e2:	0f 85 ab 04 00 00    	jne    ab93 <fwp_hof0.constprop.0+0x1873>
    a6e8:	c7 05 8a 89 00 00 01 	movl   $0x1,0x898a(%rip)        # 1307c <registered_finish.5>
    a6ef:	00 00 00 
    a6f2:	e9 1d ee ff ff       	jmp    9514 <fwp_hof0.constprop.0+0x1f4>
    a6f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a6fe:	00 00 
    a700:	66 85 c0             	test   %ax,%ax
    a703:	0f 85 a7 f9 ff ff    	jne    a0b0 <fwp_hof0.constprop.0+0xd90>
    a709:	e9 7a f9 ff ff       	jmp    a088 <fwp_hof0.constprop.0+0xd68>
    a70e:	66 90                	xchg   %ax,%ax
    a710:	66 85 c0             	test   %ax,%ax
    a713:	0f 85 a8 ed ff ff    	jne    94c1 <fwp_hof0.constprop.0+0x1a1>
    a719:	e9 8f ed ff ff       	jmp    94ad <fwp_hof0.constprop.0+0x18d>
    a71e:	66 90                	xchg   %ax,%ax
    a720:	48 39 d3             	cmp    %rdx,%rbx
    a723:	0f 8f ff fe ff ff    	jg     a628 <fwp_hof0.constprop.0+0x1308>
    a729:	48 85 db             	test   %rbx,%rbx
    a72c:	74 12                	je     a740 <fwp_hof0.constprop.0+0x1420>
    a72e:	4d 85 e4             	test   %r12,%r12
    a731:	0f 84 be 03 00 00    	je     aaf5 <fwp_hof0.constprop.0+0x17d5>
    a737:	48 85 db             	test   %rbx,%rbx
    a73a:	0f 85 b5 02 00 00    	jne    a9f5 <fwp_hof0.constprop.0+0x16d5>
    a740:	45 31 db             	xor    %r11d,%r11d
    a743:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    a74a:	e9 0d f3 ff ff       	jmp    9a5c <fwp_hof0.constprop.0+0x73c>
    a74f:	90                   	nop
    a750:	66 85 c0             	test   %ax,%ax
    a753:	0f 85 97 f4 ff ff    	jne    9bf0 <fwp_hof0.constprop.0+0x8d0>
    a759:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    a75d:	0f 85 89 f4 ff ff    	jne    9bec <fwp_hof0.constprop.0+0x8cc>
    a763:	48 89 ef             	mov    %rbp,%rdi
    a766:	e8 45 ae ff ff       	call   55b0 <fwp_rc_forget_slot>
    a76b:	e9 7c f4 ff ff       	jmp    9bec <fwp_hof0.constprop.0+0x8cc>
    a770:	4c 8b 34 24          	mov    (%rsp),%r14
    a774:	48 89 04 24          	mov    %rax,(%rsp)
    a778:	e9 95 f8 ff ff       	jmp    a012 <fwp_hof0.constprop.0+0xcf2>
    a77d:	0f 1f 00             	nopl   (%rax)
    a780:	48 8b 04 24          	mov    (%rsp),%rax
    a784:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    a78b:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a792:	48 8b 58 10          	mov    0x10(%rax),%rbx
    a796:	48 29 c8             	sub    %rcx,%rax
    a799:	48 c1 e2 10          	shl    $0x10,%rdx
    a79d:	48 39 d0             	cmp    %rdx,%rax
    a7a0:	73 66                	jae    a808 <fwp_hof0.constprop.0+0x14e8>
    a7a2:	48 89 c7             	mov    %rax,%rdi
    a7a5:	48 c1 ef 10          	shr    $0x10,%rdi
    a7a9:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    a7ad:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a7b1:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a7b5:	48 85 ff             	test   %rdi,%rdi
    a7b8:	74 4e                	je     a808 <fwp_hof0.constprop.0+0x14e8>
    a7ba:	44 0f b6 06          	movzbl (%rsi),%r8d
    a7be:	41 80 f8 02          	cmp    $0x2,%r8b
    a7c2:	0f 84 74 01 00 00    	je     a93c <fwp_hof0.constprop.0+0x161c>
    a7c8:	41 80 f8 01          	cmp    $0x1,%r8b
    a7cc:	75 3a                	jne    a808 <fwp_hof0.constprop.0+0x14e8>
    a7ce:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a7d2:	0f b7 c0             	movzwl %ax,%eax
    a7d5:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a7d8:	49 0f af c0          	imul   %r8,%rax
    a7dc:	48 c1 e8 20          	shr    $0x20,%rax
    a7e0:	48 39 f0             	cmp    %rsi,%rax
    a7e3:	73 23                	jae    a808 <fwp_hof0.constprop.0+0x14e8>
    a7e5:	48 01 c7             	add    %rax,%rdi
    a7e8:	80 3f 01             	cmpb   $0x1,(%rdi)
    a7eb:	75 1b                	jne    a808 <fwp_hof0.constprop.0+0x14e8>
    a7ed:	48 8b 3c 24          	mov    (%rsp),%rdi
    a7f1:	e8 fa af ff ff       	call   57f0 <fwp_mem_free>
    a7f6:	49 8b 95 d8 13 00 00 	mov    0x13d8(%r13),%rdx
    a7fd:	49 8b 8d b0 13 00 00 	mov    0x13b0(%r13),%rcx
    a804:	48 c1 e2 10          	shl    $0x10,%rdx
    a808:	48 89 d8             	mov    %rbx,%rax
    a80b:	48 29 c8             	sub    %rcx,%rax
    a80e:	48 39 d0             	cmp    %rdx,%rax
    a811:	0f 83 99 f8 ff ff    	jae    a0b0 <fwp_hof0.constprop.0+0xd90>
    a817:	48 89 1c 24          	mov    %rbx,(%rsp)
    a81b:	e9 1f f8 ff ff       	jmp    a03f <fwp_hof0.constprop.0+0xd1f>
    a820:	66 85 c0             	test   %ax,%ax
    a823:	0f 85 75 fc ff ff    	jne    a49e <fwp_hof0.constprop.0+0x117e>
    a829:	80 3b ff             	cmpb   $0xff,(%rbx)
    a82c:	0f 85 69 fc ff ff    	jne    a49b <fwp_hof0.constprop.0+0x117b>
    a832:	48 89 df             	mov    %rbx,%rdi
    a835:	e8 76 ad ff ff       	call   55b0 <fwp_rc_forget_slot>
    a83a:	e9 5c fc ff ff       	jmp    a49b <fwp_hof0.constprop.0+0x117b>
    a83f:	90                   	nop
    a840:	48 89 d7             	mov    %rdx,%rdi
    a843:	be 08 00 00 00       	mov    $0x8,%esi
    a848:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    a84d:	e8 ce 8c ff ff       	call   3520 <calloc@plt>
    a852:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    a857:	49 89 c4             	mov    %rax,%r12
    a85a:	e9 21 fe ff ff       	jmp    a680 <fwp_hof0.constprop.0+0x1360>
    a85f:	90                   	nop
    a860:	66 85 c0             	test   %ax,%ax
    a863:	0f 85 70 eb ff ff    	jne    93d9 <fwp_hof0.constprop.0+0xb9>
    a869:	e9 57 eb ff ff       	jmp    93c5 <fwp_hof0.constprop.0+0xa5>
    a86e:	66 90                	xchg   %ax,%ax
    a870:	66 85 c0             	test   %ax,%ax
    a873:	0f 85 4e f9 ff ff    	jne    a1c7 <fwp_hof0.constprop.0+0xea7>
    a879:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a87d:	0f 85 40 f9 ff ff    	jne    a1c3 <fwp_hof0.constprop.0+0xea3>
    a883:	4c 89 ff             	mov    %r15,%rdi
    a886:	e8 25 ad ff ff       	call   55b0 <fwp_rc_forget_slot>
    a88b:	e9 33 f9 ff ff       	jmp    a1c3 <fwp_hof0.constprop.0+0xea3>
    a890:	66 85 c0             	test   %ax,%ax
    a893:	0f 85 e7 f9 ff ff    	jne    a280 <fwp_hof0.constprop.0+0xf60>
    a899:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    a89d:	84 c0                	test   %al,%al
    a89f:	0f 84 db f9 ff ff    	je     a280 <fwp_hof0.constprop.0+0xf60>
    a8a5:	3c 01                	cmp    $0x1,%al
    a8a7:	0f 85 bd f9 ff ff    	jne    a26a <fwp_hof0.constprop.0+0xf4a>
    a8ad:	48 89 df             	mov    %rbx,%rdi
    a8b0:	e8 3b af ff ff       	call   57f0 <fwp_mem_free>
    a8b5:	e9 c6 f9 ff ff       	jmp    a280 <fwp_hof0.constprop.0+0xf60>
    a8ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a8c0:	be 68 00 00 00       	mov    $0x68,%esi
    a8c5:	bd 01 00 00 00       	mov    $0x1,%ebp
    a8ca:	e9 cb ec ff ff       	jmp    959a <fwp_hof0.constprop.0+0x27a>
    a8cf:	31 ff                	xor    %edi,%edi
    a8d1:	e8 7a 99 ff ff       	call   4250 <descent_phase_step>
    a8d6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a8da:	e9 27 ec ff ff       	jmp    9506 <fwp_hof0.constprop.0+0x1e6>
    a8df:	48 8b 45 00          	mov    0x0(%rbp),%rax
    a8e3:	48 85 c0             	test   %rax,%rax
    a8e6:	0f 88 77 fc ff ff    	js     a563 <fwp_hof0.constprop.0+0x1243>
    a8ec:	49 8b b5 d8 13 00 00 	mov    0x13d8(%r13),%rsi
    a8f3:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a8f8:	49 2b 8d b0 13 00 00 	sub    0x13b0(%r13),%rcx
    a8ff:	48 c1 e6 10          	shl    $0x10,%rsi
    a903:	48 39 f1             	cmp    %rsi,%rcx
    a906:	0f 83 57 fc ff ff    	jae    a563 <fwp_hof0.constprop.0+0x1243>
    a90c:	48 89 ce             	mov    %rcx,%rsi
    a90f:	48 c1 ee 10          	shr    $0x10,%rsi
    a913:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a917:	49 8b b5 f8 13 00 00 	mov    0x13f8(%r13),%rsi
    a91e:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a922:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a926:	48 85 ff             	test   %rdi,%rdi
    a929:	0f 84 34 fc ff ff    	je     a563 <fwp_hof0.constprop.0+0x1243>
    a92f:	48 0f ba f0 3f       	btr    $0x3f,%rax
    a934:	49 89 c7             	mov    %rax,%r15
    a937:	e9 49 f4 ff ff       	jmp    9d85 <fwp_hof0.constprop.0+0xa65>
    a93c:	66 85 c0             	test   %ax,%ax
    a93f:	0f 85 c3 fe ff ff    	jne    a808 <fwp_hof0.constprop.0+0x14e8>
    a945:	e9 9e fe ff ff       	jmp    a7e8 <fwp_hof0.constprop.0+0x14c8>
    a94a:	48 89 ea             	mov    %rbp,%rdx
    a94d:	48 c1 ea 11          	shr    $0x11,%rdx
    a951:	48 31 ea             	xor    %rbp,%rdx
    a954:	48 89 d0             	mov    %rdx,%rax
    a957:	48 c1 e8 09          	shr    $0x9,%rax
    a95b:	48 31 c2             	xor    %rax,%rdx
    a95e:	0f b6 d2             	movzbl %dl,%edx
    a961:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    a968:	00 
    a969:	48 85 c0             	test   %rax,%rax
    a96c:	75 1b                	jne    a989 <fwp_hof0.constprop.0+0x1669>
    a96e:	eb 79                	jmp    a9e9 <fwp_hof0.constprop.0+0x16c9>
    a970:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a975:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a97c:	00 00 00 00 
    a980:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a984:	48 85 c0             	test   %rax,%rax
    a987:	74 60                	je     a9e9 <fwp_hof0.constprop.0+0x16c9>
    a989:	48 89 c2             	mov    %rax,%rdx
    a98c:	48 39 28             	cmp    %rbp,(%rax)
    a98f:	75 ef                	jne    a980 <fwp_hof0.constprop.0+0x1660>
    a991:	48 8b 58 08          	mov    0x8(%rax),%rbx
    a995:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
    a999:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a99d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    a9a4:	0f 85 06 f7 ff ff    	jne    a0b0 <fwp_hof0.constprop.0+0xd90>
    a9aa:	48 89 ef             	mov    %rbp,%rdi
    a9ad:	e8 fe ab ff ff       	call   55b0 <fwp_rc_forget_slot>
    a9b2:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    a9b6:	e9 f5 f6 ff ff       	jmp    a0b0 <fwp_hof0.constprop.0+0xd90>
    a9bb:	e8 d0 aa ff ff       	call   5490 <fwp_rc_wide_dup>
    a9c0:	e9 fc ea ff ff       	jmp    94c1 <fwp_hof0.constprop.0+0x1a1>
    a9c5:	48 89 e8             	mov    %rbp,%rax
    a9c8:	48 c1 e8 11          	shr    $0x11,%rax
    a9cc:	48 31 e8             	xor    %rbp,%rax
    a9cf:	48 89 c2             	mov    %rax,%rdx
    a9d2:	48 c1 ea 09          	shr    $0x9,%rdx
    a9d6:	48 31 d0             	xor    %rdx,%rax
    a9d9:	0f b6 d0             	movzbl %al,%edx
    a9dc:	49 8b 84 d5 48 14 00 	mov    0x1448(%r13,%rdx,8),%rax
    a9e3:	00 
    a9e4:	48 85 c0             	test   %rax,%rax
    a9e7:	75 60                	jne    aa49 <fwp_hof0.constprop.0+0x1729>
    a9e9:	48 8d 3d a0 4e 00 00 	lea    0x4ea0(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    a9f0:	e8 fb 99 ff ff       	call   43f0 <fwp_trap>
    a9f5:	48 89 dd             	mov    %rbx,%rbp
    a9f8:	49 89 eb             	mov    %rbp,%r11
    a9fb:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    aa02:	00 
    aa03:	31 f6                	xor    %esi,%esi
    aa05:	4c 89 e7             	mov    %r12,%rdi
    aa08:	49 29 db             	sub    %rbx,%r11
    aa0b:	4c 8d 7d ff          	lea    -0x1(%rbp),%r15
    aa0f:	4c 89 5c 24 08       	mov    %r11,0x8(%rsp)
    aa14:	e8 a7 8a ff ff       	call   34c0 <memset@plt>
    aa19:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    aa1e:	e9 8c fc ff ff       	jmp    a6af <fwp_hof0.constprop.0+0x138f>
    aa23:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aa31:	00 00 00 00 
    aa35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aa3c:	00 00 00 00 
    aa40:	48 8b 42 10          	mov    0x10(%rdx),%rax
    aa44:	48 85 c0             	test   %rax,%rax
    aa47:	74 a0                	je     a9e9 <fwp_hof0.constprop.0+0x16c9>
    aa49:	48 89 c2             	mov    %rax,%rdx
    aa4c:	48 3b 28             	cmp    (%rax),%rbp
    aa4f:	75 ef                	jne    aa40 <fwp_hof0.constprop.0+0x1720>
    aa51:	48 8b 58 08          	mov    0x8(%rax),%rbx
    aa55:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
    aa59:	48 89 50 08          	mov    %rdx,0x8(%rax)
    aa5d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    aa64:	0f 85 16 f8 ff ff    	jne    a280 <fwp_hof0.constprop.0+0xf60>
    aa6a:	48 89 ef             	mov    %rbp,%rdi
    aa6d:	e8 3e ab ff ff       	call   55b0 <fwp_rc_forget_slot>
    aa72:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    aa76:	e9 05 f8 ff ff       	jmp    a280 <fwp_hof0.constprop.0+0xf60>
    aa7b:	e8 10 aa ff ff       	call   5490 <fwp_rc_wide_dup>
    aa80:	e9 54 e9 ff ff       	jmp    93d9 <fwp_hof0.constprop.0+0xb9>
    aa85:	45 31 ff             	xor    %r15d,%r15d
    aa88:	e9 48 f4 ff ff       	jmp    9ed5 <fwp_hof0.constprop.0+0xbb5>
    aa8d:	48 8d 3d 24 4e 00 00 	lea    0x4e24(%rip),%rdi        # f8b8 <_IO_stdin_used+0x8b8>
    aa94:	e8 57 99 ff ff       	call   43f0 <fwp_trap>
    aa99:	48 8d 3d c7 46 00 00 	lea    0x46c7(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    aaa0:	e8 4b 99 ff ff       	call   43f0 <fwp_trap>
    aaa5:	48 8d 3d e4 4e 00 00 	lea    0x4ee4(%rip),%rdi        # f990 <_IO_stdin_used+0x990>
    aaac:	e8 3f 99 ff ff       	call   43f0 <fwp_trap>
    aab1:	45 31 e4             	xor    %r12d,%r12d
    aab4:	e9 bc fa ff ff       	jmp    a575 <fwp_hof0.constprop.0+0x1255>
    aab9:	48 8d 3d 5c 47 00 00 	lea    0x475c(%rip),%rdi        # f21c <_IO_stdin_used+0x21c>
    aac0:	e8 2b 99 ff ff       	call   43f0 <fwp_trap>
    aac5:	48 8d 3d 6a 47 00 00 	lea    0x476a(%rip),%rdi        # f236 <_IO_stdin_used+0x236>
    aacc:	e8 1f 99 ff ff       	call   43f0 <fwp_trap>
    aad1:	48 8d 3d b8 46 00 00 	lea    0x46b8(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    aad8:	e8 13 99 ff ff       	call   43f0 <fwp_trap>
    aadd:	0f 1f 00             	nopl   (%rax)
    aae0:	48 8d 3d d1 4e 00 00 	lea    0x4ed1(%rip),%rdi        # f9b8 <_IO_stdin_used+0x9b8>
    aae7:	e8 04 99 ff ff       	call   43f0 <fwp_trap>
    aaec:	48 85 ed             	test   %rbp,%rbp
    aaef:	0f 84 ad fb ff ff    	je     a6a2 <fwp_hof0.constprop.0+0x1382>
    aaf5:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    aafc:	00 
    aafd:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    ab02:	48 89 05 6f a9 01 00 	mov    %rax,0x1a96f(%rip)        # 25478 <fwp_cleanups>
    ab09:	e8 c2 a5 ff ff       	call   50d0 <fwp_tape_buffers_release>
    ab0e:	ba 13 00 00 00       	mov    $0x13,%edx
    ab13:	48 8b 0d 26 85 00 00 	mov    0x8526(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    ab1a:	be 01 00 00 00       	mov    $0x1,%esi
    ab1f:	48 8d 3d e2 44 00 00 	lea    0x44e2(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    ab26:	e8 55 8b ff ff       	call   3680 <fwrite@plt>
    ab2b:	31 ff                	xor    %edi,%edi
    ab2d:	e8 8e 8a ff ff       	call   35c0 <fflush@plt>
    ab32:	bf 66 00 00 00       	mov    $0x66,%edi
    ab37:	e8 64 8b ff ff       	call   36a0 <_Exit@plt>
    ab3c:	48 8d 3d 1d 4e 00 00 	lea    0x4e1d(%rip),%rdi        # f960 <_IO_stdin_used+0x960>
    ab43:	e8 a8 98 ff ff       	call   43f0 <fwp_trap>
    ab48:	48 8b 0d f1 84 00 00 	mov    0x84f1(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    ab4f:	ba 13 00 00 00       	mov    $0x13,%edx
    ab54:	be 01 00 00 00       	mov    $0x1,%esi
    ab59:	48 8d 3d a8 44 00 00 	lea    0x44a8(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    ab60:	e8 1b 8b ff ff       	call   3680 <fwrite@plt>
    ab65:	31 ff                	xor    %edi,%edi
    ab67:	e8 54 8a ff ff       	call   35c0 <fflush@plt>
    ab6c:	bf 66 00 00 00       	mov    $0x66,%edi
    ab71:	e8 2a 8b ff ff       	call   36a0 <_Exit@plt>
    ab76:	48 8d 3d 83 4d 00 00 	lea    0x4d83(%rip),%rdi        # f900 <_IO_stdin_used+0x900>
    ab7d:	e8 6e 98 ff ff       	call   43f0 <fwp_trap>
    ab82:	e8 d9 88 ff ff       	call   3460 <__stack_chk_fail@plt>
    ab87:	48 8d 3d b8 46 00 00 	lea    0x46b8(%rip),%rdi        # f246 <_IO_stdin_used+0x246>
    ab8e:	e8 5d 98 ff ff       	call   43f0 <fwp_trap>
    ab93:	48 8b 0d a6 84 00 00 	mov    0x84a6(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    ab9a:	ba 13 00 00 00       	mov    $0x13,%edx
    ab9f:	be 01 00 00 00       	mov    $0x1,%esi
    aba4:	48 8d 3d 5d 44 00 00 	lea    0x445d(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    abab:	e8 d0 8a ff ff       	call   3680 <fwrite@plt>
    abb0:	31 ff                	xor    %edi,%edi
    abb2:	e8 09 8a ff ff       	call   35c0 <fflush@plt>
    abb7:	bf 66 00 00 00       	mov    $0x66,%edi
    abbc:	e8 df 8a ff ff       	call   36a0 <_Exit@plt>
    abc1:	0f 1f 40 00          	nopl   0x0(%rax)
    abc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    abcc:	00 00 00 00 

000000000000abd0 <f0>:
    abd0:	41 56                	push   %r14
    abd2:	4c 8d 35 07 8c 01 00 	lea    0x18c07(%rip),%r14        # 237e0 <fwp_heap>
    abd9:	41 55                	push   %r13
    abdb:	41 54                	push   %r12
    abdd:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    abe3:	55                   	push   %rbp
    abe4:	53                   	push   %rbx
    abe5:	31 db                	xor    %ebx,%ebx
    abe7:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    abee:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    abf5:	00 00 
    abf7:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    abfe:	00 
    abff:	31 c0                	xor    %eax,%eax
    ac01:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    ac08:	00 
    ac09:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    ac10:	00 00 
    ac12:	66 48 0f 6e c0       	movq   %rax,%xmm0
    ac17:	48 8d 05 72 cd ff ff 	lea    -0x328e(%rip),%rax        # 7990 <fwp_drop1>
    ac1e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    ac23:	48 8b 05 4e a8 01 00 	mov    0x1a84e(%rip),%rax        # 25478 <fwp_cleanups>
    ac2a:	48 89 25 47 a8 01 00 	mov    %rsp,0x1a847(%rip)        # 25478 <fwp_cleanups>
    ac31:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    ac35:	48 89 04 24          	mov    %rax,(%rsp)
    ac39:	48 8d 05 90 8f ff ff 	lea    -0x7070(%rip),%rax        # 3bd0 <fwp_range_release>
    ac40:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ac45:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    ac4a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    ac4f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    ac54:	eb 47                	jmp    ac9d <f0+0xcd>
    ac56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ac5d:	00 00 00 
    ac60:	80 f9 01             	cmp    $0x1,%cl
    ac63:	75 29                	jne    ac8e <f0+0xbe>
    ac65:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ac68:	0f b7 c0             	movzwl %ax,%eax
    ac6b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ac6e:	48 0f af c1          	imul   %rcx,%rax
    ac72:	48 c1 e8 20          	shr    $0x20,%rax
    ac76:	48 39 d0             	cmp    %rdx,%rax
    ac79:	73 13                	jae    ac8e <f0+0xbe>
    ac7b:	49 01 c5             	add    %rax,%r13
    ac7e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    ac83:	0f 84 c7 27 00 00    	je     d450 <f0+0x2880>
    ac89:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    ac8e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    ac93:	49 83 ec 01          	sub    $0x1,%r12
    ac97:	0f 82 83 00 00 00    	jb     ad20 <f0+0x150>
    ac9d:	48 89 ee             	mov    %rbp,%rsi
    aca0:	bf 01 00 00 00       	mov    $0x1,%edi
    aca5:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    acac:	00 
    acad:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    acb2:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    acb9:	00 
    acba:	e8 51 b1 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    acbf:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    acc6:	48 89 c3             	mov    %rax,%rbx
    acc9:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    acd0:	48 c1 e2 10          	shl    $0x10,%rdx
    acd4:	48 39 d0             	cmp    %rdx,%rax
    acd7:	73 b5                	jae    ac8e <f0+0xbe>
    acd9:	48 89 c2             	mov    %rax,%rdx
    acdc:	48 c1 ea 10          	shr    $0x10,%rdx
    ace0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ace4:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    aceb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    acef:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    acf3:	4d 85 ed             	test   %r13,%r13
    acf6:	74 96                	je     ac8e <f0+0xbe>
    acf8:	0f b6 0a             	movzbl (%rdx),%ecx
    acfb:	80 f9 02             	cmp    $0x2,%cl
    acfe:	0f 85 5c ff ff ff    	jne    ac60 <f0+0x90>
    ad04:	66 85 c0             	test   %ax,%ax
    ad07:	0f 84 71 ff ff ff    	je     ac7e <f0+0xae>
    ad0d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    ad12:	49 83 ec 01          	sub    $0x1,%r12
    ad16:	73 85                	jae    ac9d <f0+0xcd>
    ad18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ad1f:	00 
    ad20:	48 8b 04 24          	mov    (%rsp),%rax
    ad24:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    ad29:	bf 01 00 00 00       	mov    $0x1,%edi
    ad2e:	66 0f 6f 05 1a 4f 00 	movdqa 0x4f1a(%rip),%xmm0        # fc50 <msg.8+0xe0>
    ad35:	00 
    ad36:	48 89 05 3b a7 01 00 	mov    %rax,0x1a73b(%rip)        # 25478 <fwp_cleanups>
    ad3d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    ad42:	e8 c9 b0 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    ad47:	48 8b 15 6a 9e 01 00 	mov    0x19e6a(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    ad4e:	49 89 c5             	mov    %rax,%r13
    ad51:	48 2b 05 38 9e 01 00 	sub    0x19e38(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ad58:	48 c1 e2 10          	shl    $0x10,%rdx
    ad5c:	48 39 d0             	cmp    %rdx,%rax
    ad5f:	73 59                	jae    adba <f0+0x1ea>
    ad61:	48 89 c2             	mov    %rax,%rdx
    ad64:	48 c1 ea 10          	shr    $0x10,%rdx
    ad68:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ad6c:	48 8b 15 65 9e 01 00 	mov    0x19e65(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    ad73:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ad77:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ad7b:	4d 85 e4             	test   %r12,%r12
    ad7e:	74 3a                	je     adba <f0+0x1ea>
    ad80:	0f b6 0a             	movzbl (%rdx),%ecx
    ad83:	80 f9 02             	cmp    $0x2,%cl
    ad86:	0f 84 74 27 00 00    	je     d500 <f0+0x2930>
    ad8c:	80 f9 01             	cmp    $0x1,%cl
    ad8f:	75 29                	jne    adba <f0+0x1ea>
    ad91:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ad94:	0f b7 c0             	movzwl %ax,%eax
    ad97:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ad9a:	48 0f af c1          	imul   %rcx,%rax
    ad9e:	48 c1 e8 20          	shr    $0x20,%rax
    ada2:	48 39 d0             	cmp    %rdx,%rax
    ada5:	73 13                	jae    adba <f0+0x1ea>
    ada7:	49 01 c4             	add    %rax,%r12
    adaa:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    adaf:	0f 84 26 29 00 00    	je     d6db <f0+0x2b0b>
    adb5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    adba:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    adbf:	bf 01 00 00 00       	mov    $0x1,%edi
    adc4:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    adc9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    add0:	00 f0 3f 
    add3:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    add8:	e8 33 b0 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    addd:	48 8b 15 d4 9d 01 00 	mov    0x19dd4(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    ade4:	49 89 c5             	mov    %rax,%r13
    ade7:	48 2b 05 a2 9d 01 00 	sub    0x19da2(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    adee:	48 c1 e2 10          	shl    $0x10,%rdx
    adf2:	48 39 d0             	cmp    %rdx,%rax
    adf5:	73 59                	jae    ae50 <f0+0x280>
    adf7:	48 89 c2             	mov    %rax,%rdx
    adfa:	48 c1 ea 10          	shr    $0x10,%rdx
    adfe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ae02:	48 8b 15 cf 9d 01 00 	mov    0x19dcf(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    ae09:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ae0d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ae11:	4d 85 e4             	test   %r12,%r12
    ae14:	74 3a                	je     ae50 <f0+0x280>
    ae16:	0f b6 0a             	movzbl (%rdx),%ecx
    ae19:	80 f9 02             	cmp    $0x2,%cl
    ae1c:	0f 84 ce 26 00 00    	je     d4f0 <f0+0x2920>
    ae22:	80 f9 01             	cmp    $0x1,%cl
    ae25:	75 29                	jne    ae50 <f0+0x280>
    ae27:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ae2a:	0f b7 c0             	movzwl %ax,%eax
    ae2d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ae30:	48 0f af c1          	imul   %rcx,%rax
    ae34:	48 c1 e8 20          	shr    $0x20,%rax
    ae38:	48 39 d0             	cmp    %rdx,%rax
    ae3b:	73 13                	jae    ae50 <f0+0x280>
    ae3d:	49 01 c4             	add    %rax,%r12
    ae40:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ae45:	0f 84 9d 28 00 00    	je     d6e8 <f0+0x2b18>
    ae4b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ae50:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    ae55:	bf 01 00 00 00       	mov    $0x1,%edi
    ae5a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    ae5f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ae66:	33 f3 bf 
    ae69:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    ae6e:	e8 9d af ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    ae73:	48 8b 15 3e 9d 01 00 	mov    0x19d3e(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    ae7a:	49 89 c5             	mov    %rax,%r13
    ae7d:	48 2b 05 0c 9d 01 00 	sub    0x19d0c(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ae84:	48 c1 e2 10          	shl    $0x10,%rdx
    ae88:	48 39 d0             	cmp    %rdx,%rax
    ae8b:	73 59                	jae    aee6 <f0+0x316>
    ae8d:	48 89 c2             	mov    %rax,%rdx
    ae90:	48 c1 ea 10          	shr    $0x10,%rdx
    ae94:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ae98:	48 8b 15 39 9d 01 00 	mov    0x19d39(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    ae9f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aea3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    aea7:	4d 85 e4             	test   %r12,%r12
    aeaa:	74 3a                	je     aee6 <f0+0x316>
    aeac:	0f b6 0a             	movzbl (%rdx),%ecx
    aeaf:	80 f9 02             	cmp    $0x2,%cl
    aeb2:	0f 84 28 26 00 00    	je     d4e0 <f0+0x2910>
    aeb8:	80 f9 01             	cmp    $0x1,%cl
    aebb:	75 29                	jne    aee6 <f0+0x316>
    aebd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aec0:	0f b7 c0             	movzwl %ax,%eax
    aec3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aec6:	48 0f af c1          	imul   %rcx,%rax
    aeca:	48 c1 e8 20          	shr    $0x20,%rax
    aece:	48 39 d0             	cmp    %rdx,%rax
    aed1:	73 13                	jae    aee6 <f0+0x316>
    aed3:	49 01 c4             	add    %rax,%r12
    aed6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    aedb:	0f 84 14 28 00 00    	je     d6f5 <f0+0x2b25>
    aee1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    aee6:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    aeeb:	bf 01 00 00 00       	mov    $0x1,%edi
    aef0:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    aef5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    aefc:	00 f0 3f 
    aeff:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    af04:	e8 07 af ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    af09:	48 8b 15 a8 9c 01 00 	mov    0x19ca8(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    af10:	49 89 c5             	mov    %rax,%r13
    af13:	48 2b 05 76 9c 01 00 	sub    0x19c76(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    af1a:	48 c1 e2 10          	shl    $0x10,%rdx
    af1e:	48 39 d0             	cmp    %rdx,%rax
    af21:	73 59                	jae    af7c <f0+0x3ac>
    af23:	48 89 c2             	mov    %rax,%rdx
    af26:	48 c1 ea 10          	shr    $0x10,%rdx
    af2a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    af2e:	48 8b 15 a3 9c 01 00 	mov    0x19ca3(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    af35:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    af39:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    af3d:	4d 85 e4             	test   %r12,%r12
    af40:	74 3a                	je     af7c <f0+0x3ac>
    af42:	0f b6 0a             	movzbl (%rdx),%ecx
    af45:	80 f9 02             	cmp    $0x2,%cl
    af48:	0f 84 f2 25 00 00    	je     d540 <f0+0x2970>
    af4e:	80 f9 01             	cmp    $0x1,%cl
    af51:	75 29                	jne    af7c <f0+0x3ac>
    af53:	8b 4a 18             	mov    0x18(%rdx),%ecx
    af56:	0f b7 c0             	movzwl %ax,%eax
    af59:	8b 52 1c             	mov    0x1c(%rdx),%edx
    af5c:	48 0f af c1          	imul   %rcx,%rax
    af60:	48 c1 e8 20          	shr    $0x20,%rax
    af64:	48 39 d0             	cmp    %rdx,%rax
    af67:	73 13                	jae    af7c <f0+0x3ac>
    af69:	49 01 c4             	add    %rax,%r12
    af6c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    af71:	0f 84 8b 27 00 00    	je     d702 <f0+0x2b32>
    af77:	41 c6 04 24 01       	movb   $0x1,(%r12)
    af7c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    af83:	33 f3 bf 
    af86:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    af8d:	00 
    af8e:	bf 01 00 00 00       	mov    $0x1,%edi
    af93:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    af9a:	00 
    af9b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    afa2:	00 
    afa3:	e8 68 ae ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    afa8:	48 8b 15 09 9c 01 00 	mov    0x19c09(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    afaf:	49 89 c5             	mov    %rax,%r13
    afb2:	48 2b 05 d7 9b 01 00 	sub    0x19bd7(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    afb9:	48 c1 e2 10          	shl    $0x10,%rdx
    afbd:	48 39 d0             	cmp    %rdx,%rax
    afc0:	73 59                	jae    b01b <f0+0x44b>
    afc2:	48 89 c2             	mov    %rax,%rdx
    afc5:	48 c1 ea 10          	shr    $0x10,%rdx
    afc9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    afcd:	48 8b 15 04 9c 01 00 	mov    0x19c04(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    afd4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    afd8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    afdc:	4d 85 e4             	test   %r12,%r12
    afdf:	74 3a                	je     b01b <f0+0x44b>
    afe1:	0f b6 0a             	movzbl (%rdx),%ecx
    afe4:	80 f9 02             	cmp    $0x2,%cl
    afe7:	0f 84 43 25 00 00    	je     d530 <f0+0x2960>
    afed:	80 f9 01             	cmp    $0x1,%cl
    aff0:	75 29                	jne    b01b <f0+0x44b>
    aff2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aff5:	0f b7 c0             	movzwl %ax,%eax
    aff8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    affb:	48 0f af c1          	imul   %rcx,%rax
    afff:	48 c1 e8 20          	shr    $0x20,%rax
    b003:	48 39 d0             	cmp    %rdx,%rax
    b006:	73 13                	jae    b01b <f0+0x44b>
    b008:	49 01 c4             	add    %rax,%r12
    b00b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b010:	0f 84 f9 26 00 00    	je     d70f <f0+0x2b3f>
    b016:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b01b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    b022:	00 f0 3f 
    b025:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    b02c:	00 
    b02d:	bf 01 00 00 00       	mov    $0x1,%edi
    b032:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    b039:	00 
    b03a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    b041:	00 
    b042:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    b049:	33 f3 bf 
    b04c:	e8 bf ad ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b051:	48 89 c7             	mov    %rax,%rdi
    b054:	e8 07 b5 ff ff       	call   6560 <fwp_rc_fresh>
    b059:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    b060:	00 
    b061:	bf 01 00 00 00       	mov    $0x1,%edi
    b066:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    b06d:	00 
    b06e:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    b075:	00 
    b076:	e8 95 ad ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b07b:	48 89 c7             	mov    %rax,%rdi
    b07e:	e8 dd b4 ff ff       	call   6560 <fwp_rc_fresh>
    b083:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    b08a:	00 
    b08b:	bf 01 00 00 00       	mov    $0x1,%edi
    b090:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    b097:	00 
    b098:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    b09f:	00 
    b0a0:	e8 6b ad ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b0a5:	48 89 c7             	mov    %rax,%rdi
    b0a8:	e8 b3 b4 ff ff       	call   6560 <fwp_rc_fresh>
    b0ad:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    b0b4:	00 
    b0b5:	bf 01 00 00 00       	mov    $0x1,%edi
    b0ba:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    b0c1:	00 
    b0c2:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    b0c9:	00 
    b0ca:	e8 41 ad ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b0cf:	48 89 c7             	mov    %rax,%rdi
    b0d2:	e8 89 b4 ff ff       	call   6560 <fwp_rc_fresh>
    b0d7:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    b0de:	00 
    b0df:	bf 01 00 00 00       	mov    $0x1,%edi
    b0e4:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    b0eb:	00 
    b0ec:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    b0f3:	00 
    b0f4:	e8 17 ad ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b0f9:	48 89 c7             	mov    %rax,%rdi
    b0fc:	e8 5f b4 ff ff       	call   6560 <fwp_rc_fresh>
    b101:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    b108:	00 
    b109:	bf 01 00 00 00       	mov    $0x1,%edi
    b10e:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    b115:	00 
    b116:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    b11d:	00 
    b11e:	e8 ed ac ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b123:	48 89 c7             	mov    %rax,%rdi
    b126:	e8 35 b4 ff ff       	call   6560 <fwp_rc_fresh>
    b12b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    b132:	00 
    b133:	bf 01 00 00 00       	mov    $0x1,%edi
    b138:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    b13f:	00 
    b140:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    b147:	00 
    b148:	e8 c3 ac ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b14d:	48 89 c7             	mov    %rax,%rdi
    b150:	e8 0b b4 ff ff       	call   6560 <fwp_rc_fresh>
    b155:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    b15c:	00 
    b15d:	bf 01 00 00 00       	mov    $0x1,%edi
    b162:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    b169:	00 
    b16a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    b171:	00 
    b172:	e8 99 ac ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b177:	48 89 c7             	mov    %rax,%rdi
    b17a:	e8 e1 b3 ff ff       	call   6560 <fwp_rc_fresh>
    b17f:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    b186:	00 
    b187:	bf 01 00 00 00       	mov    $0x1,%edi
    b18c:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    b193:	00 
    b194:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    b19b:	00 
    b19c:	e8 6f ac ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b1a1:	48 89 c7             	mov    %rax,%rdi
    b1a4:	e8 b7 b3 ff ff       	call   6560 <fwp_rc_fresh>
    b1a9:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    b1b0:	00 
    b1b1:	bf 01 00 00 00       	mov    $0x1,%edi
    b1b6:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    b1bd:	00 
    b1be:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    b1c5:	00 
    b1c6:	e8 45 ac ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b1cb:	48 89 c7             	mov    %rax,%rdi
    b1ce:	e8 8d b3 ff ff       	call   6560 <fwp_rc_fresh>
    b1d3:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    b1da:	00 
    b1db:	bf 01 00 00 00       	mov    $0x1,%edi
    b1e0:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    b1e7:	00 
    b1e8:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    b1ef:	00 
    b1f0:	e8 1b ac ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b1f5:	48 89 c7             	mov    %rax,%rdi
    b1f8:	e8 63 b3 ff ff       	call   6560 <fwp_rc_fresh>
    b1fd:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    b204:	00 
    b205:	bf 01 00 00 00       	mov    $0x1,%edi
    b20a:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    b211:	00 
    b212:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    b219:	00 
    b21a:	e8 f1 ab ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b21f:	48 89 c7             	mov    %rax,%rdi
    b222:	e8 39 b3 ff ff       	call   6560 <fwp_rc_fresh>
    b227:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    b22e:	00 
    b22f:	bf 01 00 00 00       	mov    $0x1,%edi
    b234:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    b23b:	00 
    b23c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    b243:	00 
    b244:	e8 c7 ab ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b249:	48 89 c7             	mov    %rax,%rdi
    b24c:	e8 0f b3 ff ff       	call   6560 <fwp_rc_fresh>
    b251:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    b258:	00 
    b259:	bf 01 00 00 00       	mov    $0x1,%edi
    b25e:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    b265:	00 
    b266:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    b26d:	00 
    b26e:	e8 9d ab ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b273:	48 89 c7             	mov    %rax,%rdi
    b276:	e8 e5 b2 ff ff       	call   6560 <fwp_rc_fresh>
    b27b:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    b282:	00 
    b283:	bf 01 00 00 00       	mov    $0x1,%edi
    b288:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    b28f:	00 
    b290:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    b297:	00 
    b298:	e8 73 ab ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b29d:	48 89 c7             	mov    %rax,%rdi
    b2a0:	e8 bb b2 ff ff       	call   6560 <fwp_rc_fresh>
    b2a5:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    b2ac:	00 
    b2ad:	bf 01 00 00 00       	mov    $0x1,%edi
    b2b2:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    b2b9:	00 
    b2ba:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    b2c1:	00 
    b2c2:	e8 49 ab ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b2c7:	48 89 c7             	mov    %rax,%rdi
    b2ca:	e8 91 b2 ff ff       	call   6560 <fwp_rc_fresh>
    b2cf:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    b2d6:	00 
    b2d7:	bf 01 00 00 00       	mov    $0x1,%edi
    b2dc:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    b2e3:	00 
    b2e4:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    b2eb:	00 
    b2ec:	e8 1f ab ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b2f1:	48 89 c7             	mov    %rax,%rdi
    b2f4:	e8 67 b2 ff ff       	call   6560 <fwp_rc_fresh>
    b2f9:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    b300:	00 
    b301:	bf 01 00 00 00       	mov    $0x1,%edi
    b306:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    b30d:	00 
    b30e:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    b315:	00 
    b316:	e8 f5 aa ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b31b:	48 89 c7             	mov    %rax,%rdi
    b31e:	e8 3d b2 ff ff       	call   6560 <fwp_rc_fresh>
    b323:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    b32a:	00 
    b32b:	bf 01 00 00 00       	mov    $0x1,%edi
    b330:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    b337:	00 
    b338:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    b33f:	00 
    b340:	e8 cb aa ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b345:	48 89 c7             	mov    %rax,%rdi
    b348:	e8 13 b2 ff ff       	call   6560 <fwp_rc_fresh>
    b34d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    b354:	00 
    b355:	bf 01 00 00 00       	mov    $0x1,%edi
    b35a:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    b361:	00 
    b362:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    b369:	00 
    b36a:	e8 a1 aa ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b36f:	48 89 c7             	mov    %rax,%rdi
    b372:	e8 e9 b1 ff ff       	call   6560 <fwp_rc_fresh>
    b377:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    b37e:	00 
    b37f:	bf 01 00 00 00       	mov    $0x1,%edi
    b384:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    b38b:	00 
    b38c:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    b393:	00 
    b394:	e8 77 aa ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b399:	48 89 c7             	mov    %rax,%rdi
    b39c:	e8 bf b1 ff ff       	call   6560 <fwp_rc_fresh>
    b3a1:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    b3a8:	00 
    b3a9:	bf 01 00 00 00       	mov    $0x1,%edi
    b3ae:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    b3b5:	00 
    b3b6:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    b3bd:	00 
    b3be:	e8 4d aa ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b3c3:	48 89 c7             	mov    %rax,%rdi
    b3c6:	e8 95 b1 ff ff       	call   6560 <fwp_rc_fresh>
    b3cb:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    b3d2:	00 
    b3d3:	bf 01 00 00 00       	mov    $0x1,%edi
    b3d8:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    b3df:	00 
    b3e0:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    b3e7:	00 
    b3e8:	e8 23 aa ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b3ed:	48 89 c7             	mov    %rax,%rdi
    b3f0:	e8 6b b1 ff ff       	call   6560 <fwp_rc_fresh>
    b3f5:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    b3fc:	00 
    b3fd:	bf 01 00 00 00       	mov    $0x1,%edi
    b402:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    b409:	00 
    b40a:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    b411:	00 
    b412:	e8 f9 a9 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b417:	48 89 c7             	mov    %rax,%rdi
    b41a:	e8 41 b1 ff ff       	call   6560 <fwp_rc_fresh>
    b41f:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    b426:	00 
    b427:	bf 01 00 00 00       	mov    $0x1,%edi
    b42c:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    b433:	00 
    b434:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    b43b:	00 
    b43c:	e8 cf a9 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b441:	48 89 c7             	mov    %rax,%rdi
    b444:	e8 17 b1 ff ff       	call   6560 <fwp_rc_fresh>
    b449:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    b450:	00 
    b451:	bf 01 00 00 00       	mov    $0x1,%edi
    b456:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    b45d:	00 
    b45e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    b465:	00 
    b466:	e8 a5 a9 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b46b:	48 89 c7             	mov    %rax,%rdi
    b46e:	e8 ed b0 ff ff       	call   6560 <fwp_rc_fresh>
    b473:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    b47a:	00 
    b47b:	bf 01 00 00 00       	mov    $0x1,%edi
    b480:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    b487:	00 
    b488:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    b48f:	00 
    b490:	e8 7b a9 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b495:	48 89 c7             	mov    %rax,%rdi
    b498:	e8 c3 b0 ff ff       	call   6560 <fwp_rc_fresh>
    b49d:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    b4a4:	00 
    b4a5:	bf 01 00 00 00       	mov    $0x1,%edi
    b4aa:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    b4b1:	00 
    b4b2:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    b4b9:	00 
    b4ba:	e8 51 a9 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b4bf:	48 89 c7             	mov    %rax,%rdi
    b4c2:	e8 99 b0 ff ff       	call   6560 <fwp_rc_fresh>
    b4c7:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    b4ce:	00 
    b4cf:	bf 01 00 00 00       	mov    $0x1,%edi
    b4d4:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    b4db:	00 
    b4dc:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    b4e3:	00 
    b4e4:	e8 27 a9 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b4e9:	48 89 c7             	mov    %rax,%rdi
    b4ec:	e8 6f b0 ff ff       	call   6560 <fwp_rc_fresh>
    b4f1:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    b4f8:	00 
    b4f9:	bf 01 00 00 00       	mov    $0x1,%edi
    b4fe:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    b505:	00 
    b506:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    b50d:	00 
    b50e:	e8 fd a8 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b513:	48 89 c7             	mov    %rax,%rdi
    b516:	e8 45 b0 ff ff       	call   6560 <fwp_rc_fresh>
    b51b:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    b522:	00 
    b523:	bf 01 00 00 00       	mov    $0x1,%edi
    b528:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    b52f:	00 
    b530:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    b537:	00 
    b538:	e8 d3 a8 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b53d:	48 89 c7             	mov    %rax,%rdi
    b540:	e8 1b b0 ff ff       	call   6560 <fwp_rc_fresh>
    b545:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    b54c:	00 
    b54d:	bf 01 00 00 00       	mov    $0x1,%edi
    b552:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    b559:	00 
    b55a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    b561:	00 
    b562:	e8 a9 a8 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b567:	48 89 c7             	mov    %rax,%rdi
    b56a:	e8 f1 af ff ff       	call   6560 <fwp_rc_fresh>
    b56f:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    b576:	00 
    b577:	bf 01 00 00 00       	mov    $0x1,%edi
    b57c:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    b583:	00 
    b584:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    b58b:	00 
    b58c:	e8 7f a8 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b591:	48 89 c7             	mov    %rax,%rdi
    b594:	e8 c7 af ff ff       	call   6560 <fwp_rc_fresh>
    b599:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    b5a0:	00 
    b5a1:	bf 01 00 00 00       	mov    $0x1,%edi
    b5a6:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    b5ad:	00 
    b5ae:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    b5b5:	00 
    b5b6:	e8 55 a8 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b5bb:	48 89 c7             	mov    %rax,%rdi
    b5be:	e8 9d af ff ff       	call   6560 <fwp_rc_fresh>
    b5c3:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    b5ca:	00 
    b5cb:	bf 01 00 00 00       	mov    $0x1,%edi
    b5d0:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    b5d7:	00 
    b5d8:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    b5df:	00 
    b5e0:	e8 2b a8 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b5e5:	48 89 c7             	mov    %rax,%rdi
    b5e8:	e8 73 af ff ff       	call   6560 <fwp_rc_fresh>
    b5ed:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    b5f4:	00 
    b5f5:	bf 01 00 00 00       	mov    $0x1,%edi
    b5fa:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    b601:	00 
    b602:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    b609:	00 
    b60a:	e8 01 a8 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b60f:	48 89 c7             	mov    %rax,%rdi
    b612:	e8 49 af ff ff       	call   6560 <fwp_rc_fresh>
    b617:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    b61e:	00 
    b61f:	bf 01 00 00 00       	mov    $0x1,%edi
    b624:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    b62b:	00 
    b62c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    b633:	00 
    b634:	e8 d7 a7 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b639:	48 89 c7             	mov    %rax,%rdi
    b63c:	e8 1f af ff ff       	call   6560 <fwp_rc_fresh>
    b641:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    b648:	00 
    b649:	bf 01 00 00 00       	mov    $0x1,%edi
    b64e:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    b655:	00 
    b656:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    b65d:	00 
    b65e:	e8 ad a7 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b663:	48 89 c7             	mov    %rax,%rdi
    b666:	e8 f5 ae ff ff       	call   6560 <fwp_rc_fresh>
    b66b:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    b672:	00 
    b673:	bf 01 00 00 00       	mov    $0x1,%edi
    b678:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    b67f:	00 
    b680:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    b687:	00 
    b688:	e8 83 a7 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b68d:	48 89 c7             	mov    %rax,%rdi
    b690:	e8 cb ae ff ff       	call   6560 <fwp_rc_fresh>
    b695:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    b69c:	00 
    b69d:	bf 01 00 00 00       	mov    $0x1,%edi
    b6a2:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    b6a9:	00 
    b6aa:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    b6b1:	00 
    b6b2:	e8 59 a7 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b6b7:	48 89 c7             	mov    %rax,%rdi
    b6ba:	e8 a1 ae ff ff       	call   6560 <fwp_rc_fresh>
    b6bf:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    b6c6:	00 
    b6c7:	bf 01 00 00 00       	mov    $0x1,%edi
    b6cc:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    b6d3:	00 
    b6d4:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    b6db:	00 
    b6dc:	e8 2f a7 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b6e1:	48 89 c7             	mov    %rax,%rdi
    b6e4:	e8 77 ae ff ff       	call   6560 <fwp_rc_fresh>
    b6e9:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    b6f0:	00 
    b6f1:	bf 01 00 00 00       	mov    $0x1,%edi
    b6f6:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    b6fd:	00 
    b6fe:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    b705:	00 
    b706:	e8 05 a7 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b70b:	48 89 c7             	mov    %rax,%rdi
    b70e:	e8 4d ae ff ff       	call   6560 <fwp_rc_fresh>
    b713:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    b71a:	00 
    b71b:	bf 01 00 00 00       	mov    $0x1,%edi
    b720:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    b727:	00 
    b728:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    b72f:	00 
    b730:	e8 db a6 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b735:	48 89 c7             	mov    %rax,%rdi
    b738:	e8 23 ae ff ff       	call   6560 <fwp_rc_fresh>
    b73d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    b744:	00 
    b745:	bf 01 00 00 00       	mov    $0x1,%edi
    b74a:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    b751:	00 
    b752:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    b759:	00 
    b75a:	e8 b1 a6 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b75f:	48 89 c7             	mov    %rax,%rdi
    b762:	e8 f9 ad ff ff       	call   6560 <fwp_rc_fresh>
    b767:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    b76e:	00 
    b76f:	bf 01 00 00 00       	mov    $0x1,%edi
    b774:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    b77b:	00 
    b77c:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    b783:	00 
    b784:	e8 87 a6 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b789:	48 89 c7             	mov    %rax,%rdi
    b78c:	e8 cf ad ff ff       	call   6560 <fwp_rc_fresh>
    b791:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    b798:	00 
    b799:	bf 01 00 00 00       	mov    $0x1,%edi
    b79e:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    b7a5:	00 
    b7a6:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    b7ad:	00 
    b7ae:	e8 5d a6 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b7b3:	48 89 c7             	mov    %rax,%rdi
    b7b6:	e8 a5 ad ff ff       	call   6560 <fwp_rc_fresh>
    b7bb:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    b7c2:	00 
    b7c3:	bf 01 00 00 00       	mov    $0x1,%edi
    b7c8:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    b7cf:	00 
    b7d0:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    b7d7:	00 
    b7d8:	e8 33 a6 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b7dd:	48 89 c7             	mov    %rax,%rdi
    b7e0:	e8 7b ad ff ff       	call   6560 <fwp_rc_fresh>
    b7e5:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    b7ec:	00 
    b7ed:	bf 01 00 00 00       	mov    $0x1,%edi
    b7f2:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    b7f9:	00 
    b7fa:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    b801:	00 
    b802:	e8 09 a6 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b807:	48 89 c7             	mov    %rax,%rdi
    b80a:	e8 51 ad ff ff       	call   6560 <fwp_rc_fresh>
    b80f:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    b816:	00 
    b817:	bf 01 00 00 00       	mov    $0x1,%edi
    b81c:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    b823:	00 
    b824:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    b82b:	00 
    b82c:	e8 df a5 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b831:	48 89 c7             	mov    %rax,%rdi
    b834:	e8 27 ad ff ff       	call   6560 <fwp_rc_fresh>
    b839:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    b840:	00 
    b841:	bf 01 00 00 00       	mov    $0x1,%edi
    b846:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    b84d:	00 
    b84e:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    b855:	00 
    b856:	e8 b5 a5 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b85b:	48 89 c7             	mov    %rax,%rdi
    b85e:	e8 fd ac ff ff       	call   6560 <fwp_rc_fresh>
    b863:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    b86a:	00 
    b86b:	bf 01 00 00 00       	mov    $0x1,%edi
    b870:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    b877:	00 
    b878:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    b87f:	00 
    b880:	e8 8b a5 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b885:	48 89 c7             	mov    %rax,%rdi
    b888:	e8 d3 ac ff ff       	call   6560 <fwp_rc_fresh>
    b88d:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    b894:	00 
    b895:	bf 01 00 00 00       	mov    $0x1,%edi
    b89a:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    b8a1:	00 
    b8a2:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    b8a9:	00 
    b8aa:	e8 61 a5 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b8af:	48 89 c7             	mov    %rax,%rdi
    b8b2:	e8 a9 ac ff ff       	call   6560 <fwp_rc_fresh>
    b8b7:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    b8be:	00 
    b8bf:	bf 01 00 00 00       	mov    $0x1,%edi
    b8c4:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    b8cb:	00 
    b8cc:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    b8d3:	00 
    b8d4:	e8 37 a5 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b8d9:	48 89 c7             	mov    %rax,%rdi
    b8dc:	e8 7f ac ff ff       	call   6560 <fwp_rc_fresh>
    b8e1:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    b8e8:	00 
    b8e9:	bf 01 00 00 00       	mov    $0x1,%edi
    b8ee:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    b8f5:	00 
    b8f6:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    b8fd:	00 
    b8fe:	e8 0d a5 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b903:	48 89 c7             	mov    %rax,%rdi
    b906:	e8 55 ac ff ff       	call   6560 <fwp_rc_fresh>
    b90b:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    b912:	00 
    b913:	bf 01 00 00 00       	mov    $0x1,%edi
    b918:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    b91f:	00 
    b920:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    b927:	00 
    b928:	e8 e3 a4 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b92d:	48 89 c7             	mov    %rax,%rdi
    b930:	e8 2b ac ff ff       	call   6560 <fwp_rc_fresh>
    b935:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    b93c:	00 
    b93d:	bf 01 00 00 00       	mov    $0x1,%edi
    b942:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    b949:	00 
    b94a:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    b951:	00 
    b952:	e8 b9 a4 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b957:	48 89 c7             	mov    %rax,%rdi
    b95a:	e8 01 ac ff ff       	call   6560 <fwp_rc_fresh>
    b95f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    b966:	00 
    b967:	bf 01 00 00 00       	mov    $0x1,%edi
    b96c:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    b973:	00 
    b974:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    b97b:	00 
    b97c:	e8 8f a4 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b981:	48 89 c7             	mov    %rax,%rdi
    b984:	e8 d7 ab ff ff       	call   6560 <fwp_rc_fresh>
    b989:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    b990:	00 
    b991:	bf 01 00 00 00       	mov    $0x1,%edi
    b996:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    b99d:	00 
    b99e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    b9a5:	00 
    b9a6:	e8 65 a4 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b9ab:	48 89 c7             	mov    %rax,%rdi
    b9ae:	e8 ad ab ff ff       	call   6560 <fwp_rc_fresh>
    b9b3:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    b9ba:	00 
    b9bb:	bf 01 00 00 00       	mov    $0x1,%edi
    b9c0:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    b9c7:	00 
    b9c8:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    b9cf:	00 
    b9d0:	e8 3b a4 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b9d5:	48 89 c7             	mov    %rax,%rdi
    b9d8:	e8 83 ab ff ff       	call   6560 <fwp_rc_fresh>
    b9dd:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    b9e4:	00 
    b9e5:	bf 01 00 00 00       	mov    $0x1,%edi
    b9ea:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    b9f1:	00 
    b9f2:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    b9f9:	00 
    b9fa:	e8 11 a4 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    b9ff:	48 89 c7             	mov    %rax,%rdi
    ba02:	e8 59 ab ff ff       	call   6560 <fwp_rc_fresh>
    ba07:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    ba0e:	00 
    ba0f:	bf 01 00 00 00       	mov    $0x1,%edi
    ba14:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    ba1b:	00 
    ba1c:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    ba23:	00 
    ba24:	e8 e7 a3 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    ba29:	48 89 c7             	mov    %rax,%rdi
    ba2c:	e8 2f ab ff ff       	call   6560 <fwp_rc_fresh>
    ba31:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    ba38:	00 
    ba39:	bf 01 00 00 00       	mov    $0x1,%edi
    ba3e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    ba45:	00 
    ba46:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    ba4d:	00 
    ba4e:	e8 bd a3 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    ba53:	48 89 c7             	mov    %rax,%rdi
    ba56:	e8 05 ab ff ff       	call   6560 <fwp_rc_fresh>
    ba5b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    ba62:	00 
    ba63:	bf 01 00 00 00       	mov    $0x1,%edi
    ba68:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    ba6f:	00 
    ba70:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    ba77:	00 
    ba78:	e8 93 a3 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    ba7d:	48 89 c7             	mov    %rax,%rdi
    ba80:	e8 db aa ff ff       	call   6560 <fwp_rc_fresh>
    ba85:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    ba8c:	00 
    ba8d:	bf 01 00 00 00       	mov    $0x1,%edi
    ba92:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    ba99:	00 
    ba9a:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    baa1:	00 
    baa2:	e8 69 a3 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    baa7:	48 89 c7             	mov    %rax,%rdi
    baaa:	e8 b1 aa ff ff       	call   6560 <fwp_rc_fresh>
    baaf:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    bab6:	00 
    bab7:	bf 01 00 00 00       	mov    $0x1,%edi
    babc:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    bac3:	00 
    bac4:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    bacb:	00 
    bacc:	e8 3f a3 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bad1:	48 89 c7             	mov    %rax,%rdi
    bad4:	e8 87 aa ff ff       	call   6560 <fwp_rc_fresh>
    bad9:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    bae0:	00 
    bae1:	bf 01 00 00 00       	mov    $0x1,%edi
    bae6:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    baed:	00 
    baee:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    baf5:	00 
    baf6:	e8 15 a3 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bafb:	48 89 c7             	mov    %rax,%rdi
    bafe:	e8 5d aa ff ff       	call   6560 <fwp_rc_fresh>
    bb03:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    bb0a:	00 
    bb0b:	bf 01 00 00 00       	mov    $0x1,%edi
    bb10:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    bb17:	00 
    bb18:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    bb1f:	00 
    bb20:	e8 eb a2 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bb25:	48 89 c7             	mov    %rax,%rdi
    bb28:	e8 33 aa ff ff       	call   6560 <fwp_rc_fresh>
    bb2d:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    bb34:	00 
    bb35:	bf 01 00 00 00       	mov    $0x1,%edi
    bb3a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    bb41:	00 
    bb42:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    bb49:	00 
    bb4a:	e8 c1 a2 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bb4f:	48 89 c7             	mov    %rax,%rdi
    bb52:	e8 09 aa ff ff       	call   6560 <fwp_rc_fresh>
    bb57:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    bb5e:	00 
    bb5f:	bf 01 00 00 00       	mov    $0x1,%edi
    bb64:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    bb6b:	00 
    bb6c:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    bb73:	00 
    bb74:	e8 97 a2 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bb79:	48 89 c7             	mov    %rax,%rdi
    bb7c:	e8 df a9 ff ff       	call   6560 <fwp_rc_fresh>
    bb81:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    bb88:	00 
    bb89:	bf 01 00 00 00       	mov    $0x1,%edi
    bb8e:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    bb95:	00 
    bb96:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    bb9d:	00 
    bb9e:	e8 6d a2 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bba3:	48 89 c7             	mov    %rax,%rdi
    bba6:	e8 b5 a9 ff ff       	call   6560 <fwp_rc_fresh>
    bbab:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    bbb2:	00 
    bbb3:	bf 01 00 00 00       	mov    $0x1,%edi
    bbb8:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    bbbf:	00 
    bbc0:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    bbc7:	00 
    bbc8:	e8 43 a2 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bbcd:	48 89 c7             	mov    %rax,%rdi
    bbd0:	e8 8b a9 ff ff       	call   6560 <fwp_rc_fresh>
    bbd5:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    bbdc:	00 
    bbdd:	bf 01 00 00 00       	mov    $0x1,%edi
    bbe2:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    bbe9:	00 
    bbea:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    bbf1:	00 
    bbf2:	e8 19 a2 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bbf7:	48 89 c7             	mov    %rax,%rdi
    bbfa:	e8 61 a9 ff ff       	call   6560 <fwp_rc_fresh>
    bbff:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    bc06:	00 
    bc07:	bf 01 00 00 00       	mov    $0x1,%edi
    bc0c:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    bc13:	00 
    bc14:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    bc1b:	00 
    bc1c:	e8 ef a1 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bc21:	48 89 c7             	mov    %rax,%rdi
    bc24:	e8 37 a9 ff ff       	call   6560 <fwp_rc_fresh>
    bc29:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    bc30:	00 
    bc31:	bf 01 00 00 00       	mov    $0x1,%edi
    bc36:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    bc3d:	00 
    bc3e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    bc45:	00 
    bc46:	e8 c5 a1 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bc4b:	48 89 c7             	mov    %rax,%rdi
    bc4e:	e8 0d a9 ff ff       	call   6560 <fwp_rc_fresh>
    bc53:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    bc5a:	00 
    bc5b:	bf 01 00 00 00       	mov    $0x1,%edi
    bc60:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    bc67:	00 
    bc68:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    bc6f:	00 
    bc70:	e8 9b a1 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bc75:	48 89 c7             	mov    %rax,%rdi
    bc78:	e8 e3 a8 ff ff       	call   6560 <fwp_rc_fresh>
    bc7d:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    bc84:	00 
    bc85:	bf 01 00 00 00       	mov    $0x1,%edi
    bc8a:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    bc91:	00 
    bc92:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    bc99:	00 
    bc9a:	e8 71 a1 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bc9f:	48 89 c7             	mov    %rax,%rdi
    bca2:	e8 b9 a8 ff ff       	call   6560 <fwp_rc_fresh>
    bca7:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    bcae:	00 
    bcaf:	bf 01 00 00 00       	mov    $0x1,%edi
    bcb4:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    bcbb:	00 
    bcbc:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    bcc3:	00 
    bcc4:	e8 47 a1 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bcc9:	48 89 c7             	mov    %rax,%rdi
    bccc:	e8 8f a8 ff ff       	call   6560 <fwp_rc_fresh>
    bcd1:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    bcd8:	00 
    bcd9:	bf 01 00 00 00       	mov    $0x1,%edi
    bcde:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    bce5:	00 
    bce6:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    bced:	00 
    bcee:	e8 1d a1 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bcf3:	48 89 c7             	mov    %rax,%rdi
    bcf6:	e8 65 a8 ff ff       	call   6560 <fwp_rc_fresh>
    bcfb:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    bd02:	00 
    bd03:	bf 01 00 00 00       	mov    $0x1,%edi
    bd08:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    bd0f:	00 
    bd10:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    bd17:	00 
    bd18:	e8 f3 a0 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bd1d:	48 89 c7             	mov    %rax,%rdi
    bd20:	e8 3b a8 ff ff       	call   6560 <fwp_rc_fresh>
    bd25:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    bd2c:	00 
    bd2d:	bf 01 00 00 00       	mov    $0x1,%edi
    bd32:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    bd39:	00 
    bd3a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    bd41:	00 
    bd42:	e8 c9 a0 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bd47:	48 89 c7             	mov    %rax,%rdi
    bd4a:	e8 11 a8 ff ff       	call   6560 <fwp_rc_fresh>
    bd4f:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    bd56:	00 
    bd57:	bf 01 00 00 00       	mov    $0x1,%edi
    bd5c:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    bd63:	00 
    bd64:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    bd6b:	00 
    bd6c:	e8 9f a0 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bd71:	48 89 c7             	mov    %rax,%rdi
    bd74:	e8 e7 a7 ff ff       	call   6560 <fwp_rc_fresh>
    bd79:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    bd80:	00 
    bd81:	bf 01 00 00 00       	mov    $0x1,%edi
    bd86:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    bd8d:	00 
    bd8e:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    bd95:	00 
    bd96:	e8 75 a0 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bd9b:	48 89 c7             	mov    %rax,%rdi
    bd9e:	e8 bd a7 ff ff       	call   6560 <fwp_rc_fresh>
    bda3:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    bdaa:	00 
    bdab:	bf 01 00 00 00       	mov    $0x1,%edi
    bdb0:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    bdb7:	00 
    bdb8:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    bdbf:	00 
    bdc0:	e8 4b a0 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bdc5:	48 89 c7             	mov    %rax,%rdi
    bdc8:	e8 93 a7 ff ff       	call   6560 <fwp_rc_fresh>
    bdcd:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    bdd4:	00 
    bdd5:	bf 01 00 00 00       	mov    $0x1,%edi
    bdda:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    bde1:	00 
    bde2:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    bde9:	00 
    bdea:	e8 21 a0 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bdef:	48 89 c7             	mov    %rax,%rdi
    bdf2:	e8 69 a7 ff ff       	call   6560 <fwp_rc_fresh>
    bdf7:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    bdfe:	00 
    bdff:	bf 01 00 00 00       	mov    $0x1,%edi
    be04:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    be0b:	00 
    be0c:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    be13:	00 
    be14:	e8 f7 9f ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    be19:	48 89 c7             	mov    %rax,%rdi
    be1c:	e8 3f a7 ff ff       	call   6560 <fwp_rc_fresh>
    be21:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    be28:	00 
    be29:	bf 01 00 00 00       	mov    $0x1,%edi
    be2e:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    be35:	00 
    be36:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    be3d:	00 
    be3e:	e8 cd 9f ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    be43:	48 89 c7             	mov    %rax,%rdi
    be46:	e8 15 a7 ff ff       	call   6560 <fwp_rc_fresh>
    be4b:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    be52:	00 
    be53:	bf 01 00 00 00       	mov    $0x1,%edi
    be58:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    be5f:	00 
    be60:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    be67:	00 
    be68:	e8 a3 9f ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    be6d:	48 89 c7             	mov    %rax,%rdi
    be70:	e8 eb a6 ff ff       	call   6560 <fwp_rc_fresh>
    be75:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    be7c:	00 
    be7d:	bf 01 00 00 00       	mov    $0x1,%edi
    be82:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    be89:	00 
    be8a:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    be91:	00 
    be92:	e8 79 9f ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    be97:	48 89 c7             	mov    %rax,%rdi
    be9a:	e8 c1 a6 ff ff       	call   6560 <fwp_rc_fresh>
    be9f:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    bea6:	00 
    bea7:	bf 01 00 00 00       	mov    $0x1,%edi
    beac:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    beb3:	00 
    beb4:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    bebb:	00 
    bebc:	e8 4f 9f ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bec1:	48 89 c7             	mov    %rax,%rdi
    bec4:	e8 97 a6 ff ff       	call   6560 <fwp_rc_fresh>
    bec9:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    bed0:	00 
    bed1:	bf 01 00 00 00       	mov    $0x1,%edi
    bed6:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    bedd:	00 
    bede:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    bee5:	00 
    bee6:	e8 25 9f ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    beeb:	48 89 c7             	mov    %rax,%rdi
    beee:	e8 6d a6 ff ff       	call   6560 <fwp_rc_fresh>
    bef3:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    befa:	00 
    befb:	bf 01 00 00 00       	mov    $0x1,%edi
    bf00:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    bf07:	00 
    bf08:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    bf0f:	00 
    bf10:	e8 fb 9e ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bf15:	48 8b 15 9c 8c 01 00 	mov    0x18c9c(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    bf1c:	49 89 c5             	mov    %rax,%r13
    bf1f:	48 2b 05 6a 8c 01 00 	sub    0x18c6a(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    bf26:	48 c1 e2 10          	shl    $0x10,%rdx
    bf2a:	48 39 d0             	cmp    %rdx,%rax
    bf2d:	73 59                	jae    bf88 <f0+0x13b8>
    bf2f:	48 89 c2             	mov    %rax,%rdx
    bf32:	48 c1 ea 10          	shr    $0x10,%rdx
    bf36:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bf3a:	48 8b 15 97 8c 01 00 	mov    0x18c97(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    bf41:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bf45:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bf49:	4d 85 e4             	test   %r12,%r12
    bf4c:	74 3a                	je     bf88 <f0+0x13b8>
    bf4e:	0f b6 0a             	movzbl (%rdx),%ecx
    bf51:	80 f9 02             	cmp    $0x2,%cl
    bf54:	0f 84 c6 15 00 00    	je     d520 <f0+0x2950>
    bf5a:	80 f9 01             	cmp    $0x1,%cl
    bf5d:	75 29                	jne    bf88 <f0+0x13b8>
    bf5f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bf62:	0f b7 c0             	movzwl %ax,%eax
    bf65:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bf68:	48 0f af c1          	imul   %rcx,%rax
    bf6c:	48 c1 e8 20          	shr    $0x20,%rax
    bf70:	48 39 d0             	cmp    %rdx,%rax
    bf73:	73 13                	jae    bf88 <f0+0x13b8>
    bf75:	49 01 c4             	add    %rax,%r12
    bf78:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bf7d:	0f 84 99 17 00 00    	je     d71c <f0+0x2b4c>
    bf83:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bf88:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    bf8f:	33 f3 bf 
    bf92:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    bf99:	00 
    bf9a:	bf 01 00 00 00       	mov    $0x1,%edi
    bf9f:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    bfa6:	00 
    bfa7:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    bfae:	00 
    bfaf:	e8 5c 9e ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    bfb4:	48 8b 15 fd 8b 01 00 	mov    0x18bfd(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    bfbb:	49 89 c5             	mov    %rax,%r13
    bfbe:	48 2b 05 cb 8b 01 00 	sub    0x18bcb(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    bfc5:	48 c1 e2 10          	shl    $0x10,%rdx
    bfc9:	48 39 d0             	cmp    %rdx,%rax
    bfcc:	73 59                	jae    c027 <f0+0x1457>
    bfce:	48 89 c2             	mov    %rax,%rdx
    bfd1:	48 c1 ea 10          	shr    $0x10,%rdx
    bfd5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bfd9:	48 8b 15 f8 8b 01 00 	mov    0x18bf8(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    bfe0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bfe4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bfe8:	4d 85 e4             	test   %r12,%r12
    bfeb:	74 3a                	je     c027 <f0+0x1457>
    bfed:	0f b6 0a             	movzbl (%rdx),%ecx
    bff0:	80 f9 02             	cmp    $0x2,%cl
    bff3:	0f 84 17 15 00 00    	je     d510 <f0+0x2940>
    bff9:	80 f9 01             	cmp    $0x1,%cl
    bffc:	75 29                	jne    c027 <f0+0x1457>
    bffe:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c001:	0f b7 c0             	movzwl %ax,%eax
    c004:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c007:	48 0f af c1          	imul   %rcx,%rax
    c00b:	48 c1 e8 20          	shr    $0x20,%rax
    c00f:	48 39 d0             	cmp    %rdx,%rax
    c012:	73 13                	jae    c027 <f0+0x1457>
    c014:	49 01 c4             	add    %rax,%r12
    c017:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c01c:	0f 84 07 17 00 00    	je     d729 <f0+0x2b59>
    c022:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c027:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c02e:	00 f0 3f 
    c031:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    c038:	00 
    c039:	bf 01 00 00 00       	mov    $0x1,%edi
    c03e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    c045:	00 
    c046:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    c04d:	00 
    c04e:	e8 bd 9d ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    c053:	48 8b 15 5e 8b 01 00 	mov    0x18b5e(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c05a:	49 89 c5             	mov    %rax,%r13
    c05d:	48 2b 05 2c 8b 01 00 	sub    0x18b2c(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c064:	48 c1 e2 10          	shl    $0x10,%rdx
    c068:	48 39 d0             	cmp    %rdx,%rax
    c06b:	73 59                	jae    c0c6 <f0+0x14f6>
    c06d:	48 89 c2             	mov    %rax,%rdx
    c070:	48 c1 ea 10          	shr    $0x10,%rdx
    c074:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c078:	48 8b 15 59 8b 01 00 	mov    0x18b59(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c07f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c083:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c087:	4d 85 e4             	test   %r12,%r12
    c08a:	74 3a                	je     c0c6 <f0+0x14f6>
    c08c:	0f b6 0a             	movzbl (%rdx),%ecx
    c08f:	80 f9 02             	cmp    $0x2,%cl
    c092:	0f 84 28 15 00 00    	je     d5c0 <f0+0x29f0>
    c098:	80 f9 01             	cmp    $0x1,%cl
    c09b:	75 29                	jne    c0c6 <f0+0x14f6>
    c09d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c0a0:	0f b7 c0             	movzwl %ax,%eax
    c0a3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c0a6:	48 0f af c1          	imul   %rcx,%rax
    c0aa:	48 c1 e8 20          	shr    $0x20,%rax
    c0ae:	48 39 d0             	cmp    %rdx,%rax
    c0b1:	73 13                	jae    c0c6 <f0+0x14f6>
    c0b3:	49 01 c4             	add    %rax,%r12
    c0b6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c0bb:	0f 84 75 16 00 00    	je     d736 <f0+0x2b66>
    c0c1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c0c6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c0cd:	33 f3 bf 
    c0d0:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    c0d7:	00 
    c0d8:	bf 01 00 00 00       	mov    $0x1,%edi
    c0dd:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    c0e4:	00 
    c0e5:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    c0ec:	00 
    c0ed:	e8 1e 9d ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    c0f2:	48 8b 15 bf 8a 01 00 	mov    0x18abf(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c0f9:	49 89 c5             	mov    %rax,%r13
    c0fc:	48 2b 05 8d 8a 01 00 	sub    0x18a8d(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c103:	48 c1 e2 10          	shl    $0x10,%rdx
    c107:	48 39 d0             	cmp    %rdx,%rax
    c10a:	73 59                	jae    c165 <f0+0x1595>
    c10c:	48 89 c2             	mov    %rax,%rdx
    c10f:	48 c1 ea 10          	shr    $0x10,%rdx
    c113:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c117:	48 8b 15 ba 8a 01 00 	mov    0x18aba(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c11e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c122:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c126:	4d 85 e4             	test   %r12,%r12
    c129:	74 3a                	je     c165 <f0+0x1595>
    c12b:	0f b6 0a             	movzbl (%rdx),%ecx
    c12e:	80 f9 02             	cmp    $0x2,%cl
    c131:	0f 84 79 14 00 00    	je     d5b0 <f0+0x29e0>
    c137:	80 f9 01             	cmp    $0x1,%cl
    c13a:	75 29                	jne    c165 <f0+0x1595>
    c13c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c13f:	0f b7 c0             	movzwl %ax,%eax
    c142:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c145:	48 0f af c1          	imul   %rcx,%rax
    c149:	48 c1 e8 20          	shr    $0x20,%rax
    c14d:	48 39 d0             	cmp    %rdx,%rax
    c150:	73 13                	jae    c165 <f0+0x1595>
    c152:	49 01 c4             	add    %rax,%r12
    c155:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c15a:	0f 84 e3 15 00 00    	je     d743 <f0+0x2b73>
    c160:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c165:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c16c:	00 f0 3f 
    c16f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    c176:	00 
    c177:	bf 01 00 00 00       	mov    $0x1,%edi
    c17c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    c183:	00 
    c184:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    c18b:	00 
    c18c:	e8 7f 9c ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    c191:	48 8b 15 20 8a 01 00 	mov    0x18a20(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c198:	49 89 c5             	mov    %rax,%r13
    c19b:	48 2b 05 ee 89 01 00 	sub    0x189ee(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c1a2:	48 c1 e2 10          	shl    $0x10,%rdx
    c1a6:	48 39 d0             	cmp    %rdx,%rax
    c1a9:	73 59                	jae    c204 <f0+0x1634>
    c1ab:	48 89 c2             	mov    %rax,%rdx
    c1ae:	48 c1 ea 10          	shr    $0x10,%rdx
    c1b2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c1b6:	48 8b 15 1b 8a 01 00 	mov    0x18a1b(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c1bd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c1c1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c1c5:	4d 85 e4             	test   %r12,%r12
    c1c8:	74 3a                	je     c204 <f0+0x1634>
    c1ca:	0f b6 0a             	movzbl (%rdx),%ecx
    c1cd:	80 f9 02             	cmp    $0x2,%cl
    c1d0:	0f 84 ca 13 00 00    	je     d5a0 <f0+0x29d0>
    c1d6:	80 f9 01             	cmp    $0x1,%cl
    c1d9:	75 29                	jne    c204 <f0+0x1634>
    c1db:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c1de:	0f b7 c0             	movzwl %ax,%eax
    c1e1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c1e4:	48 0f af c1          	imul   %rcx,%rax
    c1e8:	48 c1 e8 20          	shr    $0x20,%rax
    c1ec:	48 39 d0             	cmp    %rdx,%rax
    c1ef:	73 13                	jae    c204 <f0+0x1634>
    c1f1:	49 01 c4             	add    %rax,%r12
    c1f4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c1f9:	0f 84 51 15 00 00    	je     d750 <f0+0x2b80>
    c1ff:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c204:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c20b:	33 f3 bf 
    c20e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    c215:	00 
    c216:	bf 01 00 00 00       	mov    $0x1,%edi
    c21b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    c222:	00 
    c223:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    c22a:	00 
    c22b:	e8 e0 9b ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    c230:	48 8b 15 81 89 01 00 	mov    0x18981(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c237:	49 89 c5             	mov    %rax,%r13
    c23a:	48 2b 05 4f 89 01 00 	sub    0x1894f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c241:	48 c1 e2 10          	shl    $0x10,%rdx
    c245:	48 39 d0             	cmp    %rdx,%rax
    c248:	73 59                	jae    c2a3 <f0+0x16d3>
    c24a:	48 89 c2             	mov    %rax,%rdx
    c24d:	48 c1 ea 10          	shr    $0x10,%rdx
    c251:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c255:	48 8b 15 7c 89 01 00 	mov    0x1897c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c25c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c260:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c264:	4d 85 e4             	test   %r12,%r12
    c267:	74 3a                	je     c2a3 <f0+0x16d3>
    c269:	0f b6 0a             	movzbl (%rdx),%ecx
    c26c:	80 f9 02             	cmp    $0x2,%cl
    c26f:	0f 84 1b 13 00 00    	je     d590 <f0+0x29c0>
    c275:	80 f9 01             	cmp    $0x1,%cl
    c278:	75 29                	jne    c2a3 <f0+0x16d3>
    c27a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c27d:	0f b7 c0             	movzwl %ax,%eax
    c280:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c283:	48 0f af c1          	imul   %rcx,%rax
    c287:	48 c1 e8 20          	shr    $0x20,%rax
    c28b:	48 39 d0             	cmp    %rdx,%rax
    c28e:	73 13                	jae    c2a3 <f0+0x16d3>
    c290:	49 01 c4             	add    %rax,%r12
    c293:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c298:	0f 84 bf 14 00 00    	je     d75d <f0+0x2b8d>
    c29e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c2a3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c2aa:	00 f0 3f 
    c2ad:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    c2b4:	00 
    c2b5:	bf 01 00 00 00       	mov    $0x1,%edi
    c2ba:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    c2c1:	00 
    c2c2:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    c2c9:	00 
    c2ca:	e8 41 9b ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    c2cf:	48 8b 15 e2 88 01 00 	mov    0x188e2(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c2d6:	49 89 c5             	mov    %rax,%r13
    c2d9:	48 2b 05 b0 88 01 00 	sub    0x188b0(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c2e0:	48 c1 e2 10          	shl    $0x10,%rdx
    c2e4:	48 39 d0             	cmp    %rdx,%rax
    c2e7:	73 59                	jae    c342 <f0+0x1772>
    c2e9:	48 89 c2             	mov    %rax,%rdx
    c2ec:	48 c1 ea 10          	shr    $0x10,%rdx
    c2f0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c2f4:	48 8b 15 dd 88 01 00 	mov    0x188dd(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c2fb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c2ff:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c303:	4d 85 e4             	test   %r12,%r12
    c306:	74 3a                	je     c342 <f0+0x1772>
    c308:	0f b6 0a             	movzbl (%rdx),%ecx
    c30b:	80 f9 02             	cmp    $0x2,%cl
    c30e:	0f 84 6c 12 00 00    	je     d580 <f0+0x29b0>
    c314:	80 f9 01             	cmp    $0x1,%cl
    c317:	75 29                	jne    c342 <f0+0x1772>
    c319:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c31c:	0f b7 c0             	movzwl %ax,%eax
    c31f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c322:	48 0f af c1          	imul   %rcx,%rax
    c326:	48 c1 e8 20          	shr    $0x20,%rax
    c32a:	48 39 d0             	cmp    %rdx,%rax
    c32d:	73 13                	jae    c342 <f0+0x1772>
    c32f:	49 01 c4             	add    %rax,%r12
    c332:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c337:	0f 84 2d 14 00 00    	je     d76a <f0+0x2b9a>
    c33d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c342:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c349:	33 f3 bf 
    c34c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    c353:	00 
    c354:	bf 01 00 00 00       	mov    $0x1,%edi
    c359:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    c360:	00 
    c361:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    c368:	00 
    c369:	e8 a2 9a ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    c36e:	48 8b 15 43 88 01 00 	mov    0x18843(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c375:	49 89 c5             	mov    %rax,%r13
    c378:	48 2b 05 11 88 01 00 	sub    0x18811(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c37f:	48 c1 e2 10          	shl    $0x10,%rdx
    c383:	48 39 d0             	cmp    %rdx,%rax
    c386:	73 59                	jae    c3e1 <f0+0x1811>
    c388:	48 89 c2             	mov    %rax,%rdx
    c38b:	48 c1 ea 10          	shr    $0x10,%rdx
    c38f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c393:	48 8b 15 3e 88 01 00 	mov    0x1883e(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c39a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c39e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c3a2:	4d 85 e4             	test   %r12,%r12
    c3a5:	74 3a                	je     c3e1 <f0+0x1811>
    c3a7:	0f b6 0a             	movzbl (%rdx),%ecx
    c3aa:	80 f9 02             	cmp    $0x2,%cl
    c3ad:	0f 84 bd 11 00 00    	je     d570 <f0+0x29a0>
    c3b3:	80 f9 01             	cmp    $0x1,%cl
    c3b6:	75 29                	jne    c3e1 <f0+0x1811>
    c3b8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c3bb:	0f b7 c0             	movzwl %ax,%eax
    c3be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c3c1:	48 0f af c1          	imul   %rcx,%rax
    c3c5:	48 c1 e8 20          	shr    $0x20,%rax
    c3c9:	48 39 d0             	cmp    %rdx,%rax
    c3cc:	73 13                	jae    c3e1 <f0+0x1811>
    c3ce:	49 01 c4             	add    %rax,%r12
    c3d1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c3d6:	0f 84 9b 13 00 00    	je     d777 <f0+0x2ba7>
    c3dc:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c3e1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c3e8:	00 f0 3f 
    c3eb:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    c3f2:	00 
    c3f3:	bf 01 00 00 00       	mov    $0x1,%edi
    c3f8:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    c3ff:	00 
    c400:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    c407:	00 
    c408:	e8 03 9a ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    c40d:	48 8b 15 a4 87 01 00 	mov    0x187a4(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c414:	49 89 c5             	mov    %rax,%r13
    c417:	48 2b 05 72 87 01 00 	sub    0x18772(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c41e:	48 c1 e2 10          	shl    $0x10,%rdx
    c422:	48 39 d0             	cmp    %rdx,%rax
    c425:	73 59                	jae    c480 <f0+0x18b0>
    c427:	48 89 c2             	mov    %rax,%rdx
    c42a:	48 c1 ea 10          	shr    $0x10,%rdx
    c42e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c432:	48 8b 15 9f 87 01 00 	mov    0x1879f(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c439:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c43d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c441:	4d 85 e4             	test   %r12,%r12
    c444:	74 3a                	je     c480 <f0+0x18b0>
    c446:	0f b6 0a             	movzbl (%rdx),%ecx
    c449:	80 f9 02             	cmp    $0x2,%cl
    c44c:	0f 84 0e 11 00 00    	je     d560 <f0+0x2990>
    c452:	80 f9 01             	cmp    $0x1,%cl
    c455:	75 29                	jne    c480 <f0+0x18b0>
    c457:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c45a:	0f b7 c0             	movzwl %ax,%eax
    c45d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c460:	48 0f af c1          	imul   %rcx,%rax
    c464:	48 c1 e8 20          	shr    $0x20,%rax
    c468:	48 39 d0             	cmp    %rdx,%rax
    c46b:	73 13                	jae    c480 <f0+0x18b0>
    c46d:	49 01 c4             	add    %rax,%r12
    c470:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c475:	0f 84 09 13 00 00    	je     d784 <f0+0x2bb4>
    c47b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c480:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c487:	33 f3 bf 
    c48a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    c491:	00 
    c492:	bf 01 00 00 00       	mov    $0x1,%edi
    c497:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    c49e:	00 
    c49f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    c4a6:	00 
    c4a7:	e8 64 99 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    c4ac:	48 8b 15 05 87 01 00 	mov    0x18705(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c4b3:	49 89 c5             	mov    %rax,%r13
    c4b6:	48 2b 05 d3 86 01 00 	sub    0x186d3(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c4bd:	48 c1 e2 10          	shl    $0x10,%rdx
    c4c1:	48 39 d0             	cmp    %rdx,%rax
    c4c4:	73 59                	jae    c51f <f0+0x194f>
    c4c6:	48 89 c2             	mov    %rax,%rdx
    c4c9:	48 c1 ea 10          	shr    $0x10,%rdx
    c4cd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c4d1:	48 8b 15 00 87 01 00 	mov    0x18700(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c4d8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c4dc:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c4e0:	4d 85 e4             	test   %r12,%r12
    c4e3:	74 3a                	je     c51f <f0+0x194f>
    c4e5:	0f b6 0a             	movzbl (%rdx),%ecx
    c4e8:	80 f9 02             	cmp    $0x2,%cl
    c4eb:	0f 84 5f 10 00 00    	je     d550 <f0+0x2980>
    c4f1:	80 f9 01             	cmp    $0x1,%cl
    c4f4:	75 29                	jne    c51f <f0+0x194f>
    c4f6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c4f9:	0f b7 c0             	movzwl %ax,%eax
    c4fc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c4ff:	48 0f af c1          	imul   %rcx,%rax
    c503:	48 c1 e8 20          	shr    $0x20,%rax
    c507:	48 39 d0             	cmp    %rdx,%rax
    c50a:	73 13                	jae    c51f <f0+0x194f>
    c50c:	49 01 c4             	add    %rax,%r12
    c50f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c514:	0f 84 77 12 00 00    	je     d791 <f0+0x2bc1>
    c51a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c51f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c526:	00 f0 3f 
    c529:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    c530:	00 
    c531:	bf 01 00 00 00       	mov    $0x1,%edi
    c536:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    c53d:	00 
    c53e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    c545:	00 
    c546:	e8 c5 98 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    c54b:	48 8b 15 66 86 01 00 	mov    0x18666(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c552:	49 89 c5             	mov    %rax,%r13
    c555:	48 2b 05 34 86 01 00 	sub    0x18634(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c55c:	48 c1 e2 10          	shl    $0x10,%rdx
    c560:	48 39 d0             	cmp    %rdx,%rax
    c563:	73 59                	jae    c5be <f0+0x19ee>
    c565:	48 89 c2             	mov    %rax,%rdx
    c568:	48 c1 ea 10          	shr    $0x10,%rdx
    c56c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c570:	48 8b 15 61 86 01 00 	mov    0x18661(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c577:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c57b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c57f:	4d 85 e4             	test   %r12,%r12
    c582:	74 3a                	je     c5be <f0+0x19ee>
    c584:	0f b6 0a             	movzbl (%rdx),%ecx
    c587:	80 f9 02             	cmp    $0x2,%cl
    c58a:	0f 84 40 0f 00 00    	je     d4d0 <f0+0x2900>
    c590:	80 f9 01             	cmp    $0x1,%cl
    c593:	75 29                	jne    c5be <f0+0x19ee>
    c595:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c598:	0f b7 c0             	movzwl %ax,%eax
    c59b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c59e:	48 0f af c1          	imul   %rcx,%rax
    c5a2:	48 c1 e8 20          	shr    $0x20,%rax
    c5a6:	48 39 d0             	cmp    %rdx,%rax
    c5a9:	73 13                	jae    c5be <f0+0x19ee>
    c5ab:	49 01 c4             	add    %rax,%r12
    c5ae:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c5b3:	0f 84 e5 11 00 00    	je     d79e <f0+0x2bce>
    c5b9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c5be:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c5c5:	33 f3 bf 
    c5c8:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    c5cf:	00 
    c5d0:	bf 01 00 00 00       	mov    $0x1,%edi
    c5d5:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    c5dc:	00 
    c5dd:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    c5e4:	00 
    c5e5:	e8 26 98 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    c5ea:	48 8b 15 c7 85 01 00 	mov    0x185c7(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c5f1:	49 89 c5             	mov    %rax,%r13
    c5f4:	48 2b 05 95 85 01 00 	sub    0x18595(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c5fb:	48 c1 e2 10          	shl    $0x10,%rdx
    c5ff:	48 39 d0             	cmp    %rdx,%rax
    c602:	73 59                	jae    c65d <f0+0x1a8d>
    c604:	48 89 c2             	mov    %rax,%rdx
    c607:	48 c1 ea 10          	shr    $0x10,%rdx
    c60b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c60f:	48 8b 15 c2 85 01 00 	mov    0x185c2(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c616:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c61a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c61e:	4d 85 e4             	test   %r12,%r12
    c621:	74 3a                	je     c65d <f0+0x1a8d>
    c623:	0f b6 0a             	movzbl (%rdx),%ecx
    c626:	80 f9 02             	cmp    $0x2,%cl
    c629:	0f 84 91 0e 00 00    	je     d4c0 <f0+0x28f0>
    c62f:	80 f9 01             	cmp    $0x1,%cl
    c632:	75 29                	jne    c65d <f0+0x1a8d>
    c634:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c637:	0f b7 c0             	movzwl %ax,%eax
    c63a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c63d:	48 0f af c1          	imul   %rcx,%rax
    c641:	48 c1 e8 20          	shr    $0x20,%rax
    c645:	48 39 d0             	cmp    %rdx,%rax
    c648:	73 13                	jae    c65d <f0+0x1a8d>
    c64a:	49 01 c4             	add    %rax,%r12
    c64d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c652:	0f 84 53 11 00 00    	je     d7ab <f0+0x2bdb>
    c658:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c65d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c664:	00 f0 3f 
    c667:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    c66e:	00 
    c66f:	bf 01 00 00 00       	mov    $0x1,%edi
    c674:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    c67b:	00 
    c67c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    c683:	00 
    c684:	e8 87 97 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    c689:	48 8b 15 28 85 01 00 	mov    0x18528(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c690:	49 89 c5             	mov    %rax,%r13
    c693:	48 2b 05 f6 84 01 00 	sub    0x184f6(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c69a:	48 c1 e2 10          	shl    $0x10,%rdx
    c69e:	48 39 d0             	cmp    %rdx,%rax
    c6a1:	73 59                	jae    c6fc <f0+0x1b2c>
    c6a3:	48 89 c2             	mov    %rax,%rdx
    c6a6:	48 c1 ea 10          	shr    $0x10,%rdx
    c6aa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c6ae:	48 8b 15 23 85 01 00 	mov    0x18523(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c6b5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c6b9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c6bd:	4d 85 e4             	test   %r12,%r12
    c6c0:	74 3a                	je     c6fc <f0+0x1b2c>
    c6c2:	0f b6 0a             	movzbl (%rdx),%ecx
    c6c5:	80 f9 02             	cmp    $0x2,%cl
    c6c8:	0f 84 e2 0d 00 00    	je     d4b0 <f0+0x28e0>
    c6ce:	80 f9 01             	cmp    $0x1,%cl
    c6d1:	75 29                	jne    c6fc <f0+0x1b2c>
    c6d3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c6d6:	0f b7 c0             	movzwl %ax,%eax
    c6d9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c6dc:	48 0f af c1          	imul   %rcx,%rax
    c6e0:	48 c1 e8 20          	shr    $0x20,%rax
    c6e4:	48 39 d0             	cmp    %rdx,%rax
    c6e7:	73 13                	jae    c6fc <f0+0x1b2c>
    c6e9:	49 01 c4             	add    %rax,%r12
    c6ec:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c6f1:	0f 84 c1 10 00 00    	je     d7b8 <f0+0x2be8>
    c6f7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c6fc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c703:	33 f3 bf 
    c706:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    c70d:	00 
    c70e:	bf 01 00 00 00       	mov    $0x1,%edi
    c713:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    c71a:	00 
    c71b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    c722:	00 
    c723:	e8 e8 96 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    c728:	48 8b 15 89 84 01 00 	mov    0x18489(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c72f:	49 89 c5             	mov    %rax,%r13
    c732:	48 2b 05 57 84 01 00 	sub    0x18457(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c739:	48 c1 e2 10          	shl    $0x10,%rdx
    c73d:	48 39 d0             	cmp    %rdx,%rax
    c740:	73 59                	jae    c79b <f0+0x1bcb>
    c742:	48 89 c2             	mov    %rax,%rdx
    c745:	48 c1 ea 10          	shr    $0x10,%rdx
    c749:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c74d:	48 8b 15 84 84 01 00 	mov    0x18484(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c754:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c758:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c75c:	4d 85 e4             	test   %r12,%r12
    c75f:	74 3a                	je     c79b <f0+0x1bcb>
    c761:	0f b6 0a             	movzbl (%rdx),%ecx
    c764:	80 f9 02             	cmp    $0x2,%cl
    c767:	0f 84 33 0d 00 00    	je     d4a0 <f0+0x28d0>
    c76d:	80 f9 01             	cmp    $0x1,%cl
    c770:	75 29                	jne    c79b <f0+0x1bcb>
    c772:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c775:	0f b7 c0             	movzwl %ax,%eax
    c778:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c77b:	48 0f af c1          	imul   %rcx,%rax
    c77f:	48 c1 e8 20          	shr    $0x20,%rax
    c783:	48 39 d0             	cmp    %rdx,%rax
    c786:	73 13                	jae    c79b <f0+0x1bcb>
    c788:	49 01 c4             	add    %rax,%r12
    c78b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c790:	0f 84 2f 10 00 00    	je     d7c5 <f0+0x2bf5>
    c796:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c79b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c7a2:	00 f0 3f 
    c7a5:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    c7ac:	00 
    c7ad:	bf 01 00 00 00       	mov    $0x1,%edi
    c7b2:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    c7b9:	00 
    c7ba:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    c7c1:	00 
    c7c2:	e8 49 96 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    c7c7:	48 8b 15 ea 83 01 00 	mov    0x183ea(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c7ce:	49 89 c5             	mov    %rax,%r13
    c7d1:	48 2b 05 b8 83 01 00 	sub    0x183b8(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c7d8:	48 c1 e2 10          	shl    $0x10,%rdx
    c7dc:	48 39 d0             	cmp    %rdx,%rax
    c7df:	73 59                	jae    c83a <f0+0x1c6a>
    c7e1:	48 89 c2             	mov    %rax,%rdx
    c7e4:	48 c1 ea 10          	shr    $0x10,%rdx
    c7e8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c7ec:	48 8b 15 e5 83 01 00 	mov    0x183e5(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c7f3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c7f7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c7fb:	4d 85 e4             	test   %r12,%r12
    c7fe:	74 3a                	je     c83a <f0+0x1c6a>
    c800:	0f b6 0a             	movzbl (%rdx),%ecx
    c803:	80 f9 02             	cmp    $0x2,%cl
    c806:	0f 84 84 0c 00 00    	je     d490 <f0+0x28c0>
    c80c:	80 f9 01             	cmp    $0x1,%cl
    c80f:	75 29                	jne    c83a <f0+0x1c6a>
    c811:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c814:	0f b7 c0             	movzwl %ax,%eax
    c817:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c81a:	48 0f af c1          	imul   %rcx,%rax
    c81e:	48 c1 e8 20          	shr    $0x20,%rax
    c822:	48 39 d0             	cmp    %rdx,%rax
    c825:	73 13                	jae    c83a <f0+0x1c6a>
    c827:	49 01 c4             	add    %rax,%r12
    c82a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c82f:	0f 84 9d 0f 00 00    	je     d7d2 <f0+0x2c02>
    c835:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c83a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c841:	33 f3 bf 
    c844:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    c84b:	00 
    c84c:	bf 01 00 00 00       	mov    $0x1,%edi
    c851:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    c858:	00 
    c859:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    c860:	00 
    c861:	e8 aa 95 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    c866:	48 8b 15 4b 83 01 00 	mov    0x1834b(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c86d:	49 89 c5             	mov    %rax,%r13
    c870:	48 2b 05 19 83 01 00 	sub    0x18319(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c877:	48 c1 e2 10          	shl    $0x10,%rdx
    c87b:	48 39 d0             	cmp    %rdx,%rax
    c87e:	73 59                	jae    c8d9 <f0+0x1d09>
    c880:	48 89 c2             	mov    %rax,%rdx
    c883:	48 c1 ea 10          	shr    $0x10,%rdx
    c887:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c88b:	48 8b 15 46 83 01 00 	mov    0x18346(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c892:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c896:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c89a:	4d 85 e4             	test   %r12,%r12
    c89d:	74 3a                	je     c8d9 <f0+0x1d09>
    c89f:	0f b6 0a             	movzbl (%rdx),%ecx
    c8a2:	80 f9 02             	cmp    $0x2,%cl
    c8a5:	0f 84 d5 0b 00 00    	je     d480 <f0+0x28b0>
    c8ab:	80 f9 01             	cmp    $0x1,%cl
    c8ae:	75 29                	jne    c8d9 <f0+0x1d09>
    c8b0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c8b3:	0f b7 c0             	movzwl %ax,%eax
    c8b6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c8b9:	48 0f af c1          	imul   %rcx,%rax
    c8bd:	48 c1 e8 20          	shr    $0x20,%rax
    c8c1:	48 39 d0             	cmp    %rdx,%rax
    c8c4:	73 13                	jae    c8d9 <f0+0x1d09>
    c8c6:	49 01 c4             	add    %rax,%r12
    c8c9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c8ce:	0f 84 0b 0f 00 00    	je     d7df <f0+0x2c0f>
    c8d4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c8d9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c8e0:	00 f0 3f 
    c8e3:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    c8ea:	00 
    c8eb:	bf 01 00 00 00       	mov    $0x1,%edi
    c8f0:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    c8f7:	00 
    c8f8:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    c8ff:	00 
    c900:	e8 0b 95 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    c905:	48 8b 15 ac 82 01 00 	mov    0x182ac(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c90c:	49 89 c5             	mov    %rax,%r13
    c90f:	48 2b 05 7a 82 01 00 	sub    0x1827a(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c916:	48 c1 e2 10          	shl    $0x10,%rdx
    c91a:	48 39 d0             	cmp    %rdx,%rax
    c91d:	73 59                	jae    c978 <f0+0x1da8>
    c91f:	48 89 c2             	mov    %rax,%rdx
    c922:	48 c1 ea 10          	shr    $0x10,%rdx
    c926:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c92a:	48 8b 15 a7 82 01 00 	mov    0x182a7(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c931:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c935:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c939:	4d 85 e4             	test   %r12,%r12
    c93c:	74 3a                	je     c978 <f0+0x1da8>
    c93e:	0f b6 0a             	movzbl (%rdx),%ecx
    c941:	80 f9 02             	cmp    $0x2,%cl
    c944:	0f 84 26 0b 00 00    	je     d470 <f0+0x28a0>
    c94a:	80 f9 01             	cmp    $0x1,%cl
    c94d:	75 29                	jne    c978 <f0+0x1da8>
    c94f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c952:	0f b7 c0             	movzwl %ax,%eax
    c955:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c958:	48 0f af c1          	imul   %rcx,%rax
    c95c:	48 c1 e8 20          	shr    $0x20,%rax
    c960:	48 39 d0             	cmp    %rdx,%rax
    c963:	73 13                	jae    c978 <f0+0x1da8>
    c965:	49 01 c4             	add    %rax,%r12
    c968:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c96d:	0f 84 79 0e 00 00    	je     d7ec <f0+0x2c1c>
    c973:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c978:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c97f:	33 f3 bf 
    c982:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    c989:	00 
    c98a:	bf 01 00 00 00       	mov    $0x1,%edi
    c98f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    c996:	00 
    c997:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    c99e:	00 
    c99f:	e8 6c 94 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    c9a4:	48 8b 15 0d 82 01 00 	mov    0x1820d(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    c9ab:	49 89 c5             	mov    %rax,%r13
    c9ae:	48 2b 05 db 81 01 00 	sub    0x181db(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    c9b5:	48 c1 e2 10          	shl    $0x10,%rdx
    c9b9:	48 39 d0             	cmp    %rdx,%rax
    c9bc:	73 59                	jae    ca17 <f0+0x1e47>
    c9be:	48 89 c2             	mov    %rax,%rdx
    c9c1:	48 c1 ea 10          	shr    $0x10,%rdx
    c9c5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c9c9:	48 8b 15 08 82 01 00 	mov    0x18208(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    c9d0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c9d4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c9d8:	4d 85 e4             	test   %r12,%r12
    c9db:	74 3a                	je     ca17 <f0+0x1e47>
    c9dd:	0f b6 0a             	movzbl (%rdx),%ecx
    c9e0:	80 f9 02             	cmp    $0x2,%cl
    c9e3:	0f 84 77 0a 00 00    	je     d460 <f0+0x2890>
    c9e9:	80 f9 01             	cmp    $0x1,%cl
    c9ec:	75 29                	jne    ca17 <f0+0x1e47>
    c9ee:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c9f1:	0f b7 c0             	movzwl %ax,%eax
    c9f4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c9f7:	48 0f af c1          	imul   %rcx,%rax
    c9fb:	48 c1 e8 20          	shr    $0x20,%rax
    c9ff:	48 39 d0             	cmp    %rdx,%rax
    ca02:	73 13                	jae    ca17 <f0+0x1e47>
    ca04:	49 01 c4             	add    %rax,%r12
    ca07:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca0c:	0f 84 e7 0d 00 00    	je     d7f9 <f0+0x2c29>
    ca12:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca17:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ca1e:	00 f0 3f 
    ca21:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    ca28:	00 
    ca29:	bf 01 00 00 00       	mov    $0x1,%edi
    ca2e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    ca35:	00 
    ca36:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    ca3d:	00 
    ca3e:	e8 cd 93 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    ca43:	48 8b 15 6e 81 01 00 	mov    0x1816e(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    ca4a:	49 89 c5             	mov    %rax,%r13
    ca4d:	48 2b 05 3c 81 01 00 	sub    0x1813c(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ca54:	48 c1 e2 10          	shl    $0x10,%rdx
    ca58:	48 39 d0             	cmp    %rdx,%rax
    ca5b:	73 59                	jae    cab6 <f0+0x1ee6>
    ca5d:	48 89 c2             	mov    %rax,%rdx
    ca60:	48 c1 ea 10          	shr    $0x10,%rdx
    ca64:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca68:	48 8b 15 69 81 01 00 	mov    0x18169(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    ca6f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca73:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca77:	4d 85 e4             	test   %r12,%r12
    ca7a:	74 3a                	je     cab6 <f0+0x1ee6>
    ca7c:	0f b6 0a             	movzbl (%rdx),%ecx
    ca7f:	80 f9 02             	cmp    $0x2,%cl
    ca82:	0f 84 38 0c 00 00    	je     d6c0 <f0+0x2af0>
    ca88:	80 f9 01             	cmp    $0x1,%cl
    ca8b:	75 29                	jne    cab6 <f0+0x1ee6>
    ca8d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca90:	0f b7 c0             	movzwl %ax,%eax
    ca93:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca96:	48 0f af c1          	imul   %rcx,%rax
    ca9a:	48 c1 e8 20          	shr    $0x20,%rax
    ca9e:	48 39 d0             	cmp    %rdx,%rax
    caa1:	73 13                	jae    cab6 <f0+0x1ee6>
    caa3:	49 01 c4             	add    %rax,%r12
    caa6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    caab:	0f 84 55 0d 00 00    	je     d806 <f0+0x2c36>
    cab1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cab6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cabd:	33 f3 bf 
    cac0:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    cac7:	00 
    cac8:	bf 01 00 00 00       	mov    $0x1,%edi
    cacd:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    cad4:	00 
    cad5:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    cadc:	00 
    cadd:	e8 2e 93 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    cae2:	48 8b 15 cf 80 01 00 	mov    0x180cf(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cae9:	49 89 c5             	mov    %rax,%r13
    caec:	48 2b 05 9d 80 01 00 	sub    0x1809d(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    caf3:	48 c1 e2 10          	shl    $0x10,%rdx
    caf7:	48 39 d0             	cmp    %rdx,%rax
    cafa:	73 59                	jae    cb55 <f0+0x1f85>
    cafc:	48 89 c2             	mov    %rax,%rdx
    caff:	48 c1 ea 10          	shr    $0x10,%rdx
    cb03:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb07:	48 8b 15 ca 80 01 00 	mov    0x180ca(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cb0e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb12:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb16:	4d 85 e4             	test   %r12,%r12
    cb19:	74 3a                	je     cb55 <f0+0x1f85>
    cb1b:	0f b6 0a             	movzbl (%rdx),%ecx
    cb1e:	80 f9 02             	cmp    $0x2,%cl
    cb21:	0f 84 89 0b 00 00    	je     d6b0 <f0+0x2ae0>
    cb27:	80 f9 01             	cmp    $0x1,%cl
    cb2a:	75 29                	jne    cb55 <f0+0x1f85>
    cb2c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb2f:	0f b7 c0             	movzwl %ax,%eax
    cb32:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb35:	48 0f af c1          	imul   %rcx,%rax
    cb39:	48 c1 e8 20          	shr    $0x20,%rax
    cb3d:	48 39 d0             	cmp    %rdx,%rax
    cb40:	73 13                	jae    cb55 <f0+0x1f85>
    cb42:	49 01 c4             	add    %rax,%r12
    cb45:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb4a:	0f 84 c3 0c 00 00    	je     d813 <f0+0x2c43>
    cb50:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb55:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cb5c:	00 f0 3f 
    cb5f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    cb66:	00 
    cb67:	bf 01 00 00 00       	mov    $0x1,%edi
    cb6c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    cb73:	00 
    cb74:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    cb7b:	00 
    cb7c:	e8 8f 92 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    cb81:	48 8b 15 30 80 01 00 	mov    0x18030(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cb88:	49 89 c5             	mov    %rax,%r13
    cb8b:	48 2b 05 fe 7f 01 00 	sub    0x17ffe(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cb92:	48 c1 e2 10          	shl    $0x10,%rdx
    cb96:	48 39 d0             	cmp    %rdx,%rax
    cb99:	73 59                	jae    cbf4 <f0+0x2024>
    cb9b:	48 89 c2             	mov    %rax,%rdx
    cb9e:	48 c1 ea 10          	shr    $0x10,%rdx
    cba2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cba6:	48 8b 15 2b 80 01 00 	mov    0x1802b(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cbad:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cbb1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cbb5:	4d 85 e4             	test   %r12,%r12
    cbb8:	74 3a                	je     cbf4 <f0+0x2024>
    cbba:	0f b6 0a             	movzbl (%rdx),%ecx
    cbbd:	80 f9 02             	cmp    $0x2,%cl
    cbc0:	0f 84 da 0a 00 00    	je     d6a0 <f0+0x2ad0>
    cbc6:	80 f9 01             	cmp    $0x1,%cl
    cbc9:	75 29                	jne    cbf4 <f0+0x2024>
    cbcb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cbce:	0f b7 c0             	movzwl %ax,%eax
    cbd1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cbd4:	48 0f af c1          	imul   %rcx,%rax
    cbd8:	48 c1 e8 20          	shr    $0x20,%rax
    cbdc:	48 39 d0             	cmp    %rdx,%rax
    cbdf:	73 13                	jae    cbf4 <f0+0x2024>
    cbe1:	49 01 c4             	add    %rax,%r12
    cbe4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cbe9:	0f 84 31 0c 00 00    	je     d820 <f0+0x2c50>
    cbef:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cbf4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cbfb:	33 f3 bf 
    cbfe:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    cc05:	00 
    cc06:	bf 01 00 00 00       	mov    $0x1,%edi
    cc0b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    cc12:	00 
    cc13:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    cc1a:	00 
    cc1b:	e8 f0 91 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    cc20:	48 8b 15 91 7f 01 00 	mov    0x17f91(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cc27:	49 89 c5             	mov    %rax,%r13
    cc2a:	48 2b 05 5f 7f 01 00 	sub    0x17f5f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cc31:	48 c1 e2 10          	shl    $0x10,%rdx
    cc35:	48 39 d0             	cmp    %rdx,%rax
    cc38:	73 59                	jae    cc93 <f0+0x20c3>
    cc3a:	48 89 c2             	mov    %rax,%rdx
    cc3d:	48 c1 ea 10          	shr    $0x10,%rdx
    cc41:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc45:	48 8b 15 8c 7f 01 00 	mov    0x17f8c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cc4c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc50:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc54:	4d 85 e4             	test   %r12,%r12
    cc57:	74 3a                	je     cc93 <f0+0x20c3>
    cc59:	0f b6 0a             	movzbl (%rdx),%ecx
    cc5c:	80 f9 02             	cmp    $0x2,%cl
    cc5f:	0f 84 2b 0a 00 00    	je     d690 <f0+0x2ac0>
    cc65:	80 f9 01             	cmp    $0x1,%cl
    cc68:	75 29                	jne    cc93 <f0+0x20c3>
    cc6a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc6d:	0f b7 c0             	movzwl %ax,%eax
    cc70:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc73:	48 0f af c1          	imul   %rcx,%rax
    cc77:	48 c1 e8 20          	shr    $0x20,%rax
    cc7b:	48 39 d0             	cmp    %rdx,%rax
    cc7e:	73 13                	jae    cc93 <f0+0x20c3>
    cc80:	49 01 c4             	add    %rax,%r12
    cc83:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc88:	0f 84 9f 0b 00 00    	je     d82d <f0+0x2c5d>
    cc8e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc93:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc9a:	00 f0 3f 
    cc9d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    cca4:	00 
    cca5:	bf 01 00 00 00       	mov    $0x1,%edi
    ccaa:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    ccb1:	00 
    ccb2:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    ccb9:	00 
    ccba:	e8 51 91 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    ccbf:	48 8b 15 f2 7e 01 00 	mov    0x17ef2(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    ccc6:	49 89 c5             	mov    %rax,%r13
    ccc9:	48 2b 05 c0 7e 01 00 	sub    0x17ec0(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ccd0:	48 c1 e2 10          	shl    $0x10,%rdx
    ccd4:	48 39 d0             	cmp    %rdx,%rax
    ccd7:	73 59                	jae    cd32 <f0+0x2162>
    ccd9:	48 89 c2             	mov    %rax,%rdx
    ccdc:	48 c1 ea 10          	shr    $0x10,%rdx
    cce0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cce4:	48 8b 15 ed 7e 01 00 	mov    0x17eed(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cceb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ccef:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ccf3:	4d 85 e4             	test   %r12,%r12
    ccf6:	74 3a                	je     cd32 <f0+0x2162>
    ccf8:	0f b6 0a             	movzbl (%rdx),%ecx
    ccfb:	80 f9 02             	cmp    $0x2,%cl
    ccfe:	0f 84 7c 09 00 00    	je     d680 <f0+0x2ab0>
    cd04:	80 f9 01             	cmp    $0x1,%cl
    cd07:	75 29                	jne    cd32 <f0+0x2162>
    cd09:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd0c:	0f b7 c0             	movzwl %ax,%eax
    cd0f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd12:	48 0f af c1          	imul   %rcx,%rax
    cd16:	48 c1 e8 20          	shr    $0x20,%rax
    cd1a:	48 39 d0             	cmp    %rdx,%rax
    cd1d:	73 13                	jae    cd32 <f0+0x2162>
    cd1f:	49 01 c4             	add    %rax,%r12
    cd22:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd27:	0f 84 0d 0b 00 00    	je     d83a <f0+0x2c6a>
    cd2d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd32:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cd39:	33 f3 bf 
    cd3c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    cd43:	00 
    cd44:	bf 01 00 00 00       	mov    $0x1,%edi
    cd49:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    cd50:	00 
    cd51:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    cd58:	00 
    cd59:	e8 b2 90 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    cd5e:	48 8b 15 53 7e 01 00 	mov    0x17e53(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cd65:	49 89 c5             	mov    %rax,%r13
    cd68:	48 2b 05 21 7e 01 00 	sub    0x17e21(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cd6f:	48 c1 e2 10          	shl    $0x10,%rdx
    cd73:	48 39 d0             	cmp    %rdx,%rax
    cd76:	73 59                	jae    cdd1 <f0+0x2201>
    cd78:	48 89 c2             	mov    %rax,%rdx
    cd7b:	48 c1 ea 10          	shr    $0x10,%rdx
    cd7f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd83:	48 8b 15 4e 7e 01 00 	mov    0x17e4e(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cd8a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd8e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd92:	4d 85 e4             	test   %r12,%r12
    cd95:	74 3a                	je     cdd1 <f0+0x2201>
    cd97:	0f b6 0a             	movzbl (%rdx),%ecx
    cd9a:	80 f9 02             	cmp    $0x2,%cl
    cd9d:	0f 84 cd 08 00 00    	je     d670 <f0+0x2aa0>
    cda3:	80 f9 01             	cmp    $0x1,%cl
    cda6:	75 29                	jne    cdd1 <f0+0x2201>
    cda8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cdab:	0f b7 c0             	movzwl %ax,%eax
    cdae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cdb1:	48 0f af c1          	imul   %rcx,%rax
    cdb5:	48 c1 e8 20          	shr    $0x20,%rax
    cdb9:	48 39 d0             	cmp    %rdx,%rax
    cdbc:	73 13                	jae    cdd1 <f0+0x2201>
    cdbe:	49 01 c4             	add    %rax,%r12
    cdc1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cdc6:	0f 84 7b 0a 00 00    	je     d847 <f0+0x2c77>
    cdcc:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cdd1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cdd8:	00 f0 3f 
    cddb:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    cde2:	00 
    cde3:	bf 01 00 00 00       	mov    $0x1,%edi
    cde8:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    cdef:	00 
    cdf0:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    cdf7:	00 
    cdf8:	e8 13 90 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    cdfd:	48 8b 15 b4 7d 01 00 	mov    0x17db4(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    ce04:	49 89 c5             	mov    %rax,%r13
    ce07:	48 2b 05 82 7d 01 00 	sub    0x17d82(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ce0e:	48 c1 e2 10          	shl    $0x10,%rdx
    ce12:	48 39 d0             	cmp    %rdx,%rax
    ce15:	73 59                	jae    ce70 <f0+0x22a0>
    ce17:	48 89 c2             	mov    %rax,%rdx
    ce1a:	48 c1 ea 10          	shr    $0x10,%rdx
    ce1e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce22:	48 8b 15 af 7d 01 00 	mov    0x17daf(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    ce29:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce2d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce31:	4d 85 e4             	test   %r12,%r12
    ce34:	74 3a                	je     ce70 <f0+0x22a0>
    ce36:	0f b6 0a             	movzbl (%rdx),%ecx
    ce39:	80 f9 02             	cmp    $0x2,%cl
    ce3c:	0f 84 1e 08 00 00    	je     d660 <f0+0x2a90>
    ce42:	80 f9 01             	cmp    $0x1,%cl
    ce45:	75 29                	jne    ce70 <f0+0x22a0>
    ce47:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce4a:	0f b7 c0             	movzwl %ax,%eax
    ce4d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce50:	48 0f af c1          	imul   %rcx,%rax
    ce54:	48 c1 e8 20          	shr    $0x20,%rax
    ce58:	48 39 d0             	cmp    %rdx,%rax
    ce5b:	73 13                	jae    ce70 <f0+0x22a0>
    ce5d:	49 01 c4             	add    %rax,%r12
    ce60:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce65:	0f 84 e9 09 00 00    	je     d854 <f0+0x2c84>
    ce6b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce70:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ce77:	33 f3 bf 
    ce7a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    ce81:	00 
    ce82:	bf 01 00 00 00       	mov    $0x1,%edi
    ce87:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    ce8e:	00 
    ce8f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    ce96:	00 
    ce97:	e8 74 8f ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    ce9c:	48 8b 15 15 7d 01 00 	mov    0x17d15(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cea3:	49 89 c5             	mov    %rax,%r13
    cea6:	48 2b 05 e3 7c 01 00 	sub    0x17ce3(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cead:	48 c1 e2 10          	shl    $0x10,%rdx
    ceb1:	48 39 d0             	cmp    %rdx,%rax
    ceb4:	73 59                	jae    cf0f <f0+0x233f>
    ceb6:	48 89 c2             	mov    %rax,%rdx
    ceb9:	48 c1 ea 10          	shr    $0x10,%rdx
    cebd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cec1:	48 8b 15 10 7d 01 00 	mov    0x17d10(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cec8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cecc:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ced0:	4d 85 e4             	test   %r12,%r12
    ced3:	74 3a                	je     cf0f <f0+0x233f>
    ced5:	0f b6 0a             	movzbl (%rdx),%ecx
    ced8:	80 f9 02             	cmp    $0x2,%cl
    cedb:	0f 84 6f 07 00 00    	je     d650 <f0+0x2a80>
    cee1:	80 f9 01             	cmp    $0x1,%cl
    cee4:	75 29                	jne    cf0f <f0+0x233f>
    cee6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cee9:	0f b7 c0             	movzwl %ax,%eax
    ceec:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ceef:	48 0f af c1          	imul   %rcx,%rax
    cef3:	48 c1 e8 20          	shr    $0x20,%rax
    cef7:	48 39 d0             	cmp    %rdx,%rax
    cefa:	73 13                	jae    cf0f <f0+0x233f>
    cefc:	49 01 c4             	add    %rax,%r12
    ceff:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf04:	0f 84 57 09 00 00    	je     d861 <f0+0x2c91>
    cf0a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf0f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cf16:	00 f0 3f 
    cf19:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    cf20:	00 
    cf21:	bf 01 00 00 00       	mov    $0x1,%edi
    cf26:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    cf2d:	00 
    cf2e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    cf35:	00 
    cf36:	e8 d5 8e ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    cf3b:	48 8b 15 76 7c 01 00 	mov    0x17c76(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cf42:	49 89 c5             	mov    %rax,%r13
    cf45:	48 2b 05 44 7c 01 00 	sub    0x17c44(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cf4c:	48 c1 e2 10          	shl    $0x10,%rdx
    cf50:	48 39 d0             	cmp    %rdx,%rax
    cf53:	73 59                	jae    cfae <f0+0x23de>
    cf55:	48 89 c2             	mov    %rax,%rdx
    cf58:	48 c1 ea 10          	shr    $0x10,%rdx
    cf5c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf60:	48 8b 15 71 7c 01 00 	mov    0x17c71(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cf67:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf6b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf6f:	4d 85 e4             	test   %r12,%r12
    cf72:	74 3a                	je     cfae <f0+0x23de>
    cf74:	0f b6 0a             	movzbl (%rdx),%ecx
    cf77:	80 f9 02             	cmp    $0x2,%cl
    cf7a:	0f 84 c0 06 00 00    	je     d640 <f0+0x2a70>
    cf80:	80 f9 01             	cmp    $0x1,%cl
    cf83:	75 29                	jne    cfae <f0+0x23de>
    cf85:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf88:	0f b7 c0             	movzwl %ax,%eax
    cf8b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf8e:	48 0f af c1          	imul   %rcx,%rax
    cf92:	48 c1 e8 20          	shr    $0x20,%rax
    cf96:	48 39 d0             	cmp    %rdx,%rax
    cf99:	73 13                	jae    cfae <f0+0x23de>
    cf9b:	49 01 c4             	add    %rax,%r12
    cf9e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cfa3:	0f 84 c5 08 00 00    	je     d86e <f0+0x2c9e>
    cfa9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cfae:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cfb5:	33 f3 bf 
    cfb8:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    cfbf:	00 
    cfc0:	bf 01 00 00 00       	mov    $0x1,%edi
    cfc5:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    cfcc:	00 
    cfcd:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    cfd4:	00 
    cfd5:	e8 36 8e ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    cfda:	48 8b 15 d7 7b 01 00 	mov    0x17bd7(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cfe1:	49 89 c5             	mov    %rax,%r13
    cfe4:	48 2b 05 a5 7b 01 00 	sub    0x17ba5(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cfeb:	48 c1 e2 10          	shl    $0x10,%rdx
    cfef:	48 39 d0             	cmp    %rdx,%rax
    cff2:	73 59                	jae    d04d <f0+0x247d>
    cff4:	48 89 c2             	mov    %rax,%rdx
    cff7:	48 c1 ea 10          	shr    $0x10,%rdx
    cffb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cfff:	48 8b 15 d2 7b 01 00 	mov    0x17bd2(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d006:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d00a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d00e:	4d 85 e4             	test   %r12,%r12
    d011:	74 3a                	je     d04d <f0+0x247d>
    d013:	0f b6 0a             	movzbl (%rdx),%ecx
    d016:	80 f9 02             	cmp    $0x2,%cl
    d019:	0f 84 11 06 00 00    	je     d630 <f0+0x2a60>
    d01f:	80 f9 01             	cmp    $0x1,%cl
    d022:	75 29                	jne    d04d <f0+0x247d>
    d024:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d027:	0f b7 c0             	movzwl %ax,%eax
    d02a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d02d:	48 0f af c1          	imul   %rcx,%rax
    d031:	48 c1 e8 20          	shr    $0x20,%rax
    d035:	48 39 d0             	cmp    %rdx,%rax
    d038:	73 13                	jae    d04d <f0+0x247d>
    d03a:	49 01 c4             	add    %rax,%r12
    d03d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d042:	0f 84 33 08 00 00    	je     d87b <f0+0x2cab>
    d048:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d04d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d054:	00 f0 3f 
    d057:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    d05e:	00 
    d05f:	bf 01 00 00 00       	mov    $0x1,%edi
    d064:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    d06b:	00 
    d06c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    d073:	00 
    d074:	e8 97 8d ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    d079:	48 8b 15 38 7b 01 00 	mov    0x17b38(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d080:	49 89 c5             	mov    %rax,%r13
    d083:	48 2b 05 06 7b 01 00 	sub    0x17b06(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d08a:	48 c1 e2 10          	shl    $0x10,%rdx
    d08e:	48 39 d0             	cmp    %rdx,%rax
    d091:	73 59                	jae    d0ec <f0+0x251c>
    d093:	48 89 c2             	mov    %rax,%rdx
    d096:	48 c1 ea 10          	shr    $0x10,%rdx
    d09a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d09e:	48 8b 15 33 7b 01 00 	mov    0x17b33(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d0a5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d0a9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d0ad:	4d 85 e4             	test   %r12,%r12
    d0b0:	74 3a                	je     d0ec <f0+0x251c>
    d0b2:	0f b6 0a             	movzbl (%rdx),%ecx
    d0b5:	80 f9 02             	cmp    $0x2,%cl
    d0b8:	0f 84 62 05 00 00    	je     d620 <f0+0x2a50>
    d0be:	80 f9 01             	cmp    $0x1,%cl
    d0c1:	75 29                	jne    d0ec <f0+0x251c>
    d0c3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d0c6:	0f b7 c0             	movzwl %ax,%eax
    d0c9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d0cc:	48 0f af c1          	imul   %rcx,%rax
    d0d0:	48 c1 e8 20          	shr    $0x20,%rax
    d0d4:	48 39 d0             	cmp    %rdx,%rax
    d0d7:	73 13                	jae    d0ec <f0+0x251c>
    d0d9:	49 01 c4             	add    %rax,%r12
    d0dc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d0e1:	0f 84 a1 07 00 00    	je     d888 <f0+0x2cb8>
    d0e7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0ec:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d0f3:	33 f3 bf 
    d0f6:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    d0fd:	00 
    d0fe:	bf 01 00 00 00       	mov    $0x1,%edi
    d103:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    d10a:	00 
    d10b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    d112:	00 
    d113:	e8 f8 8c ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    d118:	48 8b 15 99 7a 01 00 	mov    0x17a99(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d11f:	49 89 c5             	mov    %rax,%r13
    d122:	48 2b 05 67 7a 01 00 	sub    0x17a67(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d129:	48 c1 e2 10          	shl    $0x10,%rdx
    d12d:	48 39 d0             	cmp    %rdx,%rax
    d130:	73 59                	jae    d18b <f0+0x25bb>
    d132:	48 89 c2             	mov    %rax,%rdx
    d135:	48 c1 ea 10          	shr    $0x10,%rdx
    d139:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d13d:	48 8b 15 94 7a 01 00 	mov    0x17a94(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d144:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d148:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d14c:	4d 85 e4             	test   %r12,%r12
    d14f:	74 3a                	je     d18b <f0+0x25bb>
    d151:	0f b6 0a             	movzbl (%rdx),%ecx
    d154:	80 f9 02             	cmp    $0x2,%cl
    d157:	0f 84 b3 04 00 00    	je     d610 <f0+0x2a40>
    d15d:	80 f9 01             	cmp    $0x1,%cl
    d160:	75 29                	jne    d18b <f0+0x25bb>
    d162:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d165:	0f b7 c0             	movzwl %ax,%eax
    d168:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d16b:	48 0f af c1          	imul   %rcx,%rax
    d16f:	48 c1 e8 20          	shr    $0x20,%rax
    d173:	48 39 d0             	cmp    %rdx,%rax
    d176:	73 13                	jae    d18b <f0+0x25bb>
    d178:	49 01 c4             	add    %rax,%r12
    d17b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d180:	0f 84 0f 07 00 00    	je     d895 <f0+0x2cc5>
    d186:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d18b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d192:	00 f0 3f 
    d195:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    d19c:	00 
    d19d:	bf 01 00 00 00       	mov    $0x1,%edi
    d1a2:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    d1a9:	00 
    d1aa:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    d1b1:	00 
    d1b2:	e8 59 8c ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    d1b7:	48 8b 15 fa 79 01 00 	mov    0x179fa(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d1be:	49 89 c5             	mov    %rax,%r13
    d1c1:	48 2b 05 c8 79 01 00 	sub    0x179c8(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d1c8:	48 c1 e2 10          	shl    $0x10,%rdx
    d1cc:	48 39 d0             	cmp    %rdx,%rax
    d1cf:	73 59                	jae    d22a <f0+0x265a>
    d1d1:	48 89 c2             	mov    %rax,%rdx
    d1d4:	48 c1 ea 10          	shr    $0x10,%rdx
    d1d8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d1dc:	48 8b 15 f5 79 01 00 	mov    0x179f5(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d1e3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d1e7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d1eb:	4d 85 e4             	test   %r12,%r12
    d1ee:	74 3a                	je     d22a <f0+0x265a>
    d1f0:	0f b6 0a             	movzbl (%rdx),%ecx
    d1f3:	80 f9 02             	cmp    $0x2,%cl
    d1f6:	0f 84 04 04 00 00    	je     d600 <f0+0x2a30>
    d1fc:	80 f9 01             	cmp    $0x1,%cl
    d1ff:	75 29                	jne    d22a <f0+0x265a>
    d201:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d204:	0f b7 c0             	movzwl %ax,%eax
    d207:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d20a:	48 0f af c1          	imul   %rcx,%rax
    d20e:	48 c1 e8 20          	shr    $0x20,%rax
    d212:	48 39 d0             	cmp    %rdx,%rax
    d215:	73 13                	jae    d22a <f0+0x265a>
    d217:	49 01 c4             	add    %rax,%r12
    d21a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d21f:	0f 84 7d 06 00 00    	je     d8a2 <f0+0x2cd2>
    d225:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d22a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d231:	33 f3 bf 
    d234:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    d23b:	00 
    d23c:	bf 01 00 00 00       	mov    $0x1,%edi
    d241:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    d248:	00 
    d249:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    d250:	00 
    d251:	e8 ba 8b ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    d256:	48 8b 15 5b 79 01 00 	mov    0x1795b(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d25d:	49 89 c5             	mov    %rax,%r13
    d260:	48 2b 05 29 79 01 00 	sub    0x17929(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d267:	48 c1 e2 10          	shl    $0x10,%rdx
    d26b:	48 39 d0             	cmp    %rdx,%rax
    d26e:	73 59                	jae    d2c9 <f0+0x26f9>
    d270:	48 89 c2             	mov    %rax,%rdx
    d273:	48 c1 ea 10          	shr    $0x10,%rdx
    d277:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d27b:	48 8b 15 56 79 01 00 	mov    0x17956(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d282:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d286:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d28a:	4d 85 e4             	test   %r12,%r12
    d28d:	74 3a                	je     d2c9 <f0+0x26f9>
    d28f:	0f b6 0a             	movzbl (%rdx),%ecx
    d292:	80 f9 02             	cmp    $0x2,%cl
    d295:	0f 84 55 03 00 00    	je     d5f0 <f0+0x2a20>
    d29b:	80 f9 01             	cmp    $0x1,%cl
    d29e:	75 29                	jne    d2c9 <f0+0x26f9>
    d2a0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2a3:	0f b7 c0             	movzwl %ax,%eax
    d2a6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d2a9:	48 0f af c1          	imul   %rcx,%rax
    d2ad:	48 c1 e8 20          	shr    $0x20,%rax
    d2b1:	48 39 d0             	cmp    %rdx,%rax
    d2b4:	73 13                	jae    d2c9 <f0+0x26f9>
    d2b6:	49 01 c4             	add    %rax,%r12
    d2b9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d2be:	0f 84 eb 05 00 00    	je     d8af <f0+0x2cdf>
    d2c4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d2c9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d2d0:	00 f0 3f 
    d2d3:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    d2da:	00 
    d2db:	bf 01 00 00 00       	mov    $0x1,%edi
    d2e0:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    d2e7:	00 
    d2e8:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    d2ef:	00 
    d2f0:	e8 1b 8b ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    d2f5:	48 8b 15 bc 78 01 00 	mov    0x178bc(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d2fc:	49 89 c5             	mov    %rax,%r13
    d2ff:	48 2b 05 8a 78 01 00 	sub    0x1788a(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d306:	48 c1 e2 10          	shl    $0x10,%rdx
    d30a:	48 39 d0             	cmp    %rdx,%rax
    d30d:	73 59                	jae    d368 <f0+0x2798>
    d30f:	48 89 c2             	mov    %rax,%rdx
    d312:	48 c1 ea 10          	shr    $0x10,%rdx
    d316:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d31a:	48 8b 15 b7 78 01 00 	mov    0x178b7(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d321:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d325:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d329:	4d 85 e4             	test   %r12,%r12
    d32c:	74 3a                	je     d368 <f0+0x2798>
    d32e:	0f b6 0a             	movzbl (%rdx),%ecx
    d331:	80 f9 02             	cmp    $0x2,%cl
    d334:	0f 84 a6 02 00 00    	je     d5e0 <f0+0x2a10>
    d33a:	80 f9 01             	cmp    $0x1,%cl
    d33d:	75 29                	jne    d368 <f0+0x2798>
    d33f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d342:	0f b7 c0             	movzwl %ax,%eax
    d345:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d348:	48 0f af c1          	imul   %rcx,%rax
    d34c:	48 c1 e8 20          	shr    $0x20,%rax
    d350:	48 39 d0             	cmp    %rdx,%rax
    d353:	73 13                	jae    d368 <f0+0x2798>
    d355:	49 01 c4             	add    %rax,%r12
    d358:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d35d:	0f 84 59 05 00 00    	je     d8bc <f0+0x2cec>
    d363:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d368:	48 89 ee             	mov    %rbp,%rsi
    d36b:	bf 01 00 00 00       	mov    $0x1,%edi
    d370:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d377:	33 f3 bf 
    d37a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    d381:	00 
    d382:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    d389:	00 
    d38a:	e8 81 8a ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    d38f:	48 8b 15 22 78 01 00 	mov    0x17822(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d396:	48 89 c5             	mov    %rax,%rbp
    d399:	48 2b 05 f0 77 01 00 	sub    0x177f0(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d3a0:	48 c1 e2 10          	shl    $0x10,%rdx
    d3a4:	48 39 d0             	cmp    %rdx,%rax
    d3a7:	73 59                	jae    d402 <f0+0x2832>
    d3a9:	48 89 c2             	mov    %rax,%rdx
    d3ac:	48 c1 ea 10          	shr    $0x10,%rdx
    d3b0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d3b4:	48 8b 15 1d 78 01 00 	mov    0x1781d(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d3bb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d3bf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d3c3:	4d 85 e4             	test   %r12,%r12
    d3c6:	74 3a                	je     d402 <f0+0x2832>
    d3c8:	0f b6 0a             	movzbl (%rdx),%ecx
    d3cb:	80 f9 02             	cmp    $0x2,%cl
    d3ce:	0f 84 fc 01 00 00    	je     d5d0 <f0+0x2a00>
    d3d4:	80 f9 01             	cmp    $0x1,%cl
    d3d7:	75 29                	jne    d402 <f0+0x2832>
    d3d9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d3dc:	0f b7 c0             	movzwl %ax,%eax
    d3df:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d3e2:	48 0f af c1          	imul   %rcx,%rax
    d3e6:	48 c1 e8 20          	shr    $0x20,%rax
    d3ea:	48 39 d0             	cmp    %rdx,%rax
    d3ed:	73 13                	jae    d402 <f0+0x2832>
    d3ef:	49 01 c4             	add    %rax,%r12
    d3f2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d3f7:	0f 84 d1 02 00 00    	je     d6ce <f0+0x2afe>
    d3fd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d402:	48 89 de             	mov    %rbx,%rsi
    d405:	48 89 ef             	mov    %rbp,%rdi
    d408:	e8 13 bf ff ff       	call   9320 <fwp_hof0.constprop.0>
    d40d:	48 89 ef             	mov    %rbp,%rdi
    d410:	e8 8b a3 ff ff       	call   77a0 <fwp_drop0>
    d415:	48 89 df             	mov    %rbx,%rdi
    d418:	e8 83 a3 ff ff       	call   77a0 <fwp_drop0>
    d41d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    d424:	00 
    d425:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    d42c:	00 00 
    d42e:	0f 85 95 04 00 00    	jne    d8c9 <f0+0x2cf9>
    d434:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    d43b:	31 c0                	xor    %eax,%eax
    d43d:	5b                   	pop    %rbx
    d43e:	5d                   	pop    %rbp
    d43f:	41 5c                	pop    %r12
    d441:	41 5d                	pop    %r13
    d443:	41 5e                	pop    %r14
    d445:	c3                   	ret
    d446:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    d44d:	00 00 00 
    d450:	4c 89 ef             	mov    %r13,%rdi
    d453:	e8 58 81 ff ff       	call   55b0 <fwp_rc_forget_slot>
    d458:	e9 2c d8 ff ff       	jmp    ac89 <f0+0xb9>
    d45d:	0f 1f 00             	nopl   (%rax)
    d460:	66 85 c0             	test   %ax,%ax
    d463:	0f 85 ae f5 ff ff    	jne    ca17 <f0+0x1e47>
    d469:	e9 99 f5 ff ff       	jmp    ca07 <f0+0x1e37>
    d46e:	66 90                	xchg   %ax,%ax
    d470:	66 85 c0             	test   %ax,%ax
    d473:	0f 85 ff f4 ff ff    	jne    c978 <f0+0x1da8>
    d479:	e9 ea f4 ff ff       	jmp    c968 <f0+0x1d98>
    d47e:	66 90                	xchg   %ax,%ax
    d480:	66 85 c0             	test   %ax,%ax
    d483:	0f 85 50 f4 ff ff    	jne    c8d9 <f0+0x1d09>
    d489:	e9 3b f4 ff ff       	jmp    c8c9 <f0+0x1cf9>
    d48e:	66 90                	xchg   %ax,%ax
    d490:	66 85 c0             	test   %ax,%ax
    d493:	0f 85 a1 f3 ff ff    	jne    c83a <f0+0x1c6a>
    d499:	e9 8c f3 ff ff       	jmp    c82a <f0+0x1c5a>
    d49e:	66 90                	xchg   %ax,%ax
    d4a0:	66 85 c0             	test   %ax,%ax
    d4a3:	0f 85 f2 f2 ff ff    	jne    c79b <f0+0x1bcb>
    d4a9:	e9 dd f2 ff ff       	jmp    c78b <f0+0x1bbb>
    d4ae:	66 90                	xchg   %ax,%ax
    d4b0:	66 85 c0             	test   %ax,%ax
    d4b3:	0f 85 43 f2 ff ff    	jne    c6fc <f0+0x1b2c>
    d4b9:	e9 2e f2 ff ff       	jmp    c6ec <f0+0x1b1c>
    d4be:	66 90                	xchg   %ax,%ax
    d4c0:	66 85 c0             	test   %ax,%ax
    d4c3:	0f 85 94 f1 ff ff    	jne    c65d <f0+0x1a8d>
    d4c9:	e9 7f f1 ff ff       	jmp    c64d <f0+0x1a7d>
    d4ce:	66 90                	xchg   %ax,%ax
    d4d0:	66 85 c0             	test   %ax,%ax
    d4d3:	0f 85 e5 f0 ff ff    	jne    c5be <f0+0x19ee>
    d4d9:	e9 d0 f0 ff ff       	jmp    c5ae <f0+0x19de>
    d4de:	66 90                	xchg   %ax,%ax
    d4e0:	66 85 c0             	test   %ax,%ax
    d4e3:	0f 85 fd d9 ff ff    	jne    aee6 <f0+0x316>
    d4e9:	e9 e8 d9 ff ff       	jmp    aed6 <f0+0x306>
    d4ee:	66 90                	xchg   %ax,%ax
    d4f0:	66 85 c0             	test   %ax,%ax
    d4f3:	0f 85 57 d9 ff ff    	jne    ae50 <f0+0x280>
    d4f9:	e9 42 d9 ff ff       	jmp    ae40 <f0+0x270>
    d4fe:	66 90                	xchg   %ax,%ax
    d500:	66 85 c0             	test   %ax,%ax
    d503:	0f 85 b1 d8 ff ff    	jne    adba <f0+0x1ea>
    d509:	e9 9c d8 ff ff       	jmp    adaa <f0+0x1da>
    d50e:	66 90                	xchg   %ax,%ax
    d510:	66 85 c0             	test   %ax,%ax
    d513:	0f 85 0e eb ff ff    	jne    c027 <f0+0x1457>
    d519:	e9 f9 ea ff ff       	jmp    c017 <f0+0x1447>
    d51e:	66 90                	xchg   %ax,%ax
    d520:	66 85 c0             	test   %ax,%ax
    d523:	0f 85 5f ea ff ff    	jne    bf88 <f0+0x13b8>
    d529:	e9 4a ea ff ff       	jmp    bf78 <f0+0x13a8>
    d52e:	66 90                	xchg   %ax,%ax
    d530:	66 85 c0             	test   %ax,%ax
    d533:	0f 85 e2 da ff ff    	jne    b01b <f0+0x44b>
    d539:	e9 cd da ff ff       	jmp    b00b <f0+0x43b>
    d53e:	66 90                	xchg   %ax,%ax
    d540:	66 85 c0             	test   %ax,%ax
    d543:	0f 85 33 da ff ff    	jne    af7c <f0+0x3ac>
    d549:	e9 1e da ff ff       	jmp    af6c <f0+0x39c>
    d54e:	66 90                	xchg   %ax,%ax
    d550:	66 85 c0             	test   %ax,%ax
    d553:	0f 85 c6 ef ff ff    	jne    c51f <f0+0x194f>
    d559:	e9 b1 ef ff ff       	jmp    c50f <f0+0x193f>
    d55e:	66 90                	xchg   %ax,%ax
    d560:	66 85 c0             	test   %ax,%ax
    d563:	0f 85 17 ef ff ff    	jne    c480 <f0+0x18b0>
    d569:	e9 02 ef ff ff       	jmp    c470 <f0+0x18a0>
    d56e:	66 90                	xchg   %ax,%ax
    d570:	66 85 c0             	test   %ax,%ax
    d573:	0f 85 68 ee ff ff    	jne    c3e1 <f0+0x1811>
    d579:	e9 53 ee ff ff       	jmp    c3d1 <f0+0x1801>
    d57e:	66 90                	xchg   %ax,%ax
    d580:	66 85 c0             	test   %ax,%ax
    d583:	0f 85 b9 ed ff ff    	jne    c342 <f0+0x1772>
    d589:	e9 a4 ed ff ff       	jmp    c332 <f0+0x1762>
    d58e:	66 90                	xchg   %ax,%ax
    d590:	66 85 c0             	test   %ax,%ax
    d593:	0f 85 0a ed ff ff    	jne    c2a3 <f0+0x16d3>
    d599:	e9 f5 ec ff ff       	jmp    c293 <f0+0x16c3>
    d59e:	66 90                	xchg   %ax,%ax
    d5a0:	66 85 c0             	test   %ax,%ax
    d5a3:	0f 85 5b ec ff ff    	jne    c204 <f0+0x1634>
    d5a9:	e9 46 ec ff ff       	jmp    c1f4 <f0+0x1624>
    d5ae:	66 90                	xchg   %ax,%ax
    d5b0:	66 85 c0             	test   %ax,%ax
    d5b3:	0f 85 ac eb ff ff    	jne    c165 <f0+0x1595>
    d5b9:	e9 97 eb ff ff       	jmp    c155 <f0+0x1585>
    d5be:	66 90                	xchg   %ax,%ax
    d5c0:	66 85 c0             	test   %ax,%ax
    d5c3:	0f 85 fd ea ff ff    	jne    c0c6 <f0+0x14f6>
    d5c9:	e9 e8 ea ff ff       	jmp    c0b6 <f0+0x14e6>
    d5ce:	66 90                	xchg   %ax,%ax
    d5d0:	66 85 c0             	test   %ax,%ax
    d5d3:	0f 85 29 fe ff ff    	jne    d402 <f0+0x2832>
    d5d9:	e9 14 fe ff ff       	jmp    d3f2 <f0+0x2822>
    d5de:	66 90                	xchg   %ax,%ax
    d5e0:	66 85 c0             	test   %ax,%ax
    d5e3:	0f 85 7f fd ff ff    	jne    d368 <f0+0x2798>
    d5e9:	e9 6a fd ff ff       	jmp    d358 <f0+0x2788>
    d5ee:	66 90                	xchg   %ax,%ax
    d5f0:	66 85 c0             	test   %ax,%ax
    d5f3:	0f 85 d0 fc ff ff    	jne    d2c9 <f0+0x26f9>
    d5f9:	e9 bb fc ff ff       	jmp    d2b9 <f0+0x26e9>
    d5fe:	66 90                	xchg   %ax,%ax
    d600:	66 85 c0             	test   %ax,%ax
    d603:	0f 85 21 fc ff ff    	jne    d22a <f0+0x265a>
    d609:	e9 0c fc ff ff       	jmp    d21a <f0+0x264a>
    d60e:	66 90                	xchg   %ax,%ax
    d610:	66 85 c0             	test   %ax,%ax
    d613:	0f 85 72 fb ff ff    	jne    d18b <f0+0x25bb>
    d619:	e9 5d fb ff ff       	jmp    d17b <f0+0x25ab>
    d61e:	66 90                	xchg   %ax,%ax
    d620:	66 85 c0             	test   %ax,%ax
    d623:	0f 85 c3 fa ff ff    	jne    d0ec <f0+0x251c>
    d629:	e9 ae fa ff ff       	jmp    d0dc <f0+0x250c>
    d62e:	66 90                	xchg   %ax,%ax
    d630:	66 85 c0             	test   %ax,%ax
    d633:	0f 85 14 fa ff ff    	jne    d04d <f0+0x247d>
    d639:	e9 ff f9 ff ff       	jmp    d03d <f0+0x246d>
    d63e:	66 90                	xchg   %ax,%ax
    d640:	66 85 c0             	test   %ax,%ax
    d643:	0f 85 65 f9 ff ff    	jne    cfae <f0+0x23de>
    d649:	e9 50 f9 ff ff       	jmp    cf9e <f0+0x23ce>
    d64e:	66 90                	xchg   %ax,%ax
    d650:	66 85 c0             	test   %ax,%ax
    d653:	0f 85 b6 f8 ff ff    	jne    cf0f <f0+0x233f>
    d659:	e9 a1 f8 ff ff       	jmp    ceff <f0+0x232f>
    d65e:	66 90                	xchg   %ax,%ax
    d660:	66 85 c0             	test   %ax,%ax
    d663:	0f 85 07 f8 ff ff    	jne    ce70 <f0+0x22a0>
    d669:	e9 f2 f7 ff ff       	jmp    ce60 <f0+0x2290>
    d66e:	66 90                	xchg   %ax,%ax
    d670:	66 85 c0             	test   %ax,%ax
    d673:	0f 85 58 f7 ff ff    	jne    cdd1 <f0+0x2201>
    d679:	e9 43 f7 ff ff       	jmp    cdc1 <f0+0x21f1>
    d67e:	66 90                	xchg   %ax,%ax
    d680:	66 85 c0             	test   %ax,%ax
    d683:	0f 85 a9 f6 ff ff    	jne    cd32 <f0+0x2162>
    d689:	e9 94 f6 ff ff       	jmp    cd22 <f0+0x2152>
    d68e:	66 90                	xchg   %ax,%ax
    d690:	66 85 c0             	test   %ax,%ax
    d693:	0f 85 fa f5 ff ff    	jne    cc93 <f0+0x20c3>
    d699:	e9 e5 f5 ff ff       	jmp    cc83 <f0+0x20b3>
    d69e:	66 90                	xchg   %ax,%ax
    d6a0:	66 85 c0             	test   %ax,%ax
    d6a3:	0f 85 4b f5 ff ff    	jne    cbf4 <f0+0x2024>
    d6a9:	e9 36 f5 ff ff       	jmp    cbe4 <f0+0x2014>
    d6ae:	66 90                	xchg   %ax,%ax
    d6b0:	66 85 c0             	test   %ax,%ax
    d6b3:	0f 85 9c f4 ff ff    	jne    cb55 <f0+0x1f85>
    d6b9:	e9 87 f4 ff ff       	jmp    cb45 <f0+0x1f75>
    d6be:	66 90                	xchg   %ax,%ax
    d6c0:	66 85 c0             	test   %ax,%ax
    d6c3:	0f 85 ed f3 ff ff    	jne    cab6 <f0+0x1ee6>
    d6c9:	e9 d8 f3 ff ff       	jmp    caa6 <f0+0x1ed6>
    d6ce:	4c 89 e7             	mov    %r12,%rdi
    d6d1:	e8 da 7e ff ff       	call   55b0 <fwp_rc_forget_slot>
    d6d6:	e9 22 fd ff ff       	jmp    d3fd <f0+0x282d>
    d6db:	4c 89 e7             	mov    %r12,%rdi
    d6de:	e8 cd 7e ff ff       	call   55b0 <fwp_rc_forget_slot>
    d6e3:	e9 cd d6 ff ff       	jmp    adb5 <f0+0x1e5>
    d6e8:	4c 89 e7             	mov    %r12,%rdi
    d6eb:	e8 c0 7e ff ff       	call   55b0 <fwp_rc_forget_slot>
    d6f0:	e9 56 d7 ff ff       	jmp    ae4b <f0+0x27b>
    d6f5:	4c 89 e7             	mov    %r12,%rdi
    d6f8:	e8 b3 7e ff ff       	call   55b0 <fwp_rc_forget_slot>
    d6fd:	e9 df d7 ff ff       	jmp    aee1 <f0+0x311>
    d702:	4c 89 e7             	mov    %r12,%rdi
    d705:	e8 a6 7e ff ff       	call   55b0 <fwp_rc_forget_slot>
    d70a:	e9 68 d8 ff ff       	jmp    af77 <f0+0x3a7>
    d70f:	4c 89 e7             	mov    %r12,%rdi
    d712:	e8 99 7e ff ff       	call   55b0 <fwp_rc_forget_slot>
    d717:	e9 fa d8 ff ff       	jmp    b016 <f0+0x446>
    d71c:	4c 89 e7             	mov    %r12,%rdi
    d71f:	e8 8c 7e ff ff       	call   55b0 <fwp_rc_forget_slot>
    d724:	e9 5a e8 ff ff       	jmp    bf83 <f0+0x13b3>
    d729:	4c 89 e7             	mov    %r12,%rdi
    d72c:	e8 7f 7e ff ff       	call   55b0 <fwp_rc_forget_slot>
    d731:	e9 ec e8 ff ff       	jmp    c022 <f0+0x1452>
    d736:	4c 89 e7             	mov    %r12,%rdi
    d739:	e8 72 7e ff ff       	call   55b0 <fwp_rc_forget_slot>
    d73e:	e9 7e e9 ff ff       	jmp    c0c1 <f0+0x14f1>
    d743:	4c 89 e7             	mov    %r12,%rdi
    d746:	e8 65 7e ff ff       	call   55b0 <fwp_rc_forget_slot>
    d74b:	e9 10 ea ff ff       	jmp    c160 <f0+0x1590>
    d750:	4c 89 e7             	mov    %r12,%rdi
    d753:	e8 58 7e ff ff       	call   55b0 <fwp_rc_forget_slot>
    d758:	e9 a2 ea ff ff       	jmp    c1ff <f0+0x162f>
    d75d:	4c 89 e7             	mov    %r12,%rdi
    d760:	e8 4b 7e ff ff       	call   55b0 <fwp_rc_forget_slot>
    d765:	e9 34 eb ff ff       	jmp    c29e <f0+0x16ce>
    d76a:	4c 89 e7             	mov    %r12,%rdi
    d76d:	e8 3e 7e ff ff       	call   55b0 <fwp_rc_forget_slot>
    d772:	e9 c6 eb ff ff       	jmp    c33d <f0+0x176d>
    d777:	4c 89 e7             	mov    %r12,%rdi
    d77a:	e8 31 7e ff ff       	call   55b0 <fwp_rc_forget_slot>
    d77f:	e9 58 ec ff ff       	jmp    c3dc <f0+0x180c>
    d784:	4c 89 e7             	mov    %r12,%rdi
    d787:	e8 24 7e ff ff       	call   55b0 <fwp_rc_forget_slot>
    d78c:	e9 ea ec ff ff       	jmp    c47b <f0+0x18ab>
    d791:	4c 89 e7             	mov    %r12,%rdi
    d794:	e8 17 7e ff ff       	call   55b0 <fwp_rc_forget_slot>
    d799:	e9 7c ed ff ff       	jmp    c51a <f0+0x194a>
    d79e:	4c 89 e7             	mov    %r12,%rdi
    d7a1:	e8 0a 7e ff ff       	call   55b0 <fwp_rc_forget_slot>
    d7a6:	e9 0e ee ff ff       	jmp    c5b9 <f0+0x19e9>
    d7ab:	4c 89 e7             	mov    %r12,%rdi
    d7ae:	e8 fd 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d7b3:	e9 a0 ee ff ff       	jmp    c658 <f0+0x1a88>
    d7b8:	4c 89 e7             	mov    %r12,%rdi
    d7bb:	e8 f0 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d7c0:	e9 32 ef ff ff       	jmp    c6f7 <f0+0x1b27>
    d7c5:	4c 89 e7             	mov    %r12,%rdi
    d7c8:	e8 e3 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d7cd:	e9 c4 ef ff ff       	jmp    c796 <f0+0x1bc6>
    d7d2:	4c 89 e7             	mov    %r12,%rdi
    d7d5:	e8 d6 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d7da:	e9 56 f0 ff ff       	jmp    c835 <f0+0x1c65>
    d7df:	4c 89 e7             	mov    %r12,%rdi
    d7e2:	e8 c9 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d7e7:	e9 e8 f0 ff ff       	jmp    c8d4 <f0+0x1d04>
    d7ec:	4c 89 e7             	mov    %r12,%rdi
    d7ef:	e8 bc 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d7f4:	e9 7a f1 ff ff       	jmp    c973 <f0+0x1da3>
    d7f9:	4c 89 e7             	mov    %r12,%rdi
    d7fc:	e8 af 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d801:	e9 0c f2 ff ff       	jmp    ca12 <f0+0x1e42>
    d806:	4c 89 e7             	mov    %r12,%rdi
    d809:	e8 a2 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d80e:	e9 9e f2 ff ff       	jmp    cab1 <f0+0x1ee1>
    d813:	4c 89 e7             	mov    %r12,%rdi
    d816:	e8 95 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d81b:	e9 30 f3 ff ff       	jmp    cb50 <f0+0x1f80>
    d820:	4c 89 e7             	mov    %r12,%rdi
    d823:	e8 88 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d828:	e9 c2 f3 ff ff       	jmp    cbef <f0+0x201f>
    d82d:	4c 89 e7             	mov    %r12,%rdi
    d830:	e8 7b 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d835:	e9 54 f4 ff ff       	jmp    cc8e <f0+0x20be>
    d83a:	4c 89 e7             	mov    %r12,%rdi
    d83d:	e8 6e 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d842:	e9 e6 f4 ff ff       	jmp    cd2d <f0+0x215d>
    d847:	4c 89 e7             	mov    %r12,%rdi
    d84a:	e8 61 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d84f:	e9 78 f5 ff ff       	jmp    cdcc <f0+0x21fc>
    d854:	4c 89 e7             	mov    %r12,%rdi
    d857:	e8 54 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d85c:	e9 0a f6 ff ff       	jmp    ce6b <f0+0x229b>
    d861:	4c 89 e7             	mov    %r12,%rdi
    d864:	e8 47 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d869:	e9 9c f6 ff ff       	jmp    cf0a <f0+0x233a>
    d86e:	4c 89 e7             	mov    %r12,%rdi
    d871:	e8 3a 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d876:	e9 2e f7 ff ff       	jmp    cfa9 <f0+0x23d9>
    d87b:	4c 89 e7             	mov    %r12,%rdi
    d87e:	e8 2d 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d883:	e9 c0 f7 ff ff       	jmp    d048 <f0+0x2478>
    d888:	4c 89 e7             	mov    %r12,%rdi
    d88b:	e8 20 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d890:	e9 52 f8 ff ff       	jmp    d0e7 <f0+0x2517>
    d895:	4c 89 e7             	mov    %r12,%rdi
    d898:	e8 13 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d89d:	e9 e4 f8 ff ff       	jmp    d186 <f0+0x25b6>
    d8a2:	4c 89 e7             	mov    %r12,%rdi
    d8a5:	e8 06 7d ff ff       	call   55b0 <fwp_rc_forget_slot>
    d8aa:	e9 76 f9 ff ff       	jmp    d225 <f0+0x2655>
    d8af:	4c 89 e7             	mov    %r12,%rdi
    d8b2:	e8 f9 7c ff ff       	call   55b0 <fwp_rc_forget_slot>
    d8b7:	e9 08 fa ff ff       	jmp    d2c4 <f0+0x26f4>
    d8bc:	4c 89 e7             	mov    %r12,%rdi
    d8bf:	e8 ec 7c ff ff       	call   55b0 <fwp_rc_forget_slot>
    d8c4:	e9 9a fa ff ff       	jmp    d363 <f0+0x2793>
    d8c9:	e8 92 5b ff ff       	call   3460 <__stack_chk_fail@plt>
    d8ce:	66 90                	xchg   %ax,%ax

000000000000d8d0 <fwp_main_thread>:
    d8d0:	f3 0f 1e fa          	endbr64
    d8d4:	41 54                	push   %r12
    d8d6:	55                   	push   %rbp
    d8d7:	53                   	push   %rbx
    d8d8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    d8df:	8b 35 9f 72 01 00    	mov    0x1729f(%rip),%esi        # 24b84 <fwp_heap+0x13a4>
    d8e5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    d8ec:	00 00 
    d8ee:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    d8f5:	00 
    d8f6:	31 c0                	xor    %eax,%eax
    d8f8:	85 f6                	test   %esi,%esi
    d8fa:	0f 84 a8 06 00 00    	je     dfa8 <fwp_main_thread+0x6d8>
    d900:	8b 0d 82 72 01 00    	mov    0x17282(%rip),%ecx        # 24b88 <fwp_heap+0x13a8>
    d906:	85 c9                	test   %ecx,%ecx
    d908:	0f 85 82 06 00 00    	jne    df90 <fwp_main_thread+0x6c0>
    d90e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    d913:	31 f6                	xor    %esi,%esi
    d915:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    d91a:	48 c7 05 4b 58 01 00 	movq   $0x40000000,0x1584b(%rip)        # 23170 <fwp_main_stack_size>
    d921:	00 00 00 40 
    d925:	48 89 05 4c 58 01 00 	mov    %rax,0x1584c(%rip)        # 23178 <fwp_main_stack_top>
    d92c:	48 8d 05 6d 57 00 00 	lea    0x576d(%rip),%rax        # 130a0 <alt.9>
    d933:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    d938:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    d93f:	01 00 
    d941:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    d948:	00 
    d949:	e8 72 5d ff ff       	call   36c0 <sigaltstack@plt>
    d94e:	85 c0                	test   %eax,%eax
    d950:	0f 85 8a 06 00 00    	jne    dfe0 <fwp_main_thread+0x710>
    d956:	31 c0                	xor    %eax,%eax
    d958:	b9 12 00 00 00       	mov    $0x12,%ecx
    d95d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    d962:	f3 48 ab             	rep stos %rax,(%rdi)
    d965:	48 8d 05 84 63 ff ff 	lea    -0x9c7c(%rip),%rax        # 3cf0 <fwp_segv>
    d96c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    d971:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    d978:	04 00 00 08 
    d97c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    d981:	e8 fa 5b ff ff       	call   3580 <sigemptyset@plt>
    d986:	85 c0                	test   %eax,%eax
    d988:	0f 85 52 06 00 00    	jne    dfe0 <fwp_main_thread+0x710>
    d98e:	31 d2                	xor    %edx,%edx
    d990:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    d995:	bf 0b 00 00 00       	mov    $0xb,%edi
    d99a:	e8 61 5a ff ff       	call   3400 <sigaction@plt>
    d99f:	85 c0                	test   %eax,%eax
    d9a1:	0f 85 39 06 00 00    	jne    dfe0 <fwp_main_thread+0x710>
    d9a7:	31 d2                	xor    %edx,%edx
    d9a9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    d9ae:	bf 07 00 00 00       	mov    $0x7,%edi
    d9b3:	e8 48 5a ff ff       	call   3400 <sigaction@plt>
    d9b8:	85 c0                	test   %eax,%eax
    d9ba:	0f 85 20 06 00 00    	jne    dfe0 <fwp_main_thread+0x710>
    d9c0:	8b 15 52 57 01 00    	mov    0x15752(%rip),%edx        # 23118 <descent_registered>
    d9c6:	85 d2                	test   %edx,%edx
    d9c8:	0f 84 72 05 00 00    	je     df40 <fwp_main_thread+0x670>
    d9ce:	8b 05 b4 56 00 00    	mov    0x56b4(%rip),%eax        # 13088 <st.7>
    d9d4:	85 c0                	test   %eax,%eax
    d9d6:	0f 84 90 05 00 00    	je     df6c <fwp_main_thread+0x69c>
    d9dc:	48 8b 2d dd 5d 01 00 	mov    0x15ddd(%rip),%rbp        # 237c0 <fwp_cur>
    d9e3:	48 85 ed             	test   %rbp,%rbp
    d9e6:	0f 84 74 03 00 00    	je     dd60 <fwp_main_thread+0x490>
    d9ec:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    d9f1:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    d9f5:	48 89 eb             	mov    %rbp,%rbx
    d9f8:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    d9fd:	0f 84 41 01 00 00    	je     db44 <fwp_main_thread+0x274>
    da03:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    da08:	0f 84 82 02 00 00    	je     dc90 <fwp_main_thread+0x3c0>
    da0e:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    da12:	0f 84 68 02 00 00    	je     dc80 <fwp_main_thread+0x3b0>
    da18:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    da1c:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    da20:	0f 85 ea 02 00 00    	jne    dd10 <fwp_main_thread+0x440>
    da26:	48 8b 43 60          	mov    0x60(%rbx),%rax
    da2a:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    da31:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    da35:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    da3c:	00 00 00 00 
    da40:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    da47:	48 85 d2             	test   %rdx,%rdx
    da4a:	74 07                	je     da53 <fwp_main_thread+0x183>
    da4c:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    da53:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    da57:	48 85 c0             	test   %rax,%rax
    da5a:	74 34                	je     da90 <fwp_main_thread+0x1c0>
    da5c:	48 89 43 68          	mov    %rax,0x68(%rbx)
    da60:	48 8b 05 31 5d 01 00 	mov    0x15d31(%rip),%rax        # 23798 <fwp_timers>
    da67:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    da6b:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    da72:	00 00 00 00 
    da76:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    da7d:	48 85 c0             	test   %rax,%rax
    da80:	74 07                	je     da89 <fwp_main_thread+0x1b9>
    da82:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    da89:	48 89 1d 08 5d 01 00 	mov    %rbx,0x15d08(%rip)        # 23798 <fwp_timers>
    da90:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    da94:	e8 d7 98 ff ff       	call   7370 <fwp_block>
    da99:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    daa0:	48 85 c9             	test   %rcx,%rcx
    daa3:	74 47                	je     daec <fwp_main_thread+0x21c>
    daa5:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    daac:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    dab3:	48 85 d2             	test   %rdx,%rdx
    dab6:	0f 84 94 02 00 00    	je     dd50 <fwp_main_thread+0x480>
    dabc:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    dac3:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    daca:	48 85 c0             	test   %rax,%rax
    dacd:	74 07                	je     dad6 <fwp_main_thread+0x206>
    dacf:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    dad6:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    dadd:	00 00 00 00 
    dae1:	66 0f ef c0          	pxor   %xmm0,%xmm0
    dae5:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    daec:	48 8b 0d cd 5c 01 00 	mov    0x15ccd(%rip),%rcx        # 237c0 <fwp_cur>
    daf3:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    daf7:	0f 84 03 02 00 00    	je     dd00 <fwp_main_thread+0x430>
    dafd:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    db04:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    db0b:	48 85 d2             	test   %rdx,%rdx
    db0e:	0f 84 fc 03 00 00    	je     df10 <fwp_main_thread+0x640>
    db14:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    db1b:	48 85 c0             	test   %rax,%rax
    db1e:	74 07                	je     db27 <fwp_main_thread+0x257>
    db20:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    db27:	66 0f ef c9          	pxor   %xmm1,%xmm1
    db2b:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    db2f:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    db36:	48 89 cb             	mov    %rcx,%rbx
    db39:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    db3e:	0f 85 bf fe ff ff    	jne    da03 <fwp_main_thread+0x133>
    db44:	48 83 3d 0c 79 01 00 	cmpq   $0x0,0x1790c(%rip)        # 25458 <fwp_state_len>
    db4b:	00 
    db4c:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    db50:	0f 84 bc 00 00 00    	je     dc12 <fwp_main_thread+0x342>
    db56:	48 39 1d 5b 5c 01 00 	cmp    %rbx,0x15c5b(%rip)        # 237b8 <fwp_root>
    db5d:	c7 05 39 55 01 00 00 	movl   $0x0,0x15539(%rip)        # 230a0 <fwp_exit_code>
    db64:	00 00 00 
    db67:	0f 85 91 04 00 00    	jne    dffe <fwp_main_thread+0x72e>
    db6d:	48 85 db             	test   %rbx,%rbx
    db70:	0f 84 10 02 00 00    	je     dd86 <fwp_main_thread+0x4b6>
    db76:	48 8b 15 0b 5c 01 00 	mov    0x15c0b(%rip),%rdx        # 23788 <fwp_tasks_active>
    db7d:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    db81:	48 85 d2             	test   %rdx,%rdx
    db84:	0f 84 fc 01 00 00    	je     dd86 <fwp_main_thread+0x4b6>
    db8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    db90:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    db94:	75 08                	jne    db9e <fwp_main_thread+0x2ce>
    db96:	48 89 d7             	mov    %rdx,%rdi
    db99:	e8 62 67 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    db9e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    dba5:	48 85 d2             	test   %rdx,%rdx
    dba8:	75 e6                	jne    db90 <fwp_main_thread+0x2c0>
    dbaa:	eb 31                	jmp    dbdd <fwp_main_thread+0x30d>
    dbac:	0f 1f 40 00          	nopl   0x0(%rax)
    dbb0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    dbb7:	48 89 1d e2 5b 01 00 	mov    %rbx,0x15be2(%rip)        # 237a0 <fwp_ready_tail>
    dbbe:	e8 ad 97 ff ff       	call   7370 <fwp_block>
    dbc3:	e8 98 95 ff ff       	call   7160 <fwp_free_zombie>
    dbc8:	48 83 3d b8 5b 01 00 	cmpq   $0x0,0x15bb8(%rip)        # 23788 <fwp_tasks_active>
    dbcf:	00 
    dbd0:	0f 84 b0 01 00 00    	je     dd86 <fwp_main_thread+0x4b6>
    dbd6:	48 8b 1d db 5b 01 00 	mov    0x15bdb(%rip),%rbx        # 237b8 <fwp_root>
    dbdd:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    dbe1:	75 db                	jne    dbbe <fwp_main_thread+0x2ee>
    dbe3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    dbe7:	75 d5                	jne    dbbe <fwp_main_thread+0x2ee>
    dbe9:	48 8b 05 b0 5b 01 00 	mov    0x15bb0(%rip),%rax        # 237a0 <fwp_ready_tail>
    dbf0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    dbf4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    dbfb:	00 00 00 00 
    dbff:	48 85 c0             	test   %rax,%rax
    dc02:	75 ac                	jne    dbb0 <fwp_main_thread+0x2e0>
    dc04:	48 89 1d 9d 5b 01 00 	mov    %rbx,0x15b9d(%rip)        # 237a8 <fwp_ready_head>
    dc0b:	eb aa                	jmp    dbb7 <fwp_main_thread+0x2e7>
    dc0d:	0f 1f 00             	nopl   (%rax)
    dc10:	31 db                	xor    %ebx,%ebx
    dc12:	48 83 3d 2e 78 01 00 	cmpq   $0x0,0x1782e(%rip)        # 25448 <fwp_state_owners>
    dc19:	00 
    dc1a:	0f 85 36 ff ff ff    	jne    db56 <fwp_main_thread+0x286>
    dc20:	48 8b 3d 39 78 01 00 	mov    0x17839(%rip),%rdi        # 25460 <fwp_state>
    dc27:	e8 c4 7b ff ff       	call   57f0 <fwp_mem_free>
    dc2c:	48 c7 05 29 78 01 00 	movq   $0x0,0x17829(%rip)        # 25460 <fwp_state>
    dc33:	00 00 00 00 
    dc37:	48 c7 05 0e 78 01 00 	movq   $0x0,0x1780e(%rip)        # 25450 <fwp_state_cap>
    dc3e:	00 00 00 00 
    dc42:	48 85 db             	test   %rbx,%rbx
    dc45:	0f 84 76 03 00 00    	je     dfc1 <fwp_main_thread+0x6f1>
    dc4b:	48 39 1d 66 5b 01 00 	cmp    %rbx,0x15b66(%rip)        # 237b8 <fwp_root>
    dc52:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    dc59:	00 00 00 00 
    dc5d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    dc64:	00 00 00 00 
    dc68:	c7 05 2e 54 01 00 00 	movl   $0x0,0x1542e(%rip)        # 230a0 <fwp_exit_code>
    dc6f:	00 00 00 
    dc72:	0f 84 fe fe ff ff    	je     db76 <fwp_main_thread+0x2a6>
    dc78:	e9 d8 5a ff ff       	jmp    3755 <fwp_main_thread.cold>
    dc7d:	0f 1f 00             	nopl   (%rax)
    dc80:	e8 db 68 ff ff       	call   4560 <fwp_now_ns>
    dc85:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    dc89:	0f 8d 91 02 00 00    	jge    df20 <fwp_main_thread+0x650>
    dc8f:	90                   	nop
    dc90:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    dc94:	0f 85 7e fd ff ff    	jne    da18 <fwp_main_thread+0x148>
    dc9a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    dc9e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    dca2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    dca6:	0f 85 7e fd ff ff    	jne    da2a <fwp_main_thread+0x15a>
    dcac:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    dcb0:	48 85 c9             	test   %rcx,%rcx
    dcb3:	0f 84 71 fd ff ff    	je     da2a <fwp_main_thread+0x15a>
    dcb9:	48 85 c0             	test   %rax,%rax
    dcbc:	0f 84 2f 03 00 00    	je     dff1 <fwp_main_thread+0x721>
    dcc2:	48 39 c8             	cmp    %rcx,%rax
    dcc5:	48 0f 4f c1          	cmovg  %rcx,%rax
    dcc9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    dcd0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    dcd4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    dcdb:	00 00 00 00 
    dcdf:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    dce6:	48 85 d2             	test   %rdx,%rdx
    dce9:	74 07                	je     dcf2 <fwp_main_thread+0x422>
    dceb:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    dcf2:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    dcf6:	e9 61 fd ff ff       	jmp    da5c <fwp_main_thread+0x18c>
    dcfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    dd00:	48 89 cb             	mov    %rcx,%rbx
    dd03:	e9 f0 fc ff ff       	jmp    d9f8 <fwp_main_thread+0x128>
    dd08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    dd0f:	00 
    dd10:	48 8b 45 40          	mov    0x40(%rbp),%rax
    dd14:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    dd1b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    dd22:	00 00 00 00 
    dd26:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    dd2d:	48 85 c0             	test   %rax,%rax
    dd30:	0f 84 82 02 00 00    	je     dfb8 <fwp_main_thread+0x6e8>
    dd36:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    dd3d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    dd41:	e9 4a fd ff ff       	jmp    da90 <fwp_main_thread+0x1c0>
    dd46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    dd4d:	00 00 00 
    dd50:	48 89 01             	mov    %rax,(%rcx)
    dd53:	e9 72 fd ff ff       	jmp    daca <fwp_main_thread+0x1fa>
    dd58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    dd5f:	00 
    dd60:	48 83 3d f0 76 01 00 	cmpq   $0x0,0x176f0(%rip)        # 25458 <fwp_state_len>
    dd67:	00 
    dd68:	0f 84 a2 fe ff ff    	je     dc10 <fwp_main_thread+0x340>
    dd6e:	48 83 3d 42 5a 01 00 	cmpq   $0x0,0x15a42(%rip)        # 237b8 <fwp_root>
    dd75:	00 
    dd76:	c7 05 20 53 01 00 00 	movl   $0x0,0x15320(%rip)        # 230a0 <fwp_exit_code>
    dd7d:	00 00 00 
    dd80:	0f 85 7d 02 00 00    	jne    e003 <fwp_main_thread+0x733>
    dd86:	e8 d5 93 ff ff       	call   7160 <fwp_free_zombie>
    dd8b:	48 83 3d 15 5a 01 00 	cmpq   $0x0,0x15a15(%rip)        # 237a8 <fwp_ready_head>
    dd92:	00 
    dd93:	0f 85 bc 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    dd99:	48 83 3d f7 59 01 00 	cmpq   $0x0,0x159f7(%rip)        # 23798 <fwp_timers>
    dda0:	00 
    dda1:	0f 85 ae 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    dda7:	8b 1d d7 53 01 00    	mov    0x153d7(%rip),%ebx        # 23184 <fwp_stack_pool_n>
    ddad:	85 db                	test   %ebx,%ebx
    ddaf:	74 36                	je     dde7 <fwp_main_thread+0x517>
    ddb1:	83 eb 01             	sub    $0x1,%ebx
    ddb4:	48 8d 05 e5 53 01 00 	lea    0x153e5(%rip),%rax        # 231a0 <fwp_stack_pool>
    ddbb:	48 63 d3             	movslq %ebx,%rdx
    ddbe:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    ddc2:	eb 07                	jmp    ddcb <fwp_main_thread+0x4fb>
    ddc4:	0f 1f 40 00          	nopl   0x0(%rax)
    ddc8:	83 eb 01             	sub    $0x1,%ebx
    ddcb:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    ddcf:	be 00 00 00 10       	mov    $0x10000000,%esi
    ddd4:	89 1d aa 53 01 00    	mov    %ebx,0x153aa(%rip)        # 23184 <fwp_stack_pool_n>
    ddda:	48 83 ed 08          	sub    $0x8,%rbp
    ddde:	e8 fd 57 ff ff       	call   35e0 <munmap@plt>
    dde3:	85 db                	test   %ebx,%ebx
    dde5:	75 e1                	jne    ddc8 <fwp_main_thread+0x4f8>
    dde7:	8b 3d 2f 52 00 00    	mov    0x522f(%rip),%edi        # 1301c <fwp_epfd>
    dded:	85 ff                	test   %edi,%edi
    ddef:	78 05                	js     ddf6 <fwp_main_thread+0x526>
    ddf1:	e8 da 56 ff ff       	call   34d0 <close@plt>
    ddf6:	4c 8b 25 a3 55 01 00 	mov    0x155a3(%rip),%r12        # 233a0 <fwp_nfdws>
    ddfd:	48 8b 2d a4 55 01 00 	mov    0x155a4(%rip),%rbp        # 233a8 <fwp_fdws>
    de04:	31 db                	xor    %ebx,%ebx
    de06:	c7 05 0c 52 00 00 ff 	movl   $0xffffffff,0x520c(%rip)        # 1301c <fwp_epfd>
    de0d:	ff ff ff 
    de10:	4d 85 e4             	test   %r12,%r12
    de13:	74 38                	je     de4d <fwp_main_thread+0x57d>
    de15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    de1c:	00 00 00 00 
    de20:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    de25:	48 85 ff             	test   %rdi,%rdi
    de28:	74 1a                	je     de44 <fwp_main_thread+0x574>
    de2a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    de2e:	0f 85 21 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    de34:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    de39:	0f 85 16 59 ff ff    	jne    3755 <fwp_main_thread.cold>
    de3f:	e8 ac 79 ff ff       	call   57f0 <fwp_mem_free>
    de44:	48 83 c3 01          	add    $0x1,%rbx
    de48:	4c 39 e3             	cmp    %r12,%rbx
    de4b:	75 d3                	jne    de20 <fwp_main_thread+0x550>
    de4d:	48 89 ef             	mov    %rbp,%rdi
    de50:	e8 9b 79 ff ff       	call   57f0 <fwp_mem_free>
    de55:	48 8b 15 5c 59 01 00 	mov    0x1595c(%rip),%rdx        # 237b8 <fwp_root>
    de5c:	48 c7 05 41 55 01 00 	movq   $0x0,0x15541(%rip)        # 233a8 <fwp_fdws>
    de63:	00 00 00 00 
    de67:	48 c7 05 2e 55 01 00 	movq   $0x0,0x1552e(%rip)        # 233a0 <fwp_nfdws>
    de6e:	00 00 00 00 
    de72:	48 85 d2             	test   %rdx,%rdx
    de75:	74 4e                	je     dec5 <fwp_main_thread+0x5f5>
    de77:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    de7c:	0f 85 d3 58 ff ff    	jne    3755 <fwp_main_thread.cold>
    de82:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    de89:	00 
    de8a:	0f 85 c5 58 ff ff    	jne    3755 <fwp_main_thread.cold>
    de90:	48 83 3d c0 75 01 00 	cmpq   $0x0,0x175c0(%rip)        # 25458 <fwp_state_len>
    de97:	00 
    de98:	0f 85 b7 58 ff ff    	jne    3755 <fwp_main_thread.cold>
    de9e:	48 83 3d a2 75 01 00 	cmpq   $0x0,0x175a2(%rip)        # 25448 <fwp_state_owners>
    dea5:	00 
    dea6:	0f 85 a9 58 ff ff    	jne    3755 <fwp_main_thread.cold>
    deac:	b9 79 00 00 00       	mov    $0x79,%ecx
    deb1:	31 c0                	xor    %eax,%eax
    deb3:	48 8d 3d 06 55 01 00 	lea    0x15506(%rip),%rdi        # 233c0 <fwp_root_context>
    deba:	f3 48 ab             	rep stos %rax,(%rdi)
    debd:	48 89 d7             	mov    %rdx,%rdi
    dec0:	e8 2b 79 ff ff       	call   57f0 <fwp_mem_free>
    dec5:	48 8b 3d 54 51 00 00 	mov    0x5154(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    decc:	48 c7 05 e9 58 01 00 	movq   $0x0,0x158e9(%rip)        # 237c0 <fwp_cur>
    ded3:	00 00 00 00 
    ded7:	48 c7 05 d6 58 01 00 	movq   $0x0,0x158d6(%rip)        # 237b8 <fwp_root>
    dede:	00 00 00 00 
    dee2:	e8 d9 56 ff ff       	call   35c0 <fflush@plt>
    dee7:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    deee:	00 
    deef:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    def6:	00 00 
    def8:	0f 85 fb 00 00 00    	jne    dff9 <fwp_main_thread+0x729>
    defe:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    df05:	31 c0                	xor    %eax,%eax
    df07:	5b                   	pop    %rbx
    df08:	5d                   	pop    %rbp
    df09:	41 5c                	pop    %r12
    df0b:	c3                   	ret
    df0c:	0f 1f 40 00          	nopl   0x0(%rax)
    df10:	48 89 05 81 58 01 00 	mov    %rax,0x15881(%rip)        # 23798 <fwp_timers>
    df17:	e9 ff fb ff ff       	jmp    db1b <fwp_main_thread+0x24b>
    df1c:	0f 1f 40 00          	nopl   0x0(%rax)
    df20:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    df24:	0f 85 66 fd ff ff    	jne    dc90 <fwp_main_thread+0x3c0>
    df2a:	48 89 ef             	mov    %rbp,%rdi
    df2d:	e8 ce 63 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    df32:	e9 59 fd ff ff       	jmp    dc90 <fwp_main_thread+0x3c0>
    df37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    df3e:	00 00 
    df40:	48 8d 3d c9 5e ff ff 	lea    -0xa137(%rip),%rdi        # 3e10 <descent_phase_report>
    df47:	e8 d4 02 00 00       	call   e220 <atexit>
    df4c:	85 c0                	test   %eax,%eax
    df4e:	0f 85 98 00 00 00    	jne    dfec <fwp_main_thread+0x71c>
    df54:	c7 05 ba 51 01 00 01 	movl   $0x1,0x151ba(%rip)        # 23118 <descent_registered>
    df5b:	00 00 00 
    df5e:	8b 05 24 51 00 00    	mov    0x5124(%rip),%eax        # 13088 <st.7>
    df64:	85 c0                	test   %eax,%eax
    df66:	0f 85 70 fa ff ff    	jne    d9dc <fwp_main_thread+0x10c>
    df6c:	e8 5f cc ff ff       	call   abd0 <f0>
    df71:	48 c7 05 04 51 00 00 	movq   $0x0,0x5104(%rip)        # 13080 <v.6>
    df78:	00 00 00 00 
    df7c:	c7 05 02 51 00 00 01 	movl   $0x1,0x5102(%rip)        # 13088 <st.7>
    df83:	00 00 00 
    df86:	e9 51 fa ff ff       	jmp    d9dc <fwp_main_thread+0x10c>
    df8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    df90:	48 8d 3d c9 6c ff ff 	lea    -0x9337(%rip),%rdi        # 4c60 <fwp_heap_report>
    df97:	e8 84 02 00 00       	call   e220 <atexit>
    df9c:	e9 6d f9 ff ff       	jmp    d90e <fwp_main_thread+0x3e>
    dfa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    dfa8:	e8 c3 6d ff ff       	call   4d70 <fwp_heap_init>
    dfad:	e9 4e f9 ff ff       	jmp    d900 <fwp_main_thread+0x30>
    dfb2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    dfb8:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    dfbc:	e9 cf fa ff ff       	jmp    da90 <fwp_main_thread+0x1c0>
    dfc1:	48 83 3d ef 57 01 00 	cmpq   $0x0,0x157ef(%rip)        # 237b8 <fwp_root>
    dfc8:	00 
    dfc9:	c7 05 cd 50 01 00 00 	movl   $0x0,0x150cd(%rip)        # 230a0 <fwp_exit_code>
    dfd0:	00 00 00 
    dfd3:	0f 84 ad fd ff ff    	je     dd86 <fwp_main_thread+0x4b6>
    dfd9:	e9 77 57 ff ff       	jmp    3755 <fwp_main_thread.cold>
    dfde:	66 90                	xchg   %ax,%ax
    dfe0:	48 8d 3d 01 1a 00 00 	lea    0x1a01(%rip),%rdi        # f9e8 <_IO_stdin_used+0x9e8>
    dfe7:	e8 04 64 ff ff       	call   43f0 <fwp_trap>
    dfec:	e8 ef 5d ff ff       	call   3de0 <descent_phase_fail>
    dff1:	48 89 c8             	mov    %rcx,%rax
    dff4:	e9 d0 fc ff ff       	jmp    dcc9 <fwp_main_thread+0x3f9>
    dff9:	e8 62 54 ff ff       	call   3460 <__stack_chk_fail@plt>
    dffe:	e9 52 57 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e003:	e9 4d 57 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e008:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e00f:	00 

000000000000e010 <__divmodti4>:
    e010:	f3 0f 1e fa          	endbr64
    e014:	55                   	push   %rbp
    e015:	49 89 f1             	mov    %rsi,%r9
    e018:	49 89 d2             	mov    %rdx,%r10
    e01b:	48 89 fe             	mov    %rdi,%rsi
    e01e:	49 89 cb             	mov    %rcx,%r11
    e021:	48 89 e5             	mov    %rsp,%rbp
    e024:	41 57                	push   %r15
    e026:	41 56                	push   %r14
    e028:	41 55                	push   %r13
    e02a:	41 54                	push   %r12
    e02c:	53                   	push   %rbx
    e02d:	4c 89 c3             	mov    %r8,%rbx
    e030:	45 31 c0             	xor    %r8d,%r8d
    e033:	4d 85 c9             	test   %r9,%r9
    e036:	79 12                	jns    e04a <__divmodti4+0x3a>
    e038:	31 ff                	xor    %edi,%edi
    e03a:	48 f7 de             	neg    %rsi
    e03d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    e044:	4c 19 cf             	sbb    %r9,%rdi
    e047:	49 89 f9             	mov    %rdi,%r9
    e04a:	4c 89 d8             	mov    %r11,%rax
    e04d:	4d 85 db             	test   %r11,%r11
    e050:	0f 88 1a 01 00 00    	js     e170 <__divmodti4+0x160>
    e056:	4c 89 d9             	mov    %r11,%rcx
    e059:	49 89 f3             	mov    %rsi,%r11
    e05c:	75 62                	jne    e0c0 <__divmodti4+0xb0>
    e05e:	4d 89 c4             	mov    %r8,%r12
    e061:	4d 39 d1             	cmp    %r10,%r9
    e064:	0f 83 46 01 00 00    	jae    e1b0 <__divmodti4+0x1a0>
    e06a:	4c 89 d8             	mov    %r11,%rax
    e06d:	4c 89 ca             	mov    %r9,%rdx
    e070:	49 f7 f2             	div    %r10
    e073:	49 89 c3             	mov    %rax,%r11
    e076:	31 c0                	xor    %eax,%eax
    e078:	48 89 d6             	mov    %rdx,%rsi
    e07b:	31 ff                	xor    %edi,%edi
    e07d:	4c 89 d9             	mov    %r11,%rcx
    e080:	48 89 c2             	mov    %rax,%rdx
    e083:	48 89 c8             	mov    %rcx,%rax
    e086:	4d 85 e4             	test   %r12,%r12
    e089:	74 0a                	je     e095 <__divmodti4+0x85>
    e08b:	48 f7 d8             	neg    %rax
    e08e:	48 83 d2 00          	adc    $0x0,%rdx
    e092:	48 f7 da             	neg    %rdx
    e095:	4d 85 c0             	test   %r8,%r8
    e098:	74 0a                	je     e0a4 <__divmodti4+0x94>
    e09a:	48 f7 de             	neg    %rsi
    e09d:	48 83 d7 00          	adc    $0x0,%rdi
    e0a1:	48 f7 df             	neg    %rdi
    e0a4:	48 89 33             	mov    %rsi,(%rbx)
    e0a7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    e0ab:	5b                   	pop    %rbx
    e0ac:	41 5c                	pop    %r12
    e0ae:	41 5d                	pop    %r13
    e0b0:	41 5e                	pop    %r14
    e0b2:	41 5f                	pop    %r15
    e0b4:	5d                   	pop    %rbp
    e0b5:	c3                   	ret
    e0b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e0bd:	00 00 00 
    e0c0:	4d 89 c4             	mov    %r8,%r12
    e0c3:	49 39 c1             	cmp    %rax,%r9
    e0c6:	0f 82 ce 00 00 00    	jb     e19a <__divmodti4+0x18a>
    e0cc:	31 ff                	xor    %edi,%edi
    e0ce:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    e0d3:	48 63 c7             	movslq %edi,%rax
    e0d6:	be 40 00 00 00       	mov    $0x40,%esi
    e0db:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    e0e0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    e0e5:	48 29 c6             	sub    %rax,%rsi
    e0e8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    e0ed:	48 09 c8             	or     %rcx,%rax
    e0f0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    e0f5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    e0fa:	49 89 c6             	mov    %rax,%r14
    e0fd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    e101:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    e106:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    e10b:	49 09 c1             	or     %rax,%r9
    e10e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    e112:	4c 89 c8             	mov    %r9,%rax
    e115:	49 f7 f6             	div    %r14
    e118:	48 89 d1             	mov    %rdx,%rcx
    e11b:	49 89 c3             	mov    %rax,%r11
    e11e:	49 89 c1             	mov    %rax,%r9
    e121:	49 f7 e2             	mul    %r10
    e124:	49 89 c6             	mov    %rax,%r14
    e127:	49 89 d2             	mov    %rdx,%r10
    e12a:	48 39 d1             	cmp    %rdx,%rcx
    e12d:	72 07                	jb     e136 <__divmodti4+0x126>
    e12f:	75 17                	jne    e148 <__divmodti4+0x138>
    e131:	49 39 c7             	cmp    %rax,%r15
    e134:	73 12                	jae    e148 <__divmodti4+0x138>
    e136:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    e13a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    e13e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    e142:	49 89 d2             	mov    %rdx,%r10
    e145:	49 89 c6             	mov    %rax,%r14
    e148:	4c 89 f8             	mov    %r15,%rax
    e14b:	4c 29 f0             	sub    %r14,%rax
    e14e:	4c 19 d1             	sbb    %r10,%rcx
    e151:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    e156:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    e15b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    e160:	48 09 c6             	or     %rax,%rsi
    e163:	48 89 cf             	mov    %rcx,%rdi
    e166:	31 c0                	xor    %eax,%eax
    e168:	4c 89 c9             	mov    %r9,%rcx
    e16b:	e9 10 ff ff ff       	jmp    e080 <__divmodti4+0x70>
    e170:	4c 89 d0             	mov    %r10,%rax
    e173:	4c 89 da             	mov    %r11,%rdx
    e176:	4d 89 c4             	mov    %r8,%r12
    e179:	49 89 f3             	mov    %rsi,%r11
    e17c:	48 f7 d8             	neg    %rax
    e17f:	49 f7 d4             	not    %r12
    e182:	48 83 d2 00          	adc    $0x0,%rdx
    e186:	49 89 c2             	mov    %rax,%r10
    e189:	48 f7 da             	neg    %rdx
    e18c:	48 89 d1             	mov    %rdx,%rcx
    e18f:	0f 84 cc fe ff ff    	je     e061 <__divmodti4+0x51>
    e195:	49 39 d1             	cmp    %rdx,%r9
    e198:	73 46                	jae    e1e0 <__divmodti4+0x1d0>
    e19a:	4c 89 cf             	mov    %r9,%rdi
    e19d:	31 c0                	xor    %eax,%eax
    e19f:	31 c9                	xor    %ecx,%ecx
    e1a1:	e9 da fe ff ff       	jmp    e080 <__divmodti4+0x70>
    e1a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e1ad:	00 00 00 
    e1b0:	4d 85 d2             	test   %r10,%r10
    e1b3:	75 0d                	jne    e1c2 <__divmodti4+0x1b2>
    e1b5:	b8 01 00 00 00       	mov    $0x1,%eax
    e1ba:	31 d2                	xor    %edx,%edx
    e1bc:	49 f7 f2             	div    %r10
    e1bf:	49 89 c2             	mov    %rax,%r10
    e1c2:	4c 89 c8             	mov    %r9,%rax
    e1c5:	31 d2                	xor    %edx,%edx
    e1c7:	49 f7 f2             	div    %r10
    e1ca:	49 89 c1             	mov    %rax,%r9
    e1cd:	4c 89 d8             	mov    %r11,%rax
    e1d0:	49 f7 f2             	div    %r10
    e1d3:	49 89 c3             	mov    %rax,%r11
    e1d6:	4c 89 c8             	mov    %r9,%rax
    e1d9:	e9 9a fe ff ff       	jmp    e078 <__divmodti4+0x68>
    e1de:	66 90                	xchg   %ax,%ax
    e1e0:	45 31 f6             	xor    %r14d,%r14d
    e1e3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    e1e8:	44 89 f7             	mov    %r14d,%edi
    e1eb:	45 85 f6             	test   %r14d,%r14d
    e1ee:	0f 85 df fe ff ff    	jne    e0d3 <__divmodti4+0xc3>
    e1f4:	4c 39 ca             	cmp    %r9,%rdx
    e1f7:	72 17                	jb     e210 <__divmodti4+0x200>
    e1f9:	31 c9                	xor    %ecx,%ecx
    e1fb:	48 39 c6             	cmp    %rax,%rsi
    e1fe:	73 10                	jae    e210 <__divmodti4+0x200>
    e200:	4c 89 cf             	mov    %r9,%rdi
    e203:	31 c0                	xor    %eax,%eax
    e205:	e9 76 fe ff ff       	jmp    e080 <__divmodti4+0x70>
    e20a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e210:	4c 89 de             	mov    %r11,%rsi
    e213:	b9 01 00 00 00       	mov    $0x1,%ecx
    e218:	48 29 c6             	sub    %rax,%rsi
    e21b:	49 19 d1             	sbb    %rdx,%r9
    e21e:	eb e0                	jmp    e200 <__divmodti4+0x1f0>

000000000000e220 <atexit>:
    e220:	f3 0f 1e fa          	endbr64
    e224:	48 8b 15 dd 4d 00 00 	mov    0x4ddd(%rip),%rdx        # 13008 <__dso_handle>
    e22b:	31 f6                	xor    %esi,%esi
    e22d:	e9 2e 54 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000e234 <_fini>:
    e234:	f3 0f 1e fa          	endbr64
    e238:	48 83 ec 08          	sub    $0x8,%rsp
    e23c:	48 83 c4 08          	add    $0x8,%rsp
    e240:	c3                   	ret
