
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-history-reference-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 df 00 00 	mov    0xdfc1(%rip),%rax        # 10fd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da dd 00 00    	push   0xddda(%rip)        # 10e00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc dd 00 00    	jmp    *0xdddc(%rip)        # 10e08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 dc 00 00    	jmp    *0xdc46(%rip)        # 10fe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 da 00 00    	jmp    *0xda66(%rip)        # 10e10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e da 00 00    	jmp    *0xda5e(%rip)        # 10e18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 da 00 00    	jmp    *0xda56(%rip)        # 10e20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e da 00 00    	jmp    *0xda4e(%rip)        # 10e28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 da 00 00    	jmp    *0xda46(%rip)        # 10e30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e da 00 00    	jmp    *0xda3e(%rip)        # 10e38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 da 00 00    	jmp    *0xda36(%rip)        # 10e40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e da 00 00    	jmp    *0xda2e(%rip)        # 10e48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 da 00 00    	jmp    *0xda26(%rip)        # 10e50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e da 00 00    	jmp    *0xda1e(%rip)        # 10e58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 da 00 00    	jmp    *0xda16(%rip)        # 10e60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e da 00 00    	jmp    *0xda0e(%rip)        # 10e68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 da 00 00    	jmp    *0xda06(%rip)        # 10e70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe d9 00 00    	jmp    *0xd9fe(%rip)        # 10e78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 d9 00 00    	jmp    *0xd9f6(%rip)        # 10e80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee d9 00 00    	jmp    *0xd9ee(%rip)        # 10e88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 d9 00 00    	jmp    *0xd9e6(%rip)        # 10e90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de d9 00 00    	jmp    *0xd9de(%rip)        # 10e98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 d9 00 00    	jmp    *0xd9d6(%rip)        # 10ea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce d9 00 00    	jmp    *0xd9ce(%rip)        # 10ea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 d9 00 00    	jmp    *0xd9c6(%rip)        # 10eb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be d9 00 00    	jmp    *0xd9be(%rip)        # 10eb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 d9 00 00    	jmp    *0xd9b6(%rip)        # 10ec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae d9 00 00    	jmp    *0xd9ae(%rip)        # 10ec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 d9 00 00    	jmp    *0xd9a6(%rip)        # 10ed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e d9 00 00    	jmp    *0xd99e(%rip)        # 10ed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 d9 00 00    	jmp    *0xd996(%rip)        # 10ee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e d9 00 00    	jmp    *0xd98e(%rip)        # 10ee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 d9 00 00    	jmp    *0xd986(%rip)        # 10ef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e d9 00 00    	jmp    *0xd97e(%rip)        # 10ef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 d9 00 00    	jmp    *0xd976(%rip)        # 10f00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e d9 00 00    	jmp    *0xd96e(%rip)        # 10f08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 d9 00 00    	jmp    *0xd966(%rip)        # 10f10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e d9 00 00    	jmp    *0xd95e(%rip)        # 10f18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 d9 00 00    	jmp    *0xd956(%rip)        # 10f20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e d9 00 00    	jmp    *0xd94e(%rip)        # 10f28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 d9 00 00    	jmp    *0xd946(%rip)        # 10f30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e d9 00 00    	jmp    *0xd93e(%rip)        # 10f38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 d9 00 00    	jmp    *0xd936(%rip)        # 10f40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e d9 00 00    	jmp    *0xd92e(%rip)        # 10f48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 d9 00 00    	jmp    *0xd926(%rip)        # 10f50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e d9 00 00    	jmp    *0xd91e(%rip)        # 10f58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 d9 00 00    	jmp    *0xd916(%rip)        # 10f60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e d9 00 00    	jmp    *0xd90e(%rip)        # 10f68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 d9 00 00    	jmp    *0xd906(%rip)        # 10f70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe d8 00 00    	jmp    *0xd8fe(%rip)        # 10f78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 d8 00 00    	jmp    *0xd8f6(%rip)        # 10f80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee d8 00 00    	jmp    *0xd8ee(%rip)        # 10f88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 d8 00 00    	jmp    *0xd8e6(%rip)        # 10f90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de d8 00 00    	jmp    *0xd8de(%rip)        # 10f98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 d8 00 00    	jmp    *0xd8d6(%rip)        # 10fa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce d8 00 00    	jmp    *0xd8ce(%rip)        # 10fa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 d8 00 00    	jmp    *0xd8c6(%rip)        # 10fb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be d8 00 00    	jmp    *0xd8be(%rip)        # 10fb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd 99 00 00 	lea    0x99dd(%rip),%r9        # d0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da 99 00 00 	lea    0x99da(%rip),%r8        # d0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 e1 bc 00 00 	lea    0xbce1(%rip),%rax        # f460 <fwp_fn_table>
    377f:	48 89 05 d2 fc 01 00 	mov    %rax,0x1fcd2(%rip)        # 23458 <fwp_fns>
    3786:	48 8b 05 b3 d8 00 00 	mov    0xd8b3(%rip),%rax        # 11040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 cc fc 01 00 	mov    %rax,0x1fccc(%rip)        # 23460 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d b7 9a 00 00 	lea    0x9ab7(%rip),%rdi        # d257 <_IO_stdin_used+0x257>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 d8 00 00 	mov    0xd838(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 cf 74 00 00 	lea    0x74cf(%rip),%rdx        # ad30 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 d7 00 00 	mov    0xd7a3(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 18 d8 01 00    	mov    0x1d818(%rip),%eax        # 210c0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 67 99 00 00 	lea    0x9967(%rip),%rdi        # d260 <_IO_stdin_used+0x260>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 7e a1 00 00 	lea    0xa17e(%rip),%rdi        # da88 <_IO_stdin_used+0xa88>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 38 a1 00 00 	lea    0xa138(%rip),%rdi        # da60 <_IO_stdin_used+0xa60>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d fc a0 00 00 	lea    0xa0fc(%rip),%rdi        # da30 <_IO_stdin_used+0xa30>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d c8 a0 00 00 	lea    0xa0c8(%rip),%rdi        # da08 <_IO_stdin_used+0xa08>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b d6 00 00    	call   *0xd64b(%rip)        # 10fc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 d6 00 00 	lea    0xd6a1(%rip),%rdi        # 11028 <__TMC_END__>
    3987:	48 8d 05 9a d6 00 00 	lea    0xd69a(%rip),%rax        # 11028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e d6 00 00 	mov    0xd62e(%rip),%rax        # 10fc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 d6 00 00 	lea    0xd671(%rip),%rdi        # 11028 <__TMC_END__>
    39b7:	48 8d 35 6a d6 00 00 	lea    0xd66a(%rip),%rsi        # 11028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd d5 00 00 	mov    0xd5fd(%rip),%rax        # 10fd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d d6 00 00 00 	cmpb   $0x0,0xd66d(%rip)        # 11068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da d5 00 00 	cmpq   $0x0,0xd5da(%rip)        # 10fe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 d5 00 00 	mov    0xd5f6(%rip),%rdi        # 11008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 d6 00 00 01 	movb   $0x1,0xd645(%rip)        # 11068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 0e d5 01 00 	add    0x1d50e(%rip),%rdx        # 21130 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 fc d4 01 00 	add    0x1d4fc(%rip),%rax        # 21130 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d e9 f7 01 00 	mov    0x1f7e9(%rip),%rdi        # 23460 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d b4 d3 00 00 	mov    0xd3b4(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d a1 d3 00 00 	mov    0xd3a1(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 93 00 00 	lea    0x9345(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 92 d3 00 00 	mov    0xd392(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 e1 da 01 00 	mov    0x1dae1(%rip),%rax        # 217e0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 19 d4 01 00 	mov    0x1d419(%rip),%rax        # 21198 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 05 d4 01 00 	sub    0x1d405(%rip),%rax        # 21190 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 ad 9d 00 00 	lea    0x9dad(%rip),%rsi        # db70 <msg.8>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 7f 98 00 00 	lea    0x987f(%rip),%rdi        # d668 <_IO_stdin_used+0x668>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 62 d2 00 00 	mov    0xd262(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d ed d1 00 00 ff 	cmpl   $0xffffffff,0xd1ed(%rip)        # 11020 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 91 00 00 	lea    0x91e2(%rip),%rax        # d022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d 01 d3 01 00 	mov    0x1d301(%rip),%r9        # 21148 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f cd 00 	movq   0xcd9f(%rip),%xmm0        # 10bf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 91 00 00 	lea    0x91e7(%rip),%rax        # d044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 dc d2 01 00 	mov    0x1d2dc(%rip),%r8        # 21140 <descent_inputs>
    3e64:	48 8b 0d e5 d2 01 00 	mov    0x1d2e5(%rip),%rcx        # 21150 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d e2 d1 00 00 	mov    0xd1e2(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 91 00 00 	lea    0x91d8(%rip),%rax        # d061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 cd 00 	movq   0xcd67(%rip),%xmm0        # 10bf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 18 98 00 00 	lea    0x9818(%rip),%rdx        # d6b0 <_IO_stdin_used+0x6b0>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 b1 d2 01 00 	lea    0x1d2b1(%rip),%r12        # 21160 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 cd 00 	movq   0xcd44(%rip),%xmm0        # 10c00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 7b d1 00 00 	mov    0xd17b(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 91 00 00 	lea    0x9175(%rip),%rcx        # d06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 91 00 00 	lea    0x9170(%rip),%rdx        # d06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 40 d1 00 00 	mov    0xd140(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 91 00 00 	lea    0x9144(%rip),%rdi        # d07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d 19 d1 00 00 	mov    0xd119(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 91 00 00 	lea    0x9143(%rip),%rcx        # d091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 91 00 00 	lea    0x9119(%rip),%rdx        # d06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 5b ec 01 00 	mov    0x1ec5b(%rip),%rax        # 22bf0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 54 ec 01 00 	lea    0x1ec54(%rip),%r8        # 22bf0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d 35 ec 01 00 	mov    0x1ec35(%rip),%rbx        # 22bd8 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 45 ec 01 00 	mov    0x1ec45(%rip),%rcx        # 22bf8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d e1 eb 01 00 	mov    0x1ebe1(%rip),%rdi        # 22be0 <fwp_heap+0x13e0>
    3fff:	48 29 35 2a ec 01 00 	sub    %rsi,0x1ec2a(%rip)        # 22c30 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 ba eb 01 00 	mov    0x1ebba(%rip),%rax        # 22bd0 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 70 eb 01 00 	add    0x1eb70(%rip),%rdi        # 22bb0 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 7e eb 01 00 	mov    0x1eb7e(%rip),%rsi        # 22be0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 8c eb 01 00 	mov    0x1eb8c(%rip),%rax        # 22bf8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 3b eb 01 00 	mov    %r12,0x1eb3b(%rip)        # 22be0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d 29 eb 01 00 	mov    %rbp,0x1eb29(%rip)        # 22bd8 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d 0e eb 01 00 	cmp    %rdi,0x1eb0e(%rip)        # 22bc8 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d 05 eb 01 00 	mov    %rdi,0x1eb05(%rip)        # 22bc8 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 49 eb 01 00 	sub    %rdi,0x1eb49(%rip)        # 22c30 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 f1 ea 01 00 	mov    0x1eaf1(%rip),%rax        # 22be8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 ea ea 01 00 	lea    0x1eaea(%rip),%r8        # 22be8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 7d ce 00 00 	mov    0xce7d(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 8e 00 00 	lea    0x8e14(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d b5 cd 00 00 	movslq 0xcdb5(%rip),%rbp        # 11020 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 ba ce 01 00 	mov    0x1ceba(%rip),%rsi        # 21158 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d b6 ce 01 00 	lea    0x1ceb6(%rip),%rcx        # 21160 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 8b ce 01 00 	addq   $0x1,0x1ce8b(%rip)        # 21150 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 50 cd 00 00    	mov    %ebx,0xcd50(%rip)        # 11020 <descent_active_phase>
    42d0:	48 89 05 81 ce 01 00 	mov    %rax,0x1ce81(%rip)        # 21158 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d d9 d4 01 00 	cmp    0x1d4d9(%rip),%rdi        # 217e0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 9f d4 01 00 	mov    0x1d49f(%rip),%rax        # 217c0 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 7d d4 01 00 	mov    %rdi,0x1d47d(%rip)        # 217c0 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 59 d4 01 00 	mov    %rdi,0x1d459(%rip)        # 217c8 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 18 8e 00 00 	lea    0x8e18(%rip),%rsi        # d1c9 <_IO_stdin_used+0x1c9>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba 8c 00 00 	lea    0x8cba(%rip),%rsi        # d07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 48 cc 00 00 	mov    0xcc48(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 8c 00 00 	lea    0x8c64(%rip),%rdx        # d083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 30 cc 00 00 	mov    0xcc30(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 41 cb 00 00 	mov    0xcb41(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 8a 00 00 	lea    0x8ad8(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 8b 00 00 	lea    0x8b45(%rip),%rdi        # d092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd 8a 00 00 	lea    0x8acd(%rip),%rdi        # d0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d 10 91 00 00 	lea    0x9110(%rip),%rdi        # d700 <_IO_stdin_used+0x700>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 80 95 00 	movdqa 0x9580(%rip),%xmm0        # db90 <msg.8+0x20>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 ea ed 01 00 	add    0x1edea(%rip),%rax        # 23458 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 64 90 00 00 	lea    0x9064(%rip),%rdi        # d728 <_IO_stdin_used+0x728>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 45 ca 01 00 	cmp    %rax,0x1ca45(%rip)        # 21128 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 40 ca 01 00 	add    0x1ca40(%rip),%rax        # 21130 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 4d 90 00 00 	lea    0x904d(%rip),%rdi        # d758 <_IO_stdin_used+0x758>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 89 00 00 	lea    0x89a5(%rip),%r8        # d0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa 87 00 00 	lea    0x87fa(%rip),%r8        # d0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 86 00 00 	lea    0x8697(%rip),%r8        # d0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f 84 00 00 	lea    0x846f(%rip),%rdi        # d0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 7e 85 00 00 	lea    0x857e(%rip),%rsi        # d20c <_IO_stdin_used+0x20c>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d c5 de 01 00 	mov    0x1dec5(%rip),%r9        # 22bc8 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 1e df 01 00 	mov    0x1df1e(%rip),%r8        # 22c28 <fwp_heap+0x1428>
    4d0a:	48 8d 15 97 8a 00 00 	lea    0x8a97(%rip),%rdx        # d7a8 <_IO_stdin_used+0x7a8>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d 06 df 01 00 	mov    0x1df06(%rip),%rcx        # 22c20 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d 14 df 01 	movsd  0x1df14(%rip),%xmm1        # 22c40 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 04 df 01 	movsd  0x1df04(%rip),%xmm0        # 22c38 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 25 c3 00 00 	mov    0xc325(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 28 8e 00 	movdqa 0x8e28(%rip),%xmm0        # dba0 <msg.8+0x30>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 bf d9 01 00 	lea    0x1d9bf(%rip),%rax        # 22740 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 51 8e 00 	movdqa 0x8e51(%rip),%xmm2        # dbe0 <msg.8+0x70>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 65 d9 01 00 	movaps %xmm0,0x1d965(%rip)        # 22700 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 0d 8e 00 	movdqa 0x8e0d(%rip),%xmm0        # dbb0 <msg.8+0x40>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 f3 dd 01 00 01 	movl   $0x1,0x1ddf3(%rip)        # 22ba4 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 53 d9 01 00 	movaps %xmm0,0x1d953(%rip)        # 22710 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 fb 8d 00 	movdqa 0x8dfb(%rip),%xmm0        # dbc0 <msg.8+0x50>
    4dc4:	00 
    4dc5:	0f 29 05 54 d9 01 00 	movaps %xmm0,0x1d954(%rip)        # 22720 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 fc 8d 00 	movdqa 0x8dfc(%rip),%xmm0        # dbd0 <msg.8+0x60>
    4dd3:	00 
    4dd4:	0f 29 05 55 d9 01 00 	movaps %xmm0,0x1d955(%rip)        # 22730 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 d5 c9 01 00 	lea    0x1c9d5(%rip),%r8        # 21800 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 f0 dc 01 00 	mov    %rax,0x1dcf0(%rip)        # 22bb8 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 ce dc 01 00 	mov    %r12,0x1dcce(%rip)        # 22bc0 <fwp_heap+0x13c0>
    4ef2:	48 89 05 b7 dc 01 00 	mov    %rax,0x1dcb7(%rip)        # 22bb0 <fwp_heap+0x13b0>
    4ef9:	48 89 1d d0 dc 01 00 	mov    %rbx,0x1dcd0(%rip)        # 22bd0 <fwp_heap+0x13d0>
    4f00:	48 89 35 f9 dc 01 00 	mov    %rsi,0x1dcf9(%rip)        # 22c00 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 81 00 00 	lea    0x81f9(%rip),%rdi        # d112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 d8 dc 01 00 	mov    %rax,0x1dcd8(%rip)        # 22bf8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 5c dc 01 00    	mov    %eax,0x1dc5c(%rip)        # 22ba8 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <caf61>:
    4f60:	8b 15 3a c1 00 00    	mov    0xc13a(%rip),%edx        # 110a0 <st.4>
    4f66:	85 d2                	test   %edx,%edx
    4f68:	74 0e                	je     4f78 <caf61+0x18>
    4f6a:	48 8b 05 27 c1 00 00 	mov    0xc127(%rip),%rax        # 11098 <v.3>
    4f71:	c3                   	ret
    4f72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f78:	8b 05 12 c1 00 00    	mov    0xc112(%rip),%eax        # 11090 <st.2>
    4f7e:	85 c0                	test   %eax,%eax
    4f80:	74 1e                	je     4fa0 <caf61+0x40>
    4f82:	48 8b 05 ff c0 00 00 	mov    0xc0ff(%rip),%rax        # 11088 <v.1>
    4f89:	48 89 05 08 c1 00 00 	mov    %rax,0xc108(%rip)        # 11098 <v.3>
    4f90:	c7 05 06 c1 00 00 01 	movl   $0x1,0xc106(%rip)        # 110a0 <st.4>
    4f97:	00 00 00 
    4f9a:	c3                   	ret
    4f9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4fa0:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    4fa7:	00 f0 3f 
    4faa:	c7 05 dc c0 00 00 01 	movl   $0x1,0xc0dc(%rip)        # 11090 <st.2>
    4fb1:	00 00 00 
    4fb4:	48 89 05 cd c0 00 00 	mov    %rax,0xc0cd(%rip)        # 11088 <v.1>
    4fbb:	eb cc                	jmp    4f89 <caf61+0x29>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 ec c7 01 00 	mov    0x1c7ec(%rip),%r8        # 217c0 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d 1c c7 01 00 	mov    %rbx,0x1c71c(%rip)        # 217c8 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 08 c7 01 00 	mov    %r8,0x1c708(%rip)        # 217c0 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <fwp_tape_buffers_release>:
    50d0:	f3 0f 1e fa          	endbr64
    50d4:	53                   	push   %rbx
    50d5:	48 89 fb             	mov    %rdi,%rbx
    50d8:	48 83 ec 10          	sub    $0x10,%rsp
    50dc:	48 8b 47 28          	mov    0x28(%rdi),%rax
    50e0:	48 85 c0             	test   %rax,%rax
    50e3:	0f 88 df 00 00 00    	js     51c8 <fwp_tape_buffers_release+0xf8>
    50e9:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    50ed:	48 85 d2             	test   %rdx,%rdx
    50f0:	0f 88 d2 00 00 00    	js     51c8 <fwp_tape_buffers_release+0xf8>
    50f6:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    50fc:	0f 87 c6 00 00 00    	ja     51c8 <fwp_tape_buffers_release+0xf8>
    5102:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5106:	b8 00 00 08 00       	mov    $0x80000,%eax
    510b:	48 c1 e1 03          	shl    $0x3,%rcx
    510f:	48 29 c8             	sub    %rcx,%rax
    5112:	48 c1 e8 03          	shr    $0x3,%rax
    5116:	48 39 d0             	cmp    %rdx,%rax
    5119:	0f 82 a9 00 00 00    	jb     51c8 <fwp_tape_buffers_release+0xf8>
    511f:	48 8d 3d fc 7f 00 00 	lea    0x7ffc(%rip),%rdi        # d122 <_IO_stdin_used+0x122>
    5126:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    512b:	48 89 14 24          	mov    %rdx,(%rsp)
    512f:	e8 6c e2 ff ff       	call   33a0 <getenv@plt>
    5134:	48 8b 14 24          	mov    (%rsp),%rdx
    5138:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    513d:	48 85 c0             	test   %rax,%rax
    5140:	74 09                	je     514b <fwp_tape_buffers_release+0x7b>
    5142:	80 38 30             	cmpb   $0x30,(%rax)
    5145:	0f 84 9d 00 00 00    	je     51e8 <fwp_tape_buffers_release+0x118>
    514b:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    514f:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    5153:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    515a:	77 78                	ja     51d4 <fwp_tape_buffers_release+0x104>
    515c:	48 8d 3d 7d bf 01 00 	lea    0x1bf7d(%rip),%rdi        # 210e0 <fwp_tape_workspace>
    5163:	48 89 04 24          	mov    %rax,(%rsp)
    5167:	e8 a4 ef ff ff       	call   4110 <fwp_tape_buffers_dispose>
    516c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5170:	48 8b 04 24          	mov    (%rsp),%rax
    5174:	0f 29 05 65 bf 01 00 	movaps %xmm0,0x1bf65(%rip)        # 210e0 <fwp_tape_workspace>
    517b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5180:	48 89 05 41 bf 01 00 	mov    %rax,0x1bf41(%rip)        # 210c8 <fwp_tape_cached_bytes>
    5187:	0f 29 05 62 bf 01 00 	movaps %xmm0,0x1bf62(%rip)        # 210f0 <fwp_tape_workspace+0x10>
    518e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5193:	0f 29 05 66 bf 01 00 	movaps %xmm0,0x1bf66(%rip)        # 21100 <fwp_tape_workspace+0x20>
    519a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    519e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    51a2:	48 89 15 67 bf 01 00 	mov    %rdx,0x1bf67(%rip)        # 21110 <fwp_tape_workspace+0x30>
    51a9:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    51b0:	00 
    51b1:	0f 11 03             	movups %xmm0,(%rbx)
    51b4:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    51b8:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    51bc:	48 83 c4 10          	add    $0x10,%rsp
    51c0:	5b                   	pop    %rbx
    51c1:	c3                   	ret
    51c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    51c8:	48 8d 3d 53 7f 00 00 	lea    0x7f53(%rip),%rdi        # d122 <_IO_stdin_used+0x122>
    51cf:	e8 cc e1 ff ff       	call   33a0 <getenv@plt>
    51d4:	48 83 c4 10          	add    $0x10,%rsp
    51d8:	48 89 df             	mov    %rbx,%rdi
    51db:	5b                   	pop    %rbx
    51dc:	e9 2f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    51e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e8:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    51ec:	0f 85 59 ff ff ff    	jne    514b <fwp_tape_buffers_release+0x7b>
    51f2:	48 83 c4 10          	add    $0x10,%rsp
    51f6:	48 89 df             	mov    %rbx,%rdi
    51f9:	5b                   	pop    %rbx
    51fa:	e9 11 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    51ff:	90                   	nop

0000000000005200 <fwp_poll_events>:
    5200:	53                   	push   %rbx
    5201:	48 83 ec 20          	sub    $0x20,%rsp
    5205:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    520c:	00 00 
    520e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5213:	31 c0                	xor    %eax,%eax
    5215:	e8 46 f3 ff ff       	call   4560 <fwp_now_ns>
    521a:	48 8b 1d 97 c5 01 00 	mov    0x1c597(%rip),%rbx        # 217b8 <fwp_timers>
    5221:	48 85 db             	test   %rbx,%rbx
    5224:	0f 84 d6 00 00 00    	je     5300 <fwp_poll_events+0x100>
    522a:	48 89 c6             	mov    %rax,%rsi
    522d:	48 89 da             	mov    %rbx,%rdx
    5230:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5237:	eb 16                	jmp    524f <fwp_poll_events+0x4f>
    5239:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5240:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5247:	48 89 c8             	mov    %rcx,%rax
    524a:	48 85 d2             	test   %rdx,%rdx
    524d:	74 31                	je     5280 <fwp_poll_events+0x80>
    524f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5253:	48 85 c0             	test   %rax,%rax
    5256:	78 e8                	js     5240 <fwp_poll_events+0x40>
    5258:	48 39 c1             	cmp    %rax,%rcx
    525b:	7c e3                	jl     5240 <fwp_poll_events+0x40>
    525d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5264:	48 85 d2             	test   %rdx,%rdx
    5267:	74 1c                	je     5285 <fwp_poll_events+0x85>
    5269:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    526d:	48 39 c1             	cmp    %rax,%rcx
    5270:	7c ce                	jl     5240 <fwp_poll_events+0x40>
    5272:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5279:	48 85 d2             	test   %rdx,%rdx
    527c:	75 d1                	jne    524f <fwp_poll_events+0x4f>
    527e:	66 90                	xchg   %ax,%ax
    5280:	48 85 c0             	test   %rax,%rax
    5283:	78 7b                	js     5300 <fwp_poll_events+0x100>
    5285:	48 29 f0             	sub    %rsi,%rax
    5288:	48 89 c1             	mov    %rax,%rcx
    528b:	48 85 c0             	test   %rax,%rax
    528e:	0f 8e 9c 00 00 00    	jle    5330 <fwp_poll_events+0x130>
    5294:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    529b:	de 1b 43 
    529e:	48 f7 ea             	imul   %rdx
    52a1:	48 89 c8             	mov    %rcx,%rax
    52a4:	48 c1 f8 3f          	sar    $0x3f,%rax
    52a8:	48 c1 fa 12          	sar    $0x12,%rdx
    52ac:	48 29 c2             	sub    %rax,%rdx
    52af:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    52b6:	48 39 c1             	cmp    %rax,%rcx
    52b9:	0f 95 c0             	setne  %al
    52bc:	0f b6 c0             	movzbl %al,%eax
    52bf:	48 01 d0             	add    %rdx,%rax
    52c2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    52c8:	0f 8f 32 01 00 00    	jg     5400 <fwp_poll_events+0x200>
    52ce:	48 85 c0             	test   %rax,%rax
    52d1:	74 5d                	je     5330 <fwp_poll_events+0x130>
    52d3:	89 c1                	mov    %eax,%ecx
    52d5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    52dc:	48 c1 e9 26          	shr    $0x26,%rcx
    52e0:	48 63 d1             	movslq %ecx,%rdx
    52e3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    52e9:	29 c8                	sub    %ecx,%eax
    52eb:	48 98                	cltq
    52ed:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    52f4:	e9 11 01 00 00       	jmp    540a <fwp_poll_events+0x20a>
    52f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5300:	e8 6b e9 ff ff       	call   3c70 <fwp_flush>
    5305:	ba 2b 00 00 00       	mov    $0x2b,%edx
    530a:	be 01 00 00 00       	mov    $0x1,%esi
    530f:	48 8b 0d 4a bd 00 00 	mov    0xbd4a(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    5316:	48 8d 3d 13 85 00 00 	lea    0x8513(%rip),%rdi        # d830 <_IO_stdin_used+0x830>
    531d:	e8 5e e3 ff ff       	call   3680 <fwrite@plt>
    5322:	bf 65 00 00 00       	mov    $0x65,%edi
    5327:	e8 44 e3 ff ff       	call   3670 <exit@plt>
    532c:	0f 1f 40 00          	nopl   0x0(%rax)
    5330:	e8 2b f2 ff ff       	call   4560 <fwp_now_ns>
    5335:	48 89 c1             	mov    %rax,%rcx
    5338:	66 0f ef c0          	pxor   %xmm0,%xmm0
    533c:	eb 44                	jmp    5382 <fwp_poll_events+0x182>
    533e:	66 90                	xchg   %ax,%ax
    5340:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5344:	75 33                	jne    5379 <fwp_poll_events+0x179>
    5346:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    534a:	75 2d                	jne    5379 <fwp_poll_events+0x179>
    534c:	48 8b 05 6d c4 01 00 	mov    0x1c46d(%rip),%rax        # 217c0 <fwp_ready_tail>
    5353:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5357:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    535e:	00 00 00 00 
    5362:	48 85 c0             	test   %rax,%rax
    5365:	0f 84 05 01 00 00    	je     5470 <fwp_poll_events+0x270>
    536b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5372:	48 89 15 47 c4 01 00 	mov    %rdx,0x1c447(%rip)        # 217c0 <fwp_ready_tail>
    5379:	48 85 db             	test   %rbx,%rbx
    537c:	0f 84 be 00 00 00    	je     5440 <fwp_poll_events+0x240>
    5382:	48 89 da             	mov    %rbx,%rdx
    5385:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    538c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5390:	7f e7                	jg     5379 <fwp_poll_events+0x179>
    5392:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5396:	74 2e                	je     53c6 <fwp_poll_events+0x1c6>
    5398:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    539f:	48 85 c0             	test   %rax,%rax
    53a2:	0f 84 b8 00 00 00    	je     5460 <fwp_poll_events+0x260>
    53a8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    53af:	48 85 db             	test   %rbx,%rbx
    53b2:	74 07                	je     53bb <fwp_poll_events+0x1bb>
    53b4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    53bb:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    53bf:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    53c6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    53ca:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    53ce:	48 85 c0             	test   %rax,%rax
    53d1:	0f 84 69 ff ff ff    	je     5340 <fwp_poll_events+0x140>
    53d7:	48 39 c8             	cmp    %rcx,%rax
    53da:	0f 8f 60 ff ff ff    	jg     5340 <fwp_poll_events+0x140>
    53e0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    53e4:	0f 85 56 ff ff ff    	jne    5340 <fwp_poll_events+0x140>
    53ea:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    53ee:	75 89                	jne    5379 <fwp_poll_events+0x179>
    53f0:	48 89 d7             	mov    %rdx,%rdi
    53f3:	e8 08 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    53f8:	e9 43 ff ff ff       	jmp    5340 <fwp_poll_events+0x140>
    53fd:	0f 1f 00             	nopl   (%rax)
    5400:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5405:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    540a:	48 89 e7             	mov    %rsp,%rdi
    540d:	31 f6                	xor    %esi,%esi
    540f:	48 89 14 24          	mov    %rdx,(%rsp)
    5413:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5418:	e8 83 e0 ff ff       	call   34a0 <nanosleep@plt>
    541d:	48 8b 1d 94 c3 01 00 	mov    0x1c394(%rip),%rbx        # 217b8 <fwp_timers>
    5424:	e8 37 f1 ff ff       	call   4560 <fwp_now_ns>
    5429:	48 89 c1             	mov    %rax,%rcx
    542c:	48 85 db             	test   %rbx,%rbx
    542f:	0f 85 03 ff ff ff    	jne    5338 <fwp_poll_events+0x138>
    5435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    543c:	00 00 00 00 
    5440:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5445:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    544c:	00 00 
    544e:	75 2c                	jne    547c <fwp_poll_events+0x27c>
    5450:	48 83 c4 20          	add    $0x20,%rsp
    5454:	5b                   	pop    %rbx
    5455:	c3                   	ret
    5456:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    545d:	00 00 00 
    5460:	48 89 1d 51 c3 01 00 	mov    %rbx,0x1c351(%rip)        # 217b8 <fwp_timers>
    5467:	e9 43 ff ff ff       	jmp    53af <fwp_poll_events+0x1af>
    546c:	0f 1f 40 00          	nopl   0x0(%rax)
    5470:	48 89 15 51 c3 01 00 	mov    %rdx,0x1c351(%rip)        # 217c8 <fwp_ready_head>
    5477:	e9 f6 fe ff ff       	jmp    5372 <fwp_poll_events+0x172>
    547c:	e8 df df ff ff       	call   3460 <__stack_chk_fail@plt>
    5481:	0f 1f 40 00          	nopl   0x0(%rax)
    5485:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    548c:	00 00 00 00 

0000000000005490 <fwp_rc_wide_dup>:
    5490:	48 89 fa             	mov    %rdi,%rdx
    5493:	48 8d 35 66 c3 01 00 	lea    0x1c366(%rip),%rsi        # 21800 <fwp_heap>
    549a:	48 83 ec 18          	sub    $0x18,%rsp
    549e:	48 89 f9             	mov    %rdi,%rcx
    54a1:	48 c1 ea 11          	shr    $0x11,%rdx
    54a5:	48 31 fa             	xor    %rdi,%rdx
    54a8:	48 89 d0             	mov    %rdx,%rax
    54ab:	48 c1 e8 09          	shr    $0x9,%rax
    54af:	48 31 c2             	xor    %rax,%rdx
    54b2:	0f b6 d2             	movzbl %dl,%edx
    54b5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    54bc:	00 
    54bd:	49 8b 00             	mov    (%r8),%rax
    54c0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    54c7:	00 00 
    54c9:	75 21                	jne    54ec <fwp_rc_wide_dup+0x5c>
    54cb:	e9 98 00 00 00       	jmp    5568 <fwp_rc_wide_dup+0xd8>
    54d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    54d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    54dc:	00 00 00 00 
    54e0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    54e4:	48 85 d2             	test   %rdx,%rdx
    54e7:	74 2f                	je     5518 <fwp_rc_wide_dup+0x88>
    54e9:	48 89 d0             	mov    %rdx,%rax
    54ec:	48 3b 08             	cmp    (%rax),%rcx
    54ef:	75 ef                	jne    54e0 <fwp_rc_wide_dup+0x50>
    54f1:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54f4:	74 7c                	je     5572 <fwp_rc_wide_dup+0xe2>
    54f6:	48 8b 50 08          	mov    0x8(%rax),%rdx
    54fa:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    54fe:	0f 84 91 00 00 00    	je     5595 <fwp_rc_wide_dup+0x105>
    5504:	48 83 c2 01          	add    $0x1,%rdx
    5508:	48 89 50 08          	mov    %rdx,0x8(%rax)
    550c:	48 83 c4 18          	add    $0x18,%rsp
    5510:	c3                   	ret
    5511:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5518:	4c 8d 40 10          	lea    0x10(%rax),%r8
    551c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    551f:	75 68                	jne    5589 <fwp_rc_wide_dup+0xf9>
    5521:	bf 18 00 00 00       	mov    $0x18,%edi
    5526:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    552b:	4c 89 04 24          	mov    %r8,(%rsp)
    552f:	e8 7c e0 ff ff       	call   35b0 <malloc@plt>
    5534:	4c 8b 04 24          	mov    (%rsp),%r8
    5538:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    553d:	48 85 c0             	test   %rax,%rax
    5540:	74 5f                	je     55a1 <fwp_rc_wide_dup+0x111>
    5542:	48 89 08             	mov    %rcx,(%rax)
    5545:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    554c:	00 
    554d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5554:	00 
    5555:	49 89 00             	mov    %rax,(%r8)
    5558:	c6 01 ff             	movb   $0xff,(%rcx)
    555b:	48 83 05 e5 de 01 00 	addq   $0x1,0x1dee5(%rip)        # 23448 <fwp_heap+0x1c48>
    5562:	01 
    5563:	48 83 c4 18          	add    $0x18,%rsp
    5567:	c3                   	ret
    5568:	80 3f fe             	cmpb   $0xfe,(%rdi)
    556b:	75 13                	jne    5580 <fwp_rc_wide_dup+0xf0>
    556d:	48 85 c0             	test   %rax,%rax
    5570:	74 af                	je     5521 <fwp_rc_wide_dup+0x91>
    5572:	48 8d 3d e7 82 00 00 	lea    0x82e7(%rip),%rdi        # d860 <_IO_stdin_used+0x860>
    5579:	e8 72 ee ff ff       	call   43f0 <fwp_trap>
    557e:	66 90                	xchg   %ax,%ax
    5580:	48 85 c0             	test   %rax,%rax
    5583:	0f 85 6d ff ff ff    	jne    54f6 <fwp_rc_wide_dup+0x66>
    5589:	48 8d 3d f8 82 00 00 	lea    0x82f8(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    5590:	e8 5b ee ff ff       	call   43f0 <fwp_trap>
    5595:	48 8d 3d 97 7b 00 00 	lea    0x7b97(%rip),%rdi        # d133 <_IO_stdin_used+0x133>
    559c:	e8 4f ee ff ff       	call   43f0 <fwp_trap>
    55a1:	e8 0a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    55a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    55ad:	00 00 00 

00000000000055b0 <fwp_rc_forget_slot>:
    55b0:	80 3f ff             	cmpb   $0xff,(%rdi)
    55b3:	74 0b                	je     55c0 <fwp_rc_forget_slot+0x10>
    55b5:	c3                   	ret
    55b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    55bd:	00 00 00 
    55c0:	48 89 f8             	mov    %rdi,%rax
    55c3:	48 83 ec 08          	sub    $0x8,%rsp
    55c7:	48 89 fa             	mov    %rdi,%rdx
    55ca:	48 c1 e8 11          	shr    $0x11,%rax
    55ce:	48 31 f8             	xor    %rdi,%rax
    55d1:	48 89 c1             	mov    %rax,%rcx
    55d4:	48 c1 e9 09          	shr    $0x9,%rcx
    55d8:	48 31 c8             	xor    %rcx,%rax
    55db:	48 8d 0d 1e c2 01 00 	lea    0x1c21e(%rip),%rcx        # 21800 <fwp_heap>
    55e2:	0f b6 c0             	movzbl %al,%eax
    55e5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    55ec:	00 
    55ed:	48 85 ff             	test   %rdi,%rdi
    55f0:	74 3c                	je     562e <fwp_rc_forget_slot+0x7e>
    55f2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    55f9:	00 
    55fa:	48 8b 01             	mov    (%rcx),%rax
    55fd:	eb 11                	jmp    5610 <fwp_rc_forget_slot+0x60>
    55ff:	90                   	nop
    5600:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5604:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5608:	48 85 ff             	test   %rdi,%rdi
    560b:	74 21                	je     562e <fwp_rc_forget_slot+0x7e>
    560d:	48 89 f8             	mov    %rdi,%rax
    5610:	48 3b 10             	cmp    (%rax),%rdx
    5613:	75 eb                	jne    5600 <fwp_rc_forget_slot+0x50>
    5615:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5619:	48 89 01             	mov    %rax,(%rcx)
    561c:	e8 9f dd ff ff       	call   33c0 <free@plt>
    5621:	48 83 2d 1f de 01 00 	subq   $0x1,0x1de1f(%rip)        # 23448 <fwp_heap+0x1c48>
    5628:	01 
    5629:	48 83 c4 08          	add    $0x8,%rsp
    562d:	c3                   	ret
    562e:	48 8d 3d 53 82 00 00 	lea    0x8253(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    5635:	e8 b6 ed ff ff       	call   43f0 <fwp_trap>
    563a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005640 <fwp_rc_prepare_chunk>:
    5640:	48 83 3d 00 de 01 00 	cmpq   $0x0,0x1de00(%rip)        # 23448 <fwp_heap+0x1c48>
    5647:	00 
    5648:	41 54                	push   %r12
    564a:	49 89 f4             	mov    %rsi,%r12
    564d:	55                   	push   %rbp
    564e:	48 89 fd             	mov    %rdi,%rbp
    5651:	53                   	push   %rbx
    5652:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5655:	0f 84 7d 00 00 00    	je     56d8 <fwp_rc_prepare_chunk+0x98>
    565b:	31 db                	xor    %ebx,%ebx
    565d:	85 c0                	test   %eax,%eax
    565f:	75 5f                	jne    56c0 <fwp_rc_prepare_chunk+0x80>
    5661:	48 85 f6             	test   %rsi,%rsi
    5664:	74 7c                	je     56e2 <fwp_rc_prepare_chunk+0xa2>
    5666:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    566a:	e8 51 dd ff ff       	call   33c0 <free@plt>
    566f:	90                   	nop
    5670:	be 01 00 00 00       	mov    $0x1,%esi
    5675:	4c 89 e7             	mov    %r12,%rdi
    5678:	e8 a3 de ff ff       	call   3520 <calloc@plt>
    567d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5681:	48 85 c0             	test   %rax,%rax
    5684:	0f 85 87 00 00 00    	jne    5711 <fwp_rc_prepare_chunk+0xd1>
    568a:	e8 21 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    568f:	90                   	nop
    5690:	e8 1b ff ff ff       	call   55b0 <fwp_rc_forget_slot>
    5695:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5698:	48 83 c3 01          	add    $0x1,%rbx
    569c:	48 39 c3             	cmp    %rax,%rbx
    569f:	73 37                	jae    56d8 <fwp_rc_prepare_chunk+0x98>
    56a1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    56a8:	00 00 
    56aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56b1:	00 00 00 00 
    56b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56bc:	00 00 00 00 
    56c0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56c4:	48 01 df             	add    %rbx,%rdi
    56c7:	80 3f ff             	cmpb   $0xff,(%rdi)
    56ca:	74 c4                	je     5690 <fwp_rc_prepare_chunk+0x50>
    56cc:	8b 45 1c             	mov    0x1c(%rbp),%eax
    56cf:	48 83 c3 01          	add    $0x1,%rbx
    56d3:	48 39 c3             	cmp    %rax,%rbx
    56d6:	72 e8                	jb     56c0 <fwp_rc_prepare_chunk+0x80>
    56d8:	49 39 c4             	cmp    %rax,%r12
    56db:	75 13                	jne    56f0 <fwp_rc_prepare_chunk+0xb0>
    56dd:	4d 85 e4             	test   %r12,%r12
    56e0:	75 46                	jne    5728 <fwp_rc_prepare_chunk+0xe8>
    56e2:	5b                   	pop    %rbx
    56e3:	5d                   	pop    %rbp
    56e4:	41 5c                	pop    %r12
    56e6:	c3                   	ret
    56e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    56ee:	00 00 
    56f0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56f4:	48 29 05 55 dd 01 00 	sub    %rax,0x1dd55(%rip)        # 23450 <fwp_heap+0x1c50>
    56fb:	e8 c0 dc ff ff       	call   33c0 <free@plt>
    5700:	4d 85 e4             	test   %r12,%r12
    5703:	0f 85 67 ff ff ff    	jne    5670 <fwp_rc_prepare_chunk+0x30>
    5709:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5710:	00 
    5711:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5715:	5b                   	pop    %rbx
    5716:	4c 01 25 33 dd 01 00 	add    %r12,0x1dd33(%rip)        # 23450 <fwp_heap+0x1c50>
    571d:	5d                   	pop    %rbp
    571e:	41 5c                	pop    %r12
    5720:	c3                   	ret
    5721:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5728:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    572c:	5b                   	pop    %rbx
    572d:	4c 89 e2             	mov    %r12,%rdx
    5730:	31 f6                	xor    %esi,%esi
    5732:	5d                   	pop    %rbp
    5733:	41 5c                	pop    %r12
    5735:	e9 86 dd ff ff       	jmp    34c0 <memset@plt>
    573a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005740 <fwp_heap_refill>:
    5740:	41 56                	push   %r14
    5742:	41 89 d6             	mov    %edx,%r14d
    5745:	41 55                	push   %r13
    5747:	41 89 f5             	mov    %esi,%r13d
    574a:	41 54                	push   %r12
    574c:	49 89 fc             	mov    %rdi,%r12
    574f:	bf 01 00 00 00       	mov    $0x1,%edi
    5754:	55                   	push   %rbp
    5755:	53                   	push   %rbx
    5756:	e8 25 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    575b:	48 89 c3             	mov    %rax,%rbx
    575e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5762:	48 8b 05 8f d4 01 00 	mov    0x1d48f(%rip),%rax        # 22bf8 <fwp_heap+0x13f8>
    5769:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    576d:	48 8d 05 8c c0 01 00 	lea    0x1c08c(%rip),%rax        # 21800 <fwp_heap>
    5774:	31 d2                	xor    %edx,%edx
    5776:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    577a:	48 89 ef             	mov    %rbp,%rdi
    577d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5781:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5785:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    578c:	00 
    578d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5792:	f7 f1                	div    %ecx
    5794:	31 d2                	xor    %edx,%edx
    5796:	66 0f 6e c1          	movd   %ecx,%xmm0
    579a:	66 0f 6e c8          	movd   %eax,%xmm1
    579e:	89 c6                	mov    %eax,%esi
    57a0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    57a5:	48 01 c8             	add    %rcx,%rax
    57a8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    57ac:	48 f7 f1             	div    %rcx
    57af:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    57b4:	89 45 18             	mov    %eax,0x18(%rbp)
    57b7:	e8 84 fe ff ff       	call   5640 <fwp_rc_prepare_chunk>
    57bc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    57bf:	48 89 d8             	mov    %rbx,%rax
    57c2:	48 c1 e0 10          	shl    $0x10,%rax
    57c6:	48 03 05 e3 d3 01 00 	add    0x1d3e3(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    57cd:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    57d1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    57d6:	8b 55 08             	mov    0x8(%rbp),%edx
    57d9:	48 0f af d1          	imul   %rcx,%rdx
    57dd:	48 01 c2             	add    %rax,%rdx
    57e0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    57e5:	5b                   	pop    %rbx
    57e6:	5d                   	pop    %rbp
    57e7:	41 5c                	pop    %r12
    57e9:	41 5d                	pop    %r13
    57eb:	41 5e                	pop    %r14
    57ed:	c3                   	ret
    57ee:	66 90                	xchg   %ax,%ax

00000000000057f0 <fwp_mem_free>:
    57f0:	48 85 ff             	test   %rdi,%rdi
    57f3:	0f 84 17 02 00 00    	je     5a10 <fwp_mem_free+0x220>
    57f9:	48 8b 35 b0 d3 01 00 	mov    0x1d3b0(%rip),%rsi        # 22bb0 <fwp_heap+0x13b0>
    5800:	48 8b 05 d1 d3 01 00 	mov    0x1d3d1(%rip),%rax        # 22bd8 <fwp_heap+0x13d8>
    5807:	48 89 fa             	mov    %rdi,%rdx
    580a:	48 29 f2             	sub    %rsi,%rdx
    580d:	48 c1 e0 10          	shl    $0x10,%rax
    5811:	48 39 c2             	cmp    %rax,%rdx
    5814:	0f 83 f6 01 00 00    	jae    5a10 <fwp_mem_free+0x220>
    581a:	49 89 d1             	mov    %rdx,%r9
    581d:	49 c1 e9 10          	shr    $0x10,%r9
    5821:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5825:	48 c1 e0 03          	shl    $0x3,%rax
    5829:	49 89 c0             	mov    %rax,%r8
    582c:	4c 03 05 c5 d3 01 00 	add    0x1d3c5(%rip),%r8        # 22bf8 <fwp_heap+0x13f8>
    5833:	0f 84 d7 01 00 00    	je     5a10 <fwp_mem_free+0x220>
    5839:	48 83 ec 38          	sub    $0x38,%rsp
    583d:	48 89 f9             	mov    %rdi,%rcx
    5840:	41 0f b6 38          	movzbl (%r8),%edi
    5844:	40 80 ff 01          	cmp    $0x1,%dil
    5848:	74 16                	je     5860 <fwp_mem_free+0x70>
    584a:	40 80 ff 02          	cmp    $0x2,%dil
    584e:	0f 84 94 00 00 00    	je     58e8 <fwp_mem_free+0xf8>
    5854:	48 83 c4 38          	add    $0x38,%rsp
    5858:	c3                   	ret
    5859:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5860:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5864:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5869:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    586e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5872:	4d 85 d2             	test   %r10,%r10
    5875:	74 1d                	je     5894 <fwp_mem_free+0xa4>
    5877:	0f b7 c1             	movzwl %cx,%eax
    587a:	31 d2                	xor    %edx,%edx
    587c:	48 f7 f7             	div    %rdi
    587f:	49 01 c2             	add    %rax,%r10
    5882:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5886:	0f 84 44 01 00 00    	je     59d0 <fwp_mem_free+0x1e0>
    588c:	41 c6 02 00          	movb   $0x0,(%r10)
    5890:	41 8b 78 04          	mov    0x4(%r8),%edi
    5894:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    589b:	49 63 c1             	movslq %r9d,%rax
    589e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    58a6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    58ab:	f2 0f 58 05 8d d3 01 	addsd  0x1d38d(%rip),%xmm0        # 22c40 <fwp_heap+0x1440>
    58b2:	00 
    58b3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    58b7:	48 8d 05 42 bf 01 00 	lea    0x1bf42(%rip),%rax        # 21800 <fwp_heap>
    58be:	48 01 d0             	add    %rdx,%rax
    58c1:	48 8b 10             	mov    (%rax),%rdx
    58c4:	48 f7 d2             	not    %rdx
    58c7:	48 89 11             	mov    %rdx,(%rcx)
    58ca:	48 89 08             	mov    %rcx,(%rax)
    58cd:	48 29 3d 4c d3 01 00 	sub    %rdi,0x1d34c(%rip)        # 22c20 <fwp_heap+0x1420>
    58d4:	f2 0f 11 05 64 d3 01 	movsd  %xmm0,0x1d364(%rip)        # 22c40 <fwp_heap+0x1440>
    58db:	00 
    58dc:	48 83 c4 38          	add    $0x38,%rsp
    58e0:	c3                   	ret
    58e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    58e8:	66 31 d2             	xor    %dx,%dx
    58eb:	48 01 d6             	add    %rdx,%rsi
    58ee:	48 39 f1             	cmp    %rsi,%rcx
    58f1:	0f 85 5d ff ff ff    	jne    5854 <fwp_mem_free+0x64>
    58f7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    58fb:	48 29 15 1e d3 01 00 	sub    %rdx,0x1d31e(%rip)        # 22c20 <fwp_heap+0x1420>
    5902:	48 85 d2             	test   %rdx,%rdx
    5905:	0f 88 a5 00 00 00    	js     59b0 <fwp_mem_free+0x1c0>
    590b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    590f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5914:	f2 0f 58 05 24 d3 01 	addsd  0x1d324(%rip),%xmm0        # 22c40 <fwp_heap+0x1440>
    591b:	00 
    591c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5920:	f2 0f 11 05 18 d3 01 	movsd  %xmm0,0x1d318(%rip)        # 22c40 <fwp_heap+0x1440>
    5927:	00 
    5928:	48 85 d2             	test   %rdx,%rdx
    592b:	74 0c                	je     5939 <fwp_mem_free+0x149>
    592d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5930:	0f 84 db 00 00 00    	je     5a11 <fwp_mem_free+0x221>
    5936:	c6 02 00             	movb   $0x0,(%rdx)
    5939:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    593d:	48 85 c9             	test   %rcx,%rcx
    5940:	74 3e                	je     5980 <fwp_mem_free+0x190>
    5942:	48 8b 15 af d2 01 00 	mov    0x1d2af(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    5949:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    594d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5951:	48 01 d0             	add    %rdx,%rax
    5954:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5958:	48 89 d6             	mov    %rdx,%rsi
    595b:	48 29 c6             	sub    %rax,%rsi
    595e:	83 e6 08             	and    $0x8,%esi
    5961:	74 0d                	je     5970 <fwp_mem_free+0x180>
    5963:	c6 00 00             	movb   $0x0,(%rax)
    5966:	48 83 c0 28          	add    $0x28,%rax
    596a:	48 39 c2             	cmp    %rax,%rdx
    596d:	74 11                	je     5980 <fwp_mem_free+0x190>
    596f:	90                   	nop
    5970:	c6 00 00             	movb   $0x0,(%rax)
    5973:	48 83 c0 50          	add    $0x50,%rax
    5977:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    597b:	48 39 c2             	cmp    %rax,%rdx
    597e:	75 f0                	jne    5970 <fwp_mem_free+0x180>
    5980:	48 01 0d a9 d2 01 00 	add    %rcx,0x1d2a9(%rip)        # 22c30 <fwp_heap+0x1430>
    5987:	4c 3b 0d 62 d2 01 00 	cmp    0x1d262(%rip),%r9        # 22bf0 <fwp_heap+0x13f0>
    598e:	73 07                	jae    5997 <fwp_mem_free+0x1a7>
    5990:	4c 89 0d 59 d2 01 00 	mov    %r9,0x1d259(%rip)        # 22bf0 <fwp_heap+0x13f0>
    5997:	4c 3b 0d 4a d2 01 00 	cmp    0x1d24a(%rip),%r9        # 22be8 <fwp_heap+0x13e8>
    599e:	0f 83 b0 fe ff ff    	jae    5854 <fwp_mem_free+0x64>
    59a4:	4c 89 0d 3d d2 01 00 	mov    %r9,0x1d23d(%rip)        # 22be8 <fwp_heap+0x13e8>
    59ab:	e9 a4 fe ff ff       	jmp    5854 <fwp_mem_free+0x64>
    59b0:	48 89 d1             	mov    %rdx,%rcx
    59b3:	83 e2 01             	and    $0x1,%edx
    59b6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    59ba:	48 d1 e9             	shr    $1,%rcx
    59bd:	48 09 d1             	or     %rdx,%rcx
    59c0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    59c5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    59c9:	e9 46 ff ff ff       	jmp    5914 <fwp_mem_free+0x124>
    59ce:	66 90                	xchg   %ax,%ax
    59d0:	4c 89 d7             	mov    %r10,%rdi
    59d3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    59d8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    59dd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    59e2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    59e6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    59eb:	e8 c0 fb ff ff       	call   55b0 <fwp_rc_forget_slot>
    59f0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    59f5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    59fa:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    59ff:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5a04:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5a09:	e9 7e fe ff ff       	jmp    588c <fwp_mem_free+0x9c>
    5a0e:	66 90                	xchg   %ax,%ax
    5a10:	c3                   	ret
    5a11:	48 89 d7             	mov    %rdx,%rdi
    5a14:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5a19:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5a1e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5a23:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5a28:	e8 83 fb ff ff       	call   55b0 <fwp_rc_forget_slot>
    5a2d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5a32:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5a37:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5a3c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5a41:	e9 f0 fe ff ff       	jmp    5936 <fwp_mem_free+0x146>
    5a46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5a4d:	00 00 00 

0000000000005a50 <fwp_heap_alloc_big>:
    5a50:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5a57:	00 00 40 
    5a5a:	41 57                	push   %r15
    5a5c:	41 56                	push   %r14
    5a5e:	41 55                	push   %r13
    5a60:	41 54                	push   %r12
    5a62:	55                   	push   %rbp
    5a63:	53                   	push   %rbx
    5a64:	48 83 ec 08          	sub    $0x8,%rsp
    5a68:	48 39 f8             	cmp    %rdi,%rax
    5a6b:	0f 82 fa 00 00 00    	jb     5b6b <fwp_heap_alloc_big+0x11b>
    5a71:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a78:	49 89 fd             	mov    %rdi,%r13
    5a7b:	41 89 f6             	mov    %esi,%r14d
    5a7e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a82:	48 89 ef             	mov    %rbp,%rdi
    5a85:	e8 f6 e4 ff ff       	call   3f80 <fwp_heap_chunks>
    5a8a:	be 01 00 00 00       	mov    $0x1,%esi
    5a8f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a93:	49 89 c4             	mov    %rax,%r12
    5a96:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a9d:	00 
    5a9e:	48 03 3d 53 d1 01 00 	add    0x1d153(%rip),%rdi        # 22bf8 <fwp_heap+0x13f8>
    5aa5:	c6 07 02             	movb   $0x2,(%rdi)
    5aa8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5aac:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5aaf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5ab3:	e8 88 fb ff ff       	call   5640 <fwp_rc_prepare_chunk>
    5ab8:	48 83 fd 01          	cmp    $0x1,%rbp
    5abc:	76 47                	jbe    5b05 <fwp_heap_alloc_big+0xb5>
    5abe:	4c 01 e5             	add    %r12,%rbp
    5ac1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ac8:	00 
    5ac9:	4c 8d 3d 30 bd 01 00 	lea    0x1bd30(%rip),%r15        # 21800 <fwp_heap>
    5ad0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5ad5:	49 c1 e6 03          	shl    $0x3,%r14
    5ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ae0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5ae7:	31 f6                	xor    %esi,%esi
    5ae9:	48 01 dd             	add    %rbx,%rbp
    5aec:	48 83 c3 28          	add    $0x28,%rbx
    5af0:	48 89 ef             	mov    %rbp,%rdi
    5af3:	e8 48 fb ff ff       	call   5640 <fwp_rc_prepare_chunk>
    5af8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5afc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5b00:	49 39 de             	cmp    %rbx,%r14
    5b03:	75 db                	jne    5ae0 <fwp_heap_alloc_big+0x90>
    5b05:	49 c1 e4 10          	shl    $0x10,%r12
    5b09:	4c 03 25 a0 d0 01 00 	add    0x1d0a0(%rip),%r12        # 22bb0 <fwp_heap+0x13b0>
    5b10:	4c 89 ea             	mov    %r13,%rdx
    5b13:	31 f6                	xor    %esi,%esi
    5b15:	4c 89 e7             	mov    %r12,%rdi
    5b18:	e8 a3 d9 ff ff       	call   34c0 <memset@plt>
    5b1d:	4c 89 e8             	mov    %r13,%rax
    5b20:	48 03 05 f9 d0 01 00 	add    0x1d0f9(%rip),%rax        # 22c20 <fwp_heap+0x1420>
    5b27:	72 42                	jb     5b6b <fwp_heap_alloc_big+0x11b>
    5b29:	48 39 05 f8 d0 01 00 	cmp    %rax,0x1d0f8(%rip)        # 22c28 <fwp_heap+0x1428>
    5b30:	48 89 05 e9 d0 01 00 	mov    %rax,0x1d0e9(%rip)        # 22c20 <fwp_heap+0x1420>
    5b37:	73 07                	jae    5b40 <fwp_heap_alloc_big+0xf0>
    5b39:	48 89 05 e8 d0 01 00 	mov    %rax,0x1d0e8(%rip)        # 22c28 <fwp_heap+0x1428>
    5b40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b44:	4c 89 e0             	mov    %r12,%rax
    5b47:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5b4c:	f2 0f 58 05 e4 d0 01 	addsd  0x1d0e4(%rip),%xmm0        # 22c38 <fwp_heap+0x1438>
    5b53:	00 
    5b54:	f2 0f 11 05 dc d0 01 	movsd  %xmm0,0x1d0dc(%rip)        # 22c38 <fwp_heap+0x1438>
    5b5b:	00 
    5b5c:	48 83 c4 08          	add    $0x8,%rsp
    5b60:	5b                   	pop    %rbx
    5b61:	5d                   	pop    %rbp
    5b62:	41 5c                	pop    %r12
    5b64:	41 5d                	pop    %r13
    5b66:	41 5e                	pop    %r14
    5b68:	41 5f                	pop    %r15
    5b6a:	c3                   	ret
    5b6b:	e8 40 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b70 <fwp_heap_alloc_slow>:
    5b70:	53                   	push   %rbx
    5b71:	48 89 f9             	mov    %rdi,%rcx
    5b74:	41 89 f1             	mov    %esi,%r9d
    5b77:	48 83 ec 10          	sub    $0x10,%rsp
    5b7b:	8b 05 23 d0 01 00    	mov    0x1d023(%rip),%eax        # 22ba4 <fwp_heap+0x13a4>
    5b81:	85 c0                	test   %eax,%eax
    5b83:	0f 84 c7 00 00 00    	je     5c50 <fwp_heap_alloc_slow+0xe0>
    5b89:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b90:	0f 87 dd 00 00 00    	ja     5c73 <fwp_heap_alloc_slow+0x103>
    5b96:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b9a:	48 8d 3d 5f bc 01 00 	lea    0x1bc5f(%rip),%rdi        # 21800 <fwp_heap>
    5ba1:	49 63 f1             	movslq %r9d,%rsi
    5ba4:	48 c1 e8 04          	shr    $0x4,%rax
    5ba8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5baf:	00 00 
    5bb1:	41 0f b6 c2          	movzbl %r10b,%eax
    5bb5:	4c 89 d2             	mov    %r10,%rdx
    5bb8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5bbc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5bc3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5bca:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5bce:	48 01 f8             	add    %rdi,%rax
    5bd1:	4c 8b 00             	mov    (%rax),%r8
    5bd4:	4d 85 c0             	test   %r8,%r8
    5bd7:	0f 84 ab 00 00 00    	je     5c88 <fwp_heap_alloc_slow+0x118>
    5bdd:	49 8b 10             	mov    (%r8),%rdx
    5be0:	48 f7 d2             	not    %rdx
    5be3:	48 89 10             	mov    %rdx,(%rax)
    5be6:	41 83 f9 01          	cmp    $0x1,%r9d
    5bea:	4c 89 c7             	mov    %r8,%rdi
    5bed:	48 0f 45 cb          	cmovne %rbx,%rcx
    5bf1:	31 f6                	xor    %esi,%esi
    5bf3:	48 89 ca             	mov    %rcx,%rdx
    5bf6:	e8 c5 d8 ff ff       	call   34c0 <memset@plt>
    5bfb:	49 89 c0             	mov    %rax,%r8
    5bfe:	48 89 d8             	mov    %rbx,%rax
    5c01:	48 03 05 18 d0 01 00 	add    0x1d018(%rip),%rax        # 22c20 <fwp_heap+0x1420>
    5c08:	0f 82 d9 00 00 00    	jb     5ce7 <fwp_heap_alloc_slow+0x177>
    5c0e:	48 39 05 13 d0 01 00 	cmp    %rax,0x1d013(%rip)        # 22c28 <fwp_heap+0x1428>
    5c15:	48 89 05 04 d0 01 00 	mov    %rax,0x1d004(%rip)        # 22c20 <fwp_heap+0x1420>
    5c1c:	73 07                	jae    5c25 <fwp_heap_alloc_slow+0xb5>
    5c1e:	48 89 05 03 d0 01 00 	mov    %rax,0x1d003(%rip)        # 22c28 <fwp_heap+0x1428>
    5c25:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c29:	4c 89 c0             	mov    %r8,%rax
    5c2c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5c31:	f2 0f 58 05 ff cf 01 	addsd  0x1cfff(%rip),%xmm0        # 22c38 <fwp_heap+0x1438>
    5c38:	00 
    5c39:	f2 0f 11 05 f7 cf 01 	movsd  %xmm0,0x1cff7(%rip)        # 22c38 <fwp_heap+0x1438>
    5c40:	00 
    5c41:	48 83 c4 10          	add    $0x10,%rsp
    5c45:	5b                   	pop    %rbx
    5c46:	c3                   	ret
    5c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5c4e:	00 00 
    5c50:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5c54:	48 89 3c 24          	mov    %rdi,(%rsp)
    5c58:	e8 13 f1 ff ff       	call   4d70 <fwp_heap_init>
    5c5d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c61:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c66:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c6d:	0f 86 23 ff ff ff    	jbe    5b96 <fwp_heap_alloc_slow+0x26>
    5c73:	48 83 c4 10          	add    $0x10,%rsp
    5c77:	44 89 ce             	mov    %r9d,%esi
    5c7a:	48 89 cf             	mov    %rcx,%rdi
    5c7d:	5b                   	pop    %rbx
    5c7e:	e9 cd fd ff ff       	jmp    5a50 <fwp_heap_alloc_big>
    5c83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c88:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c8c:	4d 85 c0             	test   %r8,%r8
    5c8f:	74 1f                	je     5cb0 <fwp_heap_alloc_slow+0x140>
    5c91:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c95:	4d 29 c3             	sub    %r8,%r11
    5c98:	49 39 db             	cmp    %rbx,%r11
    5c9b:	72 13                	jb     5cb0 <fwp_heap_alloc_slow+0x140>
    5c9d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ca1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ca5:	e9 3c ff ff ff       	jmp    5be6 <fwp_heap_alloc_slow+0x76>
    5caa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5cb0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5cb7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5cbb:	44 89 ca             	mov    %r9d,%edx
    5cbe:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5cc3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5cc7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5ccb:	44 89 d6             	mov    %r10d,%esi
    5cce:	48 01 c7             	add    %rax,%rdi
    5cd1:	e8 6a fa ff ff       	call   5740 <fwp_heap_refill>
    5cd6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5cdb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5cdf:	49 89 c0             	mov    %rax,%r8
    5ce2:	e9 ff fe ff ff       	jmp    5be6 <fwp_heap_alloc_slow+0x76>
    5ce7:	e8 c4 df ff ff       	call   3cb0 <fwp_heap_oom>
    5cec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005cf0 <fwp_heap_alloc>:
    5cf0:	8b 05 ae ce 01 00    	mov    0x1ceae(%rip),%eax        # 22ba4 <fwp_heap+0x13a4>
    5cf6:	48 89 fa             	mov    %rdi,%rdx
    5cf9:	89 f7                	mov    %esi,%edi
    5cfb:	85 c0                	test   %eax,%eax
    5cfd:	0f 84 f5 00 00 00    	je     5df8 <fwp_heap_alloc+0x108>
    5d03:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5d0a:	0f 87 e8 00 00 00    	ja     5df8 <fwp_heap_alloc+0x108>
    5d10:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5d14:	48 8d 05 e5 ba 01 00 	lea    0x1bae5(%rip),%rax        # 21800 <fwp_heap>
    5d1b:	48 83 ec 18          	sub    $0x18,%rsp
    5d1f:	41 89 f0             	mov    %esi,%r8d
    5d22:	48 c1 e9 04          	shr    $0x4,%rcx
    5d26:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5d2d:	00 
    5d2e:	48 63 cf             	movslq %edi,%rcx
    5d31:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5d38:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5d3f:	00 
    5d40:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5d44:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5d48:	48 01 c8             	add    %rcx,%rax
    5d4b:	48 8b 08             	mov    (%rax),%rcx
    5d4e:	48 85 c9             	test   %rcx,%rcx
    5d51:	74 6d                	je     5dc0 <fwp_heap_alloc+0xd0>
    5d53:	48 8b 31             	mov    (%rcx),%rsi
    5d56:	48 f7 d6             	not    %rsi
    5d59:	48 89 30             	mov    %rsi,(%rax)
    5d5c:	41 83 f8 01          	cmp    $0x1,%r8d
    5d60:	48 89 cf             	mov    %rcx,%rdi
    5d63:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d68:	49 0f 45 d1          	cmovne %r9,%rdx
    5d6c:	31 f6                	xor    %esi,%esi
    5d6e:	e8 4d d7 ff ff       	call   34c0 <memset@plt>
    5d73:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d78:	48 89 c1             	mov    %rax,%rcx
    5d7b:	4c 89 c8             	mov    %r9,%rax
    5d7e:	48 03 05 9b ce 01 00 	add    0x1ce9b(%rip),%rax        # 22c20 <fwp_heap+0x1420>
    5d85:	72 7b                	jb     5e02 <fwp_heap_alloc+0x112>
    5d87:	48 39 05 9a ce 01 00 	cmp    %rax,0x1ce9a(%rip)        # 22c28 <fwp_heap+0x1428>
    5d8e:	48 89 05 8b ce 01 00 	mov    %rax,0x1ce8b(%rip)        # 22c20 <fwp_heap+0x1420>
    5d95:	73 07                	jae    5d9e <fwp_heap_alloc+0xae>
    5d97:	48 89 05 8a ce 01 00 	mov    %rax,0x1ce8a(%rip)        # 22c28 <fwp_heap+0x1428>
    5d9e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5da2:	48 89 c8             	mov    %rcx,%rax
    5da5:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5daa:	f2 0f 58 05 86 ce 01 	addsd  0x1ce86(%rip),%xmm0        # 22c38 <fwp_heap+0x1438>
    5db1:	00 
    5db2:	f2 0f 11 05 7e ce 01 	movsd  %xmm0,0x1ce7e(%rip)        # 22c38 <fwp_heap+0x1438>
    5db9:	00 
    5dba:	48 83 c4 18          	add    $0x18,%rsp
    5dbe:	c3                   	ret
    5dbf:	90                   	nop
    5dc0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5dc4:	48 85 c9             	test   %rcx,%rcx
    5dc7:	74 0c                	je     5dd5 <fwp_heap_alloc+0xe5>
    5dc9:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5dcd:	48 29 ce             	sub    %rcx,%rsi
    5dd0:	4c 39 ce             	cmp    %r9,%rsi
    5dd3:	73 13                	jae    5de8 <fwp_heap_alloc+0xf8>
    5dd5:	89 fe                	mov    %edi,%esi
    5dd7:	48 83 c4 18          	add    $0x18,%rsp
    5ddb:	48 89 d7             	mov    %rdx,%rdi
    5dde:	e9 8d fd ff ff       	jmp    5b70 <fwp_heap_alloc_slow>
    5de3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5de8:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5dec:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5df0:	e9 67 ff ff ff       	jmp    5d5c <fwp_heap_alloc+0x6c>
    5df5:	0f 1f 00             	nopl   (%rax)
    5df8:	89 fe                	mov    %edi,%esi
    5dfa:	48 89 d7             	mov    %rdx,%rdi
    5dfd:	e9 6e fd ff ff       	jmp    5b70 <fwp_heap_alloc_slow>
    5e02:	e8 a9 de ff ff       	call   3cb0 <fwp_heap_oom>
    5e07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e0e:	00 00 

0000000000005e10 <fwp_apply>:
    5e10:	55                   	push   %rbp
    5e11:	48 89 f9             	mov    %rdi,%rcx
    5e14:	48 89 e5             	mov    %rsp,%rbp
    5e17:	41 57                	push   %r15
    5e19:	41 56                	push   %r14
    5e1b:	41 55                	push   %r13
    5e1d:	41 89 f5             	mov    %esi,%r13d
    5e20:	41 54                	push   %r12
    5e22:	53                   	push   %rbx
    5e23:	48 83 ec 28          	sub    $0x28,%rsp
    5e27:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5e2e:	00 00 
    5e30:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5e34:	49 89 d6             	mov    %rdx,%r14
    5e37:	44 8b 09             	mov    (%rcx),%r9d
    5e3a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5e3e:	49 89 e0             	mov    %rsp,%r8
    5e41:	49 c1 e1 05          	shl    $0x5,%r9
    5e45:	4c 03 0d 0c d6 01 00 	add    0x1d60c(%rip),%r9        # 23458 <fwp_fns>
    5e4c:	41 8b 19             	mov    (%r9),%ebx
    5e4f:	45 85 e4             	test   %r12d,%r12d
    5e52:	75 2c                	jne    5e80 <fwp_apply+0x70>
    5e54:	41 39 dd             	cmp    %ebx,%r13d
    5e57:	72 27                	jb     5e80 <fwp_apply+0x70>
    5e59:	85 db                	test   %ebx,%ebx
    5e5b:	0f 84 a7 01 00 00    	je     6008 <fwp_apply+0x1f8>
    5e61:	4c 89 f7             	mov    %r14,%rdi
    5e64:	41 ff 51 08          	call   *0x8(%r9)
    5e68:	48 89 c1             	mov    %rax,%rcx
    5e6b:	41 39 dd             	cmp    %ebx,%r13d
    5e6e:	0f 84 6c 01 00 00    	je     5fe0 <fwp_apply+0x1d0>
    5e74:	89 d8                	mov    %ebx,%eax
    5e76:	41 29 dd             	sub    %ebx,%r13d
    5e79:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5e7d:	eb b8                	jmp    5e37 <fwp_apply+0x27>
    5e7f:	90                   	nop
    5e80:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5e85:	41 39 df             	cmp    %ebx,%r15d
    5e88:	0f 82 cc 00 00 00    	jb     5f5a <fwp_apply+0x14a>
    5e8e:	41 89 df             	mov    %ebx,%r15d
    5e91:	b8 01 00 00 00       	mov    $0x1,%eax
    5e96:	48 89 e2             	mov    %rsp,%rdx
    5e99:	45 29 e7             	sub    %r12d,%r15d
    5e9c:	85 db                	test   %ebx,%ebx
    5e9e:	0f 45 c3             	cmovne %ebx,%eax
    5ea1:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5ea8:	00 
    5ea9:	48 c1 e8 04          	shr    $0x4,%rax
    5ead:	48 c1 e0 04          	shl    $0x4,%rax
    5eb1:	48 89 c6             	mov    %rax,%rsi
    5eb4:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5ebb:	48 29 f2             	sub    %rsi,%rdx
    5ebe:	48 39 d4             	cmp    %rdx,%rsp
    5ec1:	74 15                	je     5ed8 <fwp_apply+0xc8>
    5ec3:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5eca:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5ed1:	00 00 
    5ed3:	48 39 d4             	cmp    %rdx,%rsp
    5ed6:	75 eb                	jne    5ec3 <fwp_apply+0xb3>
    5ed8:	25 ff 0f 00 00       	and    $0xfff,%eax
    5edd:	48 29 c4             	sub    %rax,%rsp
    5ee0:	48 85 c0             	test   %rax,%rax
    5ee3:	0f 85 49 01 00 00    	jne    6032 <fwp_apply+0x222>
    5ee9:	45 89 e2             	mov    %r12d,%r10d
    5eec:	48 89 e6             	mov    %rsp,%rsi
    5eef:	48 89 e7             	mov    %rsp,%rdi
    5ef2:	31 c0                	xor    %eax,%eax
    5ef4:	49 c1 e2 03          	shl    $0x3,%r10
    5ef8:	45 85 e4             	test   %r12d,%r12d
    5efb:	74 15                	je     5f12 <fwp_apply+0x102>
    5efd:	0f 1f 00             	nopl   (%rax)
    5f00:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5f05:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5f09:	48 83 c0 08          	add    $0x8,%rax
    5f0d:	4c 39 d0             	cmp    %r10,%rax
    5f10:	75 ee                	jne    5f00 <fwp_apply+0xf0>
    5f12:	45 85 ff             	test   %r15d,%r15d
    5f15:	0f 84 f4 00 00 00    	je     600f <fwp_apply+0x1ff>
    5f1b:	44 89 fa             	mov    %r15d,%edx
    5f1e:	4c 89 f0             	mov    %r14,%rax
    5f21:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5f25:	44 89 e2             	mov    %r12d,%edx
    5f28:	66 90                	xchg   %ax,%ax
    5f2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f31:	00 00 00 00 
    5f35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f3c:	00 00 00 00 
    5f40:	4c 8b 10             	mov    (%rax),%r10
    5f43:	89 d1                	mov    %edx,%ecx
    5f45:	48 83 c0 08          	add    $0x8,%rax
    5f49:	83 c2 01             	add    $0x1,%edx
    5f4c:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5f50:	4c 39 d8             	cmp    %r11,%rax
    5f53:	75 eb                	jne    5f40 <fwp_apply+0x130>
    5f55:	e9 b5 00 00 00       	jmp    600f <fwp_apply+0x1ff>
    5f5a:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5f5e:	be 02 00 00 00       	mov    $0x2,%esi
    5f63:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5f67:	48 c1 e7 03          	shl    $0x3,%rdi
    5f6b:	e8 80 fd ff ff       	call   5cf0 <fwp_heap_alloc>
    5f70:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5f74:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5f79:	48 89 c3             	mov    %rax,%rbx
    5f7c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5f80:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5f84:	66 0f d6 00          	movq   %xmm0,(%rax)
    5f88:	45 85 e4             	test   %r12d,%r12d
    5f8b:	74 14                	je     5fa1 <fwp_apply+0x191>
    5f8d:	44 89 e2             	mov    %r12d,%edx
    5f90:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5f94:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5f98:	48 c1 e2 03          	shl    $0x3,%rdx
    5f9c:	e8 6f d6 ff ff       	call   3610 <memmove@plt>
    5fa1:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5fa5:	45 85 ed             	test   %r13d,%r13d
    5fa8:	74 2e                	je     5fd8 <fwp_apply+0x1c8>
    5faa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5fb1:	00 00 00 00 
    5fb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5fbc:	00 00 00 00 
    5fc0:	49 8b 16             	mov    (%r14),%rdx
    5fc3:	44 89 e0             	mov    %r12d,%eax
    5fc6:	49 83 c6 08          	add    $0x8,%r14
    5fca:	41 83 c4 01          	add    $0x1,%r12d
    5fce:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5fd3:	49 39 ce             	cmp    %rcx,%r14
    5fd6:	75 e8                	jne    5fc0 <fwp_apply+0x1b0>
    5fd8:	48 89 d9             	mov    %rbx,%rcx
    5fdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5fe0:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5fe4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5feb:	00 00 
    5fed:	75 4e                	jne    603d <fwp_apply+0x22d>
    5fef:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5ff3:	48 89 c8             	mov    %rcx,%rax
    5ff6:	5b                   	pop    %rbx
    5ff7:	41 5c                	pop    %r12
    5ff9:	41 5d                	pop    %r13
    5ffb:	41 5e                	pop    %r14
    5ffd:	41 5f                	pop    %r15
    5fff:	5d                   	pop    %rbp
    6000:	c3                   	ret
    6001:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6008:	45 31 ff             	xor    %r15d,%r15d
    600b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    600f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    6013:	41 ff 51 08          	call   *0x8(%r9)
    6017:	48 89 c1             	mov    %rax,%rcx
    601a:	45 39 fd             	cmp    %r15d,%r13d
    601d:	74 c1                	je     5fe0 <fwp_apply+0x1d0>
    601f:	45 01 e5             	add    %r12d,%r13d
    6022:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    6026:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    602a:	41 29 dd             	sub    %ebx,%r13d
    602d:	e9 05 fe ff ff       	jmp    5e37 <fwp_apply+0x27>
    6032:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    6038:	e9 ac fe ff ff       	jmp    5ee9 <fwp_apply+0xd9>
    603d:	e8 1e d4 ff ff       	call   3460 <__stack_chk_fail@plt>
    6042:	0f 1f 00             	nopl   (%rax)
    6045:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    604c:	00 00 00 00 

0000000000006050 <fwp_p_ad_push>:
    6050:	41 57                	push   %r15
    6052:	41 56                	push   %r14
    6054:	41 55                	push   %r13
    6056:	49 89 d5             	mov    %rdx,%r13
    6059:	41 54                	push   %r12
    605b:	49 89 fc             	mov    %rdi,%r12
    605e:	55                   	push   %rbp
    605f:	53                   	push   %rbx
    6060:	48 83 ec 38          	sub    $0x38,%rsp
    6064:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6069:	48 85 ff             	test   %rdi,%rdi
    606c:	79 09                	jns    6077 <fwp_p_ad_push+0x27>
    606e:	48 85 d2             	test   %rdx,%rdx
    6071:	0f 88 a9 01 00 00    	js     6220 <fwp_p_ad_push+0x1d0>
    6077:	48 89 f8             	mov    %rdi,%rax
    607a:	48 89 0c 24          	mov    %rcx,(%rsp)
    607e:	48 09 d0             	or     %rdx,%rax
    6081:	0f 89 79 01 00 00    	jns    6200 <fwp_p_ad_push+0x1b0>
    6087:	48 89 f8             	mov    %rdi,%rax
    608a:	48 c1 f8 20          	sar    $0x20,%rax
    608e:	48 85 ff             	test   %rdi,%rdi
    6091:	79 24                	jns    60b7 <fwp_p_ad_push+0x67>
    6093:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6098:	48 89 d0             	mov    %rdx,%rax
    609b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    60a2:	00 
    60a3:	49 89 d4             	mov    %rdx,%r12
    60a6:	48 c1 f8 20          	sar    $0x20,%rax
    60aa:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    60b1:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    60b7:	48 89 c7             	mov    %rax,%rdi
    60ba:	e8 11 e6 ff ff       	call   46d0 <fwp_tape_of>
    60bf:	48 89 c3             	mov    %rax,%rbx
    60c2:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    60c7:	0f 85 76 02 00 00    	jne    6343 <fwp_p_ad_push+0x2f3>
    60cd:	4c 8b 78 10          	mov    0x10(%rax),%r15
    60d1:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    60d8:	0f 8f 59 02 00 00    	jg     6337 <fwp_p_ad_push+0x2e7>
    60de:	44 89 e0             	mov    %r12d,%eax
    60e1:	4c 39 f8             	cmp    %r15,%rax
    60e4:	0f 8d 41 02 00 00    	jge    632b <fwp_p_ad_push+0x2db>
    60ea:	4d 85 ed             	test   %r13,%r13
    60ed:	78 0c                	js     60fb <fwp_p_ad_push+0xab>
    60ef:	44 89 e8             	mov    %r13d,%eax
    60f2:	4c 39 f8             	cmp    %r15,%rax
    60f5:	0f 8d 30 02 00 00    	jge    632b <fwp_p_ad_push+0x2db>
    60fb:	4d 89 fe             	mov    %r15,%r14
    60fe:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6102:	49 8d 46 01          	lea    0x1(%r14),%rax
    6106:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    610c:	0f 87 25 02 00 00    	ja     6337 <fwp_p_ad_push+0x2e7>
    6112:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    6116:	48 39 e8             	cmp    %rbp,%rax
    6119:	0f 8e 31 01 00 00    	jle    6250 <fwp_p_ad_push+0x200>
    611f:	48 85 ed             	test   %rbp,%rbp
    6122:	b9 40 00 00 00       	mov    $0x40,%ecx
    6127:	48 0f 44 e9          	cmove  %rcx,%rbp
    612b:	48 39 e8             	cmp    %rbp,%rax
    612e:	7e 20                	jle    6150 <fwp_p_ad_push+0x100>
    6130:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    6137:	0f 8f 03 01 00 00    	jg     6240 <fwp_p_ad_push+0x1f0>
    613d:	48 01 ed             	add    %rbp,%rbp
    6140:	48 39 e8             	cmp    %rbp,%rax
    6143:	7f eb                	jg     6130 <fwp_p_ad_push+0xe0>
    6145:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    614c:	00 00 00 00 
    6150:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6157:	00 
    6158:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    615c:	48 89 c6             	mov    %rax,%rsi
    615f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6164:	e8 67 d4 ff ff       	call   35d0 <realloc@plt>
    6169:	48 85 c0             	test   %rax,%rax
    616c:	0f 84 dd 01 00 00    	je     634f <fwp_p_ad_push+0x2ff>
    6172:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    6176:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    617a:	48 89 43 20          	mov    %rax,0x20(%rbx)
    617e:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    6182:	48 89 e9             	mov    %rbp,%rcx
    6185:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6189:	48 c1 e1 04          	shl    $0x4,%rcx
    618d:	48 89 ce             	mov    %rcx,%rsi
    6190:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6195:	e8 36 d4 ff ff       	call   35d0 <realloc@plt>
    619a:	48 85 c0             	test   %rax,%rax
    619d:	0f 84 ac 01 00 00    	je     634f <fwp_p_ad_push+0x2ff>
    61a3:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    61a7:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    61ac:	4d 85 f6             	test   %r14,%r14
    61af:	48 89 43 30          	mov    %rax,0x30(%rbx)
    61b3:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    61b8:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    61bf:	00 
    61c0:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    61c7:	00 
    61c8:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    61cc:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    61d3:	00 
    61d4:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    61d8:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    61dc:	0f 85 e2 00 00 00    	jne    62c4 <fwp_p_ad_push+0x274>
    61e2:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    61e6:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    61ea:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    61ee:	49 01 c8             	add    %rcx,%r8
    61f1:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    61f5:	eb 79                	jmp    6270 <fwp_p_ad_push+0x220>
    61f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    61fe:	00 00 
    6200:	48 89 d0             	mov    %rdx,%rax
    6203:	48 c1 ff 20          	sar    $0x20,%rdi
    6207:	48 c1 f8 20          	sar    $0x20,%rax
    620b:	48 39 c7             	cmp    %rax,%rdi
    620e:	0f 84 a3 fe ff ff    	je     60b7 <fwp_p_ad_push+0x67>
    6214:	48 8d 3d 95 76 00 00 	lea    0x7695(%rip),%rdi        # d8b0 <_IO_stdin_used+0x8b0>
    621b:	e8 d0 e1 ff ff       	call   43f0 <fwp_trap>
    6220:	48 83 c4 38          	add    $0x38,%rsp
    6224:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    622b:	5b                   	pop    %rbx
    622c:	5d                   	pop    %rbp
    622d:	41 5c                	pop    %r12
    622f:	41 5d                	pop    %r13
    6231:	41 5e                	pop    %r14
    6233:	41 5f                	pop    %r15
    6235:	c3                   	ret
    6236:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    623d:	00 00 00 
    6240:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    6245:	e9 06 ff ff ff       	jmp    6150 <fwp_p_ad_push+0x100>
    624a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6250:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    6254:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6258:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    625f:	00 
    6260:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6267:	00 
    6268:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    626c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6270:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6276:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    627a:	4d 85 ed             	test   %r13,%r13
    627d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6282:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6288:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    628f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6293:	49 8d 47 01          	lea    0x1(%r15),%rax
    6297:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    629b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    62a1:	48 89 43 10          	mov    %rax,0x10(%rbx)
    62a5:	48 83 c4 38          	add    $0x38,%rsp
    62a9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    62b0:	ff ff ff 
    62b3:	4c 21 e0             	and    %r12,%rax
    62b6:	5b                   	pop    %rbx
    62b7:	5d                   	pop    %rbp
    62b8:	4c 09 f8             	or     %r15,%rax
    62bb:	41 5c                	pop    %r12
    62bd:	41 5d                	pop    %r13
    62bf:	41 5e                	pop    %r14
    62c1:	41 5f                	pop    %r15
    62c3:	c3                   	ret
    62c4:	48 39 ca             	cmp    %rcx,%rdx
    62c7:	49 89 d6             	mov    %rdx,%r14
    62ca:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    62cf:	48 0f 43 ca          	cmovae %rdx,%rcx
    62d3:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    62d8:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    62dd:	48 29 d1             	sub    %rdx,%rcx
    62e0:	4c 89 ca             	mov    %r9,%rdx
    62e3:	e8 78 d2 ff ff       	call   3560 <__memmove_chk@plt>
    62e8:	4c 03 73 30          	add    0x30(%rbx),%r14
    62ec:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    62f1:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    62f5:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    62fa:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    62fe:	48 03 7b 20          	add    0x20(%rbx),%rdi
    6302:	4c 89 d2             	mov    %r10,%rdx
    6305:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    630a:	e8 01 d3 ff ff       	call   3610 <memmove@plt>
    630f:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6313:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6317:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    631c:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    6321:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    6326:	e9 bb fe ff ff       	jmp    61e6 <fwp_p_ad_push+0x196>
    632b:	48 8d 3d 35 6e 00 00 	lea    0x6e35(%rip),%rdi        # d167 <_IO_stdin_used+0x167>
    6332:	e8 b9 e0 ff ff       	call   43f0 <fwp_trap>
    6337:	48 8d 3d 0e 6e 00 00 	lea    0x6e0e(%rip),%rdi        # d14c <_IO_stdin_used+0x14c>
    633e:	e8 ad e0 ff ff       	call   43f0 <fwp_trap>
    6343:	48 8d 3d ae 75 00 00 	lea    0x75ae(%rip),%rdi        # d8f8 <_IO_stdin_used+0x8f8>
    634a:	e8 a1 e0 ff ff       	call   43f0 <fwp_trap>
    634f:	48 89 df             	mov    %rbx,%rdi
    6352:	e8 a9 d8 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6357:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    635b:	e8 60 d0 ff ff       	call   33c0 <free@plt>
    6360:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6364:	e8 57 d0 ff ff       	call   33c0 <free@plt>
    6369:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    636d:	e8 4e d0 ff ff       	call   33c0 <free@plt>
    6372:	31 c9                	xor    %ecx,%ecx
    6374:	31 c0                	xor    %eax,%eax
    6376:	31 d2                	xor    %edx,%edx
    6378:	89 53 04             	mov    %edx,0x4(%rbx)
    637b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    637f:	ba 13 00 00 00       	mov    $0x13,%edx
    6384:	be 01 00 00 00       	mov    $0x1,%esi
    6389:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    638d:	48 8d 3d 74 6c 00 00 	lea    0x6c74(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    6394:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6398:	48 8b 0d c1 ac 00 00 	mov    0xacc1(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    639f:	48 89 43 40          	mov    %rax,0x40(%rbx)
    63a3:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    63a7:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    63ab:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    63af:	e8 cc d2 ff ff       	call   3680 <fwrite@plt>
    63b4:	31 ff                	xor    %edi,%edi
    63b6:	e8 05 d2 ff ff       	call   35c0 <fflush@plt>
    63bb:	bf 66 00 00 00       	mov    $0x66,%edi
    63c0:	e8 db d2 ff ff       	call   36a0 <_Exit@plt>
    63c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    63cc:	00 00 00 00 

00000000000063d0 <w107>:
    63d0:	66 0f 28 e0          	movapd %xmm0,%xmm4
    63d4:	41 55                	push   %r13
    63d6:	48 89 fa             	mov    %rdi,%rdx
    63d9:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    63dd:	41 54                	push   %r12
    63df:	49 89 fc             	mov    %rdi,%r12
    63e2:	55                   	push   %rbp
    63e3:	53                   	push   %rbx
    63e4:	48 89 f3             	mov    %rsi,%rbx
    63e7:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    63ec:	48 89 f1             	mov    %rsi,%rcx
    63ef:	48 83 ec 28          	sub    $0x28,%rsp
    63f3:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    63f9:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    63ff:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6405:	e8 46 fc ff ff       	call   6050 <fwp_p_ad_push>
    640a:	48 89 c7             	mov    %rax,%rdi
    640d:	e8 4e eb ff ff       	call   4f60 <caf61>
    6412:	66 48 0f 6e c0       	movq   %rax,%xmm0
    6417:	e8 44 eb ff ff       	call   4f60 <caf61>
    641c:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6422:	66 0f 57 05 c6 77 00 	xorpd  0x77c6(%rip),%xmm0        # dbf0 <msg.8+0x80>
    6429:	00 
    642a:	48 89 da             	mov    %rbx,%rdx
    642d:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6433:	48 89 c1             	mov    %rax,%rcx
    6436:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    643b:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6440:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6446:	e8 05 fc ff ff       	call   6050 <fwp_p_ad_push>
    644b:	4c 89 e7             	mov    %r12,%rdi
    644e:	49 89 c5             	mov    %rax,%r13
    6451:	e8 0a eb ff ff       	call   4f60 <caf61>
    6456:	48 89 c6             	mov    %rax,%rsi
    6459:	e8 02 eb ff ff       	call   4f60 <caf61>
    645e:	66 48 0f 6e d6       	movq   %rsi,%xmm2
    6463:	f2 0f 10 05 c5 77 00 	movsd  0x77c5(%rip),%xmm0        # dc30 <msg.8+0xc0>
    646a:	00 
    646b:	66 0f 57 15 7d 77 00 	xorpd  0x777d(%rip),%xmm2        # dbf0 <msg.8+0x80>
    6472:	00 
    6473:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    6479:	48 89 c1             	mov    %rax,%rcx
    647c:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6483:	66 48 0f 7e d6       	movq   %xmm2,%rsi
    6488:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    648d:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6493:	e8 b8 fb ff ff       	call   6050 <fwp_p_ad_push>
    6498:	48 89 e9             	mov    %rbp,%rcx
    649b:	4c 89 ea             	mov    %r13,%rdx
    649e:	48 89 ee             	mov    %rbp,%rsi
    64a1:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    64a7:	4c 89 ef             	mov    %r13,%rdi
    64aa:	49 89 c4             	mov    %rax,%r12
    64ad:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    64b1:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    64b7:	e8 94 fb ff ff       	call   6050 <fwp_p_ad_push>
    64bc:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    64c2:	f2 0f 59 1d 6e 77 00 	mulsd  0x776e(%rip),%xmm3        # dc38 <msg.8+0xc8>
    64c9:	00 
    64ca:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    64d1:	00 59 40 
    64d4:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    64d9:	48 89 c2             	mov    %rax,%rdx
    64dc:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    64e3:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    64e9:	e8 62 fb ff ff       	call   6050 <fwp_p_ad_push>
    64ee:	4c 89 e2             	mov    %r12,%rdx
    64f1:	48 89 d9             	mov    %rbx,%rcx
    64f4:	48 89 de             	mov    %rbx,%rsi
    64f7:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    64fd:	4c 89 e7             	mov    %r12,%rdi
    6500:	48 89 c5             	mov    %rax,%rbp
    6503:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6507:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    650d:	e8 3e fb ff ff       	call   6050 <fwp_p_ad_push>
    6512:	48 89 c7             	mov    %rax,%rdi
    6515:	e8 46 ea ff ff       	call   4f60 <caf61>
    651a:	48 89 c6             	mov    %rax,%rsi
    651d:	e8 3e ea ff ff       	call   4f60 <caf61>
    6522:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6528:	48 89 ea             	mov    %rbp,%rdx
    652b:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6531:	48 89 c1             	mov    %rax,%rcx
    6534:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6539:	e8 12 fb ff ff       	call   6050 <fwp_p_ad_push>
    653e:	48 83 c4 28          	add    $0x28,%rsp
    6542:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    6547:	5b                   	pop    %rbx
    6548:	5d                   	pop    %rbp
    6549:	41 5c                	pop    %r12
    654b:	41 5d                	pop    %r13
    654d:	c3                   	ret
    654e:	66 90                	xchg   %ax,%ax

0000000000006550 <w164.constprop.0>:
    6550:	41 54                	push   %r12
    6552:	55                   	push   %rbp
    6553:	53                   	push   %rbx
    6554:	48 83 ec 10          	sub    $0x10,%rsp
    6558:	4c 8b 27             	mov    (%rdi),%r12
    655b:	4d 85 e4             	test   %r12,%r12
    655e:	74 78                	je     65d8 <w164.constprop.0+0x88>
    6560:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    6567:	00 00 
    6569:	48 89 fd             	mov    %rdi,%rbp
    656c:	31 db                	xor    %ebx,%ebx
    656e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6575:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    657c:	00 00 00 00 
    6580:	4c 8b 44 dd 10       	mov    0x10(%rbp,%rbx,8),%r8
    6585:	f2 0f 10 44 dd 08    	movsd  0x8(%rbp,%rbx,8),%xmm0
    658b:	48 83 c3 02          	add    $0x2,%rbx
    658f:	e8 cc e9 ff ff       	call   4f60 <caf61>
    6594:	48 89 c6             	mov    %rax,%rsi
    6597:	e8 c4 e9 ff ff       	call   4f60 <caf61>
    659c:	f2 0f 58 44 24 08    	addsd  0x8(%rsp),%xmm0
    65a2:	4c 89 c2             	mov    %r8,%rdx
    65a5:	48 89 c1             	mov    %rax,%rcx
    65a8:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    65ae:	e8 9d fa ff ff       	call   6050 <fwp_p_ad_push>
    65b3:	48 89 c7             	mov    %rax,%rdi
    65b6:	4c 39 e3             	cmp    %r12,%rbx
    65b9:	72 c5                	jb     6580 <w164.constprop.0+0x30>
    65bb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    65c0:	48 83 c4 10          	add    $0x10,%rsp
    65c4:	5b                   	pop    %rbx
    65c5:	5d                   	pop    %rbp
    65c6:	66 48 0f 6e c0       	movq   %rax,%xmm0
    65cb:	41 5c                	pop    %r12
    65cd:	48 89 f8             	mov    %rdi,%rax
    65d0:	c3                   	ret
    65d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    65d8:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    65df:	00 00 
    65e1:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    65e8:	eb d1                	jmp    65bb <w164.constprop.0+0x6b>
    65ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000065f0 <fwp_data.part.0.constprop.0>:
    65f0:	41 56                	push   %r14
    65f2:	41 89 fe             	mov    %edi,%r14d
    65f5:	41 54                	push   %r12
    65f7:	49 89 f4             	mov    %rsi,%r12
    65fa:	55                   	push   %rbp
    65fb:	53                   	push   %rbx
    65fc:	48 83 ec 08          	sub    $0x8,%rsp
    6600:	8b 05 9e c5 01 00    	mov    0x1c59e(%rip),%eax        # 22ba4 <fwp_heap+0x13a4>
    6606:	85 c0                	test   %eax,%eax
    6608:	0f 84 fa 00 00 00    	je     6708 <fwp_data.part.0.constprop.0+0x118>
    660e:	0f b6 05 8d c1 01 00 	movzbl 0x1c18d(%rip),%eax        # 227a2 <fwp_heap+0xfa2>
    6615:	48 8d 15 e4 b1 01 00 	lea    0x1b1e4(%rip),%rdx        # 21800 <fwp_heap>
    661c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6623:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6627:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    662b:	48 8b 18             	mov    (%rax),%rbx
    662e:	48 85 db             	test   %rbx,%rbx
    6631:	0f 84 a9 00 00 00    	je     66e0 <fwp_data.part.0.constprop.0+0xf0>
    6637:	48 8b 13             	mov    (%rbx),%rdx
    663a:	48 f7 d2             	not    %rdx
    663d:	48 89 10             	mov    %rdx,(%rax)
    6640:	48 83 fd 18          	cmp    $0x18,%rbp
    6644:	76 1b                	jbe    6661 <fwp_data.part.0.constprop.0+0x71>
    6646:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    664a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    664e:	31 f6                	xor    %esi,%esi
    6650:	48 c1 e8 03          	shr    $0x3,%rax
    6654:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    665b:	00 
    665c:	e8 5f ce ff ff       	call   34c0 <memset@plt>
    6661:	48 89 e8             	mov    %rbp,%rax
    6664:	48 03 05 b5 c5 01 00 	add    0x1c5b5(%rip),%rax        # 22c20 <fwp_heap+0x1420>
    666b:	0f 82 a8 00 00 00    	jb     6719 <fwp_data.part.0.constprop.0+0x129>
    6671:	48 39 05 b0 c5 01 00 	cmp    %rax,0x1c5b0(%rip)        # 22c28 <fwp_heap+0x1428>
    6678:	48 89 05 a1 c5 01 00 	mov    %rax,0x1c5a1(%rip)        # 22c20 <fwp_heap+0x1420>
    667f:	73 07                	jae    6688 <fwp_data.part.0.constprop.0+0x98>
    6681:	48 89 05 a0 c5 01 00 	mov    %rax,0x1c5a0(%rip)        # 22c28 <fwp_heap+0x1428>
    6688:	66 0f ef c0          	pxor   %xmm0,%xmm0
    668c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6691:	f2 0f 58 05 9f c5 01 	addsd  0x1c59f(%rip),%xmm0        # 22c38 <fwp_heap+0x1438>
    6698:	00 
    6699:	f2 0f 11 05 97 c5 01 	movsd  %xmm0,0x1c597(%rip)        # 22c38 <fwp_heap+0x1438>
    66a0:	00 
    66a1:	b8 02 00 00 00       	mov    $0x2,%eax
    66a6:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    66ab:	66 0f 6e c8          	movd   %eax,%xmm1
    66af:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    66b3:	66 0f d6 03          	movq   %xmm0,(%rbx)
    66b7:	49 8b 04 24          	mov    (%r12),%rax
    66bb:	48 89 43 08          	mov    %rax,0x8(%rbx)
    66bf:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    66c4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    66c8:	48 83 c4 08          	add    $0x8,%rsp
    66cc:	48 89 d8             	mov    %rbx,%rax
    66cf:	5b                   	pop    %rbx
    66d0:	5d                   	pop    %rbp
    66d1:	41 5c                	pop    %r12
    66d3:	41 5e                	pop    %r14
    66d5:	c3                   	ret
    66d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    66dd:	00 00 00 
    66e0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    66e4:	48 85 db             	test   %rbx,%rbx
    66e7:	74 1f                	je     6708 <fwp_data.part.0.constprop.0+0x118>
    66e9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    66ed:	48 29 da             	sub    %rbx,%rdx
    66f0:	48 39 ea             	cmp    %rbp,%rdx
    66f3:	72 13                	jb     6708 <fwp_data.part.0.constprop.0+0x118>
    66f5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    66f9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    66fd:	e9 3e ff ff ff       	jmp    6640 <fwp_data.part.0.constprop.0+0x50>
    6702:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6708:	31 f6                	xor    %esi,%esi
    670a:	bf 18 00 00 00       	mov    $0x18,%edi
    670f:	e8 dc f5 ff ff       	call   5cf0 <fwp_heap_alloc>
    6714:	48 89 c3             	mov    %rax,%rbx
    6717:	eb 88                	jmp    66a1 <fwp_data.part.0.constprop.0+0xb1>
    6719:	e8 92 d5 ff ff       	call   3cb0 <fwp_heap_oom>
    671e:	66 90                	xchg   %ax,%ax

0000000000006720 <fwp_rc_share>:
    6720:	48 8b 05 b1 c4 01 00 	mov    0x1c4b1(%rip),%rax        # 22bd8 <fwp_heap+0x13d8>
    6727:	48 2b 3d 82 c4 01 00 	sub    0x1c482(%rip),%rdi        # 22bb0 <fwp_heap+0x13b0>
    672e:	48 c1 e0 10          	shl    $0x10,%rax
    6732:	48 39 c7             	cmp    %rax,%rdi
    6735:	73 4a                	jae    6781 <fwp_rc_share+0x61>
    6737:	48 89 f8             	mov    %rdi,%rax
    673a:	48 c1 e8 10          	shr    $0x10,%rax
    673e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6742:	48 8b 05 af c4 01 00 	mov    0x1c4af(%rip),%rax        # 22bf8 <fwp_heap+0x13f8>
    6749:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    674d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6751:	48 85 d2             	test   %rdx,%rdx
    6754:	74 2b                	je     6781 <fwp_rc_share+0x61>
    6756:	0f b6 08             	movzbl (%rax),%ecx
    6759:	80 f9 02             	cmp    $0x2,%cl
    675c:	74 2a                	je     6788 <fwp_rc_share+0x68>
    675e:	80 f9 01             	cmp    $0x1,%cl
    6761:	75 1e                	jne    6781 <fwp_rc_share+0x61>
    6763:	8b 48 18             	mov    0x18(%rax),%ecx
    6766:	0f b7 ff             	movzwl %di,%edi
    6769:	8b 40 1c             	mov    0x1c(%rax),%eax
    676c:	48 0f af f9          	imul   %rcx,%rdi
    6770:	48 c1 ef 20          	shr    $0x20,%rdi
    6774:	48 39 c7             	cmp    %rax,%rdi
    6777:	73 08                	jae    6781 <fwp_rc_share+0x61>
    6779:	48 01 fa             	add    %rdi,%rdx
    677c:	80 3a 00             	cmpb   $0x0,(%rdx)
    677f:	75 0d                	jne    678e <fwp_rc_share+0x6e>
    6781:	c3                   	ret
    6782:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6788:	66 85 ff             	test   %di,%di
    678b:	74 ef                	je     677c <fwp_rc_share+0x5c>
    678d:	c3                   	ret
    678e:	50                   	push   %rax
    678f:	48 8d 3d 92 71 00 00 	lea    0x7192(%rip),%rdi        # d928 <_IO_stdin_used+0x928>
    6796:	e8 55 dc ff ff       	call   43f0 <fwp_trap>
    679b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000067a0 <fwp_rc_free_arr>:
    67a0:	48 8b 15 31 c4 01 00 	mov    0x1c431(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    67a7:	48 89 f8             	mov    %rdi,%rax
    67aa:	48 2b 05 ff c3 01 00 	sub    0x1c3ff(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    67b1:	48 c1 e2 10          	shl    $0x10,%rdx
    67b5:	48 39 d0             	cmp    %rdx,%rax
    67b8:	73 5b                	jae    6815 <fwp_rc_free_arr+0x75>
    67ba:	48 89 c2             	mov    %rax,%rdx
    67bd:	48 c1 ea 10          	shr    $0x10,%rdx
    67c1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    67c5:	48 8b 15 2c c4 01 00 	mov    0x1c42c(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    67cc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    67d0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    67d4:	48 85 c9             	test   %rcx,%rcx
    67d7:	74 3c                	je     6815 <fwp_rc_free_arr+0x75>
    67d9:	0f b6 32             	movzbl (%rdx),%esi
    67dc:	40 80 fe 02          	cmp    $0x2,%sil
    67e0:	74 2e                	je     6810 <fwp_rc_free_arr+0x70>
    67e2:	40 80 fe 01          	cmp    $0x1,%sil
    67e6:	75 2d                	jne    6815 <fwp_rc_free_arr+0x75>
    67e8:	8b 72 18             	mov    0x18(%rdx),%esi
    67eb:	0f b7 c0             	movzwl %ax,%eax
    67ee:	8b 52 1c             	mov    0x1c(%rdx),%edx
    67f1:	48 0f af c6          	imul   %rsi,%rax
    67f5:	48 c1 e8 20          	shr    $0x20,%rax
    67f9:	48 39 d0             	cmp    %rdx,%rax
    67fc:	73 17                	jae    6815 <fwp_rc_free_arr+0x75>
    67fe:	48 01 c1             	add    %rax,%rcx
    6801:	80 39 01             	cmpb   $0x1,(%rcx)
    6804:	75 0f                	jne    6815 <fwp_rc_free_arr+0x75>
    6806:	e9 e5 ef ff ff       	jmp    57f0 <fwp_mem_free>
    680b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6810:	66 85 c0             	test   %ax,%ax
    6813:	74 ec                	je     6801 <fwp_rc_free_arr+0x61>
    6815:	c3                   	ret
    6816:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    681d:	00 00 00 

0000000000006820 <fwp_rc_dup>:
    6820:	f3 0f 1e fa          	endbr64
    6824:	48 8b 05 ad c3 01 00 	mov    0x1c3ad(%rip),%rax        # 22bd8 <fwp_heap+0x13d8>
    682b:	48 2b 3d 7e c3 01 00 	sub    0x1c37e(%rip),%rdi        # 22bb0 <fwp_heap+0x13b0>
    6832:	48 c1 e0 10          	shl    $0x10,%rax
    6836:	48 39 c7             	cmp    %rax,%rdi
    6839:	73 56                	jae    6891 <fwp_rc_dup+0x71>
    683b:	48 89 f8             	mov    %rdi,%rax
    683e:	48 c1 e8 10          	shr    $0x10,%rax
    6842:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6846:	48 8b 05 ab c3 01 00 	mov    0x1c3ab(%rip),%rax        # 22bf8 <fwp_heap+0x13f8>
    684d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6851:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6855:	48 85 c0             	test   %rax,%rax
    6858:	74 37                	je     6891 <fwp_rc_dup+0x71>
    685a:	0f b6 0a             	movzbl (%rdx),%ecx
    685d:	80 f9 02             	cmp    $0x2,%cl
    6860:	74 36                	je     6898 <fwp_rc_dup+0x78>
    6862:	80 f9 01             	cmp    $0x1,%cl
    6865:	75 2a                	jne    6891 <fwp_rc_dup+0x71>
    6867:	8b 4a 18             	mov    0x18(%rdx),%ecx
    686a:	0f b7 ff             	movzwl %di,%edi
    686d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6870:	48 0f af f9          	imul   %rcx,%rdi
    6874:	48 c1 ef 20          	shr    $0x20,%rdi
    6878:	48 39 d7             	cmp    %rdx,%rdi
    687b:	73 14                	jae    6891 <fwp_rc_dup+0x71>
    687d:	48 01 f8             	add    %rdi,%rax
    6880:	0f b6 10             	movzbl (%rax),%edx
    6883:	84 d2                	test   %dl,%dl
    6885:	74 0a                	je     6891 <fwp_rc_dup+0x71>
    6887:	80 fa fd             	cmp    $0xfd,%dl
    688a:	77 14                	ja     68a0 <fwp_rc_dup+0x80>
    688c:	83 c2 01             	add    $0x1,%edx
    688f:	88 10                	mov    %dl,(%rax)
    6891:	c3                   	ret
    6892:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6898:	66 85 ff             	test   %di,%di
    689b:	74 e3                	je     6880 <fwp_rc_dup+0x60>
    689d:	c3                   	ret
    689e:	66 90                	xchg   %ax,%ax
    68a0:	48 89 c7             	mov    %rax,%rdi
    68a3:	e9 e8 eb ff ff       	jmp    5490 <fwp_rc_wide_dup>
    68a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    68af:	00 

00000000000068b0 <fwp_drop0>:
    68b0:	f3 0f 1e fa          	endbr64
    68b4:	48 8b 15 1d c3 01 00 	mov    0x1c31d(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    68bb:	48 89 f8             	mov    %rdi,%rax
    68be:	48 2b 05 eb c2 01 00 	sub    0x1c2eb(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    68c5:	48 c1 e2 10          	shl    $0x10,%rdx
    68c9:	48 39 d0             	cmp    %rdx,%rax
    68cc:	0f 83 be 00 00 00    	jae    6990 <fwp_drop0+0xe0>
    68d2:	48 83 ec 18          	sub    $0x18,%rsp
    68d6:	4c 8d 05 23 af 01 00 	lea    0x1af23(%rip),%r8        # 21800 <fwp_heap>
    68dd:	48 89 c2             	mov    %rax,%rdx
    68e0:	48 c1 ea 10          	shr    $0x10,%rdx
    68e4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    68e8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    68ef:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    68f3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    68f7:	48 85 d2             	test   %rdx,%rdx
    68fa:	74 3c                	je     6938 <fwp_drop0+0x88>
    68fc:	0f b6 31             	movzbl (%rcx),%esi
    68ff:	40 80 fe 02          	cmp    $0x2,%sil
    6903:	74 3b                	je     6940 <fwp_drop0+0x90>
    6905:	40 80 fe 01          	cmp    $0x1,%sil
    6909:	75 2d                	jne    6938 <fwp_drop0+0x88>
    690b:	8b 71 18             	mov    0x18(%rcx),%esi
    690e:	0f b7 c0             	movzwl %ax,%eax
    6911:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6914:	48 0f af c6          	imul   %rsi,%rax
    6918:	48 c1 e8 20          	shr    $0x20,%rax
    691c:	48 39 c8             	cmp    %rcx,%rax
    691f:	73 17                	jae    6938 <fwp_drop0+0x88>
    6921:	48 01 c2             	add    %rax,%rdx
    6924:	0f b6 02             	movzbl (%rdx),%eax
    6927:	84 c0                	test   %al,%al
    6929:	74 0d                	je     6938 <fwp_drop0+0x88>
    692b:	3c 01                	cmp    $0x1,%al
    692d:	74 21                	je     6950 <fwp_drop0+0xa0>
    692f:	3c ff                	cmp    $0xff,%al
    6931:	74 65                	je     6998 <fwp_drop0+0xe8>
    6933:	83 e8 01             	sub    $0x1,%eax
    6936:	88 02                	mov    %al,(%rdx)
    6938:	48 83 c4 18          	add    $0x18,%rsp
    693c:	c3                   	ret
    693d:	0f 1f 00             	nopl   (%rax)
    6940:	66 85 c0             	test   %ax,%ax
    6943:	74 df                	je     6924 <fwp_drop0+0x74>
    6945:	48 83 c4 18          	add    $0x18,%rsp
    6949:	c3                   	ret
    694a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6950:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6954:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6959:	e8 42 fe ff ff       	call   67a0 <fwp_rc_free_arr>
    695e:	4c 8d 05 9b ae 01 00 	lea    0x1ae9b(%rip),%r8        # 21800 <fwp_heap>
    6965:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    696a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6971:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6978:	48 c1 e2 10          	shl    $0x10,%rdx
    697c:	48 39 d0             	cmp    %rdx,%rax
    697f:	73 b7                	jae    6938 <fwp_drop0+0x88>
    6981:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6986:	e9 52 ff ff ff       	jmp    68dd <fwp_drop0+0x2d>
    698b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6990:	c3                   	ret
    6991:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6998:	48 89 d0             	mov    %rdx,%rax
    699b:	48 c1 e8 11          	shr    $0x11,%rax
    699f:	48 31 d0             	xor    %rdx,%rax
    69a2:	48 89 c1             	mov    %rax,%rcx
    69a5:	48 c1 e9 09          	shr    $0x9,%rcx
    69a9:	48 31 c8             	xor    %rcx,%rax
    69ac:	0f b6 c8             	movzbl %al,%ecx
    69af:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    69b6:	00 
    69b7:	48 85 c0             	test   %rax,%rax
    69ba:	75 0d                	jne    69c9 <fwp_drop0+0x119>
    69bc:	eb 46                	jmp    6a04 <fwp_drop0+0x154>
    69be:	66 90                	xchg   %ax,%ax
    69c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    69c4:	48 85 c0             	test   %rax,%rax
    69c7:	74 3b                	je     6a04 <fwp_drop0+0x154>
    69c9:	48 89 c1             	mov    %rax,%rcx
    69cc:	48 39 10             	cmp    %rdx,(%rax)
    69cf:	75 ef                	jne    69c0 <fwp_drop0+0x110>
    69d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    69d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    69d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    69dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    69e4:	0f 85 4e ff ff ff    	jne    6938 <fwp_drop0+0x88>
    69ea:	48 89 d7             	mov    %rdx,%rdi
    69ed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    69f2:	e8 b9 eb ff ff       	call   55b0 <fwp_rc_forget_slot>
    69f7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    69fc:	c6 02 fe             	movb   $0xfe,(%rdx)
    69ff:	e9 34 ff ff ff       	jmp    6938 <fwp_drop0+0x88>
    6a04:	48 8d 3d 7d 6e 00 00 	lea    0x6e7d(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    6a0b:	e8 e0 d9 ff ff       	call   43f0 <fwp_trap>

0000000000006a10 <fwp_arg_drop12>:
    6a10:	f3 0f 1e fa          	endbr64
    6a14:	85 f6                	test   %esi,%esi
    6a16:	75 04                	jne    6a1c <fwp_arg_drop12+0xc>
    6a18:	85 d2                	test   %edx,%edx
    6a1a:	75 04                	jne    6a20 <fwp_arg_drop12+0x10>
    6a1c:	c3                   	ret
    6a1d:	0f 1f 00             	nopl   (%rax)
    6a20:	48 8b 3f             	mov    (%rdi),%rdi
    6a23:	e9 88 fe ff ff       	jmp    68b0 <fwp_drop0>
    6a28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6a2f:	00 

0000000000006a30 <fwp_drop1>:
    6a30:	f3 0f 1e fa          	endbr64
    6a34:	48 8b 15 9d c1 01 00 	mov    0x1c19d(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    6a3b:	48 89 f8             	mov    %rdi,%rax
    6a3e:	48 2b 05 6b c1 01 00 	sub    0x1c16b(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    6a45:	48 c1 e2 10          	shl    $0x10,%rdx
    6a49:	48 39 d0             	cmp    %rdx,%rax
    6a4c:	0f 83 be 00 00 00    	jae    6b10 <fwp_drop1+0xe0>
    6a52:	48 83 ec 18          	sub    $0x18,%rsp
    6a56:	4c 8d 05 a3 ad 01 00 	lea    0x1ada3(%rip),%r8        # 21800 <fwp_heap>
    6a5d:	48 89 c2             	mov    %rax,%rdx
    6a60:	48 c1 ea 10          	shr    $0x10,%rdx
    6a64:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6a68:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6a6f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6a73:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6a77:	48 85 d2             	test   %rdx,%rdx
    6a7a:	74 3c                	je     6ab8 <fwp_drop1+0x88>
    6a7c:	0f b6 31             	movzbl (%rcx),%esi
    6a7f:	40 80 fe 02          	cmp    $0x2,%sil
    6a83:	74 3b                	je     6ac0 <fwp_drop1+0x90>
    6a85:	40 80 fe 01          	cmp    $0x1,%sil
    6a89:	75 2d                	jne    6ab8 <fwp_drop1+0x88>
    6a8b:	8b 71 18             	mov    0x18(%rcx),%esi
    6a8e:	0f b7 c0             	movzwl %ax,%eax
    6a91:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6a94:	48 0f af c6          	imul   %rsi,%rax
    6a98:	48 c1 e8 20          	shr    $0x20,%rax
    6a9c:	48 39 c8             	cmp    %rcx,%rax
    6a9f:	73 17                	jae    6ab8 <fwp_drop1+0x88>
    6aa1:	48 01 c2             	add    %rax,%rdx
    6aa4:	0f b6 02             	movzbl (%rdx),%eax
    6aa7:	84 c0                	test   %al,%al
    6aa9:	74 0d                	je     6ab8 <fwp_drop1+0x88>
    6aab:	3c 01                	cmp    $0x1,%al
    6aad:	74 21                	je     6ad0 <fwp_drop1+0xa0>
    6aaf:	3c ff                	cmp    $0xff,%al
    6ab1:	74 65                	je     6b18 <fwp_drop1+0xe8>
    6ab3:	83 e8 01             	sub    $0x1,%eax
    6ab6:	88 02                	mov    %al,(%rdx)
    6ab8:	48 83 c4 18          	add    $0x18,%rsp
    6abc:	c3                   	ret
    6abd:	0f 1f 00             	nopl   (%rax)
    6ac0:	66 85 c0             	test   %ax,%ax
    6ac3:	74 df                	je     6aa4 <fwp_drop1+0x74>
    6ac5:	48 83 c4 18          	add    $0x18,%rsp
    6ac9:	c3                   	ret
    6aca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ad0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6ad4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6ad9:	e8 c2 fc ff ff       	call   67a0 <fwp_rc_free_arr>
    6ade:	4c 8d 05 1b ad 01 00 	lea    0x1ad1b(%rip),%r8        # 21800 <fwp_heap>
    6ae5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6aea:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6af1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6af8:	48 c1 e2 10          	shl    $0x10,%rdx
    6afc:	48 39 d0             	cmp    %rdx,%rax
    6aff:	73 b7                	jae    6ab8 <fwp_drop1+0x88>
    6b01:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6b06:	e9 52 ff ff ff       	jmp    6a5d <fwp_drop1+0x2d>
    6b0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6b10:	c3                   	ret
    6b11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b18:	48 89 d0             	mov    %rdx,%rax
    6b1b:	48 c1 e8 11          	shr    $0x11,%rax
    6b1f:	48 31 d0             	xor    %rdx,%rax
    6b22:	48 89 c1             	mov    %rax,%rcx
    6b25:	48 c1 e9 09          	shr    $0x9,%rcx
    6b29:	48 31 c8             	xor    %rcx,%rax
    6b2c:	0f b6 c8             	movzbl %al,%ecx
    6b2f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6b36:	00 
    6b37:	48 85 c0             	test   %rax,%rax
    6b3a:	75 0d                	jne    6b49 <fwp_drop1+0x119>
    6b3c:	eb 46                	jmp    6b84 <fwp_drop1+0x154>
    6b3e:	66 90                	xchg   %ax,%ax
    6b40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6b44:	48 85 c0             	test   %rax,%rax
    6b47:	74 3b                	je     6b84 <fwp_drop1+0x154>
    6b49:	48 89 c1             	mov    %rax,%rcx
    6b4c:	48 39 10             	cmp    %rdx,(%rax)
    6b4f:	75 ef                	jne    6b40 <fwp_drop1+0x110>
    6b51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6b55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6b59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6b5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6b64:	0f 85 4e ff ff ff    	jne    6ab8 <fwp_drop1+0x88>
    6b6a:	48 89 d7             	mov    %rdx,%rdi
    6b6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6b72:	e8 39 ea ff ff       	call   55b0 <fwp_rc_forget_slot>
    6b77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6b7c:	c6 02 fe             	movb   $0xfe,(%rdx)
    6b7f:	e9 34 ff ff ff       	jmp    6ab8 <fwp_drop1+0x88>
    6b84:	48 8d 3d fd 6c 00 00 	lea    0x6cfd(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    6b8b:	e8 60 d8 ff ff       	call   43f0 <fwp_trap>

0000000000006b90 <fwp_closure_drop>:
    6b90:	48 8b 15 41 c0 01 00 	mov    0x1c041(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    6b97:	48 89 f8             	mov    %rdi,%rax
    6b9a:	48 2b 05 0f c0 01 00 	sub    0x1c00f(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    6ba1:	48 c1 e2 10          	shl    $0x10,%rdx
    6ba5:	48 39 d0             	cmp    %rdx,%rax
    6ba8:	73 6b                	jae    6c15 <fwp_closure_drop+0x85>
    6baa:	48 89 c2             	mov    %rax,%rdx
    6bad:	48 c1 ea 10          	shr    $0x10,%rdx
    6bb1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6bb5:	48 8b 15 3c c0 01 00 	mov    0x1c03c(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    6bbc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6bc0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6bc4:	48 85 d2             	test   %rdx,%rdx
    6bc7:	74 4c                	je     6c15 <fwp_closure_drop+0x85>
    6bc9:	0f b6 31             	movzbl (%rcx),%esi
    6bcc:	40 80 fe 02          	cmp    $0x2,%sil
    6bd0:	74 3e                	je     6c10 <fwp_closure_drop+0x80>
    6bd2:	40 80 fe 01          	cmp    $0x1,%sil
    6bd6:	75 3d                	jne    6c15 <fwp_closure_drop+0x85>
    6bd8:	8b 71 18             	mov    0x18(%rcx),%esi
    6bdb:	0f b7 c0             	movzwl %ax,%eax
    6bde:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6be1:	48 0f af c6          	imul   %rsi,%rax
    6be5:	48 c1 e8 20          	shr    $0x20,%rax
    6be9:	48 39 c8             	cmp    %rcx,%rax
    6bec:	73 27                	jae    6c15 <fwp_closure_drop+0x85>
    6bee:	48 01 c2             	add    %rax,%rdx
    6bf1:	0f b6 02             	movzbl (%rdx),%eax
    6bf4:	84 c0                	test   %al,%al
    6bf6:	74 1d                	je     6c15 <fwp_closure_drop+0x85>
    6bf8:	3c 01                	cmp    $0x1,%al
    6bfa:	74 24                	je     6c20 <fwp_closure_drop+0x90>
    6bfc:	3c ff                	cmp    $0xff,%al
    6bfe:	74 48                	je     6c48 <fwp_closure_drop+0xb8>
    6c00:	83 e8 01             	sub    $0x1,%eax
    6c03:	88 02                	mov    %al,(%rdx)
    6c05:	c3                   	ret
    6c06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c0d:	00 00 00 
    6c10:	66 85 c0             	test   %ax,%ax
    6c13:	74 dc                	je     6bf1 <fwp_closure_drop+0x61>
    6c15:	c3                   	ret
    6c16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c1d:	00 00 00 
    6c20:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6c27:	ff ff 
    6c29:	48 85 c0             	test   %rax,%rax
    6c2c:	74 12                	je     6c40 <fwp_closure_drop+0xb0>
    6c2e:	48 89 fe             	mov    %rdi,%rsi
    6c31:	48 89 c7             	mov    %rax,%rdi
    6c34:	e9 17 d8 ff ff       	jmp    4450 <fwp_closure_drop_push>
    6c39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c40:	e9 bb d9 ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    6c45:	0f 1f 00             	nopl   (%rax)
    6c48:	48 89 d0             	mov    %rdx,%rax
    6c4b:	48 8d 35 ae ab 01 00 	lea    0x1abae(%rip),%rsi        # 21800 <fwp_heap>
    6c52:	48 83 ec 18          	sub    $0x18,%rsp
    6c56:	48 c1 e8 11          	shr    $0x11,%rax
    6c5a:	48 31 d0             	xor    %rdx,%rax
    6c5d:	48 89 c1             	mov    %rax,%rcx
    6c60:	48 c1 e9 09          	shr    $0x9,%rcx
    6c64:	48 31 c8             	xor    %rcx,%rax
    6c67:	0f b6 c8             	movzbl %al,%ecx
    6c6a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6c71:	00 
    6c72:	48 85 c0             	test   %rax,%rax
    6c75:	75 12                	jne    6c89 <fwp_closure_drop+0xf9>
    6c77:	eb 49                	jmp    6cc2 <fwp_closure_drop+0x132>
    6c79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6c84:	48 85 c0             	test   %rax,%rax
    6c87:	74 39                	je     6cc2 <fwp_closure_drop+0x132>
    6c89:	48 89 c1             	mov    %rax,%rcx
    6c8c:	48 39 10             	cmp    %rdx,(%rax)
    6c8f:	75 ef                	jne    6c80 <fwp_closure_drop+0xf0>
    6c91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6c95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6c99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6c9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6ca4:	74 05                	je     6cab <fwp_closure_drop+0x11b>
    6ca6:	48 83 c4 18          	add    $0x18,%rsp
    6caa:	c3                   	ret
    6cab:	48 89 d7             	mov    %rdx,%rdi
    6cae:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6cb3:	e8 f8 e8 ff ff       	call   55b0 <fwp_rc_forget_slot>
    6cb8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6cbd:	c6 02 fe             	movb   $0xfe,(%rdx)
    6cc0:	eb e4                	jmp    6ca6 <fwp_closure_drop+0x116>
    6cc2:	48 8d 3d bf 6b 00 00 	lea    0x6bbf(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    6cc9:	e8 22 d7 ff ff       	call   43f0 <fwp_trap>
    6cce:	66 90                	xchg   %ax,%ax

0000000000006cd0 <fwp_owned_tape_release>:
    6cd0:	48 85 ff             	test   %rdi,%rdi
    6cd3:	0f 84 f7 00 00 00    	je     6dd0 <fwp_owned_tape_release+0x100>
    6cd9:	41 54                	push   %r12
    6cdb:	55                   	push   %rbp
    6cdc:	53                   	push   %rbx
    6cdd:	48 8b 07             	mov    (%rdi),%rax
    6ce0:	48 85 c0             	test   %rax,%rax
    6ce3:	74 08                	je     6ced <fwp_owned_tape_release+0x1d>
    6ce5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6ce9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6ced:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6cf1:	48 85 d2             	test   %rdx,%rdx
    6cf4:	74 03                	je     6cf9 <fwp_owned_tape_release+0x29>
    6cf6:	48 89 02             	mov    %rax,(%rdx)
    6cf9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6cfd:	48 89 fb             	mov    %rdi,%rbx
    6d00:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6d04:	48 85 c0             	test   %rax,%rax
    6d07:	0f 84 89 00 00 00    	je     6d96 <fwp_owned_tape_release+0xc6>
    6d0d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6d11:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6d15:	7e 47                	jle    6d5e <fwp_owned_tape_release+0x8e>
    6d17:	31 ed                	xor    %ebp,%ebp
    6d19:	eb 0d                	jmp    6d28 <fwp_owned_tape_release+0x58>
    6d1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6d20:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6d24:	48 8b 40 68          	mov    0x68(%rax),%rax
    6d28:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6d2c:	49 89 ec             	mov    %rbp,%r12
    6d2f:	48 83 c5 01          	add    $0x1,%rbp
    6d33:	49 c1 e4 04          	shl    $0x4,%r12
    6d37:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6d3b:	ff d0                	call   *%rax
    6d3d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6d41:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6d46:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6d4a:	ff 50 68             	call   *0x68(%rax)
    6d4d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6d51:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6d55:	48 39 e8             	cmp    %rbp,%rax
    6d58:	7f c6                	jg     6d20 <fwp_owned_tape_release+0x50>
    6d5a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6d5e:	31 ed                	xor    %ebp,%ebp
    6d60:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6d65:	7e 28                	jle    6d8f <fwp_owned_tape_release+0xbf>
    6d67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6d6e:	00 00 
    6d70:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6d74:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6d78:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6d7c:	74 07                	je     6d85 <fwp_owned_tape_release+0xb5>
    6d7e:	ff 52 68             	call   *0x68(%rdx)
    6d81:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6d85:	48 83 c5 01          	add    $0x1,%rbp
    6d89:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6d8d:	7f e1                	jg     6d70 <fwp_owned_tape_release+0xa0>
    6d8f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6d93:	ff 52 68             	call   *0x68(%rdx)
    6d96:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6d9a:	e8 f1 fd ff ff       	call   6b90 <fwp_closure_drop>
    6d9f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6da3:	e8 e8 fd ff ff       	call   6b90 <fwp_closure_drop>
    6da8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6dac:	e8 df fd ff ff       	call   6b90 <fwp_closure_drop>
    6db1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6db5:	e8 36 ea ff ff       	call   57f0 <fwp_mem_free>
    6dba:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6dbe:	e8 2d ea ff ff       	call   57f0 <fwp_mem_free>
    6dc3:	48 89 df             	mov    %rbx,%rdi
    6dc6:	5b                   	pop    %rbx
    6dc7:	5d                   	pop    %rbp
    6dc8:	41 5c                	pop    %r12
    6dca:	e9 21 ea ff ff       	jmp    57f0 <fwp_mem_free>
    6dcf:	90                   	nop
    6dd0:	c3                   	ret
    6dd1:	0f 1f 40 00          	nopl   0x0(%rax)
    6dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6ddc:	00 00 00 00 

0000000000006de0 <fwp_tape_finish>:
    6de0:	f3 0f 1e fa          	endbr64
    6de4:	41 56                	push   %r14
    6de6:	48 8d 3d f3 a2 01 00 	lea    0x1a2f3(%rip),%rdi        # 210e0 <fwp_tape_workspace>
    6ded:	41 55                	push   %r13
    6def:	41 54                	push   %r12
    6df1:	55                   	push   %rbp
    6df2:	53                   	push   %rbx
    6df3:	e8 18 d3 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    6df8:	48 83 3d 28 a3 01 00 	cmpq   $0x0,0x1a328(%rip)        # 21128 <fwp_ntapes>
    6dff:	00 
    6e00:	48 c7 05 bd a2 01 00 	movq   $0x0,0x1a2bd(%rip)        # 210c8 <fwp_tape_cached_bytes>
    6e07:	00 00 00 00 
    6e0b:	7e 68                	jle    6e75 <fwp_tape_finish+0x95>
    6e0d:	45 31 e4             	xor    %r12d,%r12d
    6e10:	31 ed                	xor    %ebp,%ebp
    6e12:	0f 1f 00             	nopl   (%rax)
    6e15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e1c:	00 00 00 00 
    6e20:	48 8b 1d 09 a3 01 00 	mov    0x1a309(%rip),%rbx        # 21130 <fwp_tapes>
    6e27:	48 83 c5 01          	add    $0x1,%rbp
    6e2b:	4c 01 e3             	add    %r12,%rbx
    6e2e:	49 83 c4 68          	add    $0x68,%r12
    6e32:	48 89 df             	mov    %rbx,%rdi
    6e35:	e8 c6 cd ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6e3a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6e3e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6e42:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6e46:	e8 75 c5 ff ff       	call   33c0 <free@plt>
    6e4b:	4c 89 f7             	mov    %r14,%rdi
    6e4e:	e8 6d c5 ff ff       	call   33c0 <free@plt>
    6e53:	4c 89 ef             	mov    %r13,%rdi
    6e56:	e8 65 c5 ff ff       	call   33c0 <free@plt>
    6e5b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6e5f:	e8 6c fe ff ff       	call   6cd0 <fwp_owned_tape_release>
    6e64:	48 39 2d bd a2 01 00 	cmp    %rbp,0x1a2bd(%rip)        # 21128 <fwp_ntapes>
    6e6b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6e72:	00 
    6e73:	7f ab                	jg     6e20 <fwp_tape_finish+0x40>
    6e75:	48 8b 3d b4 a2 01 00 	mov    0x1a2b4(%rip),%rdi        # 21130 <fwp_tapes>
    6e7c:	e8 3f c5 ff ff       	call   33c0 <free@plt>
    6e81:	5b                   	pop    %rbx
    6e82:	5d                   	pop    %rbp
    6e83:	48 c7 05 a2 a2 01 00 	movq   $0x0,0x1a2a2(%rip)        # 21130 <fwp_tapes>
    6e8a:	00 00 00 00 
    6e8e:	48 c7 05 87 a2 01 00 	movq   $0x0,0x1a287(%rip)        # 21120 <fwp_tapes_cap>
    6e95:	00 00 00 00 
    6e99:	41 5c                	pop    %r12
    6e9b:	48 c7 05 82 a2 01 00 	movq   $0x0,0x1a282(%rip)        # 21128 <fwp_ntapes>
    6ea2:	00 00 00 00 
    6ea6:	41 5d                	pop    %r13
    6ea8:	48 c7 05 65 a2 01 00 	movq   $0x0,0x1a265(%rip)        # 21118 <fwp_tape_next_slot>
    6eaf:	00 00 00 00 
    6eb3:	41 5e                	pop    %r14
    6eb5:	c3                   	ret
    6eb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6ebd:	00 00 00 

0000000000006ec0 <fwp_tape_scope_release>:
    6ec0:	f3 0f 1e fa          	endbr64
    6ec4:	41 55                	push   %r13
    6ec6:	41 54                	push   %r12
    6ec8:	55                   	push   %rbp
    6ec9:	53                   	push   %rbx
    6eca:	48 83 ec 58          	sub    $0x58,%rsp
    6ece:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6ed5:	00 00 
    6ed7:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6edc:	48 63 07             	movslq (%rdi),%rax
    6edf:	85 c0                	test   %eax,%eax
    6ee1:	0f 88 05 01 00 00    	js     6fec <fwp_tape_scope_release+0x12c>
    6ee7:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6eee:	ec c4 4e 
    6ef1:	48 89 fb             	mov    %rdi,%rbx
    6ef4:	eb 3c                	jmp    6f32 <fwp_tape_scope_release+0x72>
    6ef6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6efd:	00 00 00 
    6f00:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6f05:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6f09:	e8 b2 c4 ff ff       	call   33c0 <free@plt>
    6f0e:	48 8b 3c 24          	mov    (%rsp),%rdi
    6f12:	e8 a9 c4 ff ff       	call   33c0 <free@plt>
    6f17:	4c 89 ef             	mov    %r13,%rdi
    6f1a:	e8 a1 c4 ff ff       	call   33c0 <free@plt>
    6f1f:	4c 89 e7             	mov    %r12,%rdi
    6f22:	e8 a9 fd ff ff       	call   6cd0 <fwp_owned_tape_release>
    6f27:	48 63 03             	movslq (%rbx),%rax
    6f2a:	85 c0                	test   %eax,%eax
    6f2c:	0f 88 ba 00 00 00    	js     6fec <fwp_tape_scope_release+0x12c>
    6f32:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6f36:	48 8b 35 f3 a1 01 00 	mov    0x1a1f3(%rip),%rsi        # 21130 <fwp_tapes>
    6f3d:	4c 01 c6             	add    %r8,%rsi
    6f40:	48 89 f7             	mov    %rsi,%rdi
    6f43:	e8 b8 cc ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6f48:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6f4d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6f52:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6f59:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6f5d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6f61:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6f68:	00 
    6f69:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6f6e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6f72:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6f77:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6f7b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6f80:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6f87:	00 
    6f88:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6f8f:	00 
    6f90:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6f97:	00 
    6f98:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6f9d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6fa2:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6fa6:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6faa:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6fae:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6fb4:	77 18                	ja     6fce <fwp_tape_scope_release+0x10e>
    6fb6:	49 c1 f8 03          	sar    $0x3,%r8
    6fba:	4c 0f af c5          	imul   %rbp,%r8
    6fbe:	4c 3b 05 53 a1 01 00 	cmp    0x1a153(%rip),%r8        # 21118 <fwp_tape_next_slot>
    6fc5:	7d 07                	jge    6fce <fwp_tape_scope_release+0x10e>
    6fc7:	4c 89 05 4a a1 01 00 	mov    %r8,0x1a14a(%rip)        # 21118 <fwp_tape_next_slot>
    6fce:	4d 85 e4             	test   %r12,%r12
    6fd1:	0f 85 29 ff ff ff    	jne    6f00 <fwp_tape_scope_release+0x40>
    6fd7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6fdc:	e8 ef e0 ff ff       	call   50d0 <fwp_tape_buffers_release>
    6fe1:	48 63 03             	movslq (%rbx),%rax
    6fe4:	85 c0                	test   %eax,%eax
    6fe6:	0f 89 46 ff ff ff    	jns    6f32 <fwp_tape_scope_release+0x72>
    6fec:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6ff1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6ff8:	00 00 
    6ffa:	75 0b                	jne    7007 <fwp_tape_scope_release+0x147>
    6ffc:	48 83 c4 58          	add    $0x58,%rsp
    7000:	5b                   	pop    %rbx
    7001:	5d                   	pop    %rbp
    7002:	41 5c                	pop    %r12
    7004:	41 5d                	pop    %r13
    7006:	c3                   	ret
    7007:	e8 54 c4 ff ff       	call   3460 <__stack_chk_fail@plt>
    700c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000007010 <fwp_task_dispose>:
    7010:	53                   	push   %rbx
    7011:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7015:	0f 84 2b c7 ff ff    	je     3746 <fwp_task_dispose.cold>
    701b:	48 89 fb             	mov    %rdi,%rbx
    701e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7023:	0f 85 1d c7 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7029:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    702d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7034:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    703b:	00 
    703c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7040:	48 85 ff             	test   %rdi,%rdi
    7043:	74 07                	je     704c <fwp_task_dispose+0x3c>
    7045:	48 85 c0             	test   %rax,%rax
    7048:	74 02                	je     704c <fwp_task_dispose+0x3c>
    704a:	ff d0                	call   *%rax
    704c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7053:	e8 98 e7 ff ff       	call   57f0 <fwp_mem_free>
    7058:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    705f:	00 00 00 00 
    7063:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7067:	74 6f                	je     70d8 <fwp_task_dispose+0xc8>
    7069:	48 8b 15 68 bb 01 00 	mov    0x1bb68(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    7070:	48 89 d8             	mov    %rbx,%rax
    7073:	48 2b 05 36 bb 01 00 	sub    0x1bb36(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    707a:	48 c1 e2 10          	shl    $0x10,%rdx
    707e:	48 39 d0             	cmp    %rdx,%rax
    7081:	73 4c                	jae    70cf <fwp_task_dispose+0xbf>
    7083:	48 89 c2             	mov    %rax,%rdx
    7086:	48 c1 ea 10          	shr    $0x10,%rdx
    708a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    708e:	48 8b 15 63 bb 01 00 	mov    0x1bb63(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    7095:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7099:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    709d:	48 85 c9             	test   %rcx,%rcx
    70a0:	74 2d                	je     70cf <fwp_task_dispose+0xbf>
    70a2:	0f b6 32             	movzbl (%rdx),%esi
    70a5:	40 80 fe 02          	cmp    $0x2,%sil
    70a9:	74 3d                	je     70e8 <fwp_task_dispose+0xd8>
    70ab:	40 80 fe 01          	cmp    $0x1,%sil
    70af:	75 1e                	jne    70cf <fwp_task_dispose+0xbf>
    70b1:	8b 72 18             	mov    0x18(%rdx),%esi
    70b4:	0f b7 c0             	movzwl %ax,%eax
    70b7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    70ba:	48 0f af c6          	imul   %rsi,%rax
    70be:	48 c1 e8 20          	shr    $0x20,%rax
    70c2:	48 39 d0             	cmp    %rdx,%rax
    70c5:	73 08                	jae    70cf <fwp_task_dispose+0xbf>
    70c7:	48 01 c1             	add    %rax,%rcx
    70ca:	80 39 01             	cmpb   $0x1,(%rcx)
    70cd:	74 09                	je     70d8 <fwp_task_dispose+0xc8>
    70cf:	5b                   	pop    %rbx
    70d0:	c3                   	ret
    70d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    70d8:	48 89 df             	mov    %rbx,%rdi
    70db:	5b                   	pop    %rbx
    70dc:	e9 0f e7 ff ff       	jmp    57f0 <fwp_mem_free>
    70e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    70e8:	66 85 c0             	test   %ax,%ax
    70eb:	74 dd                	je     70ca <fwp_task_dispose+0xba>
    70ed:	5b                   	pop    %rbx
    70ee:	c3                   	ret
    70ef:	90                   	nop

00000000000070f0 <fwp_free_zombie>:
    70f0:	48 8b 15 d9 a6 01 00 	mov    0x1a6d9(%rip),%rdx        # 217d0 <fwp_zombie>
    70f7:	48 85 d2             	test   %rdx,%rdx
    70fa:	0f 84 98 00 00 00    	je     7198 <fwp_free_zombie+0xa8>
    7100:	48 3b 15 d9 a6 01 00 	cmp    0x1a6d9(%rip),%rdx        # 217e0 <fwp_cur>
    7107:	0f 84 8b 00 00 00    	je     7198 <fwp_free_zombie+0xa8>
    710d:	48 83 ec 18          	sub    $0x18,%rsp
    7111:	48 63 05 8c a0 01 00 	movslq 0x1a08c(%rip),%rax        # 211a4 <fwp_stack_pool_n>
    7118:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    711c:	83 f8 3f             	cmp    $0x3f,%eax
    711f:	7f 7f                	jg     71a0 <fwp_free_zombie+0xb0>
    7121:	8d 48 01             	lea    0x1(%rax),%ecx
    7124:	89 0d 7a a0 01 00    	mov    %ecx,0x1a07a(%rip)        # 211a4 <fwp_stack_pool_n>
    712a:	48 8d 0d 8f a0 01 00 	lea    0x1a08f(%rip),%rcx        # 211c0 <fwp_stack_pool>
    7131:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7135:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    713c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7140:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7147:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    714b:	48 85 c9             	test   %rcx,%rcx
    714e:	0f 84 fc 00 00 00    	je     7250 <fwp_free_zombie+0x160>
    7154:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    715b:	48 85 c0             	test   %rax,%rax
    715e:	74 07                	je     7167 <fwp_free_zombie+0x77>
    7160:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7167:	8b 42 5c             	mov    0x5c(%rdx),%eax
    716a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    716e:	48 c7 05 57 a6 01 00 	movq   $0x0,0x1a657(%rip)        # 217d0 <fwp_zombie>
    7175:	00 00 00 00 
    7179:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7180:	85 c0                	test   %eax,%eax
    7182:	74 34                	je     71b8 <fwp_free_zombie+0xc8>
    7184:	83 f8 01             	cmp    $0x1,%eax
    7187:	0f 84 b3 00 00 00    	je     7240 <fwp_free_zombie+0x150>
    718d:	48 83 c4 18          	add    $0x18,%rsp
    7191:	c3                   	ret
    7192:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7198:	c3                   	ret
    7199:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    71a0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    71a4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    71a9:	e8 32 c4 ff ff       	call   35e0 <munmap@plt>
    71ae:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    71b3:	eb 80                	jmp    7135 <fwp_free_zombie+0x45>
    71b5:	0f 1f 00             	nopl   (%rax)
    71b8:	48 8b 0d 19 ba 01 00 	mov    0x1ba19(%rip),%rcx        # 22bd8 <fwp_heap+0x13d8>
    71bf:	48 89 d0             	mov    %rdx,%rax
    71c2:	48 2b 05 e7 b9 01 00 	sub    0x1b9e7(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    71c9:	48 c1 e1 10          	shl    $0x10,%rcx
    71cd:	48 39 c8             	cmp    %rcx,%rax
    71d0:	73 bb                	jae    718d <fwp_free_zombie+0x9d>
    71d2:	48 89 c1             	mov    %rax,%rcx
    71d5:	48 c1 e9 10          	shr    $0x10,%rcx
    71d9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    71dd:	48 8b 0d 14 ba 01 00 	mov    0x1ba14(%rip),%rcx        # 22bf8 <fwp_heap+0x13f8>
    71e4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    71e8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    71ec:	48 85 c9             	test   %rcx,%rcx
    71ef:	74 9c                	je     718d <fwp_free_zombie+0x9d>
    71f1:	0f b6 3e             	movzbl (%rsi),%edi
    71f4:	40 80 ff 02          	cmp    $0x2,%dil
    71f8:	74 66                	je     7260 <fwp_free_zombie+0x170>
    71fa:	40 80 ff 01          	cmp    $0x1,%dil
    71fe:	75 8d                	jne    718d <fwp_free_zombie+0x9d>
    7200:	8b 7e 18             	mov    0x18(%rsi),%edi
    7203:	0f b7 c0             	movzwl %ax,%eax
    7206:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7209:	48 0f af c7          	imul   %rdi,%rax
    720d:	48 c1 e8 20          	shr    $0x20,%rax
    7211:	48 39 f0             	cmp    %rsi,%rax
    7214:	0f 83 73 ff ff ff    	jae    718d <fwp_free_zombie+0x9d>
    721a:	48 01 c1             	add    %rax,%rcx
    721d:	0f b6 01             	movzbl (%rcx),%eax
    7220:	84 c0                	test   %al,%al
    7222:	0f 84 65 ff ff ff    	je     718d <fwp_free_zombie+0x9d>
    7228:	3c 01                	cmp    $0x1,%al
    722a:	74 14                	je     7240 <fwp_free_zombie+0x150>
    722c:	3c ff                	cmp    $0xff,%al
    722e:	74 3b                	je     726b <fwp_free_zombie+0x17b>
    7230:	83 e8 01             	sub    $0x1,%eax
    7233:	88 01                	mov    %al,(%rcx)
    7235:	e9 53 ff ff ff       	jmp    718d <fwp_free_zombie+0x9d>
    723a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7240:	48 89 d7             	mov    %rdx,%rdi
    7243:	48 83 c4 18          	add    $0x18,%rsp
    7247:	e9 c4 fd ff ff       	jmp    7010 <fwp_task_dispose>
    724c:	0f 1f 40 00          	nopl   0x0(%rax)
    7250:	48 89 05 51 a5 01 00 	mov    %rax,0x1a551(%rip)        # 217a8 <fwp_tasks_active>
    7257:	e9 ff fe ff ff       	jmp    715b <fwp_free_zombie+0x6b>
    725c:	0f 1f 40 00          	nopl   0x0(%rax)
    7260:	66 85 c0             	test   %ax,%ax
    7263:	0f 85 24 ff ff ff    	jne    718d <fwp_free_zombie+0x9d>
    7269:	eb b2                	jmp    721d <fwp_free_zombie+0x12d>
    726b:	48 89 ca             	mov    %rcx,%rdx
    726e:	48 8d 35 8b a5 01 00 	lea    0x1a58b(%rip),%rsi        # 21800 <fwp_heap>
    7275:	48 c1 ea 11          	shr    $0x11,%rdx
    7279:	48 31 ca             	xor    %rcx,%rdx
    727c:	48 89 d0             	mov    %rdx,%rax
    727f:	48 c1 e8 09          	shr    $0x9,%rax
    7283:	48 31 c2             	xor    %rax,%rdx
    7286:	0f b6 d2             	movzbl %dl,%edx
    7289:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7290:	00 
    7291:	48 85 c0             	test   %rax,%rax
    7294:	75 13                	jne    72a9 <fwp_free_zombie+0x1b9>
    7296:	eb 4c                	jmp    72e4 <fwp_free_zombie+0x1f4>
    7298:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    729f:	00 
    72a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    72a4:	48 85 c0             	test   %rax,%rax
    72a7:	74 3b                	je     72e4 <fwp_free_zombie+0x1f4>
    72a9:	48 89 c2             	mov    %rax,%rdx
    72ac:	48 39 08             	cmp    %rcx,(%rax)
    72af:	75 ef                	jne    72a0 <fwp_free_zombie+0x1b0>
    72b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    72b5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    72b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    72bd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    72c4:	0f 85 c3 fe ff ff    	jne    718d <fwp_free_zombie+0x9d>
    72ca:	48 89 cf             	mov    %rcx,%rdi
    72cd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    72d2:	e8 d9 e2 ff ff       	call   55b0 <fwp_rc_forget_slot>
    72d7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    72dc:	c6 01 fe             	movb   $0xfe,(%rcx)
    72df:	e9 a9 fe ff ff       	jmp    718d <fwp_free_zombie+0x9d>
    72e4:	48 8d 3d 9d 65 00 00 	lea    0x659d(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    72eb:	e8 00 d1 ff ff       	call   43f0 <fwp_trap>

00000000000072f0 <fwp_block>:
    72f0:	48 83 ec 08          	sub    $0x8,%rsp
    72f4:	48 8b 05 cd a4 01 00 	mov    0x1a4cd(%rip),%rax        # 217c8 <fwp_ready_head>
    72fb:	48 85 c0             	test   %rax,%rax
    72fe:	0f 84 1c 01 00 00    	je     7420 <fwp_block+0x130>
    7304:	90                   	nop
    7305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    730c:	00 00 00 00 
    7310:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7317:	48 89 15 aa a4 01 00 	mov    %rdx,0x1a4aa(%rip)        # 217c8 <fwp_ready_head>
    731e:	48 85 d2             	test   %rdx,%rdx
    7321:	0f 84 19 01 00 00    	je     7440 <fwp_block+0x150>
    7327:	48 8b 15 b2 a4 01 00 	mov    0x1a4b2(%rip),%rdx        # 217e0 <fwp_cur>
    732e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7332:	48 39 c2             	cmp    %rax,%rdx
    7335:	0f 84 d5 00 00 00    	je     7410 <fwp_block+0x120>
    733b:	48 8b 0d 26 c1 01 00 	mov    0x1c126(%rip),%rcx        # 23468 <fwp_state_owners>
    7342:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7346:	48 89 05 93 a4 01 00 	mov    %rax,0x1a493(%rip)        # 217e0 <fwp_cur>
    734d:	f3 0f 7e 05 3b c1 01 	movq   0x1c13b(%rip),%xmm0        # 23490 <fwp_foreign_callbacks>
    7354:	00 
    7355:	0f 16 05 24 c1 01 00 	movhps 0x1c124(%rip),%xmm0        # 23480 <fwp_state>
    735c:	f3 0f 7e 0d 24 c1 01 	movq   0x1c124(%rip),%xmm1        # 23488 <fwp_handlers>
    7363:	00 
    7364:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    736b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7372:	0f 16 0d 1f c1 01 00 	movhps 0x1c11f(%rip),%xmm1        # 23498 <fwp_cleanups>
    7379:	f3 0f 7e 05 f7 c0 01 	movq   0x1c0f7(%rip),%xmm0        # 23478 <fwp_state_len>
    7380:	00 
    7381:	0f 16 05 e8 c0 01 00 	movhps 0x1c0e8(%rip),%xmm0        # 23470 <fwp_state_cap>
    7388:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    738f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7396:	48 8b 70 08          	mov    0x8(%rax),%rsi
    739a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    73a1:	48 89 0d e0 c0 01 00 	mov    %rcx,0x1c0e0(%rip)        # 23488 <fwp_handlers>
    73a8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    73af:	48 89 0d e2 c0 01 00 	mov    %rcx,0x1c0e2(%rip)        # 23498 <fwp_cleanups>
    73b6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    73bd:	48 89 0d cc c0 01 00 	mov    %rcx,0x1c0cc(%rip)        # 23490 <fwp_foreign_callbacks>
    73c4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    73cb:	48 89 0d ae c0 01 00 	mov    %rcx,0x1c0ae(%rip)        # 23480 <fwp_state>
    73d2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    73d9:	48 89 0d 98 c0 01 00 	mov    %rcx,0x1c098(%rip)        # 23478 <fwp_state_len>
    73e0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    73e7:	48 89 0d 82 c0 01 00 	mov    %rcx,0x1c082(%rip)        # 23470 <fwp_state_cap>
    73ee:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    73f5:	48 89 0d 6c c0 01 00 	mov    %rcx,0x1c06c(%rip)        # 23468 <fwp_state_owners>
    73fc:	e8 8f c0 ff ff       	call   3490 <swapcontext@plt>
    7401:	f3 0f 1e fa          	endbr64
    7405:	e8 e6 fc ff ff       	call   70f0 <fwp_free_zombie>
    740a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7410:	8b 05 8a 9d 01 00    	mov    0x19d8a(%rip),%eax        # 211a0 <fwp_slice>
    7416:	85 c0                	test   %eax,%eax
    7418:	74 36                	je     7450 <fwp_block+0x160>
    741a:	48 83 c4 08          	add    $0x8,%rsp
    741e:	c3                   	ret
    741f:	90                   	nop
    7420:	e8 db dd ff ff       	call   5200 <fwp_poll_events>
    7425:	48 8b 05 9c a3 01 00 	mov    0x1a39c(%rip),%rax        # 217c8 <fwp_ready_head>
    742c:	48 85 c0             	test   %rax,%rax
    742f:	0f 85 db fe ff ff    	jne    7310 <fwp_block+0x20>
    7435:	eb e9                	jmp    7420 <fwp_block+0x130>
    7437:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    743e:	00 00 
    7440:	48 c7 05 75 a3 01 00 	movq   $0x0,0x1a375(%rip)        # 217c0 <fwp_ready_tail>
    7447:	00 00 00 00 
    744b:	e9 d7 fe ff ff       	jmp    7327 <fwp_block+0x37>
    7450:	48 8d 3d 2d 5d 00 00 	lea    0x5d2d(%rip),%rdi        # d184 <_IO_stdin_used+0x184>
    7457:	e8 44 bf ff ff       	call   33a0 <getenv@plt>
    745c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7461:	48 85 c0             	test   %rax,%rax
    7464:	74 05                	je     746b <fwp_block+0x17b>
    7466:	80 38 00             	cmpb   $0x0,(%rax)
    7469:	75 0b                	jne    7476 <fwp_block+0x186>
    746b:	89 15 2f 9d 01 00    	mov    %edx,0x19d2f(%rip)        # 211a0 <fwp_slice>
    7471:	48 83 c4 08          	add    $0x8,%rsp
    7475:	c3                   	ret
    7476:	ba 0a 00 00 00       	mov    $0xa,%edx
    747b:	31 f6                	xor    %esi,%esi
    747d:	48 89 c7             	mov    %rax,%rdi
    7480:	e8 cb c0 ff ff       	call   3550 <strtoll@plt>
    7485:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7489:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7490:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7495:	0f 46 d0             	cmovbe %eax,%edx
    7498:	eb d1                	jmp    746b <fwp_block+0x17b>
    749a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000074a0 <fwp_owned_entry161>:
    74a0:	f3 0f 1e fa          	endbr64
    74a4:	41 56                	push   %r14
    74a6:	55                   	push   %rbp
    74a7:	53                   	push   %rbx
    74a8:	48 83 ec 10          	sub    $0x10,%rsp
    74ac:	48 8b 07             	mov    (%rdi),%rax
    74af:	48 03 47 10          	add    0x10(%rdi),%rax
    74b3:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    74b8:	0f 80 b7 01 00 00    	jo     7675 <fwp_owned_entry161+0x1d5>
    74be:	49 89 c6             	mov    %rax,%r14
    74c1:	8b 05 dd b6 01 00    	mov    0x1b6dd(%rip),%eax        # 22ba4 <fwp_heap+0x13a4>
    74c7:	48 8d 15 32 a3 01 00 	lea    0x1a332(%rip),%rdx        # 21800 <fwp_heap>
    74ce:	85 c0                	test   %eax,%eax
    74d0:	0f 84 52 01 00 00    	je     7628 <fwp_owned_entry161+0x188>
    74d6:	0f b6 05 c5 b2 01 00 	movzbl 0x1b2c5(%rip),%eax        # 227a2 <fwp_heap+0xfa2>
    74dd:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    74e4:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    74e8:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    74ec:	48 8b 18             	mov    (%rax),%rbx
    74ef:	48 85 db             	test   %rbx,%rbx
    74f2:	0f 84 08 01 00 00    	je     7600 <fwp_owned_entry161+0x160>
    74f8:	48 8b 13             	mov    (%rbx),%rdx
    74fb:	48 f7 d2             	not    %rdx
    74fe:	48 89 10             	mov    %rdx,(%rax)
    7501:	48 83 fd 18          	cmp    $0x18,%rbp
    7505:	76 27                	jbe    752e <fwp_owned_entry161+0x8e>
    7507:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    750b:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    750f:	31 f6                	xor    %esi,%esi
    7511:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7517:	48 c1 e8 03          	shr    $0x3,%rax
    751b:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    7522:	00 
    7523:	e8 98 bf ff ff       	call   34c0 <memset@plt>
    7528:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    752e:	48 89 e8             	mov    %rbp,%rax
    7531:	48 03 05 e8 b6 01 00 	add    0x1b6e8(%rip),%rax        # 22c20 <fwp_heap+0x1420>
    7538:	0f 82 3c 01 00 00    	jb     767a <fwp_owned_entry161+0x1da>
    753e:	48 39 05 e3 b6 01 00 	cmp    %rax,0x1b6e3(%rip)        # 22c28 <fwp_heap+0x1428>
    7545:	48 89 05 d4 b6 01 00 	mov    %rax,0x1b6d4(%rip)        # 22c20 <fwp_heap+0x1420>
    754c:	73 07                	jae    7555 <fwp_owned_entry161+0xb5>
    754e:	48 89 05 d3 b6 01 00 	mov    %rax,0x1b6d3(%rip)        # 22c28 <fwp_heap+0x1428>
    7555:	66 0f ef c9          	pxor   %xmm1,%xmm1
    7559:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    755e:	f2 0f 58 0d d2 b6 01 	addsd  0x1b6d2(%rip),%xmm1        # 22c38 <fwp_heap+0x1438>
    7565:	00 
    7566:	f2 0f 11 0d ca b6 01 	movsd  %xmm1,0x1b6ca(%rip)        # 22c38 <fwp_heap+0x1438>
    756d:	00 
    756e:	48 8b 05 cb 66 00 00 	mov    0x66cb(%rip),%rax        # dc40 <msg.8+0xd0>
    7575:	66 49 0f 6e d6       	movq   %r14,%xmm2
    757a:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    757e:	48 89 03             	mov    %rax,(%rbx)
    7581:	48 89 d8             	mov    %rbx,%rax
    7584:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    7588:	48 8b 15 49 b6 01 00 	mov    0x1b649(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    758f:	48 2b 05 1a b6 01 00 	sub    0x1b61a(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    7596:	48 c1 e2 10          	shl    $0x10,%rdx
    759a:	48 39 d0             	cmp    %rdx,%rax
    759d:	73 53                	jae    75f2 <fwp_owned_entry161+0x152>
    759f:	48 89 c2             	mov    %rax,%rdx
    75a2:	48 c1 ea 10          	shr    $0x10,%rdx
    75a6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    75aa:	48 8b 15 47 b6 01 00 	mov    0x1b647(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    75b1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    75b5:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    75b9:	48 85 ed             	test   %rbp,%rbp
    75bc:	74 34                	je     75f2 <fwp_owned_entry161+0x152>
    75be:	0f b6 0a             	movzbl (%rdx),%ecx
    75c1:	80 f9 02             	cmp    $0x2,%cl
    75c4:	0f 84 86 00 00 00    	je     7650 <fwp_owned_entry161+0x1b0>
    75ca:	80 f9 01             	cmp    $0x1,%cl
    75cd:	75 23                	jne    75f2 <fwp_owned_entry161+0x152>
    75cf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    75d2:	0f b7 c0             	movzwl %ax,%eax
    75d5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    75d8:	48 0f af c1          	imul   %rcx,%rax
    75dc:	48 c1 e8 20          	shr    $0x20,%rax
    75e0:	48 39 d0             	cmp    %rdx,%rax
    75e3:	73 0d                	jae    75f2 <fwp_owned_entry161+0x152>
    75e5:	48 01 c5             	add    %rax,%rbp
    75e8:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    75ec:	74 7a                	je     7668 <fwp_owned_entry161+0x1c8>
    75ee:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    75f2:	48 83 c4 10          	add    $0x10,%rsp
    75f6:	48 89 d8             	mov    %rbx,%rax
    75f9:	5b                   	pop    %rbx
    75fa:	5d                   	pop    %rbp
    75fb:	41 5e                	pop    %r14
    75fd:	c3                   	ret
    75fe:	66 90                	xchg   %ax,%ax
    7600:	48 8b 58 08          	mov    0x8(%rax),%rbx
    7604:	48 85 db             	test   %rbx,%rbx
    7607:	74 1f                	je     7628 <fwp_owned_entry161+0x188>
    7609:	48 8b 50 10          	mov    0x10(%rax),%rdx
    760d:	48 29 da             	sub    %rbx,%rdx
    7610:	48 39 ea             	cmp    %rbp,%rdx
    7613:	72 13                	jb     7628 <fwp_owned_entry161+0x188>
    7615:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    7619:	48 89 50 08          	mov    %rdx,0x8(%rax)
    761d:	e9 df fe ff ff       	jmp    7501 <fwp_owned_entry161+0x61>
    7622:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7628:	31 f6                	xor    %esi,%esi
    762a:	bf 18 00 00 00       	mov    $0x18,%edi
    762f:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7635:	e8 b6 e6 ff ff       	call   5cf0 <fwp_heap_alloc>
    763a:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    7640:	48 89 c3             	mov    %rax,%rbx
    7643:	e9 26 ff ff ff       	jmp    756e <fwp_owned_entry161+0xce>
    7648:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    764f:	00 
    7650:	66 85 c0             	test   %ax,%ax
    7653:	74 93                	je     75e8 <fwp_owned_entry161+0x148>
    7655:	48 83 c4 10          	add    $0x10,%rsp
    7659:	48 89 d8             	mov    %rbx,%rax
    765c:	5b                   	pop    %rbx
    765d:	5d                   	pop    %rbp
    765e:	41 5e                	pop    %r14
    7660:	c3                   	ret
    7661:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7668:	48 89 ef             	mov    %rbp,%rdi
    766b:	e8 40 df ff ff       	call   55b0 <fwp_rc_forget_slot>
    7670:	e9 79 ff ff ff       	jmp    75ee <fwp_owned_entry161+0x14e>
    7675:	e8 86 c0 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    767a:	e8 31 c6 ff ff       	call   3cb0 <fwp_heap_oom>
    767f:	90                   	nop

0000000000007680 <e161>:
    7680:	f3 0f 1e fa          	endbr64
    7684:	41 56                	push   %r14
    7686:	55                   	push   %rbp
    7687:	53                   	push   %rbx
    7688:	48 83 ec 10          	sub    $0x10,%rsp
    768c:	48 8b 07             	mov    (%rdi),%rax
    768f:	48 03 47 10          	add    0x10(%rdi),%rax
    7693:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    7698:	0f 80 bf 01 00 00    	jo     785d <e161+0x1dd>
    769e:	49 89 c6             	mov    %rax,%r14
    76a1:	8b 05 fd b4 01 00    	mov    0x1b4fd(%rip),%eax        # 22ba4 <fwp_heap+0x13a4>
    76a7:	48 8d 15 52 a1 01 00 	lea    0x1a152(%rip),%rdx        # 21800 <fwp_heap>
    76ae:	85 c0                	test   %eax,%eax
    76b0:	0f 84 62 01 00 00    	je     7818 <e161+0x198>
    76b6:	0f b6 05 e5 b0 01 00 	movzbl 0x1b0e5(%rip),%eax        # 227a2 <fwp_heap+0xfa2>
    76bd:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    76c4:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    76c8:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    76cc:	48 8b 18             	mov    (%rax),%rbx
    76cf:	48 85 db             	test   %rbx,%rbx
    76d2:	0f 84 18 01 00 00    	je     77f0 <e161+0x170>
    76d8:	48 8b 13             	mov    (%rbx),%rdx
    76db:	48 f7 d2             	not    %rdx
    76de:	48 89 10             	mov    %rdx,(%rax)
    76e1:	48 83 fd 18          	cmp    $0x18,%rbp
    76e5:	76 27                	jbe    770e <e161+0x8e>
    76e7:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    76eb:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    76ef:	31 f6                	xor    %esi,%esi
    76f1:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    76f7:	48 c1 e8 03          	shr    $0x3,%rax
    76fb:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    7702:	00 
    7703:	e8 b8 bd ff ff       	call   34c0 <memset@plt>
    7708:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    770e:	48 89 e8             	mov    %rbp,%rax
    7711:	48 03 05 08 b5 01 00 	add    0x1b508(%rip),%rax        # 22c20 <fwp_heap+0x1420>
    7718:	0f 82 44 01 00 00    	jb     7862 <e161+0x1e2>
    771e:	48 39 05 03 b5 01 00 	cmp    %rax,0x1b503(%rip)        # 22c28 <fwp_heap+0x1428>
    7725:	48 89 05 f4 b4 01 00 	mov    %rax,0x1b4f4(%rip)        # 22c20 <fwp_heap+0x1420>
    772c:	73 07                	jae    7735 <e161+0xb5>
    772e:	48 89 05 f3 b4 01 00 	mov    %rax,0x1b4f3(%rip)        # 22c28 <fwp_heap+0x1428>
    7735:	66 0f ef c9          	pxor   %xmm1,%xmm1
    7739:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    773e:	f2 0f 58 0d f2 b4 01 	addsd  0x1b4f2(%rip),%xmm1        # 22c38 <fwp_heap+0x1438>
    7745:	00 
    7746:	f2 0f 11 0d ea b4 01 	movsd  %xmm1,0x1b4ea(%rip)        # 22c38 <fwp_heap+0x1438>
    774d:	00 
    774e:	48 8b 05 eb 64 00 00 	mov    0x64eb(%rip),%rax        # dc40 <msg.8+0xd0>
    7755:	66 49 0f 6e d6       	movq   %r14,%xmm2
    775a:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    775e:	48 89 03             	mov    %rax,(%rbx)
    7761:	48 89 d8             	mov    %rbx,%rax
    7764:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    7768:	48 8b 15 69 b4 01 00 	mov    0x1b469(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    776f:	48 2b 05 3a b4 01 00 	sub    0x1b43a(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    7776:	48 c1 e2 10          	shl    $0x10,%rdx
    777a:	48 39 d0             	cmp    %rdx,%rax
    777d:	73 57                	jae    77d6 <e161+0x156>
    777f:	48 89 c2             	mov    %rax,%rdx
    7782:	48 c1 ea 10          	shr    $0x10,%rdx
    7786:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    778a:	48 8b 15 67 b4 01 00 	mov    0x1b467(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    7791:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7795:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7799:	48 85 ed             	test   %rbp,%rbp
    779c:	74 38                	je     77d6 <e161+0x156>
    779e:	0f b6 0a             	movzbl (%rdx),%ecx
    77a1:	80 f9 02             	cmp    $0x2,%cl
    77a4:	0f 84 96 00 00 00    	je     7840 <e161+0x1c0>
    77aa:	80 f9 01             	cmp    $0x1,%cl
    77ad:	75 27                	jne    77d6 <e161+0x156>
    77af:	8b 4a 18             	mov    0x18(%rdx),%ecx
    77b2:	0f b7 c0             	movzwl %ax,%eax
    77b5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    77b8:	48 0f af c1          	imul   %rcx,%rax
    77bc:	48 c1 e8 20          	shr    $0x20,%rax
    77c0:	48 39 d0             	cmp    %rdx,%rax
    77c3:	73 11                	jae    77d6 <e161+0x156>
    77c5:	48 01 c5             	add    %rax,%rbp
    77c8:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    77cc:	0f 84 7e 00 00 00    	je     7850 <e161+0x1d0>
    77d2:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    77d6:	48 89 df             	mov    %rbx,%rdi
    77d9:	e8 42 ef ff ff       	call   6720 <fwp_rc_share>
    77de:	48 83 c4 10          	add    $0x10,%rsp
    77e2:	48 89 d8             	mov    %rbx,%rax
    77e5:	5b                   	pop    %rbx
    77e6:	5d                   	pop    %rbp
    77e7:	41 5e                	pop    %r14
    77e9:	c3                   	ret
    77ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    77f0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    77f4:	48 85 db             	test   %rbx,%rbx
    77f7:	74 1f                	je     7818 <e161+0x198>
    77f9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    77fd:	48 29 da             	sub    %rbx,%rdx
    7800:	48 39 ea             	cmp    %rbp,%rdx
    7803:	72 13                	jb     7818 <e161+0x198>
    7805:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    7809:	48 89 50 08          	mov    %rdx,0x8(%rax)
    780d:	e9 cf fe ff ff       	jmp    76e1 <e161+0x61>
    7812:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7818:	31 f6                	xor    %esi,%esi
    781a:	bf 18 00 00 00       	mov    $0x18,%edi
    781f:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7825:	e8 c6 e4 ff ff       	call   5cf0 <fwp_heap_alloc>
    782a:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    7830:	48 89 c3             	mov    %rax,%rbx
    7833:	e9 16 ff ff ff       	jmp    774e <e161+0xce>
    7838:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    783f:	00 
    7840:	66 85 c0             	test   %ax,%ax
    7843:	75 91                	jne    77d6 <e161+0x156>
    7845:	eb 81                	jmp    77c8 <e161+0x148>
    7847:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    784e:	00 00 
    7850:	48 89 ef             	mov    %rbp,%rdi
    7853:	e8 58 dd ff ff       	call   55b0 <fwp_rc_forget_slot>
    7858:	e9 75 ff ff ff       	jmp    77d2 <e161+0x152>
    785d:	e8 9e be ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    7862:	e8 49 c4 ff ff       	call   3cb0 <fwp_heap_oom>
    7867:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    786e:	00 00 

0000000000007870 <fwp_drop4>:
    7870:	48 8b 15 61 b3 01 00 	mov    0x1b361(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    7877:	48 89 f8             	mov    %rdi,%rax
    787a:	48 2b 05 2f b3 01 00 	sub    0x1b32f(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    7881:	48 c1 e2 10          	shl    $0x10,%rdx
    7885:	48 39 d0             	cmp    %rdx,%rax
    7888:	0f 83 52 01 00 00    	jae    79e0 <fwp_drop4+0x170>
    788e:	48 83 ec 18          	sub    $0x18,%rsp
    7892:	4c 8d 05 67 9f 01 00 	lea    0x19f67(%rip),%r8        # 21800 <fwp_heap>
    7899:	48 89 c2             	mov    %rax,%rdx
    789c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    78a3:	48 c1 ea 10          	shr    $0x10,%rdx
    78a7:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    78ab:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    78af:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    78b3:	48 85 d2             	test   %rdx,%rdx
    78b6:	74 46                	je     78fe <fwp_drop4+0x8e>
    78b8:	44 0f b6 09          	movzbl (%rcx),%r9d
    78bc:	41 80 f9 02          	cmp    $0x2,%r9b
    78c0:	0f 84 ca 00 00 00    	je     7990 <fwp_drop4+0x120>
    78c6:	41 80 f9 01          	cmp    $0x1,%r9b
    78ca:	75 32                	jne    78fe <fwp_drop4+0x8e>
    78cc:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    78d0:	0f b7 c0             	movzwl %ax,%eax
    78d3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    78d6:	49 0f af c1          	imul   %r9,%rax
    78da:	48 c1 e8 20          	shr    $0x20,%rax
    78de:	48 39 c8             	cmp    %rcx,%rax
    78e1:	73 1b                	jae    78fe <fwp_drop4+0x8e>
    78e3:	48 01 c2             	add    %rax,%rdx
    78e6:	0f b6 02             	movzbl (%rdx),%eax
    78e9:	84 c0                	test   %al,%al
    78eb:	74 11                	je     78fe <fwp_drop4+0x8e>
    78ed:	3c 01                	cmp    $0x1,%al
    78ef:	74 17                	je     7908 <fwp_drop4+0x98>
    78f1:	3c ff                	cmp    $0xff,%al
    78f3:	0f 84 ef 00 00 00    	je     79e8 <fwp_drop4+0x178>
    78f9:	83 e8 01             	sub    $0x1,%eax
    78fc:	88 02                	mov    %al,(%rdx)
    78fe:	48 83 c4 18          	add    $0x18,%rsp
    7902:	c3                   	ret
    7903:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7908:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    790c:	0f 88 8e 00 00 00    	js     79a0 <fwp_drop4+0x130>
    7912:	48 8b 15 bf b2 01 00 	mov    0x1b2bf(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    7919:	48 89 f8             	mov    %rdi,%rax
    791c:	48 2b 05 8d b2 01 00 	sub    0x1b28d(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    7923:	48 c1 e2 10          	shl    $0x10,%rdx
    7927:	48 39 d0             	cmp    %rdx,%rax
    792a:	73 d2                	jae    78fe <fwp_drop4+0x8e>
    792c:	48 89 c2             	mov    %rax,%rdx
    792f:	48 c1 ea 10          	shr    $0x10,%rdx
    7933:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7937:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    793b:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    793f:	48 85 c9             	test   %rcx,%rcx
    7942:	74 ba                	je     78fe <fwp_drop4+0x8e>
    7944:	0f b6 32             	movzbl (%rdx),%esi
    7947:	40 80 fe 02          	cmp    $0x2,%sil
    794b:	74 33                	je     7980 <fwp_drop4+0x110>
    794d:	40 80 fe 01          	cmp    $0x1,%sil
    7951:	75 ab                	jne    78fe <fwp_drop4+0x8e>
    7953:	8b 72 18             	mov    0x18(%rdx),%esi
    7956:	0f b7 c0             	movzwl %ax,%eax
    7959:	8b 52 1c             	mov    0x1c(%rdx),%edx
    795c:	48 0f af c6          	imul   %rsi,%rax
    7960:	48 c1 e8 20          	shr    $0x20,%rax
    7964:	48 39 d0             	cmp    %rdx,%rax
    7967:	73 95                	jae    78fe <fwp_drop4+0x8e>
    7969:	48 01 c1             	add    %rax,%rcx
    796c:	80 39 01             	cmpb   $0x1,(%rcx)
    796f:	75 8d                	jne    78fe <fwp_drop4+0x8e>
    7971:	48 83 c4 18          	add    $0x18,%rsp
    7975:	e9 76 de ff ff       	jmp    57f0 <fwp_mem_free>
    797a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7980:	66 85 c0             	test   %ax,%ax
    7983:	74 e7                	je     796c <fwp_drop4+0xfc>
    7985:	48 83 c4 18          	add    $0x18,%rsp
    7989:	c3                   	ret
    798a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7990:	66 85 c0             	test   %ax,%ax
    7993:	0f 84 4d ff ff ff    	je     78e6 <fwp_drop4+0x76>
    7999:	48 83 c4 18          	add    $0x18,%rsp
    799d:	c3                   	ret
    799e:	66 90                	xchg   %ax,%ax
    79a0:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    79a4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    79a9:	e8 f2 ed ff ff       	call   67a0 <fwp_rc_free_arr>
    79ae:	4c 8d 05 4b 9e 01 00 	lea    0x19e4b(%rip),%r8        # 21800 <fwp_heap>
    79b5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    79ba:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    79c1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    79c8:	48 c1 e2 10          	shl    $0x10,%rdx
    79cc:	48 39 d0             	cmp    %rdx,%rax
    79cf:	0f 83 29 ff ff ff    	jae    78fe <fwp_drop4+0x8e>
    79d5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    79da:	e9 ba fe ff ff       	jmp    7899 <fwp_drop4+0x29>
    79df:	90                   	nop
    79e0:	c3                   	ret
    79e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    79e8:	48 89 d0             	mov    %rdx,%rax
    79eb:	48 c1 e8 11          	shr    $0x11,%rax
    79ef:	48 31 d0             	xor    %rdx,%rax
    79f2:	48 89 c1             	mov    %rax,%rcx
    79f5:	48 c1 e9 09          	shr    $0x9,%rcx
    79f9:	48 31 c8             	xor    %rcx,%rax
    79fc:	0f b6 c8             	movzbl %al,%ecx
    79ff:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7a06:	00 
    7a07:	48 85 c0             	test   %rax,%rax
    7a0a:	75 1d                	jne    7a29 <fwp_drop4+0x1b9>
    7a0c:	eb 56                	jmp    7a64 <fwp_drop4+0x1f4>
    7a0e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7a1c:	00 00 00 00 
    7a20:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7a24:	48 85 c0             	test   %rax,%rax
    7a27:	74 3b                	je     7a64 <fwp_drop4+0x1f4>
    7a29:	48 89 c1             	mov    %rax,%rcx
    7a2c:	48 39 10             	cmp    %rdx,(%rax)
    7a2f:	75 ef                	jne    7a20 <fwp_drop4+0x1b0>
    7a31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7a35:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7a39:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7a3d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7a44:	0f 85 b4 fe ff ff    	jne    78fe <fwp_drop4+0x8e>
    7a4a:	48 89 d7             	mov    %rdx,%rdi
    7a4d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7a52:	e8 59 db ff ff       	call   55b0 <fwp_rc_forget_slot>
    7a57:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7a5c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7a5f:	e9 9a fe ff ff       	jmp    78fe <fwp_drop4+0x8e>
    7a64:	48 8d 3d 1d 5e 00 00 	lea    0x5e1d(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    7a6b:	e8 80 c9 ff ff       	call   43f0 <fwp_trap>

0000000000007a70 <fwp_caps161>:
    7a70:	f3 0f 1e fa          	endbr64
    7a74:	85 f6                	test   %esi,%esi
    7a76:	74 08                	je     7a80 <fwp_caps161+0x10>
    7a78:	c3                   	ret
    7a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a80:	48 8b 15 51 b1 01 00 	mov    0x1b151(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    7a87:	48 89 f8             	mov    %rdi,%rax
    7a8a:	48 2b 05 1f b1 01 00 	sub    0x1b11f(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    7a91:	48 c1 e2 10          	shl    $0x10,%rdx
    7a95:	48 39 d0             	cmp    %rdx,%rax
    7a98:	73 de                	jae    7a78 <fwp_caps161+0x8>
    7a9a:	48 89 c2             	mov    %rax,%rdx
    7a9d:	48 c1 ea 10          	shr    $0x10,%rdx
    7aa1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7aa5:	48 8b 15 4c b1 01 00 	mov    0x1b14c(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    7aac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ab0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7ab4:	48 85 c9             	test   %rcx,%rcx
    7ab7:	74 bf                	je     7a78 <fwp_caps161+0x8>
    7ab9:	0f b6 32             	movzbl (%rdx),%esi
    7abc:	40 80 fe 02          	cmp    $0x2,%sil
    7ac0:	74 2e                	je     7af0 <fwp_caps161+0x80>
    7ac2:	40 80 fe 01          	cmp    $0x1,%sil
    7ac6:	75 b0                	jne    7a78 <fwp_caps161+0x8>
    7ac8:	8b 72 18             	mov    0x18(%rdx),%esi
    7acb:	0f b7 c0             	movzwl %ax,%eax
    7ace:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7ad1:	48 0f af c6          	imul   %rsi,%rax
    7ad5:	48 c1 e8 20          	shr    $0x20,%rax
    7ad9:	48 39 d0             	cmp    %rdx,%rax
    7adc:	73 9a                	jae    7a78 <fwp_caps161+0x8>
    7ade:	48 01 c1             	add    %rax,%rcx
    7ae1:	80 39 01             	cmpb   $0x1,(%rcx)
    7ae4:	75 92                	jne    7a78 <fwp_caps161+0x8>
    7ae6:	e9 05 dd ff ff       	jmp    57f0 <fwp_mem_free>
    7aeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7af0:	66 85 c0             	test   %ax,%ax
    7af3:	74 ec                	je     7ae1 <fwp_caps161+0x71>
    7af5:	c3                   	ret
    7af6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7afd:	00 00 00 

0000000000007b00 <fwp_args12>:
    7b00:	f3 0f 1e fa          	endbr64
    7b04:	85 d2                	test   %edx,%edx
    7b06:	74 04                	je     7b0c <fwp_args12+0xc>
    7b08:	85 f6                	test   %esi,%esi
    7b0a:	74 04                	je     7b10 <fwp_args12+0x10>
    7b0c:	c3                   	ret
    7b0d:	0f 1f 00             	nopl   (%rax)
    7b10:	48 8b 15 c1 b0 01 00 	mov    0x1b0c1(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    7b17:	48 8b 07             	mov    (%rdi),%rax
    7b1a:	48 2b 05 8f b0 01 00 	sub    0x1b08f(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    7b21:	48 c1 e2 10          	shl    $0x10,%rdx
    7b25:	48 39 d0             	cmp    %rdx,%rax
    7b28:	73 e2                	jae    7b0c <fwp_args12+0xc>
    7b2a:	48 89 c2             	mov    %rax,%rdx
    7b2d:	48 c1 ea 10          	shr    $0x10,%rdx
    7b31:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7b35:	48 8b 15 bc b0 01 00 	mov    0x1b0bc(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    7b3c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7b40:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7b44:	48 85 ff             	test   %rdi,%rdi
    7b47:	74 c3                	je     7b0c <fwp_args12+0xc>
    7b49:	0f b6 0a             	movzbl (%rdx),%ecx
    7b4c:	80 f9 02             	cmp    $0x2,%cl
    7b4f:	74 2f                	je     7b80 <fwp_args12+0x80>
    7b51:	80 f9 01             	cmp    $0x1,%cl
    7b54:	75 b6                	jne    7b0c <fwp_args12+0xc>
    7b56:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7b59:	0f b7 c0             	movzwl %ax,%eax
    7b5c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b5f:	48 0f af c1          	imul   %rcx,%rax
    7b63:	48 c1 e8 20          	shr    $0x20,%rax
    7b67:	48 39 d0             	cmp    %rdx,%rax
    7b6a:	73 a0                	jae    7b0c <fwp_args12+0xc>
    7b6c:	48 01 c7             	add    %rax,%rdi
    7b6f:	0f b6 07             	movzbl (%rdi),%eax
    7b72:	84 c0                	test   %al,%al
    7b74:	74 96                	je     7b0c <fwp_args12+0xc>
    7b76:	3c fd                	cmp    $0xfd,%al
    7b78:	77 0c                	ja     7b86 <fwp_args12+0x86>
    7b7a:	83 c0 01             	add    $0x1,%eax
    7b7d:	88 07                	mov    %al,(%rdi)
    7b7f:	c3                   	ret
    7b80:	66 85 c0             	test   %ax,%ax
    7b83:	74 ea                	je     7b6f <fwp_args12+0x6f>
    7b85:	c3                   	ret
    7b86:	e9 05 d9 ff ff       	jmp    5490 <fwp_rc_wide_dup>
    7b8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007b90 <fwp_args23>:
    7b90:	f3 0f 1e fa          	endbr64
    7b94:	85 d2                	test   %edx,%edx
    7b96:	74 04                	je     7b9c <fwp_args23+0xc>
    7b98:	85 f6                	test   %esi,%esi
    7b9a:	74 04                	je     7ba0 <fwp_args23+0x10>
    7b9c:	c3                   	ret
    7b9d:	0f 1f 00             	nopl   (%rax)
    7ba0:	48 8b 15 31 b0 01 00 	mov    0x1b031(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    7ba7:	48 8b 07             	mov    (%rdi),%rax
    7baa:	48 2b 05 ff af 01 00 	sub    0x1afff(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    7bb1:	48 c1 e2 10          	shl    $0x10,%rdx
    7bb5:	48 39 d0             	cmp    %rdx,%rax
    7bb8:	73 e2                	jae    7b9c <fwp_args23+0xc>
    7bba:	48 89 c2             	mov    %rax,%rdx
    7bbd:	48 c1 ea 10          	shr    $0x10,%rdx
    7bc1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7bc5:	48 8b 15 2c b0 01 00 	mov    0x1b02c(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    7bcc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7bd0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7bd4:	48 85 ff             	test   %rdi,%rdi
    7bd7:	74 c3                	je     7b9c <fwp_args23+0xc>
    7bd9:	0f b6 0a             	movzbl (%rdx),%ecx
    7bdc:	80 f9 02             	cmp    $0x2,%cl
    7bdf:	74 2f                	je     7c10 <fwp_args23+0x80>
    7be1:	80 f9 01             	cmp    $0x1,%cl
    7be4:	75 b6                	jne    7b9c <fwp_args23+0xc>
    7be6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7be9:	0f b7 c0             	movzwl %ax,%eax
    7bec:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7bef:	48 0f af c1          	imul   %rcx,%rax
    7bf3:	48 c1 e8 20          	shr    $0x20,%rax
    7bf7:	48 39 d0             	cmp    %rdx,%rax
    7bfa:	73 a0                	jae    7b9c <fwp_args23+0xc>
    7bfc:	48 01 c7             	add    %rax,%rdi
    7bff:	0f b6 07             	movzbl (%rdi),%eax
    7c02:	84 c0                	test   %al,%al
    7c04:	74 96                	je     7b9c <fwp_args23+0xc>
    7c06:	3c fd                	cmp    $0xfd,%al
    7c08:	77 0c                	ja     7c16 <fwp_args23+0x86>
    7c0a:	83 c0 01             	add    $0x1,%eax
    7c0d:	88 07                	mov    %al,(%rdi)
    7c0f:	c3                   	ret
    7c10:	66 85 c0             	test   %ax,%ax
    7c13:	74 ea                	je     7bff <fwp_args23+0x6f>
    7c15:	c3                   	ret
    7c16:	e9 75 d8 ff ff       	jmp    5490 <fwp_rc_wide_dup>
    7c1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007c20 <fwp_caps12>:
    7c20:	f3 0f 1e fa          	endbr64
    7c24:	48 83 ec 18          	sub    $0x18,%rsp
    7c28:	8b 57 04             	mov    0x4(%rdi),%edx
    7c2b:	48 89 f8             	mov    %rdi,%rax
    7c2e:	85 d2                	test   %edx,%edx
    7c30:	0f 84 9a 00 00 00    	je     7cd0 <fwp_caps12+0xb0>
    7c36:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7c3a:	85 f6                	test   %esi,%esi
    7c3c:	0f 85 9e 00 00 00    	jne    7ce0 <fwp_caps12+0xc0>
    7c42:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7c47:	e8 64 ec ff ff       	call   68b0 <fwp_drop0>
    7c4c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7c51:	48 8b 0d 80 af 01 00 	mov    0x1af80(%rip),%rcx        # 22bd8 <fwp_heap+0x13d8>
    7c58:	48 89 c2             	mov    %rax,%rdx
    7c5b:	48 2b 15 4e af 01 00 	sub    0x1af4e(%rip),%rdx        # 22bb0 <fwp_heap+0x13b0>
    7c62:	48 c1 e1 10          	shl    $0x10,%rcx
    7c66:	48 39 ca             	cmp    %rcx,%rdx
    7c69:	73 6d                	jae    7cd8 <fwp_caps12+0xb8>
    7c6b:	48 89 d1             	mov    %rdx,%rcx
    7c6e:	48 c1 e9 10          	shr    $0x10,%rcx
    7c72:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7c76:	48 8b 0d 7b af 01 00 	mov    0x1af7b(%rip),%rcx        # 22bf8 <fwp_heap+0x13f8>
    7c7d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7c81:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7c85:	48 85 f6             	test   %rsi,%rsi
    7c88:	74 4e                	je     7cd8 <fwp_caps12+0xb8>
    7c8a:	0f b6 39             	movzbl (%rcx),%edi
    7c8d:	40 80 ff 02          	cmp    $0x2,%dil
    7c91:	0f 84 b9 00 00 00    	je     7d50 <fwp_caps12+0x130>
    7c97:	40 80 ff 01          	cmp    $0x1,%dil
    7c9b:	75 3b                	jne    7cd8 <fwp_caps12+0xb8>
    7c9d:	8b 79 18             	mov    0x18(%rcx),%edi
    7ca0:	0f b7 d2             	movzwl %dx,%edx
    7ca3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7ca6:	48 0f af d7          	imul   %rdi,%rdx
    7caa:	48 c1 ea 20          	shr    $0x20,%rdx
    7cae:	48 39 ca             	cmp    %rcx,%rdx
    7cb1:	73 25                	jae    7cd8 <fwp_caps12+0xb8>
    7cb3:	48 01 d6             	add    %rdx,%rsi
    7cb6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7cb9:	75 1d                	jne    7cd8 <fwp_caps12+0xb8>
    7cbb:	48 89 c7             	mov    %rax,%rdi
    7cbe:	48 83 c4 18          	add    $0x18,%rsp
    7cc2:	e9 29 db ff ff       	jmp    57f0 <fwp_mem_free>
    7cc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7cce:	00 00 
    7cd0:	85 f6                	test   %esi,%esi
    7cd2:	0f 84 79 ff ff ff    	je     7c51 <fwp_caps12+0x31>
    7cd8:	48 83 c4 18          	add    $0x18,%rsp
    7cdc:	c3                   	ret
    7cdd:	0f 1f 00             	nopl   (%rax)
    7ce0:	48 8b 05 f1 ae 01 00 	mov    0x1aef1(%rip),%rax        # 22bd8 <fwp_heap+0x13d8>
    7ce7:	48 2b 3d c2 ae 01 00 	sub    0x1aec2(%rip),%rdi        # 22bb0 <fwp_heap+0x13b0>
    7cee:	48 c1 e0 10          	shl    $0x10,%rax
    7cf2:	48 39 c7             	cmp    %rax,%rdi
    7cf5:	73 e1                	jae    7cd8 <fwp_caps12+0xb8>
    7cf7:	48 89 f8             	mov    %rdi,%rax
    7cfa:	48 c1 e8 10          	shr    $0x10,%rax
    7cfe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7d02:	48 8b 05 ef ae 01 00 	mov    0x1aeef(%rip),%rax        # 22bf8 <fwp_heap+0x13f8>
    7d09:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7d0d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7d11:	48 85 c0             	test   %rax,%rax
    7d14:	74 c2                	je     7cd8 <fwp_caps12+0xb8>
    7d16:	0f b6 0a             	movzbl (%rdx),%ecx
    7d19:	80 f9 02             	cmp    $0x2,%cl
    7d1c:	74 42                	je     7d60 <fwp_caps12+0x140>
    7d1e:	80 f9 01             	cmp    $0x1,%cl
    7d21:	75 b5                	jne    7cd8 <fwp_caps12+0xb8>
    7d23:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d26:	0f b7 ff             	movzwl %di,%edi
    7d29:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d2c:	48 0f af f9          	imul   %rcx,%rdi
    7d30:	48 c1 ef 20          	shr    $0x20,%rdi
    7d34:	48 39 d7             	cmp    %rdx,%rdi
    7d37:	73 9f                	jae    7cd8 <fwp_caps12+0xb8>
    7d39:	48 01 f8             	add    %rdi,%rax
    7d3c:	0f b6 10             	movzbl (%rax),%edx
    7d3f:	84 d2                	test   %dl,%dl
    7d41:	74 95                	je     7cd8 <fwp_caps12+0xb8>
    7d43:	80 fa fd             	cmp    $0xfd,%dl
    7d46:	77 23                	ja     7d6b <fwp_caps12+0x14b>
    7d48:	83 c2 01             	add    $0x1,%edx
    7d4b:	88 10                	mov    %dl,(%rax)
    7d4d:	eb 89                	jmp    7cd8 <fwp_caps12+0xb8>
    7d4f:	90                   	nop
    7d50:	66 85 d2             	test   %dx,%dx
    7d53:	0f 85 7f ff ff ff    	jne    7cd8 <fwp_caps12+0xb8>
    7d59:	e9 58 ff ff ff       	jmp    7cb6 <fwp_caps12+0x96>
    7d5e:	66 90                	xchg   %ax,%ax
    7d60:	66 85 ff             	test   %di,%di
    7d63:	0f 85 6f ff ff ff    	jne    7cd8 <fwp_caps12+0xb8>
    7d69:	eb d1                	jmp    7d3c <fwp_caps12+0x11c>
    7d6b:	48 89 c7             	mov    %rax,%rdi
    7d6e:	48 83 c4 18          	add    $0x18,%rsp
    7d72:	e9 19 d7 ff ff       	jmp    5490 <fwp_rc_wide_dup>
    7d77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7d7e:	00 00 

0000000000007d80 <f12>:
    7d80:	41 57                	push   %r15
    7d82:	41 56                	push   %r14
    7d84:	41 55                	push   %r13
    7d86:	4c 8d 2d 33 f1 ff ff 	lea    -0xecd(%rip),%r13        # 6ec0 <fwp_tape_scope_release>
    7d8d:	41 54                	push   %r12
    7d8f:	55                   	push   %rbp
    7d90:	53                   	push   %rbx
    7d91:	48 81 ec e8 00 00 00 	sub    $0xe8,%rsp
    7d98:	48 8b 15 39 ae 01 00 	mov    0x1ae39(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    7d9f:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    7da4:	4c 8d 7c 24 60       	lea    0x60(%rsp),%r15
    7da9:	48 c1 e2 10          	shl    $0x10,%rdx
    7dad:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7db4:	00 00 
    7db6:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    7dbd:	00 
    7dbe:	31 c0                	xor    %eax,%eax
    7dc0:	48 8b 05 d1 b6 01 00 	mov    0x1b6d1(%rip),%rax        # 23498 <fwp_cleanups>
    7dc7:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    7dce:	ff 
    7dcf:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    7dd4:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    7dd9:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    7dde:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    7de3:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    7de8:	48 8d 05 21 92 00 00 	lea    0x9221(%rip),%rax        # 11010 <fc23>
    7def:	48 2b 05 ba ad 01 00 	sub    0x1adba(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    7df6:	4c 89 3d 9b b6 01 00 	mov    %r15,0x1b69b(%rip)        # 23498 <fwp_cleanups>
    7dfd:	48 39 d0             	cmp    %rdx,%rax
    7e00:	73 5d                	jae    7e5f <f12+0xdf>
    7e02:	48 89 c2             	mov    %rax,%rdx
    7e05:	48 c1 ea 10          	shr    $0x10,%rdx
    7e09:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e0d:	48 8b 15 e4 ad 01 00 	mov    0x1ade4(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    7e14:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e18:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7e1c:	48 85 ff             	test   %rdi,%rdi
    7e1f:	74 3e                	je     7e5f <f12+0xdf>
    7e21:	0f b6 0a             	movzbl (%rdx),%ecx
    7e24:	80 f9 02             	cmp    $0x2,%cl
    7e27:	0f 84 d3 11 00 00    	je     9000 <f12+0x1280>
    7e2d:	80 f9 01             	cmp    $0x1,%cl
    7e30:	75 2d                	jne    7e5f <f12+0xdf>
    7e32:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7e35:	0f b7 c0             	movzwl %ax,%eax
    7e38:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e3b:	48 0f af c1          	imul   %rcx,%rax
    7e3f:	48 c1 e8 20          	shr    $0x20,%rax
    7e43:	48 39 d0             	cmp    %rdx,%rax
    7e46:	73 17                	jae    7e5f <f12+0xdf>
    7e48:	48 01 c7             	add    %rax,%rdi
    7e4b:	0f b6 07             	movzbl (%rdi),%eax
    7e4e:	84 c0                	test   %al,%al
    7e50:	74 0d                	je     7e5f <f12+0xdf>
    7e52:	3c fd                	cmp    $0xfd,%al
    7e54:	0f 87 04 14 00 00    	ja     925e <f12+0x14de>
    7e5a:	83 c0 01             	add    $0x1,%eax
    7e5d:	88 07                	mov    %al,(%rdi)
    7e5f:	48 8d 3d aa 91 00 00 	lea    0x91aa(%rip),%rdi        # 11010 <fc23>
    7e66:	e8 25 ed ff ff       	call   6b90 <fwp_closure_drop>
    7e6b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7e70:	48 85 c0             	test   %rax,%rax
    7e73:	0f 84 4b 13 00 00    	je     91c4 <f12+0x1444>
    7e79:	31 db                	xor    %ebx,%ebx
    7e7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7e80:	48 8b 40 10          	mov    0x10(%rax),%rax
    7e84:	48 83 c3 01          	add    $0x1,%rbx
    7e88:	48 85 c0             	test   %rax,%rax
    7e8b:	75 f3                	jne    7e80 <f12+0x100>
    7e8d:	31 ff                	xor    %edi,%edi
    7e8f:	e8 bc c3 ff ff       	call   4250 <descent_phase_step>
    7e94:	48 81 fb ff ff ff 7f 	cmp    $0x7fffffff,%rbx
    7e9b:	0f 87 b6 14 00 00    	ja     9357 <f12+0x15d7>
    7ea1:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    7ea6:	44 8b 05 d3 91 00 00 	mov    0x91d3(%rip),%r8d        # 11080 <registered_finish.0>
    7ead:	45 85 c0             	test   %r8d,%r8d
    7eb0:	0f 84 1a 11 00 00    	je     8fd0 <f12+0x1250>
    7eb6:	48 8b 15 5b 92 01 00 	mov    0x1925b(%rip),%rdx        # 21118 <fwp_tape_next_slot>
    7ebd:	48 8b 1d 64 92 01 00 	mov    0x19264(%rip),%rbx        # 21128 <fwp_ntapes>
    7ec4:	48 39 da             	cmp    %rbx,%rdx
    7ec7:	0f 8d e3 05 00 00    	jge    84b0 <f12+0x730>
    7ecd:	48 6b c2 68          	imul   $0x68,%rdx,%rax
    7ed1:	48 03 05 58 92 01 00 	add    0x19258(%rip),%rax        # 21130 <fwp_tapes>
    7ed8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7edf:	00 
    7ee0:	8b 78 04             	mov    0x4(%rax),%edi
    7ee3:	85 ff                	test   %edi,%edi
    7ee5:	75 0c                	jne    7ef3 <f12+0x173>
    7ee7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    7eed:	0f 86 bd 05 00 00    	jbe    84b0 <f12+0x730>
    7ef3:	48 83 c2 01          	add    $0x1,%rdx
    7ef7:	48 83 c0 68          	add    $0x68,%rax
    7efb:	48 39 da             	cmp    %rbx,%rdx
    7efe:	75 e0                	jne    7ee0 <f12+0x160>
    7f00:	48 81 fb fe ff 00 00 	cmp    $0xfffe,%rbx
    7f07:	0f 8f 7a 14 00 00    	jg     9387 <f12+0x1607>
    7f0d:	48 39 1d 0c 92 01 00 	cmp    %rbx,0x1920c(%rip)        # 21120 <fwp_tapes_cap>
    7f14:	48 8b 2d 15 92 01 00 	mov    0x19215(%rip),%rbp        # 21130 <fwp_tapes>
    7f1b:	75 4b                	jne    7f68 <f12+0x1e8>
    7f1d:	48 85 db             	test   %rbx,%rbx
    7f20:	0f 84 3a 12 00 00    	je     9160 <f12+0x13e0>
    7f26:	4c 8d 24 1b          	lea    (%rbx,%rbx,1),%r12
    7f2a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    7f2f:	49 39 c4             	cmp    %rax,%r12
    7f32:	4c 0f 4f e0          	cmovg  %rax,%r12
    7f36:	49 6b f4 68          	imul   $0x68,%r12,%rsi
    7f3a:	48 89 ef             	mov    %rbp,%rdi
    7f3d:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    7f43:	e8 88 b6 ff ff       	call   35d0 <realloc@plt>
    7f48:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    7f4e:	48 85 c0             	test   %rax,%rax
    7f51:	48 89 c5             	mov    %rax,%rbp
    7f54:	0f 84 eb 10 00 00    	je     9045 <f12+0x12c5>
    7f5a:	48 89 05 cf 91 01 00 	mov    %rax,0x191cf(%rip)        # 21130 <fwp_tapes>
    7f61:	4c 89 25 b8 91 01 00 	mov    %r12,0x191b8(%rip)        # 21120 <fwp_tapes_cap>
    7f68:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    7f6c:	4c 8d 63 01          	lea    0x1(%rbx),%r12
    7f70:	48 01 e8             	add    %rbp,%rax
    7f73:	48 8d 78 08          	lea    0x8(%rax),%rdi
    7f77:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    7f7e:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    7f82:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    7f89:	00 
    7f8a:	48 29 f8             	sub    %rdi,%rax
    7f8d:	8d 48 68             	lea    0x68(%rax),%ecx
    7f90:	31 c0                	xor    %eax,%eax
    7f92:	c1 e9 03             	shr    $0x3,%ecx
    7f95:	f3 48 ab             	rep stos %rax,(%rdi)
    7f98:	4c 89 25 89 91 01 00 	mov    %r12,0x19189(%rip)        # 21128 <fwp_ntapes>
    7f9f:	48 6b d3 68          	imul   $0x68,%rbx,%rdx
    7fa3:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    7fa7:	48 8d 3d 74 51 00 00 	lea    0x5174(%rip),%rdi        # d122 <_IO_stdin_used+0x122>
    7fae:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7fb3:	4c 8d 74 15 00       	lea    0x0(%rbp,%rdx,1),%r14
    7fb8:	49 c7 46 60 00 00 00 	movq   $0x0,0x60(%r14)
    7fbf:	00 
    7fc0:	e8 db b3 ff ff       	call   33a0 <getenv@plt>
    7fc5:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    7fcb:	48 85 c0             	test   %rax,%rax
    7fce:	74 09                	je     7fd9 <f12+0x259>
    7fd0:	80 38 30             	cmpb   $0x30,(%rax)
    7fd3:	0f 84 27 04 00 00    	je     8400 <f12+0x680>
    7fd9:	48 83 3d e7 90 01 00 	cmpq   $0x0,0x190e7(%rip)        # 210c8 <fwp_tape_cached_bytes>
    7fe0:	00 
    7fe1:	0f 85 b9 10 00 00    	jne    90a0 <f12+0x1320>
    7fe7:	41 8b 06             	mov    (%r14),%eax
    7fea:	41 c7 46 04 01 00 00 	movl   $0x1,0x4(%r14)
    7ff1:	00 
    7ff2:	4c 89 25 1f 91 01 00 	mov    %r12,0x1911f(%rip)        # 21118 <fwp_tape_next_slot>
    7ff9:	8d 70 01             	lea    0x1(%rax),%esi
    7ffc:	48 8b 05 95 b4 01 00 	mov    0x1b495(%rip),%rax        # 23498 <fwp_cleanups>
    8003:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
    8008:	41 89 36             	mov    %esi,(%r14)
    800b:	49 c7 46 50 00 00 00 	movq   $0x0,0x50(%r14)
    8012:	00 
    8013:	49 c7 46 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%r14)
    801a:	ff 
    801b:	48 85 c0             	test   %rax,%rax
    801e:	75 1c                	jne    803c <f12+0x2bc>
    8020:	e9 56 13 00 00       	jmp    937b <f12+0x15fb>
    8025:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    802c:	00 00 00 00 
    8030:	48 8b 00             	mov    (%rax),%rax
    8033:	48 85 c0             	test   %rax,%rax
    8036:	0f 84 3f 13 00 00    	je     937b <f12+0x15fb>
    803c:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    8040:	75 ee                	jne    8030 <f12+0x2b0>
    8042:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8046:	89 df                	mov    %ebx,%edi
    8048:	48 63 01             	movslq (%rcx),%rax
    804b:	49 89 4e 50          	mov    %rcx,0x50(%r14)
    804f:	41 89 46 5c          	mov    %eax,0x5c(%r14)
    8053:	85 c0                	test   %eax,%eax
    8055:	78 08                	js     805f <f12+0x2df>
    8057:	48 6b c0 68          	imul   $0x68,%rax,%rax
    805b:	89 5c 05 58          	mov    %ebx,0x58(%rbp,%rax,1)
    805f:	89 39                	mov    %edi,(%rcx)
    8061:	bf 01 00 00 00       	mov    $0x1,%edi
    8066:	89 74 24 10          	mov    %esi,0x10(%rsp)
    806a:	e8 e1 c1 ff ff       	call   4250 <descent_phase_step>
    806f:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8074:	31 c9                	xor    %ecx,%ecx
    8076:	8b 74 24 10          	mov    0x10(%rsp),%esi
    807a:	48 85 ff             	test   %rdi,%rdi
    807d:	48 89 f8             	mov    %rdi,%rax
    8080:	0f 84 8a 03 00 00    	je     8410 <f12+0x690>
    8086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    808d:	00 00 00 
    8090:	48 8b 40 10          	mov    0x10(%rax),%rax
    8094:	48 83 c1 01          	add    $0x1,%rcx
    8098:	48 85 c0             	test   %rax,%rax
    809b:	75 f3                	jne    8090 <f12+0x310>
    809d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    80a2:	0f 1f 00             	nopl   (%rax)
    80a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    80ac:	00 00 00 00 
    80b0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    80b4:	48 83 c0 01          	add    $0x1,%rax
    80b8:	48 85 d2             	test   %rdx,%rdx
    80bb:	75 f3                	jne    80b0 <f12+0x330>
    80bd:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    80c4:	ff ff 1f 
    80c7:	48 39 c2             	cmp    %rax,%rdx
    80ca:	0f 82 93 12 00 00    	jb     9363 <f12+0x15e3>
    80d0:	48 85 c9             	test   %rcx,%rcx
    80d3:	0f 8e 37 03 00 00    	jle    8410 <f12+0x690>
    80d9:	48 39 c1             	cmp    %rax,%rcx
    80dc:	48 0f 46 c1          	cmovbe %rcx,%rax
    80e0:	49 89 c5             	mov    %rax,%r13
    80e3:	48 c1 e8 3c          	shr    $0x3c,%rax
    80e7:	0f 85 76 12 00 00    	jne    9363 <f12+0x15e3>
    80ed:	4b 8d 6c 2d 00       	lea    0x0(%r13,%r13,1),%rbp
    80f2:	48 c1 e6 10          	shl    $0x10,%rsi
    80f6:	49 09 f4             	or     %rsi,%r12
    80f9:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8100:	00 
    8101:	be 02 00 00 00       	mov    $0x2,%esi
    8106:	e8 e5 db ff ff       	call   5cf0 <fwp_heap_alloc>
    810b:	48 89 28             	mov    %rbp,(%rax)
    810e:	48 8b 15 c3 aa 01 00 	mov    0x1aac3(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    8115:	48 89 c3             	mov    %rax,%rbx
    8118:	48 2b 05 91 aa 01 00 	sub    0x1aa91(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    811f:	48 c1 e2 10          	shl    $0x10,%rdx
    8123:	48 39 d0             	cmp    %rdx,%rax
    8126:	0f 83 64 03 00 00    	jae    8490 <f12+0x710>
    812c:	48 89 c2             	mov    %rax,%rdx
    812f:	48 c1 ea 10          	shr    $0x10,%rdx
    8133:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8137:	48 8b 15 ba aa 01 00 	mov    0x1aaba(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    813e:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8142:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8146:	48 85 d2             	test   %rdx,%rdx
    8149:	74 38                	je     8183 <f12+0x403>
    814b:	0f b6 31             	movzbl (%rcx),%esi
    814e:	40 80 fe 02          	cmp    $0x2,%sil
    8152:	0f 84 22 03 00 00    	je     847a <f12+0x6fa>
    8158:	40 80 fe 01          	cmp    $0x1,%sil
    815c:	75 25                	jne    8183 <f12+0x403>
    815e:	8b 71 18             	mov    0x18(%rcx),%esi
    8161:	0f b7 c0             	movzwl %ax,%eax
    8164:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8167:	48 0f af c6          	imul   %rsi,%rax
    816b:	48 c1 e8 20          	shr    $0x20,%rax
    816f:	48 39 c8             	cmp    %rcx,%rax
    8172:	73 0f                	jae    8183 <f12+0x403>
    8174:	48 01 c2             	add    %rax,%rdx
    8177:	80 3a ff             	cmpb   $0xff,(%rdx)
    817a:	0f 84 ad 10 00 00    	je     922d <f12+0x14ad>
    8180:	c6 02 01             	movb   $0x1,(%rdx)
    8183:	4d 85 ed             	test   %r13,%r13
    8186:	74 6b                	je     81f3 <f12+0x473>
    8188:	4c 89 e1             	mov    %r12,%rcx
    818b:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    8190:	31 c0                	xor    %eax,%eax
    8192:	48 c1 e1 20          	shl    $0x20,%rcx
    8196:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    819d:	00 00 
    819f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    81a6:	00 00 00 00 
    81aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    81b1:	00 00 00 00 
    81b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    81bc:	00 00 00 00 
    81c0:	48 89 c6             	mov    %rax,%rsi
    81c3:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    81c8:	48 01 ce             	add    %rcx,%rsi
    81cb:	0f 80 6d 11 00 00    	jo     933e <f12+0x15be>
    81d1:	66 48 0f 6e de       	movq   %rsi,%xmm3
    81d6:	48 89 c6             	mov    %rax,%rsi
    81d9:	48 83 c0 01          	add    $0x1,%rax
    81dd:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    81e1:	48 c1 e6 04          	shl    $0x4,%rsi
    81e5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    81ea:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    81ee:	4c 39 e8             	cmp    %r13,%rax
    81f1:	72 cd                	jb     81c0 <f12+0x440>
    81f3:	48 8b 03             	mov    (%rbx),%rax
    81f6:	48 d1 e8             	shr    $1,%rax
    81f9:	0f 84 a1 02 00 00    	je     84a0 <f12+0x720>
    81ff:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    8203:	48 89 d1             	mov    %rdx,%rcx
    8206:	48 c1 e9 3c          	shr    $0x3c,%rcx
    820a:	0f 85 53 11 00 00    	jne    9363 <f12+0x15e3>
    8210:	48 8d 2c 12          	lea    (%rdx,%rdx,1),%rbp
    8214:	48 85 d2             	test   %rdx,%rdx
    8217:	74 45                	je     825e <f12+0x4de>
    8219:	48 c1 e0 04          	shl    $0x4,%rax
    821d:	4c 8d 73 08          	lea    0x8(%rbx),%r14
    8221:	4c 8d 6c 03 f8       	lea    -0x8(%rbx,%rax,1),%r13
    8226:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    822d:	00 00 00 
    8230:	f2 41 0f 10 06       	movsd  (%r14),%xmm0
    8235:	49 8b 76 18          	mov    0x18(%r14),%rsi
    8239:	49 83 c6 10          	add    $0x10,%r14
    823d:	49 8b 7e f8          	mov    -0x8(%r14),%rdi
    8241:	f2 41 0f 10 0e       	movsd  (%r14),%xmm1
    8246:	e8 85 e1 ff ff       	call   63d0 <w107>
    824b:	66 48 0f 6e e0       	movq   %rax,%xmm4
    8250:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    8254:	41 0f 11 46 f0       	movups %xmm0,-0x10(%r14)
    8259:	4d 39 f5             	cmp    %r14,%r13
    825c:	75 d2                	jne    8230 <f12+0x4b0>
    825e:	48 89 2b             	mov    %rbp,(%rbx)
    8261:	48 89 df             	mov    %rbx,%rdi
    8264:	e8 e7 e2 ff ff       	call   6550 <w164.constprop.0>
    8269:	48 89 df             	mov    %rbx,%rdi
    826c:	49 63 dc             	movslq %r12d,%rbx
    826f:	49 89 c5             	mov    %rax,%r13
    8272:	e8 f9 f5 ff ff       	call   7870 <fwp_drop4>
    8277:	bf 02 00 00 00       	mov    $0x2,%edi
    827c:	e8 df cc ff ff       	call   4f60 <caf61>
    8281:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    8286:	e8 c5 bf ff ff       	call   4250 <descent_phase_step>
    828b:	48 89 df             	mov    %rbx,%rdi
    828e:	e8 3d c4 ff ff       	call   46d0 <fwp_tape_of>
    8293:	48 89 c6             	mov    %rax,%rsi
    8296:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    829b:	0f 85 ce 10 00 00    	jne    936f <f12+0x15ef>
    82a1:	48 89 c7             	mov    %rax,%rdi
    82a4:	e8 57 b9 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    82a9:	f3 0f 6f 7e 20       	movdqu 0x20(%rsi),%xmm7
    82ae:	4c 8b 56 48          	mov    0x48(%rsi),%r10
    82b2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    82b9:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    82be:	48 8b 6e 08          	mov    0x8(%rsi),%rbp
    82c2:	0f 29 7c 24 20       	movaps %xmm7,0x20(%rsp)
    82c7:	f3 0f 6f 7e 30       	movdqu 0x30(%rsi),%xmm7
    82cc:	66 49 0f 6e d2       	movq   %r10,%xmm2
    82d1:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    82d5:	4c 8b 76 40          	mov    0x40(%rsi),%r14
    82d9:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    82dd:	0f 29 7c 24 10       	movaps %xmm7,0x10(%rsp)
    82e2:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    82e8:	77 19                	ja     8303 <f12+0x583>
    82ea:	41 0f b7 c4          	movzwl %r12w,%eax
    82ee:	83 e8 01             	sub    $0x1,%eax
    82f1:	48 98                	cltq
    82f3:	48 3b 05 1e 8e 01 00 	cmp    0x18e1e(%rip),%rax        # 21118 <fwp_tape_next_slot>
    82fa:	7d 07                	jge    8303 <f12+0x583>
    82fc:	48 89 05 15 8e 01 00 	mov    %rax,0x18e15(%rip)        # 21118 <fwp_tape_next_slot>
    8303:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8307:	48 8b 05 8a b1 01 00 	mov    0x1b18a(%rip),%rax        # 23498 <fwp_cleanups>
    830e:	66 0f 6f 7c 24 20    	movdqa 0x20(%rsp),%xmm7
    8314:	4c 8d a4 24 a0 00 00 	lea    0xa0(%rsp),%r12
    831b:	00 
    831c:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    8322:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8326:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    832d:	00 
    832e:	48 8d 05 9b cd ff ff 	lea    -0x3265(%rip),%rax        # 50d0 <fwp_tape_buffers_release>
    8335:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    833c:	00 
    833d:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    8344:	00 
    8345:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    834c:	00 
    834d:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    8351:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    8355:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    835c:	00 
    835d:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    8364:	00 
    8365:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
    836c:	00 
    836d:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    8374:	00 
    8375:	48 89 05 1c b1 01 00 	mov    %rax,0x1b11c(%rip)        # 23498 <fwp_cleanups>
    837c:	0f 29 bc 24 a0 00 00 	movaps %xmm7,0xa0(%rsp)
    8383:	00 
    8384:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    838b:	00 
    838c:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    8393:	00 
    8394:	4d 85 ed             	test   %r13,%r13
    8397:	0f 88 73 0c 00 00    	js     9010 <f12+0x1290>
    839d:	4c 89 e8             	mov    %r13,%rax
    83a0:	48 c1 f8 20          	sar    $0x20,%rax
    83a4:	48 39 c3             	cmp    %rax,%rbx
    83a7:	0f 85 68 0f 00 00    	jne    9315 <f12+0x1595>
    83ad:	45 89 e9             	mov    %r13d,%r9d
    83b0:	4c 89 cb             	mov    %r9,%rbx
    83b3:	4c 39 ca             	cmp    %r9,%rdx
    83b6:	0f 8e 65 0f 00 00    	jle    9321 <f12+0x15a1>
    83bc:	4c 39 cd             	cmp    %r9,%rbp
    83bf:	0f 8e 0b 01 00 00    	jle    84d0 <f12+0x750>
    83c5:	4c 39 d5             	cmp    %r10,%rbp
    83c8:	0f 8f 42 0d 00 00    	jg     9110 <f12+0x1390>
    83ce:	4d 85 f6             	test   %r14,%r14
    83d1:	0f 84 57 0c 00 00    	je     902e <f12+0x12ae>
    83d7:	31 f6                	xor    %esi,%esi
    83d9:	4c 89 f7             	mov    %r14,%rdi
    83dc:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
    83e1:	48 8d 5d ff          	lea    -0x1(%rbp),%rbx
    83e5:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    83ec:	00 
    83ed:	e8 ce b0 ff ff       	call   34c0 <memset@plt>
    83f2:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
    83f7:	45 31 d2             	xor    %r10d,%r10d
    83fa:	e9 82 01 00 00       	jmp    8581 <f12+0x801>
    83ff:	90                   	nop
    8400:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    8404:	0f 84 dd fb ff ff    	je     7fe7 <f12+0x267>
    840a:	e9 ca fb ff ff       	jmp    7fd9 <f12+0x259>
    840f:	90                   	nop
    8410:	48 c1 e6 10          	shl    $0x10,%rsi
    8414:	bf 08 00 00 00       	mov    $0x8,%edi
    8419:	49 09 f4             	or     %rsi,%r12
    841c:	be 02 00 00 00       	mov    $0x2,%esi
    8421:	e8 ca d8 ff ff       	call   5cf0 <fwp_heap_alloc>
    8426:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    842d:	48 8b 15 a4 a7 01 00 	mov    0x1a7a4(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    8434:	48 89 c3             	mov    %rax,%rbx
    8437:	48 2b 05 72 a7 01 00 	sub    0x1a772(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    843e:	48 c1 e2 10          	shl    $0x10,%rdx
    8442:	48 39 d0             	cmp    %rdx,%rax
    8445:	73 59                	jae    84a0 <f12+0x720>
    8447:	48 89 c2             	mov    %rax,%rdx
    844a:	48 c1 ea 10          	shr    $0x10,%rdx
    844e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8452:	48 8b 15 9f a7 01 00 	mov    0x1a79f(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    8459:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    845d:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8461:	48 85 d2             	test   %rdx,%rdx
    8464:	0f 84 89 fd ff ff    	je     81f3 <f12+0x473>
    846a:	0f b6 31             	movzbl (%rcx),%esi
    846d:	45 31 ed             	xor    %r13d,%r13d
    8470:	40 80 fe 02          	cmp    $0x2,%sil
    8474:	0f 85 de fc ff ff    	jne    8158 <f12+0x3d8>
    847a:	66 85 c0             	test   %ax,%ax
    847d:	0f 85 00 fd ff ff    	jne    8183 <f12+0x403>
    8483:	e9 ef fc ff ff       	jmp    8177 <f12+0x3f7>
    8488:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    848f:	00 
    8490:	4d 85 ed             	test   %r13,%r13
    8493:	0f 85 ef fc ff ff    	jne    8188 <f12+0x408>
    8499:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    84a0:	31 ed                	xor    %ebp,%ebp
    84a2:	e9 b7 fd ff ff       	jmp    825e <f12+0x4de>
    84a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    84ae:	00 00 
    84b0:	48 39 d3             	cmp    %rdx,%rbx
    84b3:	0f 84 47 fa ff ff    	je     7f00 <f12+0x180>
    84b9:	48 8b 2d 70 8c 01 00 	mov    0x18c70(%rip),%rbp        # 21130 <fwp_tapes>
    84c0:	48 89 d3             	mov    %rdx,%rbx
    84c3:	4c 8d 62 01          	lea    0x1(%rdx),%r12
    84c7:	e9 d3 fa ff ff       	jmp    7f9f <f12+0x21f>
    84cc:	0f 1f 40 00          	nopl   0x0(%rax)
    84d0:	49 8d 51 01          	lea    0x1(%r9),%rdx
    84d4:	49 39 d2             	cmp    %rdx,%r10
    84d7:	0f 8d 43 0c 00 00    	jge    9120 <f12+0x13a0>
    84dd:	4d 85 d2             	test   %r10,%r10
    84e0:	4c 0f 44 d2          	cmove  %rdx,%r10
    84e4:	eb 2f                	jmp    8515 <f12+0x795>
    84e6:	0f 1f 40 00          	nopl   0x0(%rax)
    84ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    84f1:	00 00 00 00 
    84f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    84fc:	00 00 00 00 
    8500:	4b 8d 34 12          	lea    (%r10,%r10,1),%rsi
    8504:	49 81 fa 00 00 00 40 	cmp    $0x40000000,%r10
    850b:	48 89 d0             	mov    %rdx,%rax
    850e:	48 0f 4c c6          	cmovl  %rsi,%rax
    8512:	49 89 c2             	mov    %rax,%r10
    8515:	4c 39 d2             	cmp    %r10,%rdx
    8518:	7f e6                	jg     8500 <f12+0x780>
    851a:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
    851f:	4d 85 f6             	test   %r14,%r14
    8522:	0f 84 78 0c 00 00    	je     91a0 <f12+0x1420>
    8528:	4a 8d 34 d5 00 00 00 	lea    0x0(,%r10,8),%rsi
    852f:	00 
    8530:	4c 89 f7             	mov    %r14,%rdi
    8533:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
    8538:	e8 93 b0 ff ff       	call   35d0 <realloc@plt>
    853d:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
    8542:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
    8547:	49 89 c6             	mov    %rax,%r14
    854a:	4d 85 f6             	test   %r14,%r14
    854d:	0f 84 c9 0a 00 00    	je     901c <f12+0x129c>
    8553:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
    855a:	00 
    855b:	4c 89 94 24 d0 00 00 	mov    %r10,0xd0(%rsp)
    8562:	00 
    8563:	48 85 d2             	test   %rdx,%rdx
    8566:	0f 85 fc 0c 00 00    	jne    9268 <f12+0x14e8>
    856c:	49 89 ea             	mov    %rbp,%r10
    856f:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    8576:	49 f7 da             	neg    %r10
    8579:	4d 85 ed             	test   %r13,%r13
    857c:	78 15                	js     8593 <f12+0x813>
    857e:	45 89 e9             	mov    %r13d,%r9d
    8581:	f2 0f 10 44 24 38    	movsd  0x38(%rsp),%xmm0
    8587:	f2 43 0f 58 04 ce    	addsd  (%r14,%r9,8),%xmm0
    858d:	f2 43 0f 11 04 ce    	movsd  %xmm0,(%r14,%r9,8)
    8593:	bf 03 00 00 00       	mov    $0x3,%edi
    8598:	48 01 2d a1 8b 01 00 	add    %rbp,0x18ba1(%rip)        # 21140 <descent_inputs>
    859f:	4c 01 15 a2 8b 01 00 	add    %r10,0x18ba2(%rip)        # 21148 <descent_nodes>
    85a6:	e8 a5 bc ff ff       	call   4250 <descent_phase_step>
    85ab:	48 39 dd             	cmp    %rbx,%rbp
    85ae:	0f 8f 8e 00 00 00    	jg     8642 <f12+0x8c2>
    85b4:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    85b9:	48 29 eb             	sub    %rbp,%rbx
    85bc:	4d 8d 0c ee          	lea    (%r14,%rbp,8),%r9
    85c0:	66 0f ef d2          	pxor   %xmm2,%xmm2
    85c4:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    85c9:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
    85ce:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    85d3:	49 8d 14 db          	lea    (%r11,%rbx,8),%rdx
    85d7:	4d 29 d9             	sub    %r11,%r9
    85da:	48 8d 04 9f          	lea    (%rdi,%rbx,4),%rax
    85de:	48 29 fe             	sub    %rdi,%rsi
    85e1:	4d 29 da             	sub    %r11,%r10
    85e4:	eb 0e                	jmp    85f4 <f12+0x874>
    85e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    85ed:	00 00 00 
    85f0:	48 83 e8 04          	sub    $0x4,%rax
    85f4:	f2 41 0f 10 04 11    	movsd  (%r9,%rdx,1),%xmm0
    85fa:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    85fe:	7a 02                	jp     8602 <f12+0x882>
    8600:	74 37                	je     8639 <f12+0x8b9>
    8602:	4c 63 1c 06          	movslq (%rsi,%rax,1),%r11
    8606:	45 85 db             	test   %r11d,%r11d
    8609:	78 16                	js     8621 <f12+0x8a1>
    860b:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    8611:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    8615:	f2 43 0f 58 0c de    	addsd  (%r14,%r11,8),%xmm1
    861b:	f2 43 0f 11 0c de    	movsd  %xmm1,(%r14,%r11,8)
    8621:	4c 63 18             	movslq (%rax),%r11
    8624:	45 85 db             	test   %r11d,%r11d
    8627:	78 10                	js     8639 <f12+0x8b9>
    8629:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    862d:	f2 43 0f 58 04 de    	addsd  (%r14,%r11,8),%xmm0
    8633:	f2 43 0f 11 04 de    	movsd  %xmm0,(%r14,%r11,8)
    8639:	48 83 ea 08          	sub    $0x8,%rdx
    863d:	48 39 c7             	cmp    %rax,%rdi
    8640:	75 ae                	jne    85f0 <f12+0x870>
    8642:	bf 04 00 00 00       	mov    $0x4,%edi
    8647:	e8 04 bc ff ff       	call   4250 <descent_phase_step>
    864c:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8653:	ff ff 1f 
    8656:	48 39 e8             	cmp    %rbp,%rax
    8659:	0f 82 ec 0c 00 00    	jb     934b <f12+0x15cb>
    865f:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8666:	00 
    8667:	be 02 00 00 00       	mov    $0x2,%esi
    866c:	e8 7f d6 ff ff       	call   5cf0 <fwp_heap_alloc>
    8671:	48 89 28             	mov    %rbp,(%rax)
    8674:	48 89 c3             	mov    %rax,%rbx
    8677:	31 c0                	xor    %eax,%eax
    8679:	48 85 ed             	test   %rbp,%rbp
    867c:	74 14                	je     8692 <f12+0x912>
    867e:	66 90                	xchg   %ax,%ax
    8680:	49 8b 14 c6          	mov    (%r14,%rax,8),%rdx
    8684:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    8689:	48 83 c0 01          	add    $0x1,%rax
    868d:	48 39 c5             	cmp    %rax,%rbp
    8690:	75 ee                	jne    8680 <f12+0x900>
    8692:	bf 05 00 00 00       	mov    $0x5,%edi
    8697:	e8 b4 bb ff ff       	call   4250 <descent_phase_step>
    869c:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
    86a3:	00 
    86a4:	4c 89 e7             	mov    %r12,%rdi
    86a7:	4c 89 2d ea ad 01 00 	mov    %r13,0x1adea(%rip)        # 23498 <fwp_cleanups>
    86ae:	e8 1d ca ff ff       	call   50d0 <fwp_tape_buffers_release>
    86b3:	bf 06 00 00 00       	mov    $0x6,%edi
    86b8:	e8 93 bb ff ff       	call   4250 <descent_phase_step>
    86bd:	48 8b 15 14 a5 01 00 	mov    0x1a514(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    86c4:	48 89 d8             	mov    %rbx,%rax
    86c7:	48 2b 05 e2 a4 01 00 	sub    0x1a4e2(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    86ce:	48 c1 e2 10          	shl    $0x10,%rdx
    86d2:	48 39 d0             	cmp    %rdx,%rax
    86d5:	73 59                	jae    8730 <f12+0x9b0>
    86d7:	48 89 c2             	mov    %rax,%rdx
    86da:	48 c1 ea 10          	shr    $0x10,%rdx
    86de:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    86e2:	48 8b 15 0f a5 01 00 	mov    0x1a50f(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    86e9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    86ed:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    86f1:	4d 85 e4             	test   %r12,%r12
    86f4:	74 3a                	je     8730 <f12+0x9b0>
    86f6:	0f b6 0a             	movzbl (%rdx),%ecx
    86f9:	80 f9 02             	cmp    $0x2,%cl
    86fc:	0f 84 76 09 00 00    	je     9078 <f12+0x12f8>
    8702:	80 f9 01             	cmp    $0x1,%cl
    8705:	75 29                	jne    8730 <f12+0x9b0>
    8707:	8b 4a 18             	mov    0x18(%rdx),%ecx
    870a:	0f b7 c0             	movzwl %ax,%eax
    870d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8710:	48 0f af c1          	imul   %rcx,%rax
    8714:	48 c1 e8 20          	shr    $0x20,%rax
    8718:	48 39 d0             	cmp    %rdx,%rax
    871b:	73 13                	jae    8730 <f12+0x9b0>
    871d:	49 01 c4             	add    %rax,%r12
    8720:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8725:	0f 84 19 0b 00 00    	je     9244 <f12+0x14c4>
    872b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8730:	4d 39 fd             	cmp    %r15,%r13
    8733:	0f 85 12 b0 ff ff    	jne    374b <f12.cold>
    8739:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    873e:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    8743:	48 89 05 4e ad 01 00 	mov    %rax,0x1ad4e(%rip)        # 23498 <fwp_cleanups>
    874a:	e8 71 e7 ff ff       	call   6ec0 <fwp_tape_scope_release>
    874f:	48 8b 03             	mov    (%rbx),%rax
    8752:	49 89 c4             	mov    %rax,%r12
    8755:	49 0f ba f4 3f       	btr    $0x3f,%r12
    875a:	48 85 c0             	test   %rax,%rax
    875d:	0f 88 9d 07 00 00    	js     8f00 <f12+0x1180>
    8763:	48 8b 15 6e a4 01 00 	mov    0x1a46e(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    876a:	48 89 d8             	mov    %rbx,%rax
    876d:	48 2b 05 3c a4 01 00 	sub    0x1a43c(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    8774:	48 c1 e2 10          	shl    $0x10,%rdx
    8778:	48 39 d0             	cmp    %rdx,%rax
    877b:	0f 83 7f 07 00 00    	jae    8f00 <f12+0x1180>
    8781:	48 89 c2             	mov    %rax,%rdx
    8784:	48 c1 ea 10          	shr    $0x10,%rdx
    8788:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    878c:	48 8b 15 65 a4 01 00 	mov    0x1a465(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    8793:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8797:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    879b:	48 85 c9             	test   %rcx,%rcx
    879e:	0f 84 5c 07 00 00    	je     8f00 <f12+0x1180>
    87a4:	0f b6 32             	movzbl (%rdx),%esi
    87a7:	40 80 fe 02          	cmp    $0x2,%sil
    87ab:	0f 84 3f 07 00 00    	je     8ef0 <f12+0x1170>
    87b1:	40 80 fe 01          	cmp    $0x1,%sil
    87b5:	0f 85 45 07 00 00    	jne    8f00 <f12+0x1180>
    87bb:	8b 72 18             	mov    0x18(%rdx),%esi
    87be:	0f b7 c0             	movzwl %ax,%eax
    87c1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    87c4:	48 0f af c6          	imul   %rsi,%rax
    87c8:	48 c1 e8 20          	shr    $0x20,%rax
    87cc:	48 39 d0             	cmp    %rdx,%rax
    87cf:	0f 83 2b 07 00 00    	jae    8f00 <f12+0x1180>
    87d5:	48 01 c1             	add    %rax,%rcx
    87d8:	80 39 01             	cmpb   $0x1,(%rcx)
    87db:	0f 85 1f 07 00 00    	jne    8f00 <f12+0x1180>
    87e1:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
    87e6:	49 89 dd             	mov    %rbx,%r13
    87e9:	31 ff                	xor    %edi,%edi
    87eb:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    87f0:	f2 0f 10 0d 50 54 00 	movsd  0x5450(%rip),%xmm1        # dc48 <msg.8+0xd8>
    87f7:	00 
    87f8:	48 8d 50 08          	lea    0x8(%rax),%rdx
    87fc:	31 c0                	xor    %eax,%eax
    87fe:	4d 85 e4             	test   %r12,%r12
    8801:	75 2b                	jne    882e <f12+0xaae>
    8803:	eb 3b                	jmp    8840 <f12+0xac0>
    8805:	0f 1f 00             	nopl   (%rax)
    8808:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    880d:	0f 88 1f 0b 00 00    	js     9332 <f12+0x15b2>
    8813:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    8818:	48 83 c0 01          	add    $0x1,%rax
    881c:	48 83 c2 08          	add    $0x8,%rdx
    8820:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    8824:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8829:	49 39 c4             	cmp    %rax,%r12
    882c:	74 12                	je     8840 <f12+0xac0>
    882e:	48 8d 4b 08          	lea    0x8(%rbx),%rcx
    8832:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    8836:	79 d0                	jns    8808 <f12+0xa88>
    8838:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
    883c:	eb ca                	jmp    8808 <f12+0xa88>
    883e:	66 90                	xchg   %ax,%ax
    8840:	e8 2b f0 ff ff       	call   7870 <fwp_drop4>
    8845:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    884a:	31 d2                	xor    %edx,%edx
    884c:	48 89 c8             	mov    %rcx,%rax
    884f:	48 85 c9             	test   %rcx,%rcx
    8852:	0f 84 7c 09 00 00    	je     91d4 <f12+0x1454>
    8858:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    885f:	00 
    8860:	48 8b 40 10          	mov    0x10(%rax),%rax
    8864:	48 83 c2 01          	add    $0x1,%rdx
    8868:	48 85 c0             	test   %rax,%rax
    886b:	75 f3                	jne    8860 <f12+0xae0>
    886d:	49 8b 45 00          	mov    0x0(%r13),%rax
    8871:	49 89 c7             	mov    %rax,%r15
    8874:	49 0f ba f7 3f       	btr    $0x3f,%r15
    8879:	48 85 c0             	test   %rax,%rax
    887c:	0f 88 d3 05 00 00    	js     8e55 <f12+0x10d5>
    8882:	48 8b 0d 4f a3 01 00 	mov    0x1a34f(%rip),%rcx        # 22bd8 <fwp_heap+0x13d8>
    8889:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    888e:	48 2b 05 1b a3 01 00 	sub    0x1a31b(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    8895:	48 c1 e1 10          	shl    $0x10,%rcx
    8899:	48 39 c8             	cmp    %rcx,%rax
    889c:	0f 83 b3 05 00 00    	jae    8e55 <f12+0x10d5>
    88a2:	48 89 c1             	mov    %rax,%rcx
    88a5:	48 c1 e9 10          	shr    $0x10,%rcx
    88a9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    88ad:	48 8b 0d 44 a3 01 00 	mov    0x1a344(%rip),%rcx        # 22bf8 <fwp_heap+0x13f8>
    88b4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    88b8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    88bc:	48 85 ff             	test   %rdi,%rdi
    88bf:	0f 84 90 05 00 00    	je     8e55 <f12+0x10d5>
    88c5:	0f b6 0e             	movzbl (%rsi),%ecx
    88c8:	80 f9 02             	cmp    $0x2,%cl
    88cb:	0f 84 6f 05 00 00    	je     8e40 <f12+0x10c0>
    88d1:	80 f9 01             	cmp    $0x1,%cl
    88d4:	0f 85 6f 05 00 00    	jne    8e49 <f12+0x10c9>
    88da:	8b 4e 18             	mov    0x18(%rsi),%ecx
    88dd:	0f b7 c0             	movzwl %ax,%eax
    88e0:	48 0f af c1          	imul   %rcx,%rax
    88e4:	8b 4e 1c             	mov    0x1c(%rsi),%ecx
    88e7:	48 c1 e8 20          	shr    $0x20,%rax
    88eb:	48 39 c8             	cmp    %rcx,%rax
    88ee:	0f 83 55 05 00 00    	jae    8e49 <f12+0x10c9>
    88f4:	48 01 c7             	add    %rax,%rdi
    88f7:	80 3f 01             	cmpb   $0x1,(%rdi)
    88fa:	0f 85 49 05 00 00    	jne    8e49 <f12+0x10c9>
    8900:	4c 39 fa             	cmp    %r15,%rdx
    8903:	4c 0f 46 fa          	cmovbe %rdx,%r15
    8907:	4c 89 fd             	mov    %r15,%rbp
    890a:	4d 85 ff             	test   %r15,%r15
    890d:	0f 84 30 0a 00 00    	je     9343 <f12+0x15c3>
    8913:	c7 44 24 40 01 00 00 	movl   $0x1,0x40(%rsp)
    891a:	00 
    891b:	4d 8d 65 08          	lea    0x8(%r13),%r12
    891f:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
    8924:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    8929:	4c 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%r8
    8930:	00 
    8931:	31 c0                	xor    %eax,%eax
    8933:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    8937:	eb 24                	jmp    895d <f12+0xbdd>
    8939:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8940:	f2 0f 10 42 08       	movsd  0x8(%rdx),%xmm0
    8945:	f2 0f 5c 04 06       	subsd  (%rsi,%rax,1),%xmm0
    894a:	f2 41 0f 11 04 04    	movsd  %xmm0,(%r12,%rax,1)
    8950:	48 83 c0 08          	add    $0x8,%rax
    8954:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8958:	49 39 c0             	cmp    %rax,%r8
    895b:	74 1b                	je     8978 <f12+0xbf8>
    895d:	48 89 fe             	mov    %rdi,%rsi
    8960:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    8965:	79 d9                	jns    8940 <f12+0xbc0>
    8967:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
    896c:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8970:	eb ce                	jmp    8940 <f12+0xbc0>
    8972:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8978:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    897d:	48 85 d2             	test   %rdx,%rdx
    8980:	0f 84 87 09 00 00    	je     930d <f12+0x158d>
    8986:	4c 8b 05 4b a2 01 00 	mov    0x1a24b(%rip),%r8        # 22bd8 <fwp_heap+0x13d8>
    898d:	4c 8b 15 1c a2 01 00 	mov    0x1a21c(%rip),%r10        # 22bb0 <fwp_heap+0x13b0>
    8994:	45 31 ff             	xor    %r15d,%r15d
    8997:	4c 8b 1d 5a a2 01 00 	mov    0x1a25a(%rip),%r11        # 22bf8 <fwp_heap+0x13f8>
    899e:	49 c1 e0 10          	shl    $0x10,%r8
    89a2:	eb 1a                	jmp    89be <f12+0xc3e>
    89a4:	0f 1f 40 00          	nopl   0x0(%rax)
    89a8:	49 83 c7 01          	add    $0x1,%r15
    89ac:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    89b0:	49 39 ef             	cmp    %rbp,%r15
    89b3:	0f 83 37 02 00 00    	jae    8bf0 <f12+0xe70>
    89b9:	48 85 d2             	test   %rdx,%rdx
    89bc:	74 52                	je     8a10 <f12+0xc90>
    89be:	48 89 d0             	mov    %rdx,%rax
    89c1:	4c 29 d0             	sub    %r10,%rax
    89c4:	4c 39 c0             	cmp    %r8,%rax
    89c7:	73 47                	jae    8a10 <f12+0xc90>
    89c9:	48 89 c6             	mov    %rax,%rsi
    89cc:	48 c1 ee 10          	shr    $0x10,%rsi
    89d0:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    89d4:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    89d8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    89dc:	48 85 ff             	test   %rdi,%rdi
    89df:	74 2f                	je     8a10 <f12+0xc90>
    89e1:	0f b6 1e             	movzbl (%rsi),%ebx
    89e4:	80 fb 02             	cmp    $0x2,%bl
    89e7:	0f 84 e3 01 00 00    	je     8bd0 <f12+0xe50>
    89ed:	80 fb 01             	cmp    $0x1,%bl
    89f0:	75 1e                	jne    8a10 <f12+0xc90>
    89f2:	8b 5e 18             	mov    0x18(%rsi),%ebx
    89f5:	0f b7 c0             	movzwl %ax,%eax
    89f8:	8b 76 1c             	mov    0x1c(%rsi),%esi
    89fb:	48 0f af c3          	imul   %rbx,%rax
    89ff:	48 c1 e8 20          	shr    $0x20,%rax
    8a03:	48 39 f0             	cmp    %rsi,%rax
    8a06:	73 08                	jae    8a10 <f12+0xc90>
    8a08:	48 01 c7             	add    %rax,%rdi
    8a0b:	80 3f 01             	cmpb   $0x1,(%rdi)
    8a0e:	74 98                	je     89a8 <f12+0xc28>
    8a10:	49 39 ef             	cmp    %rbp,%r15
    8a13:	0f 83 d7 01 00 00    	jae    8bf0 <f12+0xe70>
    8a19:	4c 8b 2d c0 51 00 00 	mov    0x51c0(%rip),%r13        # dbe0 <msg.8+0x70>
    8a20:	45 31 f6             	xor    %r14d,%r14d
    8a23:	48 8d 1d d6 8d 01 00 	lea    0x18dd6(%rip),%rbx        # 21800 <fwp_heap>
    8a2a:	e9 19 01 00 00       	jmp    8b48 <f12+0xdc8>
    8a2f:	90                   	nop
    8a30:	49 8b 10             	mov    (%r8),%rdx
    8a33:	48 f7 d2             	not    %rdx
    8a36:	48 89 10             	mov    %rdx,(%rax)
    8a39:	49 83 fb 18          	cmp    $0x18,%r11
    8a3d:	76 3b                	jbe    8a7a <f12+0xcfa>
    8a3f:	49 8d 43 e7          	lea    -0x19(%r11),%rax
    8a43:	49 8d 78 18          	lea    0x18(%r8),%rdi
    8a47:	31 f6                	xor    %esi,%esi
    8a49:	4c 89 5c 24 20       	mov    %r11,0x20(%rsp)
    8a4e:	48 c1 e8 03          	shr    $0x3,%rax
    8a52:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    8a57:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    8a5e:	00 
    8a5f:	66 0f d6 44 24 30    	movq   %xmm0,0x30(%rsp)
    8a65:	e8 56 aa ff ff       	call   34c0 <memset@plt>
    8a6a:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    8a6f:	4c 8b 5c 24 20       	mov    0x20(%rsp),%r11
    8a74:	f3 0f 7e 44 24 30    	movq   0x30(%rsp),%xmm0
    8a7a:	4c 89 d8             	mov    %r11,%rax
    8a7d:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    8a84:	0f 82 a3 08 00 00    	jb     932d <f12+0x15ad>
    8a8a:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    8a91:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    8a98:	73 07                	jae    8aa1 <f12+0xd21>
    8a9a:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    8aa1:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8aa5:	f2 49 0f 2a cb       	cvtsi2sd %r11,%xmm1
    8aaa:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    8ab1:	00 
    8ab2:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    8ab9:	00 
    8aba:	66 49 0f 6e ee       	movq   %r14,%xmm5
    8abf:	4d 89 28             	mov    %r13,(%r8)
    8ac2:	4c 89 c0             	mov    %r8,%rax
    8ac5:	4d 89 c6             	mov    %r8,%r14
    8ac8:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    8acc:	41 0f 11 40 08       	movups %xmm0,0x8(%r8)
    8ad1:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    8ad8:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    8adf:	48 c1 e2 10          	shl    $0x10,%rdx
    8ae3:	48 39 d0             	cmp    %rdx,%rax
    8ae6:	73 57                	jae    8b3f <f12+0xdbf>
    8ae8:	48 89 c2             	mov    %rax,%rdx
    8aeb:	48 c1 ea 10          	shr    $0x10,%rdx
    8aef:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8af3:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    8afa:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    8afe:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    8b02:	48 85 d2             	test   %rdx,%rdx
    8b05:	74 38                	je     8b3f <f12+0xdbf>
    8b07:	0f b6 3e             	movzbl (%rsi),%edi
    8b0a:	40 80 ff 02          	cmp    $0x2,%dil
    8b0e:	0f 84 7c 01 00 00    	je     8c90 <f12+0xf10>
    8b14:	40 80 ff 01          	cmp    $0x1,%dil
    8b18:	75 25                	jne    8b3f <f12+0xdbf>
    8b1a:	8b 7e 18             	mov    0x18(%rsi),%edi
    8b1d:	0f b7 c0             	movzwl %ax,%eax
    8b20:	8b 76 1c             	mov    0x1c(%rsi),%esi
    8b23:	48 0f af c7          	imul   %rdi,%rax
    8b27:	48 c1 e8 20          	shr    $0x20,%rax
    8b2b:	48 39 f0             	cmp    %rsi,%rax
    8b2e:	73 0f                	jae    8b3f <f12+0xdbf>
    8b30:	48 01 c2             	add    %rax,%rdx
    8b33:	80 3a ff             	cmpb   $0xff,(%rdx)
    8b36:	0f 84 74 04 00 00    	je     8fb0 <f12+0x1230>
    8b3c:	c6 02 01             	movb   $0x1,(%rdx)
    8b3f:	49 39 ef             	cmp    %rbp,%r15
    8b42:	0f 83 68 01 00 00    	jae    8cb0 <f12+0xf30>
    8b48:	8b b3 a4 13 00 00    	mov    0x13a4(%rbx),%esi
    8b4e:	48 83 ed 01          	sub    $0x1,%rbp
    8b52:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    8b58:	85 f6                	test   %esi,%esi
    8b5a:	74 4c                	je     8ba8 <f12+0xe28>
    8b5c:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    8b63:	44 8b 9c 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r11d
    8b6a:	00 
    8b6b:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    8b6f:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    8b73:	4c 8b 00             	mov    (%rax),%r8
    8b76:	4d 85 c0             	test   %r8,%r8
    8b79:	0f 85 b1 fe ff ff    	jne    8a30 <f12+0xcb0>
    8b7f:	4c 8b 40 08          	mov    0x8(%rax),%r8
    8b83:	4d 85 c0             	test   %r8,%r8
    8b86:	74 20                	je     8ba8 <f12+0xe28>
    8b88:	48 8b 50 10          	mov    0x10(%rax),%rdx
    8b8c:	4c 29 c2             	sub    %r8,%rdx
    8b8f:	4c 39 da             	cmp    %r11,%rdx
    8b92:	72 14                	jb     8ba8 <f12+0xe28>
    8b94:	4b 8d 14 18          	lea    (%r8,%r11,1),%rdx
    8b98:	48 89 50 08          	mov    %rdx,0x8(%rax)
    8b9c:	e9 98 fe ff ff       	jmp    8a39 <f12+0xcb9>
    8ba1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ba8:	31 f6                	xor    %esi,%esi
    8baa:	bf 18 00 00 00       	mov    $0x18,%edi
    8baf:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    8bb5:	e8 36 d1 ff ff       	call   5cf0 <fwp_heap_alloc>
    8bba:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    8bc0:	49 89 c0             	mov    %rax,%r8
    8bc3:	e9 f2 fe ff ff       	jmp    8aba <f12+0xd3a>
    8bc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8bcf:	00 
    8bd0:	66 85 c0             	test   %ax,%ax
    8bd3:	0f 84 32 fe ff ff    	je     8a0b <f12+0xc8b>
    8bd9:	49 39 ef             	cmp    %rbp,%r15
    8bdc:	0f 82 37 fe ff ff    	jb     8a19 <f12+0xc99>
    8be2:	0f 1f 00             	nopl   (%rax)
    8be5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8bec:	00 00 00 00 
    8bf0:	45 31 f6             	xor    %r14d,%r14d
    8bf3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8bf8:	4c 89 e2             	mov    %r12,%rdx
    8bfb:	4b 8d 3c fc          	lea    (%r12,%r15,8),%rdi
    8bff:	90                   	nop
    8c00:	48 8b 0a             	mov    (%rdx),%rcx
    8c03:	48 83 c2 08          	add    $0x8,%rdx
    8c07:	48 89 c6             	mov    %rax,%rsi
    8c0a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    8c0e:	48 8b 40 10          	mov    0x10(%rax),%rax
    8c12:	48 39 d7             	cmp    %rdx,%rdi
    8c15:	75 e9                	jne    8c00 <f12+0xe80>
    8c17:	8b 4c 24 40          	mov    0x40(%rsp),%ecx
    8c1b:	4c 89 76 10          	mov    %r14,0x10(%rsi)
    8c1f:	85 c9                	test   %ecx,%ecx
    8c21:	0f 84 69 04 00 00    	je     9090 <f12+0x1310>
    8c27:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8c2c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8c31:	45 31 e4             	xor    %r12d,%r12d
    8c34:	90                   	nop
    8c35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8c3c:	00 00 00 00 
    8c40:	4c 89 e7             	mov    %r12,%rdi
    8c43:	e8 a8 cb ff ff       	call   57f0 <fwp_mem_free>
    8c48:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    8c4d:	e8 1e ec ff ff       	call   7870 <fwp_drop4>
    8c52:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8c57:	e8 54 dc ff ff       	call   68b0 <fwp_drop0>
    8c5c:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
    8c63:	00 
    8c64:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8c6b:	00 00 
    8c6d:	0f 85 20 07 00 00    	jne    9393 <f12+0x1613>
    8c73:	48 81 c4 e8 00 00 00 	add    $0xe8,%rsp
    8c7a:	4c 89 f0             	mov    %r14,%rax
    8c7d:	5b                   	pop    %rbx
    8c7e:	5d                   	pop    %rbp
    8c7f:	41 5c                	pop    %r12
    8c81:	41 5d                	pop    %r13
    8c83:	41 5e                	pop    %r14
    8c85:	41 5f                	pop    %r15
    8c87:	c3                   	ret
    8c88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8c8f:	00 
    8c90:	66 85 c0             	test   %ax,%ax
    8c93:	0f 84 9a fe ff ff    	je     8b33 <f12+0xdb3>
    8c99:	49 39 ef             	cmp    %rbp,%r15
    8c9c:	0f 82 a6 fe ff ff    	jb     8b48 <f12+0xdc8>
    8ca2:	0f 1f 00             	nopl   (%rax)
    8ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8cac:	00 00 00 00 
    8cb0:	4d 85 ff             	test   %r15,%r15
    8cb3:	0f 85 3a ff ff ff    	jne    8bf3 <f12+0xe73>
    8cb9:	8b 54 24 40          	mov    0x40(%rsp),%edx
    8cbd:	85 d2                	test   %edx,%edx
    8cbf:	4d 0f 45 e7          	cmovne %r15,%r12
    8cc3:	66 90                	xchg   %ax,%ax
    8cc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8ccc:	00 00 00 00 
    8cd0:	48 85 ed             	test   %rbp,%rbp
    8cd3:	0f 84 67 ff ff ff    	je     8c40 <f12+0xec0>
    8cd9:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    8cdf:	48 83 ed 01          	sub    $0x1,%rbp
    8ce3:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    8ce9:	85 c0                	test   %eax,%eax
    8ceb:	0f 84 c7 05 00 00    	je     92b8 <f12+0x1538>
    8cf1:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    8cf8:	44 8b 84 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r8d
    8cff:	00 
    8d00:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    8d04:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    8d08:	4c 8b 38             	mov    (%rax),%r15
    8d0b:	4d 85 ff             	test   %r15,%r15
    8d0e:	0f 84 7c 05 00 00    	je     9290 <f12+0x1510>
    8d14:	49 8b 17             	mov    (%r15),%rdx
    8d17:	48 f7 d2             	not    %rdx
    8d1a:	48 89 10             	mov    %rdx,(%rax)
    8d1d:	49 83 f8 18          	cmp    $0x18,%r8
    8d21:	76 31                	jbe    8d54 <f12+0xfd4>
    8d23:	49 8d 40 e7          	lea    -0x19(%r8),%rax
    8d27:	49 8d 7f 18          	lea    0x18(%r15),%rdi
    8d2b:	31 f6                	xor    %esi,%esi
    8d2d:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    8d32:	48 c1 e8 03          	shr    $0x3,%rax
    8d36:	66 0f d6 44 24 20    	movq   %xmm0,0x20(%rsp)
    8d3c:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    8d43:	00 
    8d44:	e8 77 a7 ff ff       	call   34c0 <memset@plt>
    8d49:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    8d4e:	f3 0f 7e 44 24 20    	movq   0x20(%rsp),%xmm0
    8d54:	4c 89 c0             	mov    %r8,%rax
    8d57:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    8d5e:	0f 82 c9 05 00 00    	jb     932d <f12+0x15ad>
    8d64:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    8d6b:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    8d72:	73 07                	jae    8d7b <f12+0xffb>
    8d74:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    8d7b:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8d7f:	f2 49 0f 2a c8       	cvtsi2sd %r8,%xmm1
    8d84:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    8d8b:	00 
    8d8c:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    8d93:	00 
    8d94:	66 49 0f 6e f6       	movq   %r14,%xmm6
    8d99:	4d 89 2f             	mov    %r13,(%r15)
    8d9c:	4c 89 f8             	mov    %r15,%rax
    8d9f:	4d 89 fe             	mov    %r15,%r14
    8da2:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    8da6:	41 0f 11 47 08       	movups %xmm0,0x8(%r15)
    8dab:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    8db2:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    8db9:	48 c1 e2 10          	shl    $0x10,%rdx
    8dbd:	48 39 d0             	cmp    %rdx,%rax
    8dc0:	0f 83 0a ff ff ff    	jae    8cd0 <f12+0xf50>
    8dc6:	48 89 c2             	mov    %rax,%rdx
    8dc9:	48 c1 ea 10          	shr    $0x10,%rdx
    8dcd:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8dd1:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    8dd8:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    8ddc:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    8de0:	4d 85 ff             	test   %r15,%r15
    8de3:	0f 84 e7 fe ff ff    	je     8cd0 <f12+0xf50>
    8de9:	0f b6 32             	movzbl (%rdx),%esi
    8dec:	40 80 fe 02          	cmp    $0x2,%sil
    8df0:	0f 84 ea 04 00 00    	je     92e0 <f12+0x1560>
    8df6:	40 80 fe 01          	cmp    $0x1,%sil
    8dfa:	0f 85 d0 fe ff ff    	jne    8cd0 <f12+0xf50>
    8e00:	8b 72 18             	mov    0x18(%rdx),%esi
    8e03:	0f b7 c0             	movzwl %ax,%eax
    8e06:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8e09:	48 0f af c6          	imul   %rsi,%rax
    8e0d:	48 c1 e8 20          	shr    $0x20,%rax
    8e11:	48 39 d0             	cmp    %rdx,%rax
    8e14:	0f 83 b6 fe ff ff    	jae    8cd0 <f12+0xf50>
    8e1a:	49 01 c7             	add    %rax,%r15
    8e1d:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8e21:	0f 84 d9 04 00 00    	je     9300 <f12+0x1580>
    8e27:	41 c6 07 01          	movb   $0x1,(%r15)
    8e2b:	48 85 ed             	test   %rbp,%rbp
    8e2e:	0f 85 a5 fe ff ff    	jne    8cd9 <f12+0xf59>
    8e34:	e9 07 fe ff ff       	jmp    8c40 <f12+0xec0>
    8e39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8e40:	66 85 c0             	test   %ax,%ax
    8e43:	0f 84 ae fa ff ff    	je     88f7 <f12+0xb77>
    8e49:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    8e4f:	0f 84 1b 03 00 00    	je     9170 <f12+0x13f0>
    8e55:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8e5a:	31 ed                	xor    %ebp,%ebp
    8e5c:	0f 1f 40 00          	nopl   0x0(%rax)
    8e60:	48 8b 40 10          	mov    0x10(%rax),%rax
    8e64:	48 89 ea             	mov    %rbp,%rdx
    8e67:	48 83 c5 01          	add    $0x1,%rbp
    8e6b:	48 85 c0             	test   %rax,%rax
    8e6e:	75 f0                	jne    8e60 <f12+0x10e0>
    8e70:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8e77:	ff ff 1f 
    8e7a:	48 39 e8             	cmp    %rbp,%rax
    8e7d:	0f 82 e0 04 00 00    	jb     9363 <f12+0x15e3>
    8e83:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    8e8a:	00 
    8e8b:	be 02 00 00 00       	mov    $0x2,%esi
    8e90:	e8 5b ce ff ff       	call   5cf0 <fwp_heap_alloc>
    8e95:	49 39 ef             	cmp    %rbp,%r15
    8e98:	49 89 c4             	mov    %rax,%r12
    8e9b:	48 89 c2             	mov    %rax,%rdx
    8e9e:	49 0f 46 ef          	cmovbe %r15,%rbp
    8ea2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8ea7:	0f 1f 00             	nopl   (%rax)
    8eaa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8eb1:	00 00 00 00 
    8eb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8ebc:	00 00 00 00 
    8ec0:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8ec4:	48 83 c2 08          	add    $0x8,%rdx
    8ec8:	48 89 72 f8          	mov    %rsi,-0x8(%rdx)
    8ecc:	48 8b 40 10          	mov    0x10(%rax),%rax
    8ed0:	48 85 c0             	test   %rax,%rax
    8ed3:	75 eb                	jne    8ec0 <f12+0x1140>
    8ed5:	48 85 ed             	test   %rbp,%rbp
    8ed8:	0f 84 a4 02 00 00    	je     9182 <f12+0x1402>
    8ede:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
    8ee5:	00 
    8ee6:	e9 34 fa ff ff       	jmp    891f <f12+0xb9f>
    8eeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8ef0:	66 85 c0             	test   %ax,%ax
    8ef3:	0f 84 df f8 ff ff    	je     87d8 <f12+0xa58>
    8ef9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8f00:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8f07:	ff ff 1f 
    8f0a:	4c 39 e0             	cmp    %r12,%rax
    8f0d:	0f 82 38 04 00 00    	jb     934b <f12+0x15cb>
    8f13:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    8f1a:	00 
    8f1b:	be 01 00 00 00       	mov    $0x1,%esi
    8f20:	e8 cb cd ff ff       	call   5cf0 <fwp_heap_alloc>
    8f25:	4c 89 20             	mov    %r12,(%rax)
    8f28:	48 8b 15 a9 9c 01 00 	mov    0x19ca9(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    8f2f:	49 89 c5             	mov    %rax,%r13
    8f32:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    8f37:	48 2b 05 72 9c 01 00 	sub    0x19c72(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    8f3e:	48 c1 e2 10          	shl    $0x10,%rdx
    8f42:	48 39 d0             	cmp    %rdx,%rax
    8f45:	73 57                	jae    8f9e <f12+0x121e>
    8f47:	48 89 c2             	mov    %rax,%rdx
    8f4a:	48 c1 ea 10          	shr    $0x10,%rdx
    8f4e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8f52:	48 8b 15 9f 9c 01 00 	mov    0x19c9f(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    8f59:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8f5d:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    8f61:	4d 85 ff             	test   %r15,%r15
    8f64:	74 38                	je     8f9e <f12+0x121e>
    8f66:	0f b6 0a             	movzbl (%rdx),%ecx
    8f69:	80 f9 02             	cmp    $0x2,%cl
    8f6c:	0f 84 1e 02 00 00    	je     9190 <f12+0x1410>
    8f72:	80 f9 01             	cmp    $0x1,%cl
    8f75:	75 27                	jne    8f9e <f12+0x121e>
    8f77:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8f7a:	0f b7 c0             	movzwl %ax,%eax
    8f7d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8f80:	48 0f af c1          	imul   %rcx,%rax
    8f84:	48 c1 e8 20          	shr    $0x20,%rax
    8f88:	48 39 d0             	cmp    %rdx,%rax
    8f8b:	73 11                	jae    8f9e <f12+0x121e>
    8f8d:	49 01 c7             	add    %rax,%r15
    8f90:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8f94:	0f 84 b7 02 00 00    	je     9251 <f12+0x14d1>
    8f9a:	41 c6 07 01          	movb   $0x1,(%r15)
    8f9e:	48 89 df             	mov    %rbx,%rdi
    8fa1:	e9 45 f8 ff ff       	jmp    87eb <f12+0xa6b>
    8fa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8fad:	00 00 00 
    8fb0:	48 89 d7             	mov    %rdx,%rdi
    8fb3:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    8fb8:	e8 f3 c5 ff ff       	call   55b0 <fwp_rc_forget_slot>
    8fbd:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8fc2:	e9 75 fb ff ff       	jmp    8b3c <f12+0xdbc>
    8fc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8fce:	00 00 
    8fd0:	48 8d 3d 09 de ff ff 	lea    -0x21f7(%rip),%rdi        # 6de0 <fwp_tape_finish>
    8fd7:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    8fdd:	e8 be 37 00 00       	call   c7a0 <atexit>
    8fe2:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    8fe8:	85 c0                	test   %eax,%eax
    8fea:	75 59                	jne    9045 <f12+0x12c5>
    8fec:	c7 05 8a 80 00 00 01 	movl   $0x1,0x808a(%rip)        # 11080 <registered_finish.0>
    8ff3:	00 00 00 
    8ff6:	e9 bb ee ff ff       	jmp    7eb6 <f12+0x136>
    8ffb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9000:	66 85 c0             	test   %ax,%ax
    9003:	0f 85 56 ee ff ff    	jne    7e5f <f12+0xdf>
    9009:	e9 3d ee ff ff       	jmp    7e4b <f12+0xcb>
    900e:	66 90                	xchg   %ax,%ax
    9010:	48 89 ea             	mov    %rbp,%rdx
    9013:	4c 39 d5             	cmp    %r10,%rbp
    9016:	0f 8f c1 f4 ff ff    	jg     84dd <f12+0x75d>
    901c:	48 85 d2             	test   %rdx,%rdx
    901f:	0f 84 47 f5 ff ff    	je     856c <f12+0x7ec>
    9025:	4d 85 f6             	test   %r14,%r14
    9028:	0f 85 35 f5 ff ff    	jne    8563 <f12+0x7e3>
    902e:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    9035:	00 
    9036:	4c 89 e7             	mov    %r12,%rdi
    9039:	48 89 05 58 a4 01 00 	mov    %rax,0x1a458(%rip)        # 23498 <fwp_cleanups>
    9040:	e8 8b c0 ff ff       	call   50d0 <fwp_tape_buffers_release>
    9045:	48 8b 0d 14 80 00 00 	mov    0x8014(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    904c:	ba 13 00 00 00       	mov    $0x13,%edx
    9051:	be 01 00 00 00       	mov    $0x1,%esi
    9056:	48 8d 3d ab 3f 00 00 	lea    0x3fab(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    905d:	e8 1e a6 ff ff       	call   3680 <fwrite@plt>
    9062:	31 ff                	xor    %edi,%edi
    9064:	e8 57 a5 ff ff       	call   35c0 <fflush@plt>
    9069:	bf 66 00 00 00       	mov    $0x66,%edi
    906e:	e8 2d a6 ff ff       	call   36a0 <_Exit@plt>
    9073:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9078:	66 85 c0             	test   %ax,%ax
    907b:	0f 85 af f6 ff ff    	jne    8730 <f12+0x9b0>
    9081:	e9 9a f6 ff ff       	jmp    8720 <f12+0x9a0>
    9086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    908d:	00 00 00 
    9090:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    9095:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    909a:	e9 a1 fb ff ff       	jmp    8c40 <f12+0xec0>
    909f:	90                   	nop
    90a0:	66 0f 6f 0d 38 80 01 	movdqa 0x18038(%rip),%xmm1        # 210e0 <fwp_tape_workspace>
    90a7:	00 
    90a8:	48 c7 05 15 80 01 00 	movq   $0x0,0x18015(%rip)        # 210c8 <fwp_tape_cached_bytes>
    90af:	00 00 00 00 
    90b3:	41 0f 11 4e 20       	movups %xmm1,0x20(%r14)
    90b8:	48 8b 05 41 80 01 00 	mov    0x18041(%rip),%rax        # 21100 <fwp_tape_workspace+0x20>
    90bf:	66 0f 6f 0d 29 80 01 	movdqa 0x18029(%rip),%xmm1        # 210f0 <fwp_tape_workspace+0x10>
    90c6:	00 
    90c7:	49 89 46 40          	mov    %rax,0x40(%r14)
    90cb:	48 8b 05 36 80 01 00 	mov    0x18036(%rip),%rax        # 21108 <fwp_tape_workspace+0x28>
    90d2:	41 0f 11 4e 30       	movups %xmm1,0x30(%r14)
    90d7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    90db:	49 89 46 18          	mov    %rax,0x18(%r14)
    90df:	48 8b 05 2a 80 01 00 	mov    0x1802a(%rip),%rax        # 21110 <fwp_tape_workspace+0x30>
    90e6:	0f 29 0d f3 7f 01 00 	movaps %xmm1,0x17ff3(%rip)        # 210e0 <fwp_tape_workspace>
    90ed:	49 89 46 48          	mov    %rax,0x48(%r14)
    90f1:	0f 29 0d f8 7f 01 00 	movaps %xmm1,0x17ff8(%rip)        # 210f0 <fwp_tape_workspace+0x10>
    90f8:	48 c7 05 0d 80 01 00 	movq   $0x0,0x1800d(%rip)        # 21110 <fwp_tape_workspace+0x30>
    90ff:	00 00 00 00 
    9103:	0f 29 0d f6 7f 01 00 	movaps %xmm1,0x17ff6(%rip)        # 21100 <fwp_tape_workspace+0x20>
    910a:	e9 d8 ee ff ff       	jmp    7fe7 <f12+0x267>
    910f:	90                   	nop
    9110:	48 89 ea             	mov    %rbp,%rdx
    9113:	e9 c5 f3 ff ff       	jmp    84dd <f12+0x75d>
    9118:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    911f:	00 
    9120:	4d 85 f6             	test   %r14,%r14
    9123:	0f 84 05 ff ff ff    	je     902e <f12+0x12ae>
    9129:	49 89 d2             	mov    %rdx,%r10
    912c:	31 f6                	xor    %esi,%esi
    912e:	48 c1 e2 03          	shl    $0x3,%rdx
    9132:	4c 89 f7             	mov    %r14,%rdi
    9135:	49 29 ea             	sub    %rbp,%r10
    9138:	4c 89 4c 24 48       	mov    %r9,0x48(%rsp)
    913d:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
    9142:	e8 79 a3 ff ff       	call   34c0 <memset@plt>
    9147:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
    914c:	4c 8b 4c 24 48       	mov    0x48(%rsp),%r9
    9151:	e9 2b f4 ff ff       	jmp    8581 <f12+0x801>
    9156:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    915d:	00 00 00 
    9160:	be 68 00 00 00       	mov    $0x68,%esi
    9165:	41 bc 01 00 00 00    	mov    $0x1,%r12d
    916b:	e9 ca ed ff ff       	jmp    7f3a <f12+0x1ba>
    9170:	be 02 00 00 00       	mov    $0x2,%esi
    9175:	bf 08 00 00 00       	mov    $0x8,%edi
    917a:	e8 71 cb ff ff       	call   5cf0 <fwp_heap_alloc>
    917f:	49 89 c4             	mov    %rax,%r12
    9182:	45 31 f6             	xor    %r14d,%r14d
    9185:	e9 b6 fa ff ff       	jmp    8c40 <f12+0xec0>
    918a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9190:	66 85 c0             	test   %ax,%ax
    9193:	0f 85 05 fe ff ff    	jne    8f9e <f12+0x121e>
    9199:	e9 f2 fd ff ff       	jmp    8f90 <f12+0x1210>
    919e:	66 90                	xchg   %ax,%ax
    91a0:	4c 89 d7             	mov    %r10,%rdi
    91a3:	be 08 00 00 00       	mov    $0x8,%esi
    91a8:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
    91ad:	e8 6e a3 ff ff       	call   3520 <calloc@plt>
    91b2:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
    91b7:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
    91bc:	49 89 c6             	mov    %rax,%r14
    91bf:	e9 86 f3 ff ff       	jmp    854a <f12+0x7ca>
    91c4:	31 ff                	xor    %edi,%edi
    91c6:	e8 85 b0 ff ff       	call   4250 <descent_phase_step>
    91cb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    91cf:	e9 d2 ec ff ff       	jmp    7ea6 <f12+0x126>
    91d4:	49 8b 4d 00          	mov    0x0(%r13),%rcx
    91d8:	48 85 c9             	test   %rcx,%rcx
    91db:	78 93                	js     9170 <f12+0x13f0>
    91dd:	48 8b 35 f4 99 01 00 	mov    0x199f4(%rip),%rsi        # 22bd8 <fwp_heap+0x13d8>
    91e4:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    91e9:	48 2b 05 c0 99 01 00 	sub    0x199c0(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    91f0:	48 c1 e6 10          	shl    $0x10,%rsi
    91f4:	48 39 f0             	cmp    %rsi,%rax
    91f7:	0f 83 73 ff ff ff    	jae    9170 <f12+0x13f0>
    91fd:	48 89 c6             	mov    %rax,%rsi
    9200:	48 c1 ee 10          	shr    $0x10,%rsi
    9204:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9208:	48 8b 35 e9 99 01 00 	mov    0x199e9(%rip),%rsi        # 22bf8 <fwp_heap+0x13f8>
    920f:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9213:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9217:	48 85 ff             	test   %rdi,%rdi
    921a:	0f 84 50 ff ff ff    	je     9170 <f12+0x13f0>
    9220:	48 0f ba f1 3f       	btr    $0x3f,%rcx
    9225:	49 89 cf             	mov    %rcx,%r15
    9228:	e9 98 f6 ff ff       	jmp    88c5 <f12+0xb45>
    922d:	48 89 d7             	mov    %rdx,%rdi
    9230:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    9235:	e8 76 c3 ff ff       	call   55b0 <fwp_rc_forget_slot>
    923a:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    923f:	e9 3c ef ff ff       	jmp    8180 <f12+0x400>
    9244:	4c 89 e7             	mov    %r12,%rdi
    9247:	e8 64 c3 ff ff       	call   55b0 <fwp_rc_forget_slot>
    924c:	e9 da f4 ff ff       	jmp    872b <f12+0x9ab>
    9251:	4c 89 ff             	mov    %r15,%rdi
    9254:	e8 57 c3 ff ff       	call   55b0 <fwp_rc_forget_slot>
    9259:	e9 3c fd ff ff       	jmp    8f9a <f12+0x121a>
    925e:	e8 2d c2 ff ff       	call   5490 <fwp_rc_wide_dup>
    9263:	e9 f7 eb ff ff       	jmp    7e5f <f12+0xdf>
    9268:	49 89 d2             	mov    %rdx,%r10
    926b:	48 8d 5a ff          	lea    -0x1(%rdx),%rbx
    926f:	31 f6                	xor    %esi,%esi
    9271:	48 c1 e2 03          	shl    $0x3,%rdx
    9275:	49 29 ea             	sub    %rbp,%r10
    9278:	4c 89 f7             	mov    %r14,%rdi
    927b:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
    9280:	e8 3b a2 ff ff       	call   34c0 <memset@plt>
    9285:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
    928a:	e9 ea f2 ff ff       	jmp    8579 <f12+0x7f9>
    928f:	90                   	nop
    9290:	4c 8b 78 08          	mov    0x8(%rax),%r15
    9294:	4d 85 ff             	test   %r15,%r15
    9297:	74 1f                	je     92b8 <f12+0x1538>
    9299:	48 8b 50 10          	mov    0x10(%rax),%rdx
    929d:	4c 29 fa             	sub    %r15,%rdx
    92a0:	4c 39 c2             	cmp    %r8,%rdx
    92a3:	72 13                	jb     92b8 <f12+0x1538>
    92a5:	4b 8d 14 07          	lea    (%r15,%r8,1),%rdx
    92a9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    92ad:	e9 6b fa ff ff       	jmp    8d1d <f12+0xf9d>
    92b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    92b8:	31 f6                	xor    %esi,%esi
    92ba:	bf 18 00 00 00       	mov    $0x18,%edi
    92bf:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    92c5:	e8 26 ca ff ff       	call   5cf0 <fwp_heap_alloc>
    92ca:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    92d0:	49 89 c7             	mov    %rax,%r15
    92d3:	e9 bc fa ff ff       	jmp    8d94 <f12+0x1014>
    92d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    92df:	00 
    92e0:	66 85 c0             	test   %ax,%ax
    92e3:	0f 85 e7 f9 ff ff    	jne    8cd0 <f12+0xf50>
    92e9:	41 80 3f ff          	cmpb   $0xff,(%r15)
    92ed:	0f 85 34 fb ff ff    	jne    8e27 <f12+0x10a7>
    92f3:	66 90                	xchg   %ax,%ax
    92f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    92fc:	00 00 00 00 
    9300:	4c 89 ff             	mov    %r15,%rdi
    9303:	e8 a8 c2 ff ff       	call   55b0 <fwp_rc_forget_slot>
    9308:	e9 1a fb ff ff       	jmp    8e27 <f12+0x10a7>
    930d:	45 31 ff             	xor    %r15d,%r15d
    9310:	e9 04 f7 ff ff       	jmp    8a19 <f12+0xc99>
    9315:	48 8d 3d 94 45 00 00 	lea    0x4594(%rip),%rdi        # d8b0 <_IO_stdin_used+0x8b0>
    931c:	e8 cf b0 ff ff       	call   43f0 <fwp_trap>
    9321:	48 8d 3d 3f 3e 00 00 	lea    0x3e3f(%rip),%rdi        # d167 <_IO_stdin_used+0x167>
    9328:	e8 c3 b0 ff ff       	call   43f0 <fwp_trap>
    932d:	e8 7e a9 ff ff       	call   3cb0 <fwp_heap_oom>
    9332:	48 8d 3d 7f 46 00 00 	lea    0x467f(%rip),%rdi        # d9b8 <_IO_stdin_used+0x9b8>
    9339:	e8 b2 b0 ff ff       	call   43f0 <fwp_trap>
    933e:	e8 bd a3 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9343:	45 31 e4             	xor    %r12d,%r12d
    9346:	e9 37 fe ff ff       	jmp    9182 <f12+0x1402>
    934b:	48 8d 3d 66 3e 00 00 	lea    0x3e66(%rip),%rdi        # d1b8 <_IO_stdin_used+0x1b8>
    9352:	e8 99 b0 ff ff       	call   43f0 <fwp_trap>
    9357:	48 8d 3d 32 3e 00 00 	lea    0x3e32(%rip),%rdi        # d190 <_IO_stdin_used+0x190>
    935e:	e8 8d b0 ff ff       	call   43f0 <fwp_trap>
    9363:	48 8d 3d 40 3e 00 00 	lea    0x3e40(%rip),%rdi        # d1aa <_IO_stdin_used+0x1aa>
    936a:	e8 81 b0 ff ff       	call   43f0 <fwp_trap>
    936f:	48 8d 3d 82 45 00 00 	lea    0x4582(%rip),%rdi        # d8f8 <_IO_stdin_used+0x8f8>
    9376:	e8 75 b0 ff ff       	call   43f0 <fwp_trap>
    937b:	48 8d 3d 06 46 00 00 	lea    0x4606(%rip),%rdi        # d988 <_IO_stdin_used+0x988>
    9382:	e8 69 b0 ff ff       	call   43f0 <fwp_trap>
    9387:	48 8d 3d ca 45 00 00 	lea    0x45ca(%rip),%rdi        # d958 <_IO_stdin_used+0x958>
    938e:	e8 5d b0 ff ff       	call   43f0 <fwp_trap>
    9393:	e8 c8 a0 ff ff       	call   3460 <__stack_chk_fail@plt>
    9398:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    939f:	00 

00000000000093a0 <fwp_owned_entry12>:
    93a0:	f3 0f 1e fa          	endbr64
    93a4:	48 8b 3f             	mov    (%rdi),%rdi
    93a7:	e9 d4 e9 ff ff       	jmp    7d80 <f12>
    93ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000093b0 <e12>:
    93b0:	f3 0f 1e fa          	endbr64
    93b4:	53                   	push   %rbx
    93b5:	48 8b 1f             	mov    (%rdi),%rbx
    93b8:	48 89 df             	mov    %rbx,%rdi
    93bb:	e8 60 d3 ff ff       	call   6720 <fwp_rc_share>
    93c0:	48 89 df             	mov    %rbx,%rdi
    93c3:	e8 b8 e9 ff ff       	call   7d80 <f12>
    93c8:	48 89 c3             	mov    %rax,%rbx
    93cb:	48 89 c7             	mov    %rax,%rdi
    93ce:	e8 4d d3 ff ff       	call   6720 <fwp_rc_share>
    93d3:	48 89 d8             	mov    %rbx,%rax
    93d6:	5b                   	pop    %rbx
    93d7:	c3                   	ret
    93d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    93df:	00 

00000000000093e0 <fwp_drop2>:
    93e0:	48 8b 0d f1 97 01 00 	mov    0x197f1(%rip),%rcx        # 22bd8 <fwp_heap+0x13d8>
    93e7:	48 89 f8             	mov    %rdi,%rax
    93ea:	48 2b 05 bf 97 01 00 	sub    0x197bf(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    93f1:	48 c1 e1 10          	shl    $0x10,%rcx
    93f5:	48 39 c8             	cmp    %rcx,%rax
    93f8:	0f 83 42 01 00 00    	jae    9540 <fwp_drop2+0x160>
    93fe:	48 83 ec 18          	sub    $0x18,%rsp
    9402:	48 89 fa             	mov    %rdi,%rdx
    9405:	4c 8d 05 f4 83 01 00 	lea    0x183f4(%rip),%r8        # 21800 <fwp_heap>
    940c:	48 89 c1             	mov    %rax,%rcx
    940f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    9416:	48 c1 e9 10          	shr    $0x10,%rcx
    941a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    941e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    9422:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9426:	48 85 c9             	test   %rcx,%rcx
    9429:	74 40                	je     946b <fwp_drop2+0x8b>
    942b:	0f b6 3e             	movzbl (%rsi),%edi
    942e:	40 80 ff 02          	cmp    $0x2,%dil
    9432:	74 3c                	je     9470 <fwp_drop2+0x90>
    9434:	40 80 ff 01          	cmp    $0x1,%dil
    9438:	75 31                	jne    946b <fwp_drop2+0x8b>
    943a:	8b 7e 18             	mov    0x18(%rsi),%edi
    943d:	0f b7 c0             	movzwl %ax,%eax
    9440:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9443:	48 0f af c7          	imul   %rdi,%rax
    9447:	48 c1 e8 20          	shr    $0x20,%rax
    944b:	48 39 f0             	cmp    %rsi,%rax
    944e:	73 1b                	jae    946b <fwp_drop2+0x8b>
    9450:	48 01 c1             	add    %rax,%rcx
    9453:	0f b6 01             	movzbl (%rcx),%eax
    9456:	84 c0                	test   %al,%al
    9458:	74 11                	je     946b <fwp_drop2+0x8b>
    945a:	3c 01                	cmp    $0x1,%al
    945c:	74 22                	je     9480 <fwp_drop2+0xa0>
    945e:	3c ff                	cmp    $0xff,%al
    9460:	0f 84 0a 01 00 00    	je     9570 <fwp_drop2+0x190>
    9466:	83 e8 01             	sub    $0x1,%eax
    9469:	88 01                	mov    %al,(%rcx)
    946b:	48 83 c4 18          	add    $0x18,%rsp
    946f:	c3                   	ret
    9470:	66 85 c0             	test   %ax,%ax
    9473:	74 de                	je     9453 <fwp_drop2+0x73>
    9475:	48 83 c4 18          	add    $0x18,%rsp
    9479:	c3                   	ret
    947a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9480:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    9484:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    948b:	48 89 f8             	mov    %rdi,%rax
    948e:	48 c1 e1 10          	shl    $0x10,%rcx
    9492:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    9499:	48 39 c8             	cmp    %rcx,%rax
    949c:	73 62                	jae    9500 <fwp_drop2+0x120>
    949e:	48 89 c1             	mov    %rax,%rcx
    94a1:	48 c1 e9 10          	shr    $0x10,%rcx
    94a5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    94a9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    94ad:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    94b1:	48 85 c9             	test   %rcx,%rcx
    94b4:	74 4a                	je     9500 <fwp_drop2+0x120>
    94b6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    94ba:	41 80 f9 02          	cmp    $0x2,%r9b
    94be:	0f 84 9c 00 00 00    	je     9560 <fwp_drop2+0x180>
    94c4:	41 80 f9 01          	cmp    $0x1,%r9b
    94c8:	75 36                	jne    9500 <fwp_drop2+0x120>
    94ca:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    94ce:	0f b7 c0             	movzwl %ax,%eax
    94d1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    94d4:	49 0f af c1          	imul   %r9,%rax
    94d8:	48 c1 e8 20          	shr    $0x20,%rax
    94dc:	48 39 f0             	cmp    %rsi,%rax
    94df:	73 1f                	jae    9500 <fwp_drop2+0x120>
    94e1:	48 01 c1             	add    %rax,%rcx
    94e4:	0f b6 01             	movzbl (%rcx),%eax
    94e7:	84 c0                	test   %al,%al
    94e9:	74 15                	je     9500 <fwp_drop2+0x120>
    94eb:	3c 01                	cmp    $0x1,%al
    94ed:	74 59                	je     9548 <fwp_drop2+0x168>
    94ef:	3c ff                	cmp    $0xff,%al
    94f1:	0f 84 ef 00 00 00    	je     95e6 <fwp_drop2+0x206>
    94f7:	83 e8 01             	sub    $0x1,%eax
    94fa:	88 01                	mov    %al,(%rcx)
    94fc:	0f 1f 40 00          	nopl   0x0(%rax)
    9500:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    9504:	48 89 d7             	mov    %rdx,%rdi
    9507:	48 89 0c 24          	mov    %rcx,(%rsp)
    950b:	e8 90 d2 ff ff       	call   67a0 <fwp_rc_free_arr>
    9510:	4c 8d 05 e9 82 01 00 	lea    0x182e9(%rip),%r8        # 21800 <fwp_heap>
    9517:	48 8b 04 24          	mov    (%rsp),%rax
    951b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    9522:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    9529:	48 c1 e2 10          	shl    $0x10,%rdx
    952d:	48 39 d0             	cmp    %rdx,%rax
    9530:	0f 83 35 ff ff ff    	jae    946b <fwp_drop2+0x8b>
    9536:	48 8b 14 24          	mov    (%rsp),%rdx
    953a:	e9 cd fe ff ff       	jmp    940c <fwp_drop2+0x2c>
    953f:	90                   	nop
    9540:	c3                   	ret
    9541:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9548:	48 89 14 24          	mov    %rdx,(%rsp)
    954c:	e8 4f d2 ff ff       	call   67a0 <fwp_rc_free_arr>
    9551:	48 8b 14 24          	mov    (%rsp),%rdx
    9555:	eb a9                	jmp    9500 <fwp_drop2+0x120>
    9557:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    955e:	00 00 
    9560:	66 85 c0             	test   %ax,%ax
    9563:	75 9b                	jne    9500 <fwp_drop2+0x120>
    9565:	e9 7a ff ff ff       	jmp    94e4 <fwp_drop2+0x104>
    956a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9570:	48 89 c8             	mov    %rcx,%rax
    9573:	48 c1 e8 11          	shr    $0x11,%rax
    9577:	48 31 c8             	xor    %rcx,%rax
    957a:	48 89 c2             	mov    %rax,%rdx
    957d:	48 c1 ea 09          	shr    $0x9,%rdx
    9581:	48 31 d0             	xor    %rdx,%rax
    9584:	0f b6 d0             	movzbl %al,%edx
    9587:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    958e:	00 
    958f:	48 85 c0             	test   %rax,%rax
    9592:	75 19                	jne    95ad <fwp_drop2+0x1cd>
    9594:	e9 d3 00 00 00       	jmp    966c <fwp_drop2+0x28c>
    9599:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    95a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    95a4:	48 85 c0             	test   %rax,%rax
    95a7:	0f 84 bf 00 00 00    	je     966c <fwp_drop2+0x28c>
    95ad:	48 89 c2             	mov    %rax,%rdx
    95b0:	48 39 08             	cmp    %rcx,(%rax)
    95b3:	75 eb                	jne    95a0 <fwp_drop2+0x1c0>
    95b5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    95b9:	48 83 ea 01          	sub    $0x1,%rdx
    95bd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    95c1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    95c8:	0f 85 9d fe ff ff    	jne    946b <fwp_drop2+0x8b>
    95ce:	48 89 cf             	mov    %rcx,%rdi
    95d1:	48 89 0c 24          	mov    %rcx,(%rsp)
    95d5:	e8 d6 bf ff ff       	call   55b0 <fwp_rc_forget_slot>
    95da:	48 8b 0c 24          	mov    (%rsp),%rcx
    95de:	c6 01 fe             	movb   $0xfe,(%rcx)
    95e1:	e9 85 fe ff ff       	jmp    946b <fwp_drop2+0x8b>
    95e6:	48 89 ce             	mov    %rcx,%rsi
    95e9:	48 c1 ee 11          	shr    $0x11,%rsi
    95ed:	48 31 ce             	xor    %rcx,%rsi
    95f0:	48 89 f0             	mov    %rsi,%rax
    95f3:	48 c1 e8 09          	shr    $0x9,%rax
    95f7:	48 31 c6             	xor    %rax,%rsi
    95fa:	40 0f b6 f6          	movzbl %sil,%esi
    95fe:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    9605:	00 
    9606:	48 85 c0             	test   %rax,%rax
    9609:	75 1e                	jne    9629 <fwp_drop2+0x249>
    960b:	eb 5f                	jmp    966c <fwp_drop2+0x28c>
    960d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9614:	00 
    9615:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    961c:	00 00 00 00 
    9620:	48 8b 46 10          	mov    0x10(%rsi),%rax
    9624:	48 85 c0             	test   %rax,%rax
    9627:	74 43                	je     966c <fwp_drop2+0x28c>
    9629:	48 89 c6             	mov    %rax,%rsi
    962c:	48 39 08             	cmp    %rcx,(%rax)
    962f:	75 ef                	jne    9620 <fwp_drop2+0x240>
    9631:	48 8b 70 08          	mov    0x8(%rax),%rsi
    9635:	48 83 ee 01          	sub    $0x1,%rsi
    9639:	48 89 70 08          	mov    %rsi,0x8(%rax)
    963d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    9644:	0f 85 b6 fe ff ff    	jne    9500 <fwp_drop2+0x120>
    964a:	48 89 cf             	mov    %rcx,%rdi
    964d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    9652:	48 89 0c 24          	mov    %rcx,(%rsp)
    9656:	e8 55 bf ff ff       	call   55b0 <fwp_rc_forget_slot>
    965b:	48 8b 0c 24          	mov    (%rsp),%rcx
    965f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9664:	c6 01 fe             	movb   $0xfe,(%rcx)
    9667:	e9 94 fe ff ff       	jmp    9500 <fwp_drop2+0x120>
    966c:	48 8d 3d 15 42 00 00 	lea    0x4215(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    9673:	e8 78 ad ff ff       	call   43f0 <fwp_trap>
    9678:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    967f:	00 

0000000000009680 <fwp_arg_drop23>:
    9680:	f3 0f 1e fa          	endbr64
    9684:	85 f6                	test   %esi,%esi
    9686:	75 04                	jne    968c <fwp_arg_drop23+0xc>
    9688:	85 d2                	test   %edx,%edx
    968a:	75 04                	jne    9690 <fwp_arg_drop23+0x10>
    968c:	c3                   	ret
    968d:	0f 1f 00             	nopl   (%rax)
    9690:	48 8b 3f             	mov    (%rdi),%rdi
    9693:	e9 48 fd ff ff       	jmp    93e0 <fwp_drop2>
    9698:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    969f:	00 

00000000000096a0 <fwp_caps23>:
    96a0:	f3 0f 1e fa          	endbr64
    96a4:	48 83 ec 18          	sub    $0x18,%rsp
    96a8:	8b 57 04             	mov    0x4(%rdi),%edx
    96ab:	48 89 f8             	mov    %rdi,%rax
    96ae:	85 d2                	test   %edx,%edx
    96b0:	0f 84 9a 00 00 00    	je     9750 <fwp_caps23+0xb0>
    96b6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    96ba:	85 f6                	test   %esi,%esi
    96bc:	0f 85 9e 00 00 00    	jne    9760 <fwp_caps23+0xc0>
    96c2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    96c7:	e8 14 fd ff ff       	call   93e0 <fwp_drop2>
    96cc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    96d1:	48 8b 0d 00 95 01 00 	mov    0x19500(%rip),%rcx        # 22bd8 <fwp_heap+0x13d8>
    96d8:	48 89 c2             	mov    %rax,%rdx
    96db:	48 2b 15 ce 94 01 00 	sub    0x194ce(%rip),%rdx        # 22bb0 <fwp_heap+0x13b0>
    96e2:	48 c1 e1 10          	shl    $0x10,%rcx
    96e6:	48 39 ca             	cmp    %rcx,%rdx
    96e9:	73 6d                	jae    9758 <fwp_caps23+0xb8>
    96eb:	48 89 d1             	mov    %rdx,%rcx
    96ee:	48 c1 e9 10          	shr    $0x10,%rcx
    96f2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    96f6:	48 8b 0d fb 94 01 00 	mov    0x194fb(%rip),%rcx        # 22bf8 <fwp_heap+0x13f8>
    96fd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    9701:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    9705:	48 85 f6             	test   %rsi,%rsi
    9708:	74 4e                	je     9758 <fwp_caps23+0xb8>
    970a:	0f b6 39             	movzbl (%rcx),%edi
    970d:	40 80 ff 02          	cmp    $0x2,%dil
    9711:	0f 84 b9 00 00 00    	je     97d0 <fwp_caps23+0x130>
    9717:	40 80 ff 01          	cmp    $0x1,%dil
    971b:	75 3b                	jne    9758 <fwp_caps23+0xb8>
    971d:	8b 79 18             	mov    0x18(%rcx),%edi
    9720:	0f b7 d2             	movzwl %dx,%edx
    9723:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9726:	48 0f af d7          	imul   %rdi,%rdx
    972a:	48 c1 ea 20          	shr    $0x20,%rdx
    972e:	48 39 ca             	cmp    %rcx,%rdx
    9731:	73 25                	jae    9758 <fwp_caps23+0xb8>
    9733:	48 01 d6             	add    %rdx,%rsi
    9736:	80 3e 01             	cmpb   $0x1,(%rsi)
    9739:	75 1d                	jne    9758 <fwp_caps23+0xb8>
    973b:	48 89 c7             	mov    %rax,%rdi
    973e:	48 83 c4 18          	add    $0x18,%rsp
    9742:	e9 a9 c0 ff ff       	jmp    57f0 <fwp_mem_free>
    9747:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    974e:	00 00 
    9750:	85 f6                	test   %esi,%esi
    9752:	0f 84 79 ff ff ff    	je     96d1 <fwp_caps23+0x31>
    9758:	48 83 c4 18          	add    $0x18,%rsp
    975c:	c3                   	ret
    975d:	0f 1f 00             	nopl   (%rax)
    9760:	48 8b 05 71 94 01 00 	mov    0x19471(%rip),%rax        # 22bd8 <fwp_heap+0x13d8>
    9767:	48 2b 3d 42 94 01 00 	sub    0x19442(%rip),%rdi        # 22bb0 <fwp_heap+0x13b0>
    976e:	48 c1 e0 10          	shl    $0x10,%rax
    9772:	48 39 c7             	cmp    %rax,%rdi
    9775:	73 e1                	jae    9758 <fwp_caps23+0xb8>
    9777:	48 89 f8             	mov    %rdi,%rax
    977a:	48 c1 e8 10          	shr    $0x10,%rax
    977e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9782:	48 8b 05 6f 94 01 00 	mov    0x1946f(%rip),%rax        # 22bf8 <fwp_heap+0x13f8>
    9789:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    978d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    9791:	48 85 c0             	test   %rax,%rax
    9794:	74 c2                	je     9758 <fwp_caps23+0xb8>
    9796:	0f b6 0a             	movzbl (%rdx),%ecx
    9799:	80 f9 02             	cmp    $0x2,%cl
    979c:	74 42                	je     97e0 <fwp_caps23+0x140>
    979e:	80 f9 01             	cmp    $0x1,%cl
    97a1:	75 b5                	jne    9758 <fwp_caps23+0xb8>
    97a3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    97a6:	0f b7 ff             	movzwl %di,%edi
    97a9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    97ac:	48 0f af f9          	imul   %rcx,%rdi
    97b0:	48 c1 ef 20          	shr    $0x20,%rdi
    97b4:	48 39 d7             	cmp    %rdx,%rdi
    97b7:	73 9f                	jae    9758 <fwp_caps23+0xb8>
    97b9:	48 01 f8             	add    %rdi,%rax
    97bc:	0f b6 10             	movzbl (%rax),%edx
    97bf:	84 d2                	test   %dl,%dl
    97c1:	74 95                	je     9758 <fwp_caps23+0xb8>
    97c3:	80 fa fd             	cmp    $0xfd,%dl
    97c6:	77 23                	ja     97eb <fwp_caps23+0x14b>
    97c8:	83 c2 01             	add    $0x1,%edx
    97cb:	88 10                	mov    %dl,(%rax)
    97cd:	eb 89                	jmp    9758 <fwp_caps23+0xb8>
    97cf:	90                   	nop
    97d0:	66 85 d2             	test   %dx,%dx
    97d3:	0f 85 7f ff ff ff    	jne    9758 <fwp_caps23+0xb8>
    97d9:	e9 58 ff ff ff       	jmp    9736 <fwp_caps23+0x96>
    97de:	66 90                	xchg   %ax,%ax
    97e0:	66 85 ff             	test   %di,%di
    97e3:	0f 85 6f ff ff ff    	jne    9758 <fwp_caps23+0xb8>
    97e9:	eb d1                	jmp    97bc <fwp_caps23+0x11c>
    97eb:	48 89 c7             	mov    %rax,%rdi
    97ee:	48 83 c4 18          	add    $0x18,%rsp
    97f2:	e9 99 bc ff ff       	jmp    5490 <fwp_rc_wide_dup>
    97f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    97fe:	00 00 

0000000000009800 <f23>:
    9800:	41 57                	push   %r15
    9802:	41 56                	push   %r14
    9804:	41 55                	push   %r13
    9806:	41 54                	push   %r12
    9808:	55                   	push   %rbp
    9809:	53                   	push   %rbx
    980a:	48 83 ec 38          	sub    $0x38,%rsp
    980e:	48 8b 15 c3 93 01 00 	mov    0x193c3(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    9815:	48 8b 0d 94 93 01 00 	mov    0x19394(%rip),%rcx        # 22bb0 <fwp_heap+0x13b0>
    981c:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9823:	00 00 
    9825:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    982a:	49 89 fc             	mov    %rdi,%r12
    982d:	48 c1 e2 10          	shl    $0x10,%rdx
    9831:	48 85 ff             	test   %rdi,%rdi
    9834:	0f 84 bc 02 00 00    	je     9af6 <f23+0x2f6>
    983a:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    983f:	48 89 d8             	mov    %rbx,%rax
    9842:	48 29 c8             	sub    %rcx,%rax
    9845:	48 39 d0             	cmp    %rdx,%rax
    9848:	0f 83 72 03 00 00    	jae    9bc0 <f23+0x3c0>
    984e:	48 89 c2             	mov    %rax,%rdx
    9851:	48 c1 ea 10          	shr    $0x10,%rdx
    9855:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9859:	48 8b 15 98 93 01 00 	mov    0x19398(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    9860:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9864:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9868:	48 85 ff             	test   %rdi,%rdi
    986b:	0f 84 4f 03 00 00    	je     9bc0 <f23+0x3c0>
    9871:	0f b6 0a             	movzbl (%rdx),%ecx
    9874:	80 f9 02             	cmp    $0x2,%cl
    9877:	0f 84 53 02 00 00    	je     9ad0 <f23+0x2d0>
    987d:	80 f9 01             	cmp    $0x1,%cl
    9880:	75 24                	jne    98a6 <f23+0xa6>
    9882:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9885:	0f b7 c0             	movzwl %ax,%eax
    9888:	8b 52 1c             	mov    0x1c(%rdx),%edx
    988b:	48 0f af c1          	imul   %rcx,%rax
    988f:	48 c1 e8 20          	shr    $0x20,%rax
    9893:	48 39 d0             	cmp    %rdx,%rax
    9896:	73 0e                	jae    98a6 <f23+0xa6>
    9898:	48 01 c7             	add    %rax,%rdi
    989b:	0f b6 07             	movzbl (%rdi),%eax
    989e:	84 c0                	test   %al,%al
    98a0:	0f 85 ca 02 00 00    	jne    9b70 <f23+0x370>
    98a6:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    98ab:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    98b0:	ba 01 00 00 00       	mov    $0x1,%edx
    98b5:	48 85 db             	test   %rbx,%rbx
    98b8:	74 13                	je     98cd <f23+0xcd>
    98ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    98c0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    98c4:	48 83 c2 01          	add    $0x1,%rdx
    98c8:	48 85 db             	test   %rbx,%rbx
    98cb:	75 f3                	jne    98c0 <f23+0xc0>
    98cd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    98d2:	48 85 c0             	test   %rax,%rax
    98d5:	0f 84 15 03 00 00    	je     9bf0 <f23+0x3f0>
    98db:	31 db                	xor    %ebx,%ebx
    98dd:	0f 1f 00             	nopl   (%rax)
    98e0:	48 8b 40 10          	mov    0x10(%rax),%rax
    98e4:	48 83 c3 01          	add    $0x1,%rbx
    98e8:	48 85 c0             	test   %rax,%rax
    98eb:	75 f3                	jne    98e0 <f23+0xe0>
    98ed:	48 39 d3             	cmp    %rdx,%rbx
    98f0:	48 0f 47 da          	cmova  %rdx,%rbx
    98f4:	48 89 d8             	mov    %rbx,%rax
    98f7:	48 c1 e8 3c          	shr    $0x3c,%rax
    98fb:	0f 85 8f 03 00 00    	jne    9c90 <f23+0x490>
    9901:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    9905:	be 02 00 00 00       	mov    $0x2,%esi
    990a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    9911:	00 
    9912:	e8 d9 c3 ff ff       	call   5cf0 <fwp_heap_alloc>
    9917:	48 89 28             	mov    %rbp,(%rax)
    991a:	48 8b 15 b7 92 01 00 	mov    0x192b7(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    9921:	49 89 c6             	mov    %rax,%r14
    9924:	48 2b 05 85 92 01 00 	sub    0x19285(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    992b:	48 c1 e2 10          	shl    $0x10,%rdx
    992f:	48 39 d0             	cmp    %rdx,%rax
    9932:	73 57                	jae    998b <f23+0x18b>
    9934:	48 89 c2             	mov    %rax,%rdx
    9937:	48 c1 ea 10          	shr    $0x10,%rdx
    993b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    993f:	48 8b 15 b2 92 01 00 	mov    0x192b2(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    9946:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    994a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    994e:	48 85 ed             	test   %rbp,%rbp
    9951:	74 38                	je     998b <f23+0x18b>
    9953:	0f b6 0a             	movzbl (%rdx),%ecx
    9956:	80 f9 02             	cmp    $0x2,%cl
    9959:	0f 84 51 02 00 00    	je     9bb0 <f23+0x3b0>
    995f:	80 f9 01             	cmp    $0x1,%cl
    9962:	75 27                	jne    998b <f23+0x18b>
    9964:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9967:	0f b7 c0             	movzwl %ax,%eax
    996a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    996d:	48 0f af c1          	imul   %rcx,%rax
    9971:	48 c1 e8 20          	shr    $0x20,%rax
    9975:	48 39 d0             	cmp    %rdx,%rax
    9978:	73 11                	jae    998b <f23+0x18b>
    997a:	48 01 c5             	add    %rax,%rbp
    997d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9981:	0f 84 d5 02 00 00    	je     9c5c <f23+0x45c>
    9987:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    998b:	48 85 db             	test   %rbx,%rbx
    998e:	74 5d                	je     99ed <f23+0x1ed>
    9990:	48 c1 e3 04          	shl    $0x4,%rbx
    9994:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    9999:	4c 89 f5             	mov    %r14,%rbp
    999c:	4d 89 e5             	mov    %r12,%r13
    999f:	4c 01 f3             	add    %r14,%rbx
    99a2:	0f 1f 00             	nopl   (%rax)
    99a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    99ac:	00 00 00 00 
    99b0:	49 8b 45 08          	mov    0x8(%r13),%rax
    99b4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    99b8:	48 83 c5 10          	add    $0x10,%rbp
    99bc:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    99c1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    99c5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    99c9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    99ce:	e8 fd c9 ff ff       	call   63d0 <w107>
    99d3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    99d8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    99dc:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    99e0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    99e4:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    99e8:	48 39 dd             	cmp    %rbx,%rbp
    99eb:	75 c3                	jne    99b0 <f23+0x1b0>
    99ed:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    99f2:	e8 e9 f9 ff ff       	call   93e0 <fwp_drop2>
    99f7:	4c 89 e7             	mov    %r12,%rdi
    99fa:	e8 e1 f9 ff ff       	call   93e0 <fwp_drop2>
    99ff:	4c 89 f7             	mov    %r14,%rdi
    9a02:	e8 49 cb ff ff       	call   6550 <w164.constprop.0>
    9a07:	4c 89 f7             	mov    %r14,%rdi
    9a0a:	48 89 c3             	mov    %rax,%rbx
    9a0d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    9a13:	e8 58 de ff ff       	call   7870 <fwp_drop4>
    9a18:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    9a1e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    9a23:	31 ff                	xor    %edi,%edi
    9a25:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    9a2a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    9a2e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    9a33:	e8 b8 cb ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    9a38:	48 8b 15 99 91 01 00 	mov    0x19199(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    9a3f:	48 89 c5             	mov    %rax,%rbp
    9a42:	48 2b 05 67 91 01 00 	sub    0x19167(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    9a49:	48 c1 e2 10          	shl    $0x10,%rdx
    9a4d:	48 39 d0             	cmp    %rdx,%rax
    9a50:	73 55                	jae    9aa7 <f23+0x2a7>
    9a52:	48 89 c2             	mov    %rax,%rdx
    9a55:	48 c1 ea 10          	shr    $0x10,%rdx
    9a59:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9a5d:	48 8b 15 94 91 01 00 	mov    0x19194(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    9a64:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9a68:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9a6c:	48 85 db             	test   %rbx,%rbx
    9a6f:	74 36                	je     9aa7 <f23+0x2a7>
    9a71:	0f b6 0a             	movzbl (%rdx),%ecx
    9a74:	80 f9 02             	cmp    $0x2,%cl
    9a77:	0f 84 1b 01 00 00    	je     9b98 <f23+0x398>
    9a7d:	80 f9 01             	cmp    $0x1,%cl
    9a80:	75 25                	jne    9aa7 <f23+0x2a7>
    9a82:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9a85:	0f b7 c0             	movzwl %ax,%eax
    9a88:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a8b:	48 0f af c1          	imul   %rcx,%rax
    9a8f:	48 c1 e8 20          	shr    $0x20,%rax
    9a93:	48 39 d0             	cmp    %rdx,%rax
    9a96:	73 0f                	jae    9aa7 <f23+0x2a7>
    9a98:	48 01 c3             	add    %rax,%rbx
    9a9b:	80 3b ff             	cmpb   $0xff,(%rbx)
    9a9e:	0f 84 ab 01 00 00    	je     9c4f <f23+0x44f>
    9aa4:	c6 03 01             	movb   $0x1,(%rbx)
    9aa7:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    9aac:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9ab3:	00 00 
    9ab5:	0f 85 d0 01 00 00    	jne    9c8b <f23+0x48b>
    9abb:	48 83 c4 38          	add    $0x38,%rsp
    9abf:	48 89 e8             	mov    %rbp,%rax
    9ac2:	5b                   	pop    %rbx
    9ac3:	5d                   	pop    %rbp
    9ac4:	41 5c                	pop    %r12
    9ac6:	41 5d                	pop    %r13
    9ac8:	41 5e                	pop    %r14
    9aca:	41 5f                	pop    %r15
    9acc:	c3                   	ret
    9acd:	0f 1f 00             	nopl   (%rax)
    9ad0:	66 85 c0             	test   %ax,%ax
    9ad3:	0f 85 cd fd ff ff    	jne    98a6 <f23+0xa6>
    9ad9:	0f b6 07             	movzbl (%rdi),%eax
    9adc:	84 c0                	test   %al,%al
    9ade:	0f 84 c2 fd ff ff    	je     98a6 <f23+0xa6>
    9ae4:	3c fd                	cmp    $0xfd,%al
    9ae6:	0f 87 95 01 00 00    	ja     9c81 <f23+0x481>
    9aec:	83 c0 01             	add    $0x1,%eax
    9aef:	88 07                	mov    %al,(%rdi)
    9af1:	e9 b0 fd ff ff       	jmp    98a6 <f23+0xa6>
    9af6:	48 f7 d9             	neg    %rcx
    9af9:	48 39 d1             	cmp    %rdx,%rcx
    9afc:	0f 83 ee 00 00 00    	jae    9bf0 <f23+0x3f0>
    9b02:	48 89 c8             	mov    %rcx,%rax
    9b05:	48 c1 e8 10          	shr    $0x10,%rax
    9b09:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9b0d:	48 8b 05 e4 90 01 00 	mov    0x190e4(%rip),%rax        # 22bf8 <fwp_heap+0x13f8>
    9b14:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9b18:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9b1c:	48 85 ff             	test   %rdi,%rdi
    9b1f:	0f 84 cb 00 00 00    	je     9bf0 <f23+0x3f0>
    9b25:	0f b6 02             	movzbl (%rdx),%eax
    9b28:	3c 02                	cmp    $0x2,%al
    9b2a:	0f 84 9a 00 00 00    	je     9bca <f23+0x3ca>
    9b30:	3c 01                	cmp    $0x1,%al
    9b32:	0f 85 b8 00 00 00    	jne    9bf0 <f23+0x3f0>
    9b38:	0f b7 c1             	movzwl %cx,%eax
    9b3b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9b3e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9b41:	48 0f af c1          	imul   %rcx,%rax
    9b45:	48 c1 e8 20          	shr    $0x20,%rax
    9b49:	48 39 d0             	cmp    %rdx,%rax
    9b4c:	0f 83 9e 00 00 00    	jae    9bf0 <f23+0x3f0>
    9b52:	48 01 c7             	add    %rax,%rdi
    9b55:	0f b6 07             	movzbl (%rdi),%eax
    9b58:	84 c0                	test   %al,%al
    9b5a:	0f 84 90 00 00 00    	je     9bf0 <f23+0x3f0>
    9b60:	31 db                	xor    %ebx,%ebx
    9b62:	0f 1f 00             	nopl   (%rax)
    9b65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b6c:	00 00 00 00 
    9b70:	3c fd                	cmp    $0xfd,%al
    9b72:	0f 87 f1 00 00 00    	ja     9c69 <f23+0x469>
    9b78:	83 c0 01             	add    $0x1,%eax
    9b7b:	88 07                	mov    %al,(%rdi)
    9b7d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9b82:	31 d2                	xor    %edx,%edx
    9b84:	4d 85 e4             	test   %r12,%r12
    9b87:	0f 85 1e fd ff ff    	jne    98ab <f23+0xab>
    9b8d:	e9 3b fd ff ff       	jmp    98cd <f23+0xcd>
    9b92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9b98:	66 85 c0             	test   %ax,%ax
    9b9b:	0f 85 06 ff ff ff    	jne    9aa7 <f23+0x2a7>
    9ba1:	e9 f5 fe ff ff       	jmp    9a9b <f23+0x29b>
    9ba6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9bad:	00 00 00 
    9bb0:	66 85 c0             	test   %ax,%ax
    9bb3:	0f 85 d2 fd ff ff    	jne    998b <f23+0x18b>
    9bb9:	e9 bf fd ff ff       	jmp    997d <f23+0x17d>
    9bbe:	66 90                	xchg   %ax,%ax
    9bc0:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9bc5:	e9 e6 fc ff ff       	jmp    98b0 <f23+0xb0>
    9bca:	66 85 c9             	test   %cx,%cx
    9bcd:	75 21                	jne    9bf0 <f23+0x3f0>
    9bcf:	0f b6 07             	movzbl (%rdi),%eax
    9bd2:	84 c0                	test   %al,%al
    9bd4:	74 1a                	je     9bf0 <f23+0x3f0>
    9bd6:	3c fd                	cmp    $0xfd,%al
    9bd8:	0f 87 be 00 00 00    	ja     9c9c <f23+0x49c>
    9bde:	83 c0 01             	add    $0x1,%eax
    9be1:	88 07                	mov    %al,(%rdi)
    9be3:	66 90                	xchg   %ax,%ax
    9be5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9bec:	00 00 00 00 
    9bf0:	be 02 00 00 00       	mov    $0x2,%esi
    9bf5:	bf 08 00 00 00       	mov    $0x8,%edi
    9bfa:	e8 f1 c0 ff ff       	call   5cf0 <fwp_heap_alloc>
    9bff:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9c06:	48 8b 15 cb 8f 01 00 	mov    0x18fcb(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    9c0d:	49 89 c6             	mov    %rax,%r14
    9c10:	48 2b 05 99 8f 01 00 	sub    0x18f99(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    9c17:	48 c1 e2 10          	shl    $0x10,%rdx
    9c1b:	48 39 d0             	cmp    %rdx,%rax
    9c1e:	73 53                	jae    9c73 <f23+0x473>
    9c20:	48 89 c2             	mov    %rax,%rdx
    9c23:	48 c1 ea 10          	shr    $0x10,%rdx
    9c27:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9c2b:	48 8b 15 c6 8f 01 00 	mov    0x18fc6(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    9c32:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9c36:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9c3a:	48 85 ed             	test   %rbp,%rbp
    9c3d:	74 34                	je     9c73 <f23+0x473>
    9c3f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    9c46:	00 00 
    9c48:	31 db                	xor    %ebx,%ebx
    9c4a:	e9 04 fd ff ff       	jmp    9953 <f23+0x153>
    9c4f:	48 89 df             	mov    %rbx,%rdi
    9c52:	e8 59 b9 ff ff       	call   55b0 <fwp_rc_forget_slot>
    9c57:	e9 48 fe ff ff       	jmp    9aa4 <f23+0x2a4>
    9c5c:	48 89 ef             	mov    %rbp,%rdi
    9c5f:	e8 4c b9 ff ff       	call   55b0 <fwp_rc_forget_slot>
    9c64:	e9 1e fd ff ff       	jmp    9987 <f23+0x187>
    9c69:	e8 22 b8 ff ff       	call   5490 <fwp_rc_wide_dup>
    9c6e:	e9 0a ff ff ff       	jmp    9b7d <f23+0x37d>
    9c73:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    9c7a:	00 00 
    9c7c:	e9 6c fd ff ff       	jmp    99ed <f23+0x1ed>
    9c81:	e8 0a b8 ff ff       	call   5490 <fwp_rc_wide_dup>
    9c86:	e9 1b fc ff ff       	jmp    98a6 <f23+0xa6>
    9c8b:	e8 d0 97 ff ff       	call   3460 <__stack_chk_fail@plt>
    9c90:	48 8d 3d 13 35 00 00 	lea    0x3513(%rip),%rdi        # d1aa <_IO_stdin_used+0x1aa>
    9c97:	e8 54 a7 ff ff       	call   43f0 <fwp_trap>
    9c9c:	e8 ef b7 ff ff       	call   5490 <fwp_rc_wide_dup>
    9ca1:	e9 4a ff ff ff       	jmp    9bf0 <f23+0x3f0>
    9ca6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9cad:	00 00 00 

0000000000009cb0 <fwp_owned_entry23>:
    9cb0:	f3 0f 1e fa          	endbr64
    9cb4:	48 8b 3f             	mov    (%rdi),%rdi
    9cb7:	e9 44 fb ff ff       	jmp    9800 <f23>
    9cbc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009cc0 <e23>:
    9cc0:	f3 0f 1e fa          	endbr64
    9cc4:	53                   	push   %rbx
    9cc5:	48 8b 1f             	mov    (%rdi),%rbx
    9cc8:	48 89 df             	mov    %rbx,%rdi
    9ccb:	e8 50 ca ff ff       	call   6720 <fwp_rc_share>
    9cd0:	48 89 df             	mov    %rbx,%rdi
    9cd3:	e8 28 fb ff ff       	call   9800 <f23>
    9cd8:	48 89 c3             	mov    %rax,%rbx
    9cdb:	48 89 c7             	mov    %rax,%rdi
    9cde:	e8 3d ca ff ff       	call   6720 <fwp_rc_share>
    9ce3:	48 89 d8             	mov    %rbx,%rax
    9ce6:	5b                   	pop    %rbx
    9ce7:	c3                   	ret
    9ce8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9cef:	00 

0000000000009cf0 <fwp_write>:
    9cf0:	41 57                	push   %r15
    9cf2:	41 56                	push   %r14
    9cf4:	41 55                	push   %r13
    9cf6:	41 54                	push   %r12
    9cf8:	55                   	push   %rbp
    9cf9:	53                   	push   %rbx
    9cfa:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9d01:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9d08:	00 00 
    9d0a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9d11:	00 
    9d12:	49 89 d4             	mov    %rdx,%r12
    9d15:	8b 12                	mov    (%rdx),%edx
    9d17:	83 fa 19             	cmp    $0x19,%edx
    9d1a:	77 6a                	ja     9d86 <fwp_write+0x96>
    9d1c:	48 89 f5             	mov    %rsi,%rbp
    9d1f:	89 d0                	mov    %edx,%eax
    9d21:	89 ce                	mov    %ecx,%esi
    9d23:	48 89 fb             	mov    %rdi,%rbx
    9d26:	48 8d 0d d3 3d 00 00 	lea    0x3dd3(%rip),%rcx        # db00 <_IO_stdin_used+0xb00>
    9d2d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9d31:	48 01 c8             	add    %rcx,%rax
    9d34:	3e ff e0             	notrack jmp *%rax
    9d37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9d3e:	00 00 
    9d40:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9d44:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9d48:	48 89 ca             	mov    %rcx,%rdx
    9d4b:	48 85 c9             	test   %rcx,%rcx
    9d4e:	0f 88 9c 0c 00 00    	js     a9f0 <fwp_write+0xd00>
    9d54:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9d5b:	00 
    9d5c:	48 89 c6             	mov    %rax,%rsi
    9d5f:	4c 89 e7             	mov    %r12,%rdi
    9d62:	e8 d9 9c ff ff       	call   3a40 <fwp_fmt_u128>
    9d67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9d6e:	00 00 
    9d70:	4c 89 e7             	mov    %r12,%rdi
    9d73:	e8 d8 96 ff ff       	call   3450 <strlen@plt>
    9d78:	4c 89 e6             	mov    %r12,%rsi
    9d7b:	48 89 df             	mov    %rbx,%rdi
    9d7e:	48 89 c2             	mov    %rax,%rdx
    9d81:	e8 8a a4 ff ff       	call   4210 <buf_put>
    9d86:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9d8d:	00 
    9d8e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9d95:	00 00 
    9d97:	0f 85 28 04 00 00    	jne    a1c5 <fwp_write+0x4d5>
    9d9d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9da4:	5b                   	pop    %rbx
    9da5:	5d                   	pop    %rbp
    9da6:	41 5c                	pop    %r12
    9da8:	41 5d                	pop    %r13
    9daa:	41 5e                	pop    %r14
    9dac:	41 5f                	pop    %r15
    9dae:	c3                   	ret
    9daf:	90                   	nop
    9db0:	49 89 e9             	mov    %rbp,%r9
    9db3:	4c 8d 05 bb 32 00 00 	lea    0x32bb(%rip),%r8        # d075 <_IO_stdin_used+0x75>
    9dba:	b9 00 02 00 00       	mov    $0x200,%ecx
    9dbf:	ba 02 00 00 00       	mov    $0x2,%edx
    9dc4:	be 00 02 00 00       	mov    $0x200,%esi
    9dc9:	31 c0                	xor    %eax,%eax
    9dcb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9dd2:	00 
    9dd3:	e8 d8 95 ff ff       	call   33b0 <__snprintf_chk@plt>
    9dd8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9ddf:	00 
    9de0:	e8 6b 96 ff ff       	call   3450 <strlen@plt>
    9de5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9dec:	00 
    9ded:	48 89 df             	mov    %rbx,%rdi
    9df0:	48 89 c2             	mov    %rax,%rdx
    9df3:	e8 18 a4 ff ff       	call   4210 <buf_put>
    9df8:	eb 8c                	jmp    9d86 <fwp_write+0x96>
    9dfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9e00:	49 89 e9             	mov    %rbp,%r9
    9e03:	4c 8d 05 d5 33 00 00 	lea    0x33d5(%rip),%r8        # d1df <_IO_stdin_used+0x1df>
    9e0a:	eb ae                	jmp    9dba <fwp_write+0xca>
    9e0c:	0f 1f 40 00          	nopl   0x0(%rax)
    9e10:	83 fa 13             	cmp    $0x13,%edx
    9e13:	48 8d 05 bb 33 00 00 	lea    0x33bb(%rip),%rax        # d1d5 <_IO_stdin_used+0x1d5>
    9e1a:	48 8d 35 b9 33 00 00 	lea    0x33b9(%rip),%rsi        # d1da <_IO_stdin_used+0x1da>
    9e21:	ba 04 00 00 00       	mov    $0x4,%edx
    9e26:	48 0f 44 f0          	cmove  %rax,%rsi
    9e2a:	45 31 ed             	xor    %r13d,%r13d
    9e2d:	e8 de a3 ff ff       	call   4210 <buf_put>
    9e32:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9e37:	0f 84 a3 08 00 00    	je     a6e0 <fwp_write+0x9f0>
    9e3d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9e42:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9e47:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9e4c:	48 89 df             	mov    %rbx,%rdi
    9e4f:	49 0f 44 c5          	cmove  %r13,%rax
    9e53:	31 c9                	xor    %ecx,%ecx
    9e55:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    9e5a:	e8 91 fe ff ff       	call   9cf0 <fwp_write>
    9e5f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9e64:	0f 84 6e 09 00 00    	je     a7d8 <fwp_write+0xae8>
    9e6a:	49 83 c5 01          	add    $0x1,%r13
    9e6e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9e72:	0f 83 68 08 00 00    	jae    a6e0 <fwp_write+0x9f0>
    9e78:	ba 02 00 00 00       	mov    $0x2,%edx
    9e7d:	48 8d 35 9b 33 00 00 	lea    0x339b(%rip),%rsi        # d21f <_IO_stdin_used+0x21f>
    9e84:	48 89 df             	mov    %rbx,%rdi
    9e87:	e8 84 a3 ff ff       	call   4210 <buf_put>
    9e8c:	eb af                	jmp    9e3d <fwp_write+0x14d>
    9e8e:	66 90                	xchg   %ax,%ax
    9e90:	ba 06 00 00 00       	mov    $0x6,%edx
    9e95:	48 8d 35 5c 33 00 00 	lea    0x335c(%rip),%rsi        # d1f8 <_IO_stdin_used+0x1f8>
    9e9c:	48 83 c5 10          	add    $0x10,%rbp
    9ea0:	e8 6b a3 ff ff       	call   4210 <buf_put>
    9ea5:	48 89 ef             	mov    %rbp,%rdi
    9ea8:	e8 a3 95 ff ff       	call   3450 <strlen@plt>
    9ead:	48 89 ee             	mov    %rbp,%rsi
    9eb0:	48 89 df             	mov    %rbx,%rdi
    9eb3:	48 89 c2             	mov    %rax,%rdx
    9eb6:	e8 55 a3 ff ff       	call   4210 <buf_put>
    9ebb:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9ec0:	ba 01 00 00 00       	mov    $0x1,%edx
    9ec5:	48 89 df             	mov    %rbx,%rdi
    9ec8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9ecd:	e8 3e a3 ff ff       	call   4210 <buf_put>
    9ed2:	e9 af fe ff ff       	jmp    9d86 <fwp_write+0x96>
    9ed7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9ede:	00 00 
    9ee0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9ee7:	00 
    9ee8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9eef:	00 00 
    9ef1:	0f 85 ce 02 00 00    	jne    a1c5 <fwp_write+0x4d5>
    9ef7:	ba 0a 00 00 00       	mov    $0xa,%edx
    9efc:	48 8d 35 e1 32 00 00 	lea    0x32e1(%rip),%rsi        # d1e4 <_IO_stdin_used+0x1e4>
    9f03:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9f0a:	48 89 df             	mov    %rbx,%rdi
    9f0d:	5b                   	pop    %rbx
    9f0e:	5d                   	pop    %rbp
    9f0f:	41 5c                	pop    %r12
    9f11:	41 5d                	pop    %r13
    9f13:	41 5e                	pop    %r14
    9f15:	41 5f                	pop    %r15
    9f17:	e9 f4 a2 ff ff       	jmp    4210 <buf_put>
    9f1c:	0f 1f 40 00          	nopl   0x0(%rax)
    9f20:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    9f25:	4d 85 ed             	test   %r13,%r13
    9f28:	0f 84 02 0c 00 00    	je     ab30 <fwp_write+0xe40>
    9f2e:	48 8d 35 f7 32 00 00 	lea    0x32f7(%rip),%rsi        # d22c <_IO_stdin_used+0x22c>
    9f35:	4c 89 ef             	mov    %r13,%rdi
    9f38:	e8 f3 95 ff ff       	call   3530 <strcmp@plt>
    9f3d:	41 89 c1             	mov    %eax,%r9d
    9f40:	85 c0                	test   %eax,%eax
    9f42:	0f 84 6c 0c 00 00    	je     abb4 <fwp_write+0xec4>
    9f48:	4c 89 ef             	mov    %r13,%rdi
    9f4b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9f50:	e8 fb 94 ff ff       	call   3450 <strlen@plt>
    9f55:	4c 89 ee             	mov    %r13,%rsi
    9f58:	48 89 df             	mov    %rbx,%rdi
    9f5b:	48 89 c2             	mov    %rax,%rdx
    9f5e:	e8 ad a2 ff ff       	call   4210 <buf_put>
    9f63:	ba 01 00 00 00       	mov    $0x1,%edx
    9f68:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9f6d:	48 89 df             	mov    %rbx,%rdi
    9f70:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9f75:	e8 96 a2 ff ff       	call   4210 <buf_put>
    9f7a:	ba 01 00 00 00       	mov    $0x1,%edx
    9f7f:	4c 89 fe             	mov    %r15,%rsi
    9f82:	48 89 df             	mov    %rbx,%rdi
    9f85:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    9f8a:	e8 81 a2 ff ff       	call   4210 <buf_put>
    9f8f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9f94:	45 31 f6             	xor    %r14d,%r14d
    9f97:	85 d2                	test   %edx,%edx
    9f99:	0f 8e 81 0a 00 00    	jle    aa20 <fwp_write+0xd30>
    9f9f:	45 31 ed             	xor    %r13d,%r13d
    9fa2:	4d 85 ed             	test   %r13,%r13
    9fa5:	0f 85 75 07 00 00    	jne    a720 <fwp_write+0xa30>
    9fab:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9fb2:	00 
    9fb3:	45 85 f6             	test   %r14d,%r14d
    9fb6:	0f 84 84 07 00 00    	je     a740 <fwp_write+0xa50>
    9fbc:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    9fc1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    9fc6:	48 89 df             	mov    %rbx,%rdi
    9fc9:	49 83 c5 01          	add    $0x1,%r13
    9fcd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    9fd1:	31 c9                	xor    %ecx,%ecx
    9fd3:	e8 18 fd ff ff       	call   9cf0 <fwp_write>
    9fd8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    9fdd:	7f c3                	jg     9fa2 <fwp_write+0x2b2>
    9fdf:	45 85 f6             	test   %r14d,%r14d
    9fe2:	0f 84 38 0a 00 00    	je     aa20 <fwp_write+0xd30>
    9fe8:	b8 29 00 00 00       	mov    $0x29,%eax
    9fed:	ba 01 00 00 00       	mov    $0x1,%edx
    9ff2:	4c 89 fe             	mov    %r15,%rsi
    9ff5:	48 89 df             	mov    %rbx,%rdi
    9ff8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    9ffc:	e8 0f a2 ff ff       	call   4210 <buf_put>
    a001:	e9 80 fd ff ff       	jmp    9d86 <fwp_write+0x96>
    a006:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a00d:	00 00 00 
    a010:	ba 01 00 00 00       	mov    $0x1,%edx
    a015:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a01a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    a01f:	e8 ec a1 ff ff       	call   4210 <buf_put>
    a024:	48 85 ed             	test   %rbp,%rbp
    a027:	0f 84 93 06 00 00    	je     a6c0 <fwp_write+0x9d0>
    a02d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    a031:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a036:	31 c9                	xor    %ecx,%ecx
    a038:	48 89 df             	mov    %rbx,%rdi
    a03b:	e8 b0 fc ff ff       	call   9cf0 <fwp_write>
    a040:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    a044:	48 85 ed             	test   %rbp,%rbp
    a047:	0f 84 73 06 00 00    	je     a6c0 <fwp_write+0x9d0>
    a04d:	ba 02 00 00 00       	mov    $0x2,%edx
    a052:	48 8d 35 c6 31 00 00 	lea    0x31c6(%rip),%rsi        # d21f <_IO_stdin_used+0x21f>
    a059:	48 89 df             	mov    %rbx,%rdi
    a05c:	e8 af a1 ff ff       	call   4210 <buf_put>
    a061:	eb ca                	jmp    a02d <fwp_write+0x33d>
    a063:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a068:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    a06c:	85 f6                	test   %esi,%esi
    a06e:	0f 84 fc 07 00 00    	je     a870 <fwp_write+0xb80>
    a074:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a07b:	00 
    a07c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a083:	00 00 
    a085:	0f 85 3a 01 00 00    	jne    a1c5 <fwp_write+0x4d5>
    a08b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    a08f:	4c 89 ea             	mov    %r13,%rdx
    a092:	e9 6c fe ff ff       	jmp    9f03 <fwp_write+0x213>
    a097:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a09e:	00 00 
    a0a0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    a0a5:	ba 01 00 00 00       	mov    $0x1,%edx
    a0aa:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    a0af:	48 89 ee             	mov    %rbp,%rsi
    a0b2:	e8 59 a1 ff ff       	call   4210 <buf_put>
    a0b7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    a0bc:	4c 89 e7             	mov    %r12,%rdi
    a0bf:	e8 8c 93 ff ff       	call   3450 <strlen@plt>
    a0c4:	4c 89 e6             	mov    %r12,%rsi
    a0c7:	48 89 df             	mov    %rbx,%rdi
    a0ca:	48 89 c2             	mov    %rax,%rdx
    a0cd:	e8 3e a1 ff ff       	call   4210 <buf_put>
    a0d2:	ba 01 00 00 00       	mov    $0x1,%edx
    a0d7:	48 89 ee             	mov    %rbp,%rsi
    a0da:	48 89 df             	mov    %rbx,%rdi
    a0dd:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a0e2:	e8 29 a1 ff ff       	call   4210 <buf_put>
    a0e7:	e9 9a fc ff ff       	jmp    9d86 <fwp_write+0x96>
    a0ec:	0f 1f 40 00          	nopl   0x0(%rax)
    a0f0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    a0f5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    a0f9:	0f 8a 8e 0b 00 00    	jp     ac8d <fwp_write+0xf9d>
    a0ff:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a103:	66 0f 54 05 05 3b 00 	andpd  0x3b05(%rip),%xmm0        # dc10 <msg.8+0xa0>
    a10a:	00 
    a10b:	bd 01 00 00 00       	mov    $0x1,%ebp
    a110:	66 0f 2e 05 38 3b 00 	ucomisd 0x3b38(%rip),%xmm0        # dc50 <msg.8+0xe0>
    a117:	00 
    a118:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a11f:	00 
    a120:	0f 87 b2 09 00 00    	ja     aad8 <fwp_write+0xde8>
    a126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a12d:	00 00 00 
    a130:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a134:	89 ee                	mov    %ebp,%esi
    a136:	4c 89 e7             	mov    %r12,%rdi
    a139:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    a13e:	e8 cd a5 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a143:	31 f6                	xor    %esi,%esi
    a145:	4c 89 e7             	mov    %r12,%rdi
    a148:	e8 c3 92 ff ff       	call   3410 <strtod@plt>
    a14d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    a152:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    a156:	7a 06                	jp     a15e <fwp_write+0x46e>
    a158:	0f 84 e9 01 00 00    	je     a347 <fwp_write+0x657>
    a15e:	83 c5 01             	add    $0x1,%ebp
    a161:	83 fd 12             	cmp    $0x12,%ebp
    a164:	75 ca                	jne    a130 <fwp_write+0x440>
    a166:	be 11 00 00 00       	mov    $0x11,%esi
    a16b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a16f:	4c 89 e7             	mov    %r12,%rdi
    a172:	e8 99 a5 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a177:	e9 cb 01 00 00       	jmp    a347 <fwp_write+0x657>
    a17c:	0f 1f 40 00          	nopl   0x0(%rax)
    a180:	48 83 fd 01          	cmp    $0x1,%rbp
    a184:	0f 84 e6 08 00 00    	je     aa70 <fwp_write+0xd80>
    a18a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    a18e:	b8 02 00 00 00       	mov    $0x2,%eax
    a193:	ba 01 00 00 00       	mov    $0x1,%edx
    a198:	48 0f 44 d0          	cmove  %rax,%rdx
    a19c:	48 8d 35 2a 30 00 00 	lea    0x302a(%rip),%rsi        # d1cd <_IO_stdin_used+0x1cd>
    a1a3:	48 8d 05 28 30 00 00 	lea    0x3028(%rip),%rax        # d1d2 <_IO_stdin_used+0x1d2>
    a1aa:	48 0f 44 f0          	cmove  %rax,%rsi
    a1ae:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a1b5:	00 
    a1b6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a1bd:	00 00 
    a1bf:	0f 84 3e fd ff ff    	je     9f03 <fwp_write+0x213>
    a1c5:	e8 96 92 ff ff       	call   3460 <__stack_chk_fail@plt>
    a1ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a1d0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    a1d5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    a1da:	e8 71 9f ff ff       	call   4150 <buf_grow>
    a1df:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    a1e3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    a1e9:	4c 03 0b             	add    (%rbx),%r9
    a1ec:	66 45 89 11          	mov    %r10w,(%r9)
    a1f0:	45 85 e4             	test   %r12d,%r12d
    a1f3:	0f 8e 07 05 00 00    	jle    a700 <fwp_write+0xa10>
    a1f9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    a200:	55 55 55 
    a203:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    a208:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    a20f:	aa aa aa 
    a212:	49 83 c1 01          	add    $0x1,%r9
    a216:	eb 45                	jmp    a25d <fwp_write+0x56d>
    a218:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a21f:	00 
    a220:	be 01 00 00 00       	mov    $0x1,%esi
    a225:	b8 2d 00 00 00       	mov    $0x2d,%eax
    a22a:	88 07                	mov    %al,(%rdi)
    a22c:	48 89 e8             	mov    %rbp,%rax
    a22f:	49 f7 e8             	imul   %r8
    a232:	48 89 e8             	mov    %rbp,%rax
    a235:	48 c1 f8 3f          	sar    $0x3f,%rax
    a239:	48 29 c2             	sub    %rax,%rdx
    a23c:	48 85 c9             	test   %rcx,%rcx
    a23f:	0f 95 c0             	setne  %al
    a242:	48 c1 ed 3f          	shr    $0x3f,%rbp
    a246:	48 83 ef 01          	sub    $0x1,%rdi
    a24a:	48 21 c5             	and    %rax,%rbp
    a24d:	48 29 ea             	sub    %rbp,%rdx
    a250:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    a254:	49 39 f9             	cmp    %rdi,%r9
    a257:	0f 84 a3 04 00 00    	je     a700 <fwp_write+0xa10>
    a25d:	48 89 e8             	mov    %rbp,%rax
    a260:	49 f7 e8             	imul   %r8
    a263:	48 89 e8             	mov    %rbp,%rax
    a266:	48 c1 f8 3f          	sar    $0x3f,%rax
    a26a:	48 89 d1             	mov    %rdx,%rcx
    a26d:	48 29 c1             	sub    %rax,%rcx
    a270:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a274:	48 89 e9             	mov    %rbp,%rcx
    a277:	48 29 c1             	sub    %rax,%rcx
    a27a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a27e:	49 f7 e2             	mul    %r10
    a281:	b8 30 00 00 00       	mov    $0x30,%eax
    a286:	48 89 d6             	mov    %rdx,%rsi
    a289:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a28d:	48 d1 ee             	shr    $1,%rsi
    a290:	48 01 f2             	add    %rsi,%rdx
    a293:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a297:	48 29 d6             	sub    %rdx,%rsi
    a29a:	74 8e                	je     a22a <fwp_write+0x53a>
    a29c:	48 83 fe 01          	cmp    $0x1,%rsi
    a2a0:	0f 85 7a ff ff ff    	jne    a220 <fwp_write+0x530>
    a2a6:	31 f6                	xor    %esi,%esi
    a2a8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a2ad:	e9 78 ff ff ff       	jmp    a22a <fwp_write+0x53a>
    a2b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a2b8:	66 0f 6e cd          	movd   %ebp,%xmm1
    a2bc:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a2bf:	0f 8a c8 09 00 00    	jp     ac8d <fwp_write+0xf9d>
    a2c5:	0f 28 c1             	movaps %xmm1,%xmm0
    a2c8:	0f 54 05 31 39 00 00 	andps  0x3931(%rip),%xmm0        # dc00 <msg.8+0x90>
    a2cf:	0f 2e 05 2e 2d 00 00 	ucomiss 0x2d2e(%rip),%xmm0        # d004 <_IO_stdin_used+0x4>
    a2d6:	0f 87 24 08 00 00    	ja     ab00 <fwp_write+0xe10>
    a2dc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a2e0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a2e6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a2ed:	00 
    a2ee:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a2f2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a2f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a2fe:	00 00 
    a300:	44 89 ee             	mov    %r13d,%esi
    a303:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a308:	4c 89 e7             	mov    %r12,%rdi
    a30b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a310:	e8 fb a3 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a315:	31 f6                	xor    %esi,%esi
    a317:	4c 89 e7             	mov    %r12,%rdi
    a31a:	e8 91 91 ff ff       	call   34b0 <strtof@plt>
    a31f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a324:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a327:	7a 02                	jp     a32b <fwp_write+0x63b>
    a329:	74 1c                	je     a347 <fwp_write+0x657>
    a32b:	41 83 c5 01          	add    $0x1,%r13d
    a32f:	41 83 fd 0a          	cmp    $0xa,%r13d
    a333:	75 cb                	jne    a300 <fwp_write+0x610>
    a335:	be 09 00 00 00       	mov    $0x9,%esi
    a33a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a33f:	4c 89 e7             	mov    %r12,%rdi
    a342:	e8 c9 a3 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a347:	4c 89 e7             	mov    %r12,%rdi
    a34a:	e8 31 a0 ff ff       	call   4380 <fwp_finish_float>
    a34f:	e9 1c fa ff ff       	jmp    9d70 <fwp_write+0x80>
    a354:	0f 1f 40 00          	nopl   0x0(%rax)
    a358:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a35c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a360:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a367:	00 
    a368:	48 89 ef             	mov    %rbp,%rdi
    a36b:	e8 d0 96 ff ff       	call   3a40 <fwp_fmt_u128>
    a370:	48 89 ef             	mov    %rbp,%rdi
    a373:	e8 d8 90 ff ff       	call   3450 <strlen@plt>
    a378:	48 89 ee             	mov    %rbp,%rsi
    a37b:	48 89 df             	mov    %rbx,%rdi
    a37e:	48 89 c2             	mov    %rax,%rdx
    a381:	e8 8a 9e ff ff       	call   4210 <buf_put>
    a386:	e9 fb f9 ff ff       	jmp    9d86 <fwp_write+0x96>
    a38b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a390:	ba 06 00 00 00       	mov    $0x6,%edx
    a395:	48 8d 35 86 2e 00 00 	lea    0x2e86(%rip),%rsi        # d222 <_IO_stdin_used+0x222>
    a39c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a3a2:	e8 69 9e ff ff       	call   4210 <buf_put>
    a3a7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a3ae:	ff ff 7f 
    a3b1:	48 23 55 00          	and    0x0(%rbp),%rdx
    a3b5:	0f 84 86 02 00 00    	je     a641 <fwp_write+0x951>
    a3bb:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a3c0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a3c4:	48 85 d2             	test   %rdx,%rdx
    a3c7:	0f 84 ae 00 00 00    	je     a47b <fwp_write+0x78b>
    a3cd:	8b 0a                	mov    (%rdx),%ecx
    a3cf:	83 f9 1c             	cmp    $0x1c,%ecx
    a3d2:	0f 84 58 06 00 00    	je     aa30 <fwp_write+0xd40>
    a3d8:	83 f9 1b             	cmp    $0x1b,%ecx
    a3db:	0f 87 9a 00 00 00    	ja     a47b <fwp_write+0x78b>
    a3e1:	be 01 00 00 00       	mov    $0x1,%esi
    a3e6:	48 d3 e6             	shl    %cl,%rsi
    a3e9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a3ef:	0f 85 4b 04 00 00    	jne    a840 <fwp_write+0xb50>
    a3f5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a3fb:	0f 85 0f 04 00 00    	jne    a810 <fwp_write+0xb20>
    a401:	83 e6 21             	and    $0x21,%esi
    a404:	74 75                	je     a47b <fwp_write+0x78b>
    a406:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a40b:	48 85 ff             	test   %rdi,%rdi
    a40e:	79 07                	jns    a417 <fwp_write+0x727>
    a410:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a414:	4c 01 ee             	add    %r13,%rsi
    a417:	48 0f be 3e          	movsbq (%rsi),%rdi
    a41b:	85 c9                	test   %ecx,%ecx
    a41d:	40 0f b6 f7          	movzbl %dil,%esi
    a421:	48 0f 44 f7          	cmove  %rdi,%rsi
    a425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a42c:	00 00 00 00 
    a430:	31 c9                	xor    %ecx,%ecx
    a432:	48 89 df             	mov    %rbx,%rdi
    a435:	49 83 c5 01          	add    $0x1,%r13
    a439:	e8 b2 f8 ff ff       	call   9cf0 <fwp_write>
    a43e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a445:	ff ff 7f 
    a448:	48 23 55 00          	and    0x0(%rbp),%rdx
    a44c:	49 39 d5             	cmp    %rdx,%r13
    a44f:	0f 83 ec 01 00 00    	jae    a641 <fwp_write+0x951>
    a455:	ba 02 00 00 00       	mov    $0x2,%edx
    a45a:	48 89 df             	mov    %rbx,%rdi
    a45d:	48 8d 35 bb 2d 00 00 	lea    0x2dbb(%rip),%rsi        # d21f <_IO_stdin_used+0x21f>
    a464:	e8 a7 9d ff ff       	call   4210 <buf_put>
    a469:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a46e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a472:	48 85 d2             	test   %rdx,%rdx
    a475:	0f 85 52 ff ff ff    	jne    a3cd <fwp_write+0x6dd>
    a47b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a480:	48 85 ff             	test   %rdi,%rdi
    a483:	0f 88 cf 05 00 00    	js     aa58 <fwp_write+0xd68>
    a489:	48 8b 31             	mov    (%rcx),%rsi
    a48c:	eb a2                	jmp    a430 <fwp_write+0x740>
    a48e:	66 90                	xchg   %ax,%ax
    a490:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a497:	00 
    a498:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a49f:	00 00 
    a4a1:	0f 85 1e fd ff ff    	jne    a1c5 <fwp_write+0x4d5>
    a4a7:	ba 08 00 00 00       	mov    $0x8,%edx
    a4ac:	48 8d 35 3c 2d 00 00 	lea    0x2d3c(%rip),%rsi        # d1ef <_IO_stdin_used+0x1ef>
    a4b3:	e9 4b fa ff ff       	jmp    9f03 <fwp_write+0x213>
    a4b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a4bf:	00 
    a4c0:	89 e8                	mov    %ebp,%eax
    a4c2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a4c9:	76 03                	jbe    a4ce <fwp_write+0x7de>
    a4cb:	8b 45 00             	mov    0x0(%rbp),%eax
    a4ce:	41 89 c6             	mov    %eax,%r14d
    a4d1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a4d6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a4db:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a4df:	4c 89 ef             	mov    %r13,%rdi
    a4e2:	e8 69 8f ff ff       	call   3450 <strlen@plt>
    a4e7:	4c 89 ee             	mov    %r13,%rsi
    a4ea:	48 89 df             	mov    %rbx,%rdi
    a4ed:	48 89 c2             	mov    %rax,%rdx
    a4f0:	e8 1b 9d ff ff       	call   4210 <buf_put>
    a4f5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a4fa:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a4fe:	85 f6                	test   %esi,%esi
    a500:	0f 8e 80 f8 ff ff    	jle    9d86 <fwp_write+0x96>
    a506:	45 31 ed             	xor    %r13d,%r13d
    a509:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a50e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a513:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a518:	ba 01 00 00 00       	mov    $0x1,%edx
    a51d:	4c 89 fe             	mov    %r15,%rsi
    a520:	48 89 04 24          	mov    %rax,(%rsp)
    a524:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a529:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a52d:	48 89 df             	mov    %rbx,%rdi
    a530:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a534:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a539:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a53e:	e8 cd 9c ff ff       	call   4210 <buf_put>
    a543:	41 8b 06             	mov    (%r14),%eax
    a546:	83 f8 0e             	cmp    $0xe,%eax
    a549:	0f 84 71 02 00 00    	je     a7c0 <fwp_write+0xad0>
    a54f:	83 f8 10             	cmp    $0x10,%eax
    a552:	0f 84 38 02 00 00    	je     a790 <fwp_write+0xaa0>
    a558:	83 f8 0a             	cmp    $0xa,%eax
    a55b:	0f 84 7f 04 00 00    	je     a9e0 <fwp_write+0xcf0>
    a561:	0f 8f f9 00 00 00    	jg     a660 <fwp_write+0x970>
    a567:	83 f8 03             	cmp    $0x3,%eax
    a56a:	0f 8f 50 04 00 00    	jg     a9c0 <fwp_write+0xcd0>
    a570:	85 c0                	test   %eax,%eax
    a572:	78 10                	js     a584 <fwp_write+0x894>
    a574:	48 8b 04 24          	mov    (%rsp),%rax
    a578:	48 c1 e8 3f          	shr    $0x3f,%rax
    a57c:	85 c0                	test   %eax,%eax
    a57e:	0f 85 f9 00 00 00    	jne    a67d <fwp_write+0x98d>
    a584:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a589:	48 8b 34 24          	mov    (%rsp),%rsi
    a58d:	31 c9                	xor    %ecx,%ecx
    a58f:	48 89 df             	mov    %rbx,%rdi
    a592:	e8 59 f7 ff ff       	call   9cf0 <fwp_write>
    a597:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a59c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a5a1:	49 83 c5 01          	add    $0x1,%r13
    a5a5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a5a9:	0f 8f 5f ff ff ff    	jg     a50e <fwp_write+0x81e>
    a5af:	e9 d2 f7 ff ff       	jmp    9d86 <fwp_write+0x96>
    a5b4:	0f 1f 40 00          	nopl   0x0(%rax)
    a5b8:	ba 06 00 00 00       	mov    $0x6,%edx
    a5bd:	48 8d 35 51 2c 00 00 	lea    0x2c51(%rip),%rsi        # d215 <_IO_stdin_used+0x215>
    a5c4:	45 31 ed             	xor    %r13d,%r13d
    a5c7:	e8 44 9c ff ff       	call   4210 <buf_put>
    a5cc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a5d1:	75 19                	jne    a5ec <fwp_write+0x8fc>
    a5d3:	eb 6c                	jmp    a641 <fwp_write+0x951>
    a5d5:	0f 1f 00             	nopl   (%rax)
    a5d8:	ba 02 00 00 00       	mov    $0x2,%edx
    a5dd:	48 8d 35 3b 2c 00 00 	lea    0x2c3b(%rip),%rsi        # d21f <_IO_stdin_used+0x21f>
    a5e4:	48 89 df             	mov    %rbx,%rdi
    a5e7:	e8 24 9c ff ff       	call   4210 <buf_put>
    a5ec:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a5f2:	b9 00 02 00 00       	mov    $0x200,%ecx
    a5f7:	31 c0                	xor    %eax,%eax
    a5f9:	49 83 c5 01          	add    $0x1,%r13
    a5fd:	4c 8d 05 18 2c 00 00 	lea    0x2c18(%rip),%r8        # d21c <_IO_stdin_used+0x21c>
    a604:	ba 02 00 00 00       	mov    $0x2,%edx
    a609:	be 00 02 00 00       	mov    $0x200,%esi
    a60e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a615:	00 
    a616:	e8 95 8d ff ff       	call   33b0 <__snprintf_chk@plt>
    a61b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a622:	00 
    a623:	e8 28 8e ff ff       	call   3450 <strlen@plt>
    a628:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a62f:	00 
    a630:	48 89 df             	mov    %rbx,%rdi
    a633:	48 89 c2             	mov    %rax,%rdx
    a636:	e8 d5 9b ff ff       	call   4210 <buf_put>
    a63b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a63f:	72 97                	jb     a5d8 <fwp_write+0x8e8>
    a641:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a646:	ba 01 00 00 00       	mov    $0x1,%edx
    a64b:	48 89 df             	mov    %rbx,%rdi
    a64e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a653:	e8 b8 9b ff ff       	call   4210 <buf_put>
    a658:	e9 29 f7 ff ff       	jmp    9d86 <fwp_write+0x96>
    a65d:	0f 1f 00             	nopl   (%rax)
    a660:	83 f8 0b             	cmp    $0xb,%eax
    a663:	0f 85 1b ff ff ff    	jne    a584 <fwp_write+0x894>
    a669:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a66e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a672:	83 e0 01             	and    $0x1,%eax
    a675:	85 c0                	test   %eax,%eax
    a677:	0f 84 07 ff ff ff    	je     a584 <fwp_write+0x894>
    a67d:	4c 89 fe             	mov    %r15,%rsi
    a680:	48 89 df             	mov    %rbx,%rdi
    a683:	ba 01 00 00 00       	mov    $0x1,%edx
    a688:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a68d:	e8 7e 9b ff ff       	call   4210 <buf_put>
    a692:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a697:	48 8b 34 24          	mov    (%rsp),%rsi
    a69b:	31 c9                	xor    %ecx,%ecx
    a69d:	48 89 df             	mov    %rbx,%rdi
    a6a0:	e8 4b f6 ff ff       	call   9cf0 <fwp_write>
    a6a5:	ba 01 00 00 00       	mov    $0x1,%edx
    a6aa:	4c 89 fe             	mov    %r15,%rsi
    a6ad:	48 89 df             	mov    %rbx,%rdi
    a6b0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a6b5:	e8 56 9b ff ff       	call   4210 <buf_put>
    a6ba:	e9 d8 fe ff ff       	jmp    a597 <fwp_write+0x8a7>
    a6bf:	90                   	nop
    a6c0:	ba 01 00 00 00       	mov    $0x1,%edx
    a6c5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a6ca:	48 89 df             	mov    %rbx,%rdi
    a6cd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a6d2:	e8 39 9b ff ff       	call   4210 <buf_put>
    a6d7:	e9 aa f6 ff ff       	jmp    9d86 <fwp_write+0x96>
    a6dc:	0f 1f 40 00          	nopl   0x0(%rax)
    a6e0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a6e5:	ba 01 00 00 00       	mov    $0x1,%edx
    a6ea:	48 89 df             	mov    %rbx,%rdi
    a6ed:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a6f2:	e8 19 9b ff ff       	call   4210 <buf_put>
    a6f7:	e9 8a f6 ff ff       	jmp    9d86 <fwp_write+0x96>
    a6fc:	0f 1f 40 00          	nopl   0x0(%rax)
    a700:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a704:	48 8b 13             	mov    (%rbx),%rdx
    a707:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a70c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a710:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a714:	e9 6d f6 ff ff       	jmp    9d86 <fwp_write+0x96>
    a719:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a720:	ba 02 00 00 00       	mov    $0x2,%edx
    a725:	48 8d 35 f3 2a 00 00 	lea    0x2af3(%rip),%rsi        # d21f <_IO_stdin_used+0x21f>
    a72c:	48 89 df             	mov    %rbx,%rdi
    a72f:	e8 dc 9a ff ff       	call   4210 <buf_put>
    a734:	e9 72 f8 ff ff       	jmp    9fab <fwp_write+0x2bb>
    a739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a740:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a745:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a74a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a74e:	48 89 f7             	mov    %rsi,%rdi
    a751:	48 89 34 24          	mov    %rsi,(%rsp)
    a755:	e8 f6 8c ff ff       	call   3450 <strlen@plt>
    a75a:	48 8b 34 24          	mov    (%rsp),%rsi
    a75e:	48 89 df             	mov    %rbx,%rdi
    a761:	48 89 c2             	mov    %rax,%rdx
    a764:	e8 a7 9a ff ff       	call   4210 <buf_put>
    a769:	ba 03 00 00 00       	mov    $0x3,%edx
    a76e:	48 8d 35 cd 2a 00 00 	lea    0x2acd(%rip),%rsi        # d242 <_IO_stdin_used+0x242>
    a775:	48 89 df             	mov    %rbx,%rdi
    a778:	e8 93 9a ff ff       	call   4210 <buf_put>
    a77d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a782:	e9 35 f8 ff ff       	jmp    9fbc <fwp_write+0x2cc>
    a787:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a78e:	00 00 
    a790:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a795:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a799:	48 85 ff             	test   %rdi,%rdi
    a79c:	0f 84 e2 fd ff ff    	je     a584 <fwp_write+0x894>
    a7a2:	48 8d 35 83 2a 00 00 	lea    0x2a83(%rip),%rsi        # d22c <_IO_stdin_used+0x22c>
    a7a9:	e8 82 8d ff ff       	call   3530 <strcmp@plt>
    a7ae:	85 c0                	test   %eax,%eax
    a7b0:	0f 95 c0             	setne  %al
    a7b3:	0f b6 c0             	movzbl %al,%eax
    a7b6:	e9 c1 fd ff ff       	jmp    a57c <fwp_write+0x88c>
    a7bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a7c0:	31 c0                	xor    %eax,%eax
    a7c2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a7c9:	00 
    a7ca:	0f 97 c0             	seta   %al
    a7cd:	e9 aa fd ff ff       	jmp    a57c <fwp_write+0x88c>
    a7d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a7d8:	48 89 df             	mov    %rbx,%rdi
    a7db:	ba 02 00 00 00       	mov    $0x2,%edx
    a7e0:	48 8d 35 42 2a 00 00 	lea    0x2a42(%rip),%rsi        # d229 <_IO_stdin_used+0x229>
    a7e7:	e8 24 9a ff ff       	call   4210 <buf_put>
    a7ec:	4c 89 e8             	mov    %r13,%rax
    a7ef:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a7f4:	31 c9                	xor    %ecx,%ecx
    a7f6:	48 c1 e0 04          	shl    $0x4,%rax
    a7fa:	48 89 df             	mov    %rbx,%rdi
    a7fd:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a802:	e8 e9 f4 ff ff       	call   9cf0 <fwp_write>
    a807:	e9 5e f6 ff ff       	jmp    9e6a <fwp_write+0x17a>
    a80c:	0f 1f 40 00          	nopl   0x0(%rax)
    a810:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a815:	48 85 ff             	test   %rdi,%rdi
    a818:	79 0c                	jns    a826 <fwp_write+0xb36>
    a81a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a821:	00 
    a822:	48 03 75 10          	add    0x10(%rbp),%rsi
    a826:	48 63 3e             	movslq (%rsi),%rdi
    a829:	83 f9 02             	cmp    $0x2,%ecx
    a82c:	89 fe                	mov    %edi,%esi
    a82e:	48 0f 44 f7          	cmove  %rdi,%rsi
    a832:	e9 f9 fb ff ff       	jmp    a430 <fwp_write+0x740>
    a837:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a83e:	00 00 
    a840:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a845:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a84a:	48 85 ff             	test   %rdi,%rdi
    a84d:	0f 88 0f 03 00 00    	js     ab62 <fwp_write+0xe72>
    a853:	49 0f bf 38          	movswq (%r8),%rdi
    a857:	83 f9 01             	cmp    $0x1,%ecx
    a85a:	0f b7 f7             	movzwl %di,%esi
    a85d:	48 0f 44 f7          	cmove  %rdi,%rsi
    a861:	e9 ca fb ff ff       	jmp    a430 <fwp_write+0x740>
    a866:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a86d:	00 00 00 
    a870:	ba 01 00 00 00       	mov    $0x1,%edx
    a875:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a87a:	48 83 c5 08          	add    $0x8,%rbp
    a87e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a883:	e8 88 99 ff ff       	call   4210 <buf_put>
    a888:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a88d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a892:	4d 85 ed             	test   %r13,%r13
    a895:	75 46                	jne    a8dd <fwp_write+0xbed>
    a897:	e9 04 01 00 00       	jmp    a9a0 <fwp_write+0xcb0>
    a89c:	0f 1f 40 00          	nopl   0x0(%rax)
    a8a0:	41 80 f9 09          	cmp    $0x9,%r9b
    a8a4:	0f 84 d6 00 00 00    	je     a980 <fwp_write+0xc90>
    a8aa:	41 80 f9 0a          	cmp    $0xa,%r9b
    a8ae:	0f 85 9c 00 00 00    	jne    a950 <fwp_write+0xc60>
    a8b4:	ba 02 00 00 00       	mov    $0x2,%edx
    a8b9:	48 8d 35 45 29 00 00 	lea    0x2945(%rip),%rsi        # d205 <_IO_stdin_used+0x205>
    a8c0:	48 89 df             	mov    %rbx,%rdi
    a8c3:	e8 48 99 ff ff       	call   4210 <buf_put>
    a8c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a8cf:	00 
    a8d0:	48 83 c5 01          	add    $0x1,%rbp
    a8d4:	49 39 ec             	cmp    %rbp,%r12
    a8d7:	0f 84 c3 00 00 00    	je     a9a0 <fwp_write+0xcb0>
    a8dd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a8e2:	41 80 f9 0d          	cmp    $0xd,%r9b
    a8e6:	74 28                	je     a910 <fwp_write+0xc20>
    a8e8:	7e b6                	jle    a8a0 <fwp_write+0xbb0>
    a8ea:	41 80 f9 22          	cmp    $0x22,%r9b
    a8ee:	74 40                	je     a930 <fwp_write+0xc40>
    a8f0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a8f4:	75 5a                	jne    a950 <fwp_write+0xc60>
    a8f6:	ba 02 00 00 00       	mov    $0x2,%edx
    a8fb:	48 8d 35 00 29 00 00 	lea    0x2900(%rip),%rsi        # d202 <_IO_stdin_used+0x202>
    a902:	48 89 df             	mov    %rbx,%rdi
    a905:	e8 06 99 ff ff       	call   4210 <buf_put>
    a90a:	eb c4                	jmp    a8d0 <fwp_write+0xbe0>
    a90c:	0f 1f 40 00          	nopl   0x0(%rax)
    a910:	ba 02 00 00 00       	mov    $0x2,%edx
    a915:	48 8d 35 ef 28 00 00 	lea    0x28ef(%rip),%rsi        # d20b <_IO_stdin_used+0x20b>
    a91c:	48 89 df             	mov    %rbx,%rdi
    a91f:	e8 ec 98 ff ff       	call   4210 <buf_put>
    a924:	eb aa                	jmp    a8d0 <fwp_write+0xbe0>
    a926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a92d:	00 00 00 
    a930:	ba 02 00 00 00       	mov    $0x2,%edx
    a935:	48 8d 35 c3 28 00 00 	lea    0x28c3(%rip),%rsi        # d1ff <_IO_stdin_used+0x1ff>
    a93c:	48 89 df             	mov    %rbx,%rdi
    a93f:	e8 cc 98 ff ff       	call   4210 <buf_put>
    a944:	eb 8a                	jmp    a8d0 <fwp_write+0xbe0>
    a946:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a94d:	00 00 00 
    a950:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a954:	0f 86 2e 01 00 00    	jbe    aa88 <fwp_write+0xd98>
    a95a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a95e:	0f 84 24 01 00 00    	je     aa88 <fwp_write+0xd98>
    a964:	ba 01 00 00 00       	mov    $0x1,%edx
    a969:	4c 89 fe             	mov    %r15,%rsi
    a96c:	48 89 df             	mov    %rbx,%rdi
    a96f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a974:	e8 97 98 ff ff       	call   4210 <buf_put>
    a979:	e9 52 ff ff ff       	jmp    a8d0 <fwp_write+0xbe0>
    a97e:	66 90                	xchg   %ax,%ax
    a980:	ba 02 00 00 00       	mov    $0x2,%edx
    a985:	48 8d 35 7c 28 00 00 	lea    0x287c(%rip),%rsi        # d208 <_IO_stdin_used+0x208>
    a98c:	48 89 df             	mov    %rbx,%rdi
    a98f:	e8 7c 98 ff ff       	call   4210 <buf_put>
    a994:	e9 37 ff ff ff       	jmp    a8d0 <fwp_write+0xbe0>
    a999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a9a0:	ba 01 00 00 00       	mov    $0x1,%edx
    a9a5:	4c 89 fe             	mov    %r15,%rsi
    a9a8:	48 89 df             	mov    %rbx,%rdi
    a9ab:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a9b0:	e8 5b 98 ff ff       	call   4210 <buf_put>
    a9b5:	e9 cc f3 ff ff       	jmp    9d86 <fwp_write+0x96>
    a9ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a9c0:	83 f8 04             	cmp    $0x4,%eax
    a9c3:	0f 85 bb fb ff ff    	jne    a584 <fwp_write+0x894>
    a9c9:	48 8b 04 24          	mov    (%rsp),%rax
    a9cd:	48 8b 40 08          	mov    0x8(%rax),%rax
    a9d1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    a9d6:	48 c1 e8 3f          	shr    $0x3f,%rax
    a9da:	e9 96 fc ff ff       	jmp    a675 <fwp_write+0x985>
    a9df:	90                   	nop
    a9e0:	8b 0c 24             	mov    (%rsp),%ecx
    a9e3:	31 c0                	xor    %eax,%eax
    a9e5:	85 c9                	test   %ecx,%ecx
    a9e7:	0f 98 c0             	sets   %al
    a9ea:	e9 86 fc ff ff       	jmp    a675 <fwp_write+0x985>
    a9ef:	90                   	nop
    a9f0:	48 f7 d8             	neg    %rax
    a9f3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    a9fa:	00 
    a9fb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    aa02:	2d 
    aa03:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    aa0a:	00 
    aa0b:	48 83 d2 00          	adc    $0x0,%rdx
    aa0f:	48 89 c6             	mov    %rax,%rsi
    aa12:	48 f7 da             	neg    %rdx
    aa15:	e8 26 90 ff ff       	call   3a40 <fwp_fmt_u128>
    aa1a:	e9 51 f3 ff ff       	jmp    9d70 <fwp_write+0x80>
    aa1f:	90                   	nop
    aa20:	b8 7d 00 00 00       	mov    $0x7d,%eax
    aa25:	e9 c3 f5 ff ff       	jmp    9fed <fwp_write+0x2fd>
    aa2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aa30:	4c 89 e9             	mov    %r13,%rcx
    aa33:	48 c1 e1 04          	shl    $0x4,%rcx
    aa37:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    aa3c:	48 85 ff             	test   %rdi,%rdi
    aa3f:	0f 89 eb f9 ff ff    	jns    a430 <fwp_write+0x740>
    aa45:	48 03 4d 10          	add    0x10(%rbp),%rcx
    aa49:	48 89 ce             	mov    %rcx,%rsi
    aa4c:	e9 df f9 ff ff       	jmp    a430 <fwp_write+0x740>
    aa51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa58:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    aa5f:	00 
    aa60:	48 03 4d 10          	add    0x10(%rbp),%rcx
    aa64:	e9 20 fa ff ff       	jmp    a489 <fwp_write+0x799>
    aa69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa70:	ba 02 00 00 00       	mov    $0x2,%edx
    aa75:	48 8d 35 53 27 00 00 	lea    0x2753(%rip),%rsi        # d1cf <_IO_stdin_used+0x1cf>
    aa7c:	e9 2d f7 ff ff       	jmp    a1ae <fwp_write+0x4be>
    aa81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa88:	4c 8d 05 7f 27 00 00 	lea    0x277f(%rip),%r8        # d20e <_IO_stdin_used+0x20e>
    aa8f:	b9 10 00 00 00       	mov    $0x10,%ecx
    aa94:	31 c0                	xor    %eax,%eax
    aa96:	ba 02 00 00 00       	mov    $0x2,%edx
    aa9b:	be 10 00 00 00       	mov    $0x10,%esi
    aaa0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    aaa7:	00 
    aaa8:	e8 03 89 ff ff       	call   33b0 <__snprintf_chk@plt>
    aaad:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    aab4:	00 
    aab5:	e8 96 89 ff ff       	call   3450 <strlen@plt>
    aaba:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    aac1:	00 
    aac2:	48 89 df             	mov    %rbx,%rdi
    aac5:	48 89 c2             	mov    %rax,%rdx
    aac8:	e8 43 97 ff ff       	call   4210 <buf_put>
    aacd:	e9 fe fd ff ff       	jmp    a8d0 <fwp_write+0xbe0>
    aad2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aad8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    aadc:	48 8d 35 e6 26 00 00 	lea    0x26e6(%rip),%rsi        # d1c9 <_IO_stdin_used+0x1c9>
    aae3:	48 8d 05 de 26 00 00 	lea    0x26de(%rip),%rax        # d1c8 <_IO_stdin_used+0x1c8>
    aaea:	4c 89 e7             	mov    %r12,%rdi
    aaed:	66 0f 2f c8          	comisd %xmm0,%xmm1
    aaf1:	48 0f 46 f0          	cmovbe %rax,%rsi
    aaf5:	e8 f6 88 ff ff       	call   33f0 <strcpy@plt>
    aafa:	e9 71 f2 ff ff       	jmp    9d70 <fwp_write+0x80>
    aaff:	90                   	nop
    ab00:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ab04:	48 8d 35 be 26 00 00 	lea    0x26be(%rip),%rsi        # d1c9 <_IO_stdin_used+0x1c9>
    ab0b:	48 8d 05 b6 26 00 00 	lea    0x26b6(%rip),%rax        # d1c8 <_IO_stdin_used+0x1c8>
    ab12:	0f 2f c8             	comiss %xmm0,%xmm1
    ab15:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ab1c:	00 
    ab1d:	4c 89 e7             	mov    %r12,%rdi
    ab20:	48 0f 46 f0          	cmovbe %rax,%rsi
    ab24:	e8 c7 88 ff ff       	call   33f0 <strcpy@plt>
    ab29:	e9 42 f2 ff ff       	jmp    9d70 <fwp_write+0x80>
    ab2e:	66 90                	xchg   %ax,%ax
    ab30:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    ab35:	45 85 c0             	test   %r8d,%r8d
    ab38:	75 34                	jne    ab6e <fwp_write+0xe7e>
    ab3a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    ab41:	00 
    ab42:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    ab49:	00 00 
    ab4b:	0f 85 74 f6 ff ff    	jne    a1c5 <fwp_write+0x4d5>
    ab51:	ba 02 00 00 00       	mov    $0x2,%edx
    ab56:	48 8d 35 e2 26 00 00 	lea    0x26e2(%rip),%rsi        # d23f <_IO_stdin_used+0x23f>
    ab5d:	e9 a1 f3 ff ff       	jmp    9f03 <fwp_write+0x213>
    ab62:	48 03 75 10          	add    0x10(%rbp),%rsi
    ab66:	49 89 f0             	mov    %rsi,%r8
    ab69:	e9 e5 fc ff ff       	jmp    a853 <fwp_write+0xb63>
    ab6e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    ab73:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ab78:	85 ff                	test   %edi,%edi
    ab7a:	0f 84 fa f3 ff ff    	je     9f7a <fwp_write+0x28a>
    ab80:	ba 01 00 00 00       	mov    $0x1,%edx
    ab85:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    ab8a:	48 89 df             	mov    %rbx,%rdi
    ab8d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    ab92:	e8 79 96 ff ff       	call   4210 <buf_put>
    ab97:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    ab9c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    aba1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    aba7:	85 c0                	test   %eax,%eax
    aba9:	0f 8f f0 f3 ff ff    	jg     9f9f <fwp_write+0x2af>
    abaf:	e9 34 f4 ff ff       	jmp    9fe8 <fwp_write+0x2f8>
    abb4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    abb8:	49 89 c5             	mov    %rax,%r13
    abbb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    abc0:	49 89 c4             	mov    %rax,%r12
    abc3:	49 c1 fd 3f          	sar    $0x3f,%r13
    abc7:	4c 09 e8             	or     %r13,%rax
    abca:	0f 84 a7 00 00 00    	je     ac77 <fwp_write+0xf87>
    abd0:	48 8d 2d 29 48 00 00 	lea    0x4829(%rip),%rbp        # f400 <units.5>
    abd7:	4d 89 e7             	mov    %r12,%r15
    abda:	48 8b 45 08          	mov    0x8(%rbp),%rax
    abde:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    abe3:	4c 89 ff             	mov    %r15,%rdi
    abe6:	4c 89 ee             	mov    %r13,%rsi
    abe9:	44 89 0c 24          	mov    %r9d,(%rsp)
    abed:	48 99                	cqto
    abef:	48 89 d1             	mov    %rdx,%rcx
    abf2:	48 89 c2             	mov    %rax,%rdx
    abf5:	e8 96 19 00 00       	call   c590 <__divmodti4>
    abfa:	44 8b 0c 24          	mov    (%rsp),%r9d
    abfe:	48 89 c1             	mov    %rax,%rcx
    ac01:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    ac06:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    ac0b:	0f 84 94 00 00 00    	je     aca5 <fwp_write+0xfb5>
    ac11:	41 83 c1 01          	add    $0x1,%r9d
    ac15:	48 83 c5 10          	add    $0x10,%rbp
    ac19:	41 83 f9 05          	cmp    $0x5,%r9d
    ac1d:	75 bb                	jne    abda <fwp_write+0xeea>
    ac1f:	4d 85 ed             	test   %r13,%r13
    ac22:	79 53                	jns    ac77 <fwp_write+0xf87>
    ac24:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    ac29:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    ac2e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    ac33:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ac38:	48 99                	cqto
    ac3a:	48 f7 d8             	neg    %rax
    ac3d:	48 83 d2 00          	adc    $0x0,%rdx
    ac41:	48 89 c6             	mov    %rax,%rsi
    ac44:	48 f7 da             	neg    %rdx
    ac47:	e8 f4 8d ff ff       	call   3a40 <fwp_fmt_u128>
    ac4c:	49 89 e8             	mov    %rbp,%r8
    ac4f:	ba 00 02 00 00       	mov    $0x200,%edx
    ac54:	be 02 00 00 00       	mov    $0x2,%esi
    ac59:	31 c0                	xor    %eax,%eax
    ac5b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ac62:	00 
    ac63:	48 8d 0d d0 25 00 00 	lea    0x25d0(%rip),%rcx        # d23a <_IO_stdin_used+0x23a>
    ac6a:	4c 89 e7             	mov    %r12,%rdi
    ac6d:	e8 6e 8a ff ff       	call   36e0 <__sprintf_chk@plt>
    ac72:	e9 f9 f0 ff ff       	jmp    9d70 <fwp_write+0x80>
    ac77:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ac7c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    ac81:	31 d2                	xor    %edx,%edx
    ac83:	48 89 ef             	mov    %rbp,%rdi
    ac86:	e8 b5 8d ff ff       	call   3a40 <fwp_fmt_u128>
    ac8b:	eb bf                	jmp    ac4c <fwp_write+0xf5c>
    ac8d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    ac94:	4e 61 4e 00 
    ac98:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ac9f:	00 
    aca0:	e9 cb f0 ff ff       	jmp    9d70 <fwp_write+0x80>
    aca5:	44 89 0c 24          	mov    %r9d,(%rsp)
    aca9:	48 89 c8             	mov    %rcx,%rax
    acac:	48 85 d2             	test   %rdx,%rdx
    acaf:	78 51                	js     ad02 <fwp_write+0x1012>
    acb1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    acb6:	48 89 c6             	mov    %rax,%rsi
    acb9:	48 89 ef             	mov    %rbp,%rdi
    acbc:	e8 7f 8d ff ff       	call   3a40 <fwp_fmt_u128>
    acc1:	44 8b 0c 24          	mov    (%rsp),%r9d
    acc5:	49 63 c1             	movslq %r9d,%rax
    acc8:	49 89 e8             	mov    %rbp,%r8
    accb:	ba 00 02 00 00       	mov    $0x200,%edx
    acd0:	be 02 00 00 00       	mov    $0x2,%esi
    acd5:	48 c1 e0 04          	shl    $0x4,%rax
    acd9:	48 8d 3d 20 47 00 00 	lea    0x4720(%rip),%rdi        # f400 <units.5>
    ace0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ace7:	00 
    ace8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    acec:	48 8d 0d 42 25 00 00 	lea    0x2542(%rip),%rcx        # d235 <_IO_stdin_used+0x235>
    acf3:	4c 89 e7             	mov    %r12,%rdi
    acf6:	31 c0                	xor    %eax,%eax
    acf8:	e8 e3 89 ff ff       	call   36e0 <__sprintf_chk@plt>
    acfd:	e9 6e f0 ff ff       	jmp    9d70 <fwp_write+0x80>
    ad02:	48 f7 d8             	neg    %rax
    ad05:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    ad0a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    ad0f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ad14:	48 83 d2 00          	adc    $0x0,%rdx
    ad18:	48 89 c6             	mov    %rax,%rsi
    ad1b:	48 f7 da             	neg    %rdx
    ad1e:	e8 1d 8d ff ff       	call   3a40 <fwp_fmt_u128>
    ad23:	44 8b 0c 24          	mov    (%rsp),%r9d
    ad27:	eb 9c                	jmp    acc5 <fwp_write+0xfd5>
    ad29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000ad30 <fwp_main_thread>:
    ad30:	f3 0f 1e fa          	endbr64
    ad34:	55                   	push   %rbp
    ad35:	48 89 e5             	mov    %rsp,%rbp
    ad38:	41 57                	push   %r15
    ad3a:	41 56                	push   %r14
    ad3c:	41 55                	push   %r13
    ad3e:	41 54                	push   %r12
    ad40:	53                   	push   %rbx
    ad41:	48 81 ec 78 01 00 00 	sub    $0x178,%rsp
    ad48:	44 8b 0d 55 7e 01 00 	mov    0x17e55(%rip),%r9d        # 22ba4 <fwp_heap+0x13a4>
    ad4f:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    ad56:	00 00 
    ad58:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    ad5c:	31 c0                	xor    %eax,%eax
    ad5e:	45 85 c9             	test   %r9d,%r9d
    ad61:	0f 84 42 0e 00 00    	je     bba9 <fwp_main_thread+0xe79>
    ad67:	44 8b 05 3a 7e 01 00 	mov    0x17e3a(%rip),%r8d        # 22ba8 <fwp_heap+0x13a8>
    ad6e:	45 85 c0             	test   %r8d,%r8d
    ad71:	0f 85 21 0e 00 00    	jne    bb98 <fwp_main_thread+0xe68>
    ad77:	48 8d 05 42 63 00 00 	lea    0x6342(%rip),%rax        # 110c0 <alt.9>
    ad7e:	31 f6                	xor    %esi,%esi
    ad80:	48 8d 9d d0 fe ff ff 	lea    -0x130(%rbp),%rbx
    ad87:	48 c7 05 fe 63 01 00 	movq   $0x40000000,0x163fe(%rip)        # 21190 <fwp_main_stack_size>
    ad8e:	00 00 00 40 
    ad92:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
    ad99:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
    ada0:	48 89 c7             	mov    %rax,%rdi
    ada3:	48 89 1d ee 63 01 00 	mov    %rbx,0x163ee(%rip)        # 21198 <fwp_main_stack_top>
    adaa:	48 c7 85 00 ff ff ff 	movq   $0x10000,-0x100(%rbp)
    adb1:	00 00 01 00 
    adb5:	c7 85 f8 fe ff ff 00 	movl   $0x0,-0x108(%rbp)
    adbc:	00 00 00 
    adbf:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
    adc6:	e8 f5 88 ff ff       	call   36c0 <sigaltstack@plt>
    adcb:	85 c0                	test   %eax,%eax
    adcd:	0f 85 66 17 00 00    	jne    c539 <fwp_main_thread+0x1809>
    add3:	31 c0                	xor    %eax,%eax
    add5:	b9 12 00 00 00       	mov    $0x12,%ecx
    adda:	48 8d bd 38 ff ff ff 	lea    -0xc8(%rbp),%rdi
    ade1:	f3 48 ab             	rep stos %rax,(%rdi)
    ade4:	48 8d 05 05 8f ff ff 	lea    -0x70fb(%rip),%rax        # 3cf0 <fwp_segv>
    adeb:	48 8d bd 38 ff ff ff 	lea    -0xc8(%rbp),%rdi
    adf2:	c7 45 b8 04 00 00 08 	movl   $0x8000004,-0x48(%rbp)
    adf9:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
    ae00:	4c 8d ad 30 ff ff ff 	lea    -0xd0(%rbp),%r13
    ae07:	e8 74 87 ff ff       	call   3580 <sigemptyset@plt>
    ae0c:	85 c0                	test   %eax,%eax
    ae0e:	0f 85 25 17 00 00    	jne    c539 <fwp_main_thread+0x1809>
    ae14:	31 d2                	xor    %edx,%edx
    ae16:	4c 89 ee             	mov    %r13,%rsi
    ae19:	bf 0b 00 00 00       	mov    $0xb,%edi
    ae1e:	e8 dd 85 ff ff       	call   3400 <sigaction@plt>
    ae23:	85 c0                	test   %eax,%eax
    ae25:	0f 85 0e 17 00 00    	jne    c539 <fwp_main_thread+0x1809>
    ae2b:	31 d2                	xor    %edx,%edx
    ae2d:	4c 89 ee             	mov    %r13,%rsi
    ae30:	bf 07 00 00 00       	mov    $0x7,%edi
    ae35:	e8 c6 85 ff ff       	call   3400 <sigaction@plt>
    ae3a:	85 c0                	test   %eax,%eax
    ae3c:	0f 85 f7 16 00 00    	jne    c539 <fwp_main_thread+0x1809>
    ae42:	8b 3d f0 62 01 00    	mov    0x162f0(%rip),%edi        # 21138 <descent_registered>
    ae48:	85 ff                	test   %edi,%edi
    ae4a:	0f 84 30 05 00 00    	je     b380 <fwp_main_thread+0x650>
    ae50:	8b 35 5a 62 00 00    	mov    0x625a(%rip),%esi        # 110b0 <st.7>
    ae56:	85 f6                	test   %esi,%esi
    ae58:	0f 84 4e 05 00 00    	je     b3ac <fwp_main_thread+0x67c>
    ae5e:	4c 8b 25 7b 69 01 00 	mov    0x1697b(%rip),%r12        # 217e0 <fwp_cur>
    ae65:	4d 85 e4             	test   %r12,%r12
    ae68:	0f 84 c5 01 00 00    	je     b033 <fwp_main_thread+0x303>
    ae6e:	45 0f b6 6c 24 52    	movzbl 0x52(%r12),%r13d
    ae74:	41 c6 44 24 52 01    	movb   $0x1,0x52(%r12)
    ae7a:	4c 89 e3             	mov    %r12,%rbx
    ae7d:	49 83 7c 24 28 00    	cmpq   $0x0,0x28(%r12)
    ae83:	0f 84 48 01 00 00    	je     afd1 <fwp_main_thread+0x2a1>
    ae89:	49 83 7c 24 60 00    	cmpq   $0x0,0x60(%r12)
    ae8f:	0f 84 94 02 00 00    	je     b129 <fwp_main_thread+0x3f9>
    ae95:	41 80 7c 24 51 00    	cmpb   $0x0,0x51(%r12)
    ae9b:	0f 84 6c 02 00 00    	je     b10d <fwp_main_thread+0x3dd>
    aea1:	49 8d 54 24 40       	lea    0x40(%r12),%rdx
    aea6:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    aeaa:	0f 85 fa 02 00 00    	jne    b1aa <fwp_main_thread+0x47a>
    aeb0:	48 8b 43 60          	mov    0x60(%rbx),%rax
    aeb4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    aebb:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    aec0:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    aec7:	00 00 00 00 
    aecb:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    aed2:	48 85 d2             	test   %rdx,%rdx
    aed5:	74 07                	je     aede <fwp_main_thread+0x1ae>
    aed7:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    aede:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    aee3:	48 85 c0             	test   %rax,%rax
    aee6:	74 34                	je     af1c <fwp_main_thread+0x1ec>
    aee8:	48 89 43 68          	mov    %rax,0x68(%rbx)
    aeec:	48 8b 05 c5 68 01 00 	mov    0x168c5(%rip),%rax        # 217b8 <fwp_timers>
    aef3:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    aef7:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    aefe:	00 00 00 00 
    af02:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    af09:	48 85 c0             	test   %rax,%rax
    af0c:	74 07                	je     af15 <fwp_main_thread+0x1e5>
    af0e:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    af15:	48 89 1d 9c 68 01 00 	mov    %rbx,0x1689c(%rip)        # 217b8 <fwp_timers>
    af1c:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    af20:	e8 cb c3 ff ff       	call   72f0 <fwp_block>
    af25:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    af2c:	48 85 c9             	test   %rcx,%rcx
    af2f:	74 47                	je     af78 <fwp_main_thread+0x248>
    af31:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    af38:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    af3f:	48 85 d2             	test   %rdx,%rdx
    af42:	0f 84 5a 02 00 00    	je     b1a2 <fwp_main_thread+0x472>
    af48:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    af4f:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    af56:	48 85 c0             	test   %rax,%rax
    af59:	74 07                	je     af62 <fwp_main_thread+0x232>
    af5b:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    af62:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    af69:	00 00 00 00 
    af6d:	66 0f ef d2          	pxor   %xmm2,%xmm2
    af71:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    af78:	48 8b 0d 61 68 01 00 	mov    0x16861(%rip),%rcx        # 217e0 <fwp_cur>
    af7f:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    af83:	0f 84 11 02 00 00    	je     b19a <fwp_main_thread+0x46a>
    af89:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    af90:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    af97:	48 85 d2             	test   %rdx,%rdx
    af9a:	0f 84 d4 03 00 00    	je     b374 <fwp_main_thread+0x644>
    afa0:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    afa7:	48 85 c0             	test   %rax,%rax
    afaa:	74 07                	je     afb3 <fwp_main_thread+0x283>
    afac:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    afb3:	66 0f ef db          	pxor   %xmm3,%xmm3
    afb7:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    afbb:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    afc2:	48 89 cb             	mov    %rcx,%rbx
    afc5:	49 83 7c 24 28 00    	cmpq   $0x0,0x28(%r12)
    afcb:	0f 85 b8 fe ff ff    	jne    ae89 <fwp_main_thread+0x159>
    afd1:	48 83 3d 9f 84 01 00 	cmpq   $0x0,0x1849f(%rip)        # 23478 <fwp_state_len>
    afd8:	00 
    afd9:	45 88 6c 24 52       	mov    %r13b,0x52(%r12)
    afde:	74 63                	je     b043 <fwp_main_thread+0x313>
    afe0:	48 39 1d f1 67 01 00 	cmp    %rbx,0x167f1(%rip)        # 217d8 <fwp_root>
    afe7:	c7 05 cf 60 01 00 00 	movl   $0x0,0x160cf(%rip)        # 210c0 <fwp_exit_code>
    afee:	00 00 00 
    aff1:	0f 85 93 15 00 00    	jne    c58a <fwp_main_thread+0x185a>
    aff7:	48 85 db             	test   %rbx,%rbx
    affa:	0f 84 fa 01 00 00    	je     b1fa <fwp_main_thread+0x4ca>
    b000:	48 8b 15 a1 67 01 00 	mov    0x167a1(%rip),%rdx        # 217a8 <fwp_tasks_active>
    b007:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    b00b:	48 85 d2             	test   %rdx,%rdx
    b00e:	0f 84 e6 01 00 00    	je     b1fa <fwp_main_thread+0x4ca>
    b014:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    b018:	75 08                	jne    b022 <fwp_main_thread+0x2f2>
    b01a:	48 89 d7             	mov    %rdx,%rdi
    b01d:	e8 de 92 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    b022:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    b029:	48 85 d2             	test   %rdx,%rdx
    b02c:	75 e6                	jne    b014 <fwp_main_thread+0x2e4>
    b02e:	e9 aa 00 00 00       	jmp    b0dd <fwp_main_thread+0x3ad>
    b033:	48 83 3d 3d 84 01 00 	cmpq   $0x0,0x1843d(%rip)        # 23478 <fwp_state_len>
    b03a:	00 
    b03b:	0f 85 a1 01 00 00    	jne    b1e2 <fwp_main_thread+0x4b2>
    b041:	31 db                	xor    %ebx,%ebx
    b043:	48 83 3d 1d 84 01 00 	cmpq   $0x0,0x1841d(%rip)        # 23468 <fwp_state_owners>
    b04a:	00 
    b04b:	75 93                	jne    afe0 <fwp_main_thread+0x2b0>
    b04d:	48 8b 3d 2c 84 01 00 	mov    0x1842c(%rip),%rdi        # 23480 <fwp_state>
    b054:	e8 97 a7 ff ff       	call   57f0 <fwp_mem_free>
    b059:	48 c7 05 1c 84 01 00 	movq   $0x0,0x1841c(%rip)        # 23480 <fwp_state>
    b060:	00 00 00 00 
    b064:	48 c7 05 01 84 01 00 	movq   $0x0,0x18401(%rip)        # 23470 <fwp_state_cap>
    b06b:	00 00 00 00 
    b06f:	48 85 db             	test   %rbx,%rbx
    b072:	0f 84 28 13 00 00    	je     c3a0 <fwp_main_thread+0x1670>
    b078:	48 39 1d 59 67 01 00 	cmp    %rbx,0x16759(%rip)        # 217d8 <fwp_root>
    b07f:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    b086:	00 00 00 00 
    b08a:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    b091:	00 00 00 00 
    b095:	c7 05 21 60 01 00 00 	movl   $0x0,0x16021(%rip)        # 210c0 <fwp_exit_code>
    b09c:	00 00 00 
    b09f:	0f 84 5b ff ff ff    	je     b000 <fwp_main_thread+0x2d0>
    b0a5:	e9 a6 86 ff ff       	jmp    3750 <fwp_main_thread.cold>
    b0aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b0b0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    b0b7:	48 89 1d 02 67 01 00 	mov    %rbx,0x16702(%rip)        # 217c0 <fwp_ready_tail>
    b0be:	e8 2d c2 ff ff       	call   72f0 <fwp_block>
    b0c3:	e8 28 c0 ff ff       	call   70f0 <fwp_free_zombie>
    b0c8:	48 83 3d d8 66 01 00 	cmpq   $0x0,0x166d8(%rip)        # 217a8 <fwp_tasks_active>
    b0cf:	00 
    b0d0:	0f 84 24 01 00 00    	je     b1fa <fwp_main_thread+0x4ca>
    b0d6:	48 8b 1d fb 66 01 00 	mov    0x166fb(%rip),%rbx        # 217d8 <fwp_root>
    b0dd:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    b0e1:	75 db                	jne    b0be <fwp_main_thread+0x38e>
    b0e3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    b0e7:	75 d5                	jne    b0be <fwp_main_thread+0x38e>
    b0e9:	48 8b 05 d0 66 01 00 	mov    0x166d0(%rip),%rax        # 217c0 <fwp_ready_tail>
    b0f0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    b0f4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    b0fb:	00 00 00 00 
    b0ff:	48 85 c0             	test   %rax,%rax
    b102:	75 ac                	jne    b0b0 <fwp_main_thread+0x380>
    b104:	48 89 1d bd 66 01 00 	mov    %rbx,0x166bd(%rip)        # 217c8 <fwp_ready_head>
    b10b:	eb aa                	jmp    b0b7 <fwp_main_thread+0x387>
    b10d:	e8 4e 94 ff ff       	call   4560 <fwp_now_ns>
    b112:	49 3b 44 24 60       	cmp    0x60(%r12),%rax
    b117:	7c 10                	jl     b129 <fwp_main_thread+0x3f9>
    b119:	41 80 7c 24 50 00    	cmpb   $0x0,0x50(%r12)
    b11f:	75 08                	jne    b129 <fwp_main_thread+0x3f9>
    b121:	4c 89 e7             	mov    %r12,%rdi
    b124:	e8 d7 91 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    b129:	41 80 7c 24 51 00    	cmpb   $0x0,0x51(%r12)
    b12f:	0f 85 6c fd ff ff    	jne    aea1 <fwp_main_thread+0x171>
    b135:	49 8b 44 24 60       	mov    0x60(%r12),%rax
    b13a:	49 8d 54 24 40       	lea    0x40(%r12),%rdx
    b13f:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b143:	0f 85 6b fd ff ff    	jne    aeb4 <fwp_main_thread+0x184>
    b149:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    b14d:	48 85 c9             	test   %rcx,%rcx
    b150:	0f 84 5e fd ff ff    	je     aeb4 <fwp_main_thread+0x184>
    b156:	48 85 c0             	test   %rax,%rax
    b159:	0f 84 86 13 00 00    	je     c4e5 <fwp_main_thread+0x17b5>
    b15f:	48 39 c8             	cmp    %rcx,%rax
    b162:	48 0f 4f c1          	cmovg  %rcx,%rax
    b166:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b16d:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    b172:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b179:	00 00 00 00 
    b17d:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b184:	48 85 d2             	test   %rdx,%rdx
    b187:	74 07                	je     b190 <fwp_main_thread+0x460>
    b189:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b190:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    b195:	e9 4e fd ff ff       	jmp    aee8 <fwp_main_thread+0x1b8>
    b19a:	48 89 cb             	mov    %rcx,%rbx
    b19d:	e9 db fc ff ff       	jmp    ae7d <fwp_main_thread+0x14d>
    b1a2:	48 89 01             	mov    %rax,(%rcx)
    b1a5:	e9 ac fd ff ff       	jmp    af56 <fwp_main_thread+0x226>
    b1aa:	49 8b 44 24 40       	mov    0x40(%r12),%rax
    b1af:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b1b6:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b1bd:	00 00 00 00 
    b1c1:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    b1c8:	48 85 c0             	test   %rax,%rax
    b1cb:	0f 84 43 11 00 00    	je     c314 <fwp_main_thread+0x15e4>
    b1d1:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    b1d8:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    b1dd:	e9 3a fd ff ff       	jmp    af1c <fwp_main_thread+0x1ec>
    b1e2:	48 83 3d ee 65 01 00 	cmpq   $0x0,0x165ee(%rip)        # 217d8 <fwp_root>
    b1e9:	00 
    b1ea:	c7 05 cc 5e 01 00 00 	movl   $0x0,0x15ecc(%rip)        # 210c0 <fwp_exit_code>
    b1f1:	00 00 00 
    b1f4:	0f 85 8b 13 00 00    	jne    c585 <fwp_main_thread+0x1855>
    b1fa:	e8 f1 be ff ff       	call   70f0 <fwp_free_zombie>
    b1ff:	48 83 3d c1 65 01 00 	cmpq   $0x0,0x165c1(%rip)        # 217c8 <fwp_ready_head>
    b206:	00 
    b207:	0f 85 43 85 ff ff    	jne    3750 <fwp_main_thread.cold>
    b20d:	48 83 3d a3 65 01 00 	cmpq   $0x0,0x165a3(%rip)        # 217b8 <fwp_timers>
    b214:	00 
    b215:	0f 85 35 85 ff ff    	jne    3750 <fwp_main_thread.cold>
    b21b:	8b 05 83 5f 01 00    	mov    0x15f83(%rip),%eax        # 211a4 <fwp_stack_pool_n>
    b221:	85 c0                	test   %eax,%eax
    b223:	74 37                	je     b25c <fwp_main_thread+0x52c>
    b225:	83 e8 01             	sub    $0x1,%eax
    b228:	4c 8d 2d 91 5f 01 00 	lea    0x15f91(%rip),%r13        # 211c0 <fwp_stack_pool>
    b22f:	48 63 d8             	movslq %eax,%rbx
    b232:	89 c0                	mov    %eax,%eax
    b234:	48 89 da             	mov    %rbx,%rdx
    b237:	48 29 c2             	sub    %rax,%rdx
    b23a:	4c 8d 62 ff          	lea    -0x1(%rdx),%r12
    b23e:	49 8b 7c dd 00       	mov    0x0(%r13,%rbx,8),%rdi
    b243:	89 1d 5b 5f 01 00    	mov    %ebx,0x15f5b(%rip)        # 211a4 <fwp_stack_pool_n>
    b249:	be 00 00 00 10       	mov    $0x10000000,%esi
    b24e:	48 83 eb 01          	sub    $0x1,%rbx
    b252:	e8 89 83 ff ff       	call   35e0 <munmap@plt>
    b257:	4c 39 e3             	cmp    %r12,%rbx
    b25a:	75 e2                	jne    b23e <fwp_main_thread+0x50e>
    b25c:	8b 3d c2 5d 00 00    	mov    0x5dc2(%rip),%edi        # 11024 <fwp_epfd>
    b262:	85 ff                	test   %edi,%edi
    b264:	78 05                	js     b26b <fwp_main_thread+0x53b>
    b266:	e8 65 82 ff ff       	call   34d0 <close@plt>
    b26b:	4c 8b 2d 4e 61 01 00 	mov    0x1614e(%rip),%r13        # 213c0 <fwp_nfdws>
    b272:	4c 8b 25 4f 61 01 00 	mov    0x1614f(%rip),%r12        # 213c8 <fwp_fdws>
    b279:	31 db                	xor    %ebx,%ebx
    b27b:	c7 05 9f 5d 00 00 ff 	movl   $0xffffffff,0x5d9f(%rip)        # 11024 <fwp_epfd>
    b282:	ff ff ff 
    b285:	4d 85 ed             	test   %r13,%r13
    b288:	74 2c                	je     b2b6 <fwp_main_thread+0x586>
    b28a:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b28e:	48 85 ff             	test   %rdi,%rdi
    b291:	74 1a                	je     b2ad <fwp_main_thread+0x57d>
    b293:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    b297:	0f 85 b3 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b29d:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    b2a2:	0f 85 a8 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2a8:	e8 43 a5 ff ff       	call   57f0 <fwp_mem_free>
    b2ad:	48 83 c3 01          	add    $0x1,%rbx
    b2b1:	4c 39 eb             	cmp    %r13,%rbx
    b2b4:	75 d4                	jne    b28a <fwp_main_thread+0x55a>
    b2b6:	4c 89 e7             	mov    %r12,%rdi
    b2b9:	e8 32 a5 ff ff       	call   57f0 <fwp_mem_free>
    b2be:	48 8b 15 13 65 01 00 	mov    0x16513(%rip),%rdx        # 217d8 <fwp_root>
    b2c5:	48 c7 05 f8 60 01 00 	movq   $0x0,0x160f8(%rip)        # 213c8 <fwp_fdws>
    b2cc:	00 00 00 00 
    b2d0:	48 c7 05 e5 60 01 00 	movq   $0x0,0x160e5(%rip)        # 213c0 <fwp_nfdws>
    b2d7:	00 00 00 00 
    b2db:	48 85 d2             	test   %rdx,%rdx
    b2de:	74 4e                	je     b32e <fwp_main_thread+0x5fe>
    b2e0:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    b2e5:	0f 85 65 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2eb:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    b2f2:	00 
    b2f3:	0f 85 57 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2f9:	48 83 3d 77 81 01 00 	cmpq   $0x0,0x18177(%rip)        # 23478 <fwp_state_len>
    b300:	00 
    b301:	0f 85 49 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b307:	48 83 3d 59 81 01 00 	cmpq   $0x0,0x18159(%rip)        # 23468 <fwp_state_owners>
    b30e:	00 
    b30f:	0f 85 3b 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b315:	b9 79 00 00 00       	mov    $0x79,%ecx
    b31a:	31 c0                	xor    %eax,%eax
    b31c:	48 8d 3d bd 60 01 00 	lea    0x160bd(%rip),%rdi        # 213e0 <fwp_root_context>
    b323:	f3 48 ab             	rep stos %rax,(%rdi)
    b326:	48 89 d7             	mov    %rdx,%rdi
    b329:	e8 c2 a4 ff ff       	call   57f0 <fwp_mem_free>
    b32e:	48 8b 3d 0b 5d 00 00 	mov    0x5d0b(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    b335:	48 c7 05 a0 64 01 00 	movq   $0x0,0x164a0(%rip)        # 217e0 <fwp_cur>
    b33c:	00 00 00 00 
    b340:	48 c7 05 8d 64 01 00 	movq   $0x0,0x1648d(%rip)        # 217d8 <fwp_root>
    b347:	00 00 00 00 
    b34b:	e8 70 82 ff ff       	call   35c0 <fflush@plt>
    b350:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    b354:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b35b:	00 00 
    b35d:	0f 85 d1 11 00 00    	jne    c534 <fwp_main_thread+0x1804>
    b363:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    b367:	31 c0                	xor    %eax,%eax
    b369:	5b                   	pop    %rbx
    b36a:	41 5c                	pop    %r12
    b36c:	41 5d                	pop    %r13
    b36e:	41 5e                	pop    %r14
    b370:	41 5f                	pop    %r15
    b372:	5d                   	pop    %rbp
    b373:	c3                   	ret
    b374:	48 89 05 3d 64 01 00 	mov    %rax,0x1643d(%rip)        # 217b8 <fwp_timers>
    b37b:	e9 27 fc ff ff       	jmp    afa7 <fwp_main_thread+0x277>
    b380:	48 8d 3d 89 8a ff ff 	lea    -0x7577(%rip),%rdi        # 3e10 <descent_phase_report>
    b387:	e8 14 14 00 00       	call   c7a0 <atexit>
    b38c:	85 c0                	test   %eax,%eax
    b38e:	0f 85 3d 11 00 00    	jne    c4d1 <fwp_main_thread+0x17a1>
    b394:	c7 05 9a 5d 01 00 01 	movl   $0x1,0x15d9a(%rip)        # 21138 <descent_registered>
    b39b:	00 00 00 
    b39e:	8b 35 0c 5d 00 00    	mov    0x5d0c(%rip),%esi        # 110b0 <st.7>
    b3a4:	85 f6                	test   %esi,%esi
    b3a6:	0f 85 b2 fa ff ff    	jne    ae5e <fwp_main_thread+0x12e>
    b3ac:	48 8d 05 7d b6 ff ff 	lea    -0x4983(%rip),%rax        # 6a30 <fwp_drop1>
    b3b3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b3b7:	4c 89 ad b0 fe ff ff 	mov    %r13,-0x150(%rbp)
    b3be:	4c 8b 25 1b 28 00 00 	mov    0x281b(%rip),%r12        # dbe0 <msg.8+0x70>
    b3c5:	66 48 0f 6e e0       	movq   %rax,%xmm4
    b3ca:	45 31 ff             	xor    %r15d,%r15d
    b3cd:	48 8b 05 c4 80 01 00 	mov    0x180c4(%rip),%rax        # 23498 <fwp_cleanups>
    b3d4:	48 c7 85 f0 fe ff ff 	movq   $0x0,-0x110(%rbp)
    b3db:	00 00 00 00 
    b3df:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    b3e3:	48 89 1d ae 80 01 00 	mov    %rbx,0x180ae(%rip)        # 23498 <fwp_cleanups>
    b3ea:	4c 8d 35 0f 64 01 00 	lea    0x1640f(%rip),%r14        # 21800 <fwp_heap>
    b3f1:	41 bd ff 01 00 00    	mov    $0x1ff,%r13d
    b3f7:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
    b3fe:	48 8d 05 cb 87 ff ff 	lea    -0x7835(%rip),%rax        # 3bd0 <fwp_range_release>
    b405:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
    b40c:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
    b413:	0f 29 85 00 ff ff ff 	movaps %xmm0,-0x100(%rbp)
    b41a:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
    b421:	e9 0a 01 00 00       	jmp    b530 <fwp_main_thread+0x800>
    b426:	48 8b 13             	mov    (%rbx),%rdx
    b429:	48 f7 d2             	not    %rdx
    b42c:	48 89 10             	mov    %rdx,(%rax)
    b42f:	49 83 f8 18          	cmp    $0x18,%r8
    b433:	76 29                	jbe    b45e <fwp_main_thread+0x72e>
    b435:	49 8d 40 e7          	lea    -0x19(%r8),%rax
    b439:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    b43d:	31 f6                	xor    %esi,%esi
    b43f:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    b446:	48 c1 e8 03          	shr    $0x3,%rax
    b44a:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    b451:	00 
    b452:	e8 69 80 ff ff       	call   34c0 <memset@plt>
    b457:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    b45e:	4c 89 c0             	mov    %r8,%rax
    b461:	49 03 86 20 14 00 00 	add    0x1420(%r14),%rax
    b468:	0f 82 72 10 00 00    	jb     c4e0 <fwp_main_thread+0x17b0>
    b46e:	49 89 86 20 14 00 00 	mov    %rax,0x1420(%r14)
    b475:	49 39 86 28 14 00 00 	cmp    %rax,0x1428(%r14)
    b47c:	73 07                	jae    b485 <fwp_main_thread+0x755>
    b47e:	49 89 86 28 14 00 00 	mov    %rax,0x1428(%r14)
    b485:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b489:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    b48e:	f2 41 0f 58 86 38 14 	addsd  0x1438(%r14),%xmm0
    b495:	00 00 
    b497:	f2 41 0f 11 86 38 14 	movsd  %xmm0,0x1438(%r14)
    b49e:	00 00 
    b4a0:	4c 89 7b 10          	mov    %r15,0x10(%rbx)
    b4a4:	48 89 d8             	mov    %rbx,%rax
    b4a7:	49 89 df             	mov    %rbx,%r15
    b4aa:	4c 89 23             	mov    %r12,(%rbx)
    b4ad:	4c 89 6b 08          	mov    %r13,0x8(%rbx)
    b4b1:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b4b8:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b4bf:	48 c1 e2 10          	shl    $0x10,%rdx
    b4c3:	48 39 d0             	cmp    %rdx,%rax
    b4c6:	73 57                	jae    b51f <fwp_main_thread+0x7ef>
    b4c8:	48 89 c2             	mov    %rax,%rdx
    b4cb:	48 c1 ea 10          	shr    $0x10,%rdx
    b4cf:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    b4d3:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b4da:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    b4de:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    b4e2:	48 85 d2             	test   %rdx,%rdx
    b4e5:	74 38                	je     b51f <fwp_main_thread+0x7ef>
    b4e7:	0f b6 3e             	movzbl (%rsi),%edi
    b4ea:	40 80 ff 02          	cmp    $0x2,%dil
    b4ee:	0f 84 a8 00 00 00    	je     b59c <fwp_main_thread+0x86c>
    b4f4:	40 80 ff 01          	cmp    $0x1,%dil
    b4f8:	75 25                	jne    b51f <fwp_main_thread+0x7ef>
    b4fa:	8b 7e 18             	mov    0x18(%rsi),%edi
    b4fd:	0f b7 c0             	movzwl %ax,%eax
    b500:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b503:	48 0f af c7          	imul   %rdi,%rax
    b507:	48 c1 e8 20          	shr    $0x20,%rax
    b50b:	48 39 f0             	cmp    %rsi,%rax
    b50e:	73 0f                	jae    b51f <fwp_main_thread+0x7ef>
    b510:	48 01 c2             	add    %rax,%rdx
    b513:	80 3a ff             	cmpb   $0xff,(%rdx)
    b516:	0f 84 4e 0e 00 00    	je     c36a <fwp_main_thread+0x163a>
    b51c:	c6 02 01             	movb   $0x1,(%rdx)
    b51f:	48 89 9d f0 fe ff ff 	mov    %rbx,-0x110(%rbp)
    b526:	49 83 ed 01          	sub    $0x1,%r13
    b52a:	0f 82 86 00 00 00    	jb     b5b6 <fwp_main_thread+0x886>
    b530:	41 8b 8e a4 13 00 00 	mov    0x13a4(%r14),%ecx
    b537:	4c 89 ad f8 fe ff ff 	mov    %r13,-0x108(%rbp)
    b53e:	85 c9                	test   %ecx,%ecx
    b540:	74 46                	je     b588 <fwp_main_thread+0x858>
    b542:	41 0f b6 86 a2 0f 00 	movzbl 0xfa2(%r14),%eax
    b549:	00 
    b54a:	45 8b 84 86 00 0f 00 	mov    0xf00(%r14,%rax,4),%r8d
    b551:	00 
    b552:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    b556:	49 8d 04 c6          	lea    (%r14,%rax,8),%rax
    b55a:	48 8b 18             	mov    (%rax),%rbx
    b55d:	48 85 db             	test   %rbx,%rbx
    b560:	0f 85 c0 fe ff ff    	jne    b426 <fwp_main_thread+0x6f6>
    b566:	48 8b 58 08          	mov    0x8(%rax),%rbx
    b56a:	48 85 db             	test   %rbx,%rbx
    b56d:	74 19                	je     b588 <fwp_main_thread+0x858>
    b56f:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b573:	48 29 da             	sub    %rbx,%rdx
    b576:	4c 39 c2             	cmp    %r8,%rdx
    b579:	72 0d                	jb     b588 <fwp_main_thread+0x858>
    b57b:	4a 8d 14 03          	lea    (%rbx,%r8,1),%rdx
    b57f:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b583:	e9 a7 fe ff ff       	jmp    b42f <fwp_main_thread+0x6ff>
    b588:	31 f6                	xor    %esi,%esi
    b58a:	bf 18 00 00 00       	mov    $0x18,%edi
    b58f:	e8 5c a7 ff ff       	call   5cf0 <fwp_heap_alloc>
    b594:	48 89 c3             	mov    %rax,%rbx
    b597:	e9 04 ff ff ff       	jmp    b4a0 <fwp_main_thread+0x770>
    b59c:	66 85 c0             	test   %ax,%ax
    b59f:	0f 84 6e ff ff ff    	je     b513 <fwp_main_thread+0x7e3>
    b5a5:	48 89 9d f0 fe ff ff 	mov    %rbx,-0x110(%rbp)
    b5ac:	49 83 ed 01          	sub    $0x1,%r13
    b5b0:	0f 83 7a ff ff ff    	jae    b530 <fwp_main_thread+0x800>
    b5b6:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
    b5bd:	66 0f 6f 05 5b 26 00 	movdqa 0x265b(%rip),%xmm0        # dc20 <msg.8+0xb0>
    b5c4:	00 
    b5c5:	bf 01 00 00 00       	mov    $0x1,%edi
    b5ca:	48 89 9d b8 fe ff ff 	mov    %rbx,-0x148(%rbp)
    b5d1:	48 8b b5 b0 fe ff ff 	mov    -0x150(%rbp),%rsi
    b5d8:	48 89 05 b9 7e 01 00 	mov    %rax,0x17eb9(%rip)        # 23498 <fwp_cleanups>
    b5df:	0f 29 85 30 ff ff ff 	movaps %xmm0,-0xd0(%rbp)
    b5e6:	e8 05 b0 ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    b5eb:	48 8b 15 e6 75 01 00 	mov    0x175e6(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    b5f2:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    b5f9:	49 89 c5             	mov    %rax,%r13
    b5fc:	48 2b 05 ad 75 01 00 	sub    0x175ad(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    b603:	48 c1 e2 10          	shl    $0x10,%rdx
    b607:	48 39 d0             	cmp    %rdx,%rax
    b60a:	73 55                	jae    b661 <fwp_main_thread+0x931>
    b60c:	48 89 c2             	mov    %rax,%rdx
    b60f:	48 c1 ea 10          	shr    $0x10,%rdx
    b613:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b617:	48 8b 15 da 75 01 00 	mov    0x175da(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    b61e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b622:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    b626:	48 85 db             	test   %rbx,%rbx
    b629:	74 36                	je     b661 <fwp_main_thread+0x931>
    b62b:	0f b6 0a             	movzbl (%rdx),%ecx
    b62e:	80 f9 02             	cmp    $0x2,%cl
    b631:	0f 84 09 0d 00 00    	je     c340 <fwp_main_thread+0x1610>
    b637:	80 f9 01             	cmp    $0x1,%cl
    b63a:	75 25                	jne    b661 <fwp_main_thread+0x931>
    b63c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b63f:	0f b7 c0             	movzwl %ax,%eax
    b642:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b645:	48 0f af c1          	imul   %rcx,%rax
    b649:	48 c1 e8 20          	shr    $0x20,%rax
    b64d:	48 39 d0             	cmp    %rdx,%rax
    b650:	73 0f                	jae    b661 <fwp_main_thread+0x931>
    b652:	48 01 c3             	add    %rax,%rbx
    b655:	80 3b ff             	cmpb   $0xff,(%rbx)
    b658:	0f 84 18 0e 00 00    	je     c476 <fwp_main_thread+0x1746>
    b65e:	c6 03 01             	movb   $0x1,(%rbx)
    b661:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b668:	00 f0 3f 
    b66b:	48 8d b5 20 ff ff ff 	lea    -0xe0(%rbp),%rsi
    b672:	bf 01 00 00 00       	mov    $0x1,%edi
    b677:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    b67e:	4c 89 ad 28 ff ff ff 	mov    %r13,-0xd8(%rbp)
    b685:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
    b68c:	e8 5f af ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    b691:	48 8b 15 40 75 01 00 	mov    0x17540(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    b698:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    b69f:	49 89 c5             	mov    %rax,%r13
    b6a2:	48 2b 05 07 75 01 00 	sub    0x17507(%rip),%rax        # 22bb0 <fwp_heap+0x13b0>
    b6a9:	48 c1 e2 10          	shl    $0x10,%rdx
    b6ad:	48 39 d0             	cmp    %rdx,%rax
    b6b0:	73 55                	jae    b707 <fwp_main_thread+0x9d7>
    b6b2:	48 89 c2             	mov    %rax,%rdx
    b6b5:	48 c1 ea 10          	shr    $0x10,%rdx
    b6b9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b6bd:	48 8b 15 34 75 01 00 	mov    0x17534(%rip),%rdx        # 22bf8 <fwp_heap+0x13f8>
    b6c4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b6c8:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    b6cc:	48 85 db             	test   %rbx,%rbx
    b6cf:	74 36                	je     b707 <fwp_main_thread+0x9d7>
    b6d1:	0f b6 0a             	movzbl (%rdx),%ecx
    b6d4:	80 f9 02             	cmp    $0x2,%cl
    b6d7:	0f 84 55 0c 00 00    	je     c332 <fwp_main_thread+0x1602>
    b6dd:	80 f9 01             	cmp    $0x1,%cl
    b6e0:	75 25                	jne    b707 <fwp_main_thread+0x9d7>
    b6e2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b6e5:	0f b7 c0             	movzwl %ax,%eax
    b6e8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b6eb:	48 0f af c1          	imul   %rcx,%rax
    b6ef:	48 c1 e8 20          	shr    $0x20,%rax
    b6f3:	48 39 d0             	cmp    %rdx,%rax
    b6f6:	73 0f                	jae    b707 <fwp_main_thread+0x9d7>
    b6f8:	48 01 c3             	add    %rax,%rbx
    b6fb:	80 3b ff             	cmpb   $0xff,(%rbx)
    b6fe:	0f 84 8d 0d 00 00    	je     c491 <fwp_main_thread+0x1761>
    b704:	c6 03 01             	movb   $0x1,(%rbx)
    b707:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b70e:	33 f3 bf 
    b711:	48 8d b5 10 ff ff ff 	lea    -0xf0(%rbp),%rsi
    b718:	bf 01 00 00 00       	mov    $0x1,%edi
    b71d:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    b724:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
    b72b:	4c 89 ad 18 ff ff ff 	mov    %r13,-0xe8(%rbp)
    b732:	e8 b9 ae ff ff       	call   65f0 <fwp_data.part.0.constprop.0>
    b737:	48 8b 15 9a 74 01 00 	mov    0x1749a(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    b73e:	48 8b 0d 6b 74 01 00 	mov    0x1746b(%rip),%rcx        # 22bb0 <fwp_heap+0x13b0>
    b745:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
    b74c:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    b753:	48 89 d6             	mov    %rdx,%rsi
    b756:	48 29 c8             	sub    %rcx,%rax
    b759:	48 c1 e6 10          	shl    $0x10,%rsi
    b75d:	48 39 f0             	cmp    %rsi,%rax
    b760:	73 65                	jae    b7c7 <fwp_main_thread+0xa97>
    b762:	48 89 c6             	mov    %rax,%rsi
    b765:	48 c1 ee 10          	shr    $0x10,%rsi
    b769:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    b76d:	48 8b 35 84 74 01 00 	mov    0x17484(%rip),%rsi        # 22bf8 <fwp_heap+0x13f8>
    b774:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b778:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    b77c:	48 85 db             	test   %rbx,%rbx
    b77f:	74 46                	je     b7c7 <fwp_main_thread+0xa97>
    b781:	0f b6 3e             	movzbl (%rsi),%edi
    b784:	40 80 ff 02          	cmp    $0x2,%dil
    b788:	0f 84 ce 0b 00 00    	je     c35c <fwp_main_thread+0x162c>
    b78e:	40 80 ff 01          	cmp    $0x1,%dil
    b792:	75 33                	jne    b7c7 <fwp_main_thread+0xa97>
    b794:	8b 7e 18             	mov    0x18(%rsi),%edi
    b797:	0f b7 c0             	movzwl %ax,%eax
    b79a:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b79d:	48 0f af c7          	imul   %rdi,%rax
    b7a1:	48 c1 e8 20          	shr    $0x20,%rax
    b7a5:	48 39 f0             	cmp    %rsi,%rax
    b7a8:	73 1d                	jae    b7c7 <fwp_main_thread+0xa97>
    b7aa:	48 01 c3             	add    %rax,%rbx
    b7ad:	80 3b ff             	cmpb   $0xff,(%rbx)
    b7b0:	0f 84 f6 0c 00 00    	je     c4ac <fwp_main_thread+0x177c>
    b7b6:	c6 03 01             	movb   $0x1,(%rbx)
    b7b9:	48 8b 0d f0 73 01 00 	mov    0x173f0(%rip),%rcx        # 22bb0 <fwp_heap+0x13b0>
    b7c0:	48 8b 15 11 74 01 00 	mov    0x17411(%rip),%rdx        # 22bd8 <fwp_heap+0x13d8>
    b7c7:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
    b7ce:	4c 89 85 68 fe ff ff 	mov    %r8,-0x198(%rbp)
    b7d5:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
    b7dc:	4c 89 85 60 fe ff ff 	mov    %r8,-0x1a0(%rbp)
    b7e3:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
    b7ea:	48 c1 e2 10          	shl    $0x10,%rdx
    b7ee:	48 29 c8             	sub    %rcx,%rax
    b7f1:	48 39 d0             	cmp    %rdx,%rax
    b7f4:	73 5d                	jae    b853 <fwp_main_thread+0xb23>
    b7f6:	48 89 c2             	mov    %rax,%rdx
    b7f9:	48 c1 ea 10          	shr    $0x10,%rdx
    b7fd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b801:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b808:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b80c:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    b810:	48 85 ff             	test   %rdi,%rdi
    b813:	74 3e                	je     b853 <fwp_main_thread+0xb23>
    b815:	0f b6 0a             	movzbl (%rdx),%ecx
    b818:	80 f9 02             	cmp    $0x2,%cl
    b81b:	0f 84 2d 0b 00 00    	je     c34e <fwp_main_thread+0x161e>
    b821:	80 f9 01             	cmp    $0x1,%cl
    b824:	75 2d                	jne    b853 <fwp_main_thread+0xb23>
    b826:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b829:	0f b7 c0             	movzwl %ax,%eax
    b82c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b82f:	48 0f af c1          	imul   %rcx,%rax
    b833:	48 c1 e8 20          	shr    $0x20,%rax
    b837:	48 39 d0             	cmp    %rdx,%rax
    b83a:	73 17                	jae    b853 <fwp_main_thread+0xb23>
    b83c:	48 01 c7             	add    %rax,%rdi
    b83f:	0f b6 07             	movzbl (%rdi),%eax
    b842:	84 c0                	test   %al,%al
    b844:	74 0d                	je     b853 <fwp_main_thread+0xb23>
    b846:	3c fd                	cmp    $0xfd,%al
    b848:	0f 87 79 0c 00 00    	ja     c4c7 <fwp_main_thread+0x1797>
    b84e:	83 c0 01             	add    $0x1,%eax
    b851:	88 07                	mov    %al,(%rdi)
    b853:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
    b85a:	48 8b 15 f7 7b 01 00 	mov    0x17bf7(%rip),%rdx        # 23458 <fwp_fns>
    b861:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
    b868:	48 8d 05 a9 57 00 00 	lea    0x57a9(%rip),%rax        # 11018 <fc12>
    b86f:	44 8b 28             	mov    (%rax),%r13d
    b872:	49 c1 e5 05          	shl    $0x5,%r13
    b876:	49 01 d5             	add    %rdx,%r13
    b879:	49 8b 4d 18          	mov    0x18(%r13),%rcx
    b87d:	48 85 c9             	test   %rcx,%rcx
    b880:	0f 84 6a 0c 00 00    	je     c4f0 <fwp_main_thread+0x17c0>
    b886:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    b88b:	0f 84 ff 08 00 00    	je     c190 <fwp_main_thread+0x1460>
    b891:	49 8b 8e d8 13 00 00 	mov    0x13d8(%r14),%rcx
    b898:	48 8d 05 79 57 00 00 	lea    0x5779(%rip),%rax        # 11018 <fc12>
    b89f:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b8a6:	48 c1 e1 10          	shl    $0x10,%rcx
    b8aa:	48 39 c8             	cmp    %rcx,%rax
    b8ad:	73 5f                	jae    b90e <fwp_main_thread+0xbde>
    b8af:	48 89 c1             	mov    %rax,%rcx
    b8b2:	48 c1 e9 10          	shr    $0x10,%rcx
    b8b6:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b8ba:	49 8b 8e f8 13 00 00 	mov    0x13f8(%r14),%rcx
    b8c1:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b8c5:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    b8c9:	48 85 ff             	test   %rdi,%rdi
    b8cc:	74 40                	je     b90e <fwp_main_thread+0xbde>
    b8ce:	0f b6 31             	movzbl (%rcx),%esi
    b8d1:	40 80 fe 02          	cmp    $0x2,%sil
    b8d5:	0f 84 92 09 00 00    	je     c26d <fwp_main_thread+0x153d>
    b8db:	40 80 fe 01          	cmp    $0x1,%sil
    b8df:	75 2d                	jne    b90e <fwp_main_thread+0xbde>
    b8e1:	8b 71 18             	mov    0x18(%rcx),%esi
    b8e4:	0f b7 c0             	movzwl %ax,%eax
    b8e7:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b8ea:	48 0f af c6          	imul   %rsi,%rax
    b8ee:	48 c1 e8 20          	shr    $0x20,%rax
    b8f2:	48 39 c8             	cmp    %rcx,%rax
    b8f5:	73 17                	jae    b90e <fwp_main_thread+0xbde>
    b8f7:	48 01 c7             	add    %rax,%rdi
    b8fa:	0f b6 07             	movzbl (%rdi),%eax
    b8fd:	84 c0                	test   %al,%al
    b8ff:	74 0d                	je     b90e <fwp_main_thread+0xbde>
    b901:	3c fd                	cmp    $0xfd,%al
    b903:	0f 87 fa 09 00 00    	ja     c303 <fwp_main_thread+0x15d3>
    b909:	83 c0 01             	add    $0x1,%eax
    b90c:	88 07                	mov    %al,(%rdi)
    b90e:	48 8b 9d 80 fe ff ff 	mov    -0x180(%rbp),%rbx
    b915:	4c 8d 3d fc 56 00 00 	lea    0x56fc(%rip),%r15        # 11018 <fc12>
    b91c:	c7 85 9c fe ff ff 01 	movl   $0x1,-0x164(%rbp)
    b923:	00 00 00 
    b926:	4c 89 f8             	mov    %r15,%rax
    b929:	48 89 9d a0 fe ff ff 	mov    %rbx,-0x160(%rbp)
    b930:	8b 9d 9c fe ff ff    	mov    -0x164(%rbp),%ebx
    b936:	41 8b 4d 00          	mov    0x0(%r13),%ecx
    b93a:	4d 89 fa             	mov    %r15,%r10
    b93d:	2b 48 04             	sub    0x4(%rax),%ecx
    b940:	41 8b 07             	mov    (%r15),%eax
    b943:	39 d9                	cmp    %ebx,%ecx
    b945:	4c 8b ad a0 fe ff ff 	mov    -0x160(%rbp),%r13
    b94c:	41 89 cc             	mov    %ecx,%r12d
    b94f:	0f 46 d9             	cmovbe %ecx,%ebx
    b952:	48 c1 e0 05          	shl    $0x5,%rax
    b956:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    b95a:	4c 89 f8             	mov    %r15,%rax
    b95d:	49 8b 50 18          	mov    0x18(%r8),%rdx
    b961:	89 9d 8c fe ff ff    	mov    %ebx,-0x174(%rbp)
    b967:	89 9d b8 fe ff ff    	mov    %ebx,-0x148(%rbp)
    b96d:	48 85 d2             	test   %rdx,%rdx
    b970:	0f 84 61 02 00 00    	je     bbd7 <fwp_main_thread+0xea7>
    b976:	89 8d 88 fe ff ff    	mov    %ecx,-0x178(%rbp)
    b97c:	eb 66                	jmp    b9e4 <fwp_main_thread+0xcb4>
    b97e:	66 90                	xchg   %ax,%ax
    b980:	85 db                	test   %ebx,%ebx
    b982:	0f 84 87 00 00 00    	je     ba0f <fwp_main_thread+0xcdf>
    b988:	4c 89 ef             	mov    %r13,%rdi
    b98b:	ff 12                	call   *(%rdx)
    b98d:	4c 89 ff             	mov    %r15,%rdi
    b990:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
    b997:	e8 f4 b1 ff ff       	call   6b90 <fwp_closure_drop>
    b99c:	44 3b a5 b8 fe ff ff 	cmp    -0x148(%rbp),%r12d
    b9a3:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
    b9aa:	0f 84 d0 07 00 00    	je     c180 <fwp_main_thread+0x1450>
    b9b0:	8b 95 98 fe ff ff    	mov    -0x168(%rbp),%edx
    b9b6:	44 8b 00             	mov    (%rax),%r8d
    b9b9:	4f 8d 6c e5 00       	lea    0x0(%r13,%r12,8),%r13
    b9be:	49 89 c2             	mov    %rax,%r10
    b9c1:	29 da                	sub    %ebx,%edx
    b9c3:	49 c1 e0 05          	shl    $0x5,%r8
    b9c7:	4c 03 05 8a 7a 01 00 	add    0x17a8a(%rip),%r8        # 23458 <fwp_fns>
    b9ce:	89 95 b8 fe ff ff    	mov    %edx,-0x148(%rbp)
    b9d4:	49 8b 50 18          	mov    0x18(%r8),%rdx
    b9d8:	48 85 d2             	test   %rdx,%rdx
    b9db:	0f 84 ef 01 00 00    	je     bbd0 <fwp_main_thread+0xea0>
    b9e1:	49 89 c7             	mov    %rax,%r15
    b9e4:	41 8b 4a 04          	mov    0x4(%r10),%ecx
    b9e8:	8b 85 b8 fe ff ff    	mov    -0x148(%rbp),%eax
    b9ee:	41 8b 18             	mov    (%r8),%ebx
    b9f1:	01 c8                	add    %ecx,%eax
    b9f3:	89 85 98 fe ff ff    	mov    %eax,-0x168(%rbp)
    b9f9:	39 d8                	cmp    %ebx,%eax
    b9fb:	0f 82 cf 04 00 00    	jb     bed0 <fwp_main_thread+0x11a0>
    ba01:	41 89 dc             	mov    %ebx,%r12d
    ba04:	41 29 cc             	sub    %ecx,%r12d
    ba07:	85 c9                	test   %ecx,%ecx
    ba09:	0f 84 71 ff ff ff    	je     b980 <fwp_main_thread+0xc50>
    ba0f:	85 db                	test   %ebx,%ebx
    ba11:	b8 01 00 00 00       	mov    $0x1,%eax
    ba16:	48 89 e6             	mov    %rsp,%rsi
    ba19:	48 89 a5 b0 fe ff ff 	mov    %rsp,-0x150(%rbp)
    ba20:	0f 45 c3             	cmovne %ebx,%eax
    ba23:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    ba2a:	00 
    ba2b:	48 c1 e8 04          	shr    $0x4,%rax
    ba2f:	48 c1 e0 04          	shl    $0x4,%rax
    ba33:	48 89 c7             	mov    %rax,%rdi
    ba36:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    ba3d:	48 29 fe             	sub    %rdi,%rsi
    ba40:	48 39 f4             	cmp    %rsi,%rsp
    ba43:	74 15                	je     ba5a <fwp_main_thread+0xd2a>
    ba45:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    ba4c:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    ba53:	00 00 
    ba55:	48 39 f4             	cmp    %rsi,%rsp
    ba58:	75 eb                	jne    ba45 <fwp_main_thread+0xd15>
    ba5a:	25 ff 0f 00 00       	and    $0xfff,%eax
    ba5f:	48 29 c4             	sub    %rax,%rsp
    ba62:	48 85 c0             	test   %rax,%rax
    ba65:	74 06                	je     ba6d <fwp_main_thread+0xd3d>
    ba67:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    ba6d:	89 c8                	mov    %ecx,%eax
    ba6f:	48 89 a5 a8 fe ff ff 	mov    %rsp,-0x158(%rbp)
    ba76:	48 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%rsi
    ba7d:	00 
    ba7e:	31 c0                	xor    %eax,%eax
    ba80:	85 c9                	test   %ecx,%ecx
    ba82:	74 35                	je     bab9 <fwp_main_thread+0xd89>
    ba84:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ba8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ba91:	00 00 00 00 
    ba95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ba9c:	00 00 00 00 
    baa0:	49 8b 7c 02 08       	mov    0x8(%r10,%rax,1),%rdi
    baa5:	4c 8b 9d a8 fe ff ff 	mov    -0x158(%rbp),%r11
    baac:	49 89 3c 03          	mov    %rdi,(%r11,%rax,1)
    bab0:	48 83 c0 08          	add    $0x8,%rax
    bab4:	48 39 c6             	cmp    %rax,%rsi
    bab7:	75 e7                	jne    baa0 <fwp_main_thread+0xd70>
    bab9:	45 85 e4             	test   %r12d,%r12d
    babc:	74 3e                	je     bafc <fwp_main_thread+0xdcc>
    babe:	44 89 e0             	mov    %r12d,%eax
    bac1:	4c 89 ee             	mov    %r13,%rsi
    bac4:	49 8d 44 c5 00       	lea    0x0(%r13,%rax,8),%rax
    bac9:	90                   	nop
    baca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bad1:	00 00 00 00 
    bad5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    badc:	00 00 00 00 
    bae0:	4c 8b 0e             	mov    (%rsi),%r9
    bae3:	4c 8b 9d a8 fe ff ff 	mov    -0x158(%rbp),%r11
    baea:	89 cf                	mov    %ecx,%edi
    baec:	48 83 c6 08          	add    $0x8,%rsi
    baf0:	83 c1 01             	add    $0x1,%ecx
    baf3:	4d 89 0c fb          	mov    %r9,(%r11,%rdi,8)
    baf7:	48 39 f0             	cmp    %rsi,%rax
    bafa:	75 e4                	jne    bae0 <fwp_main_thread+0xdb0>
    bafc:	49 8b 8e d8 13 00 00 	mov    0x13d8(%r14),%rcx
    bb03:	4c 89 f8             	mov    %r15,%rax
    bb06:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    bb0d:	48 c1 e1 10          	shl    $0x10,%rcx
    bb11:	48 39 c8             	cmp    %rcx,%rax
    bb14:	73 50                	jae    bb66 <fwp_main_thread+0xe36>
    bb16:	48 89 c1             	mov    %rax,%rcx
    bb19:	48 c1 e9 10          	shr    $0x10,%rcx
    bb1d:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    bb21:	49 8b 8e f8 13 00 00 	mov    0x13f8(%r14),%rcx
    bb28:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    bb2c:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    bb30:	48 85 f6             	test   %rsi,%rsi
    bb33:	74 31                	je     bb66 <fwp_main_thread+0xe36>
    bb35:	0f b6 39             	movzbl (%rcx),%edi
    bb38:	40 80 ff 02          	cmp    $0x2,%dil
    bb3c:	0f 84 86 00 00 00    	je     bbc8 <fwp_main_thread+0xe98>
    bb42:	40 80 ff 01          	cmp    $0x1,%dil
    bb46:	75 1e                	jne    bb66 <fwp_main_thread+0xe36>
    bb48:	8b 79 18             	mov    0x18(%rcx),%edi
    bb4b:	0f b7 c0             	movzwl %ax,%eax
    bb4e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    bb51:	48 0f af c7          	imul   %rdi,%rax
    bb55:	48 c1 e8 20          	shr    $0x20,%rax
    bb59:	48 39 c8             	cmp    %rcx,%rax
    bb5c:	73 08                	jae    bb66 <fwp_main_thread+0xe36>
    bb5e:	48 01 c6             	add    %rax,%rsi
    bb61:	80 3e 01             	cmpb   $0x1,(%rsi)
    bb64:	74 52                	je     bbb8 <fwp_main_thread+0xe88>
    bb66:	4c 89 85 90 fe ff ff 	mov    %r8,-0x170(%rbp)
    bb6d:	be 01 00 00 00       	mov    $0x1,%esi
    bb72:	4c 89 ff             	mov    %r15,%rdi
    bb75:	ff 52 08             	call   *0x8(%rdx)
    bb78:	4c 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%r8
    bb7f:	49 8b 40 18          	mov    0x18(%r8),%rax
    bb83:	48 8b bd a8 fe ff ff 	mov    -0x158(%rbp),%rdi
    bb8a:	ff 10                	call   *(%rax)
    bb8c:	48 8b a5 b0 fe ff ff 	mov    -0x150(%rbp),%rsp
    bb93:	e9 f5 fd ff ff       	jmp    b98d <fwp_main_thread+0xc5d>
    bb98:	48 8d 3d c1 90 ff ff 	lea    -0x6f3f(%rip),%rdi        # 4c60 <fwp_heap_report>
    bb9f:	e8 fc 0b 00 00       	call   c7a0 <atexit>
    bba4:	e9 ce f1 ff ff       	jmp    ad77 <fwp_main_thread+0x47>
    bba9:	e8 c2 91 ff ff       	call   4d70 <fwp_heap_init>
    bbae:	e9 b4 f1 ff ff       	jmp    ad67 <fwp_main_thread+0x37>
    bbb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    bbb8:	41 c7 42 04 00 00 00 	movl   $0x0,0x4(%r10)
    bbbf:	00 
    bbc0:	eb bd                	jmp    bb7f <fwp_main_thread+0xe4f>
    bbc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bbc8:	66 85 c0             	test   %ax,%ax
    bbcb:	75 99                	jne    bb66 <fwp_main_thread+0xe36>
    bbcd:	eb 92                	jmp    bb61 <fwp_main_thread+0xe31>
    bbcf:	90                   	nop
    bbd0:	44 8b a5 88 fe ff ff 	mov    -0x178(%rbp),%r12d
    bbd7:	48 89 c7             	mov    %rax,%rdi
    bbda:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
    bbe1:	e8 3a ab ff ff       	call   6720 <fwp_rc_share>
    bbe6:	8b 95 b8 fe ff ff    	mov    -0x148(%rbp),%edx
    bbec:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
    bbf3:	85 d2                	test   %edx,%edx
    bbf5:	74 35                	je     bc2c <fwp_main_thread+0xefc>
    bbf7:	89 d1                	mov    %edx,%ecx
    bbf9:	44 89 a5 b0 fe ff ff 	mov    %r12d,-0x150(%rbp)
    bc00:	49 89 c7             	mov    %rax,%r15
    bc03:	4d 89 ec             	mov    %r13,%r12
    bc06:	49 8d 5c cd 00       	lea    0x0(%r13,%rcx,8),%rbx
    bc0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    bc10:	49 8b 3c 24          	mov    (%r12),%rdi
    bc14:	49 83 c4 08          	add    $0x8,%r12
    bc18:	e8 03 ab ff ff       	call   6720 <fwp_rc_share>
    bc1d:	4c 39 e3             	cmp    %r12,%rbx
    bc20:	75 ee                	jne    bc10 <fwp_main_thread+0xee0>
    bc22:	44 8b a5 b0 fe ff ff 	mov    -0x150(%rbp),%r12d
    bc29:	4c 89 f8             	mov    %r15,%rax
    bc2c:	8b b5 b8 fe ff ff    	mov    -0x148(%rbp),%esi
    bc32:	4c 89 ea             	mov    %r13,%rdx
    bc35:	48 89 c7             	mov    %rax,%rdi
    bc38:	e8 d3 a1 ff ff       	call   5e10 <fwp_apply>
    bc3d:	49 89 c7             	mov    %rax,%r15
    bc40:	8b bd 9c fe ff ff    	mov    -0x164(%rbp),%edi
    bc46:	41 39 fc             	cmp    %edi,%r12d
    bc49:	0f 83 8c 00 00 00    	jae    bcdb <fwp_main_thread+0xfab>
    bc4f:	48 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%rdx
    bc56:	8b 85 8c fe ff ff    	mov    -0x174(%rbp),%eax
    bc5c:	45 8b 2f             	mov    (%r15),%r13d
    bc5f:	48 89 c6             	mov    %rax,%rsi
    bc62:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    bc66:	48 8b 15 eb 77 01 00 	mov    0x177eb(%rip),%rdx        # 23458 <fwp_fns>
    bc6d:	49 c1 e5 05          	shl    $0x5,%r13
    bc71:	29 f7                	sub    %esi,%edi
    bc73:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
    bc7a:	4c 89 f8             	mov    %r15,%rax
    bc7d:	49 01 d5             	add    %rdx,%r13
    bc80:	89 bd 9c fe ff ff    	mov    %edi,-0x164(%rbp)
    bc86:	49 83 7d 18 00       	cmpq   $0x0,0x18(%r13)
    bc8b:	0f 85 9f fc ff ff    	jne    b930 <fwp_main_thread+0xc00>
    bc91:	4c 89 ff             	mov    %r15,%rdi
    bc94:	e8 87 aa ff ff       	call   6720 <fwp_rc_share>
    bc99:	44 8b a5 9c fe ff ff 	mov    -0x164(%rbp),%r12d
    bca0:	45 85 e4             	test   %r12d,%r12d
    bca3:	74 1e                	je     bcc3 <fwp_main_thread+0xf93>
    bca5:	4c 8b ad a0 fe ff ff 	mov    -0x160(%rbp),%r13
    bcac:	31 db                	xor    %ebx,%ebx
    bcae:	66 90                	xchg   %ax,%ax
    bcb0:	49 8b 7c dd 00       	mov    0x0(%r13,%rbx,8),%rdi
    bcb5:	48 83 c3 01          	add    $0x1,%rbx
    bcb9:	e8 62 aa ff ff       	call   6720 <fwp_rc_share>
    bcbe:	44 39 e3             	cmp    %r12d,%ebx
    bcc1:	72 ed                	jb     bcb0 <fwp_main_thread+0xf80>
    bcc3:	48 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%rdx
    bcca:	8b b5 9c fe ff ff    	mov    -0x164(%rbp),%esi
    bcd0:	4c 89 ff             	mov    %r15,%rdi
    bcd3:	e8 38 a1 ff ff       	call   5e10 <fwp_apply>
    bcd8:	49 89 c7             	mov    %rax,%r15
    bcdb:	48 8b bd 78 fe ff ff 	mov    -0x188(%rbp),%rdi
    bce2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    bce6:	b9 01 00 00 00       	mov    $0x1,%ecx
    bceb:	4c 89 fe             	mov    %r15,%rsi
    bcee:	48 8d 15 8b 4e 00 00 	lea    0x4e8b(%rip),%rdx        # 10b80 <d0>
    bcf5:	0f 29 85 f0 fe ff ff 	movaps %xmm0,-0x110(%rbp)
    bcfc:	48 c7 85 00 ff ff ff 	movq   $0x0,-0x100(%rbp)
    bd03:	00 00 00 00 
    bd07:	e8 e4 df ff ff       	call   9cf0 <fwp_write>
    bd0c:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
    bd13:	4c 8b ad f8 fe ff ff 	mov    -0x108(%rbp),%r13
    bd1a:	48 8d 05 70 13 00 00 	lea    0x1370(%rip),%rax        # d091 <_IO_stdin_used+0x91>
    bd21:	48 85 c9             	test   %rcx,%rcx
    bd24:	48 0f 44 c8          	cmove  %rax,%rcx
    bd28:	49 83 fd f6          	cmp    $0xfffffffffffffff6,%r13
    bd2c:	0f 87 f6 07 00 00    	ja     c528 <fwp_main_thread+0x17f8>
    bd32:	49 8d 7d 09          	lea    0x9(%r13),%rdi
    bd36:	be 01 00 00 00       	mov    $0x1,%esi
    bd3b:	48 89 8d b8 fe ff ff 	mov    %rcx,-0x148(%rbp)
    bd42:	e8 a9 9f ff ff       	call   5cf0 <fwp_heap_alloc>
    bd47:	48 8b b5 b8 fe ff ff 	mov    -0x148(%rbp),%rsi
    bd4e:	4c 89 ea             	mov    %r13,%rdx
    bd51:	4c 89 28             	mov    %r13,(%rax)
    bd54:	4c 8d 60 08          	lea    0x8(%rax),%r12
    bd58:	48 89 c3             	mov    %rax,%rbx
    bd5b:	4c 89 e7             	mov    %r12,%rdi
    bd5e:	e8 3d 78 ff ff       	call   35a0 <memcpy@plt>
    bd63:	42 c6 44 2b 08 00    	movb   $0x0,0x8(%rbx,%r13,1)
    bd69:	48 8b bd f0 fe ff ff 	mov    -0x110(%rbp),%rdi
    bd70:	e8 4b 76 ff ff       	call   33c0 <free@plt>
    bd75:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    bd7c:	48 89 d8             	mov    %rbx,%rax
    bd7f:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    bd86:	48 c1 e2 10          	shl    $0x10,%rdx
    bd8a:	48 39 d0             	cmp    %rdx,%rax
    bd8d:	73 57                	jae    bde6 <fwp_main_thread+0x10b6>
    bd8f:	48 89 c2             	mov    %rax,%rdx
    bd92:	48 c1 ea 10          	shr    $0x10,%rdx
    bd96:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bd9a:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    bda1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    bda5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    bda9:	48 85 d2             	test   %rdx,%rdx
    bdac:	74 38                	je     bde6 <fwp_main_thread+0x10b6>
    bdae:	0f b6 31             	movzbl (%rcx),%esi
    bdb1:	40 80 fe 02          	cmp    $0x2,%sil
    bdb5:	0f 84 ad 06 00 00    	je     c468 <fwp_main_thread+0x1738>
    bdbb:	40 80 fe 01          	cmp    $0x1,%sil
    bdbf:	75 25                	jne    bde6 <fwp_main_thread+0x10b6>
    bdc1:	8b 71 18             	mov    0x18(%rcx),%esi
    bdc4:	0f b7 c0             	movzwl %ax,%eax
    bdc7:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    bdca:	48 0f af c6          	imul   %rsi,%rax
    bdce:	48 c1 e8 20          	shr    $0x20,%rax
    bdd2:	48 39 c8             	cmp    %rcx,%rax
    bdd5:	73 0f                	jae    bde6 <fwp_main_thread+0x10b6>
    bdd7:	48 01 c2             	add    %rax,%rdx
    bdda:	80 3a ff             	cmpb   $0xff,(%rdx)
    bddd:	0f 84 58 06 00 00    	je     c43b <fwp_main_thread+0x170b>
    bde3:	c6 02 01             	movb   $0x1,(%rdx)
    bde6:	4c 89 ff             	mov    %r15,%rdi
    bde9:	e8 c2 aa ff ff       	call   68b0 <fwp_drop0>
    bdee:	48 8b 13             	mov    (%rbx),%rdx
    bdf1:	be 01 00 00 00       	mov    $0x1,%esi
    bdf6:	4c 89 e7             	mov    %r12,%rdi
    bdf9:	48 8b 0d 60 76 01 00 	mov    0x17660(%rip),%rcx        # 23460 <fwp_prog_out>
    be00:	e8 7b 78 ff ff       	call   3680 <fwrite@plt>
    be05:	48 8b 35 54 76 01 00 	mov    0x17654(%rip),%rsi        # 23460 <fwp_prog_out>
    be0c:	bf 0a 00 00 00       	mov    $0xa,%edi
    be11:	e8 ca 76 ff ff       	call   34e0 <fputc@plt>
    be16:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    be1d:	48 89 d8             	mov    %rbx,%rax
    be20:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    be27:	48 c1 e2 10          	shl    $0x10,%rdx
    be2b:	48 39 d0             	cmp    %rdx,%rax
    be2e:	73 69                	jae    be99 <fwp_main_thread+0x1169>
    be30:	48 89 c2             	mov    %rax,%rdx
    be33:	48 c1 ea 10          	shr    $0x10,%rdx
    be37:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    be3b:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    be42:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    be46:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    be4a:	4d 85 ed             	test   %r13,%r13
    be4d:	74 4a                	je     be99 <fwp_main_thread+0x1169>
    be4f:	0f b6 0a             	movzbl (%rdx),%ecx
    be52:	80 f9 02             	cmp    $0x2,%cl
    be55:	0f 84 37 05 00 00    	je     c392 <fwp_main_thread+0x1662>
    be5b:	80 f9 01             	cmp    $0x1,%cl
    be5e:	75 39                	jne    be99 <fwp_main_thread+0x1169>
    be60:	8b 4a 18             	mov    0x18(%rdx),%ecx
    be63:	0f b7 c0             	movzwl %ax,%eax
    be66:	8b 52 1c             	mov    0x1c(%rdx),%edx
    be69:	48 0f af c1          	imul   %rcx,%rax
    be6d:	48 c1 e8 20          	shr    $0x20,%rax
    be71:	48 39 d0             	cmp    %rdx,%rax
    be74:	73 23                	jae    be99 <fwp_main_thread+0x1169>
    be76:	49 01 c5             	add    %rax,%r13
    be79:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
    be7e:	84 c0                	test   %al,%al
    be80:	74 17                	je     be99 <fwp_main_thread+0x1169>
    be82:	3c 01                	cmp    $0x1,%al
    be84:	0f 84 fb 04 00 00    	je     c385 <fwp_main_thread+0x1655>
    be8a:	3c ff                	cmp    $0xff,%al
    be8c:	0f 84 2e 05 00 00    	je     c3c0 <fwp_main_thread+0x1690>
    be92:	83 e8 01             	sub    $0x1,%eax
    be95:	41 88 45 00          	mov    %al,0x0(%r13)
    be99:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
    bea0:	48 8b 40 10          	mov    0x10(%rax),%rax
    bea4:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
    beab:	48 85 c0             	test   %rax,%rax
    beae:	0f 84 91 06 00 00    	je     c545 <fwp_main_thread+0x1815>
    beb4:	49 8b 8e b0 13 00 00 	mov    0x13b0(%r14),%rcx
    bebb:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    bec2:	e9 1c f9 ff ff       	jmp    b7e3 <fwp_main_thread+0xab3>
    bec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    bece:	00 00 
    bed0:	41 8b 96 a4 13 00 00 	mov    0x13a4(%r14),%edx
    bed7:	8d 70 01             	lea    0x1(%rax),%esi
    beda:	44 8b a5 88 fe ff ff 	mov    -0x178(%rbp),%r12d
    bee1:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    bee8:	00 
    bee9:	85 d2                	test   %edx,%edx
    beeb:	0f 84 ac 03 00 00    	je     c29d <fwp_main_thread+0x156d>
    bef1:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    bef8:	0f 87 9f 03 00 00    	ja     c29d <fwp_main_thread+0x156d>
    befe:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    bf02:	48 c1 e8 04          	shr    $0x4,%rax
    bf06:	41 0f b6 94 06 a0 0f 	movzbl 0xfa0(%r14,%rax,1),%edx
    bf0d:	00 00 
    bf0f:	41 8b 84 96 00 0f 00 	mov    0xf00(%r14,%rdx,4),%eax
    bf16:	00 
    bf17:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    bf1b:	49 8d 14 d6          	lea    (%r14,%rdx,8),%rdx
    bf1f:	48 8b 1a             	mov    (%rdx),%rbx
    bf22:	48 85 db             	test   %rbx,%rbx
    bf25:	0f 84 50 03 00 00    	je     c27b <fwp_main_thread+0x154b>
    bf2b:	4c 8b 1b             	mov    (%rbx),%r11
    bf2e:	49 f7 d3             	not    %r11
    bf31:	4c 89 1a             	mov    %r11,(%rdx)
    bf34:	48 39 c7             	cmp    %rax,%rdi
    bf37:	73 61                	jae    bf9a <fwp_main_thread+0x126a>
    bf39:	48 89 fa             	mov    %rdi,%rdx
    bf3c:	48 83 c7 08          	add    $0x8,%rdi
    bf40:	48 c7 04 f3 00 00 00 	movq   $0x0,(%rbx,%rsi,8)
    bf47:	00 
    bf48:	48 f7 d2             	not    %rdx
    bf4b:	48 01 c2             	add    %rax,%rdx
    bf4e:	48 c1 ea 03          	shr    $0x3,%rdx
    bf52:	48 39 c7             	cmp    %rax,%rdi
    bf55:	73 43                	jae    bf9a <fwp_main_thread+0x126a>
    bf57:	83 e2 01             	and    $0x1,%edx
    bf5a:	74 24                	je     bf80 <fwp_main_thread+0x1250>
    bf5c:	48 c7 04 3b 00 00 00 	movq   $0x0,(%rbx,%rdi,1)
    bf63:	00 
    bf64:	48 83 c7 08          	add    $0x8,%rdi
    bf68:	48 39 c7             	cmp    %rax,%rdi
    bf6b:	73 2d                	jae    bf9a <fwp_main_thread+0x126a>
    bf6d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    bf74:	00 
    bf75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bf7c:	00 00 00 00 
    bf80:	48 c7 04 3b 00 00 00 	movq   $0x0,(%rbx,%rdi,1)
    bf87:	00 
    bf88:	48 c7 44 3b 08 00 00 	movq   $0x0,0x8(%rbx,%rdi,1)
    bf8f:	00 00 
    bf91:	48 83 c7 10          	add    $0x10,%rdi
    bf95:	48 39 c7             	cmp    %rax,%rdi
    bf98:	72 e6                	jb     bf80 <fwp_main_thread+0x1250>
    bf9a:	48 89 c2             	mov    %rax,%rdx
    bf9d:	49 03 96 20 14 00 00 	add    0x1420(%r14),%rdx
    bfa4:	0f 82 36 05 00 00    	jb     c4e0 <fwp_main_thread+0x17b0>
    bfaa:	49 89 96 20 14 00 00 	mov    %rdx,0x1420(%r14)
    bfb1:	49 39 96 28 14 00 00 	cmp    %rdx,0x1428(%r14)
    bfb8:	73 07                	jae    bfc1 <fwp_main_thread+0x1291>
    bfba:	49 89 96 28 14 00 00 	mov    %rdx,0x1428(%r14)
    bfc1:	66 0f ef c0          	pxor   %xmm0,%xmm0
    bfc5:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    bfca:	f2 41 0f 58 86 38 14 	addsd  0x1438(%r14),%xmm0
    bfd1:	00 00 
    bfd3:	f2 41 0f 11 86 38 14 	movsd  %xmm0,0x1438(%r14)
    bfda:	00 00 
    bfdc:	66 41 0f 6e 02       	movd   (%r10),%xmm0
    bfe1:	66 0f 6e 8d 98 fe ff 	movd   -0x168(%rbp),%xmm1
    bfe8:	ff 
    bfe9:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    bfed:	66 0f d6 03          	movq   %xmm0,(%rbx)
    bff1:	85 c9                	test   %ecx,%ecx
    bff3:	74 3b                	je     c030 <fwp_main_thread+0x1300>
    bff5:	89 ca                	mov    %ecx,%edx
    bff7:	49 8d 72 08          	lea    0x8(%r10),%rsi
    bffb:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    bfff:	89 8d a8 fe ff ff    	mov    %ecx,-0x158(%rbp)
    c005:	48 c1 e2 03          	shl    $0x3,%rdx
    c009:	4c 89 85 90 fe ff ff 	mov    %r8,-0x170(%rbp)
    c010:	4c 89 95 b0 fe ff ff 	mov    %r10,-0x150(%rbp)
    c017:	e8 f4 75 ff ff       	call   3610 <memmove@plt>
    c01c:	4c 8b 95 b0 fe ff ff 	mov    -0x150(%rbp),%r10
    c023:	8b 8d a8 fe ff ff    	mov    -0x158(%rbp),%ecx
    c029:	4c 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%r8
    c030:	8b 85 b8 fe ff ff    	mov    -0x148(%rbp),%eax
    c036:	85 c0                	test   %eax,%eax
    c038:	74 3c                	je     c076 <fwp_main_thread+0x1346>
    c03a:	8b 95 b8 fe ff ff    	mov    -0x148(%rbp),%edx
    c040:	4c 89 e8             	mov    %r13,%rax
    c043:	49 8d 7c d5 00       	lea    0x0(%r13,%rdx,8),%rdi
    c048:	66 90                	xchg   %ax,%ax
    c04a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    c051:	00 00 00 00 
    c055:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    c05c:	00 00 00 00 
    c060:	48 8b 30             	mov    (%rax),%rsi
    c063:	89 ca                	mov    %ecx,%edx
    c065:	48 83 c0 08          	add    $0x8,%rax
    c069:	83 c1 01             	add    $0x1,%ecx
    c06c:	48 89 74 d3 08       	mov    %rsi,0x8(%rbx,%rdx,8)
    c071:	48 39 c7             	cmp    %rax,%rdi
    c074:	75 ea                	jne    c060 <fwp_main_thread+0x1330>
    c076:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    c07d:	4c 89 f8             	mov    %r15,%rax
    c080:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    c087:	48 c1 e2 10          	shl    $0x10,%rdx
    c08b:	48 39 d0             	cmp    %rdx,%rax
    c08e:	73 54                	jae    c0e4 <fwp_main_thread+0x13b4>
    c090:	48 89 c2             	mov    %rax,%rdx
    c093:	48 c1 ea 10          	shr    $0x10,%rdx
    c097:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c09b:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    c0a2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c0a6:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    c0aa:	48 85 c9             	test   %rcx,%rcx
    c0ad:	74 35                	je     c0e4 <fwp_main_thread+0x13b4>
    c0af:	0f b6 32             	movzbl (%rdx),%esi
    c0b2:	40 80 fe 02          	cmp    $0x2,%sil
    c0b6:	0f 84 39 02 00 00    	je     c2f5 <fwp_main_thread+0x15c5>
    c0bc:	40 80 fe 01          	cmp    $0x1,%sil
    c0c0:	75 22                	jne    c0e4 <fwp_main_thread+0x13b4>
    c0c2:	8b 72 18             	mov    0x18(%rdx),%esi
    c0c5:	0f b7 c0             	movzwl %ax,%eax
    c0c8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c0cb:	48 0f af c6          	imul   %rsi,%rax
    c0cf:	48 c1 e8 20          	shr    $0x20,%rax
    c0d3:	48 39 d0             	cmp    %rdx,%rax
    c0d6:	73 0c                	jae    c0e4 <fwp_main_thread+0x13b4>
    c0d8:	48 01 c1             	add    %rax,%rcx
    c0db:	80 39 01             	cmpb   $0x1,(%rcx)
    c0de:	0f 84 7c 01 00 00    	je     c260 <fwp_main_thread+0x1530>
    c0e4:	49 8b 40 18          	mov    0x18(%r8),%rax
    c0e8:	be 01 00 00 00       	mov    $0x1,%esi
    c0ed:	4c 89 ff             	mov    %r15,%rdi
    c0f0:	ff 50 08             	call   *0x8(%rax)
    c0f3:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    c0fa:	48 89 d8             	mov    %rbx,%rax
    c0fd:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    c104:	48 c1 e2 10          	shl    $0x10,%rdx
    c108:	48 39 d0             	cmp    %rdx,%rax
    c10b:	73 5b                	jae    c168 <fwp_main_thread+0x1438>
    c10d:	48 89 c2             	mov    %rax,%rdx
    c110:	48 c1 ea 10          	shr    $0x10,%rdx
    c114:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c118:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    c11f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    c123:	4c 8b 69 20          	mov    0x20(%rcx),%r13
    c127:	4d 85 ed             	test   %r13,%r13
    c12a:	74 3c                	je     c168 <fwp_main_thread+0x1438>
    c12c:	0f b6 31             	movzbl (%rcx),%esi
    c12f:	40 80 fe 02          	cmp    $0x2,%sil
    c133:	0f 84 9b 01 00 00    	je     c2d4 <fwp_main_thread+0x15a4>
    c139:	40 80 fe 01          	cmp    $0x1,%sil
    c13d:	75 29                	jne    c168 <fwp_main_thread+0x1438>
    c13f:	8b 71 18             	mov    0x18(%rcx),%esi
    c142:	0f b7 c0             	movzwl %ax,%eax
    c145:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    c148:	48 0f af c6          	imul   %rsi,%rax
    c14c:	48 c1 e8 20          	shr    $0x20,%rax
    c150:	48 39 c8             	cmp    %rcx,%rax
    c153:	73 13                	jae    c168 <fwp_main_thread+0x1438>
    c155:	49 01 c5             	add    %rax,%r13
    c158:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    c15d:	0f 84 85 01 00 00    	je     c2e8 <fwp_main_thread+0x15b8>
    c163:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    c168:	4c 89 ff             	mov    %r15,%rdi
    c16b:	49 89 df             	mov    %rbx,%r15
    c16e:	e8 1d aa ff ff       	call   6b90 <fwp_closure_drop>
    c173:	e9 c8 fa ff ff       	jmp    bc40 <fwp_main_thread+0xf10>
    c178:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    c17f:	00 
    c180:	44 8b a5 88 fe ff ff 	mov    -0x178(%rbp),%r12d
    c187:	49 89 c7             	mov    %rax,%r15
    c18a:	e9 b1 fa ff ff       	jmp    bc40 <fwp_main_thread+0xf10>
    c18f:	90                   	nop
    c190:	41 8b 75 00          	mov    0x0(%r13),%esi
    c194:	8b 05 82 4e 00 00    	mov    0x4e82(%rip),%eax        # 1101c <fc12+0x4>
    c19a:	89 f7                	mov    %esi,%edi
    c19c:	29 c7                	sub    %eax,%edi
    c19e:	83 ff 01             	cmp    $0x1,%edi
    c1a1:	0f 85 ea f6 ff ff    	jne    b891 <fwp_main_thread+0xb61>
    c1a7:	48 89 e3             	mov    %rsp,%rbx
    c1aa:	85 c0                	test   %eax,%eax
    c1ac:	0f 84 6c 01 00 00    	je     c31e <fwp_main_thread+0x15ee>
    c1b2:	89 f1                	mov    %esi,%ecx
    c1b4:	ba 08 00 00 00       	mov    $0x8,%edx
    c1b9:	48 c1 e1 03          	shl    $0x3,%rcx
    c1bd:	85 f6                	test   %esi,%esi
    c1bf:	48 89 e6             	mov    %rsp,%rsi
    c1c2:	48 0f 45 d1          	cmovne %rcx,%rdx
    c1c6:	49 89 d7             	mov    %rdx,%r15
    c1c9:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    c1cd:	48 c1 ea 04          	shr    $0x4,%rdx
    c1d1:	48 c1 e2 04          	shl    $0x4,%rdx
    c1d5:	48 89 d7             	mov    %rdx,%rdi
    c1d8:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    c1df:	48 29 fe             	sub    %rdi,%rsi
    c1e2:	48 39 f4             	cmp    %rsi,%rsp
    c1e5:	74 15                	je     c1fc <fwp_main_thread+0x14cc>
    c1e7:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    c1ee:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    c1f5:	00 00 
    c1f7:	48 39 f4             	cmp    %rsi,%rsp
    c1fa:	75 eb                	jne    c1e7 <fwp_main_thread+0x14b7>
    c1fc:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    c202:	48 29 d4             	sub    %rdx,%rsp
    c205:	48 85 d2             	test   %rdx,%rdx
    c208:	74 06                	je     c210 <fwp_main_thread+0x14e0>
    c20a:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    c210:	4c 8d 24 c5 00 00 00 	lea    0x0(,%rax,8),%r12
    c217:	00 
    c218:	4c 89 f9             	mov    %r15,%rcx
    c21b:	48 8d 35 fe 4d 00 00 	lea    0x4dfe(%rip),%rsi        # 11020 <descent_active_phase>
    c222:	48 89 e7             	mov    %rsp,%rdi
    c225:	4c 89 e2             	mov    %r12,%rdx
    c228:	e8 43 73 ff ff       	call   3570 <__memcpy_chk@plt>
    c22d:	4d 39 e7             	cmp    %r12,%r15
    c230:	4c 89 f9             	mov    %r15,%rcx
    c233:	4a 8d 3c 24          	lea    (%rsp,%r12,1),%rdi
    c237:	49 0f 42 cc          	cmovb  %r12,%rcx
    c23b:	48 8b b5 80 fe ff ff 	mov    -0x180(%rbp),%rsi
    c242:	ba 08 00 00 00       	mov    $0x8,%edx
    c247:	4c 29 e1             	sub    %r12,%rcx
    c24a:	e8 21 73 ff ff       	call   3570 <__memcpy_chk@plt>
    c24f:	49 8b 45 18          	mov    0x18(%r13),%rax
    c253:	48 89 e7             	mov    %rsp,%rdi
    c256:	ff 10                	call   *(%rax)
    c258:	49 89 c7             	mov    %rax,%r15
    c25b:	e9 ca 00 00 00       	jmp    c32a <fwp_main_thread+0x15fa>
    c260:	41 c7 42 04 00 00 00 	movl   $0x0,0x4(%r10)
    c267:	00 
    c268:	e9 86 fe ff ff       	jmp    c0f3 <fwp_main_thread+0x13c3>
    c26d:	66 85 c0             	test   %ax,%ax
    c270:	0f 85 98 f6 ff ff    	jne    b90e <fwp_main_thread+0xbde>
    c276:	e9 7f f6 ff ff       	jmp    b8fa <fwp_main_thread+0xbca>
    c27b:	48 8b 5a 08          	mov    0x8(%rdx),%rbx
    c27f:	48 85 db             	test   %rbx,%rbx
    c282:	74 19                	je     c29d <fwp_main_thread+0x156d>
    c284:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
    c288:	49 29 db             	sub    %rbx,%r11
    c28b:	49 39 c3             	cmp    %rax,%r11
    c28e:	72 0d                	jb     c29d <fwp_main_thread+0x156d>
    c290:	4c 8d 1c 03          	lea    (%rbx,%rax,1),%r11
    c294:	4c 89 5a 08          	mov    %r11,0x8(%rdx)
    c298:	e9 97 fc ff ff       	jmp    bf34 <fwp_main_thread+0x1204>
    c29d:	31 f6                	xor    %esi,%esi
    c29f:	89 8d 90 fe ff ff    	mov    %ecx,-0x170(%rbp)
    c2a5:	4c 89 85 a8 fe ff ff 	mov    %r8,-0x158(%rbp)
    c2ac:	4c 89 95 b0 fe ff ff 	mov    %r10,-0x150(%rbp)
    c2b3:	e8 38 9a ff ff       	call   5cf0 <fwp_heap_alloc>
    c2b8:	8b 8d 90 fe ff ff    	mov    -0x170(%rbp),%ecx
    c2be:	4c 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%r8
    c2c5:	4c 8b 95 b0 fe ff ff 	mov    -0x150(%rbp),%r10
    c2cc:	48 89 c3             	mov    %rax,%rbx
    c2cf:	e9 08 fd ff ff       	jmp    bfdc <fwp_main_thread+0x12ac>
    c2d4:	66 85 c0             	test   %ax,%ax
    c2d7:	0f 85 8b fe ff ff    	jne    c168 <fwp_main_thread+0x1438>
    c2dd:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    c2e2:	0f 85 7b fe ff ff    	jne    c163 <fwp_main_thread+0x1433>
    c2e8:	4c 89 ef             	mov    %r13,%rdi
    c2eb:	e8 c0 92 ff ff       	call   55b0 <fwp_rc_forget_slot>
    c2f0:	e9 6e fe ff ff       	jmp    c163 <fwp_main_thread+0x1433>
    c2f5:	66 85 c0             	test   %ax,%ax
    c2f8:	0f 85 e6 fd ff ff    	jne    c0e4 <fwp_main_thread+0x13b4>
    c2fe:	e9 d8 fd ff ff       	jmp    c0db <fwp_main_thread+0x13ab>
    c303:	e8 88 91 ff ff       	call   5490 <fwp_rc_wide_dup>
    c308:	48 8b 15 49 71 01 00 	mov    0x17149(%rip),%rdx        # 23458 <fwp_fns>
    c30f:	e9 fa f5 ff ff       	jmp    b90e <fwp_main_thread+0xbde>
    c314:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    c319:	e9 fe eb ff ff       	jmp    af1c <fwp_main_thread+0x1ec>
    c31e:	48 8b bd 80 fe ff ff 	mov    -0x180(%rbp),%rdi
    c325:	ff 11                	call   *(%rcx)
    c327:	49 89 c7             	mov    %rax,%r15
    c32a:	48 89 dc             	mov    %rbx,%rsp
    c32d:	e9 a9 f9 ff ff       	jmp    bcdb <fwp_main_thread+0xfab>
    c332:	66 85 c0             	test   %ax,%ax
    c335:	0f 85 cc f3 ff ff    	jne    b707 <fwp_main_thread+0x9d7>
    c33b:	e9 bb f3 ff ff       	jmp    b6fb <fwp_main_thread+0x9cb>
    c340:	66 85 c0             	test   %ax,%ax
    c343:	0f 85 18 f3 ff ff    	jne    b661 <fwp_main_thread+0x931>
    c349:	e9 07 f3 ff ff       	jmp    b655 <fwp_main_thread+0x925>
    c34e:	66 85 c0             	test   %ax,%ax
    c351:	0f 85 fc f4 ff ff    	jne    b853 <fwp_main_thread+0xb23>
    c357:	e9 e3 f4 ff ff       	jmp    b83f <fwp_main_thread+0xb0f>
    c35c:	66 85 c0             	test   %ax,%ax
    c35f:	0f 85 62 f4 ff ff    	jne    b7c7 <fwp_main_thread+0xa97>
    c365:	e9 43 f4 ff ff       	jmp    b7ad <fwp_main_thread+0xa7d>
    c36a:	48 89 d7             	mov    %rdx,%rdi
    c36d:	48 89 95 b8 fe ff ff 	mov    %rdx,-0x148(%rbp)
    c374:	e8 37 92 ff ff       	call   55b0 <fwp_rc_forget_slot>
    c379:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
    c380:	e9 97 f1 ff ff       	jmp    b51c <fwp_main_thread+0x7ec>
    c385:	48 89 df             	mov    %rbx,%rdi
    c388:	e8 13 a4 ff ff       	call   67a0 <fwp_rc_free_arr>
    c38d:	e9 07 fb ff ff       	jmp    be99 <fwp_main_thread+0x1169>
    c392:	66 85 c0             	test   %ax,%ax
    c395:	0f 85 fe fa ff ff    	jne    be99 <fwp_main_thread+0x1169>
    c39b:	e9 d9 fa ff ff       	jmp    be79 <fwp_main_thread+0x1149>
    c3a0:	48 83 3d 30 54 01 00 	cmpq   $0x0,0x15430(%rip)        # 217d8 <fwp_root>
    c3a7:	00 
    c3a8:	c7 05 0e 4d 01 00 00 	movl   $0x0,0x14d0e(%rip)        # 210c0 <fwp_exit_code>
    c3af:	00 00 00 
    c3b2:	0f 84 42 ee ff ff    	je     b1fa <fwp_main_thread+0x4ca>
    c3b8:	e9 93 73 ff ff       	jmp    3750 <fwp_main_thread.cold>
    c3bd:	0f 1f 00             	nopl   (%rax)
    c3c0:	4c 89 e8             	mov    %r13,%rax
    c3c3:	48 c1 e8 11          	shr    $0x11,%rax
    c3c7:	4c 31 e8             	xor    %r13,%rax
    c3ca:	48 89 c2             	mov    %rax,%rdx
    c3cd:	48 c1 ea 09          	shr    $0x9,%rdx
    c3d1:	48 31 d0             	xor    %rdx,%rax
    c3d4:	0f b6 c0             	movzbl %al,%eax
    c3d7:	49 8b 94 c6 48 14 00 	mov    0x1448(%r14,%rax,8),%rdx
    c3de:	00 
    c3df:	48 85 d2             	test   %rdx,%rdx
    c3e2:	75 25                	jne    c409 <fwp_main_thread+0x16d9>
    c3e4:	eb 70                	jmp    c456 <fwp_main_thread+0x1726>
    c3e6:	0f 1f 40 00          	nopl   0x0(%rax)
    c3ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    c3f1:	00 00 00 00 
    c3f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    c3fc:	00 00 00 00 
    c400:	48 8b 50 10          	mov    0x10(%rax),%rdx
    c404:	48 85 d2             	test   %rdx,%rdx
    c407:	74 4d                	je     c456 <fwp_main_thread+0x1726>
    c409:	48 89 d0             	mov    %rdx,%rax
    c40c:	4c 39 2a             	cmp    %r13,(%rdx)
    c40f:	75 ef                	jne    c400 <fwp_main_thread+0x16d0>
    c411:	48 8b 42 08          	mov    0x8(%rdx),%rax
    c415:	48 83 e8 01          	sub    $0x1,%rax
    c419:	48 89 42 08          	mov    %rax,0x8(%rdx)
    c41d:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    c423:	0f 85 70 fa ff ff    	jne    be99 <fwp_main_thread+0x1169>
    c429:	4c 89 ef             	mov    %r13,%rdi
    c42c:	e8 7f 91 ff ff       	call   55b0 <fwp_rc_forget_slot>
    c431:	41 c6 45 00 fe       	movb   $0xfe,0x0(%r13)
    c436:	e9 5e fa ff ff       	jmp    be99 <fwp_main_thread+0x1169>
    c43b:	48 89 d7             	mov    %rdx,%rdi
    c43e:	48 89 95 b8 fe ff ff 	mov    %rdx,-0x148(%rbp)
    c445:	e8 66 91 ff ff       	call   55b0 <fwp_rc_forget_slot>
    c44a:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
    c451:	e9 8d f9 ff ff       	jmp    bde3 <fwp_main_thread+0x10b3>
    c456:	48 8d 3d 2b 14 00 00 	lea    0x142b(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    c45d:	e8 8e 7f ff ff       	call   43f0 <fwp_trap>
    c462:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    c468:	66 85 c0             	test   %ax,%ax
    c46b:	0f 85 75 f9 ff ff    	jne    bde6 <fwp_main_thread+0x10b6>
    c471:	e9 64 f9 ff ff       	jmp    bdda <fwp_main_thread+0x10aa>
    c476:	48 89 df             	mov    %rbx,%rdi
    c479:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c480:	e8 2b 91 ff ff       	call   55b0 <fwp_rc_forget_slot>
    c485:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    c48c:	e9 cd f1 ff ff       	jmp    b65e <fwp_main_thread+0x92e>
    c491:	48 89 df             	mov    %rbx,%rdi
    c494:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c49b:	e8 10 91 ff ff       	call   55b0 <fwp_rc_forget_slot>
    c4a0:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    c4a7:	e9 58 f2 ff ff       	jmp    b704 <fwp_main_thread+0x9d4>
    c4ac:	48 89 df             	mov    %rbx,%rdi
    c4af:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c4b6:	e8 f5 90 ff ff       	call   55b0 <fwp_rc_forget_slot>
    c4bb:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    c4c2:	e9 ef f2 ff ff       	jmp    b7b6 <fwp_main_thread+0xa86>
    c4c7:	e8 c4 8f ff ff       	call   5490 <fwp_rc_wide_dup>
    c4cc:	e9 82 f3 ff ff       	jmp    b853 <fwp_main_thread+0xb23>
    c4d1:	e8 0a 79 ff ff       	call   3de0 <descent_phase_fail>
    c4d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    c4dd:	00 00 00 
    c4e0:	e8 cb 77 ff ff       	call   3cb0 <fwp_heap_oom>
    c4e5:	48 89 c8             	mov    %rcx,%rax
    c4e8:	e9 79 ec ff ff       	jmp    b166 <fwp_main_thread+0x436>
    c4ed:	0f 1f 00             	nopl   (%rax)
    c4f0:	48 89 c7             	mov    %rax,%rdi
    c4f3:	4c 8d 3d 1e 4b 00 00 	lea    0x4b1e(%rip),%r15        # 11018 <fc12>
    c4fa:	e8 21 a2 ff ff       	call   6720 <fwp_rc_share>
    c4ff:	48 8b bd 70 fe ff ff 	mov    -0x190(%rbp),%rdi
    c506:	e8 15 a2 ff ff       	call   6720 <fwp_rc_share>
    c50b:	48 8b 85 80 fe ff ff 	mov    -0x180(%rbp),%rax
    c512:	c7 85 9c fe ff ff 01 	movl   $0x1,-0x164(%rbp)
    c519:	00 00 00 
    c51c:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
    c523:	e9 9b f7 ff ff       	jmp    bcc3 <fwp_main_thread+0xf93>
    c528:	48 8d 3d 17 0d 00 00 	lea    0xd17(%rip),%rdi        # d246 <_IO_stdin_used+0x246>
    c52f:	e8 bc 7e ff ff       	call   43f0 <fwp_trap>
    c534:	e8 27 6f ff ff       	call   3460 <__stack_chk_fail@plt>
    c539:	48 8d 3d a0 14 00 00 	lea    0x14a0(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    c540:	e8 ab 7e ff ff       	call   43f0 <fwp_trap>
    c545:	4c 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%r8
    c54c:	48 8b bd 70 fe ff ff 	mov    -0x190(%rbp),%rdi
    c553:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c55a:	e8 51 a3 ff ff       	call   68b0 <fwp_drop0>
    c55f:	48 8b bd b8 fe ff ff 	mov    -0x148(%rbp),%rdi
    c566:	e8 45 a3 ff ff       	call   68b0 <fwp_drop0>
    c56b:	48 c7 05 32 4b 00 00 	movq   $0x0,0x4b32(%rip)        # 110a8 <v.6>
    c572:	00 00 00 00 
    c576:	c7 05 30 4b 00 00 01 	movl   $0x1,0x4b30(%rip)        # 110b0 <st.7>
    c57d:	00 00 00 
    c580:	e9 d9 e8 ff ff       	jmp    ae5e <fwp_main_thread+0x12e>
    c585:	e9 c6 71 ff ff       	jmp    3750 <fwp_main_thread.cold>
    c58a:	e9 c1 71 ff ff       	jmp    3750 <fwp_main_thread.cold>
    c58f:	90                   	nop

000000000000c590 <__divmodti4>:
    c590:	f3 0f 1e fa          	endbr64
    c594:	55                   	push   %rbp
    c595:	49 89 f1             	mov    %rsi,%r9
    c598:	49 89 d2             	mov    %rdx,%r10
    c59b:	48 89 fe             	mov    %rdi,%rsi
    c59e:	49 89 cb             	mov    %rcx,%r11
    c5a1:	48 89 e5             	mov    %rsp,%rbp
    c5a4:	41 57                	push   %r15
    c5a6:	41 56                	push   %r14
    c5a8:	41 55                	push   %r13
    c5aa:	41 54                	push   %r12
    c5ac:	53                   	push   %rbx
    c5ad:	4c 89 c3             	mov    %r8,%rbx
    c5b0:	45 31 c0             	xor    %r8d,%r8d
    c5b3:	4d 85 c9             	test   %r9,%r9
    c5b6:	79 12                	jns    c5ca <__divmodti4+0x3a>
    c5b8:	31 ff                	xor    %edi,%edi
    c5ba:	48 f7 de             	neg    %rsi
    c5bd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    c5c4:	4c 19 cf             	sbb    %r9,%rdi
    c5c7:	49 89 f9             	mov    %rdi,%r9
    c5ca:	4c 89 d8             	mov    %r11,%rax
    c5cd:	4d 85 db             	test   %r11,%r11
    c5d0:	0f 88 1a 01 00 00    	js     c6f0 <__divmodti4+0x160>
    c5d6:	4c 89 d9             	mov    %r11,%rcx
    c5d9:	49 89 f3             	mov    %rsi,%r11
    c5dc:	75 62                	jne    c640 <__divmodti4+0xb0>
    c5de:	4d 89 c4             	mov    %r8,%r12
    c5e1:	4d 39 d1             	cmp    %r10,%r9
    c5e4:	0f 83 46 01 00 00    	jae    c730 <__divmodti4+0x1a0>
    c5ea:	4c 89 d8             	mov    %r11,%rax
    c5ed:	4c 89 ca             	mov    %r9,%rdx
    c5f0:	49 f7 f2             	div    %r10
    c5f3:	49 89 c3             	mov    %rax,%r11
    c5f6:	31 c0                	xor    %eax,%eax
    c5f8:	48 89 d6             	mov    %rdx,%rsi
    c5fb:	31 ff                	xor    %edi,%edi
    c5fd:	4c 89 d9             	mov    %r11,%rcx
    c600:	48 89 c2             	mov    %rax,%rdx
    c603:	48 89 c8             	mov    %rcx,%rax
    c606:	4d 85 e4             	test   %r12,%r12
    c609:	74 0a                	je     c615 <__divmodti4+0x85>
    c60b:	48 f7 d8             	neg    %rax
    c60e:	48 83 d2 00          	adc    $0x0,%rdx
    c612:	48 f7 da             	neg    %rdx
    c615:	4d 85 c0             	test   %r8,%r8
    c618:	74 0a                	je     c624 <__divmodti4+0x94>
    c61a:	48 f7 de             	neg    %rsi
    c61d:	48 83 d7 00          	adc    $0x0,%rdi
    c621:	48 f7 df             	neg    %rdi
    c624:	48 89 33             	mov    %rsi,(%rbx)
    c627:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    c62b:	5b                   	pop    %rbx
    c62c:	41 5c                	pop    %r12
    c62e:	41 5d                	pop    %r13
    c630:	41 5e                	pop    %r14
    c632:	41 5f                	pop    %r15
    c634:	5d                   	pop    %rbp
    c635:	c3                   	ret
    c636:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    c63d:	00 00 00 
    c640:	4d 89 c4             	mov    %r8,%r12
    c643:	49 39 c1             	cmp    %rax,%r9
    c646:	0f 82 ce 00 00 00    	jb     c71a <__divmodti4+0x18a>
    c64c:	31 ff                	xor    %edi,%edi
    c64e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    c653:	48 63 c7             	movslq %edi,%rax
    c656:	be 40 00 00 00       	mov    $0x40,%esi
    c65b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    c660:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    c665:	48 29 c6             	sub    %rax,%rsi
    c668:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    c66d:	48 09 c8             	or     %rcx,%rax
    c670:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    c675:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    c67a:	49 89 c6             	mov    %rax,%r14
    c67d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    c681:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    c686:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    c68b:	49 09 c1             	or     %rax,%r9
    c68e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    c692:	4c 89 c8             	mov    %r9,%rax
    c695:	49 f7 f6             	div    %r14
    c698:	48 89 d1             	mov    %rdx,%rcx
    c69b:	49 89 c3             	mov    %rax,%r11
    c69e:	49 89 c1             	mov    %rax,%r9
    c6a1:	49 f7 e2             	mul    %r10
    c6a4:	49 89 c6             	mov    %rax,%r14
    c6a7:	49 89 d2             	mov    %rdx,%r10
    c6aa:	48 39 d1             	cmp    %rdx,%rcx
    c6ad:	72 07                	jb     c6b6 <__divmodti4+0x126>
    c6af:	75 17                	jne    c6c8 <__divmodti4+0x138>
    c6b1:	49 39 c7             	cmp    %rax,%r15
    c6b4:	73 12                	jae    c6c8 <__divmodti4+0x138>
    c6b6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    c6ba:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    c6be:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    c6c2:	49 89 d2             	mov    %rdx,%r10
    c6c5:	49 89 c6             	mov    %rax,%r14
    c6c8:	4c 89 f8             	mov    %r15,%rax
    c6cb:	4c 29 f0             	sub    %r14,%rax
    c6ce:	4c 19 d1             	sbb    %r10,%rcx
    c6d1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    c6d6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    c6db:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    c6e0:	48 09 c6             	or     %rax,%rsi
    c6e3:	48 89 cf             	mov    %rcx,%rdi
    c6e6:	31 c0                	xor    %eax,%eax
    c6e8:	4c 89 c9             	mov    %r9,%rcx
    c6eb:	e9 10 ff ff ff       	jmp    c600 <__divmodti4+0x70>
    c6f0:	4c 89 d0             	mov    %r10,%rax
    c6f3:	4c 89 da             	mov    %r11,%rdx
    c6f6:	4d 89 c4             	mov    %r8,%r12
    c6f9:	49 89 f3             	mov    %rsi,%r11
    c6fc:	48 f7 d8             	neg    %rax
    c6ff:	49 f7 d4             	not    %r12
    c702:	48 83 d2 00          	adc    $0x0,%rdx
    c706:	49 89 c2             	mov    %rax,%r10
    c709:	48 f7 da             	neg    %rdx
    c70c:	48 89 d1             	mov    %rdx,%rcx
    c70f:	0f 84 cc fe ff ff    	je     c5e1 <__divmodti4+0x51>
    c715:	49 39 d1             	cmp    %rdx,%r9
    c718:	73 46                	jae    c760 <__divmodti4+0x1d0>
    c71a:	4c 89 cf             	mov    %r9,%rdi
    c71d:	31 c0                	xor    %eax,%eax
    c71f:	31 c9                	xor    %ecx,%ecx
    c721:	e9 da fe ff ff       	jmp    c600 <__divmodti4+0x70>
    c726:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    c72d:	00 00 00 
    c730:	4d 85 d2             	test   %r10,%r10
    c733:	75 0d                	jne    c742 <__divmodti4+0x1b2>
    c735:	b8 01 00 00 00       	mov    $0x1,%eax
    c73a:	31 d2                	xor    %edx,%edx
    c73c:	49 f7 f2             	div    %r10
    c73f:	49 89 c2             	mov    %rax,%r10
    c742:	4c 89 c8             	mov    %r9,%rax
    c745:	31 d2                	xor    %edx,%edx
    c747:	49 f7 f2             	div    %r10
    c74a:	49 89 c1             	mov    %rax,%r9
    c74d:	4c 89 d8             	mov    %r11,%rax
    c750:	49 f7 f2             	div    %r10
    c753:	49 89 c3             	mov    %rax,%r11
    c756:	4c 89 c8             	mov    %r9,%rax
    c759:	e9 9a fe ff ff       	jmp    c5f8 <__divmodti4+0x68>
    c75e:	66 90                	xchg   %ax,%ax
    c760:	45 31 f6             	xor    %r14d,%r14d
    c763:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    c768:	44 89 f7             	mov    %r14d,%edi
    c76b:	45 85 f6             	test   %r14d,%r14d
    c76e:	0f 85 df fe ff ff    	jne    c653 <__divmodti4+0xc3>
    c774:	4c 39 ca             	cmp    %r9,%rdx
    c777:	72 17                	jb     c790 <__divmodti4+0x200>
    c779:	31 c9                	xor    %ecx,%ecx
    c77b:	48 39 c6             	cmp    %rax,%rsi
    c77e:	73 10                	jae    c790 <__divmodti4+0x200>
    c780:	4c 89 cf             	mov    %r9,%rdi
    c783:	31 c0                	xor    %eax,%eax
    c785:	e9 76 fe ff ff       	jmp    c600 <__divmodti4+0x70>
    c78a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    c790:	4c 89 de             	mov    %r11,%rsi
    c793:	b9 01 00 00 00       	mov    $0x1,%ecx
    c798:	48 29 c6             	sub    %rax,%rsi
    c79b:	49 19 d1             	sbb    %rdx,%r9
    c79e:	eb e0                	jmp    c780 <__divmodti4+0x1f0>

000000000000c7a0 <atexit>:
    c7a0:	f3 0f 1e fa          	endbr64
    c7a4:	48 8b 15 5d 48 00 00 	mov    0x485d(%rip),%rdx        # 11008 <__dso_handle>
    c7ab:	31 f6                	xor    %esi,%esi
    c7ad:	e9 ae 6e ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000c7b4 <_fini>:
    c7b4:	f3 0f 1e fa          	endbr64
    c7b8:	48 83 ec 08          	sub    $0x8,%rsp
    c7bc:	48 83 c4 08          	add    $0x8,%rsp
    c7c0:	c3                   	ret
