
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-history-reference:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 df 00 00 	mov    0xdfc9(%rip),%rax        # 10fd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 dd 00 00    	push   0xdde2(%rip)        # 10e08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 dd 00 00    	jmp    *0xdde4(%rip)        # 10e10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e dc 00 00    	jmp    *0xdc4e(%rip)        # 10fe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e da 00 00    	jmp    *0xda6e(%rip)        # 10e18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 da 00 00    	jmp    *0xda66(%rip)        # 10e20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e da 00 00    	jmp    *0xda5e(%rip)        # 10e28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 da 00 00    	jmp    *0xda56(%rip)        # 10e30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e da 00 00    	jmp    *0xda4e(%rip)        # 10e38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 da 00 00    	jmp    *0xda46(%rip)        # 10e40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e da 00 00    	jmp    *0xda3e(%rip)        # 10e48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 da 00 00    	jmp    *0xda36(%rip)        # 10e50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e da 00 00    	jmp    *0xda2e(%rip)        # 10e58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 da 00 00    	jmp    *0xda26(%rip)        # 10e60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e da 00 00    	jmp    *0xda1e(%rip)        # 10e68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 da 00 00    	jmp    *0xda16(%rip)        # 10e70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e da 00 00    	jmp    *0xda0e(%rip)        # 10e78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 da 00 00    	jmp    *0xda06(%rip)        # 10e80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe d9 00 00    	jmp    *0xd9fe(%rip)        # 10e88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 d9 00 00    	jmp    *0xd9f6(%rip)        # 10e90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee d9 00 00    	jmp    *0xd9ee(%rip)        # 10e98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 d9 00 00    	jmp    *0xd9e6(%rip)        # 10ea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de d9 00 00    	jmp    *0xd9de(%rip)        # 10ea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 d9 00 00    	jmp    *0xd9d6(%rip)        # 10eb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce d9 00 00    	jmp    *0xd9ce(%rip)        # 10eb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 d9 00 00    	jmp    *0xd9c6(%rip)        # 10ec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be d9 00 00    	jmp    *0xd9be(%rip)        # 10ec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 d9 00 00    	jmp    *0xd9b6(%rip)        # 10ed0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae d9 00 00    	jmp    *0xd9ae(%rip)        # 10ed8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 d9 00 00    	jmp    *0xd9a6(%rip)        # 10ee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e d9 00 00    	jmp    *0xd99e(%rip)        # 10ee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 d9 00 00    	jmp    *0xd996(%rip)        # 10ef0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e d9 00 00    	jmp    *0xd98e(%rip)        # 10ef8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 d9 00 00    	jmp    *0xd986(%rip)        # 10f00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e d9 00 00    	jmp    *0xd97e(%rip)        # 10f08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 d9 00 00    	jmp    *0xd976(%rip)        # 10f10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e d9 00 00    	jmp    *0xd96e(%rip)        # 10f18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 d9 00 00    	jmp    *0xd966(%rip)        # 10f20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e d9 00 00    	jmp    *0xd95e(%rip)        # 10f28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 d9 00 00    	jmp    *0xd956(%rip)        # 10f30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e d9 00 00    	jmp    *0xd94e(%rip)        # 10f38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 d9 00 00    	jmp    *0xd946(%rip)        # 10f40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e d9 00 00    	jmp    *0xd93e(%rip)        # 10f48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 d9 00 00    	jmp    *0xd936(%rip)        # 10f50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e d9 00 00    	jmp    *0xd92e(%rip)        # 10f58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 d9 00 00    	jmp    *0xd926(%rip)        # 10f60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e d9 00 00    	jmp    *0xd91e(%rip)        # 10f68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 d9 00 00    	jmp    *0xd916(%rip)        # 10f70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e d9 00 00    	jmp    *0xd90e(%rip)        # 10f78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 d9 00 00    	jmp    *0xd906(%rip)        # 10f80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe d8 00 00    	jmp    *0xd8fe(%rip)        # 10f88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 d8 00 00    	jmp    *0xd8f6(%rip)        # 10f90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee d8 00 00    	jmp    *0xd8ee(%rip)        # 10f98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 d8 00 00    	jmp    *0xd8e6(%rip)        # 10fa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de d8 00 00    	jmp    *0xd8de(%rip)        # 10fa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 d8 00 00    	jmp    *0xd8d6(%rip)        # 10fb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce d8 00 00    	jmp    *0xd8ce(%rip)        # 10fb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 d8 00 00    	jmp    *0xd8c6(%rip)        # 10fc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a 99 00 00 	lea    0x997a(%rip),%r9        # d091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 99 00 00 	lea    0x9977(%rip),%r8        # d095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 bd 00 00 	lea    0xbd01(%rip),%rax        # f480 <fwp_fn_table>
    377f:	48 89 05 72 fc 01 00 	mov    %rax,0x1fc72(%rip)        # 233f8 <fwp_fns>
    3786:	48 8b 05 b3 d8 00 00 	mov    0xd8b3(%rip),%rax        # 11040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 6c fc 01 00 	mov    %rax,0x1fc6c(%rip)        # 23400 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 59 9a 00 00 	lea    0x9a59(%rip),%rdi        # d1f9 <_IO_stdin_used+0x1f9>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 d8 00 00 	mov    0xd838(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 6f 72 00 00 	lea    0x726f(%rip),%rdx        # aad0 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 d7 00 00 	mov    0xd7a3(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 18 d8 01 00    	mov    0x1d818(%rip),%eax        # 210c0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 09 99 00 00 	lea    0x9909(%rip),%rdi        # d202 <_IO_stdin_used+0x202>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 8e a0 00 00 	lea    0xa08e(%rip),%rdi        # d998 <_IO_stdin_used+0x998>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 48 a0 00 00 	lea    0xa048(%rip),%rdi        # d970 <_IO_stdin_used+0x970>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 0c a0 00 00 	lea    0xa00c(%rip),%rdi        # d940 <_IO_stdin_used+0x940>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d d8 9f 00 00 	lea    0x9fd8(%rip),%rdi        # d918 <_IO_stdin_used+0x918>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 d6 00 00    	call   *0xd653(%rip)        # 10fc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 d6 00 00 	lea    0xd6a1(%rip),%rdi        # 11028 <__TMC_END__>
    3987:	48 8d 05 9a d6 00 00 	lea    0xd69a(%rip),%rax        # 11028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 d6 00 00 	mov    0xd636(%rip),%rax        # 10fd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 d6 00 00 	lea    0xd671(%rip),%rdi        # 11028 <__TMC_END__>
    39b7:	48 8d 35 6a d6 00 00 	lea    0xd66a(%rip),%rsi        # 11028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 d6 00 00 	mov    0xd605(%rip),%rax        # 10fe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d d6 00 00 00 	cmpb   $0x0,0xd66d(%rip)        # 11068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 d5 00 00 	cmpq   $0x0,0xd5e2(%rip)        # 10fe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 d5 00 00 	mov    0xd5f6(%rip),%rdi        # 11008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 d6 00 00 01 	movb   $0x1,0xd645(%rip)        # 11068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 0e d5 01 00 	add    0x1d50e(%rip),%rdx        # 21130 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 fc d4 01 00 	add    0x1d4fc(%rip),%rax        # 21130 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 89 f7 01 00 	mov    0x1f789(%rip),%rdi        # 23400 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d b4 d3 00 00 	mov    0xd3b4(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d a1 d3 00 00 	mov    0xd3a1(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 93 00 00 	lea    0x9345(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 92 d3 00 00 	mov    0xd392(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 81 da 01 00 	mov    0x1da81(%rip),%rax        # 21780 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 c1 d3 01 00 	mov    0x1d3c1(%rip),%rax        # 21140 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 ad d3 01 00 	sub    0x1d3ad(%rip),%rax        # 21138 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 bd 9c 00 00 	lea    0x9cbd(%rip),%rsi        # da80 <msg.8>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 9b ed 01 00 	mov    0x1ed9b(%rip),%rax        # 22b90 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 94 ed 01 00 	lea    0x1ed94(%rip),%r8        # 22b90 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 75 ed 01 00 	mov    0x1ed75(%rip),%rbx        # 22b78 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 85 ed 01 00 	mov    0x1ed85(%rip),%rcx        # 22b98 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d 21 ed 01 00 	mov    0x1ed21(%rip),%rdi        # 22b80 <fwp_heap+0x13e0>
    3e5f:	48 29 35 6a ed 01 00 	sub    %rsi,0x1ed6a(%rip)        # 22bd0 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 fa ec 01 00 	mov    0x1ecfa(%rip),%rax        # 22b70 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d b0 ec 01 00 	add    0x1ecb0(%rip),%rdi        # 22b50 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 be ec 01 00 	mov    0x1ecbe(%rip),%rsi        # 22b80 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 cc ec 01 00 	mov    0x1eccc(%rip),%rax        # 22b98 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 7b ec 01 00 	mov    %r12,0x1ec7b(%rip)        # 22b80 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 69 ec 01 00 	mov    %rbp,0x1ec69(%rip)        # 22b78 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 4e ec 01 00 	cmp    %rdi,0x1ec4e(%rip)        # 22b68 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 45 ec 01 00 	mov    %rdi,0x1ec45(%rip)        # 22b68 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 89 ec 01 00 	sub    %rdi,0x1ec89(%rip)        # 22bd0 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 31 ec 01 00 	mov    0x1ec31(%rip),%rax        # 22b88 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 2a ec 01 00 	lea    0x1ec2a(%rip),%r8        # 22b88 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d 1d d0 00 00 	mov    0xd01d(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 8f 00 00 	lea    0x8fb4(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d c9 d6 01 00 	cmp    0x1d6c9(%rip),%rdi        # 21780 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 8f d6 01 00 	mov    0x1d68f(%rip),%rax        # 21760 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 6d d6 01 00 	mov    %rdi,0x1d66d(%rip)        # 21760 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 49 d6 01 00 	mov    %rdi,0x1d649(%rip)        # 21768 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 05 90 00 00 	lea    0x9005(%rip),%rsi        # d166 <_IO_stdin_used+0x166>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 8e 00 00 	lea    0x8ea7(%rip),%rsi        # d01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 98 ce 00 00 	mov    0xce98(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 8e 00 00 	lea    0x8e51(%rip),%rdx        # d020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 80 ce 00 00 	mov    0xce80(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 91 cd 00 00 	mov    0xcd91(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 8d 00 00 	lea    0x8d28(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 8d 00 00 	lea    0x8d32(%rip),%rdi        # d02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba 8c 00 00 	lea    0x8cba(%rip),%rdi        # d049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 68 92 00 00 	lea    0x9268(%rip),%rdi        # d608 <_IO_stdin_used+0x608>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 e0 96 00 	movdqa 0x96e0(%rip),%xmm0        # daa0 <msg.8+0x20>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 da ef 01 00 	add    0x1efda(%rip),%rax        # 233f8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d c4 91 00 00 	lea    0x91c4(%rip),%rdi        # d638 <_IO_stdin_used+0x638>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 95 cc 01 00 	cmp    %rax,0x1cc95(%rip)        # 21128 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 90 cc 01 00 	add    0x1cc90(%rip),%rax        # 21130 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d ad 91 00 00 	lea    0x91ad(%rip),%rdi        # d668 <_IO_stdin_used+0x668>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 8b 00 00 	lea    0x8b92(%rip),%r8        # d065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 89 00 00 	lea    0x89e7(%rip),%r8        # d074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 88 00 00 	lea    0x8874(%rip),%r8        # d06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c 86 00 00 	lea    0x864c(%rip),%rdi        # d079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 60 87 00 00 	lea    0x8760(%rip),%rsi        # d1ae <_IO_stdin_used+0x1ae>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d a5 e0 01 00 	mov    0x1e0a5(%rip),%r9        # 22b68 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 fe e0 01 00 	mov    0x1e0fe(%rip),%r8        # 22bc8 <fwp_heap+0x1428>
    4aca:	48 8d 15 e7 8b 00 00 	lea    0x8be7(%rip),%rdx        # d6b8 <_IO_stdin_used+0x6b8>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d e6 e0 01 00 	mov    0x1e0e6(%rip),%rcx        # 22bc0 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d f4 e0 01 	movsd  0x1e0f4(%rip),%xmm1        # 22be0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 e4 e0 01 	movsd  0x1e0e4(%rip),%xmm0        # 22bd8 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 65 c5 00 00 	mov    0xc565(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 78 8f 00 	movdqa 0x8f78(%rip),%xmm0        # dab0 <msg.8+0x30>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 9f db 01 00 	lea    0x1db9f(%rip),%rax        # 226e0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 a1 8f 00 	movdqa 0x8fa1(%rip),%xmm2        # daf0 <msg.8+0x70>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 45 db 01 00 	movaps %xmm0,0x1db45(%rip)        # 226a0 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 5d 8f 00 	movdqa 0x8f5d(%rip),%xmm0        # dac0 <msg.8+0x40>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 d3 df 01 00 01 	movl   $0x1,0x1dfd3(%rip)        # 22b44 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 33 db 01 00 	movaps %xmm0,0x1db33(%rip)        # 226b0 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 4b 8f 00 	movdqa 0x8f4b(%rip),%xmm0        # dad0 <msg.8+0x50>
    4b84:	00 
    4b85:	0f 29 05 34 db 01 00 	movaps %xmm0,0x1db34(%rip)        # 226c0 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 4c 8f 00 	movdqa 0x8f4c(%rip),%xmm0        # dae0 <msg.8+0x60>
    4b93:	00 
    4b94:	0f 29 05 35 db 01 00 	movaps %xmm0,0x1db35(%rip)        # 226d0 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 b5 cb 01 00 	lea    0x1cbb5(%rip),%r8        # 217a0 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 d0 de 01 00 	mov    %rax,0x1ded0(%rip)        # 22b58 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 ae de 01 00 	mov    %r12,0x1deae(%rip)        # 22b60 <fwp_heap+0x13c0>
    4cb2:	48 89 05 97 de 01 00 	mov    %rax,0x1de97(%rip)        # 22b50 <fwp_heap+0x13b0>
    4cb9:	48 89 1d b0 de 01 00 	mov    %rbx,0x1deb0(%rip)        # 22b70 <fwp_heap+0x13d0>
    4cc0:	48 89 35 d9 de 01 00 	mov    %rsi,0x1ded9(%rip)        # 22ba0 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 83 00 00 	lea    0x83d6(%rip),%rdi        # d0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 b8 de 01 00 	mov    %rax,0x1deb8(%rip)        # 22b98 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 3c de 01 00    	mov    %eax,0x1de3c(%rip)        # 22b48 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <caf61>:
    4d20:	8b 15 7a c3 00 00    	mov    0xc37a(%rip),%edx        # 110a0 <st.4>
    4d26:	85 d2                	test   %edx,%edx
    4d28:	74 0e                	je     4d38 <caf61+0x18>
    4d2a:	48 8b 05 67 c3 00 00 	mov    0xc367(%rip),%rax        # 11098 <v.3>
    4d31:	c3                   	ret
    4d32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4d38:	8b 05 52 c3 00 00    	mov    0xc352(%rip),%eax        # 11090 <st.2>
    4d3e:	85 c0                	test   %eax,%eax
    4d40:	74 1e                	je     4d60 <caf61+0x40>
    4d42:	48 8b 05 3f c3 00 00 	mov    0xc33f(%rip),%rax        # 11088 <v.1>
    4d49:	48 89 05 48 c3 00 00 	mov    %rax,0xc348(%rip)        # 11098 <v.3>
    4d50:	c7 05 46 c3 00 00 01 	movl   $0x1,0xc346(%rip)        # 110a0 <st.4>
    4d57:	00 00 00 
    4d5a:	c3                   	ret
    4d5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4d60:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    4d67:	00 f0 3f 
    4d6a:	c7 05 1c c3 00 00 01 	movl   $0x1,0xc31c(%rip)        # 11090 <st.2>
    4d71:	00 00 00 
    4d74:	48 89 05 0d c3 00 00 	mov    %rax,0xc30d(%rip)        # 11088 <v.1>
    4d7b:	eb cc                	jmp    4d49 <caf61+0x29>
    4d7d:	0f 1f 00             	nopl   (%rax)

0000000000004d80 <fwp_wake_io>:
    4d80:	48 8b 07             	mov    (%rdi),%rax
    4d83:	48 85 c0             	test   %rax,%rax
    4d86:	0f 84 f4 00 00 00    	je     4e80 <fwp_wake_io+0x100>
    4d8c:	53                   	push   %rbx
    4d8d:	4c 8b 05 cc c9 01 00 	mov    0x1c9cc(%rip),%r8        # 21760 <fwp_ready_tail>
    4d94:	49 89 f9             	mov    %rdi,%r9
    4d97:	48 89 c2             	mov    %rax,%rdx
    4d9a:	45 31 db             	xor    %r11d,%r11d
    4d9d:	45 31 d2             	xor    %r10d,%r10d
    4da0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4da4:	eb 71                	jmp    4e17 <fwp_wake_io+0x97>
    4da6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4dad:	00 00 00 
    4db0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4db7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dbe:	48 85 c9             	test   %rcx,%rcx
    4dc1:	74 07                	je     4dca <fwp_wake_io+0x4a>
    4dc3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4dca:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4dd1:	00 00 00 00 
    4dd5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4ddc:	49 8b 01             	mov    (%r9),%rax
    4ddf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4de3:	75 2a                	jne    4e0f <fwp_wake_io+0x8f>
    4de5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4de9:	75 24                	jne    4e0f <fwp_wake_io+0x8f>
    4deb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4def:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4df6:	00 00 00 00 
    4dfa:	4d 85 c0             	test   %r8,%r8
    4dfd:	74 51                	je     4e50 <fwp_wake_io+0xd0>
    4dff:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4e06:	49 89 d0             	mov    %rdx,%r8
    4e09:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4e0f:	48 89 c2             	mov    %rax,%rdx
    4e12:	48 85 c0             	test   %rax,%rax
    4e15:	74 49                	je     4e60 <fwp_wake_io+0xe0>
    4e17:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4e1e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4e22:	48 85 ff             	test   %rdi,%rdi
    4e25:	74 b8                	je     4ddf <fwp_wake_io+0x5f>
    4e27:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4e2e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4e35:	48 85 f6             	test   %rsi,%rsi
    4e38:	0f 85 72 ff ff ff    	jne    4db0 <fwp_wake_io+0x30>
    4e3e:	48 89 0f             	mov    %rcx,(%rdi)
    4e41:	e9 78 ff ff ff       	jmp    4dbe <fwp_wake_io+0x3e>
    4e46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e4d:	00 00 00 
    4e50:	48 89 d3             	mov    %rdx,%rbx
    4e53:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4e59:	eb ab                	jmp    4e06 <fwp_wake_io+0x86>
    4e5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e60:	45 84 db             	test   %r11b,%r11b
    4e63:	74 07                	je     4e6c <fwp_wake_io+0xec>
    4e65:	48 89 1d fc c8 01 00 	mov    %rbx,0x1c8fc(%rip)        # 21768 <fwp_ready_head>
    4e6c:	45 84 d2             	test   %r10b,%r10b
    4e6f:	74 07                	je     4e78 <fwp_wake_io+0xf8>
    4e71:	4c 89 05 e8 c8 01 00 	mov    %r8,0x1c8e8(%rip)        # 21760 <fwp_ready_tail>
    4e78:	5b                   	pop    %rbx
    4e79:	c3                   	ret
    4e7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e80:	c3                   	ret
    4e81:	0f 1f 40 00          	nopl   0x0(%rax)
    4e85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e8c:	00 00 00 00 

0000000000004e90 <fwp_tape_buffers_release>:
    4e90:	f3 0f 1e fa          	endbr64
    4e94:	53                   	push   %rbx
    4e95:	48 89 fb             	mov    %rdi,%rbx
    4e98:	48 83 ec 10          	sub    $0x10,%rsp
    4e9c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4ea0:	48 85 c0             	test   %rax,%rax
    4ea3:	0f 88 df 00 00 00    	js     4f88 <fwp_tape_buffers_release+0xf8>
    4ea9:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4ead:	48 85 d2             	test   %rdx,%rdx
    4eb0:	0f 88 d2 00 00 00    	js     4f88 <fwp_tape_buffers_release+0xf8>
    4eb6:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4ebc:	0f 87 c6 00 00 00    	ja     4f88 <fwp_tape_buffers_release+0xf8>
    4ec2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4ec6:	b8 00 00 08 00       	mov    $0x80000,%eax
    4ecb:	48 c1 e1 03          	shl    $0x3,%rcx
    4ecf:	48 29 c8             	sub    %rcx,%rax
    4ed2:	48 c1 e8 03          	shr    $0x3,%rax
    4ed6:	48 39 d0             	cmp    %rdx,%rax
    4ed9:	0f 82 a9 00 00 00    	jb     4f88 <fwp_tape_buffers_release+0xf8>
    4edf:	48 8d 3d d9 81 00 00 	lea    0x81d9(%rip),%rdi        # d0bf <_IO_stdin_used+0xbf>
    4ee6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4eeb:	48 89 14 24          	mov    %rdx,(%rsp)
    4eef:	e8 ac e4 ff ff       	call   33a0 <getenv@plt>
    4ef4:	48 8b 14 24          	mov    (%rsp),%rdx
    4ef8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4efd:	48 85 c0             	test   %rax,%rax
    4f00:	74 09                	je     4f0b <fwp_tape_buffers_release+0x7b>
    4f02:	80 38 30             	cmpb   $0x30,(%rax)
    4f05:	0f 84 9d 00 00 00    	je     4fa8 <fwp_tape_buffers_release+0x118>
    4f0b:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4f0f:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4f13:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4f1a:	77 78                	ja     4f94 <fwp_tape_buffers_release+0x104>
    4f1c:	48 8d 3d bd c1 01 00 	lea    0x1c1bd(%rip),%rdi        # 210e0 <fwp_tape_workspace>
    4f23:	48 89 04 24          	mov    %rax,(%rsp)
    4f27:	e8 44 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4f2c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4f30:	48 8b 04 24          	mov    (%rsp),%rax
    4f34:	0f 29 05 a5 c1 01 00 	movaps %xmm0,0x1c1a5(%rip)        # 210e0 <fwp_tape_workspace>
    4f3b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4f40:	48 89 05 81 c1 01 00 	mov    %rax,0x1c181(%rip)        # 210c8 <fwp_tape_cached_bytes>
    4f47:	0f 29 05 a2 c1 01 00 	movaps %xmm0,0x1c1a2(%rip)        # 210f0 <fwp_tape_workspace+0x10>
    4f4e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4f53:	0f 29 05 a6 c1 01 00 	movaps %xmm0,0x1c1a6(%rip)        # 21100 <fwp_tape_workspace+0x20>
    4f5a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4f5e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f62:	48 89 15 a7 c1 01 00 	mov    %rdx,0x1c1a7(%rip)        # 21110 <fwp_tape_workspace+0x30>
    4f69:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f70:	00 
    4f71:	0f 11 03             	movups %xmm0,(%rbx)
    4f74:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f78:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f7c:	48 83 c4 10          	add    $0x10,%rsp
    4f80:	5b                   	pop    %rbx
    4f81:	c3                   	ret
    4f82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f88:	48 8d 3d 30 81 00 00 	lea    0x8130(%rip),%rdi        # d0bf <_IO_stdin_used+0xbf>
    4f8f:	e8 0c e4 ff ff       	call   33a0 <getenv@plt>
    4f94:	48 83 c4 10          	add    $0x10,%rsp
    4f98:	48 89 df             	mov    %rbx,%rdi
    4f9b:	5b                   	pop    %rbx
    4f9c:	e9 cf ef ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4fa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa8:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4fac:	0f 85 59 ff ff ff    	jne    4f0b <fwp_tape_buffers_release+0x7b>
    4fb2:	48 83 c4 10          	add    $0x10,%rsp
    4fb6:	48 89 df             	mov    %rbx,%rdi
    4fb9:	5b                   	pop    %rbx
    4fba:	e9 b1 ef ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4fbf:	90                   	nop

0000000000004fc0 <fwp_poll_events>:
    4fc0:	53                   	push   %rbx
    4fc1:	48 83 ec 20          	sub    $0x20,%rsp
    4fc5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4fcc:	00 00 
    4fce:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4fd3:	31 c0                	xor    %eax,%eax
    4fd5:	e8 36 f3 ff ff       	call   4310 <fwp_now_ns>
    4fda:	48 8b 1d 77 c7 01 00 	mov    0x1c777(%rip),%rbx        # 21758 <fwp_timers>
    4fe1:	48 85 db             	test   %rbx,%rbx
    4fe4:	0f 84 d6 00 00 00    	je     50c0 <fwp_poll_events+0x100>
    4fea:	48 89 c6             	mov    %rax,%rsi
    4fed:	48 89 da             	mov    %rbx,%rdx
    4ff0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4ff7:	eb 16                	jmp    500f <fwp_poll_events+0x4f>
    4ff9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5000:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5007:	48 89 c8             	mov    %rcx,%rax
    500a:	48 85 d2             	test   %rdx,%rdx
    500d:	74 31                	je     5040 <fwp_poll_events+0x80>
    500f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5013:	48 85 c0             	test   %rax,%rax
    5016:	78 e8                	js     5000 <fwp_poll_events+0x40>
    5018:	48 39 c1             	cmp    %rax,%rcx
    501b:	7c e3                	jl     5000 <fwp_poll_events+0x40>
    501d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5024:	48 85 d2             	test   %rdx,%rdx
    5027:	74 1c                	je     5045 <fwp_poll_events+0x85>
    5029:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    502d:	48 39 c1             	cmp    %rax,%rcx
    5030:	7c ce                	jl     5000 <fwp_poll_events+0x40>
    5032:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5039:	48 85 d2             	test   %rdx,%rdx
    503c:	75 d1                	jne    500f <fwp_poll_events+0x4f>
    503e:	66 90                	xchg   %ax,%ax
    5040:	48 85 c0             	test   %rax,%rax
    5043:	78 7b                	js     50c0 <fwp_poll_events+0x100>
    5045:	48 29 f0             	sub    %rsi,%rax
    5048:	48 89 c1             	mov    %rax,%rcx
    504b:	48 85 c0             	test   %rax,%rax
    504e:	0f 8e 9c 00 00 00    	jle    50f0 <fwp_poll_events+0x130>
    5054:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    505b:	de 1b 43 
    505e:	48 f7 ea             	imul   %rdx
    5061:	48 89 c8             	mov    %rcx,%rax
    5064:	48 c1 f8 3f          	sar    $0x3f,%rax
    5068:	48 c1 fa 12          	sar    $0x12,%rdx
    506c:	48 29 c2             	sub    %rax,%rdx
    506f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5076:	48 39 c1             	cmp    %rax,%rcx
    5079:	0f 95 c0             	setne  %al
    507c:	0f b6 c0             	movzbl %al,%eax
    507f:	48 01 d0             	add    %rdx,%rax
    5082:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5088:	0f 8f 32 01 00 00    	jg     51c0 <fwp_poll_events+0x200>
    508e:	48 85 c0             	test   %rax,%rax
    5091:	74 5d                	je     50f0 <fwp_poll_events+0x130>
    5093:	89 c1                	mov    %eax,%ecx
    5095:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    509c:	48 c1 e9 26          	shr    $0x26,%rcx
    50a0:	48 63 d1             	movslq %ecx,%rdx
    50a3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    50a9:	29 c8                	sub    %ecx,%eax
    50ab:	48 98                	cltq
    50ad:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    50b4:	e9 11 01 00 00       	jmp    51ca <fwp_poll_events+0x20a>
    50b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    50c0:	e8 ab eb ff ff       	call   3c70 <fwp_flush>
    50c5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    50ca:	be 01 00 00 00       	mov    $0x1,%esi
    50cf:	48 8b 0d 8a bf 00 00 	mov    0xbf8a(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    50d6:	48 8d 3d 63 86 00 00 	lea    0x8663(%rip),%rdi        # d740 <_IO_stdin_used+0x740>
    50dd:	e8 9e e5 ff ff       	call   3680 <fwrite@plt>
    50e2:	bf 65 00 00 00       	mov    $0x65,%edi
    50e7:	e8 84 e5 ff ff       	call   3670 <exit@plt>
    50ec:	0f 1f 40 00          	nopl   0x0(%rax)
    50f0:	e8 1b f2 ff ff       	call   4310 <fwp_now_ns>
    50f5:	48 89 c1             	mov    %rax,%rcx
    50f8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fc:	eb 44                	jmp    5142 <fwp_poll_events+0x182>
    50fe:	66 90                	xchg   %ax,%ax
    5100:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5104:	75 33                	jne    5139 <fwp_poll_events+0x179>
    5106:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    510a:	75 2d                	jne    5139 <fwp_poll_events+0x179>
    510c:	48 8b 05 4d c6 01 00 	mov    0x1c64d(%rip),%rax        # 21760 <fwp_ready_tail>
    5113:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5117:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    511e:	00 00 00 00 
    5122:	48 85 c0             	test   %rax,%rax
    5125:	0f 84 05 01 00 00    	je     5230 <fwp_poll_events+0x270>
    512b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5132:	48 89 15 27 c6 01 00 	mov    %rdx,0x1c627(%rip)        # 21760 <fwp_ready_tail>
    5139:	48 85 db             	test   %rbx,%rbx
    513c:	0f 84 be 00 00 00    	je     5200 <fwp_poll_events+0x240>
    5142:	48 89 da             	mov    %rbx,%rdx
    5145:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    514c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5150:	7f e7                	jg     5139 <fwp_poll_events+0x179>
    5152:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5156:	74 2e                	je     5186 <fwp_poll_events+0x1c6>
    5158:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    515f:	48 85 c0             	test   %rax,%rax
    5162:	0f 84 b8 00 00 00    	je     5220 <fwp_poll_events+0x260>
    5168:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    516f:	48 85 db             	test   %rbx,%rbx
    5172:	74 07                	je     517b <fwp_poll_events+0x1bb>
    5174:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    517b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    517f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5186:	48 8b 42 60          	mov    0x60(%rdx),%rax
    518a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    518e:	48 85 c0             	test   %rax,%rax
    5191:	0f 84 69 ff ff ff    	je     5100 <fwp_poll_events+0x140>
    5197:	48 39 c8             	cmp    %rcx,%rax
    519a:	0f 8f 60 ff ff ff    	jg     5100 <fwp_poll_events+0x140>
    51a0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    51a4:	0f 85 56 ff ff ff    	jne    5100 <fwp_poll_events+0x140>
    51aa:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    51ae:	75 89                	jne    5139 <fwp_poll_events+0x179>
    51b0:	48 89 d7             	mov    %rdx,%rdi
    51b3:	e8 f8 ee ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    51b8:	e9 43 ff ff ff       	jmp    5100 <fwp_poll_events+0x140>
    51bd:	0f 1f 00             	nopl   (%rax)
    51c0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    51c5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    51ca:	48 89 e7             	mov    %rsp,%rdi
    51cd:	31 f6                	xor    %esi,%esi
    51cf:	48 89 14 24          	mov    %rdx,(%rsp)
    51d3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    51d8:	e8 c3 e2 ff ff       	call   34a0 <nanosleep@plt>
    51dd:	48 8b 1d 74 c5 01 00 	mov    0x1c574(%rip),%rbx        # 21758 <fwp_timers>
    51e4:	e8 27 f1 ff ff       	call   4310 <fwp_now_ns>
    51e9:	48 89 c1             	mov    %rax,%rcx
    51ec:	48 85 db             	test   %rbx,%rbx
    51ef:	0f 85 03 ff ff ff    	jne    50f8 <fwp_poll_events+0x138>
    51f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51fc:	00 00 00 00 
    5200:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5205:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    520c:	00 00 
    520e:	75 2c                	jne    523c <fwp_poll_events+0x27c>
    5210:	48 83 c4 20          	add    $0x20,%rsp
    5214:	5b                   	pop    %rbx
    5215:	c3                   	ret
    5216:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    521d:	00 00 00 
    5220:	48 89 1d 31 c5 01 00 	mov    %rbx,0x1c531(%rip)        # 21758 <fwp_timers>
    5227:	e9 43 ff ff ff       	jmp    516f <fwp_poll_events+0x1af>
    522c:	0f 1f 40 00          	nopl   0x0(%rax)
    5230:	48 89 15 31 c5 01 00 	mov    %rdx,0x1c531(%rip)        # 21768 <fwp_ready_head>
    5237:	e9 f6 fe ff ff       	jmp    5132 <fwp_poll_events+0x172>
    523c:	e8 1f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    5241:	0f 1f 40 00          	nopl   0x0(%rax)
    5245:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    524c:	00 00 00 00 

0000000000005250 <fwp_rc_wide_dup>:
    5250:	48 89 fa             	mov    %rdi,%rdx
    5253:	48 8d 35 46 c5 01 00 	lea    0x1c546(%rip),%rsi        # 217a0 <fwp_heap>
    525a:	48 83 ec 18          	sub    $0x18,%rsp
    525e:	48 89 f9             	mov    %rdi,%rcx
    5261:	48 c1 ea 11          	shr    $0x11,%rdx
    5265:	48 31 fa             	xor    %rdi,%rdx
    5268:	48 89 d0             	mov    %rdx,%rax
    526b:	48 c1 e8 09          	shr    $0x9,%rax
    526f:	48 31 c2             	xor    %rax,%rdx
    5272:	0f b6 d2             	movzbl %dl,%edx
    5275:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    527c:	00 
    527d:	49 8b 00             	mov    (%r8),%rax
    5280:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5287:	00 00 
    5289:	75 21                	jne    52ac <fwp_rc_wide_dup+0x5c>
    528b:	e9 98 00 00 00       	jmp    5328 <fwp_rc_wide_dup+0xd8>
    5290:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    529c:	00 00 00 00 
    52a0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    52a4:	48 85 d2             	test   %rdx,%rdx
    52a7:	74 2f                	je     52d8 <fwp_rc_wide_dup+0x88>
    52a9:	48 89 d0             	mov    %rdx,%rax
    52ac:	48 3b 08             	cmp    (%rax),%rcx
    52af:	75 ef                	jne    52a0 <fwp_rc_wide_dup+0x50>
    52b1:	80 39 fe             	cmpb   $0xfe,(%rcx)
    52b4:	74 7c                	je     5332 <fwp_rc_wide_dup+0xe2>
    52b6:	48 8b 50 08          	mov    0x8(%rax),%rdx
    52ba:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    52be:	0f 84 91 00 00 00    	je     5355 <fwp_rc_wide_dup+0x105>
    52c4:	48 83 c2 01          	add    $0x1,%rdx
    52c8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    52cc:	48 83 c4 18          	add    $0x18,%rsp
    52d0:	c3                   	ret
    52d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52d8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    52dc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    52df:	75 68                	jne    5349 <fwp_rc_wide_dup+0xf9>
    52e1:	bf 18 00 00 00       	mov    $0x18,%edi
    52e6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52eb:	4c 89 04 24          	mov    %r8,(%rsp)
    52ef:	e8 bc e2 ff ff       	call   35b0 <malloc@plt>
    52f4:	4c 8b 04 24          	mov    (%rsp),%r8
    52f8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52fd:	48 85 c0             	test   %rax,%rax
    5300:	74 5f                	je     5361 <fwp_rc_wide_dup+0x111>
    5302:	48 89 08             	mov    %rcx,(%rax)
    5305:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    530c:	00 
    530d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5314:	00 
    5315:	49 89 00             	mov    %rax,(%r8)
    5318:	c6 01 ff             	movb   $0xff,(%rcx)
    531b:	48 83 05 c5 e0 01 00 	addq   $0x1,0x1e0c5(%rip)        # 233e8 <fwp_heap+0x1c48>
    5322:	01 
    5323:	48 83 c4 18          	add    $0x18,%rsp
    5327:	c3                   	ret
    5328:	80 3f fe             	cmpb   $0xfe,(%rdi)
    532b:	75 13                	jne    5340 <fwp_rc_wide_dup+0xf0>
    532d:	48 85 c0             	test   %rax,%rax
    5330:	74 af                	je     52e1 <fwp_rc_wide_dup+0x91>
    5332:	48 8d 3d 37 84 00 00 	lea    0x8437(%rip),%rdi        # d770 <_IO_stdin_used+0x770>
    5339:	e8 62 ee ff ff       	call   41a0 <fwp_trap>
    533e:	66 90                	xchg   %ax,%ax
    5340:	48 85 c0             	test   %rax,%rax
    5343:	0f 85 6d ff ff ff    	jne    52b6 <fwp_rc_wide_dup+0x66>
    5349:	48 8d 3d 48 84 00 00 	lea    0x8448(%rip),%rdi        # d798 <_IO_stdin_used+0x798>
    5350:	e8 4b ee ff ff       	call   41a0 <fwp_trap>
    5355:	48 8d 3d 74 7d 00 00 	lea    0x7d74(%rip),%rdi        # d0d0 <_IO_stdin_used+0xd0>
    535c:	e8 3f ee ff ff       	call   41a0 <fwp_trap>
    5361:	e8 4a e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5366:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    536d:	00 00 00 

0000000000005370 <fwp_rc_forget_slot>:
    5370:	80 3f ff             	cmpb   $0xff,(%rdi)
    5373:	74 0b                	je     5380 <fwp_rc_forget_slot+0x10>
    5375:	c3                   	ret
    5376:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    537d:	00 00 00 
    5380:	48 89 f8             	mov    %rdi,%rax
    5383:	48 83 ec 08          	sub    $0x8,%rsp
    5387:	48 89 fa             	mov    %rdi,%rdx
    538a:	48 c1 e8 11          	shr    $0x11,%rax
    538e:	48 31 f8             	xor    %rdi,%rax
    5391:	48 89 c1             	mov    %rax,%rcx
    5394:	48 c1 e9 09          	shr    $0x9,%rcx
    5398:	48 31 c8             	xor    %rcx,%rax
    539b:	48 8d 0d fe c3 01 00 	lea    0x1c3fe(%rip),%rcx        # 217a0 <fwp_heap>
    53a2:	0f b6 c0             	movzbl %al,%eax
    53a5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    53ac:	00 
    53ad:	48 85 ff             	test   %rdi,%rdi
    53b0:	74 3c                	je     53ee <fwp_rc_forget_slot+0x7e>
    53b2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    53b9:	00 
    53ba:	48 8b 01             	mov    (%rcx),%rax
    53bd:	eb 11                	jmp    53d0 <fwp_rc_forget_slot+0x60>
    53bf:	90                   	nop
    53c0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    53c4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    53c8:	48 85 ff             	test   %rdi,%rdi
    53cb:	74 21                	je     53ee <fwp_rc_forget_slot+0x7e>
    53cd:	48 89 f8             	mov    %rdi,%rax
    53d0:	48 3b 10             	cmp    (%rax),%rdx
    53d3:	75 eb                	jne    53c0 <fwp_rc_forget_slot+0x50>
    53d5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    53d9:	48 89 01             	mov    %rax,(%rcx)
    53dc:	e8 df df ff ff       	call   33c0 <free@plt>
    53e1:	48 83 2d ff df 01 00 	subq   $0x1,0x1dfff(%rip)        # 233e8 <fwp_heap+0x1c48>
    53e8:	01 
    53e9:	48 83 c4 08          	add    $0x8,%rsp
    53ed:	c3                   	ret
    53ee:	48 8d 3d a3 83 00 00 	lea    0x83a3(%rip),%rdi        # d798 <_IO_stdin_used+0x798>
    53f5:	e8 a6 ed ff ff       	call   41a0 <fwp_trap>
    53fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005400 <fwp_rc_prepare_chunk>:
    5400:	48 83 3d e0 df 01 00 	cmpq   $0x0,0x1dfe0(%rip)        # 233e8 <fwp_heap+0x1c48>
    5407:	00 
    5408:	41 54                	push   %r12
    540a:	49 89 f4             	mov    %rsi,%r12
    540d:	55                   	push   %rbp
    540e:	48 89 fd             	mov    %rdi,%rbp
    5411:	53                   	push   %rbx
    5412:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5415:	0f 84 7d 00 00 00    	je     5498 <fwp_rc_prepare_chunk+0x98>
    541b:	31 db                	xor    %ebx,%ebx
    541d:	85 c0                	test   %eax,%eax
    541f:	75 5f                	jne    5480 <fwp_rc_prepare_chunk+0x80>
    5421:	48 85 f6             	test   %rsi,%rsi
    5424:	74 7c                	je     54a2 <fwp_rc_prepare_chunk+0xa2>
    5426:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    542a:	e8 91 df ff ff       	call   33c0 <free@plt>
    542f:	90                   	nop
    5430:	be 01 00 00 00       	mov    $0x1,%esi
    5435:	4c 89 e7             	mov    %r12,%rdi
    5438:	e8 e3 e0 ff ff       	call   3520 <calloc@plt>
    543d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5441:	48 85 c0             	test   %rax,%rax
    5444:	0f 85 87 00 00 00    	jne    54d1 <fwp_rc_prepare_chunk+0xd1>
    544a:	e8 61 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    544f:	90                   	nop
    5450:	e8 1b ff ff ff       	call   5370 <fwp_rc_forget_slot>
    5455:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5458:	48 83 c3 01          	add    $0x1,%rbx
    545c:	48 39 c3             	cmp    %rax,%rbx
    545f:	73 37                	jae    5498 <fwp_rc_prepare_chunk+0x98>
    5461:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5468:	00 00 
    546a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5471:	00 00 00 00 
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5484:	48 01 df             	add    %rbx,%rdi
    5487:	80 3f ff             	cmpb   $0xff,(%rdi)
    548a:	74 c4                	je     5450 <fwp_rc_prepare_chunk+0x50>
    548c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    548f:	48 83 c3 01          	add    $0x1,%rbx
    5493:	48 39 c3             	cmp    %rax,%rbx
    5496:	72 e8                	jb     5480 <fwp_rc_prepare_chunk+0x80>
    5498:	49 39 c4             	cmp    %rax,%r12
    549b:	75 13                	jne    54b0 <fwp_rc_prepare_chunk+0xb0>
    549d:	4d 85 e4             	test   %r12,%r12
    54a0:	75 46                	jne    54e8 <fwp_rc_prepare_chunk+0xe8>
    54a2:	5b                   	pop    %rbx
    54a3:	5d                   	pop    %rbp
    54a4:	41 5c                	pop    %r12
    54a6:	c3                   	ret
    54a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    54ae:	00 00 
    54b0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    54b4:	48 29 05 35 df 01 00 	sub    %rax,0x1df35(%rip)        # 233f0 <fwp_heap+0x1c50>
    54bb:	e8 00 df ff ff       	call   33c0 <free@plt>
    54c0:	4d 85 e4             	test   %r12,%r12
    54c3:	0f 85 67 ff ff ff    	jne    5430 <fwp_rc_prepare_chunk+0x30>
    54c9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    54d0:	00 
    54d1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    54d5:	5b                   	pop    %rbx
    54d6:	4c 01 25 13 df 01 00 	add    %r12,0x1df13(%rip)        # 233f0 <fwp_heap+0x1c50>
    54dd:	5d                   	pop    %rbp
    54de:	41 5c                	pop    %r12
    54e0:	c3                   	ret
    54e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54e8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    54ec:	5b                   	pop    %rbx
    54ed:	4c 89 e2             	mov    %r12,%rdx
    54f0:	31 f6                	xor    %esi,%esi
    54f2:	5d                   	pop    %rbp
    54f3:	41 5c                	pop    %r12
    54f5:	e9 c6 df ff ff       	jmp    34c0 <memset@plt>
    54fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005500 <fwp_heap_refill>:
    5500:	41 56                	push   %r14
    5502:	41 89 d6             	mov    %edx,%r14d
    5505:	41 55                	push   %r13
    5507:	41 89 f5             	mov    %esi,%r13d
    550a:	41 54                	push   %r12
    550c:	49 89 fc             	mov    %rdi,%r12
    550f:	bf 01 00 00 00       	mov    $0x1,%edi
    5514:	55                   	push   %rbp
    5515:	53                   	push   %rbx
    5516:	e8 c5 e8 ff ff       	call   3de0 <fwp_heap_chunks>
    551b:	48 89 c3             	mov    %rax,%rbx
    551e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5522:	48 8b 05 6f d6 01 00 	mov    0x1d66f(%rip),%rax        # 22b98 <fwp_heap+0x13f8>
    5529:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    552d:	48 8d 05 6c c2 01 00 	lea    0x1c26c(%rip),%rax        # 217a0 <fwp_heap>
    5534:	31 d2                	xor    %edx,%edx
    5536:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    553a:	48 89 ef             	mov    %rbp,%rdi
    553d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5541:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5545:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    554c:	00 
    554d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5552:	f7 f1                	div    %ecx
    5554:	31 d2                	xor    %edx,%edx
    5556:	66 0f 6e c1          	movd   %ecx,%xmm0
    555a:	66 0f 6e c8          	movd   %eax,%xmm1
    555e:	89 c6                	mov    %eax,%esi
    5560:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5565:	48 01 c8             	add    %rcx,%rax
    5568:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    556c:	48 f7 f1             	div    %rcx
    556f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5574:	89 45 18             	mov    %eax,0x18(%rbp)
    5577:	e8 84 fe ff ff       	call   5400 <fwp_rc_prepare_chunk>
    557c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    557f:	48 89 d8             	mov    %rbx,%rax
    5582:	48 c1 e0 10          	shl    $0x10,%rax
    5586:	48 03 05 c3 d5 01 00 	add    0x1d5c3(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    558d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5591:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5596:	8b 55 08             	mov    0x8(%rbp),%edx
    5599:	48 0f af d1          	imul   %rcx,%rdx
    559d:	48 01 c2             	add    %rax,%rdx
    55a0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    55a5:	5b                   	pop    %rbx
    55a6:	5d                   	pop    %rbp
    55a7:	41 5c                	pop    %r12
    55a9:	41 5d                	pop    %r13
    55ab:	41 5e                	pop    %r14
    55ad:	c3                   	ret
    55ae:	66 90                	xchg   %ax,%ax

00000000000055b0 <fwp_mem_free>:
    55b0:	48 85 ff             	test   %rdi,%rdi
    55b3:	0f 84 17 02 00 00    	je     57d0 <fwp_mem_free+0x220>
    55b9:	48 8b 35 90 d5 01 00 	mov    0x1d590(%rip),%rsi        # 22b50 <fwp_heap+0x13b0>
    55c0:	48 8b 05 b1 d5 01 00 	mov    0x1d5b1(%rip),%rax        # 22b78 <fwp_heap+0x13d8>
    55c7:	48 89 fa             	mov    %rdi,%rdx
    55ca:	48 29 f2             	sub    %rsi,%rdx
    55cd:	48 c1 e0 10          	shl    $0x10,%rax
    55d1:	48 39 c2             	cmp    %rax,%rdx
    55d4:	0f 83 f6 01 00 00    	jae    57d0 <fwp_mem_free+0x220>
    55da:	49 89 d1             	mov    %rdx,%r9
    55dd:	49 c1 e9 10          	shr    $0x10,%r9
    55e1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    55e5:	48 c1 e0 03          	shl    $0x3,%rax
    55e9:	49 89 c0             	mov    %rax,%r8
    55ec:	4c 03 05 a5 d5 01 00 	add    0x1d5a5(%rip),%r8        # 22b98 <fwp_heap+0x13f8>
    55f3:	0f 84 d7 01 00 00    	je     57d0 <fwp_mem_free+0x220>
    55f9:	48 83 ec 38          	sub    $0x38,%rsp
    55fd:	48 89 f9             	mov    %rdi,%rcx
    5600:	41 0f b6 38          	movzbl (%r8),%edi
    5604:	40 80 ff 01          	cmp    $0x1,%dil
    5608:	74 16                	je     5620 <fwp_mem_free+0x70>
    560a:	40 80 ff 02          	cmp    $0x2,%dil
    560e:	0f 84 94 00 00 00    	je     56a8 <fwp_mem_free+0xf8>
    5614:	48 83 c4 38          	add    $0x38,%rsp
    5618:	c3                   	ret
    5619:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5620:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5624:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5629:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    562e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5632:	4d 85 d2             	test   %r10,%r10
    5635:	74 1d                	je     5654 <fwp_mem_free+0xa4>
    5637:	0f b7 c1             	movzwl %cx,%eax
    563a:	31 d2                	xor    %edx,%edx
    563c:	48 f7 f7             	div    %rdi
    563f:	49 01 c2             	add    %rax,%r10
    5642:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5646:	0f 84 44 01 00 00    	je     5790 <fwp_mem_free+0x1e0>
    564c:	41 c6 02 00          	movb   $0x0,(%r10)
    5650:	41 8b 78 04          	mov    0x4(%r8),%edi
    5654:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    565b:	49 63 c1             	movslq %r9d,%rax
    565e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5662:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5666:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    566b:	f2 0f 58 05 6d d5 01 	addsd  0x1d56d(%rip),%xmm0        # 22be0 <fwp_heap+0x1440>
    5672:	00 
    5673:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5677:	48 8d 05 22 c1 01 00 	lea    0x1c122(%rip),%rax        # 217a0 <fwp_heap>
    567e:	48 01 d0             	add    %rdx,%rax
    5681:	48 8b 10             	mov    (%rax),%rdx
    5684:	48 f7 d2             	not    %rdx
    5687:	48 89 11             	mov    %rdx,(%rcx)
    568a:	48 89 08             	mov    %rcx,(%rax)
    568d:	48 29 3d 2c d5 01 00 	sub    %rdi,0x1d52c(%rip)        # 22bc0 <fwp_heap+0x1420>
    5694:	f2 0f 11 05 44 d5 01 	movsd  %xmm0,0x1d544(%rip)        # 22be0 <fwp_heap+0x1440>
    569b:	00 
    569c:	48 83 c4 38          	add    $0x38,%rsp
    56a0:	c3                   	ret
    56a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56a8:	66 31 d2             	xor    %dx,%dx
    56ab:	48 01 d6             	add    %rdx,%rsi
    56ae:	48 39 f1             	cmp    %rsi,%rcx
    56b1:	0f 85 5d ff ff ff    	jne    5614 <fwp_mem_free+0x64>
    56b7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    56bb:	48 29 15 fe d4 01 00 	sub    %rdx,0x1d4fe(%rip)        # 22bc0 <fwp_heap+0x1420>
    56c2:	48 85 d2             	test   %rdx,%rdx
    56c5:	0f 88 a5 00 00 00    	js     5770 <fwp_mem_free+0x1c0>
    56cb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    56cf:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    56d4:	f2 0f 58 05 04 d5 01 	addsd  0x1d504(%rip),%xmm0        # 22be0 <fwp_heap+0x1440>
    56db:	00 
    56dc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    56e0:	f2 0f 11 05 f8 d4 01 	movsd  %xmm0,0x1d4f8(%rip)        # 22be0 <fwp_heap+0x1440>
    56e7:	00 
    56e8:	48 85 d2             	test   %rdx,%rdx
    56eb:	74 0c                	je     56f9 <fwp_mem_free+0x149>
    56ed:	80 3a ff             	cmpb   $0xff,(%rdx)
    56f0:	0f 84 db 00 00 00    	je     57d1 <fwp_mem_free+0x221>
    56f6:	c6 02 00             	movb   $0x0,(%rdx)
    56f9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    56fd:	48 85 c9             	test   %rcx,%rcx
    5700:	74 3e                	je     5740 <fwp_mem_free+0x190>
    5702:	48 8b 15 8f d4 01 00 	mov    0x1d48f(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    5709:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    570d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5711:	48 01 d0             	add    %rdx,%rax
    5714:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5718:	48 89 d6             	mov    %rdx,%rsi
    571b:	48 29 c6             	sub    %rax,%rsi
    571e:	83 e6 08             	and    $0x8,%esi
    5721:	74 0d                	je     5730 <fwp_mem_free+0x180>
    5723:	c6 00 00             	movb   $0x0,(%rax)
    5726:	48 83 c0 28          	add    $0x28,%rax
    572a:	48 39 c2             	cmp    %rax,%rdx
    572d:	74 11                	je     5740 <fwp_mem_free+0x190>
    572f:	90                   	nop
    5730:	c6 00 00             	movb   $0x0,(%rax)
    5733:	48 83 c0 50          	add    $0x50,%rax
    5737:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    573b:	48 39 c2             	cmp    %rax,%rdx
    573e:	75 f0                	jne    5730 <fwp_mem_free+0x180>
    5740:	48 01 0d 89 d4 01 00 	add    %rcx,0x1d489(%rip)        # 22bd0 <fwp_heap+0x1430>
    5747:	4c 3b 0d 42 d4 01 00 	cmp    0x1d442(%rip),%r9        # 22b90 <fwp_heap+0x13f0>
    574e:	73 07                	jae    5757 <fwp_mem_free+0x1a7>
    5750:	4c 89 0d 39 d4 01 00 	mov    %r9,0x1d439(%rip)        # 22b90 <fwp_heap+0x13f0>
    5757:	4c 3b 0d 2a d4 01 00 	cmp    0x1d42a(%rip),%r9        # 22b88 <fwp_heap+0x13e8>
    575e:	0f 83 b0 fe ff ff    	jae    5614 <fwp_mem_free+0x64>
    5764:	4c 89 0d 1d d4 01 00 	mov    %r9,0x1d41d(%rip)        # 22b88 <fwp_heap+0x13e8>
    576b:	e9 a4 fe ff ff       	jmp    5614 <fwp_mem_free+0x64>
    5770:	48 89 d1             	mov    %rdx,%rcx
    5773:	83 e2 01             	and    $0x1,%edx
    5776:	66 0f ef c0          	pxor   %xmm0,%xmm0
    577a:	48 d1 e9             	shr    $1,%rcx
    577d:	48 09 d1             	or     %rdx,%rcx
    5780:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5785:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5789:	e9 46 ff ff ff       	jmp    56d4 <fwp_mem_free+0x124>
    578e:	66 90                	xchg   %ax,%ax
    5790:	4c 89 d7             	mov    %r10,%rdi
    5793:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5798:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    579d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    57a2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    57a6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    57ab:	e8 c0 fb ff ff       	call   5370 <fwp_rc_forget_slot>
    57b0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    57b5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    57ba:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    57bf:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    57c4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    57c9:	e9 7e fe ff ff       	jmp    564c <fwp_mem_free+0x9c>
    57ce:	66 90                	xchg   %ax,%ax
    57d0:	c3                   	ret
    57d1:	48 89 d7             	mov    %rdx,%rdi
    57d4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    57d9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    57de:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    57e3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    57e8:	e8 83 fb ff ff       	call   5370 <fwp_rc_forget_slot>
    57ed:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    57f2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    57f7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    57fc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5801:	e9 f0 fe ff ff       	jmp    56f6 <fwp_mem_free+0x146>
    5806:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    580d:	00 00 00 

0000000000005810 <fwp_heap_alloc_big>:
    5810:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5817:	00 00 40 
    581a:	41 57                	push   %r15
    581c:	41 56                	push   %r14
    581e:	41 55                	push   %r13
    5820:	41 54                	push   %r12
    5822:	55                   	push   %rbp
    5823:	53                   	push   %rbx
    5824:	48 83 ec 08          	sub    $0x8,%rsp
    5828:	48 39 f8             	cmp    %rdi,%rax
    582b:	0f 82 fa 00 00 00    	jb     592b <fwp_heap_alloc_big+0x11b>
    5831:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5838:	49 89 fd             	mov    %rdi,%r13
    583b:	41 89 f6             	mov    %esi,%r14d
    583e:	48 c1 ed 10          	shr    $0x10,%rbp
    5842:	48 89 ef             	mov    %rbp,%rdi
    5845:	e8 96 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    584a:	be 01 00 00 00       	mov    $0x1,%esi
    584f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5853:	49 89 c4             	mov    %rax,%r12
    5856:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    585d:	00 
    585e:	48 03 3d 33 d3 01 00 	add    0x1d333(%rip),%rdi        # 22b98 <fwp_heap+0x13f8>
    5865:	c6 07 02             	movb   $0x2,(%rdi)
    5868:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    586c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    586f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5873:	e8 88 fb ff ff       	call   5400 <fwp_rc_prepare_chunk>
    5878:	48 83 fd 01          	cmp    $0x1,%rbp
    587c:	76 47                	jbe    58c5 <fwp_heap_alloc_big+0xb5>
    587e:	4c 01 e5             	add    %r12,%rbp
    5881:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5888:	00 
    5889:	4c 8d 3d 10 bf 01 00 	lea    0x1bf10(%rip),%r15        # 217a0 <fwp_heap>
    5890:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5895:	49 c1 e6 03          	shl    $0x3,%r14
    5899:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    58a0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    58a7:	31 f6                	xor    %esi,%esi
    58a9:	48 01 dd             	add    %rbx,%rbp
    58ac:	48 83 c3 28          	add    $0x28,%rbx
    58b0:	48 89 ef             	mov    %rbp,%rdi
    58b3:	e8 48 fb ff ff       	call   5400 <fwp_rc_prepare_chunk>
    58b8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    58bc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    58c0:	49 39 de             	cmp    %rbx,%r14
    58c3:	75 db                	jne    58a0 <fwp_heap_alloc_big+0x90>
    58c5:	49 c1 e4 10          	shl    $0x10,%r12
    58c9:	4c 03 25 80 d2 01 00 	add    0x1d280(%rip),%r12        # 22b50 <fwp_heap+0x13b0>
    58d0:	4c 89 ea             	mov    %r13,%rdx
    58d3:	31 f6                	xor    %esi,%esi
    58d5:	4c 89 e7             	mov    %r12,%rdi
    58d8:	e8 e3 db ff ff       	call   34c0 <memset@plt>
    58dd:	4c 89 e8             	mov    %r13,%rax
    58e0:	48 03 05 d9 d2 01 00 	add    0x1d2d9(%rip),%rax        # 22bc0 <fwp_heap+0x1420>
    58e7:	72 42                	jb     592b <fwp_heap_alloc_big+0x11b>
    58e9:	48 39 05 d8 d2 01 00 	cmp    %rax,0x1d2d8(%rip)        # 22bc8 <fwp_heap+0x1428>
    58f0:	48 89 05 c9 d2 01 00 	mov    %rax,0x1d2c9(%rip)        # 22bc0 <fwp_heap+0x1420>
    58f7:	73 07                	jae    5900 <fwp_heap_alloc_big+0xf0>
    58f9:	48 89 05 c8 d2 01 00 	mov    %rax,0x1d2c8(%rip)        # 22bc8 <fwp_heap+0x1428>
    5900:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5904:	4c 89 e0             	mov    %r12,%rax
    5907:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    590c:	f2 0f 58 05 c4 d2 01 	addsd  0x1d2c4(%rip),%xmm0        # 22bd8 <fwp_heap+0x1438>
    5913:	00 
    5914:	f2 0f 11 05 bc d2 01 	movsd  %xmm0,0x1d2bc(%rip)        # 22bd8 <fwp_heap+0x1438>
    591b:	00 
    591c:	48 83 c4 08          	add    $0x8,%rsp
    5920:	5b                   	pop    %rbx
    5921:	5d                   	pop    %rbp
    5922:	41 5c                	pop    %r12
    5924:	41 5d                	pop    %r13
    5926:	41 5e                	pop    %r14
    5928:	41 5f                	pop    %r15
    592a:	c3                   	ret
    592b:	e8 80 e3 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005930 <fwp_heap_alloc_slow>:
    5930:	53                   	push   %rbx
    5931:	48 89 f9             	mov    %rdi,%rcx
    5934:	41 89 f1             	mov    %esi,%r9d
    5937:	48 83 ec 10          	sub    $0x10,%rsp
    593b:	8b 05 03 d2 01 00    	mov    0x1d203(%rip),%eax        # 22b44 <fwp_heap+0x13a4>
    5941:	85 c0                	test   %eax,%eax
    5943:	0f 84 c7 00 00 00    	je     5a10 <fwp_heap_alloc_slow+0xe0>
    5949:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5950:	0f 87 dd 00 00 00    	ja     5a33 <fwp_heap_alloc_slow+0x103>
    5956:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    595a:	48 8d 3d 3f be 01 00 	lea    0x1be3f(%rip),%rdi        # 217a0 <fwp_heap>
    5961:	49 63 f1             	movslq %r9d,%rsi
    5964:	48 c1 e8 04          	shr    $0x4,%rax
    5968:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    596f:	00 00 
    5971:	41 0f b6 c2          	movzbl %r10b,%eax
    5975:	4c 89 d2             	mov    %r10,%rdx
    5978:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    597c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5983:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    598a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    598e:	48 01 f8             	add    %rdi,%rax
    5991:	4c 8b 00             	mov    (%rax),%r8
    5994:	4d 85 c0             	test   %r8,%r8
    5997:	0f 84 ab 00 00 00    	je     5a48 <fwp_heap_alloc_slow+0x118>
    599d:	49 8b 10             	mov    (%r8),%rdx
    59a0:	48 f7 d2             	not    %rdx
    59a3:	48 89 10             	mov    %rdx,(%rax)
    59a6:	41 83 f9 01          	cmp    $0x1,%r9d
    59aa:	4c 89 c7             	mov    %r8,%rdi
    59ad:	48 0f 45 cb          	cmovne %rbx,%rcx
    59b1:	31 f6                	xor    %esi,%esi
    59b3:	48 89 ca             	mov    %rcx,%rdx
    59b6:	e8 05 db ff ff       	call   34c0 <memset@plt>
    59bb:	49 89 c0             	mov    %rax,%r8
    59be:	48 89 d8             	mov    %rbx,%rax
    59c1:	48 03 05 f8 d1 01 00 	add    0x1d1f8(%rip),%rax        # 22bc0 <fwp_heap+0x1420>
    59c8:	0f 82 d9 00 00 00    	jb     5aa7 <fwp_heap_alloc_slow+0x177>
    59ce:	48 39 05 f3 d1 01 00 	cmp    %rax,0x1d1f3(%rip)        # 22bc8 <fwp_heap+0x1428>
    59d5:	48 89 05 e4 d1 01 00 	mov    %rax,0x1d1e4(%rip)        # 22bc0 <fwp_heap+0x1420>
    59dc:	73 07                	jae    59e5 <fwp_heap_alloc_slow+0xb5>
    59de:	48 89 05 e3 d1 01 00 	mov    %rax,0x1d1e3(%rip)        # 22bc8 <fwp_heap+0x1428>
    59e5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    59e9:	4c 89 c0             	mov    %r8,%rax
    59ec:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    59f1:	f2 0f 58 05 df d1 01 	addsd  0x1d1df(%rip),%xmm0        # 22bd8 <fwp_heap+0x1438>
    59f8:	00 
    59f9:	f2 0f 11 05 d7 d1 01 	movsd  %xmm0,0x1d1d7(%rip)        # 22bd8 <fwp_heap+0x1438>
    5a00:	00 
    5a01:	48 83 c4 10          	add    $0x10,%rsp
    5a05:	5b                   	pop    %rbx
    5a06:	c3                   	ret
    5a07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5a0e:	00 00 
    5a10:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5a14:	48 89 3c 24          	mov    %rdi,(%rsp)
    5a18:	e8 13 f1 ff ff       	call   4b30 <fwp_heap_init>
    5a1d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5a21:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5a26:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5a2d:	0f 86 23 ff ff ff    	jbe    5956 <fwp_heap_alloc_slow+0x26>
    5a33:	48 83 c4 10          	add    $0x10,%rsp
    5a37:	44 89 ce             	mov    %r9d,%esi
    5a3a:	48 89 cf             	mov    %rcx,%rdi
    5a3d:	5b                   	pop    %rbx
    5a3e:	e9 cd fd ff ff       	jmp    5810 <fwp_heap_alloc_big>
    5a43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5a48:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5a4c:	4d 85 c0             	test   %r8,%r8
    5a4f:	74 1f                	je     5a70 <fwp_heap_alloc_slow+0x140>
    5a51:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5a55:	4d 29 c3             	sub    %r8,%r11
    5a58:	49 39 db             	cmp    %rbx,%r11
    5a5b:	72 13                	jb     5a70 <fwp_heap_alloc_slow+0x140>
    5a5d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a61:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a65:	e9 3c ff ff ff       	jmp    59a6 <fwp_heap_alloc_slow+0x76>
    5a6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a70:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a77:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a7b:	44 89 ca             	mov    %r9d,%edx
    5a7e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a83:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a87:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a8b:	44 89 d6             	mov    %r10d,%esi
    5a8e:	48 01 c7             	add    %rax,%rdi
    5a91:	e8 6a fa ff ff       	call   5500 <fwp_heap_refill>
    5a96:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a9b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a9f:	49 89 c0             	mov    %rax,%r8
    5aa2:	e9 ff fe ff ff       	jmp    59a6 <fwp_heap_alloc_slow+0x76>
    5aa7:	e8 04 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5aac:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005ab0 <fwp_heap_alloc>:
    5ab0:	8b 05 8e d0 01 00    	mov    0x1d08e(%rip),%eax        # 22b44 <fwp_heap+0x13a4>
    5ab6:	48 89 fa             	mov    %rdi,%rdx
    5ab9:	89 f7                	mov    %esi,%edi
    5abb:	85 c0                	test   %eax,%eax
    5abd:	0f 84 f5 00 00 00    	je     5bb8 <fwp_heap_alloc+0x108>
    5ac3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5aca:	0f 87 e8 00 00 00    	ja     5bb8 <fwp_heap_alloc+0x108>
    5ad0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5ad4:	48 8d 05 c5 bc 01 00 	lea    0x1bcc5(%rip),%rax        # 217a0 <fwp_heap>
    5adb:	48 83 ec 18          	sub    $0x18,%rsp
    5adf:	41 89 f0             	mov    %esi,%r8d
    5ae2:	48 c1 e9 04          	shr    $0x4,%rcx
    5ae6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5aed:	00 
    5aee:	48 63 cf             	movslq %edi,%rcx
    5af1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5af8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5aff:	00 
    5b00:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5b04:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5b08:	48 01 c8             	add    %rcx,%rax
    5b0b:	48 8b 08             	mov    (%rax),%rcx
    5b0e:	48 85 c9             	test   %rcx,%rcx
    5b11:	74 6d                	je     5b80 <fwp_heap_alloc+0xd0>
    5b13:	48 8b 31             	mov    (%rcx),%rsi
    5b16:	48 f7 d6             	not    %rsi
    5b19:	48 89 30             	mov    %rsi,(%rax)
    5b1c:	41 83 f8 01          	cmp    $0x1,%r8d
    5b20:	48 89 cf             	mov    %rcx,%rdi
    5b23:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5b28:	49 0f 45 d1          	cmovne %r9,%rdx
    5b2c:	31 f6                	xor    %esi,%esi
    5b2e:	e8 8d d9 ff ff       	call   34c0 <memset@plt>
    5b33:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5b38:	48 89 c1             	mov    %rax,%rcx
    5b3b:	4c 89 c8             	mov    %r9,%rax
    5b3e:	48 03 05 7b d0 01 00 	add    0x1d07b(%rip),%rax        # 22bc0 <fwp_heap+0x1420>
    5b45:	72 7b                	jb     5bc2 <fwp_heap_alloc+0x112>
    5b47:	48 39 05 7a d0 01 00 	cmp    %rax,0x1d07a(%rip)        # 22bc8 <fwp_heap+0x1428>
    5b4e:	48 89 05 6b d0 01 00 	mov    %rax,0x1d06b(%rip)        # 22bc0 <fwp_heap+0x1420>
    5b55:	73 07                	jae    5b5e <fwp_heap_alloc+0xae>
    5b57:	48 89 05 6a d0 01 00 	mov    %rax,0x1d06a(%rip)        # 22bc8 <fwp_heap+0x1428>
    5b5e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b62:	48 89 c8             	mov    %rcx,%rax
    5b65:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b6a:	f2 0f 58 05 66 d0 01 	addsd  0x1d066(%rip),%xmm0        # 22bd8 <fwp_heap+0x1438>
    5b71:	00 
    5b72:	f2 0f 11 05 5e d0 01 	movsd  %xmm0,0x1d05e(%rip)        # 22bd8 <fwp_heap+0x1438>
    5b79:	00 
    5b7a:	48 83 c4 18          	add    $0x18,%rsp
    5b7e:	c3                   	ret
    5b7f:	90                   	nop
    5b80:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b84:	48 85 c9             	test   %rcx,%rcx
    5b87:	74 0c                	je     5b95 <fwp_heap_alloc+0xe5>
    5b89:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b8d:	48 29 ce             	sub    %rcx,%rsi
    5b90:	4c 39 ce             	cmp    %r9,%rsi
    5b93:	73 13                	jae    5ba8 <fwp_heap_alloc+0xf8>
    5b95:	89 fe                	mov    %edi,%esi
    5b97:	48 83 c4 18          	add    $0x18,%rsp
    5b9b:	48 89 d7             	mov    %rdx,%rdi
    5b9e:	e9 8d fd ff ff       	jmp    5930 <fwp_heap_alloc_slow>
    5ba3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ba8:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5bac:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5bb0:	e9 67 ff ff ff       	jmp    5b1c <fwp_heap_alloc+0x6c>
    5bb5:	0f 1f 00             	nopl   (%rax)
    5bb8:	89 fe                	mov    %edi,%esi
    5bba:	48 89 d7             	mov    %rdx,%rdi
    5bbd:	e9 6e fd ff ff       	jmp    5930 <fwp_heap_alloc_slow>
    5bc2:	e8 e9 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5bc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bce:	00 00 

0000000000005bd0 <fwp_apply>:
    5bd0:	55                   	push   %rbp
    5bd1:	48 89 f9             	mov    %rdi,%rcx
    5bd4:	48 89 e5             	mov    %rsp,%rbp
    5bd7:	41 57                	push   %r15
    5bd9:	41 56                	push   %r14
    5bdb:	41 55                	push   %r13
    5bdd:	41 89 f5             	mov    %esi,%r13d
    5be0:	41 54                	push   %r12
    5be2:	53                   	push   %rbx
    5be3:	48 83 ec 28          	sub    $0x28,%rsp
    5be7:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5bee:	00 00 
    5bf0:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5bf4:	49 89 d6             	mov    %rdx,%r14
    5bf7:	44 8b 09             	mov    (%rcx),%r9d
    5bfa:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5bfe:	49 89 e0             	mov    %rsp,%r8
    5c01:	49 c1 e1 05          	shl    $0x5,%r9
    5c05:	4c 03 0d ec d7 01 00 	add    0x1d7ec(%rip),%r9        # 233f8 <fwp_fns>
    5c0c:	41 8b 19             	mov    (%r9),%ebx
    5c0f:	45 85 e4             	test   %r12d,%r12d
    5c12:	75 2c                	jne    5c40 <fwp_apply+0x70>
    5c14:	41 39 dd             	cmp    %ebx,%r13d
    5c17:	72 27                	jb     5c40 <fwp_apply+0x70>
    5c19:	85 db                	test   %ebx,%ebx
    5c1b:	0f 84 a7 01 00 00    	je     5dc8 <fwp_apply+0x1f8>
    5c21:	4c 89 f7             	mov    %r14,%rdi
    5c24:	41 ff 51 08          	call   *0x8(%r9)
    5c28:	48 89 c1             	mov    %rax,%rcx
    5c2b:	41 39 dd             	cmp    %ebx,%r13d
    5c2e:	0f 84 6c 01 00 00    	je     5da0 <fwp_apply+0x1d0>
    5c34:	89 d8                	mov    %ebx,%eax
    5c36:	41 29 dd             	sub    %ebx,%r13d
    5c39:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5c3d:	eb b8                	jmp    5bf7 <fwp_apply+0x27>
    5c3f:	90                   	nop
    5c40:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5c45:	41 39 df             	cmp    %ebx,%r15d
    5c48:	0f 82 cc 00 00 00    	jb     5d1a <fwp_apply+0x14a>
    5c4e:	41 89 df             	mov    %ebx,%r15d
    5c51:	b8 01 00 00 00       	mov    $0x1,%eax
    5c56:	48 89 e2             	mov    %rsp,%rdx
    5c59:	45 29 e7             	sub    %r12d,%r15d
    5c5c:	85 db                	test   %ebx,%ebx
    5c5e:	0f 45 c3             	cmovne %ebx,%eax
    5c61:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5c68:	00 
    5c69:	48 c1 e8 04          	shr    $0x4,%rax
    5c6d:	48 c1 e0 04          	shl    $0x4,%rax
    5c71:	48 89 c6             	mov    %rax,%rsi
    5c74:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5c7b:	48 29 f2             	sub    %rsi,%rdx
    5c7e:	48 39 d4             	cmp    %rdx,%rsp
    5c81:	74 15                	je     5c98 <fwp_apply+0xc8>
    5c83:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5c8a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5c91:	00 00 
    5c93:	48 39 d4             	cmp    %rdx,%rsp
    5c96:	75 eb                	jne    5c83 <fwp_apply+0xb3>
    5c98:	25 ff 0f 00 00       	and    $0xfff,%eax
    5c9d:	48 29 c4             	sub    %rax,%rsp
    5ca0:	48 85 c0             	test   %rax,%rax
    5ca3:	0f 85 49 01 00 00    	jne    5df2 <fwp_apply+0x222>
    5ca9:	45 89 e2             	mov    %r12d,%r10d
    5cac:	48 89 e6             	mov    %rsp,%rsi
    5caf:	48 89 e7             	mov    %rsp,%rdi
    5cb2:	31 c0                	xor    %eax,%eax
    5cb4:	49 c1 e2 03          	shl    $0x3,%r10
    5cb8:	45 85 e4             	test   %r12d,%r12d
    5cbb:	74 15                	je     5cd2 <fwp_apply+0x102>
    5cbd:	0f 1f 00             	nopl   (%rax)
    5cc0:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5cc5:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5cc9:	48 83 c0 08          	add    $0x8,%rax
    5ccd:	4c 39 d0             	cmp    %r10,%rax
    5cd0:	75 ee                	jne    5cc0 <fwp_apply+0xf0>
    5cd2:	45 85 ff             	test   %r15d,%r15d
    5cd5:	0f 84 f4 00 00 00    	je     5dcf <fwp_apply+0x1ff>
    5cdb:	44 89 fa             	mov    %r15d,%edx
    5cde:	4c 89 f0             	mov    %r14,%rax
    5ce1:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5ce5:	44 89 e2             	mov    %r12d,%edx
    5ce8:	66 90                	xchg   %ax,%ax
    5cea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5cf1:	00 00 00 00 
    5cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5cfc:	00 00 00 00 
    5d00:	4c 8b 10             	mov    (%rax),%r10
    5d03:	89 d1                	mov    %edx,%ecx
    5d05:	48 83 c0 08          	add    $0x8,%rax
    5d09:	83 c2 01             	add    $0x1,%edx
    5d0c:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5d10:	4c 39 d8             	cmp    %r11,%rax
    5d13:	75 eb                	jne    5d00 <fwp_apply+0x130>
    5d15:	e9 b5 00 00 00       	jmp    5dcf <fwp_apply+0x1ff>
    5d1a:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5d1e:	be 02 00 00 00       	mov    $0x2,%esi
    5d23:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5d27:	48 c1 e7 03          	shl    $0x3,%rdi
    5d2b:	e8 80 fd ff ff       	call   5ab0 <fwp_heap_alloc>
    5d30:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5d34:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5d39:	48 89 c3             	mov    %rax,%rbx
    5d3c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5d40:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5d44:	66 0f d6 00          	movq   %xmm0,(%rax)
    5d48:	45 85 e4             	test   %r12d,%r12d
    5d4b:	74 14                	je     5d61 <fwp_apply+0x191>
    5d4d:	44 89 e2             	mov    %r12d,%edx
    5d50:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5d54:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5d58:	48 c1 e2 03          	shl    $0x3,%rdx
    5d5c:	e8 af d8 ff ff       	call   3610 <memmove@plt>
    5d61:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5d65:	45 85 ed             	test   %r13d,%r13d
    5d68:	74 2e                	je     5d98 <fwp_apply+0x1c8>
    5d6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d71:	00 00 00 00 
    5d75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d7c:	00 00 00 00 
    5d80:	49 8b 16             	mov    (%r14),%rdx
    5d83:	44 89 e0             	mov    %r12d,%eax
    5d86:	49 83 c6 08          	add    $0x8,%r14
    5d8a:	41 83 c4 01          	add    $0x1,%r12d
    5d8e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5d93:	49 39 ce             	cmp    %rcx,%r14
    5d96:	75 e8                	jne    5d80 <fwp_apply+0x1b0>
    5d98:	48 89 d9             	mov    %rbx,%rcx
    5d9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5da0:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5da4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5dab:	00 00 
    5dad:	75 4e                	jne    5dfd <fwp_apply+0x22d>
    5daf:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5db3:	48 89 c8             	mov    %rcx,%rax
    5db6:	5b                   	pop    %rbx
    5db7:	41 5c                	pop    %r12
    5db9:	41 5d                	pop    %r13
    5dbb:	41 5e                	pop    %r14
    5dbd:	41 5f                	pop    %r15
    5dbf:	5d                   	pop    %rbp
    5dc0:	c3                   	ret
    5dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5dc8:	45 31 ff             	xor    %r15d,%r15d
    5dcb:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    5dcf:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    5dd3:	41 ff 51 08          	call   *0x8(%r9)
    5dd7:	48 89 c1             	mov    %rax,%rcx
    5dda:	45 39 fd             	cmp    %r15d,%r13d
    5ddd:	74 c1                	je     5da0 <fwp_apply+0x1d0>
    5ddf:	45 01 e5             	add    %r12d,%r13d
    5de2:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    5de6:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    5dea:	41 29 dd             	sub    %ebx,%r13d
    5ded:	e9 05 fe ff ff       	jmp    5bf7 <fwp_apply+0x27>
    5df2:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    5df8:	e9 ac fe ff ff       	jmp    5ca9 <fwp_apply+0xd9>
    5dfd:	e8 5e d6 ff ff       	call   3460 <__stack_chk_fail@plt>
    5e02:	0f 1f 00             	nopl   (%rax)
    5e05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5e0c:	00 00 00 00 

0000000000005e10 <fwp_p_ad_push>:
    5e10:	41 57                	push   %r15
    5e12:	41 56                	push   %r14
    5e14:	41 55                	push   %r13
    5e16:	49 89 d5             	mov    %rdx,%r13
    5e19:	41 54                	push   %r12
    5e1b:	49 89 fc             	mov    %rdi,%r12
    5e1e:	55                   	push   %rbp
    5e1f:	53                   	push   %rbx
    5e20:	48 83 ec 38          	sub    $0x38,%rsp
    5e24:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5e29:	48 85 ff             	test   %rdi,%rdi
    5e2c:	79 09                	jns    5e37 <fwp_p_ad_push+0x27>
    5e2e:	48 85 d2             	test   %rdx,%rdx
    5e31:	0f 88 a9 01 00 00    	js     5fe0 <fwp_p_ad_push+0x1d0>
    5e37:	48 89 f8             	mov    %rdi,%rax
    5e3a:	48 89 0c 24          	mov    %rcx,(%rsp)
    5e3e:	48 09 d0             	or     %rdx,%rax
    5e41:	0f 89 79 01 00 00    	jns    5fc0 <fwp_p_ad_push+0x1b0>
    5e47:	48 89 f8             	mov    %rdi,%rax
    5e4a:	48 c1 f8 20          	sar    $0x20,%rax
    5e4e:	48 85 ff             	test   %rdi,%rdi
    5e51:	79 24                	jns    5e77 <fwp_p_ad_push+0x67>
    5e53:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5e58:	48 89 d0             	mov    %rdx,%rax
    5e5b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5e62:	00 
    5e63:	49 89 d4             	mov    %rdx,%r12
    5e66:	48 c1 f8 20          	sar    $0x20,%rax
    5e6a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5e71:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5e77:	48 89 c7             	mov    %rax,%rdi
    5e7a:	e8 01 e6 ff ff       	call   4480 <fwp_tape_of>
    5e7f:	48 89 c3             	mov    %rax,%rbx
    5e82:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5e87:	0f 85 76 02 00 00    	jne    6103 <fwp_p_ad_push+0x2f3>
    5e8d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    5e91:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    5e98:	0f 8f 59 02 00 00    	jg     60f7 <fwp_p_ad_push+0x2e7>
    5e9e:	44 89 e0             	mov    %r12d,%eax
    5ea1:	4c 39 f8             	cmp    %r15,%rax
    5ea4:	0f 8d 41 02 00 00    	jge    60eb <fwp_p_ad_push+0x2db>
    5eaa:	4d 85 ed             	test   %r13,%r13
    5ead:	78 0c                	js     5ebb <fwp_p_ad_push+0xab>
    5eaf:	44 89 e8             	mov    %r13d,%eax
    5eb2:	4c 39 f8             	cmp    %r15,%rax
    5eb5:	0f 8d 30 02 00 00    	jge    60eb <fwp_p_ad_push+0x2db>
    5ebb:	4d 89 fe             	mov    %r15,%r14
    5ebe:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5ec2:	49 8d 46 01          	lea    0x1(%r14),%rax
    5ec6:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5ecc:	0f 87 25 02 00 00    	ja     60f7 <fwp_p_ad_push+0x2e7>
    5ed2:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5ed6:	48 39 e8             	cmp    %rbp,%rax
    5ed9:	0f 8e 31 01 00 00    	jle    6010 <fwp_p_ad_push+0x200>
    5edf:	48 85 ed             	test   %rbp,%rbp
    5ee2:	b9 40 00 00 00       	mov    $0x40,%ecx
    5ee7:	48 0f 44 e9          	cmove  %rcx,%rbp
    5eeb:	48 39 e8             	cmp    %rbp,%rax
    5eee:	7e 20                	jle    5f10 <fwp_p_ad_push+0x100>
    5ef0:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5ef7:	0f 8f 03 01 00 00    	jg     6000 <fwp_p_ad_push+0x1f0>
    5efd:	48 01 ed             	add    %rbp,%rbp
    5f00:	48 39 e8             	cmp    %rbp,%rax
    5f03:	7f eb                	jg     5ef0 <fwp_p_ad_push+0xe0>
    5f05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f0c:	00 00 00 00 
    5f10:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5f17:	00 
    5f18:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5f1c:	48 89 c6             	mov    %rax,%rsi
    5f1f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    5f24:	e8 a7 d6 ff ff       	call   35d0 <realloc@plt>
    5f29:	48 85 c0             	test   %rax,%rax
    5f2c:	0f 84 dd 01 00 00    	je     610f <fwp_p_ad_push+0x2ff>
    5f32:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    5f36:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    5f3a:	48 89 43 20          	mov    %rax,0x20(%rbx)
    5f3e:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    5f42:	48 89 e9             	mov    %rbp,%rcx
    5f45:	48 89 43 28          	mov    %rax,0x28(%rbx)
    5f49:	48 c1 e1 04          	shl    $0x4,%rcx
    5f4d:	48 89 ce             	mov    %rcx,%rsi
    5f50:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    5f55:	e8 76 d6 ff ff       	call   35d0 <realloc@plt>
    5f5a:	48 85 c0             	test   %rax,%rax
    5f5d:	0f 84 ac 01 00 00    	je     610f <fwp_p_ad_push+0x2ff>
    5f63:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    5f67:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    5f6c:	4d 85 f6             	test   %r14,%r14
    5f6f:	48 89 43 30          	mov    %rax,0x30(%rbx)
    5f73:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    5f78:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    5f7f:	00 
    5f80:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    5f87:	00 
    5f88:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    5f8c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    5f93:	00 
    5f94:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    5f98:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    5f9c:	0f 85 e2 00 00 00    	jne    6084 <fwp_p_ad_push+0x274>
    5fa2:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    5fa6:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    5faa:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    5fae:	49 01 c8             	add    %rcx,%r8
    5fb1:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    5fb5:	eb 79                	jmp    6030 <fwp_p_ad_push+0x220>
    5fb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5fbe:	00 00 
    5fc0:	48 89 d0             	mov    %rdx,%rax
    5fc3:	48 c1 ff 20          	sar    $0x20,%rdi
    5fc7:	48 c1 f8 20          	sar    $0x20,%rax
    5fcb:	48 39 c7             	cmp    %rax,%rdi
    5fce:	0f 84 a3 fe ff ff    	je     5e77 <fwp_p_ad_push+0x67>
    5fd4:	48 8d 3d e5 77 00 00 	lea    0x77e5(%rip),%rdi        # d7c0 <_IO_stdin_used+0x7c0>
    5fdb:	e8 c0 e1 ff ff       	call   41a0 <fwp_trap>
    5fe0:	48 83 c4 38          	add    $0x38,%rsp
    5fe4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5feb:	5b                   	pop    %rbx
    5fec:	5d                   	pop    %rbp
    5fed:	41 5c                	pop    %r12
    5fef:	41 5d                	pop    %r13
    5ff1:	41 5e                	pop    %r14
    5ff3:	41 5f                	pop    %r15
    5ff5:	c3                   	ret
    5ff6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5ffd:	00 00 00 
    6000:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    6005:	e9 06 ff ff ff       	jmp    5f10 <fwp_p_ad_push+0x100>
    600a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6010:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    6014:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6018:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    601f:	00 
    6020:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6027:	00 
    6028:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    602c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6030:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6036:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    603a:	4d 85 ed             	test   %r13,%r13
    603d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6042:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6048:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    604f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6053:	49 8d 47 01          	lea    0x1(%r15),%rax
    6057:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    605b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6061:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6065:	48 83 c4 38          	add    $0x38,%rsp
    6069:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6070:	ff ff ff 
    6073:	4c 21 e0             	and    %r12,%rax
    6076:	5b                   	pop    %rbx
    6077:	5d                   	pop    %rbp
    6078:	4c 09 f8             	or     %r15,%rax
    607b:	41 5c                	pop    %r12
    607d:	41 5d                	pop    %r13
    607f:	41 5e                	pop    %r14
    6081:	41 5f                	pop    %r15
    6083:	c3                   	ret
    6084:	48 39 ca             	cmp    %rcx,%rdx
    6087:	49 89 d6             	mov    %rdx,%r14
    608a:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    608f:	48 0f 43 ca          	cmovae %rdx,%rcx
    6093:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    6098:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    609d:	48 29 d1             	sub    %rdx,%rcx
    60a0:	4c 89 ca             	mov    %r9,%rdx
    60a3:	e8 b8 d4 ff ff       	call   3560 <__memmove_chk@plt>
    60a8:	4c 03 73 30          	add    0x30(%rbx),%r14
    60ac:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    60b1:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    60b5:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    60ba:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    60be:	48 03 7b 20          	add    0x20(%rbx),%rdi
    60c2:	4c 89 d2             	mov    %r10,%rdx
    60c5:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    60ca:	e8 41 d5 ff ff       	call   3610 <memmove@plt>
    60cf:	48 8b 43 30          	mov    0x30(%rbx),%rax
    60d3:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    60d7:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    60dc:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    60e1:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    60e6:	e9 bb fe ff ff       	jmp    5fa6 <fwp_p_ad_push+0x196>
    60eb:	48 8d 3d 12 70 00 00 	lea    0x7012(%rip),%rdi        # d104 <_IO_stdin_used+0x104>
    60f2:	e8 a9 e0 ff ff       	call   41a0 <fwp_trap>
    60f7:	48 8d 3d eb 6f 00 00 	lea    0x6feb(%rip),%rdi        # d0e9 <_IO_stdin_used+0xe9>
    60fe:	e8 9d e0 ff ff       	call   41a0 <fwp_trap>
    6103:	48 8d 3d fe 76 00 00 	lea    0x76fe(%rip),%rdi        # d808 <_IO_stdin_used+0x808>
    610a:	e8 91 e0 ff ff       	call   41a0 <fwp_trap>
    610f:	48 89 df             	mov    %rbx,%rdi
    6112:	e8 e9 da ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6117:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    611b:	e8 a0 d2 ff ff       	call   33c0 <free@plt>
    6120:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6124:	e8 97 d2 ff ff       	call   33c0 <free@plt>
    6129:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    612d:	e8 8e d2 ff ff       	call   33c0 <free@plt>
    6132:	31 c9                	xor    %ecx,%ecx
    6134:	31 c0                	xor    %eax,%eax
    6136:	31 d2                	xor    %edx,%edx
    6138:	89 53 04             	mov    %edx,0x4(%rbx)
    613b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    613f:	ba 13 00 00 00       	mov    $0x13,%edx
    6144:	be 01 00 00 00       	mov    $0x1,%esi
    6149:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    614d:	48 8d 3d b4 6e 00 00 	lea    0x6eb4(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    6154:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6158:	48 8b 0d 01 af 00 00 	mov    0xaf01(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    615f:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6163:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    6167:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    616b:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    616f:	e8 0c d5 ff ff       	call   3680 <fwrite@plt>
    6174:	31 ff                	xor    %edi,%edi
    6176:	e8 45 d4 ff ff       	call   35c0 <fflush@plt>
    617b:	bf 66 00 00 00       	mov    $0x66,%edi
    6180:	e8 1b d5 ff ff       	call   36a0 <_Exit@plt>
    6185:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    618c:	00 00 00 00 

0000000000006190 <w107>:
    6190:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6194:	41 55                	push   %r13
    6196:	48 89 fa             	mov    %rdi,%rdx
    6199:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    619d:	41 54                	push   %r12
    619f:	49 89 fc             	mov    %rdi,%r12
    61a2:	55                   	push   %rbp
    61a3:	53                   	push   %rbx
    61a4:	48 89 f3             	mov    %rsi,%rbx
    61a7:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    61ac:	48 89 f1             	mov    %rsi,%rcx
    61af:	48 83 ec 28          	sub    $0x28,%rsp
    61b3:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    61b9:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    61bf:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    61c5:	e8 46 fc ff ff       	call   5e10 <fwp_p_ad_push>
    61ca:	48 89 c7             	mov    %rax,%rdi
    61cd:	e8 4e eb ff ff       	call   4d20 <caf61>
    61d2:	66 48 0f 6e c0       	movq   %rax,%xmm0
    61d7:	e8 44 eb ff ff       	call   4d20 <caf61>
    61dc:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    61e2:	66 0f 57 05 16 79 00 	xorpd  0x7916(%rip),%xmm0        # db00 <msg.8+0x80>
    61e9:	00 
    61ea:	48 89 da             	mov    %rbx,%rdx
    61ed:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    61f3:	48 89 c1             	mov    %rax,%rcx
    61f6:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    61fb:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6200:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6206:	e8 05 fc ff ff       	call   5e10 <fwp_p_ad_push>
    620b:	4c 89 e7             	mov    %r12,%rdi
    620e:	49 89 c5             	mov    %rax,%r13
    6211:	e8 0a eb ff ff       	call   4d20 <caf61>
    6216:	48 89 c6             	mov    %rax,%rsi
    6219:	e8 02 eb ff ff       	call   4d20 <caf61>
    621e:	66 48 0f 6e d6       	movq   %rsi,%xmm2
    6223:	f2 0f 10 05 15 79 00 	movsd  0x7915(%rip),%xmm0        # db40 <msg.8+0xc0>
    622a:	00 
    622b:	66 0f 57 15 cd 78 00 	xorpd  0x78cd(%rip),%xmm2        # db00 <msg.8+0x80>
    6232:	00 
    6233:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    6239:	48 89 c1             	mov    %rax,%rcx
    623c:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6243:	66 48 0f 7e d6       	movq   %xmm2,%rsi
    6248:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    624d:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6253:	e8 b8 fb ff ff       	call   5e10 <fwp_p_ad_push>
    6258:	48 89 e9             	mov    %rbp,%rcx
    625b:	4c 89 ea             	mov    %r13,%rdx
    625e:	48 89 ee             	mov    %rbp,%rsi
    6261:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6267:	4c 89 ef             	mov    %r13,%rdi
    626a:	49 89 c4             	mov    %rax,%r12
    626d:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6271:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6277:	e8 94 fb ff ff       	call   5e10 <fwp_p_ad_push>
    627c:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6282:	f2 0f 59 1d be 78 00 	mulsd  0x78be(%rip),%xmm3        # db48 <msg.8+0xc8>
    6289:	00 
    628a:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6291:	00 59 40 
    6294:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6299:	48 89 c2             	mov    %rax,%rdx
    629c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    62a3:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    62a9:	e8 62 fb ff ff       	call   5e10 <fwp_p_ad_push>
    62ae:	4c 89 e2             	mov    %r12,%rdx
    62b1:	48 89 d9             	mov    %rbx,%rcx
    62b4:	48 89 de             	mov    %rbx,%rsi
    62b7:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    62bd:	4c 89 e7             	mov    %r12,%rdi
    62c0:	48 89 c5             	mov    %rax,%rbp
    62c3:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    62c7:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    62cd:	e8 3e fb ff ff       	call   5e10 <fwp_p_ad_push>
    62d2:	48 89 c7             	mov    %rax,%rdi
    62d5:	e8 46 ea ff ff       	call   4d20 <caf61>
    62da:	48 89 c6             	mov    %rax,%rsi
    62dd:	e8 3e ea ff ff       	call   4d20 <caf61>
    62e2:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    62e8:	48 89 ea             	mov    %rbp,%rdx
    62eb:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    62f1:	48 89 c1             	mov    %rax,%rcx
    62f4:	66 48 0f 7e db       	movq   %xmm3,%rbx
    62f9:	e8 12 fb ff ff       	call   5e10 <fwp_p_ad_push>
    62fe:	48 83 c4 28          	add    $0x28,%rsp
    6302:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    6307:	5b                   	pop    %rbx
    6308:	5d                   	pop    %rbp
    6309:	41 5c                	pop    %r12
    630b:	41 5d                	pop    %r13
    630d:	c3                   	ret
    630e:	66 90                	xchg   %ax,%ax

0000000000006310 <w164.constprop.0>:
    6310:	41 54                	push   %r12
    6312:	55                   	push   %rbp
    6313:	53                   	push   %rbx
    6314:	48 83 ec 10          	sub    $0x10,%rsp
    6318:	4c 8b 27             	mov    (%rdi),%r12
    631b:	4d 85 e4             	test   %r12,%r12
    631e:	74 78                	je     6398 <w164.constprop.0+0x88>
    6320:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    6327:	00 00 
    6329:	48 89 fd             	mov    %rdi,%rbp
    632c:	31 db                	xor    %ebx,%ebx
    632e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    633c:	00 00 00 00 
    6340:	4c 8b 44 dd 10       	mov    0x10(%rbp,%rbx,8),%r8
    6345:	f2 0f 10 44 dd 08    	movsd  0x8(%rbp,%rbx,8),%xmm0
    634b:	48 83 c3 02          	add    $0x2,%rbx
    634f:	e8 cc e9 ff ff       	call   4d20 <caf61>
    6354:	48 89 c6             	mov    %rax,%rsi
    6357:	e8 c4 e9 ff ff       	call   4d20 <caf61>
    635c:	f2 0f 58 44 24 08    	addsd  0x8(%rsp),%xmm0
    6362:	4c 89 c2             	mov    %r8,%rdx
    6365:	48 89 c1             	mov    %rax,%rcx
    6368:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    636e:	e8 9d fa ff ff       	call   5e10 <fwp_p_ad_push>
    6373:	48 89 c7             	mov    %rax,%rdi
    6376:	4c 39 e3             	cmp    %r12,%rbx
    6379:	72 c5                	jb     6340 <w164.constprop.0+0x30>
    637b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6380:	48 83 c4 10          	add    $0x10,%rsp
    6384:	5b                   	pop    %rbx
    6385:	5d                   	pop    %rbp
    6386:	66 48 0f 6e c0       	movq   %rax,%xmm0
    638b:	41 5c                	pop    %r12
    638d:	48 89 f8             	mov    %rdi,%rax
    6390:	c3                   	ret
    6391:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6398:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    639f:	00 00 
    63a1:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    63a8:	eb d1                	jmp    637b <w164.constprop.0+0x6b>
    63aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000063b0 <fwp_data.part.0.constprop.0>:
    63b0:	41 56                	push   %r14
    63b2:	41 89 fe             	mov    %edi,%r14d
    63b5:	41 54                	push   %r12
    63b7:	49 89 f4             	mov    %rsi,%r12
    63ba:	55                   	push   %rbp
    63bb:	53                   	push   %rbx
    63bc:	48 83 ec 08          	sub    $0x8,%rsp
    63c0:	8b 05 7e c7 01 00    	mov    0x1c77e(%rip),%eax        # 22b44 <fwp_heap+0x13a4>
    63c6:	85 c0                	test   %eax,%eax
    63c8:	0f 84 fa 00 00 00    	je     64c8 <fwp_data.part.0.constprop.0+0x118>
    63ce:	0f b6 05 6d c3 01 00 	movzbl 0x1c36d(%rip),%eax        # 22742 <fwp_heap+0xfa2>
    63d5:	48 8d 15 c4 b3 01 00 	lea    0x1b3c4(%rip),%rdx        # 217a0 <fwp_heap>
    63dc:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    63e3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    63e7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    63eb:	48 8b 18             	mov    (%rax),%rbx
    63ee:	48 85 db             	test   %rbx,%rbx
    63f1:	0f 84 a9 00 00 00    	je     64a0 <fwp_data.part.0.constprop.0+0xf0>
    63f7:	48 8b 13             	mov    (%rbx),%rdx
    63fa:	48 f7 d2             	not    %rdx
    63fd:	48 89 10             	mov    %rdx,(%rax)
    6400:	48 83 fd 18          	cmp    $0x18,%rbp
    6404:	76 1b                	jbe    6421 <fwp_data.part.0.constprop.0+0x71>
    6406:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    640a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    640e:	31 f6                	xor    %esi,%esi
    6410:	48 c1 e8 03          	shr    $0x3,%rax
    6414:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    641b:	00 
    641c:	e8 9f d0 ff ff       	call   34c0 <memset@plt>
    6421:	48 89 e8             	mov    %rbp,%rax
    6424:	48 03 05 95 c7 01 00 	add    0x1c795(%rip),%rax        # 22bc0 <fwp_heap+0x1420>
    642b:	0f 82 a8 00 00 00    	jb     64d9 <fwp_data.part.0.constprop.0+0x129>
    6431:	48 39 05 90 c7 01 00 	cmp    %rax,0x1c790(%rip)        # 22bc8 <fwp_heap+0x1428>
    6438:	48 89 05 81 c7 01 00 	mov    %rax,0x1c781(%rip)        # 22bc0 <fwp_heap+0x1420>
    643f:	73 07                	jae    6448 <fwp_data.part.0.constprop.0+0x98>
    6441:	48 89 05 80 c7 01 00 	mov    %rax,0x1c780(%rip)        # 22bc8 <fwp_heap+0x1428>
    6448:	66 0f ef c0          	pxor   %xmm0,%xmm0
    644c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6451:	f2 0f 58 05 7f c7 01 	addsd  0x1c77f(%rip),%xmm0        # 22bd8 <fwp_heap+0x1438>
    6458:	00 
    6459:	f2 0f 11 05 77 c7 01 	movsd  %xmm0,0x1c777(%rip)        # 22bd8 <fwp_heap+0x1438>
    6460:	00 
    6461:	b8 02 00 00 00       	mov    $0x2,%eax
    6466:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    646b:	66 0f 6e c8          	movd   %eax,%xmm1
    646f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6473:	66 0f d6 03          	movq   %xmm0,(%rbx)
    6477:	49 8b 04 24          	mov    (%r12),%rax
    647b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    647f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6484:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6488:	48 83 c4 08          	add    $0x8,%rsp
    648c:	48 89 d8             	mov    %rbx,%rax
    648f:	5b                   	pop    %rbx
    6490:	5d                   	pop    %rbp
    6491:	41 5c                	pop    %r12
    6493:	41 5e                	pop    %r14
    6495:	c3                   	ret
    6496:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    649d:	00 00 00 
    64a0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    64a4:	48 85 db             	test   %rbx,%rbx
    64a7:	74 1f                	je     64c8 <fwp_data.part.0.constprop.0+0x118>
    64a9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    64ad:	48 29 da             	sub    %rbx,%rdx
    64b0:	48 39 ea             	cmp    %rbp,%rdx
    64b3:	72 13                	jb     64c8 <fwp_data.part.0.constprop.0+0x118>
    64b5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    64b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    64bd:	e9 3e ff ff ff       	jmp    6400 <fwp_data.part.0.constprop.0+0x50>
    64c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    64c8:	31 f6                	xor    %esi,%esi
    64ca:	bf 18 00 00 00       	mov    $0x18,%edi
    64cf:	e8 dc f5 ff ff       	call   5ab0 <fwp_heap_alloc>
    64d4:	48 89 c3             	mov    %rax,%rbx
    64d7:	eb 88                	jmp    6461 <fwp_data.part.0.constprop.0+0xb1>
    64d9:	e8 d2 d7 ff ff       	call   3cb0 <fwp_heap_oom>
    64de:	66 90                	xchg   %ax,%ax

00000000000064e0 <fwp_rc_share>:
    64e0:	48 8b 05 91 c6 01 00 	mov    0x1c691(%rip),%rax        # 22b78 <fwp_heap+0x13d8>
    64e7:	48 2b 3d 62 c6 01 00 	sub    0x1c662(%rip),%rdi        # 22b50 <fwp_heap+0x13b0>
    64ee:	48 c1 e0 10          	shl    $0x10,%rax
    64f2:	48 39 c7             	cmp    %rax,%rdi
    64f5:	73 4a                	jae    6541 <fwp_rc_share+0x61>
    64f7:	48 89 f8             	mov    %rdi,%rax
    64fa:	48 c1 e8 10          	shr    $0x10,%rax
    64fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6502:	48 8b 05 8f c6 01 00 	mov    0x1c68f(%rip),%rax        # 22b98 <fwp_heap+0x13f8>
    6509:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    650d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6511:	48 85 d2             	test   %rdx,%rdx
    6514:	74 2b                	je     6541 <fwp_rc_share+0x61>
    6516:	0f b6 08             	movzbl (%rax),%ecx
    6519:	80 f9 02             	cmp    $0x2,%cl
    651c:	74 2a                	je     6548 <fwp_rc_share+0x68>
    651e:	80 f9 01             	cmp    $0x1,%cl
    6521:	75 1e                	jne    6541 <fwp_rc_share+0x61>
    6523:	8b 48 18             	mov    0x18(%rax),%ecx
    6526:	0f b7 ff             	movzwl %di,%edi
    6529:	8b 40 1c             	mov    0x1c(%rax),%eax
    652c:	48 0f af f9          	imul   %rcx,%rdi
    6530:	48 c1 ef 20          	shr    $0x20,%rdi
    6534:	48 39 c7             	cmp    %rax,%rdi
    6537:	73 08                	jae    6541 <fwp_rc_share+0x61>
    6539:	48 01 fa             	add    %rdi,%rdx
    653c:	80 3a 00             	cmpb   $0x0,(%rdx)
    653f:	75 0d                	jne    654e <fwp_rc_share+0x6e>
    6541:	c3                   	ret
    6542:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6548:	66 85 ff             	test   %di,%di
    654b:	74 ef                	je     653c <fwp_rc_share+0x5c>
    654d:	c3                   	ret
    654e:	50                   	push   %rax
    654f:	48 8d 3d e2 72 00 00 	lea    0x72e2(%rip),%rdi        # d838 <_IO_stdin_used+0x838>
    6556:	e8 45 dc ff ff       	call   41a0 <fwp_trap>
    655b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006560 <fwp_rc_free_arr>:
    6560:	48 8b 15 11 c6 01 00 	mov    0x1c611(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    6567:	48 89 f8             	mov    %rdi,%rax
    656a:	48 2b 05 df c5 01 00 	sub    0x1c5df(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    6571:	48 c1 e2 10          	shl    $0x10,%rdx
    6575:	48 39 d0             	cmp    %rdx,%rax
    6578:	73 5b                	jae    65d5 <fwp_rc_free_arr+0x75>
    657a:	48 89 c2             	mov    %rax,%rdx
    657d:	48 c1 ea 10          	shr    $0x10,%rdx
    6581:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6585:	48 8b 15 0c c6 01 00 	mov    0x1c60c(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    658c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6590:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6594:	48 85 c9             	test   %rcx,%rcx
    6597:	74 3c                	je     65d5 <fwp_rc_free_arr+0x75>
    6599:	0f b6 32             	movzbl (%rdx),%esi
    659c:	40 80 fe 02          	cmp    $0x2,%sil
    65a0:	74 2e                	je     65d0 <fwp_rc_free_arr+0x70>
    65a2:	40 80 fe 01          	cmp    $0x1,%sil
    65a6:	75 2d                	jne    65d5 <fwp_rc_free_arr+0x75>
    65a8:	8b 72 18             	mov    0x18(%rdx),%esi
    65ab:	0f b7 c0             	movzwl %ax,%eax
    65ae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    65b1:	48 0f af c6          	imul   %rsi,%rax
    65b5:	48 c1 e8 20          	shr    $0x20,%rax
    65b9:	48 39 d0             	cmp    %rdx,%rax
    65bc:	73 17                	jae    65d5 <fwp_rc_free_arr+0x75>
    65be:	48 01 c1             	add    %rax,%rcx
    65c1:	80 39 01             	cmpb   $0x1,(%rcx)
    65c4:	75 0f                	jne    65d5 <fwp_rc_free_arr+0x75>
    65c6:	e9 e5 ef ff ff       	jmp    55b0 <fwp_mem_free>
    65cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    65d0:	66 85 c0             	test   %ax,%ax
    65d3:	74 ec                	je     65c1 <fwp_rc_free_arr+0x61>
    65d5:	c3                   	ret
    65d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    65dd:	00 00 00 

00000000000065e0 <fwp_rc_dup>:
    65e0:	f3 0f 1e fa          	endbr64
    65e4:	48 8b 05 8d c5 01 00 	mov    0x1c58d(%rip),%rax        # 22b78 <fwp_heap+0x13d8>
    65eb:	48 2b 3d 5e c5 01 00 	sub    0x1c55e(%rip),%rdi        # 22b50 <fwp_heap+0x13b0>
    65f2:	48 c1 e0 10          	shl    $0x10,%rax
    65f6:	48 39 c7             	cmp    %rax,%rdi
    65f9:	73 56                	jae    6651 <fwp_rc_dup+0x71>
    65fb:	48 89 f8             	mov    %rdi,%rax
    65fe:	48 c1 e8 10          	shr    $0x10,%rax
    6602:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6606:	48 8b 05 8b c5 01 00 	mov    0x1c58b(%rip),%rax        # 22b98 <fwp_heap+0x13f8>
    660d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6611:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6615:	48 85 c0             	test   %rax,%rax
    6618:	74 37                	je     6651 <fwp_rc_dup+0x71>
    661a:	0f b6 0a             	movzbl (%rdx),%ecx
    661d:	80 f9 02             	cmp    $0x2,%cl
    6620:	74 36                	je     6658 <fwp_rc_dup+0x78>
    6622:	80 f9 01             	cmp    $0x1,%cl
    6625:	75 2a                	jne    6651 <fwp_rc_dup+0x71>
    6627:	8b 4a 18             	mov    0x18(%rdx),%ecx
    662a:	0f b7 ff             	movzwl %di,%edi
    662d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6630:	48 0f af f9          	imul   %rcx,%rdi
    6634:	48 c1 ef 20          	shr    $0x20,%rdi
    6638:	48 39 d7             	cmp    %rdx,%rdi
    663b:	73 14                	jae    6651 <fwp_rc_dup+0x71>
    663d:	48 01 f8             	add    %rdi,%rax
    6640:	0f b6 10             	movzbl (%rax),%edx
    6643:	84 d2                	test   %dl,%dl
    6645:	74 0a                	je     6651 <fwp_rc_dup+0x71>
    6647:	80 fa fd             	cmp    $0xfd,%dl
    664a:	77 14                	ja     6660 <fwp_rc_dup+0x80>
    664c:	83 c2 01             	add    $0x1,%edx
    664f:	88 10                	mov    %dl,(%rax)
    6651:	c3                   	ret
    6652:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6658:	66 85 ff             	test   %di,%di
    665b:	74 e3                	je     6640 <fwp_rc_dup+0x60>
    665d:	c3                   	ret
    665e:	66 90                	xchg   %ax,%ax
    6660:	48 89 c7             	mov    %rax,%rdi
    6663:	e9 e8 eb ff ff       	jmp    5250 <fwp_rc_wide_dup>
    6668:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    666f:	00 

0000000000006670 <fwp_drop0>:
    6670:	f3 0f 1e fa          	endbr64
    6674:	48 8b 15 fd c4 01 00 	mov    0x1c4fd(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    667b:	48 89 f8             	mov    %rdi,%rax
    667e:	48 2b 05 cb c4 01 00 	sub    0x1c4cb(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    6685:	48 c1 e2 10          	shl    $0x10,%rdx
    6689:	48 39 d0             	cmp    %rdx,%rax
    668c:	0f 83 be 00 00 00    	jae    6750 <fwp_drop0+0xe0>
    6692:	48 83 ec 18          	sub    $0x18,%rsp
    6696:	4c 8d 05 03 b1 01 00 	lea    0x1b103(%rip),%r8        # 217a0 <fwp_heap>
    669d:	48 89 c2             	mov    %rax,%rdx
    66a0:	48 c1 ea 10          	shr    $0x10,%rdx
    66a4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    66a8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    66af:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    66b3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    66b7:	48 85 d2             	test   %rdx,%rdx
    66ba:	74 3c                	je     66f8 <fwp_drop0+0x88>
    66bc:	0f b6 31             	movzbl (%rcx),%esi
    66bf:	40 80 fe 02          	cmp    $0x2,%sil
    66c3:	74 3b                	je     6700 <fwp_drop0+0x90>
    66c5:	40 80 fe 01          	cmp    $0x1,%sil
    66c9:	75 2d                	jne    66f8 <fwp_drop0+0x88>
    66cb:	8b 71 18             	mov    0x18(%rcx),%esi
    66ce:	0f b7 c0             	movzwl %ax,%eax
    66d1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    66d4:	48 0f af c6          	imul   %rsi,%rax
    66d8:	48 c1 e8 20          	shr    $0x20,%rax
    66dc:	48 39 c8             	cmp    %rcx,%rax
    66df:	73 17                	jae    66f8 <fwp_drop0+0x88>
    66e1:	48 01 c2             	add    %rax,%rdx
    66e4:	0f b6 02             	movzbl (%rdx),%eax
    66e7:	84 c0                	test   %al,%al
    66e9:	74 0d                	je     66f8 <fwp_drop0+0x88>
    66eb:	3c 01                	cmp    $0x1,%al
    66ed:	74 21                	je     6710 <fwp_drop0+0xa0>
    66ef:	3c ff                	cmp    $0xff,%al
    66f1:	74 65                	je     6758 <fwp_drop0+0xe8>
    66f3:	83 e8 01             	sub    $0x1,%eax
    66f6:	88 02                	mov    %al,(%rdx)
    66f8:	48 83 c4 18          	add    $0x18,%rsp
    66fc:	c3                   	ret
    66fd:	0f 1f 00             	nopl   (%rax)
    6700:	66 85 c0             	test   %ax,%ax
    6703:	74 df                	je     66e4 <fwp_drop0+0x74>
    6705:	48 83 c4 18          	add    $0x18,%rsp
    6709:	c3                   	ret
    670a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6710:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6714:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6719:	e8 42 fe ff ff       	call   6560 <fwp_rc_free_arr>
    671e:	4c 8d 05 7b b0 01 00 	lea    0x1b07b(%rip),%r8        # 217a0 <fwp_heap>
    6725:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    672a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6731:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6738:	48 c1 e2 10          	shl    $0x10,%rdx
    673c:	48 39 d0             	cmp    %rdx,%rax
    673f:	73 b7                	jae    66f8 <fwp_drop0+0x88>
    6741:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6746:	e9 52 ff ff ff       	jmp    669d <fwp_drop0+0x2d>
    674b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6750:	c3                   	ret
    6751:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6758:	48 89 d0             	mov    %rdx,%rax
    675b:	48 c1 e8 11          	shr    $0x11,%rax
    675f:	48 31 d0             	xor    %rdx,%rax
    6762:	48 89 c1             	mov    %rax,%rcx
    6765:	48 c1 e9 09          	shr    $0x9,%rcx
    6769:	48 31 c8             	xor    %rcx,%rax
    676c:	0f b6 c8             	movzbl %al,%ecx
    676f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6776:	00 
    6777:	48 85 c0             	test   %rax,%rax
    677a:	75 0d                	jne    6789 <fwp_drop0+0x119>
    677c:	eb 46                	jmp    67c4 <fwp_drop0+0x154>
    677e:	66 90                	xchg   %ax,%ax
    6780:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6784:	48 85 c0             	test   %rax,%rax
    6787:	74 3b                	je     67c4 <fwp_drop0+0x154>
    6789:	48 89 c1             	mov    %rax,%rcx
    678c:	48 39 10             	cmp    %rdx,(%rax)
    678f:	75 ef                	jne    6780 <fwp_drop0+0x110>
    6791:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6795:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6799:	48 89 48 08          	mov    %rcx,0x8(%rax)
    679d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    67a4:	0f 85 4e ff ff ff    	jne    66f8 <fwp_drop0+0x88>
    67aa:	48 89 d7             	mov    %rdx,%rdi
    67ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    67b2:	e8 b9 eb ff ff       	call   5370 <fwp_rc_forget_slot>
    67b7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    67bc:	c6 02 fe             	movb   $0xfe,(%rdx)
    67bf:	e9 34 ff ff ff       	jmp    66f8 <fwp_drop0+0x88>
    67c4:	48 8d 3d cd 6f 00 00 	lea    0x6fcd(%rip),%rdi        # d798 <_IO_stdin_used+0x798>
    67cb:	e8 d0 d9 ff ff       	call   41a0 <fwp_trap>

00000000000067d0 <fwp_arg_drop12>:
    67d0:	f3 0f 1e fa          	endbr64
    67d4:	85 f6                	test   %esi,%esi
    67d6:	75 04                	jne    67dc <fwp_arg_drop12+0xc>
    67d8:	85 d2                	test   %edx,%edx
    67da:	75 04                	jne    67e0 <fwp_arg_drop12+0x10>
    67dc:	c3                   	ret
    67dd:	0f 1f 00             	nopl   (%rax)
    67e0:	48 8b 3f             	mov    (%rdi),%rdi
    67e3:	e9 88 fe ff ff       	jmp    6670 <fwp_drop0>
    67e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    67ef:	00 

00000000000067f0 <fwp_drop1>:
    67f0:	f3 0f 1e fa          	endbr64
    67f4:	48 8b 15 7d c3 01 00 	mov    0x1c37d(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    67fb:	48 89 f8             	mov    %rdi,%rax
    67fe:	48 2b 05 4b c3 01 00 	sub    0x1c34b(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    6805:	48 c1 e2 10          	shl    $0x10,%rdx
    6809:	48 39 d0             	cmp    %rdx,%rax
    680c:	0f 83 be 00 00 00    	jae    68d0 <fwp_drop1+0xe0>
    6812:	48 83 ec 18          	sub    $0x18,%rsp
    6816:	4c 8d 05 83 af 01 00 	lea    0x1af83(%rip),%r8        # 217a0 <fwp_heap>
    681d:	48 89 c2             	mov    %rax,%rdx
    6820:	48 c1 ea 10          	shr    $0x10,%rdx
    6824:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6828:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    682f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6833:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6837:	48 85 d2             	test   %rdx,%rdx
    683a:	74 3c                	je     6878 <fwp_drop1+0x88>
    683c:	0f b6 31             	movzbl (%rcx),%esi
    683f:	40 80 fe 02          	cmp    $0x2,%sil
    6843:	74 3b                	je     6880 <fwp_drop1+0x90>
    6845:	40 80 fe 01          	cmp    $0x1,%sil
    6849:	75 2d                	jne    6878 <fwp_drop1+0x88>
    684b:	8b 71 18             	mov    0x18(%rcx),%esi
    684e:	0f b7 c0             	movzwl %ax,%eax
    6851:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6854:	48 0f af c6          	imul   %rsi,%rax
    6858:	48 c1 e8 20          	shr    $0x20,%rax
    685c:	48 39 c8             	cmp    %rcx,%rax
    685f:	73 17                	jae    6878 <fwp_drop1+0x88>
    6861:	48 01 c2             	add    %rax,%rdx
    6864:	0f b6 02             	movzbl (%rdx),%eax
    6867:	84 c0                	test   %al,%al
    6869:	74 0d                	je     6878 <fwp_drop1+0x88>
    686b:	3c 01                	cmp    $0x1,%al
    686d:	74 21                	je     6890 <fwp_drop1+0xa0>
    686f:	3c ff                	cmp    $0xff,%al
    6871:	74 65                	je     68d8 <fwp_drop1+0xe8>
    6873:	83 e8 01             	sub    $0x1,%eax
    6876:	88 02                	mov    %al,(%rdx)
    6878:	48 83 c4 18          	add    $0x18,%rsp
    687c:	c3                   	ret
    687d:	0f 1f 00             	nopl   (%rax)
    6880:	66 85 c0             	test   %ax,%ax
    6883:	74 df                	je     6864 <fwp_drop1+0x74>
    6885:	48 83 c4 18          	add    $0x18,%rsp
    6889:	c3                   	ret
    688a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6890:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6894:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6899:	e8 c2 fc ff ff       	call   6560 <fwp_rc_free_arr>
    689e:	4c 8d 05 fb ae 01 00 	lea    0x1aefb(%rip),%r8        # 217a0 <fwp_heap>
    68a5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    68aa:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    68b1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    68b8:	48 c1 e2 10          	shl    $0x10,%rdx
    68bc:	48 39 d0             	cmp    %rdx,%rax
    68bf:	73 b7                	jae    6878 <fwp_drop1+0x88>
    68c1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    68c6:	e9 52 ff ff ff       	jmp    681d <fwp_drop1+0x2d>
    68cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    68d0:	c3                   	ret
    68d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    68d8:	48 89 d0             	mov    %rdx,%rax
    68db:	48 c1 e8 11          	shr    $0x11,%rax
    68df:	48 31 d0             	xor    %rdx,%rax
    68e2:	48 89 c1             	mov    %rax,%rcx
    68e5:	48 c1 e9 09          	shr    $0x9,%rcx
    68e9:	48 31 c8             	xor    %rcx,%rax
    68ec:	0f b6 c8             	movzbl %al,%ecx
    68ef:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    68f6:	00 
    68f7:	48 85 c0             	test   %rax,%rax
    68fa:	75 0d                	jne    6909 <fwp_drop1+0x119>
    68fc:	eb 46                	jmp    6944 <fwp_drop1+0x154>
    68fe:	66 90                	xchg   %ax,%ax
    6900:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6904:	48 85 c0             	test   %rax,%rax
    6907:	74 3b                	je     6944 <fwp_drop1+0x154>
    6909:	48 89 c1             	mov    %rax,%rcx
    690c:	48 39 10             	cmp    %rdx,(%rax)
    690f:	75 ef                	jne    6900 <fwp_drop1+0x110>
    6911:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6915:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6919:	48 89 48 08          	mov    %rcx,0x8(%rax)
    691d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6924:	0f 85 4e ff ff ff    	jne    6878 <fwp_drop1+0x88>
    692a:	48 89 d7             	mov    %rdx,%rdi
    692d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6932:	e8 39 ea ff ff       	call   5370 <fwp_rc_forget_slot>
    6937:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    693c:	c6 02 fe             	movb   $0xfe,(%rdx)
    693f:	e9 34 ff ff ff       	jmp    6878 <fwp_drop1+0x88>
    6944:	48 8d 3d 4d 6e 00 00 	lea    0x6e4d(%rip),%rdi        # d798 <_IO_stdin_used+0x798>
    694b:	e8 50 d8 ff ff       	call   41a0 <fwp_trap>

0000000000006950 <fwp_closure_drop>:
    6950:	48 8b 15 21 c2 01 00 	mov    0x1c221(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    6957:	48 89 f8             	mov    %rdi,%rax
    695a:	48 2b 05 ef c1 01 00 	sub    0x1c1ef(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    6961:	48 c1 e2 10          	shl    $0x10,%rdx
    6965:	48 39 d0             	cmp    %rdx,%rax
    6968:	73 6b                	jae    69d5 <fwp_closure_drop+0x85>
    696a:	48 89 c2             	mov    %rax,%rdx
    696d:	48 c1 ea 10          	shr    $0x10,%rdx
    6971:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6975:	48 8b 15 1c c2 01 00 	mov    0x1c21c(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    697c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6980:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6984:	48 85 d2             	test   %rdx,%rdx
    6987:	74 4c                	je     69d5 <fwp_closure_drop+0x85>
    6989:	0f b6 31             	movzbl (%rcx),%esi
    698c:	40 80 fe 02          	cmp    $0x2,%sil
    6990:	74 3e                	je     69d0 <fwp_closure_drop+0x80>
    6992:	40 80 fe 01          	cmp    $0x1,%sil
    6996:	75 3d                	jne    69d5 <fwp_closure_drop+0x85>
    6998:	8b 71 18             	mov    0x18(%rcx),%esi
    699b:	0f b7 c0             	movzwl %ax,%eax
    699e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    69a1:	48 0f af c6          	imul   %rsi,%rax
    69a5:	48 c1 e8 20          	shr    $0x20,%rax
    69a9:	48 39 c8             	cmp    %rcx,%rax
    69ac:	73 27                	jae    69d5 <fwp_closure_drop+0x85>
    69ae:	48 01 c2             	add    %rax,%rdx
    69b1:	0f b6 02             	movzbl (%rdx),%eax
    69b4:	84 c0                	test   %al,%al
    69b6:	74 1d                	je     69d5 <fwp_closure_drop+0x85>
    69b8:	3c 01                	cmp    $0x1,%al
    69ba:	74 24                	je     69e0 <fwp_closure_drop+0x90>
    69bc:	3c ff                	cmp    $0xff,%al
    69be:	74 48                	je     6a08 <fwp_closure_drop+0xb8>
    69c0:	83 e8 01             	sub    $0x1,%eax
    69c3:	88 02                	mov    %al,(%rdx)
    69c5:	c3                   	ret
    69c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    69cd:	00 00 00 
    69d0:	66 85 c0             	test   %ax,%ax
    69d3:	74 dc                	je     69b1 <fwp_closure_drop+0x61>
    69d5:	c3                   	ret
    69d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    69dd:	00 00 00 
    69e0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    69e7:	ff ff 
    69e9:	48 85 c0             	test   %rax,%rax
    69ec:	74 12                	je     6a00 <fwp_closure_drop+0xb0>
    69ee:	48 89 fe             	mov    %rdi,%rsi
    69f1:	48 89 c7             	mov    %rax,%rdi
    69f4:	e9 07 d8 ff ff       	jmp    4200 <fwp_closure_drop_push>
    69f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6a00:	e9 ab d9 ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    6a05:	0f 1f 00             	nopl   (%rax)
    6a08:	48 89 d0             	mov    %rdx,%rax
    6a0b:	48 8d 35 8e ad 01 00 	lea    0x1ad8e(%rip),%rsi        # 217a0 <fwp_heap>
    6a12:	48 83 ec 18          	sub    $0x18,%rsp
    6a16:	48 c1 e8 11          	shr    $0x11,%rax
    6a1a:	48 31 d0             	xor    %rdx,%rax
    6a1d:	48 89 c1             	mov    %rax,%rcx
    6a20:	48 c1 e9 09          	shr    $0x9,%rcx
    6a24:	48 31 c8             	xor    %rcx,%rax
    6a27:	0f b6 c8             	movzbl %al,%ecx
    6a2a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6a31:	00 
    6a32:	48 85 c0             	test   %rax,%rax
    6a35:	75 12                	jne    6a49 <fwp_closure_drop+0xf9>
    6a37:	eb 49                	jmp    6a82 <fwp_closure_drop+0x132>
    6a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6a40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6a44:	48 85 c0             	test   %rax,%rax
    6a47:	74 39                	je     6a82 <fwp_closure_drop+0x132>
    6a49:	48 89 c1             	mov    %rax,%rcx
    6a4c:	48 39 10             	cmp    %rdx,(%rax)
    6a4f:	75 ef                	jne    6a40 <fwp_closure_drop+0xf0>
    6a51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6a55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6a59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6a5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6a64:	74 05                	je     6a6b <fwp_closure_drop+0x11b>
    6a66:	48 83 c4 18          	add    $0x18,%rsp
    6a6a:	c3                   	ret
    6a6b:	48 89 d7             	mov    %rdx,%rdi
    6a6e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6a73:	e8 f8 e8 ff ff       	call   5370 <fwp_rc_forget_slot>
    6a78:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6a7d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6a80:	eb e4                	jmp    6a66 <fwp_closure_drop+0x116>
    6a82:	48 8d 3d 0f 6d 00 00 	lea    0x6d0f(%rip),%rdi        # d798 <_IO_stdin_used+0x798>
    6a89:	e8 12 d7 ff ff       	call   41a0 <fwp_trap>
    6a8e:	66 90                	xchg   %ax,%ax

0000000000006a90 <fwp_owned_tape_release>:
    6a90:	48 85 ff             	test   %rdi,%rdi
    6a93:	0f 84 f7 00 00 00    	je     6b90 <fwp_owned_tape_release+0x100>
    6a99:	41 54                	push   %r12
    6a9b:	55                   	push   %rbp
    6a9c:	53                   	push   %rbx
    6a9d:	48 8b 07             	mov    (%rdi),%rax
    6aa0:	48 85 c0             	test   %rax,%rax
    6aa3:	74 08                	je     6aad <fwp_owned_tape_release+0x1d>
    6aa5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6aa9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6aad:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6ab1:	48 85 d2             	test   %rdx,%rdx
    6ab4:	74 03                	je     6ab9 <fwp_owned_tape_release+0x29>
    6ab6:	48 89 02             	mov    %rax,(%rdx)
    6ab9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6abd:	48 89 fb             	mov    %rdi,%rbx
    6ac0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6ac4:	48 85 c0             	test   %rax,%rax
    6ac7:	0f 84 89 00 00 00    	je     6b56 <fwp_owned_tape_release+0xc6>
    6acd:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6ad1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6ad5:	7e 47                	jle    6b1e <fwp_owned_tape_release+0x8e>
    6ad7:	31 ed                	xor    %ebp,%ebp
    6ad9:	eb 0d                	jmp    6ae8 <fwp_owned_tape_release+0x58>
    6adb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6ae0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6ae4:	48 8b 40 68          	mov    0x68(%rax),%rax
    6ae8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6aec:	49 89 ec             	mov    %rbp,%r12
    6aef:	48 83 c5 01          	add    $0x1,%rbp
    6af3:	49 c1 e4 04          	shl    $0x4,%r12
    6af7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6afb:	ff d0                	call   *%rax
    6afd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6b01:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6b06:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6b0a:	ff 50 68             	call   *0x68(%rax)
    6b0d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6b11:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6b15:	48 39 e8             	cmp    %rbp,%rax
    6b18:	7f c6                	jg     6ae0 <fwp_owned_tape_release+0x50>
    6b1a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6b1e:	31 ed                	xor    %ebp,%ebp
    6b20:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6b25:	7e 28                	jle    6b4f <fwp_owned_tape_release+0xbf>
    6b27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6b2e:	00 00 
    6b30:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6b34:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6b38:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6b3c:	74 07                	je     6b45 <fwp_owned_tape_release+0xb5>
    6b3e:	ff 52 68             	call   *0x68(%rdx)
    6b41:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6b45:	48 83 c5 01          	add    $0x1,%rbp
    6b49:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6b4d:	7f e1                	jg     6b30 <fwp_owned_tape_release+0xa0>
    6b4f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6b53:	ff 52 68             	call   *0x68(%rdx)
    6b56:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6b5a:	e8 f1 fd ff ff       	call   6950 <fwp_closure_drop>
    6b5f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6b63:	e8 e8 fd ff ff       	call   6950 <fwp_closure_drop>
    6b68:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6b6c:	e8 df fd ff ff       	call   6950 <fwp_closure_drop>
    6b71:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6b75:	e8 36 ea ff ff       	call   55b0 <fwp_mem_free>
    6b7a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6b7e:	e8 2d ea ff ff       	call   55b0 <fwp_mem_free>
    6b83:	48 89 df             	mov    %rbx,%rdi
    6b86:	5b                   	pop    %rbx
    6b87:	5d                   	pop    %rbp
    6b88:	41 5c                	pop    %r12
    6b8a:	e9 21 ea ff ff       	jmp    55b0 <fwp_mem_free>
    6b8f:	90                   	nop
    6b90:	c3                   	ret
    6b91:	0f 1f 40 00          	nopl   0x0(%rax)
    6b95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6b9c:	00 00 00 00 

0000000000006ba0 <fwp_tape_finish>:
    6ba0:	f3 0f 1e fa          	endbr64
    6ba4:	41 56                	push   %r14
    6ba6:	48 8d 3d 33 a5 01 00 	lea    0x1a533(%rip),%rdi        # 210e0 <fwp_tape_workspace>
    6bad:	41 55                	push   %r13
    6baf:	41 54                	push   %r12
    6bb1:	55                   	push   %rbp
    6bb2:	53                   	push   %rbx
    6bb3:	e8 b8 d3 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    6bb8:	48 83 3d 68 a5 01 00 	cmpq   $0x0,0x1a568(%rip)        # 21128 <fwp_ntapes>
    6bbf:	00 
    6bc0:	48 c7 05 fd a4 01 00 	movq   $0x0,0x1a4fd(%rip)        # 210c8 <fwp_tape_cached_bytes>
    6bc7:	00 00 00 00 
    6bcb:	7e 68                	jle    6c35 <fwp_tape_finish+0x95>
    6bcd:	45 31 e4             	xor    %r12d,%r12d
    6bd0:	31 ed                	xor    %ebp,%ebp
    6bd2:	0f 1f 00             	nopl   (%rax)
    6bd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6bdc:	00 00 00 00 
    6be0:	48 8b 1d 49 a5 01 00 	mov    0x1a549(%rip),%rbx        # 21130 <fwp_tapes>
    6be7:	48 83 c5 01          	add    $0x1,%rbp
    6beb:	4c 01 e3             	add    %r12,%rbx
    6bee:	49 83 c4 68          	add    $0x68,%r12
    6bf2:	48 89 df             	mov    %rbx,%rdi
    6bf5:	e8 06 d0 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6bfa:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6bfe:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6c02:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6c06:	e8 b5 c7 ff ff       	call   33c0 <free@plt>
    6c0b:	4c 89 f7             	mov    %r14,%rdi
    6c0e:	e8 ad c7 ff ff       	call   33c0 <free@plt>
    6c13:	4c 89 ef             	mov    %r13,%rdi
    6c16:	e8 a5 c7 ff ff       	call   33c0 <free@plt>
    6c1b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6c1f:	e8 6c fe ff ff       	call   6a90 <fwp_owned_tape_release>
    6c24:	48 39 2d fd a4 01 00 	cmp    %rbp,0x1a4fd(%rip)        # 21128 <fwp_ntapes>
    6c2b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6c32:	00 
    6c33:	7f ab                	jg     6be0 <fwp_tape_finish+0x40>
    6c35:	48 8b 3d f4 a4 01 00 	mov    0x1a4f4(%rip),%rdi        # 21130 <fwp_tapes>
    6c3c:	e8 7f c7 ff ff       	call   33c0 <free@plt>
    6c41:	5b                   	pop    %rbx
    6c42:	5d                   	pop    %rbp
    6c43:	48 c7 05 e2 a4 01 00 	movq   $0x0,0x1a4e2(%rip)        # 21130 <fwp_tapes>
    6c4a:	00 00 00 00 
    6c4e:	48 c7 05 c7 a4 01 00 	movq   $0x0,0x1a4c7(%rip)        # 21120 <fwp_tapes_cap>
    6c55:	00 00 00 00 
    6c59:	41 5c                	pop    %r12
    6c5b:	48 c7 05 c2 a4 01 00 	movq   $0x0,0x1a4c2(%rip)        # 21128 <fwp_ntapes>
    6c62:	00 00 00 00 
    6c66:	41 5d                	pop    %r13
    6c68:	48 c7 05 a5 a4 01 00 	movq   $0x0,0x1a4a5(%rip)        # 21118 <fwp_tape_next_slot>
    6c6f:	00 00 00 00 
    6c73:	41 5e                	pop    %r14
    6c75:	c3                   	ret
    6c76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c7d:	00 00 00 

0000000000006c80 <fwp_tape_scope_release>:
    6c80:	f3 0f 1e fa          	endbr64
    6c84:	41 55                	push   %r13
    6c86:	41 54                	push   %r12
    6c88:	55                   	push   %rbp
    6c89:	53                   	push   %rbx
    6c8a:	48 83 ec 58          	sub    $0x58,%rsp
    6c8e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6c95:	00 00 
    6c97:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6c9c:	48 63 07             	movslq (%rdi),%rax
    6c9f:	85 c0                	test   %eax,%eax
    6ca1:	0f 88 05 01 00 00    	js     6dac <fwp_tape_scope_release+0x12c>
    6ca7:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6cae:	ec c4 4e 
    6cb1:	48 89 fb             	mov    %rdi,%rbx
    6cb4:	eb 3c                	jmp    6cf2 <fwp_tape_scope_release+0x72>
    6cb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6cbd:	00 00 00 
    6cc0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6cc5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6cc9:	e8 f2 c6 ff ff       	call   33c0 <free@plt>
    6cce:	48 8b 3c 24          	mov    (%rsp),%rdi
    6cd2:	e8 e9 c6 ff ff       	call   33c0 <free@plt>
    6cd7:	4c 89 ef             	mov    %r13,%rdi
    6cda:	e8 e1 c6 ff ff       	call   33c0 <free@plt>
    6cdf:	4c 89 e7             	mov    %r12,%rdi
    6ce2:	e8 a9 fd ff ff       	call   6a90 <fwp_owned_tape_release>
    6ce7:	48 63 03             	movslq (%rbx),%rax
    6cea:	85 c0                	test   %eax,%eax
    6cec:	0f 88 ba 00 00 00    	js     6dac <fwp_tape_scope_release+0x12c>
    6cf2:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6cf6:	48 8b 35 33 a4 01 00 	mov    0x1a433(%rip),%rsi        # 21130 <fwp_tapes>
    6cfd:	4c 01 c6             	add    %r8,%rsi
    6d00:	48 89 f7             	mov    %rsi,%rdi
    6d03:	e8 f8 ce ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6d08:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6d0d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6d12:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6d19:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6d1d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6d21:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6d28:	00 
    6d29:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6d2e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6d32:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6d37:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6d3b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6d40:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6d47:	00 
    6d48:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6d4f:	00 
    6d50:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6d57:	00 
    6d58:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6d5d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6d62:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6d66:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6d6a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6d6e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6d74:	77 18                	ja     6d8e <fwp_tape_scope_release+0x10e>
    6d76:	49 c1 f8 03          	sar    $0x3,%r8
    6d7a:	4c 0f af c5          	imul   %rbp,%r8
    6d7e:	4c 3b 05 93 a3 01 00 	cmp    0x1a393(%rip),%r8        # 21118 <fwp_tape_next_slot>
    6d85:	7d 07                	jge    6d8e <fwp_tape_scope_release+0x10e>
    6d87:	4c 89 05 8a a3 01 00 	mov    %r8,0x1a38a(%rip)        # 21118 <fwp_tape_next_slot>
    6d8e:	4d 85 e4             	test   %r12,%r12
    6d91:	0f 85 29 ff ff ff    	jne    6cc0 <fwp_tape_scope_release+0x40>
    6d97:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6d9c:	e8 ef e0 ff ff       	call   4e90 <fwp_tape_buffers_release>
    6da1:	48 63 03             	movslq (%rbx),%rax
    6da4:	85 c0                	test   %eax,%eax
    6da6:	0f 89 46 ff ff ff    	jns    6cf2 <fwp_tape_scope_release+0x72>
    6dac:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6db1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6db8:	00 00 
    6dba:	75 0b                	jne    6dc7 <fwp_tape_scope_release+0x147>
    6dbc:	48 83 c4 58          	add    $0x58,%rsp
    6dc0:	5b                   	pop    %rbx
    6dc1:	5d                   	pop    %rbp
    6dc2:	41 5c                	pop    %r12
    6dc4:	41 5d                	pop    %r13
    6dc6:	c3                   	ret
    6dc7:	e8 94 c6 ff ff       	call   3460 <__stack_chk_fail@plt>
    6dcc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006dd0 <fwp_task_dispose>:
    6dd0:	53                   	push   %rbx
    6dd1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6dd5:	0f 84 6b c9 ff ff    	je     3746 <fwp_task_dispose.cold>
    6ddb:	48 89 fb             	mov    %rdi,%rbx
    6dde:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6de3:	0f 85 5d c9 ff ff    	jne    3746 <fwp_task_dispose.cold>
    6de9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6ded:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6df4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6dfb:	00 
    6dfc:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6e00:	48 85 ff             	test   %rdi,%rdi
    6e03:	74 07                	je     6e0c <fwp_task_dispose+0x3c>
    6e05:	48 85 c0             	test   %rax,%rax
    6e08:	74 02                	je     6e0c <fwp_task_dispose+0x3c>
    6e0a:	ff d0                	call   *%rax
    6e0c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    6e13:	e8 98 e7 ff ff       	call   55b0 <fwp_mem_free>
    6e18:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    6e1f:	00 00 00 00 
    6e23:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    6e27:	74 6f                	je     6e98 <fwp_task_dispose+0xc8>
    6e29:	48 8b 15 48 bd 01 00 	mov    0x1bd48(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    6e30:	48 89 d8             	mov    %rbx,%rax
    6e33:	48 2b 05 16 bd 01 00 	sub    0x1bd16(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    6e3a:	48 c1 e2 10          	shl    $0x10,%rdx
    6e3e:	48 39 d0             	cmp    %rdx,%rax
    6e41:	73 4c                	jae    6e8f <fwp_task_dispose+0xbf>
    6e43:	48 89 c2             	mov    %rax,%rdx
    6e46:	48 c1 ea 10          	shr    $0x10,%rdx
    6e4a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6e4e:	48 8b 15 43 bd 01 00 	mov    0x1bd43(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    6e55:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6e59:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6e5d:	48 85 c9             	test   %rcx,%rcx
    6e60:	74 2d                	je     6e8f <fwp_task_dispose+0xbf>
    6e62:	0f b6 32             	movzbl (%rdx),%esi
    6e65:	40 80 fe 02          	cmp    $0x2,%sil
    6e69:	74 3d                	je     6ea8 <fwp_task_dispose+0xd8>
    6e6b:	40 80 fe 01          	cmp    $0x1,%sil
    6e6f:	75 1e                	jne    6e8f <fwp_task_dispose+0xbf>
    6e71:	8b 72 18             	mov    0x18(%rdx),%esi
    6e74:	0f b7 c0             	movzwl %ax,%eax
    6e77:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6e7a:	48 0f af c6          	imul   %rsi,%rax
    6e7e:	48 c1 e8 20          	shr    $0x20,%rax
    6e82:	48 39 d0             	cmp    %rdx,%rax
    6e85:	73 08                	jae    6e8f <fwp_task_dispose+0xbf>
    6e87:	48 01 c1             	add    %rax,%rcx
    6e8a:	80 39 01             	cmpb   $0x1,(%rcx)
    6e8d:	74 09                	je     6e98 <fwp_task_dispose+0xc8>
    6e8f:	5b                   	pop    %rbx
    6e90:	c3                   	ret
    6e91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e98:	48 89 df             	mov    %rbx,%rdi
    6e9b:	5b                   	pop    %rbx
    6e9c:	e9 0f e7 ff ff       	jmp    55b0 <fwp_mem_free>
    6ea1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6ea8:	66 85 c0             	test   %ax,%ax
    6eab:	74 dd                	je     6e8a <fwp_task_dispose+0xba>
    6ead:	5b                   	pop    %rbx
    6eae:	c3                   	ret
    6eaf:	90                   	nop

0000000000006eb0 <fwp_free_zombie>:
    6eb0:	48 8b 15 b9 a8 01 00 	mov    0x1a8b9(%rip),%rdx        # 21770 <fwp_zombie>
    6eb7:	48 85 d2             	test   %rdx,%rdx
    6eba:	0f 84 98 00 00 00    	je     6f58 <fwp_free_zombie+0xa8>
    6ec0:	48 3b 15 b9 a8 01 00 	cmp    0x1a8b9(%rip),%rdx        # 21780 <fwp_cur>
    6ec7:	0f 84 8b 00 00 00    	je     6f58 <fwp_free_zombie+0xa8>
    6ecd:	48 83 ec 18          	sub    $0x18,%rsp
    6ed1:	48 63 05 74 a2 01 00 	movslq 0x1a274(%rip),%rax        # 2114c <fwp_stack_pool_n>
    6ed8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    6edc:	83 f8 3f             	cmp    $0x3f,%eax
    6edf:	7f 7f                	jg     6f60 <fwp_free_zombie+0xb0>
    6ee1:	8d 48 01             	lea    0x1(%rax),%ecx
    6ee4:	89 0d 62 a2 01 00    	mov    %ecx,0x1a262(%rip)        # 2114c <fwp_stack_pool_n>
    6eea:	48 8d 0d 6f a2 01 00 	lea    0x1a26f(%rip),%rcx        # 21160 <fwp_stack_pool>
    6ef1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    6ef5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    6efc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6f00:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    6f07:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    6f0b:	48 85 c9             	test   %rcx,%rcx
    6f0e:	0f 84 fc 00 00 00    	je     7010 <fwp_free_zombie+0x160>
    6f14:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    6f1b:	48 85 c0             	test   %rax,%rax
    6f1e:	74 07                	je     6f27 <fwp_free_zombie+0x77>
    6f20:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    6f27:	8b 42 5c             	mov    0x5c(%rdx),%eax
    6f2a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6f2e:	48 c7 05 37 a8 01 00 	movq   $0x0,0x1a837(%rip)        # 21770 <fwp_zombie>
    6f35:	00 00 00 00 
    6f39:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    6f40:	85 c0                	test   %eax,%eax
    6f42:	74 34                	je     6f78 <fwp_free_zombie+0xc8>
    6f44:	83 f8 01             	cmp    $0x1,%eax
    6f47:	0f 84 b3 00 00 00    	je     7000 <fwp_free_zombie+0x150>
    6f4d:	48 83 c4 18          	add    $0x18,%rsp
    6f51:	c3                   	ret
    6f52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f58:	c3                   	ret
    6f59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f60:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    6f64:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6f69:	e8 72 c6 ff ff       	call   35e0 <munmap@plt>
    6f6e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6f73:	eb 80                	jmp    6ef5 <fwp_free_zombie+0x45>
    6f75:	0f 1f 00             	nopl   (%rax)
    6f78:	48 8b 0d f9 bb 01 00 	mov    0x1bbf9(%rip),%rcx        # 22b78 <fwp_heap+0x13d8>
    6f7f:	48 89 d0             	mov    %rdx,%rax
    6f82:	48 2b 05 c7 bb 01 00 	sub    0x1bbc7(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    6f89:	48 c1 e1 10          	shl    $0x10,%rcx
    6f8d:	48 39 c8             	cmp    %rcx,%rax
    6f90:	73 bb                	jae    6f4d <fwp_free_zombie+0x9d>
    6f92:	48 89 c1             	mov    %rax,%rcx
    6f95:	48 c1 e9 10          	shr    $0x10,%rcx
    6f99:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    6f9d:	48 8b 0d f4 bb 01 00 	mov    0x1bbf4(%rip),%rcx        # 22b98 <fwp_heap+0x13f8>
    6fa4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    6fa8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6fac:	48 85 c9             	test   %rcx,%rcx
    6faf:	74 9c                	je     6f4d <fwp_free_zombie+0x9d>
    6fb1:	0f b6 3e             	movzbl (%rsi),%edi
    6fb4:	40 80 ff 02          	cmp    $0x2,%dil
    6fb8:	74 66                	je     7020 <fwp_free_zombie+0x170>
    6fba:	40 80 ff 01          	cmp    $0x1,%dil
    6fbe:	75 8d                	jne    6f4d <fwp_free_zombie+0x9d>
    6fc0:	8b 7e 18             	mov    0x18(%rsi),%edi
    6fc3:	0f b7 c0             	movzwl %ax,%eax
    6fc6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6fc9:	48 0f af c7          	imul   %rdi,%rax
    6fcd:	48 c1 e8 20          	shr    $0x20,%rax
    6fd1:	48 39 f0             	cmp    %rsi,%rax
    6fd4:	0f 83 73 ff ff ff    	jae    6f4d <fwp_free_zombie+0x9d>
    6fda:	48 01 c1             	add    %rax,%rcx
    6fdd:	0f b6 01             	movzbl (%rcx),%eax
    6fe0:	84 c0                	test   %al,%al
    6fe2:	0f 84 65 ff ff ff    	je     6f4d <fwp_free_zombie+0x9d>
    6fe8:	3c 01                	cmp    $0x1,%al
    6fea:	74 14                	je     7000 <fwp_free_zombie+0x150>
    6fec:	3c ff                	cmp    $0xff,%al
    6fee:	74 3b                	je     702b <fwp_free_zombie+0x17b>
    6ff0:	83 e8 01             	sub    $0x1,%eax
    6ff3:	88 01                	mov    %al,(%rcx)
    6ff5:	e9 53 ff ff ff       	jmp    6f4d <fwp_free_zombie+0x9d>
    6ffa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7000:	48 89 d7             	mov    %rdx,%rdi
    7003:	48 83 c4 18          	add    $0x18,%rsp
    7007:	e9 c4 fd ff ff       	jmp    6dd0 <fwp_task_dispose>
    700c:	0f 1f 40 00          	nopl   0x0(%rax)
    7010:	48 89 05 31 a7 01 00 	mov    %rax,0x1a731(%rip)        # 21748 <fwp_tasks_active>
    7017:	e9 ff fe ff ff       	jmp    6f1b <fwp_free_zombie+0x6b>
    701c:	0f 1f 40 00          	nopl   0x0(%rax)
    7020:	66 85 c0             	test   %ax,%ax
    7023:	0f 85 24 ff ff ff    	jne    6f4d <fwp_free_zombie+0x9d>
    7029:	eb b2                	jmp    6fdd <fwp_free_zombie+0x12d>
    702b:	48 89 ca             	mov    %rcx,%rdx
    702e:	48 8d 35 6b a7 01 00 	lea    0x1a76b(%rip),%rsi        # 217a0 <fwp_heap>
    7035:	48 c1 ea 11          	shr    $0x11,%rdx
    7039:	48 31 ca             	xor    %rcx,%rdx
    703c:	48 89 d0             	mov    %rdx,%rax
    703f:	48 c1 e8 09          	shr    $0x9,%rax
    7043:	48 31 c2             	xor    %rax,%rdx
    7046:	0f b6 d2             	movzbl %dl,%edx
    7049:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7050:	00 
    7051:	48 85 c0             	test   %rax,%rax
    7054:	75 13                	jne    7069 <fwp_free_zombie+0x1b9>
    7056:	eb 4c                	jmp    70a4 <fwp_free_zombie+0x1f4>
    7058:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    705f:	00 
    7060:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7064:	48 85 c0             	test   %rax,%rax
    7067:	74 3b                	je     70a4 <fwp_free_zombie+0x1f4>
    7069:	48 89 c2             	mov    %rax,%rdx
    706c:	48 39 08             	cmp    %rcx,(%rax)
    706f:	75 ef                	jne    7060 <fwp_free_zombie+0x1b0>
    7071:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7075:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7079:	48 89 50 08          	mov    %rdx,0x8(%rax)
    707d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7084:	0f 85 c3 fe ff ff    	jne    6f4d <fwp_free_zombie+0x9d>
    708a:	48 89 cf             	mov    %rcx,%rdi
    708d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7092:	e8 d9 e2 ff ff       	call   5370 <fwp_rc_forget_slot>
    7097:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    709c:	c6 01 fe             	movb   $0xfe,(%rcx)
    709f:	e9 a9 fe ff ff       	jmp    6f4d <fwp_free_zombie+0x9d>
    70a4:	48 8d 3d ed 66 00 00 	lea    0x66ed(%rip),%rdi        # d798 <_IO_stdin_used+0x798>
    70ab:	e8 f0 d0 ff ff       	call   41a0 <fwp_trap>

00000000000070b0 <fwp_block>:
    70b0:	48 83 ec 08          	sub    $0x8,%rsp
    70b4:	48 8b 05 ad a6 01 00 	mov    0x1a6ad(%rip),%rax        # 21768 <fwp_ready_head>
    70bb:	48 85 c0             	test   %rax,%rax
    70be:	0f 84 1c 01 00 00    	je     71e0 <fwp_block+0x130>
    70c4:	90                   	nop
    70c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    70cc:	00 00 00 00 
    70d0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    70d7:	48 89 15 8a a6 01 00 	mov    %rdx,0x1a68a(%rip)        # 21768 <fwp_ready_head>
    70de:	48 85 d2             	test   %rdx,%rdx
    70e1:	0f 84 19 01 00 00    	je     7200 <fwp_block+0x150>
    70e7:	48 8b 15 92 a6 01 00 	mov    0x1a692(%rip),%rdx        # 21780 <fwp_cur>
    70ee:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    70f2:	48 39 c2             	cmp    %rax,%rdx
    70f5:	0f 84 d5 00 00 00    	je     71d0 <fwp_block+0x120>
    70fb:	48 8b 0d 06 c3 01 00 	mov    0x1c306(%rip),%rcx        # 23408 <fwp_state_owners>
    7102:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7106:	48 89 05 73 a6 01 00 	mov    %rax,0x1a673(%rip)        # 21780 <fwp_cur>
    710d:	f3 0f 7e 05 1b c3 01 	movq   0x1c31b(%rip),%xmm0        # 23430 <fwp_foreign_callbacks>
    7114:	00 
    7115:	0f 16 05 04 c3 01 00 	movhps 0x1c304(%rip),%xmm0        # 23420 <fwp_state>
    711c:	f3 0f 7e 0d 04 c3 01 	movq   0x1c304(%rip),%xmm1        # 23428 <fwp_handlers>
    7123:	00 
    7124:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    712b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7132:	0f 16 0d ff c2 01 00 	movhps 0x1c2ff(%rip),%xmm1        # 23438 <fwp_cleanups>
    7139:	f3 0f 7e 05 d7 c2 01 	movq   0x1c2d7(%rip),%xmm0        # 23418 <fwp_state_len>
    7140:	00 
    7141:	0f 16 05 c8 c2 01 00 	movhps 0x1c2c8(%rip),%xmm0        # 23410 <fwp_state_cap>
    7148:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    714f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7156:	48 8b 70 08          	mov    0x8(%rax),%rsi
    715a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7161:	48 89 0d c0 c2 01 00 	mov    %rcx,0x1c2c0(%rip)        # 23428 <fwp_handlers>
    7168:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    716f:	48 89 0d c2 c2 01 00 	mov    %rcx,0x1c2c2(%rip)        # 23438 <fwp_cleanups>
    7176:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    717d:	48 89 0d ac c2 01 00 	mov    %rcx,0x1c2ac(%rip)        # 23430 <fwp_foreign_callbacks>
    7184:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    718b:	48 89 0d 8e c2 01 00 	mov    %rcx,0x1c28e(%rip)        # 23420 <fwp_state>
    7192:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7199:	48 89 0d 78 c2 01 00 	mov    %rcx,0x1c278(%rip)        # 23418 <fwp_state_len>
    71a0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    71a7:	48 89 0d 62 c2 01 00 	mov    %rcx,0x1c262(%rip)        # 23410 <fwp_state_cap>
    71ae:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    71b5:	48 89 0d 4c c2 01 00 	mov    %rcx,0x1c24c(%rip)        # 23408 <fwp_state_owners>
    71bc:	e8 cf c2 ff ff       	call   3490 <swapcontext@plt>
    71c1:	f3 0f 1e fa          	endbr64
    71c5:	e8 e6 fc ff ff       	call   6eb0 <fwp_free_zombie>
    71ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    71d0:	8b 05 72 9f 01 00    	mov    0x19f72(%rip),%eax        # 21148 <fwp_slice>
    71d6:	85 c0                	test   %eax,%eax
    71d8:	74 36                	je     7210 <fwp_block+0x160>
    71da:	48 83 c4 08          	add    $0x8,%rsp
    71de:	c3                   	ret
    71df:	90                   	nop
    71e0:	e8 db dd ff ff       	call   4fc0 <fwp_poll_events>
    71e5:	48 8b 05 7c a5 01 00 	mov    0x1a57c(%rip),%rax        # 21768 <fwp_ready_head>
    71ec:	48 85 c0             	test   %rax,%rax
    71ef:	0f 85 db fe ff ff    	jne    70d0 <fwp_block+0x20>
    71f5:	eb e9                	jmp    71e0 <fwp_block+0x130>
    71f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    71fe:	00 00 
    7200:	48 c7 05 55 a5 01 00 	movq   $0x0,0x1a555(%rip)        # 21760 <fwp_ready_tail>
    7207:	00 00 00 00 
    720b:	e9 d7 fe ff ff       	jmp    70e7 <fwp_block+0x37>
    7210:	48 8d 3d 0a 5f 00 00 	lea    0x5f0a(%rip),%rdi        # d121 <_IO_stdin_used+0x121>
    7217:	e8 84 c1 ff ff       	call   33a0 <getenv@plt>
    721c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7221:	48 85 c0             	test   %rax,%rax
    7224:	74 05                	je     722b <fwp_block+0x17b>
    7226:	80 38 00             	cmpb   $0x0,(%rax)
    7229:	75 0b                	jne    7236 <fwp_block+0x186>
    722b:	89 15 17 9f 01 00    	mov    %edx,0x19f17(%rip)        # 21148 <fwp_slice>
    7231:	48 83 c4 08          	add    $0x8,%rsp
    7235:	c3                   	ret
    7236:	ba 0a 00 00 00       	mov    $0xa,%edx
    723b:	31 f6                	xor    %esi,%esi
    723d:	48 89 c7             	mov    %rax,%rdi
    7240:	e8 0b c3 ff ff       	call   3550 <strtoll@plt>
    7245:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7249:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7250:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7255:	0f 46 d0             	cmovbe %eax,%edx
    7258:	eb d1                	jmp    722b <fwp_block+0x17b>
    725a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007260 <fwp_owned_entry161>:
    7260:	f3 0f 1e fa          	endbr64
    7264:	41 56                	push   %r14
    7266:	55                   	push   %rbp
    7267:	53                   	push   %rbx
    7268:	48 83 ec 10          	sub    $0x10,%rsp
    726c:	48 8b 07             	mov    (%rdi),%rax
    726f:	48 03 47 10          	add    0x10(%rdi),%rax
    7273:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    7278:	0f 80 b7 01 00 00    	jo     7435 <fwp_owned_entry161+0x1d5>
    727e:	49 89 c6             	mov    %rax,%r14
    7281:	8b 05 bd b8 01 00    	mov    0x1b8bd(%rip),%eax        # 22b44 <fwp_heap+0x13a4>
    7287:	48 8d 15 12 a5 01 00 	lea    0x1a512(%rip),%rdx        # 217a0 <fwp_heap>
    728e:	85 c0                	test   %eax,%eax
    7290:	0f 84 52 01 00 00    	je     73e8 <fwp_owned_entry161+0x188>
    7296:	0f b6 05 a5 b4 01 00 	movzbl 0x1b4a5(%rip),%eax        # 22742 <fwp_heap+0xfa2>
    729d:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    72a4:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    72a8:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    72ac:	48 8b 18             	mov    (%rax),%rbx
    72af:	48 85 db             	test   %rbx,%rbx
    72b2:	0f 84 08 01 00 00    	je     73c0 <fwp_owned_entry161+0x160>
    72b8:	48 8b 13             	mov    (%rbx),%rdx
    72bb:	48 f7 d2             	not    %rdx
    72be:	48 89 10             	mov    %rdx,(%rax)
    72c1:	48 83 fd 18          	cmp    $0x18,%rbp
    72c5:	76 27                	jbe    72ee <fwp_owned_entry161+0x8e>
    72c7:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    72cb:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    72cf:	31 f6                	xor    %esi,%esi
    72d1:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    72d7:	48 c1 e8 03          	shr    $0x3,%rax
    72db:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    72e2:	00 
    72e3:	e8 d8 c1 ff ff       	call   34c0 <memset@plt>
    72e8:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    72ee:	48 89 e8             	mov    %rbp,%rax
    72f1:	48 03 05 c8 b8 01 00 	add    0x1b8c8(%rip),%rax        # 22bc0 <fwp_heap+0x1420>
    72f8:	0f 82 3c 01 00 00    	jb     743a <fwp_owned_entry161+0x1da>
    72fe:	48 39 05 c3 b8 01 00 	cmp    %rax,0x1b8c3(%rip)        # 22bc8 <fwp_heap+0x1428>
    7305:	48 89 05 b4 b8 01 00 	mov    %rax,0x1b8b4(%rip)        # 22bc0 <fwp_heap+0x1420>
    730c:	73 07                	jae    7315 <fwp_owned_entry161+0xb5>
    730e:	48 89 05 b3 b8 01 00 	mov    %rax,0x1b8b3(%rip)        # 22bc8 <fwp_heap+0x1428>
    7315:	66 0f ef c9          	pxor   %xmm1,%xmm1
    7319:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    731e:	f2 0f 58 0d b2 b8 01 	addsd  0x1b8b2(%rip),%xmm1        # 22bd8 <fwp_heap+0x1438>
    7325:	00 
    7326:	f2 0f 11 0d aa b8 01 	movsd  %xmm1,0x1b8aa(%rip)        # 22bd8 <fwp_heap+0x1438>
    732d:	00 
    732e:	48 8b 05 1b 68 00 00 	mov    0x681b(%rip),%rax        # db50 <msg.8+0xd0>
    7335:	66 49 0f 6e d6       	movq   %r14,%xmm2
    733a:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    733e:	48 89 03             	mov    %rax,(%rbx)
    7341:	48 89 d8             	mov    %rbx,%rax
    7344:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    7348:	48 8b 15 29 b8 01 00 	mov    0x1b829(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    734f:	48 2b 05 fa b7 01 00 	sub    0x1b7fa(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    7356:	48 c1 e2 10          	shl    $0x10,%rdx
    735a:	48 39 d0             	cmp    %rdx,%rax
    735d:	73 53                	jae    73b2 <fwp_owned_entry161+0x152>
    735f:	48 89 c2             	mov    %rax,%rdx
    7362:	48 c1 ea 10          	shr    $0x10,%rdx
    7366:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    736a:	48 8b 15 27 b8 01 00 	mov    0x1b827(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    7371:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7375:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7379:	48 85 ed             	test   %rbp,%rbp
    737c:	74 34                	je     73b2 <fwp_owned_entry161+0x152>
    737e:	0f b6 0a             	movzbl (%rdx),%ecx
    7381:	80 f9 02             	cmp    $0x2,%cl
    7384:	0f 84 86 00 00 00    	je     7410 <fwp_owned_entry161+0x1b0>
    738a:	80 f9 01             	cmp    $0x1,%cl
    738d:	75 23                	jne    73b2 <fwp_owned_entry161+0x152>
    738f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7392:	0f b7 c0             	movzwl %ax,%eax
    7395:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7398:	48 0f af c1          	imul   %rcx,%rax
    739c:	48 c1 e8 20          	shr    $0x20,%rax
    73a0:	48 39 d0             	cmp    %rdx,%rax
    73a3:	73 0d                	jae    73b2 <fwp_owned_entry161+0x152>
    73a5:	48 01 c5             	add    %rax,%rbp
    73a8:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    73ac:	74 7a                	je     7428 <fwp_owned_entry161+0x1c8>
    73ae:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    73b2:	48 83 c4 10          	add    $0x10,%rsp
    73b6:	48 89 d8             	mov    %rbx,%rax
    73b9:	5b                   	pop    %rbx
    73ba:	5d                   	pop    %rbp
    73bb:	41 5e                	pop    %r14
    73bd:	c3                   	ret
    73be:	66 90                	xchg   %ax,%ax
    73c0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    73c4:	48 85 db             	test   %rbx,%rbx
    73c7:	74 1f                	je     73e8 <fwp_owned_entry161+0x188>
    73c9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    73cd:	48 29 da             	sub    %rbx,%rdx
    73d0:	48 39 ea             	cmp    %rbp,%rdx
    73d3:	72 13                	jb     73e8 <fwp_owned_entry161+0x188>
    73d5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    73d9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    73dd:	e9 df fe ff ff       	jmp    72c1 <fwp_owned_entry161+0x61>
    73e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    73e8:	31 f6                	xor    %esi,%esi
    73ea:	bf 18 00 00 00       	mov    $0x18,%edi
    73ef:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    73f5:	e8 b6 e6 ff ff       	call   5ab0 <fwp_heap_alloc>
    73fa:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    7400:	48 89 c3             	mov    %rax,%rbx
    7403:	e9 26 ff ff ff       	jmp    732e <fwp_owned_entry161+0xce>
    7408:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    740f:	00 
    7410:	66 85 c0             	test   %ax,%ax
    7413:	74 93                	je     73a8 <fwp_owned_entry161+0x148>
    7415:	48 83 c4 10          	add    $0x10,%rsp
    7419:	48 89 d8             	mov    %rbx,%rax
    741c:	5b                   	pop    %rbx
    741d:	5d                   	pop    %rbp
    741e:	41 5e                	pop    %r14
    7420:	c3                   	ret
    7421:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7428:	48 89 ef             	mov    %rbp,%rdi
    742b:	e8 40 df ff ff       	call   5370 <fwp_rc_forget_slot>
    7430:	e9 79 ff ff ff       	jmp    73ae <fwp_owned_entry161+0x14e>
    7435:	e8 c6 c2 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    743a:	e8 71 c8 ff ff       	call   3cb0 <fwp_heap_oom>
    743f:	90                   	nop

0000000000007440 <e161>:
    7440:	f3 0f 1e fa          	endbr64
    7444:	41 56                	push   %r14
    7446:	55                   	push   %rbp
    7447:	53                   	push   %rbx
    7448:	48 83 ec 10          	sub    $0x10,%rsp
    744c:	48 8b 07             	mov    (%rdi),%rax
    744f:	48 03 47 10          	add    0x10(%rdi),%rax
    7453:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    7458:	0f 80 bf 01 00 00    	jo     761d <e161+0x1dd>
    745e:	49 89 c6             	mov    %rax,%r14
    7461:	8b 05 dd b6 01 00    	mov    0x1b6dd(%rip),%eax        # 22b44 <fwp_heap+0x13a4>
    7467:	48 8d 15 32 a3 01 00 	lea    0x1a332(%rip),%rdx        # 217a0 <fwp_heap>
    746e:	85 c0                	test   %eax,%eax
    7470:	0f 84 62 01 00 00    	je     75d8 <e161+0x198>
    7476:	0f b6 05 c5 b2 01 00 	movzbl 0x1b2c5(%rip),%eax        # 22742 <fwp_heap+0xfa2>
    747d:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    7484:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    7488:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    748c:	48 8b 18             	mov    (%rax),%rbx
    748f:	48 85 db             	test   %rbx,%rbx
    7492:	0f 84 18 01 00 00    	je     75b0 <e161+0x170>
    7498:	48 8b 13             	mov    (%rbx),%rdx
    749b:	48 f7 d2             	not    %rdx
    749e:	48 89 10             	mov    %rdx,(%rax)
    74a1:	48 83 fd 18          	cmp    $0x18,%rbp
    74a5:	76 27                	jbe    74ce <e161+0x8e>
    74a7:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    74ab:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    74af:	31 f6                	xor    %esi,%esi
    74b1:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    74b7:	48 c1 e8 03          	shr    $0x3,%rax
    74bb:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    74c2:	00 
    74c3:	e8 f8 bf ff ff       	call   34c0 <memset@plt>
    74c8:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    74ce:	48 89 e8             	mov    %rbp,%rax
    74d1:	48 03 05 e8 b6 01 00 	add    0x1b6e8(%rip),%rax        # 22bc0 <fwp_heap+0x1420>
    74d8:	0f 82 44 01 00 00    	jb     7622 <e161+0x1e2>
    74de:	48 39 05 e3 b6 01 00 	cmp    %rax,0x1b6e3(%rip)        # 22bc8 <fwp_heap+0x1428>
    74e5:	48 89 05 d4 b6 01 00 	mov    %rax,0x1b6d4(%rip)        # 22bc0 <fwp_heap+0x1420>
    74ec:	73 07                	jae    74f5 <e161+0xb5>
    74ee:	48 89 05 d3 b6 01 00 	mov    %rax,0x1b6d3(%rip)        # 22bc8 <fwp_heap+0x1428>
    74f5:	66 0f ef c9          	pxor   %xmm1,%xmm1
    74f9:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    74fe:	f2 0f 58 0d d2 b6 01 	addsd  0x1b6d2(%rip),%xmm1        # 22bd8 <fwp_heap+0x1438>
    7505:	00 
    7506:	f2 0f 11 0d ca b6 01 	movsd  %xmm1,0x1b6ca(%rip)        # 22bd8 <fwp_heap+0x1438>
    750d:	00 
    750e:	48 8b 05 3b 66 00 00 	mov    0x663b(%rip),%rax        # db50 <msg.8+0xd0>
    7515:	66 49 0f 6e d6       	movq   %r14,%xmm2
    751a:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    751e:	48 89 03             	mov    %rax,(%rbx)
    7521:	48 89 d8             	mov    %rbx,%rax
    7524:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    7528:	48 8b 15 49 b6 01 00 	mov    0x1b649(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    752f:	48 2b 05 1a b6 01 00 	sub    0x1b61a(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    7536:	48 c1 e2 10          	shl    $0x10,%rdx
    753a:	48 39 d0             	cmp    %rdx,%rax
    753d:	73 57                	jae    7596 <e161+0x156>
    753f:	48 89 c2             	mov    %rax,%rdx
    7542:	48 c1 ea 10          	shr    $0x10,%rdx
    7546:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    754a:	48 8b 15 47 b6 01 00 	mov    0x1b647(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    7551:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7555:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7559:	48 85 ed             	test   %rbp,%rbp
    755c:	74 38                	je     7596 <e161+0x156>
    755e:	0f b6 0a             	movzbl (%rdx),%ecx
    7561:	80 f9 02             	cmp    $0x2,%cl
    7564:	0f 84 96 00 00 00    	je     7600 <e161+0x1c0>
    756a:	80 f9 01             	cmp    $0x1,%cl
    756d:	75 27                	jne    7596 <e161+0x156>
    756f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7572:	0f b7 c0             	movzwl %ax,%eax
    7575:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7578:	48 0f af c1          	imul   %rcx,%rax
    757c:	48 c1 e8 20          	shr    $0x20,%rax
    7580:	48 39 d0             	cmp    %rdx,%rax
    7583:	73 11                	jae    7596 <e161+0x156>
    7585:	48 01 c5             	add    %rax,%rbp
    7588:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    758c:	0f 84 7e 00 00 00    	je     7610 <e161+0x1d0>
    7592:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7596:	48 89 df             	mov    %rbx,%rdi
    7599:	e8 42 ef ff ff       	call   64e0 <fwp_rc_share>
    759e:	48 83 c4 10          	add    $0x10,%rsp
    75a2:	48 89 d8             	mov    %rbx,%rax
    75a5:	5b                   	pop    %rbx
    75a6:	5d                   	pop    %rbp
    75a7:	41 5e                	pop    %r14
    75a9:	c3                   	ret
    75aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75b0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    75b4:	48 85 db             	test   %rbx,%rbx
    75b7:	74 1f                	je     75d8 <e161+0x198>
    75b9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    75bd:	48 29 da             	sub    %rbx,%rdx
    75c0:	48 39 ea             	cmp    %rbp,%rdx
    75c3:	72 13                	jb     75d8 <e161+0x198>
    75c5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    75c9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    75cd:	e9 cf fe ff ff       	jmp    74a1 <e161+0x61>
    75d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75d8:	31 f6                	xor    %esi,%esi
    75da:	bf 18 00 00 00       	mov    $0x18,%edi
    75df:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    75e5:	e8 c6 e4 ff ff       	call   5ab0 <fwp_heap_alloc>
    75ea:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    75f0:	48 89 c3             	mov    %rax,%rbx
    75f3:	e9 16 ff ff ff       	jmp    750e <e161+0xce>
    75f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    75ff:	00 
    7600:	66 85 c0             	test   %ax,%ax
    7603:	75 91                	jne    7596 <e161+0x156>
    7605:	eb 81                	jmp    7588 <e161+0x148>
    7607:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    760e:	00 00 
    7610:	48 89 ef             	mov    %rbp,%rdi
    7613:	e8 58 dd ff ff       	call   5370 <fwp_rc_forget_slot>
    7618:	e9 75 ff ff ff       	jmp    7592 <e161+0x152>
    761d:	e8 de c0 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    7622:	e8 89 c6 ff ff       	call   3cb0 <fwp_heap_oom>
    7627:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    762e:	00 00 

0000000000007630 <fwp_drop4>:
    7630:	48 8b 15 41 b5 01 00 	mov    0x1b541(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    7637:	48 89 f8             	mov    %rdi,%rax
    763a:	48 2b 05 0f b5 01 00 	sub    0x1b50f(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    7641:	48 c1 e2 10          	shl    $0x10,%rdx
    7645:	48 39 d0             	cmp    %rdx,%rax
    7648:	0f 83 52 01 00 00    	jae    77a0 <fwp_drop4+0x170>
    764e:	48 83 ec 18          	sub    $0x18,%rsp
    7652:	4c 8d 05 47 a1 01 00 	lea    0x1a147(%rip),%r8        # 217a0 <fwp_heap>
    7659:	48 89 c2             	mov    %rax,%rdx
    765c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7663:	48 c1 ea 10          	shr    $0x10,%rdx
    7667:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    766b:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    766f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7673:	48 85 d2             	test   %rdx,%rdx
    7676:	74 46                	je     76be <fwp_drop4+0x8e>
    7678:	44 0f b6 09          	movzbl (%rcx),%r9d
    767c:	41 80 f9 02          	cmp    $0x2,%r9b
    7680:	0f 84 ca 00 00 00    	je     7750 <fwp_drop4+0x120>
    7686:	41 80 f9 01          	cmp    $0x1,%r9b
    768a:	75 32                	jne    76be <fwp_drop4+0x8e>
    768c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7690:	0f b7 c0             	movzwl %ax,%eax
    7693:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7696:	49 0f af c1          	imul   %r9,%rax
    769a:	48 c1 e8 20          	shr    $0x20,%rax
    769e:	48 39 c8             	cmp    %rcx,%rax
    76a1:	73 1b                	jae    76be <fwp_drop4+0x8e>
    76a3:	48 01 c2             	add    %rax,%rdx
    76a6:	0f b6 02             	movzbl (%rdx),%eax
    76a9:	84 c0                	test   %al,%al
    76ab:	74 11                	je     76be <fwp_drop4+0x8e>
    76ad:	3c 01                	cmp    $0x1,%al
    76af:	74 17                	je     76c8 <fwp_drop4+0x98>
    76b1:	3c ff                	cmp    $0xff,%al
    76b3:	0f 84 ef 00 00 00    	je     77a8 <fwp_drop4+0x178>
    76b9:	83 e8 01             	sub    $0x1,%eax
    76bc:	88 02                	mov    %al,(%rdx)
    76be:	48 83 c4 18          	add    $0x18,%rsp
    76c2:	c3                   	ret
    76c3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    76c8:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    76cc:	0f 88 8e 00 00 00    	js     7760 <fwp_drop4+0x130>
    76d2:	48 8b 15 9f b4 01 00 	mov    0x1b49f(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    76d9:	48 89 f8             	mov    %rdi,%rax
    76dc:	48 2b 05 6d b4 01 00 	sub    0x1b46d(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    76e3:	48 c1 e2 10          	shl    $0x10,%rdx
    76e7:	48 39 d0             	cmp    %rdx,%rax
    76ea:	73 d2                	jae    76be <fwp_drop4+0x8e>
    76ec:	48 89 c2             	mov    %rax,%rdx
    76ef:	48 c1 ea 10          	shr    $0x10,%rdx
    76f3:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    76f7:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    76fb:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    76ff:	48 85 c9             	test   %rcx,%rcx
    7702:	74 ba                	je     76be <fwp_drop4+0x8e>
    7704:	0f b6 32             	movzbl (%rdx),%esi
    7707:	40 80 fe 02          	cmp    $0x2,%sil
    770b:	74 33                	je     7740 <fwp_drop4+0x110>
    770d:	40 80 fe 01          	cmp    $0x1,%sil
    7711:	75 ab                	jne    76be <fwp_drop4+0x8e>
    7713:	8b 72 18             	mov    0x18(%rdx),%esi
    7716:	0f b7 c0             	movzwl %ax,%eax
    7719:	8b 52 1c             	mov    0x1c(%rdx),%edx
    771c:	48 0f af c6          	imul   %rsi,%rax
    7720:	48 c1 e8 20          	shr    $0x20,%rax
    7724:	48 39 d0             	cmp    %rdx,%rax
    7727:	73 95                	jae    76be <fwp_drop4+0x8e>
    7729:	48 01 c1             	add    %rax,%rcx
    772c:	80 39 01             	cmpb   $0x1,(%rcx)
    772f:	75 8d                	jne    76be <fwp_drop4+0x8e>
    7731:	48 83 c4 18          	add    $0x18,%rsp
    7735:	e9 76 de ff ff       	jmp    55b0 <fwp_mem_free>
    773a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7740:	66 85 c0             	test   %ax,%ax
    7743:	74 e7                	je     772c <fwp_drop4+0xfc>
    7745:	48 83 c4 18          	add    $0x18,%rsp
    7749:	c3                   	ret
    774a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7750:	66 85 c0             	test   %ax,%ax
    7753:	0f 84 4d ff ff ff    	je     76a6 <fwp_drop4+0x76>
    7759:	48 83 c4 18          	add    $0x18,%rsp
    775d:	c3                   	ret
    775e:	66 90                	xchg   %ax,%ax
    7760:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7764:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7769:	e8 f2 ed ff ff       	call   6560 <fwp_rc_free_arr>
    776e:	4c 8d 05 2b a0 01 00 	lea    0x1a02b(%rip),%r8        # 217a0 <fwp_heap>
    7775:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    777a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7781:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7788:	48 c1 e2 10          	shl    $0x10,%rdx
    778c:	48 39 d0             	cmp    %rdx,%rax
    778f:	0f 83 29 ff ff ff    	jae    76be <fwp_drop4+0x8e>
    7795:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    779a:	e9 ba fe ff ff       	jmp    7659 <fwp_drop4+0x29>
    779f:	90                   	nop
    77a0:	c3                   	ret
    77a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    77a8:	48 89 d0             	mov    %rdx,%rax
    77ab:	48 c1 e8 11          	shr    $0x11,%rax
    77af:	48 31 d0             	xor    %rdx,%rax
    77b2:	48 89 c1             	mov    %rax,%rcx
    77b5:	48 c1 e9 09          	shr    $0x9,%rcx
    77b9:	48 31 c8             	xor    %rcx,%rax
    77bc:	0f b6 c8             	movzbl %al,%ecx
    77bf:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    77c6:	00 
    77c7:	48 85 c0             	test   %rax,%rax
    77ca:	75 1d                	jne    77e9 <fwp_drop4+0x1b9>
    77cc:	eb 56                	jmp    7824 <fwp_drop4+0x1f4>
    77ce:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    77d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    77dc:	00 00 00 00 
    77e0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    77e4:	48 85 c0             	test   %rax,%rax
    77e7:	74 3b                	je     7824 <fwp_drop4+0x1f4>
    77e9:	48 89 c1             	mov    %rax,%rcx
    77ec:	48 39 10             	cmp    %rdx,(%rax)
    77ef:	75 ef                	jne    77e0 <fwp_drop4+0x1b0>
    77f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    77f5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    77f9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    77fd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7804:	0f 85 b4 fe ff ff    	jne    76be <fwp_drop4+0x8e>
    780a:	48 89 d7             	mov    %rdx,%rdi
    780d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7812:	e8 59 db ff ff       	call   5370 <fwp_rc_forget_slot>
    7817:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    781c:	c6 02 fe             	movb   $0xfe,(%rdx)
    781f:	e9 9a fe ff ff       	jmp    76be <fwp_drop4+0x8e>
    7824:	48 8d 3d 6d 5f 00 00 	lea    0x5f6d(%rip),%rdi        # d798 <_IO_stdin_used+0x798>
    782b:	e8 70 c9 ff ff       	call   41a0 <fwp_trap>

0000000000007830 <fwp_caps161>:
    7830:	f3 0f 1e fa          	endbr64
    7834:	85 f6                	test   %esi,%esi
    7836:	74 08                	je     7840 <fwp_caps161+0x10>
    7838:	c3                   	ret
    7839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7840:	48 8b 15 31 b3 01 00 	mov    0x1b331(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    7847:	48 89 f8             	mov    %rdi,%rax
    784a:	48 2b 05 ff b2 01 00 	sub    0x1b2ff(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    7851:	48 c1 e2 10          	shl    $0x10,%rdx
    7855:	48 39 d0             	cmp    %rdx,%rax
    7858:	73 de                	jae    7838 <fwp_caps161+0x8>
    785a:	48 89 c2             	mov    %rax,%rdx
    785d:	48 c1 ea 10          	shr    $0x10,%rdx
    7861:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7865:	48 8b 15 2c b3 01 00 	mov    0x1b32c(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    786c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7870:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7874:	48 85 c9             	test   %rcx,%rcx
    7877:	74 bf                	je     7838 <fwp_caps161+0x8>
    7879:	0f b6 32             	movzbl (%rdx),%esi
    787c:	40 80 fe 02          	cmp    $0x2,%sil
    7880:	74 2e                	je     78b0 <fwp_caps161+0x80>
    7882:	40 80 fe 01          	cmp    $0x1,%sil
    7886:	75 b0                	jne    7838 <fwp_caps161+0x8>
    7888:	8b 72 18             	mov    0x18(%rdx),%esi
    788b:	0f b7 c0             	movzwl %ax,%eax
    788e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7891:	48 0f af c6          	imul   %rsi,%rax
    7895:	48 c1 e8 20          	shr    $0x20,%rax
    7899:	48 39 d0             	cmp    %rdx,%rax
    789c:	73 9a                	jae    7838 <fwp_caps161+0x8>
    789e:	48 01 c1             	add    %rax,%rcx
    78a1:	80 39 01             	cmpb   $0x1,(%rcx)
    78a4:	75 92                	jne    7838 <fwp_caps161+0x8>
    78a6:	e9 05 dd ff ff       	jmp    55b0 <fwp_mem_free>
    78ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    78b0:	66 85 c0             	test   %ax,%ax
    78b3:	74 ec                	je     78a1 <fwp_caps161+0x71>
    78b5:	c3                   	ret
    78b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    78bd:	00 00 00 

00000000000078c0 <fwp_args12>:
    78c0:	f3 0f 1e fa          	endbr64
    78c4:	85 d2                	test   %edx,%edx
    78c6:	74 04                	je     78cc <fwp_args12+0xc>
    78c8:	85 f6                	test   %esi,%esi
    78ca:	74 04                	je     78d0 <fwp_args12+0x10>
    78cc:	c3                   	ret
    78cd:	0f 1f 00             	nopl   (%rax)
    78d0:	48 8b 15 a1 b2 01 00 	mov    0x1b2a1(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    78d7:	48 8b 07             	mov    (%rdi),%rax
    78da:	48 2b 05 6f b2 01 00 	sub    0x1b26f(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    78e1:	48 c1 e2 10          	shl    $0x10,%rdx
    78e5:	48 39 d0             	cmp    %rdx,%rax
    78e8:	73 e2                	jae    78cc <fwp_args12+0xc>
    78ea:	48 89 c2             	mov    %rax,%rdx
    78ed:	48 c1 ea 10          	shr    $0x10,%rdx
    78f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    78f5:	48 8b 15 9c b2 01 00 	mov    0x1b29c(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    78fc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7900:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7904:	48 85 ff             	test   %rdi,%rdi
    7907:	74 c3                	je     78cc <fwp_args12+0xc>
    7909:	0f b6 0a             	movzbl (%rdx),%ecx
    790c:	80 f9 02             	cmp    $0x2,%cl
    790f:	74 2f                	je     7940 <fwp_args12+0x80>
    7911:	80 f9 01             	cmp    $0x1,%cl
    7914:	75 b6                	jne    78cc <fwp_args12+0xc>
    7916:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7919:	0f b7 c0             	movzwl %ax,%eax
    791c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    791f:	48 0f af c1          	imul   %rcx,%rax
    7923:	48 c1 e8 20          	shr    $0x20,%rax
    7927:	48 39 d0             	cmp    %rdx,%rax
    792a:	73 a0                	jae    78cc <fwp_args12+0xc>
    792c:	48 01 c7             	add    %rax,%rdi
    792f:	0f b6 07             	movzbl (%rdi),%eax
    7932:	84 c0                	test   %al,%al
    7934:	74 96                	je     78cc <fwp_args12+0xc>
    7936:	3c fd                	cmp    $0xfd,%al
    7938:	77 0c                	ja     7946 <fwp_args12+0x86>
    793a:	83 c0 01             	add    $0x1,%eax
    793d:	88 07                	mov    %al,(%rdi)
    793f:	c3                   	ret
    7940:	66 85 c0             	test   %ax,%ax
    7943:	74 ea                	je     792f <fwp_args12+0x6f>
    7945:	c3                   	ret
    7946:	e9 05 d9 ff ff       	jmp    5250 <fwp_rc_wide_dup>
    794b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007950 <fwp_args23>:
    7950:	f3 0f 1e fa          	endbr64
    7954:	85 d2                	test   %edx,%edx
    7956:	74 04                	je     795c <fwp_args23+0xc>
    7958:	85 f6                	test   %esi,%esi
    795a:	74 04                	je     7960 <fwp_args23+0x10>
    795c:	c3                   	ret
    795d:	0f 1f 00             	nopl   (%rax)
    7960:	48 8b 15 11 b2 01 00 	mov    0x1b211(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    7967:	48 8b 07             	mov    (%rdi),%rax
    796a:	48 2b 05 df b1 01 00 	sub    0x1b1df(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    7971:	48 c1 e2 10          	shl    $0x10,%rdx
    7975:	48 39 d0             	cmp    %rdx,%rax
    7978:	73 e2                	jae    795c <fwp_args23+0xc>
    797a:	48 89 c2             	mov    %rax,%rdx
    797d:	48 c1 ea 10          	shr    $0x10,%rdx
    7981:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7985:	48 8b 15 0c b2 01 00 	mov    0x1b20c(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    798c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7990:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7994:	48 85 ff             	test   %rdi,%rdi
    7997:	74 c3                	je     795c <fwp_args23+0xc>
    7999:	0f b6 0a             	movzbl (%rdx),%ecx
    799c:	80 f9 02             	cmp    $0x2,%cl
    799f:	74 2f                	je     79d0 <fwp_args23+0x80>
    79a1:	80 f9 01             	cmp    $0x1,%cl
    79a4:	75 b6                	jne    795c <fwp_args23+0xc>
    79a6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    79a9:	0f b7 c0             	movzwl %ax,%eax
    79ac:	8b 52 1c             	mov    0x1c(%rdx),%edx
    79af:	48 0f af c1          	imul   %rcx,%rax
    79b3:	48 c1 e8 20          	shr    $0x20,%rax
    79b7:	48 39 d0             	cmp    %rdx,%rax
    79ba:	73 a0                	jae    795c <fwp_args23+0xc>
    79bc:	48 01 c7             	add    %rax,%rdi
    79bf:	0f b6 07             	movzbl (%rdi),%eax
    79c2:	84 c0                	test   %al,%al
    79c4:	74 96                	je     795c <fwp_args23+0xc>
    79c6:	3c fd                	cmp    $0xfd,%al
    79c8:	77 0c                	ja     79d6 <fwp_args23+0x86>
    79ca:	83 c0 01             	add    $0x1,%eax
    79cd:	88 07                	mov    %al,(%rdi)
    79cf:	c3                   	ret
    79d0:	66 85 c0             	test   %ax,%ax
    79d3:	74 ea                	je     79bf <fwp_args23+0x6f>
    79d5:	c3                   	ret
    79d6:	e9 75 d8 ff ff       	jmp    5250 <fwp_rc_wide_dup>
    79db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000079e0 <fwp_caps12>:
    79e0:	f3 0f 1e fa          	endbr64
    79e4:	48 83 ec 18          	sub    $0x18,%rsp
    79e8:	8b 57 04             	mov    0x4(%rdi),%edx
    79eb:	48 89 f8             	mov    %rdi,%rax
    79ee:	85 d2                	test   %edx,%edx
    79f0:	0f 84 9a 00 00 00    	je     7a90 <fwp_caps12+0xb0>
    79f6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    79fa:	85 f6                	test   %esi,%esi
    79fc:	0f 85 9e 00 00 00    	jne    7aa0 <fwp_caps12+0xc0>
    7a02:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7a07:	e8 64 ec ff ff       	call   6670 <fwp_drop0>
    7a0c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7a11:	48 8b 0d 60 b1 01 00 	mov    0x1b160(%rip),%rcx        # 22b78 <fwp_heap+0x13d8>
    7a18:	48 89 c2             	mov    %rax,%rdx
    7a1b:	48 2b 15 2e b1 01 00 	sub    0x1b12e(%rip),%rdx        # 22b50 <fwp_heap+0x13b0>
    7a22:	48 c1 e1 10          	shl    $0x10,%rcx
    7a26:	48 39 ca             	cmp    %rcx,%rdx
    7a29:	73 6d                	jae    7a98 <fwp_caps12+0xb8>
    7a2b:	48 89 d1             	mov    %rdx,%rcx
    7a2e:	48 c1 e9 10          	shr    $0x10,%rcx
    7a32:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7a36:	48 8b 0d 5b b1 01 00 	mov    0x1b15b(%rip),%rcx        # 22b98 <fwp_heap+0x13f8>
    7a3d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7a41:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7a45:	48 85 f6             	test   %rsi,%rsi
    7a48:	74 4e                	je     7a98 <fwp_caps12+0xb8>
    7a4a:	0f b6 39             	movzbl (%rcx),%edi
    7a4d:	40 80 ff 02          	cmp    $0x2,%dil
    7a51:	0f 84 b9 00 00 00    	je     7b10 <fwp_caps12+0x130>
    7a57:	40 80 ff 01          	cmp    $0x1,%dil
    7a5b:	75 3b                	jne    7a98 <fwp_caps12+0xb8>
    7a5d:	8b 79 18             	mov    0x18(%rcx),%edi
    7a60:	0f b7 d2             	movzwl %dx,%edx
    7a63:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7a66:	48 0f af d7          	imul   %rdi,%rdx
    7a6a:	48 c1 ea 20          	shr    $0x20,%rdx
    7a6e:	48 39 ca             	cmp    %rcx,%rdx
    7a71:	73 25                	jae    7a98 <fwp_caps12+0xb8>
    7a73:	48 01 d6             	add    %rdx,%rsi
    7a76:	80 3e 01             	cmpb   $0x1,(%rsi)
    7a79:	75 1d                	jne    7a98 <fwp_caps12+0xb8>
    7a7b:	48 89 c7             	mov    %rax,%rdi
    7a7e:	48 83 c4 18          	add    $0x18,%rsp
    7a82:	e9 29 db ff ff       	jmp    55b0 <fwp_mem_free>
    7a87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a8e:	00 00 
    7a90:	85 f6                	test   %esi,%esi
    7a92:	0f 84 79 ff ff ff    	je     7a11 <fwp_caps12+0x31>
    7a98:	48 83 c4 18          	add    $0x18,%rsp
    7a9c:	c3                   	ret
    7a9d:	0f 1f 00             	nopl   (%rax)
    7aa0:	48 8b 05 d1 b0 01 00 	mov    0x1b0d1(%rip),%rax        # 22b78 <fwp_heap+0x13d8>
    7aa7:	48 2b 3d a2 b0 01 00 	sub    0x1b0a2(%rip),%rdi        # 22b50 <fwp_heap+0x13b0>
    7aae:	48 c1 e0 10          	shl    $0x10,%rax
    7ab2:	48 39 c7             	cmp    %rax,%rdi
    7ab5:	73 e1                	jae    7a98 <fwp_caps12+0xb8>
    7ab7:	48 89 f8             	mov    %rdi,%rax
    7aba:	48 c1 e8 10          	shr    $0x10,%rax
    7abe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7ac2:	48 8b 05 cf b0 01 00 	mov    0x1b0cf(%rip),%rax        # 22b98 <fwp_heap+0x13f8>
    7ac9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7acd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7ad1:	48 85 c0             	test   %rax,%rax
    7ad4:	74 c2                	je     7a98 <fwp_caps12+0xb8>
    7ad6:	0f b6 0a             	movzbl (%rdx),%ecx
    7ad9:	80 f9 02             	cmp    $0x2,%cl
    7adc:	74 42                	je     7b20 <fwp_caps12+0x140>
    7ade:	80 f9 01             	cmp    $0x1,%cl
    7ae1:	75 b5                	jne    7a98 <fwp_caps12+0xb8>
    7ae3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ae6:	0f b7 ff             	movzwl %di,%edi
    7ae9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7aec:	48 0f af f9          	imul   %rcx,%rdi
    7af0:	48 c1 ef 20          	shr    $0x20,%rdi
    7af4:	48 39 d7             	cmp    %rdx,%rdi
    7af7:	73 9f                	jae    7a98 <fwp_caps12+0xb8>
    7af9:	48 01 f8             	add    %rdi,%rax
    7afc:	0f b6 10             	movzbl (%rax),%edx
    7aff:	84 d2                	test   %dl,%dl
    7b01:	74 95                	je     7a98 <fwp_caps12+0xb8>
    7b03:	80 fa fd             	cmp    $0xfd,%dl
    7b06:	77 23                	ja     7b2b <fwp_caps12+0x14b>
    7b08:	83 c2 01             	add    $0x1,%edx
    7b0b:	88 10                	mov    %dl,(%rax)
    7b0d:	eb 89                	jmp    7a98 <fwp_caps12+0xb8>
    7b0f:	90                   	nop
    7b10:	66 85 d2             	test   %dx,%dx
    7b13:	0f 85 7f ff ff ff    	jne    7a98 <fwp_caps12+0xb8>
    7b19:	e9 58 ff ff ff       	jmp    7a76 <fwp_caps12+0x96>
    7b1e:	66 90                	xchg   %ax,%ax
    7b20:	66 85 ff             	test   %di,%di
    7b23:	0f 85 6f ff ff ff    	jne    7a98 <fwp_caps12+0xb8>
    7b29:	eb d1                	jmp    7afc <fwp_caps12+0x11c>
    7b2b:	48 89 c7             	mov    %rax,%rdi
    7b2e:	48 83 c4 18          	add    $0x18,%rsp
    7b32:	e9 19 d7 ff ff       	jmp    5250 <fwp_rc_wide_dup>
    7b37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7b3e:	00 00 

0000000000007b40 <f12>:
    7b40:	41 57                	push   %r15
    7b42:	41 56                	push   %r14
    7b44:	41 55                	push   %r13
    7b46:	4c 8d 2d 33 f1 ff ff 	lea    -0xecd(%rip),%r13        # 6c80 <fwp_tape_scope_release>
    7b4d:	41 54                	push   %r12
    7b4f:	55                   	push   %rbp
    7b50:	53                   	push   %rbx
    7b51:	48 81 ec f8 00 00 00 	sub    $0xf8,%rsp
    7b58:	48 8b 15 19 b0 01 00 	mov    0x1b019(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    7b5f:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    7b64:	4c 8d 74 24 6c       	lea    0x6c(%rsp),%r14
    7b69:	4c 8d 7c 24 70       	lea    0x70(%rsp),%r15
    7b6e:	48 c1 e2 10          	shl    $0x10,%rdx
    7b72:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7b79:	00 00 
    7b7b:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    7b82:	00 
    7b83:	31 c0                	xor    %eax,%eax
    7b85:	48 8b 05 ac b8 01 00 	mov    0x1b8ac(%rip),%rax        # 23438 <fwp_cleanups>
    7b8c:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    7b91:	c7 44 24 6c ff ff ff 	movl   $0xffffffff,0x6c(%rsp)
    7b98:	ff 
    7b99:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    7b9e:	48 8d 05 6b 94 00 00 	lea    0x946b(%rip),%rax        # 11010 <fc23>
    7ba5:	48 2b 05 a4 af 01 00 	sub    0x1afa4(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    7bac:	4c 89 b4 24 80 00 00 	mov    %r14,0x80(%rsp)
    7bb3:	00 
    7bb4:	4c 89 3d 7d b8 01 00 	mov    %r15,0x1b87d(%rip)        # 23438 <fwp_cleanups>
    7bbb:	48 39 d0             	cmp    %rdx,%rax
    7bbe:	73 5d                	jae    7c1d <f12+0xdd>
    7bc0:	48 89 c2             	mov    %rax,%rdx
    7bc3:	48 c1 ea 10          	shr    $0x10,%rdx
    7bc7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7bcb:	48 8b 15 c6 af 01 00 	mov    0x1afc6(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    7bd2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7bd6:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7bda:	48 85 ff             	test   %rdi,%rdi
    7bdd:	74 3e                	je     7c1d <f12+0xdd>
    7bdf:	0f b6 0a             	movzbl (%rdx),%ecx
    7be2:	80 f9 02             	cmp    $0x2,%cl
    7be5:	0f 84 75 11 00 00    	je     8d60 <f12+0x1220>
    7beb:	80 f9 01             	cmp    $0x1,%cl
    7bee:	75 2d                	jne    7c1d <f12+0xdd>
    7bf0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7bf3:	0f b7 c0             	movzwl %ax,%eax
    7bf6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7bf9:	48 0f af c1          	imul   %rcx,%rax
    7bfd:	48 c1 e8 20          	shr    $0x20,%rax
    7c01:	48 39 d0             	cmp    %rdx,%rax
    7c04:	73 17                	jae    7c1d <f12+0xdd>
    7c06:	48 01 c7             	add    %rax,%rdi
    7c09:	0f b6 07             	movzbl (%rdi),%eax
    7c0c:	84 c0                	test   %al,%al
    7c0e:	74 0d                	je     7c1d <f12+0xdd>
    7c10:	3c fd                	cmp    $0xfd,%al
    7c12:	0f 87 aa 13 00 00    	ja     8fc2 <f12+0x1482>
    7c18:	83 c0 01             	add    $0x1,%eax
    7c1b:	88 07                	mov    %al,(%rdi)
    7c1d:	48 8d 3d ec 93 00 00 	lea    0x93ec(%rip),%rdi        # 11010 <fc23>
    7c24:	e8 27 ed ff ff       	call   6950 <fwp_closure_drop>
    7c29:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7c2e:	48 85 c0             	test   %rax,%rax
    7c31:	0f 84 a9 12 00 00    	je     8ee0 <f12+0x13a0>
    7c37:	31 d2                	xor    %edx,%edx
    7c39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c40:	48 8b 40 10          	mov    0x10(%rax),%rax
    7c44:	48 83 c2 01          	add    $0x1,%rdx
    7c48:	48 85 c0             	test   %rax,%rax
    7c4b:	75 f3                	jne    7c40 <f12+0x100>
    7c4d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    7c54:	0f 87 31 14 00 00    	ja     908b <f12+0x154b>
    7c5a:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    7c5f:	44 8b 05 1a 94 00 00 	mov    0x941a(%rip),%r8d        # 11080 <registered_finish.0>
    7c66:	45 85 c0             	test   %r8d,%r8d
    7c69:	0f 84 c1 10 00 00    	je     8d30 <f12+0x11f0>
    7c6f:	48 8b 1d a2 94 01 00 	mov    0x194a2(%rip),%rbx        # 21118 <fwp_tape_next_slot>
    7c76:	4c 8b 25 ab 94 01 00 	mov    0x194ab(%rip),%r12        # 21128 <fwp_ntapes>
    7c7d:	4c 39 e3             	cmp    %r12,%rbx
    7c80:	0f 8d e2 00 00 00    	jge    7d68 <f12+0x228>
    7c86:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    7c8a:	48 03 05 9f 94 01 00 	add    0x1949f(%rip),%rax        # 21130 <fwp_tapes>
    7c91:	0f 1f 40 00          	nopl   0x0(%rax)
    7c95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7c9c:	00 00 00 00 
    7ca0:	8b 78 04             	mov    0x4(%rax),%edi
    7ca3:	85 ff                	test   %edi,%edi
    7ca5:	75 0c                	jne    7cb3 <f12+0x173>
    7ca7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    7cad:	0f 86 b5 00 00 00    	jbe    7d68 <f12+0x228>
    7cb3:	48 83 c3 01          	add    $0x1,%rbx
    7cb7:	48 83 c0 68          	add    $0x68,%rax
    7cbb:	4c 39 e3             	cmp    %r12,%rbx
    7cbe:	75 e0                	jne    7ca0 <f12+0x160>
    7cc0:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    7cc7:	0f 8f 3c 14 00 00    	jg     9109 <f12+0x15c9>
    7ccd:	4c 39 25 4c 94 01 00 	cmp    %r12,0x1944c(%rip)        # 21120 <fwp_tapes_cap>
    7cd4:	48 8b 2d 55 94 01 00 	mov    0x19455(%rip),%rbp        # 21130 <fwp_tapes>
    7cdb:	75 4b                	jne    7d28 <f12+0x1e8>
    7cdd:	4d 85 e4             	test   %r12,%r12
    7ce0:	0f 84 5c 12 00 00    	je     8f42 <f12+0x1402>
    7ce6:	4b 8d 1c 24          	lea    (%r12,%r12,1),%rbx
    7cea:	b8 ff ff 00 00       	mov    $0xffff,%eax
    7cef:	48 39 c3             	cmp    %rax,%rbx
    7cf2:	48 0f 4f d8          	cmovg  %rax,%rbx
    7cf6:	48 6b f3 68          	imul   $0x68,%rbx,%rsi
    7cfa:	48 89 ef             	mov    %rbp,%rdi
    7cfd:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    7d03:	e8 c8 b8 ff ff       	call   35d0 <realloc@plt>
    7d08:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    7d0e:	48 85 c0             	test   %rax,%rax
    7d11:	48 89 c5             	mov    %rax,%rbp
    7d14:	0f 84 b5 13 00 00    	je     90cf <f12+0x158f>
    7d1a:	48 89 05 0f 94 01 00 	mov    %rax,0x1940f(%rip)        # 21130 <fwp_tapes>
    7d21:	48 89 1d f8 93 01 00 	mov    %rbx,0x193f8(%rip)        # 21120 <fwp_tapes_cap>
    7d28:	49 6b c4 68          	imul   $0x68,%r12,%rax
    7d2c:	4c 89 e3             	mov    %r12,%rbx
    7d2f:	48 01 e8             	add    %rbp,%rax
    7d32:	48 8d 78 08          	lea    0x8(%rax),%rdi
    7d36:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    7d3d:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    7d41:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    7d48:	00 
    7d49:	48 29 f8             	sub    %rdi,%rax
    7d4c:	8d 48 68             	lea    0x68(%rax),%ecx
    7d4f:	31 c0                	xor    %eax,%eax
    7d51:	c1 e9 03             	shr    $0x3,%ecx
    7d54:	f3 48 ab             	rep stos %rax,(%rdi)
    7d57:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    7d5c:	48 89 05 c5 93 01 00 	mov    %rax,0x193c5(%rip)        # 21128 <fwp_ntapes>
    7d63:	eb 13                	jmp    7d78 <f12+0x238>
    7d65:	0f 1f 00             	nopl   (%rax)
    7d68:	49 39 dc             	cmp    %rbx,%r12
    7d6b:	0f 84 4f ff ff ff    	je     7cc0 <f12+0x180>
    7d71:	48 8b 2d b8 93 01 00 	mov    0x193b8(%rip),%rbp        # 21130 <fwp_tapes>
    7d78:	4c 6b e3 68          	imul   $0x68,%rbx,%r12
    7d7c:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    7d80:	48 8d 3d 38 53 00 00 	lea    0x5338(%rip),%rdi        # d0bf <_IO_stdin_used+0xbf>
    7d87:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7d8c:	49 01 ec             	add    %rbp,%r12
    7d8f:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    7d96:	00 00 
    7d98:	e8 03 b6 ff ff       	call   33a0 <getenv@plt>
    7d9d:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    7da3:	48 85 c0             	test   %rax,%rax
    7da6:	74 09                	je     7db1 <f12+0x271>
    7da8:	80 38 30             	cmpb   $0x30,(%rax)
    7dab:	0f 84 ff 06 00 00    	je     84b0 <f12+0x970>
    7db1:	48 83 3d 0f 93 01 00 	cmpq   $0x0,0x1930f(%rip)        # 210c8 <fwp_tape_cached_bytes>
    7db8:	00 
    7db9:	0f 85 01 10 00 00    	jne    8dc0 <f12+0x1280>
    7dbf:	41 8b 04 24          	mov    (%r12),%eax
    7dc3:	48 8d 7b 01          	lea    0x1(%rbx),%rdi
    7dc7:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    7dce:	00 00 
    7dd0:	48 89 3d 41 93 01 00 	mov    %rdi,0x19341(%rip)        # 21118 <fwp_tape_next_slot>
    7dd7:	8d 70 01             	lea    0x1(%rax),%esi
    7dda:	48 8b 05 57 b6 01 00 	mov    0x1b657(%rip),%rax        # 23438 <fwp_cleanups>
    7de1:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    7de8:	00 00 
    7dea:	41 89 34 24          	mov    %esi,(%r12)
    7dee:	49 c7 44 24 58 ff ff 	movq   $0xffffffffffffffff,0x58(%r12)
    7df5:	ff ff 
    7df7:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    7dfd:	48 85 c0             	test   %rax,%rax
    7e00:	75 1a                	jne    7e1c <f12+0x2dc>
    7e02:	e9 f6 12 00 00       	jmp    90fd <f12+0x15bd>
    7e07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7e0e:	00 00 
    7e10:	48 8b 00             	mov    (%rax),%rax
    7e13:	48 85 c0             	test   %rax,%rax
    7e16:	0f 84 e1 12 00 00    	je     90fd <f12+0x15bd>
    7e1c:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    7e20:	75 ee                	jne    7e10 <f12+0x2d0>
    7e22:	48 8b 48 10          	mov    0x10(%rax),%rcx
    7e26:	41 89 d8             	mov    %ebx,%r8d
    7e29:	48 63 01             	movslq (%rcx),%rax
    7e2c:	49 89 4c 24 50       	mov    %rcx,0x50(%r12)
    7e31:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    7e36:	85 c0                	test   %eax,%eax
    7e38:	78 08                	js     7e42 <f12+0x302>
    7e3a:	48 6b c0 68          	imul   $0x68,%rax,%rax
    7e3e:	89 5c 05 58          	mov    %ebx,0x58(%rbp,%rax,1)
    7e42:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    7e47:	44 89 01             	mov    %r8d,(%rcx)
    7e4a:	31 c9                	xor    %ecx,%ecx
    7e4c:	48 89 d8             	mov    %rbx,%rax
    7e4f:	48 85 db             	test   %rbx,%rbx
    7e52:	0f 84 d8 0d 00 00    	je     8c30 <f12+0x10f0>
    7e58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7e5f:	00 
    7e60:	48 8b 40 10          	mov    0x10(%rax),%rax
    7e64:	48 83 c1 01          	add    $0x1,%rcx
    7e68:	48 85 c0             	test   %rax,%rax
    7e6b:	75 f3                	jne    7e60 <f12+0x320>
    7e6d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7e72:	0f 1f 00             	nopl   (%rax)
    7e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e7c:	00 00 00 00 
    7e80:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    7e84:	48 83 c0 01          	add    $0x1,%rax
    7e88:	48 85 d2             	test   %rdx,%rdx
    7e8b:	75 f3                	jne    7e80 <f12+0x340>
    7e8d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    7e94:	ff ff 1f 
    7e97:	48 39 c2             	cmp    %rax,%rdx
    7e9a:	0f 82 f7 11 00 00    	jb     9097 <f12+0x1557>
    7ea0:	48 85 c9             	test   %rcx,%rcx
    7ea3:	0f 8e 87 0d 00 00    	jle    8c30 <f12+0x10f0>
    7ea9:	48 39 c1             	cmp    %rax,%rcx
    7eac:	48 0f 46 c1          	cmovbe %rcx,%rax
    7eb0:	49 89 c5             	mov    %rax,%r13
    7eb3:	48 c1 e8 3c          	shr    $0x3c,%rax
    7eb7:	0f 85 da 11 00 00    	jne    9097 <f12+0x1557>
    7ebd:	48 c1 e6 10          	shl    $0x10,%rsi
    7ec1:	4b 8d 6c 2d 00       	lea    0x0(%r13,%r13,1),%rbp
    7ec6:	48 09 fe             	or     %rdi,%rsi
    7ec9:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7ed0:	00 
    7ed1:	49 89 f4             	mov    %rsi,%r12
    7ed4:	be 02 00 00 00       	mov    $0x2,%esi
    7ed9:	e8 d2 db ff ff       	call   5ab0 <fwp_heap_alloc>
    7ede:	48 89 28             	mov    %rbp,(%rax)
    7ee1:	48 8b 15 90 ac 01 00 	mov    0x1ac90(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    7ee8:	48 89 c3             	mov    %rax,%rbx
    7eeb:	48 2b 05 5e ac 01 00 	sub    0x1ac5e(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    7ef2:	48 c1 e2 10          	shl    $0x10,%rdx
    7ef6:	48 39 d0             	cmp    %rdx,%rax
    7ef9:	0f 83 d1 0d 00 00    	jae    8cd0 <f12+0x1190>
    7eff:	48 89 c2             	mov    %rax,%rdx
    7f02:	48 c1 ea 10          	shr    $0x10,%rdx
    7f06:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7f0a:	48 8b 15 87 ac 01 00 	mov    0x1ac87(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    7f11:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7f15:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7f19:	48 85 d2             	test   %rdx,%rdx
    7f1c:	74 38                	je     7f56 <f12+0x416>
    7f1e:	0f b6 31             	movzbl (%rcx),%esi
    7f21:	40 80 fe 02          	cmp    $0x2,%sil
    7f25:	0f 84 72 0d 00 00    	je     8c9d <f12+0x115d>
    7f2b:	40 80 fe 01          	cmp    $0x1,%sil
    7f2f:	75 25                	jne    7f56 <f12+0x416>
    7f31:	8b 71 18             	mov    0x18(%rcx),%esi
    7f34:	0f b7 c0             	movzwl %ax,%eax
    7f37:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7f3a:	48 0f af c6          	imul   %rsi,%rax
    7f3e:	48 c1 e8 20          	shr    $0x20,%rax
    7f42:	48 39 c8             	cmp    %rcx,%rax
    7f45:	73 0f                	jae    7f56 <f12+0x416>
    7f47:	48 01 c2             	add    %rax,%rdx
    7f4a:	80 3a ff             	cmpb   $0xff,(%rdx)
    7f4d:	0f 84 fe 0f 00 00    	je     8f51 <f12+0x1411>
    7f53:	c6 02 01             	movb   $0x1,(%rdx)
    7f56:	4d 85 ed             	test   %r13,%r13
    7f59:	74 58                	je     7fb3 <f12+0x473>
    7f5b:	4c 89 e1             	mov    %r12,%rcx
    7f5e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7f63:	31 c0                	xor    %eax,%eax
    7f65:	48 c1 e1 20          	shl    $0x20,%rcx
    7f69:	90                   	nop
    7f6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7f71:	00 00 00 00 
    7f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7f7c:	00 00 00 00 
    7f80:	48 89 c6             	mov    %rax,%rsi
    7f83:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    7f88:	48 01 ce             	add    %rcx,%rsi
    7f8b:	0f 80 ed 10 00 00    	jo     907e <f12+0x153e>
    7f91:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    7f96:	48 89 c6             	mov    %rax,%rsi
    7f99:	48 83 c0 01          	add    $0x1,%rax
    7f9d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    7fa1:	48 c1 e6 04          	shl    $0x4,%rsi
    7fa5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    7faa:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    7fae:	4c 39 e8             	cmp    %r13,%rax
    7fb1:	72 cd                	jb     7f80 <f12+0x440>
    7fb3:	48 8b 03             	mov    (%rbx),%rax
    7fb6:	48 d1 e8             	shr    $1,%rax
    7fb9:	0f 84 21 0d 00 00    	je     8ce0 <f12+0x11a0>
    7fbf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7fc3:	48 89 d1             	mov    %rdx,%rcx
    7fc6:	48 c1 e9 3c          	shr    $0x3c,%rcx
    7fca:	0f 85 c7 10 00 00    	jne    9097 <f12+0x1557>
    7fd0:	48 8d 0c 12          	lea    (%rdx,%rdx,1),%rcx
    7fd4:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    7fd9:	48 85 d2             	test   %rdx,%rdx
    7fdc:	74 3f                	je     801d <f12+0x4dd>
    7fde:	48 c1 e0 04          	shl    $0x4,%rax
    7fe2:	48 8d 6b 08          	lea    0x8(%rbx),%rbp
    7fe6:	4c 8d 6c 03 f8       	lea    -0x8(%rbx,%rax,1),%r13
    7feb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7ff0:	f2 0f 10 45 00       	movsd  0x0(%rbp),%xmm0
    7ff5:	48 8b 75 18          	mov    0x18(%rbp),%rsi
    7ff9:	48 83 c5 10          	add    $0x10,%rbp
    7ffd:	48 8b 7d f8          	mov    -0x8(%rbp),%rdi
    8001:	f2 0f 10 4d 00       	movsd  0x0(%rbp),%xmm1
    8006:	e8 85 e1 ff ff       	call   6190 <w107>
    800b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    8010:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    8014:	0f 11 45 f0          	movups %xmm0,-0x10(%rbp)
    8018:	49 39 ed             	cmp    %rbp,%r13
    801b:	75 d3                	jne    7ff0 <f12+0x4b0>
    801d:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8022:	48 89 df             	mov    %rbx,%rdi
    8025:	48 89 03             	mov    %rax,(%rbx)
    8028:	e8 e3 e2 ff ff       	call   6310 <w164.constprop.0>
    802d:	48 89 df             	mov    %rbx,%rdi
    8030:	49 63 dc             	movslq %r12d,%rbx
    8033:	49 89 c5             	mov    %rax,%r13
    8036:	e8 f5 f5 ff ff       	call   7630 <fwp_drop4>
    803b:	48 89 df             	mov    %rbx,%rdi
    803e:	e8 dd cc ff ff       	call   4d20 <caf61>
    8043:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    8048:	e8 33 c4 ff ff       	call   4480 <fwp_tape_of>
    804d:	48 89 c6             	mov    %rax,%rsi
    8050:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    8055:	0f 85 bf 10 00 00    	jne    911a <f12+0x15da>
    805b:	48 89 c7             	mov    %rax,%rdi
    805e:	e8 9d bb ff ff       	call   3c00 <fwp_tape_unlink_scope>
    8063:	48 8b 56 48          	mov    0x48(%rsi),%rdx
    8067:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    806c:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    8073:	48 8b 6e 08          	mov    0x8(%rsi),%rbp
    8077:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
    807b:	66 48 0f 6e fa       	movq   %rdx,%xmm7
    8080:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    8085:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    808a:	48 8b 4e 40          	mov    0x40(%rsi),%rcx
    808e:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    8092:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    8098:	77 19                	ja     80b3 <f12+0x573>
    809a:	41 0f b7 c4          	movzwl %r12w,%eax
    809e:	83 e8 01             	sub    $0x1,%eax
    80a1:	48 98                	cltq
    80a3:	48 3b 05 6e 90 01 00 	cmp    0x1906e(%rip),%rax        # 21118 <fwp_tape_next_slot>
    80aa:	7d 07                	jge    80b3 <f12+0x573>
    80ac:	48 89 05 65 90 01 00 	mov    %rax,0x19065(%rip)        # 21118 <fwp_tape_next_slot>
    80b3:	48 8b 05 7e b3 01 00 	mov    0x1b37e(%rip),%rax        # 23438 <fwp_cleanups>
    80ba:	66 0f ef c9          	pxor   %xmm1,%xmm1
    80be:	4c 8d a4 24 b0 00 00 	lea    0xb0(%rsp),%r12
    80c5:	00 
    80c6:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    80cd:	00 
    80ce:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    80d2:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    80d9:	00 
    80da:	48 8d 05 af cd ff ff 	lea    -0x3251(%rip),%rax        # 4e90 <fwp_tape_buffers_release>
    80e1:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    80e8:	00 
    80e9:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    80f0:	00 
    80f1:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    80f5:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    80f9:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    8100:	00 
    8101:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    8108:	00 
    8109:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
    8110:	00 
    8111:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
    8118:	00 
    8119:	48 89 05 18 b3 01 00 	mov    %rax,0x1b318(%rip)        # 23438 <fwp_cleanups>
    8120:	0f 29 9c 24 b0 00 00 	movaps %xmm3,0xb0(%rsp)
    8127:	00 
    8128:	0f 29 94 24 c0 00 00 	movaps %xmm2,0xc0(%rsp)
    812f:	00 
    8130:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
    8137:	00 
    8138:	4d 85 ed             	test   %r13,%r13
    813b:	0f 88 2f 0c 00 00    	js     8d70 <f12+0x1230>
    8141:	4c 89 e8             	mov    %r13,%rax
    8144:	48 c1 f8 20          	sar    $0x20,%rax
    8148:	48 39 c3             	cmp    %rax,%rbx
    814b:	0f 85 10 0f 00 00    	jne    9061 <f12+0x1521>
    8151:	45 89 e9             	mov    %r13d,%r9d
    8154:	4c 89 cb             	mov    %r9,%rbx
    8157:	4c 39 cf             	cmp    %r9,%rdi
    815a:	0f 8e f5 0e 00 00    	jle    9055 <f12+0x1515>
    8160:	4c 39 cd             	cmp    %r9,%rbp
    8163:	0f 8e 87 0b 00 00    	jle    8cf0 <f12+0x11b0>
    8169:	48 39 d5             	cmp    %rdx,%rbp
    816c:	0f 8e c6 0c 00 00    	jle    8e38 <f12+0x12f8>
    8172:	49 89 ea             	mov    %rbp,%r10
    8175:	48 85 d2             	test   %rdx,%rdx
    8178:	49 0f 44 d2          	cmove  %r10,%rdx
    817c:	eb 17                	jmp    8195 <f12+0x655>
    817e:	66 90                	xchg   %ax,%ax
    8180:	48 8d 34 12          	lea    (%rdx,%rdx,1),%rsi
    8184:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
    818b:	4c 89 d0             	mov    %r10,%rax
    818e:	48 0f 4c c6          	cmovl  %rsi,%rax
    8192:	48 89 c2             	mov    %rax,%rdx
    8195:	49 39 d2             	cmp    %rdx,%r10
    8198:	7f e6                	jg     8180 <f12+0x640>
    819a:	4c 89 54 24 30       	mov    %r10,0x30(%rsp)
    819f:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    81a4:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
    81a9:	48 85 c9             	test   %rcx,%rcx
    81ac:	0f 84 fe 0c 00 00    	je     8eb0 <f12+0x1370>
    81b2:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
    81b9:	00 
    81ba:	48 89 cf             	mov    %rcx,%rdi
    81bd:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    81c2:	e8 09 b4 ff ff       	call   35d0 <realloc@plt>
    81c7:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    81cc:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
    81d1:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
    81d7:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    81dd:	48 89 c1             	mov    %rax,%rcx
    81e0:	48 85 c9             	test   %rcx,%rcx
    81e3:	0f 84 c6 0e 00 00    	je     90af <f12+0x156f>
    81e9:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
    81f0:	00 
    81f1:	48 89 94 24 e0 00 00 	mov    %rdx,0xe0(%rsp)
    81f8:	00 
    81f9:	4d 85 d2             	test   %r10,%r10
    81fc:	0f 85 7f 0d 00 00    	jne    8f81 <f12+0x1441>
    8202:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    8209:	4d 85 ed             	test   %r13,%r13
    820c:	78 15                	js     8223 <f12+0x6e3>
    820e:	45 89 e9             	mov    %r13d,%r9d
    8211:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    8217:	f2 42 0f 58 04 c9    	addsd  (%rcx,%r9,8),%xmm0
    821d:	f2 42 0f 11 04 c9    	movsd  %xmm0,(%rcx,%r9,8)
    8223:	48 39 dd             	cmp    %rbx,%rbp
    8226:	0f 8f 8e 00 00 00    	jg     82ba <f12+0x77a>
    822c:	0f 12 f3             	movhlps %xmm3,%xmm6
    822f:	66 48 0f 7e de       	movq   %xmm3,%rsi
    8234:	0f 12 da             	movhlps %xmm2,%xmm3
    8237:	48 29 eb             	sub    %rbp,%rbx
    823a:	66 49 0f 7e db       	movq   %xmm3,%r11
    823f:	66 48 0f 7e f7       	movq   %xmm6,%rdi
    8244:	66 49 0f 7e d2       	movq   %xmm2,%r10
    8249:	4c 8d 0c e9          	lea    (%rcx,%rbp,8),%r9
    824d:	49 8d 14 db          	lea    (%r11,%rbx,8),%rdx
    8251:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8255:	48 29 fe             	sub    %rdi,%rsi
    8258:	48 8d 04 9f          	lea    (%rdi,%rbx,4),%rax
    825c:	4d 29 d9             	sub    %r11,%r9
    825f:	4d 29 da             	sub    %r11,%r10
    8262:	eb 08                	jmp    826c <f12+0x72c>
    8264:	0f 1f 40 00          	nopl   0x0(%rax)
    8268:	48 83 e8 04          	sub    $0x4,%rax
    826c:	f2 41 0f 10 04 11    	movsd  (%r9,%rdx,1),%xmm0
    8272:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    8276:	7a 02                	jp     827a <f12+0x73a>
    8278:	74 37                	je     82b1 <f12+0x771>
    827a:	4c 63 1c 06          	movslq (%rsi,%rax,1),%r11
    827e:	45 85 db             	test   %r11d,%r11d
    8281:	78 16                	js     8299 <f12+0x759>
    8283:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    8289:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    828d:	f2 42 0f 58 0c d9    	addsd  (%rcx,%r11,8),%xmm1
    8293:	f2 42 0f 11 0c d9    	movsd  %xmm1,(%rcx,%r11,8)
    8299:	4c 63 18             	movslq (%rax),%r11
    829c:	45 85 db             	test   %r11d,%r11d
    829f:	78 10                	js     82b1 <f12+0x771>
    82a1:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    82a5:	f2 42 0f 58 04 d9    	addsd  (%rcx,%r11,8),%xmm0
    82ab:	f2 42 0f 11 04 d9    	movsd  %xmm0,(%rcx,%r11,8)
    82b1:	48 83 ea 08          	sub    $0x8,%rdx
    82b5:	48 39 c7             	cmp    %rax,%rdi
    82b8:	75 ae                	jne    8268 <f12+0x728>
    82ba:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    82c1:	ff ff 1f 
    82c4:	48 39 e8             	cmp    %rbp,%rax
    82c7:	0f 82 d6 0d 00 00    	jb     90a3 <f12+0x1563>
    82cd:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    82d4:	00 
    82d5:	be 02 00 00 00       	mov    $0x2,%esi
    82da:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    82df:	e8 cc d7 ff ff       	call   5ab0 <fwp_heap_alloc>
    82e4:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    82e9:	48 89 28             	mov    %rbp,(%rax)
    82ec:	48 89 c3             	mov    %rax,%rbx
    82ef:	31 c0                	xor    %eax,%eax
    82f1:	48 85 ed             	test   %rbp,%rbp
    82f4:	74 1c                	je     8312 <f12+0x7d2>
    82f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    82fd:	00 00 00 
    8300:	48 8b 14 c1          	mov    (%rcx,%rax,8),%rdx
    8304:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    8309:	48 83 c0 01          	add    $0x1,%rax
    830d:	48 39 c5             	cmp    %rax,%rbp
    8310:	75 ee                	jne    8300 <f12+0x7c0>
    8312:	4c 8b ac 24 90 00 00 	mov    0x90(%rsp),%r13
    8319:	00 
    831a:	4c 89 e7             	mov    %r12,%rdi
    831d:	4c 89 2d 14 b1 01 00 	mov    %r13,0x1b114(%rip)        # 23438 <fwp_cleanups>
    8324:	e8 67 cb ff ff       	call   4e90 <fwp_tape_buffers_release>
    8329:	48 8b 15 48 a8 01 00 	mov    0x1a848(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    8330:	48 89 d8             	mov    %rbx,%rax
    8333:	48 2b 05 16 a8 01 00 	sub    0x1a816(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    833a:	48 c1 e2 10          	shl    $0x10,%rdx
    833e:	48 39 d0             	cmp    %rdx,%rax
    8341:	73 59                	jae    839c <f12+0x85c>
    8343:	48 89 c2             	mov    %rax,%rdx
    8346:	48 c1 ea 10          	shr    $0x10,%rdx
    834a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    834e:	48 8b 15 43 a8 01 00 	mov    0x1a843(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    8355:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8359:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    835d:	4d 85 e4             	test   %r12,%r12
    8360:	74 3a                	je     839c <f12+0x85c>
    8362:	0f b6 0a             	movzbl (%rdx),%ecx
    8365:	80 f9 02             	cmp    $0x2,%cl
    8368:	0f 84 32 0a 00 00    	je     8da0 <f12+0x1260>
    836e:	80 f9 01             	cmp    $0x1,%cl
    8371:	75 29                	jne    839c <f12+0x85c>
    8373:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8376:	0f b7 c0             	movzwl %ax,%eax
    8379:	8b 52 1c             	mov    0x1c(%rdx),%edx
    837c:	48 0f af c1          	imul   %rcx,%rax
    8380:	48 c1 e8 20          	shr    $0x20,%rax
    8384:	48 39 d0             	cmp    %rdx,%rax
    8387:	73 13                	jae    839c <f12+0x85c>
    8389:	49 01 c4             	add    %rax,%r12
    838c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8391:	0f 84 d1 0b 00 00    	je     8f68 <f12+0x1428>
    8397:	41 c6 04 24 01       	movb   $0x1,(%r12)
    839c:	4d 39 fd             	cmp    %r15,%r13
    839f:	0f 85 a6 b3 ff ff    	jne    374b <f12.cold>
    83a5:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    83aa:	4c 89 f7             	mov    %r14,%rdi
    83ad:	48 89 05 84 b0 01 00 	mov    %rax,0x1b084(%rip)        # 23438 <fwp_cleanups>
    83b4:	e8 c7 e8 ff ff       	call   6c80 <fwp_tape_scope_release>
    83b9:	48 8b 03             	mov    (%rbx),%rax
    83bc:	49 89 c4             	mov    %rax,%r12
    83bf:	49 0f ba f4 3f       	btr    $0x3f,%r12
    83c4:	48 85 c0             	test   %rax,%rax
    83c7:	0f 88 b3 07 00 00    	js     8b80 <f12+0x1040>
    83cd:	48 8b 15 a4 a7 01 00 	mov    0x1a7a4(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    83d4:	48 89 d8             	mov    %rbx,%rax
    83d7:	48 2b 05 72 a7 01 00 	sub    0x1a772(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    83de:	48 c1 e2 10          	shl    $0x10,%rdx
    83e2:	48 39 d0             	cmp    %rdx,%rax
    83e5:	0f 83 95 07 00 00    	jae    8b80 <f12+0x1040>
    83eb:	48 89 c2             	mov    %rax,%rdx
    83ee:	48 c1 ea 10          	shr    $0x10,%rdx
    83f2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    83f6:	48 8b 15 9b a7 01 00 	mov    0x1a79b(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    83fd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8401:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    8405:	48 85 c9             	test   %rcx,%rcx
    8408:	0f 84 72 07 00 00    	je     8b80 <f12+0x1040>
    840e:	0f b6 32             	movzbl (%rdx),%esi
    8411:	40 80 fe 02          	cmp    $0x2,%sil
    8415:	0f 84 55 07 00 00    	je     8b70 <f12+0x1030>
    841b:	40 80 fe 01          	cmp    $0x1,%sil
    841f:	0f 85 5b 07 00 00    	jne    8b80 <f12+0x1040>
    8425:	8b 72 18             	mov    0x18(%rdx),%esi
    8428:	0f b7 c0             	movzwl %ax,%eax
    842b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    842e:	48 0f af c6          	imul   %rsi,%rax
    8432:	48 c1 e8 20          	shr    $0x20,%rax
    8436:	48 39 d0             	cmp    %rdx,%rax
    8439:	0f 83 41 07 00 00    	jae    8b80 <f12+0x1040>
    843f:	48 01 c1             	add    %rax,%rcx
    8442:	80 39 01             	cmpb   $0x1,(%rcx)
    8445:	0f 85 35 07 00 00    	jne    8b80 <f12+0x1040>
    844b:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
    8450:	49 89 dd             	mov    %rbx,%r13
    8453:	31 ff                	xor    %edi,%edi
    8455:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    845a:	f2 0f 10 0d f6 56 00 	movsd  0x56f6(%rip),%xmm1        # db58 <msg.8+0xd8>
    8461:	00 
    8462:	48 8d 50 08          	lea    0x8(%rax),%rdx
    8466:	31 c0                	xor    %eax,%eax
    8468:	4d 85 e4             	test   %r12,%r12
    846b:	75 29                	jne    8496 <f12+0x956>
    846d:	eb 51                	jmp    84c0 <f12+0x980>
    846f:	90                   	nop
    8470:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    8475:	0f 88 f7 0b 00 00    	js     9072 <f12+0x1532>
    847b:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    8480:	48 83 c0 01          	add    $0x1,%rax
    8484:	48 83 c2 08          	add    $0x8,%rdx
    8488:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    848c:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8491:	49 39 c4             	cmp    %rax,%r12
    8494:	74 2a                	je     84c0 <f12+0x980>
    8496:	48 8d 4b 08          	lea    0x8(%rbx),%rcx
    849a:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    849e:	79 d0                	jns    8470 <f12+0x930>
    84a0:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
    84a4:	eb ca                	jmp    8470 <f12+0x930>
    84a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    84ad:	00 00 00 
    84b0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    84b4:	0f 84 05 f9 ff ff    	je     7dbf <f12+0x27f>
    84ba:	e9 f2 f8 ff ff       	jmp    7db1 <f12+0x271>
    84bf:	90                   	nop
    84c0:	e8 6b f1 ff ff       	call   7630 <fwp_drop4>
    84c5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    84ca:	31 d2                	xor    %edx,%edx
    84cc:	48 89 c8             	mov    %rcx,%rax
    84cf:	48 85 c9             	test   %rcx,%rcx
    84d2:	0f 84 11 0a 00 00    	je     8ee9 <f12+0x13a9>
    84d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    84df:	00 
    84e0:	48 8b 40 10          	mov    0x10(%rax),%rax
    84e4:	48 83 c2 01          	add    $0x1,%rdx
    84e8:	48 85 c0             	test   %rax,%rax
    84eb:	75 f3                	jne    84e0 <f12+0x9a0>
    84ed:	49 8b 45 00          	mov    0x0(%r13),%rax
    84f1:	49 89 c7             	mov    %rax,%r15
    84f4:	49 0f ba f7 3f       	btr    $0x3f,%r15
    84f9:	48 85 c0             	test   %rax,%rax
    84fc:	0f 88 d3 05 00 00    	js     8ad5 <f12+0xf95>
    8502:	48 8b 0d 6f a6 01 00 	mov    0x1a66f(%rip),%rcx        # 22b78 <fwp_heap+0x13d8>
    8509:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    850e:	48 2b 05 3b a6 01 00 	sub    0x1a63b(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    8515:	48 c1 e1 10          	shl    $0x10,%rcx
    8519:	48 39 c8             	cmp    %rcx,%rax
    851c:	0f 83 b3 05 00 00    	jae    8ad5 <f12+0xf95>
    8522:	48 89 c1             	mov    %rax,%rcx
    8525:	48 c1 e9 10          	shr    $0x10,%rcx
    8529:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    852d:	48 8b 0d 64 a6 01 00 	mov    0x1a664(%rip),%rcx        # 22b98 <fwp_heap+0x13f8>
    8534:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    8538:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    853c:	48 85 ff             	test   %rdi,%rdi
    853f:	0f 84 90 05 00 00    	je     8ad5 <f12+0xf95>
    8545:	0f b6 0e             	movzbl (%rsi),%ecx
    8548:	80 f9 02             	cmp    $0x2,%cl
    854b:	0f 84 6f 05 00 00    	je     8ac0 <f12+0xf80>
    8551:	80 f9 01             	cmp    $0x1,%cl
    8554:	0f 85 6f 05 00 00    	jne    8ac9 <f12+0xf89>
    855a:	8b 4e 18             	mov    0x18(%rsi),%ecx
    855d:	0f b7 c0             	movzwl %ax,%eax
    8560:	48 0f af c1          	imul   %rcx,%rax
    8564:	8b 4e 1c             	mov    0x1c(%rsi),%ecx
    8567:	48 c1 e8 20          	shr    $0x20,%rax
    856b:	48 39 c8             	cmp    %rcx,%rax
    856e:	0f 83 55 05 00 00    	jae    8ac9 <f12+0xf89>
    8574:	48 01 c7             	add    %rax,%rdi
    8577:	80 3f 01             	cmpb   $0x1,(%rdi)
    857a:	0f 85 49 05 00 00    	jne    8ac9 <f12+0xf89>
    8580:	49 39 d7             	cmp    %rdx,%r15
    8583:	49 0f 46 d7          	cmovbe %r15,%rdx
    8587:	48 89 d5             	mov    %rdx,%rbp
    858a:	48 85 d2             	test   %rdx,%rdx
    858d:	0f 84 f0 0a 00 00    	je     9083 <f12+0x1543>
    8593:	c7 44 24 50 01 00 00 	movl   $0x1,0x50(%rsp)
    859a:	00 
    859b:	4d 8d 65 08          	lea    0x8(%r13),%r12
    859f:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    85a4:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    85a9:	4c 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%r8
    85b0:	00 
    85b1:	31 c0                	xor    %eax,%eax
    85b3:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    85b7:	eb 24                	jmp    85dd <f12+0xa9d>
    85b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    85c0:	f2 0f 10 42 08       	movsd  0x8(%rdx),%xmm0
    85c5:	f2 0f 5c 04 06       	subsd  (%rsi,%rax,1),%xmm0
    85ca:	f2 41 0f 11 04 04    	movsd  %xmm0,(%r12,%rax,1)
    85d0:	48 83 c0 08          	add    $0x8,%rax
    85d4:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    85d8:	49 39 c0             	cmp    %rax,%r8
    85db:	74 1b                	je     85f8 <f12+0xab8>
    85dd:	48 89 fe             	mov    %rdi,%rsi
    85e0:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    85e5:	79 d9                	jns    85c0 <f12+0xa80>
    85e7:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    85ec:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    85f0:	eb ce                	jmp    85c0 <f12+0xa80>
    85f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    85f8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    85fd:	48 85 d2             	test   %rdx,%rdx
    8600:	0f 84 47 0a 00 00    	je     904d <f12+0x150d>
    8606:	4c 8b 05 6b a5 01 00 	mov    0x1a56b(%rip),%r8        # 22b78 <fwp_heap+0x13d8>
    860d:	4c 8b 15 3c a5 01 00 	mov    0x1a53c(%rip),%r10        # 22b50 <fwp_heap+0x13b0>
    8614:	45 31 ff             	xor    %r15d,%r15d
    8617:	4c 8b 1d 7a a5 01 00 	mov    0x1a57a(%rip),%r11        # 22b98 <fwp_heap+0x13f8>
    861e:	49 c1 e0 10          	shl    $0x10,%r8
    8622:	eb 1a                	jmp    863e <f12+0xafe>
    8624:	0f 1f 40 00          	nopl   0x0(%rax)
    8628:	49 83 c7 01          	add    $0x1,%r15
    862c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8630:	49 39 ef             	cmp    %rbp,%r15
    8633:	0f 83 37 02 00 00    	jae    8870 <f12+0xd30>
    8639:	48 85 d2             	test   %rdx,%rdx
    863c:	74 52                	je     8690 <f12+0xb50>
    863e:	48 89 d0             	mov    %rdx,%rax
    8641:	4c 29 d0             	sub    %r10,%rax
    8644:	4c 39 c0             	cmp    %r8,%rax
    8647:	73 47                	jae    8690 <f12+0xb50>
    8649:	48 89 c6             	mov    %rax,%rsi
    864c:	48 c1 ee 10          	shr    $0x10,%rsi
    8650:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    8654:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    8658:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    865c:	48 85 ff             	test   %rdi,%rdi
    865f:	74 2f                	je     8690 <f12+0xb50>
    8661:	0f b6 1e             	movzbl (%rsi),%ebx
    8664:	80 fb 02             	cmp    $0x2,%bl
    8667:	0f 84 e3 01 00 00    	je     8850 <f12+0xd10>
    866d:	80 fb 01             	cmp    $0x1,%bl
    8670:	75 1e                	jne    8690 <f12+0xb50>
    8672:	8b 5e 18             	mov    0x18(%rsi),%ebx
    8675:	0f b7 c0             	movzwl %ax,%eax
    8678:	8b 76 1c             	mov    0x1c(%rsi),%esi
    867b:	48 0f af c3          	imul   %rbx,%rax
    867f:	48 c1 e8 20          	shr    $0x20,%rax
    8683:	48 39 f0             	cmp    %rsi,%rax
    8686:	73 08                	jae    8690 <f12+0xb50>
    8688:	48 01 c7             	add    %rax,%rdi
    868b:	80 3f 01             	cmpb   $0x1,(%rdi)
    868e:	74 98                	je     8628 <f12+0xae8>
    8690:	49 39 ef             	cmp    %rbp,%r15
    8693:	0f 83 d7 01 00 00    	jae    8870 <f12+0xd30>
    8699:	4c 8b 2d 50 54 00 00 	mov    0x5450(%rip),%r13        # daf0 <msg.8+0x70>
    86a0:	45 31 f6             	xor    %r14d,%r14d
    86a3:	48 8d 1d f6 90 01 00 	lea    0x190f6(%rip),%rbx        # 217a0 <fwp_heap>
    86aa:	e9 19 01 00 00       	jmp    87c8 <f12+0xc88>
    86af:	90                   	nop
    86b0:	49 8b 10             	mov    (%r8),%rdx
    86b3:	48 f7 d2             	not    %rdx
    86b6:	48 89 10             	mov    %rdx,(%rax)
    86b9:	49 83 fb 18          	cmp    $0x18,%r11
    86bd:	76 3b                	jbe    86fa <f12+0xbba>
    86bf:	49 8d 43 e7          	lea    -0x19(%r11),%rax
    86c3:	49 8d 78 18          	lea    0x18(%r8),%rdi
    86c7:	31 f6                	xor    %esi,%esi
    86c9:	4c 89 5c 24 20       	mov    %r11,0x20(%rsp)
    86ce:	48 c1 e8 03          	shr    $0x3,%rax
    86d2:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    86d7:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    86de:	00 
    86df:	66 0f d6 44 24 30    	movq   %xmm0,0x30(%rsp)
    86e5:	e8 d6 ad ff ff       	call   34c0 <memset@plt>
    86ea:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    86ef:	4c 8b 5c 24 20       	mov    0x20(%rsp),%r11
    86f4:	f3 0f 7e 44 24 30    	movq   0x30(%rsp),%xmm0
    86fa:	4c 89 d8             	mov    %r11,%rax
    86fd:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    8704:	0f 82 63 09 00 00    	jb     906d <f12+0x152d>
    870a:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    8711:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    8718:	73 07                	jae    8721 <f12+0xbe1>
    871a:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    8721:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8725:	f2 49 0f 2a cb       	cvtsi2sd %r11,%xmm1
    872a:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    8731:	00 
    8732:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    8739:	00 
    873a:	66 49 0f 6e f6       	movq   %r14,%xmm6
    873f:	4d 89 28             	mov    %r13,(%r8)
    8742:	4c 89 c0             	mov    %r8,%rax
    8745:	4d 89 c6             	mov    %r8,%r14
    8748:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    874c:	41 0f 11 40 08       	movups %xmm0,0x8(%r8)
    8751:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    8758:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    875f:	48 c1 e2 10          	shl    $0x10,%rdx
    8763:	48 39 d0             	cmp    %rdx,%rax
    8766:	73 57                	jae    87bf <f12+0xc7f>
    8768:	48 89 c2             	mov    %rax,%rdx
    876b:	48 c1 ea 10          	shr    $0x10,%rdx
    876f:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8773:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    877a:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    877e:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    8782:	48 85 d2             	test   %rdx,%rdx
    8785:	74 38                	je     87bf <f12+0xc7f>
    8787:	0f b6 3e             	movzbl (%rsi),%edi
    878a:	40 80 ff 02          	cmp    $0x2,%dil
    878e:	0f 84 7c 01 00 00    	je     8910 <f12+0xdd0>
    8794:	40 80 ff 01          	cmp    $0x1,%dil
    8798:	75 25                	jne    87bf <f12+0xc7f>
    879a:	8b 7e 18             	mov    0x18(%rsi),%edi
    879d:	0f b7 c0             	movzwl %ax,%eax
    87a0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    87a3:	48 0f af c7          	imul   %rdi,%rax
    87a7:	48 c1 e8 20          	shr    $0x20,%rax
    87ab:	48 39 f0             	cmp    %rsi,%rax
    87ae:	73 0f                	jae    87bf <f12+0xc7f>
    87b0:	48 01 c2             	add    %rax,%rdx
    87b3:	80 3a ff             	cmpb   $0xff,(%rdx)
    87b6:	0f 84 f4 04 00 00    	je     8cb0 <f12+0x1170>
    87bc:	c6 02 01             	movb   $0x1,(%rdx)
    87bf:	49 39 ef             	cmp    %rbp,%r15
    87c2:	0f 83 68 01 00 00    	jae    8930 <f12+0xdf0>
    87c8:	8b b3 a4 13 00 00    	mov    0x13a4(%rbx),%esi
    87ce:	48 83 ed 01          	sub    $0x1,%rbp
    87d2:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    87d8:	85 f6                	test   %esi,%esi
    87da:	74 4c                	je     8828 <f12+0xce8>
    87dc:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    87e3:	44 8b 9c 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r11d
    87ea:	00 
    87eb:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    87ef:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    87f3:	4c 8b 00             	mov    (%rax),%r8
    87f6:	4d 85 c0             	test   %r8,%r8
    87f9:	0f 85 b1 fe ff ff    	jne    86b0 <f12+0xb70>
    87ff:	4c 8b 40 08          	mov    0x8(%rax),%r8
    8803:	4d 85 c0             	test   %r8,%r8
    8806:	74 20                	je     8828 <f12+0xce8>
    8808:	48 8b 50 10          	mov    0x10(%rax),%rdx
    880c:	4c 29 c2             	sub    %r8,%rdx
    880f:	4c 39 da             	cmp    %r11,%rdx
    8812:	72 14                	jb     8828 <f12+0xce8>
    8814:	4b 8d 14 18          	lea    (%r8,%r11,1),%rdx
    8818:	48 89 50 08          	mov    %rdx,0x8(%rax)
    881c:	e9 98 fe ff ff       	jmp    86b9 <f12+0xb79>
    8821:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8828:	31 f6                	xor    %esi,%esi
    882a:	bf 18 00 00 00       	mov    $0x18,%edi
    882f:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    8835:	e8 76 d2 ff ff       	call   5ab0 <fwp_heap_alloc>
    883a:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    8840:	49 89 c0             	mov    %rax,%r8
    8843:	e9 f2 fe ff ff       	jmp    873a <f12+0xbfa>
    8848:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    884f:	00 
    8850:	66 85 c0             	test   %ax,%ax
    8853:	0f 84 32 fe ff ff    	je     868b <f12+0xb4b>
    8859:	49 39 ef             	cmp    %rbp,%r15
    885c:	0f 82 37 fe ff ff    	jb     8699 <f12+0xb59>
    8862:	0f 1f 00             	nopl   (%rax)
    8865:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    886c:	00 00 00 00 
    8870:	45 31 f6             	xor    %r14d,%r14d
    8873:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8878:	4c 89 e2             	mov    %r12,%rdx
    887b:	4b 8d 3c fc          	lea    (%r12,%r15,8),%rdi
    887f:	90                   	nop
    8880:	48 8b 0a             	mov    (%rdx),%rcx
    8883:	48 83 c2 08          	add    $0x8,%rdx
    8887:	48 89 c6             	mov    %rax,%rsi
    888a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    888e:	48 8b 40 10          	mov    0x10(%rax),%rax
    8892:	48 39 d7             	cmp    %rdx,%rdi
    8895:	75 e9                	jne    8880 <f12+0xd40>
    8897:	8b 4c 24 50          	mov    0x50(%rsp),%ecx
    889b:	4c 89 76 10          	mov    %r14,0x10(%rsi)
    889f:	85 c9                	test   %ecx,%ecx
    88a1:	0f 84 09 05 00 00    	je     8db0 <f12+0x1270>
    88a7:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    88ac:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    88b1:	45 31 e4             	xor    %r12d,%r12d
    88b4:	90                   	nop
    88b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    88bc:	00 00 00 00 
    88c0:	4c 89 e7             	mov    %r12,%rdi
    88c3:	e8 e8 cc ff ff       	call   55b0 <fwp_mem_free>
    88c8:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    88cd:	e8 5e ed ff ff       	call   7630 <fwp_drop4>
    88d2:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    88d7:	e8 94 dd ff ff       	call   6670 <fwp_drop0>
    88dc:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
    88e3:	00 
    88e4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    88eb:	00 00 
    88ed:	0f 85 22 08 00 00    	jne    9115 <f12+0x15d5>
    88f3:	48 81 c4 f8 00 00 00 	add    $0xf8,%rsp
    88fa:	4c 89 f0             	mov    %r14,%rax
    88fd:	5b                   	pop    %rbx
    88fe:	5d                   	pop    %rbp
    88ff:	41 5c                	pop    %r12
    8901:	41 5d                	pop    %r13
    8903:	41 5e                	pop    %r14
    8905:	41 5f                	pop    %r15
    8907:	c3                   	ret
    8908:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    890f:	00 
    8910:	66 85 c0             	test   %ax,%ax
    8913:	0f 84 9a fe ff ff    	je     87b3 <f12+0xc73>
    8919:	49 39 ef             	cmp    %rbp,%r15
    891c:	0f 82 a6 fe ff ff    	jb     87c8 <f12+0xc88>
    8922:	0f 1f 00             	nopl   (%rax)
    8925:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    892c:	00 00 00 00 
    8930:	4d 85 ff             	test   %r15,%r15
    8933:	0f 85 3a ff ff ff    	jne    8873 <f12+0xd33>
    8939:	8b 54 24 50          	mov    0x50(%rsp),%edx
    893d:	85 d2                	test   %edx,%edx
    893f:	4d 0f 45 e7          	cmovne %r15,%r12
    8943:	66 90                	xchg   %ax,%ax
    8945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    894c:	00 00 00 00 
    8950:	48 85 ed             	test   %rbp,%rbp
    8953:	0f 84 67 ff ff ff    	je     88c0 <f12+0xd80>
    8959:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    895f:	48 83 ed 01          	sub    $0x1,%rbp
    8963:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    8969:	85 c0                	test   %eax,%eax
    896b:	0f 84 87 06 00 00    	je     8ff8 <f12+0x14b8>
    8971:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    8978:	44 8b 84 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r8d
    897f:	00 
    8980:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    8984:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    8988:	4c 8b 38             	mov    (%rax),%r15
    898b:	4d 85 ff             	test   %r15,%r15
    898e:	0f 84 3c 06 00 00    	je     8fd0 <f12+0x1490>
    8994:	49 8b 17             	mov    (%r15),%rdx
    8997:	48 f7 d2             	not    %rdx
    899a:	48 89 10             	mov    %rdx,(%rax)
    899d:	49 83 f8 18          	cmp    $0x18,%r8
    89a1:	76 31                	jbe    89d4 <f12+0xe94>
    89a3:	49 8d 40 e7          	lea    -0x19(%r8),%rax
    89a7:	49 8d 7f 18          	lea    0x18(%r15),%rdi
    89ab:	31 f6                	xor    %esi,%esi
    89ad:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    89b2:	48 c1 e8 03          	shr    $0x3,%rax
    89b6:	66 0f d6 44 24 20    	movq   %xmm0,0x20(%rsp)
    89bc:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    89c3:	00 
    89c4:	e8 f7 aa ff ff       	call   34c0 <memset@plt>
    89c9:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    89ce:	f3 0f 7e 44 24 20    	movq   0x20(%rsp),%xmm0
    89d4:	4c 89 c0             	mov    %r8,%rax
    89d7:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    89de:	0f 82 89 06 00 00    	jb     906d <f12+0x152d>
    89e4:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    89eb:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    89f2:	73 07                	jae    89fb <f12+0xebb>
    89f4:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    89fb:	66 0f ef c9          	pxor   %xmm1,%xmm1
    89ff:	f2 49 0f 2a c8       	cvtsi2sd %r8,%xmm1
    8a04:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    8a0b:	00 
    8a0c:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    8a13:	00 
    8a14:	66 49 0f 6e fe       	movq   %r14,%xmm7
    8a19:	4d 89 2f             	mov    %r13,(%r15)
    8a1c:	4c 89 f8             	mov    %r15,%rax
    8a1f:	4d 89 fe             	mov    %r15,%r14
    8a22:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    8a26:	41 0f 11 47 08       	movups %xmm0,0x8(%r15)
    8a2b:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    8a32:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    8a39:	48 c1 e2 10          	shl    $0x10,%rdx
    8a3d:	48 39 d0             	cmp    %rdx,%rax
    8a40:	0f 83 0a ff ff ff    	jae    8950 <f12+0xe10>
    8a46:	48 89 c2             	mov    %rax,%rdx
    8a49:	48 c1 ea 10          	shr    $0x10,%rdx
    8a4d:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8a51:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    8a58:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    8a5c:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    8a60:	4d 85 ff             	test   %r15,%r15
    8a63:	0f 84 e7 fe ff ff    	je     8950 <f12+0xe10>
    8a69:	0f b6 32             	movzbl (%rdx),%esi
    8a6c:	40 80 fe 02          	cmp    $0x2,%sil
    8a70:	0f 84 aa 05 00 00    	je     9020 <f12+0x14e0>
    8a76:	40 80 fe 01          	cmp    $0x1,%sil
    8a7a:	0f 85 d0 fe ff ff    	jne    8950 <f12+0xe10>
    8a80:	8b 72 18             	mov    0x18(%rdx),%esi
    8a83:	0f b7 c0             	movzwl %ax,%eax
    8a86:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8a89:	48 0f af c6          	imul   %rsi,%rax
    8a8d:	48 c1 e8 20          	shr    $0x20,%rax
    8a91:	48 39 d0             	cmp    %rdx,%rax
    8a94:	0f 83 b6 fe ff ff    	jae    8950 <f12+0xe10>
    8a9a:	49 01 c7             	add    %rax,%r15
    8a9d:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8aa1:	0f 84 99 05 00 00    	je     9040 <f12+0x1500>
    8aa7:	41 c6 07 01          	movb   $0x1,(%r15)
    8aab:	48 85 ed             	test   %rbp,%rbp
    8aae:	0f 85 a5 fe ff ff    	jne    8959 <f12+0xe19>
    8ab4:	e9 07 fe ff ff       	jmp    88c0 <f12+0xd80>
    8ab9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ac0:	66 85 c0             	test   %ax,%ax
    8ac3:	0f 84 ae fa ff ff    	je     8577 <f12+0xa37>
    8ac9:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    8acf:	0f 84 aa 03 00 00    	je     8e7f <f12+0x133f>
    8ad5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8ada:	31 ed                	xor    %ebp,%ebp
    8adc:	0f 1f 40 00          	nopl   0x0(%rax)
    8ae0:	48 8b 40 10          	mov    0x10(%rax),%rax
    8ae4:	48 89 ea             	mov    %rbp,%rdx
    8ae7:	48 83 c5 01          	add    $0x1,%rbp
    8aeb:	48 85 c0             	test   %rax,%rax
    8aee:	75 f0                	jne    8ae0 <f12+0xfa0>
    8af0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8af7:	ff ff 1f 
    8afa:	48 39 e8             	cmp    %rbp,%rax
    8afd:	0f 82 94 05 00 00    	jb     9097 <f12+0x1557>
    8b03:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    8b0a:	00 
    8b0b:	be 02 00 00 00       	mov    $0x2,%esi
    8b10:	e8 9b cf ff ff       	call   5ab0 <fwp_heap_alloc>
    8b15:	49 39 ef             	cmp    %rbp,%r15
    8b18:	49 89 c4             	mov    %rax,%r12
    8b1b:	48 89 c2             	mov    %rax,%rdx
    8b1e:	49 0f 46 ef          	cmovbe %r15,%rbp
    8b22:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8b27:	0f 1f 00             	nopl   (%rax)
    8b2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8b31:	00 00 00 00 
    8b35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8b3c:	00 00 00 00 
    8b40:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8b44:	48 83 c2 08          	add    $0x8,%rdx
    8b48:	48 89 72 f8          	mov    %rsi,-0x8(%rdx)
    8b4c:	48 8b 40 10          	mov    0x10(%rax),%rax
    8b50:	48 85 c0             	test   %rax,%rax
    8b53:	75 eb                	jne    8b40 <f12+0x1000>
    8b55:	48 85 ed             	test   %rbp,%rbp
    8b58:	0f 84 33 03 00 00    	je     8e91 <f12+0x1351>
    8b5e:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
    8b65:	00 
    8b66:	e9 34 fa ff ff       	jmp    859f <f12+0xa5f>
    8b6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8b70:	66 85 c0             	test   %ax,%ax
    8b73:	0f 84 c9 f8 ff ff    	je     8442 <f12+0x902>
    8b79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8b80:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8b87:	ff ff 1f 
    8b8a:	4c 39 e0             	cmp    %r12,%rax
    8b8d:	0f 82 10 05 00 00    	jb     90a3 <f12+0x1563>
    8b93:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    8b9a:	00 
    8b9b:	be 01 00 00 00       	mov    $0x1,%esi
    8ba0:	e8 0b cf ff ff       	call   5ab0 <fwp_heap_alloc>
    8ba5:	4c 89 20             	mov    %r12,(%rax)
    8ba8:	48 8b 15 c9 9f 01 00 	mov    0x19fc9(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    8baf:	49 89 c5             	mov    %rax,%r13
    8bb2:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    8bb7:	48 2b 05 92 9f 01 00 	sub    0x19f92(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    8bbe:	48 c1 e2 10          	shl    $0x10,%rdx
    8bc2:	48 39 d0             	cmp    %rdx,%rax
    8bc5:	73 57                	jae    8c1e <f12+0x10de>
    8bc7:	48 89 c2             	mov    %rax,%rdx
    8bca:	48 c1 ea 10          	shr    $0x10,%rdx
    8bce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8bd2:	48 8b 15 bf 9f 01 00 	mov    0x19fbf(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    8bd9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8bdd:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    8be1:	4d 85 ff             	test   %r15,%r15
    8be4:	74 38                	je     8c1e <f12+0x10de>
    8be6:	0f b6 0a             	movzbl (%rdx),%ecx
    8be9:	80 f9 02             	cmp    $0x2,%cl
    8bec:	0f 84 ae 02 00 00    	je     8ea0 <f12+0x1360>
    8bf2:	80 f9 01             	cmp    $0x1,%cl
    8bf5:	75 27                	jne    8c1e <f12+0x10de>
    8bf7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8bfa:	0f b7 c0             	movzwl %ax,%eax
    8bfd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8c00:	48 0f af c1          	imul   %rcx,%rax
    8c04:	48 c1 e8 20          	shr    $0x20,%rax
    8c08:	48 39 d0             	cmp    %rdx,%rax
    8c0b:	73 11                	jae    8c1e <f12+0x10de>
    8c0d:	49 01 c7             	add    %rax,%r15
    8c10:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8c14:	0f 84 9b 03 00 00    	je     8fb5 <f12+0x1475>
    8c1a:	41 c6 07 01          	movb   $0x1,(%r15)
    8c1e:	48 89 df             	mov    %rbx,%rdi
    8c21:	e9 2f f8 ff ff       	jmp    8455 <f12+0x915>
    8c26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8c2d:	00 00 00 
    8c30:	48 c1 e6 10          	shl    $0x10,%rsi
    8c34:	48 09 fe             	or     %rdi,%rsi
    8c37:	bf 08 00 00 00       	mov    $0x8,%edi
    8c3c:	49 89 f4             	mov    %rsi,%r12
    8c3f:	be 02 00 00 00       	mov    $0x2,%esi
    8c44:	e8 67 ce ff ff       	call   5ab0 <fwp_heap_alloc>
    8c49:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8c50:	48 8b 15 21 9f 01 00 	mov    0x19f21(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    8c57:	48 89 c3             	mov    %rax,%rbx
    8c5a:	48 2b 05 ef 9e 01 00 	sub    0x19eef(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    8c61:	48 c1 e2 10          	shl    $0x10,%rdx
    8c65:	48 39 d0             	cmp    %rdx,%rax
    8c68:	73 76                	jae    8ce0 <f12+0x11a0>
    8c6a:	48 89 c2             	mov    %rax,%rdx
    8c6d:	48 c1 ea 10          	shr    $0x10,%rdx
    8c71:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8c75:	48 8b 15 1c 9f 01 00 	mov    0x19f1c(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    8c7c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8c80:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8c84:	48 85 d2             	test   %rdx,%rdx
    8c87:	0f 84 26 f3 ff ff    	je     7fb3 <f12+0x473>
    8c8d:	0f b6 31             	movzbl (%rcx),%esi
    8c90:	45 31 ed             	xor    %r13d,%r13d
    8c93:	40 80 fe 02          	cmp    $0x2,%sil
    8c97:	0f 85 8e f2 ff ff    	jne    7f2b <f12+0x3eb>
    8c9d:	66 85 c0             	test   %ax,%ax
    8ca0:	0f 85 b0 f2 ff ff    	jne    7f56 <f12+0x416>
    8ca6:	e9 9f f2 ff ff       	jmp    7f4a <f12+0x40a>
    8cab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8cb0:	48 89 d7             	mov    %rdx,%rdi
    8cb3:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    8cb8:	e8 b3 c6 ff ff       	call   5370 <fwp_rc_forget_slot>
    8cbd:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8cc2:	e9 f5 fa ff ff       	jmp    87bc <f12+0xc7c>
    8cc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8cce:	00 00 
    8cd0:	4d 85 ed             	test   %r13,%r13
    8cd3:	0f 85 82 f2 ff ff    	jne    7f5b <f12+0x41b>
    8cd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ce0:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
    8ce7:	00 00 
    8ce9:	e9 2f f3 ff ff       	jmp    801d <f12+0x4dd>
    8cee:	66 90                	xchg   %ax,%ax
    8cf0:	4d 8d 51 01          	lea    0x1(%r9),%r10
    8cf4:	4c 39 d2             	cmp    %r10,%rdx
    8cf7:	0f 8c 78 f4 ff ff    	jl     8175 <f12+0x635>
    8cfd:	48 85 c9             	test   %rcx,%rcx
    8d00:	0f 84 b2 03 00 00    	je     90b8 <f12+0x1578>
    8d06:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
    8d0b:	4a 8d 14 d5 00 00 00 	lea    0x0(,%r10,8),%rdx
    8d12:	00 
    8d13:	31 f6                	xor    %esi,%esi
    8d15:	48 89 cf             	mov    %rcx,%rdi
    8d18:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8d1d:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8d22:	e9 3a 01 00 00       	jmp    8e61 <f12+0x1321>
    8d27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8d2e:	00 00 
    8d30:	48 8d 3d 69 de ff ff 	lea    -0x2197(%rip),%rdi        # 6ba0 <fwp_tape_finish>
    8d37:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    8d3d:	e8 9e 37 00 00       	call   c4e0 <atexit>
    8d42:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    8d48:	85 c0                	test   %eax,%eax
    8d4a:	0f 85 7f 03 00 00    	jne    90cf <f12+0x158f>
    8d50:	c7 05 26 83 00 00 01 	movl   $0x1,0x8326(%rip)        # 11080 <registered_finish.0>
    8d57:	00 00 00 
    8d5a:	e9 10 ef ff ff       	jmp    7c6f <f12+0x12f>
    8d5f:	90                   	nop
    8d60:	66 85 c0             	test   %ax,%ax
    8d63:	0f 85 b4 ee ff ff    	jne    7c1d <f12+0xdd>
    8d69:	e9 9b ee ff ff       	jmp    7c09 <f12+0xc9>
    8d6e:	66 90                	xchg   %ax,%ax
    8d70:	48 39 d5             	cmp    %rdx,%rbp
    8d73:	0f 8f f9 f3 ff ff    	jg     8172 <f12+0x632>
    8d79:	48 85 c9             	test   %rcx,%rcx
    8d7c:	0f 85 f3 01 00 00    	jne    8f75 <f12+0x1435>
    8d82:	48 85 ed             	test   %rbp,%rbp
    8d85:	0f 85 2d 03 00 00    	jne    90b8 <f12+0x1578>
    8d8b:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    8d92:	e9 8c f4 ff ff       	jmp    8223 <f12+0x6e3>
    8d97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8d9e:	00 00 
    8da0:	66 85 c0             	test   %ax,%ax
    8da3:	0f 85 f3 f5 ff ff    	jne    839c <f12+0x85c>
    8da9:	e9 de f5 ff ff       	jmp    838c <f12+0x84c>
    8dae:	66 90                	xchg   %ax,%ax
    8db0:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8db5:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8dba:	e9 01 fb ff ff       	jmp    88c0 <f12+0xd80>
    8dbf:	90                   	nop
    8dc0:	66 0f 6f 0d 18 83 01 	movdqa 0x18318(%rip),%xmm1        # 210e0 <fwp_tape_workspace>
    8dc7:	00 
    8dc8:	48 c7 05 f5 82 01 00 	movq   $0x0,0x182f5(%rip)        # 210c8 <fwp_tape_cached_bytes>
    8dcf:	00 00 00 00 
    8dd3:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    8dd9:	48 8b 05 20 83 01 00 	mov    0x18320(%rip),%rax        # 21100 <fwp_tape_workspace+0x20>
    8de0:	66 0f 6f 0d 08 83 01 	movdqa 0x18308(%rip),%xmm1        # 210f0 <fwp_tape_workspace+0x10>
    8de7:	00 
    8de8:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    8ded:	48 8b 05 14 83 01 00 	mov    0x18314(%rip),%rax        # 21108 <fwp_tape_workspace+0x28>
    8df4:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    8dfa:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8dfe:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    8e03:	48 8b 05 06 83 01 00 	mov    0x18306(%rip),%rax        # 21110 <fwp_tape_workspace+0x30>
    8e0a:	0f 29 0d cf 82 01 00 	movaps %xmm1,0x182cf(%rip)        # 210e0 <fwp_tape_workspace>
    8e11:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    8e16:	0f 29 0d d3 82 01 00 	movaps %xmm1,0x182d3(%rip)        # 210f0 <fwp_tape_workspace+0x10>
    8e1d:	48 c7 05 e8 82 01 00 	movq   $0x0,0x182e8(%rip)        # 21110 <fwp_tape_workspace+0x30>
    8e24:	00 00 00 00 
    8e28:	0f 29 0d d1 82 01 00 	movaps %xmm1,0x182d1(%rip)        # 21100 <fwp_tape_workspace+0x20>
    8e2f:	e9 8b ef ff ff       	jmp    7dbf <f12+0x27f>
    8e34:	0f 1f 40 00          	nopl   0x0(%rax)
    8e38:	48 85 c9             	test   %rcx,%rcx
    8e3b:	0f 84 77 02 00 00    	je     90b8 <f12+0x1578>
    8e41:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
    8e46:	48 8d 5d ff          	lea    -0x1(%rbp),%rbx
    8e4a:	31 f6                	xor    %esi,%esi
    8e4c:	48 89 cf             	mov    %rcx,%rdi
    8e4f:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8e54:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    8e5b:	00 
    8e5c:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8e61:	e8 5a a6 ff ff       	call   34c0 <memset@plt>
    8e66:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8e6c:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    8e72:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
    8e77:	48 89 c1             	mov    %rax,%rcx
    8e7a:	e9 92 f3 ff ff       	jmp    8211 <f12+0x6d1>
    8e7f:	be 02 00 00 00       	mov    $0x2,%esi
    8e84:	bf 08 00 00 00       	mov    $0x8,%edi
    8e89:	e8 22 cc ff ff       	call   5ab0 <fwp_heap_alloc>
    8e8e:	49 89 c4             	mov    %rax,%r12
    8e91:	45 31 f6             	xor    %r14d,%r14d
    8e94:	e9 27 fa ff ff       	jmp    88c0 <f12+0xd80>
    8e99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ea0:	66 85 c0             	test   %ax,%ax
    8ea3:	0f 85 75 fd ff ff    	jne    8c1e <f12+0x10de>
    8ea9:	e9 62 fd ff ff       	jmp    8c10 <f12+0x10d0>
    8eae:	66 90                	xchg   %ax,%ax
    8eb0:	48 89 d7             	mov    %rdx,%rdi
    8eb3:	be 08 00 00 00       	mov    $0x8,%esi
    8eb8:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    8ebd:	e8 5e a6 ff ff       	call   3520 <calloc@plt>
    8ec2:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    8ec8:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
    8ece:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
    8ed3:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    8ed8:	48 89 c1             	mov    %rax,%rcx
    8edb:	e9 00 f3 ff ff       	jmp    81e0 <f12+0x6a0>
    8ee0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8ee4:	e9 76 ed ff ff       	jmp    7c5f <f12+0x11f>
    8ee9:	49 8b 4d 00          	mov    0x0(%r13),%rcx
    8eed:	48 85 c9             	test   %rcx,%rcx
    8ef0:	78 8d                	js     8e7f <f12+0x133f>
    8ef2:	48 8b 35 7f 9c 01 00 	mov    0x19c7f(%rip),%rsi        # 22b78 <fwp_heap+0x13d8>
    8ef9:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    8efe:	48 2b 05 4b 9c 01 00 	sub    0x19c4b(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    8f05:	48 c1 e6 10          	shl    $0x10,%rsi
    8f09:	48 39 f0             	cmp    %rsi,%rax
    8f0c:	0f 83 6d ff ff ff    	jae    8e7f <f12+0x133f>
    8f12:	48 89 c6             	mov    %rax,%rsi
    8f15:	48 c1 ee 10          	shr    $0x10,%rsi
    8f19:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    8f1d:	48 8b 35 74 9c 01 00 	mov    0x19c74(%rip),%rsi        # 22b98 <fwp_heap+0x13f8>
    8f24:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    8f28:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8f2c:	48 85 ff             	test   %rdi,%rdi
    8f2f:	0f 84 4a ff ff ff    	je     8e7f <f12+0x133f>
    8f35:	48 0f ba f1 3f       	btr    $0x3f,%rcx
    8f3a:	49 89 cf             	mov    %rcx,%r15
    8f3d:	e9 03 f6 ff ff       	jmp    8545 <f12+0xa05>
    8f42:	be 68 00 00 00       	mov    $0x68,%esi
    8f47:	bb 01 00 00 00       	mov    $0x1,%ebx
    8f4c:	e9 a9 ed ff ff       	jmp    7cfa <f12+0x1ba>
    8f51:	48 89 d7             	mov    %rdx,%rdi
    8f54:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    8f59:	e8 12 c4 ff ff       	call   5370 <fwp_rc_forget_slot>
    8f5e:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8f63:	e9 eb ef ff ff       	jmp    7f53 <f12+0x413>
    8f68:	4c 89 e7             	mov    %r12,%rdi
    8f6b:	e8 00 c4 ff ff       	call   5370 <fwp_rc_forget_slot>
    8f70:	e9 22 f4 ff ff       	jmp    8397 <f12+0x857>
    8f75:	48 85 ed             	test   %rbp,%rbp
    8f78:	0f 84 0d fe ff ff    	je     8d8b <f12+0x124b>
    8f7e:	49 89 ea             	mov    %rbp,%r10
    8f81:	48 89 cf             	mov    %rcx,%rdi
    8f84:	31 f6                	xor    %esi,%esi
    8f86:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8f8b:	49 8d 5a ff          	lea    -0x1(%r10),%rbx
    8f8f:	4a 8d 14 d5 00 00 00 	lea    0x0(,%r10,8),%rdx
    8f96:	00 
    8f97:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8f9c:	e8 1f a5 ff ff       	call   34c0 <memset@plt>
    8fa1:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8fa7:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    8fad:	48 89 c1             	mov    %rax,%rcx
    8fb0:	e9 54 f2 ff ff       	jmp    8209 <f12+0x6c9>
    8fb5:	4c 89 ff             	mov    %r15,%rdi
    8fb8:	e8 b3 c3 ff ff       	call   5370 <fwp_rc_forget_slot>
    8fbd:	e9 58 fc ff ff       	jmp    8c1a <f12+0x10da>
    8fc2:	e8 89 c2 ff ff       	call   5250 <fwp_rc_wide_dup>
    8fc7:	e9 51 ec ff ff       	jmp    7c1d <f12+0xdd>
    8fcc:	0f 1f 40 00          	nopl   0x0(%rax)
    8fd0:	4c 8b 78 08          	mov    0x8(%rax),%r15
    8fd4:	4d 85 ff             	test   %r15,%r15
    8fd7:	74 1f                	je     8ff8 <f12+0x14b8>
    8fd9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    8fdd:	4c 29 fa             	sub    %r15,%rdx
    8fe0:	4c 39 c2             	cmp    %r8,%rdx
    8fe3:	72 13                	jb     8ff8 <f12+0x14b8>
    8fe5:	4b 8d 14 07          	lea    (%r15,%r8,1),%rdx
    8fe9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    8fed:	e9 ab f9 ff ff       	jmp    899d <f12+0xe5d>
    8ff2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ff8:	31 f6                	xor    %esi,%esi
    8ffa:	bf 18 00 00 00       	mov    $0x18,%edi
    8fff:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    9005:	e8 a6 ca ff ff       	call   5ab0 <fwp_heap_alloc>
    900a:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    9010:	49 89 c7             	mov    %rax,%r15
    9013:	e9 fc f9 ff ff       	jmp    8a14 <f12+0xed4>
    9018:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    901f:	00 
    9020:	66 85 c0             	test   %ax,%ax
    9023:	0f 85 27 f9 ff ff    	jne    8950 <f12+0xe10>
    9029:	41 80 3f ff          	cmpb   $0xff,(%r15)
    902d:	0f 85 74 fa ff ff    	jne    8aa7 <f12+0xf67>
    9033:	66 90                	xchg   %ax,%ax
    9035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    903c:	00 00 00 00 
    9040:	4c 89 ff             	mov    %r15,%rdi
    9043:	e8 28 c3 ff ff       	call   5370 <fwp_rc_forget_slot>
    9048:	e9 5a fa ff ff       	jmp    8aa7 <f12+0xf67>
    904d:	45 31 ff             	xor    %r15d,%r15d
    9050:	e9 44 f6 ff ff       	jmp    8699 <f12+0xb59>
    9055:	48 8d 3d a8 40 00 00 	lea    0x40a8(%rip),%rdi        # d104 <_IO_stdin_used+0x104>
    905c:	e8 3f b1 ff ff       	call   41a0 <fwp_trap>
    9061:	48 8d 3d 58 47 00 00 	lea    0x4758(%rip),%rdi        # d7c0 <_IO_stdin_used+0x7c0>
    9068:	e8 33 b1 ff ff       	call   41a0 <fwp_trap>
    906d:	e8 3e ac ff ff       	call   3cb0 <fwp_heap_oom>
    9072:	48 8d 3d 4f 48 00 00 	lea    0x484f(%rip),%rdi        # d8c8 <_IO_stdin_used+0x8c8>
    9079:	e8 22 b1 ff ff       	call   41a0 <fwp_trap>
    907e:	e8 7d a6 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9083:	45 31 e4             	xor    %r12d,%r12d
    9086:	e9 06 fe ff ff       	jmp    8e91 <f12+0x1351>
    908b:	48 8d 3d 9b 40 00 00 	lea    0x409b(%rip),%rdi        # d12d <_IO_stdin_used+0x12d>
    9092:	e8 09 b1 ff ff       	call   41a0 <fwp_trap>
    9097:	48 8d 3d a9 40 00 00 	lea    0x40a9(%rip),%rdi        # d147 <_IO_stdin_used+0x147>
    909e:	e8 fd b0 ff ff       	call   41a0 <fwp_trap>
    90a3:	48 8d 3d ab 40 00 00 	lea    0x40ab(%rip),%rdi        # d155 <_IO_stdin_used+0x155>
    90aa:	e8 f1 b0 ff ff       	call   41a0 <fwp_trap>
    90af:	4d 85 d2             	test   %r10,%r10
    90b2:	0f 84 4a f1 ff ff    	je     8202 <f12+0x6c2>
    90b8:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
    90bf:	00 
    90c0:	4c 89 e7             	mov    %r12,%rdi
    90c3:	48 89 05 6e a3 01 00 	mov    %rax,0x1a36e(%rip)        # 23438 <fwp_cleanups>
    90ca:	e8 c1 bd ff ff       	call   4e90 <fwp_tape_buffers_release>
    90cf:	48 8b 0d 8a 7f 00 00 	mov    0x7f8a(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    90d6:	ba 13 00 00 00       	mov    $0x13,%edx
    90db:	be 01 00 00 00       	mov    $0x1,%esi
    90e0:	48 8d 3d 21 3f 00 00 	lea    0x3f21(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    90e7:	e8 94 a5 ff ff       	call   3680 <fwrite@plt>
    90ec:	31 ff                	xor    %edi,%edi
    90ee:	e8 cd a4 ff ff       	call   35c0 <fflush@plt>
    90f3:	bf 66 00 00 00       	mov    $0x66,%edi
    90f8:	e8 a3 a5 ff ff       	call   36a0 <_Exit@plt>
    90fd:	48 8d 3d 94 47 00 00 	lea    0x4794(%rip),%rdi        # d898 <_IO_stdin_used+0x898>
    9104:	e8 97 b0 ff ff       	call   41a0 <fwp_trap>
    9109:	48 8d 3d 58 47 00 00 	lea    0x4758(%rip),%rdi        # d868 <_IO_stdin_used+0x868>
    9110:	e8 8b b0 ff ff       	call   41a0 <fwp_trap>
    9115:	e8 46 a3 ff ff       	call   3460 <__stack_chk_fail@plt>
    911a:	48 8d 3d e7 46 00 00 	lea    0x46e7(%rip),%rdi        # d808 <_IO_stdin_used+0x808>
    9121:	e8 7a b0 ff ff       	call   41a0 <fwp_trap>
    9126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    912d:	00 00 00 

0000000000009130 <fwp_owned_entry12>:
    9130:	f3 0f 1e fa          	endbr64
    9134:	48 8b 3f             	mov    (%rdi),%rdi
    9137:	e9 04 ea ff ff       	jmp    7b40 <f12>
    913c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009140 <e12>:
    9140:	f3 0f 1e fa          	endbr64
    9144:	53                   	push   %rbx
    9145:	48 8b 1f             	mov    (%rdi),%rbx
    9148:	48 89 df             	mov    %rbx,%rdi
    914b:	e8 90 d3 ff ff       	call   64e0 <fwp_rc_share>
    9150:	48 89 df             	mov    %rbx,%rdi
    9153:	e8 e8 e9 ff ff       	call   7b40 <f12>
    9158:	48 89 c3             	mov    %rax,%rbx
    915b:	48 89 c7             	mov    %rax,%rdi
    915e:	e8 7d d3 ff ff       	call   64e0 <fwp_rc_share>
    9163:	48 89 d8             	mov    %rbx,%rax
    9166:	5b                   	pop    %rbx
    9167:	c3                   	ret
    9168:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    916f:	00 

0000000000009170 <fwp_drop2>:
    9170:	48 8b 0d 01 9a 01 00 	mov    0x19a01(%rip),%rcx        # 22b78 <fwp_heap+0x13d8>
    9177:	48 89 f8             	mov    %rdi,%rax
    917a:	48 2b 05 cf 99 01 00 	sub    0x199cf(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    9181:	48 c1 e1 10          	shl    $0x10,%rcx
    9185:	48 39 c8             	cmp    %rcx,%rax
    9188:	0f 83 42 01 00 00    	jae    92d0 <fwp_drop2+0x160>
    918e:	48 83 ec 18          	sub    $0x18,%rsp
    9192:	48 89 fa             	mov    %rdi,%rdx
    9195:	4c 8d 05 04 86 01 00 	lea    0x18604(%rip),%r8        # 217a0 <fwp_heap>
    919c:	48 89 c1             	mov    %rax,%rcx
    919f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    91a6:	48 c1 e9 10          	shr    $0x10,%rcx
    91aa:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    91ae:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    91b2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    91b6:	48 85 c9             	test   %rcx,%rcx
    91b9:	74 40                	je     91fb <fwp_drop2+0x8b>
    91bb:	0f b6 3e             	movzbl (%rsi),%edi
    91be:	40 80 ff 02          	cmp    $0x2,%dil
    91c2:	74 3c                	je     9200 <fwp_drop2+0x90>
    91c4:	40 80 ff 01          	cmp    $0x1,%dil
    91c8:	75 31                	jne    91fb <fwp_drop2+0x8b>
    91ca:	8b 7e 18             	mov    0x18(%rsi),%edi
    91cd:	0f b7 c0             	movzwl %ax,%eax
    91d0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    91d3:	48 0f af c7          	imul   %rdi,%rax
    91d7:	48 c1 e8 20          	shr    $0x20,%rax
    91db:	48 39 f0             	cmp    %rsi,%rax
    91de:	73 1b                	jae    91fb <fwp_drop2+0x8b>
    91e0:	48 01 c1             	add    %rax,%rcx
    91e3:	0f b6 01             	movzbl (%rcx),%eax
    91e6:	84 c0                	test   %al,%al
    91e8:	74 11                	je     91fb <fwp_drop2+0x8b>
    91ea:	3c 01                	cmp    $0x1,%al
    91ec:	74 22                	je     9210 <fwp_drop2+0xa0>
    91ee:	3c ff                	cmp    $0xff,%al
    91f0:	0f 84 0a 01 00 00    	je     9300 <fwp_drop2+0x190>
    91f6:	83 e8 01             	sub    $0x1,%eax
    91f9:	88 01                	mov    %al,(%rcx)
    91fb:	48 83 c4 18          	add    $0x18,%rsp
    91ff:	c3                   	ret
    9200:	66 85 c0             	test   %ax,%ax
    9203:	74 de                	je     91e3 <fwp_drop2+0x73>
    9205:	48 83 c4 18          	add    $0x18,%rsp
    9209:	c3                   	ret
    920a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9210:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    9214:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    921b:	48 89 f8             	mov    %rdi,%rax
    921e:	48 c1 e1 10          	shl    $0x10,%rcx
    9222:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    9229:	48 39 c8             	cmp    %rcx,%rax
    922c:	73 62                	jae    9290 <fwp_drop2+0x120>
    922e:	48 89 c1             	mov    %rax,%rcx
    9231:	48 c1 e9 10          	shr    $0x10,%rcx
    9235:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    9239:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    923d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9241:	48 85 c9             	test   %rcx,%rcx
    9244:	74 4a                	je     9290 <fwp_drop2+0x120>
    9246:	44 0f b6 0e          	movzbl (%rsi),%r9d
    924a:	41 80 f9 02          	cmp    $0x2,%r9b
    924e:	0f 84 9c 00 00 00    	je     92f0 <fwp_drop2+0x180>
    9254:	41 80 f9 01          	cmp    $0x1,%r9b
    9258:	75 36                	jne    9290 <fwp_drop2+0x120>
    925a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    925e:	0f b7 c0             	movzwl %ax,%eax
    9261:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9264:	49 0f af c1          	imul   %r9,%rax
    9268:	48 c1 e8 20          	shr    $0x20,%rax
    926c:	48 39 f0             	cmp    %rsi,%rax
    926f:	73 1f                	jae    9290 <fwp_drop2+0x120>
    9271:	48 01 c1             	add    %rax,%rcx
    9274:	0f b6 01             	movzbl (%rcx),%eax
    9277:	84 c0                	test   %al,%al
    9279:	74 15                	je     9290 <fwp_drop2+0x120>
    927b:	3c 01                	cmp    $0x1,%al
    927d:	74 59                	je     92d8 <fwp_drop2+0x168>
    927f:	3c ff                	cmp    $0xff,%al
    9281:	0f 84 ff 00 00 00    	je     9386 <fwp_drop2+0x216>
    9287:	83 e8 01             	sub    $0x1,%eax
    928a:	88 01                	mov    %al,(%rcx)
    928c:	0f 1f 40 00          	nopl   0x0(%rax)
    9290:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    9294:	48 89 d7             	mov    %rdx,%rdi
    9297:	48 89 0c 24          	mov    %rcx,(%rsp)
    929b:	e8 c0 d2 ff ff       	call   6560 <fwp_rc_free_arr>
    92a0:	4c 8d 05 f9 84 01 00 	lea    0x184f9(%rip),%r8        # 217a0 <fwp_heap>
    92a7:	48 8b 04 24          	mov    (%rsp),%rax
    92ab:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    92b2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    92b9:	48 c1 e2 10          	shl    $0x10,%rdx
    92bd:	48 39 d0             	cmp    %rdx,%rax
    92c0:	0f 83 35 ff ff ff    	jae    91fb <fwp_drop2+0x8b>
    92c6:	48 8b 14 24          	mov    (%rsp),%rdx
    92ca:	e9 cd fe ff ff       	jmp    919c <fwp_drop2+0x2c>
    92cf:	90                   	nop
    92d0:	c3                   	ret
    92d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    92d8:	48 89 14 24          	mov    %rdx,(%rsp)
    92dc:	e8 7f d2 ff ff       	call   6560 <fwp_rc_free_arr>
    92e1:	48 8b 14 24          	mov    (%rsp),%rdx
    92e5:	eb a9                	jmp    9290 <fwp_drop2+0x120>
    92e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    92ee:	00 00 
    92f0:	66 85 c0             	test   %ax,%ax
    92f3:	75 9b                	jne    9290 <fwp_drop2+0x120>
    92f5:	e9 7a ff ff ff       	jmp    9274 <fwp_drop2+0x104>
    92fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9300:	48 89 c8             	mov    %rcx,%rax
    9303:	48 c1 e8 11          	shr    $0x11,%rax
    9307:	48 31 c8             	xor    %rcx,%rax
    930a:	48 89 c2             	mov    %rax,%rdx
    930d:	48 c1 ea 09          	shr    $0x9,%rdx
    9311:	48 31 d0             	xor    %rdx,%rax
    9314:	0f b6 d0             	movzbl %al,%edx
    9317:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    931e:	00 
    931f:	48 85 c0             	test   %rax,%rax
    9322:	75 29                	jne    934d <fwp_drop2+0x1dd>
    9324:	e9 e3 00 00 00       	jmp    940c <fwp_drop2+0x29c>
    9329:	90                   	nop
    932a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9331:	00 00 00 00 
    9335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    933c:	00 00 00 00 
    9340:	48 8b 42 10          	mov    0x10(%rdx),%rax
    9344:	48 85 c0             	test   %rax,%rax
    9347:	0f 84 bf 00 00 00    	je     940c <fwp_drop2+0x29c>
    934d:	48 89 c2             	mov    %rax,%rdx
    9350:	48 39 08             	cmp    %rcx,(%rax)
    9353:	75 eb                	jne    9340 <fwp_drop2+0x1d0>
    9355:	48 8b 50 08          	mov    0x8(%rax),%rdx
    9359:	48 83 ea 01          	sub    $0x1,%rdx
    935d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    9361:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    9368:	0f 85 8d fe ff ff    	jne    91fb <fwp_drop2+0x8b>
    936e:	48 89 cf             	mov    %rcx,%rdi
    9371:	48 89 0c 24          	mov    %rcx,(%rsp)
    9375:	e8 f6 bf ff ff       	call   5370 <fwp_rc_forget_slot>
    937a:	48 8b 0c 24          	mov    (%rsp),%rcx
    937e:	c6 01 fe             	movb   $0xfe,(%rcx)
    9381:	e9 75 fe ff ff       	jmp    91fb <fwp_drop2+0x8b>
    9386:	48 89 ce             	mov    %rcx,%rsi
    9389:	48 c1 ee 11          	shr    $0x11,%rsi
    938d:	48 31 ce             	xor    %rcx,%rsi
    9390:	48 89 f0             	mov    %rsi,%rax
    9393:	48 c1 e8 09          	shr    $0x9,%rax
    9397:	48 31 c6             	xor    %rax,%rsi
    939a:	40 0f b6 f6          	movzbl %sil,%esi
    939e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    93a5:	00 
    93a6:	48 85 c0             	test   %rax,%rax
    93a9:	75 1e                	jne    93c9 <fwp_drop2+0x259>
    93ab:	eb 5f                	jmp    940c <fwp_drop2+0x29c>
    93ad:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    93b4:	00 
    93b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    93bc:	00 00 00 00 
    93c0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    93c4:	48 85 c0             	test   %rax,%rax
    93c7:	74 43                	je     940c <fwp_drop2+0x29c>
    93c9:	48 89 c6             	mov    %rax,%rsi
    93cc:	48 39 08             	cmp    %rcx,(%rax)
    93cf:	75 ef                	jne    93c0 <fwp_drop2+0x250>
    93d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    93d5:	48 83 ee 01          	sub    $0x1,%rsi
    93d9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    93dd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    93e4:	0f 85 a6 fe ff ff    	jne    9290 <fwp_drop2+0x120>
    93ea:	48 89 cf             	mov    %rcx,%rdi
    93ed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    93f2:	48 89 0c 24          	mov    %rcx,(%rsp)
    93f6:	e8 75 bf ff ff       	call   5370 <fwp_rc_forget_slot>
    93fb:	48 8b 0c 24          	mov    (%rsp),%rcx
    93ff:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9404:	c6 01 fe             	movb   $0xfe,(%rcx)
    9407:	e9 84 fe ff ff       	jmp    9290 <fwp_drop2+0x120>
    940c:	48 8d 3d 85 43 00 00 	lea    0x4385(%rip),%rdi        # d798 <_IO_stdin_used+0x798>
    9413:	e8 88 ad ff ff       	call   41a0 <fwp_trap>
    9418:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    941f:	00 

0000000000009420 <fwp_arg_drop23>:
    9420:	f3 0f 1e fa          	endbr64
    9424:	85 f6                	test   %esi,%esi
    9426:	75 04                	jne    942c <fwp_arg_drop23+0xc>
    9428:	85 d2                	test   %edx,%edx
    942a:	75 04                	jne    9430 <fwp_arg_drop23+0x10>
    942c:	c3                   	ret
    942d:	0f 1f 00             	nopl   (%rax)
    9430:	48 8b 3f             	mov    (%rdi),%rdi
    9433:	e9 38 fd ff ff       	jmp    9170 <fwp_drop2>
    9438:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    943f:	00 

0000000000009440 <fwp_caps23>:
    9440:	f3 0f 1e fa          	endbr64
    9444:	48 83 ec 18          	sub    $0x18,%rsp
    9448:	8b 57 04             	mov    0x4(%rdi),%edx
    944b:	48 89 f8             	mov    %rdi,%rax
    944e:	85 d2                	test   %edx,%edx
    9450:	0f 84 9a 00 00 00    	je     94f0 <fwp_caps23+0xb0>
    9456:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    945a:	85 f6                	test   %esi,%esi
    945c:	0f 85 9e 00 00 00    	jne    9500 <fwp_caps23+0xc0>
    9462:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9467:	e8 04 fd ff ff       	call   9170 <fwp_drop2>
    946c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9471:	48 8b 0d 00 97 01 00 	mov    0x19700(%rip),%rcx        # 22b78 <fwp_heap+0x13d8>
    9478:	48 89 c2             	mov    %rax,%rdx
    947b:	48 2b 15 ce 96 01 00 	sub    0x196ce(%rip),%rdx        # 22b50 <fwp_heap+0x13b0>
    9482:	48 c1 e1 10          	shl    $0x10,%rcx
    9486:	48 39 ca             	cmp    %rcx,%rdx
    9489:	73 6d                	jae    94f8 <fwp_caps23+0xb8>
    948b:	48 89 d1             	mov    %rdx,%rcx
    948e:	48 c1 e9 10          	shr    $0x10,%rcx
    9492:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    9496:	48 8b 0d fb 96 01 00 	mov    0x196fb(%rip),%rcx        # 22b98 <fwp_heap+0x13f8>
    949d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    94a1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    94a5:	48 85 f6             	test   %rsi,%rsi
    94a8:	74 4e                	je     94f8 <fwp_caps23+0xb8>
    94aa:	0f b6 39             	movzbl (%rcx),%edi
    94ad:	40 80 ff 02          	cmp    $0x2,%dil
    94b1:	0f 84 b9 00 00 00    	je     9570 <fwp_caps23+0x130>
    94b7:	40 80 ff 01          	cmp    $0x1,%dil
    94bb:	75 3b                	jne    94f8 <fwp_caps23+0xb8>
    94bd:	8b 79 18             	mov    0x18(%rcx),%edi
    94c0:	0f b7 d2             	movzwl %dx,%edx
    94c3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    94c6:	48 0f af d7          	imul   %rdi,%rdx
    94ca:	48 c1 ea 20          	shr    $0x20,%rdx
    94ce:	48 39 ca             	cmp    %rcx,%rdx
    94d1:	73 25                	jae    94f8 <fwp_caps23+0xb8>
    94d3:	48 01 d6             	add    %rdx,%rsi
    94d6:	80 3e 01             	cmpb   $0x1,(%rsi)
    94d9:	75 1d                	jne    94f8 <fwp_caps23+0xb8>
    94db:	48 89 c7             	mov    %rax,%rdi
    94de:	48 83 c4 18          	add    $0x18,%rsp
    94e2:	e9 c9 c0 ff ff       	jmp    55b0 <fwp_mem_free>
    94e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    94ee:	00 00 
    94f0:	85 f6                	test   %esi,%esi
    94f2:	0f 84 79 ff ff ff    	je     9471 <fwp_caps23+0x31>
    94f8:	48 83 c4 18          	add    $0x18,%rsp
    94fc:	c3                   	ret
    94fd:	0f 1f 00             	nopl   (%rax)
    9500:	48 8b 05 71 96 01 00 	mov    0x19671(%rip),%rax        # 22b78 <fwp_heap+0x13d8>
    9507:	48 2b 3d 42 96 01 00 	sub    0x19642(%rip),%rdi        # 22b50 <fwp_heap+0x13b0>
    950e:	48 c1 e0 10          	shl    $0x10,%rax
    9512:	48 39 c7             	cmp    %rax,%rdi
    9515:	73 e1                	jae    94f8 <fwp_caps23+0xb8>
    9517:	48 89 f8             	mov    %rdi,%rax
    951a:	48 c1 e8 10          	shr    $0x10,%rax
    951e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9522:	48 8b 05 6f 96 01 00 	mov    0x1966f(%rip),%rax        # 22b98 <fwp_heap+0x13f8>
    9529:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    952d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    9531:	48 85 c0             	test   %rax,%rax
    9534:	74 c2                	je     94f8 <fwp_caps23+0xb8>
    9536:	0f b6 0a             	movzbl (%rdx),%ecx
    9539:	80 f9 02             	cmp    $0x2,%cl
    953c:	74 42                	je     9580 <fwp_caps23+0x140>
    953e:	80 f9 01             	cmp    $0x1,%cl
    9541:	75 b5                	jne    94f8 <fwp_caps23+0xb8>
    9543:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9546:	0f b7 ff             	movzwl %di,%edi
    9549:	8b 52 1c             	mov    0x1c(%rdx),%edx
    954c:	48 0f af f9          	imul   %rcx,%rdi
    9550:	48 c1 ef 20          	shr    $0x20,%rdi
    9554:	48 39 d7             	cmp    %rdx,%rdi
    9557:	73 9f                	jae    94f8 <fwp_caps23+0xb8>
    9559:	48 01 f8             	add    %rdi,%rax
    955c:	0f b6 10             	movzbl (%rax),%edx
    955f:	84 d2                	test   %dl,%dl
    9561:	74 95                	je     94f8 <fwp_caps23+0xb8>
    9563:	80 fa fd             	cmp    $0xfd,%dl
    9566:	77 23                	ja     958b <fwp_caps23+0x14b>
    9568:	83 c2 01             	add    $0x1,%edx
    956b:	88 10                	mov    %dl,(%rax)
    956d:	eb 89                	jmp    94f8 <fwp_caps23+0xb8>
    956f:	90                   	nop
    9570:	66 85 d2             	test   %dx,%dx
    9573:	0f 85 7f ff ff ff    	jne    94f8 <fwp_caps23+0xb8>
    9579:	e9 58 ff ff ff       	jmp    94d6 <fwp_caps23+0x96>
    957e:	66 90                	xchg   %ax,%ax
    9580:	66 85 ff             	test   %di,%di
    9583:	0f 85 6f ff ff ff    	jne    94f8 <fwp_caps23+0xb8>
    9589:	eb d1                	jmp    955c <fwp_caps23+0x11c>
    958b:	48 89 c7             	mov    %rax,%rdi
    958e:	48 83 c4 18          	add    $0x18,%rsp
    9592:	e9 b9 bc ff ff       	jmp    5250 <fwp_rc_wide_dup>
    9597:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    959e:	00 00 

00000000000095a0 <f23>:
    95a0:	41 57                	push   %r15
    95a2:	41 56                	push   %r14
    95a4:	41 55                	push   %r13
    95a6:	41 54                	push   %r12
    95a8:	55                   	push   %rbp
    95a9:	53                   	push   %rbx
    95aa:	48 83 ec 38          	sub    $0x38,%rsp
    95ae:	48 8b 15 c3 95 01 00 	mov    0x195c3(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    95b5:	48 8b 0d 94 95 01 00 	mov    0x19594(%rip),%rcx        # 22b50 <fwp_heap+0x13b0>
    95bc:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    95c3:	00 00 
    95c5:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    95ca:	49 89 fc             	mov    %rdi,%r12
    95cd:	48 c1 e2 10          	shl    $0x10,%rdx
    95d1:	48 85 ff             	test   %rdi,%rdi
    95d4:	0f 84 bc 02 00 00    	je     9896 <f23+0x2f6>
    95da:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    95df:	48 89 d8             	mov    %rbx,%rax
    95e2:	48 29 c8             	sub    %rcx,%rax
    95e5:	48 39 d0             	cmp    %rdx,%rax
    95e8:	0f 83 72 03 00 00    	jae    9960 <f23+0x3c0>
    95ee:	48 89 c2             	mov    %rax,%rdx
    95f1:	48 c1 ea 10          	shr    $0x10,%rdx
    95f5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    95f9:	48 8b 15 98 95 01 00 	mov    0x19598(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    9600:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9604:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9608:	48 85 ff             	test   %rdi,%rdi
    960b:	0f 84 4f 03 00 00    	je     9960 <f23+0x3c0>
    9611:	0f b6 0a             	movzbl (%rdx),%ecx
    9614:	80 f9 02             	cmp    $0x2,%cl
    9617:	0f 84 53 02 00 00    	je     9870 <f23+0x2d0>
    961d:	80 f9 01             	cmp    $0x1,%cl
    9620:	75 24                	jne    9646 <f23+0xa6>
    9622:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9625:	0f b7 c0             	movzwl %ax,%eax
    9628:	8b 52 1c             	mov    0x1c(%rdx),%edx
    962b:	48 0f af c1          	imul   %rcx,%rax
    962f:	48 c1 e8 20          	shr    $0x20,%rax
    9633:	48 39 d0             	cmp    %rdx,%rax
    9636:	73 0e                	jae    9646 <f23+0xa6>
    9638:	48 01 c7             	add    %rax,%rdi
    963b:	0f b6 07             	movzbl (%rdi),%eax
    963e:	84 c0                	test   %al,%al
    9640:	0f 85 ca 02 00 00    	jne    9910 <f23+0x370>
    9646:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    964b:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    9650:	ba 01 00 00 00       	mov    $0x1,%edx
    9655:	48 85 db             	test   %rbx,%rbx
    9658:	74 13                	je     966d <f23+0xcd>
    965a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9660:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    9664:	48 83 c2 01          	add    $0x1,%rdx
    9668:	48 85 db             	test   %rbx,%rbx
    966b:	75 f3                	jne    9660 <f23+0xc0>
    966d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9672:	48 85 c0             	test   %rax,%rax
    9675:	0f 84 15 03 00 00    	je     9990 <f23+0x3f0>
    967b:	31 db                	xor    %ebx,%ebx
    967d:	0f 1f 00             	nopl   (%rax)
    9680:	48 8b 40 10          	mov    0x10(%rax),%rax
    9684:	48 83 c3 01          	add    $0x1,%rbx
    9688:	48 85 c0             	test   %rax,%rax
    968b:	75 f3                	jne    9680 <f23+0xe0>
    968d:	48 39 d3             	cmp    %rdx,%rbx
    9690:	48 0f 47 da          	cmova  %rdx,%rbx
    9694:	48 89 d8             	mov    %rbx,%rax
    9697:	48 c1 e8 3c          	shr    $0x3c,%rax
    969b:	0f 85 8f 03 00 00    	jne    9a30 <f23+0x490>
    96a1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    96a5:	be 02 00 00 00       	mov    $0x2,%esi
    96aa:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    96b1:	00 
    96b2:	e8 f9 c3 ff ff       	call   5ab0 <fwp_heap_alloc>
    96b7:	48 89 28             	mov    %rbp,(%rax)
    96ba:	48 8b 15 b7 94 01 00 	mov    0x194b7(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    96c1:	49 89 c6             	mov    %rax,%r14
    96c4:	48 2b 05 85 94 01 00 	sub    0x19485(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    96cb:	48 c1 e2 10          	shl    $0x10,%rdx
    96cf:	48 39 d0             	cmp    %rdx,%rax
    96d2:	73 57                	jae    972b <f23+0x18b>
    96d4:	48 89 c2             	mov    %rax,%rdx
    96d7:	48 c1 ea 10          	shr    $0x10,%rdx
    96db:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    96df:	48 8b 15 b2 94 01 00 	mov    0x194b2(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    96e6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    96ea:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    96ee:	48 85 ed             	test   %rbp,%rbp
    96f1:	74 38                	je     972b <f23+0x18b>
    96f3:	0f b6 0a             	movzbl (%rdx),%ecx
    96f6:	80 f9 02             	cmp    $0x2,%cl
    96f9:	0f 84 51 02 00 00    	je     9950 <f23+0x3b0>
    96ff:	80 f9 01             	cmp    $0x1,%cl
    9702:	75 27                	jne    972b <f23+0x18b>
    9704:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9707:	0f b7 c0             	movzwl %ax,%eax
    970a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    970d:	48 0f af c1          	imul   %rcx,%rax
    9711:	48 c1 e8 20          	shr    $0x20,%rax
    9715:	48 39 d0             	cmp    %rdx,%rax
    9718:	73 11                	jae    972b <f23+0x18b>
    971a:	48 01 c5             	add    %rax,%rbp
    971d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9721:	0f 84 d5 02 00 00    	je     99fc <f23+0x45c>
    9727:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    972b:	48 85 db             	test   %rbx,%rbx
    972e:	74 5d                	je     978d <f23+0x1ed>
    9730:	48 c1 e3 04          	shl    $0x4,%rbx
    9734:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    9739:	4c 89 f5             	mov    %r14,%rbp
    973c:	4d 89 e5             	mov    %r12,%r13
    973f:	4c 01 f3             	add    %r14,%rbx
    9742:	0f 1f 00             	nopl   (%rax)
    9745:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    974c:	00 00 00 00 
    9750:	49 8b 45 08          	mov    0x8(%r13),%rax
    9754:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    9758:	48 83 c5 10          	add    $0x10,%rbp
    975c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    9761:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    9765:	48 8b 78 10          	mov    0x10(%rax),%rdi
    9769:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    976e:	e8 1d ca ff ff       	call   6190 <w107>
    9773:	66 48 0f 6e d0       	movq   %rax,%xmm2
    9778:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    977c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    9780:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    9784:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    9788:	48 39 dd             	cmp    %rbx,%rbp
    978b:	75 c3                	jne    9750 <f23+0x1b0>
    978d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9792:	e8 d9 f9 ff ff       	call   9170 <fwp_drop2>
    9797:	4c 89 e7             	mov    %r12,%rdi
    979a:	e8 d1 f9 ff ff       	call   9170 <fwp_drop2>
    979f:	4c 89 f7             	mov    %r14,%rdi
    97a2:	e8 69 cb ff ff       	call   6310 <w164.constprop.0>
    97a7:	4c 89 f7             	mov    %r14,%rdi
    97aa:	48 89 c3             	mov    %rax,%rbx
    97ad:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    97b3:	e8 78 de ff ff       	call   7630 <fwp_drop4>
    97b8:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    97be:	66 48 0f 6e db       	movq   %rbx,%xmm3
    97c3:	31 ff                	xor    %edi,%edi
    97c5:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    97ca:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    97ce:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    97d3:	e8 d8 cb ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    97d8:	48 8b 15 99 93 01 00 	mov    0x19399(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    97df:	48 89 c5             	mov    %rax,%rbp
    97e2:	48 2b 05 67 93 01 00 	sub    0x19367(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    97e9:	48 c1 e2 10          	shl    $0x10,%rdx
    97ed:	48 39 d0             	cmp    %rdx,%rax
    97f0:	73 55                	jae    9847 <f23+0x2a7>
    97f2:	48 89 c2             	mov    %rax,%rdx
    97f5:	48 c1 ea 10          	shr    $0x10,%rdx
    97f9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    97fd:	48 8b 15 94 93 01 00 	mov    0x19394(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    9804:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9808:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    980c:	48 85 db             	test   %rbx,%rbx
    980f:	74 36                	je     9847 <f23+0x2a7>
    9811:	0f b6 0a             	movzbl (%rdx),%ecx
    9814:	80 f9 02             	cmp    $0x2,%cl
    9817:	0f 84 1b 01 00 00    	je     9938 <f23+0x398>
    981d:	80 f9 01             	cmp    $0x1,%cl
    9820:	75 25                	jne    9847 <f23+0x2a7>
    9822:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9825:	0f b7 c0             	movzwl %ax,%eax
    9828:	8b 52 1c             	mov    0x1c(%rdx),%edx
    982b:	48 0f af c1          	imul   %rcx,%rax
    982f:	48 c1 e8 20          	shr    $0x20,%rax
    9833:	48 39 d0             	cmp    %rdx,%rax
    9836:	73 0f                	jae    9847 <f23+0x2a7>
    9838:	48 01 c3             	add    %rax,%rbx
    983b:	80 3b ff             	cmpb   $0xff,(%rbx)
    983e:	0f 84 ab 01 00 00    	je     99ef <f23+0x44f>
    9844:	c6 03 01             	movb   $0x1,(%rbx)
    9847:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    984c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9853:	00 00 
    9855:	0f 85 d0 01 00 00    	jne    9a2b <f23+0x48b>
    985b:	48 83 c4 38          	add    $0x38,%rsp
    985f:	48 89 e8             	mov    %rbp,%rax
    9862:	5b                   	pop    %rbx
    9863:	5d                   	pop    %rbp
    9864:	41 5c                	pop    %r12
    9866:	41 5d                	pop    %r13
    9868:	41 5e                	pop    %r14
    986a:	41 5f                	pop    %r15
    986c:	c3                   	ret
    986d:	0f 1f 00             	nopl   (%rax)
    9870:	66 85 c0             	test   %ax,%ax
    9873:	0f 85 cd fd ff ff    	jne    9646 <f23+0xa6>
    9879:	0f b6 07             	movzbl (%rdi),%eax
    987c:	84 c0                	test   %al,%al
    987e:	0f 84 c2 fd ff ff    	je     9646 <f23+0xa6>
    9884:	3c fd                	cmp    $0xfd,%al
    9886:	0f 87 95 01 00 00    	ja     9a21 <f23+0x481>
    988c:	83 c0 01             	add    $0x1,%eax
    988f:	88 07                	mov    %al,(%rdi)
    9891:	e9 b0 fd ff ff       	jmp    9646 <f23+0xa6>
    9896:	48 f7 d9             	neg    %rcx
    9899:	48 39 d1             	cmp    %rdx,%rcx
    989c:	0f 83 ee 00 00 00    	jae    9990 <f23+0x3f0>
    98a2:	48 89 c8             	mov    %rcx,%rax
    98a5:	48 c1 e8 10          	shr    $0x10,%rax
    98a9:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    98ad:	48 8b 05 e4 92 01 00 	mov    0x192e4(%rip),%rax        # 22b98 <fwp_heap+0x13f8>
    98b4:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    98b8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    98bc:	48 85 ff             	test   %rdi,%rdi
    98bf:	0f 84 cb 00 00 00    	je     9990 <f23+0x3f0>
    98c5:	0f b6 02             	movzbl (%rdx),%eax
    98c8:	3c 02                	cmp    $0x2,%al
    98ca:	0f 84 9a 00 00 00    	je     996a <f23+0x3ca>
    98d0:	3c 01                	cmp    $0x1,%al
    98d2:	0f 85 b8 00 00 00    	jne    9990 <f23+0x3f0>
    98d8:	0f b7 c1             	movzwl %cx,%eax
    98db:	8b 4a 18             	mov    0x18(%rdx),%ecx
    98de:	8b 52 1c             	mov    0x1c(%rdx),%edx
    98e1:	48 0f af c1          	imul   %rcx,%rax
    98e5:	48 c1 e8 20          	shr    $0x20,%rax
    98e9:	48 39 d0             	cmp    %rdx,%rax
    98ec:	0f 83 9e 00 00 00    	jae    9990 <f23+0x3f0>
    98f2:	48 01 c7             	add    %rax,%rdi
    98f5:	0f b6 07             	movzbl (%rdi),%eax
    98f8:	84 c0                	test   %al,%al
    98fa:	0f 84 90 00 00 00    	je     9990 <f23+0x3f0>
    9900:	31 db                	xor    %ebx,%ebx
    9902:	0f 1f 00             	nopl   (%rax)
    9905:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    990c:	00 00 00 00 
    9910:	3c fd                	cmp    $0xfd,%al
    9912:	0f 87 f1 00 00 00    	ja     9a09 <f23+0x469>
    9918:	83 c0 01             	add    $0x1,%eax
    991b:	88 07                	mov    %al,(%rdi)
    991d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9922:	31 d2                	xor    %edx,%edx
    9924:	4d 85 e4             	test   %r12,%r12
    9927:	0f 85 1e fd ff ff    	jne    964b <f23+0xab>
    992d:	e9 3b fd ff ff       	jmp    966d <f23+0xcd>
    9932:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9938:	66 85 c0             	test   %ax,%ax
    993b:	0f 85 06 ff ff ff    	jne    9847 <f23+0x2a7>
    9941:	e9 f5 fe ff ff       	jmp    983b <f23+0x29b>
    9946:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    994d:	00 00 00 
    9950:	66 85 c0             	test   %ax,%ax
    9953:	0f 85 d2 fd ff ff    	jne    972b <f23+0x18b>
    9959:	e9 bf fd ff ff       	jmp    971d <f23+0x17d>
    995e:	66 90                	xchg   %ax,%ax
    9960:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9965:	e9 e6 fc ff ff       	jmp    9650 <f23+0xb0>
    996a:	66 85 c9             	test   %cx,%cx
    996d:	75 21                	jne    9990 <f23+0x3f0>
    996f:	0f b6 07             	movzbl (%rdi),%eax
    9972:	84 c0                	test   %al,%al
    9974:	74 1a                	je     9990 <f23+0x3f0>
    9976:	3c fd                	cmp    $0xfd,%al
    9978:	0f 87 be 00 00 00    	ja     9a3c <f23+0x49c>
    997e:	83 c0 01             	add    $0x1,%eax
    9981:	88 07                	mov    %al,(%rdi)
    9983:	66 90                	xchg   %ax,%ax
    9985:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    998c:	00 00 00 00 
    9990:	be 02 00 00 00       	mov    $0x2,%esi
    9995:	bf 08 00 00 00       	mov    $0x8,%edi
    999a:	e8 11 c1 ff ff       	call   5ab0 <fwp_heap_alloc>
    999f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    99a6:	48 8b 15 cb 91 01 00 	mov    0x191cb(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    99ad:	49 89 c6             	mov    %rax,%r14
    99b0:	48 2b 05 99 91 01 00 	sub    0x19199(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    99b7:	48 c1 e2 10          	shl    $0x10,%rdx
    99bb:	48 39 d0             	cmp    %rdx,%rax
    99be:	73 53                	jae    9a13 <f23+0x473>
    99c0:	48 89 c2             	mov    %rax,%rdx
    99c3:	48 c1 ea 10          	shr    $0x10,%rdx
    99c7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    99cb:	48 8b 15 c6 91 01 00 	mov    0x191c6(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    99d2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    99d6:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    99da:	48 85 ed             	test   %rbp,%rbp
    99dd:	74 34                	je     9a13 <f23+0x473>
    99df:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    99e6:	00 00 
    99e8:	31 db                	xor    %ebx,%ebx
    99ea:	e9 04 fd ff ff       	jmp    96f3 <f23+0x153>
    99ef:	48 89 df             	mov    %rbx,%rdi
    99f2:	e8 79 b9 ff ff       	call   5370 <fwp_rc_forget_slot>
    99f7:	e9 48 fe ff ff       	jmp    9844 <f23+0x2a4>
    99fc:	48 89 ef             	mov    %rbp,%rdi
    99ff:	e8 6c b9 ff ff       	call   5370 <fwp_rc_forget_slot>
    9a04:	e9 1e fd ff ff       	jmp    9727 <f23+0x187>
    9a09:	e8 42 b8 ff ff       	call   5250 <fwp_rc_wide_dup>
    9a0e:	e9 0a ff ff ff       	jmp    991d <f23+0x37d>
    9a13:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    9a1a:	00 00 
    9a1c:	e9 6c fd ff ff       	jmp    978d <f23+0x1ed>
    9a21:	e8 2a b8 ff ff       	call   5250 <fwp_rc_wide_dup>
    9a26:	e9 1b fc ff ff       	jmp    9646 <f23+0xa6>
    9a2b:	e8 30 9a ff ff       	call   3460 <__stack_chk_fail@plt>
    9a30:	48 8d 3d 10 37 00 00 	lea    0x3710(%rip),%rdi        # d147 <_IO_stdin_used+0x147>
    9a37:	e8 64 a7 ff ff       	call   41a0 <fwp_trap>
    9a3c:	e8 0f b8 ff ff       	call   5250 <fwp_rc_wide_dup>
    9a41:	e9 4a ff ff ff       	jmp    9990 <f23+0x3f0>
    9a46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9a4d:	00 00 00 

0000000000009a50 <fwp_owned_entry23>:
    9a50:	f3 0f 1e fa          	endbr64
    9a54:	48 8b 3f             	mov    (%rdi),%rdi
    9a57:	e9 44 fb ff ff       	jmp    95a0 <f23>
    9a5c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009a60 <e23>:
    9a60:	f3 0f 1e fa          	endbr64
    9a64:	53                   	push   %rbx
    9a65:	48 8b 1f             	mov    (%rdi),%rbx
    9a68:	48 89 df             	mov    %rbx,%rdi
    9a6b:	e8 70 ca ff ff       	call   64e0 <fwp_rc_share>
    9a70:	48 89 df             	mov    %rbx,%rdi
    9a73:	e8 28 fb ff ff       	call   95a0 <f23>
    9a78:	48 89 c3             	mov    %rax,%rbx
    9a7b:	48 89 c7             	mov    %rax,%rdi
    9a7e:	e8 5d ca ff ff       	call   64e0 <fwp_rc_share>
    9a83:	48 89 d8             	mov    %rbx,%rax
    9a86:	5b                   	pop    %rbx
    9a87:	c3                   	ret
    9a88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9a8f:	00 

0000000000009a90 <fwp_write>:
    9a90:	41 57                	push   %r15
    9a92:	41 56                	push   %r14
    9a94:	41 55                	push   %r13
    9a96:	41 54                	push   %r12
    9a98:	55                   	push   %rbp
    9a99:	53                   	push   %rbx
    9a9a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9aa1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9aa8:	00 00 
    9aaa:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9ab1:	00 
    9ab2:	49 89 d4             	mov    %rdx,%r12
    9ab5:	8b 12                	mov    (%rdx),%edx
    9ab7:	83 fa 19             	cmp    $0x19,%edx
    9aba:	77 6a                	ja     9b26 <fwp_write+0x96>
    9abc:	48 89 f5             	mov    %rsi,%rbp
    9abf:	89 d0                	mov    %edx,%eax
    9ac1:	89 ce                	mov    %ecx,%esi
    9ac3:	48 89 fb             	mov    %rdi,%rbx
    9ac6:	48 8d 0d 43 3f 00 00 	lea    0x3f43(%rip),%rcx        # da10 <_IO_stdin_used+0xa10>
    9acd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9ad1:	48 01 c8             	add    %rcx,%rax
    9ad4:	3e ff e0             	notrack jmp *%rax
    9ad7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9ade:	00 00 
    9ae0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9ae4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9ae8:	48 89 ca             	mov    %rcx,%rdx
    9aeb:	48 85 c9             	test   %rcx,%rcx
    9aee:	0f 88 9c 0c 00 00    	js     a790 <fwp_write+0xd00>
    9af4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9afb:	00 
    9afc:	48 89 c6             	mov    %rax,%rsi
    9aff:	4c 89 e7             	mov    %r12,%rdi
    9b02:	e8 39 9f ff ff       	call   3a40 <fwp_fmt_u128>
    9b07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9b0e:	00 00 
    9b10:	4c 89 e7             	mov    %r12,%rdi
    9b13:	e8 38 99 ff ff       	call   3450 <strlen@plt>
    9b18:	4c 89 e6             	mov    %r12,%rsi
    9b1b:	48 89 df             	mov    %rbx,%rdi
    9b1e:	48 89 c2             	mov    %rax,%rdx
    9b21:	e8 4a a5 ff ff       	call   4070 <buf_put>
    9b26:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9b2d:	00 
    9b2e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9b35:	00 00 
    9b37:	0f 85 28 04 00 00    	jne    9f65 <fwp_write+0x4d5>
    9b3d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9b44:	5b                   	pop    %rbx
    9b45:	5d                   	pop    %rbp
    9b46:	41 5c                	pop    %r12
    9b48:	41 5d                	pop    %r13
    9b4a:	41 5e                	pop    %r14
    9b4c:	41 5f                	pop    %r15
    9b4e:	c3                   	ret
    9b4f:	90                   	nop
    9b50:	49 89 e9             	mov    %rbp,%r9
    9b53:	4c 8d 05 27 36 00 00 	lea    0x3627(%rip),%r8        # d181 <_IO_stdin_used+0x181>
    9b5a:	b9 00 02 00 00       	mov    $0x200,%ecx
    9b5f:	ba 02 00 00 00       	mov    $0x2,%edx
    9b64:	be 00 02 00 00       	mov    $0x200,%esi
    9b69:	31 c0                	xor    %eax,%eax
    9b6b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9b72:	00 
    9b73:	e8 38 98 ff ff       	call   33b0 <__snprintf_chk@plt>
    9b78:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9b7f:	00 
    9b80:	e8 cb 98 ff ff       	call   3450 <strlen@plt>
    9b85:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9b8c:	00 
    9b8d:	48 89 df             	mov    %rbx,%rdi
    9b90:	48 89 c2             	mov    %rax,%rdx
    9b93:	e8 d8 a4 ff ff       	call   4070 <buf_put>
    9b98:	eb 8c                	jmp    9b26 <fwp_write+0x96>
    9b9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ba0:	49 89 e9             	mov    %rbp,%r9
    9ba3:	4c 8d 05 d2 35 00 00 	lea    0x35d2(%rip),%r8        # d17c <_IO_stdin_used+0x17c>
    9baa:	eb ae                	jmp    9b5a <fwp_write+0xca>
    9bac:	0f 1f 40 00          	nopl   0x0(%rax)
    9bb0:	83 fa 13             	cmp    $0x13,%edx
    9bb3:	48 8d 05 b8 35 00 00 	lea    0x35b8(%rip),%rax        # d172 <_IO_stdin_used+0x172>
    9bba:	48 8d 35 b6 35 00 00 	lea    0x35b6(%rip),%rsi        # d177 <_IO_stdin_used+0x177>
    9bc1:	ba 04 00 00 00       	mov    $0x4,%edx
    9bc6:	48 0f 44 f0          	cmove  %rax,%rsi
    9bca:	45 31 ed             	xor    %r13d,%r13d
    9bcd:	e8 9e a4 ff ff       	call   4070 <buf_put>
    9bd2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9bd7:	0f 84 a3 08 00 00    	je     a480 <fwp_write+0x9f0>
    9bdd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9be2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9be7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9bec:	48 89 df             	mov    %rbx,%rdi
    9bef:	49 0f 44 c5          	cmove  %r13,%rax
    9bf3:	31 c9                	xor    %ecx,%ecx
    9bf5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    9bfa:	e8 91 fe ff ff       	call   9a90 <fwp_write>
    9bff:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9c04:	0f 84 6e 09 00 00    	je     a578 <fwp_write+0xae8>
    9c0a:	49 83 c5 01          	add    $0x1,%r13
    9c0e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9c12:	0f 83 68 08 00 00    	jae    a480 <fwp_write+0x9f0>
    9c18:	ba 02 00 00 00       	mov    $0x2,%edx
    9c1d:	48 8d 35 9d 35 00 00 	lea    0x359d(%rip),%rsi        # d1c1 <_IO_stdin_used+0x1c1>
    9c24:	48 89 df             	mov    %rbx,%rdi
    9c27:	e8 44 a4 ff ff       	call   4070 <buf_put>
    9c2c:	eb af                	jmp    9bdd <fwp_write+0x14d>
    9c2e:	66 90                	xchg   %ax,%ax
    9c30:	ba 06 00 00 00       	mov    $0x6,%edx
    9c35:	48 8d 35 5e 35 00 00 	lea    0x355e(%rip),%rsi        # d19a <_IO_stdin_used+0x19a>
    9c3c:	48 83 c5 10          	add    $0x10,%rbp
    9c40:	e8 2b a4 ff ff       	call   4070 <buf_put>
    9c45:	48 89 ef             	mov    %rbp,%rdi
    9c48:	e8 03 98 ff ff       	call   3450 <strlen@plt>
    9c4d:	48 89 ee             	mov    %rbp,%rsi
    9c50:	48 89 df             	mov    %rbx,%rdi
    9c53:	48 89 c2             	mov    %rax,%rdx
    9c56:	e8 15 a4 ff ff       	call   4070 <buf_put>
    9c5b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9c60:	ba 01 00 00 00       	mov    $0x1,%edx
    9c65:	48 89 df             	mov    %rbx,%rdi
    9c68:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9c6d:	e8 fe a3 ff ff       	call   4070 <buf_put>
    9c72:	e9 af fe ff ff       	jmp    9b26 <fwp_write+0x96>
    9c77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9c7e:	00 00 
    9c80:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9c87:	00 
    9c88:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9c8f:	00 00 
    9c91:	0f 85 ce 02 00 00    	jne    9f65 <fwp_write+0x4d5>
    9c97:	ba 0a 00 00 00       	mov    $0xa,%edx
    9c9c:	48 8d 35 e3 34 00 00 	lea    0x34e3(%rip),%rsi        # d186 <_IO_stdin_used+0x186>
    9ca3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9caa:	48 89 df             	mov    %rbx,%rdi
    9cad:	5b                   	pop    %rbx
    9cae:	5d                   	pop    %rbp
    9caf:	41 5c                	pop    %r12
    9cb1:	41 5d                	pop    %r13
    9cb3:	41 5e                	pop    %r14
    9cb5:	41 5f                	pop    %r15
    9cb7:	e9 b4 a3 ff ff       	jmp    4070 <buf_put>
    9cbc:	0f 1f 40 00          	nopl   0x0(%rax)
    9cc0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    9cc5:	4d 85 ed             	test   %r13,%r13
    9cc8:	0f 84 02 0c 00 00    	je     a8d0 <fwp_write+0xe40>
    9cce:	48 8d 35 f9 34 00 00 	lea    0x34f9(%rip),%rsi        # d1ce <_IO_stdin_used+0x1ce>
    9cd5:	4c 89 ef             	mov    %r13,%rdi
    9cd8:	e8 53 98 ff ff       	call   3530 <strcmp@plt>
    9cdd:	41 89 c1             	mov    %eax,%r9d
    9ce0:	85 c0                	test   %eax,%eax
    9ce2:	0f 84 6c 0c 00 00    	je     a954 <fwp_write+0xec4>
    9ce8:	4c 89 ef             	mov    %r13,%rdi
    9ceb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9cf0:	e8 5b 97 ff ff       	call   3450 <strlen@plt>
    9cf5:	4c 89 ee             	mov    %r13,%rsi
    9cf8:	48 89 df             	mov    %rbx,%rdi
    9cfb:	48 89 c2             	mov    %rax,%rdx
    9cfe:	e8 6d a3 ff ff       	call   4070 <buf_put>
    9d03:	ba 01 00 00 00       	mov    $0x1,%edx
    9d08:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9d0d:	48 89 df             	mov    %rbx,%rdi
    9d10:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9d15:	e8 56 a3 ff ff       	call   4070 <buf_put>
    9d1a:	ba 01 00 00 00       	mov    $0x1,%edx
    9d1f:	4c 89 fe             	mov    %r15,%rsi
    9d22:	48 89 df             	mov    %rbx,%rdi
    9d25:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    9d2a:	e8 41 a3 ff ff       	call   4070 <buf_put>
    9d2f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9d34:	45 31 f6             	xor    %r14d,%r14d
    9d37:	85 d2                	test   %edx,%edx
    9d39:	0f 8e 81 0a 00 00    	jle    a7c0 <fwp_write+0xd30>
    9d3f:	45 31 ed             	xor    %r13d,%r13d
    9d42:	4d 85 ed             	test   %r13,%r13
    9d45:	0f 85 75 07 00 00    	jne    a4c0 <fwp_write+0xa30>
    9d4b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9d52:	00 
    9d53:	45 85 f6             	test   %r14d,%r14d
    9d56:	0f 84 84 07 00 00    	je     a4e0 <fwp_write+0xa50>
    9d5c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    9d61:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    9d66:	48 89 df             	mov    %rbx,%rdi
    9d69:	49 83 c5 01          	add    $0x1,%r13
    9d6d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    9d71:	31 c9                	xor    %ecx,%ecx
    9d73:	e8 18 fd ff ff       	call   9a90 <fwp_write>
    9d78:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    9d7d:	7f c3                	jg     9d42 <fwp_write+0x2b2>
    9d7f:	45 85 f6             	test   %r14d,%r14d
    9d82:	0f 84 38 0a 00 00    	je     a7c0 <fwp_write+0xd30>
    9d88:	b8 29 00 00 00       	mov    $0x29,%eax
    9d8d:	ba 01 00 00 00       	mov    $0x1,%edx
    9d92:	4c 89 fe             	mov    %r15,%rsi
    9d95:	48 89 df             	mov    %rbx,%rdi
    9d98:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    9d9c:	e8 cf a2 ff ff       	call   4070 <buf_put>
    9da1:	e9 80 fd ff ff       	jmp    9b26 <fwp_write+0x96>
    9da6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9dad:	00 00 00 
    9db0:	ba 01 00 00 00       	mov    $0x1,%edx
    9db5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9dba:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    9dbf:	e8 ac a2 ff ff       	call   4070 <buf_put>
    9dc4:	48 85 ed             	test   %rbp,%rbp
    9dc7:	0f 84 93 06 00 00    	je     a460 <fwp_write+0x9d0>
    9dcd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    9dd1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9dd6:	31 c9                	xor    %ecx,%ecx
    9dd8:	48 89 df             	mov    %rbx,%rdi
    9ddb:	e8 b0 fc ff ff       	call   9a90 <fwp_write>
    9de0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    9de4:	48 85 ed             	test   %rbp,%rbp
    9de7:	0f 84 73 06 00 00    	je     a460 <fwp_write+0x9d0>
    9ded:	ba 02 00 00 00       	mov    $0x2,%edx
    9df2:	48 8d 35 c8 33 00 00 	lea    0x33c8(%rip),%rsi        # d1c1 <_IO_stdin_used+0x1c1>
    9df9:	48 89 df             	mov    %rbx,%rdi
    9dfc:	e8 6f a2 ff ff       	call   4070 <buf_put>
    9e01:	eb ca                	jmp    9dcd <fwp_write+0x33d>
    9e03:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9e08:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    9e0c:	85 f6                	test   %esi,%esi
    9e0e:	0f 84 fc 07 00 00    	je     a610 <fwp_write+0xb80>
    9e14:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9e1b:	00 
    9e1c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9e23:	00 00 
    9e25:	0f 85 3a 01 00 00    	jne    9f65 <fwp_write+0x4d5>
    9e2b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    9e2f:	4c 89 ea             	mov    %r13,%rdx
    9e32:	e9 6c fe ff ff       	jmp    9ca3 <fwp_write+0x213>
    9e37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9e3e:	00 00 
    9e40:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    9e45:	ba 01 00 00 00       	mov    $0x1,%edx
    9e4a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    9e4f:	48 89 ee             	mov    %rbp,%rsi
    9e52:	e8 19 a2 ff ff       	call   4070 <buf_put>
    9e57:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    9e5c:	4c 89 e7             	mov    %r12,%rdi
    9e5f:	e8 ec 95 ff ff       	call   3450 <strlen@plt>
    9e64:	4c 89 e6             	mov    %r12,%rsi
    9e67:	48 89 df             	mov    %rbx,%rdi
    9e6a:	48 89 c2             	mov    %rax,%rdx
    9e6d:	e8 fe a1 ff ff       	call   4070 <buf_put>
    9e72:	ba 01 00 00 00       	mov    $0x1,%edx
    9e77:	48 89 ee             	mov    %rbp,%rsi
    9e7a:	48 89 df             	mov    %rbx,%rdi
    9e7d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9e82:	e8 e9 a1 ff ff       	call   4070 <buf_put>
    9e87:	e9 9a fc ff ff       	jmp    9b26 <fwp_write+0x96>
    9e8c:	0f 1f 40 00          	nopl   0x0(%rax)
    9e90:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    9e95:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    9e99:	0f 8a 8e 0b 00 00    	jp     aa2d <fwp_write+0xf9d>
    9e9f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9ea3:	66 0f 54 05 75 3c 00 	andpd  0x3c75(%rip),%xmm0        # db20 <msg.8+0xa0>
    9eaa:	00 
    9eab:	bd 01 00 00 00       	mov    $0x1,%ebp
    9eb0:	66 0f 2e 05 a8 3c 00 	ucomisd 0x3ca8(%rip),%xmm0        # db60 <msg.8+0xe0>
    9eb7:	00 
    9eb8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9ebf:	00 
    9ec0:	0f 87 b2 09 00 00    	ja     a878 <fwp_write+0xde8>
    9ec6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9ecd:	00 00 00 
    9ed0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9ed4:	89 ee                	mov    %ebp,%esi
    9ed6:	4c 89 e7             	mov    %r12,%rdi
    9ed9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    9ede:	e8 dd a5 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9ee3:	31 f6                	xor    %esi,%esi
    9ee5:	4c 89 e7             	mov    %r12,%rdi
    9ee8:	e8 23 95 ff ff       	call   3410 <strtod@plt>
    9eed:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    9ef2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    9ef6:	7a 06                	jp     9efe <fwp_write+0x46e>
    9ef8:	0f 84 e9 01 00 00    	je     a0e7 <fwp_write+0x657>
    9efe:	83 c5 01             	add    $0x1,%ebp
    9f01:	83 fd 12             	cmp    $0x12,%ebp
    9f04:	75 ca                	jne    9ed0 <fwp_write+0x440>
    9f06:	be 11 00 00 00       	mov    $0x11,%esi
    9f0b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9f0f:	4c 89 e7             	mov    %r12,%rdi
    9f12:	e8 a9 a5 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9f17:	e9 cb 01 00 00       	jmp    a0e7 <fwp_write+0x657>
    9f1c:	0f 1f 40 00          	nopl   0x0(%rax)
    9f20:	48 83 fd 01          	cmp    $0x1,%rbp
    9f24:	0f 84 e6 08 00 00    	je     a810 <fwp_write+0xd80>
    9f2a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    9f2e:	b8 02 00 00 00       	mov    $0x2,%eax
    9f33:	ba 01 00 00 00       	mov    $0x1,%edx
    9f38:	48 0f 44 d0          	cmove  %rax,%rdx
    9f3c:	48 8d 35 27 32 00 00 	lea    0x3227(%rip),%rsi        # d16a <_IO_stdin_used+0x16a>
    9f43:	48 8d 05 25 32 00 00 	lea    0x3225(%rip),%rax        # d16f <_IO_stdin_used+0x16f>
    9f4a:	48 0f 44 f0          	cmove  %rax,%rsi
    9f4e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9f55:	00 
    9f56:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9f5d:	00 00 
    9f5f:	0f 84 3e fd ff ff    	je     9ca3 <fwp_write+0x213>
    9f65:	e8 f6 94 ff ff       	call   3460 <__stack_chk_fail@plt>
    9f6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9f70:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    9f75:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    9f7a:	e8 31 a0 ff ff       	call   3fb0 <buf_grow>
    9f7f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    9f83:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    9f89:	4c 03 0b             	add    (%rbx),%r9
    9f8c:	66 45 89 11          	mov    %r10w,(%r9)
    9f90:	45 85 e4             	test   %r12d,%r12d
    9f93:	0f 8e 07 05 00 00    	jle    a4a0 <fwp_write+0xa10>
    9f99:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    9fa0:	55 55 55 
    9fa3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    9fa8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    9faf:	aa aa aa 
    9fb2:	49 83 c1 01          	add    $0x1,%r9
    9fb6:	eb 45                	jmp    9ffd <fwp_write+0x56d>
    9fb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9fbf:	00 
    9fc0:	be 01 00 00 00       	mov    $0x1,%esi
    9fc5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    9fca:	88 07                	mov    %al,(%rdi)
    9fcc:	48 89 e8             	mov    %rbp,%rax
    9fcf:	49 f7 e8             	imul   %r8
    9fd2:	48 89 e8             	mov    %rbp,%rax
    9fd5:	48 c1 f8 3f          	sar    $0x3f,%rax
    9fd9:	48 29 c2             	sub    %rax,%rdx
    9fdc:	48 85 c9             	test   %rcx,%rcx
    9fdf:	0f 95 c0             	setne  %al
    9fe2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    9fe6:	48 83 ef 01          	sub    $0x1,%rdi
    9fea:	48 21 c5             	and    %rax,%rbp
    9fed:	48 29 ea             	sub    %rbp,%rdx
    9ff0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    9ff4:	49 39 f9             	cmp    %rdi,%r9
    9ff7:	0f 84 a3 04 00 00    	je     a4a0 <fwp_write+0xa10>
    9ffd:	48 89 e8             	mov    %rbp,%rax
    a000:	49 f7 e8             	imul   %r8
    a003:	48 89 e8             	mov    %rbp,%rax
    a006:	48 c1 f8 3f          	sar    $0x3f,%rax
    a00a:	48 89 d1             	mov    %rdx,%rcx
    a00d:	48 29 c1             	sub    %rax,%rcx
    a010:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a014:	48 89 e9             	mov    %rbp,%rcx
    a017:	48 29 c1             	sub    %rax,%rcx
    a01a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a01e:	49 f7 e2             	mul    %r10
    a021:	b8 30 00 00 00       	mov    $0x30,%eax
    a026:	48 89 d6             	mov    %rdx,%rsi
    a029:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a02d:	48 d1 ee             	shr    $1,%rsi
    a030:	48 01 f2             	add    %rsi,%rdx
    a033:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a037:	48 29 d6             	sub    %rdx,%rsi
    a03a:	74 8e                	je     9fca <fwp_write+0x53a>
    a03c:	48 83 fe 01          	cmp    $0x1,%rsi
    a040:	0f 85 7a ff ff ff    	jne    9fc0 <fwp_write+0x530>
    a046:	31 f6                	xor    %esi,%esi
    a048:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a04d:	e9 78 ff ff ff       	jmp    9fca <fwp_write+0x53a>
    a052:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a058:	66 0f 6e cd          	movd   %ebp,%xmm1
    a05c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a05f:	0f 8a c8 09 00 00    	jp     aa2d <fwp_write+0xf9d>
    a065:	0f 28 c1             	movaps %xmm1,%xmm0
    a068:	0f 54 05 a1 3a 00 00 	andps  0x3aa1(%rip),%xmm0        # db10 <msg.8+0x90>
    a06f:	0f 2e 05 8e 2f 00 00 	ucomiss 0x2f8e(%rip),%xmm0        # d004 <_IO_stdin_used+0x4>
    a076:	0f 87 24 08 00 00    	ja     a8a0 <fwp_write+0xe10>
    a07c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a080:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a086:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a08d:	00 
    a08e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a092:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a097:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a09e:	00 00 
    a0a0:	44 89 ee             	mov    %r13d,%esi
    a0a3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a0a8:	4c 89 e7             	mov    %r12,%rdi
    a0ab:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a0b0:	e8 0b a4 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    a0b5:	31 f6                	xor    %esi,%esi
    a0b7:	4c 89 e7             	mov    %r12,%rdi
    a0ba:	e8 f1 93 ff ff       	call   34b0 <strtof@plt>
    a0bf:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a0c4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a0c7:	7a 02                	jp     a0cb <fwp_write+0x63b>
    a0c9:	74 1c                	je     a0e7 <fwp_write+0x657>
    a0cb:	41 83 c5 01          	add    $0x1,%r13d
    a0cf:	41 83 fd 0a          	cmp    $0xa,%r13d
    a0d3:	75 cb                	jne    a0a0 <fwp_write+0x610>
    a0d5:	be 09 00 00 00       	mov    $0x9,%esi
    a0da:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a0df:	4c 89 e7             	mov    %r12,%rdi
    a0e2:	e8 d9 a3 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    a0e7:	4c 89 e7             	mov    %r12,%rdi
    a0ea:	e8 41 a0 ff ff       	call   4130 <fwp_finish_float>
    a0ef:	e9 1c fa ff ff       	jmp    9b10 <fwp_write+0x80>
    a0f4:	0f 1f 40 00          	nopl   0x0(%rax)
    a0f8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a0fc:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a100:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a107:	00 
    a108:	48 89 ef             	mov    %rbp,%rdi
    a10b:	e8 30 99 ff ff       	call   3a40 <fwp_fmt_u128>
    a110:	48 89 ef             	mov    %rbp,%rdi
    a113:	e8 38 93 ff ff       	call   3450 <strlen@plt>
    a118:	48 89 ee             	mov    %rbp,%rsi
    a11b:	48 89 df             	mov    %rbx,%rdi
    a11e:	48 89 c2             	mov    %rax,%rdx
    a121:	e8 4a 9f ff ff       	call   4070 <buf_put>
    a126:	e9 fb f9 ff ff       	jmp    9b26 <fwp_write+0x96>
    a12b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a130:	ba 06 00 00 00       	mov    $0x6,%edx
    a135:	48 8d 35 88 30 00 00 	lea    0x3088(%rip),%rsi        # d1c4 <_IO_stdin_used+0x1c4>
    a13c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a142:	e8 29 9f ff ff       	call   4070 <buf_put>
    a147:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a14e:	ff ff 7f 
    a151:	48 23 55 00          	and    0x0(%rbp),%rdx
    a155:	0f 84 86 02 00 00    	je     a3e1 <fwp_write+0x951>
    a15b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a160:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a164:	48 85 d2             	test   %rdx,%rdx
    a167:	0f 84 ae 00 00 00    	je     a21b <fwp_write+0x78b>
    a16d:	8b 0a                	mov    (%rdx),%ecx
    a16f:	83 f9 1c             	cmp    $0x1c,%ecx
    a172:	0f 84 58 06 00 00    	je     a7d0 <fwp_write+0xd40>
    a178:	83 f9 1b             	cmp    $0x1b,%ecx
    a17b:	0f 87 9a 00 00 00    	ja     a21b <fwp_write+0x78b>
    a181:	be 01 00 00 00       	mov    $0x1,%esi
    a186:	48 d3 e6             	shl    %cl,%rsi
    a189:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a18f:	0f 85 4b 04 00 00    	jne    a5e0 <fwp_write+0xb50>
    a195:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a19b:	0f 85 0f 04 00 00    	jne    a5b0 <fwp_write+0xb20>
    a1a1:	83 e6 21             	and    $0x21,%esi
    a1a4:	74 75                	je     a21b <fwp_write+0x78b>
    a1a6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a1ab:	48 85 ff             	test   %rdi,%rdi
    a1ae:	79 07                	jns    a1b7 <fwp_write+0x727>
    a1b0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a1b4:	4c 01 ee             	add    %r13,%rsi
    a1b7:	48 0f be 3e          	movsbq (%rsi),%rdi
    a1bb:	85 c9                	test   %ecx,%ecx
    a1bd:	40 0f b6 f7          	movzbl %dil,%esi
    a1c1:	48 0f 44 f7          	cmove  %rdi,%rsi
    a1c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a1cc:	00 00 00 00 
    a1d0:	31 c9                	xor    %ecx,%ecx
    a1d2:	48 89 df             	mov    %rbx,%rdi
    a1d5:	49 83 c5 01          	add    $0x1,%r13
    a1d9:	e8 b2 f8 ff ff       	call   9a90 <fwp_write>
    a1de:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a1e5:	ff ff 7f 
    a1e8:	48 23 55 00          	and    0x0(%rbp),%rdx
    a1ec:	49 39 d5             	cmp    %rdx,%r13
    a1ef:	0f 83 ec 01 00 00    	jae    a3e1 <fwp_write+0x951>
    a1f5:	ba 02 00 00 00       	mov    $0x2,%edx
    a1fa:	48 89 df             	mov    %rbx,%rdi
    a1fd:	48 8d 35 bd 2f 00 00 	lea    0x2fbd(%rip),%rsi        # d1c1 <_IO_stdin_used+0x1c1>
    a204:	e8 67 9e ff ff       	call   4070 <buf_put>
    a209:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a20e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a212:	48 85 d2             	test   %rdx,%rdx
    a215:	0f 85 52 ff ff ff    	jne    a16d <fwp_write+0x6dd>
    a21b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a220:	48 85 ff             	test   %rdi,%rdi
    a223:	0f 88 cf 05 00 00    	js     a7f8 <fwp_write+0xd68>
    a229:	48 8b 31             	mov    (%rcx),%rsi
    a22c:	eb a2                	jmp    a1d0 <fwp_write+0x740>
    a22e:	66 90                	xchg   %ax,%ax
    a230:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a237:	00 
    a238:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a23f:	00 00 
    a241:	0f 85 1e fd ff ff    	jne    9f65 <fwp_write+0x4d5>
    a247:	ba 08 00 00 00       	mov    $0x8,%edx
    a24c:	48 8d 35 3e 2f 00 00 	lea    0x2f3e(%rip),%rsi        # d191 <_IO_stdin_used+0x191>
    a253:	e9 4b fa ff ff       	jmp    9ca3 <fwp_write+0x213>
    a258:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a25f:	00 
    a260:	89 e8                	mov    %ebp,%eax
    a262:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a269:	76 03                	jbe    a26e <fwp_write+0x7de>
    a26b:	8b 45 00             	mov    0x0(%rbp),%eax
    a26e:	41 89 c6             	mov    %eax,%r14d
    a271:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a276:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a27b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a27f:	4c 89 ef             	mov    %r13,%rdi
    a282:	e8 c9 91 ff ff       	call   3450 <strlen@plt>
    a287:	4c 89 ee             	mov    %r13,%rsi
    a28a:	48 89 df             	mov    %rbx,%rdi
    a28d:	48 89 c2             	mov    %rax,%rdx
    a290:	e8 db 9d ff ff       	call   4070 <buf_put>
    a295:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a29a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a29e:	85 f6                	test   %esi,%esi
    a2a0:	0f 8e 80 f8 ff ff    	jle    9b26 <fwp_write+0x96>
    a2a6:	45 31 ed             	xor    %r13d,%r13d
    a2a9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a2ae:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a2b3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a2b8:	ba 01 00 00 00       	mov    $0x1,%edx
    a2bd:	4c 89 fe             	mov    %r15,%rsi
    a2c0:	48 89 04 24          	mov    %rax,(%rsp)
    a2c4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a2c9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a2cd:	48 89 df             	mov    %rbx,%rdi
    a2d0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a2d4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a2d9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a2de:	e8 8d 9d ff ff       	call   4070 <buf_put>
    a2e3:	41 8b 06             	mov    (%r14),%eax
    a2e6:	83 f8 0e             	cmp    $0xe,%eax
    a2e9:	0f 84 71 02 00 00    	je     a560 <fwp_write+0xad0>
    a2ef:	83 f8 10             	cmp    $0x10,%eax
    a2f2:	0f 84 38 02 00 00    	je     a530 <fwp_write+0xaa0>
    a2f8:	83 f8 0a             	cmp    $0xa,%eax
    a2fb:	0f 84 7f 04 00 00    	je     a780 <fwp_write+0xcf0>
    a301:	0f 8f f9 00 00 00    	jg     a400 <fwp_write+0x970>
    a307:	83 f8 03             	cmp    $0x3,%eax
    a30a:	0f 8f 50 04 00 00    	jg     a760 <fwp_write+0xcd0>
    a310:	85 c0                	test   %eax,%eax
    a312:	78 10                	js     a324 <fwp_write+0x894>
    a314:	48 8b 04 24          	mov    (%rsp),%rax
    a318:	48 c1 e8 3f          	shr    $0x3f,%rax
    a31c:	85 c0                	test   %eax,%eax
    a31e:	0f 85 f9 00 00 00    	jne    a41d <fwp_write+0x98d>
    a324:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a329:	48 8b 34 24          	mov    (%rsp),%rsi
    a32d:	31 c9                	xor    %ecx,%ecx
    a32f:	48 89 df             	mov    %rbx,%rdi
    a332:	e8 59 f7 ff ff       	call   9a90 <fwp_write>
    a337:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a33c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a341:	49 83 c5 01          	add    $0x1,%r13
    a345:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a349:	0f 8f 5f ff ff ff    	jg     a2ae <fwp_write+0x81e>
    a34f:	e9 d2 f7 ff ff       	jmp    9b26 <fwp_write+0x96>
    a354:	0f 1f 40 00          	nopl   0x0(%rax)
    a358:	ba 06 00 00 00       	mov    $0x6,%edx
    a35d:	48 8d 35 53 2e 00 00 	lea    0x2e53(%rip),%rsi        # d1b7 <_IO_stdin_used+0x1b7>
    a364:	45 31 ed             	xor    %r13d,%r13d
    a367:	e8 04 9d ff ff       	call   4070 <buf_put>
    a36c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a371:	75 19                	jne    a38c <fwp_write+0x8fc>
    a373:	eb 6c                	jmp    a3e1 <fwp_write+0x951>
    a375:	0f 1f 00             	nopl   (%rax)
    a378:	ba 02 00 00 00       	mov    $0x2,%edx
    a37d:	48 8d 35 3d 2e 00 00 	lea    0x2e3d(%rip),%rsi        # d1c1 <_IO_stdin_used+0x1c1>
    a384:	48 89 df             	mov    %rbx,%rdi
    a387:	e8 e4 9c ff ff       	call   4070 <buf_put>
    a38c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a392:	b9 00 02 00 00       	mov    $0x200,%ecx
    a397:	31 c0                	xor    %eax,%eax
    a399:	49 83 c5 01          	add    $0x1,%r13
    a39d:	4c 8d 05 1a 2e 00 00 	lea    0x2e1a(%rip),%r8        # d1be <_IO_stdin_used+0x1be>
    a3a4:	ba 02 00 00 00       	mov    $0x2,%edx
    a3a9:	be 00 02 00 00       	mov    $0x200,%esi
    a3ae:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a3b5:	00 
    a3b6:	e8 f5 8f ff ff       	call   33b0 <__snprintf_chk@plt>
    a3bb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a3c2:	00 
    a3c3:	e8 88 90 ff ff       	call   3450 <strlen@plt>
    a3c8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a3cf:	00 
    a3d0:	48 89 df             	mov    %rbx,%rdi
    a3d3:	48 89 c2             	mov    %rax,%rdx
    a3d6:	e8 95 9c ff ff       	call   4070 <buf_put>
    a3db:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a3df:	72 97                	jb     a378 <fwp_write+0x8e8>
    a3e1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a3e6:	ba 01 00 00 00       	mov    $0x1,%edx
    a3eb:	48 89 df             	mov    %rbx,%rdi
    a3ee:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a3f3:	e8 78 9c ff ff       	call   4070 <buf_put>
    a3f8:	e9 29 f7 ff ff       	jmp    9b26 <fwp_write+0x96>
    a3fd:	0f 1f 00             	nopl   (%rax)
    a400:	83 f8 0b             	cmp    $0xb,%eax
    a403:	0f 85 1b ff ff ff    	jne    a324 <fwp_write+0x894>
    a409:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a40e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a412:	83 e0 01             	and    $0x1,%eax
    a415:	85 c0                	test   %eax,%eax
    a417:	0f 84 07 ff ff ff    	je     a324 <fwp_write+0x894>
    a41d:	4c 89 fe             	mov    %r15,%rsi
    a420:	48 89 df             	mov    %rbx,%rdi
    a423:	ba 01 00 00 00       	mov    $0x1,%edx
    a428:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a42d:	e8 3e 9c ff ff       	call   4070 <buf_put>
    a432:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a437:	48 8b 34 24          	mov    (%rsp),%rsi
    a43b:	31 c9                	xor    %ecx,%ecx
    a43d:	48 89 df             	mov    %rbx,%rdi
    a440:	e8 4b f6 ff ff       	call   9a90 <fwp_write>
    a445:	ba 01 00 00 00       	mov    $0x1,%edx
    a44a:	4c 89 fe             	mov    %r15,%rsi
    a44d:	48 89 df             	mov    %rbx,%rdi
    a450:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a455:	e8 16 9c ff ff       	call   4070 <buf_put>
    a45a:	e9 d8 fe ff ff       	jmp    a337 <fwp_write+0x8a7>
    a45f:	90                   	nop
    a460:	ba 01 00 00 00       	mov    $0x1,%edx
    a465:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a46a:	48 89 df             	mov    %rbx,%rdi
    a46d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a472:	e8 f9 9b ff ff       	call   4070 <buf_put>
    a477:	e9 aa f6 ff ff       	jmp    9b26 <fwp_write+0x96>
    a47c:	0f 1f 40 00          	nopl   0x0(%rax)
    a480:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a485:	ba 01 00 00 00       	mov    $0x1,%edx
    a48a:	48 89 df             	mov    %rbx,%rdi
    a48d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a492:	e8 d9 9b ff ff       	call   4070 <buf_put>
    a497:	e9 8a f6 ff ff       	jmp    9b26 <fwp_write+0x96>
    a49c:	0f 1f 40 00          	nopl   0x0(%rax)
    a4a0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a4a4:	48 8b 13             	mov    (%rbx),%rdx
    a4a7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a4ac:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a4b0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a4b4:	e9 6d f6 ff ff       	jmp    9b26 <fwp_write+0x96>
    a4b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a4c0:	ba 02 00 00 00       	mov    $0x2,%edx
    a4c5:	48 8d 35 f5 2c 00 00 	lea    0x2cf5(%rip),%rsi        # d1c1 <_IO_stdin_used+0x1c1>
    a4cc:	48 89 df             	mov    %rbx,%rdi
    a4cf:	e8 9c 9b ff ff       	call   4070 <buf_put>
    a4d4:	e9 72 f8 ff ff       	jmp    9d4b <fwp_write+0x2bb>
    a4d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a4e0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a4e5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a4ea:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a4ee:	48 89 f7             	mov    %rsi,%rdi
    a4f1:	48 89 34 24          	mov    %rsi,(%rsp)
    a4f5:	e8 56 8f ff ff       	call   3450 <strlen@plt>
    a4fa:	48 8b 34 24          	mov    (%rsp),%rsi
    a4fe:	48 89 df             	mov    %rbx,%rdi
    a501:	48 89 c2             	mov    %rax,%rdx
    a504:	e8 67 9b ff ff       	call   4070 <buf_put>
    a509:	ba 03 00 00 00       	mov    $0x3,%edx
    a50e:	48 8d 35 cf 2c 00 00 	lea    0x2ccf(%rip),%rsi        # d1e4 <_IO_stdin_used+0x1e4>
    a515:	48 89 df             	mov    %rbx,%rdi
    a518:	e8 53 9b ff ff       	call   4070 <buf_put>
    a51d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a522:	e9 35 f8 ff ff       	jmp    9d5c <fwp_write+0x2cc>
    a527:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a52e:	00 00 
    a530:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a535:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a539:	48 85 ff             	test   %rdi,%rdi
    a53c:	0f 84 e2 fd ff ff    	je     a324 <fwp_write+0x894>
    a542:	48 8d 35 85 2c 00 00 	lea    0x2c85(%rip),%rsi        # d1ce <_IO_stdin_used+0x1ce>
    a549:	e8 e2 8f ff ff       	call   3530 <strcmp@plt>
    a54e:	85 c0                	test   %eax,%eax
    a550:	0f 95 c0             	setne  %al
    a553:	0f b6 c0             	movzbl %al,%eax
    a556:	e9 c1 fd ff ff       	jmp    a31c <fwp_write+0x88c>
    a55b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a560:	31 c0                	xor    %eax,%eax
    a562:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a569:	00 
    a56a:	0f 97 c0             	seta   %al
    a56d:	e9 aa fd ff ff       	jmp    a31c <fwp_write+0x88c>
    a572:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a578:	48 89 df             	mov    %rbx,%rdi
    a57b:	ba 02 00 00 00       	mov    $0x2,%edx
    a580:	48 8d 35 44 2c 00 00 	lea    0x2c44(%rip),%rsi        # d1cb <_IO_stdin_used+0x1cb>
    a587:	e8 e4 9a ff ff       	call   4070 <buf_put>
    a58c:	4c 89 e8             	mov    %r13,%rax
    a58f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a594:	31 c9                	xor    %ecx,%ecx
    a596:	48 c1 e0 04          	shl    $0x4,%rax
    a59a:	48 89 df             	mov    %rbx,%rdi
    a59d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a5a2:	e8 e9 f4 ff ff       	call   9a90 <fwp_write>
    a5a7:	e9 5e f6 ff ff       	jmp    9c0a <fwp_write+0x17a>
    a5ac:	0f 1f 40 00          	nopl   0x0(%rax)
    a5b0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a5b5:	48 85 ff             	test   %rdi,%rdi
    a5b8:	79 0c                	jns    a5c6 <fwp_write+0xb36>
    a5ba:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a5c1:	00 
    a5c2:	48 03 75 10          	add    0x10(%rbp),%rsi
    a5c6:	48 63 3e             	movslq (%rsi),%rdi
    a5c9:	83 f9 02             	cmp    $0x2,%ecx
    a5cc:	89 fe                	mov    %edi,%esi
    a5ce:	48 0f 44 f7          	cmove  %rdi,%rsi
    a5d2:	e9 f9 fb ff ff       	jmp    a1d0 <fwp_write+0x740>
    a5d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a5de:	00 00 
    a5e0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a5e5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a5ea:	48 85 ff             	test   %rdi,%rdi
    a5ed:	0f 88 0f 03 00 00    	js     a902 <fwp_write+0xe72>
    a5f3:	49 0f bf 38          	movswq (%r8),%rdi
    a5f7:	83 f9 01             	cmp    $0x1,%ecx
    a5fa:	0f b7 f7             	movzwl %di,%esi
    a5fd:	48 0f 44 f7          	cmove  %rdi,%rsi
    a601:	e9 ca fb ff ff       	jmp    a1d0 <fwp_write+0x740>
    a606:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a60d:	00 00 00 
    a610:	ba 01 00 00 00       	mov    $0x1,%edx
    a615:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a61a:	48 83 c5 08          	add    $0x8,%rbp
    a61e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a623:	e8 48 9a ff ff       	call   4070 <buf_put>
    a628:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a62d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a632:	4d 85 ed             	test   %r13,%r13
    a635:	75 46                	jne    a67d <fwp_write+0xbed>
    a637:	e9 04 01 00 00       	jmp    a740 <fwp_write+0xcb0>
    a63c:	0f 1f 40 00          	nopl   0x0(%rax)
    a640:	41 80 f9 09          	cmp    $0x9,%r9b
    a644:	0f 84 d6 00 00 00    	je     a720 <fwp_write+0xc90>
    a64a:	41 80 f9 0a          	cmp    $0xa,%r9b
    a64e:	0f 85 9c 00 00 00    	jne    a6f0 <fwp_write+0xc60>
    a654:	ba 02 00 00 00       	mov    $0x2,%edx
    a659:	48 8d 35 47 2b 00 00 	lea    0x2b47(%rip),%rsi        # d1a7 <_IO_stdin_used+0x1a7>
    a660:	48 89 df             	mov    %rbx,%rdi
    a663:	e8 08 9a ff ff       	call   4070 <buf_put>
    a668:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a66f:	00 
    a670:	48 83 c5 01          	add    $0x1,%rbp
    a674:	49 39 ec             	cmp    %rbp,%r12
    a677:	0f 84 c3 00 00 00    	je     a740 <fwp_write+0xcb0>
    a67d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a682:	41 80 f9 0d          	cmp    $0xd,%r9b
    a686:	74 28                	je     a6b0 <fwp_write+0xc20>
    a688:	7e b6                	jle    a640 <fwp_write+0xbb0>
    a68a:	41 80 f9 22          	cmp    $0x22,%r9b
    a68e:	74 40                	je     a6d0 <fwp_write+0xc40>
    a690:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a694:	75 5a                	jne    a6f0 <fwp_write+0xc60>
    a696:	ba 02 00 00 00       	mov    $0x2,%edx
    a69b:	48 8d 35 02 2b 00 00 	lea    0x2b02(%rip),%rsi        # d1a4 <_IO_stdin_used+0x1a4>
    a6a2:	48 89 df             	mov    %rbx,%rdi
    a6a5:	e8 c6 99 ff ff       	call   4070 <buf_put>
    a6aa:	eb c4                	jmp    a670 <fwp_write+0xbe0>
    a6ac:	0f 1f 40 00          	nopl   0x0(%rax)
    a6b0:	ba 02 00 00 00       	mov    $0x2,%edx
    a6b5:	48 8d 35 f1 2a 00 00 	lea    0x2af1(%rip),%rsi        # d1ad <_IO_stdin_used+0x1ad>
    a6bc:	48 89 df             	mov    %rbx,%rdi
    a6bf:	e8 ac 99 ff ff       	call   4070 <buf_put>
    a6c4:	eb aa                	jmp    a670 <fwp_write+0xbe0>
    a6c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a6cd:	00 00 00 
    a6d0:	ba 02 00 00 00       	mov    $0x2,%edx
    a6d5:	48 8d 35 c5 2a 00 00 	lea    0x2ac5(%rip),%rsi        # d1a1 <_IO_stdin_used+0x1a1>
    a6dc:	48 89 df             	mov    %rbx,%rdi
    a6df:	e8 8c 99 ff ff       	call   4070 <buf_put>
    a6e4:	eb 8a                	jmp    a670 <fwp_write+0xbe0>
    a6e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a6ed:	00 00 00 
    a6f0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a6f4:	0f 86 2e 01 00 00    	jbe    a828 <fwp_write+0xd98>
    a6fa:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a6fe:	0f 84 24 01 00 00    	je     a828 <fwp_write+0xd98>
    a704:	ba 01 00 00 00       	mov    $0x1,%edx
    a709:	4c 89 fe             	mov    %r15,%rsi
    a70c:	48 89 df             	mov    %rbx,%rdi
    a70f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a714:	e8 57 99 ff ff       	call   4070 <buf_put>
    a719:	e9 52 ff ff ff       	jmp    a670 <fwp_write+0xbe0>
    a71e:	66 90                	xchg   %ax,%ax
    a720:	ba 02 00 00 00       	mov    $0x2,%edx
    a725:	48 8d 35 7e 2a 00 00 	lea    0x2a7e(%rip),%rsi        # d1aa <_IO_stdin_used+0x1aa>
    a72c:	48 89 df             	mov    %rbx,%rdi
    a72f:	e8 3c 99 ff ff       	call   4070 <buf_put>
    a734:	e9 37 ff ff ff       	jmp    a670 <fwp_write+0xbe0>
    a739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a740:	ba 01 00 00 00       	mov    $0x1,%edx
    a745:	4c 89 fe             	mov    %r15,%rsi
    a748:	48 89 df             	mov    %rbx,%rdi
    a74b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a750:	e8 1b 99 ff ff       	call   4070 <buf_put>
    a755:	e9 cc f3 ff ff       	jmp    9b26 <fwp_write+0x96>
    a75a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a760:	83 f8 04             	cmp    $0x4,%eax
    a763:	0f 85 bb fb ff ff    	jne    a324 <fwp_write+0x894>
    a769:	48 8b 04 24          	mov    (%rsp),%rax
    a76d:	48 8b 40 08          	mov    0x8(%rax),%rax
    a771:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    a776:	48 c1 e8 3f          	shr    $0x3f,%rax
    a77a:	e9 96 fc ff ff       	jmp    a415 <fwp_write+0x985>
    a77f:	90                   	nop
    a780:	8b 0c 24             	mov    (%rsp),%ecx
    a783:	31 c0                	xor    %eax,%eax
    a785:	85 c9                	test   %ecx,%ecx
    a787:	0f 98 c0             	sets   %al
    a78a:	e9 86 fc ff ff       	jmp    a415 <fwp_write+0x985>
    a78f:	90                   	nop
    a790:	48 f7 d8             	neg    %rax
    a793:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    a79a:	00 
    a79b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    a7a2:	2d 
    a7a3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a7aa:	00 
    a7ab:	48 83 d2 00          	adc    $0x0,%rdx
    a7af:	48 89 c6             	mov    %rax,%rsi
    a7b2:	48 f7 da             	neg    %rdx
    a7b5:	e8 86 92 ff ff       	call   3a40 <fwp_fmt_u128>
    a7ba:	e9 51 f3 ff ff       	jmp    9b10 <fwp_write+0x80>
    a7bf:	90                   	nop
    a7c0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    a7c5:	e9 c3 f5 ff ff       	jmp    9d8d <fwp_write+0x2fd>
    a7ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a7d0:	4c 89 e9             	mov    %r13,%rcx
    a7d3:	48 c1 e1 04          	shl    $0x4,%rcx
    a7d7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    a7dc:	48 85 ff             	test   %rdi,%rdi
    a7df:	0f 89 eb f9 ff ff    	jns    a1d0 <fwp_write+0x740>
    a7e5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a7e9:	48 89 ce             	mov    %rcx,%rsi
    a7ec:	e9 df f9 ff ff       	jmp    a1d0 <fwp_write+0x740>
    a7f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a7f8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a7ff:	00 
    a800:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a804:	e9 20 fa ff ff       	jmp    a229 <fwp_write+0x799>
    a809:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a810:	ba 02 00 00 00       	mov    $0x2,%edx
    a815:	48 8d 35 50 29 00 00 	lea    0x2950(%rip),%rsi        # d16c <_IO_stdin_used+0x16c>
    a81c:	e9 2d f7 ff ff       	jmp    9f4e <fwp_write+0x4be>
    a821:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a828:	4c 8d 05 81 29 00 00 	lea    0x2981(%rip),%r8        # d1b0 <_IO_stdin_used+0x1b0>
    a82f:	b9 10 00 00 00       	mov    $0x10,%ecx
    a834:	31 c0                	xor    %eax,%eax
    a836:	ba 02 00 00 00       	mov    $0x2,%edx
    a83b:	be 10 00 00 00       	mov    $0x10,%esi
    a840:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a847:	00 
    a848:	e8 63 8b ff ff       	call   33b0 <__snprintf_chk@plt>
    a84d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a854:	00 
    a855:	e8 f6 8b ff ff       	call   3450 <strlen@plt>
    a85a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a861:	00 
    a862:	48 89 df             	mov    %rbx,%rdi
    a865:	48 89 c2             	mov    %rax,%rdx
    a868:	e8 03 98 ff ff       	call   4070 <buf_put>
    a86d:	e9 fe fd ff ff       	jmp    a670 <fwp_write+0xbe0>
    a872:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a878:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a87c:	48 8d 35 e3 28 00 00 	lea    0x28e3(%rip),%rsi        # d166 <_IO_stdin_used+0x166>
    a883:	48 8d 05 db 28 00 00 	lea    0x28db(%rip),%rax        # d165 <_IO_stdin_used+0x165>
    a88a:	4c 89 e7             	mov    %r12,%rdi
    a88d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    a891:	48 0f 46 f0          	cmovbe %rax,%rsi
    a895:	e8 56 8b ff ff       	call   33f0 <strcpy@plt>
    a89a:	e9 71 f2 ff ff       	jmp    9b10 <fwp_write+0x80>
    a89f:	90                   	nop
    a8a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a8a4:	48 8d 35 bb 28 00 00 	lea    0x28bb(%rip),%rsi        # d166 <_IO_stdin_used+0x166>
    a8ab:	48 8d 05 b3 28 00 00 	lea    0x28b3(%rip),%rax        # d165 <_IO_stdin_used+0x165>
    a8b2:	0f 2f c8             	comiss %xmm0,%xmm1
    a8b5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a8bc:	00 
    a8bd:	4c 89 e7             	mov    %r12,%rdi
    a8c0:	48 0f 46 f0          	cmovbe %rax,%rsi
    a8c4:	e8 27 8b ff ff       	call   33f0 <strcpy@plt>
    a8c9:	e9 42 f2 ff ff       	jmp    9b10 <fwp_write+0x80>
    a8ce:	66 90                	xchg   %ax,%ax
    a8d0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    a8d5:	45 85 c0             	test   %r8d,%r8d
    a8d8:	75 34                	jne    a90e <fwp_write+0xe7e>
    a8da:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a8e1:	00 
    a8e2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a8e9:	00 00 
    a8eb:	0f 85 74 f6 ff ff    	jne    9f65 <fwp_write+0x4d5>
    a8f1:	ba 02 00 00 00       	mov    $0x2,%edx
    a8f6:	48 8d 35 e4 28 00 00 	lea    0x28e4(%rip),%rsi        # d1e1 <_IO_stdin_used+0x1e1>
    a8fd:	e9 a1 f3 ff ff       	jmp    9ca3 <fwp_write+0x213>
    a902:	48 03 75 10          	add    0x10(%rbp),%rsi
    a906:	49 89 f0             	mov    %rsi,%r8
    a909:	e9 e5 fc ff ff       	jmp    a5f3 <fwp_write+0xb63>
    a90e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    a913:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a918:	85 ff                	test   %edi,%edi
    a91a:	0f 84 fa f3 ff ff    	je     9d1a <fwp_write+0x28a>
    a920:	ba 01 00 00 00       	mov    $0x1,%edx
    a925:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a92a:	48 89 df             	mov    %rbx,%rdi
    a92d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a932:	e8 39 97 ff ff       	call   4070 <buf_put>
    a937:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    a93c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a941:	41 be 01 00 00 00    	mov    $0x1,%r14d
    a947:	85 c0                	test   %eax,%eax
    a949:	0f 8f f0 f3 ff ff    	jg     9d3f <fwp_write+0x2af>
    a94f:	e9 34 f4 ff ff       	jmp    9d88 <fwp_write+0x2f8>
    a954:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a958:	49 89 c5             	mov    %rax,%r13
    a95b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a960:	49 89 c4             	mov    %rax,%r12
    a963:	49 c1 fd 3f          	sar    $0x3f,%r13
    a967:	4c 09 e8             	or     %r13,%rax
    a96a:	0f 84 a7 00 00 00    	je     aa17 <fwp_write+0xf87>
    a970:	48 8d 2d a9 4a 00 00 	lea    0x4aa9(%rip),%rbp        # f420 <units.5>
    a977:	4d 89 e7             	mov    %r12,%r15
    a97a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a97e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    a983:	4c 89 ff             	mov    %r15,%rdi
    a986:	4c 89 ee             	mov    %r13,%rsi
    a989:	44 89 0c 24          	mov    %r9d,(%rsp)
    a98d:	48 99                	cqto
    a98f:	48 89 d1             	mov    %rdx,%rcx
    a992:	48 89 c2             	mov    %rax,%rdx
    a995:	e8 36 19 00 00       	call   c2d0 <__divmodti4>
    a99a:	44 8b 0c 24          	mov    (%rsp),%r9d
    a99e:	48 89 c1             	mov    %rax,%rcx
    a9a1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a9a6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    a9ab:	0f 84 94 00 00 00    	je     aa45 <fwp_write+0xfb5>
    a9b1:	41 83 c1 01          	add    $0x1,%r9d
    a9b5:	48 83 c5 10          	add    $0x10,%rbp
    a9b9:	41 83 f9 05          	cmp    $0x5,%r9d
    a9bd:	75 bb                	jne    a97a <fwp_write+0xeea>
    a9bf:	4d 85 ed             	test   %r13,%r13
    a9c2:	79 53                	jns    aa17 <fwp_write+0xf87>
    a9c4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a9c9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a9ce:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a9d3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a9d8:	48 99                	cqto
    a9da:	48 f7 d8             	neg    %rax
    a9dd:	48 83 d2 00          	adc    $0x0,%rdx
    a9e1:	48 89 c6             	mov    %rax,%rsi
    a9e4:	48 f7 da             	neg    %rdx
    a9e7:	e8 54 90 ff ff       	call   3a40 <fwp_fmt_u128>
    a9ec:	49 89 e8             	mov    %rbp,%r8
    a9ef:	ba 00 02 00 00       	mov    $0x200,%edx
    a9f4:	be 02 00 00 00       	mov    $0x2,%esi
    a9f9:	31 c0                	xor    %eax,%eax
    a9fb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    aa02:	00 
    aa03:	48 8d 0d d2 27 00 00 	lea    0x27d2(%rip),%rcx        # d1dc <_IO_stdin_used+0x1dc>
    aa0a:	4c 89 e7             	mov    %r12,%rdi
    aa0d:	e8 ce 8c ff ff       	call   36e0 <__sprintf_chk@plt>
    aa12:	e9 f9 f0 ff ff       	jmp    9b10 <fwp_write+0x80>
    aa17:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    aa1c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    aa21:	31 d2                	xor    %edx,%edx
    aa23:	48 89 ef             	mov    %rbp,%rdi
    aa26:	e8 15 90 ff ff       	call   3a40 <fwp_fmt_u128>
    aa2b:	eb bf                	jmp    a9ec <fwp_write+0xf5c>
    aa2d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    aa34:	4e 61 4e 00 
    aa38:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    aa3f:	00 
    aa40:	e9 cb f0 ff ff       	jmp    9b10 <fwp_write+0x80>
    aa45:	44 89 0c 24          	mov    %r9d,(%rsp)
    aa49:	48 89 c8             	mov    %rcx,%rax
    aa4c:	48 85 d2             	test   %rdx,%rdx
    aa4f:	78 51                	js     aaa2 <fwp_write+0x1012>
    aa51:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    aa56:	48 89 c6             	mov    %rax,%rsi
    aa59:	48 89 ef             	mov    %rbp,%rdi
    aa5c:	e8 df 8f ff ff       	call   3a40 <fwp_fmt_u128>
    aa61:	44 8b 0c 24          	mov    (%rsp),%r9d
    aa65:	49 63 c1             	movslq %r9d,%rax
    aa68:	49 89 e8             	mov    %rbp,%r8
    aa6b:	ba 00 02 00 00       	mov    $0x200,%edx
    aa70:	be 02 00 00 00       	mov    $0x2,%esi
    aa75:	48 c1 e0 04          	shl    $0x4,%rax
    aa79:	48 8d 3d a0 49 00 00 	lea    0x49a0(%rip),%rdi        # f420 <units.5>
    aa80:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    aa87:	00 
    aa88:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    aa8c:	48 8d 0d 44 27 00 00 	lea    0x2744(%rip),%rcx        # d1d7 <_IO_stdin_used+0x1d7>
    aa93:	4c 89 e7             	mov    %r12,%rdi
    aa96:	31 c0                	xor    %eax,%eax
    aa98:	e8 43 8c ff ff       	call   36e0 <__sprintf_chk@plt>
    aa9d:	e9 6e f0 ff ff       	jmp    9b10 <fwp_write+0x80>
    aaa2:	48 f7 d8             	neg    %rax
    aaa5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    aaaa:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    aaaf:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    aab4:	48 83 d2 00          	adc    $0x0,%rdx
    aab8:	48 89 c6             	mov    %rax,%rsi
    aabb:	48 f7 da             	neg    %rdx
    aabe:	e8 7d 8f ff ff       	call   3a40 <fwp_fmt_u128>
    aac3:	44 8b 0c 24          	mov    (%rsp),%r9d
    aac7:	eb 9c                	jmp    aa65 <fwp_write+0xfd5>
    aac9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000aad0 <fwp_main_thread>:
    aad0:	f3 0f 1e fa          	endbr64
    aad4:	55                   	push   %rbp
    aad5:	48 89 e5             	mov    %rsp,%rbp
    aad8:	41 57                	push   %r15
    aada:	41 56                	push   %r14
    aadc:	41 55                	push   %r13
    aade:	41 54                	push   %r12
    aae0:	53                   	push   %rbx
    aae1:	48 81 ec 78 01 00 00 	sub    $0x178,%rsp
    aae8:	44 8b 05 55 80 01 00 	mov    0x18055(%rip),%r8d        # 22b44 <fwp_heap+0x13a4>
    aaef:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    aaf6:	00 00 
    aaf8:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    aafc:	31 c0                	xor    %eax,%eax
    aafe:	45 85 c0             	test   %r8d,%r8d
    ab01:	0f 84 09 06 00 00    	je     b110 <fwp_main_thread+0x640>
    ab07:	8b 3d 3b 80 01 00    	mov    0x1803b(%rip),%edi        # 22b48 <fwp_heap+0x13a8>
    ab0d:	85 ff                	test   %edi,%edi
    ab0f:	0f 85 0e 06 00 00    	jne    b123 <fwp_main_thread+0x653>
    ab15:	48 8d 05 a4 65 00 00 	lea    0x65a4(%rip),%rax        # 110c0 <alt.9>
    ab1c:	31 f6                	xor    %esi,%esi
    ab1e:	4c 8d a5 d0 fe ff ff 	lea    -0x130(%rbp),%r12
    ab25:	48 c7 05 08 66 01 00 	movq   $0x40000000,0x16608(%rip)        # 21138 <fwp_main_stack_size>
    ab2c:	00 00 00 40 
    ab30:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
    ab37:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
    ab3e:	48 89 c7             	mov    %rax,%rdi
    ab41:	4c 89 25 f8 65 01 00 	mov    %r12,0x165f8(%rip)        # 21140 <fwp_main_stack_top>
    ab48:	48 c7 85 00 ff ff ff 	movq   $0x10000,-0x100(%rbp)
    ab4f:	00 00 01 00 
    ab53:	c7 85 f8 fe ff ff 00 	movl   $0x0,-0x108(%rbp)
    ab5a:	00 00 00 
    ab5d:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
    ab64:	e8 57 8b ff ff       	call   36c0 <sigaltstack@plt>
    ab69:	85 c0                	test   %eax,%eax
    ab6b:	0f 85 b4 16 00 00    	jne    c225 <fwp_main_thread+0x1755>
    ab71:	31 db                	xor    %ebx,%ebx
    ab73:	b9 12 00 00 00       	mov    $0x12,%ecx
    ab78:	48 8d bd 38 ff ff ff 	lea    -0xc8(%rbp),%rdi
    ab7f:	48 89 d8             	mov    %rbx,%rax
    ab82:	4c 8d ad 30 ff ff ff 	lea    -0xd0(%rbp),%r13
    ab89:	f3 48 ab             	rep stos %rax,(%rdi)
    ab8c:	48 8d 05 5d 91 ff ff 	lea    -0x6ea3(%rip),%rax        # 3cf0 <fwp_segv>
    ab93:	48 8d bd 38 ff ff ff 	lea    -0xc8(%rbp),%rdi
    ab9a:	c7 45 b8 04 00 00 08 	movl   $0x8000004,-0x48(%rbp)
    aba1:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
    aba8:	e8 d3 89 ff ff       	call   3580 <sigemptyset@plt>
    abad:	85 c0                	test   %eax,%eax
    abaf:	0f 85 70 16 00 00    	jne    c225 <fwp_main_thread+0x1755>
    abb5:	31 d2                	xor    %edx,%edx
    abb7:	4c 89 ee             	mov    %r13,%rsi
    abba:	bf 0b 00 00 00       	mov    $0xb,%edi
    abbf:	e8 3c 88 ff ff       	call   3400 <sigaction@plt>
    abc4:	85 c0                	test   %eax,%eax
    abc6:	0f 85 59 16 00 00    	jne    c225 <fwp_main_thread+0x1755>
    abcc:	31 d2                	xor    %edx,%edx
    abce:	4c 89 ee             	mov    %r13,%rsi
    abd1:	bf 07 00 00 00       	mov    $0x7,%edi
    abd6:	e8 25 88 ff ff       	call   3400 <sigaction@plt>
    abdb:	85 c0                	test   %eax,%eax
    abdd:	0f 85 42 16 00 00    	jne    c225 <fwp_main_thread+0x1755>
    abe3:	8b 35 c7 64 00 00    	mov    0x64c7(%rip),%esi        # 110b0 <st.7>
    abe9:	85 f6                	test   %esi,%esi
    abeb:	0f 84 43 05 00 00    	je     b134 <fwp_main_thread+0x664>
    abf1:	4c 8b 25 88 6b 01 00 	mov    0x16b88(%rip),%r12        # 21780 <fwp_cur>
    abf8:	4d 85 e4             	test   %r12,%r12
    abfb:	0f 84 c5 01 00 00    	je     adc6 <fwp_main_thread+0x2f6>
    ac01:	45 0f b6 6c 24 52    	movzbl 0x52(%r12),%r13d
    ac07:	41 c6 44 24 52 01    	movb   $0x1,0x52(%r12)
    ac0d:	4c 89 e3             	mov    %r12,%rbx
    ac10:	49 83 7c 24 28 00    	cmpq   $0x0,0x28(%r12)
    ac16:	0f 84 48 01 00 00    	je     ad64 <fwp_main_thread+0x294>
    ac1c:	49 83 7c 24 60 00    	cmpq   $0x0,0x60(%r12)
    ac22:	0f 84 91 02 00 00    	je     aeb9 <fwp_main_thread+0x3e9>
    ac28:	41 80 7c 24 51 00    	cmpb   $0x0,0x51(%r12)
    ac2e:	0f 84 69 02 00 00    	je     ae9d <fwp_main_thread+0x3cd>
    ac34:	49 8d 54 24 40       	lea    0x40(%r12),%rdx
    ac39:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    ac3d:	0f 85 f7 02 00 00    	jne    af3a <fwp_main_thread+0x46a>
    ac43:	48 8b 43 60          	mov    0x60(%rbx),%rax
    ac47:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    ac4e:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    ac53:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ac5a:	00 00 00 00 
    ac5e:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    ac65:	48 85 d2             	test   %rdx,%rdx
    ac68:	74 07                	je     ac71 <fwp_main_thread+0x1a1>
    ac6a:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    ac71:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    ac76:	48 85 c0             	test   %rax,%rax
    ac79:	74 34                	je     acaf <fwp_main_thread+0x1df>
    ac7b:	48 89 43 68          	mov    %rax,0x68(%rbx)
    ac7f:	48 8b 05 d2 6a 01 00 	mov    0x16ad2(%rip),%rax        # 21758 <fwp_timers>
    ac86:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    ac8a:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    ac91:	00 00 00 00 
    ac95:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    ac9c:	48 85 c0             	test   %rax,%rax
    ac9f:	74 07                	je     aca8 <fwp_main_thread+0x1d8>
    aca1:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    aca8:	48 89 1d a9 6a 01 00 	mov    %rbx,0x16aa9(%rip)        # 21758 <fwp_timers>
    acaf:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    acb3:	e8 f8 c3 ff ff       	call   70b0 <fwp_block>
    acb8:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    acbf:	48 85 c9             	test   %rcx,%rcx
    acc2:	74 47                	je     ad0b <fwp_main_thread+0x23b>
    acc4:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    accb:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    acd2:	48 85 d2             	test   %rdx,%rdx
    acd5:	0f 84 57 02 00 00    	je     af32 <fwp_main_thread+0x462>
    acdb:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    ace2:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    ace9:	48 85 c0             	test   %rax,%rax
    acec:	74 07                	je     acf5 <fwp_main_thread+0x225>
    acee:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    acf5:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    acfc:	00 00 00 00 
    ad00:	66 0f ef d2          	pxor   %xmm2,%xmm2
    ad04:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    ad0b:	48 8b 0d 6e 6a 01 00 	mov    0x16a6e(%rip),%rcx        # 21780 <fwp_cur>
    ad12:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    ad16:	0f 84 0e 02 00 00    	je     af2a <fwp_main_thread+0x45a>
    ad1c:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    ad23:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    ad2a:	48 85 d2             	test   %rdx,%rdx
    ad2d:	0f 84 d1 03 00 00    	je     b104 <fwp_main_thread+0x634>
    ad33:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    ad3a:	48 85 c0             	test   %rax,%rax
    ad3d:	74 07                	je     ad46 <fwp_main_thread+0x276>
    ad3f:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    ad46:	66 0f ef db          	pxor   %xmm3,%xmm3
    ad4a:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    ad4e:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    ad55:	48 89 cb             	mov    %rcx,%rbx
    ad58:	49 83 7c 24 28 00    	cmpq   $0x0,0x28(%r12)
    ad5e:	0f 85 b8 fe ff ff    	jne    ac1c <fwp_main_thread+0x14c>
    ad64:	48 83 3d ac 86 01 00 	cmpq   $0x0,0x186ac(%rip)        # 23418 <fwp_state_len>
    ad6b:	00 
    ad6c:	45 88 6c 24 52       	mov    %r13b,0x52(%r12)
    ad71:	74 63                	je     add6 <fwp_main_thread+0x306>
    ad73:	48 39 1d fe 69 01 00 	cmp    %rbx,0x169fe(%rip)        # 21778 <fwp_root>
    ad7a:	c7 05 3c 63 01 00 00 	movl   $0x0,0x1633c(%rip)        # 210c0 <fwp_exit_code>
    ad81:	00 00 00 
    ad84:	0f 85 40 15 00 00    	jne    c2ca <fwp_main_thread+0x17fa>
    ad8a:	48 85 db             	test   %rbx,%rbx
    ad8d:	0f 84 f7 01 00 00    	je     af8a <fwp_main_thread+0x4ba>
    ad93:	48 8b 15 ae 69 01 00 	mov    0x169ae(%rip),%rdx        # 21748 <fwp_tasks_active>
    ad9a:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    ad9e:	48 85 d2             	test   %rdx,%rdx
    ada1:	0f 84 e3 01 00 00    	je     af8a <fwp_main_thread+0x4ba>
    ada7:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    adab:	75 08                	jne    adb5 <fwp_main_thread+0x2e5>
    adad:	48 89 d7             	mov    %rdx,%rdi
    adb0:	e8 fb 92 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    adb5:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    adbc:	48 85 d2             	test   %rdx,%rdx
    adbf:	75 e6                	jne    ada7 <fwp_main_thread+0x2d7>
    adc1:	e9 a7 00 00 00       	jmp    ae6d <fwp_main_thread+0x39d>
    adc6:	48 83 3d 4a 86 01 00 	cmpq   $0x0,0x1864a(%rip)        # 23418 <fwp_state_len>
    adcd:	00 
    adce:	0f 85 9e 01 00 00    	jne    af72 <fwp_main_thread+0x4a2>
    add4:	31 db                	xor    %ebx,%ebx
    add6:	48 83 3d 2a 86 01 00 	cmpq   $0x0,0x1862a(%rip)        # 23408 <fwp_state_owners>
    addd:	00 
    adde:	75 93                	jne    ad73 <fwp_main_thread+0x2a3>
    ade0:	48 8b 3d 39 86 01 00 	mov    0x18639(%rip),%rdi        # 23420 <fwp_state>
    ade7:	e8 c4 a7 ff ff       	call   55b0 <fwp_mem_free>
    adec:	48 c7 05 29 86 01 00 	movq   $0x0,0x18629(%rip)        # 23420 <fwp_state>
    adf3:	00 00 00 00 
    adf7:	48 c7 05 0e 86 01 00 	movq   $0x0,0x1860e(%rip)        # 23410 <fwp_state_cap>
    adfe:	00 00 00 00 
    ae02:	48 85 db             	test   %rbx,%rbx
    ae05:	0f 84 a3 13 00 00    	je     c1ae <fwp_main_thread+0x16de>
    ae0b:	48 39 1d 66 69 01 00 	cmp    %rbx,0x16966(%rip)        # 21778 <fwp_root>
    ae12:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    ae19:	00 00 00 00 
    ae1d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    ae24:	00 00 00 00 
    ae28:	c7 05 8e 62 01 00 00 	movl   $0x0,0x1628e(%rip)        # 210c0 <fwp_exit_code>
    ae2f:	00 00 00 
    ae32:	0f 84 5b ff ff ff    	je     ad93 <fwp_main_thread+0x2c3>
    ae38:	e9 13 89 ff ff       	jmp    3750 <fwp_main_thread.cold>
    ae3d:	0f 1f 00             	nopl   (%rax)
    ae40:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    ae47:	48 89 1d 12 69 01 00 	mov    %rbx,0x16912(%rip)        # 21760 <fwp_ready_tail>
    ae4e:	e8 5d c2 ff ff       	call   70b0 <fwp_block>
    ae53:	e8 58 c0 ff ff       	call   6eb0 <fwp_free_zombie>
    ae58:	48 83 3d e8 68 01 00 	cmpq   $0x0,0x168e8(%rip)        # 21748 <fwp_tasks_active>
    ae5f:	00 
    ae60:	0f 84 24 01 00 00    	je     af8a <fwp_main_thread+0x4ba>
    ae66:	48 8b 1d 0b 69 01 00 	mov    0x1690b(%rip),%rbx        # 21778 <fwp_root>
    ae6d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    ae71:	75 db                	jne    ae4e <fwp_main_thread+0x37e>
    ae73:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    ae77:	75 d5                	jne    ae4e <fwp_main_thread+0x37e>
    ae79:	48 8b 05 e0 68 01 00 	mov    0x168e0(%rip),%rax        # 21760 <fwp_ready_tail>
    ae80:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    ae84:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    ae8b:	00 00 00 00 
    ae8f:	48 85 c0             	test   %rax,%rax
    ae92:	75 ac                	jne    ae40 <fwp_main_thread+0x370>
    ae94:	48 89 1d cd 68 01 00 	mov    %rbx,0x168cd(%rip)        # 21768 <fwp_ready_head>
    ae9b:	eb aa                	jmp    ae47 <fwp_main_thread+0x377>
    ae9d:	e8 6e 94 ff ff       	call   4310 <fwp_now_ns>
    aea2:	49 3b 44 24 60       	cmp    0x60(%r12),%rax
    aea7:	7c 10                	jl     aeb9 <fwp_main_thread+0x3e9>
    aea9:	41 80 7c 24 50 00    	cmpb   $0x0,0x50(%r12)
    aeaf:	75 08                	jne    aeb9 <fwp_main_thread+0x3e9>
    aeb1:	4c 89 e7             	mov    %r12,%rdi
    aeb4:	e8 f7 91 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    aeb9:	41 80 7c 24 51 00    	cmpb   $0x0,0x51(%r12)
    aebf:	0f 85 6f fd ff ff    	jne    ac34 <fwp_main_thread+0x164>
    aec5:	49 8b 44 24 60       	mov    0x60(%r12),%rax
    aeca:	49 8d 54 24 40       	lea    0x40(%r12),%rdx
    aecf:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    aed3:	0f 85 6e fd ff ff    	jne    ac47 <fwp_main_thread+0x177>
    aed9:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    aedd:	48 85 c9             	test   %rcx,%rcx
    aee0:	0f 84 61 fd ff ff    	je     ac47 <fwp_main_thread+0x177>
    aee6:	48 85 c0             	test   %rax,%rax
    aee9:	0f 84 86 13 00 00    	je     c275 <fwp_main_thread+0x17a5>
    aeef:	48 39 c8             	cmp    %rcx,%rax
    aef2:	48 0f 4f c1          	cmovg  %rcx,%rax
    aef6:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    aefd:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    af02:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    af09:	00 00 00 00 
    af0d:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    af14:	48 85 d2             	test   %rdx,%rdx
    af17:	74 07                	je     af20 <fwp_main_thread+0x450>
    af19:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    af20:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    af25:	e9 51 fd ff ff       	jmp    ac7b <fwp_main_thread+0x1ab>
    af2a:	48 89 cb             	mov    %rcx,%rbx
    af2d:	e9 de fc ff ff       	jmp    ac10 <fwp_main_thread+0x140>
    af32:	48 89 01             	mov    %rax,(%rcx)
    af35:	e9 af fd ff ff       	jmp    ace9 <fwp_main_thread+0x219>
    af3a:	49 8b 44 24 40       	mov    0x40(%r12),%rax
    af3f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    af46:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    af4d:	00 00 00 00 
    af51:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    af58:	48 85 c0             	test   %rax,%rax
    af5b:	0f 84 13 11 00 00    	je     c074 <fwp_main_thread+0x15a4>
    af61:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    af68:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    af6d:	e9 3d fd ff ff       	jmp    acaf <fwp_main_thread+0x1df>
    af72:	48 83 3d fe 67 01 00 	cmpq   $0x0,0x167fe(%rip)        # 21778 <fwp_root>
    af79:	00 
    af7a:	c7 05 3c 61 01 00 00 	movl   $0x0,0x1613c(%rip)        # 210c0 <fwp_exit_code>
    af81:	00 00 00 
    af84:	0f 85 3b 13 00 00    	jne    c2c5 <fwp_main_thread+0x17f5>
    af8a:	e8 21 bf ff ff       	call   6eb0 <fwp_free_zombie>
    af8f:	48 83 3d d1 67 01 00 	cmpq   $0x0,0x167d1(%rip)        # 21768 <fwp_ready_head>
    af96:	00 
    af97:	0f 85 b3 87 ff ff    	jne    3750 <fwp_main_thread.cold>
    af9d:	48 83 3d b3 67 01 00 	cmpq   $0x0,0x167b3(%rip)        # 21758 <fwp_timers>
    afa4:	00 
    afa5:	0f 85 a5 87 ff ff    	jne    3750 <fwp_main_thread.cold>
    afab:	8b 05 9b 61 01 00    	mov    0x1619b(%rip),%eax        # 2114c <fwp_stack_pool_n>
    afb1:	85 c0                	test   %eax,%eax
    afb3:	74 37                	je     afec <fwp_main_thread+0x51c>
    afb5:	83 e8 01             	sub    $0x1,%eax
    afb8:	4c 8d 2d a1 61 01 00 	lea    0x161a1(%rip),%r13        # 21160 <fwp_stack_pool>
    afbf:	48 63 d8             	movslq %eax,%rbx
    afc2:	89 c0                	mov    %eax,%eax
    afc4:	48 89 da             	mov    %rbx,%rdx
    afc7:	48 29 c2             	sub    %rax,%rdx
    afca:	4c 8d 62 ff          	lea    -0x1(%rdx),%r12
    afce:	49 8b 7c dd 00       	mov    0x0(%r13,%rbx,8),%rdi
    afd3:	89 1d 73 61 01 00    	mov    %ebx,0x16173(%rip)        # 2114c <fwp_stack_pool_n>
    afd9:	be 00 00 00 10       	mov    $0x10000000,%esi
    afde:	48 83 eb 01          	sub    $0x1,%rbx
    afe2:	e8 f9 85 ff ff       	call   35e0 <munmap@plt>
    afe7:	4c 39 e3             	cmp    %r12,%rbx
    afea:	75 e2                	jne    afce <fwp_main_thread+0x4fe>
    afec:	8b 3d 2e 60 00 00    	mov    0x602e(%rip),%edi        # 11020 <fwp_epfd>
    aff2:	85 ff                	test   %edi,%edi
    aff4:	78 05                	js     affb <fwp_main_thread+0x52b>
    aff6:	e8 d5 84 ff ff       	call   34d0 <close@plt>
    affb:	4c 8b 2d 5e 63 01 00 	mov    0x1635e(%rip),%r13        # 21360 <fwp_nfdws>
    b002:	4c 8b 25 5f 63 01 00 	mov    0x1635f(%rip),%r12        # 21368 <fwp_fdws>
    b009:	31 db                	xor    %ebx,%ebx
    b00b:	c7 05 0b 60 00 00 ff 	movl   $0xffffffff,0x600b(%rip)        # 11020 <fwp_epfd>
    b012:	ff ff ff 
    b015:	4d 85 ed             	test   %r13,%r13
    b018:	74 2c                	je     b046 <fwp_main_thread+0x576>
    b01a:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b01e:	48 85 ff             	test   %rdi,%rdi
    b021:	74 1a                	je     b03d <fwp_main_thread+0x56d>
    b023:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    b027:	0f 85 23 87 ff ff    	jne    3750 <fwp_main_thread.cold>
    b02d:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    b032:	0f 85 18 87 ff ff    	jne    3750 <fwp_main_thread.cold>
    b038:	e8 73 a5 ff ff       	call   55b0 <fwp_mem_free>
    b03d:	48 83 c3 01          	add    $0x1,%rbx
    b041:	4c 39 eb             	cmp    %r13,%rbx
    b044:	75 d4                	jne    b01a <fwp_main_thread+0x54a>
    b046:	4c 89 e7             	mov    %r12,%rdi
    b049:	e8 62 a5 ff ff       	call   55b0 <fwp_mem_free>
    b04e:	48 8b 15 23 67 01 00 	mov    0x16723(%rip),%rdx        # 21778 <fwp_root>
    b055:	48 c7 05 08 63 01 00 	movq   $0x0,0x16308(%rip)        # 21368 <fwp_fdws>
    b05c:	00 00 00 00 
    b060:	48 c7 05 f5 62 01 00 	movq   $0x0,0x162f5(%rip)        # 21360 <fwp_nfdws>
    b067:	00 00 00 00 
    b06b:	48 85 d2             	test   %rdx,%rdx
    b06e:	74 4e                	je     b0be <fwp_main_thread+0x5ee>
    b070:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    b075:	0f 85 d5 86 ff ff    	jne    3750 <fwp_main_thread.cold>
    b07b:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    b082:	00 
    b083:	0f 85 c7 86 ff ff    	jne    3750 <fwp_main_thread.cold>
    b089:	48 83 3d 87 83 01 00 	cmpq   $0x0,0x18387(%rip)        # 23418 <fwp_state_len>
    b090:	00 
    b091:	0f 85 b9 86 ff ff    	jne    3750 <fwp_main_thread.cold>
    b097:	48 83 3d 69 83 01 00 	cmpq   $0x0,0x18369(%rip)        # 23408 <fwp_state_owners>
    b09e:	00 
    b09f:	0f 85 ab 86 ff ff    	jne    3750 <fwp_main_thread.cold>
    b0a5:	b9 79 00 00 00       	mov    $0x79,%ecx
    b0aa:	31 c0                	xor    %eax,%eax
    b0ac:	48 8d 3d cd 62 01 00 	lea    0x162cd(%rip),%rdi        # 21380 <fwp_root_context>
    b0b3:	f3 48 ab             	rep stos %rax,(%rdi)
    b0b6:	48 89 d7             	mov    %rdx,%rdi
    b0b9:	e8 f2 a4 ff ff       	call   55b0 <fwp_mem_free>
    b0be:	48 8b 3d 7b 5f 00 00 	mov    0x5f7b(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    b0c5:	48 c7 05 b0 66 01 00 	movq   $0x0,0x166b0(%rip)        # 21780 <fwp_cur>
    b0cc:	00 00 00 00 
    b0d0:	48 c7 05 9d 66 01 00 	movq   $0x0,0x1669d(%rip)        # 21778 <fwp_root>
    b0d7:	00 00 00 00 
    b0db:	e8 e0 84 ff ff       	call   35c0 <fflush@plt>
    b0e0:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    b0e4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b0eb:	00 00 
    b0ed:	0f 85 2d 11 00 00    	jne    c220 <fwp_main_thread+0x1750>
    b0f3:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    b0f7:	31 c0                	xor    %eax,%eax
    b0f9:	5b                   	pop    %rbx
    b0fa:	41 5c                	pop    %r12
    b0fc:	41 5d                	pop    %r13
    b0fe:	41 5e                	pop    %r14
    b100:	41 5f                	pop    %r15
    b102:	5d                   	pop    %rbp
    b103:	c3                   	ret
    b104:	48 89 05 4d 66 01 00 	mov    %rax,0x1664d(%rip)        # 21758 <fwp_timers>
    b10b:	e9 2a fc ff ff       	jmp    ad3a <fwp_main_thread+0x26a>
    b110:	e8 1b 9a ff ff       	call   4b30 <fwp_heap_init>
    b115:	8b 3d 2d 7a 01 00    	mov    0x17a2d(%rip),%edi        # 22b48 <fwp_heap+0x13a8>
    b11b:	85 ff                	test   %edi,%edi
    b11d:	0f 84 f2 f9 ff ff    	je     ab15 <fwp_main_thread+0x45>
    b123:	48 8d 3d f6 98 ff ff 	lea    -0x670a(%rip),%rdi        # 4a20 <fwp_heap_report>
    b12a:	e8 b1 13 00 00       	call   c4e0 <atexit>
    b12f:	e9 e1 f9 ff ff       	jmp    ab15 <fwp_main_thread+0x45>
    b134:	48 8d 05 b5 b6 ff ff 	lea    -0x494b(%rip),%rax        # 67f0 <fwp_drop1>
    b13b:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    b140:	4c 89 ad b0 fe ff ff 	mov    %r13,-0x150(%rbp)
    b147:	45 31 ff             	xor    %r15d,%r15d
    b14a:	66 48 0f 6e e0       	movq   %rax,%xmm4
    b14f:	48 8b 05 e2 82 01 00 	mov    0x182e2(%rip),%rax        # 23438 <fwp_cleanups>
    b156:	48 c7 85 f0 fe ff ff 	movq   $0x0,-0x110(%rbp)
    b15d:	00 00 00 00 
    b161:	4c 8d 35 38 66 01 00 	lea    0x16638(%rip),%r14        # 217a0 <fwp_heap>
    b168:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    b16c:	4c 89 25 c5 82 01 00 	mov    %r12,0x182c5(%rip)        # 23438 <fwp_cleanups>
    b173:	41 bd ff 01 00 00    	mov    $0x1ff,%r13d
    b179:	4c 8b 25 70 29 00 00 	mov    0x2970(%rip),%r12        # daf0 <msg.8+0x70>
    b180:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
    b187:	48 8d 05 42 8a ff ff 	lea    -0x75be(%rip),%rax        # 3bd0 <fwp_range_release>
    b18e:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
    b195:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
    b19c:	0f 29 85 00 ff ff ff 	movaps %xmm0,-0x100(%rbp)
    b1a3:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
    b1aa:	e9 0a 01 00 00       	jmp    b2b9 <fwp_main_thread+0x7e9>
    b1af:	48 8b 13             	mov    (%rbx),%rdx
    b1b2:	48 f7 d2             	not    %rdx
    b1b5:	48 89 10             	mov    %rdx,(%rax)
    b1b8:	49 83 f8 18          	cmp    $0x18,%r8
    b1bc:	76 29                	jbe    b1e7 <fwp_main_thread+0x717>
    b1be:	49 8d 40 e7          	lea    -0x19(%r8),%rax
    b1c2:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    b1c6:	31 f6                	xor    %esi,%esi
    b1c8:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    b1cf:	48 c1 e8 03          	shr    $0x3,%rax
    b1d3:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    b1da:	00 
    b1db:	e8 e0 82 ff ff       	call   34c0 <memset@plt>
    b1e0:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    b1e7:	4c 89 c0             	mov    %r8,%rax
    b1ea:	49 03 86 20 14 00 00 	add    0x1420(%r14),%rax
    b1f1:	0f 82 89 10 00 00    	jb     c280 <fwp_main_thread+0x17b0>
    b1f7:	49 89 86 20 14 00 00 	mov    %rax,0x1420(%r14)
    b1fe:	49 39 86 28 14 00 00 	cmp    %rax,0x1428(%r14)
    b205:	73 07                	jae    b20e <fwp_main_thread+0x73e>
    b207:	49 89 86 28 14 00 00 	mov    %rax,0x1428(%r14)
    b20e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b212:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    b217:	f2 41 0f 58 86 38 14 	addsd  0x1438(%r14),%xmm0
    b21e:	00 00 
    b220:	f2 41 0f 11 86 38 14 	movsd  %xmm0,0x1438(%r14)
    b227:	00 00 
    b229:	4c 89 7b 10          	mov    %r15,0x10(%rbx)
    b22d:	48 89 d8             	mov    %rbx,%rax
    b230:	49 89 df             	mov    %rbx,%r15
    b233:	4c 89 23             	mov    %r12,(%rbx)
    b236:	4c 89 6b 08          	mov    %r13,0x8(%rbx)
    b23a:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b241:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b248:	48 c1 e2 10          	shl    $0x10,%rdx
    b24c:	48 39 d0             	cmp    %rdx,%rax
    b24f:	73 57                	jae    b2a8 <fwp_main_thread+0x7d8>
    b251:	48 89 c2             	mov    %rax,%rdx
    b254:	48 c1 ea 10          	shr    $0x10,%rdx
    b258:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    b25c:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b263:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    b267:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    b26b:	48 85 d2             	test   %rdx,%rdx
    b26e:	74 38                	je     b2a8 <fwp_main_thread+0x7d8>
    b270:	0f b6 3e             	movzbl (%rsi),%edi
    b273:	40 80 ff 02          	cmp    $0x2,%dil
    b277:	0f 84 a8 00 00 00    	je     b325 <fwp_main_thread+0x855>
    b27d:	40 80 ff 01          	cmp    $0x1,%dil
    b281:	75 25                	jne    b2a8 <fwp_main_thread+0x7d8>
    b283:	8b 7e 18             	mov    0x18(%rsi),%edi
    b286:	0f b7 c0             	movzwl %ax,%eax
    b289:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b28c:	48 0f af c7          	imul   %rdi,%rax
    b290:	48 c1 e8 20          	shr    $0x20,%rax
    b294:	48 39 f0             	cmp    %rsi,%rax
    b297:	73 0f                	jae    b2a8 <fwp_main_thread+0x7d8>
    b299:	48 01 c2             	add    %rax,%rdx
    b29c:	80 3a ff             	cmpb   $0xff,(%rdx)
    b29f:	0f 84 25 0e 00 00    	je     c0ca <fwp_main_thread+0x15fa>
    b2a5:	c6 02 01             	movb   $0x1,(%rdx)
    b2a8:	48 89 9d f0 fe ff ff 	mov    %rbx,-0x110(%rbp)
    b2af:	49 83 ed 01          	sub    $0x1,%r13
    b2b3:	0f 82 86 00 00 00    	jb     b33f <fwp_main_thread+0x86f>
    b2b9:	41 8b 8e a4 13 00 00 	mov    0x13a4(%r14),%ecx
    b2c0:	4c 89 ad f8 fe ff ff 	mov    %r13,-0x108(%rbp)
    b2c7:	85 c9                	test   %ecx,%ecx
    b2c9:	74 46                	je     b311 <fwp_main_thread+0x841>
    b2cb:	41 0f b6 86 a2 0f 00 	movzbl 0xfa2(%r14),%eax
    b2d2:	00 
    b2d3:	45 8b 84 86 00 0f 00 	mov    0xf00(%r14,%rax,4),%r8d
    b2da:	00 
    b2db:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    b2df:	49 8d 04 c6          	lea    (%r14,%rax,8),%rax
    b2e3:	48 8b 18             	mov    (%rax),%rbx
    b2e6:	48 85 db             	test   %rbx,%rbx
    b2e9:	0f 85 c0 fe ff ff    	jne    b1af <fwp_main_thread+0x6df>
    b2ef:	48 8b 58 08          	mov    0x8(%rax),%rbx
    b2f3:	48 85 db             	test   %rbx,%rbx
    b2f6:	74 19                	je     b311 <fwp_main_thread+0x841>
    b2f8:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b2fc:	48 29 da             	sub    %rbx,%rdx
    b2ff:	4c 39 c2             	cmp    %r8,%rdx
    b302:	72 0d                	jb     b311 <fwp_main_thread+0x841>
    b304:	4a 8d 14 03          	lea    (%rbx,%r8,1),%rdx
    b308:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b30c:	e9 a7 fe ff ff       	jmp    b1b8 <fwp_main_thread+0x6e8>
    b311:	31 f6                	xor    %esi,%esi
    b313:	bf 18 00 00 00       	mov    $0x18,%edi
    b318:	e8 93 a7 ff ff       	call   5ab0 <fwp_heap_alloc>
    b31d:	48 89 c3             	mov    %rax,%rbx
    b320:	e9 04 ff ff ff       	jmp    b229 <fwp_main_thread+0x759>
    b325:	66 85 c0             	test   %ax,%ax
    b328:	0f 84 6e ff ff ff    	je     b29c <fwp_main_thread+0x7cc>
    b32e:	48 89 9d f0 fe ff ff 	mov    %rbx,-0x110(%rbp)
    b335:	49 83 ed 01          	sub    $0x1,%r13
    b339:	0f 83 7a ff ff ff    	jae    b2b9 <fwp_main_thread+0x7e9>
    b33f:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
    b346:	66 0f 6f 05 e2 27 00 	movdqa 0x27e2(%rip),%xmm0        # db30 <msg.8+0xb0>
    b34d:	00 
    b34e:	bf 01 00 00 00       	mov    $0x1,%edi
    b353:	48 89 9d b8 fe ff ff 	mov    %rbx,-0x148(%rbp)
    b35a:	48 8b b5 b0 fe ff ff 	mov    -0x150(%rbp),%rsi
    b361:	48 89 05 d0 80 01 00 	mov    %rax,0x180d0(%rip)        # 23438 <fwp_cleanups>
    b368:	0f 29 85 30 ff ff ff 	movaps %xmm0,-0xd0(%rbp)
    b36f:	e8 3c b0 ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b374:	48 8b 15 fd 77 01 00 	mov    0x177fd(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    b37b:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    b382:	49 89 c5             	mov    %rax,%r13
    b385:	48 2b 05 c4 77 01 00 	sub    0x177c4(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    b38c:	48 c1 e2 10          	shl    $0x10,%rdx
    b390:	48 39 d0             	cmp    %rdx,%rax
    b393:	73 55                	jae    b3ea <fwp_main_thread+0x91a>
    b395:	48 89 c2             	mov    %rax,%rdx
    b398:	48 c1 ea 10          	shr    $0x10,%rdx
    b39c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b3a0:	48 8b 15 f1 77 01 00 	mov    0x177f1(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    b3a7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b3ab:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    b3af:	48 85 db             	test   %rbx,%rbx
    b3b2:	74 36                	je     b3ea <fwp_main_thread+0x91a>
    b3b4:	0f b6 0a             	movzbl (%rdx),%ecx
    b3b7:	80 f9 02             	cmp    $0x2,%cl
    b3ba:	0f 84 ee 0c 00 00    	je     c0ae <fwp_main_thread+0x15de>
    b3c0:	80 f9 01             	cmp    $0x1,%cl
    b3c3:	75 25                	jne    b3ea <fwp_main_thread+0x91a>
    b3c5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b3c8:	0f b7 c0             	movzwl %ax,%eax
    b3cb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b3ce:	48 0f af c1          	imul   %rcx,%rax
    b3d2:	48 c1 e8 20          	shr    $0x20,%rax
    b3d6:	48 39 d0             	cmp    %rdx,%rax
    b3d9:	73 0f                	jae    b3ea <fwp_main_thread+0x91a>
    b3db:	48 01 c3             	add    %rax,%rbx
    b3de:	80 3b ff             	cmpb   $0xff,(%rbx)
    b3e1:	0f 84 26 0d 00 00    	je     c10d <fwp_main_thread+0x163d>
    b3e7:	c6 03 01             	movb   $0x1,(%rbx)
    b3ea:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b3f1:	00 f0 3f 
    b3f4:	48 8d b5 20 ff ff ff 	lea    -0xe0(%rbp),%rsi
    b3fb:	bf 01 00 00 00       	mov    $0x1,%edi
    b400:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    b407:	4c 89 ad 28 ff ff ff 	mov    %r13,-0xd8(%rbp)
    b40e:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
    b415:	e8 96 af ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b41a:	48 8b 15 57 77 01 00 	mov    0x17757(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    b421:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    b428:	49 89 c5             	mov    %rax,%r13
    b42b:	48 2b 05 1e 77 01 00 	sub    0x1771e(%rip),%rax        # 22b50 <fwp_heap+0x13b0>
    b432:	48 c1 e2 10          	shl    $0x10,%rdx
    b436:	48 39 d0             	cmp    %rdx,%rax
    b439:	73 55                	jae    b490 <fwp_main_thread+0x9c0>
    b43b:	48 89 c2             	mov    %rax,%rdx
    b43e:	48 c1 ea 10          	shr    $0x10,%rdx
    b442:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b446:	48 8b 15 4b 77 01 00 	mov    0x1774b(%rip),%rdx        # 22b98 <fwp_heap+0x13f8>
    b44d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b451:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    b455:	48 85 db             	test   %rbx,%rbx
    b458:	74 36                	je     b490 <fwp_main_thread+0x9c0>
    b45a:	0f b6 0a             	movzbl (%rdx),%ecx
    b45d:	80 f9 02             	cmp    $0x2,%cl
    b460:	0f 84 56 0c 00 00    	je     c0bc <fwp_main_thread+0x15ec>
    b466:	80 f9 01             	cmp    $0x1,%cl
    b469:	75 25                	jne    b490 <fwp_main_thread+0x9c0>
    b46b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b46e:	0f b7 c0             	movzwl %ax,%eax
    b471:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b474:	48 0f af c1          	imul   %rcx,%rax
    b478:	48 c1 e8 20          	shr    $0x20,%rax
    b47c:	48 39 d0             	cmp    %rdx,%rax
    b47f:	73 0f                	jae    b490 <fwp_main_thread+0x9c0>
    b481:	48 01 c3             	add    %rax,%rbx
    b484:	80 3b ff             	cmpb   $0xff,(%rbx)
    b487:	0f 84 53 0d 00 00    	je     c1e0 <fwp_main_thread+0x1710>
    b48d:	c6 03 01             	movb   $0x1,(%rbx)
    b490:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b497:	33 f3 bf 
    b49a:	48 8d b5 10 ff ff ff 	lea    -0xf0(%rbp),%rsi
    b4a1:	bf 01 00 00 00       	mov    $0x1,%edi
    b4a6:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    b4ad:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
    b4b4:	4c 89 ad 18 ff ff ff 	mov    %r13,-0xe8(%rbp)
    b4bb:	e8 f0 ae ff ff       	call   63b0 <fwp_data.part.0.constprop.0>
    b4c0:	48 8b 15 b1 76 01 00 	mov    0x176b1(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    b4c7:	48 8b 0d 82 76 01 00 	mov    0x17682(%rip),%rcx        # 22b50 <fwp_heap+0x13b0>
    b4ce:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
    b4d5:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    b4dc:	48 89 d6             	mov    %rdx,%rsi
    b4df:	48 29 c8             	sub    %rcx,%rax
    b4e2:	48 c1 e6 10          	shl    $0x10,%rsi
    b4e6:	48 39 f0             	cmp    %rsi,%rax
    b4e9:	73 65                	jae    b550 <fwp_main_thread+0xa80>
    b4eb:	48 89 c6             	mov    %rax,%rsi
    b4ee:	48 c1 ee 10          	shr    $0x10,%rsi
    b4f2:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    b4f6:	48 8b 35 9b 76 01 00 	mov    0x1769b(%rip),%rsi        # 22b98 <fwp_heap+0x13f8>
    b4fd:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b501:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    b505:	48 85 db             	test   %rbx,%rbx
    b508:	74 46                	je     b550 <fwp_main_thread+0xa80>
    b50a:	0f b6 3e             	movzbl (%rsi),%edi
    b50d:	40 80 ff 02          	cmp    $0x2,%dil
    b511:	0f 84 89 0b 00 00    	je     c0a0 <fwp_main_thread+0x15d0>
    b517:	40 80 ff 01          	cmp    $0x1,%dil
    b51b:	75 33                	jne    b550 <fwp_main_thread+0xa80>
    b51d:	8b 7e 18             	mov    0x18(%rsi),%edi
    b520:	0f b7 c0             	movzwl %ax,%eax
    b523:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b526:	48 0f af c7          	imul   %rdi,%rax
    b52a:	48 c1 e8 20          	shr    $0x20,%rax
    b52e:	48 39 f0             	cmp    %rsi,%rax
    b531:	73 1d                	jae    b550 <fwp_main_thread+0xa80>
    b533:	48 01 c3             	add    %rax,%rbx
    b536:	80 3b ff             	cmpb   $0xff,(%rbx)
    b539:	0f 84 bc 0c 00 00    	je     c1fb <fwp_main_thread+0x172b>
    b53f:	c6 03 01             	movb   $0x1,(%rbx)
    b542:	48 8b 0d 07 76 01 00 	mov    0x17607(%rip),%rcx        # 22b50 <fwp_heap+0x13b0>
    b549:	48 8b 15 28 76 01 00 	mov    0x17628(%rip),%rdx        # 22b78 <fwp_heap+0x13d8>
    b550:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
    b557:	4c 89 85 68 fe ff ff 	mov    %r8,-0x198(%rbp)
    b55e:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
    b565:	4c 89 85 60 fe ff ff 	mov    %r8,-0x1a0(%rbp)
    b56c:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
    b573:	48 c1 e2 10          	shl    $0x10,%rdx
    b577:	48 29 c8             	sub    %rcx,%rax
    b57a:	48 39 d0             	cmp    %rdx,%rax
    b57d:	73 5d                	jae    b5dc <fwp_main_thread+0xb0c>
    b57f:	48 89 c2             	mov    %rax,%rdx
    b582:	48 c1 ea 10          	shr    $0x10,%rdx
    b586:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b58a:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b591:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b595:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    b599:	48 85 ff             	test   %rdi,%rdi
    b59c:	74 3e                	je     b5dc <fwp_main_thread+0xb0c>
    b59e:	0f b6 0a             	movzbl (%rdx),%ecx
    b5a1:	80 f9 02             	cmp    $0x2,%cl
    b5a4:	0f 84 e8 0a 00 00    	je     c092 <fwp_main_thread+0x15c2>
    b5aa:	80 f9 01             	cmp    $0x1,%cl
    b5ad:	75 2d                	jne    b5dc <fwp_main_thread+0xb0c>
    b5af:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b5b2:	0f b7 c0             	movzwl %ax,%eax
    b5b5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b5b8:	48 0f af c1          	imul   %rcx,%rax
    b5bc:	48 c1 e8 20          	shr    $0x20,%rax
    b5c0:	48 39 d0             	cmp    %rdx,%rax
    b5c3:	73 17                	jae    b5dc <fwp_main_thread+0xb0c>
    b5c5:	48 01 c7             	add    %rax,%rdi
    b5c8:	0f b6 07             	movzbl (%rdi),%eax
    b5cb:	84 c0                	test   %al,%al
    b5cd:	74 0d                	je     b5dc <fwp_main_thread+0xb0c>
    b5cf:	3c fd                	cmp    $0xfd,%al
    b5d1:	0f 87 3f 0c 00 00    	ja     c216 <fwp_main_thread+0x1746>
    b5d7:	83 c0 01             	add    $0x1,%eax
    b5da:	88 07                	mov    %al,(%rdi)
    b5dc:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
    b5e3:	48 8b 15 0e 7e 01 00 	mov    0x17e0e(%rip),%rdx        # 233f8 <fwp_fns>
    b5ea:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
    b5f1:	48 8d 05 20 5a 00 00 	lea    0x5a20(%rip),%rax        # 11018 <fc12>
    b5f8:	44 8b 28             	mov    (%rax),%r13d
    b5fb:	49 c1 e5 05          	shl    $0x5,%r13
    b5ff:	49 01 d5             	add    %rdx,%r13
    b602:	49 8b 4d 18          	mov    0x18(%r13),%rcx
    b606:	48 85 c9             	test   %rcx,%rcx
    b609:	0f 84 22 0c 00 00    	je     c231 <fwp_main_thread+0x1761>
    b60f:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    b614:	0f 84 d6 08 00 00    	je     bef0 <fwp_main_thread+0x1420>
    b61a:	49 8b 8e d8 13 00 00 	mov    0x13d8(%r14),%rcx
    b621:	48 8d 05 f0 59 00 00 	lea    0x59f0(%rip),%rax        # 11018 <fc12>
    b628:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b62f:	48 c1 e1 10          	shl    $0x10,%rcx
    b633:	48 39 c8             	cmp    %rcx,%rax
    b636:	73 5f                	jae    b697 <fwp_main_thread+0xbc7>
    b638:	48 89 c1             	mov    %rax,%rcx
    b63b:	48 c1 e9 10          	shr    $0x10,%rcx
    b63f:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b643:	49 8b 8e f8 13 00 00 	mov    0x13f8(%r14),%rcx
    b64a:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b64e:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    b652:	48 85 ff             	test   %rdi,%rdi
    b655:	74 40                	je     b697 <fwp_main_thread+0xbc7>
    b657:	0f b6 31             	movzbl (%rcx),%esi
    b65a:	40 80 fe 02          	cmp    $0x2,%sil
    b65e:	0f 84 69 09 00 00    	je     bfcd <fwp_main_thread+0x14fd>
    b664:	40 80 fe 01          	cmp    $0x1,%sil
    b668:	75 2d                	jne    b697 <fwp_main_thread+0xbc7>
    b66a:	8b 71 18             	mov    0x18(%rcx),%esi
    b66d:	0f b7 c0             	movzwl %ax,%eax
    b670:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b673:	48 0f af c6          	imul   %rsi,%rax
    b677:	48 c1 e8 20          	shr    $0x20,%rax
    b67b:	48 39 c8             	cmp    %rcx,%rax
    b67e:	73 17                	jae    b697 <fwp_main_thread+0xbc7>
    b680:	48 01 c7             	add    %rax,%rdi
    b683:	0f b6 07             	movzbl (%rdi),%eax
    b686:	84 c0                	test   %al,%al
    b688:	74 0d                	je     b697 <fwp_main_thread+0xbc7>
    b68a:	3c fd                	cmp    $0xfd,%al
    b68c:	0f 87 d1 09 00 00    	ja     c063 <fwp_main_thread+0x1593>
    b692:	83 c0 01             	add    $0x1,%eax
    b695:	88 07                	mov    %al,(%rdi)
    b697:	48 8b 9d 80 fe ff ff 	mov    -0x180(%rbp),%rbx
    b69e:	4c 8d 3d 73 59 00 00 	lea    0x5973(%rip),%r15        # 11018 <fc12>
    b6a5:	c7 85 9c fe ff ff 01 	movl   $0x1,-0x164(%rbp)
    b6ac:	00 00 00 
    b6af:	4c 89 f8             	mov    %r15,%rax
    b6b2:	48 89 9d a0 fe ff ff 	mov    %rbx,-0x160(%rbp)
    b6b9:	8b 9d 9c fe ff ff    	mov    -0x164(%rbp),%ebx
    b6bf:	41 8b 4d 00          	mov    0x0(%r13),%ecx
    b6c3:	4d 89 fa             	mov    %r15,%r10
    b6c6:	2b 48 04             	sub    0x4(%rax),%ecx
    b6c9:	41 8b 07             	mov    (%r15),%eax
    b6cc:	39 d9                	cmp    %ebx,%ecx
    b6ce:	4c 8b ad a0 fe ff ff 	mov    -0x160(%rbp),%r13
    b6d5:	41 89 cc             	mov    %ecx,%r12d
    b6d8:	0f 46 d9             	cmovbe %ecx,%ebx
    b6db:	48 c1 e0 05          	shl    $0x5,%rax
    b6df:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    b6e3:	4c 89 f8             	mov    %r15,%rax
    b6e6:	49 8b 50 18          	mov    0x18(%r8),%rdx
    b6ea:	89 9d 8c fe ff ff    	mov    %ebx,-0x174(%rbp)
    b6f0:	89 9d b8 fe ff ff    	mov    %ebx,-0x148(%rbp)
    b6f6:	48 85 d2             	test   %rdx,%rdx
    b6f9:	0f 84 38 02 00 00    	je     b937 <fwp_main_thread+0xe67>
    b6ff:	89 8d 88 fe ff ff    	mov    %ecx,-0x178(%rbp)
    b705:	eb 6d                	jmp    b774 <fwp_main_thread+0xca4>
    b707:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b70e:	00 00 
    b710:	85 db                	test   %ebx,%ebx
    b712:	0f 84 87 00 00 00    	je     b79f <fwp_main_thread+0xccf>
    b718:	4c 89 ef             	mov    %r13,%rdi
    b71b:	ff 12                	call   *(%rdx)
    b71d:	4c 89 ff             	mov    %r15,%rdi
    b720:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
    b727:	e8 24 b2 ff ff       	call   6950 <fwp_closure_drop>
    b72c:	44 3b a5 b8 fe ff ff 	cmp    -0x148(%rbp),%r12d
    b733:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
    b73a:	0f 84 a0 07 00 00    	je     bee0 <fwp_main_thread+0x1410>
    b740:	8b 95 98 fe ff ff    	mov    -0x168(%rbp),%edx
    b746:	44 8b 00             	mov    (%rax),%r8d
    b749:	4f 8d 6c e5 00       	lea    0x0(%r13,%r12,8),%r13
    b74e:	49 89 c2             	mov    %rax,%r10
    b751:	29 da                	sub    %ebx,%edx
    b753:	49 c1 e0 05          	shl    $0x5,%r8
    b757:	4c 03 05 9a 7c 01 00 	add    0x17c9a(%rip),%r8        # 233f8 <fwp_fns>
    b75e:	89 95 b8 fe ff ff    	mov    %edx,-0x148(%rbp)
    b764:	49 8b 50 18          	mov    0x18(%r8),%rdx
    b768:	48 85 d2             	test   %rdx,%rdx
    b76b:	0f 84 bf 01 00 00    	je     b930 <fwp_main_thread+0xe60>
    b771:	49 89 c7             	mov    %rax,%r15
    b774:	41 8b 4a 04          	mov    0x4(%r10),%ecx
    b778:	8b 85 b8 fe ff ff    	mov    -0x148(%rbp),%eax
    b77e:	41 8b 18             	mov    (%r8),%ebx
    b781:	01 c8                	add    %ecx,%eax
    b783:	89 85 98 fe ff ff    	mov    %eax,-0x168(%rbp)
    b789:	39 d8                	cmp    %ebx,%eax
    b78b:	0f 82 9f 04 00 00    	jb     bc30 <fwp_main_thread+0x1160>
    b791:	41 89 dc             	mov    %ebx,%r12d
    b794:	41 29 cc             	sub    %ecx,%r12d
    b797:	85 c9                	test   %ecx,%ecx
    b799:	0f 84 71 ff ff ff    	je     b710 <fwp_main_thread+0xc40>
    b79f:	85 db                	test   %ebx,%ebx
    b7a1:	b8 01 00 00 00       	mov    $0x1,%eax
    b7a6:	48 89 e6             	mov    %rsp,%rsi
    b7a9:	48 89 a5 b0 fe ff ff 	mov    %rsp,-0x150(%rbp)
    b7b0:	0f 45 c3             	cmovne %ebx,%eax
    b7b3:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    b7ba:	00 
    b7bb:	48 c1 e8 04          	shr    $0x4,%rax
    b7bf:	48 c1 e0 04          	shl    $0x4,%rax
    b7c3:	48 89 c7             	mov    %rax,%rdi
    b7c6:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    b7cd:	48 29 fe             	sub    %rdi,%rsi
    b7d0:	48 39 f4             	cmp    %rsi,%rsp
    b7d3:	74 15                	je     b7ea <fwp_main_thread+0xd1a>
    b7d5:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    b7dc:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    b7e3:	00 00 
    b7e5:	48 39 f4             	cmp    %rsi,%rsp
    b7e8:	75 eb                	jne    b7d5 <fwp_main_thread+0xd05>
    b7ea:	25 ff 0f 00 00       	and    $0xfff,%eax
    b7ef:	48 29 c4             	sub    %rax,%rsp
    b7f2:	48 85 c0             	test   %rax,%rax
    b7f5:	74 06                	je     b7fd <fwp_main_thread+0xd2d>
    b7f7:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    b7fd:	89 c8                	mov    %ecx,%eax
    b7ff:	48 89 a5 a8 fe ff ff 	mov    %rsp,-0x158(%rbp)
    b806:	48 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%rsi
    b80d:	00 
    b80e:	31 c0                	xor    %eax,%eax
    b810:	85 c9                	test   %ecx,%ecx
    b812:	74 25                	je     b839 <fwp_main_thread+0xd69>
    b814:	90                   	nop
    b815:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b81c:	00 00 00 00 
    b820:	49 8b 7c 02 08       	mov    0x8(%r10,%rax,1),%rdi
    b825:	4c 8b 9d a8 fe ff ff 	mov    -0x158(%rbp),%r11
    b82c:	49 89 3c 03          	mov    %rdi,(%r11,%rax,1)
    b830:	48 83 c0 08          	add    $0x8,%rax
    b834:	48 39 c6             	cmp    %rax,%rsi
    b837:	75 e7                	jne    b820 <fwp_main_thread+0xd50>
    b839:	45 85 e4             	test   %r12d,%r12d
    b83c:	74 3e                	je     b87c <fwp_main_thread+0xdac>
    b83e:	44 89 e0             	mov    %r12d,%eax
    b841:	4c 89 ee             	mov    %r13,%rsi
    b844:	49 8d 44 c5 00       	lea    0x0(%r13,%rax,8),%rax
    b849:	90                   	nop
    b84a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b851:	00 00 00 00 
    b855:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b85c:	00 00 00 00 
    b860:	4c 8b 0e             	mov    (%rsi),%r9
    b863:	4c 8b 9d a8 fe ff ff 	mov    -0x158(%rbp),%r11
    b86a:	89 cf                	mov    %ecx,%edi
    b86c:	48 83 c6 08          	add    $0x8,%rsi
    b870:	83 c1 01             	add    $0x1,%ecx
    b873:	4d 89 0c fb          	mov    %r9,(%r11,%rdi,8)
    b877:	48 39 f0             	cmp    %rsi,%rax
    b87a:	75 e4                	jne    b860 <fwp_main_thread+0xd90>
    b87c:	49 8b 8e d8 13 00 00 	mov    0x13d8(%r14),%rcx
    b883:	4c 89 f8             	mov    %r15,%rax
    b886:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b88d:	48 c1 e1 10          	shl    $0x10,%rcx
    b891:	48 39 c8             	cmp    %rcx,%rax
    b894:	73 4c                	jae    b8e2 <fwp_main_thread+0xe12>
    b896:	48 89 c1             	mov    %rax,%rcx
    b899:	48 c1 e9 10          	shr    $0x10,%rcx
    b89d:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b8a1:	49 8b 8e f8 13 00 00 	mov    0x13f8(%r14),%rcx
    b8a8:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b8ac:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    b8b0:	48 85 f6             	test   %rsi,%rsi
    b8b3:	74 2d                	je     b8e2 <fwp_main_thread+0xe12>
    b8b5:	0f b6 39             	movzbl (%rcx),%edi
    b8b8:	40 80 ff 02          	cmp    $0x2,%dil
    b8bc:	74 6a                	je     b928 <fwp_main_thread+0xe58>
    b8be:	40 80 ff 01          	cmp    $0x1,%dil
    b8c2:	75 1e                	jne    b8e2 <fwp_main_thread+0xe12>
    b8c4:	8b 79 18             	mov    0x18(%rcx),%edi
    b8c7:	0f b7 c0             	movzwl %ax,%eax
    b8ca:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b8cd:	48 0f af c7          	imul   %rdi,%rax
    b8d1:	48 c1 e8 20          	shr    $0x20,%rax
    b8d5:	48 39 c8             	cmp    %rcx,%rax
    b8d8:	73 08                	jae    b8e2 <fwp_main_thread+0xe12>
    b8da:	48 01 c6             	add    %rax,%rsi
    b8dd:	80 3e 01             	cmpb   $0x1,(%rsi)
    b8e0:	74 36                	je     b918 <fwp_main_thread+0xe48>
    b8e2:	4c 89 85 90 fe ff ff 	mov    %r8,-0x170(%rbp)
    b8e9:	be 01 00 00 00       	mov    $0x1,%esi
    b8ee:	4c 89 ff             	mov    %r15,%rdi
    b8f1:	ff 52 08             	call   *0x8(%rdx)
    b8f4:	4c 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%r8
    b8fb:	49 8b 40 18          	mov    0x18(%r8),%rax
    b8ff:	48 8b bd a8 fe ff ff 	mov    -0x158(%rbp),%rdi
    b906:	ff 10                	call   *(%rax)
    b908:	48 8b a5 b0 fe ff ff 	mov    -0x150(%rbp),%rsp
    b90f:	e9 09 fe ff ff       	jmp    b71d <fwp_main_thread+0xc4d>
    b914:	0f 1f 40 00          	nopl   0x0(%rax)
    b918:	41 c7 42 04 00 00 00 	movl   $0x0,0x4(%r10)
    b91f:	00 
    b920:	eb d9                	jmp    b8fb <fwp_main_thread+0xe2b>
    b922:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b928:	66 85 c0             	test   %ax,%ax
    b92b:	75 b5                	jne    b8e2 <fwp_main_thread+0xe12>
    b92d:	eb ae                	jmp    b8dd <fwp_main_thread+0xe0d>
    b92f:	90                   	nop
    b930:	44 8b a5 88 fe ff ff 	mov    -0x178(%rbp),%r12d
    b937:	48 89 c7             	mov    %rax,%rdi
    b93a:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
    b941:	e8 9a ab ff ff       	call   64e0 <fwp_rc_share>
    b946:	8b 95 b8 fe ff ff    	mov    -0x148(%rbp),%edx
    b94c:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
    b953:	85 d2                	test   %edx,%edx
    b955:	74 35                	je     b98c <fwp_main_thread+0xebc>
    b957:	89 d1                	mov    %edx,%ecx
    b959:	44 89 a5 b0 fe ff ff 	mov    %r12d,-0x150(%rbp)
    b960:	49 89 c7             	mov    %rax,%r15
    b963:	4d 89 ec             	mov    %r13,%r12
    b966:	49 8d 5c cd 00       	lea    0x0(%r13,%rcx,8),%rbx
    b96b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b970:	49 8b 3c 24          	mov    (%r12),%rdi
    b974:	49 83 c4 08          	add    $0x8,%r12
    b978:	e8 63 ab ff ff       	call   64e0 <fwp_rc_share>
    b97d:	4c 39 e3             	cmp    %r12,%rbx
    b980:	75 ee                	jne    b970 <fwp_main_thread+0xea0>
    b982:	44 8b a5 b0 fe ff ff 	mov    -0x150(%rbp),%r12d
    b989:	4c 89 f8             	mov    %r15,%rax
    b98c:	8b b5 b8 fe ff ff    	mov    -0x148(%rbp),%esi
    b992:	4c 89 ea             	mov    %r13,%rdx
    b995:	48 89 c7             	mov    %rax,%rdi
    b998:	e8 33 a2 ff ff       	call   5bd0 <fwp_apply>
    b99d:	49 89 c7             	mov    %rax,%r15
    b9a0:	8b bd 9c fe ff ff    	mov    -0x164(%rbp),%edi
    b9a6:	41 39 fc             	cmp    %edi,%r12d
    b9a9:	0f 83 8c 00 00 00    	jae    ba3b <fwp_main_thread+0xf6b>
    b9af:	48 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%rdx
    b9b6:	8b 85 8c fe ff ff    	mov    -0x174(%rbp),%eax
    b9bc:	45 8b 2f             	mov    (%r15),%r13d
    b9bf:	48 89 c6             	mov    %rax,%rsi
    b9c2:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    b9c6:	48 8b 15 2b 7a 01 00 	mov    0x17a2b(%rip),%rdx        # 233f8 <fwp_fns>
    b9cd:	49 c1 e5 05          	shl    $0x5,%r13
    b9d1:	29 f7                	sub    %esi,%edi
    b9d3:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
    b9da:	4c 89 f8             	mov    %r15,%rax
    b9dd:	49 01 d5             	add    %rdx,%r13
    b9e0:	89 bd 9c fe ff ff    	mov    %edi,-0x164(%rbp)
    b9e6:	49 83 7d 18 00       	cmpq   $0x0,0x18(%r13)
    b9eb:	0f 85 c8 fc ff ff    	jne    b6b9 <fwp_main_thread+0xbe9>
    b9f1:	4c 89 ff             	mov    %r15,%rdi
    b9f4:	e8 e7 aa ff ff       	call   64e0 <fwp_rc_share>
    b9f9:	44 8b a5 9c fe ff ff 	mov    -0x164(%rbp),%r12d
    ba00:	45 85 e4             	test   %r12d,%r12d
    ba03:	74 1e                	je     ba23 <fwp_main_thread+0xf53>
    ba05:	4c 8b ad a0 fe ff ff 	mov    -0x160(%rbp),%r13
    ba0c:	31 db                	xor    %ebx,%ebx
    ba0e:	66 90                	xchg   %ax,%ax
    ba10:	49 8b 7c dd 00       	mov    0x0(%r13,%rbx,8),%rdi
    ba15:	48 83 c3 01          	add    $0x1,%rbx
    ba19:	e8 c2 aa ff ff       	call   64e0 <fwp_rc_share>
    ba1e:	44 39 e3             	cmp    %r12d,%ebx
    ba21:	72 ed                	jb     ba10 <fwp_main_thread+0xf40>
    ba23:	48 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%rdx
    ba2a:	8b b5 9c fe ff ff    	mov    -0x164(%rbp),%esi
    ba30:	4c 89 ff             	mov    %r15,%rdi
    ba33:	e8 98 a1 ff ff       	call   5bd0 <fwp_apply>
    ba38:	49 89 c7             	mov    %rax,%r15
    ba3b:	48 8b bd 78 fe ff ff 	mov    -0x188(%rbp),%rdi
    ba42:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ba46:	b9 01 00 00 00       	mov    $0x1,%ecx
    ba4b:	4c 89 fe             	mov    %r15,%rsi
    ba4e:	48 8d 15 4b 51 00 00 	lea    0x514b(%rip),%rdx        # 10ba0 <d0>
    ba55:	0f 29 85 f0 fe ff ff 	movaps %xmm0,-0x110(%rbp)
    ba5c:	48 c7 85 00 ff ff ff 	movq   $0x0,-0x100(%rbp)
    ba63:	00 00 00 00 
    ba67:	e8 24 e0 ff ff       	call   9a90 <fwp_write>
    ba6c:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
    ba73:	4c 8b ad f8 fe ff ff 	mov    -0x108(%rbp),%r13
    ba7a:	48 8d 05 ad 15 00 00 	lea    0x15ad(%rip),%rax        # d02e <_IO_stdin_used+0x2e>
    ba81:	48 85 c9             	test   %rcx,%rcx
    ba84:	48 0f 44 c8          	cmove  %rax,%rcx
    ba88:	49 83 fd f6          	cmp    $0xfffffffffffffff6,%r13
    ba8c:	0f 87 d7 07 00 00    	ja     c269 <fwp_main_thread+0x1799>
    ba92:	49 8d 7d 09          	lea    0x9(%r13),%rdi
    ba96:	be 01 00 00 00       	mov    $0x1,%esi
    ba9b:	48 89 8d b8 fe ff ff 	mov    %rcx,-0x148(%rbp)
    baa2:	e8 09 a0 ff ff       	call   5ab0 <fwp_heap_alloc>
    baa7:	48 8b b5 b8 fe ff ff 	mov    -0x148(%rbp),%rsi
    baae:	4c 89 ea             	mov    %r13,%rdx
    bab1:	4c 89 28             	mov    %r13,(%rax)
    bab4:	4c 8d 60 08          	lea    0x8(%rax),%r12
    bab8:	48 89 c3             	mov    %rax,%rbx
    babb:	4c 89 e7             	mov    %r12,%rdi
    babe:	e8 dd 7a ff ff       	call   35a0 <memcpy@plt>
    bac3:	42 c6 44 2b 08 00    	movb   $0x0,0x8(%rbx,%r13,1)
    bac9:	48 8b bd f0 fe ff ff 	mov    -0x110(%rbp),%rdi
    bad0:	e8 eb 78 ff ff       	call   33c0 <free@plt>
    bad5:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    badc:	48 89 d8             	mov    %rbx,%rax
    badf:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    bae6:	48 c1 e2 10          	shl    $0x10,%rdx
    baea:	48 39 d0             	cmp    %rdx,%rax
    baed:	73 57                	jae    bb46 <fwp_main_thread+0x1076>
    baef:	48 89 c2             	mov    %rax,%rdx
    baf2:	48 c1 ea 10          	shr    $0x10,%rdx
    baf6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bafa:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    bb01:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    bb05:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    bb09:	48 85 d2             	test   %rdx,%rdx
    bb0c:	74 38                	je     bb46 <fwp_main_thread+0x1076>
    bb0e:	0f b6 31             	movzbl (%rcx),%esi
    bb11:	40 80 fe 02          	cmp    $0x2,%sil
    bb15:	0f 84 85 06 00 00    	je     c1a0 <fwp_main_thread+0x16d0>
    bb1b:	40 80 fe 01          	cmp    $0x1,%sil
    bb1f:	75 25                	jne    bb46 <fwp_main_thread+0x1076>
    bb21:	8b 71 18             	mov    0x18(%rcx),%esi
    bb24:	0f b7 c0             	movzwl %ax,%eax
    bb27:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    bb2a:	48 0f af c6          	imul   %rsi,%rax
    bb2e:	48 c1 e8 20          	shr    $0x20,%rax
    bb32:	48 39 c8             	cmp    %rcx,%rax
    bb35:	73 0f                	jae    bb46 <fwp_main_thread+0x1076>
    bb37:	48 01 c2             	add    %rax,%rdx
    bb3a:	80 3a ff             	cmpb   $0xff,(%rdx)
    bb3d:	0f 84 af 05 00 00    	je     c0f2 <fwp_main_thread+0x1622>
    bb43:	c6 02 01             	movb   $0x1,(%rdx)
    bb46:	4c 89 ff             	mov    %r15,%rdi
    bb49:	e8 22 ab ff ff       	call   6670 <fwp_drop0>
    bb4e:	48 8b 13             	mov    (%rbx),%rdx
    bb51:	be 01 00 00 00       	mov    $0x1,%esi
    bb56:	4c 89 e7             	mov    %r12,%rdi
    bb59:	48 8b 0d a0 78 01 00 	mov    0x178a0(%rip),%rcx        # 23400 <fwp_prog_out>
    bb60:	e8 1b 7b ff ff       	call   3680 <fwrite@plt>
    bb65:	48 8b 35 94 78 01 00 	mov    0x17894(%rip),%rsi        # 23400 <fwp_prog_out>
    bb6c:	bf 0a 00 00 00       	mov    $0xa,%edi
    bb71:	e8 6a 79 ff ff       	call   34e0 <fputc@plt>
    bb76:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    bb7d:	48 89 d8             	mov    %rbx,%rax
    bb80:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    bb87:	48 c1 e2 10          	shl    $0x10,%rdx
    bb8b:	48 39 d0             	cmp    %rdx,%rax
    bb8e:	73 69                	jae    bbf9 <fwp_main_thread+0x1129>
    bb90:	48 89 c2             	mov    %rax,%rdx
    bb93:	48 c1 ea 10          	shr    $0x10,%rdx
    bb97:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bb9b:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    bba2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bba6:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    bbaa:	4d 85 ed             	test   %r13,%r13
    bbad:	74 4a                	je     bbf9 <fwp_main_thread+0x1129>
    bbaf:	0f b6 0a             	movzbl (%rdx),%ecx
    bbb2:	80 f9 02             	cmp    $0x2,%cl
    bbb5:	0f 84 6d 05 00 00    	je     c128 <fwp_main_thread+0x1658>
    bbbb:	80 f9 01             	cmp    $0x1,%cl
    bbbe:	75 39                	jne    bbf9 <fwp_main_thread+0x1129>
    bbc0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bbc3:	0f b7 c0             	movzwl %ax,%eax
    bbc6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bbc9:	48 0f af c1          	imul   %rcx,%rax
    bbcd:	48 c1 e8 20          	shr    $0x20,%rax
    bbd1:	48 39 d0             	cmp    %rdx,%rax
    bbd4:	73 23                	jae    bbf9 <fwp_main_thread+0x1129>
    bbd6:	49 01 c5             	add    %rax,%r13
    bbd9:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
    bbde:	84 c0                	test   %al,%al
    bbe0:	74 17                	je     bbf9 <fwp_main_thread+0x1129>
    bbe2:	3c 01                	cmp    $0x1,%al
    bbe4:	0f 84 fb 04 00 00    	je     c0e5 <fwp_main_thread+0x1615>
    bbea:	3c ff                	cmp    $0xff,%al
    bbec:	0f 84 44 05 00 00    	je     c136 <fwp_main_thread+0x1666>
    bbf2:	83 e8 01             	sub    $0x1,%eax
    bbf5:	41 88 45 00          	mov    %al,0x0(%r13)
    bbf9:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
    bc00:	48 8b 40 10          	mov    0x10(%rax),%rax
    bc04:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
    bc0b:	48 85 c0             	test   %rax,%rax
    bc0e:	0f 84 71 06 00 00    	je     c285 <fwp_main_thread+0x17b5>
    bc14:	49 8b 8e b0 13 00 00 	mov    0x13b0(%r14),%rcx
    bc1b:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    bc22:	e9 45 f9 ff ff       	jmp    b56c <fwp_main_thread+0xa9c>
    bc27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    bc2e:	00 00 
    bc30:	41 8b 96 a4 13 00 00 	mov    0x13a4(%r14),%edx
    bc37:	8d 70 01             	lea    0x1(%rax),%esi
    bc3a:	44 8b a5 88 fe ff ff 	mov    -0x178(%rbp),%r12d
    bc41:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    bc48:	00 
    bc49:	85 d2                	test   %edx,%edx
    bc4b:	0f 84 ac 03 00 00    	je     bffd <fwp_main_thread+0x152d>
    bc51:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    bc58:	0f 87 9f 03 00 00    	ja     bffd <fwp_main_thread+0x152d>
    bc5e:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    bc62:	48 c1 e8 04          	shr    $0x4,%rax
    bc66:	41 0f b6 94 06 a0 0f 	movzbl 0xfa0(%r14,%rax,1),%edx
    bc6d:	00 00 
    bc6f:	41 8b 84 96 00 0f 00 	mov    0xf00(%r14,%rdx,4),%eax
    bc76:	00 
    bc77:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    bc7b:	49 8d 14 d6          	lea    (%r14,%rdx,8),%rdx
    bc7f:	48 8b 1a             	mov    (%rdx),%rbx
    bc82:	48 85 db             	test   %rbx,%rbx
    bc85:	0f 84 50 03 00 00    	je     bfdb <fwp_main_thread+0x150b>
    bc8b:	4c 8b 1b             	mov    (%rbx),%r11
    bc8e:	49 f7 d3             	not    %r11
    bc91:	4c 89 1a             	mov    %r11,(%rdx)
    bc94:	48 39 c7             	cmp    %rax,%rdi
    bc97:	73 61                	jae    bcfa <fwp_main_thread+0x122a>
    bc99:	48 89 fa             	mov    %rdi,%rdx
    bc9c:	48 83 c7 08          	add    $0x8,%rdi
    bca0:	48 c7 04 f3 00 00 00 	movq   $0x0,(%rbx,%rsi,8)
    bca7:	00 
    bca8:	48 f7 d2             	not    %rdx
    bcab:	48 01 c2             	add    %rax,%rdx
    bcae:	48 c1 ea 03          	shr    $0x3,%rdx
    bcb2:	48 39 c7             	cmp    %rax,%rdi
    bcb5:	73 43                	jae    bcfa <fwp_main_thread+0x122a>
    bcb7:	83 e2 01             	and    $0x1,%edx
    bcba:	74 24                	je     bce0 <fwp_main_thread+0x1210>
    bcbc:	48 c7 04 3b 00 00 00 	movq   $0x0,(%rbx,%rdi,1)
    bcc3:	00 
    bcc4:	48 83 c7 08          	add    $0x8,%rdi
    bcc8:	48 39 c7             	cmp    %rax,%rdi
    bccb:	73 2d                	jae    bcfa <fwp_main_thread+0x122a>
    bccd:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    bcd4:	00 
    bcd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bcdc:	00 00 00 00 
    bce0:	48 c7 04 3b 00 00 00 	movq   $0x0,(%rbx,%rdi,1)
    bce7:	00 
    bce8:	48 c7 44 3b 08 00 00 	movq   $0x0,0x8(%rbx,%rdi,1)
    bcef:	00 00 
    bcf1:	48 83 c7 10          	add    $0x10,%rdi
    bcf5:	48 39 c7             	cmp    %rax,%rdi
    bcf8:	72 e6                	jb     bce0 <fwp_main_thread+0x1210>
    bcfa:	48 89 c2             	mov    %rax,%rdx
    bcfd:	49 03 96 20 14 00 00 	add    0x1420(%r14),%rdx
    bd04:	0f 82 76 05 00 00    	jb     c280 <fwp_main_thread+0x17b0>
    bd0a:	49 89 96 20 14 00 00 	mov    %rdx,0x1420(%r14)
    bd11:	49 39 96 28 14 00 00 	cmp    %rdx,0x1428(%r14)
    bd18:	73 07                	jae    bd21 <fwp_main_thread+0x1251>
    bd1a:	49 89 96 28 14 00 00 	mov    %rdx,0x1428(%r14)
    bd21:	66 0f ef c0          	pxor   %xmm0,%xmm0
    bd25:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    bd2a:	f2 41 0f 58 86 38 14 	addsd  0x1438(%r14),%xmm0
    bd31:	00 00 
    bd33:	f2 41 0f 11 86 38 14 	movsd  %xmm0,0x1438(%r14)
    bd3a:	00 00 
    bd3c:	66 41 0f 6e 02       	movd   (%r10),%xmm0
    bd41:	66 0f 6e 8d 98 fe ff 	movd   -0x168(%rbp),%xmm1
    bd48:	ff 
    bd49:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    bd4d:	66 0f d6 03          	movq   %xmm0,(%rbx)
    bd51:	85 c9                	test   %ecx,%ecx
    bd53:	74 3b                	je     bd90 <fwp_main_thread+0x12c0>
    bd55:	89 ca                	mov    %ecx,%edx
    bd57:	49 8d 72 08          	lea    0x8(%r10),%rsi
    bd5b:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    bd5f:	89 8d a8 fe ff ff    	mov    %ecx,-0x158(%rbp)
    bd65:	48 c1 e2 03          	shl    $0x3,%rdx
    bd69:	4c 89 85 90 fe ff ff 	mov    %r8,-0x170(%rbp)
    bd70:	4c 89 95 b0 fe ff ff 	mov    %r10,-0x150(%rbp)
    bd77:	e8 94 78 ff ff       	call   3610 <memmove@plt>
    bd7c:	4c 8b 95 b0 fe ff ff 	mov    -0x150(%rbp),%r10
    bd83:	8b 8d a8 fe ff ff    	mov    -0x158(%rbp),%ecx
    bd89:	4c 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%r8
    bd90:	8b 85 b8 fe ff ff    	mov    -0x148(%rbp),%eax
    bd96:	85 c0                	test   %eax,%eax
    bd98:	74 3c                	je     bdd6 <fwp_main_thread+0x1306>
    bd9a:	8b 95 b8 fe ff ff    	mov    -0x148(%rbp),%edx
    bda0:	4c 89 e8             	mov    %r13,%rax
    bda3:	49 8d 7c d5 00       	lea    0x0(%r13,%rdx,8),%rdi
    bda8:	66 90                	xchg   %ax,%ax
    bdaa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bdb1:	00 00 00 00 
    bdb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bdbc:	00 00 00 00 
    bdc0:	48 8b 30             	mov    (%rax),%rsi
    bdc3:	89 ca                	mov    %ecx,%edx
    bdc5:	48 83 c0 08          	add    $0x8,%rax
    bdc9:	83 c1 01             	add    $0x1,%ecx
    bdcc:	48 89 74 d3 08       	mov    %rsi,0x8(%rbx,%rdx,8)
    bdd1:	48 39 c7             	cmp    %rax,%rdi
    bdd4:	75 ea                	jne    bdc0 <fwp_main_thread+0x12f0>
    bdd6:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    bddd:	4c 89 f8             	mov    %r15,%rax
    bde0:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    bde7:	48 c1 e2 10          	shl    $0x10,%rdx
    bdeb:	48 39 d0             	cmp    %rdx,%rax
    bdee:	73 54                	jae    be44 <fwp_main_thread+0x1374>
    bdf0:	48 89 c2             	mov    %rax,%rdx
    bdf3:	48 c1 ea 10          	shr    $0x10,%rdx
    bdf7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bdfb:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    be02:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    be06:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    be0a:	48 85 c9             	test   %rcx,%rcx
    be0d:	74 35                	je     be44 <fwp_main_thread+0x1374>
    be0f:	0f b6 32             	movzbl (%rdx),%esi
    be12:	40 80 fe 02          	cmp    $0x2,%sil
    be16:	0f 84 39 02 00 00    	je     c055 <fwp_main_thread+0x1585>
    be1c:	40 80 fe 01          	cmp    $0x1,%sil
    be20:	75 22                	jne    be44 <fwp_main_thread+0x1374>
    be22:	8b 72 18             	mov    0x18(%rdx),%esi
    be25:	0f b7 c0             	movzwl %ax,%eax
    be28:	8b 52 1c             	mov    0x1c(%rdx),%edx
    be2b:	48 0f af c6          	imul   %rsi,%rax
    be2f:	48 c1 e8 20          	shr    $0x20,%rax
    be33:	48 39 d0             	cmp    %rdx,%rax
    be36:	73 0c                	jae    be44 <fwp_main_thread+0x1374>
    be38:	48 01 c1             	add    %rax,%rcx
    be3b:	80 39 01             	cmpb   $0x1,(%rcx)
    be3e:	0f 84 7c 01 00 00    	je     bfc0 <fwp_main_thread+0x14f0>
    be44:	49 8b 40 18          	mov    0x18(%r8),%rax
    be48:	be 01 00 00 00       	mov    $0x1,%esi
    be4d:	4c 89 ff             	mov    %r15,%rdi
    be50:	ff 50 08             	call   *0x8(%rax)
    be53:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    be5a:	48 89 d8             	mov    %rbx,%rax
    be5d:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    be64:	48 c1 e2 10          	shl    $0x10,%rdx
    be68:	48 39 d0             	cmp    %rdx,%rax
    be6b:	73 5b                	jae    bec8 <fwp_main_thread+0x13f8>
    be6d:	48 89 c2             	mov    %rax,%rdx
    be70:	48 c1 ea 10          	shr    $0x10,%rdx
    be74:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    be78:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    be7f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    be83:	4c 8b 69 20          	mov    0x20(%rcx),%r13
    be87:	4d 85 ed             	test   %r13,%r13
    be8a:	74 3c                	je     bec8 <fwp_main_thread+0x13f8>
    be8c:	0f b6 31             	movzbl (%rcx),%esi
    be8f:	40 80 fe 02          	cmp    $0x2,%sil
    be93:	0f 84 9b 01 00 00    	je     c034 <fwp_main_thread+0x1564>
    be99:	40 80 fe 01          	cmp    $0x1,%sil
    be9d:	75 29                	jne    bec8 <fwp_main_thread+0x13f8>
    be9f:	8b 71 18             	mov    0x18(%rcx),%esi
    bea2:	0f b7 c0             	movzwl %ax,%eax
    bea5:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    bea8:	48 0f af c6          	imul   %rsi,%rax
    beac:	48 c1 e8 20          	shr    $0x20,%rax
    beb0:	48 39 c8             	cmp    %rcx,%rax
    beb3:	73 13                	jae    bec8 <fwp_main_thread+0x13f8>
    beb5:	49 01 c5             	add    %rax,%r13
    beb8:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    bebd:	0f 84 85 01 00 00    	je     c048 <fwp_main_thread+0x1578>
    bec3:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    bec8:	4c 89 ff             	mov    %r15,%rdi
    becb:	49 89 df             	mov    %rbx,%r15
    bece:	e8 7d aa ff ff       	call   6950 <fwp_closure_drop>
    bed3:	e9 c8 fa ff ff       	jmp    b9a0 <fwp_main_thread+0xed0>
    bed8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    bedf:	00 
    bee0:	44 8b a5 88 fe ff ff 	mov    -0x178(%rbp),%r12d
    bee7:	49 89 c7             	mov    %rax,%r15
    beea:	e9 b1 fa ff ff       	jmp    b9a0 <fwp_main_thread+0xed0>
    beef:	90                   	nop
    bef0:	41 8b 75 00          	mov    0x0(%r13),%esi
    bef4:	8b 05 22 51 00 00    	mov    0x5122(%rip),%eax        # 1101c <fc12+0x4>
    befa:	89 f7                	mov    %esi,%edi
    befc:	29 c7                	sub    %eax,%edi
    befe:	83 ff 01             	cmp    $0x1,%edi
    bf01:	0f 85 13 f7 ff ff    	jne    b61a <fwp_main_thread+0xb4a>
    bf07:	48 89 e3             	mov    %rsp,%rbx
    bf0a:	85 c0                	test   %eax,%eax
    bf0c:	0f 84 6c 01 00 00    	je     c07e <fwp_main_thread+0x15ae>
    bf12:	89 f1                	mov    %esi,%ecx
    bf14:	ba 08 00 00 00       	mov    $0x8,%edx
    bf19:	48 c1 e1 03          	shl    $0x3,%rcx
    bf1d:	85 f6                	test   %esi,%esi
    bf1f:	48 89 e6             	mov    %rsp,%rsi
    bf22:	48 0f 45 d1          	cmovne %rcx,%rdx
    bf26:	49 89 d7             	mov    %rdx,%r15
    bf29:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    bf2d:	48 c1 ea 04          	shr    $0x4,%rdx
    bf31:	48 c1 e2 04          	shl    $0x4,%rdx
    bf35:	48 89 d7             	mov    %rdx,%rdi
    bf38:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    bf3f:	48 29 fe             	sub    %rdi,%rsi
    bf42:	48 39 f4             	cmp    %rsi,%rsp
    bf45:	74 15                	je     bf5c <fwp_main_thread+0x148c>
    bf47:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    bf4e:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    bf55:	00 00 
    bf57:	48 39 f4             	cmp    %rsi,%rsp
    bf5a:	75 eb                	jne    bf47 <fwp_main_thread+0x1477>
    bf5c:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    bf62:	48 29 d4             	sub    %rdx,%rsp
    bf65:	48 85 d2             	test   %rdx,%rdx
    bf68:	74 06                	je     bf70 <fwp_main_thread+0x14a0>
    bf6a:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    bf70:	4c 8d 24 c5 00 00 00 	lea    0x0(,%rax,8),%r12
    bf77:	00 
    bf78:	4c 89 f9             	mov    %r15,%rcx
    bf7b:	48 8d 35 9e 50 00 00 	lea    0x509e(%rip),%rsi        # 11020 <fwp_epfd>
    bf82:	48 89 e7             	mov    %rsp,%rdi
    bf85:	4c 89 e2             	mov    %r12,%rdx
    bf88:	e8 e3 75 ff ff       	call   3570 <__memcpy_chk@plt>
    bf8d:	4d 39 e7             	cmp    %r12,%r15
    bf90:	4c 89 f9             	mov    %r15,%rcx
    bf93:	4a 8d 3c 24          	lea    (%rsp,%r12,1),%rdi
    bf97:	49 0f 42 cc          	cmovb  %r12,%rcx
    bf9b:	48 8b b5 80 fe ff ff 	mov    -0x180(%rbp),%rsi
    bfa2:	ba 08 00 00 00       	mov    $0x8,%edx
    bfa7:	4c 29 e1             	sub    %r12,%rcx
    bfaa:	e8 c1 75 ff ff       	call   3570 <__memcpy_chk@plt>
    bfaf:	49 8b 45 18          	mov    0x18(%r13),%rax
    bfb3:	48 89 e7             	mov    %rsp,%rdi
    bfb6:	ff 10                	call   *(%rax)
    bfb8:	49 89 c7             	mov    %rax,%r15
    bfbb:	e9 ca 00 00 00       	jmp    c08a <fwp_main_thread+0x15ba>
    bfc0:	41 c7 42 04 00 00 00 	movl   $0x0,0x4(%r10)
    bfc7:	00 
    bfc8:	e9 86 fe ff ff       	jmp    be53 <fwp_main_thread+0x1383>
    bfcd:	66 85 c0             	test   %ax,%ax
    bfd0:	0f 85 c1 f6 ff ff    	jne    b697 <fwp_main_thread+0xbc7>
    bfd6:	e9 a8 f6 ff ff       	jmp    b683 <fwp_main_thread+0xbb3>
    bfdb:	48 8b 5a 08          	mov    0x8(%rdx),%rbx
    bfdf:	48 85 db             	test   %rbx,%rbx
    bfe2:	74 19                	je     bffd <fwp_main_thread+0x152d>
    bfe4:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
    bfe8:	49 29 db             	sub    %rbx,%r11
    bfeb:	49 39 c3             	cmp    %rax,%r11
    bfee:	72 0d                	jb     bffd <fwp_main_thread+0x152d>
    bff0:	4c 8d 1c 03          	lea    (%rbx,%rax,1),%r11
    bff4:	4c 89 5a 08          	mov    %r11,0x8(%rdx)
    bff8:	e9 97 fc ff ff       	jmp    bc94 <fwp_main_thread+0x11c4>
    bffd:	31 f6                	xor    %esi,%esi
    bfff:	89 8d 90 fe ff ff    	mov    %ecx,-0x170(%rbp)
    c005:	4c 89 85 a8 fe ff ff 	mov    %r8,-0x158(%rbp)
    c00c:	4c 89 95 b0 fe ff ff 	mov    %r10,-0x150(%rbp)
    c013:	e8 98 9a ff ff       	call   5ab0 <fwp_heap_alloc>
    c018:	8b 8d 90 fe ff ff    	mov    -0x170(%rbp),%ecx
    c01e:	4c 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%r8
    c025:	4c 8b 95 b0 fe ff ff 	mov    -0x150(%rbp),%r10
    c02c:	48 89 c3             	mov    %rax,%rbx
    c02f:	e9 08 fd ff ff       	jmp    bd3c <fwp_main_thread+0x126c>
    c034:	66 85 c0             	test   %ax,%ax
    c037:	0f 85 8b fe ff ff    	jne    bec8 <fwp_main_thread+0x13f8>
    c03d:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    c042:	0f 85 7b fe ff ff    	jne    bec3 <fwp_main_thread+0x13f3>
    c048:	4c 89 ef             	mov    %r13,%rdi
    c04b:	e8 20 93 ff ff       	call   5370 <fwp_rc_forget_slot>
    c050:	e9 6e fe ff ff       	jmp    bec3 <fwp_main_thread+0x13f3>
    c055:	66 85 c0             	test   %ax,%ax
    c058:	0f 85 e6 fd ff ff    	jne    be44 <fwp_main_thread+0x1374>
    c05e:	e9 d8 fd ff ff       	jmp    be3b <fwp_main_thread+0x136b>
    c063:	e8 e8 91 ff ff       	call   5250 <fwp_rc_wide_dup>
    c068:	48 8b 15 89 73 01 00 	mov    0x17389(%rip),%rdx        # 233f8 <fwp_fns>
    c06f:	e9 23 f6 ff ff       	jmp    b697 <fwp_main_thread+0xbc7>
    c074:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    c079:	e9 31 ec ff ff       	jmp    acaf <fwp_main_thread+0x1df>
    c07e:	48 8b bd 80 fe ff ff 	mov    -0x180(%rbp),%rdi
    c085:	ff 11                	call   *(%rcx)
    c087:	49 89 c7             	mov    %rax,%r15
    c08a:	48 89 dc             	mov    %rbx,%rsp
    c08d:	e9 a9 f9 ff ff       	jmp    ba3b <fwp_main_thread+0xf6b>
    c092:	66 85 c0             	test   %ax,%ax
    c095:	0f 85 41 f5 ff ff    	jne    b5dc <fwp_main_thread+0xb0c>
    c09b:	e9 28 f5 ff ff       	jmp    b5c8 <fwp_main_thread+0xaf8>
    c0a0:	66 85 c0             	test   %ax,%ax
    c0a3:	0f 85 a7 f4 ff ff    	jne    b550 <fwp_main_thread+0xa80>
    c0a9:	e9 88 f4 ff ff       	jmp    b536 <fwp_main_thread+0xa66>
    c0ae:	66 85 c0             	test   %ax,%ax
    c0b1:	0f 85 33 f3 ff ff    	jne    b3ea <fwp_main_thread+0x91a>
    c0b7:	e9 22 f3 ff ff       	jmp    b3de <fwp_main_thread+0x90e>
    c0bc:	66 85 c0             	test   %ax,%ax
    c0bf:	0f 85 cb f3 ff ff    	jne    b490 <fwp_main_thread+0x9c0>
    c0c5:	e9 ba f3 ff ff       	jmp    b484 <fwp_main_thread+0x9b4>
    c0ca:	48 89 d7             	mov    %rdx,%rdi
    c0cd:	48 89 95 b8 fe ff ff 	mov    %rdx,-0x148(%rbp)
    c0d4:	e8 97 92 ff ff       	call   5370 <fwp_rc_forget_slot>
    c0d9:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
    c0e0:	e9 c0 f1 ff ff       	jmp    b2a5 <fwp_main_thread+0x7d5>
    c0e5:	48 89 df             	mov    %rbx,%rdi
    c0e8:	e8 73 a4 ff ff       	call   6560 <fwp_rc_free_arr>
    c0ed:	e9 07 fb ff ff       	jmp    bbf9 <fwp_main_thread+0x1129>
    c0f2:	48 89 d7             	mov    %rdx,%rdi
    c0f5:	48 89 95 b8 fe ff ff 	mov    %rdx,-0x148(%rbp)
    c0fc:	e8 6f 92 ff ff       	call   5370 <fwp_rc_forget_slot>
    c101:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
    c108:	e9 36 fa ff ff       	jmp    bb43 <fwp_main_thread+0x1073>
    c10d:	48 89 df             	mov    %rbx,%rdi
    c110:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c117:	e8 54 92 ff ff       	call   5370 <fwp_rc_forget_slot>
    c11c:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    c123:	e9 bf f2 ff ff       	jmp    b3e7 <fwp_main_thread+0x917>
    c128:	66 85 c0             	test   %ax,%ax
    c12b:	0f 85 c8 fa ff ff    	jne    bbf9 <fwp_main_thread+0x1129>
    c131:	e9 a3 fa ff ff       	jmp    bbd9 <fwp_main_thread+0x1109>
    c136:	4c 89 e8             	mov    %r13,%rax
    c139:	48 c1 e8 11          	shr    $0x11,%rax
    c13d:	4c 31 e8             	xor    %r13,%rax
    c140:	48 89 c2             	mov    %rax,%rdx
    c143:	48 c1 ea 09          	shr    $0x9,%rdx
    c147:	48 31 d0             	xor    %rdx,%rax
    c14a:	0f b6 c0             	movzbl %al,%eax
    c14d:	49 8b 94 c6 48 14 00 	mov    0x1448(%r14,%rax,8),%rdx
    c154:	00 
    c155:	48 85 d2             	test   %rdx,%rdx
    c158:	75 0f                	jne    c169 <fwp_main_thread+0x1699>
    c15a:	eb 6f                	jmp    c1cb <fwp_main_thread+0x16fb>
    c15c:	0f 1f 40 00          	nopl   0x0(%rax)
    c160:	48 8b 50 10          	mov    0x10(%rax),%rdx
    c164:	48 85 d2             	test   %rdx,%rdx
    c167:	74 62                	je     c1cb <fwp_main_thread+0x16fb>
    c169:	48 89 d0             	mov    %rdx,%rax
    c16c:	4c 39 2a             	cmp    %r13,(%rdx)
    c16f:	75 ef                	jne    c160 <fwp_main_thread+0x1690>
    c171:	48 8b 42 08          	mov    0x8(%rdx),%rax
    c175:	48 83 e8 01          	sub    $0x1,%rax
    c179:	48 89 42 08          	mov    %rax,0x8(%rdx)
    c17d:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    c183:	0f 85 70 fa ff ff    	jne    bbf9 <fwp_main_thread+0x1129>
    c189:	4c 89 ef             	mov    %r13,%rdi
    c18c:	e8 df 91 ff ff       	call   5370 <fwp_rc_forget_slot>
    c191:	41 c6 45 00 fe       	movb   $0xfe,0x0(%r13)
    c196:	e9 5e fa ff ff       	jmp    bbf9 <fwp_main_thread+0x1129>
    c19b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    c1a0:	66 85 c0             	test   %ax,%ax
    c1a3:	0f 85 9d f9 ff ff    	jne    bb46 <fwp_main_thread+0x1076>
    c1a9:	e9 8c f9 ff ff       	jmp    bb3a <fwp_main_thread+0x106a>
    c1ae:	48 83 3d c2 55 01 00 	cmpq   $0x0,0x155c2(%rip)        # 21778 <fwp_root>
    c1b5:	00 
    c1b6:	c7 05 00 4f 01 00 00 	movl   $0x0,0x14f00(%rip)        # 210c0 <fwp_exit_code>
    c1bd:	00 00 00 
    c1c0:	0f 84 c4 ed ff ff    	je     af8a <fwp_main_thread+0x4ba>
    c1c6:	e9 85 75 ff ff       	jmp    3750 <fwp_main_thread.cold>
    c1cb:	48 8d 3d c6 15 00 00 	lea    0x15c6(%rip),%rdi        # d798 <_IO_stdin_used+0x798>
    c1d2:	e8 c9 7f ff ff       	call   41a0 <fwp_trap>
    c1d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    c1de:	00 00 
    c1e0:	48 89 df             	mov    %rbx,%rdi
    c1e3:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c1ea:	e8 81 91 ff ff       	call   5370 <fwp_rc_forget_slot>
    c1ef:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    c1f6:	e9 92 f2 ff ff       	jmp    b48d <fwp_main_thread+0x9bd>
    c1fb:	48 89 df             	mov    %rbx,%rdi
    c1fe:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c205:	e8 66 91 ff ff       	call   5370 <fwp_rc_forget_slot>
    c20a:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    c211:	e9 29 f3 ff ff       	jmp    b53f <fwp_main_thread+0xa6f>
    c216:	e8 35 90 ff ff       	call   5250 <fwp_rc_wide_dup>
    c21b:	e9 bc f3 ff ff       	jmp    b5dc <fwp_main_thread+0xb0c>
    c220:	e8 3b 72 ff ff       	call   3460 <__stack_chk_fail@plt>
    c225:	48 8d 3d c4 16 00 00 	lea    0x16c4(%rip),%rdi        # d8f0 <_IO_stdin_used+0x8f0>
    c22c:	e8 6f 7f ff ff       	call   41a0 <fwp_trap>
    c231:	48 89 c7             	mov    %rax,%rdi
    c234:	4c 8d 3d dd 4d 00 00 	lea    0x4ddd(%rip),%r15        # 11018 <fc12>
    c23b:	e8 a0 a2 ff ff       	call   64e0 <fwp_rc_share>
    c240:	48 8b bd 70 fe ff ff 	mov    -0x190(%rbp),%rdi
    c247:	e8 94 a2 ff ff       	call   64e0 <fwp_rc_share>
    c24c:	48 8b 85 80 fe ff ff 	mov    -0x180(%rbp),%rax
    c253:	c7 85 9c fe ff ff 01 	movl   $0x1,-0x164(%rbp)
    c25a:	00 00 00 
    c25d:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
    c264:	e9 ba f7 ff ff       	jmp    ba23 <fwp_main_thread+0xf53>
    c269:	48 8d 3d 78 0f 00 00 	lea    0xf78(%rip),%rdi        # d1e8 <_IO_stdin_used+0x1e8>
    c270:	e8 2b 7f ff ff       	call   41a0 <fwp_trap>
    c275:	48 89 c8             	mov    %rcx,%rax
    c278:	e9 79 ec ff ff       	jmp    aef6 <fwp_main_thread+0x426>
    c27d:	0f 1f 00             	nopl   (%rax)
    c280:	e8 2b 7a ff ff       	call   3cb0 <fwp_heap_oom>
    c285:	4c 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%r8
    c28c:	48 8b bd 70 fe ff ff 	mov    -0x190(%rbp),%rdi
    c293:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c29a:	e8 d1 a3 ff ff       	call   6670 <fwp_drop0>
    c29f:	48 8b bd b8 fe ff ff 	mov    -0x148(%rbp),%rdi
    c2a6:	e8 c5 a3 ff ff       	call   6670 <fwp_drop0>
    c2ab:	48 c7 05 f2 4d 00 00 	movq   $0x0,0x4df2(%rip)        # 110a8 <v.6>
    c2b2:	00 00 00 00 
    c2b6:	c7 05 f0 4d 00 00 01 	movl   $0x1,0x4df0(%rip)        # 110b0 <st.7>
    c2bd:	00 00 00 
    c2c0:	e9 2c e9 ff ff       	jmp    abf1 <fwp_main_thread+0x121>
    c2c5:	e9 86 74 ff ff       	jmp    3750 <fwp_main_thread.cold>
    c2ca:	e9 81 74 ff ff       	jmp    3750 <fwp_main_thread.cold>
    c2cf:	90                   	nop

000000000000c2d0 <__divmodti4>:
    c2d0:	f3 0f 1e fa          	endbr64
    c2d4:	55                   	push   %rbp
    c2d5:	49 89 f1             	mov    %rsi,%r9
    c2d8:	49 89 d2             	mov    %rdx,%r10
    c2db:	48 89 fe             	mov    %rdi,%rsi
    c2de:	49 89 cb             	mov    %rcx,%r11
    c2e1:	48 89 e5             	mov    %rsp,%rbp
    c2e4:	41 57                	push   %r15
    c2e6:	41 56                	push   %r14
    c2e8:	41 55                	push   %r13
    c2ea:	41 54                	push   %r12
    c2ec:	53                   	push   %rbx
    c2ed:	4c 89 c3             	mov    %r8,%rbx
    c2f0:	45 31 c0             	xor    %r8d,%r8d
    c2f3:	4d 85 c9             	test   %r9,%r9
    c2f6:	79 12                	jns    c30a <__divmodti4+0x3a>
    c2f8:	31 ff                	xor    %edi,%edi
    c2fa:	48 f7 de             	neg    %rsi
    c2fd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    c304:	4c 19 cf             	sbb    %r9,%rdi
    c307:	49 89 f9             	mov    %rdi,%r9
    c30a:	4c 89 d8             	mov    %r11,%rax
    c30d:	4d 85 db             	test   %r11,%r11
    c310:	0f 88 1a 01 00 00    	js     c430 <__divmodti4+0x160>
    c316:	4c 89 d9             	mov    %r11,%rcx
    c319:	49 89 f3             	mov    %rsi,%r11
    c31c:	75 62                	jne    c380 <__divmodti4+0xb0>
    c31e:	4d 89 c4             	mov    %r8,%r12
    c321:	4d 39 d1             	cmp    %r10,%r9
    c324:	0f 83 46 01 00 00    	jae    c470 <__divmodti4+0x1a0>
    c32a:	4c 89 d8             	mov    %r11,%rax
    c32d:	4c 89 ca             	mov    %r9,%rdx
    c330:	49 f7 f2             	div    %r10
    c333:	49 89 c3             	mov    %rax,%r11
    c336:	31 c0                	xor    %eax,%eax
    c338:	48 89 d6             	mov    %rdx,%rsi
    c33b:	31 ff                	xor    %edi,%edi
    c33d:	4c 89 d9             	mov    %r11,%rcx
    c340:	48 89 c2             	mov    %rax,%rdx
    c343:	48 89 c8             	mov    %rcx,%rax
    c346:	4d 85 e4             	test   %r12,%r12
    c349:	74 0a                	je     c355 <__divmodti4+0x85>
    c34b:	48 f7 d8             	neg    %rax
    c34e:	48 83 d2 00          	adc    $0x0,%rdx
    c352:	48 f7 da             	neg    %rdx
    c355:	4d 85 c0             	test   %r8,%r8
    c358:	74 0a                	je     c364 <__divmodti4+0x94>
    c35a:	48 f7 de             	neg    %rsi
    c35d:	48 83 d7 00          	adc    $0x0,%rdi
    c361:	48 f7 df             	neg    %rdi
    c364:	48 89 33             	mov    %rsi,(%rbx)
    c367:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    c36b:	5b                   	pop    %rbx
    c36c:	41 5c                	pop    %r12
    c36e:	41 5d                	pop    %r13
    c370:	41 5e                	pop    %r14
    c372:	41 5f                	pop    %r15
    c374:	5d                   	pop    %rbp
    c375:	c3                   	ret
    c376:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    c37d:	00 00 00 
    c380:	4d 89 c4             	mov    %r8,%r12
    c383:	49 39 c1             	cmp    %rax,%r9
    c386:	0f 82 ce 00 00 00    	jb     c45a <__divmodti4+0x18a>
    c38c:	31 ff                	xor    %edi,%edi
    c38e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    c393:	48 63 c7             	movslq %edi,%rax
    c396:	be 40 00 00 00       	mov    $0x40,%esi
    c39b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    c3a0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    c3a5:	48 29 c6             	sub    %rax,%rsi
    c3a8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    c3ad:	48 09 c8             	or     %rcx,%rax
    c3b0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    c3b5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    c3ba:	49 89 c6             	mov    %rax,%r14
    c3bd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    c3c1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    c3c6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    c3cb:	49 09 c1             	or     %rax,%r9
    c3ce:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    c3d2:	4c 89 c8             	mov    %r9,%rax
    c3d5:	49 f7 f6             	div    %r14
    c3d8:	48 89 d1             	mov    %rdx,%rcx
    c3db:	49 89 c3             	mov    %rax,%r11
    c3de:	49 89 c1             	mov    %rax,%r9
    c3e1:	49 f7 e2             	mul    %r10
    c3e4:	49 89 c6             	mov    %rax,%r14
    c3e7:	49 89 d2             	mov    %rdx,%r10
    c3ea:	48 39 d1             	cmp    %rdx,%rcx
    c3ed:	72 07                	jb     c3f6 <__divmodti4+0x126>
    c3ef:	75 17                	jne    c408 <__divmodti4+0x138>
    c3f1:	49 39 c7             	cmp    %rax,%r15
    c3f4:	73 12                	jae    c408 <__divmodti4+0x138>
    c3f6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    c3fa:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    c3fe:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    c402:	49 89 d2             	mov    %rdx,%r10
    c405:	49 89 c6             	mov    %rax,%r14
    c408:	4c 89 f8             	mov    %r15,%rax
    c40b:	4c 29 f0             	sub    %r14,%rax
    c40e:	4c 19 d1             	sbb    %r10,%rcx
    c411:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    c416:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    c41b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    c420:	48 09 c6             	or     %rax,%rsi
    c423:	48 89 cf             	mov    %rcx,%rdi
    c426:	31 c0                	xor    %eax,%eax
    c428:	4c 89 c9             	mov    %r9,%rcx
    c42b:	e9 10 ff ff ff       	jmp    c340 <__divmodti4+0x70>
    c430:	4c 89 d0             	mov    %r10,%rax
    c433:	4c 89 da             	mov    %r11,%rdx
    c436:	4d 89 c4             	mov    %r8,%r12
    c439:	49 89 f3             	mov    %rsi,%r11
    c43c:	48 f7 d8             	neg    %rax
    c43f:	49 f7 d4             	not    %r12
    c442:	48 83 d2 00          	adc    $0x0,%rdx
    c446:	49 89 c2             	mov    %rax,%r10
    c449:	48 f7 da             	neg    %rdx
    c44c:	48 89 d1             	mov    %rdx,%rcx
    c44f:	0f 84 cc fe ff ff    	je     c321 <__divmodti4+0x51>
    c455:	49 39 d1             	cmp    %rdx,%r9
    c458:	73 46                	jae    c4a0 <__divmodti4+0x1d0>
    c45a:	4c 89 cf             	mov    %r9,%rdi
    c45d:	31 c0                	xor    %eax,%eax
    c45f:	31 c9                	xor    %ecx,%ecx
    c461:	e9 da fe ff ff       	jmp    c340 <__divmodti4+0x70>
    c466:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    c46d:	00 00 00 
    c470:	4d 85 d2             	test   %r10,%r10
    c473:	75 0d                	jne    c482 <__divmodti4+0x1b2>
    c475:	b8 01 00 00 00       	mov    $0x1,%eax
    c47a:	31 d2                	xor    %edx,%edx
    c47c:	49 f7 f2             	div    %r10
    c47f:	49 89 c2             	mov    %rax,%r10
    c482:	4c 89 c8             	mov    %r9,%rax
    c485:	31 d2                	xor    %edx,%edx
    c487:	49 f7 f2             	div    %r10
    c48a:	49 89 c1             	mov    %rax,%r9
    c48d:	4c 89 d8             	mov    %r11,%rax
    c490:	49 f7 f2             	div    %r10
    c493:	49 89 c3             	mov    %rax,%r11
    c496:	4c 89 c8             	mov    %r9,%rax
    c499:	e9 9a fe ff ff       	jmp    c338 <__divmodti4+0x68>
    c49e:	66 90                	xchg   %ax,%ax
    c4a0:	45 31 f6             	xor    %r14d,%r14d
    c4a3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    c4a8:	44 89 f7             	mov    %r14d,%edi
    c4ab:	45 85 f6             	test   %r14d,%r14d
    c4ae:	0f 85 df fe ff ff    	jne    c393 <__divmodti4+0xc3>
    c4b4:	4c 39 ca             	cmp    %r9,%rdx
    c4b7:	72 17                	jb     c4d0 <__divmodti4+0x200>
    c4b9:	31 c9                	xor    %ecx,%ecx
    c4bb:	48 39 c6             	cmp    %rax,%rsi
    c4be:	73 10                	jae    c4d0 <__divmodti4+0x200>
    c4c0:	4c 89 cf             	mov    %r9,%rdi
    c4c3:	31 c0                	xor    %eax,%eax
    c4c5:	e9 76 fe ff ff       	jmp    c340 <__divmodti4+0x70>
    c4ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    c4d0:	4c 89 de             	mov    %r11,%rsi
    c4d3:	b9 01 00 00 00       	mov    $0x1,%ecx
    c4d8:	48 29 c6             	sub    %rax,%rsi
    c4db:	49 19 d1             	sbb    %rdx,%r9
    c4de:	eb e0                	jmp    c4c0 <__divmodti4+0x1f0>

000000000000c4e0 <atexit>:
    c4e0:	f3 0f 1e fa          	endbr64
    c4e4:	48 8b 15 1d 4b 00 00 	mov    0x4b1d(%rip),%rdx        # 11008 <__dso_handle>
    c4eb:	31 f6                	xor    %esi,%esi
    c4ed:	e9 6e 71 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000c4f4 <_fini>:
    c4f4:	f3 0f 1e fa          	endbr64
    c4f8:	48 83 ec 08          	sub    $0x8,%rsp
    c4fc:	48 83 c4 08          	add    $0x8,%rsp
    c500:	c3                   	ret
