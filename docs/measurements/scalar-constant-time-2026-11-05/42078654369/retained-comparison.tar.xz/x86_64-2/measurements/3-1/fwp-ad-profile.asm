
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 cf 00 00 	mov    0xcfd1(%rip),%rax        # ffe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 cd 00 00    	push   0xcdf2(%rip)        # fe18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 cd 00 00    	jmp    *0xcdf4(%rip)        # fe20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 cc 00 00    	jmp    *0xcc66(%rip)        # fff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e ca 00 00    	jmp    *0xca8e(%rip)        # fe28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 ca 00 00    	jmp    *0xca86(%rip)        # fe30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e ca 00 00    	jmp    *0xca7e(%rip)        # fe38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 ca 00 00    	jmp    *0xca76(%rip)        # fe40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e ca 00 00    	jmp    *0xca6e(%rip)        # fe48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # fe50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # fe58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # fe60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # fe68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # fe70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # fe78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # fe80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # fe88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # fe90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # fe98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # fea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # fea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # feb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # feb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # fec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # fec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # fed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # fed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # fee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # fee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # fef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # fef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # ff00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # ff08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # ff10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # ff18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # ff20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # ff28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # ff30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # ff38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ff40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ff48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ff50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ff58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ff60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ff68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ff70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ff78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # ff80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # ff88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # ff90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # ff98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # ffa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e c9 00 00    	jmp    *0xc90e(%rip)        # ffa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 c9 00 00    	jmp    *0xc906(%rip)        # ffb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe c8 00 00    	jmp    *0xc8fe(%rip)        # ffb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 c8 00 00    	jmp    *0xc8f6(%rip)        # ffc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee c8 00 00    	jmp    *0xc8ee(%rip)        # ffc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 89 00 00 	lea    0x89b8(%rip),%r9        # c0cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 89 00 00 	lea    0x89b5(%rip),%r8        # c0d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <fwp_main_thread.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>

0000000000003750 <main.cold>:
    3750:	e8 6b fc ff ff       	call   33c0 <abort@plt>
    3755:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    375c:	00 00 00 
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 ab 00 00 	lea    0xaba1(%rip),%rax        # e320 <fwp_fn_table>
    377f:	48 89 05 f2 6c 06 00 	mov    %rax,0x66cf2(%rip)        # 6a478 <fwp_fns>
    3786:	48 8b 05 93 c8 00 00 	mov    0xc893(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ec 6c 06 00 	mov    %rax,0x66cec(%rip)        # 6a480 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e 8b 00 00 	lea    0x8b4e(%rip),%rdi        # c2ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 c8 00 00 	mov    0xc818(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 af 5d 00 00 	lea    0x5daf(%rip),%rdx        # 9610 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 d6 fe ff ff    	jne    3750 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 ba fe ff ff    	jne    3750 <main.cold>
    3896:	48 8b 3d 83 c7 00 00 	mov    0xc783(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 d8 c7 01 00    	mov    0x1c7d8(%rip),%eax        # 20080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe 89 00 00 	lea    0x89fe(%rip),%rdi        # c2f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 56 93 00 00 	lea    0x9356(%rip),%rdi        # cc60 <_IO_stdin_used+0xc60>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 2f fe ff ff    	jne    3750 <main.cold>
    3921:	48 8d 3d 10 93 00 00 	lea    0x9310(%rip),%rdi        # cc38 <_IO_stdin_used+0xc38>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d d4 92 00 00 	lea    0x92d4(%rip),%rdi        # cc08 <_IO_stdin_used+0xc08>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d a0 92 00 00 	lea    0x92a0(%rip),%rdi        # cbe0 <_IO_stdin_used+0xbe0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b c6 00 00    	call   *0xc65b(%rip)        # ffd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 c6 00 00 	lea    0xc699(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 c6 00 00 	lea    0xc692(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e c6 00 00 	mov    0xc63e(%rip),%rax        # ffd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 c6 00 00 	lea    0xc669(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 c6 00 00 	lea    0xc662(%rip),%rsi        # 10020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d c6 00 00 	mov    0xc60d(%rip),%rax        # ffe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d c6 00 00 00 	cmpb   $0x0,0xc64d(%rip)        # 10048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea c5 00 00 	cmpq   $0x0,0xc5ea(%rip)        # fff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 c5 00 00 	mov    0xc5f6(%rip),%rdi        # 10008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 c6 00 00 01 	movb   $0x1,0xc625(%rip)        # 10048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 97 c5 04 00 	lea    0x4c597(%rip),%r8        # 501a0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 3b c5 04 00 	lea    0x4c53b(%rip),%rcx        # 50160 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 0f c5 04 00 	lea    0x4c50f(%rip),%rcx        # 50140 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 41 c5 04 00 	lea    0x4c541(%rip),%rcx        # 50180 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 50 c5 04 	movdqa 0x4c550(%rip),%xmm0        # 501b0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 38 c5 04 	paddq  0x4c538(%rip),%xmm0        # 501a0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 9f c4 04 00 	cmp    %rax,0x4c49f(%rip)        # 50120 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 95 c4 04 	movq   %xmm0,0x4c495(%rip)        # 50120 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 3e c4 01 00 	add    0x1c43e(%rip),%rdx        # 200f0 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 2c c4 01 00 	add    0x1c42c(%rip),%rax        # 200f0 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args173>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 79 67 06 00 	mov    0x66779(%rip),%rdi        # 6a480 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 04 c3 00 00 	mov    0xc304(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d f1 c2 00 00 	mov    0xc2f1(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 b1 4a 06 00 	mov    0x64ab1(%rip),%rax        # 68800 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 f9 43 06 00 	mov    0x643f9(%rip),%rax        # 681c8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 e5 43 06 00 	sub    0x643e5(%rip),%rax        # 681c0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 2d 8f 00 00 	lea    0x8f2d(%rip),%rsi        # cd40 <msg.4>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 81 00 00 	lea    0x81c5(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d f2 c1 00 00 	mov    0xc1f2(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 8b 5d 06 00 	mov    0x65d8b(%rip),%rax        # 69c10 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 84 5d 06 00 	lea    0x65d84(%rip),%r8        # 69c10 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 65 5d 06 00 	mov    0x65d65(%rip),%rbx        # 69bf8 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 75 5d 06 00 	mov    0x65d75(%rip),%rcx        # 69c18 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 11 5d 06 00 	mov    0x65d11(%rip),%rdi        # 69c00 <fwp_heap+0x13e0>
    3eef:	48 29 35 5a 5d 06 00 	sub    %rsi,0x65d5a(%rip)        # 69c50 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 ea 5c 06 00 	mov    0x65cea(%rip),%rax        # 69bf0 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d a0 5c 06 00 	add    0x65ca0(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ae 5c 06 00 	mov    0x65cae(%rip),%rsi        # 69c00 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 bc 5c 06 00 	mov    0x65cbc(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 6b 5c 06 00 	mov    %r12,0x65c6b(%rip)        # 69c00 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 59 5c 06 00 	mov    %rbp,0x65c59(%rip)        # 69bf8 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 3e 5c 06 00 	cmp    %rdi,0x65c3e(%rip)        # 69be8 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 35 5c 06 00 	mov    %rdi,0x65c35(%rip)        # 69be8 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 79 5c 06 00 	sub    %rdi,0x65c79(%rip)        # 69c50 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 21 5c 06 00 	mov    0x65c21(%rip),%rax        # 69c08 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 1a 5c 06 00 	lea    0x65c1a(%rip),%r8        # 69c08 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ff 86 00 00 	lea    0x86ff(%rip),%rdx        # c708 <_IO_stdin_used+0x708>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 22 c0 00 00 	mov    0xc022(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 7d bf 00 00 	mov    0xbf7d(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 7f 00 00 	lea    0x7f34(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d c9 46 06 00 	cmp    0x646c9(%rip),%rdi        # 68800 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 8f 46 06 00 	mov    0x6468f(%rip),%rax        # 687e0 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 6d 46 06 00 	mov    %rdi,0x6466d(%rip)        # 687e0 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 49 46 06 00 	mov    %rdi,0x64649(%rip)        # 687e8 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 19 80 00 00 	lea    0x8019(%rip),%rsi        # c1fa <_IO_stdin_used+0x1fa>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 7e 00 00 	lea    0x7e27(%rip),%rsi        # c01c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 76 bf 04 	movdqa 0x4bf76(%rip),%xmm0        # 501b0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 5e bf 04 	paddq  0x4bf5e(%rip),%xmm0        # 501a0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 84 be 01 00 	mov    0x1be84(%rip),%r8        # 200f8 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d 9e be 04 00 	mov    0x4be9e(%rip),%rcx        # 50120 <ad_raw_total_peak>
    4282:	48 8b 3d b7 bd 00 00 	mov    0xbdb7(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 c5 84 00 00 	lea    0x84c5(%rip),%rdx        # c758 <_IO_stdin_used+0x758>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d e1 be 04 00 	lea    0x4bee1(%rip),%r15        # 50180 <ad_raw_peak>
    429f:	4c 8d 35 9a be 04 00 	lea    0x4be9a(%rip),%r14        # 50140 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 7d 00 00 	lea    0x7d79(%rip),%rax        # c02b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 b9 00 	movq   0xb956(%rip),%xmm0        # fc10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d 9f be 04 00 	lea    0x4be9f(%rip),%r13        # 50160 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f 7d 00 00 	lea    0x7d6f(%rip),%rax        # c03c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 b9 00 	movq   0xb936(%rip),%xmm0        # fc18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 33 bd 00 00 	mov    0xbd33(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c 7d 00 00 	lea    0x7d0c(%rip),%rcx        # c020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 9d 84 00 00 	lea    0x849d(%rip),%rdx        # c7b8 <_IO_stdin_used+0x7b8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 04 bd 00 00 	mov    0xbd04(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 7c 00 00 	lea    0x7cf8(%rip),%rdi        # c045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d a6 bd 01 00 	cmpq   $0x0,0x1bda6(%rip)        # 20100 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 bd bd 01 00 	mov    0x1bdbd(%rip),%r8        # 20120 <ad_raw_checkpoints>
    4363:	4c 8b 0d be bd 01 00 	mov    0x1bdbe(%rip),%r9        # 20128 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d af bd 01 00 	lea    0x1bdaf(%rip),%rbx        # 20120 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 7c 00 00 	lea    0x7cf4(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 b1 bd 01 00 	mov    0x1bdb1(%rip),%rax        # 20130 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a 7c 00 00 	lea    0x7c9a(%rip),%r12        # c020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d 89 bc 00 00 	mov    0xbc89(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 39 84 00 00 	lea    0x8439(%rip),%rdx        # c7f8 <_IO_stdin_used+0x7f8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 33 bd 01 00 	cmp    0x1bd33(%rip),%rbp        # 20100 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 58 bc 00 00 	mov    0xbc58(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b 7c 00 00 	lea    0x7c5b(%rip),%rdi        # c059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 23 bc 00 00 	mov    0xbc23(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 94 83 00 00 	lea    0x8394(%rip),%rdx        # c7b8 <_IO_stdin_used+0x7b8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 7c 00 00 	lea    0x7c40(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d ea 82 00 00 	lea    0x82ea(%rip),%rdi        # c730 <_IO_stdin_used+0x730>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d c8 bb 00 00 	mov    0xbbc8(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df 7b 00 00 	lea    0x7bdf(%rip),%rdx        # c05e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d b0 bb 00 00 	mov    0xbbb0(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d c1 ba 00 00 	mov    0xbac1(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 7a 00 00 	lea    0x7a78(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 7a 00 00 	lea    0x7ac0(%rip),%rdi        # c06d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 7a 00 00 	lea    0x7a48(%rip),%rdi        # c087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d e8 81 00 00 	lea    0x81e8(%rip),%rdi        # c838 <_IO_stdin_used+0x838>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 20 87 00 	movdqa 0x8720(%rip),%xmm0        # cd90 <msg.4+0x50>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 aa 5d 06 00 	add    0x65daa(%rip),%rax        # 6a478 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 3c 81 00 00 	lea    0x813c(%rip),%rdi        # c860 <_IO_stdin_used+0x860>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 a5 b9 01 00 	cmp    %rax,0x1b9a5(%rip)        # 200e8 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 a0 b9 01 00 	add    0x1b9a0(%rip),%rax        # 200f0 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 25 81 00 00 	lea    0x8125(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 79 00 00 	lea    0x7920(%rip),%r8        # c0a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 77 00 00 	lea    0x7775(%rip),%r8        # c0b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 76 00 00 	lea    0x7612(%rip),%r8        # c0a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea 73 00 00 	lea    0x73ea(%rip),%rdi        # c0b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 54 75 00 00 	lea    0x7554(%rip),%rsi        # c242 <_IO_stdin_used+0x242>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d 85 4e 06 00 	mov    0x64e85(%rip),%r9        # 69be8 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 de 4e 06 00 	mov    0x64ede(%rip),%r8        # 69c48 <fwp_heap+0x1428>
    4d6a:	48 8d 15 6f 7b 00 00 	lea    0x7b6f(%rip),%rdx        # c8e0 <_IO_stdin_used+0x8e0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d c6 4e 06 00 	mov    0x64ec6(%rip),%rcx        # 69c40 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d d4 4e 06 	movsd  0x64ed4(%rip),%xmm1        # 69c60 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 c4 4e 06 	movsd  0x64ec4(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d a5 b2 00 00 	mov    0xb2a5(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 c8 7f 00 	movdqa 0x7fc8(%rip),%xmm0        # cda0 <msg.4+0x60>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 7f 49 06 00 	lea    0x6497f(%rip),%rax        # 69760 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 f1 7f 00 	movdqa 0x7ff1(%rip),%xmm2        # cde0 <msg.4+0xa0>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 25 49 06 00 	movaps %xmm0,0x64925(%rip)        # 69720 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 ad 7f 00 	movdqa 0x7fad(%rip),%xmm0        # cdb0 <msg.4+0x70>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 b3 4d 06 00 01 	movl   $0x1,0x64db3(%rip)        # 69bc4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 13 49 06 00 	movaps %xmm0,0x64913(%rip)        # 69730 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 9b 7f 00 	movdqa 0x7f9b(%rip),%xmm0        # cdc0 <msg.4+0x80>
    4e24:	00 
    4e25:	0f 29 05 14 49 06 00 	movaps %xmm0,0x64914(%rip)        # 69740 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 9c 7f 00 	movdqa 0x7f9c(%rip),%xmm0        # cdd0 <msg.4+0x90>
    4e33:	00 
    4e34:	0f 29 05 15 49 06 00 	movaps %xmm0,0x64915(%rip)        # 69750 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 95 39 06 00 	lea    0x63995(%rip),%r8        # 68820 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 b0 4c 06 00 	mov    %rax,0x64cb0(%rip)        # 69bd8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 8e 4c 06 00 	mov    %r12,0x64c8e(%rip)        # 69be0 <fwp_heap+0x13c0>
    4f52:	48 89 05 77 4c 06 00 	mov    %rax,0x64c77(%rip)        # 69bd0 <fwp_heap+0x13b0>
    4f59:	48 89 1d 90 4c 06 00 	mov    %rbx,0x64c90(%rip)        # 69bf0 <fwp_heap+0x13d0>
    4f60:	48 89 35 b9 4c 06 00 	mov    %rsi,0x64cb9(%rip)        # 69c20 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 71 00 00 	lea    0x7174(%rip),%rdi        # c0ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 98 4c 06 00 	mov    %rax,0x64c98(%rip)        # 69c18 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 1c 4c 06 00    	mov    %eax,0x64c1c(%rip)        # 69bc8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 0c 38 06 00 	mov    0x6380c(%rip),%r8        # 687e0 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d 3c 37 06 00 	mov    %rbx,0x6373c(%rip)        # 687e8 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 28 37 06 00 	mov    %r8,0x63728(%rip)        # 687e0 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <ad_raw_free.part.0>:
    50d0:	48 8d 0d e9 b0 04 00 	lea    0x4b0e9(%rip),%rcx        # 501c0 <ad_raw_blocks>
    50d7:	31 c0                	xor    %eax,%eax
    50d9:	48 89 ca             	mov    %rcx,%rdx
    50dc:	eb 12                	jmp    50f0 <ad_raw_free.part.0+0x20>
    50de:	66 90                	xchg   %ax,%ax
    50e0:	48 83 c0 01          	add    $0x1,%rax
    50e4:	48 83 c2 18          	add    $0x18,%rdx
    50e8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ee:	74 40                	je     5130 <ad_raw_free.part.0+0x60>
    50f0:	48 3b 3a             	cmp    (%rdx),%rdi
    50f3:	75 eb                	jne    50e0 <ad_raw_free.part.0+0x10>
    50f5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50f9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5101:	48 8d 0d 98 b0 04 00 	lea    0x4b098(%rip),%rcx        # 501a0 <ad_raw_live>
    5108:	8b 70 10             	mov    0x10(%rax),%esi
    510b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5112:	00 
    5113:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5117:	48 2b 50 08          	sub    0x8(%rax),%rdx
    511b:	0f 11 00             	movups %xmm0,(%rax)
    511e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5122:	e9 89 e2 ff ff       	jmp    33b0 <free@plt>
    5127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    512e:	00 00 
    5130:	48 83 ec 08          	sub    $0x8,%rsp
    5134:	48 8d 3d c2 6f 00 00 	lea    0x6fc2(%rip),%rdi        # c0fd <_IO_stdin_used+0xfd>
    513b:	e8 c0 ee ff ff       	call   4000 <ad_raw_fail>

0000000000005140 <fwp_tape_buffers_dispose>:
    5140:	53                   	push   %rbx
    5141:	48 89 fb             	mov    %rdi,%rbx
    5144:	48 8b 3f             	mov    (%rdi),%rdi
    5147:	48 85 ff             	test   %rdi,%rdi
    514a:	74 05                	je     5151 <fwp_tape_buffers_dispose+0x11>
    514c:	e8 7f ff ff ff       	call   50d0 <ad_raw_free.part.0>
    5151:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5155:	48 85 ff             	test   %rdi,%rdi
    5158:	74 05                	je     515f <fwp_tape_buffers_dispose+0x1f>
    515a:	e8 71 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    515f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5163:	48 85 ff             	test   %rdi,%rdi
    5166:	74 05                	je     516d <fwp_tape_buffers_dispose+0x2d>
    5168:	e8 63 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    516d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5171:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5178:	00 
    5179:	0f 11 03             	movups %xmm0,(%rbx)
    517c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5180:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5184:	5b                   	pop    %rbx
    5185:	c3                   	ret
    5186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    518d:	00 00 00 

0000000000005190 <ad_raw_realloc>:
    5190:	41 55                	push   %r13
    5192:	41 54                	push   %r12
    5194:	55                   	push   %rbp
    5195:	53                   	push   %rbx
    5196:	48 83 ec 08          	sub    $0x8,%rsp
    519a:	48 85 f6             	test   %rsi,%rsi
    519d:	0f 84 a6 00 00 00    	je     5249 <ad_raw_realloc+0xb9>
    51a3:	4c 8d 25 16 b0 04 00 	lea    0x4b016(%rip),%r12        # 501c0 <ad_raw_blocks>
    51aa:	48 89 f5             	mov    %rsi,%rbp
    51ad:	41 89 d5             	mov    %edx,%r13d
    51b0:	31 db                	xor    %ebx,%ebx
    51b2:	4c 89 e0             	mov    %r12,%rax
    51b5:	eb 1a                	jmp    51d1 <ad_raw_realloc+0x41>
    51b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51be:	00 00 
    51c0:	48 83 c3 01          	add    $0x1,%rbx
    51c4:	48 83 c0 18          	add    $0x18,%rax
    51c8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51cf:	74 4f                	je     5220 <ad_raw_realloc+0x90>
    51d1:	48 3b 38             	cmp    (%rax),%rdi
    51d4:	75 ea                	jne    51c0 <ad_raw_realloc+0x30>
    51d6:	48 85 ff             	test   %rdi,%rdi
    51d9:	74 0b                	je     51e6 <ad_raw_realloc+0x56>
    51db:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51df:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51e4:	75 57                	jne    523d <ad_raw_realloc+0xad>
    51e6:	48 89 ee             	mov    %rbp,%rsi
    51e9:	e8 c2 e3 ff ff       	call   35b0 <realloc@plt>
    51ee:	49 89 c2             	mov    %rax,%r10
    51f1:	48 85 c0             	test   %rax,%rax
    51f4:	74 16                	je     520c <ad_raw_realloc+0x7c>
    51f6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51fa:	44 89 e9             	mov    %r13d,%ecx
    51fd:	48 89 ea             	mov    %rbp,%rdx
    5200:	4c 89 d6             	mov    %r10,%rsi
    5203:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5207:	e8 f4 e9 ff ff       	call   3c00 <ad_raw_record>
    520c:	48 83 c4 08          	add    $0x8,%rsp
    5210:	4c 89 d0             	mov    %r10,%rax
    5213:	5b                   	pop    %rbx
    5214:	5d                   	pop    %rbp
    5215:	41 5c                	pop    %r12
    5217:	41 5d                	pop    %r13
    5219:	c3                   	ret
    521a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5220:	48 85 ff             	test   %rdi,%rdi
    5223:	48 8d 05 e8 6e 00 00 	lea    0x6ee8(%rip),%rax        # c112 <_IO_stdin_used+0x112>
    522a:	48 8d 15 cc 6e 00 00 	lea    0x6ecc(%rip),%rdx        # c0fd <_IO_stdin_used+0xfd>
    5231:	48 0f 45 c2          	cmovne %rdx,%rax
    5235:	48 89 c7             	mov    %rax,%rdi
    5238:	e8 c3 ed ff ff       	call   4000 <ad_raw_fail>
    523d:	48 8d 3d 04 6f 00 00 	lea    0x6f04(%rip),%rdi        # c148 <_IO_stdin_used+0x148>
    5244:	e8 b7 ed ff ff       	call   4000 <ad_raw_fail>
    5249:	48 8d 3d dd 6e 00 00 	lea    0x6edd(%rip),%rdi        # c12d <_IO_stdin_used+0x12d>
    5250:	e8 ab ed ff ff       	call   4000 <ad_raw_fail>
    5255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    525c:	00 00 00 00 

0000000000005260 <fwp_tape_buffers_release>:
    5260:	f3 0f 1e fa          	endbr64
    5264:	53                   	push   %rbx
    5265:	48 89 fb             	mov    %rdi,%rbx
    5268:	48 83 ec 10          	sub    $0x10,%rsp
    526c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5270:	48 85 c0             	test   %rax,%rax
    5273:	0f 88 d7 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5279:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    527d:	48 85 d2             	test   %rdx,%rdx
    5280:	0f 88 ca 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5286:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    528c:	0f 87 be 00 00 00    	ja     5350 <fwp_tape_buffers_release+0xf0>
    5292:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5296:	b8 00 00 08 00       	mov    $0x80000,%eax
    529b:	48 c1 e1 03          	shl    $0x3,%rcx
    529f:	48 29 c8             	sub    %rcx,%rax
    52a2:	48 c1 e8 03          	shr    $0x3,%rax
    52a6:	48 39 d0             	cmp    %rdx,%rax
    52a9:	0f 82 a1 00 00 00    	jb     5350 <fwp_tape_buffers_release+0xf0>
    52af:	48 8d 3d aa 6e 00 00 	lea    0x6eaa(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    52b6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52bb:	48 89 14 24          	mov    %rdx,(%rsp)
    52bf:	e8 cc e0 ff ff       	call   3390 <getenv@plt>
    52c4:	48 8b 14 24          	mov    (%rsp),%rdx
    52c8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 09                	je     52db <fwp_tape_buffers_release+0x7b>
    52d2:	80 38 30             	cmpb   $0x30,(%rax)
    52d5:	0f 84 05 01 00 00    	je     53e0 <fwp_tape_buffers_release+0x180>
    52db:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52df:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52e3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52e9:	77 71                	ja     535c <fwp_tape_buffers_release+0xfc>
    52eb:	48 8d 3d ae ad 01 00 	lea    0x1adae(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    52f2:	48 89 34 24          	mov    %rsi,(%rsp)
    52f6:	e8 45 fe ff ff       	call   5140 <fwp_tape_buffers_dispose>
    52fb:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52ff:	48 8b 34 24          	mov    (%rsp),%rsi
    5303:	0f 29 05 96 ad 01 00 	movaps %xmm0,0x1ad96(%rip)        # 200a0 <fwp_tape_workspace>
    530a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    530f:	48 89 35 72 ad 01 00 	mov    %rsi,0x1ad72(%rip)        # 20088 <fwp_tape_cached_bytes>
    5316:	0f 29 05 93 ad 01 00 	movaps %xmm0,0x1ad93(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    531d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5322:	0f 29 05 97 ad 01 00 	movaps %xmm0,0x1ad97(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    5329:	48 8b 43 30          	mov    0x30(%rbx),%rax
    532d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5331:	48 89 05 98 ad 01 00 	mov    %rax,0x1ad98(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    5338:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    533f:	00 
    5340:	0f 11 03             	movups %xmm0,(%rbx)
    5343:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5347:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    534b:	eb 1e                	jmp    536b <fwp_tape_buffers_release+0x10b>
    534d:	0f 1f 00             	nopl   (%rax)
    5350:	48 8d 3d 09 6e 00 00 	lea    0x6e09(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    5357:	e8 34 e0 ff ff       	call   3390 <getenv@plt>
    535c:	48 89 df             	mov    %rbx,%rdi
    535f:	e8 dc fd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    5364:	48 8b 35 1d ad 01 00 	mov    0x1ad1d(%rip),%rsi        # 20088 <fwp_tape_cached_bytes>
    536b:	48 6b 15 6d ad 01 00 	imul   $0x68,0x1ad6d(%rip),%rdx        # 200e0 <fwp_tapes_cap>
    5372:	68 
    5373:	48 3b 15 26 ae 04 00 	cmp    0x4ae26(%rip),%rdx        # 501a0 <ad_raw_live>
    537a:	75 73                	jne    53ef <fwp_tape_buffers_release+0x18f>
    537c:	48 8b 05 25 ae 04 00 	mov    0x4ae25(%rip),%rax        # 501a8 <ad_raw_live+0x8>
    5383:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5387:	48 01 d0             	add    %rdx,%rax
    538a:	48 03 05 1f ae 04 00 	add    0x4ae1f(%rip),%rax        # 501b0 <ad_raw_live+0x10>
    5391:	48 03 05 20 ae 04 00 	add    0x4ae20(%rip),%rax        # 501b8 <ad_raw_live+0x18>
    5398:	48 39 c8             	cmp    %rcx,%rax
    539b:	72 52                	jb     53ef <fwp_tape_buffers_release+0x18f>
    539d:	48 8b 0d 5c ad 01 00 	mov    0x1ad5c(%rip),%rcx        # 20100 <ad_raw_checkpoint_count>
    53a4:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    53ab:	74 4e                	je     53fb <fwp_tape_buffers_release+0x19b>
    53ad:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    53b1:	48 29 d0             	sub    %rdx,%rax
    53b4:	48 89 3d 45 ad 01 00 	mov    %rdi,0x1ad45(%rip)        # 20100 <ad_raw_checkpoint_count>
    53bb:	48 29 f0             	sub    %rsi,%rax
    53be:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53c2:	48 8d 0d 57 ad 01 00 	lea    0x1ad57(%rip),%rcx        # 20120 <ad_raw_checkpoints>
    53c9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53cd:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53d2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53d7:	48 83 c4 10          	add    $0x10,%rsp
    53db:	5b                   	pop    %rbx
    53dc:	c3                   	ret
    53dd:	0f 1f 00             	nopl   (%rax)
    53e0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53e4:	0f 84 72 ff ff ff    	je     535c <fwp_tape_buffers_release+0xfc>
    53ea:	e9 ec fe ff ff       	jmp    52db <fwp_tape_buffers_release+0x7b>
    53ef:	48 8d 3d 72 75 00 00 	lea    0x7572(%rip),%rdi        # c968 <_IO_stdin_used+0x968>
    53f6:	e8 05 ec ff ff       	call   4000 <ad_raw_fail>
    53fb:	48 8d 3d 6f 6d 00 00 	lea    0x6d6f(%rip),%rdi        # c171 <_IO_stdin_used+0x171>
    5402:	e8 f9 eb ff ff       	call   4000 <ad_raw_fail>
    5407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    540e:	00 00 

0000000000005410 <fwp_poll_events>:
    5410:	53                   	push   %rbx
    5411:	48 83 ec 20          	sub    $0x20,%rsp
    5415:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    541c:	00 00 
    541e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5423:	31 c0                	xor    %eax,%eax
    5425:	e8 96 f1 ff ff       	call   45c0 <fwp_now_ns>
    542a:	48 8b 1d a7 33 06 00 	mov    0x633a7(%rip),%rbx        # 687d8 <fwp_timers>
    5431:	48 85 db             	test   %rbx,%rbx
    5434:	0f 84 e6 00 00 00    	je     5520 <fwp_poll_events+0x110>
    543a:	48 89 c6             	mov    %rax,%rsi
    543d:	48 89 da             	mov    %rbx,%rdx
    5440:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5447:	eb 26                	jmp    546f <fwp_poll_events+0x5f>
    5449:	90                   	nop
    544a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5451:	00 00 00 00 
    5455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    545c:	00 00 00 00 
    5460:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5467:	48 89 c8             	mov    %rcx,%rax
    546a:	48 85 d2             	test   %rdx,%rdx
    546d:	74 31                	je     54a0 <fwp_poll_events+0x90>
    546f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5473:	48 85 c0             	test   %rax,%rax
    5476:	78 e8                	js     5460 <fwp_poll_events+0x50>
    5478:	48 39 c1             	cmp    %rax,%rcx
    547b:	7c e3                	jl     5460 <fwp_poll_events+0x50>
    547d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 1c                	je     54a5 <fwp_poll_events+0x95>
    5489:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    548d:	48 39 c1             	cmp    %rax,%rcx
    5490:	7c ce                	jl     5460 <fwp_poll_events+0x50>
    5492:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5499:	48 85 d2             	test   %rdx,%rdx
    549c:	75 d1                	jne    546f <fwp_poll_events+0x5f>
    549e:	66 90                	xchg   %ax,%ax
    54a0:	48 85 c0             	test   %rax,%rax
    54a3:	78 7b                	js     5520 <fwp_poll_events+0x110>
    54a5:	48 29 f0             	sub    %rsi,%rax
    54a8:	48 89 c1             	mov    %rax,%rcx
    54ab:	48 85 c0             	test   %rax,%rax
    54ae:	0f 8e 9c 00 00 00    	jle    5550 <fwp_poll_events+0x140>
    54b4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    54bb:	de 1b 43 
    54be:	48 f7 ea             	imul   %rdx
    54c1:	48 89 c8             	mov    %rcx,%rax
    54c4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54c8:	48 c1 fa 12          	sar    $0x12,%rdx
    54cc:	48 29 c2             	sub    %rax,%rdx
    54cf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54d6:	48 39 c1             	cmp    %rax,%rcx
    54d9:	0f 95 c0             	setne  %al
    54dc:	0f b6 c0             	movzbl %al,%eax
    54df:	48 01 d0             	add    %rdx,%rax
    54e2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54e8:	0f 8f 32 01 00 00    	jg     5620 <fwp_poll_events+0x210>
    54ee:	48 85 c0             	test   %rax,%rax
    54f1:	74 5d                	je     5550 <fwp_poll_events+0x140>
    54f3:	89 c1                	mov    %eax,%ecx
    54f5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54fc:	48 c1 e9 26          	shr    $0x26,%rcx
    5500:	48 63 d1             	movslq %ecx,%rdx
    5503:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5509:	29 c8                	sub    %ecx,%eax
    550b:	48 98                	cltq
    550d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5514:	e9 11 01 00 00       	jmp    562a <fwp_poll_events+0x21a>
    5519:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5520:	e8 db e7 ff ff       	call   3d00 <fwp_flush>
    5525:	ba 2b 00 00 00       	mov    $0x2b,%edx
    552a:	be 01 00 00 00       	mov    $0x1,%esi
    552f:	48 8b 0d 0a ab 00 00 	mov    0xab0a(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    5536:	48 8d 3d 5b 74 00 00 	lea    0x745b(%rip),%rdi        # c998 <_IO_stdin_used+0x998>
    553d:	e8 1e e1 ff ff       	call   3660 <fwrite@plt>
    5542:	bf 65 00 00 00       	mov    $0x65,%edi
    5547:	e8 04 e1 ff ff       	call   3650 <exit@plt>
    554c:	0f 1f 40 00          	nopl   0x0(%rax)
    5550:	e8 6b f0 ff ff       	call   45c0 <fwp_now_ns>
    5555:	48 89 c1             	mov    %rax,%rcx
    5558:	66 0f ef c0          	pxor   %xmm0,%xmm0
    555c:	eb 44                	jmp    55a2 <fwp_poll_events+0x192>
    555e:	66 90                	xchg   %ax,%ax
    5560:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5564:	75 33                	jne    5599 <fwp_poll_events+0x189>
    5566:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    556a:	75 2d                	jne    5599 <fwp_poll_events+0x189>
    556c:	48 8b 05 6d 32 06 00 	mov    0x6326d(%rip),%rax        # 687e0 <fwp_ready_tail>
    5573:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5577:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    557e:	00 00 00 00 
    5582:	48 85 c0             	test   %rax,%rax
    5585:	0f 84 05 01 00 00    	je     5690 <fwp_poll_events+0x280>
    558b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5592:	48 89 15 47 32 06 00 	mov    %rdx,0x63247(%rip)        # 687e0 <fwp_ready_tail>
    5599:	48 85 db             	test   %rbx,%rbx
    559c:	0f 84 be 00 00 00    	je     5660 <fwp_poll_events+0x250>
    55a2:	48 89 da             	mov    %rbx,%rdx
    55a5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    55ac:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    55b0:	7f e7                	jg     5599 <fwp_poll_events+0x189>
    55b2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    55b6:	74 2e                	je     55e6 <fwp_poll_events+0x1d6>
    55b8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    55bf:	48 85 c0             	test   %rax,%rax
    55c2:	0f 84 b8 00 00 00    	je     5680 <fwp_poll_events+0x270>
    55c8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55cf:	48 85 db             	test   %rbx,%rbx
    55d2:	74 07                	je     55db <fwp_poll_events+0x1cb>
    55d4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55db:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55df:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55e6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ea:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ee:	48 85 c0             	test   %rax,%rax
    55f1:	0f 84 69 ff ff ff    	je     5560 <fwp_poll_events+0x150>
    55f7:	48 39 c8             	cmp    %rcx,%rax
    55fa:	0f 8f 60 ff ff ff    	jg     5560 <fwp_poll_events+0x150>
    5600:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5604:	0f 85 56 ff ff ff    	jne    5560 <fwp_poll_events+0x150>
    560a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    560e:	75 89                	jne    5599 <fwp_poll_events+0x189>
    5610:	48 89 d7             	mov    %rdx,%rdi
    5613:	e8 18 eb ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5618:	e9 43 ff ff ff       	jmp    5560 <fwp_poll_events+0x150>
    561d:	0f 1f 00             	nopl   (%rax)
    5620:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5625:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    562a:	48 89 e7             	mov    %rsp,%rdi
    562d:	31 f6                	xor    %esi,%esi
    562f:	48 89 14 24          	mov    %rdx,(%rsp)
    5633:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5638:	e8 53 de ff ff       	call   3490 <nanosleep@plt>
    563d:	48 8b 1d 94 31 06 00 	mov    0x63194(%rip),%rbx        # 687d8 <fwp_timers>
    5644:	e8 77 ef ff ff       	call   45c0 <fwp_now_ns>
    5649:	48 89 c1             	mov    %rax,%rcx
    564c:	48 85 db             	test   %rbx,%rbx
    564f:	0f 85 03 ff ff ff    	jne    5558 <fwp_poll_events+0x148>
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5665:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    566c:	00 00 
    566e:	75 2c                	jne    569c <fwp_poll_events+0x28c>
    5670:	48 83 c4 20          	add    $0x20,%rsp
    5674:	5b                   	pop    %rbx
    5675:	c3                   	ret
    5676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    567d:	00 00 00 
    5680:	48 89 1d 51 31 06 00 	mov    %rbx,0x63151(%rip)        # 687d8 <fwp_timers>
    5687:	e9 43 ff ff ff       	jmp    55cf <fwp_poll_events+0x1bf>
    568c:	0f 1f 40 00          	nopl   0x0(%rax)
    5690:	48 89 15 51 31 06 00 	mov    %rdx,0x63151(%rip)        # 687e8 <fwp_ready_head>
    5697:	e9 f6 fe ff ff       	jmp    5592 <fwp_poll_events+0x182>
    569c:	e8 af dd ff ff       	call   3450 <__stack_chk_fail@plt>
    56a1:	0f 1f 40 00          	nopl   0x0(%rax)
    56a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ac:	00 00 00 00 

00000000000056b0 <fwp_rc_wide_dup>:
    56b0:	48 89 fa             	mov    %rdi,%rdx
    56b3:	48 8d 35 66 31 06 00 	lea    0x63166(%rip),%rsi        # 68820 <fwp_heap>
    56ba:	48 83 ec 18          	sub    $0x18,%rsp
    56be:	48 89 f9             	mov    %rdi,%rcx
    56c1:	48 c1 ea 11          	shr    $0x11,%rdx
    56c5:	48 31 fa             	xor    %rdi,%rdx
    56c8:	48 89 d0             	mov    %rdx,%rax
    56cb:	48 c1 e8 09          	shr    $0x9,%rax
    56cf:	48 31 c2             	xor    %rax,%rdx
    56d2:	0f b6 d2             	movzbl %dl,%edx
    56d5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56dc:	00 
    56dd:	49 8b 00             	mov    (%r8),%rax
    56e0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56e7:	00 00 
    56e9:	75 21                	jne    570c <fwp_rc_wide_dup+0x5c>
    56eb:	e9 98 00 00 00       	jmp    5788 <fwp_rc_wide_dup+0xd8>
    56f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56fc:	00 00 00 00 
    5700:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5704:	48 85 d2             	test   %rdx,%rdx
    5707:	74 2f                	je     5738 <fwp_rc_wide_dup+0x88>
    5709:	48 89 d0             	mov    %rdx,%rax
    570c:	48 3b 08             	cmp    (%rax),%rcx
    570f:	75 ef                	jne    5700 <fwp_rc_wide_dup+0x50>
    5711:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5714:	74 7c                	je     5792 <fwp_rc_wide_dup+0xe2>
    5716:	48 8b 50 08          	mov    0x8(%rax),%rdx
    571a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    571e:	0f 84 91 00 00 00    	je     57b5 <fwp_rc_wide_dup+0x105>
    5724:	48 83 c2 01          	add    $0x1,%rdx
    5728:	48 89 50 08          	mov    %rdx,0x8(%rax)
    572c:	48 83 c4 18          	add    $0x18,%rsp
    5730:	c3                   	ret
    5731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5738:	4c 8d 40 10          	lea    0x10(%rax),%r8
    573c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    573f:	75 68                	jne    57a9 <fwp_rc_wide_dup+0xf9>
    5741:	bf 18 00 00 00       	mov    $0x18,%edi
    5746:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    574b:	4c 89 04 24          	mov    %r8,(%rsp)
    574f:	e8 3c de ff ff       	call   3590 <malloc@plt>
    5754:	4c 8b 04 24          	mov    (%rsp),%r8
    5758:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    575d:	48 85 c0             	test   %rax,%rax
    5760:	74 5f                	je     57c1 <fwp_rc_wide_dup+0x111>
    5762:	48 89 08             	mov    %rcx,(%rax)
    5765:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    576c:	00 
    576d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5774:	00 
    5775:	49 89 00             	mov    %rax,(%r8)
    5778:	c6 01 ff             	movb   $0xff,(%rcx)
    577b:	48 83 05 e5 4c 06 00 	addq   $0x1,0x64ce5(%rip)        # 6a468 <fwp_heap+0x1c48>
    5782:	01 
    5783:	48 83 c4 18          	add    $0x18,%rsp
    5787:	c3                   	ret
    5788:	80 3f fe             	cmpb   $0xfe,(%rdi)
    578b:	75 13                	jne    57a0 <fwp_rc_wide_dup+0xf0>
    578d:	48 85 c0             	test   %rax,%rax
    5790:	74 af                	je     5741 <fwp_rc_wide_dup+0x91>
    5792:	48 8d 3d 2f 72 00 00 	lea    0x722f(%rip),%rdi        # c9c8 <_IO_stdin_used+0x9c8>
    5799:	e8 b2 ec ff ff       	call   4450 <fwp_trap>
    579e:	66 90                	xchg   %ax,%ax
    57a0:	48 85 c0             	test   %rax,%rax
    57a3:	0f 85 6d ff ff ff    	jne    5716 <fwp_rc_wide_dup+0x66>
    57a9:	48 8d 3d 40 72 00 00 	lea    0x7240(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    57b0:	e8 9b ec ff ff       	call   4450 <fwp_trap>
    57b5:	48 8d 3d d2 69 00 00 	lea    0x69d2(%rip),%rdi        # c18e <_IO_stdin_used+0x18e>
    57bc:	e8 8f ec ff ff       	call   4450 <fwp_trap>
    57c1:	e8 6a e6 ff ff       	call   3e30 <fwp_heap_oom>
    57c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57cd:	00 00 00 

00000000000057d0 <fwp_rc_forget_slot>:
    57d0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57d3:	74 0b                	je     57e0 <fwp_rc_forget_slot+0x10>
    57d5:	c3                   	ret
    57d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57dd:	00 00 00 
    57e0:	48 89 f8             	mov    %rdi,%rax
    57e3:	48 83 ec 08          	sub    $0x8,%rsp
    57e7:	48 89 fa             	mov    %rdi,%rdx
    57ea:	48 c1 e8 11          	shr    $0x11,%rax
    57ee:	48 31 f8             	xor    %rdi,%rax
    57f1:	48 89 c1             	mov    %rax,%rcx
    57f4:	48 c1 e9 09          	shr    $0x9,%rcx
    57f8:	48 31 c8             	xor    %rcx,%rax
    57fb:	48 8d 0d 1e 30 06 00 	lea    0x6301e(%rip),%rcx        # 68820 <fwp_heap>
    5802:	0f b6 c0             	movzbl %al,%eax
    5805:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    580c:	00 
    580d:	48 85 ff             	test   %rdi,%rdi
    5810:	74 3c                	je     584e <fwp_rc_forget_slot+0x7e>
    5812:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5819:	00 
    581a:	48 8b 01             	mov    (%rcx),%rax
    581d:	eb 11                	jmp    5830 <fwp_rc_forget_slot+0x60>
    581f:	90                   	nop
    5820:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5824:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5828:	48 85 ff             	test   %rdi,%rdi
    582b:	74 21                	je     584e <fwp_rc_forget_slot+0x7e>
    582d:	48 89 f8             	mov    %rdi,%rax
    5830:	48 3b 10             	cmp    (%rax),%rdx
    5833:	75 eb                	jne    5820 <fwp_rc_forget_slot+0x50>
    5835:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5839:	48 89 01             	mov    %rax,(%rcx)
    583c:	e8 6f db ff ff       	call   33b0 <free@plt>
    5841:	48 83 2d 1f 4c 06 00 	subq   $0x1,0x64c1f(%rip)        # 6a468 <fwp_heap+0x1c48>
    5848:	01 
    5849:	48 83 c4 08          	add    $0x8,%rsp
    584d:	c3                   	ret
    584e:	48 8d 3d 9b 71 00 00 	lea    0x719b(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    5855:	e8 f6 eb ff ff       	call   4450 <fwp_trap>
    585a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005860 <fwp_rc_prepare_chunk>:
    5860:	48 83 3d 00 4c 06 00 	cmpq   $0x0,0x64c00(%rip)        # 6a468 <fwp_heap+0x1c48>
    5867:	00 
    5868:	41 54                	push   %r12
    586a:	49 89 f4             	mov    %rsi,%r12
    586d:	55                   	push   %rbp
    586e:	48 89 fd             	mov    %rdi,%rbp
    5871:	53                   	push   %rbx
    5872:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5875:	0f 84 7d 00 00 00    	je     58f8 <fwp_rc_prepare_chunk+0x98>
    587b:	31 db                	xor    %ebx,%ebx
    587d:	85 c0                	test   %eax,%eax
    587f:	75 5f                	jne    58e0 <fwp_rc_prepare_chunk+0x80>
    5881:	48 85 f6             	test   %rsi,%rsi
    5884:	74 7c                	je     5902 <fwp_rc_prepare_chunk+0xa2>
    5886:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    588a:	e8 21 db ff ff       	call   33b0 <free@plt>
    588f:	90                   	nop
    5890:	be 01 00 00 00       	mov    $0x1,%esi
    5895:	4c 89 e7             	mov    %r12,%rdi
    5898:	e8 73 dc ff ff       	call   3510 <calloc@plt>
    589d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    58a1:	48 85 c0             	test   %rax,%rax
    58a4:	0f 85 87 00 00 00    	jne    5931 <fwp_rc_prepare_chunk+0xd1>
    58aa:	e8 81 e5 ff ff       	call   3e30 <fwp_heap_oom>
    58af:	90                   	nop
    58b0:	e8 1b ff ff ff       	call   57d0 <fwp_rc_forget_slot>
    58b5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58b8:	48 83 c3 01          	add    $0x1,%rbx
    58bc:	48 39 c3             	cmp    %rax,%rbx
    58bf:	73 37                	jae    58f8 <fwp_rc_prepare_chunk+0x98>
    58c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58c8:	00 00 
    58ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58d1:	00 00 00 00 
    58d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58dc:	00 00 00 00 
    58e0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58e4:	48 01 df             	add    %rbx,%rdi
    58e7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ea:	74 c4                	je     58b0 <fwp_rc_prepare_chunk+0x50>
    58ec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58ef:	48 83 c3 01          	add    $0x1,%rbx
    58f3:	48 39 c3             	cmp    %rax,%rbx
    58f6:	72 e8                	jb     58e0 <fwp_rc_prepare_chunk+0x80>
    58f8:	49 39 c4             	cmp    %rax,%r12
    58fb:	75 13                	jne    5910 <fwp_rc_prepare_chunk+0xb0>
    58fd:	4d 85 e4             	test   %r12,%r12
    5900:	75 46                	jne    5948 <fwp_rc_prepare_chunk+0xe8>
    5902:	5b                   	pop    %rbx
    5903:	5d                   	pop    %rbp
    5904:	41 5c                	pop    %r12
    5906:	c3                   	ret
    5907:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    590e:	00 00 
    5910:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5914:	48 29 05 55 4b 06 00 	sub    %rax,0x64b55(%rip)        # 6a470 <fwp_heap+0x1c50>
    591b:	e8 90 da ff ff       	call   33b0 <free@plt>
    5920:	4d 85 e4             	test   %r12,%r12
    5923:	0f 85 67 ff ff ff    	jne    5890 <fwp_rc_prepare_chunk+0x30>
    5929:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5930:	00 
    5931:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5935:	5b                   	pop    %rbx
    5936:	4c 01 25 33 4b 06 00 	add    %r12,0x64b33(%rip)        # 6a470 <fwp_heap+0x1c50>
    593d:	5d                   	pop    %rbp
    593e:	41 5c                	pop    %r12
    5940:	c3                   	ret
    5941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5948:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    594c:	5b                   	pop    %rbx
    594d:	4c 89 e2             	mov    %r12,%rdx
    5950:	31 f6                	xor    %esi,%esi
    5952:	5d                   	pop    %rbp
    5953:	41 5c                	pop    %r12
    5955:	e9 56 db ff ff       	jmp    34b0 <memset@plt>
    595a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005960 <fwp_heap_refill>:
    5960:	41 56                	push   %r14
    5962:	41 89 d6             	mov    %edx,%r14d
    5965:	41 55                	push   %r13
    5967:	41 89 f5             	mov    %esi,%r13d
    596a:	41 54                	push   %r12
    596c:	49 89 fc             	mov    %rdi,%r12
    596f:	bf 01 00 00 00       	mov    $0x1,%edi
    5974:	55                   	push   %rbp
    5975:	53                   	push   %rbx
    5976:	e8 f5 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    597b:	48 89 c3             	mov    %rax,%rbx
    597e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5982:	48 8b 05 8f 42 06 00 	mov    0x6428f(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    5989:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    598d:	48 8d 05 8c 2e 06 00 	lea    0x62e8c(%rip),%rax        # 68820 <fwp_heap>
    5994:	31 d2                	xor    %edx,%edx
    5996:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    599a:	48 89 ef             	mov    %rbp,%rdi
    599d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    59a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    59a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    59ac:	00 
    59ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    59b2:	f7 f1                	div    %ecx
    59b4:	31 d2                	xor    %edx,%edx
    59b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    59ba:	66 0f 6e c8          	movd   %eax,%xmm1
    59be:	89 c6                	mov    %eax,%esi
    59c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59c5:	48 01 c8             	add    %rcx,%rax
    59c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59cc:	48 f7 f1             	div    %rcx
    59cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59d4:	89 45 18             	mov    %eax,0x18(%rbp)
    59d7:	e8 84 fe ff ff       	call   5860 <fwp_rc_prepare_chunk>
    59dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59df:	48 89 d8             	mov    %rbx,%rax
    59e2:	48 c1 e0 10          	shl    $0x10,%rax
    59e6:	48 03 05 e3 41 06 00 	add    0x641e3(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    59ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59f6:	8b 55 08             	mov    0x8(%rbp),%edx
    59f9:	48 0f af d1          	imul   %rcx,%rdx
    59fd:	48 01 c2             	add    %rax,%rdx
    5a00:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a05:	5b                   	pop    %rbx
    5a06:	5d                   	pop    %rbp
    5a07:	41 5c                	pop    %r12
    5a09:	41 5d                	pop    %r13
    5a0b:	41 5e                	pop    %r14
    5a0d:	c3                   	ret
    5a0e:	66 90                	xchg   %ax,%ax

0000000000005a10 <fwp_mem_free>:
    5a10:	48 85 ff             	test   %rdi,%rdi
    5a13:	0f 84 17 02 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a19:	48 8b 35 b0 41 06 00 	mov    0x641b0(%rip),%rsi        # 69bd0 <fwp_heap+0x13b0>
    5a20:	48 8b 05 d1 41 06 00 	mov    0x641d1(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    5a27:	48 89 fa             	mov    %rdi,%rdx
    5a2a:	48 29 f2             	sub    %rsi,%rdx
    5a2d:	48 c1 e0 10          	shl    $0x10,%rax
    5a31:	48 39 c2             	cmp    %rax,%rdx
    5a34:	0f 83 f6 01 00 00    	jae    5c30 <fwp_mem_free+0x220>
    5a3a:	49 89 d1             	mov    %rdx,%r9
    5a3d:	49 c1 e9 10          	shr    $0x10,%r9
    5a41:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a45:	48 c1 e0 03          	shl    $0x3,%rax
    5a49:	49 89 c0             	mov    %rax,%r8
    5a4c:	4c 03 05 c5 41 06 00 	add    0x641c5(%rip),%r8        # 69c18 <fwp_heap+0x13f8>
    5a53:	0f 84 d7 01 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a59:	48 83 ec 38          	sub    $0x38,%rsp
    5a5d:	48 89 f9             	mov    %rdi,%rcx
    5a60:	41 0f b6 38          	movzbl (%r8),%edi
    5a64:	40 80 ff 01          	cmp    $0x1,%dil
    5a68:	74 16                	je     5a80 <fwp_mem_free+0x70>
    5a6a:	40 80 ff 02          	cmp    $0x2,%dil
    5a6e:	0f 84 94 00 00 00    	je     5b08 <fwp_mem_free+0xf8>
    5a74:	48 83 c4 38          	add    $0x38,%rsp
    5a78:	c3                   	ret
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a84:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a89:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a8e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a92:	4d 85 d2             	test   %r10,%r10
    5a95:	74 1d                	je     5ab4 <fwp_mem_free+0xa4>
    5a97:	0f b7 c1             	movzwl %cx,%eax
    5a9a:	31 d2                	xor    %edx,%edx
    5a9c:	48 f7 f7             	div    %rdi
    5a9f:	49 01 c2             	add    %rax,%r10
    5aa2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5aa6:	0f 84 44 01 00 00    	je     5bf0 <fwp_mem_free+0x1e0>
    5aac:	41 c6 02 00          	movb   $0x0,(%r10)
    5ab0:	41 8b 78 04          	mov    0x4(%r8),%edi
    5ab4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5abb:	49 63 c1             	movslq %r9d,%rax
    5abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ac2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ac6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5acb:	f2 0f 58 05 8d 41 06 	addsd  0x6418d(%rip),%xmm0        # 69c60 <fwp_heap+0x1440>
    5ad2:	00 
    5ad3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ad7:	48 8d 05 42 2d 06 00 	lea    0x62d42(%rip),%rax        # 68820 <fwp_heap>
    5ade:	48 01 d0             	add    %rdx,%rax
    5ae1:	48 8b 10             	mov    (%rax),%rdx
    5ae4:	48 f7 d2             	not    %rdx
    5ae7:	48 89 11             	mov    %rdx,(%rcx)
    5aea:	48 89 08             	mov    %rcx,(%rax)
    5aed:	48 29 3d 4c 41 06 00 	sub    %rdi,0x6414c(%rip)        # 69c40 <fwp_heap+0x1420>
    5af4:	f2 0f 11 05 64 41 06 	movsd  %xmm0,0x64164(%rip)        # 69c60 <fwp_heap+0x1440>
    5afb:	00 
    5afc:	48 83 c4 38          	add    $0x38,%rsp
    5b00:	c3                   	ret
    5b01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b08:	66 31 d2             	xor    %dx,%dx
    5b0b:	48 01 d6             	add    %rdx,%rsi
    5b0e:	48 39 f1             	cmp    %rsi,%rcx
    5b11:	0f 85 5d ff ff ff    	jne    5a74 <fwp_mem_free+0x64>
    5b17:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b1b:	48 29 15 1e 41 06 00 	sub    %rdx,0x6411e(%rip)        # 69c40 <fwp_heap+0x1420>
    5b22:	48 85 d2             	test   %rdx,%rdx
    5b25:	0f 88 a5 00 00 00    	js     5bd0 <fwp_mem_free+0x1c0>
    5b2b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b2f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b34:	f2 0f 58 05 24 41 06 	addsd  0x64124(%rip),%xmm0        # 69c60 <fwp_heap+0x1440>
    5b3b:	00 
    5b3c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b40:	f2 0f 11 05 18 41 06 	movsd  %xmm0,0x64118(%rip)        # 69c60 <fwp_heap+0x1440>
    5b47:	00 
    5b48:	48 85 d2             	test   %rdx,%rdx
    5b4b:	74 0c                	je     5b59 <fwp_mem_free+0x149>
    5b4d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b50:	0f 84 db 00 00 00    	je     5c31 <fwp_mem_free+0x221>
    5b56:	c6 02 00             	movb   $0x0,(%rdx)
    5b59:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b5d:	48 85 c9             	test   %rcx,%rcx
    5b60:	74 3e                	je     5ba0 <fwp_mem_free+0x190>
    5b62:	48 8b 15 af 40 06 00 	mov    0x640af(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    5b69:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b6d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b71:	48 01 d0             	add    %rdx,%rax
    5b74:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b78:	48 89 d6             	mov    %rdx,%rsi
    5b7b:	48 29 c6             	sub    %rax,%rsi
    5b7e:	83 e6 08             	and    $0x8,%esi
    5b81:	74 0d                	je     5b90 <fwp_mem_free+0x180>
    5b83:	c6 00 00             	movb   $0x0,(%rax)
    5b86:	48 83 c0 28          	add    $0x28,%rax
    5b8a:	48 39 c2             	cmp    %rax,%rdx
    5b8d:	74 11                	je     5ba0 <fwp_mem_free+0x190>
    5b8f:	90                   	nop
    5b90:	c6 00 00             	movb   $0x0,(%rax)
    5b93:	48 83 c0 50          	add    $0x50,%rax
    5b97:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b9b:	48 39 c2             	cmp    %rax,%rdx
    5b9e:	75 f0                	jne    5b90 <fwp_mem_free+0x180>
    5ba0:	48 01 0d a9 40 06 00 	add    %rcx,0x640a9(%rip)        # 69c50 <fwp_heap+0x1430>
    5ba7:	4c 3b 0d 62 40 06 00 	cmp    0x64062(%rip),%r9        # 69c10 <fwp_heap+0x13f0>
    5bae:	73 07                	jae    5bb7 <fwp_mem_free+0x1a7>
    5bb0:	4c 89 0d 59 40 06 00 	mov    %r9,0x64059(%rip)        # 69c10 <fwp_heap+0x13f0>
    5bb7:	4c 3b 0d 4a 40 06 00 	cmp    0x6404a(%rip),%r9        # 69c08 <fwp_heap+0x13e8>
    5bbe:	0f 83 b0 fe ff ff    	jae    5a74 <fwp_mem_free+0x64>
    5bc4:	4c 89 0d 3d 40 06 00 	mov    %r9,0x6403d(%rip)        # 69c08 <fwp_heap+0x13e8>
    5bcb:	e9 a4 fe ff ff       	jmp    5a74 <fwp_mem_free+0x64>
    5bd0:	48 89 d1             	mov    %rdx,%rcx
    5bd3:	83 e2 01             	and    $0x1,%edx
    5bd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bda:	48 d1 e9             	shr    $1,%rcx
    5bdd:	48 09 d1             	or     %rdx,%rcx
    5be0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5be5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5be9:	e9 46 ff ff ff       	jmp    5b34 <fwp_mem_free+0x124>
    5bee:	66 90                	xchg   %ax,%ax
    5bf0:	4c 89 d7             	mov    %r10,%rdi
    5bf3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bf8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bfd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c02:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c06:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c0b:	e8 c0 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c10:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c15:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c1a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c1f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c24:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c29:	e9 7e fe ff ff       	jmp    5aac <fwp_mem_free+0x9c>
    5c2e:	66 90                	xchg   %ax,%ax
    5c30:	c3                   	ret
    5c31:	48 89 d7             	mov    %rdx,%rdi
    5c34:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c39:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c3e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c48:	e8 83 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c4d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c52:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c57:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c5c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c61:	e9 f0 fe ff ff       	jmp    5b56 <fwp_mem_free+0x146>
    5c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c6d:	00 00 00 

0000000000005c70 <fwp_heap_alloc_big>:
    5c70:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c77:	00 00 40 
    5c7a:	41 57                	push   %r15
    5c7c:	41 56                	push   %r14
    5c7e:	41 55                	push   %r13
    5c80:	41 54                	push   %r12
    5c82:	55                   	push   %rbp
    5c83:	53                   	push   %rbx
    5c84:	48 83 ec 08          	sub    $0x8,%rsp
    5c88:	48 39 f8             	cmp    %rdi,%rax
    5c8b:	0f 82 fa 00 00 00    	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5c91:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c98:	49 89 fd             	mov    %rdi,%r13
    5c9b:	41 89 f6             	mov    %esi,%r14d
    5c9e:	48 c1 ed 10          	shr    $0x10,%rbp
    5ca2:	48 89 ef             	mov    %rbp,%rdi
    5ca5:	e8 c6 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5caa:	be 01 00 00 00       	mov    $0x1,%esi
    5caf:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5cb3:	49 89 c4             	mov    %rax,%r12
    5cb6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5cbd:	00 
    5cbe:	48 03 3d 53 3f 06 00 	add    0x63f53(%rip),%rdi        # 69c18 <fwp_heap+0x13f8>
    5cc5:	c6 07 02             	movb   $0x2,(%rdi)
    5cc8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5ccc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5ccf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cd3:	e8 88 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5cd8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cdc:	76 47                	jbe    5d25 <fwp_heap_alloc_big+0xb5>
    5cde:	4c 01 e5             	add    %r12,%rbp
    5ce1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ce8:	00 
    5ce9:	4c 8d 3d 30 2b 06 00 	lea    0x62b30(%rip),%r15        # 68820 <fwp_heap>
    5cf0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cf5:	49 c1 e6 03          	shl    $0x3,%r14
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d00:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d07:	31 f6                	xor    %esi,%esi
    5d09:	48 01 dd             	add    %rbx,%rbp
    5d0c:	48 83 c3 28          	add    $0x28,%rbx
    5d10:	48 89 ef             	mov    %rbp,%rdi
    5d13:	e8 48 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5d18:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d1c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d20:	49 39 de             	cmp    %rbx,%r14
    5d23:	75 db                	jne    5d00 <fwp_heap_alloc_big+0x90>
    5d25:	49 c1 e4 10          	shl    $0x10,%r12
    5d29:	4c 03 25 a0 3e 06 00 	add    0x63ea0(%rip),%r12        # 69bd0 <fwp_heap+0x13b0>
    5d30:	4c 89 ea             	mov    %r13,%rdx
    5d33:	31 f6                	xor    %esi,%esi
    5d35:	4c 89 e7             	mov    %r12,%rdi
    5d38:	e8 73 d7 ff ff       	call   34b0 <memset@plt>
    5d3d:	4c 89 e8             	mov    %r13,%rax
    5d40:	48 03 05 f9 3e 06 00 	add    0x63ef9(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5d47:	72 42                	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5d49:	48 39 05 f8 3e 06 00 	cmp    %rax,0x63ef8(%rip)        # 69c48 <fwp_heap+0x1428>
    5d50:	48 89 05 e9 3e 06 00 	mov    %rax,0x63ee9(%rip)        # 69c40 <fwp_heap+0x1420>
    5d57:	73 07                	jae    5d60 <fwp_heap_alloc_big+0xf0>
    5d59:	48 89 05 e8 3e 06 00 	mov    %rax,0x63ee8(%rip)        # 69c48 <fwp_heap+0x1428>
    5d60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d64:	4c 89 e0             	mov    %r12,%rax
    5d67:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d6c:	f2 0f 58 05 e4 3e 06 	addsd  0x63ee4(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    5d73:	00 
    5d74:	f2 0f 11 05 dc 3e 06 	movsd  %xmm0,0x63edc(%rip)        # 69c58 <fwp_heap+0x1438>
    5d7b:	00 
    5d7c:	48 83 c4 08          	add    $0x8,%rsp
    5d80:	5b                   	pop    %rbx
    5d81:	5d                   	pop    %rbp
    5d82:	41 5c                	pop    %r12
    5d84:	41 5d                	pop    %r13
    5d86:	41 5e                	pop    %r14
    5d88:	41 5f                	pop    %r15
    5d8a:	c3                   	ret
    5d8b:	e8 a0 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005d90 <fwp_heap_alloc_slow>:
    5d90:	53                   	push   %rbx
    5d91:	48 89 f9             	mov    %rdi,%rcx
    5d94:	41 89 f1             	mov    %esi,%r9d
    5d97:	48 83 ec 10          	sub    $0x10,%rsp
    5d9b:	8b 05 23 3e 06 00    	mov    0x63e23(%rip),%eax        # 69bc4 <fwp_heap+0x13a4>
    5da1:	85 c0                	test   %eax,%eax
    5da3:	0f 84 c7 00 00 00    	je     5e70 <fwp_heap_alloc_slow+0xe0>
    5da9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5db0:	0f 87 dd 00 00 00    	ja     5e93 <fwp_heap_alloc_slow+0x103>
    5db6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5dba:	48 8d 3d 5f 2a 06 00 	lea    0x62a5f(%rip),%rdi        # 68820 <fwp_heap>
    5dc1:	49 63 f1             	movslq %r9d,%rsi
    5dc4:	48 c1 e8 04          	shr    $0x4,%rax
    5dc8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5dcf:	00 00 
    5dd1:	41 0f b6 c2          	movzbl %r10b,%eax
    5dd5:	4c 89 d2             	mov    %r10,%rdx
    5dd8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5ddc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5de3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dee:	48 01 f8             	add    %rdi,%rax
    5df1:	4c 8b 00             	mov    (%rax),%r8
    5df4:	4d 85 c0             	test   %r8,%r8
    5df7:	0f 84 ab 00 00 00    	je     5ea8 <fwp_heap_alloc_slow+0x118>
    5dfd:	49 8b 10             	mov    (%r8),%rdx
    5e00:	48 f7 d2             	not    %rdx
    5e03:	48 89 10             	mov    %rdx,(%rax)
    5e06:	41 83 f9 01          	cmp    $0x1,%r9d
    5e0a:	4c 89 c7             	mov    %r8,%rdi
    5e0d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e11:	31 f6                	xor    %esi,%esi
    5e13:	48 89 ca             	mov    %rcx,%rdx
    5e16:	e8 95 d6 ff ff       	call   34b0 <memset@plt>
    5e1b:	49 89 c0             	mov    %rax,%r8
    5e1e:	48 89 d8             	mov    %rbx,%rax
    5e21:	48 03 05 18 3e 06 00 	add    0x63e18(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5e28:	0f 82 d9 00 00 00    	jb     5f07 <fwp_heap_alloc_slow+0x177>
    5e2e:	48 39 05 13 3e 06 00 	cmp    %rax,0x63e13(%rip)        # 69c48 <fwp_heap+0x1428>
    5e35:	48 89 05 04 3e 06 00 	mov    %rax,0x63e04(%rip)        # 69c40 <fwp_heap+0x1420>
    5e3c:	73 07                	jae    5e45 <fwp_heap_alloc_slow+0xb5>
    5e3e:	48 89 05 03 3e 06 00 	mov    %rax,0x63e03(%rip)        # 69c48 <fwp_heap+0x1428>
    5e45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e49:	4c 89 c0             	mov    %r8,%rax
    5e4c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e51:	f2 0f 58 05 ff 3d 06 	addsd  0x63dff(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 f7 3d 06 	movsd  %xmm0,0x63df7(%rip)        # 69c58 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	48 83 c4 10          	add    $0x10,%rsp
    5e65:	5b                   	pop    %rbx
    5e66:	c3                   	ret
    5e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e6e:	00 00 
    5e70:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e74:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e78:	e8 53 ef ff ff       	call   4dd0 <fwp_heap_init>
    5e7d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e81:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e86:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e8d:	0f 86 23 ff ff ff    	jbe    5db6 <fwp_heap_alloc_slow+0x26>
    5e93:	48 83 c4 10          	add    $0x10,%rsp
    5e97:	44 89 ce             	mov    %r9d,%esi
    5e9a:	48 89 cf             	mov    %rcx,%rdi
    5e9d:	5b                   	pop    %rbx
    5e9e:	e9 cd fd ff ff       	jmp    5c70 <fwp_heap_alloc_big>
    5ea3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ea8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5eac:	4d 85 c0             	test   %r8,%r8
    5eaf:	74 1f                	je     5ed0 <fwp_heap_alloc_slow+0x140>
    5eb1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5eb5:	4d 29 c3             	sub    %r8,%r11
    5eb8:	49 39 db             	cmp    %rbx,%r11
    5ebb:	72 13                	jb     5ed0 <fwp_heap_alloc_slow+0x140>
    5ebd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ec1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ec5:	e9 3c ff ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ed0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5ed7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5edb:	44 89 ca             	mov    %r9d,%edx
    5ede:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ee3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ee7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5eeb:	44 89 d6             	mov    %r10d,%esi
    5eee:	48 01 c7             	add    %rax,%rdi
    5ef1:	e8 6a fa ff ff       	call   5960 <fwp_heap_refill>
    5ef6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5efb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5eff:	49 89 c0             	mov    %rax,%r8
    5f02:	e9 ff fe ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5f07:	e8 24 df ff ff       	call   3e30 <fwp_heap_oom>
    5f0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f10 <fwp_heap_alloc>:
    5f10:	53                   	push   %rbx
    5f11:	48 89 fa             	mov    %rdi,%rdx
    5f14:	48 83 ec 10          	sub    $0x10,%rsp
    5f18:	8b 1d ca 45 06 00    	mov    0x645ca(%rip),%ebx        # 6a4e8 <iteration_active>
    5f1e:	8b 05 a0 3c 06 00    	mov    0x63ca0(%rip),%eax        # 69bc4 <fwp_heap+0x13a4>
    5f24:	85 db                	test   %ebx,%ebx
    5f26:	0f 85 04 01 00 00    	jne    6030 <fwp_heap_alloc+0x120>
    5f2c:	85 c0                	test   %eax,%eax
    5f2e:	0f 84 ac 01 00 00    	je     60e0 <fwp_heap_alloc+0x1d0>
    5f34:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f3b:	0f 87 9f 01 00 00    	ja     60e0 <fwp_heap_alloc+0x1d0>
    5f41:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f45:	48 8d 05 d4 28 06 00 	lea    0x628d4(%rip),%rax        # 68820 <fwp_heap>
    5f4c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f50:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f57:	00 
    5f58:	48 63 ce             	movslq %esi,%rcx
    5f5b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f62:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f69:	00 
    5f6a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f6e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f72:	48 01 c8             	add    %rcx,%rax
    5f75:	48 8b 08             	mov    (%rax),%rcx
    5f78:	48 85 c9             	test   %rcx,%rcx
    5f7b:	0f 84 ff 00 00 00    	je     6080 <fwp_heap_alloc+0x170>
    5f81:	48 8b 39             	mov    (%rcx),%rdi
    5f84:	48 f7 d7             	not    %rdi
    5f87:	48 89 38             	mov    %rdi,(%rax)
    5f8a:	83 fe 01             	cmp    $0x1,%esi
    5f8d:	48 89 cf             	mov    %rcx,%rdi
    5f90:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f95:	49 0f 45 d0          	cmovne %r8,%rdx
    5f99:	31 f6                	xor    %esi,%esi
    5f9b:	e8 10 d5 ff ff       	call   34b0 <memset@plt>
    5fa0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5fa5:	48 89 c1             	mov    %rax,%rcx
    5fa8:	4c 89 c0             	mov    %r8,%rax
    5fab:	48 03 05 8e 3c 06 00 	add    0x63c8e(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5fb2:	0f 82 35 01 00 00    	jb     60ed <fwp_heap_alloc+0x1dd>
    5fb8:	48 39 05 89 3c 06 00 	cmp    %rax,0x63c89(%rip)        # 69c48 <fwp_heap+0x1428>
    5fbf:	48 89 05 7a 3c 06 00 	mov    %rax,0x63c7a(%rip)        # 69c40 <fwp_heap+0x1420>
    5fc6:	73 07                	jae    5fcf <fwp_heap_alloc+0xbf>
    5fc8:	48 89 05 79 3c 06 00 	mov    %rax,0x63c79(%rip)        # 69c48 <fwp_heap+0x1428>
    5fcf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fd3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fd8:	f2 0f 58 05 78 3c 06 	addsd  0x63c78(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    5fdf:	00 
    5fe0:	f2 0f 11 05 70 3c 06 	movsd  %xmm0,0x63c70(%rip)        # 69c58 <fwp_heap+0x1438>
    5fe7:	00 
    5fe8:	85 db                	test   %ebx,%ebx
    5fea:	74 33                	je     601f <fwp_heap_alloc+0x10f>
    5fec:	48 8b 05 4d 3c 06 00 	mov    0x63c4d(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    5ff3:	48 85 c0             	test   %rax,%rax
    5ff6:	0f 88 ac 00 00 00    	js     60a8 <fwp_heap_alloc+0x198>
    5ffc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6000:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6005:	f2 0f 5c 05 bb 44 06 	subsd  0x644bb(%rip),%xmm0        # 6a4c8 <iteration_start_charge>
    600c:	00 
    600d:	66 0f 2f 05 ab 44 06 	comisd 0x644ab(%rip),%xmm0        # 6a4c0 <iteration_peak>
    6014:	00 
    6015:	76 08                	jbe    601f <fwp_heap_alloc+0x10f>
    6017:	f2 0f 11 05 a1 44 06 	movsd  %xmm0,0x644a1(%rip)        # 6a4c0 <iteration_peak>
    601e:	00 
    601f:	48 83 c4 10          	add    $0x10,%rsp
    6023:	48 89 c8             	mov    %rcx,%rax
    6026:	5b                   	pop    %rbx
    6027:	c3                   	ret
    6028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    602f:	00 
    6030:	85 f6                	test   %esi,%esi
    6032:	74 34                	je     6068 <fwp_heap_alloc+0x158>
    6034:	48 83 05 a4 44 06 00 	addq   $0x1,0x644a4(%rip)        # 6a4e0 <iteration_requests>
    603b:	01 
    603c:	48 01 3d 95 44 06 00 	add    %rdi,0x64495(%rip)        # 6a4d8 <iteration_bytes>
    6043:	85 c0                	test   %eax,%eax
    6045:	74 0d                	je     6054 <fwp_heap_alloc+0x144>
    6047:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    604e:	0f 86 ed fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6054:	48 89 d7             	mov    %rdx,%rdi
    6057:	e8 34 fd ff ff       	call   5d90 <fwp_heap_alloc_slow>
    605c:	48 89 c1             	mov    %rax,%rcx
    605f:	eb 8b                	jmp    5fec <fwp_heap_alloc+0xdc>
    6061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6068:	85 c0                	test   %eax,%eax
    606a:	74 0d                	je     6079 <fwp_heap_alloc+0x169>
    606c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6073:	0f 86 c8 fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6079:	31 f6                	xor    %esi,%esi
    607b:	eb d7                	jmp    6054 <fwp_heap_alloc+0x144>
    607d:	0f 1f 00             	nopl   (%rax)
    6080:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6084:	48 85 c9             	test   %rcx,%rcx
    6087:	74 0c                	je     6095 <fwp_heap_alloc+0x185>
    6089:	48 8b 78 10          	mov    0x10(%rax),%rdi
    608d:	48 29 cf             	sub    %rcx,%rdi
    6090:	4c 39 c7             	cmp    %r8,%rdi
    6093:	73 3b                	jae    60d0 <fwp_heap_alloc+0x1c0>
    6095:	48 89 d7             	mov    %rdx,%rdi
    6098:	e8 f3 fc ff ff       	call   5d90 <fwp_heap_alloc_slow>
    609d:	48 89 c1             	mov    %rax,%rcx
    60a0:	e9 43 ff ff ff       	jmp    5fe8 <fwp_heap_alloc+0xd8>
    60a5:	0f 1f 00             	nopl   (%rax)
    60a8:	48 89 c2             	mov    %rax,%rdx
    60ab:	83 e0 01             	and    $0x1,%eax
    60ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60b2:	48 d1 ea             	shr    $1,%rdx
    60b5:	48 09 c2             	or     %rax,%rdx
    60b8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    60bd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60c1:	e9 3f ff ff ff       	jmp    6005 <fwp_heap_alloc+0xf5>
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60d4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60d8:	e9 ad fe ff ff       	jmp    5f8a <fwp_heap_alloc+0x7a>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 83 c4 10          	add    $0x10,%rsp
    60e4:	48 89 d7             	mov    %rdx,%rdi
    60e7:	5b                   	pop    %rbx
    60e8:	e9 a3 fc ff ff       	jmp    5d90 <fwp_heap_alloc_slow>
    60ed:	e8 3e dd ff ff       	call   3e30 <fwp_heap_oom>
    60f2:	0f 1f 00             	nopl   (%rax)
    60f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60fc:	00 00 00 00 

0000000000006100 <fwp_data.part.0.constprop.0>:
    6100:	41 56                	push   %r14
    6102:	8b 05 bc 3a 06 00    	mov    0x63abc(%rip),%eax        # 69bc4 <fwp_heap+0x13a4>
    6108:	41 89 fe             	mov    %edi,%r14d
    610b:	41 55                	push   %r13
    610d:	44 8b 2d d4 43 06 00 	mov    0x643d4(%rip),%r13d        # 6a4e8 <iteration_active>
    6114:	41 54                	push   %r12
    6116:	49 89 f4             	mov    %rsi,%r12
    6119:	55                   	push   %rbp
    611a:	53                   	push   %rbx
    611b:	45 85 ed             	test   %r13d,%r13d
    611e:	0f 84 1c 01 00 00    	je     6240 <fwp_data.part.0.constprop.0+0x140>
    6124:	48 83 05 b4 43 06 00 	addq   $0x1,0x643b4(%rip)        # 6a4e0 <iteration_requests>
    612b:	01 
    612c:	48 83 05 a4 43 06 00 	addq   $0x18,0x643a4(%rip)        # 6a4d8 <iteration_bytes>
    6133:	18 
    6134:	85 c0                	test   %eax,%eax
    6136:	0f 84 8c 01 00 00    	je     62c8 <fwp_data.part.0.constprop.0+0x1c8>
    613c:	0f b6 05 7f 36 06 00 	movzbl 0x6367f(%rip),%eax        # 697c2 <fwp_heap+0xfa2>
    6143:	48 8d 15 d6 26 06 00 	lea    0x626d6(%rip),%rdx        # 68820 <fwp_heap>
    614a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6151:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6155:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6159:	48 8b 18             	mov    (%rax),%rbx
    615c:	48 85 db             	test   %rbx,%rbx
    615f:	0f 84 fb 00 00 00    	je     6260 <fwp_data.part.0.constprop.0+0x160>
    6165:	48 8b 13             	mov    (%rbx),%rdx
    6168:	48 f7 d2             	not    %rdx
    616b:	48 89 10             	mov    %rdx,(%rax)
    616e:	48 83 fd 18          	cmp    $0x18,%rbp
    6172:	76 1b                	jbe    618f <fwp_data.part.0.constprop.0+0x8f>
    6174:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6178:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    617c:	31 f6                	xor    %esi,%esi
    617e:	48 c1 e8 03          	shr    $0x3,%rax
    6182:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6189:	00 
    618a:	e8 21 d3 ff ff       	call   34b0 <memset@plt>
    618f:	48 89 e8             	mov    %rbp,%rax
    6192:	48 03 05 a7 3a 06 00 	add    0x63aa7(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    6199:	0f 82 3d 01 00 00    	jb     62dc <fwp_data.part.0.constprop.0+0x1dc>
    619f:	48 39 05 a2 3a 06 00 	cmp    %rax,0x63aa2(%rip)        # 69c48 <fwp_heap+0x1428>
    61a6:	48 89 05 93 3a 06 00 	mov    %rax,0x63a93(%rip)        # 69c40 <fwp_heap+0x1420>
    61ad:	73 07                	jae    61b6 <fwp_data.part.0.constprop.0+0xb6>
    61af:	48 89 05 92 3a 06 00 	mov    %rax,0x63a92(%rip)        # 69c48 <fwp_heap+0x1428>
    61b6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61ba:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    61bf:	f2 0f 58 05 91 3a 06 	addsd  0x63a91(%rip),%xmm0        # 69c58 <fwp_heap+0x1438>
    61c6:	00 
    61c7:	f2 0f 11 05 89 3a 06 	movsd  %xmm0,0x63a89(%rip)        # 69c58 <fwp_heap+0x1438>
    61ce:	00 
    61cf:	45 85 ed             	test   %r13d,%r13d
    61d2:	74 33                	je     6207 <fwp_data.part.0.constprop.0+0x107>
    61d4:	48 8b 05 65 3a 06 00 	mov    0x63a65(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    61db:	48 85 c0             	test   %rax,%rax
    61de:	0f 88 a4 00 00 00    	js     6288 <fwp_data.part.0.constprop.0+0x188>
    61e4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61e8:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    61ed:	f2 0f 5c 05 d3 42 06 	subsd  0x642d3(%rip),%xmm0        # 6a4c8 <iteration_start_charge>
    61f4:	00 
    61f5:	66 0f 2f 05 c3 42 06 	comisd 0x642c3(%rip),%xmm0        # 6a4c0 <iteration_peak>
    61fc:	00 
    61fd:	76 08                	jbe    6207 <fwp_data.part.0.constprop.0+0x107>
    61ff:	f2 0f 11 05 b9 42 06 	movsd  %xmm0,0x642b9(%rip)        # 6a4c0 <iteration_peak>
    6206:	00 
    6207:	b8 02 00 00 00       	mov    $0x2,%eax
    620c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6211:	66 0f 6e c8          	movd   %eax,%xmm1
    6215:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6219:	66 0f d6 03          	movq   %xmm0,(%rbx)
    621d:	49 8b 04 24          	mov    (%r12),%rax
    6221:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6225:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    622a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    622e:	48 89 d8             	mov    %rbx,%rax
    6231:	5b                   	pop    %rbx
    6232:	5d                   	pop    %rbp
    6233:	41 5c                	pop    %r12
    6235:	41 5d                	pop    %r13
    6237:	41 5e                	pop    %r14
    6239:	c3                   	ret
    623a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6240:	85 c0                	test   %eax,%eax
    6242:	0f 85 f4 fe ff ff    	jne    613c <fwp_data.part.0.constprop.0+0x3c>
    6248:	31 f6                	xor    %esi,%esi
    624a:	bf 18 00 00 00       	mov    $0x18,%edi
    624f:	e8 bc fc ff ff       	call   5f10 <fwp_heap_alloc>
    6254:	48 89 c3             	mov    %rax,%rbx
    6257:	eb ae                	jmp    6207 <fwp_data.part.0.constprop.0+0x107>
    6259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6260:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6264:	48 85 db             	test   %rbx,%rbx
    6267:	74 47                	je     62b0 <fwp_data.part.0.constprop.0+0x1b0>
    6269:	48 8b 50 10          	mov    0x10(%rax),%rdx
    626d:	48 29 da             	sub    %rbx,%rdx
    6270:	48 39 ea             	cmp    %rbp,%rdx
    6273:	72 3b                	jb     62b0 <fwp_data.part.0.constprop.0+0x1b0>
    6275:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6279:	48 89 50 08          	mov    %rdx,0x8(%rax)
    627d:	e9 ec fe ff ff       	jmp    616e <fwp_data.part.0.constprop.0+0x6e>
    6282:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6288:	48 89 c2             	mov    %rax,%rdx
    628b:	83 e0 01             	and    $0x1,%eax
    628e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6292:	48 d1 ea             	shr    $1,%rdx
    6295:	48 09 c2             	or     %rax,%rdx
    6298:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    629d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    62a1:	e9 47 ff ff ff       	jmp    61ed <fwp_data.part.0.constprop.0+0xed>
    62a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    62ad:	00 00 00 
    62b0:	31 f6                	xor    %esi,%esi
    62b2:	bf 18 00 00 00       	mov    $0x18,%edi
    62b7:	e8 54 fc ff ff       	call   5f10 <fwp_heap_alloc>
    62bc:	48 89 c3             	mov    %rax,%rbx
    62bf:	e9 0b ff ff ff       	jmp    61cf <fwp_data.part.0.constprop.0+0xcf>
    62c4:	0f 1f 40 00          	nopl   0x0(%rax)
    62c8:	31 f6                	xor    %esi,%esi
    62ca:	bf 18 00 00 00       	mov    $0x18,%edi
    62cf:	e8 3c fc ff ff       	call   5f10 <fwp_heap_alloc>
    62d4:	48 89 c3             	mov    %rax,%rbx
    62d7:	e9 f8 fe ff ff       	jmp    61d4 <fwp_data.part.0.constprop.0+0xd4>
    62dc:	e8 4f db ff ff       	call   3e30 <fwp_heap_oom>
    62e1:	0f 1f 40 00          	nopl   0x0(%rax)
    62e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62ec:	00 00 00 00 

00000000000062f0 <fwp_p_ad_push>:
    62f0:	41 57                	push   %r15
    62f2:	41 56                	push   %r14
    62f4:	41 55                	push   %r13
    62f6:	49 89 d5             	mov    %rdx,%r13
    62f9:	41 54                	push   %r12
    62fb:	49 89 fc             	mov    %rdi,%r12
    62fe:	55                   	push   %rbp
    62ff:	53                   	push   %rbx
    6300:	48 83 ec 38          	sub    $0x38,%rsp
    6304:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6309:	48 85 ff             	test   %rdi,%rdi
    630c:	79 09                	jns    6317 <fwp_p_ad_push+0x27>
    630e:	48 85 d2             	test   %rdx,%rdx
    6311:	0f 88 a9 01 00 00    	js     64c0 <fwp_p_ad_push+0x1d0>
    6317:	48 89 f8             	mov    %rdi,%rax
    631a:	48 89 0c 24          	mov    %rcx,(%rsp)
    631e:	48 09 d0             	or     %rdx,%rax
    6321:	0f 89 71 01 00 00    	jns    6498 <fwp_p_ad_push+0x1a8>
    6327:	48 89 f8             	mov    %rdi,%rax
    632a:	48 c1 f8 20          	sar    $0x20,%rax
    632e:	48 85 ff             	test   %rdi,%rdi
    6331:	79 24                	jns    6357 <fwp_p_ad_push+0x67>
    6333:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6338:	48 89 d0             	mov    %rdx,%rax
    633b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    6342:	00 
    6343:	49 89 d4             	mov    %rdx,%r12
    6346:	48 c1 f8 20          	sar    $0x20,%rax
    634a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    6351:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6357:	48 89 c7             	mov    %rax,%rdi
    635a:	e8 d1 e3 ff ff       	call   4730 <fwp_tape_of>
    635f:	48 89 c3             	mov    %rax,%rbx
    6362:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6367:	0f 85 6e 02 00 00    	jne    65db <fwp_p_ad_push+0x2eb>
    636d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    6371:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6378:	0f 8f 51 02 00 00    	jg     65cf <fwp_p_ad_push+0x2df>
    637e:	44 89 e0             	mov    %r12d,%eax
    6381:	4c 39 f8             	cmp    %r15,%rax
    6384:	0f 8d 39 02 00 00    	jge    65c3 <fwp_p_ad_push+0x2d3>
    638a:	4d 85 ed             	test   %r13,%r13
    638d:	78 0c                	js     639b <fwp_p_ad_push+0xab>
    638f:	44 89 e8             	mov    %r13d,%eax
    6392:	4c 39 f8             	cmp    %r15,%rax
    6395:	0f 8d 28 02 00 00    	jge    65c3 <fwp_p_ad_push+0x2d3>
    639b:	4d 89 fe             	mov    %r15,%r14
    639e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    63a2:	49 8d 46 01          	lea    0x1(%r14),%rax
    63a6:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    63ac:	0f 87 1d 02 00 00    	ja     65cf <fwp_p_ad_push+0x2df>
    63b2:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    63b6:	48 39 e8             	cmp    %rbp,%rax
    63b9:	0f 8e 31 01 00 00    	jle    64f0 <fwp_p_ad_push+0x200>
    63bf:	48 85 ed             	test   %rbp,%rbp
    63c2:	ba 40 00 00 00       	mov    $0x40,%edx
    63c7:	48 0f 44 ea          	cmove  %rdx,%rbp
    63cb:	48 39 e8             	cmp    %rbp,%rax
    63ce:	7e 20                	jle    63f0 <fwp_p_ad_push+0x100>
    63d0:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    63d7:	0f 8f 03 01 00 00    	jg     64e0 <fwp_p_ad_push+0x1f0>
    63dd:	48 01 ed             	add    %rbp,%rbp
    63e0:	48 39 e8             	cmp    %rbp,%rax
    63e3:	7f eb                	jg     63d0 <fwp_p_ad_push+0xe0>
    63e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    63ec:	00 00 00 00 
    63f0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    63f7:	00 
    63f8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    63fc:	ba 01 00 00 00       	mov    $0x1,%edx
    6401:	48 89 c6             	mov    %rax,%rsi
    6404:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6409:	e8 82 ed ff ff       	call   5190 <ad_raw_realloc>
    640e:	48 85 c0             	test   %rax,%rax
    6411:	0f 84 d0 01 00 00    	je     65e7 <fwp_p_ad_push+0x2f7>
    6417:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    641b:	48 89 ee             	mov    %rbp,%rsi
    641e:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6422:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6426:	48 c1 e6 04          	shl    $0x4,%rsi
    642a:	48 8d 04 90          	lea    (%rax,%rdx,4),%rax
    642e:	ba 02 00 00 00       	mov    $0x2,%edx
    6433:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6437:	e8 54 ed ff ff       	call   5190 <ad_raw_realloc>
    643c:	48 85 c0             	test   %rax,%rax
    643f:	0f 84 a2 01 00 00    	je     65e7 <fwp_p_ad_push+0x2f7>
    6445:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    6449:	48 89 43 30          	mov    %rax,0x30(%rbx)
    644d:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6454:	00 
    6455:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    645c:	00 
    645d:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
    6464:	00 
    6465:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    6469:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    646e:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6472:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    6476:	4d 85 f6             	test   %r14,%r14
    6479:	0f 85 e5 00 00 00    	jne    6564 <fwp_p_ad_push+0x274>
    647f:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6483:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    6487:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    648b:	48 01 d1             	add    %rdx,%rcx
    648e:	48 89 4b 28          	mov    %rcx,0x28(%rbx)
    6492:	eb 7c                	jmp    6510 <fwp_p_ad_push+0x220>
    6494:	0f 1f 40 00          	nopl   0x0(%rax)
    6498:	48 89 d0             	mov    %rdx,%rax
    649b:	48 c1 ff 20          	sar    $0x20,%rdi
    649f:	48 c1 f8 20          	sar    $0x20,%rax
    64a3:	48 39 c7             	cmp    %rax,%rdi
    64a6:	0f 84 ab fe ff ff    	je     6357 <fwp_p_ad_push+0x67>
    64ac:	48 8d 3d 65 65 00 00 	lea    0x6565(%rip),%rdi        # ca18 <_IO_stdin_used+0xa18>
    64b3:	e8 98 df ff ff       	call   4450 <fwp_trap>
    64b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    64bf:	00 
    64c0:	48 83 c4 38          	add    $0x38,%rsp
    64c4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    64cb:	5b                   	pop    %rbx
    64cc:	5d                   	pop    %rbp
    64cd:	41 5c                	pop    %r12
    64cf:	41 5d                	pop    %r13
    64d1:	41 5e                	pop    %r14
    64d3:	41 5f                	pop    %r15
    64d5:	c3                   	ret
    64d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    64dd:	00 00 00 
    64e0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    64e5:	e9 06 ff ff ff       	jmp    63f0 <fwp_p_ad_push+0x100>
    64ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    64f0:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    64f4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    64f8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    64ff:	00 
    6500:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6507:	00 
    6508:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
    650c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6510:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6516:	46 89 24 12          	mov    %r12d,(%rdx,%r10,1)
    651a:	4d 85 ed             	test   %r13,%r13
    651d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6522:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6528:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    652f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6533:	49 8d 47 01          	lea    0x1(%r15),%rax
    6537:	46 89 2c 11          	mov    %r13d,(%rcx,%r10,1)
    653b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6541:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6545:	48 83 c4 38          	add    $0x38,%rsp
    6549:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6550:	ff ff ff 
    6553:	4c 21 e0             	and    %r12,%rax
    6556:	5b                   	pop    %rbx
    6557:	5d                   	pop    %rbp
    6558:	4c 09 f8             	or     %r15,%rax
    655b:	41 5c                	pop    %r12
    655d:	41 5d                	pop    %r13
    655f:	41 5e                	pop    %r14
    6561:	41 5f                	pop    %r15
    6563:	c3                   	ret
    6564:	4c 89 ca             	mov    %r9,%rdx
    6567:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    656c:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    6571:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    6576:	e8 75 d0 ff ff       	call   35f0 <memmove@plt>
    657b:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    6580:	4c 03 73 30          	add    0x30(%rbx),%r14
    6584:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    6589:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    658d:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6591:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    6596:	48 03 7b 20          	add    0x20(%rbx),%rdi
    659a:	4c 89 d2             	mov    %r10,%rdx
    659d:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    65a2:	e8 49 d0 ff ff       	call   35f0 <memmove@plt>
    65a7:	48 8b 43 30          	mov    0x30(%rbx),%rax
    65ab:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    65af:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    65b4:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    65b9:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    65be:	e9 c0 fe ff ff       	jmp    6483 <fwp_p_ad_push+0x193>
    65c3:	48 8d 3d f8 5b 00 00 	lea    0x5bf8(%rip),%rdi        # c1c2 <_IO_stdin_used+0x1c2>
    65ca:	e8 81 de ff ff       	call   4450 <fwp_trap>
    65cf:	48 8d 3d d1 5b 00 00 	lea    0x5bd1(%rip),%rdi        # c1a7 <_IO_stdin_used+0x1a7>
    65d6:	e8 75 de ff ff       	call   4450 <fwp_trap>
    65db:	48 8d 3d 7e 64 00 00 	lea    0x647e(%rip),%rdi        # ca60 <_IO_stdin_used+0xa60>
    65e2:	e8 69 de ff ff       	call   4450 <fwp_trap>
    65e7:	48 89 df             	mov    %rbx,%rdi
    65ea:	e8 a1 d6 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    65ef:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    65f3:	48 85 ff             	test   %rdi,%rdi
    65f6:	74 05                	je     65fd <fwp_p_ad_push+0x30d>
    65f8:	e8 d3 ea ff ff       	call   50d0 <ad_raw_free.part.0>
    65fd:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6601:	48 85 ff             	test   %rdi,%rdi
    6604:	74 05                	je     660b <fwp_p_ad_push+0x31b>
    6606:	e8 c5 ea ff ff       	call   50d0 <ad_raw_free.part.0>
    660b:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    660f:	48 85 ff             	test   %rdi,%rdi
    6612:	74 05                	je     6619 <fwp_p_ad_push+0x329>
    6614:	e8 b7 ea ff ff       	call   50d0 <ad_raw_free.part.0>
    6619:	31 c9                	xor    %ecx,%ecx
    661b:	31 c0                	xor    %eax,%eax
    661d:	31 d2                	xor    %edx,%edx
    661f:	be 01 00 00 00       	mov    $0x1,%esi
    6624:	89 53 04             	mov    %edx,0x4(%rbx)
    6627:	66 0f ef c0          	pxor   %xmm0,%xmm0
    662b:	ba 13 00 00 00       	mov    $0x13,%edx
    6630:	48 8d 3d d1 59 00 00 	lea    0x59d1(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    6637:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    663b:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    663f:	48 8b 0d fa 99 00 00 	mov    0x99fa(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    6646:	48 89 43 40          	mov    %rax,0x40(%rbx)
    664a:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    664e:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    6652:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    6656:	e8 05 d0 ff ff       	call   3660 <fwrite@plt>
    665b:	31 ff                	xor    %edi,%edi
    665d:	e8 3e cf ff ff       	call   35a0 <fflush@plt>
    6662:	bf 66 00 00 00       	mov    $0x66,%edi
    6667:	e8 14 d0 ff ff       	call   3680 <_Exit@plt>
    666c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006670 <w120>:
    6670:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6674:	41 55                	push   %r13
    6676:	48 89 fa             	mov    %rdi,%rdx
    6679:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    667d:	41 54                	push   %r12
    667f:	49 89 fc             	mov    %rdi,%r12
    6682:	55                   	push   %rbp
    6683:	53                   	push   %rbx
    6684:	48 89 f3             	mov    %rsi,%rbx
    6687:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    668c:	48 89 f1             	mov    %rsi,%rcx
    668f:	48 83 ec 28          	sub    $0x28,%rsp
    6693:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6699:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    669f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    66a5:	e8 46 fc ff ff       	call   62f0 <fwp_p_ad_push>
    66aa:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    66b0:	48 89 da             	mov    %rbx,%rdx
    66b3:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    66b9:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    66c0:	00 f0 3f 
    66c3:	48 89 c7             	mov    %rax,%rdi
    66c6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    66cd:	00 f0 bf 
    66d0:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    66d5:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    66db:	e8 10 fc ff ff       	call   62f0 <fwp_p_ad_push>
    66e0:	f2 0f 10 05 80 66 00 	movsd  0x6680(%rip),%xmm0        # cd68 <msg.4+0x28>
    66e7:	00 
    66e8:	4c 89 e7             	mov    %r12,%rdi
    66eb:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    66f1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    66f8:	00 f0 3f 
    66fb:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6702:	49 89 c5             	mov    %rax,%r13
    6705:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    670c:	00 f0 bf 
    670f:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    6714:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    671a:	e8 d1 fb ff ff       	call   62f0 <fwp_p_ad_push>
    671f:	48 89 e9             	mov    %rbp,%rcx
    6722:	4c 89 ea             	mov    %r13,%rdx
    6725:	48 89 ee             	mov    %rbp,%rsi
    6728:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    672e:	4c 89 ef             	mov    %r13,%rdi
    6731:	49 89 c4             	mov    %rax,%r12
    6734:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6738:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    673e:	e8 ad fb ff ff       	call   62f0 <fwp_p_ad_push>
    6743:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6749:	f2 0f 59 1d 1f 66 00 	mulsd  0x661f(%rip),%xmm3        # cd70 <msg.4+0x30>
    6750:	00 
    6751:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6758:	00 59 40 
    675b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6760:	48 89 c2             	mov    %rax,%rdx
    6763:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    676a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6770:	e8 7b fb ff ff       	call   62f0 <fwp_p_ad_push>
    6775:	48 89 d9             	mov    %rbx,%rcx
    6778:	4c 89 e2             	mov    %r12,%rdx
    677b:	48 89 de             	mov    %rbx,%rsi
    677e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6784:	4c 89 e7             	mov    %r12,%rdi
    6787:	48 89 c5             	mov    %rax,%rbp
    678a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    678e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6794:	e8 57 fb ff ff       	call   62f0 <fwp_p_ad_push>
    6799:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    679f:	48 89 ea             	mov    %rbp,%rdx
    67a2:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    67a8:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    67af:	00 f0 3f 
    67b2:	48 89 c7             	mov    %rax,%rdi
    67b5:	48 89 ce             	mov    %rcx,%rsi
    67b8:	66 48 0f 7e db       	movq   %xmm3,%rbx
    67bd:	e8 2e fb ff ff       	call   62f0 <fwp_p_ad_push>
    67c2:	48 83 c4 28          	add    $0x28,%rsp
    67c6:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    67cb:	5b                   	pop    %rbx
    67cc:	5d                   	pop    %rbp
    67cd:	41 5c                	pop    %r12
    67cf:	41 5d                	pop    %r13
    67d1:	c3                   	ret
    67d2:	0f 1f 00             	nopl   (%rax)
    67d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    67dc:	00 00 00 00 

00000000000067e0 <fwp_rc_share>:
    67e0:	48 8b 05 11 34 06 00 	mov    0x63411(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    67e7:	48 2b 3d e2 33 06 00 	sub    0x633e2(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    67ee:	48 c1 e0 10          	shl    $0x10,%rax
    67f2:	48 39 c7             	cmp    %rax,%rdi
    67f5:	73 4a                	jae    6841 <fwp_rc_share+0x61>
    67f7:	48 89 f8             	mov    %rdi,%rax
    67fa:	48 c1 e8 10          	shr    $0x10,%rax
    67fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6802:	48 8b 05 0f 34 06 00 	mov    0x6340f(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    6809:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    680d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6811:	48 85 d2             	test   %rdx,%rdx
    6814:	74 2b                	je     6841 <fwp_rc_share+0x61>
    6816:	0f b6 08             	movzbl (%rax),%ecx
    6819:	80 f9 02             	cmp    $0x2,%cl
    681c:	74 2a                	je     6848 <fwp_rc_share+0x68>
    681e:	80 f9 01             	cmp    $0x1,%cl
    6821:	75 1e                	jne    6841 <fwp_rc_share+0x61>
    6823:	8b 48 18             	mov    0x18(%rax),%ecx
    6826:	0f b7 ff             	movzwl %di,%edi
    6829:	8b 40 1c             	mov    0x1c(%rax),%eax
    682c:	48 0f af f9          	imul   %rcx,%rdi
    6830:	48 c1 ef 20          	shr    $0x20,%rdi
    6834:	48 39 c7             	cmp    %rax,%rdi
    6837:	73 08                	jae    6841 <fwp_rc_share+0x61>
    6839:	48 01 fa             	add    %rdi,%rdx
    683c:	80 3a 00             	cmpb   $0x0,(%rdx)
    683f:	75 0d                	jne    684e <fwp_rc_share+0x6e>
    6841:	c3                   	ret
    6842:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6848:	66 85 ff             	test   %di,%di
    684b:	74 ef                	je     683c <fwp_rc_share+0x5c>
    684d:	c3                   	ret
    684e:	50                   	push   %rax
    684f:	48 8d 3d 3a 62 00 00 	lea    0x623a(%rip),%rdi        # ca90 <_IO_stdin_used+0xa90>
    6856:	e8 f5 db ff ff       	call   4450 <fwp_trap>
    685b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006860 <fwp_rc_free_obj>:
    6860:	48 8b 15 91 33 06 00 	mov    0x63391(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6867:	48 89 f8             	mov    %rdi,%rax
    686a:	48 2b 05 5f 33 06 00 	sub    0x6335f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    6871:	48 c1 e2 10          	shl    $0x10,%rdx
    6875:	48 39 d0             	cmp    %rdx,%rax
    6878:	73 5b                	jae    68d5 <fwp_rc_free_obj+0x75>
    687a:	48 89 c2             	mov    %rax,%rdx
    687d:	48 c1 ea 10          	shr    $0x10,%rdx
    6881:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6885:	48 8b 15 8c 33 06 00 	mov    0x6338c(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    688c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6890:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6894:	48 85 c9             	test   %rcx,%rcx
    6897:	74 3c                	je     68d5 <fwp_rc_free_obj+0x75>
    6899:	0f b6 32             	movzbl (%rdx),%esi
    689c:	40 80 fe 02          	cmp    $0x2,%sil
    68a0:	74 2e                	je     68d0 <fwp_rc_free_obj+0x70>
    68a2:	40 80 fe 01          	cmp    $0x1,%sil
    68a6:	75 2d                	jne    68d5 <fwp_rc_free_obj+0x75>
    68a8:	8b 72 18             	mov    0x18(%rdx),%esi
    68ab:	0f b7 c0             	movzwl %ax,%eax
    68ae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    68b1:	48 0f af c6          	imul   %rsi,%rax
    68b5:	48 c1 e8 20          	shr    $0x20,%rax
    68b9:	48 39 d0             	cmp    %rdx,%rax
    68bc:	73 17                	jae    68d5 <fwp_rc_free_obj+0x75>
    68be:	48 01 c1             	add    %rax,%rcx
    68c1:	80 39 01             	cmpb   $0x1,(%rcx)
    68c4:	75 0f                	jne    68d5 <fwp_rc_free_obj+0x75>
    68c6:	e9 45 f1 ff ff       	jmp    5a10 <fwp_mem_free>
    68cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    68d0:	66 85 c0             	test   %ax,%ax
    68d3:	74 ec                	je     68c1 <fwp_rc_free_obj+0x61>
    68d5:	c3                   	ret
    68d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    68dd:	00 00 00 

00000000000068e0 <fwp_rc_dup>:
    68e0:	f3 0f 1e fa          	endbr64
    68e4:	48 8b 05 0d 33 06 00 	mov    0x6330d(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    68eb:	48 2b 3d de 32 06 00 	sub    0x632de(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    68f2:	48 c1 e0 10          	shl    $0x10,%rax
    68f6:	48 39 c7             	cmp    %rax,%rdi
    68f9:	73 60                	jae    695b <fwp_rc_dup+0x7b>
    68fb:	48 89 f8             	mov    %rdi,%rax
    68fe:	48 c1 e8 10          	shr    $0x10,%rax
    6902:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6906:	48 8b 05 0b 33 06 00 	mov    0x6330b(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    690d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6911:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6915:	48 85 c0             	test   %rax,%rax
    6918:	74 41                	je     695b <fwp_rc_dup+0x7b>
    691a:	0f b6 0a             	movzbl (%rdx),%ecx
    691d:	80 f9 02             	cmp    $0x2,%cl
    6920:	74 3e                	je     6960 <fwp_rc_dup+0x80>
    6922:	80 f9 01             	cmp    $0x1,%cl
    6925:	75 34                	jne    695b <fwp_rc_dup+0x7b>
    6927:	8b 4a 18             	mov    0x18(%rdx),%ecx
    692a:	0f b7 ff             	movzwl %di,%edi
    692d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6930:	48 0f af f9          	imul   %rcx,%rdi
    6934:	48 c1 ef 20          	shr    $0x20,%rdi
    6938:	48 39 d7             	cmp    %rdx,%rdi
    693b:	73 1e                	jae    695b <fwp_rc_dup+0x7b>
    693d:	48 01 f8             	add    %rdi,%rax
    6940:	0f b6 10             	movzbl (%rax),%edx
    6943:	84 d2                	test   %dl,%dl
    6945:	74 14                	je     695b <fwp_rc_dup+0x7b>
    6947:	8b 0d 9b 3b 06 00    	mov    0x63b9b(%rip),%ecx        # 6a4e8 <iteration_active>
    694d:	85 c9                	test   %ecx,%ecx
    694f:	75 1f                	jne    6970 <fwp_rc_dup+0x90>
    6951:	80 fa fd             	cmp    $0xfd,%dl
    6954:	77 2a                	ja     6980 <fwp_rc_dup+0xa0>
    6956:	83 c2 01             	add    $0x1,%edx
    6959:	88 10                	mov    %dl,(%rax)
    695b:	c3                   	ret
    695c:	0f 1f 40 00          	nopl   0x0(%rax)
    6960:	66 85 ff             	test   %di,%di
    6963:	74 db                	je     6940 <fwp_rc_dup+0x60>
    6965:	c3                   	ret
    6966:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    696d:	00 00 00 
    6970:	48 83 05 58 3b 06 00 	addq   $0x1,0x63b58(%rip)        # 6a4d0 <iteration_retains>
    6977:	01 
    6978:	eb d7                	jmp    6951 <fwp_rc_dup+0x71>
    697a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6980:	48 89 c7             	mov    %rax,%rdi
    6983:	e9 28 ed ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    6988:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    698f:	00 

0000000000006990 <fwp_owned_entry173>:
    6990:	f3 0f 1e fa          	endbr64
    6994:	48 83 ec 38          	sub    $0x38,%rsp
    6998:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    699d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    69a4:	00 00 
    69a6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    69ab:	31 c0                	xor    %eax,%eax
    69ad:	48 8b 07             	mov    (%rdi),%rax
    69b0:	48 03 47 10          	add    0x10(%rdi),%rax
    69b4:	0f 80 c2 00 00 00    	jo     6a7c <fwp_owned_entry173+0xec>
    69ba:	66 48 0f 6e c8       	movq   %rax,%xmm1
    69bf:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    69c4:	31 ff                	xor    %edi,%edi
    69c6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    69ca:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    69cf:	e8 2c f7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    69d4:	48 8b 15 1d 32 06 00 	mov    0x6321d(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    69db:	48 89 c6             	mov    %rax,%rsi
    69de:	48 2b 05 eb 31 06 00 	sub    0x631eb(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    69e5:	48 c1 e2 10          	shl    $0x10,%rdx
    69e9:	48 39 d0             	cmp    %rdx,%rax
    69ec:	73 4f                	jae    6a3d <fwp_owned_entry173+0xad>
    69ee:	48 89 c2             	mov    %rax,%rdx
    69f1:	48 c1 ea 10          	shr    $0x10,%rdx
    69f5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    69f9:	48 8b 15 18 32 06 00 	mov    0x63218(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    6a00:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6a04:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6a08:	48 85 d2             	test   %rdx,%rdx
    6a0b:	74 30                	je     6a3d <fwp_owned_entry173+0xad>
    6a0d:	0f b6 39             	movzbl (%rcx),%edi
    6a10:	40 80 ff 02          	cmp    $0x2,%dil
    6a14:	74 42                	je     6a58 <fwp_owned_entry173+0xc8>
    6a16:	40 80 ff 01          	cmp    $0x1,%dil
    6a1a:	75 21                	jne    6a3d <fwp_owned_entry173+0xad>
    6a1c:	8b 79 18             	mov    0x18(%rcx),%edi
    6a1f:	0f b7 c0             	movzwl %ax,%eax
    6a22:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6a25:	48 0f af c7          	imul   %rdi,%rax
    6a29:	48 c1 e8 20          	shr    $0x20,%rax
    6a2d:	48 39 c8             	cmp    %rcx,%rax
    6a30:	73 0b                	jae    6a3d <fwp_owned_entry173+0xad>
    6a32:	48 01 c2             	add    %rax,%rdx
    6a35:	80 3a ff             	cmpb   $0xff,(%rdx)
    6a38:	74 26                	je     6a60 <fwp_owned_entry173+0xd0>
    6a3a:	c6 02 01             	movb   $0x1,(%rdx)
    6a3d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6a42:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6a49:	00 00 
    6a4b:	75 34                	jne    6a81 <fwp_owned_entry173+0xf1>
    6a4d:	48 89 f0             	mov    %rsi,%rax
    6a50:	48 83 c4 38          	add    $0x38,%rsp
    6a54:	c3                   	ret
    6a55:	0f 1f 00             	nopl   (%rax)
    6a58:	66 85 c0             	test   %ax,%ax
    6a5b:	75 e0                	jne    6a3d <fwp_owned_entry173+0xad>
    6a5d:	eb d6                	jmp    6a35 <fwp_owned_entry173+0xa5>
    6a5f:	90                   	nop
    6a60:	48 89 d7             	mov    %rdx,%rdi
    6a63:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6a68:	48 89 14 24          	mov    %rdx,(%rsp)
    6a6c:	e8 5f ed ff ff       	call   57d0 <fwp_rc_forget_slot>
    6a71:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6a76:	48 8b 14 24          	mov    (%rsp),%rdx
    6a7a:	eb be                	jmp    6a3a <fwp_owned_entry173+0xaa>
    6a7c:	e8 7f cc ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6a81:	e8 ca c9 ff ff       	call   3450 <__stack_chk_fail@plt>
    6a86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a8d:	00 00 00 

0000000000006a90 <e173>:
    6a90:	f3 0f 1e fa          	endbr64
    6a94:	53                   	push   %rbx
    6a95:	48 83 ec 30          	sub    $0x30,%rsp
    6a99:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6a9e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6aa5:	00 00 
    6aa7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6aac:	31 c0                	xor    %eax,%eax
    6aae:	48 8b 07             	mov    (%rdi),%rax
    6ab1:	48 03 47 10          	add    0x10(%rdi),%rax
    6ab5:	0f 80 c9 00 00 00    	jo     6b84 <e173+0xf4>
    6abb:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6ac0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6ac5:	31 ff                	xor    %edi,%edi
    6ac7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6acb:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6ad0:	e8 2b f6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    6ad5:	48 8b 15 1c 31 06 00 	mov    0x6311c(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6adc:	48 89 c3             	mov    %rax,%rbx
    6adf:	48 2b 05 ea 30 06 00 	sub    0x630ea(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    6ae6:	48 c1 e2 10          	shl    $0x10,%rdx
    6aea:	48 39 d0             	cmp    %rdx,%rax
    6aed:	73 4f                	jae    6b3e <e173+0xae>
    6aef:	48 89 c2             	mov    %rax,%rdx
    6af2:	48 c1 ea 10          	shr    $0x10,%rdx
    6af6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6afa:	48 8b 15 17 31 06 00 	mov    0x63117(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    6b01:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6b05:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6b09:	48 85 d2             	test   %rdx,%rdx
    6b0c:	74 30                	je     6b3e <e173+0xae>
    6b0e:	0f b6 31             	movzbl (%rcx),%esi
    6b11:	40 80 fe 02          	cmp    $0x2,%sil
    6b15:	74 49                	je     6b60 <e173+0xd0>
    6b17:	40 80 fe 01          	cmp    $0x1,%sil
    6b1b:	75 21                	jne    6b3e <e173+0xae>
    6b1d:	8b 71 18             	mov    0x18(%rcx),%esi
    6b20:	0f b7 c0             	movzwl %ax,%eax
    6b23:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6b26:	48 0f af c6          	imul   %rsi,%rax
    6b2a:	48 c1 e8 20          	shr    $0x20,%rax
    6b2e:	48 39 c8             	cmp    %rcx,%rax
    6b31:	73 0b                	jae    6b3e <e173+0xae>
    6b33:	48 01 c2             	add    %rax,%rdx
    6b36:	80 3a ff             	cmpb   $0xff,(%rdx)
    6b39:	74 35                	je     6b70 <e173+0xe0>
    6b3b:	c6 02 01             	movb   $0x1,(%rdx)
    6b3e:	48 89 df             	mov    %rbx,%rdi
    6b41:	e8 9a fc ff ff       	call   67e0 <fwp_rc_share>
    6b46:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6b4b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6b52:	00 00 
    6b54:	75 33                	jne    6b89 <e173+0xf9>
    6b56:	48 83 c4 30          	add    $0x30,%rsp
    6b5a:	48 89 d8             	mov    %rbx,%rax
    6b5d:	5b                   	pop    %rbx
    6b5e:	c3                   	ret
    6b5f:	90                   	nop
    6b60:	66 85 c0             	test   %ax,%ax
    6b63:	75 d9                	jne    6b3e <e173+0xae>
    6b65:	eb cf                	jmp    6b36 <e173+0xa6>
    6b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6b6e:	00 00 
    6b70:	48 89 d7             	mov    %rdx,%rdi
    6b73:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6b78:	e8 53 ec ff ff       	call   57d0 <fwp_rc_forget_slot>
    6b7d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6b82:	eb b7                	jmp    6b3b <e173+0xab>
    6b84:	e8 77 cb ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6b89:	e8 c2 c8 ff ff       	call   3450 <__stack_chk_fail@plt>
    6b8e:	66 90                	xchg   %ax,%ax

0000000000006b90 <fwp_closure_drop>:
    6b90:	48 8b 15 61 30 06 00 	mov    0x63061(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    6b97:	48 89 f8             	mov    %rdi,%rax
    6b9a:	48 2b 05 2f 30 06 00 	sub    0x6302f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    6ba1:	48 c1 e2 10          	shl    $0x10,%rdx
    6ba5:	48 39 d0             	cmp    %rdx,%rax
    6ba8:	73 6b                	jae    6c15 <fwp_closure_drop+0x85>
    6baa:	48 89 c2             	mov    %rax,%rdx
    6bad:	48 c1 ea 10          	shr    $0x10,%rdx
    6bb1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6bb5:	48 8b 15 5c 30 06 00 	mov    0x6305c(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    6bbc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6bc0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6bc4:	48 85 d2             	test   %rdx,%rdx
    6bc7:	74 4c                	je     6c15 <fwp_closure_drop+0x85>
    6bc9:	0f b6 31             	movzbl (%rcx),%esi
    6bcc:	40 80 fe 02          	cmp    $0x2,%sil
    6bd0:	74 3e                	je     6c10 <fwp_closure_drop+0x80>
    6bd2:	40 80 fe 01          	cmp    $0x1,%sil
    6bd6:	75 3d                	jne    6c15 <fwp_closure_drop+0x85>
    6bd8:	8b 71 18             	mov    0x18(%rcx),%esi
    6bdb:	0f b7 c0             	movzwl %ax,%eax
    6bde:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6be1:	48 0f af c6          	imul   %rsi,%rax
    6be5:	48 c1 e8 20          	shr    $0x20,%rax
    6be9:	48 39 c8             	cmp    %rcx,%rax
    6bec:	73 27                	jae    6c15 <fwp_closure_drop+0x85>
    6bee:	48 01 c2             	add    %rax,%rdx
    6bf1:	0f b6 02             	movzbl (%rdx),%eax
    6bf4:	84 c0                	test   %al,%al
    6bf6:	74 1d                	je     6c15 <fwp_closure_drop+0x85>
    6bf8:	3c 01                	cmp    $0x1,%al
    6bfa:	74 24                	je     6c20 <fwp_closure_drop+0x90>
    6bfc:	3c ff                	cmp    $0xff,%al
    6bfe:	74 48                	je     6c48 <fwp_closure_drop+0xb8>
    6c00:	83 e8 01             	sub    $0x1,%eax
    6c03:	88 02                	mov    %al,(%rdx)
    6c05:	c3                   	ret
    6c06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c0d:	00 00 00 
    6c10:	66 85 c0             	test   %ax,%ax
    6c13:	74 dc                	je     6bf1 <fwp_closure_drop+0x61>
    6c15:	c3                   	ret
    6c16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c1d:	00 00 00 
    6c20:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6c27:	ff ff 
    6c29:	48 85 c0             	test   %rax,%rax
    6c2c:	74 12                	je     6c40 <fwp_closure_drop+0xb0>
    6c2e:	48 89 fe             	mov    %rdi,%rsi
    6c31:	48 89 c7             	mov    %rax,%rdi
    6c34:	e9 77 d8 ff ff       	jmp    44b0 <fwp_closure_drop_push>
    6c39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c40:	e9 1b da ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    6c45:	0f 1f 00             	nopl   (%rax)
    6c48:	48 89 d0             	mov    %rdx,%rax
    6c4b:	48 8d 35 ce 1b 06 00 	lea    0x61bce(%rip),%rsi        # 68820 <fwp_heap>
    6c52:	48 83 ec 18          	sub    $0x18,%rsp
    6c56:	48 c1 e8 11          	shr    $0x11,%rax
    6c5a:	48 31 d0             	xor    %rdx,%rax
    6c5d:	48 89 c1             	mov    %rax,%rcx
    6c60:	48 c1 e9 09          	shr    $0x9,%rcx
    6c64:	48 31 c8             	xor    %rcx,%rax
    6c67:	0f b6 c8             	movzbl %al,%ecx
    6c6a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6c71:	00 
    6c72:	48 85 c0             	test   %rax,%rax
    6c75:	75 12                	jne    6c89 <fwp_closure_drop+0xf9>
    6c77:	eb 49                	jmp    6cc2 <fwp_closure_drop+0x132>
    6c79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6c84:	48 85 c0             	test   %rax,%rax
    6c87:	74 39                	je     6cc2 <fwp_closure_drop+0x132>
    6c89:	48 89 c1             	mov    %rax,%rcx
    6c8c:	48 39 10             	cmp    %rdx,(%rax)
    6c8f:	75 ef                	jne    6c80 <fwp_closure_drop+0xf0>
    6c91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6c95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6c99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6c9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6ca4:	74 05                	je     6cab <fwp_closure_drop+0x11b>
    6ca6:	48 83 c4 18          	add    $0x18,%rsp
    6caa:	c3                   	ret
    6cab:	48 89 d7             	mov    %rdx,%rdi
    6cae:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6cb3:	e8 18 eb ff ff       	call   57d0 <fwp_rc_forget_slot>
    6cb8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6cbd:	c6 02 fe             	movb   $0xfe,(%rdx)
    6cc0:	eb e4                	jmp    6ca6 <fwp_closure_drop+0x116>
    6cc2:	48 8d 3d 27 5d 00 00 	lea    0x5d27(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    6cc9:	e8 82 d7 ff ff       	call   4450 <fwp_trap>
    6cce:	66 90                	xchg   %ax,%ax

0000000000006cd0 <fwp_owned_tape_release>:
    6cd0:	48 85 ff             	test   %rdi,%rdi
    6cd3:	0f 84 f7 00 00 00    	je     6dd0 <fwp_owned_tape_release+0x100>
    6cd9:	41 54                	push   %r12
    6cdb:	55                   	push   %rbp
    6cdc:	53                   	push   %rbx
    6cdd:	48 8b 07             	mov    (%rdi),%rax
    6ce0:	48 85 c0             	test   %rax,%rax
    6ce3:	74 08                	je     6ced <fwp_owned_tape_release+0x1d>
    6ce5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6ce9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6ced:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6cf1:	48 85 d2             	test   %rdx,%rdx
    6cf4:	74 03                	je     6cf9 <fwp_owned_tape_release+0x29>
    6cf6:	48 89 02             	mov    %rax,(%rdx)
    6cf9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6cfd:	48 89 fb             	mov    %rdi,%rbx
    6d00:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6d04:	48 85 c0             	test   %rax,%rax
    6d07:	0f 84 89 00 00 00    	je     6d96 <fwp_owned_tape_release+0xc6>
    6d0d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6d11:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6d15:	7e 47                	jle    6d5e <fwp_owned_tape_release+0x8e>
    6d17:	31 ed                	xor    %ebp,%ebp
    6d19:	eb 0d                	jmp    6d28 <fwp_owned_tape_release+0x58>
    6d1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6d20:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6d24:	48 8b 40 68          	mov    0x68(%rax),%rax
    6d28:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6d2c:	49 89 ec             	mov    %rbp,%r12
    6d2f:	48 83 c5 01          	add    $0x1,%rbp
    6d33:	49 c1 e4 04          	shl    $0x4,%r12
    6d37:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6d3b:	ff d0                	call   *%rax
    6d3d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6d41:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6d46:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6d4a:	ff 50 68             	call   *0x68(%rax)
    6d4d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6d51:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6d55:	48 39 e8             	cmp    %rbp,%rax
    6d58:	7f c6                	jg     6d20 <fwp_owned_tape_release+0x50>
    6d5a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6d5e:	31 ed                	xor    %ebp,%ebp
    6d60:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6d65:	7e 28                	jle    6d8f <fwp_owned_tape_release+0xbf>
    6d67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6d6e:	00 00 
    6d70:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6d74:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6d78:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6d7c:	74 07                	je     6d85 <fwp_owned_tape_release+0xb5>
    6d7e:	ff 52 68             	call   *0x68(%rdx)
    6d81:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6d85:	48 83 c5 01          	add    $0x1,%rbp
    6d89:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6d8d:	7f e1                	jg     6d70 <fwp_owned_tape_release+0xa0>
    6d8f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6d93:	ff 52 68             	call   *0x68(%rdx)
    6d96:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6d9a:	e8 f1 fd ff ff       	call   6b90 <fwp_closure_drop>
    6d9f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6da3:	e8 e8 fd ff ff       	call   6b90 <fwp_closure_drop>
    6da8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6dac:	e8 df fd ff ff       	call   6b90 <fwp_closure_drop>
    6db1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6db5:	e8 56 ec ff ff       	call   5a10 <fwp_mem_free>
    6dba:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6dbe:	e8 4d ec ff ff       	call   5a10 <fwp_mem_free>
    6dc3:	48 89 df             	mov    %rbx,%rdi
    6dc6:	5b                   	pop    %rbx
    6dc7:	5d                   	pop    %rbp
    6dc8:	41 5c                	pop    %r12
    6dca:	e9 41 ec ff ff       	jmp    5a10 <fwp_mem_free>
    6dcf:	90                   	nop
    6dd0:	c3                   	ret
    6dd1:	0f 1f 40 00          	nopl   0x0(%rax)
    6dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6ddc:	00 00 00 00 

0000000000006de0 <fwp_tape_finish>:
    6de0:	f3 0f 1e fa          	endbr64
    6de4:	41 55                	push   %r13
    6de6:	41 54                	push   %r12
    6de8:	55                   	push   %rbp
    6de9:	53                   	push   %rbx
    6dea:	48 83 ec 48          	sub    $0x48,%rsp
    6dee:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    6df5:	00 00 
    6df7:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    6dfc:	48 8d 3d 9d 92 01 00 	lea    0x1929d(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    6e03:	e8 38 e3 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    6e08:	48 83 3d d8 92 01 00 	cmpq   $0x0,0x192d8(%rip)        # 200e8 <fwp_ntapes>
    6e0f:	00 
    6e10:	48 c7 05 6d 92 01 00 	movq   $0x0,0x1926d(%rip)        # 20088 <fwp_tape_cached_bytes>
    6e17:	00 00 00 00 
    6e1b:	7e 79                	jle    6e96 <fwp_tape_finish+0xb6>
    6e1d:	45 31 e4             	xor    %r12d,%r12d
    6e20:	31 ed                	xor    %ebp,%ebp
    6e22:	0f 1f 00             	nopl   (%rax)
    6e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e2c:	00 00 00 00 
    6e30:	48 8b 1d b9 92 01 00 	mov    0x192b9(%rip),%rbx        # 200f0 <fwp_tapes>
    6e37:	48 83 c5 01          	add    $0x1,%rbp
    6e3b:	4c 01 e3             	add    %r12,%rbx
    6e3e:	49 83 c4 68          	add    $0x68,%r12
    6e42:	48 89 df             	mov    %rbx,%rdi
    6e45:	e8 46 ce ff ff       	call   3c90 <fwp_tape_unlink_scope>
    6e4a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    6e4f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    6e54:	48 89 e7             	mov    %rsp,%rdi
    6e57:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6e5b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    6e5f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6e64:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6e69:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    6e6e:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    6e72:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    6e77:	e8 c4 e2 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    6e7c:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6e80:	e8 4b fe ff ff       	call   6cd0 <fwp_owned_tape_release>
    6e85:	48 39 2d 5c 92 01 00 	cmp    %rbp,0x1925c(%rip)        # 200e8 <fwp_ntapes>
    6e8c:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6e93:	00 
    6e94:	7f 9a                	jg     6e30 <fwp_tape_finish+0x50>
    6e96:	48 8b 3d 53 92 01 00 	mov    0x19253(%rip),%rdi        # 200f0 <fwp_tapes>
    6e9d:	48 85 ff             	test   %rdi,%rdi
    6ea0:	74 05                	je     6ea7 <fwp_tape_finish+0xc7>
    6ea2:	e8 29 e2 ff ff       	call   50d0 <ad_raw_free.part.0>
    6ea7:	48 c7 05 3e 92 01 00 	movq   $0x0,0x1923e(%rip)        # 200f0 <fwp_tapes>
    6eae:	00 00 00 00 
    6eb2:	48 c7 05 23 92 01 00 	movq   $0x0,0x19223(%rip)        # 200e0 <fwp_tapes_cap>
    6eb9:	00 00 00 00 
    6ebd:	48 c7 05 20 92 01 00 	movq   $0x0,0x19220(%rip)        # 200e8 <fwp_ntapes>
    6ec4:	00 00 00 00 
    6ec8:	48 c7 05 05 92 01 00 	movq   $0x0,0x19205(%rip)        # 200d8 <fwp_tape_next_slot>
    6ecf:	00 00 00 00 
    6ed3:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    6ed8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6edf:	00 00 
    6ee1:	75 0b                	jne    6eee <fwp_tape_finish+0x10e>
    6ee3:	48 83 c4 48          	add    $0x48,%rsp
    6ee7:	5b                   	pop    %rbx
    6ee8:	5d                   	pop    %rbp
    6ee9:	41 5c                	pop    %r12
    6eeb:	41 5d                	pop    %r13
    6eed:	c3                   	ret
    6eee:	e8 5d c5 ff ff       	call   3450 <__stack_chk_fail@plt>
    6ef3:	66 90                	xchg   %ax,%ax
    6ef5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6efc:	00 00 00 00 

0000000000006f00 <fwp_tape_scope_release>:
    6f00:	f3 0f 1e fa          	endbr64
    6f04:	41 55                	push   %r13
    6f06:	41 54                	push   %r12
    6f08:	55                   	push   %rbp
    6f09:	53                   	push   %rbx
    6f0a:	48 83 ec 48          	sub    $0x48,%rsp
    6f0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6f15:	00 00 
    6f17:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    6f1c:	48 63 07             	movslq (%rdi),%rax
    6f1f:	85 c0                	test   %eax,%eax
    6f21:	0f 88 e8 00 00 00    	js     700f <fwp_tape_scope_release+0x10f>
    6f27:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    6f2e:	ec c4 4e 
    6f31:	48 89 fb             	mov    %rdi,%rbx
    6f34:	48 89 e5             	mov    %rsp,%rbp
    6f37:	eb 1f                	jmp    6f58 <fwp_tape_scope_release+0x58>
    6f39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f40:	e8 fb e1 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    6f45:	4c 89 ef             	mov    %r13,%rdi
    6f48:	e8 83 fd ff ff       	call   6cd0 <fwp_owned_tape_release>
    6f4d:	48 63 03             	movslq (%rbx),%rax
    6f50:	85 c0                	test   %eax,%eax
    6f52:	0f 88 b7 00 00 00    	js     700f <fwp_tape_scope_release+0x10f>
    6f58:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6f5c:	48 8b 35 8d 91 01 00 	mov    0x1918d(%rip),%rsi        # 200f0 <fwp_tapes>
    6f63:	4c 01 c6             	add    %r8,%rsi
    6f66:	48 89 f7             	mov    %rsi,%rdi
    6f69:	e8 22 cd ff ff       	call   3c90 <fwp_tape_unlink_scope>
    6f6e:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6f73:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6f78:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6f7f:	48 8b 46 40          	mov    0x40(%rsi),%rax
    6f83:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    6f87:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6f8e:	00 
    6f8f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6f94:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    6f99:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    6f9d:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    6fa2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6fa6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6fab:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6fb2:	00 
    6fb3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6fba:	00 
    6fbb:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6fc2:	00 
    6fc3:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    6fc7:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    6fcb:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    6fcf:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    6fd3:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6fd9:	77 18                	ja     6ff3 <fwp_tape_scope_release+0xf3>
    6fdb:	49 c1 f8 03          	sar    $0x3,%r8
    6fdf:	4d 0f af c4          	imul   %r12,%r8
    6fe3:	4c 3b 05 ee 90 01 00 	cmp    0x190ee(%rip),%r8        # 200d8 <fwp_tape_next_slot>
    6fea:	7d 07                	jge    6ff3 <fwp_tape_scope_release+0xf3>
    6fec:	4c 89 05 e5 90 01 00 	mov    %r8,0x190e5(%rip)        # 200d8 <fwp_tape_next_slot>
    6ff3:	48 89 ef             	mov    %rbp,%rdi
    6ff6:	4d 85 ed             	test   %r13,%r13
    6ff9:	0f 85 41 ff ff ff    	jne    6f40 <fwp_tape_scope_release+0x40>
    6fff:	e8 5c e2 ff ff       	call   5260 <fwp_tape_buffers_release>
    7004:	48 63 03             	movslq (%rbx),%rax
    7007:	85 c0                	test   %eax,%eax
    7009:	0f 89 49 ff ff ff    	jns    6f58 <fwp_tape_scope_release+0x58>
    700f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7014:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    701b:	00 00 
    701d:	75 0b                	jne    702a <fwp_tape_scope_release+0x12a>
    701f:	48 83 c4 48          	add    $0x48,%rsp
    7023:	5b                   	pop    %rbx
    7024:	5d                   	pop    %rbp
    7025:	41 5c                	pop    %r12
    7027:	41 5d                	pop    %r13
    7029:	c3                   	ret
    702a:	e8 21 c4 ff ff       	call   3450 <__stack_chk_fail@plt>
    702f:	90                   	nop

0000000000007030 <fwp_drop4>:
    7030:	48 8b 0d c1 2b 06 00 	mov    0x62bc1(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    7037:	48 89 f8             	mov    %rdi,%rax
    703a:	48 2b 05 8f 2b 06 00 	sub    0x62b8f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7041:	48 c1 e1 10          	shl    $0x10,%rcx
    7045:	48 39 c8             	cmp    %rcx,%rax
    7048:	0f 83 42 01 00 00    	jae    7190 <fwp_drop4+0x160>
    704e:	48 83 ec 18          	sub    $0x18,%rsp
    7052:	48 89 fa             	mov    %rdi,%rdx
    7055:	4c 8d 05 c4 17 06 00 	lea    0x617c4(%rip),%r8        # 68820 <fwp_heap>
    705c:	48 89 c1             	mov    %rax,%rcx
    705f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7066:	48 c1 e9 10          	shr    $0x10,%rcx
    706a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    706e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7072:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7076:	48 85 c9             	test   %rcx,%rcx
    7079:	74 40                	je     70bb <fwp_drop4+0x8b>
    707b:	0f b6 3e             	movzbl (%rsi),%edi
    707e:	40 80 ff 02          	cmp    $0x2,%dil
    7082:	74 3c                	je     70c0 <fwp_drop4+0x90>
    7084:	40 80 ff 01          	cmp    $0x1,%dil
    7088:	75 31                	jne    70bb <fwp_drop4+0x8b>
    708a:	8b 7e 18             	mov    0x18(%rsi),%edi
    708d:	0f b7 c0             	movzwl %ax,%eax
    7090:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7093:	48 0f af c7          	imul   %rdi,%rax
    7097:	48 c1 e8 20          	shr    $0x20,%rax
    709b:	48 39 f0             	cmp    %rsi,%rax
    709e:	73 1b                	jae    70bb <fwp_drop4+0x8b>
    70a0:	48 01 c1             	add    %rax,%rcx
    70a3:	0f b6 01             	movzbl (%rcx),%eax
    70a6:	84 c0                	test   %al,%al
    70a8:	74 11                	je     70bb <fwp_drop4+0x8b>
    70aa:	3c 01                	cmp    $0x1,%al
    70ac:	74 22                	je     70d0 <fwp_drop4+0xa0>
    70ae:	3c ff                	cmp    $0xff,%al
    70b0:	0f 84 0a 01 00 00    	je     71c0 <fwp_drop4+0x190>
    70b6:	83 e8 01             	sub    $0x1,%eax
    70b9:	88 01                	mov    %al,(%rcx)
    70bb:	48 83 c4 18          	add    $0x18,%rsp
    70bf:	c3                   	ret
    70c0:	66 85 c0             	test   %ax,%ax
    70c3:	74 de                	je     70a3 <fwp_drop4+0x73>
    70c5:	48 83 c4 18          	add    $0x18,%rsp
    70c9:	c3                   	ret
    70ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    70d0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    70d4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    70db:	48 89 f8             	mov    %rdi,%rax
    70de:	48 c1 e1 10          	shl    $0x10,%rcx
    70e2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    70e9:	48 39 c8             	cmp    %rcx,%rax
    70ec:	73 62                	jae    7150 <fwp_drop4+0x120>
    70ee:	48 89 c1             	mov    %rax,%rcx
    70f1:	48 c1 e9 10          	shr    $0x10,%rcx
    70f5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    70f9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    70fd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7101:	48 85 c9             	test   %rcx,%rcx
    7104:	74 4a                	je     7150 <fwp_drop4+0x120>
    7106:	44 0f b6 0e          	movzbl (%rsi),%r9d
    710a:	41 80 f9 02          	cmp    $0x2,%r9b
    710e:	0f 84 9c 00 00 00    	je     71b0 <fwp_drop4+0x180>
    7114:	41 80 f9 01          	cmp    $0x1,%r9b
    7118:	75 36                	jne    7150 <fwp_drop4+0x120>
    711a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    711e:	0f b7 c0             	movzwl %ax,%eax
    7121:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7124:	49 0f af c1          	imul   %r9,%rax
    7128:	48 c1 e8 20          	shr    $0x20,%rax
    712c:	48 39 f0             	cmp    %rsi,%rax
    712f:	73 1f                	jae    7150 <fwp_drop4+0x120>
    7131:	48 01 c1             	add    %rax,%rcx
    7134:	0f b6 01             	movzbl (%rcx),%eax
    7137:	84 c0                	test   %al,%al
    7139:	74 15                	je     7150 <fwp_drop4+0x120>
    713b:	3c 01                	cmp    $0x1,%al
    713d:	74 59                	je     7198 <fwp_drop4+0x168>
    713f:	3c ff                	cmp    $0xff,%al
    7141:	0f 84 ff 00 00 00    	je     7246 <fwp_drop4+0x216>
    7147:	83 e8 01             	sub    $0x1,%eax
    714a:	88 01                	mov    %al,(%rcx)
    714c:	0f 1f 40 00          	nopl   0x0(%rax)
    7150:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7154:	48 89 d7             	mov    %rdx,%rdi
    7157:	48 89 0c 24          	mov    %rcx,(%rsp)
    715b:	e8 00 f7 ff ff       	call   6860 <fwp_rc_free_obj>
    7160:	4c 8d 05 b9 16 06 00 	lea    0x616b9(%rip),%r8        # 68820 <fwp_heap>
    7167:	48 8b 04 24          	mov    (%rsp),%rax
    716b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7172:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7179:	48 c1 e2 10          	shl    $0x10,%rdx
    717d:	48 39 d0             	cmp    %rdx,%rax
    7180:	0f 83 35 ff ff ff    	jae    70bb <fwp_drop4+0x8b>
    7186:	48 8b 14 24          	mov    (%rsp),%rdx
    718a:	e9 cd fe ff ff       	jmp    705c <fwp_drop4+0x2c>
    718f:	90                   	nop
    7190:	c3                   	ret
    7191:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7198:	48 89 14 24          	mov    %rdx,(%rsp)
    719c:	e8 bf f6 ff ff       	call   6860 <fwp_rc_free_obj>
    71a1:	48 8b 14 24          	mov    (%rsp),%rdx
    71a5:	eb a9                	jmp    7150 <fwp_drop4+0x120>
    71a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    71ae:	00 00 
    71b0:	66 85 c0             	test   %ax,%ax
    71b3:	75 9b                	jne    7150 <fwp_drop4+0x120>
    71b5:	e9 7a ff ff ff       	jmp    7134 <fwp_drop4+0x104>
    71ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    71c0:	48 89 c8             	mov    %rcx,%rax
    71c3:	48 c1 e8 11          	shr    $0x11,%rax
    71c7:	48 31 c8             	xor    %rcx,%rax
    71ca:	48 89 c2             	mov    %rax,%rdx
    71cd:	48 c1 ea 09          	shr    $0x9,%rdx
    71d1:	48 31 d0             	xor    %rdx,%rax
    71d4:	0f b6 d0             	movzbl %al,%edx
    71d7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    71de:	00 
    71df:	48 85 c0             	test   %rax,%rax
    71e2:	75 29                	jne    720d <fwp_drop4+0x1dd>
    71e4:	e9 e3 00 00 00       	jmp    72cc <fwp_drop4+0x29c>
    71e9:	90                   	nop
    71ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    71f1:	00 00 00 00 
    71f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    71fc:	00 00 00 00 
    7200:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7204:	48 85 c0             	test   %rax,%rax
    7207:	0f 84 bf 00 00 00    	je     72cc <fwp_drop4+0x29c>
    720d:	48 89 c2             	mov    %rax,%rdx
    7210:	48 39 08             	cmp    %rcx,(%rax)
    7213:	75 eb                	jne    7200 <fwp_drop4+0x1d0>
    7215:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7219:	48 83 ea 01          	sub    $0x1,%rdx
    721d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7221:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7228:	0f 85 8d fe ff ff    	jne    70bb <fwp_drop4+0x8b>
    722e:	48 89 cf             	mov    %rcx,%rdi
    7231:	48 89 0c 24          	mov    %rcx,(%rsp)
    7235:	e8 96 e5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    723a:	48 8b 0c 24          	mov    (%rsp),%rcx
    723e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7241:	e9 75 fe ff ff       	jmp    70bb <fwp_drop4+0x8b>
    7246:	48 89 ce             	mov    %rcx,%rsi
    7249:	48 c1 ee 11          	shr    $0x11,%rsi
    724d:	48 31 ce             	xor    %rcx,%rsi
    7250:	48 89 f0             	mov    %rsi,%rax
    7253:	48 c1 e8 09          	shr    $0x9,%rax
    7257:	48 31 c6             	xor    %rax,%rsi
    725a:	40 0f b6 f6          	movzbl %sil,%esi
    725e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7265:	00 
    7266:	48 85 c0             	test   %rax,%rax
    7269:	75 1e                	jne    7289 <fwp_drop4+0x259>
    726b:	eb 5f                	jmp    72cc <fwp_drop4+0x29c>
    726d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7274:	00 
    7275:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    727c:	00 00 00 00 
    7280:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7284:	48 85 c0             	test   %rax,%rax
    7287:	74 43                	je     72cc <fwp_drop4+0x29c>
    7289:	48 89 c6             	mov    %rax,%rsi
    728c:	48 39 08             	cmp    %rcx,(%rax)
    728f:	75 ef                	jne    7280 <fwp_drop4+0x250>
    7291:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7295:	48 83 ee 01          	sub    $0x1,%rsi
    7299:	48 89 70 08          	mov    %rsi,0x8(%rax)
    729d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    72a4:	0f 85 a6 fe ff ff    	jne    7150 <fwp_drop4+0x120>
    72aa:	48 89 cf             	mov    %rcx,%rdi
    72ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    72b2:	48 89 0c 24          	mov    %rcx,(%rsp)
    72b6:	e8 15 e5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    72bb:	48 8b 0c 24          	mov    (%rsp),%rcx
    72bf:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    72c4:	c6 01 fe             	movb   $0xfe,(%rcx)
    72c7:	e9 84 fe ff ff       	jmp    7150 <fwp_drop4+0x120>
    72cc:	48 8d 3d 1d 57 00 00 	lea    0x571d(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    72d3:	e8 78 d1 ff ff       	call   4450 <fwp_trap>
    72d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    72df:	00 

00000000000072e0 <fwp_arg_drop37>:
    72e0:	f3 0f 1e fa          	endbr64
    72e4:	85 f6                	test   %esi,%esi
    72e6:	75 04                	jne    72ec <fwp_arg_drop37+0xc>
    72e8:	85 d2                	test   %edx,%edx
    72ea:	75 04                	jne    72f0 <fwp_arg_drop37+0x10>
    72ec:	c3                   	ret
    72ed:	0f 1f 00             	nopl   (%rax)
    72f0:	48 8b 3f             	mov    (%rdi),%rdi
    72f3:	e9 38 fd ff ff       	jmp    7030 <fwp_drop4>
    72f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    72ff:	00 

0000000000007300 <fwp_task_dispose>:
    7300:	53                   	push   %rbx
    7301:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7305:	0f 84 3b c4 ff ff    	je     3746 <fwp_task_dispose.cold>
    730b:	48 89 fb             	mov    %rdi,%rbx
    730e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7313:	0f 85 2d c4 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7319:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    731d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7324:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    732b:	00 
    732c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7330:	48 85 ff             	test   %rdi,%rdi
    7333:	74 07                	je     733c <fwp_task_dispose+0x3c>
    7335:	48 85 c0             	test   %rax,%rax
    7338:	74 02                	je     733c <fwp_task_dispose+0x3c>
    733a:	ff d0                	call   *%rax
    733c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7343:	e8 c8 e6 ff ff       	call   5a10 <fwp_mem_free>
    7348:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    734f:	00 00 00 00 
    7353:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7357:	74 6f                	je     73c8 <fwp_task_dispose+0xc8>
    7359:	48 8b 15 98 28 06 00 	mov    0x62898(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7360:	48 89 d8             	mov    %rbx,%rax
    7363:	48 2b 05 66 28 06 00 	sub    0x62866(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    736a:	48 c1 e2 10          	shl    $0x10,%rdx
    736e:	48 39 d0             	cmp    %rdx,%rax
    7371:	73 4c                	jae    73bf <fwp_task_dispose+0xbf>
    7373:	48 89 c2             	mov    %rax,%rdx
    7376:	48 c1 ea 10          	shr    $0x10,%rdx
    737a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    737e:	48 8b 15 93 28 06 00 	mov    0x62893(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    7385:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7389:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    738d:	48 85 c9             	test   %rcx,%rcx
    7390:	74 2d                	je     73bf <fwp_task_dispose+0xbf>
    7392:	0f b6 32             	movzbl (%rdx),%esi
    7395:	40 80 fe 02          	cmp    $0x2,%sil
    7399:	74 3d                	je     73d8 <fwp_task_dispose+0xd8>
    739b:	40 80 fe 01          	cmp    $0x1,%sil
    739f:	75 1e                	jne    73bf <fwp_task_dispose+0xbf>
    73a1:	8b 72 18             	mov    0x18(%rdx),%esi
    73a4:	0f b7 c0             	movzwl %ax,%eax
    73a7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    73aa:	48 0f af c6          	imul   %rsi,%rax
    73ae:	48 c1 e8 20          	shr    $0x20,%rax
    73b2:	48 39 d0             	cmp    %rdx,%rax
    73b5:	73 08                	jae    73bf <fwp_task_dispose+0xbf>
    73b7:	48 01 c1             	add    %rax,%rcx
    73ba:	80 39 01             	cmpb   $0x1,(%rcx)
    73bd:	74 09                	je     73c8 <fwp_task_dispose+0xc8>
    73bf:	5b                   	pop    %rbx
    73c0:	c3                   	ret
    73c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    73c8:	48 89 df             	mov    %rbx,%rdi
    73cb:	5b                   	pop    %rbx
    73cc:	e9 3f e6 ff ff       	jmp    5a10 <fwp_mem_free>
    73d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    73d8:	66 85 c0             	test   %ax,%ax
    73db:	74 dd                	je     73ba <fwp_task_dispose+0xba>
    73dd:	5b                   	pop    %rbx
    73de:	c3                   	ret
    73df:	90                   	nop

00000000000073e0 <fwp_free_zombie>:
    73e0:	48 8b 15 09 14 06 00 	mov    0x61409(%rip),%rdx        # 687f0 <fwp_zombie>
    73e7:	48 85 d2             	test   %rdx,%rdx
    73ea:	0f 84 98 00 00 00    	je     7488 <fwp_free_zombie+0xa8>
    73f0:	48 3b 15 09 14 06 00 	cmp    0x61409(%rip),%rdx        # 68800 <fwp_cur>
    73f7:	0f 84 8b 00 00 00    	je     7488 <fwp_free_zombie+0xa8>
    73fd:	48 83 ec 18          	sub    $0x18,%rsp
    7401:	48 63 05 cc 0d 06 00 	movslq 0x60dcc(%rip),%rax        # 681d4 <fwp_stack_pool_n>
    7408:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    740c:	83 f8 3f             	cmp    $0x3f,%eax
    740f:	7f 7f                	jg     7490 <fwp_free_zombie+0xb0>
    7411:	8d 48 01             	lea    0x1(%rax),%ecx
    7414:	89 0d ba 0d 06 00    	mov    %ecx,0x60dba(%rip)        # 681d4 <fwp_stack_pool_n>
    741a:	48 8d 0d bf 0d 06 00 	lea    0x60dbf(%rip),%rcx        # 681e0 <fwp_stack_pool>
    7421:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7425:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    742c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7430:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7437:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    743b:	48 85 c9             	test   %rcx,%rcx
    743e:	0f 84 fc 00 00 00    	je     7540 <fwp_free_zombie+0x160>
    7444:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    744b:	48 85 c0             	test   %rax,%rax
    744e:	74 07                	je     7457 <fwp_free_zombie+0x77>
    7450:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7457:	8b 42 5c             	mov    0x5c(%rdx),%eax
    745a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    745e:	48 c7 05 87 13 06 00 	movq   $0x0,0x61387(%rip)        # 687f0 <fwp_zombie>
    7465:	00 00 00 00 
    7469:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7470:	85 c0                	test   %eax,%eax
    7472:	74 34                	je     74a8 <fwp_free_zombie+0xc8>
    7474:	83 f8 01             	cmp    $0x1,%eax
    7477:	0f 84 b3 00 00 00    	je     7530 <fwp_free_zombie+0x150>
    747d:	48 83 c4 18          	add    $0x18,%rsp
    7481:	c3                   	ret
    7482:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7488:	c3                   	ret
    7489:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7490:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7494:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7499:	e8 22 c1 ff ff       	call   35c0 <munmap@plt>
    749e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    74a3:	eb 80                	jmp    7425 <fwp_free_zombie+0x45>
    74a5:	0f 1f 00             	nopl   (%rax)
    74a8:	48 8b 0d 49 27 06 00 	mov    0x62749(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    74af:	48 89 d0             	mov    %rdx,%rax
    74b2:	48 2b 05 17 27 06 00 	sub    0x62717(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    74b9:	48 c1 e1 10          	shl    $0x10,%rcx
    74bd:	48 39 c8             	cmp    %rcx,%rax
    74c0:	73 bb                	jae    747d <fwp_free_zombie+0x9d>
    74c2:	48 89 c1             	mov    %rax,%rcx
    74c5:	48 c1 e9 10          	shr    $0x10,%rcx
    74c9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    74cd:	48 8b 0d 44 27 06 00 	mov    0x62744(%rip),%rcx        # 69c18 <fwp_heap+0x13f8>
    74d4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    74d8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    74dc:	48 85 c9             	test   %rcx,%rcx
    74df:	74 9c                	je     747d <fwp_free_zombie+0x9d>
    74e1:	0f b6 3e             	movzbl (%rsi),%edi
    74e4:	40 80 ff 02          	cmp    $0x2,%dil
    74e8:	74 66                	je     7550 <fwp_free_zombie+0x170>
    74ea:	40 80 ff 01          	cmp    $0x1,%dil
    74ee:	75 8d                	jne    747d <fwp_free_zombie+0x9d>
    74f0:	8b 7e 18             	mov    0x18(%rsi),%edi
    74f3:	0f b7 c0             	movzwl %ax,%eax
    74f6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    74f9:	48 0f af c7          	imul   %rdi,%rax
    74fd:	48 c1 e8 20          	shr    $0x20,%rax
    7501:	48 39 f0             	cmp    %rsi,%rax
    7504:	0f 83 73 ff ff ff    	jae    747d <fwp_free_zombie+0x9d>
    750a:	48 01 c1             	add    %rax,%rcx
    750d:	0f b6 01             	movzbl (%rcx),%eax
    7510:	84 c0                	test   %al,%al
    7512:	0f 84 65 ff ff ff    	je     747d <fwp_free_zombie+0x9d>
    7518:	3c 01                	cmp    $0x1,%al
    751a:	74 14                	je     7530 <fwp_free_zombie+0x150>
    751c:	3c ff                	cmp    $0xff,%al
    751e:	74 3b                	je     755b <fwp_free_zombie+0x17b>
    7520:	83 e8 01             	sub    $0x1,%eax
    7523:	88 01                	mov    %al,(%rcx)
    7525:	e9 53 ff ff ff       	jmp    747d <fwp_free_zombie+0x9d>
    752a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7530:	48 89 d7             	mov    %rdx,%rdi
    7533:	48 83 c4 18          	add    $0x18,%rsp
    7537:	e9 c4 fd ff ff       	jmp    7300 <fwp_task_dispose>
    753c:	0f 1f 40 00          	nopl   0x0(%rax)
    7540:	48 89 05 81 12 06 00 	mov    %rax,0x61281(%rip)        # 687c8 <fwp_tasks_active>
    7547:	e9 ff fe ff ff       	jmp    744b <fwp_free_zombie+0x6b>
    754c:	0f 1f 40 00          	nopl   0x0(%rax)
    7550:	66 85 c0             	test   %ax,%ax
    7553:	0f 85 24 ff ff ff    	jne    747d <fwp_free_zombie+0x9d>
    7559:	eb b2                	jmp    750d <fwp_free_zombie+0x12d>
    755b:	48 89 ca             	mov    %rcx,%rdx
    755e:	48 8d 35 bb 12 06 00 	lea    0x612bb(%rip),%rsi        # 68820 <fwp_heap>
    7565:	48 c1 ea 11          	shr    $0x11,%rdx
    7569:	48 31 ca             	xor    %rcx,%rdx
    756c:	48 89 d0             	mov    %rdx,%rax
    756f:	48 c1 e8 09          	shr    $0x9,%rax
    7573:	48 31 c2             	xor    %rax,%rdx
    7576:	0f b6 d2             	movzbl %dl,%edx
    7579:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7580:	00 
    7581:	48 85 c0             	test   %rax,%rax
    7584:	75 23                	jne    75a9 <fwp_free_zombie+0x1c9>
    7586:	eb 5c                	jmp    75e4 <fwp_free_zombie+0x204>
    7588:	66 90                	xchg   %ax,%ax
    758a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7591:	00 00 00 00 
    7595:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    759c:	00 00 00 00 
    75a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    75a4:	48 85 c0             	test   %rax,%rax
    75a7:	74 3b                	je     75e4 <fwp_free_zombie+0x204>
    75a9:	48 89 c2             	mov    %rax,%rdx
    75ac:	48 39 08             	cmp    %rcx,(%rax)
    75af:	75 ef                	jne    75a0 <fwp_free_zombie+0x1c0>
    75b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    75b5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    75b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    75bd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    75c4:	0f 85 b3 fe ff ff    	jne    747d <fwp_free_zombie+0x9d>
    75ca:	48 89 cf             	mov    %rcx,%rdi
    75cd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    75d2:	e8 f9 e1 ff ff       	call   57d0 <fwp_rc_forget_slot>
    75d7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    75dc:	c6 01 fe             	movb   $0xfe,(%rcx)
    75df:	e9 99 fe ff ff       	jmp    747d <fwp_free_zombie+0x9d>
    75e4:	48 8d 3d 05 54 00 00 	lea    0x5405(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    75eb:	e8 60 ce ff ff       	call   4450 <fwp_trap>

00000000000075f0 <fwp_block>:
    75f0:	48 83 ec 08          	sub    $0x8,%rsp
    75f4:	48 8b 05 ed 11 06 00 	mov    0x611ed(%rip),%rax        # 687e8 <fwp_ready_head>
    75fb:	48 85 c0             	test   %rax,%rax
    75fe:	0f 84 1c 01 00 00    	je     7720 <fwp_block+0x130>
    7604:	90                   	nop
    7605:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    760c:	00 00 00 00 
    7610:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7617:	48 89 15 ca 11 06 00 	mov    %rdx,0x611ca(%rip)        # 687e8 <fwp_ready_head>
    761e:	48 85 d2             	test   %rdx,%rdx
    7621:	0f 84 19 01 00 00    	je     7740 <fwp_block+0x150>
    7627:	48 8b 15 d2 11 06 00 	mov    0x611d2(%rip),%rdx        # 68800 <fwp_cur>
    762e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7632:	48 39 c2             	cmp    %rax,%rdx
    7635:	0f 84 d5 00 00 00    	je     7710 <fwp_block+0x120>
    763b:	48 8b 0d 46 2e 06 00 	mov    0x62e46(%rip),%rcx        # 6a488 <fwp_state_owners>
    7642:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7646:	48 89 05 b3 11 06 00 	mov    %rax,0x611b3(%rip)        # 68800 <fwp_cur>
    764d:	f3 0f 7e 05 5b 2e 06 	movq   0x62e5b(%rip),%xmm0        # 6a4b0 <fwp_foreign_callbacks>
    7654:	00 
    7655:	0f 16 05 44 2e 06 00 	movhps 0x62e44(%rip),%xmm0        # 6a4a0 <fwp_state>
    765c:	f3 0f 7e 0d 44 2e 06 	movq   0x62e44(%rip),%xmm1        # 6a4a8 <fwp_handlers>
    7663:	00 
    7664:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    766b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7672:	0f 16 0d 3f 2e 06 00 	movhps 0x62e3f(%rip),%xmm1        # 6a4b8 <fwp_cleanups>
    7679:	f3 0f 7e 05 17 2e 06 	movq   0x62e17(%rip),%xmm0        # 6a498 <fwp_state_len>
    7680:	00 
    7681:	0f 16 05 08 2e 06 00 	movhps 0x62e08(%rip),%xmm0        # 6a490 <fwp_state_cap>
    7688:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    768f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7696:	48 8b 70 08          	mov    0x8(%rax),%rsi
    769a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    76a1:	48 89 0d 00 2e 06 00 	mov    %rcx,0x62e00(%rip)        # 6a4a8 <fwp_handlers>
    76a8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    76af:	48 89 0d 02 2e 06 00 	mov    %rcx,0x62e02(%rip)        # 6a4b8 <fwp_cleanups>
    76b6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    76bd:	48 89 0d ec 2d 06 00 	mov    %rcx,0x62dec(%rip)        # 6a4b0 <fwp_foreign_callbacks>
    76c4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    76cb:	48 89 0d ce 2d 06 00 	mov    %rcx,0x62dce(%rip)        # 6a4a0 <fwp_state>
    76d2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    76d9:	48 89 0d b8 2d 06 00 	mov    %rcx,0x62db8(%rip)        # 6a498 <fwp_state_len>
    76e0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    76e7:	48 89 0d a2 2d 06 00 	mov    %rcx,0x62da2(%rip)        # 6a490 <fwp_state_cap>
    76ee:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    76f5:	48 89 0d 8c 2d 06 00 	mov    %rcx,0x62d8c(%rip)        # 6a488 <fwp_state_owners>
    76fc:	e8 7f bd ff ff       	call   3480 <swapcontext@plt>
    7701:	f3 0f 1e fa          	endbr64
    7705:	e8 d6 fc ff ff       	call   73e0 <fwp_free_zombie>
    770a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7710:	8b 05 ba 0a 06 00    	mov    0x60aba(%rip),%eax        # 681d0 <fwp_slice>
    7716:	85 c0                	test   %eax,%eax
    7718:	74 36                	je     7750 <fwp_block+0x160>
    771a:	48 83 c4 08          	add    $0x8,%rsp
    771e:	c3                   	ret
    771f:	90                   	nop
    7720:	e8 eb dc ff ff       	call   5410 <fwp_poll_events>
    7725:	48 8b 05 bc 10 06 00 	mov    0x610bc(%rip),%rax        # 687e8 <fwp_ready_head>
    772c:	48 85 c0             	test   %rax,%rax
    772f:	0f 85 db fe ff ff    	jne    7610 <fwp_block+0x20>
    7735:	eb e9                	jmp    7720 <fwp_block+0x130>
    7737:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    773e:	00 00 
    7740:	48 c7 05 95 10 06 00 	movq   $0x0,0x61095(%rip)        # 687e0 <fwp_ready_tail>
    7747:	00 00 00 00 
    774b:	e9 d7 fe ff ff       	jmp    7627 <fwp_block+0x37>
    7750:	48 8d 3d 88 4a 00 00 	lea    0x4a88(%rip),%rdi        # c1df <_IO_stdin_used+0x1df>
    7757:	e8 34 bc ff ff       	call   3390 <getenv@plt>
    775c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7761:	48 85 c0             	test   %rax,%rax
    7764:	74 05                	je     776b <fwp_block+0x17b>
    7766:	80 38 00             	cmpb   $0x0,(%rax)
    7769:	75 0b                	jne    7776 <fwp_block+0x186>
    776b:	89 15 5f 0a 06 00    	mov    %edx,0x60a5f(%rip)        # 681d0 <fwp_slice>
    7771:	48 83 c4 08          	add    $0x8,%rsp
    7775:	c3                   	ret
    7776:	ba 0a 00 00 00       	mov    $0xa,%edx
    777b:	31 f6                	xor    %esi,%esi
    777d:	48 89 c7             	mov    %rax,%rdi
    7780:	e8 bb bd ff ff       	call   3540 <strtoll@plt>
    7785:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7789:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7790:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7795:	0f 46 d0             	cmovbe %eax,%edx
    7798:	eb d1                	jmp    776b <fwp_block+0x17b>
    779a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000077a0 <fwp_caps173>:
    77a0:	f3 0f 1e fa          	endbr64
    77a4:	85 f6                	test   %esi,%esi
    77a6:	74 08                	je     77b0 <fwp_caps173+0x10>
    77a8:	c3                   	ret
    77a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    77b0:	48 8b 15 41 24 06 00 	mov    0x62441(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    77b7:	48 89 f8             	mov    %rdi,%rax
    77ba:	48 2b 05 0f 24 06 00 	sub    0x6240f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    77c1:	48 c1 e2 10          	shl    $0x10,%rdx
    77c5:	48 39 d0             	cmp    %rdx,%rax
    77c8:	73 de                	jae    77a8 <fwp_caps173+0x8>
    77ca:	48 89 c2             	mov    %rax,%rdx
    77cd:	48 c1 ea 10          	shr    $0x10,%rdx
    77d1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    77d5:	48 8b 15 3c 24 06 00 	mov    0x6243c(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    77dc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    77e0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    77e4:	48 85 c9             	test   %rcx,%rcx
    77e7:	74 bf                	je     77a8 <fwp_caps173+0x8>
    77e9:	0f b6 32             	movzbl (%rdx),%esi
    77ec:	40 80 fe 02          	cmp    $0x2,%sil
    77f0:	74 2e                	je     7820 <fwp_caps173+0x80>
    77f2:	40 80 fe 01          	cmp    $0x1,%sil
    77f6:	75 b0                	jne    77a8 <fwp_caps173+0x8>
    77f8:	8b 72 18             	mov    0x18(%rdx),%esi
    77fb:	0f b7 c0             	movzwl %ax,%eax
    77fe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7801:	48 0f af c6          	imul   %rsi,%rax
    7805:	48 c1 e8 20          	shr    $0x20,%rax
    7809:	48 39 d0             	cmp    %rdx,%rax
    780c:	73 9a                	jae    77a8 <fwp_caps173+0x8>
    780e:	48 01 c1             	add    %rax,%rcx
    7811:	80 39 01             	cmpb   $0x1,(%rcx)
    7814:	75 92                	jne    77a8 <fwp_caps173+0x8>
    7816:	e9 f5 e1 ff ff       	jmp    5a10 <fwp_mem_free>
    781b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7820:	66 85 c0             	test   %ax,%ax
    7823:	74 ec                	je     7811 <fwp_caps173+0x71>
    7825:	c3                   	ret
    7826:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    782d:	00 00 00 

0000000000007830 <fwp_args37>:
    7830:	f3 0f 1e fa          	endbr64
    7834:	85 d2                	test   %edx,%edx
    7836:	74 04                	je     783c <fwp_args37+0xc>
    7838:	85 f6                	test   %esi,%esi
    783a:	74 04                	je     7840 <fwp_args37+0x10>
    783c:	c3                   	ret
    783d:	0f 1f 00             	nopl   (%rax)
    7840:	48 8b 15 b1 23 06 00 	mov    0x623b1(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7847:	48 8b 07             	mov    (%rdi),%rax
    784a:	48 2b 05 7f 23 06 00 	sub    0x6237f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7851:	48 c1 e2 10          	shl    $0x10,%rdx
    7855:	48 39 d0             	cmp    %rdx,%rax
    7858:	73 e2                	jae    783c <fwp_args37+0xc>
    785a:	48 89 c2             	mov    %rax,%rdx
    785d:	48 c1 ea 10          	shr    $0x10,%rdx
    7861:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7865:	48 8b 15 ac 23 06 00 	mov    0x623ac(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    786c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7870:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7874:	48 85 ff             	test   %rdi,%rdi
    7877:	74 c3                	je     783c <fwp_args37+0xc>
    7879:	0f b6 0a             	movzbl (%rdx),%ecx
    787c:	80 f9 02             	cmp    $0x2,%cl
    787f:	74 4f                	je     78d0 <fwp_args37+0xa0>
    7881:	80 f9 01             	cmp    $0x1,%cl
    7884:	75 b6                	jne    783c <fwp_args37+0xc>
    7886:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7889:	0f b7 c0             	movzwl %ax,%eax
    788c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    788f:	48 0f af c1          	imul   %rcx,%rax
    7893:	48 c1 e8 20          	shr    $0x20,%rax
    7897:	48 39 d0             	cmp    %rdx,%rax
    789a:	73 a0                	jae    783c <fwp_args37+0xc>
    789c:	48 01 c7             	add    %rax,%rdi
    789f:	0f b6 07             	movzbl (%rdi),%eax
    78a2:	84 c0                	test   %al,%al
    78a4:	74 96                	je     783c <fwp_args37+0xc>
    78a6:	8b 15 3c 2c 06 00    	mov    0x62c3c(%rip),%edx        # 6a4e8 <iteration_active>
    78ac:	85 d2                	test   %edx,%edx
    78ae:	75 10                	jne    78c0 <fwp_args37+0x90>
    78b0:	3c fd                	cmp    $0xfd,%al
    78b2:	77 22                	ja     78d6 <fwp_args37+0xa6>
    78b4:	83 c0 01             	add    $0x1,%eax
    78b7:	88 07                	mov    %al,(%rdi)
    78b9:	c3                   	ret
    78ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    78c0:	48 83 05 08 2c 06 00 	addq   $0x1,0x62c08(%rip)        # 6a4d0 <iteration_retains>
    78c7:	01 
    78c8:	eb e6                	jmp    78b0 <fwp_args37+0x80>
    78ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    78d0:	66 85 c0             	test   %ax,%ax
    78d3:	74 ca                	je     789f <fwp_args37+0x6f>
    78d5:	c3                   	ret
    78d6:	e9 d5 dd ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    78db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000078e0 <fwp_caps37>:
    78e0:	f3 0f 1e fa          	endbr64
    78e4:	48 83 ec 18          	sub    $0x18,%rsp
    78e8:	48 89 f8             	mov    %rdi,%rax
    78eb:	8b 7f 04             	mov    0x4(%rdi),%edi
    78ee:	85 ff                	test   %edi,%edi
    78f0:	0f 84 9a 00 00 00    	je     7990 <fwp_caps37+0xb0>
    78f6:	48 8b 78 08          	mov    0x8(%rax),%rdi
    78fa:	85 f6                	test   %esi,%esi
    78fc:	0f 85 9e 00 00 00    	jne    79a0 <fwp_caps37+0xc0>
    7902:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7907:	e8 24 f7 ff ff       	call   7030 <fwp_drop4>
    790c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7911:	48 8b 0d e0 22 06 00 	mov    0x622e0(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    7918:	48 89 c2             	mov    %rax,%rdx
    791b:	48 2b 15 ae 22 06 00 	sub    0x622ae(%rip),%rdx        # 69bd0 <fwp_heap+0x13b0>
    7922:	48 c1 e1 10          	shl    $0x10,%rcx
    7926:	48 39 ca             	cmp    %rcx,%rdx
    7929:	73 6d                	jae    7998 <fwp_caps37+0xb8>
    792b:	48 89 d1             	mov    %rdx,%rcx
    792e:	48 c1 e9 10          	shr    $0x10,%rcx
    7932:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7936:	48 8b 0d db 22 06 00 	mov    0x622db(%rip),%rcx        # 69c18 <fwp_heap+0x13f8>
    793d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7941:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7945:	48 85 f6             	test   %rsi,%rsi
    7948:	74 4e                	je     7998 <fwp_caps37+0xb8>
    794a:	0f b6 39             	movzbl (%rcx),%edi
    794d:	40 80 ff 02          	cmp    $0x2,%dil
    7951:	0f 84 c9 00 00 00    	je     7a20 <fwp_caps37+0x140>
    7957:	40 80 ff 01          	cmp    $0x1,%dil
    795b:	75 3b                	jne    7998 <fwp_caps37+0xb8>
    795d:	8b 79 18             	mov    0x18(%rcx),%edi
    7960:	0f b7 d2             	movzwl %dx,%edx
    7963:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7966:	48 0f af d7          	imul   %rdi,%rdx
    796a:	48 c1 ea 20          	shr    $0x20,%rdx
    796e:	48 39 ca             	cmp    %rcx,%rdx
    7971:	73 25                	jae    7998 <fwp_caps37+0xb8>
    7973:	48 01 d6             	add    %rdx,%rsi
    7976:	80 3e 01             	cmpb   $0x1,(%rsi)
    7979:	75 1d                	jne    7998 <fwp_caps37+0xb8>
    797b:	48 89 c7             	mov    %rax,%rdi
    797e:	48 83 c4 18          	add    $0x18,%rsp
    7982:	e9 89 e0 ff ff       	jmp    5a10 <fwp_mem_free>
    7987:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    798e:	00 00 
    7990:	85 f6                	test   %esi,%esi
    7992:	0f 84 79 ff ff ff    	je     7911 <fwp_caps37+0x31>
    7998:	48 83 c4 18          	add    $0x18,%rsp
    799c:	c3                   	ret
    799d:	0f 1f 00             	nopl   (%rax)
    79a0:	48 8b 05 51 22 06 00 	mov    0x62251(%rip),%rax        # 69bf8 <fwp_heap+0x13d8>
    79a7:	48 2b 3d 22 22 06 00 	sub    0x62222(%rip),%rdi        # 69bd0 <fwp_heap+0x13b0>
    79ae:	48 c1 e0 10          	shl    $0x10,%rax
    79b2:	48 39 c7             	cmp    %rax,%rdi
    79b5:	73 e1                	jae    7998 <fwp_caps37+0xb8>
    79b7:	48 89 f8             	mov    %rdi,%rax
    79ba:	48 c1 e8 10          	shr    $0x10,%rax
    79be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    79c2:	48 8b 05 4f 22 06 00 	mov    0x6224f(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    79c9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    79cd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    79d1:	48 85 c0             	test   %rax,%rax
    79d4:	74 c2                	je     7998 <fwp_caps37+0xb8>
    79d6:	0f b6 0a             	movzbl (%rdx),%ecx
    79d9:	80 f9 02             	cmp    $0x2,%cl
    79dc:	74 52                	je     7a30 <fwp_caps37+0x150>
    79de:	80 f9 01             	cmp    $0x1,%cl
    79e1:	75 b5                	jne    7998 <fwp_caps37+0xb8>
    79e3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    79e6:	0f b7 ff             	movzwl %di,%edi
    79e9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    79ec:	48 0f af f9          	imul   %rcx,%rdi
    79f0:	48 c1 ef 20          	shr    $0x20,%rdi
    79f4:	48 39 d7             	cmp    %rdx,%rdi
    79f7:	73 9f                	jae    7998 <fwp_caps37+0xb8>
    79f9:	48 01 f8             	add    %rdi,%rax
    79fc:	0f b6 10             	movzbl (%rax),%edx
    79ff:	84 d2                	test   %dl,%dl
    7a01:	74 95                	je     7998 <fwp_caps37+0xb8>
    7a03:	8b 0d df 2a 06 00    	mov    0x62adf(%rip),%ecx        # 6a4e8 <iteration_active>
    7a09:	85 c9                	test   %ecx,%ecx
    7a0b:	75 33                	jne    7a40 <fwp_caps37+0x160>
    7a0d:	80 fa fd             	cmp    $0xfd,%dl
    7a10:	77 38                	ja     7a4a <fwp_caps37+0x16a>
    7a12:	83 c2 01             	add    $0x1,%edx
    7a15:	88 10                	mov    %dl,(%rax)
    7a17:	e9 7c ff ff ff       	jmp    7998 <fwp_caps37+0xb8>
    7a1c:	0f 1f 40 00          	nopl   0x0(%rax)
    7a20:	66 85 d2             	test   %dx,%dx
    7a23:	0f 85 6f ff ff ff    	jne    7998 <fwp_caps37+0xb8>
    7a29:	e9 48 ff ff ff       	jmp    7976 <fwp_caps37+0x96>
    7a2e:	66 90                	xchg   %ax,%ax
    7a30:	66 85 ff             	test   %di,%di
    7a33:	0f 85 5f ff ff ff    	jne    7998 <fwp_caps37+0xb8>
    7a39:	eb c1                	jmp    79fc <fwp_caps37+0x11c>
    7a3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7a40:	48 83 05 88 2a 06 00 	addq   $0x1,0x62a88(%rip)        # 6a4d0 <iteration_retains>
    7a47:	01 
    7a48:	eb c3                	jmp    7a0d <fwp_caps37+0x12d>
    7a4a:	48 89 c7             	mov    %rax,%rdi
    7a4d:	48 83 c4 18          	add    $0x18,%rsp
    7a51:	e9 5a dc ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    7a56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7a5d:	00 00 00 

0000000000007a60 <fwp_drop0>:
    7a60:	f3 0f 1e fa          	endbr64
    7a64:	48 8b 15 8d 21 06 00 	mov    0x6218d(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7a6b:	48 89 f8             	mov    %rdi,%rax
    7a6e:	48 2b 05 5b 21 06 00 	sub    0x6215b(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7a75:	48 c1 e2 10          	shl    $0x10,%rdx
    7a79:	48 39 d0             	cmp    %rdx,%rax
    7a7c:	0f 83 36 01 00 00    	jae    7bb8 <fwp_drop0+0x158>
    7a82:	48 83 ec 18          	sub    $0x18,%rsp
    7a86:	48 8d 35 93 0d 06 00 	lea    0x60d93(%rip),%rsi        # 68820 <fwp_heap>
    7a8d:	48 89 c2             	mov    %rax,%rdx
    7a90:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7a97:	48 c1 ea 10          	shr    $0x10,%rdx
    7a9b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7a9f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7aa3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7aa7:	48 85 d2             	test   %rdx,%rdx
    7aaa:	74 42                	je     7aee <fwp_drop0+0x8e>
    7aac:	44 0f b6 01          	movzbl (%rcx),%r8d
    7ab0:	41 80 f8 02          	cmp    $0x2,%r8b
    7ab4:	74 42                	je     7af8 <fwp_drop0+0x98>
    7ab6:	41 80 f8 01          	cmp    $0x1,%r8b
    7aba:	75 32                	jne    7aee <fwp_drop0+0x8e>
    7abc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7ac0:	0f b7 c0             	movzwl %ax,%eax
    7ac3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7ac6:	49 0f af c0          	imul   %r8,%rax
    7aca:	48 c1 e8 20          	shr    $0x20,%rax
    7ace:	48 39 c8             	cmp    %rcx,%rax
    7ad1:	73 1b                	jae    7aee <fwp_drop0+0x8e>
    7ad3:	48 01 c2             	add    %rax,%rdx
    7ad6:	0f b6 02             	movzbl (%rdx),%eax
    7ad9:	84 c0                	test   %al,%al
    7adb:	74 11                	je     7aee <fwp_drop0+0x8e>
    7add:	3c 01                	cmp    $0x1,%al
    7adf:	74 27                	je     7b08 <fwp_drop0+0xa8>
    7ae1:	3c ff                	cmp    $0xff,%al
    7ae3:	0f 84 e7 00 00 00    	je     7bd0 <fwp_drop0+0x170>
    7ae9:	83 e8 01             	sub    $0x1,%eax
    7aec:	88 02                	mov    %al,(%rdx)
    7aee:	48 83 c4 18          	add    $0x18,%rsp
    7af2:	c3                   	ret
    7af3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7af8:	66 85 c0             	test   %ax,%ax
    7afb:	74 d9                	je     7ad6 <fwp_drop0+0x76>
    7afd:	48 83 c4 18          	add    $0x18,%rsp
    7b01:	c3                   	ret
    7b02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b08:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7b0f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7b16:	48 89 f8             	mov    %rdi,%rax
    7b19:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7b1d:	48 29 c8             	sub    %rcx,%rax
    7b20:	48 c1 e2 10          	shl    $0x10,%rdx
    7b24:	48 39 d0             	cmp    %rdx,%rax
    7b27:	73 71                	jae    7b9a <fwp_drop0+0x13a>
    7b29:	49 89 c2             	mov    %rax,%r10
    7b2c:	49 c1 ea 10          	shr    $0x10,%r10
    7b30:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7b34:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7b38:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7b3c:	4d 85 d2             	test   %r10,%r10
    7b3f:	74 59                	je     7b9a <fwp_drop0+0x13a>
    7b41:	45 0f b6 19          	movzbl (%r9),%r11d
    7b45:	41 80 fb 02          	cmp    $0x2,%r11b
    7b49:	74 75                	je     7bc0 <fwp_drop0+0x160>
    7b4b:	41 80 fb 01          	cmp    $0x1,%r11b
    7b4f:	75 49                	jne    7b9a <fwp_drop0+0x13a>
    7b51:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7b55:	0f b7 c0             	movzwl %ax,%eax
    7b58:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7b5c:	49 0f af c3          	imul   %r11,%rax
    7b60:	48 c1 e8 20          	shr    $0x20,%rax
    7b64:	4c 39 c8             	cmp    %r9,%rax
    7b67:	73 31                	jae    7b9a <fwp_drop0+0x13a>
    7b69:	49 01 c2             	add    %rax,%r10
    7b6c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7b70:	75 28                	jne    7b9a <fwp_drop0+0x13a>
    7b72:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7b77:	e8 94 de ff ff       	call   5a10 <fwp_mem_free>
    7b7c:	48 8d 35 9d 0c 06 00 	lea    0x60c9d(%rip),%rsi        # 68820 <fwp_heap>
    7b83:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7b88:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7b8f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7b96:	48 c1 e2 10          	shl    $0x10,%rdx
    7b9a:	4c 89 c0             	mov    %r8,%rax
    7b9d:	48 29 c8             	sub    %rcx,%rax
    7ba0:	48 39 d0             	cmp    %rdx,%rax
    7ba3:	0f 83 45 ff ff ff    	jae    7aee <fwp_drop0+0x8e>
    7ba9:	4c 89 c7             	mov    %r8,%rdi
    7bac:	e9 dc fe ff ff       	jmp    7a8d <fwp_drop0+0x2d>
    7bb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7bb8:	c3                   	ret
    7bb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7bc0:	66 85 c0             	test   %ax,%ax
    7bc3:	75 d5                	jne    7b9a <fwp_drop0+0x13a>
    7bc5:	eb a5                	jmp    7b6c <fwp_drop0+0x10c>
    7bc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7bce:	00 00 
    7bd0:	48 89 d0             	mov    %rdx,%rax
    7bd3:	48 c1 e8 11          	shr    $0x11,%rax
    7bd7:	48 31 d0             	xor    %rdx,%rax
    7bda:	48 89 c1             	mov    %rax,%rcx
    7bdd:	48 c1 e9 09          	shr    $0x9,%rcx
    7be1:	48 31 c8             	xor    %rcx,%rax
    7be4:	0f b6 c8             	movzbl %al,%ecx
    7be7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7bee:	00 
    7bef:	48 85 c0             	test   %rax,%rax
    7bf2:	75 15                	jne    7c09 <fwp_drop0+0x1a9>
    7bf4:	eb 4e                	jmp    7c44 <fwp_drop0+0x1e4>
    7bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7bfd:	00 00 00 
    7c00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7c04:	48 85 c0             	test   %rax,%rax
    7c07:	74 3b                	je     7c44 <fwp_drop0+0x1e4>
    7c09:	48 89 c1             	mov    %rax,%rcx
    7c0c:	48 39 10             	cmp    %rdx,(%rax)
    7c0f:	75 ef                	jne    7c00 <fwp_drop0+0x1a0>
    7c11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7c15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7c19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7c1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7c24:	0f 85 c4 fe ff ff    	jne    7aee <fwp_drop0+0x8e>
    7c2a:	48 89 d7             	mov    %rdx,%rdi
    7c2d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7c32:	e8 99 db ff ff       	call   57d0 <fwp_rc_forget_slot>
    7c37:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7c3c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7c3f:	e9 aa fe ff ff       	jmp    7aee <fwp_drop0+0x8e>
    7c44:	48 8d 3d a5 4d 00 00 	lea    0x4da5(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    7c4b:	e8 00 c8 ff ff       	call   4450 <fwp_trap>

0000000000007c50 <fwp_drop1>:
    7c50:	f3 0f 1e fa          	endbr64
    7c54:	48 8b 15 9d 1f 06 00 	mov    0x61f9d(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    7c5b:	48 89 f8             	mov    %rdi,%rax
    7c5e:	48 2b 05 6b 1f 06 00 	sub    0x61f6b(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7c65:	48 c1 e2 10          	shl    $0x10,%rdx
    7c69:	48 39 d0             	cmp    %rdx,%rax
    7c6c:	0f 83 36 01 00 00    	jae    7da8 <fwp_drop1+0x158>
    7c72:	48 83 ec 18          	sub    $0x18,%rsp
    7c76:	48 8d 35 a3 0b 06 00 	lea    0x60ba3(%rip),%rsi        # 68820 <fwp_heap>
    7c7d:	48 89 c2             	mov    %rax,%rdx
    7c80:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7c87:	48 c1 ea 10          	shr    $0x10,%rdx
    7c8b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7c8f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7c93:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7c97:	48 85 d2             	test   %rdx,%rdx
    7c9a:	74 42                	je     7cde <fwp_drop1+0x8e>
    7c9c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7ca0:	41 80 f8 02          	cmp    $0x2,%r8b
    7ca4:	74 42                	je     7ce8 <fwp_drop1+0x98>
    7ca6:	41 80 f8 01          	cmp    $0x1,%r8b
    7caa:	75 32                	jne    7cde <fwp_drop1+0x8e>
    7cac:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7cb0:	0f b7 c0             	movzwl %ax,%eax
    7cb3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7cb6:	49 0f af c0          	imul   %r8,%rax
    7cba:	48 c1 e8 20          	shr    $0x20,%rax
    7cbe:	48 39 c8             	cmp    %rcx,%rax
    7cc1:	73 1b                	jae    7cde <fwp_drop1+0x8e>
    7cc3:	48 01 c2             	add    %rax,%rdx
    7cc6:	0f b6 02             	movzbl (%rdx),%eax
    7cc9:	84 c0                	test   %al,%al
    7ccb:	74 11                	je     7cde <fwp_drop1+0x8e>
    7ccd:	3c 01                	cmp    $0x1,%al
    7ccf:	74 27                	je     7cf8 <fwp_drop1+0xa8>
    7cd1:	3c ff                	cmp    $0xff,%al
    7cd3:	0f 84 e7 00 00 00    	je     7dc0 <fwp_drop1+0x170>
    7cd9:	83 e8 01             	sub    $0x1,%eax
    7cdc:	88 02                	mov    %al,(%rdx)
    7cde:	48 83 c4 18          	add    $0x18,%rsp
    7ce2:	c3                   	ret
    7ce3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7ce8:	66 85 c0             	test   %ax,%ax
    7ceb:	74 d9                	je     7cc6 <fwp_drop1+0x76>
    7ced:	48 83 c4 18          	add    $0x18,%rsp
    7cf1:	c3                   	ret
    7cf2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7cf8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7cff:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7d06:	48 89 f8             	mov    %rdi,%rax
    7d09:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7d0d:	48 29 c8             	sub    %rcx,%rax
    7d10:	48 c1 e2 10          	shl    $0x10,%rdx
    7d14:	48 39 d0             	cmp    %rdx,%rax
    7d17:	73 71                	jae    7d8a <fwp_drop1+0x13a>
    7d19:	49 89 c2             	mov    %rax,%r10
    7d1c:	49 c1 ea 10          	shr    $0x10,%r10
    7d20:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7d24:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7d28:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7d2c:	4d 85 d2             	test   %r10,%r10
    7d2f:	74 59                	je     7d8a <fwp_drop1+0x13a>
    7d31:	45 0f b6 19          	movzbl (%r9),%r11d
    7d35:	41 80 fb 02          	cmp    $0x2,%r11b
    7d39:	74 75                	je     7db0 <fwp_drop1+0x160>
    7d3b:	41 80 fb 01          	cmp    $0x1,%r11b
    7d3f:	75 49                	jne    7d8a <fwp_drop1+0x13a>
    7d41:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7d45:	0f b7 c0             	movzwl %ax,%eax
    7d48:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7d4c:	49 0f af c3          	imul   %r11,%rax
    7d50:	48 c1 e8 20          	shr    $0x20,%rax
    7d54:	4c 39 c8             	cmp    %r9,%rax
    7d57:	73 31                	jae    7d8a <fwp_drop1+0x13a>
    7d59:	49 01 c2             	add    %rax,%r10
    7d5c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7d60:	75 28                	jne    7d8a <fwp_drop1+0x13a>
    7d62:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7d67:	e8 a4 dc ff ff       	call   5a10 <fwp_mem_free>
    7d6c:	48 8d 35 ad 0a 06 00 	lea    0x60aad(%rip),%rsi        # 68820 <fwp_heap>
    7d73:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7d78:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7d7f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7d86:	48 c1 e2 10          	shl    $0x10,%rdx
    7d8a:	4c 89 c0             	mov    %r8,%rax
    7d8d:	48 29 c8             	sub    %rcx,%rax
    7d90:	48 39 d0             	cmp    %rdx,%rax
    7d93:	0f 83 45 ff ff ff    	jae    7cde <fwp_drop1+0x8e>
    7d99:	4c 89 c7             	mov    %r8,%rdi
    7d9c:	e9 dc fe ff ff       	jmp    7c7d <fwp_drop1+0x2d>
    7da1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7da8:	c3                   	ret
    7da9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7db0:	66 85 c0             	test   %ax,%ax
    7db3:	75 d5                	jne    7d8a <fwp_drop1+0x13a>
    7db5:	eb a5                	jmp    7d5c <fwp_drop1+0x10c>
    7db7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7dbe:	00 00 
    7dc0:	48 89 d0             	mov    %rdx,%rax
    7dc3:	48 c1 e8 11          	shr    $0x11,%rax
    7dc7:	48 31 d0             	xor    %rdx,%rax
    7dca:	48 89 c1             	mov    %rax,%rcx
    7dcd:	48 c1 e9 09          	shr    $0x9,%rcx
    7dd1:	48 31 c8             	xor    %rcx,%rax
    7dd4:	0f b6 c8             	movzbl %al,%ecx
    7dd7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7dde:	00 
    7ddf:	48 85 c0             	test   %rax,%rax
    7de2:	75 25                	jne    7e09 <fwp_drop1+0x1b9>
    7de4:	eb 5e                	jmp    7e44 <fwp_drop1+0x1f4>
    7de6:	0f 1f 40 00          	nopl   0x0(%rax)
    7dea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7df1:	00 00 00 00 
    7df5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7dfc:	00 00 00 00 
    7e00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7e04:	48 85 c0             	test   %rax,%rax
    7e07:	74 3b                	je     7e44 <fwp_drop1+0x1f4>
    7e09:	48 89 c1             	mov    %rax,%rcx
    7e0c:	48 39 10             	cmp    %rdx,(%rax)
    7e0f:	75 ef                	jne    7e00 <fwp_drop1+0x1b0>
    7e11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7e15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7e19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7e1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7e24:	0f 85 b4 fe ff ff    	jne    7cde <fwp_drop1+0x8e>
    7e2a:	48 89 d7             	mov    %rdx,%rdi
    7e2d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7e32:	e8 99 d9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7e37:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7e3c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7e3f:	e9 9a fe ff ff       	jmp    7cde <fwp_drop1+0x8e>
    7e44:	48 8d 3d a5 4b 00 00 	lea    0x4ba5(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    7e4b:	e8 00 c6 ff ff       	call   4450 <fwp_trap>

0000000000007e50 <fwp_drop10>:
    7e50:	48 8b 0d a1 1d 06 00 	mov    0x61da1(%rip),%rcx        # 69bf8 <fwp_heap+0x13d8>
    7e57:	48 89 f8             	mov    %rdi,%rax
    7e5a:	48 2b 05 6f 1d 06 00 	sub    0x61d6f(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    7e61:	48 c1 e1 10          	shl    $0x10,%rcx
    7e65:	48 39 c8             	cmp    %rcx,%rax
    7e68:	0f 83 c2 01 00 00    	jae    8030 <fwp_drop10+0x1e0>
    7e6e:	48 83 ec 18          	sub    $0x18,%rsp
    7e72:	48 89 fa             	mov    %rdi,%rdx
    7e75:	48 8d 35 a4 09 06 00 	lea    0x609a4(%rip),%rsi        # 68820 <fwp_heap>
    7e7c:	48 89 c1             	mov    %rax,%rcx
    7e7f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7e86:	48 c1 e9 10          	shr    $0x10,%rcx
    7e8a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7e8e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7e92:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7e96:	48 85 c9             	test   %rcx,%rcx
    7e99:	74 46                	je     7ee1 <fwp_drop10+0x91>
    7e9b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7e9f:	41 80 f9 02          	cmp    $0x2,%r9b
    7ea3:	0f 84 d7 00 00 00    	je     7f80 <fwp_drop10+0x130>
    7ea9:	41 80 f9 01          	cmp    $0x1,%r9b
    7ead:	75 32                	jne    7ee1 <fwp_drop10+0x91>
    7eaf:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7eb3:	0f b7 c0             	movzwl %ax,%eax
    7eb6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7eb9:	49 0f af c1          	imul   %r9,%rax
    7ebd:	48 c1 e8 20          	shr    $0x20,%rax
    7ec1:	48 39 f8             	cmp    %rdi,%rax
    7ec4:	73 1b                	jae    7ee1 <fwp_drop10+0x91>
    7ec6:	48 01 c1             	add    %rax,%rcx
    7ec9:	0f b6 01             	movzbl (%rcx),%eax
    7ecc:	84 c0                	test   %al,%al
    7ece:	74 11                	je     7ee1 <fwp_drop10+0x91>
    7ed0:	3c 01                	cmp    $0x1,%al
    7ed2:	74 1c                	je     7ef0 <fwp_drop10+0xa0>
    7ed4:	3c ff                	cmp    $0xff,%al
    7ed6:	0f 84 5c 01 00 00    	je     8038 <fwp_drop10+0x1e8>
    7edc:	83 e8 01             	sub    $0x1,%eax
    7edf:	88 01                	mov    %al,(%rcx)
    7ee1:	48 83 c4 18          	add    $0x18,%rsp
    7ee5:	c3                   	ret
    7ee6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7eed:	00 00 00 
    7ef0:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7ef7:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7efe:	48 89 d0             	mov    %rdx,%rax
    7f01:	49 89 d1             	mov    %rdx,%r9
    7f04:	48 c1 e1 10          	shl    $0x10,%rcx
    7f08:	48 29 f8             	sub    %rdi,%rax
    7f0b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7f0f:	78 7f                	js     7f90 <fwp_drop10+0x140>
    7f11:	48 39 c8             	cmp    %rcx,%rax
    7f14:	73 cb                	jae    7ee1 <fwp_drop10+0x91>
    7f16:	48 89 c1             	mov    %rax,%rcx
    7f19:	48 c1 e9 10          	shr    $0x10,%rcx
    7f1d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7f21:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7f25:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7f29:	48 85 f6             	test   %rsi,%rsi
    7f2c:	74 b3                	je     7ee1 <fwp_drop10+0x91>
    7f2e:	0f b6 39             	movzbl (%rcx),%edi
    7f31:	40 80 ff 02          	cmp    $0x2,%dil
    7f35:	74 39                	je     7f70 <fwp_drop10+0x120>
    7f37:	40 80 ff 01          	cmp    $0x1,%dil
    7f3b:	75 a4                	jne    7ee1 <fwp_drop10+0x91>
    7f3d:	8b 79 18             	mov    0x18(%rcx),%edi
    7f40:	0f b7 c0             	movzwl %ax,%eax
    7f43:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7f46:	48 0f af c7          	imul   %rdi,%rax
    7f4a:	48 c1 e8 20          	shr    $0x20,%rax
    7f4e:	48 39 c8             	cmp    %rcx,%rax
    7f51:	73 8e                	jae    7ee1 <fwp_drop10+0x91>
    7f53:	48 01 c6             	add    %rax,%rsi
    7f56:	80 3e 01             	cmpb   $0x1,(%rsi)
    7f59:	75 86                	jne    7ee1 <fwp_drop10+0x91>
    7f5b:	48 89 d7             	mov    %rdx,%rdi
    7f5e:	48 83 c4 18          	add    $0x18,%rsp
    7f62:	e9 a9 da ff ff       	jmp    5a10 <fwp_mem_free>
    7f67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7f6e:	00 00 
    7f70:	66 85 c0             	test   %ax,%ax
    7f73:	74 e1                	je     7f56 <fwp_drop10+0x106>
    7f75:	48 83 c4 18          	add    $0x18,%rsp
    7f79:	c3                   	ret
    7f7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7f80:	66 85 c0             	test   %ax,%ax
    7f83:	0f 84 40 ff ff ff    	je     7ec9 <fwp_drop10+0x79>
    7f89:	48 83 c4 18          	add    $0x18,%rsp
    7f8d:	c3                   	ret
    7f8e:	66 90                	xchg   %ax,%ax
    7f90:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7f94:	48 39 c8             	cmp    %rcx,%rax
    7f97:	73 74                	jae    800d <fwp_drop10+0x1bd>
    7f99:	49 89 c2             	mov    %rax,%r10
    7f9c:	49 c1 ea 10          	shr    $0x10,%r10
    7fa0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7fa4:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7fa8:	4d 8b 50 20          	mov    0x20(%r8),%r10
    7fac:	4d 85 d2             	test   %r10,%r10
    7faf:	74 5c                	je     800d <fwp_drop10+0x1bd>
    7fb1:	45 0f b6 18          	movzbl (%r8),%r11d
    7fb5:	41 80 fb 02          	cmp    $0x2,%r11b
    7fb9:	74 6d                	je     8028 <fwp_drop10+0x1d8>
    7fbb:	41 80 fb 01          	cmp    $0x1,%r11b
    7fbf:	75 4c                	jne    800d <fwp_drop10+0x1bd>
    7fc1:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7fc5:	0f b7 c0             	movzwl %ax,%eax
    7fc8:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    7fcc:	49 0f af c3          	imul   %r11,%rax
    7fd0:	48 c1 e8 20          	shr    $0x20,%rax
    7fd4:	4c 39 c0             	cmp    %r8,%rax
    7fd7:	73 34                	jae    800d <fwp_drop10+0x1bd>
    7fd9:	49 01 c2             	add    %rax,%r10
    7fdc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7fe0:	75 2b                	jne    800d <fwp_drop10+0x1bd>
    7fe2:	4c 89 cf             	mov    %r9,%rdi
    7fe5:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7fea:	e8 21 da ff ff       	call   5a10 <fwp_mem_free>
    7fef:	48 8d 35 2a 08 06 00 	lea    0x6082a(%rip),%rsi        # 68820 <fwp_heap>
    7ff6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7ffb:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8002:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    8009:	48 c1 e1 10          	shl    $0x10,%rcx
    800d:	48 89 d0             	mov    %rdx,%rax
    8010:	48 29 f8             	sub    %rdi,%rax
    8013:	48 39 c8             	cmp    %rcx,%rax
    8016:	0f 82 60 fe ff ff    	jb     7e7c <fwp_drop10+0x2c>
    801c:	e9 c0 fe ff ff       	jmp    7ee1 <fwp_drop10+0x91>
    8021:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8028:	66 85 c0             	test   %ax,%ax
    802b:	75 e0                	jne    800d <fwp_drop10+0x1bd>
    802d:	eb ad                	jmp    7fdc <fwp_drop10+0x18c>
    802f:	90                   	nop
    8030:	c3                   	ret
    8031:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8038:	48 89 c8             	mov    %rcx,%rax
    803b:	48 c1 e8 11          	shr    $0x11,%rax
    803f:	48 31 c8             	xor    %rcx,%rax
    8042:	48 89 c2             	mov    %rax,%rdx
    8045:	48 c1 ea 09          	shr    $0x9,%rdx
    8049:	48 31 d0             	xor    %rdx,%rax
    804c:	0f b6 d0             	movzbl %al,%edx
    804f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    8056:	00 
    8057:	48 85 c0             	test   %rax,%rax
    805a:	75 0d                	jne    8069 <fwp_drop10+0x219>
    805c:	eb 46                	jmp    80a4 <fwp_drop10+0x254>
    805e:	66 90                	xchg   %ax,%ax
    8060:	48 8b 42 10          	mov    0x10(%rdx),%rax
    8064:	48 85 c0             	test   %rax,%rax
    8067:	74 3b                	je     80a4 <fwp_drop10+0x254>
    8069:	48 89 c2             	mov    %rax,%rdx
    806c:	48 39 08             	cmp    %rcx,(%rax)
    806f:	75 ef                	jne    8060 <fwp_drop10+0x210>
    8071:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8075:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    8079:	48 89 50 08          	mov    %rdx,0x8(%rax)
    807d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    8084:	0f 85 57 fe ff ff    	jne    7ee1 <fwp_drop10+0x91>
    808a:	48 89 cf             	mov    %rcx,%rdi
    808d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8092:	e8 39 d7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8097:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    809c:	c6 01 fe             	movb   $0xfe,(%rcx)
    809f:	e9 3d fe ff ff       	jmp    7ee1 <fwp_drop10+0x91>
    80a4:	48 8d 3d 45 49 00 00 	lea    0x4945(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    80ab:	e8 a0 c3 ff ff       	call   4450 <fwp_trap>

00000000000080b0 <f37>:
    80b0:	41 57                	push   %r15
    80b2:	41 56                	push   %r14
    80b4:	41 55                	push   %r13
    80b6:	41 54                	push   %r12
    80b8:	55                   	push   %rbp
    80b9:	53                   	push   %rbx
    80ba:	48 83 ec 38          	sub    $0x38,%rsp
    80be:	48 8b 15 33 1b 06 00 	mov    0x61b33(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    80c5:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    80ca:	48 c1 e2 10          	shl    $0x10,%rdx
    80ce:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    80d5:	00 00 
    80d7:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    80dc:	48 8b 0d ed 1a 06 00 	mov    0x61aed(%rip),%rcx        # 69bd0 <fwp_heap+0x13b0>
    80e3:	48 85 ff             	test   %rdi,%rdi
    80e6:	0f 84 6e 03 00 00    	je     845a <f37+0x3aa>
    80ec:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    80f1:	4c 8b 68 10          	mov    0x10(%rax),%r13
    80f5:	4c 89 e8             	mov    %r13,%rax
    80f8:	48 29 c8             	sub    %rcx,%rax
    80fb:	48 39 d0             	cmp    %rdx,%rax
    80fe:	0f 83 3c 03 00 00    	jae    8440 <f37+0x390>
    8104:	48 89 c2             	mov    %rax,%rdx
    8107:	48 c1 ea 10          	shr    $0x10,%rdx
    810b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    810f:	48 8b 15 02 1b 06 00 	mov    0x61b02(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    8116:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    811a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    811e:	48 85 ff             	test   %rdi,%rdi
    8121:	0f 84 19 03 00 00    	je     8440 <f37+0x390>
    8127:	0f b6 0a             	movzbl (%rdx),%ecx
    812a:	80 f9 02             	cmp    $0x2,%cl
    812d:	0f 84 9d 02 00 00    	je     83d0 <f37+0x320>
    8133:	80 f9 01             	cmp    $0x1,%cl
    8136:	75 24                	jne    815c <f37+0xac>
    8138:	8b 4a 18             	mov    0x18(%rdx),%ecx
    813b:	0f b7 c0             	movzwl %ax,%eax
    813e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8141:	48 0f af c1          	imul   %rcx,%rax
    8145:	48 c1 e8 20          	shr    $0x20,%rax
    8149:	48 39 d0             	cmp    %rdx,%rax
    814c:	73 0e                	jae    815c <f37+0xac>
    814e:	48 01 c7             	add    %rax,%rdi
    8151:	0f b6 07             	movzbl (%rdi),%eax
    8154:	84 c0                	test   %al,%al
    8156:	0f 85 94 02 00 00    	jne    83f0 <f37+0x340>
    815c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8161:	48 8b 40 10          	mov    0x10(%rax),%rax
    8165:	ba 01 00 00 00       	mov    $0x1,%edx
    816a:	48 85 c0             	test   %rax,%rax
    816d:	74 0e                	je     817d <f37+0xcd>
    816f:	90                   	nop
    8170:	48 8b 40 10          	mov    0x10(%rax),%rax
    8174:	48 83 c2 01          	add    $0x1,%rdx
    8178:	48 85 c0             	test   %rax,%rax
    817b:	75 f3                	jne    8170 <f37+0xc0>
    817d:	4d 85 ed             	test   %r13,%r13
    8180:	0f 84 ea 02 00 00    	je     8470 <f37+0x3c0>
    8186:	4c 89 e8             	mov    %r13,%rax
    8189:	31 db                	xor    %ebx,%ebx
    818b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8190:	48 8b 40 10          	mov    0x10(%rax),%rax
    8194:	48 83 c3 01          	add    $0x1,%rbx
    8198:	48 85 c0             	test   %rax,%rax
    819b:	75 f3                	jne    8190 <f37+0xe0>
    819d:	48 39 d3             	cmp    %rdx,%rbx
    81a0:	48 0f 47 da          	cmova  %rdx,%rbx
    81a4:	48 89 d8             	mov    %rbx,%rax
    81a7:	48 c1 e8 3c          	shr    $0x3c,%rax
    81ab:	0f 85 cd 03 00 00    	jne    857e <f37+0x4ce>
    81b1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    81b5:	be 02 00 00 00       	mov    $0x2,%esi
    81ba:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    81c1:	00 
    81c2:	e8 49 dd ff ff       	call   5f10 <fwp_heap_alloc>
    81c7:	48 89 28             	mov    %rbp,(%rax)
    81ca:	48 8b 15 27 1a 06 00 	mov    0x61a27(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    81d1:	49 89 c4             	mov    %rax,%r12
    81d4:	48 2b 05 f5 19 06 00 	sub    0x619f5(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    81db:	48 c1 e2 10          	shl    $0x10,%rdx
    81df:	48 39 d0             	cmp    %rdx,%rax
    81e2:	73 57                	jae    823b <f37+0x18b>
    81e4:	48 89 c2             	mov    %rax,%rdx
    81e7:	48 c1 ea 10          	shr    $0x10,%rdx
    81eb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    81ef:	48 8b 15 22 1a 06 00 	mov    0x61a22(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    81f6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    81fa:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    81fe:	48 85 ed             	test   %rbp,%rbp
    8201:	74 38                	je     823b <f37+0x18b>
    8203:	0f b6 0a             	movzbl (%rdx),%ecx
    8206:	80 f9 02             	cmp    $0x2,%cl
    8209:	0f 84 21 02 00 00    	je     8430 <f37+0x380>
    820f:	80 f9 01             	cmp    $0x1,%cl
    8212:	75 27                	jne    823b <f37+0x18b>
    8214:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8217:	0f b7 c0             	movzwl %ax,%eax
    821a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    821d:	48 0f af c1          	imul   %rcx,%rax
    8221:	48 c1 e8 20          	shr    $0x20,%rax
    8225:	48 39 d0             	cmp    %rdx,%rax
    8228:	73 11                	jae    823b <f37+0x18b>
    822a:	48 01 c5             	add    %rax,%rbp
    822d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8231:	0f 84 a7 02 00 00    	je     84de <f37+0x42e>
    8237:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    823b:	48 85 db             	test   %rbx,%rbx
    823e:	74 5d                	je     829d <f37+0x1ed>
    8240:	48 c1 e3 04          	shl    $0x4,%rbx
    8244:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8249:	4c 89 e5             	mov    %r12,%rbp
    824c:	4d 89 ef             	mov    %r13,%r15
    824f:	4c 01 e3             	add    %r12,%rbx
    8252:	0f 1f 00             	nopl   (%rax)
    8255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    825c:	00 00 00 00 
    8260:	49 8b 46 08          	mov    0x8(%r14),%rax
    8264:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8268:	48 83 c5 10          	add    $0x10,%rbp
    826c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8271:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8275:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8279:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    827e:	e8 ed e3 ff ff       	call   6670 <w120>
    8283:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8288:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    828c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8290:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8294:	4d 8b 76 10          	mov    0x10(%r14),%r14
    8298:	48 39 eb             	cmp    %rbp,%rbx
    829b:	75 c3                	jne    8260 <f37+0x1b0>
    829d:	4c 89 ef             	mov    %r13,%rdi
    82a0:	31 db                	xor    %ebx,%ebx
    82a2:	e8 89 ed ff ff       	call   7030 <fwp_drop4>
    82a7:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    82ac:	e8 7f ed ff ff       	call   7030 <fwp_drop4>
    82b1:	4d 8b 2c 24          	mov    (%r12),%r13
    82b5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    82b9:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    82c0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    82c7:	4d 85 ed             	test   %r13,%r13
    82ca:	74 3f                	je     830b <f37+0x25b>
    82cc:	0f 1f 40 00          	nopl   0x0(%rax)
    82d0:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    82d7:	49 8b 54 dc 10       	mov    0x10(%r12,%rbx,8),%rdx
    82dc:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    82e3:	00 f0 3f 
    82e6:	48 83 c3 02          	add    $0x2,%rbx
    82ea:	48 89 ce             	mov    %rcx,%rsi
    82ed:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    82f3:	e8 f8 df ff ff       	call   62f0 <fwp_p_ad_push>
    82f8:	4c 39 eb             	cmp    %r13,%rbx
    82fb:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    8301:	48 89 c7             	mov    %rax,%rdi
    8304:	72 ca                	jb     82d0 <f37+0x220>
    8306:	66 49 0f 7e c5       	movq   %xmm0,%r13
    830b:	4c 89 e7             	mov    %r12,%rdi
    830e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8313:	e8 38 fb ff ff       	call   7e50 <fwp_drop10>
    8318:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    831d:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    8322:	31 ff                	xor    %edi,%edi
    8324:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    8329:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    832e:	e8 cd dd ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    8333:	48 8b 15 be 18 06 00 	mov    0x618be(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    833a:	48 89 c5             	mov    %rax,%rbp
    833d:	48 2b 05 8c 18 06 00 	sub    0x6188c(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    8344:	48 c1 e2 10          	shl    $0x10,%rdx
    8348:	48 39 d0             	cmp    %rdx,%rax
    834b:	73 55                	jae    83a2 <f37+0x2f2>
    834d:	48 89 c2             	mov    %rax,%rdx
    8350:	48 c1 ea 10          	shr    $0x10,%rdx
    8354:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8358:	48 8b 15 b9 18 06 00 	mov    0x618b9(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    835f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8363:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    8367:	48 85 db             	test   %rbx,%rbx
    836a:	74 36                	je     83a2 <f37+0x2f2>
    836c:	0f b6 0a             	movzbl (%rdx),%ecx
    836f:	80 f9 02             	cmp    $0x2,%cl
    8372:	0f 84 a8 00 00 00    	je     8420 <f37+0x370>
    8378:	80 f9 01             	cmp    $0x1,%cl
    837b:	75 25                	jne    83a2 <f37+0x2f2>
    837d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8380:	0f b7 c0             	movzwl %ax,%eax
    8383:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8386:	48 0f af c1          	imul   %rcx,%rax
    838a:	48 c1 e8 20          	shr    $0x20,%rax
    838e:	48 39 d0             	cmp    %rdx,%rax
    8391:	73 0f                	jae    83a2 <f37+0x2f2>
    8393:	48 01 c3             	add    %rax,%rbx
    8396:	80 3b ff             	cmpb   $0xff,(%rbx)
    8399:	0f 84 32 01 00 00    	je     84d1 <f37+0x421>
    839f:	c6 03 01             	movb   $0x1,(%rbx)
    83a2:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    83a7:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    83ae:	00 00 
    83b0:	0f 85 d4 01 00 00    	jne    858a <f37+0x4da>
    83b6:	48 83 c4 38          	add    $0x38,%rsp
    83ba:	48 89 e8             	mov    %rbp,%rax
    83bd:	5b                   	pop    %rbx
    83be:	5d                   	pop    %rbp
    83bf:	41 5c                	pop    %r12
    83c1:	41 5d                	pop    %r13
    83c3:	41 5e                	pop    %r14
    83c5:	41 5f                	pop    %r15
    83c7:	c3                   	ret
    83c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    83cf:	00 
    83d0:	66 85 c0             	test   %ax,%ax
    83d3:	0f 85 83 fd ff ff    	jne    815c <f37+0xac>
    83d9:	0f b6 07             	movzbl (%rdi),%eax
    83dc:	84 c0                	test   %al,%al
    83de:	0f 84 78 fd ff ff    	je     815c <f37+0xac>
    83e4:	90                   	nop
    83e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    83ec:	00 00 00 00 
    83f0:	8b 15 f2 20 06 00    	mov    0x620f2(%rip),%edx        # 6a4e8 <iteration_active>
    83f6:	85 d2                	test   %edx,%edx
    83f8:	75 56                	jne    8450 <f37+0x3a0>
    83fa:	3c fd                	cmp    $0xfd,%al
    83fc:	0f 87 4b 01 00 00    	ja     854d <f37+0x49d>
    8402:	83 c0 01             	add    $0x1,%eax
    8405:	88 07                	mov    %al,(%rdi)
    8407:	31 d2                	xor    %edx,%edx
    8409:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    840f:	0f 85 47 fd ff ff    	jne    815c <f37+0xac>
    8415:	e9 63 fd ff ff       	jmp    817d <f37+0xcd>
    841a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8420:	66 85 c0             	test   %ax,%ax
    8423:	0f 85 79 ff ff ff    	jne    83a2 <f37+0x2f2>
    8429:	e9 68 ff ff ff       	jmp    8396 <f37+0x2e6>
    842e:	66 90                	xchg   %ax,%ax
    8430:	66 85 c0             	test   %ax,%ax
    8433:	0f 85 02 fe ff ff    	jne    823b <f37+0x18b>
    8439:	e9 ef fd ff ff       	jmp    822d <f37+0x17d>
    843e:	66 90                	xchg   %ax,%ax
    8440:	4c 89 e8             	mov    %r13,%rax
    8443:	e9 1d fd ff ff       	jmp    8165 <f37+0xb5>
    8448:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    844f:	00 
    8450:	48 83 05 78 20 06 00 	addq   $0x1,0x62078(%rip)        # 6a4d0 <iteration_retains>
    8457:	01 
    8458:	eb a0                	jmp    83fa <f37+0x34a>
    845a:	48 f7 d9             	neg    %rcx
    845d:	48 39 d1             	cmp    %rdx,%rcx
    8460:	0f 82 85 00 00 00    	jb     84eb <f37+0x43b>
    8466:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    846d:	00 00 00 
    8470:	be 02 00 00 00       	mov    $0x2,%esi
    8475:	bf 08 00 00 00       	mov    $0x8,%edi
    847a:	e8 91 da ff ff       	call   5f10 <fwp_heap_alloc>
    847f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8486:	48 8b 15 6b 17 06 00 	mov    0x6176b(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    848d:	49 89 c4             	mov    %rax,%r12
    8490:	48 2b 05 39 17 06 00 	sub    0x61739(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    8497:	48 c1 e2 10          	shl    $0x10,%rdx
    849b:	48 39 d0             	cmp    %rdx,%rax
    849e:	0f 83 b3 00 00 00    	jae    8557 <f37+0x4a7>
    84a4:	48 89 c2             	mov    %rax,%rdx
    84a7:	45 31 ed             	xor    %r13d,%r13d
    84aa:	48 c1 ea 10          	shr    $0x10,%rdx
    84ae:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    84b2:	48 8b 15 5f 17 06 00 	mov    0x6175f(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    84b9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    84bd:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    84c1:	48 85 ed             	test   %rbp,%rbp
    84c4:	0f 84 d3 fd ff ff    	je     829d <f37+0x1ed>
    84ca:	31 db                	xor    %ebx,%ebx
    84cc:	e9 32 fd ff ff       	jmp    8203 <f37+0x153>
    84d1:	48 89 df             	mov    %rbx,%rdi
    84d4:	e8 f7 d2 ff ff       	call   57d0 <fwp_rc_forget_slot>
    84d9:	e9 c1 fe ff ff       	jmp    839f <f37+0x2ef>
    84de:	48 89 ef             	mov    %rbp,%rdi
    84e1:	e8 ea d2 ff ff       	call   57d0 <fwp_rc_forget_slot>
    84e6:	e9 4c fd ff ff       	jmp    8237 <f37+0x187>
    84eb:	48 89 c8             	mov    %rcx,%rax
    84ee:	48 c1 e8 10          	shr    $0x10,%rax
    84f2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    84f6:	48 8b 05 1b 17 06 00 	mov    0x6171b(%rip),%rax        # 69c18 <fwp_heap+0x13f8>
    84fd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8501:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8505:	48 85 ff             	test   %rdi,%rdi
    8508:	0f 84 62 ff ff ff    	je     8470 <f37+0x3c0>
    850e:	0f b6 02             	movzbl (%rdx),%eax
    8511:	3c 02                	cmp    $0x2,%al
    8513:	74 4a                	je     855f <f37+0x4af>
    8515:	3c 01                	cmp    $0x1,%al
    8517:	0f 85 53 ff ff ff    	jne    8470 <f37+0x3c0>
    851d:	0f b7 c1             	movzwl %cx,%eax
    8520:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8523:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8526:	48 0f af c1          	imul   %rcx,%rax
    852a:	48 c1 e8 20          	shr    $0x20,%rax
    852e:	48 39 d0             	cmp    %rdx,%rax
    8531:	0f 83 39 ff ff ff    	jae    8470 <f37+0x3c0>
    8537:	48 01 c7             	add    %rax,%rdi
    853a:	0f b6 07             	movzbl (%rdi),%eax
    853d:	84 c0                	test   %al,%al
    853f:	0f 84 2b ff ff ff    	je     8470 <f37+0x3c0>
    8545:	45 31 ed             	xor    %r13d,%r13d
    8548:	e9 a3 fe ff ff       	jmp    83f0 <f37+0x340>
    854d:	e8 5e d1 ff ff       	call   56b0 <fwp_rc_wide_dup>
    8552:	e9 b0 fe ff ff       	jmp    8407 <f37+0x357>
    8557:	45 31 ed             	xor    %r13d,%r13d
    855a:	e9 3e fd ff ff       	jmp    829d <f37+0x1ed>
    855f:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    8565:	49 89 cd             	mov    %rcx,%r13
    8568:	0f 85 02 ff ff ff    	jne    8470 <f37+0x3c0>
    856e:	0f b6 07             	movzbl (%rdi),%eax
    8571:	84 c0                	test   %al,%al
    8573:	0f 85 77 fe ff ff    	jne    83f0 <f37+0x340>
    8579:	e9 f2 fe ff ff       	jmp    8470 <f37+0x3c0>
    857e:	48 8d 3d 66 3c 00 00 	lea    0x3c66(%rip),%rdi        # c1eb <_IO_stdin_used+0x1eb>
    8585:	e8 c6 be ff ff       	call   4450 <fwp_trap>
    858a:	e8 c1 ae ff ff       	call   3450 <__stack_chk_fail@plt>
    858f:	90                   	nop

0000000000008590 <fwp_owned_entry37>:
    8590:	f3 0f 1e fa          	endbr64
    8594:	48 8b 3f             	mov    (%rdi),%rdi
    8597:	e9 14 fb ff ff       	jmp    80b0 <f37>
    859c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000085a0 <e37>:
    85a0:	f3 0f 1e fa          	endbr64
    85a4:	53                   	push   %rbx
    85a5:	48 8b 1f             	mov    (%rdi),%rbx
    85a8:	48 89 df             	mov    %rbx,%rdi
    85ab:	e8 30 e2 ff ff       	call   67e0 <fwp_rc_share>
    85b0:	48 89 df             	mov    %rbx,%rdi
    85b3:	e8 f8 fa ff ff       	call   80b0 <f37>
    85b8:	48 89 c3             	mov    %rax,%rbx
    85bb:	48 89 c7             	mov    %rax,%rdi
    85be:	e8 1d e2 ff ff       	call   67e0 <fwp_rc_share>
    85c3:	48 89 d8             	mov    %rbx,%rax
    85c6:	5b                   	pop    %rbx
    85c7:	c3                   	ret
    85c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    85cf:	00 

00000000000085d0 <fwp_write>:
    85d0:	41 57                	push   %r15
    85d2:	41 56                	push   %r14
    85d4:	41 55                	push   %r13
    85d6:	41 54                	push   %r12
    85d8:	55                   	push   %rbp
    85d9:	53                   	push   %rbx
    85da:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    85e1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    85e8:	00 00 
    85ea:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    85f1:	00 
    85f2:	49 89 d4             	mov    %rdx,%r12
    85f5:	8b 12                	mov    (%rdx),%edx
    85f7:	83 fa 19             	cmp    $0x19,%edx
    85fa:	77 6a                	ja     8666 <fwp_write+0x96>
    85fc:	48 89 f5             	mov    %rsi,%rbp
    85ff:	89 d0                	mov    %edx,%eax
    8601:	89 ce                	mov    %ecx,%esi
    8603:	48 89 fb             	mov    %rdi,%rbx
    8606:	48 8d 0d c3 46 00 00 	lea    0x46c3(%rip),%rcx        # ccd0 <_IO_stdin_used+0xcd0>
    860d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8611:	48 01 c8             	add    %rcx,%rax
    8614:	3e ff e0             	notrack jmp *%rax
    8617:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    861e:	00 00 
    8620:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8624:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8628:	48 89 ca             	mov    %rcx,%rdx
    862b:	48 85 c9             	test   %rcx,%rcx
    862e:	0f 88 9c 0c 00 00    	js     92d0 <fwp_write+0xd00>
    8634:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    863b:	00 
    863c:	48 89 c6             	mov    %rax,%rsi
    863f:	4c 89 e7             	mov    %r12,%rdi
    8642:	e8 f9 b3 ff ff       	call   3a40 <fwp_fmt_u128>
    8647:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    864e:	00 00 
    8650:	4c 89 e7             	mov    %r12,%rdi
    8653:	e8 e8 ad ff ff       	call   3440 <strlen@plt>
    8658:	4c 89 e6             	mov    %r12,%rsi
    865b:	48 89 df             	mov    %rbx,%rdi
    865e:	48 89 c2             	mov    %rax,%rdx
    8661:	e8 8a ba ff ff       	call   40f0 <buf_put>
    8666:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    866d:	00 
    866e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8675:	00 00 
    8677:	0f 85 28 04 00 00    	jne    8aa5 <fwp_write+0x4d5>
    867d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8684:	5b                   	pop    %rbx
    8685:	5d                   	pop    %rbp
    8686:	41 5c                	pop    %r12
    8688:	41 5d                	pop    %r13
    868a:	41 5e                	pop    %r14
    868c:	41 5f                	pop    %r15
    868e:	c3                   	ret
    868f:	90                   	nop
    8690:	49 89 e9             	mov    %rbp,%r9
    8693:	4c 8d 05 7b 3b 00 00 	lea    0x3b7b(%rip),%r8        # c215 <_IO_stdin_used+0x215>
    869a:	b9 00 02 00 00       	mov    $0x200,%ecx
    869f:	ba 02 00 00 00       	mov    $0x2,%edx
    86a4:	be 00 02 00 00       	mov    $0x200,%esi
    86a9:	31 c0                	xor    %eax,%eax
    86ab:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    86b2:	00 
    86b3:	e8 e8 ac ff ff       	call   33a0 <__snprintf_chk@plt>
    86b8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    86bf:	00 
    86c0:	e8 7b ad ff ff       	call   3440 <strlen@plt>
    86c5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    86cc:	00 
    86cd:	48 89 df             	mov    %rbx,%rdi
    86d0:	48 89 c2             	mov    %rax,%rdx
    86d3:	e8 18 ba ff ff       	call   40f0 <buf_put>
    86d8:	eb 8c                	jmp    8666 <fwp_write+0x96>
    86da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    86e0:	49 89 e9             	mov    %rbp,%r9
    86e3:	4c 8d 05 26 3b 00 00 	lea    0x3b26(%rip),%r8        # c210 <_IO_stdin_used+0x210>
    86ea:	eb ae                	jmp    869a <fwp_write+0xca>
    86ec:	0f 1f 40 00          	nopl   0x0(%rax)
    86f0:	83 fa 13             	cmp    $0x13,%edx
    86f3:	48 8d 05 0c 3b 00 00 	lea    0x3b0c(%rip),%rax        # c206 <_IO_stdin_used+0x206>
    86fa:	48 8d 35 0a 3b 00 00 	lea    0x3b0a(%rip),%rsi        # c20b <_IO_stdin_used+0x20b>
    8701:	ba 04 00 00 00       	mov    $0x4,%edx
    8706:	48 0f 44 f0          	cmove  %rax,%rsi
    870a:	45 31 ed             	xor    %r13d,%r13d
    870d:	e8 de b9 ff ff       	call   40f0 <buf_put>
    8712:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8717:	0f 84 a3 08 00 00    	je     8fc0 <fwp_write+0x9f0>
    871d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8722:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8727:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    872c:	48 89 df             	mov    %rbx,%rdi
    872f:	49 0f 44 c5          	cmove  %r13,%rax
    8733:	31 c9                	xor    %ecx,%ecx
    8735:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    873a:	e8 91 fe ff ff       	call   85d0 <fwp_write>
    873f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8744:	0f 84 6e 09 00 00    	je     90b8 <fwp_write+0xae8>
    874a:	49 83 c5 01          	add    $0x1,%r13
    874e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8752:	0f 83 68 08 00 00    	jae    8fc0 <fwp_write+0x9f0>
    8758:	ba 02 00 00 00       	mov    $0x2,%edx
    875d:	48 8d 35 f1 3a 00 00 	lea    0x3af1(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    8764:	48 89 df             	mov    %rbx,%rdi
    8767:	e8 84 b9 ff ff       	call   40f0 <buf_put>
    876c:	eb af                	jmp    871d <fwp_write+0x14d>
    876e:	66 90                	xchg   %ax,%ax
    8770:	ba 06 00 00 00       	mov    $0x6,%edx
    8775:	48 8d 35 b2 3a 00 00 	lea    0x3ab2(%rip),%rsi        # c22e <_IO_stdin_used+0x22e>
    877c:	48 83 c5 10          	add    $0x10,%rbp
    8780:	e8 6b b9 ff ff       	call   40f0 <buf_put>
    8785:	48 89 ef             	mov    %rbp,%rdi
    8788:	e8 b3 ac ff ff       	call   3440 <strlen@plt>
    878d:	48 89 ee             	mov    %rbp,%rsi
    8790:	48 89 df             	mov    %rbx,%rdi
    8793:	48 89 c2             	mov    %rax,%rdx
    8796:	e8 55 b9 ff ff       	call   40f0 <buf_put>
    879b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    87a0:	ba 01 00 00 00       	mov    $0x1,%edx
    87a5:	48 89 df             	mov    %rbx,%rdi
    87a8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    87ad:	e8 3e b9 ff ff       	call   40f0 <buf_put>
    87b2:	e9 af fe ff ff       	jmp    8666 <fwp_write+0x96>
    87b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    87be:	00 00 
    87c0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    87c7:	00 
    87c8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    87cf:	00 00 
    87d1:	0f 85 ce 02 00 00    	jne    8aa5 <fwp_write+0x4d5>
    87d7:	ba 0a 00 00 00       	mov    $0xa,%edx
    87dc:	48 8d 35 37 3a 00 00 	lea    0x3a37(%rip),%rsi        # c21a <_IO_stdin_used+0x21a>
    87e3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    87ea:	48 89 df             	mov    %rbx,%rdi
    87ed:	5b                   	pop    %rbx
    87ee:	5d                   	pop    %rbp
    87ef:	41 5c                	pop    %r12
    87f1:	41 5d                	pop    %r13
    87f3:	41 5e                	pop    %r14
    87f5:	41 5f                	pop    %r15
    87f7:	e9 f4 b8 ff ff       	jmp    40f0 <buf_put>
    87fc:	0f 1f 40 00          	nopl   0x0(%rax)
    8800:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8805:	4d 85 ed             	test   %r13,%r13
    8808:	0f 84 02 0c 00 00    	je     9410 <fwp_write+0xe40>
    880e:	48 8d 35 4d 3a 00 00 	lea    0x3a4d(%rip),%rsi        # c262 <_IO_stdin_used+0x262>
    8815:	4c 89 ef             	mov    %r13,%rdi
    8818:	e8 03 ad ff ff       	call   3520 <strcmp@plt>
    881d:	41 89 c1             	mov    %eax,%r9d
    8820:	85 c0                	test   %eax,%eax
    8822:	0f 84 6c 0c 00 00    	je     9494 <fwp_write+0xec4>
    8828:	4c 89 ef             	mov    %r13,%rdi
    882b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8830:	e8 0b ac ff ff       	call   3440 <strlen@plt>
    8835:	4c 89 ee             	mov    %r13,%rsi
    8838:	48 89 df             	mov    %rbx,%rdi
    883b:	48 89 c2             	mov    %rax,%rdx
    883e:	e8 ad b8 ff ff       	call   40f0 <buf_put>
    8843:	ba 01 00 00 00       	mov    $0x1,%edx
    8848:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    884d:	48 89 df             	mov    %rbx,%rdi
    8850:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8855:	e8 96 b8 ff ff       	call   40f0 <buf_put>
    885a:	ba 01 00 00 00       	mov    $0x1,%edx
    885f:	4c 89 fe             	mov    %r15,%rsi
    8862:	48 89 df             	mov    %rbx,%rdi
    8865:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    886a:	e8 81 b8 ff ff       	call   40f0 <buf_put>
    886f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8874:	45 31 f6             	xor    %r14d,%r14d
    8877:	85 d2                	test   %edx,%edx
    8879:	0f 8e 81 0a 00 00    	jle    9300 <fwp_write+0xd30>
    887f:	45 31 ed             	xor    %r13d,%r13d
    8882:	4d 85 ed             	test   %r13,%r13
    8885:	0f 85 75 07 00 00    	jne    9000 <fwp_write+0xa30>
    888b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8892:	00 
    8893:	45 85 f6             	test   %r14d,%r14d
    8896:	0f 84 84 07 00 00    	je     9020 <fwp_write+0xa50>
    889c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    88a1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    88a6:	48 89 df             	mov    %rbx,%rdi
    88a9:	49 83 c5 01          	add    $0x1,%r13
    88ad:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    88b1:	31 c9                	xor    %ecx,%ecx
    88b3:	e8 18 fd ff ff       	call   85d0 <fwp_write>
    88b8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    88bd:	7f c3                	jg     8882 <fwp_write+0x2b2>
    88bf:	45 85 f6             	test   %r14d,%r14d
    88c2:	0f 84 38 0a 00 00    	je     9300 <fwp_write+0xd30>
    88c8:	b8 29 00 00 00       	mov    $0x29,%eax
    88cd:	ba 01 00 00 00       	mov    $0x1,%edx
    88d2:	4c 89 fe             	mov    %r15,%rsi
    88d5:	48 89 df             	mov    %rbx,%rdi
    88d8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    88dc:	e8 0f b8 ff ff       	call   40f0 <buf_put>
    88e1:	e9 80 fd ff ff       	jmp    8666 <fwp_write+0x96>
    88e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    88ed:	00 00 00 
    88f0:	ba 01 00 00 00       	mov    $0x1,%edx
    88f5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    88fa:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    88ff:	e8 ec b7 ff ff       	call   40f0 <buf_put>
    8904:	48 85 ed             	test   %rbp,%rbp
    8907:	0f 84 93 06 00 00    	je     8fa0 <fwp_write+0x9d0>
    890d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8911:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8916:	31 c9                	xor    %ecx,%ecx
    8918:	48 89 df             	mov    %rbx,%rdi
    891b:	e8 b0 fc ff ff       	call   85d0 <fwp_write>
    8920:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8924:	48 85 ed             	test   %rbp,%rbp
    8927:	0f 84 73 06 00 00    	je     8fa0 <fwp_write+0x9d0>
    892d:	ba 02 00 00 00       	mov    $0x2,%edx
    8932:	48 8d 35 1c 39 00 00 	lea    0x391c(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    8939:	48 89 df             	mov    %rbx,%rdi
    893c:	e8 af b7 ff ff       	call   40f0 <buf_put>
    8941:	eb ca                	jmp    890d <fwp_write+0x33d>
    8943:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8948:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    894c:	85 f6                	test   %esi,%esi
    894e:	0f 84 fc 07 00 00    	je     9150 <fwp_write+0xb80>
    8954:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    895b:	00 
    895c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8963:	00 00 
    8965:	0f 85 3a 01 00 00    	jne    8aa5 <fwp_write+0x4d5>
    896b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    896f:	4c 89 ea             	mov    %r13,%rdx
    8972:	e9 6c fe ff ff       	jmp    87e3 <fwp_write+0x213>
    8977:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    897e:	00 00 
    8980:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8985:	ba 01 00 00 00       	mov    $0x1,%edx
    898a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    898f:	48 89 ee             	mov    %rbp,%rsi
    8992:	e8 59 b7 ff ff       	call   40f0 <buf_put>
    8997:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    899c:	4c 89 e7             	mov    %r12,%rdi
    899f:	e8 9c aa ff ff       	call   3440 <strlen@plt>
    89a4:	4c 89 e6             	mov    %r12,%rsi
    89a7:	48 89 df             	mov    %rbx,%rdi
    89aa:	48 89 c2             	mov    %rax,%rdx
    89ad:	e8 3e b7 ff ff       	call   40f0 <buf_put>
    89b2:	ba 01 00 00 00       	mov    $0x1,%edx
    89b7:	48 89 ee             	mov    %rbp,%rsi
    89ba:	48 89 df             	mov    %rbx,%rdi
    89bd:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    89c2:	e8 29 b7 ff ff       	call   40f0 <buf_put>
    89c7:	e9 9a fc ff ff       	jmp    8666 <fwp_write+0x96>
    89cc:	0f 1f 40 00          	nopl   0x0(%rax)
    89d0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    89d5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    89d9:	0f 8a 8e 0b 00 00    	jp     956d <fwp_write+0xf9d>
    89df:	66 0f 28 c1          	movapd %xmm1,%xmm0
    89e3:	66 0f 54 05 15 44 00 	andpd  0x4415(%rip),%xmm0        # ce00 <msg.4+0xc0>
    89ea:	00 
    89eb:	bd 01 00 00 00       	mov    $0x1,%ebp
    89f0:	66 0f 2e 05 80 43 00 	ucomisd 0x4380(%rip),%xmm0        # cd78 <msg.4+0x38>
    89f7:	00 
    89f8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    89ff:	00 
    8a00:	0f 87 b2 09 00 00    	ja     93b8 <fwp_write+0xde8>
    8a06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8a0d:	00 00 00 
    8a10:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8a14:	89 ee                	mov    %ebp,%esi
    8a16:	4c 89 e7             	mov    %r12,%rdi
    8a19:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    8a1e:	e8 4d bd ff ff       	call   4770 <fwp_format_g.constprop.0>
    8a23:	31 f6                	xor    %esi,%esi
    8a25:	4c 89 e7             	mov    %r12,%rdi
    8a28:	e8 d3 a9 ff ff       	call   3400 <strtod@plt>
    8a2d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8a32:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8a36:	7a 06                	jp     8a3e <fwp_write+0x46e>
    8a38:	0f 84 e9 01 00 00    	je     8c27 <fwp_write+0x657>
    8a3e:	83 c5 01             	add    $0x1,%ebp
    8a41:	83 fd 12             	cmp    $0x12,%ebp
    8a44:	75 ca                	jne    8a10 <fwp_write+0x440>
    8a46:	be 11 00 00 00       	mov    $0x11,%esi
    8a4b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8a4f:	4c 89 e7             	mov    %r12,%rdi
    8a52:	e8 19 bd ff ff       	call   4770 <fwp_format_g.constprop.0>
    8a57:	e9 cb 01 00 00       	jmp    8c27 <fwp_write+0x657>
    8a5c:	0f 1f 40 00          	nopl   0x0(%rax)
    8a60:	48 83 fd 01          	cmp    $0x1,%rbp
    8a64:	0f 84 e6 08 00 00    	je     9350 <fwp_write+0xd80>
    8a6a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8a6e:	b8 02 00 00 00       	mov    $0x2,%eax
    8a73:	ba 01 00 00 00       	mov    $0x1,%edx
    8a78:	48 0f 44 d0          	cmove  %rax,%rdx
    8a7c:	48 8d 35 7b 37 00 00 	lea    0x377b(%rip),%rsi        # c1fe <_IO_stdin_used+0x1fe>
    8a83:	48 8d 05 79 37 00 00 	lea    0x3779(%rip),%rax        # c203 <_IO_stdin_used+0x203>
    8a8a:	48 0f 44 f0          	cmove  %rax,%rsi
    8a8e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8a95:	00 
    8a96:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8a9d:	00 00 
    8a9f:	0f 84 3e fd ff ff    	je     87e3 <fwp_write+0x213>
    8aa5:	e8 a6 a9 ff ff       	call   3450 <__stack_chk_fail@plt>
    8aaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ab0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8ab5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8aba:	e8 71 b5 ff ff       	call   4030 <buf_grow>
    8abf:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8ac3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8ac9:	4c 03 0b             	add    (%rbx),%r9
    8acc:	66 45 89 11          	mov    %r10w,(%r9)
    8ad0:	45 85 e4             	test   %r12d,%r12d
    8ad3:	0f 8e 07 05 00 00    	jle    8fe0 <fwp_write+0xa10>
    8ad9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8ae0:	55 55 55 
    8ae3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8ae8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8aef:	aa aa aa 
    8af2:	49 83 c1 01          	add    $0x1,%r9
    8af6:	eb 45                	jmp    8b3d <fwp_write+0x56d>
    8af8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8aff:	00 
    8b00:	be 01 00 00 00       	mov    $0x1,%esi
    8b05:	b8 2d 00 00 00       	mov    $0x2d,%eax
    8b0a:	88 07                	mov    %al,(%rdi)
    8b0c:	48 89 e8             	mov    %rbp,%rax
    8b0f:	49 f7 e8             	imul   %r8
    8b12:	48 89 e8             	mov    %rbp,%rax
    8b15:	48 c1 f8 3f          	sar    $0x3f,%rax
    8b19:	48 29 c2             	sub    %rax,%rdx
    8b1c:	48 85 c9             	test   %rcx,%rcx
    8b1f:	0f 95 c0             	setne  %al
    8b22:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8b26:	48 83 ef 01          	sub    $0x1,%rdi
    8b2a:	48 21 c5             	and    %rax,%rbp
    8b2d:	48 29 ea             	sub    %rbp,%rdx
    8b30:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8b34:	49 39 f9             	cmp    %rdi,%r9
    8b37:	0f 84 a3 04 00 00    	je     8fe0 <fwp_write+0xa10>
    8b3d:	48 89 e8             	mov    %rbp,%rax
    8b40:	49 f7 e8             	imul   %r8
    8b43:	48 89 e8             	mov    %rbp,%rax
    8b46:	48 c1 f8 3f          	sar    $0x3f,%rax
    8b4a:	48 89 d1             	mov    %rdx,%rcx
    8b4d:	48 29 c1             	sub    %rax,%rcx
    8b50:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8b54:	48 89 e9             	mov    %rbp,%rcx
    8b57:	48 29 c1             	sub    %rax,%rcx
    8b5a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    8b5e:	49 f7 e2             	mul    %r10
    8b61:	b8 30 00 00 00       	mov    $0x30,%eax
    8b66:	48 89 d6             	mov    %rdx,%rsi
    8b69:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    8b6d:	48 d1 ee             	shr    $1,%rsi
    8b70:	48 01 f2             	add    %rsi,%rdx
    8b73:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8b77:	48 29 d6             	sub    %rdx,%rsi
    8b7a:	74 8e                	je     8b0a <fwp_write+0x53a>
    8b7c:	48 83 fe 01          	cmp    $0x1,%rsi
    8b80:	0f 85 7a ff ff ff    	jne    8b00 <fwp_write+0x530>
    8b86:	31 f6                	xor    %esi,%esi
    8b88:	b8 2b 00 00 00       	mov    $0x2b,%eax
    8b8d:	e9 78 ff ff ff       	jmp    8b0a <fwp_write+0x53a>
    8b92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8b98:	66 0f 6e cd          	movd   %ebp,%xmm1
    8b9c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    8b9f:	0f 8a c8 09 00 00    	jp     956d <fwp_write+0xf9d>
    8ba5:	0f 28 c1             	movaps %xmm1,%xmm0
    8ba8:	0f 54 05 41 42 00 00 	andps  0x4241(%rip),%xmm0        # cdf0 <msg.4+0xb0>
    8baf:	0f 2e 05 4e 34 00 00 	ucomiss 0x344e(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    8bb6:	0f 87 24 08 00 00    	ja     93e0 <fwp_write+0xe10>
    8bbc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8bc0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8bc6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8bcd:	00 
    8bce:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8bd2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8bd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8bde:	00 00 
    8be0:	44 89 ee             	mov    %r13d,%esi
    8be3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8be8:	4c 89 e7             	mov    %r12,%rdi
    8beb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8bf0:	e8 7b bb ff ff       	call   4770 <fwp_format_g.constprop.0>
    8bf5:	31 f6                	xor    %esi,%esi
    8bf7:	4c 89 e7             	mov    %r12,%rdi
    8bfa:	e8 a1 a8 ff ff       	call   34a0 <strtof@plt>
    8bff:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8c04:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8c07:	7a 02                	jp     8c0b <fwp_write+0x63b>
    8c09:	74 1c                	je     8c27 <fwp_write+0x657>
    8c0b:	41 83 c5 01          	add    $0x1,%r13d
    8c0f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8c13:	75 cb                	jne    8be0 <fwp_write+0x610>
    8c15:	be 09 00 00 00       	mov    $0x9,%esi
    8c1a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8c1f:	4c 89 e7             	mov    %r12,%rdi
    8c22:	e8 49 bb ff ff       	call   4770 <fwp_format_g.constprop.0>
    8c27:	4c 89 e7             	mov    %r12,%rdi
    8c2a:	e8 81 b5 ff ff       	call   41b0 <fwp_finish_float>
    8c2f:	e9 1c fa ff ff       	jmp    8650 <fwp_write+0x80>
    8c34:	0f 1f 40 00          	nopl   0x0(%rax)
    8c38:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8c3c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8c40:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8c47:	00 
    8c48:	48 89 ef             	mov    %rbp,%rdi
    8c4b:	e8 f0 ad ff ff       	call   3a40 <fwp_fmt_u128>
    8c50:	48 89 ef             	mov    %rbp,%rdi
    8c53:	e8 e8 a7 ff ff       	call   3440 <strlen@plt>
    8c58:	48 89 ee             	mov    %rbp,%rsi
    8c5b:	48 89 df             	mov    %rbx,%rdi
    8c5e:	48 89 c2             	mov    %rax,%rdx
    8c61:	e8 8a b4 ff ff       	call   40f0 <buf_put>
    8c66:	e9 fb f9 ff ff       	jmp    8666 <fwp_write+0x96>
    8c6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8c70:	ba 06 00 00 00       	mov    $0x6,%edx
    8c75:	48 8d 35 dc 35 00 00 	lea    0x35dc(%rip),%rsi        # c258 <_IO_stdin_used+0x258>
    8c7c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8c82:	e8 69 b4 ff ff       	call   40f0 <buf_put>
    8c87:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8c8e:	ff ff 7f 
    8c91:	48 23 55 00          	and    0x0(%rbp),%rdx
    8c95:	0f 84 86 02 00 00    	je     8f21 <fwp_write+0x951>
    8c9b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8ca0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8ca4:	48 85 d2             	test   %rdx,%rdx
    8ca7:	0f 84 ae 00 00 00    	je     8d5b <fwp_write+0x78b>
    8cad:	8b 0a                	mov    (%rdx),%ecx
    8caf:	83 f9 1c             	cmp    $0x1c,%ecx
    8cb2:	0f 84 58 06 00 00    	je     9310 <fwp_write+0xd40>
    8cb8:	83 f9 1b             	cmp    $0x1b,%ecx
    8cbb:	0f 87 9a 00 00 00    	ja     8d5b <fwp_write+0x78b>
    8cc1:	be 01 00 00 00       	mov    $0x1,%esi
    8cc6:	48 d3 e6             	shl    %cl,%rsi
    8cc9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8ccf:	0f 85 4b 04 00 00    	jne    9120 <fwp_write+0xb50>
    8cd5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8cdb:	0f 85 0f 04 00 00    	jne    90f0 <fwp_write+0xb20>
    8ce1:	83 e6 21             	and    $0x21,%esi
    8ce4:	74 75                	je     8d5b <fwp_write+0x78b>
    8ce6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8ceb:	48 85 ff             	test   %rdi,%rdi
    8cee:	79 07                	jns    8cf7 <fwp_write+0x727>
    8cf0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8cf4:	4c 01 ee             	add    %r13,%rsi
    8cf7:	48 0f be 3e          	movsbq (%rsi),%rdi
    8cfb:	85 c9                	test   %ecx,%ecx
    8cfd:	40 0f b6 f7          	movzbl %dil,%esi
    8d01:	48 0f 44 f7          	cmove  %rdi,%rsi
    8d05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d0c:	00 00 00 00 
    8d10:	31 c9                	xor    %ecx,%ecx
    8d12:	48 89 df             	mov    %rbx,%rdi
    8d15:	49 83 c5 01          	add    $0x1,%r13
    8d19:	e8 b2 f8 ff ff       	call   85d0 <fwp_write>
    8d1e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8d25:	ff ff 7f 
    8d28:	48 23 55 00          	and    0x0(%rbp),%rdx
    8d2c:	49 39 d5             	cmp    %rdx,%r13
    8d2f:	0f 83 ec 01 00 00    	jae    8f21 <fwp_write+0x951>
    8d35:	ba 02 00 00 00       	mov    $0x2,%edx
    8d3a:	48 89 df             	mov    %rbx,%rdi
    8d3d:	48 8d 35 11 35 00 00 	lea    0x3511(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    8d44:	e8 a7 b3 ff ff       	call   40f0 <buf_put>
    8d49:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8d4e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8d52:	48 85 d2             	test   %rdx,%rdx
    8d55:	0f 85 52 ff ff ff    	jne    8cad <fwp_write+0x6dd>
    8d5b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8d60:	48 85 ff             	test   %rdi,%rdi
    8d63:	0f 88 cf 05 00 00    	js     9338 <fwp_write+0xd68>
    8d69:	48 8b 31             	mov    (%rcx),%rsi
    8d6c:	eb a2                	jmp    8d10 <fwp_write+0x740>
    8d6e:	66 90                	xchg   %ax,%ax
    8d70:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8d77:	00 
    8d78:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8d7f:	00 00 
    8d81:	0f 85 1e fd ff ff    	jne    8aa5 <fwp_write+0x4d5>
    8d87:	ba 08 00 00 00       	mov    $0x8,%edx
    8d8c:	48 8d 35 92 34 00 00 	lea    0x3492(%rip),%rsi        # c225 <_IO_stdin_used+0x225>
    8d93:	e9 4b fa ff ff       	jmp    87e3 <fwp_write+0x213>
    8d98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8d9f:	00 
    8da0:	89 e8                	mov    %ebp,%eax
    8da2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8da9:	76 03                	jbe    8dae <fwp_write+0x7de>
    8dab:	8b 45 00             	mov    0x0(%rbp),%eax
    8dae:	41 89 c6             	mov    %eax,%r14d
    8db1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8db6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8dbb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8dbf:	4c 89 ef             	mov    %r13,%rdi
    8dc2:	e8 79 a6 ff ff       	call   3440 <strlen@plt>
    8dc7:	4c 89 ee             	mov    %r13,%rsi
    8dca:	48 89 df             	mov    %rbx,%rdi
    8dcd:	48 89 c2             	mov    %rax,%rdx
    8dd0:	e8 1b b3 ff ff       	call   40f0 <buf_put>
    8dd5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8dda:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8dde:	85 f6                	test   %esi,%esi
    8de0:	0f 8e 80 f8 ff ff    	jle    8666 <fwp_write+0x96>
    8de6:	45 31 ed             	xor    %r13d,%r13d
    8de9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8dee:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8df3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8df8:	ba 01 00 00 00       	mov    $0x1,%edx
    8dfd:	4c 89 fe             	mov    %r15,%rsi
    8e00:	48 89 04 24          	mov    %rax,(%rsp)
    8e04:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8e09:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8e0d:	48 89 df             	mov    %rbx,%rdi
    8e10:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8e14:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8e19:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8e1e:	e8 cd b2 ff ff       	call   40f0 <buf_put>
    8e23:	41 8b 06             	mov    (%r14),%eax
    8e26:	83 f8 0e             	cmp    $0xe,%eax
    8e29:	0f 84 71 02 00 00    	je     90a0 <fwp_write+0xad0>
    8e2f:	83 f8 10             	cmp    $0x10,%eax
    8e32:	0f 84 38 02 00 00    	je     9070 <fwp_write+0xaa0>
    8e38:	83 f8 0a             	cmp    $0xa,%eax
    8e3b:	0f 84 7f 04 00 00    	je     92c0 <fwp_write+0xcf0>
    8e41:	0f 8f f9 00 00 00    	jg     8f40 <fwp_write+0x970>
    8e47:	83 f8 03             	cmp    $0x3,%eax
    8e4a:	0f 8f 50 04 00 00    	jg     92a0 <fwp_write+0xcd0>
    8e50:	85 c0                	test   %eax,%eax
    8e52:	78 10                	js     8e64 <fwp_write+0x894>
    8e54:	48 8b 04 24          	mov    (%rsp),%rax
    8e58:	48 c1 e8 3f          	shr    $0x3f,%rax
    8e5c:	85 c0                	test   %eax,%eax
    8e5e:	0f 85 f9 00 00 00    	jne    8f5d <fwp_write+0x98d>
    8e64:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8e69:	48 8b 34 24          	mov    (%rsp),%rsi
    8e6d:	31 c9                	xor    %ecx,%ecx
    8e6f:	48 89 df             	mov    %rbx,%rdi
    8e72:	e8 59 f7 ff ff       	call   85d0 <fwp_write>
    8e77:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8e7c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8e81:	49 83 c5 01          	add    $0x1,%r13
    8e85:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8e89:	0f 8f 5f ff ff ff    	jg     8dee <fwp_write+0x81e>
    8e8f:	e9 d2 f7 ff ff       	jmp    8666 <fwp_write+0x96>
    8e94:	0f 1f 40 00          	nopl   0x0(%rax)
    8e98:	ba 06 00 00 00       	mov    $0x6,%edx
    8e9d:	48 8d 35 a7 33 00 00 	lea    0x33a7(%rip),%rsi        # c24b <_IO_stdin_used+0x24b>
    8ea4:	45 31 ed             	xor    %r13d,%r13d
    8ea7:	e8 44 b2 ff ff       	call   40f0 <buf_put>
    8eac:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8eb1:	75 19                	jne    8ecc <fwp_write+0x8fc>
    8eb3:	eb 6c                	jmp    8f21 <fwp_write+0x951>
    8eb5:	0f 1f 00             	nopl   (%rax)
    8eb8:	ba 02 00 00 00       	mov    $0x2,%edx
    8ebd:	48 8d 35 91 33 00 00 	lea    0x3391(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    8ec4:	48 89 df             	mov    %rbx,%rdi
    8ec7:	e8 24 b2 ff ff       	call   40f0 <buf_put>
    8ecc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8ed2:	b9 00 02 00 00       	mov    $0x200,%ecx
    8ed7:	31 c0                	xor    %eax,%eax
    8ed9:	49 83 c5 01          	add    $0x1,%r13
    8edd:	4c 8d 05 6e 33 00 00 	lea    0x336e(%rip),%r8        # c252 <_IO_stdin_used+0x252>
    8ee4:	ba 02 00 00 00       	mov    $0x2,%edx
    8ee9:	be 00 02 00 00       	mov    $0x200,%esi
    8eee:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8ef5:	00 
    8ef6:	e8 a5 a4 ff ff       	call   33a0 <__snprintf_chk@plt>
    8efb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8f02:	00 
    8f03:	e8 38 a5 ff ff       	call   3440 <strlen@plt>
    8f08:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8f0f:	00 
    8f10:	48 89 df             	mov    %rbx,%rdi
    8f13:	48 89 c2             	mov    %rax,%rdx
    8f16:	e8 d5 b1 ff ff       	call   40f0 <buf_put>
    8f1b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8f1f:	72 97                	jb     8eb8 <fwp_write+0x8e8>
    8f21:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8f26:	ba 01 00 00 00       	mov    $0x1,%edx
    8f2b:	48 89 df             	mov    %rbx,%rdi
    8f2e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8f33:	e8 b8 b1 ff ff       	call   40f0 <buf_put>
    8f38:	e9 29 f7 ff ff       	jmp    8666 <fwp_write+0x96>
    8f3d:	0f 1f 00             	nopl   (%rax)
    8f40:	83 f8 0b             	cmp    $0xb,%eax
    8f43:	0f 85 1b ff ff ff    	jne    8e64 <fwp_write+0x894>
    8f49:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8f4e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8f52:	83 e0 01             	and    $0x1,%eax
    8f55:	85 c0                	test   %eax,%eax
    8f57:	0f 84 07 ff ff ff    	je     8e64 <fwp_write+0x894>
    8f5d:	4c 89 fe             	mov    %r15,%rsi
    8f60:	48 89 df             	mov    %rbx,%rdi
    8f63:	ba 01 00 00 00       	mov    $0x1,%edx
    8f68:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8f6d:	e8 7e b1 ff ff       	call   40f0 <buf_put>
    8f72:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8f77:	48 8b 34 24          	mov    (%rsp),%rsi
    8f7b:	31 c9                	xor    %ecx,%ecx
    8f7d:	48 89 df             	mov    %rbx,%rdi
    8f80:	e8 4b f6 ff ff       	call   85d0 <fwp_write>
    8f85:	ba 01 00 00 00       	mov    $0x1,%edx
    8f8a:	4c 89 fe             	mov    %r15,%rsi
    8f8d:	48 89 df             	mov    %rbx,%rdi
    8f90:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8f95:	e8 56 b1 ff ff       	call   40f0 <buf_put>
    8f9a:	e9 d8 fe ff ff       	jmp    8e77 <fwp_write+0x8a7>
    8f9f:	90                   	nop
    8fa0:	ba 01 00 00 00       	mov    $0x1,%edx
    8fa5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8faa:	48 89 df             	mov    %rbx,%rdi
    8fad:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8fb2:	e8 39 b1 ff ff       	call   40f0 <buf_put>
    8fb7:	e9 aa f6 ff ff       	jmp    8666 <fwp_write+0x96>
    8fbc:	0f 1f 40 00          	nopl   0x0(%rax)
    8fc0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8fc5:	ba 01 00 00 00       	mov    $0x1,%edx
    8fca:	48 89 df             	mov    %rbx,%rdi
    8fcd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8fd2:	e8 19 b1 ff ff       	call   40f0 <buf_put>
    8fd7:	e9 8a f6 ff ff       	jmp    8666 <fwp_write+0x96>
    8fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    8fe0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8fe4:	48 8b 13             	mov    (%rbx),%rdx
    8fe7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    8fec:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8ff0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8ff4:	e9 6d f6 ff ff       	jmp    8666 <fwp_write+0x96>
    8ff9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9000:	ba 02 00 00 00       	mov    $0x2,%edx
    9005:	48 8d 35 49 32 00 00 	lea    0x3249(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    900c:	48 89 df             	mov    %rbx,%rdi
    900f:	e8 dc b0 ff ff       	call   40f0 <buf_put>
    9014:	e9 72 f8 ff ff       	jmp    888b <fwp_write+0x2bb>
    9019:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9020:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9025:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    902a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    902e:	48 89 f7             	mov    %rsi,%rdi
    9031:	48 89 34 24          	mov    %rsi,(%rsp)
    9035:	e8 06 a4 ff ff       	call   3440 <strlen@plt>
    903a:	48 8b 34 24          	mov    (%rsp),%rsi
    903e:	48 89 df             	mov    %rbx,%rdi
    9041:	48 89 c2             	mov    %rax,%rdx
    9044:	e8 a7 b0 ff ff       	call   40f0 <buf_put>
    9049:	ba 03 00 00 00       	mov    $0x3,%edx
    904e:	48 8d 35 23 32 00 00 	lea    0x3223(%rip),%rsi        # c278 <_IO_stdin_used+0x278>
    9055:	48 89 df             	mov    %rbx,%rdi
    9058:	e8 93 b0 ff ff       	call   40f0 <buf_put>
    905d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9062:	e9 35 f8 ff ff       	jmp    889c <fwp_write+0x2cc>
    9067:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    906e:	00 00 
    9070:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9075:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9079:	48 85 ff             	test   %rdi,%rdi
    907c:	0f 84 e2 fd ff ff    	je     8e64 <fwp_write+0x894>
    9082:	48 8d 35 d9 31 00 00 	lea    0x31d9(%rip),%rsi        # c262 <_IO_stdin_used+0x262>
    9089:	e8 92 a4 ff ff       	call   3520 <strcmp@plt>
    908e:	85 c0                	test   %eax,%eax
    9090:	0f 95 c0             	setne  %al
    9093:	0f b6 c0             	movzbl %al,%eax
    9096:	e9 c1 fd ff ff       	jmp    8e5c <fwp_write+0x88c>
    909b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    90a0:	31 c0                	xor    %eax,%eax
    90a2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    90a9:	00 
    90aa:	0f 97 c0             	seta   %al
    90ad:	e9 aa fd ff ff       	jmp    8e5c <fwp_write+0x88c>
    90b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    90b8:	48 89 df             	mov    %rbx,%rdi
    90bb:	ba 02 00 00 00       	mov    $0x2,%edx
    90c0:	48 8d 35 98 31 00 00 	lea    0x3198(%rip),%rsi        # c25f <_IO_stdin_used+0x25f>
    90c7:	e8 24 b0 ff ff       	call   40f0 <buf_put>
    90cc:	4c 89 e8             	mov    %r13,%rax
    90cf:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    90d4:	31 c9                	xor    %ecx,%ecx
    90d6:	48 c1 e0 04          	shl    $0x4,%rax
    90da:	48 89 df             	mov    %rbx,%rdi
    90dd:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    90e2:	e8 e9 f4 ff ff       	call   85d0 <fwp_write>
    90e7:	e9 5e f6 ff ff       	jmp    874a <fwp_write+0x17a>
    90ec:	0f 1f 40 00          	nopl   0x0(%rax)
    90f0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    90f5:	48 85 ff             	test   %rdi,%rdi
    90f8:	79 0c                	jns    9106 <fwp_write+0xb36>
    90fa:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    9101:	00 
    9102:	48 03 75 10          	add    0x10(%rbp),%rsi
    9106:	48 63 3e             	movslq (%rsi),%rdi
    9109:	83 f9 02             	cmp    $0x2,%ecx
    910c:	89 fe                	mov    %edi,%esi
    910e:	48 0f 44 f7          	cmove  %rdi,%rsi
    9112:	e9 f9 fb ff ff       	jmp    8d10 <fwp_write+0x740>
    9117:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    911e:	00 00 
    9120:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    9125:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    912a:	48 85 ff             	test   %rdi,%rdi
    912d:	0f 88 0f 03 00 00    	js     9442 <fwp_write+0xe72>
    9133:	49 0f bf 38          	movswq (%r8),%rdi
    9137:	83 f9 01             	cmp    $0x1,%ecx
    913a:	0f b7 f7             	movzwl %di,%esi
    913d:	48 0f 44 f7          	cmove  %rdi,%rsi
    9141:	e9 ca fb ff ff       	jmp    8d10 <fwp_write+0x740>
    9146:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    914d:	00 00 00 
    9150:	ba 01 00 00 00       	mov    $0x1,%edx
    9155:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    915a:	48 83 c5 08          	add    $0x8,%rbp
    915e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9163:	e8 88 af ff ff       	call   40f0 <buf_put>
    9168:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    916d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    9172:	4d 85 ed             	test   %r13,%r13
    9175:	75 46                	jne    91bd <fwp_write+0xbed>
    9177:	e9 04 01 00 00       	jmp    9280 <fwp_write+0xcb0>
    917c:	0f 1f 40 00          	nopl   0x0(%rax)
    9180:	41 80 f9 09          	cmp    $0x9,%r9b
    9184:	0f 84 d6 00 00 00    	je     9260 <fwp_write+0xc90>
    918a:	41 80 f9 0a          	cmp    $0xa,%r9b
    918e:	0f 85 9c 00 00 00    	jne    9230 <fwp_write+0xc60>
    9194:	ba 02 00 00 00       	mov    $0x2,%edx
    9199:	48 8d 35 9b 30 00 00 	lea    0x309b(%rip),%rsi        # c23b <_IO_stdin_used+0x23b>
    91a0:	48 89 df             	mov    %rbx,%rdi
    91a3:	e8 48 af ff ff       	call   40f0 <buf_put>
    91a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    91af:	00 
    91b0:	48 83 c5 01          	add    $0x1,%rbp
    91b4:	49 39 ec             	cmp    %rbp,%r12
    91b7:	0f 84 c3 00 00 00    	je     9280 <fwp_write+0xcb0>
    91bd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    91c2:	41 80 f9 0d          	cmp    $0xd,%r9b
    91c6:	74 28                	je     91f0 <fwp_write+0xc20>
    91c8:	7e b6                	jle    9180 <fwp_write+0xbb0>
    91ca:	41 80 f9 22          	cmp    $0x22,%r9b
    91ce:	74 40                	je     9210 <fwp_write+0xc40>
    91d0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    91d4:	75 5a                	jne    9230 <fwp_write+0xc60>
    91d6:	ba 02 00 00 00       	mov    $0x2,%edx
    91db:	48 8d 35 56 30 00 00 	lea    0x3056(%rip),%rsi        # c238 <_IO_stdin_used+0x238>
    91e2:	48 89 df             	mov    %rbx,%rdi
    91e5:	e8 06 af ff ff       	call   40f0 <buf_put>
    91ea:	eb c4                	jmp    91b0 <fwp_write+0xbe0>
    91ec:	0f 1f 40 00          	nopl   0x0(%rax)
    91f0:	ba 02 00 00 00       	mov    $0x2,%edx
    91f5:	48 8d 35 45 30 00 00 	lea    0x3045(%rip),%rsi        # c241 <_IO_stdin_used+0x241>
    91fc:	48 89 df             	mov    %rbx,%rdi
    91ff:	e8 ec ae ff ff       	call   40f0 <buf_put>
    9204:	eb aa                	jmp    91b0 <fwp_write+0xbe0>
    9206:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    920d:	00 00 00 
    9210:	ba 02 00 00 00       	mov    $0x2,%edx
    9215:	48 8d 35 19 30 00 00 	lea    0x3019(%rip),%rsi        # c235 <_IO_stdin_used+0x235>
    921c:	48 89 df             	mov    %rbx,%rdi
    921f:	e8 cc ae ff ff       	call   40f0 <buf_put>
    9224:	eb 8a                	jmp    91b0 <fwp_write+0xbe0>
    9226:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    922d:	00 00 00 
    9230:	41 80 f9 1f          	cmp    $0x1f,%r9b
    9234:	0f 86 2e 01 00 00    	jbe    9368 <fwp_write+0xd98>
    923a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    923e:	0f 84 24 01 00 00    	je     9368 <fwp_write+0xd98>
    9244:	ba 01 00 00 00       	mov    $0x1,%edx
    9249:	4c 89 fe             	mov    %r15,%rsi
    924c:	48 89 df             	mov    %rbx,%rdi
    924f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    9254:	e8 97 ae ff ff       	call   40f0 <buf_put>
    9259:	e9 52 ff ff ff       	jmp    91b0 <fwp_write+0xbe0>
    925e:	66 90                	xchg   %ax,%ax
    9260:	ba 02 00 00 00       	mov    $0x2,%edx
    9265:	48 8d 35 d2 2f 00 00 	lea    0x2fd2(%rip),%rsi        # c23e <_IO_stdin_used+0x23e>
    926c:	48 89 df             	mov    %rbx,%rdi
    926f:	e8 7c ae ff ff       	call   40f0 <buf_put>
    9274:	e9 37 ff ff ff       	jmp    91b0 <fwp_write+0xbe0>
    9279:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9280:	ba 01 00 00 00       	mov    $0x1,%edx
    9285:	4c 89 fe             	mov    %r15,%rsi
    9288:	48 89 df             	mov    %rbx,%rdi
    928b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9290:	e8 5b ae ff ff       	call   40f0 <buf_put>
    9295:	e9 cc f3 ff ff       	jmp    8666 <fwp_write+0x96>
    929a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    92a0:	83 f8 04             	cmp    $0x4,%eax
    92a3:	0f 85 bb fb ff ff    	jne    8e64 <fwp_write+0x894>
    92a9:	48 8b 04 24          	mov    (%rsp),%rax
    92ad:	48 8b 40 08          	mov    0x8(%rax),%rax
    92b1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    92b6:	48 c1 e8 3f          	shr    $0x3f,%rax
    92ba:	e9 96 fc ff ff       	jmp    8f55 <fwp_write+0x985>
    92bf:	90                   	nop
    92c0:	8b 0c 24             	mov    (%rsp),%ecx
    92c3:	31 c0                	xor    %eax,%eax
    92c5:	85 c9                	test   %ecx,%ecx
    92c7:	0f 98 c0             	sets   %al
    92ca:	e9 86 fc ff ff       	jmp    8f55 <fwp_write+0x985>
    92cf:	90                   	nop
    92d0:	48 f7 d8             	neg    %rax
    92d3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    92da:	00 
    92db:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    92e2:	2d 
    92e3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    92ea:	00 
    92eb:	48 83 d2 00          	adc    $0x0,%rdx
    92ef:	48 89 c6             	mov    %rax,%rsi
    92f2:	48 f7 da             	neg    %rdx
    92f5:	e8 46 a7 ff ff       	call   3a40 <fwp_fmt_u128>
    92fa:	e9 51 f3 ff ff       	jmp    8650 <fwp_write+0x80>
    92ff:	90                   	nop
    9300:	b8 7d 00 00 00       	mov    $0x7d,%eax
    9305:	e9 c3 f5 ff ff       	jmp    88cd <fwp_write+0x2fd>
    930a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9310:	4c 89 e9             	mov    %r13,%rcx
    9313:	48 c1 e1 04          	shl    $0x4,%rcx
    9317:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    931c:	48 85 ff             	test   %rdi,%rdi
    931f:	0f 89 eb f9 ff ff    	jns    8d10 <fwp_write+0x740>
    9325:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9329:	48 89 ce             	mov    %rcx,%rsi
    932c:	e9 df f9 ff ff       	jmp    8d10 <fwp_write+0x740>
    9331:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9338:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    933f:	00 
    9340:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9344:	e9 20 fa ff ff       	jmp    8d69 <fwp_write+0x799>
    9349:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9350:	ba 02 00 00 00       	mov    $0x2,%edx
    9355:	48 8d 35 a4 2e 00 00 	lea    0x2ea4(%rip),%rsi        # c200 <_IO_stdin_used+0x200>
    935c:	e9 2d f7 ff ff       	jmp    8a8e <fwp_write+0x4be>
    9361:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9368:	4c 8d 05 d5 2e 00 00 	lea    0x2ed5(%rip),%r8        # c244 <_IO_stdin_used+0x244>
    936f:	b9 10 00 00 00       	mov    $0x10,%ecx
    9374:	31 c0                	xor    %eax,%eax
    9376:	ba 02 00 00 00       	mov    $0x2,%edx
    937b:	be 10 00 00 00       	mov    $0x10,%esi
    9380:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9387:	00 
    9388:	e8 13 a0 ff ff       	call   33a0 <__snprintf_chk@plt>
    938d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9394:	00 
    9395:	e8 a6 a0 ff ff       	call   3440 <strlen@plt>
    939a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    93a1:	00 
    93a2:	48 89 df             	mov    %rbx,%rdi
    93a5:	48 89 c2             	mov    %rax,%rdx
    93a8:	e8 43 ad ff ff       	call   40f0 <buf_put>
    93ad:	e9 fe fd ff ff       	jmp    91b0 <fwp_write+0xbe0>
    93b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    93b8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    93bc:	48 8d 35 37 2e 00 00 	lea    0x2e37(%rip),%rsi        # c1fa <_IO_stdin_used+0x1fa>
    93c3:	48 8d 05 2f 2e 00 00 	lea    0x2e2f(%rip),%rax        # c1f9 <_IO_stdin_used+0x1f9>
    93ca:	4c 89 e7             	mov    %r12,%rdi
    93cd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    93d1:	48 0f 46 f0          	cmovbe %rax,%rsi
    93d5:	e8 06 a0 ff ff       	call   33e0 <strcpy@plt>
    93da:	e9 71 f2 ff ff       	jmp    8650 <fwp_write+0x80>
    93df:	90                   	nop
    93e0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    93e4:	48 8d 35 0f 2e 00 00 	lea    0x2e0f(%rip),%rsi        # c1fa <_IO_stdin_used+0x1fa>
    93eb:	48 8d 05 07 2e 00 00 	lea    0x2e07(%rip),%rax        # c1f9 <_IO_stdin_used+0x1f9>
    93f2:	0f 2f c8             	comiss %xmm0,%xmm1
    93f5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    93fc:	00 
    93fd:	4c 89 e7             	mov    %r12,%rdi
    9400:	48 0f 46 f0          	cmovbe %rax,%rsi
    9404:	e8 d7 9f ff ff       	call   33e0 <strcpy@plt>
    9409:	e9 42 f2 ff ff       	jmp    8650 <fwp_write+0x80>
    940e:	66 90                	xchg   %ax,%ax
    9410:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9415:	45 85 c0             	test   %r8d,%r8d
    9418:	75 34                	jne    944e <fwp_write+0xe7e>
    941a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9421:	00 
    9422:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9429:	00 00 
    942b:	0f 85 74 f6 ff ff    	jne    8aa5 <fwp_write+0x4d5>
    9431:	ba 02 00 00 00       	mov    $0x2,%edx
    9436:	48 8d 35 38 2e 00 00 	lea    0x2e38(%rip),%rsi        # c275 <_IO_stdin_used+0x275>
    943d:	e9 a1 f3 ff ff       	jmp    87e3 <fwp_write+0x213>
    9442:	48 03 75 10          	add    0x10(%rbp),%rsi
    9446:	49 89 f0             	mov    %rsi,%r8
    9449:	e9 e5 fc ff ff       	jmp    9133 <fwp_write+0xb63>
    944e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9453:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9458:	85 ff                	test   %edi,%edi
    945a:	0f 84 fa f3 ff ff    	je     885a <fwp_write+0x28a>
    9460:	ba 01 00 00 00       	mov    $0x1,%edx
    9465:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    946a:	48 89 df             	mov    %rbx,%rdi
    946d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9472:	e8 79 ac ff ff       	call   40f0 <buf_put>
    9477:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    947c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9481:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9487:	85 c0                	test   %eax,%eax
    9489:	0f 8f f0 f3 ff ff    	jg     887f <fwp_write+0x2af>
    948f:	e9 34 f4 ff ff       	jmp    88c8 <fwp_write+0x2f8>
    9494:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9498:	49 89 c5             	mov    %rax,%r13
    949b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    94a0:	49 89 c4             	mov    %rax,%r12
    94a3:	49 c1 fd 3f          	sar    $0x3f,%r13
    94a7:	4c 09 e8             	or     %r13,%rax
    94aa:	0f 84 a7 00 00 00    	je     9557 <fwp_write+0xf87>
    94b0:	48 8d 2d 09 4e 00 00 	lea    0x4e09(%rip),%rbp        # e2c0 <units.0>
    94b7:	4d 89 e7             	mov    %r12,%r15
    94ba:	48 8b 45 08          	mov    0x8(%rbp),%rax
    94be:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    94c3:	4c 89 ff             	mov    %r15,%rdi
    94c6:	4c 89 ee             	mov    %r13,%rsi
    94c9:	44 89 0c 24          	mov    %r9d,(%rsp)
    94cd:	48 99                	cqto
    94cf:	48 89 d1             	mov    %rdx,%rcx
    94d2:	48 89 c2             	mov    %rax,%rdx
    94d5:	e8 c6 25 00 00       	call   baa0 <__divmodti4>
    94da:	44 8b 0c 24          	mov    (%rsp),%r9d
    94de:	48 89 c1             	mov    %rax,%rcx
    94e1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    94e6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    94eb:	0f 84 94 00 00 00    	je     9585 <fwp_write+0xfb5>
    94f1:	41 83 c1 01          	add    $0x1,%r9d
    94f5:	48 83 c5 10          	add    $0x10,%rbp
    94f9:	41 83 f9 05          	cmp    $0x5,%r9d
    94fd:	75 bb                	jne    94ba <fwp_write+0xeea>
    94ff:	4d 85 ed             	test   %r13,%r13
    9502:	79 53                	jns    9557 <fwp_write+0xf87>
    9504:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9509:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    950e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9513:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9518:	48 99                	cqto
    951a:	48 f7 d8             	neg    %rax
    951d:	48 83 d2 00          	adc    $0x0,%rdx
    9521:	48 89 c6             	mov    %rax,%rsi
    9524:	48 f7 da             	neg    %rdx
    9527:	e8 14 a5 ff ff       	call   3a40 <fwp_fmt_u128>
    952c:	49 89 e8             	mov    %rbp,%r8
    952f:	ba 00 02 00 00       	mov    $0x200,%edx
    9534:	be 02 00 00 00       	mov    $0x2,%esi
    9539:	31 c0                	xor    %eax,%eax
    953b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9542:	00 
    9543:	48 8d 0d 26 2d 00 00 	lea    0x2d26(%rip),%rcx        # c270 <_IO_stdin_used+0x270>
    954a:	4c 89 e7             	mov    %r12,%rdi
    954d:	e8 6e a1 ff ff       	call   36c0 <__sprintf_chk@plt>
    9552:	e9 f9 f0 ff ff       	jmp    8650 <fwp_write+0x80>
    9557:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    955c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9561:	31 d2                	xor    %edx,%edx
    9563:	48 89 ef             	mov    %rbp,%rdi
    9566:	e8 d5 a4 ff ff       	call   3a40 <fwp_fmt_u128>
    956b:	eb bf                	jmp    952c <fwp_write+0xf5c>
    956d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9574:	4e 61 4e 00 
    9578:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    957f:	00 
    9580:	e9 cb f0 ff ff       	jmp    8650 <fwp_write+0x80>
    9585:	44 89 0c 24          	mov    %r9d,(%rsp)
    9589:	48 89 c8             	mov    %rcx,%rax
    958c:	48 85 d2             	test   %rdx,%rdx
    958f:	78 51                	js     95e2 <fwp_write+0x1012>
    9591:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9596:	48 89 c6             	mov    %rax,%rsi
    9599:	48 89 ef             	mov    %rbp,%rdi
    959c:	e8 9f a4 ff ff       	call   3a40 <fwp_fmt_u128>
    95a1:	44 8b 0c 24          	mov    (%rsp),%r9d
    95a5:	49 63 c1             	movslq %r9d,%rax
    95a8:	49 89 e8             	mov    %rbp,%r8
    95ab:	ba 00 02 00 00       	mov    $0x200,%edx
    95b0:	be 02 00 00 00       	mov    $0x2,%esi
    95b5:	48 c1 e0 04          	shl    $0x4,%rax
    95b9:	48 8d 3d 00 4d 00 00 	lea    0x4d00(%rip),%rdi        # e2c0 <units.0>
    95c0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    95c7:	00 
    95c8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    95cc:	48 8d 0d 98 2c 00 00 	lea    0x2c98(%rip),%rcx        # c26b <_IO_stdin_used+0x26b>
    95d3:	4c 89 e7             	mov    %r12,%rdi
    95d6:	31 c0                	xor    %eax,%eax
    95d8:	e8 e3 a0 ff ff       	call   36c0 <__sprintf_chk@plt>
    95dd:	e9 6e f0 ff ff       	jmp    8650 <fwp_write+0x80>
    95e2:	48 f7 d8             	neg    %rax
    95e5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    95ea:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    95ef:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    95f4:	48 83 d2 00          	adc    $0x0,%rdx
    95f8:	48 89 c6             	mov    %rax,%rsi
    95fb:	48 f7 da             	neg    %rdx
    95fe:	e8 3d a4 ff ff       	call   3a40 <fwp_fmt_u128>
    9603:	44 8b 0c 24          	mov    (%rsp),%r9d
    9607:	eb 9c                	jmp    95a5 <fwp_write+0xfd5>
    9609:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009610 <fwp_main_thread>:
    9610:	f3 0f 1e fa          	endbr64
    9614:	41 57                	push   %r15
    9616:	41 56                	push   %r14
    9618:	41 55                	push   %r13
    961a:	41 54                	push   %r12
    961c:	55                   	push   %rbp
    961d:	53                   	push   %rbx
    961e:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
    9625:	8b 1d 99 05 06 00    	mov    0x60599(%rip),%ebx        # 69bc4 <fwp_heap+0x13a4>
    962b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9632:	00 00 
    9634:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    963b:	00 
    963c:	31 c0                	xor    %eax,%eax
    963e:	85 db                	test   %ebx,%ebx
    9640:	0f 84 83 13 00 00    	je     a9c9 <fwp_main_thread+0x13b9>
    9646:	44 8b 1d 7b 05 06 00 	mov    0x6057b(%rip),%r11d        # 69bc8 <fwp_heap+0x13a8>
    964d:	45 85 db             	test   %r11d,%r11d
    9650:	0f 85 88 13 00 00    	jne    a9de <fwp_main_thread+0x13ce>
    9656:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
    965d:	00 
    965e:	31 f6                	xor    %esi,%esi
    9660:	48 c7 05 55 eb 05 00 	movq   $0x40000000,0x5eb55(%rip)        # 681c0 <fwp_main_stack_size>
    9667:	00 00 00 40 
    966b:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    9670:	48 89 05 51 eb 05 00 	mov    %rax,0x5eb51(%rip)        # 681c8 <fwp_main_stack_top>
    9677:	48 8d 05 02 6a 00 00 	lea    0x6a02(%rip),%rax        # 10080 <alt.5>
    967e:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
    9685:	00 
    9686:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
    968d:	00 
    968e:	48 89 c7             	mov    %rax,%rdi
    9691:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    9696:	48 c7 84 24 e0 00 00 	movq   $0x10000,0xe0(%rsp)
    969d:	00 00 00 01 00 
    96a2:	c7 84 24 d8 00 00 00 	movl   $0x0,0xd8(%rsp)
    96a9:	00 00 00 00 
    96ad:	e8 ee 9f ff ff       	call   36a0 <sigaltstack@plt>
    96b2:	85 c0                	test   %eax,%eax
    96b4:	0f 85 7e 23 00 00    	jne    ba38 <fwp_main_thread+0x2428>
    96ba:	31 c0                	xor    %eax,%eax
    96bc:	b9 12 00 00 00       	mov    $0x12,%ecx
    96c1:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
    96c8:	00 
    96c9:	f3 48 ab             	rep stos %rax,(%rdi)
    96cc:	48 8d 9c 24 40 01 00 	lea    0x140(%rsp),%rbx
    96d3:	00 
    96d4:	48 8d 05 65 a6 ff ff 	lea    -0x599b(%rip),%rax        # 3d40 <fwp_segv>
    96db:	c7 84 24 c8 01 00 00 	movl   $0x8000004,0x1c8(%rsp)
    96e2:	04 00 00 08 
    96e6:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
    96ed:	00 
    96ee:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    96f3:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
    96fa:	00 
    96fb:	e8 60 9e ff ff       	call   3560 <sigemptyset@plt>
    9700:	85 c0                	test   %eax,%eax
    9702:	0f 85 30 23 00 00    	jne    ba38 <fwp_main_thread+0x2428>
    9708:	31 d2                	xor    %edx,%edx
    970a:	48 89 de             	mov    %rbx,%rsi
    970d:	bf 0b 00 00 00       	mov    $0xb,%edi
    9712:	e8 d9 9c ff ff       	call   33f0 <sigaction@plt>
    9717:	85 c0                	test   %eax,%eax
    9719:	0f 85 19 23 00 00    	jne    ba38 <fwp_main_thread+0x2428>
    971f:	31 d2                	xor    %edx,%edx
    9721:	48 89 de             	mov    %rbx,%rsi
    9724:	bf 07 00 00 00       	mov    $0x7,%edi
    9729:	e8 c2 9c ff ff       	call   33f0 <sigaction@plt>
    972e:	85 c0                	test   %eax,%eax
    9730:	0f 85 02 23 00 00    	jne    ba38 <fwp_main_thread+0x2428>
    9736:	48 8b 05 03 05 06 00 	mov    0x60503(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    973d:	48 85 c0             	test   %rax,%rax
    9740:	0f 88 ba 05 00 00    	js     9d00 <fwp_main_thread+0x6f0>
    9746:	66 0f ef c0          	pxor   %xmm0,%xmm0
    974a:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    974f:	48 8d 3d ca aa ff ff 	lea    -0x5536(%rip),%rdi        # 4220 <ad_raw_report>
    9756:	f2 0f 11 05 6a 0d 06 	movsd  %xmm0,0x60d6a(%rip)        # 6a4c8 <iteration_start_charge>
    975d:	00 
    975e:	c7 05 80 0d 06 00 01 	movl   $0x1,0x60d80(%rip)        # 6a4e8 <iteration_active>
    9765:	00 00 00 
    9768:	e8 43 25 00 00       	call   bcb0 <atexit>
    976d:	85 c0                	test   %eax,%eax
    976f:	0f 85 f7 22 00 00    	jne    ba6c <fwp_main_thread+0x245c>
    9775:	44 8b 15 f4 68 00 00 	mov    0x68f4(%rip),%r10d        # 10070 <st.3>
    977c:	45 85 d2             	test   %r10d,%r10d
    977f:	0f 84 b9 05 00 00    	je     9d3e <fwp_main_thread+0x72e>
    9785:	48 8b 2d 74 f0 05 00 	mov    0x5f074(%rip),%rbp        # 68800 <fwp_cur>
    978c:	48 85 ed             	test   %rbp,%rbp
    978f:	0f 84 cb 01 00 00    	je     9960 <fwp_main_thread+0x350>
    9795:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    979a:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    979e:	48 89 eb             	mov    %rbp,%rbx
    97a1:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    97a6:	0f 84 41 01 00 00    	je     98ed <fwp_main_thread+0x2dd>
    97ac:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    97b1:	0f 84 69 04 00 00    	je     9c20 <fwp_main_thread+0x610>
    97b7:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    97bb:	0f 84 3f 04 00 00    	je     9c00 <fwp_main_thread+0x5f0>
    97c1:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    97c5:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    97c9:	0f 85 d1 04 00 00    	jne    9ca0 <fwp_main_thread+0x690>
    97cf:	48 8b 43 60          	mov    0x60(%rbx),%rax
    97d3:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    97da:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    97de:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    97e5:	00 00 00 00 
    97e9:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    97f0:	48 85 d2             	test   %rdx,%rdx
    97f3:	74 07                	je     97fc <fwp_main_thread+0x1ec>
    97f5:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    97fc:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9800:	48 85 c0             	test   %rax,%rax
    9803:	74 34                	je     9839 <fwp_main_thread+0x229>
    9805:	48 89 43 68          	mov    %rax,0x68(%rbx)
    9809:	48 8b 05 c8 ef 05 00 	mov    0x5efc8(%rip),%rax        # 687d8 <fwp_timers>
    9810:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    9814:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    981b:	00 00 00 00 
    981f:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    9826:	48 85 c0             	test   %rax,%rax
    9829:	74 07                	je     9832 <fwp_main_thread+0x222>
    982b:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9832:	48 89 1d 9f ef 05 00 	mov    %rbx,0x5ef9f(%rip)        # 687d8 <fwp_timers>
    9839:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    983d:	e8 ae dd ff ff       	call   75f0 <fwp_block>
    9842:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    9849:	48 85 c9             	test   %rcx,%rcx
    984c:	74 47                	je     9895 <fwp_main_thread+0x285>
    984e:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    9855:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    985c:	48 85 d2             	test   %rdx,%rdx
    985f:	0f 84 7b 04 00 00    	je     9ce0 <fwp_main_thread+0x6d0>
    9865:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    986c:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9873:	48 85 c0             	test   %rax,%rax
    9876:	74 07                	je     987f <fwp_main_thread+0x26f>
    9878:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    987f:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    9886:	00 00 00 00 
    988a:	66 0f ef ff          	pxor   %xmm7,%xmm7
    988e:	0f 11 bb 18 01 00 00 	movups %xmm7,0x118(%rbx)
    9895:	48 8b 0d 64 ef 05 00 	mov    0x5ef64(%rip),%rcx        # 68800 <fwp_cur>
    989c:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    98a0:	0f 84 ea 03 00 00    	je     9c90 <fwp_main_thread+0x680>
    98a6:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    98ad:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    98b4:	48 85 d2             	test   %rdx,%rdx
    98b7:	0f 84 33 04 00 00    	je     9cf0 <fwp_main_thread+0x6e0>
    98bd:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    98c4:	48 85 c0             	test   %rax,%rax
    98c7:	74 07                	je     98d0 <fwp_main_thread+0x2c0>
    98c9:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    98d0:	66 0f ef ff          	pxor   %xmm7,%xmm7
    98d4:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    98d8:	0f 11 bb 08 01 00 00 	movups %xmm7,0x108(%rbx)
    98df:	48 89 cb             	mov    %rcx,%rbx
    98e2:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    98e7:	0f 85 bf fe ff ff    	jne    97ac <fwp_main_thread+0x19c>
    98ed:	48 83 3d a3 0b 06 00 	cmpq   $0x0,0x60ba3(%rip)        # 6a498 <fwp_state_len>
    98f4:	00 
    98f5:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    98f9:	75 0e                	jne    9909 <fwp_main_thread+0x2f9>
    98fb:	48 83 3d 85 0b 06 00 	cmpq   $0x0,0x60b85(%rip)        # 6a488 <fwp_state_owners>
    9902:	00 
    9903:	0f 84 7b 1f 00 00    	je     b884 <fwp_main_thread+0x2274>
    9909:	48 39 1d e8 ee 05 00 	cmp    %rbx,0x5eee8(%rip)        # 687f8 <fwp_root>
    9910:	c7 05 66 67 01 00 00 	movl   $0x0,0x16766(%rip)        # 20080 <fwp_exit_code>
    9917:	00 00 00 
    991a:	0f 85 7a 21 00 00    	jne    ba9a <fwp_main_thread+0x248a>
    9920:	48 85 db             	test   %rbx,%rbx
    9923:	74 61                	je     9986 <fwp_main_thread+0x376>
    9925:	48 8b 15 9c ee 05 00 	mov    0x5ee9c(%rip),%rdx        # 687c8 <fwp_tasks_active>
    992c:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    9930:	48 85 d2             	test   %rdx,%rdx
    9933:	74 51                	je     9986 <fwp_main_thread+0x376>
    9935:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    993c:	00 00 00 00 
    9940:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9944:	75 08                	jne    994e <fwp_main_thread+0x33e>
    9946:	48 89 d7             	mov    %rdx,%rdi
    9949:	e8 e2 a7 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    994e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    9955:	48 85 d2             	test   %rdx,%rdx
    9958:	75 e6                	jne    9940 <fwp_main_thread+0x330>
    995a:	e9 6e 02 00 00       	jmp    9bcd <fwp_main_thread+0x5bd>
    995f:	90                   	nop
    9960:	48 83 3d 30 0b 06 00 	cmpq   $0x0,0x60b30(%rip)        # 6a498 <fwp_state_len>
    9967:	00 
    9968:	0f 84 89 1d 00 00    	je     b6f7 <fwp_main_thread+0x20e7>
    996e:	48 83 3d 82 ee 05 00 	cmpq   $0x0,0x5ee82(%rip)        # 687f8 <fwp_root>
    9975:	00 
    9976:	c7 05 00 67 01 00 00 	movl   $0x0,0x16700(%rip)        # 20080 <fwp_exit_code>
    997d:	00 00 00 
    9980:	0f 85 0f 21 00 00    	jne    ba95 <fwp_main_thread+0x2485>
    9986:	e8 55 da ff ff       	call   73e0 <fwp_free_zombie>
    998b:	48 83 3d 55 ee 05 00 	cmpq   $0x0,0x5ee55(%rip)        # 687e8 <fwp_ready_head>
    9992:	00 
    9993:	0f 85 b2 9d ff ff    	jne    374b <fwp_main_thread.cold>
    9999:	48 83 3d 37 ee 05 00 	cmpq   $0x0,0x5ee37(%rip)        # 687d8 <fwp_timers>
    99a0:	00 
    99a1:	0f 85 a4 9d ff ff    	jne    374b <fwp_main_thread.cold>
    99a7:	8b 05 27 e8 05 00    	mov    0x5e827(%rip),%eax        # 681d4 <fwp_stack_pool_n>
    99ad:	85 c0                	test   %eax,%eax
    99af:	74 3c                	je     99ed <fwp_main_thread+0x3dd>
    99b1:	83 e8 01             	sub    $0x1,%eax
    99b4:	4c 8d 25 25 e8 05 00 	lea    0x5e825(%rip),%r12        # 681e0 <fwp_stack_pool>
    99bb:	48 63 d8             	movslq %eax,%rbx
    99be:	89 c0                	mov    %eax,%eax
    99c0:	48 89 da             	mov    %rbx,%rdx
    99c3:	48 29 c2             	sub    %rax,%rdx
    99c6:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    99ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    99d0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    99d4:	89 1d fa e7 05 00    	mov    %ebx,0x5e7fa(%rip)        # 681d4 <fwp_stack_pool_n>
    99da:	be 00 00 00 10       	mov    $0x10000000,%esi
    99df:	48 83 eb 01          	sub    $0x1,%rbx
    99e3:	e8 d8 9b ff ff       	call   35c0 <munmap@plt>
    99e8:	48 39 eb             	cmp    %rbp,%rbx
    99eb:	75 e3                	jne    99d0 <fwp_main_thread+0x3c0>
    99ed:	8b 3d 25 66 00 00    	mov    0x6625(%rip),%edi        # 10018 <fwp_epfd>
    99f3:	85 ff                	test   %edi,%edi
    99f5:	78 05                	js     99fc <fwp_main_thread+0x3ec>
    99f7:	e8 c4 9a ff ff       	call   34c0 <close@plt>
    99fc:	4c 8b 25 dd e9 05 00 	mov    0x5e9dd(%rip),%r12        # 683e0 <fwp_nfdws>
    9a03:	48 8b 2d de e9 05 00 	mov    0x5e9de(%rip),%rbp        # 683e8 <fwp_fdws>
    9a0a:	31 db                	xor    %ebx,%ebx
    9a0c:	c7 05 02 66 00 00 ff 	movl   $0xffffffff,0x6602(%rip)        # 10018 <fwp_epfd>
    9a13:	ff ff ff 
    9a16:	4d 85 e4             	test   %r12,%r12
    9a19:	74 32                	je     9a4d <fwp_main_thread+0x43d>
    9a1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9a20:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9a25:	48 85 ff             	test   %rdi,%rdi
    9a28:	74 1a                	je     9a44 <fwp_main_thread+0x434>
    9a2a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    9a2e:	0f 85 17 9d ff ff    	jne    374b <fwp_main_thread.cold>
    9a34:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9a39:	0f 85 0c 9d ff ff    	jne    374b <fwp_main_thread.cold>
    9a3f:	e8 cc bf ff ff       	call   5a10 <fwp_mem_free>
    9a44:	48 83 c3 01          	add    $0x1,%rbx
    9a48:	4c 39 e3             	cmp    %r12,%rbx
    9a4b:	75 d3                	jne    9a20 <fwp_main_thread+0x410>
    9a4d:	48 89 ef             	mov    %rbp,%rdi
    9a50:	e8 bb bf ff ff       	call   5a10 <fwp_mem_free>
    9a55:	48 8b 15 9c ed 05 00 	mov    0x5ed9c(%rip),%rdx        # 687f8 <fwp_root>
    9a5c:	48 c7 05 81 e9 05 00 	movq   $0x0,0x5e981(%rip)        # 683e8 <fwp_fdws>
    9a63:	00 00 00 00 
    9a67:	48 c7 05 6e e9 05 00 	movq   $0x0,0x5e96e(%rip)        # 683e0 <fwp_nfdws>
    9a6e:	00 00 00 00 
    9a72:	48 85 d2             	test   %rdx,%rdx
    9a75:	74 4e                	je     9ac5 <fwp_main_thread+0x4b5>
    9a77:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    9a7c:	0f 85 c9 9c ff ff    	jne    374b <fwp_main_thread.cold>
    9a82:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    9a89:	00 
    9a8a:	0f 85 bb 9c ff ff    	jne    374b <fwp_main_thread.cold>
    9a90:	48 83 3d 00 0a 06 00 	cmpq   $0x0,0x60a00(%rip)        # 6a498 <fwp_state_len>
    9a97:	00 
    9a98:	0f 85 ad 9c ff ff    	jne    374b <fwp_main_thread.cold>
    9a9e:	48 83 3d e2 09 06 00 	cmpq   $0x0,0x609e2(%rip)        # 6a488 <fwp_state_owners>
    9aa5:	00 
    9aa6:	0f 85 9f 9c ff ff    	jne    374b <fwp_main_thread.cold>
    9aac:	b9 79 00 00 00       	mov    $0x79,%ecx
    9ab1:	31 c0                	xor    %eax,%eax
    9ab3:	48 8d 3d 46 e9 05 00 	lea    0x5e946(%rip),%rdi        # 68400 <fwp_root_context>
    9aba:	f3 48 ab             	rep stos %rax,(%rdi)
    9abd:	48 89 d7             	mov    %rdx,%rdi
    9ac0:	e8 4b bf ff ff       	call   5a10 <fwp_mem_free>
    9ac5:	66 0f 6f 05 e3 66 04 	movdqa 0x466e3(%rip),%xmm0        # 501b0 <ad_raw_live+0x10>
    9acc:	00 
    9acd:	66 0f d4 05 cb 66 04 	paddq  0x466cb(%rip),%xmm0        # 501a0 <ad_raw_live>
    9ad4:	00 
    9ad5:	48 c7 05 20 ed 05 00 	movq   $0x0,0x5ed20(%rip)        # 68800 <fwp_cur>
    9adc:	00 00 00 00 
    9ae0:	48 8b 05 59 01 06 00 	mov    0x60159(%rip),%rax        # 69c40 <fwp_heap+0x1420>
    9ae7:	48 c7 05 06 ed 05 00 	movq   $0x0,0x5ed06(%rip)        # 687f8 <fwp_root>
    9aee:	00 00 00 00 
    9af2:	c7 05 ec 09 06 00 00 	movl   $0x0,0x609ec(%rip)        # 6a4e8 <iteration_active>
    9af9:	00 00 00 
    9afc:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    9b00:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    9b05:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    9b09:	66 0f d6 05 e7 65 01 	movq   %xmm0,0x165e7(%rip)        # 200f8 <ad_raw_before_shutdown>
    9b10:	00 
    9b11:	48 85 c0             	test   %rax,%rax
    9b14:	0f 88 06 02 00 00    	js     9d20 <fwp_main_thread+0x710>
    9b1a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9b1e:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    9b23:	f2 0f 5c 0d 9d 09 06 	subsd  0x6099d(%rip),%xmm1        # 6a4c8 <iteration_start_charge>
    9b2a:	00 
    9b2b:	48 8b 3d 0e 65 00 00 	mov    0x650e(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    9b32:	48 8d 15 07 30 00 00 	lea    0x3007(%rip),%rdx        # cb40 <_IO_stdin_used+0xb40>
    9b39:	be 02 00 00 00       	mov    $0x2,%esi
    9b3e:	f2 0f 10 05 7a 09 06 	movsd  0x6097a(%rip),%xmm0        # 6a4c0 <iteration_peak>
    9b45:	00 
    9b46:	4c 8b 0d 83 09 06 00 	mov    0x60983(%rip),%r9        # 6a4d0 <iteration_retains>
    9b4d:	b8 02 00 00 00       	mov    $0x2,%eax
    9b52:	4c 8b 05 7f 09 06 00 	mov    0x6097f(%rip),%r8        # 6a4d8 <iteration_bytes>
    9b59:	48 8b 0d 80 09 06 00 	mov    0x60980(%rip),%rcx        # 6a4e0 <iteration_requests>
    9b60:	e8 0b 9b ff ff       	call   3670 <__fprintf_chk@plt>
    9b65:	48 8b 3d b4 64 00 00 	mov    0x64b4(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    9b6c:	e8 2f 9a ff ff       	call   35a0 <fflush@plt>
    9b71:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
    9b78:	00 
    9b79:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9b80:	00 00 
    9b82:	0f 85 f0 1e 00 00    	jne    ba78 <fwp_main_thread+0x2468>
    9b88:	48 81 c4 e8 01 00 00 	add    $0x1e8,%rsp
    9b8f:	31 c0                	xor    %eax,%eax
    9b91:	5b                   	pop    %rbx
    9b92:	5d                   	pop    %rbp
    9b93:	41 5c                	pop    %r12
    9b95:	41 5d                	pop    %r13
    9b97:	41 5e                	pop    %r14
    9b99:	41 5f                	pop    %r15
    9b9b:	c3                   	ret
    9b9c:	0f 1f 40 00          	nopl   0x0(%rax)
    9ba0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    9ba7:	48 89 1d 32 ec 05 00 	mov    %rbx,0x5ec32(%rip)        # 687e0 <fwp_ready_tail>
    9bae:	e8 3d da ff ff       	call   75f0 <fwp_block>
    9bb3:	e8 28 d8 ff ff       	call   73e0 <fwp_free_zombie>
    9bb8:	48 83 3d 08 ec 05 00 	cmpq   $0x0,0x5ec08(%rip)        # 687c8 <fwp_tasks_active>
    9bbf:	00 
    9bc0:	0f 84 c0 fd ff ff    	je     9986 <fwp_main_thread+0x376>
    9bc6:	48 8b 1d 2b ec 05 00 	mov    0x5ec2b(%rip),%rbx        # 687f8 <fwp_root>
    9bcd:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    9bd1:	75 db                	jne    9bae <fwp_main_thread+0x59e>
    9bd3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    9bd7:	75 d5                	jne    9bae <fwp_main_thread+0x59e>
    9bd9:	48 8b 05 00 ec 05 00 	mov    0x5ec00(%rip),%rax        # 687e0 <fwp_ready_tail>
    9be0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    9be4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    9beb:	00 00 00 00 
    9bef:	48 85 c0             	test   %rax,%rax
    9bf2:	75 ac                	jne    9ba0 <fwp_main_thread+0x590>
    9bf4:	48 89 1d ed eb 05 00 	mov    %rbx,0x5ebed(%rip)        # 687e8 <fwp_ready_head>
    9bfb:	eb aa                	jmp    9ba7 <fwp_main_thread+0x597>
    9bfd:	0f 1f 00             	nopl   (%rax)
    9c00:	e8 bb a9 ff ff       	call   45c0 <fwp_now_ns>
    9c05:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    9c09:	7c 15                	jl     9c20 <fwp_main_thread+0x610>
    9c0b:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    9c0f:	75 0f                	jne    9c20 <fwp_main_thread+0x610>
    9c11:	48 89 ef             	mov    %rbp,%rdi
    9c14:	e8 17 a5 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    9c19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9c20:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9c24:	0f 85 97 fb ff ff    	jne    97c1 <fwp_main_thread+0x1b1>
    9c2a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    9c2e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9c32:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9c36:	0f 85 97 fb ff ff    	jne    97d3 <fwp_main_thread+0x1c3>
    9c3c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    9c40:	48 85 c9             	test   %rcx,%rcx
    9c43:	0f 84 8a fb ff ff    	je     97d3 <fwp_main_thread+0x1c3>
    9c49:	48 39 c8             	cmp    %rcx,%rax
    9c4c:	48 89 ce             	mov    %rcx,%rsi
    9c4f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9c56:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9c5a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9c61:	00 00 00 00 
    9c65:	48 0f 4e f0          	cmovle %rax,%rsi
    9c69:	48 85 c0             	test   %rax,%rax
    9c6c:	48 89 c8             	mov    %rcx,%rax
    9c6f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9c76:	48 0f 45 c6          	cmovne %rsi,%rax
    9c7a:	48 85 d2             	test   %rdx,%rdx
    9c7d:	74 07                	je     9c86 <fwp_main_thread+0x676>
    9c7f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9c86:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9c8a:	e9 76 fb ff ff       	jmp    9805 <fwp_main_thread+0x1f5>
    9c8f:	90                   	nop
    9c90:	48 89 cb             	mov    %rcx,%rbx
    9c93:	e9 09 fb ff ff       	jmp    97a1 <fwp_main_thread+0x191>
    9c98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9c9f:	00 
    9ca0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9ca4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9cab:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9cb2:	00 00 00 00 
    9cb6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    9cbd:	48 85 c0             	test   %rax,%rax
    9cc0:	0f 84 0b 1a 00 00    	je     b6d1 <fwp_main_thread+0x20c1>
    9cc6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    9ccd:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9cd1:	e9 63 fb ff ff       	jmp    9839 <fwp_main_thread+0x229>
    9cd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9cdd:	00 00 00 
    9ce0:	48 89 01             	mov    %rax,(%rcx)
    9ce3:	e9 8b fb ff ff       	jmp    9873 <fwp_main_thread+0x263>
    9ce8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9cef:	00 
    9cf0:	48 89 05 e1 ea 05 00 	mov    %rax,0x5eae1(%rip)        # 687d8 <fwp_timers>
    9cf7:	e9 c8 fb ff ff       	jmp    98c4 <fwp_main_thread+0x2b4>
    9cfc:	0f 1f 40 00          	nopl   0x0(%rax)
    9d00:	48 89 c2             	mov    %rax,%rdx
    9d03:	83 e0 01             	and    $0x1,%eax
    9d06:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9d0a:	48 d1 ea             	shr    $1,%rdx
    9d0d:	48 09 c2             	or     %rax,%rdx
    9d10:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    9d15:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    9d19:	e9 31 fa ff ff       	jmp    974f <fwp_main_thread+0x13f>
    9d1e:	66 90                	xchg   %ax,%ax
    9d20:	48 89 c2             	mov    %rax,%rdx
    9d23:	83 e0 01             	and    $0x1,%eax
    9d26:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9d2a:	48 d1 ea             	shr    $1,%rdx
    9d2d:	48 09 c2             	or     %rax,%rdx
    9d30:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    9d35:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    9d39:	e9 e5 fd ff ff       	jmp    9b23 <fwp_main_thread+0x513>
    9d3e:	48 8d 05 0b df ff ff 	lea    -0x20f5(%rip),%rax        # 7c50 <fwp_drop1>
    9d45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9d49:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    9d4e:	45 31 f6             	xor    %r14d,%r14d
    9d51:	66 48 0f 6e d8       	movq   %rax,%xmm3
    9d56:	48 8b 05 5b 07 06 00 	mov    0x6075b(%rip),%rax        # 6a4b8 <fwp_cleanups>
    9d5d:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
    9d64:	00 00 00 00 00 
    9d69:	bd ff 01 00 00       	mov    $0x1ff,%ebp
    9d6e:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    9d72:	4c 8d 25 a7 ea 05 00 	lea    0x5eaa7(%rip),%r12        # 68820 <fwp_heap>
    9d79:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    9d80:	00 
    9d81:	48 8d 05 48 9e ff ff 	lea    -0x61b8(%rip),%rax        # 3bd0 <fwp_range_release>
    9d88:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    9d8f:	00 
    9d90:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    9d95:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    9d9c:	00 
    9d9d:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    9da4:	00 
    9da5:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    9daa:	48 89 05 07 07 06 00 	mov    %rax,0x60707(%rip)        # 6a4b8 <fwp_cleanups>
    9db1:	eb 45                	jmp    9df8 <fwp_main_thread+0x7e8>
    9db3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9db8:	80 f9 01             	cmp    $0x1,%cl
    9dbb:	75 29                	jne    9de6 <fwp_main_thread+0x7d6>
    9dbd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9dc0:	0f b7 c0             	movzwl %ax,%eax
    9dc3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9dc6:	48 0f af c1          	imul   %rcx,%rax
    9dca:	48 c1 e8 20          	shr    $0x20,%rax
    9dce:	48 39 d0             	cmp    %rdx,%rax
    9dd1:	73 13                	jae    9de6 <fwp_main_thread+0x7d6>
    9dd3:	49 01 c5             	add    %rax,%r13
    9dd6:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9ddb:	0f 84 a1 19 00 00    	je     b782 <fwp_main_thread+0x2172>
    9de1:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9de6:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    9ded:	00 
    9dee:	48 83 ed 01          	sub    $0x1,%rbp
    9df2:	0f 82 88 00 00 00    	jb     9e80 <fwp_main_thread+0x870>
    9df8:	48 89 de             	mov    %rbx,%rsi
    9dfb:	bf 01 00 00 00       	mov    $0x1,%edi
    9e00:	4c 89 b4 24 48 01 00 	mov    %r14,0x148(%rsp)
    9e07:	00 
    9e08:	48 89 ac 24 d8 00 00 	mov    %rbp,0xd8(%rsp)
    9e0f:	00 
    9e10:	48 89 ac 24 40 01 00 	mov    %rbp,0x140(%rsp)
    9e17:	00 
    9e18:	e8 e3 c2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    9e1d:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    9e24:	00 
    9e25:	49 89 c6             	mov    %rax,%r14
    9e28:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    9e2f:	00 
    9e30:	48 c1 e2 10          	shl    $0x10,%rdx
    9e34:	48 39 d0             	cmp    %rdx,%rax
    9e37:	73 ad                	jae    9de6 <fwp_main_thread+0x7d6>
    9e39:	48 89 c2             	mov    %rax,%rdx
    9e3c:	48 c1 ea 10          	shr    $0x10,%rdx
    9e40:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9e44:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    9e4b:	00 
    9e4c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9e50:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9e54:	4d 85 ed             	test   %r13,%r13
    9e57:	74 8d                	je     9de6 <fwp_main_thread+0x7d6>
    9e59:	0f b6 0a             	movzbl (%rdx),%ecx
    9e5c:	80 f9 02             	cmp    $0x2,%cl
    9e5f:	0f 85 53 ff ff ff    	jne    9db8 <fwp_main_thread+0x7a8>
    9e65:	66 85 c0             	test   %ax,%ax
    9e68:	0f 84 68 ff ff ff    	je     9dd6 <fwp_main_thread+0x7c6>
    9e6e:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    9e75:	00 
    9e76:	48 83 ed 01          	sub    $0x1,%rbp
    9e7a:	0f 83 78 ff ff ff    	jae    9df8 <fwp_main_thread+0x7e8>
    9e80:	48 8b 9c 24 b0 00 00 	mov    0xb0(%rsp),%rbx
    9e87:	00 
    9e88:	66 0f 6f 05 80 2f 00 	movdqa 0x2f80(%rip),%xmm0        # ce10 <msg.4+0xd0>
    9e8f:	00 
    9e90:	bf 01 00 00 00       	mov    $0x1,%edi
    9e95:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    9e9c:	00 
    9e9d:	48 89 1d 14 06 06 00 	mov    %rbx,0x60614(%rip)        # 6a4b8 <fwp_cleanups>
    9ea4:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
    9eab:	00 
    9eac:	e8 4f c2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    9eb1:	48 8b 15 40 fd 05 00 	mov    0x5fd40(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    9eb8:	49 89 c5             	mov    %rax,%r13
    9ebb:	48 2b 05 0e fd 05 00 	sub    0x5fd0e(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    9ec2:	48 c1 e2 10          	shl    $0x10,%rdx
    9ec6:	48 39 d0             	cmp    %rdx,%rax
    9ec9:	73 57                	jae    9f22 <fwp_main_thread+0x912>
    9ecb:	48 89 c2             	mov    %rax,%rdx
    9ece:	48 c1 ea 10          	shr    $0x10,%rdx
    9ed2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ed6:	48 8b 15 3b fd 05 00 	mov    0x5fd3b(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    9edd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9ee1:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9ee5:	48 85 ed             	test   %rbp,%rbp
    9ee8:	74 38                	je     9f22 <fwp_main_thread+0x912>
    9eea:	0f b6 0a             	movzbl (%rdx),%ecx
    9eed:	80 f9 02             	cmp    $0x2,%cl
    9ef0:	0f 84 60 18 00 00    	je     b756 <fwp_main_thread+0x2146>
    9ef6:	80 f9 01             	cmp    $0x1,%cl
    9ef9:	75 27                	jne    9f22 <fwp_main_thread+0x912>
    9efb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9efe:	0f b7 c0             	movzwl %ax,%eax
    9f01:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f04:	48 0f af c1          	imul   %rcx,%rax
    9f08:	48 c1 e8 20          	shr    $0x20,%rax
    9f0c:	48 39 d0             	cmp    %rdx,%rax
    9f0f:	73 11                	jae    9f22 <fwp_main_thread+0x912>
    9f11:	48 01 c5             	add    %rax,%rbp
    9f14:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9f18:	0f 84 4c 1a 00 00    	je     b96a <fwp_main_thread+0x235a>
    9f1e:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    9f22:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9f29:	00 f0 3f 
    9f2c:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    9f33:	00 
    9f34:	bf 01 00 00 00       	mov    $0x1,%edi
    9f39:	4c 89 ac 24 28 01 00 	mov    %r13,0x128(%rsp)
    9f40:	00 
    9f41:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
    9f48:	00 
    9f49:	e8 b2 c1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    9f4e:	48 8b 15 a3 fc 05 00 	mov    0x5fca3(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    9f55:	49 89 c5             	mov    %rax,%r13
    9f58:	48 2b 05 71 fc 05 00 	sub    0x5fc71(%rip),%rax        # 69bd0 <fwp_heap+0x13b0>
    9f5f:	48 c1 e2 10          	shl    $0x10,%rdx
    9f63:	48 39 d0             	cmp    %rdx,%rax
    9f66:	73 57                	jae    9fbf <fwp_main_thread+0x9af>
    9f68:	48 89 c2             	mov    %rax,%rdx
    9f6b:	48 c1 ea 10          	shr    $0x10,%rdx
    9f6f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f73:	48 8b 15 9e fc 05 00 	mov    0x5fc9e(%rip),%rdx        # 69c18 <fwp_heap+0x13f8>
    9f7a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9f7e:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9f82:	48 85 ed             	test   %rbp,%rbp
    9f85:	74 38                	je     9fbf <fwp_main_thread+0x9af>
    9f87:	0f b6 0a             	movzbl (%rdx),%ecx
    9f8a:	80 f9 02             	cmp    $0x2,%cl
    9f8d:	0f 84 b5 17 00 00    	je     b748 <fwp_main_thread+0x2138>
    9f93:	80 f9 01             	cmp    $0x1,%cl
    9f96:	75 27                	jne    9fbf <fwp_main_thread+0x9af>
    9f98:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9f9b:	0f b7 c0             	movzwl %ax,%eax
    9f9e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9fa1:	48 0f af c1          	imul   %rcx,%rax
    9fa5:	48 c1 e8 20          	shr    $0x20,%rax
    9fa9:	48 39 d0             	cmp    %rdx,%rax
    9fac:	73 11                	jae    9fbf <fwp_main_thread+0x9af>
    9fae:	48 01 c5             	add    %rax,%rbp
    9fb1:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9fb5:	0f 84 bc 19 00 00    	je     b977 <fwp_main_thread+0x2367>
    9fbb:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    9fbf:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9fc6:	33 f3 bf 
    9fc9:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    9fd0:	00 
    9fd1:	bf 01 00 00 00       	mov    $0x1,%edi
    9fd6:	4c 89 ac 24 18 01 00 	mov    %r13,0x118(%rsp)
    9fdd:	00 
    9fde:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
    9fe5:	00 
    9fe6:	e8 15 c1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    9feb:	48 8b 15 06 fc 05 00 	mov    0x5fc06(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    9ff2:	48 8b 0d d7 fb 05 00 	mov    0x5fbd7(%rip),%rcx        # 69bd0 <fwp_heap+0x13b0>
    9ff9:	48 89 04 24          	mov    %rax,(%rsp)
    9ffd:	48 89 d6             	mov    %rdx,%rsi
    a000:	48 29 c8             	sub    %rcx,%rax
    a003:	48 c1 e6 10          	shl    $0x10,%rsi
    a007:	48 39 f0             	cmp    %rsi,%rax
    a00a:	73 67                	jae    a073 <fwp_main_thread+0xa63>
    a00c:	48 89 c6             	mov    %rax,%rsi
    a00f:	48 c1 ee 10          	shr    $0x10,%rsi
    a013:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a017:	48 8b 35 fa fb 05 00 	mov    0x5fbfa(%rip),%rsi        # 69c18 <fwp_heap+0x13f8>
    a01e:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a022:	48 8b 6e 20          	mov    0x20(%rsi),%rbp
    a026:	48 85 ed             	test   %rbp,%rbp
    a029:	74 48                	je     a073 <fwp_main_thread+0xa63>
    a02b:	0f b6 3e             	movzbl (%rsi),%edi
    a02e:	40 80 ff 02          	cmp    $0x2,%dil
    a032:	0f 84 2c 17 00 00    	je     b764 <fwp_main_thread+0x2154>
    a038:	40 80 ff 01          	cmp    $0x1,%dil
    a03c:	75 35                	jne    a073 <fwp_main_thread+0xa63>
    a03e:	8b 7e 18             	mov    0x18(%rsi),%edi
    a041:	0f b7 c0             	movzwl %ax,%eax
    a044:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a047:	48 0f af c7          	imul   %rdi,%rax
    a04b:	48 c1 e8 20          	shr    $0x20,%rax
    a04f:	48 39 f0             	cmp    %rsi,%rax
    a052:	73 1f                	jae    a073 <fwp_main_thread+0xa63>
    a054:	48 01 c5             	add    %rax,%rbp
    a057:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    a05b:	0f 84 23 19 00 00    	je     b984 <fwp_main_thread+0x2374>
    a061:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    a065:	48 8b 0d 64 fb 05 00 	mov    0x5fb64(%rip),%rcx        # 69bd0 <fwp_heap+0x13b0>
    a06c:	48 8b 15 85 fb 05 00 	mov    0x5fb85(%rip),%rdx        # 69bf8 <fwp_heap+0x13d8>
    a073:	48 8d 84 24 8c 00 00 	lea    0x8c(%rsp),%rax
    a07a:	00 
    a07b:	4c 89 74 24 58       	mov    %r14,0x58(%rsp)
    a080:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    a085:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    a08c:	00 
    a08d:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    a092:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
    a097:	48 8b 04 24          	mov    (%rsp),%rax
    a09b:	48 c1 e2 10          	shl    $0x10,%rdx
    a09f:	48 29 c8             	sub    %rcx,%rax
    a0a2:	48 39 d0             	cmp    %rdx,%rax
    a0a5:	0f 83 8a 00 00 00    	jae    a135 <fwp_main_thread+0xb25>
    a0ab:	48 89 c6             	mov    %rax,%rsi
    a0ae:	48 c1 ee 10          	shr    $0x10,%rsi
    a0b2:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a0b6:	49 8b b4 24 f8 13 00 	mov    0x13f8(%r12),%rsi
    a0bd:	00 
    a0be:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a0c2:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a0c6:	48 85 ff             	test   %rdi,%rdi
    a0c9:	74 6a                	je     a135 <fwp_main_thread+0xb25>
    a0cb:	44 0f b6 06          	movzbl (%rsi),%r8d
    a0cf:	41 80 f8 02          	cmp    $0x2,%r8b
    a0d3:	0f 84 97 15 00 00    	je     b670 <fwp_main_thread+0x2060>
    a0d9:	41 80 f8 01          	cmp    $0x1,%r8b
    a0dd:	75 56                	jne    a135 <fwp_main_thread+0xb25>
    a0df:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a0e3:	0f b7 c0             	movzwl %ax,%eax
    a0e6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a0e9:	49 0f af c0          	imul   %r8,%rax
    a0ed:	48 c1 e8 20          	shr    $0x20,%rax
    a0f1:	48 39 f0             	cmp    %rsi,%rax
    a0f4:	73 3f                	jae    a135 <fwp_main_thread+0xb25>
    a0f6:	48 01 c7             	add    %rax,%rdi
    a0f9:	0f b6 07             	movzbl (%rdi),%eax
    a0fc:	84 c0                	test   %al,%al
    a0fe:	74 35                	je     a135 <fwp_main_thread+0xb25>
    a100:	44 8b 0d e1 03 06 00 	mov    0x603e1(%rip),%r9d        # 6a4e8 <iteration_active>
    a107:	45 85 c9             	test   %r9d,%r9d
    a10a:	74 08                	je     a114 <fwp_main_thread+0xb04>
    a10c:	48 83 05 bc 03 06 00 	addq   $0x1,0x603bc(%rip)        # 6a4d0 <iteration_retains>
    a113:	01 
    a114:	3c fd                	cmp    $0xfd,%al
    a116:	0f 87 d8 17 00 00    	ja     b8f4 <fwp_main_thread+0x22e4>
    a11c:	83 c0 01             	add    $0x1,%eax
    a11f:	88 07                	mov    %al,(%rdi)
    a121:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    a128:	00 
    a129:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    a130:	00 
    a131:	48 c1 e2 10          	shl    $0x10,%rdx
    a135:	48 8d 05 c4 cd ff ff 	lea    -0x323c(%rip),%rax        # 6f00 <fwp_tape_scope_release>
    a13c:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
    a143:	00 
    a144:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    a14b:	00 
    a14c:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    a151:	c7 84 24 8c 00 00 00 	movl   $0xffffffff,0x8c(%rsp)
    a158:	ff ff ff ff 
    a15c:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    a163:	00 
    a164:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    a169:	48 89 05 48 03 06 00 	mov    %rax,0x60348(%rip)        # 6a4b8 <fwp_cleanups>
    a170:	48 8d 05 99 5e 00 00 	lea    0x5e99(%rip),%rax        # 10010 <fc37>
    a177:	48 29 c8             	sub    %rcx,%rax
    a17a:	48 39 d0             	cmp    %rdx,%rax
    a17d:	73 72                	jae    a1f1 <fwp_main_thread+0xbe1>
    a17f:	48 89 c2             	mov    %rax,%rdx
    a182:	48 c1 ea 10          	shr    $0x10,%rdx
    a186:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a18a:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    a191:	00 
    a192:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a196:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a19a:	48 85 ff             	test   %rdi,%rdi
    a19d:	74 52                	je     a1f1 <fwp_main_thread+0xbe1>
    a19f:	0f b6 0a             	movzbl (%rdx),%ecx
    a1a2:	80 f9 02             	cmp    $0x2,%cl
    a1a5:	0f 84 a5 12 00 00    	je     b450 <fwp_main_thread+0x1e40>
    a1ab:	80 f9 01             	cmp    $0x1,%cl
    a1ae:	75 41                	jne    a1f1 <fwp_main_thread+0xbe1>
    a1b0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a1b3:	0f b7 c0             	movzwl %ax,%eax
    a1b6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a1b9:	48 0f af c1          	imul   %rcx,%rax
    a1bd:	48 c1 e8 20          	shr    $0x20,%rax
    a1c1:	48 39 d0             	cmp    %rdx,%rax
    a1c4:	73 2b                	jae    a1f1 <fwp_main_thread+0xbe1>
    a1c6:	48 01 c7             	add    %rax,%rdi
    a1c9:	0f b6 07             	movzbl (%rdi),%eax
    a1cc:	84 c0                	test   %al,%al
    a1ce:	74 21                	je     a1f1 <fwp_main_thread+0xbe1>
    a1d0:	44 8b 05 11 03 06 00 	mov    0x60311(%rip),%r8d        # 6a4e8 <iteration_active>
    a1d7:	45 85 c0             	test   %r8d,%r8d
    a1da:	74 08                	je     a1e4 <fwp_main_thread+0xbd4>
    a1dc:	48 83 05 ec 02 06 00 	addq   $0x1,0x602ec(%rip)        # 6a4d0 <iteration_retains>
    a1e3:	01 
    a1e4:	3c fd                	cmp    $0xfd,%al
    a1e6:	0f 87 5a 16 00 00    	ja     b846 <fwp_main_thread+0x2236>
    a1ec:	83 c0 01             	add    $0x1,%eax
    a1ef:	88 07                	mov    %al,(%rdi)
    a1f1:	48 8d 3d 18 5e 00 00 	lea    0x5e18(%rip),%rdi        # 10010 <fc37>
    a1f8:	31 ed                	xor    %ebp,%ebp
    a1fa:	e8 91 c9 ff ff       	call   6b90 <fwp_closure_drop>
    a1ff:	48 8b 1c 24          	mov    (%rsp),%rbx
    a203:	66 90                	xchg   %ax,%ax
    a205:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a20c:	00 00 00 00 
    a210:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    a214:	48 83 c5 01          	add    $0x1,%rbp
    a218:	48 85 db             	test   %rbx,%rbx
    a21b:	75 f3                	jne    a210 <fwp_main_thread+0xc00>
    a21d:	48 81 fd ff ff ff 7f 	cmp    $0x7fffffff,%rbp
    a224:	0f 87 af 17 00 00    	ja     b9d9 <fwp_main_thread+0x23c9>
    a22a:	8b 35 30 5e 00 00    	mov    0x5e30(%rip),%esi        # 10060 <registered_finish.1>
    a230:	85 f6                	test   %esi,%esi
    a232:	0f 84 e0 11 00 00    	je     b418 <fwp_main_thread+0x1e08>
    a238:	4c 8b 3d 99 5e 01 00 	mov    0x15e99(%rip),%r15        # 200d8 <fwp_tape_next_slot>
    a23f:	4c 8b 2d a2 5e 01 00 	mov    0x15ea2(%rip),%r13        # 200e8 <fwp_ntapes>
    a246:	4d 39 fd             	cmp    %r15,%r13
    a249:	0f 8e 39 0e 00 00    	jle    b088 <fwp_main_thread+0x1a78>
    a24f:	49 6b c7 68          	imul   $0x68,%r15,%rax
    a253:	48 03 05 96 5e 01 00 	add    0x15e96(%rip),%rax        # 200f0 <fwp_tapes>
    a25a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a260:	8b 48 04             	mov    0x4(%rax),%ecx
    a263:	85 c9                	test   %ecx,%ecx
    a265:	75 0c                	jne    a273 <fwp_main_thread+0xc63>
    a267:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    a26d:	0f 86 15 0e 00 00    	jbe    b088 <fwp_main_thread+0x1a78>
    a273:	49 83 c7 01          	add    $0x1,%r15
    a277:	48 83 c0 68          	add    $0x68,%rax
    a27b:	4d 39 fd             	cmp    %r15,%r13
    a27e:	75 e0                	jne    a260 <fwp_main_thread+0xc50>
    a280:	49 81 fd fe ff 00 00 	cmp    $0xfffe,%r13
    a287:	0f 8f c3 17 00 00    	jg     ba50 <fwp_main_thread+0x2440>
    a28d:	4c 39 2d 4c 5e 01 00 	cmp    %r13,0x15e4c(%rip)        # 200e0 <fwp_tapes_cap>
    a294:	4c 8b 35 55 5e 01 00 	mov    0x15e55(%rip),%r14        # 200f0 <fwp_tapes>
    a29b:	75 42                	jne    a2df <fwp_main_thread+0xccf>
    a29d:	4d 85 ed             	test   %r13,%r13
    a2a0:	0f 84 34 14 00 00    	je     b6da <fwp_main_thread+0x20ca>
    a2a6:	4f 8d 7c 2d 00       	lea    0x0(%r13,%r13,1),%r15
    a2ab:	b8 ff ff 00 00       	mov    $0xffff,%eax
    a2b0:	49 39 c7             	cmp    %rax,%r15
    a2b3:	4c 0f 4f f8          	cmovg  %rax,%r15
    a2b7:	49 6b f7 68          	imul   $0x68,%r15,%rsi
    a2bb:	4c 89 f7             	mov    %r14,%rdi
    a2be:	31 d2                	xor    %edx,%edx
    a2c0:	e8 cb ae ff ff       	call   5190 <ad_raw_realloc>
    a2c5:	49 89 c6             	mov    %rax,%r14
    a2c8:	48 85 c0             	test   %rax,%rax
    a2cb:	0f 84 2d 17 00 00    	je     b9fe <fwp_main_thread+0x23ee>
    a2d1:	48 89 05 18 5e 01 00 	mov    %rax,0x15e18(%rip)        # 200f0 <fwp_tapes>
    a2d8:	4c 89 3d 01 5e 01 00 	mov    %r15,0x15e01(%rip)        # 200e0 <fwp_tapes_cap>
    a2df:	49 6b c5 68          	imul   $0x68,%r13,%rax
    a2e3:	4d 89 ef             	mov    %r13,%r15
    a2e6:	4c 01 f0             	add    %r14,%rax
    a2e9:	48 8d 78 08          	lea    0x8(%rax),%rdi
    a2ed:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a2f4:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    a2f8:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    a2ff:	00 
    a300:	48 29 f8             	sub    %rdi,%rax
    a303:	8d 48 68             	lea    0x68(%rax),%ecx
    a306:	31 c0                	xor    %eax,%eax
    a308:	c1 e9 03             	shr    $0x3,%ecx
    a30b:	f3 48 ab             	rep stos %rax,(%rdi)
    a30e:	49 8d 45 01          	lea    0x1(%r13),%rax
    a312:	48 89 05 cf 5d 01 00 	mov    %rax,0x15dcf(%rip)        # 200e8 <fwp_ntapes>
    a319:	4d 6b ef 68          	imul   $0x68,%r15,%r13
    a31d:	66 48 0f 6e c5       	movq   %rbp,%xmm0
    a322:	48 8d 3d 37 1e 00 00 	lea    0x1e37(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    a329:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    a32d:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    a332:	4d 01 f5             	add    %r14,%r13
    a335:	49 c7 45 60 00 00 00 	movq   $0x0,0x60(%r13)
    a33c:	00 
    a33d:	e8 4e 90 ff ff       	call   3390 <getenv@plt>
    a342:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    a348:	48 85 c0             	test   %rax,%rax
    a34b:	0f 84 4f 0d 00 00    	je     b0a0 <fwp_main_thread+0x1a90>
    a351:	80 38 30             	cmpb   $0x30,(%rax)
    a354:	0f 85 46 0d 00 00    	jne    b0a0 <fwp_main_thread+0x1a90>
    a35a:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    a35e:	0f 85 3c 0d 00 00    	jne    b0a0 <fwp_main_thread+0x1a90>
    a364:	41 8b 45 00          	mov    0x0(%r13),%eax
    a368:	49 8d 6f 01          	lea    0x1(%r15),%rbp
    a36c:	41 c7 45 04 01 00 00 	movl   $0x1,0x4(%r13)
    a373:	00 
    a374:	48 89 2d 5d 5d 01 00 	mov    %rbp,0x15d5d(%rip)        # 200d8 <fwp_tape_next_slot>
    a37b:	8d 50 01             	lea    0x1(%rax),%edx
    a37e:	48 8b 05 db 29 00 00 	mov    0x29db(%rip),%rax        # cd60 <msg.4+0x20>
    a385:	41 0f 11 45 08       	movups %xmm0,0x8(%r13)
    a38a:	41 89 55 00          	mov    %edx,0x0(%r13)
    a38e:	49 89 45 58          	mov    %rax,0x58(%r13)
    a392:	48 8b 05 1f 01 06 00 	mov    0x6011f(%rip),%rax        # 6a4b8 <fwp_cleanups>
    a399:	49 c7 45 50 00 00 00 	movq   $0x0,0x50(%r13)
    a3a0:	00 
    a3a1:	48 85 c0             	test   %rax,%rax
    a3a4:	75 26                	jne    a3cc <fwp_main_thread+0xdbc>
    a3a6:	e9 b5 16 00 00       	jmp    ba60 <fwp_main_thread+0x2450>
    a3ab:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a3b2:	00 00 00 
    a3b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a3bc:	00 00 00 00 
    a3c0:	48 8b 00             	mov    (%rax),%rax
    a3c3:	48 85 c0             	test   %rax,%rax
    a3c6:	0f 84 94 16 00 00    	je     ba60 <fwp_main_thread+0x2450>
    a3cc:	48 8d 3d 2d cb ff ff 	lea    -0x34d3(%rip),%rdi        # 6f00 <fwp_tape_scope_release>
    a3d3:	48 39 78 08          	cmp    %rdi,0x8(%rax)
    a3d7:	75 e7                	jne    a3c0 <fwp_main_thread+0xdb0>
    a3d9:	48 8b 70 10          	mov    0x10(%rax),%rsi
    a3dd:	44 89 f9             	mov    %r15d,%ecx
    a3e0:	48 63 06             	movslq (%rsi),%rax
    a3e3:	49 89 75 50          	mov    %rsi,0x50(%r13)
    a3e7:	41 89 45 5c          	mov    %eax,0x5c(%r13)
    a3eb:	85 c0                	test   %eax,%eax
    a3ed:	78 09                	js     a3f8 <fwp_main_thread+0xde8>
    a3ef:	48 6b c0 68          	imul   $0x68,%rax,%rax
    a3f3:	45 89 7c 06 58       	mov    %r15d,0x58(%r14,%rax,1)
    a3f8:	89 0e                	mov    %ecx,(%rsi)
    a3fa:	48 8b 04 24          	mov    (%rsp),%rax
    a3fe:	66 90                	xchg   %ax,%ax
    a400:	48 8b 40 10          	mov    0x10(%rax),%rax
    a404:	48 83 c3 01          	add    $0x1,%rbx
    a408:	48 85 c0             	test   %rax,%rax
    a40b:	75 f3                	jne    a400 <fwp_main_thread+0xdf0>
    a40d:	4c 8b 34 24          	mov    (%rsp),%r14
    a411:	0f 1f 40 00          	nopl   0x0(%rax)
    a415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a41c:	00 00 00 00 
    a420:	4d 8b 76 10          	mov    0x10(%r14),%r14
    a424:	48 83 c0 01          	add    $0x1,%rax
    a428:	4d 85 f6             	test   %r14,%r14
    a42b:	75 f3                	jne    a420 <fwp_main_thread+0xe10>
    a42d:	48 b9 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rcx
    a434:	ff ff 1f 
    a437:	48 39 c1             	cmp    %rax,%rcx
    a43a:	0f 82 8d 15 00 00    	jb     b9cd <fwp_main_thread+0x23bd>
    a440:	48 85 db             	test   %rbx,%rbx
    a443:	0f 8e 57 0e 00 00    	jle    b2a0 <fwp_main_thread+0x1c90>
    a449:	48 39 c3             	cmp    %rax,%rbx
    a44c:	48 0f 47 d8          	cmova  %rax,%rbx
    a450:	48 89 d8             	mov    %rbx,%rax
    a453:	48 c1 e8 3c          	shr    $0x3c,%rax
    a457:	0f 85 70 15 00 00    	jne    b9cd <fwp_main_thread+0x23bd>
    a45d:	4c 8d 2c 1b          	lea    (%rbx,%rbx,1),%r13
    a461:	48 c1 e2 10          	shl    $0x10,%rdx
    a465:	be 02 00 00 00       	mov    $0x2,%esi
    a46a:	48 09 ea             	or     %rbp,%rdx
    a46d:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    a474:	00 
    a475:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    a47a:	e8 91 ba ff ff       	call   5f10 <fwp_heap_alloc>
    a47f:	4c 89 28             	mov    %r13,(%rax)
    a482:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    a489:	00 
    a48a:	48 89 c5             	mov    %rax,%rbp
    a48d:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    a494:	00 
    a495:	48 c1 e2 10          	shl    $0x10,%rdx
    a499:	48 39 d0             	cmp    %rdx,%rax
    a49c:	0f 83 ee 10 00 00    	jae    b590 <fwp_main_thread+0x1f80>
    a4a2:	48 89 c2             	mov    %rax,%rdx
    a4a5:	48 c1 ea 10          	shr    $0x10,%rdx
    a4a9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a4ad:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    a4b4:	00 
    a4b5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a4b9:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a4bd:	4d 85 ed             	test   %r13,%r13
    a4c0:	74 3a                	je     a4fc <fwp_main_thread+0xeec>
    a4c2:	0f b6 0a             	movzbl (%rdx),%ecx
    a4c5:	80 f9 02             	cmp    $0x2,%cl
    a4c8:	0f 84 46 0e 00 00    	je     b314 <fwp_main_thread+0x1d04>
    a4ce:	80 f9 01             	cmp    $0x1,%cl
    a4d1:	75 29                	jne    a4fc <fwp_main_thread+0xeec>
    a4d3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a4d6:	0f b7 c0             	movzwl %ax,%eax
    a4d9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a4dc:	48 0f af c1          	imul   %rcx,%rax
    a4e0:	48 c1 e8 20          	shr    $0x20,%rax
    a4e4:	48 39 d0             	cmp    %rdx,%rax
    a4e7:	73 13                	jae    a4fc <fwp_main_thread+0xeec>
    a4e9:	49 01 c5             	add    %rax,%r13
    a4ec:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a4f1:	0f 84 31 0e 00 00    	je     b328 <fwp_main_thread+0x1d18>
    a4f7:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a4fc:	48 85 db             	test   %rbx,%rbx
    a4ff:	74 72                	je     a573 <fwp_main_thread+0xf63>
    a501:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    a506:	48 8b 14 24          	mov    (%rsp),%rdx
    a50a:	31 c0                	xor    %eax,%eax
    a50c:	48 c1 e1 20          	shl    $0x20,%rcx
    a510:	0f 1f 40 00          	nopl   0x0(%rax)
    a514:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a51b:	00 00 00 00 
    a51f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a526:	00 00 00 00 
    a52a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a531:	00 00 00 00 
    a535:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a53c:	00 00 00 00 
    a540:	48 89 c6             	mov    %rax,%rsi
    a543:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    a548:	48 01 ce             	add    %rcx,%rsi
    a54b:	0f 80 77 14 00 00    	jo     b9c8 <fwp_main_thread+0x23b8>
    a551:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    a556:	48 89 c6             	mov    %rax,%rsi
    a559:	48 83 c0 01          	add    $0x1,%rax
    a55d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    a561:	48 c1 e6 04          	shl    $0x4,%rsi
    a565:	0f 11 44 35 08       	movups %xmm0,0x8(%rbp,%rsi,1)
    a56a:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a56e:	48 39 d8             	cmp    %rbx,%rax
    a571:	72 cd                	jb     a540 <fwp_main_thread+0xf30>
    a573:	48 8b 45 00          	mov    0x0(%rbp),%rax
    a577:	48 d1 e8             	shr    $1,%rax
    a57a:	0f 85 80 0c 00 00    	jne    b200 <fwp_main_thread+0x1bf0>
    a580:	48 c7 45 00 00 00 00 	movq   $0x0,0x0(%rbp)
    a587:	00 
    a588:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    a58f:	90                   	nop
    a590:	48 89 ef             	mov    %rbp,%rdi
    a593:	e8 b8 d8 ff ff       	call   7e50 <fwp_drop10>
    a598:	4c 63 6c 24 20       	movslq 0x20(%rsp),%r13
    a59d:	4c 89 ef             	mov    %r13,%rdi
    a5a0:	e8 8b a1 ff ff       	call   4730 <fwp_tape_of>
    a5a5:	48 89 c6             	mov    %rax,%rsi
    a5a8:	48 8b 40 60          	mov    0x60(%rax),%rax
    a5ac:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    a5b1:	48 85 c0             	test   %rax,%rax
    a5b4:	0f 85 8a 14 00 00    	jne    ba44 <fwp_main_thread+0x2434>
    a5ba:	48 89 f7             	mov    %rsi,%rdi
    a5bd:	e8 ce 96 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    a5c2:	48 8b 5e 48          	mov    0x48(%rsi),%rbx
    a5c6:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    a5cb:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    a5d2:	4c 8b 4e 08          	mov    0x8(%rsi),%r9
    a5d6:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    a5da:	66 48 0f 6e fb       	movq   %rbx,%xmm7
    a5df:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    a5e4:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    a5e9:	4c 8b 46 40          	mov    0x40(%rsi),%r8
    a5ed:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    a5f1:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    a5f7:	77 1a                	ja     a613 <fwp_main_thread+0x1003>
    a5f9:	0f b7 44 24 20       	movzwl 0x20(%rsp),%eax
    a5fe:	83 e8 01             	sub    $0x1,%eax
    a601:	48 98                	cltq
    a603:	48 3b 05 ce 5a 01 00 	cmp    0x15ace(%rip),%rax        # 200d8 <fwp_tape_next_slot>
    a60a:	7d 07                	jge    a613 <fwp_main_thread+0x1003>
    a60c:	48 89 05 c5 5a 01 00 	mov    %rax,0x15ac5(%rip)        # 200d8 <fwp_tape_next_slot>
    a613:	48 8b 05 9e fe 05 00 	mov    0x5fe9e(%rip),%rax        # 6a4b8 <fwp_cleanups>
    a61a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a61e:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    a625:	00 
    a626:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    a62d:	00 
    a62e:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    a635:	00 
    a636:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    a63a:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    a63e:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    a642:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    a649:	00 
    a64a:	48 8d 05 0f ac ff ff 	lea    -0x53f1(%rip),%rax        # 5260 <fwp_tape_buffers_release>
    a651:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    a658:	00 
    a659:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    a65e:	4c 89 84 24 f0 00 00 	mov    %r8,0xf0(%rsp)
    a665:	00 
    a666:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    a66d:	00 
    a66e:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    a673:	0f 29 9c 24 d0 00 00 	movaps %xmm3,0xd0(%rsp)
    a67a:	00 
    a67b:	48 89 05 36 fe 05 00 	mov    %rax,0x5fe36(%rip)        # 6a4b8 <fwp_cleanups>
    a682:	0f 29 94 24 e0 00 00 	movaps %xmm2,0xe0(%rsp)
    a689:	00 
    a68a:	0f 11 84 24 f8 00 00 	movups %xmm0,0xf8(%rsp)
    a691:	00 
    a692:	4d 85 ff             	test   %r15,%r15
    a695:	0f 88 c5 0d 00 00    	js     b460 <fwp_main_thread+0x1e50>
    a69b:	4c 89 f8             	mov    %r15,%rax
    a69e:	48 c1 f8 20          	sar    $0x20,%rax
    a6a2:	49 39 c5             	cmp    %rax,%r13
    a6a5:	0f 85 05 13 00 00    	jne    b9b0 <fwp_main_thread+0x23a0>
    a6ab:	44 89 f9             	mov    %r15d,%ecx
    a6ae:	49 89 cd             	mov    %rcx,%r13
    a6b1:	48 39 ca             	cmp    %rcx,%rdx
    a6b4:	0f 8e a4 12 00 00    	jle    b95e <fwp_main_thread+0x234e>
    a6ba:	49 39 c9             	cmp    %rcx,%r9
    a6bd:	0f 8e 75 0c 00 00    	jle    b338 <fwp_main_thread+0x1d28>
    a6c3:	49 39 d9             	cmp    %rbx,%r9
    a6c6:	0f 8f a4 0c 00 00    	jg     b370 <fwp_main_thread+0x1d60>
    a6cc:	4d 85 c0             	test   %r8,%r8
    a6cf:	0f 84 10 13 00 00    	je     b9e5 <fwp_main_thread+0x23d5>
    a6d5:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
    a6da:	4d 8d 69 ff          	lea    -0x1(%r9),%r13
    a6de:	31 f6                	xor    %esi,%esi
    a6e0:	4c 89 c7             	mov    %r8,%rdi
    a6e3:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    a6e8:	4a 8d 14 cd 00 00 00 	lea    0x0(,%r9,8),%rdx
    a6ef:	00 
    a6f0:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    a6f5:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    a6fa:	e8 b1 8d ff ff       	call   34b0 <memset@plt>
    a6ff:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    a704:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    a70a:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    a710:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
    a715:	49 89 c0             	mov    %rax,%r8
    a718:	f2 0f 10 05 48 26 00 	movsd  0x2648(%rip),%xmm0        # cd68 <msg.4+0x28>
    a71f:	00 
    a720:	f2 41 0f 58 04 c8    	addsd  (%r8,%rcx,8),%xmm0
    a726:	f2 41 0f 11 04 c8    	movsd  %xmm0,(%r8,%rcx,8)
    a72c:	4d 39 e9             	cmp    %r13,%r9
    a72f:	0f 8f 8c 00 00 00    	jg     a7c1 <fwp_main_thread+0x11b1>
    a735:	0f 12 fb             	movhlps %xmm3,%xmm7
    a738:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    a73d:	0f 12 da             	movhlps %xmm2,%xmm3
    a740:	4d 29 cd             	sub    %r9,%r13
    a743:	66 49 0f 7e da       	movq   %xmm3,%r10
    a748:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    a74d:	66 48 0f 7e d7       	movq   %xmm2,%rdi
    a752:	4f 8d 1c c8          	lea    (%r8,%r9,8),%r11
    a756:	4b 8d 14 ea          	lea    (%r10,%r13,8),%rdx
    a75a:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a75e:	48 29 f1             	sub    %rsi,%rcx
    a761:	4a 8d 04 ae          	lea    (%rsi,%r13,4),%rax
    a765:	4d 29 d3             	sub    %r10,%r11
    a768:	4c 29 d7             	sub    %r10,%rdi
    a76b:	eb 07                	jmp    a774 <fwp_main_thread+0x1164>
    a76d:	0f 1f 00             	nopl   (%rax)
    a770:	48 83 e8 04          	sub    $0x4,%rax
    a774:	f2 41 0f 10 04 13    	movsd  (%r11,%rdx,1),%xmm0
    a77a:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    a77e:	7a 02                	jp     a782 <fwp_main_thread+0x1172>
    a780:	74 36                	je     a7b8 <fwp_main_thread+0x11a8>
    a782:	4c 63 14 01          	movslq (%rcx,%rax,1),%r10
    a786:	45 85 d2             	test   %r10d,%r10d
    a789:	78 15                	js     a7a0 <fwp_main_thread+0x1190>
    a78b:	f2 0f 10 0c 17       	movsd  (%rdi,%rdx,1),%xmm1
    a790:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    a794:	f2 43 0f 58 0c d0    	addsd  (%r8,%r10,8),%xmm1
    a79a:	f2 43 0f 11 0c d0    	movsd  %xmm1,(%r8,%r10,8)
    a7a0:	4c 63 10             	movslq (%rax),%r10
    a7a3:	45 85 d2             	test   %r10d,%r10d
    a7a6:	78 10                	js     a7b8 <fwp_main_thread+0x11a8>
    a7a8:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    a7ac:	f2 43 0f 58 04 d0    	addsd  (%r8,%r10,8),%xmm0
    a7b2:	f2 43 0f 11 04 d0    	movsd  %xmm0,(%r8,%r10,8)
    a7b8:	48 83 ea 08          	sub    $0x8,%rdx
    a7bc:	48 39 f0             	cmp    %rsi,%rax
    a7bf:	75 af                	jne    a770 <fwp_main_thread+0x1160>
    a7c1:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a7c8:	ff ff 1f 
    a7cb:	4c 39 c8             	cmp    %r9,%rax
    a7ce:	0f 82 58 12 00 00    	jb     ba2c <fwp_main_thread+0x241c>
    a7d4:	4a 8d 3c cd 08 00 00 	lea    0x8(,%r9,8),%rdi
    a7db:	00 
    a7dc:	be 02 00 00 00       	mov    $0x2,%esi
    a7e1:	4c 89 44 24 30       	mov    %r8,0x30(%rsp)
    a7e6:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    a7eb:	e8 20 b7 ff ff       	call   5f10 <fwp_heap_alloc>
    a7f0:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    a7f5:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
    a7fa:	48 89 c3             	mov    %rax,%rbx
    a7fd:	4c 89 08             	mov    %r9,(%rax)
    a800:	31 c0                	xor    %eax,%eax
    a802:	4d 85 c9             	test   %r9,%r9
    a805:	74 2b                	je     a832 <fwp_main_thread+0x1222>
    a807:	0f 1f 00             	nopl   (%rax)
    a80a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a811:	00 00 00 00 
    a815:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a81c:	00 00 00 00 
    a820:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    a824:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    a829:	48 83 c0 01          	add    $0x1,%rax
    a82d:	49 39 c1             	cmp    %rax,%r9
    a830:	75 ee                	jne    a820 <fwp_main_thread+0x1210>
    a832:	48 8b ac 24 b0 00 00 	mov    0xb0(%rsp),%rbp
    a839:	00 
    a83a:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    a83f:	48 89 2d 72 fc 05 00 	mov    %rbp,0x5fc72(%rip)        # 6a4b8 <fwp_cleanups>
    a846:	e8 15 aa ff ff       	call   5260 <fwp_tape_buffers_release>
    a84b:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    a852:	00 
    a853:	48 89 d8             	mov    %rbx,%rax
    a856:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    a85d:	00 
    a85e:	48 c1 e2 10          	shl    $0x10,%rdx
    a862:	48 39 d0             	cmp    %rdx,%rax
    a865:	73 5a                	jae    a8c1 <fwp_main_thread+0x12b1>
    a867:	48 89 c2             	mov    %rax,%rdx
    a86a:	48 c1 ea 10          	shr    $0x10,%rdx
    a86e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a872:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    a879:	00 
    a87a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a87e:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a882:	4d 85 ed             	test   %r13,%r13
    a885:	74 3a                	je     a8c1 <fwp_main_thread+0x12b1>
    a887:	0f b6 0a             	movzbl (%rdx),%ecx
    a88a:	80 f9 02             	cmp    $0x2,%cl
    a88d:	0f 84 fd 0b 00 00    	je     b490 <fwp_main_thread+0x1e80>
    a893:	80 f9 01             	cmp    $0x1,%cl
    a896:	75 29                	jne    a8c1 <fwp_main_thread+0x12b1>
    a898:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a89b:	0f b7 c0             	movzwl %ax,%eax
    a89e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a8a1:	48 0f af c1          	imul   %rcx,%rax
    a8a5:	48 c1 e8 20          	shr    $0x20,%rax
    a8a9:	48 39 d0             	cmp    %rdx,%rax
    a8ac:	73 13                	jae    a8c1 <fwp_main_thread+0x12b1>
    a8ae:	49 01 c5             	add    %rax,%r13
    a8b1:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a8b6:	0f 84 e8 0b 00 00    	je     b4a4 <fwp_main_thread+0x1e94>
    a8bc:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a8c1:	48 3b 6c 24 48       	cmp    0x48(%rsp),%rbp
    a8c6:	0f 85 7f 8e ff ff    	jne    374b <fwp_main_thread.cold>
    a8cc:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
    a8d3:	00 
    a8d4:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    a8d9:	48 89 05 d8 fb 05 00 	mov    %rax,0x5fbd8(%rip)        # 6a4b8 <fwp_cleanups>
    a8e0:	e8 1b c6 ff ff       	call   6f00 <fwp_tape_scope_release>
    a8e5:	48 8b 03             	mov    (%rbx),%rax
    a8e8:	49 89 c5             	mov    %rax,%r13
    a8eb:	49 0f ba f5 3f       	btr    $0x3f,%r13
    a8f0:	48 85 c0             	test   %rax,%rax
    a8f3:	0f 88 37 08 00 00    	js     b130 <fwp_main_thread+0x1b20>
    a8f9:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    a900:	00 
    a901:	48 89 d8             	mov    %rbx,%rax
    a904:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    a90b:	00 
    a90c:	48 c1 e2 10          	shl    $0x10,%rdx
    a910:	48 39 d0             	cmp    %rdx,%rax
    a913:	0f 83 17 08 00 00    	jae    b130 <fwp_main_thread+0x1b20>
    a919:	48 89 c2             	mov    %rax,%rdx
    a91c:	48 c1 ea 10          	shr    $0x10,%rdx
    a920:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a924:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    a92b:	00 
    a92c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a930:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    a934:	48 85 c9             	test   %rcx,%rcx
    a937:	0f 84 f3 07 00 00    	je     b130 <fwp_main_thread+0x1b20>
    a93d:	0f b6 32             	movzbl (%rdx),%esi
    a940:	40 80 fe 02          	cmp    $0x2,%sil
    a944:	0f 84 d6 07 00 00    	je     b120 <fwp_main_thread+0x1b10>
    a94a:	40 80 fe 01          	cmp    $0x1,%sil
    a94e:	0f 85 dc 07 00 00    	jne    b130 <fwp_main_thread+0x1b20>
    a954:	8b 72 18             	mov    0x18(%rdx),%esi
    a957:	0f b7 c0             	movzwl %ax,%eax
    a95a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a95d:	48 0f af c6          	imul   %rsi,%rax
    a961:	48 c1 e8 20          	shr    $0x20,%rax
    a965:	48 39 d0             	cmp    %rdx,%rax
    a968:	0f 83 c2 07 00 00    	jae    b130 <fwp_main_thread+0x1b20>
    a96e:	48 01 c1             	add    %rax,%rcx
    a971:	80 39 01             	cmpb   $0x1,(%rcx)
    a974:	0f 85 b6 07 00 00    	jne    b130 <fwp_main_thread+0x1b20>
    a97a:	48 89 da             	mov    %rbx,%rdx
    a97d:	48 89 dd             	mov    %rbx,%rbp
    a980:	31 ff                	xor    %edi,%edi
    a982:	48 8d 4d 08          	lea    0x8(%rbp),%rcx
    a986:	31 c0                	xor    %eax,%eax
    a988:	4d 85 ed             	test   %r13,%r13
    a98b:	75 2c                	jne    a9b9 <fwp_main_thread+0x13a9>
    a98d:	eb 61                	jmp    a9f0 <fwp_main_thread+0x13e0>
    a98f:	90                   	nop
    a990:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    a994:	0f 88 22 10 00 00    	js     b9bc <fwp_main_thread+0x23ac>
    a99a:	f2 0f 10 05 de 23 00 	movsd  0x23de(%rip),%xmm0        # cd80 <msg.4+0x40>
    a9a1:	00 
    a9a2:	f2 0f 59 04 c6       	mulsd  (%rsi,%rax,8),%xmm0
    a9a7:	48 83 c0 01          	add    $0x1,%rax
    a9ab:	48 83 c1 08          	add    $0x8,%rcx
    a9af:	f2 0f 11 41 f8       	movsd  %xmm0,-0x8(%rcx)
    a9b4:	49 39 c5             	cmp    %rax,%r13
    a9b7:	74 37                	je     a9f0 <fwp_main_thread+0x13e0>
    a9b9:	48 8d 73 08          	lea    0x8(%rbx),%rsi
    a9bd:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    a9c1:	79 cd                	jns    a990 <fwp_main_thread+0x1380>
    a9c3:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    a9c7:	eb c7                	jmp    a990 <fwp_main_thread+0x1380>
    a9c9:	e8 02 a4 ff ff       	call   4dd0 <fwp_heap_init>
    a9ce:	44 8b 1d f3 f1 05 00 	mov    0x5f1f3(%rip),%r11d        # 69bc8 <fwp_heap+0x13a8>
    a9d5:	45 85 db             	test   %r11d,%r11d
    a9d8:	0f 84 78 ec ff ff    	je     9656 <fwp_main_thread+0x46>
    a9de:	48 8d 3d db a2 ff ff 	lea    -0x5d25(%rip),%rdi        # 4cc0 <fwp_heap_report>
    a9e5:	e8 c6 12 00 00       	call   bcb0 <atexit>
    a9ea:	e9 67 ec ff ff       	jmp    9656 <fwp_main_thread+0x46>
    a9ef:	90                   	nop
    a9f0:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    a9f5:	e8 56 d4 ff ff       	call   7e50 <fwp_drop10>
    a9fa:	48 8b 1c 24          	mov    (%rsp),%rbx
    a9fe:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    aa03:	66 90                	xchg   %ax,%ax
    aa05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aa0c:	00 00 00 00 
    aa10:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    aa14:	49 83 c6 01          	add    $0x1,%r14
    aa18:	48 85 db             	test   %rbx,%rbx
    aa1b:	75 f3                	jne    aa10 <fwp_main_thread+0x1400>
    aa1d:	4c 8b 2a             	mov    (%rdx),%r13
    aa20:	4d 85 ed             	test   %r13,%r13
    aa23:	0f 88 27 01 00 00    	js     ab50 <fwp_main_thread+0x1540>
    aa29:	49 8b 8c 24 d8 13 00 	mov    0x13d8(%r12),%rcx
    aa30:	00 
    aa31:	48 89 e8             	mov    %rbp,%rax
    aa34:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    aa3b:	00 
    aa3c:	48 c1 e1 10          	shl    $0x10,%rcx
    aa40:	48 39 c8             	cmp    %rcx,%rax
    aa43:	0f 83 07 01 00 00    	jae    ab50 <fwp_main_thread+0x1540>
    aa49:	48 89 c1             	mov    %rax,%rcx
    aa4c:	48 c1 e9 10          	shr    $0x10,%rcx
    aa50:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    aa54:	49 8b 8c 24 f8 13 00 	mov    0x13f8(%r12),%rcx
    aa5b:	00 
    aa5c:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    aa60:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    aa64:	48 85 f6             	test   %rsi,%rsi
    aa67:	0f 84 e3 00 00 00    	je     ab50 <fwp_main_thread+0x1540>
    aa6d:	0f b6 39             	movzbl (%rcx),%edi
    aa70:	40 80 ff 02          	cmp    $0x2,%dil
    aa74:	0f 84 be 00 00 00    	je     ab38 <fwp_main_thread+0x1528>
    aa7a:	40 80 ff 01          	cmp    $0x1,%dil
    aa7e:	0f 85 cc 00 00 00    	jne    ab50 <fwp_main_thread+0x1540>
    aa84:	8b 79 18             	mov    0x18(%rcx),%edi
    aa87:	0f b7 c0             	movzwl %ax,%eax
    aa8a:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    aa8d:	48 0f af c7          	imul   %rdi,%rax
    aa91:	48 c1 e8 20          	shr    $0x20,%rax
    aa95:	48 39 c8             	cmp    %rcx,%rax
    aa98:	0f 83 b2 00 00 00    	jae    ab50 <fwp_main_thread+0x1540>
    aa9e:	48 01 c6             	add    %rax,%rsi
    aaa1:	80 3e 01             	cmpb   $0x1,(%rsi)
    aaa4:	0f 85 a6 00 00 00    	jne    ab50 <fwp_main_thread+0x1540>
    aaaa:	4d 39 ee             	cmp    %r13,%r14
    aaad:	4c 89 e9             	mov    %r13,%rcx
    aab0:	49 0f 46 ce          	cmovbe %r14,%rcx
    aab4:	48 85 c9             	test   %rcx,%rcx
    aab7:	0f 84 7e 0d 00 00    	je     b83b <fwp_main_thread+0x222b>
    aabd:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
    aac4:	00 
    aac5:	4c 8d 7a 08          	lea    0x8(%rdx),%r15
    aac9:	48 8b 34 24          	mov    (%rsp),%rsi
    aacd:	4c 8d 04 cd 00 00 00 	lea    0x0(,%rcx,8),%r8
    aad4:	00 
    aad5:	31 c0                	xor    %eax,%eax
    aad7:	48 8d 7d 08          	lea    0x8(%rbp),%rdi
    aadb:	eb 45                	jmp    ab22 <fwp_main_thread+0x1512>
    aadd:	66 90                	xchg   %ax,%ax
    aadf:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aae6:	00 00 00 00 
    aaea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aaf1:	00 00 00 00 
    aaf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aafc:	00 00 00 00 
    ab00:	f2 0f 10 46 08       	movsd  0x8(%rsi),%xmm0
    ab05:	f2 41 0f 5c 04 01    	subsd  (%r9,%rax,1),%xmm0
    ab0b:	f2 41 0f 11 04 07    	movsd  %xmm0,(%r15,%rax,1)
    ab11:	48 83 c0 08          	add    $0x8,%rax
    ab15:	48 8b 76 10          	mov    0x10(%rsi),%rsi
    ab19:	49 39 c0             	cmp    %rax,%r8
    ab1c:	0f 84 de 00 00 00    	je     ac00 <fwp_main_thread+0x15f0>
    ab22:	49 89 f9             	mov    %rdi,%r9
    ab25:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    ab29:	79 d5                	jns    ab00 <fwp_main_thread+0x14f0>
    ab2b:	4c 8b 4d 10          	mov    0x10(%rbp),%r9
    ab2f:	eb cf                	jmp    ab00 <fwp_main_thread+0x14f0>
    ab31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab38:	66 85 c0             	test   %ax,%ax
    ab3b:	0f 84 60 ff ff ff    	je     aaa1 <fwp_main_thread+0x1491>
    ab41:	0f 1f 40 00          	nopl   0x0(%rax)
    ab45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ab4c:	00 00 00 00 
    ab50:	48 8b 04 24          	mov    (%rsp),%rax
    ab54:	45 31 f6             	xor    %r14d,%r14d
    ab57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ab5e:	00 00 
    ab60:	48 8b 40 10          	mov    0x10(%rax),%rax
    ab64:	4c 89 f1             	mov    %r14,%rcx
    ab67:	49 83 c6 01          	add    $0x1,%r14
    ab6b:	48 85 c0             	test   %rax,%rax
    ab6e:	75 f0                	jne    ab60 <fwp_main_thread+0x1550>
    ab70:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    ab77:	ff ff 1f 
    ab7a:	4c 39 f0             	cmp    %r14,%rax
    ab7d:	0f 82 4a 0e 00 00    	jb     b9cd <fwp_main_thread+0x23bd>
    ab83:	48 8d 3c cd 10 00 00 	lea    0x10(,%rcx,8),%rdi
    ab8a:	00 
    ab8b:	be 02 00 00 00       	mov    $0x2,%esi
    ab90:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    ab95:	e8 76 b3 ff ff       	call   5f10 <fwp_heap_alloc>
    ab9a:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    ab9f:	49 89 c7             	mov    %rax,%r15
    aba2:	48 89 c1             	mov    %rax,%rcx
    aba5:	48 8b 04 24          	mov    (%rsp),%rax
    aba9:	90                   	nop
    abaa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    abb1:	00 00 00 00 
    abb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    abbc:	00 00 00 00 
    abc0:	48 8b 70 08          	mov    0x8(%rax),%rsi
    abc4:	48 83 c1 08          	add    $0x8,%rcx
    abc8:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    abcc:	48 8b 40 10          	mov    0x10(%rax),%rax
    abd0:	48 85 c0             	test   %rax,%rax
    abd3:	75 eb                	jne    abc0 <fwp_main_thread+0x15b0>
    abd5:	4c 89 e9             	mov    %r13,%rcx
    abd8:	48 0f ba f1 3f       	btr    $0x3f,%rcx
    abdd:	4c 39 f1             	cmp    %r14,%rcx
    abe0:	49 0f 47 ce          	cmova  %r14,%rcx
    abe4:	48 85 c9             	test   %rcx,%rcx
    abe7:	0f 84 85 0b 00 00    	je     b772 <fwp_main_thread+0x2162>
    abed:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
    abf4:	00 
    abf5:	e9 cf fe ff ff       	jmp    aac9 <fwp_main_thread+0x14b9>
    abfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ac00:	4d 8b 84 24 d8 13 00 	mov    0x13d8(%r12),%r8
    ac07:	00 
    ac08:	4d 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%r9
    ac0f:	00 
    ac10:	45 31 f6             	xor    %r14d,%r14d
    ac13:	4d 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%r10
    ac1a:	00 
    ac1b:	48 8b 14 24          	mov    (%rsp),%rdx
    ac1f:	49 c1 e0 10          	shl    $0x10,%r8
    ac23:	eb 15                	jmp    ac3a <fwp_main_thread+0x162a>
    ac25:	0f 1f 00             	nopl   (%rax)
    ac28:	49 83 c6 01          	add    $0x1,%r14
    ac2c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    ac30:	49 39 ce             	cmp    %rcx,%r14
    ac33:	73 5b                	jae    ac90 <fwp_main_thread+0x1680>
    ac35:	48 85 d2             	test   %rdx,%rdx
    ac38:	74 56                	je     ac90 <fwp_main_thread+0x1680>
    ac3a:	48 89 d0             	mov    %rdx,%rax
    ac3d:	4c 29 c8             	sub    %r9,%rax
    ac40:	4c 39 c0             	cmp    %r8,%rax
    ac43:	73 4b                	jae    ac90 <fwp_main_thread+0x1680>
    ac45:	48 89 c6             	mov    %rax,%rsi
    ac48:	48 c1 ee 10          	shr    $0x10,%rsi
    ac4c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    ac50:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    ac54:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    ac58:	48 85 ff             	test   %rdi,%rdi
    ac5b:	74 33                	je     ac90 <fwp_main_thread+0x1680>
    ac5d:	44 0f b6 1e          	movzbl (%rsi),%r11d
    ac61:	41 80 fb 02          	cmp    $0x2,%r11b
    ac65:	0f 84 15 01 00 00    	je     ad80 <fwp_main_thread+0x1770>
    ac6b:	41 80 fb 01          	cmp    $0x1,%r11b
    ac6f:	75 1f                	jne    ac90 <fwp_main_thread+0x1680>
    ac71:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    ac75:	0f b7 c0             	movzwl %ax,%eax
    ac78:	8b 76 1c             	mov    0x1c(%rsi),%esi
    ac7b:	49 0f af c3          	imul   %r11,%rax
    ac7f:	48 c1 e8 20          	shr    $0x20,%rax
    ac83:	48 39 f0             	cmp    %rsi,%rax
    ac86:	73 08                	jae    ac90 <fwp_main_thread+0x1680>
    ac88:	48 01 c7             	add    %rax,%rdi
    ac8b:	80 3f 01             	cmpb   $0x1,(%rdi)
    ac8e:	74 98                	je     ac28 <fwp_main_thread+0x1618>
    ac90:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    ac94:	49 39 ce             	cmp    %rcx,%r14
    ac97:	72 3f                	jb     acd8 <fwp_main_thread+0x16c8>
    ac99:	e9 02 01 00 00       	jmp    ada0 <fwp_main_thread+0x1790>
    ac9e:	66 90                	xchg   %ax,%ax
    aca0:	40 80 fe 01          	cmp    $0x1,%sil
    aca4:	75 25                	jne    accb <fwp_main_thread+0x16bb>
    aca6:	8b 71 18             	mov    0x18(%rcx),%esi
    aca9:	0f b7 c0             	movzwl %ax,%eax
    acac:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    acaf:	48 0f af c6          	imul   %rsi,%rax
    acb3:	48 c1 e8 20          	shr    $0x20,%rax
    acb7:	48 39 c8             	cmp    %rcx,%rax
    acba:	73 0f                	jae    accb <fwp_main_thread+0x16bb>
    acbc:	48 01 c2             	add    %rax,%rdx
    acbf:	80 3a ff             	cmpb   $0xff,(%rdx)
    acc2:	0f 84 18 05 00 00    	je     b1e0 <fwp_main_thread+0x1bd0>
    acc8:	c6 02 01             	movb   $0x1,(%rdx)
    accb:	4d 39 ee             	cmp    %r13,%r14
    acce:	0f 84 8c 00 00 00    	je     ad60 <fwp_main_thread+0x1750>
    acd4:	49 83 ed 01          	sub    $0x1,%r13
    acd8:	f3 43 0f 7e 04 ef    	movq   (%r15,%r13,8),%xmm0
    acde:	66 48 0f 6e f3       	movq   %rbx,%xmm6
    ace3:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    ace8:	bf 01 00 00 00       	mov    $0x1,%edi
    aced:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    acf1:	0f 29 84 24 40 01 00 	movaps %xmm0,0x140(%rsp)
    acf8:	00 
    acf9:	e8 02 b4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    acfe:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    ad05:	00 
    ad06:	48 89 c3             	mov    %rax,%rbx
    ad09:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    ad10:	00 
    ad11:	48 c1 e2 10          	shl    $0x10,%rdx
    ad15:	48 39 d0             	cmp    %rdx,%rax
    ad18:	73 b1                	jae    accb <fwp_main_thread+0x16bb>
    ad1a:	48 89 c2             	mov    %rax,%rdx
    ad1d:	48 c1 ea 10          	shr    $0x10,%rdx
    ad21:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ad25:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    ad2c:	00 
    ad2d:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    ad31:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    ad35:	48 85 d2             	test   %rdx,%rdx
    ad38:	74 91                	je     accb <fwp_main_thread+0x16bb>
    ad3a:	0f b6 31             	movzbl (%rcx),%esi
    ad3d:	40 80 fe 02          	cmp    $0x2,%sil
    ad41:	0f 85 59 ff ff ff    	jne    aca0 <fwp_main_thread+0x1690>
    ad47:	66 85 c0             	test   %ax,%ax
    ad4a:	0f 84 6f ff ff ff    	je     acbf <fwp_main_thread+0x16af>
    ad50:	4d 39 ee             	cmp    %r13,%r14
    ad53:	0f 85 7b ff ff ff    	jne    acd4 <fwp_main_thread+0x16c4>
    ad59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ad60:	4d 85 f6             	test   %r14,%r14
    ad63:	75 3b                	jne    ada0 <fwp_main_thread+0x1790>
    ad65:	8b 44 24 20          	mov    0x20(%rsp),%eax
    ad69:	4c 8b 34 24          	mov    (%rsp),%r14
    ad6d:	85 c0                	test   %eax,%eax
    ad6f:	4c 0f 45 7c 24 10    	cmovne 0x10(%rsp),%r15
    ad75:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
    ad7a:	eb 74                	jmp    adf0 <fwp_main_thread+0x17e0>
    ad7c:	0f 1f 40 00          	nopl   0x0(%rax)
    ad80:	66 85 c0             	test   %ax,%ax
    ad83:	0f 84 02 ff ff ff    	je     ac8b <fwp_main_thread+0x167b>
    ad89:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    ad8d:	49 39 ce             	cmp    %rcx,%r14
    ad90:	0f 82 42 ff ff ff    	jb     acd8 <fwp_main_thread+0x16c8>
    ad96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ad9d:	00 00 00 
    ada0:	4b 8d 34 f7          	lea    (%r15,%r14,8),%rsi
    ada4:	4c 8b 34 24          	mov    (%rsp),%r14
    ada8:	4c 89 f8             	mov    %r15,%rax
    adab:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    adb2:	00 00 00 
    adb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    adbc:	00 00 00 00 
    adc0:	48 8b 10             	mov    (%rax),%rdx
    adc3:	48 83 c0 08          	add    $0x8,%rax
    adc7:	4c 89 f1             	mov    %r14,%rcx
    adca:	49 89 56 08          	mov    %rdx,0x8(%r14)
    adce:	4d 8b 76 10          	mov    0x10(%r14),%r14
    add2:	48 39 f0             	cmp    %rsi,%rax
    add5:	75 e9                	jne    adc0 <fwp_main_thread+0x17b0>
    add7:	8b 54 24 20          	mov    0x20(%rsp),%edx
    addb:	48 89 59 10          	mov    %rbx,0x10(%rcx)
    addf:	48 8b 1c 24          	mov    (%rsp),%rbx
    ade3:	85 d2                	test   %edx,%edx
    ade5:	4c 0f 45 7c 24 10    	cmovne 0x10(%rsp),%r15
    adeb:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
    adf0:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    adf5:	e8 16 ac ff ff       	call   5a10 <fwp_mem_free>
    adfa:	48 89 ef             	mov    %rbp,%rdi
    adfd:	e8 4e d0 ff ff       	call   7e50 <fwp_drop10>
    ae02:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    ae09:	00 
    ae0a:	4c 89 f0             	mov    %r14,%rax
    ae0d:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    ae14:	00 
    ae15:	48 c1 e2 10          	shl    $0x10,%rdx
    ae19:	48 39 d0             	cmp    %rdx,%rax
    ae1c:	73 72                	jae    ae90 <fwp_main_thread+0x1880>
    ae1e:	48 89 c2             	mov    %rax,%rdx
    ae21:	49 8b b4 24 f8 13 00 	mov    0x13f8(%r12),%rsi
    ae28:	00 
    ae29:	48 c1 ea 10          	shr    $0x10,%rdx
    ae2d:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    ae31:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    ae35:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    ae39:	48 85 ed             	test   %rbp,%rbp
    ae3c:	74 52                	je     ae90 <fwp_main_thread+0x1880>
    ae3e:	0f b6 0a             	movzbl (%rdx),%ecx
    ae41:	80 f9 02             	cmp    $0x2,%cl
    ae44:	0f 84 f6 05 00 00    	je     b440 <fwp_main_thread+0x1e30>
    ae4a:	80 f9 01             	cmp    $0x1,%cl
    ae4d:	75 41                	jne    ae90 <fwp_main_thread+0x1880>
    ae4f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ae52:	0f b7 c0             	movzwl %ax,%eax
    ae55:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ae58:	48 0f af c1          	imul   %rcx,%rax
    ae5c:	48 c1 e8 20          	shr    $0x20,%rax
    ae60:	48 39 d0             	cmp    %rdx,%rax
    ae63:	73 2b                	jae    ae90 <fwp_main_thread+0x1880>
    ae65:	48 01 c5             	add    %rax,%rbp
    ae68:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    ae6c:	84 c0                	test   %al,%al
    ae6e:	74 20                	je     ae90 <fwp_main_thread+0x1880>
    ae70:	3c 01                	cmp    $0x1,%al
    ae72:	0f 84 40 06 00 00    	je     b4b8 <fwp_main_thread+0x1ea8>
    ae78:	3c ff                	cmp    $0xff,%al
    ae7a:	0f 84 4d 09 00 00    	je     b7cd <fwp_main_thread+0x21bd>
    ae80:	83 e8 01             	sub    $0x1,%eax
    ae83:	88 45 00             	mov    %al,0x0(%rbp)
    ae86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ae8d:	00 00 00 
    ae90:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    ae95:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ae99:	b9 01 00 00 00       	mov    $0x1,%ecx
    ae9e:	48 89 de             	mov    %rbx,%rsi
    aea1:	48 8d 15 f8 4c 00 00 	lea    0x4cf8(%rip),%rdx        # fba0 <d0>
    aea8:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    aeaf:	00 
    aeb0:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
    aeb7:	00 00 00 00 00 
    aebc:	e8 0f d7 ff ff       	call   85d0 <fwp_write>
    aec1:	4c 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%r14
    aec8:	00 
    aec9:	4c 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%r15
    aed0:	00 
    aed1:	48 8d 05 94 11 00 00 	lea    0x1194(%rip),%rax        # c06c <_IO_stdin_used+0x6c>
    aed8:	4d 85 f6             	test   %r14,%r14
    aedb:	4c 0f 44 f0          	cmove  %rax,%r14
    aedf:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    aee3:	0f 87 a0 0b 00 00    	ja     ba89 <fwp_main_thread+0x2479>
    aee9:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    aeed:	be 01 00 00 00       	mov    $0x1,%esi
    aef2:	e8 19 b0 ff ff       	call   5f10 <fwp_heap_alloc>
    aef7:	4c 89 fa             	mov    %r15,%rdx
    aefa:	4c 89 f6             	mov    %r14,%rsi
    aefd:	4c 89 38             	mov    %r15,(%rax)
    af00:	4c 8d 68 08          	lea    0x8(%rax),%r13
    af04:	48 89 c5             	mov    %rax,%rbp
    af07:	4c 89 ef             	mov    %r13,%rdi
    af0a:	e8 71 86 ff ff       	call   3580 <memcpy@plt>
    af0f:	42 c6 44 3d 08 00    	movb   $0x0,0x8(%rbp,%r15,1)
    af15:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
    af1c:	00 
    af1d:	e8 8e 84 ff ff       	call   33b0 <free@plt>
    af22:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    af29:	00 
    af2a:	48 89 e8             	mov    %rbp,%rax
    af2d:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    af34:	00 
    af35:	48 c1 e2 10          	shl    $0x10,%rdx
    af39:	48 39 d0             	cmp    %rdx,%rax
    af3c:	73 58                	jae    af96 <fwp_main_thread+0x1986>
    af3e:	48 89 c2             	mov    %rax,%rdx
    af41:	48 c1 ea 10          	shr    $0x10,%rdx
    af45:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    af49:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    af50:	00 
    af51:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    af55:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    af59:	4d 85 f6             	test   %r14,%r14
    af5c:	74 38                	je     af96 <fwp_main_thread+0x1986>
    af5e:	0f b6 0a             	movzbl (%rdx),%ecx
    af61:	80 f9 02             	cmp    $0x2,%cl
    af64:	0f 84 36 07 00 00    	je     b6a0 <fwp_main_thread+0x2090>
    af6a:	80 f9 01             	cmp    $0x1,%cl
    af6d:	75 27                	jne    af96 <fwp_main_thread+0x1986>
    af6f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    af72:	0f b7 c0             	movzwl %ax,%eax
    af75:	8b 52 1c             	mov    0x1c(%rdx),%edx
    af78:	48 0f af c1          	imul   %rcx,%rax
    af7c:	48 c1 e8 20          	shr    $0x20,%rax
    af80:	48 39 d0             	cmp    %rdx,%rax
    af83:	73 11                	jae    af96 <fwp_main_thread+0x1986>
    af85:	49 01 c6             	add    %rax,%r14
    af88:	41 80 3e ff          	cmpb   $0xff,(%r14)
    af8c:	0f 84 21 07 00 00    	je     b6b3 <fwp_main_thread+0x20a3>
    af92:	41 c6 06 01          	movb   $0x1,(%r14)
    af96:	48 89 df             	mov    %rbx,%rdi
    af99:	e8 c2 ca ff ff       	call   7a60 <fwp_drop0>
    af9e:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    afa2:	be 01 00 00 00       	mov    $0x1,%esi
    afa7:	4c 89 ef             	mov    %r13,%rdi
    afaa:	48 8b 0d cf f4 05 00 	mov    0x5f4cf(%rip),%rcx        # 6a480 <fwp_prog_out>
    afb1:	e8 aa 86 ff ff       	call   3660 <fwrite@plt>
    afb6:	48 8b 35 c3 f4 05 00 	mov    0x5f4c3(%rip),%rsi        # 6a480 <fwp_prog_out>
    afbd:	bf 0a 00 00 00       	mov    $0xa,%edi
    afc2:	e8 09 85 ff ff       	call   34d0 <fputc@plt>
    afc7:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    afce:	00 
    afcf:	48 89 e8             	mov    %rbp,%rax
    afd2:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    afd9:	00 
    afda:	48 c1 e2 10          	shl    $0x10,%rdx
    afde:	48 39 d0             	cmp    %rdx,%rax
    afe1:	73 6d                	jae    b050 <fwp_main_thread+0x1a40>
    afe3:	48 89 c2             	mov    %rax,%rdx
    afe6:	48 c1 ea 10          	shr    $0x10,%rdx
    afea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    afee:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    aff5:	00 
    aff6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    affa:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    affe:	48 85 db             	test   %rbx,%rbx
    b001:	74 4d                	je     b050 <fwp_main_thread+0x1a40>
    b003:	0f b6 0a             	movzbl (%rdx),%ecx
    b006:	80 f9 02             	cmp    $0x2,%cl
    b009:	0f 84 71 06 00 00    	je     b680 <fwp_main_thread+0x2070>
    b00f:	80 f9 01             	cmp    $0x1,%cl
    b012:	75 3c                	jne    b050 <fwp_main_thread+0x1a40>
    b014:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b017:	0f b7 c0             	movzwl %ax,%eax
    b01a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b01d:	48 0f af c1          	imul   %rcx,%rax
    b021:	48 c1 e8 20          	shr    $0x20,%rax
    b025:	48 39 d0             	cmp    %rdx,%rax
    b028:	73 26                	jae    b050 <fwp_main_thread+0x1a40>
    b02a:	48 01 c3             	add    %rax,%rbx
    b02d:	0f b6 03             	movzbl (%rbx),%eax
    b030:	84 c0                	test   %al,%al
    b032:	74 1c                	je     b050 <fwp_main_thread+0x1a40>
    b034:	3c 01                	cmp    $0x1,%al
    b036:	0f 84 ae 06 00 00    	je     b6ea <fwp_main_thread+0x20da>
    b03c:	3c ff                	cmp    $0xff,%al
    b03e:	0f 84 0c 08 00 00    	je     b850 <fwp_main_thread+0x2240>
    b044:	83 e8 01             	sub    $0x1,%eax
    b047:	88 03                	mov    %al,(%rbx)
    b049:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b050:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    b055:	48 8b 40 10          	mov    0x10(%rax),%rax
    b059:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    b05e:	48 85 c0             	test   %rax,%rax
    b061:	0f 84 36 07 00 00    	je     b79d <fwp_main_thread+0x218d>
    b067:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    b06e:	00 
    b06f:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b076:	00 
    b077:	48 8b 1d 3a f4 05 00 	mov    0x5f43a(%rip),%rbx        # 6a4b8 <fwp_cleanups>
    b07e:	e9 14 f0 ff ff       	jmp    a097 <fwp_main_thread+0xa87>
    b083:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b088:	4d 39 fd             	cmp    %r15,%r13
    b08b:	0f 84 ef f1 ff ff    	je     a280 <fwp_main_thread+0xc70>
    b091:	4c 8b 35 58 50 01 00 	mov    0x15058(%rip),%r14        # 200f0 <fwp_tapes>
    b098:	e9 7c f2 ff ff       	jmp    a319 <fwp_main_thread+0xd09>
    b09d:	0f 1f 00             	nopl   (%rax)
    b0a0:	48 83 3d e0 4f 01 00 	cmpq   $0x0,0x14fe0(%rip)        # 20088 <fwp_tape_cached_bytes>
    b0a7:	00 
    b0a8:	0f 84 b6 f2 ff ff    	je     a364 <fwp_main_thread+0xd54>
    b0ae:	66 0f 6f 0d ea 4f 01 	movdqa 0x14fea(%rip),%xmm1        # 200a0 <fwp_tape_workspace>
    b0b5:	00 
    b0b6:	48 c7 05 c7 4f 01 00 	movq   $0x0,0x14fc7(%rip)        # 20088 <fwp_tape_cached_bytes>
    b0bd:	00 00 00 00 
    b0c1:	41 0f 11 4d 20       	movups %xmm1,0x20(%r13)
    b0c6:	48 8b 05 f3 4f 01 00 	mov    0x14ff3(%rip),%rax        # 200c0 <fwp_tape_workspace+0x20>
    b0cd:	66 0f 6f 0d db 4f 01 	movdqa 0x14fdb(%rip),%xmm1        # 200b0 <fwp_tape_workspace+0x10>
    b0d4:	00 
    b0d5:	49 89 45 40          	mov    %rax,0x40(%r13)
    b0d9:	48 8b 05 e8 4f 01 00 	mov    0x14fe8(%rip),%rax        # 200c8 <fwp_tape_workspace+0x28>
    b0e0:	41 0f 11 4d 30       	movups %xmm1,0x30(%r13)
    b0e5:	66 0f ef c9          	pxor   %xmm1,%xmm1
    b0e9:	49 89 45 18          	mov    %rax,0x18(%r13)
    b0ed:	48 8b 05 dc 4f 01 00 	mov    0x14fdc(%rip),%rax        # 200d0 <fwp_tape_workspace+0x30>
    b0f4:	0f 29 0d a5 4f 01 00 	movaps %xmm1,0x14fa5(%rip)        # 200a0 <fwp_tape_workspace>
    b0fb:	49 89 45 48          	mov    %rax,0x48(%r13)
    b0ff:	0f 29 0d aa 4f 01 00 	movaps %xmm1,0x14faa(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    b106:	48 c7 05 bf 4f 01 00 	movq   $0x0,0x14fbf(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    b10d:	00 00 00 00 
    b111:	0f 29 0d a8 4f 01 00 	movaps %xmm1,0x14fa8(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    b118:	e9 47 f2 ff ff       	jmp    a364 <fwp_main_thread+0xd54>
    b11d:	0f 1f 00             	nopl   (%rax)
    b120:	66 85 c0             	test   %ax,%ax
    b123:	0f 84 48 f8 ff ff    	je     a971 <fwp_main_thread+0x1361>
    b129:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b130:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    b137:	ff ff 1f 
    b13a:	4c 39 e8             	cmp    %r13,%rax
    b13d:	0f 82 e9 08 00 00    	jb     ba2c <fwp_main_thread+0x241c>
    b143:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    b14a:	00 
    b14b:	be 01 00 00 00       	mov    $0x1,%esi
    b150:	e8 bb ad ff ff       	call   5f10 <fwp_heap_alloc>
    b155:	4c 89 28             	mov    %r13,(%rax)
    b158:	49 8b 8c 24 d8 13 00 	mov    0x13d8(%r12),%rcx
    b15f:	00 
    b160:	48 89 c2             	mov    %rax,%rdx
    b163:	48 89 c5             	mov    %rax,%rbp
    b166:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    b16d:	00 
    b16e:	48 c1 e1 10          	shl    $0x10,%rcx
    b172:	48 39 c8             	cmp    %rcx,%rax
    b175:	73 5a                	jae    b1d1 <fwp_main_thread+0x1bc1>
    b177:	48 89 c1             	mov    %rax,%rcx
    b17a:	48 c1 e9 10          	shr    $0x10,%rcx
    b17e:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b182:	49 8b 8c 24 f8 13 00 	mov    0x13f8(%r12),%rcx
    b189:	00 
    b18a:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b18e:	4c 8b 79 20          	mov    0x20(%rcx),%r15
    b192:	4d 85 ff             	test   %r15,%r15
    b195:	74 3a                	je     b1d1 <fwp_main_thread+0x1bc1>
    b197:	0f b6 31             	movzbl (%rcx),%esi
    b19a:	40 80 fe 02          	cmp    $0x2,%sil
    b19e:	0f 84 bc 03 00 00    	je     b560 <fwp_main_thread+0x1f50>
    b1a4:	40 80 fe 01          	cmp    $0x1,%sil
    b1a8:	75 27                	jne    b1d1 <fwp_main_thread+0x1bc1>
    b1aa:	8b 71 18             	mov    0x18(%rcx),%esi
    b1ad:	0f b7 c0             	movzwl %ax,%eax
    b1b0:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b1b3:	48 0f af c6          	imul   %rsi,%rax
    b1b7:	48 c1 e8 20          	shr    $0x20,%rax
    b1bb:	48 39 c8             	cmp    %rcx,%rax
    b1be:	73 11                	jae    b1d1 <fwp_main_thread+0x1bc1>
    b1c0:	49 01 c7             	add    %rax,%r15
    b1c3:	41 80 3f ff          	cmpb   $0xff,(%r15)
    b1c7:	0f 84 a6 03 00 00    	je     b573 <fwp_main_thread+0x1f63>
    b1cd:	41 c6 07 01          	movb   $0x1,(%r15)
    b1d1:	48 89 df             	mov    %rbx,%rdi
    b1d4:	e9 a9 f7 ff ff       	jmp    a982 <fwp_main_thread+0x1372>
    b1d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b1e0:	48 89 d7             	mov    %rdx,%rdi
    b1e3:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    b1e8:	e8 e3 a5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b1ed:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    b1f2:	e9 d1 fa ff ff       	jmp    acc8 <fwp_main_thread+0x16b8>
    b1f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b1fe:	00 00 
    b200:	48 8d 58 ff          	lea    -0x1(%rax),%rbx
    b204:	48 89 df             	mov    %rbx,%rdi
    b207:	48 c1 ef 3c          	shr    $0x3c,%rdi
    b20b:	0f 85 bc 07 00 00    	jne    b9cd <fwp_main_thread+0x23bd>
    b211:	48 85 db             	test   %rbx,%rbx
    b214:	0f 84 66 f3 ff ff    	je     a580 <fwp_main_thread+0xf70>
    b21a:	48 c1 e0 04          	shl    $0x4,%rax
    b21e:	48 01 db             	add    %rbx,%rbx
    b221:	4c 8d 7d 08          	lea    0x8(%rbp),%r15
    b225:	4c 8d 6c 05 f8       	lea    -0x8(%rbp,%rax,1),%r13
    b22a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b230:	f2 41 0f 10 07       	movsd  (%r15),%xmm0
    b235:	49 8b 77 18          	mov    0x18(%r15),%rsi
    b239:	49 83 c7 10          	add    $0x10,%r15
    b23d:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
    b241:	f2 41 0f 10 0f       	movsd  (%r15),%xmm1
    b246:	e8 25 b4 ff ff       	call   6670 <w120>
    b24b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    b250:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    b254:	41 0f 11 47 f0       	movups %xmm0,-0x10(%r15)
    b259:	4d 39 fd             	cmp    %r15,%r13
    b25c:	75 d2                	jne    b230 <fwp_main_thread+0x1c20>
    b25e:	48 89 5d 00          	mov    %rbx,0x0(%rbp)
    b262:	45 31 ed             	xor    %r13d,%r13d
    b265:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    b26c:	0f 1f 40 00          	nopl   0x0(%rax)
    b270:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    b277:	00 f0 3f 
    b27a:	4a 8b 54 ed 10       	mov    0x10(%rbp,%r13,8),%rdx
    b27f:	49 83 c5 02          	add    $0x2,%r13
    b283:	48 89 ce             	mov    %rcx,%rsi
    b286:	e8 65 b0 ff ff       	call   62f0 <fwp_p_ad_push>
    b28b:	48 89 c7             	mov    %rax,%rdi
    b28e:	49 39 dd             	cmp    %rbx,%r13
    b291:	72 dd                	jb     b270 <fwp_main_thread+0x1c60>
    b293:	49 89 c7             	mov    %rax,%r15
    b296:	e9 f5 f2 ff ff       	jmp    a590 <fwp_main_thread+0xf80>
    b29b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b2a0:	48 c1 e2 10          	shl    $0x10,%rdx
    b2a4:	be 02 00 00 00       	mov    $0x2,%esi
    b2a9:	bf 08 00 00 00       	mov    $0x8,%edi
    b2ae:	48 09 ea             	or     %rbp,%rdx
    b2b1:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    b2b6:	e8 55 ac ff ff       	call   5f10 <fwp_heap_alloc>
    b2bb:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    b2c2:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b2c9:	00 
    b2ca:	48 89 c5             	mov    %rax,%rbp
    b2cd:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    b2d4:	00 
    b2d5:	48 c1 e2 10          	shl    $0x10,%rdx
    b2d9:	48 39 d0             	cmp    %rdx,%rax
    b2dc:	0f 83 9e f2 ff ff    	jae    a580 <fwp_main_thread+0xf70>
    b2e2:	48 89 c2             	mov    %rax,%rdx
    b2e5:	48 c1 ea 10          	shr    $0x10,%rdx
    b2e9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b2ed:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    b2f4:	00 
    b2f5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b2f9:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b2fd:	4d 85 ed             	test   %r13,%r13
    b300:	0f 84 6d f2 ff ff    	je     a573 <fwp_main_thread+0xf63>
    b306:	0f b6 0a             	movzbl (%rdx),%ecx
    b309:	31 db                	xor    %ebx,%ebx
    b30b:	80 f9 02             	cmp    $0x2,%cl
    b30e:	0f 85 ba f1 ff ff    	jne    a4ce <fwp_main_thread+0xebe>
    b314:	66 85 c0             	test   %ax,%ax
    b317:	0f 85 df f1 ff ff    	jne    a4fc <fwp_main_thread+0xeec>
    b31d:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b322:	0f 85 cf f1 ff ff    	jne    a4f7 <fwp_main_thread+0xee7>
    b328:	4c 89 ef             	mov    %r13,%rdi
    b32b:	e8 a0 a4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b330:	e9 c2 f1 ff ff       	jmp    a4f7 <fwp_main_thread+0xee7>
    b335:	0f 1f 00             	nopl   (%rax)
    b338:	48 8d 69 01          	lea    0x1(%rcx),%rbp
    b33c:	48 39 eb             	cmp    %rbp,%rbx
    b33f:	7c 32                	jl     b373 <fwp_main_thread+0x1d63>
    b341:	4d 85 c0             	test   %r8,%r8
    b344:	0f 84 9b 06 00 00    	je     b9e5 <fwp_main_thread+0x23d5>
    b34a:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    b34f:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    b356:	00 
    b357:	31 f6                	xor    %esi,%esi
    b359:	4c 89 c7             	mov    %r8,%rdi
    b35c:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
    b361:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    b366:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    b36b:	e9 8a f3 ff ff       	jmp    a6fa <fwp_main_thread+0x10ea>
    b370:	4c 89 cd             	mov    %r9,%rbp
    b373:	48 85 db             	test   %rbx,%rbx
    b376:	48 0f 44 dd          	cmove  %rbp,%rbx
    b37a:	eb 19                	jmp    b395 <fwp_main_thread+0x1d85>
    b37c:	0f 1f 40 00          	nopl   0x0(%rax)
    b380:	48 8d 14 1b          	lea    (%rbx,%rbx,1),%rdx
    b384:	48 81 fb 00 00 00 40 	cmp    $0x40000000,%rbx
    b38b:	48 89 e8             	mov    %rbp,%rax
    b38e:	48 0f 4c c2          	cmovl  %rdx,%rax
    b392:	48 89 c3             	mov    %rax,%rbx
    b395:	48 39 eb             	cmp    %rbp,%rbx
    b398:	7c e6                	jl     b380 <fwp_main_thread+0x1d70>
    b39a:	4d 85 c0             	test   %r8,%r8
    b39d:	0f 84 fd 01 00 00    	je     b5a0 <fwp_main_thread+0x1f90>
    b3a3:	4c 89 c7             	mov    %r8,%rdi
    b3a6:	ba 03 00 00 00       	mov    $0x3,%edx
    b3ab:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    b3b0:	48 8d 34 dd 00 00 00 	lea    0x0(,%rbx,8),%rsi
    b3b7:	00 
    b3b8:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    b3bd:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    b3c2:	e8 c9 9d ff ff       	call   5190 <ad_raw_realloc>
    b3c7:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    b3cc:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    b3d2:	48 85 c0             	test   %rax,%rax
    b3d5:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    b3db:	49 89 c0             	mov    %rax,%r8
    b3de:	0f 84 dc 02 00 00    	je     b6c0 <fwp_main_thread+0x20b0>
    b3e4:	4c 89 84 24 f0 00 00 	mov    %r8,0xf0(%rsp)
    b3eb:	00 
    b3ec:	48 89 9c 24 00 01 00 	mov    %rbx,0x100(%rsp)
    b3f3:	00 
    b3f4:	48 85 ed             	test   %rbp,%rbp
    b3f7:	0f 85 0d 03 00 00    	jne    b70a <fwp_main_thread+0x20fa>
    b3fd:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    b404:	4d 85 ff             	test   %r15,%r15
    b407:	0f 88 1f f3 ff ff    	js     a72c <fwp_main_thread+0x111c>
    b40d:	44 89 f9             	mov    %r15d,%ecx
    b410:	e9 03 f3 ff ff       	jmp    a718 <fwp_main_thread+0x1108>
    b415:	0f 1f 00             	nopl   (%rax)
    b418:	48 8d 3d c1 b9 ff ff 	lea    -0x463f(%rip),%rdi        # 6de0 <fwp_tape_finish>
    b41f:	e8 8c 08 00 00       	call   bcb0 <atexit>
    b424:	85 c0                	test   %eax,%eax
    b426:	0f 85 d2 05 00 00    	jne    b9fe <fwp_main_thread+0x23ee>
    b42c:	c7 05 2a 4c 00 00 01 	movl   $0x1,0x4c2a(%rip)        # 10060 <registered_finish.1>
    b433:	00 00 00 
    b436:	e9 fd ed ff ff       	jmp    a238 <fwp_main_thread+0xc28>
    b43b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b440:	66 85 c0             	test   %ax,%ax
    b443:	0f 85 47 fa ff ff    	jne    ae90 <fwp_main_thread+0x1880>
    b449:	e9 1a fa ff ff       	jmp    ae68 <fwp_main_thread+0x1858>
    b44e:	66 90                	xchg   %ax,%ax
    b450:	66 85 c0             	test   %ax,%ax
    b453:	0f 85 98 ed ff ff    	jne    a1f1 <fwp_main_thread+0xbe1>
    b459:	e9 6b ed ff ff       	jmp    a1c9 <fwp_main_thread+0xbb9>
    b45e:	66 90                	xchg   %ax,%ax
    b460:	49 39 d9             	cmp    %rbx,%r9
    b463:	0f 8f 07 ff ff ff    	jg     b370 <fwp_main_thread+0x1d60>
    b469:	4d 85 c0             	test   %r8,%r8
    b46c:	0f 85 8c 02 00 00    	jne    b6fe <fwp_main_thread+0x20ee>
    b472:	4d 85 c9             	test   %r9,%r9
    b475:	0f 85 6a 05 00 00    	jne    b9e5 <fwp_main_thread+0x23d5>
    b47b:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    b482:	e9 a5 f2 ff ff       	jmp    a72c <fwp_main_thread+0x111c>
    b487:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b48e:	00 00 
    b490:	66 85 c0             	test   %ax,%ax
    b493:	0f 85 28 f4 ff ff    	jne    a8c1 <fwp_main_thread+0x12b1>
    b499:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b49e:	0f 85 18 f4 ff ff    	jne    a8bc <fwp_main_thread+0x12ac>
    b4a4:	4c 89 ef             	mov    %r13,%rdi
    b4a7:	e8 24 a3 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b4ac:	e9 0b f4 ff ff       	jmp    a8bc <fwp_main_thread+0x12ac>
    b4b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b4b8:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    b4bf:	00 
    b4c0:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b4c7:	00 
    b4c8:	4c 89 f0             	mov    %r14,%rax
    b4cb:	49 8b 6e 10          	mov    0x10(%r14),%rbp
    b4cf:	48 29 c8             	sub    %rcx,%rax
    b4d2:	48 c1 e2 10          	shl    $0x10,%rdx
    b4d6:	48 39 d0             	cmp    %rdx,%rax
    b4d9:	73 67                	jae    b542 <fwp_main_thread+0x1f32>
    b4db:	48 89 c7             	mov    %rax,%rdi
    b4de:	48 c1 ef 10          	shr    $0x10,%rdi
    b4e2:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    b4e6:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b4ea:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    b4ee:	48 85 ff             	test   %rdi,%rdi
    b4f1:	74 4f                	je     b542 <fwp_main_thread+0x1f32>
    b4f3:	44 0f b6 06          	movzbl (%rsi),%r8d
    b4f7:	41 80 f8 02          	cmp    $0x2,%r8b
    b4fb:	0f 84 8e 02 00 00    	je     b78f <fwp_main_thread+0x217f>
    b501:	41 80 f8 01          	cmp    $0x1,%r8b
    b505:	75 3b                	jne    b542 <fwp_main_thread+0x1f32>
    b507:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    b50b:	0f b7 c0             	movzwl %ax,%eax
    b50e:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b511:	49 0f af c0          	imul   %r8,%rax
    b515:	48 c1 e8 20          	shr    $0x20,%rax
    b519:	48 39 f0             	cmp    %rsi,%rax
    b51c:	73 24                	jae    b542 <fwp_main_thread+0x1f32>
    b51e:	48 01 c7             	add    %rax,%rdi
    b521:	80 3f 01             	cmpb   $0x1,(%rdi)
    b524:	75 1c                	jne    b542 <fwp_main_thread+0x1f32>
    b526:	4c 89 f7             	mov    %r14,%rdi
    b529:	e8 e2 a4 ff ff       	call   5a10 <fwp_mem_free>
    b52e:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b535:	00 
    b536:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    b53d:	00 
    b53e:	48 c1 e2 10          	shl    $0x10,%rdx
    b542:	48 89 e8             	mov    %rbp,%rax
    b545:	48 29 c8             	sub    %rcx,%rax
    b548:	48 39 d0             	cmp    %rdx,%rax
    b54b:	0f 83 3f f9 ff ff    	jae    ae90 <fwp_main_thread+0x1880>
    b551:	49 89 ee             	mov    %rbp,%r14
    b554:	e9 c5 f8 ff ff       	jmp    ae1e <fwp_main_thread+0x180e>
    b559:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b560:	66 85 c0             	test   %ax,%ax
    b563:	0f 85 68 fc ff ff    	jne    b1d1 <fwp_main_thread+0x1bc1>
    b569:	41 80 3f ff          	cmpb   $0xff,(%r15)
    b56d:	0f 85 5a fc ff ff    	jne    b1cd <fwp_main_thread+0x1bbd>
    b573:	4c 89 ff             	mov    %r15,%rdi
    b576:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    b57b:	e8 50 a2 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b580:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    b585:	e9 43 fc ff ff       	jmp    b1cd <fwp_main_thread+0x1bbd>
    b58a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b590:	48 85 db             	test   %rbx,%rbx
    b593:	0f 85 68 ef ff ff    	jne    a501 <fwp_main_thread+0xef1>
    b599:	e9 e2 ef ff ff       	jmp    a580 <fwp_main_thread+0xf70>
    b59e:	66 90                	xchg   %ax,%ax
    b5a0:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    b5a7:	ff ff 1f 
    b5aa:	48 8d 43 ff          	lea    -0x1(%rbx),%rax
    b5ae:	48 39 c2             	cmp    %rax,%rdx
    b5b1:	0f 82 c6 04 00 00    	jb     ba7d <fwp_main_thread+0x246d>
    b5b7:	48 8d 05 02 4c 04 00 	lea    0x44c02(%rip),%rax        # 501c0 <ad_raw_blocks>
    b5be:	45 31 ed             	xor    %r13d,%r13d
    b5c1:	eb 32                	jmp    b5f5 <fwp_main_thread+0x1fe5>
    b5c3:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b5ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b5d1:	00 00 00 00 
    b5d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b5dc:	00 00 00 00 
    b5e0:	49 83 c5 01          	add    $0x1,%r13
    b5e4:	48 83 c0 18          	add    $0x18,%rax
    b5e8:	49 81 fd 00 10 00 00 	cmp    $0x1000,%r13
    b5ef:	0f 84 f3 02 00 00    	je     b8e8 <fwp_main_thread+0x22d8>
    b5f5:	48 83 38 00          	cmpq   $0x0,(%rax)
    b5f9:	75 e5                	jne    b5e0 <fwp_main_thread+0x1fd0>
    b5fb:	be 08 00 00 00       	mov    $0x8,%esi
    b600:	48 89 df             	mov    %rbx,%rdi
    b603:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    b608:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    b60d:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    b612:	e8 f9 7e ff ff       	call   3510 <calloc@plt>
    b617:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    b61c:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    b622:	48 8d 15 97 4b 04 00 	lea    0x44b97(%rip),%rdx        # 501c0 <ad_raw_blocks>
    b629:	48 85 c0             	test   %rax,%rax
    b62c:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    b632:	0f 84 88 00 00 00    	je     b6c0 <fwp_main_thread+0x20b0>
    b638:	4b 8d 4c 6d 00       	lea    0x0(%r13,%r13,2),%rcx
    b63d:	48 89 c6             	mov    %rax,%rsi
    b640:	4c 89 4c 24 30       	mov    %r9,0x30(%rsp)
    b645:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    b649:	b9 03 00 00 00       	mov    $0x3,%ecx
    b64e:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    b653:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    b65a:	00 
    b65b:	e8 a0 85 ff ff       	call   3c00 <ad_raw_record>
    b660:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
    b665:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    b66a:	e9 75 fd ff ff       	jmp    b3e4 <fwp_main_thread+0x1dd4>
    b66f:	90                   	nop
    b670:	66 85 c0             	test   %ax,%ax
    b673:	0f 85 bc ea ff ff    	jne    a135 <fwp_main_thread+0xb25>
    b679:	e9 7b ea ff ff       	jmp    a0f9 <fwp_main_thread+0xae9>
    b67e:	66 90                	xchg   %ax,%ax
    b680:	66 85 c0             	test   %ax,%ax
    b683:	0f 85 c7 f9 ff ff    	jne    b050 <fwp_main_thread+0x1a40>
    b689:	0f b6 03             	movzbl (%rbx),%eax
    b68c:	84 c0                	test   %al,%al
    b68e:	0f 85 a0 f9 ff ff    	jne    b034 <fwp_main_thread+0x1a24>
    b694:	e9 b7 f9 ff ff       	jmp    b050 <fwp_main_thread+0x1a40>
    b699:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b6a0:	66 85 c0             	test   %ax,%ax
    b6a3:	0f 85 ed f8 ff ff    	jne    af96 <fwp_main_thread+0x1986>
    b6a9:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b6ad:	0f 85 df f8 ff ff    	jne    af92 <fwp_main_thread+0x1982>
    b6b3:	4c 89 f7             	mov    %r14,%rdi
    b6b6:	e8 15 a1 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b6bb:	e9 d2 f8 ff ff       	jmp    af92 <fwp_main_thread+0x1982>
    b6c0:	48 85 ed             	test   %rbp,%rbp
    b6c3:	0f 85 1c 03 00 00    	jne    b9e5 <fwp_main_thread+0x23d5>
    b6c9:	45 31 c0             	xor    %r8d,%r8d
    b6cc:	e9 2c fd ff ff       	jmp    b3fd <fwp_main_thread+0x1ded>
    b6d1:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b6d5:	e9 5f e1 ff ff       	jmp    9839 <fwp_main_thread+0x229>
    b6da:	be 68 00 00 00       	mov    $0x68,%esi
    b6df:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    b6e5:	e9 d1 eb ff ff       	jmp    a2bb <fwp_main_thread+0xcab>
    b6ea:	48 89 ef             	mov    %rbp,%rdi
    b6ed:	e8 1e a3 ff ff       	call   5a10 <fwp_mem_free>
    b6f2:	e9 59 f9 ff ff       	jmp    b050 <fwp_main_thread+0x1a40>
    b6f7:	31 db                	xor    %ebx,%ebx
    b6f9:	e9 fd e1 ff ff       	jmp    98fb <fwp_main_thread+0x2eb>
    b6fe:	4d 85 c9             	test   %r9,%r9
    b701:	0f 84 74 fd ff ff    	je     b47b <fwp_main_thread+0x1e6b>
    b707:	4c 89 cd             	mov    %r9,%rbp
    b70a:	4c 89 c7             	mov    %r8,%rdi
    b70d:	31 f6                	xor    %esi,%esi
    b70f:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    b714:	4c 8d 6d ff          	lea    -0x1(%rbp),%r13
    b718:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    b71f:	00 
    b720:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    b725:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    b72a:	e8 81 7d ff ff       	call   34b0 <memset@plt>
    b72f:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    b734:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    b73a:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    b740:	49 89 c0             	mov    %rax,%r8
    b743:	e9 bc fc ff ff       	jmp    b404 <fwp_main_thread+0x1df4>
    b748:	66 85 c0             	test   %ax,%ax
    b74b:	0f 85 6e e8 ff ff    	jne    9fbf <fwp_main_thread+0x9af>
    b751:	e9 5b e8 ff ff       	jmp    9fb1 <fwp_main_thread+0x9a1>
    b756:	66 85 c0             	test   %ax,%ax
    b759:	0f 85 c3 e7 ff ff    	jne    9f22 <fwp_main_thread+0x912>
    b75f:	e9 b0 e7 ff ff       	jmp    9f14 <fwp_main_thread+0x904>
    b764:	66 85 c0             	test   %ax,%ax
    b767:	0f 85 06 e9 ff ff    	jne    a073 <fwp_main_thread+0xa63>
    b76d:	e9 e5 e8 ff ff       	jmp    a057 <fwp_main_thread+0xa47>
    b772:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
    b777:	4c 8b 34 24          	mov    (%rsp),%r14
    b77b:	31 db                	xor    %ebx,%ebx
    b77d:	e9 6e f6 ff ff       	jmp    adf0 <fwp_main_thread+0x17e0>
    b782:	4c 89 ef             	mov    %r13,%rdi
    b785:	e8 46 a0 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b78a:	e9 52 e6 ff ff       	jmp    9de1 <fwp_main_thread+0x7d1>
    b78f:	66 85 c0             	test   %ax,%ax
    b792:	0f 85 aa fd ff ff    	jne    b542 <fwp_main_thread+0x1f32>
    b798:	e9 84 fd ff ff       	jmp    b521 <fwp_main_thread+0x1f11>
    b79d:	4c 8b 74 24 78       	mov    0x78(%rsp),%r14
    b7a2:	48 8b 3c 24          	mov    (%rsp),%rdi
    b7a6:	e8 b5 c2 ff ff       	call   7a60 <fwp_drop0>
    b7ab:	4c 89 f7             	mov    %r14,%rdi
    b7ae:	e8 ad c2 ff ff       	call   7a60 <fwp_drop0>
    b7b3:	48 c7 05 aa 48 00 00 	movq   $0x0,0x48aa(%rip)        # 10068 <v.2>
    b7ba:	00 00 00 00 
    b7be:	c7 05 a8 48 00 00 01 	movl   $0x1,0x48a8(%rip)        # 10070 <st.3>
    b7c5:	00 00 00 
    b7c8:	e9 b8 df ff ff       	jmp    9785 <fwp_main_thread+0x175>
    b7cd:	48 89 ea             	mov    %rbp,%rdx
    b7d0:	48 c1 ea 11          	shr    $0x11,%rdx
    b7d4:	48 31 ea             	xor    %rbp,%rdx
    b7d7:	48 89 d0             	mov    %rdx,%rax
    b7da:	48 c1 e8 09          	shr    $0x9,%rax
    b7de:	48 31 c2             	xor    %rax,%rdx
    b7e1:	0f b6 d2             	movzbl %dl,%edx
    b7e4:	49 8b 84 d4 48 14 00 	mov    0x1448(%r12,%rdx,8),%rax
    b7eb:	00 
    b7ec:	48 85 c0             	test   %rax,%rax
    b7ef:	75 18                	jne    b809 <fwp_main_thread+0x21f9>
    b7f1:	e9 82 00 00 00       	jmp    b878 <fwp_main_thread+0x2268>
    b7f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b7fd:	00 00 00 
    b800:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b804:	48 85 c0             	test   %rax,%rax
    b807:	74 6f                	je     b878 <fwp_main_thread+0x2268>
    b809:	48 89 c2             	mov    %rax,%rdx
    b80c:	48 3b 28             	cmp    (%rax),%rbp
    b80f:	75 ef                	jne    b800 <fwp_main_thread+0x21f0>
    b811:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b815:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b819:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b81d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b824:	0f 85 66 f6 ff ff    	jne    ae90 <fwp_main_thread+0x1880>
    b82a:	48 89 ef             	mov    %rbp,%rdi
    b82d:	e8 9e 9f ff ff       	call   57d0 <fwp_rc_forget_slot>
    b832:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    b836:	e9 55 f6 ff ff       	jmp    ae90 <fwp_main_thread+0x1880>
    b83b:	4c 8b 34 24          	mov    (%rsp),%r14
    b83f:	31 db                	xor    %ebx,%ebx
    b841:	e9 aa f5 ff ff       	jmp    adf0 <fwp_main_thread+0x17e0>
    b846:	e8 65 9e ff ff       	call   56b0 <fwp_rc_wide_dup>
    b84b:	e9 a1 e9 ff ff       	jmp    a1f1 <fwp_main_thread+0xbe1>
    b850:	48 89 d8             	mov    %rbx,%rax
    b853:	48 c1 e8 11          	shr    $0x11,%rax
    b857:	48 31 d8             	xor    %rbx,%rax
    b85a:	48 89 c2             	mov    %rax,%rdx
    b85d:	48 c1 ea 09          	shr    $0x9,%rdx
    b861:	48 31 d0             	xor    %rdx,%rax
    b864:	0f b6 d0             	movzbl %al,%edx
    b867:	49 8b 84 d4 48 14 00 	mov    0x1448(%r12,%rdx,8),%rax
    b86e:	00 
    b86f:	48 85 c0             	test   %rax,%rax
    b872:	0f 85 b5 00 00 00    	jne    b92d <fwp_main_thread+0x231d>
    b878:	48 8d 3d 71 11 00 00 	lea    0x1171(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    b87f:	e8 cc 8b ff ff       	call   4450 <fwp_trap>
    b884:	48 8b 3d 15 ec 05 00 	mov    0x5ec15(%rip),%rdi        # 6a4a0 <fwp_state>
    b88b:	e8 80 a1 ff ff       	call   5a10 <fwp_mem_free>
    b890:	48 c7 05 05 ec 05 00 	movq   $0x0,0x5ec05(%rip)        # 6a4a0 <fwp_state>
    b897:	00 00 00 00 
    b89b:	48 c7 05 ea eb 05 00 	movq   $0x0,0x5ebea(%rip)        # 6a490 <fwp_state_cap>
    b8a2:	00 00 00 00 
    b8a6:	48 85 db             	test   %rbx,%rbx
    b8a9:	0f 84 e2 00 00 00    	je     b991 <fwp_main_thread+0x2381>
    b8af:	48 3b 1d 42 cf 05 00 	cmp    0x5cf42(%rip),%rbx        # 687f8 <fwp_root>
    b8b6:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    b8bd:	00 00 00 00 
    b8c1:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    b8c8:	00 00 00 00 
    b8cc:	c7 05 aa 47 01 00 00 	movl   $0x0,0x147aa(%rip)        # 20080 <fwp_exit_code>
    b8d3:	00 00 00 
    b8d6:	0f 84 49 e0 ff ff    	je     9925 <fwp_main_thread+0x315>
    b8dc:	e9 6a 7e ff ff       	jmp    374b <fwp_main_thread.cold>
    b8e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b8e8:	48 8d 3d 23 08 00 00 	lea    0x823(%rip),%rdi        # c112 <_IO_stdin_used+0x112>
    b8ef:	e8 0c 87 ff ff       	call   4000 <ad_raw_fail>
    b8f4:	e8 b7 9d ff ff       	call   56b0 <fwp_rc_wide_dup>
    b8f9:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b900:	00 
    b901:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    b908:	00 
    b909:	48 c1 e2 10          	shl    $0x10,%rdx
    b90d:	e9 23 e8 ff ff       	jmp    a135 <fwp_main_thread+0xb25>
    b912:	0f 1f 00             	nopl   (%rax)
    b915:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b91c:	00 00 00 00 
    b920:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b924:	48 85 c0             	test   %rax,%rax
    b927:	0f 84 4b ff ff ff    	je     b878 <fwp_main_thread+0x2268>
    b92d:	48 89 c2             	mov    %rax,%rdx
    b930:	48 39 18             	cmp    %rbx,(%rax)
    b933:	75 eb                	jne    b920 <fwp_main_thread+0x2310>
    b935:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b939:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b93d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b941:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b948:	0f 85 02 f7 ff ff    	jne    b050 <fwp_main_thread+0x1a40>
    b94e:	48 89 df             	mov    %rbx,%rdi
    b951:	e8 7a 9e ff ff       	call   57d0 <fwp_rc_forget_slot>
    b956:	c6 03 fe             	movb   $0xfe,(%rbx)
    b959:	e9 f2 f6 ff ff       	jmp    b050 <fwp_main_thread+0x1a40>
    b95e:	48 8d 3d 5d 08 00 00 	lea    0x85d(%rip),%rdi        # c1c2 <_IO_stdin_used+0x1c2>
    b965:	e8 e6 8a ff ff       	call   4450 <fwp_trap>
    b96a:	48 89 ef             	mov    %rbp,%rdi
    b96d:	e8 5e 9e ff ff       	call   57d0 <fwp_rc_forget_slot>
    b972:	e9 a7 e5 ff ff       	jmp    9f1e <fwp_main_thread+0x90e>
    b977:	48 89 ef             	mov    %rbp,%rdi
    b97a:	e8 51 9e ff ff       	call   57d0 <fwp_rc_forget_slot>
    b97f:	e9 37 e6 ff ff       	jmp    9fbb <fwp_main_thread+0x9ab>
    b984:	48 89 ef             	mov    %rbp,%rdi
    b987:	e8 44 9e ff ff       	call   57d0 <fwp_rc_forget_slot>
    b98c:	e9 d0 e6 ff ff       	jmp    a061 <fwp_main_thread+0xa51>
    b991:	48 83 3d 5f ce 05 00 	cmpq   $0x0,0x5ce5f(%rip)        # 687f8 <fwp_root>
    b998:	00 
    b999:	c7 05 dd 46 01 00 00 	movl   $0x0,0x146dd(%rip)        # 20080 <fwp_exit_code>
    b9a0:	00 00 00 
    b9a3:	0f 84 dd df ff ff    	je     9986 <fwp_main_thread+0x376>
    b9a9:	e9 9d 7d ff ff       	jmp    374b <fwp_main_thread.cold>
    b9ae:	66 90                	xchg   %ax,%ax
    b9b0:	48 8d 3d 61 10 00 00 	lea    0x1061(%rip),%rdi        # ca18 <_IO_stdin_used+0xa18>
    b9b7:	e8 94 8a ff ff       	call   4450 <fwp_trap>
    b9bc:	48 8d 3d 55 11 00 00 	lea    0x1155(%rip),%rdi        # cb18 <_IO_stdin_used+0xb18>
    b9c3:	e8 88 8a ff ff       	call   4450 <fwp_trap>
    b9c8:	e8 33 7d ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    b9cd:	48 8d 3d 17 08 00 00 	lea    0x817(%rip),%rdi        # c1eb <_IO_stdin_used+0x1eb>
    b9d4:	e8 77 8a ff ff       	call   4450 <fwp_trap>
    b9d9:	48 8d 3d b7 08 00 00 	lea    0x8b7(%rip),%rdi        # c297 <_IO_stdin_used+0x297>
    b9e0:	e8 6b 8a ff ff       	call   4450 <fwp_trap>
    b9e5:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    b9ec:	00 
    b9ed:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    b9f2:	48 89 05 bf ea 05 00 	mov    %rax,0x5eabf(%rip)        # 6a4b8 <fwp_cleanups>
    b9f9:	e8 62 98 ff ff       	call   5260 <fwp_tape_buffers_release>
    b9fe:	48 8b 0d 3b 46 00 00 	mov    0x463b(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    ba05:	ba 13 00 00 00       	mov    $0x13,%edx
    ba0a:	be 01 00 00 00       	mov    $0x1,%esi
    ba0f:	48 8d 3d f2 05 00 00 	lea    0x5f2(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    ba16:	e8 45 7c ff ff       	call   3660 <fwrite@plt>
    ba1b:	31 ff                	xor    %edi,%edi
    ba1d:	e8 7e 7b ff ff       	call   35a0 <fflush@plt>
    ba22:	bf 66 00 00 00       	mov    $0x66,%edi
    ba27:	e8 54 7c ff ff       	call   3680 <_Exit@plt>
    ba2c:	48 8d 3d 9a 08 00 00 	lea    0x89a(%rip),%rdi        # c2cd <_IO_stdin_used+0x2cd>
    ba33:	e8 18 8a ff ff       	call   4450 <fwp_trap>
    ba38:	48 8d 3d 81 10 00 00 	lea    0x1081(%rip),%rdi        # cac0 <_IO_stdin_used+0xac0>
    ba3f:	e8 0c 8a ff ff       	call   4450 <fwp_trap>
    ba44:	48 8d 3d 15 10 00 00 	lea    0x1015(%rip),%rdi        # ca60 <_IO_stdin_used+0xa60>
    ba4b:	e8 00 8a ff ff       	call   4450 <fwp_trap>
    ba50:	48 8d 3d 91 10 00 00 	lea    0x1091(%rip),%rdi        # cae8 <_IO_stdin_used+0xae8>
    ba57:	e8 f4 89 ff ff       	call   4450 <fwp_trap>
    ba5c:	0f 1f 40 00          	nopl   0x0(%rax)
    ba60:	48 8d 3d 49 11 00 00 	lea    0x1149(%rip),%rdi        # cbb0 <_IO_stdin_used+0xbb0>
    ba67:	e8 e4 89 ff ff       	call   4450 <fwp_trap>
    ba6c:	48 8d 3d 09 08 00 00 	lea    0x809(%rip),%rdi        # c27c <_IO_stdin_used+0x27c>
    ba73:	e8 88 85 ff ff       	call   4000 <ad_raw_fail>
    ba78:	e8 d3 79 ff ff       	call   3450 <__stack_chk_fail@plt>
    ba7d:	48 8d 3d 2d 08 00 00 	lea    0x82d(%rip),%rdi        # c2b1 <_IO_stdin_used+0x2b1>
    ba84:	e8 77 85 ff ff       	call   4000 <ad_raw_fail>
    ba89:	48 8d 3d 4d 08 00 00 	lea    0x84d(%rip),%rdi        # c2dd <_IO_stdin_used+0x2dd>
    ba90:	e8 bb 89 ff ff       	call   4450 <fwp_trap>
    ba95:	e9 b1 7c ff ff       	jmp    374b <fwp_main_thread.cold>
    ba9a:	e9 ac 7c ff ff       	jmp    374b <fwp_main_thread.cold>
    ba9f:	90                   	nop

000000000000baa0 <__divmodti4>:
    baa0:	f3 0f 1e fa          	endbr64
    baa4:	55                   	push   %rbp
    baa5:	49 89 f1             	mov    %rsi,%r9
    baa8:	49 89 d2             	mov    %rdx,%r10
    baab:	48 89 fe             	mov    %rdi,%rsi
    baae:	49 89 cb             	mov    %rcx,%r11
    bab1:	48 89 e5             	mov    %rsp,%rbp
    bab4:	41 57                	push   %r15
    bab6:	41 56                	push   %r14
    bab8:	41 55                	push   %r13
    baba:	41 54                	push   %r12
    babc:	53                   	push   %rbx
    babd:	4c 89 c3             	mov    %r8,%rbx
    bac0:	45 31 c0             	xor    %r8d,%r8d
    bac3:	4d 85 c9             	test   %r9,%r9
    bac6:	79 12                	jns    bada <__divmodti4+0x3a>
    bac8:	31 ff                	xor    %edi,%edi
    baca:	48 f7 de             	neg    %rsi
    bacd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    bad4:	4c 19 cf             	sbb    %r9,%rdi
    bad7:	49 89 f9             	mov    %rdi,%r9
    bada:	4c 89 d8             	mov    %r11,%rax
    badd:	4d 85 db             	test   %r11,%r11
    bae0:	0f 88 1a 01 00 00    	js     bc00 <__divmodti4+0x160>
    bae6:	4c 89 d9             	mov    %r11,%rcx
    bae9:	49 89 f3             	mov    %rsi,%r11
    baec:	75 62                	jne    bb50 <__divmodti4+0xb0>
    baee:	4d 89 c4             	mov    %r8,%r12
    baf1:	4d 39 d1             	cmp    %r10,%r9
    baf4:	0f 83 46 01 00 00    	jae    bc40 <__divmodti4+0x1a0>
    bafa:	4c 89 d8             	mov    %r11,%rax
    bafd:	4c 89 ca             	mov    %r9,%rdx
    bb00:	49 f7 f2             	div    %r10
    bb03:	49 89 c3             	mov    %rax,%r11
    bb06:	31 c0                	xor    %eax,%eax
    bb08:	48 89 d6             	mov    %rdx,%rsi
    bb0b:	31 ff                	xor    %edi,%edi
    bb0d:	4c 89 d9             	mov    %r11,%rcx
    bb10:	48 89 c2             	mov    %rax,%rdx
    bb13:	48 89 c8             	mov    %rcx,%rax
    bb16:	4d 85 e4             	test   %r12,%r12
    bb19:	74 0a                	je     bb25 <__divmodti4+0x85>
    bb1b:	48 f7 d8             	neg    %rax
    bb1e:	48 83 d2 00          	adc    $0x0,%rdx
    bb22:	48 f7 da             	neg    %rdx
    bb25:	4d 85 c0             	test   %r8,%r8
    bb28:	74 0a                	je     bb34 <__divmodti4+0x94>
    bb2a:	48 f7 de             	neg    %rsi
    bb2d:	48 83 d7 00          	adc    $0x0,%rdi
    bb31:	48 f7 df             	neg    %rdi
    bb34:	48 89 33             	mov    %rsi,(%rbx)
    bb37:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    bb3b:	5b                   	pop    %rbx
    bb3c:	41 5c                	pop    %r12
    bb3e:	41 5d                	pop    %r13
    bb40:	41 5e                	pop    %r14
    bb42:	41 5f                	pop    %r15
    bb44:	5d                   	pop    %rbp
    bb45:	c3                   	ret
    bb46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bb4d:	00 00 00 
    bb50:	4d 89 c4             	mov    %r8,%r12
    bb53:	49 39 c1             	cmp    %rax,%r9
    bb56:	0f 82 ce 00 00 00    	jb     bc2a <__divmodti4+0x18a>
    bb5c:	31 ff                	xor    %edi,%edi
    bb5e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    bb63:	48 63 c7             	movslq %edi,%rax
    bb66:	be 40 00 00 00       	mov    $0x40,%esi
    bb6b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    bb70:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    bb75:	48 29 c6             	sub    %rax,%rsi
    bb78:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    bb7d:	48 09 c8             	or     %rcx,%rax
    bb80:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    bb85:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    bb8a:	49 89 c6             	mov    %rax,%r14
    bb8d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    bb91:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    bb96:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    bb9b:	49 09 c1             	or     %rax,%r9
    bb9e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    bba2:	4c 89 c8             	mov    %r9,%rax
    bba5:	49 f7 f6             	div    %r14
    bba8:	48 89 d1             	mov    %rdx,%rcx
    bbab:	49 89 c3             	mov    %rax,%r11
    bbae:	49 89 c1             	mov    %rax,%r9
    bbb1:	49 f7 e2             	mul    %r10
    bbb4:	49 89 c6             	mov    %rax,%r14
    bbb7:	49 89 d2             	mov    %rdx,%r10
    bbba:	48 39 d1             	cmp    %rdx,%rcx
    bbbd:	72 07                	jb     bbc6 <__divmodti4+0x126>
    bbbf:	75 17                	jne    bbd8 <__divmodti4+0x138>
    bbc1:	49 39 c7             	cmp    %rax,%r15
    bbc4:	73 12                	jae    bbd8 <__divmodti4+0x138>
    bbc6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    bbca:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    bbce:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    bbd2:	49 89 d2             	mov    %rdx,%r10
    bbd5:	49 89 c6             	mov    %rax,%r14
    bbd8:	4c 89 f8             	mov    %r15,%rax
    bbdb:	4c 29 f0             	sub    %r14,%rax
    bbde:	4c 19 d1             	sbb    %r10,%rcx
    bbe1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    bbe6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    bbeb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    bbf0:	48 09 c6             	or     %rax,%rsi
    bbf3:	48 89 cf             	mov    %rcx,%rdi
    bbf6:	31 c0                	xor    %eax,%eax
    bbf8:	4c 89 c9             	mov    %r9,%rcx
    bbfb:	e9 10 ff ff ff       	jmp    bb10 <__divmodti4+0x70>
    bc00:	4c 89 d0             	mov    %r10,%rax
    bc03:	4c 89 da             	mov    %r11,%rdx
    bc06:	4d 89 c4             	mov    %r8,%r12
    bc09:	49 89 f3             	mov    %rsi,%r11
    bc0c:	48 f7 d8             	neg    %rax
    bc0f:	49 f7 d4             	not    %r12
    bc12:	48 83 d2 00          	adc    $0x0,%rdx
    bc16:	49 89 c2             	mov    %rax,%r10
    bc19:	48 f7 da             	neg    %rdx
    bc1c:	48 89 d1             	mov    %rdx,%rcx
    bc1f:	0f 84 cc fe ff ff    	je     baf1 <__divmodti4+0x51>
    bc25:	49 39 d1             	cmp    %rdx,%r9
    bc28:	73 46                	jae    bc70 <__divmodti4+0x1d0>
    bc2a:	4c 89 cf             	mov    %r9,%rdi
    bc2d:	31 c0                	xor    %eax,%eax
    bc2f:	31 c9                	xor    %ecx,%ecx
    bc31:	e9 da fe ff ff       	jmp    bb10 <__divmodti4+0x70>
    bc36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bc3d:	00 00 00 
    bc40:	4d 85 d2             	test   %r10,%r10
    bc43:	75 0d                	jne    bc52 <__divmodti4+0x1b2>
    bc45:	b8 01 00 00 00       	mov    $0x1,%eax
    bc4a:	31 d2                	xor    %edx,%edx
    bc4c:	49 f7 f2             	div    %r10
    bc4f:	49 89 c2             	mov    %rax,%r10
    bc52:	4c 89 c8             	mov    %r9,%rax
    bc55:	31 d2                	xor    %edx,%edx
    bc57:	49 f7 f2             	div    %r10
    bc5a:	49 89 c1             	mov    %rax,%r9
    bc5d:	4c 89 d8             	mov    %r11,%rax
    bc60:	49 f7 f2             	div    %r10
    bc63:	49 89 c3             	mov    %rax,%r11
    bc66:	4c 89 c8             	mov    %r9,%rax
    bc69:	e9 9a fe ff ff       	jmp    bb08 <__divmodti4+0x68>
    bc6e:	66 90                	xchg   %ax,%ax
    bc70:	45 31 f6             	xor    %r14d,%r14d
    bc73:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    bc78:	44 89 f7             	mov    %r14d,%edi
    bc7b:	45 85 f6             	test   %r14d,%r14d
    bc7e:	0f 85 df fe ff ff    	jne    bb63 <__divmodti4+0xc3>
    bc84:	4c 39 ca             	cmp    %r9,%rdx
    bc87:	72 17                	jb     bca0 <__divmodti4+0x200>
    bc89:	31 c9                	xor    %ecx,%ecx
    bc8b:	48 39 c6             	cmp    %rax,%rsi
    bc8e:	73 10                	jae    bca0 <__divmodti4+0x200>
    bc90:	4c 89 cf             	mov    %r9,%rdi
    bc93:	31 c0                	xor    %eax,%eax
    bc95:	e9 76 fe ff ff       	jmp    bb10 <__divmodti4+0x70>
    bc9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bca0:	4c 89 de             	mov    %r11,%rsi
    bca3:	b9 01 00 00 00       	mov    $0x1,%ecx
    bca8:	48 29 c6             	sub    %rax,%rsi
    bcab:	49 19 d1             	sbb    %rdx,%r9
    bcae:	eb e0                	jmp    bc90 <__divmodti4+0x1f0>

000000000000bcb0 <atexit>:
    bcb0:	f3 0f 1e fa          	endbr64
    bcb4:	48 8b 15 4d 43 00 00 	mov    0x434d(%rip),%rdx        # 10008 <__dso_handle>
    bcbb:	31 f6                	xor    %esi,%esi
    bcbd:	e9 7e 79 ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000bcc4 <_fini>:
    bcc4:	f3 0f 1e fa          	endbr64
    bcc8:	48 83 ec 08          	sub    $0x8,%rsp
    bccc:	48 83 c4 08          	add    $0x8,%rsp
    bcd0:	c3                   	ret
