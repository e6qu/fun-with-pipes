
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-reference-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 cf 00 00 	mov    0xcfc1(%rip),%rax        # ffd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da cd 00 00    	push   0xcdda(%rip)        # fe00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc cd 00 00    	jmp    *0xcddc(%rip)        # fe08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 cc 00 00    	jmp    *0xcc46(%rip)        # ffe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # fe10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # fe18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # fe20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # fe28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # fe30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # fe38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # fe40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # fe48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # fe50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # fe58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # fe60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # fe68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # fe70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # fe78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # fe80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # fe88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # fe90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # fe98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # fea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # fea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # feb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # feb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # fec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # fec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # fed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # fed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # fee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # fee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # fef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # fef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ff00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ff08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ff10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ff18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ff20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ff28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ff30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ff38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # ff40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # ff48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # ff50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # ff58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # ff60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e c9 00 00    	jmp    *0xc90e(%rip)        # ff68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 c9 00 00    	jmp    *0xc906(%rip)        # ff70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe c8 00 00    	jmp    *0xc8fe(%rip)        # ff78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 c8 00 00    	jmp    *0xc8f6(%rip)        # ff80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee c8 00 00    	jmp    *0xc8ee(%rip)        # ff88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 c8 00 00    	jmp    *0xc8e6(%rip)        # ff90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de c8 00 00    	jmp    *0xc8de(%rip)        # ff98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 c8 00 00    	jmp    *0xc8d6(%rip)        # ffa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce c8 00 00    	jmp    *0xc8ce(%rip)        # ffa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 c8 00 00    	jmp    *0xc8c6(%rip)        # ffb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be c8 00 00    	jmp    *0xc8be(%rip)        # ffb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd 89 00 00 	lea    0x89dd(%rip),%r9        # c0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da 89 00 00 	lea    0x89da(%rip),%r8        # c0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_main_thread.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <main.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>
    3755:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    375c:	00 00 00 
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 81 ab 00 00 	lea    0xab81(%rip),%rax        # e300 <fwp_fn_table>
    377f:	48 89 05 b2 ec 01 00 	mov    %rax,0x1ecb2(%rip)        # 22438 <fwp_fns>
    3786:	48 8b 05 93 c8 00 00 	mov    0xc893(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ac ec 01 00 	mov    %rax,0x1ecac(%rip)        # 22440 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d b7 8a 00 00 	lea    0x8ab7(%rip),%rdi        # c257 <_IO_stdin_used+0x257>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 c8 00 00 	mov    0xc818(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 ff 59 00 00 	lea    0x59ff(%rip),%rdx        # 9260 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 d6 fe ff ff    	jne    3750 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 ba fe ff ff    	jne    3750 <main.cold>
    3896:	48 8b 3d 83 c7 00 00 	mov    0xc783(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 f8 c7 01 00    	mov    0x1c7f8(%rip),%eax        # 200a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 67 89 00 00 	lea    0x8967(%rip),%rdi        # c260 <_IO_stdin_used+0x260>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 86 91 00 00 	lea    0x9186(%rip),%rdi        # ca90 <_IO_stdin_used+0xa90>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 2f fe ff ff    	jne    3750 <main.cold>
    3921:	48 8d 3d 40 91 00 00 	lea    0x9140(%rip),%rdi        # ca68 <_IO_stdin_used+0xa68>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d 04 91 00 00 	lea    0x9104(%rip),%rdi        # ca38 <_IO_stdin_used+0xa38>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d d0 90 00 00 	lea    0x90d0(%rip),%rdi        # ca10 <_IO_stdin_used+0xa10>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b c6 00 00    	call   *0xc64b(%rip)        # ffc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 c6 00 00 	lea    0xc699(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 c6 00 00 	lea    0xc692(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e c6 00 00 	mov    0xc62e(%rip),%rax        # ffc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 c6 00 00 	lea    0xc669(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 c6 00 00 	lea    0xc662(%rip),%rsi        # 10020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd c5 00 00 	mov    0xc5fd(%rip),%rax        # ffd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d c6 00 00 00 	cmpb   $0x0,0xc64d(%rip)        # 10048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da c5 00 00 	cmpq   $0x0,0xc5da(%rip)        # ffe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 c5 00 00 	mov    0xc5f6(%rip),%rdi        # 10008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 c6 00 00 01 	movb   $0x1,0xc625(%rip)        # 10048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ee c4 01 00 	add    0x1c4ee(%rip),%rdx        # 20110 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 dc c4 01 00 	add    0x1c4dc(%rip),%rax        # 20110 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d c9 e7 01 00 	mov    0x1e7c9(%rip),%rdi        # 22440 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 c3 00 00 	mov    0xc394(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 c3 00 00 	mov    0xc381(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 83 00 00 	lea    0x8345(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 c3 00 00 	mov    0xc372(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 c1 ca 01 00 	mov    0x1cac1(%rip),%rax        # 207c0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 f9 c3 01 00 	mov    0x1c3f9(%rip),%rax        # 20178 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 e5 c3 01 00 	sub    0x1c3e5(%rip),%rax        # 20170 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 ad 8d 00 00 	lea    0x8dad(%rip),%rsi        # cb70 <msg.8>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 87 88 00 00 	lea    0x8887(%rip),%rdi        # c670 <_IO_stdin_used+0x670>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 42 c2 00 00 	mov    0xc242(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d e5 c1 00 00 ff 	cmpl   $0xffffffff,0xc1e5(%rip)        # 10018 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 81 00 00 	lea    0x81e2(%rip),%rax        # c022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d e1 c2 01 00 	mov    0x1c2e1(%rip),%r9        # 20128 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f bd 00 	movq   0xbd9f(%rip),%xmm0        # fbf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 81 00 00 	lea    0x81e7(%rip),%rax        # c044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 bc c2 01 00 	mov    0x1c2bc(%rip),%r8        # 20120 <descent_inputs>
    3e64:	48 8b 0d c5 c2 01 00 	mov    0x1c2c5(%rip),%rcx        # 20130 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d c2 c1 00 00 	mov    0xc1c2(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 81 00 00 	lea    0x81d8(%rip),%rax        # c061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 bd 00 	movq   0xbd67(%rip),%xmm0        # fbf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 20 88 00 00 	lea    0x8820(%rip),%rdx        # c6b8 <_IO_stdin_used+0x6b8>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 91 c2 01 00 	lea    0x1c291(%rip),%r12        # 20140 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 bd 00 	movq   0xbd44(%rip),%xmm0        # fc00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 5b c1 00 00 	mov    0xc15b(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 81 00 00 	lea    0x8175(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 81 00 00 	lea    0x8170(%rip),%rdx        # c06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 20 c1 00 00 	mov    0xc120(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 81 00 00 	lea    0x8144(%rip),%rdi        # c07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d f9 c0 00 00 	mov    0xc0f9(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 81 00 00 	lea    0x8143(%rip),%rcx        # c091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 81 00 00 	lea    0x8119(%rip),%rdx        # c06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 3b dc 01 00 	mov    0x1dc3b(%rip),%rax        # 21bd0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 34 dc 01 00 	lea    0x1dc34(%rip),%r8        # 21bd0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d 15 dc 01 00 	mov    0x1dc15(%rip),%rbx        # 21bb8 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 25 dc 01 00 	mov    0x1dc25(%rip),%rcx        # 21bd8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d c1 db 01 00 	mov    0x1dbc1(%rip),%rdi        # 21bc0 <fwp_heap+0x13e0>
    3fff:	48 29 35 0a dc 01 00 	sub    %rsi,0x1dc0a(%rip)        # 21c10 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 9a db 01 00 	mov    0x1db9a(%rip),%rax        # 21bb0 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 50 db 01 00 	add    0x1db50(%rip),%rdi        # 21b90 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 5e db 01 00 	mov    0x1db5e(%rip),%rsi        # 21bc0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 6c db 01 00 	mov    0x1db6c(%rip),%rax        # 21bd8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 1b db 01 00 	mov    %r12,0x1db1b(%rip)        # 21bc0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d 09 db 01 00 	mov    %rbp,0x1db09(%rip)        # 21bb8 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d ee da 01 00 	cmp    %rdi,0x1daee(%rip)        # 21ba8 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d e5 da 01 00 	mov    %rdi,0x1dae5(%rip)        # 21ba8 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 29 db 01 00 	sub    %rdi,0x1db29(%rip)        # 21c10 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 d1 da 01 00 	mov    0x1dad1(%rip),%rax        # 21bc8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 ca da 01 00 	lea    0x1daca(%rip),%r8        # 21bc8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 5d be 00 00 	mov    0xbe5d(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 7e 00 00 	lea    0x7e14(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d ad bd 00 00 	movslq 0xbdad(%rip),%rbp        # 10018 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 9a be 01 00 	mov    0x1be9a(%rip),%rsi        # 20138 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d 96 be 01 00 	lea    0x1be96(%rip),%rcx        # 20140 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 6b be 01 00 	addq   $0x1,0x1be6b(%rip)        # 20130 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 48 bd 00 00    	mov    %ebx,0xbd48(%rip)        # 10018 <descent_active_phase>
    42d0:	48 89 05 61 be 01 00 	mov    %rax,0x1be61(%rip)        # 20138 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d b9 c4 01 00 	cmp    0x1c4b9(%rip),%rdi        # 207c0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 7f c4 01 00 	mov    0x1c47f(%rip),%rax        # 207a0 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 5d c4 01 00 	mov    %rdi,0x1c45d(%rip)        # 207a0 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 39 c4 01 00 	mov    %rdi,0x1c439(%rip)        # 207a8 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 ee 7d 00 00 	lea    0x7dee(%rip),%rsi        # c19f <_IO_stdin_used+0x19f>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba 7c 00 00 	lea    0x7cba(%rip),%rsi        # c07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 28 bc 00 00 	mov    0xbc28(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 7c 00 00 	lea    0x7c64(%rip),%rdx        # c083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 10 bc 00 00 	mov    0xbc10(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 21 bb 00 00 	mov    0xbb21(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 7a 00 00 	lea    0x7ad8(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 7b 00 00 	lea    0x7b45(%rip),%rdi        # c092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd 7a 00 00 	lea    0x7acd(%rip),%rdi        # c0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d 18 81 00 00 	lea    0x8118(%rip),%rdi        # c708 <_IO_stdin_used+0x708>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 b0 85 00 	movdqa 0x85b0(%rip),%xmm0        # cbc0 <msg.8+0x50>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 ca dd 01 00 	add    0x1ddca(%rip),%rax        # 22438 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 6c 80 00 00 	lea    0x806c(%rip),%rdi        # c730 <_IO_stdin_used+0x730>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 25 ba 01 00 	cmp    %rax,0x1ba25(%rip)        # 20108 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 20 ba 01 00 	add    0x1ba20(%rip),%rax        # 20110 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 55 80 00 00 	lea    0x8055(%rip),%rdi        # c760 <_IO_stdin_used+0x760>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 79 00 00 	lea    0x79a5(%rip),%r8        # c0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa 77 00 00 	lea    0x77fa(%rip),%r8        # c0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 76 00 00 	lea    0x7697(%rip),%r8        # c0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f 74 00 00 	lea    0x746f(%rip),%rdi        # c0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 54 75 00 00 	lea    0x7554(%rip),%rsi        # c1e2 <_IO_stdin_used+0x1e2>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d a5 ce 01 00 	mov    0x1cea5(%rip),%r9        # 21ba8 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 fe ce 01 00 	mov    0x1cefe(%rip),%r8        # 21c08 <fwp_heap+0x1428>
    4d0a:	48 8d 15 9f 7a 00 00 	lea    0x7a9f(%rip),%rdx        # c7b0 <_IO_stdin_used+0x7b0>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d e6 ce 01 00 	mov    0x1cee6(%rip),%rcx        # 21c00 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d f4 ce 01 	movsd  0x1cef4(%rip),%xmm1        # 21c20 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 e4 ce 01 	movsd  0x1cee4(%rip),%xmm0        # 21c18 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 05 b3 00 00 	mov    0xb305(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 58 7e 00 	movdqa 0x7e58(%rip),%xmm0        # cbd0 <msg.8+0x60>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 9f c9 01 00 	lea    0x1c99f(%rip),%rax        # 21720 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 81 7e 00 	movdqa 0x7e81(%rip),%xmm2        # cc10 <msg.8+0xa0>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 45 c9 01 00 	movaps %xmm0,0x1c945(%rip)        # 216e0 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 3d 7e 00 	movdqa 0x7e3d(%rip),%xmm0        # cbe0 <msg.8+0x70>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 d3 cd 01 00 01 	movl   $0x1,0x1cdd3(%rip)        # 21b84 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 33 c9 01 00 	movaps %xmm0,0x1c933(%rip)        # 216f0 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 2b 7e 00 	movdqa 0x7e2b(%rip),%xmm0        # cbf0 <msg.8+0x80>
    4dc4:	00 
    4dc5:	0f 29 05 34 c9 01 00 	movaps %xmm0,0x1c934(%rip)        # 21700 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 2c 7e 00 	movdqa 0x7e2c(%rip),%xmm0        # cc00 <msg.8+0x90>
    4dd3:	00 
    4dd4:	0f 29 05 35 c9 01 00 	movaps %xmm0,0x1c935(%rip)        # 21710 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 b5 b9 01 00 	lea    0x1b9b5(%rip),%r8        # 207e0 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 d0 cc 01 00 	mov    %rax,0x1ccd0(%rip)        # 21b98 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 ae cc 01 00 	mov    %r12,0x1ccae(%rip)        # 21ba0 <fwp_heap+0x13c0>
    4ef2:	48 89 05 97 cc 01 00 	mov    %rax,0x1cc97(%rip)        # 21b90 <fwp_heap+0x13b0>
    4ef9:	48 89 1d b0 cc 01 00 	mov    %rbx,0x1ccb0(%rip)        # 21bb0 <fwp_heap+0x13d0>
    4f00:	48 89 35 d9 cc 01 00 	mov    %rsi,0x1ccd9(%rip)        # 21be0 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 71 00 00 	lea    0x71f9(%rip),%rdi        # c112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 b8 cc 01 00 	mov    %rax,0x1ccb8(%rip)        # 21bd8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 3c cc 01 00    	mov    %eax,0x1cc3c(%rip)        # 21b88 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <caf75>:
    4f60:	8b 15 12 b1 00 00    	mov    0xb112(%rip),%edx        # 10078 <st.4>
    4f66:	85 d2                	test   %edx,%edx
    4f68:	74 0e                	je     4f78 <caf75+0x18>
    4f6a:	48 8b 05 ff b0 00 00 	mov    0xb0ff(%rip),%rax        # 10070 <v.3>
    4f71:	c3                   	ret
    4f72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f78:	8b 05 ea b0 00 00    	mov    0xb0ea(%rip),%eax        # 10068 <st.2>
    4f7e:	85 c0                	test   %eax,%eax
    4f80:	74 1e                	je     4fa0 <caf75+0x40>
    4f82:	48 8b 05 d7 b0 00 00 	mov    0xb0d7(%rip),%rax        # 10060 <v.1>
    4f89:	48 89 05 e0 b0 00 00 	mov    %rax,0xb0e0(%rip)        # 10070 <v.3>
    4f90:	c7 05 de b0 00 00 01 	movl   $0x1,0xb0de(%rip)        # 10078 <st.4>
    4f97:	00 00 00 
    4f9a:	c3                   	ret
    4f9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4fa0:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    4fa7:	00 f0 3f 
    4faa:	c7 05 b4 b0 00 00 01 	movl   $0x1,0xb0b4(%rip)        # 10068 <st.2>
    4fb1:	00 00 00 
    4fb4:	48 89 05 a5 b0 00 00 	mov    %rax,0xb0a5(%rip)        # 10060 <v.1>
    4fbb:	eb cc                	jmp    4f89 <caf75+0x29>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 cc b7 01 00 	mov    0x1b7cc(%rip),%r8        # 207a0 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d fc b6 01 00 	mov    %rbx,0x1b6fc(%rip)        # 207a8 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 e8 b6 01 00 	mov    %r8,0x1b6e8(%rip)        # 207a0 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <fwp_tape_buffers_release>:
    50d0:	f3 0f 1e fa          	endbr64
    50d4:	53                   	push   %rbx
    50d5:	48 89 fb             	mov    %rdi,%rbx
    50d8:	48 83 ec 10          	sub    $0x10,%rsp
    50dc:	48 8b 47 28          	mov    0x28(%rdi),%rax
    50e0:	48 85 c0             	test   %rax,%rax
    50e3:	0f 88 df 00 00 00    	js     51c8 <fwp_tape_buffers_release+0xf8>
    50e9:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    50ed:	48 85 d2             	test   %rdx,%rdx
    50f0:	0f 88 d2 00 00 00    	js     51c8 <fwp_tape_buffers_release+0xf8>
    50f6:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    50fc:	0f 87 c6 00 00 00    	ja     51c8 <fwp_tape_buffers_release+0xf8>
    5102:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5106:	b8 00 00 08 00       	mov    $0x80000,%eax
    510b:	48 c1 e1 03          	shl    $0x3,%rcx
    510f:	48 29 c8             	sub    %rcx,%rax
    5112:	48 c1 e8 03          	shr    $0x3,%rax
    5116:	48 39 d0             	cmp    %rdx,%rax
    5119:	0f 82 a9 00 00 00    	jb     51c8 <fwp_tape_buffers_release+0xf8>
    511f:	48 8d 3d fc 6f 00 00 	lea    0x6ffc(%rip),%rdi        # c122 <_IO_stdin_used+0x122>
    5126:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    512b:	48 89 14 24          	mov    %rdx,(%rsp)
    512f:	e8 6c e2 ff ff       	call   33a0 <getenv@plt>
    5134:	48 8b 14 24          	mov    (%rsp),%rdx
    5138:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    513d:	48 85 c0             	test   %rax,%rax
    5140:	74 09                	je     514b <fwp_tape_buffers_release+0x7b>
    5142:	80 38 30             	cmpb   $0x30,(%rax)
    5145:	0f 84 9d 00 00 00    	je     51e8 <fwp_tape_buffers_release+0x118>
    514b:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    514f:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    5153:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    515a:	77 78                	ja     51d4 <fwp_tape_buffers_release+0x104>
    515c:	48 8d 3d 5d af 01 00 	lea    0x1af5d(%rip),%rdi        # 200c0 <fwp_tape_workspace>
    5163:	48 89 04 24          	mov    %rax,(%rsp)
    5167:	e8 a4 ef ff ff       	call   4110 <fwp_tape_buffers_dispose>
    516c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5170:	48 8b 04 24          	mov    (%rsp),%rax
    5174:	0f 29 05 45 af 01 00 	movaps %xmm0,0x1af45(%rip)        # 200c0 <fwp_tape_workspace>
    517b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5180:	48 89 05 21 af 01 00 	mov    %rax,0x1af21(%rip)        # 200a8 <fwp_tape_cached_bytes>
    5187:	0f 29 05 42 af 01 00 	movaps %xmm0,0x1af42(%rip)        # 200d0 <fwp_tape_workspace+0x10>
    518e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5193:	0f 29 05 46 af 01 00 	movaps %xmm0,0x1af46(%rip)        # 200e0 <fwp_tape_workspace+0x20>
    519a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    519e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    51a2:	48 89 15 47 af 01 00 	mov    %rdx,0x1af47(%rip)        # 200f0 <fwp_tape_workspace+0x30>
    51a9:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    51b0:	00 
    51b1:	0f 11 03             	movups %xmm0,(%rbx)
    51b4:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    51b8:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    51bc:	48 83 c4 10          	add    $0x10,%rsp
    51c0:	5b                   	pop    %rbx
    51c1:	c3                   	ret
    51c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    51c8:	48 8d 3d 53 6f 00 00 	lea    0x6f53(%rip),%rdi        # c122 <_IO_stdin_used+0x122>
    51cf:	e8 cc e1 ff ff       	call   33a0 <getenv@plt>
    51d4:	48 83 c4 10          	add    $0x10,%rsp
    51d8:	48 89 df             	mov    %rbx,%rdi
    51db:	5b                   	pop    %rbx
    51dc:	e9 2f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    51e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e8:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    51ec:	0f 85 59 ff ff ff    	jne    514b <fwp_tape_buffers_release+0x7b>
    51f2:	48 83 c4 10          	add    $0x10,%rsp
    51f6:	48 89 df             	mov    %rbx,%rdi
    51f9:	5b                   	pop    %rbx
    51fa:	e9 11 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    51ff:	90                   	nop

0000000000005200 <fwp_poll_events>:
    5200:	53                   	push   %rbx
    5201:	48 83 ec 20          	sub    $0x20,%rsp
    5205:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    520c:	00 00 
    520e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5213:	31 c0                	xor    %eax,%eax
    5215:	e8 46 f3 ff ff       	call   4560 <fwp_now_ns>
    521a:	48 8b 1d 77 b5 01 00 	mov    0x1b577(%rip),%rbx        # 20798 <fwp_timers>
    5221:	48 85 db             	test   %rbx,%rbx
    5224:	0f 84 d6 00 00 00    	je     5300 <fwp_poll_events+0x100>
    522a:	48 89 c6             	mov    %rax,%rsi
    522d:	48 89 da             	mov    %rbx,%rdx
    5230:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5237:	eb 16                	jmp    524f <fwp_poll_events+0x4f>
    5239:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5240:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5247:	48 89 c8             	mov    %rcx,%rax
    524a:	48 85 d2             	test   %rdx,%rdx
    524d:	74 31                	je     5280 <fwp_poll_events+0x80>
    524f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5253:	48 85 c0             	test   %rax,%rax
    5256:	78 e8                	js     5240 <fwp_poll_events+0x40>
    5258:	48 39 c1             	cmp    %rax,%rcx
    525b:	7c e3                	jl     5240 <fwp_poll_events+0x40>
    525d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5264:	48 85 d2             	test   %rdx,%rdx
    5267:	74 1c                	je     5285 <fwp_poll_events+0x85>
    5269:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    526d:	48 39 c1             	cmp    %rax,%rcx
    5270:	7c ce                	jl     5240 <fwp_poll_events+0x40>
    5272:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5279:	48 85 d2             	test   %rdx,%rdx
    527c:	75 d1                	jne    524f <fwp_poll_events+0x4f>
    527e:	66 90                	xchg   %ax,%ax
    5280:	48 85 c0             	test   %rax,%rax
    5283:	78 7b                	js     5300 <fwp_poll_events+0x100>
    5285:	48 29 f0             	sub    %rsi,%rax
    5288:	48 89 c1             	mov    %rax,%rcx
    528b:	48 85 c0             	test   %rax,%rax
    528e:	0f 8e 9c 00 00 00    	jle    5330 <fwp_poll_events+0x130>
    5294:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    529b:	de 1b 43 
    529e:	48 f7 ea             	imul   %rdx
    52a1:	48 89 c8             	mov    %rcx,%rax
    52a4:	48 c1 f8 3f          	sar    $0x3f,%rax
    52a8:	48 c1 fa 12          	sar    $0x12,%rdx
    52ac:	48 29 c2             	sub    %rax,%rdx
    52af:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    52b6:	48 39 c1             	cmp    %rax,%rcx
    52b9:	0f 95 c0             	setne  %al
    52bc:	0f b6 c0             	movzbl %al,%eax
    52bf:	48 01 d0             	add    %rdx,%rax
    52c2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    52c8:	0f 8f 32 01 00 00    	jg     5400 <fwp_poll_events+0x200>
    52ce:	48 85 c0             	test   %rax,%rax
    52d1:	74 5d                	je     5330 <fwp_poll_events+0x130>
    52d3:	89 c1                	mov    %eax,%ecx
    52d5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    52dc:	48 c1 e9 26          	shr    $0x26,%rcx
    52e0:	48 63 d1             	movslq %ecx,%rdx
    52e3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    52e9:	29 c8                	sub    %ecx,%eax
    52eb:	48 98                	cltq
    52ed:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    52f4:	e9 11 01 00 00       	jmp    540a <fwp_poll_events+0x20a>
    52f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5300:	e8 6b e9 ff ff       	call   3c70 <fwp_flush>
    5305:	ba 2b 00 00 00       	mov    $0x2b,%edx
    530a:	be 01 00 00 00       	mov    $0x1,%esi
    530f:	48 8b 0d 2a ad 00 00 	mov    0xad2a(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    5316:	48 8d 3d 1b 75 00 00 	lea    0x751b(%rip),%rdi        # c838 <_IO_stdin_used+0x838>
    531d:	e8 5e e3 ff ff       	call   3680 <fwrite@plt>
    5322:	bf 65 00 00 00       	mov    $0x65,%edi
    5327:	e8 44 e3 ff ff       	call   3670 <exit@plt>
    532c:	0f 1f 40 00          	nopl   0x0(%rax)
    5330:	e8 2b f2 ff ff       	call   4560 <fwp_now_ns>
    5335:	48 89 c1             	mov    %rax,%rcx
    5338:	66 0f ef c0          	pxor   %xmm0,%xmm0
    533c:	eb 44                	jmp    5382 <fwp_poll_events+0x182>
    533e:	66 90                	xchg   %ax,%ax
    5340:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5344:	75 33                	jne    5379 <fwp_poll_events+0x179>
    5346:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    534a:	75 2d                	jne    5379 <fwp_poll_events+0x179>
    534c:	48 8b 05 4d b4 01 00 	mov    0x1b44d(%rip),%rax        # 207a0 <fwp_ready_tail>
    5353:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5357:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    535e:	00 00 00 00 
    5362:	48 85 c0             	test   %rax,%rax
    5365:	0f 84 05 01 00 00    	je     5470 <fwp_poll_events+0x270>
    536b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5372:	48 89 15 27 b4 01 00 	mov    %rdx,0x1b427(%rip)        # 207a0 <fwp_ready_tail>
    5379:	48 85 db             	test   %rbx,%rbx
    537c:	0f 84 be 00 00 00    	je     5440 <fwp_poll_events+0x240>
    5382:	48 89 da             	mov    %rbx,%rdx
    5385:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    538c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5390:	7f e7                	jg     5379 <fwp_poll_events+0x179>
    5392:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5396:	74 2e                	je     53c6 <fwp_poll_events+0x1c6>
    5398:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    539f:	48 85 c0             	test   %rax,%rax
    53a2:	0f 84 b8 00 00 00    	je     5460 <fwp_poll_events+0x260>
    53a8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    53af:	48 85 db             	test   %rbx,%rbx
    53b2:	74 07                	je     53bb <fwp_poll_events+0x1bb>
    53b4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    53bb:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    53bf:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    53c6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    53ca:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    53ce:	48 85 c0             	test   %rax,%rax
    53d1:	0f 84 69 ff ff ff    	je     5340 <fwp_poll_events+0x140>
    53d7:	48 39 c8             	cmp    %rcx,%rax
    53da:	0f 8f 60 ff ff ff    	jg     5340 <fwp_poll_events+0x140>
    53e0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    53e4:	0f 85 56 ff ff ff    	jne    5340 <fwp_poll_events+0x140>
    53ea:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    53ee:	75 89                	jne    5379 <fwp_poll_events+0x179>
    53f0:	48 89 d7             	mov    %rdx,%rdi
    53f3:	e8 08 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    53f8:	e9 43 ff ff ff       	jmp    5340 <fwp_poll_events+0x140>
    53fd:	0f 1f 00             	nopl   (%rax)
    5400:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5405:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    540a:	48 89 e7             	mov    %rsp,%rdi
    540d:	31 f6                	xor    %esi,%esi
    540f:	48 89 14 24          	mov    %rdx,(%rsp)
    5413:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5418:	e8 83 e0 ff ff       	call   34a0 <nanosleep@plt>
    541d:	48 8b 1d 74 b3 01 00 	mov    0x1b374(%rip),%rbx        # 20798 <fwp_timers>
    5424:	e8 37 f1 ff ff       	call   4560 <fwp_now_ns>
    5429:	48 89 c1             	mov    %rax,%rcx
    542c:	48 85 db             	test   %rbx,%rbx
    542f:	0f 85 03 ff ff ff    	jne    5338 <fwp_poll_events+0x138>
    5435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    543c:	00 00 00 00 
    5440:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5445:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    544c:	00 00 
    544e:	75 2c                	jne    547c <fwp_poll_events+0x27c>
    5450:	48 83 c4 20          	add    $0x20,%rsp
    5454:	5b                   	pop    %rbx
    5455:	c3                   	ret
    5456:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    545d:	00 00 00 
    5460:	48 89 1d 31 b3 01 00 	mov    %rbx,0x1b331(%rip)        # 20798 <fwp_timers>
    5467:	e9 43 ff ff ff       	jmp    53af <fwp_poll_events+0x1af>
    546c:	0f 1f 40 00          	nopl   0x0(%rax)
    5470:	48 89 15 31 b3 01 00 	mov    %rdx,0x1b331(%rip)        # 207a8 <fwp_ready_head>
    5477:	e9 f6 fe ff ff       	jmp    5372 <fwp_poll_events+0x172>
    547c:	e8 df df ff ff       	call   3460 <__stack_chk_fail@plt>
    5481:	0f 1f 40 00          	nopl   0x0(%rax)
    5485:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    548c:	00 00 00 00 

0000000000005490 <fwp_rc_wide_dup>:
    5490:	48 89 fa             	mov    %rdi,%rdx
    5493:	48 8d 35 46 b3 01 00 	lea    0x1b346(%rip),%rsi        # 207e0 <fwp_heap>
    549a:	48 83 ec 18          	sub    $0x18,%rsp
    549e:	48 89 f9             	mov    %rdi,%rcx
    54a1:	48 c1 ea 11          	shr    $0x11,%rdx
    54a5:	48 31 fa             	xor    %rdi,%rdx
    54a8:	48 89 d0             	mov    %rdx,%rax
    54ab:	48 c1 e8 09          	shr    $0x9,%rax
    54af:	48 31 c2             	xor    %rax,%rdx
    54b2:	0f b6 d2             	movzbl %dl,%edx
    54b5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    54bc:	00 
    54bd:	49 8b 00             	mov    (%r8),%rax
    54c0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    54c7:	00 00 
    54c9:	75 21                	jne    54ec <fwp_rc_wide_dup+0x5c>
    54cb:	e9 98 00 00 00       	jmp    5568 <fwp_rc_wide_dup+0xd8>
    54d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    54d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    54dc:	00 00 00 00 
    54e0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    54e4:	48 85 d2             	test   %rdx,%rdx
    54e7:	74 2f                	je     5518 <fwp_rc_wide_dup+0x88>
    54e9:	48 89 d0             	mov    %rdx,%rax
    54ec:	48 3b 08             	cmp    (%rax),%rcx
    54ef:	75 ef                	jne    54e0 <fwp_rc_wide_dup+0x50>
    54f1:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54f4:	74 7c                	je     5572 <fwp_rc_wide_dup+0xe2>
    54f6:	48 8b 50 08          	mov    0x8(%rax),%rdx
    54fa:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    54fe:	0f 84 91 00 00 00    	je     5595 <fwp_rc_wide_dup+0x105>
    5504:	48 83 c2 01          	add    $0x1,%rdx
    5508:	48 89 50 08          	mov    %rdx,0x8(%rax)
    550c:	48 83 c4 18          	add    $0x18,%rsp
    5510:	c3                   	ret
    5511:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5518:	4c 8d 40 10          	lea    0x10(%rax),%r8
    551c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    551f:	75 68                	jne    5589 <fwp_rc_wide_dup+0xf9>
    5521:	bf 18 00 00 00       	mov    $0x18,%edi
    5526:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    552b:	4c 89 04 24          	mov    %r8,(%rsp)
    552f:	e8 7c e0 ff ff       	call   35b0 <malloc@plt>
    5534:	4c 8b 04 24          	mov    (%rsp),%r8
    5538:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    553d:	48 85 c0             	test   %rax,%rax
    5540:	74 5f                	je     55a1 <fwp_rc_wide_dup+0x111>
    5542:	48 89 08             	mov    %rcx,(%rax)
    5545:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    554c:	00 
    554d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5554:	00 
    5555:	49 89 00             	mov    %rax,(%r8)
    5558:	c6 01 ff             	movb   $0xff,(%rcx)
    555b:	48 83 05 c5 ce 01 00 	addq   $0x1,0x1cec5(%rip)        # 22428 <fwp_heap+0x1c48>
    5562:	01 
    5563:	48 83 c4 18          	add    $0x18,%rsp
    5567:	c3                   	ret
    5568:	80 3f fe             	cmpb   $0xfe,(%rdi)
    556b:	75 13                	jne    5580 <fwp_rc_wide_dup+0xf0>
    556d:	48 85 c0             	test   %rax,%rax
    5570:	74 af                	je     5521 <fwp_rc_wide_dup+0x91>
    5572:	48 8d 3d ef 72 00 00 	lea    0x72ef(%rip),%rdi        # c868 <_IO_stdin_used+0x868>
    5579:	e8 72 ee ff ff       	call   43f0 <fwp_trap>
    557e:	66 90                	xchg   %ax,%ax
    5580:	48 85 c0             	test   %rax,%rax
    5583:	0f 85 6d ff ff ff    	jne    54f6 <fwp_rc_wide_dup+0x66>
    5589:	48 8d 3d 00 73 00 00 	lea    0x7300(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    5590:	e8 5b ee ff ff       	call   43f0 <fwp_trap>
    5595:	48 8d 3d 97 6b 00 00 	lea    0x6b97(%rip),%rdi        # c133 <_IO_stdin_used+0x133>
    559c:	e8 4f ee ff ff       	call   43f0 <fwp_trap>
    55a1:	e8 0a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    55a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    55ad:	00 00 00 

00000000000055b0 <fwp_rc_forget_slot>:
    55b0:	80 3f ff             	cmpb   $0xff,(%rdi)
    55b3:	74 0b                	je     55c0 <fwp_rc_forget_slot+0x10>
    55b5:	c3                   	ret
    55b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    55bd:	00 00 00 
    55c0:	48 89 f8             	mov    %rdi,%rax
    55c3:	48 83 ec 08          	sub    $0x8,%rsp
    55c7:	48 89 fa             	mov    %rdi,%rdx
    55ca:	48 c1 e8 11          	shr    $0x11,%rax
    55ce:	48 31 f8             	xor    %rdi,%rax
    55d1:	48 89 c1             	mov    %rax,%rcx
    55d4:	48 c1 e9 09          	shr    $0x9,%rcx
    55d8:	48 31 c8             	xor    %rcx,%rax
    55db:	48 8d 0d fe b1 01 00 	lea    0x1b1fe(%rip),%rcx        # 207e0 <fwp_heap>
    55e2:	0f b6 c0             	movzbl %al,%eax
    55e5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    55ec:	00 
    55ed:	48 85 ff             	test   %rdi,%rdi
    55f0:	74 3c                	je     562e <fwp_rc_forget_slot+0x7e>
    55f2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    55f9:	00 
    55fa:	48 8b 01             	mov    (%rcx),%rax
    55fd:	eb 11                	jmp    5610 <fwp_rc_forget_slot+0x60>
    55ff:	90                   	nop
    5600:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5604:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5608:	48 85 ff             	test   %rdi,%rdi
    560b:	74 21                	je     562e <fwp_rc_forget_slot+0x7e>
    560d:	48 89 f8             	mov    %rdi,%rax
    5610:	48 3b 10             	cmp    (%rax),%rdx
    5613:	75 eb                	jne    5600 <fwp_rc_forget_slot+0x50>
    5615:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5619:	48 89 01             	mov    %rax,(%rcx)
    561c:	e8 9f dd ff ff       	call   33c0 <free@plt>
    5621:	48 83 2d ff cd 01 00 	subq   $0x1,0x1cdff(%rip)        # 22428 <fwp_heap+0x1c48>
    5628:	01 
    5629:	48 83 c4 08          	add    $0x8,%rsp
    562d:	c3                   	ret
    562e:	48 8d 3d 5b 72 00 00 	lea    0x725b(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    5635:	e8 b6 ed ff ff       	call   43f0 <fwp_trap>
    563a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005640 <fwp_rc_prepare_chunk>:
    5640:	48 83 3d e0 cd 01 00 	cmpq   $0x0,0x1cde0(%rip)        # 22428 <fwp_heap+0x1c48>
    5647:	00 
    5648:	41 54                	push   %r12
    564a:	49 89 f4             	mov    %rsi,%r12
    564d:	55                   	push   %rbp
    564e:	48 89 fd             	mov    %rdi,%rbp
    5651:	53                   	push   %rbx
    5652:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5655:	0f 84 7d 00 00 00    	je     56d8 <fwp_rc_prepare_chunk+0x98>
    565b:	31 db                	xor    %ebx,%ebx
    565d:	85 c0                	test   %eax,%eax
    565f:	75 5f                	jne    56c0 <fwp_rc_prepare_chunk+0x80>
    5661:	48 85 f6             	test   %rsi,%rsi
    5664:	74 7c                	je     56e2 <fwp_rc_prepare_chunk+0xa2>
    5666:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    566a:	e8 51 dd ff ff       	call   33c0 <free@plt>
    566f:	90                   	nop
    5670:	be 01 00 00 00       	mov    $0x1,%esi
    5675:	4c 89 e7             	mov    %r12,%rdi
    5678:	e8 a3 de ff ff       	call   3520 <calloc@plt>
    567d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5681:	48 85 c0             	test   %rax,%rax
    5684:	0f 85 87 00 00 00    	jne    5711 <fwp_rc_prepare_chunk+0xd1>
    568a:	e8 21 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    568f:	90                   	nop
    5690:	e8 1b ff ff ff       	call   55b0 <fwp_rc_forget_slot>
    5695:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5698:	48 83 c3 01          	add    $0x1,%rbx
    569c:	48 39 c3             	cmp    %rax,%rbx
    569f:	73 37                	jae    56d8 <fwp_rc_prepare_chunk+0x98>
    56a1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    56a8:	00 00 
    56aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56b1:	00 00 00 00 
    56b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56bc:	00 00 00 00 
    56c0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56c4:	48 01 df             	add    %rbx,%rdi
    56c7:	80 3f ff             	cmpb   $0xff,(%rdi)
    56ca:	74 c4                	je     5690 <fwp_rc_prepare_chunk+0x50>
    56cc:	8b 45 1c             	mov    0x1c(%rbp),%eax
    56cf:	48 83 c3 01          	add    $0x1,%rbx
    56d3:	48 39 c3             	cmp    %rax,%rbx
    56d6:	72 e8                	jb     56c0 <fwp_rc_prepare_chunk+0x80>
    56d8:	49 39 c4             	cmp    %rax,%r12
    56db:	75 13                	jne    56f0 <fwp_rc_prepare_chunk+0xb0>
    56dd:	4d 85 e4             	test   %r12,%r12
    56e0:	75 46                	jne    5728 <fwp_rc_prepare_chunk+0xe8>
    56e2:	5b                   	pop    %rbx
    56e3:	5d                   	pop    %rbp
    56e4:	41 5c                	pop    %r12
    56e6:	c3                   	ret
    56e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    56ee:	00 00 
    56f0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56f4:	48 29 05 35 cd 01 00 	sub    %rax,0x1cd35(%rip)        # 22430 <fwp_heap+0x1c50>
    56fb:	e8 c0 dc ff ff       	call   33c0 <free@plt>
    5700:	4d 85 e4             	test   %r12,%r12
    5703:	0f 85 67 ff ff ff    	jne    5670 <fwp_rc_prepare_chunk+0x30>
    5709:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5710:	00 
    5711:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5715:	5b                   	pop    %rbx
    5716:	4c 01 25 13 cd 01 00 	add    %r12,0x1cd13(%rip)        # 22430 <fwp_heap+0x1c50>
    571d:	5d                   	pop    %rbp
    571e:	41 5c                	pop    %r12
    5720:	c3                   	ret
    5721:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5728:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    572c:	5b                   	pop    %rbx
    572d:	4c 89 e2             	mov    %r12,%rdx
    5730:	31 f6                	xor    %esi,%esi
    5732:	5d                   	pop    %rbp
    5733:	41 5c                	pop    %r12
    5735:	e9 86 dd ff ff       	jmp    34c0 <memset@plt>
    573a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005740 <fwp_heap_refill>:
    5740:	41 56                	push   %r14
    5742:	41 89 d6             	mov    %edx,%r14d
    5745:	41 55                	push   %r13
    5747:	41 89 f5             	mov    %esi,%r13d
    574a:	41 54                	push   %r12
    574c:	49 89 fc             	mov    %rdi,%r12
    574f:	bf 01 00 00 00       	mov    $0x1,%edi
    5754:	55                   	push   %rbp
    5755:	53                   	push   %rbx
    5756:	e8 25 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    575b:	48 89 c3             	mov    %rax,%rbx
    575e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5762:	48 8b 05 6f c4 01 00 	mov    0x1c46f(%rip),%rax        # 21bd8 <fwp_heap+0x13f8>
    5769:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    576d:	48 8d 05 6c b0 01 00 	lea    0x1b06c(%rip),%rax        # 207e0 <fwp_heap>
    5774:	31 d2                	xor    %edx,%edx
    5776:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    577a:	48 89 ef             	mov    %rbp,%rdi
    577d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5781:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5785:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    578c:	00 
    578d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5792:	f7 f1                	div    %ecx
    5794:	31 d2                	xor    %edx,%edx
    5796:	66 0f 6e c1          	movd   %ecx,%xmm0
    579a:	66 0f 6e c8          	movd   %eax,%xmm1
    579e:	89 c6                	mov    %eax,%esi
    57a0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    57a5:	48 01 c8             	add    %rcx,%rax
    57a8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    57ac:	48 f7 f1             	div    %rcx
    57af:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    57b4:	89 45 18             	mov    %eax,0x18(%rbp)
    57b7:	e8 84 fe ff ff       	call   5640 <fwp_rc_prepare_chunk>
    57bc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    57bf:	48 89 d8             	mov    %rbx,%rax
    57c2:	48 c1 e0 10          	shl    $0x10,%rax
    57c6:	48 03 05 c3 c3 01 00 	add    0x1c3c3(%rip),%rax        # 21b90 <fwp_heap+0x13b0>
    57cd:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    57d1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    57d6:	8b 55 08             	mov    0x8(%rbp),%edx
    57d9:	48 0f af d1          	imul   %rcx,%rdx
    57dd:	48 01 c2             	add    %rax,%rdx
    57e0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    57e5:	5b                   	pop    %rbx
    57e6:	5d                   	pop    %rbp
    57e7:	41 5c                	pop    %r12
    57e9:	41 5d                	pop    %r13
    57eb:	41 5e                	pop    %r14
    57ed:	c3                   	ret
    57ee:	66 90                	xchg   %ax,%ax

00000000000057f0 <fwp_mem_free>:
    57f0:	48 85 ff             	test   %rdi,%rdi
    57f3:	0f 84 17 02 00 00    	je     5a10 <fwp_mem_free+0x220>
    57f9:	48 8b 35 90 c3 01 00 	mov    0x1c390(%rip),%rsi        # 21b90 <fwp_heap+0x13b0>
    5800:	48 8b 05 b1 c3 01 00 	mov    0x1c3b1(%rip),%rax        # 21bb8 <fwp_heap+0x13d8>
    5807:	48 89 fa             	mov    %rdi,%rdx
    580a:	48 29 f2             	sub    %rsi,%rdx
    580d:	48 c1 e0 10          	shl    $0x10,%rax
    5811:	48 39 c2             	cmp    %rax,%rdx
    5814:	0f 83 f6 01 00 00    	jae    5a10 <fwp_mem_free+0x220>
    581a:	49 89 d1             	mov    %rdx,%r9
    581d:	49 c1 e9 10          	shr    $0x10,%r9
    5821:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5825:	48 c1 e0 03          	shl    $0x3,%rax
    5829:	49 89 c0             	mov    %rax,%r8
    582c:	4c 03 05 a5 c3 01 00 	add    0x1c3a5(%rip),%r8        # 21bd8 <fwp_heap+0x13f8>
    5833:	0f 84 d7 01 00 00    	je     5a10 <fwp_mem_free+0x220>
    5839:	48 83 ec 38          	sub    $0x38,%rsp
    583d:	48 89 f9             	mov    %rdi,%rcx
    5840:	41 0f b6 38          	movzbl (%r8),%edi
    5844:	40 80 ff 01          	cmp    $0x1,%dil
    5848:	74 16                	je     5860 <fwp_mem_free+0x70>
    584a:	40 80 ff 02          	cmp    $0x2,%dil
    584e:	0f 84 94 00 00 00    	je     58e8 <fwp_mem_free+0xf8>
    5854:	48 83 c4 38          	add    $0x38,%rsp
    5858:	c3                   	ret
    5859:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5860:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5864:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5869:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    586e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5872:	4d 85 d2             	test   %r10,%r10
    5875:	74 1d                	je     5894 <fwp_mem_free+0xa4>
    5877:	0f b7 c1             	movzwl %cx,%eax
    587a:	31 d2                	xor    %edx,%edx
    587c:	48 f7 f7             	div    %rdi
    587f:	49 01 c2             	add    %rax,%r10
    5882:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5886:	0f 84 44 01 00 00    	je     59d0 <fwp_mem_free+0x1e0>
    588c:	41 c6 02 00          	movb   $0x0,(%r10)
    5890:	41 8b 78 04          	mov    0x4(%r8),%edi
    5894:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    589b:	49 63 c1             	movslq %r9d,%rax
    589e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    58a6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    58ab:	f2 0f 58 05 6d c3 01 	addsd  0x1c36d(%rip),%xmm0        # 21c20 <fwp_heap+0x1440>
    58b2:	00 
    58b3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    58b7:	48 8d 05 22 af 01 00 	lea    0x1af22(%rip),%rax        # 207e0 <fwp_heap>
    58be:	48 01 d0             	add    %rdx,%rax
    58c1:	48 8b 10             	mov    (%rax),%rdx
    58c4:	48 f7 d2             	not    %rdx
    58c7:	48 89 11             	mov    %rdx,(%rcx)
    58ca:	48 89 08             	mov    %rcx,(%rax)
    58cd:	48 29 3d 2c c3 01 00 	sub    %rdi,0x1c32c(%rip)        # 21c00 <fwp_heap+0x1420>
    58d4:	f2 0f 11 05 44 c3 01 	movsd  %xmm0,0x1c344(%rip)        # 21c20 <fwp_heap+0x1440>
    58db:	00 
    58dc:	48 83 c4 38          	add    $0x38,%rsp
    58e0:	c3                   	ret
    58e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    58e8:	66 31 d2             	xor    %dx,%dx
    58eb:	48 01 d6             	add    %rdx,%rsi
    58ee:	48 39 f1             	cmp    %rsi,%rcx
    58f1:	0f 85 5d ff ff ff    	jne    5854 <fwp_mem_free+0x64>
    58f7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    58fb:	48 29 15 fe c2 01 00 	sub    %rdx,0x1c2fe(%rip)        # 21c00 <fwp_heap+0x1420>
    5902:	48 85 d2             	test   %rdx,%rdx
    5905:	0f 88 a5 00 00 00    	js     59b0 <fwp_mem_free+0x1c0>
    590b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    590f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5914:	f2 0f 58 05 04 c3 01 	addsd  0x1c304(%rip),%xmm0        # 21c20 <fwp_heap+0x1440>
    591b:	00 
    591c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5920:	f2 0f 11 05 f8 c2 01 	movsd  %xmm0,0x1c2f8(%rip)        # 21c20 <fwp_heap+0x1440>
    5927:	00 
    5928:	48 85 d2             	test   %rdx,%rdx
    592b:	74 0c                	je     5939 <fwp_mem_free+0x149>
    592d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5930:	0f 84 db 00 00 00    	je     5a11 <fwp_mem_free+0x221>
    5936:	c6 02 00             	movb   $0x0,(%rdx)
    5939:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    593d:	48 85 c9             	test   %rcx,%rcx
    5940:	74 3e                	je     5980 <fwp_mem_free+0x190>
    5942:	48 8b 15 8f c2 01 00 	mov    0x1c28f(%rip),%rdx        # 21bd8 <fwp_heap+0x13f8>
    5949:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    594d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5951:	48 01 d0             	add    %rdx,%rax
    5954:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5958:	48 89 d6             	mov    %rdx,%rsi
    595b:	48 29 c6             	sub    %rax,%rsi
    595e:	83 e6 08             	and    $0x8,%esi
    5961:	74 0d                	je     5970 <fwp_mem_free+0x180>
    5963:	c6 00 00             	movb   $0x0,(%rax)
    5966:	48 83 c0 28          	add    $0x28,%rax
    596a:	48 39 c2             	cmp    %rax,%rdx
    596d:	74 11                	je     5980 <fwp_mem_free+0x190>
    596f:	90                   	nop
    5970:	c6 00 00             	movb   $0x0,(%rax)
    5973:	48 83 c0 50          	add    $0x50,%rax
    5977:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    597b:	48 39 c2             	cmp    %rax,%rdx
    597e:	75 f0                	jne    5970 <fwp_mem_free+0x180>
    5980:	48 01 0d 89 c2 01 00 	add    %rcx,0x1c289(%rip)        # 21c10 <fwp_heap+0x1430>
    5987:	4c 3b 0d 42 c2 01 00 	cmp    0x1c242(%rip),%r9        # 21bd0 <fwp_heap+0x13f0>
    598e:	73 07                	jae    5997 <fwp_mem_free+0x1a7>
    5990:	4c 89 0d 39 c2 01 00 	mov    %r9,0x1c239(%rip)        # 21bd0 <fwp_heap+0x13f0>
    5997:	4c 3b 0d 2a c2 01 00 	cmp    0x1c22a(%rip),%r9        # 21bc8 <fwp_heap+0x13e8>
    599e:	0f 83 b0 fe ff ff    	jae    5854 <fwp_mem_free+0x64>
    59a4:	4c 89 0d 1d c2 01 00 	mov    %r9,0x1c21d(%rip)        # 21bc8 <fwp_heap+0x13e8>
    59ab:	e9 a4 fe ff ff       	jmp    5854 <fwp_mem_free+0x64>
    59b0:	48 89 d1             	mov    %rdx,%rcx
    59b3:	83 e2 01             	and    $0x1,%edx
    59b6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    59ba:	48 d1 e9             	shr    $1,%rcx
    59bd:	48 09 d1             	or     %rdx,%rcx
    59c0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    59c5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    59c9:	e9 46 ff ff ff       	jmp    5914 <fwp_mem_free+0x124>
    59ce:	66 90                	xchg   %ax,%ax
    59d0:	4c 89 d7             	mov    %r10,%rdi
    59d3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    59d8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    59dd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    59e2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    59e6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    59eb:	e8 c0 fb ff ff       	call   55b0 <fwp_rc_forget_slot>
    59f0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    59f5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    59fa:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    59ff:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5a04:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5a09:	e9 7e fe ff ff       	jmp    588c <fwp_mem_free+0x9c>
    5a0e:	66 90                	xchg   %ax,%ax
    5a10:	c3                   	ret
    5a11:	48 89 d7             	mov    %rdx,%rdi
    5a14:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5a19:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5a1e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5a23:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5a28:	e8 83 fb ff ff       	call   55b0 <fwp_rc_forget_slot>
    5a2d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5a32:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5a37:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5a3c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5a41:	e9 f0 fe ff ff       	jmp    5936 <fwp_mem_free+0x146>
    5a46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5a4d:	00 00 00 

0000000000005a50 <fwp_heap_alloc_big>:
    5a50:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5a57:	00 00 40 
    5a5a:	41 57                	push   %r15
    5a5c:	41 56                	push   %r14
    5a5e:	41 55                	push   %r13
    5a60:	41 54                	push   %r12
    5a62:	55                   	push   %rbp
    5a63:	53                   	push   %rbx
    5a64:	48 83 ec 08          	sub    $0x8,%rsp
    5a68:	48 39 f8             	cmp    %rdi,%rax
    5a6b:	0f 82 fa 00 00 00    	jb     5b6b <fwp_heap_alloc_big+0x11b>
    5a71:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a78:	49 89 fd             	mov    %rdi,%r13
    5a7b:	41 89 f6             	mov    %esi,%r14d
    5a7e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a82:	48 89 ef             	mov    %rbp,%rdi
    5a85:	e8 f6 e4 ff ff       	call   3f80 <fwp_heap_chunks>
    5a8a:	be 01 00 00 00       	mov    $0x1,%esi
    5a8f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a93:	49 89 c4             	mov    %rax,%r12
    5a96:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a9d:	00 
    5a9e:	48 03 3d 33 c1 01 00 	add    0x1c133(%rip),%rdi        # 21bd8 <fwp_heap+0x13f8>
    5aa5:	c6 07 02             	movb   $0x2,(%rdi)
    5aa8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5aac:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5aaf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5ab3:	e8 88 fb ff ff       	call   5640 <fwp_rc_prepare_chunk>
    5ab8:	48 83 fd 01          	cmp    $0x1,%rbp
    5abc:	76 47                	jbe    5b05 <fwp_heap_alloc_big+0xb5>
    5abe:	4c 01 e5             	add    %r12,%rbp
    5ac1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ac8:	00 
    5ac9:	4c 8d 3d 10 ad 01 00 	lea    0x1ad10(%rip),%r15        # 207e0 <fwp_heap>
    5ad0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5ad5:	49 c1 e6 03          	shl    $0x3,%r14
    5ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ae0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5ae7:	31 f6                	xor    %esi,%esi
    5ae9:	48 01 dd             	add    %rbx,%rbp
    5aec:	48 83 c3 28          	add    $0x28,%rbx
    5af0:	48 89 ef             	mov    %rbp,%rdi
    5af3:	e8 48 fb ff ff       	call   5640 <fwp_rc_prepare_chunk>
    5af8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5afc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5b00:	49 39 de             	cmp    %rbx,%r14
    5b03:	75 db                	jne    5ae0 <fwp_heap_alloc_big+0x90>
    5b05:	49 c1 e4 10          	shl    $0x10,%r12
    5b09:	4c 03 25 80 c0 01 00 	add    0x1c080(%rip),%r12        # 21b90 <fwp_heap+0x13b0>
    5b10:	4c 89 ea             	mov    %r13,%rdx
    5b13:	31 f6                	xor    %esi,%esi
    5b15:	4c 89 e7             	mov    %r12,%rdi
    5b18:	e8 a3 d9 ff ff       	call   34c0 <memset@plt>
    5b1d:	4c 89 e8             	mov    %r13,%rax
    5b20:	48 03 05 d9 c0 01 00 	add    0x1c0d9(%rip),%rax        # 21c00 <fwp_heap+0x1420>
    5b27:	72 42                	jb     5b6b <fwp_heap_alloc_big+0x11b>
    5b29:	48 39 05 d8 c0 01 00 	cmp    %rax,0x1c0d8(%rip)        # 21c08 <fwp_heap+0x1428>
    5b30:	48 89 05 c9 c0 01 00 	mov    %rax,0x1c0c9(%rip)        # 21c00 <fwp_heap+0x1420>
    5b37:	73 07                	jae    5b40 <fwp_heap_alloc_big+0xf0>
    5b39:	48 89 05 c8 c0 01 00 	mov    %rax,0x1c0c8(%rip)        # 21c08 <fwp_heap+0x1428>
    5b40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b44:	4c 89 e0             	mov    %r12,%rax
    5b47:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5b4c:	f2 0f 58 05 c4 c0 01 	addsd  0x1c0c4(%rip),%xmm0        # 21c18 <fwp_heap+0x1438>
    5b53:	00 
    5b54:	f2 0f 11 05 bc c0 01 	movsd  %xmm0,0x1c0bc(%rip)        # 21c18 <fwp_heap+0x1438>
    5b5b:	00 
    5b5c:	48 83 c4 08          	add    $0x8,%rsp
    5b60:	5b                   	pop    %rbx
    5b61:	5d                   	pop    %rbp
    5b62:	41 5c                	pop    %r12
    5b64:	41 5d                	pop    %r13
    5b66:	41 5e                	pop    %r14
    5b68:	41 5f                	pop    %r15
    5b6a:	c3                   	ret
    5b6b:	e8 40 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b70 <fwp_heap_alloc_slow>:
    5b70:	53                   	push   %rbx
    5b71:	48 89 f9             	mov    %rdi,%rcx
    5b74:	41 89 f1             	mov    %esi,%r9d
    5b77:	48 83 ec 10          	sub    $0x10,%rsp
    5b7b:	8b 05 03 c0 01 00    	mov    0x1c003(%rip),%eax        # 21b84 <fwp_heap+0x13a4>
    5b81:	85 c0                	test   %eax,%eax
    5b83:	0f 84 c7 00 00 00    	je     5c50 <fwp_heap_alloc_slow+0xe0>
    5b89:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b90:	0f 87 dd 00 00 00    	ja     5c73 <fwp_heap_alloc_slow+0x103>
    5b96:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b9a:	48 8d 3d 3f ac 01 00 	lea    0x1ac3f(%rip),%rdi        # 207e0 <fwp_heap>
    5ba1:	49 63 f1             	movslq %r9d,%rsi
    5ba4:	48 c1 e8 04          	shr    $0x4,%rax
    5ba8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5baf:	00 00 
    5bb1:	41 0f b6 c2          	movzbl %r10b,%eax
    5bb5:	4c 89 d2             	mov    %r10,%rdx
    5bb8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5bbc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5bc3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5bca:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5bce:	48 01 f8             	add    %rdi,%rax
    5bd1:	4c 8b 00             	mov    (%rax),%r8
    5bd4:	4d 85 c0             	test   %r8,%r8
    5bd7:	0f 84 ab 00 00 00    	je     5c88 <fwp_heap_alloc_slow+0x118>
    5bdd:	49 8b 10             	mov    (%r8),%rdx
    5be0:	48 f7 d2             	not    %rdx
    5be3:	48 89 10             	mov    %rdx,(%rax)
    5be6:	41 83 f9 01          	cmp    $0x1,%r9d
    5bea:	4c 89 c7             	mov    %r8,%rdi
    5bed:	48 0f 45 cb          	cmovne %rbx,%rcx
    5bf1:	31 f6                	xor    %esi,%esi
    5bf3:	48 89 ca             	mov    %rcx,%rdx
    5bf6:	e8 c5 d8 ff ff       	call   34c0 <memset@plt>
    5bfb:	49 89 c0             	mov    %rax,%r8
    5bfe:	48 89 d8             	mov    %rbx,%rax
    5c01:	48 03 05 f8 bf 01 00 	add    0x1bff8(%rip),%rax        # 21c00 <fwp_heap+0x1420>
    5c08:	0f 82 d9 00 00 00    	jb     5ce7 <fwp_heap_alloc_slow+0x177>
    5c0e:	48 39 05 f3 bf 01 00 	cmp    %rax,0x1bff3(%rip)        # 21c08 <fwp_heap+0x1428>
    5c15:	48 89 05 e4 bf 01 00 	mov    %rax,0x1bfe4(%rip)        # 21c00 <fwp_heap+0x1420>
    5c1c:	73 07                	jae    5c25 <fwp_heap_alloc_slow+0xb5>
    5c1e:	48 89 05 e3 bf 01 00 	mov    %rax,0x1bfe3(%rip)        # 21c08 <fwp_heap+0x1428>
    5c25:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c29:	4c 89 c0             	mov    %r8,%rax
    5c2c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5c31:	f2 0f 58 05 df bf 01 	addsd  0x1bfdf(%rip),%xmm0        # 21c18 <fwp_heap+0x1438>
    5c38:	00 
    5c39:	f2 0f 11 05 d7 bf 01 	movsd  %xmm0,0x1bfd7(%rip)        # 21c18 <fwp_heap+0x1438>
    5c40:	00 
    5c41:	48 83 c4 10          	add    $0x10,%rsp
    5c45:	5b                   	pop    %rbx
    5c46:	c3                   	ret
    5c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5c4e:	00 00 
    5c50:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5c54:	48 89 3c 24          	mov    %rdi,(%rsp)
    5c58:	e8 13 f1 ff ff       	call   4d70 <fwp_heap_init>
    5c5d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c61:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c66:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c6d:	0f 86 23 ff ff ff    	jbe    5b96 <fwp_heap_alloc_slow+0x26>
    5c73:	48 83 c4 10          	add    $0x10,%rsp
    5c77:	44 89 ce             	mov    %r9d,%esi
    5c7a:	48 89 cf             	mov    %rcx,%rdi
    5c7d:	5b                   	pop    %rbx
    5c7e:	e9 cd fd ff ff       	jmp    5a50 <fwp_heap_alloc_big>
    5c83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c88:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c8c:	4d 85 c0             	test   %r8,%r8
    5c8f:	74 1f                	je     5cb0 <fwp_heap_alloc_slow+0x140>
    5c91:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c95:	4d 29 c3             	sub    %r8,%r11
    5c98:	49 39 db             	cmp    %rbx,%r11
    5c9b:	72 13                	jb     5cb0 <fwp_heap_alloc_slow+0x140>
    5c9d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ca1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ca5:	e9 3c ff ff ff       	jmp    5be6 <fwp_heap_alloc_slow+0x76>
    5caa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5cb0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5cb7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5cbb:	44 89 ca             	mov    %r9d,%edx
    5cbe:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5cc3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5cc7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5ccb:	44 89 d6             	mov    %r10d,%esi
    5cce:	48 01 c7             	add    %rax,%rdi
    5cd1:	e8 6a fa ff ff       	call   5740 <fwp_heap_refill>
    5cd6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5cdb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5cdf:	49 89 c0             	mov    %rax,%r8
    5ce2:	e9 ff fe ff ff       	jmp    5be6 <fwp_heap_alloc_slow+0x76>
    5ce7:	e8 c4 df ff ff       	call   3cb0 <fwp_heap_oom>
    5cec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005cf0 <fwp_heap_alloc>:
    5cf0:	8b 05 8e be 01 00    	mov    0x1be8e(%rip),%eax        # 21b84 <fwp_heap+0x13a4>
    5cf6:	48 89 fa             	mov    %rdi,%rdx
    5cf9:	89 f7                	mov    %esi,%edi
    5cfb:	85 c0                	test   %eax,%eax
    5cfd:	0f 84 f5 00 00 00    	je     5df8 <fwp_heap_alloc+0x108>
    5d03:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5d0a:	0f 87 e8 00 00 00    	ja     5df8 <fwp_heap_alloc+0x108>
    5d10:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5d14:	48 8d 05 c5 aa 01 00 	lea    0x1aac5(%rip),%rax        # 207e0 <fwp_heap>
    5d1b:	48 83 ec 18          	sub    $0x18,%rsp
    5d1f:	41 89 f0             	mov    %esi,%r8d
    5d22:	48 c1 e9 04          	shr    $0x4,%rcx
    5d26:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5d2d:	00 
    5d2e:	48 63 cf             	movslq %edi,%rcx
    5d31:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5d38:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5d3f:	00 
    5d40:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5d44:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5d48:	48 01 c8             	add    %rcx,%rax
    5d4b:	48 8b 08             	mov    (%rax),%rcx
    5d4e:	48 85 c9             	test   %rcx,%rcx
    5d51:	74 6d                	je     5dc0 <fwp_heap_alloc+0xd0>
    5d53:	48 8b 31             	mov    (%rcx),%rsi
    5d56:	48 f7 d6             	not    %rsi
    5d59:	48 89 30             	mov    %rsi,(%rax)
    5d5c:	41 83 f8 01          	cmp    $0x1,%r8d
    5d60:	48 89 cf             	mov    %rcx,%rdi
    5d63:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d68:	49 0f 45 d1          	cmovne %r9,%rdx
    5d6c:	31 f6                	xor    %esi,%esi
    5d6e:	e8 4d d7 ff ff       	call   34c0 <memset@plt>
    5d73:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d78:	48 89 c1             	mov    %rax,%rcx
    5d7b:	4c 89 c8             	mov    %r9,%rax
    5d7e:	48 03 05 7b be 01 00 	add    0x1be7b(%rip),%rax        # 21c00 <fwp_heap+0x1420>
    5d85:	72 7b                	jb     5e02 <fwp_heap_alloc+0x112>
    5d87:	48 39 05 7a be 01 00 	cmp    %rax,0x1be7a(%rip)        # 21c08 <fwp_heap+0x1428>
    5d8e:	48 89 05 6b be 01 00 	mov    %rax,0x1be6b(%rip)        # 21c00 <fwp_heap+0x1420>
    5d95:	73 07                	jae    5d9e <fwp_heap_alloc+0xae>
    5d97:	48 89 05 6a be 01 00 	mov    %rax,0x1be6a(%rip)        # 21c08 <fwp_heap+0x1428>
    5d9e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5da2:	48 89 c8             	mov    %rcx,%rax
    5da5:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5daa:	f2 0f 58 05 66 be 01 	addsd  0x1be66(%rip),%xmm0        # 21c18 <fwp_heap+0x1438>
    5db1:	00 
    5db2:	f2 0f 11 05 5e be 01 	movsd  %xmm0,0x1be5e(%rip)        # 21c18 <fwp_heap+0x1438>
    5db9:	00 
    5dba:	48 83 c4 18          	add    $0x18,%rsp
    5dbe:	c3                   	ret
    5dbf:	90                   	nop
    5dc0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5dc4:	48 85 c9             	test   %rcx,%rcx
    5dc7:	74 0c                	je     5dd5 <fwp_heap_alloc+0xe5>
    5dc9:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5dcd:	48 29 ce             	sub    %rcx,%rsi
    5dd0:	4c 39 ce             	cmp    %r9,%rsi
    5dd3:	73 13                	jae    5de8 <fwp_heap_alloc+0xf8>
    5dd5:	89 fe                	mov    %edi,%esi
    5dd7:	48 83 c4 18          	add    $0x18,%rsp
    5ddb:	48 89 d7             	mov    %rdx,%rdi
    5dde:	e9 8d fd ff ff       	jmp    5b70 <fwp_heap_alloc_slow>
    5de3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5de8:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5dec:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5df0:	e9 67 ff ff ff       	jmp    5d5c <fwp_heap_alloc+0x6c>
    5df5:	0f 1f 00             	nopl   (%rax)
    5df8:	89 fe                	mov    %edi,%esi
    5dfa:	48 89 d7             	mov    %rdx,%rdi
    5dfd:	e9 6e fd ff ff       	jmp    5b70 <fwp_heap_alloc_slow>
    5e02:	e8 a9 de ff ff       	call   3cb0 <fwp_heap_oom>
    5e07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e0e:	00 00 

0000000000005e10 <fwp_data.part.0.constprop.0>:
    5e10:	41 56                	push   %r14
    5e12:	41 89 fe             	mov    %edi,%r14d
    5e15:	41 54                	push   %r12
    5e17:	49 89 f4             	mov    %rsi,%r12
    5e1a:	55                   	push   %rbp
    5e1b:	53                   	push   %rbx
    5e1c:	48 83 ec 08          	sub    $0x8,%rsp
    5e20:	8b 05 5e bd 01 00    	mov    0x1bd5e(%rip),%eax        # 21b84 <fwp_heap+0x13a4>
    5e26:	85 c0                	test   %eax,%eax
    5e28:	0f 84 fa 00 00 00    	je     5f28 <fwp_data.part.0.constprop.0+0x118>
    5e2e:	0f b6 05 4d b9 01 00 	movzbl 0x1b94d(%rip),%eax        # 21782 <fwp_heap+0xfa2>
    5e35:	48 8d 15 a4 a9 01 00 	lea    0x1a9a4(%rip),%rdx        # 207e0 <fwp_heap>
    5e3c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5e43:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5e47:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5e4b:	48 8b 18             	mov    (%rax),%rbx
    5e4e:	48 85 db             	test   %rbx,%rbx
    5e51:	0f 84 a9 00 00 00    	je     5f00 <fwp_data.part.0.constprop.0+0xf0>
    5e57:	48 8b 13             	mov    (%rbx),%rdx
    5e5a:	48 f7 d2             	not    %rdx
    5e5d:	48 89 10             	mov    %rdx,(%rax)
    5e60:	48 83 fd 18          	cmp    $0x18,%rbp
    5e64:	76 1b                	jbe    5e81 <fwp_data.part.0.constprop.0+0x71>
    5e66:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5e6a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5e6e:	31 f6                	xor    %esi,%esi
    5e70:	48 c1 e8 03          	shr    $0x3,%rax
    5e74:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5e7b:	00 
    5e7c:	e8 3f d6 ff ff       	call   34c0 <memset@plt>
    5e81:	48 89 e8             	mov    %rbp,%rax
    5e84:	48 03 05 75 bd 01 00 	add    0x1bd75(%rip),%rax        # 21c00 <fwp_heap+0x1420>
    5e8b:	0f 82 a8 00 00 00    	jb     5f39 <fwp_data.part.0.constprop.0+0x129>
    5e91:	48 39 05 70 bd 01 00 	cmp    %rax,0x1bd70(%rip)        # 21c08 <fwp_heap+0x1428>
    5e98:	48 89 05 61 bd 01 00 	mov    %rax,0x1bd61(%rip)        # 21c00 <fwp_heap+0x1420>
    5e9f:	73 07                	jae    5ea8 <fwp_data.part.0.constprop.0+0x98>
    5ea1:	48 89 05 60 bd 01 00 	mov    %rax,0x1bd60(%rip)        # 21c08 <fwp_heap+0x1428>
    5ea8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5eac:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5eb1:	f2 0f 58 05 5f bd 01 	addsd  0x1bd5f(%rip),%xmm0        # 21c18 <fwp_heap+0x1438>
    5eb8:	00 
    5eb9:	f2 0f 11 05 57 bd 01 	movsd  %xmm0,0x1bd57(%rip)        # 21c18 <fwp_heap+0x1438>
    5ec0:	00 
    5ec1:	b8 02 00 00 00       	mov    $0x2,%eax
    5ec6:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5ecb:	66 0f 6e c8          	movd   %eax,%xmm1
    5ecf:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5ed3:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5ed7:	49 8b 04 24          	mov    (%r12),%rax
    5edb:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5edf:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5ee4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5ee8:	48 83 c4 08          	add    $0x8,%rsp
    5eec:	48 89 d8             	mov    %rbx,%rax
    5eef:	5b                   	pop    %rbx
    5ef0:	5d                   	pop    %rbp
    5ef1:	41 5c                	pop    %r12
    5ef3:	41 5e                	pop    %r14
    5ef5:	c3                   	ret
    5ef6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5efd:	00 00 00 
    5f00:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5f04:	48 85 db             	test   %rbx,%rbx
    5f07:	74 1f                	je     5f28 <fwp_data.part.0.constprop.0+0x118>
    5f09:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5f0d:	48 29 da             	sub    %rbx,%rdx
    5f10:	48 39 ea             	cmp    %rbp,%rdx
    5f13:	72 13                	jb     5f28 <fwp_data.part.0.constprop.0+0x118>
    5f15:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5f19:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5f1d:	e9 3e ff ff ff       	jmp    5e60 <fwp_data.part.0.constprop.0+0x50>
    5f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5f28:	31 f6                	xor    %esi,%esi
    5f2a:	bf 18 00 00 00       	mov    $0x18,%edi
    5f2f:	e8 bc fd ff ff       	call   5cf0 <fwp_heap_alloc>
    5f34:	48 89 c3             	mov    %rax,%rbx
    5f37:	eb 88                	jmp    5ec1 <fwp_data.part.0.constprop.0+0xb1>
    5f39:	e8 72 dd ff ff       	call   3cb0 <fwp_heap_oom>
    5f3e:	66 90                	xchg   %ax,%ax

0000000000005f40 <fwp_p_ad_push>:
    5f40:	41 57                	push   %r15
    5f42:	41 56                	push   %r14
    5f44:	41 55                	push   %r13
    5f46:	49 89 d5             	mov    %rdx,%r13
    5f49:	41 54                	push   %r12
    5f4b:	49 89 fc             	mov    %rdi,%r12
    5f4e:	55                   	push   %rbp
    5f4f:	53                   	push   %rbx
    5f50:	48 83 ec 38          	sub    $0x38,%rsp
    5f54:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5f59:	48 85 ff             	test   %rdi,%rdi
    5f5c:	79 09                	jns    5f67 <fwp_p_ad_push+0x27>
    5f5e:	48 85 d2             	test   %rdx,%rdx
    5f61:	0f 88 a9 01 00 00    	js     6110 <fwp_p_ad_push+0x1d0>
    5f67:	48 89 f8             	mov    %rdi,%rax
    5f6a:	48 89 0c 24          	mov    %rcx,(%rsp)
    5f6e:	48 09 d0             	or     %rdx,%rax
    5f71:	0f 89 79 01 00 00    	jns    60f0 <fwp_p_ad_push+0x1b0>
    5f77:	48 89 f8             	mov    %rdi,%rax
    5f7a:	48 c1 f8 20          	sar    $0x20,%rax
    5f7e:	48 85 ff             	test   %rdi,%rdi
    5f81:	79 24                	jns    5fa7 <fwp_p_ad_push+0x67>
    5f83:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5f88:	48 89 d0             	mov    %rdx,%rax
    5f8b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5f92:	00 
    5f93:	49 89 d4             	mov    %rdx,%r12
    5f96:	48 c1 f8 20          	sar    $0x20,%rax
    5f9a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5fa1:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5fa7:	48 89 c7             	mov    %rax,%rdi
    5faa:	e8 21 e7 ff ff       	call   46d0 <fwp_tape_of>
    5faf:	48 89 c3             	mov    %rax,%rbx
    5fb2:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5fb7:	0f 85 76 02 00 00    	jne    6233 <fwp_p_ad_push+0x2f3>
    5fbd:	4c 8b 78 10          	mov    0x10(%rax),%r15
    5fc1:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    5fc8:	0f 8f 59 02 00 00    	jg     6227 <fwp_p_ad_push+0x2e7>
    5fce:	44 89 e0             	mov    %r12d,%eax
    5fd1:	4c 39 f8             	cmp    %r15,%rax
    5fd4:	0f 8d 41 02 00 00    	jge    621b <fwp_p_ad_push+0x2db>
    5fda:	4d 85 ed             	test   %r13,%r13
    5fdd:	78 0c                	js     5feb <fwp_p_ad_push+0xab>
    5fdf:	44 89 e8             	mov    %r13d,%eax
    5fe2:	4c 39 f8             	cmp    %r15,%rax
    5fe5:	0f 8d 30 02 00 00    	jge    621b <fwp_p_ad_push+0x2db>
    5feb:	4d 89 fe             	mov    %r15,%r14
    5fee:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5ff2:	49 8d 46 01          	lea    0x1(%r14),%rax
    5ff6:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5ffc:	0f 87 25 02 00 00    	ja     6227 <fwp_p_ad_push+0x2e7>
    6002:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    6006:	48 39 e8             	cmp    %rbp,%rax
    6009:	0f 8e 31 01 00 00    	jle    6140 <fwp_p_ad_push+0x200>
    600f:	48 85 ed             	test   %rbp,%rbp
    6012:	b9 40 00 00 00       	mov    $0x40,%ecx
    6017:	48 0f 44 e9          	cmove  %rcx,%rbp
    601b:	48 39 e8             	cmp    %rbp,%rax
    601e:	7e 20                	jle    6040 <fwp_p_ad_push+0x100>
    6020:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    6027:	0f 8f 03 01 00 00    	jg     6130 <fwp_p_ad_push+0x1f0>
    602d:	48 01 ed             	add    %rbp,%rbp
    6030:	48 39 e8             	cmp    %rbp,%rax
    6033:	7f eb                	jg     6020 <fwp_p_ad_push+0xe0>
    6035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    603c:	00 00 00 00 
    6040:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6047:	00 
    6048:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    604c:	48 89 c6             	mov    %rax,%rsi
    604f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6054:	e8 77 d5 ff ff       	call   35d0 <realloc@plt>
    6059:	48 85 c0             	test   %rax,%rax
    605c:	0f 84 dd 01 00 00    	je     623f <fwp_p_ad_push+0x2ff>
    6062:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    6066:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    606a:	48 89 43 20          	mov    %rax,0x20(%rbx)
    606e:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    6072:	48 89 e9             	mov    %rbp,%rcx
    6075:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6079:	48 c1 e1 04          	shl    $0x4,%rcx
    607d:	48 89 ce             	mov    %rcx,%rsi
    6080:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6085:	e8 46 d5 ff ff       	call   35d0 <realloc@plt>
    608a:	48 85 c0             	test   %rax,%rax
    608d:	0f 84 ac 01 00 00    	je     623f <fwp_p_ad_push+0x2ff>
    6093:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    6097:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    609c:	4d 85 f6             	test   %r14,%r14
    609f:	48 89 43 30          	mov    %rax,0x30(%rbx)
    60a3:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    60a8:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    60af:	00 
    60b0:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    60b7:	00 
    60b8:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    60bc:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    60c3:	00 
    60c4:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    60c8:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    60cc:	0f 85 e2 00 00 00    	jne    61b4 <fwp_p_ad_push+0x274>
    60d2:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    60d6:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    60da:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    60de:	49 01 c8             	add    %rcx,%r8
    60e1:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    60e5:	eb 79                	jmp    6160 <fwp_p_ad_push+0x220>
    60e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    60ee:	00 00 
    60f0:	48 89 d0             	mov    %rdx,%rax
    60f3:	48 c1 ff 20          	sar    $0x20,%rdi
    60f7:	48 c1 f8 20          	sar    $0x20,%rax
    60fb:	48 39 c7             	cmp    %rax,%rdi
    60fe:	0f 84 a3 fe ff ff    	je     5fa7 <fwp_p_ad_push+0x67>
    6104:	48 8d 3d ad 67 00 00 	lea    0x67ad(%rip),%rdi        # c8b8 <_IO_stdin_used+0x8b8>
    610b:	e8 e0 e2 ff ff       	call   43f0 <fwp_trap>
    6110:	48 83 c4 38          	add    $0x38,%rsp
    6114:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    611b:	5b                   	pop    %rbx
    611c:	5d                   	pop    %rbp
    611d:	41 5c                	pop    %r12
    611f:	41 5d                	pop    %r13
    6121:	41 5e                	pop    %r14
    6123:	41 5f                	pop    %r15
    6125:	c3                   	ret
    6126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    612d:	00 00 00 
    6130:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    6135:	e9 06 ff ff ff       	jmp    6040 <fwp_p_ad_push+0x100>
    613a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6140:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    6144:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6148:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    614f:	00 
    6150:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6157:	00 
    6158:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    615c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6160:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6166:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    616a:	4d 85 ed             	test   %r13,%r13
    616d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6172:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6178:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    617f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6183:	49 8d 47 01          	lea    0x1(%r15),%rax
    6187:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    618b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6191:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6195:	48 83 c4 38          	add    $0x38,%rsp
    6199:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    61a0:	ff ff ff 
    61a3:	4c 21 e0             	and    %r12,%rax
    61a6:	5b                   	pop    %rbx
    61a7:	5d                   	pop    %rbp
    61a8:	4c 09 f8             	or     %r15,%rax
    61ab:	41 5c                	pop    %r12
    61ad:	41 5d                	pop    %r13
    61af:	41 5e                	pop    %r14
    61b1:	41 5f                	pop    %r15
    61b3:	c3                   	ret
    61b4:	48 39 ca             	cmp    %rcx,%rdx
    61b7:	49 89 d6             	mov    %rdx,%r14
    61ba:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    61bf:	48 0f 43 ca          	cmovae %rdx,%rcx
    61c3:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    61c8:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    61cd:	48 29 d1             	sub    %rdx,%rcx
    61d0:	4c 89 ca             	mov    %r9,%rdx
    61d3:	e8 88 d3 ff ff       	call   3560 <__memmove_chk@plt>
    61d8:	4c 03 73 30          	add    0x30(%rbx),%r14
    61dc:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    61e1:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    61e5:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    61ea:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    61ee:	48 03 7b 20          	add    0x20(%rbx),%rdi
    61f2:	4c 89 d2             	mov    %r10,%rdx
    61f5:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    61fa:	e8 11 d4 ff ff       	call   3610 <memmove@plt>
    61ff:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6203:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6207:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    620c:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    6211:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    6216:	e9 bb fe ff ff       	jmp    60d6 <fwp_p_ad_push+0x196>
    621b:	48 8d 3d 45 5f 00 00 	lea    0x5f45(%rip),%rdi        # c167 <_IO_stdin_used+0x167>
    6222:	e8 c9 e1 ff ff       	call   43f0 <fwp_trap>
    6227:	48 8d 3d 1e 5f 00 00 	lea    0x5f1e(%rip),%rdi        # c14c <_IO_stdin_used+0x14c>
    622e:	e8 bd e1 ff ff       	call   43f0 <fwp_trap>
    6233:	48 8d 3d c6 66 00 00 	lea    0x66c6(%rip),%rdi        # c900 <_IO_stdin_used+0x900>
    623a:	e8 b1 e1 ff ff       	call   43f0 <fwp_trap>
    623f:	48 89 df             	mov    %rbx,%rdi
    6242:	e8 b9 d9 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6247:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    624b:	e8 70 d1 ff ff       	call   33c0 <free@plt>
    6250:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6254:	e8 67 d1 ff ff       	call   33c0 <free@plt>
    6259:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    625d:	e8 5e d1 ff ff       	call   33c0 <free@plt>
    6262:	31 c9                	xor    %ecx,%ecx
    6264:	31 c0                	xor    %eax,%eax
    6266:	31 d2                	xor    %edx,%edx
    6268:	89 53 04             	mov    %edx,0x4(%rbx)
    626b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    626f:	ba 13 00 00 00       	mov    $0x13,%edx
    6274:	be 01 00 00 00       	mov    $0x1,%esi
    6279:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    627d:	48 8d 3d 84 5d 00 00 	lea    0x5d84(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    6284:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6288:	48 8b 0d b1 9d 00 00 	mov    0x9db1(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    628f:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6293:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    6297:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    629b:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    629f:	e8 dc d3 ff ff       	call   3680 <fwrite@plt>
    62a4:	31 ff                	xor    %edi,%edi
    62a6:	e8 15 d3 ff ff       	call   35c0 <fflush@plt>
    62ab:	bf 66 00 00 00       	mov    $0x66,%edi
    62b0:	e8 eb d3 ff ff       	call   36a0 <_Exit@plt>
    62b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62bc:	00 00 00 00 

00000000000062c0 <w120>:
    62c0:	66 0f 28 e0          	movapd %xmm0,%xmm4
    62c4:	41 55                	push   %r13
    62c6:	48 89 fa             	mov    %rdi,%rdx
    62c9:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    62cd:	41 54                	push   %r12
    62cf:	49 89 fc             	mov    %rdi,%r12
    62d2:	55                   	push   %rbp
    62d3:	53                   	push   %rbx
    62d4:	48 89 f3             	mov    %rsi,%rbx
    62d7:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    62dc:	48 89 f1             	mov    %rsi,%rcx
    62df:	48 83 ec 28          	sub    $0x28,%rsp
    62e3:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    62e9:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    62ef:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    62f5:	e8 46 fc ff ff       	call   5f40 <fwp_p_ad_push>
    62fa:	48 89 c7             	mov    %rax,%rdi
    62fd:	e8 5e ec ff ff       	call   4f60 <caf75>
    6302:	66 48 0f 6e c0       	movq   %rax,%xmm0
    6307:	e8 54 ec ff ff       	call   4f60 <caf75>
    630c:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6312:	66 0f 57 05 06 69 00 	xorpd  0x6906(%rip),%xmm0        # cc20 <msg.8+0xb0>
    6319:	00 
    631a:	48 89 da             	mov    %rbx,%rdx
    631d:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6323:	48 89 c1             	mov    %rax,%rcx
    6326:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    632b:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6330:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6336:	e8 05 fc ff ff       	call   5f40 <fwp_p_ad_push>
    633b:	4c 89 e7             	mov    %r12,%rdi
    633e:	49 89 c5             	mov    %rax,%r13
    6341:	e8 1a ec ff ff       	call   4f60 <caf75>
    6346:	48 89 c6             	mov    %rax,%rsi
    6349:	e8 12 ec ff ff       	call   4f60 <caf75>
    634e:	66 48 0f 6e d6       	movq   %rsi,%xmm2
    6353:	f2 0f 10 05 3d 68 00 	movsd  0x683d(%rip),%xmm0        # cb98 <msg.8+0x28>
    635a:	00 
    635b:	66 0f 57 15 bd 68 00 	xorpd  0x68bd(%rip),%xmm2        # cc20 <msg.8+0xb0>
    6362:	00 
    6363:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    6369:	48 89 c1             	mov    %rax,%rcx
    636c:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6373:	66 48 0f 7e d6       	movq   %xmm2,%rsi
    6378:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    637d:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6383:	e8 b8 fb ff ff       	call   5f40 <fwp_p_ad_push>
    6388:	48 89 e9             	mov    %rbp,%rcx
    638b:	4c 89 ea             	mov    %r13,%rdx
    638e:	48 89 ee             	mov    %rbp,%rsi
    6391:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6397:	4c 89 ef             	mov    %r13,%rdi
    639a:	49 89 c4             	mov    %rax,%r12
    639d:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    63a1:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    63a7:	e8 94 fb ff ff       	call   5f40 <fwp_p_ad_push>
    63ac:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    63b2:	f2 0f 59 1d e6 67 00 	mulsd  0x67e6(%rip),%xmm3        # cba0 <msg.8+0x30>
    63b9:	00 
    63ba:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    63c1:	00 59 40 
    63c4:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    63c9:	48 89 c2             	mov    %rax,%rdx
    63cc:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    63d3:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    63d9:	e8 62 fb ff ff       	call   5f40 <fwp_p_ad_push>
    63de:	4c 89 e2             	mov    %r12,%rdx
    63e1:	48 89 d9             	mov    %rbx,%rcx
    63e4:	48 89 de             	mov    %rbx,%rsi
    63e7:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    63ed:	4c 89 e7             	mov    %r12,%rdi
    63f0:	48 89 c5             	mov    %rax,%rbp
    63f3:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    63f7:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    63fd:	e8 3e fb ff ff       	call   5f40 <fwp_p_ad_push>
    6402:	48 89 c7             	mov    %rax,%rdi
    6405:	e8 56 eb ff ff       	call   4f60 <caf75>
    640a:	48 89 c6             	mov    %rax,%rsi
    640d:	e8 4e eb ff ff       	call   4f60 <caf75>
    6412:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6418:	48 89 ea             	mov    %rbp,%rdx
    641b:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6421:	48 89 c1             	mov    %rax,%rcx
    6424:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6429:	e8 12 fb ff ff       	call   5f40 <fwp_p_ad_push>
    642e:	48 83 c4 28          	add    $0x28,%rsp
    6432:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    6437:	5b                   	pop    %rbx
    6438:	5d                   	pop    %rbp
    6439:	41 5c                	pop    %r12
    643b:	41 5d                	pop    %r13
    643d:	c3                   	ret
    643e:	66 90                	xchg   %ax,%ax

0000000000006440 <w176.constprop.0>:
    6440:	41 54                	push   %r12
    6442:	55                   	push   %rbp
    6443:	53                   	push   %rbx
    6444:	48 83 ec 10          	sub    $0x10,%rsp
    6448:	4c 8b 27             	mov    (%rdi),%r12
    644b:	4d 85 e4             	test   %r12,%r12
    644e:	74 78                	je     64c8 <w176.constprop.0+0x88>
    6450:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    6457:	00 00 
    6459:	48 89 fd             	mov    %rdi,%rbp
    645c:	31 db                	xor    %ebx,%ebx
    645e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6465:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    646c:	00 00 00 00 
    6470:	4c 8b 44 dd 10       	mov    0x10(%rbp,%rbx,8),%r8
    6475:	f2 0f 10 44 dd 08    	movsd  0x8(%rbp,%rbx,8),%xmm0
    647b:	48 83 c3 02          	add    $0x2,%rbx
    647f:	e8 dc ea ff ff       	call   4f60 <caf75>
    6484:	48 89 c6             	mov    %rax,%rsi
    6487:	e8 d4 ea ff ff       	call   4f60 <caf75>
    648c:	f2 0f 58 44 24 08    	addsd  0x8(%rsp),%xmm0
    6492:	4c 89 c2             	mov    %r8,%rdx
    6495:	48 89 c1             	mov    %rax,%rcx
    6498:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    649e:	e8 9d fa ff ff       	call   5f40 <fwp_p_ad_push>
    64a3:	48 89 c7             	mov    %rax,%rdi
    64a6:	4c 39 e3             	cmp    %r12,%rbx
    64a9:	72 c5                	jb     6470 <w176.constprop.0+0x30>
    64ab:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    64b0:	48 83 c4 10          	add    $0x10,%rsp
    64b4:	5b                   	pop    %rbx
    64b5:	5d                   	pop    %rbp
    64b6:	66 48 0f 6e c0       	movq   %rax,%xmm0
    64bb:	41 5c                	pop    %r12
    64bd:	48 89 f8             	mov    %rdi,%rax
    64c0:	c3                   	ret
    64c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    64c8:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    64cf:	00 00 
    64d1:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    64d8:	eb d1                	jmp    64ab <w176.constprop.0+0x6b>
    64da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000064e0 <fwp_rc_share>:
    64e0:	48 8b 05 d1 b6 01 00 	mov    0x1b6d1(%rip),%rax        # 21bb8 <fwp_heap+0x13d8>
    64e7:	48 2b 3d a2 b6 01 00 	sub    0x1b6a2(%rip),%rdi        # 21b90 <fwp_heap+0x13b0>
    64ee:	48 c1 e0 10          	shl    $0x10,%rax
    64f2:	48 39 c7             	cmp    %rax,%rdi
    64f5:	73 4a                	jae    6541 <fwp_rc_share+0x61>
    64f7:	48 89 f8             	mov    %rdi,%rax
    64fa:	48 c1 e8 10          	shr    $0x10,%rax
    64fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6502:	48 8b 05 cf b6 01 00 	mov    0x1b6cf(%rip),%rax        # 21bd8 <fwp_heap+0x13f8>
    6509:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    650d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6511:	48 85 d2             	test   %rdx,%rdx
    6514:	74 2b                	je     6541 <fwp_rc_share+0x61>
    6516:	0f b6 08             	movzbl (%rax),%ecx
    6519:	80 f9 02             	cmp    $0x2,%cl
    651c:	74 2a                	je     6548 <fwp_rc_share+0x68>
    651e:	80 f9 01             	cmp    $0x1,%cl
    6521:	75 1e                	jne    6541 <fwp_rc_share+0x61>
    6523:	8b 48 18             	mov    0x18(%rax),%ecx
    6526:	0f b7 ff             	movzwl %di,%edi
    6529:	8b 40 1c             	mov    0x1c(%rax),%eax
    652c:	48 0f af f9          	imul   %rcx,%rdi
    6530:	48 c1 ef 20          	shr    $0x20,%rdi
    6534:	48 39 c7             	cmp    %rax,%rdi
    6537:	73 08                	jae    6541 <fwp_rc_share+0x61>
    6539:	48 01 fa             	add    %rdi,%rdx
    653c:	80 3a 00             	cmpb   $0x0,(%rdx)
    653f:	75 0d                	jne    654e <fwp_rc_share+0x6e>
    6541:	c3                   	ret
    6542:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6548:	66 85 ff             	test   %di,%di
    654b:	74 ef                	je     653c <fwp_rc_share+0x5c>
    654d:	c3                   	ret
    654e:	50                   	push   %rax
    654f:	48 8d 3d da 63 00 00 	lea    0x63da(%rip),%rdi        # c930 <_IO_stdin_used+0x930>
    6556:	e8 95 de ff ff       	call   43f0 <fwp_trap>
    655b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006560 <fwp_rc_free_obj>:
    6560:	48 8b 15 51 b6 01 00 	mov    0x1b651(%rip),%rdx        # 21bb8 <fwp_heap+0x13d8>
    6567:	48 89 f8             	mov    %rdi,%rax
    656a:	48 2b 05 1f b6 01 00 	sub    0x1b61f(%rip),%rax        # 21b90 <fwp_heap+0x13b0>
    6571:	48 c1 e2 10          	shl    $0x10,%rdx
    6575:	48 39 d0             	cmp    %rdx,%rax
    6578:	73 5b                	jae    65d5 <fwp_rc_free_obj+0x75>
    657a:	48 89 c2             	mov    %rax,%rdx
    657d:	48 c1 ea 10          	shr    $0x10,%rdx
    6581:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6585:	48 8b 15 4c b6 01 00 	mov    0x1b64c(%rip),%rdx        # 21bd8 <fwp_heap+0x13f8>
    658c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6590:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6594:	48 85 c9             	test   %rcx,%rcx
    6597:	74 3c                	je     65d5 <fwp_rc_free_obj+0x75>
    6599:	0f b6 32             	movzbl (%rdx),%esi
    659c:	40 80 fe 02          	cmp    $0x2,%sil
    65a0:	74 2e                	je     65d0 <fwp_rc_free_obj+0x70>
    65a2:	40 80 fe 01          	cmp    $0x1,%sil
    65a6:	75 2d                	jne    65d5 <fwp_rc_free_obj+0x75>
    65a8:	8b 72 18             	mov    0x18(%rdx),%esi
    65ab:	0f b7 c0             	movzwl %ax,%eax
    65ae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    65b1:	48 0f af c6          	imul   %rsi,%rax
    65b5:	48 c1 e8 20          	shr    $0x20,%rax
    65b9:	48 39 d0             	cmp    %rdx,%rax
    65bc:	73 17                	jae    65d5 <fwp_rc_free_obj+0x75>
    65be:	48 01 c1             	add    %rax,%rcx
    65c1:	80 39 01             	cmpb   $0x1,(%rcx)
    65c4:	75 0f                	jne    65d5 <fwp_rc_free_obj+0x75>
    65c6:	e9 25 f2 ff ff       	jmp    57f0 <fwp_mem_free>
    65cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    65d0:	66 85 c0             	test   %ax,%ax
    65d3:	74 ec                	je     65c1 <fwp_rc_free_obj+0x61>
    65d5:	c3                   	ret
    65d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    65dd:	00 00 00 

00000000000065e0 <fwp_rc_dup>:
    65e0:	f3 0f 1e fa          	endbr64
    65e4:	48 8b 05 cd b5 01 00 	mov    0x1b5cd(%rip),%rax        # 21bb8 <fwp_heap+0x13d8>
    65eb:	48 2b 3d 9e b5 01 00 	sub    0x1b59e(%rip),%rdi        # 21b90 <fwp_heap+0x13b0>
    65f2:	48 c1 e0 10          	shl    $0x10,%rax
    65f6:	48 39 c7             	cmp    %rax,%rdi
    65f9:	73 56                	jae    6651 <fwp_rc_dup+0x71>
    65fb:	48 89 f8             	mov    %rdi,%rax
    65fe:	48 c1 e8 10          	shr    $0x10,%rax
    6602:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6606:	48 8b 05 cb b5 01 00 	mov    0x1b5cb(%rip),%rax        # 21bd8 <fwp_heap+0x13f8>
    660d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6611:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6615:	48 85 c0             	test   %rax,%rax
    6618:	74 37                	je     6651 <fwp_rc_dup+0x71>
    661a:	0f b6 0a             	movzbl (%rdx),%ecx
    661d:	80 f9 02             	cmp    $0x2,%cl
    6620:	74 36                	je     6658 <fwp_rc_dup+0x78>
    6622:	80 f9 01             	cmp    $0x1,%cl
    6625:	75 2a                	jne    6651 <fwp_rc_dup+0x71>
    6627:	8b 4a 18             	mov    0x18(%rdx),%ecx
    662a:	0f b7 ff             	movzwl %di,%edi
    662d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6630:	48 0f af f9          	imul   %rcx,%rdi
    6634:	48 c1 ef 20          	shr    $0x20,%rdi
    6638:	48 39 d7             	cmp    %rdx,%rdi
    663b:	73 14                	jae    6651 <fwp_rc_dup+0x71>
    663d:	48 01 f8             	add    %rdi,%rax
    6640:	0f b6 10             	movzbl (%rax),%edx
    6643:	84 d2                	test   %dl,%dl
    6645:	74 0a                	je     6651 <fwp_rc_dup+0x71>
    6647:	80 fa fd             	cmp    $0xfd,%dl
    664a:	77 14                	ja     6660 <fwp_rc_dup+0x80>
    664c:	83 c2 01             	add    $0x1,%edx
    664f:	88 10                	mov    %dl,(%rax)
    6651:	c3                   	ret
    6652:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6658:	66 85 ff             	test   %di,%di
    665b:	74 e3                	je     6640 <fwp_rc_dup+0x60>
    665d:	c3                   	ret
    665e:	66 90                	xchg   %ax,%ax
    6660:	48 89 c7             	mov    %rax,%rdi
    6663:	e9 28 ee ff ff       	jmp    5490 <fwp_rc_wide_dup>
    6668:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    666f:	00 

0000000000006670 <fwp_owned_entry173>:
    6670:	f3 0f 1e fa          	endbr64
    6674:	48 83 ec 38          	sub    $0x38,%rsp
    6678:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    667d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6684:	00 00 
    6686:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    668b:	31 c0                	xor    %eax,%eax
    668d:	48 8b 07             	mov    (%rdi),%rax
    6690:	48 03 47 10          	add    0x10(%rdi),%rax
    6694:	0f 80 c2 00 00 00    	jo     675c <fwp_owned_entry173+0xec>
    669a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    669f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    66a4:	31 ff                	xor    %edi,%edi
    66a6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    66aa:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    66af:	e8 5c f7 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    66b4:	48 8b 15 fd b4 01 00 	mov    0x1b4fd(%rip),%rdx        # 21bb8 <fwp_heap+0x13d8>
    66bb:	48 89 c6             	mov    %rax,%rsi
    66be:	48 2b 05 cb b4 01 00 	sub    0x1b4cb(%rip),%rax        # 21b90 <fwp_heap+0x13b0>
    66c5:	48 c1 e2 10          	shl    $0x10,%rdx
    66c9:	48 39 d0             	cmp    %rdx,%rax
    66cc:	73 4f                	jae    671d <fwp_owned_entry173+0xad>
    66ce:	48 89 c2             	mov    %rax,%rdx
    66d1:	48 c1 ea 10          	shr    $0x10,%rdx
    66d5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    66d9:	48 8b 15 f8 b4 01 00 	mov    0x1b4f8(%rip),%rdx        # 21bd8 <fwp_heap+0x13f8>
    66e0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    66e4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    66e8:	48 85 d2             	test   %rdx,%rdx
    66eb:	74 30                	je     671d <fwp_owned_entry173+0xad>
    66ed:	0f b6 39             	movzbl (%rcx),%edi
    66f0:	40 80 ff 02          	cmp    $0x2,%dil
    66f4:	74 42                	je     6738 <fwp_owned_entry173+0xc8>
    66f6:	40 80 ff 01          	cmp    $0x1,%dil
    66fa:	75 21                	jne    671d <fwp_owned_entry173+0xad>
    66fc:	8b 79 18             	mov    0x18(%rcx),%edi
    66ff:	0f b7 c0             	movzwl %ax,%eax
    6702:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6705:	48 0f af c7          	imul   %rdi,%rax
    6709:	48 c1 e8 20          	shr    $0x20,%rax
    670d:	48 39 c8             	cmp    %rcx,%rax
    6710:	73 0b                	jae    671d <fwp_owned_entry173+0xad>
    6712:	48 01 c2             	add    %rax,%rdx
    6715:	80 3a ff             	cmpb   $0xff,(%rdx)
    6718:	74 26                	je     6740 <fwp_owned_entry173+0xd0>
    671a:	c6 02 01             	movb   $0x1,(%rdx)
    671d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6722:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6729:	00 00 
    672b:	75 34                	jne    6761 <fwp_owned_entry173+0xf1>
    672d:	48 89 f0             	mov    %rsi,%rax
    6730:	48 83 c4 38          	add    $0x38,%rsp
    6734:	c3                   	ret
    6735:	0f 1f 00             	nopl   (%rax)
    6738:	66 85 c0             	test   %ax,%ax
    673b:	75 e0                	jne    671d <fwp_owned_entry173+0xad>
    673d:	eb d6                	jmp    6715 <fwp_owned_entry173+0xa5>
    673f:	90                   	nop
    6740:	48 89 d7             	mov    %rdx,%rdi
    6743:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6748:	48 89 14 24          	mov    %rdx,(%rsp)
    674c:	e8 5f ee ff ff       	call   55b0 <fwp_rc_forget_slot>
    6751:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6756:	48 8b 14 24          	mov    (%rsp),%rdx
    675a:	eb be                	jmp    671a <fwp_owned_entry173+0xaa>
    675c:	e8 9f cf ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6761:	e8 fa cc ff ff       	call   3460 <__stack_chk_fail@plt>
    6766:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    676d:	00 00 00 

0000000000006770 <e173>:
    6770:	f3 0f 1e fa          	endbr64
    6774:	53                   	push   %rbx
    6775:	48 83 ec 30          	sub    $0x30,%rsp
    6779:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    677e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6785:	00 00 
    6787:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    678c:	31 c0                	xor    %eax,%eax
    678e:	48 8b 07             	mov    (%rdi),%rax
    6791:	48 03 47 10          	add    0x10(%rdi),%rax
    6795:	0f 80 c9 00 00 00    	jo     6864 <e173+0xf4>
    679b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    67a0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    67a5:	31 ff                	xor    %edi,%edi
    67a7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    67ab:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    67b0:	e8 5b f6 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    67b5:	48 8b 15 fc b3 01 00 	mov    0x1b3fc(%rip),%rdx        # 21bb8 <fwp_heap+0x13d8>
    67bc:	48 89 c3             	mov    %rax,%rbx
    67bf:	48 2b 05 ca b3 01 00 	sub    0x1b3ca(%rip),%rax        # 21b90 <fwp_heap+0x13b0>
    67c6:	48 c1 e2 10          	shl    $0x10,%rdx
    67ca:	48 39 d0             	cmp    %rdx,%rax
    67cd:	73 4f                	jae    681e <e173+0xae>
    67cf:	48 89 c2             	mov    %rax,%rdx
    67d2:	48 c1 ea 10          	shr    $0x10,%rdx
    67d6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    67da:	48 8b 15 f7 b3 01 00 	mov    0x1b3f7(%rip),%rdx        # 21bd8 <fwp_heap+0x13f8>
    67e1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    67e5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    67e9:	48 85 d2             	test   %rdx,%rdx
    67ec:	74 30                	je     681e <e173+0xae>
    67ee:	0f b6 31             	movzbl (%rcx),%esi
    67f1:	40 80 fe 02          	cmp    $0x2,%sil
    67f5:	74 49                	je     6840 <e173+0xd0>
    67f7:	40 80 fe 01          	cmp    $0x1,%sil
    67fb:	75 21                	jne    681e <e173+0xae>
    67fd:	8b 71 18             	mov    0x18(%rcx),%esi
    6800:	0f b7 c0             	movzwl %ax,%eax
    6803:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6806:	48 0f af c6          	imul   %rsi,%rax
    680a:	48 c1 e8 20          	shr    $0x20,%rax
    680e:	48 39 c8             	cmp    %rcx,%rax
    6811:	73 0b                	jae    681e <e173+0xae>
    6813:	48 01 c2             	add    %rax,%rdx
    6816:	80 3a ff             	cmpb   $0xff,(%rdx)
    6819:	74 35                	je     6850 <e173+0xe0>
    681b:	c6 02 01             	movb   $0x1,(%rdx)
    681e:	48 89 df             	mov    %rbx,%rdi
    6821:	e8 ba fc ff ff       	call   64e0 <fwp_rc_share>
    6826:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    682b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6832:	00 00 
    6834:	75 33                	jne    6869 <e173+0xf9>
    6836:	48 83 c4 30          	add    $0x30,%rsp
    683a:	48 89 d8             	mov    %rbx,%rax
    683d:	5b                   	pop    %rbx
    683e:	c3                   	ret
    683f:	90                   	nop
    6840:	66 85 c0             	test   %ax,%ax
    6843:	75 d9                	jne    681e <e173+0xae>
    6845:	eb cf                	jmp    6816 <e173+0xa6>
    6847:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    684e:	00 00 
    6850:	48 89 d7             	mov    %rdx,%rdi
    6853:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6858:	e8 53 ed ff ff       	call   55b0 <fwp_rc_forget_slot>
    685d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6862:	eb b7                	jmp    681b <e173+0xab>
    6864:	e8 97 ce ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6869:	e8 f2 cb ff ff       	call   3460 <__stack_chk_fail@plt>
    686e:	66 90                	xchg   %ax,%ax

0000000000006870 <fwp_closure_drop>:
    6870:	48 8b 15 41 b3 01 00 	mov    0x1b341(%rip),%rdx        # 21bb8 <fwp_heap+0x13d8>
    6877:	48 89 f8             	mov    %rdi,%rax
    687a:	48 2b 05 0f b3 01 00 	sub    0x1b30f(%rip),%rax        # 21b90 <fwp_heap+0x13b0>
    6881:	48 c1 e2 10          	shl    $0x10,%rdx
    6885:	48 39 d0             	cmp    %rdx,%rax
    6888:	73 6b                	jae    68f5 <fwp_closure_drop+0x85>
    688a:	48 89 c2             	mov    %rax,%rdx
    688d:	48 c1 ea 10          	shr    $0x10,%rdx
    6891:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6895:	48 8b 15 3c b3 01 00 	mov    0x1b33c(%rip),%rdx        # 21bd8 <fwp_heap+0x13f8>
    689c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    68a0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    68a4:	48 85 d2             	test   %rdx,%rdx
    68a7:	74 4c                	je     68f5 <fwp_closure_drop+0x85>
    68a9:	0f b6 31             	movzbl (%rcx),%esi
    68ac:	40 80 fe 02          	cmp    $0x2,%sil
    68b0:	74 3e                	je     68f0 <fwp_closure_drop+0x80>
    68b2:	40 80 fe 01          	cmp    $0x1,%sil
    68b6:	75 3d                	jne    68f5 <fwp_closure_drop+0x85>
    68b8:	8b 71 18             	mov    0x18(%rcx),%esi
    68bb:	0f b7 c0             	movzwl %ax,%eax
    68be:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    68c1:	48 0f af c6          	imul   %rsi,%rax
    68c5:	48 c1 e8 20          	shr    $0x20,%rax
    68c9:	48 39 c8             	cmp    %rcx,%rax
    68cc:	73 27                	jae    68f5 <fwp_closure_drop+0x85>
    68ce:	48 01 c2             	add    %rax,%rdx
    68d1:	0f b6 02             	movzbl (%rdx),%eax
    68d4:	84 c0                	test   %al,%al
    68d6:	74 1d                	je     68f5 <fwp_closure_drop+0x85>
    68d8:	3c 01                	cmp    $0x1,%al
    68da:	74 24                	je     6900 <fwp_closure_drop+0x90>
    68dc:	3c ff                	cmp    $0xff,%al
    68de:	74 48                	je     6928 <fwp_closure_drop+0xb8>
    68e0:	83 e8 01             	sub    $0x1,%eax
    68e3:	88 02                	mov    %al,(%rdx)
    68e5:	c3                   	ret
    68e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    68ed:	00 00 00 
    68f0:	66 85 c0             	test   %ax,%ax
    68f3:	74 dc                	je     68d1 <fwp_closure_drop+0x61>
    68f5:	c3                   	ret
    68f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    68fd:	00 00 00 
    6900:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6907:	ff ff 
    6909:	48 85 c0             	test   %rax,%rax
    690c:	74 12                	je     6920 <fwp_closure_drop+0xb0>
    690e:	48 89 fe             	mov    %rdi,%rsi
    6911:	48 89 c7             	mov    %rax,%rdi
    6914:	e9 37 db ff ff       	jmp    4450 <fwp_closure_drop_push>
    6919:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6920:	e9 db dc ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    6925:	0f 1f 00             	nopl   (%rax)
    6928:	48 89 d0             	mov    %rdx,%rax
    692b:	48 8d 35 ae 9e 01 00 	lea    0x19eae(%rip),%rsi        # 207e0 <fwp_heap>
    6932:	48 83 ec 18          	sub    $0x18,%rsp
    6936:	48 c1 e8 11          	shr    $0x11,%rax
    693a:	48 31 d0             	xor    %rdx,%rax
    693d:	48 89 c1             	mov    %rax,%rcx
    6940:	48 c1 e9 09          	shr    $0x9,%rcx
    6944:	48 31 c8             	xor    %rcx,%rax
    6947:	0f b6 c8             	movzbl %al,%ecx
    694a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6951:	00 
    6952:	48 85 c0             	test   %rax,%rax
    6955:	75 12                	jne    6969 <fwp_closure_drop+0xf9>
    6957:	eb 49                	jmp    69a2 <fwp_closure_drop+0x132>
    6959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6960:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6964:	48 85 c0             	test   %rax,%rax
    6967:	74 39                	je     69a2 <fwp_closure_drop+0x132>
    6969:	48 89 c1             	mov    %rax,%rcx
    696c:	48 39 10             	cmp    %rdx,(%rax)
    696f:	75 ef                	jne    6960 <fwp_closure_drop+0xf0>
    6971:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6975:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6979:	48 89 48 08          	mov    %rcx,0x8(%rax)
    697d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6984:	74 05                	je     698b <fwp_closure_drop+0x11b>
    6986:	48 83 c4 18          	add    $0x18,%rsp
    698a:	c3                   	ret
    698b:	48 89 d7             	mov    %rdx,%rdi
    698e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6993:	e8 18 ec ff ff       	call   55b0 <fwp_rc_forget_slot>
    6998:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    699d:	c6 02 fe             	movb   $0xfe,(%rdx)
    69a0:	eb e4                	jmp    6986 <fwp_closure_drop+0x116>
    69a2:	48 8d 3d e7 5e 00 00 	lea    0x5ee7(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    69a9:	e8 42 da ff ff       	call   43f0 <fwp_trap>
    69ae:	66 90                	xchg   %ax,%ax

00000000000069b0 <fwp_owned_tape_release>:
    69b0:	48 85 ff             	test   %rdi,%rdi
    69b3:	0f 84 f7 00 00 00    	je     6ab0 <fwp_owned_tape_release+0x100>
    69b9:	41 54                	push   %r12
    69bb:	55                   	push   %rbp
    69bc:	53                   	push   %rbx
    69bd:	48 8b 07             	mov    (%rdi),%rax
    69c0:	48 85 c0             	test   %rax,%rax
    69c3:	74 08                	je     69cd <fwp_owned_tape_release+0x1d>
    69c5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    69c9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    69cd:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    69d1:	48 85 d2             	test   %rdx,%rdx
    69d4:	74 03                	je     69d9 <fwp_owned_tape_release+0x29>
    69d6:	48 89 02             	mov    %rax,(%rdx)
    69d9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    69dd:	48 89 fb             	mov    %rdi,%rbx
    69e0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    69e4:	48 85 c0             	test   %rax,%rax
    69e7:	0f 84 89 00 00 00    	je     6a76 <fwp_owned_tape_release+0xc6>
    69ed:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    69f1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    69f5:	7e 47                	jle    6a3e <fwp_owned_tape_release+0x8e>
    69f7:	31 ed                	xor    %ebp,%ebp
    69f9:	eb 0d                	jmp    6a08 <fwp_owned_tape_release+0x58>
    69fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6a00:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6a04:	48 8b 40 68          	mov    0x68(%rax),%rax
    6a08:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6a0c:	49 89 ec             	mov    %rbp,%r12
    6a0f:	48 83 c5 01          	add    $0x1,%rbp
    6a13:	49 c1 e4 04          	shl    $0x4,%r12
    6a17:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6a1b:	ff d0                	call   *%rax
    6a1d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6a21:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6a26:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6a2a:	ff 50 68             	call   *0x68(%rax)
    6a2d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6a31:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6a35:	48 39 e8             	cmp    %rbp,%rax
    6a38:	7f c6                	jg     6a00 <fwp_owned_tape_release+0x50>
    6a3a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6a3e:	31 ed                	xor    %ebp,%ebp
    6a40:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6a45:	7e 28                	jle    6a6f <fwp_owned_tape_release+0xbf>
    6a47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6a4e:	00 00 
    6a50:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6a54:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6a58:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6a5c:	74 07                	je     6a65 <fwp_owned_tape_release+0xb5>
    6a5e:	ff 52 68             	call   *0x68(%rdx)
    6a61:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6a65:	48 83 c5 01          	add    $0x1,%rbp
    6a69:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6a6d:	7f e1                	jg     6a50 <fwp_owned_tape_release+0xa0>
    6a6f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6a73:	ff 52 68             	call   *0x68(%rdx)
    6a76:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6a7a:	e8 f1 fd ff ff       	call   6870 <fwp_closure_drop>
    6a7f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6a83:	e8 e8 fd ff ff       	call   6870 <fwp_closure_drop>
    6a88:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6a8c:	e8 df fd ff ff       	call   6870 <fwp_closure_drop>
    6a91:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6a95:	e8 56 ed ff ff       	call   57f0 <fwp_mem_free>
    6a9a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6a9e:	e8 4d ed ff ff       	call   57f0 <fwp_mem_free>
    6aa3:	48 89 df             	mov    %rbx,%rdi
    6aa6:	5b                   	pop    %rbx
    6aa7:	5d                   	pop    %rbp
    6aa8:	41 5c                	pop    %r12
    6aaa:	e9 41 ed ff ff       	jmp    57f0 <fwp_mem_free>
    6aaf:	90                   	nop
    6ab0:	c3                   	ret
    6ab1:	0f 1f 40 00          	nopl   0x0(%rax)
    6ab5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6abc:	00 00 00 00 

0000000000006ac0 <fwp_tape_finish>:
    6ac0:	f3 0f 1e fa          	endbr64
    6ac4:	41 56                	push   %r14
    6ac6:	48 8d 3d f3 95 01 00 	lea    0x195f3(%rip),%rdi        # 200c0 <fwp_tape_workspace>
    6acd:	41 55                	push   %r13
    6acf:	41 54                	push   %r12
    6ad1:	55                   	push   %rbp
    6ad2:	53                   	push   %rbx
    6ad3:	e8 38 d6 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    6ad8:	48 83 3d 28 96 01 00 	cmpq   $0x0,0x19628(%rip)        # 20108 <fwp_ntapes>
    6adf:	00 
    6ae0:	48 c7 05 bd 95 01 00 	movq   $0x0,0x195bd(%rip)        # 200a8 <fwp_tape_cached_bytes>
    6ae7:	00 00 00 00 
    6aeb:	7e 68                	jle    6b55 <fwp_tape_finish+0x95>
    6aed:	45 31 e4             	xor    %r12d,%r12d
    6af0:	31 ed                	xor    %ebp,%ebp
    6af2:	0f 1f 00             	nopl   (%rax)
    6af5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6afc:	00 00 00 00 
    6b00:	48 8b 1d 09 96 01 00 	mov    0x19609(%rip),%rbx        # 20110 <fwp_tapes>
    6b07:	48 83 c5 01          	add    $0x1,%rbp
    6b0b:	4c 01 e3             	add    %r12,%rbx
    6b0e:	49 83 c4 68          	add    $0x68,%r12
    6b12:	48 89 df             	mov    %rbx,%rdi
    6b15:	e8 e6 d0 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6b1a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6b1e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6b22:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6b26:	e8 95 c8 ff ff       	call   33c0 <free@plt>
    6b2b:	4c 89 f7             	mov    %r14,%rdi
    6b2e:	e8 8d c8 ff ff       	call   33c0 <free@plt>
    6b33:	4c 89 ef             	mov    %r13,%rdi
    6b36:	e8 85 c8 ff ff       	call   33c0 <free@plt>
    6b3b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6b3f:	e8 6c fe ff ff       	call   69b0 <fwp_owned_tape_release>
    6b44:	48 39 2d bd 95 01 00 	cmp    %rbp,0x195bd(%rip)        # 20108 <fwp_ntapes>
    6b4b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6b52:	00 
    6b53:	7f ab                	jg     6b00 <fwp_tape_finish+0x40>
    6b55:	48 8b 3d b4 95 01 00 	mov    0x195b4(%rip),%rdi        # 20110 <fwp_tapes>
    6b5c:	e8 5f c8 ff ff       	call   33c0 <free@plt>
    6b61:	5b                   	pop    %rbx
    6b62:	5d                   	pop    %rbp
    6b63:	48 c7 05 a2 95 01 00 	movq   $0x0,0x195a2(%rip)        # 20110 <fwp_tapes>
    6b6a:	00 00 00 00 
    6b6e:	48 c7 05 87 95 01 00 	movq   $0x0,0x19587(%rip)        # 20100 <fwp_tapes_cap>
    6b75:	00 00 00 00 
    6b79:	41 5c                	pop    %r12
    6b7b:	48 c7 05 82 95 01 00 	movq   $0x0,0x19582(%rip)        # 20108 <fwp_ntapes>
    6b82:	00 00 00 00 
    6b86:	41 5d                	pop    %r13
    6b88:	48 c7 05 65 95 01 00 	movq   $0x0,0x19565(%rip)        # 200f8 <fwp_tape_next_slot>
    6b8f:	00 00 00 00 
    6b93:	41 5e                	pop    %r14
    6b95:	c3                   	ret
    6b96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b9d:	00 00 00 

0000000000006ba0 <fwp_tape_scope_release>:
    6ba0:	f3 0f 1e fa          	endbr64
    6ba4:	41 55                	push   %r13
    6ba6:	41 54                	push   %r12
    6ba8:	55                   	push   %rbp
    6ba9:	53                   	push   %rbx
    6baa:	48 83 ec 58          	sub    $0x58,%rsp
    6bae:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6bb5:	00 00 
    6bb7:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6bbc:	48 63 07             	movslq (%rdi),%rax
    6bbf:	85 c0                	test   %eax,%eax
    6bc1:	0f 88 05 01 00 00    	js     6ccc <fwp_tape_scope_release+0x12c>
    6bc7:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6bce:	ec c4 4e 
    6bd1:	48 89 fb             	mov    %rdi,%rbx
    6bd4:	eb 3c                	jmp    6c12 <fwp_tape_scope_release+0x72>
    6bd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bdd:	00 00 00 
    6be0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6be5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6be9:	e8 d2 c7 ff ff       	call   33c0 <free@plt>
    6bee:	48 8b 3c 24          	mov    (%rsp),%rdi
    6bf2:	e8 c9 c7 ff ff       	call   33c0 <free@plt>
    6bf7:	4c 89 ef             	mov    %r13,%rdi
    6bfa:	e8 c1 c7 ff ff       	call   33c0 <free@plt>
    6bff:	4c 89 e7             	mov    %r12,%rdi
    6c02:	e8 a9 fd ff ff       	call   69b0 <fwp_owned_tape_release>
    6c07:	48 63 03             	movslq (%rbx),%rax
    6c0a:	85 c0                	test   %eax,%eax
    6c0c:	0f 88 ba 00 00 00    	js     6ccc <fwp_tape_scope_release+0x12c>
    6c12:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6c16:	48 8b 35 f3 94 01 00 	mov    0x194f3(%rip),%rsi        # 20110 <fwp_tapes>
    6c1d:	4c 01 c6             	add    %r8,%rsi
    6c20:	48 89 f7             	mov    %rsi,%rdi
    6c23:	e8 d8 cf ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6c28:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6c2d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6c32:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6c39:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6c3d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6c41:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6c48:	00 
    6c49:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6c4e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6c52:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6c57:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6c5b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6c60:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6c67:	00 
    6c68:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6c6f:	00 
    6c70:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6c77:	00 
    6c78:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6c7d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6c82:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6c86:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6c8a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6c8e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6c94:	77 18                	ja     6cae <fwp_tape_scope_release+0x10e>
    6c96:	49 c1 f8 03          	sar    $0x3,%r8
    6c9a:	4c 0f af c5          	imul   %rbp,%r8
    6c9e:	4c 3b 05 53 94 01 00 	cmp    0x19453(%rip),%r8        # 200f8 <fwp_tape_next_slot>
    6ca5:	7d 07                	jge    6cae <fwp_tape_scope_release+0x10e>
    6ca7:	4c 89 05 4a 94 01 00 	mov    %r8,0x1944a(%rip)        # 200f8 <fwp_tape_next_slot>
    6cae:	4d 85 e4             	test   %r12,%r12
    6cb1:	0f 85 29 ff ff ff    	jne    6be0 <fwp_tape_scope_release+0x40>
    6cb7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6cbc:	e8 0f e4 ff ff       	call   50d0 <fwp_tape_buffers_release>
    6cc1:	48 63 03             	movslq (%rbx),%rax
    6cc4:	85 c0                	test   %eax,%eax
    6cc6:	0f 89 46 ff ff ff    	jns    6c12 <fwp_tape_scope_release+0x72>
    6ccc:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6cd1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6cd8:	00 00 
    6cda:	75 0b                	jne    6ce7 <fwp_tape_scope_release+0x147>
    6cdc:	48 83 c4 58          	add    $0x58,%rsp
    6ce0:	5b                   	pop    %rbx
    6ce1:	5d                   	pop    %rbp
    6ce2:	41 5c                	pop    %r12
    6ce4:	41 5d                	pop    %r13
    6ce6:	c3                   	ret
    6ce7:	e8 74 c7 ff ff       	call   3460 <__stack_chk_fail@plt>
    6cec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006cf0 <fwp_drop4>:
    6cf0:	48 8b 0d c1 ae 01 00 	mov    0x1aec1(%rip),%rcx        # 21bb8 <fwp_heap+0x13d8>
    6cf7:	48 89 f8             	mov    %rdi,%rax
    6cfa:	48 2b 05 8f ae 01 00 	sub    0x1ae8f(%rip),%rax        # 21b90 <fwp_heap+0x13b0>
    6d01:	48 c1 e1 10          	shl    $0x10,%rcx
    6d05:	48 39 c8             	cmp    %rcx,%rax
    6d08:	0f 83 42 01 00 00    	jae    6e50 <fwp_drop4+0x160>
    6d0e:	48 83 ec 18          	sub    $0x18,%rsp
    6d12:	48 89 fa             	mov    %rdi,%rdx
    6d15:	4c 8d 05 c4 9a 01 00 	lea    0x19ac4(%rip),%r8        # 207e0 <fwp_heap>
    6d1c:	48 89 c1             	mov    %rax,%rcx
    6d1f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    6d26:	48 c1 e9 10          	shr    $0x10,%rcx
    6d2a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6d2e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6d32:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6d36:	48 85 c9             	test   %rcx,%rcx
    6d39:	74 40                	je     6d7b <fwp_drop4+0x8b>
    6d3b:	0f b6 3e             	movzbl (%rsi),%edi
    6d3e:	40 80 ff 02          	cmp    $0x2,%dil
    6d42:	74 3c                	je     6d80 <fwp_drop4+0x90>
    6d44:	40 80 ff 01          	cmp    $0x1,%dil
    6d48:	75 31                	jne    6d7b <fwp_drop4+0x8b>
    6d4a:	8b 7e 18             	mov    0x18(%rsi),%edi
    6d4d:	0f b7 c0             	movzwl %ax,%eax
    6d50:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6d53:	48 0f af c7          	imul   %rdi,%rax
    6d57:	48 c1 e8 20          	shr    $0x20,%rax
    6d5b:	48 39 f0             	cmp    %rsi,%rax
    6d5e:	73 1b                	jae    6d7b <fwp_drop4+0x8b>
    6d60:	48 01 c1             	add    %rax,%rcx
    6d63:	0f b6 01             	movzbl (%rcx),%eax
    6d66:	84 c0                	test   %al,%al
    6d68:	74 11                	je     6d7b <fwp_drop4+0x8b>
    6d6a:	3c 01                	cmp    $0x1,%al
    6d6c:	74 22                	je     6d90 <fwp_drop4+0xa0>
    6d6e:	3c ff                	cmp    $0xff,%al
    6d70:	0f 84 0a 01 00 00    	je     6e80 <fwp_drop4+0x190>
    6d76:	83 e8 01             	sub    $0x1,%eax
    6d79:	88 01                	mov    %al,(%rcx)
    6d7b:	48 83 c4 18          	add    $0x18,%rsp
    6d7f:	c3                   	ret
    6d80:	66 85 c0             	test   %ax,%ax
    6d83:	74 de                	je     6d63 <fwp_drop4+0x73>
    6d85:	48 83 c4 18          	add    $0x18,%rsp
    6d89:	c3                   	ret
    6d8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d90:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6d94:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    6d9b:	48 89 f8             	mov    %rdi,%rax
    6d9e:	48 c1 e1 10          	shl    $0x10,%rcx
    6da2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6da9:	48 39 c8             	cmp    %rcx,%rax
    6dac:	73 62                	jae    6e10 <fwp_drop4+0x120>
    6dae:	48 89 c1             	mov    %rax,%rcx
    6db1:	48 c1 e9 10          	shr    $0x10,%rcx
    6db5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6db9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6dbd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6dc1:	48 85 c9             	test   %rcx,%rcx
    6dc4:	74 4a                	je     6e10 <fwp_drop4+0x120>
    6dc6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    6dca:	41 80 f9 02          	cmp    $0x2,%r9b
    6dce:	0f 84 9c 00 00 00    	je     6e70 <fwp_drop4+0x180>
    6dd4:	41 80 f9 01          	cmp    $0x1,%r9b
    6dd8:	75 36                	jne    6e10 <fwp_drop4+0x120>
    6dda:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    6dde:	0f b7 c0             	movzwl %ax,%eax
    6de1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6de4:	49 0f af c1          	imul   %r9,%rax
    6de8:	48 c1 e8 20          	shr    $0x20,%rax
    6dec:	48 39 f0             	cmp    %rsi,%rax
    6def:	73 1f                	jae    6e10 <fwp_drop4+0x120>
    6df1:	48 01 c1             	add    %rax,%rcx
    6df4:	0f b6 01             	movzbl (%rcx),%eax
    6df7:	84 c0                	test   %al,%al
    6df9:	74 15                	je     6e10 <fwp_drop4+0x120>
    6dfb:	3c 01                	cmp    $0x1,%al
    6dfd:	74 59                	je     6e58 <fwp_drop4+0x168>
    6dff:	3c ff                	cmp    $0xff,%al
    6e01:	0f 84 ff 00 00 00    	je     6f06 <fwp_drop4+0x216>
    6e07:	83 e8 01             	sub    $0x1,%eax
    6e0a:	88 01                	mov    %al,(%rcx)
    6e0c:	0f 1f 40 00          	nopl   0x0(%rax)
    6e10:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    6e14:	48 89 d7             	mov    %rdx,%rdi
    6e17:	48 89 0c 24          	mov    %rcx,(%rsp)
    6e1b:	e8 40 f7 ff ff       	call   6560 <fwp_rc_free_obj>
    6e20:	4c 8d 05 b9 99 01 00 	lea    0x199b9(%rip),%r8        # 207e0 <fwp_heap>
    6e27:	48 8b 04 24          	mov    (%rsp),%rax
    6e2b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6e32:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6e39:	48 c1 e2 10          	shl    $0x10,%rdx
    6e3d:	48 39 d0             	cmp    %rdx,%rax
    6e40:	0f 83 35 ff ff ff    	jae    6d7b <fwp_drop4+0x8b>
    6e46:	48 8b 14 24          	mov    (%rsp),%rdx
    6e4a:	e9 cd fe ff ff       	jmp    6d1c <fwp_drop4+0x2c>
    6e4f:	90                   	nop
    6e50:	c3                   	ret
    6e51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e58:	48 89 14 24          	mov    %rdx,(%rsp)
    6e5c:	e8 ff f6 ff ff       	call   6560 <fwp_rc_free_obj>
    6e61:	48 8b 14 24          	mov    (%rsp),%rdx
    6e65:	eb a9                	jmp    6e10 <fwp_drop4+0x120>
    6e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6e6e:	00 00 
    6e70:	66 85 c0             	test   %ax,%ax
    6e73:	75 9b                	jne    6e10 <fwp_drop4+0x120>
    6e75:	e9 7a ff ff ff       	jmp    6df4 <fwp_drop4+0x104>
    6e7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6e80:	48 89 c8             	mov    %rcx,%rax
    6e83:	48 c1 e8 11          	shr    $0x11,%rax
    6e87:	48 31 c8             	xor    %rcx,%rax
    6e8a:	48 89 c2             	mov    %rax,%rdx
    6e8d:	48 c1 ea 09          	shr    $0x9,%rdx
    6e91:	48 31 d0             	xor    %rdx,%rax
    6e94:	0f b6 d0             	movzbl %al,%edx
    6e97:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    6e9e:	00 
    6e9f:	48 85 c0             	test   %rax,%rax
    6ea2:	75 29                	jne    6ecd <fwp_drop4+0x1dd>
    6ea4:	e9 e3 00 00 00       	jmp    6f8c <fwp_drop4+0x29c>
    6ea9:	90                   	nop
    6eaa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6eb1:	00 00 00 00 
    6eb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6ebc:	00 00 00 00 
    6ec0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6ec4:	48 85 c0             	test   %rax,%rax
    6ec7:	0f 84 bf 00 00 00    	je     6f8c <fwp_drop4+0x29c>
    6ecd:	48 89 c2             	mov    %rax,%rdx
    6ed0:	48 39 08             	cmp    %rcx,(%rax)
    6ed3:	75 eb                	jne    6ec0 <fwp_drop4+0x1d0>
    6ed5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    6ed9:	48 83 ea 01          	sub    $0x1,%rdx
    6edd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6ee1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6ee8:	0f 85 8d fe ff ff    	jne    6d7b <fwp_drop4+0x8b>
    6eee:	48 89 cf             	mov    %rcx,%rdi
    6ef1:	48 89 0c 24          	mov    %rcx,(%rsp)
    6ef5:	e8 b6 e6 ff ff       	call   55b0 <fwp_rc_forget_slot>
    6efa:	48 8b 0c 24          	mov    (%rsp),%rcx
    6efe:	c6 01 fe             	movb   $0xfe,(%rcx)
    6f01:	e9 75 fe ff ff       	jmp    6d7b <fwp_drop4+0x8b>
    6f06:	48 89 ce             	mov    %rcx,%rsi
    6f09:	48 c1 ee 11          	shr    $0x11,%rsi
    6f0d:	48 31 ce             	xor    %rcx,%rsi
    6f10:	48 89 f0             	mov    %rsi,%rax
    6f13:	48 c1 e8 09          	shr    $0x9,%rax
    6f17:	48 31 c6             	xor    %rax,%rsi
    6f1a:	40 0f b6 f6          	movzbl %sil,%esi
    6f1e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    6f25:	00 
    6f26:	48 85 c0             	test   %rax,%rax
    6f29:	75 1e                	jne    6f49 <fwp_drop4+0x259>
    6f2b:	eb 5f                	jmp    6f8c <fwp_drop4+0x29c>
    6f2d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6f34:	00 
    6f35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f3c:	00 00 00 00 
    6f40:	48 8b 46 10          	mov    0x10(%rsi),%rax
    6f44:	48 85 c0             	test   %rax,%rax
    6f47:	74 43                	je     6f8c <fwp_drop4+0x29c>
    6f49:	48 89 c6             	mov    %rax,%rsi
    6f4c:	48 39 08             	cmp    %rcx,(%rax)
    6f4f:	75 ef                	jne    6f40 <fwp_drop4+0x250>
    6f51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6f55:	48 83 ee 01          	sub    $0x1,%rsi
    6f59:	48 89 70 08          	mov    %rsi,0x8(%rax)
    6f5d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    6f64:	0f 85 a6 fe ff ff    	jne    6e10 <fwp_drop4+0x120>
    6f6a:	48 89 cf             	mov    %rcx,%rdi
    6f6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6f72:	48 89 0c 24          	mov    %rcx,(%rsp)
    6f76:	e8 35 e6 ff ff       	call   55b0 <fwp_rc_forget_slot>
    6f7b:	48 8b 0c 24          	mov    (%rsp),%rcx
    6f7f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6f84:	c6 01 fe             	movb   $0xfe,(%rcx)
    6f87:	e9 84 fe ff ff       	jmp    6e10 <fwp_drop4+0x120>
    6f8c:	48 8d 3d fd 58 00 00 	lea    0x58fd(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    6f93:	e8 58 d4 ff ff       	call   43f0 <fwp_trap>
    6f98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6f9f:	00 

0000000000006fa0 <fwp_arg_drop37>:
    6fa0:	f3 0f 1e fa          	endbr64
    6fa4:	85 f6                	test   %esi,%esi
    6fa6:	75 04                	jne    6fac <fwp_arg_drop37+0xc>
    6fa8:	85 d2                	test   %edx,%edx
    6faa:	75 04                	jne    6fb0 <fwp_arg_drop37+0x10>
    6fac:	c3                   	ret
    6fad:	0f 1f 00             	nopl   (%rax)
    6fb0:	48 8b 3f             	mov    (%rdi),%rdi
    6fb3:	e9 38 fd ff ff       	jmp    6cf0 <fwp_drop4>
    6fb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6fbf:	00 

0000000000006fc0 <fwp_task_dispose>:
    6fc0:	53                   	push   %rbx
    6fc1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6fc5:	0f 84 7b c7 ff ff    	je     3746 <fwp_task_dispose.cold>
    6fcb:	48 89 fb             	mov    %rdi,%rbx
    6fce:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6fd3:	0f 85 6d c7 ff ff    	jne    3746 <fwp_task_dispose.cold>
    6fd9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6fdd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6fe4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6feb:	00 
    6fec:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6ff0:	48 85 ff             	test   %rdi,%rdi
    6ff3:	74 07                	je     6ffc <fwp_task_dispose+0x3c>
    6ff5:	48 85 c0             	test   %rax,%rax
    6ff8:	74 02                	je     6ffc <fwp_task_dispose+0x3c>
    6ffa:	ff d0                	call   *%rax
    6ffc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7003:	e8 e8 e7 ff ff       	call   57f0 <fwp_mem_free>
    7008:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    700f:	00 00 00 00 
    7013:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7017:	74 6f                	je     7088 <fwp_task_dispose+0xc8>
    7019:	48 8b 15 98 ab 01 00 	mov    0x1ab98(%rip),%rdx        # 21bb8 <fwp_heap+0x13d8>
    7020:	48 89 d8             	mov    %rbx,%rax
    7023:	48 2b 05 66 ab 01 00 	sub    0x1ab66(%rip),%rax        # 21b90 <fwp_heap+0x13b0>
    702a:	48 c1 e2 10          	shl    $0x10,%rdx
    702e:	48 39 d0             	cmp    %rdx,%rax
    7031:	73 4c                	jae    707f <fwp_task_dispose+0xbf>
    7033:	48 89 c2             	mov    %rax,%rdx
    7036:	48 c1 ea 10          	shr    $0x10,%rdx
    703a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    703e:	48 8b 15 93 ab 01 00 	mov    0x1ab93(%rip),%rdx        # 21bd8 <fwp_heap+0x13f8>
    7045:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7049:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    704d:	48 85 c9             	test   %rcx,%rcx
    7050:	74 2d                	je     707f <fwp_task_dispose+0xbf>
    7052:	0f b6 32             	movzbl (%rdx),%esi
    7055:	40 80 fe 02          	cmp    $0x2,%sil
    7059:	74 3d                	je     7098 <fwp_task_dispose+0xd8>
    705b:	40 80 fe 01          	cmp    $0x1,%sil
    705f:	75 1e                	jne    707f <fwp_task_dispose+0xbf>
    7061:	8b 72 18             	mov    0x18(%rdx),%esi
    7064:	0f b7 c0             	movzwl %ax,%eax
    7067:	8b 52 1c             	mov    0x1c(%rdx),%edx
    706a:	48 0f af c6          	imul   %rsi,%rax
    706e:	48 c1 e8 20          	shr    $0x20,%rax
    7072:	48 39 d0             	cmp    %rdx,%rax
    7075:	73 08                	jae    707f <fwp_task_dispose+0xbf>
    7077:	48 01 c1             	add    %rax,%rcx
    707a:	80 39 01             	cmpb   $0x1,(%rcx)
    707d:	74 09                	je     7088 <fwp_task_dispose+0xc8>
    707f:	5b                   	pop    %rbx
    7080:	c3                   	ret
    7081:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7088:	48 89 df             	mov    %rbx,%rdi
    708b:	5b                   	pop    %rbx
    708c:	e9 5f e7 ff ff       	jmp    57f0 <fwp_mem_free>
    7091:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7098:	66 85 c0             	test   %ax,%ax
    709b:	74 dd                	je     707a <fwp_task_dispose+0xba>
    709d:	5b                   	pop    %rbx
    709e:	c3                   	ret
    709f:	90                   	nop

00000000000070a0 <fwp_free_zombie>:
    70a0:	48 8b 15 09 97 01 00 	mov    0x19709(%rip),%rdx        # 207b0 <fwp_zombie>
    70a7:	48 85 d2             	test   %rdx,%rdx
    70aa:	0f 84 98 00 00 00    	je     7148 <fwp_free_zombie+0xa8>
    70b0:	48 3b 15 09 97 01 00 	cmp    0x19709(%rip),%rdx        # 207c0 <fwp_cur>
    70b7:	0f 84 8b 00 00 00    	je     7148 <fwp_free_zombie+0xa8>
    70bd:	48 83 ec 18          	sub    $0x18,%rsp
    70c1:	48 63 05 bc 90 01 00 	movslq 0x190bc(%rip),%rax        # 20184 <fwp_stack_pool_n>
    70c8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    70cc:	83 f8 3f             	cmp    $0x3f,%eax
    70cf:	7f 7f                	jg     7150 <fwp_free_zombie+0xb0>
    70d1:	8d 48 01             	lea    0x1(%rax),%ecx
    70d4:	89 0d aa 90 01 00    	mov    %ecx,0x190aa(%rip)        # 20184 <fwp_stack_pool_n>
    70da:	48 8d 0d bf 90 01 00 	lea    0x190bf(%rip),%rcx        # 201a0 <fwp_stack_pool>
    70e1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    70e5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    70ec:	66 0f ef c0          	pxor   %xmm0,%xmm0
    70f0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    70f7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    70fb:	48 85 c9             	test   %rcx,%rcx
    70fe:	0f 84 fc 00 00 00    	je     7200 <fwp_free_zombie+0x160>
    7104:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    710b:	48 85 c0             	test   %rax,%rax
    710e:	74 07                	je     7117 <fwp_free_zombie+0x77>
    7110:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7117:	8b 42 5c             	mov    0x5c(%rdx),%eax
    711a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    711e:	48 c7 05 87 96 01 00 	movq   $0x0,0x19687(%rip)        # 207b0 <fwp_zombie>
    7125:	00 00 00 00 
    7129:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7130:	85 c0                	test   %eax,%eax
    7132:	74 34                	je     7168 <fwp_free_zombie+0xc8>
    7134:	83 f8 01             	cmp    $0x1,%eax
    7137:	0f 84 b3 00 00 00    	je     71f0 <fwp_free_zombie+0x150>
    713d:	48 83 c4 18          	add    $0x18,%rsp
    7141:	c3                   	ret
    7142:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7148:	c3                   	ret
    7149:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7150:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7154:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7159:	e8 82 c4 ff ff       	call   35e0 <munmap@plt>
    715e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7163:	eb 80                	jmp    70e5 <fwp_free_zombie+0x45>
    7165:	0f 1f 00             	nopl   (%rax)
    7168:	48 8b 0d 49 aa 01 00 	mov    0x1aa49(%rip),%rcx        # 21bb8 <fwp_heap+0x13d8>
    716f:	48 89 d0             	mov    %rdx,%rax
    7172:	48 2b 05 17 aa 01 00 	sub    0x1aa17(%rip),%rax        # 21b90 <fwp_heap+0x13b0>
    7179:	48 c1 e1 10          	shl    $0x10,%rcx
    717d:	48 39 c8             	cmp    %rcx,%rax
    7180:	73 bb                	jae    713d <fwp_free_zombie+0x9d>
    7182:	48 89 c1             	mov    %rax,%rcx
    7185:	48 c1 e9 10          	shr    $0x10,%rcx
    7189:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    718d:	48 8b 0d 44 aa 01 00 	mov    0x1aa44(%rip),%rcx        # 21bd8 <fwp_heap+0x13f8>
    7194:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7198:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    719c:	48 85 c9             	test   %rcx,%rcx
    719f:	74 9c                	je     713d <fwp_free_zombie+0x9d>
    71a1:	0f b6 3e             	movzbl (%rsi),%edi
    71a4:	40 80 ff 02          	cmp    $0x2,%dil
    71a8:	74 66                	je     7210 <fwp_free_zombie+0x170>
    71aa:	40 80 ff 01          	cmp    $0x1,%dil
    71ae:	75 8d                	jne    713d <fwp_free_zombie+0x9d>
    71b0:	8b 7e 18             	mov    0x18(%rsi),%edi
    71b3:	0f b7 c0             	movzwl %ax,%eax
    71b6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    71b9:	48 0f af c7          	imul   %rdi,%rax
    71bd:	48 c1 e8 20          	shr    $0x20,%rax
    71c1:	48 39 f0             	cmp    %rsi,%rax
    71c4:	0f 83 73 ff ff ff    	jae    713d <fwp_free_zombie+0x9d>
    71ca:	48 01 c1             	add    %rax,%rcx
    71cd:	0f b6 01             	movzbl (%rcx),%eax
    71d0:	84 c0                	test   %al,%al
    71d2:	0f 84 65 ff ff ff    	je     713d <fwp_free_zombie+0x9d>
    71d8:	3c 01                	cmp    $0x1,%al
    71da:	74 14                	je     71f0 <fwp_free_zombie+0x150>
    71dc:	3c ff                	cmp    $0xff,%al
    71de:	74 3b                	je     721b <fwp_free_zombie+0x17b>
    71e0:	83 e8 01             	sub    $0x1,%eax
    71e3:	88 01                	mov    %al,(%rcx)
    71e5:	e9 53 ff ff ff       	jmp    713d <fwp_free_zombie+0x9d>
    71ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    71f0:	48 89 d7             	mov    %rdx,%rdi
    71f3:	48 83 c4 18          	add    $0x18,%rsp
    71f7:	e9 c4 fd ff ff       	jmp    6fc0 <fwp_task_dispose>
    71fc:	0f 1f 40 00          	nopl   0x0(%rax)
    7200:	48 89 05 81 95 01 00 	mov    %rax,0x19581(%rip)        # 20788 <fwp_tasks_active>
    7207:	e9 ff fe ff ff       	jmp    710b <fwp_free_zombie+0x6b>
    720c:	0f 1f 40 00          	nopl   0x0(%rax)
    7210:	66 85 c0             	test   %ax,%ax
    7213:	0f 85 24 ff ff ff    	jne    713d <fwp_free_zombie+0x9d>
    7219:	eb b2                	jmp    71cd <fwp_free_zombie+0x12d>
    721b:	48 89 ca             	mov    %rcx,%rdx
    721e:	48 8d 35 bb 95 01 00 	lea    0x195bb(%rip),%rsi        # 207e0 <fwp_heap>
    7225:	48 c1 ea 11          	shr    $0x11,%rdx
    7229:	48 31 ca             	xor    %rcx,%rdx
    722c:	48 89 d0             	mov    %rdx,%rax
    722f:	48 c1 e8 09          	shr    $0x9,%rax
    7233:	48 31 c2             	xor    %rax,%rdx
    7236:	0f b6 d2             	movzbl %dl,%edx
    7239:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7240:	00 
    7241:	48 85 c0             	test   %rax,%rax
    7244:	75 23                	jne    7269 <fwp_free_zombie+0x1c9>
    7246:	eb 5c                	jmp    72a4 <fwp_free_zombie+0x204>
    7248:	66 90                	xchg   %ax,%ax
    724a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7251:	00 00 00 00 
    7255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    725c:	00 00 00 00 
    7260:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7264:	48 85 c0             	test   %rax,%rax
    7267:	74 3b                	je     72a4 <fwp_free_zombie+0x204>
    7269:	48 89 c2             	mov    %rax,%rdx
    726c:	48 39 08             	cmp    %rcx,(%rax)
    726f:	75 ef                	jne    7260 <fwp_free_zombie+0x1c0>
    7271:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7275:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7279:	48 89 50 08          	mov    %rdx,0x8(%rax)
    727d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7284:	0f 85 b3 fe ff ff    	jne    713d <fwp_free_zombie+0x9d>
    728a:	48 89 cf             	mov    %rcx,%rdi
    728d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7292:	e8 19 e3 ff ff       	call   55b0 <fwp_rc_forget_slot>
    7297:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    729c:	c6 01 fe             	movb   $0xfe,(%rcx)
    729f:	e9 99 fe ff ff       	jmp    713d <fwp_free_zombie+0x9d>
    72a4:	48 8d 3d e5 55 00 00 	lea    0x55e5(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    72ab:	e8 40 d1 ff ff       	call   43f0 <fwp_trap>

00000000000072b0 <fwp_block>:
    72b0:	48 83 ec 08          	sub    $0x8,%rsp
    72b4:	48 8b 05 ed 94 01 00 	mov    0x194ed(%rip),%rax        # 207a8 <fwp_ready_head>
    72bb:	48 85 c0             	test   %rax,%rax
    72be:	0f 84 1c 01 00 00    	je     73e0 <fwp_block+0x130>
    72c4:	90                   	nop
    72c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    72cc:	00 00 00 00 
    72d0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    72d7:	48 89 15 ca 94 01 00 	mov    %rdx,0x194ca(%rip)        # 207a8 <fwp_ready_head>
    72de:	48 85 d2             	test   %rdx,%rdx
    72e1:	0f 84 19 01 00 00    	je     7400 <fwp_block+0x150>
    72e7:	48 8b 15 d2 94 01 00 	mov    0x194d2(%rip),%rdx        # 207c0 <fwp_cur>
    72ee:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    72f2:	48 39 c2             	cmp    %rax,%rdx
    72f5:	0f 84 d5 00 00 00    	je     73d0 <fwp_block+0x120>
    72fb:	48 8b 0d 46 b1 01 00 	mov    0x1b146(%rip),%rcx        # 22448 <fwp_state_owners>
    7302:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7306:	48 89 05 b3 94 01 00 	mov    %rax,0x194b3(%rip)        # 207c0 <fwp_cur>
    730d:	f3 0f 7e 05 5b b1 01 	movq   0x1b15b(%rip),%xmm0        # 22470 <fwp_foreign_callbacks>
    7314:	00 
    7315:	0f 16 05 44 b1 01 00 	movhps 0x1b144(%rip),%xmm0        # 22460 <fwp_state>
    731c:	f3 0f 7e 0d 44 b1 01 	movq   0x1b144(%rip),%xmm1        # 22468 <fwp_handlers>
    7323:	00 
    7324:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    732b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7332:	0f 16 0d 3f b1 01 00 	movhps 0x1b13f(%rip),%xmm1        # 22478 <fwp_cleanups>
    7339:	f3 0f 7e 05 17 b1 01 	movq   0x1b117(%rip),%xmm0        # 22458 <fwp_state_len>
    7340:	00 
    7341:	0f 16 05 08 b1 01 00 	movhps 0x1b108(%rip),%xmm0        # 22450 <fwp_state_cap>
    7348:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    734f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7356:	48 8b 70 08          	mov    0x8(%rax),%rsi
    735a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7361:	48 89 0d 00 b1 01 00 	mov    %rcx,0x1b100(%rip)        # 22468 <fwp_handlers>
    7368:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    736f:	48 89 0d 02 b1 01 00 	mov    %rcx,0x1b102(%rip)        # 22478 <fwp_cleanups>
    7376:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    737d:	48 89 0d ec b0 01 00 	mov    %rcx,0x1b0ec(%rip)        # 22470 <fwp_foreign_callbacks>
    7384:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    738b:	48 89 0d ce b0 01 00 	mov    %rcx,0x1b0ce(%rip)        # 22460 <fwp_state>
    7392:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7399:	48 89 0d b8 b0 01 00 	mov    %rcx,0x1b0b8(%rip)        # 22458 <fwp_state_len>
    73a0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    73a7:	48 89 0d a2 b0 01 00 	mov    %rcx,0x1b0a2(%rip)        # 22450 <fwp_state_cap>
    73ae:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    73b5:	48 89 0d 8c b0 01 00 	mov    %rcx,0x1b08c(%rip)        # 22448 <fwp_state_owners>
    73bc:	e8 cf c0 ff ff       	call   3490 <swapcontext@plt>
    73c1:	f3 0f 1e fa          	endbr64
    73c5:	e8 d6 fc ff ff       	call   70a0 <fwp_free_zombie>
    73ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    73d0:	8b 05 aa 8d 01 00    	mov    0x18daa(%rip),%eax        # 20180 <fwp_slice>
    73d6:	85 c0                	test   %eax,%eax
    73d8:	74 36                	je     7410 <fwp_block+0x160>
    73da:	48 83 c4 08          	add    $0x8,%rsp
    73de:	c3                   	ret
    73df:	90                   	nop
    73e0:	e8 1b de ff ff       	call   5200 <fwp_poll_events>
    73e5:	48 8b 05 bc 93 01 00 	mov    0x193bc(%rip),%rax        # 207a8 <fwp_ready_head>
    73ec:	48 85 c0             	test   %rax,%rax
    73ef:	0f 85 db fe ff ff    	jne    72d0 <fwp_block+0x20>
    73f5:	eb e9                	jmp    73e0 <fwp_block+0x130>
    73f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    73fe:	00 00 
    7400:	48 c7 05 95 93 01 00 	movq   $0x0,0x19395(%rip)        # 207a0 <fwp_ready_tail>
    7407:	00 00 00 00 
    740b:	e9 d7 fe ff ff       	jmp    72e7 <fwp_block+0x37>
    7410:	48 8d 3d 6d 4d 00 00 	lea    0x4d6d(%rip),%rdi        # c184 <_IO_stdin_used+0x184>
    7417:	e8 84 bf ff ff       	call   33a0 <getenv@plt>
    741c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7421:	48 85 c0             	test   %rax,%rax
    7424:	74 05                	je     742b <fwp_block+0x17b>
    7426:	80 38 00             	cmpb   $0x0,(%rax)
    7429:	75 0b                	jne    7436 <fwp_block+0x186>
    742b:	89 15 4f 8d 01 00    	mov    %edx,0x18d4f(%rip)        # 20180 <fwp_slice>
    7431:	48 83 c4 08          	add    $0x8,%rsp
    7435:	c3                   	ret
    7436:	ba 0a 00 00 00       	mov    $0xa,%edx
    743b:	31 f6                	xor    %esi,%esi
    743d:	48 89 c7             	mov    %rax,%rdi
    7440:	e8 0b c1 ff ff       	call   3550 <strtoll@plt>
    7445:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7449:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7450:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7455:	0f 46 d0             	cmovbe %eax,%edx
    7458:	eb d1                	jmp    742b <fwp_block+0x17b>
    745a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007460 <fwp_caps173>:
    7460:	f3 0f 1e fa          	endbr64
    7464:	85 f6                	test   %esi,%esi
    7466:	74 08                	je     7470 <fwp_caps173+0x10>
    7468:	c3                   	ret
    7469:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7470:	48 8b 15 41 a7 01 00 	mov    0x1a741(%rip),%rdx        # 21bb8 <fwp_heap+0x13d8>
    7477:	48 89 f8             	mov    %rdi,%rax
    747a:	48 2b 05 0f a7 01 00 	sub    0x1a70f(%rip),%rax        # 21b90 <fwp_heap+0x13b0>
    7481:	48 c1 e2 10          	shl    $0x10,%rdx
    7485:	48 39 d0             	cmp    %rdx,%rax
    7488:	73 de                	jae    7468 <fwp_caps173+0x8>
    748a:	48 89 c2             	mov    %rax,%rdx
    748d:	48 c1 ea 10          	shr    $0x10,%rdx
    7491:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7495:	48 8b 15 3c a7 01 00 	mov    0x1a73c(%rip),%rdx        # 21bd8 <fwp_heap+0x13f8>
    749c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    74a0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    74a4:	48 85 c9             	test   %rcx,%rcx
    74a7:	74 bf                	je     7468 <fwp_caps173+0x8>
    74a9:	0f b6 32             	movzbl (%rdx),%esi
    74ac:	40 80 fe 02          	cmp    $0x2,%sil
    74b0:	74 2e                	je     74e0 <fwp_caps173+0x80>
    74b2:	40 80 fe 01          	cmp    $0x1,%sil
    74b6:	75 b0                	jne    7468 <fwp_caps173+0x8>
    74b8:	8b 72 18             	mov    0x18(%rdx),%esi
    74bb:	0f b7 c0             	movzwl %ax,%eax
    74be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    74c1:	48 0f af c6          	imul   %rsi,%rax
    74c5:	48 c1 e8 20          	shr    $0x20,%rax
    74c9:	48 39 d0             	cmp    %rdx,%rax
    74cc:	73 9a                	jae    7468 <fwp_caps173+0x8>
    74ce:	48 01 c1             	add    %rax,%rcx
    74d1:	80 39 01             	cmpb   $0x1,(%rcx)
    74d4:	75 92                	jne    7468 <fwp_caps173+0x8>
    74d6:	e9 15 e3 ff ff       	jmp    57f0 <fwp_mem_free>
    74db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    74e0:	66 85 c0             	test   %ax,%ax
    74e3:	74 ec                	je     74d1 <fwp_caps173+0x71>
    74e5:	c3                   	ret
    74e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    74ed:	00 00 00 

00000000000074f0 <fwp_args37>:
    74f0:	f3 0f 1e fa          	endbr64
    74f4:	85 d2                	test   %edx,%edx
    74f6:	74 04                	je     74fc <fwp_args37+0xc>
    74f8:	85 f6                	test   %esi,%esi
    74fa:	74 04                	je     7500 <fwp_args37+0x10>
    74fc:	c3                   	ret
    74fd:	0f 1f 00             	nopl   (%rax)
    7500:	48 8b 15 b1 a6 01 00 	mov    0x1a6b1(%rip),%rdx        # 21bb8 <fwp_heap+0x13d8>
    7507:	48 8b 07             	mov    (%rdi),%rax
    750a:	48 2b 05 7f a6 01 00 	sub    0x1a67f(%rip),%rax        # 21b90 <fwp_heap+0x13b0>
    7511:	48 c1 e2 10          	shl    $0x10,%rdx
    7515:	48 39 d0             	cmp    %rdx,%rax
    7518:	73 e2                	jae    74fc <fwp_args37+0xc>
    751a:	48 89 c2             	mov    %rax,%rdx
    751d:	48 c1 ea 10          	shr    $0x10,%rdx
    7521:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7525:	48 8b 15 ac a6 01 00 	mov    0x1a6ac(%rip),%rdx        # 21bd8 <fwp_heap+0x13f8>
    752c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7530:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7534:	48 85 ff             	test   %rdi,%rdi
    7537:	74 c3                	je     74fc <fwp_args37+0xc>
    7539:	0f b6 0a             	movzbl (%rdx),%ecx
    753c:	80 f9 02             	cmp    $0x2,%cl
    753f:	74 2f                	je     7570 <fwp_args37+0x80>
    7541:	80 f9 01             	cmp    $0x1,%cl
    7544:	75 b6                	jne    74fc <fwp_args37+0xc>
    7546:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7549:	0f b7 c0             	movzwl %ax,%eax
    754c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    754f:	48 0f af c1          	imul   %rcx,%rax
    7553:	48 c1 e8 20          	shr    $0x20,%rax
    7557:	48 39 d0             	cmp    %rdx,%rax
    755a:	73 a0                	jae    74fc <fwp_args37+0xc>
    755c:	48 01 c7             	add    %rax,%rdi
    755f:	0f b6 07             	movzbl (%rdi),%eax
    7562:	84 c0                	test   %al,%al
    7564:	74 96                	je     74fc <fwp_args37+0xc>
    7566:	3c fd                	cmp    $0xfd,%al
    7568:	77 0c                	ja     7576 <fwp_args37+0x86>
    756a:	83 c0 01             	add    $0x1,%eax
    756d:	88 07                	mov    %al,(%rdi)
    756f:	c3                   	ret
    7570:	66 85 c0             	test   %ax,%ax
    7573:	74 ea                	je     755f <fwp_args37+0x6f>
    7575:	c3                   	ret
    7576:	e9 15 df ff ff       	jmp    5490 <fwp_rc_wide_dup>
    757b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007580 <fwp_caps37>:
    7580:	f3 0f 1e fa          	endbr64
    7584:	48 83 ec 18          	sub    $0x18,%rsp
    7588:	8b 57 04             	mov    0x4(%rdi),%edx
    758b:	48 89 f8             	mov    %rdi,%rax
    758e:	85 d2                	test   %edx,%edx
    7590:	0f 84 9a 00 00 00    	je     7630 <fwp_caps37+0xb0>
    7596:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    759a:	85 f6                	test   %esi,%esi
    759c:	0f 85 9e 00 00 00    	jne    7640 <fwp_caps37+0xc0>
    75a2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    75a7:	e8 44 f7 ff ff       	call   6cf0 <fwp_drop4>
    75ac:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    75b1:	48 8b 0d 00 a6 01 00 	mov    0x1a600(%rip),%rcx        # 21bb8 <fwp_heap+0x13d8>
    75b8:	48 89 c2             	mov    %rax,%rdx
    75bb:	48 2b 15 ce a5 01 00 	sub    0x1a5ce(%rip),%rdx        # 21b90 <fwp_heap+0x13b0>
    75c2:	48 c1 e1 10          	shl    $0x10,%rcx
    75c6:	48 39 ca             	cmp    %rcx,%rdx
    75c9:	73 6d                	jae    7638 <fwp_caps37+0xb8>
    75cb:	48 89 d1             	mov    %rdx,%rcx
    75ce:	48 c1 e9 10          	shr    $0x10,%rcx
    75d2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    75d6:	48 8b 0d fb a5 01 00 	mov    0x1a5fb(%rip),%rcx        # 21bd8 <fwp_heap+0x13f8>
    75dd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    75e1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    75e5:	48 85 f6             	test   %rsi,%rsi
    75e8:	74 4e                	je     7638 <fwp_caps37+0xb8>
    75ea:	0f b6 39             	movzbl (%rcx),%edi
    75ed:	40 80 ff 02          	cmp    $0x2,%dil
    75f1:	0f 84 b9 00 00 00    	je     76b0 <fwp_caps37+0x130>
    75f7:	40 80 ff 01          	cmp    $0x1,%dil
    75fb:	75 3b                	jne    7638 <fwp_caps37+0xb8>
    75fd:	8b 79 18             	mov    0x18(%rcx),%edi
    7600:	0f b7 d2             	movzwl %dx,%edx
    7603:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7606:	48 0f af d7          	imul   %rdi,%rdx
    760a:	48 c1 ea 20          	shr    $0x20,%rdx
    760e:	48 39 ca             	cmp    %rcx,%rdx
    7611:	73 25                	jae    7638 <fwp_caps37+0xb8>
    7613:	48 01 d6             	add    %rdx,%rsi
    7616:	80 3e 01             	cmpb   $0x1,(%rsi)
    7619:	75 1d                	jne    7638 <fwp_caps37+0xb8>
    761b:	48 89 c7             	mov    %rax,%rdi
    761e:	48 83 c4 18          	add    $0x18,%rsp
    7622:	e9 c9 e1 ff ff       	jmp    57f0 <fwp_mem_free>
    7627:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    762e:	00 00 
    7630:	85 f6                	test   %esi,%esi
    7632:	0f 84 79 ff ff ff    	je     75b1 <fwp_caps37+0x31>
    7638:	48 83 c4 18          	add    $0x18,%rsp
    763c:	c3                   	ret
    763d:	0f 1f 00             	nopl   (%rax)
    7640:	48 8b 05 71 a5 01 00 	mov    0x1a571(%rip),%rax        # 21bb8 <fwp_heap+0x13d8>
    7647:	48 2b 3d 42 a5 01 00 	sub    0x1a542(%rip),%rdi        # 21b90 <fwp_heap+0x13b0>
    764e:	48 c1 e0 10          	shl    $0x10,%rax
    7652:	48 39 c7             	cmp    %rax,%rdi
    7655:	73 e1                	jae    7638 <fwp_caps37+0xb8>
    7657:	48 89 f8             	mov    %rdi,%rax
    765a:	48 c1 e8 10          	shr    $0x10,%rax
    765e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7662:	48 8b 05 6f a5 01 00 	mov    0x1a56f(%rip),%rax        # 21bd8 <fwp_heap+0x13f8>
    7669:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    766d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7671:	48 85 c0             	test   %rax,%rax
    7674:	74 c2                	je     7638 <fwp_caps37+0xb8>
    7676:	0f b6 0a             	movzbl (%rdx),%ecx
    7679:	80 f9 02             	cmp    $0x2,%cl
    767c:	74 42                	je     76c0 <fwp_caps37+0x140>
    767e:	80 f9 01             	cmp    $0x1,%cl
    7681:	75 b5                	jne    7638 <fwp_caps37+0xb8>
    7683:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7686:	0f b7 ff             	movzwl %di,%edi
    7689:	8b 52 1c             	mov    0x1c(%rdx),%edx
    768c:	48 0f af f9          	imul   %rcx,%rdi
    7690:	48 c1 ef 20          	shr    $0x20,%rdi
    7694:	48 39 d7             	cmp    %rdx,%rdi
    7697:	73 9f                	jae    7638 <fwp_caps37+0xb8>
    7699:	48 01 f8             	add    %rdi,%rax
    769c:	0f b6 10             	movzbl (%rax),%edx
    769f:	84 d2                	test   %dl,%dl
    76a1:	74 95                	je     7638 <fwp_caps37+0xb8>
    76a3:	80 fa fd             	cmp    $0xfd,%dl
    76a6:	77 23                	ja     76cb <fwp_caps37+0x14b>
    76a8:	83 c2 01             	add    $0x1,%edx
    76ab:	88 10                	mov    %dl,(%rax)
    76ad:	eb 89                	jmp    7638 <fwp_caps37+0xb8>
    76af:	90                   	nop
    76b0:	66 85 d2             	test   %dx,%dx
    76b3:	0f 85 7f ff ff ff    	jne    7638 <fwp_caps37+0xb8>
    76b9:	e9 58 ff ff ff       	jmp    7616 <fwp_caps37+0x96>
    76be:	66 90                	xchg   %ax,%ax
    76c0:	66 85 ff             	test   %di,%di
    76c3:	0f 85 6f ff ff ff    	jne    7638 <fwp_caps37+0xb8>
    76c9:	eb d1                	jmp    769c <fwp_caps37+0x11c>
    76cb:	48 89 c7             	mov    %rax,%rdi
    76ce:	48 83 c4 18          	add    $0x18,%rsp
    76d2:	e9 b9 dd ff ff       	jmp    5490 <fwp_rc_wide_dup>
    76d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    76de:	00 00 

00000000000076e0 <fwp_drop0>:
    76e0:	f3 0f 1e fa          	endbr64
    76e4:	48 8b 15 cd a4 01 00 	mov    0x1a4cd(%rip),%rdx        # 21bb8 <fwp_heap+0x13d8>
    76eb:	48 89 f8             	mov    %rdi,%rax
    76ee:	48 2b 05 9b a4 01 00 	sub    0x1a49b(%rip),%rax        # 21b90 <fwp_heap+0x13b0>
    76f5:	48 c1 e2 10          	shl    $0x10,%rdx
    76f9:	48 39 d0             	cmp    %rdx,%rax
    76fc:	0f 83 36 01 00 00    	jae    7838 <fwp_drop0+0x158>
    7702:	48 83 ec 18          	sub    $0x18,%rsp
    7706:	48 8d 35 d3 90 01 00 	lea    0x190d3(%rip),%rsi        # 207e0 <fwp_heap>
    770d:	48 89 c2             	mov    %rax,%rdx
    7710:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7717:	48 c1 ea 10          	shr    $0x10,%rdx
    771b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    771f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7723:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7727:	48 85 d2             	test   %rdx,%rdx
    772a:	74 42                	je     776e <fwp_drop0+0x8e>
    772c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7730:	41 80 f8 02          	cmp    $0x2,%r8b
    7734:	74 42                	je     7778 <fwp_drop0+0x98>
    7736:	41 80 f8 01          	cmp    $0x1,%r8b
    773a:	75 32                	jne    776e <fwp_drop0+0x8e>
    773c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7740:	0f b7 c0             	movzwl %ax,%eax
    7743:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7746:	49 0f af c0          	imul   %r8,%rax
    774a:	48 c1 e8 20          	shr    $0x20,%rax
    774e:	48 39 c8             	cmp    %rcx,%rax
    7751:	73 1b                	jae    776e <fwp_drop0+0x8e>
    7753:	48 01 c2             	add    %rax,%rdx
    7756:	0f b6 02             	movzbl (%rdx),%eax
    7759:	84 c0                	test   %al,%al
    775b:	74 11                	je     776e <fwp_drop0+0x8e>
    775d:	3c 01                	cmp    $0x1,%al
    775f:	74 27                	je     7788 <fwp_drop0+0xa8>
    7761:	3c ff                	cmp    $0xff,%al
    7763:	0f 84 e7 00 00 00    	je     7850 <fwp_drop0+0x170>
    7769:	83 e8 01             	sub    $0x1,%eax
    776c:	88 02                	mov    %al,(%rdx)
    776e:	48 83 c4 18          	add    $0x18,%rsp
    7772:	c3                   	ret
    7773:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7778:	66 85 c0             	test   %ax,%ax
    777b:	74 d9                	je     7756 <fwp_drop0+0x76>
    777d:	48 83 c4 18          	add    $0x18,%rsp
    7781:	c3                   	ret
    7782:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7788:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    778f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7796:	48 89 f8             	mov    %rdi,%rax
    7799:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    779d:	48 29 c8             	sub    %rcx,%rax
    77a0:	48 c1 e2 10          	shl    $0x10,%rdx
    77a4:	48 39 d0             	cmp    %rdx,%rax
    77a7:	73 71                	jae    781a <fwp_drop0+0x13a>
    77a9:	49 89 c2             	mov    %rax,%r10
    77ac:	49 c1 ea 10          	shr    $0x10,%r10
    77b0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    77b4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    77b8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    77bc:	4d 85 d2             	test   %r10,%r10
    77bf:	74 59                	je     781a <fwp_drop0+0x13a>
    77c1:	45 0f b6 19          	movzbl (%r9),%r11d
    77c5:	41 80 fb 02          	cmp    $0x2,%r11b
    77c9:	74 75                	je     7840 <fwp_drop0+0x160>
    77cb:	41 80 fb 01          	cmp    $0x1,%r11b
    77cf:	75 49                	jne    781a <fwp_drop0+0x13a>
    77d1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    77d5:	0f b7 c0             	movzwl %ax,%eax
    77d8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    77dc:	49 0f af c3          	imul   %r11,%rax
    77e0:	48 c1 e8 20          	shr    $0x20,%rax
    77e4:	4c 39 c8             	cmp    %r9,%rax
    77e7:	73 31                	jae    781a <fwp_drop0+0x13a>
    77e9:	49 01 c2             	add    %rax,%r10
    77ec:	41 80 3a 01          	cmpb   $0x1,(%r10)
    77f0:	75 28                	jne    781a <fwp_drop0+0x13a>
    77f2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    77f7:	e8 f4 df ff ff       	call   57f0 <fwp_mem_free>
    77fc:	48 8d 35 dd 8f 01 00 	lea    0x18fdd(%rip),%rsi        # 207e0 <fwp_heap>
    7803:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7808:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    780f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7816:	48 c1 e2 10          	shl    $0x10,%rdx
    781a:	4c 89 c0             	mov    %r8,%rax
    781d:	48 29 c8             	sub    %rcx,%rax
    7820:	48 39 d0             	cmp    %rdx,%rax
    7823:	0f 83 45 ff ff ff    	jae    776e <fwp_drop0+0x8e>
    7829:	4c 89 c7             	mov    %r8,%rdi
    782c:	e9 dc fe ff ff       	jmp    770d <fwp_drop0+0x2d>
    7831:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7838:	c3                   	ret
    7839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7840:	66 85 c0             	test   %ax,%ax
    7843:	75 d5                	jne    781a <fwp_drop0+0x13a>
    7845:	eb a5                	jmp    77ec <fwp_drop0+0x10c>
    7847:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    784e:	00 00 
    7850:	48 89 d0             	mov    %rdx,%rax
    7853:	48 c1 e8 11          	shr    $0x11,%rax
    7857:	48 31 d0             	xor    %rdx,%rax
    785a:	48 89 c1             	mov    %rax,%rcx
    785d:	48 c1 e9 09          	shr    $0x9,%rcx
    7861:	48 31 c8             	xor    %rcx,%rax
    7864:	0f b6 c8             	movzbl %al,%ecx
    7867:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    786e:	00 
    786f:	48 85 c0             	test   %rax,%rax
    7872:	75 15                	jne    7889 <fwp_drop0+0x1a9>
    7874:	eb 4e                	jmp    78c4 <fwp_drop0+0x1e4>
    7876:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    787d:	00 00 00 
    7880:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7884:	48 85 c0             	test   %rax,%rax
    7887:	74 3b                	je     78c4 <fwp_drop0+0x1e4>
    7889:	48 89 c1             	mov    %rax,%rcx
    788c:	48 39 10             	cmp    %rdx,(%rax)
    788f:	75 ef                	jne    7880 <fwp_drop0+0x1a0>
    7891:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7895:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7899:	48 89 48 08          	mov    %rcx,0x8(%rax)
    789d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    78a4:	0f 85 c4 fe ff ff    	jne    776e <fwp_drop0+0x8e>
    78aa:	48 89 d7             	mov    %rdx,%rdi
    78ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    78b2:	e8 f9 dc ff ff       	call   55b0 <fwp_rc_forget_slot>
    78b7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    78bc:	c6 02 fe             	movb   $0xfe,(%rdx)
    78bf:	e9 aa fe ff ff       	jmp    776e <fwp_drop0+0x8e>
    78c4:	48 8d 3d c5 4f 00 00 	lea    0x4fc5(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    78cb:	e8 20 cb ff ff       	call   43f0 <fwp_trap>

00000000000078d0 <fwp_drop1>:
    78d0:	f3 0f 1e fa          	endbr64
    78d4:	48 8b 15 dd a2 01 00 	mov    0x1a2dd(%rip),%rdx        # 21bb8 <fwp_heap+0x13d8>
    78db:	48 89 f8             	mov    %rdi,%rax
    78de:	48 2b 05 ab a2 01 00 	sub    0x1a2ab(%rip),%rax        # 21b90 <fwp_heap+0x13b0>
    78e5:	48 c1 e2 10          	shl    $0x10,%rdx
    78e9:	48 39 d0             	cmp    %rdx,%rax
    78ec:	0f 83 36 01 00 00    	jae    7a28 <fwp_drop1+0x158>
    78f2:	48 83 ec 18          	sub    $0x18,%rsp
    78f6:	48 8d 35 e3 8e 01 00 	lea    0x18ee3(%rip),%rsi        # 207e0 <fwp_heap>
    78fd:	48 89 c2             	mov    %rax,%rdx
    7900:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7907:	48 c1 ea 10          	shr    $0x10,%rdx
    790b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    790f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7913:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7917:	48 85 d2             	test   %rdx,%rdx
    791a:	74 42                	je     795e <fwp_drop1+0x8e>
    791c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7920:	41 80 f8 02          	cmp    $0x2,%r8b
    7924:	74 42                	je     7968 <fwp_drop1+0x98>
    7926:	41 80 f8 01          	cmp    $0x1,%r8b
    792a:	75 32                	jne    795e <fwp_drop1+0x8e>
    792c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7930:	0f b7 c0             	movzwl %ax,%eax
    7933:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7936:	49 0f af c0          	imul   %r8,%rax
    793a:	48 c1 e8 20          	shr    $0x20,%rax
    793e:	48 39 c8             	cmp    %rcx,%rax
    7941:	73 1b                	jae    795e <fwp_drop1+0x8e>
    7943:	48 01 c2             	add    %rax,%rdx
    7946:	0f b6 02             	movzbl (%rdx),%eax
    7949:	84 c0                	test   %al,%al
    794b:	74 11                	je     795e <fwp_drop1+0x8e>
    794d:	3c 01                	cmp    $0x1,%al
    794f:	74 27                	je     7978 <fwp_drop1+0xa8>
    7951:	3c ff                	cmp    $0xff,%al
    7953:	0f 84 e7 00 00 00    	je     7a40 <fwp_drop1+0x170>
    7959:	83 e8 01             	sub    $0x1,%eax
    795c:	88 02                	mov    %al,(%rdx)
    795e:	48 83 c4 18          	add    $0x18,%rsp
    7962:	c3                   	ret
    7963:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7968:	66 85 c0             	test   %ax,%ax
    796b:	74 d9                	je     7946 <fwp_drop1+0x76>
    796d:	48 83 c4 18          	add    $0x18,%rsp
    7971:	c3                   	ret
    7972:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7978:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    797f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7986:	48 89 f8             	mov    %rdi,%rax
    7989:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    798d:	48 29 c8             	sub    %rcx,%rax
    7990:	48 c1 e2 10          	shl    $0x10,%rdx
    7994:	48 39 d0             	cmp    %rdx,%rax
    7997:	73 71                	jae    7a0a <fwp_drop1+0x13a>
    7999:	49 89 c2             	mov    %rax,%r10
    799c:	49 c1 ea 10          	shr    $0x10,%r10
    79a0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    79a4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    79a8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    79ac:	4d 85 d2             	test   %r10,%r10
    79af:	74 59                	je     7a0a <fwp_drop1+0x13a>
    79b1:	45 0f b6 19          	movzbl (%r9),%r11d
    79b5:	41 80 fb 02          	cmp    $0x2,%r11b
    79b9:	74 75                	je     7a30 <fwp_drop1+0x160>
    79bb:	41 80 fb 01          	cmp    $0x1,%r11b
    79bf:	75 49                	jne    7a0a <fwp_drop1+0x13a>
    79c1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    79c5:	0f b7 c0             	movzwl %ax,%eax
    79c8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    79cc:	49 0f af c3          	imul   %r11,%rax
    79d0:	48 c1 e8 20          	shr    $0x20,%rax
    79d4:	4c 39 c8             	cmp    %r9,%rax
    79d7:	73 31                	jae    7a0a <fwp_drop1+0x13a>
    79d9:	49 01 c2             	add    %rax,%r10
    79dc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    79e0:	75 28                	jne    7a0a <fwp_drop1+0x13a>
    79e2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    79e7:	e8 04 de ff ff       	call   57f0 <fwp_mem_free>
    79ec:	48 8d 35 ed 8d 01 00 	lea    0x18ded(%rip),%rsi        # 207e0 <fwp_heap>
    79f3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    79f8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    79ff:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7a06:	48 c1 e2 10          	shl    $0x10,%rdx
    7a0a:	4c 89 c0             	mov    %r8,%rax
    7a0d:	48 29 c8             	sub    %rcx,%rax
    7a10:	48 39 d0             	cmp    %rdx,%rax
    7a13:	0f 83 45 ff ff ff    	jae    795e <fwp_drop1+0x8e>
    7a19:	4c 89 c7             	mov    %r8,%rdi
    7a1c:	e9 dc fe ff ff       	jmp    78fd <fwp_drop1+0x2d>
    7a21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a28:	c3                   	ret
    7a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a30:	66 85 c0             	test   %ax,%ax
    7a33:	75 d5                	jne    7a0a <fwp_drop1+0x13a>
    7a35:	eb a5                	jmp    79dc <fwp_drop1+0x10c>
    7a37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a3e:	00 00 
    7a40:	48 89 d0             	mov    %rdx,%rax
    7a43:	48 c1 e8 11          	shr    $0x11,%rax
    7a47:	48 31 d0             	xor    %rdx,%rax
    7a4a:	48 89 c1             	mov    %rax,%rcx
    7a4d:	48 c1 e9 09          	shr    $0x9,%rcx
    7a51:	48 31 c8             	xor    %rcx,%rax
    7a54:	0f b6 c8             	movzbl %al,%ecx
    7a57:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7a5e:	00 
    7a5f:	48 85 c0             	test   %rax,%rax
    7a62:	75 25                	jne    7a89 <fwp_drop1+0x1b9>
    7a64:	eb 5e                	jmp    7ac4 <fwp_drop1+0x1f4>
    7a66:	0f 1f 40 00          	nopl   0x0(%rax)
    7a6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7a71:	00 00 00 00 
    7a75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7a7c:	00 00 00 00 
    7a80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7a84:	48 85 c0             	test   %rax,%rax
    7a87:	74 3b                	je     7ac4 <fwp_drop1+0x1f4>
    7a89:	48 89 c1             	mov    %rax,%rcx
    7a8c:	48 39 10             	cmp    %rdx,(%rax)
    7a8f:	75 ef                	jne    7a80 <fwp_drop1+0x1b0>
    7a91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7a95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7a99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7a9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7aa4:	0f 85 b4 fe ff ff    	jne    795e <fwp_drop1+0x8e>
    7aaa:	48 89 d7             	mov    %rdx,%rdi
    7aad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7ab2:	e8 f9 da ff ff       	call   55b0 <fwp_rc_forget_slot>
    7ab7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7abc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7abf:	e9 9a fe ff ff       	jmp    795e <fwp_drop1+0x8e>
    7ac4:	48 8d 3d c5 4d 00 00 	lea    0x4dc5(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    7acb:	e8 20 c9 ff ff       	call   43f0 <fwp_trap>

0000000000007ad0 <fwp_drop10>:
    7ad0:	48 8b 0d e1 a0 01 00 	mov    0x1a0e1(%rip),%rcx        # 21bb8 <fwp_heap+0x13d8>
    7ad7:	48 89 f8             	mov    %rdi,%rax
    7ada:	48 2b 05 af a0 01 00 	sub    0x1a0af(%rip),%rax        # 21b90 <fwp_heap+0x13b0>
    7ae1:	48 c1 e1 10          	shl    $0x10,%rcx
    7ae5:	48 39 c8             	cmp    %rcx,%rax
    7ae8:	0f 83 c2 01 00 00    	jae    7cb0 <fwp_drop10+0x1e0>
    7aee:	48 83 ec 18          	sub    $0x18,%rsp
    7af2:	48 89 fa             	mov    %rdi,%rdx
    7af5:	48 8d 35 e4 8c 01 00 	lea    0x18ce4(%rip),%rsi        # 207e0 <fwp_heap>
    7afc:	48 89 c1             	mov    %rax,%rcx
    7aff:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7b06:	48 c1 e9 10          	shr    $0x10,%rcx
    7b0a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7b0e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7b12:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7b16:	48 85 c9             	test   %rcx,%rcx
    7b19:	74 46                	je     7b61 <fwp_drop10+0x91>
    7b1b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7b1f:	41 80 f9 02          	cmp    $0x2,%r9b
    7b23:	0f 84 d7 00 00 00    	je     7c00 <fwp_drop10+0x130>
    7b29:	41 80 f9 01          	cmp    $0x1,%r9b
    7b2d:	75 32                	jne    7b61 <fwp_drop10+0x91>
    7b2f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7b33:	0f b7 c0             	movzwl %ax,%eax
    7b36:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7b39:	49 0f af c1          	imul   %r9,%rax
    7b3d:	48 c1 e8 20          	shr    $0x20,%rax
    7b41:	48 39 f8             	cmp    %rdi,%rax
    7b44:	73 1b                	jae    7b61 <fwp_drop10+0x91>
    7b46:	48 01 c1             	add    %rax,%rcx
    7b49:	0f b6 01             	movzbl (%rcx),%eax
    7b4c:	84 c0                	test   %al,%al
    7b4e:	74 11                	je     7b61 <fwp_drop10+0x91>
    7b50:	3c 01                	cmp    $0x1,%al
    7b52:	74 1c                	je     7b70 <fwp_drop10+0xa0>
    7b54:	3c ff                	cmp    $0xff,%al
    7b56:	0f 84 5c 01 00 00    	je     7cb8 <fwp_drop10+0x1e8>
    7b5c:	83 e8 01             	sub    $0x1,%eax
    7b5f:	88 01                	mov    %al,(%rcx)
    7b61:	48 83 c4 18          	add    $0x18,%rsp
    7b65:	c3                   	ret
    7b66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7b6d:	00 00 00 
    7b70:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7b77:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7b7e:	48 89 d0             	mov    %rdx,%rax
    7b81:	49 89 d1             	mov    %rdx,%r9
    7b84:	48 c1 e1 10          	shl    $0x10,%rcx
    7b88:	48 29 f8             	sub    %rdi,%rax
    7b8b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7b8f:	78 7f                	js     7c10 <fwp_drop10+0x140>
    7b91:	48 39 c8             	cmp    %rcx,%rax
    7b94:	73 cb                	jae    7b61 <fwp_drop10+0x91>
    7b96:	48 89 c1             	mov    %rax,%rcx
    7b99:	48 c1 e9 10          	shr    $0x10,%rcx
    7b9d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7ba1:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7ba5:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7ba9:	48 85 f6             	test   %rsi,%rsi
    7bac:	74 b3                	je     7b61 <fwp_drop10+0x91>
    7bae:	0f b6 39             	movzbl (%rcx),%edi
    7bb1:	40 80 ff 02          	cmp    $0x2,%dil
    7bb5:	74 39                	je     7bf0 <fwp_drop10+0x120>
    7bb7:	40 80 ff 01          	cmp    $0x1,%dil
    7bbb:	75 a4                	jne    7b61 <fwp_drop10+0x91>
    7bbd:	8b 79 18             	mov    0x18(%rcx),%edi
    7bc0:	0f b7 c0             	movzwl %ax,%eax
    7bc3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7bc6:	48 0f af c7          	imul   %rdi,%rax
    7bca:	48 c1 e8 20          	shr    $0x20,%rax
    7bce:	48 39 c8             	cmp    %rcx,%rax
    7bd1:	73 8e                	jae    7b61 <fwp_drop10+0x91>
    7bd3:	48 01 c6             	add    %rax,%rsi
    7bd6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7bd9:	75 86                	jne    7b61 <fwp_drop10+0x91>
    7bdb:	48 89 d7             	mov    %rdx,%rdi
    7bde:	48 83 c4 18          	add    $0x18,%rsp
    7be2:	e9 09 dc ff ff       	jmp    57f0 <fwp_mem_free>
    7be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7bee:	00 00 
    7bf0:	66 85 c0             	test   %ax,%ax
    7bf3:	74 e1                	je     7bd6 <fwp_drop10+0x106>
    7bf5:	48 83 c4 18          	add    $0x18,%rsp
    7bf9:	c3                   	ret
    7bfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c00:	66 85 c0             	test   %ax,%ax
    7c03:	0f 84 40 ff ff ff    	je     7b49 <fwp_drop10+0x79>
    7c09:	48 83 c4 18          	add    $0x18,%rsp
    7c0d:	c3                   	ret
    7c0e:	66 90                	xchg   %ax,%ax
    7c10:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7c14:	48 39 c8             	cmp    %rcx,%rax
    7c17:	73 74                	jae    7c8d <fwp_drop10+0x1bd>
    7c19:	49 89 c2             	mov    %rax,%r10
    7c1c:	49 c1 ea 10          	shr    $0x10,%r10
    7c20:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7c24:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7c28:	4d 8b 50 20          	mov    0x20(%r8),%r10
    7c2c:	4d 85 d2             	test   %r10,%r10
    7c2f:	74 5c                	je     7c8d <fwp_drop10+0x1bd>
    7c31:	45 0f b6 18          	movzbl (%r8),%r11d
    7c35:	41 80 fb 02          	cmp    $0x2,%r11b
    7c39:	74 6d                	je     7ca8 <fwp_drop10+0x1d8>
    7c3b:	41 80 fb 01          	cmp    $0x1,%r11b
    7c3f:	75 4c                	jne    7c8d <fwp_drop10+0x1bd>
    7c41:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7c45:	0f b7 c0             	movzwl %ax,%eax
    7c48:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    7c4c:	49 0f af c3          	imul   %r11,%rax
    7c50:	48 c1 e8 20          	shr    $0x20,%rax
    7c54:	4c 39 c0             	cmp    %r8,%rax
    7c57:	73 34                	jae    7c8d <fwp_drop10+0x1bd>
    7c59:	49 01 c2             	add    %rax,%r10
    7c5c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7c60:	75 2b                	jne    7c8d <fwp_drop10+0x1bd>
    7c62:	4c 89 cf             	mov    %r9,%rdi
    7c65:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7c6a:	e8 81 db ff ff       	call   57f0 <fwp_mem_free>
    7c6f:	48 8d 35 6a 8b 01 00 	lea    0x18b6a(%rip),%rsi        # 207e0 <fwp_heap>
    7c76:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7c7b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7c82:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7c89:	48 c1 e1 10          	shl    $0x10,%rcx
    7c8d:	48 89 d0             	mov    %rdx,%rax
    7c90:	48 29 f8             	sub    %rdi,%rax
    7c93:	48 39 c8             	cmp    %rcx,%rax
    7c96:	0f 82 60 fe ff ff    	jb     7afc <fwp_drop10+0x2c>
    7c9c:	e9 c0 fe ff ff       	jmp    7b61 <fwp_drop10+0x91>
    7ca1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ca8:	66 85 c0             	test   %ax,%ax
    7cab:	75 e0                	jne    7c8d <fwp_drop10+0x1bd>
    7cad:	eb ad                	jmp    7c5c <fwp_drop10+0x18c>
    7caf:	90                   	nop
    7cb0:	c3                   	ret
    7cb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7cb8:	48 89 c8             	mov    %rcx,%rax
    7cbb:	48 c1 e8 11          	shr    $0x11,%rax
    7cbf:	48 31 c8             	xor    %rcx,%rax
    7cc2:	48 89 c2             	mov    %rax,%rdx
    7cc5:	48 c1 ea 09          	shr    $0x9,%rdx
    7cc9:	48 31 d0             	xor    %rdx,%rax
    7ccc:	0f b6 d0             	movzbl %al,%edx
    7ccf:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7cd6:	00 
    7cd7:	48 85 c0             	test   %rax,%rax
    7cda:	75 0d                	jne    7ce9 <fwp_drop10+0x219>
    7cdc:	eb 46                	jmp    7d24 <fwp_drop10+0x254>
    7cde:	66 90                	xchg   %ax,%ax
    7ce0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7ce4:	48 85 c0             	test   %rax,%rax
    7ce7:	74 3b                	je     7d24 <fwp_drop10+0x254>
    7ce9:	48 89 c2             	mov    %rax,%rdx
    7cec:	48 39 08             	cmp    %rcx,(%rax)
    7cef:	75 ef                	jne    7ce0 <fwp_drop10+0x210>
    7cf1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7cf5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7cf9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7cfd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7d04:	0f 85 57 fe ff ff    	jne    7b61 <fwp_drop10+0x91>
    7d0a:	48 89 cf             	mov    %rcx,%rdi
    7d0d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7d12:	e8 99 d8 ff ff       	call   55b0 <fwp_rc_forget_slot>
    7d17:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7d1c:	c6 01 fe             	movb   $0xfe,(%rcx)
    7d1f:	e9 3d fe ff ff       	jmp    7b61 <fwp_drop10+0x91>
    7d24:	48 8d 3d 65 4b 00 00 	lea    0x4b65(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    7d2b:	e8 c0 c6 ff ff       	call   43f0 <fwp_trap>

0000000000007d30 <f37>:
    7d30:	41 57                	push   %r15
    7d32:	41 56                	push   %r14
    7d34:	41 55                	push   %r13
    7d36:	41 54                	push   %r12
    7d38:	55                   	push   %rbp
    7d39:	53                   	push   %rbx
    7d3a:	48 83 ec 38          	sub    $0x38,%rsp
    7d3e:	48 8b 15 73 9e 01 00 	mov    0x19e73(%rip),%rdx        # 21bb8 <fwp_heap+0x13d8>
    7d45:	48 8b 0d 44 9e 01 00 	mov    0x19e44(%rip),%rcx        # 21b90 <fwp_heap+0x13b0>
    7d4c:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7d53:	00 00 
    7d55:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7d5a:	49 89 fc             	mov    %rdi,%r12
    7d5d:	48 c1 e2 10          	shl    $0x10,%rdx
    7d61:	48 85 ff             	test   %rdi,%rdi
    7d64:	0f 84 bc 02 00 00    	je     8026 <f37+0x2f6>
    7d6a:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7d6f:	48 89 d8             	mov    %rbx,%rax
    7d72:	48 29 c8             	sub    %rcx,%rax
    7d75:	48 39 d0             	cmp    %rdx,%rax
    7d78:	0f 83 72 03 00 00    	jae    80f0 <f37+0x3c0>
    7d7e:	48 89 c2             	mov    %rax,%rdx
    7d81:	48 c1 ea 10          	shr    $0x10,%rdx
    7d85:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d89:	48 8b 15 48 9e 01 00 	mov    0x19e48(%rip),%rdx        # 21bd8 <fwp_heap+0x13f8>
    7d90:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d94:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d98:	48 85 ff             	test   %rdi,%rdi
    7d9b:	0f 84 4f 03 00 00    	je     80f0 <f37+0x3c0>
    7da1:	0f b6 0a             	movzbl (%rdx),%ecx
    7da4:	80 f9 02             	cmp    $0x2,%cl
    7da7:	0f 84 53 02 00 00    	je     8000 <f37+0x2d0>
    7dad:	80 f9 01             	cmp    $0x1,%cl
    7db0:	75 24                	jne    7dd6 <f37+0xa6>
    7db2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7db5:	0f b7 c0             	movzwl %ax,%eax
    7db8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7dbb:	48 0f af c1          	imul   %rcx,%rax
    7dbf:	48 c1 e8 20          	shr    $0x20,%rax
    7dc3:	48 39 d0             	cmp    %rdx,%rax
    7dc6:	73 0e                	jae    7dd6 <f37+0xa6>
    7dc8:	48 01 c7             	add    %rax,%rdi
    7dcb:	0f b6 07             	movzbl (%rdi),%eax
    7dce:	84 c0                	test   %al,%al
    7dd0:	0f 85 ca 02 00 00    	jne    80a0 <f37+0x370>
    7dd6:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7ddb:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7de0:	ba 01 00 00 00       	mov    $0x1,%edx
    7de5:	48 85 db             	test   %rbx,%rbx
    7de8:	74 13                	je     7dfd <f37+0xcd>
    7dea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7df0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7df4:	48 83 c2 01          	add    $0x1,%rdx
    7df8:	48 85 db             	test   %rbx,%rbx
    7dfb:	75 f3                	jne    7df0 <f37+0xc0>
    7dfd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7e02:	48 85 c0             	test   %rax,%rax
    7e05:	0f 84 15 03 00 00    	je     8120 <f37+0x3f0>
    7e0b:	31 db                	xor    %ebx,%ebx
    7e0d:	0f 1f 00             	nopl   (%rax)
    7e10:	48 8b 40 10          	mov    0x10(%rax),%rax
    7e14:	48 83 c3 01          	add    $0x1,%rbx
    7e18:	48 85 c0             	test   %rax,%rax
    7e1b:	75 f3                	jne    7e10 <f37+0xe0>
    7e1d:	48 39 d3             	cmp    %rdx,%rbx
    7e20:	48 0f 47 da          	cmova  %rdx,%rbx
    7e24:	48 89 d8             	mov    %rbx,%rax
    7e27:	48 c1 e8 3c          	shr    $0x3c,%rax
    7e2b:	0f 85 8f 03 00 00    	jne    81c0 <f37+0x490>
    7e31:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7e35:	be 02 00 00 00       	mov    $0x2,%esi
    7e3a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7e41:	00 
    7e42:	e8 a9 de ff ff       	call   5cf0 <fwp_heap_alloc>
    7e47:	48 89 28             	mov    %rbp,(%rax)
    7e4a:	48 8b 15 67 9d 01 00 	mov    0x19d67(%rip),%rdx        # 21bb8 <fwp_heap+0x13d8>
    7e51:	49 89 c6             	mov    %rax,%r14
    7e54:	48 2b 05 35 9d 01 00 	sub    0x19d35(%rip),%rax        # 21b90 <fwp_heap+0x13b0>
    7e5b:	48 c1 e2 10          	shl    $0x10,%rdx
    7e5f:	48 39 d0             	cmp    %rdx,%rax
    7e62:	73 57                	jae    7ebb <f37+0x18b>
    7e64:	48 89 c2             	mov    %rax,%rdx
    7e67:	48 c1 ea 10          	shr    $0x10,%rdx
    7e6b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e6f:	48 8b 15 62 9d 01 00 	mov    0x19d62(%rip),%rdx        # 21bd8 <fwp_heap+0x13f8>
    7e76:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e7a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7e7e:	48 85 ed             	test   %rbp,%rbp
    7e81:	74 38                	je     7ebb <f37+0x18b>
    7e83:	0f b6 0a             	movzbl (%rdx),%ecx
    7e86:	80 f9 02             	cmp    $0x2,%cl
    7e89:	0f 84 51 02 00 00    	je     80e0 <f37+0x3b0>
    7e8f:	80 f9 01             	cmp    $0x1,%cl
    7e92:	75 27                	jne    7ebb <f37+0x18b>
    7e94:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7e97:	0f b7 c0             	movzwl %ax,%eax
    7e9a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e9d:	48 0f af c1          	imul   %rcx,%rax
    7ea1:	48 c1 e8 20          	shr    $0x20,%rax
    7ea5:	48 39 d0             	cmp    %rdx,%rax
    7ea8:	73 11                	jae    7ebb <f37+0x18b>
    7eaa:	48 01 c5             	add    %rax,%rbp
    7ead:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7eb1:	0f 84 d5 02 00 00    	je     818c <f37+0x45c>
    7eb7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7ebb:	48 85 db             	test   %rbx,%rbx
    7ebe:	74 5d                	je     7f1d <f37+0x1ed>
    7ec0:	48 c1 e3 04          	shl    $0x4,%rbx
    7ec4:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    7ec9:	4c 89 f5             	mov    %r14,%rbp
    7ecc:	4d 89 e5             	mov    %r12,%r13
    7ecf:	4c 01 f3             	add    %r14,%rbx
    7ed2:	0f 1f 00             	nopl   (%rax)
    7ed5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7edc:	00 00 00 00 
    7ee0:	49 8b 45 08          	mov    0x8(%r13),%rax
    7ee4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    7ee8:	48 83 c5 10          	add    $0x10,%rbp
    7eec:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    7ef1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    7ef5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    7ef9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    7efe:	e8 bd e3 ff ff       	call   62c0 <w120>
    7f03:	66 48 0f 6e d0       	movq   %rax,%xmm2
    7f08:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    7f0c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    7f10:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    7f14:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    7f18:	48 39 dd             	cmp    %rbx,%rbp
    7f1b:	75 c3                	jne    7ee0 <f37+0x1b0>
    7f1d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7f22:	e8 c9 ed ff ff       	call   6cf0 <fwp_drop4>
    7f27:	4c 89 e7             	mov    %r12,%rdi
    7f2a:	e8 c1 ed ff ff       	call   6cf0 <fwp_drop4>
    7f2f:	4c 89 f7             	mov    %r14,%rdi
    7f32:	e8 09 e5 ff ff       	call   6440 <w176.constprop.0>
    7f37:	4c 89 f7             	mov    %r14,%rdi
    7f3a:	48 89 c3             	mov    %rax,%rbx
    7f3d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    7f43:	e8 88 fb ff ff       	call   7ad0 <fwp_drop10>
    7f48:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    7f4e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    7f53:	31 ff                	xor    %edi,%edi
    7f55:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7f5a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    7f5e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7f63:	e8 a8 de ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    7f68:	48 8b 15 49 9c 01 00 	mov    0x19c49(%rip),%rdx        # 21bb8 <fwp_heap+0x13d8>
    7f6f:	48 89 c5             	mov    %rax,%rbp
    7f72:	48 2b 05 17 9c 01 00 	sub    0x19c17(%rip),%rax        # 21b90 <fwp_heap+0x13b0>
    7f79:	48 c1 e2 10          	shl    $0x10,%rdx
    7f7d:	48 39 d0             	cmp    %rdx,%rax
    7f80:	73 55                	jae    7fd7 <f37+0x2a7>
    7f82:	48 89 c2             	mov    %rax,%rdx
    7f85:	48 c1 ea 10          	shr    $0x10,%rdx
    7f89:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7f8d:	48 8b 15 44 9c 01 00 	mov    0x19c44(%rip),%rdx        # 21bd8 <fwp_heap+0x13f8>
    7f94:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7f98:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    7f9c:	48 85 db             	test   %rbx,%rbx
    7f9f:	74 36                	je     7fd7 <f37+0x2a7>
    7fa1:	0f b6 0a             	movzbl (%rdx),%ecx
    7fa4:	80 f9 02             	cmp    $0x2,%cl
    7fa7:	0f 84 1b 01 00 00    	je     80c8 <f37+0x398>
    7fad:	80 f9 01             	cmp    $0x1,%cl
    7fb0:	75 25                	jne    7fd7 <f37+0x2a7>
    7fb2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7fb5:	0f b7 c0             	movzwl %ax,%eax
    7fb8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7fbb:	48 0f af c1          	imul   %rcx,%rax
    7fbf:	48 c1 e8 20          	shr    $0x20,%rax
    7fc3:	48 39 d0             	cmp    %rdx,%rax
    7fc6:	73 0f                	jae    7fd7 <f37+0x2a7>
    7fc8:	48 01 c3             	add    %rax,%rbx
    7fcb:	80 3b ff             	cmpb   $0xff,(%rbx)
    7fce:	0f 84 ab 01 00 00    	je     817f <f37+0x44f>
    7fd4:	c6 03 01             	movb   $0x1,(%rbx)
    7fd7:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7fdc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7fe3:	00 00 
    7fe5:	0f 85 d0 01 00 00    	jne    81bb <f37+0x48b>
    7feb:	48 83 c4 38          	add    $0x38,%rsp
    7fef:	48 89 e8             	mov    %rbp,%rax
    7ff2:	5b                   	pop    %rbx
    7ff3:	5d                   	pop    %rbp
    7ff4:	41 5c                	pop    %r12
    7ff6:	41 5d                	pop    %r13
    7ff8:	41 5e                	pop    %r14
    7ffa:	41 5f                	pop    %r15
    7ffc:	c3                   	ret
    7ffd:	0f 1f 00             	nopl   (%rax)
    8000:	66 85 c0             	test   %ax,%ax
    8003:	0f 85 cd fd ff ff    	jne    7dd6 <f37+0xa6>
    8009:	0f b6 07             	movzbl (%rdi),%eax
    800c:	84 c0                	test   %al,%al
    800e:	0f 84 c2 fd ff ff    	je     7dd6 <f37+0xa6>
    8014:	3c fd                	cmp    $0xfd,%al
    8016:	0f 87 95 01 00 00    	ja     81b1 <f37+0x481>
    801c:	83 c0 01             	add    $0x1,%eax
    801f:	88 07                	mov    %al,(%rdi)
    8021:	e9 b0 fd ff ff       	jmp    7dd6 <f37+0xa6>
    8026:	48 f7 d9             	neg    %rcx
    8029:	48 39 d1             	cmp    %rdx,%rcx
    802c:	0f 83 ee 00 00 00    	jae    8120 <f37+0x3f0>
    8032:	48 89 c8             	mov    %rcx,%rax
    8035:	48 c1 e8 10          	shr    $0x10,%rax
    8039:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    803d:	48 8b 05 94 9b 01 00 	mov    0x19b94(%rip),%rax        # 21bd8 <fwp_heap+0x13f8>
    8044:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8048:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    804c:	48 85 ff             	test   %rdi,%rdi
    804f:	0f 84 cb 00 00 00    	je     8120 <f37+0x3f0>
    8055:	0f b6 02             	movzbl (%rdx),%eax
    8058:	3c 02                	cmp    $0x2,%al
    805a:	0f 84 9a 00 00 00    	je     80fa <f37+0x3ca>
    8060:	3c 01                	cmp    $0x1,%al
    8062:	0f 85 b8 00 00 00    	jne    8120 <f37+0x3f0>
    8068:	0f b7 c1             	movzwl %cx,%eax
    806b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    806e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8071:	48 0f af c1          	imul   %rcx,%rax
    8075:	48 c1 e8 20          	shr    $0x20,%rax
    8079:	48 39 d0             	cmp    %rdx,%rax
    807c:	0f 83 9e 00 00 00    	jae    8120 <f37+0x3f0>
    8082:	48 01 c7             	add    %rax,%rdi
    8085:	0f b6 07             	movzbl (%rdi),%eax
    8088:	84 c0                	test   %al,%al
    808a:	0f 84 90 00 00 00    	je     8120 <f37+0x3f0>
    8090:	31 db                	xor    %ebx,%ebx
    8092:	0f 1f 00             	nopl   (%rax)
    8095:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    809c:	00 00 00 00 
    80a0:	3c fd                	cmp    $0xfd,%al
    80a2:	0f 87 f1 00 00 00    	ja     8199 <f37+0x469>
    80a8:	83 c0 01             	add    $0x1,%eax
    80ab:	88 07                	mov    %al,(%rdi)
    80ad:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    80b2:	31 d2                	xor    %edx,%edx
    80b4:	4d 85 e4             	test   %r12,%r12
    80b7:	0f 85 1e fd ff ff    	jne    7ddb <f37+0xab>
    80bd:	e9 3b fd ff ff       	jmp    7dfd <f37+0xcd>
    80c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    80c8:	66 85 c0             	test   %ax,%ax
    80cb:	0f 85 06 ff ff ff    	jne    7fd7 <f37+0x2a7>
    80d1:	e9 f5 fe ff ff       	jmp    7fcb <f37+0x29b>
    80d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    80dd:	00 00 00 
    80e0:	66 85 c0             	test   %ax,%ax
    80e3:	0f 85 d2 fd ff ff    	jne    7ebb <f37+0x18b>
    80e9:	e9 bf fd ff ff       	jmp    7ead <f37+0x17d>
    80ee:	66 90                	xchg   %ax,%ax
    80f0:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    80f5:	e9 e6 fc ff ff       	jmp    7de0 <f37+0xb0>
    80fa:	66 85 c9             	test   %cx,%cx
    80fd:	75 21                	jne    8120 <f37+0x3f0>
    80ff:	0f b6 07             	movzbl (%rdi),%eax
    8102:	84 c0                	test   %al,%al
    8104:	74 1a                	je     8120 <f37+0x3f0>
    8106:	3c fd                	cmp    $0xfd,%al
    8108:	0f 87 be 00 00 00    	ja     81cc <f37+0x49c>
    810e:	83 c0 01             	add    $0x1,%eax
    8111:	88 07                	mov    %al,(%rdi)
    8113:	66 90                	xchg   %ax,%ax
    8115:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    811c:	00 00 00 00 
    8120:	be 02 00 00 00       	mov    $0x2,%esi
    8125:	bf 08 00 00 00       	mov    $0x8,%edi
    812a:	e8 c1 db ff ff       	call   5cf0 <fwp_heap_alloc>
    812f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8136:	48 8b 15 7b 9a 01 00 	mov    0x19a7b(%rip),%rdx        # 21bb8 <fwp_heap+0x13d8>
    813d:	49 89 c6             	mov    %rax,%r14
    8140:	48 2b 05 49 9a 01 00 	sub    0x19a49(%rip),%rax        # 21b90 <fwp_heap+0x13b0>
    8147:	48 c1 e2 10          	shl    $0x10,%rdx
    814b:	48 39 d0             	cmp    %rdx,%rax
    814e:	73 53                	jae    81a3 <f37+0x473>
    8150:	48 89 c2             	mov    %rax,%rdx
    8153:	48 c1 ea 10          	shr    $0x10,%rdx
    8157:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    815b:	48 8b 15 76 9a 01 00 	mov    0x19a76(%rip),%rdx        # 21bd8 <fwp_heap+0x13f8>
    8162:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8166:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    816a:	48 85 ed             	test   %rbp,%rbp
    816d:	74 34                	je     81a3 <f37+0x473>
    816f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8176:	00 00 
    8178:	31 db                	xor    %ebx,%ebx
    817a:	e9 04 fd ff ff       	jmp    7e83 <f37+0x153>
    817f:	48 89 df             	mov    %rbx,%rdi
    8182:	e8 29 d4 ff ff       	call   55b0 <fwp_rc_forget_slot>
    8187:	e9 48 fe ff ff       	jmp    7fd4 <f37+0x2a4>
    818c:	48 89 ef             	mov    %rbp,%rdi
    818f:	e8 1c d4 ff ff       	call   55b0 <fwp_rc_forget_slot>
    8194:	e9 1e fd ff ff       	jmp    7eb7 <f37+0x187>
    8199:	e8 f2 d2 ff ff       	call   5490 <fwp_rc_wide_dup>
    819e:	e9 0a ff ff ff       	jmp    80ad <f37+0x37d>
    81a3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    81aa:	00 00 
    81ac:	e9 6c fd ff ff       	jmp    7f1d <f37+0x1ed>
    81b1:	e8 da d2 ff ff       	call   5490 <fwp_rc_wide_dup>
    81b6:	e9 1b fc ff ff       	jmp    7dd6 <f37+0xa6>
    81bb:	e8 a0 b2 ff ff       	call   3460 <__stack_chk_fail@plt>
    81c0:	48 8d 3d c9 3f 00 00 	lea    0x3fc9(%rip),%rdi        # c190 <_IO_stdin_used+0x190>
    81c7:	e8 24 c2 ff ff       	call   43f0 <fwp_trap>
    81cc:	e8 bf d2 ff ff       	call   5490 <fwp_rc_wide_dup>
    81d1:	e9 4a ff ff ff       	jmp    8120 <f37+0x3f0>
    81d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    81dd:	00 00 00 

00000000000081e0 <fwp_owned_entry37>:
    81e0:	f3 0f 1e fa          	endbr64
    81e4:	48 8b 3f             	mov    (%rdi),%rdi
    81e7:	e9 44 fb ff ff       	jmp    7d30 <f37>
    81ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000081f0 <e37>:
    81f0:	f3 0f 1e fa          	endbr64
    81f4:	53                   	push   %rbx
    81f5:	48 8b 1f             	mov    (%rdi),%rbx
    81f8:	48 89 df             	mov    %rbx,%rdi
    81fb:	e8 e0 e2 ff ff       	call   64e0 <fwp_rc_share>
    8200:	48 89 df             	mov    %rbx,%rdi
    8203:	e8 28 fb ff ff       	call   7d30 <f37>
    8208:	48 89 c3             	mov    %rax,%rbx
    820b:	48 89 c7             	mov    %rax,%rdi
    820e:	e8 cd e2 ff ff       	call   64e0 <fwp_rc_share>
    8213:	48 89 d8             	mov    %rbx,%rax
    8216:	5b                   	pop    %rbx
    8217:	c3                   	ret
    8218:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    821f:	00 

0000000000008220 <fwp_write>:
    8220:	41 57                	push   %r15
    8222:	41 56                	push   %r14
    8224:	41 55                	push   %r13
    8226:	41 54                	push   %r12
    8228:	55                   	push   %rbp
    8229:	53                   	push   %rbx
    822a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8231:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8238:	00 00 
    823a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8241:	00 
    8242:	49 89 d4             	mov    %rdx,%r12
    8245:	8b 12                	mov    (%rdx),%edx
    8247:	83 fa 19             	cmp    $0x19,%edx
    824a:	77 6a                	ja     82b6 <fwp_write+0x96>
    824c:	48 89 f5             	mov    %rsi,%rbp
    824f:	89 d0                	mov    %edx,%eax
    8251:	89 ce                	mov    %ecx,%esi
    8253:	48 89 fb             	mov    %rdi,%rbx
    8256:	48 8d 0d a3 48 00 00 	lea    0x48a3(%rip),%rcx        # cb00 <_IO_stdin_used+0xb00>
    825d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8261:	48 01 c8             	add    %rcx,%rax
    8264:	3e ff e0             	notrack jmp *%rax
    8267:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    826e:	00 00 
    8270:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8274:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8278:	48 89 ca             	mov    %rcx,%rdx
    827b:	48 85 c9             	test   %rcx,%rcx
    827e:	0f 88 9c 0c 00 00    	js     8f20 <fwp_write+0xd00>
    8284:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    828b:	00 
    828c:	48 89 c6             	mov    %rax,%rsi
    828f:	4c 89 e7             	mov    %r12,%rdi
    8292:	e8 a9 b7 ff ff       	call   3a40 <fwp_fmt_u128>
    8297:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    829e:	00 00 
    82a0:	4c 89 e7             	mov    %r12,%rdi
    82a3:	e8 a8 b1 ff ff       	call   3450 <strlen@plt>
    82a8:	4c 89 e6             	mov    %r12,%rsi
    82ab:	48 89 df             	mov    %rbx,%rdi
    82ae:	48 89 c2             	mov    %rax,%rdx
    82b1:	e8 5a bf ff ff       	call   4210 <buf_put>
    82b6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    82bd:	00 
    82be:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    82c5:	00 00 
    82c7:	0f 85 28 04 00 00    	jne    86f5 <fwp_write+0x4d5>
    82cd:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    82d4:	5b                   	pop    %rbx
    82d5:	5d                   	pop    %rbp
    82d6:	41 5c                	pop    %r12
    82d8:	41 5d                	pop    %r13
    82da:	41 5e                	pop    %r14
    82dc:	41 5f                	pop    %r15
    82de:	c3                   	ret
    82df:	90                   	nop
    82e0:	49 89 e9             	mov    %rbp,%r9
    82e3:	4c 8d 05 8b 3d 00 00 	lea    0x3d8b(%rip),%r8        # c075 <_IO_stdin_used+0x75>
    82ea:	b9 00 02 00 00       	mov    $0x200,%ecx
    82ef:	ba 02 00 00 00       	mov    $0x2,%edx
    82f4:	be 00 02 00 00       	mov    $0x200,%esi
    82f9:	31 c0                	xor    %eax,%eax
    82fb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8302:	00 
    8303:	e8 a8 b0 ff ff       	call   33b0 <__snprintf_chk@plt>
    8308:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    830f:	00 
    8310:	e8 3b b1 ff ff       	call   3450 <strlen@plt>
    8315:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    831c:	00 
    831d:	48 89 df             	mov    %rbx,%rdi
    8320:	48 89 c2             	mov    %rax,%rdx
    8323:	e8 e8 be ff ff       	call   4210 <buf_put>
    8328:	eb 8c                	jmp    82b6 <fwp_write+0x96>
    832a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8330:	49 89 e9             	mov    %rbp,%r9
    8333:	4c 8d 05 7b 3e 00 00 	lea    0x3e7b(%rip),%r8        # c1b5 <_IO_stdin_used+0x1b5>
    833a:	eb ae                	jmp    82ea <fwp_write+0xca>
    833c:	0f 1f 40 00          	nopl   0x0(%rax)
    8340:	83 fa 13             	cmp    $0x13,%edx
    8343:	48 8d 05 61 3e 00 00 	lea    0x3e61(%rip),%rax        # c1ab <_IO_stdin_used+0x1ab>
    834a:	48 8d 35 5f 3e 00 00 	lea    0x3e5f(%rip),%rsi        # c1b0 <_IO_stdin_used+0x1b0>
    8351:	ba 04 00 00 00       	mov    $0x4,%edx
    8356:	48 0f 44 f0          	cmove  %rax,%rsi
    835a:	45 31 ed             	xor    %r13d,%r13d
    835d:	e8 ae be ff ff       	call   4210 <buf_put>
    8362:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8367:	0f 84 a3 08 00 00    	je     8c10 <fwp_write+0x9f0>
    836d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8372:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8377:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    837c:	48 89 df             	mov    %rbx,%rdi
    837f:	49 0f 44 c5          	cmove  %r13,%rax
    8383:	31 c9                	xor    %ecx,%ecx
    8385:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    838a:	e8 91 fe ff ff       	call   8220 <fwp_write>
    838f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8394:	0f 84 6e 09 00 00    	je     8d08 <fwp_write+0xae8>
    839a:	49 83 c5 01          	add    $0x1,%r13
    839e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    83a2:	0f 83 68 08 00 00    	jae    8c10 <fwp_write+0x9f0>
    83a8:	ba 02 00 00 00       	mov    $0x2,%edx
    83ad:	48 8d 35 41 3e 00 00 	lea    0x3e41(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    83b4:	48 89 df             	mov    %rbx,%rdi
    83b7:	e8 54 be ff ff       	call   4210 <buf_put>
    83bc:	eb af                	jmp    836d <fwp_write+0x14d>
    83be:	66 90                	xchg   %ax,%ax
    83c0:	ba 06 00 00 00       	mov    $0x6,%edx
    83c5:	48 8d 35 02 3e 00 00 	lea    0x3e02(%rip),%rsi        # c1ce <_IO_stdin_used+0x1ce>
    83cc:	48 83 c5 10          	add    $0x10,%rbp
    83d0:	e8 3b be ff ff       	call   4210 <buf_put>
    83d5:	48 89 ef             	mov    %rbp,%rdi
    83d8:	e8 73 b0 ff ff       	call   3450 <strlen@plt>
    83dd:	48 89 ee             	mov    %rbp,%rsi
    83e0:	48 89 df             	mov    %rbx,%rdi
    83e3:	48 89 c2             	mov    %rax,%rdx
    83e6:	e8 25 be ff ff       	call   4210 <buf_put>
    83eb:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    83f0:	ba 01 00 00 00       	mov    $0x1,%edx
    83f5:	48 89 df             	mov    %rbx,%rdi
    83f8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    83fd:	e8 0e be ff ff       	call   4210 <buf_put>
    8402:	e9 af fe ff ff       	jmp    82b6 <fwp_write+0x96>
    8407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    840e:	00 00 
    8410:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8417:	00 
    8418:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    841f:	00 00 
    8421:	0f 85 ce 02 00 00    	jne    86f5 <fwp_write+0x4d5>
    8427:	ba 0a 00 00 00       	mov    $0xa,%edx
    842c:	48 8d 35 87 3d 00 00 	lea    0x3d87(%rip),%rsi        # c1ba <_IO_stdin_used+0x1ba>
    8433:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    843a:	48 89 df             	mov    %rbx,%rdi
    843d:	5b                   	pop    %rbx
    843e:	5d                   	pop    %rbp
    843f:	41 5c                	pop    %r12
    8441:	41 5d                	pop    %r13
    8443:	41 5e                	pop    %r14
    8445:	41 5f                	pop    %r15
    8447:	e9 c4 bd ff ff       	jmp    4210 <buf_put>
    844c:	0f 1f 40 00          	nopl   0x0(%rax)
    8450:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8455:	4d 85 ed             	test   %r13,%r13
    8458:	0f 84 02 0c 00 00    	je     9060 <fwp_write+0xe40>
    845e:	48 8d 35 9d 3d 00 00 	lea    0x3d9d(%rip),%rsi        # c202 <_IO_stdin_used+0x202>
    8465:	4c 89 ef             	mov    %r13,%rdi
    8468:	e8 c3 b0 ff ff       	call   3530 <strcmp@plt>
    846d:	41 89 c1             	mov    %eax,%r9d
    8470:	85 c0                	test   %eax,%eax
    8472:	0f 84 6c 0c 00 00    	je     90e4 <fwp_write+0xec4>
    8478:	4c 89 ef             	mov    %r13,%rdi
    847b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8480:	e8 cb af ff ff       	call   3450 <strlen@plt>
    8485:	4c 89 ee             	mov    %r13,%rsi
    8488:	48 89 df             	mov    %rbx,%rdi
    848b:	48 89 c2             	mov    %rax,%rdx
    848e:	e8 7d bd ff ff       	call   4210 <buf_put>
    8493:	ba 01 00 00 00       	mov    $0x1,%edx
    8498:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    849d:	48 89 df             	mov    %rbx,%rdi
    84a0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    84a5:	e8 66 bd ff ff       	call   4210 <buf_put>
    84aa:	ba 01 00 00 00       	mov    $0x1,%edx
    84af:	4c 89 fe             	mov    %r15,%rsi
    84b2:	48 89 df             	mov    %rbx,%rdi
    84b5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    84ba:	e8 51 bd ff ff       	call   4210 <buf_put>
    84bf:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    84c4:	45 31 f6             	xor    %r14d,%r14d
    84c7:	85 d2                	test   %edx,%edx
    84c9:	0f 8e 81 0a 00 00    	jle    8f50 <fwp_write+0xd30>
    84cf:	45 31 ed             	xor    %r13d,%r13d
    84d2:	4d 85 ed             	test   %r13,%r13
    84d5:	0f 85 75 07 00 00    	jne    8c50 <fwp_write+0xa30>
    84db:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    84e2:	00 
    84e3:	45 85 f6             	test   %r14d,%r14d
    84e6:	0f 84 84 07 00 00    	je     8c70 <fwp_write+0xa50>
    84ec:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    84f1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    84f6:	48 89 df             	mov    %rbx,%rdi
    84f9:	49 83 c5 01          	add    $0x1,%r13
    84fd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8501:	31 c9                	xor    %ecx,%ecx
    8503:	e8 18 fd ff ff       	call   8220 <fwp_write>
    8508:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    850d:	7f c3                	jg     84d2 <fwp_write+0x2b2>
    850f:	45 85 f6             	test   %r14d,%r14d
    8512:	0f 84 38 0a 00 00    	je     8f50 <fwp_write+0xd30>
    8518:	b8 29 00 00 00       	mov    $0x29,%eax
    851d:	ba 01 00 00 00       	mov    $0x1,%edx
    8522:	4c 89 fe             	mov    %r15,%rsi
    8525:	48 89 df             	mov    %rbx,%rdi
    8528:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    852c:	e8 df bc ff ff       	call   4210 <buf_put>
    8531:	e9 80 fd ff ff       	jmp    82b6 <fwp_write+0x96>
    8536:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    853d:	00 00 00 
    8540:	ba 01 00 00 00       	mov    $0x1,%edx
    8545:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    854a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    854f:	e8 bc bc ff ff       	call   4210 <buf_put>
    8554:	48 85 ed             	test   %rbp,%rbp
    8557:	0f 84 93 06 00 00    	je     8bf0 <fwp_write+0x9d0>
    855d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8561:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8566:	31 c9                	xor    %ecx,%ecx
    8568:	48 89 df             	mov    %rbx,%rdi
    856b:	e8 b0 fc ff ff       	call   8220 <fwp_write>
    8570:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8574:	48 85 ed             	test   %rbp,%rbp
    8577:	0f 84 73 06 00 00    	je     8bf0 <fwp_write+0x9d0>
    857d:	ba 02 00 00 00       	mov    $0x2,%edx
    8582:	48 8d 35 6c 3c 00 00 	lea    0x3c6c(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    8589:	48 89 df             	mov    %rbx,%rdi
    858c:	e8 7f bc ff ff       	call   4210 <buf_put>
    8591:	eb ca                	jmp    855d <fwp_write+0x33d>
    8593:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8598:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    859c:	85 f6                	test   %esi,%esi
    859e:	0f 84 fc 07 00 00    	je     8da0 <fwp_write+0xb80>
    85a4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    85ab:	00 
    85ac:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    85b3:	00 00 
    85b5:	0f 85 3a 01 00 00    	jne    86f5 <fwp_write+0x4d5>
    85bb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    85bf:	4c 89 ea             	mov    %r13,%rdx
    85c2:	e9 6c fe ff ff       	jmp    8433 <fwp_write+0x213>
    85c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    85ce:	00 00 
    85d0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    85d5:	ba 01 00 00 00       	mov    $0x1,%edx
    85da:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    85df:	48 89 ee             	mov    %rbp,%rsi
    85e2:	e8 29 bc ff ff       	call   4210 <buf_put>
    85e7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    85ec:	4c 89 e7             	mov    %r12,%rdi
    85ef:	e8 5c ae ff ff       	call   3450 <strlen@plt>
    85f4:	4c 89 e6             	mov    %r12,%rsi
    85f7:	48 89 df             	mov    %rbx,%rdi
    85fa:	48 89 c2             	mov    %rax,%rdx
    85fd:	e8 0e bc ff ff       	call   4210 <buf_put>
    8602:	ba 01 00 00 00       	mov    $0x1,%edx
    8607:	48 89 ee             	mov    %rbp,%rsi
    860a:	48 89 df             	mov    %rbx,%rdi
    860d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8612:	e8 f9 bb ff ff       	call   4210 <buf_put>
    8617:	e9 9a fc ff ff       	jmp    82b6 <fwp_write+0x96>
    861c:	0f 1f 40 00          	nopl   0x0(%rax)
    8620:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8625:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8629:	0f 8a 8e 0b 00 00    	jp     91bd <fwp_write+0xf9d>
    862f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8633:	66 0f 54 05 05 46 00 	andpd  0x4605(%rip),%xmm0        # cc40 <msg.8+0xd0>
    863a:	00 
    863b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8640:	66 0f 2e 05 60 45 00 	ucomisd 0x4560(%rip),%xmm0        # cba8 <msg.8+0x38>
    8647:	00 
    8648:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    864f:	00 
    8650:	0f 87 b2 09 00 00    	ja     9008 <fwp_write+0xde8>
    8656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    865d:	00 00 00 
    8660:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8664:	89 ee                	mov    %ebp,%esi
    8666:	4c 89 e7             	mov    %r12,%rdi
    8669:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    866e:	e8 9d c0 ff ff       	call   4710 <fwp_format_g.constprop.0>
    8673:	31 f6                	xor    %esi,%esi
    8675:	4c 89 e7             	mov    %r12,%rdi
    8678:	e8 93 ad ff ff       	call   3410 <strtod@plt>
    867d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8682:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8686:	7a 06                	jp     868e <fwp_write+0x46e>
    8688:	0f 84 e9 01 00 00    	je     8877 <fwp_write+0x657>
    868e:	83 c5 01             	add    $0x1,%ebp
    8691:	83 fd 12             	cmp    $0x12,%ebp
    8694:	75 ca                	jne    8660 <fwp_write+0x440>
    8696:	be 11 00 00 00       	mov    $0x11,%esi
    869b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    869f:	4c 89 e7             	mov    %r12,%rdi
    86a2:	e8 69 c0 ff ff       	call   4710 <fwp_format_g.constprop.0>
    86a7:	e9 cb 01 00 00       	jmp    8877 <fwp_write+0x657>
    86ac:	0f 1f 40 00          	nopl   0x0(%rax)
    86b0:	48 83 fd 01          	cmp    $0x1,%rbp
    86b4:	0f 84 e6 08 00 00    	je     8fa0 <fwp_write+0xd80>
    86ba:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    86be:	b8 02 00 00 00       	mov    $0x2,%eax
    86c3:	ba 01 00 00 00       	mov    $0x1,%edx
    86c8:	48 0f 44 d0          	cmove  %rax,%rdx
    86cc:	48 8d 35 d0 3a 00 00 	lea    0x3ad0(%rip),%rsi        # c1a3 <_IO_stdin_used+0x1a3>
    86d3:	48 8d 05 ce 3a 00 00 	lea    0x3ace(%rip),%rax        # c1a8 <_IO_stdin_used+0x1a8>
    86da:	48 0f 44 f0          	cmove  %rax,%rsi
    86de:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    86e5:	00 
    86e6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    86ed:	00 00 
    86ef:	0f 84 3e fd ff ff    	je     8433 <fwp_write+0x213>
    86f5:	e8 66 ad ff ff       	call   3460 <__stack_chk_fail@plt>
    86fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8700:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8705:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    870a:	e8 41 ba ff ff       	call   4150 <buf_grow>
    870f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8713:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8719:	4c 03 0b             	add    (%rbx),%r9
    871c:	66 45 89 11          	mov    %r10w,(%r9)
    8720:	45 85 e4             	test   %r12d,%r12d
    8723:	0f 8e 07 05 00 00    	jle    8c30 <fwp_write+0xa10>
    8729:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8730:	55 55 55 
    8733:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8738:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    873f:	aa aa aa 
    8742:	49 83 c1 01          	add    $0x1,%r9
    8746:	eb 45                	jmp    878d <fwp_write+0x56d>
    8748:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    874f:	00 
    8750:	be 01 00 00 00       	mov    $0x1,%esi
    8755:	b8 2d 00 00 00       	mov    $0x2d,%eax
    875a:	88 07                	mov    %al,(%rdi)
    875c:	48 89 e8             	mov    %rbp,%rax
    875f:	49 f7 e8             	imul   %r8
    8762:	48 89 e8             	mov    %rbp,%rax
    8765:	48 c1 f8 3f          	sar    $0x3f,%rax
    8769:	48 29 c2             	sub    %rax,%rdx
    876c:	48 85 c9             	test   %rcx,%rcx
    876f:	0f 95 c0             	setne  %al
    8772:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8776:	48 83 ef 01          	sub    $0x1,%rdi
    877a:	48 21 c5             	and    %rax,%rbp
    877d:	48 29 ea             	sub    %rbp,%rdx
    8780:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8784:	49 39 f9             	cmp    %rdi,%r9
    8787:	0f 84 a3 04 00 00    	je     8c30 <fwp_write+0xa10>
    878d:	48 89 e8             	mov    %rbp,%rax
    8790:	49 f7 e8             	imul   %r8
    8793:	48 89 e8             	mov    %rbp,%rax
    8796:	48 c1 f8 3f          	sar    $0x3f,%rax
    879a:	48 89 d1             	mov    %rdx,%rcx
    879d:	48 29 c1             	sub    %rax,%rcx
    87a0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    87a4:	48 89 e9             	mov    %rbp,%rcx
    87a7:	48 29 c1             	sub    %rax,%rcx
    87aa:	48 8d 41 03          	lea    0x3(%rcx),%rax
    87ae:	49 f7 e2             	mul    %r10
    87b1:	b8 30 00 00 00       	mov    $0x30,%eax
    87b6:	48 89 d6             	mov    %rdx,%rsi
    87b9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    87bd:	48 d1 ee             	shr    $1,%rsi
    87c0:	48 01 f2             	add    %rsi,%rdx
    87c3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    87c7:	48 29 d6             	sub    %rdx,%rsi
    87ca:	74 8e                	je     875a <fwp_write+0x53a>
    87cc:	48 83 fe 01          	cmp    $0x1,%rsi
    87d0:	0f 85 7a ff ff ff    	jne    8750 <fwp_write+0x530>
    87d6:	31 f6                	xor    %esi,%esi
    87d8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    87dd:	e9 78 ff ff ff       	jmp    875a <fwp_write+0x53a>
    87e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    87e8:	66 0f 6e cd          	movd   %ebp,%xmm1
    87ec:	0f 2e c9             	ucomiss %xmm1,%xmm1
    87ef:	0f 8a c8 09 00 00    	jp     91bd <fwp_write+0xf9d>
    87f5:	0f 28 c1             	movaps %xmm1,%xmm0
    87f8:	0f 54 05 31 44 00 00 	andps  0x4431(%rip),%xmm0        # cc30 <msg.8+0xc0>
    87ff:	0f 2e 05 fe 37 00 00 	ucomiss 0x37fe(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    8806:	0f 87 24 08 00 00    	ja     9030 <fwp_write+0xe10>
    880c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8810:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8816:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    881d:	00 
    881e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8822:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8827:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    882e:	00 00 
    8830:	44 89 ee             	mov    %r13d,%esi
    8833:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8838:	4c 89 e7             	mov    %r12,%rdi
    883b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8840:	e8 cb be ff ff       	call   4710 <fwp_format_g.constprop.0>
    8845:	31 f6                	xor    %esi,%esi
    8847:	4c 89 e7             	mov    %r12,%rdi
    884a:	e8 61 ac ff ff       	call   34b0 <strtof@plt>
    884f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8854:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8857:	7a 02                	jp     885b <fwp_write+0x63b>
    8859:	74 1c                	je     8877 <fwp_write+0x657>
    885b:	41 83 c5 01          	add    $0x1,%r13d
    885f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8863:	75 cb                	jne    8830 <fwp_write+0x610>
    8865:	be 09 00 00 00       	mov    $0x9,%esi
    886a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    886f:	4c 89 e7             	mov    %r12,%rdi
    8872:	e8 99 be ff ff       	call   4710 <fwp_format_g.constprop.0>
    8877:	4c 89 e7             	mov    %r12,%rdi
    887a:	e8 01 bb ff ff       	call   4380 <fwp_finish_float>
    887f:	e9 1c fa ff ff       	jmp    82a0 <fwp_write+0x80>
    8884:	0f 1f 40 00          	nopl   0x0(%rax)
    8888:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    888c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8890:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8897:	00 
    8898:	48 89 ef             	mov    %rbp,%rdi
    889b:	e8 a0 b1 ff ff       	call   3a40 <fwp_fmt_u128>
    88a0:	48 89 ef             	mov    %rbp,%rdi
    88a3:	e8 a8 ab ff ff       	call   3450 <strlen@plt>
    88a8:	48 89 ee             	mov    %rbp,%rsi
    88ab:	48 89 df             	mov    %rbx,%rdi
    88ae:	48 89 c2             	mov    %rax,%rdx
    88b1:	e8 5a b9 ff ff       	call   4210 <buf_put>
    88b6:	e9 fb f9 ff ff       	jmp    82b6 <fwp_write+0x96>
    88bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    88c0:	ba 06 00 00 00       	mov    $0x6,%edx
    88c5:	48 8d 35 2c 39 00 00 	lea    0x392c(%rip),%rsi        # c1f8 <_IO_stdin_used+0x1f8>
    88cc:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    88d2:	e8 39 b9 ff ff       	call   4210 <buf_put>
    88d7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    88de:	ff ff 7f 
    88e1:	48 23 55 00          	and    0x0(%rbp),%rdx
    88e5:	0f 84 86 02 00 00    	je     8b71 <fwp_write+0x951>
    88eb:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    88f0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    88f4:	48 85 d2             	test   %rdx,%rdx
    88f7:	0f 84 ae 00 00 00    	je     89ab <fwp_write+0x78b>
    88fd:	8b 0a                	mov    (%rdx),%ecx
    88ff:	83 f9 1c             	cmp    $0x1c,%ecx
    8902:	0f 84 58 06 00 00    	je     8f60 <fwp_write+0xd40>
    8908:	83 f9 1b             	cmp    $0x1b,%ecx
    890b:	0f 87 9a 00 00 00    	ja     89ab <fwp_write+0x78b>
    8911:	be 01 00 00 00       	mov    $0x1,%esi
    8916:	48 d3 e6             	shl    %cl,%rsi
    8919:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    891f:	0f 85 4b 04 00 00    	jne    8d70 <fwp_write+0xb50>
    8925:	f7 c6 84 04 00 00    	test   $0x484,%esi
    892b:	0f 85 0f 04 00 00    	jne    8d40 <fwp_write+0xb20>
    8931:	83 e6 21             	and    $0x21,%esi
    8934:	74 75                	je     89ab <fwp_write+0x78b>
    8936:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    893b:	48 85 ff             	test   %rdi,%rdi
    893e:	79 07                	jns    8947 <fwp_write+0x727>
    8940:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8944:	4c 01 ee             	add    %r13,%rsi
    8947:	48 0f be 3e          	movsbq (%rsi),%rdi
    894b:	85 c9                	test   %ecx,%ecx
    894d:	40 0f b6 f7          	movzbl %dil,%esi
    8951:	48 0f 44 f7          	cmove  %rdi,%rsi
    8955:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    895c:	00 00 00 00 
    8960:	31 c9                	xor    %ecx,%ecx
    8962:	48 89 df             	mov    %rbx,%rdi
    8965:	49 83 c5 01          	add    $0x1,%r13
    8969:	e8 b2 f8 ff ff       	call   8220 <fwp_write>
    896e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8975:	ff ff 7f 
    8978:	48 23 55 00          	and    0x0(%rbp),%rdx
    897c:	49 39 d5             	cmp    %rdx,%r13
    897f:	0f 83 ec 01 00 00    	jae    8b71 <fwp_write+0x951>
    8985:	ba 02 00 00 00       	mov    $0x2,%edx
    898a:	48 89 df             	mov    %rbx,%rdi
    898d:	48 8d 35 61 38 00 00 	lea    0x3861(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    8994:	e8 77 b8 ff ff       	call   4210 <buf_put>
    8999:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    899e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    89a2:	48 85 d2             	test   %rdx,%rdx
    89a5:	0f 85 52 ff ff ff    	jne    88fd <fwp_write+0x6dd>
    89ab:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    89b0:	48 85 ff             	test   %rdi,%rdi
    89b3:	0f 88 cf 05 00 00    	js     8f88 <fwp_write+0xd68>
    89b9:	48 8b 31             	mov    (%rcx),%rsi
    89bc:	eb a2                	jmp    8960 <fwp_write+0x740>
    89be:	66 90                	xchg   %ax,%ax
    89c0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    89c7:	00 
    89c8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    89cf:	00 00 
    89d1:	0f 85 1e fd ff ff    	jne    86f5 <fwp_write+0x4d5>
    89d7:	ba 08 00 00 00       	mov    $0x8,%edx
    89dc:	48 8d 35 e2 37 00 00 	lea    0x37e2(%rip),%rsi        # c1c5 <_IO_stdin_used+0x1c5>
    89e3:	e9 4b fa ff ff       	jmp    8433 <fwp_write+0x213>
    89e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    89ef:	00 
    89f0:	89 e8                	mov    %ebp,%eax
    89f2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    89f9:	76 03                	jbe    89fe <fwp_write+0x7de>
    89fb:	8b 45 00             	mov    0x0(%rbp),%eax
    89fe:	41 89 c6             	mov    %eax,%r14d
    8a01:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8a06:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8a0b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8a0f:	4c 89 ef             	mov    %r13,%rdi
    8a12:	e8 39 aa ff ff       	call   3450 <strlen@plt>
    8a17:	4c 89 ee             	mov    %r13,%rsi
    8a1a:	48 89 df             	mov    %rbx,%rdi
    8a1d:	48 89 c2             	mov    %rax,%rdx
    8a20:	e8 eb b7 ff ff       	call   4210 <buf_put>
    8a25:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8a2a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8a2e:	85 f6                	test   %esi,%esi
    8a30:	0f 8e 80 f8 ff ff    	jle    82b6 <fwp_write+0x96>
    8a36:	45 31 ed             	xor    %r13d,%r13d
    8a39:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8a3e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8a43:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8a48:	ba 01 00 00 00       	mov    $0x1,%edx
    8a4d:	4c 89 fe             	mov    %r15,%rsi
    8a50:	48 89 04 24          	mov    %rax,(%rsp)
    8a54:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8a59:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8a5d:	48 89 df             	mov    %rbx,%rdi
    8a60:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8a64:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8a69:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8a6e:	e8 9d b7 ff ff       	call   4210 <buf_put>
    8a73:	41 8b 06             	mov    (%r14),%eax
    8a76:	83 f8 0e             	cmp    $0xe,%eax
    8a79:	0f 84 71 02 00 00    	je     8cf0 <fwp_write+0xad0>
    8a7f:	83 f8 10             	cmp    $0x10,%eax
    8a82:	0f 84 38 02 00 00    	je     8cc0 <fwp_write+0xaa0>
    8a88:	83 f8 0a             	cmp    $0xa,%eax
    8a8b:	0f 84 7f 04 00 00    	je     8f10 <fwp_write+0xcf0>
    8a91:	0f 8f f9 00 00 00    	jg     8b90 <fwp_write+0x970>
    8a97:	83 f8 03             	cmp    $0x3,%eax
    8a9a:	0f 8f 50 04 00 00    	jg     8ef0 <fwp_write+0xcd0>
    8aa0:	85 c0                	test   %eax,%eax
    8aa2:	78 10                	js     8ab4 <fwp_write+0x894>
    8aa4:	48 8b 04 24          	mov    (%rsp),%rax
    8aa8:	48 c1 e8 3f          	shr    $0x3f,%rax
    8aac:	85 c0                	test   %eax,%eax
    8aae:	0f 85 f9 00 00 00    	jne    8bad <fwp_write+0x98d>
    8ab4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8ab9:	48 8b 34 24          	mov    (%rsp),%rsi
    8abd:	31 c9                	xor    %ecx,%ecx
    8abf:	48 89 df             	mov    %rbx,%rdi
    8ac2:	e8 59 f7 ff ff       	call   8220 <fwp_write>
    8ac7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8acc:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8ad1:	49 83 c5 01          	add    $0x1,%r13
    8ad5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8ad9:	0f 8f 5f ff ff ff    	jg     8a3e <fwp_write+0x81e>
    8adf:	e9 d2 f7 ff ff       	jmp    82b6 <fwp_write+0x96>
    8ae4:	0f 1f 40 00          	nopl   0x0(%rax)
    8ae8:	ba 06 00 00 00       	mov    $0x6,%edx
    8aed:	48 8d 35 f7 36 00 00 	lea    0x36f7(%rip),%rsi        # c1eb <_IO_stdin_used+0x1eb>
    8af4:	45 31 ed             	xor    %r13d,%r13d
    8af7:	e8 14 b7 ff ff       	call   4210 <buf_put>
    8afc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8b01:	75 19                	jne    8b1c <fwp_write+0x8fc>
    8b03:	eb 6c                	jmp    8b71 <fwp_write+0x951>
    8b05:	0f 1f 00             	nopl   (%rax)
    8b08:	ba 02 00 00 00       	mov    $0x2,%edx
    8b0d:	48 8d 35 e1 36 00 00 	lea    0x36e1(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    8b14:	48 89 df             	mov    %rbx,%rdi
    8b17:	e8 f4 b6 ff ff       	call   4210 <buf_put>
    8b1c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8b22:	b9 00 02 00 00       	mov    $0x200,%ecx
    8b27:	31 c0                	xor    %eax,%eax
    8b29:	49 83 c5 01          	add    $0x1,%r13
    8b2d:	4c 8d 05 be 36 00 00 	lea    0x36be(%rip),%r8        # c1f2 <_IO_stdin_used+0x1f2>
    8b34:	ba 02 00 00 00       	mov    $0x2,%edx
    8b39:	be 00 02 00 00       	mov    $0x200,%esi
    8b3e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8b45:	00 
    8b46:	e8 65 a8 ff ff       	call   33b0 <__snprintf_chk@plt>
    8b4b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8b52:	00 
    8b53:	e8 f8 a8 ff ff       	call   3450 <strlen@plt>
    8b58:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8b5f:	00 
    8b60:	48 89 df             	mov    %rbx,%rdi
    8b63:	48 89 c2             	mov    %rax,%rdx
    8b66:	e8 a5 b6 ff ff       	call   4210 <buf_put>
    8b6b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8b6f:	72 97                	jb     8b08 <fwp_write+0x8e8>
    8b71:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8b76:	ba 01 00 00 00       	mov    $0x1,%edx
    8b7b:	48 89 df             	mov    %rbx,%rdi
    8b7e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8b83:	e8 88 b6 ff ff       	call   4210 <buf_put>
    8b88:	e9 29 f7 ff ff       	jmp    82b6 <fwp_write+0x96>
    8b8d:	0f 1f 00             	nopl   (%rax)
    8b90:	83 f8 0b             	cmp    $0xb,%eax
    8b93:	0f 85 1b ff ff ff    	jne    8ab4 <fwp_write+0x894>
    8b99:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8b9e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8ba2:	83 e0 01             	and    $0x1,%eax
    8ba5:	85 c0                	test   %eax,%eax
    8ba7:	0f 84 07 ff ff ff    	je     8ab4 <fwp_write+0x894>
    8bad:	4c 89 fe             	mov    %r15,%rsi
    8bb0:	48 89 df             	mov    %rbx,%rdi
    8bb3:	ba 01 00 00 00       	mov    $0x1,%edx
    8bb8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8bbd:	e8 4e b6 ff ff       	call   4210 <buf_put>
    8bc2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8bc7:	48 8b 34 24          	mov    (%rsp),%rsi
    8bcb:	31 c9                	xor    %ecx,%ecx
    8bcd:	48 89 df             	mov    %rbx,%rdi
    8bd0:	e8 4b f6 ff ff       	call   8220 <fwp_write>
    8bd5:	ba 01 00 00 00       	mov    $0x1,%edx
    8bda:	4c 89 fe             	mov    %r15,%rsi
    8bdd:	48 89 df             	mov    %rbx,%rdi
    8be0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8be5:	e8 26 b6 ff ff       	call   4210 <buf_put>
    8bea:	e9 d8 fe ff ff       	jmp    8ac7 <fwp_write+0x8a7>
    8bef:	90                   	nop
    8bf0:	ba 01 00 00 00       	mov    $0x1,%edx
    8bf5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8bfa:	48 89 df             	mov    %rbx,%rdi
    8bfd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8c02:	e8 09 b6 ff ff       	call   4210 <buf_put>
    8c07:	e9 aa f6 ff ff       	jmp    82b6 <fwp_write+0x96>
    8c0c:	0f 1f 40 00          	nopl   0x0(%rax)
    8c10:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8c15:	ba 01 00 00 00       	mov    $0x1,%edx
    8c1a:	48 89 df             	mov    %rbx,%rdi
    8c1d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8c22:	e8 e9 b5 ff ff       	call   4210 <buf_put>
    8c27:	e9 8a f6 ff ff       	jmp    82b6 <fwp_write+0x96>
    8c2c:	0f 1f 40 00          	nopl   0x0(%rax)
    8c30:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8c34:	48 8b 13             	mov    (%rbx),%rdx
    8c37:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    8c3c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8c40:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8c44:	e9 6d f6 ff ff       	jmp    82b6 <fwp_write+0x96>
    8c49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8c50:	ba 02 00 00 00       	mov    $0x2,%edx
    8c55:	48 8d 35 99 35 00 00 	lea    0x3599(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    8c5c:	48 89 df             	mov    %rbx,%rdi
    8c5f:	e8 ac b5 ff ff       	call   4210 <buf_put>
    8c64:	e9 72 f8 ff ff       	jmp    84db <fwp_write+0x2bb>
    8c69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8c70:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8c75:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8c7a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    8c7e:	48 89 f7             	mov    %rsi,%rdi
    8c81:	48 89 34 24          	mov    %rsi,(%rsp)
    8c85:	e8 c6 a7 ff ff       	call   3450 <strlen@plt>
    8c8a:	48 8b 34 24          	mov    (%rsp),%rsi
    8c8e:	48 89 df             	mov    %rbx,%rdi
    8c91:	48 89 c2             	mov    %rax,%rdx
    8c94:	e8 77 b5 ff ff       	call   4210 <buf_put>
    8c99:	ba 03 00 00 00       	mov    $0x3,%edx
    8c9e:	48 8d 35 73 35 00 00 	lea    0x3573(%rip),%rsi        # c218 <_IO_stdin_used+0x218>
    8ca5:	48 89 df             	mov    %rbx,%rdi
    8ca8:	e8 63 b5 ff ff       	call   4210 <buf_put>
    8cad:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    8cb2:	e9 35 f8 ff ff       	jmp    84ec <fwp_write+0x2cc>
    8cb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8cbe:	00 00 
    8cc0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8cc5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    8cc9:	48 85 ff             	test   %rdi,%rdi
    8ccc:	0f 84 e2 fd ff ff    	je     8ab4 <fwp_write+0x894>
    8cd2:	48 8d 35 29 35 00 00 	lea    0x3529(%rip),%rsi        # c202 <_IO_stdin_used+0x202>
    8cd9:	e8 52 a8 ff ff       	call   3530 <strcmp@plt>
    8cde:	85 c0                	test   %eax,%eax
    8ce0:	0f 95 c0             	setne  %al
    8ce3:	0f b6 c0             	movzbl %al,%eax
    8ce6:	e9 c1 fd ff ff       	jmp    8aac <fwp_write+0x88c>
    8ceb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8cf0:	31 c0                	xor    %eax,%eax
    8cf2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    8cf9:	00 
    8cfa:	0f 97 c0             	seta   %al
    8cfd:	e9 aa fd ff ff       	jmp    8aac <fwp_write+0x88c>
    8d02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d08:	48 89 df             	mov    %rbx,%rdi
    8d0b:	ba 02 00 00 00       	mov    $0x2,%edx
    8d10:	48 8d 35 e8 34 00 00 	lea    0x34e8(%rip),%rsi        # c1ff <_IO_stdin_used+0x1ff>
    8d17:	e8 f4 b4 ff ff       	call   4210 <buf_put>
    8d1c:	4c 89 e8             	mov    %r13,%rax
    8d1f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    8d24:	31 c9                	xor    %ecx,%ecx
    8d26:	48 c1 e0 04          	shl    $0x4,%rax
    8d2a:	48 89 df             	mov    %rbx,%rdi
    8d2d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    8d32:	e8 e9 f4 ff ff       	call   8220 <fwp_write>
    8d37:	e9 5e f6 ff ff       	jmp    839a <fwp_write+0x17a>
    8d3c:	0f 1f 40 00          	nopl   0x0(%rax)
    8d40:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    8d45:	48 85 ff             	test   %rdi,%rdi
    8d48:	79 0c                	jns    8d56 <fwp_write+0xb36>
    8d4a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    8d51:	00 
    8d52:	48 03 75 10          	add    0x10(%rbp),%rsi
    8d56:	48 63 3e             	movslq (%rsi),%rdi
    8d59:	83 f9 02             	cmp    $0x2,%ecx
    8d5c:	89 fe                	mov    %edi,%esi
    8d5e:	48 0f 44 f7          	cmove  %rdi,%rsi
    8d62:	e9 f9 fb ff ff       	jmp    8960 <fwp_write+0x740>
    8d67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8d6e:	00 00 
    8d70:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    8d75:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    8d7a:	48 85 ff             	test   %rdi,%rdi
    8d7d:	0f 88 0f 03 00 00    	js     9092 <fwp_write+0xe72>
    8d83:	49 0f bf 38          	movswq (%r8),%rdi
    8d87:	83 f9 01             	cmp    $0x1,%ecx
    8d8a:	0f b7 f7             	movzwl %di,%esi
    8d8d:	48 0f 44 f7          	cmove  %rdi,%rsi
    8d91:	e9 ca fb ff ff       	jmp    8960 <fwp_write+0x740>
    8d96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8d9d:	00 00 00 
    8da0:	ba 01 00 00 00       	mov    $0x1,%edx
    8da5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8daa:	48 83 c5 08          	add    $0x8,%rbp
    8dae:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8db3:	e8 58 b4 ff ff       	call   4210 <buf_put>
    8db8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8dbd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    8dc2:	4d 85 ed             	test   %r13,%r13
    8dc5:	75 46                	jne    8e0d <fwp_write+0xbed>
    8dc7:	e9 04 01 00 00       	jmp    8ed0 <fwp_write+0xcb0>
    8dcc:	0f 1f 40 00          	nopl   0x0(%rax)
    8dd0:	41 80 f9 09          	cmp    $0x9,%r9b
    8dd4:	0f 84 d6 00 00 00    	je     8eb0 <fwp_write+0xc90>
    8dda:	41 80 f9 0a          	cmp    $0xa,%r9b
    8dde:	0f 85 9c 00 00 00    	jne    8e80 <fwp_write+0xc60>
    8de4:	ba 02 00 00 00       	mov    $0x2,%edx
    8de9:	48 8d 35 eb 33 00 00 	lea    0x33eb(%rip),%rsi        # c1db <_IO_stdin_used+0x1db>
    8df0:	48 89 df             	mov    %rbx,%rdi
    8df3:	e8 18 b4 ff ff       	call   4210 <buf_put>
    8df8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8dff:	00 
    8e00:	48 83 c5 01          	add    $0x1,%rbp
    8e04:	49 39 ec             	cmp    %rbp,%r12
    8e07:	0f 84 c3 00 00 00    	je     8ed0 <fwp_write+0xcb0>
    8e0d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    8e12:	41 80 f9 0d          	cmp    $0xd,%r9b
    8e16:	74 28                	je     8e40 <fwp_write+0xc20>
    8e18:	7e b6                	jle    8dd0 <fwp_write+0xbb0>
    8e1a:	41 80 f9 22          	cmp    $0x22,%r9b
    8e1e:	74 40                	je     8e60 <fwp_write+0xc40>
    8e20:	41 80 f9 5c          	cmp    $0x5c,%r9b
    8e24:	75 5a                	jne    8e80 <fwp_write+0xc60>
    8e26:	ba 02 00 00 00       	mov    $0x2,%edx
    8e2b:	48 8d 35 a6 33 00 00 	lea    0x33a6(%rip),%rsi        # c1d8 <_IO_stdin_used+0x1d8>
    8e32:	48 89 df             	mov    %rbx,%rdi
    8e35:	e8 d6 b3 ff ff       	call   4210 <buf_put>
    8e3a:	eb c4                	jmp    8e00 <fwp_write+0xbe0>
    8e3c:	0f 1f 40 00          	nopl   0x0(%rax)
    8e40:	ba 02 00 00 00       	mov    $0x2,%edx
    8e45:	48 8d 35 95 33 00 00 	lea    0x3395(%rip),%rsi        # c1e1 <_IO_stdin_used+0x1e1>
    8e4c:	48 89 df             	mov    %rbx,%rdi
    8e4f:	e8 bc b3 ff ff       	call   4210 <buf_put>
    8e54:	eb aa                	jmp    8e00 <fwp_write+0xbe0>
    8e56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8e5d:	00 00 00 
    8e60:	ba 02 00 00 00       	mov    $0x2,%edx
    8e65:	48 8d 35 69 33 00 00 	lea    0x3369(%rip),%rsi        # c1d5 <_IO_stdin_used+0x1d5>
    8e6c:	48 89 df             	mov    %rbx,%rdi
    8e6f:	e8 9c b3 ff ff       	call   4210 <buf_put>
    8e74:	eb 8a                	jmp    8e00 <fwp_write+0xbe0>
    8e76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8e7d:	00 00 00 
    8e80:	41 80 f9 1f          	cmp    $0x1f,%r9b
    8e84:	0f 86 2e 01 00 00    	jbe    8fb8 <fwp_write+0xd98>
    8e8a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    8e8e:	0f 84 24 01 00 00    	je     8fb8 <fwp_write+0xd98>
    8e94:	ba 01 00 00 00       	mov    $0x1,%edx
    8e99:	4c 89 fe             	mov    %r15,%rsi
    8e9c:	48 89 df             	mov    %rbx,%rdi
    8e9f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    8ea4:	e8 67 b3 ff ff       	call   4210 <buf_put>
    8ea9:	e9 52 ff ff ff       	jmp    8e00 <fwp_write+0xbe0>
    8eae:	66 90                	xchg   %ax,%ax
    8eb0:	ba 02 00 00 00       	mov    $0x2,%edx
    8eb5:	48 8d 35 22 33 00 00 	lea    0x3322(%rip),%rsi        # c1de <_IO_stdin_used+0x1de>
    8ebc:	48 89 df             	mov    %rbx,%rdi
    8ebf:	e8 4c b3 ff ff       	call   4210 <buf_put>
    8ec4:	e9 37 ff ff ff       	jmp    8e00 <fwp_write+0xbe0>
    8ec9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ed0:	ba 01 00 00 00       	mov    $0x1,%edx
    8ed5:	4c 89 fe             	mov    %r15,%rsi
    8ed8:	48 89 df             	mov    %rbx,%rdi
    8edb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8ee0:	e8 2b b3 ff ff       	call   4210 <buf_put>
    8ee5:	e9 cc f3 ff ff       	jmp    82b6 <fwp_write+0x96>
    8eea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ef0:	83 f8 04             	cmp    $0x4,%eax
    8ef3:	0f 85 bb fb ff ff    	jne    8ab4 <fwp_write+0x894>
    8ef9:	48 8b 04 24          	mov    (%rsp),%rax
    8efd:	48 8b 40 08          	mov    0x8(%rax),%rax
    8f01:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8f06:	48 c1 e8 3f          	shr    $0x3f,%rax
    8f0a:	e9 96 fc ff ff       	jmp    8ba5 <fwp_write+0x985>
    8f0f:	90                   	nop
    8f10:	8b 0c 24             	mov    (%rsp),%ecx
    8f13:	31 c0                	xor    %eax,%eax
    8f15:	85 c9                	test   %ecx,%ecx
    8f17:	0f 98 c0             	sets   %al
    8f1a:	e9 86 fc ff ff       	jmp    8ba5 <fwp_write+0x985>
    8f1f:	90                   	nop
    8f20:	48 f7 d8             	neg    %rax
    8f23:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    8f2a:	00 
    8f2b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    8f32:	2d 
    8f33:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8f3a:	00 
    8f3b:	48 83 d2 00          	adc    $0x0,%rdx
    8f3f:	48 89 c6             	mov    %rax,%rsi
    8f42:	48 f7 da             	neg    %rdx
    8f45:	e8 f6 aa ff ff       	call   3a40 <fwp_fmt_u128>
    8f4a:	e9 51 f3 ff ff       	jmp    82a0 <fwp_write+0x80>
    8f4f:	90                   	nop
    8f50:	b8 7d 00 00 00       	mov    $0x7d,%eax
    8f55:	e9 c3 f5 ff ff       	jmp    851d <fwp_write+0x2fd>
    8f5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8f60:	4c 89 e9             	mov    %r13,%rcx
    8f63:	48 c1 e1 04          	shl    $0x4,%rcx
    8f67:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    8f6c:	48 85 ff             	test   %rdi,%rdi
    8f6f:	0f 89 eb f9 ff ff    	jns    8960 <fwp_write+0x740>
    8f75:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8f79:	48 89 ce             	mov    %rcx,%rsi
    8f7c:	e9 df f9 ff ff       	jmp    8960 <fwp_write+0x740>
    8f81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8f88:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8f8f:	00 
    8f90:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8f94:	e9 20 fa ff ff       	jmp    89b9 <fwp_write+0x799>
    8f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8fa0:	ba 02 00 00 00       	mov    $0x2,%edx
    8fa5:	48 8d 35 f9 31 00 00 	lea    0x31f9(%rip),%rsi        # c1a5 <_IO_stdin_used+0x1a5>
    8fac:	e9 2d f7 ff ff       	jmp    86de <fwp_write+0x4be>
    8fb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8fb8:	4c 8d 05 25 32 00 00 	lea    0x3225(%rip),%r8        # c1e4 <_IO_stdin_used+0x1e4>
    8fbf:	b9 10 00 00 00       	mov    $0x10,%ecx
    8fc4:	31 c0                	xor    %eax,%eax
    8fc6:	ba 02 00 00 00       	mov    $0x2,%edx
    8fcb:	be 10 00 00 00       	mov    $0x10,%esi
    8fd0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8fd7:	00 
    8fd8:	e8 d3 a3 ff ff       	call   33b0 <__snprintf_chk@plt>
    8fdd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8fe4:	00 
    8fe5:	e8 66 a4 ff ff       	call   3450 <strlen@plt>
    8fea:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8ff1:	00 
    8ff2:	48 89 df             	mov    %rbx,%rdi
    8ff5:	48 89 c2             	mov    %rax,%rdx
    8ff8:	e8 13 b2 ff ff       	call   4210 <buf_put>
    8ffd:	e9 fe fd ff ff       	jmp    8e00 <fwp_write+0xbe0>
    9002:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9008:	66 0f ef c0          	pxor   %xmm0,%xmm0
    900c:	48 8d 35 8c 31 00 00 	lea    0x318c(%rip),%rsi        # c19f <_IO_stdin_used+0x19f>
    9013:	48 8d 05 84 31 00 00 	lea    0x3184(%rip),%rax        # c19e <_IO_stdin_used+0x19e>
    901a:	4c 89 e7             	mov    %r12,%rdi
    901d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9021:	48 0f 46 f0          	cmovbe %rax,%rsi
    9025:	e8 c6 a3 ff ff       	call   33f0 <strcpy@plt>
    902a:	e9 71 f2 ff ff       	jmp    82a0 <fwp_write+0x80>
    902f:	90                   	nop
    9030:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9034:	48 8d 35 64 31 00 00 	lea    0x3164(%rip),%rsi        # c19f <_IO_stdin_used+0x19f>
    903b:	48 8d 05 5c 31 00 00 	lea    0x315c(%rip),%rax        # c19e <_IO_stdin_used+0x19e>
    9042:	0f 2f c8             	comiss %xmm0,%xmm1
    9045:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    904c:	00 
    904d:	4c 89 e7             	mov    %r12,%rdi
    9050:	48 0f 46 f0          	cmovbe %rax,%rsi
    9054:	e8 97 a3 ff ff       	call   33f0 <strcpy@plt>
    9059:	e9 42 f2 ff ff       	jmp    82a0 <fwp_write+0x80>
    905e:	66 90                	xchg   %ax,%ax
    9060:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9065:	45 85 c0             	test   %r8d,%r8d
    9068:	75 34                	jne    909e <fwp_write+0xe7e>
    906a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9071:	00 
    9072:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9079:	00 00 
    907b:	0f 85 74 f6 ff ff    	jne    86f5 <fwp_write+0x4d5>
    9081:	ba 02 00 00 00       	mov    $0x2,%edx
    9086:	48 8d 35 88 31 00 00 	lea    0x3188(%rip),%rsi        # c215 <_IO_stdin_used+0x215>
    908d:	e9 a1 f3 ff ff       	jmp    8433 <fwp_write+0x213>
    9092:	48 03 75 10          	add    0x10(%rbp),%rsi
    9096:	49 89 f0             	mov    %rsi,%r8
    9099:	e9 e5 fc ff ff       	jmp    8d83 <fwp_write+0xb63>
    909e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    90a3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    90a8:	85 ff                	test   %edi,%edi
    90aa:	0f 84 fa f3 ff ff    	je     84aa <fwp_write+0x28a>
    90b0:	ba 01 00 00 00       	mov    $0x1,%edx
    90b5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    90ba:	48 89 df             	mov    %rbx,%rdi
    90bd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    90c2:	e8 49 b1 ff ff       	call   4210 <buf_put>
    90c7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    90cc:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    90d1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    90d7:	85 c0                	test   %eax,%eax
    90d9:	0f 8f f0 f3 ff ff    	jg     84cf <fwp_write+0x2af>
    90df:	e9 34 f4 ff ff       	jmp    8518 <fwp_write+0x2f8>
    90e4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    90e8:	49 89 c5             	mov    %rax,%r13
    90eb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    90f0:	49 89 c4             	mov    %rax,%r12
    90f3:	49 c1 fd 3f          	sar    $0x3f,%r13
    90f7:	4c 09 e8             	or     %r13,%rax
    90fa:	0f 84 a7 00 00 00    	je     91a7 <fwp_write+0xf87>
    9100:	48 8d 2d 99 51 00 00 	lea    0x5199(%rip),%rbp        # e2a0 <units.0>
    9107:	4d 89 e7             	mov    %r12,%r15
    910a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    910e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9113:	4c 89 ff             	mov    %r15,%rdi
    9116:	4c 89 ee             	mov    %r13,%rsi
    9119:	44 89 0c 24          	mov    %r9d,(%rsp)
    911d:	48 99                	cqto
    911f:	48 89 d1             	mov    %rdx,%rcx
    9122:	48 89 c2             	mov    %rax,%rdx
    9125:	e8 66 23 00 00       	call   b490 <__divmodti4>
    912a:	44 8b 0c 24          	mov    (%rsp),%r9d
    912e:	48 89 c1             	mov    %rax,%rcx
    9131:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9136:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    913b:	0f 84 94 00 00 00    	je     91d5 <fwp_write+0xfb5>
    9141:	41 83 c1 01          	add    $0x1,%r9d
    9145:	48 83 c5 10          	add    $0x10,%rbp
    9149:	41 83 f9 05          	cmp    $0x5,%r9d
    914d:	75 bb                	jne    910a <fwp_write+0xeea>
    914f:	4d 85 ed             	test   %r13,%r13
    9152:	79 53                	jns    91a7 <fwp_write+0xf87>
    9154:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9159:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    915e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9163:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9168:	48 99                	cqto
    916a:	48 f7 d8             	neg    %rax
    916d:	48 83 d2 00          	adc    $0x0,%rdx
    9171:	48 89 c6             	mov    %rax,%rsi
    9174:	48 f7 da             	neg    %rdx
    9177:	e8 c4 a8 ff ff       	call   3a40 <fwp_fmt_u128>
    917c:	49 89 e8             	mov    %rbp,%r8
    917f:	ba 00 02 00 00       	mov    $0x200,%edx
    9184:	be 02 00 00 00       	mov    $0x2,%esi
    9189:	31 c0                	xor    %eax,%eax
    918b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9192:	00 
    9193:	48 8d 0d 76 30 00 00 	lea    0x3076(%rip),%rcx        # c210 <_IO_stdin_used+0x210>
    919a:	4c 89 e7             	mov    %r12,%rdi
    919d:	e8 3e a5 ff ff       	call   36e0 <__sprintf_chk@plt>
    91a2:	e9 f9 f0 ff ff       	jmp    82a0 <fwp_write+0x80>
    91a7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    91ac:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    91b1:	31 d2                	xor    %edx,%edx
    91b3:	48 89 ef             	mov    %rbp,%rdi
    91b6:	e8 85 a8 ff ff       	call   3a40 <fwp_fmt_u128>
    91bb:	eb bf                	jmp    917c <fwp_write+0xf5c>
    91bd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    91c4:	4e 61 4e 00 
    91c8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    91cf:	00 
    91d0:	e9 cb f0 ff ff       	jmp    82a0 <fwp_write+0x80>
    91d5:	44 89 0c 24          	mov    %r9d,(%rsp)
    91d9:	48 89 c8             	mov    %rcx,%rax
    91dc:	48 85 d2             	test   %rdx,%rdx
    91df:	78 51                	js     9232 <fwp_write+0x1012>
    91e1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    91e6:	48 89 c6             	mov    %rax,%rsi
    91e9:	48 89 ef             	mov    %rbp,%rdi
    91ec:	e8 4f a8 ff ff       	call   3a40 <fwp_fmt_u128>
    91f1:	44 8b 0c 24          	mov    (%rsp),%r9d
    91f5:	49 63 c1             	movslq %r9d,%rax
    91f8:	49 89 e8             	mov    %rbp,%r8
    91fb:	ba 00 02 00 00       	mov    $0x200,%edx
    9200:	be 02 00 00 00       	mov    $0x2,%esi
    9205:	48 c1 e0 04          	shl    $0x4,%rax
    9209:	48 8d 3d 90 50 00 00 	lea    0x5090(%rip),%rdi        # e2a0 <units.0>
    9210:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9217:	00 
    9218:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    921c:	48 8d 0d e8 2f 00 00 	lea    0x2fe8(%rip),%rcx        # c20b <_IO_stdin_used+0x20b>
    9223:	4c 89 e7             	mov    %r12,%rdi
    9226:	31 c0                	xor    %eax,%eax
    9228:	e8 b3 a4 ff ff       	call   36e0 <__sprintf_chk@plt>
    922d:	e9 6e f0 ff ff       	jmp    82a0 <fwp_write+0x80>
    9232:	48 f7 d8             	neg    %rax
    9235:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    923a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    923f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9244:	48 83 d2 00          	adc    $0x0,%rdx
    9248:	48 89 c6             	mov    %rax,%rsi
    924b:	48 f7 da             	neg    %rdx
    924e:	e8 ed a7 ff ff       	call   3a40 <fwp_fmt_u128>
    9253:	44 8b 0c 24          	mov    (%rsp),%r9d
    9257:	eb 9c                	jmp    91f5 <fwp_write+0xfd5>
    9259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009260 <fwp_main_thread>:
    9260:	f3 0f 1e fa          	endbr64
    9264:	41 57                	push   %r15
    9266:	41 56                	push   %r14
    9268:	41 55                	push   %r13
    926a:	41 54                	push   %r12
    926c:	55                   	push   %rbp
    926d:	53                   	push   %rbx
    926e:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
    9275:	44 8b 15 08 89 01 00 	mov    0x18908(%rip),%r10d        # 21b84 <fwp_heap+0x13a4>
    927c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9283:	00 00 
    9285:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    928c:	00 
    928d:	31 c0                	xor    %eax,%eax
    928f:	45 85 d2             	test   %r10d,%r10d
    9292:	0f 84 1a 13 00 00    	je     a5b2 <fwp_main_thread+0x1352>
    9298:	44 8b 0d e9 88 01 00 	mov    0x188e9(%rip),%r9d        # 21b88 <fwp_heap+0x13a8>
    929f:	45 85 c9             	test   %r9d,%r9d
    92a2:	0f 85 f9 12 00 00    	jne    a5a1 <fwp_main_thread+0x1341>
    92a8:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
    92af:	00 
    92b0:	31 f6                	xor    %esi,%esi
    92b2:	48 c7 05 b3 6e 01 00 	movq   $0x40000000,0x16eb3(%rip)        # 20170 <fwp_main_stack_size>
    92b9:	00 00 00 40 
    92bd:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    92c2:	48 89 05 af 6e 01 00 	mov    %rax,0x16eaf(%rip)        # 20178 <fwp_main_stack_top>
    92c9:	48 8d 05 d0 6d 00 00 	lea    0x6dd0(%rip),%rax        # 100a0 <alt.9>
    92d0:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
    92d7:	00 
    92d8:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
    92df:	00 
    92e0:	48 89 c7             	mov    %rax,%rdi
    92e3:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    92e8:	48 c7 84 24 e0 00 00 	movq   $0x10000,0xe0(%rsp)
    92ef:	00 00 00 01 00 
    92f4:	c7 84 24 d8 00 00 00 	movl   $0x0,0xd8(%rsp)
    92fb:	00 00 00 00 
    92ff:	e8 bc a3 ff ff       	call   36c0 <sigaltstack@plt>
    9304:	85 c0                	test   %eax,%eax
    9306:	0f 85 2c 21 00 00    	jne    b438 <fwp_main_thread+0x21d8>
    930c:	31 c0                	xor    %eax,%eax
    930e:	b9 12 00 00 00       	mov    $0x12,%ecx
    9313:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
    931a:	00 
    931b:	f3 48 ab             	rep stos %rax,(%rdi)
    931e:	48 8d 9c 24 40 01 00 	lea    0x140(%rsp),%rbx
    9325:	00 
    9326:	48 8d 05 c3 a9 ff ff 	lea    -0x563d(%rip),%rax        # 3cf0 <fwp_segv>
    932d:	c7 84 24 c8 01 00 00 	movl   $0x8000004,0x1c8(%rsp)
    9334:	04 00 00 08 
    9338:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
    933f:	00 
    9340:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9345:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
    934c:	00 
    934d:	e8 2e a2 ff ff       	call   3580 <sigemptyset@plt>
    9352:	85 c0                	test   %eax,%eax
    9354:	0f 85 de 20 00 00    	jne    b438 <fwp_main_thread+0x21d8>
    935a:	31 d2                	xor    %edx,%edx
    935c:	48 89 de             	mov    %rbx,%rsi
    935f:	bf 0b 00 00 00       	mov    $0xb,%edi
    9364:	e8 97 a0 ff ff       	call   3400 <sigaction@plt>
    9369:	85 c0                	test   %eax,%eax
    936b:	0f 85 c7 20 00 00    	jne    b438 <fwp_main_thread+0x21d8>
    9371:	31 d2                	xor    %edx,%edx
    9373:	48 89 de             	mov    %rbx,%rsi
    9376:	bf 07 00 00 00       	mov    $0x7,%edi
    937b:	e8 80 a0 ff ff       	call   3400 <sigaction@plt>
    9380:	85 c0                	test   %eax,%eax
    9382:	0f 85 b0 20 00 00    	jne    b438 <fwp_main_thread+0x21d8>
    9388:	44 8b 05 89 6d 01 00 	mov    0x16d89(%rip),%r8d        # 20118 <descent_registered>
    938f:	45 85 c0             	test   %r8d,%r8d
    9392:	0f 84 08 05 00 00    	je     98a0 <fwp_main_thread+0x640>
    9398:	8b 3d ea 6c 00 00    	mov    0x6cea(%rip),%edi        # 10088 <st.7>
    939e:	85 ff                	test   %edi,%edi
    93a0:	0f 84 26 05 00 00    	je     98cc <fwp_main_thread+0x66c>
    93a6:	48 8b 2d 13 74 01 00 	mov    0x17413(%rip),%rbp        # 207c0 <fwp_cur>
    93ad:	48 85 ed             	test   %rbp,%rbp
    93b0:	0f 84 c9 01 00 00    	je     957f <fwp_main_thread+0x31f>
    93b6:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    93bb:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    93bf:	48 89 eb             	mov    %rbp,%rbx
    93c2:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    93c7:	0f 84 41 01 00 00    	je     950e <fwp_main_thread+0x2ae>
    93cd:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    93d2:	0f 84 e8 03 00 00    	je     97c0 <fwp_main_thread+0x560>
    93d8:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    93dc:	0f 84 b6 03 00 00    	je     9798 <fwp_main_thread+0x538>
    93e2:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    93e6:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    93ea:	0f 85 50 04 00 00    	jne    9840 <fwp_main_thread+0x5e0>
    93f0:	48 8b 43 60          	mov    0x60(%rbx),%rax
    93f4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    93fb:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    93ff:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9406:	00 00 00 00 
    940a:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9411:	48 85 d2             	test   %rdx,%rdx
    9414:	74 07                	je     941d <fwp_main_thread+0x1bd>
    9416:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    941d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9421:	48 85 c0             	test   %rax,%rax
    9424:	74 34                	je     945a <fwp_main_thread+0x1fa>
    9426:	48 89 43 68          	mov    %rax,0x68(%rbx)
    942a:	48 8b 05 67 73 01 00 	mov    0x17367(%rip),%rax        # 20798 <fwp_timers>
    9431:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    9435:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    943c:	00 00 00 00 
    9440:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    9447:	48 85 c0             	test   %rax,%rax
    944a:	74 07                	je     9453 <fwp_main_thread+0x1f3>
    944c:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9453:	48 89 1d 3e 73 01 00 	mov    %rbx,0x1733e(%rip)        # 20798 <fwp_timers>
    945a:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    945e:	e8 4d de ff ff       	call   72b0 <fwp_block>
    9463:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    946a:	48 85 c9             	test   %rcx,%rcx
    946d:	74 47                	je     94b6 <fwp_main_thread+0x256>
    946f:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    9476:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    947d:	48 85 d2             	test   %rdx,%rdx
    9480:	0f 84 fa 03 00 00    	je     9880 <fwp_main_thread+0x620>
    9486:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    948d:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9494:	48 85 c0             	test   %rax,%rax
    9497:	74 07                	je     94a0 <fwp_main_thread+0x240>
    9499:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    94a0:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    94a7:	00 00 00 00 
    94ab:	66 0f ef ff          	pxor   %xmm7,%xmm7
    94af:	0f 11 bb 18 01 00 00 	movups %xmm7,0x118(%rbx)
    94b6:	48 8b 0d 03 73 01 00 	mov    0x17303(%rip),%rcx        # 207c0 <fwp_cur>
    94bd:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    94c1:	0f 84 69 03 00 00    	je     9830 <fwp_main_thread+0x5d0>
    94c7:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    94ce:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    94d5:	48 85 d2             	test   %rdx,%rdx
    94d8:	0f 84 b2 03 00 00    	je     9890 <fwp_main_thread+0x630>
    94de:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    94e5:	48 85 c0             	test   %rax,%rax
    94e8:	74 07                	je     94f1 <fwp_main_thread+0x291>
    94ea:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    94f1:	66 0f ef ff          	pxor   %xmm7,%xmm7
    94f5:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    94f9:	0f 11 bb 08 01 00 00 	movups %xmm7,0x108(%rbx)
    9500:	48 89 cb             	mov    %rcx,%rbx
    9503:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9508:	0f 85 bf fe ff ff    	jne    93cd <fwp_main_thread+0x16d>
    950e:	48 83 3d 42 8f 01 00 	cmpq   $0x0,0x18f42(%rip)        # 22458 <fwp_state_len>
    9515:	00 
    9516:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    951a:	75 0e                	jne    952a <fwp_main_thread+0x2ca>
    951c:	48 83 3d 24 8f 01 00 	cmpq   $0x0,0x18f24(%rip)        # 22448 <fwp_state_owners>
    9523:	00 
    9524:	0f 84 77 1d 00 00    	je     b2a1 <fwp_main_thread+0x2041>
    952a:	48 39 1d 87 72 01 00 	cmp    %rbx,0x17287(%rip)        # 207b8 <fwp_root>
    9531:	c7 05 65 6b 01 00 00 	movl   $0x0,0x16b65(%rip)        # 200a0 <fwp_exit_code>
    9538:	00 00 00 
    953b:	0f 85 38 1f 00 00    	jne    b479 <fwp_main_thread+0x2219>
    9541:	48 85 db             	test   %rbx,%rbx
    9544:	74 5f                	je     95a5 <fwp_main_thread+0x345>
    9546:	48 8b 15 3b 72 01 00 	mov    0x1723b(%rip),%rdx        # 20788 <fwp_tasks_active>
    954d:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    9551:	48 85 d2             	test   %rdx,%rdx
    9554:	74 4f                	je     95a5 <fwp_main_thread+0x345>
    9556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    955d:	00 00 00 
    9560:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9564:	75 08                	jne    956e <fwp_main_thread+0x30e>
    9566:	48 89 d7             	mov    %rdx,%rdi
    9569:	e8 92 ad ff ff       	call   4300 <fwp_cancel_tree.part.0>
    956e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    9575:	48 85 d2             	test   %rdx,%rdx
    9578:	75 e6                	jne    9560 <fwp_main_thread+0x300>
    957a:	e9 e6 01 00 00       	jmp    9765 <fwp_main_thread+0x505>
    957f:	48 83 3d d1 8e 01 00 	cmpq   $0x0,0x18ed1(%rip)        # 22458 <fwp_state_len>
    9586:	00 
    9587:	0f 84 e9 1b 00 00    	je     b176 <fwp_main_thread+0x1f16>
    958d:	48 83 3d 23 72 01 00 	cmpq   $0x0,0x17223(%rip)        # 207b8 <fwp_root>
    9594:	00 
    9595:	c7 05 01 6b 01 00 00 	movl   $0x0,0x16b01(%rip)        # 200a0 <fwp_exit_code>
    959c:	00 00 00 
    959f:	0f 85 d9 1e 00 00    	jne    b47e <fwp_main_thread+0x221e>
    95a5:	e8 f6 da ff ff       	call   70a0 <fwp_free_zombie>
    95aa:	48 83 3d f6 71 01 00 	cmpq   $0x0,0x171f6(%rip)        # 207a8 <fwp_ready_head>
    95b1:	00 
    95b2:	0f 85 93 a1 ff ff    	jne    374b <fwp_main_thread.cold>
    95b8:	48 83 3d d8 71 01 00 	cmpq   $0x0,0x171d8(%rip)        # 20798 <fwp_timers>
    95bf:	00 
    95c0:	0f 85 85 a1 ff ff    	jne    374b <fwp_main_thread.cold>
    95c6:	8b 05 b8 6b 01 00    	mov    0x16bb8(%rip),%eax        # 20184 <fwp_stack_pool_n>
    95cc:	85 c0                	test   %eax,%eax
    95ce:	74 3d                	je     960d <fwp_main_thread+0x3ad>
    95d0:	83 e8 01             	sub    $0x1,%eax
    95d3:	4c 8d 25 c6 6b 01 00 	lea    0x16bc6(%rip),%r12        # 201a0 <fwp_stack_pool>
    95da:	48 63 d8             	movslq %eax,%rbx
    95dd:	89 c0                	mov    %eax,%eax
    95df:	48 89 da             	mov    %rbx,%rdx
    95e2:	48 29 c2             	sub    %rax,%rdx
    95e5:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    95e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    95f0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    95f4:	89 1d 8a 6b 01 00    	mov    %ebx,0x16b8a(%rip)        # 20184 <fwp_stack_pool_n>
    95fa:	be 00 00 00 10       	mov    $0x10000000,%esi
    95ff:	48 83 eb 01          	sub    $0x1,%rbx
    9603:	e8 d8 9f ff ff       	call   35e0 <munmap@plt>
    9608:	48 39 eb             	cmp    %rbp,%rbx
    960b:	75 e3                	jne    95f0 <fwp_main_thread+0x390>
    960d:	8b 3d 09 6a 00 00    	mov    0x6a09(%rip),%edi        # 1001c <fwp_epfd>
    9613:	85 ff                	test   %edi,%edi
    9615:	78 05                	js     961c <fwp_main_thread+0x3bc>
    9617:	e8 b4 9e ff ff       	call   34d0 <close@plt>
    961c:	4c 8b 25 7d 6d 01 00 	mov    0x16d7d(%rip),%r12        # 203a0 <fwp_nfdws>
    9623:	48 8b 2d 7e 6d 01 00 	mov    0x16d7e(%rip),%rbp        # 203a8 <fwp_fdws>
    962a:	31 db                	xor    %ebx,%ebx
    962c:	c7 05 e6 69 00 00 ff 	movl   $0xffffffff,0x69e6(%rip)        # 1001c <fwp_epfd>
    9633:	ff ff ff 
    9636:	4d 85 e4             	test   %r12,%r12
    9639:	74 32                	je     966d <fwp_main_thread+0x40d>
    963b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9640:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9645:	48 85 ff             	test   %rdi,%rdi
    9648:	74 1a                	je     9664 <fwp_main_thread+0x404>
    964a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    964e:	0f 85 f7 a0 ff ff    	jne    374b <fwp_main_thread.cold>
    9654:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9659:	0f 85 ec a0 ff ff    	jne    374b <fwp_main_thread.cold>
    965f:	e8 8c c1 ff ff       	call   57f0 <fwp_mem_free>
    9664:	48 83 c3 01          	add    $0x1,%rbx
    9668:	4c 39 e3             	cmp    %r12,%rbx
    966b:	75 d3                	jne    9640 <fwp_main_thread+0x3e0>
    966d:	48 89 ef             	mov    %rbp,%rdi
    9670:	e8 7b c1 ff ff       	call   57f0 <fwp_mem_free>
    9675:	48 8b 15 3c 71 01 00 	mov    0x1713c(%rip),%rdx        # 207b8 <fwp_root>
    967c:	48 c7 05 21 6d 01 00 	movq   $0x0,0x16d21(%rip)        # 203a8 <fwp_fdws>
    9683:	00 00 00 00 
    9687:	48 c7 05 0e 6d 01 00 	movq   $0x0,0x16d0e(%rip)        # 203a0 <fwp_nfdws>
    968e:	00 00 00 00 
    9692:	48 85 d2             	test   %rdx,%rdx
    9695:	74 4e                	je     96e5 <fwp_main_thread+0x485>
    9697:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    969c:	0f 85 a9 a0 ff ff    	jne    374b <fwp_main_thread.cold>
    96a2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    96a9:	00 
    96aa:	0f 85 9b a0 ff ff    	jne    374b <fwp_main_thread.cold>
    96b0:	48 83 3d a0 8d 01 00 	cmpq   $0x0,0x18da0(%rip)        # 22458 <fwp_state_len>
    96b7:	00 
    96b8:	0f 85 8d a0 ff ff    	jne    374b <fwp_main_thread.cold>
    96be:	48 83 3d 82 8d 01 00 	cmpq   $0x0,0x18d82(%rip)        # 22448 <fwp_state_owners>
    96c5:	00 
    96c6:	0f 85 7f a0 ff ff    	jne    374b <fwp_main_thread.cold>
    96cc:	b9 79 00 00 00       	mov    $0x79,%ecx
    96d1:	31 c0                	xor    %eax,%eax
    96d3:	48 8d 3d e6 6c 01 00 	lea    0x16ce6(%rip),%rdi        # 203c0 <fwp_root_context>
    96da:	f3 48 ab             	rep stos %rax,(%rdi)
    96dd:	48 89 d7             	mov    %rdx,%rdi
    96e0:	e8 0b c1 ff ff       	call   57f0 <fwp_mem_free>
    96e5:	48 8b 3d 34 69 00 00 	mov    0x6934(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    96ec:	48 c7 05 c9 70 01 00 	movq   $0x0,0x170c9(%rip)        # 207c0 <fwp_cur>
    96f3:	00 00 00 00 
    96f7:	48 c7 05 b6 70 01 00 	movq   $0x0,0x170b6(%rip)        # 207b8 <fwp_root>
    96fe:	00 00 00 00 
    9702:	e8 b9 9e ff ff       	call   35c0 <fflush@plt>
    9707:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
    970e:	00 
    970f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9716:	00 00 
    9718:	0f 85 26 1d 00 00    	jne    b444 <fwp_main_thread+0x21e4>
    971e:	48 81 c4 e8 01 00 00 	add    $0x1e8,%rsp
    9725:	31 c0                	xor    %eax,%eax
    9727:	5b                   	pop    %rbx
    9728:	5d                   	pop    %rbp
    9729:	41 5c                	pop    %r12
    972b:	41 5d                	pop    %r13
    972d:	41 5e                	pop    %r14
    972f:	41 5f                	pop    %r15
    9731:	c3                   	ret
    9732:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9738:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    973f:	48 89 1d 5a 70 01 00 	mov    %rbx,0x1705a(%rip)        # 207a0 <fwp_ready_tail>
    9746:	e8 65 db ff ff       	call   72b0 <fwp_block>
    974b:	e8 50 d9 ff ff       	call   70a0 <fwp_free_zombie>
    9750:	48 83 3d 30 70 01 00 	cmpq   $0x0,0x17030(%rip)        # 20788 <fwp_tasks_active>
    9757:	00 
    9758:	0f 84 47 fe ff ff    	je     95a5 <fwp_main_thread+0x345>
    975e:	48 8b 1d 53 70 01 00 	mov    0x17053(%rip),%rbx        # 207b8 <fwp_root>
    9765:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    9769:	75 db                	jne    9746 <fwp_main_thread+0x4e6>
    976b:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    976f:	75 d5                	jne    9746 <fwp_main_thread+0x4e6>
    9771:	48 8b 05 28 70 01 00 	mov    0x17028(%rip),%rax        # 207a0 <fwp_ready_tail>
    9778:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    977c:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    9783:	00 00 00 00 
    9787:	48 85 c0             	test   %rax,%rax
    978a:	75 ac                	jne    9738 <fwp_main_thread+0x4d8>
    978c:	48 89 1d 15 70 01 00 	mov    %rbx,0x17015(%rip)        # 207a8 <fwp_ready_head>
    9793:	eb aa                	jmp    973f <fwp_main_thread+0x4df>
    9795:	0f 1f 00             	nopl   (%rax)
    9798:	e8 c3 ad ff ff       	call   4560 <fwp_now_ns>
    979d:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    97a1:	7c 1d                	jl     97c0 <fwp_main_thread+0x560>
    97a3:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    97a7:	75 17                	jne    97c0 <fwp_main_thread+0x560>
    97a9:	48 89 ef             	mov    %rbp,%rdi
    97ac:	e8 4f ab ff ff       	call   4300 <fwp_cancel_tree.part.0>
    97b1:	0f 1f 40 00          	nopl   0x0(%rax)
    97b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    97bc:	00 00 00 00 
    97c0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    97c4:	0f 85 18 fc ff ff    	jne    93e2 <fwp_main_thread+0x182>
    97ca:	48 8b 45 60          	mov    0x60(%rbp),%rax
    97ce:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    97d2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    97d6:	0f 85 18 fc ff ff    	jne    93f4 <fwp_main_thread+0x194>
    97dc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    97e0:	48 85 c9             	test   %rcx,%rcx
    97e3:	0f 84 0b fc ff ff    	je     93f4 <fwp_main_thread+0x194>
    97e9:	48 39 c8             	cmp    %rcx,%rax
    97ec:	48 89 ce             	mov    %rcx,%rsi
    97ef:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    97f6:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    97fa:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9801:	00 00 00 00 
    9805:	48 0f 4e f0          	cmovle %rax,%rsi
    9809:	48 85 c0             	test   %rax,%rax
    980c:	48 89 c8             	mov    %rcx,%rax
    980f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9816:	48 0f 45 c6          	cmovne %rsi,%rax
    981a:	48 85 d2             	test   %rdx,%rdx
    981d:	74 07                	je     9826 <fwp_main_thread+0x5c6>
    981f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9826:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    982a:	e9 f7 fb ff ff       	jmp    9426 <fwp_main_thread+0x1c6>
    982f:	90                   	nop
    9830:	48 89 cb             	mov    %rcx,%rbx
    9833:	e9 8a fb ff ff       	jmp    93c2 <fwp_main_thread+0x162>
    9838:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    983f:	00 
    9840:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9844:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    984b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9852:	00 00 00 00 
    9856:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    985d:	48 85 c0             	test   %rax,%rax
    9860:	0f 84 e9 18 00 00    	je     b14f <fwp_main_thread+0x1eef>
    9866:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    986d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9871:	e9 e4 fb ff ff       	jmp    945a <fwp_main_thread+0x1fa>
    9876:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    987d:	00 00 00 
    9880:	48 89 01             	mov    %rax,(%rcx)
    9883:	e9 0c fc ff ff       	jmp    9494 <fwp_main_thread+0x234>
    9888:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    988f:	00 
    9890:	48 89 05 01 6f 01 00 	mov    %rax,0x16f01(%rip)        # 20798 <fwp_timers>
    9897:	e9 49 fc ff ff       	jmp    94e5 <fwp_main_thread+0x285>
    989c:	0f 1f 40 00          	nopl   0x0(%rax)
    98a0:	48 8d 3d 69 a5 ff ff 	lea    -0x5a97(%rip),%rdi        # 3e10 <descent_phase_report>
    98a7:	e8 f4 1d 00 00       	call   b6a0 <atexit>
    98ac:	85 c0                	test   %eax,%eax
    98ae:	0f 85 b4 1b 00 00    	jne    b468 <fwp_main_thread+0x2208>
    98b4:	c7 05 5a 68 01 00 01 	movl   $0x1,0x1685a(%rip)        # 20118 <descent_registered>
    98bb:	00 00 00 
    98be:	8b 3d c4 67 00 00    	mov    0x67c4(%rip),%edi        # 10088 <st.7>
    98c4:	85 ff                	test   %edi,%edi
    98c6:	0f 85 da fa ff ff    	jne    93a6 <fwp_main_thread+0x146>
    98cc:	48 8d 05 fd df ff ff 	lea    -0x2003(%rip),%rax        # 78d0 <fwp_drop1>
    98d3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    98d7:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    98dc:	45 31 f6             	xor    %r14d,%r14d
    98df:	66 48 0f 6e f0       	movq   %rax,%xmm6
    98e4:	48 8b 05 8d 8b 01 00 	mov    0x18b8d(%rip),%rax        # 22478 <fwp_cleanups>
    98eb:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
    98f2:	00 00 00 00 00 
    98f7:	bb ff 01 00 00       	mov    $0x1ff,%ebx
    98fc:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    9900:	48 8d 2d d9 6e 01 00 	lea    0x16ed9(%rip),%rbp        # 207e0 <fwp_heap>
    9907:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    990e:	00 
    990f:	48 8d 05 ba a2 ff ff 	lea    -0x5d46(%rip),%rax        # 3bd0 <fwp_range_release>
    9916:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    991d:	00 
    991e:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    9923:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    992a:	00 
    992b:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    9932:	00 
    9933:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
    9938:	48 89 05 39 8b 01 00 	mov    %rax,0x18b39(%rip)        # 22478 <fwp_cleanups>
    993f:	eb 47                	jmp    9988 <fwp_main_thread+0x728>
    9941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9948:	80 f9 01             	cmp    $0x1,%cl
    994b:	75 29                	jne    9976 <fwp_main_thread+0x716>
    994d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9950:	0f b7 c0             	movzwl %ax,%eax
    9953:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9956:	48 0f af c1          	imul   %rcx,%rax
    995a:	48 c1 e8 20          	shr    $0x20,%rax
    995e:	48 39 d0             	cmp    %rdx,%rax
    9961:	73 13                	jae    9976 <fwp_main_thread+0x716>
    9963:	49 01 c5             	add    %rax,%r13
    9966:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    996b:	0f 84 66 18 00 00    	je     b1d7 <fwp_main_thread+0x1f77>
    9971:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9976:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    997d:	00 
    997e:	48 83 eb 01          	sub    $0x1,%rbx
    9982:	0f 82 85 00 00 00    	jb     9a0d <fwp_main_thread+0x7ad>
    9988:	4c 89 e6             	mov    %r12,%rsi
    998b:	bf 01 00 00 00       	mov    $0x1,%edi
    9990:	4c 89 b4 24 48 01 00 	mov    %r14,0x148(%rsp)
    9997:	00 
    9998:	48 89 9c 24 d8 00 00 	mov    %rbx,0xd8(%rsp)
    999f:	00 
    99a0:	48 89 9c 24 40 01 00 	mov    %rbx,0x140(%rsp)
    99a7:	00 
    99a8:	e8 63 c4 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    99ad:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    99b4:	49 89 c6             	mov    %rax,%r14
    99b7:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    99be:	48 c1 e2 10          	shl    $0x10,%rdx
    99c2:	48 39 d0             	cmp    %rdx,%rax
    99c5:	73 af                	jae    9976 <fwp_main_thread+0x716>
    99c7:	48 89 c2             	mov    %rax,%rdx
    99ca:	48 c1 ea 10          	shr    $0x10,%rdx
    99ce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    99d2:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    99d9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    99dd:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    99e1:	4d 85 ed             	test   %r13,%r13
    99e4:	74 90                	je     9976 <fwp_main_thread+0x716>
    99e6:	0f b6 0a             	movzbl (%rdx),%ecx
    99e9:	80 f9 02             	cmp    $0x2,%cl
    99ec:	0f 85 56 ff ff ff    	jne    9948 <fwp_main_thread+0x6e8>
    99f2:	66 85 c0             	test   %ax,%ax
    99f5:	0f 84 6b ff ff ff    	je     9966 <fwp_main_thread+0x706>
    99fb:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    9a02:	00 
    9a03:	48 83 eb 01          	sub    $0x1,%rbx
    9a07:	0f 83 7b ff ff ff    	jae    9988 <fwp_main_thread+0x728>
    9a0d:	48 8b 9c 24 b0 00 00 	mov    0xb0(%rsp),%rbx
    9a14:	00 
    9a15:	66 0f 6f 05 33 32 00 	movdqa 0x3233(%rip),%xmm0        # cc50 <msg.8+0xe0>
    9a1c:	00 
    9a1d:	bf 01 00 00 00       	mov    $0x1,%edi
    9a22:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    9a29:	00 
    9a2a:	48 89 1d 47 8a 01 00 	mov    %rbx,0x18a47(%rip)        # 22478 <fwp_cleanups>
    9a31:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
    9a38:	00 
    9a39:	e8 d2 c3 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    9a3e:	48 8b 15 73 81 01 00 	mov    0x18173(%rip),%rdx        # 21bb8 <fwp_heap+0x13d8>
    9a45:	49 89 c5             	mov    %rax,%r13
    9a48:	48 2b 05 41 81 01 00 	sub    0x18141(%rip),%rax        # 21b90 <fwp_heap+0x13b0>
    9a4f:	48 c1 e2 10          	shl    $0x10,%rdx
    9a53:	48 39 d0             	cmp    %rdx,%rax
    9a56:	73 59                	jae    9ab1 <fwp_main_thread+0x851>
    9a58:	48 89 c2             	mov    %rax,%rdx
    9a5b:	48 c1 ea 10          	shr    $0x10,%rdx
    9a5f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9a63:	48 8b 15 6e 81 01 00 	mov    0x1816e(%rip),%rdx        # 21bd8 <fwp_heap+0x13f8>
    9a6a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9a6e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9a72:	4d 85 e4             	test   %r12,%r12
    9a75:	74 3a                	je     9ab1 <fwp_main_thread+0x851>
    9a77:	0f b6 0a             	movzbl (%rdx),%ecx
    9a7a:	80 f9 02             	cmp    $0x2,%cl
    9a7d:	0f 84 38 17 00 00    	je     b1bb <fwp_main_thread+0x1f5b>
    9a83:	80 f9 01             	cmp    $0x1,%cl
    9a86:	75 29                	jne    9ab1 <fwp_main_thread+0x851>
    9a88:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9a8b:	0f b7 c0             	movzwl %ax,%eax
    9a8e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a91:	48 0f af c1          	imul   %rcx,%rax
    9a95:	48 c1 e8 20          	shr    $0x20,%rax
    9a99:	48 39 d0             	cmp    %rdx,%rax
    9a9c:	73 13                	jae    9ab1 <fwp_main_thread+0x851>
    9a9e:	49 01 c4             	add    %rax,%r12
    9aa1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9aa6:	0f 84 24 19 00 00    	je     b3d0 <fwp_main_thread+0x2170>
    9aac:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9ab1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9ab8:	00 f0 3f 
    9abb:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    9ac2:	00 
    9ac3:	bf 01 00 00 00       	mov    $0x1,%edi
    9ac8:	4c 89 ac 24 28 01 00 	mov    %r13,0x128(%rsp)
    9acf:	00 
    9ad0:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
    9ad7:	00 
    9ad8:	e8 33 c3 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    9add:	48 8b 15 d4 80 01 00 	mov    0x180d4(%rip),%rdx        # 21bb8 <fwp_heap+0x13d8>
    9ae4:	49 89 c5             	mov    %rax,%r13
    9ae7:	48 2b 05 a2 80 01 00 	sub    0x180a2(%rip),%rax        # 21b90 <fwp_heap+0x13b0>
    9aee:	48 c1 e2 10          	shl    $0x10,%rdx
    9af2:	48 39 d0             	cmp    %rdx,%rax
    9af5:	73 59                	jae    9b50 <fwp_main_thread+0x8f0>
    9af7:	48 89 c2             	mov    %rax,%rdx
    9afa:	48 c1 ea 10          	shr    $0x10,%rdx
    9afe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9b02:	48 8b 15 cf 80 01 00 	mov    0x180cf(%rip),%rdx        # 21bd8 <fwp_heap+0x13f8>
    9b09:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9b0d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9b11:	4d 85 e4             	test   %r12,%r12
    9b14:	74 3a                	je     9b50 <fwp_main_thread+0x8f0>
    9b16:	0f b6 0a             	movzbl (%rdx),%ecx
    9b19:	80 f9 02             	cmp    $0x2,%cl
    9b1c:	0f 84 8b 16 00 00    	je     b1ad <fwp_main_thread+0x1f4d>
    9b22:	80 f9 01             	cmp    $0x1,%cl
    9b25:	75 29                	jne    9b50 <fwp_main_thread+0x8f0>
    9b27:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9b2a:	0f b7 c0             	movzwl %ax,%eax
    9b2d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9b30:	48 0f af c1          	imul   %rcx,%rax
    9b34:	48 c1 e8 20          	shr    $0x20,%rax
    9b38:	48 39 d0             	cmp    %rdx,%rax
    9b3b:	73 13                	jae    9b50 <fwp_main_thread+0x8f0>
    9b3d:	49 01 c4             	add    %rax,%r12
    9b40:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9b45:	0f 84 92 18 00 00    	je     b3dd <fwp_main_thread+0x217d>
    9b4b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9b50:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9b57:	33 f3 bf 
    9b5a:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    9b61:	00 
    9b62:	bf 01 00 00 00       	mov    $0x1,%edi
    9b67:	4c 89 ac 24 18 01 00 	mov    %r13,0x118(%rsp)
    9b6e:	00 
    9b6f:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
    9b76:	00 
    9b77:	e8 94 c2 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    9b7c:	48 8b 15 35 80 01 00 	mov    0x18035(%rip),%rdx        # 21bb8 <fwp_heap+0x13d8>
    9b83:	48 8b 0d 06 80 01 00 	mov    0x18006(%rip),%rcx        # 21b90 <fwp_heap+0x13b0>
    9b8a:	48 89 04 24          	mov    %rax,(%rsp)
    9b8e:	48 89 d6             	mov    %rdx,%rsi
    9b91:	48 29 c8             	sub    %rcx,%rax
    9b94:	48 c1 e6 10          	shl    $0x10,%rsi
    9b98:	48 39 f0             	cmp    %rsi,%rax
    9b9b:	73 69                	jae    9c06 <fwp_main_thread+0x9a6>
    9b9d:	48 89 c6             	mov    %rax,%rsi
    9ba0:	48 c1 ee 10          	shr    $0x10,%rsi
    9ba4:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9ba8:	48 8b 35 29 80 01 00 	mov    0x18029(%rip),%rsi        # 21bd8 <fwp_heap+0x13f8>
    9baf:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9bb3:	4c 8b 66 20          	mov    0x20(%rsi),%r12
    9bb7:	4d 85 e4             	test   %r12,%r12
    9bba:	74 4a                	je     9c06 <fwp_main_thread+0x9a6>
    9bbc:	0f b6 3e             	movzbl (%rsi),%edi
    9bbf:	40 80 ff 02          	cmp    $0x2,%dil
    9bc3:	0f 84 00 16 00 00    	je     b1c9 <fwp_main_thread+0x1f69>
    9bc9:	40 80 ff 01          	cmp    $0x1,%dil
    9bcd:	75 37                	jne    9c06 <fwp_main_thread+0x9a6>
    9bcf:	8b 7e 18             	mov    0x18(%rsi),%edi
    9bd2:	0f b7 c0             	movzwl %ax,%eax
    9bd5:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9bd8:	48 0f af c7          	imul   %rdi,%rax
    9bdc:	48 c1 e8 20          	shr    $0x20,%rax
    9be0:	48 39 f0             	cmp    %rsi,%rax
    9be3:	73 21                	jae    9c06 <fwp_main_thread+0x9a6>
    9be5:	49 01 c4             	add    %rax,%r12
    9be8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9bed:	0f 84 f7 17 00 00    	je     b3ea <fwp_main_thread+0x218a>
    9bf3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9bf8:	48 8b 0d 91 7f 01 00 	mov    0x17f91(%rip),%rcx        # 21b90 <fwp_heap+0x13b0>
    9bff:	48 8b 15 b2 7f 01 00 	mov    0x17fb2(%rip),%rdx        # 21bb8 <fwp_heap+0x13d8>
    9c06:	48 8d 84 24 8c 00 00 	lea    0x8c(%rsp),%rax
    9c0d:	00 
    9c0e:	4c 89 74 24 70       	mov    %r14,0x70(%rsp)
    9c13:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    9c18:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    9c1f:	00 
    9c20:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    9c25:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
    9c2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9c30:	48 8b 04 24          	mov    (%rsp),%rax
    9c34:	48 c1 e2 10          	shl    $0x10,%rdx
    9c38:	48 29 c8             	sub    %rcx,%rax
    9c3b:	48 39 d0             	cmp    %rdx,%rax
    9c3e:	73 73                	jae    9cb3 <fwp_main_thread+0xa53>
    9c40:	48 89 c6             	mov    %rax,%rsi
    9c43:	48 c1 ee 10          	shr    $0x10,%rsi
    9c47:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9c4b:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    9c52:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9c56:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9c5a:	48 85 ff             	test   %rdi,%rdi
    9c5d:	74 54                	je     9cb3 <fwp_main_thread+0xa53>
    9c5f:	44 0f b6 06          	movzbl (%rsi),%r8d
    9c63:	41 80 f8 02          	cmp    $0x2,%r8b
    9c67:	0f 84 6b 14 00 00    	je     b0d8 <fwp_main_thread+0x1e78>
    9c6d:	41 80 f8 01          	cmp    $0x1,%r8b
    9c71:	75 40                	jne    9cb3 <fwp_main_thread+0xa53>
    9c73:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    9c77:	0f b7 c0             	movzwl %ax,%eax
    9c7a:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9c7d:	49 0f af c0          	imul   %r8,%rax
    9c81:	48 c1 e8 20          	shr    $0x20,%rax
    9c85:	48 39 f0             	cmp    %rsi,%rax
    9c88:	73 29                	jae    9cb3 <fwp_main_thread+0xa53>
    9c8a:	48 01 c7             	add    %rax,%rdi
    9c8d:	0f b6 07             	movzbl (%rdi),%eax
    9c90:	84 c0                	test   %al,%al
    9c92:	74 1f                	je     9cb3 <fwp_main_thread+0xa53>
    9c94:	3c fd                	cmp    $0xfd,%al
    9c96:	0f 87 e2 16 00 00    	ja     b37e <fwp_main_thread+0x211e>
    9c9c:	83 c0 01             	add    $0x1,%eax
    9c9f:	88 07                	mov    %al,(%rdi)
    9ca1:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9ca8:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    9caf:	48 c1 e2 10          	shl    $0x10,%rdx
    9cb3:	48 8d 05 e6 ce ff ff 	lea    -0x311a(%rip),%rax        # 6ba0 <fwp_tape_scope_release>
    9cba:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
    9cc1:	00 
    9cc2:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    9cc9:	00 
    9cca:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    9ccf:	c7 84 24 8c 00 00 00 	movl   $0xffffffff,0x8c(%rsp)
    9cd6:	ff ff ff ff 
    9cda:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    9ce1:	00 
    9ce2:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    9ce7:	48 89 05 8a 87 01 00 	mov    %rax,0x1878a(%rip)        # 22478 <fwp_cleanups>
    9cee:	48 8d 05 1b 63 00 00 	lea    0x631b(%rip),%rax        # 10010 <fc37>
    9cf5:	48 29 c8             	sub    %rcx,%rax
    9cf8:	48 39 d0             	cmp    %rdx,%rax
    9cfb:	73 5d                	jae    9d5a <fwp_main_thread+0xafa>
    9cfd:	48 89 c2             	mov    %rax,%rdx
    9d00:	48 c1 ea 10          	shr    $0x10,%rdx
    9d04:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9d08:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9d0f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9d13:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9d17:	48 85 ff             	test   %rdi,%rdi
    9d1a:	74 3e                	je     9d5a <fwp_main_thread+0xafa>
    9d1c:	0f b6 0a             	movzbl (%rdx),%ecx
    9d1f:	80 f9 02             	cmp    $0x2,%cl
    9d22:	0f 84 28 12 00 00    	je     af50 <fwp_main_thread+0x1cf0>
    9d28:	80 f9 01             	cmp    $0x1,%cl
    9d2b:	75 2d                	jne    9d5a <fwp_main_thread+0xafa>
    9d2d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9d30:	0f b7 c0             	movzwl %ax,%eax
    9d33:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9d36:	48 0f af c1          	imul   %rcx,%rax
    9d3a:	48 c1 e8 20          	shr    $0x20,%rax
    9d3e:	48 39 d0             	cmp    %rdx,%rax
    9d41:	73 17                	jae    9d5a <fwp_main_thread+0xafa>
    9d43:	48 01 c7             	add    %rax,%rdi
    9d46:	0f b6 07             	movzbl (%rdi),%eax
    9d49:	84 c0                	test   %al,%al
    9d4b:	74 0d                	je     9d5a <fwp_main_thread+0xafa>
    9d4d:	3c fd                	cmp    $0xfd,%al
    9d4f:	0f 87 12 15 00 00    	ja     b267 <fwp_main_thread+0x2007>
    9d55:	83 c0 01             	add    $0x1,%eax
    9d58:	88 07                	mov    %al,(%rdi)
    9d5a:	48 8d 3d af 62 00 00 	lea    0x62af(%rip),%rdi        # 10010 <fc37>
    9d61:	45 31 ed             	xor    %r13d,%r13d
    9d64:	e8 07 cb ff ff       	call   6870 <fwp_closure_drop>
    9d69:	4c 8b 24 24          	mov    (%rsp),%r12
    9d6d:	0f 1f 00             	nopl   (%rax)
    9d70:	4d 8b 64 24 10       	mov    0x10(%r12),%r12
    9d75:	49 83 c5 01          	add    $0x1,%r13
    9d79:	4d 85 e4             	test   %r12,%r12
    9d7c:	75 f2                	jne    9d70 <fwp_main_thread+0xb10>
    9d7e:	31 ff                	xor    %edi,%edi
    9d80:	e8 cb a4 ff ff       	call   4250 <descent_phase_step>
    9d85:	49 81 fd ff ff ff 7f 	cmp    $0x7fffffff,%r13
    9d8c:	0f 87 82 16 00 00    	ja     b414 <fwp_main_thread+0x21b4>
    9d92:	8b 35 e4 62 00 00    	mov    0x62e4(%rip),%esi        # 1007c <registered_finish.5>
    9d98:	85 f6                	test   %esi,%esi
    9d9a:	0f 84 80 11 00 00    	je     af20 <fwp_main_thread+0x1cc0>
    9da0:	48 8b 15 51 63 01 00 	mov    0x16351(%rip),%rdx        # 200f8 <fwp_tape_next_slot>
    9da7:	4c 8b 35 5a 63 01 00 	mov    0x1635a(%rip),%r14        # 20108 <fwp_ntapes>
    9dae:	4c 39 f2             	cmp    %r14,%rdx
    9db1:	0f 8d e9 0f 00 00    	jge    ada0 <fwp_main_thread+0x1b40>
    9db7:	48 6b c2 68          	imul   $0x68,%rdx,%rax
    9dbb:	48 03 05 4e 63 01 00 	add    0x1634e(%rip),%rax        # 20110 <fwp_tapes>
    9dc2:	0f 1f 00             	nopl   (%rax)
    9dc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9dcc:	00 00 00 00 
    9dd0:	8b 48 04             	mov    0x4(%rax),%ecx
    9dd3:	85 c9                	test   %ecx,%ecx
    9dd5:	75 0c                	jne    9de3 <fwp_main_thread+0xb83>
    9dd7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    9ddd:	0f 86 bd 0f 00 00    	jbe    ada0 <fwp_main_thread+0x1b40>
    9de3:	48 83 c2 01          	add    $0x1,%rdx
    9de7:	48 83 c0 68          	add    $0x68,%rax
    9deb:	4c 39 f2             	cmp    %r14,%rdx
    9dee:	75 e0                	jne    9dd0 <fwp_main_thread+0xb70>
    9df0:	49 81 fe fe ff 00 00 	cmp    $0xfffe,%r14
    9df7:	0f 8f 2f 16 00 00    	jg     b42c <fwp_main_thread+0x21cc>
    9dfd:	4c 39 35 fc 62 01 00 	cmp    %r14,0x162fc(%rip)        # 20100 <fwp_tapes_cap>
    9e04:	4c 8b 3d 05 63 01 00 	mov    0x16305(%rip),%r15        # 20110 <fwp_tapes>
    9e0b:	75 3f                	jne    9e4c <fwp_main_thread+0xbec>
    9e0d:	4d 85 f6             	test   %r14,%r14
    9e10:	0f 84 2a 13 00 00    	je     b140 <fwp_main_thread+0x1ee0>
    9e16:	4b 8d 1c 36          	lea    (%r14,%r14,1),%rbx
    9e1a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    9e1f:	48 39 c3             	cmp    %rax,%rbx
    9e22:	48 0f 4f d8          	cmovg  %rax,%rbx
    9e26:	48 6b f3 68          	imul   $0x68,%rbx,%rsi
    9e2a:	4c 89 ff             	mov    %r15,%rdi
    9e2d:	e8 9e 97 ff ff       	call   35d0 <realloc@plt>
    9e32:	49 89 c7             	mov    %rax,%r15
    9e35:	48 85 c0             	test   %rax,%rax
    9e38:	0f 84 55 11 00 00    	je     af93 <fwp_main_thread+0x1d33>
    9e3e:	48 89 05 cb 62 01 00 	mov    %rax,0x162cb(%rip)        # 20110 <fwp_tapes>
    9e45:	48 89 1d b4 62 01 00 	mov    %rbx,0x162b4(%rip)        # 20100 <fwp_tapes_cap>
    9e4c:	49 6b c6 68          	imul   $0x68,%r14,%rax
    9e50:	49 8d 5e 01          	lea    0x1(%r14),%rbx
    9e54:	4c 01 f8             	add    %r15,%rax
    9e57:	48 8d 78 08          	lea    0x8(%rax),%rdi
    9e5b:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9e62:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    9e66:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    9e6d:	00 
    9e6e:	48 29 f8             	sub    %rdi,%rax
    9e71:	8d 48 68             	lea    0x68(%rax),%ecx
    9e74:	31 c0                	xor    %eax,%eax
    9e76:	c1 e9 03             	shr    $0x3,%ecx
    9e79:	f3 48 ab             	rep stos %rax,(%rdi)
    9e7c:	48 89 1d 85 62 01 00 	mov    %rbx,0x16285(%rip)        # 20108 <fwp_ntapes>
    9e83:	49 6b d6 68          	imul   $0x68,%r14,%rdx
    9e87:	66 49 0f 6e c5       	movq   %r13,%xmm0
    9e8c:	48 8d 3d 8f 22 00 00 	lea    0x228f(%rip),%rdi        # c122 <_IO_stdin_used+0x122>
    9e93:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    9e97:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    9e9c:	4c 01 fa             	add    %r15,%rdx
    9e9f:	48 c7 42 60 00 00 00 	movq   $0x0,0x60(%rdx)
    9ea6:	00 
    9ea7:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    9eac:	e8 ef 94 ff ff       	call   33a0 <getenv@plt>
    9eb1:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9eb6:	66 0f 6f 44 24 20    	movdqa 0x20(%rsp),%xmm0
    9ebc:	48 85 c0             	test   %rax,%rax
    9ebf:	0f 84 53 0d 00 00    	je     ac18 <fwp_main_thread+0x19b8>
    9ec5:	80 38 30             	cmpb   $0x30,(%rax)
    9ec8:	0f 85 4a 0d 00 00    	jne    ac18 <fwp_main_thread+0x19b8>
    9ece:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9ed2:	0f 85 40 0d 00 00    	jne    ac18 <fwp_main_thread+0x19b8>
    9ed8:	8b 02                	mov    (%rdx),%eax
    9eda:	c7 42 04 01 00 00 00 	movl   $0x1,0x4(%rdx)
    9ee1:	48 89 1d 10 62 01 00 	mov    %rbx,0x16210(%rip)        # 200f8 <fwp_tape_next_slot>
    9ee8:	44 8d 68 01          	lea    0x1(%rax),%r13d
    9eec:	48 8b 05 9d 2c 00 00 	mov    0x2c9d(%rip),%rax        # cb90 <msg.8+0x20>
    9ef3:	48 c7 42 50 00 00 00 	movq   $0x0,0x50(%rdx)
    9efa:	00 
    9efb:	44 89 2a             	mov    %r13d,(%rdx)
    9efe:	48 89 42 58          	mov    %rax,0x58(%rdx)
    9f02:	48 8b 05 6f 85 01 00 	mov    0x1856f(%rip),%rax        # 22478 <fwp_cleanups>
    9f09:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    9f0d:	48 85 c0             	test   %rax,%rax
    9f10:	75 1a                	jne    9f2c <fwp_main_thread+0xccc>
    9f12:	e9 39 15 00 00       	jmp    b450 <fwp_main_thread+0x21f0>
    9f17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9f1e:	00 00 
    9f20:	48 8b 00             	mov    (%rax),%rax
    9f23:	48 85 c0             	test   %rax,%rax
    9f26:	0f 84 24 15 00 00    	je     b450 <fwp_main_thread+0x21f0>
    9f2c:	48 8d 3d 6d cc ff ff 	lea    -0x3393(%rip),%rdi        # 6ba0 <fwp_tape_scope_release>
    9f33:	48 39 78 08          	cmp    %rdi,0x8(%rax)
    9f37:	75 e7                	jne    9f20 <fwp_main_thread+0xcc0>
    9f39:	48 8b 70 10          	mov    0x10(%rax),%rsi
    9f3d:	44 89 f1             	mov    %r14d,%ecx
    9f40:	48 63 06             	movslq (%rsi),%rax
    9f43:	48 89 72 50          	mov    %rsi,0x50(%rdx)
    9f47:	89 42 5c             	mov    %eax,0x5c(%rdx)
    9f4a:	85 c0                	test   %eax,%eax
    9f4c:	78 09                	js     9f57 <fwp_main_thread+0xcf7>
    9f4e:	48 6b c0 68          	imul   $0x68,%rax,%rax
    9f52:	45 89 74 07 58       	mov    %r14d,0x58(%r15,%rax,1)
    9f57:	89 0e                	mov    %ecx,(%rsi)
    9f59:	bf 01 00 00 00       	mov    $0x1,%edi
    9f5e:	e8 ed a2 ff ff       	call   4250 <descent_phase_step>
    9f63:	48 8b 04 24          	mov    (%rsp),%rax
    9f67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9f6e:	00 00 
    9f70:	48 8b 40 10          	mov    0x10(%rax),%rax
    9f74:	49 83 c4 01          	add    $0x1,%r12
    9f78:	48 85 c0             	test   %rax,%rax
    9f7b:	75 f3                	jne    9f70 <fwp_main_thread+0xd10>
    9f7d:	4c 8b 3c 24          	mov    (%rsp),%r15
    9f81:	0f 1f 40 00          	nopl   0x0(%rax)
    9f85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f8c:	00 00 00 00 
    9f90:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    9f94:	48 83 c0 01          	add    $0x1,%rax
    9f98:	4d 85 ff             	test   %r15,%r15
    9f9b:	75 f3                	jne    9f90 <fwp_main_thread+0xd30>
    9f9d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    9fa4:	ff ff 1f 
    9fa7:	48 39 c2             	cmp    %rax,%rdx
    9faa:	0f 82 70 14 00 00    	jb     b420 <fwp_main_thread+0x21c0>
    9fb0:	4d 85 e4             	test   %r12,%r12
    9fb3:	0f 8e 07 0e 00 00    	jle    adc0 <fwp_main_thread+0x1b60>
    9fb9:	49 39 c4             	cmp    %rax,%r12
    9fbc:	4c 0f 47 e0          	cmova  %rax,%r12
    9fc0:	4c 89 e0             	mov    %r12,%rax
    9fc3:	48 c1 e8 3c          	shr    $0x3c,%rax
    9fc7:	0f 85 53 14 00 00    	jne    b420 <fwp_main_thread+0x21c0>
    9fcd:	4b 8d 14 24          	lea    (%r12,%r12,1),%rdx
    9fd1:	be 02 00 00 00       	mov    $0x2,%esi
    9fd6:	49 c1 e5 10          	shl    $0x10,%r13
    9fda:	48 8d 3c d5 08 00 00 	lea    0x8(,%rdx,8),%rdi
    9fe1:	00 
    9fe2:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    9fe7:	4c 09 eb             	or     %r13,%rbx
    9fea:	e8 01 bd ff ff       	call   5cf0 <fwp_heap_alloc>
    9fef:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9ff4:	49 89 c6             	mov    %rax,%r14
    9ff7:	48 89 10             	mov    %rdx,(%rax)
    9ffa:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a001:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a008:	48 c1 e2 10          	shl    $0x10,%rdx
    a00c:	48 39 d0             	cmp    %rdx,%rax
    a00f:	0f 83 6b 0d 00 00    	jae    ad80 <fwp_main_thread+0x1b20>
    a015:	48 89 c2             	mov    %rax,%rdx
    a018:	48 c1 ea 10          	shr    $0x10,%rdx
    a01c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a020:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a027:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a02b:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a02f:	4d 85 ed             	test   %r13,%r13
    a032:	74 3a                	je     a06e <fwp_main_thread+0xe0e>
    a034:	0f b6 0a             	movzbl (%rdx),%ecx
    a037:	80 f9 02             	cmp    $0x2,%cl
    a03a:	0f 84 e9 0d 00 00    	je     ae29 <fwp_main_thread+0x1bc9>
    a040:	80 f9 01             	cmp    $0x1,%cl
    a043:	75 29                	jne    a06e <fwp_main_thread+0xe0e>
    a045:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a048:	0f b7 c0             	movzwl %ax,%eax
    a04b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a04e:	48 0f af c1          	imul   %rcx,%rax
    a052:	48 c1 e8 20          	shr    $0x20,%rax
    a056:	48 39 d0             	cmp    %rdx,%rax
    a059:	73 13                	jae    a06e <fwp_main_thread+0xe0e>
    a05b:	49 01 c5             	add    %rax,%r13
    a05e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a063:	0f 84 d4 0d 00 00    	je     ae3d <fwp_main_thread+0x1bdd>
    a069:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a06e:	4d 85 e4             	test   %r12,%r12
    a071:	74 41                	je     a0b4 <fwp_main_thread+0xe54>
    a073:	48 89 d9             	mov    %rbx,%rcx
    a076:	48 8b 14 24          	mov    (%rsp),%rdx
    a07a:	31 c0                	xor    %eax,%eax
    a07c:	48 c1 e1 20          	shl    $0x20,%rcx
    a080:	48 89 c6             	mov    %rax,%rsi
    a083:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    a088:	48 01 ce             	add    %rcx,%rsi
    a08b:	0f 80 72 13 00 00    	jo     b403 <fwp_main_thread+0x21a3>
    a091:	66 48 0f 6e de       	movq   %rsi,%xmm3
    a096:	48 89 c6             	mov    %rax,%rsi
    a099:	48 83 c0 01          	add    $0x1,%rax
    a09d:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    a0a1:	48 c1 e6 04          	shl    $0x4,%rsi
    a0a5:	41 0f 11 44 36 08    	movups %xmm0,0x8(%r14,%rsi,1)
    a0ab:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a0af:	4c 39 e0             	cmp    %r12,%rax
    a0b2:	72 cc                	jb     a080 <fwp_main_thread+0xe20>
    a0b4:	49 8b 06             	mov    (%r14),%rax
    a0b7:	48 d1 e8             	shr    $1,%rax
    a0ba:	0f 84 d0 0c 00 00    	je     ad90 <fwp_main_thread+0x1b30>
    a0c0:	48 8d 48 ff          	lea    -0x1(%rax),%rcx
    a0c4:	48 89 cf             	mov    %rcx,%rdi
    a0c7:	48 c1 ef 3c          	shr    $0x3c,%rdi
    a0cb:	0f 85 4f 13 00 00    	jne    b420 <fwp_main_thread+0x21c0>
    a0d1:	48 8d 14 09          	lea    (%rcx,%rcx,1),%rdx
    a0d5:	48 85 c9             	test   %rcx,%rcx
    a0d8:	74 49                	je     a123 <fwp_main_thread+0xec3>
    a0da:	48 c1 e0 04          	shl    $0x4,%rax
    a0de:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    a0e3:	49 89 d5             	mov    %rdx,%r13
    a0e6:	49 8d 5e 08          	lea    0x8(%r14),%rbx
    a0ea:	4d 8d 64 06 f8       	lea    -0x8(%r14,%rax,1),%r12
    a0ef:	90                   	nop
    a0f0:	f2 0f 10 03          	movsd  (%rbx),%xmm0
    a0f4:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    a0f8:	48 83 c3 10          	add    $0x10,%rbx
    a0fc:	48 8b 7b f8          	mov    -0x8(%rbx),%rdi
    a100:	f2 0f 10 0b          	movsd  (%rbx),%xmm1
    a104:	e8 b7 c1 ff ff       	call   62c0 <w120>
    a109:	66 48 0f 6e e0       	movq   %rax,%xmm4
    a10e:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    a112:	0f 11 43 f0          	movups %xmm0,-0x10(%rbx)
    a116:	49 39 dc             	cmp    %rbx,%r12
    a119:	75 d5                	jne    a0f0 <fwp_main_thread+0xe90>
    a11b:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    a120:	4c 89 ea             	mov    %r13,%rdx
    a123:	49 89 16             	mov    %rdx,(%r14)
    a126:	4c 89 f7             	mov    %r14,%rdi
    a129:	4c 63 eb             	movslq %ebx,%r13
    a12c:	e8 0f c3 ff ff       	call   6440 <w176.constprop.0>
    a131:	4c 89 f7             	mov    %r14,%rdi
    a134:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    a139:	e8 92 d9 ff ff       	call   7ad0 <fwp_drop10>
    a13e:	bf 02 00 00 00       	mov    $0x2,%edi
    a143:	e8 18 ae ff ff       	call   4f60 <caf75>
    a148:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    a14d:	e8 fe a0 ff ff       	call   4250 <descent_phase_step>
    a152:	4c 89 ef             	mov    %r13,%rdi
    a155:	e8 76 a5 ff ff       	call   46d0 <fwp_tape_of>
    a15a:	48 89 c6             	mov    %rax,%rsi
    a15d:	48 8b 40 60          	mov    0x60(%rax),%rax
    a161:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    a166:	48 85 c0             	test   %rax,%rax
    a169:	0f 85 ed 12 00 00    	jne    b45c <fwp_main_thread+0x21fc>
    a16f:	48 89 f7             	mov    %rsi,%rdi
    a172:	e8 89 9a ff ff       	call   3c00 <fwp_tape_unlink_scope>
    a177:	f3 0f 6f 76 20       	movdqu 0x20(%rsi),%xmm6
    a17c:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    a180:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    a187:	f3 0f 6f 7e 30       	movdqu 0x30(%rsi),%xmm7
    a18c:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    a191:	0f 29 74 24 30       	movaps %xmm6,0x30(%rsp)
    a196:	66 49 0f 6e f6       	movq   %r14,%xmm6
    a19b:	4c 8b 66 08          	mov    0x8(%rsi),%r12
    a19f:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    a1a3:	48 8b 4e 40          	mov    0x40(%rsi),%rcx
    a1a7:	0f 29 7c 24 10       	movaps %xmm7,0x10(%rsp)
    a1ac:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    a1b0:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    a1b6:	77 18                	ja     a1d0 <fwp_main_thread+0xf70>
    a1b8:	0f b7 c3             	movzwl %bx,%eax
    a1bb:	83 e8 01             	sub    $0x1,%eax
    a1be:	48 98                	cltq
    a1c0:	48 3b 05 31 5f 01 00 	cmp    0x15f31(%rip),%rax        # 200f8 <fwp_tape_next_slot>
    a1c7:	7d 07                	jge    a1d0 <fwp_main_thread+0xf70>
    a1c9:	48 89 05 28 5f 01 00 	mov    %rax,0x15f28(%rip)        # 200f8 <fwp_tape_next_slot>
    a1d0:	48 8b 05 a1 82 01 00 	mov    0x182a1(%rip),%rax        # 22478 <fwp_cleanups>
    a1d7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a1db:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    a1e2:	00 
    a1e3:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    a1e7:	66 0f 6f 7c 24 30    	movdqa 0x30(%rsp),%xmm7
    a1ed:	66 0f 6f 74 24 10    	movdqa 0x10(%rsp),%xmm6
    a1f3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    a1fa:	00 
    a1fb:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
    a200:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    a207:	00 
    a208:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    a20c:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    a210:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    a217:	00 
    a218:	48 8d 05 b1 ae ff ff 	lea    -0x514f(%rip),%rax        # 50d0 <fwp_tape_buffers_release>
    a21f:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    a226:	00 
    a227:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    a22c:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
    a233:	00 
    a234:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    a23b:	00 
    a23c:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
    a241:	0f 29 bc 24 d0 00 00 	movaps %xmm7,0xd0(%rsp)
    a248:	00 
    a249:	48 89 05 28 82 01 00 	mov    %rax,0x18228(%rip)        # 22478 <fwp_cleanups>
    a250:	0f 29 b4 24 e0 00 00 	movaps %xmm6,0xe0(%rsp)
    a257:	00 
    a258:	0f 11 84 24 f8 00 00 	movups %xmm0,0xf8(%rsp)
    a25f:	00 
    a260:	48 85 ff             	test   %rdi,%rdi
    a263:	0f 88 f7 0c 00 00    	js     af60 <fwp_main_thread+0x1d00>
    a269:	48 89 f8             	mov    %rdi,%rax
    a26c:	48 c1 f8 20          	sar    $0x20,%rax
    a270:	49 39 c5             	cmp    %rax,%r13
    a273:	0f 85 2d 11 00 00    	jne    b3a6 <fwp_main_thread+0x2146>
    a279:	41 89 f9             	mov    %edi,%r9d
    a27c:	4d 89 cd             	mov    %r9,%r13
    a27f:	4c 39 ca             	cmp    %r9,%rdx
    a282:	0f 8e 12 11 00 00    	jle    b39a <fwp_main_thread+0x213a>
    a288:	4d 39 cc             	cmp    %r9,%r12
    a28b:	0f 8e bf 0b 00 00    	jle    ae50 <fwp_main_thread+0x1bf0>
    a291:	4d 39 f4             	cmp    %r14,%r12
    a294:	0f 8f f6 0b 00 00    	jg     ae90 <fwp_main_thread+0x1c30>
    a29a:	48 85 c9             	test   %rcx,%rcx
    a29d:	0f 84 d7 0c 00 00    	je     af7a <fwp_main_thread+0x1d1a>
    a2a3:	48 89 cf             	mov    %rcx,%rdi
    a2a6:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    a2ad:	00 
    a2ae:	31 f6                	xor    %esi,%esi
    a2b0:	45 31 f6             	xor    %r14d,%r14d
    a2b3:	4c 89 4c 24 48       	mov    %r9,0x48(%rsp)
    a2b8:	4d 8d 6c 24 ff       	lea    -0x1(%r12),%r13
    a2bd:	e8 fe 91 ff ff       	call   34c0 <memset@plt>
    a2c2:	4c 8b 4c 24 48       	mov    0x48(%rsp),%r9
    a2c7:	48 89 c1             	mov    %rax,%rcx
    a2ca:	f2 0f 10 44 24 60    	movsd  0x60(%rsp),%xmm0
    a2d0:	f2 42 0f 58 04 c9    	addsd  (%rcx,%r9,8),%xmm0
    a2d6:	f2 42 0f 11 04 c9    	movsd  %xmm0,(%rcx,%r9,8)
    a2dc:	bf 03 00 00 00       	mov    $0x3,%edi
    a2e1:	4c 01 25 38 5e 01 00 	add    %r12,0x15e38(%rip)        # 20120 <descent_inputs>
    a2e8:	4c 01 35 39 5e 01 00 	add    %r14,0x15e39(%rip)        # 20128 <descent_nodes>
    a2ef:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
    a2f4:	e8 57 9f ff ff       	call   4250 <descent_phase_step>
    a2f9:	4d 39 ec             	cmp    %r13,%r12
    a2fc:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
    a301:	0f 8f 8b 00 00 00    	jg     a392 <fwp_main_thread+0x1132>
    a307:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
    a30c:	4d 29 e5             	sub    %r12,%r13
    a30f:	4e 8d 1c e1          	lea    (%rcx,%r12,8),%r11
    a313:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a317:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    a31c:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
    a321:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    a326:	4b 8d 14 ea          	lea    (%r10,%r13,8),%rdx
    a32a:	4d 29 d3             	sub    %r10,%r11
    a32d:	4a 8d 04 af          	lea    (%rdi,%r13,4),%rax
    a331:	48 29 fe             	sub    %rdi,%rsi
    a334:	4d 29 d1             	sub    %r10,%r9
    a337:	eb 0b                	jmp    a344 <fwp_main_thread+0x10e4>
    a339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a340:	48 83 e8 04          	sub    $0x4,%rax
    a344:	f2 41 0f 10 04 13    	movsd  (%r11,%rdx,1),%xmm0
    a34a:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    a34e:	7a 02                	jp     a352 <fwp_main_thread+0x10f2>
    a350:	74 37                	je     a389 <fwp_main_thread+0x1129>
    a352:	4c 63 04 06          	movslq (%rsi,%rax,1),%r8
    a356:	45 85 c0             	test   %r8d,%r8d
    a359:	78 16                	js     a371 <fwp_main_thread+0x1111>
    a35b:	f2 41 0f 10 0c 11    	movsd  (%r9,%rdx,1),%xmm1
    a361:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    a365:	f2 42 0f 58 0c c1    	addsd  (%rcx,%r8,8),%xmm1
    a36b:	f2 42 0f 11 0c c1    	movsd  %xmm1,(%rcx,%r8,8)
    a371:	4c 63 00             	movslq (%rax),%r8
    a374:	45 85 c0             	test   %r8d,%r8d
    a377:	78 10                	js     a389 <fwp_main_thread+0x1129>
    a379:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    a37d:	f2 42 0f 58 04 c1    	addsd  (%rcx,%r8,8),%xmm0
    a383:	f2 42 0f 11 04 c1    	movsd  %xmm0,(%rcx,%r8,8)
    a389:	48 83 ea 08          	sub    $0x8,%rdx
    a38d:	48 39 f8             	cmp    %rdi,%rax
    a390:	75 ae                	jne    a340 <fwp_main_thread+0x10e0>
    a392:	bf 04 00 00 00       	mov    $0x4,%edi
    a397:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a39c:	e8 af 9e ff ff       	call   4250 <descent_phase_step>
    a3a1:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a3a8:	ff ff 1f 
    a3ab:	4c 39 e0             	cmp    %r12,%rax
    a3ae:	0f 82 54 10 00 00    	jb     b408 <fwp_main_thread+0x21a8>
    a3b4:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    a3bb:	00 
    a3bc:	be 02 00 00 00       	mov    $0x2,%esi
    a3c1:	e8 2a b9 ff ff       	call   5cf0 <fwp_heap_alloc>
    a3c6:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    a3cb:	4c 89 20             	mov    %r12,(%rax)
    a3ce:	48 89 c3             	mov    %rax,%rbx
    a3d1:	31 c0                	xor    %eax,%eax
    a3d3:	4d 85 e4             	test   %r12,%r12
    a3d6:	74 1a                	je     a3f2 <fwp_main_thread+0x1192>
    a3d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a3df:	00 
    a3e0:	48 8b 14 c1          	mov    (%rcx,%rax,8),%rdx
    a3e4:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    a3e9:	48 83 c0 01          	add    $0x1,%rax
    a3ed:	49 39 c4             	cmp    %rax,%r12
    a3f0:	75 ee                	jne    a3e0 <fwp_main_thread+0x1180>
    a3f2:	bf 05 00 00 00       	mov    $0x5,%edi
    a3f7:	e8 54 9e ff ff       	call   4250 <descent_phase_step>
    a3fc:	4c 8b a4 24 b0 00 00 	mov    0xb0(%rsp),%r12
    a403:	00 
    a404:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    a409:	4c 89 25 68 80 01 00 	mov    %r12,0x18068(%rip)        # 22478 <fwp_cleanups>
    a410:	e8 bb ac ff ff       	call   50d0 <fwp_tape_buffers_release>
    a415:	bf 06 00 00 00       	mov    $0x6,%edi
    a41a:	e8 31 9e ff ff       	call   4250 <descent_phase_step>
    a41f:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a426:	48 89 d8             	mov    %rbx,%rax
    a429:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a430:	48 c1 e2 10          	shl    $0x10,%rdx
    a434:	48 39 d0             	cmp    %rdx,%rax
    a437:	73 59                	jae    a492 <fwp_main_thread+0x1232>
    a439:	48 89 c2             	mov    %rax,%rdx
    a43c:	48 c1 ea 10          	shr    $0x10,%rdx
    a440:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a444:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a44b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a44f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a453:	4d 85 ed             	test   %r13,%r13
    a456:	74 3a                	je     a492 <fwp_main_thread+0x1232>
    a458:	0f b6 0a             	movzbl (%rdx),%ecx
    a45b:	80 f9 02             	cmp    $0x2,%cl
    a45e:	0f 84 64 0b 00 00    	je     afc8 <fwp_main_thread+0x1d68>
    a464:	80 f9 01             	cmp    $0x1,%cl
    a467:	75 29                	jne    a492 <fwp_main_thread+0x1232>
    a469:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a46c:	0f b7 c0             	movzwl %ax,%eax
    a46f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a472:	48 0f af c1          	imul   %rcx,%rax
    a476:	48 c1 e8 20          	shr    $0x20,%rax
    a47a:	48 39 d0             	cmp    %rdx,%rax
    a47d:	73 13                	jae    a492 <fwp_main_thread+0x1232>
    a47f:	49 01 c5             	add    %rax,%r13
    a482:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a487:	0f 84 4f 0b 00 00    	je     afdc <fwp_main_thread+0x1d7c>
    a48d:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a492:	4c 3b 64 24 58       	cmp    0x58(%rsp),%r12
    a497:	0f 85 ae 92 ff ff    	jne    374b <fwp_main_thread.cold>
    a49d:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
    a4a4:	00 
    a4a5:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
    a4aa:	48 89 05 c7 7f 01 00 	mov    %rax,0x17fc7(%rip)        # 22478 <fwp_cleanups>
    a4b1:	e8 ea c6 ff ff       	call   6ba0 <fwp_tape_scope_release>
    a4b6:	48 8b 03             	mov    (%rbx),%rax
    a4b9:	49 89 c5             	mov    %rax,%r13
    a4bc:	49 0f ba f5 3f       	btr    $0x3f,%r13
    a4c1:	48 85 c0             	test   %rax,%rax
    a4c4:	0f 88 e6 07 00 00    	js     acb0 <fwp_main_thread+0x1a50>
    a4ca:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a4d1:	48 89 d8             	mov    %rbx,%rax
    a4d4:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a4db:	48 c1 e2 10          	shl    $0x10,%rdx
    a4df:	48 39 d0             	cmp    %rdx,%rax
    a4e2:	0f 83 c8 07 00 00    	jae    acb0 <fwp_main_thread+0x1a50>
    a4e8:	48 89 c2             	mov    %rax,%rdx
    a4eb:	48 c1 ea 10          	shr    $0x10,%rdx
    a4ef:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a4f3:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a4fa:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a4fe:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    a502:	48 85 c9             	test   %rcx,%rcx
    a505:	0f 84 a5 07 00 00    	je     acb0 <fwp_main_thread+0x1a50>
    a50b:	0f b6 32             	movzbl (%rdx),%esi
    a50e:	40 80 fe 02          	cmp    $0x2,%sil
    a512:	0f 84 80 07 00 00    	je     ac98 <fwp_main_thread+0x1a38>
    a518:	40 80 fe 01          	cmp    $0x1,%sil
    a51c:	0f 85 8e 07 00 00    	jne    acb0 <fwp_main_thread+0x1a50>
    a522:	8b 72 18             	mov    0x18(%rdx),%esi
    a525:	0f b7 c0             	movzwl %ax,%eax
    a528:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a52b:	48 0f af c6          	imul   %rsi,%rax
    a52f:	48 c1 e8 20          	shr    $0x20,%rax
    a533:	48 39 d0             	cmp    %rdx,%rax
    a536:	0f 83 74 07 00 00    	jae    acb0 <fwp_main_thread+0x1a50>
    a53c:	48 01 c1             	add    %rax,%rcx
    a53f:	80 39 01             	cmpb   $0x1,(%rcx)
    a542:	0f 85 68 07 00 00    	jne    acb0 <fwp_main_thread+0x1a50>
    a548:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    a54d:	48 89 da             	mov    %rbx,%rdx
    a550:	31 ff                	xor    %edi,%edi
    a552:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a557:	48 8d 48 08          	lea    0x8(%rax),%rcx
    a55b:	31 c0                	xor    %eax,%eax
    a55d:	4d 85 ed             	test   %r13,%r13
    a560:	75 2f                	jne    a591 <fwp_main_thread+0x1331>
    a562:	eb 5c                	jmp    a5c0 <fwp_main_thread+0x1360>
    a564:	0f 1f 40 00          	nopl   0x0(%rax)
    a568:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    a56c:	0f 88 85 0e 00 00    	js     b3f7 <fwp_main_thread+0x2197>
    a572:	f2 0f 10 05 36 26 00 	movsd  0x2636(%rip),%xmm0        # cbb0 <msg.8+0x40>
    a579:	00 
    a57a:	f2 0f 59 04 c6       	mulsd  (%rsi,%rax,8),%xmm0
    a57f:	48 83 c0 01          	add    $0x1,%rax
    a583:	48 83 c1 08          	add    $0x8,%rcx
    a587:	f2 0f 11 41 f8       	movsd  %xmm0,-0x8(%rcx)
    a58c:	49 39 c5             	cmp    %rax,%r13
    a58f:	74 2f                	je     a5c0 <fwp_main_thread+0x1360>
    a591:	48 8d 73 08          	lea    0x8(%rbx),%rsi
    a595:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    a599:	79 cd                	jns    a568 <fwp_main_thread+0x1308>
    a59b:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    a59f:	eb c7                	jmp    a568 <fwp_main_thread+0x1308>
    a5a1:	48 8d 3d b8 a6 ff ff 	lea    -0x5948(%rip),%rdi        # 4c60 <fwp_heap_report>
    a5a8:	e8 f3 10 00 00       	call   b6a0 <atexit>
    a5ad:	e9 f6 ec ff ff       	jmp    92a8 <fwp_main_thread+0x48>
    a5b2:	e8 b9 a7 ff ff       	call   4d70 <fwp_heap_init>
    a5b7:	e9 dc ec ff ff       	jmp    9298 <fwp_main_thread+0x38>
    a5bc:	0f 1f 40 00          	nopl   0x0(%rax)
    a5c0:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    a5c5:	e8 06 d5 ff ff       	call   7ad0 <fwp_drop10>
    a5ca:	48 8b 1c 24          	mov    (%rsp),%rbx
    a5ce:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    a5d3:	66 90                	xchg   %ax,%ax
    a5d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a5dc:	00 00 00 00 
    a5e0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    a5e4:	49 83 c7 01          	add    $0x1,%r15
    a5e8:	48 85 db             	test   %rbx,%rbx
    a5eb:	75 f3                	jne    a5e0 <fwp_main_thread+0x1380>
    a5ed:	4c 8b 32             	mov    (%rdx),%r14
    a5f0:	4d 85 f6             	test   %r14,%r14
    a5f3:	0f 88 07 01 00 00    	js     a700 <fwp_main_thread+0x14a0>
    a5f9:	48 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%rcx
    a600:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a605:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a60c:	48 c1 e1 10          	shl    $0x10,%rcx
    a610:	48 39 c8             	cmp    %rcx,%rax
    a613:	0f 83 e7 00 00 00    	jae    a700 <fwp_main_thread+0x14a0>
    a619:	48 89 c1             	mov    %rax,%rcx
    a61c:	48 c1 e9 10          	shr    $0x10,%rcx
    a620:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    a624:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    a62b:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    a62f:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    a633:	48 85 f6             	test   %rsi,%rsi
    a636:	0f 84 c4 00 00 00    	je     a700 <fwp_main_thread+0x14a0>
    a63c:	0f b6 39             	movzbl (%rcx),%edi
    a63f:	40 80 ff 02          	cmp    $0x2,%dil
    a643:	0f 84 a7 00 00 00    	je     a6f0 <fwp_main_thread+0x1490>
    a649:	40 80 ff 01          	cmp    $0x1,%dil
    a64d:	0f 85 ad 00 00 00    	jne    a700 <fwp_main_thread+0x14a0>
    a653:	8b 79 18             	mov    0x18(%rcx),%edi
    a656:	0f b7 c0             	movzwl %ax,%eax
    a659:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a65c:	48 0f af c7          	imul   %rdi,%rax
    a660:	48 c1 e8 20          	shr    $0x20,%rax
    a664:	48 39 c8             	cmp    %rcx,%rax
    a667:	0f 83 93 00 00 00    	jae    a700 <fwp_main_thread+0x14a0>
    a66d:	48 01 c6             	add    %rax,%rsi
    a670:	80 3e 01             	cmpb   $0x1,(%rsi)
    a673:	0f 85 87 00 00 00    	jne    a700 <fwp_main_thread+0x14a0>
    a679:	4d 39 f7             	cmp    %r14,%r15
    a67c:	4d 0f 46 f7          	cmovbe %r15,%r14
    a680:	4d 85 f6             	test   %r14,%r14
    a683:	0f 84 d3 0b 00 00    	je     b25c <fwp_main_thread+0x1ffc>
    a689:	4c 8d 62 08          	lea    0x8(%rdx),%r12
    a68d:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a693:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    a698:	48 8b 34 24          	mov    (%rsp),%rsi
    a69c:	4e 8d 04 f5 00 00 00 	lea    0x0(,%r14,8),%r8
    a6a3:	00 
    a6a4:	31 c0                	xor    %eax,%eax
    a6a6:	49 8d 79 08          	lea    0x8(%r9),%rdi
    a6aa:	eb 35                	jmp    a6e1 <fwp_main_thread+0x1481>
    a6ac:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a6b3:	00 00 
    a6b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a6bc:	00 00 00 00 
    a6c0:	f2 0f 10 46 08       	movsd  0x8(%rsi),%xmm0
    a6c5:	f2 0f 5c 04 01       	subsd  (%rcx,%rax,1),%xmm0
    a6ca:	f2 41 0f 11 04 04    	movsd  %xmm0,(%r12,%rax,1)
    a6d0:	48 83 c0 08          	add    $0x8,%rax
    a6d4:	48 8b 76 10          	mov    0x10(%rsi),%rsi
    a6d8:	49 39 c0             	cmp    %rax,%r8
    a6db:	0f 84 b7 00 00 00    	je     a798 <fwp_main_thread+0x1538>
    a6e1:	48 89 f9             	mov    %rdi,%rcx
    a6e4:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    a6e8:	79 d6                	jns    a6c0 <fwp_main_thread+0x1460>
    a6ea:	49 8b 49 10          	mov    0x10(%r9),%rcx
    a6ee:	eb d0                	jmp    a6c0 <fwp_main_thread+0x1460>
    a6f0:	66 85 c0             	test   %ax,%ax
    a6f3:	0f 84 77 ff ff ff    	je     a670 <fwp_main_thread+0x1410>
    a6f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a700:	48 8b 04 24          	mov    (%rsp),%rax
    a704:	45 31 ed             	xor    %r13d,%r13d
    a707:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a70e:	00 00 
    a710:	48 8b 40 10          	mov    0x10(%rax),%rax
    a714:	4c 89 e9             	mov    %r13,%rcx
    a717:	49 83 c5 01          	add    $0x1,%r13
    a71b:	48 85 c0             	test   %rax,%rax
    a71e:	75 f0                	jne    a710 <fwp_main_thread+0x14b0>
    a720:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a727:	ff ff 1f 
    a72a:	4c 39 e8             	cmp    %r13,%rax
    a72d:	0f 82 ed 0c 00 00    	jb     b420 <fwp_main_thread+0x21c0>
    a733:	be 02 00 00 00       	mov    $0x2,%esi
    a738:	48 8d 3c cd 10 00 00 	lea    0x10(,%rcx,8),%rdi
    a73f:	00 
    a740:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    a745:	e8 a6 b5 ff ff       	call   5cf0 <fwp_heap_alloc>
    a74a:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    a74f:	49 89 c4             	mov    %rax,%r12
    a752:	48 89 c6             	mov    %rax,%rsi
    a755:	48 8b 04 24          	mov    (%rsp),%rax
    a759:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a760:	48 8b 48 08          	mov    0x8(%rax),%rcx
    a764:	48 83 c6 08          	add    $0x8,%rsi
    a768:	48 89 4e f8          	mov    %rcx,-0x8(%rsi)
    a76c:	48 8b 40 10          	mov    0x10(%rax),%rax
    a770:	48 85 c0             	test   %rax,%rax
    a773:	75 eb                	jne    a760 <fwp_main_thread+0x1500>
    a775:	49 0f ba f6 3f       	btr    $0x3f,%r14
    a77a:	4d 39 ee             	cmp    %r13,%r14
    a77d:	4d 0f 47 f5          	cmova  %r13,%r14
    a781:	4d 85 f6             	test   %r14,%r14
    a784:	0f 84 ce 09 00 00    	je     b158 <fwp_main_thread+0x1ef8>
    a78a:	45 31 ed             	xor    %r13d,%r13d
    a78d:	e9 01 ff ff ff       	jmp    a693 <fwp_main_thread+0x1433>
    a792:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a798:	48 8b bd d8 13 00 00 	mov    0x13d8(%rbp),%rdi
    a79f:	4c 8b 85 b0 13 00 00 	mov    0x13b0(%rbp),%r8
    a7a6:	45 31 ff             	xor    %r15d,%r15d
    a7a9:	4c 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%r9
    a7b0:	48 8b 14 24          	mov    (%rsp),%rdx
    a7b4:	48 c1 e7 10          	shl    $0x10,%rdi
    a7b8:	eb 1c                	jmp    a7d6 <fwp_main_thread+0x1576>
    a7ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a7c0:	49 83 c7 01          	add    $0x1,%r15
    a7c4:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a7c8:	4d 39 f7             	cmp    %r14,%r15
    a7cb:	0f 83 ff 03 00 00    	jae    abd0 <fwp_main_thread+0x1970>
    a7d1:	48 85 d2             	test   %rdx,%rdx
    a7d4:	74 56                	je     a82c <fwp_main_thread+0x15cc>
    a7d6:	48 89 d0             	mov    %rdx,%rax
    a7d9:	4c 29 c0             	sub    %r8,%rax
    a7dc:	48 39 f8             	cmp    %rdi,%rax
    a7df:	73 4b                	jae    a82c <fwp_main_thread+0x15cc>
    a7e1:	48 89 c1             	mov    %rax,%rcx
    a7e4:	48 c1 e9 10          	shr    $0x10,%rcx
    a7e8:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    a7ec:	49 8d 0c c9          	lea    (%r9,%rcx,8),%rcx
    a7f0:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    a7f4:	48 85 f6             	test   %rsi,%rsi
    a7f7:	74 33                	je     a82c <fwp_main_thread+0x15cc>
    a7f9:	44 0f b6 11          	movzbl (%rcx),%r10d
    a7fd:	41 80 fa 02          	cmp    $0x2,%r10b
    a801:	0f 84 b1 03 00 00    	je     abb8 <fwp_main_thread+0x1958>
    a807:	41 80 fa 01          	cmp    $0x1,%r10b
    a80b:	75 1f                	jne    a82c <fwp_main_thread+0x15cc>
    a80d:	44 8b 51 18          	mov    0x18(%rcx),%r10d
    a811:	0f b7 c0             	movzwl %ax,%eax
    a814:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a817:	49 0f af c2          	imul   %r10,%rax
    a81b:	48 c1 e8 20          	shr    $0x20,%rax
    a81f:	48 39 c8             	cmp    %rcx,%rax
    a822:	73 08                	jae    a82c <fwp_main_thread+0x15cc>
    a824:	48 01 c6             	add    %rax,%rsi
    a827:	80 3e 01             	cmpb   $0x1,(%rsi)
    a82a:	74 94                	je     a7c0 <fwp_main_thread+0x1560>
    a82c:	4d 39 f7             	cmp    %r14,%r15
    a82f:	72 43                	jb     a874 <fwp_main_thread+0x1614>
    a831:	e9 9a 03 00 00       	jmp    abd0 <fwp_main_thread+0x1970>
    a836:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a83d:	00 00 00 
    a840:	40 80 fe 01          	cmp    $0x1,%sil
    a844:	75 25                	jne    a86b <fwp_main_thread+0x160b>
    a846:	8b 71 18             	mov    0x18(%rcx),%esi
    a849:	0f b7 c0             	movzwl %ax,%eax
    a84c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a84f:	48 0f af c6          	imul   %rsi,%rax
    a853:	48 c1 e8 20          	shr    $0x20,%rax
    a857:	48 39 c8             	cmp    %rcx,%rax
    a85a:	73 0f                	jae    a86b <fwp_main_thread+0x160b>
    a85c:	48 01 c2             	add    %rax,%rdx
    a85f:	80 3a ff             	cmpb   $0xff,(%rdx)
    a862:	0f 84 f8 04 00 00    	je     ad60 <fwp_main_thread+0x1b00>
    a868:	c6 02 01             	movb   $0x1,(%rdx)
    a86b:	4d 39 fe             	cmp    %r15,%r14
    a86e:	0f 84 8c 00 00 00    	je     a900 <fwp_main_thread+0x16a0>
    a874:	49 83 ee 01          	sub    $0x1,%r14
    a878:	66 48 0f 6e eb       	movq   %rbx,%xmm5
    a87d:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a882:	bf 01 00 00 00       	mov    $0x1,%edi
    a887:	f3 43 0f 7e 04 f4    	movq   (%r12,%r14,8),%xmm0
    a88d:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    a891:	0f 29 84 24 40 01 00 	movaps %xmm0,0x140(%rsp)
    a898:	00 
    a899:	e8 72 b5 ff ff       	call   5e10 <fwp_data.part.0.constprop.0>
    a89e:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a8a5:	48 89 c3             	mov    %rax,%rbx
    a8a8:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a8af:	48 c1 e2 10          	shl    $0x10,%rdx
    a8b3:	48 39 d0             	cmp    %rdx,%rax
    a8b6:	73 b3                	jae    a86b <fwp_main_thread+0x160b>
    a8b8:	48 89 c2             	mov    %rax,%rdx
    a8bb:	48 c1 ea 10          	shr    $0x10,%rdx
    a8bf:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a8c3:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a8ca:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a8ce:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    a8d2:	48 85 d2             	test   %rdx,%rdx
    a8d5:	74 94                	je     a86b <fwp_main_thread+0x160b>
    a8d7:	0f b6 31             	movzbl (%rcx),%esi
    a8da:	40 80 fe 02          	cmp    $0x2,%sil
    a8de:	0f 85 5c ff ff ff    	jne    a840 <fwp_main_thread+0x15e0>
    a8e4:	66 85 c0             	test   %ax,%ax
    a8e7:	0f 84 72 ff ff ff    	je     a85f <fwp_main_thread+0x15ff>
    a8ed:	4d 39 fe             	cmp    %r15,%r14
    a8f0:	75 82                	jne    a874 <fwp_main_thread+0x1614>
    a8f2:	0f 1f 00             	nopl   (%rax)
    a8f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a8fc:	00 00 00 00 
    a900:	4d 85 f6             	test   %r14,%r14
    a903:	0f 85 c7 02 00 00    	jne    abd0 <fwp_main_thread+0x1970>
    a909:	45 85 ed             	test   %r13d,%r13d
    a90c:	4c 0f 45 64 24 20    	cmovne 0x20(%rsp),%r12
    a912:	4c 8b 34 24          	mov    (%rsp),%r14
    a916:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
    a91b:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    a920:	e8 cb ae ff ff       	call   57f0 <fwp_mem_free>
    a925:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    a92a:	e8 a1 d1 ff ff       	call   7ad0 <fwp_drop10>
    a92f:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a936:	4c 89 f0             	mov    %r14,%rax
    a939:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a940:	48 c1 e2 10          	shl    $0x10,%rdx
    a944:	48 39 d0             	cmp    %rdx,%rax
    a947:	73 77                	jae    a9c0 <fwp_main_thread+0x1760>
    a949:	48 89 c2             	mov    %rax,%rdx
    a94c:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    a953:	48 c1 ea 10          	shr    $0x10,%rdx
    a957:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    a95b:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    a95f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a963:	4d 85 e4             	test   %r12,%r12
    a966:	74 58                	je     a9c0 <fwp_main_thread+0x1760>
    a968:	0f b6 0a             	movzbl (%rdx),%ecx
    a96b:	80 f9 02             	cmp    $0x2,%cl
    a96e:	0f 84 cc 05 00 00    	je     af40 <fwp_main_thread+0x1ce0>
    a974:	80 f9 01             	cmp    $0x1,%cl
    a977:	75 47                	jne    a9c0 <fwp_main_thread+0x1760>
    a979:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a97c:	0f b7 c0             	movzwl %ax,%eax
    a97f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a982:	48 0f af c1          	imul   %rcx,%rax
    a986:	48 c1 e8 20          	shr    $0x20,%rax
    a98a:	48 39 d0             	cmp    %rdx,%rax
    a98d:	73 31                	jae    a9c0 <fwp_main_thread+0x1760>
    a98f:	49 01 c4             	add    %rax,%r12
    a992:	41 0f b6 04 24       	movzbl (%r12),%eax
    a997:	84 c0                	test   %al,%al
    a999:	74 25                	je     a9c0 <fwp_main_thread+0x1760>
    a99b:	3c 01                	cmp    $0x1,%al
    a99d:	0f 84 4d 06 00 00    	je     aff0 <fwp_main_thread+0x1d90>
    a9a3:	3c ff                	cmp    $0xff,%al
    a9a5:	0f 84 39 08 00 00    	je     b1e4 <fwp_main_thread+0x1f84>
    a9ab:	83 e8 01             	sub    $0x1,%eax
    a9ae:	41 88 04 24          	mov    %al,(%r12)
    a9b2:	0f 1f 00             	nopl   (%rax)
    a9b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a9bc:	00 00 00 00 
    a9c0:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    a9c5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a9c9:	b9 01 00 00 00       	mov    $0x1,%ecx
    a9ce:	48 89 de             	mov    %rbx,%rsi
    a9d1:	48 8d 15 a8 51 00 00 	lea    0x51a8(%rip),%rdx        # fb80 <d0>
    a9d8:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    a9df:	00 
    a9e0:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
    a9e7:	00 00 00 00 00 
    a9ec:	e8 2f d8 ff ff       	call   8220 <fwp_write>
    a9f1:	4c 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%r14
    a9f8:	00 
    a9f9:	4c 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%r15
    aa00:	00 
    aa01:	48 8d 05 89 16 00 00 	lea    0x1689(%rip),%rax        # c091 <_IO_stdin_used+0x91>
    aa08:	4d 85 f6             	test   %r14,%r14
    aa0b:	4c 0f 44 f0          	cmove  %rax,%r14
    aa0f:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    aa13:	0f 87 54 0a 00 00    	ja     b46d <fwp_main_thread+0x220d>
    aa19:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    aa1d:	be 01 00 00 00       	mov    $0x1,%esi
    aa22:	e8 c9 b2 ff ff       	call   5cf0 <fwp_heap_alloc>
    aa27:	4c 89 fa             	mov    %r15,%rdx
    aa2a:	4c 89 f6             	mov    %r14,%rsi
    aa2d:	4c 89 38             	mov    %r15,(%rax)
    aa30:	4c 8d 68 08          	lea    0x8(%rax),%r13
    aa34:	49 89 c4             	mov    %rax,%r12
    aa37:	4c 89 ef             	mov    %r13,%rdi
    aa3a:	e8 61 8b ff ff       	call   35a0 <memcpy@plt>
    aa3f:	43 c6 44 3c 08 00    	movb   $0x0,0x8(%r12,%r15,1)
    aa45:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
    aa4c:	00 
    aa4d:	e8 6e 89 ff ff       	call   33c0 <free@plt>
    aa52:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    aa59:	4c 89 e0             	mov    %r12,%rax
    aa5c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    aa63:	48 c1 e2 10          	shl    $0x10,%rdx
    aa67:	48 39 d0             	cmp    %rdx,%rax
    aa6a:	73 57                	jae    aac3 <fwp_main_thread+0x1863>
    aa6c:	48 89 c2             	mov    %rax,%rdx
    aa6f:	48 c1 ea 10          	shr    $0x10,%rdx
    aa73:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aa77:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    aa7e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aa82:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    aa86:	4d 85 f6             	test   %r14,%r14
    aa89:	74 38                	je     aac3 <fwp_main_thread+0x1863>
    aa8b:	0f b6 0a             	movzbl (%rdx),%ecx
    aa8e:	80 f9 02             	cmp    $0x2,%cl
    aa91:	0f 84 59 06 00 00    	je     b0f0 <fwp_main_thread+0x1e90>
    aa97:	80 f9 01             	cmp    $0x1,%cl
    aa9a:	75 27                	jne    aac3 <fwp_main_thread+0x1863>
    aa9c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aa9f:	0f b7 c0             	movzwl %ax,%eax
    aaa2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aaa5:	48 0f af c1          	imul   %rcx,%rax
    aaa9:	48 c1 e8 20          	shr    $0x20,%rax
    aaad:	48 39 d0             	cmp    %rdx,%rax
    aab0:	73 11                	jae    aac3 <fwp_main_thread+0x1863>
    aab2:	49 01 c6             	add    %rax,%r14
    aab5:	41 80 3e ff          	cmpb   $0xff,(%r14)
    aab9:	0f 84 44 06 00 00    	je     b103 <fwp_main_thread+0x1ea3>
    aabf:	41 c6 06 01          	movb   $0x1,(%r14)
    aac3:	48 89 df             	mov    %rbx,%rdi
    aac6:	e8 15 cc ff ff       	call   76e0 <fwp_drop0>
    aacb:	49 8b 14 24          	mov    (%r12),%rdx
    aacf:	be 01 00 00 00       	mov    $0x1,%esi
    aad4:	4c 89 ef             	mov    %r13,%rdi
    aad7:	48 8b 0d 62 79 01 00 	mov    0x17962(%rip),%rcx        # 22440 <fwp_prog_out>
    aade:	e8 9d 8b ff ff       	call   3680 <fwrite@plt>
    aae3:	48 8b 35 56 79 01 00 	mov    0x17956(%rip),%rsi        # 22440 <fwp_prog_out>
    aaea:	bf 0a 00 00 00       	mov    $0xa,%edi
    aaef:	e8 ec 89 ff ff       	call   34e0 <fputc@plt>
    aaf4:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    aafb:	4c 89 e0             	mov    %r12,%rax
    aafe:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    ab05:	48 c1 e2 10          	shl    $0x10,%rdx
    ab09:	48 39 d0             	cmp    %rdx,%rax
    ab0c:	73 72                	jae    ab80 <fwp_main_thread+0x1920>
    ab0e:	48 89 c2             	mov    %rax,%rdx
    ab11:	48 c1 ea 10          	shr    $0x10,%rdx
    ab15:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ab19:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    ab20:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ab24:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    ab28:	48 85 db             	test   %rbx,%rbx
    ab2b:	74 53                	je     ab80 <fwp_main_thread+0x1920>
    ab2d:	0f b6 0a             	movzbl (%rdx),%ecx
    ab30:	80 f9 02             	cmp    $0x2,%cl
    ab33:	0f 84 d7 05 00 00    	je     b110 <fwp_main_thread+0x1eb0>
    ab39:	80 f9 01             	cmp    $0x1,%cl
    ab3c:	75 42                	jne    ab80 <fwp_main_thread+0x1920>
    ab3e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ab41:	0f b7 c0             	movzwl %ax,%eax
    ab44:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ab47:	48 0f af c1          	imul   %rcx,%rax
    ab4b:	48 c1 e8 20          	shr    $0x20,%rax
    ab4f:	48 39 d0             	cmp    %rdx,%rax
    ab52:	73 2c                	jae    ab80 <fwp_main_thread+0x1920>
    ab54:	48 01 c3             	add    %rax,%rbx
    ab57:	0f b6 03             	movzbl (%rbx),%eax
    ab5a:	84 c0                	test   %al,%al
    ab5c:	74 22                	je     ab80 <fwp_main_thread+0x1920>
    ab5e:	3c 01                	cmp    $0x1,%al
    ab60:	0f 84 c6 05 00 00    	je     b12c <fwp_main_thread+0x1ecc>
    ab66:	3c ff                	cmp    $0xff,%al
    ab68:	0f 84 92 07 00 00    	je     b300 <fwp_main_thread+0x20a0>
    ab6e:	83 e8 01             	sub    $0x1,%eax
    ab71:	88 03                	mov    %al,(%rbx)
    ab73:	66 90                	xchg   %ax,%ax
    ab75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ab7c:	00 00 00 00 
    ab80:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    ab85:	48 8b 40 10          	mov    0x10(%rax),%rax
    ab89:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    ab8e:	48 85 c0             	test   %rax,%rax
    ab91:	0f 84 e6 05 00 00    	je     b17d <fwp_main_thread+0x1f1d>
    ab97:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    ab9e:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    aba5:	48 8b 1d cc 78 01 00 	mov    0x178cc(%rip),%rbx        # 22478 <fwp_cleanups>
    abac:	e9 7f f0 ff ff       	jmp    9c30 <fwp_main_thread+0x9d0>
    abb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    abb8:	66 85 c0             	test   %ax,%ax
    abbb:	0f 84 66 fc ff ff    	je     a827 <fwp_main_thread+0x15c7>
    abc1:	4d 39 f7             	cmp    %r14,%r15
    abc4:	0f 82 aa fc ff ff    	jb     a874 <fwp_main_thread+0x1614>
    abca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    abd0:	4c 8b 34 24          	mov    (%rsp),%r14
    abd4:	4c 89 e0             	mov    %r12,%rax
    abd7:	4b 8d 3c fc          	lea    (%r12,%r15,8),%rdi
    abdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    abe0:	48 8b 10             	mov    (%rax),%rdx
    abe3:	48 83 c0 08          	add    $0x8,%rax
    abe7:	4c 89 f6             	mov    %r14,%rsi
    abea:	49 89 56 08          	mov    %rdx,0x8(%r14)
    abee:	4d 8b 76 10          	mov    0x10(%r14),%r14
    abf2:	48 39 f8             	cmp    %rdi,%rax
    abf5:	75 e9                	jne    abe0 <fwp_main_thread+0x1980>
    abf7:	45 85 ed             	test   %r13d,%r13d
    abfa:	4c 0f 45 64 24 20    	cmovne 0x20(%rsp),%r12
    ac00:	48 89 5e 10          	mov    %rbx,0x10(%rsi)
    ac04:	48 8b 1c 24          	mov    (%rsp),%rbx
    ac08:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
    ac0d:	e9 09 fd ff ff       	jmp    a91b <fwp_main_thread+0x16bb>
    ac12:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ac18:	48 83 3d 88 54 01 00 	cmpq   $0x0,0x15488(%rip)        # 200a8 <fwp_tape_cached_bytes>
    ac1f:	00 
    ac20:	0f 84 b2 f2 ff ff    	je     9ed8 <fwp_main_thread+0xc78>
    ac26:	66 0f 6f 0d 92 54 01 	movdqa 0x15492(%rip),%xmm1        # 200c0 <fwp_tape_workspace>
    ac2d:	00 
    ac2e:	48 c7 05 6f 54 01 00 	movq   $0x0,0x1546f(%rip)        # 200a8 <fwp_tape_cached_bytes>
    ac35:	00 00 00 00 
    ac39:	0f 11 4a 20          	movups %xmm1,0x20(%rdx)
    ac3d:	48 8b 05 9c 54 01 00 	mov    0x1549c(%rip),%rax        # 200e0 <fwp_tape_workspace+0x20>
    ac44:	66 0f 6f 0d 84 54 01 	movdqa 0x15484(%rip),%xmm1        # 200d0 <fwp_tape_workspace+0x10>
    ac4b:	00 
    ac4c:	48 89 42 40          	mov    %rax,0x40(%rdx)
    ac50:	48 8b 05 91 54 01 00 	mov    0x15491(%rip),%rax        # 200e8 <fwp_tape_workspace+0x28>
    ac57:	0f 11 4a 30          	movups %xmm1,0x30(%rdx)
    ac5b:	66 0f ef c9          	pxor   %xmm1,%xmm1
    ac5f:	48 89 42 18          	mov    %rax,0x18(%rdx)
    ac63:	48 8b 05 86 54 01 00 	mov    0x15486(%rip),%rax        # 200f0 <fwp_tape_workspace+0x30>
    ac6a:	0f 29 0d 4f 54 01 00 	movaps %xmm1,0x1544f(%rip)        # 200c0 <fwp_tape_workspace>
    ac71:	48 89 42 48          	mov    %rax,0x48(%rdx)
    ac75:	0f 29 0d 54 54 01 00 	movaps %xmm1,0x15454(%rip)        # 200d0 <fwp_tape_workspace+0x10>
    ac7c:	48 c7 05 69 54 01 00 	movq   $0x0,0x15469(%rip)        # 200f0 <fwp_tape_workspace+0x30>
    ac83:	00 00 00 00 
    ac87:	0f 29 0d 52 54 01 00 	movaps %xmm1,0x15452(%rip)        # 200e0 <fwp_tape_workspace+0x20>
    ac8e:	e9 45 f2 ff ff       	jmp    9ed8 <fwp_main_thread+0xc78>
    ac93:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ac98:	66 85 c0             	test   %ax,%ax
    ac9b:	0f 84 9e f8 ff ff    	je     a53f <fwp_main_thread+0x12df>
    aca1:	0f 1f 40 00          	nopl   0x0(%rax)
    aca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    acac:	00 00 00 00 
    acb0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    acb7:	ff ff 1f 
    acba:	4c 39 e8             	cmp    %r13,%rax
    acbd:	0f 82 45 07 00 00    	jb     b408 <fwp_main_thread+0x21a8>
    acc3:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    acca:	00 
    accb:	be 01 00 00 00       	mov    $0x1,%esi
    acd0:	e8 1b b0 ff ff       	call   5cf0 <fwp_heap_alloc>
    acd5:	4c 89 28             	mov    %r13,(%rax)
    acd8:	48 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%rcx
    acdf:	48 89 c2             	mov    %rax,%rdx
    ace2:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    ace7:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    acee:	48 c1 e1 10          	shl    $0x10,%rcx
    acf2:	48 39 c8             	cmp    %rcx,%rax
    acf5:	73 59                	jae    ad50 <fwp_main_thread+0x1af0>
    acf7:	48 89 c1             	mov    %rax,%rcx
    acfa:	48 c1 e9 10          	shr    $0x10,%rcx
    acfe:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    ad02:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    ad09:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    ad0d:	4c 8b 71 20          	mov    0x20(%rcx),%r14
    ad11:	4d 85 f6             	test   %r14,%r14
    ad14:	74 3a                	je     ad50 <fwp_main_thread+0x1af0>
    ad16:	0f b6 31             	movzbl (%rcx),%esi
    ad19:	40 80 fe 02          	cmp    $0x2,%sil
    ad1d:	0f 84 6d 03 00 00    	je     b090 <fwp_main_thread+0x1e30>
    ad23:	40 80 fe 01          	cmp    $0x1,%sil
    ad27:	75 27                	jne    ad50 <fwp_main_thread+0x1af0>
    ad29:	8b 71 18             	mov    0x18(%rcx),%esi
    ad2c:	0f b7 c0             	movzwl %ax,%eax
    ad2f:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    ad32:	48 0f af c6          	imul   %rsi,%rax
    ad36:	48 c1 e8 20          	shr    $0x20,%rax
    ad3a:	48 39 c8             	cmp    %rcx,%rax
    ad3d:	73 11                	jae    ad50 <fwp_main_thread+0x1af0>
    ad3f:	49 01 c6             	add    %rax,%r14
    ad42:	41 80 3e ff          	cmpb   $0xff,(%r14)
    ad46:	0f 84 57 03 00 00    	je     b0a3 <fwp_main_thread+0x1e43>
    ad4c:	41 c6 06 01          	movb   $0x1,(%r14)
    ad50:	48 89 df             	mov    %rbx,%rdi
    ad53:	e9 fa f7 ff ff       	jmp    a552 <fwp_main_thread+0x12f2>
    ad58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ad5f:	00 
    ad60:	48 89 d7             	mov    %rdx,%rdi
    ad63:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    ad68:	e8 43 a8 ff ff       	call   55b0 <fwp_rc_forget_slot>
    ad6d:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    ad72:	e9 f1 fa ff ff       	jmp    a868 <fwp_main_thread+0x1608>
    ad77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ad7e:	00 00 
    ad80:	4d 85 e4             	test   %r12,%r12
    ad83:	0f 85 ea f2 ff ff    	jne    a073 <fwp_main_thread+0xe13>
    ad89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ad90:	31 d2                	xor    %edx,%edx
    ad92:	e9 8c f3 ff ff       	jmp    a123 <fwp_main_thread+0xec3>
    ad97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ad9e:	00 00 
    ada0:	49 39 d6             	cmp    %rdx,%r14
    ada3:	0f 84 47 f0 ff ff    	je     9df0 <fwp_main_thread+0xb90>
    ada9:	4c 8b 3d 60 53 01 00 	mov    0x15360(%rip),%r15        # 20110 <fwp_tapes>
    adb0:	49 89 d6             	mov    %rdx,%r14
    adb3:	48 8d 5a 01          	lea    0x1(%rdx),%rbx
    adb7:	e9 c7 f0 ff ff       	jmp    9e83 <fwp_main_thread+0xc23>
    adbc:	0f 1f 40 00          	nopl   0x0(%rax)
    adc0:	be 02 00 00 00       	mov    $0x2,%esi
    adc5:	bf 08 00 00 00       	mov    $0x8,%edi
    adca:	49 c1 e5 10          	shl    $0x10,%r13
    adce:	e8 1d af ff ff       	call   5cf0 <fwp_heap_alloc>
    add3:	4c 09 eb             	or     %r13,%rbx
    add6:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    addd:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ade4:	49 89 c6             	mov    %rax,%r14
    ade7:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    adee:	48 c1 e2 10          	shl    $0x10,%rdx
    adf2:	48 39 d0             	cmp    %rdx,%rax
    adf5:	73 99                	jae    ad90 <fwp_main_thread+0x1b30>
    adf7:	48 89 c2             	mov    %rax,%rdx
    adfa:	48 c1 ea 10          	shr    $0x10,%rdx
    adfe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ae02:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    ae09:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ae0d:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    ae11:	4d 85 ed             	test   %r13,%r13
    ae14:	0f 84 9a f2 ff ff    	je     a0b4 <fwp_main_thread+0xe54>
    ae1a:	0f b6 0a             	movzbl (%rdx),%ecx
    ae1d:	45 31 e4             	xor    %r12d,%r12d
    ae20:	80 f9 02             	cmp    $0x2,%cl
    ae23:	0f 85 17 f2 ff ff    	jne    a040 <fwp_main_thread+0xde0>
    ae29:	66 85 c0             	test   %ax,%ax
    ae2c:	0f 85 3c f2 ff ff    	jne    a06e <fwp_main_thread+0xe0e>
    ae32:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    ae37:	0f 85 2c f2 ff ff    	jne    a069 <fwp_main_thread+0xe09>
    ae3d:	4c 89 ef             	mov    %r13,%rdi
    ae40:	e8 6b a7 ff ff       	call   55b0 <fwp_rc_forget_slot>
    ae45:	e9 1f f2 ff ff       	jmp    a069 <fwp_main_thread+0xe09>
    ae4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ae50:	49 8d 59 01          	lea    0x1(%r9),%rbx
    ae54:	49 39 de             	cmp    %rbx,%r14
    ae57:	7c 3a                	jl     ae93 <fwp_main_thread+0x1c33>
    ae59:	48 85 c9             	test   %rcx,%rcx
    ae5c:	0f 84 18 01 00 00    	je     af7a <fwp_main_thread+0x1d1a>
    ae62:	48 89 cf             	mov    %rcx,%rdi
    ae65:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    ae6c:	00 
    ae6d:	31 f6                	xor    %esi,%esi
    ae6f:	49 89 de             	mov    %rbx,%r14
    ae72:	4c 89 4c 24 48       	mov    %r9,0x48(%rsp)
    ae77:	4d 29 e6             	sub    %r12,%r14
    ae7a:	e8 41 86 ff ff       	call   34c0 <memset@plt>
    ae7f:	4c 8b 4c 24 48       	mov    0x48(%rsp),%r9
    ae84:	48 89 c1             	mov    %rax,%rcx
    ae87:	e9 3e f4 ff ff       	jmp    a2ca <fwp_main_thread+0x106a>
    ae8c:	0f 1f 40 00          	nopl   0x0(%rax)
    ae90:	4c 89 e3             	mov    %r12,%rbx
    ae93:	4d 85 f6             	test   %r14,%r14
    ae96:	4c 0f 44 f3          	cmove  %rbx,%r14
    ae9a:	eb 19                	jmp    aeb5 <fwp_main_thread+0x1c55>
    ae9c:	0f 1f 40 00          	nopl   0x0(%rax)
    aea0:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
    aea4:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    aeab:	48 89 d8             	mov    %rbx,%rax
    aeae:	48 0f 4c c2          	cmovl  %rdx,%rax
    aeb2:	49 89 c6             	mov    %rax,%r14
    aeb5:	49 39 de             	cmp    %rbx,%r14
    aeb8:	7c e6                	jl     aea0 <fwp_main_thread+0x1c40>
    aeba:	48 85 c9             	test   %rcx,%rcx
    aebd:	0f 84 fd 01 00 00    	je     b0c0 <fwp_main_thread+0x1e60>
    aec3:	48 89 cf             	mov    %rcx,%rdi
    aec6:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    aecd:	00 
    aece:	e8 fd 86 ff ff       	call   35d0 <realloc@plt>
    aed3:	48 89 c1             	mov    %rax,%rcx
    aed6:	48 85 c9             	test   %rcx,%rcx
    aed9:	0f 84 8d 00 00 00    	je     af6c <fwp_main_thread+0x1d0c>
    aedf:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
    aee6:	00 
    aee7:	4c 89 b4 24 00 01 00 	mov    %r14,0x100(%rsp)
    aeee:	00 
    aeef:	48 85 db             	test   %rbx,%rbx
    aef2:	0f 85 85 03 00 00    	jne    b27d <fwp_main_thread+0x201d>
    aef8:	4d 89 e6             	mov    %r12,%r14
    aefb:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    af02:	49 f7 de             	neg    %r14
    af05:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    af0a:	48 85 c0             	test   %rax,%rax
    af0d:	0f 88 c9 f3 ff ff    	js     a2dc <fwp_main_thread+0x107c>
    af13:	41 89 c1             	mov    %eax,%r9d
    af16:	e9 af f3 ff ff       	jmp    a2ca <fwp_main_thread+0x106a>
    af1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    af20:	48 8d 3d 99 bb ff ff 	lea    -0x4467(%rip),%rdi        # 6ac0 <fwp_tape_finish>
    af27:	e8 74 07 00 00       	call   b6a0 <atexit>
    af2c:	85 c0                	test   %eax,%eax
    af2e:	75 63                	jne    af93 <fwp_main_thread+0x1d33>
    af30:	c7 05 42 51 00 00 01 	movl   $0x1,0x5142(%rip)        # 1007c <registered_finish.5>
    af37:	00 00 00 
    af3a:	e9 61 ee ff ff       	jmp    9da0 <fwp_main_thread+0xb40>
    af3f:	90                   	nop
    af40:	66 85 c0             	test   %ax,%ax
    af43:	0f 85 77 fa ff ff    	jne    a9c0 <fwp_main_thread+0x1760>
    af49:	e9 44 fa ff ff       	jmp    a992 <fwp_main_thread+0x1732>
    af4e:	66 90                	xchg   %ax,%ax
    af50:	66 85 c0             	test   %ax,%ax
    af53:	0f 85 01 ee ff ff    	jne    9d5a <fwp_main_thread+0xafa>
    af59:	e9 e8 ed ff ff       	jmp    9d46 <fwp_main_thread+0xae6>
    af5e:	66 90                	xchg   %ax,%ax
    af60:	4c 89 e3             	mov    %r12,%rbx
    af63:	4d 39 f4             	cmp    %r14,%r12
    af66:	0f 8f 27 ff ff ff    	jg     ae93 <fwp_main_thread+0x1c33>
    af6c:	48 85 db             	test   %rbx,%rbx
    af6f:	74 87                	je     aef8 <fwp_main_thread+0x1c98>
    af71:	48 85 c9             	test   %rcx,%rcx
    af74:	0f 85 75 ff ff ff    	jne    aeef <fwp_main_thread+0x1c8f>
    af7a:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    af81:	00 
    af82:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    af87:	48 89 05 ea 74 01 00 	mov    %rax,0x174ea(%rip)        # 22478 <fwp_cleanups>
    af8e:	e8 3d a1 ff ff       	call   50d0 <fwp_tape_buffers_release>
    af93:	48 8b 0d a6 50 00 00 	mov    0x50a6(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    af9a:	ba 13 00 00 00       	mov    $0x13,%edx
    af9f:	be 01 00 00 00       	mov    $0x1,%esi
    afa4:	48 8d 3d 5d 10 00 00 	lea    0x105d(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    afab:	e8 d0 86 ff ff       	call   3680 <fwrite@plt>
    afb0:	31 ff                	xor    %edi,%edi
    afb2:	e8 09 86 ff ff       	call   35c0 <fflush@plt>
    afb7:	bf 66 00 00 00       	mov    $0x66,%edi
    afbc:	e8 df 86 ff ff       	call   36a0 <_Exit@plt>
    afc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    afc8:	66 85 c0             	test   %ax,%ax
    afcb:	0f 85 c1 f4 ff ff    	jne    a492 <fwp_main_thread+0x1232>
    afd1:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    afd6:	0f 85 b1 f4 ff ff    	jne    a48d <fwp_main_thread+0x122d>
    afdc:	4c 89 ef             	mov    %r13,%rdi
    afdf:	e8 cc a5 ff ff       	call   55b0 <fwp_rc_forget_slot>
    afe4:	e9 a4 f4 ff ff       	jmp    a48d <fwp_main_thread+0x122d>
    afe9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aff0:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    aff7:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    affe:	4c 89 f0             	mov    %r14,%rax
    b001:	4d 8b 66 10          	mov    0x10(%r14),%r12
    b005:	48 29 c8             	sub    %rcx,%rax
    b008:	48 c1 e2 10          	shl    $0x10,%rdx
    b00c:	48 39 d0             	cmp    %rdx,%rax
    b00f:	73 65                	jae    b076 <fwp_main_thread+0x1e16>
    b011:	48 89 c7             	mov    %rax,%rdi
    b014:	48 c1 ef 10          	shr    $0x10,%rdi
    b018:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    b01c:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b020:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    b024:	48 85 ff             	test   %rdi,%rdi
    b027:	74 4d                	je     b076 <fwp_main_thread+0x1e16>
    b029:	44 0f b6 06          	movzbl (%rsi),%r8d
    b02d:	41 80 f8 02          	cmp    $0x2,%r8b
    b031:	0f 84 31 01 00 00    	je     b168 <fwp_main_thread+0x1f08>
    b037:	41 80 f8 01          	cmp    $0x1,%r8b
    b03b:	75 39                	jne    b076 <fwp_main_thread+0x1e16>
    b03d:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    b041:	0f b7 c0             	movzwl %ax,%eax
    b044:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b047:	49 0f af c0          	imul   %r8,%rax
    b04b:	48 c1 e8 20          	shr    $0x20,%rax
    b04f:	48 39 f0             	cmp    %rsi,%rax
    b052:	73 22                	jae    b076 <fwp_main_thread+0x1e16>
    b054:	48 01 c7             	add    %rax,%rdi
    b057:	80 3f 01             	cmpb   $0x1,(%rdi)
    b05a:	75 1a                	jne    b076 <fwp_main_thread+0x1e16>
    b05c:	4c 89 f7             	mov    %r14,%rdi
    b05f:	e8 8c a7 ff ff       	call   57f0 <fwp_mem_free>
    b064:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b06b:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b072:	48 c1 e2 10          	shl    $0x10,%rdx
    b076:	4c 89 e0             	mov    %r12,%rax
    b079:	48 29 c8             	sub    %rcx,%rax
    b07c:	48 39 d0             	cmp    %rdx,%rax
    b07f:	0f 83 3b f9 ff ff    	jae    a9c0 <fwp_main_thread+0x1760>
    b085:	4d 89 e6             	mov    %r12,%r14
    b088:	e9 bc f8 ff ff       	jmp    a949 <fwp_main_thread+0x16e9>
    b08d:	0f 1f 00             	nopl   (%rax)
    b090:	66 85 c0             	test   %ax,%ax
    b093:	0f 85 b7 fc ff ff    	jne    ad50 <fwp_main_thread+0x1af0>
    b099:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b09d:	0f 85 a9 fc ff ff    	jne    ad4c <fwp_main_thread+0x1aec>
    b0a3:	4c 89 f7             	mov    %r14,%rdi
    b0a6:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    b0ab:	e8 00 a5 ff ff       	call   55b0 <fwp_rc_forget_slot>
    b0b0:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    b0b5:	e9 92 fc ff ff       	jmp    ad4c <fwp_main_thread+0x1aec>
    b0ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b0c0:	be 08 00 00 00       	mov    $0x8,%esi
    b0c5:	4c 89 f7             	mov    %r14,%rdi
    b0c8:	e8 53 84 ff ff       	call   3520 <calloc@plt>
    b0cd:	48 89 c1             	mov    %rax,%rcx
    b0d0:	e9 01 fe ff ff       	jmp    aed6 <fwp_main_thread+0x1c76>
    b0d5:	0f 1f 00             	nopl   (%rax)
    b0d8:	66 85 c0             	test   %ax,%ax
    b0db:	0f 85 d2 eb ff ff    	jne    9cb3 <fwp_main_thread+0xa53>
    b0e1:	e9 a7 eb ff ff       	jmp    9c8d <fwp_main_thread+0xa2d>
    b0e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b0ed:	00 00 00 
    b0f0:	66 85 c0             	test   %ax,%ax
    b0f3:	0f 85 ca f9 ff ff    	jne    aac3 <fwp_main_thread+0x1863>
    b0f9:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b0fd:	0f 85 bc f9 ff ff    	jne    aabf <fwp_main_thread+0x185f>
    b103:	4c 89 f7             	mov    %r14,%rdi
    b106:	e8 a5 a4 ff ff       	call   55b0 <fwp_rc_forget_slot>
    b10b:	e9 af f9 ff ff       	jmp    aabf <fwp_main_thread+0x185f>
    b110:	66 85 c0             	test   %ax,%ax
    b113:	0f 85 67 fa ff ff    	jne    ab80 <fwp_main_thread+0x1920>
    b119:	0f b6 03             	movzbl (%rbx),%eax
    b11c:	84 c0                	test   %al,%al
    b11e:	0f 84 5c fa ff ff    	je     ab80 <fwp_main_thread+0x1920>
    b124:	3c 01                	cmp    $0x1,%al
    b126:	0f 85 3a fa ff ff    	jne    ab66 <fwp_main_thread+0x1906>
    b12c:	4c 89 e7             	mov    %r12,%rdi
    b12f:	e8 bc a6 ff ff       	call   57f0 <fwp_mem_free>
    b134:	e9 47 fa ff ff       	jmp    ab80 <fwp_main_thread+0x1920>
    b139:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b140:	be 68 00 00 00       	mov    $0x68,%esi
    b145:	bb 01 00 00 00       	mov    $0x1,%ebx
    b14a:	e9 db ec ff ff       	jmp    9e2a <fwp_main_thread+0xbca>
    b14f:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b153:	e9 02 e3 ff ff       	jmp    945a <fwp_main_thread+0x1fa>
    b158:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
    b15d:	4c 8b 34 24          	mov    (%rsp),%r14
    b161:	31 db                	xor    %ebx,%ebx
    b163:	e9 b3 f7 ff ff       	jmp    a91b <fwp_main_thread+0x16bb>
    b168:	66 85 c0             	test   %ax,%ax
    b16b:	0f 85 05 ff ff ff    	jne    b076 <fwp_main_thread+0x1e16>
    b171:	e9 e1 fe ff ff       	jmp    b057 <fwp_main_thread+0x1df7>
    b176:	31 db                	xor    %ebx,%ebx
    b178:	e9 9f e3 ff ff       	jmp    951c <fwp_main_thread+0x2bc>
    b17d:	4c 8b 74 24 78       	mov    0x78(%rsp),%r14
    b182:	48 8b 3c 24          	mov    (%rsp),%rdi
    b186:	e8 55 c5 ff ff       	call   76e0 <fwp_drop0>
    b18b:	4c 89 f7             	mov    %r14,%rdi
    b18e:	e8 4d c5 ff ff       	call   76e0 <fwp_drop0>
    b193:	48 c7 05 e2 4e 00 00 	movq   $0x0,0x4ee2(%rip)        # 10080 <v.6>
    b19a:	00 00 00 00 
    b19e:	c7 05 e0 4e 00 00 01 	movl   $0x1,0x4ee0(%rip)        # 10088 <st.7>
    b1a5:	00 00 00 
    b1a8:	e9 f9 e1 ff ff       	jmp    93a6 <fwp_main_thread+0x146>
    b1ad:	66 85 c0             	test   %ax,%ax
    b1b0:	0f 85 9a e9 ff ff    	jne    9b50 <fwp_main_thread+0x8f0>
    b1b6:	e9 85 e9 ff ff       	jmp    9b40 <fwp_main_thread+0x8e0>
    b1bb:	66 85 c0             	test   %ax,%ax
    b1be:	0f 85 ed e8 ff ff    	jne    9ab1 <fwp_main_thread+0x851>
    b1c4:	e9 d8 e8 ff ff       	jmp    9aa1 <fwp_main_thread+0x841>
    b1c9:	66 85 c0             	test   %ax,%ax
    b1cc:	0f 85 34 ea ff ff    	jne    9c06 <fwp_main_thread+0x9a6>
    b1d2:	e9 11 ea ff ff       	jmp    9be8 <fwp_main_thread+0x988>
    b1d7:	4c 89 ef             	mov    %r13,%rdi
    b1da:	e8 d1 a3 ff ff       	call   55b0 <fwp_rc_forget_slot>
    b1df:	e9 8d e7 ff ff       	jmp    9971 <fwp_main_thread+0x711>
    b1e4:	4c 89 e2             	mov    %r12,%rdx
    b1e7:	48 c1 ea 11          	shr    $0x11,%rdx
    b1eb:	4c 31 e2             	xor    %r12,%rdx
    b1ee:	48 89 d0             	mov    %rdx,%rax
    b1f1:	48 c1 e8 09          	shr    $0x9,%rax
    b1f5:	48 31 c2             	xor    %rax,%rdx
    b1f8:	0f b6 d2             	movzbl %dl,%edx
    b1fb:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b202:	00 
    b203:	48 85 c0             	test   %rax,%rax
    b206:	75 21                	jne    b229 <fwp_main_thread+0x1fc9>
    b208:	eb 67                	jmp    b271 <fwp_main_thread+0x2011>
    b20a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b211:	00 00 00 00 
    b215:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b21c:	00 00 00 00 
    b220:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b224:	48 85 c0             	test   %rax,%rax
    b227:	74 48                	je     b271 <fwp_main_thread+0x2011>
    b229:	48 89 c2             	mov    %rax,%rdx
    b22c:	4c 3b 20             	cmp    (%rax),%r12
    b22f:	75 ef                	jne    b220 <fwp_main_thread+0x1fc0>
    b231:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b235:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b239:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b23d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b244:	0f 85 76 f7 ff ff    	jne    a9c0 <fwp_main_thread+0x1760>
    b24a:	4c 89 e7             	mov    %r12,%rdi
    b24d:	e8 5e a3 ff ff       	call   55b0 <fwp_rc_forget_slot>
    b252:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b257:	e9 64 f7 ff ff       	jmp    a9c0 <fwp_main_thread+0x1760>
    b25c:	4c 8b 34 24          	mov    (%rsp),%r14
    b260:	31 db                	xor    %ebx,%ebx
    b262:	e9 b4 f6 ff ff       	jmp    a91b <fwp_main_thread+0x16bb>
    b267:	e8 24 a2 ff ff       	call   5490 <fwp_rc_wide_dup>
    b26c:	e9 e9 ea ff ff       	jmp    9d5a <fwp_main_thread+0xafa>
    b271:	48 8d 3d 18 16 00 00 	lea    0x1618(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    b278:	e8 73 91 ff ff       	call   43f0 <fwp_trap>
    b27d:	48 89 cf             	mov    %rcx,%rdi
    b280:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    b287:	00 
    b288:	31 f6                	xor    %esi,%esi
    b28a:	49 89 de             	mov    %rbx,%r14
    b28d:	e8 2e 82 ff ff       	call   34c0 <memset@plt>
    b292:	4c 8d 6b ff          	lea    -0x1(%rbx),%r13
    b296:	4d 29 e6             	sub    %r12,%r14
    b299:	48 89 c1             	mov    %rax,%rcx
    b29c:	e9 64 fc ff ff       	jmp    af05 <fwp_main_thread+0x1ca5>
    b2a1:	48 8b 3d b8 71 01 00 	mov    0x171b8(%rip),%rdi        # 22460 <fwp_state>
    b2a8:	e8 43 a5 ff ff       	call   57f0 <fwp_mem_free>
    b2ad:	48 c7 05 a8 71 01 00 	movq   $0x0,0x171a8(%rip)        # 22460 <fwp_state>
    b2b4:	00 00 00 00 
    b2b8:	48 c7 05 8d 71 01 00 	movq   $0x0,0x1718d(%rip)        # 22450 <fwp_state_cap>
    b2bf:	00 00 00 00 
    b2c3:	48 85 db             	test   %rbx,%rbx
    b2c6:	0f 84 e6 00 00 00    	je     b3b2 <fwp_main_thread+0x2152>
    b2cc:	48 3b 1d e5 54 01 00 	cmp    0x154e5(%rip),%rbx        # 207b8 <fwp_root>
    b2d3:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    b2da:	00 00 00 00 
    b2de:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    b2e5:	00 00 00 00 
    b2e9:	c7 05 ad 4d 01 00 00 	movl   $0x0,0x14dad(%rip)        # 200a0 <fwp_exit_code>
    b2f0:	00 00 00 
    b2f3:	0f 84 4d e2 ff ff    	je     9546 <fwp_main_thread+0x2e6>
    b2f9:	e9 4d 84 ff ff       	jmp    374b <fwp_main_thread.cold>
    b2fe:	66 90                	xchg   %ax,%ax
    b300:	48 89 d8             	mov    %rbx,%rax
    b303:	48 c1 e8 11          	shr    $0x11,%rax
    b307:	48 31 d8             	xor    %rbx,%rax
    b30a:	48 89 c2             	mov    %rax,%rdx
    b30d:	48 c1 ea 09          	shr    $0x9,%rdx
    b311:	48 31 d0             	xor    %rdx,%rax
    b314:	0f b6 d0             	movzbl %al,%edx
    b317:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b31e:	00 
    b31f:	48 85 c0             	test   %rax,%rax
    b322:	75 29                	jne    b34d <fwp_main_thread+0x20ed>
    b324:	e9 48 ff ff ff       	jmp    b271 <fwp_main_thread+0x2011>
    b329:	90                   	nop
    b32a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b331:	00 00 00 00 
    b335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b33c:	00 00 00 00 
    b340:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b344:	48 85 c0             	test   %rax,%rax
    b347:	0f 84 24 ff ff ff    	je     b271 <fwp_main_thread+0x2011>
    b34d:	48 89 c2             	mov    %rax,%rdx
    b350:	48 3b 18             	cmp    (%rax),%rbx
    b353:	75 eb                	jne    b340 <fwp_main_thread+0x20e0>
    b355:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b359:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b35d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b361:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b368:	0f 85 12 f8 ff ff    	jne    ab80 <fwp_main_thread+0x1920>
    b36e:	48 89 df             	mov    %rbx,%rdi
    b371:	e8 3a a2 ff ff       	call   55b0 <fwp_rc_forget_slot>
    b376:	c6 03 fe             	movb   $0xfe,(%rbx)
    b379:	e9 02 f8 ff ff       	jmp    ab80 <fwp_main_thread+0x1920>
    b37e:	e8 0d a1 ff ff       	call   5490 <fwp_rc_wide_dup>
    b383:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b38a:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b391:	48 c1 e2 10          	shl    $0x10,%rdx
    b395:	e9 19 e9 ff ff       	jmp    9cb3 <fwp_main_thread+0xa53>
    b39a:	48 8d 3d c6 0d 00 00 	lea    0xdc6(%rip),%rdi        # c167 <_IO_stdin_used+0x167>
    b3a1:	e8 4a 90 ff ff       	call   43f0 <fwp_trap>
    b3a6:	48 8d 3d 0b 15 00 00 	lea    0x150b(%rip),%rdi        # c8b8 <_IO_stdin_used+0x8b8>
    b3ad:	e8 3e 90 ff ff       	call   43f0 <fwp_trap>
    b3b2:	48 83 3d fe 53 01 00 	cmpq   $0x0,0x153fe(%rip)        # 207b8 <fwp_root>
    b3b9:	00 
    b3ba:	c7 05 dc 4c 01 00 00 	movl   $0x0,0x14cdc(%rip)        # 200a0 <fwp_exit_code>
    b3c1:	00 00 00 
    b3c4:	0f 84 db e1 ff ff    	je     95a5 <fwp_main_thread+0x345>
    b3ca:	e9 7c 83 ff ff       	jmp    374b <fwp_main_thread.cold>
    b3cf:	90                   	nop
    b3d0:	4c 89 e7             	mov    %r12,%rdi
    b3d3:	e8 d8 a1 ff ff       	call   55b0 <fwp_rc_forget_slot>
    b3d8:	e9 cf e6 ff ff       	jmp    9aac <fwp_main_thread+0x84c>
    b3dd:	4c 89 e7             	mov    %r12,%rdi
    b3e0:	e8 cb a1 ff ff       	call   55b0 <fwp_rc_forget_slot>
    b3e5:	e9 61 e7 ff ff       	jmp    9b4b <fwp_main_thread+0x8eb>
    b3ea:	4c 89 e7             	mov    %r12,%rdi
    b3ed:	e8 be a1 ff ff       	call   55b0 <fwp_rc_forget_slot>
    b3f2:	e9 fc e7 ff ff       	jmp    9bf3 <fwp_main_thread+0x993>
    b3f7:	48 8d 3d ba 15 00 00 	lea    0x15ba(%rip),%rdi        # c9b8 <_IO_stdin_used+0x9b8>
    b3fe:	e8 ed 8f ff ff       	call   43f0 <fwp_trap>
    b403:	e8 f8 82 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    b408:	48 8d 3d 27 0e 00 00 	lea    0xe27(%rip),%rdi        # c236 <_IO_stdin_used+0x236>
    b40f:	e8 dc 8f ff ff       	call   43f0 <fwp_trap>
    b414:	48 8d 3d 01 0e 00 00 	lea    0xe01(%rip),%rdi        # c21c <_IO_stdin_used+0x21c>
    b41b:	e8 d0 8f ff ff       	call   43f0 <fwp_trap>
    b420:	48 8d 3d 69 0d 00 00 	lea    0xd69(%rip),%rdi        # c190 <_IO_stdin_used+0x190>
    b427:	e8 c4 8f ff ff       	call   43f0 <fwp_trap>
    b42c:	48 8d 3d 55 15 00 00 	lea    0x1555(%rip),%rdi        # c988 <_IO_stdin_used+0x988>
    b433:	e8 b8 8f ff ff       	call   43f0 <fwp_trap>
    b438:	48 8d 3d 21 15 00 00 	lea    0x1521(%rip),%rdi        # c960 <_IO_stdin_used+0x960>
    b43f:	e8 ac 8f ff ff       	call   43f0 <fwp_trap>
    b444:	e8 17 80 ff ff       	call   3460 <__stack_chk_fail@plt>
    b449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b450:	48 8d 3d 89 15 00 00 	lea    0x1589(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    b457:	e8 94 8f ff ff       	call   43f0 <fwp_trap>
    b45c:	48 8d 3d 9d 14 00 00 	lea    0x149d(%rip),%rdi        # c900 <_IO_stdin_used+0x900>
    b463:	e8 88 8f ff ff       	call   43f0 <fwp_trap>
    b468:	e8 73 89 ff ff       	call   3de0 <descent_phase_fail>
    b46d:	48 8d 3d d2 0d 00 00 	lea    0xdd2(%rip),%rdi        # c246 <_IO_stdin_used+0x246>
    b474:	e8 77 8f ff ff       	call   43f0 <fwp_trap>
    b479:	e9 cd 82 ff ff       	jmp    374b <fwp_main_thread.cold>
    b47e:	e9 c8 82 ff ff       	jmp    374b <fwp_main_thread.cold>
    b483:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b48a:	00 00 00 
    b48d:	0f 1f 00             	nopl   (%rax)

000000000000b490 <__divmodti4>:
    b490:	f3 0f 1e fa          	endbr64
    b494:	55                   	push   %rbp
    b495:	49 89 f1             	mov    %rsi,%r9
    b498:	49 89 d2             	mov    %rdx,%r10
    b49b:	48 89 fe             	mov    %rdi,%rsi
    b49e:	49 89 cb             	mov    %rcx,%r11
    b4a1:	48 89 e5             	mov    %rsp,%rbp
    b4a4:	41 57                	push   %r15
    b4a6:	41 56                	push   %r14
    b4a8:	41 55                	push   %r13
    b4aa:	41 54                	push   %r12
    b4ac:	53                   	push   %rbx
    b4ad:	4c 89 c3             	mov    %r8,%rbx
    b4b0:	45 31 c0             	xor    %r8d,%r8d
    b4b3:	4d 85 c9             	test   %r9,%r9
    b4b6:	79 12                	jns    b4ca <__divmodti4+0x3a>
    b4b8:	31 ff                	xor    %edi,%edi
    b4ba:	48 f7 de             	neg    %rsi
    b4bd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    b4c4:	4c 19 cf             	sbb    %r9,%rdi
    b4c7:	49 89 f9             	mov    %rdi,%r9
    b4ca:	4c 89 d8             	mov    %r11,%rax
    b4cd:	4d 85 db             	test   %r11,%r11
    b4d0:	0f 88 1a 01 00 00    	js     b5f0 <__divmodti4+0x160>
    b4d6:	4c 89 d9             	mov    %r11,%rcx
    b4d9:	49 89 f3             	mov    %rsi,%r11
    b4dc:	75 62                	jne    b540 <__divmodti4+0xb0>
    b4de:	4d 89 c4             	mov    %r8,%r12
    b4e1:	4d 39 d1             	cmp    %r10,%r9
    b4e4:	0f 83 46 01 00 00    	jae    b630 <__divmodti4+0x1a0>
    b4ea:	4c 89 d8             	mov    %r11,%rax
    b4ed:	4c 89 ca             	mov    %r9,%rdx
    b4f0:	49 f7 f2             	div    %r10
    b4f3:	49 89 c3             	mov    %rax,%r11
    b4f6:	31 c0                	xor    %eax,%eax
    b4f8:	48 89 d6             	mov    %rdx,%rsi
    b4fb:	31 ff                	xor    %edi,%edi
    b4fd:	4c 89 d9             	mov    %r11,%rcx
    b500:	48 89 c2             	mov    %rax,%rdx
    b503:	48 89 c8             	mov    %rcx,%rax
    b506:	4d 85 e4             	test   %r12,%r12
    b509:	74 0a                	je     b515 <__divmodti4+0x85>
    b50b:	48 f7 d8             	neg    %rax
    b50e:	48 83 d2 00          	adc    $0x0,%rdx
    b512:	48 f7 da             	neg    %rdx
    b515:	4d 85 c0             	test   %r8,%r8
    b518:	74 0a                	je     b524 <__divmodti4+0x94>
    b51a:	48 f7 de             	neg    %rsi
    b51d:	48 83 d7 00          	adc    $0x0,%rdi
    b521:	48 f7 df             	neg    %rdi
    b524:	48 89 33             	mov    %rsi,(%rbx)
    b527:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    b52b:	5b                   	pop    %rbx
    b52c:	41 5c                	pop    %r12
    b52e:	41 5d                	pop    %r13
    b530:	41 5e                	pop    %r14
    b532:	41 5f                	pop    %r15
    b534:	5d                   	pop    %rbp
    b535:	c3                   	ret
    b536:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b53d:	00 00 00 
    b540:	4d 89 c4             	mov    %r8,%r12
    b543:	49 39 c1             	cmp    %rax,%r9
    b546:	0f 82 ce 00 00 00    	jb     b61a <__divmodti4+0x18a>
    b54c:	31 ff                	xor    %edi,%edi
    b54e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    b553:	48 63 c7             	movslq %edi,%rax
    b556:	be 40 00 00 00       	mov    $0x40,%esi
    b55b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    b560:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    b565:	48 29 c6             	sub    %rax,%rsi
    b568:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    b56d:	48 09 c8             	or     %rcx,%rax
    b570:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    b575:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    b57a:	49 89 c6             	mov    %rax,%r14
    b57d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    b581:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    b586:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    b58b:	49 09 c1             	or     %rax,%r9
    b58e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    b592:	4c 89 c8             	mov    %r9,%rax
    b595:	49 f7 f6             	div    %r14
    b598:	48 89 d1             	mov    %rdx,%rcx
    b59b:	49 89 c3             	mov    %rax,%r11
    b59e:	49 89 c1             	mov    %rax,%r9
    b5a1:	49 f7 e2             	mul    %r10
    b5a4:	49 89 c6             	mov    %rax,%r14
    b5a7:	49 89 d2             	mov    %rdx,%r10
    b5aa:	48 39 d1             	cmp    %rdx,%rcx
    b5ad:	72 07                	jb     b5b6 <__divmodti4+0x126>
    b5af:	75 17                	jne    b5c8 <__divmodti4+0x138>
    b5b1:	49 39 c7             	cmp    %rax,%r15
    b5b4:	73 12                	jae    b5c8 <__divmodti4+0x138>
    b5b6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    b5ba:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    b5be:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    b5c2:	49 89 d2             	mov    %rdx,%r10
    b5c5:	49 89 c6             	mov    %rax,%r14
    b5c8:	4c 89 f8             	mov    %r15,%rax
    b5cb:	4c 29 f0             	sub    %r14,%rax
    b5ce:	4c 19 d1             	sbb    %r10,%rcx
    b5d1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    b5d6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    b5db:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    b5e0:	48 09 c6             	or     %rax,%rsi
    b5e3:	48 89 cf             	mov    %rcx,%rdi
    b5e6:	31 c0                	xor    %eax,%eax
    b5e8:	4c 89 c9             	mov    %r9,%rcx
    b5eb:	e9 10 ff ff ff       	jmp    b500 <__divmodti4+0x70>
    b5f0:	4c 89 d0             	mov    %r10,%rax
    b5f3:	4c 89 da             	mov    %r11,%rdx
    b5f6:	4d 89 c4             	mov    %r8,%r12
    b5f9:	49 89 f3             	mov    %rsi,%r11
    b5fc:	48 f7 d8             	neg    %rax
    b5ff:	49 f7 d4             	not    %r12
    b602:	48 83 d2 00          	adc    $0x0,%rdx
    b606:	49 89 c2             	mov    %rax,%r10
    b609:	48 f7 da             	neg    %rdx
    b60c:	48 89 d1             	mov    %rdx,%rcx
    b60f:	0f 84 cc fe ff ff    	je     b4e1 <__divmodti4+0x51>
    b615:	49 39 d1             	cmp    %rdx,%r9
    b618:	73 46                	jae    b660 <__divmodti4+0x1d0>
    b61a:	4c 89 cf             	mov    %r9,%rdi
    b61d:	31 c0                	xor    %eax,%eax
    b61f:	31 c9                	xor    %ecx,%ecx
    b621:	e9 da fe ff ff       	jmp    b500 <__divmodti4+0x70>
    b626:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b62d:	00 00 00 
    b630:	4d 85 d2             	test   %r10,%r10
    b633:	75 0d                	jne    b642 <__divmodti4+0x1b2>
    b635:	b8 01 00 00 00       	mov    $0x1,%eax
    b63a:	31 d2                	xor    %edx,%edx
    b63c:	49 f7 f2             	div    %r10
    b63f:	49 89 c2             	mov    %rax,%r10
    b642:	4c 89 c8             	mov    %r9,%rax
    b645:	31 d2                	xor    %edx,%edx
    b647:	49 f7 f2             	div    %r10
    b64a:	49 89 c1             	mov    %rax,%r9
    b64d:	4c 89 d8             	mov    %r11,%rax
    b650:	49 f7 f2             	div    %r10
    b653:	49 89 c3             	mov    %rax,%r11
    b656:	4c 89 c8             	mov    %r9,%rax
    b659:	e9 9a fe ff ff       	jmp    b4f8 <__divmodti4+0x68>
    b65e:	66 90                	xchg   %ax,%ax
    b660:	45 31 f6             	xor    %r14d,%r14d
    b663:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    b668:	44 89 f7             	mov    %r14d,%edi
    b66b:	45 85 f6             	test   %r14d,%r14d
    b66e:	0f 85 df fe ff ff    	jne    b553 <__divmodti4+0xc3>
    b674:	4c 39 ca             	cmp    %r9,%rdx
    b677:	72 17                	jb     b690 <__divmodti4+0x200>
    b679:	31 c9                	xor    %ecx,%ecx
    b67b:	48 39 c6             	cmp    %rax,%rsi
    b67e:	73 10                	jae    b690 <__divmodti4+0x200>
    b680:	4c 89 cf             	mov    %r9,%rdi
    b683:	31 c0                	xor    %eax,%eax
    b685:	e9 76 fe ff ff       	jmp    b500 <__divmodti4+0x70>
    b68a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b690:	4c 89 de             	mov    %r11,%rsi
    b693:	b9 01 00 00 00       	mov    $0x1,%ecx
    b698:	48 29 c6             	sub    %rax,%rsi
    b69b:	49 19 d1             	sbb    %rdx,%r9
    b69e:	eb e0                	jmp    b680 <__divmodti4+0x1f0>

000000000000b6a0 <atexit>:
    b6a0:	f3 0f 1e fa          	endbr64
    b6a4:	48 8b 15 5d 49 00 00 	mov    0x495d(%rip),%rdx        # 10008 <__dso_handle>
    b6ab:	31 f6                	xor    %esi,%esi
    b6ad:	e9 ae 7f ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b6b4 <_fini>:
    b6b4:	f3 0f 1e fa          	endbr64
    b6b8:	48 83 ec 08          	sub    $0x8,%rsp
    b6bc:	48 83 c4 08          	add    $0x8,%rsp
    b6c0:	c3                   	ret
