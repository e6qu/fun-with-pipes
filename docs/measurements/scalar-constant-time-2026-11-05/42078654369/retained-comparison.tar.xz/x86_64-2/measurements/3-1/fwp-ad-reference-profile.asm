
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-reference-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 cf 00 00 	mov    0xcfd1(%rip),%rax        # ffe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 cd 00 00    	push   0xcdf2(%rip)        # fe18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 cd 00 00    	jmp    *0xcdf4(%rip)        # fe20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 cc 00 00    	jmp    *0xcc66(%rip)        # fff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e ca 00 00    	jmp    *0xca8e(%rip)        # fe28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 ca 00 00    	jmp    *0xca86(%rip)        # fe30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e ca 00 00    	jmp    *0xca7e(%rip)        # fe38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 ca 00 00    	jmp    *0xca76(%rip)        # fe40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e ca 00 00    	jmp    *0xca6e(%rip)        # fe48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # fe50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # fe58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # fe60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # fe68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # fe70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # fe78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # fe80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # fe88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # fe90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # fe98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # fea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # fea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # feb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # feb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # fec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # fec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # fed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # fed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # fee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # fee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # fef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # fef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # ff00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # ff08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # ff10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # ff18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # ff20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # ff28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # ff30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # ff38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ff40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ff48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ff50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ff58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ff60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ff68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ff70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ff78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # ff80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # ff88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # ff90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # ff98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # ffa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e c9 00 00    	jmp    *0xc90e(%rip)        # ffa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 c9 00 00    	jmp    *0xc906(%rip)        # ffb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe c8 00 00    	jmp    *0xc8fe(%rip)        # ffb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 c8 00 00    	jmp    *0xc8f6(%rip)        # ffc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee c8 00 00    	jmp    *0xc8ee(%rip)        # ffc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 89 00 00 	lea    0x89b8(%rip),%r9        # c0cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 89 00 00 	lea    0x89b5(%rip),%r8        # c0d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <fwp_main_thread.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>

0000000000003750 <main.cold>:
    3750:	e8 6b fc ff ff       	call   33c0 <abort@plt>
    3755:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    375c:	00 00 00 
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 ab 00 00 	lea    0xaba1(%rip),%rax        # e320 <fwp_fn_table>
    377f:	48 89 05 12 6d 06 00 	mov    %rax,0x66d12(%rip)        # 6a498 <fwp_fns>
    3786:	48 8b 05 93 c8 00 00 	mov    0xc893(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 0c 6d 06 00 	mov    %rax,0x66d0c(%rip)        # 6a4a0 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e 8b 00 00 	lea    0x8b4e(%rip),%rdi        # c2ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 c8 00 00 	mov    0xc818(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 7f 5e 00 00 	lea    0x5e7f(%rip),%rdx        # 96e0 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 d6 fe ff ff    	jne    3750 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 ba fe ff ff    	jne    3750 <main.cold>
    3896:	48 8b 3d 83 c7 00 00 	mov    0xc783(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 f8 c7 01 00    	mov    0x1c7f8(%rip),%eax        # 200a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe 89 00 00 	lea    0x89fe(%rip),%rdi        # c2f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 56 93 00 00 	lea    0x9356(%rip),%rdi        # cc60 <_IO_stdin_used+0xc60>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 2f fe ff ff    	jne    3750 <main.cold>
    3921:	48 8d 3d 10 93 00 00 	lea    0x9310(%rip),%rdi        # cc38 <_IO_stdin_used+0xc38>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d d4 92 00 00 	lea    0x92d4(%rip),%rdi        # cc08 <_IO_stdin_used+0xc08>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d a0 92 00 00 	lea    0x92a0(%rip),%rdi        # cbe0 <_IO_stdin_used+0xbe0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b c6 00 00    	call   *0xc65b(%rip)        # ffd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 c6 00 00 	lea    0xc699(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 c6 00 00 	lea    0xc692(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e c6 00 00 	mov    0xc63e(%rip),%rax        # ffd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 c6 00 00 	lea    0xc669(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 c6 00 00 	lea    0xc662(%rip),%rsi        # 10020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d c6 00 00 	mov    0xc60d(%rip),%rax        # ffe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d c6 00 00 00 	cmpb   $0x0,0xc64d(%rip)        # 10048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea c5 00 00 	cmpq   $0x0,0xc5ea(%rip)        # fff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 c5 00 00 	mov    0xc5f6(%rip),%rdi        # 10008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 c6 00 00 01 	movb   $0x1,0xc625(%rip)        # 10048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 b7 c5 04 00 	lea    0x4c5b7(%rip),%r8        # 501c0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 5b c5 04 00 	lea    0x4c55b(%rip),%rcx        # 50180 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 2f c5 04 00 	lea    0x4c52f(%rip),%rcx        # 50160 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 61 c5 04 00 	lea    0x4c561(%rip),%rcx        # 501a0 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 70 c5 04 	movdqa 0x4c570(%rip),%xmm0        # 501d0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 58 c5 04 	paddq  0x4c558(%rip),%xmm0        # 501c0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 bf c4 04 00 	cmp    %rax,0x4c4bf(%rip)        # 50140 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 b5 c4 04 	movq   %xmm0,0x4c4b5(%rip)        # 50140 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 5e c4 01 00 	add    0x1c45e(%rip),%rdx        # 20110 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 4c c4 01 00 	add    0x1c44c(%rip),%rax        # 20110 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args173>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 99 67 06 00 	mov    0x66799(%rip),%rdi        # 6a4a0 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 04 c3 00 00 	mov    0xc304(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d f1 c2 00 00 	mov    0xc2f1(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 d1 4a 06 00 	mov    0x64ad1(%rip),%rax        # 68820 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 19 44 06 00 	mov    0x64419(%rip),%rax        # 681e8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 05 44 06 00 	sub    0x64405(%rip),%rax        # 681e0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 2d 8f 00 00 	lea    0x8f2d(%rip),%rsi        # cd40 <msg.8>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 81 00 00 	lea    0x81c5(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d f2 c1 00 00 	mov    0xc1f2(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 ab 5d 06 00 	mov    0x65dab(%rip),%rax        # 69c30 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 a4 5d 06 00 	lea    0x65da4(%rip),%r8        # 69c30 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 85 5d 06 00 	mov    0x65d85(%rip),%rbx        # 69c18 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 95 5d 06 00 	mov    0x65d95(%rip),%rcx        # 69c38 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 31 5d 06 00 	mov    0x65d31(%rip),%rdi        # 69c20 <fwp_heap+0x13e0>
    3eef:	48 29 35 7a 5d 06 00 	sub    %rsi,0x65d7a(%rip)        # 69c70 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 0a 5d 06 00 	mov    0x65d0a(%rip),%rax        # 69c10 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d c0 5c 06 00 	add    0x65cc0(%rip),%rdi        # 69bf0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ce 5c 06 00 	mov    0x65cce(%rip),%rsi        # 69c20 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 dc 5c 06 00 	mov    0x65cdc(%rip),%rax        # 69c38 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 8b 5c 06 00 	mov    %r12,0x65c8b(%rip)        # 69c20 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 79 5c 06 00 	mov    %rbp,0x65c79(%rip)        # 69c18 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 5e 5c 06 00 	cmp    %rdi,0x65c5e(%rip)        # 69c08 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 55 5c 06 00 	mov    %rdi,0x65c55(%rip)        # 69c08 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 99 5c 06 00 	sub    %rdi,0x65c99(%rip)        # 69c70 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 41 5c 06 00 	mov    0x65c41(%rip),%rax        # 69c28 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 3a 5c 06 00 	lea    0x65c3a(%rip),%r8        # 69c28 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ff 86 00 00 	lea    0x86ff(%rip),%rdx        # c708 <_IO_stdin_used+0x708>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 22 c0 00 00 	mov    0xc022(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 7d bf 00 00 	mov    0xbf7d(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 7f 00 00 	lea    0x7f34(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d e9 46 06 00 	cmp    0x646e9(%rip),%rdi        # 68820 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 af 46 06 00 	mov    0x646af(%rip),%rax        # 68800 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 8d 46 06 00 	mov    %rdi,0x6468d(%rip)        # 68800 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 69 46 06 00 	mov    %rdi,0x64669(%rip)        # 68808 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 19 80 00 00 	lea    0x8019(%rip),%rsi        # c1fa <_IO_stdin_used+0x1fa>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 7e 00 00 	lea    0x7e27(%rip),%rsi        # c01c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 96 bf 04 	movdqa 0x4bf96(%rip),%xmm0        # 501d0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 7e bf 04 	paddq  0x4bf7e(%rip),%xmm0        # 501c0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 a4 be 01 00 	mov    0x1bea4(%rip),%r8        # 20118 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d be be 04 00 	mov    0x4bebe(%rip),%rcx        # 50140 <ad_raw_total_peak>
    4282:	48 8b 3d b7 bd 00 00 	mov    0xbdb7(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 c5 84 00 00 	lea    0x84c5(%rip),%rdx        # c758 <_IO_stdin_used+0x758>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d 01 bf 04 00 	lea    0x4bf01(%rip),%r15        # 501a0 <ad_raw_peak>
    429f:	4c 8d 35 ba be 04 00 	lea    0x4beba(%rip),%r14        # 50160 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 7d 00 00 	lea    0x7d79(%rip),%rax        # c02b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 b9 00 	movq   0xb956(%rip),%xmm0        # fc10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d bf be 04 00 	lea    0x4bebf(%rip),%r13        # 50180 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f 7d 00 00 	lea    0x7d6f(%rip),%rax        # c03c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 b9 00 	movq   0xb936(%rip),%xmm0        # fc18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 33 bd 00 00 	mov    0xbd33(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c 7d 00 00 	lea    0x7d0c(%rip),%rcx        # c020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 9d 84 00 00 	lea    0x849d(%rip),%rdx        # c7b8 <_IO_stdin_used+0x7b8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 04 bd 00 00 	mov    0xbd04(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 7c 00 00 	lea    0x7cf8(%rip),%rdi        # c045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d c6 bd 01 00 	cmpq   $0x0,0x1bdc6(%rip)        # 20120 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 dd bd 01 00 	mov    0x1bddd(%rip),%r8        # 20140 <ad_raw_checkpoints>
    4363:	4c 8b 0d de bd 01 00 	mov    0x1bdde(%rip),%r9        # 20148 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d cf bd 01 00 	lea    0x1bdcf(%rip),%rbx        # 20140 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 7c 00 00 	lea    0x7cf4(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 d1 bd 01 00 	mov    0x1bdd1(%rip),%rax        # 20150 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a 7c 00 00 	lea    0x7c9a(%rip),%r12        # c020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d 89 bc 00 00 	mov    0xbc89(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 39 84 00 00 	lea    0x8439(%rip),%rdx        # c7f8 <_IO_stdin_used+0x7f8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 53 bd 01 00 	cmp    0x1bd53(%rip),%rbp        # 20120 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 58 bc 00 00 	mov    0xbc58(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b 7c 00 00 	lea    0x7c5b(%rip),%rdi        # c059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 23 bc 00 00 	mov    0xbc23(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 94 83 00 00 	lea    0x8394(%rip),%rdx        # c7b8 <_IO_stdin_used+0x7b8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 7c 00 00 	lea    0x7c40(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d ea 82 00 00 	lea    0x82ea(%rip),%rdi        # c730 <_IO_stdin_used+0x730>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d c8 bb 00 00 	mov    0xbbc8(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df 7b 00 00 	lea    0x7bdf(%rip),%rdx        # c05e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d b0 bb 00 00 	mov    0xbbb0(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d c1 ba 00 00 	mov    0xbac1(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 7a 00 00 	lea    0x7a78(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 7a 00 00 	lea    0x7ac0(%rip),%rdi        # c06d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 7a 00 00 	lea    0x7a48(%rip),%rdi        # c087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d e8 81 00 00 	lea    0x81e8(%rip),%rdi        # c838 <_IO_stdin_used+0x838>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 20 87 00 	movdqa 0x8720(%rip),%xmm0        # cd90 <msg.8+0x50>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 ca 5d 06 00 	add    0x65dca(%rip),%rax        # 6a498 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 3c 81 00 00 	lea    0x813c(%rip),%rdi        # c860 <_IO_stdin_used+0x860>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 c5 b9 01 00 	cmp    %rax,0x1b9c5(%rip)        # 20108 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 c0 b9 01 00 	add    0x1b9c0(%rip),%rax        # 20110 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 25 81 00 00 	lea    0x8125(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 79 00 00 	lea    0x7920(%rip),%r8        # c0a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 77 00 00 	lea    0x7775(%rip),%r8        # c0b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 76 00 00 	lea    0x7612(%rip),%r8        # c0a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea 73 00 00 	lea    0x73ea(%rip),%rdi        # c0b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 54 75 00 00 	lea    0x7554(%rip),%rsi        # c242 <_IO_stdin_used+0x242>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d a5 4e 06 00 	mov    0x64ea5(%rip),%r9        # 69c08 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 fe 4e 06 00 	mov    0x64efe(%rip),%r8        # 69c68 <fwp_heap+0x1428>
    4d6a:	48 8d 15 6f 7b 00 00 	lea    0x7b6f(%rip),%rdx        # c8e0 <_IO_stdin_used+0x8e0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d e6 4e 06 00 	mov    0x64ee6(%rip),%rcx        # 69c60 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d f4 4e 06 	movsd  0x64ef4(%rip),%xmm1        # 69c80 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 e4 4e 06 	movsd  0x64ee4(%rip),%xmm0        # 69c78 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d a5 b2 00 00 	mov    0xb2a5(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 c8 7f 00 	movdqa 0x7fc8(%rip),%xmm0        # cda0 <msg.8+0x60>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 9f 49 06 00 	lea    0x6499f(%rip),%rax        # 69780 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 f1 7f 00 	movdqa 0x7ff1(%rip),%xmm2        # cde0 <msg.8+0xa0>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 45 49 06 00 	movaps %xmm0,0x64945(%rip)        # 69740 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 ad 7f 00 	movdqa 0x7fad(%rip),%xmm0        # cdb0 <msg.8+0x70>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 d3 4d 06 00 01 	movl   $0x1,0x64dd3(%rip)        # 69be4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 33 49 06 00 	movaps %xmm0,0x64933(%rip)        # 69750 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 9b 7f 00 	movdqa 0x7f9b(%rip),%xmm0        # cdc0 <msg.8+0x80>
    4e24:	00 
    4e25:	0f 29 05 34 49 06 00 	movaps %xmm0,0x64934(%rip)        # 69760 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 9c 7f 00 	movdqa 0x7f9c(%rip),%xmm0        # cdd0 <msg.8+0x90>
    4e33:	00 
    4e34:	0f 29 05 35 49 06 00 	movaps %xmm0,0x64935(%rip)        # 69770 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 b5 39 06 00 	lea    0x639b5(%rip),%r8        # 68840 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 d0 4c 06 00 	mov    %rax,0x64cd0(%rip)        # 69bf8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 ae 4c 06 00 	mov    %r12,0x64cae(%rip)        # 69c00 <fwp_heap+0x13c0>
    4f52:	48 89 05 97 4c 06 00 	mov    %rax,0x64c97(%rip)        # 69bf0 <fwp_heap+0x13b0>
    4f59:	48 89 1d b0 4c 06 00 	mov    %rbx,0x64cb0(%rip)        # 69c10 <fwp_heap+0x13d0>
    4f60:	48 89 35 d9 4c 06 00 	mov    %rsi,0x64cd9(%rip)        # 69c40 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 71 00 00 	lea    0x7174(%rip),%rdi        # c0ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 b8 4c 06 00 	mov    %rax,0x64cb8(%rip)        # 69c38 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 3c 4c 06 00    	mov    %eax,0x64c3c(%rip)        # 69be8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <caf75>:
    4fc0:	8b 15 b2 b0 00 00    	mov    0xb0b2(%rip),%edx        # 10078 <st.4>
    4fc6:	85 d2                	test   %edx,%edx
    4fc8:	74 0e                	je     4fd8 <caf75+0x18>
    4fca:	48 8b 05 9f b0 00 00 	mov    0xb09f(%rip),%rax        # 10070 <v.3>
    4fd1:	c3                   	ret
    4fd2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4fd8:	8b 05 8a b0 00 00    	mov    0xb08a(%rip),%eax        # 10068 <st.2>
    4fde:	85 c0                	test   %eax,%eax
    4fe0:	74 1e                	je     5000 <caf75+0x40>
    4fe2:	48 8b 05 77 b0 00 00 	mov    0xb077(%rip),%rax        # 10060 <v.1>
    4fe9:	48 89 05 80 b0 00 00 	mov    %rax,0xb080(%rip)        # 10070 <v.3>
    4ff0:	c7 05 7e b0 00 00 01 	movl   $0x1,0xb07e(%rip)        # 10078 <st.4>
    4ff7:	00 00 00 
    4ffa:	c3                   	ret
    4ffb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5000:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    5007:	00 f0 3f 
    500a:	c7 05 54 b0 00 00 01 	movl   $0x1,0xb054(%rip)        # 10068 <st.2>
    5011:	00 00 00 
    5014:	48 89 05 45 b0 00 00 	mov    %rax,0xb045(%rip)        # 10060 <v.1>
    501b:	eb cc                	jmp    4fe9 <caf75+0x29>
    501d:	0f 1f 00             	nopl   (%rax)

0000000000005020 <fwp_wake_io>:
    5020:	48 8b 07             	mov    (%rdi),%rax
    5023:	48 85 c0             	test   %rax,%rax
    5026:	0f 84 f4 00 00 00    	je     5120 <fwp_wake_io+0x100>
    502c:	53                   	push   %rbx
    502d:	4c 8b 05 cc 37 06 00 	mov    0x637cc(%rip),%r8        # 68800 <fwp_ready_tail>
    5034:	49 89 f9             	mov    %rdi,%r9
    5037:	48 89 c2             	mov    %rax,%rdx
    503a:	45 31 db             	xor    %r11d,%r11d
    503d:	45 31 d2             	xor    %r10d,%r10d
    5040:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5044:	eb 71                	jmp    50b7 <fwp_wake_io+0x97>
    5046:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    504d:	00 00 00 
    5050:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    5057:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    505e:	48 85 c9             	test   %rcx,%rcx
    5061:	74 07                	je     506a <fwp_wake_io+0x4a>
    5063:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    506a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5071:	00 00 00 00 
    5075:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    507c:	49 8b 01             	mov    (%r9),%rax
    507f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5083:	75 2a                	jne    50af <fwp_wake_io+0x8f>
    5085:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5089:	75 24                	jne    50af <fwp_wake_io+0x8f>
    508b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    508f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5096:	00 00 00 00 
    509a:	4d 85 c0             	test   %r8,%r8
    509d:	74 51                	je     50f0 <fwp_wake_io+0xd0>
    509f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    50a6:	49 89 d0             	mov    %rdx,%r8
    50a9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    50af:	48 89 c2             	mov    %rax,%rdx
    50b2:	48 85 c0             	test   %rax,%rax
    50b5:	74 49                	je     5100 <fwp_wake_io+0xe0>
    50b7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    50be:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    50c2:	48 85 ff             	test   %rdi,%rdi
    50c5:	74 b8                	je     507f <fwp_wake_io+0x5f>
    50c7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    50ce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    50d5:	48 85 f6             	test   %rsi,%rsi
    50d8:	0f 85 72 ff ff ff    	jne    5050 <fwp_wake_io+0x30>
    50de:	48 89 0f             	mov    %rcx,(%rdi)
    50e1:	e9 78 ff ff ff       	jmp    505e <fwp_wake_io+0x3e>
    50e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    50ed:	00 00 00 
    50f0:	48 89 d3             	mov    %rdx,%rbx
    50f3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    50f9:	eb ab                	jmp    50a6 <fwp_wake_io+0x86>
    50fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5100:	45 84 db             	test   %r11b,%r11b
    5103:	74 07                	je     510c <fwp_wake_io+0xec>
    5105:	48 89 1d fc 36 06 00 	mov    %rbx,0x636fc(%rip)        # 68808 <fwp_ready_head>
    510c:	45 84 d2             	test   %r10b,%r10b
    510f:	74 07                	je     5118 <fwp_wake_io+0xf8>
    5111:	4c 89 05 e8 36 06 00 	mov    %r8,0x636e8(%rip)        # 68800 <fwp_ready_tail>
    5118:	5b                   	pop    %rbx
    5119:	c3                   	ret
    511a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5120:	c3                   	ret
    5121:	0f 1f 40 00          	nopl   0x0(%rax)
    5125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    512c:	00 00 00 00 

0000000000005130 <ad_raw_free.part.0>:
    5130:	48 8d 0d a9 b0 04 00 	lea    0x4b0a9(%rip),%rcx        # 501e0 <ad_raw_blocks>
    5137:	31 c0                	xor    %eax,%eax
    5139:	48 89 ca             	mov    %rcx,%rdx
    513c:	eb 12                	jmp    5150 <ad_raw_free.part.0+0x20>
    513e:	66 90                	xchg   %ax,%ax
    5140:	48 83 c0 01          	add    $0x1,%rax
    5144:	48 83 c2 18          	add    $0x18,%rdx
    5148:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    514e:	74 40                	je     5190 <ad_raw_free.part.0+0x60>
    5150:	48 3b 3a             	cmp    (%rdx),%rdi
    5153:	75 eb                	jne    5140 <ad_raw_free.part.0+0x10>
    5155:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5159:	66 0f ef c0          	pxor   %xmm0,%xmm0
    515d:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5161:	48 8d 0d 58 b0 04 00 	lea    0x4b058(%rip),%rcx        # 501c0 <ad_raw_live>
    5168:	8b 70 10             	mov    0x10(%rax),%esi
    516b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5172:	00 
    5173:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5177:	48 2b 50 08          	sub    0x8(%rax),%rdx
    517b:	0f 11 00             	movups %xmm0,(%rax)
    517e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5182:	e9 29 e2 ff ff       	jmp    33b0 <free@plt>
    5187:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    518e:	00 00 
    5190:	48 83 ec 08          	sub    $0x8,%rsp
    5194:	48 8d 3d 62 6f 00 00 	lea    0x6f62(%rip),%rdi        # c0fd <_IO_stdin_used+0xfd>
    519b:	e8 60 ee ff ff       	call   4000 <ad_raw_fail>

00000000000051a0 <fwp_tape_buffers_dispose>:
    51a0:	53                   	push   %rbx
    51a1:	48 89 fb             	mov    %rdi,%rbx
    51a4:	48 8b 3f             	mov    (%rdi),%rdi
    51a7:	48 85 ff             	test   %rdi,%rdi
    51aa:	74 05                	je     51b1 <fwp_tape_buffers_dispose+0x11>
    51ac:	e8 7f ff ff ff       	call   5130 <ad_raw_free.part.0>
    51b1:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    51b5:	48 85 ff             	test   %rdi,%rdi
    51b8:	74 05                	je     51bf <fwp_tape_buffers_dispose+0x1f>
    51ba:	e8 71 ff ff ff       	call   5130 <ad_raw_free.part.0>
    51bf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    51c3:	48 85 ff             	test   %rdi,%rdi
    51c6:	74 05                	je     51cd <fwp_tape_buffers_dispose+0x2d>
    51c8:	e8 63 ff ff ff       	call   5130 <ad_raw_free.part.0>
    51cd:	66 0f ef c0          	pxor   %xmm0,%xmm0
    51d1:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    51d8:	00 
    51d9:	0f 11 03             	movups %xmm0,(%rbx)
    51dc:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    51e0:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    51e4:	5b                   	pop    %rbx
    51e5:	c3                   	ret
    51e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51ed:	00 00 00 

00000000000051f0 <ad_raw_realloc>:
    51f0:	41 55                	push   %r13
    51f2:	41 54                	push   %r12
    51f4:	55                   	push   %rbp
    51f5:	53                   	push   %rbx
    51f6:	48 83 ec 08          	sub    $0x8,%rsp
    51fa:	48 85 f6             	test   %rsi,%rsi
    51fd:	0f 84 a6 00 00 00    	je     52a9 <ad_raw_realloc+0xb9>
    5203:	4c 8d 25 d6 af 04 00 	lea    0x4afd6(%rip),%r12        # 501e0 <ad_raw_blocks>
    520a:	48 89 f5             	mov    %rsi,%rbp
    520d:	41 89 d5             	mov    %edx,%r13d
    5210:	31 db                	xor    %ebx,%ebx
    5212:	4c 89 e0             	mov    %r12,%rax
    5215:	eb 1a                	jmp    5231 <ad_raw_realloc+0x41>
    5217:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    521e:	00 00 
    5220:	48 83 c3 01          	add    $0x1,%rbx
    5224:	48 83 c0 18          	add    $0x18,%rax
    5228:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    522f:	74 4f                	je     5280 <ad_raw_realloc+0x90>
    5231:	48 3b 38             	cmp    (%rax),%rdi
    5234:	75 ea                	jne    5220 <ad_raw_realloc+0x30>
    5236:	48 85 ff             	test   %rdi,%rdi
    5239:	74 0b                	je     5246 <ad_raw_realloc+0x56>
    523b:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    523f:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    5244:	75 57                	jne    529d <ad_raw_realloc+0xad>
    5246:	48 89 ee             	mov    %rbp,%rsi
    5249:	e8 62 e3 ff ff       	call   35b0 <realloc@plt>
    524e:	49 89 c2             	mov    %rax,%r10
    5251:	48 85 c0             	test   %rax,%rax
    5254:	74 16                	je     526c <ad_raw_realloc+0x7c>
    5256:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    525a:	44 89 e9             	mov    %r13d,%ecx
    525d:	48 89 ea             	mov    %rbp,%rdx
    5260:	4c 89 d6             	mov    %r10,%rsi
    5263:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5267:	e8 94 e9 ff ff       	call   3c00 <ad_raw_record>
    526c:	48 83 c4 08          	add    $0x8,%rsp
    5270:	4c 89 d0             	mov    %r10,%rax
    5273:	5b                   	pop    %rbx
    5274:	5d                   	pop    %rbp
    5275:	41 5c                	pop    %r12
    5277:	41 5d                	pop    %r13
    5279:	c3                   	ret
    527a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5280:	48 85 ff             	test   %rdi,%rdi
    5283:	48 8d 05 88 6e 00 00 	lea    0x6e88(%rip),%rax        # c112 <_IO_stdin_used+0x112>
    528a:	48 8d 15 6c 6e 00 00 	lea    0x6e6c(%rip),%rdx        # c0fd <_IO_stdin_used+0xfd>
    5291:	48 0f 45 c2          	cmovne %rdx,%rax
    5295:	48 89 c7             	mov    %rax,%rdi
    5298:	e8 63 ed ff ff       	call   4000 <ad_raw_fail>
    529d:	48 8d 3d a4 6e 00 00 	lea    0x6ea4(%rip),%rdi        # c148 <_IO_stdin_used+0x148>
    52a4:	e8 57 ed ff ff       	call   4000 <ad_raw_fail>
    52a9:	48 8d 3d 7d 6e 00 00 	lea    0x6e7d(%rip),%rdi        # c12d <_IO_stdin_used+0x12d>
    52b0:	e8 4b ed ff ff       	call   4000 <ad_raw_fail>
    52b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    52bc:	00 00 00 00 

00000000000052c0 <fwp_tape_buffers_release>:
    52c0:	f3 0f 1e fa          	endbr64
    52c4:	53                   	push   %rbx
    52c5:	48 89 fb             	mov    %rdi,%rbx
    52c8:	48 83 ec 10          	sub    $0x10,%rsp
    52cc:	48 8b 47 28          	mov    0x28(%rdi),%rax
    52d0:	48 85 c0             	test   %rax,%rax
    52d3:	0f 88 d7 00 00 00    	js     53b0 <fwp_tape_buffers_release+0xf0>
    52d9:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    52dd:	48 85 d2             	test   %rdx,%rdx
    52e0:	0f 88 ca 00 00 00    	js     53b0 <fwp_tape_buffers_release+0xf0>
    52e6:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    52ec:	0f 87 be 00 00 00    	ja     53b0 <fwp_tape_buffers_release+0xf0>
    52f2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    52f6:	b8 00 00 08 00       	mov    $0x80000,%eax
    52fb:	48 c1 e1 03          	shl    $0x3,%rcx
    52ff:	48 29 c8             	sub    %rcx,%rax
    5302:	48 c1 e8 03          	shr    $0x3,%rax
    5306:	48 39 d0             	cmp    %rdx,%rax
    5309:	0f 82 a1 00 00 00    	jb     53b0 <fwp_tape_buffers_release+0xf0>
    530f:	48 8d 3d 4a 6e 00 00 	lea    0x6e4a(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    5316:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    531b:	48 89 14 24          	mov    %rdx,(%rsp)
    531f:	e8 6c e0 ff ff       	call   3390 <getenv@plt>
    5324:	48 8b 14 24          	mov    (%rsp),%rdx
    5328:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    532d:	48 85 c0             	test   %rax,%rax
    5330:	74 09                	je     533b <fwp_tape_buffers_release+0x7b>
    5332:	80 38 30             	cmpb   $0x30,(%rax)
    5335:	0f 84 05 01 00 00    	je     5440 <fwp_tape_buffers_release+0x180>
    533b:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    533f:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    5343:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    5349:	77 71                	ja     53bc <fwp_tape_buffers_release+0xfc>
    534b:	48 8d 3d 6e ad 01 00 	lea    0x1ad6e(%rip),%rdi        # 200c0 <fwp_tape_workspace>
    5352:	48 89 34 24          	mov    %rsi,(%rsp)
    5356:	e8 45 fe ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    535b:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    535f:	48 8b 34 24          	mov    (%rsp),%rsi
    5363:	0f 29 05 56 ad 01 00 	movaps %xmm0,0x1ad56(%rip)        # 200c0 <fwp_tape_workspace>
    536a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    536f:	48 89 35 32 ad 01 00 	mov    %rsi,0x1ad32(%rip)        # 200a8 <fwp_tape_cached_bytes>
    5376:	0f 29 05 53 ad 01 00 	movaps %xmm0,0x1ad53(%rip)        # 200d0 <fwp_tape_workspace+0x10>
    537d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5382:	0f 29 05 57 ad 01 00 	movaps %xmm0,0x1ad57(%rip)        # 200e0 <fwp_tape_workspace+0x20>
    5389:	48 8b 43 30          	mov    0x30(%rbx),%rax
    538d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5391:	48 89 05 58 ad 01 00 	mov    %rax,0x1ad58(%rip)        # 200f0 <fwp_tape_workspace+0x30>
    5398:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    539f:	00 
    53a0:	0f 11 03             	movups %xmm0,(%rbx)
    53a3:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    53a7:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    53ab:	eb 1e                	jmp    53cb <fwp_tape_buffers_release+0x10b>
    53ad:	0f 1f 00             	nopl   (%rax)
    53b0:	48 8d 3d a9 6d 00 00 	lea    0x6da9(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    53b7:	e8 d4 df ff ff       	call   3390 <getenv@plt>
    53bc:	48 89 df             	mov    %rbx,%rdi
    53bf:	e8 dc fd ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    53c4:	48 8b 35 dd ac 01 00 	mov    0x1acdd(%rip),%rsi        # 200a8 <fwp_tape_cached_bytes>
    53cb:	48 6b 15 2d ad 01 00 	imul   $0x68,0x1ad2d(%rip),%rdx        # 20100 <fwp_tapes_cap>
    53d2:	68 
    53d3:	48 3b 15 e6 ad 04 00 	cmp    0x4ade6(%rip),%rdx        # 501c0 <ad_raw_live>
    53da:	75 73                	jne    544f <fwp_tape_buffers_release+0x18f>
    53dc:	48 8b 05 e5 ad 04 00 	mov    0x4ade5(%rip),%rax        # 501c8 <ad_raw_live+0x8>
    53e3:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    53e7:	48 01 d0             	add    %rdx,%rax
    53ea:	48 03 05 df ad 04 00 	add    0x4addf(%rip),%rax        # 501d0 <ad_raw_live+0x10>
    53f1:	48 03 05 e0 ad 04 00 	add    0x4ade0(%rip),%rax        # 501d8 <ad_raw_live+0x18>
    53f8:	48 39 c8             	cmp    %rcx,%rax
    53fb:	72 52                	jb     544f <fwp_tape_buffers_release+0x18f>
    53fd:	48 8b 0d 1c ad 01 00 	mov    0x1ad1c(%rip),%rcx        # 20120 <ad_raw_checkpoint_count>
    5404:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    540b:	74 4e                	je     545b <fwp_tape_buffers_release+0x19b>
    540d:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    5411:	48 29 d0             	sub    %rdx,%rax
    5414:	48 89 3d 05 ad 01 00 	mov    %rdi,0x1ad05(%rip)        # 20120 <ad_raw_checkpoint_count>
    541b:	48 29 f0             	sub    %rsi,%rax
    541e:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    5422:	48 8d 0d 17 ad 01 00 	lea    0x1ad17(%rip),%rcx        # 20140 <ad_raw_checkpoints>
    5429:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    542d:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    5432:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    5437:	48 83 c4 10          	add    $0x10,%rsp
    543b:	5b                   	pop    %rbx
    543c:	c3                   	ret
    543d:	0f 1f 00             	nopl   (%rax)
    5440:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    5444:	0f 84 72 ff ff ff    	je     53bc <fwp_tape_buffers_release+0xfc>
    544a:	e9 ec fe ff ff       	jmp    533b <fwp_tape_buffers_release+0x7b>
    544f:	48 8d 3d 12 75 00 00 	lea    0x7512(%rip),%rdi        # c968 <_IO_stdin_used+0x968>
    5456:	e8 a5 eb ff ff       	call   4000 <ad_raw_fail>
    545b:	48 8d 3d 0f 6d 00 00 	lea    0x6d0f(%rip),%rdi        # c171 <_IO_stdin_used+0x171>
    5462:	e8 99 eb ff ff       	call   4000 <ad_raw_fail>
    5467:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    546e:	00 00 

0000000000005470 <fwp_poll_events>:
    5470:	53                   	push   %rbx
    5471:	48 83 ec 20          	sub    $0x20,%rsp
    5475:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    547c:	00 00 
    547e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5483:	31 c0                	xor    %eax,%eax
    5485:	e8 36 f1 ff ff       	call   45c0 <fwp_now_ns>
    548a:	48 8b 1d 67 33 06 00 	mov    0x63367(%rip),%rbx        # 687f8 <fwp_timers>
    5491:	48 85 db             	test   %rbx,%rbx
    5494:	0f 84 e6 00 00 00    	je     5580 <fwp_poll_events+0x110>
    549a:	48 89 c6             	mov    %rax,%rsi
    549d:	48 89 da             	mov    %rbx,%rdx
    54a0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    54a7:	eb 26                	jmp    54cf <fwp_poll_events+0x5f>
    54a9:	90                   	nop
    54aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    54b1:	00 00 00 00 
    54b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    54bc:	00 00 00 00 
    54c0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    54c7:	48 89 c8             	mov    %rcx,%rax
    54ca:	48 85 d2             	test   %rdx,%rdx
    54cd:	74 31                	je     5500 <fwp_poll_events+0x90>
    54cf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    54d3:	48 85 c0             	test   %rax,%rax
    54d6:	78 e8                	js     54c0 <fwp_poll_events+0x50>
    54d8:	48 39 c1             	cmp    %rax,%rcx
    54db:	7c e3                	jl     54c0 <fwp_poll_events+0x50>
    54dd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    54e4:	48 85 d2             	test   %rdx,%rdx
    54e7:	74 1c                	je     5505 <fwp_poll_events+0x95>
    54e9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    54ed:	48 39 c1             	cmp    %rax,%rcx
    54f0:	7c ce                	jl     54c0 <fwp_poll_events+0x50>
    54f2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    54f9:	48 85 d2             	test   %rdx,%rdx
    54fc:	75 d1                	jne    54cf <fwp_poll_events+0x5f>
    54fe:	66 90                	xchg   %ax,%ax
    5500:	48 85 c0             	test   %rax,%rax
    5503:	78 7b                	js     5580 <fwp_poll_events+0x110>
    5505:	48 29 f0             	sub    %rsi,%rax
    5508:	48 89 c1             	mov    %rax,%rcx
    550b:	48 85 c0             	test   %rax,%rax
    550e:	0f 8e 9c 00 00 00    	jle    55b0 <fwp_poll_events+0x140>
    5514:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    551b:	de 1b 43 
    551e:	48 f7 ea             	imul   %rdx
    5521:	48 89 c8             	mov    %rcx,%rax
    5524:	48 c1 f8 3f          	sar    $0x3f,%rax
    5528:	48 c1 fa 12          	sar    $0x12,%rdx
    552c:	48 29 c2             	sub    %rax,%rdx
    552f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5536:	48 39 c1             	cmp    %rax,%rcx
    5539:	0f 95 c0             	setne  %al
    553c:	0f b6 c0             	movzbl %al,%eax
    553f:	48 01 d0             	add    %rdx,%rax
    5542:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5548:	0f 8f 32 01 00 00    	jg     5680 <fwp_poll_events+0x210>
    554e:	48 85 c0             	test   %rax,%rax
    5551:	74 5d                	je     55b0 <fwp_poll_events+0x140>
    5553:	89 c1                	mov    %eax,%ecx
    5555:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    555c:	48 c1 e9 26          	shr    $0x26,%rcx
    5560:	48 63 d1             	movslq %ecx,%rdx
    5563:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5569:	29 c8                	sub    %ecx,%eax
    556b:	48 98                	cltq
    556d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5574:	e9 11 01 00 00       	jmp    568a <fwp_poll_events+0x21a>
    5579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5580:	e8 7b e7 ff ff       	call   3d00 <fwp_flush>
    5585:	ba 2b 00 00 00       	mov    $0x2b,%edx
    558a:	be 01 00 00 00       	mov    $0x1,%esi
    558f:	48 8b 0d aa aa 00 00 	mov    0xaaaa(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    5596:	48 8d 3d fb 73 00 00 	lea    0x73fb(%rip),%rdi        # c998 <_IO_stdin_used+0x998>
    559d:	e8 be e0 ff ff       	call   3660 <fwrite@plt>
    55a2:	bf 65 00 00 00       	mov    $0x65,%edi
    55a7:	e8 a4 e0 ff ff       	call   3650 <exit@plt>
    55ac:	0f 1f 40 00          	nopl   0x0(%rax)
    55b0:	e8 0b f0 ff ff       	call   45c0 <fwp_now_ns>
    55b5:	48 89 c1             	mov    %rax,%rcx
    55b8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    55bc:	eb 44                	jmp    5602 <fwp_poll_events+0x192>
    55be:	66 90                	xchg   %ax,%ax
    55c0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    55c4:	75 33                	jne    55f9 <fwp_poll_events+0x189>
    55c6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    55ca:	75 2d                	jne    55f9 <fwp_poll_events+0x189>
    55cc:	48 8b 05 2d 32 06 00 	mov    0x6322d(%rip),%rax        # 68800 <fwp_ready_tail>
    55d3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    55d7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    55de:	00 00 00 00 
    55e2:	48 85 c0             	test   %rax,%rax
    55e5:	0f 84 05 01 00 00    	je     56f0 <fwp_poll_events+0x280>
    55eb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    55f2:	48 89 15 07 32 06 00 	mov    %rdx,0x63207(%rip)        # 68800 <fwp_ready_tail>
    55f9:	48 85 db             	test   %rbx,%rbx
    55fc:	0f 84 be 00 00 00    	je     56c0 <fwp_poll_events+0x250>
    5602:	48 89 da             	mov    %rbx,%rdx
    5605:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    560c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5610:	7f e7                	jg     55f9 <fwp_poll_events+0x189>
    5612:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5616:	74 2e                	je     5646 <fwp_poll_events+0x1d6>
    5618:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    561f:	48 85 c0             	test   %rax,%rax
    5622:	0f 84 b8 00 00 00    	je     56e0 <fwp_poll_events+0x270>
    5628:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    562f:	48 85 db             	test   %rbx,%rbx
    5632:	74 07                	je     563b <fwp_poll_events+0x1cb>
    5634:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    563b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    563f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5646:	48 8b 42 60          	mov    0x60(%rdx),%rax
    564a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    564e:	48 85 c0             	test   %rax,%rax
    5651:	0f 84 69 ff ff ff    	je     55c0 <fwp_poll_events+0x150>
    5657:	48 39 c8             	cmp    %rcx,%rax
    565a:	0f 8f 60 ff ff ff    	jg     55c0 <fwp_poll_events+0x150>
    5660:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5664:	0f 85 56 ff ff ff    	jne    55c0 <fwp_poll_events+0x150>
    566a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    566e:	75 89                	jne    55f9 <fwp_poll_events+0x189>
    5670:	48 89 d7             	mov    %rdx,%rdi
    5673:	e8 b8 ea ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5678:	e9 43 ff ff ff       	jmp    55c0 <fwp_poll_events+0x150>
    567d:	0f 1f 00             	nopl   (%rax)
    5680:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5685:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    568a:	48 89 e7             	mov    %rsp,%rdi
    568d:	31 f6                	xor    %esi,%esi
    568f:	48 89 14 24          	mov    %rdx,(%rsp)
    5693:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5698:	e8 f3 dd ff ff       	call   3490 <nanosleep@plt>
    569d:	48 8b 1d 54 31 06 00 	mov    0x63154(%rip),%rbx        # 687f8 <fwp_timers>
    56a4:	e8 17 ef ff ff       	call   45c0 <fwp_now_ns>
    56a9:	48 89 c1             	mov    %rax,%rcx
    56ac:	48 85 db             	test   %rbx,%rbx
    56af:	0f 85 03 ff ff ff    	jne    55b8 <fwp_poll_events+0x148>
    56b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56bc:	00 00 00 00 
    56c0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    56c5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    56cc:	00 00 
    56ce:	75 2c                	jne    56fc <fwp_poll_events+0x28c>
    56d0:	48 83 c4 20          	add    $0x20,%rsp
    56d4:	5b                   	pop    %rbx
    56d5:	c3                   	ret
    56d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    56dd:	00 00 00 
    56e0:	48 89 1d 11 31 06 00 	mov    %rbx,0x63111(%rip)        # 687f8 <fwp_timers>
    56e7:	e9 43 ff ff ff       	jmp    562f <fwp_poll_events+0x1bf>
    56ec:	0f 1f 40 00          	nopl   0x0(%rax)
    56f0:	48 89 15 11 31 06 00 	mov    %rdx,0x63111(%rip)        # 68808 <fwp_ready_head>
    56f7:	e9 f6 fe ff ff       	jmp    55f2 <fwp_poll_events+0x182>
    56fc:	e8 4f dd ff ff       	call   3450 <__stack_chk_fail@plt>
    5701:	0f 1f 40 00          	nopl   0x0(%rax)
    5705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    570c:	00 00 00 00 

0000000000005710 <fwp_rc_wide_dup>:
    5710:	48 89 fa             	mov    %rdi,%rdx
    5713:	48 8d 35 26 31 06 00 	lea    0x63126(%rip),%rsi        # 68840 <fwp_heap>
    571a:	48 83 ec 18          	sub    $0x18,%rsp
    571e:	48 89 f9             	mov    %rdi,%rcx
    5721:	48 c1 ea 11          	shr    $0x11,%rdx
    5725:	48 31 fa             	xor    %rdi,%rdx
    5728:	48 89 d0             	mov    %rdx,%rax
    572b:	48 c1 e8 09          	shr    $0x9,%rax
    572f:	48 31 c2             	xor    %rax,%rdx
    5732:	0f b6 d2             	movzbl %dl,%edx
    5735:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    573c:	00 
    573d:	49 8b 00             	mov    (%r8),%rax
    5740:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5747:	00 00 
    5749:	75 21                	jne    576c <fwp_rc_wide_dup+0x5c>
    574b:	e9 98 00 00 00       	jmp    57e8 <fwp_rc_wide_dup+0xd8>
    5750:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5755:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    575c:	00 00 00 00 
    5760:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5764:	48 85 d2             	test   %rdx,%rdx
    5767:	74 2f                	je     5798 <fwp_rc_wide_dup+0x88>
    5769:	48 89 d0             	mov    %rdx,%rax
    576c:	48 3b 08             	cmp    (%rax),%rcx
    576f:	75 ef                	jne    5760 <fwp_rc_wide_dup+0x50>
    5771:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5774:	74 7c                	je     57f2 <fwp_rc_wide_dup+0xe2>
    5776:	48 8b 50 08          	mov    0x8(%rax),%rdx
    577a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    577e:	0f 84 91 00 00 00    	je     5815 <fwp_rc_wide_dup+0x105>
    5784:	48 83 c2 01          	add    $0x1,%rdx
    5788:	48 89 50 08          	mov    %rdx,0x8(%rax)
    578c:	48 83 c4 18          	add    $0x18,%rsp
    5790:	c3                   	ret
    5791:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5798:	4c 8d 40 10          	lea    0x10(%rax),%r8
    579c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    579f:	75 68                	jne    5809 <fwp_rc_wide_dup+0xf9>
    57a1:	bf 18 00 00 00       	mov    $0x18,%edi
    57a6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    57ab:	4c 89 04 24          	mov    %r8,(%rsp)
    57af:	e8 dc dd ff ff       	call   3590 <malloc@plt>
    57b4:	4c 8b 04 24          	mov    (%rsp),%r8
    57b8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    57bd:	48 85 c0             	test   %rax,%rax
    57c0:	74 5f                	je     5821 <fwp_rc_wide_dup+0x111>
    57c2:	48 89 08             	mov    %rcx,(%rax)
    57c5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    57cc:	00 
    57cd:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    57d4:	00 
    57d5:	49 89 00             	mov    %rax,(%r8)
    57d8:	c6 01 ff             	movb   $0xff,(%rcx)
    57db:	48 83 05 a5 4c 06 00 	addq   $0x1,0x64ca5(%rip)        # 6a488 <fwp_heap+0x1c48>
    57e2:	01 
    57e3:	48 83 c4 18          	add    $0x18,%rsp
    57e7:	c3                   	ret
    57e8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    57eb:	75 13                	jne    5800 <fwp_rc_wide_dup+0xf0>
    57ed:	48 85 c0             	test   %rax,%rax
    57f0:	74 af                	je     57a1 <fwp_rc_wide_dup+0x91>
    57f2:	48 8d 3d cf 71 00 00 	lea    0x71cf(%rip),%rdi        # c9c8 <_IO_stdin_used+0x9c8>
    57f9:	e8 52 ec ff ff       	call   4450 <fwp_trap>
    57fe:	66 90                	xchg   %ax,%ax
    5800:	48 85 c0             	test   %rax,%rax
    5803:	0f 85 6d ff ff ff    	jne    5776 <fwp_rc_wide_dup+0x66>
    5809:	48 8d 3d e0 71 00 00 	lea    0x71e0(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    5810:	e8 3b ec ff ff       	call   4450 <fwp_trap>
    5815:	48 8d 3d 72 69 00 00 	lea    0x6972(%rip),%rdi        # c18e <_IO_stdin_used+0x18e>
    581c:	e8 2f ec ff ff       	call   4450 <fwp_trap>
    5821:	e8 0a e6 ff ff       	call   3e30 <fwp_heap_oom>
    5826:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    582d:	00 00 00 

0000000000005830 <fwp_rc_forget_slot>:
    5830:	80 3f ff             	cmpb   $0xff,(%rdi)
    5833:	74 0b                	je     5840 <fwp_rc_forget_slot+0x10>
    5835:	c3                   	ret
    5836:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    583d:	00 00 00 
    5840:	48 89 f8             	mov    %rdi,%rax
    5843:	48 83 ec 08          	sub    $0x8,%rsp
    5847:	48 89 fa             	mov    %rdi,%rdx
    584a:	48 c1 e8 11          	shr    $0x11,%rax
    584e:	48 31 f8             	xor    %rdi,%rax
    5851:	48 89 c1             	mov    %rax,%rcx
    5854:	48 c1 e9 09          	shr    $0x9,%rcx
    5858:	48 31 c8             	xor    %rcx,%rax
    585b:	48 8d 0d de 2f 06 00 	lea    0x62fde(%rip),%rcx        # 68840 <fwp_heap>
    5862:	0f b6 c0             	movzbl %al,%eax
    5865:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    586c:	00 
    586d:	48 85 ff             	test   %rdi,%rdi
    5870:	74 3c                	je     58ae <fwp_rc_forget_slot+0x7e>
    5872:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5879:	00 
    587a:	48 8b 01             	mov    (%rcx),%rax
    587d:	eb 11                	jmp    5890 <fwp_rc_forget_slot+0x60>
    587f:	90                   	nop
    5880:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5884:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5888:	48 85 ff             	test   %rdi,%rdi
    588b:	74 21                	je     58ae <fwp_rc_forget_slot+0x7e>
    588d:	48 89 f8             	mov    %rdi,%rax
    5890:	48 3b 10             	cmp    (%rax),%rdx
    5893:	75 eb                	jne    5880 <fwp_rc_forget_slot+0x50>
    5895:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5899:	48 89 01             	mov    %rax,(%rcx)
    589c:	e8 0f db ff ff       	call   33b0 <free@plt>
    58a1:	48 83 2d df 4b 06 00 	subq   $0x1,0x64bdf(%rip)        # 6a488 <fwp_heap+0x1c48>
    58a8:	01 
    58a9:	48 83 c4 08          	add    $0x8,%rsp
    58ad:	c3                   	ret
    58ae:	48 8d 3d 3b 71 00 00 	lea    0x713b(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    58b5:	e8 96 eb ff ff       	call   4450 <fwp_trap>
    58ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000058c0 <fwp_rc_prepare_chunk>:
    58c0:	48 83 3d c0 4b 06 00 	cmpq   $0x0,0x64bc0(%rip)        # 6a488 <fwp_heap+0x1c48>
    58c7:	00 
    58c8:	41 54                	push   %r12
    58ca:	49 89 f4             	mov    %rsi,%r12
    58cd:	55                   	push   %rbp
    58ce:	48 89 fd             	mov    %rdi,%rbp
    58d1:	53                   	push   %rbx
    58d2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    58d5:	0f 84 7d 00 00 00    	je     5958 <fwp_rc_prepare_chunk+0x98>
    58db:	31 db                	xor    %ebx,%ebx
    58dd:	85 c0                	test   %eax,%eax
    58df:	75 5f                	jne    5940 <fwp_rc_prepare_chunk+0x80>
    58e1:	48 85 f6             	test   %rsi,%rsi
    58e4:	74 7c                	je     5962 <fwp_rc_prepare_chunk+0xa2>
    58e6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    58ea:	e8 c1 da ff ff       	call   33b0 <free@plt>
    58ef:	90                   	nop
    58f0:	be 01 00 00 00       	mov    $0x1,%esi
    58f5:	4c 89 e7             	mov    %r12,%rdi
    58f8:	e8 13 dc ff ff       	call   3510 <calloc@plt>
    58fd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5901:	48 85 c0             	test   %rax,%rax
    5904:	0f 85 87 00 00 00    	jne    5991 <fwp_rc_prepare_chunk+0xd1>
    590a:	e8 21 e5 ff ff       	call   3e30 <fwp_heap_oom>
    590f:	90                   	nop
    5910:	e8 1b ff ff ff       	call   5830 <fwp_rc_forget_slot>
    5915:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5918:	48 83 c3 01          	add    $0x1,%rbx
    591c:	48 39 c3             	cmp    %rax,%rbx
    591f:	73 37                	jae    5958 <fwp_rc_prepare_chunk+0x98>
    5921:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5928:	00 00 
    592a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5931:	00 00 00 00 
    5935:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    593c:	00 00 00 00 
    5940:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5944:	48 01 df             	add    %rbx,%rdi
    5947:	80 3f ff             	cmpb   $0xff,(%rdi)
    594a:	74 c4                	je     5910 <fwp_rc_prepare_chunk+0x50>
    594c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    594f:	48 83 c3 01          	add    $0x1,%rbx
    5953:	48 39 c3             	cmp    %rax,%rbx
    5956:	72 e8                	jb     5940 <fwp_rc_prepare_chunk+0x80>
    5958:	49 39 c4             	cmp    %rax,%r12
    595b:	75 13                	jne    5970 <fwp_rc_prepare_chunk+0xb0>
    595d:	4d 85 e4             	test   %r12,%r12
    5960:	75 46                	jne    59a8 <fwp_rc_prepare_chunk+0xe8>
    5962:	5b                   	pop    %rbx
    5963:	5d                   	pop    %rbp
    5964:	41 5c                	pop    %r12
    5966:	c3                   	ret
    5967:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    596e:	00 00 
    5970:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5974:	48 29 05 15 4b 06 00 	sub    %rax,0x64b15(%rip)        # 6a490 <fwp_heap+0x1c50>
    597b:	e8 30 da ff ff       	call   33b0 <free@plt>
    5980:	4d 85 e4             	test   %r12,%r12
    5983:	0f 85 67 ff ff ff    	jne    58f0 <fwp_rc_prepare_chunk+0x30>
    5989:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5990:	00 
    5991:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5995:	5b                   	pop    %rbx
    5996:	4c 01 25 f3 4a 06 00 	add    %r12,0x64af3(%rip)        # 6a490 <fwp_heap+0x1c50>
    599d:	5d                   	pop    %rbp
    599e:	41 5c                	pop    %r12
    59a0:	c3                   	ret
    59a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    59a8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    59ac:	5b                   	pop    %rbx
    59ad:	4c 89 e2             	mov    %r12,%rdx
    59b0:	31 f6                	xor    %esi,%esi
    59b2:	5d                   	pop    %rbp
    59b3:	41 5c                	pop    %r12
    59b5:	e9 f6 da ff ff       	jmp    34b0 <memset@plt>
    59ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000059c0 <fwp_heap_refill>:
    59c0:	41 56                	push   %r14
    59c2:	41 89 d6             	mov    %edx,%r14d
    59c5:	41 55                	push   %r13
    59c7:	41 89 f5             	mov    %esi,%r13d
    59ca:	41 54                	push   %r12
    59cc:	49 89 fc             	mov    %rdi,%r12
    59cf:	bf 01 00 00 00       	mov    $0x1,%edi
    59d4:	55                   	push   %rbp
    59d5:	53                   	push   %rbx
    59d6:	e8 95 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    59db:	48 89 c3             	mov    %rax,%rbx
    59de:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    59e2:	48 8b 05 4f 42 06 00 	mov    0x6424f(%rip),%rax        # 69c38 <fwp_heap+0x13f8>
    59e9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    59ed:	48 8d 05 4c 2e 06 00 	lea    0x62e4c(%rip),%rax        # 68840 <fwp_heap>
    59f4:	31 d2                	xor    %edx,%edx
    59f6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    59fa:	48 89 ef             	mov    %rbp,%rdi
    59fd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5a01:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5a05:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    5a0c:	00 
    5a0d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5a12:	f7 f1                	div    %ecx
    5a14:	31 d2                	xor    %edx,%edx
    5a16:	66 0f 6e c1          	movd   %ecx,%xmm0
    5a1a:	66 0f 6e c8          	movd   %eax,%xmm1
    5a1e:	89 c6                	mov    %eax,%esi
    5a20:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5a25:	48 01 c8             	add    %rcx,%rax
    5a28:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5a2c:	48 f7 f1             	div    %rcx
    5a2f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5a34:	89 45 18             	mov    %eax,0x18(%rbp)
    5a37:	e8 84 fe ff ff       	call   58c0 <fwp_rc_prepare_chunk>
    5a3c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    5a3f:	48 89 d8             	mov    %rbx,%rax
    5a42:	48 c1 e0 10          	shl    $0x10,%rax
    5a46:	48 03 05 a3 41 06 00 	add    0x641a3(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    5a4d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5a51:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5a56:	8b 55 08             	mov    0x8(%rbp),%edx
    5a59:	48 0f af d1          	imul   %rcx,%rdx
    5a5d:	48 01 c2             	add    %rax,%rdx
    5a60:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a65:	5b                   	pop    %rbx
    5a66:	5d                   	pop    %rbp
    5a67:	41 5c                	pop    %r12
    5a69:	41 5d                	pop    %r13
    5a6b:	41 5e                	pop    %r14
    5a6d:	c3                   	ret
    5a6e:	66 90                	xchg   %ax,%ax

0000000000005a70 <fwp_mem_free>:
    5a70:	48 85 ff             	test   %rdi,%rdi
    5a73:	0f 84 17 02 00 00    	je     5c90 <fwp_mem_free+0x220>
    5a79:	48 8b 35 70 41 06 00 	mov    0x64170(%rip),%rsi        # 69bf0 <fwp_heap+0x13b0>
    5a80:	48 8b 05 91 41 06 00 	mov    0x64191(%rip),%rax        # 69c18 <fwp_heap+0x13d8>
    5a87:	48 89 fa             	mov    %rdi,%rdx
    5a8a:	48 29 f2             	sub    %rsi,%rdx
    5a8d:	48 c1 e0 10          	shl    $0x10,%rax
    5a91:	48 39 c2             	cmp    %rax,%rdx
    5a94:	0f 83 f6 01 00 00    	jae    5c90 <fwp_mem_free+0x220>
    5a9a:	49 89 d1             	mov    %rdx,%r9
    5a9d:	49 c1 e9 10          	shr    $0x10,%r9
    5aa1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5aa5:	48 c1 e0 03          	shl    $0x3,%rax
    5aa9:	49 89 c0             	mov    %rax,%r8
    5aac:	4c 03 05 85 41 06 00 	add    0x64185(%rip),%r8        # 69c38 <fwp_heap+0x13f8>
    5ab3:	0f 84 d7 01 00 00    	je     5c90 <fwp_mem_free+0x220>
    5ab9:	48 83 ec 38          	sub    $0x38,%rsp
    5abd:	48 89 f9             	mov    %rdi,%rcx
    5ac0:	41 0f b6 38          	movzbl (%r8),%edi
    5ac4:	40 80 ff 01          	cmp    $0x1,%dil
    5ac8:	74 16                	je     5ae0 <fwp_mem_free+0x70>
    5aca:	40 80 ff 02          	cmp    $0x2,%dil
    5ace:	0f 84 94 00 00 00    	je     5b68 <fwp_mem_free+0xf8>
    5ad4:	48 83 c4 38          	add    $0x38,%rsp
    5ad8:	c3                   	ret
    5ad9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ae0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5ae4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5ae9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5aee:	41 8b 78 04          	mov    0x4(%r8),%edi
    5af2:	4d 85 d2             	test   %r10,%r10
    5af5:	74 1d                	je     5b14 <fwp_mem_free+0xa4>
    5af7:	0f b7 c1             	movzwl %cx,%eax
    5afa:	31 d2                	xor    %edx,%edx
    5afc:	48 f7 f7             	div    %rdi
    5aff:	49 01 c2             	add    %rax,%r10
    5b02:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5b06:	0f 84 44 01 00 00    	je     5c50 <fwp_mem_free+0x1e0>
    5b0c:	41 c6 02 00          	movb   $0x0,(%r10)
    5b10:	41 8b 78 04          	mov    0x4(%r8),%edi
    5b14:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5b1b:	49 63 c1             	movslq %r9d,%rax
    5b1e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b22:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5b26:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5b2b:	f2 0f 58 05 4d 41 06 	addsd  0x6414d(%rip),%xmm0        # 69c80 <fwp_heap+0x1440>
    5b32:	00 
    5b33:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5b37:	48 8d 05 02 2d 06 00 	lea    0x62d02(%rip),%rax        # 68840 <fwp_heap>
    5b3e:	48 01 d0             	add    %rdx,%rax
    5b41:	48 8b 10             	mov    (%rax),%rdx
    5b44:	48 f7 d2             	not    %rdx
    5b47:	48 89 11             	mov    %rdx,(%rcx)
    5b4a:	48 89 08             	mov    %rcx,(%rax)
    5b4d:	48 29 3d 0c 41 06 00 	sub    %rdi,0x6410c(%rip)        # 69c60 <fwp_heap+0x1420>
    5b54:	f2 0f 11 05 24 41 06 	movsd  %xmm0,0x64124(%rip)        # 69c80 <fwp_heap+0x1440>
    5b5b:	00 
    5b5c:	48 83 c4 38          	add    $0x38,%rsp
    5b60:	c3                   	ret
    5b61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b68:	66 31 d2             	xor    %dx,%dx
    5b6b:	48 01 d6             	add    %rdx,%rsi
    5b6e:	48 39 f1             	cmp    %rsi,%rcx
    5b71:	0f 85 5d ff ff ff    	jne    5ad4 <fwp_mem_free+0x64>
    5b77:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b7b:	48 29 15 de 40 06 00 	sub    %rdx,0x640de(%rip)        # 69c60 <fwp_heap+0x1420>
    5b82:	48 85 d2             	test   %rdx,%rdx
    5b85:	0f 88 a5 00 00 00    	js     5c30 <fwp_mem_free+0x1c0>
    5b8b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b8f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b94:	f2 0f 58 05 e4 40 06 	addsd  0x640e4(%rip),%xmm0        # 69c80 <fwp_heap+0x1440>
    5b9b:	00 
    5b9c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5ba0:	f2 0f 11 05 d8 40 06 	movsd  %xmm0,0x640d8(%rip)        # 69c80 <fwp_heap+0x1440>
    5ba7:	00 
    5ba8:	48 85 d2             	test   %rdx,%rdx
    5bab:	74 0c                	je     5bb9 <fwp_mem_free+0x149>
    5bad:	80 3a ff             	cmpb   $0xff,(%rdx)
    5bb0:	0f 84 db 00 00 00    	je     5c91 <fwp_mem_free+0x221>
    5bb6:	c6 02 00             	movb   $0x0,(%rdx)
    5bb9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5bbd:	48 85 c9             	test   %rcx,%rcx
    5bc0:	74 3e                	je     5c00 <fwp_mem_free+0x190>
    5bc2:	48 8b 15 6f 40 06 00 	mov    0x6406f(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    5bc9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5bcd:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5bd1:	48 01 d0             	add    %rdx,%rax
    5bd4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5bd8:	48 89 d6             	mov    %rdx,%rsi
    5bdb:	48 29 c6             	sub    %rax,%rsi
    5bde:	83 e6 08             	and    $0x8,%esi
    5be1:	74 0d                	je     5bf0 <fwp_mem_free+0x180>
    5be3:	c6 00 00             	movb   $0x0,(%rax)
    5be6:	48 83 c0 28          	add    $0x28,%rax
    5bea:	48 39 c2             	cmp    %rax,%rdx
    5bed:	74 11                	je     5c00 <fwp_mem_free+0x190>
    5bef:	90                   	nop
    5bf0:	c6 00 00             	movb   $0x0,(%rax)
    5bf3:	48 83 c0 50          	add    $0x50,%rax
    5bf7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5bfb:	48 39 c2             	cmp    %rax,%rdx
    5bfe:	75 f0                	jne    5bf0 <fwp_mem_free+0x180>
    5c00:	48 01 0d 69 40 06 00 	add    %rcx,0x64069(%rip)        # 69c70 <fwp_heap+0x1430>
    5c07:	4c 3b 0d 22 40 06 00 	cmp    0x64022(%rip),%r9        # 69c30 <fwp_heap+0x13f0>
    5c0e:	73 07                	jae    5c17 <fwp_mem_free+0x1a7>
    5c10:	4c 89 0d 19 40 06 00 	mov    %r9,0x64019(%rip)        # 69c30 <fwp_heap+0x13f0>
    5c17:	4c 3b 0d 0a 40 06 00 	cmp    0x6400a(%rip),%r9        # 69c28 <fwp_heap+0x13e8>
    5c1e:	0f 83 b0 fe ff ff    	jae    5ad4 <fwp_mem_free+0x64>
    5c24:	4c 89 0d fd 3f 06 00 	mov    %r9,0x63ffd(%rip)        # 69c28 <fwp_heap+0x13e8>
    5c2b:	e9 a4 fe ff ff       	jmp    5ad4 <fwp_mem_free+0x64>
    5c30:	48 89 d1             	mov    %rdx,%rcx
    5c33:	83 e2 01             	and    $0x1,%edx
    5c36:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c3a:	48 d1 e9             	shr    $1,%rcx
    5c3d:	48 09 d1             	or     %rdx,%rcx
    5c40:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5c45:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5c49:	e9 46 ff ff ff       	jmp    5b94 <fwp_mem_free+0x124>
    5c4e:	66 90                	xchg   %ax,%ax
    5c50:	4c 89 d7             	mov    %r10,%rdi
    5c53:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5c58:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5c5d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c62:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c66:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c6b:	e8 c0 fb ff ff       	call   5830 <fwp_rc_forget_slot>
    5c70:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c75:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c7a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c7f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c84:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c89:	e9 7e fe ff ff       	jmp    5b0c <fwp_mem_free+0x9c>
    5c8e:	66 90                	xchg   %ax,%ax
    5c90:	c3                   	ret
    5c91:	48 89 d7             	mov    %rdx,%rdi
    5c94:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c99:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c9e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5ca3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5ca8:	e8 83 fb ff ff       	call   5830 <fwp_rc_forget_slot>
    5cad:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5cb2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5cb7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5cbc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5cc1:	e9 f0 fe ff ff       	jmp    5bb6 <fwp_mem_free+0x146>
    5cc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5ccd:	00 00 00 

0000000000005cd0 <fwp_heap_alloc_big>:
    5cd0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5cd7:	00 00 40 
    5cda:	41 57                	push   %r15
    5cdc:	41 56                	push   %r14
    5cde:	41 55                	push   %r13
    5ce0:	41 54                	push   %r12
    5ce2:	55                   	push   %rbp
    5ce3:	53                   	push   %rbx
    5ce4:	48 83 ec 08          	sub    $0x8,%rsp
    5ce8:	48 39 f8             	cmp    %rdi,%rax
    5ceb:	0f 82 fa 00 00 00    	jb     5deb <fwp_heap_alloc_big+0x11b>
    5cf1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5cf8:	49 89 fd             	mov    %rdi,%r13
    5cfb:	41 89 f6             	mov    %esi,%r14d
    5cfe:	48 c1 ed 10          	shr    $0x10,%rbp
    5d02:	48 89 ef             	mov    %rbp,%rdi
    5d05:	e8 66 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5d0a:	be 01 00 00 00       	mov    $0x1,%esi
    5d0f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5d13:	49 89 c4             	mov    %rax,%r12
    5d16:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5d1d:	00 
    5d1e:	48 03 3d 13 3f 06 00 	add    0x63f13(%rip),%rdi        # 69c38 <fwp_heap+0x13f8>
    5d25:	c6 07 02             	movb   $0x2,(%rdi)
    5d28:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5d2c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5d2f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5d33:	e8 88 fb ff ff       	call   58c0 <fwp_rc_prepare_chunk>
    5d38:	48 83 fd 01          	cmp    $0x1,%rbp
    5d3c:	76 47                	jbe    5d85 <fwp_heap_alloc_big+0xb5>
    5d3e:	4c 01 e5             	add    %r12,%rbp
    5d41:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5d48:	00 
    5d49:	4c 8d 3d f0 2a 06 00 	lea    0x62af0(%rip),%r15        # 68840 <fwp_heap>
    5d50:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5d55:	49 c1 e6 03          	shl    $0x3,%r14
    5d59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d60:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d67:	31 f6                	xor    %esi,%esi
    5d69:	48 01 dd             	add    %rbx,%rbp
    5d6c:	48 83 c3 28          	add    $0x28,%rbx
    5d70:	48 89 ef             	mov    %rbp,%rdi
    5d73:	e8 48 fb ff ff       	call   58c0 <fwp_rc_prepare_chunk>
    5d78:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d7c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d80:	49 39 de             	cmp    %rbx,%r14
    5d83:	75 db                	jne    5d60 <fwp_heap_alloc_big+0x90>
    5d85:	49 c1 e4 10          	shl    $0x10,%r12
    5d89:	4c 03 25 60 3e 06 00 	add    0x63e60(%rip),%r12        # 69bf0 <fwp_heap+0x13b0>
    5d90:	4c 89 ea             	mov    %r13,%rdx
    5d93:	31 f6                	xor    %esi,%esi
    5d95:	4c 89 e7             	mov    %r12,%rdi
    5d98:	e8 13 d7 ff ff       	call   34b0 <memset@plt>
    5d9d:	4c 89 e8             	mov    %r13,%rax
    5da0:	48 03 05 b9 3e 06 00 	add    0x63eb9(%rip),%rax        # 69c60 <fwp_heap+0x1420>
    5da7:	72 42                	jb     5deb <fwp_heap_alloc_big+0x11b>
    5da9:	48 39 05 b8 3e 06 00 	cmp    %rax,0x63eb8(%rip)        # 69c68 <fwp_heap+0x1428>
    5db0:	48 89 05 a9 3e 06 00 	mov    %rax,0x63ea9(%rip)        # 69c60 <fwp_heap+0x1420>
    5db7:	73 07                	jae    5dc0 <fwp_heap_alloc_big+0xf0>
    5db9:	48 89 05 a8 3e 06 00 	mov    %rax,0x63ea8(%rip)        # 69c68 <fwp_heap+0x1428>
    5dc0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5dc4:	4c 89 e0             	mov    %r12,%rax
    5dc7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5dcc:	f2 0f 58 05 a4 3e 06 	addsd  0x63ea4(%rip),%xmm0        # 69c78 <fwp_heap+0x1438>
    5dd3:	00 
    5dd4:	f2 0f 11 05 9c 3e 06 	movsd  %xmm0,0x63e9c(%rip)        # 69c78 <fwp_heap+0x1438>
    5ddb:	00 
    5ddc:	48 83 c4 08          	add    $0x8,%rsp
    5de0:	5b                   	pop    %rbx
    5de1:	5d                   	pop    %rbp
    5de2:	41 5c                	pop    %r12
    5de4:	41 5d                	pop    %r13
    5de6:	41 5e                	pop    %r14
    5de8:	41 5f                	pop    %r15
    5dea:	c3                   	ret
    5deb:	e8 40 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005df0 <fwp_heap_alloc_slow>:
    5df0:	53                   	push   %rbx
    5df1:	48 89 f9             	mov    %rdi,%rcx
    5df4:	41 89 f1             	mov    %esi,%r9d
    5df7:	48 83 ec 10          	sub    $0x10,%rsp
    5dfb:	8b 05 e3 3d 06 00    	mov    0x63de3(%rip),%eax        # 69be4 <fwp_heap+0x13a4>
    5e01:	85 c0                	test   %eax,%eax
    5e03:	0f 84 c7 00 00 00    	je     5ed0 <fwp_heap_alloc_slow+0xe0>
    5e09:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e10:	0f 87 dd 00 00 00    	ja     5ef3 <fwp_heap_alloc_slow+0x103>
    5e16:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5e1a:	48 8d 3d 1f 2a 06 00 	lea    0x62a1f(%rip),%rdi        # 68840 <fwp_heap>
    5e21:	49 63 f1             	movslq %r9d,%rsi
    5e24:	48 c1 e8 04          	shr    $0x4,%rax
    5e28:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5e2f:	00 00 
    5e31:	41 0f b6 c2          	movzbl %r10b,%eax
    5e35:	4c 89 d2             	mov    %r10,%rdx
    5e38:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5e3c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5e43:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5e4a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5e4e:	48 01 f8             	add    %rdi,%rax
    5e51:	4c 8b 00             	mov    (%rax),%r8
    5e54:	4d 85 c0             	test   %r8,%r8
    5e57:	0f 84 ab 00 00 00    	je     5f08 <fwp_heap_alloc_slow+0x118>
    5e5d:	49 8b 10             	mov    (%r8),%rdx
    5e60:	48 f7 d2             	not    %rdx
    5e63:	48 89 10             	mov    %rdx,(%rax)
    5e66:	41 83 f9 01          	cmp    $0x1,%r9d
    5e6a:	4c 89 c7             	mov    %r8,%rdi
    5e6d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e71:	31 f6                	xor    %esi,%esi
    5e73:	48 89 ca             	mov    %rcx,%rdx
    5e76:	e8 35 d6 ff ff       	call   34b0 <memset@plt>
    5e7b:	49 89 c0             	mov    %rax,%r8
    5e7e:	48 89 d8             	mov    %rbx,%rax
    5e81:	48 03 05 d8 3d 06 00 	add    0x63dd8(%rip),%rax        # 69c60 <fwp_heap+0x1420>
    5e88:	0f 82 d9 00 00 00    	jb     5f67 <fwp_heap_alloc_slow+0x177>
    5e8e:	48 39 05 d3 3d 06 00 	cmp    %rax,0x63dd3(%rip)        # 69c68 <fwp_heap+0x1428>
    5e95:	48 89 05 c4 3d 06 00 	mov    %rax,0x63dc4(%rip)        # 69c60 <fwp_heap+0x1420>
    5e9c:	73 07                	jae    5ea5 <fwp_heap_alloc_slow+0xb5>
    5e9e:	48 89 05 c3 3d 06 00 	mov    %rax,0x63dc3(%rip)        # 69c68 <fwp_heap+0x1428>
    5ea5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ea9:	4c 89 c0             	mov    %r8,%rax
    5eac:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5eb1:	f2 0f 58 05 bf 3d 06 	addsd  0x63dbf(%rip),%xmm0        # 69c78 <fwp_heap+0x1438>
    5eb8:	00 
    5eb9:	f2 0f 11 05 b7 3d 06 	movsd  %xmm0,0x63db7(%rip)        # 69c78 <fwp_heap+0x1438>
    5ec0:	00 
    5ec1:	48 83 c4 10          	add    $0x10,%rsp
    5ec5:	5b                   	pop    %rbx
    5ec6:	c3                   	ret
    5ec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5ece:	00 00 
    5ed0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5ed4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5ed8:	e8 f3 ee ff ff       	call   4dd0 <fwp_heap_init>
    5edd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5ee1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5ee6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5eed:	0f 86 23 ff ff ff    	jbe    5e16 <fwp_heap_alloc_slow+0x26>
    5ef3:	48 83 c4 10          	add    $0x10,%rsp
    5ef7:	44 89 ce             	mov    %r9d,%esi
    5efa:	48 89 cf             	mov    %rcx,%rdi
    5efd:	5b                   	pop    %rbx
    5efe:	e9 cd fd ff ff       	jmp    5cd0 <fwp_heap_alloc_big>
    5f03:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5f08:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5f0c:	4d 85 c0             	test   %r8,%r8
    5f0f:	74 1f                	je     5f30 <fwp_heap_alloc_slow+0x140>
    5f11:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5f15:	4d 29 c3             	sub    %r8,%r11
    5f18:	49 39 db             	cmp    %rbx,%r11
    5f1b:	72 13                	jb     5f30 <fwp_heap_alloc_slow+0x140>
    5f1d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5f21:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5f25:	e9 3c ff ff ff       	jmp    5e66 <fwp_heap_alloc_slow+0x76>
    5f2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5f30:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5f37:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5f3b:	44 89 ca             	mov    %r9d,%edx
    5f3e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5f43:	44 89 0c 24          	mov    %r9d,(%rsp)
    5f47:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5f4b:	44 89 d6             	mov    %r10d,%esi
    5f4e:	48 01 c7             	add    %rax,%rdi
    5f51:	e8 6a fa ff ff       	call   59c0 <fwp_heap_refill>
    5f56:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5f5b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5f5f:	49 89 c0             	mov    %rax,%r8
    5f62:	e9 ff fe ff ff       	jmp    5e66 <fwp_heap_alloc_slow+0x76>
    5f67:	e8 c4 de ff ff       	call   3e30 <fwp_heap_oom>
    5f6c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f70 <fwp_heap_alloc>:
    5f70:	53                   	push   %rbx
    5f71:	48 89 fa             	mov    %rdi,%rdx
    5f74:	48 83 ec 10          	sub    $0x10,%rsp
    5f78:	8b 1d 8a 45 06 00    	mov    0x6458a(%rip),%ebx        # 6a508 <iteration_active>
    5f7e:	8b 05 60 3c 06 00    	mov    0x63c60(%rip),%eax        # 69be4 <fwp_heap+0x13a4>
    5f84:	85 db                	test   %ebx,%ebx
    5f86:	0f 85 04 01 00 00    	jne    6090 <fwp_heap_alloc+0x120>
    5f8c:	85 c0                	test   %eax,%eax
    5f8e:	0f 84 ac 01 00 00    	je     6140 <fwp_heap_alloc+0x1d0>
    5f94:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f9b:	0f 87 9f 01 00 00    	ja     6140 <fwp_heap_alloc+0x1d0>
    5fa1:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5fa5:	48 8d 05 94 28 06 00 	lea    0x62894(%rip),%rax        # 68840 <fwp_heap>
    5fac:	48 c1 e9 04          	shr    $0x4,%rcx
    5fb0:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5fb7:	00 
    5fb8:	48 63 ce             	movslq %esi,%rcx
    5fbb:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5fc2:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5fc9:	00 
    5fca:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5fce:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5fd2:	48 01 c8             	add    %rcx,%rax
    5fd5:	48 8b 08             	mov    (%rax),%rcx
    5fd8:	48 85 c9             	test   %rcx,%rcx
    5fdb:	0f 84 ff 00 00 00    	je     60e0 <fwp_heap_alloc+0x170>
    5fe1:	48 8b 39             	mov    (%rcx),%rdi
    5fe4:	48 f7 d7             	not    %rdi
    5fe7:	48 89 38             	mov    %rdi,(%rax)
    5fea:	83 fe 01             	cmp    $0x1,%esi
    5fed:	48 89 cf             	mov    %rcx,%rdi
    5ff0:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5ff5:	49 0f 45 d0          	cmovne %r8,%rdx
    5ff9:	31 f6                	xor    %esi,%esi
    5ffb:	e8 b0 d4 ff ff       	call   34b0 <memset@plt>
    6000:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    6005:	48 89 c1             	mov    %rax,%rcx
    6008:	4c 89 c0             	mov    %r8,%rax
    600b:	48 03 05 4e 3c 06 00 	add    0x63c4e(%rip),%rax        # 69c60 <fwp_heap+0x1420>
    6012:	0f 82 35 01 00 00    	jb     614d <fwp_heap_alloc+0x1dd>
    6018:	48 39 05 49 3c 06 00 	cmp    %rax,0x63c49(%rip)        # 69c68 <fwp_heap+0x1428>
    601f:	48 89 05 3a 3c 06 00 	mov    %rax,0x63c3a(%rip)        # 69c60 <fwp_heap+0x1420>
    6026:	73 07                	jae    602f <fwp_heap_alloc+0xbf>
    6028:	48 89 05 39 3c 06 00 	mov    %rax,0x63c39(%rip)        # 69c68 <fwp_heap+0x1428>
    602f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6033:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    6038:	f2 0f 58 05 38 3c 06 	addsd  0x63c38(%rip),%xmm0        # 69c78 <fwp_heap+0x1438>
    603f:	00 
    6040:	f2 0f 11 05 30 3c 06 	movsd  %xmm0,0x63c30(%rip)        # 69c78 <fwp_heap+0x1438>
    6047:	00 
    6048:	85 db                	test   %ebx,%ebx
    604a:	74 33                	je     607f <fwp_heap_alloc+0x10f>
    604c:	48 8b 05 0d 3c 06 00 	mov    0x63c0d(%rip),%rax        # 69c60 <fwp_heap+0x1420>
    6053:	48 85 c0             	test   %rax,%rax
    6056:	0f 88 ac 00 00 00    	js     6108 <fwp_heap_alloc+0x198>
    605c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6060:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6065:	f2 0f 5c 05 7b 44 06 	subsd  0x6447b(%rip),%xmm0        # 6a4e8 <iteration_start_charge>
    606c:	00 
    606d:	66 0f 2f 05 6b 44 06 	comisd 0x6446b(%rip),%xmm0        # 6a4e0 <iteration_peak>
    6074:	00 
    6075:	76 08                	jbe    607f <fwp_heap_alloc+0x10f>
    6077:	f2 0f 11 05 61 44 06 	movsd  %xmm0,0x64461(%rip)        # 6a4e0 <iteration_peak>
    607e:	00 
    607f:	48 83 c4 10          	add    $0x10,%rsp
    6083:	48 89 c8             	mov    %rcx,%rax
    6086:	5b                   	pop    %rbx
    6087:	c3                   	ret
    6088:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    608f:	00 
    6090:	85 f6                	test   %esi,%esi
    6092:	74 34                	je     60c8 <fwp_heap_alloc+0x158>
    6094:	48 83 05 64 44 06 00 	addq   $0x1,0x64464(%rip)        # 6a500 <iteration_requests>
    609b:	01 
    609c:	48 01 3d 55 44 06 00 	add    %rdi,0x64455(%rip)        # 6a4f8 <iteration_bytes>
    60a3:	85 c0                	test   %eax,%eax
    60a5:	74 0d                	je     60b4 <fwp_heap_alloc+0x144>
    60a7:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    60ae:	0f 86 ed fe ff ff    	jbe    5fa1 <fwp_heap_alloc+0x31>
    60b4:	48 89 d7             	mov    %rdx,%rdi
    60b7:	e8 34 fd ff ff       	call   5df0 <fwp_heap_alloc_slow>
    60bc:	48 89 c1             	mov    %rax,%rcx
    60bf:	eb 8b                	jmp    604c <fwp_heap_alloc+0xdc>
    60c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    60c8:	85 c0                	test   %eax,%eax
    60ca:	74 0d                	je     60d9 <fwp_heap_alloc+0x169>
    60cc:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    60d3:	0f 86 c8 fe ff ff    	jbe    5fa1 <fwp_heap_alloc+0x31>
    60d9:	31 f6                	xor    %esi,%esi
    60db:	eb d7                	jmp    60b4 <fwp_heap_alloc+0x144>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    60e4:	48 85 c9             	test   %rcx,%rcx
    60e7:	74 0c                	je     60f5 <fwp_heap_alloc+0x185>
    60e9:	48 8b 78 10          	mov    0x10(%rax),%rdi
    60ed:	48 29 cf             	sub    %rcx,%rdi
    60f0:	4c 39 c7             	cmp    %r8,%rdi
    60f3:	73 3b                	jae    6130 <fwp_heap_alloc+0x1c0>
    60f5:	48 89 d7             	mov    %rdx,%rdi
    60f8:	e8 f3 fc ff ff       	call   5df0 <fwp_heap_alloc_slow>
    60fd:	48 89 c1             	mov    %rax,%rcx
    6100:	e9 43 ff ff ff       	jmp    6048 <fwp_heap_alloc+0xd8>
    6105:	0f 1f 00             	nopl   (%rax)
    6108:	48 89 c2             	mov    %rax,%rdx
    610b:	83 e0 01             	and    $0x1,%eax
    610e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6112:	48 d1 ea             	shr    $1,%rdx
    6115:	48 09 c2             	or     %rax,%rdx
    6118:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    611d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6121:	e9 3f ff ff ff       	jmp    6065 <fwp_heap_alloc+0xf5>
    6126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    612d:	00 00 00 
    6130:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    6134:	48 89 78 08          	mov    %rdi,0x8(%rax)
    6138:	e9 ad fe ff ff       	jmp    5fea <fwp_heap_alloc+0x7a>
    613d:	0f 1f 00             	nopl   (%rax)
    6140:	48 83 c4 10          	add    $0x10,%rsp
    6144:	48 89 d7             	mov    %rdx,%rdi
    6147:	5b                   	pop    %rbx
    6148:	e9 a3 fc ff ff       	jmp    5df0 <fwp_heap_alloc_slow>
    614d:	e8 de dc ff ff       	call   3e30 <fwp_heap_oom>
    6152:	0f 1f 00             	nopl   (%rax)
    6155:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    615c:	00 00 00 00 

0000000000006160 <fwp_data.part.0.constprop.0>:
    6160:	41 56                	push   %r14
    6162:	8b 05 7c 3a 06 00    	mov    0x63a7c(%rip),%eax        # 69be4 <fwp_heap+0x13a4>
    6168:	41 89 fe             	mov    %edi,%r14d
    616b:	41 55                	push   %r13
    616d:	44 8b 2d 94 43 06 00 	mov    0x64394(%rip),%r13d        # 6a508 <iteration_active>
    6174:	41 54                	push   %r12
    6176:	49 89 f4             	mov    %rsi,%r12
    6179:	55                   	push   %rbp
    617a:	53                   	push   %rbx
    617b:	45 85 ed             	test   %r13d,%r13d
    617e:	0f 84 1c 01 00 00    	je     62a0 <fwp_data.part.0.constprop.0+0x140>
    6184:	48 83 05 74 43 06 00 	addq   $0x1,0x64374(%rip)        # 6a500 <iteration_requests>
    618b:	01 
    618c:	48 83 05 64 43 06 00 	addq   $0x18,0x64364(%rip)        # 6a4f8 <iteration_bytes>
    6193:	18 
    6194:	85 c0                	test   %eax,%eax
    6196:	0f 84 8c 01 00 00    	je     6328 <fwp_data.part.0.constprop.0+0x1c8>
    619c:	0f b6 05 3f 36 06 00 	movzbl 0x6363f(%rip),%eax        # 697e2 <fwp_heap+0xfa2>
    61a3:	48 8d 15 96 26 06 00 	lea    0x62696(%rip),%rdx        # 68840 <fwp_heap>
    61aa:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    61b1:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    61b5:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    61b9:	48 8b 18             	mov    (%rax),%rbx
    61bc:	48 85 db             	test   %rbx,%rbx
    61bf:	0f 84 fb 00 00 00    	je     62c0 <fwp_data.part.0.constprop.0+0x160>
    61c5:	48 8b 13             	mov    (%rbx),%rdx
    61c8:	48 f7 d2             	not    %rdx
    61cb:	48 89 10             	mov    %rdx,(%rax)
    61ce:	48 83 fd 18          	cmp    $0x18,%rbp
    61d2:	76 1b                	jbe    61ef <fwp_data.part.0.constprop.0+0x8f>
    61d4:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    61d8:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    61dc:	31 f6                	xor    %esi,%esi
    61de:	48 c1 e8 03          	shr    $0x3,%rax
    61e2:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    61e9:	00 
    61ea:	e8 c1 d2 ff ff       	call   34b0 <memset@plt>
    61ef:	48 89 e8             	mov    %rbp,%rax
    61f2:	48 03 05 67 3a 06 00 	add    0x63a67(%rip),%rax        # 69c60 <fwp_heap+0x1420>
    61f9:	0f 82 3d 01 00 00    	jb     633c <fwp_data.part.0.constprop.0+0x1dc>
    61ff:	48 39 05 62 3a 06 00 	cmp    %rax,0x63a62(%rip)        # 69c68 <fwp_heap+0x1428>
    6206:	48 89 05 53 3a 06 00 	mov    %rax,0x63a53(%rip)        # 69c60 <fwp_heap+0x1420>
    620d:	73 07                	jae    6216 <fwp_data.part.0.constprop.0+0xb6>
    620f:	48 89 05 52 3a 06 00 	mov    %rax,0x63a52(%rip)        # 69c68 <fwp_heap+0x1428>
    6216:	66 0f ef c0          	pxor   %xmm0,%xmm0
    621a:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    621f:	f2 0f 58 05 51 3a 06 	addsd  0x63a51(%rip),%xmm0        # 69c78 <fwp_heap+0x1438>
    6226:	00 
    6227:	f2 0f 11 05 49 3a 06 	movsd  %xmm0,0x63a49(%rip)        # 69c78 <fwp_heap+0x1438>
    622e:	00 
    622f:	45 85 ed             	test   %r13d,%r13d
    6232:	74 33                	je     6267 <fwp_data.part.0.constprop.0+0x107>
    6234:	48 8b 05 25 3a 06 00 	mov    0x63a25(%rip),%rax        # 69c60 <fwp_heap+0x1420>
    623b:	48 85 c0             	test   %rax,%rax
    623e:	0f 88 a4 00 00 00    	js     62e8 <fwp_data.part.0.constprop.0+0x188>
    6244:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6248:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    624d:	f2 0f 5c 05 93 42 06 	subsd  0x64293(%rip),%xmm0        # 6a4e8 <iteration_start_charge>
    6254:	00 
    6255:	66 0f 2f 05 83 42 06 	comisd 0x64283(%rip),%xmm0        # 6a4e0 <iteration_peak>
    625c:	00 
    625d:	76 08                	jbe    6267 <fwp_data.part.0.constprop.0+0x107>
    625f:	f2 0f 11 05 79 42 06 	movsd  %xmm0,0x64279(%rip)        # 6a4e0 <iteration_peak>
    6266:	00 
    6267:	b8 02 00 00 00       	mov    $0x2,%eax
    626c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6271:	66 0f 6e c8          	movd   %eax,%xmm1
    6275:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6279:	66 0f d6 03          	movq   %xmm0,(%rbx)
    627d:	49 8b 04 24          	mov    (%r12),%rax
    6281:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6285:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    628a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    628e:	48 89 d8             	mov    %rbx,%rax
    6291:	5b                   	pop    %rbx
    6292:	5d                   	pop    %rbp
    6293:	41 5c                	pop    %r12
    6295:	41 5d                	pop    %r13
    6297:	41 5e                	pop    %r14
    6299:	c3                   	ret
    629a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    62a0:	85 c0                	test   %eax,%eax
    62a2:	0f 85 f4 fe ff ff    	jne    619c <fwp_data.part.0.constprop.0+0x3c>
    62a8:	31 f6                	xor    %esi,%esi
    62aa:	bf 18 00 00 00       	mov    $0x18,%edi
    62af:	e8 bc fc ff ff       	call   5f70 <fwp_heap_alloc>
    62b4:	48 89 c3             	mov    %rax,%rbx
    62b7:	eb ae                	jmp    6267 <fwp_data.part.0.constprop.0+0x107>
    62b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    62c0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    62c4:	48 85 db             	test   %rbx,%rbx
    62c7:	74 47                	je     6310 <fwp_data.part.0.constprop.0+0x1b0>
    62c9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    62cd:	48 29 da             	sub    %rbx,%rdx
    62d0:	48 39 ea             	cmp    %rbp,%rdx
    62d3:	72 3b                	jb     6310 <fwp_data.part.0.constprop.0+0x1b0>
    62d5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    62d9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    62dd:	e9 ec fe ff ff       	jmp    61ce <fwp_data.part.0.constprop.0+0x6e>
    62e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    62e8:	48 89 c2             	mov    %rax,%rdx
    62eb:	83 e0 01             	and    $0x1,%eax
    62ee:	66 0f ef c0          	pxor   %xmm0,%xmm0
    62f2:	48 d1 ea             	shr    $1,%rdx
    62f5:	48 09 c2             	or     %rax,%rdx
    62f8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    62fd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6301:	e9 47 ff ff ff       	jmp    624d <fwp_data.part.0.constprop.0+0xed>
    6306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    630d:	00 00 00 
    6310:	31 f6                	xor    %esi,%esi
    6312:	bf 18 00 00 00       	mov    $0x18,%edi
    6317:	e8 54 fc ff ff       	call   5f70 <fwp_heap_alloc>
    631c:	48 89 c3             	mov    %rax,%rbx
    631f:	e9 0b ff ff ff       	jmp    622f <fwp_data.part.0.constprop.0+0xcf>
    6324:	0f 1f 40 00          	nopl   0x0(%rax)
    6328:	31 f6                	xor    %esi,%esi
    632a:	bf 18 00 00 00       	mov    $0x18,%edi
    632f:	e8 3c fc ff ff       	call   5f70 <fwp_heap_alloc>
    6334:	48 89 c3             	mov    %rax,%rbx
    6337:	e9 f8 fe ff ff       	jmp    6234 <fwp_data.part.0.constprop.0+0xd4>
    633c:	e8 ef da ff ff       	call   3e30 <fwp_heap_oom>
    6341:	0f 1f 40 00          	nopl   0x0(%rax)
    6345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    634c:	00 00 00 00 

0000000000006350 <fwp_p_ad_push>:
    6350:	41 57                	push   %r15
    6352:	41 56                	push   %r14
    6354:	41 55                	push   %r13
    6356:	49 89 d5             	mov    %rdx,%r13
    6359:	41 54                	push   %r12
    635b:	49 89 fc             	mov    %rdi,%r12
    635e:	55                   	push   %rbp
    635f:	53                   	push   %rbx
    6360:	48 83 ec 38          	sub    $0x38,%rsp
    6364:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6369:	48 85 ff             	test   %rdi,%rdi
    636c:	79 09                	jns    6377 <fwp_p_ad_push+0x27>
    636e:	48 85 d2             	test   %rdx,%rdx
    6371:	0f 88 a9 01 00 00    	js     6520 <fwp_p_ad_push+0x1d0>
    6377:	48 89 f8             	mov    %rdi,%rax
    637a:	48 89 0c 24          	mov    %rcx,(%rsp)
    637e:	48 09 d0             	or     %rdx,%rax
    6381:	0f 89 71 01 00 00    	jns    64f8 <fwp_p_ad_push+0x1a8>
    6387:	48 89 f8             	mov    %rdi,%rax
    638a:	48 c1 f8 20          	sar    $0x20,%rax
    638e:	48 85 ff             	test   %rdi,%rdi
    6391:	79 24                	jns    63b7 <fwp_p_ad_push+0x67>
    6393:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6398:	48 89 d0             	mov    %rdx,%rax
    639b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    63a2:	00 
    63a3:	49 89 d4             	mov    %rdx,%r12
    63a6:	48 c1 f8 20          	sar    $0x20,%rax
    63aa:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    63b1:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    63b7:	48 89 c7             	mov    %rax,%rdi
    63ba:	e8 71 e3 ff ff       	call   4730 <fwp_tape_of>
    63bf:	48 89 c3             	mov    %rax,%rbx
    63c2:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    63c7:	0f 85 6e 02 00 00    	jne    663b <fwp_p_ad_push+0x2eb>
    63cd:	4c 8b 78 10          	mov    0x10(%rax),%r15
    63d1:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    63d8:	0f 8f 51 02 00 00    	jg     662f <fwp_p_ad_push+0x2df>
    63de:	44 89 e0             	mov    %r12d,%eax
    63e1:	4c 39 f8             	cmp    %r15,%rax
    63e4:	0f 8d 39 02 00 00    	jge    6623 <fwp_p_ad_push+0x2d3>
    63ea:	4d 85 ed             	test   %r13,%r13
    63ed:	78 0c                	js     63fb <fwp_p_ad_push+0xab>
    63ef:	44 89 e8             	mov    %r13d,%eax
    63f2:	4c 39 f8             	cmp    %r15,%rax
    63f5:	0f 8d 28 02 00 00    	jge    6623 <fwp_p_ad_push+0x2d3>
    63fb:	4d 89 fe             	mov    %r15,%r14
    63fe:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6402:	49 8d 46 01          	lea    0x1(%r14),%rax
    6406:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    640c:	0f 87 1d 02 00 00    	ja     662f <fwp_p_ad_push+0x2df>
    6412:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    6416:	48 39 e8             	cmp    %rbp,%rax
    6419:	0f 8e 31 01 00 00    	jle    6550 <fwp_p_ad_push+0x200>
    641f:	48 85 ed             	test   %rbp,%rbp
    6422:	ba 40 00 00 00       	mov    $0x40,%edx
    6427:	48 0f 44 ea          	cmove  %rdx,%rbp
    642b:	48 39 e8             	cmp    %rbp,%rax
    642e:	7e 20                	jle    6450 <fwp_p_ad_push+0x100>
    6430:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    6437:	0f 8f 03 01 00 00    	jg     6540 <fwp_p_ad_push+0x1f0>
    643d:	48 01 ed             	add    %rbp,%rbp
    6440:	48 39 e8             	cmp    %rbp,%rax
    6443:	7f eb                	jg     6430 <fwp_p_ad_push+0xe0>
    6445:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    644c:	00 00 00 00 
    6450:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6457:	00 
    6458:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    645c:	ba 01 00 00 00       	mov    $0x1,%edx
    6461:	48 89 c6             	mov    %rax,%rsi
    6464:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6469:	e8 82 ed ff ff       	call   51f0 <ad_raw_realloc>
    646e:	48 85 c0             	test   %rax,%rax
    6471:	0f 84 d0 01 00 00    	je     6647 <fwp_p_ad_push+0x2f7>
    6477:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    647b:	48 89 ee             	mov    %rbp,%rsi
    647e:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6482:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6486:	48 c1 e6 04          	shl    $0x4,%rsi
    648a:	48 8d 04 90          	lea    (%rax,%rdx,4),%rax
    648e:	ba 02 00 00 00       	mov    $0x2,%edx
    6493:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6497:	e8 54 ed ff ff       	call   51f0 <ad_raw_realloc>
    649c:	48 85 c0             	test   %rax,%rax
    649f:	0f 84 a2 01 00 00    	je     6647 <fwp_p_ad_push+0x2f7>
    64a5:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    64a9:	48 89 43 30          	mov    %rax,0x30(%rbx)
    64ad:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    64b4:	00 
    64b5:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    64bc:	00 
    64bd:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
    64c4:	00 
    64c5:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    64c9:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    64ce:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    64d2:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    64d6:	4d 85 f6             	test   %r14,%r14
    64d9:	0f 85 e5 00 00 00    	jne    65c4 <fwp_p_ad_push+0x274>
    64df:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    64e3:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    64e7:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    64eb:	48 01 d1             	add    %rdx,%rcx
    64ee:	48 89 4b 28          	mov    %rcx,0x28(%rbx)
    64f2:	eb 7c                	jmp    6570 <fwp_p_ad_push+0x220>
    64f4:	0f 1f 40 00          	nopl   0x0(%rax)
    64f8:	48 89 d0             	mov    %rdx,%rax
    64fb:	48 c1 ff 20          	sar    $0x20,%rdi
    64ff:	48 c1 f8 20          	sar    $0x20,%rax
    6503:	48 39 c7             	cmp    %rax,%rdi
    6506:	0f 84 ab fe ff ff    	je     63b7 <fwp_p_ad_push+0x67>
    650c:	48 8d 3d 05 65 00 00 	lea    0x6505(%rip),%rdi        # ca18 <_IO_stdin_used+0xa18>
    6513:	e8 38 df ff ff       	call   4450 <fwp_trap>
    6518:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    651f:	00 
    6520:	48 83 c4 38          	add    $0x38,%rsp
    6524:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    652b:	5b                   	pop    %rbx
    652c:	5d                   	pop    %rbp
    652d:	41 5c                	pop    %r12
    652f:	41 5d                	pop    %r13
    6531:	41 5e                	pop    %r14
    6533:	41 5f                	pop    %r15
    6535:	c3                   	ret
    6536:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    653d:	00 00 00 
    6540:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    6545:	e9 06 ff ff ff       	jmp    6450 <fwp_p_ad_push+0x100>
    654a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6550:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    6554:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6558:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    655f:	00 
    6560:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6567:	00 
    6568:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
    656c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6570:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6576:	46 89 24 12          	mov    %r12d,(%rdx,%r10,1)
    657a:	4d 85 ed             	test   %r13,%r13
    657d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6582:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6588:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    658f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6593:	49 8d 47 01          	lea    0x1(%r15),%rax
    6597:	46 89 2c 11          	mov    %r13d,(%rcx,%r10,1)
    659b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    65a1:	48 89 43 10          	mov    %rax,0x10(%rbx)
    65a5:	48 83 c4 38          	add    $0x38,%rsp
    65a9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    65b0:	ff ff ff 
    65b3:	4c 21 e0             	and    %r12,%rax
    65b6:	5b                   	pop    %rbx
    65b7:	5d                   	pop    %rbp
    65b8:	4c 09 f8             	or     %r15,%rax
    65bb:	41 5c                	pop    %r12
    65bd:	41 5d                	pop    %r13
    65bf:	41 5e                	pop    %r14
    65c1:	41 5f                	pop    %r15
    65c3:	c3                   	ret
    65c4:	4c 89 ca             	mov    %r9,%rdx
    65c7:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    65cc:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    65d1:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    65d6:	e8 15 d0 ff ff       	call   35f0 <memmove@plt>
    65db:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    65e0:	4c 03 73 30          	add    0x30(%rbx),%r14
    65e4:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    65e9:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    65ed:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    65f1:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    65f6:	48 03 7b 20          	add    0x20(%rbx),%rdi
    65fa:	4c 89 d2             	mov    %r10,%rdx
    65fd:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    6602:	e8 e9 cf ff ff       	call   35f0 <memmove@plt>
    6607:	48 8b 43 30          	mov    0x30(%rbx),%rax
    660b:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    660f:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    6614:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6619:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    661e:	e9 c0 fe ff ff       	jmp    64e3 <fwp_p_ad_push+0x193>
    6623:	48 8d 3d 98 5b 00 00 	lea    0x5b98(%rip),%rdi        # c1c2 <_IO_stdin_used+0x1c2>
    662a:	e8 21 de ff ff       	call   4450 <fwp_trap>
    662f:	48 8d 3d 71 5b 00 00 	lea    0x5b71(%rip),%rdi        # c1a7 <_IO_stdin_used+0x1a7>
    6636:	e8 15 de ff ff       	call   4450 <fwp_trap>
    663b:	48 8d 3d 1e 64 00 00 	lea    0x641e(%rip),%rdi        # ca60 <_IO_stdin_used+0xa60>
    6642:	e8 09 de ff ff       	call   4450 <fwp_trap>
    6647:	48 89 df             	mov    %rbx,%rdi
    664a:	e8 41 d6 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    664f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6653:	48 85 ff             	test   %rdi,%rdi
    6656:	74 05                	je     665d <fwp_p_ad_push+0x30d>
    6658:	e8 d3 ea ff ff       	call   5130 <ad_raw_free.part.0>
    665d:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6661:	48 85 ff             	test   %rdi,%rdi
    6664:	74 05                	je     666b <fwp_p_ad_push+0x31b>
    6666:	e8 c5 ea ff ff       	call   5130 <ad_raw_free.part.0>
    666b:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    666f:	48 85 ff             	test   %rdi,%rdi
    6672:	74 05                	je     6679 <fwp_p_ad_push+0x329>
    6674:	e8 b7 ea ff ff       	call   5130 <ad_raw_free.part.0>
    6679:	31 c9                	xor    %ecx,%ecx
    667b:	31 c0                	xor    %eax,%eax
    667d:	31 d2                	xor    %edx,%edx
    667f:	be 01 00 00 00       	mov    $0x1,%esi
    6684:	89 53 04             	mov    %edx,0x4(%rbx)
    6687:	66 0f ef c0          	pxor   %xmm0,%xmm0
    668b:	ba 13 00 00 00       	mov    $0x13,%edx
    6690:	48 8d 3d 71 59 00 00 	lea    0x5971(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    6697:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    669b:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    669f:	48 8b 0d 9a 99 00 00 	mov    0x999a(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    66a6:	48 89 43 40          	mov    %rax,0x40(%rbx)
    66aa:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    66ae:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    66b2:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    66b6:	e8 a5 cf ff ff       	call   3660 <fwrite@plt>
    66bb:	31 ff                	xor    %edi,%edi
    66bd:	e8 de ce ff ff       	call   35a0 <fflush@plt>
    66c2:	bf 66 00 00 00       	mov    $0x66,%edi
    66c7:	e8 b4 cf ff ff       	call   3680 <_Exit@plt>
    66cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000066d0 <w120>:
    66d0:	66 0f 28 e0          	movapd %xmm0,%xmm4
    66d4:	41 55                	push   %r13
    66d6:	48 89 fa             	mov    %rdi,%rdx
    66d9:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    66dd:	41 54                	push   %r12
    66df:	49 89 fc             	mov    %rdi,%r12
    66e2:	55                   	push   %rbp
    66e3:	53                   	push   %rbx
    66e4:	48 89 f3             	mov    %rsi,%rbx
    66e7:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    66ec:	48 89 f1             	mov    %rsi,%rcx
    66ef:	48 83 ec 28          	sub    $0x28,%rsp
    66f3:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    66f9:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    66ff:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6705:	e8 46 fc ff ff       	call   6350 <fwp_p_ad_push>
    670a:	48 89 c7             	mov    %rax,%rdi
    670d:	e8 ae e8 ff ff       	call   4fc0 <caf75>
    6712:	66 48 0f 6e c0       	movq   %rax,%xmm0
    6717:	e8 a4 e8 ff ff       	call   4fc0 <caf75>
    671c:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6722:	66 0f 57 05 c6 66 00 	xorpd  0x66c6(%rip),%xmm0        # cdf0 <msg.8+0xb0>
    6729:	00 
    672a:	48 89 da             	mov    %rbx,%rdx
    672d:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6733:	48 89 c1             	mov    %rax,%rcx
    6736:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    673b:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6740:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6746:	e8 05 fc ff ff       	call   6350 <fwp_p_ad_push>
    674b:	4c 89 e7             	mov    %r12,%rdi
    674e:	49 89 c5             	mov    %rax,%r13
    6751:	e8 6a e8 ff ff       	call   4fc0 <caf75>
    6756:	48 89 c6             	mov    %rax,%rsi
    6759:	e8 62 e8 ff ff       	call   4fc0 <caf75>
    675e:	66 48 0f 6e d6       	movq   %rsi,%xmm2
    6763:	f2 0f 10 05 fd 65 00 	movsd  0x65fd(%rip),%xmm0        # cd68 <msg.8+0x28>
    676a:	00 
    676b:	66 0f 57 15 7d 66 00 	xorpd  0x667d(%rip),%xmm2        # cdf0 <msg.8+0xb0>
    6772:	00 
    6773:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    6779:	48 89 c1             	mov    %rax,%rcx
    677c:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6783:	66 48 0f 7e d6       	movq   %xmm2,%rsi
    6788:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    678d:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6793:	e8 b8 fb ff ff       	call   6350 <fwp_p_ad_push>
    6798:	48 89 e9             	mov    %rbp,%rcx
    679b:	4c 89 ea             	mov    %r13,%rdx
    679e:	48 89 ee             	mov    %rbp,%rsi
    67a1:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    67a7:	4c 89 ef             	mov    %r13,%rdi
    67aa:	49 89 c4             	mov    %rax,%r12
    67ad:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    67b1:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    67b7:	e8 94 fb ff ff       	call   6350 <fwp_p_ad_push>
    67bc:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    67c2:	f2 0f 59 1d a6 65 00 	mulsd  0x65a6(%rip),%xmm3        # cd70 <msg.8+0x30>
    67c9:	00 
    67ca:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    67d1:	00 59 40 
    67d4:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    67d9:	48 89 c2             	mov    %rax,%rdx
    67dc:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    67e3:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    67e9:	e8 62 fb ff ff       	call   6350 <fwp_p_ad_push>
    67ee:	4c 89 e2             	mov    %r12,%rdx
    67f1:	48 89 d9             	mov    %rbx,%rcx
    67f4:	48 89 de             	mov    %rbx,%rsi
    67f7:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    67fd:	4c 89 e7             	mov    %r12,%rdi
    6800:	48 89 c5             	mov    %rax,%rbp
    6803:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6807:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    680d:	e8 3e fb ff ff       	call   6350 <fwp_p_ad_push>
    6812:	48 89 c7             	mov    %rax,%rdi
    6815:	e8 a6 e7 ff ff       	call   4fc0 <caf75>
    681a:	48 89 c6             	mov    %rax,%rsi
    681d:	e8 9e e7 ff ff       	call   4fc0 <caf75>
    6822:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6828:	48 89 ea             	mov    %rbp,%rdx
    682b:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6831:	48 89 c1             	mov    %rax,%rcx
    6834:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6839:	e8 12 fb ff ff       	call   6350 <fwp_p_ad_push>
    683e:	48 83 c4 28          	add    $0x28,%rsp
    6842:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    6847:	5b                   	pop    %rbx
    6848:	5d                   	pop    %rbp
    6849:	41 5c                	pop    %r12
    684b:	41 5d                	pop    %r13
    684d:	c3                   	ret
    684e:	66 90                	xchg   %ax,%ax

0000000000006850 <w176.constprop.0>:
    6850:	41 54                	push   %r12
    6852:	55                   	push   %rbp
    6853:	53                   	push   %rbx
    6854:	48 83 ec 10          	sub    $0x10,%rsp
    6858:	4c 8b 27             	mov    (%rdi),%r12
    685b:	4d 85 e4             	test   %r12,%r12
    685e:	74 78                	je     68d8 <w176.constprop.0+0x88>
    6860:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    6867:	00 00 
    6869:	48 89 fd             	mov    %rdi,%rbp
    686c:	31 db                	xor    %ebx,%ebx
    686e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6875:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    687c:	00 00 00 00 
    6880:	4c 8b 44 dd 10       	mov    0x10(%rbp,%rbx,8),%r8
    6885:	f2 0f 10 44 dd 08    	movsd  0x8(%rbp,%rbx,8),%xmm0
    688b:	48 83 c3 02          	add    $0x2,%rbx
    688f:	e8 2c e7 ff ff       	call   4fc0 <caf75>
    6894:	48 89 c6             	mov    %rax,%rsi
    6897:	e8 24 e7 ff ff       	call   4fc0 <caf75>
    689c:	f2 0f 58 44 24 08    	addsd  0x8(%rsp),%xmm0
    68a2:	4c 89 c2             	mov    %r8,%rdx
    68a5:	48 89 c1             	mov    %rax,%rcx
    68a8:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    68ae:	e8 9d fa ff ff       	call   6350 <fwp_p_ad_push>
    68b3:	48 89 c7             	mov    %rax,%rdi
    68b6:	4c 39 e3             	cmp    %r12,%rbx
    68b9:	72 c5                	jb     6880 <w176.constprop.0+0x30>
    68bb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    68c0:	48 83 c4 10          	add    $0x10,%rsp
    68c4:	5b                   	pop    %rbx
    68c5:	5d                   	pop    %rbp
    68c6:	66 48 0f 6e c0       	movq   %rax,%xmm0
    68cb:	41 5c                	pop    %r12
    68cd:	48 89 f8             	mov    %rdi,%rax
    68d0:	c3                   	ret
    68d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    68d8:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    68df:	00 00 
    68e1:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    68e8:	eb d1                	jmp    68bb <w176.constprop.0+0x6b>
    68ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000068f0 <fwp_rc_share>:
    68f0:	48 8b 05 21 33 06 00 	mov    0x63321(%rip),%rax        # 69c18 <fwp_heap+0x13d8>
    68f7:	48 2b 3d f2 32 06 00 	sub    0x632f2(%rip),%rdi        # 69bf0 <fwp_heap+0x13b0>
    68fe:	48 c1 e0 10          	shl    $0x10,%rax
    6902:	48 39 c7             	cmp    %rax,%rdi
    6905:	73 4a                	jae    6951 <fwp_rc_share+0x61>
    6907:	48 89 f8             	mov    %rdi,%rax
    690a:	48 c1 e8 10          	shr    $0x10,%rax
    690e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6912:	48 8b 05 1f 33 06 00 	mov    0x6331f(%rip),%rax        # 69c38 <fwp_heap+0x13f8>
    6919:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    691d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6921:	48 85 d2             	test   %rdx,%rdx
    6924:	74 2b                	je     6951 <fwp_rc_share+0x61>
    6926:	0f b6 08             	movzbl (%rax),%ecx
    6929:	80 f9 02             	cmp    $0x2,%cl
    692c:	74 2a                	je     6958 <fwp_rc_share+0x68>
    692e:	80 f9 01             	cmp    $0x1,%cl
    6931:	75 1e                	jne    6951 <fwp_rc_share+0x61>
    6933:	8b 48 18             	mov    0x18(%rax),%ecx
    6936:	0f b7 ff             	movzwl %di,%edi
    6939:	8b 40 1c             	mov    0x1c(%rax),%eax
    693c:	48 0f af f9          	imul   %rcx,%rdi
    6940:	48 c1 ef 20          	shr    $0x20,%rdi
    6944:	48 39 c7             	cmp    %rax,%rdi
    6947:	73 08                	jae    6951 <fwp_rc_share+0x61>
    6949:	48 01 fa             	add    %rdi,%rdx
    694c:	80 3a 00             	cmpb   $0x0,(%rdx)
    694f:	75 0d                	jne    695e <fwp_rc_share+0x6e>
    6951:	c3                   	ret
    6952:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6958:	66 85 ff             	test   %di,%di
    695b:	74 ef                	je     694c <fwp_rc_share+0x5c>
    695d:	c3                   	ret
    695e:	50                   	push   %rax
    695f:	48 8d 3d 2a 61 00 00 	lea    0x612a(%rip),%rdi        # ca90 <_IO_stdin_used+0xa90>
    6966:	e8 e5 da ff ff       	call   4450 <fwp_trap>
    696b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006970 <fwp_rc_free_obj>:
    6970:	48 8b 15 a1 32 06 00 	mov    0x632a1(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    6977:	48 89 f8             	mov    %rdi,%rax
    697a:	48 2b 05 6f 32 06 00 	sub    0x6326f(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    6981:	48 c1 e2 10          	shl    $0x10,%rdx
    6985:	48 39 d0             	cmp    %rdx,%rax
    6988:	73 5b                	jae    69e5 <fwp_rc_free_obj+0x75>
    698a:	48 89 c2             	mov    %rax,%rdx
    698d:	48 c1 ea 10          	shr    $0x10,%rdx
    6991:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6995:	48 8b 15 9c 32 06 00 	mov    0x6329c(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    699c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    69a0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    69a4:	48 85 c9             	test   %rcx,%rcx
    69a7:	74 3c                	je     69e5 <fwp_rc_free_obj+0x75>
    69a9:	0f b6 32             	movzbl (%rdx),%esi
    69ac:	40 80 fe 02          	cmp    $0x2,%sil
    69b0:	74 2e                	je     69e0 <fwp_rc_free_obj+0x70>
    69b2:	40 80 fe 01          	cmp    $0x1,%sil
    69b6:	75 2d                	jne    69e5 <fwp_rc_free_obj+0x75>
    69b8:	8b 72 18             	mov    0x18(%rdx),%esi
    69bb:	0f b7 c0             	movzwl %ax,%eax
    69be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    69c1:	48 0f af c6          	imul   %rsi,%rax
    69c5:	48 c1 e8 20          	shr    $0x20,%rax
    69c9:	48 39 d0             	cmp    %rdx,%rax
    69cc:	73 17                	jae    69e5 <fwp_rc_free_obj+0x75>
    69ce:	48 01 c1             	add    %rax,%rcx
    69d1:	80 39 01             	cmpb   $0x1,(%rcx)
    69d4:	75 0f                	jne    69e5 <fwp_rc_free_obj+0x75>
    69d6:	e9 95 f0 ff ff       	jmp    5a70 <fwp_mem_free>
    69db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    69e0:	66 85 c0             	test   %ax,%ax
    69e3:	74 ec                	je     69d1 <fwp_rc_free_obj+0x61>
    69e5:	c3                   	ret
    69e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    69ed:	00 00 00 

00000000000069f0 <fwp_rc_dup>:
    69f0:	f3 0f 1e fa          	endbr64
    69f4:	48 8b 05 1d 32 06 00 	mov    0x6321d(%rip),%rax        # 69c18 <fwp_heap+0x13d8>
    69fb:	48 2b 3d ee 31 06 00 	sub    0x631ee(%rip),%rdi        # 69bf0 <fwp_heap+0x13b0>
    6a02:	48 c1 e0 10          	shl    $0x10,%rax
    6a06:	48 39 c7             	cmp    %rax,%rdi
    6a09:	73 60                	jae    6a6b <fwp_rc_dup+0x7b>
    6a0b:	48 89 f8             	mov    %rdi,%rax
    6a0e:	48 c1 e8 10          	shr    $0x10,%rax
    6a12:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6a16:	48 8b 05 1b 32 06 00 	mov    0x6321b(%rip),%rax        # 69c38 <fwp_heap+0x13f8>
    6a1d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6a21:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6a25:	48 85 c0             	test   %rax,%rax
    6a28:	74 41                	je     6a6b <fwp_rc_dup+0x7b>
    6a2a:	0f b6 0a             	movzbl (%rdx),%ecx
    6a2d:	80 f9 02             	cmp    $0x2,%cl
    6a30:	74 3e                	je     6a70 <fwp_rc_dup+0x80>
    6a32:	80 f9 01             	cmp    $0x1,%cl
    6a35:	75 34                	jne    6a6b <fwp_rc_dup+0x7b>
    6a37:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6a3a:	0f b7 ff             	movzwl %di,%edi
    6a3d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6a40:	48 0f af f9          	imul   %rcx,%rdi
    6a44:	48 c1 ef 20          	shr    $0x20,%rdi
    6a48:	48 39 d7             	cmp    %rdx,%rdi
    6a4b:	73 1e                	jae    6a6b <fwp_rc_dup+0x7b>
    6a4d:	48 01 f8             	add    %rdi,%rax
    6a50:	0f b6 10             	movzbl (%rax),%edx
    6a53:	84 d2                	test   %dl,%dl
    6a55:	74 14                	je     6a6b <fwp_rc_dup+0x7b>
    6a57:	8b 0d ab 3a 06 00    	mov    0x63aab(%rip),%ecx        # 6a508 <iteration_active>
    6a5d:	85 c9                	test   %ecx,%ecx
    6a5f:	75 1f                	jne    6a80 <fwp_rc_dup+0x90>
    6a61:	80 fa fd             	cmp    $0xfd,%dl
    6a64:	77 2a                	ja     6a90 <fwp_rc_dup+0xa0>
    6a66:	83 c2 01             	add    $0x1,%edx
    6a69:	88 10                	mov    %dl,(%rax)
    6a6b:	c3                   	ret
    6a6c:	0f 1f 40 00          	nopl   0x0(%rax)
    6a70:	66 85 ff             	test   %di,%di
    6a73:	74 db                	je     6a50 <fwp_rc_dup+0x60>
    6a75:	c3                   	ret
    6a76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a7d:	00 00 00 
    6a80:	48 83 05 68 3a 06 00 	addq   $0x1,0x63a68(%rip)        # 6a4f0 <iteration_retains>
    6a87:	01 
    6a88:	eb d7                	jmp    6a61 <fwp_rc_dup+0x71>
    6a8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a90:	48 89 c7             	mov    %rax,%rdi
    6a93:	e9 78 ec ff ff       	jmp    5710 <fwp_rc_wide_dup>
    6a98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6a9f:	00 

0000000000006aa0 <fwp_owned_entry173>:
    6aa0:	f3 0f 1e fa          	endbr64
    6aa4:	48 83 ec 38          	sub    $0x38,%rsp
    6aa8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6aad:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6ab4:	00 00 
    6ab6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6abb:	31 c0                	xor    %eax,%eax
    6abd:	48 8b 07             	mov    (%rdi),%rax
    6ac0:	48 03 47 10          	add    0x10(%rdi),%rax
    6ac4:	0f 80 c2 00 00 00    	jo     6b8c <fwp_owned_entry173+0xec>
    6aca:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6acf:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6ad4:	31 ff                	xor    %edi,%edi
    6ad6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6ada:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6adf:	e8 7c f6 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    6ae4:	48 8b 15 2d 31 06 00 	mov    0x6312d(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    6aeb:	48 89 c6             	mov    %rax,%rsi
    6aee:	48 2b 05 fb 30 06 00 	sub    0x630fb(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    6af5:	48 c1 e2 10          	shl    $0x10,%rdx
    6af9:	48 39 d0             	cmp    %rdx,%rax
    6afc:	73 4f                	jae    6b4d <fwp_owned_entry173+0xad>
    6afe:	48 89 c2             	mov    %rax,%rdx
    6b01:	48 c1 ea 10          	shr    $0x10,%rdx
    6b05:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b09:	48 8b 15 28 31 06 00 	mov    0x63128(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    6b10:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6b14:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6b18:	48 85 d2             	test   %rdx,%rdx
    6b1b:	74 30                	je     6b4d <fwp_owned_entry173+0xad>
    6b1d:	0f b6 39             	movzbl (%rcx),%edi
    6b20:	40 80 ff 02          	cmp    $0x2,%dil
    6b24:	74 42                	je     6b68 <fwp_owned_entry173+0xc8>
    6b26:	40 80 ff 01          	cmp    $0x1,%dil
    6b2a:	75 21                	jne    6b4d <fwp_owned_entry173+0xad>
    6b2c:	8b 79 18             	mov    0x18(%rcx),%edi
    6b2f:	0f b7 c0             	movzwl %ax,%eax
    6b32:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6b35:	48 0f af c7          	imul   %rdi,%rax
    6b39:	48 c1 e8 20          	shr    $0x20,%rax
    6b3d:	48 39 c8             	cmp    %rcx,%rax
    6b40:	73 0b                	jae    6b4d <fwp_owned_entry173+0xad>
    6b42:	48 01 c2             	add    %rax,%rdx
    6b45:	80 3a ff             	cmpb   $0xff,(%rdx)
    6b48:	74 26                	je     6b70 <fwp_owned_entry173+0xd0>
    6b4a:	c6 02 01             	movb   $0x1,(%rdx)
    6b4d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6b52:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6b59:	00 00 
    6b5b:	75 34                	jne    6b91 <fwp_owned_entry173+0xf1>
    6b5d:	48 89 f0             	mov    %rsi,%rax
    6b60:	48 83 c4 38          	add    $0x38,%rsp
    6b64:	c3                   	ret
    6b65:	0f 1f 00             	nopl   (%rax)
    6b68:	66 85 c0             	test   %ax,%ax
    6b6b:	75 e0                	jne    6b4d <fwp_owned_entry173+0xad>
    6b6d:	eb d6                	jmp    6b45 <fwp_owned_entry173+0xa5>
    6b6f:	90                   	nop
    6b70:	48 89 d7             	mov    %rdx,%rdi
    6b73:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6b78:	48 89 14 24          	mov    %rdx,(%rsp)
    6b7c:	e8 af ec ff ff       	call   5830 <fwp_rc_forget_slot>
    6b81:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6b86:	48 8b 14 24          	mov    (%rsp),%rdx
    6b8a:	eb be                	jmp    6b4a <fwp_owned_entry173+0xaa>
    6b8c:	e8 6f cb ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6b91:	e8 ba c8 ff ff       	call   3450 <__stack_chk_fail@plt>
    6b96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b9d:	00 00 00 

0000000000006ba0 <e173>:
    6ba0:	f3 0f 1e fa          	endbr64
    6ba4:	53                   	push   %rbx
    6ba5:	48 83 ec 30          	sub    $0x30,%rsp
    6ba9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6bae:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6bb5:	00 00 
    6bb7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6bbc:	31 c0                	xor    %eax,%eax
    6bbe:	48 8b 07             	mov    (%rdi),%rax
    6bc1:	48 03 47 10          	add    0x10(%rdi),%rax
    6bc5:	0f 80 c9 00 00 00    	jo     6c94 <e173+0xf4>
    6bcb:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6bd0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6bd5:	31 ff                	xor    %edi,%edi
    6bd7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6bdb:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6be0:	e8 7b f5 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    6be5:	48 8b 15 2c 30 06 00 	mov    0x6302c(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    6bec:	48 89 c3             	mov    %rax,%rbx
    6bef:	48 2b 05 fa 2f 06 00 	sub    0x62ffa(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    6bf6:	48 c1 e2 10          	shl    $0x10,%rdx
    6bfa:	48 39 d0             	cmp    %rdx,%rax
    6bfd:	73 4f                	jae    6c4e <e173+0xae>
    6bff:	48 89 c2             	mov    %rax,%rdx
    6c02:	48 c1 ea 10          	shr    $0x10,%rdx
    6c06:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c0a:	48 8b 15 27 30 06 00 	mov    0x63027(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    6c11:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c15:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c19:	48 85 d2             	test   %rdx,%rdx
    6c1c:	74 30                	je     6c4e <e173+0xae>
    6c1e:	0f b6 31             	movzbl (%rcx),%esi
    6c21:	40 80 fe 02          	cmp    $0x2,%sil
    6c25:	74 49                	je     6c70 <e173+0xd0>
    6c27:	40 80 fe 01          	cmp    $0x1,%sil
    6c2b:	75 21                	jne    6c4e <e173+0xae>
    6c2d:	8b 71 18             	mov    0x18(%rcx),%esi
    6c30:	0f b7 c0             	movzwl %ax,%eax
    6c33:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c36:	48 0f af c6          	imul   %rsi,%rax
    6c3a:	48 c1 e8 20          	shr    $0x20,%rax
    6c3e:	48 39 c8             	cmp    %rcx,%rax
    6c41:	73 0b                	jae    6c4e <e173+0xae>
    6c43:	48 01 c2             	add    %rax,%rdx
    6c46:	80 3a ff             	cmpb   $0xff,(%rdx)
    6c49:	74 35                	je     6c80 <e173+0xe0>
    6c4b:	c6 02 01             	movb   $0x1,(%rdx)
    6c4e:	48 89 df             	mov    %rbx,%rdi
    6c51:	e8 9a fc ff ff       	call   68f0 <fwp_rc_share>
    6c56:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6c5b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6c62:	00 00 
    6c64:	75 33                	jne    6c99 <e173+0xf9>
    6c66:	48 83 c4 30          	add    $0x30,%rsp
    6c6a:	48 89 d8             	mov    %rbx,%rax
    6c6d:	5b                   	pop    %rbx
    6c6e:	c3                   	ret
    6c6f:	90                   	nop
    6c70:	66 85 c0             	test   %ax,%ax
    6c73:	75 d9                	jne    6c4e <e173+0xae>
    6c75:	eb cf                	jmp    6c46 <e173+0xa6>
    6c77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c7e:	00 00 
    6c80:	48 89 d7             	mov    %rdx,%rdi
    6c83:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6c88:	e8 a3 eb ff ff       	call   5830 <fwp_rc_forget_slot>
    6c8d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6c92:	eb b7                	jmp    6c4b <e173+0xab>
    6c94:	e8 67 ca ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6c99:	e8 b2 c7 ff ff       	call   3450 <__stack_chk_fail@plt>
    6c9e:	66 90                	xchg   %ax,%ax

0000000000006ca0 <fwp_closure_drop>:
    6ca0:	48 8b 15 71 2f 06 00 	mov    0x62f71(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    6ca7:	48 89 f8             	mov    %rdi,%rax
    6caa:	48 2b 05 3f 2f 06 00 	sub    0x62f3f(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    6cb1:	48 c1 e2 10          	shl    $0x10,%rdx
    6cb5:	48 39 d0             	cmp    %rdx,%rax
    6cb8:	73 6b                	jae    6d25 <fwp_closure_drop+0x85>
    6cba:	48 89 c2             	mov    %rax,%rdx
    6cbd:	48 c1 ea 10          	shr    $0x10,%rdx
    6cc1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6cc5:	48 8b 15 6c 2f 06 00 	mov    0x62f6c(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    6ccc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6cd0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6cd4:	48 85 d2             	test   %rdx,%rdx
    6cd7:	74 4c                	je     6d25 <fwp_closure_drop+0x85>
    6cd9:	0f b6 31             	movzbl (%rcx),%esi
    6cdc:	40 80 fe 02          	cmp    $0x2,%sil
    6ce0:	74 3e                	je     6d20 <fwp_closure_drop+0x80>
    6ce2:	40 80 fe 01          	cmp    $0x1,%sil
    6ce6:	75 3d                	jne    6d25 <fwp_closure_drop+0x85>
    6ce8:	8b 71 18             	mov    0x18(%rcx),%esi
    6ceb:	0f b7 c0             	movzwl %ax,%eax
    6cee:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6cf1:	48 0f af c6          	imul   %rsi,%rax
    6cf5:	48 c1 e8 20          	shr    $0x20,%rax
    6cf9:	48 39 c8             	cmp    %rcx,%rax
    6cfc:	73 27                	jae    6d25 <fwp_closure_drop+0x85>
    6cfe:	48 01 c2             	add    %rax,%rdx
    6d01:	0f b6 02             	movzbl (%rdx),%eax
    6d04:	84 c0                	test   %al,%al
    6d06:	74 1d                	je     6d25 <fwp_closure_drop+0x85>
    6d08:	3c 01                	cmp    $0x1,%al
    6d0a:	74 24                	je     6d30 <fwp_closure_drop+0x90>
    6d0c:	3c ff                	cmp    $0xff,%al
    6d0e:	74 48                	je     6d58 <fwp_closure_drop+0xb8>
    6d10:	83 e8 01             	sub    $0x1,%eax
    6d13:	88 02                	mov    %al,(%rdx)
    6d15:	c3                   	ret
    6d16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d1d:	00 00 00 
    6d20:	66 85 c0             	test   %ax,%ax
    6d23:	74 dc                	je     6d01 <fwp_closure_drop+0x61>
    6d25:	c3                   	ret
    6d26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d2d:	00 00 00 
    6d30:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6d37:	ff ff 
    6d39:	48 85 c0             	test   %rax,%rax
    6d3c:	74 12                	je     6d50 <fwp_closure_drop+0xb0>
    6d3e:	48 89 fe             	mov    %rdi,%rsi
    6d41:	48 89 c7             	mov    %rax,%rdi
    6d44:	e9 67 d7 ff ff       	jmp    44b0 <fwp_closure_drop_push>
    6d49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6d50:	e9 0b d9 ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    6d55:	0f 1f 00             	nopl   (%rax)
    6d58:	48 89 d0             	mov    %rdx,%rax
    6d5b:	48 8d 35 de 1a 06 00 	lea    0x61ade(%rip),%rsi        # 68840 <fwp_heap>
    6d62:	48 83 ec 18          	sub    $0x18,%rsp
    6d66:	48 c1 e8 11          	shr    $0x11,%rax
    6d6a:	48 31 d0             	xor    %rdx,%rax
    6d6d:	48 89 c1             	mov    %rax,%rcx
    6d70:	48 c1 e9 09          	shr    $0x9,%rcx
    6d74:	48 31 c8             	xor    %rcx,%rax
    6d77:	0f b6 c8             	movzbl %al,%ecx
    6d7a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6d81:	00 
    6d82:	48 85 c0             	test   %rax,%rax
    6d85:	75 22                	jne    6da9 <fwp_closure_drop+0x109>
    6d87:	eb 59                	jmp    6de2 <fwp_closure_drop+0x142>
    6d89:	90                   	nop
    6d8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d91:	00 00 00 00 
    6d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d9c:	00 00 00 00 
    6da0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6da4:	48 85 c0             	test   %rax,%rax
    6da7:	74 39                	je     6de2 <fwp_closure_drop+0x142>
    6da9:	48 89 c1             	mov    %rax,%rcx
    6dac:	48 39 10             	cmp    %rdx,(%rax)
    6daf:	75 ef                	jne    6da0 <fwp_closure_drop+0x100>
    6db1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6db5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6db9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6dbd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6dc4:	74 05                	je     6dcb <fwp_closure_drop+0x12b>
    6dc6:	48 83 c4 18          	add    $0x18,%rsp
    6dca:	c3                   	ret
    6dcb:	48 89 d7             	mov    %rdx,%rdi
    6dce:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6dd3:	e8 58 ea ff ff       	call   5830 <fwp_rc_forget_slot>
    6dd8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6ddd:	c6 02 fe             	movb   $0xfe,(%rdx)
    6de0:	eb e4                	jmp    6dc6 <fwp_closure_drop+0x126>
    6de2:	48 8d 3d 07 5c 00 00 	lea    0x5c07(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    6de9:	e8 62 d6 ff ff       	call   4450 <fwp_trap>
    6dee:	66 90                	xchg   %ax,%ax

0000000000006df0 <fwp_owned_tape_release>:
    6df0:	48 85 ff             	test   %rdi,%rdi
    6df3:	0f 84 f7 00 00 00    	je     6ef0 <fwp_owned_tape_release+0x100>
    6df9:	41 54                	push   %r12
    6dfb:	55                   	push   %rbp
    6dfc:	53                   	push   %rbx
    6dfd:	48 8b 07             	mov    (%rdi),%rax
    6e00:	48 85 c0             	test   %rax,%rax
    6e03:	74 08                	je     6e0d <fwp_owned_tape_release+0x1d>
    6e05:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6e09:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6e0d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6e11:	48 85 d2             	test   %rdx,%rdx
    6e14:	74 03                	je     6e19 <fwp_owned_tape_release+0x29>
    6e16:	48 89 02             	mov    %rax,(%rdx)
    6e19:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6e1d:	48 89 fb             	mov    %rdi,%rbx
    6e20:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6e24:	48 85 c0             	test   %rax,%rax
    6e27:	0f 84 89 00 00 00    	je     6eb6 <fwp_owned_tape_release+0xc6>
    6e2d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6e31:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6e35:	7e 47                	jle    6e7e <fwp_owned_tape_release+0x8e>
    6e37:	31 ed                	xor    %ebp,%ebp
    6e39:	eb 0d                	jmp    6e48 <fwp_owned_tape_release+0x58>
    6e3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6e40:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6e44:	48 8b 40 68          	mov    0x68(%rax),%rax
    6e48:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6e4c:	49 89 ec             	mov    %rbp,%r12
    6e4f:	48 83 c5 01          	add    $0x1,%rbp
    6e53:	49 c1 e4 04          	shl    $0x4,%r12
    6e57:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6e5b:	ff d0                	call   *%rax
    6e5d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6e61:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6e66:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6e6a:	ff 50 68             	call   *0x68(%rax)
    6e6d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6e71:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6e75:	48 39 e8             	cmp    %rbp,%rax
    6e78:	7f c6                	jg     6e40 <fwp_owned_tape_release+0x50>
    6e7a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6e7e:	31 ed                	xor    %ebp,%ebp
    6e80:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6e85:	7e 28                	jle    6eaf <fwp_owned_tape_release+0xbf>
    6e87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6e8e:	00 00 
    6e90:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6e94:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6e98:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6e9c:	74 07                	je     6ea5 <fwp_owned_tape_release+0xb5>
    6e9e:	ff 52 68             	call   *0x68(%rdx)
    6ea1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6ea5:	48 83 c5 01          	add    $0x1,%rbp
    6ea9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6ead:	7f e1                	jg     6e90 <fwp_owned_tape_release+0xa0>
    6eaf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6eb3:	ff 52 68             	call   *0x68(%rdx)
    6eb6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6eba:	e8 e1 fd ff ff       	call   6ca0 <fwp_closure_drop>
    6ebf:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6ec3:	e8 d8 fd ff ff       	call   6ca0 <fwp_closure_drop>
    6ec8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6ecc:	e8 cf fd ff ff       	call   6ca0 <fwp_closure_drop>
    6ed1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6ed5:	e8 96 eb ff ff       	call   5a70 <fwp_mem_free>
    6eda:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6ede:	e8 8d eb ff ff       	call   5a70 <fwp_mem_free>
    6ee3:	48 89 df             	mov    %rbx,%rdi
    6ee6:	5b                   	pop    %rbx
    6ee7:	5d                   	pop    %rbp
    6ee8:	41 5c                	pop    %r12
    6eea:	e9 81 eb ff ff       	jmp    5a70 <fwp_mem_free>
    6eef:	90                   	nop
    6ef0:	c3                   	ret
    6ef1:	0f 1f 40 00          	nopl   0x0(%rax)
    6ef5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6efc:	00 00 00 00 

0000000000006f00 <fwp_tape_finish>:
    6f00:	f3 0f 1e fa          	endbr64
    6f04:	41 55                	push   %r13
    6f06:	41 54                	push   %r12
    6f08:	55                   	push   %rbp
    6f09:	53                   	push   %rbx
    6f0a:	48 83 ec 48          	sub    $0x48,%rsp
    6f0e:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    6f15:	00 00 
    6f17:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    6f1c:	48 8d 3d 9d 91 01 00 	lea    0x1919d(%rip),%rdi        # 200c0 <fwp_tape_workspace>
    6f23:	e8 78 e2 ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    6f28:	48 83 3d d8 91 01 00 	cmpq   $0x0,0x191d8(%rip)        # 20108 <fwp_ntapes>
    6f2f:	00 
    6f30:	48 c7 05 6d 91 01 00 	movq   $0x0,0x1916d(%rip)        # 200a8 <fwp_tape_cached_bytes>
    6f37:	00 00 00 00 
    6f3b:	7e 79                	jle    6fb6 <fwp_tape_finish+0xb6>
    6f3d:	45 31 e4             	xor    %r12d,%r12d
    6f40:	31 ed                	xor    %ebp,%ebp
    6f42:	0f 1f 00             	nopl   (%rax)
    6f45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f4c:	00 00 00 00 
    6f50:	48 8b 1d b9 91 01 00 	mov    0x191b9(%rip),%rbx        # 20110 <fwp_tapes>
    6f57:	48 83 c5 01          	add    $0x1,%rbp
    6f5b:	4c 01 e3             	add    %r12,%rbx
    6f5e:	49 83 c4 68          	add    $0x68,%r12
    6f62:	48 89 df             	mov    %rbx,%rdi
    6f65:	e8 26 cd ff ff       	call   3c90 <fwp_tape_unlink_scope>
    6f6a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    6f6f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    6f74:	48 89 e7             	mov    %rsp,%rdi
    6f77:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6f7b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    6f7f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6f84:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6f89:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    6f8e:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    6f92:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    6f97:	e8 04 e2 ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    6f9c:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6fa0:	e8 4b fe ff ff       	call   6df0 <fwp_owned_tape_release>
    6fa5:	48 39 2d 5c 91 01 00 	cmp    %rbp,0x1915c(%rip)        # 20108 <fwp_ntapes>
    6fac:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6fb3:	00 
    6fb4:	7f 9a                	jg     6f50 <fwp_tape_finish+0x50>
    6fb6:	48 8b 3d 53 91 01 00 	mov    0x19153(%rip),%rdi        # 20110 <fwp_tapes>
    6fbd:	48 85 ff             	test   %rdi,%rdi
    6fc0:	74 05                	je     6fc7 <fwp_tape_finish+0xc7>
    6fc2:	e8 69 e1 ff ff       	call   5130 <ad_raw_free.part.0>
    6fc7:	48 c7 05 3e 91 01 00 	movq   $0x0,0x1913e(%rip)        # 20110 <fwp_tapes>
    6fce:	00 00 00 00 
    6fd2:	48 c7 05 23 91 01 00 	movq   $0x0,0x19123(%rip)        # 20100 <fwp_tapes_cap>
    6fd9:	00 00 00 00 
    6fdd:	48 c7 05 20 91 01 00 	movq   $0x0,0x19120(%rip)        # 20108 <fwp_ntapes>
    6fe4:	00 00 00 00 
    6fe8:	48 c7 05 05 91 01 00 	movq   $0x0,0x19105(%rip)        # 200f8 <fwp_tape_next_slot>
    6fef:	00 00 00 00 
    6ff3:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    6ff8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6fff:	00 00 
    7001:	75 0b                	jne    700e <fwp_tape_finish+0x10e>
    7003:	48 83 c4 48          	add    $0x48,%rsp
    7007:	5b                   	pop    %rbx
    7008:	5d                   	pop    %rbp
    7009:	41 5c                	pop    %r12
    700b:	41 5d                	pop    %r13
    700d:	c3                   	ret
    700e:	e8 3d c4 ff ff       	call   3450 <__stack_chk_fail@plt>
    7013:	66 90                	xchg   %ax,%ax
    7015:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    701c:	00 00 00 00 

0000000000007020 <fwp_tape_scope_release>:
    7020:	f3 0f 1e fa          	endbr64
    7024:	41 55                	push   %r13
    7026:	41 54                	push   %r12
    7028:	55                   	push   %rbp
    7029:	53                   	push   %rbx
    702a:	48 83 ec 48          	sub    $0x48,%rsp
    702e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7035:	00 00 
    7037:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    703c:	48 63 07             	movslq (%rdi),%rax
    703f:	85 c0                	test   %eax,%eax
    7041:	0f 88 e8 00 00 00    	js     712f <fwp_tape_scope_release+0x10f>
    7047:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    704e:	ec c4 4e 
    7051:	48 89 fb             	mov    %rdi,%rbx
    7054:	48 89 e5             	mov    %rsp,%rbp
    7057:	eb 1f                	jmp    7078 <fwp_tape_scope_release+0x58>
    7059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7060:	e8 3b e1 ff ff       	call   51a0 <fwp_tape_buffers_dispose>
    7065:	4c 89 ef             	mov    %r13,%rdi
    7068:	e8 83 fd ff ff       	call   6df0 <fwp_owned_tape_release>
    706d:	48 63 03             	movslq (%rbx),%rax
    7070:	85 c0                	test   %eax,%eax
    7072:	0f 88 b7 00 00 00    	js     712f <fwp_tape_scope_release+0x10f>
    7078:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    707c:	48 8b 35 8d 90 01 00 	mov    0x1908d(%rip),%rsi        # 20110 <fwp_tapes>
    7083:	4c 01 c6             	add    %r8,%rsi
    7086:	48 89 f7             	mov    %rsi,%rdi
    7089:	e8 02 cc ff ff       	call   3c90 <fwp_tape_unlink_scope>
    708e:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7093:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    7098:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    709f:	48 8b 46 40          	mov    0x40(%rsi),%rax
    70a3:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    70a7:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    70ae:	00 
    70af:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    70b4:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    70b9:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    70bd:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    70c2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    70c6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    70cb:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    70d2:	00 
    70d3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    70da:	00 
    70db:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    70e2:	00 
    70e3:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    70e7:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    70eb:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    70ef:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    70f3:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    70f9:	77 18                	ja     7113 <fwp_tape_scope_release+0xf3>
    70fb:	49 c1 f8 03          	sar    $0x3,%r8
    70ff:	4d 0f af c4          	imul   %r12,%r8
    7103:	4c 3b 05 ee 8f 01 00 	cmp    0x18fee(%rip),%r8        # 200f8 <fwp_tape_next_slot>
    710a:	7d 07                	jge    7113 <fwp_tape_scope_release+0xf3>
    710c:	4c 89 05 e5 8f 01 00 	mov    %r8,0x18fe5(%rip)        # 200f8 <fwp_tape_next_slot>
    7113:	48 89 ef             	mov    %rbp,%rdi
    7116:	4d 85 ed             	test   %r13,%r13
    7119:	0f 85 41 ff ff ff    	jne    7060 <fwp_tape_scope_release+0x40>
    711f:	e8 9c e1 ff ff       	call   52c0 <fwp_tape_buffers_release>
    7124:	48 63 03             	movslq (%rbx),%rax
    7127:	85 c0                	test   %eax,%eax
    7129:	0f 89 49 ff ff ff    	jns    7078 <fwp_tape_scope_release+0x58>
    712f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7134:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    713b:	00 00 
    713d:	75 0b                	jne    714a <fwp_tape_scope_release+0x12a>
    713f:	48 83 c4 48          	add    $0x48,%rsp
    7143:	5b                   	pop    %rbx
    7144:	5d                   	pop    %rbp
    7145:	41 5c                	pop    %r12
    7147:	41 5d                	pop    %r13
    7149:	c3                   	ret
    714a:	e8 01 c3 ff ff       	call   3450 <__stack_chk_fail@plt>
    714f:	90                   	nop

0000000000007150 <fwp_drop4>:
    7150:	48 8b 0d c1 2a 06 00 	mov    0x62ac1(%rip),%rcx        # 69c18 <fwp_heap+0x13d8>
    7157:	48 89 f8             	mov    %rdi,%rax
    715a:	48 2b 05 8f 2a 06 00 	sub    0x62a8f(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    7161:	48 c1 e1 10          	shl    $0x10,%rcx
    7165:	48 39 c8             	cmp    %rcx,%rax
    7168:	0f 83 42 01 00 00    	jae    72b0 <fwp_drop4+0x160>
    716e:	48 83 ec 18          	sub    $0x18,%rsp
    7172:	48 89 fa             	mov    %rdi,%rdx
    7175:	4c 8d 05 c4 16 06 00 	lea    0x616c4(%rip),%r8        # 68840 <fwp_heap>
    717c:	48 89 c1             	mov    %rax,%rcx
    717f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7186:	48 c1 e9 10          	shr    $0x10,%rcx
    718a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    718e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7192:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7196:	48 85 c9             	test   %rcx,%rcx
    7199:	74 40                	je     71db <fwp_drop4+0x8b>
    719b:	0f b6 3e             	movzbl (%rsi),%edi
    719e:	40 80 ff 02          	cmp    $0x2,%dil
    71a2:	74 3c                	je     71e0 <fwp_drop4+0x90>
    71a4:	40 80 ff 01          	cmp    $0x1,%dil
    71a8:	75 31                	jne    71db <fwp_drop4+0x8b>
    71aa:	8b 7e 18             	mov    0x18(%rsi),%edi
    71ad:	0f b7 c0             	movzwl %ax,%eax
    71b0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    71b3:	48 0f af c7          	imul   %rdi,%rax
    71b7:	48 c1 e8 20          	shr    $0x20,%rax
    71bb:	48 39 f0             	cmp    %rsi,%rax
    71be:	73 1b                	jae    71db <fwp_drop4+0x8b>
    71c0:	48 01 c1             	add    %rax,%rcx
    71c3:	0f b6 01             	movzbl (%rcx),%eax
    71c6:	84 c0                	test   %al,%al
    71c8:	74 11                	je     71db <fwp_drop4+0x8b>
    71ca:	3c 01                	cmp    $0x1,%al
    71cc:	74 22                	je     71f0 <fwp_drop4+0xa0>
    71ce:	3c ff                	cmp    $0xff,%al
    71d0:	0f 84 0a 01 00 00    	je     72e0 <fwp_drop4+0x190>
    71d6:	83 e8 01             	sub    $0x1,%eax
    71d9:	88 01                	mov    %al,(%rcx)
    71db:	48 83 c4 18          	add    $0x18,%rsp
    71df:	c3                   	ret
    71e0:	66 85 c0             	test   %ax,%ax
    71e3:	74 de                	je     71c3 <fwp_drop4+0x73>
    71e5:	48 83 c4 18          	add    $0x18,%rsp
    71e9:	c3                   	ret
    71ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    71f0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    71f4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    71fb:	48 89 f8             	mov    %rdi,%rax
    71fe:	48 c1 e1 10          	shl    $0x10,%rcx
    7202:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7209:	48 39 c8             	cmp    %rcx,%rax
    720c:	73 62                	jae    7270 <fwp_drop4+0x120>
    720e:	48 89 c1             	mov    %rax,%rcx
    7211:	48 c1 e9 10          	shr    $0x10,%rcx
    7215:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7219:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    721d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7221:	48 85 c9             	test   %rcx,%rcx
    7224:	74 4a                	je     7270 <fwp_drop4+0x120>
    7226:	44 0f b6 0e          	movzbl (%rsi),%r9d
    722a:	41 80 f9 02          	cmp    $0x2,%r9b
    722e:	0f 84 9c 00 00 00    	je     72d0 <fwp_drop4+0x180>
    7234:	41 80 f9 01          	cmp    $0x1,%r9b
    7238:	75 36                	jne    7270 <fwp_drop4+0x120>
    723a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    723e:	0f b7 c0             	movzwl %ax,%eax
    7241:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7244:	49 0f af c1          	imul   %r9,%rax
    7248:	48 c1 e8 20          	shr    $0x20,%rax
    724c:	48 39 f0             	cmp    %rsi,%rax
    724f:	73 1f                	jae    7270 <fwp_drop4+0x120>
    7251:	48 01 c1             	add    %rax,%rcx
    7254:	0f b6 01             	movzbl (%rcx),%eax
    7257:	84 c0                	test   %al,%al
    7259:	74 15                	je     7270 <fwp_drop4+0x120>
    725b:	3c 01                	cmp    $0x1,%al
    725d:	74 59                	je     72b8 <fwp_drop4+0x168>
    725f:	3c ff                	cmp    $0xff,%al
    7261:	0f 84 ff 00 00 00    	je     7366 <fwp_drop4+0x216>
    7267:	83 e8 01             	sub    $0x1,%eax
    726a:	88 01                	mov    %al,(%rcx)
    726c:	0f 1f 40 00          	nopl   0x0(%rax)
    7270:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7274:	48 89 d7             	mov    %rdx,%rdi
    7277:	48 89 0c 24          	mov    %rcx,(%rsp)
    727b:	e8 f0 f6 ff ff       	call   6970 <fwp_rc_free_obj>
    7280:	4c 8d 05 b9 15 06 00 	lea    0x615b9(%rip),%r8        # 68840 <fwp_heap>
    7287:	48 8b 04 24          	mov    (%rsp),%rax
    728b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7292:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7299:	48 c1 e2 10          	shl    $0x10,%rdx
    729d:	48 39 d0             	cmp    %rdx,%rax
    72a0:	0f 83 35 ff ff ff    	jae    71db <fwp_drop4+0x8b>
    72a6:	48 8b 14 24          	mov    (%rsp),%rdx
    72aa:	e9 cd fe ff ff       	jmp    717c <fwp_drop4+0x2c>
    72af:	90                   	nop
    72b0:	c3                   	ret
    72b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    72b8:	48 89 14 24          	mov    %rdx,(%rsp)
    72bc:	e8 af f6 ff ff       	call   6970 <fwp_rc_free_obj>
    72c1:	48 8b 14 24          	mov    (%rsp),%rdx
    72c5:	eb a9                	jmp    7270 <fwp_drop4+0x120>
    72c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    72ce:	00 00 
    72d0:	66 85 c0             	test   %ax,%ax
    72d3:	75 9b                	jne    7270 <fwp_drop4+0x120>
    72d5:	e9 7a ff ff ff       	jmp    7254 <fwp_drop4+0x104>
    72da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    72e0:	48 89 c8             	mov    %rcx,%rax
    72e3:	48 c1 e8 11          	shr    $0x11,%rax
    72e7:	48 31 c8             	xor    %rcx,%rax
    72ea:	48 89 c2             	mov    %rax,%rdx
    72ed:	48 c1 ea 09          	shr    $0x9,%rdx
    72f1:	48 31 d0             	xor    %rdx,%rax
    72f4:	0f b6 d0             	movzbl %al,%edx
    72f7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    72fe:	00 
    72ff:	48 85 c0             	test   %rax,%rax
    7302:	75 29                	jne    732d <fwp_drop4+0x1dd>
    7304:	e9 e3 00 00 00       	jmp    73ec <fwp_drop4+0x29c>
    7309:	90                   	nop
    730a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7311:	00 00 00 00 
    7315:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    731c:	00 00 00 00 
    7320:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7324:	48 85 c0             	test   %rax,%rax
    7327:	0f 84 bf 00 00 00    	je     73ec <fwp_drop4+0x29c>
    732d:	48 89 c2             	mov    %rax,%rdx
    7330:	48 39 08             	cmp    %rcx,(%rax)
    7333:	75 eb                	jne    7320 <fwp_drop4+0x1d0>
    7335:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7339:	48 83 ea 01          	sub    $0x1,%rdx
    733d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7341:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7348:	0f 85 8d fe ff ff    	jne    71db <fwp_drop4+0x8b>
    734e:	48 89 cf             	mov    %rcx,%rdi
    7351:	48 89 0c 24          	mov    %rcx,(%rsp)
    7355:	e8 d6 e4 ff ff       	call   5830 <fwp_rc_forget_slot>
    735a:	48 8b 0c 24          	mov    (%rsp),%rcx
    735e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7361:	e9 75 fe ff ff       	jmp    71db <fwp_drop4+0x8b>
    7366:	48 89 ce             	mov    %rcx,%rsi
    7369:	48 c1 ee 11          	shr    $0x11,%rsi
    736d:	48 31 ce             	xor    %rcx,%rsi
    7370:	48 89 f0             	mov    %rsi,%rax
    7373:	48 c1 e8 09          	shr    $0x9,%rax
    7377:	48 31 c6             	xor    %rax,%rsi
    737a:	40 0f b6 f6          	movzbl %sil,%esi
    737e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7385:	00 
    7386:	48 85 c0             	test   %rax,%rax
    7389:	75 1e                	jne    73a9 <fwp_drop4+0x259>
    738b:	eb 5f                	jmp    73ec <fwp_drop4+0x29c>
    738d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7394:	00 
    7395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    739c:	00 00 00 00 
    73a0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    73a4:	48 85 c0             	test   %rax,%rax
    73a7:	74 43                	je     73ec <fwp_drop4+0x29c>
    73a9:	48 89 c6             	mov    %rax,%rsi
    73ac:	48 39 08             	cmp    %rcx,(%rax)
    73af:	75 ef                	jne    73a0 <fwp_drop4+0x250>
    73b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    73b5:	48 83 ee 01          	sub    $0x1,%rsi
    73b9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    73bd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    73c4:	0f 85 a6 fe ff ff    	jne    7270 <fwp_drop4+0x120>
    73ca:	48 89 cf             	mov    %rcx,%rdi
    73cd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    73d2:	48 89 0c 24          	mov    %rcx,(%rsp)
    73d6:	e8 55 e4 ff ff       	call   5830 <fwp_rc_forget_slot>
    73db:	48 8b 0c 24          	mov    (%rsp),%rcx
    73df:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    73e4:	c6 01 fe             	movb   $0xfe,(%rcx)
    73e7:	e9 84 fe ff ff       	jmp    7270 <fwp_drop4+0x120>
    73ec:	48 8d 3d fd 55 00 00 	lea    0x55fd(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    73f3:	e8 58 d0 ff ff       	call   4450 <fwp_trap>
    73f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    73ff:	00 

0000000000007400 <fwp_arg_drop37>:
    7400:	f3 0f 1e fa          	endbr64
    7404:	85 f6                	test   %esi,%esi
    7406:	75 04                	jne    740c <fwp_arg_drop37+0xc>
    7408:	85 d2                	test   %edx,%edx
    740a:	75 04                	jne    7410 <fwp_arg_drop37+0x10>
    740c:	c3                   	ret
    740d:	0f 1f 00             	nopl   (%rax)
    7410:	48 8b 3f             	mov    (%rdi),%rdi
    7413:	e9 38 fd ff ff       	jmp    7150 <fwp_drop4>
    7418:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    741f:	00 

0000000000007420 <fwp_task_dispose>:
    7420:	53                   	push   %rbx
    7421:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7425:	0f 84 1b c3 ff ff    	je     3746 <fwp_task_dispose.cold>
    742b:	48 89 fb             	mov    %rdi,%rbx
    742e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7433:	0f 85 0d c3 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7439:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    743d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7444:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    744b:	00 
    744c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7450:	48 85 ff             	test   %rdi,%rdi
    7453:	74 07                	je     745c <fwp_task_dispose+0x3c>
    7455:	48 85 c0             	test   %rax,%rax
    7458:	74 02                	je     745c <fwp_task_dispose+0x3c>
    745a:	ff d0                	call   *%rax
    745c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7463:	e8 08 e6 ff ff       	call   5a70 <fwp_mem_free>
    7468:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    746f:	00 00 00 00 
    7473:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7477:	74 6f                	je     74e8 <fwp_task_dispose+0xc8>
    7479:	48 8b 15 98 27 06 00 	mov    0x62798(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    7480:	48 89 d8             	mov    %rbx,%rax
    7483:	48 2b 05 66 27 06 00 	sub    0x62766(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    748a:	48 c1 e2 10          	shl    $0x10,%rdx
    748e:	48 39 d0             	cmp    %rdx,%rax
    7491:	73 4c                	jae    74df <fwp_task_dispose+0xbf>
    7493:	48 89 c2             	mov    %rax,%rdx
    7496:	48 c1 ea 10          	shr    $0x10,%rdx
    749a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    749e:	48 8b 15 93 27 06 00 	mov    0x62793(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    74a5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    74a9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    74ad:	48 85 c9             	test   %rcx,%rcx
    74b0:	74 2d                	je     74df <fwp_task_dispose+0xbf>
    74b2:	0f b6 32             	movzbl (%rdx),%esi
    74b5:	40 80 fe 02          	cmp    $0x2,%sil
    74b9:	74 3d                	je     74f8 <fwp_task_dispose+0xd8>
    74bb:	40 80 fe 01          	cmp    $0x1,%sil
    74bf:	75 1e                	jne    74df <fwp_task_dispose+0xbf>
    74c1:	8b 72 18             	mov    0x18(%rdx),%esi
    74c4:	0f b7 c0             	movzwl %ax,%eax
    74c7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    74ca:	48 0f af c6          	imul   %rsi,%rax
    74ce:	48 c1 e8 20          	shr    $0x20,%rax
    74d2:	48 39 d0             	cmp    %rdx,%rax
    74d5:	73 08                	jae    74df <fwp_task_dispose+0xbf>
    74d7:	48 01 c1             	add    %rax,%rcx
    74da:	80 39 01             	cmpb   $0x1,(%rcx)
    74dd:	74 09                	je     74e8 <fwp_task_dispose+0xc8>
    74df:	5b                   	pop    %rbx
    74e0:	c3                   	ret
    74e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    74e8:	48 89 df             	mov    %rbx,%rdi
    74eb:	5b                   	pop    %rbx
    74ec:	e9 7f e5 ff ff       	jmp    5a70 <fwp_mem_free>
    74f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    74f8:	66 85 c0             	test   %ax,%ax
    74fb:	74 dd                	je     74da <fwp_task_dispose+0xba>
    74fd:	5b                   	pop    %rbx
    74fe:	c3                   	ret
    74ff:	90                   	nop

0000000000007500 <fwp_free_zombie>:
    7500:	48 8b 15 09 13 06 00 	mov    0x61309(%rip),%rdx        # 68810 <fwp_zombie>
    7507:	48 85 d2             	test   %rdx,%rdx
    750a:	0f 84 98 00 00 00    	je     75a8 <fwp_free_zombie+0xa8>
    7510:	48 3b 15 09 13 06 00 	cmp    0x61309(%rip),%rdx        # 68820 <fwp_cur>
    7517:	0f 84 8b 00 00 00    	je     75a8 <fwp_free_zombie+0xa8>
    751d:	48 83 ec 18          	sub    $0x18,%rsp
    7521:	48 63 05 cc 0c 06 00 	movslq 0x60ccc(%rip),%rax        # 681f4 <fwp_stack_pool_n>
    7528:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    752c:	83 f8 3f             	cmp    $0x3f,%eax
    752f:	7f 7f                	jg     75b0 <fwp_free_zombie+0xb0>
    7531:	8d 48 01             	lea    0x1(%rax),%ecx
    7534:	89 0d ba 0c 06 00    	mov    %ecx,0x60cba(%rip)        # 681f4 <fwp_stack_pool_n>
    753a:	48 8d 0d bf 0c 06 00 	lea    0x60cbf(%rip),%rcx        # 68200 <fwp_stack_pool>
    7541:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7545:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    754c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7550:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7557:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    755b:	48 85 c9             	test   %rcx,%rcx
    755e:	0f 84 fc 00 00 00    	je     7660 <fwp_free_zombie+0x160>
    7564:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    756b:	48 85 c0             	test   %rax,%rax
    756e:	74 07                	je     7577 <fwp_free_zombie+0x77>
    7570:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7577:	8b 42 5c             	mov    0x5c(%rdx),%eax
    757a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    757e:	48 c7 05 87 12 06 00 	movq   $0x0,0x61287(%rip)        # 68810 <fwp_zombie>
    7585:	00 00 00 00 
    7589:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7590:	85 c0                	test   %eax,%eax
    7592:	74 34                	je     75c8 <fwp_free_zombie+0xc8>
    7594:	83 f8 01             	cmp    $0x1,%eax
    7597:	0f 84 b3 00 00 00    	je     7650 <fwp_free_zombie+0x150>
    759d:	48 83 c4 18          	add    $0x18,%rsp
    75a1:	c3                   	ret
    75a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75a8:	c3                   	ret
    75a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    75b0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    75b4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    75b9:	e8 02 c0 ff ff       	call   35c0 <munmap@plt>
    75be:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    75c3:	eb 80                	jmp    7545 <fwp_free_zombie+0x45>
    75c5:	0f 1f 00             	nopl   (%rax)
    75c8:	48 8b 0d 49 26 06 00 	mov    0x62649(%rip),%rcx        # 69c18 <fwp_heap+0x13d8>
    75cf:	48 89 d0             	mov    %rdx,%rax
    75d2:	48 2b 05 17 26 06 00 	sub    0x62617(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    75d9:	48 c1 e1 10          	shl    $0x10,%rcx
    75dd:	48 39 c8             	cmp    %rcx,%rax
    75e0:	73 bb                	jae    759d <fwp_free_zombie+0x9d>
    75e2:	48 89 c1             	mov    %rax,%rcx
    75e5:	48 c1 e9 10          	shr    $0x10,%rcx
    75e9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    75ed:	48 8b 0d 44 26 06 00 	mov    0x62644(%rip),%rcx        # 69c38 <fwp_heap+0x13f8>
    75f4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    75f8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    75fc:	48 85 c9             	test   %rcx,%rcx
    75ff:	74 9c                	je     759d <fwp_free_zombie+0x9d>
    7601:	0f b6 3e             	movzbl (%rsi),%edi
    7604:	40 80 ff 02          	cmp    $0x2,%dil
    7608:	74 66                	je     7670 <fwp_free_zombie+0x170>
    760a:	40 80 ff 01          	cmp    $0x1,%dil
    760e:	75 8d                	jne    759d <fwp_free_zombie+0x9d>
    7610:	8b 7e 18             	mov    0x18(%rsi),%edi
    7613:	0f b7 c0             	movzwl %ax,%eax
    7616:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7619:	48 0f af c7          	imul   %rdi,%rax
    761d:	48 c1 e8 20          	shr    $0x20,%rax
    7621:	48 39 f0             	cmp    %rsi,%rax
    7624:	0f 83 73 ff ff ff    	jae    759d <fwp_free_zombie+0x9d>
    762a:	48 01 c1             	add    %rax,%rcx
    762d:	0f b6 01             	movzbl (%rcx),%eax
    7630:	84 c0                	test   %al,%al
    7632:	0f 84 65 ff ff ff    	je     759d <fwp_free_zombie+0x9d>
    7638:	3c 01                	cmp    $0x1,%al
    763a:	74 14                	je     7650 <fwp_free_zombie+0x150>
    763c:	3c ff                	cmp    $0xff,%al
    763e:	74 3b                	je     767b <fwp_free_zombie+0x17b>
    7640:	83 e8 01             	sub    $0x1,%eax
    7643:	88 01                	mov    %al,(%rcx)
    7645:	e9 53 ff ff ff       	jmp    759d <fwp_free_zombie+0x9d>
    764a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7650:	48 89 d7             	mov    %rdx,%rdi
    7653:	48 83 c4 18          	add    $0x18,%rsp
    7657:	e9 c4 fd ff ff       	jmp    7420 <fwp_task_dispose>
    765c:	0f 1f 40 00          	nopl   0x0(%rax)
    7660:	48 89 05 81 11 06 00 	mov    %rax,0x61181(%rip)        # 687e8 <fwp_tasks_active>
    7667:	e9 ff fe ff ff       	jmp    756b <fwp_free_zombie+0x6b>
    766c:	0f 1f 40 00          	nopl   0x0(%rax)
    7670:	66 85 c0             	test   %ax,%ax
    7673:	0f 85 24 ff ff ff    	jne    759d <fwp_free_zombie+0x9d>
    7679:	eb b2                	jmp    762d <fwp_free_zombie+0x12d>
    767b:	48 89 ca             	mov    %rcx,%rdx
    767e:	48 8d 35 bb 11 06 00 	lea    0x611bb(%rip),%rsi        # 68840 <fwp_heap>
    7685:	48 c1 ea 11          	shr    $0x11,%rdx
    7689:	48 31 ca             	xor    %rcx,%rdx
    768c:	48 89 d0             	mov    %rdx,%rax
    768f:	48 c1 e8 09          	shr    $0x9,%rax
    7693:	48 31 c2             	xor    %rax,%rdx
    7696:	0f b6 d2             	movzbl %dl,%edx
    7699:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    76a0:	00 
    76a1:	48 85 c0             	test   %rax,%rax
    76a4:	75 23                	jne    76c9 <fwp_free_zombie+0x1c9>
    76a6:	eb 5c                	jmp    7704 <fwp_free_zombie+0x204>
    76a8:	66 90                	xchg   %ax,%ax
    76aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    76b1:	00 00 00 00 
    76b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    76bc:	00 00 00 00 
    76c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    76c4:	48 85 c0             	test   %rax,%rax
    76c7:	74 3b                	je     7704 <fwp_free_zombie+0x204>
    76c9:	48 89 c2             	mov    %rax,%rdx
    76cc:	48 39 08             	cmp    %rcx,(%rax)
    76cf:	75 ef                	jne    76c0 <fwp_free_zombie+0x1c0>
    76d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    76d5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    76d9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    76dd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    76e4:	0f 85 b3 fe ff ff    	jne    759d <fwp_free_zombie+0x9d>
    76ea:	48 89 cf             	mov    %rcx,%rdi
    76ed:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    76f2:	e8 39 e1 ff ff       	call   5830 <fwp_rc_forget_slot>
    76f7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    76fc:	c6 01 fe             	movb   $0xfe,(%rcx)
    76ff:	e9 99 fe ff ff       	jmp    759d <fwp_free_zombie+0x9d>
    7704:	48 8d 3d e5 52 00 00 	lea    0x52e5(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    770b:	e8 40 cd ff ff       	call   4450 <fwp_trap>

0000000000007710 <fwp_block>:
    7710:	48 83 ec 08          	sub    $0x8,%rsp
    7714:	48 8b 05 ed 10 06 00 	mov    0x610ed(%rip),%rax        # 68808 <fwp_ready_head>
    771b:	48 85 c0             	test   %rax,%rax
    771e:	0f 84 1c 01 00 00    	je     7840 <fwp_block+0x130>
    7724:	90                   	nop
    7725:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    772c:	00 00 00 00 
    7730:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7737:	48 89 15 ca 10 06 00 	mov    %rdx,0x610ca(%rip)        # 68808 <fwp_ready_head>
    773e:	48 85 d2             	test   %rdx,%rdx
    7741:	0f 84 19 01 00 00    	je     7860 <fwp_block+0x150>
    7747:	48 8b 15 d2 10 06 00 	mov    0x610d2(%rip),%rdx        # 68820 <fwp_cur>
    774e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7752:	48 39 c2             	cmp    %rax,%rdx
    7755:	0f 84 d5 00 00 00    	je     7830 <fwp_block+0x120>
    775b:	48 8b 0d 46 2d 06 00 	mov    0x62d46(%rip),%rcx        # 6a4a8 <fwp_state_owners>
    7762:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7766:	48 89 05 b3 10 06 00 	mov    %rax,0x610b3(%rip)        # 68820 <fwp_cur>
    776d:	f3 0f 7e 05 5b 2d 06 	movq   0x62d5b(%rip),%xmm0        # 6a4d0 <fwp_foreign_callbacks>
    7774:	00 
    7775:	0f 16 05 44 2d 06 00 	movhps 0x62d44(%rip),%xmm0        # 6a4c0 <fwp_state>
    777c:	f3 0f 7e 0d 44 2d 06 	movq   0x62d44(%rip),%xmm1        # 6a4c8 <fwp_handlers>
    7783:	00 
    7784:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    778b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7792:	0f 16 0d 3f 2d 06 00 	movhps 0x62d3f(%rip),%xmm1        # 6a4d8 <fwp_cleanups>
    7799:	f3 0f 7e 05 17 2d 06 	movq   0x62d17(%rip),%xmm0        # 6a4b8 <fwp_state_len>
    77a0:	00 
    77a1:	0f 16 05 08 2d 06 00 	movhps 0x62d08(%rip),%xmm0        # 6a4b0 <fwp_state_cap>
    77a8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    77af:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    77b6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    77ba:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    77c1:	48 89 0d 00 2d 06 00 	mov    %rcx,0x62d00(%rip)        # 6a4c8 <fwp_handlers>
    77c8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    77cf:	48 89 0d 02 2d 06 00 	mov    %rcx,0x62d02(%rip)        # 6a4d8 <fwp_cleanups>
    77d6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    77dd:	48 89 0d ec 2c 06 00 	mov    %rcx,0x62cec(%rip)        # 6a4d0 <fwp_foreign_callbacks>
    77e4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    77eb:	48 89 0d ce 2c 06 00 	mov    %rcx,0x62cce(%rip)        # 6a4c0 <fwp_state>
    77f2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    77f9:	48 89 0d b8 2c 06 00 	mov    %rcx,0x62cb8(%rip)        # 6a4b8 <fwp_state_len>
    7800:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7807:	48 89 0d a2 2c 06 00 	mov    %rcx,0x62ca2(%rip)        # 6a4b0 <fwp_state_cap>
    780e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7815:	48 89 0d 8c 2c 06 00 	mov    %rcx,0x62c8c(%rip)        # 6a4a8 <fwp_state_owners>
    781c:	e8 5f bc ff ff       	call   3480 <swapcontext@plt>
    7821:	f3 0f 1e fa          	endbr64
    7825:	e8 d6 fc ff ff       	call   7500 <fwp_free_zombie>
    782a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7830:	8b 05 ba 09 06 00    	mov    0x609ba(%rip),%eax        # 681f0 <fwp_slice>
    7836:	85 c0                	test   %eax,%eax
    7838:	74 36                	je     7870 <fwp_block+0x160>
    783a:	48 83 c4 08          	add    $0x8,%rsp
    783e:	c3                   	ret
    783f:	90                   	nop
    7840:	e8 2b dc ff ff       	call   5470 <fwp_poll_events>
    7845:	48 8b 05 bc 0f 06 00 	mov    0x60fbc(%rip),%rax        # 68808 <fwp_ready_head>
    784c:	48 85 c0             	test   %rax,%rax
    784f:	0f 85 db fe ff ff    	jne    7730 <fwp_block+0x20>
    7855:	eb e9                	jmp    7840 <fwp_block+0x130>
    7857:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    785e:	00 00 
    7860:	48 c7 05 95 0f 06 00 	movq   $0x0,0x60f95(%rip)        # 68800 <fwp_ready_tail>
    7867:	00 00 00 00 
    786b:	e9 d7 fe ff ff       	jmp    7747 <fwp_block+0x37>
    7870:	48 8d 3d 68 49 00 00 	lea    0x4968(%rip),%rdi        # c1df <_IO_stdin_used+0x1df>
    7877:	e8 14 bb ff ff       	call   3390 <getenv@plt>
    787c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7881:	48 85 c0             	test   %rax,%rax
    7884:	74 05                	je     788b <fwp_block+0x17b>
    7886:	80 38 00             	cmpb   $0x0,(%rax)
    7889:	75 0b                	jne    7896 <fwp_block+0x186>
    788b:	89 15 5f 09 06 00    	mov    %edx,0x6095f(%rip)        # 681f0 <fwp_slice>
    7891:	48 83 c4 08          	add    $0x8,%rsp
    7895:	c3                   	ret
    7896:	ba 0a 00 00 00       	mov    $0xa,%edx
    789b:	31 f6                	xor    %esi,%esi
    789d:	48 89 c7             	mov    %rax,%rdi
    78a0:	e8 9b bc ff ff       	call   3540 <strtoll@plt>
    78a5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    78a9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    78b0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    78b5:	0f 46 d0             	cmovbe %eax,%edx
    78b8:	eb d1                	jmp    788b <fwp_block+0x17b>
    78ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000078c0 <fwp_caps173>:
    78c0:	f3 0f 1e fa          	endbr64
    78c4:	85 f6                	test   %esi,%esi
    78c6:	74 08                	je     78d0 <fwp_caps173+0x10>
    78c8:	c3                   	ret
    78c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    78d0:	48 8b 15 41 23 06 00 	mov    0x62341(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    78d7:	48 89 f8             	mov    %rdi,%rax
    78da:	48 2b 05 0f 23 06 00 	sub    0x6230f(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    78e1:	48 c1 e2 10          	shl    $0x10,%rdx
    78e5:	48 39 d0             	cmp    %rdx,%rax
    78e8:	73 de                	jae    78c8 <fwp_caps173+0x8>
    78ea:	48 89 c2             	mov    %rax,%rdx
    78ed:	48 c1 ea 10          	shr    $0x10,%rdx
    78f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    78f5:	48 8b 15 3c 23 06 00 	mov    0x6233c(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    78fc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7900:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7904:	48 85 c9             	test   %rcx,%rcx
    7907:	74 bf                	je     78c8 <fwp_caps173+0x8>
    7909:	0f b6 32             	movzbl (%rdx),%esi
    790c:	40 80 fe 02          	cmp    $0x2,%sil
    7910:	74 2e                	je     7940 <fwp_caps173+0x80>
    7912:	40 80 fe 01          	cmp    $0x1,%sil
    7916:	75 b0                	jne    78c8 <fwp_caps173+0x8>
    7918:	8b 72 18             	mov    0x18(%rdx),%esi
    791b:	0f b7 c0             	movzwl %ax,%eax
    791e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7921:	48 0f af c6          	imul   %rsi,%rax
    7925:	48 c1 e8 20          	shr    $0x20,%rax
    7929:	48 39 d0             	cmp    %rdx,%rax
    792c:	73 9a                	jae    78c8 <fwp_caps173+0x8>
    792e:	48 01 c1             	add    %rax,%rcx
    7931:	80 39 01             	cmpb   $0x1,(%rcx)
    7934:	75 92                	jne    78c8 <fwp_caps173+0x8>
    7936:	e9 35 e1 ff ff       	jmp    5a70 <fwp_mem_free>
    793b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7940:	66 85 c0             	test   %ax,%ax
    7943:	74 ec                	je     7931 <fwp_caps173+0x71>
    7945:	c3                   	ret
    7946:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    794d:	00 00 00 

0000000000007950 <fwp_args37>:
    7950:	f3 0f 1e fa          	endbr64
    7954:	85 d2                	test   %edx,%edx
    7956:	74 04                	je     795c <fwp_args37+0xc>
    7958:	85 f6                	test   %esi,%esi
    795a:	74 04                	je     7960 <fwp_args37+0x10>
    795c:	c3                   	ret
    795d:	0f 1f 00             	nopl   (%rax)
    7960:	48 8b 15 b1 22 06 00 	mov    0x622b1(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    7967:	48 8b 07             	mov    (%rdi),%rax
    796a:	48 2b 05 7f 22 06 00 	sub    0x6227f(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    7971:	48 c1 e2 10          	shl    $0x10,%rdx
    7975:	48 39 d0             	cmp    %rdx,%rax
    7978:	73 e2                	jae    795c <fwp_args37+0xc>
    797a:	48 89 c2             	mov    %rax,%rdx
    797d:	48 c1 ea 10          	shr    $0x10,%rdx
    7981:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7985:	48 8b 15 ac 22 06 00 	mov    0x622ac(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    798c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7990:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7994:	48 85 ff             	test   %rdi,%rdi
    7997:	74 c3                	je     795c <fwp_args37+0xc>
    7999:	0f b6 0a             	movzbl (%rdx),%ecx
    799c:	80 f9 02             	cmp    $0x2,%cl
    799f:	74 4f                	je     79f0 <fwp_args37+0xa0>
    79a1:	80 f9 01             	cmp    $0x1,%cl
    79a4:	75 b6                	jne    795c <fwp_args37+0xc>
    79a6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    79a9:	0f b7 c0             	movzwl %ax,%eax
    79ac:	8b 52 1c             	mov    0x1c(%rdx),%edx
    79af:	48 0f af c1          	imul   %rcx,%rax
    79b3:	48 c1 e8 20          	shr    $0x20,%rax
    79b7:	48 39 d0             	cmp    %rdx,%rax
    79ba:	73 a0                	jae    795c <fwp_args37+0xc>
    79bc:	48 01 c7             	add    %rax,%rdi
    79bf:	0f b6 07             	movzbl (%rdi),%eax
    79c2:	84 c0                	test   %al,%al
    79c4:	74 96                	je     795c <fwp_args37+0xc>
    79c6:	8b 15 3c 2b 06 00    	mov    0x62b3c(%rip),%edx        # 6a508 <iteration_active>
    79cc:	85 d2                	test   %edx,%edx
    79ce:	75 10                	jne    79e0 <fwp_args37+0x90>
    79d0:	3c fd                	cmp    $0xfd,%al
    79d2:	77 22                	ja     79f6 <fwp_args37+0xa6>
    79d4:	83 c0 01             	add    $0x1,%eax
    79d7:	88 07                	mov    %al,(%rdi)
    79d9:	c3                   	ret
    79da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    79e0:	48 83 05 08 2b 06 00 	addq   $0x1,0x62b08(%rip)        # 6a4f0 <iteration_retains>
    79e7:	01 
    79e8:	eb e6                	jmp    79d0 <fwp_args37+0x80>
    79ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    79f0:	66 85 c0             	test   %ax,%ax
    79f3:	74 ca                	je     79bf <fwp_args37+0x6f>
    79f5:	c3                   	ret
    79f6:	e9 15 dd ff ff       	jmp    5710 <fwp_rc_wide_dup>
    79fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007a00 <fwp_caps37>:
    7a00:	f3 0f 1e fa          	endbr64
    7a04:	48 83 ec 18          	sub    $0x18,%rsp
    7a08:	48 89 f8             	mov    %rdi,%rax
    7a0b:	8b 7f 04             	mov    0x4(%rdi),%edi
    7a0e:	85 ff                	test   %edi,%edi
    7a10:	0f 84 9a 00 00 00    	je     7ab0 <fwp_caps37+0xb0>
    7a16:	48 8b 78 08          	mov    0x8(%rax),%rdi
    7a1a:	85 f6                	test   %esi,%esi
    7a1c:	0f 85 9e 00 00 00    	jne    7ac0 <fwp_caps37+0xc0>
    7a22:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7a27:	e8 24 f7 ff ff       	call   7150 <fwp_drop4>
    7a2c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7a31:	48 8b 0d e0 21 06 00 	mov    0x621e0(%rip),%rcx        # 69c18 <fwp_heap+0x13d8>
    7a38:	48 89 c2             	mov    %rax,%rdx
    7a3b:	48 2b 15 ae 21 06 00 	sub    0x621ae(%rip),%rdx        # 69bf0 <fwp_heap+0x13b0>
    7a42:	48 c1 e1 10          	shl    $0x10,%rcx
    7a46:	48 39 ca             	cmp    %rcx,%rdx
    7a49:	73 6d                	jae    7ab8 <fwp_caps37+0xb8>
    7a4b:	48 89 d1             	mov    %rdx,%rcx
    7a4e:	48 c1 e9 10          	shr    $0x10,%rcx
    7a52:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7a56:	48 8b 0d db 21 06 00 	mov    0x621db(%rip),%rcx        # 69c38 <fwp_heap+0x13f8>
    7a5d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7a61:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7a65:	48 85 f6             	test   %rsi,%rsi
    7a68:	74 4e                	je     7ab8 <fwp_caps37+0xb8>
    7a6a:	0f b6 39             	movzbl (%rcx),%edi
    7a6d:	40 80 ff 02          	cmp    $0x2,%dil
    7a71:	0f 84 c9 00 00 00    	je     7b40 <fwp_caps37+0x140>
    7a77:	40 80 ff 01          	cmp    $0x1,%dil
    7a7b:	75 3b                	jne    7ab8 <fwp_caps37+0xb8>
    7a7d:	8b 79 18             	mov    0x18(%rcx),%edi
    7a80:	0f b7 d2             	movzwl %dx,%edx
    7a83:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7a86:	48 0f af d7          	imul   %rdi,%rdx
    7a8a:	48 c1 ea 20          	shr    $0x20,%rdx
    7a8e:	48 39 ca             	cmp    %rcx,%rdx
    7a91:	73 25                	jae    7ab8 <fwp_caps37+0xb8>
    7a93:	48 01 d6             	add    %rdx,%rsi
    7a96:	80 3e 01             	cmpb   $0x1,(%rsi)
    7a99:	75 1d                	jne    7ab8 <fwp_caps37+0xb8>
    7a9b:	48 89 c7             	mov    %rax,%rdi
    7a9e:	48 83 c4 18          	add    $0x18,%rsp
    7aa2:	e9 c9 df ff ff       	jmp    5a70 <fwp_mem_free>
    7aa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7aae:	00 00 
    7ab0:	85 f6                	test   %esi,%esi
    7ab2:	0f 84 79 ff ff ff    	je     7a31 <fwp_caps37+0x31>
    7ab8:	48 83 c4 18          	add    $0x18,%rsp
    7abc:	c3                   	ret
    7abd:	0f 1f 00             	nopl   (%rax)
    7ac0:	48 8b 05 51 21 06 00 	mov    0x62151(%rip),%rax        # 69c18 <fwp_heap+0x13d8>
    7ac7:	48 2b 3d 22 21 06 00 	sub    0x62122(%rip),%rdi        # 69bf0 <fwp_heap+0x13b0>
    7ace:	48 c1 e0 10          	shl    $0x10,%rax
    7ad2:	48 39 c7             	cmp    %rax,%rdi
    7ad5:	73 e1                	jae    7ab8 <fwp_caps37+0xb8>
    7ad7:	48 89 f8             	mov    %rdi,%rax
    7ada:	48 c1 e8 10          	shr    $0x10,%rax
    7ade:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7ae2:	48 8b 05 4f 21 06 00 	mov    0x6214f(%rip),%rax        # 69c38 <fwp_heap+0x13f8>
    7ae9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7aed:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7af1:	48 85 c0             	test   %rax,%rax
    7af4:	74 c2                	je     7ab8 <fwp_caps37+0xb8>
    7af6:	0f b6 0a             	movzbl (%rdx),%ecx
    7af9:	80 f9 02             	cmp    $0x2,%cl
    7afc:	74 52                	je     7b50 <fwp_caps37+0x150>
    7afe:	80 f9 01             	cmp    $0x1,%cl
    7b01:	75 b5                	jne    7ab8 <fwp_caps37+0xb8>
    7b03:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7b06:	0f b7 ff             	movzwl %di,%edi
    7b09:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b0c:	48 0f af f9          	imul   %rcx,%rdi
    7b10:	48 c1 ef 20          	shr    $0x20,%rdi
    7b14:	48 39 d7             	cmp    %rdx,%rdi
    7b17:	73 9f                	jae    7ab8 <fwp_caps37+0xb8>
    7b19:	48 01 f8             	add    %rdi,%rax
    7b1c:	0f b6 10             	movzbl (%rax),%edx
    7b1f:	84 d2                	test   %dl,%dl
    7b21:	74 95                	je     7ab8 <fwp_caps37+0xb8>
    7b23:	8b 0d df 29 06 00    	mov    0x629df(%rip),%ecx        # 6a508 <iteration_active>
    7b29:	85 c9                	test   %ecx,%ecx
    7b2b:	75 33                	jne    7b60 <fwp_caps37+0x160>
    7b2d:	80 fa fd             	cmp    $0xfd,%dl
    7b30:	77 38                	ja     7b6a <fwp_caps37+0x16a>
    7b32:	83 c2 01             	add    $0x1,%edx
    7b35:	88 10                	mov    %dl,(%rax)
    7b37:	e9 7c ff ff ff       	jmp    7ab8 <fwp_caps37+0xb8>
    7b3c:	0f 1f 40 00          	nopl   0x0(%rax)
    7b40:	66 85 d2             	test   %dx,%dx
    7b43:	0f 85 6f ff ff ff    	jne    7ab8 <fwp_caps37+0xb8>
    7b49:	e9 48 ff ff ff       	jmp    7a96 <fwp_caps37+0x96>
    7b4e:	66 90                	xchg   %ax,%ax
    7b50:	66 85 ff             	test   %di,%di
    7b53:	0f 85 5f ff ff ff    	jne    7ab8 <fwp_caps37+0xb8>
    7b59:	eb c1                	jmp    7b1c <fwp_caps37+0x11c>
    7b5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7b60:	48 83 05 88 29 06 00 	addq   $0x1,0x62988(%rip)        # 6a4f0 <iteration_retains>
    7b67:	01 
    7b68:	eb c3                	jmp    7b2d <fwp_caps37+0x12d>
    7b6a:	48 89 c7             	mov    %rax,%rdi
    7b6d:	48 83 c4 18          	add    $0x18,%rsp
    7b71:	e9 9a db ff ff       	jmp    5710 <fwp_rc_wide_dup>
    7b76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7b7d:	00 00 00 

0000000000007b80 <fwp_drop0>:
    7b80:	f3 0f 1e fa          	endbr64
    7b84:	48 8b 15 8d 20 06 00 	mov    0x6208d(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    7b8b:	48 89 f8             	mov    %rdi,%rax
    7b8e:	48 2b 05 5b 20 06 00 	sub    0x6205b(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    7b95:	48 c1 e2 10          	shl    $0x10,%rdx
    7b99:	48 39 d0             	cmp    %rdx,%rax
    7b9c:	0f 83 36 01 00 00    	jae    7cd8 <fwp_drop0+0x158>
    7ba2:	48 83 ec 18          	sub    $0x18,%rsp
    7ba6:	48 8d 35 93 0c 06 00 	lea    0x60c93(%rip),%rsi        # 68840 <fwp_heap>
    7bad:	48 89 c2             	mov    %rax,%rdx
    7bb0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7bb7:	48 c1 ea 10          	shr    $0x10,%rdx
    7bbb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7bbf:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7bc3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7bc7:	48 85 d2             	test   %rdx,%rdx
    7bca:	74 42                	je     7c0e <fwp_drop0+0x8e>
    7bcc:	44 0f b6 01          	movzbl (%rcx),%r8d
    7bd0:	41 80 f8 02          	cmp    $0x2,%r8b
    7bd4:	74 42                	je     7c18 <fwp_drop0+0x98>
    7bd6:	41 80 f8 01          	cmp    $0x1,%r8b
    7bda:	75 32                	jne    7c0e <fwp_drop0+0x8e>
    7bdc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7be0:	0f b7 c0             	movzwl %ax,%eax
    7be3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7be6:	49 0f af c0          	imul   %r8,%rax
    7bea:	48 c1 e8 20          	shr    $0x20,%rax
    7bee:	48 39 c8             	cmp    %rcx,%rax
    7bf1:	73 1b                	jae    7c0e <fwp_drop0+0x8e>
    7bf3:	48 01 c2             	add    %rax,%rdx
    7bf6:	0f b6 02             	movzbl (%rdx),%eax
    7bf9:	84 c0                	test   %al,%al
    7bfb:	74 11                	je     7c0e <fwp_drop0+0x8e>
    7bfd:	3c 01                	cmp    $0x1,%al
    7bff:	74 27                	je     7c28 <fwp_drop0+0xa8>
    7c01:	3c ff                	cmp    $0xff,%al
    7c03:	0f 84 e7 00 00 00    	je     7cf0 <fwp_drop0+0x170>
    7c09:	83 e8 01             	sub    $0x1,%eax
    7c0c:	88 02                	mov    %al,(%rdx)
    7c0e:	48 83 c4 18          	add    $0x18,%rsp
    7c12:	c3                   	ret
    7c13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7c18:	66 85 c0             	test   %ax,%ax
    7c1b:	74 d9                	je     7bf6 <fwp_drop0+0x76>
    7c1d:	48 83 c4 18          	add    $0x18,%rsp
    7c21:	c3                   	ret
    7c22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c28:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7c2f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7c36:	48 89 f8             	mov    %rdi,%rax
    7c39:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7c3d:	48 29 c8             	sub    %rcx,%rax
    7c40:	48 c1 e2 10          	shl    $0x10,%rdx
    7c44:	48 39 d0             	cmp    %rdx,%rax
    7c47:	73 71                	jae    7cba <fwp_drop0+0x13a>
    7c49:	49 89 c2             	mov    %rax,%r10
    7c4c:	49 c1 ea 10          	shr    $0x10,%r10
    7c50:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7c54:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7c58:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7c5c:	4d 85 d2             	test   %r10,%r10
    7c5f:	74 59                	je     7cba <fwp_drop0+0x13a>
    7c61:	45 0f b6 19          	movzbl (%r9),%r11d
    7c65:	41 80 fb 02          	cmp    $0x2,%r11b
    7c69:	74 75                	je     7ce0 <fwp_drop0+0x160>
    7c6b:	41 80 fb 01          	cmp    $0x1,%r11b
    7c6f:	75 49                	jne    7cba <fwp_drop0+0x13a>
    7c71:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7c75:	0f b7 c0             	movzwl %ax,%eax
    7c78:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7c7c:	49 0f af c3          	imul   %r11,%rax
    7c80:	48 c1 e8 20          	shr    $0x20,%rax
    7c84:	4c 39 c8             	cmp    %r9,%rax
    7c87:	73 31                	jae    7cba <fwp_drop0+0x13a>
    7c89:	49 01 c2             	add    %rax,%r10
    7c8c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7c90:	75 28                	jne    7cba <fwp_drop0+0x13a>
    7c92:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7c97:	e8 d4 dd ff ff       	call   5a70 <fwp_mem_free>
    7c9c:	48 8d 35 9d 0b 06 00 	lea    0x60b9d(%rip),%rsi        # 68840 <fwp_heap>
    7ca3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7ca8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7caf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7cb6:	48 c1 e2 10          	shl    $0x10,%rdx
    7cba:	4c 89 c0             	mov    %r8,%rax
    7cbd:	48 29 c8             	sub    %rcx,%rax
    7cc0:	48 39 d0             	cmp    %rdx,%rax
    7cc3:	0f 83 45 ff ff ff    	jae    7c0e <fwp_drop0+0x8e>
    7cc9:	4c 89 c7             	mov    %r8,%rdi
    7ccc:	e9 dc fe ff ff       	jmp    7bad <fwp_drop0+0x2d>
    7cd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7cd8:	c3                   	ret
    7cd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ce0:	66 85 c0             	test   %ax,%ax
    7ce3:	75 d5                	jne    7cba <fwp_drop0+0x13a>
    7ce5:	eb a5                	jmp    7c8c <fwp_drop0+0x10c>
    7ce7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7cee:	00 00 
    7cf0:	48 89 d0             	mov    %rdx,%rax
    7cf3:	48 c1 e8 11          	shr    $0x11,%rax
    7cf7:	48 31 d0             	xor    %rdx,%rax
    7cfa:	48 89 c1             	mov    %rax,%rcx
    7cfd:	48 c1 e9 09          	shr    $0x9,%rcx
    7d01:	48 31 c8             	xor    %rcx,%rax
    7d04:	0f b6 c8             	movzbl %al,%ecx
    7d07:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7d0e:	00 
    7d0f:	48 85 c0             	test   %rax,%rax
    7d12:	75 15                	jne    7d29 <fwp_drop0+0x1a9>
    7d14:	eb 4e                	jmp    7d64 <fwp_drop0+0x1e4>
    7d16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7d1d:	00 00 00 
    7d20:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7d24:	48 85 c0             	test   %rax,%rax
    7d27:	74 3b                	je     7d64 <fwp_drop0+0x1e4>
    7d29:	48 89 c1             	mov    %rax,%rcx
    7d2c:	48 39 10             	cmp    %rdx,(%rax)
    7d2f:	75 ef                	jne    7d20 <fwp_drop0+0x1a0>
    7d31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7d35:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7d39:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7d3d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7d44:	0f 85 c4 fe ff ff    	jne    7c0e <fwp_drop0+0x8e>
    7d4a:	48 89 d7             	mov    %rdx,%rdi
    7d4d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7d52:	e8 d9 da ff ff       	call   5830 <fwp_rc_forget_slot>
    7d57:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7d5c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7d5f:	e9 aa fe ff ff       	jmp    7c0e <fwp_drop0+0x8e>
    7d64:	48 8d 3d 85 4c 00 00 	lea    0x4c85(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    7d6b:	e8 e0 c6 ff ff       	call   4450 <fwp_trap>

0000000000007d70 <fwp_drop1>:
    7d70:	f3 0f 1e fa          	endbr64
    7d74:	48 8b 15 9d 1e 06 00 	mov    0x61e9d(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    7d7b:	48 89 f8             	mov    %rdi,%rax
    7d7e:	48 2b 05 6b 1e 06 00 	sub    0x61e6b(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    7d85:	48 c1 e2 10          	shl    $0x10,%rdx
    7d89:	48 39 d0             	cmp    %rdx,%rax
    7d8c:	0f 83 36 01 00 00    	jae    7ec8 <fwp_drop1+0x158>
    7d92:	48 83 ec 18          	sub    $0x18,%rsp
    7d96:	48 8d 35 a3 0a 06 00 	lea    0x60aa3(%rip),%rsi        # 68840 <fwp_heap>
    7d9d:	48 89 c2             	mov    %rax,%rdx
    7da0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7da7:	48 c1 ea 10          	shr    $0x10,%rdx
    7dab:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7daf:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7db3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7db7:	48 85 d2             	test   %rdx,%rdx
    7dba:	74 42                	je     7dfe <fwp_drop1+0x8e>
    7dbc:	44 0f b6 01          	movzbl (%rcx),%r8d
    7dc0:	41 80 f8 02          	cmp    $0x2,%r8b
    7dc4:	74 42                	je     7e08 <fwp_drop1+0x98>
    7dc6:	41 80 f8 01          	cmp    $0x1,%r8b
    7dca:	75 32                	jne    7dfe <fwp_drop1+0x8e>
    7dcc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7dd0:	0f b7 c0             	movzwl %ax,%eax
    7dd3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7dd6:	49 0f af c0          	imul   %r8,%rax
    7dda:	48 c1 e8 20          	shr    $0x20,%rax
    7dde:	48 39 c8             	cmp    %rcx,%rax
    7de1:	73 1b                	jae    7dfe <fwp_drop1+0x8e>
    7de3:	48 01 c2             	add    %rax,%rdx
    7de6:	0f b6 02             	movzbl (%rdx),%eax
    7de9:	84 c0                	test   %al,%al
    7deb:	74 11                	je     7dfe <fwp_drop1+0x8e>
    7ded:	3c 01                	cmp    $0x1,%al
    7def:	74 27                	je     7e18 <fwp_drop1+0xa8>
    7df1:	3c ff                	cmp    $0xff,%al
    7df3:	0f 84 e7 00 00 00    	je     7ee0 <fwp_drop1+0x170>
    7df9:	83 e8 01             	sub    $0x1,%eax
    7dfc:	88 02                	mov    %al,(%rdx)
    7dfe:	48 83 c4 18          	add    $0x18,%rsp
    7e02:	c3                   	ret
    7e03:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7e08:	66 85 c0             	test   %ax,%ax
    7e0b:	74 d9                	je     7de6 <fwp_drop1+0x76>
    7e0d:	48 83 c4 18          	add    $0x18,%rsp
    7e11:	c3                   	ret
    7e12:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7e18:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7e1f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7e26:	48 89 f8             	mov    %rdi,%rax
    7e29:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7e2d:	48 29 c8             	sub    %rcx,%rax
    7e30:	48 c1 e2 10          	shl    $0x10,%rdx
    7e34:	48 39 d0             	cmp    %rdx,%rax
    7e37:	73 71                	jae    7eaa <fwp_drop1+0x13a>
    7e39:	49 89 c2             	mov    %rax,%r10
    7e3c:	49 c1 ea 10          	shr    $0x10,%r10
    7e40:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7e44:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7e48:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7e4c:	4d 85 d2             	test   %r10,%r10
    7e4f:	74 59                	je     7eaa <fwp_drop1+0x13a>
    7e51:	45 0f b6 19          	movzbl (%r9),%r11d
    7e55:	41 80 fb 02          	cmp    $0x2,%r11b
    7e59:	74 75                	je     7ed0 <fwp_drop1+0x160>
    7e5b:	41 80 fb 01          	cmp    $0x1,%r11b
    7e5f:	75 49                	jne    7eaa <fwp_drop1+0x13a>
    7e61:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7e65:	0f b7 c0             	movzwl %ax,%eax
    7e68:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7e6c:	49 0f af c3          	imul   %r11,%rax
    7e70:	48 c1 e8 20          	shr    $0x20,%rax
    7e74:	4c 39 c8             	cmp    %r9,%rax
    7e77:	73 31                	jae    7eaa <fwp_drop1+0x13a>
    7e79:	49 01 c2             	add    %rax,%r10
    7e7c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7e80:	75 28                	jne    7eaa <fwp_drop1+0x13a>
    7e82:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7e87:	e8 e4 db ff ff       	call   5a70 <fwp_mem_free>
    7e8c:	48 8d 35 ad 09 06 00 	lea    0x609ad(%rip),%rsi        # 68840 <fwp_heap>
    7e93:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7e98:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7e9f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7ea6:	48 c1 e2 10          	shl    $0x10,%rdx
    7eaa:	4c 89 c0             	mov    %r8,%rax
    7ead:	48 29 c8             	sub    %rcx,%rax
    7eb0:	48 39 d0             	cmp    %rdx,%rax
    7eb3:	0f 83 45 ff ff ff    	jae    7dfe <fwp_drop1+0x8e>
    7eb9:	4c 89 c7             	mov    %r8,%rdi
    7ebc:	e9 dc fe ff ff       	jmp    7d9d <fwp_drop1+0x2d>
    7ec1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ec8:	c3                   	ret
    7ec9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ed0:	66 85 c0             	test   %ax,%ax
    7ed3:	75 d5                	jne    7eaa <fwp_drop1+0x13a>
    7ed5:	eb a5                	jmp    7e7c <fwp_drop1+0x10c>
    7ed7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7ede:	00 00 
    7ee0:	48 89 d0             	mov    %rdx,%rax
    7ee3:	48 c1 e8 11          	shr    $0x11,%rax
    7ee7:	48 31 d0             	xor    %rdx,%rax
    7eea:	48 89 c1             	mov    %rax,%rcx
    7eed:	48 c1 e9 09          	shr    $0x9,%rcx
    7ef1:	48 31 c8             	xor    %rcx,%rax
    7ef4:	0f b6 c8             	movzbl %al,%ecx
    7ef7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7efe:	00 
    7eff:	48 85 c0             	test   %rax,%rax
    7f02:	75 25                	jne    7f29 <fwp_drop1+0x1b9>
    7f04:	eb 5e                	jmp    7f64 <fwp_drop1+0x1f4>
    7f06:	0f 1f 40 00          	nopl   0x0(%rax)
    7f0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7f11:	00 00 00 00 
    7f15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7f1c:	00 00 00 00 
    7f20:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7f24:	48 85 c0             	test   %rax,%rax
    7f27:	74 3b                	je     7f64 <fwp_drop1+0x1f4>
    7f29:	48 89 c1             	mov    %rax,%rcx
    7f2c:	48 39 10             	cmp    %rdx,(%rax)
    7f2f:	75 ef                	jne    7f20 <fwp_drop1+0x1b0>
    7f31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7f35:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7f39:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7f3d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7f44:	0f 85 b4 fe ff ff    	jne    7dfe <fwp_drop1+0x8e>
    7f4a:	48 89 d7             	mov    %rdx,%rdi
    7f4d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7f52:	e8 d9 d8 ff ff       	call   5830 <fwp_rc_forget_slot>
    7f57:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7f5c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7f5f:	e9 9a fe ff ff       	jmp    7dfe <fwp_drop1+0x8e>
    7f64:	48 8d 3d 85 4a 00 00 	lea    0x4a85(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    7f6b:	e8 e0 c4 ff ff       	call   4450 <fwp_trap>

0000000000007f70 <fwp_drop10>:
    7f70:	48 8b 0d a1 1c 06 00 	mov    0x61ca1(%rip),%rcx        # 69c18 <fwp_heap+0x13d8>
    7f77:	48 89 f8             	mov    %rdi,%rax
    7f7a:	48 2b 05 6f 1c 06 00 	sub    0x61c6f(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    7f81:	48 c1 e1 10          	shl    $0x10,%rcx
    7f85:	48 39 c8             	cmp    %rcx,%rax
    7f88:	0f 83 c2 01 00 00    	jae    8150 <fwp_drop10+0x1e0>
    7f8e:	48 83 ec 18          	sub    $0x18,%rsp
    7f92:	48 89 fa             	mov    %rdi,%rdx
    7f95:	48 8d 35 a4 08 06 00 	lea    0x608a4(%rip),%rsi        # 68840 <fwp_heap>
    7f9c:	48 89 c1             	mov    %rax,%rcx
    7f9f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7fa6:	48 c1 e9 10          	shr    $0x10,%rcx
    7faa:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7fae:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7fb2:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7fb6:	48 85 c9             	test   %rcx,%rcx
    7fb9:	74 46                	je     8001 <fwp_drop10+0x91>
    7fbb:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7fbf:	41 80 f9 02          	cmp    $0x2,%r9b
    7fc3:	0f 84 d7 00 00 00    	je     80a0 <fwp_drop10+0x130>
    7fc9:	41 80 f9 01          	cmp    $0x1,%r9b
    7fcd:	75 32                	jne    8001 <fwp_drop10+0x91>
    7fcf:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7fd3:	0f b7 c0             	movzwl %ax,%eax
    7fd6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7fd9:	49 0f af c1          	imul   %r9,%rax
    7fdd:	48 c1 e8 20          	shr    $0x20,%rax
    7fe1:	48 39 f8             	cmp    %rdi,%rax
    7fe4:	73 1b                	jae    8001 <fwp_drop10+0x91>
    7fe6:	48 01 c1             	add    %rax,%rcx
    7fe9:	0f b6 01             	movzbl (%rcx),%eax
    7fec:	84 c0                	test   %al,%al
    7fee:	74 11                	je     8001 <fwp_drop10+0x91>
    7ff0:	3c 01                	cmp    $0x1,%al
    7ff2:	74 1c                	je     8010 <fwp_drop10+0xa0>
    7ff4:	3c ff                	cmp    $0xff,%al
    7ff6:	0f 84 5c 01 00 00    	je     8158 <fwp_drop10+0x1e8>
    7ffc:	83 e8 01             	sub    $0x1,%eax
    7fff:	88 01                	mov    %al,(%rcx)
    8001:	48 83 c4 18          	add    $0x18,%rsp
    8005:	c3                   	ret
    8006:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    800d:	00 00 00 
    8010:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8017:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    801e:	48 89 d0             	mov    %rdx,%rax
    8021:	49 89 d1             	mov    %rdx,%r9
    8024:	48 c1 e1 10          	shl    $0x10,%rcx
    8028:	48 29 f8             	sub    %rdi,%rax
    802b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    802f:	78 7f                	js     80b0 <fwp_drop10+0x140>
    8031:	48 39 c8             	cmp    %rcx,%rax
    8034:	73 cb                	jae    8001 <fwp_drop10+0x91>
    8036:	48 89 c1             	mov    %rax,%rcx
    8039:	48 c1 e9 10          	shr    $0x10,%rcx
    803d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    8041:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    8045:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8049:	48 85 f6             	test   %rsi,%rsi
    804c:	74 b3                	je     8001 <fwp_drop10+0x91>
    804e:	0f b6 39             	movzbl (%rcx),%edi
    8051:	40 80 ff 02          	cmp    $0x2,%dil
    8055:	74 39                	je     8090 <fwp_drop10+0x120>
    8057:	40 80 ff 01          	cmp    $0x1,%dil
    805b:	75 a4                	jne    8001 <fwp_drop10+0x91>
    805d:	8b 79 18             	mov    0x18(%rcx),%edi
    8060:	0f b7 c0             	movzwl %ax,%eax
    8063:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8066:	48 0f af c7          	imul   %rdi,%rax
    806a:	48 c1 e8 20          	shr    $0x20,%rax
    806e:	48 39 c8             	cmp    %rcx,%rax
    8071:	73 8e                	jae    8001 <fwp_drop10+0x91>
    8073:	48 01 c6             	add    %rax,%rsi
    8076:	80 3e 01             	cmpb   $0x1,(%rsi)
    8079:	75 86                	jne    8001 <fwp_drop10+0x91>
    807b:	48 89 d7             	mov    %rdx,%rdi
    807e:	48 83 c4 18          	add    $0x18,%rsp
    8082:	e9 e9 d9 ff ff       	jmp    5a70 <fwp_mem_free>
    8087:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    808e:	00 00 
    8090:	66 85 c0             	test   %ax,%ax
    8093:	74 e1                	je     8076 <fwp_drop10+0x106>
    8095:	48 83 c4 18          	add    $0x18,%rsp
    8099:	c3                   	ret
    809a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    80a0:	66 85 c0             	test   %ax,%ax
    80a3:	0f 84 40 ff ff ff    	je     7fe9 <fwp_drop10+0x79>
    80a9:	48 83 c4 18          	add    $0x18,%rsp
    80ad:	c3                   	ret
    80ae:	66 90                	xchg   %ax,%ax
    80b0:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    80b4:	48 39 c8             	cmp    %rcx,%rax
    80b7:	73 74                	jae    812d <fwp_drop10+0x1bd>
    80b9:	49 89 c2             	mov    %rax,%r10
    80bc:	49 c1 ea 10          	shr    $0x10,%r10
    80c0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    80c4:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    80c8:	4d 8b 50 20          	mov    0x20(%r8),%r10
    80cc:	4d 85 d2             	test   %r10,%r10
    80cf:	74 5c                	je     812d <fwp_drop10+0x1bd>
    80d1:	45 0f b6 18          	movzbl (%r8),%r11d
    80d5:	41 80 fb 02          	cmp    $0x2,%r11b
    80d9:	74 6d                	je     8148 <fwp_drop10+0x1d8>
    80db:	41 80 fb 01          	cmp    $0x1,%r11b
    80df:	75 4c                	jne    812d <fwp_drop10+0x1bd>
    80e1:	45 8b 58 18          	mov    0x18(%r8),%r11d
    80e5:	0f b7 c0             	movzwl %ax,%eax
    80e8:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    80ec:	49 0f af c3          	imul   %r11,%rax
    80f0:	48 c1 e8 20          	shr    $0x20,%rax
    80f4:	4c 39 c0             	cmp    %r8,%rax
    80f7:	73 34                	jae    812d <fwp_drop10+0x1bd>
    80f9:	49 01 c2             	add    %rax,%r10
    80fc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8100:	75 2b                	jne    812d <fwp_drop10+0x1bd>
    8102:	4c 89 cf             	mov    %r9,%rdi
    8105:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    810a:	e8 61 d9 ff ff       	call   5a70 <fwp_mem_free>
    810f:	48 8d 35 2a 07 06 00 	lea    0x6072a(%rip),%rsi        # 68840 <fwp_heap>
    8116:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    811b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8122:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    8129:	48 c1 e1 10          	shl    $0x10,%rcx
    812d:	48 89 d0             	mov    %rdx,%rax
    8130:	48 29 f8             	sub    %rdi,%rax
    8133:	48 39 c8             	cmp    %rcx,%rax
    8136:	0f 82 60 fe ff ff    	jb     7f9c <fwp_drop10+0x2c>
    813c:	e9 c0 fe ff ff       	jmp    8001 <fwp_drop10+0x91>
    8141:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8148:	66 85 c0             	test   %ax,%ax
    814b:	75 e0                	jne    812d <fwp_drop10+0x1bd>
    814d:	eb ad                	jmp    80fc <fwp_drop10+0x18c>
    814f:	90                   	nop
    8150:	c3                   	ret
    8151:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8158:	48 89 c8             	mov    %rcx,%rax
    815b:	48 c1 e8 11          	shr    $0x11,%rax
    815f:	48 31 c8             	xor    %rcx,%rax
    8162:	48 89 c2             	mov    %rax,%rdx
    8165:	48 c1 ea 09          	shr    $0x9,%rdx
    8169:	48 31 d0             	xor    %rdx,%rax
    816c:	0f b6 d0             	movzbl %al,%edx
    816f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    8176:	00 
    8177:	48 85 c0             	test   %rax,%rax
    817a:	75 0d                	jne    8189 <fwp_drop10+0x219>
    817c:	eb 46                	jmp    81c4 <fwp_drop10+0x254>
    817e:	66 90                	xchg   %ax,%ax
    8180:	48 8b 42 10          	mov    0x10(%rdx),%rax
    8184:	48 85 c0             	test   %rax,%rax
    8187:	74 3b                	je     81c4 <fwp_drop10+0x254>
    8189:	48 89 c2             	mov    %rax,%rdx
    818c:	48 39 08             	cmp    %rcx,(%rax)
    818f:	75 ef                	jne    8180 <fwp_drop10+0x210>
    8191:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8195:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    8199:	48 89 50 08          	mov    %rdx,0x8(%rax)
    819d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    81a4:	0f 85 57 fe ff ff    	jne    8001 <fwp_drop10+0x91>
    81aa:	48 89 cf             	mov    %rcx,%rdi
    81ad:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    81b2:	e8 79 d6 ff ff       	call   5830 <fwp_rc_forget_slot>
    81b7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    81bc:	c6 01 fe             	movb   $0xfe,(%rcx)
    81bf:	e9 3d fe ff ff       	jmp    8001 <fwp_drop10+0x91>
    81c4:	48 8d 3d 25 48 00 00 	lea    0x4825(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    81cb:	e8 80 c2 ff ff       	call   4450 <fwp_trap>

00000000000081d0 <f37>:
    81d0:	41 57                	push   %r15
    81d2:	41 56                	push   %r14
    81d4:	41 55                	push   %r13
    81d6:	41 54                	push   %r12
    81d8:	55                   	push   %rbp
    81d9:	53                   	push   %rbx
    81da:	48 83 ec 38          	sub    $0x38,%rsp
    81de:	48 8b 15 33 1a 06 00 	mov    0x61a33(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    81e5:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    81ea:	48 c1 e2 10          	shl    $0x10,%rdx
    81ee:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    81f5:	00 00 
    81f7:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    81fc:	48 8b 0d ed 19 06 00 	mov    0x619ed(%rip),%rcx        # 69bf0 <fwp_heap+0x13b0>
    8203:	48 85 ff             	test   %rdi,%rdi
    8206:	0f 84 1e 03 00 00    	je     852a <f37+0x35a>
    820c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8211:	4c 8b 68 10          	mov    0x10(%rax),%r13
    8215:	4c 89 e8             	mov    %r13,%rax
    8218:	48 29 c8             	sub    %rcx,%rax
    821b:	48 39 d0             	cmp    %rdx,%rax
    821e:	0f 83 ec 02 00 00    	jae    8510 <f37+0x340>
    8224:	48 89 c2             	mov    %rax,%rdx
    8227:	48 c1 ea 10          	shr    $0x10,%rdx
    822b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    822f:	48 8b 15 02 1a 06 00 	mov    0x61a02(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    8236:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    823a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    823e:	48 85 ff             	test   %rdi,%rdi
    8241:	0f 84 c9 02 00 00    	je     8510 <f37+0x340>
    8247:	0f b6 0a             	movzbl (%rdx),%ecx
    824a:	80 f9 02             	cmp    $0x2,%cl
    824d:	0f 84 4d 02 00 00    	je     84a0 <f37+0x2d0>
    8253:	80 f9 01             	cmp    $0x1,%cl
    8256:	75 24                	jne    827c <f37+0xac>
    8258:	8b 4a 18             	mov    0x18(%rdx),%ecx
    825b:	0f b7 c0             	movzwl %ax,%eax
    825e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8261:	48 0f af c1          	imul   %rcx,%rax
    8265:	48 c1 e8 20          	shr    $0x20,%rax
    8269:	48 39 d0             	cmp    %rdx,%rax
    826c:	73 0e                	jae    827c <f37+0xac>
    826e:	48 01 c7             	add    %rax,%rdi
    8271:	0f b6 07             	movzbl (%rdi),%eax
    8274:	84 c0                	test   %al,%al
    8276:	0f 85 44 02 00 00    	jne    84c0 <f37+0x2f0>
    827c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8281:	48 8b 40 10          	mov    0x10(%rax),%rax
    8285:	ba 01 00 00 00       	mov    $0x1,%edx
    828a:	48 85 c0             	test   %rax,%rax
    828d:	74 0e                	je     829d <f37+0xcd>
    828f:	90                   	nop
    8290:	48 8b 40 10          	mov    0x10(%rax),%rax
    8294:	48 83 c2 01          	add    $0x1,%rdx
    8298:	48 85 c0             	test   %rax,%rax
    829b:	75 f3                	jne    8290 <f37+0xc0>
    829d:	4d 85 ed             	test   %r13,%r13
    82a0:	0f 84 9a 02 00 00    	je     8540 <f37+0x370>
    82a6:	4c 89 e8             	mov    %r13,%rax
    82a9:	31 db                	xor    %ebx,%ebx
    82ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    82b0:	48 8b 40 10          	mov    0x10(%rax),%rax
    82b4:	48 83 c3 01          	add    $0x1,%rbx
    82b8:	48 85 c0             	test   %rax,%rax
    82bb:	75 f3                	jne    82b0 <f37+0xe0>
    82bd:	48 39 d3             	cmp    %rdx,%rbx
    82c0:	48 0f 47 da          	cmova  %rdx,%rbx
    82c4:	48 89 d8             	mov    %rbx,%rax
    82c7:	48 c1 e8 3c          	shr    $0x3c,%rax
    82cb:	0f 85 7d 03 00 00    	jne    864e <f37+0x47e>
    82d1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    82d5:	be 02 00 00 00       	mov    $0x2,%esi
    82da:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    82e1:	00 
    82e2:	e8 89 dc ff ff       	call   5f70 <fwp_heap_alloc>
    82e7:	48 89 28             	mov    %rbp,(%rax)
    82ea:	48 8b 15 27 19 06 00 	mov    0x61927(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    82f1:	49 89 c4             	mov    %rax,%r12
    82f4:	48 2b 05 f5 18 06 00 	sub    0x618f5(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    82fb:	48 c1 e2 10          	shl    $0x10,%rdx
    82ff:	48 39 d0             	cmp    %rdx,%rax
    8302:	73 57                	jae    835b <f37+0x18b>
    8304:	48 89 c2             	mov    %rax,%rdx
    8307:	48 c1 ea 10          	shr    $0x10,%rdx
    830b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    830f:	48 8b 15 22 19 06 00 	mov    0x61922(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    8316:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    831a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    831e:	48 85 ed             	test   %rbp,%rbp
    8321:	74 38                	je     835b <f37+0x18b>
    8323:	0f b6 0a             	movzbl (%rdx),%ecx
    8326:	80 f9 02             	cmp    $0x2,%cl
    8329:	0f 84 d1 01 00 00    	je     8500 <f37+0x330>
    832f:	80 f9 01             	cmp    $0x1,%cl
    8332:	75 27                	jne    835b <f37+0x18b>
    8334:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8337:	0f b7 c0             	movzwl %ax,%eax
    833a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    833d:	48 0f af c1          	imul   %rcx,%rax
    8341:	48 c1 e8 20          	shr    $0x20,%rax
    8345:	48 39 d0             	cmp    %rdx,%rax
    8348:	73 11                	jae    835b <f37+0x18b>
    834a:	48 01 c5             	add    %rax,%rbp
    834d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8351:	0f 84 57 02 00 00    	je     85ae <f37+0x3de>
    8357:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    835b:	48 85 db             	test   %rbx,%rbx
    835e:	74 5d                	je     83bd <f37+0x1ed>
    8360:	48 c1 e3 04          	shl    $0x4,%rbx
    8364:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8369:	4c 89 e5             	mov    %r12,%rbp
    836c:	4d 89 ef             	mov    %r13,%r15
    836f:	4c 01 e3             	add    %r12,%rbx
    8372:	0f 1f 00             	nopl   (%rax)
    8375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    837c:	00 00 00 00 
    8380:	49 8b 46 08          	mov    0x8(%r14),%rax
    8384:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8388:	48 83 c5 10          	add    $0x10,%rbp
    838c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8391:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8395:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8399:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    839e:	e8 2d e3 ff ff       	call   66d0 <w120>
    83a3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    83a8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    83ac:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    83b0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    83b4:	4d 8b 76 10          	mov    0x10(%r14),%r14
    83b8:	48 39 dd             	cmp    %rbx,%rbp
    83bb:	75 c3                	jne    8380 <f37+0x1b0>
    83bd:	4c 89 ef             	mov    %r13,%rdi
    83c0:	e8 8b ed ff ff       	call   7150 <fwp_drop4>
    83c5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    83ca:	e8 81 ed ff ff       	call   7150 <fwp_drop4>
    83cf:	4c 89 e7             	mov    %r12,%rdi
    83d2:	e8 79 e4 ff ff       	call   6850 <w176.constprop.0>
    83d7:	4c 89 e7             	mov    %r12,%rdi
    83da:	48 89 c3             	mov    %rax,%rbx
    83dd:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    83e3:	e8 88 fb ff ff       	call   7f70 <fwp_drop10>
    83e8:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    83ee:	66 48 0f 6e db       	movq   %rbx,%xmm3
    83f3:	31 ff                	xor    %edi,%edi
    83f5:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    83fa:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    83fe:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    8403:	e8 58 dd ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    8408:	48 8b 15 09 18 06 00 	mov    0x61809(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    840f:	48 89 c5             	mov    %rax,%rbp
    8412:	48 2b 05 d7 17 06 00 	sub    0x617d7(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    8419:	48 c1 e2 10          	shl    $0x10,%rdx
    841d:	48 39 d0             	cmp    %rdx,%rax
    8420:	73 55                	jae    8477 <f37+0x2a7>
    8422:	48 89 c2             	mov    %rax,%rdx
    8425:	48 c1 ea 10          	shr    $0x10,%rdx
    8429:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    842d:	48 8b 15 04 18 06 00 	mov    0x61804(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    8434:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8438:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    843c:	48 85 db             	test   %rbx,%rbx
    843f:	74 36                	je     8477 <f37+0x2a7>
    8441:	0f b6 0a             	movzbl (%rdx),%ecx
    8444:	80 f9 02             	cmp    $0x2,%cl
    8447:	0f 84 a3 00 00 00    	je     84f0 <f37+0x320>
    844d:	80 f9 01             	cmp    $0x1,%cl
    8450:	75 25                	jne    8477 <f37+0x2a7>
    8452:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8455:	0f b7 c0             	movzwl %ax,%eax
    8458:	8b 52 1c             	mov    0x1c(%rdx),%edx
    845b:	48 0f af c1          	imul   %rcx,%rax
    845f:	48 c1 e8 20          	shr    $0x20,%rax
    8463:	48 39 d0             	cmp    %rdx,%rax
    8466:	73 0f                	jae    8477 <f37+0x2a7>
    8468:	48 01 c3             	add    %rax,%rbx
    846b:	80 3b ff             	cmpb   $0xff,(%rbx)
    846e:	0f 84 2d 01 00 00    	je     85a1 <f37+0x3d1>
    8474:	c6 03 01             	movb   $0x1,(%rbx)
    8477:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    847c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8483:	00 00 
    8485:	0f 85 cf 01 00 00    	jne    865a <f37+0x48a>
    848b:	48 83 c4 38          	add    $0x38,%rsp
    848f:	48 89 e8             	mov    %rbp,%rax
    8492:	5b                   	pop    %rbx
    8493:	5d                   	pop    %rbp
    8494:	41 5c                	pop    %r12
    8496:	41 5d                	pop    %r13
    8498:	41 5e                	pop    %r14
    849a:	41 5f                	pop    %r15
    849c:	c3                   	ret
    849d:	0f 1f 00             	nopl   (%rax)
    84a0:	66 85 c0             	test   %ax,%ax
    84a3:	0f 85 d3 fd ff ff    	jne    827c <f37+0xac>
    84a9:	0f b6 07             	movzbl (%rdi),%eax
    84ac:	84 c0                	test   %al,%al
    84ae:	0f 84 c8 fd ff ff    	je     827c <f37+0xac>
    84b4:	90                   	nop
    84b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    84bc:	00 00 00 00 
    84c0:	8b 15 42 20 06 00    	mov    0x62042(%rip),%edx        # 6a508 <iteration_active>
    84c6:	85 d2                	test   %edx,%edx
    84c8:	75 56                	jne    8520 <f37+0x350>
    84ca:	3c fd                	cmp    $0xfd,%al
    84cc:	0f 87 4b 01 00 00    	ja     861d <f37+0x44d>
    84d2:	83 c0 01             	add    $0x1,%eax
    84d5:	88 07                	mov    %al,(%rdi)
    84d7:	31 d2                	xor    %edx,%edx
    84d9:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    84df:	0f 85 97 fd ff ff    	jne    827c <f37+0xac>
    84e5:	e9 b3 fd ff ff       	jmp    829d <f37+0xcd>
    84ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    84f0:	66 85 c0             	test   %ax,%ax
    84f3:	0f 85 7e ff ff ff    	jne    8477 <f37+0x2a7>
    84f9:	e9 6d ff ff ff       	jmp    846b <f37+0x29b>
    84fe:	66 90                	xchg   %ax,%ax
    8500:	66 85 c0             	test   %ax,%ax
    8503:	0f 85 52 fe ff ff    	jne    835b <f37+0x18b>
    8509:	e9 3f fe ff ff       	jmp    834d <f37+0x17d>
    850e:	66 90                	xchg   %ax,%ax
    8510:	4c 89 e8             	mov    %r13,%rax
    8513:	e9 6d fd ff ff       	jmp    8285 <f37+0xb5>
    8518:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    851f:	00 
    8520:	48 83 05 c8 1f 06 00 	addq   $0x1,0x61fc8(%rip)        # 6a4f0 <iteration_retains>
    8527:	01 
    8528:	eb a0                	jmp    84ca <f37+0x2fa>
    852a:	48 f7 d9             	neg    %rcx
    852d:	48 39 d1             	cmp    %rdx,%rcx
    8530:	0f 82 85 00 00 00    	jb     85bb <f37+0x3eb>
    8536:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    853d:	00 00 00 
    8540:	be 02 00 00 00       	mov    $0x2,%esi
    8545:	bf 08 00 00 00       	mov    $0x8,%edi
    854a:	e8 21 da ff ff       	call   5f70 <fwp_heap_alloc>
    854f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8556:	48 8b 15 bb 16 06 00 	mov    0x616bb(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    855d:	49 89 c4             	mov    %rax,%r12
    8560:	48 2b 05 89 16 06 00 	sub    0x61689(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    8567:	48 c1 e2 10          	shl    $0x10,%rdx
    856b:	48 39 d0             	cmp    %rdx,%rax
    856e:	0f 83 b3 00 00 00    	jae    8627 <f37+0x457>
    8574:	48 89 c2             	mov    %rax,%rdx
    8577:	48 c1 ea 10          	shr    $0x10,%rdx
    857b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    857f:	48 8b 15 b2 16 06 00 	mov    0x616b2(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    8586:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    858a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    858e:	48 85 ed             	test   %rbp,%rbp
    8591:	0f 84 90 00 00 00    	je     8627 <f37+0x457>
    8597:	31 db                	xor    %ebx,%ebx
    8599:	45 31 ed             	xor    %r13d,%r13d
    859c:	e9 82 fd ff ff       	jmp    8323 <f37+0x153>
    85a1:	48 89 df             	mov    %rbx,%rdi
    85a4:	e8 87 d2 ff ff       	call   5830 <fwp_rc_forget_slot>
    85a9:	e9 c6 fe ff ff       	jmp    8474 <f37+0x2a4>
    85ae:	48 89 ef             	mov    %rbp,%rdi
    85b1:	e8 7a d2 ff ff       	call   5830 <fwp_rc_forget_slot>
    85b6:	e9 9c fd ff ff       	jmp    8357 <f37+0x187>
    85bb:	48 89 c8             	mov    %rcx,%rax
    85be:	48 c1 e8 10          	shr    $0x10,%rax
    85c2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    85c6:	48 8b 05 6b 16 06 00 	mov    0x6166b(%rip),%rax        # 69c38 <fwp_heap+0x13f8>
    85cd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    85d1:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    85d5:	48 85 ff             	test   %rdi,%rdi
    85d8:	0f 84 62 ff ff ff    	je     8540 <f37+0x370>
    85de:	0f b6 02             	movzbl (%rdx),%eax
    85e1:	3c 02                	cmp    $0x2,%al
    85e3:	74 4a                	je     862f <f37+0x45f>
    85e5:	3c 01                	cmp    $0x1,%al
    85e7:	0f 85 53 ff ff ff    	jne    8540 <f37+0x370>
    85ed:	0f b7 c1             	movzwl %cx,%eax
    85f0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    85f3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    85f6:	48 0f af c1          	imul   %rcx,%rax
    85fa:	48 c1 e8 20          	shr    $0x20,%rax
    85fe:	48 39 d0             	cmp    %rdx,%rax
    8601:	0f 83 39 ff ff ff    	jae    8540 <f37+0x370>
    8607:	48 01 c7             	add    %rax,%rdi
    860a:	0f b6 07             	movzbl (%rdi),%eax
    860d:	84 c0                	test   %al,%al
    860f:	0f 84 2b ff ff ff    	je     8540 <f37+0x370>
    8615:	45 31 ed             	xor    %r13d,%r13d
    8618:	e9 a3 fe ff ff       	jmp    84c0 <f37+0x2f0>
    861d:	e8 ee d0 ff ff       	call   5710 <fwp_rc_wide_dup>
    8622:	e9 b0 fe ff ff       	jmp    84d7 <f37+0x307>
    8627:	45 31 ed             	xor    %r13d,%r13d
    862a:	e9 8e fd ff ff       	jmp    83bd <f37+0x1ed>
    862f:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    8635:	49 89 cd             	mov    %rcx,%r13
    8638:	0f 85 02 ff ff ff    	jne    8540 <f37+0x370>
    863e:	0f b6 07             	movzbl (%rdi),%eax
    8641:	84 c0                	test   %al,%al
    8643:	0f 85 77 fe ff ff    	jne    84c0 <f37+0x2f0>
    8649:	e9 f2 fe ff ff       	jmp    8540 <f37+0x370>
    864e:	48 8d 3d 96 3b 00 00 	lea    0x3b96(%rip),%rdi        # c1eb <_IO_stdin_used+0x1eb>
    8655:	e8 f6 bd ff ff       	call   4450 <fwp_trap>
    865a:	e8 f1 ad ff ff       	call   3450 <__stack_chk_fail@plt>
    865f:	90                   	nop

0000000000008660 <fwp_owned_entry37>:
    8660:	f3 0f 1e fa          	endbr64
    8664:	48 8b 3f             	mov    (%rdi),%rdi
    8667:	e9 64 fb ff ff       	jmp    81d0 <f37>
    866c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008670 <e37>:
    8670:	f3 0f 1e fa          	endbr64
    8674:	53                   	push   %rbx
    8675:	48 8b 1f             	mov    (%rdi),%rbx
    8678:	48 89 df             	mov    %rbx,%rdi
    867b:	e8 70 e2 ff ff       	call   68f0 <fwp_rc_share>
    8680:	48 89 df             	mov    %rbx,%rdi
    8683:	e8 48 fb ff ff       	call   81d0 <f37>
    8688:	48 89 c3             	mov    %rax,%rbx
    868b:	48 89 c7             	mov    %rax,%rdi
    868e:	e8 5d e2 ff ff       	call   68f0 <fwp_rc_share>
    8693:	48 89 d8             	mov    %rbx,%rax
    8696:	5b                   	pop    %rbx
    8697:	c3                   	ret
    8698:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    869f:	00 

00000000000086a0 <fwp_write>:
    86a0:	41 57                	push   %r15
    86a2:	41 56                	push   %r14
    86a4:	41 55                	push   %r13
    86a6:	41 54                	push   %r12
    86a8:	55                   	push   %rbp
    86a9:	53                   	push   %rbx
    86aa:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    86b1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    86b8:	00 00 
    86ba:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    86c1:	00 
    86c2:	49 89 d4             	mov    %rdx,%r12
    86c5:	8b 12                	mov    (%rdx),%edx
    86c7:	83 fa 19             	cmp    $0x19,%edx
    86ca:	77 6a                	ja     8736 <fwp_write+0x96>
    86cc:	48 89 f5             	mov    %rsi,%rbp
    86cf:	89 d0                	mov    %edx,%eax
    86d1:	89 ce                	mov    %ecx,%esi
    86d3:	48 89 fb             	mov    %rdi,%rbx
    86d6:	48 8d 0d f3 45 00 00 	lea    0x45f3(%rip),%rcx        # ccd0 <_IO_stdin_used+0xcd0>
    86dd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    86e1:	48 01 c8             	add    %rcx,%rax
    86e4:	3e ff e0             	notrack jmp *%rax
    86e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    86ee:	00 00 
    86f0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    86f4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    86f8:	48 89 ca             	mov    %rcx,%rdx
    86fb:	48 85 c9             	test   %rcx,%rcx
    86fe:	0f 88 9c 0c 00 00    	js     93a0 <fwp_write+0xd00>
    8704:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    870b:	00 
    870c:	48 89 c6             	mov    %rax,%rsi
    870f:	4c 89 e7             	mov    %r12,%rdi
    8712:	e8 29 b3 ff ff       	call   3a40 <fwp_fmt_u128>
    8717:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    871e:	00 00 
    8720:	4c 89 e7             	mov    %r12,%rdi
    8723:	e8 18 ad ff ff       	call   3440 <strlen@plt>
    8728:	4c 89 e6             	mov    %r12,%rsi
    872b:	48 89 df             	mov    %rbx,%rdi
    872e:	48 89 c2             	mov    %rax,%rdx
    8731:	e8 ba b9 ff ff       	call   40f0 <buf_put>
    8736:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    873d:	00 
    873e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8745:	00 00 
    8747:	0f 85 28 04 00 00    	jne    8b75 <fwp_write+0x4d5>
    874d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8754:	5b                   	pop    %rbx
    8755:	5d                   	pop    %rbp
    8756:	41 5c                	pop    %r12
    8758:	41 5d                	pop    %r13
    875a:	41 5e                	pop    %r14
    875c:	41 5f                	pop    %r15
    875e:	c3                   	ret
    875f:	90                   	nop
    8760:	49 89 e9             	mov    %rbp,%r9
    8763:	4c 8d 05 ab 3a 00 00 	lea    0x3aab(%rip),%r8        # c215 <_IO_stdin_used+0x215>
    876a:	b9 00 02 00 00       	mov    $0x200,%ecx
    876f:	ba 02 00 00 00       	mov    $0x2,%edx
    8774:	be 00 02 00 00       	mov    $0x200,%esi
    8779:	31 c0                	xor    %eax,%eax
    877b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8782:	00 
    8783:	e8 18 ac ff ff       	call   33a0 <__snprintf_chk@plt>
    8788:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    878f:	00 
    8790:	e8 ab ac ff ff       	call   3440 <strlen@plt>
    8795:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    879c:	00 
    879d:	48 89 df             	mov    %rbx,%rdi
    87a0:	48 89 c2             	mov    %rax,%rdx
    87a3:	e8 48 b9 ff ff       	call   40f0 <buf_put>
    87a8:	eb 8c                	jmp    8736 <fwp_write+0x96>
    87aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    87b0:	49 89 e9             	mov    %rbp,%r9
    87b3:	4c 8d 05 56 3a 00 00 	lea    0x3a56(%rip),%r8        # c210 <_IO_stdin_used+0x210>
    87ba:	eb ae                	jmp    876a <fwp_write+0xca>
    87bc:	0f 1f 40 00          	nopl   0x0(%rax)
    87c0:	83 fa 13             	cmp    $0x13,%edx
    87c3:	48 8d 05 3c 3a 00 00 	lea    0x3a3c(%rip),%rax        # c206 <_IO_stdin_used+0x206>
    87ca:	48 8d 35 3a 3a 00 00 	lea    0x3a3a(%rip),%rsi        # c20b <_IO_stdin_used+0x20b>
    87d1:	ba 04 00 00 00       	mov    $0x4,%edx
    87d6:	48 0f 44 f0          	cmove  %rax,%rsi
    87da:	45 31 ed             	xor    %r13d,%r13d
    87dd:	e8 0e b9 ff ff       	call   40f0 <buf_put>
    87e2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    87e7:	0f 84 a3 08 00 00    	je     9090 <fwp_write+0x9f0>
    87ed:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    87f2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    87f7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    87fc:	48 89 df             	mov    %rbx,%rdi
    87ff:	49 0f 44 c5          	cmove  %r13,%rax
    8803:	31 c9                	xor    %ecx,%ecx
    8805:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    880a:	e8 91 fe ff ff       	call   86a0 <fwp_write>
    880f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8814:	0f 84 6e 09 00 00    	je     9188 <fwp_write+0xae8>
    881a:	49 83 c5 01          	add    $0x1,%r13
    881e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8822:	0f 83 68 08 00 00    	jae    9090 <fwp_write+0x9f0>
    8828:	ba 02 00 00 00       	mov    $0x2,%edx
    882d:	48 8d 35 21 3a 00 00 	lea    0x3a21(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    8834:	48 89 df             	mov    %rbx,%rdi
    8837:	e8 b4 b8 ff ff       	call   40f0 <buf_put>
    883c:	eb af                	jmp    87ed <fwp_write+0x14d>
    883e:	66 90                	xchg   %ax,%ax
    8840:	ba 06 00 00 00       	mov    $0x6,%edx
    8845:	48 8d 35 e2 39 00 00 	lea    0x39e2(%rip),%rsi        # c22e <_IO_stdin_used+0x22e>
    884c:	48 83 c5 10          	add    $0x10,%rbp
    8850:	e8 9b b8 ff ff       	call   40f0 <buf_put>
    8855:	48 89 ef             	mov    %rbp,%rdi
    8858:	e8 e3 ab ff ff       	call   3440 <strlen@plt>
    885d:	48 89 ee             	mov    %rbp,%rsi
    8860:	48 89 df             	mov    %rbx,%rdi
    8863:	48 89 c2             	mov    %rax,%rdx
    8866:	e8 85 b8 ff ff       	call   40f0 <buf_put>
    886b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8870:	ba 01 00 00 00       	mov    $0x1,%edx
    8875:	48 89 df             	mov    %rbx,%rdi
    8878:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    887d:	e8 6e b8 ff ff       	call   40f0 <buf_put>
    8882:	e9 af fe ff ff       	jmp    8736 <fwp_write+0x96>
    8887:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    888e:	00 00 
    8890:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8897:	00 
    8898:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    889f:	00 00 
    88a1:	0f 85 ce 02 00 00    	jne    8b75 <fwp_write+0x4d5>
    88a7:	ba 0a 00 00 00       	mov    $0xa,%edx
    88ac:	48 8d 35 67 39 00 00 	lea    0x3967(%rip),%rsi        # c21a <_IO_stdin_used+0x21a>
    88b3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    88ba:	48 89 df             	mov    %rbx,%rdi
    88bd:	5b                   	pop    %rbx
    88be:	5d                   	pop    %rbp
    88bf:	41 5c                	pop    %r12
    88c1:	41 5d                	pop    %r13
    88c3:	41 5e                	pop    %r14
    88c5:	41 5f                	pop    %r15
    88c7:	e9 24 b8 ff ff       	jmp    40f0 <buf_put>
    88cc:	0f 1f 40 00          	nopl   0x0(%rax)
    88d0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    88d5:	4d 85 ed             	test   %r13,%r13
    88d8:	0f 84 02 0c 00 00    	je     94e0 <fwp_write+0xe40>
    88de:	48 8d 35 7d 39 00 00 	lea    0x397d(%rip),%rsi        # c262 <_IO_stdin_used+0x262>
    88e5:	4c 89 ef             	mov    %r13,%rdi
    88e8:	e8 33 ac ff ff       	call   3520 <strcmp@plt>
    88ed:	41 89 c1             	mov    %eax,%r9d
    88f0:	85 c0                	test   %eax,%eax
    88f2:	0f 84 6c 0c 00 00    	je     9564 <fwp_write+0xec4>
    88f8:	4c 89 ef             	mov    %r13,%rdi
    88fb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8900:	e8 3b ab ff ff       	call   3440 <strlen@plt>
    8905:	4c 89 ee             	mov    %r13,%rsi
    8908:	48 89 df             	mov    %rbx,%rdi
    890b:	48 89 c2             	mov    %rax,%rdx
    890e:	e8 dd b7 ff ff       	call   40f0 <buf_put>
    8913:	ba 01 00 00 00       	mov    $0x1,%edx
    8918:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    891d:	48 89 df             	mov    %rbx,%rdi
    8920:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8925:	e8 c6 b7 ff ff       	call   40f0 <buf_put>
    892a:	ba 01 00 00 00       	mov    $0x1,%edx
    892f:	4c 89 fe             	mov    %r15,%rsi
    8932:	48 89 df             	mov    %rbx,%rdi
    8935:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    893a:	e8 b1 b7 ff ff       	call   40f0 <buf_put>
    893f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8944:	45 31 f6             	xor    %r14d,%r14d
    8947:	85 d2                	test   %edx,%edx
    8949:	0f 8e 81 0a 00 00    	jle    93d0 <fwp_write+0xd30>
    894f:	45 31 ed             	xor    %r13d,%r13d
    8952:	4d 85 ed             	test   %r13,%r13
    8955:	0f 85 75 07 00 00    	jne    90d0 <fwp_write+0xa30>
    895b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8962:	00 
    8963:	45 85 f6             	test   %r14d,%r14d
    8966:	0f 84 84 07 00 00    	je     90f0 <fwp_write+0xa50>
    896c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8971:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8976:	48 89 df             	mov    %rbx,%rdi
    8979:	49 83 c5 01          	add    $0x1,%r13
    897d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8981:	31 c9                	xor    %ecx,%ecx
    8983:	e8 18 fd ff ff       	call   86a0 <fwp_write>
    8988:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    898d:	7f c3                	jg     8952 <fwp_write+0x2b2>
    898f:	45 85 f6             	test   %r14d,%r14d
    8992:	0f 84 38 0a 00 00    	je     93d0 <fwp_write+0xd30>
    8998:	b8 29 00 00 00       	mov    $0x29,%eax
    899d:	ba 01 00 00 00       	mov    $0x1,%edx
    89a2:	4c 89 fe             	mov    %r15,%rsi
    89a5:	48 89 df             	mov    %rbx,%rdi
    89a8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    89ac:	e8 3f b7 ff ff       	call   40f0 <buf_put>
    89b1:	e9 80 fd ff ff       	jmp    8736 <fwp_write+0x96>
    89b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    89bd:	00 00 00 
    89c0:	ba 01 00 00 00       	mov    $0x1,%edx
    89c5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    89ca:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    89cf:	e8 1c b7 ff ff       	call   40f0 <buf_put>
    89d4:	48 85 ed             	test   %rbp,%rbp
    89d7:	0f 84 93 06 00 00    	je     9070 <fwp_write+0x9d0>
    89dd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    89e1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    89e6:	31 c9                	xor    %ecx,%ecx
    89e8:	48 89 df             	mov    %rbx,%rdi
    89eb:	e8 b0 fc ff ff       	call   86a0 <fwp_write>
    89f0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    89f4:	48 85 ed             	test   %rbp,%rbp
    89f7:	0f 84 73 06 00 00    	je     9070 <fwp_write+0x9d0>
    89fd:	ba 02 00 00 00       	mov    $0x2,%edx
    8a02:	48 8d 35 4c 38 00 00 	lea    0x384c(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    8a09:	48 89 df             	mov    %rbx,%rdi
    8a0c:	e8 df b6 ff ff       	call   40f0 <buf_put>
    8a11:	eb ca                	jmp    89dd <fwp_write+0x33d>
    8a13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8a18:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    8a1c:	85 f6                	test   %esi,%esi
    8a1e:	0f 84 fc 07 00 00    	je     9220 <fwp_write+0xb80>
    8a24:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8a2b:	00 
    8a2c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8a33:	00 00 
    8a35:	0f 85 3a 01 00 00    	jne    8b75 <fwp_write+0x4d5>
    8a3b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    8a3f:	4c 89 ea             	mov    %r13,%rdx
    8a42:	e9 6c fe ff ff       	jmp    88b3 <fwp_write+0x213>
    8a47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8a4e:	00 00 
    8a50:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8a55:	ba 01 00 00 00       	mov    $0x1,%edx
    8a5a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    8a5f:	48 89 ee             	mov    %rbp,%rsi
    8a62:	e8 89 b6 ff ff       	call   40f0 <buf_put>
    8a67:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    8a6c:	4c 89 e7             	mov    %r12,%rdi
    8a6f:	e8 cc a9 ff ff       	call   3440 <strlen@plt>
    8a74:	4c 89 e6             	mov    %r12,%rsi
    8a77:	48 89 df             	mov    %rbx,%rdi
    8a7a:	48 89 c2             	mov    %rax,%rdx
    8a7d:	e8 6e b6 ff ff       	call   40f0 <buf_put>
    8a82:	ba 01 00 00 00       	mov    $0x1,%edx
    8a87:	48 89 ee             	mov    %rbp,%rsi
    8a8a:	48 89 df             	mov    %rbx,%rdi
    8a8d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8a92:	e8 59 b6 ff ff       	call   40f0 <buf_put>
    8a97:	e9 9a fc ff ff       	jmp    8736 <fwp_write+0x96>
    8a9c:	0f 1f 40 00          	nopl   0x0(%rax)
    8aa0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8aa5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8aa9:	0f 8a 8e 0b 00 00    	jp     963d <fwp_write+0xf9d>
    8aaf:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8ab3:	66 0f 54 05 55 43 00 	andpd  0x4355(%rip),%xmm0        # ce10 <msg.8+0xd0>
    8aba:	00 
    8abb:	bd 01 00 00 00       	mov    $0x1,%ebp
    8ac0:	66 0f 2e 05 b0 42 00 	ucomisd 0x42b0(%rip),%xmm0        # cd78 <msg.8+0x38>
    8ac7:	00 
    8ac8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8acf:	00 
    8ad0:	0f 87 b2 09 00 00    	ja     9488 <fwp_write+0xde8>
    8ad6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8add:	00 00 00 
    8ae0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8ae4:	89 ee                	mov    %ebp,%esi
    8ae6:	4c 89 e7             	mov    %r12,%rdi
    8ae9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    8aee:	e8 7d bc ff ff       	call   4770 <fwp_format_g.constprop.0>
    8af3:	31 f6                	xor    %esi,%esi
    8af5:	4c 89 e7             	mov    %r12,%rdi
    8af8:	e8 03 a9 ff ff       	call   3400 <strtod@plt>
    8afd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8b02:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8b06:	7a 06                	jp     8b0e <fwp_write+0x46e>
    8b08:	0f 84 e9 01 00 00    	je     8cf7 <fwp_write+0x657>
    8b0e:	83 c5 01             	add    $0x1,%ebp
    8b11:	83 fd 12             	cmp    $0x12,%ebp
    8b14:	75 ca                	jne    8ae0 <fwp_write+0x440>
    8b16:	be 11 00 00 00       	mov    $0x11,%esi
    8b1b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8b1f:	4c 89 e7             	mov    %r12,%rdi
    8b22:	e8 49 bc ff ff       	call   4770 <fwp_format_g.constprop.0>
    8b27:	e9 cb 01 00 00       	jmp    8cf7 <fwp_write+0x657>
    8b2c:	0f 1f 40 00          	nopl   0x0(%rax)
    8b30:	48 83 fd 01          	cmp    $0x1,%rbp
    8b34:	0f 84 e6 08 00 00    	je     9420 <fwp_write+0xd80>
    8b3a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8b3e:	b8 02 00 00 00       	mov    $0x2,%eax
    8b43:	ba 01 00 00 00       	mov    $0x1,%edx
    8b48:	48 0f 44 d0          	cmove  %rax,%rdx
    8b4c:	48 8d 35 ab 36 00 00 	lea    0x36ab(%rip),%rsi        # c1fe <_IO_stdin_used+0x1fe>
    8b53:	48 8d 05 a9 36 00 00 	lea    0x36a9(%rip),%rax        # c203 <_IO_stdin_used+0x203>
    8b5a:	48 0f 44 f0          	cmove  %rax,%rsi
    8b5e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8b65:	00 
    8b66:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8b6d:	00 00 
    8b6f:	0f 84 3e fd ff ff    	je     88b3 <fwp_write+0x213>
    8b75:	e8 d6 a8 ff ff       	call   3450 <__stack_chk_fail@plt>
    8b7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8b80:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8b85:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8b8a:	e8 a1 b4 ff ff       	call   4030 <buf_grow>
    8b8f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8b93:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8b99:	4c 03 0b             	add    (%rbx),%r9
    8b9c:	66 45 89 11          	mov    %r10w,(%r9)
    8ba0:	45 85 e4             	test   %r12d,%r12d
    8ba3:	0f 8e 07 05 00 00    	jle    90b0 <fwp_write+0xa10>
    8ba9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8bb0:	55 55 55 
    8bb3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8bb8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8bbf:	aa aa aa 
    8bc2:	49 83 c1 01          	add    $0x1,%r9
    8bc6:	eb 45                	jmp    8c0d <fwp_write+0x56d>
    8bc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8bcf:	00 
    8bd0:	be 01 00 00 00       	mov    $0x1,%esi
    8bd5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    8bda:	88 07                	mov    %al,(%rdi)
    8bdc:	48 89 e8             	mov    %rbp,%rax
    8bdf:	49 f7 e8             	imul   %r8
    8be2:	48 89 e8             	mov    %rbp,%rax
    8be5:	48 c1 f8 3f          	sar    $0x3f,%rax
    8be9:	48 29 c2             	sub    %rax,%rdx
    8bec:	48 85 c9             	test   %rcx,%rcx
    8bef:	0f 95 c0             	setne  %al
    8bf2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8bf6:	48 83 ef 01          	sub    $0x1,%rdi
    8bfa:	48 21 c5             	and    %rax,%rbp
    8bfd:	48 29 ea             	sub    %rbp,%rdx
    8c00:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8c04:	49 39 f9             	cmp    %rdi,%r9
    8c07:	0f 84 a3 04 00 00    	je     90b0 <fwp_write+0xa10>
    8c0d:	48 89 e8             	mov    %rbp,%rax
    8c10:	49 f7 e8             	imul   %r8
    8c13:	48 89 e8             	mov    %rbp,%rax
    8c16:	48 c1 f8 3f          	sar    $0x3f,%rax
    8c1a:	48 89 d1             	mov    %rdx,%rcx
    8c1d:	48 29 c1             	sub    %rax,%rcx
    8c20:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8c24:	48 89 e9             	mov    %rbp,%rcx
    8c27:	48 29 c1             	sub    %rax,%rcx
    8c2a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    8c2e:	49 f7 e2             	mul    %r10
    8c31:	b8 30 00 00 00       	mov    $0x30,%eax
    8c36:	48 89 d6             	mov    %rdx,%rsi
    8c39:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    8c3d:	48 d1 ee             	shr    $1,%rsi
    8c40:	48 01 f2             	add    %rsi,%rdx
    8c43:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8c47:	48 29 d6             	sub    %rdx,%rsi
    8c4a:	74 8e                	je     8bda <fwp_write+0x53a>
    8c4c:	48 83 fe 01          	cmp    $0x1,%rsi
    8c50:	0f 85 7a ff ff ff    	jne    8bd0 <fwp_write+0x530>
    8c56:	31 f6                	xor    %esi,%esi
    8c58:	b8 2b 00 00 00       	mov    $0x2b,%eax
    8c5d:	e9 78 ff ff ff       	jmp    8bda <fwp_write+0x53a>
    8c62:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8c68:	66 0f 6e cd          	movd   %ebp,%xmm1
    8c6c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    8c6f:	0f 8a c8 09 00 00    	jp     963d <fwp_write+0xf9d>
    8c75:	0f 28 c1             	movaps %xmm1,%xmm0
    8c78:	0f 54 05 81 41 00 00 	andps  0x4181(%rip),%xmm0        # ce00 <msg.8+0xc0>
    8c7f:	0f 2e 05 7e 33 00 00 	ucomiss 0x337e(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    8c86:	0f 87 24 08 00 00    	ja     94b0 <fwp_write+0xe10>
    8c8c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8c90:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8c96:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8c9d:	00 
    8c9e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8ca2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8ca7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8cae:	00 00 
    8cb0:	44 89 ee             	mov    %r13d,%esi
    8cb3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8cb8:	4c 89 e7             	mov    %r12,%rdi
    8cbb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8cc0:	e8 ab ba ff ff       	call   4770 <fwp_format_g.constprop.0>
    8cc5:	31 f6                	xor    %esi,%esi
    8cc7:	4c 89 e7             	mov    %r12,%rdi
    8cca:	e8 d1 a7 ff ff       	call   34a0 <strtof@plt>
    8ccf:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8cd4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8cd7:	7a 02                	jp     8cdb <fwp_write+0x63b>
    8cd9:	74 1c                	je     8cf7 <fwp_write+0x657>
    8cdb:	41 83 c5 01          	add    $0x1,%r13d
    8cdf:	41 83 fd 0a          	cmp    $0xa,%r13d
    8ce3:	75 cb                	jne    8cb0 <fwp_write+0x610>
    8ce5:	be 09 00 00 00       	mov    $0x9,%esi
    8cea:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8cef:	4c 89 e7             	mov    %r12,%rdi
    8cf2:	e8 79 ba ff ff       	call   4770 <fwp_format_g.constprop.0>
    8cf7:	4c 89 e7             	mov    %r12,%rdi
    8cfa:	e8 b1 b4 ff ff       	call   41b0 <fwp_finish_float>
    8cff:	e9 1c fa ff ff       	jmp    8720 <fwp_write+0x80>
    8d04:	0f 1f 40 00          	nopl   0x0(%rax)
    8d08:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8d0c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8d10:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8d17:	00 
    8d18:	48 89 ef             	mov    %rbp,%rdi
    8d1b:	e8 20 ad ff ff       	call   3a40 <fwp_fmt_u128>
    8d20:	48 89 ef             	mov    %rbp,%rdi
    8d23:	e8 18 a7 ff ff       	call   3440 <strlen@plt>
    8d28:	48 89 ee             	mov    %rbp,%rsi
    8d2b:	48 89 df             	mov    %rbx,%rdi
    8d2e:	48 89 c2             	mov    %rax,%rdx
    8d31:	e8 ba b3 ff ff       	call   40f0 <buf_put>
    8d36:	e9 fb f9 ff ff       	jmp    8736 <fwp_write+0x96>
    8d3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8d40:	ba 06 00 00 00       	mov    $0x6,%edx
    8d45:	48 8d 35 0c 35 00 00 	lea    0x350c(%rip),%rsi        # c258 <_IO_stdin_used+0x258>
    8d4c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8d52:	e8 99 b3 ff ff       	call   40f0 <buf_put>
    8d57:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8d5e:	ff ff 7f 
    8d61:	48 23 55 00          	and    0x0(%rbp),%rdx
    8d65:	0f 84 86 02 00 00    	je     8ff1 <fwp_write+0x951>
    8d6b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8d70:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8d74:	48 85 d2             	test   %rdx,%rdx
    8d77:	0f 84 ae 00 00 00    	je     8e2b <fwp_write+0x78b>
    8d7d:	8b 0a                	mov    (%rdx),%ecx
    8d7f:	83 f9 1c             	cmp    $0x1c,%ecx
    8d82:	0f 84 58 06 00 00    	je     93e0 <fwp_write+0xd40>
    8d88:	83 f9 1b             	cmp    $0x1b,%ecx
    8d8b:	0f 87 9a 00 00 00    	ja     8e2b <fwp_write+0x78b>
    8d91:	be 01 00 00 00       	mov    $0x1,%esi
    8d96:	48 d3 e6             	shl    %cl,%rsi
    8d99:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8d9f:	0f 85 4b 04 00 00    	jne    91f0 <fwp_write+0xb50>
    8da5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8dab:	0f 85 0f 04 00 00    	jne    91c0 <fwp_write+0xb20>
    8db1:	83 e6 21             	and    $0x21,%esi
    8db4:	74 75                	je     8e2b <fwp_write+0x78b>
    8db6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8dbb:	48 85 ff             	test   %rdi,%rdi
    8dbe:	79 07                	jns    8dc7 <fwp_write+0x727>
    8dc0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8dc4:	4c 01 ee             	add    %r13,%rsi
    8dc7:	48 0f be 3e          	movsbq (%rsi),%rdi
    8dcb:	85 c9                	test   %ecx,%ecx
    8dcd:	40 0f b6 f7          	movzbl %dil,%esi
    8dd1:	48 0f 44 f7          	cmove  %rdi,%rsi
    8dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8ddc:	00 00 00 00 
    8de0:	31 c9                	xor    %ecx,%ecx
    8de2:	48 89 df             	mov    %rbx,%rdi
    8de5:	49 83 c5 01          	add    $0x1,%r13
    8de9:	e8 b2 f8 ff ff       	call   86a0 <fwp_write>
    8dee:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8df5:	ff ff 7f 
    8df8:	48 23 55 00          	and    0x0(%rbp),%rdx
    8dfc:	49 39 d5             	cmp    %rdx,%r13
    8dff:	0f 83 ec 01 00 00    	jae    8ff1 <fwp_write+0x951>
    8e05:	ba 02 00 00 00       	mov    $0x2,%edx
    8e0a:	48 89 df             	mov    %rbx,%rdi
    8e0d:	48 8d 35 41 34 00 00 	lea    0x3441(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    8e14:	e8 d7 b2 ff ff       	call   40f0 <buf_put>
    8e19:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8e1e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8e22:	48 85 d2             	test   %rdx,%rdx
    8e25:	0f 85 52 ff ff ff    	jne    8d7d <fwp_write+0x6dd>
    8e2b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8e30:	48 85 ff             	test   %rdi,%rdi
    8e33:	0f 88 cf 05 00 00    	js     9408 <fwp_write+0xd68>
    8e39:	48 8b 31             	mov    (%rcx),%rsi
    8e3c:	eb a2                	jmp    8de0 <fwp_write+0x740>
    8e3e:	66 90                	xchg   %ax,%ax
    8e40:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8e47:	00 
    8e48:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8e4f:	00 00 
    8e51:	0f 85 1e fd ff ff    	jne    8b75 <fwp_write+0x4d5>
    8e57:	ba 08 00 00 00       	mov    $0x8,%edx
    8e5c:	48 8d 35 c2 33 00 00 	lea    0x33c2(%rip),%rsi        # c225 <_IO_stdin_used+0x225>
    8e63:	e9 4b fa ff ff       	jmp    88b3 <fwp_write+0x213>
    8e68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8e6f:	00 
    8e70:	89 e8                	mov    %ebp,%eax
    8e72:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8e79:	76 03                	jbe    8e7e <fwp_write+0x7de>
    8e7b:	8b 45 00             	mov    0x0(%rbp),%eax
    8e7e:	41 89 c6             	mov    %eax,%r14d
    8e81:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8e86:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8e8b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8e8f:	4c 89 ef             	mov    %r13,%rdi
    8e92:	e8 a9 a5 ff ff       	call   3440 <strlen@plt>
    8e97:	4c 89 ee             	mov    %r13,%rsi
    8e9a:	48 89 df             	mov    %rbx,%rdi
    8e9d:	48 89 c2             	mov    %rax,%rdx
    8ea0:	e8 4b b2 ff ff       	call   40f0 <buf_put>
    8ea5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8eaa:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8eae:	85 f6                	test   %esi,%esi
    8eb0:	0f 8e 80 f8 ff ff    	jle    8736 <fwp_write+0x96>
    8eb6:	45 31 ed             	xor    %r13d,%r13d
    8eb9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8ebe:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8ec3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8ec8:	ba 01 00 00 00       	mov    $0x1,%edx
    8ecd:	4c 89 fe             	mov    %r15,%rsi
    8ed0:	48 89 04 24          	mov    %rax,(%rsp)
    8ed4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8ed9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8edd:	48 89 df             	mov    %rbx,%rdi
    8ee0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8ee4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8ee9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8eee:	e8 fd b1 ff ff       	call   40f0 <buf_put>
    8ef3:	41 8b 06             	mov    (%r14),%eax
    8ef6:	83 f8 0e             	cmp    $0xe,%eax
    8ef9:	0f 84 71 02 00 00    	je     9170 <fwp_write+0xad0>
    8eff:	83 f8 10             	cmp    $0x10,%eax
    8f02:	0f 84 38 02 00 00    	je     9140 <fwp_write+0xaa0>
    8f08:	83 f8 0a             	cmp    $0xa,%eax
    8f0b:	0f 84 7f 04 00 00    	je     9390 <fwp_write+0xcf0>
    8f11:	0f 8f f9 00 00 00    	jg     9010 <fwp_write+0x970>
    8f17:	83 f8 03             	cmp    $0x3,%eax
    8f1a:	0f 8f 50 04 00 00    	jg     9370 <fwp_write+0xcd0>
    8f20:	85 c0                	test   %eax,%eax
    8f22:	78 10                	js     8f34 <fwp_write+0x894>
    8f24:	48 8b 04 24          	mov    (%rsp),%rax
    8f28:	48 c1 e8 3f          	shr    $0x3f,%rax
    8f2c:	85 c0                	test   %eax,%eax
    8f2e:	0f 85 f9 00 00 00    	jne    902d <fwp_write+0x98d>
    8f34:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8f39:	48 8b 34 24          	mov    (%rsp),%rsi
    8f3d:	31 c9                	xor    %ecx,%ecx
    8f3f:	48 89 df             	mov    %rbx,%rdi
    8f42:	e8 59 f7 ff ff       	call   86a0 <fwp_write>
    8f47:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8f4c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8f51:	49 83 c5 01          	add    $0x1,%r13
    8f55:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8f59:	0f 8f 5f ff ff ff    	jg     8ebe <fwp_write+0x81e>
    8f5f:	e9 d2 f7 ff ff       	jmp    8736 <fwp_write+0x96>
    8f64:	0f 1f 40 00          	nopl   0x0(%rax)
    8f68:	ba 06 00 00 00       	mov    $0x6,%edx
    8f6d:	48 8d 35 d7 32 00 00 	lea    0x32d7(%rip),%rsi        # c24b <_IO_stdin_used+0x24b>
    8f74:	45 31 ed             	xor    %r13d,%r13d
    8f77:	e8 74 b1 ff ff       	call   40f0 <buf_put>
    8f7c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8f81:	75 19                	jne    8f9c <fwp_write+0x8fc>
    8f83:	eb 6c                	jmp    8ff1 <fwp_write+0x951>
    8f85:	0f 1f 00             	nopl   (%rax)
    8f88:	ba 02 00 00 00       	mov    $0x2,%edx
    8f8d:	48 8d 35 c1 32 00 00 	lea    0x32c1(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    8f94:	48 89 df             	mov    %rbx,%rdi
    8f97:	e8 54 b1 ff ff       	call   40f0 <buf_put>
    8f9c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8fa2:	b9 00 02 00 00       	mov    $0x200,%ecx
    8fa7:	31 c0                	xor    %eax,%eax
    8fa9:	49 83 c5 01          	add    $0x1,%r13
    8fad:	4c 8d 05 9e 32 00 00 	lea    0x329e(%rip),%r8        # c252 <_IO_stdin_used+0x252>
    8fb4:	ba 02 00 00 00       	mov    $0x2,%edx
    8fb9:	be 00 02 00 00       	mov    $0x200,%esi
    8fbe:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8fc5:	00 
    8fc6:	e8 d5 a3 ff ff       	call   33a0 <__snprintf_chk@plt>
    8fcb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8fd2:	00 
    8fd3:	e8 68 a4 ff ff       	call   3440 <strlen@plt>
    8fd8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8fdf:	00 
    8fe0:	48 89 df             	mov    %rbx,%rdi
    8fe3:	48 89 c2             	mov    %rax,%rdx
    8fe6:	e8 05 b1 ff ff       	call   40f0 <buf_put>
    8feb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8fef:	72 97                	jb     8f88 <fwp_write+0x8e8>
    8ff1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8ff6:	ba 01 00 00 00       	mov    $0x1,%edx
    8ffb:	48 89 df             	mov    %rbx,%rdi
    8ffe:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9003:	e8 e8 b0 ff ff       	call   40f0 <buf_put>
    9008:	e9 29 f7 ff ff       	jmp    8736 <fwp_write+0x96>
    900d:	0f 1f 00             	nopl   (%rax)
    9010:	83 f8 0b             	cmp    $0xb,%eax
    9013:	0f 85 1b ff ff ff    	jne    8f34 <fwp_write+0x894>
    9019:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    901e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    9022:	83 e0 01             	and    $0x1,%eax
    9025:	85 c0                	test   %eax,%eax
    9027:	0f 84 07 ff ff ff    	je     8f34 <fwp_write+0x894>
    902d:	4c 89 fe             	mov    %r15,%rsi
    9030:	48 89 df             	mov    %rbx,%rdi
    9033:	ba 01 00 00 00       	mov    $0x1,%edx
    9038:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    903d:	e8 ae b0 ff ff       	call   40f0 <buf_put>
    9042:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9047:	48 8b 34 24          	mov    (%rsp),%rsi
    904b:	31 c9                	xor    %ecx,%ecx
    904d:	48 89 df             	mov    %rbx,%rdi
    9050:	e8 4b f6 ff ff       	call   86a0 <fwp_write>
    9055:	ba 01 00 00 00       	mov    $0x1,%edx
    905a:	4c 89 fe             	mov    %r15,%rsi
    905d:	48 89 df             	mov    %rbx,%rdi
    9060:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    9065:	e8 86 b0 ff ff       	call   40f0 <buf_put>
    906a:	e9 d8 fe ff ff       	jmp    8f47 <fwp_write+0x8a7>
    906f:	90                   	nop
    9070:	ba 01 00 00 00       	mov    $0x1,%edx
    9075:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    907a:	48 89 df             	mov    %rbx,%rdi
    907d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9082:	e8 69 b0 ff ff       	call   40f0 <buf_put>
    9087:	e9 aa f6 ff ff       	jmp    8736 <fwp_write+0x96>
    908c:	0f 1f 40 00          	nopl   0x0(%rax)
    9090:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9095:	ba 01 00 00 00       	mov    $0x1,%edx
    909a:	48 89 df             	mov    %rbx,%rdi
    909d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    90a2:	e8 49 b0 ff ff       	call   40f0 <buf_put>
    90a7:	e9 8a f6 ff ff       	jmp    8736 <fwp_write+0x96>
    90ac:	0f 1f 40 00          	nopl   0x0(%rax)
    90b0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    90b4:	48 8b 13             	mov    (%rbx),%rdx
    90b7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    90bc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    90c0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    90c4:	e9 6d f6 ff ff       	jmp    8736 <fwp_write+0x96>
    90c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    90d0:	ba 02 00 00 00       	mov    $0x2,%edx
    90d5:	48 8d 35 79 31 00 00 	lea    0x3179(%rip),%rsi        # c255 <_IO_stdin_used+0x255>
    90dc:	48 89 df             	mov    %rbx,%rdi
    90df:	e8 0c b0 ff ff       	call   40f0 <buf_put>
    90e4:	e9 72 f8 ff ff       	jmp    895b <fwp_write+0x2bb>
    90e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    90f0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    90f5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    90fa:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    90fe:	48 89 f7             	mov    %rsi,%rdi
    9101:	48 89 34 24          	mov    %rsi,(%rsp)
    9105:	e8 36 a3 ff ff       	call   3440 <strlen@plt>
    910a:	48 8b 34 24          	mov    (%rsp),%rsi
    910e:	48 89 df             	mov    %rbx,%rdi
    9111:	48 89 c2             	mov    %rax,%rdx
    9114:	e8 d7 af ff ff       	call   40f0 <buf_put>
    9119:	ba 03 00 00 00       	mov    $0x3,%edx
    911e:	48 8d 35 53 31 00 00 	lea    0x3153(%rip),%rsi        # c278 <_IO_stdin_used+0x278>
    9125:	48 89 df             	mov    %rbx,%rdi
    9128:	e8 c3 af ff ff       	call   40f0 <buf_put>
    912d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9132:	e9 35 f8 ff ff       	jmp    896c <fwp_write+0x2cc>
    9137:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    913e:	00 00 
    9140:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9145:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9149:	48 85 ff             	test   %rdi,%rdi
    914c:	0f 84 e2 fd ff ff    	je     8f34 <fwp_write+0x894>
    9152:	48 8d 35 09 31 00 00 	lea    0x3109(%rip),%rsi        # c262 <_IO_stdin_used+0x262>
    9159:	e8 c2 a3 ff ff       	call   3520 <strcmp@plt>
    915e:	85 c0                	test   %eax,%eax
    9160:	0f 95 c0             	setne  %al
    9163:	0f b6 c0             	movzbl %al,%eax
    9166:	e9 c1 fd ff ff       	jmp    8f2c <fwp_write+0x88c>
    916b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9170:	31 c0                	xor    %eax,%eax
    9172:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    9179:	00 
    917a:	0f 97 c0             	seta   %al
    917d:	e9 aa fd ff ff       	jmp    8f2c <fwp_write+0x88c>
    9182:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9188:	48 89 df             	mov    %rbx,%rdi
    918b:	ba 02 00 00 00       	mov    $0x2,%edx
    9190:	48 8d 35 c8 30 00 00 	lea    0x30c8(%rip),%rsi        # c25f <_IO_stdin_used+0x25f>
    9197:	e8 54 af ff ff       	call   40f0 <buf_put>
    919c:	4c 89 e8             	mov    %r13,%rax
    919f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    91a4:	31 c9                	xor    %ecx,%ecx
    91a6:	48 c1 e0 04          	shl    $0x4,%rax
    91aa:	48 89 df             	mov    %rbx,%rdi
    91ad:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    91b2:	e8 e9 f4 ff ff       	call   86a0 <fwp_write>
    91b7:	e9 5e f6 ff ff       	jmp    881a <fwp_write+0x17a>
    91bc:	0f 1f 40 00          	nopl   0x0(%rax)
    91c0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    91c5:	48 85 ff             	test   %rdi,%rdi
    91c8:	79 0c                	jns    91d6 <fwp_write+0xb36>
    91ca:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    91d1:	00 
    91d2:	48 03 75 10          	add    0x10(%rbp),%rsi
    91d6:	48 63 3e             	movslq (%rsi),%rdi
    91d9:	83 f9 02             	cmp    $0x2,%ecx
    91dc:	89 fe                	mov    %edi,%esi
    91de:	48 0f 44 f7          	cmove  %rdi,%rsi
    91e2:	e9 f9 fb ff ff       	jmp    8de0 <fwp_write+0x740>
    91e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    91ee:	00 00 
    91f0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    91f5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    91fa:	48 85 ff             	test   %rdi,%rdi
    91fd:	0f 88 0f 03 00 00    	js     9512 <fwp_write+0xe72>
    9203:	49 0f bf 38          	movswq (%r8),%rdi
    9207:	83 f9 01             	cmp    $0x1,%ecx
    920a:	0f b7 f7             	movzwl %di,%esi
    920d:	48 0f 44 f7          	cmove  %rdi,%rsi
    9211:	e9 ca fb ff ff       	jmp    8de0 <fwp_write+0x740>
    9216:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    921d:	00 00 00 
    9220:	ba 01 00 00 00       	mov    $0x1,%edx
    9225:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    922a:	48 83 c5 08          	add    $0x8,%rbp
    922e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9233:	e8 b8 ae ff ff       	call   40f0 <buf_put>
    9238:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    923d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    9242:	4d 85 ed             	test   %r13,%r13
    9245:	75 46                	jne    928d <fwp_write+0xbed>
    9247:	e9 04 01 00 00       	jmp    9350 <fwp_write+0xcb0>
    924c:	0f 1f 40 00          	nopl   0x0(%rax)
    9250:	41 80 f9 09          	cmp    $0x9,%r9b
    9254:	0f 84 d6 00 00 00    	je     9330 <fwp_write+0xc90>
    925a:	41 80 f9 0a          	cmp    $0xa,%r9b
    925e:	0f 85 9c 00 00 00    	jne    9300 <fwp_write+0xc60>
    9264:	ba 02 00 00 00       	mov    $0x2,%edx
    9269:	48 8d 35 cb 2f 00 00 	lea    0x2fcb(%rip),%rsi        # c23b <_IO_stdin_used+0x23b>
    9270:	48 89 df             	mov    %rbx,%rdi
    9273:	e8 78 ae ff ff       	call   40f0 <buf_put>
    9278:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    927f:	00 
    9280:	48 83 c5 01          	add    $0x1,%rbp
    9284:	49 39 ec             	cmp    %rbp,%r12
    9287:	0f 84 c3 00 00 00    	je     9350 <fwp_write+0xcb0>
    928d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    9292:	41 80 f9 0d          	cmp    $0xd,%r9b
    9296:	74 28                	je     92c0 <fwp_write+0xc20>
    9298:	7e b6                	jle    9250 <fwp_write+0xbb0>
    929a:	41 80 f9 22          	cmp    $0x22,%r9b
    929e:	74 40                	je     92e0 <fwp_write+0xc40>
    92a0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    92a4:	75 5a                	jne    9300 <fwp_write+0xc60>
    92a6:	ba 02 00 00 00       	mov    $0x2,%edx
    92ab:	48 8d 35 86 2f 00 00 	lea    0x2f86(%rip),%rsi        # c238 <_IO_stdin_used+0x238>
    92b2:	48 89 df             	mov    %rbx,%rdi
    92b5:	e8 36 ae ff ff       	call   40f0 <buf_put>
    92ba:	eb c4                	jmp    9280 <fwp_write+0xbe0>
    92bc:	0f 1f 40 00          	nopl   0x0(%rax)
    92c0:	ba 02 00 00 00       	mov    $0x2,%edx
    92c5:	48 8d 35 75 2f 00 00 	lea    0x2f75(%rip),%rsi        # c241 <_IO_stdin_used+0x241>
    92cc:	48 89 df             	mov    %rbx,%rdi
    92cf:	e8 1c ae ff ff       	call   40f0 <buf_put>
    92d4:	eb aa                	jmp    9280 <fwp_write+0xbe0>
    92d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    92dd:	00 00 00 
    92e0:	ba 02 00 00 00       	mov    $0x2,%edx
    92e5:	48 8d 35 49 2f 00 00 	lea    0x2f49(%rip),%rsi        # c235 <_IO_stdin_used+0x235>
    92ec:	48 89 df             	mov    %rbx,%rdi
    92ef:	e8 fc ad ff ff       	call   40f0 <buf_put>
    92f4:	eb 8a                	jmp    9280 <fwp_write+0xbe0>
    92f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    92fd:	00 00 00 
    9300:	41 80 f9 1f          	cmp    $0x1f,%r9b
    9304:	0f 86 2e 01 00 00    	jbe    9438 <fwp_write+0xd98>
    930a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    930e:	0f 84 24 01 00 00    	je     9438 <fwp_write+0xd98>
    9314:	ba 01 00 00 00       	mov    $0x1,%edx
    9319:	4c 89 fe             	mov    %r15,%rsi
    931c:	48 89 df             	mov    %rbx,%rdi
    931f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    9324:	e8 c7 ad ff ff       	call   40f0 <buf_put>
    9329:	e9 52 ff ff ff       	jmp    9280 <fwp_write+0xbe0>
    932e:	66 90                	xchg   %ax,%ax
    9330:	ba 02 00 00 00       	mov    $0x2,%edx
    9335:	48 8d 35 02 2f 00 00 	lea    0x2f02(%rip),%rsi        # c23e <_IO_stdin_used+0x23e>
    933c:	48 89 df             	mov    %rbx,%rdi
    933f:	e8 ac ad ff ff       	call   40f0 <buf_put>
    9344:	e9 37 ff ff ff       	jmp    9280 <fwp_write+0xbe0>
    9349:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9350:	ba 01 00 00 00       	mov    $0x1,%edx
    9355:	4c 89 fe             	mov    %r15,%rsi
    9358:	48 89 df             	mov    %rbx,%rdi
    935b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9360:	e8 8b ad ff ff       	call   40f0 <buf_put>
    9365:	e9 cc f3 ff ff       	jmp    8736 <fwp_write+0x96>
    936a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9370:	83 f8 04             	cmp    $0x4,%eax
    9373:	0f 85 bb fb ff ff    	jne    8f34 <fwp_write+0x894>
    9379:	48 8b 04 24          	mov    (%rsp),%rax
    937d:	48 8b 40 08          	mov    0x8(%rax),%rax
    9381:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9386:	48 c1 e8 3f          	shr    $0x3f,%rax
    938a:	e9 96 fc ff ff       	jmp    9025 <fwp_write+0x985>
    938f:	90                   	nop
    9390:	8b 0c 24             	mov    (%rsp),%ecx
    9393:	31 c0                	xor    %eax,%eax
    9395:	85 c9                	test   %ecx,%ecx
    9397:	0f 98 c0             	sets   %al
    939a:	e9 86 fc ff ff       	jmp    9025 <fwp_write+0x985>
    939f:	90                   	nop
    93a0:	48 f7 d8             	neg    %rax
    93a3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    93aa:	00 
    93ab:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    93b2:	2d 
    93b3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    93ba:	00 
    93bb:	48 83 d2 00          	adc    $0x0,%rdx
    93bf:	48 89 c6             	mov    %rax,%rsi
    93c2:	48 f7 da             	neg    %rdx
    93c5:	e8 76 a6 ff ff       	call   3a40 <fwp_fmt_u128>
    93ca:	e9 51 f3 ff ff       	jmp    8720 <fwp_write+0x80>
    93cf:	90                   	nop
    93d0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    93d5:	e9 c3 f5 ff ff       	jmp    899d <fwp_write+0x2fd>
    93da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    93e0:	4c 89 e9             	mov    %r13,%rcx
    93e3:	48 c1 e1 04          	shl    $0x4,%rcx
    93e7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    93ec:	48 85 ff             	test   %rdi,%rdi
    93ef:	0f 89 eb f9 ff ff    	jns    8de0 <fwp_write+0x740>
    93f5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    93f9:	48 89 ce             	mov    %rcx,%rsi
    93fc:	e9 df f9 ff ff       	jmp    8de0 <fwp_write+0x740>
    9401:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9408:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    940f:	00 
    9410:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9414:	e9 20 fa ff ff       	jmp    8e39 <fwp_write+0x799>
    9419:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9420:	ba 02 00 00 00       	mov    $0x2,%edx
    9425:	48 8d 35 d4 2d 00 00 	lea    0x2dd4(%rip),%rsi        # c200 <_IO_stdin_used+0x200>
    942c:	e9 2d f7 ff ff       	jmp    8b5e <fwp_write+0x4be>
    9431:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9438:	4c 8d 05 05 2e 00 00 	lea    0x2e05(%rip),%r8        # c244 <_IO_stdin_used+0x244>
    943f:	b9 10 00 00 00       	mov    $0x10,%ecx
    9444:	31 c0                	xor    %eax,%eax
    9446:	ba 02 00 00 00       	mov    $0x2,%edx
    944b:	be 10 00 00 00       	mov    $0x10,%esi
    9450:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9457:	00 
    9458:	e8 43 9f ff ff       	call   33a0 <__snprintf_chk@plt>
    945d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9464:	00 
    9465:	e8 d6 9f ff ff       	call   3440 <strlen@plt>
    946a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9471:	00 
    9472:	48 89 df             	mov    %rbx,%rdi
    9475:	48 89 c2             	mov    %rax,%rdx
    9478:	e8 73 ac ff ff       	call   40f0 <buf_put>
    947d:	e9 fe fd ff ff       	jmp    9280 <fwp_write+0xbe0>
    9482:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9488:	66 0f ef c0          	pxor   %xmm0,%xmm0
    948c:	48 8d 35 67 2d 00 00 	lea    0x2d67(%rip),%rsi        # c1fa <_IO_stdin_used+0x1fa>
    9493:	48 8d 05 5f 2d 00 00 	lea    0x2d5f(%rip),%rax        # c1f9 <_IO_stdin_used+0x1f9>
    949a:	4c 89 e7             	mov    %r12,%rdi
    949d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    94a1:	48 0f 46 f0          	cmovbe %rax,%rsi
    94a5:	e8 36 9f ff ff       	call   33e0 <strcpy@plt>
    94aa:	e9 71 f2 ff ff       	jmp    8720 <fwp_write+0x80>
    94af:	90                   	nop
    94b0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    94b4:	48 8d 35 3f 2d 00 00 	lea    0x2d3f(%rip),%rsi        # c1fa <_IO_stdin_used+0x1fa>
    94bb:	48 8d 05 37 2d 00 00 	lea    0x2d37(%rip),%rax        # c1f9 <_IO_stdin_used+0x1f9>
    94c2:	0f 2f c8             	comiss %xmm0,%xmm1
    94c5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    94cc:	00 
    94cd:	4c 89 e7             	mov    %r12,%rdi
    94d0:	48 0f 46 f0          	cmovbe %rax,%rsi
    94d4:	e8 07 9f ff ff       	call   33e0 <strcpy@plt>
    94d9:	e9 42 f2 ff ff       	jmp    8720 <fwp_write+0x80>
    94de:	66 90                	xchg   %ax,%ax
    94e0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    94e5:	45 85 c0             	test   %r8d,%r8d
    94e8:	75 34                	jne    951e <fwp_write+0xe7e>
    94ea:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    94f1:	00 
    94f2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    94f9:	00 00 
    94fb:	0f 85 74 f6 ff ff    	jne    8b75 <fwp_write+0x4d5>
    9501:	ba 02 00 00 00       	mov    $0x2,%edx
    9506:	48 8d 35 68 2d 00 00 	lea    0x2d68(%rip),%rsi        # c275 <_IO_stdin_used+0x275>
    950d:	e9 a1 f3 ff ff       	jmp    88b3 <fwp_write+0x213>
    9512:	48 03 75 10          	add    0x10(%rbp),%rsi
    9516:	49 89 f0             	mov    %rsi,%r8
    9519:	e9 e5 fc ff ff       	jmp    9203 <fwp_write+0xb63>
    951e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9523:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9528:	85 ff                	test   %edi,%edi
    952a:	0f 84 fa f3 ff ff    	je     892a <fwp_write+0x28a>
    9530:	ba 01 00 00 00       	mov    $0x1,%edx
    9535:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    953a:	48 89 df             	mov    %rbx,%rdi
    953d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9542:	e8 a9 ab ff ff       	call   40f0 <buf_put>
    9547:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    954c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9551:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9557:	85 c0                	test   %eax,%eax
    9559:	0f 8f f0 f3 ff ff    	jg     894f <fwp_write+0x2af>
    955f:	e9 34 f4 ff ff       	jmp    8998 <fwp_write+0x2f8>
    9564:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9568:	49 89 c5             	mov    %rax,%r13
    956b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9570:	49 89 c4             	mov    %rax,%r12
    9573:	49 c1 fd 3f          	sar    $0x3f,%r13
    9577:	4c 09 e8             	or     %r13,%rax
    957a:	0f 84 a7 00 00 00    	je     9627 <fwp_write+0xf87>
    9580:	48 8d 2d 39 4d 00 00 	lea    0x4d39(%rip),%rbp        # e2c0 <units.0>
    9587:	4d 89 e7             	mov    %r12,%r15
    958a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    958e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9593:	4c 89 ff             	mov    %r15,%rdi
    9596:	4c 89 ee             	mov    %r13,%rsi
    9599:	44 89 0c 24          	mov    %r9d,(%rsp)
    959d:	48 99                	cqto
    959f:	48 89 d1             	mov    %rdx,%rcx
    95a2:	48 89 c2             	mov    %rax,%rdx
    95a5:	e8 f6 24 00 00       	call   baa0 <__divmodti4>
    95aa:	44 8b 0c 24          	mov    (%rsp),%r9d
    95ae:	48 89 c1             	mov    %rax,%rcx
    95b1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    95b6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    95bb:	0f 84 94 00 00 00    	je     9655 <fwp_write+0xfb5>
    95c1:	41 83 c1 01          	add    $0x1,%r9d
    95c5:	48 83 c5 10          	add    $0x10,%rbp
    95c9:	41 83 f9 05          	cmp    $0x5,%r9d
    95cd:	75 bb                	jne    958a <fwp_write+0xeea>
    95cf:	4d 85 ed             	test   %r13,%r13
    95d2:	79 53                	jns    9627 <fwp_write+0xf87>
    95d4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    95d9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    95de:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    95e3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    95e8:	48 99                	cqto
    95ea:	48 f7 d8             	neg    %rax
    95ed:	48 83 d2 00          	adc    $0x0,%rdx
    95f1:	48 89 c6             	mov    %rax,%rsi
    95f4:	48 f7 da             	neg    %rdx
    95f7:	e8 44 a4 ff ff       	call   3a40 <fwp_fmt_u128>
    95fc:	49 89 e8             	mov    %rbp,%r8
    95ff:	ba 00 02 00 00       	mov    $0x200,%edx
    9604:	be 02 00 00 00       	mov    $0x2,%esi
    9609:	31 c0                	xor    %eax,%eax
    960b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9612:	00 
    9613:	48 8d 0d 56 2c 00 00 	lea    0x2c56(%rip),%rcx        # c270 <_IO_stdin_used+0x270>
    961a:	4c 89 e7             	mov    %r12,%rdi
    961d:	e8 9e a0 ff ff       	call   36c0 <__sprintf_chk@plt>
    9622:	e9 f9 f0 ff ff       	jmp    8720 <fwp_write+0x80>
    9627:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    962c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9631:	31 d2                	xor    %edx,%edx
    9633:	48 89 ef             	mov    %rbp,%rdi
    9636:	e8 05 a4 ff ff       	call   3a40 <fwp_fmt_u128>
    963b:	eb bf                	jmp    95fc <fwp_write+0xf5c>
    963d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9644:	4e 61 4e 00 
    9648:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    964f:	00 
    9650:	e9 cb f0 ff ff       	jmp    8720 <fwp_write+0x80>
    9655:	44 89 0c 24          	mov    %r9d,(%rsp)
    9659:	48 89 c8             	mov    %rcx,%rax
    965c:	48 85 d2             	test   %rdx,%rdx
    965f:	78 51                	js     96b2 <fwp_write+0x1012>
    9661:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9666:	48 89 c6             	mov    %rax,%rsi
    9669:	48 89 ef             	mov    %rbp,%rdi
    966c:	e8 cf a3 ff ff       	call   3a40 <fwp_fmt_u128>
    9671:	44 8b 0c 24          	mov    (%rsp),%r9d
    9675:	49 63 c1             	movslq %r9d,%rax
    9678:	49 89 e8             	mov    %rbp,%r8
    967b:	ba 00 02 00 00       	mov    $0x200,%edx
    9680:	be 02 00 00 00       	mov    $0x2,%esi
    9685:	48 c1 e0 04          	shl    $0x4,%rax
    9689:	48 8d 3d 30 4c 00 00 	lea    0x4c30(%rip),%rdi        # e2c0 <units.0>
    9690:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9697:	00 
    9698:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    969c:	48 8d 0d c8 2b 00 00 	lea    0x2bc8(%rip),%rcx        # c26b <_IO_stdin_used+0x26b>
    96a3:	4c 89 e7             	mov    %r12,%rdi
    96a6:	31 c0                	xor    %eax,%eax
    96a8:	e8 13 a0 ff ff       	call   36c0 <__sprintf_chk@plt>
    96ad:	e9 6e f0 ff ff       	jmp    8720 <fwp_write+0x80>
    96b2:	48 f7 d8             	neg    %rax
    96b5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    96ba:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    96bf:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    96c4:	48 83 d2 00          	adc    $0x0,%rdx
    96c8:	48 89 c6             	mov    %rax,%rsi
    96cb:	48 f7 da             	neg    %rdx
    96ce:	e8 6d a3 ff ff       	call   3a40 <fwp_fmt_u128>
    96d3:	44 8b 0c 24          	mov    (%rsp),%r9d
    96d7:	eb 9c                	jmp    9675 <fwp_write+0xfd5>
    96d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000096e0 <fwp_main_thread>:
    96e0:	f3 0f 1e fa          	endbr64
    96e4:	41 57                	push   %r15
    96e6:	41 56                	push   %r14
    96e8:	41 55                	push   %r13
    96ea:	41 54                	push   %r12
    96ec:	55                   	push   %rbp
    96ed:	53                   	push   %rbx
    96ee:	48 81 ec f8 01 00 00 	sub    $0x1f8,%rsp
    96f5:	44 8b 1d e8 04 06 00 	mov    0x604e8(%rip),%r11d        # 69be4 <fwp_heap+0x13a4>
    96fc:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9703:	00 00 
    9705:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    970c:	00 
    970d:	31 c0                	xor    %eax,%eax
    970f:	45 85 db             	test   %r11d,%r11d
    9712:	0f 84 22 14 00 00    	je     ab3a <fwp_main_thread+0x145a>
    9718:	44 8b 15 c9 04 06 00 	mov    0x604c9(%rip),%r10d        # 69be8 <fwp_heap+0x13a8>
    971f:	45 85 d2             	test   %r10d,%r10d
    9722:	0f 85 01 14 00 00    	jne    ab29 <fwp_main_thread+0x1449>
    9728:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
    972f:	00 
    9730:	31 f6                	xor    %esi,%esi
    9732:	48 c7 05 a3 ea 05 00 	movq   $0x40000000,0x5eaa3(%rip)        # 681e0 <fwp_main_stack_size>
    9739:	00 00 00 40 
    973d:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    9742:	48 89 05 9f ea 05 00 	mov    %rax,0x5ea9f(%rip)        # 681e8 <fwp_main_stack_top>
    9749:	48 8d 05 50 69 00 00 	lea    0x6950(%rip),%rax        # 100a0 <alt.9>
    9750:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
    9757:	00 
    9758:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
    975f:	00 
    9760:	48 89 c7             	mov    %rax,%rdi
    9763:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    9768:	48 c7 84 24 f0 00 00 	movq   $0x10000,0xf0(%rsp)
    976f:	00 00 00 01 00 
    9774:	c7 84 24 e8 00 00 00 	movl   $0x0,0xe8(%rsp)
    977b:	00 00 00 00 
    977f:	e8 1c 9f ff ff       	call   36a0 <sigaltstack@plt>
    9784:	85 c0                	test   %eax,%eax
    9786:	0f 85 a9 22 00 00    	jne    ba35 <fwp_main_thread+0x2355>
    978c:	31 c0                	xor    %eax,%eax
    978e:	b9 12 00 00 00       	mov    $0x12,%ecx
    9793:	48 8d bc 24 58 01 00 	lea    0x158(%rsp),%rdi
    979a:	00 
    979b:	f3 48 ab             	rep stos %rax,(%rdi)
    979e:	48 8d 9c 24 50 01 00 	lea    0x150(%rsp),%rbx
    97a5:	00 
    97a6:	48 8d 05 93 a5 ff ff 	lea    -0x5a6d(%rip),%rax        # 3d40 <fwp_segv>
    97ad:	c7 84 24 d8 01 00 00 	movl   $0x8000004,0x1d8(%rsp)
    97b4:	04 00 00 08 
    97b8:	48 8d bc 24 58 01 00 	lea    0x158(%rsp),%rdi
    97bf:	00 
    97c0:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    97c5:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
    97cc:	00 
    97cd:	e8 8e 9d ff ff       	call   3560 <sigemptyset@plt>
    97d2:	85 c0                	test   %eax,%eax
    97d4:	0f 85 5b 22 00 00    	jne    ba35 <fwp_main_thread+0x2355>
    97da:	31 d2                	xor    %edx,%edx
    97dc:	48 89 de             	mov    %rbx,%rsi
    97df:	bf 0b 00 00 00       	mov    $0xb,%edi
    97e4:	e8 07 9c ff ff       	call   33f0 <sigaction@plt>
    97e9:	85 c0                	test   %eax,%eax
    97eb:	0f 85 44 22 00 00    	jne    ba35 <fwp_main_thread+0x2355>
    97f1:	31 d2                	xor    %edx,%edx
    97f3:	48 89 de             	mov    %rbx,%rsi
    97f6:	bf 07 00 00 00       	mov    $0x7,%edi
    97fb:	e8 f0 9b ff ff       	call   33f0 <sigaction@plt>
    9800:	85 c0                	test   %eax,%eax
    9802:	0f 85 2d 22 00 00    	jne    ba35 <fwp_main_thread+0x2355>
    9808:	48 8b 05 51 04 06 00 	mov    0x60451(%rip),%rax        # 69c60 <fwp_heap+0x1420>
    980f:	48 85 c0             	test   %rax,%rax
    9812:	0f 88 08 06 00 00    	js     9e20 <fwp_main_thread+0x740>
    9818:	66 0f ef c0          	pxor   %xmm0,%xmm0
    981c:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    9821:	48 8d 3d f8 a9 ff ff 	lea    -0x5608(%rip),%rdi        # 4220 <ad_raw_report>
    9828:	f2 0f 11 05 b8 0c 06 	movsd  %xmm0,0x60cb8(%rip)        # 6a4e8 <iteration_start_charge>
    982f:	00 
    9830:	c7 05 ce 0c 06 00 01 	movl   $0x1,0x60cce(%rip)        # 6a508 <iteration_active>
    9837:	00 00 00 
    983a:	e8 71 24 00 00       	call   bcb0 <atexit>
    983f:	85 c0                	test   %eax,%eax
    9841:	0f 85 1d 22 00 00    	jne    ba64 <fwp_main_thread+0x2384>
    9847:	44 8b 0d 3a 68 00 00 	mov    0x683a(%rip),%r9d        # 10088 <st.7>
    984e:	45 85 c9             	test   %r9d,%r9d
    9851:	0f 84 07 06 00 00    	je     9e5e <fwp_main_thread+0x77e>
    9857:	48 8b 2d c2 ef 05 00 	mov    0x5efc2(%rip),%rbp        # 68820 <fwp_cur>
    985e:	48 85 ed             	test   %rbp,%rbp
    9861:	0f 84 5f 01 00 00    	je     99c6 <fwp_main_thread+0x2e6>
    9867:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    986c:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    9870:	48 89 eb             	mov    %rbp,%rbx
    9873:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9878:	0f 84 41 01 00 00    	je     99bf <fwp_main_thread+0x2df>
    987e:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    9883:	0f 84 b7 04 00 00    	je     9d40 <fwp_main_thread+0x660>
    9889:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    988d:	0f 84 8d 04 00 00    	je     9d20 <fwp_main_thread+0x640>
    9893:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9897:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    989b:	0f 85 1f 05 00 00    	jne    9dc0 <fwp_main_thread+0x6e0>
    98a1:	48 8b 43 60          	mov    0x60(%rbx),%rax
    98a5:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    98ac:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    98b0:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    98b7:	00 00 00 00 
    98bb:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    98c2:	48 85 d2             	test   %rdx,%rdx
    98c5:	74 07                	je     98ce <fwp_main_thread+0x1ee>
    98c7:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    98ce:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    98d2:	48 85 c0             	test   %rax,%rax
    98d5:	74 34                	je     990b <fwp_main_thread+0x22b>
    98d7:	48 89 43 68          	mov    %rax,0x68(%rbx)
    98db:	48 8b 05 16 ef 05 00 	mov    0x5ef16(%rip),%rax        # 687f8 <fwp_timers>
    98e2:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    98e6:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    98ed:	00 00 00 00 
    98f1:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    98f8:	48 85 c0             	test   %rax,%rax
    98fb:	74 07                	je     9904 <fwp_main_thread+0x224>
    98fd:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9904:	48 89 1d ed ee 05 00 	mov    %rbx,0x5eeed(%rip)        # 687f8 <fwp_timers>
    990b:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    990f:	e8 fc dd ff ff       	call   7710 <fwp_block>
    9914:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    991b:	48 85 c9             	test   %rcx,%rcx
    991e:	74 47                	je     9967 <fwp_main_thread+0x287>
    9920:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    9927:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    992e:	48 85 d2             	test   %rdx,%rdx
    9931:	0f 84 c9 04 00 00    	je     9e00 <fwp_main_thread+0x720>
    9937:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    993e:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9945:	48 85 c0             	test   %rax,%rax
    9948:	74 07                	je     9951 <fwp_main_thread+0x271>
    994a:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9951:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    9958:	00 00 00 00 
    995c:	66 0f ef ff          	pxor   %xmm7,%xmm7
    9960:	0f 11 bb 18 01 00 00 	movups %xmm7,0x118(%rbx)
    9967:	48 8b 0d b2 ee 05 00 	mov    0x5eeb2(%rip),%rcx        # 68820 <fwp_cur>
    996e:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9972:	0f 84 38 04 00 00    	je     9db0 <fwp_main_thread+0x6d0>
    9978:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    997f:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    9986:	48 85 d2             	test   %rdx,%rdx
    9989:	0f 84 81 04 00 00    	je     9e10 <fwp_main_thread+0x730>
    998f:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    9996:	48 85 c0             	test   %rax,%rax
    9999:	74 07                	je     99a2 <fwp_main_thread+0x2c2>
    999b:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    99a2:	66 0f ef ff          	pxor   %xmm7,%xmm7
    99a6:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    99aa:	0f 11 bb 08 01 00 00 	movups %xmm7,0x108(%rbx)
    99b1:	48 89 cb             	mov    %rcx,%rbx
    99b4:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    99b9:	0f 85 bf fe ff ff    	jne    987e <fwp_main_thread+0x19e>
    99bf:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    99c3:	48 89 dd             	mov    %rbx,%rbp
    99c6:	48 83 3d ea 0a 06 00 	cmpq   $0x0,0x60aea(%rip)        # 6a4b8 <fwp_state_len>
    99cd:	00 
    99ce:	0f 84 dc 02 00 00    	je     9cb0 <fwp_main_thread+0x5d0>
    99d4:	48 8b 15 3d ee 05 00 	mov    0x5ee3d(%rip),%rdx        # 68818 <fwp_root>
    99db:	c7 05 bb 66 01 00 00 	movl   $0x0,0x166bb(%rip)        # 200a0 <fwp_exit_code>
    99e2:	00 00 00 
    99e5:	48 39 d5             	cmp    %rdx,%rbp
    99e8:	0f 85 a6 20 00 00    	jne    ba94 <fwp_main_thread+0x23b4>
    99ee:	48 85 d2             	test   %rdx,%rdx
    99f1:	0f 84 99 00 00 00    	je     9a90 <fwp_main_thread+0x3b0>
    99f7:	48 8b 0d ea ed 05 00 	mov    0x5edea(%rip),%rcx        # 687e8 <fwp_tasks_active>
    99fe:	c6 42 52 01          	movb   $0x1,0x52(%rdx)
    9a02:	48 85 c9             	test   %rcx,%rcx
    9a05:	0f 84 85 00 00 00    	je     9a90 <fwp_main_thread+0x3b0>
    9a0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9a10:	80 79 50 00          	cmpb   $0x0,0x50(%rcx)
    9a14:	75 08                	jne    9a1e <fwp_main_thread+0x33e>
    9a16:	48 89 cf             	mov    %rcx,%rdi
    9a19:	e8 12 a7 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    9a1e:	48 8b 89 38 01 00 00 	mov    0x138(%rcx),%rcx
    9a25:	48 85 c9             	test   %rcx,%rcx
    9a28:	75 e6                	jne    9a10 <fwp_main_thread+0x330>
    9a2a:	eb 2d                	jmp    9a59 <fwp_main_thread+0x379>
    9a2c:	0f 1f 40 00          	nopl   0x0(%rax)
    9a30:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    9a37:	48 89 15 c2 ed 05 00 	mov    %rdx,0x5edc2(%rip)        # 68800 <fwp_ready_tail>
    9a3e:	e8 cd dc ff ff       	call   7710 <fwp_block>
    9a43:	e8 b8 da ff ff       	call   7500 <fwp_free_zombie>
    9a48:	48 83 3d 98 ed 05 00 	cmpq   $0x0,0x5ed98(%rip)        # 687e8 <fwp_tasks_active>
    9a4f:	00 
    9a50:	74 3e                	je     9a90 <fwp_main_thread+0x3b0>
    9a52:	48 8b 15 bf ed 05 00 	mov    0x5edbf(%rip),%rdx        # 68818 <fwp_root>
    9a59:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    9a5d:	75 df                	jne    9a3e <fwp_main_thread+0x35e>
    9a5f:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9a63:	75 d9                	jne    9a3e <fwp_main_thread+0x35e>
    9a65:	48 8b 05 94 ed 05 00 	mov    0x5ed94(%rip),%rax        # 68800 <fwp_ready_tail>
    9a6c:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    9a70:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    9a77:	00 00 00 00 
    9a7b:	48 85 c0             	test   %rax,%rax
    9a7e:	75 b0                	jne    9a30 <fwp_main_thread+0x350>
    9a80:	48 89 15 81 ed 05 00 	mov    %rdx,0x5ed81(%rip)        # 68808 <fwp_ready_head>
    9a87:	eb ae                	jmp    9a37 <fwp_main_thread+0x357>
    9a89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9a90:	e8 6b da ff ff       	call   7500 <fwp_free_zombie>
    9a95:	48 83 3d 6b ed 05 00 	cmpq   $0x0,0x5ed6b(%rip)        # 68808 <fwp_ready_head>
    9a9c:	00 
    9a9d:	0f 85 a8 9c ff ff    	jne    374b <fwp_main_thread.cold>
    9aa3:	48 83 3d 4d ed 05 00 	cmpq   $0x0,0x5ed4d(%rip)        # 687f8 <fwp_timers>
    9aaa:	00 
    9aab:	0f 85 9a 9c ff ff    	jne    374b <fwp_main_thread.cold>
    9ab1:	8b 05 3d e7 05 00    	mov    0x5e73d(%rip),%eax        # 681f4 <fwp_stack_pool_n>
    9ab7:	85 c0                	test   %eax,%eax
    9ab9:	74 42                	je     9afd <fwp_main_thread+0x41d>
    9abb:	83 e8 01             	sub    $0x1,%eax
    9abe:	4c 8d 25 3b e7 05 00 	lea    0x5e73b(%rip),%r12        # 68200 <fwp_stack_pool>
    9ac5:	48 63 d8             	movslq %eax,%rbx
    9ac8:	89 c0                	mov    %eax,%eax
    9aca:	48 89 da             	mov    %rbx,%rdx
    9acd:	48 29 c2             	sub    %rax,%rdx
    9ad0:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    9ad4:	90                   	nop
    9ad5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9adc:	00 00 00 00 
    9ae0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    9ae4:	89 1d 0a e7 05 00    	mov    %ebx,0x5e70a(%rip)        # 681f4 <fwp_stack_pool_n>
    9aea:	be 00 00 00 10       	mov    $0x10000000,%esi
    9aef:	48 83 eb 01          	sub    $0x1,%rbx
    9af3:	e8 c8 9a ff ff       	call   35c0 <munmap@plt>
    9af8:	48 39 eb             	cmp    %rbp,%rbx
    9afb:	75 e3                	jne    9ae0 <fwp_main_thread+0x400>
    9afd:	8b 3d 15 65 00 00    	mov    0x6515(%rip),%edi        # 10018 <fwp_epfd>
    9b03:	85 ff                	test   %edi,%edi
    9b05:	78 05                	js     9b0c <fwp_main_thread+0x42c>
    9b07:	e8 b4 99 ff ff       	call   34c0 <close@plt>
    9b0c:	4c 8b 25 ed e8 05 00 	mov    0x5e8ed(%rip),%r12        # 68400 <fwp_nfdws>
    9b13:	48 8b 2d ee e8 05 00 	mov    0x5e8ee(%rip),%rbp        # 68408 <fwp_fdws>
    9b1a:	31 db                	xor    %ebx,%ebx
    9b1c:	c7 05 f2 64 00 00 ff 	movl   $0xffffffff,0x64f2(%rip)        # 10018 <fwp_epfd>
    9b23:	ff ff ff 
    9b26:	4d 85 e4             	test   %r12,%r12
    9b29:	74 32                	je     9b5d <fwp_main_thread+0x47d>
    9b2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9b30:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9b35:	48 85 ff             	test   %rdi,%rdi
    9b38:	74 1a                	je     9b54 <fwp_main_thread+0x474>
    9b3a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    9b3e:	0f 85 07 9c ff ff    	jne    374b <fwp_main_thread.cold>
    9b44:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9b49:	0f 85 fc 9b ff ff    	jne    374b <fwp_main_thread.cold>
    9b4f:	e8 1c bf ff ff       	call   5a70 <fwp_mem_free>
    9b54:	48 83 c3 01          	add    $0x1,%rbx
    9b58:	4c 39 e3             	cmp    %r12,%rbx
    9b5b:	75 d3                	jne    9b30 <fwp_main_thread+0x450>
    9b5d:	48 89 ef             	mov    %rbp,%rdi
    9b60:	e8 0b bf ff ff       	call   5a70 <fwp_mem_free>
    9b65:	48 8b 15 ac ec 05 00 	mov    0x5ecac(%rip),%rdx        # 68818 <fwp_root>
    9b6c:	48 c7 05 91 e8 05 00 	movq   $0x0,0x5e891(%rip)        # 68408 <fwp_fdws>
    9b73:	00 00 00 00 
    9b77:	48 c7 05 7e e8 05 00 	movq   $0x0,0x5e87e(%rip)        # 68400 <fwp_nfdws>
    9b7e:	00 00 00 00 
    9b82:	48 85 d2             	test   %rdx,%rdx
    9b85:	74 4e                	je     9bd5 <fwp_main_thread+0x4f5>
    9b87:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    9b8c:	0f 85 b9 9b ff ff    	jne    374b <fwp_main_thread.cold>
    9b92:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    9b99:	00 
    9b9a:	0f 85 ab 9b ff ff    	jne    374b <fwp_main_thread.cold>
    9ba0:	48 83 3d 10 09 06 00 	cmpq   $0x0,0x60910(%rip)        # 6a4b8 <fwp_state_len>
    9ba7:	00 
    9ba8:	0f 85 9d 9b ff ff    	jne    374b <fwp_main_thread.cold>
    9bae:	48 83 3d f2 08 06 00 	cmpq   $0x0,0x608f2(%rip)        # 6a4a8 <fwp_state_owners>
    9bb5:	00 
    9bb6:	0f 85 8f 9b ff ff    	jne    374b <fwp_main_thread.cold>
    9bbc:	b9 79 00 00 00       	mov    $0x79,%ecx
    9bc1:	31 c0                	xor    %eax,%eax
    9bc3:	48 8d 3d 56 e8 05 00 	lea    0x5e856(%rip),%rdi        # 68420 <fwp_root_context>
    9bca:	f3 48 ab             	rep stos %rax,(%rdi)
    9bcd:	48 89 d7             	mov    %rdx,%rdi
    9bd0:	e8 9b be ff ff       	call   5a70 <fwp_mem_free>
    9bd5:	66 0f 6f 05 f3 65 04 	movdqa 0x465f3(%rip),%xmm0        # 501d0 <ad_raw_live+0x10>
    9bdc:	00 
    9bdd:	66 0f d4 05 db 65 04 	paddq  0x465db(%rip),%xmm0        # 501c0 <ad_raw_live>
    9be4:	00 
    9be5:	48 c7 05 30 ec 05 00 	movq   $0x0,0x5ec30(%rip)        # 68820 <fwp_cur>
    9bec:	00 00 00 00 
    9bf0:	48 8b 05 69 00 06 00 	mov    0x60069(%rip),%rax        # 69c60 <fwp_heap+0x1420>
    9bf7:	48 c7 05 16 ec 05 00 	movq   $0x0,0x5ec16(%rip)        # 68818 <fwp_root>
    9bfe:	00 00 00 00 
    9c02:	c7 05 fc 08 06 00 00 	movl   $0x0,0x608fc(%rip)        # 6a508 <iteration_active>
    9c09:	00 00 00 
    9c0c:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    9c10:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    9c15:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    9c19:	66 0f d6 05 f7 64 01 	movq   %xmm0,0x164f7(%rip)        # 20118 <ad_raw_before_shutdown>
    9c20:	00 
    9c21:	48 85 c0             	test   %rax,%rax
    9c24:	0f 88 16 02 00 00    	js     9e40 <fwp_main_thread+0x760>
    9c2a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9c2e:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    9c33:	f2 0f 5c 0d ad 08 06 	subsd  0x608ad(%rip),%xmm1        # 6a4e8 <iteration_start_charge>
    9c3a:	00 
    9c3b:	48 8b 3d fe 63 00 00 	mov    0x63fe(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    9c42:	48 8d 15 f7 2e 00 00 	lea    0x2ef7(%rip),%rdx        # cb40 <_IO_stdin_used+0xb40>
    9c49:	be 02 00 00 00       	mov    $0x2,%esi
    9c4e:	f2 0f 10 05 8a 08 06 	movsd  0x6088a(%rip),%xmm0        # 6a4e0 <iteration_peak>
    9c55:	00 
    9c56:	4c 8b 0d 93 08 06 00 	mov    0x60893(%rip),%r9        # 6a4f0 <iteration_retains>
    9c5d:	b8 02 00 00 00       	mov    $0x2,%eax
    9c62:	4c 8b 05 8f 08 06 00 	mov    0x6088f(%rip),%r8        # 6a4f8 <iteration_bytes>
    9c69:	48 8b 0d 90 08 06 00 	mov    0x60890(%rip),%rcx        # 6a500 <iteration_requests>
    9c70:	e8 fb 99 ff ff       	call   3670 <__fprintf_chk@plt>
    9c75:	48 8b 3d a4 63 00 00 	mov    0x63a4(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    9c7c:	e8 1f 99 ff ff       	call   35a0 <fflush@plt>
    9c81:	48 8b 84 24 e8 01 00 	mov    0x1e8(%rsp),%rax
    9c88:	00 
    9c89:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9c90:	00 00 
    9c92:	0f 85 a9 1d 00 00    	jne    ba41 <fwp_main_thread+0x2361>
    9c98:	48 81 c4 f8 01 00 00 	add    $0x1f8,%rsp
    9c9f:	31 c0                	xor    %eax,%eax
    9ca1:	5b                   	pop    %rbx
    9ca2:	5d                   	pop    %rbp
    9ca3:	41 5c                	pop    %r12
    9ca5:	41 5d                	pop    %r13
    9ca7:	41 5e                	pop    %r14
    9ca9:	41 5f                	pop    %r15
    9cab:	c3                   	ret
    9cac:	0f 1f 40 00          	nopl   0x0(%rax)
    9cb0:	48 83 3d f0 07 06 00 	cmpq   $0x0,0x607f0(%rip)        # 6a4a8 <fwp_state_owners>
    9cb7:	00 
    9cb8:	0f 85 16 fd ff ff    	jne    99d4 <fwp_main_thread+0x2f4>
    9cbe:	48 8b 3d fb 07 06 00 	mov    0x607fb(%rip),%rdi        # 6a4c0 <fwp_state>
    9cc5:	e8 a6 bd ff ff       	call   5a70 <fwp_mem_free>
    9cca:	48 c7 05 eb 07 06 00 	movq   $0x0,0x607eb(%rip)        # 6a4c0 <fwp_state>
    9cd1:	00 00 00 00 
    9cd5:	48 c7 05 d0 07 06 00 	movq   $0x0,0x607d0(%rip)        # 6a4b0 <fwp_state_cap>
    9cdc:	00 00 00 00 
    9ce0:	48 85 ed             	test   %rbp,%rbp
    9ce3:	0f 84 eb fc ff ff    	je     99d4 <fwp_main_thread+0x2f4>
    9ce9:	48 8b 15 28 eb 05 00 	mov    0x5eb28(%rip),%rdx        # 68818 <fwp_root>
    9cf0:	48 c7 85 a8 00 00 00 	movq   $0x0,0xa8(%rbp)
    9cf7:	00 00 00 00 
    9cfb:	48 c7 85 b8 00 00 00 	movq   $0x0,0xb8(%rbp)
    9d02:	00 00 00 00 
    9d06:	c7 05 90 63 01 00 00 	movl   $0x0,0x16390(%rip)        # 200a0 <fwp_exit_code>
    9d0d:	00 00 00 
    9d10:	48 39 d5             	cmp    %rdx,%rbp
    9d13:	0f 84 de fc ff ff    	je     99f7 <fwp_main_thread+0x317>
    9d19:	e9 2d 9a ff ff       	jmp    374b <fwp_main_thread.cold>
    9d1e:	66 90                	xchg   %ax,%ax
    9d20:	e8 9b a8 ff ff       	call   45c0 <fwp_now_ns>
    9d25:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    9d29:	7c 15                	jl     9d40 <fwp_main_thread+0x660>
    9d2b:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    9d2f:	75 0f                	jne    9d40 <fwp_main_thread+0x660>
    9d31:	48 89 ef             	mov    %rbp,%rdi
    9d34:	e8 f7 a3 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    9d39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9d40:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9d44:	0f 85 49 fb ff ff    	jne    9893 <fwp_main_thread+0x1b3>
    9d4a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    9d4e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9d52:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9d56:	0f 85 49 fb ff ff    	jne    98a5 <fwp_main_thread+0x1c5>
    9d5c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    9d60:	48 85 c9             	test   %rcx,%rcx
    9d63:	0f 84 3c fb ff ff    	je     98a5 <fwp_main_thread+0x1c5>
    9d69:	48 39 c8             	cmp    %rcx,%rax
    9d6c:	48 89 ce             	mov    %rcx,%rsi
    9d6f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9d76:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9d7a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9d81:	00 00 00 00 
    9d85:	48 0f 4e f0          	cmovle %rax,%rsi
    9d89:	48 85 c0             	test   %rax,%rax
    9d8c:	48 89 c8             	mov    %rcx,%rax
    9d8f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9d96:	48 0f 45 c6          	cmovne %rsi,%rax
    9d9a:	48 85 d2             	test   %rdx,%rdx
    9d9d:	74 07                	je     9da6 <fwp_main_thread+0x6c6>
    9d9f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9da6:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9daa:	e9 28 fb ff ff       	jmp    98d7 <fwp_main_thread+0x1f7>
    9daf:	90                   	nop
    9db0:	48 89 cb             	mov    %rcx,%rbx
    9db3:	e9 bb fa ff ff       	jmp    9873 <fwp_main_thread+0x193>
    9db8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9dbf:	00 
    9dc0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9dc4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9dcb:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9dd2:	00 00 00 00 
    9dd6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    9ddd:	48 85 c0             	test   %rax,%rax
    9de0:	0f 84 6b 19 00 00    	je     b751 <fwp_main_thread+0x2071>
    9de6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    9ded:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9df1:	e9 15 fb ff ff       	jmp    990b <fwp_main_thread+0x22b>
    9df6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9dfd:	00 00 00 
    9e00:	48 89 01             	mov    %rax,(%rcx)
    9e03:	e9 3d fb ff ff       	jmp    9945 <fwp_main_thread+0x265>
    9e08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9e0f:	00 
    9e10:	48 89 05 e1 e9 05 00 	mov    %rax,0x5e9e1(%rip)        # 687f8 <fwp_timers>
    9e17:	e9 7a fb ff ff       	jmp    9996 <fwp_main_thread+0x2b6>
    9e1c:	0f 1f 40 00          	nopl   0x0(%rax)
    9e20:	48 89 c2             	mov    %rax,%rdx
    9e23:	83 e0 01             	and    $0x1,%eax
    9e26:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9e2a:	48 d1 ea             	shr    $1,%rdx
    9e2d:	48 09 c2             	or     %rax,%rdx
    9e30:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    9e35:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    9e39:	e9 e3 f9 ff ff       	jmp    9821 <fwp_main_thread+0x141>
    9e3e:	66 90                	xchg   %ax,%ax
    9e40:	48 89 c2             	mov    %rax,%rdx
    9e43:	83 e0 01             	and    $0x1,%eax
    9e46:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9e4a:	48 d1 ea             	shr    $1,%rdx
    9e4d:	48 09 c2             	or     %rax,%rdx
    9e50:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    9e55:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    9e59:	e9 d5 fd ff ff       	jmp    9c33 <fwp_main_thread+0x553>
    9e5e:	48 8d 05 0b df ff ff 	lea    -0x20f5(%rip),%rax        # 7d70 <fwp_drop1>
    9e65:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9e69:	4c 8b 64 24 20       	mov    0x20(%rsp),%r12
    9e6e:	45 31 f6             	xor    %r14d,%r14d
    9e71:	66 48 0f 6e d8       	movq   %rax,%xmm3
    9e76:	48 8b 05 5b 06 06 00 	mov    0x6065b(%rip),%rax        # 6a4d8 <fwp_cleanups>
    9e7d:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
    9e84:	00 00 00 00 00 
    9e89:	bb ff 01 00 00       	mov    $0x1ff,%ebx
    9e8e:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    9e92:	48 8d 2d a7 e9 05 00 	lea    0x5e9a7(%rip),%rbp        # 68840 <fwp_heap>
    9e99:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    9ea0:	00 
    9ea1:	48 8d 05 28 9d ff ff 	lea    -0x62d8(%rip),%rax        # 3bd0 <fwp_range_release>
    9ea8:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    9eaf:	00 
    9eb0:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    9eb5:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
    9ebc:	00 
    9ebd:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
    9ec4:	00 
    9ec5:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    9eca:	48 89 05 07 06 06 00 	mov    %rax,0x60607(%rip)        # 6a4d8 <fwp_cleanups>
    9ed1:	eb 45                	jmp    9f18 <fwp_main_thread+0x838>
    9ed3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9ed8:	80 f9 01             	cmp    $0x1,%cl
    9edb:	75 29                	jne    9f06 <fwp_main_thread+0x826>
    9edd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ee0:	0f b7 c0             	movzwl %ax,%eax
    9ee3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9ee6:	48 0f af c1          	imul   %rcx,%rax
    9eea:	48 c1 e8 20          	shr    $0x20,%rax
    9eee:	48 39 d0             	cmp    %rdx,%rax
    9ef1:	73 13                	jae    9f06 <fwp_main_thread+0x826>
    9ef3:	49 01 c5             	add    %rax,%r13
    9ef6:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9efb:	0f 84 fa 18 00 00    	je     b7fb <fwp_main_thread+0x211b>
    9f01:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9f06:	4c 89 b4 24 e0 00 00 	mov    %r14,0xe0(%rsp)
    9f0d:	00 
    9f0e:	48 83 eb 01          	sub    $0x1,%rbx
    9f12:	0f 82 85 00 00 00    	jb     9f9d <fwp_main_thread+0x8bd>
    9f18:	4c 89 e6             	mov    %r12,%rsi
    9f1b:	bf 01 00 00 00       	mov    $0x1,%edi
    9f20:	4c 89 b4 24 58 01 00 	mov    %r14,0x158(%rsp)
    9f27:	00 
    9f28:	48 89 9c 24 e8 00 00 	mov    %rbx,0xe8(%rsp)
    9f2f:	00 
    9f30:	48 89 9c 24 50 01 00 	mov    %rbx,0x150(%rsp)
    9f37:	00 
    9f38:	e8 23 c2 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    9f3d:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9f44:	49 89 c6             	mov    %rax,%r14
    9f47:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9f4e:	48 c1 e2 10          	shl    $0x10,%rdx
    9f52:	48 39 d0             	cmp    %rdx,%rax
    9f55:	73 af                	jae    9f06 <fwp_main_thread+0x826>
    9f57:	48 89 c2             	mov    %rax,%rdx
    9f5a:	48 c1 ea 10          	shr    $0x10,%rdx
    9f5e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f62:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9f69:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9f6d:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9f71:	4d 85 ed             	test   %r13,%r13
    9f74:	74 90                	je     9f06 <fwp_main_thread+0x826>
    9f76:	0f b6 0a             	movzbl (%rdx),%ecx
    9f79:	80 f9 02             	cmp    $0x2,%cl
    9f7c:	0f 85 56 ff ff ff    	jne    9ed8 <fwp_main_thread+0x7f8>
    9f82:	66 85 c0             	test   %ax,%ax
    9f85:	0f 84 6b ff ff ff    	je     9ef6 <fwp_main_thread+0x816>
    9f8b:	4c 89 b4 24 e0 00 00 	mov    %r14,0xe0(%rsp)
    9f92:	00 
    9f93:	48 83 eb 01          	sub    $0x1,%rbx
    9f97:	0f 83 7b ff ff ff    	jae    9f18 <fwp_main_thread+0x838>
    9f9d:	48 8b 9c 24 c0 00 00 	mov    0xc0(%rsp),%rbx
    9fa4:	00 
    9fa5:	66 0f 6f 05 73 2e 00 	movdqa 0x2e73(%rip),%xmm0        # ce20 <msg.8+0xe0>
    9fac:	00 
    9fad:	bf 01 00 00 00       	mov    $0x1,%edi
    9fb2:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    9fb9:	00 
    9fba:	48 89 1d 17 05 06 00 	mov    %rbx,0x60517(%rip)        # 6a4d8 <fwp_cleanups>
    9fc1:	0f 29 84 24 40 01 00 	movaps %xmm0,0x140(%rsp)
    9fc8:	00 
    9fc9:	e8 92 c1 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    9fce:	48 8b 15 43 fc 05 00 	mov    0x5fc43(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    9fd5:	49 89 c5             	mov    %rax,%r13
    9fd8:	48 2b 05 11 fc 05 00 	sub    0x5fc11(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    9fdf:	48 c1 e2 10          	shl    $0x10,%rdx
    9fe3:	48 39 d0             	cmp    %rdx,%rax
    9fe6:	73 59                	jae    a041 <fwp_main_thread+0x961>
    9fe8:	48 89 c2             	mov    %rax,%rdx
    9feb:	48 c1 ea 10          	shr    $0x10,%rdx
    9fef:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ff3:	48 8b 15 3e fc 05 00 	mov    0x5fc3e(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    9ffa:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9ffe:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a002:	4d 85 e4             	test   %r12,%r12
    a005:	74 3a                	je     a041 <fwp_main_thread+0x961>
    a007:	0f b6 0a             	movzbl (%rdx),%ecx
    a00a:	80 f9 02             	cmp    $0x2,%cl
    a00d:	0f 84 bb 17 00 00    	je     b7ce <fwp_main_thread+0x20ee>
    a013:	80 f9 01             	cmp    $0x1,%cl
    a016:	75 29                	jne    a041 <fwp_main_thread+0x961>
    a018:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a01b:	0f b7 c0             	movzwl %ax,%eax
    a01e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a021:	48 0f af c1          	imul   %rcx,%rax
    a025:	48 c1 e8 20          	shr    $0x20,%rax
    a029:	48 39 d0             	cmp    %rdx,%rax
    a02c:	73 13                	jae    a041 <fwp_main_thread+0x961>
    a02e:	49 01 c4             	add    %rax,%r12
    a031:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a036:	0f 84 63 19 00 00    	je     b99f <fwp_main_thread+0x22bf>
    a03c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a041:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    a048:	00 f0 3f 
    a04b:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    a052:	00 
    a053:	bf 01 00 00 00       	mov    $0x1,%edi
    a058:	4c 89 ac 24 38 01 00 	mov    %r13,0x138(%rsp)
    a05f:	00 
    a060:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
    a067:	00 
    a068:	e8 f3 c0 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    a06d:	48 8b 15 a4 fb 05 00 	mov    0x5fba4(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    a074:	49 89 c5             	mov    %rax,%r13
    a077:	48 2b 05 72 fb 05 00 	sub    0x5fb72(%rip),%rax        # 69bf0 <fwp_heap+0x13b0>
    a07e:	48 c1 e2 10          	shl    $0x10,%rdx
    a082:	48 39 d0             	cmp    %rdx,%rax
    a085:	73 59                	jae    a0e0 <fwp_main_thread+0xa00>
    a087:	48 89 c2             	mov    %rax,%rdx
    a08a:	48 c1 ea 10          	shr    $0x10,%rdx
    a08e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a092:	48 8b 15 9f fb 05 00 	mov    0x5fb9f(%rip),%rdx        # 69c38 <fwp_heap+0x13f8>
    a099:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a09d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a0a1:	4d 85 e4             	test   %r12,%r12
    a0a4:	74 3a                	je     a0e0 <fwp_main_thread+0xa00>
    a0a6:	0f b6 0a             	movzbl (%rdx),%ecx
    a0a9:	80 f9 02             	cmp    $0x2,%cl
    a0ac:	0f 84 2a 17 00 00    	je     b7dc <fwp_main_thread+0x20fc>
    a0b2:	80 f9 01             	cmp    $0x1,%cl
    a0b5:	75 29                	jne    a0e0 <fwp_main_thread+0xa00>
    a0b7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a0ba:	0f b7 c0             	movzwl %ax,%eax
    a0bd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a0c0:	48 0f af c1          	imul   %rcx,%rax
    a0c4:	48 c1 e8 20          	shr    $0x20,%rax
    a0c8:	48 39 d0             	cmp    %rdx,%rax
    a0cb:	73 13                	jae    a0e0 <fwp_main_thread+0xa00>
    a0cd:	49 01 c4             	add    %rax,%r12
    a0d0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a0d5:	0f 84 d1 18 00 00    	je     b9ac <fwp_main_thread+0x22cc>
    a0db:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a0e0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a0e7:	33 f3 bf 
    a0ea:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    a0f1:	00 
    a0f2:	bf 01 00 00 00       	mov    $0x1,%edi
    a0f7:	4c 89 ac 24 28 01 00 	mov    %r13,0x128(%rsp)
    a0fe:	00 
    a0ff:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
    a106:	00 
    a107:	e8 54 c0 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    a10c:	48 8b 15 05 fb 05 00 	mov    0x5fb05(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    a113:	48 8b 0d d6 fa 05 00 	mov    0x5fad6(%rip),%rcx        # 69bf0 <fwp_heap+0x13b0>
    a11a:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a11f:	48 89 d6             	mov    %rdx,%rsi
    a122:	48 29 c8             	sub    %rcx,%rax
    a125:	48 c1 e6 10          	shl    $0x10,%rsi
    a129:	48 39 f0             	cmp    %rsi,%rax
    a12c:	73 69                	jae    a197 <fwp_main_thread+0xab7>
    a12e:	48 89 c6             	mov    %rax,%rsi
    a131:	48 c1 ee 10          	shr    $0x10,%rsi
    a135:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a139:	48 8b 35 f8 fa 05 00 	mov    0x5faf8(%rip),%rsi        # 69c38 <fwp_heap+0x13f8>
    a140:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a144:	4c 8b 66 20          	mov    0x20(%rsi),%r12
    a148:	4d 85 e4             	test   %r12,%r12
    a14b:	74 4a                	je     a197 <fwp_main_thread+0xab7>
    a14d:	0f b6 3e             	movzbl (%rsi),%edi
    a150:	40 80 ff 02          	cmp    $0x2,%dil
    a154:	0f 84 66 16 00 00    	je     b7c0 <fwp_main_thread+0x20e0>
    a15a:	40 80 ff 01          	cmp    $0x1,%dil
    a15e:	75 37                	jne    a197 <fwp_main_thread+0xab7>
    a160:	8b 7e 18             	mov    0x18(%rsi),%edi
    a163:	0f b7 c0             	movzwl %ax,%eax
    a166:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a169:	48 0f af c7          	imul   %rdi,%rax
    a16d:	48 c1 e8 20          	shr    $0x20,%rax
    a171:	48 39 f0             	cmp    %rsi,%rax
    a174:	73 21                	jae    a197 <fwp_main_thread+0xab7>
    a176:	49 01 c4             	add    %rax,%r12
    a179:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a17e:	0f 84 0e 18 00 00    	je     b992 <fwp_main_thread+0x22b2>
    a184:	41 c6 04 24 01       	movb   $0x1,(%r12)
    a189:	48 8b 0d 60 fa 05 00 	mov    0x5fa60(%rip),%rcx        # 69bf0 <fwp_heap+0x13b0>
    a190:	48 8b 15 81 fa 05 00 	mov    0x5fa81(%rip),%rdx        # 69c18 <fwp_heap+0x13d8>
    a197:	48 8d 84 24 9c 00 00 	lea    0x9c(%rsp),%rax
    a19e:	00 
    a19f:	4c 89 74 24 58       	mov    %r14,0x58(%rsp)
    a1a4:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    a1a9:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    a1b0:	00 
    a1b1:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    a1b6:	4c 89 b4 24 88 00 00 	mov    %r14,0x88(%rsp)
    a1bd:	00 
    a1be:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a1c3:	48 c1 e2 10          	shl    $0x10,%rdx
    a1c7:	48 29 c8             	sub    %rcx,%rax
    a1ca:	48 39 d0             	cmp    %rdx,%rax
    a1cd:	0f 83 87 00 00 00    	jae    a25a <fwp_main_thread+0xb7a>
    a1d3:	48 89 c6             	mov    %rax,%rsi
    a1d6:	48 c1 ee 10          	shr    $0x10,%rsi
    a1da:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a1de:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    a1e5:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a1e9:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a1ed:	48 85 ff             	test   %rdi,%rdi
    a1f0:	74 68                	je     a25a <fwp_main_thread+0xb7a>
    a1f2:	44 0f b6 06          	movzbl (%rsi),%r8d
    a1f6:	41 80 f8 02          	cmp    $0x2,%r8b
    a1fa:	0f 84 f0 14 00 00    	je     b6f0 <fwp_main_thread+0x2010>
    a200:	41 80 f8 01          	cmp    $0x1,%r8b
    a204:	75 54                	jne    a25a <fwp_main_thread+0xb7a>
    a206:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a20a:	0f b7 c0             	movzwl %ax,%eax
    a20d:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a210:	49 0f af c0          	imul   %r8,%rax
    a214:	48 c1 e8 20          	shr    $0x20,%rax
    a218:	48 39 f0             	cmp    %rsi,%rax
    a21b:	73 3d                	jae    a25a <fwp_main_thread+0xb7a>
    a21d:	48 01 c7             	add    %rax,%rdi
    a220:	0f b6 07             	movzbl (%rdi),%eax
    a223:	84 c0                	test   %al,%al
    a225:	74 33                	je     a25a <fwp_main_thread+0xb7a>
    a227:	44 8b 05 da 02 06 00 	mov    0x602da(%rip),%r8d        # 6a508 <iteration_active>
    a22e:	45 85 c0             	test   %r8d,%r8d
    a231:	74 08                	je     a23b <fwp_main_thread+0xb5b>
    a233:	48 83 05 b5 02 06 00 	addq   $0x1,0x602b5(%rip)        # 6a4f0 <iteration_retains>
    a23a:	01 
    a23b:	3c fd                	cmp    $0xfd,%al
    a23d:	0f 87 cb 16 00 00    	ja     b90e <fwp_main_thread+0x222e>
    a243:	83 c0 01             	add    $0x1,%eax
    a246:	88 07                	mov    %al,(%rdi)
    a248:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a24f:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    a256:	48 c1 e2 10          	shl    $0x10,%rdx
    a25a:	48 8d 05 bf cd ff ff 	lea    -0x3241(%rip),%rax        # 7020 <fwp_tape_scope_release>
    a261:	48 89 9c 24 a0 00 00 	mov    %rbx,0xa0(%rsp)
    a268:	00 
    a269:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    a270:	00 
    a271:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    a276:	c7 84 24 9c 00 00 00 	movl   $0xffffffff,0x9c(%rsp)
    a27d:	ff ff ff ff 
    a281:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    a288:	00 
    a289:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    a28e:	48 89 05 43 02 06 00 	mov    %rax,0x60243(%rip)        # 6a4d8 <fwp_cleanups>
    a295:	48 8d 05 74 5d 00 00 	lea    0x5d74(%rip),%rax        # 10010 <fc37>
    a29c:	48 29 c8             	sub    %rcx,%rax
    a29f:	48 39 d0             	cmp    %rdx,%rax
    a2a2:	73 6f                	jae    a313 <fwp_main_thread+0xc33>
    a2a4:	48 89 c2             	mov    %rax,%rdx
    a2a7:	48 c1 ea 10          	shr    $0x10,%rdx
    a2ab:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a2af:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a2b6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a2ba:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a2be:	48 85 ff             	test   %rdi,%rdi
    a2c1:	74 50                	je     a313 <fwp_main_thread+0xc33>
    a2c3:	0f b6 0a             	movzbl (%rdx),%ecx
    a2c6:	80 f9 02             	cmp    $0x2,%cl
    a2c9:	0f 84 21 12 00 00    	je     b4f0 <fwp_main_thread+0x1e10>
    a2cf:	80 f9 01             	cmp    $0x1,%cl
    a2d2:	75 3f                	jne    a313 <fwp_main_thread+0xc33>
    a2d4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a2d7:	0f b7 c0             	movzwl %ax,%eax
    a2da:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a2dd:	48 0f af c1          	imul   %rcx,%rax
    a2e1:	48 c1 e8 20          	shr    $0x20,%rax
    a2e5:	48 39 d0             	cmp    %rdx,%rax
    a2e8:	73 29                	jae    a313 <fwp_main_thread+0xc33>
    a2ea:	48 01 c7             	add    %rax,%rdi
    a2ed:	0f b6 07             	movzbl (%rdi),%eax
    a2f0:	84 c0                	test   %al,%al
    a2f2:	74 1f                	je     a313 <fwp_main_thread+0xc33>
    a2f4:	8b 35 0e 02 06 00    	mov    0x6020e(%rip),%esi        # 6a508 <iteration_active>
    a2fa:	85 f6                	test   %esi,%esi
    a2fc:	74 08                	je     a306 <fwp_main_thread+0xc26>
    a2fe:	48 83 05 ea 01 06 00 	addq   $0x1,0x601ea(%rip)        # 6a4f0 <iteration_retains>
    a305:	01 
    a306:	3c fd                	cmp    $0xfd,%al
    a308:	0f 87 ba 15 00 00    	ja     b8c8 <fwp_main_thread+0x21e8>
    a30e:	83 c0 01             	add    $0x1,%eax
    a311:	88 07                	mov    %al,(%rdi)
    a313:	48 8d 3d f6 5c 00 00 	lea    0x5cf6(%rip),%rdi        # 10010 <fc37>
    a31a:	31 db                	xor    %ebx,%ebx
    a31c:	e8 7f c9 ff ff       	call   6ca0 <fwp_closure_drop>
    a321:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    a326:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a32d:	00 00 00 
    a330:	4d 8b 64 24 10       	mov    0x10(%r12),%r12
    a335:	48 83 c3 01          	add    $0x1,%rbx
    a339:	4d 85 e4             	test   %r12,%r12
    a33c:	75 f2                	jne    a330 <fwp_main_thread+0xc50>
    a33e:	48 81 fb ff ff ff 7f 	cmp    $0x7fffffff,%rbx
    a345:	0f 87 7f 16 00 00    	ja     b9ca <fwp_main_thread+0x22ea>
    a34b:	8b 0d 2b 5d 00 00    	mov    0x5d2b(%rip),%ecx        # 1007c <registered_finish.5>
    a351:	85 c9                	test   %ecx,%ecx
    a353:	0f 84 5f 11 00 00    	je     b4b8 <fwp_main_thread+0x1dd8>
    a359:	4c 8b 2d 98 5d 01 00 	mov    0x15d98(%rip),%r13        # 200f8 <fwp_tape_next_slot>
    a360:	4c 8b 35 a1 5d 01 00 	mov    0x15da1(%rip),%r14        # 20108 <fwp_ntapes>
    a367:	4d 39 f5             	cmp    %r14,%r13
    a36a:	0f 8d 28 0e 00 00    	jge    b198 <fwp_main_thread+0x1ab8>
    a370:	49 6b c5 68          	imul   $0x68,%r13,%rax
    a374:	48 03 05 95 5d 01 00 	add    0x15d95(%rip),%rax        # 20110 <fwp_tapes>
    a37b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a380:	8b 50 04             	mov    0x4(%rax),%edx
    a383:	85 d2                	test   %edx,%edx
    a385:	75 0c                	jne    a393 <fwp_main_thread+0xcb3>
    a387:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    a38d:	0f 86 05 0e 00 00    	jbe    b198 <fwp_main_thread+0x1ab8>
    a393:	49 83 c5 01          	add    $0x1,%r13
    a397:	48 83 c0 68          	add    $0x68,%rax
    a39b:	4d 39 f5             	cmp    %r14,%r13
    a39e:	75 e0                	jne    a380 <fwp_main_thread+0xca0>
    a3a0:	49 81 fe fe ff 00 00 	cmp    $0xfffe,%r14
    a3a7:	0f 8f 99 16 00 00    	jg     ba46 <fwp_main_thread+0x2366>
    a3ad:	4c 39 35 4c 5d 01 00 	cmp    %r14,0x15d4c(%rip)        # 20100 <fwp_tapes_cap>
    a3b4:	4c 8b 3d 55 5d 01 00 	mov    0x15d55(%rip),%r15        # 20110 <fwp_tapes>
    a3bb:	75 4b                	jne    a408 <fwp_main_thread+0xd28>
    a3bd:	4d 85 f6             	test   %r14,%r14
    a3c0:	0f 84 94 13 00 00    	je     b75a <fwp_main_thread+0x207a>
    a3c6:	4b 8d 0c 36          	lea    (%r14,%r14,1),%rcx
    a3ca:	b8 ff ff 00 00       	mov    $0xffff,%eax
    a3cf:	48 39 c1             	cmp    %rax,%rcx
    a3d2:	48 0f 4f c8          	cmovg  %rax,%rcx
    a3d6:	48 6b f1 68          	imul   $0x68,%rcx,%rsi
    a3da:	31 d2                	xor    %edx,%edx
    a3dc:	4c 89 ff             	mov    %r15,%rdi
    a3df:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a3e4:	e8 07 ae ff ff       	call   51f0 <ad_raw_realloc>
    a3e9:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    a3ee:	48 85 c0             	test   %rax,%rax
    a3f1:	49 89 c7             	mov    %rax,%r15
    a3f4:	0f 84 0d 16 00 00    	je     ba07 <fwp_main_thread+0x2327>
    a3fa:	48 89 05 0f 5d 01 00 	mov    %rax,0x15d0f(%rip)        # 20110 <fwp_tapes>
    a401:	48 89 0d f8 5c 01 00 	mov    %rcx,0x15cf8(%rip)        # 20100 <fwp_tapes_cap>
    a408:	49 6b c6 68          	imul   $0x68,%r14,%rax
    a40c:	49 83 c6 01          	add    $0x1,%r14
    a410:	4c 01 f8             	add    %r15,%rax
    a413:	48 8d 78 08          	lea    0x8(%rax),%rdi
    a417:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a41e:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    a422:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    a429:	00 
    a42a:	48 29 f8             	sub    %rdi,%rax
    a42d:	8d 48 68             	lea    0x68(%rax),%ecx
    a430:	31 c0                	xor    %eax,%eax
    a432:	c1 e9 03             	shr    $0x3,%ecx
    a435:	f3 48 ab             	rep stos %rax,(%rdi)
    a438:	4c 89 35 c9 5c 01 00 	mov    %r14,0x15cc9(%rip)        # 20108 <fwp_ntapes>
    a43f:	4d 6b f5 68          	imul   $0x68,%r13,%r14
    a443:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    a448:	48 8d 3d 11 1d 00 00 	lea    0x1d11(%rip),%rdi        # c160 <_IO_stdin_used+0x160>
    a44f:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    a453:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    a458:	4d 01 fe             	add    %r15,%r14
    a45b:	49 c7 46 60 00 00 00 	movq   $0x0,0x60(%r14)
    a462:	00 
    a463:	e8 28 8f ff ff       	call   3390 <getenv@plt>
    a468:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    a46e:	48 85 c0             	test   %rax,%rax
    a471:	0f 84 39 0d 00 00    	je     b1b0 <fwp_main_thread+0x1ad0>
    a477:	80 38 30             	cmpb   $0x30,(%rax)
    a47a:	0f 85 30 0d 00 00    	jne    b1b0 <fwp_main_thread+0x1ad0>
    a480:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    a484:	0f 85 26 0d 00 00    	jne    b1b0 <fwp_main_thread+0x1ad0>
    a48a:	41 8b 06             	mov    (%r14),%eax
    a48d:	49 8d 5d 01          	lea    0x1(%r13),%rbx
    a491:	41 c7 46 04 01 00 00 	movl   $0x1,0x4(%r14)
    a498:	00 
    a499:	48 89 1d 58 5c 01 00 	mov    %rbx,0x15c58(%rip)        # 200f8 <fwp_tape_next_slot>
    a4a0:	8d 50 01             	lea    0x1(%rax),%edx
    a4a3:	48 8b 05 b6 28 00 00 	mov    0x28b6(%rip),%rax        # cd60 <msg.8+0x20>
    a4aa:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
    a4af:	41 89 16             	mov    %edx,(%r14)
    a4b2:	49 89 46 58          	mov    %rax,0x58(%r14)
    a4b6:	48 8b 05 1b 00 06 00 	mov    0x6001b(%rip),%rax        # 6a4d8 <fwp_cleanups>
    a4bd:	49 c7 46 50 00 00 00 	movq   $0x0,0x50(%r14)
    a4c4:	00 
    a4c5:	48 85 c0             	test   %rax,%rax
    a4c8:	75 22                	jne    a4ec <fwp_main_thread+0xe0c>
    a4ca:	e9 89 15 00 00       	jmp    ba58 <fwp_main_thread+0x2378>
    a4cf:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a4d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a4dc:	00 00 00 00 
    a4e0:	48 8b 00             	mov    (%rax),%rax
    a4e3:	48 85 c0             	test   %rax,%rax
    a4e6:	0f 84 6c 15 00 00    	je     ba58 <fwp_main_thread+0x2378>
    a4ec:	48 8d 3d 2d cb ff ff 	lea    -0x34d3(%rip),%rdi        # 7020 <fwp_tape_scope_release>
    a4f3:	48 39 78 08          	cmp    %rdi,0x8(%rax)
    a4f7:	75 e7                	jne    a4e0 <fwp_main_thread+0xe00>
    a4f9:	48 8b 70 10          	mov    0x10(%rax),%rsi
    a4fd:	44 89 e9             	mov    %r13d,%ecx
    a500:	48 63 06             	movslq (%rsi),%rax
    a503:	49 89 76 50          	mov    %rsi,0x50(%r14)
    a507:	41 89 46 5c          	mov    %eax,0x5c(%r14)
    a50b:	85 c0                	test   %eax,%eax
    a50d:	78 09                	js     a518 <fwp_main_thread+0xe38>
    a50f:	48 6b c0 68          	imul   $0x68,%rax,%rax
    a513:	45 89 6c 07 58       	mov    %r13d,0x58(%r15,%rax,1)
    a518:	89 0e                	mov    %ecx,(%rsi)
    a51a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a51f:	90                   	nop
    a520:	48 8b 40 10          	mov    0x10(%rax),%rax
    a524:	49 83 c4 01          	add    $0x1,%r12
    a528:	48 85 c0             	test   %rax,%rax
    a52b:	75 f3                	jne    a520 <fwp_main_thread+0xe40>
    a52d:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    a532:	0f 1f 00             	nopl   (%rax)
    a535:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a53c:	00 00 00 00 
    a540:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    a544:	48 83 c0 01          	add    $0x1,%rax
    a548:	4d 85 ff             	test   %r15,%r15
    a54b:	75 f3                	jne    a540 <fwp_main_thread+0xe60>
    a54d:	48 b9 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rcx
    a554:	ff ff 1f 
    a557:	48 39 c1             	cmp    %rax,%rcx
    a55a:	0f 82 76 14 00 00    	jb     b9d6 <fwp_main_thread+0x22f6>
    a560:	4d 85 e4             	test   %r12,%r12
    a563:	0f 8e c7 0d 00 00    	jle    b330 <fwp_main_thread+0x1c50>
    a569:	49 39 c4             	cmp    %rax,%r12
    a56c:	4c 0f 47 e0          	cmova  %rax,%r12
    a570:	4c 89 e0             	mov    %r12,%rax
    a573:	48 c1 e8 3c          	shr    $0x3c,%rax
    a577:	0f 85 59 14 00 00    	jne    b9d6 <fwp_main_thread+0x22f6>
    a57d:	4f 8d 2c 24          	lea    (%r12,%r12,1),%r13
    a581:	48 c1 e2 10          	shl    $0x10,%rdx
    a585:	be 02 00 00 00       	mov    $0x2,%esi
    a58a:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    a591:	00 
    a592:	48 09 d3             	or     %rdx,%rbx
    a595:	e8 d6 b9 ff ff       	call   5f70 <fwp_heap_alloc>
    a59a:	4c 89 28             	mov    %r13,(%rax)
    a59d:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a5a4:	49 89 c6             	mov    %rax,%r14
    a5a7:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a5ae:	48 c1 e2 10          	shl    $0x10,%rdx
    a5b2:	48 39 d0             	cmp    %rdx,%rax
    a5b5:	0f 83 55 0d 00 00    	jae    b310 <fwp_main_thread+0x1c30>
    a5bb:	48 89 c2             	mov    %rax,%rdx
    a5be:	48 c1 ea 10          	shr    $0x10,%rdx
    a5c2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a5c6:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a5cd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a5d1:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a5d5:	4d 85 ed             	test   %r13,%r13
    a5d8:	74 3a                	je     a614 <fwp_main_thread+0xf34>
    a5da:	0f b6 0a             	movzbl (%rdx),%ecx
    a5dd:	80 f9 02             	cmp    $0x2,%cl
    a5e0:	0f 84 b3 0d 00 00    	je     b399 <fwp_main_thread+0x1cb9>
    a5e6:	80 f9 01             	cmp    $0x1,%cl
    a5e9:	75 29                	jne    a614 <fwp_main_thread+0xf34>
    a5eb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a5ee:	0f b7 c0             	movzwl %ax,%eax
    a5f1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a5f4:	48 0f af c1          	imul   %rcx,%rax
    a5f8:	48 c1 e8 20          	shr    $0x20,%rax
    a5fc:	48 39 d0             	cmp    %rdx,%rax
    a5ff:	73 13                	jae    a614 <fwp_main_thread+0xf34>
    a601:	49 01 c5             	add    %rax,%r13
    a604:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a609:	0f 84 9e 0d 00 00    	je     b3ad <fwp_main_thread+0x1ccd>
    a60f:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a614:	4d 85 e4             	test   %r12,%r12
    a617:	74 5b                	je     a674 <fwp_main_thread+0xf94>
    a619:	48 89 d9             	mov    %rbx,%rcx
    a61c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    a621:	31 c0                	xor    %eax,%eax
    a623:	48 c1 e1 20          	shl    $0x20,%rcx
    a627:	0f 1f 00             	nopl   (%rax)
    a62a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a631:	00 00 00 00 
    a635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a63c:	00 00 00 00 
    a640:	48 89 c6             	mov    %rax,%rsi
    a643:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    a648:	48 01 ce             	add    %rcx,%rsi
    a64b:	0f 80 68 13 00 00    	jo     b9b9 <fwp_main_thread+0x22d9>
    a651:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    a656:	48 89 c6             	mov    %rax,%rsi
    a659:	48 83 c0 01          	add    $0x1,%rax
    a65d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    a661:	48 c1 e6 04          	shl    $0x4,%rsi
    a665:	41 0f 11 44 36 08    	movups %xmm0,0x8(%r14,%rsi,1)
    a66b:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a66f:	4c 39 e0             	cmp    %r12,%rax
    a672:	72 cc                	jb     a640 <fwp_main_thread+0xf60>
    a674:	49 8b 06             	mov    (%r14),%rax
    a677:	48 d1 e8             	shr    $1,%rax
    a67a:	0f 84 a0 0c 00 00    	je     b320 <fwp_main_thread+0x1c40>
    a680:	48 8d 48 ff          	lea    -0x1(%rax),%rcx
    a684:	48 89 cf             	mov    %rcx,%rdi
    a687:	48 c1 ef 3c          	shr    $0x3c,%rdi
    a68b:	0f 85 45 13 00 00    	jne    b9d6 <fwp_main_thread+0x22f6>
    a691:	48 8d 14 09          	lea    (%rcx,%rcx,1),%rdx
    a695:	48 85 c9             	test   %rcx,%rcx
    a698:	74 49                	je     a6e3 <fwp_main_thread+0x1003>
    a69a:	48 c1 e0 04          	shl    $0x4,%rax
    a69e:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    a6a3:	49 89 d5             	mov    %rdx,%r13
    a6a6:	49 8d 5e 08          	lea    0x8(%r14),%rbx
    a6aa:	4d 8d 64 06 f8       	lea    -0x8(%r14,%rax,1),%r12
    a6af:	90                   	nop
    a6b0:	f2 0f 10 03          	movsd  (%rbx),%xmm0
    a6b4:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    a6b8:	48 83 c3 10          	add    $0x10,%rbx
    a6bc:	48 8b 7b f8          	mov    -0x8(%rbx),%rdi
    a6c0:	f2 0f 10 0b          	movsd  (%rbx),%xmm1
    a6c4:	e8 07 c0 ff ff       	call   66d0 <w120>
    a6c9:	66 48 0f 6e e8       	movq   %rax,%xmm5
    a6ce:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    a6d2:	0f 11 43 f0          	movups %xmm0,-0x10(%rbx)
    a6d6:	49 39 dc             	cmp    %rbx,%r12
    a6d9:	75 d5                	jne    a6b0 <fwp_main_thread+0xfd0>
    a6db:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    a6e0:	4c 89 ea             	mov    %r13,%rdx
    a6e3:	49 89 16             	mov    %rdx,(%r14)
    a6e6:	4c 89 f7             	mov    %r14,%rdi
    a6e9:	4c 63 eb             	movslq %ebx,%r13
    a6ec:	e8 5f c1 ff ff       	call   6850 <w176.constprop.0>
    a6f1:	4c 89 f7             	mov    %r14,%rdi
    a6f4:	49 89 c4             	mov    %rax,%r12
    a6f7:	e8 74 d8 ff ff       	call   7f70 <fwp_drop10>
    a6fc:	4c 89 ef             	mov    %r13,%rdi
    a6ff:	e8 bc a8 ff ff       	call   4fc0 <caf75>
    a704:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    a709:	e8 22 a0 ff ff       	call   4730 <fwp_tape_of>
    a70e:	48 89 c6             	mov    %rax,%rsi
    a711:	48 8b 40 60          	mov    0x60(%rax),%rax
    a715:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    a71a:	48 85 c0             	test   %rax,%rax
    a71d:	0f 85 65 13 00 00    	jne    ba88 <fwp_main_thread+0x23a8>
    a723:	48 89 f7             	mov    %rsi,%rdi
    a726:	e8 65 95 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    a72b:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    a72f:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    a734:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    a73b:	4c 8b 4e 08          	mov    0x8(%rsi),%r9
    a73f:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    a743:	66 49 0f 6e fe       	movq   %r14,%xmm7
    a748:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    a74d:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    a752:	4c 8b 46 40          	mov    0x40(%rsi),%r8
    a756:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    a75a:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    a760:	77 18                	ja     a77a <fwp_main_thread+0x109a>
    a762:	0f b7 c3             	movzwl %bx,%eax
    a765:	83 e8 01             	sub    $0x1,%eax
    a768:	48 98                	cltq
    a76a:	48 3b 05 87 59 01 00 	cmp    0x15987(%rip),%rax        # 200f8 <fwp_tape_next_slot>
    a771:	7d 07                	jge    a77a <fwp_main_thread+0x109a>
    a773:	48 89 05 7e 59 01 00 	mov    %rax,0x1597e(%rip)        # 200f8 <fwp_tape_next_slot>
    a77a:	48 8b 05 57 fd 05 00 	mov    0x5fd57(%rip),%rax        # 6a4d8 <fwp_cleanups>
    a781:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a785:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    a78c:	00 
    a78d:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    a794:	00 
    a795:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    a79c:	00 
    a79d:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    a7a1:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    a7a5:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    a7a9:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    a7b0:	00 
    a7b1:	48 8d 05 08 ab ff ff 	lea    -0x54f8(%rip),%rax        # 52c0 <fwp_tape_buffers_release>
    a7b8:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    a7bf:	00 
    a7c0:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    a7c5:	4c 89 84 24 00 01 00 	mov    %r8,0x100(%rsp)
    a7cc:	00 
    a7cd:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
    a7d4:	00 
    a7d5:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    a7da:	0f 29 9c 24 e0 00 00 	movaps %xmm3,0xe0(%rsp)
    a7e1:	00 
    a7e2:	48 89 05 ef fc 05 00 	mov    %rax,0x5fcef(%rip)        # 6a4d8 <fwp_cleanups>
    a7e9:	0f 29 94 24 f0 00 00 	movaps %xmm2,0xf0(%rsp)
    a7f0:	00 
    a7f1:	0f 11 84 24 08 01 00 	movups %xmm0,0x108(%rsp)
    a7f8:	00 
    a7f9:	4d 85 e4             	test   %r12,%r12
    a7fc:	0f 88 fe 0c 00 00    	js     b500 <fwp_main_thread+0x1e20>
    a802:	4c 89 e0             	mov    %r12,%rax
    a805:	48 c1 f8 20          	sar    $0x20,%rax
    a809:	49 39 c5             	cmp    %rax,%r13
    a80c:	0f 85 68 11 00 00    	jne    b97a <fwp_main_thread+0x229a>
    a812:	44 89 e1             	mov    %r12d,%ecx
    a815:	49 89 cd             	mov    %rcx,%r13
    a818:	48 39 ca             	cmp    %rcx,%rdx
    a81b:	0f 8e 65 11 00 00    	jle    b986 <fwp_main_thread+0x22a6>
    a821:	49 39 c9             	cmp    %rcx,%r9
    a824:	0f 8e 96 0b 00 00    	jle    b3c0 <fwp_main_thread+0x1ce0>
    a82a:	4d 39 f1             	cmp    %r14,%r9
    a82d:	0f 8f cd 0b 00 00    	jg     b400 <fwp_main_thread+0x1d20>
    a833:	4d 85 c0             	test   %r8,%r8
    a836:	0f 84 b2 11 00 00    	je     b9ee <fwp_main_thread+0x230e>
    a83c:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
    a841:	4d 8d 69 ff          	lea    -0x1(%r9),%r13
    a845:	31 f6                	xor    %esi,%esi
    a847:	4c 89 c7             	mov    %r8,%rdi
    a84a:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
    a851:	00 
    a852:	4a 8d 14 cd 00 00 00 	lea    0x0(,%r9,8),%rdx
    a859:	00 
    a85a:	0f 29 5c 24 70       	movaps %xmm3,0x70(%rsp)
    a85f:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
    a864:	e8 47 8c ff ff       	call   34b0 <memset@plt>
    a869:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
    a86e:	66 0f 6f 54 24 60    	movdqa 0x60(%rsp),%xmm2
    a874:	66 0f 6f 5c 24 70    	movdqa 0x70(%rsp),%xmm3
    a87a:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
    a881:	00 
    a882:	49 89 c0             	mov    %rax,%r8
    a885:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    a88b:	f2 41 0f 58 04 c8    	addsd  (%r8,%rcx,8),%xmm0
    a891:	f2 41 0f 11 04 c8    	movsd  %xmm0,(%r8,%rcx,8)
    a897:	4d 39 e9             	cmp    %r13,%r9
    a89a:	0f 8f 91 00 00 00    	jg     a931 <fwp_main_thread+0x1251>
    a8a0:	0f 12 fb             	movhlps %xmm3,%xmm7
    a8a3:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    a8a8:	0f 12 da             	movhlps %xmm2,%xmm3
    a8ab:	4d 29 cd             	sub    %r9,%r13
    a8ae:	66 49 0f 7e da       	movq   %xmm3,%r10
    a8b3:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    a8b8:	66 48 0f 7e d7       	movq   %xmm2,%rdi
    a8bd:	4f 8d 1c c8          	lea    (%r8,%r9,8),%r11
    a8c1:	4b 8d 14 ea          	lea    (%r10,%r13,8),%rdx
    a8c5:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a8c9:	48 29 f1             	sub    %rsi,%rcx
    a8cc:	4a 8d 04 ae          	lea    (%rsi,%r13,4),%rax
    a8d0:	4d 29 d3             	sub    %r10,%r11
    a8d3:	4c 29 d7             	sub    %r10,%rdi
    a8d6:	eb 0c                	jmp    a8e4 <fwp_main_thread+0x1204>
    a8d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a8df:	00 
    a8e0:	48 83 e8 04          	sub    $0x4,%rax
    a8e4:	f2 41 0f 10 04 13    	movsd  (%r11,%rdx,1),%xmm0
    a8ea:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    a8ee:	7a 02                	jp     a8f2 <fwp_main_thread+0x1212>
    a8f0:	74 36                	je     a928 <fwp_main_thread+0x1248>
    a8f2:	4c 63 14 01          	movslq (%rcx,%rax,1),%r10
    a8f6:	45 85 d2             	test   %r10d,%r10d
    a8f9:	78 15                	js     a910 <fwp_main_thread+0x1230>
    a8fb:	f2 0f 10 0c 17       	movsd  (%rdi,%rdx,1),%xmm1
    a900:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    a904:	f2 43 0f 58 0c d0    	addsd  (%r8,%r10,8),%xmm1
    a90a:	f2 43 0f 11 0c d0    	movsd  %xmm1,(%r8,%r10,8)
    a910:	4c 63 10             	movslq (%rax),%r10
    a913:	45 85 d2             	test   %r10d,%r10d
    a916:	78 10                	js     a928 <fwp_main_thread+0x1248>
    a918:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    a91c:	f2 43 0f 58 04 d0    	addsd  (%r8,%r10,8),%xmm0
    a922:	f2 43 0f 11 04 d0    	movsd  %xmm0,(%r8,%r10,8)
    a928:	48 83 ea 08          	sub    $0x8,%rdx
    a92c:	48 39 f0             	cmp    %rsi,%rax
    a92f:	75 af                	jne    a8e0 <fwp_main_thread+0x1200>
    a931:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a938:	ff ff 1f 
    a93b:	4c 39 c8             	cmp    %r9,%rax
    a93e:	0f 82 9e 10 00 00    	jb     b9e2 <fwp_main_thread+0x2302>
    a944:	4a 8d 3c cd 08 00 00 	lea    0x8(,%r9,8),%rdi
    a94b:	00 
    a94c:	be 02 00 00 00       	mov    $0x2,%esi
    a951:	4c 89 44 24 38       	mov    %r8,0x38(%rsp)
    a956:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    a95b:	e8 10 b6 ff ff       	call   5f70 <fwp_heap_alloc>
    a960:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    a965:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
    a96a:	48 89 c3             	mov    %rax,%rbx
    a96d:	4c 89 08             	mov    %r9,(%rax)
    a970:	31 c0                	xor    %eax,%eax
    a972:	4d 85 c9             	test   %r9,%r9
    a975:	74 1b                	je     a992 <fwp_main_thread+0x12b2>
    a977:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a97e:	00 00 
    a980:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    a984:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    a989:	48 83 c0 01          	add    $0x1,%rax
    a98d:	49 39 c1             	cmp    %rax,%r9
    a990:	75 ee                	jne    a980 <fwp_main_thread+0x12a0>
    a992:	4c 8b a4 24 c0 00 00 	mov    0xc0(%rsp),%r12
    a999:	00 
    a99a:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    a99f:	4c 89 25 32 fb 05 00 	mov    %r12,0x5fb32(%rip)        # 6a4d8 <fwp_cleanups>
    a9a6:	e8 15 a9 ff ff       	call   52c0 <fwp_tape_buffers_release>
    a9ab:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a9b2:	48 89 d8             	mov    %rbx,%rax
    a9b5:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a9bc:	48 c1 e2 10          	shl    $0x10,%rdx
    a9c0:	48 39 d0             	cmp    %rdx,%rax
    a9c3:	73 59                	jae    aa1e <fwp_main_thread+0x133e>
    a9c5:	48 89 c2             	mov    %rax,%rdx
    a9c8:	48 c1 ea 10          	shr    $0x10,%rdx
    a9cc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a9d0:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a9d7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a9db:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a9df:	4d 85 ed             	test   %r13,%r13
    a9e2:	74 3a                	je     aa1e <fwp_main_thread+0x133e>
    a9e4:	0f b6 0a             	movzbl (%rdx),%ecx
    a9e7:	80 f9 02             	cmp    $0x2,%cl
    a9ea:	0f 84 40 0b 00 00    	je     b530 <fwp_main_thread+0x1e50>
    a9f0:	80 f9 01             	cmp    $0x1,%cl
    a9f3:	75 29                	jne    aa1e <fwp_main_thread+0x133e>
    a9f5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a9f8:	0f b7 c0             	movzwl %ax,%eax
    a9fb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a9fe:	48 0f af c1          	imul   %rcx,%rax
    aa02:	48 c1 e8 20          	shr    $0x20,%rax
    aa06:	48 39 d0             	cmp    %rdx,%rax
    aa09:	73 13                	jae    aa1e <fwp_main_thread+0x133e>
    aa0b:	49 01 c5             	add    %rax,%r13
    aa0e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    aa13:	0f 84 2b 0b 00 00    	je     b544 <fwp_main_thread+0x1e64>
    aa19:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    aa1e:	4c 3b 64 24 48       	cmp    0x48(%rsp),%r12
    aa23:	0f 85 22 8d ff ff    	jne    374b <fwp_main_thread.cold>
    aa29:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    aa30:	00 
    aa31:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    aa36:	48 89 05 9b fa 05 00 	mov    %rax,0x5fa9b(%rip)        # 6a4d8 <fwp_cleanups>
    aa3d:	e8 de c5 ff ff       	call   7020 <fwp_tape_scope_release>
    aa42:	48 8b 03             	mov    (%rbx),%rax
    aa45:	49 89 c5             	mov    %rax,%r13
    aa48:	49 0f ba f5 3f       	btr    $0x3f,%r13
    aa4d:	48 85 c0             	test   %rax,%rax
    aa50:	0f 88 ea 07 00 00    	js     b240 <fwp_main_thread+0x1b60>
    aa56:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    aa5d:	48 89 d8             	mov    %rbx,%rax
    aa60:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    aa67:	48 c1 e2 10          	shl    $0x10,%rdx
    aa6b:	48 39 d0             	cmp    %rdx,%rax
    aa6e:	0f 83 cc 07 00 00    	jae    b240 <fwp_main_thread+0x1b60>
    aa74:	48 89 c2             	mov    %rax,%rdx
    aa77:	48 c1 ea 10          	shr    $0x10,%rdx
    aa7b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aa7f:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    aa86:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aa8a:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    aa8e:	48 85 c9             	test   %rcx,%rcx
    aa91:	0f 84 a9 07 00 00    	je     b240 <fwp_main_thread+0x1b60>
    aa97:	0f b6 32             	movzbl (%rdx),%esi
    aa9a:	40 80 fe 02          	cmp    $0x2,%sil
    aa9e:	0f 84 8c 07 00 00    	je     b230 <fwp_main_thread+0x1b50>
    aaa4:	40 80 fe 01          	cmp    $0x1,%sil
    aaa8:	0f 85 92 07 00 00    	jne    b240 <fwp_main_thread+0x1b60>
    aaae:	8b 72 18             	mov    0x18(%rdx),%esi
    aab1:	0f b7 c0             	movzwl %ax,%eax
    aab4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aab7:	48 0f af c6          	imul   %rsi,%rax
    aabb:	48 c1 e8 20          	shr    $0x20,%rax
    aabf:	48 39 d0             	cmp    %rdx,%rax
    aac2:	0f 83 78 07 00 00    	jae    b240 <fwp_main_thread+0x1b60>
    aac8:	48 01 c1             	add    %rax,%rcx
    aacb:	80 39 01             	cmpb   $0x1,(%rcx)
    aace:	0f 85 6c 07 00 00    	jne    b240 <fwp_main_thread+0x1b60>
    aad4:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    aad9:	48 89 da             	mov    %rbx,%rdx
    aadc:	31 ff                	xor    %edi,%edi
    aade:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    aae3:	48 8d 48 08          	lea    0x8(%rax),%rcx
    aae7:	31 c0                	xor    %eax,%eax
    aae9:	4d 85 ed             	test   %r13,%r13
    aaec:	75 2b                	jne    ab19 <fwp_main_thread+0x1439>
    aaee:	eb 58                	jmp    ab48 <fwp_main_thread+0x1468>
    aaf0:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    aaf4:	0f 88 c4 0e 00 00    	js     b9be <fwp_main_thread+0x22de>
    aafa:	f2 0f 10 05 7e 22 00 	movsd  0x227e(%rip),%xmm0        # cd80 <msg.8+0x40>
    ab01:	00 
    ab02:	f2 0f 59 04 c6       	mulsd  (%rsi,%rax,8),%xmm0
    ab07:	48 83 c0 01          	add    $0x1,%rax
    ab0b:	48 83 c1 08          	add    $0x8,%rcx
    ab0f:	f2 0f 11 41 f8       	movsd  %xmm0,-0x8(%rcx)
    ab14:	49 39 c5             	cmp    %rax,%r13
    ab17:	74 2f                	je     ab48 <fwp_main_thread+0x1468>
    ab19:	48 8d 73 08          	lea    0x8(%rbx),%rsi
    ab1d:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    ab21:	79 cd                	jns    aaf0 <fwp_main_thread+0x1410>
    ab23:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    ab27:	eb c7                	jmp    aaf0 <fwp_main_thread+0x1410>
    ab29:	48 8d 3d 90 a1 ff ff 	lea    -0x5e70(%rip),%rdi        # 4cc0 <fwp_heap_report>
    ab30:	e8 7b 11 00 00       	call   bcb0 <atexit>
    ab35:	e9 ee eb ff ff       	jmp    9728 <fwp_main_thread+0x48>
    ab3a:	e8 91 a2 ff ff       	call   4dd0 <fwp_heap_init>
    ab3f:	e9 d4 eb ff ff       	jmp    9718 <fwp_main_thread+0x38>
    ab44:	0f 1f 40 00          	nopl   0x0(%rax)
    ab48:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    ab4d:	e8 1e d4 ff ff       	call   7f70 <fwp_drop10>
    ab52:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    ab57:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    ab5c:	0f 1f 40 00          	nopl   0x0(%rax)
    ab60:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    ab64:	49 83 c7 01          	add    $0x1,%r15
    ab68:	48 85 db             	test   %rbx,%rbx
    ab6b:	75 f3                	jne    ab60 <fwp_main_thread+0x1480>
    ab6d:	4c 8b 32             	mov    (%rdx),%r14
    ab70:	4d 85 f6             	test   %r14,%r14
    ab73:	0f 88 07 01 00 00    	js     ac80 <fwp_main_thread+0x15a0>
    ab79:	48 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%rcx
    ab80:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    ab85:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    ab8c:	48 c1 e1 10          	shl    $0x10,%rcx
    ab90:	48 39 c8             	cmp    %rcx,%rax
    ab93:	0f 83 e7 00 00 00    	jae    ac80 <fwp_main_thread+0x15a0>
    ab99:	48 89 c1             	mov    %rax,%rcx
    ab9c:	48 c1 e9 10          	shr    $0x10,%rcx
    aba0:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    aba4:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    abab:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    abaf:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    abb3:	48 85 f6             	test   %rsi,%rsi
    abb6:	0f 84 c4 00 00 00    	je     ac80 <fwp_main_thread+0x15a0>
    abbc:	0f b6 39             	movzbl (%rcx),%edi
    abbf:	40 80 ff 02          	cmp    $0x2,%dil
    abc3:	0f 84 a7 00 00 00    	je     ac70 <fwp_main_thread+0x1590>
    abc9:	40 80 ff 01          	cmp    $0x1,%dil
    abcd:	0f 85 ad 00 00 00    	jne    ac80 <fwp_main_thread+0x15a0>
    abd3:	8b 79 18             	mov    0x18(%rcx),%edi
    abd6:	0f b7 c0             	movzwl %ax,%eax
    abd9:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    abdc:	48 0f af c7          	imul   %rdi,%rax
    abe0:	48 c1 e8 20          	shr    $0x20,%rax
    abe4:	48 39 c8             	cmp    %rcx,%rax
    abe7:	0f 83 93 00 00 00    	jae    ac80 <fwp_main_thread+0x15a0>
    abed:	48 01 c6             	add    %rax,%rsi
    abf0:	80 3e 01             	cmpb   $0x1,(%rsi)
    abf3:	0f 85 87 00 00 00    	jne    ac80 <fwp_main_thread+0x15a0>
    abf9:	4d 39 f7             	cmp    %r14,%r15
    abfc:	4d 0f 46 f7          	cmovbe %r15,%r14
    ac00:	4d 85 f6             	test   %r14,%r14
    ac03:	0f 84 b3 0c 00 00    	je     b8bc <fwp_main_thread+0x21dc>
    ac09:	4c 8d 62 08          	lea    0x8(%rdx),%r12
    ac0d:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    ac13:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    ac18:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    ac1d:	4e 8d 04 f5 00 00 00 	lea    0x0(,%r14,8),%r8
    ac24:	00 
    ac25:	31 c0                	xor    %eax,%eax
    ac27:	49 8d 79 08          	lea    0x8(%r9),%rdi
    ac2b:	eb 34                	jmp    ac61 <fwp_main_thread+0x1581>
    ac2d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ac34:	00 
    ac35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ac3c:	00 00 00 00 
    ac40:	f2 0f 10 46 08       	movsd  0x8(%rsi),%xmm0
    ac45:	f2 0f 5c 04 01       	subsd  (%rcx,%rax,1),%xmm0
    ac4a:	f2 41 0f 11 04 04    	movsd  %xmm0,(%r12,%rax,1)
    ac50:	48 83 c0 08          	add    $0x8,%rax
    ac54:	48 8b 76 10          	mov    0x10(%rsi),%rsi
    ac58:	49 39 c0             	cmp    %rax,%r8
    ac5b:	0f 84 b7 00 00 00    	je     ad18 <fwp_main_thread+0x1638>
    ac61:	48 89 f9             	mov    %rdi,%rcx
    ac64:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    ac68:	79 d6                	jns    ac40 <fwp_main_thread+0x1560>
    ac6a:	49 8b 49 10          	mov    0x10(%r9),%rcx
    ac6e:	eb d0                	jmp    ac40 <fwp_main_thread+0x1560>
    ac70:	66 85 c0             	test   %ax,%ax
    ac73:	0f 84 77 ff ff ff    	je     abf0 <fwp_main_thread+0x1510>
    ac79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ac80:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    ac85:	45 31 ed             	xor    %r13d,%r13d
    ac88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ac8f:	00 
    ac90:	48 8b 40 10          	mov    0x10(%rax),%rax
    ac94:	4c 89 e9             	mov    %r13,%rcx
    ac97:	49 83 c5 01          	add    $0x1,%r13
    ac9b:	48 85 c0             	test   %rax,%rax
    ac9e:	75 f0                	jne    ac90 <fwp_main_thread+0x15b0>
    aca0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    aca7:	ff ff 1f 
    acaa:	4c 39 e8             	cmp    %r13,%rax
    acad:	0f 82 23 0d 00 00    	jb     b9d6 <fwp_main_thread+0x22f6>
    acb3:	be 02 00 00 00       	mov    $0x2,%esi
    acb8:	48 8d 3c cd 10 00 00 	lea    0x10(,%rcx,8),%rdi
    acbf:	00 
    acc0:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    acc5:	e8 a6 b2 ff ff       	call   5f70 <fwp_heap_alloc>
    acca:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    accf:	49 89 c4             	mov    %rax,%r12
    acd2:	48 89 c6             	mov    %rax,%rsi
    acd5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    acda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ace0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    ace4:	48 83 c6 08          	add    $0x8,%rsi
    ace8:	48 89 4e f8          	mov    %rcx,-0x8(%rsi)
    acec:	48 8b 40 10          	mov    0x10(%rax),%rax
    acf0:	48 85 c0             	test   %rax,%rax
    acf3:	75 eb                	jne    ace0 <fwp_main_thread+0x1600>
    acf5:	49 0f ba f6 3f       	btr    $0x3f,%r14
    acfa:	4d 39 ee             	cmp    %r13,%r14
    acfd:	4d 0f 47 f5          	cmova  %r13,%r14
    ad01:	4d 85 f6             	test   %r14,%r14
    ad04:	0f 84 e0 0a 00 00    	je     b7ea <fwp_main_thread+0x210a>
    ad0a:	45 31 ed             	xor    %r13d,%r13d
    ad0d:	e9 01 ff ff ff       	jmp    ac13 <fwp_main_thread+0x1533>
    ad12:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ad18:	48 8b bd d8 13 00 00 	mov    0x13d8(%rbp),%rdi
    ad1f:	4c 8b 85 b0 13 00 00 	mov    0x13b0(%rbp),%r8
    ad26:	45 31 ff             	xor    %r15d,%r15d
    ad29:	4c 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%r9
    ad30:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    ad35:	48 c1 e7 10          	shl    $0x10,%rdi
    ad39:	eb 1b                	jmp    ad56 <fwp_main_thread+0x1676>
    ad3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ad40:	49 83 c7 01          	add    $0x1,%r15
    ad44:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    ad48:	4d 39 f7             	cmp    %r14,%r15
    ad4b:	0f 83 ff 03 00 00    	jae    b150 <fwp_main_thread+0x1a70>
    ad51:	48 85 d2             	test   %rdx,%rdx
    ad54:	74 56                	je     adac <fwp_main_thread+0x16cc>
    ad56:	48 89 d0             	mov    %rdx,%rax
    ad59:	4c 29 c0             	sub    %r8,%rax
    ad5c:	48 39 f8             	cmp    %rdi,%rax
    ad5f:	73 4b                	jae    adac <fwp_main_thread+0x16cc>
    ad61:	48 89 c1             	mov    %rax,%rcx
    ad64:	48 c1 e9 10          	shr    $0x10,%rcx
    ad68:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    ad6c:	49 8d 0c c9          	lea    (%r9,%rcx,8),%rcx
    ad70:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    ad74:	48 85 f6             	test   %rsi,%rsi
    ad77:	74 33                	je     adac <fwp_main_thread+0x16cc>
    ad79:	44 0f b6 11          	movzbl (%rcx),%r10d
    ad7d:	41 80 fa 02          	cmp    $0x2,%r10b
    ad81:	0f 84 b1 03 00 00    	je     b138 <fwp_main_thread+0x1a58>
    ad87:	41 80 fa 01          	cmp    $0x1,%r10b
    ad8b:	75 1f                	jne    adac <fwp_main_thread+0x16cc>
    ad8d:	44 8b 51 18          	mov    0x18(%rcx),%r10d
    ad91:	0f b7 c0             	movzwl %ax,%eax
    ad94:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    ad97:	49 0f af c2          	imul   %r10,%rax
    ad9b:	48 c1 e8 20          	shr    $0x20,%rax
    ad9f:	48 39 c8             	cmp    %rcx,%rax
    ada2:	73 08                	jae    adac <fwp_main_thread+0x16cc>
    ada4:	48 01 c6             	add    %rax,%rsi
    ada7:	80 3e 01             	cmpb   $0x1,(%rsi)
    adaa:	74 94                	je     ad40 <fwp_main_thread+0x1660>
    adac:	4d 39 f7             	cmp    %r14,%r15
    adaf:	72 43                	jb     adf4 <fwp_main_thread+0x1714>
    adb1:	e9 9a 03 00 00       	jmp    b150 <fwp_main_thread+0x1a70>
    adb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    adbd:	00 00 00 
    adc0:	40 80 fe 01          	cmp    $0x1,%sil
    adc4:	75 25                	jne    adeb <fwp_main_thread+0x170b>
    adc6:	8b 71 18             	mov    0x18(%rcx),%esi
    adc9:	0f b7 c0             	movzwl %ax,%eax
    adcc:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    adcf:	48 0f af c6          	imul   %rsi,%rax
    add3:	48 c1 e8 20          	shr    $0x20,%rax
    add7:	48 39 c8             	cmp    %rcx,%rax
    adda:	73 0f                	jae    adeb <fwp_main_thread+0x170b>
    addc:	48 01 c2             	add    %rax,%rdx
    addf:	80 3a ff             	cmpb   $0xff,(%rdx)
    ade2:	0f 84 08 05 00 00    	je     b2f0 <fwp_main_thread+0x1c10>
    ade8:	c6 02 01             	movb   $0x1,(%rdx)
    adeb:	4d 39 fe             	cmp    %r15,%r14
    adee:	0f 84 8c 00 00 00    	je     ae80 <fwp_main_thread+0x17a0>
    adf4:	49 83 ee 01          	sub    $0x1,%r14
    adf8:	66 48 0f 6e f3       	movq   %rbx,%xmm6
    adfd:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
    ae02:	bf 01 00 00 00       	mov    $0x1,%edi
    ae07:	f3 43 0f 7e 04 f4    	movq   (%r12,%r14,8),%xmm0
    ae0d:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    ae11:	0f 29 84 24 50 01 00 	movaps %xmm0,0x150(%rsp)
    ae18:	00 
    ae19:	e8 42 b3 ff ff       	call   6160 <fwp_data.part.0.constprop.0>
    ae1e:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ae25:	48 89 c3             	mov    %rax,%rbx
    ae28:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    ae2f:	48 c1 e2 10          	shl    $0x10,%rdx
    ae33:	48 39 d0             	cmp    %rdx,%rax
    ae36:	73 b3                	jae    adeb <fwp_main_thread+0x170b>
    ae38:	48 89 c2             	mov    %rax,%rdx
    ae3b:	48 c1 ea 10          	shr    $0x10,%rdx
    ae3f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ae43:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    ae4a:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    ae4e:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    ae52:	48 85 d2             	test   %rdx,%rdx
    ae55:	74 94                	je     adeb <fwp_main_thread+0x170b>
    ae57:	0f b6 31             	movzbl (%rcx),%esi
    ae5a:	40 80 fe 02          	cmp    $0x2,%sil
    ae5e:	0f 85 5c ff ff ff    	jne    adc0 <fwp_main_thread+0x16e0>
    ae64:	66 85 c0             	test   %ax,%ax
    ae67:	0f 84 72 ff ff ff    	je     addf <fwp_main_thread+0x16ff>
    ae6d:	4d 39 fe             	cmp    %r15,%r14
    ae70:	75 82                	jne    adf4 <fwp_main_thread+0x1714>
    ae72:	0f 1f 00             	nopl   (%rax)
    ae75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ae7c:	00 00 00 00 
    ae80:	4d 85 f6             	test   %r14,%r14
    ae83:	0f 85 c7 02 00 00    	jne    b150 <fwp_main_thread+0x1a70>
    ae89:	45 85 ed             	test   %r13d,%r13d
    ae8c:	4c 0f 45 64 24 28    	cmovne 0x28(%rsp),%r12
    ae92:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    ae97:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    ae9c:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    aea1:	e8 ca ab ff ff       	call   5a70 <fwp_mem_free>
    aea6:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    aeab:	e8 c0 d0 ff ff       	call   7f70 <fwp_drop10>
    aeb0:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    aeb7:	4c 89 f0             	mov    %r14,%rax
    aeba:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    aec1:	48 c1 e2 10          	shl    $0x10,%rdx
    aec5:	48 39 d0             	cmp    %rdx,%rax
    aec8:	73 76                	jae    af40 <fwp_main_thread+0x1860>
    aeca:	48 89 c2             	mov    %rax,%rdx
    aecd:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    aed4:	48 c1 ea 10          	shr    $0x10,%rdx
    aed8:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    aedc:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    aee0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    aee4:	4d 85 e4             	test   %r12,%r12
    aee7:	74 57                	je     af40 <fwp_main_thread+0x1860>
    aee9:	0f b6 0a             	movzbl (%rdx),%ecx
    aeec:	80 f9 02             	cmp    $0x2,%cl
    aeef:	0f 84 eb 05 00 00    	je     b4e0 <fwp_main_thread+0x1e00>
    aef5:	80 f9 01             	cmp    $0x1,%cl
    aef8:	75 46                	jne    af40 <fwp_main_thread+0x1860>
    aefa:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aefd:	0f b7 c0             	movzwl %ax,%eax
    af00:	8b 52 1c             	mov    0x1c(%rdx),%edx
    af03:	48 0f af c1          	imul   %rcx,%rax
    af07:	48 c1 e8 20          	shr    $0x20,%rax
    af0b:	48 39 d0             	cmp    %rdx,%rax
    af0e:	73 30                	jae    af40 <fwp_main_thread+0x1860>
    af10:	49 01 c4             	add    %rax,%r12
    af13:	41 0f b6 04 24       	movzbl (%r12),%eax
    af18:	84 c0                	test   %al,%al
    af1a:	74 24                	je     af40 <fwp_main_thread+0x1860>
    af1c:	3c 01                	cmp    $0x1,%al
    af1e:	0f 84 34 06 00 00    	je     b558 <fwp_main_thread+0x1e78>
    af24:	3c ff                	cmp    $0xff,%al
    af26:	0f 84 1e 09 00 00    	je     b84a <fwp_main_thread+0x216a>
    af2c:	83 e8 01             	sub    $0x1,%eax
    af2f:	41 88 04 24          	mov    %al,(%r12)
    af33:	66 90                	xchg   %ax,%ax
    af35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    af3c:	00 00 00 00 
    af40:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    af45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    af49:	b9 01 00 00 00       	mov    $0x1,%ecx
    af4e:	48 89 de             	mov    %rbx,%rsi
    af51:	48 8d 15 48 4c 00 00 	lea    0x4c48(%rip),%rdx        # fba0 <d0>
    af58:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    af5f:	00 
    af60:	48 c7 84 24 f0 00 00 	movq   $0x0,0xf0(%rsp)
    af67:	00 00 00 00 00 
    af6c:	e8 2f d7 ff ff       	call   86a0 <fwp_write>
    af71:	4c 8b b4 24 e0 00 00 	mov    0xe0(%rsp),%r14
    af78:	00 
    af79:	4c 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%r15
    af80:	00 
    af81:	48 8d 05 e4 10 00 00 	lea    0x10e4(%rip),%rax        # c06c <_IO_stdin_used+0x6c>
    af88:	4d 85 f6             	test   %r14,%r14
    af8b:	4c 0f 44 f0          	cmove  %rax,%r14
    af8f:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    af93:	0f 87 e3 0a 00 00    	ja     ba7c <fwp_main_thread+0x239c>
    af99:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    af9d:	be 01 00 00 00       	mov    $0x1,%esi
    afa2:	e8 c9 af ff ff       	call   5f70 <fwp_heap_alloc>
    afa7:	4c 89 fa             	mov    %r15,%rdx
    afaa:	4c 89 f6             	mov    %r14,%rsi
    afad:	4c 89 38             	mov    %r15,(%rax)
    afb0:	4c 8d 68 08          	lea    0x8(%rax),%r13
    afb4:	49 89 c4             	mov    %rax,%r12
    afb7:	4c 89 ef             	mov    %r13,%rdi
    afba:	e8 c1 85 ff ff       	call   3580 <memcpy@plt>
    afbf:	43 c6 44 3c 08 00    	movb   $0x0,0x8(%r12,%r15,1)
    afc5:	48 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%rdi
    afcc:	00 
    afcd:	e8 de 83 ff ff       	call   33b0 <free@plt>
    afd2:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    afd9:	4c 89 e0             	mov    %r12,%rax
    afdc:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    afe3:	48 c1 e2 10          	shl    $0x10,%rdx
    afe7:	48 39 d0             	cmp    %rdx,%rax
    afea:	73 57                	jae    b043 <fwp_main_thread+0x1963>
    afec:	48 89 c2             	mov    %rax,%rdx
    afef:	48 c1 ea 10          	shr    $0x10,%rdx
    aff3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aff7:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    affe:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b002:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b006:	4d 85 f6             	test   %r14,%r14
    b009:	74 38                	je     b043 <fwp_main_thread+0x1963>
    b00b:	0f b6 0a             	movzbl (%rdx),%ecx
    b00e:	80 f9 02             	cmp    $0x2,%cl
    b011:	0f 84 09 07 00 00    	je     b720 <fwp_main_thread+0x2040>
    b017:	80 f9 01             	cmp    $0x1,%cl
    b01a:	75 27                	jne    b043 <fwp_main_thread+0x1963>
    b01c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b01f:	0f b7 c0             	movzwl %ax,%eax
    b022:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b025:	48 0f af c1          	imul   %rcx,%rax
    b029:	48 c1 e8 20          	shr    $0x20,%rax
    b02d:	48 39 d0             	cmp    %rdx,%rax
    b030:	73 11                	jae    b043 <fwp_main_thread+0x1963>
    b032:	49 01 c6             	add    %rax,%r14
    b035:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b039:	0f 84 f4 06 00 00    	je     b733 <fwp_main_thread+0x2053>
    b03f:	41 c6 06 01          	movb   $0x1,(%r14)
    b043:	48 89 df             	mov    %rbx,%rdi
    b046:	e8 35 cb ff ff       	call   7b80 <fwp_drop0>
    b04b:	49 8b 14 24          	mov    (%r12),%rdx
    b04f:	be 01 00 00 00       	mov    $0x1,%esi
    b054:	4c 89 ef             	mov    %r13,%rdi
    b057:	48 8b 0d 42 f4 05 00 	mov    0x5f442(%rip),%rcx        # 6a4a0 <fwp_prog_out>
    b05e:	e8 fd 85 ff ff       	call   3660 <fwrite@plt>
    b063:	48 8b 35 36 f4 05 00 	mov    0x5f436(%rip),%rsi        # 6a4a0 <fwp_prog_out>
    b06a:	bf 0a 00 00 00       	mov    $0xa,%edi
    b06f:	e8 5c 84 ff ff       	call   34d0 <fputc@plt>
    b074:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b07b:	4c 89 e0             	mov    %r12,%rax
    b07e:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    b085:	48 c1 e2 10          	shl    $0x10,%rdx
    b089:	48 39 d0             	cmp    %rdx,%rax
    b08c:	73 72                	jae    b100 <fwp_main_thread+0x1a20>
    b08e:	48 89 c2             	mov    %rax,%rdx
    b091:	48 c1 ea 10          	shr    $0x10,%rdx
    b095:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b099:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    b0a0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b0a4:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    b0a8:	48 85 db             	test   %rbx,%rbx
    b0ab:	74 53                	je     b100 <fwp_main_thread+0x1a20>
    b0ad:	0f b6 0a             	movzbl (%rdx),%ecx
    b0b0:	80 f9 02             	cmp    $0x2,%cl
    b0b3:	0f 84 47 06 00 00    	je     b700 <fwp_main_thread+0x2020>
    b0b9:	80 f9 01             	cmp    $0x1,%cl
    b0bc:	75 42                	jne    b100 <fwp_main_thread+0x1a20>
    b0be:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b0c1:	0f b7 c0             	movzwl %ax,%eax
    b0c4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b0c7:	48 0f af c1          	imul   %rcx,%rax
    b0cb:	48 c1 e8 20          	shr    $0x20,%rax
    b0cf:	48 39 d0             	cmp    %rdx,%rax
    b0d2:	73 2c                	jae    b100 <fwp_main_thread+0x1a20>
    b0d4:	48 01 c3             	add    %rax,%rbx
    b0d7:	0f b6 03             	movzbl (%rbx),%eax
    b0da:	84 c0                	test   %al,%al
    b0dc:	74 22                	je     b100 <fwp_main_thread+0x1a20>
    b0de:	3c 01                	cmp    $0x1,%al
    b0e0:	0f 84 83 06 00 00    	je     b769 <fwp_main_thread+0x2089>
    b0e6:	3c ff                	cmp    $0xff,%al
    b0e8:	0f 84 e4 07 00 00    	je     b8d2 <fwp_main_thread+0x21f2>
    b0ee:	83 e8 01             	sub    $0x1,%eax
    b0f1:	88 03                	mov    %al,(%rbx)
    b0f3:	66 90                	xchg   %ax,%ax
    b0f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b0fc:	00 00 00 00 
    b100:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    b105:	48 8b 40 10          	mov    0x10(%rax),%rax
    b109:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    b10e:	48 85 c0             	test   %rax,%rax
    b111:	0f 84 ff 06 00 00    	je     b816 <fwp_main_thread+0x2136>
    b117:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b11e:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b125:	48 8b 1d ac f3 05 00 	mov    0x5f3ac(%rip),%rbx        # 6a4d8 <fwp_cleanups>
    b12c:	e9 8d f0 ff ff       	jmp    a1be <fwp_main_thread+0xade>
    b131:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b138:	66 85 c0             	test   %ax,%ax
    b13b:	0f 84 66 fc ff ff    	je     ada7 <fwp_main_thread+0x16c7>
    b141:	4d 39 f7             	cmp    %r14,%r15
    b144:	0f 82 aa fc ff ff    	jb     adf4 <fwp_main_thread+0x1714>
    b14a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b150:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    b155:	4c 89 e0             	mov    %r12,%rax
    b158:	4b 8d 3c fc          	lea    (%r12,%r15,8),%rdi
    b15c:	0f 1f 40 00          	nopl   0x0(%rax)
    b160:	48 8b 10             	mov    (%rax),%rdx
    b163:	48 83 c0 08          	add    $0x8,%rax
    b167:	4c 89 f6             	mov    %r14,%rsi
    b16a:	49 89 56 08          	mov    %rdx,0x8(%r14)
    b16e:	4d 8b 76 10          	mov    0x10(%r14),%r14
    b172:	48 39 f8             	cmp    %rdi,%rax
    b175:	75 e9                	jne    b160 <fwp_main_thread+0x1a80>
    b177:	45 85 ed             	test   %r13d,%r13d
    b17a:	4c 0f 45 64 24 28    	cmovne 0x28(%rsp),%r12
    b180:	48 89 5e 10          	mov    %rbx,0x10(%rsi)
    b184:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    b189:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    b18e:	e9 09 fd ff ff       	jmp    ae9c <fwp_main_thread+0x17bc>
    b193:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b198:	4d 39 f5             	cmp    %r14,%r13
    b19b:	0f 84 ff f1 ff ff    	je     a3a0 <fwp_main_thread+0xcc0>
    b1a1:	4c 8b 3d 68 4f 01 00 	mov    0x14f68(%rip),%r15        # 20110 <fwp_tapes>
    b1a8:	e9 92 f2 ff ff       	jmp    a43f <fwp_main_thread+0xd5f>
    b1ad:	0f 1f 00             	nopl   (%rax)
    b1b0:	48 83 3d f0 4e 01 00 	cmpq   $0x0,0x14ef0(%rip)        # 200a8 <fwp_tape_cached_bytes>
    b1b7:	00 
    b1b8:	0f 84 cc f2 ff ff    	je     a48a <fwp_main_thread+0xdaa>
    b1be:	66 0f 6f 0d fa 4e 01 	movdqa 0x14efa(%rip),%xmm1        # 200c0 <fwp_tape_workspace>
    b1c5:	00 
    b1c6:	48 c7 05 d7 4e 01 00 	movq   $0x0,0x14ed7(%rip)        # 200a8 <fwp_tape_cached_bytes>
    b1cd:	00 00 00 00 
    b1d1:	41 0f 11 4e 20       	movups %xmm1,0x20(%r14)
    b1d6:	48 8b 05 03 4f 01 00 	mov    0x14f03(%rip),%rax        # 200e0 <fwp_tape_workspace+0x20>
    b1dd:	66 0f 6f 0d eb 4e 01 	movdqa 0x14eeb(%rip),%xmm1        # 200d0 <fwp_tape_workspace+0x10>
    b1e4:	00 
    b1e5:	49 89 46 40          	mov    %rax,0x40(%r14)
    b1e9:	48 8b 05 f8 4e 01 00 	mov    0x14ef8(%rip),%rax        # 200e8 <fwp_tape_workspace+0x28>
    b1f0:	41 0f 11 4e 30       	movups %xmm1,0x30(%r14)
    b1f5:	66 0f ef c9          	pxor   %xmm1,%xmm1
    b1f9:	49 89 46 18          	mov    %rax,0x18(%r14)
    b1fd:	48 8b 05 ec 4e 01 00 	mov    0x14eec(%rip),%rax        # 200f0 <fwp_tape_workspace+0x30>
    b204:	0f 29 0d b5 4e 01 00 	movaps %xmm1,0x14eb5(%rip)        # 200c0 <fwp_tape_workspace>
    b20b:	49 89 46 48          	mov    %rax,0x48(%r14)
    b20f:	0f 29 0d ba 4e 01 00 	movaps %xmm1,0x14eba(%rip)        # 200d0 <fwp_tape_workspace+0x10>
    b216:	48 c7 05 cf 4e 01 00 	movq   $0x0,0x14ecf(%rip)        # 200f0 <fwp_tape_workspace+0x30>
    b21d:	00 00 00 00 
    b221:	0f 29 0d b8 4e 01 00 	movaps %xmm1,0x14eb8(%rip)        # 200e0 <fwp_tape_workspace+0x20>
    b228:	e9 5d f2 ff ff       	jmp    a48a <fwp_main_thread+0xdaa>
    b22d:	0f 1f 00             	nopl   (%rax)
    b230:	66 85 c0             	test   %ax,%ax
    b233:	0f 84 92 f8 ff ff    	je     aacb <fwp_main_thread+0x13eb>
    b239:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b240:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    b247:	ff ff 1f 
    b24a:	4c 39 e8             	cmp    %r13,%rax
    b24d:	0f 82 8f 07 00 00    	jb     b9e2 <fwp_main_thread+0x2302>
    b253:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    b25a:	00 
    b25b:	be 01 00 00 00       	mov    $0x1,%esi
    b260:	e8 0b ad ff ff       	call   5f70 <fwp_heap_alloc>
    b265:	4c 89 28             	mov    %r13,(%rax)
    b268:	48 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%rcx
    b26f:	48 89 c2             	mov    %rax,%rdx
    b272:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b277:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    b27e:	48 c1 e1 10          	shl    $0x10,%rcx
    b282:	48 39 c8             	cmp    %rcx,%rax
    b285:	73 59                	jae    b2e0 <fwp_main_thread+0x1c00>
    b287:	48 89 c1             	mov    %rax,%rcx
    b28a:	48 c1 e9 10          	shr    $0x10,%rcx
    b28e:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b292:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    b299:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b29d:	4c 8b 71 20          	mov    0x20(%rcx),%r14
    b2a1:	4d 85 f6             	test   %r14,%r14
    b2a4:	74 3a                	je     b2e0 <fwp_main_thread+0x1c00>
    b2a6:	0f b6 31             	movzbl (%rcx),%esi
    b2a9:	40 80 fe 02          	cmp    $0x2,%sil
    b2ad:	0f 84 45 03 00 00    	je     b5f8 <fwp_main_thread+0x1f18>
    b2b3:	40 80 fe 01          	cmp    $0x1,%sil
    b2b7:	75 27                	jne    b2e0 <fwp_main_thread+0x1c00>
    b2b9:	8b 71 18             	mov    0x18(%rcx),%esi
    b2bc:	0f b7 c0             	movzwl %ax,%eax
    b2bf:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b2c2:	48 0f af c6          	imul   %rsi,%rax
    b2c6:	48 c1 e8 20          	shr    $0x20,%rax
    b2ca:	48 39 c8             	cmp    %rcx,%rax
    b2cd:	73 11                	jae    b2e0 <fwp_main_thread+0x1c00>
    b2cf:	49 01 c6             	add    %rax,%r14
    b2d2:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b2d6:	0f 84 2f 03 00 00    	je     b60b <fwp_main_thread+0x1f2b>
    b2dc:	41 c6 06 01          	movb   $0x1,(%r14)
    b2e0:	48 89 df             	mov    %rbx,%rdi
    b2e3:	e9 f6 f7 ff ff       	jmp    aade <fwp_main_thread+0x13fe>
    b2e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b2ef:	00 
    b2f0:	48 89 d7             	mov    %rdx,%rdi
    b2f3:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    b2f8:	e8 33 a5 ff ff       	call   5830 <fwp_rc_forget_slot>
    b2fd:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    b302:	e9 e1 fa ff ff       	jmp    ade8 <fwp_main_thread+0x1708>
    b307:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b30e:	00 00 
    b310:	4d 85 e4             	test   %r12,%r12
    b313:	0f 85 00 f3 ff ff    	jne    a619 <fwp_main_thread+0xf39>
    b319:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b320:	31 d2                	xor    %edx,%edx
    b322:	e9 bc f3 ff ff       	jmp    a6e3 <fwp_main_thread+0x1003>
    b327:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b32e:	00 00 
    b330:	48 c1 e2 10          	shl    $0x10,%rdx
    b334:	be 02 00 00 00       	mov    $0x2,%esi
    b339:	bf 08 00 00 00       	mov    $0x8,%edi
    b33e:	48 09 d3             	or     %rdx,%rbx
    b341:	e8 2a ac ff ff       	call   5f70 <fwp_heap_alloc>
    b346:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    b34d:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b354:	49 89 c6             	mov    %rax,%r14
    b357:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    b35e:	48 c1 e2 10          	shl    $0x10,%rdx
    b362:	48 39 d0             	cmp    %rdx,%rax
    b365:	73 b9                	jae    b320 <fwp_main_thread+0x1c40>
    b367:	48 89 c2             	mov    %rax,%rdx
    b36a:	48 c1 ea 10          	shr    $0x10,%rdx
    b36e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b372:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    b379:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b37d:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b381:	4d 85 ed             	test   %r13,%r13
    b384:	0f 84 ea f2 ff ff    	je     a674 <fwp_main_thread+0xf94>
    b38a:	0f b6 0a             	movzbl (%rdx),%ecx
    b38d:	45 31 e4             	xor    %r12d,%r12d
    b390:	80 f9 02             	cmp    $0x2,%cl
    b393:	0f 85 4d f2 ff ff    	jne    a5e6 <fwp_main_thread+0xf06>
    b399:	66 85 c0             	test   %ax,%ax
    b39c:	0f 85 72 f2 ff ff    	jne    a614 <fwp_main_thread+0xf34>
    b3a2:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b3a7:	0f 85 62 f2 ff ff    	jne    a60f <fwp_main_thread+0xf2f>
    b3ad:	4c 89 ef             	mov    %r13,%rdi
    b3b0:	e8 7b a4 ff ff       	call   5830 <fwp_rc_forget_slot>
    b3b5:	e9 55 f2 ff ff       	jmp    a60f <fwp_main_thread+0xf2f>
    b3ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b3c0:	48 8d 59 01          	lea    0x1(%rcx),%rbx
    b3c4:	49 39 de             	cmp    %rbx,%r14
    b3c7:	7c 3a                	jl     b403 <fwp_main_thread+0x1d23>
    b3c9:	4d 85 c0             	test   %r8,%r8
    b3cc:	0f 84 1c 06 00 00    	je     b9ee <fwp_main_thread+0x230e>
    b3d2:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
    b3d7:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    b3de:	00 
    b3df:	31 f6                	xor    %esi,%esi
    b3e1:	4c 89 c7             	mov    %r8,%rdi
    b3e4:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
    b3eb:	00 
    b3ec:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
    b3f1:	0f 29 5c 24 70       	movaps %xmm3,0x70(%rsp)
    b3f6:	e9 69 f4 ff ff       	jmp    a864 <fwp_main_thread+0x1184>
    b3fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b400:	4c 89 cb             	mov    %r9,%rbx
    b403:	4d 85 f6             	test   %r14,%r14
    b406:	4c 0f 44 f3          	cmove  %rbx,%r14
    b40a:	eb 29                	jmp    b435 <fwp_main_thread+0x1d55>
    b40c:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b413:	00 00 
    b415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b41c:	00 00 00 00 
    b420:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
    b424:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    b42b:	48 89 d8             	mov    %rbx,%rax
    b42e:	48 0f 4c c2          	cmovl  %rdx,%rax
    b432:	49 89 c6             	mov    %rax,%r14
    b435:	49 39 de             	cmp    %rbx,%r14
    b438:	7c e6                	jl     b420 <fwp_main_thread+0x1d40>
    b43a:	4d 85 c0             	test   %r8,%r8
    b43d:	0f 84 e5 01 00 00    	je     b628 <fwp_main_thread+0x1f48>
    b443:	4c 89 c7             	mov    %r8,%rdi
    b446:	ba 03 00 00 00       	mov    $0x3,%edx
    b44b:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
    b450:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    b457:	00 
    b458:	0f 29 5c 24 70       	movaps %xmm3,0x70(%rsp)
    b45d:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
    b462:	e8 89 9d ff ff       	call   51f0 <ad_raw_realloc>
    b467:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
    b46c:	66 0f 6f 54 24 60    	movdqa 0x60(%rsp),%xmm2
    b472:	48 85 c0             	test   %rax,%rax
    b475:	66 0f 6f 5c 24 70    	movdqa 0x70(%rsp),%xmm3
    b47b:	49 89 c0             	mov    %rax,%r8
    b47e:	0f 84 bc 02 00 00    	je     b740 <fwp_main_thread+0x2060>
    b484:	4c 89 84 24 00 01 00 	mov    %r8,0x100(%rsp)
    b48b:	00 
    b48c:	4c 89 b4 24 10 01 00 	mov    %r14,0x110(%rsp)
    b493:	00 
    b494:	48 85 db             	test   %rbx,%rbx
    b497:	0f 85 e5 02 00 00    	jne    b782 <fwp_main_thread+0x20a2>
    b49d:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    b4a4:	4d 85 e4             	test   %r12,%r12
    b4a7:	0f 88 ea f3 ff ff    	js     a897 <fwp_main_thread+0x11b7>
    b4ad:	44 89 e1             	mov    %r12d,%ecx
    b4b0:	e9 d0 f3 ff ff       	jmp    a885 <fwp_main_thread+0x11a5>
    b4b5:	0f 1f 00             	nopl   (%rax)
    b4b8:	48 8d 3d 41 ba ff ff 	lea    -0x45bf(%rip),%rdi        # 6f00 <fwp_tape_finish>
    b4bf:	e8 ec 07 00 00       	call   bcb0 <atexit>
    b4c4:	85 c0                	test   %eax,%eax
    b4c6:	0f 85 3b 05 00 00    	jne    ba07 <fwp_main_thread+0x2327>
    b4cc:	c7 05 a6 4b 00 00 01 	movl   $0x1,0x4ba6(%rip)        # 1007c <registered_finish.5>
    b4d3:	00 00 00 
    b4d6:	e9 7e ee ff ff       	jmp    a359 <fwp_main_thread+0xc79>
    b4db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b4e0:	66 85 c0             	test   %ax,%ax
    b4e3:	0f 85 57 fa ff ff    	jne    af40 <fwp_main_thread+0x1860>
    b4e9:	e9 25 fa ff ff       	jmp    af13 <fwp_main_thread+0x1833>
    b4ee:	66 90                	xchg   %ax,%ax
    b4f0:	66 85 c0             	test   %ax,%ax
    b4f3:	0f 85 1a ee ff ff    	jne    a313 <fwp_main_thread+0xc33>
    b4f9:	e9 ef ed ff ff       	jmp    a2ed <fwp_main_thread+0xc0d>
    b4fe:	66 90                	xchg   %ax,%ax
    b500:	4d 39 f1             	cmp    %r14,%r9
    b503:	0f 8f f7 fe ff ff    	jg     b400 <fwp_main_thread+0x1d20>
    b509:	4d 85 c0             	test   %r8,%r8
    b50c:	0f 85 64 02 00 00    	jne    b776 <fwp_main_thread+0x2096>
    b512:	4d 85 c9             	test   %r9,%r9
    b515:	0f 85 d3 04 00 00    	jne    b9ee <fwp_main_thread+0x230e>
    b51b:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    b522:	e9 70 f3 ff ff       	jmp    a897 <fwp_main_thread+0x11b7>
    b527:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b52e:	00 00 
    b530:	66 85 c0             	test   %ax,%ax
    b533:	0f 85 e5 f4 ff ff    	jne    aa1e <fwp_main_thread+0x133e>
    b539:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b53e:	0f 85 d5 f4 ff ff    	jne    aa19 <fwp_main_thread+0x1339>
    b544:	4c 89 ef             	mov    %r13,%rdi
    b547:	e8 e4 a2 ff ff       	call   5830 <fwp_rc_forget_slot>
    b54c:	e9 c8 f4 ff ff       	jmp    aa19 <fwp_main_thread+0x1339>
    b551:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b558:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b55f:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b566:	4c 89 f0             	mov    %r14,%rax
    b569:	4d 8b 66 10          	mov    0x10(%r14),%r12
    b56d:	48 29 c8             	sub    %rcx,%rax
    b570:	48 c1 e2 10          	shl    $0x10,%rdx
    b574:	48 39 d0             	cmp    %rdx,%rax
    b577:	73 65                	jae    b5de <fwp_main_thread+0x1efe>
    b579:	48 89 c7             	mov    %rax,%rdi
    b57c:	48 c1 ef 10          	shr    $0x10,%rdi
    b580:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    b584:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b588:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    b58c:	48 85 ff             	test   %rdi,%rdi
    b58f:	74 4d                	je     b5de <fwp_main_thread+0x1efe>
    b591:	44 0f b6 06          	movzbl (%rsi),%r8d
    b595:	41 80 f8 02          	cmp    $0x2,%r8b
    b599:	0f 84 69 02 00 00    	je     b808 <fwp_main_thread+0x2128>
    b59f:	41 80 f8 01          	cmp    $0x1,%r8b
    b5a3:	75 39                	jne    b5de <fwp_main_thread+0x1efe>
    b5a5:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    b5a9:	0f b7 c0             	movzwl %ax,%eax
    b5ac:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b5af:	49 0f af c0          	imul   %r8,%rax
    b5b3:	48 c1 e8 20          	shr    $0x20,%rax
    b5b7:	48 39 f0             	cmp    %rsi,%rax
    b5ba:	73 22                	jae    b5de <fwp_main_thread+0x1efe>
    b5bc:	48 01 c7             	add    %rax,%rdi
    b5bf:	80 3f 01             	cmpb   $0x1,(%rdi)
    b5c2:	75 1a                	jne    b5de <fwp_main_thread+0x1efe>
    b5c4:	4c 89 f7             	mov    %r14,%rdi
    b5c7:	e8 a4 a4 ff ff       	call   5a70 <fwp_mem_free>
    b5cc:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b5d3:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b5da:	48 c1 e2 10          	shl    $0x10,%rdx
    b5de:	4c 89 e0             	mov    %r12,%rax
    b5e1:	48 29 c8             	sub    %rcx,%rax
    b5e4:	48 39 d0             	cmp    %rdx,%rax
    b5e7:	0f 83 53 f9 ff ff    	jae    af40 <fwp_main_thread+0x1860>
    b5ed:	4d 89 e6             	mov    %r12,%r14
    b5f0:	e9 d5 f8 ff ff       	jmp    aeca <fwp_main_thread+0x17ea>
    b5f5:	0f 1f 00             	nopl   (%rax)
    b5f8:	66 85 c0             	test   %ax,%ax
    b5fb:	0f 85 df fc ff ff    	jne    b2e0 <fwp_main_thread+0x1c00>
    b601:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b605:	0f 85 d1 fc ff ff    	jne    b2dc <fwp_main_thread+0x1bfc>
    b60b:	4c 89 f7             	mov    %r14,%rdi
    b60e:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    b613:	e8 18 a2 ff ff       	call   5830 <fwp_rc_forget_slot>
    b618:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    b61d:	e9 ba fc ff ff       	jmp    b2dc <fwp_main_thread+0x1bfc>
    b622:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b628:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    b62f:	ff ff 1f 
    b632:	49 8d 46 ff          	lea    -0x1(%r14),%rax
    b636:	48 39 c2             	cmp    %rax,%rdx
    b639:	0f 82 31 04 00 00    	jb     ba70 <fwp_main_thread+0x2390>
    b63f:	48 8d 05 9a 4b 04 00 	lea    0x44b9a(%rip),%rax        # 501e0 <ad_raw_blocks>
    b646:	45 31 ed             	xor    %r13d,%r13d
    b649:	eb 2a                	jmp    b675 <fwp_main_thread+0x1f95>
    b64b:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b652:	00 00 00 
    b655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b65c:	00 00 00 00 
    b660:	49 83 c5 01          	add    $0x1,%r13
    b664:	48 83 c0 18          	add    $0x18,%rax
    b668:	49 81 fd 00 10 00 00 	cmp    $0x1000,%r13
    b66f:	0f 84 8d 02 00 00    	je     b902 <fwp_main_thread+0x2222>
    b675:	48 83 38 00          	cmpq   $0x0,(%rax)
    b679:	75 e5                	jne    b660 <fwp_main_thread+0x1f80>
    b67b:	be 08 00 00 00       	mov    $0x8,%esi
    b680:	4c 89 f7             	mov    %r14,%rdi
    b683:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
    b688:	0f 29 5c 24 70       	movaps %xmm3,0x70(%rsp)
    b68d:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
    b692:	e8 79 7e ff ff       	call   3510 <calloc@plt>
    b697:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
    b69c:	66 0f 6f 54 24 60    	movdqa 0x60(%rsp),%xmm2
    b6a2:	48 8d 15 37 4b 04 00 	lea    0x44b37(%rip),%rdx        # 501e0 <ad_raw_blocks>
    b6a9:	48 85 c0             	test   %rax,%rax
    b6ac:	66 0f 6f 5c 24 70    	movdqa 0x70(%rsp),%xmm3
    b6b2:	0f 84 88 00 00 00    	je     b740 <fwp_main_thread+0x2060>
    b6b8:	4b 8d 4c 6d 00       	lea    0x0(%r13,%r13,2),%rcx
    b6bd:	48 89 c6             	mov    %rax,%rsi
    b6c0:	4c 89 4c 24 60       	mov    %r9,0x60(%rsp)
    b6c5:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    b6c9:	b9 03 00 00 00       	mov    $0x3,%ecx
    b6ce:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    b6d3:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    b6da:	00 
    b6db:	e8 20 85 ff ff       	call   3c00 <ad_raw_record>
    b6e0:	4c 8b 4c 24 60       	mov    0x60(%rsp),%r9
    b6e5:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
    b6ea:	e9 95 fd ff ff       	jmp    b484 <fwp_main_thread+0x1da4>
    b6ef:	90                   	nop
    b6f0:	66 85 c0             	test   %ax,%ax
    b6f3:	0f 85 61 eb ff ff    	jne    a25a <fwp_main_thread+0xb7a>
    b6f9:	e9 22 eb ff ff       	jmp    a220 <fwp_main_thread+0xb40>
    b6fe:	66 90                	xchg   %ax,%ax
    b700:	66 85 c0             	test   %ax,%ax
    b703:	0f 85 f7 f9 ff ff    	jne    b100 <fwp_main_thread+0x1a20>
    b709:	0f b6 03             	movzbl (%rbx),%eax
    b70c:	84 c0                	test   %al,%al
    b70e:	0f 85 ca f9 ff ff    	jne    b0de <fwp_main_thread+0x19fe>
    b714:	e9 e7 f9 ff ff       	jmp    b100 <fwp_main_thread+0x1a20>
    b719:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b720:	66 85 c0             	test   %ax,%ax
    b723:	0f 85 1a f9 ff ff    	jne    b043 <fwp_main_thread+0x1963>
    b729:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b72d:	0f 85 0c f9 ff ff    	jne    b03f <fwp_main_thread+0x195f>
    b733:	4c 89 f7             	mov    %r14,%rdi
    b736:	e8 f5 a0 ff ff       	call   5830 <fwp_rc_forget_slot>
    b73b:	e9 ff f8 ff ff       	jmp    b03f <fwp_main_thread+0x195f>
    b740:	48 85 db             	test   %rbx,%rbx
    b743:	0f 85 a5 02 00 00    	jne    b9ee <fwp_main_thread+0x230e>
    b749:	45 31 c0             	xor    %r8d,%r8d
    b74c:	e9 4c fd ff ff       	jmp    b49d <fwp_main_thread+0x1dbd>
    b751:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b755:	e9 b1 e1 ff ff       	jmp    990b <fwp_main_thread+0x22b>
    b75a:	be 68 00 00 00       	mov    $0x68,%esi
    b75f:	b9 01 00 00 00       	mov    $0x1,%ecx
    b764:	e9 71 ec ff ff       	jmp    a3da <fwp_main_thread+0xcfa>
    b769:	4c 89 e7             	mov    %r12,%rdi
    b76c:	e8 ff a2 ff ff       	call   5a70 <fwp_mem_free>
    b771:	e9 8a f9 ff ff       	jmp    b100 <fwp_main_thread+0x1a20>
    b776:	4d 85 c9             	test   %r9,%r9
    b779:	0f 84 9c fd ff ff    	je     b51b <fwp_main_thread+0x1e3b>
    b77f:	4c 89 cb             	mov    %r9,%rbx
    b782:	4c 89 c7             	mov    %r8,%rdi
    b785:	31 f6                	xor    %esi,%esi
    b787:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
    b78c:	4c 8d 6b ff          	lea    -0x1(%rbx),%r13
    b790:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    b797:	00 
    b798:	0f 29 5c 24 70       	movaps %xmm3,0x70(%rsp)
    b79d:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
    b7a2:	e8 09 7d ff ff       	call   34b0 <memset@plt>
    b7a7:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
    b7ac:	66 0f 6f 54 24 60    	movdqa 0x60(%rsp),%xmm2
    b7b2:	66 0f 6f 5c 24 70    	movdqa 0x70(%rsp),%xmm3
    b7b8:	49 89 c0             	mov    %rax,%r8
    b7bb:	e9 e4 fc ff ff       	jmp    b4a4 <fwp_main_thread+0x1dc4>
    b7c0:	66 85 c0             	test   %ax,%ax
    b7c3:	0f 85 ce e9 ff ff    	jne    a197 <fwp_main_thread+0xab7>
    b7c9:	e9 ab e9 ff ff       	jmp    a179 <fwp_main_thread+0xa99>
    b7ce:	66 85 c0             	test   %ax,%ax
    b7d1:	0f 85 6a e8 ff ff    	jne    a041 <fwp_main_thread+0x961>
    b7d7:	e9 55 e8 ff ff       	jmp    a031 <fwp_main_thread+0x951>
    b7dc:	66 85 c0             	test   %ax,%ax
    b7df:	0f 85 fb e8 ff ff    	jne    a0e0 <fwp_main_thread+0xa00>
    b7e5:	e9 e6 e8 ff ff       	jmp    a0d0 <fwp_main_thread+0x9f0>
    b7ea:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    b7ef:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    b7f4:	31 db                	xor    %ebx,%ebx
    b7f6:	e9 a1 f6 ff ff       	jmp    ae9c <fwp_main_thread+0x17bc>
    b7fb:	4c 89 ef             	mov    %r13,%rdi
    b7fe:	e8 2d a0 ff ff       	call   5830 <fwp_rc_forget_slot>
    b803:	e9 f9 e6 ff ff       	jmp    9f01 <fwp_main_thread+0x821>
    b808:	66 85 c0             	test   %ax,%ax
    b80b:	0f 85 cd fd ff ff    	jne    b5de <fwp_main_thread+0x1efe>
    b811:	e9 a9 fd ff ff       	jmp    b5bf <fwp_main_thread+0x1edf>
    b816:	4c 8b b4 24 88 00 00 	mov    0x88(%rsp),%r14
    b81d:	00 
    b81e:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    b823:	e8 58 c3 ff ff       	call   7b80 <fwp_drop0>
    b828:	4c 89 f7             	mov    %r14,%rdi
    b82b:	e8 50 c3 ff ff       	call   7b80 <fwp_drop0>
    b830:	48 c7 05 45 48 00 00 	movq   $0x0,0x4845(%rip)        # 10080 <v.6>
    b837:	00 00 00 00 
    b83b:	c7 05 43 48 00 00 01 	movl   $0x1,0x4843(%rip)        # 10088 <st.7>
    b842:	00 00 00 
    b845:	e9 0d e0 ff ff       	jmp    9857 <fwp_main_thread+0x177>
    b84a:	4c 89 e2             	mov    %r12,%rdx
    b84d:	48 c1 ea 11          	shr    $0x11,%rdx
    b851:	4c 31 e2             	xor    %r12,%rdx
    b854:	48 89 d0             	mov    %rdx,%rax
    b857:	48 c1 e8 09          	shr    $0x9,%rax
    b85b:	48 31 c2             	xor    %rax,%rdx
    b85e:	0f b6 d2             	movzbl %dl,%edx
    b861:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b868:	00 
    b869:	48 85 c0             	test   %rax,%rax
    b86c:	75 1b                	jne    b889 <fwp_main_thread+0x21a9>
    b86e:	e9 83 00 00 00       	jmp    b8f6 <fwp_main_thread+0x2216>
    b873:	66 90                	xchg   %ax,%ax
    b875:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b87c:	00 00 00 00 
    b880:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b884:	48 85 c0             	test   %rax,%rax
    b887:	74 6d                	je     b8f6 <fwp_main_thread+0x2216>
    b889:	48 89 c2             	mov    %rax,%rdx
    b88c:	4c 3b 20             	cmp    (%rax),%r12
    b88f:	75 ef                	jne    b880 <fwp_main_thread+0x21a0>
    b891:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b895:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b899:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b89d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b8a4:	0f 85 96 f6 ff ff    	jne    af40 <fwp_main_thread+0x1860>
    b8aa:	4c 89 e7             	mov    %r12,%rdi
    b8ad:	e8 7e 9f ff ff       	call   5830 <fwp_rc_forget_slot>
    b8b2:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b8b7:	e9 84 f6 ff ff       	jmp    af40 <fwp_main_thread+0x1860>
    b8bc:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    b8c1:	31 db                	xor    %ebx,%ebx
    b8c3:	e9 d4 f5 ff ff       	jmp    ae9c <fwp_main_thread+0x17bc>
    b8c8:	e8 43 9e ff ff       	call   5710 <fwp_rc_wide_dup>
    b8cd:	e9 41 ea ff ff       	jmp    a313 <fwp_main_thread+0xc33>
    b8d2:	48 89 d8             	mov    %rbx,%rax
    b8d5:	48 c1 e8 11          	shr    $0x11,%rax
    b8d9:	48 31 d8             	xor    %rbx,%rax
    b8dc:	48 89 c2             	mov    %rax,%rdx
    b8df:	48 c1 ea 09          	shr    $0x9,%rdx
    b8e3:	48 31 d0             	xor    %rdx,%rax
    b8e6:	0f b6 d0             	movzbl %al,%edx
    b8e9:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b8f0:	00 
    b8f1:	48 85 c0             	test   %rax,%rax
    b8f4:	75 53                	jne    b949 <fwp_main_thread+0x2269>
    b8f6:	48 8d 3d f3 10 00 00 	lea    0x10f3(%rip),%rdi        # c9f0 <_IO_stdin_used+0x9f0>
    b8fd:	e8 4e 8b ff ff       	call   4450 <fwp_trap>
    b902:	48 8d 3d 09 08 00 00 	lea    0x809(%rip),%rdi        # c112 <_IO_stdin_used+0x112>
    b909:	e8 f2 86 ff ff       	call   4000 <ad_raw_fail>
    b90e:	e8 fd 9d ff ff       	call   5710 <fwp_rc_wide_dup>
    b913:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b91a:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b921:	48 c1 e2 10          	shl    $0x10,%rdx
    b925:	e9 30 e9 ff ff       	jmp    a25a <fwp_main_thread+0xb7a>
    b92a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b931:	00 00 00 00 
    b935:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b93c:	00 00 00 00 
    b940:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b944:	48 85 c0             	test   %rax,%rax
    b947:	74 ad                	je     b8f6 <fwp_main_thread+0x2216>
    b949:	48 89 c2             	mov    %rax,%rdx
    b94c:	48 39 18             	cmp    %rbx,(%rax)
    b94f:	75 ef                	jne    b940 <fwp_main_thread+0x2260>
    b951:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b955:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b959:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b95d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b964:	0f 85 96 f7 ff ff    	jne    b100 <fwp_main_thread+0x1a20>
    b96a:	48 89 df             	mov    %rbx,%rdi
    b96d:	e8 be 9e ff ff       	call   5830 <fwp_rc_forget_slot>
    b972:	c6 03 fe             	movb   $0xfe,(%rbx)
    b975:	e9 86 f7 ff ff       	jmp    b100 <fwp_main_thread+0x1a20>
    b97a:	48 8d 3d 97 10 00 00 	lea    0x1097(%rip),%rdi        # ca18 <_IO_stdin_used+0xa18>
    b981:	e8 ca 8a ff ff       	call   4450 <fwp_trap>
    b986:	48 8d 3d 35 08 00 00 	lea    0x835(%rip),%rdi        # c1c2 <_IO_stdin_used+0x1c2>
    b98d:	e8 be 8a ff ff       	call   4450 <fwp_trap>
    b992:	4c 89 e7             	mov    %r12,%rdi
    b995:	e8 96 9e ff ff       	call   5830 <fwp_rc_forget_slot>
    b99a:	e9 e5 e7 ff ff       	jmp    a184 <fwp_main_thread+0xaa4>
    b99f:	4c 89 e7             	mov    %r12,%rdi
    b9a2:	e8 89 9e ff ff       	call   5830 <fwp_rc_forget_slot>
    b9a7:	e9 90 e6 ff ff       	jmp    a03c <fwp_main_thread+0x95c>
    b9ac:	4c 89 e7             	mov    %r12,%rdi
    b9af:	e8 7c 9e ff ff       	call   5830 <fwp_rc_forget_slot>
    b9b4:	e9 22 e7 ff ff       	jmp    a0db <fwp_main_thread+0x9fb>
    b9b9:	e8 42 7d ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    b9be:	48 8d 3d 53 11 00 00 	lea    0x1153(%rip),%rdi        # cb18 <_IO_stdin_used+0xb18>
    b9c5:	e8 86 8a ff ff       	call   4450 <fwp_trap>
    b9ca:	48 8d 3d c6 08 00 00 	lea    0x8c6(%rip),%rdi        # c297 <_IO_stdin_used+0x297>
    b9d1:	e8 7a 8a ff ff       	call   4450 <fwp_trap>
    b9d6:	48 8d 3d 0e 08 00 00 	lea    0x80e(%rip),%rdi        # c1eb <_IO_stdin_used+0x1eb>
    b9dd:	e8 6e 8a ff ff       	call   4450 <fwp_trap>
    b9e2:	48 8d 3d e4 08 00 00 	lea    0x8e4(%rip),%rdi        # c2cd <_IO_stdin_used+0x2cd>
    b9e9:	e8 62 8a ff ff       	call   4450 <fwp_trap>
    b9ee:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
    b9f5:	00 
    b9f6:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    b9fb:	48 89 05 d6 ea 05 00 	mov    %rax,0x5ead6(%rip)        # 6a4d8 <fwp_cleanups>
    ba02:	e8 b9 98 ff ff       	call   52c0 <fwp_tape_buffers_release>
    ba07:	48 8b 0d 32 46 00 00 	mov    0x4632(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    ba0e:	ba 13 00 00 00       	mov    $0x13,%edx
    ba13:	be 01 00 00 00       	mov    $0x1,%esi
    ba18:	48 8d 3d e9 05 00 00 	lea    0x5e9(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    ba1f:	e8 3c 7c ff ff       	call   3660 <fwrite@plt>
    ba24:	31 ff                	xor    %edi,%edi
    ba26:	e8 75 7b ff ff       	call   35a0 <fflush@plt>
    ba2b:	bf 66 00 00 00       	mov    $0x66,%edi
    ba30:	e8 4b 7c ff ff       	call   3680 <_Exit@plt>
    ba35:	48 8d 3d 84 10 00 00 	lea    0x1084(%rip),%rdi        # cac0 <_IO_stdin_used+0xac0>
    ba3c:	e8 0f 8a ff ff       	call   4450 <fwp_trap>
    ba41:	e8 0a 7a ff ff       	call   3450 <__stack_chk_fail@plt>
    ba46:	48 8d 3d 9b 10 00 00 	lea    0x109b(%rip),%rdi        # cae8 <_IO_stdin_used+0xae8>
    ba4d:	e8 fe 89 ff ff       	call   4450 <fwp_trap>
    ba52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ba58:	48 8d 3d 51 11 00 00 	lea    0x1151(%rip),%rdi        # cbb0 <_IO_stdin_used+0xbb0>
    ba5f:	e8 ec 89 ff ff       	call   4450 <fwp_trap>
    ba64:	48 8d 3d 11 08 00 00 	lea    0x811(%rip),%rdi        # c27c <_IO_stdin_used+0x27c>
    ba6b:	e8 90 85 ff ff       	call   4000 <ad_raw_fail>
    ba70:	48 8d 3d 3a 08 00 00 	lea    0x83a(%rip),%rdi        # c2b1 <_IO_stdin_used+0x2b1>
    ba77:	e8 84 85 ff ff       	call   4000 <ad_raw_fail>
    ba7c:	48 8d 3d 5a 08 00 00 	lea    0x85a(%rip),%rdi        # c2dd <_IO_stdin_used+0x2dd>
    ba83:	e8 c8 89 ff ff       	call   4450 <fwp_trap>
    ba88:	48 8d 3d d1 0f 00 00 	lea    0xfd1(%rip),%rdi        # ca60 <_IO_stdin_used+0xa60>
    ba8f:	e8 bc 89 ff ff       	call   4450 <fwp_trap>
    ba94:	e9 b2 7c ff ff       	jmp    374b <fwp_main_thread.cold>
    ba99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000baa0 <__divmodti4>:
    baa0:	f3 0f 1e fa          	endbr64
    baa4:	55                   	push   %rbp
    baa5:	49 89 f1             	mov    %rsi,%r9
    baa8:	49 89 d2             	mov    %rdx,%r10
    baab:	48 89 fe             	mov    %rdi,%rsi
    baae:	49 89 cb             	mov    %rcx,%r11
    bab1:	48 89 e5             	mov    %rsp,%rbp
    bab4:	41 57                	push   %r15
    bab6:	41 56                	push   %r14
    bab8:	41 55                	push   %r13
    baba:	41 54                	push   %r12
    babc:	53                   	push   %rbx
    babd:	4c 89 c3             	mov    %r8,%rbx
    bac0:	45 31 c0             	xor    %r8d,%r8d
    bac3:	4d 85 c9             	test   %r9,%r9
    bac6:	79 12                	jns    bada <__divmodti4+0x3a>
    bac8:	31 ff                	xor    %edi,%edi
    baca:	48 f7 de             	neg    %rsi
    bacd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    bad4:	4c 19 cf             	sbb    %r9,%rdi
    bad7:	49 89 f9             	mov    %rdi,%r9
    bada:	4c 89 d8             	mov    %r11,%rax
    badd:	4d 85 db             	test   %r11,%r11
    bae0:	0f 88 1a 01 00 00    	js     bc00 <__divmodti4+0x160>
    bae6:	4c 89 d9             	mov    %r11,%rcx
    bae9:	49 89 f3             	mov    %rsi,%r11
    baec:	75 62                	jne    bb50 <__divmodti4+0xb0>
    baee:	4d 89 c4             	mov    %r8,%r12
    baf1:	4d 39 d1             	cmp    %r10,%r9
    baf4:	0f 83 46 01 00 00    	jae    bc40 <__divmodti4+0x1a0>
    bafa:	4c 89 d8             	mov    %r11,%rax
    bafd:	4c 89 ca             	mov    %r9,%rdx
    bb00:	49 f7 f2             	div    %r10
    bb03:	49 89 c3             	mov    %rax,%r11
    bb06:	31 c0                	xor    %eax,%eax
    bb08:	48 89 d6             	mov    %rdx,%rsi
    bb0b:	31 ff                	xor    %edi,%edi
    bb0d:	4c 89 d9             	mov    %r11,%rcx
    bb10:	48 89 c2             	mov    %rax,%rdx
    bb13:	48 89 c8             	mov    %rcx,%rax
    bb16:	4d 85 e4             	test   %r12,%r12
    bb19:	74 0a                	je     bb25 <__divmodti4+0x85>
    bb1b:	48 f7 d8             	neg    %rax
    bb1e:	48 83 d2 00          	adc    $0x0,%rdx
    bb22:	48 f7 da             	neg    %rdx
    bb25:	4d 85 c0             	test   %r8,%r8
    bb28:	74 0a                	je     bb34 <__divmodti4+0x94>
    bb2a:	48 f7 de             	neg    %rsi
    bb2d:	48 83 d7 00          	adc    $0x0,%rdi
    bb31:	48 f7 df             	neg    %rdi
    bb34:	48 89 33             	mov    %rsi,(%rbx)
    bb37:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    bb3b:	5b                   	pop    %rbx
    bb3c:	41 5c                	pop    %r12
    bb3e:	41 5d                	pop    %r13
    bb40:	41 5e                	pop    %r14
    bb42:	41 5f                	pop    %r15
    bb44:	5d                   	pop    %rbp
    bb45:	c3                   	ret
    bb46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bb4d:	00 00 00 
    bb50:	4d 89 c4             	mov    %r8,%r12
    bb53:	49 39 c1             	cmp    %rax,%r9
    bb56:	0f 82 ce 00 00 00    	jb     bc2a <__divmodti4+0x18a>
    bb5c:	31 ff                	xor    %edi,%edi
    bb5e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    bb63:	48 63 c7             	movslq %edi,%rax
    bb66:	be 40 00 00 00       	mov    $0x40,%esi
    bb6b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    bb70:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    bb75:	48 29 c6             	sub    %rax,%rsi
    bb78:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    bb7d:	48 09 c8             	or     %rcx,%rax
    bb80:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    bb85:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    bb8a:	49 89 c6             	mov    %rax,%r14
    bb8d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    bb91:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    bb96:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    bb9b:	49 09 c1             	or     %rax,%r9
    bb9e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    bba2:	4c 89 c8             	mov    %r9,%rax
    bba5:	49 f7 f6             	div    %r14
    bba8:	48 89 d1             	mov    %rdx,%rcx
    bbab:	49 89 c3             	mov    %rax,%r11
    bbae:	49 89 c1             	mov    %rax,%r9
    bbb1:	49 f7 e2             	mul    %r10
    bbb4:	49 89 c6             	mov    %rax,%r14
    bbb7:	49 89 d2             	mov    %rdx,%r10
    bbba:	48 39 d1             	cmp    %rdx,%rcx
    bbbd:	72 07                	jb     bbc6 <__divmodti4+0x126>
    bbbf:	75 17                	jne    bbd8 <__divmodti4+0x138>
    bbc1:	49 39 c7             	cmp    %rax,%r15
    bbc4:	73 12                	jae    bbd8 <__divmodti4+0x138>
    bbc6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    bbca:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    bbce:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    bbd2:	49 89 d2             	mov    %rdx,%r10
    bbd5:	49 89 c6             	mov    %rax,%r14
    bbd8:	4c 89 f8             	mov    %r15,%rax
    bbdb:	4c 29 f0             	sub    %r14,%rax
    bbde:	4c 19 d1             	sbb    %r10,%rcx
    bbe1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    bbe6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    bbeb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    bbf0:	48 09 c6             	or     %rax,%rsi
    bbf3:	48 89 cf             	mov    %rcx,%rdi
    bbf6:	31 c0                	xor    %eax,%eax
    bbf8:	4c 89 c9             	mov    %r9,%rcx
    bbfb:	e9 10 ff ff ff       	jmp    bb10 <__divmodti4+0x70>
    bc00:	4c 89 d0             	mov    %r10,%rax
    bc03:	4c 89 da             	mov    %r11,%rdx
    bc06:	4d 89 c4             	mov    %r8,%r12
    bc09:	49 89 f3             	mov    %rsi,%r11
    bc0c:	48 f7 d8             	neg    %rax
    bc0f:	49 f7 d4             	not    %r12
    bc12:	48 83 d2 00          	adc    $0x0,%rdx
    bc16:	49 89 c2             	mov    %rax,%r10
    bc19:	48 f7 da             	neg    %rdx
    bc1c:	48 89 d1             	mov    %rdx,%rcx
    bc1f:	0f 84 cc fe ff ff    	je     baf1 <__divmodti4+0x51>
    bc25:	49 39 d1             	cmp    %rdx,%r9
    bc28:	73 46                	jae    bc70 <__divmodti4+0x1d0>
    bc2a:	4c 89 cf             	mov    %r9,%rdi
    bc2d:	31 c0                	xor    %eax,%eax
    bc2f:	31 c9                	xor    %ecx,%ecx
    bc31:	e9 da fe ff ff       	jmp    bb10 <__divmodti4+0x70>
    bc36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bc3d:	00 00 00 
    bc40:	4d 85 d2             	test   %r10,%r10
    bc43:	75 0d                	jne    bc52 <__divmodti4+0x1b2>
    bc45:	b8 01 00 00 00       	mov    $0x1,%eax
    bc4a:	31 d2                	xor    %edx,%edx
    bc4c:	49 f7 f2             	div    %r10
    bc4f:	49 89 c2             	mov    %rax,%r10
    bc52:	4c 89 c8             	mov    %r9,%rax
    bc55:	31 d2                	xor    %edx,%edx
    bc57:	49 f7 f2             	div    %r10
    bc5a:	49 89 c1             	mov    %rax,%r9
    bc5d:	4c 89 d8             	mov    %r11,%rax
    bc60:	49 f7 f2             	div    %r10
    bc63:	49 89 c3             	mov    %rax,%r11
    bc66:	4c 89 c8             	mov    %r9,%rax
    bc69:	e9 9a fe ff ff       	jmp    bb08 <__divmodti4+0x68>
    bc6e:	66 90                	xchg   %ax,%ax
    bc70:	45 31 f6             	xor    %r14d,%r14d
    bc73:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    bc78:	44 89 f7             	mov    %r14d,%edi
    bc7b:	45 85 f6             	test   %r14d,%r14d
    bc7e:	0f 85 df fe ff ff    	jne    bb63 <__divmodti4+0xc3>
    bc84:	4c 39 ca             	cmp    %r9,%rdx
    bc87:	72 17                	jb     bca0 <__divmodti4+0x200>
    bc89:	31 c9                	xor    %ecx,%ecx
    bc8b:	48 39 c6             	cmp    %rax,%rsi
    bc8e:	73 10                	jae    bca0 <__divmodti4+0x200>
    bc90:	4c 89 cf             	mov    %r9,%rdi
    bc93:	31 c0                	xor    %eax,%eax
    bc95:	e9 76 fe ff ff       	jmp    bb10 <__divmodti4+0x70>
    bc9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bca0:	4c 89 de             	mov    %r11,%rsi
    bca3:	b9 01 00 00 00       	mov    $0x1,%ecx
    bca8:	48 29 c6             	sub    %rax,%rsi
    bcab:	49 19 d1             	sbb    %rdx,%r9
    bcae:	eb e0                	jmp    bc90 <__divmodti4+0x1f0>

000000000000bcb0 <atexit>:
    bcb0:	f3 0f 1e fa          	endbr64
    bcb4:	48 8b 15 4d 43 00 00 	mov    0x434d(%rip),%rdx        # 10008 <__dso_handle>
    bcbb:	31 f6                	xor    %esi,%esi
    bcbd:	e9 7e 79 ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000bcc4 <_fini>:
    bcc4:	f3 0f 1e fa          	endbr64
    bcc8:	48 83 ec 08          	sub    $0x8,%rsp
    bccc:	48 83 c4 08          	add    $0x8,%rsp
    bcd0:	c3                   	ret
