
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-history-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 df 00 00 	mov    0xdfd1(%rip),%rax        # 10fe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 dd 00 00    	push   0xddf2(%rip)        # 10e18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 dd 00 00    	jmp    *0xddf4(%rip)        # 10e20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 dc 00 00    	jmp    *0xdc66(%rip)        # 10ff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e da 00 00    	jmp    *0xda8e(%rip)        # 10e28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 da 00 00    	jmp    *0xda86(%rip)        # 10e30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e da 00 00    	jmp    *0xda7e(%rip)        # 10e38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 da 00 00    	jmp    *0xda76(%rip)        # 10e40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e da 00 00    	jmp    *0xda6e(%rip)        # 10e48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 da 00 00    	jmp    *0xda66(%rip)        # 10e50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e da 00 00    	jmp    *0xda5e(%rip)        # 10e58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 da 00 00    	jmp    *0xda56(%rip)        # 10e60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e da 00 00    	jmp    *0xda4e(%rip)        # 10e68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 da 00 00    	jmp    *0xda46(%rip)        # 10e70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e da 00 00    	jmp    *0xda3e(%rip)        # 10e78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 da 00 00    	jmp    *0xda36(%rip)        # 10e80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e da 00 00    	jmp    *0xda2e(%rip)        # 10e88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 da 00 00    	jmp    *0xda26(%rip)        # 10e90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e da 00 00    	jmp    *0xda1e(%rip)        # 10e98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 da 00 00    	jmp    *0xda16(%rip)        # 10ea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e da 00 00    	jmp    *0xda0e(%rip)        # 10ea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 da 00 00    	jmp    *0xda06(%rip)        # 10eb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe d9 00 00    	jmp    *0xd9fe(%rip)        # 10eb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 d9 00 00    	jmp    *0xd9f6(%rip)        # 10ec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee d9 00 00    	jmp    *0xd9ee(%rip)        # 10ec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 d9 00 00    	jmp    *0xd9e6(%rip)        # 10ed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de d9 00 00    	jmp    *0xd9de(%rip)        # 10ed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 d9 00 00    	jmp    *0xd9d6(%rip)        # 10ee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce d9 00 00    	jmp    *0xd9ce(%rip)        # 10ee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 d9 00 00    	jmp    *0xd9c6(%rip)        # 10ef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be d9 00 00    	jmp    *0xd9be(%rip)        # 10ef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 d9 00 00    	jmp    *0xd9b6(%rip)        # 10f00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae d9 00 00    	jmp    *0xd9ae(%rip)        # 10f08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 d9 00 00    	jmp    *0xd9a6(%rip)        # 10f10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e d9 00 00    	jmp    *0xd99e(%rip)        # 10f18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 d9 00 00    	jmp    *0xd996(%rip)        # 10f20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e d9 00 00    	jmp    *0xd98e(%rip)        # 10f28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 d9 00 00    	jmp    *0xd986(%rip)        # 10f30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e d9 00 00    	jmp    *0xd97e(%rip)        # 10f38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 d9 00 00    	jmp    *0xd976(%rip)        # 10f40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e d9 00 00    	jmp    *0xd96e(%rip)        # 10f48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 d9 00 00    	jmp    *0xd966(%rip)        # 10f50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e d9 00 00    	jmp    *0xd95e(%rip)        # 10f58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 d9 00 00    	jmp    *0xd956(%rip)        # 10f60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e d9 00 00    	jmp    *0xd94e(%rip)        # 10f68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 d9 00 00    	jmp    *0xd946(%rip)        # 10f70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e d9 00 00    	jmp    *0xd93e(%rip)        # 10f78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 d9 00 00    	jmp    *0xd936(%rip)        # 10f80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e d9 00 00    	jmp    *0xd92e(%rip)        # 10f88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 d9 00 00    	jmp    *0xd926(%rip)        # 10f90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e d9 00 00    	jmp    *0xd91e(%rip)        # 10f98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 d9 00 00    	jmp    *0xd916(%rip)        # 10fa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e d9 00 00    	jmp    *0xd90e(%rip)        # 10fa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 d9 00 00    	jmp    *0xd906(%rip)        # 10fb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe d8 00 00    	jmp    *0xd8fe(%rip)        # 10fb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 d8 00 00    	jmp    *0xd8f6(%rip)        # 10fc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee d8 00 00    	jmp    *0xd8ee(%rip)        # 10fc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 99 00 00 	lea    0x99b8(%rip),%r9        # d0cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 99 00 00 	lea    0x99b5(%rip),%r8        # d0d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 6b fc ff ff       	call   33c0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 66 fc ff ff       	call   33c0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 bd 00 00 	lea    0xbd01(%rip),%rax        # f480 <fwp_fn_table>
    377f:	48 89 05 12 7d 06 00 	mov    %rax,0x67d12(%rip)        # 6b498 <fwp_fns>
    3786:	48 8b 05 b3 d8 00 00 	mov    0xd8b3(%rip),%rax        # 11040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 0c 7d 06 00 	mov    %rax,0x67d0c(%rip)        # 6b4a0 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e 9b 00 00 	lea    0x9b4e(%rip),%rdi        # d2ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 d8 00 00 	mov    0xd838(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 7f 74 00 00 	lea    0x747f(%rip),%rdx        # ace0 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 d7 00 00 	mov    0xd7a3(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 f8 d7 01 00    	mov    0x1d7f8(%rip),%eax        # 210a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe 99 00 00 	lea    0x99fe(%rip),%rdi        # d2f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 46 a3 00 00 	lea    0xa346(%rip),%rdi        # dc50 <_IO_stdin_used+0xc50>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 00 a3 00 00 	lea    0xa300(%rip),%rdi        # dc28 <_IO_stdin_used+0xc28>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d c4 a2 00 00 	lea    0xa2c4(%rip),%rdi        # dbf8 <_IO_stdin_used+0xbf8>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d 90 a2 00 00 	lea    0xa290(%rip),%rdi        # dbd0 <_IO_stdin_used+0xbd0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b d6 00 00    	call   *0xd65b(%rip)        # 10fd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 d6 00 00 	lea    0xd6a1(%rip),%rdi        # 11028 <__TMC_END__>
    3987:	48 8d 05 9a d6 00 00 	lea    0xd69a(%rip),%rax        # 11028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e d6 00 00 	mov    0xd63e(%rip),%rax        # 10fd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 d6 00 00 	lea    0xd671(%rip),%rdi        # 11028 <__TMC_END__>
    39b7:	48 8d 35 6a d6 00 00 	lea    0xd66a(%rip),%rsi        # 11028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d d6 00 00 	mov    0xd60d(%rip),%rax        # 10fe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d d6 00 00 00 	cmpb   $0x0,0xd66d(%rip)        # 11068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea d5 00 00 	cmpq   $0x0,0xd5ea(%rip)        # 10ff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 d5 00 00 	mov    0xd5f6(%rip),%rdi        # 11008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 d6 00 00 01 	movb   $0x1,0xd645(%rip)        # 11068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 b7 d5 04 00 	lea    0x4d5b7(%rip),%r8        # 511c0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 5b d5 04 00 	lea    0x4d55b(%rip),%rcx        # 51180 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 2f d5 04 00 	lea    0x4d52f(%rip),%rcx        # 51160 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 61 d5 04 00 	lea    0x4d561(%rip),%rcx        # 511a0 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 70 d5 04 	movdqa 0x4d570(%rip),%xmm0        # 511d0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 58 d5 04 	paddq  0x4d558(%rip),%xmm0        # 511c0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 bf d4 04 00 	cmp    %rax,0x4d4bf(%rip)        # 51140 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 b5 d4 04 	movq   %xmm0,0x4d4b5(%rip)        # 51140 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 5e d4 01 00 	add    0x1d45e(%rip),%rdx        # 21110 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 4c d4 01 00 	add    0x1d44c(%rip),%rax        # 21110 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args161>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 99 77 06 00 	mov    0x67799(%rip),%rdi        # 6b4a0 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 24 d3 00 00 	mov    0xd324(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d 11 d3 00 00 	mov    0xd311(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 d1 5a 06 00 	mov    0x65ad1(%rip),%rax        # 69820 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 19 54 06 00 	mov    0x65419(%rip),%rax        # 691e8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 05 54 06 00 	sub    0x65405(%rip),%rax        # 691e0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 1d 9f 00 00 	lea    0x9f1d(%rip),%rsi        # dd30 <msg.4>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 91 00 00 	lea    0x91c5(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d 12 d2 00 00 	mov    0xd212(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 ab 6d 06 00 	mov    0x66dab(%rip),%rax        # 6ac30 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 a4 6d 06 00 	lea    0x66da4(%rip),%r8        # 6ac30 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 85 6d 06 00 	mov    0x66d85(%rip),%rbx        # 6ac18 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 95 6d 06 00 	mov    0x66d95(%rip),%rcx        # 6ac38 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 31 6d 06 00 	mov    0x66d31(%rip),%rdi        # 6ac20 <fwp_heap+0x13e0>
    3eef:	48 29 35 7a 6d 06 00 	sub    %rsi,0x66d7a(%rip)        # 6ac70 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 0a 6d 06 00 	mov    0x66d0a(%rip),%rax        # 6ac10 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d c0 6c 06 00 	add    0x66cc0(%rip),%rdi        # 6abf0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ce 6c 06 00 	mov    0x66cce(%rip),%rsi        # 6ac20 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 dc 6c 06 00 	mov    0x66cdc(%rip),%rax        # 6ac38 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 8b 6c 06 00 	mov    %r12,0x66c8b(%rip)        # 6ac20 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 79 6c 06 00 	mov    %rbp,0x66c79(%rip)        # 6ac18 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 5e 6c 06 00 	cmp    %rdi,0x66c5e(%rip)        # 6ac08 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 55 6c 06 00 	mov    %rdi,0x66c55(%rip)        # 6ac08 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 99 6c 06 00 	sub    %rdi,0x66c99(%rip)        # 6ac70 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 41 6c 06 00 	mov    0x66c41(%rip),%rax        # 6ac28 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 3a 6c 06 00 	lea    0x66c3a(%rip),%r8        # 6ac28 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ef 96 00 00 	lea    0x96ef(%rip),%rdx        # d6f8 <_IO_stdin_used+0x6f8>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 42 d0 00 00 	mov    0xd042(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 9d cf 00 00 	mov    0xcf9d(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 8f 00 00 	lea    0x8f34(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d e9 56 06 00 	cmp    0x656e9(%rip),%rdi        # 69820 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 af 56 06 00 	mov    0x656af(%rip),%rax        # 69800 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 8d 56 06 00 	mov    %rdi,0x6568d(%rip)        # 69800 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 69 56 06 00 	mov    %rdi,0x65669(%rip)        # 69808 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 5f 90 00 00 	lea    0x905f(%rip),%rsi        # d240 <_IO_stdin_used+0x240>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 8e 00 00 	lea    0x8e27(%rip),%rsi        # d01c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 96 cf 04 	movdqa 0x4cf96(%rip),%xmm0        # 511d0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 7e cf 04 	paddq  0x4cf7e(%rip),%xmm0        # 511c0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 a4 ce 01 00 	mov    0x1cea4(%rip),%r8        # 21118 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d be ce 04 00 	mov    0x4cebe(%rip),%rcx        # 51140 <ad_raw_total_peak>
    4282:	48 8b 3d d7 cd 00 00 	mov    0xcdd7(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 b5 94 00 00 	lea    0x94b5(%rip),%rdx        # d748 <_IO_stdin_used+0x748>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d 01 cf 04 00 	lea    0x4cf01(%rip),%r15        # 511a0 <ad_raw_peak>
    429f:	4c 8d 35 ba ce 04 00 	lea    0x4ceba(%rip),%r14        # 51160 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 8d 00 00 	lea    0x8d79(%rip),%rax        # d02b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 c9 00 	movq   0xc956(%rip),%xmm0        # 10c10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d bf ce 04 00 	lea    0x4cebf(%rip),%r13        # 51180 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f 8d 00 00 	lea    0x8d6f(%rip),%rax        # d03c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 c9 00 	movq   0xc936(%rip),%xmm0        # 10c18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 53 cd 00 00 	mov    0xcd53(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c 8d 00 00 	lea    0x8d0c(%rip),%rcx        # d020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 8d 94 00 00 	lea    0x948d(%rip),%rdx        # d7a8 <_IO_stdin_used+0x7a8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 24 cd 00 00 	mov    0xcd24(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 8c 00 00 	lea    0x8cf8(%rip),%rdi        # d045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d c6 cd 01 00 	cmpq   $0x0,0x1cdc6(%rip)        # 21120 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 dd cd 01 00 	mov    0x1cddd(%rip),%r8        # 21140 <ad_raw_checkpoints>
    4363:	4c 8b 0d de cd 01 00 	mov    0x1cdde(%rip),%r9        # 21148 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d cf cd 01 00 	lea    0x1cdcf(%rip),%rbx        # 21140 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 8c 00 00 	lea    0x8cf4(%rip),%rcx        # d06c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 d1 cd 01 00 	mov    0x1cdd1(%rip),%rax        # 21150 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a 8c 00 00 	lea    0x8c9a(%rip),%r12        # d020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d a9 cc 00 00 	mov    0xcca9(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 29 94 00 00 	lea    0x9429(%rip),%rdx        # d7e8 <_IO_stdin_used+0x7e8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 53 cd 01 00 	cmp    0x1cd53(%rip),%rbp        # 21120 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 78 cc 00 00 	mov    0xcc78(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b 8c 00 00 	lea    0x8c5b(%rip),%rdi        # d059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 43 cc 00 00 	mov    0xcc43(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 84 93 00 00 	lea    0x9384(%rip),%rdx        # d7a8 <_IO_stdin_used+0x7a8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 8c 00 00 	lea    0x8c40(%rip),%rcx        # d06c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d da 92 00 00 	lea    0x92da(%rip),%rdi        # d720 <_IO_stdin_used+0x720>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d e8 cb 00 00 	mov    0xcbe8(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df 8b 00 00 	lea    0x8bdf(%rip),%rdx        # d05e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d d0 cb 00 00 	mov    0xcbd0(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d e1 ca 00 00 	mov    0xcae1(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 8a 00 00 	lea    0x8a78(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 8a 00 00 	lea    0x8ac0(%rip),%rdi        # d06d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 8a 00 00 	lea    0x8a48(%rip),%rdi        # d087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d d8 91 00 00 	lea    0x91d8(%rip),%rdi        # d828 <_IO_stdin_used+0x828>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 e0 96 00 	movdqa 0x96e0(%rip),%xmm0        # dd50 <msg.4+0x20>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 ca 6d 06 00 	add    0x66dca(%rip),%rax        # 6b498 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 2c 91 00 00 	lea    0x912c(%rip),%rdi        # d850 <_IO_stdin_used+0x850>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 c5 c9 01 00 	cmp    %rax,0x1c9c5(%rip)        # 21108 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 c0 c9 01 00 	add    0x1c9c0(%rip),%rax        # 21110 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 15 91 00 00 	lea    0x9115(%rip),%rdi        # d880 <_IO_stdin_used+0x880>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 89 00 00 	lea    0x8920(%rip),%r8        # d0a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 87 00 00 	lea    0x8775(%rip),%r8        # d0b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 86 00 00 	lea    0x8612(%rip),%r8        # d0a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea 83 00 00 	lea    0x83ea(%rip),%rdi        # d0b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 9a 85 00 00 	lea    0x859a(%rip),%rsi        # d288 <_IO_stdin_used+0x288>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d a5 5e 06 00 	mov    0x65ea5(%rip),%r9        # 6ac08 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 fe 5e 06 00 	mov    0x65efe(%rip),%r8        # 6ac68 <fwp_heap+0x1428>
    4d6a:	48 8d 15 5f 8b 00 00 	lea    0x8b5f(%rip),%rdx        # d8d0 <_IO_stdin_used+0x8d0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d e6 5e 06 00 	mov    0x65ee6(%rip),%rcx        # 6ac60 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d f4 5e 06 	movsd  0x65ef4(%rip),%xmm1        # 6ac80 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 e4 5e 06 	movsd  0x65ee4(%rip),%xmm0        # 6ac78 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d c5 c2 00 00 	mov    0xc2c5(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 88 8f 00 	movdqa 0x8f88(%rip),%xmm0        # dd60 <msg.4+0x30>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 9f 59 06 00 	lea    0x6599f(%rip),%rax        # 6a780 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 b1 8f 00 	movdqa 0x8fb1(%rip),%xmm2        # dda0 <msg.4+0x70>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 45 59 06 00 	movaps %xmm0,0x65945(%rip)        # 6a740 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 6d 8f 00 	movdqa 0x8f6d(%rip),%xmm0        # dd70 <msg.4+0x40>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 d3 5d 06 00 01 	movl   $0x1,0x65dd3(%rip)        # 6abe4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 33 59 06 00 	movaps %xmm0,0x65933(%rip)        # 6a750 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 5b 8f 00 	movdqa 0x8f5b(%rip),%xmm0        # dd80 <msg.4+0x50>
    4e24:	00 
    4e25:	0f 29 05 34 59 06 00 	movaps %xmm0,0x65934(%rip)        # 6a760 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 5c 8f 00 	movdqa 0x8f5c(%rip),%xmm0        # dd90 <msg.4+0x60>
    4e33:	00 
    4e34:	0f 29 05 35 59 06 00 	movaps %xmm0,0x65935(%rip)        # 6a770 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 b5 49 06 00 	lea    0x649b5(%rip),%r8        # 69840 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 d0 5c 06 00 	mov    %rax,0x65cd0(%rip)        # 6abf8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 ae 5c 06 00 	mov    %r12,0x65cae(%rip)        # 6ac00 <fwp_heap+0x13c0>
    4f52:	48 89 05 97 5c 06 00 	mov    %rax,0x65c97(%rip)        # 6abf0 <fwp_heap+0x13b0>
    4f59:	48 89 1d b0 5c 06 00 	mov    %rbx,0x65cb0(%rip)        # 6ac10 <fwp_heap+0x13d0>
    4f60:	48 89 35 d9 5c 06 00 	mov    %rsi,0x65cd9(%rip)        # 6ac40 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 81 00 00 	lea    0x8174(%rip),%rdi        # d0ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 b8 5c 06 00 	mov    %rax,0x65cb8(%rip)        # 6ac38 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 3c 5c 06 00    	mov    %eax,0x65c3c(%rip)        # 6abe8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 2c 48 06 00 	mov    0x6482c(%rip),%r8        # 69800 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d 5c 47 06 00 	mov    %rbx,0x6475c(%rip)        # 69808 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 48 47 06 00 	mov    %r8,0x64748(%rip)        # 69800 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <ad_raw_free.part.0>:
    50d0:	48 8d 0d 09 c1 04 00 	lea    0x4c109(%rip),%rcx        # 511e0 <ad_raw_blocks>
    50d7:	31 c0                	xor    %eax,%eax
    50d9:	48 89 ca             	mov    %rcx,%rdx
    50dc:	eb 12                	jmp    50f0 <ad_raw_free.part.0+0x20>
    50de:	66 90                	xchg   %ax,%ax
    50e0:	48 83 c0 01          	add    $0x1,%rax
    50e4:	48 83 c2 18          	add    $0x18,%rdx
    50e8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ee:	74 40                	je     5130 <ad_raw_free.part.0+0x60>
    50f0:	48 3b 3a             	cmp    (%rdx),%rdi
    50f3:	75 eb                	jne    50e0 <ad_raw_free.part.0+0x10>
    50f5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50f9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5101:	48 8d 0d b8 c0 04 00 	lea    0x4c0b8(%rip),%rcx        # 511c0 <ad_raw_live>
    5108:	8b 70 10             	mov    0x10(%rax),%esi
    510b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5112:	00 
    5113:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5117:	48 2b 50 08          	sub    0x8(%rax),%rdx
    511b:	0f 11 00             	movups %xmm0,(%rax)
    511e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5122:	e9 89 e2 ff ff       	jmp    33b0 <free@plt>
    5127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    512e:	00 00 
    5130:	48 83 ec 08          	sub    $0x8,%rsp
    5134:	48 8d 3d c2 7f 00 00 	lea    0x7fc2(%rip),%rdi        # d0fd <_IO_stdin_used+0xfd>
    513b:	e8 c0 ee ff ff       	call   4000 <ad_raw_fail>

0000000000005140 <fwp_tape_buffers_dispose>:
    5140:	53                   	push   %rbx
    5141:	48 89 fb             	mov    %rdi,%rbx
    5144:	48 8b 3f             	mov    (%rdi),%rdi
    5147:	48 85 ff             	test   %rdi,%rdi
    514a:	74 05                	je     5151 <fwp_tape_buffers_dispose+0x11>
    514c:	e8 7f ff ff ff       	call   50d0 <ad_raw_free.part.0>
    5151:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5155:	48 85 ff             	test   %rdi,%rdi
    5158:	74 05                	je     515f <fwp_tape_buffers_dispose+0x1f>
    515a:	e8 71 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    515f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5163:	48 85 ff             	test   %rdi,%rdi
    5166:	74 05                	je     516d <fwp_tape_buffers_dispose+0x2d>
    5168:	e8 63 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    516d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5171:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5178:	00 
    5179:	0f 11 03             	movups %xmm0,(%rbx)
    517c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5180:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5184:	5b                   	pop    %rbx
    5185:	c3                   	ret
    5186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    518d:	00 00 00 

0000000000005190 <ad_raw_realloc>:
    5190:	41 55                	push   %r13
    5192:	41 54                	push   %r12
    5194:	55                   	push   %rbp
    5195:	53                   	push   %rbx
    5196:	48 83 ec 08          	sub    $0x8,%rsp
    519a:	48 85 f6             	test   %rsi,%rsi
    519d:	0f 84 a6 00 00 00    	je     5249 <ad_raw_realloc+0xb9>
    51a3:	4c 8d 25 36 c0 04 00 	lea    0x4c036(%rip),%r12        # 511e0 <ad_raw_blocks>
    51aa:	48 89 f5             	mov    %rsi,%rbp
    51ad:	41 89 d5             	mov    %edx,%r13d
    51b0:	31 db                	xor    %ebx,%ebx
    51b2:	4c 89 e0             	mov    %r12,%rax
    51b5:	eb 1a                	jmp    51d1 <ad_raw_realloc+0x41>
    51b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51be:	00 00 
    51c0:	48 83 c3 01          	add    $0x1,%rbx
    51c4:	48 83 c0 18          	add    $0x18,%rax
    51c8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51cf:	74 4f                	je     5220 <ad_raw_realloc+0x90>
    51d1:	48 3b 38             	cmp    (%rax),%rdi
    51d4:	75 ea                	jne    51c0 <ad_raw_realloc+0x30>
    51d6:	48 85 ff             	test   %rdi,%rdi
    51d9:	74 0b                	je     51e6 <ad_raw_realloc+0x56>
    51db:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51df:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51e4:	75 57                	jne    523d <ad_raw_realloc+0xad>
    51e6:	48 89 ee             	mov    %rbp,%rsi
    51e9:	e8 c2 e3 ff ff       	call   35b0 <realloc@plt>
    51ee:	49 89 c2             	mov    %rax,%r10
    51f1:	48 85 c0             	test   %rax,%rax
    51f4:	74 16                	je     520c <ad_raw_realloc+0x7c>
    51f6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51fa:	44 89 e9             	mov    %r13d,%ecx
    51fd:	48 89 ea             	mov    %rbp,%rdx
    5200:	4c 89 d6             	mov    %r10,%rsi
    5203:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5207:	e8 f4 e9 ff ff       	call   3c00 <ad_raw_record>
    520c:	48 83 c4 08          	add    $0x8,%rsp
    5210:	4c 89 d0             	mov    %r10,%rax
    5213:	5b                   	pop    %rbx
    5214:	5d                   	pop    %rbp
    5215:	41 5c                	pop    %r12
    5217:	41 5d                	pop    %r13
    5219:	c3                   	ret
    521a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5220:	48 85 ff             	test   %rdi,%rdi
    5223:	48 8d 05 e8 7e 00 00 	lea    0x7ee8(%rip),%rax        # d112 <_IO_stdin_used+0x112>
    522a:	48 8d 15 cc 7e 00 00 	lea    0x7ecc(%rip),%rdx        # d0fd <_IO_stdin_used+0xfd>
    5231:	48 0f 45 c2          	cmovne %rdx,%rax
    5235:	48 89 c7             	mov    %rax,%rdi
    5238:	e8 c3 ed ff ff       	call   4000 <ad_raw_fail>
    523d:	48 8d 3d 04 7f 00 00 	lea    0x7f04(%rip),%rdi        # d148 <_IO_stdin_used+0x148>
    5244:	e8 b7 ed ff ff       	call   4000 <ad_raw_fail>
    5249:	48 8d 3d dd 7e 00 00 	lea    0x7edd(%rip),%rdi        # d12d <_IO_stdin_used+0x12d>
    5250:	e8 ab ed ff ff       	call   4000 <ad_raw_fail>
    5255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    525c:	00 00 00 00 

0000000000005260 <fwp_tape_buffers_release>:
    5260:	f3 0f 1e fa          	endbr64
    5264:	53                   	push   %rbx
    5265:	48 89 fb             	mov    %rdi,%rbx
    5268:	48 83 ec 10          	sub    $0x10,%rsp
    526c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5270:	48 85 c0             	test   %rax,%rax
    5273:	0f 88 d7 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5279:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    527d:	48 85 d2             	test   %rdx,%rdx
    5280:	0f 88 ca 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5286:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    528c:	0f 87 be 00 00 00    	ja     5350 <fwp_tape_buffers_release+0xf0>
    5292:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5296:	b8 00 00 08 00       	mov    $0x80000,%eax
    529b:	48 c1 e1 03          	shl    $0x3,%rcx
    529f:	48 29 c8             	sub    %rcx,%rax
    52a2:	48 c1 e8 03          	shr    $0x3,%rax
    52a6:	48 39 d0             	cmp    %rdx,%rax
    52a9:	0f 82 a1 00 00 00    	jb     5350 <fwp_tape_buffers_release+0xf0>
    52af:	48 8d 3d aa 7e 00 00 	lea    0x7eaa(%rip),%rdi        # d160 <_IO_stdin_used+0x160>
    52b6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52bb:	48 89 14 24          	mov    %rdx,(%rsp)
    52bf:	e8 cc e0 ff ff       	call   3390 <getenv@plt>
    52c4:	48 8b 14 24          	mov    (%rsp),%rdx
    52c8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 09                	je     52db <fwp_tape_buffers_release+0x7b>
    52d2:	80 38 30             	cmpb   $0x30,(%rax)
    52d5:	0f 84 05 01 00 00    	je     53e0 <fwp_tape_buffers_release+0x180>
    52db:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52df:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52e3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52e9:	77 71                	ja     535c <fwp_tape_buffers_release+0xfc>
    52eb:	48 8d 3d ce bd 01 00 	lea    0x1bdce(%rip),%rdi        # 210c0 <fwp_tape_workspace>
    52f2:	48 89 34 24          	mov    %rsi,(%rsp)
    52f6:	e8 45 fe ff ff       	call   5140 <fwp_tape_buffers_dispose>
    52fb:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52ff:	48 8b 34 24          	mov    (%rsp),%rsi
    5303:	0f 29 05 b6 bd 01 00 	movaps %xmm0,0x1bdb6(%rip)        # 210c0 <fwp_tape_workspace>
    530a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    530f:	48 89 35 92 bd 01 00 	mov    %rsi,0x1bd92(%rip)        # 210a8 <fwp_tape_cached_bytes>
    5316:	0f 29 05 b3 bd 01 00 	movaps %xmm0,0x1bdb3(%rip)        # 210d0 <fwp_tape_workspace+0x10>
    531d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5322:	0f 29 05 b7 bd 01 00 	movaps %xmm0,0x1bdb7(%rip)        # 210e0 <fwp_tape_workspace+0x20>
    5329:	48 8b 43 30          	mov    0x30(%rbx),%rax
    532d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5331:	48 89 05 b8 bd 01 00 	mov    %rax,0x1bdb8(%rip)        # 210f0 <fwp_tape_workspace+0x30>
    5338:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    533f:	00 
    5340:	0f 11 03             	movups %xmm0,(%rbx)
    5343:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5347:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    534b:	eb 1e                	jmp    536b <fwp_tape_buffers_release+0x10b>
    534d:	0f 1f 00             	nopl   (%rax)
    5350:	48 8d 3d 09 7e 00 00 	lea    0x7e09(%rip),%rdi        # d160 <_IO_stdin_used+0x160>
    5357:	e8 34 e0 ff ff       	call   3390 <getenv@plt>
    535c:	48 89 df             	mov    %rbx,%rdi
    535f:	e8 dc fd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    5364:	48 8b 35 3d bd 01 00 	mov    0x1bd3d(%rip),%rsi        # 210a8 <fwp_tape_cached_bytes>
    536b:	48 6b 15 8d bd 01 00 	imul   $0x68,0x1bd8d(%rip),%rdx        # 21100 <fwp_tapes_cap>
    5372:	68 
    5373:	48 3b 15 46 be 04 00 	cmp    0x4be46(%rip),%rdx        # 511c0 <ad_raw_live>
    537a:	75 73                	jne    53ef <fwp_tape_buffers_release+0x18f>
    537c:	48 8b 05 45 be 04 00 	mov    0x4be45(%rip),%rax        # 511c8 <ad_raw_live+0x8>
    5383:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5387:	48 01 d0             	add    %rdx,%rax
    538a:	48 03 05 3f be 04 00 	add    0x4be3f(%rip),%rax        # 511d0 <ad_raw_live+0x10>
    5391:	48 03 05 40 be 04 00 	add    0x4be40(%rip),%rax        # 511d8 <ad_raw_live+0x18>
    5398:	48 39 c8             	cmp    %rcx,%rax
    539b:	72 52                	jb     53ef <fwp_tape_buffers_release+0x18f>
    539d:	48 8b 0d 7c bd 01 00 	mov    0x1bd7c(%rip),%rcx        # 21120 <ad_raw_checkpoint_count>
    53a4:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    53ab:	74 4e                	je     53fb <fwp_tape_buffers_release+0x19b>
    53ad:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    53b1:	48 29 d0             	sub    %rdx,%rax
    53b4:	48 89 3d 65 bd 01 00 	mov    %rdi,0x1bd65(%rip)        # 21120 <ad_raw_checkpoint_count>
    53bb:	48 29 f0             	sub    %rsi,%rax
    53be:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53c2:	48 8d 0d 77 bd 01 00 	lea    0x1bd77(%rip),%rcx        # 21140 <ad_raw_checkpoints>
    53c9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53cd:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53d2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53d7:	48 83 c4 10          	add    $0x10,%rsp
    53db:	5b                   	pop    %rbx
    53dc:	c3                   	ret
    53dd:	0f 1f 00             	nopl   (%rax)
    53e0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53e4:	0f 84 72 ff ff ff    	je     535c <fwp_tape_buffers_release+0xfc>
    53ea:	e9 ec fe ff ff       	jmp    52db <fwp_tape_buffers_release+0x7b>
    53ef:	48 8d 3d 62 85 00 00 	lea    0x8562(%rip),%rdi        # d958 <_IO_stdin_used+0x958>
    53f6:	e8 05 ec ff ff       	call   4000 <ad_raw_fail>
    53fb:	48 8d 3d 6f 7d 00 00 	lea    0x7d6f(%rip),%rdi        # d171 <_IO_stdin_used+0x171>
    5402:	e8 f9 eb ff ff       	call   4000 <ad_raw_fail>
    5407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    540e:	00 00 

0000000000005410 <fwp_poll_events>:
    5410:	53                   	push   %rbx
    5411:	48 83 ec 20          	sub    $0x20,%rsp
    5415:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    541c:	00 00 
    541e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5423:	31 c0                	xor    %eax,%eax
    5425:	e8 96 f1 ff ff       	call   45c0 <fwp_now_ns>
    542a:	48 8b 1d c7 43 06 00 	mov    0x643c7(%rip),%rbx        # 697f8 <fwp_timers>
    5431:	48 85 db             	test   %rbx,%rbx
    5434:	0f 84 e6 00 00 00    	je     5520 <fwp_poll_events+0x110>
    543a:	48 89 c6             	mov    %rax,%rsi
    543d:	48 89 da             	mov    %rbx,%rdx
    5440:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5447:	eb 26                	jmp    546f <fwp_poll_events+0x5f>
    5449:	90                   	nop
    544a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5451:	00 00 00 00 
    5455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    545c:	00 00 00 00 
    5460:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5467:	48 89 c8             	mov    %rcx,%rax
    546a:	48 85 d2             	test   %rdx,%rdx
    546d:	74 31                	je     54a0 <fwp_poll_events+0x90>
    546f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5473:	48 85 c0             	test   %rax,%rax
    5476:	78 e8                	js     5460 <fwp_poll_events+0x50>
    5478:	48 39 c1             	cmp    %rax,%rcx
    547b:	7c e3                	jl     5460 <fwp_poll_events+0x50>
    547d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 1c                	je     54a5 <fwp_poll_events+0x95>
    5489:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    548d:	48 39 c1             	cmp    %rax,%rcx
    5490:	7c ce                	jl     5460 <fwp_poll_events+0x50>
    5492:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5499:	48 85 d2             	test   %rdx,%rdx
    549c:	75 d1                	jne    546f <fwp_poll_events+0x5f>
    549e:	66 90                	xchg   %ax,%ax
    54a0:	48 85 c0             	test   %rax,%rax
    54a3:	78 7b                	js     5520 <fwp_poll_events+0x110>
    54a5:	48 29 f0             	sub    %rsi,%rax
    54a8:	48 89 c1             	mov    %rax,%rcx
    54ab:	48 85 c0             	test   %rax,%rax
    54ae:	0f 8e 9c 00 00 00    	jle    5550 <fwp_poll_events+0x140>
    54b4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    54bb:	de 1b 43 
    54be:	48 f7 ea             	imul   %rdx
    54c1:	48 89 c8             	mov    %rcx,%rax
    54c4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54c8:	48 c1 fa 12          	sar    $0x12,%rdx
    54cc:	48 29 c2             	sub    %rax,%rdx
    54cf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54d6:	48 39 c1             	cmp    %rax,%rcx
    54d9:	0f 95 c0             	setne  %al
    54dc:	0f b6 c0             	movzbl %al,%eax
    54df:	48 01 d0             	add    %rdx,%rax
    54e2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54e8:	0f 8f 32 01 00 00    	jg     5620 <fwp_poll_events+0x210>
    54ee:	48 85 c0             	test   %rax,%rax
    54f1:	74 5d                	je     5550 <fwp_poll_events+0x140>
    54f3:	89 c1                	mov    %eax,%ecx
    54f5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54fc:	48 c1 e9 26          	shr    $0x26,%rcx
    5500:	48 63 d1             	movslq %ecx,%rdx
    5503:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5509:	29 c8                	sub    %ecx,%eax
    550b:	48 98                	cltq
    550d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5514:	e9 11 01 00 00       	jmp    562a <fwp_poll_events+0x21a>
    5519:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5520:	e8 db e7 ff ff       	call   3d00 <fwp_flush>
    5525:	ba 2b 00 00 00       	mov    $0x2b,%edx
    552a:	be 01 00 00 00       	mov    $0x1,%esi
    552f:	48 8b 0d 2a bb 00 00 	mov    0xbb2a(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    5536:	48 8d 3d 4b 84 00 00 	lea    0x844b(%rip),%rdi        # d988 <_IO_stdin_used+0x988>
    553d:	e8 1e e1 ff ff       	call   3660 <fwrite@plt>
    5542:	bf 65 00 00 00       	mov    $0x65,%edi
    5547:	e8 04 e1 ff ff       	call   3650 <exit@plt>
    554c:	0f 1f 40 00          	nopl   0x0(%rax)
    5550:	e8 6b f0 ff ff       	call   45c0 <fwp_now_ns>
    5555:	48 89 c1             	mov    %rax,%rcx
    5558:	66 0f ef c0          	pxor   %xmm0,%xmm0
    555c:	eb 44                	jmp    55a2 <fwp_poll_events+0x192>
    555e:	66 90                	xchg   %ax,%ax
    5560:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5564:	75 33                	jne    5599 <fwp_poll_events+0x189>
    5566:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    556a:	75 2d                	jne    5599 <fwp_poll_events+0x189>
    556c:	48 8b 05 8d 42 06 00 	mov    0x6428d(%rip),%rax        # 69800 <fwp_ready_tail>
    5573:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5577:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    557e:	00 00 00 00 
    5582:	48 85 c0             	test   %rax,%rax
    5585:	0f 84 05 01 00 00    	je     5690 <fwp_poll_events+0x280>
    558b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5592:	48 89 15 67 42 06 00 	mov    %rdx,0x64267(%rip)        # 69800 <fwp_ready_tail>
    5599:	48 85 db             	test   %rbx,%rbx
    559c:	0f 84 be 00 00 00    	je     5660 <fwp_poll_events+0x250>
    55a2:	48 89 da             	mov    %rbx,%rdx
    55a5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    55ac:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    55b0:	7f e7                	jg     5599 <fwp_poll_events+0x189>
    55b2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    55b6:	74 2e                	je     55e6 <fwp_poll_events+0x1d6>
    55b8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    55bf:	48 85 c0             	test   %rax,%rax
    55c2:	0f 84 b8 00 00 00    	je     5680 <fwp_poll_events+0x270>
    55c8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55cf:	48 85 db             	test   %rbx,%rbx
    55d2:	74 07                	je     55db <fwp_poll_events+0x1cb>
    55d4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55db:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55df:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55e6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ea:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ee:	48 85 c0             	test   %rax,%rax
    55f1:	0f 84 69 ff ff ff    	je     5560 <fwp_poll_events+0x150>
    55f7:	48 39 c8             	cmp    %rcx,%rax
    55fa:	0f 8f 60 ff ff ff    	jg     5560 <fwp_poll_events+0x150>
    5600:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5604:	0f 85 56 ff ff ff    	jne    5560 <fwp_poll_events+0x150>
    560a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    560e:	75 89                	jne    5599 <fwp_poll_events+0x189>
    5610:	48 89 d7             	mov    %rdx,%rdi
    5613:	e8 18 eb ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5618:	e9 43 ff ff ff       	jmp    5560 <fwp_poll_events+0x150>
    561d:	0f 1f 00             	nopl   (%rax)
    5620:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5625:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    562a:	48 89 e7             	mov    %rsp,%rdi
    562d:	31 f6                	xor    %esi,%esi
    562f:	48 89 14 24          	mov    %rdx,(%rsp)
    5633:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5638:	e8 53 de ff ff       	call   3490 <nanosleep@plt>
    563d:	48 8b 1d b4 41 06 00 	mov    0x641b4(%rip),%rbx        # 697f8 <fwp_timers>
    5644:	e8 77 ef ff ff       	call   45c0 <fwp_now_ns>
    5649:	48 89 c1             	mov    %rax,%rcx
    564c:	48 85 db             	test   %rbx,%rbx
    564f:	0f 85 03 ff ff ff    	jne    5558 <fwp_poll_events+0x148>
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5665:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    566c:	00 00 
    566e:	75 2c                	jne    569c <fwp_poll_events+0x28c>
    5670:	48 83 c4 20          	add    $0x20,%rsp
    5674:	5b                   	pop    %rbx
    5675:	c3                   	ret
    5676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    567d:	00 00 00 
    5680:	48 89 1d 71 41 06 00 	mov    %rbx,0x64171(%rip)        # 697f8 <fwp_timers>
    5687:	e9 43 ff ff ff       	jmp    55cf <fwp_poll_events+0x1bf>
    568c:	0f 1f 40 00          	nopl   0x0(%rax)
    5690:	48 89 15 71 41 06 00 	mov    %rdx,0x64171(%rip)        # 69808 <fwp_ready_head>
    5697:	e9 f6 fe ff ff       	jmp    5592 <fwp_poll_events+0x182>
    569c:	e8 af dd ff ff       	call   3450 <__stack_chk_fail@plt>
    56a1:	0f 1f 40 00          	nopl   0x0(%rax)
    56a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ac:	00 00 00 00 

00000000000056b0 <fwp_rc_wide_dup>:
    56b0:	48 89 fa             	mov    %rdi,%rdx
    56b3:	48 8d 35 86 41 06 00 	lea    0x64186(%rip),%rsi        # 69840 <fwp_heap>
    56ba:	48 83 ec 18          	sub    $0x18,%rsp
    56be:	48 89 f9             	mov    %rdi,%rcx
    56c1:	48 c1 ea 11          	shr    $0x11,%rdx
    56c5:	48 31 fa             	xor    %rdi,%rdx
    56c8:	48 89 d0             	mov    %rdx,%rax
    56cb:	48 c1 e8 09          	shr    $0x9,%rax
    56cf:	48 31 c2             	xor    %rax,%rdx
    56d2:	0f b6 d2             	movzbl %dl,%edx
    56d5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56dc:	00 
    56dd:	49 8b 00             	mov    (%r8),%rax
    56e0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56e7:	00 00 
    56e9:	75 21                	jne    570c <fwp_rc_wide_dup+0x5c>
    56eb:	e9 98 00 00 00       	jmp    5788 <fwp_rc_wide_dup+0xd8>
    56f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56fc:	00 00 00 00 
    5700:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5704:	48 85 d2             	test   %rdx,%rdx
    5707:	74 2f                	je     5738 <fwp_rc_wide_dup+0x88>
    5709:	48 89 d0             	mov    %rdx,%rax
    570c:	48 3b 08             	cmp    (%rax),%rcx
    570f:	75 ef                	jne    5700 <fwp_rc_wide_dup+0x50>
    5711:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5714:	74 7c                	je     5792 <fwp_rc_wide_dup+0xe2>
    5716:	48 8b 50 08          	mov    0x8(%rax),%rdx
    571a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    571e:	0f 84 91 00 00 00    	je     57b5 <fwp_rc_wide_dup+0x105>
    5724:	48 83 c2 01          	add    $0x1,%rdx
    5728:	48 89 50 08          	mov    %rdx,0x8(%rax)
    572c:	48 83 c4 18          	add    $0x18,%rsp
    5730:	c3                   	ret
    5731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5738:	4c 8d 40 10          	lea    0x10(%rax),%r8
    573c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    573f:	75 68                	jne    57a9 <fwp_rc_wide_dup+0xf9>
    5741:	bf 18 00 00 00       	mov    $0x18,%edi
    5746:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    574b:	4c 89 04 24          	mov    %r8,(%rsp)
    574f:	e8 3c de ff ff       	call   3590 <malloc@plt>
    5754:	4c 8b 04 24          	mov    (%rsp),%r8
    5758:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    575d:	48 85 c0             	test   %rax,%rax
    5760:	74 5f                	je     57c1 <fwp_rc_wide_dup+0x111>
    5762:	48 89 08             	mov    %rcx,(%rax)
    5765:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    576c:	00 
    576d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5774:	00 
    5775:	49 89 00             	mov    %rax,(%r8)
    5778:	c6 01 ff             	movb   $0xff,(%rcx)
    577b:	48 83 05 05 5d 06 00 	addq   $0x1,0x65d05(%rip)        # 6b488 <fwp_heap+0x1c48>
    5782:	01 
    5783:	48 83 c4 18          	add    $0x18,%rsp
    5787:	c3                   	ret
    5788:	80 3f fe             	cmpb   $0xfe,(%rdi)
    578b:	75 13                	jne    57a0 <fwp_rc_wide_dup+0xf0>
    578d:	48 85 c0             	test   %rax,%rax
    5790:	74 af                	je     5741 <fwp_rc_wide_dup+0x91>
    5792:	48 8d 3d 1f 82 00 00 	lea    0x821f(%rip),%rdi        # d9b8 <_IO_stdin_used+0x9b8>
    5799:	e8 b2 ec ff ff       	call   4450 <fwp_trap>
    579e:	66 90                	xchg   %ax,%ax
    57a0:	48 85 c0             	test   %rax,%rax
    57a3:	0f 85 6d ff ff ff    	jne    5716 <fwp_rc_wide_dup+0x66>
    57a9:	48 8d 3d 30 82 00 00 	lea    0x8230(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    57b0:	e8 9b ec ff ff       	call   4450 <fwp_trap>
    57b5:	48 8d 3d d2 79 00 00 	lea    0x79d2(%rip),%rdi        # d18e <_IO_stdin_used+0x18e>
    57bc:	e8 8f ec ff ff       	call   4450 <fwp_trap>
    57c1:	e8 6a e6 ff ff       	call   3e30 <fwp_heap_oom>
    57c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57cd:	00 00 00 

00000000000057d0 <fwp_rc_forget_slot>:
    57d0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57d3:	74 0b                	je     57e0 <fwp_rc_forget_slot+0x10>
    57d5:	c3                   	ret
    57d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57dd:	00 00 00 
    57e0:	48 89 f8             	mov    %rdi,%rax
    57e3:	48 83 ec 08          	sub    $0x8,%rsp
    57e7:	48 89 fa             	mov    %rdi,%rdx
    57ea:	48 c1 e8 11          	shr    $0x11,%rax
    57ee:	48 31 f8             	xor    %rdi,%rax
    57f1:	48 89 c1             	mov    %rax,%rcx
    57f4:	48 c1 e9 09          	shr    $0x9,%rcx
    57f8:	48 31 c8             	xor    %rcx,%rax
    57fb:	48 8d 0d 3e 40 06 00 	lea    0x6403e(%rip),%rcx        # 69840 <fwp_heap>
    5802:	0f b6 c0             	movzbl %al,%eax
    5805:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    580c:	00 
    580d:	48 85 ff             	test   %rdi,%rdi
    5810:	74 3c                	je     584e <fwp_rc_forget_slot+0x7e>
    5812:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5819:	00 
    581a:	48 8b 01             	mov    (%rcx),%rax
    581d:	eb 11                	jmp    5830 <fwp_rc_forget_slot+0x60>
    581f:	90                   	nop
    5820:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5824:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5828:	48 85 ff             	test   %rdi,%rdi
    582b:	74 21                	je     584e <fwp_rc_forget_slot+0x7e>
    582d:	48 89 f8             	mov    %rdi,%rax
    5830:	48 3b 10             	cmp    (%rax),%rdx
    5833:	75 eb                	jne    5820 <fwp_rc_forget_slot+0x50>
    5835:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5839:	48 89 01             	mov    %rax,(%rcx)
    583c:	e8 6f db ff ff       	call   33b0 <free@plt>
    5841:	48 83 2d 3f 5c 06 00 	subq   $0x1,0x65c3f(%rip)        # 6b488 <fwp_heap+0x1c48>
    5848:	01 
    5849:	48 83 c4 08          	add    $0x8,%rsp
    584d:	c3                   	ret
    584e:	48 8d 3d 8b 81 00 00 	lea    0x818b(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    5855:	e8 f6 eb ff ff       	call   4450 <fwp_trap>
    585a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005860 <fwp_rc_prepare_chunk>:
    5860:	48 83 3d 20 5c 06 00 	cmpq   $0x0,0x65c20(%rip)        # 6b488 <fwp_heap+0x1c48>
    5867:	00 
    5868:	41 54                	push   %r12
    586a:	49 89 f4             	mov    %rsi,%r12
    586d:	55                   	push   %rbp
    586e:	48 89 fd             	mov    %rdi,%rbp
    5871:	53                   	push   %rbx
    5872:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5875:	0f 84 7d 00 00 00    	je     58f8 <fwp_rc_prepare_chunk+0x98>
    587b:	31 db                	xor    %ebx,%ebx
    587d:	85 c0                	test   %eax,%eax
    587f:	75 5f                	jne    58e0 <fwp_rc_prepare_chunk+0x80>
    5881:	48 85 f6             	test   %rsi,%rsi
    5884:	74 7c                	je     5902 <fwp_rc_prepare_chunk+0xa2>
    5886:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    588a:	e8 21 db ff ff       	call   33b0 <free@plt>
    588f:	90                   	nop
    5890:	be 01 00 00 00       	mov    $0x1,%esi
    5895:	4c 89 e7             	mov    %r12,%rdi
    5898:	e8 73 dc ff ff       	call   3510 <calloc@plt>
    589d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    58a1:	48 85 c0             	test   %rax,%rax
    58a4:	0f 85 87 00 00 00    	jne    5931 <fwp_rc_prepare_chunk+0xd1>
    58aa:	e8 81 e5 ff ff       	call   3e30 <fwp_heap_oom>
    58af:	90                   	nop
    58b0:	e8 1b ff ff ff       	call   57d0 <fwp_rc_forget_slot>
    58b5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58b8:	48 83 c3 01          	add    $0x1,%rbx
    58bc:	48 39 c3             	cmp    %rax,%rbx
    58bf:	73 37                	jae    58f8 <fwp_rc_prepare_chunk+0x98>
    58c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58c8:	00 00 
    58ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58d1:	00 00 00 00 
    58d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58dc:	00 00 00 00 
    58e0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58e4:	48 01 df             	add    %rbx,%rdi
    58e7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ea:	74 c4                	je     58b0 <fwp_rc_prepare_chunk+0x50>
    58ec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58ef:	48 83 c3 01          	add    $0x1,%rbx
    58f3:	48 39 c3             	cmp    %rax,%rbx
    58f6:	72 e8                	jb     58e0 <fwp_rc_prepare_chunk+0x80>
    58f8:	49 39 c4             	cmp    %rax,%r12
    58fb:	75 13                	jne    5910 <fwp_rc_prepare_chunk+0xb0>
    58fd:	4d 85 e4             	test   %r12,%r12
    5900:	75 46                	jne    5948 <fwp_rc_prepare_chunk+0xe8>
    5902:	5b                   	pop    %rbx
    5903:	5d                   	pop    %rbp
    5904:	41 5c                	pop    %r12
    5906:	c3                   	ret
    5907:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    590e:	00 00 
    5910:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5914:	48 29 05 75 5b 06 00 	sub    %rax,0x65b75(%rip)        # 6b490 <fwp_heap+0x1c50>
    591b:	e8 90 da ff ff       	call   33b0 <free@plt>
    5920:	4d 85 e4             	test   %r12,%r12
    5923:	0f 85 67 ff ff ff    	jne    5890 <fwp_rc_prepare_chunk+0x30>
    5929:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5930:	00 
    5931:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5935:	5b                   	pop    %rbx
    5936:	4c 01 25 53 5b 06 00 	add    %r12,0x65b53(%rip)        # 6b490 <fwp_heap+0x1c50>
    593d:	5d                   	pop    %rbp
    593e:	41 5c                	pop    %r12
    5940:	c3                   	ret
    5941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5948:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    594c:	5b                   	pop    %rbx
    594d:	4c 89 e2             	mov    %r12,%rdx
    5950:	31 f6                	xor    %esi,%esi
    5952:	5d                   	pop    %rbp
    5953:	41 5c                	pop    %r12
    5955:	e9 56 db ff ff       	jmp    34b0 <memset@plt>
    595a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005960 <fwp_heap_refill>:
    5960:	41 56                	push   %r14
    5962:	41 89 d6             	mov    %edx,%r14d
    5965:	41 55                	push   %r13
    5967:	41 89 f5             	mov    %esi,%r13d
    596a:	41 54                	push   %r12
    596c:	49 89 fc             	mov    %rdi,%r12
    596f:	bf 01 00 00 00       	mov    $0x1,%edi
    5974:	55                   	push   %rbp
    5975:	53                   	push   %rbx
    5976:	e8 f5 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    597b:	48 89 c3             	mov    %rax,%rbx
    597e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5982:	48 8b 05 af 52 06 00 	mov    0x652af(%rip),%rax        # 6ac38 <fwp_heap+0x13f8>
    5989:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    598d:	48 8d 05 ac 3e 06 00 	lea    0x63eac(%rip),%rax        # 69840 <fwp_heap>
    5994:	31 d2                	xor    %edx,%edx
    5996:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    599a:	48 89 ef             	mov    %rbp,%rdi
    599d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    59a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    59a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    59ac:	00 
    59ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    59b2:	f7 f1                	div    %ecx
    59b4:	31 d2                	xor    %edx,%edx
    59b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    59ba:	66 0f 6e c8          	movd   %eax,%xmm1
    59be:	89 c6                	mov    %eax,%esi
    59c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59c5:	48 01 c8             	add    %rcx,%rax
    59c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59cc:	48 f7 f1             	div    %rcx
    59cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59d4:	89 45 18             	mov    %eax,0x18(%rbp)
    59d7:	e8 84 fe ff ff       	call   5860 <fwp_rc_prepare_chunk>
    59dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59df:	48 89 d8             	mov    %rbx,%rax
    59e2:	48 c1 e0 10          	shl    $0x10,%rax
    59e6:	48 03 05 03 52 06 00 	add    0x65203(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    59ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59f6:	8b 55 08             	mov    0x8(%rbp),%edx
    59f9:	48 0f af d1          	imul   %rcx,%rdx
    59fd:	48 01 c2             	add    %rax,%rdx
    5a00:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a05:	5b                   	pop    %rbx
    5a06:	5d                   	pop    %rbp
    5a07:	41 5c                	pop    %r12
    5a09:	41 5d                	pop    %r13
    5a0b:	41 5e                	pop    %r14
    5a0d:	c3                   	ret
    5a0e:	66 90                	xchg   %ax,%ax

0000000000005a10 <fwp_mem_free>:
    5a10:	48 85 ff             	test   %rdi,%rdi
    5a13:	0f 84 17 02 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a19:	48 8b 35 d0 51 06 00 	mov    0x651d0(%rip),%rsi        # 6abf0 <fwp_heap+0x13b0>
    5a20:	48 8b 05 f1 51 06 00 	mov    0x651f1(%rip),%rax        # 6ac18 <fwp_heap+0x13d8>
    5a27:	48 89 fa             	mov    %rdi,%rdx
    5a2a:	48 29 f2             	sub    %rsi,%rdx
    5a2d:	48 c1 e0 10          	shl    $0x10,%rax
    5a31:	48 39 c2             	cmp    %rax,%rdx
    5a34:	0f 83 f6 01 00 00    	jae    5c30 <fwp_mem_free+0x220>
    5a3a:	49 89 d1             	mov    %rdx,%r9
    5a3d:	49 c1 e9 10          	shr    $0x10,%r9
    5a41:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a45:	48 c1 e0 03          	shl    $0x3,%rax
    5a49:	49 89 c0             	mov    %rax,%r8
    5a4c:	4c 03 05 e5 51 06 00 	add    0x651e5(%rip),%r8        # 6ac38 <fwp_heap+0x13f8>
    5a53:	0f 84 d7 01 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a59:	48 83 ec 38          	sub    $0x38,%rsp
    5a5d:	48 89 f9             	mov    %rdi,%rcx
    5a60:	41 0f b6 38          	movzbl (%r8),%edi
    5a64:	40 80 ff 01          	cmp    $0x1,%dil
    5a68:	74 16                	je     5a80 <fwp_mem_free+0x70>
    5a6a:	40 80 ff 02          	cmp    $0x2,%dil
    5a6e:	0f 84 94 00 00 00    	je     5b08 <fwp_mem_free+0xf8>
    5a74:	48 83 c4 38          	add    $0x38,%rsp
    5a78:	c3                   	ret
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a84:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a89:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a8e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a92:	4d 85 d2             	test   %r10,%r10
    5a95:	74 1d                	je     5ab4 <fwp_mem_free+0xa4>
    5a97:	0f b7 c1             	movzwl %cx,%eax
    5a9a:	31 d2                	xor    %edx,%edx
    5a9c:	48 f7 f7             	div    %rdi
    5a9f:	49 01 c2             	add    %rax,%r10
    5aa2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5aa6:	0f 84 44 01 00 00    	je     5bf0 <fwp_mem_free+0x1e0>
    5aac:	41 c6 02 00          	movb   $0x0,(%r10)
    5ab0:	41 8b 78 04          	mov    0x4(%r8),%edi
    5ab4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5abb:	49 63 c1             	movslq %r9d,%rax
    5abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ac2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ac6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5acb:	f2 0f 58 05 ad 51 06 	addsd  0x651ad(%rip),%xmm0        # 6ac80 <fwp_heap+0x1440>
    5ad2:	00 
    5ad3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ad7:	48 8d 05 62 3d 06 00 	lea    0x63d62(%rip),%rax        # 69840 <fwp_heap>
    5ade:	48 01 d0             	add    %rdx,%rax
    5ae1:	48 8b 10             	mov    (%rax),%rdx
    5ae4:	48 f7 d2             	not    %rdx
    5ae7:	48 89 11             	mov    %rdx,(%rcx)
    5aea:	48 89 08             	mov    %rcx,(%rax)
    5aed:	48 29 3d 6c 51 06 00 	sub    %rdi,0x6516c(%rip)        # 6ac60 <fwp_heap+0x1420>
    5af4:	f2 0f 11 05 84 51 06 	movsd  %xmm0,0x65184(%rip)        # 6ac80 <fwp_heap+0x1440>
    5afb:	00 
    5afc:	48 83 c4 38          	add    $0x38,%rsp
    5b00:	c3                   	ret
    5b01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b08:	66 31 d2             	xor    %dx,%dx
    5b0b:	48 01 d6             	add    %rdx,%rsi
    5b0e:	48 39 f1             	cmp    %rsi,%rcx
    5b11:	0f 85 5d ff ff ff    	jne    5a74 <fwp_mem_free+0x64>
    5b17:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b1b:	48 29 15 3e 51 06 00 	sub    %rdx,0x6513e(%rip)        # 6ac60 <fwp_heap+0x1420>
    5b22:	48 85 d2             	test   %rdx,%rdx
    5b25:	0f 88 a5 00 00 00    	js     5bd0 <fwp_mem_free+0x1c0>
    5b2b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b2f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b34:	f2 0f 58 05 44 51 06 	addsd  0x65144(%rip),%xmm0        # 6ac80 <fwp_heap+0x1440>
    5b3b:	00 
    5b3c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b40:	f2 0f 11 05 38 51 06 	movsd  %xmm0,0x65138(%rip)        # 6ac80 <fwp_heap+0x1440>
    5b47:	00 
    5b48:	48 85 d2             	test   %rdx,%rdx
    5b4b:	74 0c                	je     5b59 <fwp_mem_free+0x149>
    5b4d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b50:	0f 84 db 00 00 00    	je     5c31 <fwp_mem_free+0x221>
    5b56:	c6 02 00             	movb   $0x0,(%rdx)
    5b59:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b5d:	48 85 c9             	test   %rcx,%rcx
    5b60:	74 3e                	je     5ba0 <fwp_mem_free+0x190>
    5b62:	48 8b 15 cf 50 06 00 	mov    0x650cf(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    5b69:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b6d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b71:	48 01 d0             	add    %rdx,%rax
    5b74:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b78:	48 89 d6             	mov    %rdx,%rsi
    5b7b:	48 29 c6             	sub    %rax,%rsi
    5b7e:	83 e6 08             	and    $0x8,%esi
    5b81:	74 0d                	je     5b90 <fwp_mem_free+0x180>
    5b83:	c6 00 00             	movb   $0x0,(%rax)
    5b86:	48 83 c0 28          	add    $0x28,%rax
    5b8a:	48 39 c2             	cmp    %rax,%rdx
    5b8d:	74 11                	je     5ba0 <fwp_mem_free+0x190>
    5b8f:	90                   	nop
    5b90:	c6 00 00             	movb   $0x0,(%rax)
    5b93:	48 83 c0 50          	add    $0x50,%rax
    5b97:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b9b:	48 39 c2             	cmp    %rax,%rdx
    5b9e:	75 f0                	jne    5b90 <fwp_mem_free+0x180>
    5ba0:	48 01 0d c9 50 06 00 	add    %rcx,0x650c9(%rip)        # 6ac70 <fwp_heap+0x1430>
    5ba7:	4c 3b 0d 82 50 06 00 	cmp    0x65082(%rip),%r9        # 6ac30 <fwp_heap+0x13f0>
    5bae:	73 07                	jae    5bb7 <fwp_mem_free+0x1a7>
    5bb0:	4c 89 0d 79 50 06 00 	mov    %r9,0x65079(%rip)        # 6ac30 <fwp_heap+0x13f0>
    5bb7:	4c 3b 0d 6a 50 06 00 	cmp    0x6506a(%rip),%r9        # 6ac28 <fwp_heap+0x13e8>
    5bbe:	0f 83 b0 fe ff ff    	jae    5a74 <fwp_mem_free+0x64>
    5bc4:	4c 89 0d 5d 50 06 00 	mov    %r9,0x6505d(%rip)        # 6ac28 <fwp_heap+0x13e8>
    5bcb:	e9 a4 fe ff ff       	jmp    5a74 <fwp_mem_free+0x64>
    5bd0:	48 89 d1             	mov    %rdx,%rcx
    5bd3:	83 e2 01             	and    $0x1,%edx
    5bd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bda:	48 d1 e9             	shr    $1,%rcx
    5bdd:	48 09 d1             	or     %rdx,%rcx
    5be0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5be5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5be9:	e9 46 ff ff ff       	jmp    5b34 <fwp_mem_free+0x124>
    5bee:	66 90                	xchg   %ax,%ax
    5bf0:	4c 89 d7             	mov    %r10,%rdi
    5bf3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bf8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bfd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c02:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c06:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c0b:	e8 c0 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c10:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c15:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c1a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c1f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c24:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c29:	e9 7e fe ff ff       	jmp    5aac <fwp_mem_free+0x9c>
    5c2e:	66 90                	xchg   %ax,%ax
    5c30:	c3                   	ret
    5c31:	48 89 d7             	mov    %rdx,%rdi
    5c34:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c39:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c3e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c48:	e8 83 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c4d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c52:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c57:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c5c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c61:	e9 f0 fe ff ff       	jmp    5b56 <fwp_mem_free+0x146>
    5c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c6d:	00 00 00 

0000000000005c70 <fwp_heap_alloc_big>:
    5c70:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c77:	00 00 40 
    5c7a:	41 57                	push   %r15
    5c7c:	41 56                	push   %r14
    5c7e:	41 55                	push   %r13
    5c80:	41 54                	push   %r12
    5c82:	55                   	push   %rbp
    5c83:	53                   	push   %rbx
    5c84:	48 83 ec 08          	sub    $0x8,%rsp
    5c88:	48 39 f8             	cmp    %rdi,%rax
    5c8b:	0f 82 fa 00 00 00    	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5c91:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c98:	49 89 fd             	mov    %rdi,%r13
    5c9b:	41 89 f6             	mov    %esi,%r14d
    5c9e:	48 c1 ed 10          	shr    $0x10,%rbp
    5ca2:	48 89 ef             	mov    %rbp,%rdi
    5ca5:	e8 c6 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5caa:	be 01 00 00 00       	mov    $0x1,%esi
    5caf:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5cb3:	49 89 c4             	mov    %rax,%r12
    5cb6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5cbd:	00 
    5cbe:	48 03 3d 73 4f 06 00 	add    0x64f73(%rip),%rdi        # 6ac38 <fwp_heap+0x13f8>
    5cc5:	c6 07 02             	movb   $0x2,(%rdi)
    5cc8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5ccc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5ccf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cd3:	e8 88 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5cd8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cdc:	76 47                	jbe    5d25 <fwp_heap_alloc_big+0xb5>
    5cde:	4c 01 e5             	add    %r12,%rbp
    5ce1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ce8:	00 
    5ce9:	4c 8d 3d 50 3b 06 00 	lea    0x63b50(%rip),%r15        # 69840 <fwp_heap>
    5cf0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cf5:	49 c1 e6 03          	shl    $0x3,%r14
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d00:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d07:	31 f6                	xor    %esi,%esi
    5d09:	48 01 dd             	add    %rbx,%rbp
    5d0c:	48 83 c3 28          	add    $0x28,%rbx
    5d10:	48 89 ef             	mov    %rbp,%rdi
    5d13:	e8 48 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5d18:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d1c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d20:	49 39 de             	cmp    %rbx,%r14
    5d23:	75 db                	jne    5d00 <fwp_heap_alloc_big+0x90>
    5d25:	49 c1 e4 10          	shl    $0x10,%r12
    5d29:	4c 03 25 c0 4e 06 00 	add    0x64ec0(%rip),%r12        # 6abf0 <fwp_heap+0x13b0>
    5d30:	4c 89 ea             	mov    %r13,%rdx
    5d33:	31 f6                	xor    %esi,%esi
    5d35:	4c 89 e7             	mov    %r12,%rdi
    5d38:	e8 73 d7 ff ff       	call   34b0 <memset@plt>
    5d3d:	4c 89 e8             	mov    %r13,%rax
    5d40:	48 03 05 19 4f 06 00 	add    0x64f19(%rip),%rax        # 6ac60 <fwp_heap+0x1420>
    5d47:	72 42                	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5d49:	48 39 05 18 4f 06 00 	cmp    %rax,0x64f18(%rip)        # 6ac68 <fwp_heap+0x1428>
    5d50:	48 89 05 09 4f 06 00 	mov    %rax,0x64f09(%rip)        # 6ac60 <fwp_heap+0x1420>
    5d57:	73 07                	jae    5d60 <fwp_heap_alloc_big+0xf0>
    5d59:	48 89 05 08 4f 06 00 	mov    %rax,0x64f08(%rip)        # 6ac68 <fwp_heap+0x1428>
    5d60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d64:	4c 89 e0             	mov    %r12,%rax
    5d67:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d6c:	f2 0f 58 05 04 4f 06 	addsd  0x64f04(%rip),%xmm0        # 6ac78 <fwp_heap+0x1438>
    5d73:	00 
    5d74:	f2 0f 11 05 fc 4e 06 	movsd  %xmm0,0x64efc(%rip)        # 6ac78 <fwp_heap+0x1438>
    5d7b:	00 
    5d7c:	48 83 c4 08          	add    $0x8,%rsp
    5d80:	5b                   	pop    %rbx
    5d81:	5d                   	pop    %rbp
    5d82:	41 5c                	pop    %r12
    5d84:	41 5d                	pop    %r13
    5d86:	41 5e                	pop    %r14
    5d88:	41 5f                	pop    %r15
    5d8a:	c3                   	ret
    5d8b:	e8 a0 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005d90 <fwp_heap_alloc_slow>:
    5d90:	53                   	push   %rbx
    5d91:	48 89 f9             	mov    %rdi,%rcx
    5d94:	41 89 f1             	mov    %esi,%r9d
    5d97:	48 83 ec 10          	sub    $0x10,%rsp
    5d9b:	8b 05 43 4e 06 00    	mov    0x64e43(%rip),%eax        # 6abe4 <fwp_heap+0x13a4>
    5da1:	85 c0                	test   %eax,%eax
    5da3:	0f 84 c7 00 00 00    	je     5e70 <fwp_heap_alloc_slow+0xe0>
    5da9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5db0:	0f 87 dd 00 00 00    	ja     5e93 <fwp_heap_alloc_slow+0x103>
    5db6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5dba:	48 8d 3d 7f 3a 06 00 	lea    0x63a7f(%rip),%rdi        # 69840 <fwp_heap>
    5dc1:	49 63 f1             	movslq %r9d,%rsi
    5dc4:	48 c1 e8 04          	shr    $0x4,%rax
    5dc8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5dcf:	00 00 
    5dd1:	41 0f b6 c2          	movzbl %r10b,%eax
    5dd5:	4c 89 d2             	mov    %r10,%rdx
    5dd8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5ddc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5de3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dee:	48 01 f8             	add    %rdi,%rax
    5df1:	4c 8b 00             	mov    (%rax),%r8
    5df4:	4d 85 c0             	test   %r8,%r8
    5df7:	0f 84 ab 00 00 00    	je     5ea8 <fwp_heap_alloc_slow+0x118>
    5dfd:	49 8b 10             	mov    (%r8),%rdx
    5e00:	48 f7 d2             	not    %rdx
    5e03:	48 89 10             	mov    %rdx,(%rax)
    5e06:	41 83 f9 01          	cmp    $0x1,%r9d
    5e0a:	4c 89 c7             	mov    %r8,%rdi
    5e0d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e11:	31 f6                	xor    %esi,%esi
    5e13:	48 89 ca             	mov    %rcx,%rdx
    5e16:	e8 95 d6 ff ff       	call   34b0 <memset@plt>
    5e1b:	49 89 c0             	mov    %rax,%r8
    5e1e:	48 89 d8             	mov    %rbx,%rax
    5e21:	48 03 05 38 4e 06 00 	add    0x64e38(%rip),%rax        # 6ac60 <fwp_heap+0x1420>
    5e28:	0f 82 d9 00 00 00    	jb     5f07 <fwp_heap_alloc_slow+0x177>
    5e2e:	48 39 05 33 4e 06 00 	cmp    %rax,0x64e33(%rip)        # 6ac68 <fwp_heap+0x1428>
    5e35:	48 89 05 24 4e 06 00 	mov    %rax,0x64e24(%rip)        # 6ac60 <fwp_heap+0x1420>
    5e3c:	73 07                	jae    5e45 <fwp_heap_alloc_slow+0xb5>
    5e3e:	48 89 05 23 4e 06 00 	mov    %rax,0x64e23(%rip)        # 6ac68 <fwp_heap+0x1428>
    5e45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e49:	4c 89 c0             	mov    %r8,%rax
    5e4c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e51:	f2 0f 58 05 1f 4e 06 	addsd  0x64e1f(%rip),%xmm0        # 6ac78 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 17 4e 06 	movsd  %xmm0,0x64e17(%rip)        # 6ac78 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	48 83 c4 10          	add    $0x10,%rsp
    5e65:	5b                   	pop    %rbx
    5e66:	c3                   	ret
    5e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e6e:	00 00 
    5e70:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e74:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e78:	e8 53 ef ff ff       	call   4dd0 <fwp_heap_init>
    5e7d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e81:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e86:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e8d:	0f 86 23 ff ff ff    	jbe    5db6 <fwp_heap_alloc_slow+0x26>
    5e93:	48 83 c4 10          	add    $0x10,%rsp
    5e97:	44 89 ce             	mov    %r9d,%esi
    5e9a:	48 89 cf             	mov    %rcx,%rdi
    5e9d:	5b                   	pop    %rbx
    5e9e:	e9 cd fd ff ff       	jmp    5c70 <fwp_heap_alloc_big>
    5ea3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ea8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5eac:	4d 85 c0             	test   %r8,%r8
    5eaf:	74 1f                	je     5ed0 <fwp_heap_alloc_slow+0x140>
    5eb1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5eb5:	4d 29 c3             	sub    %r8,%r11
    5eb8:	49 39 db             	cmp    %rbx,%r11
    5ebb:	72 13                	jb     5ed0 <fwp_heap_alloc_slow+0x140>
    5ebd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ec1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ec5:	e9 3c ff ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ed0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5ed7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5edb:	44 89 ca             	mov    %r9d,%edx
    5ede:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ee3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ee7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5eeb:	44 89 d6             	mov    %r10d,%esi
    5eee:	48 01 c7             	add    %rax,%rdi
    5ef1:	e8 6a fa ff ff       	call   5960 <fwp_heap_refill>
    5ef6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5efb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5eff:	49 89 c0             	mov    %rax,%r8
    5f02:	e9 ff fe ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5f07:	e8 24 df ff ff       	call   3e30 <fwp_heap_oom>
    5f0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f10 <fwp_heap_alloc>:
    5f10:	53                   	push   %rbx
    5f11:	48 89 fa             	mov    %rdi,%rdx
    5f14:	48 83 ec 10          	sub    $0x10,%rsp
    5f18:	8b 1d ea 55 06 00    	mov    0x655ea(%rip),%ebx        # 6b508 <iteration_active>
    5f1e:	8b 05 c0 4c 06 00    	mov    0x64cc0(%rip),%eax        # 6abe4 <fwp_heap+0x13a4>
    5f24:	85 db                	test   %ebx,%ebx
    5f26:	0f 85 04 01 00 00    	jne    6030 <fwp_heap_alloc+0x120>
    5f2c:	85 c0                	test   %eax,%eax
    5f2e:	0f 84 ac 01 00 00    	je     60e0 <fwp_heap_alloc+0x1d0>
    5f34:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f3b:	0f 87 9f 01 00 00    	ja     60e0 <fwp_heap_alloc+0x1d0>
    5f41:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f45:	48 8d 05 f4 38 06 00 	lea    0x638f4(%rip),%rax        # 69840 <fwp_heap>
    5f4c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f50:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f57:	00 
    5f58:	48 63 ce             	movslq %esi,%rcx
    5f5b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f62:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f69:	00 
    5f6a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f6e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f72:	48 01 c8             	add    %rcx,%rax
    5f75:	48 8b 08             	mov    (%rax),%rcx
    5f78:	48 85 c9             	test   %rcx,%rcx
    5f7b:	0f 84 ff 00 00 00    	je     6080 <fwp_heap_alloc+0x170>
    5f81:	48 8b 39             	mov    (%rcx),%rdi
    5f84:	48 f7 d7             	not    %rdi
    5f87:	48 89 38             	mov    %rdi,(%rax)
    5f8a:	83 fe 01             	cmp    $0x1,%esi
    5f8d:	48 89 cf             	mov    %rcx,%rdi
    5f90:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f95:	49 0f 45 d0          	cmovne %r8,%rdx
    5f99:	31 f6                	xor    %esi,%esi
    5f9b:	e8 10 d5 ff ff       	call   34b0 <memset@plt>
    5fa0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5fa5:	48 89 c1             	mov    %rax,%rcx
    5fa8:	4c 89 c0             	mov    %r8,%rax
    5fab:	48 03 05 ae 4c 06 00 	add    0x64cae(%rip),%rax        # 6ac60 <fwp_heap+0x1420>
    5fb2:	0f 82 35 01 00 00    	jb     60ed <fwp_heap_alloc+0x1dd>
    5fb8:	48 39 05 a9 4c 06 00 	cmp    %rax,0x64ca9(%rip)        # 6ac68 <fwp_heap+0x1428>
    5fbf:	48 89 05 9a 4c 06 00 	mov    %rax,0x64c9a(%rip)        # 6ac60 <fwp_heap+0x1420>
    5fc6:	73 07                	jae    5fcf <fwp_heap_alloc+0xbf>
    5fc8:	48 89 05 99 4c 06 00 	mov    %rax,0x64c99(%rip)        # 6ac68 <fwp_heap+0x1428>
    5fcf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fd3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fd8:	f2 0f 58 05 98 4c 06 	addsd  0x64c98(%rip),%xmm0        # 6ac78 <fwp_heap+0x1438>
    5fdf:	00 
    5fe0:	f2 0f 11 05 90 4c 06 	movsd  %xmm0,0x64c90(%rip)        # 6ac78 <fwp_heap+0x1438>
    5fe7:	00 
    5fe8:	85 db                	test   %ebx,%ebx
    5fea:	74 33                	je     601f <fwp_heap_alloc+0x10f>
    5fec:	48 8b 05 6d 4c 06 00 	mov    0x64c6d(%rip),%rax        # 6ac60 <fwp_heap+0x1420>
    5ff3:	48 85 c0             	test   %rax,%rax
    5ff6:	0f 88 ac 00 00 00    	js     60a8 <fwp_heap_alloc+0x198>
    5ffc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6000:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6005:	f2 0f 5c 05 db 54 06 	subsd  0x654db(%rip),%xmm0        # 6b4e8 <iteration_start_charge>
    600c:	00 
    600d:	66 0f 2f 05 cb 54 06 	comisd 0x654cb(%rip),%xmm0        # 6b4e0 <iteration_peak>
    6014:	00 
    6015:	76 08                	jbe    601f <fwp_heap_alloc+0x10f>
    6017:	f2 0f 11 05 c1 54 06 	movsd  %xmm0,0x654c1(%rip)        # 6b4e0 <iteration_peak>
    601e:	00 
    601f:	48 83 c4 10          	add    $0x10,%rsp
    6023:	48 89 c8             	mov    %rcx,%rax
    6026:	5b                   	pop    %rbx
    6027:	c3                   	ret
    6028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    602f:	00 
    6030:	85 f6                	test   %esi,%esi
    6032:	74 34                	je     6068 <fwp_heap_alloc+0x158>
    6034:	48 83 05 c4 54 06 00 	addq   $0x1,0x654c4(%rip)        # 6b500 <iteration_requests>
    603b:	01 
    603c:	48 01 3d b5 54 06 00 	add    %rdi,0x654b5(%rip)        # 6b4f8 <iteration_bytes>
    6043:	85 c0                	test   %eax,%eax
    6045:	74 0d                	je     6054 <fwp_heap_alloc+0x144>
    6047:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    604e:	0f 86 ed fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6054:	48 89 d7             	mov    %rdx,%rdi
    6057:	e8 34 fd ff ff       	call   5d90 <fwp_heap_alloc_slow>
    605c:	48 89 c1             	mov    %rax,%rcx
    605f:	eb 8b                	jmp    5fec <fwp_heap_alloc+0xdc>
    6061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6068:	85 c0                	test   %eax,%eax
    606a:	74 0d                	je     6079 <fwp_heap_alloc+0x169>
    606c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6073:	0f 86 c8 fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6079:	31 f6                	xor    %esi,%esi
    607b:	eb d7                	jmp    6054 <fwp_heap_alloc+0x144>
    607d:	0f 1f 00             	nopl   (%rax)
    6080:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6084:	48 85 c9             	test   %rcx,%rcx
    6087:	74 0c                	je     6095 <fwp_heap_alloc+0x185>
    6089:	48 8b 78 10          	mov    0x10(%rax),%rdi
    608d:	48 29 cf             	sub    %rcx,%rdi
    6090:	4c 39 c7             	cmp    %r8,%rdi
    6093:	73 3b                	jae    60d0 <fwp_heap_alloc+0x1c0>
    6095:	48 89 d7             	mov    %rdx,%rdi
    6098:	e8 f3 fc ff ff       	call   5d90 <fwp_heap_alloc_slow>
    609d:	48 89 c1             	mov    %rax,%rcx
    60a0:	e9 43 ff ff ff       	jmp    5fe8 <fwp_heap_alloc+0xd8>
    60a5:	0f 1f 00             	nopl   (%rax)
    60a8:	48 89 c2             	mov    %rax,%rdx
    60ab:	83 e0 01             	and    $0x1,%eax
    60ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60b2:	48 d1 ea             	shr    $1,%rdx
    60b5:	48 09 c2             	or     %rax,%rdx
    60b8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    60bd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60c1:	e9 3f ff ff ff       	jmp    6005 <fwp_heap_alloc+0xf5>
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60d4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60d8:	e9 ad fe ff ff       	jmp    5f8a <fwp_heap_alloc+0x7a>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 83 c4 10          	add    $0x10,%rsp
    60e4:	48 89 d7             	mov    %rdx,%rdi
    60e7:	5b                   	pop    %rbx
    60e8:	e9 a3 fc ff ff       	jmp    5d90 <fwp_heap_alloc_slow>
    60ed:	e8 3e dd ff ff       	call   3e30 <fwp_heap_oom>
    60f2:	0f 1f 00             	nopl   (%rax)
    60f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60fc:	00 00 00 00 

0000000000006100 <fwp_apply>:
    6100:	55                   	push   %rbp
    6101:	48 89 f9             	mov    %rdi,%rcx
    6104:	48 89 e5             	mov    %rsp,%rbp
    6107:	41 57                	push   %r15
    6109:	41 56                	push   %r14
    610b:	41 55                	push   %r13
    610d:	41 89 f5             	mov    %esi,%r13d
    6110:	41 54                	push   %r12
    6112:	53                   	push   %rbx
    6113:	48 83 ec 28          	sub    $0x28,%rsp
    6117:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    611e:	00 00 
    6120:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    6124:	49 89 d6             	mov    %rdx,%r14
    6127:	44 8b 09             	mov    (%rcx),%r9d
    612a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    612e:	49 89 e0             	mov    %rsp,%r8
    6131:	49 c1 e1 05          	shl    $0x5,%r9
    6135:	4c 03 0d 5c 53 06 00 	add    0x6535c(%rip),%r9        # 6b498 <fwp_fns>
    613c:	41 8b 19             	mov    (%r9),%ebx
    613f:	45 85 e4             	test   %r12d,%r12d
    6142:	75 2c                	jne    6170 <fwp_apply+0x70>
    6144:	41 39 dd             	cmp    %ebx,%r13d
    6147:	72 27                	jb     6170 <fwp_apply+0x70>
    6149:	85 db                	test   %ebx,%ebx
    614b:	0f 84 b7 01 00 00    	je     6308 <fwp_apply+0x208>
    6151:	4c 89 f7             	mov    %r14,%rdi
    6154:	41 ff 51 08          	call   *0x8(%r9)
    6158:	48 89 c1             	mov    %rax,%rcx
    615b:	41 39 dd             	cmp    %ebx,%r13d
    615e:	0f 84 7c 01 00 00    	je     62e0 <fwp_apply+0x1e0>
    6164:	89 d8                	mov    %ebx,%eax
    6166:	41 29 dd             	sub    %ebx,%r13d
    6169:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    616d:	eb b8                	jmp    6127 <fwp_apply+0x27>
    616f:	90                   	nop
    6170:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    6175:	41 39 df             	cmp    %ebx,%r15d
    6178:	0f 82 dc 00 00 00    	jb     625a <fwp_apply+0x15a>
    617e:	41 89 df             	mov    %ebx,%r15d
    6181:	b8 01 00 00 00       	mov    $0x1,%eax
    6186:	48 89 e2             	mov    %rsp,%rdx
    6189:	45 29 e7             	sub    %r12d,%r15d
    618c:	85 db                	test   %ebx,%ebx
    618e:	0f 45 c3             	cmovne %ebx,%eax
    6191:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    6198:	00 
    6199:	48 c1 e8 04          	shr    $0x4,%rax
    619d:	48 c1 e0 04          	shl    $0x4,%rax
    61a1:	48 89 c6             	mov    %rax,%rsi
    61a4:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    61ab:	48 29 f2             	sub    %rsi,%rdx
    61ae:	48 39 d4             	cmp    %rdx,%rsp
    61b1:	74 15                	je     61c8 <fwp_apply+0xc8>
    61b3:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    61ba:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    61c1:	00 00 
    61c3:	48 39 d4             	cmp    %rdx,%rsp
    61c6:	75 eb                	jne    61b3 <fwp_apply+0xb3>
    61c8:	25 ff 0f 00 00       	and    $0xfff,%eax
    61cd:	48 29 c4             	sub    %rax,%rsp
    61d0:	48 85 c0             	test   %rax,%rax
    61d3:	0f 85 59 01 00 00    	jne    6332 <fwp_apply+0x232>
    61d9:	45 89 e2             	mov    %r12d,%r10d
    61dc:	48 89 e6             	mov    %rsp,%rsi
    61df:	48 89 e7             	mov    %rsp,%rdi
    61e2:	31 c0                	xor    %eax,%eax
    61e4:	49 c1 e2 03          	shl    $0x3,%r10
    61e8:	45 85 e4             	test   %r12d,%r12d
    61eb:	74 25                	je     6212 <fwp_apply+0x112>
    61ed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    61f4:	00 
    61f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    61fc:	00 00 00 00 
    6200:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    6205:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    6209:	48 83 c0 08          	add    $0x8,%rax
    620d:	4c 39 d0             	cmp    %r10,%rax
    6210:	75 ee                	jne    6200 <fwp_apply+0x100>
    6212:	45 85 ff             	test   %r15d,%r15d
    6215:	0f 84 f4 00 00 00    	je     630f <fwp_apply+0x20f>
    621b:	44 89 fa             	mov    %r15d,%edx
    621e:	4c 89 f0             	mov    %r14,%rax
    6221:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    6225:	44 89 e2             	mov    %r12d,%edx
    6228:	66 90                	xchg   %ax,%ax
    622a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6231:	00 00 00 00 
    6235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    623c:	00 00 00 00 
    6240:	4c 8b 10             	mov    (%rax),%r10
    6243:	89 d1                	mov    %edx,%ecx
    6245:	48 83 c0 08          	add    $0x8,%rax
    6249:	83 c2 01             	add    $0x1,%edx
    624c:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    6250:	4c 39 d8             	cmp    %r11,%rax
    6253:	75 eb                	jne    6240 <fwp_apply+0x140>
    6255:	e9 b5 00 00 00       	jmp    630f <fwp_apply+0x20f>
    625a:	41 8d 7f 01          	lea    0x1(%r15),%edi
    625e:	be 02 00 00 00       	mov    $0x2,%esi
    6263:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    6267:	48 c1 e7 03          	shl    $0x3,%rdi
    626b:	e8 a0 fc ff ff       	call   5f10 <fwp_heap_alloc>
    6270:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    6274:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    6279:	48 89 c3             	mov    %rax,%rbx
    627c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    6280:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6284:	66 0f d6 00          	movq   %xmm0,(%rax)
    6288:	45 85 e4             	test   %r12d,%r12d
    628b:	74 14                	je     62a1 <fwp_apply+0x1a1>
    628d:	44 89 e2             	mov    %r12d,%edx
    6290:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    6294:	48 8d 78 08          	lea    0x8(%rax),%rdi
    6298:	48 c1 e2 03          	shl    $0x3,%rdx
    629c:	e8 4f d3 ff ff       	call   35f0 <memmove@plt>
    62a1:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    62a5:	45 85 ed             	test   %r13d,%r13d
    62a8:	74 2e                	je     62d8 <fwp_apply+0x1d8>
    62aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62b1:	00 00 00 00 
    62b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62bc:	00 00 00 00 
    62c0:	49 8b 16             	mov    (%r14),%rdx
    62c3:	44 89 e0             	mov    %r12d,%eax
    62c6:	49 83 c6 08          	add    $0x8,%r14
    62ca:	41 83 c4 01          	add    $0x1,%r12d
    62ce:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    62d3:	49 39 ce             	cmp    %rcx,%r14
    62d6:	75 e8                	jne    62c0 <fwp_apply+0x1c0>
    62d8:	48 89 d9             	mov    %rbx,%rcx
    62db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    62e0:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    62e4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    62eb:	00 00 
    62ed:	75 4e                	jne    633d <fwp_apply+0x23d>
    62ef:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    62f3:	48 89 c8             	mov    %rcx,%rax
    62f6:	5b                   	pop    %rbx
    62f7:	41 5c                	pop    %r12
    62f9:	41 5d                	pop    %r13
    62fb:	41 5e                	pop    %r14
    62fd:	41 5f                	pop    %r15
    62ff:	5d                   	pop    %rbp
    6300:	c3                   	ret
    6301:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6308:	45 31 ff             	xor    %r15d,%r15d
    630b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    630f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    6313:	41 ff 51 08          	call   *0x8(%r9)
    6317:	48 89 c1             	mov    %rax,%rcx
    631a:	45 39 fd             	cmp    %r15d,%r13d
    631d:	74 c1                	je     62e0 <fwp_apply+0x1e0>
    631f:	45 01 e5             	add    %r12d,%r13d
    6322:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    6326:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    632a:	41 29 dd             	sub    %ebx,%r13d
    632d:	e9 f5 fd ff ff       	jmp    6127 <fwp_apply+0x27>
    6332:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    6338:	e9 9c fe ff ff       	jmp    61d9 <fwp_apply+0xd9>
    633d:	e8 0e d1 ff ff       	call   3450 <__stack_chk_fail@plt>
    6342:	0f 1f 00             	nopl   (%rax)
    6345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    634c:	00 00 00 00 

0000000000006350 <fwp_p_ad_push>:
    6350:	41 57                	push   %r15
    6352:	41 56                	push   %r14
    6354:	41 55                	push   %r13
    6356:	49 89 d5             	mov    %rdx,%r13
    6359:	41 54                	push   %r12
    635b:	49 89 fc             	mov    %rdi,%r12
    635e:	55                   	push   %rbp
    635f:	53                   	push   %rbx
    6360:	48 83 ec 38          	sub    $0x38,%rsp
    6364:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6369:	48 85 ff             	test   %rdi,%rdi
    636c:	79 09                	jns    6377 <fwp_p_ad_push+0x27>
    636e:	48 85 d2             	test   %rdx,%rdx
    6371:	0f 88 a9 01 00 00    	js     6520 <fwp_p_ad_push+0x1d0>
    6377:	48 89 f8             	mov    %rdi,%rax
    637a:	48 89 0c 24          	mov    %rcx,(%rsp)
    637e:	48 09 d0             	or     %rdx,%rax
    6381:	0f 89 71 01 00 00    	jns    64f8 <fwp_p_ad_push+0x1a8>
    6387:	48 89 f8             	mov    %rdi,%rax
    638a:	48 c1 f8 20          	sar    $0x20,%rax
    638e:	48 85 ff             	test   %rdi,%rdi
    6391:	79 24                	jns    63b7 <fwp_p_ad_push+0x67>
    6393:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6398:	48 89 d0             	mov    %rdx,%rax
    639b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    63a2:	00 
    63a3:	49 89 d4             	mov    %rdx,%r12
    63a6:	48 c1 f8 20          	sar    $0x20,%rax
    63aa:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    63b1:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    63b7:	48 89 c7             	mov    %rax,%rdi
    63ba:	e8 71 e3 ff ff       	call   4730 <fwp_tape_of>
    63bf:	48 89 c3             	mov    %rax,%rbx
    63c2:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    63c7:	0f 85 6e 02 00 00    	jne    663b <fwp_p_ad_push+0x2eb>
    63cd:	4c 8b 78 10          	mov    0x10(%rax),%r15
    63d1:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    63d8:	0f 8f 51 02 00 00    	jg     662f <fwp_p_ad_push+0x2df>
    63de:	44 89 e0             	mov    %r12d,%eax
    63e1:	4c 39 f8             	cmp    %r15,%rax
    63e4:	0f 8d 39 02 00 00    	jge    6623 <fwp_p_ad_push+0x2d3>
    63ea:	4d 85 ed             	test   %r13,%r13
    63ed:	78 0c                	js     63fb <fwp_p_ad_push+0xab>
    63ef:	44 89 e8             	mov    %r13d,%eax
    63f2:	4c 39 f8             	cmp    %r15,%rax
    63f5:	0f 8d 28 02 00 00    	jge    6623 <fwp_p_ad_push+0x2d3>
    63fb:	4d 89 fe             	mov    %r15,%r14
    63fe:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6402:	49 8d 46 01          	lea    0x1(%r14),%rax
    6406:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    640c:	0f 87 1d 02 00 00    	ja     662f <fwp_p_ad_push+0x2df>
    6412:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    6416:	48 39 e8             	cmp    %rbp,%rax
    6419:	0f 8e 31 01 00 00    	jle    6550 <fwp_p_ad_push+0x200>
    641f:	48 85 ed             	test   %rbp,%rbp
    6422:	ba 40 00 00 00       	mov    $0x40,%edx
    6427:	48 0f 44 ea          	cmove  %rdx,%rbp
    642b:	48 39 e8             	cmp    %rbp,%rax
    642e:	7e 20                	jle    6450 <fwp_p_ad_push+0x100>
    6430:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    6437:	0f 8f 03 01 00 00    	jg     6540 <fwp_p_ad_push+0x1f0>
    643d:	48 01 ed             	add    %rbp,%rbp
    6440:	48 39 e8             	cmp    %rbp,%rax
    6443:	7f eb                	jg     6430 <fwp_p_ad_push+0xe0>
    6445:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    644c:	00 00 00 00 
    6450:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6457:	00 
    6458:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    645c:	ba 01 00 00 00       	mov    $0x1,%edx
    6461:	48 89 c6             	mov    %rax,%rsi
    6464:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    6469:	e8 22 ed ff ff       	call   5190 <ad_raw_realloc>
    646e:	48 85 c0             	test   %rax,%rax
    6471:	0f 84 d0 01 00 00    	je     6647 <fwp_p_ad_push+0x2f7>
    6477:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    647b:	48 89 ee             	mov    %rbp,%rsi
    647e:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6482:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6486:	48 c1 e6 04          	shl    $0x4,%rsi
    648a:	48 8d 04 90          	lea    (%rax,%rdx,4),%rax
    648e:	ba 02 00 00 00       	mov    $0x2,%edx
    6493:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6497:	e8 f4 ec ff ff       	call   5190 <ad_raw_realloc>
    649c:	48 85 c0             	test   %rax,%rax
    649f:	0f 84 a2 01 00 00    	je     6647 <fwp_p_ad_push+0x2f7>
    64a5:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    64a9:	48 89 43 30          	mov    %rax,0x30(%rbx)
    64ad:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    64b4:	00 
    64b5:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    64bc:	00 
    64bd:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
    64c4:	00 
    64c5:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    64c9:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    64ce:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    64d2:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    64d6:	4d 85 f6             	test   %r14,%r14
    64d9:	0f 85 e5 00 00 00    	jne    65c4 <fwp_p_ad_push+0x274>
    64df:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    64e3:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    64e7:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    64eb:	48 01 d1             	add    %rdx,%rcx
    64ee:	48 89 4b 28          	mov    %rcx,0x28(%rbx)
    64f2:	eb 7c                	jmp    6570 <fwp_p_ad_push+0x220>
    64f4:	0f 1f 40 00          	nopl   0x0(%rax)
    64f8:	48 89 d0             	mov    %rdx,%rax
    64fb:	48 c1 ff 20          	sar    $0x20,%rdi
    64ff:	48 c1 f8 20          	sar    $0x20,%rax
    6503:	48 39 c7             	cmp    %rax,%rdi
    6506:	0f 84 ab fe ff ff    	je     63b7 <fwp_p_ad_push+0x67>
    650c:	48 8d 3d f5 74 00 00 	lea    0x74f5(%rip),%rdi        # da08 <_IO_stdin_used+0xa08>
    6513:	e8 38 df ff ff       	call   4450 <fwp_trap>
    6518:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    651f:	00 
    6520:	48 83 c4 38          	add    $0x38,%rsp
    6524:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    652b:	5b                   	pop    %rbx
    652c:	5d                   	pop    %rbp
    652d:	41 5c                	pop    %r12
    652f:	41 5d                	pop    %r13
    6531:	41 5e                	pop    %r14
    6533:	41 5f                	pop    %r15
    6535:	c3                   	ret
    6536:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    653d:	00 00 00 
    6540:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    6545:	e9 06 ff ff ff       	jmp    6450 <fwp_p_ad_push+0x100>
    654a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6550:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    6554:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6558:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    655f:	00 
    6560:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    6567:	00 
    6568:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
    656c:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6570:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6576:	46 89 24 12          	mov    %r12d,(%rdx,%r10,1)
    657a:	4d 85 ed             	test   %r13,%r13
    657d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6582:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6588:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    658f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6593:	49 8d 47 01          	lea    0x1(%r15),%rax
    6597:	46 89 2c 11          	mov    %r13d,(%rcx,%r10,1)
    659b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    65a1:	48 89 43 10          	mov    %rax,0x10(%rbx)
    65a5:	48 83 c4 38          	add    $0x38,%rsp
    65a9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    65b0:	ff ff ff 
    65b3:	4c 21 e0             	and    %r12,%rax
    65b6:	5b                   	pop    %rbx
    65b7:	5d                   	pop    %rbp
    65b8:	4c 09 f8             	or     %r15,%rax
    65bb:	41 5c                	pop    %r12
    65bd:	41 5d                	pop    %r13
    65bf:	41 5e                	pop    %r14
    65c1:	41 5f                	pop    %r15
    65c3:	c3                   	ret
    65c4:	4c 89 ca             	mov    %r9,%rdx
    65c7:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    65cc:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    65d1:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    65d6:	e8 15 d0 ff ff       	call   35f0 <memmove@plt>
    65db:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    65e0:	4c 03 73 30          	add    0x30(%rbx),%r14
    65e4:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    65e9:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    65ed:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    65f1:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    65f6:	48 03 7b 20          	add    0x20(%rbx),%rdi
    65fa:	4c 89 d2             	mov    %r10,%rdx
    65fd:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    6602:	e8 e9 cf ff ff       	call   35f0 <memmove@plt>
    6607:	48 8b 43 30          	mov    0x30(%rbx),%rax
    660b:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    660f:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    6614:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6619:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    661e:	e9 c0 fe ff ff       	jmp    64e3 <fwp_p_ad_push+0x193>
    6623:	48 8d 3d 98 6b 00 00 	lea    0x6b98(%rip),%rdi        # d1c2 <_IO_stdin_used+0x1c2>
    662a:	e8 21 de ff ff       	call   4450 <fwp_trap>
    662f:	48 8d 3d 71 6b 00 00 	lea    0x6b71(%rip),%rdi        # d1a7 <_IO_stdin_used+0x1a7>
    6636:	e8 15 de ff ff       	call   4450 <fwp_trap>
    663b:	48 8d 3d 0e 74 00 00 	lea    0x740e(%rip),%rdi        # da50 <_IO_stdin_used+0xa50>
    6642:	e8 09 de ff ff       	call   4450 <fwp_trap>
    6647:	48 89 df             	mov    %rbx,%rdi
    664a:	e8 41 d6 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    664f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6653:	48 85 ff             	test   %rdi,%rdi
    6656:	74 05                	je     665d <fwp_p_ad_push+0x30d>
    6658:	e8 73 ea ff ff       	call   50d0 <ad_raw_free.part.0>
    665d:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6661:	48 85 ff             	test   %rdi,%rdi
    6664:	74 05                	je     666b <fwp_p_ad_push+0x31b>
    6666:	e8 65 ea ff ff       	call   50d0 <ad_raw_free.part.0>
    666b:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    666f:	48 85 ff             	test   %rdi,%rdi
    6672:	74 05                	je     6679 <fwp_p_ad_push+0x329>
    6674:	e8 57 ea ff ff       	call   50d0 <ad_raw_free.part.0>
    6679:	31 c9                	xor    %ecx,%ecx
    667b:	31 c0                	xor    %eax,%eax
    667d:	31 d2                	xor    %edx,%edx
    667f:	be 01 00 00 00       	mov    $0x1,%esi
    6684:	89 53 04             	mov    %edx,0x4(%rbx)
    6687:	66 0f ef c0          	pxor   %xmm0,%xmm0
    668b:	ba 13 00 00 00       	mov    $0x13,%edx
    6690:	48 8d 3d 71 69 00 00 	lea    0x6971(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    6697:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    669b:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    669f:	48 8b 0d ba a9 00 00 	mov    0xa9ba(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    66a6:	48 89 43 40          	mov    %rax,0x40(%rbx)
    66aa:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    66ae:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    66b2:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    66b6:	e8 a5 cf ff ff       	call   3660 <fwrite@plt>
    66bb:	31 ff                	xor    %edi,%edi
    66bd:	e8 de ce ff ff       	call   35a0 <fflush@plt>
    66c2:	bf 66 00 00 00       	mov    $0x66,%edi
    66c7:	e8 b4 cf ff ff       	call   3680 <_Exit@plt>
    66cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000066d0 <w107>:
    66d0:	66 0f 28 e0          	movapd %xmm0,%xmm4
    66d4:	41 55                	push   %r13
    66d6:	48 89 fa             	mov    %rdi,%rdx
    66d9:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    66dd:	41 54                	push   %r12
    66df:	49 89 fc             	mov    %rdi,%r12
    66e2:	55                   	push   %rbp
    66e3:	53                   	push   %rbx
    66e4:	48 89 f3             	mov    %rsi,%rbx
    66e7:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    66ec:	48 89 f1             	mov    %rsi,%rcx
    66ef:	48 83 ec 28          	sub    $0x28,%rsp
    66f3:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    66f9:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    66ff:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6705:	e8 46 fc ff ff       	call   6350 <fwp_p_ad_push>
    670a:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6710:	48 89 da             	mov    %rbx,%rdx
    6713:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6719:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6720:	00 f0 3f 
    6723:	48 89 c7             	mov    %rax,%rdi
    6726:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    672d:	00 f0 bf 
    6730:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    6735:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    673b:	e8 10 fc ff ff       	call   6350 <fwp_p_ad_push>
    6740:	f2 0f 10 05 98 76 00 	movsd  0x7698(%rip),%xmm0        # dde0 <msg.4+0xb0>
    6747:	00 
    6748:	4c 89 e7             	mov    %r12,%rdi
    674b:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    6751:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6758:	00 f0 3f 
    675b:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6762:	49 89 c5             	mov    %rax,%r13
    6765:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    676c:	00 f0 bf 
    676f:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    6774:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    677a:	e8 d1 fb ff ff       	call   6350 <fwp_p_ad_push>
    677f:	48 89 e9             	mov    %rbp,%rcx
    6782:	4c 89 ea             	mov    %r13,%rdx
    6785:	48 89 ee             	mov    %rbp,%rsi
    6788:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    678e:	4c 89 ef             	mov    %r13,%rdi
    6791:	49 89 c4             	mov    %rax,%r12
    6794:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6798:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    679e:	e8 ad fb ff ff       	call   6350 <fwp_p_ad_push>
    67a3:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    67a9:	f2 0f 59 1d 37 76 00 	mulsd  0x7637(%rip),%xmm3        # dde8 <msg.4+0xb8>
    67b0:	00 
    67b1:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    67b8:	00 59 40 
    67bb:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    67c0:	48 89 c2             	mov    %rax,%rdx
    67c3:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    67ca:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    67d0:	e8 7b fb ff ff       	call   6350 <fwp_p_ad_push>
    67d5:	48 89 d9             	mov    %rbx,%rcx
    67d8:	4c 89 e2             	mov    %r12,%rdx
    67db:	48 89 de             	mov    %rbx,%rsi
    67de:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    67e4:	4c 89 e7             	mov    %r12,%rdi
    67e7:	48 89 c5             	mov    %rax,%rbp
    67ea:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    67ee:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    67f4:	e8 57 fb ff ff       	call   6350 <fwp_p_ad_push>
    67f9:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    67ff:	48 89 ea             	mov    %rbp,%rdx
    6802:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6808:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    680f:	00 f0 3f 
    6812:	48 89 c7             	mov    %rax,%rdi
    6815:	48 89 ce             	mov    %rcx,%rsi
    6818:	66 48 0f 7e db       	movq   %xmm3,%rbx
    681d:	e8 2e fb ff ff       	call   6350 <fwp_p_ad_push>
    6822:	48 83 c4 28          	add    $0x28,%rsp
    6826:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    682b:	5b                   	pop    %rbx
    682c:	5d                   	pop    %rbp
    682d:	41 5c                	pop    %r12
    682f:	41 5d                	pop    %r13
    6831:	c3                   	ret
    6832:	0f 1f 00             	nopl   (%rax)
    6835:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    683c:	00 00 00 00 

0000000000006840 <fwp_data.part.0.constprop.0>:
    6840:	41 56                	push   %r14
    6842:	8b 05 9c 43 06 00    	mov    0x6439c(%rip),%eax        # 6abe4 <fwp_heap+0x13a4>
    6848:	41 89 fe             	mov    %edi,%r14d
    684b:	41 55                	push   %r13
    684d:	44 8b 2d b4 4c 06 00 	mov    0x64cb4(%rip),%r13d        # 6b508 <iteration_active>
    6854:	41 54                	push   %r12
    6856:	49 89 f4             	mov    %rsi,%r12
    6859:	55                   	push   %rbp
    685a:	53                   	push   %rbx
    685b:	45 85 ed             	test   %r13d,%r13d
    685e:	0f 84 1c 01 00 00    	je     6980 <fwp_data.part.0.constprop.0+0x140>
    6864:	48 83 05 94 4c 06 00 	addq   $0x1,0x64c94(%rip)        # 6b500 <iteration_requests>
    686b:	01 
    686c:	48 83 05 84 4c 06 00 	addq   $0x18,0x64c84(%rip)        # 6b4f8 <iteration_bytes>
    6873:	18 
    6874:	85 c0                	test   %eax,%eax
    6876:	0f 84 8c 01 00 00    	je     6a08 <fwp_data.part.0.constprop.0+0x1c8>
    687c:	0f b6 05 5f 3f 06 00 	movzbl 0x63f5f(%rip),%eax        # 6a7e2 <fwp_heap+0xfa2>
    6883:	48 8d 15 b6 2f 06 00 	lea    0x62fb6(%rip),%rdx        # 69840 <fwp_heap>
    688a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6891:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6895:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6899:	48 8b 18             	mov    (%rax),%rbx
    689c:	48 85 db             	test   %rbx,%rbx
    689f:	0f 84 fb 00 00 00    	je     69a0 <fwp_data.part.0.constprop.0+0x160>
    68a5:	48 8b 13             	mov    (%rbx),%rdx
    68a8:	48 f7 d2             	not    %rdx
    68ab:	48 89 10             	mov    %rdx,(%rax)
    68ae:	48 83 fd 18          	cmp    $0x18,%rbp
    68b2:	76 1b                	jbe    68cf <fwp_data.part.0.constprop.0+0x8f>
    68b4:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    68b8:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    68bc:	31 f6                	xor    %esi,%esi
    68be:	48 c1 e8 03          	shr    $0x3,%rax
    68c2:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    68c9:	00 
    68ca:	e8 e1 cb ff ff       	call   34b0 <memset@plt>
    68cf:	48 89 e8             	mov    %rbp,%rax
    68d2:	48 03 05 87 43 06 00 	add    0x64387(%rip),%rax        # 6ac60 <fwp_heap+0x1420>
    68d9:	0f 82 3d 01 00 00    	jb     6a1c <fwp_data.part.0.constprop.0+0x1dc>
    68df:	48 39 05 82 43 06 00 	cmp    %rax,0x64382(%rip)        # 6ac68 <fwp_heap+0x1428>
    68e6:	48 89 05 73 43 06 00 	mov    %rax,0x64373(%rip)        # 6ac60 <fwp_heap+0x1420>
    68ed:	73 07                	jae    68f6 <fwp_data.part.0.constprop.0+0xb6>
    68ef:	48 89 05 72 43 06 00 	mov    %rax,0x64372(%rip)        # 6ac68 <fwp_heap+0x1428>
    68f6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    68fa:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    68ff:	f2 0f 58 05 71 43 06 	addsd  0x64371(%rip),%xmm0        # 6ac78 <fwp_heap+0x1438>
    6906:	00 
    6907:	f2 0f 11 05 69 43 06 	movsd  %xmm0,0x64369(%rip)        # 6ac78 <fwp_heap+0x1438>
    690e:	00 
    690f:	45 85 ed             	test   %r13d,%r13d
    6912:	74 33                	je     6947 <fwp_data.part.0.constprop.0+0x107>
    6914:	48 8b 05 45 43 06 00 	mov    0x64345(%rip),%rax        # 6ac60 <fwp_heap+0x1420>
    691b:	48 85 c0             	test   %rax,%rax
    691e:	0f 88 a4 00 00 00    	js     69c8 <fwp_data.part.0.constprop.0+0x188>
    6924:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6928:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    692d:	f2 0f 5c 05 b3 4b 06 	subsd  0x64bb3(%rip),%xmm0        # 6b4e8 <iteration_start_charge>
    6934:	00 
    6935:	66 0f 2f 05 a3 4b 06 	comisd 0x64ba3(%rip),%xmm0        # 6b4e0 <iteration_peak>
    693c:	00 
    693d:	76 08                	jbe    6947 <fwp_data.part.0.constprop.0+0x107>
    693f:	f2 0f 11 05 99 4b 06 	movsd  %xmm0,0x64b99(%rip)        # 6b4e0 <iteration_peak>
    6946:	00 
    6947:	b8 02 00 00 00       	mov    $0x2,%eax
    694c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6951:	66 0f 6e c8          	movd   %eax,%xmm1
    6955:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6959:	66 0f d6 03          	movq   %xmm0,(%rbx)
    695d:	49 8b 04 24          	mov    (%r12),%rax
    6961:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6965:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    696a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    696e:	48 89 d8             	mov    %rbx,%rax
    6971:	5b                   	pop    %rbx
    6972:	5d                   	pop    %rbp
    6973:	41 5c                	pop    %r12
    6975:	41 5d                	pop    %r13
    6977:	41 5e                	pop    %r14
    6979:	c3                   	ret
    697a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6980:	85 c0                	test   %eax,%eax
    6982:	0f 85 f4 fe ff ff    	jne    687c <fwp_data.part.0.constprop.0+0x3c>
    6988:	31 f6                	xor    %esi,%esi
    698a:	bf 18 00 00 00       	mov    $0x18,%edi
    698f:	e8 7c f5 ff ff       	call   5f10 <fwp_heap_alloc>
    6994:	48 89 c3             	mov    %rax,%rbx
    6997:	eb ae                	jmp    6947 <fwp_data.part.0.constprop.0+0x107>
    6999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    69a0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    69a4:	48 85 db             	test   %rbx,%rbx
    69a7:	74 47                	je     69f0 <fwp_data.part.0.constprop.0+0x1b0>
    69a9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    69ad:	48 29 da             	sub    %rbx,%rdx
    69b0:	48 39 ea             	cmp    %rbp,%rdx
    69b3:	72 3b                	jb     69f0 <fwp_data.part.0.constprop.0+0x1b0>
    69b5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    69b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    69bd:	e9 ec fe ff ff       	jmp    68ae <fwp_data.part.0.constprop.0+0x6e>
    69c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    69c8:	48 89 c2             	mov    %rax,%rdx
    69cb:	83 e0 01             	and    $0x1,%eax
    69ce:	66 0f ef c0          	pxor   %xmm0,%xmm0
    69d2:	48 d1 ea             	shr    $1,%rdx
    69d5:	48 09 c2             	or     %rax,%rdx
    69d8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    69dd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    69e1:	e9 47 ff ff ff       	jmp    692d <fwp_data.part.0.constprop.0+0xed>
    69e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    69ed:	00 00 00 
    69f0:	31 f6                	xor    %esi,%esi
    69f2:	bf 18 00 00 00       	mov    $0x18,%edi
    69f7:	e8 14 f5 ff ff       	call   5f10 <fwp_heap_alloc>
    69fc:	48 89 c3             	mov    %rax,%rbx
    69ff:	e9 0b ff ff ff       	jmp    690f <fwp_data.part.0.constprop.0+0xcf>
    6a04:	0f 1f 40 00          	nopl   0x0(%rax)
    6a08:	31 f6                	xor    %esi,%esi
    6a0a:	bf 18 00 00 00       	mov    $0x18,%edi
    6a0f:	e8 fc f4 ff ff       	call   5f10 <fwp_heap_alloc>
    6a14:	48 89 c3             	mov    %rax,%rbx
    6a17:	e9 f8 fe ff ff       	jmp    6914 <fwp_data.part.0.constprop.0+0xd4>
    6a1c:	e8 0f d4 ff ff       	call   3e30 <fwp_heap_oom>
    6a21:	0f 1f 40 00          	nopl   0x0(%rax)
    6a25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6a2c:	00 00 00 00 

0000000000006a30 <fwp_rc_share>:
    6a30:	48 8b 05 e1 41 06 00 	mov    0x641e1(%rip),%rax        # 6ac18 <fwp_heap+0x13d8>
    6a37:	48 2b 3d b2 41 06 00 	sub    0x641b2(%rip),%rdi        # 6abf0 <fwp_heap+0x13b0>
    6a3e:	48 c1 e0 10          	shl    $0x10,%rax
    6a42:	48 39 c7             	cmp    %rax,%rdi
    6a45:	73 4a                	jae    6a91 <fwp_rc_share+0x61>
    6a47:	48 89 f8             	mov    %rdi,%rax
    6a4a:	48 c1 e8 10          	shr    $0x10,%rax
    6a4e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6a52:	48 8b 05 df 41 06 00 	mov    0x641df(%rip),%rax        # 6ac38 <fwp_heap+0x13f8>
    6a59:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6a5d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6a61:	48 85 d2             	test   %rdx,%rdx
    6a64:	74 2b                	je     6a91 <fwp_rc_share+0x61>
    6a66:	0f b6 08             	movzbl (%rax),%ecx
    6a69:	80 f9 02             	cmp    $0x2,%cl
    6a6c:	74 2a                	je     6a98 <fwp_rc_share+0x68>
    6a6e:	80 f9 01             	cmp    $0x1,%cl
    6a71:	75 1e                	jne    6a91 <fwp_rc_share+0x61>
    6a73:	8b 48 18             	mov    0x18(%rax),%ecx
    6a76:	0f b7 ff             	movzwl %di,%edi
    6a79:	8b 40 1c             	mov    0x1c(%rax),%eax
    6a7c:	48 0f af f9          	imul   %rcx,%rdi
    6a80:	48 c1 ef 20          	shr    $0x20,%rdi
    6a84:	48 39 c7             	cmp    %rax,%rdi
    6a87:	73 08                	jae    6a91 <fwp_rc_share+0x61>
    6a89:	48 01 fa             	add    %rdi,%rdx
    6a8c:	80 3a 00             	cmpb   $0x0,(%rdx)
    6a8f:	75 0d                	jne    6a9e <fwp_rc_share+0x6e>
    6a91:	c3                   	ret
    6a92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a98:	66 85 ff             	test   %di,%di
    6a9b:	74 ef                	je     6a8c <fwp_rc_share+0x5c>
    6a9d:	c3                   	ret
    6a9e:	50                   	push   %rax
    6a9f:	48 8d 3d da 6f 00 00 	lea    0x6fda(%rip),%rdi        # da80 <_IO_stdin_used+0xa80>
    6aa6:	e8 a5 d9 ff ff       	call   4450 <fwp_trap>
    6aab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006ab0 <fwp_rc_free_arr>:
    6ab0:	48 8b 15 61 41 06 00 	mov    0x64161(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    6ab7:	48 89 f8             	mov    %rdi,%rax
    6aba:	48 2b 05 2f 41 06 00 	sub    0x6412f(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    6ac1:	48 c1 e2 10          	shl    $0x10,%rdx
    6ac5:	48 39 d0             	cmp    %rdx,%rax
    6ac8:	73 5b                	jae    6b25 <fwp_rc_free_arr+0x75>
    6aca:	48 89 c2             	mov    %rax,%rdx
    6acd:	48 c1 ea 10          	shr    $0x10,%rdx
    6ad1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ad5:	48 8b 15 5c 41 06 00 	mov    0x6415c(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    6adc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6ae0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6ae4:	48 85 c9             	test   %rcx,%rcx
    6ae7:	74 3c                	je     6b25 <fwp_rc_free_arr+0x75>
    6ae9:	0f b6 32             	movzbl (%rdx),%esi
    6aec:	40 80 fe 02          	cmp    $0x2,%sil
    6af0:	74 2e                	je     6b20 <fwp_rc_free_arr+0x70>
    6af2:	40 80 fe 01          	cmp    $0x1,%sil
    6af6:	75 2d                	jne    6b25 <fwp_rc_free_arr+0x75>
    6af8:	8b 72 18             	mov    0x18(%rdx),%esi
    6afb:	0f b7 c0             	movzwl %ax,%eax
    6afe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6b01:	48 0f af c6          	imul   %rsi,%rax
    6b05:	48 c1 e8 20          	shr    $0x20,%rax
    6b09:	48 39 d0             	cmp    %rdx,%rax
    6b0c:	73 17                	jae    6b25 <fwp_rc_free_arr+0x75>
    6b0e:	48 01 c1             	add    %rax,%rcx
    6b11:	80 39 01             	cmpb   $0x1,(%rcx)
    6b14:	75 0f                	jne    6b25 <fwp_rc_free_arr+0x75>
    6b16:	e9 f5 ee ff ff       	jmp    5a10 <fwp_mem_free>
    6b1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6b20:	66 85 c0             	test   %ax,%ax
    6b23:	74 ec                	je     6b11 <fwp_rc_free_arr+0x61>
    6b25:	c3                   	ret
    6b26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b2d:	00 00 00 

0000000000006b30 <fwp_rc_dup>:
    6b30:	f3 0f 1e fa          	endbr64
    6b34:	48 8b 05 dd 40 06 00 	mov    0x640dd(%rip),%rax        # 6ac18 <fwp_heap+0x13d8>
    6b3b:	48 2b 3d ae 40 06 00 	sub    0x640ae(%rip),%rdi        # 6abf0 <fwp_heap+0x13b0>
    6b42:	48 c1 e0 10          	shl    $0x10,%rax
    6b46:	48 39 c7             	cmp    %rax,%rdi
    6b49:	73 60                	jae    6bab <fwp_rc_dup+0x7b>
    6b4b:	48 89 f8             	mov    %rdi,%rax
    6b4e:	48 c1 e8 10          	shr    $0x10,%rax
    6b52:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6b56:	48 8b 05 db 40 06 00 	mov    0x640db(%rip),%rax        # 6ac38 <fwp_heap+0x13f8>
    6b5d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6b61:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6b65:	48 85 c0             	test   %rax,%rax
    6b68:	74 41                	je     6bab <fwp_rc_dup+0x7b>
    6b6a:	0f b6 0a             	movzbl (%rdx),%ecx
    6b6d:	80 f9 02             	cmp    $0x2,%cl
    6b70:	74 3e                	je     6bb0 <fwp_rc_dup+0x80>
    6b72:	80 f9 01             	cmp    $0x1,%cl
    6b75:	75 34                	jne    6bab <fwp_rc_dup+0x7b>
    6b77:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6b7a:	0f b7 ff             	movzwl %di,%edi
    6b7d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6b80:	48 0f af f9          	imul   %rcx,%rdi
    6b84:	48 c1 ef 20          	shr    $0x20,%rdi
    6b88:	48 39 d7             	cmp    %rdx,%rdi
    6b8b:	73 1e                	jae    6bab <fwp_rc_dup+0x7b>
    6b8d:	48 01 f8             	add    %rdi,%rax
    6b90:	0f b6 10             	movzbl (%rax),%edx
    6b93:	84 d2                	test   %dl,%dl
    6b95:	74 14                	je     6bab <fwp_rc_dup+0x7b>
    6b97:	8b 0d 6b 49 06 00    	mov    0x6496b(%rip),%ecx        # 6b508 <iteration_active>
    6b9d:	85 c9                	test   %ecx,%ecx
    6b9f:	75 1f                	jne    6bc0 <fwp_rc_dup+0x90>
    6ba1:	80 fa fd             	cmp    $0xfd,%dl
    6ba4:	77 2a                	ja     6bd0 <fwp_rc_dup+0xa0>
    6ba6:	83 c2 01             	add    $0x1,%edx
    6ba9:	88 10                	mov    %dl,(%rax)
    6bab:	c3                   	ret
    6bac:	0f 1f 40 00          	nopl   0x0(%rax)
    6bb0:	66 85 ff             	test   %di,%di
    6bb3:	74 db                	je     6b90 <fwp_rc_dup+0x60>
    6bb5:	c3                   	ret
    6bb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6bbd:	00 00 00 
    6bc0:	48 83 05 28 49 06 00 	addq   $0x1,0x64928(%rip)        # 6b4f0 <iteration_retains>
    6bc7:	01 
    6bc8:	eb d7                	jmp    6ba1 <fwp_rc_dup+0x71>
    6bca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6bd0:	48 89 c7             	mov    %rax,%rdi
    6bd3:	e9 d8 ea ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    6bd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6bdf:	00 

0000000000006be0 <fwp_owned_entry161>:
    6be0:	f3 0f 1e fa          	endbr64
    6be4:	48 83 ec 38          	sub    $0x38,%rsp
    6be8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6bed:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6bf4:	00 00 
    6bf6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6bfb:	31 c0                	xor    %eax,%eax
    6bfd:	48 8b 07             	mov    (%rdi),%rax
    6c00:	48 03 47 10          	add    0x10(%rdi),%rax
    6c04:	0f 80 c2 00 00 00    	jo     6ccc <fwp_owned_entry161+0xec>
    6c0a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6c0f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6c14:	31 ff                	xor    %edi,%edi
    6c16:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6c1a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6c1f:	e8 1c fc ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    6c24:	48 8b 15 ed 3f 06 00 	mov    0x63fed(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    6c2b:	48 89 c6             	mov    %rax,%rsi
    6c2e:	48 2b 05 bb 3f 06 00 	sub    0x63fbb(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    6c35:	48 c1 e2 10          	shl    $0x10,%rdx
    6c39:	48 39 d0             	cmp    %rdx,%rax
    6c3c:	73 4f                	jae    6c8d <fwp_owned_entry161+0xad>
    6c3e:	48 89 c2             	mov    %rax,%rdx
    6c41:	48 c1 ea 10          	shr    $0x10,%rdx
    6c45:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c49:	48 8b 15 e8 3f 06 00 	mov    0x63fe8(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    6c50:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c54:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c58:	48 85 d2             	test   %rdx,%rdx
    6c5b:	74 30                	je     6c8d <fwp_owned_entry161+0xad>
    6c5d:	0f b6 39             	movzbl (%rcx),%edi
    6c60:	40 80 ff 02          	cmp    $0x2,%dil
    6c64:	74 42                	je     6ca8 <fwp_owned_entry161+0xc8>
    6c66:	40 80 ff 01          	cmp    $0x1,%dil
    6c6a:	75 21                	jne    6c8d <fwp_owned_entry161+0xad>
    6c6c:	8b 79 18             	mov    0x18(%rcx),%edi
    6c6f:	0f b7 c0             	movzwl %ax,%eax
    6c72:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c75:	48 0f af c7          	imul   %rdi,%rax
    6c79:	48 c1 e8 20          	shr    $0x20,%rax
    6c7d:	48 39 c8             	cmp    %rcx,%rax
    6c80:	73 0b                	jae    6c8d <fwp_owned_entry161+0xad>
    6c82:	48 01 c2             	add    %rax,%rdx
    6c85:	80 3a ff             	cmpb   $0xff,(%rdx)
    6c88:	74 26                	je     6cb0 <fwp_owned_entry161+0xd0>
    6c8a:	c6 02 01             	movb   $0x1,(%rdx)
    6c8d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6c92:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6c99:	00 00 
    6c9b:	75 34                	jne    6cd1 <fwp_owned_entry161+0xf1>
    6c9d:	48 89 f0             	mov    %rsi,%rax
    6ca0:	48 83 c4 38          	add    $0x38,%rsp
    6ca4:	c3                   	ret
    6ca5:	0f 1f 00             	nopl   (%rax)
    6ca8:	66 85 c0             	test   %ax,%ax
    6cab:	75 e0                	jne    6c8d <fwp_owned_entry161+0xad>
    6cad:	eb d6                	jmp    6c85 <fwp_owned_entry161+0xa5>
    6caf:	90                   	nop
    6cb0:	48 89 d7             	mov    %rdx,%rdi
    6cb3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6cb8:	48 89 14 24          	mov    %rdx,(%rsp)
    6cbc:	e8 0f eb ff ff       	call   57d0 <fwp_rc_forget_slot>
    6cc1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6cc6:	48 8b 14 24          	mov    (%rsp),%rdx
    6cca:	eb be                	jmp    6c8a <fwp_owned_entry161+0xaa>
    6ccc:	e8 2f ca ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6cd1:	e8 7a c7 ff ff       	call   3450 <__stack_chk_fail@plt>
    6cd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6cdd:	00 00 00 

0000000000006ce0 <e161>:
    6ce0:	f3 0f 1e fa          	endbr64
    6ce4:	53                   	push   %rbx
    6ce5:	48 83 ec 30          	sub    $0x30,%rsp
    6ce9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6cee:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6cf5:	00 00 
    6cf7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6cfc:	31 c0                	xor    %eax,%eax
    6cfe:	48 8b 07             	mov    (%rdi),%rax
    6d01:	48 03 47 10          	add    0x10(%rdi),%rax
    6d05:	0f 80 c9 00 00 00    	jo     6dd4 <e161+0xf4>
    6d0b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6d10:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6d15:	31 ff                	xor    %edi,%edi
    6d17:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6d1b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6d20:	e8 1b fb ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    6d25:	48 8b 15 ec 3e 06 00 	mov    0x63eec(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    6d2c:	48 89 c3             	mov    %rax,%rbx
    6d2f:	48 2b 05 ba 3e 06 00 	sub    0x63eba(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    6d36:	48 c1 e2 10          	shl    $0x10,%rdx
    6d3a:	48 39 d0             	cmp    %rdx,%rax
    6d3d:	73 4f                	jae    6d8e <e161+0xae>
    6d3f:	48 89 c2             	mov    %rax,%rdx
    6d42:	48 c1 ea 10          	shr    $0x10,%rdx
    6d46:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d4a:	48 8b 15 e7 3e 06 00 	mov    0x63ee7(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    6d51:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6d55:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d59:	48 85 d2             	test   %rdx,%rdx
    6d5c:	74 30                	je     6d8e <e161+0xae>
    6d5e:	0f b6 31             	movzbl (%rcx),%esi
    6d61:	40 80 fe 02          	cmp    $0x2,%sil
    6d65:	74 49                	je     6db0 <e161+0xd0>
    6d67:	40 80 fe 01          	cmp    $0x1,%sil
    6d6b:	75 21                	jne    6d8e <e161+0xae>
    6d6d:	8b 71 18             	mov    0x18(%rcx),%esi
    6d70:	0f b7 c0             	movzwl %ax,%eax
    6d73:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6d76:	48 0f af c6          	imul   %rsi,%rax
    6d7a:	48 c1 e8 20          	shr    $0x20,%rax
    6d7e:	48 39 c8             	cmp    %rcx,%rax
    6d81:	73 0b                	jae    6d8e <e161+0xae>
    6d83:	48 01 c2             	add    %rax,%rdx
    6d86:	80 3a ff             	cmpb   $0xff,(%rdx)
    6d89:	74 35                	je     6dc0 <e161+0xe0>
    6d8b:	c6 02 01             	movb   $0x1,(%rdx)
    6d8e:	48 89 df             	mov    %rbx,%rdi
    6d91:	e8 9a fc ff ff       	call   6a30 <fwp_rc_share>
    6d96:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6d9b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6da2:	00 00 
    6da4:	75 33                	jne    6dd9 <e161+0xf9>
    6da6:	48 83 c4 30          	add    $0x30,%rsp
    6daa:	48 89 d8             	mov    %rbx,%rax
    6dad:	5b                   	pop    %rbx
    6dae:	c3                   	ret
    6daf:	90                   	nop
    6db0:	66 85 c0             	test   %ax,%ax
    6db3:	75 d9                	jne    6d8e <e161+0xae>
    6db5:	eb cf                	jmp    6d86 <e161+0xa6>
    6db7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6dbe:	00 00 
    6dc0:	48 89 d7             	mov    %rdx,%rdi
    6dc3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6dc8:	e8 03 ea ff ff       	call   57d0 <fwp_rc_forget_slot>
    6dcd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6dd2:	eb b7                	jmp    6d8b <e161+0xab>
    6dd4:	e8 27 c9 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6dd9:	e8 72 c6 ff ff       	call   3450 <__stack_chk_fail@plt>
    6dde:	66 90                	xchg   %ax,%ax

0000000000006de0 <fwp_drop0>:
    6de0:	f3 0f 1e fa          	endbr64
    6de4:	48 8b 15 2d 3e 06 00 	mov    0x63e2d(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    6deb:	48 89 f8             	mov    %rdi,%rax
    6dee:	48 2b 05 fb 3d 06 00 	sub    0x63dfb(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    6df5:	48 c1 e2 10          	shl    $0x10,%rdx
    6df9:	48 39 d0             	cmp    %rdx,%rax
    6dfc:	0f 83 be 00 00 00    	jae    6ec0 <fwp_drop0+0xe0>
    6e02:	48 83 ec 18          	sub    $0x18,%rsp
    6e06:	4c 8d 05 33 2a 06 00 	lea    0x62a33(%rip),%r8        # 69840 <fwp_heap>
    6e0d:	48 89 c2             	mov    %rax,%rdx
    6e10:	48 c1 ea 10          	shr    $0x10,%rdx
    6e14:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6e18:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6e1f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6e23:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6e27:	48 85 d2             	test   %rdx,%rdx
    6e2a:	74 3c                	je     6e68 <fwp_drop0+0x88>
    6e2c:	0f b6 31             	movzbl (%rcx),%esi
    6e2f:	40 80 fe 02          	cmp    $0x2,%sil
    6e33:	74 3b                	je     6e70 <fwp_drop0+0x90>
    6e35:	40 80 fe 01          	cmp    $0x1,%sil
    6e39:	75 2d                	jne    6e68 <fwp_drop0+0x88>
    6e3b:	8b 71 18             	mov    0x18(%rcx),%esi
    6e3e:	0f b7 c0             	movzwl %ax,%eax
    6e41:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6e44:	48 0f af c6          	imul   %rsi,%rax
    6e48:	48 c1 e8 20          	shr    $0x20,%rax
    6e4c:	48 39 c8             	cmp    %rcx,%rax
    6e4f:	73 17                	jae    6e68 <fwp_drop0+0x88>
    6e51:	48 01 c2             	add    %rax,%rdx
    6e54:	0f b6 02             	movzbl (%rdx),%eax
    6e57:	84 c0                	test   %al,%al
    6e59:	74 0d                	je     6e68 <fwp_drop0+0x88>
    6e5b:	3c 01                	cmp    $0x1,%al
    6e5d:	74 21                	je     6e80 <fwp_drop0+0xa0>
    6e5f:	3c ff                	cmp    $0xff,%al
    6e61:	74 65                	je     6ec8 <fwp_drop0+0xe8>
    6e63:	83 e8 01             	sub    $0x1,%eax
    6e66:	88 02                	mov    %al,(%rdx)
    6e68:	48 83 c4 18          	add    $0x18,%rsp
    6e6c:	c3                   	ret
    6e6d:	0f 1f 00             	nopl   (%rax)
    6e70:	66 85 c0             	test   %ax,%ax
    6e73:	74 df                	je     6e54 <fwp_drop0+0x74>
    6e75:	48 83 c4 18          	add    $0x18,%rsp
    6e79:	c3                   	ret
    6e7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6e80:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6e84:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6e89:	e8 22 fc ff ff       	call   6ab0 <fwp_rc_free_arr>
    6e8e:	4c 8d 05 ab 29 06 00 	lea    0x629ab(%rip),%r8        # 69840 <fwp_heap>
    6e95:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6e9a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6ea1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6ea8:	48 c1 e2 10          	shl    $0x10,%rdx
    6eac:	48 39 d0             	cmp    %rdx,%rax
    6eaf:	73 b7                	jae    6e68 <fwp_drop0+0x88>
    6eb1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6eb6:	e9 52 ff ff ff       	jmp    6e0d <fwp_drop0+0x2d>
    6ebb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6ec0:	c3                   	ret
    6ec1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6ec8:	48 89 d0             	mov    %rdx,%rax
    6ecb:	48 c1 e8 11          	shr    $0x11,%rax
    6ecf:	48 31 d0             	xor    %rdx,%rax
    6ed2:	48 89 c1             	mov    %rax,%rcx
    6ed5:	48 c1 e9 09          	shr    $0x9,%rcx
    6ed9:	48 31 c8             	xor    %rcx,%rax
    6edc:	0f b6 c8             	movzbl %al,%ecx
    6edf:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6ee6:	00 
    6ee7:	48 85 c0             	test   %rax,%rax
    6eea:	75 1d                	jne    6f09 <fwp_drop0+0x129>
    6eec:	eb 56                	jmp    6f44 <fwp_drop0+0x164>
    6eee:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6ef5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6efc:	00 00 00 00 
    6f00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6f04:	48 85 c0             	test   %rax,%rax
    6f07:	74 3b                	je     6f44 <fwp_drop0+0x164>
    6f09:	48 89 c1             	mov    %rax,%rcx
    6f0c:	48 39 10             	cmp    %rdx,(%rax)
    6f0f:	75 ef                	jne    6f00 <fwp_drop0+0x120>
    6f11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6f15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6f19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6f1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6f24:	0f 85 3e ff ff ff    	jne    6e68 <fwp_drop0+0x88>
    6f2a:	48 89 d7             	mov    %rdx,%rdi
    6f2d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6f32:	e8 99 e8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    6f37:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6f3c:	c6 02 fe             	movb   $0xfe,(%rdx)
    6f3f:	e9 24 ff ff ff       	jmp    6e68 <fwp_drop0+0x88>
    6f44:	48 8d 3d 95 6a 00 00 	lea    0x6a95(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    6f4b:	e8 00 d5 ff ff       	call   4450 <fwp_trap>

0000000000006f50 <fwp_arg_drop12>:
    6f50:	f3 0f 1e fa          	endbr64
    6f54:	85 f6                	test   %esi,%esi
    6f56:	75 04                	jne    6f5c <fwp_arg_drop12+0xc>
    6f58:	85 d2                	test   %edx,%edx
    6f5a:	75 04                	jne    6f60 <fwp_arg_drop12+0x10>
    6f5c:	c3                   	ret
    6f5d:	0f 1f 00             	nopl   (%rax)
    6f60:	48 8b 3f             	mov    (%rdi),%rdi
    6f63:	e9 78 fe ff ff       	jmp    6de0 <fwp_drop0>
    6f68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6f6f:	00 

0000000000006f70 <fwp_drop1>:
    6f70:	f3 0f 1e fa          	endbr64
    6f74:	48 8b 15 9d 3c 06 00 	mov    0x63c9d(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    6f7b:	48 89 f8             	mov    %rdi,%rax
    6f7e:	48 2b 05 6b 3c 06 00 	sub    0x63c6b(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    6f85:	48 c1 e2 10          	shl    $0x10,%rdx
    6f89:	48 39 d0             	cmp    %rdx,%rax
    6f8c:	0f 83 be 00 00 00    	jae    7050 <fwp_drop1+0xe0>
    6f92:	48 83 ec 18          	sub    $0x18,%rsp
    6f96:	4c 8d 05 a3 28 06 00 	lea    0x628a3(%rip),%r8        # 69840 <fwp_heap>
    6f9d:	48 89 c2             	mov    %rax,%rdx
    6fa0:	48 c1 ea 10          	shr    $0x10,%rdx
    6fa4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6fa8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6faf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6fb3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6fb7:	48 85 d2             	test   %rdx,%rdx
    6fba:	74 3c                	je     6ff8 <fwp_drop1+0x88>
    6fbc:	0f b6 31             	movzbl (%rcx),%esi
    6fbf:	40 80 fe 02          	cmp    $0x2,%sil
    6fc3:	74 3b                	je     7000 <fwp_drop1+0x90>
    6fc5:	40 80 fe 01          	cmp    $0x1,%sil
    6fc9:	75 2d                	jne    6ff8 <fwp_drop1+0x88>
    6fcb:	8b 71 18             	mov    0x18(%rcx),%esi
    6fce:	0f b7 c0             	movzwl %ax,%eax
    6fd1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6fd4:	48 0f af c6          	imul   %rsi,%rax
    6fd8:	48 c1 e8 20          	shr    $0x20,%rax
    6fdc:	48 39 c8             	cmp    %rcx,%rax
    6fdf:	73 17                	jae    6ff8 <fwp_drop1+0x88>
    6fe1:	48 01 c2             	add    %rax,%rdx
    6fe4:	0f b6 02             	movzbl (%rdx),%eax
    6fe7:	84 c0                	test   %al,%al
    6fe9:	74 0d                	je     6ff8 <fwp_drop1+0x88>
    6feb:	3c 01                	cmp    $0x1,%al
    6fed:	74 21                	je     7010 <fwp_drop1+0xa0>
    6fef:	3c ff                	cmp    $0xff,%al
    6ff1:	74 65                	je     7058 <fwp_drop1+0xe8>
    6ff3:	83 e8 01             	sub    $0x1,%eax
    6ff6:	88 02                	mov    %al,(%rdx)
    6ff8:	48 83 c4 18          	add    $0x18,%rsp
    6ffc:	c3                   	ret
    6ffd:	0f 1f 00             	nopl   (%rax)
    7000:	66 85 c0             	test   %ax,%ax
    7003:	74 df                	je     6fe4 <fwp_drop1+0x74>
    7005:	48 83 c4 18          	add    $0x18,%rsp
    7009:	c3                   	ret
    700a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7010:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    7014:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7019:	e8 92 fa ff ff       	call   6ab0 <fwp_rc_free_arr>
    701e:	4c 8d 05 1b 28 06 00 	lea    0x6281b(%rip),%r8        # 69840 <fwp_heap>
    7025:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    702a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7031:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7038:	48 c1 e2 10          	shl    $0x10,%rdx
    703c:	48 39 d0             	cmp    %rdx,%rax
    703f:	73 b7                	jae    6ff8 <fwp_drop1+0x88>
    7041:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7046:	e9 52 ff ff ff       	jmp    6f9d <fwp_drop1+0x2d>
    704b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7050:	c3                   	ret
    7051:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7058:	48 89 d0             	mov    %rdx,%rax
    705b:	48 c1 e8 11          	shr    $0x11,%rax
    705f:	48 31 d0             	xor    %rdx,%rax
    7062:	48 89 c1             	mov    %rax,%rcx
    7065:	48 c1 e9 09          	shr    $0x9,%rcx
    7069:	48 31 c8             	xor    %rcx,%rax
    706c:	0f b6 c8             	movzbl %al,%ecx
    706f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7076:	00 
    7077:	48 85 c0             	test   %rax,%rax
    707a:	75 0d                	jne    7089 <fwp_drop1+0x119>
    707c:	eb 46                	jmp    70c4 <fwp_drop1+0x154>
    707e:	66 90                	xchg   %ax,%ax
    7080:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7084:	48 85 c0             	test   %rax,%rax
    7087:	74 3b                	je     70c4 <fwp_drop1+0x154>
    7089:	48 89 c1             	mov    %rax,%rcx
    708c:	48 39 10             	cmp    %rdx,(%rax)
    708f:	75 ef                	jne    7080 <fwp_drop1+0x110>
    7091:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7095:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7099:	48 89 48 08          	mov    %rcx,0x8(%rax)
    709d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    70a4:	0f 85 4e ff ff ff    	jne    6ff8 <fwp_drop1+0x88>
    70aa:	48 89 d7             	mov    %rdx,%rdi
    70ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    70b2:	e8 19 e7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    70b7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    70bc:	c6 02 fe             	movb   $0xfe,(%rdx)
    70bf:	e9 34 ff ff ff       	jmp    6ff8 <fwp_drop1+0x88>
    70c4:	48 8d 3d 15 69 00 00 	lea    0x6915(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    70cb:	e8 80 d3 ff ff       	call   4450 <fwp_trap>

00000000000070d0 <fwp_closure_drop>:
    70d0:	48 8b 15 41 3b 06 00 	mov    0x63b41(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    70d7:	48 89 f8             	mov    %rdi,%rax
    70da:	48 2b 05 0f 3b 06 00 	sub    0x63b0f(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    70e1:	48 c1 e2 10          	shl    $0x10,%rdx
    70e5:	48 39 d0             	cmp    %rdx,%rax
    70e8:	73 6b                	jae    7155 <fwp_closure_drop+0x85>
    70ea:	48 89 c2             	mov    %rax,%rdx
    70ed:	48 c1 ea 10          	shr    $0x10,%rdx
    70f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    70f5:	48 8b 15 3c 3b 06 00 	mov    0x63b3c(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    70fc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7100:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7104:	48 85 d2             	test   %rdx,%rdx
    7107:	74 4c                	je     7155 <fwp_closure_drop+0x85>
    7109:	0f b6 31             	movzbl (%rcx),%esi
    710c:	40 80 fe 02          	cmp    $0x2,%sil
    7110:	74 3e                	je     7150 <fwp_closure_drop+0x80>
    7112:	40 80 fe 01          	cmp    $0x1,%sil
    7116:	75 3d                	jne    7155 <fwp_closure_drop+0x85>
    7118:	8b 71 18             	mov    0x18(%rcx),%esi
    711b:	0f b7 c0             	movzwl %ax,%eax
    711e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7121:	48 0f af c6          	imul   %rsi,%rax
    7125:	48 c1 e8 20          	shr    $0x20,%rax
    7129:	48 39 c8             	cmp    %rcx,%rax
    712c:	73 27                	jae    7155 <fwp_closure_drop+0x85>
    712e:	48 01 c2             	add    %rax,%rdx
    7131:	0f b6 02             	movzbl (%rdx),%eax
    7134:	84 c0                	test   %al,%al
    7136:	74 1d                	je     7155 <fwp_closure_drop+0x85>
    7138:	3c 01                	cmp    $0x1,%al
    713a:	74 24                	je     7160 <fwp_closure_drop+0x90>
    713c:	3c ff                	cmp    $0xff,%al
    713e:	74 48                	je     7188 <fwp_closure_drop+0xb8>
    7140:	83 e8 01             	sub    $0x1,%eax
    7143:	88 02                	mov    %al,(%rdx)
    7145:	c3                   	ret
    7146:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    714d:	00 00 00 
    7150:	66 85 c0             	test   %ax,%ax
    7153:	74 dc                	je     7131 <fwp_closure_drop+0x61>
    7155:	c3                   	ret
    7156:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    715d:	00 00 00 
    7160:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    7167:	ff ff 
    7169:	48 85 c0             	test   %rax,%rax
    716c:	74 12                	je     7180 <fwp_closure_drop+0xb0>
    716e:	48 89 fe             	mov    %rdi,%rsi
    7171:	48 89 c7             	mov    %rax,%rdi
    7174:	e9 37 d3 ff ff       	jmp    44b0 <fwp_closure_drop_push>
    7179:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7180:	e9 db d4 ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    7185:	0f 1f 00             	nopl   (%rax)
    7188:	48 89 d0             	mov    %rdx,%rax
    718b:	48 8d 35 ae 26 06 00 	lea    0x626ae(%rip),%rsi        # 69840 <fwp_heap>
    7192:	48 83 ec 18          	sub    $0x18,%rsp
    7196:	48 c1 e8 11          	shr    $0x11,%rax
    719a:	48 31 d0             	xor    %rdx,%rax
    719d:	48 89 c1             	mov    %rax,%rcx
    71a0:	48 c1 e9 09          	shr    $0x9,%rcx
    71a4:	48 31 c8             	xor    %rcx,%rax
    71a7:	0f b6 c8             	movzbl %al,%ecx
    71aa:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    71b1:	00 
    71b2:	48 85 c0             	test   %rax,%rax
    71b5:	75 12                	jne    71c9 <fwp_closure_drop+0xf9>
    71b7:	eb 49                	jmp    7202 <fwp_closure_drop+0x132>
    71b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    71c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    71c4:	48 85 c0             	test   %rax,%rax
    71c7:	74 39                	je     7202 <fwp_closure_drop+0x132>
    71c9:	48 89 c1             	mov    %rax,%rcx
    71cc:	48 39 10             	cmp    %rdx,(%rax)
    71cf:	75 ef                	jne    71c0 <fwp_closure_drop+0xf0>
    71d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    71d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    71d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    71dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    71e4:	74 05                	je     71eb <fwp_closure_drop+0x11b>
    71e6:	48 83 c4 18          	add    $0x18,%rsp
    71ea:	c3                   	ret
    71eb:	48 89 d7             	mov    %rdx,%rdi
    71ee:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    71f3:	e8 d8 e5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    71f8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    71fd:	c6 02 fe             	movb   $0xfe,(%rdx)
    7200:	eb e4                	jmp    71e6 <fwp_closure_drop+0x116>
    7202:	48 8d 3d d7 67 00 00 	lea    0x67d7(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    7209:	e8 42 d2 ff ff       	call   4450 <fwp_trap>
    720e:	66 90                	xchg   %ax,%ax

0000000000007210 <fwp_owned_tape_release>:
    7210:	48 85 ff             	test   %rdi,%rdi
    7213:	0f 84 f7 00 00 00    	je     7310 <fwp_owned_tape_release+0x100>
    7219:	41 54                	push   %r12
    721b:	55                   	push   %rbp
    721c:	53                   	push   %rbx
    721d:	48 8b 07             	mov    (%rdi),%rax
    7220:	48 85 c0             	test   %rax,%rax
    7223:	74 08                	je     722d <fwp_owned_tape_release+0x1d>
    7225:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7229:	48 89 50 08          	mov    %rdx,0x8(%rax)
    722d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7231:	48 85 d2             	test   %rdx,%rdx
    7234:	74 03                	je     7239 <fwp_owned_tape_release+0x29>
    7236:	48 89 02             	mov    %rax,(%rdx)
    7239:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    723d:	48 89 fb             	mov    %rdi,%rbx
    7240:	48 8b 42 68          	mov    0x68(%rdx),%rax
    7244:	48 85 c0             	test   %rax,%rax
    7247:	0f 84 89 00 00 00    	je     72d6 <fwp_owned_tape_release+0xc6>
    724d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    7251:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    7255:	7e 47                	jle    729e <fwp_owned_tape_release+0x8e>
    7257:	31 ed                	xor    %ebp,%ebp
    7259:	eb 0d                	jmp    7268 <fwp_owned_tape_release+0x58>
    725b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7260:	48 8b 43 10          	mov    0x10(%rbx),%rax
    7264:	48 8b 40 68          	mov    0x68(%rax),%rax
    7268:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    726c:	49 89 ec             	mov    %rbp,%r12
    726f:	48 83 c5 01          	add    $0x1,%rbp
    7273:	49 c1 e4 04          	shl    $0x4,%r12
    7277:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    727b:	ff d0                	call   *%rax
    727d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    7281:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    7286:	48 8b 43 10          	mov    0x10(%rbx),%rax
    728a:	ff 50 68             	call   *0x68(%rax)
    728d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    7291:	48 2b 43 50          	sub    0x50(%rbx),%rax
    7295:	48 39 e8             	cmp    %rbp,%rax
    7298:	7f c6                	jg     7260 <fwp_owned_tape_release+0x50>
    729a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    729e:	31 ed                	xor    %ebp,%ebp
    72a0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    72a5:	7e 28                	jle    72cf <fwp_owned_tape_release+0xbf>
    72a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    72ae:	00 00 
    72b0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    72b4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    72b8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    72bc:	74 07                	je     72c5 <fwp_owned_tape_release+0xb5>
    72be:	ff 52 68             	call   *0x68(%rdx)
    72c1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    72c5:	48 83 c5 01          	add    $0x1,%rbp
    72c9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    72cd:	7f e1                	jg     72b0 <fwp_owned_tape_release+0xa0>
    72cf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    72d3:	ff 52 68             	call   *0x68(%rdx)
    72d6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    72da:	e8 f1 fd ff ff       	call   70d0 <fwp_closure_drop>
    72df:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    72e3:	e8 e8 fd ff ff       	call   70d0 <fwp_closure_drop>
    72e8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    72ec:	e8 df fd ff ff       	call   70d0 <fwp_closure_drop>
    72f1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    72f5:	e8 16 e7 ff ff       	call   5a10 <fwp_mem_free>
    72fa:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    72fe:	e8 0d e7 ff ff       	call   5a10 <fwp_mem_free>
    7303:	48 89 df             	mov    %rbx,%rdi
    7306:	5b                   	pop    %rbx
    7307:	5d                   	pop    %rbp
    7308:	41 5c                	pop    %r12
    730a:	e9 01 e7 ff ff       	jmp    5a10 <fwp_mem_free>
    730f:	90                   	nop
    7310:	c3                   	ret
    7311:	0f 1f 40 00          	nopl   0x0(%rax)
    7315:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    731c:	00 00 00 00 

0000000000007320 <fwp_tape_finish>:
    7320:	f3 0f 1e fa          	endbr64
    7324:	41 55                	push   %r13
    7326:	41 54                	push   %r12
    7328:	55                   	push   %rbp
    7329:	53                   	push   %rbx
    732a:	48 83 ec 48          	sub    $0x48,%rsp
    732e:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    7335:	00 00 
    7337:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    733c:	48 8d 3d 7d 9d 01 00 	lea    0x19d7d(%rip),%rdi        # 210c0 <fwp_tape_workspace>
    7343:	e8 f8 dd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7348:	48 83 3d b8 9d 01 00 	cmpq   $0x0,0x19db8(%rip)        # 21108 <fwp_ntapes>
    734f:	00 
    7350:	48 c7 05 4d 9d 01 00 	movq   $0x0,0x19d4d(%rip)        # 210a8 <fwp_tape_cached_bytes>
    7357:	00 00 00 00 
    735b:	7e 79                	jle    73d6 <fwp_tape_finish+0xb6>
    735d:	45 31 e4             	xor    %r12d,%r12d
    7360:	31 ed                	xor    %ebp,%ebp
    7362:	0f 1f 00             	nopl   (%rax)
    7365:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    736c:	00 00 00 00 
    7370:	48 8b 1d 99 9d 01 00 	mov    0x19d99(%rip),%rbx        # 21110 <fwp_tapes>
    7377:	48 83 c5 01          	add    $0x1,%rbp
    737b:	4c 01 e3             	add    %r12,%rbx
    737e:	49 83 c4 68          	add    $0x68,%r12
    7382:	48 89 df             	mov    %rbx,%rdi
    7385:	e8 06 c9 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    738a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    738f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    7394:	48 89 e7             	mov    %rsp,%rdi
    7397:	48 8b 43 40          	mov    0x40(%rbx),%rax
    739b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    739f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    73a4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    73a9:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    73ae:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    73b2:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    73b7:	e8 84 dd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    73bc:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    73c0:	e8 4b fe ff ff       	call   7210 <fwp_owned_tape_release>
    73c5:	48 39 2d 3c 9d 01 00 	cmp    %rbp,0x19d3c(%rip)        # 21108 <fwp_ntapes>
    73cc:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    73d3:	00 
    73d4:	7f 9a                	jg     7370 <fwp_tape_finish+0x50>
    73d6:	48 8b 3d 33 9d 01 00 	mov    0x19d33(%rip),%rdi        # 21110 <fwp_tapes>
    73dd:	48 85 ff             	test   %rdi,%rdi
    73e0:	74 05                	je     73e7 <fwp_tape_finish+0xc7>
    73e2:	e8 e9 dc ff ff       	call   50d0 <ad_raw_free.part.0>
    73e7:	48 c7 05 1e 9d 01 00 	movq   $0x0,0x19d1e(%rip)        # 21110 <fwp_tapes>
    73ee:	00 00 00 00 
    73f2:	48 c7 05 03 9d 01 00 	movq   $0x0,0x19d03(%rip)        # 21100 <fwp_tapes_cap>
    73f9:	00 00 00 00 
    73fd:	48 c7 05 00 9d 01 00 	movq   $0x0,0x19d00(%rip)        # 21108 <fwp_ntapes>
    7404:	00 00 00 00 
    7408:	48 c7 05 e5 9c 01 00 	movq   $0x0,0x19ce5(%rip)        # 210f8 <fwp_tape_next_slot>
    740f:	00 00 00 00 
    7413:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7418:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    741f:	00 00 
    7421:	75 0b                	jne    742e <fwp_tape_finish+0x10e>
    7423:	48 83 c4 48          	add    $0x48,%rsp
    7427:	5b                   	pop    %rbx
    7428:	5d                   	pop    %rbp
    7429:	41 5c                	pop    %r12
    742b:	41 5d                	pop    %r13
    742d:	c3                   	ret
    742e:	e8 1d c0 ff ff       	call   3450 <__stack_chk_fail@plt>
    7433:	66 90                	xchg   %ax,%ax
    7435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    743c:	00 00 00 00 

0000000000007440 <fwp_tape_scope_release>:
    7440:	f3 0f 1e fa          	endbr64
    7444:	41 55                	push   %r13
    7446:	41 54                	push   %r12
    7448:	55                   	push   %rbp
    7449:	53                   	push   %rbx
    744a:	48 83 ec 48          	sub    $0x48,%rsp
    744e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7455:	00 00 
    7457:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    745c:	48 63 07             	movslq (%rdi),%rax
    745f:	85 c0                	test   %eax,%eax
    7461:	0f 88 e8 00 00 00    	js     754f <fwp_tape_scope_release+0x10f>
    7467:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    746e:	ec c4 4e 
    7471:	48 89 fb             	mov    %rdi,%rbx
    7474:	48 89 e5             	mov    %rsp,%rbp
    7477:	eb 1f                	jmp    7498 <fwp_tape_scope_release+0x58>
    7479:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7480:	e8 bb dc ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7485:	4c 89 ef             	mov    %r13,%rdi
    7488:	e8 83 fd ff ff       	call   7210 <fwp_owned_tape_release>
    748d:	48 63 03             	movslq (%rbx),%rax
    7490:	85 c0                	test   %eax,%eax
    7492:	0f 88 b7 00 00 00    	js     754f <fwp_tape_scope_release+0x10f>
    7498:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    749c:	48 8b 35 6d 9c 01 00 	mov    0x19c6d(%rip),%rsi        # 21110 <fwp_tapes>
    74a3:	4c 01 c6             	add    %r8,%rsi
    74a6:	48 89 f7             	mov    %rsi,%rdi
    74a9:	e8 e2 c7 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    74ae:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    74b3:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    74b8:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    74bf:	48 8b 46 40          	mov    0x40(%rsi),%rax
    74c3:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    74c7:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    74ce:	00 
    74cf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    74d4:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    74d9:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    74dd:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    74e2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    74e6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    74eb:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    74f2:	00 
    74f3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    74fa:	00 
    74fb:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7502:	00 
    7503:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    7507:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    750b:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    750f:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    7513:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7519:	77 18                	ja     7533 <fwp_tape_scope_release+0xf3>
    751b:	49 c1 f8 03          	sar    $0x3,%r8
    751f:	4d 0f af c4          	imul   %r12,%r8
    7523:	4c 3b 05 ce 9b 01 00 	cmp    0x19bce(%rip),%r8        # 210f8 <fwp_tape_next_slot>
    752a:	7d 07                	jge    7533 <fwp_tape_scope_release+0xf3>
    752c:	4c 89 05 c5 9b 01 00 	mov    %r8,0x19bc5(%rip)        # 210f8 <fwp_tape_next_slot>
    7533:	48 89 ef             	mov    %rbp,%rdi
    7536:	4d 85 ed             	test   %r13,%r13
    7539:	0f 85 41 ff ff ff    	jne    7480 <fwp_tape_scope_release+0x40>
    753f:	e8 1c dd ff ff       	call   5260 <fwp_tape_buffers_release>
    7544:	48 63 03             	movslq (%rbx),%rax
    7547:	85 c0                	test   %eax,%eax
    7549:	0f 89 49 ff ff ff    	jns    7498 <fwp_tape_scope_release+0x58>
    754f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7554:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    755b:	00 00 
    755d:	75 0b                	jne    756a <fwp_tape_scope_release+0x12a>
    755f:	48 83 c4 48          	add    $0x48,%rsp
    7563:	5b                   	pop    %rbx
    7564:	5d                   	pop    %rbp
    7565:	41 5c                	pop    %r12
    7567:	41 5d                	pop    %r13
    7569:	c3                   	ret
    756a:	e8 e1 be ff ff       	call   3450 <__stack_chk_fail@plt>
    756f:	90                   	nop

0000000000007570 <fwp_task_dispose>:
    7570:	53                   	push   %rbx
    7571:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7575:	0f 84 cb c1 ff ff    	je     3746 <fwp_task_dispose.cold>
    757b:	48 89 fb             	mov    %rdi,%rbx
    757e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7583:	0f 85 bd c1 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7589:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    758d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7594:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    759b:	00 
    759c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    75a0:	48 85 ff             	test   %rdi,%rdi
    75a3:	74 07                	je     75ac <fwp_task_dispose+0x3c>
    75a5:	48 85 c0             	test   %rax,%rax
    75a8:	74 02                	je     75ac <fwp_task_dispose+0x3c>
    75aa:	ff d0                	call   *%rax
    75ac:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    75b3:	e8 58 e4 ff ff       	call   5a10 <fwp_mem_free>
    75b8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    75bf:	00 00 00 00 
    75c3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    75c7:	74 6f                	je     7638 <fwp_task_dispose+0xc8>
    75c9:	48 8b 15 48 36 06 00 	mov    0x63648(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    75d0:	48 89 d8             	mov    %rbx,%rax
    75d3:	48 2b 05 16 36 06 00 	sub    0x63616(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    75da:	48 c1 e2 10          	shl    $0x10,%rdx
    75de:	48 39 d0             	cmp    %rdx,%rax
    75e1:	73 4c                	jae    762f <fwp_task_dispose+0xbf>
    75e3:	48 89 c2             	mov    %rax,%rdx
    75e6:	48 c1 ea 10          	shr    $0x10,%rdx
    75ea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    75ee:	48 8b 15 43 36 06 00 	mov    0x63643(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    75f5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    75f9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    75fd:	48 85 c9             	test   %rcx,%rcx
    7600:	74 2d                	je     762f <fwp_task_dispose+0xbf>
    7602:	0f b6 32             	movzbl (%rdx),%esi
    7605:	40 80 fe 02          	cmp    $0x2,%sil
    7609:	74 3d                	je     7648 <fwp_task_dispose+0xd8>
    760b:	40 80 fe 01          	cmp    $0x1,%sil
    760f:	75 1e                	jne    762f <fwp_task_dispose+0xbf>
    7611:	8b 72 18             	mov    0x18(%rdx),%esi
    7614:	0f b7 c0             	movzwl %ax,%eax
    7617:	8b 52 1c             	mov    0x1c(%rdx),%edx
    761a:	48 0f af c6          	imul   %rsi,%rax
    761e:	48 c1 e8 20          	shr    $0x20,%rax
    7622:	48 39 d0             	cmp    %rdx,%rax
    7625:	73 08                	jae    762f <fwp_task_dispose+0xbf>
    7627:	48 01 c1             	add    %rax,%rcx
    762a:	80 39 01             	cmpb   $0x1,(%rcx)
    762d:	74 09                	je     7638 <fwp_task_dispose+0xc8>
    762f:	5b                   	pop    %rbx
    7630:	c3                   	ret
    7631:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7638:	48 89 df             	mov    %rbx,%rdi
    763b:	5b                   	pop    %rbx
    763c:	e9 cf e3 ff ff       	jmp    5a10 <fwp_mem_free>
    7641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7648:	66 85 c0             	test   %ax,%ax
    764b:	74 dd                	je     762a <fwp_task_dispose+0xba>
    764d:	5b                   	pop    %rbx
    764e:	c3                   	ret
    764f:	90                   	nop

0000000000007650 <fwp_free_zombie>:
    7650:	48 8b 15 b9 21 06 00 	mov    0x621b9(%rip),%rdx        # 69810 <fwp_zombie>
    7657:	48 85 d2             	test   %rdx,%rdx
    765a:	0f 84 98 00 00 00    	je     76f8 <fwp_free_zombie+0xa8>
    7660:	48 3b 15 b9 21 06 00 	cmp    0x621b9(%rip),%rdx        # 69820 <fwp_cur>
    7667:	0f 84 8b 00 00 00    	je     76f8 <fwp_free_zombie+0xa8>
    766d:	48 83 ec 18          	sub    $0x18,%rsp
    7671:	48 63 05 7c 1b 06 00 	movslq 0x61b7c(%rip),%rax        # 691f4 <fwp_stack_pool_n>
    7678:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    767c:	83 f8 3f             	cmp    $0x3f,%eax
    767f:	7f 7f                	jg     7700 <fwp_free_zombie+0xb0>
    7681:	8d 48 01             	lea    0x1(%rax),%ecx
    7684:	89 0d 6a 1b 06 00    	mov    %ecx,0x61b6a(%rip)        # 691f4 <fwp_stack_pool_n>
    768a:	48 8d 0d 6f 1b 06 00 	lea    0x61b6f(%rip),%rcx        # 69200 <fwp_stack_pool>
    7691:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7695:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    769c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    76a0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    76a7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    76ab:	48 85 c9             	test   %rcx,%rcx
    76ae:	0f 84 fc 00 00 00    	je     77b0 <fwp_free_zombie+0x160>
    76b4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    76bb:	48 85 c0             	test   %rax,%rax
    76be:	74 07                	je     76c7 <fwp_free_zombie+0x77>
    76c0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    76c7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    76ca:	66 0f ef c0          	pxor   %xmm0,%xmm0
    76ce:	48 c7 05 37 21 06 00 	movq   $0x0,0x62137(%rip)        # 69810 <fwp_zombie>
    76d5:	00 00 00 00 
    76d9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    76e0:	85 c0                	test   %eax,%eax
    76e2:	74 34                	je     7718 <fwp_free_zombie+0xc8>
    76e4:	83 f8 01             	cmp    $0x1,%eax
    76e7:	0f 84 b3 00 00 00    	je     77a0 <fwp_free_zombie+0x150>
    76ed:	48 83 c4 18          	add    $0x18,%rsp
    76f1:	c3                   	ret
    76f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    76f8:	c3                   	ret
    76f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7700:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7704:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7709:	e8 b2 be ff ff       	call   35c0 <munmap@plt>
    770e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7713:	eb 80                	jmp    7695 <fwp_free_zombie+0x45>
    7715:	0f 1f 00             	nopl   (%rax)
    7718:	48 8b 0d f9 34 06 00 	mov    0x634f9(%rip),%rcx        # 6ac18 <fwp_heap+0x13d8>
    771f:	48 89 d0             	mov    %rdx,%rax
    7722:	48 2b 05 c7 34 06 00 	sub    0x634c7(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    7729:	48 c1 e1 10          	shl    $0x10,%rcx
    772d:	48 39 c8             	cmp    %rcx,%rax
    7730:	73 bb                	jae    76ed <fwp_free_zombie+0x9d>
    7732:	48 89 c1             	mov    %rax,%rcx
    7735:	48 c1 e9 10          	shr    $0x10,%rcx
    7739:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    773d:	48 8b 0d f4 34 06 00 	mov    0x634f4(%rip),%rcx        # 6ac38 <fwp_heap+0x13f8>
    7744:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7748:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    774c:	48 85 c9             	test   %rcx,%rcx
    774f:	74 9c                	je     76ed <fwp_free_zombie+0x9d>
    7751:	0f b6 3e             	movzbl (%rsi),%edi
    7754:	40 80 ff 02          	cmp    $0x2,%dil
    7758:	74 66                	je     77c0 <fwp_free_zombie+0x170>
    775a:	40 80 ff 01          	cmp    $0x1,%dil
    775e:	75 8d                	jne    76ed <fwp_free_zombie+0x9d>
    7760:	8b 7e 18             	mov    0x18(%rsi),%edi
    7763:	0f b7 c0             	movzwl %ax,%eax
    7766:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7769:	48 0f af c7          	imul   %rdi,%rax
    776d:	48 c1 e8 20          	shr    $0x20,%rax
    7771:	48 39 f0             	cmp    %rsi,%rax
    7774:	0f 83 73 ff ff ff    	jae    76ed <fwp_free_zombie+0x9d>
    777a:	48 01 c1             	add    %rax,%rcx
    777d:	0f b6 01             	movzbl (%rcx),%eax
    7780:	84 c0                	test   %al,%al
    7782:	0f 84 65 ff ff ff    	je     76ed <fwp_free_zombie+0x9d>
    7788:	3c 01                	cmp    $0x1,%al
    778a:	74 14                	je     77a0 <fwp_free_zombie+0x150>
    778c:	3c ff                	cmp    $0xff,%al
    778e:	74 3b                	je     77cb <fwp_free_zombie+0x17b>
    7790:	83 e8 01             	sub    $0x1,%eax
    7793:	88 01                	mov    %al,(%rcx)
    7795:	e9 53 ff ff ff       	jmp    76ed <fwp_free_zombie+0x9d>
    779a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    77a0:	48 89 d7             	mov    %rdx,%rdi
    77a3:	48 83 c4 18          	add    $0x18,%rsp
    77a7:	e9 c4 fd ff ff       	jmp    7570 <fwp_task_dispose>
    77ac:	0f 1f 40 00          	nopl   0x0(%rax)
    77b0:	48 89 05 31 20 06 00 	mov    %rax,0x62031(%rip)        # 697e8 <fwp_tasks_active>
    77b7:	e9 ff fe ff ff       	jmp    76bb <fwp_free_zombie+0x6b>
    77bc:	0f 1f 40 00          	nopl   0x0(%rax)
    77c0:	66 85 c0             	test   %ax,%ax
    77c3:	0f 85 24 ff ff ff    	jne    76ed <fwp_free_zombie+0x9d>
    77c9:	eb b2                	jmp    777d <fwp_free_zombie+0x12d>
    77cb:	48 89 ca             	mov    %rcx,%rdx
    77ce:	48 8d 35 6b 20 06 00 	lea    0x6206b(%rip),%rsi        # 69840 <fwp_heap>
    77d5:	48 c1 ea 11          	shr    $0x11,%rdx
    77d9:	48 31 ca             	xor    %rcx,%rdx
    77dc:	48 89 d0             	mov    %rdx,%rax
    77df:	48 c1 e8 09          	shr    $0x9,%rax
    77e3:	48 31 c2             	xor    %rax,%rdx
    77e6:	0f b6 d2             	movzbl %dl,%edx
    77e9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    77f0:	00 
    77f1:	48 85 c0             	test   %rax,%rax
    77f4:	75 13                	jne    7809 <fwp_free_zombie+0x1b9>
    77f6:	eb 4c                	jmp    7844 <fwp_free_zombie+0x1f4>
    77f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    77ff:	00 
    7800:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7804:	48 85 c0             	test   %rax,%rax
    7807:	74 3b                	je     7844 <fwp_free_zombie+0x1f4>
    7809:	48 89 c2             	mov    %rax,%rdx
    780c:	48 39 08             	cmp    %rcx,(%rax)
    780f:	75 ef                	jne    7800 <fwp_free_zombie+0x1b0>
    7811:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7815:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7819:	48 89 50 08          	mov    %rdx,0x8(%rax)
    781d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7824:	0f 85 c3 fe ff ff    	jne    76ed <fwp_free_zombie+0x9d>
    782a:	48 89 cf             	mov    %rcx,%rdi
    782d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7832:	e8 99 df ff ff       	call   57d0 <fwp_rc_forget_slot>
    7837:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    783c:	c6 01 fe             	movb   $0xfe,(%rcx)
    783f:	e9 a9 fe ff ff       	jmp    76ed <fwp_free_zombie+0x9d>
    7844:	48 8d 3d 95 61 00 00 	lea    0x6195(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    784b:	e8 00 cc ff ff       	call   4450 <fwp_trap>

0000000000007850 <fwp_block>:
    7850:	48 83 ec 08          	sub    $0x8,%rsp
    7854:	48 8b 05 ad 1f 06 00 	mov    0x61fad(%rip),%rax        # 69808 <fwp_ready_head>
    785b:	48 85 c0             	test   %rax,%rax
    785e:	0f 84 1c 01 00 00    	je     7980 <fwp_block+0x130>
    7864:	90                   	nop
    7865:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    786c:	00 00 00 00 
    7870:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7877:	48 89 15 8a 1f 06 00 	mov    %rdx,0x61f8a(%rip)        # 69808 <fwp_ready_head>
    787e:	48 85 d2             	test   %rdx,%rdx
    7881:	0f 84 19 01 00 00    	je     79a0 <fwp_block+0x150>
    7887:	48 8b 15 92 1f 06 00 	mov    0x61f92(%rip),%rdx        # 69820 <fwp_cur>
    788e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7892:	48 39 c2             	cmp    %rax,%rdx
    7895:	0f 84 d5 00 00 00    	je     7970 <fwp_block+0x120>
    789b:	48 8b 0d 06 3c 06 00 	mov    0x63c06(%rip),%rcx        # 6b4a8 <fwp_state_owners>
    78a2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    78a6:	48 89 05 73 1f 06 00 	mov    %rax,0x61f73(%rip)        # 69820 <fwp_cur>
    78ad:	f3 0f 7e 05 1b 3c 06 	movq   0x63c1b(%rip),%xmm0        # 6b4d0 <fwp_foreign_callbacks>
    78b4:	00 
    78b5:	0f 16 05 04 3c 06 00 	movhps 0x63c04(%rip),%xmm0        # 6b4c0 <fwp_state>
    78bc:	f3 0f 7e 0d 04 3c 06 	movq   0x63c04(%rip),%xmm1        # 6b4c8 <fwp_handlers>
    78c3:	00 
    78c4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    78cb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    78d2:	0f 16 0d ff 3b 06 00 	movhps 0x63bff(%rip),%xmm1        # 6b4d8 <fwp_cleanups>
    78d9:	f3 0f 7e 05 d7 3b 06 	movq   0x63bd7(%rip),%xmm0        # 6b4b8 <fwp_state_len>
    78e0:	00 
    78e1:	0f 16 05 c8 3b 06 00 	movhps 0x63bc8(%rip),%xmm0        # 6b4b0 <fwp_state_cap>
    78e8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    78ef:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    78f6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    78fa:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7901:	48 89 0d c0 3b 06 00 	mov    %rcx,0x63bc0(%rip)        # 6b4c8 <fwp_handlers>
    7908:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    790f:	48 89 0d c2 3b 06 00 	mov    %rcx,0x63bc2(%rip)        # 6b4d8 <fwp_cleanups>
    7916:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    791d:	48 89 0d ac 3b 06 00 	mov    %rcx,0x63bac(%rip)        # 6b4d0 <fwp_foreign_callbacks>
    7924:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    792b:	48 89 0d 8e 3b 06 00 	mov    %rcx,0x63b8e(%rip)        # 6b4c0 <fwp_state>
    7932:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7939:	48 89 0d 78 3b 06 00 	mov    %rcx,0x63b78(%rip)        # 6b4b8 <fwp_state_len>
    7940:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7947:	48 89 0d 62 3b 06 00 	mov    %rcx,0x63b62(%rip)        # 6b4b0 <fwp_state_cap>
    794e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7955:	48 89 0d 4c 3b 06 00 	mov    %rcx,0x63b4c(%rip)        # 6b4a8 <fwp_state_owners>
    795c:	e8 1f bb ff ff       	call   3480 <swapcontext@plt>
    7961:	f3 0f 1e fa          	endbr64
    7965:	e8 e6 fc ff ff       	call   7650 <fwp_free_zombie>
    796a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7970:	8b 05 7a 18 06 00    	mov    0x6187a(%rip),%eax        # 691f0 <fwp_slice>
    7976:	85 c0                	test   %eax,%eax
    7978:	74 36                	je     79b0 <fwp_block+0x160>
    797a:	48 83 c4 08          	add    $0x8,%rsp
    797e:	c3                   	ret
    797f:	90                   	nop
    7980:	e8 8b da ff ff       	call   5410 <fwp_poll_events>
    7985:	48 8b 05 7c 1e 06 00 	mov    0x61e7c(%rip),%rax        # 69808 <fwp_ready_head>
    798c:	48 85 c0             	test   %rax,%rax
    798f:	0f 85 db fe ff ff    	jne    7870 <fwp_block+0x20>
    7995:	eb e9                	jmp    7980 <fwp_block+0x130>
    7997:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    799e:	00 00 
    79a0:	48 c7 05 55 1e 06 00 	movq   $0x0,0x61e55(%rip)        # 69800 <fwp_ready_tail>
    79a7:	00 00 00 00 
    79ab:	e9 d7 fe ff ff       	jmp    7887 <fwp_block+0x37>
    79b0:	48 8d 3d 28 58 00 00 	lea    0x5828(%rip),%rdi        # d1df <_IO_stdin_used+0x1df>
    79b7:	e8 d4 b9 ff ff       	call   3390 <getenv@plt>
    79bc:	ba 10 27 00 00       	mov    $0x2710,%edx
    79c1:	48 85 c0             	test   %rax,%rax
    79c4:	74 05                	je     79cb <fwp_block+0x17b>
    79c6:	80 38 00             	cmpb   $0x0,(%rax)
    79c9:	75 0b                	jne    79d6 <fwp_block+0x186>
    79cb:	89 15 1f 18 06 00    	mov    %edx,0x6181f(%rip)        # 691f0 <fwp_slice>
    79d1:	48 83 c4 08          	add    $0x8,%rsp
    79d5:	c3                   	ret
    79d6:	ba 0a 00 00 00       	mov    $0xa,%edx
    79db:	31 f6                	xor    %esi,%esi
    79dd:	48 89 c7             	mov    %rax,%rdi
    79e0:	e8 5b bb ff ff       	call   3540 <strtoll@plt>
    79e5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    79e9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    79f0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    79f5:	0f 46 d0             	cmovbe %eax,%edx
    79f8:	eb d1                	jmp    79cb <fwp_block+0x17b>
    79fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007a00 <fwp_drop4>:
    7a00:	48 8b 15 11 32 06 00 	mov    0x63211(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    7a07:	48 89 f8             	mov    %rdi,%rax
    7a0a:	48 2b 05 df 31 06 00 	sub    0x631df(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    7a11:	48 c1 e2 10          	shl    $0x10,%rdx
    7a15:	48 39 d0             	cmp    %rdx,%rax
    7a18:	0f 83 52 01 00 00    	jae    7b70 <fwp_drop4+0x170>
    7a1e:	48 83 ec 18          	sub    $0x18,%rsp
    7a22:	4c 8d 05 17 1e 06 00 	lea    0x61e17(%rip),%r8        # 69840 <fwp_heap>
    7a29:	48 89 c2             	mov    %rax,%rdx
    7a2c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7a33:	48 c1 ea 10          	shr    $0x10,%rdx
    7a37:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7a3b:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    7a3f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7a43:	48 85 d2             	test   %rdx,%rdx
    7a46:	74 46                	je     7a8e <fwp_drop4+0x8e>
    7a48:	44 0f b6 09          	movzbl (%rcx),%r9d
    7a4c:	41 80 f9 02          	cmp    $0x2,%r9b
    7a50:	0f 84 ca 00 00 00    	je     7b20 <fwp_drop4+0x120>
    7a56:	41 80 f9 01          	cmp    $0x1,%r9b
    7a5a:	75 32                	jne    7a8e <fwp_drop4+0x8e>
    7a5c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7a60:	0f b7 c0             	movzwl %ax,%eax
    7a63:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7a66:	49 0f af c1          	imul   %r9,%rax
    7a6a:	48 c1 e8 20          	shr    $0x20,%rax
    7a6e:	48 39 c8             	cmp    %rcx,%rax
    7a71:	73 1b                	jae    7a8e <fwp_drop4+0x8e>
    7a73:	48 01 c2             	add    %rax,%rdx
    7a76:	0f b6 02             	movzbl (%rdx),%eax
    7a79:	84 c0                	test   %al,%al
    7a7b:	74 11                	je     7a8e <fwp_drop4+0x8e>
    7a7d:	3c 01                	cmp    $0x1,%al
    7a7f:	74 17                	je     7a98 <fwp_drop4+0x98>
    7a81:	3c ff                	cmp    $0xff,%al
    7a83:	0f 84 ef 00 00 00    	je     7b78 <fwp_drop4+0x178>
    7a89:	83 e8 01             	sub    $0x1,%eax
    7a8c:	88 02                	mov    %al,(%rdx)
    7a8e:	48 83 c4 18          	add    $0x18,%rsp
    7a92:	c3                   	ret
    7a93:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7a98:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    7a9c:	0f 88 8e 00 00 00    	js     7b30 <fwp_drop4+0x130>
    7aa2:	48 8b 15 6f 31 06 00 	mov    0x6316f(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    7aa9:	48 89 f8             	mov    %rdi,%rax
    7aac:	48 2b 05 3d 31 06 00 	sub    0x6313d(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    7ab3:	48 c1 e2 10          	shl    $0x10,%rdx
    7ab7:	48 39 d0             	cmp    %rdx,%rax
    7aba:	73 d2                	jae    7a8e <fwp_drop4+0x8e>
    7abc:	48 89 c2             	mov    %rax,%rdx
    7abf:	48 c1 ea 10          	shr    $0x10,%rdx
    7ac3:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7ac7:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    7acb:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7acf:	48 85 c9             	test   %rcx,%rcx
    7ad2:	74 ba                	je     7a8e <fwp_drop4+0x8e>
    7ad4:	0f b6 32             	movzbl (%rdx),%esi
    7ad7:	40 80 fe 02          	cmp    $0x2,%sil
    7adb:	74 33                	je     7b10 <fwp_drop4+0x110>
    7add:	40 80 fe 01          	cmp    $0x1,%sil
    7ae1:	75 ab                	jne    7a8e <fwp_drop4+0x8e>
    7ae3:	8b 72 18             	mov    0x18(%rdx),%esi
    7ae6:	0f b7 c0             	movzwl %ax,%eax
    7ae9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7aec:	48 0f af c6          	imul   %rsi,%rax
    7af0:	48 c1 e8 20          	shr    $0x20,%rax
    7af4:	48 39 d0             	cmp    %rdx,%rax
    7af7:	73 95                	jae    7a8e <fwp_drop4+0x8e>
    7af9:	48 01 c1             	add    %rax,%rcx
    7afc:	80 39 01             	cmpb   $0x1,(%rcx)
    7aff:	75 8d                	jne    7a8e <fwp_drop4+0x8e>
    7b01:	48 83 c4 18          	add    $0x18,%rsp
    7b05:	e9 06 df ff ff       	jmp    5a10 <fwp_mem_free>
    7b0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b10:	66 85 c0             	test   %ax,%ax
    7b13:	74 e7                	je     7afc <fwp_drop4+0xfc>
    7b15:	48 83 c4 18          	add    $0x18,%rsp
    7b19:	c3                   	ret
    7b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b20:	66 85 c0             	test   %ax,%ax
    7b23:	0f 84 4d ff ff ff    	je     7a76 <fwp_drop4+0x76>
    7b29:	48 83 c4 18          	add    $0x18,%rsp
    7b2d:	c3                   	ret
    7b2e:	66 90                	xchg   %ax,%ax
    7b30:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7b34:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7b39:	e8 72 ef ff ff       	call   6ab0 <fwp_rc_free_arr>
    7b3e:	4c 8d 05 fb 1c 06 00 	lea    0x61cfb(%rip),%r8        # 69840 <fwp_heap>
    7b45:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7b4a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7b51:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7b58:	48 c1 e2 10          	shl    $0x10,%rdx
    7b5c:	48 39 d0             	cmp    %rdx,%rax
    7b5f:	0f 83 29 ff ff ff    	jae    7a8e <fwp_drop4+0x8e>
    7b65:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7b6a:	e9 ba fe ff ff       	jmp    7a29 <fwp_drop4+0x29>
    7b6f:	90                   	nop
    7b70:	c3                   	ret
    7b71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7b78:	48 89 d0             	mov    %rdx,%rax
    7b7b:	48 c1 e8 11          	shr    $0x11,%rax
    7b7f:	48 31 d0             	xor    %rdx,%rax
    7b82:	48 89 c1             	mov    %rax,%rcx
    7b85:	48 c1 e9 09          	shr    $0x9,%rcx
    7b89:	48 31 c8             	xor    %rcx,%rax
    7b8c:	0f b6 c8             	movzbl %al,%ecx
    7b8f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7b96:	00 
    7b97:	48 85 c0             	test   %rax,%rax
    7b9a:	75 0d                	jne    7ba9 <fwp_drop4+0x1a9>
    7b9c:	eb 46                	jmp    7be4 <fwp_drop4+0x1e4>
    7b9e:	66 90                	xchg   %ax,%ax
    7ba0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7ba4:	48 85 c0             	test   %rax,%rax
    7ba7:	74 3b                	je     7be4 <fwp_drop4+0x1e4>
    7ba9:	48 89 c1             	mov    %rax,%rcx
    7bac:	48 39 10             	cmp    %rdx,(%rax)
    7baf:	75 ef                	jne    7ba0 <fwp_drop4+0x1a0>
    7bb1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7bb5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7bb9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7bbd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7bc4:	0f 85 c4 fe ff ff    	jne    7a8e <fwp_drop4+0x8e>
    7bca:	48 89 d7             	mov    %rdx,%rdi
    7bcd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7bd2:	e8 f9 db ff ff       	call   57d0 <fwp_rc_forget_slot>
    7bd7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7bdc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7bdf:	e9 aa fe ff ff       	jmp    7a8e <fwp_drop4+0x8e>
    7be4:	48 8d 3d f5 5d 00 00 	lea    0x5df5(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    7beb:	e8 60 c8 ff ff       	call   4450 <fwp_trap>

0000000000007bf0 <fwp_caps161>:
    7bf0:	f3 0f 1e fa          	endbr64
    7bf4:	85 f6                	test   %esi,%esi
    7bf6:	74 08                	je     7c00 <fwp_caps161+0x10>
    7bf8:	c3                   	ret
    7bf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c00:	48 8b 15 11 30 06 00 	mov    0x63011(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    7c07:	48 89 f8             	mov    %rdi,%rax
    7c0a:	48 2b 05 df 2f 06 00 	sub    0x62fdf(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    7c11:	48 c1 e2 10          	shl    $0x10,%rdx
    7c15:	48 39 d0             	cmp    %rdx,%rax
    7c18:	73 de                	jae    7bf8 <fwp_caps161+0x8>
    7c1a:	48 89 c2             	mov    %rax,%rdx
    7c1d:	48 c1 ea 10          	shr    $0x10,%rdx
    7c21:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7c25:	48 8b 15 0c 30 06 00 	mov    0x6300c(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    7c2c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7c30:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7c34:	48 85 c9             	test   %rcx,%rcx
    7c37:	74 bf                	je     7bf8 <fwp_caps161+0x8>
    7c39:	0f b6 32             	movzbl (%rdx),%esi
    7c3c:	40 80 fe 02          	cmp    $0x2,%sil
    7c40:	74 2e                	je     7c70 <fwp_caps161+0x80>
    7c42:	40 80 fe 01          	cmp    $0x1,%sil
    7c46:	75 b0                	jne    7bf8 <fwp_caps161+0x8>
    7c48:	8b 72 18             	mov    0x18(%rdx),%esi
    7c4b:	0f b7 c0             	movzwl %ax,%eax
    7c4e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7c51:	48 0f af c6          	imul   %rsi,%rax
    7c55:	48 c1 e8 20          	shr    $0x20,%rax
    7c59:	48 39 d0             	cmp    %rdx,%rax
    7c5c:	73 9a                	jae    7bf8 <fwp_caps161+0x8>
    7c5e:	48 01 c1             	add    %rax,%rcx
    7c61:	80 39 01             	cmpb   $0x1,(%rcx)
    7c64:	75 92                	jne    7bf8 <fwp_caps161+0x8>
    7c66:	e9 a5 dd ff ff       	jmp    5a10 <fwp_mem_free>
    7c6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7c70:	66 85 c0             	test   %ax,%ax
    7c73:	74 ec                	je     7c61 <fwp_caps161+0x71>
    7c75:	c3                   	ret
    7c76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7c7d:	00 00 00 

0000000000007c80 <f12>:
    7c80:	41 57                	push   %r15
    7c82:	41 56                	push   %r14
    7c84:	41 55                	push   %r13
    7c86:	41 54                	push   %r12
    7c88:	4c 8d 25 b1 f7 ff ff 	lea    -0x84f(%rip),%r12        # 7440 <fwp_tape_scope_release>
    7c8f:	55                   	push   %rbp
    7c90:	53                   	push   %rbx
    7c91:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
    7c98:	48 8b 05 39 38 06 00 	mov    0x63839(%rip),%rax        # 6b4d8 <fwp_cleanups>
    7c9f:	48 8b 15 72 2f 06 00 	mov    0x62f72(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    7ca6:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    7cad:	00 00 
    7caf:	48 89 ac 24 f8 00 00 	mov    %rbp,0xf8(%rsp)
    7cb6:	00 
    7cb7:	48 89 fd             	mov    %rdi,%rbp
    7cba:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    7cc1:	ff 
    7cc2:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    7cc7:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    7ccc:	48 c1 e2 10          	shl    $0x10,%rdx
    7cd0:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    7cd5:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    7cda:	48 8d 44 24 60       	lea    0x60(%rsp),%rax
    7cdf:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    7ce4:	48 89 05 ed 37 06 00 	mov    %rax,0x637ed(%rip)        # 6b4d8 <fwp_cleanups>
    7ceb:	48 8d 05 1e 93 00 00 	lea    0x931e(%rip),%rax        # 11010 <fc23>
    7cf2:	48 2b 05 f7 2e 06 00 	sub    0x62ef7(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    7cf9:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    7cfe:	48 39 d0             	cmp    %rdx,%rax
    7d01:	73 6d                	jae    7d70 <f12+0xf0>
    7d03:	48 89 c2             	mov    %rax,%rdx
    7d06:	48 c1 ea 10          	shr    $0x10,%rdx
    7d0a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d0e:	48 8b 15 23 2f 06 00 	mov    0x62f23(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    7d15:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d19:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d1d:	48 85 ff             	test   %rdi,%rdi
    7d20:	74 4e                	je     7d70 <f12+0xf0>
    7d22:	0f b6 0a             	movzbl (%rdx),%ecx
    7d25:	80 f9 02             	cmp    $0x2,%cl
    7d28:	0f 84 02 0f 00 00    	je     8c30 <f12+0xfb0>
    7d2e:	80 f9 01             	cmp    $0x1,%cl
    7d31:	75 3d                	jne    7d70 <f12+0xf0>
    7d33:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d36:	0f b7 c0             	movzwl %ax,%eax
    7d39:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d3c:	48 0f af c1          	imul   %rcx,%rax
    7d40:	48 c1 e8 20          	shr    $0x20,%rax
    7d44:	48 39 d0             	cmp    %rdx,%rax
    7d47:	73 27                	jae    7d70 <f12+0xf0>
    7d49:	48 01 c7             	add    %rax,%rdi
    7d4c:	0f b6 07             	movzbl (%rdi),%eax
    7d4f:	84 c0                	test   %al,%al
    7d51:	74 1d                	je     7d70 <f12+0xf0>
    7d53:	44 8b 05 ae 37 06 00 	mov    0x637ae(%rip),%r8d        # 6b508 <iteration_active>
    7d5a:	45 85 c0             	test   %r8d,%r8d
    7d5d:	0f 85 cd 0f 00 00    	jne    8d30 <f12+0x10b0>
    7d63:	3c fd                	cmp    $0xfd,%al
    7d65:	0f 87 82 11 00 00    	ja     8eed <f12+0x126d>
    7d6b:	83 c0 01             	add    $0x1,%eax
    7d6e:	88 07                	mov    %al,(%rdi)
    7d70:	48 8d 3d 99 92 00 00 	lea    0x9299(%rip),%rdi        # 11010 <fc23>
    7d77:	e8 54 f3 ff ff       	call   70d0 <fwp_closure_drop>
    7d7c:	48 85 ed             	test   %rbp,%rbp
    7d7f:	0f 84 cc 10 00 00    	je     8e51 <f12+0x11d1>
    7d85:	48 89 e8             	mov    %rbp,%rax
    7d88:	31 d2                	xor    %edx,%edx
    7d8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d90:	48 8b 40 10          	mov    0x10(%rax),%rax
    7d94:	48 83 c2 01          	add    $0x1,%rdx
    7d98:	48 85 c0             	test   %rax,%rax
    7d9b:	75 f3                	jne    7d90 <f12+0x110>
    7d9d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    7da4:	0f 87 ca 11 00 00    	ja     8f74 <f12+0x12f4>
    7daa:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    7daf:	8b 35 cb 92 00 00    	mov    0x92cb(%rip),%esi        # 11080 <registered_finish.0>
    7db5:	85 f6                	test   %esi,%esi
    7db7:	0f 84 43 0e 00 00    	je     8c00 <f12+0xf80>
    7dbd:	48 8b 1d 34 93 01 00 	mov    0x19334(%rip),%rbx        # 210f8 <fwp_tape_next_slot>
    7dc4:	4c 8b 2d 3d 93 01 00 	mov    0x1933d(%rip),%r13        # 21108 <fwp_ntapes>
    7dcb:	4c 39 eb             	cmp    %r13,%rbx
    7dce:	0f 8d d4 00 00 00    	jge    7ea8 <f12+0x228>
    7dd4:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    7dd8:	48 03 05 31 93 01 00 	add    0x19331(%rip),%rax        # 21110 <fwp_tapes>
    7ddf:	90                   	nop
    7de0:	8b 48 04             	mov    0x4(%rax),%ecx
    7de3:	85 c9                	test   %ecx,%ecx
    7de5:	75 0c                	jne    7df3 <f12+0x173>
    7de7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    7ded:	0f 86 b5 00 00 00    	jbe    7ea8 <f12+0x228>
    7df3:	48 83 c3 01          	add    $0x1,%rbx
    7df7:	48 83 c0 68          	add    $0x68,%rax
    7dfb:	4c 39 eb             	cmp    %r13,%rbx
    7dfe:	75 e0                	jne    7de0 <f12+0x160>
    7e00:	49 81 fd fe ff 00 00 	cmp    $0xfffe,%r13
    7e07:	0f 8f e9 11 00 00    	jg     8ff6 <f12+0x1376>
    7e0d:	4c 39 2d ec 92 01 00 	cmp    %r13,0x192ec(%rip)        # 21100 <fwp_tapes_cap>
    7e14:	4c 8b 3d f5 92 01 00 	mov    0x192f5(%rip),%r15        # 21110 <fwp_tapes>
    7e1b:	75 4c                	jne    7e69 <f12+0x1e9>
    7e1d:	4d 85 ed             	test   %r13,%r13
    7e20:	0f 84 91 10 00 00    	je     8eb7 <f12+0x1237>
    7e26:	4b 8d 5c 2d 00       	lea    0x0(%r13,%r13,1),%rbx
    7e2b:	b8 ff ff 00 00       	mov    $0xffff,%eax
    7e30:	48 39 c3             	cmp    %rax,%rbx
    7e33:	48 0f 4f d8          	cmovg  %rax,%rbx
    7e37:	48 6b f3 68          	imul   $0x68,%rbx,%rsi
    7e3b:	31 d2                	xor    %edx,%edx
    7e3d:	4c 89 ff             	mov    %r15,%rdi
    7e40:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    7e45:	e8 46 d3 ff ff       	call   5190 <ad_raw_realloc>
    7e4a:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    7e4f:	48 85 c0             	test   %rax,%rax
    7e52:	49 89 c7             	mov    %rax,%r15
    7e55:	0f 84 3d 11 00 00    	je     8f98 <f12+0x1318>
    7e5b:	48 89 05 ae 92 01 00 	mov    %rax,0x192ae(%rip)        # 21110 <fwp_tapes>
    7e62:	48 89 1d 97 92 01 00 	mov    %rbx,0x19297(%rip)        # 21100 <fwp_tapes_cap>
    7e69:	49 6b c5 68          	imul   $0x68,%r13,%rax
    7e6d:	4c 89 eb             	mov    %r13,%rbx
    7e70:	4c 01 f8             	add    %r15,%rax
    7e73:	48 8d 78 08          	lea    0x8(%rax),%rdi
    7e77:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    7e7e:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    7e82:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    7e89:	00 
    7e8a:	48 29 f8             	sub    %rdi,%rax
    7e8d:	8d 48 68             	lea    0x68(%rax),%ecx
    7e90:	31 c0                	xor    %eax,%eax
    7e92:	c1 e9 03             	shr    $0x3,%ecx
    7e95:	f3 48 ab             	rep stos %rax,(%rdi)
    7e98:	49 8d 45 01          	lea    0x1(%r13),%rax
    7e9c:	48 89 05 65 92 01 00 	mov    %rax,0x19265(%rip)        # 21108 <fwp_ntapes>
    7ea3:	eb 13                	jmp    7eb8 <f12+0x238>
    7ea5:	0f 1f 00             	nopl   (%rax)
    7ea8:	49 39 dd             	cmp    %rbx,%r13
    7eab:	0f 84 4f ff ff ff    	je     7e00 <f12+0x180>
    7eb1:	4c 8b 3d 58 92 01 00 	mov    0x19258(%rip),%r15        # 21110 <fwp_tapes>
    7eb8:	4c 6b f3 68          	imul   $0x68,%rbx,%r14
    7ebc:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    7ec0:	48 8d 3d 99 52 00 00 	lea    0x5299(%rip),%rdi        # d160 <_IO_stdin_used+0x160>
    7ec7:	0f 29 04 24          	movaps %xmm0,(%rsp)
    7ecb:	4d 01 fe             	add    %r15,%r14
    7ece:	49 c7 46 60 00 00 00 	movq   $0x0,0x60(%r14)
    7ed5:	00 
    7ed6:	e8 b5 b4 ff ff       	call   3390 <getenv@plt>
    7edb:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    7ee0:	48 85 c0             	test   %rax,%rax
    7ee3:	74 09                	je     7eee <f12+0x26e>
    7ee5:	80 38 30             	cmpb   $0x30,(%rax)
    7ee8:	0f 84 6a 06 00 00    	je     8558 <f12+0x8d8>
    7eee:	48 83 3d b2 91 01 00 	cmpq   $0x0,0x191b2(%rip)        # 210a8 <fwp_tape_cached_bytes>
    7ef5:	00 
    7ef6:	0f 85 94 0d 00 00    	jne    8c90 <f12+0x1010>
    7efc:	41 8b 06             	mov    (%r14),%eax
    7eff:	4c 8d 6b 01          	lea    0x1(%rbx),%r13
    7f03:	41 c7 46 04 01 00 00 	movl   $0x1,0x4(%r14)
    7f0a:	00 
    7f0b:	4c 89 2d e6 91 01 00 	mov    %r13,0x191e6(%rip)        # 210f8 <fwp_tape_next_slot>
    7f12:	8d 70 01             	lea    0x1(%rax),%esi
    7f15:	48 8b 05 bc 35 06 00 	mov    0x635bc(%rip),%rax        # 6b4d8 <fwp_cleanups>
    7f1c:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
    7f21:	41 89 36             	mov    %esi,(%r14)
    7f24:	49 c7 46 50 00 00 00 	movq   $0x0,0x50(%r14)
    7f2b:	00 
    7f2c:	49 c7 46 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%r14)
    7f33:	ff 
    7f34:	48 85 c0             	test   %rax,%rax
    7f37:	75 13                	jne    7f4c <f12+0x2cc>
    7f39:	e9 c9 10 00 00       	jmp    9007 <f12+0x1387>
    7f3e:	66 90                	xchg   %ax,%ax
    7f40:	48 8b 00             	mov    (%rax),%rax
    7f43:	48 85 c0             	test   %rax,%rax
    7f46:	0f 84 bb 10 00 00    	je     9007 <f12+0x1387>
    7f4c:	4c 39 60 08          	cmp    %r12,0x8(%rax)
    7f50:	75 ee                	jne    7f40 <f12+0x2c0>
    7f52:	48 8b 50 10          	mov    0x10(%rax),%rdx
    7f56:	89 d9                	mov    %ebx,%ecx
    7f58:	48 63 02             	movslq (%rdx),%rax
    7f5b:	49 89 56 50          	mov    %rdx,0x50(%r14)
    7f5f:	41 89 46 5c          	mov    %eax,0x5c(%r14)
    7f63:	85 c0                	test   %eax,%eax
    7f65:	78 09                	js     7f70 <f12+0x2f0>
    7f67:	48 6b c0 68          	imul   $0x68,%rax,%rax
    7f6b:	41 89 5c 07 58       	mov    %ebx,0x58(%r15,%rax,1)
    7f70:	89 0a                	mov    %ecx,(%rdx)
    7f72:	48 89 e8             	mov    %rbp,%rax
    7f75:	31 c9                	xor    %ecx,%ecx
    7f77:	48 85 ed             	test   %rbp,%rbp
    7f7a:	0f 84 f0 0a 00 00    	je     8a70 <f12+0xdf0>
    7f80:	48 8b 40 10          	mov    0x10(%rax),%rax
    7f84:	48 83 c1 01          	add    $0x1,%rcx
    7f88:	48 85 c0             	test   %rax,%rax
    7f8b:	75 f3                	jne    7f80 <f12+0x300>
    7f8d:	48 89 ea             	mov    %rbp,%rdx
    7f90:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    7f94:	48 83 c0 01          	add    $0x1,%rax
    7f98:	48 85 d2             	test   %rdx,%rdx
    7f9b:	75 f3                	jne    7f90 <f12+0x310>
    7f9d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    7fa4:	ff ff 1f 
    7fa7:	48 39 c2             	cmp    %rax,%rdx
    7faa:	0f 82 16 10 00 00    	jb     8fc6 <f12+0x1346>
    7fb0:	48 85 c9             	test   %rcx,%rcx
    7fb3:	0f 8e b7 0a 00 00    	jle    8a70 <f12+0xdf0>
    7fb9:	48 39 c1             	cmp    %rax,%rcx
    7fbc:	48 0f 46 c1          	cmovbe %rcx,%rax
    7fc0:	49 89 c4             	mov    %rax,%r12
    7fc3:	48 c1 e8 3c          	shr    $0x3c,%rax
    7fc7:	0f 85 f9 0f 00 00    	jne    8fc6 <f12+0x1346>
    7fcd:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    7fd1:	48 c1 e6 10          	shl    $0x10,%rsi
    7fd5:	49 09 f5             	or     %rsi,%r13
    7fd8:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    7fdf:	00 
    7fe0:	be 02 00 00 00       	mov    $0x2,%esi
    7fe5:	e8 26 df ff ff       	call   5f10 <fwp_heap_alloc>
    7fea:	4c 89 30             	mov    %r14,(%rax)
    7fed:	48 8b 15 24 2c 06 00 	mov    0x62c24(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    7ff4:	48 89 c3             	mov    %rax,%rbx
    7ff7:	48 2b 05 f2 2b 06 00 	sub    0x62bf2(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    7ffe:	48 c1 e2 10          	shl    $0x10,%rdx
    8002:	48 39 d0             	cmp    %rdx,%rax
    8005:	0f 83 65 0d 00 00    	jae    8d70 <f12+0x10f0>
    800b:	48 89 c2             	mov    %rax,%rdx
    800e:	48 c1 ea 10          	shr    $0x10,%rdx
    8012:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8016:	48 8b 15 1b 2c 06 00 	mov    0x62c1b(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    801d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8021:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8025:	4d 85 f6             	test   %r14,%r14
    8028:	74 38                	je     8062 <f12+0x3e2>
    802a:	0f b6 0a             	movzbl (%rdx),%ecx
    802d:	80 f9 02             	cmp    $0x2,%cl
    8030:	0f 84 a7 0a 00 00    	je     8add <f12+0xe5d>
    8036:	80 f9 01             	cmp    $0x1,%cl
    8039:	75 27                	jne    8062 <f12+0x3e2>
    803b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    803e:	0f b7 c0             	movzwl %ax,%eax
    8041:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8044:	48 0f af c1          	imul   %rcx,%rax
    8048:	48 c1 e8 20          	shr    $0x20,%rax
    804c:	48 39 d0             	cmp    %rdx,%rax
    804f:	73 11                	jae    8062 <f12+0x3e2>
    8051:	49 01 c6             	add    %rax,%r14
    8054:	41 80 3e ff          	cmpb   $0xff,(%r14)
    8058:	0f 84 68 0e 00 00    	je     8ec6 <f12+0x1246>
    805e:	41 c6 06 01          	movb   $0x1,(%r14)
    8062:	4d 85 e4             	test   %r12,%r12
    8065:	74 4c                	je     80b3 <f12+0x433>
    8067:	4c 89 e9             	mov    %r13,%rcx
    806a:	48 89 ea             	mov    %rbp,%rdx
    806d:	31 c0                	xor    %eax,%eax
    806f:	48 c1 e1 20          	shl    $0x20,%rcx
    8073:	66 90                	xchg   %ax,%ax
    8075:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    807c:	00 00 00 00 
    8080:	48 89 c6             	mov    %rax,%rsi
    8083:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8088:	48 01 ce             	add    %rcx,%rsi
    808b:	0f 80 ca 0e 00 00    	jo     8f5b <f12+0x12db>
    8091:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    8096:	48 89 c6             	mov    %rax,%rsi
    8099:	48 83 c0 01          	add    $0x1,%rax
    809d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    80a1:	48 c1 e6 04          	shl    $0x4,%rsi
    80a5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    80aa:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    80ae:	4c 39 e0             	cmp    %r12,%rax
    80b1:	72 cd                	jb     8080 <f12+0x400>
    80b3:	48 8b 03             	mov    (%rbx),%rax
    80b6:	48 d1 e8             	shr    $1,%rax
    80b9:	0f 85 49 0a 00 00    	jne    8b08 <f12+0xe88>
    80bf:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
    80c6:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    80cd:	0f 1f 00             	nopl   (%rax)
    80d0:	48 89 df             	mov    %rbx,%rdi
    80d3:	4d 63 e5             	movslq %r13d,%r12
    80d6:	e8 25 f9 ff ff       	call   7a00 <fwp_drop4>
    80db:	4c 89 e7             	mov    %r12,%rdi
    80de:	e8 4d c6 ff ff       	call   4730 <fwp_tape_of>
    80e3:	48 89 c6             	mov    %rax,%rsi
    80e6:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    80eb:	0f 85 f9 0e 00 00    	jne    8fea <f12+0x136a>
    80f1:	48 89 c7             	mov    %rax,%rdi
    80f4:	e8 97 bb ff ff       	call   3c90 <fwp_tape_unlink_scope>
    80f9:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    80fd:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    8102:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    8109:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
    810d:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    8111:	66 49 0f 6e fe       	movq   %r14,%xmm7
    8116:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    811b:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    8120:	4c 8b 46 40          	mov    0x40(%rsi),%r8
    8124:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    8128:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    812e:	77 19                	ja     8149 <f12+0x4c9>
    8130:	41 0f b7 c5          	movzwl %r13w,%eax
    8134:	83 e8 01             	sub    $0x1,%eax
    8137:	48 98                	cltq
    8139:	48 3b 05 b8 8f 01 00 	cmp    0x18fb8(%rip),%rax        # 210f8 <fwp_tape_next_slot>
    8140:	7d 07                	jge    8149 <f12+0x4c9>
    8142:	48 89 05 af 8f 01 00 	mov    %rax,0x18faf(%rip)        # 210f8 <fwp_tape_next_slot>
    8149:	48 8b 05 88 33 06 00 	mov    0x63388(%rip),%rax        # 6b4d8 <fwp_cleanups>
    8150:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8154:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    815b:	00 
    815c:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8160:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    8167:	00 
    8168:	48 8d 05 f1 d0 ff ff 	lea    -0x2f0f(%rip),%rax        # 5260 <fwp_tape_buffers_release>
    816f:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    8176:	00 
    8177:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    817e:	00 
    817f:	48 89 04 24          	mov    %rax,(%rsp)
    8183:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    818a:	00 
    818b:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    8192:	00 
    8193:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    8197:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    819b:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    81a2:	00 
    81a3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    81aa:	00 
    81ab:	4c 89 84 24 c0 00 00 	mov    %r8,0xc0(%rsp)
    81b2:	00 
    81b3:	48 89 05 1e 33 06 00 	mov    %rax,0x6331e(%rip)        # 6b4d8 <fwp_cleanups>
    81ba:	0f 29 9c 24 a0 00 00 	movaps %xmm3,0xa0(%rsp)
    81c1:	00 
    81c2:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    81c9:	00 
    81ca:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    81d1:	00 
    81d2:	4d 85 ff             	test   %r15,%r15
    81d5:	0f 88 65 0a 00 00    	js     8c40 <f12+0xfc0>
    81db:	4c 89 f8             	mov    %r15,%rax
    81de:	48 c1 f8 20          	sar    $0x20,%rax
    81e2:	49 39 c4             	cmp    %rax,%r12
    81e5:	0f 85 64 0d 00 00    	jne    8f4f <f12+0x12cf>
    81eb:	44 89 f9             	mov    %r15d,%ecx
    81ee:	49 89 cd             	mov    %rcx,%r13
    81f1:	48 39 ca             	cmp    %rcx,%rdx
    81f4:	0f 8e 49 0d 00 00    	jle    8f43 <f12+0x12c3>
    81fa:	48 39 cb             	cmp    %rcx,%rbx
    81fd:	0f 8e ad 09 00 00    	jle    8bb0 <f12+0xf30>
    8203:	4c 39 f3             	cmp    %r14,%rbx
    8206:	0f 8e f4 0a 00 00    	jle    8d00 <f12+0x1080>
    820c:	49 89 dc             	mov    %rbx,%r12
    820f:	4d 85 f6             	test   %r14,%r14
    8212:	4d 0f 44 f4          	cmove  %r12,%r14
    8216:	eb 1d                	jmp    8235 <f12+0x5b5>
    8218:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    821f:	00 
    8220:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
    8224:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    822b:	4c 89 e0             	mov    %r12,%rax
    822e:	48 0f 4c c2          	cmovl  %rdx,%rax
    8232:	49 89 c6             	mov    %rax,%r14
    8235:	4d 39 f4             	cmp    %r14,%r12
    8238:	7f e6                	jg     8220 <f12+0x5a0>
    823a:	4d 85 c0             	test   %r8,%r8
    823d:	0f 84 3d 0b 00 00    	je     8d80 <f12+0x1100>
    8243:	4c 89 c7             	mov    %r8,%rdi
    8246:	ba 03 00 00 00       	mov    $0x3,%edx
    824b:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8250:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    8257:	00 
    8258:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    825d:	e8 2e cf ff ff       	call   5190 <ad_raw_realloc>
    8262:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8268:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    826e:	48 85 c0             	test   %rax,%rax
    8271:	49 89 c0             	mov    %rax,%r8
    8274:	0f 84 c6 0b 00 00    	je     8e40 <f12+0x11c0>
    827a:	4c 89 84 24 c0 00 00 	mov    %r8,0xc0(%rsp)
    8281:	00 
    8282:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    8289:	00 
    828a:	4d 85 e4             	test   %r12,%r12
    828d:	0f 85 67 0c 00 00    	jne    8efa <f12+0x127a>
    8293:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    829a:	4d 85 ff             	test   %r15,%r15
    829d:	78 17                	js     82b6 <f12+0x636>
    829f:	44 89 f9             	mov    %r15d,%ecx
    82a2:	f2 0f 10 05 36 5b 00 	movsd  0x5b36(%rip),%xmm0        # dde0 <msg.4+0xb0>
    82a9:	00 
    82aa:	f2 41 0f 58 04 c8    	addsd  (%r8,%rcx,8),%xmm0
    82b0:	f2 41 0f 11 04 c8    	movsd  %xmm0,(%r8,%rcx,8)
    82b6:	4c 39 eb             	cmp    %r13,%rbx
    82b9:	0f 8f 92 00 00 00    	jg     8351 <f12+0x6d1>
    82bf:	0f 12 fb             	movhlps %xmm3,%xmm7
    82c2:	66 49 0f 7e d2       	movq   %xmm2,%r10
    82c7:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    82cc:	49 29 dd             	sub    %rbx,%r13
    82cf:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    82d4:	0f 12 fa             	movhlps %xmm2,%xmm7
    82d7:	49 8d 3c d8          	lea    (%r8,%rbx,8),%rdi
    82db:	66 49 0f 7e fb       	movq   %xmm7,%r11
    82e0:	4a 8d 04 ae          	lea    (%rsi,%r13,4),%rax
    82e4:	66 0f ef d2          	pxor   %xmm2,%xmm2
    82e8:	48 29 f1             	sub    %rsi,%rcx
    82eb:	4b 8d 14 eb          	lea    (%r11,%r13,8),%rdx
    82ef:	4c 29 df             	sub    %r11,%rdi
    82f2:	4d 29 da             	sub    %r11,%r10
    82f5:	eb 0d                	jmp    8304 <f12+0x684>
    82f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    82fe:	00 00 
    8300:	48 83 e8 04          	sub    $0x4,%rax
    8304:	f2 0f 10 04 17       	movsd  (%rdi,%rdx,1),%xmm0
    8309:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    830d:	7a 02                	jp     8311 <f12+0x691>
    830f:	74 37                	je     8348 <f12+0x6c8>
    8311:	4c 63 1c 01          	movslq (%rcx,%rax,1),%r11
    8315:	45 85 db             	test   %r11d,%r11d
    8318:	78 16                	js     8330 <f12+0x6b0>
    831a:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    8320:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    8324:	f2 43 0f 58 0c d8    	addsd  (%r8,%r11,8),%xmm1
    832a:	f2 43 0f 11 0c d8    	movsd  %xmm1,(%r8,%r11,8)
    8330:	4c 63 18             	movslq (%rax),%r11
    8333:	45 85 db             	test   %r11d,%r11d
    8336:	78 10                	js     8348 <f12+0x6c8>
    8338:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    833c:	f2 43 0f 58 04 d8    	addsd  (%r8,%r11,8),%xmm0
    8342:	f2 43 0f 11 04 d8    	movsd  %xmm0,(%r8,%r11,8)
    8348:	48 83 ea 08          	sub    $0x8,%rdx
    834c:	48 39 c6             	cmp    %rax,%rsi
    834f:	75 af                	jne    8300 <f12+0x680>
    8351:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8358:	ff ff 1f 
    835b:	48 39 d8             	cmp    %rbx,%rax
    835e:	0f 82 6e 0c 00 00    	jb     8fd2 <f12+0x1352>
    8364:	48 8d 3c dd 08 00 00 	lea    0x8(,%rbx,8),%rdi
    836b:	00 
    836c:	be 02 00 00 00       	mov    $0x2,%esi
    8371:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    8376:	e8 95 db ff ff       	call   5f10 <fwp_heap_alloc>
    837b:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    8380:	48 89 18             	mov    %rbx,(%rax)
    8383:	49 89 c4             	mov    %rax,%r12
    8386:	31 c0                	xor    %eax,%eax
    8388:	48 85 db             	test   %rbx,%rbx
    838b:	74 25                	je     83b2 <f12+0x732>
    838d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8394:	00 
    8395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    839c:	00 00 00 00 
    83a0:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    83a4:	49 89 54 c4 08       	mov    %rdx,0x8(%r12,%rax,8)
    83a9:	48 83 c0 01          	add    $0x1,%rax
    83ad:	48 39 c3             	cmp    %rax,%rbx
    83b0:	75 ee                	jne    83a0 <f12+0x720>
    83b2:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
    83b9:	00 
    83ba:	48 8b 3c 24          	mov    (%rsp),%rdi
    83be:	4c 89 2d 13 31 06 00 	mov    %r13,0x63113(%rip)        # 6b4d8 <fwp_cleanups>
    83c5:	e8 96 ce ff ff       	call   5260 <fwp_tape_buffers_release>
    83ca:	48 8b 15 47 28 06 00 	mov    0x62847(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    83d1:	4c 89 e0             	mov    %r12,%rax
    83d4:	48 2b 05 15 28 06 00 	sub    0x62815(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    83db:	48 c1 e2 10          	shl    $0x10,%rdx
    83df:	48 39 d0             	cmp    %rdx,%rax
    83e2:	73 55                	jae    8439 <f12+0x7b9>
    83e4:	48 89 c2             	mov    %rax,%rdx
    83e7:	48 c1 ea 10          	shr    $0x10,%rdx
    83eb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    83ef:	48 8b 15 42 28 06 00 	mov    0x62842(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    83f6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    83fa:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    83fe:	48 85 db             	test   %rbx,%rbx
    8401:	74 36                	je     8439 <f12+0x7b9>
    8403:	0f b6 0a             	movzbl (%rdx),%ecx
    8406:	80 f9 02             	cmp    $0x2,%cl
    8409:	0f 84 61 08 00 00    	je     8c70 <f12+0xff0>
    840f:	80 f9 01             	cmp    $0x1,%cl
    8412:	75 25                	jne    8439 <f12+0x7b9>
    8414:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8417:	0f b7 c0             	movzwl %ax,%eax
    841a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    841d:	48 0f af c1          	imul   %rcx,%rax
    8421:	48 c1 e8 20          	shr    $0x20,%rax
    8425:	48 39 d0             	cmp    %rdx,%rax
    8428:	73 0f                	jae    8439 <f12+0x7b9>
    842a:	48 01 c3             	add    %rax,%rbx
    842d:	80 3b ff             	cmpb   $0xff,(%rbx)
    8430:	0f 84 9d 0a 00 00    	je     8ed3 <f12+0x1253>
    8436:	c6 03 01             	movb   $0x1,(%rbx)
    8439:	4c 3b 6c 24 40       	cmp    0x40(%rsp),%r13
    843e:	0f 85 07 b3 ff ff    	jne    374b <f12.cold>
    8444:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    8449:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    844e:	48 89 05 83 30 06 00 	mov    %rax,0x63083(%rip)        # 6b4d8 <fwp_cleanups>
    8455:	e8 e6 ef ff ff       	call   7440 <fwp_tape_scope_release>
    845a:	49 8b 04 24          	mov    (%r12),%rax
    845e:	49 89 c6             	mov    %rax,%r14
    8461:	49 0f ba f6 3f       	btr    $0x3f,%r14
    8466:	48 85 c0             	test   %rax,%rax
    8469:	0f 88 51 05 00 00    	js     89c0 <f12+0xd40>
    846f:	48 8b 15 a2 27 06 00 	mov    0x627a2(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    8476:	4c 89 e0             	mov    %r12,%rax
    8479:	48 2b 05 70 27 06 00 	sub    0x62770(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    8480:	48 c1 e2 10          	shl    $0x10,%rdx
    8484:	48 39 d0             	cmp    %rdx,%rax
    8487:	0f 83 33 05 00 00    	jae    89c0 <f12+0xd40>
    848d:	48 89 c2             	mov    %rax,%rdx
    8490:	48 c1 ea 10          	shr    $0x10,%rdx
    8494:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8498:	48 8b 15 99 27 06 00 	mov    0x62799(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    849f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    84a3:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    84a7:	48 85 c9             	test   %rcx,%rcx
    84aa:	0f 84 10 05 00 00    	je     89c0 <f12+0xd40>
    84b0:	0f b6 32             	movzbl (%rdx),%esi
    84b3:	40 80 fe 02          	cmp    $0x2,%sil
    84b7:	0f 84 f3 04 00 00    	je     89b0 <f12+0xd30>
    84bd:	40 80 fe 01          	cmp    $0x1,%sil
    84c1:	0f 85 f9 04 00 00    	jne    89c0 <f12+0xd40>
    84c7:	8b 72 18             	mov    0x18(%rdx),%esi
    84ca:	0f b7 c0             	movzwl %ax,%eax
    84cd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    84d0:	48 0f af c6          	imul   %rsi,%rax
    84d4:	48 c1 e8 20          	shr    $0x20,%rax
    84d8:	48 39 d0             	cmp    %rdx,%rax
    84db:	0f 83 df 04 00 00    	jae    89c0 <f12+0xd40>
    84e1:	48 01 c1             	add    %rax,%rcx
    84e4:	80 39 01             	cmpb   $0x1,(%rcx)
    84e7:	0f 85 d3 04 00 00    	jne    89c0 <f12+0xd40>
    84ed:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
    84f2:	4d 89 e5             	mov    %r12,%r13
    84f5:	31 ff                	xor    %edi,%edi
    84f7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    84fc:	f2 0f 10 0d ec 58 00 	movsd  0x58ec(%rip),%xmm1        # ddf0 <msg.4+0xc0>
    8503:	00 
    8504:	48 8d 50 08          	lea    0x8(%rax),%rdx
    8508:	31 c0                	xor    %eax,%eax
    850a:	4d 85 f6             	test   %r14,%r14
    850d:	75 2f                	jne    853e <f12+0x8be>
    850f:	eb 5f                	jmp    8570 <f12+0x8f0>
    8511:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8518:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    851d:	0f 88 3d 0a 00 00    	js     8f60 <f12+0x12e0>
    8523:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    8528:	48 83 c0 01          	add    $0x1,%rax
    852c:	48 83 c2 08          	add    $0x8,%rdx
    8530:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    8534:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8539:	49 39 c6             	cmp    %rax,%r14
    853c:	74 32                	je     8570 <f12+0x8f0>
    853e:	49 8d 4c 24 08       	lea    0x8(%r12),%rcx
    8543:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    8548:	79 ce                	jns    8518 <f12+0x898>
    854a:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
    854f:	eb c7                	jmp    8518 <f12+0x898>
    8551:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8558:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    855c:	0f 84 9a f9 ff ff    	je     7efc <f12+0x27c>
    8562:	e9 87 f9 ff ff       	jmp    7eee <f12+0x26e>
    8567:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    856e:	00 00 
    8570:	e8 8b f4 ff ff       	call   7a00 <fwp_drop4>
    8575:	48 89 e8             	mov    %rbp,%rax
    8578:	31 d2                	xor    %edx,%edx
    857a:	48 85 ed             	test   %rbp,%rbp
    857d:	0f 84 d7 08 00 00    	je     8e5a <f12+0x11da>
    8583:	66 90                	xchg   %ax,%ax
    8585:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    858c:	00 00 00 00 
    8590:	48 8b 40 10          	mov    0x10(%rax),%rax
    8594:	48 83 c2 01          	add    $0x1,%rdx
    8598:	48 85 c0             	test   %rax,%rax
    859b:	75 f3                	jne    8590 <f12+0x910>
    859d:	49 8b 45 00          	mov    0x0(%r13),%rax
    85a1:	49 89 c7             	mov    %rax,%r15
    85a4:	49 0f ba f7 3f       	btr    $0x3f,%r15
    85a9:	48 85 c0             	test   %rax,%rax
    85ac:	0f 88 60 03 00 00    	js     8912 <f12+0xc92>
    85b2:	48 8b 05 5f 26 06 00 	mov    0x6265f(%rip),%rax        # 6ac18 <fwp_heap+0x13d8>
    85b9:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    85be:	48 2b 0d 2b 26 06 00 	sub    0x6262b(%rip),%rcx        # 6abf0 <fwp_heap+0x13b0>
    85c5:	48 c1 e0 10          	shl    $0x10,%rax
    85c9:	48 39 c1             	cmp    %rax,%rcx
    85cc:	0f 83 40 03 00 00    	jae    8912 <f12+0xc92>
    85d2:	48 89 c8             	mov    %rcx,%rax
    85d5:	48 c1 e8 10          	shr    $0x10,%rax
    85d9:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    85dd:	48 8b 05 54 26 06 00 	mov    0x62654(%rip),%rax        # 6ac38 <fwp_heap+0x13f8>
    85e4:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    85e8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    85ec:	48 85 ff             	test   %rdi,%rdi
    85ef:	0f 84 1d 03 00 00    	je     8912 <f12+0xc92>
    85f5:	0f b6 06             	movzbl (%rsi),%eax
    85f8:	3c 02                	cmp    $0x2,%al
    85fa:	0f 84 00 03 00 00    	je     8900 <f12+0xc80>
    8600:	3c 01                	cmp    $0x1,%al
    8602:	0f 85 01 03 00 00    	jne    8909 <f12+0xc89>
    8608:	8b 46 18             	mov    0x18(%rsi),%eax
    860b:	0f b7 c9             	movzwl %cx,%ecx
    860e:	48 0f af c8          	imul   %rax,%rcx
    8612:	8b 46 1c             	mov    0x1c(%rsi),%eax
    8615:	48 c1 e9 20          	shr    $0x20,%rcx
    8619:	48 39 c1             	cmp    %rax,%rcx
    861c:	0f 83 e7 02 00 00    	jae    8909 <f12+0xc89>
    8622:	48 01 cf             	add    %rcx,%rdi
    8625:	80 3f 01             	cmpb   $0x1,(%rdi)
    8628:	0f 85 db 02 00 00    	jne    8909 <f12+0xc89>
    862e:	49 39 d7             	cmp    %rdx,%r15
    8631:	48 89 d0             	mov    %rdx,%rax
    8634:	49 0f 46 c7          	cmovbe %r15,%rax
    8638:	48 85 c0             	test   %rax,%rax
    863b:	0f 84 2b 09 00 00    	je     8f6c <f12+0x12ec>
    8641:	c7 44 24 40 01 00 00 	movl   $0x1,0x40(%rsp)
    8648:	00 
    8649:	4d 8d 75 08          	lea    0x8(%r13),%r14
    864d:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    8652:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    8659:	00 
    865a:	48 89 e9             	mov    %rbp,%rcx
    865d:	31 d2                	xor    %edx,%edx
    865f:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    8663:	eb 38                	jmp    869d <f12+0xa1d>
    8665:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    866a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8671:	00 00 00 00 
    8675:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    867c:	00 00 00 00 
    8680:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    8685:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    868a:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    8690:	48 83 c2 08          	add    $0x8,%rdx
    8694:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    8698:	49 39 d0             	cmp    %rdx,%r8
    869b:	74 1b                	je     86b8 <f12+0xa38>
    869d:	48 89 fe             	mov    %rdi,%rsi
    86a0:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    86a5:	79 d9                	jns    8680 <f12+0xa00>
    86a7:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    86ac:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    86b0:	eb ce                	jmp    8680 <f12+0xa00>
    86b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    86b8:	48 85 ed             	test   %rbp,%rbp
    86bb:	0f 84 7a 08 00 00    	je     8f3b <f12+0x12bb>
    86c1:	4c 8b 05 50 25 06 00 	mov    0x62550(%rip),%r8        # 6ac18 <fwp_heap+0x13d8>
    86c8:	4c 8b 0d 21 25 06 00 	mov    0x62521(%rip),%r9        # 6abf0 <fwp_heap+0x13b0>
    86cf:	48 89 e9             	mov    %rbp,%rcx
    86d2:	45 31 ed             	xor    %r13d,%r13d
    86d5:	4c 8b 15 5c 25 06 00 	mov    0x6255c(%rip),%r10        # 6ac38 <fwp_heap+0x13f8>
    86dc:	49 c1 e0 10          	shl    $0x10,%r8
    86e0:	eb 1c                	jmp    86fe <f12+0xa7e>
    86e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    86e8:	49 83 c5 01          	add    $0x1,%r13
    86ec:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    86f0:	49 39 c5             	cmp    %rax,%r13
    86f3:	0f 83 67 01 00 00    	jae    8860 <f12+0xbe0>
    86f9:	48 85 c9             	test   %rcx,%rcx
    86fc:	74 56                	je     8754 <f12+0xad4>
    86fe:	48 89 ca             	mov    %rcx,%rdx
    8701:	4c 29 ca             	sub    %r9,%rdx
    8704:	4c 39 c2             	cmp    %r8,%rdx
    8707:	73 4b                	jae    8754 <f12+0xad4>
    8709:	48 89 d6             	mov    %rdx,%rsi
    870c:	48 c1 ee 10          	shr    $0x10,%rsi
    8710:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    8714:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    8718:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    871c:	48 85 ff             	test   %rdi,%rdi
    871f:	74 33                	je     8754 <f12+0xad4>
    8721:	44 0f b6 1e          	movzbl (%rsi),%r11d
    8725:	41 80 fb 02          	cmp    $0x2,%r11b
    8729:	0f 84 19 01 00 00    	je     8848 <f12+0xbc8>
    872f:	41 80 fb 01          	cmp    $0x1,%r11b
    8733:	75 1f                	jne    8754 <f12+0xad4>
    8735:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    8739:	0f b7 d2             	movzwl %dx,%edx
    873c:	8b 76 1c             	mov    0x1c(%rsi),%esi
    873f:	49 0f af d3          	imul   %r11,%rdx
    8743:	48 c1 ea 20          	shr    $0x20,%rdx
    8747:	48 39 f2             	cmp    %rsi,%rdx
    874a:	73 08                	jae    8754 <f12+0xad4>
    874c:	48 01 d7             	add    %rdx,%rdi
    874f:	80 3f 01             	cmpb   $0x1,(%rdi)
    8752:	74 94                	je     86e8 <f12+0xa68>
    8754:	49 39 c5             	cmp    %rax,%r13
    8757:	0f 83 03 01 00 00    	jae    8860 <f12+0xbe0>
    875d:	49 89 c7             	mov    %rax,%r15
    8760:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
    8767:	00 
    8768:	45 31 e4             	xor    %r12d,%r12d
    876b:	48 89 04 24          	mov    %rax,(%rsp)
    876f:	48 8d 1d ca 10 06 00 	lea    0x610ca(%rip),%rbx        # 69840 <fwp_heap>
    8776:	eb 3a                	jmp    87b2 <f12+0xb32>
    8778:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    877f:	00 
    8780:	41 80 f9 01          	cmp    $0x1,%r9b
    8784:	75 27                	jne    87ad <f12+0xb2d>
    8786:	45 8b 48 18          	mov    0x18(%r8),%r9d
    878a:	0f b7 c0             	movzwl %ax,%eax
    878d:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    8791:	49 0f af c1          	imul   %r9,%rax
    8795:	48 c1 e8 20          	shr    $0x20,%rax
    8799:	4c 39 c0             	cmp    %r8,%rax
    879c:	73 0f                	jae    87ad <f12+0xb2d>
    879e:	48 01 c7             	add    %rax,%rdi
    87a1:	80 3f ff             	cmpb   $0xff,(%rdi)
    87a4:	0f 84 46 03 00 00    	je     8af0 <f12+0xe70>
    87aa:	c6 07 01             	movb   $0x1,(%rdi)
    87ad:	4d 39 fd             	cmp    %r15,%r13
    87b0:	73 7e                	jae    8830 <f12+0xbb0>
    87b2:	49 83 ef 01          	sub    $0x1,%r15
    87b6:	66 49 0f 6e f4       	movq   %r12,%xmm6
    87bb:	48 8b 34 24          	mov    (%rsp),%rsi
    87bf:	bf 01 00 00 00       	mov    $0x1,%edi
    87c4:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    87ca:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    87ce:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    87d5:	00 
    87d6:	e8 65 e0 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    87db:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    87e2:	49 89 c4             	mov    %rax,%r12
    87e5:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    87ec:	48 c1 e7 10          	shl    $0x10,%rdi
    87f0:	48 39 f8             	cmp    %rdi,%rax
    87f3:	73 b8                	jae    87ad <f12+0xb2d>
    87f5:	48 89 c7             	mov    %rax,%rdi
    87f8:	48 c1 ef 10          	shr    $0x10,%rdi
    87fc:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    8800:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    8807:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    880b:	49 8b 78 20          	mov    0x20(%r8),%rdi
    880f:	48 85 ff             	test   %rdi,%rdi
    8812:	74 99                	je     87ad <f12+0xb2d>
    8814:	45 0f b6 08          	movzbl (%r8),%r9d
    8818:	41 80 f9 02          	cmp    $0x2,%r9b
    881c:	0f 85 5e ff ff ff    	jne    8780 <f12+0xb00>
    8822:	66 85 c0             	test   %ax,%ax
    8825:	0f 84 76 ff ff ff    	je     87a1 <f12+0xb21>
    882b:	4d 39 fd             	cmp    %r15,%r13
    882e:	72 82                	jb     87b2 <f12+0xb32>
    8830:	4d 85 ed             	test   %r13,%r13
    8833:	75 2e                	jne    8863 <f12+0xbe3>
    8835:	8b 44 24 40          	mov    0x40(%rsp),%eax
    8839:	85 c0                	test   %eax,%eax
    883b:	4d 0f 45 f5          	cmovne %r13,%r14
    883f:	eb 6f                	jmp    88b0 <f12+0xc30>
    8841:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8848:	66 85 d2             	test   %dx,%dx
    884b:	0f 84 fe fe ff ff    	je     874f <f12+0xacf>
    8851:	49 39 c5             	cmp    %rax,%r13
    8854:	0f 82 03 ff ff ff    	jb     875d <f12+0xadd>
    885a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8860:	45 31 e4             	xor    %r12d,%r12d
    8863:	4c 89 f2             	mov    %r14,%rdx
    8866:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    886a:	48 89 e8             	mov    %rbp,%rax
    886d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8874:	00 
    8875:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    887c:	00 00 00 00 
    8880:	48 8b 0a             	mov    (%rdx),%rcx
    8883:	48 83 c2 08          	add    $0x8,%rdx
    8887:	48 89 c7             	mov    %rax,%rdi
    888a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    888e:	48 8b 40 10          	mov    0x10(%rax),%rax
    8892:	49 39 d0             	cmp    %rdx,%r8
    8895:	75 e9                	jne    8880 <f12+0xc00>
    8897:	8b 54 24 40          	mov    0x40(%rsp),%edx
    889b:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    889f:	85 d2                	test   %edx,%edx
    88a1:	0f 84 d9 03 00 00    	je     8c80 <f12+0x1000>
    88a7:	49 89 ec             	mov    %rbp,%r12
    88aa:	45 31 f6             	xor    %r14d,%r14d
    88ad:	48 89 c5             	mov    %rax,%rbp
    88b0:	4c 89 f7             	mov    %r14,%rdi
    88b3:	e8 58 d1 ff ff       	call   5a10 <fwp_mem_free>
    88b8:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    88bd:	e8 3e f1 ff ff       	call   7a00 <fwp_drop4>
    88c2:	48 89 ef             	mov    %rbp,%rdi
    88c5:	e8 16 e5 ff ff       	call   6de0 <fwp_drop0>
    88ca:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
    88d1:	00 
    88d2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    88d9:	00 00 
    88db:	0f 85 21 07 00 00    	jne    9002 <f12+0x1382>
    88e1:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
    88e8:	4c 89 e0             	mov    %r12,%rax
    88eb:	5b                   	pop    %rbx
    88ec:	5d                   	pop    %rbp
    88ed:	41 5c                	pop    %r12
    88ef:	41 5d                	pop    %r13
    88f1:	41 5e                	pop    %r14
    88f3:	41 5f                	pop    %r15
    88f5:	c3                   	ret
    88f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    88fd:	00 00 00 
    8900:	66 85 c9             	test   %cx,%cx
    8903:	0f 84 1c fd ff ff    	je     8625 <f12+0x9a5>
    8909:	48 85 ed             	test   %rbp,%rbp
    890c:	0f 84 2b 04 00 00    	je     8d3d <f12+0x10bd>
    8912:	48 89 e8             	mov    %rbp,%rax
    8915:	45 31 e4             	xor    %r12d,%r12d
    8918:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    891f:	00 
    8920:	48 8b 40 10          	mov    0x10(%rax),%rax
    8924:	4c 89 e2             	mov    %r12,%rdx
    8927:	49 83 c4 01          	add    $0x1,%r12
    892b:	48 85 c0             	test   %rax,%rax
    892e:	75 f0                	jne    8920 <f12+0xca0>
    8930:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8937:	ff ff 1f 
    893a:	4c 39 e0             	cmp    %r12,%rax
    893d:	0f 82 83 06 00 00    	jb     8fc6 <f12+0x1346>
    8943:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    894a:	00 
    894b:	be 02 00 00 00       	mov    $0x2,%esi
    8950:	e8 bb d5 ff ff       	call   5f10 <fwp_heap_alloc>
    8955:	4d 39 e7             	cmp    %r12,%r15
    8958:	48 89 ea             	mov    %rbp,%rdx
    895b:	49 89 c6             	mov    %rax,%r14
    895e:	4c 89 e0             	mov    %r12,%rax
    8961:	49 0f 46 c7          	cmovbe %r15,%rax
    8965:	4c 89 f1             	mov    %r14,%rcx
    8968:	66 90                	xchg   %ax,%ax
    896a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8971:	00 00 00 00 
    8975:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    897c:	00 00 00 00 
    8980:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    8984:	48 83 c1 08          	add    $0x8,%rcx
    8988:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    898c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8990:	48 85 d2             	test   %rdx,%rdx
    8993:	75 eb                	jne    8980 <f12+0xd00>
    8995:	48 85 c0             	test   %rax,%rax
    8998:	0f 84 b1 03 00 00    	je     8d4f <f12+0x10cf>
    899e:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
    89a5:	00 
    89a6:	e9 a2 fc ff ff       	jmp    864d <f12+0x9cd>
    89ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    89b0:	66 85 c0             	test   %ax,%ax
    89b3:	0f 84 2b fb ff ff    	je     84e4 <f12+0x864>
    89b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    89c0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    89c7:	ff ff 1f 
    89ca:	4c 39 f0             	cmp    %r14,%rax
    89cd:	0f 82 ff 05 00 00    	jb     8fd2 <f12+0x1352>
    89d3:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    89da:	00 
    89db:	be 01 00 00 00       	mov    $0x1,%esi
    89e0:	e8 2b d5 ff ff       	call   5f10 <fwp_heap_alloc>
    89e5:	4c 89 30             	mov    %r14,(%rax)
    89e8:	48 8b 15 29 22 06 00 	mov    0x62229(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    89ef:	49 89 c5             	mov    %rax,%r13
    89f2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    89f7:	48 2b 05 f2 21 06 00 	sub    0x621f2(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    89fe:	48 c1 e2 10          	shl    $0x10,%rdx
    8a02:	48 39 d0             	cmp    %rdx,%rax
    8a05:	73 57                	jae    8a5e <f12+0xdde>
    8a07:	48 89 c2             	mov    %rax,%rdx
    8a0a:	48 c1 ea 10          	shr    $0x10,%rdx
    8a0e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8a12:	48 8b 15 1f 22 06 00 	mov    0x6221f(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    8a19:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8a1d:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    8a21:	4d 85 ff             	test   %r15,%r15
    8a24:	74 38                	je     8a5e <f12+0xdde>
    8a26:	0f b6 0a             	movzbl (%rdx),%ecx
    8a29:	80 f9 02             	cmp    $0x2,%cl
    8a2c:	0f 84 2e 03 00 00    	je     8d60 <f12+0x10e0>
    8a32:	80 f9 01             	cmp    $0x1,%cl
    8a35:	75 27                	jne    8a5e <f12+0xdde>
    8a37:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8a3a:	0f b7 c0             	movzwl %ax,%eax
    8a3d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8a40:	48 0f af c1          	imul   %rcx,%rax
    8a44:	48 c1 e8 20          	shr    $0x20,%rax
    8a48:	48 39 d0             	cmp    %rdx,%rax
    8a4b:	73 11                	jae    8a5e <f12+0xdde>
    8a4d:	49 01 c7             	add    %rax,%r15
    8a50:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8a54:	0f 84 86 04 00 00    	je     8ee0 <f12+0x1260>
    8a5a:	41 c6 07 01          	movb   $0x1,(%r15)
    8a5e:	4c 89 e7             	mov    %r12,%rdi
    8a61:	e9 91 fa ff ff       	jmp    84f7 <f12+0x877>
    8a66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8a6d:	00 00 00 
    8a70:	48 c1 e6 10          	shl    $0x10,%rsi
    8a74:	bf 08 00 00 00       	mov    $0x8,%edi
    8a79:	49 09 f5             	or     %rsi,%r13
    8a7c:	be 02 00 00 00       	mov    $0x2,%esi
    8a81:	e8 8a d4 ff ff       	call   5f10 <fwp_heap_alloc>
    8a86:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8a8d:	48 8b 15 84 21 06 00 	mov    0x62184(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    8a94:	48 89 c3             	mov    %rax,%rbx
    8a97:	48 2b 05 52 21 06 00 	sub    0x62152(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    8a9e:	48 c1 e2 10          	shl    $0x10,%rdx
    8aa2:	48 39 d0             	cmp    %rdx,%rax
    8aa5:	0f 83 14 f6 ff ff    	jae    80bf <f12+0x43f>
    8aab:	48 89 c2             	mov    %rax,%rdx
    8aae:	48 c1 ea 10          	shr    $0x10,%rdx
    8ab2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8ab6:	48 8b 15 7b 21 06 00 	mov    0x6217b(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    8abd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8ac1:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8ac5:	4d 85 f6             	test   %r14,%r14
    8ac8:	0f 84 e5 f5 ff ff    	je     80b3 <f12+0x433>
    8ace:	0f b6 0a             	movzbl (%rdx),%ecx
    8ad1:	45 31 e4             	xor    %r12d,%r12d
    8ad4:	80 f9 02             	cmp    $0x2,%cl
    8ad7:	0f 85 59 f5 ff ff    	jne    8036 <f12+0x3b6>
    8add:	66 85 c0             	test   %ax,%ax
    8ae0:	0f 85 7c f5 ff ff    	jne    8062 <f12+0x3e2>
    8ae6:	e9 69 f5 ff ff       	jmp    8054 <f12+0x3d4>
    8aeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8af0:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
    8af5:	e8 d6 cc ff ff       	call   57d0 <fwp_rc_forget_slot>
    8afa:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    8aff:	e9 a6 fc ff ff       	jmp    87aa <f12+0xb2a>
    8b04:	0f 1f 40 00          	nopl   0x0(%rax)
    8b08:	4c 8d 60 ff          	lea    -0x1(%rax),%r12
    8b0c:	4c 89 e1             	mov    %r12,%rcx
    8b0f:	48 c1 e9 3c          	shr    $0x3c,%rcx
    8b13:	0f 85 ad 04 00 00    	jne    8fc6 <f12+0x1346>
    8b19:	4d 85 e4             	test   %r12,%r12
    8b1c:	0f 84 9d f5 ff ff    	je     80bf <f12+0x43f>
    8b22:	48 c1 e0 04          	shl    $0x4,%rax
    8b26:	4d 01 e4             	add    %r12,%r12
    8b29:	4c 8d 7b 08          	lea    0x8(%rbx),%r15
    8b2d:	4c 8d 74 03 f8       	lea    -0x8(%rbx,%rax,1),%r14
    8b32:	0f 1f 00             	nopl   (%rax)
    8b35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8b3c:	00 00 00 00 
    8b40:	f2 41 0f 10 07       	movsd  (%r15),%xmm0
    8b45:	49 8b 77 18          	mov    0x18(%r15),%rsi
    8b49:	49 83 c7 10          	add    $0x10,%r15
    8b4d:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
    8b51:	f2 41 0f 10 0f       	movsd  (%r15),%xmm1
    8b56:	e8 75 db ff ff       	call   66d0 <w107>
    8b5b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    8b60:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    8b64:	41 0f 11 47 f0       	movups %xmm0,-0x10(%r15)
    8b69:	4d 39 fe             	cmp    %r15,%r14
    8b6c:	75 d2                	jne    8b40 <f12+0xec0>
    8b6e:	4c 89 23             	mov    %r12,(%rbx)
    8b71:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    8b78:	45 31 f6             	xor    %r14d,%r14d
    8b7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8b80:	4a 8b 54 f3 10       	mov    0x10(%rbx,%r14,8),%rdx
    8b85:	4c 89 ff             	mov    %r15,%rdi
    8b88:	49 83 c6 02          	add    $0x2,%r14
    8b8c:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    8b93:	00 f0 3f 
    8b96:	48 89 ce             	mov    %rcx,%rsi
    8b99:	e8 b2 d7 ff ff       	call   6350 <fwp_p_ad_push>
    8b9e:	49 89 c7             	mov    %rax,%r15
    8ba1:	4d 39 e6             	cmp    %r12,%r14
    8ba4:	72 da                	jb     8b80 <f12+0xf00>
    8ba6:	e9 25 f5 ff ff       	jmp    80d0 <f12+0x450>
    8bab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8bb0:	4c 8d 61 01          	lea    0x1(%rcx),%r12
    8bb4:	4d 39 e6             	cmp    %r12,%r14
    8bb7:	0f 8c 52 f6 ff ff    	jl     820f <f12+0x58f>
    8bbd:	4d 85 c0             	test   %r8,%r8
    8bc0:	0f 84 ba 03 00 00    	je     8f80 <f12+0x1300>
    8bc6:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
    8bcb:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    8bd2:	00 
    8bd3:	31 f6                	xor    %esi,%esi
    8bd5:	4c 89 c7             	mov    %r8,%rdi
    8bd8:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8bdd:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8be2:	e8 c9 a8 ff ff       	call   34b0 <memset@plt>
    8be7:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8bed:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    8bf3:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
    8bf8:	49 89 c0             	mov    %rax,%r8
    8bfb:	e9 a2 f6 ff ff       	jmp    82a2 <f12+0x622>
    8c00:	48 8d 3d 19 e7 ff ff 	lea    -0x18e7(%rip),%rdi        # 7320 <fwp_tape_finish>
    8c07:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8c0c:	e8 0f 3c 00 00       	call   c820 <atexit>
    8c11:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8c16:	85 c0                	test   %eax,%eax
    8c18:	0f 85 7a 03 00 00    	jne    8f98 <f12+0x1318>
    8c1e:	c7 05 58 84 00 00 01 	movl   $0x1,0x8458(%rip)        # 11080 <registered_finish.0>
    8c25:	00 00 00 
    8c28:	e9 90 f1 ff ff       	jmp    7dbd <f12+0x13d>
    8c2d:	0f 1f 00             	nopl   (%rax)
    8c30:	66 85 c0             	test   %ax,%ax
    8c33:	0f 85 37 f1 ff ff    	jne    7d70 <f12+0xf0>
    8c39:	e9 0e f1 ff ff       	jmp    7d4c <f12+0xcc>
    8c3e:	66 90                	xchg   %ax,%ax
    8c40:	4c 39 f3             	cmp    %r14,%rbx
    8c43:	0f 8f c3 f5 ff ff    	jg     820c <f12+0x58c>
    8c49:	48 85 db             	test   %rbx,%rbx
    8c4c:	74 12                	je     8c60 <f12+0xfe0>
    8c4e:	4d 85 c0             	test   %r8,%r8
    8c51:	0f 84 29 03 00 00    	je     8f80 <f12+0x1300>
    8c57:	48 85 db             	test   %rbx,%rbx
    8c5a:	0f 85 97 02 00 00    	jne    8ef7 <f12+0x1277>
    8c60:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    8c67:	e9 4a f6 ff ff       	jmp    82b6 <f12+0x636>
    8c6c:	0f 1f 40 00          	nopl   0x0(%rax)
    8c70:	66 85 c0             	test   %ax,%ax
    8c73:	0f 85 c0 f7 ff ff    	jne    8439 <f12+0x7b9>
    8c79:	e9 af f7 ff ff       	jmp    842d <f12+0x7ad>
    8c7e:	66 90                	xchg   %ax,%ax
    8c80:	49 89 ec             	mov    %rbp,%r12
    8c83:	48 89 c5             	mov    %rax,%rbp
    8c86:	e9 25 fc ff ff       	jmp    88b0 <f12+0xc30>
    8c8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8c90:	66 0f 6f 0d 28 84 01 	movdqa 0x18428(%rip),%xmm1        # 210c0 <fwp_tape_workspace>
    8c97:	00 
    8c98:	48 c7 05 05 84 01 00 	movq   $0x0,0x18405(%rip)        # 210a8 <fwp_tape_cached_bytes>
    8c9f:	00 00 00 00 
    8ca3:	41 0f 11 4e 20       	movups %xmm1,0x20(%r14)
    8ca8:	48 8b 05 31 84 01 00 	mov    0x18431(%rip),%rax        # 210e0 <fwp_tape_workspace+0x20>
    8caf:	66 0f 6f 0d 19 84 01 	movdqa 0x18419(%rip),%xmm1        # 210d0 <fwp_tape_workspace+0x10>
    8cb6:	00 
    8cb7:	49 89 46 40          	mov    %rax,0x40(%r14)
    8cbb:	48 8b 05 26 84 01 00 	mov    0x18426(%rip),%rax        # 210e8 <fwp_tape_workspace+0x28>
    8cc2:	41 0f 11 4e 30       	movups %xmm1,0x30(%r14)
    8cc7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8ccb:	49 89 46 18          	mov    %rax,0x18(%r14)
    8ccf:	48 8b 05 1a 84 01 00 	mov    0x1841a(%rip),%rax        # 210f0 <fwp_tape_workspace+0x30>
    8cd6:	0f 29 0d e3 83 01 00 	movaps %xmm1,0x183e3(%rip)        # 210c0 <fwp_tape_workspace>
    8cdd:	49 89 46 48          	mov    %rax,0x48(%r14)
    8ce1:	0f 29 0d e8 83 01 00 	movaps %xmm1,0x183e8(%rip)        # 210d0 <fwp_tape_workspace+0x10>
    8ce8:	48 c7 05 fd 83 01 00 	movq   $0x0,0x183fd(%rip)        # 210f0 <fwp_tape_workspace+0x30>
    8cef:	00 00 00 00 
    8cf3:	0f 29 0d e6 83 01 00 	movaps %xmm1,0x183e6(%rip)        # 210e0 <fwp_tape_workspace+0x20>
    8cfa:	e9 fd f1 ff ff       	jmp    7efc <f12+0x27c>
    8cff:	90                   	nop
    8d00:	4d 85 c0             	test   %r8,%r8
    8d03:	0f 84 77 02 00 00    	je     8f80 <f12+0x1300>
    8d09:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
    8d0e:	4c 8d 6b ff          	lea    -0x1(%rbx),%r13
    8d12:	31 f6                	xor    %esi,%esi
    8d14:	4c 89 c7             	mov    %r8,%rdi
    8d17:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8d1c:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    8d23:	00 
    8d24:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8d29:	e9 b4 fe ff ff       	jmp    8be2 <f12+0xf62>
    8d2e:	66 90                	xchg   %ax,%ax
    8d30:	48 83 05 b8 27 06 00 	addq   $0x1,0x627b8(%rip)        # 6b4f0 <iteration_retains>
    8d37:	01 
    8d38:	e9 26 f0 ff ff       	jmp    7d63 <f12+0xe3>
    8d3d:	be 02 00 00 00       	mov    $0x2,%esi
    8d42:	bf 08 00 00 00       	mov    $0x8,%edi
    8d47:	e8 c4 d1 ff ff       	call   5f10 <fwp_heap_alloc>
    8d4c:	49 89 c6             	mov    %rax,%r14
    8d4f:	45 31 e4             	xor    %r12d,%r12d
    8d52:	e9 59 fb ff ff       	jmp    88b0 <f12+0xc30>
    8d57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8d5e:	00 00 
    8d60:	66 85 c0             	test   %ax,%ax
    8d63:	0f 85 f5 fc ff ff    	jne    8a5e <f12+0xdde>
    8d69:	e9 e2 fc ff ff       	jmp    8a50 <f12+0xdd0>
    8d6e:	66 90                	xchg   %ax,%ax
    8d70:	4d 85 e4             	test   %r12,%r12
    8d73:	0f 85 ee f2 ff ff    	jne    8067 <f12+0x3e7>
    8d79:	e9 41 f3 ff ff       	jmp    80bf <f12+0x43f>
    8d7e:	66 90                	xchg   %ax,%ax
    8d80:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    8d87:	ff ff 1f 
    8d8a:	49 8d 46 ff          	lea    -0x1(%r14),%rax
    8d8e:	48 39 c2             	cmp    %rax,%rdx
    8d91:	0f 82 47 02 00 00    	jb     8fde <f12+0x135e>
    8d97:	48 8d 05 42 84 04 00 	lea    0x48442(%rip),%rax        # 511e0 <ad_raw_blocks>
    8d9e:	45 31 ed             	xor    %r13d,%r13d
    8da1:	eb 32                	jmp    8dd5 <f12+0x1155>
    8da3:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8daa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8db1:	00 00 00 00 
    8db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8dbc:	00 00 00 00 
    8dc0:	49 83 c5 01          	add    $0x1,%r13
    8dc4:	48 83 c0 18          	add    $0x18,%rax
    8dc8:	49 81 fd 00 10 00 00 	cmp    $0x1000,%r13
    8dcf:	0f 84 5a 01 00 00    	je     8f2f <f12+0x12af>
    8dd5:	48 83 38 00          	cmpq   $0x0,(%rax)
    8dd9:	75 e5                	jne    8dc0 <f12+0x1140>
    8ddb:	be 08 00 00 00       	mov    $0x8,%esi
    8de0:	4c 89 f7             	mov    %r14,%rdi
    8de3:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8de8:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8ded:	e8 1e a7 ff ff       	call   3510 <calloc@plt>
    8df2:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8df8:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    8dfe:	48 8d 15 db 83 04 00 	lea    0x483db(%rip),%rdx        # 511e0 <ad_raw_blocks>
    8e05:	48 85 c0             	test   %rax,%rax
    8e08:	74 36                	je     8e40 <f12+0x11c0>
    8e0a:	4b 8d 4c 6d 00       	lea    0x0(%r13,%r13,2),%rcx
    8e0f:	48 89 c6             	mov    %rax,%rsi
    8e12:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    8e17:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    8e1b:	b9 03 00 00 00       	mov    $0x3,%ecx
    8e20:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    8e27:	00 
    8e28:	e8 d3 ad ff ff       	call   3c00 <ad_raw_record>
    8e2d:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    8e32:	e9 43 f4 ff ff       	jmp    827a <f12+0x5fa>
    8e37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8e3e:	00 00 
    8e40:	4d 85 e4             	test   %r12,%r12
    8e43:	0f 85 37 01 00 00    	jne    8f80 <f12+0x1300>
    8e49:	45 31 c0             	xor    %r8d,%r8d
    8e4c:	e9 42 f4 ff ff       	jmp    8293 <f12+0x613>
    8e51:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8e55:	e9 55 ef ff ff       	jmp    7daf <f12+0x12f>
    8e5a:	49 8b 45 00          	mov    0x0(%r13),%rax
    8e5e:	48 85 c0             	test   %rax,%rax
    8e61:	0f 88 d6 fe ff ff    	js     8d3d <f12+0x10bd>
    8e67:	48 8b 35 aa 1d 06 00 	mov    0x61daa(%rip),%rsi        # 6ac18 <fwp_heap+0x13d8>
    8e6e:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    8e73:	48 2b 0d 76 1d 06 00 	sub    0x61d76(%rip),%rcx        # 6abf0 <fwp_heap+0x13b0>
    8e7a:	48 c1 e6 10          	shl    $0x10,%rsi
    8e7e:	48 39 f1             	cmp    %rsi,%rcx
    8e81:	0f 83 b6 fe ff ff    	jae    8d3d <f12+0x10bd>
    8e87:	48 89 ce             	mov    %rcx,%rsi
    8e8a:	48 c1 ee 10          	shr    $0x10,%rsi
    8e8e:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    8e92:	48 8b 35 9f 1d 06 00 	mov    0x61d9f(%rip),%rsi        # 6ac38 <fwp_heap+0x13f8>
    8e99:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    8e9d:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8ea1:	48 85 ff             	test   %rdi,%rdi
    8ea4:	0f 84 93 fe ff ff    	je     8d3d <f12+0x10bd>
    8eaa:	48 0f ba f0 3f       	btr    $0x3f,%rax
    8eaf:	49 89 c7             	mov    %rax,%r15
    8eb2:	e9 3e f7 ff ff       	jmp    85f5 <f12+0x975>
    8eb7:	be 68 00 00 00       	mov    $0x68,%esi
    8ebc:	bb 01 00 00 00       	mov    $0x1,%ebx
    8ec1:	e9 75 ef ff ff       	jmp    7e3b <f12+0x1bb>
    8ec6:	4c 89 f7             	mov    %r14,%rdi
    8ec9:	e8 02 c9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8ece:	e9 8b f1 ff ff       	jmp    805e <f12+0x3de>
    8ed3:	48 89 df             	mov    %rbx,%rdi
    8ed6:	e8 f5 c8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8edb:	e9 56 f5 ff ff       	jmp    8436 <f12+0x7b6>
    8ee0:	4c 89 ff             	mov    %r15,%rdi
    8ee3:	e8 e8 c8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8ee8:	e9 6d fb ff ff       	jmp    8a5a <f12+0xdda>
    8eed:	e8 be c7 ff ff       	call   56b0 <fwp_rc_wide_dup>
    8ef2:	e9 79 ee ff ff       	jmp    7d70 <f12+0xf0>
    8ef7:	49 89 dc             	mov    %rbx,%r12
    8efa:	4c 89 c7             	mov    %r8,%rdi
    8efd:	31 f6                	xor    %esi,%esi
    8eff:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8f04:	4d 8d 6c 24 ff       	lea    -0x1(%r12),%r13
    8f09:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    8f10:	00 
    8f11:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8f16:	e8 95 a5 ff ff       	call   34b0 <memset@plt>
    8f1b:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8f21:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    8f27:	49 89 c0             	mov    %rax,%r8
    8f2a:	e9 6b f3 ff ff       	jmp    829a <f12+0x61a>
    8f2f:	48 8d 3d dc 41 00 00 	lea    0x41dc(%rip),%rdi        # d112 <_IO_stdin_used+0x112>
    8f36:	e8 c5 b0 ff ff       	call   4000 <ad_raw_fail>
    8f3b:	45 31 ed             	xor    %r13d,%r13d
    8f3e:	e9 1a f8 ff ff       	jmp    875d <f12+0xadd>
    8f43:	48 8d 3d 78 42 00 00 	lea    0x4278(%rip),%rdi        # d1c2 <_IO_stdin_used+0x1c2>
    8f4a:	e8 01 b5 ff ff       	call   4450 <fwp_trap>
    8f4f:	48 8d 3d b2 4a 00 00 	lea    0x4ab2(%rip),%rdi        # da08 <_IO_stdin_used+0xa08>
    8f56:	e8 f5 b4 ff ff       	call   4450 <fwp_trap>
    8f5b:	e8 a0 a7 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    8f60:	48 8d 3d a9 4b 00 00 	lea    0x4ba9(%rip),%rdi        # db10 <_IO_stdin_used+0xb10>
    8f67:	e8 e4 b4 ff ff       	call   4450 <fwp_trap>
    8f6c:	45 31 f6             	xor    %r14d,%r14d
    8f6f:	e9 db fd ff ff       	jmp    8d4f <f12+0x10cf>
    8f74:	48 8d 3d 70 42 00 00 	lea    0x4270(%rip),%rdi        # d1eb <_IO_stdin_used+0x1eb>
    8f7b:	e8 d0 b4 ff ff       	call   4450 <fwp_trap>
    8f80:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    8f87:	00 
    8f88:	48 8b 3c 24          	mov    (%rsp),%rdi
    8f8c:	48 89 05 45 25 06 00 	mov    %rax,0x62545(%rip)        # 6b4d8 <fwp_cleanups>
    8f93:	e8 c8 c2 ff ff       	call   5260 <fwp_tape_buffers_release>
    8f98:	48 8b 0d c1 80 00 00 	mov    0x80c1(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    8f9f:	ba 13 00 00 00       	mov    $0x13,%edx
    8fa4:	be 01 00 00 00       	mov    $0x1,%esi
    8fa9:	48 8d 3d 58 40 00 00 	lea    0x4058(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    8fb0:	e8 ab a6 ff ff       	call   3660 <fwrite@plt>
    8fb5:	31 ff                	xor    %edi,%edi
    8fb7:	e8 e4 a5 ff ff       	call   35a0 <fflush@plt>
    8fbc:	bf 66 00 00 00       	mov    $0x66,%edi
    8fc1:	e8 ba a6 ff ff       	call   3680 <_Exit@plt>
    8fc6:	48 8d 3d 38 42 00 00 	lea    0x4238(%rip),%rdi        # d205 <_IO_stdin_used+0x205>
    8fcd:	e8 7e b4 ff ff       	call   4450 <fwp_trap>
    8fd2:	48 8d 3d 56 42 00 00 	lea    0x4256(%rip),%rdi        # d22f <_IO_stdin_used+0x22f>
    8fd9:	e8 72 b4 ff ff       	call   4450 <fwp_trap>
    8fde:	48 8d 3d 2e 42 00 00 	lea    0x422e(%rip),%rdi        # d213 <_IO_stdin_used+0x213>
    8fe5:	e8 16 b0 ff ff       	call   4000 <ad_raw_fail>
    8fea:	48 8d 3d 5f 4a 00 00 	lea    0x4a5f(%rip),%rdi        # da50 <_IO_stdin_used+0xa50>
    8ff1:	e8 5a b4 ff ff       	call   4450 <fwp_trap>
    8ff6:	48 8d 3d b3 4a 00 00 	lea    0x4ab3(%rip),%rdi        # dab0 <_IO_stdin_used+0xab0>
    8ffd:	e8 4e b4 ff ff       	call   4450 <fwp_trap>
    9002:	e8 49 a4 ff ff       	call   3450 <__stack_chk_fail@plt>
    9007:	48 8d 3d d2 4a 00 00 	lea    0x4ad2(%rip),%rdi        # dae0 <_IO_stdin_used+0xae0>
    900e:	e8 3d b4 ff ff       	call   4450 <fwp_trap>
    9013:	66 90                	xchg   %ax,%ax
    9015:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    901c:	00 00 00 00 

0000000000009020 <fwp_owned_entry12>:
    9020:	f3 0f 1e fa          	endbr64
    9024:	48 8b 3f             	mov    (%rdi),%rdi
    9027:	e9 54 ec ff ff       	jmp    7c80 <f12>
    902c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009030 <e12>:
    9030:	f3 0f 1e fa          	endbr64
    9034:	53                   	push   %rbx
    9035:	48 8b 1f             	mov    (%rdi),%rbx
    9038:	48 89 df             	mov    %rbx,%rdi
    903b:	e8 f0 d9 ff ff       	call   6a30 <fwp_rc_share>
    9040:	48 89 df             	mov    %rbx,%rdi
    9043:	e8 38 ec ff ff       	call   7c80 <f12>
    9048:	48 89 c3             	mov    %rax,%rbx
    904b:	48 89 c7             	mov    %rax,%rdi
    904e:	e8 dd d9 ff ff       	call   6a30 <fwp_rc_share>
    9053:	48 89 d8             	mov    %rbx,%rax
    9056:	5b                   	pop    %rbx
    9057:	c3                   	ret
    9058:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    905f:	00 

0000000000009060 <fwp_drop2>:
    9060:	48 8b 0d b1 1b 06 00 	mov    0x61bb1(%rip),%rcx        # 6ac18 <fwp_heap+0x13d8>
    9067:	48 89 f8             	mov    %rdi,%rax
    906a:	48 2b 05 7f 1b 06 00 	sub    0x61b7f(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    9071:	48 c1 e1 10          	shl    $0x10,%rcx
    9075:	48 39 c8             	cmp    %rcx,%rax
    9078:	0f 83 42 01 00 00    	jae    91c0 <fwp_drop2+0x160>
    907e:	48 83 ec 18          	sub    $0x18,%rsp
    9082:	48 89 fa             	mov    %rdi,%rdx
    9085:	4c 8d 05 b4 07 06 00 	lea    0x607b4(%rip),%r8        # 69840 <fwp_heap>
    908c:	48 89 c1             	mov    %rax,%rcx
    908f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    9096:	48 c1 e9 10          	shr    $0x10,%rcx
    909a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    909e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    90a2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    90a6:	48 85 c9             	test   %rcx,%rcx
    90a9:	74 40                	je     90eb <fwp_drop2+0x8b>
    90ab:	0f b6 3e             	movzbl (%rsi),%edi
    90ae:	40 80 ff 02          	cmp    $0x2,%dil
    90b2:	74 3c                	je     90f0 <fwp_drop2+0x90>
    90b4:	40 80 ff 01          	cmp    $0x1,%dil
    90b8:	75 31                	jne    90eb <fwp_drop2+0x8b>
    90ba:	8b 7e 18             	mov    0x18(%rsi),%edi
    90bd:	0f b7 c0             	movzwl %ax,%eax
    90c0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    90c3:	48 0f af c7          	imul   %rdi,%rax
    90c7:	48 c1 e8 20          	shr    $0x20,%rax
    90cb:	48 39 f0             	cmp    %rsi,%rax
    90ce:	73 1b                	jae    90eb <fwp_drop2+0x8b>
    90d0:	48 01 c1             	add    %rax,%rcx
    90d3:	0f b6 01             	movzbl (%rcx),%eax
    90d6:	84 c0                	test   %al,%al
    90d8:	74 11                	je     90eb <fwp_drop2+0x8b>
    90da:	3c 01                	cmp    $0x1,%al
    90dc:	74 22                	je     9100 <fwp_drop2+0xa0>
    90de:	3c ff                	cmp    $0xff,%al
    90e0:	0f 84 0a 01 00 00    	je     91f0 <fwp_drop2+0x190>
    90e6:	83 e8 01             	sub    $0x1,%eax
    90e9:	88 01                	mov    %al,(%rcx)
    90eb:	48 83 c4 18          	add    $0x18,%rsp
    90ef:	c3                   	ret
    90f0:	66 85 c0             	test   %ax,%ax
    90f3:	74 de                	je     90d3 <fwp_drop2+0x73>
    90f5:	48 83 c4 18          	add    $0x18,%rsp
    90f9:	c3                   	ret
    90fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9100:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    9104:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    910b:	48 89 f8             	mov    %rdi,%rax
    910e:	48 c1 e1 10          	shl    $0x10,%rcx
    9112:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    9119:	48 39 c8             	cmp    %rcx,%rax
    911c:	73 62                	jae    9180 <fwp_drop2+0x120>
    911e:	48 89 c1             	mov    %rax,%rcx
    9121:	48 c1 e9 10          	shr    $0x10,%rcx
    9125:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    9129:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    912d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9131:	48 85 c9             	test   %rcx,%rcx
    9134:	74 4a                	je     9180 <fwp_drop2+0x120>
    9136:	44 0f b6 0e          	movzbl (%rsi),%r9d
    913a:	41 80 f9 02          	cmp    $0x2,%r9b
    913e:	0f 84 9c 00 00 00    	je     91e0 <fwp_drop2+0x180>
    9144:	41 80 f9 01          	cmp    $0x1,%r9b
    9148:	75 36                	jne    9180 <fwp_drop2+0x120>
    914a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    914e:	0f b7 c0             	movzwl %ax,%eax
    9151:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9154:	49 0f af c1          	imul   %r9,%rax
    9158:	48 c1 e8 20          	shr    $0x20,%rax
    915c:	48 39 f0             	cmp    %rsi,%rax
    915f:	73 1f                	jae    9180 <fwp_drop2+0x120>
    9161:	48 01 c1             	add    %rax,%rcx
    9164:	0f b6 01             	movzbl (%rcx),%eax
    9167:	84 c0                	test   %al,%al
    9169:	74 15                	je     9180 <fwp_drop2+0x120>
    916b:	3c 01                	cmp    $0x1,%al
    916d:	74 59                	je     91c8 <fwp_drop2+0x168>
    916f:	3c ff                	cmp    $0xff,%al
    9171:	0f 84 ef 00 00 00    	je     9266 <fwp_drop2+0x206>
    9177:	83 e8 01             	sub    $0x1,%eax
    917a:	88 01                	mov    %al,(%rcx)
    917c:	0f 1f 40 00          	nopl   0x0(%rax)
    9180:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    9184:	48 89 d7             	mov    %rdx,%rdi
    9187:	48 89 0c 24          	mov    %rcx,(%rsp)
    918b:	e8 20 d9 ff ff       	call   6ab0 <fwp_rc_free_arr>
    9190:	4c 8d 05 a9 06 06 00 	lea    0x606a9(%rip),%r8        # 69840 <fwp_heap>
    9197:	48 8b 04 24          	mov    (%rsp),%rax
    919b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    91a2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    91a9:	48 c1 e2 10          	shl    $0x10,%rdx
    91ad:	48 39 d0             	cmp    %rdx,%rax
    91b0:	0f 83 35 ff ff ff    	jae    90eb <fwp_drop2+0x8b>
    91b6:	48 8b 14 24          	mov    (%rsp),%rdx
    91ba:	e9 cd fe ff ff       	jmp    908c <fwp_drop2+0x2c>
    91bf:	90                   	nop
    91c0:	c3                   	ret
    91c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    91c8:	48 89 14 24          	mov    %rdx,(%rsp)
    91cc:	e8 df d8 ff ff       	call   6ab0 <fwp_rc_free_arr>
    91d1:	48 8b 14 24          	mov    (%rsp),%rdx
    91d5:	eb a9                	jmp    9180 <fwp_drop2+0x120>
    91d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    91de:	00 00 
    91e0:	66 85 c0             	test   %ax,%ax
    91e3:	75 9b                	jne    9180 <fwp_drop2+0x120>
    91e5:	e9 7a ff ff ff       	jmp    9164 <fwp_drop2+0x104>
    91ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    91f0:	48 89 c8             	mov    %rcx,%rax
    91f3:	48 c1 e8 11          	shr    $0x11,%rax
    91f7:	48 31 c8             	xor    %rcx,%rax
    91fa:	48 89 c2             	mov    %rax,%rdx
    91fd:	48 c1 ea 09          	shr    $0x9,%rdx
    9201:	48 31 d0             	xor    %rdx,%rax
    9204:	0f b6 d0             	movzbl %al,%edx
    9207:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    920e:	00 
    920f:	48 85 c0             	test   %rax,%rax
    9212:	75 19                	jne    922d <fwp_drop2+0x1cd>
    9214:	e9 d3 00 00 00       	jmp    92ec <fwp_drop2+0x28c>
    9219:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9220:	48 8b 42 10          	mov    0x10(%rdx),%rax
    9224:	48 85 c0             	test   %rax,%rax
    9227:	0f 84 bf 00 00 00    	je     92ec <fwp_drop2+0x28c>
    922d:	48 89 c2             	mov    %rax,%rdx
    9230:	48 39 08             	cmp    %rcx,(%rax)
    9233:	75 eb                	jne    9220 <fwp_drop2+0x1c0>
    9235:	48 8b 50 08          	mov    0x8(%rax),%rdx
    9239:	48 83 ea 01          	sub    $0x1,%rdx
    923d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    9241:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    9248:	0f 85 9d fe ff ff    	jne    90eb <fwp_drop2+0x8b>
    924e:	48 89 cf             	mov    %rcx,%rdi
    9251:	48 89 0c 24          	mov    %rcx,(%rsp)
    9255:	e8 76 c5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    925a:	48 8b 0c 24          	mov    (%rsp),%rcx
    925e:	c6 01 fe             	movb   $0xfe,(%rcx)
    9261:	e9 85 fe ff ff       	jmp    90eb <fwp_drop2+0x8b>
    9266:	48 89 ce             	mov    %rcx,%rsi
    9269:	48 c1 ee 11          	shr    $0x11,%rsi
    926d:	48 31 ce             	xor    %rcx,%rsi
    9270:	48 89 f0             	mov    %rsi,%rax
    9273:	48 c1 e8 09          	shr    $0x9,%rax
    9277:	48 31 c6             	xor    %rax,%rsi
    927a:	40 0f b6 f6          	movzbl %sil,%esi
    927e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    9285:	00 
    9286:	48 85 c0             	test   %rax,%rax
    9289:	75 1e                	jne    92a9 <fwp_drop2+0x249>
    928b:	eb 5f                	jmp    92ec <fwp_drop2+0x28c>
    928d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9294:	00 
    9295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    929c:	00 00 00 00 
    92a0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    92a4:	48 85 c0             	test   %rax,%rax
    92a7:	74 43                	je     92ec <fwp_drop2+0x28c>
    92a9:	48 89 c6             	mov    %rax,%rsi
    92ac:	48 39 08             	cmp    %rcx,(%rax)
    92af:	75 ef                	jne    92a0 <fwp_drop2+0x240>
    92b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    92b5:	48 83 ee 01          	sub    $0x1,%rsi
    92b9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    92bd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    92c4:	0f 85 b6 fe ff ff    	jne    9180 <fwp_drop2+0x120>
    92ca:	48 89 cf             	mov    %rcx,%rdi
    92cd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    92d2:	48 89 0c 24          	mov    %rcx,(%rsp)
    92d6:	e8 f5 c4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    92db:	48 8b 0c 24          	mov    (%rsp),%rcx
    92df:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    92e4:	c6 01 fe             	movb   $0xfe,(%rcx)
    92e7:	e9 94 fe ff ff       	jmp    9180 <fwp_drop2+0x120>
    92ec:	48 8d 3d ed 46 00 00 	lea    0x46ed(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    92f3:	e8 58 b1 ff ff       	call   4450 <fwp_trap>
    92f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    92ff:	00 

0000000000009300 <fwp_arg_drop23>:
    9300:	f3 0f 1e fa          	endbr64
    9304:	85 f6                	test   %esi,%esi
    9306:	75 04                	jne    930c <fwp_arg_drop23+0xc>
    9308:	85 d2                	test   %edx,%edx
    930a:	75 04                	jne    9310 <fwp_arg_drop23+0x10>
    930c:	c3                   	ret
    930d:	0f 1f 00             	nopl   (%rax)
    9310:	48 8b 3f             	mov    (%rdi),%rdi
    9313:	e9 48 fd ff ff       	jmp    9060 <fwp_drop2>
    9318:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    931f:	00 

0000000000009320 <f23>:
    9320:	41 57                	push   %r15
    9322:	41 56                	push   %r14
    9324:	41 55                	push   %r13
    9326:	41 54                	push   %r12
    9328:	55                   	push   %rbp
    9329:	53                   	push   %rbx
    932a:	48 83 ec 38          	sub    $0x38,%rsp
    932e:	48 8b 15 e3 18 06 00 	mov    0x618e3(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    9335:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    933a:	48 c1 e2 10          	shl    $0x10,%rdx
    933e:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    9345:	00 00 
    9347:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    934c:	48 8b 0d 9d 18 06 00 	mov    0x6189d(%rip),%rcx        # 6abf0 <fwp_heap+0x13b0>
    9353:	48 85 ff             	test   %rdi,%rdi
    9356:	0f 84 6e 03 00 00    	je     96ca <f23+0x3aa>
    935c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9361:	4c 8b 68 10          	mov    0x10(%rax),%r13
    9365:	4c 89 e8             	mov    %r13,%rax
    9368:	48 29 c8             	sub    %rcx,%rax
    936b:	48 39 d0             	cmp    %rdx,%rax
    936e:	0f 83 3c 03 00 00    	jae    96b0 <f23+0x390>
    9374:	48 89 c2             	mov    %rax,%rdx
    9377:	48 c1 ea 10          	shr    $0x10,%rdx
    937b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    937f:	48 8b 15 b2 18 06 00 	mov    0x618b2(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    9386:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    938a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    938e:	48 85 ff             	test   %rdi,%rdi
    9391:	0f 84 19 03 00 00    	je     96b0 <f23+0x390>
    9397:	0f b6 0a             	movzbl (%rdx),%ecx
    939a:	80 f9 02             	cmp    $0x2,%cl
    939d:	0f 84 9d 02 00 00    	je     9640 <f23+0x320>
    93a3:	80 f9 01             	cmp    $0x1,%cl
    93a6:	75 24                	jne    93cc <f23+0xac>
    93a8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    93ab:	0f b7 c0             	movzwl %ax,%eax
    93ae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    93b1:	48 0f af c1          	imul   %rcx,%rax
    93b5:	48 c1 e8 20          	shr    $0x20,%rax
    93b9:	48 39 d0             	cmp    %rdx,%rax
    93bc:	73 0e                	jae    93cc <f23+0xac>
    93be:	48 01 c7             	add    %rax,%rdi
    93c1:	0f b6 07             	movzbl (%rdi),%eax
    93c4:	84 c0                	test   %al,%al
    93c6:	0f 85 94 02 00 00    	jne    9660 <f23+0x340>
    93cc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    93d1:	48 8b 40 10          	mov    0x10(%rax),%rax
    93d5:	ba 01 00 00 00       	mov    $0x1,%edx
    93da:	48 85 c0             	test   %rax,%rax
    93dd:	74 0e                	je     93ed <f23+0xcd>
    93df:	90                   	nop
    93e0:	48 8b 40 10          	mov    0x10(%rax),%rax
    93e4:	48 83 c2 01          	add    $0x1,%rdx
    93e8:	48 85 c0             	test   %rax,%rax
    93eb:	75 f3                	jne    93e0 <f23+0xc0>
    93ed:	4d 85 ed             	test   %r13,%r13
    93f0:	0f 84 ea 02 00 00    	je     96e0 <f23+0x3c0>
    93f6:	4c 89 e8             	mov    %r13,%rax
    93f9:	31 db                	xor    %ebx,%ebx
    93fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9400:	48 8b 40 10          	mov    0x10(%rax),%rax
    9404:	48 83 c3 01          	add    $0x1,%rbx
    9408:	48 85 c0             	test   %rax,%rax
    940b:	75 f3                	jne    9400 <f23+0xe0>
    940d:	48 39 d3             	cmp    %rdx,%rbx
    9410:	48 0f 47 da          	cmova  %rdx,%rbx
    9414:	48 89 d8             	mov    %rbx,%rax
    9417:	48 c1 e8 3c          	shr    $0x3c,%rax
    941b:	0f 85 cd 03 00 00    	jne    97ee <f23+0x4ce>
    9421:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    9425:	be 02 00 00 00       	mov    $0x2,%esi
    942a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    9431:	00 
    9432:	e8 d9 ca ff ff       	call   5f10 <fwp_heap_alloc>
    9437:	48 89 28             	mov    %rbp,(%rax)
    943a:	48 8b 15 d7 17 06 00 	mov    0x617d7(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    9441:	49 89 c4             	mov    %rax,%r12
    9444:	48 2b 05 a5 17 06 00 	sub    0x617a5(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    944b:	48 c1 e2 10          	shl    $0x10,%rdx
    944f:	48 39 d0             	cmp    %rdx,%rax
    9452:	73 57                	jae    94ab <f23+0x18b>
    9454:	48 89 c2             	mov    %rax,%rdx
    9457:	48 c1 ea 10          	shr    $0x10,%rdx
    945b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    945f:	48 8b 15 d2 17 06 00 	mov    0x617d2(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    9466:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    946a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    946e:	48 85 ed             	test   %rbp,%rbp
    9471:	74 38                	je     94ab <f23+0x18b>
    9473:	0f b6 0a             	movzbl (%rdx),%ecx
    9476:	80 f9 02             	cmp    $0x2,%cl
    9479:	0f 84 21 02 00 00    	je     96a0 <f23+0x380>
    947f:	80 f9 01             	cmp    $0x1,%cl
    9482:	75 27                	jne    94ab <f23+0x18b>
    9484:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9487:	0f b7 c0             	movzwl %ax,%eax
    948a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    948d:	48 0f af c1          	imul   %rcx,%rax
    9491:	48 c1 e8 20          	shr    $0x20,%rax
    9495:	48 39 d0             	cmp    %rdx,%rax
    9498:	73 11                	jae    94ab <f23+0x18b>
    949a:	48 01 c5             	add    %rax,%rbp
    949d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    94a1:	0f 84 a7 02 00 00    	je     974e <f23+0x42e>
    94a7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    94ab:	48 85 db             	test   %rbx,%rbx
    94ae:	74 5d                	je     950d <f23+0x1ed>
    94b0:	48 c1 e3 04          	shl    $0x4,%rbx
    94b4:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    94b9:	4c 89 e5             	mov    %r12,%rbp
    94bc:	4d 89 ef             	mov    %r13,%r15
    94bf:	4c 01 e3             	add    %r12,%rbx
    94c2:	0f 1f 00             	nopl   (%rax)
    94c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    94cc:	00 00 00 00 
    94d0:	49 8b 46 08          	mov    0x8(%r14),%rax
    94d4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    94d8:	48 83 c5 10          	add    $0x10,%rbp
    94dc:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    94e1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    94e5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    94e9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    94ee:	e8 dd d1 ff ff       	call   66d0 <w107>
    94f3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    94f8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    94fc:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    9500:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    9504:	4d 8b 76 10          	mov    0x10(%r14),%r14
    9508:	48 39 eb             	cmp    %rbp,%rbx
    950b:	75 c3                	jne    94d0 <f23+0x1b0>
    950d:	4c 89 ef             	mov    %r13,%rdi
    9510:	31 db                	xor    %ebx,%ebx
    9512:	e8 49 fb ff ff       	call   9060 <fwp_drop2>
    9517:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    951c:	e8 3f fb ff ff       	call   9060 <fwp_drop2>
    9521:	4d 8b 2c 24          	mov    (%r12),%r13
    9525:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9529:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    9530:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    9537:	4d 85 ed             	test   %r13,%r13
    953a:	74 3f                	je     957b <f23+0x25b>
    953c:	0f 1f 40 00          	nopl   0x0(%rax)
    9540:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    9547:	49 8b 54 dc 10       	mov    0x10(%r12,%rbx,8),%rdx
    954c:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    9553:	00 f0 3f 
    9556:	48 83 c3 02          	add    $0x2,%rbx
    955a:	48 89 ce             	mov    %rcx,%rsi
    955d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    9563:	e8 e8 cd ff ff       	call   6350 <fwp_p_ad_push>
    9568:	4c 39 eb             	cmp    %r13,%rbx
    956b:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    9571:	48 89 c7             	mov    %rax,%rdi
    9574:	72 ca                	jb     9540 <f23+0x220>
    9576:	66 49 0f 7e c5       	movq   %xmm0,%r13
    957b:	4c 89 e7             	mov    %r12,%rdi
    957e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9583:	e8 78 e4 ff ff       	call   7a00 <fwp_drop4>
    9588:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    958d:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    9592:	31 ff                	xor    %edi,%edi
    9594:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    9599:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    959e:	e8 9d d2 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    95a3:	48 8b 15 6e 16 06 00 	mov    0x6166e(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    95aa:	48 89 c5             	mov    %rax,%rbp
    95ad:	48 2b 05 3c 16 06 00 	sub    0x6163c(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    95b4:	48 c1 e2 10          	shl    $0x10,%rdx
    95b8:	48 39 d0             	cmp    %rdx,%rax
    95bb:	73 55                	jae    9612 <f23+0x2f2>
    95bd:	48 89 c2             	mov    %rax,%rdx
    95c0:	48 c1 ea 10          	shr    $0x10,%rdx
    95c4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    95c8:	48 8b 15 69 16 06 00 	mov    0x61669(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    95cf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    95d3:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    95d7:	48 85 db             	test   %rbx,%rbx
    95da:	74 36                	je     9612 <f23+0x2f2>
    95dc:	0f b6 0a             	movzbl (%rdx),%ecx
    95df:	80 f9 02             	cmp    $0x2,%cl
    95e2:	0f 84 a8 00 00 00    	je     9690 <f23+0x370>
    95e8:	80 f9 01             	cmp    $0x1,%cl
    95eb:	75 25                	jne    9612 <f23+0x2f2>
    95ed:	8b 4a 18             	mov    0x18(%rdx),%ecx
    95f0:	0f b7 c0             	movzwl %ax,%eax
    95f3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    95f6:	48 0f af c1          	imul   %rcx,%rax
    95fa:	48 c1 e8 20          	shr    $0x20,%rax
    95fe:	48 39 d0             	cmp    %rdx,%rax
    9601:	73 0f                	jae    9612 <f23+0x2f2>
    9603:	48 01 c3             	add    %rax,%rbx
    9606:	80 3b ff             	cmpb   $0xff,(%rbx)
    9609:	0f 84 32 01 00 00    	je     9741 <f23+0x421>
    960f:	c6 03 01             	movb   $0x1,(%rbx)
    9612:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    9617:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    961e:	00 00 
    9620:	0f 85 d4 01 00 00    	jne    97fa <f23+0x4da>
    9626:	48 83 c4 38          	add    $0x38,%rsp
    962a:	48 89 e8             	mov    %rbp,%rax
    962d:	5b                   	pop    %rbx
    962e:	5d                   	pop    %rbp
    962f:	41 5c                	pop    %r12
    9631:	41 5d                	pop    %r13
    9633:	41 5e                	pop    %r14
    9635:	41 5f                	pop    %r15
    9637:	c3                   	ret
    9638:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    963f:	00 
    9640:	66 85 c0             	test   %ax,%ax
    9643:	0f 85 83 fd ff ff    	jne    93cc <f23+0xac>
    9649:	0f b6 07             	movzbl (%rdi),%eax
    964c:	84 c0                	test   %al,%al
    964e:	0f 84 78 fd ff ff    	je     93cc <f23+0xac>
    9654:	90                   	nop
    9655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    965c:	00 00 00 00 
    9660:	8b 15 a2 1e 06 00    	mov    0x61ea2(%rip),%edx        # 6b508 <iteration_active>
    9666:	85 d2                	test   %edx,%edx
    9668:	75 56                	jne    96c0 <f23+0x3a0>
    966a:	3c fd                	cmp    $0xfd,%al
    966c:	0f 87 4b 01 00 00    	ja     97bd <f23+0x49d>
    9672:	83 c0 01             	add    $0x1,%eax
    9675:	88 07                	mov    %al,(%rdi)
    9677:	31 d2                	xor    %edx,%edx
    9679:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    967f:	0f 85 47 fd ff ff    	jne    93cc <f23+0xac>
    9685:	e9 63 fd ff ff       	jmp    93ed <f23+0xcd>
    968a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9690:	66 85 c0             	test   %ax,%ax
    9693:	0f 85 79 ff ff ff    	jne    9612 <f23+0x2f2>
    9699:	e9 68 ff ff ff       	jmp    9606 <f23+0x2e6>
    969e:	66 90                	xchg   %ax,%ax
    96a0:	66 85 c0             	test   %ax,%ax
    96a3:	0f 85 02 fe ff ff    	jne    94ab <f23+0x18b>
    96a9:	e9 ef fd ff ff       	jmp    949d <f23+0x17d>
    96ae:	66 90                	xchg   %ax,%ax
    96b0:	4c 89 e8             	mov    %r13,%rax
    96b3:	e9 1d fd ff ff       	jmp    93d5 <f23+0xb5>
    96b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    96bf:	00 
    96c0:	48 83 05 28 1e 06 00 	addq   $0x1,0x61e28(%rip)        # 6b4f0 <iteration_retains>
    96c7:	01 
    96c8:	eb a0                	jmp    966a <f23+0x34a>
    96ca:	48 f7 d9             	neg    %rcx
    96cd:	48 39 d1             	cmp    %rdx,%rcx
    96d0:	0f 82 85 00 00 00    	jb     975b <f23+0x43b>
    96d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    96dd:	00 00 00 
    96e0:	be 02 00 00 00       	mov    $0x2,%esi
    96e5:	bf 08 00 00 00       	mov    $0x8,%edi
    96ea:	e8 21 c8 ff ff       	call   5f10 <fwp_heap_alloc>
    96ef:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    96f6:	48 8b 15 1b 15 06 00 	mov    0x6151b(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    96fd:	49 89 c4             	mov    %rax,%r12
    9700:	48 2b 05 e9 14 06 00 	sub    0x614e9(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    9707:	48 c1 e2 10          	shl    $0x10,%rdx
    970b:	48 39 d0             	cmp    %rdx,%rax
    970e:	0f 83 b3 00 00 00    	jae    97c7 <f23+0x4a7>
    9714:	48 89 c2             	mov    %rax,%rdx
    9717:	45 31 ed             	xor    %r13d,%r13d
    971a:	48 c1 ea 10          	shr    $0x10,%rdx
    971e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9722:	48 8b 15 0f 15 06 00 	mov    0x6150f(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    9729:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    972d:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9731:	48 85 ed             	test   %rbp,%rbp
    9734:	0f 84 d3 fd ff ff    	je     950d <f23+0x1ed>
    973a:	31 db                	xor    %ebx,%ebx
    973c:	e9 32 fd ff ff       	jmp    9473 <f23+0x153>
    9741:	48 89 df             	mov    %rbx,%rdi
    9744:	e8 87 c0 ff ff       	call   57d0 <fwp_rc_forget_slot>
    9749:	e9 c1 fe ff ff       	jmp    960f <f23+0x2ef>
    974e:	48 89 ef             	mov    %rbp,%rdi
    9751:	e8 7a c0 ff ff       	call   57d0 <fwp_rc_forget_slot>
    9756:	e9 4c fd ff ff       	jmp    94a7 <f23+0x187>
    975b:	48 89 c8             	mov    %rcx,%rax
    975e:	48 c1 e8 10          	shr    $0x10,%rax
    9762:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9766:	48 8b 05 cb 14 06 00 	mov    0x614cb(%rip),%rax        # 6ac38 <fwp_heap+0x13f8>
    976d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9771:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9775:	48 85 ff             	test   %rdi,%rdi
    9778:	0f 84 62 ff ff ff    	je     96e0 <f23+0x3c0>
    977e:	0f b6 02             	movzbl (%rdx),%eax
    9781:	3c 02                	cmp    $0x2,%al
    9783:	74 4a                	je     97cf <f23+0x4af>
    9785:	3c 01                	cmp    $0x1,%al
    9787:	0f 85 53 ff ff ff    	jne    96e0 <f23+0x3c0>
    978d:	0f b7 c1             	movzwl %cx,%eax
    9790:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9793:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9796:	48 0f af c1          	imul   %rcx,%rax
    979a:	48 c1 e8 20          	shr    $0x20,%rax
    979e:	48 39 d0             	cmp    %rdx,%rax
    97a1:	0f 83 39 ff ff ff    	jae    96e0 <f23+0x3c0>
    97a7:	48 01 c7             	add    %rax,%rdi
    97aa:	0f b6 07             	movzbl (%rdi),%eax
    97ad:	84 c0                	test   %al,%al
    97af:	0f 84 2b ff ff ff    	je     96e0 <f23+0x3c0>
    97b5:	45 31 ed             	xor    %r13d,%r13d
    97b8:	e9 a3 fe ff ff       	jmp    9660 <f23+0x340>
    97bd:	e8 ee be ff ff       	call   56b0 <fwp_rc_wide_dup>
    97c2:	e9 b0 fe ff ff       	jmp    9677 <f23+0x357>
    97c7:	45 31 ed             	xor    %r13d,%r13d
    97ca:	e9 3e fd ff ff       	jmp    950d <f23+0x1ed>
    97cf:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    97d5:	49 89 cd             	mov    %rcx,%r13
    97d8:	0f 85 02 ff ff ff    	jne    96e0 <f23+0x3c0>
    97de:	0f b6 07             	movzbl (%rdi),%eax
    97e1:	84 c0                	test   %al,%al
    97e3:	0f 85 77 fe ff ff    	jne    9660 <f23+0x340>
    97e9:	e9 f2 fe ff ff       	jmp    96e0 <f23+0x3c0>
    97ee:	48 8d 3d 10 3a 00 00 	lea    0x3a10(%rip),%rdi        # d205 <_IO_stdin_used+0x205>
    97f5:	e8 56 ac ff ff       	call   4450 <fwp_trap>
    97fa:	e8 51 9c ff ff       	call   3450 <__stack_chk_fail@plt>
    97ff:	90                   	nop

0000000000009800 <fwp_owned_entry23>:
    9800:	f3 0f 1e fa          	endbr64
    9804:	48 8b 3f             	mov    (%rdi),%rdi
    9807:	e9 14 fb ff ff       	jmp    9320 <f23>
    980c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009810 <e23>:
    9810:	f3 0f 1e fa          	endbr64
    9814:	53                   	push   %rbx
    9815:	48 8b 1f             	mov    (%rdi),%rbx
    9818:	48 89 df             	mov    %rbx,%rdi
    981b:	e8 10 d2 ff ff       	call   6a30 <fwp_rc_share>
    9820:	48 89 df             	mov    %rbx,%rdi
    9823:	e8 f8 fa ff ff       	call   9320 <f23>
    9828:	48 89 c3             	mov    %rax,%rbx
    982b:	48 89 c7             	mov    %rax,%rdi
    982e:	e8 fd d1 ff ff       	call   6a30 <fwp_rc_share>
    9833:	48 89 d8             	mov    %rbx,%rax
    9836:	5b                   	pop    %rbx
    9837:	c3                   	ret
    9838:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    983f:	00 

0000000000009840 <fwp_args12>:
    9840:	f3 0f 1e fa          	endbr64
    9844:	85 d2                	test   %edx,%edx
    9846:	74 04                	je     984c <fwp_args12+0xc>
    9848:	85 f6                	test   %esi,%esi
    984a:	74 04                	je     9850 <fwp_args12+0x10>
    984c:	c3                   	ret
    984d:	0f 1f 00             	nopl   (%rax)
    9850:	48 8b 15 c1 13 06 00 	mov    0x613c1(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    9857:	48 8b 07             	mov    (%rdi),%rax
    985a:	48 2b 05 8f 13 06 00 	sub    0x6138f(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    9861:	48 c1 e2 10          	shl    $0x10,%rdx
    9865:	48 39 d0             	cmp    %rdx,%rax
    9868:	73 e2                	jae    984c <fwp_args12+0xc>
    986a:	48 89 c2             	mov    %rax,%rdx
    986d:	48 c1 ea 10          	shr    $0x10,%rdx
    9871:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9875:	48 8b 15 bc 13 06 00 	mov    0x613bc(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    987c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9880:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9884:	48 85 ff             	test   %rdi,%rdi
    9887:	74 c3                	je     984c <fwp_args12+0xc>
    9889:	0f b6 0a             	movzbl (%rdx),%ecx
    988c:	80 f9 02             	cmp    $0x2,%cl
    988f:	74 4f                	je     98e0 <fwp_args12+0xa0>
    9891:	80 f9 01             	cmp    $0x1,%cl
    9894:	75 b6                	jne    984c <fwp_args12+0xc>
    9896:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9899:	0f b7 c0             	movzwl %ax,%eax
    989c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    989f:	48 0f af c1          	imul   %rcx,%rax
    98a3:	48 c1 e8 20          	shr    $0x20,%rax
    98a7:	48 39 d0             	cmp    %rdx,%rax
    98aa:	73 a0                	jae    984c <fwp_args12+0xc>
    98ac:	48 01 c7             	add    %rax,%rdi
    98af:	0f b6 07             	movzbl (%rdi),%eax
    98b2:	84 c0                	test   %al,%al
    98b4:	74 96                	je     984c <fwp_args12+0xc>
    98b6:	8b 15 4c 1c 06 00    	mov    0x61c4c(%rip),%edx        # 6b508 <iteration_active>
    98bc:	85 d2                	test   %edx,%edx
    98be:	75 10                	jne    98d0 <fwp_args12+0x90>
    98c0:	3c fd                	cmp    $0xfd,%al
    98c2:	77 22                	ja     98e6 <fwp_args12+0xa6>
    98c4:	83 c0 01             	add    $0x1,%eax
    98c7:	88 07                	mov    %al,(%rdi)
    98c9:	c3                   	ret
    98ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    98d0:	48 83 05 18 1c 06 00 	addq   $0x1,0x61c18(%rip)        # 6b4f0 <iteration_retains>
    98d7:	01 
    98d8:	eb e6                	jmp    98c0 <fwp_args12+0x80>
    98da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    98e0:	66 85 c0             	test   %ax,%ax
    98e3:	74 ca                	je     98af <fwp_args12+0x6f>
    98e5:	c3                   	ret
    98e6:	e9 c5 bd ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    98eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000098f0 <fwp_args23>:
    98f0:	f3 0f 1e fa          	endbr64
    98f4:	85 d2                	test   %edx,%edx
    98f6:	74 04                	je     98fc <fwp_args23+0xc>
    98f8:	85 f6                	test   %esi,%esi
    98fa:	74 04                	je     9900 <fwp_args23+0x10>
    98fc:	c3                   	ret
    98fd:	0f 1f 00             	nopl   (%rax)
    9900:	48 8b 15 11 13 06 00 	mov    0x61311(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    9907:	48 8b 07             	mov    (%rdi),%rax
    990a:	48 2b 05 df 12 06 00 	sub    0x612df(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    9911:	48 c1 e2 10          	shl    $0x10,%rdx
    9915:	48 39 d0             	cmp    %rdx,%rax
    9918:	73 e2                	jae    98fc <fwp_args23+0xc>
    991a:	48 89 c2             	mov    %rax,%rdx
    991d:	48 c1 ea 10          	shr    $0x10,%rdx
    9921:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9925:	48 8b 15 0c 13 06 00 	mov    0x6130c(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    992c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9930:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9934:	48 85 ff             	test   %rdi,%rdi
    9937:	74 c3                	je     98fc <fwp_args23+0xc>
    9939:	0f b6 0a             	movzbl (%rdx),%ecx
    993c:	80 f9 02             	cmp    $0x2,%cl
    993f:	74 4f                	je     9990 <fwp_args23+0xa0>
    9941:	80 f9 01             	cmp    $0x1,%cl
    9944:	75 b6                	jne    98fc <fwp_args23+0xc>
    9946:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9949:	0f b7 c0             	movzwl %ax,%eax
    994c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    994f:	48 0f af c1          	imul   %rcx,%rax
    9953:	48 c1 e8 20          	shr    $0x20,%rax
    9957:	48 39 d0             	cmp    %rdx,%rax
    995a:	73 a0                	jae    98fc <fwp_args23+0xc>
    995c:	48 01 c7             	add    %rax,%rdi
    995f:	0f b6 07             	movzbl (%rdi),%eax
    9962:	84 c0                	test   %al,%al
    9964:	74 96                	je     98fc <fwp_args23+0xc>
    9966:	8b 15 9c 1b 06 00    	mov    0x61b9c(%rip),%edx        # 6b508 <iteration_active>
    996c:	85 d2                	test   %edx,%edx
    996e:	75 10                	jne    9980 <fwp_args23+0x90>
    9970:	3c fd                	cmp    $0xfd,%al
    9972:	77 22                	ja     9996 <fwp_args23+0xa6>
    9974:	83 c0 01             	add    $0x1,%eax
    9977:	88 07                	mov    %al,(%rdi)
    9979:	c3                   	ret
    997a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9980:	48 83 05 68 1b 06 00 	addq   $0x1,0x61b68(%rip)        # 6b4f0 <iteration_retains>
    9987:	01 
    9988:	eb e6                	jmp    9970 <fwp_args23+0x80>
    998a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9990:	66 85 c0             	test   %ax,%ax
    9993:	74 ca                	je     995f <fwp_args23+0x6f>
    9995:	c3                   	ret
    9996:	e9 15 bd ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    999b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000099a0 <fwp_caps12>:
    99a0:	f3 0f 1e fa          	endbr64
    99a4:	48 83 ec 18          	sub    $0x18,%rsp
    99a8:	48 89 f8             	mov    %rdi,%rax
    99ab:	8b 7f 04             	mov    0x4(%rdi),%edi
    99ae:	85 ff                	test   %edi,%edi
    99b0:	0f 84 9a 00 00 00    	je     9a50 <fwp_caps12+0xb0>
    99b6:	48 8b 78 08          	mov    0x8(%rax),%rdi
    99ba:	85 f6                	test   %esi,%esi
    99bc:	0f 85 9e 00 00 00    	jne    9a60 <fwp_caps12+0xc0>
    99c2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    99c7:	e8 14 d4 ff ff       	call   6de0 <fwp_drop0>
    99cc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    99d1:	48 8b 0d 40 12 06 00 	mov    0x61240(%rip),%rcx        # 6ac18 <fwp_heap+0x13d8>
    99d8:	48 89 c2             	mov    %rax,%rdx
    99db:	48 2b 15 0e 12 06 00 	sub    0x6120e(%rip),%rdx        # 6abf0 <fwp_heap+0x13b0>
    99e2:	48 c1 e1 10          	shl    $0x10,%rcx
    99e6:	48 39 ca             	cmp    %rcx,%rdx
    99e9:	73 6d                	jae    9a58 <fwp_caps12+0xb8>
    99eb:	48 89 d1             	mov    %rdx,%rcx
    99ee:	48 c1 e9 10          	shr    $0x10,%rcx
    99f2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    99f6:	48 8b 0d 3b 12 06 00 	mov    0x6123b(%rip),%rcx        # 6ac38 <fwp_heap+0x13f8>
    99fd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    9a01:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    9a05:	48 85 f6             	test   %rsi,%rsi
    9a08:	74 4e                	je     9a58 <fwp_caps12+0xb8>
    9a0a:	0f b6 39             	movzbl (%rcx),%edi
    9a0d:	40 80 ff 02          	cmp    $0x2,%dil
    9a11:	0f 84 c9 00 00 00    	je     9ae0 <fwp_caps12+0x140>
    9a17:	40 80 ff 01          	cmp    $0x1,%dil
    9a1b:	75 3b                	jne    9a58 <fwp_caps12+0xb8>
    9a1d:	8b 79 18             	mov    0x18(%rcx),%edi
    9a20:	0f b7 d2             	movzwl %dx,%edx
    9a23:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9a26:	48 0f af d7          	imul   %rdi,%rdx
    9a2a:	48 c1 ea 20          	shr    $0x20,%rdx
    9a2e:	48 39 ca             	cmp    %rcx,%rdx
    9a31:	73 25                	jae    9a58 <fwp_caps12+0xb8>
    9a33:	48 01 d6             	add    %rdx,%rsi
    9a36:	80 3e 01             	cmpb   $0x1,(%rsi)
    9a39:	75 1d                	jne    9a58 <fwp_caps12+0xb8>
    9a3b:	48 89 c7             	mov    %rax,%rdi
    9a3e:	48 83 c4 18          	add    $0x18,%rsp
    9a42:	e9 c9 bf ff ff       	jmp    5a10 <fwp_mem_free>
    9a47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9a4e:	00 00 
    9a50:	85 f6                	test   %esi,%esi
    9a52:	0f 84 79 ff ff ff    	je     99d1 <fwp_caps12+0x31>
    9a58:	48 83 c4 18          	add    $0x18,%rsp
    9a5c:	c3                   	ret
    9a5d:	0f 1f 00             	nopl   (%rax)
    9a60:	48 8b 05 b1 11 06 00 	mov    0x611b1(%rip),%rax        # 6ac18 <fwp_heap+0x13d8>
    9a67:	48 2b 3d 82 11 06 00 	sub    0x61182(%rip),%rdi        # 6abf0 <fwp_heap+0x13b0>
    9a6e:	48 c1 e0 10          	shl    $0x10,%rax
    9a72:	48 39 c7             	cmp    %rax,%rdi
    9a75:	73 e1                	jae    9a58 <fwp_caps12+0xb8>
    9a77:	48 89 f8             	mov    %rdi,%rax
    9a7a:	48 c1 e8 10          	shr    $0x10,%rax
    9a7e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9a82:	48 8b 05 af 11 06 00 	mov    0x611af(%rip),%rax        # 6ac38 <fwp_heap+0x13f8>
    9a89:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9a8d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    9a91:	48 85 c0             	test   %rax,%rax
    9a94:	74 c2                	je     9a58 <fwp_caps12+0xb8>
    9a96:	0f b6 0a             	movzbl (%rdx),%ecx
    9a99:	80 f9 02             	cmp    $0x2,%cl
    9a9c:	74 52                	je     9af0 <fwp_caps12+0x150>
    9a9e:	80 f9 01             	cmp    $0x1,%cl
    9aa1:	75 b5                	jne    9a58 <fwp_caps12+0xb8>
    9aa3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9aa6:	0f b7 ff             	movzwl %di,%edi
    9aa9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9aac:	48 0f af f9          	imul   %rcx,%rdi
    9ab0:	48 c1 ef 20          	shr    $0x20,%rdi
    9ab4:	48 39 d7             	cmp    %rdx,%rdi
    9ab7:	73 9f                	jae    9a58 <fwp_caps12+0xb8>
    9ab9:	48 01 f8             	add    %rdi,%rax
    9abc:	0f b6 10             	movzbl (%rax),%edx
    9abf:	84 d2                	test   %dl,%dl
    9ac1:	74 95                	je     9a58 <fwp_caps12+0xb8>
    9ac3:	8b 0d 3f 1a 06 00    	mov    0x61a3f(%rip),%ecx        # 6b508 <iteration_active>
    9ac9:	85 c9                	test   %ecx,%ecx
    9acb:	75 33                	jne    9b00 <fwp_caps12+0x160>
    9acd:	80 fa fd             	cmp    $0xfd,%dl
    9ad0:	77 38                	ja     9b0a <fwp_caps12+0x16a>
    9ad2:	83 c2 01             	add    $0x1,%edx
    9ad5:	88 10                	mov    %dl,(%rax)
    9ad7:	e9 7c ff ff ff       	jmp    9a58 <fwp_caps12+0xb8>
    9adc:	0f 1f 40 00          	nopl   0x0(%rax)
    9ae0:	66 85 d2             	test   %dx,%dx
    9ae3:	0f 85 6f ff ff ff    	jne    9a58 <fwp_caps12+0xb8>
    9ae9:	e9 48 ff ff ff       	jmp    9a36 <fwp_caps12+0x96>
    9aee:	66 90                	xchg   %ax,%ax
    9af0:	66 85 ff             	test   %di,%di
    9af3:	0f 85 5f ff ff ff    	jne    9a58 <fwp_caps12+0xb8>
    9af9:	eb c1                	jmp    9abc <fwp_caps12+0x11c>
    9afb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9b00:	48 83 05 e8 19 06 00 	addq   $0x1,0x619e8(%rip)        # 6b4f0 <iteration_retains>
    9b07:	01 
    9b08:	eb c3                	jmp    9acd <fwp_caps12+0x12d>
    9b0a:	48 89 c7             	mov    %rax,%rdi
    9b0d:	48 83 c4 18          	add    $0x18,%rsp
    9b11:	e9 9a bb ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    9b16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9b1d:	00 00 00 

0000000000009b20 <fwp_caps23>:
    9b20:	f3 0f 1e fa          	endbr64
    9b24:	48 83 ec 18          	sub    $0x18,%rsp
    9b28:	48 89 f8             	mov    %rdi,%rax
    9b2b:	8b 7f 04             	mov    0x4(%rdi),%edi
    9b2e:	85 ff                	test   %edi,%edi
    9b30:	0f 84 9a 00 00 00    	je     9bd0 <fwp_caps23+0xb0>
    9b36:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9b3a:	85 f6                	test   %esi,%esi
    9b3c:	0f 85 9e 00 00 00    	jne    9be0 <fwp_caps23+0xc0>
    9b42:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9b47:	e8 14 f5 ff ff       	call   9060 <fwp_drop2>
    9b4c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9b51:	48 8b 0d c0 10 06 00 	mov    0x610c0(%rip),%rcx        # 6ac18 <fwp_heap+0x13d8>
    9b58:	48 89 c2             	mov    %rax,%rdx
    9b5b:	48 2b 15 8e 10 06 00 	sub    0x6108e(%rip),%rdx        # 6abf0 <fwp_heap+0x13b0>
    9b62:	48 c1 e1 10          	shl    $0x10,%rcx
    9b66:	48 39 ca             	cmp    %rcx,%rdx
    9b69:	73 6d                	jae    9bd8 <fwp_caps23+0xb8>
    9b6b:	48 89 d1             	mov    %rdx,%rcx
    9b6e:	48 c1 e9 10          	shr    $0x10,%rcx
    9b72:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    9b76:	48 8b 0d bb 10 06 00 	mov    0x610bb(%rip),%rcx        # 6ac38 <fwp_heap+0x13f8>
    9b7d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    9b81:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    9b85:	48 85 f6             	test   %rsi,%rsi
    9b88:	74 4e                	je     9bd8 <fwp_caps23+0xb8>
    9b8a:	0f b6 39             	movzbl (%rcx),%edi
    9b8d:	40 80 ff 02          	cmp    $0x2,%dil
    9b91:	0f 84 c9 00 00 00    	je     9c60 <fwp_caps23+0x140>
    9b97:	40 80 ff 01          	cmp    $0x1,%dil
    9b9b:	75 3b                	jne    9bd8 <fwp_caps23+0xb8>
    9b9d:	8b 79 18             	mov    0x18(%rcx),%edi
    9ba0:	0f b7 d2             	movzwl %dx,%edx
    9ba3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9ba6:	48 0f af d7          	imul   %rdi,%rdx
    9baa:	48 c1 ea 20          	shr    $0x20,%rdx
    9bae:	48 39 ca             	cmp    %rcx,%rdx
    9bb1:	73 25                	jae    9bd8 <fwp_caps23+0xb8>
    9bb3:	48 01 d6             	add    %rdx,%rsi
    9bb6:	80 3e 01             	cmpb   $0x1,(%rsi)
    9bb9:	75 1d                	jne    9bd8 <fwp_caps23+0xb8>
    9bbb:	48 89 c7             	mov    %rax,%rdi
    9bbe:	48 83 c4 18          	add    $0x18,%rsp
    9bc2:	e9 49 be ff ff       	jmp    5a10 <fwp_mem_free>
    9bc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9bce:	00 00 
    9bd0:	85 f6                	test   %esi,%esi
    9bd2:	0f 84 79 ff ff ff    	je     9b51 <fwp_caps23+0x31>
    9bd8:	48 83 c4 18          	add    $0x18,%rsp
    9bdc:	c3                   	ret
    9bdd:	0f 1f 00             	nopl   (%rax)
    9be0:	48 8b 05 31 10 06 00 	mov    0x61031(%rip),%rax        # 6ac18 <fwp_heap+0x13d8>
    9be7:	48 2b 3d 02 10 06 00 	sub    0x61002(%rip),%rdi        # 6abf0 <fwp_heap+0x13b0>
    9bee:	48 c1 e0 10          	shl    $0x10,%rax
    9bf2:	48 39 c7             	cmp    %rax,%rdi
    9bf5:	73 e1                	jae    9bd8 <fwp_caps23+0xb8>
    9bf7:	48 89 f8             	mov    %rdi,%rax
    9bfa:	48 c1 e8 10          	shr    $0x10,%rax
    9bfe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9c02:	48 8b 05 2f 10 06 00 	mov    0x6102f(%rip),%rax        # 6ac38 <fwp_heap+0x13f8>
    9c09:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9c0d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    9c11:	48 85 c0             	test   %rax,%rax
    9c14:	74 c2                	je     9bd8 <fwp_caps23+0xb8>
    9c16:	0f b6 0a             	movzbl (%rdx),%ecx
    9c19:	80 f9 02             	cmp    $0x2,%cl
    9c1c:	74 52                	je     9c70 <fwp_caps23+0x150>
    9c1e:	80 f9 01             	cmp    $0x1,%cl
    9c21:	75 b5                	jne    9bd8 <fwp_caps23+0xb8>
    9c23:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9c26:	0f b7 ff             	movzwl %di,%edi
    9c29:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9c2c:	48 0f af f9          	imul   %rcx,%rdi
    9c30:	48 c1 ef 20          	shr    $0x20,%rdi
    9c34:	48 39 d7             	cmp    %rdx,%rdi
    9c37:	73 9f                	jae    9bd8 <fwp_caps23+0xb8>
    9c39:	48 01 f8             	add    %rdi,%rax
    9c3c:	0f b6 10             	movzbl (%rax),%edx
    9c3f:	84 d2                	test   %dl,%dl
    9c41:	74 95                	je     9bd8 <fwp_caps23+0xb8>
    9c43:	8b 0d bf 18 06 00    	mov    0x618bf(%rip),%ecx        # 6b508 <iteration_active>
    9c49:	85 c9                	test   %ecx,%ecx
    9c4b:	75 33                	jne    9c80 <fwp_caps23+0x160>
    9c4d:	80 fa fd             	cmp    $0xfd,%dl
    9c50:	77 38                	ja     9c8a <fwp_caps23+0x16a>
    9c52:	83 c2 01             	add    $0x1,%edx
    9c55:	88 10                	mov    %dl,(%rax)
    9c57:	e9 7c ff ff ff       	jmp    9bd8 <fwp_caps23+0xb8>
    9c5c:	0f 1f 40 00          	nopl   0x0(%rax)
    9c60:	66 85 d2             	test   %dx,%dx
    9c63:	0f 85 6f ff ff ff    	jne    9bd8 <fwp_caps23+0xb8>
    9c69:	e9 48 ff ff ff       	jmp    9bb6 <fwp_caps23+0x96>
    9c6e:	66 90                	xchg   %ax,%ax
    9c70:	66 85 ff             	test   %di,%di
    9c73:	0f 85 5f ff ff ff    	jne    9bd8 <fwp_caps23+0xb8>
    9c79:	eb c1                	jmp    9c3c <fwp_caps23+0x11c>
    9c7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9c80:	48 83 05 68 18 06 00 	addq   $0x1,0x61868(%rip)        # 6b4f0 <iteration_retains>
    9c87:	01 
    9c88:	eb c3                	jmp    9c4d <fwp_caps23+0x12d>
    9c8a:	48 89 c7             	mov    %rax,%rdi
    9c8d:	48 83 c4 18          	add    $0x18,%rsp
    9c91:	e9 1a ba ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    9c96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9c9d:	00 00 00 

0000000000009ca0 <fwp_write>:
    9ca0:	41 57                	push   %r15
    9ca2:	41 56                	push   %r14
    9ca4:	41 55                	push   %r13
    9ca6:	41 54                	push   %r12
    9ca8:	55                   	push   %rbp
    9ca9:	53                   	push   %rbx
    9caa:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9cb1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9cb8:	00 00 
    9cba:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9cc1:	00 
    9cc2:	49 89 d4             	mov    %rdx,%r12
    9cc5:	8b 12                	mov    (%rdx),%edx
    9cc7:	83 fa 19             	cmp    $0x19,%edx
    9cca:	77 6a                	ja     9d36 <fwp_write+0x96>
    9ccc:	48 89 f5             	mov    %rsi,%rbp
    9ccf:	89 d0                	mov    %edx,%eax
    9cd1:	89 ce                	mov    %ecx,%esi
    9cd3:	48 89 fb             	mov    %rdi,%rbx
    9cd6:	48 8d 0d e3 3f 00 00 	lea    0x3fe3(%rip),%rcx        # dcc0 <_IO_stdin_used+0xcc0>
    9cdd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9ce1:	48 01 c8             	add    %rcx,%rax
    9ce4:	3e ff e0             	notrack jmp *%rax
    9ce7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9cee:	00 00 
    9cf0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9cf4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9cf8:	48 89 ca             	mov    %rcx,%rdx
    9cfb:	48 85 c9             	test   %rcx,%rcx
    9cfe:	0f 88 9c 0c 00 00    	js     a9a0 <fwp_write+0xd00>
    9d04:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9d0b:	00 
    9d0c:	48 89 c6             	mov    %rax,%rsi
    9d0f:	4c 89 e7             	mov    %r12,%rdi
    9d12:	e8 29 9d ff ff       	call   3a40 <fwp_fmt_u128>
    9d17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9d1e:	00 00 
    9d20:	4c 89 e7             	mov    %r12,%rdi
    9d23:	e8 18 97 ff ff       	call   3440 <strlen@plt>
    9d28:	4c 89 e6             	mov    %r12,%rsi
    9d2b:	48 89 df             	mov    %rbx,%rdi
    9d2e:	48 89 c2             	mov    %rax,%rdx
    9d31:	e8 ba a3 ff ff       	call   40f0 <buf_put>
    9d36:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9d3d:	00 
    9d3e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9d45:	00 00 
    9d47:	0f 85 28 04 00 00    	jne    a175 <fwp_write+0x4d5>
    9d4d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9d54:	5b                   	pop    %rbx
    9d55:	5d                   	pop    %rbp
    9d56:	41 5c                	pop    %r12
    9d58:	41 5d                	pop    %r13
    9d5a:	41 5e                	pop    %r14
    9d5c:	41 5f                	pop    %r15
    9d5e:	c3                   	ret
    9d5f:	90                   	nop
    9d60:	49 89 e9             	mov    %rbp,%r9
    9d63:	4c 8d 05 f1 34 00 00 	lea    0x34f1(%rip),%r8        # d25b <_IO_stdin_used+0x25b>
    9d6a:	b9 00 02 00 00       	mov    $0x200,%ecx
    9d6f:	ba 02 00 00 00       	mov    $0x2,%edx
    9d74:	be 00 02 00 00       	mov    $0x200,%esi
    9d79:	31 c0                	xor    %eax,%eax
    9d7b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9d82:	00 
    9d83:	e8 18 96 ff ff       	call   33a0 <__snprintf_chk@plt>
    9d88:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9d8f:	00 
    9d90:	e8 ab 96 ff ff       	call   3440 <strlen@plt>
    9d95:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9d9c:	00 
    9d9d:	48 89 df             	mov    %rbx,%rdi
    9da0:	48 89 c2             	mov    %rax,%rdx
    9da3:	e8 48 a3 ff ff       	call   40f0 <buf_put>
    9da8:	eb 8c                	jmp    9d36 <fwp_write+0x96>
    9daa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9db0:	49 89 e9             	mov    %rbp,%r9
    9db3:	4c 8d 05 9c 34 00 00 	lea    0x349c(%rip),%r8        # d256 <_IO_stdin_used+0x256>
    9dba:	eb ae                	jmp    9d6a <fwp_write+0xca>
    9dbc:	0f 1f 40 00          	nopl   0x0(%rax)
    9dc0:	83 fa 13             	cmp    $0x13,%edx
    9dc3:	48 8d 05 82 34 00 00 	lea    0x3482(%rip),%rax        # d24c <_IO_stdin_used+0x24c>
    9dca:	48 8d 35 80 34 00 00 	lea    0x3480(%rip),%rsi        # d251 <_IO_stdin_used+0x251>
    9dd1:	ba 04 00 00 00       	mov    $0x4,%edx
    9dd6:	48 0f 44 f0          	cmove  %rax,%rsi
    9dda:	45 31 ed             	xor    %r13d,%r13d
    9ddd:	e8 0e a3 ff ff       	call   40f0 <buf_put>
    9de2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9de7:	0f 84 a3 08 00 00    	je     a690 <fwp_write+0x9f0>
    9ded:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9df2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9df7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9dfc:	48 89 df             	mov    %rbx,%rdi
    9dff:	49 0f 44 c5          	cmove  %r13,%rax
    9e03:	31 c9                	xor    %ecx,%ecx
    9e05:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    9e0a:	e8 91 fe ff ff       	call   9ca0 <fwp_write>
    9e0f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9e14:	0f 84 6e 09 00 00    	je     a788 <fwp_write+0xae8>
    9e1a:	49 83 c5 01          	add    $0x1,%r13
    9e1e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9e22:	0f 83 68 08 00 00    	jae    a690 <fwp_write+0x9f0>
    9e28:	ba 02 00 00 00       	mov    $0x2,%edx
    9e2d:	48 8d 35 67 34 00 00 	lea    0x3467(%rip),%rsi        # d29b <_IO_stdin_used+0x29b>
    9e34:	48 89 df             	mov    %rbx,%rdi
    9e37:	e8 b4 a2 ff ff       	call   40f0 <buf_put>
    9e3c:	eb af                	jmp    9ded <fwp_write+0x14d>
    9e3e:	66 90                	xchg   %ax,%ax
    9e40:	ba 06 00 00 00       	mov    $0x6,%edx
    9e45:	48 8d 35 28 34 00 00 	lea    0x3428(%rip),%rsi        # d274 <_IO_stdin_used+0x274>
    9e4c:	48 83 c5 10          	add    $0x10,%rbp
    9e50:	e8 9b a2 ff ff       	call   40f0 <buf_put>
    9e55:	48 89 ef             	mov    %rbp,%rdi
    9e58:	e8 e3 95 ff ff       	call   3440 <strlen@plt>
    9e5d:	48 89 ee             	mov    %rbp,%rsi
    9e60:	48 89 df             	mov    %rbx,%rdi
    9e63:	48 89 c2             	mov    %rax,%rdx
    9e66:	e8 85 a2 ff ff       	call   40f0 <buf_put>
    9e6b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9e70:	ba 01 00 00 00       	mov    $0x1,%edx
    9e75:	48 89 df             	mov    %rbx,%rdi
    9e78:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9e7d:	e8 6e a2 ff ff       	call   40f0 <buf_put>
    9e82:	e9 af fe ff ff       	jmp    9d36 <fwp_write+0x96>
    9e87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9e8e:	00 00 
    9e90:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9e97:	00 
    9e98:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9e9f:	00 00 
    9ea1:	0f 85 ce 02 00 00    	jne    a175 <fwp_write+0x4d5>
    9ea7:	ba 0a 00 00 00       	mov    $0xa,%edx
    9eac:	48 8d 35 ad 33 00 00 	lea    0x33ad(%rip),%rsi        # d260 <_IO_stdin_used+0x260>
    9eb3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9eba:	48 89 df             	mov    %rbx,%rdi
    9ebd:	5b                   	pop    %rbx
    9ebe:	5d                   	pop    %rbp
    9ebf:	41 5c                	pop    %r12
    9ec1:	41 5d                	pop    %r13
    9ec3:	41 5e                	pop    %r14
    9ec5:	41 5f                	pop    %r15
    9ec7:	e9 24 a2 ff ff       	jmp    40f0 <buf_put>
    9ecc:	0f 1f 40 00          	nopl   0x0(%rax)
    9ed0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    9ed5:	4d 85 ed             	test   %r13,%r13
    9ed8:	0f 84 02 0c 00 00    	je     aae0 <fwp_write+0xe40>
    9ede:	48 8d 35 c3 33 00 00 	lea    0x33c3(%rip),%rsi        # d2a8 <_IO_stdin_used+0x2a8>
    9ee5:	4c 89 ef             	mov    %r13,%rdi
    9ee8:	e8 33 96 ff ff       	call   3520 <strcmp@plt>
    9eed:	41 89 c1             	mov    %eax,%r9d
    9ef0:	85 c0                	test   %eax,%eax
    9ef2:	0f 84 6c 0c 00 00    	je     ab64 <fwp_write+0xec4>
    9ef8:	4c 89 ef             	mov    %r13,%rdi
    9efb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9f00:	e8 3b 95 ff ff       	call   3440 <strlen@plt>
    9f05:	4c 89 ee             	mov    %r13,%rsi
    9f08:	48 89 df             	mov    %rbx,%rdi
    9f0b:	48 89 c2             	mov    %rax,%rdx
    9f0e:	e8 dd a1 ff ff       	call   40f0 <buf_put>
    9f13:	ba 01 00 00 00       	mov    $0x1,%edx
    9f18:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9f1d:	48 89 df             	mov    %rbx,%rdi
    9f20:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9f25:	e8 c6 a1 ff ff       	call   40f0 <buf_put>
    9f2a:	ba 01 00 00 00       	mov    $0x1,%edx
    9f2f:	4c 89 fe             	mov    %r15,%rsi
    9f32:	48 89 df             	mov    %rbx,%rdi
    9f35:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    9f3a:	e8 b1 a1 ff ff       	call   40f0 <buf_put>
    9f3f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9f44:	45 31 f6             	xor    %r14d,%r14d
    9f47:	85 d2                	test   %edx,%edx
    9f49:	0f 8e 81 0a 00 00    	jle    a9d0 <fwp_write+0xd30>
    9f4f:	45 31 ed             	xor    %r13d,%r13d
    9f52:	4d 85 ed             	test   %r13,%r13
    9f55:	0f 85 75 07 00 00    	jne    a6d0 <fwp_write+0xa30>
    9f5b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9f62:	00 
    9f63:	45 85 f6             	test   %r14d,%r14d
    9f66:	0f 84 84 07 00 00    	je     a6f0 <fwp_write+0xa50>
    9f6c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    9f71:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    9f76:	48 89 df             	mov    %rbx,%rdi
    9f79:	49 83 c5 01          	add    $0x1,%r13
    9f7d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    9f81:	31 c9                	xor    %ecx,%ecx
    9f83:	e8 18 fd ff ff       	call   9ca0 <fwp_write>
    9f88:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    9f8d:	7f c3                	jg     9f52 <fwp_write+0x2b2>
    9f8f:	45 85 f6             	test   %r14d,%r14d
    9f92:	0f 84 38 0a 00 00    	je     a9d0 <fwp_write+0xd30>
    9f98:	b8 29 00 00 00       	mov    $0x29,%eax
    9f9d:	ba 01 00 00 00       	mov    $0x1,%edx
    9fa2:	4c 89 fe             	mov    %r15,%rsi
    9fa5:	48 89 df             	mov    %rbx,%rdi
    9fa8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    9fac:	e8 3f a1 ff ff       	call   40f0 <buf_put>
    9fb1:	e9 80 fd ff ff       	jmp    9d36 <fwp_write+0x96>
    9fb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9fbd:	00 00 00 
    9fc0:	ba 01 00 00 00       	mov    $0x1,%edx
    9fc5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9fca:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    9fcf:	e8 1c a1 ff ff       	call   40f0 <buf_put>
    9fd4:	48 85 ed             	test   %rbp,%rbp
    9fd7:	0f 84 93 06 00 00    	je     a670 <fwp_write+0x9d0>
    9fdd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    9fe1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9fe6:	31 c9                	xor    %ecx,%ecx
    9fe8:	48 89 df             	mov    %rbx,%rdi
    9feb:	e8 b0 fc ff ff       	call   9ca0 <fwp_write>
    9ff0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    9ff4:	48 85 ed             	test   %rbp,%rbp
    9ff7:	0f 84 73 06 00 00    	je     a670 <fwp_write+0x9d0>
    9ffd:	ba 02 00 00 00       	mov    $0x2,%edx
    a002:	48 8d 35 92 32 00 00 	lea    0x3292(%rip),%rsi        # d29b <_IO_stdin_used+0x29b>
    a009:	48 89 df             	mov    %rbx,%rdi
    a00c:	e8 df a0 ff ff       	call   40f0 <buf_put>
    a011:	eb ca                	jmp    9fdd <fwp_write+0x33d>
    a013:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a018:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    a01c:	85 f6                	test   %esi,%esi
    a01e:	0f 84 fc 07 00 00    	je     a820 <fwp_write+0xb80>
    a024:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a02b:	00 
    a02c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a033:	00 00 
    a035:	0f 85 3a 01 00 00    	jne    a175 <fwp_write+0x4d5>
    a03b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    a03f:	4c 89 ea             	mov    %r13,%rdx
    a042:	e9 6c fe ff ff       	jmp    9eb3 <fwp_write+0x213>
    a047:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a04e:	00 00 
    a050:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    a055:	ba 01 00 00 00       	mov    $0x1,%edx
    a05a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    a05f:	48 89 ee             	mov    %rbp,%rsi
    a062:	e8 89 a0 ff ff       	call   40f0 <buf_put>
    a067:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    a06c:	4c 89 e7             	mov    %r12,%rdi
    a06f:	e8 cc 93 ff ff       	call   3440 <strlen@plt>
    a074:	4c 89 e6             	mov    %r12,%rsi
    a077:	48 89 df             	mov    %rbx,%rdi
    a07a:	48 89 c2             	mov    %rax,%rdx
    a07d:	e8 6e a0 ff ff       	call   40f0 <buf_put>
    a082:	ba 01 00 00 00       	mov    $0x1,%edx
    a087:	48 89 ee             	mov    %rbp,%rsi
    a08a:	48 89 df             	mov    %rbx,%rdi
    a08d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a092:	e8 59 a0 ff ff       	call   40f0 <buf_put>
    a097:	e9 9a fc ff ff       	jmp    9d36 <fwp_write+0x96>
    a09c:	0f 1f 40 00          	nopl   0x0(%rax)
    a0a0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    a0a5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    a0a9:	0f 8a 8e 0b 00 00    	jp     ac3d <fwp_write+0xf9d>
    a0af:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a0b3:	66 0f 54 05 05 3d 00 	andpd  0x3d05(%rip),%xmm0        # ddc0 <msg.4+0x90>
    a0ba:	00 
    a0bb:	bd 01 00 00 00       	mov    $0x1,%ebp
    a0c0:	66 0f 2e 05 30 3d 00 	ucomisd 0x3d30(%rip),%xmm0        # ddf8 <msg.4+0xc8>
    a0c7:	00 
    a0c8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a0cf:	00 
    a0d0:	0f 87 b2 09 00 00    	ja     aa88 <fwp_write+0xde8>
    a0d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a0dd:	00 00 00 
    a0e0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a0e4:	89 ee                	mov    %ebp,%esi
    a0e6:	4c 89 e7             	mov    %r12,%rdi
    a0e9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    a0ee:	e8 7d a6 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a0f3:	31 f6                	xor    %esi,%esi
    a0f5:	4c 89 e7             	mov    %r12,%rdi
    a0f8:	e8 03 93 ff ff       	call   3400 <strtod@plt>
    a0fd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    a102:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    a106:	7a 06                	jp     a10e <fwp_write+0x46e>
    a108:	0f 84 e9 01 00 00    	je     a2f7 <fwp_write+0x657>
    a10e:	83 c5 01             	add    $0x1,%ebp
    a111:	83 fd 12             	cmp    $0x12,%ebp
    a114:	75 ca                	jne    a0e0 <fwp_write+0x440>
    a116:	be 11 00 00 00       	mov    $0x11,%esi
    a11b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a11f:	4c 89 e7             	mov    %r12,%rdi
    a122:	e8 49 a6 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a127:	e9 cb 01 00 00       	jmp    a2f7 <fwp_write+0x657>
    a12c:	0f 1f 40 00          	nopl   0x0(%rax)
    a130:	48 83 fd 01          	cmp    $0x1,%rbp
    a134:	0f 84 e6 08 00 00    	je     aa20 <fwp_write+0xd80>
    a13a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    a13e:	b8 02 00 00 00       	mov    $0x2,%eax
    a143:	ba 01 00 00 00       	mov    $0x1,%edx
    a148:	48 0f 44 d0          	cmove  %rax,%rdx
    a14c:	48 8d 35 f1 30 00 00 	lea    0x30f1(%rip),%rsi        # d244 <_IO_stdin_used+0x244>
    a153:	48 8d 05 ef 30 00 00 	lea    0x30ef(%rip),%rax        # d249 <_IO_stdin_used+0x249>
    a15a:	48 0f 44 f0          	cmove  %rax,%rsi
    a15e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a165:	00 
    a166:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a16d:	00 00 
    a16f:	0f 84 3e fd ff ff    	je     9eb3 <fwp_write+0x213>
    a175:	e8 d6 92 ff ff       	call   3450 <__stack_chk_fail@plt>
    a17a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a180:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    a185:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    a18a:	e8 a1 9e ff ff       	call   4030 <buf_grow>
    a18f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    a193:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    a199:	4c 03 0b             	add    (%rbx),%r9
    a19c:	66 45 89 11          	mov    %r10w,(%r9)
    a1a0:	45 85 e4             	test   %r12d,%r12d
    a1a3:	0f 8e 07 05 00 00    	jle    a6b0 <fwp_write+0xa10>
    a1a9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    a1b0:	55 55 55 
    a1b3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    a1b8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    a1bf:	aa aa aa 
    a1c2:	49 83 c1 01          	add    $0x1,%r9
    a1c6:	eb 45                	jmp    a20d <fwp_write+0x56d>
    a1c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a1cf:	00 
    a1d0:	be 01 00 00 00       	mov    $0x1,%esi
    a1d5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    a1da:	88 07                	mov    %al,(%rdi)
    a1dc:	48 89 e8             	mov    %rbp,%rax
    a1df:	49 f7 e8             	imul   %r8
    a1e2:	48 89 e8             	mov    %rbp,%rax
    a1e5:	48 c1 f8 3f          	sar    $0x3f,%rax
    a1e9:	48 29 c2             	sub    %rax,%rdx
    a1ec:	48 85 c9             	test   %rcx,%rcx
    a1ef:	0f 95 c0             	setne  %al
    a1f2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    a1f6:	48 83 ef 01          	sub    $0x1,%rdi
    a1fa:	48 21 c5             	and    %rax,%rbp
    a1fd:	48 29 ea             	sub    %rbp,%rdx
    a200:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    a204:	49 39 f9             	cmp    %rdi,%r9
    a207:	0f 84 a3 04 00 00    	je     a6b0 <fwp_write+0xa10>
    a20d:	48 89 e8             	mov    %rbp,%rax
    a210:	49 f7 e8             	imul   %r8
    a213:	48 89 e8             	mov    %rbp,%rax
    a216:	48 c1 f8 3f          	sar    $0x3f,%rax
    a21a:	48 89 d1             	mov    %rdx,%rcx
    a21d:	48 29 c1             	sub    %rax,%rcx
    a220:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a224:	48 89 e9             	mov    %rbp,%rcx
    a227:	48 29 c1             	sub    %rax,%rcx
    a22a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a22e:	49 f7 e2             	mul    %r10
    a231:	b8 30 00 00 00       	mov    $0x30,%eax
    a236:	48 89 d6             	mov    %rdx,%rsi
    a239:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a23d:	48 d1 ee             	shr    $1,%rsi
    a240:	48 01 f2             	add    %rsi,%rdx
    a243:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a247:	48 29 d6             	sub    %rdx,%rsi
    a24a:	74 8e                	je     a1da <fwp_write+0x53a>
    a24c:	48 83 fe 01          	cmp    $0x1,%rsi
    a250:	0f 85 7a ff ff ff    	jne    a1d0 <fwp_write+0x530>
    a256:	31 f6                	xor    %esi,%esi
    a258:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a25d:	e9 78 ff ff ff       	jmp    a1da <fwp_write+0x53a>
    a262:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a268:	66 0f 6e cd          	movd   %ebp,%xmm1
    a26c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a26f:	0f 8a c8 09 00 00    	jp     ac3d <fwp_write+0xf9d>
    a275:	0f 28 c1             	movaps %xmm1,%xmm0
    a278:	0f 54 05 31 3b 00 00 	andps  0x3b31(%rip),%xmm0        # ddb0 <msg.4+0x80>
    a27f:	0f 2e 05 7e 2d 00 00 	ucomiss 0x2d7e(%rip),%xmm0        # d004 <_IO_stdin_used+0x4>
    a286:	0f 87 24 08 00 00    	ja     aab0 <fwp_write+0xe10>
    a28c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a290:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a296:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a29d:	00 
    a29e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a2a2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a2a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a2ae:	00 00 
    a2b0:	44 89 ee             	mov    %r13d,%esi
    a2b3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a2b8:	4c 89 e7             	mov    %r12,%rdi
    a2bb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a2c0:	e8 ab a4 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a2c5:	31 f6                	xor    %esi,%esi
    a2c7:	4c 89 e7             	mov    %r12,%rdi
    a2ca:	e8 d1 91 ff ff       	call   34a0 <strtof@plt>
    a2cf:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a2d4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a2d7:	7a 02                	jp     a2db <fwp_write+0x63b>
    a2d9:	74 1c                	je     a2f7 <fwp_write+0x657>
    a2db:	41 83 c5 01          	add    $0x1,%r13d
    a2df:	41 83 fd 0a          	cmp    $0xa,%r13d
    a2e3:	75 cb                	jne    a2b0 <fwp_write+0x610>
    a2e5:	be 09 00 00 00       	mov    $0x9,%esi
    a2ea:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a2ef:	4c 89 e7             	mov    %r12,%rdi
    a2f2:	e8 79 a4 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a2f7:	4c 89 e7             	mov    %r12,%rdi
    a2fa:	e8 b1 9e ff ff       	call   41b0 <fwp_finish_float>
    a2ff:	e9 1c fa ff ff       	jmp    9d20 <fwp_write+0x80>
    a304:	0f 1f 40 00          	nopl   0x0(%rax)
    a308:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a30c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a310:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a317:	00 
    a318:	48 89 ef             	mov    %rbp,%rdi
    a31b:	e8 20 97 ff ff       	call   3a40 <fwp_fmt_u128>
    a320:	48 89 ef             	mov    %rbp,%rdi
    a323:	e8 18 91 ff ff       	call   3440 <strlen@plt>
    a328:	48 89 ee             	mov    %rbp,%rsi
    a32b:	48 89 df             	mov    %rbx,%rdi
    a32e:	48 89 c2             	mov    %rax,%rdx
    a331:	e8 ba 9d ff ff       	call   40f0 <buf_put>
    a336:	e9 fb f9 ff ff       	jmp    9d36 <fwp_write+0x96>
    a33b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a340:	ba 06 00 00 00       	mov    $0x6,%edx
    a345:	48 8d 35 52 2f 00 00 	lea    0x2f52(%rip),%rsi        # d29e <_IO_stdin_used+0x29e>
    a34c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a352:	e8 99 9d ff ff       	call   40f0 <buf_put>
    a357:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a35e:	ff ff 7f 
    a361:	48 23 55 00          	and    0x0(%rbp),%rdx
    a365:	0f 84 86 02 00 00    	je     a5f1 <fwp_write+0x951>
    a36b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a370:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a374:	48 85 d2             	test   %rdx,%rdx
    a377:	0f 84 ae 00 00 00    	je     a42b <fwp_write+0x78b>
    a37d:	8b 0a                	mov    (%rdx),%ecx
    a37f:	83 f9 1c             	cmp    $0x1c,%ecx
    a382:	0f 84 58 06 00 00    	je     a9e0 <fwp_write+0xd40>
    a388:	83 f9 1b             	cmp    $0x1b,%ecx
    a38b:	0f 87 9a 00 00 00    	ja     a42b <fwp_write+0x78b>
    a391:	be 01 00 00 00       	mov    $0x1,%esi
    a396:	48 d3 e6             	shl    %cl,%rsi
    a399:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a39f:	0f 85 4b 04 00 00    	jne    a7f0 <fwp_write+0xb50>
    a3a5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a3ab:	0f 85 0f 04 00 00    	jne    a7c0 <fwp_write+0xb20>
    a3b1:	83 e6 21             	and    $0x21,%esi
    a3b4:	74 75                	je     a42b <fwp_write+0x78b>
    a3b6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a3bb:	48 85 ff             	test   %rdi,%rdi
    a3be:	79 07                	jns    a3c7 <fwp_write+0x727>
    a3c0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a3c4:	4c 01 ee             	add    %r13,%rsi
    a3c7:	48 0f be 3e          	movsbq (%rsi),%rdi
    a3cb:	85 c9                	test   %ecx,%ecx
    a3cd:	40 0f b6 f7          	movzbl %dil,%esi
    a3d1:	48 0f 44 f7          	cmove  %rdi,%rsi
    a3d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a3dc:	00 00 00 00 
    a3e0:	31 c9                	xor    %ecx,%ecx
    a3e2:	48 89 df             	mov    %rbx,%rdi
    a3e5:	49 83 c5 01          	add    $0x1,%r13
    a3e9:	e8 b2 f8 ff ff       	call   9ca0 <fwp_write>
    a3ee:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a3f5:	ff ff 7f 
    a3f8:	48 23 55 00          	and    0x0(%rbp),%rdx
    a3fc:	49 39 d5             	cmp    %rdx,%r13
    a3ff:	0f 83 ec 01 00 00    	jae    a5f1 <fwp_write+0x951>
    a405:	ba 02 00 00 00       	mov    $0x2,%edx
    a40a:	48 89 df             	mov    %rbx,%rdi
    a40d:	48 8d 35 87 2e 00 00 	lea    0x2e87(%rip),%rsi        # d29b <_IO_stdin_used+0x29b>
    a414:	e8 d7 9c ff ff       	call   40f0 <buf_put>
    a419:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a41e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a422:	48 85 d2             	test   %rdx,%rdx
    a425:	0f 85 52 ff ff ff    	jne    a37d <fwp_write+0x6dd>
    a42b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a430:	48 85 ff             	test   %rdi,%rdi
    a433:	0f 88 cf 05 00 00    	js     aa08 <fwp_write+0xd68>
    a439:	48 8b 31             	mov    (%rcx),%rsi
    a43c:	eb a2                	jmp    a3e0 <fwp_write+0x740>
    a43e:	66 90                	xchg   %ax,%ax
    a440:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a447:	00 
    a448:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a44f:	00 00 
    a451:	0f 85 1e fd ff ff    	jne    a175 <fwp_write+0x4d5>
    a457:	ba 08 00 00 00       	mov    $0x8,%edx
    a45c:	48 8d 35 08 2e 00 00 	lea    0x2e08(%rip),%rsi        # d26b <_IO_stdin_used+0x26b>
    a463:	e9 4b fa ff ff       	jmp    9eb3 <fwp_write+0x213>
    a468:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a46f:	00 
    a470:	89 e8                	mov    %ebp,%eax
    a472:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a479:	76 03                	jbe    a47e <fwp_write+0x7de>
    a47b:	8b 45 00             	mov    0x0(%rbp),%eax
    a47e:	41 89 c6             	mov    %eax,%r14d
    a481:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a486:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a48b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a48f:	4c 89 ef             	mov    %r13,%rdi
    a492:	e8 a9 8f ff ff       	call   3440 <strlen@plt>
    a497:	4c 89 ee             	mov    %r13,%rsi
    a49a:	48 89 df             	mov    %rbx,%rdi
    a49d:	48 89 c2             	mov    %rax,%rdx
    a4a0:	e8 4b 9c ff ff       	call   40f0 <buf_put>
    a4a5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a4aa:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a4ae:	85 f6                	test   %esi,%esi
    a4b0:	0f 8e 80 f8 ff ff    	jle    9d36 <fwp_write+0x96>
    a4b6:	45 31 ed             	xor    %r13d,%r13d
    a4b9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a4be:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a4c3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a4c8:	ba 01 00 00 00       	mov    $0x1,%edx
    a4cd:	4c 89 fe             	mov    %r15,%rsi
    a4d0:	48 89 04 24          	mov    %rax,(%rsp)
    a4d4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a4d9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a4dd:	48 89 df             	mov    %rbx,%rdi
    a4e0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a4e4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a4e9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a4ee:	e8 fd 9b ff ff       	call   40f0 <buf_put>
    a4f3:	41 8b 06             	mov    (%r14),%eax
    a4f6:	83 f8 0e             	cmp    $0xe,%eax
    a4f9:	0f 84 71 02 00 00    	je     a770 <fwp_write+0xad0>
    a4ff:	83 f8 10             	cmp    $0x10,%eax
    a502:	0f 84 38 02 00 00    	je     a740 <fwp_write+0xaa0>
    a508:	83 f8 0a             	cmp    $0xa,%eax
    a50b:	0f 84 7f 04 00 00    	je     a990 <fwp_write+0xcf0>
    a511:	0f 8f f9 00 00 00    	jg     a610 <fwp_write+0x970>
    a517:	83 f8 03             	cmp    $0x3,%eax
    a51a:	0f 8f 50 04 00 00    	jg     a970 <fwp_write+0xcd0>
    a520:	85 c0                	test   %eax,%eax
    a522:	78 10                	js     a534 <fwp_write+0x894>
    a524:	48 8b 04 24          	mov    (%rsp),%rax
    a528:	48 c1 e8 3f          	shr    $0x3f,%rax
    a52c:	85 c0                	test   %eax,%eax
    a52e:	0f 85 f9 00 00 00    	jne    a62d <fwp_write+0x98d>
    a534:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a539:	48 8b 34 24          	mov    (%rsp),%rsi
    a53d:	31 c9                	xor    %ecx,%ecx
    a53f:	48 89 df             	mov    %rbx,%rdi
    a542:	e8 59 f7 ff ff       	call   9ca0 <fwp_write>
    a547:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a54c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a551:	49 83 c5 01          	add    $0x1,%r13
    a555:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a559:	0f 8f 5f ff ff ff    	jg     a4be <fwp_write+0x81e>
    a55f:	e9 d2 f7 ff ff       	jmp    9d36 <fwp_write+0x96>
    a564:	0f 1f 40 00          	nopl   0x0(%rax)
    a568:	ba 06 00 00 00       	mov    $0x6,%edx
    a56d:	48 8d 35 1d 2d 00 00 	lea    0x2d1d(%rip),%rsi        # d291 <_IO_stdin_used+0x291>
    a574:	45 31 ed             	xor    %r13d,%r13d
    a577:	e8 74 9b ff ff       	call   40f0 <buf_put>
    a57c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a581:	75 19                	jne    a59c <fwp_write+0x8fc>
    a583:	eb 6c                	jmp    a5f1 <fwp_write+0x951>
    a585:	0f 1f 00             	nopl   (%rax)
    a588:	ba 02 00 00 00       	mov    $0x2,%edx
    a58d:	48 8d 35 07 2d 00 00 	lea    0x2d07(%rip),%rsi        # d29b <_IO_stdin_used+0x29b>
    a594:	48 89 df             	mov    %rbx,%rdi
    a597:	e8 54 9b ff ff       	call   40f0 <buf_put>
    a59c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a5a2:	b9 00 02 00 00       	mov    $0x200,%ecx
    a5a7:	31 c0                	xor    %eax,%eax
    a5a9:	49 83 c5 01          	add    $0x1,%r13
    a5ad:	4c 8d 05 e4 2c 00 00 	lea    0x2ce4(%rip),%r8        # d298 <_IO_stdin_used+0x298>
    a5b4:	ba 02 00 00 00       	mov    $0x2,%edx
    a5b9:	be 00 02 00 00       	mov    $0x200,%esi
    a5be:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a5c5:	00 
    a5c6:	e8 d5 8d ff ff       	call   33a0 <__snprintf_chk@plt>
    a5cb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a5d2:	00 
    a5d3:	e8 68 8e ff ff       	call   3440 <strlen@plt>
    a5d8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a5df:	00 
    a5e0:	48 89 df             	mov    %rbx,%rdi
    a5e3:	48 89 c2             	mov    %rax,%rdx
    a5e6:	e8 05 9b ff ff       	call   40f0 <buf_put>
    a5eb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a5ef:	72 97                	jb     a588 <fwp_write+0x8e8>
    a5f1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a5f6:	ba 01 00 00 00       	mov    $0x1,%edx
    a5fb:	48 89 df             	mov    %rbx,%rdi
    a5fe:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a603:	e8 e8 9a ff ff       	call   40f0 <buf_put>
    a608:	e9 29 f7 ff ff       	jmp    9d36 <fwp_write+0x96>
    a60d:	0f 1f 00             	nopl   (%rax)
    a610:	83 f8 0b             	cmp    $0xb,%eax
    a613:	0f 85 1b ff ff ff    	jne    a534 <fwp_write+0x894>
    a619:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a61e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a622:	83 e0 01             	and    $0x1,%eax
    a625:	85 c0                	test   %eax,%eax
    a627:	0f 84 07 ff ff ff    	je     a534 <fwp_write+0x894>
    a62d:	4c 89 fe             	mov    %r15,%rsi
    a630:	48 89 df             	mov    %rbx,%rdi
    a633:	ba 01 00 00 00       	mov    $0x1,%edx
    a638:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a63d:	e8 ae 9a ff ff       	call   40f0 <buf_put>
    a642:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a647:	48 8b 34 24          	mov    (%rsp),%rsi
    a64b:	31 c9                	xor    %ecx,%ecx
    a64d:	48 89 df             	mov    %rbx,%rdi
    a650:	e8 4b f6 ff ff       	call   9ca0 <fwp_write>
    a655:	ba 01 00 00 00       	mov    $0x1,%edx
    a65a:	4c 89 fe             	mov    %r15,%rsi
    a65d:	48 89 df             	mov    %rbx,%rdi
    a660:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a665:	e8 86 9a ff ff       	call   40f0 <buf_put>
    a66a:	e9 d8 fe ff ff       	jmp    a547 <fwp_write+0x8a7>
    a66f:	90                   	nop
    a670:	ba 01 00 00 00       	mov    $0x1,%edx
    a675:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a67a:	48 89 df             	mov    %rbx,%rdi
    a67d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a682:	e8 69 9a ff ff       	call   40f0 <buf_put>
    a687:	e9 aa f6 ff ff       	jmp    9d36 <fwp_write+0x96>
    a68c:	0f 1f 40 00          	nopl   0x0(%rax)
    a690:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a695:	ba 01 00 00 00       	mov    $0x1,%edx
    a69a:	48 89 df             	mov    %rbx,%rdi
    a69d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a6a2:	e8 49 9a ff ff       	call   40f0 <buf_put>
    a6a7:	e9 8a f6 ff ff       	jmp    9d36 <fwp_write+0x96>
    a6ac:	0f 1f 40 00          	nopl   0x0(%rax)
    a6b0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a6b4:	48 8b 13             	mov    (%rbx),%rdx
    a6b7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a6bc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a6c0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a6c4:	e9 6d f6 ff ff       	jmp    9d36 <fwp_write+0x96>
    a6c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a6d0:	ba 02 00 00 00       	mov    $0x2,%edx
    a6d5:	48 8d 35 bf 2b 00 00 	lea    0x2bbf(%rip),%rsi        # d29b <_IO_stdin_used+0x29b>
    a6dc:	48 89 df             	mov    %rbx,%rdi
    a6df:	e8 0c 9a ff ff       	call   40f0 <buf_put>
    a6e4:	e9 72 f8 ff ff       	jmp    9f5b <fwp_write+0x2bb>
    a6e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a6f0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a6f5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a6fa:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a6fe:	48 89 f7             	mov    %rsi,%rdi
    a701:	48 89 34 24          	mov    %rsi,(%rsp)
    a705:	e8 36 8d ff ff       	call   3440 <strlen@plt>
    a70a:	48 8b 34 24          	mov    (%rsp),%rsi
    a70e:	48 89 df             	mov    %rbx,%rdi
    a711:	48 89 c2             	mov    %rax,%rdx
    a714:	e8 d7 99 ff ff       	call   40f0 <buf_put>
    a719:	ba 03 00 00 00       	mov    $0x3,%edx
    a71e:	48 8d 35 99 2b 00 00 	lea    0x2b99(%rip),%rsi        # d2be <_IO_stdin_used+0x2be>
    a725:	48 89 df             	mov    %rbx,%rdi
    a728:	e8 c3 99 ff ff       	call   40f0 <buf_put>
    a72d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a732:	e9 35 f8 ff ff       	jmp    9f6c <fwp_write+0x2cc>
    a737:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a73e:	00 00 
    a740:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a745:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a749:	48 85 ff             	test   %rdi,%rdi
    a74c:	0f 84 e2 fd ff ff    	je     a534 <fwp_write+0x894>
    a752:	48 8d 35 4f 2b 00 00 	lea    0x2b4f(%rip),%rsi        # d2a8 <_IO_stdin_used+0x2a8>
    a759:	e8 c2 8d ff ff       	call   3520 <strcmp@plt>
    a75e:	85 c0                	test   %eax,%eax
    a760:	0f 95 c0             	setne  %al
    a763:	0f b6 c0             	movzbl %al,%eax
    a766:	e9 c1 fd ff ff       	jmp    a52c <fwp_write+0x88c>
    a76b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a770:	31 c0                	xor    %eax,%eax
    a772:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a779:	00 
    a77a:	0f 97 c0             	seta   %al
    a77d:	e9 aa fd ff ff       	jmp    a52c <fwp_write+0x88c>
    a782:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a788:	48 89 df             	mov    %rbx,%rdi
    a78b:	ba 02 00 00 00       	mov    $0x2,%edx
    a790:	48 8d 35 0e 2b 00 00 	lea    0x2b0e(%rip),%rsi        # d2a5 <_IO_stdin_used+0x2a5>
    a797:	e8 54 99 ff ff       	call   40f0 <buf_put>
    a79c:	4c 89 e8             	mov    %r13,%rax
    a79f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a7a4:	31 c9                	xor    %ecx,%ecx
    a7a6:	48 c1 e0 04          	shl    $0x4,%rax
    a7aa:	48 89 df             	mov    %rbx,%rdi
    a7ad:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a7b2:	e8 e9 f4 ff ff       	call   9ca0 <fwp_write>
    a7b7:	e9 5e f6 ff ff       	jmp    9e1a <fwp_write+0x17a>
    a7bc:	0f 1f 40 00          	nopl   0x0(%rax)
    a7c0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a7c5:	48 85 ff             	test   %rdi,%rdi
    a7c8:	79 0c                	jns    a7d6 <fwp_write+0xb36>
    a7ca:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a7d1:	00 
    a7d2:	48 03 75 10          	add    0x10(%rbp),%rsi
    a7d6:	48 63 3e             	movslq (%rsi),%rdi
    a7d9:	83 f9 02             	cmp    $0x2,%ecx
    a7dc:	89 fe                	mov    %edi,%esi
    a7de:	48 0f 44 f7          	cmove  %rdi,%rsi
    a7e2:	e9 f9 fb ff ff       	jmp    a3e0 <fwp_write+0x740>
    a7e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a7ee:	00 00 
    a7f0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a7f5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a7fa:	48 85 ff             	test   %rdi,%rdi
    a7fd:	0f 88 0f 03 00 00    	js     ab12 <fwp_write+0xe72>
    a803:	49 0f bf 38          	movswq (%r8),%rdi
    a807:	83 f9 01             	cmp    $0x1,%ecx
    a80a:	0f b7 f7             	movzwl %di,%esi
    a80d:	48 0f 44 f7          	cmove  %rdi,%rsi
    a811:	e9 ca fb ff ff       	jmp    a3e0 <fwp_write+0x740>
    a816:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a81d:	00 00 00 
    a820:	ba 01 00 00 00       	mov    $0x1,%edx
    a825:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a82a:	48 83 c5 08          	add    $0x8,%rbp
    a82e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a833:	e8 b8 98 ff ff       	call   40f0 <buf_put>
    a838:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a83d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a842:	4d 85 ed             	test   %r13,%r13
    a845:	75 46                	jne    a88d <fwp_write+0xbed>
    a847:	e9 04 01 00 00       	jmp    a950 <fwp_write+0xcb0>
    a84c:	0f 1f 40 00          	nopl   0x0(%rax)
    a850:	41 80 f9 09          	cmp    $0x9,%r9b
    a854:	0f 84 d6 00 00 00    	je     a930 <fwp_write+0xc90>
    a85a:	41 80 f9 0a          	cmp    $0xa,%r9b
    a85e:	0f 85 9c 00 00 00    	jne    a900 <fwp_write+0xc60>
    a864:	ba 02 00 00 00       	mov    $0x2,%edx
    a869:	48 8d 35 11 2a 00 00 	lea    0x2a11(%rip),%rsi        # d281 <_IO_stdin_used+0x281>
    a870:	48 89 df             	mov    %rbx,%rdi
    a873:	e8 78 98 ff ff       	call   40f0 <buf_put>
    a878:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a87f:	00 
    a880:	48 83 c5 01          	add    $0x1,%rbp
    a884:	49 39 ec             	cmp    %rbp,%r12
    a887:	0f 84 c3 00 00 00    	je     a950 <fwp_write+0xcb0>
    a88d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a892:	41 80 f9 0d          	cmp    $0xd,%r9b
    a896:	74 28                	je     a8c0 <fwp_write+0xc20>
    a898:	7e b6                	jle    a850 <fwp_write+0xbb0>
    a89a:	41 80 f9 22          	cmp    $0x22,%r9b
    a89e:	74 40                	je     a8e0 <fwp_write+0xc40>
    a8a0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a8a4:	75 5a                	jne    a900 <fwp_write+0xc60>
    a8a6:	ba 02 00 00 00       	mov    $0x2,%edx
    a8ab:	48 8d 35 cc 29 00 00 	lea    0x29cc(%rip),%rsi        # d27e <_IO_stdin_used+0x27e>
    a8b2:	48 89 df             	mov    %rbx,%rdi
    a8b5:	e8 36 98 ff ff       	call   40f0 <buf_put>
    a8ba:	eb c4                	jmp    a880 <fwp_write+0xbe0>
    a8bc:	0f 1f 40 00          	nopl   0x0(%rax)
    a8c0:	ba 02 00 00 00       	mov    $0x2,%edx
    a8c5:	48 8d 35 bb 29 00 00 	lea    0x29bb(%rip),%rsi        # d287 <_IO_stdin_used+0x287>
    a8cc:	48 89 df             	mov    %rbx,%rdi
    a8cf:	e8 1c 98 ff ff       	call   40f0 <buf_put>
    a8d4:	eb aa                	jmp    a880 <fwp_write+0xbe0>
    a8d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a8dd:	00 00 00 
    a8e0:	ba 02 00 00 00       	mov    $0x2,%edx
    a8e5:	48 8d 35 8f 29 00 00 	lea    0x298f(%rip),%rsi        # d27b <_IO_stdin_used+0x27b>
    a8ec:	48 89 df             	mov    %rbx,%rdi
    a8ef:	e8 fc 97 ff ff       	call   40f0 <buf_put>
    a8f4:	eb 8a                	jmp    a880 <fwp_write+0xbe0>
    a8f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a8fd:	00 00 00 
    a900:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a904:	0f 86 2e 01 00 00    	jbe    aa38 <fwp_write+0xd98>
    a90a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a90e:	0f 84 24 01 00 00    	je     aa38 <fwp_write+0xd98>
    a914:	ba 01 00 00 00       	mov    $0x1,%edx
    a919:	4c 89 fe             	mov    %r15,%rsi
    a91c:	48 89 df             	mov    %rbx,%rdi
    a91f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a924:	e8 c7 97 ff ff       	call   40f0 <buf_put>
    a929:	e9 52 ff ff ff       	jmp    a880 <fwp_write+0xbe0>
    a92e:	66 90                	xchg   %ax,%ax
    a930:	ba 02 00 00 00       	mov    $0x2,%edx
    a935:	48 8d 35 48 29 00 00 	lea    0x2948(%rip),%rsi        # d284 <_IO_stdin_used+0x284>
    a93c:	48 89 df             	mov    %rbx,%rdi
    a93f:	e8 ac 97 ff ff       	call   40f0 <buf_put>
    a944:	e9 37 ff ff ff       	jmp    a880 <fwp_write+0xbe0>
    a949:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a950:	ba 01 00 00 00       	mov    $0x1,%edx
    a955:	4c 89 fe             	mov    %r15,%rsi
    a958:	48 89 df             	mov    %rbx,%rdi
    a95b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a960:	e8 8b 97 ff ff       	call   40f0 <buf_put>
    a965:	e9 cc f3 ff ff       	jmp    9d36 <fwp_write+0x96>
    a96a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a970:	83 f8 04             	cmp    $0x4,%eax
    a973:	0f 85 bb fb ff ff    	jne    a534 <fwp_write+0x894>
    a979:	48 8b 04 24          	mov    (%rsp),%rax
    a97d:	48 8b 40 08          	mov    0x8(%rax),%rax
    a981:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    a986:	48 c1 e8 3f          	shr    $0x3f,%rax
    a98a:	e9 96 fc ff ff       	jmp    a625 <fwp_write+0x985>
    a98f:	90                   	nop
    a990:	8b 0c 24             	mov    (%rsp),%ecx
    a993:	31 c0                	xor    %eax,%eax
    a995:	85 c9                	test   %ecx,%ecx
    a997:	0f 98 c0             	sets   %al
    a99a:	e9 86 fc ff ff       	jmp    a625 <fwp_write+0x985>
    a99f:	90                   	nop
    a9a0:	48 f7 d8             	neg    %rax
    a9a3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    a9aa:	00 
    a9ab:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    a9b2:	2d 
    a9b3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a9ba:	00 
    a9bb:	48 83 d2 00          	adc    $0x0,%rdx
    a9bf:	48 89 c6             	mov    %rax,%rsi
    a9c2:	48 f7 da             	neg    %rdx
    a9c5:	e8 76 90 ff ff       	call   3a40 <fwp_fmt_u128>
    a9ca:	e9 51 f3 ff ff       	jmp    9d20 <fwp_write+0x80>
    a9cf:	90                   	nop
    a9d0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    a9d5:	e9 c3 f5 ff ff       	jmp    9f9d <fwp_write+0x2fd>
    a9da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a9e0:	4c 89 e9             	mov    %r13,%rcx
    a9e3:	48 c1 e1 04          	shl    $0x4,%rcx
    a9e7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    a9ec:	48 85 ff             	test   %rdi,%rdi
    a9ef:	0f 89 eb f9 ff ff    	jns    a3e0 <fwp_write+0x740>
    a9f5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a9f9:	48 89 ce             	mov    %rcx,%rsi
    a9fc:	e9 df f9 ff ff       	jmp    a3e0 <fwp_write+0x740>
    aa01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa08:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    aa0f:	00 
    aa10:	48 03 4d 10          	add    0x10(%rbp),%rcx
    aa14:	e9 20 fa ff ff       	jmp    a439 <fwp_write+0x799>
    aa19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa20:	ba 02 00 00 00       	mov    $0x2,%edx
    aa25:	48 8d 35 1a 28 00 00 	lea    0x281a(%rip),%rsi        # d246 <_IO_stdin_used+0x246>
    aa2c:	e9 2d f7 ff ff       	jmp    a15e <fwp_write+0x4be>
    aa31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa38:	4c 8d 05 4b 28 00 00 	lea    0x284b(%rip),%r8        # d28a <_IO_stdin_used+0x28a>
    aa3f:	b9 10 00 00 00       	mov    $0x10,%ecx
    aa44:	31 c0                	xor    %eax,%eax
    aa46:	ba 02 00 00 00       	mov    $0x2,%edx
    aa4b:	be 10 00 00 00       	mov    $0x10,%esi
    aa50:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    aa57:	00 
    aa58:	e8 43 89 ff ff       	call   33a0 <__snprintf_chk@plt>
    aa5d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    aa64:	00 
    aa65:	e8 d6 89 ff ff       	call   3440 <strlen@plt>
    aa6a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    aa71:	00 
    aa72:	48 89 df             	mov    %rbx,%rdi
    aa75:	48 89 c2             	mov    %rax,%rdx
    aa78:	e8 73 96 ff ff       	call   40f0 <buf_put>
    aa7d:	e9 fe fd ff ff       	jmp    a880 <fwp_write+0xbe0>
    aa82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aa88:	66 0f ef c0          	pxor   %xmm0,%xmm0
    aa8c:	48 8d 35 ad 27 00 00 	lea    0x27ad(%rip),%rsi        # d240 <_IO_stdin_used+0x240>
    aa93:	48 8d 05 a5 27 00 00 	lea    0x27a5(%rip),%rax        # d23f <_IO_stdin_used+0x23f>
    aa9a:	4c 89 e7             	mov    %r12,%rdi
    aa9d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    aaa1:	48 0f 46 f0          	cmovbe %rax,%rsi
    aaa5:	e8 36 89 ff ff       	call   33e0 <strcpy@plt>
    aaaa:	e9 71 f2 ff ff       	jmp    9d20 <fwp_write+0x80>
    aaaf:	90                   	nop
    aab0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    aab4:	48 8d 35 85 27 00 00 	lea    0x2785(%rip),%rsi        # d240 <_IO_stdin_used+0x240>
    aabb:	48 8d 05 7d 27 00 00 	lea    0x277d(%rip),%rax        # d23f <_IO_stdin_used+0x23f>
    aac2:	0f 2f c8             	comiss %xmm0,%xmm1
    aac5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    aacc:	00 
    aacd:	4c 89 e7             	mov    %r12,%rdi
    aad0:	48 0f 46 f0          	cmovbe %rax,%rsi
    aad4:	e8 07 89 ff ff       	call   33e0 <strcpy@plt>
    aad9:	e9 42 f2 ff ff       	jmp    9d20 <fwp_write+0x80>
    aade:	66 90                	xchg   %ax,%ax
    aae0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    aae5:	45 85 c0             	test   %r8d,%r8d
    aae8:	75 34                	jne    ab1e <fwp_write+0xe7e>
    aaea:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    aaf1:	00 
    aaf2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    aaf9:	00 00 
    aafb:	0f 85 74 f6 ff ff    	jne    a175 <fwp_write+0x4d5>
    ab01:	ba 02 00 00 00       	mov    $0x2,%edx
    ab06:	48 8d 35 ae 27 00 00 	lea    0x27ae(%rip),%rsi        # d2bb <_IO_stdin_used+0x2bb>
    ab0d:	e9 a1 f3 ff ff       	jmp    9eb3 <fwp_write+0x213>
    ab12:	48 03 75 10          	add    0x10(%rbp),%rsi
    ab16:	49 89 f0             	mov    %rsi,%r8
    ab19:	e9 e5 fc ff ff       	jmp    a803 <fwp_write+0xb63>
    ab1e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    ab23:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ab28:	85 ff                	test   %edi,%edi
    ab2a:	0f 84 fa f3 ff ff    	je     9f2a <fwp_write+0x28a>
    ab30:	ba 01 00 00 00       	mov    $0x1,%edx
    ab35:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    ab3a:	48 89 df             	mov    %rbx,%rdi
    ab3d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    ab42:	e8 a9 95 ff ff       	call   40f0 <buf_put>
    ab47:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    ab4c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ab51:	41 be 01 00 00 00    	mov    $0x1,%r14d
    ab57:	85 c0                	test   %eax,%eax
    ab59:	0f 8f f0 f3 ff ff    	jg     9f4f <fwp_write+0x2af>
    ab5f:	e9 34 f4 ff ff       	jmp    9f98 <fwp_write+0x2f8>
    ab64:	48 8b 45 08          	mov    0x8(%rbp),%rax
    ab68:	49 89 c5             	mov    %rax,%r13
    ab6b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ab70:	49 89 c4             	mov    %rax,%r12
    ab73:	49 c1 fd 3f          	sar    $0x3f,%r13
    ab77:	4c 09 e8             	or     %r13,%rax
    ab7a:	0f 84 a7 00 00 00    	je     ac27 <fwp_write+0xf87>
    ab80:	48 8d 2d 99 48 00 00 	lea    0x4899(%rip),%rbp        # f420 <units.1>
    ab87:	4d 89 e7             	mov    %r12,%r15
    ab8a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    ab8e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    ab93:	4c 89 ff             	mov    %r15,%rdi
    ab96:	4c 89 ee             	mov    %r13,%rsi
    ab99:	44 89 0c 24          	mov    %r9d,(%rsp)
    ab9d:	48 99                	cqto
    ab9f:	48 89 d1             	mov    %rdx,%rcx
    aba2:	48 89 c2             	mov    %rax,%rdx
    aba5:	e8 66 1a 00 00       	call   c610 <__divmodti4>
    abaa:	44 8b 0c 24          	mov    (%rsp),%r9d
    abae:	48 89 c1             	mov    %rax,%rcx
    abb1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    abb6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    abbb:	0f 84 94 00 00 00    	je     ac55 <fwp_write+0xfb5>
    abc1:	41 83 c1 01          	add    $0x1,%r9d
    abc5:	48 83 c5 10          	add    $0x10,%rbp
    abc9:	41 83 f9 05          	cmp    $0x5,%r9d
    abcd:	75 bb                	jne    ab8a <fwp_write+0xeea>
    abcf:	4d 85 ed             	test   %r13,%r13
    abd2:	79 53                	jns    ac27 <fwp_write+0xf87>
    abd4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    abd9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    abde:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    abe3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    abe8:	48 99                	cqto
    abea:	48 f7 d8             	neg    %rax
    abed:	48 83 d2 00          	adc    $0x0,%rdx
    abf1:	48 89 c6             	mov    %rax,%rsi
    abf4:	48 f7 da             	neg    %rdx
    abf7:	e8 44 8e ff ff       	call   3a40 <fwp_fmt_u128>
    abfc:	49 89 e8             	mov    %rbp,%r8
    abff:	ba 00 02 00 00       	mov    $0x200,%edx
    ac04:	be 02 00 00 00       	mov    $0x2,%esi
    ac09:	31 c0                	xor    %eax,%eax
    ac0b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ac12:	00 
    ac13:	48 8d 0d 9c 26 00 00 	lea    0x269c(%rip),%rcx        # d2b6 <_IO_stdin_used+0x2b6>
    ac1a:	4c 89 e7             	mov    %r12,%rdi
    ac1d:	e8 9e 8a ff ff       	call   36c0 <__sprintf_chk@plt>
    ac22:	e9 f9 f0 ff ff       	jmp    9d20 <fwp_write+0x80>
    ac27:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ac2c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    ac31:	31 d2                	xor    %edx,%edx
    ac33:	48 89 ef             	mov    %rbp,%rdi
    ac36:	e8 05 8e ff ff       	call   3a40 <fwp_fmt_u128>
    ac3b:	eb bf                	jmp    abfc <fwp_write+0xf5c>
    ac3d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    ac44:	4e 61 4e 00 
    ac48:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ac4f:	00 
    ac50:	e9 cb f0 ff ff       	jmp    9d20 <fwp_write+0x80>
    ac55:	44 89 0c 24          	mov    %r9d,(%rsp)
    ac59:	48 89 c8             	mov    %rcx,%rax
    ac5c:	48 85 d2             	test   %rdx,%rdx
    ac5f:	78 51                	js     acb2 <fwp_write+0x1012>
    ac61:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ac66:	48 89 c6             	mov    %rax,%rsi
    ac69:	48 89 ef             	mov    %rbp,%rdi
    ac6c:	e8 cf 8d ff ff       	call   3a40 <fwp_fmt_u128>
    ac71:	44 8b 0c 24          	mov    (%rsp),%r9d
    ac75:	49 63 c1             	movslq %r9d,%rax
    ac78:	49 89 e8             	mov    %rbp,%r8
    ac7b:	ba 00 02 00 00       	mov    $0x200,%edx
    ac80:	be 02 00 00 00       	mov    $0x2,%esi
    ac85:	48 c1 e0 04          	shl    $0x4,%rax
    ac89:	48 8d 3d 90 47 00 00 	lea    0x4790(%rip),%rdi        # f420 <units.1>
    ac90:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ac97:	00 
    ac98:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    ac9c:	48 8d 0d 0e 26 00 00 	lea    0x260e(%rip),%rcx        # d2b1 <_IO_stdin_used+0x2b1>
    aca3:	4c 89 e7             	mov    %r12,%rdi
    aca6:	31 c0                	xor    %eax,%eax
    aca8:	e8 13 8a ff ff       	call   36c0 <__sprintf_chk@plt>
    acad:	e9 6e f0 ff ff       	jmp    9d20 <fwp_write+0x80>
    acb2:	48 f7 d8             	neg    %rax
    acb5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    acba:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    acbf:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    acc4:	48 83 d2 00          	adc    $0x0,%rdx
    acc8:	48 89 c6             	mov    %rax,%rsi
    accb:	48 f7 da             	neg    %rdx
    acce:	e8 6d 8d ff ff       	call   3a40 <fwp_fmt_u128>
    acd3:	44 8b 0c 24          	mov    (%rsp),%r9d
    acd7:	eb 9c                	jmp    ac75 <fwp_write+0xfd5>
    acd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000ace0 <fwp_main_thread>:
    ace0:	f3 0f 1e fa          	endbr64
    ace4:	55                   	push   %rbp
    ace5:	48 89 e5             	mov    %rsp,%rbp
    ace8:	41 57                	push   %r15
    acea:	41 56                	push   %r14
    acec:	41 55                	push   %r13
    acee:	41 54                	push   %r12
    acf0:	53                   	push   %rbx
    acf1:	48 81 ec 68 01 00 00 	sub    $0x168,%rsp
    acf8:	44 8b 0d e5 fe 05 00 	mov    0x5fee5(%rip),%r9d        # 6abe4 <fwp_heap+0x13a4>
    acff:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    ad06:	00 00 
    ad08:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    ad0c:	31 c0                	xor    %eax,%eax
    ad0e:	45 85 c9             	test   %r9d,%r9d
    ad11:	0f 84 ed 06 00 00    	je     b404 <fwp_main_thread+0x724>
    ad17:	44 8b 05 ca fe 05 00 	mov    0x5feca(%rip),%r8d        # 6abe8 <fwp_heap+0x13a8>
    ad1e:	45 85 c0             	test   %r8d,%r8d
    ad21:	0f 85 f2 06 00 00    	jne    b419 <fwp_main_thread+0x739>
    ad27:	4c 8d ad f0 fe ff ff 	lea    -0x110(%rbp),%r13
    ad2e:	48 8d 9d d0 fe ff ff 	lea    -0x130(%rbp),%rbx
    ad35:	31 f6                	xor    %esi,%esi
    ad37:	48 c7 05 9e e4 05 00 	movq   $0x40000000,0x5e49e(%rip)        # 691e0 <fwp_main_stack_size>
    ad3e:	00 00 00 40 
    ad42:	48 8d 05 57 63 00 00 	lea    0x6357(%rip),%rax        # 110a0 <alt.5>
    ad49:	4c 89 ef             	mov    %r13,%rdi
    ad4c:	48 89 1d 95 e4 05 00 	mov    %rbx,0x5e495(%rip)        # 691e8 <fwp_main_stack_top>
    ad53:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
    ad5a:	48 c7 85 00 ff ff ff 	movq   $0x10000,-0x100(%rbp)
    ad61:	00 00 01 00 
    ad65:	c7 85 f8 fe ff ff 00 	movl   $0x0,-0x108(%rbp)
    ad6c:	00 00 00 
    ad6f:	e8 2c 89 ff ff       	call   36a0 <sigaltstack@plt>
    ad74:	85 c0                	test   %eax,%eax
    ad76:	0f 85 e0 17 00 00    	jne    c55c <fwp_main_thread+0x187c>
    ad7c:	31 c0                	xor    %eax,%eax
    ad7e:	b9 12 00 00 00       	mov    $0x12,%ecx
    ad83:	48 8d bd 38 ff ff ff 	lea    -0xc8(%rbp),%rdi
    ad8a:	f3 48 ab             	rep stos %rax,(%rdi)
    ad8d:	48 8d 05 ac 8f ff ff 	lea    -0x7054(%rip),%rax        # 3d40 <fwp_segv>
    ad94:	48 8d bd 38 ff ff ff 	lea    -0xc8(%rbp),%rdi
    ad9b:	c7 45 b8 04 00 00 08 	movl   $0x8000004,-0x48(%rbp)
    ada2:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
    ada9:	4c 8d a5 30 ff ff ff 	lea    -0xd0(%rbp),%r12
    adb0:	e8 ab 87 ff ff       	call   3560 <sigemptyset@plt>
    adb5:	85 c0                	test   %eax,%eax
    adb7:	0f 85 9f 17 00 00    	jne    c55c <fwp_main_thread+0x187c>
    adbd:	31 d2                	xor    %edx,%edx
    adbf:	4c 89 e6             	mov    %r12,%rsi
    adc2:	bf 0b 00 00 00       	mov    $0xb,%edi
    adc7:	e8 24 86 ff ff       	call   33f0 <sigaction@plt>
    adcc:	85 c0                	test   %eax,%eax
    adce:	0f 85 88 17 00 00    	jne    c55c <fwp_main_thread+0x187c>
    add4:	31 d2                	xor    %edx,%edx
    add6:	4c 89 e6             	mov    %r12,%rsi
    add9:	bf 07 00 00 00       	mov    $0x7,%edi
    adde:	e8 0d 86 ff ff       	call   33f0 <sigaction@plt>
    ade3:	85 c0                	test   %eax,%eax
    ade5:	0f 85 71 17 00 00    	jne    c55c <fwp_main_thread+0x187c>
    adeb:	48 8b 05 6e fe 05 00 	mov    0x5fe6e(%rip),%rax        # 6ac60 <fwp_heap+0x1420>
    adf2:	48 85 c0             	test   %rax,%rax
    adf5:	0f 88 eb 05 00 00    	js     b3e6 <fwp_main_thread+0x706>
    adfb:	66 0f ef c0          	pxor   %xmm0,%xmm0
    adff:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    ae04:	48 8d 3d 15 94 ff ff 	lea    -0x6beb(%rip),%rdi        # 4220 <ad_raw_report>
    ae0b:	f2 0f 11 05 d5 06 06 	movsd  %xmm0,0x606d5(%rip)        # 6b4e8 <iteration_start_charge>
    ae12:	00 
    ae13:	c7 05 eb 06 06 00 01 	movl   $0x1,0x606eb(%rip)        # 6b508 <iteration_active>
    ae1a:	00 00 00 
    ae1d:	e8 fe 19 00 00       	call   c820 <atexit>
    ae22:	85 c0                	test   %eax,%eax
    ae24:	0f 85 43 17 00 00    	jne    c56d <fwp_main_thread+0x188d>
    ae2a:	8b 3d 60 62 00 00    	mov    0x6260(%rip),%edi        # 11090 <st.3>
    ae30:	85 ff                	test   %edi,%edi
    ae32:	0f 84 f2 05 00 00    	je     b42a <fwp_main_thread+0x74a>
    ae38:	4c 8b 25 e1 e9 05 00 	mov    0x5e9e1(%rip),%r12        # 69820 <fwp_cur>
    ae3f:	4d 85 e4             	test   %r12,%r12
    ae42:	0f 84 c5 01 00 00    	je     b00d <fwp_main_thread+0x32d>
    ae48:	45 0f b6 6c 24 52    	movzbl 0x52(%r12),%r13d
    ae4e:	41 c6 44 24 52 01    	movb   $0x1,0x52(%r12)
    ae54:	4c 89 e3             	mov    %r12,%rbx
    ae57:	49 83 7c 24 28 00    	cmpq   $0x0,0x28(%r12)
    ae5d:	0f 84 48 01 00 00    	je     afab <fwp_main_thread+0x2cb>
    ae63:	49 83 7c 24 60 00    	cmpq   $0x0,0x60(%r12)
    ae69:	0f 84 92 02 00 00    	je     b101 <fwp_main_thread+0x421>
    ae6f:	41 80 7c 24 51 00    	cmpb   $0x0,0x51(%r12)
    ae75:	0f 84 6a 02 00 00    	je     b0e5 <fwp_main_thread+0x405>
    ae7b:	49 8d 54 24 40       	lea    0x40(%r12),%rdx
    ae80:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    ae84:	0f 85 fc 02 00 00    	jne    b186 <fwp_main_thread+0x4a6>
    ae8a:	48 8b 43 60          	mov    0x60(%rbx),%rax
    ae8e:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    ae95:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    ae9a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    aea1:	00 00 00 00 
    aea5:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    aeac:	48 85 d2             	test   %rdx,%rdx
    aeaf:	74 07                	je     aeb8 <fwp_main_thread+0x1d8>
    aeb1:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    aeb8:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    aebd:	48 85 c0             	test   %rax,%rax
    aec0:	74 34                	je     aef6 <fwp_main_thread+0x216>
    aec2:	48 89 43 68          	mov    %rax,0x68(%rbx)
    aec6:	48 8b 05 2b e9 05 00 	mov    0x5e92b(%rip),%rax        # 697f8 <fwp_timers>
    aecd:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    aed1:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    aed8:	00 00 00 00 
    aedc:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    aee3:	48 85 c0             	test   %rax,%rax
    aee6:	74 07                	je     aeef <fwp_main_thread+0x20f>
    aee8:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    aeef:	48 89 1d 02 e9 05 00 	mov    %rbx,0x5e902(%rip)        # 697f8 <fwp_timers>
    aef6:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    aefa:	e8 51 c9 ff ff       	call   7850 <fwp_block>
    aeff:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    af06:	48 85 c9             	test   %rcx,%rcx
    af09:	74 47                	je     af52 <fwp_main_thread+0x272>
    af0b:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    af12:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    af19:	48 85 d2             	test   %rdx,%rdx
    af1c:	0f 84 5c 02 00 00    	je     b17e <fwp_main_thread+0x49e>
    af22:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    af29:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    af30:	48 85 c0             	test   %rax,%rax
    af33:	74 07                	je     af3c <fwp_main_thread+0x25c>
    af35:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    af3c:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    af43:	00 00 00 00 
    af47:	66 0f ef db          	pxor   %xmm3,%xmm3
    af4b:	0f 11 9b 18 01 00 00 	movups %xmm3,0x118(%rbx)
    af52:	48 8b 0d c7 e8 05 00 	mov    0x5e8c7(%rip),%rcx        # 69820 <fwp_cur>
    af59:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    af5d:	0f 84 13 02 00 00    	je     b176 <fwp_main_thread+0x496>
    af63:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    af6a:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    af71:	48 85 d2             	test   %rdx,%rdx
    af74:	0f 84 60 04 00 00    	je     b3da <fwp_main_thread+0x6fa>
    af7a:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    af81:	48 85 c0             	test   %rax,%rax
    af84:	74 07                	je     af8d <fwp_main_thread+0x2ad>
    af86:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    af8d:	66 0f ef e4          	pxor   %xmm4,%xmm4
    af91:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    af95:	0f 11 a3 08 01 00 00 	movups %xmm4,0x108(%rbx)
    af9c:	48 89 cb             	mov    %rcx,%rbx
    af9f:	49 83 7c 24 28 00    	cmpq   $0x0,0x28(%r12)
    afa5:	0f 85 b8 fe ff ff    	jne    ae63 <fwp_main_thread+0x183>
    afab:	48 83 3d 05 05 06 00 	cmpq   $0x0,0x60505(%rip)        # 6b4b8 <fwp_state_len>
    afb2:	00 
    afb3:	45 88 6c 24 52       	mov    %r13b,0x52(%r12)
    afb8:	74 63                	je     b01d <fwp_main_thread+0x33d>
    afba:	48 39 1d 57 e8 05 00 	cmp    %rbx,0x5e857(%rip)        # 69818 <fwp_root>
    afc1:	c7 05 d5 60 01 00 00 	movl   $0x0,0x160d5(%rip)        # 210a0 <fwp_exit_code>
    afc8:	00 00 00 
    afcb:	0f 85 39 16 00 00    	jne    c60a <fwp_main_thread+0x192a>
    afd1:	48 85 db             	test   %rbx,%rbx
    afd4:	0f 84 fc 01 00 00    	je     b1d6 <fwp_main_thread+0x4f6>
    afda:	48 8b 15 07 e8 05 00 	mov    0x5e807(%rip),%rdx        # 697e8 <fwp_tasks_active>
    afe1:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    afe5:	48 85 d2             	test   %rdx,%rdx
    afe8:	0f 84 e8 01 00 00    	je     b1d6 <fwp_main_thread+0x4f6>
    afee:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    aff2:	75 08                	jne    affc <fwp_main_thread+0x31c>
    aff4:	48 89 d7             	mov    %rdx,%rdi
    aff7:	e8 34 91 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    affc:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    b003:	48 85 d2             	test   %rdx,%rdx
    b006:	75 e6                	jne    afee <fwp_main_thread+0x30e>
    b008:	e9 a8 00 00 00       	jmp    b0b5 <fwp_main_thread+0x3d5>
    b00d:	48 83 3d a3 04 06 00 	cmpq   $0x0,0x604a3(%rip)        # 6b4b8 <fwp_state_len>
    b014:	00 
    b015:	0f 85 a3 01 00 00    	jne    b1be <fwp_main_thread+0x4de>
    b01b:	31 db                	xor    %ebx,%ebx
    b01d:	48 83 3d 83 04 06 00 	cmpq   $0x0,0x60483(%rip)        # 6b4a8 <fwp_state_owners>
    b024:	00 
    b025:	75 93                	jne    afba <fwp_main_thread+0x2da>
    b027:	48 8b 3d 92 04 06 00 	mov    0x60492(%rip),%rdi        # 6b4c0 <fwp_state>
    b02e:	e8 dd a9 ff ff       	call   5a10 <fwp_mem_free>
    b033:	48 c7 05 82 04 06 00 	movq   $0x0,0x60482(%rip)        # 6b4c0 <fwp_state>
    b03a:	00 00 00 00 
    b03e:	48 c7 05 67 04 06 00 	movq   $0x0,0x60467(%rip)        # 6b4b0 <fwp_state_cap>
    b045:	00 00 00 00 
    b049:	48 85 db             	test   %rbx,%rbx
    b04c:	0f 84 32 14 00 00    	je     c484 <fwp_main_thread+0x17a4>
    b052:	48 39 1d bf e7 05 00 	cmp    %rbx,0x5e7bf(%rip)        # 69818 <fwp_root>
    b059:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    b060:	00 00 00 00 
    b064:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    b06b:	00 00 00 00 
    b06f:	c7 05 27 60 01 00 00 	movl   $0x0,0x16027(%rip)        # 210a0 <fwp_exit_code>
    b076:	00 00 00 
    b079:	0f 84 5b ff ff ff    	je     afda <fwp_main_thread+0x2fa>
    b07f:	e9 cc 86 ff ff       	jmp    3750 <fwp_main_thread.cold>
    b084:	0f 1f 40 00          	nopl   0x0(%rax)
    b088:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    b08f:	48 89 1d 6a e7 05 00 	mov    %rbx,0x5e76a(%rip)        # 69800 <fwp_ready_tail>
    b096:	e8 b5 c7 ff ff       	call   7850 <fwp_block>
    b09b:	e8 b0 c5 ff ff       	call   7650 <fwp_free_zombie>
    b0a0:	48 83 3d 40 e7 05 00 	cmpq   $0x0,0x5e740(%rip)        # 697e8 <fwp_tasks_active>
    b0a7:	00 
    b0a8:	0f 84 28 01 00 00    	je     b1d6 <fwp_main_thread+0x4f6>
    b0ae:	48 8b 1d 63 e7 05 00 	mov    0x5e763(%rip),%rbx        # 69818 <fwp_root>
    b0b5:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    b0b9:	75 db                	jne    b096 <fwp_main_thread+0x3b6>
    b0bb:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    b0bf:	75 d5                	jne    b096 <fwp_main_thread+0x3b6>
    b0c1:	48 8b 05 38 e7 05 00 	mov    0x5e738(%rip),%rax        # 69800 <fwp_ready_tail>
    b0c8:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    b0cc:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    b0d3:	00 00 00 00 
    b0d7:	48 85 c0             	test   %rax,%rax
    b0da:	75 ac                	jne    b088 <fwp_main_thread+0x3a8>
    b0dc:	48 89 1d 25 e7 05 00 	mov    %rbx,0x5e725(%rip)        # 69808 <fwp_ready_head>
    b0e3:	eb aa                	jmp    b08f <fwp_main_thread+0x3af>
    b0e5:	e8 d6 94 ff ff       	call   45c0 <fwp_now_ns>
    b0ea:	49 3b 44 24 60       	cmp    0x60(%r12),%rax
    b0ef:	7c 10                	jl     b101 <fwp_main_thread+0x421>
    b0f1:	41 80 7c 24 50 00    	cmpb   $0x0,0x50(%r12)
    b0f7:	75 08                	jne    b101 <fwp_main_thread+0x421>
    b0f9:	4c 89 e7             	mov    %r12,%rdi
    b0fc:	e8 2f 90 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    b101:	41 80 7c 24 51 00    	cmpb   $0x0,0x51(%r12)
    b107:	0f 85 6e fd ff ff    	jne    ae7b <fwp_main_thread+0x19b>
    b10d:	49 8b 44 24 60       	mov    0x60(%r12),%rax
    b112:	49 8d 54 24 40       	lea    0x40(%r12),%rdx
    b117:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b11b:	0f 85 6d fd ff ff    	jne    ae8e <fwp_main_thread+0x1ae>
    b121:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    b125:	48 85 c9             	test   %rcx,%rcx
    b128:	0f 84 60 fd ff ff    	je     ae8e <fwp_main_thread+0x1ae>
    b12e:	48 39 c8             	cmp    %rcx,%rax
    b131:	48 89 ce             	mov    %rcx,%rsi
    b134:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b13b:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    b140:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b147:	00 00 00 00 
    b14b:	48 0f 4e f0          	cmovle %rax,%rsi
    b14f:	48 85 c0             	test   %rax,%rax
    b152:	48 89 c8             	mov    %rcx,%rax
    b155:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b15c:	48 0f 45 c6          	cmovne %rsi,%rax
    b160:	48 85 d2             	test   %rdx,%rdx
    b163:	74 07                	je     b16c <fwp_main_thread+0x48c>
    b165:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b16c:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    b171:	e9 4c fd ff ff       	jmp    aec2 <fwp_main_thread+0x1e2>
    b176:	48 89 cb             	mov    %rcx,%rbx
    b179:	e9 d9 fc ff ff       	jmp    ae57 <fwp_main_thread+0x177>
    b17e:	48 89 01             	mov    %rax,(%rcx)
    b181:	e9 aa fd ff ff       	jmp    af30 <fwp_main_thread+0x250>
    b186:	49 8b 44 24 40       	mov    0x40(%r12),%rax
    b18b:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b192:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b199:	00 00 00 00 
    b19d:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    b1a4:	48 85 c0             	test   %rax,%rax
    b1a7:	0f 84 3e 12 00 00    	je     c3eb <fwp_main_thread+0x170b>
    b1ad:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    b1b4:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    b1b9:	e9 38 fd ff ff       	jmp    aef6 <fwp_main_thread+0x216>
    b1be:	48 83 3d 52 e6 05 00 	cmpq   $0x0,0x5e652(%rip)        # 69818 <fwp_root>
    b1c5:	00 
    b1c6:	c7 05 d0 5e 01 00 00 	movl   $0x0,0x15ed0(%rip)        # 210a0 <fwp_exit_code>
    b1cd:	00 00 00 
    b1d0:	0f 85 2f 14 00 00    	jne    c605 <fwp_main_thread+0x1925>
    b1d6:	e8 75 c4 ff ff       	call   7650 <fwp_free_zombie>
    b1db:	48 83 3d 25 e6 05 00 	cmpq   $0x0,0x5e625(%rip)        # 69808 <fwp_ready_head>
    b1e2:	00 
    b1e3:	0f 85 67 85 ff ff    	jne    3750 <fwp_main_thread.cold>
    b1e9:	48 83 3d 07 e6 05 00 	cmpq   $0x0,0x5e607(%rip)        # 697f8 <fwp_timers>
    b1f0:	00 
    b1f1:	0f 85 59 85 ff ff    	jne    3750 <fwp_main_thread.cold>
    b1f7:	8b 05 f7 df 05 00    	mov    0x5dff7(%rip),%eax        # 691f4 <fwp_stack_pool_n>
    b1fd:	85 c0                	test   %eax,%eax
    b1ff:	74 37                	je     b238 <fwp_main_thread+0x558>
    b201:	83 e8 01             	sub    $0x1,%eax
    b204:	4c 8d 2d f5 df 05 00 	lea    0x5dff5(%rip),%r13        # 69200 <fwp_stack_pool>
    b20b:	48 63 d8             	movslq %eax,%rbx
    b20e:	89 c0                	mov    %eax,%eax
    b210:	48 89 da             	mov    %rbx,%rdx
    b213:	48 29 c2             	sub    %rax,%rdx
    b216:	4c 8d 62 ff          	lea    -0x1(%rdx),%r12
    b21a:	49 8b 7c dd 00       	mov    0x0(%r13,%rbx,8),%rdi
    b21f:	89 1d cf df 05 00    	mov    %ebx,0x5dfcf(%rip)        # 691f4 <fwp_stack_pool_n>
    b225:	be 00 00 00 10       	mov    $0x10000000,%esi
    b22a:	48 83 eb 01          	sub    $0x1,%rbx
    b22e:	e8 8d 83 ff ff       	call   35c0 <munmap@plt>
    b233:	4c 39 e3             	cmp    %r12,%rbx
    b236:	75 e2                	jne    b21a <fwp_main_thread+0x53a>
    b238:	8b 3d e2 5d 00 00    	mov    0x5de2(%rip),%edi        # 11020 <fwp_epfd>
    b23e:	85 ff                	test   %edi,%edi
    b240:	78 05                	js     b247 <fwp_main_thread+0x567>
    b242:	e8 79 82 ff ff       	call   34c0 <close@plt>
    b247:	4c 8b 2d b2 e1 05 00 	mov    0x5e1b2(%rip),%r13        # 69400 <fwp_nfdws>
    b24e:	4c 8b 25 b3 e1 05 00 	mov    0x5e1b3(%rip),%r12        # 69408 <fwp_fdws>
    b255:	31 db                	xor    %ebx,%ebx
    b257:	c7 05 bf 5d 00 00 ff 	movl   $0xffffffff,0x5dbf(%rip)        # 11020 <fwp_epfd>
    b25e:	ff ff ff 
    b261:	4d 85 ed             	test   %r13,%r13
    b264:	74 2c                	je     b292 <fwp_main_thread+0x5b2>
    b266:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b26a:	48 85 ff             	test   %rdi,%rdi
    b26d:	74 1a                	je     b289 <fwp_main_thread+0x5a9>
    b26f:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    b273:	0f 85 d7 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b279:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    b27e:	0f 85 cc 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b284:	e8 87 a7 ff ff       	call   5a10 <fwp_mem_free>
    b289:	48 83 c3 01          	add    $0x1,%rbx
    b28d:	49 39 dd             	cmp    %rbx,%r13
    b290:	75 d4                	jne    b266 <fwp_main_thread+0x586>
    b292:	4c 89 e7             	mov    %r12,%rdi
    b295:	e8 76 a7 ff ff       	call   5a10 <fwp_mem_free>
    b29a:	48 8b 15 77 e5 05 00 	mov    0x5e577(%rip),%rdx        # 69818 <fwp_root>
    b2a1:	48 c7 05 5c e1 05 00 	movq   $0x0,0x5e15c(%rip)        # 69408 <fwp_fdws>
    b2a8:	00 00 00 00 
    b2ac:	48 c7 05 49 e1 05 00 	movq   $0x0,0x5e149(%rip)        # 69400 <fwp_nfdws>
    b2b3:	00 00 00 00 
    b2b7:	48 85 d2             	test   %rdx,%rdx
    b2ba:	74 4e                	je     b30a <fwp_main_thread+0x62a>
    b2bc:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    b2c1:	0f 85 89 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2c7:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    b2ce:	00 
    b2cf:	0f 85 7b 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2d5:	48 83 3d db 01 06 00 	cmpq   $0x0,0x601db(%rip)        # 6b4b8 <fwp_state_len>
    b2dc:	00 
    b2dd:	0f 85 6d 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2e3:	48 83 3d bd 01 06 00 	cmpq   $0x0,0x601bd(%rip)        # 6b4a8 <fwp_state_owners>
    b2ea:	00 
    b2eb:	0f 85 5f 84 ff ff    	jne    3750 <fwp_main_thread.cold>
    b2f1:	b9 79 00 00 00       	mov    $0x79,%ecx
    b2f6:	31 c0                	xor    %eax,%eax
    b2f8:	48 8d 3d 21 e1 05 00 	lea    0x5e121(%rip),%rdi        # 69420 <fwp_root_context>
    b2ff:	f3 48 ab             	rep stos %rax,(%rdi)
    b302:	48 89 d7             	mov    %rdx,%rdi
    b305:	e8 06 a7 ff ff       	call   5a10 <fwp_mem_free>
    b30a:	66 0f 6f 05 be 5e 04 	movdqa 0x45ebe(%rip),%xmm0        # 511d0 <ad_raw_live+0x10>
    b311:	00 
    b312:	66 0f d4 05 a6 5e 04 	paddq  0x45ea6(%rip),%xmm0        # 511c0 <ad_raw_live>
    b319:	00 
    b31a:	48 c7 05 fb e4 05 00 	movq   $0x0,0x5e4fb(%rip)        # 69820 <fwp_cur>
    b321:	00 00 00 00 
    b325:	48 8b 05 34 f9 05 00 	mov    0x5f934(%rip),%rax        # 6ac60 <fwp_heap+0x1420>
    b32c:	48 c7 05 e1 e4 05 00 	movq   $0x0,0x5e4e1(%rip)        # 69818 <fwp_root>
    b333:	00 00 00 00 
    b337:	c7 05 c7 01 06 00 00 	movl   $0x0,0x601c7(%rip)        # 6b508 <iteration_active>
    b33e:	00 00 00 
    b341:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    b345:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    b34a:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    b34e:	66 0f d6 05 c2 5d 01 	movq   %xmm0,0x15dc2(%rip)        # 21118 <ad_raw_before_shutdown>
    b355:	00 
    b356:	48 85 c0             	test   %rax,%rax
    b359:	0f 88 6e 10 00 00    	js     c3cd <fwp_main_thread+0x16ed>
    b35f:	66 0f ef c9          	pxor   %xmm1,%xmm1
    b363:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    b368:	f2 0f 5c 0d 78 01 06 	subsd  0x60178(%rip),%xmm1        # 6b4e8 <iteration_start_charge>
    b36f:	00 
    b370:	48 8b 3d e9 5c 00 00 	mov    0x5ce9(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    b377:	48 8d 15 e2 27 00 00 	lea    0x27e2(%rip),%rdx        # db60 <_IO_stdin_used+0xb60>
    b37e:	be 02 00 00 00       	mov    $0x2,%esi
    b383:	f2 0f 10 05 55 01 06 	movsd  0x60155(%rip),%xmm0        # 6b4e0 <iteration_peak>
    b38a:	00 
    b38b:	4c 8b 0d 5e 01 06 00 	mov    0x6015e(%rip),%r9        # 6b4f0 <iteration_retains>
    b392:	b8 02 00 00 00       	mov    $0x2,%eax
    b397:	4c 8b 05 5a 01 06 00 	mov    0x6015a(%rip),%r8        # 6b4f8 <iteration_bytes>
    b39e:	48 8b 0d 5b 01 06 00 	mov    0x6015b(%rip),%rcx        # 6b500 <iteration_requests>
    b3a5:	e8 c6 82 ff ff       	call   3670 <__fprintf_chk@plt>
    b3aa:	48 8b 3d 8f 5c 00 00 	mov    0x5c8f(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    b3b1:	e8 ea 81 ff ff       	call   35a0 <fflush@plt>
    b3b6:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    b3ba:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b3c1:	00 00 
    b3c3:	0f 85 fb 11 00 00    	jne    c5c4 <fwp_main_thread+0x18e4>
    b3c9:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    b3cd:	31 c0                	xor    %eax,%eax
    b3cf:	5b                   	pop    %rbx
    b3d0:	41 5c                	pop    %r12
    b3d2:	41 5d                	pop    %r13
    b3d4:	41 5e                	pop    %r14
    b3d6:	41 5f                	pop    %r15
    b3d8:	5d                   	pop    %rbp
    b3d9:	c3                   	ret
    b3da:	48 89 05 17 e4 05 00 	mov    %rax,0x5e417(%rip)        # 697f8 <fwp_timers>
    b3e1:	e9 9b fb ff ff       	jmp    af81 <fwp_main_thread+0x2a1>
    b3e6:	48 89 c2             	mov    %rax,%rdx
    b3e9:	83 e0 01             	and    $0x1,%eax
    b3ec:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b3f0:	48 d1 ea             	shr    $1,%rdx
    b3f3:	48 09 c2             	or     %rax,%rdx
    b3f6:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    b3fb:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    b3ff:	e9 00 fa ff ff       	jmp    ae04 <fwp_main_thread+0x124>
    b404:	e8 c7 99 ff ff       	call   4dd0 <fwp_heap_init>
    b409:	44 8b 05 d8 f7 05 00 	mov    0x5f7d8(%rip),%r8d        # 6abe8 <fwp_heap+0x13a8>
    b410:	45 85 c0             	test   %r8d,%r8d
    b413:	0f 84 0e f9 ff ff    	je     ad27 <fwp_main_thread+0x47>
    b419:	48 8d 3d a0 98 ff ff 	lea    -0x6760(%rip),%rdi        # 4cc0 <fwp_heap_report>
    b420:	e8 fb 13 00 00       	call   c820 <atexit>
    b425:	e9 fd f8 ff ff       	jmp    ad27 <fwp_main_thread+0x47>
    b42a:	48 8d 05 3f bb ff ff 	lea    -0x44c1(%rip),%rax        # 6f70 <fwp_drop1>
    b431:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b435:	45 31 ff             	xor    %r15d,%r15d
    b438:	48 c7 85 f0 fe ff ff 	movq   $0x0,-0x110(%rbp)
    b43f:	00 00 00 00 
    b443:	66 48 0f 6e e8       	movq   %rax,%xmm5
    b448:	48 8b 05 89 00 06 00 	mov    0x60089(%rip),%rax        # 6b4d8 <fwp_cleanups>
    b44f:	4c 89 ad e0 fe ff ff 	mov    %r13,-0x120(%rbp)
    b456:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    b45a:	48 89 1d 77 00 06 00 	mov    %rbx,0x60077(%rip)        # 6b4d8 <fwp_cleanups>
    b461:	bb ff 01 00 00       	mov    $0x1ff,%ebx
    b466:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
    b46d:	48 8d 05 5c 87 ff ff 	lea    -0x78a4(%rip),%rax        # 3bd0 <fwp_range_release>
    b474:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
    b47b:	0f 29 85 00 ff ff ff 	movaps %xmm0,-0x100(%rbp)
    b482:	eb 3d                	jmp    b4c1 <fwp_main_thread+0x7e1>
    b484:	80 f9 01             	cmp    $0x1,%cl
    b487:	75 27                	jne    b4b0 <fwp_main_thread+0x7d0>
    b489:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b48c:	0f b7 c0             	movzwl %ax,%eax
    b48f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b492:	48 0f af c1          	imul   %rcx,%rax
    b496:	48 c1 e8 20          	shr    $0x20,%rax
    b49a:	48 39 d0             	cmp    %rdx,%rax
    b49d:	73 11                	jae    b4b0 <fwp_main_thread+0x7d0>
    b49f:	49 01 c6             	add    %rax,%r14
    b4a2:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b4a6:	0f 84 95 0f 00 00    	je     c441 <fwp_main_thread+0x1761>
    b4ac:	41 c6 06 01          	movb   $0x1,(%r14)
    b4b0:	4c 89 bd f0 fe ff ff 	mov    %r15,-0x110(%rbp)
    b4b7:	48 83 eb 01          	sub    $0x1,%rbx
    b4bb:	0f 82 8f 00 00 00    	jb     b550 <fwp_main_thread+0x870>
    b4c1:	bf 01 00 00 00       	mov    $0x1,%edi
    b4c6:	4c 89 e6             	mov    %r12,%rsi
    b4c9:	4c 89 bd 38 ff ff ff 	mov    %r15,-0xc8(%rbp)
    b4d0:	48 89 9d f8 fe ff ff 	mov    %rbx,-0x108(%rbp)
    b4d7:	48 89 9d 30 ff ff ff 	mov    %rbx,-0xd0(%rbp)
    b4de:	e8 5d b3 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    b4e3:	48 8d 3d 56 e3 05 00 	lea    0x5e356(%rip),%rdi        # 69840 <fwp_heap>
    b4ea:	48 8b 97 d8 13 00 00 	mov    0x13d8(%rdi),%rdx
    b4f1:	49 89 c7             	mov    %rax,%r15
    b4f4:	48 2b 87 b0 13 00 00 	sub    0x13b0(%rdi),%rax
    b4fb:	48 89 95 c8 fe ff ff 	mov    %rdx,-0x138(%rbp)
    b502:	48 c1 e2 10          	shl    $0x10,%rdx
    b506:	48 39 d0             	cmp    %rdx,%rax
    b509:	73 a5                	jae    b4b0 <fwp_main_thread+0x7d0>
    b50b:	48 89 c2             	mov    %rax,%rdx
    b50e:	48 c1 ea 10          	shr    $0x10,%rdx
    b512:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b516:	48 8b 97 f8 13 00 00 	mov    0x13f8(%rdi),%rdx
    b51d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b521:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b525:	4d 85 f6             	test   %r14,%r14
    b528:	74 86                	je     b4b0 <fwp_main_thread+0x7d0>
    b52a:	0f b6 0a             	movzbl (%rdx),%ecx
    b52d:	80 f9 02             	cmp    $0x2,%cl
    b530:	0f 85 4e ff ff ff    	jne    b484 <fwp_main_thread+0x7a4>
    b536:	66 85 c0             	test   %ax,%ax
    b539:	0f 84 63 ff ff ff    	je     b4a2 <fwp_main_thread+0x7c2>
    b53f:	4c 89 bd f0 fe ff ff 	mov    %r15,-0x110(%rbp)
    b546:	48 83 eb 01          	sub    $0x1,%rbx
    b54a:	0f 83 71 ff ff ff    	jae    b4c1 <fwp_main_thread+0x7e1>
    b550:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
    b557:	66 0f 6f 05 71 28 00 	movdqa 0x2871(%rip),%xmm0        # ddd0 <msg.4+0xa0>
    b55e:	00 
    b55f:	4c 89 e6             	mov    %r12,%rsi
    b562:	bf 01 00 00 00       	mov    $0x1,%edi
    b567:	48 89 05 6a ff 05 00 	mov    %rax,0x5ff6a(%rip)        # 6b4d8 <fwp_cleanups>
    b56e:	0f 29 85 30 ff ff ff 	movaps %xmm0,-0xd0(%rbp)
    b575:	e8 c6 b2 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    b57a:	48 8b 15 97 f6 05 00 	mov    0x5f697(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    b581:	49 89 c4             	mov    %rax,%r12
    b584:	48 2b 05 65 f6 05 00 	sub    0x5f665(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    b58b:	48 c1 e2 10          	shl    $0x10,%rdx
    b58f:	48 39 d0             	cmp    %rdx,%rax
    b592:	73 55                	jae    b5e9 <fwp_main_thread+0x909>
    b594:	48 89 c2             	mov    %rax,%rdx
    b597:	48 c1 ea 10          	shr    $0x10,%rdx
    b59b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b59f:	48 8b 15 92 f6 05 00 	mov    0x5f692(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    b5a6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b5aa:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    b5ae:	48 85 db             	test   %rbx,%rbx
    b5b1:	74 36                	je     b5e9 <fwp_main_thread+0x909>
    b5b3:	0f b6 0a             	movzbl (%rdx),%ecx
    b5b6:	80 f9 02             	cmp    $0x2,%cl
    b5b9:	0f 84 66 0e 00 00    	je     c425 <fwp_main_thread+0x1745>
    b5bf:	80 f9 01             	cmp    $0x1,%cl
    b5c2:	75 25                	jne    b5e9 <fwp_main_thread+0x909>
    b5c4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b5c7:	0f b7 c0             	movzwl %ax,%eax
    b5ca:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b5cd:	48 0f af c1          	imul   %rcx,%rax
    b5d1:	48 c1 e8 20          	shr    $0x20,%rax
    b5d5:	48 39 d0             	cmp    %rdx,%rax
    b5d8:	73 0f                	jae    b5e9 <fwp_main_thread+0x909>
    b5da:	48 01 c3             	add    %rax,%rbx
    b5dd:	80 3b ff             	cmpb   $0xff,(%rbx)
    b5e0:	0f 84 83 0e 00 00    	je     c469 <fwp_main_thread+0x1789>
    b5e6:	c6 03 01             	movb   $0x1,(%rbx)
    b5e9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b5f0:	00 f0 3f 
    b5f3:	48 8d b5 20 ff ff ff 	lea    -0xe0(%rbp),%rsi
    b5fa:	bf 01 00 00 00       	mov    $0x1,%edi
    b5ff:	4c 89 a5 28 ff ff ff 	mov    %r12,-0xd8(%rbp)
    b606:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
    b60d:	e8 2e b2 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    b612:	48 8b 15 ff f5 05 00 	mov    0x5f5ff(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    b619:	49 89 c4             	mov    %rax,%r12
    b61c:	48 2b 05 cd f5 05 00 	sub    0x5f5cd(%rip),%rax        # 6abf0 <fwp_heap+0x13b0>
    b623:	48 c1 e2 10          	shl    $0x10,%rdx
    b627:	48 39 d0             	cmp    %rdx,%rax
    b62a:	73 55                	jae    b681 <fwp_main_thread+0x9a1>
    b62c:	48 89 c2             	mov    %rax,%rdx
    b62f:	48 c1 ea 10          	shr    $0x10,%rdx
    b633:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b637:	48 8b 15 fa f5 05 00 	mov    0x5f5fa(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    b63e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b642:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    b646:	48 85 db             	test   %rbx,%rbx
    b649:	74 36                	je     b681 <fwp_main_thread+0x9a1>
    b64b:	0f b6 0a             	movzbl (%rdx),%ecx
    b64e:	80 f9 02             	cmp    $0x2,%cl
    b651:	0f 84 dc 0d 00 00    	je     c433 <fwp_main_thread+0x1753>
    b657:	80 f9 01             	cmp    $0x1,%cl
    b65a:	75 25                	jne    b681 <fwp_main_thread+0x9a1>
    b65c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b65f:	0f b7 c0             	movzwl %ax,%eax
    b662:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b665:	48 0f af c1          	imul   %rcx,%rax
    b669:	48 c1 e8 20          	shr    $0x20,%rax
    b66d:	48 39 d0             	cmp    %rdx,%rax
    b670:	73 0f                	jae    b681 <fwp_main_thread+0x9a1>
    b672:	48 01 c3             	add    %rax,%rbx
    b675:	80 3b ff             	cmpb   $0xff,(%rbx)
    b678:	0f 84 ba 0e 00 00    	je     c538 <fwp_main_thread+0x1858>
    b67e:	c6 03 01             	movb   $0x1,(%rbx)
    b681:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b688:	33 f3 bf 
    b68b:	48 8d b5 10 ff ff ff 	lea    -0xf0(%rbp),%rsi
    b692:	bf 01 00 00 00       	mov    $0x1,%edi
    b697:	4c 89 a5 18 ff ff ff 	mov    %r12,-0xe8(%rbp)
    b69e:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
    b6a5:	e8 96 b1 ff ff       	call   6840 <fwp_data.part.0.constprop.0>
    b6aa:	48 8b 15 67 f5 05 00 	mov    0x5f567(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    b6b1:	48 8b 0d 38 f5 05 00 	mov    0x5f538(%rip),%rcx        # 6abf0 <fwp_heap+0x13b0>
    b6b8:	48 89 85 88 fe ff ff 	mov    %rax,-0x178(%rbp)
    b6bf:	48 89 d6             	mov    %rdx,%rsi
    b6c2:	48 29 c8             	sub    %rcx,%rax
    b6c5:	48 c1 e6 10          	shl    $0x10,%rsi
    b6c9:	48 39 f0             	cmp    %rsi,%rax
    b6cc:	73 65                	jae    b733 <fwp_main_thread+0xa53>
    b6ce:	48 89 c6             	mov    %rax,%rsi
    b6d1:	48 c1 ee 10          	shr    $0x10,%rsi
    b6d5:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    b6d9:	48 8b 35 58 f5 05 00 	mov    0x5f558(%rip),%rsi        # 6ac38 <fwp_heap+0x13f8>
    b6e0:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b6e4:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    b6e8:	48 85 db             	test   %rbx,%rbx
    b6eb:	74 46                	je     b733 <fwp_main_thread+0xa53>
    b6ed:	0f b6 3e             	movzbl (%rsi),%edi
    b6f0:	40 80 ff 02          	cmp    $0x2,%dil
    b6f4:	0f 84 1d 0d 00 00    	je     c417 <fwp_main_thread+0x1737>
    b6fa:	40 80 ff 01          	cmp    $0x1,%dil
    b6fe:	75 33                	jne    b733 <fwp_main_thread+0xa53>
    b700:	8b 7e 18             	mov    0x18(%rsi),%edi
    b703:	0f b7 c0             	movzwl %ax,%eax
    b706:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b709:	48 0f af c7          	imul   %rdi,%rax
    b70d:	48 c1 e8 20          	shr    $0x20,%rax
    b711:	48 39 f0             	cmp    %rsi,%rax
    b714:	73 1d                	jae    b733 <fwp_main_thread+0xa53>
    b716:	48 01 c3             	add    %rax,%rbx
    b719:	80 3b ff             	cmpb   $0xff,(%rbx)
    b71c:	0f 84 23 0e 00 00    	je     c545 <fwp_main_thread+0x1865>
    b722:	c6 03 01             	movb   $0x1,(%rbx)
    b725:	48 8b 0d c4 f4 05 00 	mov    0x5f4c4(%rip),%rcx        # 6abf0 <fwp_heap+0x13b0>
    b72c:	48 8b 15 e5 f4 05 00 	mov    0x5f4e5(%rip),%rdx        # 6ac18 <fwp_heap+0x13d8>
    b733:	4c 89 bd 80 fe ff ff 	mov    %r15,-0x180(%rbp)
    b73a:	4c 89 bd 78 fe ff ff 	mov    %r15,-0x188(%rbp)
    b741:	48 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%rax
    b748:	48 c1 e2 10          	shl    $0x10,%rdx
    b74c:	48 29 c8             	sub    %rcx,%rax
    b74f:	48 39 d0             	cmp    %rdx,%rax
    b752:	73 6f                	jae    b7c3 <fwp_main_thread+0xae3>
    b754:	48 89 c2             	mov    %rax,%rdx
    b757:	48 c1 ea 10          	shr    $0x10,%rdx
    b75b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b75f:	48 8b 15 d2 f4 05 00 	mov    0x5f4d2(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    b766:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b76a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    b76e:	48 85 ff             	test   %rdi,%rdi
    b771:	74 50                	je     b7c3 <fwp_main_thread+0xae3>
    b773:	0f b6 0a             	movzbl (%rdx),%ecx
    b776:	80 f9 02             	cmp    $0x2,%cl
    b779:	0f 84 8a 0c 00 00    	je     c409 <fwp_main_thread+0x1729>
    b77f:	80 f9 01             	cmp    $0x1,%cl
    b782:	75 3f                	jne    b7c3 <fwp_main_thread+0xae3>
    b784:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b787:	0f b7 c0             	movzwl %ax,%eax
    b78a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b78d:	48 0f af c1          	imul   %rcx,%rax
    b791:	48 c1 e8 20          	shr    $0x20,%rax
    b795:	48 39 d0             	cmp    %rdx,%rax
    b798:	73 29                	jae    b7c3 <fwp_main_thread+0xae3>
    b79a:	48 01 c7             	add    %rax,%rdi
    b79d:	0f b6 07             	movzbl (%rdi),%eax
    b7a0:	84 c0                	test   %al,%al
    b7a2:	74 1f                	je     b7c3 <fwp_main_thread+0xae3>
    b7a4:	8b 35 5e fd 05 00    	mov    0x5fd5e(%rip),%esi        # 6b508 <iteration_active>
    b7aa:	85 f6                	test   %esi,%esi
    b7ac:	74 08                	je     b7b6 <fwp_main_thread+0xad6>
    b7ae:	48 83 05 3a fd 05 00 	addq   $0x1,0x5fd3a(%rip)        # 6b4f0 <iteration_retains>
    b7b5:	01 
    b7b6:	3c fd                	cmp    $0xfd,%al
    b7b8:	0f 87 94 0d 00 00    	ja     c552 <fwp_main_thread+0x1872>
    b7be:	83 c0 01             	add    $0x1,%eax
    b7c1:	88 07                	mov    %al,(%rdi)
    b7c3:	48 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%rax
    b7ca:	48 8b 15 c7 fc 05 00 	mov    0x5fcc7(%rip),%rdx        # 6b498 <fwp_fns>
    b7d1:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
    b7d8:	48 8d 05 39 58 00 00 	lea    0x5839(%rip),%rax        # 11018 <fc12>
    b7df:	44 8b 20             	mov    (%rax),%r12d
    b7e2:	49 c1 e4 05          	shl    $0x5,%r12
    b7e6:	49 01 d4             	add    %rdx,%r12
    b7e9:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
    b7ee:	48 85 c9             	test   %rcx,%rcx
    b7f1:	0f 84 89 0d 00 00    	je     c580 <fwp_main_thread+0x18a0>
    b7f7:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    b7fc:	0f 84 8e 09 00 00    	je     c190 <fwp_main_thread+0x14b0>
    b802:	48 8d 3d 37 e0 05 00 	lea    0x5e037(%rip),%rdi        # 69840 <fwp_heap>
    b809:	48 8d 05 08 58 00 00 	lea    0x5808(%rip),%rax        # 11018 <fc12>
    b810:	48 8b b7 d8 13 00 00 	mov    0x13d8(%rdi),%rsi
    b817:	48 2b 87 b0 13 00 00 	sub    0x13b0(%rdi),%rax
    b81e:	48 89 f1             	mov    %rsi,%rcx
    b821:	48 89 b5 c8 fe ff ff 	mov    %rsi,-0x138(%rbp)
    b828:	48 c1 e1 10          	shl    $0x10,%rcx
    b82c:	48 39 c8             	cmp    %rcx,%rax
    b82f:	73 71                	jae    b8a2 <fwp_main_thread+0xbc2>
    b831:	48 89 c1             	mov    %rax,%rcx
    b834:	48 c1 e9 10          	shr    $0x10,%rcx
    b838:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b83c:	48 8b 8f f8 13 00 00 	mov    0x13f8(%rdi),%rcx
    b843:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b847:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    b84b:	48 85 ff             	test   %rdi,%rdi
    b84e:	74 52                	je     b8a2 <fwp_main_thread+0xbc2>
    b850:	0f b6 31             	movzbl (%rcx),%esi
    b853:	40 80 fe 02          	cmp    $0x2,%sil
    b857:	0f 84 62 0a 00 00    	je     c2bf <fwp_main_thread+0x15df>
    b85d:	40 80 fe 01          	cmp    $0x1,%sil
    b861:	75 3f                	jne    b8a2 <fwp_main_thread+0xbc2>
    b863:	8b 71 18             	mov    0x18(%rcx),%esi
    b866:	0f b7 c0             	movzwl %ax,%eax
    b869:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b86c:	48 0f af c6          	imul   %rsi,%rax
    b870:	48 c1 e8 20          	shr    $0x20,%rax
    b874:	48 39 c8             	cmp    %rcx,%rax
    b877:	73 29                	jae    b8a2 <fwp_main_thread+0xbc2>
    b879:	48 01 c7             	add    %rax,%rdi
    b87c:	0f b6 07             	movzbl (%rdi),%eax
    b87f:	84 c0                	test   %al,%al
    b881:	74 1f                	je     b8a2 <fwp_main_thread+0xbc2>
    b883:	8b 0d 7f fc 05 00    	mov    0x5fc7f(%rip),%ecx        # 6b508 <iteration_active>
    b889:	85 c9                	test   %ecx,%ecx
    b88b:	74 08                	je     b895 <fwp_main_thread+0xbb5>
    b88d:	48 83 05 5b fc 05 00 	addq   $0x1,0x5fc5b(%rip)        # 6b4f0 <iteration_retains>
    b894:	01 
    b895:	3c fd                	cmp    $0xfd,%al
    b897:	0f 87 1f 0b 00 00    	ja     c3bc <fwp_main_thread+0x16dc>
    b89d:	83 c0 01             	add    $0x1,%eax
    b8a0:	88 07                	mov    %al,(%rdi)
    b8a2:	48 8d 05 6f 57 00 00 	lea    0x576f(%rip),%rax        # 11018 <fc12>
    b8a9:	4c 89 ad a8 fe ff ff 	mov    %r13,-0x158(%rbp)
    b8b0:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
    b8b7:	c7 85 a4 fe ff ff 01 	movl   $0x1,-0x15c(%rbp)
    b8be:	00 00 00 
    b8c1:	4c 89 ad 90 fe ff ff 	mov    %r13,-0x170(%rbp)
    b8c8:	41 8b 0c 24          	mov    (%r12),%ecx
    b8cc:	2b 48 04             	sub    0x4(%rax),%ecx
    b8cf:	48 8b 85 c8 fe ff ff 	mov    -0x138(%rbp),%rax
    b8d6:	44 8b ad a4 fe ff ff 	mov    -0x15c(%rbp),%r13d
    b8dd:	89 8d 9c fe ff ff    	mov    %ecx,-0x164(%rbp)
    b8e3:	4c 8b a5 a8 fe ff ff 	mov    -0x158(%rbp),%r12
    b8ea:	49 89 c1             	mov    %rax,%r9
    b8ed:	8b 00                	mov    (%rax),%eax
    b8ef:	44 39 e9             	cmp    %r13d,%ecx
    b8f2:	44 0f 46 e9          	cmovbe %ecx,%r13d
    b8f6:	4d 89 cf             	mov    %r9,%r15
    b8f9:	48 c1 e0 05          	shl    $0x5,%rax
    b8fd:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    b901:	44 89 ad a0 fe ff ff 	mov    %r13d,-0x160(%rbp)
    b908:	48 8b 41 18          	mov    0x18(%rcx),%rax
    b90c:	48 85 c0             	test   %rax,%rax
    b90f:	0f 84 3e 02 00 00    	je     bb53 <fwp_main_thread+0xe73>
    b915:	49 89 c2             	mov    %rax,%r10
    b918:	eb 62                	jmp    b97c <fwp_main_thread+0xc9c>
    b91a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b920:	45 85 ff             	test   %r15d,%r15d
    b923:	74 76                	je     b99b <fwp_main_thread+0xcbb>
    b925:	4c 89 e7             	mov    %r12,%rdi
    b928:	41 ff 12             	call   *(%r10)
    b92b:	48 8b bd c8 fe ff ff 	mov    -0x138(%rbp),%rdi
    b932:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
    b939:	e8 92 b7 ff ff       	call   70d0 <fwp_closure_drop>
    b93e:	44 39 eb             	cmp    %r13d,%ebx
    b941:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
    b948:	0f 84 32 08 00 00    	je     c180 <fwp_main_thread+0x14a0>
    b94e:	8b 08                	mov    (%rax),%ecx
    b950:	45 29 fe             	sub    %r15d,%r14d
    b953:	4d 8d 24 dc          	lea    (%r12,%rbx,8),%r12
    b957:	49 89 c1             	mov    %rax,%r9
    b95a:	45 89 f5             	mov    %r14d,%r13d
    b95d:	48 c1 e1 05          	shl    $0x5,%rcx
    b961:	48 03 0d 30 fb 05 00 	add    0x5fb30(%rip),%rcx        # 6b498 <fwp_fns>
    b968:	4c 8b 51 18          	mov    0x18(%rcx),%r10
    b96c:	4d 85 d2             	test   %r10,%r10
    b96f:	0f 84 db 01 00 00    	je     bb50 <fwp_main_thread+0xe70>
    b975:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
    b97c:	45 8b 41 04          	mov    0x4(%r9),%r8d
    b980:	44 8b 39             	mov    (%rcx),%r15d
    b983:	47 8d 34 28          	lea    (%r8,%r13,1),%r14d
    b987:	45 39 fe             	cmp    %r15d,%r14d
    b98a:	0f 82 d0 04 00 00    	jb     be60 <fwp_main_thread+0x1180>
    b990:	44 89 fb             	mov    %r15d,%ebx
    b993:	44 29 c3             	sub    %r8d,%ebx
    b996:	45 85 c0             	test   %r8d,%r8d
    b999:	74 85                	je     b920 <fwp_main_thread+0xc40>
    b99b:	45 85 ff             	test   %r15d,%r15d
    b99e:	b8 01 00 00 00       	mov    $0x1,%eax
    b9a3:	48 89 e6             	mov    %rsp,%rsi
    b9a6:	48 89 a5 c0 fe ff ff 	mov    %rsp,-0x140(%rbp)
    b9ad:	41 0f 45 c7          	cmovne %r15d,%eax
    b9b1:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    b9b8:	00 
    b9b9:	48 c1 e8 04          	shr    $0x4,%rax
    b9bd:	48 c1 e0 04          	shl    $0x4,%rax
    b9c1:	48 89 c7             	mov    %rax,%rdi
    b9c4:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    b9cb:	48 29 fe             	sub    %rdi,%rsi
    b9ce:	48 39 f4             	cmp    %rsi,%rsp
    b9d1:	74 15                	je     b9e8 <fwp_main_thread+0xd08>
    b9d3:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    b9da:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    b9e1:	00 00 
    b9e3:	48 39 f4             	cmp    %rsi,%rsp
    b9e6:	75 eb                	jne    b9d3 <fwp_main_thread+0xcf3>
    b9e8:	25 ff 0f 00 00       	and    $0xfff,%eax
    b9ed:	48 29 c4             	sub    %rax,%rsp
    b9f0:	48 85 c0             	test   %rax,%rax
    b9f3:	74 06                	je     b9fb <fwp_main_thread+0xd1b>
    b9f5:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    b9fb:	44 89 c0             	mov    %r8d,%eax
    b9fe:	48 89 a5 b0 fe ff ff 	mov    %rsp,-0x150(%rbp)
    ba05:	48 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%rsi
    ba0c:	00 
    ba0d:	31 c0                	xor    %eax,%eax
    ba0f:	45 85 c0             	test   %r8d,%r8d
    ba12:	74 25                	je     ba39 <fwp_main_thread+0xd59>
    ba14:	90                   	nop
    ba15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ba1c:	00 00 00 00 
    ba20:	49 8b 54 01 08       	mov    0x8(%r9,%rax,1),%rdx
    ba25:	48 8b bd b0 fe ff ff 	mov    -0x150(%rbp),%rdi
    ba2c:	48 89 14 07          	mov    %rdx,(%rdi,%rax,1)
    ba30:	48 83 c0 08          	add    $0x8,%rax
    ba34:	48 39 c6             	cmp    %rax,%rsi
    ba37:	75 e7                	jne    ba20 <fwp_main_thread+0xd40>
    ba39:	85 db                	test   %ebx,%ebx
    ba3b:	74 41                	je     ba7e <fwp_main_thread+0xd9e>
    ba3d:	89 d8                	mov    %ebx,%eax
    ba3f:	4c 89 e6             	mov    %r12,%rsi
    ba42:	49 8d 04 c4          	lea    (%r12,%rax,8),%rax
    ba46:	0f 1f 40 00          	nopl   0x0(%rax)
    ba4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ba51:	00 00 00 00 
    ba55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ba5c:	00 00 00 00 
    ba60:	48 8b 3e             	mov    (%rsi),%rdi
    ba63:	4c 8b 9d b0 fe ff ff 	mov    -0x150(%rbp),%r11
    ba6a:	44 89 c2             	mov    %r8d,%edx
    ba6d:	48 83 c6 08          	add    $0x8,%rsi
    ba71:	41 83 c0 01          	add    $0x1,%r8d
    ba75:	49 89 3c d3          	mov    %rdi,(%r11,%rdx,8)
    ba79:	48 39 f0             	cmp    %rsi,%rax
    ba7c:	75 e2                	jne    ba60 <fwp_main_thread+0xd80>
    ba7e:	48 8d 15 bb dd 05 00 	lea    0x5ddbb(%rip),%rdx        # 69840 <fwp_heap>
    ba85:	48 8b 85 c8 fe ff ff 	mov    -0x138(%rbp),%rax
    ba8c:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    ba93:	48 8b 92 d8 13 00 00 	mov    0x13d8(%rdx),%rdx
    ba9a:	48 89 d6             	mov    %rdx,%rsi
    ba9d:	48 89 95 b8 fe ff ff 	mov    %rdx,-0x148(%rbp)
    baa4:	48 c1 e6 10          	shl    $0x10,%rsi
    baa8:	48 39 f0             	cmp    %rsi,%rax
    baab:	73 4e                	jae    bafb <fwp_main_thread+0xe1b>
    baad:	48 89 c6             	mov    %rax,%rsi
    bab0:	48 c1 ee 10          	shr    $0x10,%rsi
    bab4:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    bab8:	48 8b 35 79 f1 05 00 	mov    0x5f179(%rip),%rsi        # 6ac38 <fwp_heap+0x13f8>
    babf:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    bac3:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    bac7:	48 85 ff             	test   %rdi,%rdi
    baca:	74 2f                	je     bafb <fwp_main_thread+0xe1b>
    bacc:	44 0f b6 06          	movzbl (%rsi),%r8d
    bad0:	41 80 f8 02          	cmp    $0x2,%r8b
    bad4:	74 72                	je     bb48 <fwp_main_thread+0xe68>
    bad6:	41 80 f8 01          	cmp    $0x1,%r8b
    bada:	75 1f                	jne    bafb <fwp_main_thread+0xe1b>
    badc:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    bae0:	0f b7 c0             	movzwl %ax,%eax
    bae3:	8b 76 1c             	mov    0x1c(%rsi),%esi
    bae6:	49 0f af c0          	imul   %r8,%rax
    baea:	48 c1 e8 20          	shr    $0x20,%rax
    baee:	48 39 f0             	cmp    %rsi,%rax
    baf1:	73 08                	jae    bafb <fwp_main_thread+0xe1b>
    baf3:	48 01 c7             	add    %rax,%rdi
    baf6:	80 3f 01             	cmpb   $0x1,(%rdi)
    baf9:	74 3d                	je     bb38 <fwp_main_thread+0xe58>
    bafb:	48 89 8d b8 fe ff ff 	mov    %rcx,-0x148(%rbp)
    bb02:	48 8b bd c8 fe ff ff 	mov    -0x138(%rbp),%rdi
    bb09:	be 01 00 00 00       	mov    $0x1,%esi
    bb0e:	41 ff 52 08          	call   *0x8(%r10)
    bb12:	48 8b 8d b8 fe ff ff 	mov    -0x148(%rbp),%rcx
    bb19:	48 8b 41 18          	mov    0x18(%rcx),%rax
    bb1d:	48 8b bd b0 fe ff ff 	mov    -0x150(%rbp),%rdi
    bb24:	ff 10                	call   *(%rax)
    bb26:	48 8b a5 c0 fe ff ff 	mov    -0x140(%rbp),%rsp
    bb2d:	e9 f9 fd ff ff       	jmp    b92b <fwp_main_thread+0xc4b>
    bb32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bb38:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    bb3f:	00 
    bb40:	eb d7                	jmp    bb19 <fwp_main_thread+0xe39>
    bb42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bb48:	66 85 c0             	test   %ax,%ax
    bb4b:	75 ae                	jne    bafb <fwp_main_thread+0xe1b>
    bb4d:	eb a7                	jmp    baf6 <fwp_main_thread+0xe16>
    bb4f:	90                   	nop
    bb50:	49 89 c7             	mov    %rax,%r15
    bb53:	4c 89 ff             	mov    %r15,%rdi
    bb56:	e8 d5 ae ff ff       	call   6a30 <fwp_rc_share>
    bb5b:	45 85 ed             	test   %r13d,%r13d
    bb5e:	74 21                	je     bb81 <fwp_main_thread+0xea1>
    bb60:	44 89 ea             	mov    %r13d,%edx
    bb63:	4d 89 e6             	mov    %r12,%r14
    bb66:	49 8d 1c d4          	lea    (%r12,%rdx,8),%rbx
    bb6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bb70:	49 8b 3e             	mov    (%r14),%rdi
    bb73:	49 83 c6 08          	add    $0x8,%r14
    bb77:	e8 b4 ae ff ff       	call   6a30 <fwp_rc_share>
    bb7c:	4c 39 f3             	cmp    %r14,%rbx
    bb7f:	75 ef                	jne    bb70 <fwp_main_thread+0xe90>
    bb81:	4c 89 e2             	mov    %r12,%rdx
    bb84:	44 89 ee             	mov    %r13d,%esi
    bb87:	4c 89 ff             	mov    %r15,%rdi
    bb8a:	e8 71 a5 ff ff       	call   6100 <fwp_apply>
    bb8f:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
    bb96:	8b 95 a4 fe ff ff    	mov    -0x15c(%rbp),%edx
    bb9c:	39 95 9c fe ff ff    	cmp    %edx,-0x164(%rbp)
    bba2:	0f 83 ca 05 00 00    	jae    c172 <fwp_main_thread+0x1492>
    bba8:	8b 85 a0 fe ff ff    	mov    -0x160(%rbp),%eax
    bbae:	48 8b b5 a8 fe ff ff 	mov    -0x158(%rbp),%rsi
    bbb5:	48 89 c7             	mov    %rax,%rdi
    bbb8:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    bbbc:	29 fa                	sub    %edi,%edx
    bbbe:	48 89 85 a8 fe ff ff 	mov    %rax,-0x158(%rbp)
    bbc5:	89 95 a4 fe ff ff    	mov    %edx,-0x15c(%rbp)
    bbcb:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
    bbd2:	44 8b 22             	mov    (%rdx),%r12d
    bbd5:	48 89 d0             	mov    %rdx,%rax
    bbd8:	48 8b 15 b9 f8 05 00 	mov    0x5f8b9(%rip),%rdx        # 6b498 <fwp_fns>
    bbdf:	49 c1 e4 05          	shl    $0x5,%r12
    bbe3:	49 01 d4             	add    %rdx,%r12
    bbe6:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
    bbec:	0f 85 d6 fc ff ff    	jne    b8c8 <fwp_main_thread+0xbe8>
    bbf2:	48 8b bd c8 fe ff ff 	mov    -0x138(%rbp),%rdi
    bbf9:	4c 8b ad 90 fe ff ff 	mov    -0x170(%rbp),%r13
    bc00:	e8 2b ae ff ff       	call   6a30 <fwp_rc_share>
    bc05:	44 8b b5 a4 fe ff ff 	mov    -0x15c(%rbp),%r14d
    bc0c:	45 85 f6             	test   %r14d,%r14d
    bc0f:	74 21                	je     bc32 <fwp_main_thread+0xf52>
    bc11:	4c 8b a5 a8 fe ff ff 	mov    -0x158(%rbp),%r12
    bc18:	31 db                	xor    %ebx,%ebx
    bc1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bc20:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    bc24:	48 83 c3 01          	add    $0x1,%rbx
    bc28:	e8 03 ae ff ff       	call   6a30 <fwp_rc_share>
    bc2d:	44 39 f3             	cmp    %r14d,%ebx
    bc30:	72 ee                	jb     bc20 <fwp_main_thread+0xf40>
    bc32:	48 8b 95 a8 fe ff ff 	mov    -0x158(%rbp),%rdx
    bc39:	8b b5 a4 fe ff ff    	mov    -0x15c(%rbp),%esi
    bc3f:	48 8b bd c8 fe ff ff 	mov    -0x138(%rbp),%rdi
    bc46:	e8 b5 a4 ff ff       	call   6100 <fwp_apply>
    bc4b:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
    bc52:	48 8b b5 c8 fe ff ff 	mov    -0x138(%rbp),%rsi
    bc59:	66 0f ef c0          	pxor   %xmm0,%xmm0
    bc5d:	b9 01 00 00 00       	mov    $0x1,%ecx
    bc62:	4c 89 ef             	mov    %r13,%rdi
    bc65:	48 8d 15 34 4f 00 00 	lea    0x4f34(%rip),%rdx        # 10ba0 <d0>
    bc6c:	0f 29 85 f0 fe ff ff 	movaps %xmm0,-0x110(%rbp)
    bc73:	48 c7 85 00 ff ff ff 	movq   $0x0,-0x100(%rbp)
    bc7a:	00 00 00 00 
    bc7e:	e8 1d e0 ff ff       	call   9ca0 <fwp_write>
    bc83:	4c 8b b5 f0 fe ff ff 	mov    -0x110(%rbp),%r14
    bc8a:	4c 8b a5 f8 fe ff ff 	mov    -0x108(%rbp),%r12
    bc91:	48 8d 05 d4 13 00 00 	lea    0x13d4(%rip),%rax        # d06c <_IO_stdin_used+0x6c>
    bc98:	4d 85 f6             	test   %r14,%r14
    bc9b:	4c 0f 44 f0          	cmove  %rax,%r14
    bc9f:	49 83 fc f6          	cmp    $0xfffffffffffffff6,%r12
    bca3:	0f 87 0f 09 00 00    	ja     c5b8 <fwp_main_thread+0x18d8>
    bca9:	49 8d 7c 24 09       	lea    0x9(%r12),%rdi
    bcae:	be 01 00 00 00       	mov    $0x1,%esi
    bcb3:	e8 58 a2 ff ff       	call   5f10 <fwp_heap_alloc>
    bcb8:	4c 89 e2             	mov    %r12,%rdx
    bcbb:	4c 89 f6             	mov    %r14,%rsi
    bcbe:	4c 89 20             	mov    %r12,(%rax)
    bcc1:	4c 8d 78 08          	lea    0x8(%rax),%r15
    bcc5:	48 89 c3             	mov    %rax,%rbx
    bcc8:	4c 89 ff             	mov    %r15,%rdi
    bccb:	e8 b0 78 ff ff       	call   3580 <memcpy@plt>
    bcd0:	42 c6 44 23 08 00    	movb   $0x0,0x8(%rbx,%r12,1)
    bcd6:	48 8b bd f0 fe ff ff 	mov    -0x110(%rbp),%rdi
    bcdd:	e8 ce 76 ff ff       	call   33b0 <free@plt>
    bce2:	48 8d 35 57 db 05 00 	lea    0x5db57(%rip),%rsi        # 69840 <fwp_heap>
    bce9:	48 89 d8             	mov    %rbx,%rax
    bcec:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    bcf3:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    bcfa:	48 89 95 c0 fe ff ff 	mov    %rdx,-0x140(%rbp)
    bd01:	48 c1 e2 10          	shl    $0x10,%rdx
    bd05:	48 39 d0             	cmp    %rdx,%rax
    bd08:	73 57                	jae    bd61 <fwp_main_thread+0x1081>
    bd0a:	48 89 c2             	mov    %rax,%rdx
    bd0d:	48 c1 ea 10          	shr    $0x10,%rdx
    bd11:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bd15:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    bd1c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bd20:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    bd24:	4d 85 f6             	test   %r14,%r14
    bd27:	74 38                	je     bd61 <fwp_main_thread+0x1081>
    bd29:	0f b6 0a             	movzbl (%rdx),%ecx
    bd2c:	80 f9 02             	cmp    $0x2,%cl
    bd2f:	0f 84 26 07 00 00    	je     c45b <fwp_main_thread+0x177b>
    bd35:	80 f9 01             	cmp    $0x1,%cl
    bd38:	75 27                	jne    bd61 <fwp_main_thread+0x1081>
    bd3a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bd3d:	0f b7 c0             	movzwl %ax,%eax
    bd40:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bd43:	48 0f af c1          	imul   %rcx,%rax
    bd47:	48 c1 e8 20          	shr    $0x20,%rax
    bd4b:	48 39 d0             	cmp    %rdx,%rax
    bd4e:	73 11                	jae    bd61 <fwp_main_thread+0x1081>
    bd50:	49 01 c6             	add    %rax,%r14
    bd53:	41 80 3e ff          	cmpb   $0xff,(%r14)
    bd57:	0f 84 be 07 00 00    	je     c51b <fwp_main_thread+0x183b>
    bd5d:	41 c6 06 01          	movb   $0x1,(%r14)
    bd61:	48 8b bd c8 fe ff ff 	mov    -0x138(%rbp),%rdi
    bd68:	e8 73 b0 ff ff       	call   6de0 <fwp_drop0>
    bd6d:	48 8b 13             	mov    (%rbx),%rdx
    bd70:	be 01 00 00 00       	mov    $0x1,%esi
    bd75:	4c 89 ff             	mov    %r15,%rdi
    bd78:	48 8b 0d 21 f7 05 00 	mov    0x5f721(%rip),%rcx        # 6b4a0 <fwp_prog_out>
    bd7f:	e8 dc 78 ff ff       	call   3660 <fwrite@plt>
    bd84:	48 8b 35 15 f7 05 00 	mov    0x5f715(%rip),%rsi        # 6b4a0 <fwp_prog_out>
    bd8b:	bf 0a 00 00 00       	mov    $0xa,%edi
    bd90:	e8 3b 77 ff ff       	call   34d0 <fputc@plt>
    bd95:	48 8d 35 a4 da 05 00 	lea    0x5daa4(%rip),%rsi        # 69840 <fwp_heap>
    bd9c:	48 89 d8             	mov    %rbx,%rax
    bd9f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    bda6:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    bdad:	48 89 95 c8 fe ff ff 	mov    %rdx,-0x138(%rbp)
    bdb4:	48 c1 e2 10          	shl    $0x10,%rdx
    bdb8:	48 39 d0             	cmp    %rdx,%rax
    bdbb:	73 69                	jae    be26 <fwp_main_thread+0x1146>
    bdbd:	48 89 c2             	mov    %rax,%rdx
    bdc0:	48 c1 ea 10          	shr    $0x10,%rdx
    bdc4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bdc8:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    bdcf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bdd3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bdd7:	4d 85 e4             	test   %r12,%r12
    bdda:	74 4a                	je     be26 <fwp_main_thread+0x1146>
    bddc:	0f b6 0a             	movzbl (%rdx),%ecx
    bddf:	80 f9 02             	cmp    $0x2,%cl
    bde2:	0f 84 8e 06 00 00    	je     c476 <fwp_main_thread+0x1796>
    bde8:	80 f9 01             	cmp    $0x1,%cl
    bdeb:	75 39                	jne    be26 <fwp_main_thread+0x1146>
    bded:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bdf0:	0f b7 c0             	movzwl %ax,%eax
    bdf3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bdf6:	48 0f af c1          	imul   %rcx,%rax
    bdfa:	48 c1 e8 20          	shr    $0x20,%rax
    bdfe:	48 39 d0             	cmp    %rdx,%rax
    be01:	73 23                	jae    be26 <fwp_main_thread+0x1146>
    be03:	49 01 c4             	add    %rax,%r12
    be06:	41 0f b6 04 24       	movzbl (%r12),%eax
    be0b:	84 c0                	test   %al,%al
    be0d:	74 17                	je     be26 <fwp_main_thread+0x1146>
    be0f:	3c 01                	cmp    $0x1,%al
    be11:	0f 84 37 06 00 00    	je     c44e <fwp_main_thread+0x176e>
    be17:	3c ff                	cmp    $0xff,%al
    be19:	0f 84 89 06 00 00    	je     c4a8 <fwp_main_thread+0x17c8>
    be1f:	83 e8 01             	sub    $0x1,%eax
    be22:	41 88 04 24          	mov    %al,(%r12)
    be26:	48 8b 85 80 fe ff ff 	mov    -0x180(%rbp),%rax
    be2d:	48 8b 40 10          	mov    0x10(%rax),%rax
    be31:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
    be38:	48 85 c0             	test   %rax,%rax
    be3b:	0f 84 8f 07 00 00    	je     c5d0 <fwp_main_thread+0x18f0>
    be41:	48 8d 05 f8 d9 05 00 	lea    0x5d9f8(%rip),%rax        # 69840 <fwp_heap>
    be48:	48 8b 88 b0 13 00 00 	mov    0x13b0(%rax),%rcx
    be4f:	48 8b 90 d8 13 00 00 	mov    0x13d8(%rax),%rdx
    be56:	e9 e6 f8 ff ff       	jmp    b741 <fwp_main_thread+0xa61>
    be5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    be60:	44 8b 1d a1 f6 05 00 	mov    0x5f6a1(%rip),%r11d        # 6b508 <iteration_active>
    be67:	41 8d 76 01          	lea    0x1(%r14),%esi
    be6b:	8b 05 73 ed 05 00    	mov    0x5ed73(%rip),%eax        # 6abe4 <fwp_heap+0x13a4>
    be71:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    be78:	00 
    be79:	45 85 db             	test   %r11d,%r11d
    be7c:	0f 84 e6 03 00 00    	je     c268 <fwp_main_thread+0x1588>
    be82:	48 83 05 76 f6 05 00 	addq   $0x1,0x5f676(%rip)        # 6b500 <iteration_requests>
    be89:	01 
    be8a:	48 01 3d 67 f6 05 00 	add    %rdi,0x5f667(%rip)        # 6b4f8 <iteration_bytes>
    be91:	85 c0                	test   %eax,%eax
    be93:	0f 84 ea 04 00 00    	je     c383 <fwp_main_thread+0x16a3>
    be99:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    bea0:	0f 87 dd 04 00 00    	ja     c383 <fwp_main_thread+0x16a3>
    bea6:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    beaa:	48 8d 1d 8f d9 05 00 	lea    0x5d98f(%rip),%rbx        # 69840 <fwp_heap>
    beb1:	48 c1 e8 04          	shr    $0x4,%rax
    beb5:	0f b6 94 03 a0 0f 00 	movzbl 0xfa0(%rbx,%rax,1),%edx
    bebc:	00 
    bebd:	8b 84 93 00 0f 00 00 	mov    0xf00(%rbx,%rdx,4),%eax
    bec4:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    bec8:	48 8d 14 d3          	lea    (%rbx,%rdx,8),%rdx
    becc:	4c 8b 3a             	mov    (%rdx),%r15
    becf:	4d 85 ff             	test   %r15,%r15
    bed2:	0f 84 f5 03 00 00    	je     c2cd <fwp_main_thread+0x15ed>
    bed8:	4d 8b 17             	mov    (%r15),%r10
    bedb:	49 f7 d2             	not    %r10
    bede:	4c 89 12             	mov    %r10,(%rdx)
    bee1:	48 39 c7             	cmp    %rax,%rdi
    bee4:	73 54                	jae    bf3a <fwp_main_thread+0x125a>
    bee6:	48 89 fa             	mov    %rdi,%rdx
    bee9:	48 83 c7 08          	add    $0x8,%rdi
    beed:	49 c7 04 f7 00 00 00 	movq   $0x0,(%r15,%rsi,8)
    bef4:	00 
    bef5:	48 f7 d2             	not    %rdx
    bef8:	48 01 c2             	add    %rax,%rdx
    befb:	48 c1 ea 03          	shr    $0x3,%rdx
    beff:	48 39 c7             	cmp    %rax,%rdi
    bf02:	73 36                	jae    bf3a <fwp_main_thread+0x125a>
    bf04:	83 e2 01             	and    $0x1,%edx
    bf07:	74 17                	je     bf20 <fwp_main_thread+0x1240>
    bf09:	49 c7 04 3f 00 00 00 	movq   $0x0,(%r15,%rdi,1)
    bf10:	00 
    bf11:	48 83 c7 08          	add    $0x8,%rdi
    bf15:	48 39 c7             	cmp    %rax,%rdi
    bf18:	73 20                	jae    bf3a <fwp_main_thread+0x125a>
    bf1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bf20:	49 c7 04 3f 00 00 00 	movq   $0x0,(%r15,%rdi,1)
    bf27:	00 
    bf28:	49 c7 44 3f 08 00 00 	movq   $0x0,0x8(%r15,%rdi,1)
    bf2f:	00 00 
    bf31:	48 83 c7 10          	add    $0x10,%rdi
    bf35:	48 39 c7             	cmp    %rax,%rdi
    bf38:	72 e6                	jb     bf20 <fwp_main_thread+0x1240>
    bf3a:	48 8d 35 ff d8 05 00 	lea    0x5d8ff(%rip),%rsi        # 69840 <fwp_heap>
    bf41:	48 89 c2             	mov    %rax,%rdx
    bf44:	48 03 96 20 14 00 00 	add    0x1420(%rsi),%rdx
    bf4b:	0f 82 17 06 00 00    	jb     c568 <fwp_main_thread+0x1888>
    bf51:	48 89 96 20 14 00 00 	mov    %rdx,0x1420(%rsi)
    bf58:	48 39 96 28 14 00 00 	cmp    %rdx,0x1428(%rsi)
    bf5f:	73 07                	jae    bf68 <fwp_main_thread+0x1288>
    bf61:	48 89 15 00 ed 05 00 	mov    %rdx,0x5ed00(%rip)        # 6ac68 <fwp_heap+0x1428>
    bf68:	66 0f ef c0          	pxor   %xmm0,%xmm0
    bf6c:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    bf71:	f2 0f 58 05 ff ec 05 	addsd  0x5ecff(%rip),%xmm0        # 6ac78 <fwp_heap+0x1438>
    bf78:	00 
    bf79:	f2 0f 11 05 f7 ec 05 	movsd  %xmm0,0x5ecf7(%rip)        # 6ac78 <fwp_heap+0x1438>
    bf80:	00 
    bf81:	45 85 db             	test   %r11d,%r11d
    bf84:	74 33                	je     bfb9 <fwp_main_thread+0x12d9>
    bf86:	48 8b 05 d3 ec 05 00 	mov    0x5ecd3(%rip),%rax        # 6ac60 <fwp_heap+0x1420>
    bf8d:	48 85 c0             	test   %rax,%rax
    bf90:	0f 88 88 03 00 00    	js     c31e <fwp_main_thread+0x163e>
    bf96:	66 0f ef c0          	pxor   %xmm0,%xmm0
    bf9a:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    bf9f:	f2 0f 5c 05 41 f5 05 	subsd  0x5f541(%rip),%xmm0        # 6b4e8 <iteration_start_charge>
    bfa6:	00 
    bfa7:	66 0f 2f 05 31 f5 05 	comisd 0x5f531(%rip),%xmm0        # 6b4e0 <iteration_peak>
    bfae:	00 
    bfaf:	76 08                	jbe    bfb9 <fwp_main_thread+0x12d9>
    bfb1:	f2 0f 11 05 27 f5 05 	movsd  %xmm0,0x5f527(%rip)        # 6b4e0 <iteration_peak>
    bfb8:	00 
    bfb9:	66 41 0f 6e 01       	movd   (%r9),%xmm0
    bfbe:	66 41 0f 6e d6       	movd   %r14d,%xmm2
    bfc3:	66 0f 62 c2          	punpckldq %xmm2,%xmm0
    bfc7:	66 41 0f d6 07       	movq   %xmm0,(%r15)
    bfcc:	45 85 c0             	test   %r8d,%r8d
    bfcf:	74 3e                	je     c00f <fwp_main_thread+0x132f>
    bfd1:	44 89 c2             	mov    %r8d,%edx
    bfd4:	49 8d 71 08          	lea    0x8(%r9),%rsi
    bfd8:	49 8d 7f 08          	lea    0x8(%r15),%rdi
    bfdc:	48 89 8d b0 fe ff ff 	mov    %rcx,-0x150(%rbp)
    bfe3:	48 c1 e2 03          	shl    $0x3,%rdx
    bfe7:	44 89 85 b8 fe ff ff 	mov    %r8d,-0x148(%rbp)
    bfee:	4c 89 8d c0 fe ff ff 	mov    %r9,-0x140(%rbp)
    bff5:	e8 f6 75 ff ff       	call   35f0 <memmove@plt>
    bffa:	4c 8b 8d c0 fe ff ff 	mov    -0x140(%rbp),%r9
    c001:	44 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8d
    c008:	48 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%rcx
    c00f:	45 85 ed             	test   %r13d,%r13d
    c012:	74 25                	je     c039 <fwp_main_thread+0x1359>
    c014:	45 89 ed             	mov    %r13d,%r13d
    c017:	4b 8d 34 ec          	lea    (%r12,%r13,8),%rsi
    c01b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    c020:	49 8b 14 24          	mov    (%r12),%rdx
    c024:	44 89 c0             	mov    %r8d,%eax
    c027:	49 83 c4 08          	add    $0x8,%r12
    c02b:	41 83 c0 01          	add    $0x1,%r8d
    c02f:	49 89 54 c7 08       	mov    %rdx,0x8(%r15,%rax,8)
    c034:	4c 39 e6             	cmp    %r12,%rsi
    c037:	75 e7                	jne    c020 <fwp_main_thread+0x1340>
    c039:	48 8d 15 00 d8 05 00 	lea    0x5d800(%rip),%rdx        # 69840 <fwp_heap>
    c040:	48 8b 85 c8 fe ff ff 	mov    -0x138(%rbp),%rax
    c047:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    c04e:	48 8b 92 d8 13 00 00 	mov    0x13d8(%rdx),%rdx
    c055:	48 89 95 c0 fe ff ff 	mov    %rdx,-0x140(%rbp)
    c05c:	48 c1 e2 10          	shl    $0x10,%rdx
    c060:	48 39 d0             	cmp    %rdx,%rax
    c063:	73 54                	jae    c0b9 <fwp_main_thread+0x13d9>
    c065:	48 89 c2             	mov    %rax,%rdx
    c068:	48 c1 ea 10          	shr    $0x10,%rdx
    c06c:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    c070:	48 8b 15 c1 eb 05 00 	mov    0x5ebc1(%rip),%rdx        # 6ac38 <fwp_heap+0x13f8>
    c077:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    c07b:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    c07f:	48 85 f6             	test   %rsi,%rsi
    c082:	74 35                	je     c0b9 <fwp_main_thread+0x13d9>
    c084:	0f b6 3a             	movzbl (%rdx),%edi
    c087:	40 80 ff 02          	cmp    $0x2,%dil
    c08b:	0f 84 7f 02 00 00    	je     c310 <fwp_main_thread+0x1630>
    c091:	40 80 ff 01          	cmp    $0x1,%dil
    c095:	75 22                	jne    c0b9 <fwp_main_thread+0x13d9>
    c097:	8b 7a 18             	mov    0x18(%rdx),%edi
    c09a:	0f b7 c0             	movzwl %ax,%eax
    c09d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c0a0:	48 0f af c7          	imul   %rdi,%rax
    c0a4:	48 c1 e8 20          	shr    $0x20,%rax
    c0a8:	48 39 d0             	cmp    %rdx,%rax
    c0ab:	73 0c                	jae    c0b9 <fwp_main_thread+0x13d9>
    c0ad:	48 01 c6             	add    %rax,%rsi
    c0b0:	80 3e 01             	cmpb   $0x1,(%rsi)
    c0b3:	0f 84 f9 01 00 00    	je     c2b2 <fwp_main_thread+0x15d2>
    c0b9:	48 8b 41 18          	mov    0x18(%rcx),%rax
    c0bd:	48 8b bd c8 fe ff ff 	mov    -0x138(%rbp),%rdi
    c0c4:	be 01 00 00 00       	mov    $0x1,%esi
    c0c9:	ff 50 08             	call   *0x8(%rax)
    c0cc:	48 8d 3d 6d d7 05 00 	lea    0x5d76d(%rip),%rdi        # 69840 <fwp_heap>
    c0d3:	4c 89 f8             	mov    %r15,%rax
    c0d6:	48 8b 97 d8 13 00 00 	mov    0x13d8(%rdi),%rdx
    c0dd:	48 2b 87 b0 13 00 00 	sub    0x13b0(%rdi),%rax
    c0e4:	48 89 95 c0 fe ff ff 	mov    %rdx,-0x140(%rbp)
    c0eb:	48 c1 e2 10          	shl    $0x10,%rdx
    c0ef:	48 39 d0             	cmp    %rdx,%rax
    c0f2:	73 59                	jae    c14d <fwp_main_thread+0x146d>
    c0f4:	48 89 c2             	mov    %rax,%rdx
    c0f7:	48 c1 ea 10          	shr    $0x10,%rdx
    c0fb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c0ff:	48 8b 97 f8 13 00 00 	mov    0x13f8(%rdi),%rdx
    c106:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c10a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c10e:	4d 85 e4             	test   %r12,%r12
    c111:	74 3a                	je     c14d <fwp_main_thread+0x146d>
    c113:	0f b6 0a             	movzbl (%rdx),%ecx
    c116:	80 f9 02             	cmp    $0x2,%cl
    c119:	0f 84 d0 01 00 00    	je     c2ef <fwp_main_thread+0x160f>
    c11f:	80 f9 01             	cmp    $0x1,%cl
    c122:	75 29                	jne    c14d <fwp_main_thread+0x146d>
    c124:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c127:	0f b7 c0             	movzwl %ax,%eax
    c12a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c12d:	48 0f af c1          	imul   %rcx,%rax
    c131:	48 c1 e8 20          	shr    $0x20,%rax
    c135:	48 39 d0             	cmp    %rdx,%rax
    c138:	73 13                	jae    c14d <fwp_main_thread+0x146d>
    c13a:	49 01 c4             	add    %rax,%r12
    c13d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c142:	0f 84 bb 01 00 00    	je     c303 <fwp_main_thread+0x1623>
    c148:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c14d:	48 8b bd c8 fe ff ff 	mov    -0x138(%rbp),%rdi
    c154:	e8 77 af ff ff       	call   70d0 <fwp_closure_drop>
    c159:	4c 89 bd c8 fe ff ff 	mov    %r15,-0x138(%rbp)
    c160:	8b 95 a4 fe ff ff    	mov    -0x15c(%rbp),%edx
    c166:	39 95 9c fe ff ff    	cmp    %edx,-0x164(%rbp)
    c16c:	0f 82 36 fa ff ff    	jb     bba8 <fwp_main_thread+0xec8>
    c172:	4c 8b ad 90 fe ff ff 	mov    -0x170(%rbp),%r13
    c179:	e9 d4 fa ff ff       	jmp    bc52 <fwp_main_thread+0xf72>
    c17e:	66 90                	xchg   %ax,%ax
    c180:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
    c187:	e9 0a fa ff ff       	jmp    bb96 <fwp_main_thread+0xeb6>
    c18c:	0f 1f 40 00          	nopl   0x0(%rax)
    c190:	41 8b 34 24          	mov    (%r12),%esi
    c194:	8b 05 82 4e 00 00    	mov    0x4e82(%rip),%eax        # 1101c <fc12+0x4>
    c19a:	89 f7                	mov    %esi,%edi
    c19c:	29 c7                	sub    %eax,%edi
    c19e:	83 ff 01             	cmp    $0x1,%edi
    c1a1:	0f 85 5b f6 ff ff    	jne    b802 <fwp_main_thread+0xb22>
    c1a7:	48 89 e3             	mov    %rsp,%rbx
    c1aa:	85 c0                	test   %eax,%eax
    c1ac:	0f 84 43 02 00 00    	je     c3f5 <fwp_main_thread+0x1715>
    c1b2:	89 f1                	mov    %esi,%ecx
    c1b4:	ba 08 00 00 00       	mov    $0x8,%edx
    c1b9:	48 c1 e1 03          	shl    $0x3,%rcx
    c1bd:	85 f6                	test   %esi,%esi
    c1bf:	48 89 e6             	mov    %rsp,%rsi
    c1c2:	48 0f 45 d1          	cmovne %rcx,%rdx
    c1c6:	49 89 d7             	mov    %rdx,%r15
    c1c9:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    c1cd:	48 c1 ea 04          	shr    $0x4,%rdx
    c1d1:	48 c1 e2 04          	shl    $0x4,%rdx
    c1d5:	48 89 d7             	mov    %rdx,%rdi
    c1d8:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    c1df:	48 29 fe             	sub    %rdi,%rsi
    c1e2:	48 39 f4             	cmp    %rsi,%rsp
    c1e5:	74 15                	je     c1fc <fwp_main_thread+0x151c>
    c1e7:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    c1ee:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    c1f5:	00 00 
    c1f7:	48 39 f4             	cmp    %rsi,%rsp
    c1fa:	75 eb                	jne    c1e7 <fwp_main_thread+0x1507>
    c1fc:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    c202:	48 29 d4             	sub    %rdx,%rsp
    c205:	48 85 d2             	test   %rdx,%rdx
    c208:	74 06                	je     c210 <fwp_main_thread+0x1530>
    c20a:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    c210:	4c 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%r14
    c217:	00 
    c218:	4c 89 f9             	mov    %r15,%rcx
    c21b:	48 8d 35 fe 4d 00 00 	lea    0x4dfe(%rip),%rsi        # 11020 <fwp_epfd>
    c222:	48 89 e7             	mov    %rsp,%rdi
    c225:	4c 89 f2             	mov    %r14,%rdx
    c228:	e8 23 73 ff ff       	call   3550 <__memcpy_chk@plt>
    c22d:	4d 39 f7             	cmp    %r14,%r15
    c230:	4c 89 f9             	mov    %r15,%rcx
    c233:	4a 8d 3c 34          	lea    (%rsp,%r14,1),%rdi
    c237:	49 0f 42 ce          	cmovb  %r14,%rcx
    c23b:	ba 08 00 00 00       	mov    $0x8,%edx
    c240:	4c 89 ee             	mov    %r13,%rsi
    c243:	4c 29 f1             	sub    %r14,%rcx
    c246:	e8 05 73 ff ff       	call   3550 <__memcpy_chk@plt>
    c24b:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    c250:	48 89 e7             	mov    %rsp,%rdi
    c253:	ff 10                	call   *(%rax)
    c255:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
    c25c:	e9 a0 01 00 00       	jmp    c401 <fwp_main_thread+0x1721>
    c261:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    c268:	85 c0                	test   %eax,%eax
    c26a:	74 0d                	je     c279 <fwp_main_thread+0x1599>
    c26c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    c273:	0f 86 2d fc ff ff    	jbe    bea6 <fwp_main_thread+0x11c6>
    c279:	31 f6                	xor    %esi,%esi
    c27b:	44 89 85 b0 fe ff ff 	mov    %r8d,-0x150(%rbp)
    c282:	4c 89 8d b8 fe ff ff 	mov    %r9,-0x148(%rbp)
    c289:	48 89 8d c0 fe ff ff 	mov    %rcx,-0x140(%rbp)
    c290:	e8 7b 9c ff ff       	call   5f10 <fwp_heap_alloc>
    c295:	48 8b 8d c0 fe ff ff 	mov    -0x140(%rbp),%rcx
    c29c:	4c 8b 8d b8 fe ff ff 	mov    -0x148(%rbp),%r9
    c2a3:	44 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%r8d
    c2aa:	49 89 c7             	mov    %rax,%r15
    c2ad:	e9 07 fd ff ff       	jmp    bfb9 <fwp_main_thread+0x12d9>
    c2b2:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    c2b9:	00 
    c2ba:	e9 0d fe ff ff       	jmp    c0cc <fwp_main_thread+0x13ec>
    c2bf:	66 85 c0             	test   %ax,%ax
    c2c2:	0f 85 da f5 ff ff    	jne    b8a2 <fwp_main_thread+0xbc2>
    c2c8:	e9 af f5 ff ff       	jmp    b87c <fwp_main_thread+0xb9c>
    c2cd:	4c 8b 7a 08          	mov    0x8(%rdx),%r15
    c2d1:	4d 85 ff             	test   %r15,%r15
    c2d4:	74 66                	je     c33c <fwp_main_thread+0x165c>
    c2d6:	4c 8b 52 10          	mov    0x10(%rdx),%r10
    c2da:	4d 29 fa             	sub    %r15,%r10
    c2dd:	49 39 c2             	cmp    %rax,%r10
    c2e0:	72 5a                	jb     c33c <fwp_main_thread+0x165c>
    c2e2:	4d 8d 14 07          	lea    (%r15,%rax,1),%r10
    c2e6:	4c 89 52 08          	mov    %r10,0x8(%rdx)
    c2ea:	e9 f2 fb ff ff       	jmp    bee1 <fwp_main_thread+0x1201>
    c2ef:	66 85 c0             	test   %ax,%ax
    c2f2:	0f 85 55 fe ff ff    	jne    c14d <fwp_main_thread+0x146d>
    c2f8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c2fd:	0f 85 45 fe ff ff    	jne    c148 <fwp_main_thread+0x1468>
    c303:	4c 89 e7             	mov    %r12,%rdi
    c306:	e8 c5 94 ff ff       	call   57d0 <fwp_rc_forget_slot>
    c30b:	e9 38 fe ff ff       	jmp    c148 <fwp_main_thread+0x1468>
    c310:	66 85 c0             	test   %ax,%ax
    c313:	0f 85 a0 fd ff ff    	jne    c0b9 <fwp_main_thread+0x13d9>
    c319:	e9 92 fd ff ff       	jmp    c0b0 <fwp_main_thread+0x13d0>
    c31e:	48 89 c2             	mov    %rax,%rdx
    c321:	83 e0 01             	and    $0x1,%eax
    c324:	66 0f ef c0          	pxor   %xmm0,%xmm0
    c328:	48 d1 ea             	shr    $1,%rdx
    c32b:	48 09 c2             	or     %rax,%rdx
    c32e:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    c333:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    c337:	e9 63 fc ff ff       	jmp    bf9f <fwp_main_thread+0x12bf>
    c33c:	31 f6                	xor    %esi,%esi
    c33e:	44 89 9d 98 fe ff ff 	mov    %r11d,-0x168(%rbp)
    c345:	44 89 85 b0 fe ff ff 	mov    %r8d,-0x150(%rbp)
    c34c:	4c 89 8d b8 fe ff ff 	mov    %r9,-0x148(%rbp)
    c353:	48 89 8d c0 fe ff ff 	mov    %rcx,-0x140(%rbp)
    c35a:	e8 b1 9b ff ff       	call   5f10 <fwp_heap_alloc>
    c35f:	44 8b 9d 98 fe ff ff 	mov    -0x168(%rbp),%r11d
    c366:	44 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%r8d
    c36d:	4c 8b 8d b8 fe ff ff 	mov    -0x148(%rbp),%r9
    c374:	48 8b 8d c0 fe ff ff 	mov    -0x140(%rbp),%rcx
    c37b:	49 89 c7             	mov    %rax,%r15
    c37e:	e9 fe fb ff ff       	jmp    bf81 <fwp_main_thread+0x12a1>
    c383:	31 f6                	xor    %esi,%esi
    c385:	44 89 85 b0 fe ff ff 	mov    %r8d,-0x150(%rbp)
    c38c:	4c 89 8d b8 fe ff ff 	mov    %r9,-0x148(%rbp)
    c393:	48 89 8d c0 fe ff ff 	mov    %rcx,-0x140(%rbp)
    c39a:	e8 71 9b ff ff       	call   5f10 <fwp_heap_alloc>
    c39f:	48 8b 8d c0 fe ff ff 	mov    -0x140(%rbp),%rcx
    c3a6:	4c 8b 8d b8 fe ff ff 	mov    -0x148(%rbp),%r9
    c3ad:	44 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%r8d
    c3b4:	49 89 c7             	mov    %rax,%r15
    c3b7:	e9 ca fb ff ff       	jmp    bf86 <fwp_main_thread+0x12a6>
    c3bc:	e8 ef 92 ff ff       	call   56b0 <fwp_rc_wide_dup>
    c3c1:	48 8b 15 d0 f0 05 00 	mov    0x5f0d0(%rip),%rdx        # 6b498 <fwp_fns>
    c3c8:	e9 d5 f4 ff ff       	jmp    b8a2 <fwp_main_thread+0xbc2>
    c3cd:	48 89 c2             	mov    %rax,%rdx
    c3d0:	83 e0 01             	and    $0x1,%eax
    c3d3:	66 0f ef c9          	pxor   %xmm1,%xmm1
    c3d7:	48 d1 ea             	shr    $1,%rdx
    c3da:	48 09 c2             	or     %rax,%rdx
    c3dd:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    c3e2:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    c3e6:	e9 7d ef ff ff       	jmp    b368 <fwp_main_thread+0x688>
    c3eb:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    c3f0:	e9 01 eb ff ff       	jmp    aef6 <fwp_main_thread+0x216>
    c3f5:	4c 89 ef             	mov    %r13,%rdi
    c3f8:	ff 11                	call   *(%rcx)
    c3fa:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
    c401:	48 89 dc             	mov    %rbx,%rsp
    c404:	e9 49 f8 ff ff       	jmp    bc52 <fwp_main_thread+0xf72>
    c409:	66 85 c0             	test   %ax,%ax
    c40c:	0f 85 b1 f3 ff ff    	jne    b7c3 <fwp_main_thread+0xae3>
    c412:	e9 86 f3 ff ff       	jmp    b79d <fwp_main_thread+0xabd>
    c417:	66 85 c0             	test   %ax,%ax
    c41a:	0f 85 13 f3 ff ff    	jne    b733 <fwp_main_thread+0xa53>
    c420:	e9 f4 f2 ff ff       	jmp    b719 <fwp_main_thread+0xa39>
    c425:	66 85 c0             	test   %ax,%ax
    c428:	0f 85 bb f1 ff ff    	jne    b5e9 <fwp_main_thread+0x909>
    c42e:	e9 aa f1 ff ff       	jmp    b5dd <fwp_main_thread+0x8fd>
    c433:	66 85 c0             	test   %ax,%ax
    c436:	0f 85 45 f2 ff ff    	jne    b681 <fwp_main_thread+0x9a1>
    c43c:	e9 34 f2 ff ff       	jmp    b675 <fwp_main_thread+0x995>
    c441:	4c 89 f7             	mov    %r14,%rdi
    c444:	e8 87 93 ff ff       	call   57d0 <fwp_rc_forget_slot>
    c449:	e9 5e f0 ff ff       	jmp    b4ac <fwp_main_thread+0x7cc>
    c44e:	48 89 df             	mov    %rbx,%rdi
    c451:	e8 5a a6 ff ff       	call   6ab0 <fwp_rc_free_arr>
    c456:	e9 cb f9 ff ff       	jmp    be26 <fwp_main_thread+0x1146>
    c45b:	66 85 c0             	test   %ax,%ax
    c45e:	0f 85 fd f8 ff ff    	jne    bd61 <fwp_main_thread+0x1081>
    c464:	e9 ea f8 ff ff       	jmp    bd53 <fwp_main_thread+0x1073>
    c469:	48 89 df             	mov    %rbx,%rdi
    c46c:	e8 5f 93 ff ff       	call   57d0 <fwp_rc_forget_slot>
    c471:	e9 70 f1 ff ff       	jmp    b5e6 <fwp_main_thread+0x906>
    c476:	66 85 c0             	test   %ax,%ax
    c479:	0f 85 a7 f9 ff ff    	jne    be26 <fwp_main_thread+0x1146>
    c47f:	e9 82 f9 ff ff       	jmp    be06 <fwp_main_thread+0x1126>
    c484:	48 83 3d 8c d3 05 00 	cmpq   $0x0,0x5d38c(%rip)        # 69818 <fwp_root>
    c48b:	00 
    c48c:	c7 05 0a 4c 01 00 00 	movl   $0x0,0x14c0a(%rip)        # 210a0 <fwp_exit_code>
    c493:	00 00 00 
    c496:	0f 84 3a ed ff ff    	je     b1d6 <fwp_main_thread+0x4f6>
    c49c:	e9 af 72 ff ff       	jmp    3750 <fwp_main_thread.cold>
    c4a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    c4a8:	4c 89 e0             	mov    %r12,%rax
    c4ab:	48 8d 35 8e d3 05 00 	lea    0x5d38e(%rip),%rsi        # 69840 <fwp_heap>
    c4b2:	48 c1 e8 11          	shr    $0x11,%rax
    c4b6:	4c 31 e0             	xor    %r12,%rax
    c4b9:	48 89 c2             	mov    %rax,%rdx
    c4bc:	48 c1 ea 09          	shr    $0x9,%rdx
    c4c0:	48 31 d0             	xor    %rdx,%rax
    c4c3:	0f b6 c0             	movzbl %al,%eax
    c4c6:	48 8b 94 c6 48 14 00 	mov    0x1448(%rsi,%rax,8),%rdx
    c4cd:	00 
    c4ce:	48 85 d2             	test   %rdx,%rdx
    c4d1:	75 16                	jne    c4e9 <fwp_main_thread+0x1809>
    c4d3:	eb 53                	jmp    c528 <fwp_main_thread+0x1848>
    c4d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    c4dc:	00 00 00 00 
    c4e0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    c4e4:	48 85 d2             	test   %rdx,%rdx
    c4e7:	74 3f                	je     c528 <fwp_main_thread+0x1848>
    c4e9:	48 89 d0             	mov    %rdx,%rax
    c4ec:	4c 3b 22             	cmp    (%rdx),%r12
    c4ef:	75 ef                	jne    c4e0 <fwp_main_thread+0x1800>
    c4f1:	48 8b 42 08          	mov    0x8(%rdx),%rax
    c4f5:	48 83 e8 01          	sub    $0x1,%rax
    c4f9:	48 89 42 08          	mov    %rax,0x8(%rdx)
    c4fd:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    c503:	0f 85 1d f9 ff ff    	jne    be26 <fwp_main_thread+0x1146>
    c509:	4c 89 e7             	mov    %r12,%rdi
    c50c:	e8 bf 92 ff ff       	call   57d0 <fwp_rc_forget_slot>
    c511:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    c516:	e9 0b f9 ff ff       	jmp    be26 <fwp_main_thread+0x1146>
    c51b:	4c 89 f7             	mov    %r14,%rdi
    c51e:	e8 ad 92 ff ff       	call   57d0 <fwp_rc_forget_slot>
    c523:	e9 35 f8 ff ff       	jmp    bd5d <fwp_main_thread+0x107d>
    c528:	48 8d 3d b1 14 00 00 	lea    0x14b1(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    c52f:	e8 1c 7f ff ff       	call   4450 <fwp_trap>
    c534:	0f 1f 40 00          	nopl   0x0(%rax)
    c538:	48 89 df             	mov    %rbx,%rdi
    c53b:	e8 90 92 ff ff       	call   57d0 <fwp_rc_forget_slot>
    c540:	e9 39 f1 ff ff       	jmp    b67e <fwp_main_thread+0x99e>
    c545:	48 89 df             	mov    %rbx,%rdi
    c548:	e8 83 92 ff ff       	call   57d0 <fwp_rc_forget_slot>
    c54d:	e9 d0 f1 ff ff       	jmp    b722 <fwp_main_thread+0xa42>
    c552:	e8 59 91 ff ff       	call   56b0 <fwp_rc_wide_dup>
    c557:	e9 67 f2 ff ff       	jmp    b7c3 <fwp_main_thread+0xae3>
    c55c:	48 8d 3d d5 15 00 00 	lea    0x15d5(%rip),%rdi        # db38 <_IO_stdin_used+0xb38>
    c563:	e8 e8 7e ff ff       	call   4450 <fwp_trap>
    c568:	e8 c3 78 ff ff       	call   3e30 <fwp_heap_oom>
    c56d:	48 8d 3d 4e 0d 00 00 	lea    0xd4e(%rip),%rdi        # d2c2 <_IO_stdin_used+0x2c2>
    c574:	e8 87 7a ff ff       	call   4000 <ad_raw_fail>
    c579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    c580:	48 89 c7             	mov    %rax,%rdi
    c583:	e8 a8 a4 ff ff       	call   6a30 <fwp_rc_share>
    c588:	48 8b bd 88 fe ff ff 	mov    -0x178(%rbp),%rdi
    c58f:	e8 9c a4 ff ff       	call   6a30 <fwp_rc_share>
    c594:	48 8d 05 7d 4a 00 00 	lea    0x4a7d(%rip),%rax        # 11018 <fc12>
    c59b:	4c 89 ad a8 fe ff ff 	mov    %r13,-0x158(%rbp)
    c5a2:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
    c5a9:	c7 85 a4 fe ff ff 01 	movl   $0x1,-0x15c(%rbp)
    c5b0:	00 00 00 
    c5b3:	e9 7a f6 ff ff       	jmp    bc32 <fwp_main_thread+0xf52>
    c5b8:	48 8d 3d 1e 0d 00 00 	lea    0xd1e(%rip),%rdi        # d2dd <_IO_stdin_used+0x2dd>
    c5bf:	e8 8c 7e ff ff       	call   4450 <fwp_trap>
    c5c4:	e8 87 6e ff ff       	call   3450 <__stack_chk_fail@plt>
    c5c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    c5d0:	4c 8b bd 78 fe ff ff 	mov    -0x188(%rbp),%r15
    c5d7:	48 8b bd 88 fe ff ff 	mov    -0x178(%rbp),%rdi
    c5de:	e8 fd a7 ff ff       	call   6de0 <fwp_drop0>
    c5e3:	4c 89 ff             	mov    %r15,%rdi
    c5e6:	e8 f5 a7 ff ff       	call   6de0 <fwp_drop0>
    c5eb:	48 c7 05 92 4a 00 00 	movq   $0x0,0x4a92(%rip)        # 11088 <v.2>
    c5f2:	00 00 00 00 
    c5f6:	c7 05 90 4a 00 00 01 	movl   $0x1,0x4a90(%rip)        # 11090 <st.3>
    c5fd:	00 00 00 
    c600:	e9 33 e8 ff ff       	jmp    ae38 <fwp_main_thread+0x158>
    c605:	e9 46 71 ff ff       	jmp    3750 <fwp_main_thread.cold>
    c60a:	e9 41 71 ff ff       	jmp    3750 <fwp_main_thread.cold>
    c60f:	90                   	nop

000000000000c610 <__divmodti4>:
    c610:	f3 0f 1e fa          	endbr64
    c614:	55                   	push   %rbp
    c615:	49 89 f1             	mov    %rsi,%r9
    c618:	49 89 d2             	mov    %rdx,%r10
    c61b:	48 89 fe             	mov    %rdi,%rsi
    c61e:	49 89 cb             	mov    %rcx,%r11
    c621:	48 89 e5             	mov    %rsp,%rbp
    c624:	41 57                	push   %r15
    c626:	41 56                	push   %r14
    c628:	41 55                	push   %r13
    c62a:	41 54                	push   %r12
    c62c:	53                   	push   %rbx
    c62d:	4c 89 c3             	mov    %r8,%rbx
    c630:	45 31 c0             	xor    %r8d,%r8d
    c633:	4d 85 c9             	test   %r9,%r9
    c636:	79 12                	jns    c64a <__divmodti4+0x3a>
    c638:	31 ff                	xor    %edi,%edi
    c63a:	48 f7 de             	neg    %rsi
    c63d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    c644:	4c 19 cf             	sbb    %r9,%rdi
    c647:	49 89 f9             	mov    %rdi,%r9
    c64a:	4c 89 d8             	mov    %r11,%rax
    c64d:	4d 85 db             	test   %r11,%r11
    c650:	0f 88 1a 01 00 00    	js     c770 <__divmodti4+0x160>
    c656:	4c 89 d9             	mov    %r11,%rcx
    c659:	49 89 f3             	mov    %rsi,%r11
    c65c:	75 62                	jne    c6c0 <__divmodti4+0xb0>
    c65e:	4d 89 c4             	mov    %r8,%r12
    c661:	4d 39 d1             	cmp    %r10,%r9
    c664:	0f 83 46 01 00 00    	jae    c7b0 <__divmodti4+0x1a0>
    c66a:	4c 89 d8             	mov    %r11,%rax
    c66d:	4c 89 ca             	mov    %r9,%rdx
    c670:	49 f7 f2             	div    %r10
    c673:	49 89 c3             	mov    %rax,%r11
    c676:	31 c0                	xor    %eax,%eax
    c678:	48 89 d6             	mov    %rdx,%rsi
    c67b:	31 ff                	xor    %edi,%edi
    c67d:	4c 89 d9             	mov    %r11,%rcx
    c680:	48 89 c2             	mov    %rax,%rdx
    c683:	48 89 c8             	mov    %rcx,%rax
    c686:	4d 85 e4             	test   %r12,%r12
    c689:	74 0a                	je     c695 <__divmodti4+0x85>
    c68b:	48 f7 d8             	neg    %rax
    c68e:	48 83 d2 00          	adc    $0x0,%rdx
    c692:	48 f7 da             	neg    %rdx
    c695:	4d 85 c0             	test   %r8,%r8
    c698:	74 0a                	je     c6a4 <__divmodti4+0x94>
    c69a:	48 f7 de             	neg    %rsi
    c69d:	48 83 d7 00          	adc    $0x0,%rdi
    c6a1:	48 f7 df             	neg    %rdi
    c6a4:	48 89 33             	mov    %rsi,(%rbx)
    c6a7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    c6ab:	5b                   	pop    %rbx
    c6ac:	41 5c                	pop    %r12
    c6ae:	41 5d                	pop    %r13
    c6b0:	41 5e                	pop    %r14
    c6b2:	41 5f                	pop    %r15
    c6b4:	5d                   	pop    %rbp
    c6b5:	c3                   	ret
    c6b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    c6bd:	00 00 00 
    c6c0:	4d 89 c4             	mov    %r8,%r12
    c6c3:	49 39 c1             	cmp    %rax,%r9
    c6c6:	0f 82 ce 00 00 00    	jb     c79a <__divmodti4+0x18a>
    c6cc:	31 ff                	xor    %edi,%edi
    c6ce:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    c6d3:	48 63 c7             	movslq %edi,%rax
    c6d6:	be 40 00 00 00       	mov    $0x40,%esi
    c6db:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    c6e0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    c6e5:	48 29 c6             	sub    %rax,%rsi
    c6e8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    c6ed:	48 09 c8             	or     %rcx,%rax
    c6f0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    c6f5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    c6fa:	49 89 c6             	mov    %rax,%r14
    c6fd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    c701:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    c706:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    c70b:	49 09 c1             	or     %rax,%r9
    c70e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    c712:	4c 89 c8             	mov    %r9,%rax
    c715:	49 f7 f6             	div    %r14
    c718:	48 89 d1             	mov    %rdx,%rcx
    c71b:	49 89 c3             	mov    %rax,%r11
    c71e:	49 89 c1             	mov    %rax,%r9
    c721:	49 f7 e2             	mul    %r10
    c724:	49 89 c6             	mov    %rax,%r14
    c727:	49 89 d2             	mov    %rdx,%r10
    c72a:	48 39 d1             	cmp    %rdx,%rcx
    c72d:	72 07                	jb     c736 <__divmodti4+0x126>
    c72f:	75 17                	jne    c748 <__divmodti4+0x138>
    c731:	49 39 c7             	cmp    %rax,%r15
    c734:	73 12                	jae    c748 <__divmodti4+0x138>
    c736:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    c73a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    c73e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    c742:	49 89 d2             	mov    %rdx,%r10
    c745:	49 89 c6             	mov    %rax,%r14
    c748:	4c 89 f8             	mov    %r15,%rax
    c74b:	4c 29 f0             	sub    %r14,%rax
    c74e:	4c 19 d1             	sbb    %r10,%rcx
    c751:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    c756:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    c75b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    c760:	48 09 c6             	or     %rax,%rsi
    c763:	48 89 cf             	mov    %rcx,%rdi
    c766:	31 c0                	xor    %eax,%eax
    c768:	4c 89 c9             	mov    %r9,%rcx
    c76b:	e9 10 ff ff ff       	jmp    c680 <__divmodti4+0x70>
    c770:	4c 89 d0             	mov    %r10,%rax
    c773:	4c 89 da             	mov    %r11,%rdx
    c776:	4d 89 c4             	mov    %r8,%r12
    c779:	49 89 f3             	mov    %rsi,%r11
    c77c:	48 f7 d8             	neg    %rax
    c77f:	49 f7 d4             	not    %r12
    c782:	48 83 d2 00          	adc    $0x0,%rdx
    c786:	49 89 c2             	mov    %rax,%r10
    c789:	48 f7 da             	neg    %rdx
    c78c:	48 89 d1             	mov    %rdx,%rcx
    c78f:	0f 84 cc fe ff ff    	je     c661 <__divmodti4+0x51>
    c795:	49 39 d1             	cmp    %rdx,%r9
    c798:	73 46                	jae    c7e0 <__divmodti4+0x1d0>
    c79a:	4c 89 cf             	mov    %r9,%rdi
    c79d:	31 c0                	xor    %eax,%eax
    c79f:	31 c9                	xor    %ecx,%ecx
    c7a1:	e9 da fe ff ff       	jmp    c680 <__divmodti4+0x70>
    c7a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    c7ad:	00 00 00 
    c7b0:	4d 85 d2             	test   %r10,%r10
    c7b3:	75 0d                	jne    c7c2 <__divmodti4+0x1b2>
    c7b5:	b8 01 00 00 00       	mov    $0x1,%eax
    c7ba:	31 d2                	xor    %edx,%edx
    c7bc:	49 f7 f2             	div    %r10
    c7bf:	49 89 c2             	mov    %rax,%r10
    c7c2:	4c 89 c8             	mov    %r9,%rax
    c7c5:	31 d2                	xor    %edx,%edx
    c7c7:	49 f7 f2             	div    %r10
    c7ca:	49 89 c1             	mov    %rax,%r9
    c7cd:	4c 89 d8             	mov    %r11,%rax
    c7d0:	49 f7 f2             	div    %r10
    c7d3:	49 89 c3             	mov    %rax,%r11
    c7d6:	4c 89 c8             	mov    %r9,%rax
    c7d9:	e9 9a fe ff ff       	jmp    c678 <__divmodti4+0x68>
    c7de:	66 90                	xchg   %ax,%ax
    c7e0:	45 31 f6             	xor    %r14d,%r14d
    c7e3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    c7e8:	44 89 f7             	mov    %r14d,%edi
    c7eb:	45 85 f6             	test   %r14d,%r14d
    c7ee:	0f 85 df fe ff ff    	jne    c6d3 <__divmodti4+0xc3>
    c7f4:	4c 39 ca             	cmp    %r9,%rdx
    c7f7:	72 17                	jb     c810 <__divmodti4+0x200>
    c7f9:	31 c9                	xor    %ecx,%ecx
    c7fb:	48 39 c6             	cmp    %rax,%rsi
    c7fe:	73 10                	jae    c810 <__divmodti4+0x200>
    c800:	4c 89 cf             	mov    %r9,%rdi
    c803:	31 c0                	xor    %eax,%eax
    c805:	e9 76 fe ff ff       	jmp    c680 <__divmodti4+0x70>
    c80a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    c810:	4c 89 de             	mov    %r11,%rsi
    c813:	b9 01 00 00 00       	mov    $0x1,%ecx
    c818:	48 29 c6             	sub    %rax,%rsi
    c81b:	49 19 d1             	sbb    %rdx,%r9
    c81e:	eb e0                	jmp    c800 <__divmodti4+0x1f0>

000000000000c820 <atexit>:
    c820:	f3 0f 1e fa          	endbr64
    c824:	48 8b 15 dd 47 00 00 	mov    0x47dd(%rip),%rdx        # 11008 <__dso_handle>
    c82b:	31 f6                	xor    %esi,%esi
    c82d:	e9 0e 6e ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000c834 <_fini>:
    c834:	f3 0f 1e fa          	endbr64
    c838:	48 83 ec 08          	sub    $0x8,%rsp
    c83c:	48 83 c4 08          	add    $0x8,%rsp
    c840:	c3                   	ret
