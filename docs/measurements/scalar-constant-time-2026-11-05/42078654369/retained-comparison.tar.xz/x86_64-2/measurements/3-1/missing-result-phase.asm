
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/missing-result-phase:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 cf 00 00 	mov    0xcfc1(%rip),%rax        # ffd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da cd 00 00    	push   0xcdda(%rip)        # fe00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc cd 00 00    	jmp    *0xcddc(%rip)        # fe08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 cc 00 00    	jmp    *0xcc46(%rip)        # ffe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # fe10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # fe18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # fe20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # fe28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # fe30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # fe38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # fe40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # fe48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # fe50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # fe58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # fe60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # fe68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # fe70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # fe78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # fe80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # fe88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # fe90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # fe98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # fea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # fea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # feb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # feb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # fec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # fec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # fed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # fed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # fee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # fee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # fef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # fef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ff00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ff08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ff10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ff18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ff20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ff28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ff30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ff38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # ff40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # ff48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # ff50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # ff58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # ff60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e c9 00 00    	jmp    *0xc90e(%rip)        # ff68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 c9 00 00    	jmp    *0xc906(%rip)        # ff70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe c8 00 00    	jmp    *0xc8fe(%rip)        # ff78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 c8 00 00    	jmp    *0xc8f6(%rip)        # ff80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee c8 00 00    	jmp    *0xc8ee(%rip)        # ff88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 c8 00 00    	jmp    *0xc8e6(%rip)        # ff90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de c8 00 00    	jmp    *0xc8de(%rip)        # ff98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 c8 00 00    	jmp    *0xc8d6(%rip)        # ffa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce c8 00 00    	jmp    *0xc8ce(%rip)        # ffa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 c8 00 00    	jmp    *0xc8c6(%rip)        # ffb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be c8 00 00    	jmp    *0xc8be(%rip)        # ffb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd 89 00 00 	lea    0x89dd(%rip),%r9        # c0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da 89 00 00 	lea    0x89da(%rip),%r8        # c0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_main_thread.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <main.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>
    3755:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    375c:	00 00 00 
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 81 ab 00 00 	lea    0xab81(%rip),%rax        # e300 <fwp_fn_table>
    377f:	48 89 05 92 ec 01 00 	mov    %rax,0x1ec92(%rip)        # 22418 <fwp_fns>
    3786:	48 8b 05 93 c8 00 00 	mov    0xc893(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 8c ec 01 00 	mov    %rax,0x1ec8c(%rip)        # 22420 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d b7 8a 00 00 	lea    0x8ab7(%rip),%rdi        # c257 <_IO_stdin_used+0x257>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 c8 00 00 	mov    0xc818(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 4f 59 00 00 	lea    0x594f(%rip),%rdx        # 91b0 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 d6 fe ff ff    	jne    3750 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 ba fe ff ff    	jne    3750 <main.cold>
    3896:	48 8b 3d 83 c7 00 00 	mov    0xc783(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 c7 01 00    	mov    0x1c7d8(%rip),%eax        # 20080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 67 89 00 00 	lea    0x8967(%rip),%rdi        # c260 <_IO_stdin_used+0x260>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 86 91 00 00 	lea    0x9186(%rip),%rdi        # ca90 <_IO_stdin_used+0xa90>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 2f fe ff ff    	jne    3750 <main.cold>
    3921:	48 8d 3d 40 91 00 00 	lea    0x9140(%rip),%rdi        # ca68 <_IO_stdin_used+0xa68>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d 04 91 00 00 	lea    0x9104(%rip),%rdi        # ca38 <_IO_stdin_used+0xa38>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d d0 90 00 00 	lea    0x90d0(%rip),%rdi        # ca10 <_IO_stdin_used+0xa10>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b c6 00 00    	call   *0xc64b(%rip)        # ffc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 c6 00 00 	lea    0xc699(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 c6 00 00 	lea    0xc692(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e c6 00 00 	mov    0xc62e(%rip),%rax        # ffc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 c6 00 00 	lea    0xc669(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 c6 00 00 	lea    0xc662(%rip),%rsi        # 10020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd c5 00 00 	mov    0xc5fd(%rip),%rax        # ffd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d c6 00 00 00 	cmpb   $0x0,0xc64d(%rip)        # 10048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da c5 00 00 	cmpq   $0x0,0xc5da(%rip)        # ffe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 c5 00 00 	mov    0xc5f6(%rip),%rdi        # 10008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 c6 00 00 01 	movb   $0x1,0xc625(%rip)        # 10048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce c4 01 00 	add    0x1c4ce(%rip),%rdx        # 200f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc c4 01 00 	add    0x1c4bc(%rip),%rax        # 200f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d a9 e7 01 00 	mov    0x1e7a9(%rip),%rdi        # 22420 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 c3 00 00 	mov    0xc394(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 c3 00 00 	mov    0xc381(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 83 00 00 	lea    0x8345(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 c3 00 00 	mov    0xc372(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 a1 ca 01 00 	mov    0x1caa1(%rip),%rax        # 207a0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 d9 c3 01 00 	mov    0x1c3d9(%rip),%rax        # 20158 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 c5 c3 01 00 	sub    0x1c3c5(%rip),%rax        # 20150 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 ad 8d 00 00 	lea    0x8dad(%rip),%rsi        # cb70 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 87 88 00 00 	lea    0x8887(%rip),%rdi        # c670 <_IO_stdin_used+0x670>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 42 c2 00 00 	mov    0xc242(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d e5 c1 00 00 ff 	cmpl   $0xffffffff,0xc1e5(%rip)        # 10018 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 81 00 00 	lea    0x81e2(%rip),%rax        # c022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d c1 c2 01 00 	mov    0x1c2c1(%rip),%r9        # 20108 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f bd 00 	movq   0xbd9f(%rip),%xmm0        # fbf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 81 00 00 	lea    0x81e7(%rip),%rax        # c044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 9c c2 01 00 	mov    0x1c29c(%rip),%r8        # 20100 <descent_inputs>
    3e64:	48 8b 0d a5 c2 01 00 	mov    0x1c2a5(%rip),%rcx        # 20110 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d c2 c1 00 00 	mov    0xc1c2(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 81 00 00 	lea    0x81d8(%rip),%rax        # c061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 bd 00 	movq   0xbd67(%rip),%xmm0        # fbf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 20 88 00 00 	lea    0x8820(%rip),%rdx        # c6b8 <_IO_stdin_used+0x6b8>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 71 c2 01 00 	lea    0x1c271(%rip),%r12        # 20120 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 bd 00 	movq   0xbd44(%rip),%xmm0        # fc00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 5b c1 00 00 	mov    0xc15b(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 81 00 00 	lea    0x8175(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 81 00 00 	lea    0x8170(%rip),%rdx        # c06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 20 c1 00 00 	mov    0xc120(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 81 00 00 	lea    0x8144(%rip),%rdi        # c07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d f9 c0 00 00 	mov    0xc0f9(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 81 00 00 	lea    0x8143(%rip),%rcx        # c091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 81 00 00 	lea    0x8119(%rip),%rdx        # c06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 1b dc 01 00 	mov    0x1dc1b(%rip),%rax        # 21bb0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 14 dc 01 00 	lea    0x1dc14(%rip),%r8        # 21bb0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d f5 db 01 00 	mov    0x1dbf5(%rip),%rbx        # 21b98 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 05 dc 01 00 	mov    0x1dc05(%rip),%rcx        # 21bb8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d a1 db 01 00 	mov    0x1dba1(%rip),%rdi        # 21ba0 <fwp_heap+0x13e0>
    3fff:	48 29 35 ea db 01 00 	sub    %rsi,0x1dbea(%rip)        # 21bf0 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 7a db 01 00 	mov    0x1db7a(%rip),%rax        # 21b90 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 30 db 01 00 	add    0x1db30(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 3e db 01 00 	mov    0x1db3e(%rip),%rsi        # 21ba0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 4c db 01 00 	mov    0x1db4c(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 fb da 01 00 	mov    %r12,0x1dafb(%rip)        # 21ba0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d e9 da 01 00 	mov    %rbp,0x1dae9(%rip)        # 21b98 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d ce da 01 00 	cmp    %rdi,0x1dace(%rip)        # 21b88 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d c5 da 01 00 	mov    %rdi,0x1dac5(%rip)        # 21b88 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 09 db 01 00 	sub    %rdi,0x1db09(%rip)        # 21bf0 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 b1 da 01 00 	mov    0x1dab1(%rip),%rax        # 21ba8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 aa da 01 00 	lea    0x1daaa(%rip),%r8        # 21ba8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 5d be 00 00 	mov    0xbe5d(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 7e 00 00 	lea    0x7e14(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d ad bd 00 00 	movslq 0xbdad(%rip),%rbp        # 10018 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 7a be 01 00 	mov    0x1be7a(%rip),%rsi        # 20118 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d 76 be 01 00 	lea    0x1be76(%rip),%rcx        # 20120 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 4b be 01 00 	addq   $0x1,0x1be4b(%rip)        # 20110 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 48 bd 00 00    	mov    %ebx,0xbd48(%rip)        # 10018 <descent_active_phase>
    42d0:	48 89 05 41 be 01 00 	mov    %rax,0x1be41(%rip)        # 20118 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d 99 c4 01 00 	cmp    0x1c499(%rip),%rdi        # 207a0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 5f c4 01 00 	mov    0x1c45f(%rip),%rax        # 20780 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 3d c4 01 00 	mov    %rdi,0x1c43d(%rip)        # 20780 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 19 c4 01 00 	mov    %rdi,0x1c419(%rip)        # 20788 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 ee 7d 00 00 	lea    0x7dee(%rip),%rsi        # c19f <_IO_stdin_used+0x19f>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba 7c 00 00 	lea    0x7cba(%rip),%rsi        # c07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 28 bc 00 00 	mov    0xbc28(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 7c 00 00 	lea    0x7c64(%rip),%rdx        # c083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 10 bc 00 00 	mov    0xbc10(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 21 bb 00 00 	mov    0xbb21(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 7a 00 00 	lea    0x7ad8(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 7b 00 00 	lea    0x7b45(%rip),%rdi        # c092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd 7a 00 00 	lea    0x7acd(%rip),%rdi        # c0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d 18 81 00 00 	lea    0x8118(%rip),%rdi        # c708 <_IO_stdin_used+0x708>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 b0 85 00 	movdqa 0x85b0(%rip),%xmm0        # cbc0 <msg.4+0x50>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 aa dd 01 00 	add    0x1ddaa(%rip),%rax        # 22418 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 6c 80 00 00 	lea    0x806c(%rip),%rdi        # c730 <_IO_stdin_used+0x730>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 05 ba 01 00 	cmp    %rax,0x1ba05(%rip)        # 200e8 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 00 ba 01 00 	add    0x1ba00(%rip),%rax        # 200f0 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 55 80 00 00 	lea    0x8055(%rip),%rdi        # c760 <_IO_stdin_used+0x760>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 79 00 00 	lea    0x79a5(%rip),%r8        # c0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa 77 00 00 	lea    0x77fa(%rip),%r8        # c0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 76 00 00 	lea    0x7697(%rip),%r8        # c0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f 74 00 00 	lea    0x746f(%rip),%rdi        # c0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 54 75 00 00 	lea    0x7554(%rip),%rsi        # c1e2 <_IO_stdin_used+0x1e2>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d 85 ce 01 00 	mov    0x1ce85(%rip),%r9        # 21b88 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 de ce 01 00 	mov    0x1cede(%rip),%r8        # 21be8 <fwp_heap+0x1428>
    4d0a:	48 8d 15 9f 7a 00 00 	lea    0x7a9f(%rip),%rdx        # c7b0 <_IO_stdin_used+0x7b0>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d c6 ce 01 00 	mov    0x1cec6(%rip),%rcx        # 21be0 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d d4 ce 01 	movsd  0x1ced4(%rip),%xmm1        # 21c00 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 c4 ce 01 	movsd  0x1cec4(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 05 b3 00 00 	mov    0xb305(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 58 7e 00 	movdqa 0x7e58(%rip),%xmm0        # cbd0 <msg.4+0x60>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 7f c9 01 00 	lea    0x1c97f(%rip),%rax        # 21700 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 81 7e 00 	movdqa 0x7e81(%rip),%xmm2        # cc10 <msg.4+0xa0>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 25 c9 01 00 	movaps %xmm0,0x1c925(%rip)        # 216c0 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 3d 7e 00 	movdqa 0x7e3d(%rip),%xmm0        # cbe0 <msg.4+0x70>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 b3 cd 01 00 01 	movl   $0x1,0x1cdb3(%rip)        # 21b64 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 13 c9 01 00 	movaps %xmm0,0x1c913(%rip)        # 216d0 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 2b 7e 00 	movdqa 0x7e2b(%rip),%xmm0        # cbf0 <msg.4+0x80>
    4dc4:	00 
    4dc5:	0f 29 05 14 c9 01 00 	movaps %xmm0,0x1c914(%rip)        # 216e0 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 2c 7e 00 	movdqa 0x7e2c(%rip),%xmm0        # cc00 <msg.4+0x90>
    4dd3:	00 
    4dd4:	0f 29 05 15 c9 01 00 	movaps %xmm0,0x1c915(%rip)        # 216f0 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 95 b9 01 00 	lea    0x1b995(%rip),%r8        # 207c0 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 b0 cc 01 00 	mov    %rax,0x1ccb0(%rip)        # 21b78 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 8e cc 01 00 	mov    %r12,0x1cc8e(%rip)        # 21b80 <fwp_heap+0x13c0>
    4ef2:	48 89 05 77 cc 01 00 	mov    %rax,0x1cc77(%rip)        # 21b70 <fwp_heap+0x13b0>
    4ef9:	48 89 1d 90 cc 01 00 	mov    %rbx,0x1cc90(%rip)        # 21b90 <fwp_heap+0x13d0>
    4f00:	48 89 35 b9 cc 01 00 	mov    %rsi,0x1ccb9(%rip)        # 21bc0 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 71 00 00 	lea    0x71f9(%rip),%rdi        # c112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 98 cc 01 00 	mov    %rax,0x1cc98(%rip)        # 21bb8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 1c cc 01 00    	mov    %eax,0x1cc1c(%rip)        # 21b68 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <fwp_wake_io>:
    4f60:	48 8b 07             	mov    (%rdi),%rax
    4f63:	48 85 c0             	test   %rax,%rax
    4f66:	0f 84 f4 00 00 00    	je     5060 <fwp_wake_io+0x100>
    4f6c:	53                   	push   %rbx
    4f6d:	4c 8b 05 0c b8 01 00 	mov    0x1b80c(%rip),%r8        # 20780 <fwp_ready_tail>
    4f74:	49 89 f9             	mov    %rdi,%r9
    4f77:	48 89 c2             	mov    %rax,%rdx
    4f7a:	45 31 db             	xor    %r11d,%r11d
    4f7d:	45 31 d2             	xor    %r10d,%r10d
    4f80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f84:	eb 71                	jmp    4ff7 <fwp_wake_io+0x97>
    4f86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f8d:	00 00 00 
    4f90:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4f97:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4f9e:	48 85 c9             	test   %rcx,%rcx
    4fa1:	74 07                	je     4faa <fwp_wake_io+0x4a>
    4fa3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4faa:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4fb1:	00 00 00 00 
    4fb5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4fbc:	49 8b 01             	mov    (%r9),%rax
    4fbf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4fc3:	75 2a                	jne    4fef <fwp_wake_io+0x8f>
    4fc5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4fc9:	75 24                	jne    4fef <fwp_wake_io+0x8f>
    4fcb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4fcf:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4fd6:	00 00 00 00 
    4fda:	4d 85 c0             	test   %r8,%r8
    4fdd:	74 51                	je     5030 <fwp_wake_io+0xd0>
    4fdf:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4fe6:	49 89 d0             	mov    %rdx,%r8
    4fe9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4fef:	48 89 c2             	mov    %rax,%rdx
    4ff2:	48 85 c0             	test   %rax,%rax
    4ff5:	74 49                	je     5040 <fwp_wake_io+0xe0>
    4ff7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4ffe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5002:	48 85 ff             	test   %rdi,%rdi
    5005:	74 b8                	je     4fbf <fwp_wake_io+0x5f>
    5007:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    500e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5015:	48 85 f6             	test   %rsi,%rsi
    5018:	0f 85 72 ff ff ff    	jne    4f90 <fwp_wake_io+0x30>
    501e:	48 89 0f             	mov    %rcx,(%rdi)
    5021:	e9 78 ff ff ff       	jmp    4f9e <fwp_wake_io+0x3e>
    5026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    502d:	00 00 00 
    5030:	48 89 d3             	mov    %rdx,%rbx
    5033:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5039:	eb ab                	jmp    4fe6 <fwp_wake_io+0x86>
    503b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5040:	45 84 db             	test   %r11b,%r11b
    5043:	74 07                	je     504c <fwp_wake_io+0xec>
    5045:	48 89 1d 3c b7 01 00 	mov    %rbx,0x1b73c(%rip)        # 20788 <fwp_ready_head>
    504c:	45 84 d2             	test   %r10b,%r10b
    504f:	74 07                	je     5058 <fwp_wake_io+0xf8>
    5051:	4c 89 05 28 b7 01 00 	mov    %r8,0x1b728(%rip)        # 20780 <fwp_ready_tail>
    5058:	5b                   	pop    %rbx
    5059:	c3                   	ret
    505a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5060:	c3                   	ret
    5061:	0f 1f 40 00          	nopl   0x0(%rax)
    5065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    506c:	00 00 00 00 

0000000000005070 <fwp_tape_buffers_release>:
    5070:	f3 0f 1e fa          	endbr64
    5074:	53                   	push   %rbx
    5075:	48 89 fb             	mov    %rdi,%rbx
    5078:	48 83 ec 10          	sub    $0x10,%rsp
    507c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5080:	48 85 c0             	test   %rax,%rax
    5083:	0f 88 df 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5089:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    508d:	48 85 d2             	test   %rdx,%rdx
    5090:	0f 88 d2 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5096:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    509c:	0f 87 c6 00 00 00    	ja     5168 <fwp_tape_buffers_release+0xf8>
    50a2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    50a6:	b8 00 00 08 00       	mov    $0x80000,%eax
    50ab:	48 c1 e1 03          	shl    $0x3,%rcx
    50af:	48 29 c8             	sub    %rcx,%rax
    50b2:	48 c1 e8 03          	shr    $0x3,%rax
    50b6:	48 39 d0             	cmp    %rdx,%rax
    50b9:	0f 82 a9 00 00 00    	jb     5168 <fwp_tape_buffers_release+0xf8>
    50bf:	48 8d 3d 5c 70 00 00 	lea    0x705c(%rip),%rdi        # c122 <_IO_stdin_used+0x122>
    50c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    50cb:	48 89 14 24          	mov    %rdx,(%rsp)
    50cf:	e8 cc e2 ff ff       	call   33a0 <getenv@plt>
    50d4:	48 8b 14 24          	mov    (%rsp),%rdx
    50d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    50dd:	48 85 c0             	test   %rax,%rax
    50e0:	74 09                	je     50eb <fwp_tape_buffers_release+0x7b>
    50e2:	80 38 30             	cmpb   $0x30,(%rax)
    50e5:	0f 84 9d 00 00 00    	je     5188 <fwp_tape_buffers_release+0x118>
    50eb:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    50ef:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    50f3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    50fa:	77 78                	ja     5174 <fwp_tape_buffers_release+0x104>
    50fc:	48 8d 3d 9d af 01 00 	lea    0x1af9d(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    5103:	48 89 04 24          	mov    %rax,(%rsp)
    5107:	e8 04 f0 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    510c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5110:	48 8b 04 24          	mov    (%rsp),%rax
    5114:	0f 29 05 85 af 01 00 	movaps %xmm0,0x1af85(%rip)        # 200a0 <fwp_tape_workspace>
    511b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5120:	48 89 05 61 af 01 00 	mov    %rax,0x1af61(%rip)        # 20088 <fwp_tape_cached_bytes>
    5127:	0f 29 05 82 af 01 00 	movaps %xmm0,0x1af82(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    512e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5133:	0f 29 05 86 af 01 00 	movaps %xmm0,0x1af86(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    513a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    513e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5142:	48 89 15 87 af 01 00 	mov    %rdx,0x1af87(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    5149:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5150:	00 
    5151:	0f 11 03             	movups %xmm0,(%rbx)
    5154:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5158:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    515c:	48 83 c4 10          	add    $0x10,%rsp
    5160:	5b                   	pop    %rbx
    5161:	c3                   	ret
    5162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5168:	48 8d 3d b3 6f 00 00 	lea    0x6fb3(%rip),%rdi        # c122 <_IO_stdin_used+0x122>
    516f:	e8 2c e2 ff ff       	call   33a0 <getenv@plt>
    5174:	48 83 c4 10          	add    $0x10,%rsp
    5178:	48 89 df             	mov    %rbx,%rdi
    517b:	5b                   	pop    %rbx
    517c:	e9 8f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    5181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5188:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    518c:	0f 85 59 ff ff ff    	jne    50eb <fwp_tape_buffers_release+0x7b>
    5192:	48 83 c4 10          	add    $0x10,%rsp
    5196:	48 89 df             	mov    %rbx,%rdi
    5199:	5b                   	pop    %rbx
    519a:	e9 71 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    519f:	90                   	nop

00000000000051a0 <fwp_poll_events>:
    51a0:	53                   	push   %rbx
    51a1:	48 83 ec 20          	sub    $0x20,%rsp
    51a5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    51b3:	31 c0                	xor    %eax,%eax
    51b5:	e8 a6 f3 ff ff       	call   4560 <fwp_now_ns>
    51ba:	48 8b 1d b7 b5 01 00 	mov    0x1b5b7(%rip),%rbx        # 20778 <fwp_timers>
    51c1:	48 85 db             	test   %rbx,%rbx
    51c4:	0f 84 d6 00 00 00    	je     52a0 <fwp_poll_events+0x100>
    51ca:	48 89 c6             	mov    %rax,%rsi
    51cd:	48 89 da             	mov    %rbx,%rdx
    51d0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    51d7:	eb 16                	jmp    51ef <fwp_poll_events+0x4f>
    51d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51e7:	48 89 c8             	mov    %rcx,%rax
    51ea:	48 85 d2             	test   %rdx,%rdx
    51ed:	74 31                	je     5220 <fwp_poll_events+0x80>
    51ef:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51f3:	48 85 c0             	test   %rax,%rax
    51f6:	78 e8                	js     51e0 <fwp_poll_events+0x40>
    51f8:	48 39 c1             	cmp    %rax,%rcx
    51fb:	7c e3                	jl     51e0 <fwp_poll_events+0x40>
    51fd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5204:	48 85 d2             	test   %rdx,%rdx
    5207:	74 1c                	je     5225 <fwp_poll_events+0x85>
    5209:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    520d:	48 39 c1             	cmp    %rax,%rcx
    5210:	7c ce                	jl     51e0 <fwp_poll_events+0x40>
    5212:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5219:	48 85 d2             	test   %rdx,%rdx
    521c:	75 d1                	jne    51ef <fwp_poll_events+0x4f>
    521e:	66 90                	xchg   %ax,%ax
    5220:	48 85 c0             	test   %rax,%rax
    5223:	78 7b                	js     52a0 <fwp_poll_events+0x100>
    5225:	48 29 f0             	sub    %rsi,%rax
    5228:	48 89 c1             	mov    %rax,%rcx
    522b:	48 85 c0             	test   %rax,%rax
    522e:	0f 8e 9c 00 00 00    	jle    52d0 <fwp_poll_events+0x130>
    5234:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    523b:	de 1b 43 
    523e:	48 f7 ea             	imul   %rdx
    5241:	48 89 c8             	mov    %rcx,%rax
    5244:	48 c1 f8 3f          	sar    $0x3f,%rax
    5248:	48 c1 fa 12          	sar    $0x12,%rdx
    524c:	48 29 c2             	sub    %rax,%rdx
    524f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5256:	48 39 c1             	cmp    %rax,%rcx
    5259:	0f 95 c0             	setne  %al
    525c:	0f b6 c0             	movzbl %al,%eax
    525f:	48 01 d0             	add    %rdx,%rax
    5262:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5268:	0f 8f 32 01 00 00    	jg     53a0 <fwp_poll_events+0x200>
    526e:	48 85 c0             	test   %rax,%rax
    5271:	74 5d                	je     52d0 <fwp_poll_events+0x130>
    5273:	89 c1                	mov    %eax,%ecx
    5275:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    527c:	48 c1 e9 26          	shr    $0x26,%rcx
    5280:	48 63 d1             	movslq %ecx,%rdx
    5283:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5289:	29 c8                	sub    %ecx,%eax
    528b:	48 98                	cltq
    528d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5294:	e9 11 01 00 00       	jmp    53aa <fwp_poll_events+0x20a>
    5299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52a0:	e8 cb e9 ff ff       	call   3c70 <fwp_flush>
    52a5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    52aa:	be 01 00 00 00       	mov    $0x1,%esi
    52af:	48 8b 0d 8a ad 00 00 	mov    0xad8a(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    52b6:	48 8d 3d 7b 75 00 00 	lea    0x757b(%rip),%rdi        # c838 <_IO_stdin_used+0x838>
    52bd:	e8 be e3 ff ff       	call   3680 <fwrite@plt>
    52c2:	bf 65 00 00 00       	mov    $0x65,%edi
    52c7:	e8 a4 e3 ff ff       	call   3670 <exit@plt>
    52cc:	0f 1f 40 00          	nopl   0x0(%rax)
    52d0:	e8 8b f2 ff ff       	call   4560 <fwp_now_ns>
    52d5:	48 89 c1             	mov    %rax,%rcx
    52d8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    52dc:	eb 44                	jmp    5322 <fwp_poll_events+0x182>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    52e4:	75 33                	jne    5319 <fwp_poll_events+0x179>
    52e6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    52ea:	75 2d                	jne    5319 <fwp_poll_events+0x179>
    52ec:	48 8b 05 8d b4 01 00 	mov    0x1b48d(%rip),%rax        # 20780 <fwp_ready_tail>
    52f3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    52f7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    52fe:	00 00 00 00 
    5302:	48 85 c0             	test   %rax,%rax
    5305:	0f 84 05 01 00 00    	je     5410 <fwp_poll_events+0x270>
    530b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5312:	48 89 15 67 b4 01 00 	mov    %rdx,0x1b467(%rip)        # 20780 <fwp_ready_tail>
    5319:	48 85 db             	test   %rbx,%rbx
    531c:	0f 84 be 00 00 00    	je     53e0 <fwp_poll_events+0x240>
    5322:	48 89 da             	mov    %rbx,%rdx
    5325:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    532c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5330:	7f e7                	jg     5319 <fwp_poll_events+0x179>
    5332:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5336:	74 2e                	je     5366 <fwp_poll_events+0x1c6>
    5338:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    533f:	48 85 c0             	test   %rax,%rax
    5342:	0f 84 b8 00 00 00    	je     5400 <fwp_poll_events+0x260>
    5348:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    534f:	48 85 db             	test   %rbx,%rbx
    5352:	74 07                	je     535b <fwp_poll_events+0x1bb>
    5354:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    535b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    535f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5366:	48 8b 42 60          	mov    0x60(%rdx),%rax
    536a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    536e:	48 85 c0             	test   %rax,%rax
    5371:	0f 84 69 ff ff ff    	je     52e0 <fwp_poll_events+0x140>
    5377:	48 39 c8             	cmp    %rcx,%rax
    537a:	0f 8f 60 ff ff ff    	jg     52e0 <fwp_poll_events+0x140>
    5380:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5384:	0f 85 56 ff ff ff    	jne    52e0 <fwp_poll_events+0x140>
    538a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    538e:	75 89                	jne    5319 <fwp_poll_events+0x179>
    5390:	48 89 d7             	mov    %rdx,%rdi
    5393:	e8 68 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    5398:	e9 43 ff ff ff       	jmp    52e0 <fwp_poll_events+0x140>
    539d:	0f 1f 00             	nopl   (%rax)
    53a0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    53a5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    53aa:	48 89 e7             	mov    %rsp,%rdi
    53ad:	31 f6                	xor    %esi,%esi
    53af:	48 89 14 24          	mov    %rdx,(%rsp)
    53b3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    53b8:	e8 e3 e0 ff ff       	call   34a0 <nanosleep@plt>
    53bd:	48 8b 1d b4 b3 01 00 	mov    0x1b3b4(%rip),%rbx        # 20778 <fwp_timers>
    53c4:	e8 97 f1 ff ff       	call   4560 <fwp_now_ns>
    53c9:	48 89 c1             	mov    %rax,%rcx
    53cc:	48 85 db             	test   %rbx,%rbx
    53cf:	0f 85 03 ff ff ff    	jne    52d8 <fwp_poll_events+0x138>
    53d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53dc:	00 00 00 00 
    53e0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    53e5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    53ec:	00 00 
    53ee:	75 2c                	jne    541c <fwp_poll_events+0x27c>
    53f0:	48 83 c4 20          	add    $0x20,%rsp
    53f4:	5b                   	pop    %rbx
    53f5:	c3                   	ret
    53f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53fd:	00 00 00 
    5400:	48 89 1d 71 b3 01 00 	mov    %rbx,0x1b371(%rip)        # 20778 <fwp_timers>
    5407:	e9 43 ff ff ff       	jmp    534f <fwp_poll_events+0x1af>
    540c:	0f 1f 40 00          	nopl   0x0(%rax)
    5410:	48 89 15 71 b3 01 00 	mov    %rdx,0x1b371(%rip)        # 20788 <fwp_ready_head>
    5417:	e9 f6 fe ff ff       	jmp    5312 <fwp_poll_events+0x172>
    541c:	e8 3f e0 ff ff       	call   3460 <__stack_chk_fail@plt>
    5421:	0f 1f 40 00          	nopl   0x0(%rax)
    5425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    542c:	00 00 00 00 

0000000000005430 <fwp_rc_wide_dup>:
    5430:	48 89 fa             	mov    %rdi,%rdx
    5433:	48 8d 35 86 b3 01 00 	lea    0x1b386(%rip),%rsi        # 207c0 <fwp_heap>
    543a:	48 83 ec 18          	sub    $0x18,%rsp
    543e:	48 89 f9             	mov    %rdi,%rcx
    5441:	48 c1 ea 11          	shr    $0x11,%rdx
    5445:	48 31 fa             	xor    %rdi,%rdx
    5448:	48 89 d0             	mov    %rdx,%rax
    544b:	48 c1 e8 09          	shr    $0x9,%rax
    544f:	48 31 c2             	xor    %rax,%rdx
    5452:	0f b6 d2             	movzbl %dl,%edx
    5455:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    545c:	00 
    545d:	49 8b 00             	mov    (%r8),%rax
    5460:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5467:	00 00 
    5469:	75 21                	jne    548c <fwp_rc_wide_dup+0x5c>
    546b:	e9 98 00 00 00       	jmp    5508 <fwp_rc_wide_dup+0xd8>
    5470:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 2f                	je     54b8 <fwp_rc_wide_dup+0x88>
    5489:	48 89 d0             	mov    %rdx,%rax
    548c:	48 3b 08             	cmp    (%rax),%rcx
    548f:	75 ef                	jne    5480 <fwp_rc_wide_dup+0x50>
    5491:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5494:	74 7c                	je     5512 <fwp_rc_wide_dup+0xe2>
    5496:	48 8b 50 08          	mov    0x8(%rax),%rdx
    549a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    549e:	0f 84 91 00 00 00    	je     5535 <fwp_rc_wide_dup+0x105>
    54a4:	48 83 c2 01          	add    $0x1,%rdx
    54a8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    54ac:	48 83 c4 18          	add    $0x18,%rsp
    54b0:	c3                   	ret
    54b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54b8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    54bc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54bf:	75 68                	jne    5529 <fwp_rc_wide_dup+0xf9>
    54c1:	bf 18 00 00 00       	mov    $0x18,%edi
    54c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    54cb:	4c 89 04 24          	mov    %r8,(%rsp)
    54cf:	e8 dc e0 ff ff       	call   35b0 <malloc@plt>
    54d4:	4c 8b 04 24          	mov    (%rsp),%r8
    54d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    54dd:	48 85 c0             	test   %rax,%rax
    54e0:	74 5f                	je     5541 <fwp_rc_wide_dup+0x111>
    54e2:	48 89 08             	mov    %rcx,(%rax)
    54e5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    54ec:	00 
    54ed:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    54f4:	00 
    54f5:	49 89 00             	mov    %rax,(%r8)
    54f8:	c6 01 ff             	movb   $0xff,(%rcx)
    54fb:	48 83 05 05 cf 01 00 	addq   $0x1,0x1cf05(%rip)        # 22408 <fwp_heap+0x1c48>
    5502:	01 
    5503:	48 83 c4 18          	add    $0x18,%rsp
    5507:	c3                   	ret
    5508:	80 3f fe             	cmpb   $0xfe,(%rdi)
    550b:	75 13                	jne    5520 <fwp_rc_wide_dup+0xf0>
    550d:	48 85 c0             	test   %rax,%rax
    5510:	74 af                	je     54c1 <fwp_rc_wide_dup+0x91>
    5512:	48 8d 3d 4f 73 00 00 	lea    0x734f(%rip),%rdi        # c868 <_IO_stdin_used+0x868>
    5519:	e8 d2 ee ff ff       	call   43f0 <fwp_trap>
    551e:	66 90                	xchg   %ax,%ax
    5520:	48 85 c0             	test   %rax,%rax
    5523:	0f 85 6d ff ff ff    	jne    5496 <fwp_rc_wide_dup+0x66>
    5529:	48 8d 3d 60 73 00 00 	lea    0x7360(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    5530:	e8 bb ee ff ff       	call   43f0 <fwp_trap>
    5535:	48 8d 3d f7 6b 00 00 	lea    0x6bf7(%rip),%rdi        # c133 <_IO_stdin_used+0x133>
    553c:	e8 af ee ff ff       	call   43f0 <fwp_trap>
    5541:	e8 6a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    5546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    554d:	00 00 00 

0000000000005550 <fwp_rc_forget_slot>:
    5550:	80 3f ff             	cmpb   $0xff,(%rdi)
    5553:	74 0b                	je     5560 <fwp_rc_forget_slot+0x10>
    5555:	c3                   	ret
    5556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    555d:	00 00 00 
    5560:	48 89 f8             	mov    %rdi,%rax
    5563:	48 83 ec 08          	sub    $0x8,%rsp
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 c1 e8 11          	shr    $0x11,%rax
    556e:	48 31 f8             	xor    %rdi,%rax
    5571:	48 89 c1             	mov    %rax,%rcx
    5574:	48 c1 e9 09          	shr    $0x9,%rcx
    5578:	48 31 c8             	xor    %rcx,%rax
    557b:	48 8d 0d 3e b2 01 00 	lea    0x1b23e(%rip),%rcx        # 207c0 <fwp_heap>
    5582:	0f b6 c0             	movzbl %al,%eax
    5585:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    558c:	00 
    558d:	48 85 ff             	test   %rdi,%rdi
    5590:	74 3c                	je     55ce <fwp_rc_forget_slot+0x7e>
    5592:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5599:	00 
    559a:	48 8b 01             	mov    (%rcx),%rax
    559d:	eb 11                	jmp    55b0 <fwp_rc_forget_slot+0x60>
    559f:	90                   	nop
    55a0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    55a4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    55a8:	48 85 ff             	test   %rdi,%rdi
    55ab:	74 21                	je     55ce <fwp_rc_forget_slot+0x7e>
    55ad:	48 89 f8             	mov    %rdi,%rax
    55b0:	48 3b 10             	cmp    (%rax),%rdx
    55b3:	75 eb                	jne    55a0 <fwp_rc_forget_slot+0x50>
    55b5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    55b9:	48 89 01             	mov    %rax,(%rcx)
    55bc:	e8 ff dd ff ff       	call   33c0 <free@plt>
    55c1:	48 83 2d 3f ce 01 00 	subq   $0x1,0x1ce3f(%rip)        # 22408 <fwp_heap+0x1c48>
    55c8:	01 
    55c9:	48 83 c4 08          	add    $0x8,%rsp
    55cd:	c3                   	ret
    55ce:	48 8d 3d bb 72 00 00 	lea    0x72bb(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    55d5:	e8 16 ee ff ff       	call   43f0 <fwp_trap>
    55da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000055e0 <fwp_rc_prepare_chunk>:
    55e0:	48 83 3d 20 ce 01 00 	cmpq   $0x0,0x1ce20(%rip)        # 22408 <fwp_heap+0x1c48>
    55e7:	00 
    55e8:	41 54                	push   %r12
    55ea:	49 89 f4             	mov    %rsi,%r12
    55ed:	55                   	push   %rbp
    55ee:	48 89 fd             	mov    %rdi,%rbp
    55f1:	53                   	push   %rbx
    55f2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    55f5:	0f 84 7d 00 00 00    	je     5678 <fwp_rc_prepare_chunk+0x98>
    55fb:	31 db                	xor    %ebx,%ebx
    55fd:	85 c0                	test   %eax,%eax
    55ff:	75 5f                	jne    5660 <fwp_rc_prepare_chunk+0x80>
    5601:	48 85 f6             	test   %rsi,%rsi
    5604:	74 7c                	je     5682 <fwp_rc_prepare_chunk+0xa2>
    5606:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    560a:	e8 b1 dd ff ff       	call   33c0 <free@plt>
    560f:	90                   	nop
    5610:	be 01 00 00 00       	mov    $0x1,%esi
    5615:	4c 89 e7             	mov    %r12,%rdi
    5618:	e8 03 df ff ff       	call   3520 <calloc@plt>
    561d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5621:	48 85 c0             	test   %rax,%rax
    5624:	0f 85 87 00 00 00    	jne    56b1 <fwp_rc_prepare_chunk+0xd1>
    562a:	e8 81 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    562f:	90                   	nop
    5630:	e8 1b ff ff ff       	call   5550 <fwp_rc_forget_slot>
    5635:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5638:	48 83 c3 01          	add    $0x1,%rbx
    563c:	48 39 c3             	cmp    %rax,%rbx
    563f:	73 37                	jae    5678 <fwp_rc_prepare_chunk+0x98>
    5641:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5648:	00 00 
    564a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5651:	00 00 00 00 
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5664:	48 01 df             	add    %rbx,%rdi
    5667:	80 3f ff             	cmpb   $0xff,(%rdi)
    566a:	74 c4                	je     5630 <fwp_rc_prepare_chunk+0x50>
    566c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    566f:	48 83 c3 01          	add    $0x1,%rbx
    5673:	48 39 c3             	cmp    %rax,%rbx
    5676:	72 e8                	jb     5660 <fwp_rc_prepare_chunk+0x80>
    5678:	49 39 c4             	cmp    %rax,%r12
    567b:	75 13                	jne    5690 <fwp_rc_prepare_chunk+0xb0>
    567d:	4d 85 e4             	test   %r12,%r12
    5680:	75 46                	jne    56c8 <fwp_rc_prepare_chunk+0xe8>
    5682:	5b                   	pop    %rbx
    5683:	5d                   	pop    %rbp
    5684:	41 5c                	pop    %r12
    5686:	c3                   	ret
    5687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    568e:	00 00 
    5690:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5694:	48 29 05 75 cd 01 00 	sub    %rax,0x1cd75(%rip)        # 22410 <fwp_heap+0x1c50>
    569b:	e8 20 dd ff ff       	call   33c0 <free@plt>
    56a0:	4d 85 e4             	test   %r12,%r12
    56a3:	0f 85 67 ff ff ff    	jne    5610 <fwp_rc_prepare_chunk+0x30>
    56a9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    56b0:	00 
    56b1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    56b5:	5b                   	pop    %rbx
    56b6:	4c 01 25 53 cd 01 00 	add    %r12,0x1cd53(%rip)        # 22410 <fwp_heap+0x1c50>
    56bd:	5d                   	pop    %rbp
    56be:	41 5c                	pop    %r12
    56c0:	c3                   	ret
    56c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56c8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56cc:	5b                   	pop    %rbx
    56cd:	4c 89 e2             	mov    %r12,%rdx
    56d0:	31 f6                	xor    %esi,%esi
    56d2:	5d                   	pop    %rbp
    56d3:	41 5c                	pop    %r12
    56d5:	e9 e6 dd ff ff       	jmp    34c0 <memset@plt>
    56da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000056e0 <fwp_heap_refill>:
    56e0:	41 56                	push   %r14
    56e2:	41 89 d6             	mov    %edx,%r14d
    56e5:	41 55                	push   %r13
    56e7:	41 89 f5             	mov    %esi,%r13d
    56ea:	41 54                	push   %r12
    56ec:	49 89 fc             	mov    %rdi,%r12
    56ef:	bf 01 00 00 00       	mov    $0x1,%edi
    56f4:	55                   	push   %rbp
    56f5:	53                   	push   %rbx
    56f6:	e8 85 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    56fb:	48 89 c3             	mov    %rax,%rbx
    56fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5702:	48 8b 05 af c4 01 00 	mov    0x1c4af(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    5709:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    570d:	48 8d 05 ac b0 01 00 	lea    0x1b0ac(%rip),%rax        # 207c0 <fwp_heap>
    5714:	31 d2                	xor    %edx,%edx
    5716:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    571a:	48 89 ef             	mov    %rbp,%rdi
    571d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5721:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5725:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    572c:	00 
    572d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5732:	f7 f1                	div    %ecx
    5734:	31 d2                	xor    %edx,%edx
    5736:	66 0f 6e c1          	movd   %ecx,%xmm0
    573a:	66 0f 6e c8          	movd   %eax,%xmm1
    573e:	89 c6                	mov    %eax,%esi
    5740:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5745:	48 01 c8             	add    %rcx,%rax
    5748:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    574c:	48 f7 f1             	div    %rcx
    574f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5754:	89 45 18             	mov    %eax,0x18(%rbp)
    5757:	e8 84 fe ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    575c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    575f:	48 89 d8             	mov    %rbx,%rax
    5762:	48 c1 e0 10          	shl    $0x10,%rax
    5766:	48 03 05 03 c4 01 00 	add    0x1c403(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    576d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5771:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5776:	8b 55 08             	mov    0x8(%rbp),%edx
    5779:	48 0f af d1          	imul   %rcx,%rdx
    577d:	48 01 c2             	add    %rax,%rdx
    5780:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5785:	5b                   	pop    %rbx
    5786:	5d                   	pop    %rbp
    5787:	41 5c                	pop    %r12
    5789:	41 5d                	pop    %r13
    578b:	41 5e                	pop    %r14
    578d:	c3                   	ret
    578e:	66 90                	xchg   %ax,%ax

0000000000005790 <fwp_mem_free>:
    5790:	48 85 ff             	test   %rdi,%rdi
    5793:	0f 84 17 02 00 00    	je     59b0 <fwp_mem_free+0x220>
    5799:	48 8b 35 d0 c3 01 00 	mov    0x1c3d0(%rip),%rsi        # 21b70 <fwp_heap+0x13b0>
    57a0:	48 8b 05 f1 c3 01 00 	mov    0x1c3f1(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    57a7:	48 89 fa             	mov    %rdi,%rdx
    57aa:	48 29 f2             	sub    %rsi,%rdx
    57ad:	48 c1 e0 10          	shl    $0x10,%rax
    57b1:	48 39 c2             	cmp    %rax,%rdx
    57b4:	0f 83 f6 01 00 00    	jae    59b0 <fwp_mem_free+0x220>
    57ba:	49 89 d1             	mov    %rdx,%r9
    57bd:	49 c1 e9 10          	shr    $0x10,%r9
    57c1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    57c5:	48 c1 e0 03          	shl    $0x3,%rax
    57c9:	49 89 c0             	mov    %rax,%r8
    57cc:	4c 03 05 e5 c3 01 00 	add    0x1c3e5(%rip),%r8        # 21bb8 <fwp_heap+0x13f8>
    57d3:	0f 84 d7 01 00 00    	je     59b0 <fwp_mem_free+0x220>
    57d9:	48 83 ec 38          	sub    $0x38,%rsp
    57dd:	48 89 f9             	mov    %rdi,%rcx
    57e0:	41 0f b6 38          	movzbl (%r8),%edi
    57e4:	40 80 ff 01          	cmp    $0x1,%dil
    57e8:	74 16                	je     5800 <fwp_mem_free+0x70>
    57ea:	40 80 ff 02          	cmp    $0x2,%dil
    57ee:	0f 84 94 00 00 00    	je     5888 <fwp_mem_free+0xf8>
    57f4:	48 83 c4 38          	add    $0x38,%rsp
    57f8:	c3                   	ret
    57f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5800:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5804:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5809:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    580e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5812:	4d 85 d2             	test   %r10,%r10
    5815:	74 1d                	je     5834 <fwp_mem_free+0xa4>
    5817:	0f b7 c1             	movzwl %cx,%eax
    581a:	31 d2                	xor    %edx,%edx
    581c:	48 f7 f7             	div    %rdi
    581f:	49 01 c2             	add    %rax,%r10
    5822:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5826:	0f 84 44 01 00 00    	je     5970 <fwp_mem_free+0x1e0>
    582c:	41 c6 02 00          	movb   $0x0,(%r10)
    5830:	41 8b 78 04          	mov    0x4(%r8),%edi
    5834:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    583b:	49 63 c1             	movslq %r9d,%rax
    583e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5842:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5846:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    584b:	f2 0f 58 05 ad c3 01 	addsd  0x1c3ad(%rip),%xmm0        # 21c00 <fwp_heap+0x1440>
    5852:	00 
    5853:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5857:	48 8d 05 62 af 01 00 	lea    0x1af62(%rip),%rax        # 207c0 <fwp_heap>
    585e:	48 01 d0             	add    %rdx,%rax
    5861:	48 8b 10             	mov    (%rax),%rdx
    5864:	48 f7 d2             	not    %rdx
    5867:	48 89 11             	mov    %rdx,(%rcx)
    586a:	48 89 08             	mov    %rcx,(%rax)
    586d:	48 29 3d 6c c3 01 00 	sub    %rdi,0x1c36c(%rip)        # 21be0 <fwp_heap+0x1420>
    5874:	f2 0f 11 05 84 c3 01 	movsd  %xmm0,0x1c384(%rip)        # 21c00 <fwp_heap+0x1440>
    587b:	00 
    587c:	48 83 c4 38          	add    $0x38,%rsp
    5880:	c3                   	ret
    5881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5888:	66 31 d2             	xor    %dx,%dx
    588b:	48 01 d6             	add    %rdx,%rsi
    588e:	48 39 f1             	cmp    %rsi,%rcx
    5891:	0f 85 5d ff ff ff    	jne    57f4 <fwp_mem_free+0x64>
    5897:	49 8b 50 10          	mov    0x10(%r8),%rdx
    589b:	48 29 15 3e c3 01 00 	sub    %rdx,0x1c33e(%rip)        # 21be0 <fwp_heap+0x1420>
    58a2:	48 85 d2             	test   %rdx,%rdx
    58a5:	0f 88 a5 00 00 00    	js     5950 <fwp_mem_free+0x1c0>
    58ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58af:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    58b4:	f2 0f 58 05 44 c3 01 	addsd  0x1c344(%rip),%xmm0        # 21c00 <fwp_heap+0x1440>
    58bb:	00 
    58bc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    58c0:	f2 0f 11 05 38 c3 01 	movsd  %xmm0,0x1c338(%rip)        # 21c00 <fwp_heap+0x1440>
    58c7:	00 
    58c8:	48 85 d2             	test   %rdx,%rdx
    58cb:	74 0c                	je     58d9 <fwp_mem_free+0x149>
    58cd:	80 3a ff             	cmpb   $0xff,(%rdx)
    58d0:	0f 84 db 00 00 00    	je     59b1 <fwp_mem_free+0x221>
    58d6:	c6 02 00             	movb   $0x0,(%rdx)
    58d9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    58dd:	48 85 c9             	test   %rcx,%rcx
    58e0:	74 3e                	je     5920 <fwp_mem_free+0x190>
    58e2:	48 8b 15 cf c2 01 00 	mov    0x1c2cf(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    58e9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    58ed:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    58f1:	48 01 d0             	add    %rdx,%rax
    58f4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    58f8:	48 89 d6             	mov    %rdx,%rsi
    58fb:	48 29 c6             	sub    %rax,%rsi
    58fe:	83 e6 08             	and    $0x8,%esi
    5901:	74 0d                	je     5910 <fwp_mem_free+0x180>
    5903:	c6 00 00             	movb   $0x0,(%rax)
    5906:	48 83 c0 28          	add    $0x28,%rax
    590a:	48 39 c2             	cmp    %rax,%rdx
    590d:	74 11                	je     5920 <fwp_mem_free+0x190>
    590f:	90                   	nop
    5910:	c6 00 00             	movb   $0x0,(%rax)
    5913:	48 83 c0 50          	add    $0x50,%rax
    5917:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    591b:	48 39 c2             	cmp    %rax,%rdx
    591e:	75 f0                	jne    5910 <fwp_mem_free+0x180>
    5920:	48 01 0d c9 c2 01 00 	add    %rcx,0x1c2c9(%rip)        # 21bf0 <fwp_heap+0x1430>
    5927:	4c 3b 0d 82 c2 01 00 	cmp    0x1c282(%rip),%r9        # 21bb0 <fwp_heap+0x13f0>
    592e:	73 07                	jae    5937 <fwp_mem_free+0x1a7>
    5930:	4c 89 0d 79 c2 01 00 	mov    %r9,0x1c279(%rip)        # 21bb0 <fwp_heap+0x13f0>
    5937:	4c 3b 0d 6a c2 01 00 	cmp    0x1c26a(%rip),%r9        # 21ba8 <fwp_heap+0x13e8>
    593e:	0f 83 b0 fe ff ff    	jae    57f4 <fwp_mem_free+0x64>
    5944:	4c 89 0d 5d c2 01 00 	mov    %r9,0x1c25d(%rip)        # 21ba8 <fwp_heap+0x13e8>
    594b:	e9 a4 fe ff ff       	jmp    57f4 <fwp_mem_free+0x64>
    5950:	48 89 d1             	mov    %rdx,%rcx
    5953:	83 e2 01             	and    $0x1,%edx
    5956:	66 0f ef c0          	pxor   %xmm0,%xmm0
    595a:	48 d1 e9             	shr    $1,%rcx
    595d:	48 09 d1             	or     %rdx,%rcx
    5960:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5965:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5969:	e9 46 ff ff ff       	jmp    58b4 <fwp_mem_free+0x124>
    596e:	66 90                	xchg   %ax,%ax
    5970:	4c 89 d7             	mov    %r10,%rdi
    5973:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5978:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    597d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5982:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5986:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    598b:	e8 c0 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    5990:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5995:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    599a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    599f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    59a4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    59a9:	e9 7e fe ff ff       	jmp    582c <fwp_mem_free+0x9c>
    59ae:	66 90                	xchg   %ax,%ax
    59b0:	c3                   	ret
    59b1:	48 89 d7             	mov    %rdx,%rdi
    59b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    59b9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    59be:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    59c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    59c8:	e8 83 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    59cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    59d2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    59d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    59dc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    59e1:	e9 f0 fe ff ff       	jmp    58d6 <fwp_mem_free+0x146>
    59e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    59ed:	00 00 00 

00000000000059f0 <fwp_heap_alloc_big>:
    59f0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    59f7:	00 00 40 
    59fa:	41 57                	push   %r15
    59fc:	41 56                	push   %r14
    59fe:	41 55                	push   %r13
    5a00:	41 54                	push   %r12
    5a02:	55                   	push   %rbp
    5a03:	53                   	push   %rbx
    5a04:	48 83 ec 08          	sub    $0x8,%rsp
    5a08:	48 39 f8             	cmp    %rdi,%rax
    5a0b:	0f 82 fa 00 00 00    	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5a11:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a18:	49 89 fd             	mov    %rdi,%r13
    5a1b:	41 89 f6             	mov    %esi,%r14d
    5a1e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a22:	48 89 ef             	mov    %rbp,%rdi
    5a25:	e8 56 e5 ff ff       	call   3f80 <fwp_heap_chunks>
    5a2a:	be 01 00 00 00       	mov    $0x1,%esi
    5a2f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a33:	49 89 c4             	mov    %rax,%r12
    5a36:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a3d:	00 
    5a3e:	48 03 3d 73 c1 01 00 	add    0x1c173(%rip),%rdi        # 21bb8 <fwp_heap+0x13f8>
    5a45:	c6 07 02             	movb   $0x2,(%rdi)
    5a48:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5a4c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5a4f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5a53:	e8 88 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a58:	48 83 fd 01          	cmp    $0x1,%rbp
    5a5c:	76 47                	jbe    5aa5 <fwp_heap_alloc_big+0xb5>
    5a5e:	4c 01 e5             	add    %r12,%rbp
    5a61:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5a68:	00 
    5a69:	4c 8d 3d 50 ad 01 00 	lea    0x1ad50(%rip),%r15        # 207c0 <fwp_heap>
    5a70:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5a75:	49 c1 e6 03          	shl    $0x3,%r14
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5a87:	31 f6                	xor    %esi,%esi
    5a89:	48 01 dd             	add    %rbx,%rbp
    5a8c:	48 83 c3 28          	add    $0x28,%rbx
    5a90:	48 89 ef             	mov    %rbp,%rdi
    5a93:	e8 48 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a98:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5a9c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5aa0:	49 39 de             	cmp    %rbx,%r14
    5aa3:	75 db                	jne    5a80 <fwp_heap_alloc_big+0x90>
    5aa5:	49 c1 e4 10          	shl    $0x10,%r12
    5aa9:	4c 03 25 c0 c0 01 00 	add    0x1c0c0(%rip),%r12        # 21b70 <fwp_heap+0x13b0>
    5ab0:	4c 89 ea             	mov    %r13,%rdx
    5ab3:	31 f6                	xor    %esi,%esi
    5ab5:	4c 89 e7             	mov    %r12,%rdi
    5ab8:	e8 03 da ff ff       	call   34c0 <memset@plt>
    5abd:	4c 89 e8             	mov    %r13,%rax
    5ac0:	48 03 05 19 c1 01 00 	add    0x1c119(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    5ac7:	72 42                	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5ac9:	48 39 05 18 c1 01 00 	cmp    %rax,0x1c118(%rip)        # 21be8 <fwp_heap+0x1428>
    5ad0:	48 89 05 09 c1 01 00 	mov    %rax,0x1c109(%rip)        # 21be0 <fwp_heap+0x1420>
    5ad7:	73 07                	jae    5ae0 <fwp_heap_alloc_big+0xf0>
    5ad9:	48 89 05 08 c1 01 00 	mov    %rax,0x1c108(%rip)        # 21be8 <fwp_heap+0x1428>
    5ae0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ae4:	4c 89 e0             	mov    %r12,%rax
    5ae7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5aec:	f2 0f 58 05 04 c1 01 	addsd  0x1c104(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    5af3:	00 
    5af4:	f2 0f 11 05 fc c0 01 	movsd  %xmm0,0x1c0fc(%rip)        # 21bf8 <fwp_heap+0x1438>
    5afb:	00 
    5afc:	48 83 c4 08          	add    $0x8,%rsp
    5b00:	5b                   	pop    %rbx
    5b01:	5d                   	pop    %rbp
    5b02:	41 5c                	pop    %r12
    5b04:	41 5d                	pop    %r13
    5b06:	41 5e                	pop    %r14
    5b08:	41 5f                	pop    %r15
    5b0a:	c3                   	ret
    5b0b:	e8 a0 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b10 <fwp_heap_alloc_slow>:
    5b10:	53                   	push   %rbx
    5b11:	48 89 f9             	mov    %rdi,%rcx
    5b14:	41 89 f1             	mov    %esi,%r9d
    5b17:	48 83 ec 10          	sub    $0x10,%rsp
    5b1b:	8b 05 43 c0 01 00    	mov    0x1c043(%rip),%eax        # 21b64 <fwp_heap+0x13a4>
    5b21:	85 c0                	test   %eax,%eax
    5b23:	0f 84 c7 00 00 00    	je     5bf0 <fwp_heap_alloc_slow+0xe0>
    5b29:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b30:	0f 87 dd 00 00 00    	ja     5c13 <fwp_heap_alloc_slow+0x103>
    5b36:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b3a:	48 8d 3d 7f ac 01 00 	lea    0x1ac7f(%rip),%rdi        # 207c0 <fwp_heap>
    5b41:	49 63 f1             	movslq %r9d,%rsi
    5b44:	48 c1 e8 04          	shr    $0x4,%rax
    5b48:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5b4f:	00 00 
    5b51:	41 0f b6 c2          	movzbl %r10b,%eax
    5b55:	4c 89 d2             	mov    %r10,%rdx
    5b58:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5b5c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5b63:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5b6a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5b6e:	48 01 f8             	add    %rdi,%rax
    5b71:	4c 8b 00             	mov    (%rax),%r8
    5b74:	4d 85 c0             	test   %r8,%r8
    5b77:	0f 84 ab 00 00 00    	je     5c28 <fwp_heap_alloc_slow+0x118>
    5b7d:	49 8b 10             	mov    (%r8),%rdx
    5b80:	48 f7 d2             	not    %rdx
    5b83:	48 89 10             	mov    %rdx,(%rax)
    5b86:	41 83 f9 01          	cmp    $0x1,%r9d
    5b8a:	4c 89 c7             	mov    %r8,%rdi
    5b8d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5b91:	31 f6                	xor    %esi,%esi
    5b93:	48 89 ca             	mov    %rcx,%rdx
    5b96:	e8 25 d9 ff ff       	call   34c0 <memset@plt>
    5b9b:	49 89 c0             	mov    %rax,%r8
    5b9e:	48 89 d8             	mov    %rbx,%rax
    5ba1:	48 03 05 38 c0 01 00 	add    0x1c038(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    5ba8:	0f 82 d9 00 00 00    	jb     5c87 <fwp_heap_alloc_slow+0x177>
    5bae:	48 39 05 33 c0 01 00 	cmp    %rax,0x1c033(%rip)        # 21be8 <fwp_heap+0x1428>
    5bb5:	48 89 05 24 c0 01 00 	mov    %rax,0x1c024(%rip)        # 21be0 <fwp_heap+0x1420>
    5bbc:	73 07                	jae    5bc5 <fwp_heap_alloc_slow+0xb5>
    5bbe:	48 89 05 23 c0 01 00 	mov    %rax,0x1c023(%rip)        # 21be8 <fwp_heap+0x1428>
    5bc5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bc9:	4c 89 c0             	mov    %r8,%rax
    5bcc:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5bd1:	f2 0f 58 05 1f c0 01 	addsd  0x1c01f(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    5bd8:	00 
    5bd9:	f2 0f 11 05 17 c0 01 	movsd  %xmm0,0x1c017(%rip)        # 21bf8 <fwp_heap+0x1438>
    5be0:	00 
    5be1:	48 83 c4 10          	add    $0x10,%rsp
    5be5:	5b                   	pop    %rbx
    5be6:	c3                   	ret
    5be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bee:	00 00 
    5bf0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5bf4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5bf8:	e8 73 f1 ff ff       	call   4d70 <fwp_heap_init>
    5bfd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c01:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c06:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c0d:	0f 86 23 ff ff ff    	jbe    5b36 <fwp_heap_alloc_slow+0x26>
    5c13:	48 83 c4 10          	add    $0x10,%rsp
    5c17:	44 89 ce             	mov    %r9d,%esi
    5c1a:	48 89 cf             	mov    %rcx,%rdi
    5c1d:	5b                   	pop    %rbx
    5c1e:	e9 cd fd ff ff       	jmp    59f0 <fwp_heap_alloc_big>
    5c23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c28:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c2c:	4d 85 c0             	test   %r8,%r8
    5c2f:	74 1f                	je     5c50 <fwp_heap_alloc_slow+0x140>
    5c31:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c35:	4d 29 c3             	sub    %r8,%r11
    5c38:	49 39 db             	cmp    %rbx,%r11
    5c3b:	72 13                	jb     5c50 <fwp_heap_alloc_slow+0x140>
    5c3d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5c41:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c45:	e9 3c ff ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c50:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5c57:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5c5b:	44 89 ca             	mov    %r9d,%edx
    5c5e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5c63:	44 89 0c 24          	mov    %r9d,(%rsp)
    5c67:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5c6b:	44 89 d6             	mov    %r10d,%esi
    5c6e:	48 01 c7             	add    %rax,%rdi
    5c71:	e8 6a fa ff ff       	call   56e0 <fwp_heap_refill>
    5c76:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5c7b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5c7f:	49 89 c0             	mov    %rax,%r8
    5c82:	e9 ff fe ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c87:	e8 24 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005c90 <fwp_heap_alloc>:
    5c90:	8b 05 ce be 01 00    	mov    0x1bece(%rip),%eax        # 21b64 <fwp_heap+0x13a4>
    5c96:	48 89 fa             	mov    %rdi,%rdx
    5c99:	89 f7                	mov    %esi,%edi
    5c9b:	85 c0                	test   %eax,%eax
    5c9d:	0f 84 f5 00 00 00    	je     5d98 <fwp_heap_alloc+0x108>
    5ca3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5caa:	0f 87 e8 00 00 00    	ja     5d98 <fwp_heap_alloc+0x108>
    5cb0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5cb4:	48 8d 05 05 ab 01 00 	lea    0x1ab05(%rip),%rax        # 207c0 <fwp_heap>
    5cbb:	48 83 ec 18          	sub    $0x18,%rsp
    5cbf:	41 89 f0             	mov    %esi,%r8d
    5cc2:	48 c1 e9 04          	shr    $0x4,%rcx
    5cc6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5ccd:	00 
    5cce:	48 63 cf             	movslq %edi,%rcx
    5cd1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5cd8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5cdf:	00 
    5ce0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5ce4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5ce8:	48 01 c8             	add    %rcx,%rax
    5ceb:	48 8b 08             	mov    (%rax),%rcx
    5cee:	48 85 c9             	test   %rcx,%rcx
    5cf1:	74 6d                	je     5d60 <fwp_heap_alloc+0xd0>
    5cf3:	48 8b 31             	mov    (%rcx),%rsi
    5cf6:	48 f7 d6             	not    %rsi
    5cf9:	48 89 30             	mov    %rsi,(%rax)
    5cfc:	41 83 f8 01          	cmp    $0x1,%r8d
    5d00:	48 89 cf             	mov    %rcx,%rdi
    5d03:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d08:	49 0f 45 d1          	cmovne %r9,%rdx
    5d0c:	31 f6                	xor    %esi,%esi
    5d0e:	e8 ad d7 ff ff       	call   34c0 <memset@plt>
    5d13:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d18:	48 89 c1             	mov    %rax,%rcx
    5d1b:	4c 89 c8             	mov    %r9,%rax
    5d1e:	48 03 05 bb be 01 00 	add    0x1bebb(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    5d25:	72 7b                	jb     5da2 <fwp_heap_alloc+0x112>
    5d27:	48 39 05 ba be 01 00 	cmp    %rax,0x1beba(%rip)        # 21be8 <fwp_heap+0x1428>
    5d2e:	48 89 05 ab be 01 00 	mov    %rax,0x1beab(%rip)        # 21be0 <fwp_heap+0x1420>
    5d35:	73 07                	jae    5d3e <fwp_heap_alloc+0xae>
    5d37:	48 89 05 aa be 01 00 	mov    %rax,0x1beaa(%rip)        # 21be8 <fwp_heap+0x1428>
    5d3e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d42:	48 89 c8             	mov    %rcx,%rax
    5d45:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5d4a:	f2 0f 58 05 a6 be 01 	addsd  0x1bea6(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    5d51:	00 
    5d52:	f2 0f 11 05 9e be 01 	movsd  %xmm0,0x1be9e(%rip)        # 21bf8 <fwp_heap+0x1438>
    5d59:	00 
    5d5a:	48 83 c4 18          	add    $0x18,%rsp
    5d5e:	c3                   	ret
    5d5f:	90                   	nop
    5d60:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5d64:	48 85 c9             	test   %rcx,%rcx
    5d67:	74 0c                	je     5d75 <fwp_heap_alloc+0xe5>
    5d69:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5d6d:	48 29 ce             	sub    %rcx,%rsi
    5d70:	4c 39 ce             	cmp    %r9,%rsi
    5d73:	73 13                	jae    5d88 <fwp_heap_alloc+0xf8>
    5d75:	89 fe                	mov    %edi,%esi
    5d77:	48 83 c4 18          	add    $0x18,%rsp
    5d7b:	48 89 d7             	mov    %rdx,%rdi
    5d7e:	e9 8d fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5d83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d88:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5d8c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5d90:	e9 67 ff ff ff       	jmp    5cfc <fwp_heap_alloc+0x6c>
    5d95:	0f 1f 00             	nopl   (%rax)
    5d98:	89 fe                	mov    %edi,%esi
    5d9a:	48 89 d7             	mov    %rdx,%rdi
    5d9d:	e9 6e fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5da2:	e8 09 df ff ff       	call   3cb0 <fwp_heap_oom>
    5da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5dae:	00 00 

0000000000005db0 <fwp_data.part.0.constprop.0>:
    5db0:	41 56                	push   %r14
    5db2:	41 89 fe             	mov    %edi,%r14d
    5db5:	41 54                	push   %r12
    5db7:	49 89 f4             	mov    %rsi,%r12
    5dba:	55                   	push   %rbp
    5dbb:	53                   	push   %rbx
    5dbc:	48 83 ec 08          	sub    $0x8,%rsp
    5dc0:	8b 05 9e bd 01 00    	mov    0x1bd9e(%rip),%eax        # 21b64 <fwp_heap+0x13a4>
    5dc6:	85 c0                	test   %eax,%eax
    5dc8:	0f 84 fa 00 00 00    	je     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5dce:	0f b6 05 8d b9 01 00 	movzbl 0x1b98d(%rip),%eax        # 21762 <fwp_heap+0xfa2>
    5dd5:	48 8d 15 e4 a9 01 00 	lea    0x1a9e4(%rip),%rdx        # 207c0 <fwp_heap>
    5ddc:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5de3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5de7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5deb:	48 8b 18             	mov    (%rax),%rbx
    5dee:	48 85 db             	test   %rbx,%rbx
    5df1:	0f 84 a9 00 00 00    	je     5ea0 <fwp_data.part.0.constprop.0+0xf0>
    5df7:	48 8b 13             	mov    (%rbx),%rdx
    5dfa:	48 f7 d2             	not    %rdx
    5dfd:	48 89 10             	mov    %rdx,(%rax)
    5e00:	48 83 fd 18          	cmp    $0x18,%rbp
    5e04:	76 1b                	jbe    5e21 <fwp_data.part.0.constprop.0+0x71>
    5e06:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5e0a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5e0e:	31 f6                	xor    %esi,%esi
    5e10:	48 c1 e8 03          	shr    $0x3,%rax
    5e14:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5e1b:	00 
    5e1c:	e8 9f d6 ff ff       	call   34c0 <memset@plt>
    5e21:	48 89 e8             	mov    %rbp,%rax
    5e24:	48 03 05 b5 bd 01 00 	add    0x1bdb5(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    5e2b:	0f 82 a8 00 00 00    	jb     5ed9 <fwp_data.part.0.constprop.0+0x129>
    5e31:	48 39 05 b0 bd 01 00 	cmp    %rax,0x1bdb0(%rip)        # 21be8 <fwp_heap+0x1428>
    5e38:	48 89 05 a1 bd 01 00 	mov    %rax,0x1bda1(%rip)        # 21be0 <fwp_heap+0x1420>
    5e3f:	73 07                	jae    5e48 <fwp_data.part.0.constprop.0+0x98>
    5e41:	48 89 05 a0 bd 01 00 	mov    %rax,0x1bda0(%rip)        # 21be8 <fwp_heap+0x1428>
    5e48:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e4c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5e51:	f2 0f 58 05 9f bd 01 	addsd  0x1bd9f(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 97 bd 01 	movsd  %xmm0,0x1bd97(%rip)        # 21bf8 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	b8 02 00 00 00       	mov    $0x2,%eax
    5e66:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5e6b:	66 0f 6e c8          	movd   %eax,%xmm1
    5e6f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5e73:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5e77:	49 8b 04 24          	mov    (%r12),%rax
    5e7b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5e7f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5e84:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5e88:	48 83 c4 08          	add    $0x8,%rsp
    5e8c:	48 89 d8             	mov    %rbx,%rax
    5e8f:	5b                   	pop    %rbx
    5e90:	5d                   	pop    %rbp
    5e91:	41 5c                	pop    %r12
    5e93:	41 5e                	pop    %r14
    5e95:	c3                   	ret
    5e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5e9d:	00 00 00 
    5ea0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5ea4:	48 85 db             	test   %rbx,%rbx
    5ea7:	74 1f                	je     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5ea9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5ead:	48 29 da             	sub    %rbx,%rdx
    5eb0:	48 39 ea             	cmp    %rbp,%rdx
    5eb3:	72 13                	jb     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5eb5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5eb9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ebd:	e9 3e ff ff ff       	jmp    5e00 <fwp_data.part.0.constprop.0+0x50>
    5ec2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ec8:	31 f6                	xor    %esi,%esi
    5eca:	bf 18 00 00 00       	mov    $0x18,%edi
    5ecf:	e8 bc fd ff ff       	call   5c90 <fwp_heap_alloc>
    5ed4:	48 89 c3             	mov    %rax,%rbx
    5ed7:	eb 88                	jmp    5e61 <fwp_data.part.0.constprop.0+0xb1>
    5ed9:	e8 d2 dd ff ff       	call   3cb0 <fwp_heap_oom>
    5ede:	66 90                	xchg   %ax,%ax

0000000000005ee0 <fwp_p_ad_push>:
    5ee0:	41 57                	push   %r15
    5ee2:	41 56                	push   %r14
    5ee4:	41 55                	push   %r13
    5ee6:	49 89 d5             	mov    %rdx,%r13
    5ee9:	41 54                	push   %r12
    5eeb:	49 89 fc             	mov    %rdi,%r12
    5eee:	55                   	push   %rbp
    5eef:	53                   	push   %rbx
    5ef0:	48 83 ec 38          	sub    $0x38,%rsp
    5ef4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5ef9:	48 85 ff             	test   %rdi,%rdi
    5efc:	79 09                	jns    5f07 <fwp_p_ad_push+0x27>
    5efe:	48 85 d2             	test   %rdx,%rdx
    5f01:	0f 88 a9 01 00 00    	js     60b0 <fwp_p_ad_push+0x1d0>
    5f07:	48 89 f8             	mov    %rdi,%rax
    5f0a:	48 89 0c 24          	mov    %rcx,(%rsp)
    5f0e:	48 09 d0             	or     %rdx,%rax
    5f11:	0f 89 79 01 00 00    	jns    6090 <fwp_p_ad_push+0x1b0>
    5f17:	48 89 f8             	mov    %rdi,%rax
    5f1a:	48 c1 f8 20          	sar    $0x20,%rax
    5f1e:	48 85 ff             	test   %rdi,%rdi
    5f21:	79 24                	jns    5f47 <fwp_p_ad_push+0x67>
    5f23:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5f28:	48 89 d0             	mov    %rdx,%rax
    5f2b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5f32:	00 
    5f33:	49 89 d4             	mov    %rdx,%r12
    5f36:	48 c1 f8 20          	sar    $0x20,%rax
    5f3a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5f41:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5f47:	48 89 c7             	mov    %rax,%rdi
    5f4a:	e8 81 e7 ff ff       	call   46d0 <fwp_tape_of>
    5f4f:	48 89 c3             	mov    %rax,%rbx
    5f52:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5f57:	0f 85 76 02 00 00    	jne    61d3 <fwp_p_ad_push+0x2f3>
    5f5d:	4c 8b 78 10          	mov    0x10(%rax),%r15
    5f61:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    5f68:	0f 8f 59 02 00 00    	jg     61c7 <fwp_p_ad_push+0x2e7>
    5f6e:	44 89 e0             	mov    %r12d,%eax
    5f71:	4c 39 f8             	cmp    %r15,%rax
    5f74:	0f 8d 41 02 00 00    	jge    61bb <fwp_p_ad_push+0x2db>
    5f7a:	4d 85 ed             	test   %r13,%r13
    5f7d:	78 0c                	js     5f8b <fwp_p_ad_push+0xab>
    5f7f:	44 89 e8             	mov    %r13d,%eax
    5f82:	4c 39 f8             	cmp    %r15,%rax
    5f85:	0f 8d 30 02 00 00    	jge    61bb <fwp_p_ad_push+0x2db>
    5f8b:	4d 89 fe             	mov    %r15,%r14
    5f8e:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5f92:	49 8d 46 01          	lea    0x1(%r14),%rax
    5f96:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5f9c:	0f 87 25 02 00 00    	ja     61c7 <fwp_p_ad_push+0x2e7>
    5fa2:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5fa6:	48 39 e8             	cmp    %rbp,%rax
    5fa9:	0f 8e 31 01 00 00    	jle    60e0 <fwp_p_ad_push+0x200>
    5faf:	48 85 ed             	test   %rbp,%rbp
    5fb2:	b9 40 00 00 00       	mov    $0x40,%ecx
    5fb7:	48 0f 44 e9          	cmove  %rcx,%rbp
    5fbb:	48 39 e8             	cmp    %rbp,%rax
    5fbe:	7e 20                	jle    5fe0 <fwp_p_ad_push+0x100>
    5fc0:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5fc7:	0f 8f 03 01 00 00    	jg     60d0 <fwp_p_ad_push+0x1f0>
    5fcd:	48 01 ed             	add    %rbp,%rbp
    5fd0:	48 39 e8             	cmp    %rbp,%rax
    5fd3:	7f eb                	jg     5fc0 <fwp_p_ad_push+0xe0>
    5fd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5fdc:	00 00 00 00 
    5fe0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5fe7:	00 
    5fe8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5fec:	48 89 c6             	mov    %rax,%rsi
    5fef:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    5ff4:	e8 d7 d5 ff ff       	call   35d0 <realloc@plt>
    5ff9:	48 85 c0             	test   %rax,%rax
    5ffc:	0f 84 dd 01 00 00    	je     61df <fwp_p_ad_push+0x2ff>
    6002:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    6006:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    600a:	48 89 43 20          	mov    %rax,0x20(%rbx)
    600e:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
    6012:	48 89 e9             	mov    %rbp,%rcx
    6015:	48 89 43 28          	mov    %rax,0x28(%rbx)
    6019:	48 c1 e1 04          	shl    $0x4,%rcx
    601d:	48 89 ce             	mov    %rcx,%rsi
    6020:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6025:	e8 a6 d5 ff ff       	call   35d0 <realloc@plt>
    602a:	48 85 c0             	test   %rax,%rax
    602d:	0f 84 ac 01 00 00    	je     61df <fwp_p_ad_push+0x2ff>
    6033:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    6037:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    603c:	4d 85 f6             	test   %r14,%r14
    603f:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6043:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6048:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    604f:	00 
    6050:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    6057:	00 
    6058:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    605c:	4c 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%r8
    6063:	00 
    6064:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6068:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
    606c:	0f 85 e2 00 00 00    	jne    6154 <fwp_p_ad_push+0x274>
    6072:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6076:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    607a:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    607e:	49 01 c8             	add    %rcx,%r8
    6081:	4c 89 43 28          	mov    %r8,0x28(%rbx)
    6085:	eb 79                	jmp    6100 <fwp_p_ad_push+0x220>
    6087:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    608e:	00 00 
    6090:	48 89 d0             	mov    %rdx,%rax
    6093:	48 c1 ff 20          	sar    $0x20,%rdi
    6097:	48 c1 f8 20          	sar    $0x20,%rax
    609b:	48 39 c7             	cmp    %rax,%rdi
    609e:	0f 84 a3 fe ff ff    	je     5f47 <fwp_p_ad_push+0x67>
    60a4:	48 8d 3d 0d 68 00 00 	lea    0x680d(%rip),%rdi        # c8b8 <_IO_stdin_used+0x8b8>
    60ab:	e8 40 e3 ff ff       	call   43f0 <fwp_trap>
    60b0:	48 83 c4 38          	add    $0x38,%rsp
    60b4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    60bb:	5b                   	pop    %rbx
    60bc:	5d                   	pop    %rbp
    60bd:	41 5c                	pop    %r12
    60bf:	41 5d                	pop    %r13
    60c1:	41 5e                	pop    %r14
    60c3:	41 5f                	pop    %r15
    60c5:	c3                   	ret
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    60d5:	e9 06 ff ff ff       	jmp    5fe0 <fwp_p_ad_push+0x100>
    60da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    60e0:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
    60e4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    60e8:	4e 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%r10
    60ef:	00 
    60f0:	4e 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%r9
    60f7:	00 
    60f8:	4c 8b 43 28          	mov    0x28(%rbx),%r8
    60fc:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6100:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6106:	46 89 24 11          	mov    %r12d,(%rcx,%r10,1)
    610a:	4d 85 ed             	test   %r13,%r13
    610d:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6112:	f2 42 0f 11 0c 08    	movsd  %xmm1,(%rax,%r9,1)
    6118:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    611f:	4c 0f 48 e8          	cmovs  %rax,%r13
    6123:	49 8d 47 01          	lea    0x1(%r15),%rax
    6127:	47 89 2c 10          	mov    %r13d,(%r8,%r10,1)
    612b:	f2 42 0f 11 14 0f    	movsd  %xmm2,(%rdi,%r9,1)
    6131:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6135:	48 83 c4 38          	add    $0x38,%rsp
    6139:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6140:	ff ff ff 
    6143:	4c 21 e0             	and    %r12,%rax
    6146:	5b                   	pop    %rbx
    6147:	5d                   	pop    %rbp
    6148:	4c 09 f8             	or     %r15,%rax
    614b:	41 5c                	pop    %r12
    614d:	41 5d                	pop    %r13
    614f:	41 5e                	pop    %r14
    6151:	41 5f                	pop    %r15
    6153:	c3                   	ret
    6154:	48 39 ca             	cmp    %rcx,%rdx
    6157:	49 89 d6             	mov    %rdx,%r14
    615a:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    615f:	48 0f 43 ca          	cmovae %rdx,%rcx
    6163:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    6168:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    616d:	48 29 d1             	sub    %rdx,%rcx
    6170:	4c 89 ca             	mov    %r9,%rdx
    6173:	e8 e8 d3 ff ff       	call   3560 <__memmove_chk@plt>
    6178:	4c 03 73 30          	add    0x30(%rbx),%r14
    617c:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    6181:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6185:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    618a:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    618e:	48 03 7b 20          	add    0x20(%rbx),%rdi
    6192:	4c 89 d2             	mov    %r10,%rdx
    6195:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    619a:	e8 71 d4 ff ff       	call   3610 <memmove@plt>
    619f:	48 8b 43 30          	mov    0x30(%rbx),%rax
    61a3:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    61a7:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    61ac:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    61b1:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    61b6:	e9 bb fe ff ff       	jmp    6076 <fwp_p_ad_push+0x196>
    61bb:	48 8d 3d a5 5f 00 00 	lea    0x5fa5(%rip),%rdi        # c167 <_IO_stdin_used+0x167>
    61c2:	e8 29 e2 ff ff       	call   43f0 <fwp_trap>
    61c7:	48 8d 3d 7e 5f 00 00 	lea    0x5f7e(%rip),%rdi        # c14c <_IO_stdin_used+0x14c>
    61ce:	e8 1d e2 ff ff       	call   43f0 <fwp_trap>
    61d3:	48 8d 3d 26 67 00 00 	lea    0x6726(%rip),%rdi        # c900 <_IO_stdin_used+0x900>
    61da:	e8 11 e2 ff ff       	call   43f0 <fwp_trap>
    61df:	48 89 df             	mov    %rbx,%rdi
    61e2:	e8 19 da ff ff       	call   3c00 <fwp_tape_unlink_scope>
    61e7:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    61eb:	e8 d0 d1 ff ff       	call   33c0 <free@plt>
    61f0:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    61f4:	e8 c7 d1 ff ff       	call   33c0 <free@plt>
    61f9:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    61fd:	e8 be d1 ff ff       	call   33c0 <free@plt>
    6202:	31 c9                	xor    %ecx,%ecx
    6204:	31 c0                	xor    %eax,%eax
    6206:	31 d2                	xor    %edx,%edx
    6208:	89 53 04             	mov    %edx,0x4(%rbx)
    620b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    620f:	ba 13 00 00 00       	mov    $0x13,%edx
    6214:	be 01 00 00 00       	mov    $0x1,%esi
    6219:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    621d:	48 8d 3d e4 5d 00 00 	lea    0x5de4(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    6224:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6228:	48 8b 0d 11 9e 00 00 	mov    0x9e11(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    622f:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6233:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    6237:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    623b:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    623f:	e8 3c d4 ff ff       	call   3680 <fwrite@plt>
    6244:	31 ff                	xor    %edi,%edi
    6246:	e8 75 d3 ff ff       	call   35c0 <fflush@plt>
    624b:	bf 66 00 00 00       	mov    $0x66,%edi
    6250:	e8 4b d4 ff ff       	call   36a0 <_Exit@plt>
    6255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    625c:	00 00 00 00 

0000000000006260 <w120>:
    6260:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6264:	41 55                	push   %r13
    6266:	48 89 fa             	mov    %rdi,%rdx
    6269:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    626d:	41 54                	push   %r12
    626f:	49 89 fc             	mov    %rdi,%r12
    6272:	55                   	push   %rbp
    6273:	53                   	push   %rbx
    6274:	48 89 f3             	mov    %rsi,%rbx
    6277:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    627c:	48 89 f1             	mov    %rsi,%rcx
    627f:	48 83 ec 28          	sub    $0x28,%rsp
    6283:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6289:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    628f:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6295:	e8 46 fc ff ff       	call   5ee0 <fwp_p_ad_push>
    629a:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    62a0:	48 89 da             	mov    %rbx,%rdx
    62a3:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    62a9:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    62b0:	00 f0 3f 
    62b3:	48 89 c7             	mov    %rax,%rdi
    62b6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    62bd:	00 f0 bf 
    62c0:	66 48 0f 7e cd       	movq   %xmm1,%rbp
    62c5:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    62cb:	e8 10 fc ff ff       	call   5ee0 <fwp_p_ad_push>
    62d0:	f2 0f 10 05 c0 68 00 	movsd  0x68c0(%rip),%xmm0        # cb98 <msg.4+0x28>
    62d7:	00 
    62d8:	4c 89 e7             	mov    %r12,%rdi
    62db:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    62e1:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    62e8:	00 f0 3f 
    62eb:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    62f2:	49 89 c5             	mov    %rax,%r13
    62f5:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    62fc:	00 f0 bf 
    62ff:	66 48 0f 7e c3       	movq   %xmm0,%rbx
    6304:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    630a:	e8 d1 fb ff ff       	call   5ee0 <fwp_p_ad_push>
    630f:	48 89 e9             	mov    %rbp,%rcx
    6312:	4c 89 ea             	mov    %r13,%rdx
    6315:	48 89 ee             	mov    %rbp,%rsi
    6318:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    631e:	4c 89 ef             	mov    %r13,%rdi
    6321:	49 89 c4             	mov    %rax,%r12
    6324:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6328:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    632e:	e8 ad fb ff ff       	call   5ee0 <fwp_p_ad_push>
    6333:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    6339:	f2 0f 59 1d 5f 68 00 	mulsd  0x685f(%rip),%xmm3        # cba0 <msg.4+0x30>
    6340:	00 
    6341:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    6348:	00 59 40 
    634b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6350:	48 89 c2             	mov    %rax,%rdx
    6353:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    635a:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6360:	e8 7b fb ff ff       	call   5ee0 <fwp_p_ad_push>
    6365:	48 89 d9             	mov    %rbx,%rcx
    6368:	4c 89 e2             	mov    %r12,%rdx
    636b:	48 89 de             	mov    %rbx,%rsi
    636e:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6374:	4c 89 e7             	mov    %r12,%rdi
    6377:	48 89 c5             	mov    %rax,%rbp
    637a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    637e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6384:	e8 57 fb ff ff       	call   5ee0 <fwp_p_ad_push>
    6389:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    638f:	48 89 ea             	mov    %rbp,%rdx
    6392:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    6398:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    639f:	00 f0 3f 
    63a2:	48 89 c7             	mov    %rax,%rdi
    63a5:	48 89 ce             	mov    %rcx,%rsi
    63a8:	66 48 0f 7e db       	movq   %xmm3,%rbx
    63ad:	e8 2e fb ff ff       	call   5ee0 <fwp_p_ad_push>
    63b2:	48 83 c4 28          	add    $0x28,%rsp
    63b6:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    63bb:	5b                   	pop    %rbx
    63bc:	5d                   	pop    %rbp
    63bd:	41 5c                	pop    %r12
    63bf:	41 5d                	pop    %r13
    63c1:	c3                   	ret
    63c2:	0f 1f 00             	nopl   (%rax)
    63c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    63cc:	00 00 00 00 

00000000000063d0 <fwp_rc_share>:
    63d0:	48 8b 05 c1 b7 01 00 	mov    0x1b7c1(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    63d7:	48 2b 3d 92 b7 01 00 	sub    0x1b792(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    63de:	48 c1 e0 10          	shl    $0x10,%rax
    63e2:	48 39 c7             	cmp    %rax,%rdi
    63e5:	73 4a                	jae    6431 <fwp_rc_share+0x61>
    63e7:	48 89 f8             	mov    %rdi,%rax
    63ea:	48 c1 e8 10          	shr    $0x10,%rax
    63ee:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    63f2:	48 8b 05 bf b7 01 00 	mov    0x1b7bf(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    63f9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    63fd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6401:	48 85 d2             	test   %rdx,%rdx
    6404:	74 2b                	je     6431 <fwp_rc_share+0x61>
    6406:	0f b6 08             	movzbl (%rax),%ecx
    6409:	80 f9 02             	cmp    $0x2,%cl
    640c:	74 2a                	je     6438 <fwp_rc_share+0x68>
    640e:	80 f9 01             	cmp    $0x1,%cl
    6411:	75 1e                	jne    6431 <fwp_rc_share+0x61>
    6413:	8b 48 18             	mov    0x18(%rax),%ecx
    6416:	0f b7 ff             	movzwl %di,%edi
    6419:	8b 40 1c             	mov    0x1c(%rax),%eax
    641c:	48 0f af f9          	imul   %rcx,%rdi
    6420:	48 c1 ef 20          	shr    $0x20,%rdi
    6424:	48 39 c7             	cmp    %rax,%rdi
    6427:	73 08                	jae    6431 <fwp_rc_share+0x61>
    6429:	48 01 fa             	add    %rdi,%rdx
    642c:	80 3a 00             	cmpb   $0x0,(%rdx)
    642f:	75 0d                	jne    643e <fwp_rc_share+0x6e>
    6431:	c3                   	ret
    6432:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6438:	66 85 ff             	test   %di,%di
    643b:	74 ef                	je     642c <fwp_rc_share+0x5c>
    643d:	c3                   	ret
    643e:	50                   	push   %rax
    643f:	48 8d 3d ea 64 00 00 	lea    0x64ea(%rip),%rdi        # c930 <_IO_stdin_used+0x930>
    6446:	e8 a5 df ff ff       	call   43f0 <fwp_trap>
    644b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006450 <fwp_rc_free_obj>:
    6450:	48 8b 15 41 b7 01 00 	mov    0x1b741(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    6457:	48 89 f8             	mov    %rdi,%rax
    645a:	48 2b 05 0f b7 01 00 	sub    0x1b70f(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    6461:	48 c1 e2 10          	shl    $0x10,%rdx
    6465:	48 39 d0             	cmp    %rdx,%rax
    6468:	73 5b                	jae    64c5 <fwp_rc_free_obj+0x75>
    646a:	48 89 c2             	mov    %rax,%rdx
    646d:	48 c1 ea 10          	shr    $0x10,%rdx
    6471:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6475:	48 8b 15 3c b7 01 00 	mov    0x1b73c(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    647c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6480:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6484:	48 85 c9             	test   %rcx,%rcx
    6487:	74 3c                	je     64c5 <fwp_rc_free_obj+0x75>
    6489:	0f b6 32             	movzbl (%rdx),%esi
    648c:	40 80 fe 02          	cmp    $0x2,%sil
    6490:	74 2e                	je     64c0 <fwp_rc_free_obj+0x70>
    6492:	40 80 fe 01          	cmp    $0x1,%sil
    6496:	75 2d                	jne    64c5 <fwp_rc_free_obj+0x75>
    6498:	8b 72 18             	mov    0x18(%rdx),%esi
    649b:	0f b7 c0             	movzwl %ax,%eax
    649e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    64a1:	48 0f af c6          	imul   %rsi,%rax
    64a5:	48 c1 e8 20          	shr    $0x20,%rax
    64a9:	48 39 d0             	cmp    %rdx,%rax
    64ac:	73 17                	jae    64c5 <fwp_rc_free_obj+0x75>
    64ae:	48 01 c1             	add    %rax,%rcx
    64b1:	80 39 01             	cmpb   $0x1,(%rcx)
    64b4:	75 0f                	jne    64c5 <fwp_rc_free_obj+0x75>
    64b6:	e9 d5 f2 ff ff       	jmp    5790 <fwp_mem_free>
    64bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    64c0:	66 85 c0             	test   %ax,%ax
    64c3:	74 ec                	je     64b1 <fwp_rc_free_obj+0x61>
    64c5:	c3                   	ret
    64c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    64cd:	00 00 00 

00000000000064d0 <fwp_rc_dup>:
    64d0:	f3 0f 1e fa          	endbr64
    64d4:	48 8b 05 bd b6 01 00 	mov    0x1b6bd(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    64db:	48 2b 3d 8e b6 01 00 	sub    0x1b68e(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    64e2:	48 c1 e0 10          	shl    $0x10,%rax
    64e6:	48 39 c7             	cmp    %rax,%rdi
    64e9:	73 56                	jae    6541 <fwp_rc_dup+0x71>
    64eb:	48 89 f8             	mov    %rdi,%rax
    64ee:	48 c1 e8 10          	shr    $0x10,%rax
    64f2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    64f6:	48 8b 05 bb b6 01 00 	mov    0x1b6bb(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    64fd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6501:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6505:	48 85 c0             	test   %rax,%rax
    6508:	74 37                	je     6541 <fwp_rc_dup+0x71>
    650a:	0f b6 0a             	movzbl (%rdx),%ecx
    650d:	80 f9 02             	cmp    $0x2,%cl
    6510:	74 36                	je     6548 <fwp_rc_dup+0x78>
    6512:	80 f9 01             	cmp    $0x1,%cl
    6515:	75 2a                	jne    6541 <fwp_rc_dup+0x71>
    6517:	8b 4a 18             	mov    0x18(%rdx),%ecx
    651a:	0f b7 ff             	movzwl %di,%edi
    651d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6520:	48 0f af f9          	imul   %rcx,%rdi
    6524:	48 c1 ef 20          	shr    $0x20,%rdi
    6528:	48 39 d7             	cmp    %rdx,%rdi
    652b:	73 14                	jae    6541 <fwp_rc_dup+0x71>
    652d:	48 01 f8             	add    %rdi,%rax
    6530:	0f b6 10             	movzbl (%rax),%edx
    6533:	84 d2                	test   %dl,%dl
    6535:	74 0a                	je     6541 <fwp_rc_dup+0x71>
    6537:	80 fa fd             	cmp    $0xfd,%dl
    653a:	77 14                	ja     6550 <fwp_rc_dup+0x80>
    653c:	83 c2 01             	add    $0x1,%edx
    653f:	88 10                	mov    %dl,(%rax)
    6541:	c3                   	ret
    6542:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6548:	66 85 ff             	test   %di,%di
    654b:	74 e3                	je     6530 <fwp_rc_dup+0x60>
    654d:	c3                   	ret
    654e:	66 90                	xchg   %ax,%ax
    6550:	48 89 c7             	mov    %rax,%rdi
    6553:	e9 d8 ee ff ff       	jmp    5430 <fwp_rc_wide_dup>
    6558:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    655f:	00 

0000000000006560 <fwp_owned_entry173>:
    6560:	f3 0f 1e fa          	endbr64
    6564:	48 83 ec 38          	sub    $0x38,%rsp
    6568:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    656d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6574:	00 00 
    6576:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    657b:	31 c0                	xor    %eax,%eax
    657d:	48 8b 07             	mov    (%rdi),%rax
    6580:	48 03 47 10          	add    0x10(%rdi),%rax
    6584:	0f 80 c2 00 00 00    	jo     664c <fwp_owned_entry173+0xec>
    658a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    658f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6594:	31 ff                	xor    %edi,%edi
    6596:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    659a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    659f:	e8 0c f8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    65a4:	48 8b 15 ed b5 01 00 	mov    0x1b5ed(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    65ab:	48 89 c6             	mov    %rax,%rsi
    65ae:	48 2b 05 bb b5 01 00 	sub    0x1b5bb(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    65b5:	48 c1 e2 10          	shl    $0x10,%rdx
    65b9:	48 39 d0             	cmp    %rdx,%rax
    65bc:	73 4f                	jae    660d <fwp_owned_entry173+0xad>
    65be:	48 89 c2             	mov    %rax,%rdx
    65c1:	48 c1 ea 10          	shr    $0x10,%rdx
    65c5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    65c9:	48 8b 15 e8 b5 01 00 	mov    0x1b5e8(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    65d0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    65d4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    65d8:	48 85 d2             	test   %rdx,%rdx
    65db:	74 30                	je     660d <fwp_owned_entry173+0xad>
    65dd:	0f b6 39             	movzbl (%rcx),%edi
    65e0:	40 80 ff 02          	cmp    $0x2,%dil
    65e4:	74 42                	je     6628 <fwp_owned_entry173+0xc8>
    65e6:	40 80 ff 01          	cmp    $0x1,%dil
    65ea:	75 21                	jne    660d <fwp_owned_entry173+0xad>
    65ec:	8b 79 18             	mov    0x18(%rcx),%edi
    65ef:	0f b7 c0             	movzwl %ax,%eax
    65f2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    65f5:	48 0f af c7          	imul   %rdi,%rax
    65f9:	48 c1 e8 20          	shr    $0x20,%rax
    65fd:	48 39 c8             	cmp    %rcx,%rax
    6600:	73 0b                	jae    660d <fwp_owned_entry173+0xad>
    6602:	48 01 c2             	add    %rax,%rdx
    6605:	80 3a ff             	cmpb   $0xff,(%rdx)
    6608:	74 26                	je     6630 <fwp_owned_entry173+0xd0>
    660a:	c6 02 01             	movb   $0x1,(%rdx)
    660d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6612:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6619:	00 00 
    661b:	75 34                	jne    6651 <fwp_owned_entry173+0xf1>
    661d:	48 89 f0             	mov    %rsi,%rax
    6620:	48 83 c4 38          	add    $0x38,%rsp
    6624:	c3                   	ret
    6625:	0f 1f 00             	nopl   (%rax)
    6628:	66 85 c0             	test   %ax,%ax
    662b:	75 e0                	jne    660d <fwp_owned_entry173+0xad>
    662d:	eb d6                	jmp    6605 <fwp_owned_entry173+0xa5>
    662f:	90                   	nop
    6630:	48 89 d7             	mov    %rdx,%rdi
    6633:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6638:	48 89 14 24          	mov    %rdx,(%rsp)
    663c:	e8 0f ef ff ff       	call   5550 <fwp_rc_forget_slot>
    6641:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6646:	48 8b 14 24          	mov    (%rsp),%rdx
    664a:	eb be                	jmp    660a <fwp_owned_entry173+0xaa>
    664c:	e8 af d0 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6651:	e8 0a ce ff ff       	call   3460 <__stack_chk_fail@plt>
    6656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    665d:	00 00 00 

0000000000006660 <e173>:
    6660:	f3 0f 1e fa          	endbr64
    6664:	53                   	push   %rbx
    6665:	48 83 ec 30          	sub    $0x30,%rsp
    6669:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    666e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6675:	00 00 
    6677:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    667c:	31 c0                	xor    %eax,%eax
    667e:	48 8b 07             	mov    (%rdi),%rax
    6681:	48 03 47 10          	add    0x10(%rdi),%rax
    6685:	0f 80 c9 00 00 00    	jo     6754 <e173+0xf4>
    668b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6690:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6695:	31 ff                	xor    %edi,%edi
    6697:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    669b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    66a0:	e8 0b f7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    66a5:	48 8b 15 ec b4 01 00 	mov    0x1b4ec(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    66ac:	48 89 c3             	mov    %rax,%rbx
    66af:	48 2b 05 ba b4 01 00 	sub    0x1b4ba(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    66b6:	48 c1 e2 10          	shl    $0x10,%rdx
    66ba:	48 39 d0             	cmp    %rdx,%rax
    66bd:	73 4f                	jae    670e <e173+0xae>
    66bf:	48 89 c2             	mov    %rax,%rdx
    66c2:	48 c1 ea 10          	shr    $0x10,%rdx
    66c6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    66ca:	48 8b 15 e7 b4 01 00 	mov    0x1b4e7(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    66d1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    66d5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    66d9:	48 85 d2             	test   %rdx,%rdx
    66dc:	74 30                	je     670e <e173+0xae>
    66de:	0f b6 31             	movzbl (%rcx),%esi
    66e1:	40 80 fe 02          	cmp    $0x2,%sil
    66e5:	74 49                	je     6730 <e173+0xd0>
    66e7:	40 80 fe 01          	cmp    $0x1,%sil
    66eb:	75 21                	jne    670e <e173+0xae>
    66ed:	8b 71 18             	mov    0x18(%rcx),%esi
    66f0:	0f b7 c0             	movzwl %ax,%eax
    66f3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    66f6:	48 0f af c6          	imul   %rsi,%rax
    66fa:	48 c1 e8 20          	shr    $0x20,%rax
    66fe:	48 39 c8             	cmp    %rcx,%rax
    6701:	73 0b                	jae    670e <e173+0xae>
    6703:	48 01 c2             	add    %rax,%rdx
    6706:	80 3a ff             	cmpb   $0xff,(%rdx)
    6709:	74 35                	je     6740 <e173+0xe0>
    670b:	c6 02 01             	movb   $0x1,(%rdx)
    670e:	48 89 df             	mov    %rbx,%rdi
    6711:	e8 ba fc ff ff       	call   63d0 <fwp_rc_share>
    6716:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    671b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6722:	00 00 
    6724:	75 33                	jne    6759 <e173+0xf9>
    6726:	48 83 c4 30          	add    $0x30,%rsp
    672a:	48 89 d8             	mov    %rbx,%rax
    672d:	5b                   	pop    %rbx
    672e:	c3                   	ret
    672f:	90                   	nop
    6730:	66 85 c0             	test   %ax,%ax
    6733:	75 d9                	jne    670e <e173+0xae>
    6735:	eb cf                	jmp    6706 <e173+0xa6>
    6737:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    673e:	00 00 
    6740:	48 89 d7             	mov    %rdx,%rdi
    6743:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6748:	e8 03 ee ff ff       	call   5550 <fwp_rc_forget_slot>
    674d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6752:	eb b7                	jmp    670b <e173+0xab>
    6754:	e8 a7 cf ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6759:	e8 02 cd ff ff       	call   3460 <__stack_chk_fail@plt>
    675e:	66 90                	xchg   %ax,%ax

0000000000006760 <fwp_closure_drop>:
    6760:	48 8b 15 31 b4 01 00 	mov    0x1b431(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    6767:	48 89 f8             	mov    %rdi,%rax
    676a:	48 2b 05 ff b3 01 00 	sub    0x1b3ff(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    6771:	48 c1 e2 10          	shl    $0x10,%rdx
    6775:	48 39 d0             	cmp    %rdx,%rax
    6778:	73 6b                	jae    67e5 <fwp_closure_drop+0x85>
    677a:	48 89 c2             	mov    %rax,%rdx
    677d:	48 c1 ea 10          	shr    $0x10,%rdx
    6781:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6785:	48 8b 15 2c b4 01 00 	mov    0x1b42c(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    678c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6790:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6794:	48 85 d2             	test   %rdx,%rdx
    6797:	74 4c                	je     67e5 <fwp_closure_drop+0x85>
    6799:	0f b6 31             	movzbl (%rcx),%esi
    679c:	40 80 fe 02          	cmp    $0x2,%sil
    67a0:	74 3e                	je     67e0 <fwp_closure_drop+0x80>
    67a2:	40 80 fe 01          	cmp    $0x1,%sil
    67a6:	75 3d                	jne    67e5 <fwp_closure_drop+0x85>
    67a8:	8b 71 18             	mov    0x18(%rcx),%esi
    67ab:	0f b7 c0             	movzwl %ax,%eax
    67ae:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    67b1:	48 0f af c6          	imul   %rsi,%rax
    67b5:	48 c1 e8 20          	shr    $0x20,%rax
    67b9:	48 39 c8             	cmp    %rcx,%rax
    67bc:	73 27                	jae    67e5 <fwp_closure_drop+0x85>
    67be:	48 01 c2             	add    %rax,%rdx
    67c1:	0f b6 02             	movzbl (%rdx),%eax
    67c4:	84 c0                	test   %al,%al
    67c6:	74 1d                	je     67e5 <fwp_closure_drop+0x85>
    67c8:	3c 01                	cmp    $0x1,%al
    67ca:	74 24                	je     67f0 <fwp_closure_drop+0x90>
    67cc:	3c ff                	cmp    $0xff,%al
    67ce:	74 48                	je     6818 <fwp_closure_drop+0xb8>
    67d0:	83 e8 01             	sub    $0x1,%eax
    67d3:	88 02                	mov    %al,(%rdx)
    67d5:	c3                   	ret
    67d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    67dd:	00 00 00 
    67e0:	66 85 c0             	test   %ax,%ax
    67e3:	74 dc                	je     67c1 <fwp_closure_drop+0x61>
    67e5:	c3                   	ret
    67e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    67ed:	00 00 00 
    67f0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    67f7:	ff ff 
    67f9:	48 85 c0             	test   %rax,%rax
    67fc:	74 12                	je     6810 <fwp_closure_drop+0xb0>
    67fe:	48 89 fe             	mov    %rdi,%rsi
    6801:	48 89 c7             	mov    %rax,%rdi
    6804:	e9 47 dc ff ff       	jmp    4450 <fwp_closure_drop_push>
    6809:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6810:	e9 eb dd ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    6815:	0f 1f 00             	nopl   (%rax)
    6818:	48 89 d0             	mov    %rdx,%rax
    681b:	48 8d 35 9e 9f 01 00 	lea    0x19f9e(%rip),%rsi        # 207c0 <fwp_heap>
    6822:	48 83 ec 18          	sub    $0x18,%rsp
    6826:	48 c1 e8 11          	shr    $0x11,%rax
    682a:	48 31 d0             	xor    %rdx,%rax
    682d:	48 89 c1             	mov    %rax,%rcx
    6830:	48 c1 e9 09          	shr    $0x9,%rcx
    6834:	48 31 c8             	xor    %rcx,%rax
    6837:	0f b6 c8             	movzbl %al,%ecx
    683a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6841:	00 
    6842:	48 85 c0             	test   %rax,%rax
    6845:	75 22                	jne    6869 <fwp_closure_drop+0x109>
    6847:	eb 59                	jmp    68a2 <fwp_closure_drop+0x142>
    6849:	90                   	nop
    684a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6851:	00 00 00 00 
    6855:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    685c:	00 00 00 00 
    6860:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6864:	48 85 c0             	test   %rax,%rax
    6867:	74 39                	je     68a2 <fwp_closure_drop+0x142>
    6869:	48 89 c1             	mov    %rax,%rcx
    686c:	48 39 10             	cmp    %rdx,(%rax)
    686f:	75 ef                	jne    6860 <fwp_closure_drop+0x100>
    6871:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6875:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6879:	48 89 48 08          	mov    %rcx,0x8(%rax)
    687d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6884:	74 05                	je     688b <fwp_closure_drop+0x12b>
    6886:	48 83 c4 18          	add    $0x18,%rsp
    688a:	c3                   	ret
    688b:	48 89 d7             	mov    %rdx,%rdi
    688e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6893:	e8 b8 ec ff ff       	call   5550 <fwp_rc_forget_slot>
    6898:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    689d:	c6 02 fe             	movb   $0xfe,(%rdx)
    68a0:	eb e4                	jmp    6886 <fwp_closure_drop+0x126>
    68a2:	48 8d 3d e7 5f 00 00 	lea    0x5fe7(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    68a9:	e8 42 db ff ff       	call   43f0 <fwp_trap>
    68ae:	66 90                	xchg   %ax,%ax

00000000000068b0 <fwp_owned_tape_release>:
    68b0:	48 85 ff             	test   %rdi,%rdi
    68b3:	0f 84 f7 00 00 00    	je     69b0 <fwp_owned_tape_release+0x100>
    68b9:	41 54                	push   %r12
    68bb:	55                   	push   %rbp
    68bc:	53                   	push   %rbx
    68bd:	48 8b 07             	mov    (%rdi),%rax
    68c0:	48 85 c0             	test   %rax,%rax
    68c3:	74 08                	je     68cd <fwp_owned_tape_release+0x1d>
    68c5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    68c9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    68cd:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    68d1:	48 85 d2             	test   %rdx,%rdx
    68d4:	74 03                	je     68d9 <fwp_owned_tape_release+0x29>
    68d6:	48 89 02             	mov    %rax,(%rdx)
    68d9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    68dd:	48 89 fb             	mov    %rdi,%rbx
    68e0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    68e4:	48 85 c0             	test   %rax,%rax
    68e7:	0f 84 89 00 00 00    	je     6976 <fwp_owned_tape_release+0xc6>
    68ed:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    68f1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    68f5:	7e 47                	jle    693e <fwp_owned_tape_release+0x8e>
    68f7:	31 ed                	xor    %ebp,%ebp
    68f9:	eb 0d                	jmp    6908 <fwp_owned_tape_release+0x58>
    68fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6900:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6904:	48 8b 40 68          	mov    0x68(%rax),%rax
    6908:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    690c:	49 89 ec             	mov    %rbp,%r12
    690f:	48 83 c5 01          	add    $0x1,%rbp
    6913:	49 c1 e4 04          	shl    $0x4,%r12
    6917:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    691b:	ff d0                	call   *%rax
    691d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6921:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6926:	48 8b 43 10          	mov    0x10(%rbx),%rax
    692a:	ff 50 68             	call   *0x68(%rax)
    692d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6931:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6935:	48 39 e8             	cmp    %rbp,%rax
    6938:	7f c6                	jg     6900 <fwp_owned_tape_release+0x50>
    693a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    693e:	31 ed                	xor    %ebp,%ebp
    6940:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6945:	7e 28                	jle    696f <fwp_owned_tape_release+0xbf>
    6947:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    694e:	00 00 
    6950:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6954:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6958:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    695c:	74 07                	je     6965 <fwp_owned_tape_release+0xb5>
    695e:	ff 52 68             	call   *0x68(%rdx)
    6961:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6965:	48 83 c5 01          	add    $0x1,%rbp
    6969:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    696d:	7f e1                	jg     6950 <fwp_owned_tape_release+0xa0>
    696f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6973:	ff 52 68             	call   *0x68(%rdx)
    6976:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    697a:	e8 e1 fd ff ff       	call   6760 <fwp_closure_drop>
    697f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6983:	e8 d8 fd ff ff       	call   6760 <fwp_closure_drop>
    6988:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    698c:	e8 cf fd ff ff       	call   6760 <fwp_closure_drop>
    6991:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6995:	e8 f6 ed ff ff       	call   5790 <fwp_mem_free>
    699a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    699e:	e8 ed ed ff ff       	call   5790 <fwp_mem_free>
    69a3:	48 89 df             	mov    %rbx,%rdi
    69a6:	5b                   	pop    %rbx
    69a7:	5d                   	pop    %rbp
    69a8:	41 5c                	pop    %r12
    69aa:	e9 e1 ed ff ff       	jmp    5790 <fwp_mem_free>
    69af:	90                   	nop
    69b0:	c3                   	ret
    69b1:	0f 1f 40 00          	nopl   0x0(%rax)
    69b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    69bc:	00 00 00 00 

00000000000069c0 <fwp_tape_finish>:
    69c0:	f3 0f 1e fa          	endbr64
    69c4:	41 56                	push   %r14
    69c6:	48 8d 3d d3 96 01 00 	lea    0x196d3(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    69cd:	41 55                	push   %r13
    69cf:	41 54                	push   %r12
    69d1:	55                   	push   %rbp
    69d2:	53                   	push   %rbx
    69d3:	e8 38 d7 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    69d8:	48 83 3d 08 97 01 00 	cmpq   $0x0,0x19708(%rip)        # 200e8 <fwp_ntapes>
    69df:	00 
    69e0:	48 c7 05 9d 96 01 00 	movq   $0x0,0x1969d(%rip)        # 20088 <fwp_tape_cached_bytes>
    69e7:	00 00 00 00 
    69eb:	7e 68                	jle    6a55 <fwp_tape_finish+0x95>
    69ed:	45 31 e4             	xor    %r12d,%r12d
    69f0:	31 ed                	xor    %ebp,%ebp
    69f2:	0f 1f 00             	nopl   (%rax)
    69f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    69fc:	00 00 00 00 
    6a00:	48 8b 1d e9 96 01 00 	mov    0x196e9(%rip),%rbx        # 200f0 <fwp_tapes>
    6a07:	48 83 c5 01          	add    $0x1,%rbp
    6a0b:	4c 01 e3             	add    %r12,%rbx
    6a0e:	49 83 c4 68          	add    $0x68,%r12
    6a12:	48 89 df             	mov    %rbx,%rdi
    6a15:	e8 e6 d1 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6a1a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6a1e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6a22:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6a26:	e8 95 c9 ff ff       	call   33c0 <free@plt>
    6a2b:	4c 89 f7             	mov    %r14,%rdi
    6a2e:	e8 8d c9 ff ff       	call   33c0 <free@plt>
    6a33:	4c 89 ef             	mov    %r13,%rdi
    6a36:	e8 85 c9 ff ff       	call   33c0 <free@plt>
    6a3b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6a3f:	e8 6c fe ff ff       	call   68b0 <fwp_owned_tape_release>
    6a44:	48 39 2d 9d 96 01 00 	cmp    %rbp,0x1969d(%rip)        # 200e8 <fwp_ntapes>
    6a4b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6a52:	00 
    6a53:	7f ab                	jg     6a00 <fwp_tape_finish+0x40>
    6a55:	48 8b 3d 94 96 01 00 	mov    0x19694(%rip),%rdi        # 200f0 <fwp_tapes>
    6a5c:	e8 5f c9 ff ff       	call   33c0 <free@plt>
    6a61:	5b                   	pop    %rbx
    6a62:	5d                   	pop    %rbp
    6a63:	48 c7 05 82 96 01 00 	movq   $0x0,0x19682(%rip)        # 200f0 <fwp_tapes>
    6a6a:	00 00 00 00 
    6a6e:	48 c7 05 67 96 01 00 	movq   $0x0,0x19667(%rip)        # 200e0 <fwp_tapes_cap>
    6a75:	00 00 00 00 
    6a79:	41 5c                	pop    %r12
    6a7b:	48 c7 05 62 96 01 00 	movq   $0x0,0x19662(%rip)        # 200e8 <fwp_ntapes>
    6a82:	00 00 00 00 
    6a86:	41 5d                	pop    %r13
    6a88:	48 c7 05 45 96 01 00 	movq   $0x0,0x19645(%rip)        # 200d8 <fwp_tape_next_slot>
    6a8f:	00 00 00 00 
    6a93:	41 5e                	pop    %r14
    6a95:	c3                   	ret
    6a96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a9d:	00 00 00 

0000000000006aa0 <fwp_tape_scope_release>:
    6aa0:	f3 0f 1e fa          	endbr64
    6aa4:	41 55                	push   %r13
    6aa6:	41 54                	push   %r12
    6aa8:	55                   	push   %rbp
    6aa9:	53                   	push   %rbx
    6aaa:	48 83 ec 58          	sub    $0x58,%rsp
    6aae:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6ab5:	00 00 
    6ab7:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6abc:	48 63 07             	movslq (%rdi),%rax
    6abf:	85 c0                	test   %eax,%eax
    6ac1:	0f 88 05 01 00 00    	js     6bcc <fwp_tape_scope_release+0x12c>
    6ac7:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6ace:	ec c4 4e 
    6ad1:	48 89 fb             	mov    %rdi,%rbx
    6ad4:	eb 3c                	jmp    6b12 <fwp_tape_scope_release+0x72>
    6ad6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6add:	00 00 00 
    6ae0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6ae5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6ae9:	e8 d2 c8 ff ff       	call   33c0 <free@plt>
    6aee:	48 8b 3c 24          	mov    (%rsp),%rdi
    6af2:	e8 c9 c8 ff ff       	call   33c0 <free@plt>
    6af7:	4c 89 ef             	mov    %r13,%rdi
    6afa:	e8 c1 c8 ff ff       	call   33c0 <free@plt>
    6aff:	4c 89 e7             	mov    %r12,%rdi
    6b02:	e8 a9 fd ff ff       	call   68b0 <fwp_owned_tape_release>
    6b07:	48 63 03             	movslq (%rbx),%rax
    6b0a:	85 c0                	test   %eax,%eax
    6b0c:	0f 88 ba 00 00 00    	js     6bcc <fwp_tape_scope_release+0x12c>
    6b12:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6b16:	48 8b 35 d3 95 01 00 	mov    0x195d3(%rip),%rsi        # 200f0 <fwp_tapes>
    6b1d:	4c 01 c6             	add    %r8,%rsi
    6b20:	48 89 f7             	mov    %rsi,%rdi
    6b23:	e8 d8 d0 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6b28:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6b2d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6b32:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6b39:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6b3d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6b41:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6b48:	00 
    6b49:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6b4e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6b52:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6b57:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6b5b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6b60:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6b67:	00 
    6b68:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6b6f:	00 
    6b70:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6b77:	00 
    6b78:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6b7d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6b82:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6b86:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6b8a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6b8e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6b94:	77 18                	ja     6bae <fwp_tape_scope_release+0x10e>
    6b96:	49 c1 f8 03          	sar    $0x3,%r8
    6b9a:	4c 0f af c5          	imul   %rbp,%r8
    6b9e:	4c 3b 05 33 95 01 00 	cmp    0x19533(%rip),%r8        # 200d8 <fwp_tape_next_slot>
    6ba5:	7d 07                	jge    6bae <fwp_tape_scope_release+0x10e>
    6ba7:	4c 89 05 2a 95 01 00 	mov    %r8,0x1952a(%rip)        # 200d8 <fwp_tape_next_slot>
    6bae:	4d 85 e4             	test   %r12,%r12
    6bb1:	0f 85 29 ff ff ff    	jne    6ae0 <fwp_tape_scope_release+0x40>
    6bb7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6bbc:	e8 af e4 ff ff       	call   5070 <fwp_tape_buffers_release>
    6bc1:	48 63 03             	movslq (%rbx),%rax
    6bc4:	85 c0                	test   %eax,%eax
    6bc6:	0f 89 46 ff ff ff    	jns    6b12 <fwp_tape_scope_release+0x72>
    6bcc:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6bd1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6bd8:	00 00 
    6bda:	75 0b                	jne    6be7 <fwp_tape_scope_release+0x147>
    6bdc:	48 83 c4 58          	add    $0x58,%rsp
    6be0:	5b                   	pop    %rbx
    6be1:	5d                   	pop    %rbp
    6be2:	41 5c                	pop    %r12
    6be4:	41 5d                	pop    %r13
    6be6:	c3                   	ret
    6be7:	e8 74 c8 ff ff       	call   3460 <__stack_chk_fail@plt>
    6bec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006bf0 <fwp_drop4>:
    6bf0:	48 8b 0d a1 af 01 00 	mov    0x1afa1(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    6bf7:	48 89 f8             	mov    %rdi,%rax
    6bfa:	48 2b 05 6f af 01 00 	sub    0x1af6f(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    6c01:	48 c1 e1 10          	shl    $0x10,%rcx
    6c05:	48 39 c8             	cmp    %rcx,%rax
    6c08:	0f 83 42 01 00 00    	jae    6d50 <fwp_drop4+0x160>
    6c0e:	48 83 ec 18          	sub    $0x18,%rsp
    6c12:	48 89 fa             	mov    %rdi,%rdx
    6c15:	4c 8d 05 a4 9b 01 00 	lea    0x19ba4(%rip),%r8        # 207c0 <fwp_heap>
    6c1c:	48 89 c1             	mov    %rax,%rcx
    6c1f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    6c26:	48 c1 e9 10          	shr    $0x10,%rcx
    6c2a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6c2e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6c32:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6c36:	48 85 c9             	test   %rcx,%rcx
    6c39:	74 40                	je     6c7b <fwp_drop4+0x8b>
    6c3b:	0f b6 3e             	movzbl (%rsi),%edi
    6c3e:	40 80 ff 02          	cmp    $0x2,%dil
    6c42:	74 3c                	je     6c80 <fwp_drop4+0x90>
    6c44:	40 80 ff 01          	cmp    $0x1,%dil
    6c48:	75 31                	jne    6c7b <fwp_drop4+0x8b>
    6c4a:	8b 7e 18             	mov    0x18(%rsi),%edi
    6c4d:	0f b7 c0             	movzwl %ax,%eax
    6c50:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6c53:	48 0f af c7          	imul   %rdi,%rax
    6c57:	48 c1 e8 20          	shr    $0x20,%rax
    6c5b:	48 39 f0             	cmp    %rsi,%rax
    6c5e:	73 1b                	jae    6c7b <fwp_drop4+0x8b>
    6c60:	48 01 c1             	add    %rax,%rcx
    6c63:	0f b6 01             	movzbl (%rcx),%eax
    6c66:	84 c0                	test   %al,%al
    6c68:	74 11                	je     6c7b <fwp_drop4+0x8b>
    6c6a:	3c 01                	cmp    $0x1,%al
    6c6c:	74 22                	je     6c90 <fwp_drop4+0xa0>
    6c6e:	3c ff                	cmp    $0xff,%al
    6c70:	0f 84 0a 01 00 00    	je     6d80 <fwp_drop4+0x190>
    6c76:	83 e8 01             	sub    $0x1,%eax
    6c79:	88 01                	mov    %al,(%rcx)
    6c7b:	48 83 c4 18          	add    $0x18,%rsp
    6c7f:	c3                   	ret
    6c80:	66 85 c0             	test   %ax,%ax
    6c83:	74 de                	je     6c63 <fwp_drop4+0x73>
    6c85:	48 83 c4 18          	add    $0x18,%rsp
    6c89:	c3                   	ret
    6c8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c90:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6c94:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    6c9b:	48 89 f8             	mov    %rdi,%rax
    6c9e:	48 c1 e1 10          	shl    $0x10,%rcx
    6ca2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6ca9:	48 39 c8             	cmp    %rcx,%rax
    6cac:	73 62                	jae    6d10 <fwp_drop4+0x120>
    6cae:	48 89 c1             	mov    %rax,%rcx
    6cb1:	48 c1 e9 10          	shr    $0x10,%rcx
    6cb5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6cb9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6cbd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6cc1:	48 85 c9             	test   %rcx,%rcx
    6cc4:	74 4a                	je     6d10 <fwp_drop4+0x120>
    6cc6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    6cca:	41 80 f9 02          	cmp    $0x2,%r9b
    6cce:	0f 84 9c 00 00 00    	je     6d70 <fwp_drop4+0x180>
    6cd4:	41 80 f9 01          	cmp    $0x1,%r9b
    6cd8:	75 36                	jne    6d10 <fwp_drop4+0x120>
    6cda:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    6cde:	0f b7 c0             	movzwl %ax,%eax
    6ce1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6ce4:	49 0f af c1          	imul   %r9,%rax
    6ce8:	48 c1 e8 20          	shr    $0x20,%rax
    6cec:	48 39 f0             	cmp    %rsi,%rax
    6cef:	73 1f                	jae    6d10 <fwp_drop4+0x120>
    6cf1:	48 01 c1             	add    %rax,%rcx
    6cf4:	0f b6 01             	movzbl (%rcx),%eax
    6cf7:	84 c0                	test   %al,%al
    6cf9:	74 15                	je     6d10 <fwp_drop4+0x120>
    6cfb:	3c 01                	cmp    $0x1,%al
    6cfd:	74 59                	je     6d58 <fwp_drop4+0x168>
    6cff:	3c ff                	cmp    $0xff,%al
    6d01:	0f 84 ff 00 00 00    	je     6e06 <fwp_drop4+0x216>
    6d07:	83 e8 01             	sub    $0x1,%eax
    6d0a:	88 01                	mov    %al,(%rcx)
    6d0c:	0f 1f 40 00          	nopl   0x0(%rax)
    6d10:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    6d14:	48 89 d7             	mov    %rdx,%rdi
    6d17:	48 89 0c 24          	mov    %rcx,(%rsp)
    6d1b:	e8 30 f7 ff ff       	call   6450 <fwp_rc_free_obj>
    6d20:	4c 8d 05 99 9a 01 00 	lea    0x19a99(%rip),%r8        # 207c0 <fwp_heap>
    6d27:	48 8b 04 24          	mov    (%rsp),%rax
    6d2b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6d32:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6d39:	48 c1 e2 10          	shl    $0x10,%rdx
    6d3d:	48 39 d0             	cmp    %rdx,%rax
    6d40:	0f 83 35 ff ff ff    	jae    6c7b <fwp_drop4+0x8b>
    6d46:	48 8b 14 24          	mov    (%rsp),%rdx
    6d4a:	e9 cd fe ff ff       	jmp    6c1c <fwp_drop4+0x2c>
    6d4f:	90                   	nop
    6d50:	c3                   	ret
    6d51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6d58:	48 89 14 24          	mov    %rdx,(%rsp)
    6d5c:	e8 ef f6 ff ff       	call   6450 <fwp_rc_free_obj>
    6d61:	48 8b 14 24          	mov    (%rsp),%rdx
    6d65:	eb a9                	jmp    6d10 <fwp_drop4+0x120>
    6d67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6d6e:	00 00 
    6d70:	66 85 c0             	test   %ax,%ax
    6d73:	75 9b                	jne    6d10 <fwp_drop4+0x120>
    6d75:	e9 7a ff ff ff       	jmp    6cf4 <fwp_drop4+0x104>
    6d7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d80:	48 89 c8             	mov    %rcx,%rax
    6d83:	48 c1 e8 11          	shr    $0x11,%rax
    6d87:	48 31 c8             	xor    %rcx,%rax
    6d8a:	48 89 c2             	mov    %rax,%rdx
    6d8d:	48 c1 ea 09          	shr    $0x9,%rdx
    6d91:	48 31 d0             	xor    %rdx,%rax
    6d94:	0f b6 d0             	movzbl %al,%edx
    6d97:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    6d9e:	00 
    6d9f:	48 85 c0             	test   %rax,%rax
    6da2:	75 29                	jne    6dcd <fwp_drop4+0x1dd>
    6da4:	e9 e3 00 00 00       	jmp    6e8c <fwp_drop4+0x29c>
    6da9:	90                   	nop
    6daa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6db1:	00 00 00 00 
    6db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6dbc:	00 00 00 00 
    6dc0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6dc4:	48 85 c0             	test   %rax,%rax
    6dc7:	0f 84 bf 00 00 00    	je     6e8c <fwp_drop4+0x29c>
    6dcd:	48 89 c2             	mov    %rax,%rdx
    6dd0:	48 39 08             	cmp    %rcx,(%rax)
    6dd3:	75 eb                	jne    6dc0 <fwp_drop4+0x1d0>
    6dd5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    6dd9:	48 83 ea 01          	sub    $0x1,%rdx
    6ddd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6de1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6de8:	0f 85 8d fe ff ff    	jne    6c7b <fwp_drop4+0x8b>
    6dee:	48 89 cf             	mov    %rcx,%rdi
    6df1:	48 89 0c 24          	mov    %rcx,(%rsp)
    6df5:	e8 56 e7 ff ff       	call   5550 <fwp_rc_forget_slot>
    6dfa:	48 8b 0c 24          	mov    (%rsp),%rcx
    6dfe:	c6 01 fe             	movb   $0xfe,(%rcx)
    6e01:	e9 75 fe ff ff       	jmp    6c7b <fwp_drop4+0x8b>
    6e06:	48 89 ce             	mov    %rcx,%rsi
    6e09:	48 c1 ee 11          	shr    $0x11,%rsi
    6e0d:	48 31 ce             	xor    %rcx,%rsi
    6e10:	48 89 f0             	mov    %rsi,%rax
    6e13:	48 c1 e8 09          	shr    $0x9,%rax
    6e17:	48 31 c6             	xor    %rax,%rsi
    6e1a:	40 0f b6 f6          	movzbl %sil,%esi
    6e1e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    6e25:	00 
    6e26:	48 85 c0             	test   %rax,%rax
    6e29:	75 1e                	jne    6e49 <fwp_drop4+0x259>
    6e2b:	eb 5f                	jmp    6e8c <fwp_drop4+0x29c>
    6e2d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6e34:	00 
    6e35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e3c:	00 00 00 00 
    6e40:	48 8b 46 10          	mov    0x10(%rsi),%rax
    6e44:	48 85 c0             	test   %rax,%rax
    6e47:	74 43                	je     6e8c <fwp_drop4+0x29c>
    6e49:	48 89 c6             	mov    %rax,%rsi
    6e4c:	48 39 08             	cmp    %rcx,(%rax)
    6e4f:	75 ef                	jne    6e40 <fwp_drop4+0x250>
    6e51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6e55:	48 83 ee 01          	sub    $0x1,%rsi
    6e59:	48 89 70 08          	mov    %rsi,0x8(%rax)
    6e5d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    6e64:	0f 85 a6 fe ff ff    	jne    6d10 <fwp_drop4+0x120>
    6e6a:	48 89 cf             	mov    %rcx,%rdi
    6e6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6e72:	48 89 0c 24          	mov    %rcx,(%rsp)
    6e76:	e8 d5 e6 ff ff       	call   5550 <fwp_rc_forget_slot>
    6e7b:	48 8b 0c 24          	mov    (%rsp),%rcx
    6e7f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6e84:	c6 01 fe             	movb   $0xfe,(%rcx)
    6e87:	e9 84 fe ff ff       	jmp    6d10 <fwp_drop4+0x120>
    6e8c:	48 8d 3d fd 59 00 00 	lea    0x59fd(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    6e93:	e8 58 d5 ff ff       	call   43f0 <fwp_trap>
    6e98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6e9f:	00 

0000000000006ea0 <fwp_arg_drop37>:
    6ea0:	f3 0f 1e fa          	endbr64
    6ea4:	85 f6                	test   %esi,%esi
    6ea6:	75 04                	jne    6eac <fwp_arg_drop37+0xc>
    6ea8:	85 d2                	test   %edx,%edx
    6eaa:	75 04                	jne    6eb0 <fwp_arg_drop37+0x10>
    6eac:	c3                   	ret
    6ead:	0f 1f 00             	nopl   (%rax)
    6eb0:	48 8b 3f             	mov    (%rdi),%rdi
    6eb3:	e9 38 fd ff ff       	jmp    6bf0 <fwp_drop4>
    6eb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6ebf:	00 

0000000000006ec0 <fwp_task_dispose>:
    6ec0:	53                   	push   %rbx
    6ec1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6ec5:	0f 84 7b c8 ff ff    	je     3746 <fwp_task_dispose.cold>
    6ecb:	48 89 fb             	mov    %rdi,%rbx
    6ece:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6ed3:	0f 85 6d c8 ff ff    	jne    3746 <fwp_task_dispose.cold>
    6ed9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6edd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6ee4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6eeb:	00 
    6eec:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6ef0:	48 85 ff             	test   %rdi,%rdi
    6ef3:	74 07                	je     6efc <fwp_task_dispose+0x3c>
    6ef5:	48 85 c0             	test   %rax,%rax
    6ef8:	74 02                	je     6efc <fwp_task_dispose+0x3c>
    6efa:	ff d0                	call   *%rax
    6efc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    6f03:	e8 88 e8 ff ff       	call   5790 <fwp_mem_free>
    6f08:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    6f0f:	00 00 00 00 
    6f13:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    6f17:	74 6f                	je     6f88 <fwp_task_dispose+0xc8>
    6f19:	48 8b 15 78 ac 01 00 	mov    0x1ac78(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    6f20:	48 89 d8             	mov    %rbx,%rax
    6f23:	48 2b 05 46 ac 01 00 	sub    0x1ac46(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    6f2a:	48 c1 e2 10          	shl    $0x10,%rdx
    6f2e:	48 39 d0             	cmp    %rdx,%rax
    6f31:	73 4c                	jae    6f7f <fwp_task_dispose+0xbf>
    6f33:	48 89 c2             	mov    %rax,%rdx
    6f36:	48 c1 ea 10          	shr    $0x10,%rdx
    6f3a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6f3e:	48 8b 15 73 ac 01 00 	mov    0x1ac73(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    6f45:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6f49:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6f4d:	48 85 c9             	test   %rcx,%rcx
    6f50:	74 2d                	je     6f7f <fwp_task_dispose+0xbf>
    6f52:	0f b6 32             	movzbl (%rdx),%esi
    6f55:	40 80 fe 02          	cmp    $0x2,%sil
    6f59:	74 3d                	je     6f98 <fwp_task_dispose+0xd8>
    6f5b:	40 80 fe 01          	cmp    $0x1,%sil
    6f5f:	75 1e                	jne    6f7f <fwp_task_dispose+0xbf>
    6f61:	8b 72 18             	mov    0x18(%rdx),%esi
    6f64:	0f b7 c0             	movzwl %ax,%eax
    6f67:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6f6a:	48 0f af c6          	imul   %rsi,%rax
    6f6e:	48 c1 e8 20          	shr    $0x20,%rax
    6f72:	48 39 d0             	cmp    %rdx,%rax
    6f75:	73 08                	jae    6f7f <fwp_task_dispose+0xbf>
    6f77:	48 01 c1             	add    %rax,%rcx
    6f7a:	80 39 01             	cmpb   $0x1,(%rcx)
    6f7d:	74 09                	je     6f88 <fwp_task_dispose+0xc8>
    6f7f:	5b                   	pop    %rbx
    6f80:	c3                   	ret
    6f81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f88:	48 89 df             	mov    %rbx,%rdi
    6f8b:	5b                   	pop    %rbx
    6f8c:	e9 ff e7 ff ff       	jmp    5790 <fwp_mem_free>
    6f91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f98:	66 85 c0             	test   %ax,%ax
    6f9b:	74 dd                	je     6f7a <fwp_task_dispose+0xba>
    6f9d:	5b                   	pop    %rbx
    6f9e:	c3                   	ret
    6f9f:	90                   	nop

0000000000006fa0 <fwp_free_zombie>:
    6fa0:	48 8b 15 e9 97 01 00 	mov    0x197e9(%rip),%rdx        # 20790 <fwp_zombie>
    6fa7:	48 85 d2             	test   %rdx,%rdx
    6faa:	0f 84 98 00 00 00    	je     7048 <fwp_free_zombie+0xa8>
    6fb0:	48 3b 15 e9 97 01 00 	cmp    0x197e9(%rip),%rdx        # 207a0 <fwp_cur>
    6fb7:	0f 84 8b 00 00 00    	je     7048 <fwp_free_zombie+0xa8>
    6fbd:	48 83 ec 18          	sub    $0x18,%rsp
    6fc1:	48 63 05 9c 91 01 00 	movslq 0x1919c(%rip),%rax        # 20164 <fwp_stack_pool_n>
    6fc8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    6fcc:	83 f8 3f             	cmp    $0x3f,%eax
    6fcf:	7f 7f                	jg     7050 <fwp_free_zombie+0xb0>
    6fd1:	8d 48 01             	lea    0x1(%rax),%ecx
    6fd4:	89 0d 8a 91 01 00    	mov    %ecx,0x1918a(%rip)        # 20164 <fwp_stack_pool_n>
    6fda:	48 8d 0d 9f 91 01 00 	lea    0x1919f(%rip),%rcx        # 20180 <fwp_stack_pool>
    6fe1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    6fe5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    6fec:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6ff0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    6ff7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    6ffb:	48 85 c9             	test   %rcx,%rcx
    6ffe:	0f 84 fc 00 00 00    	je     7100 <fwp_free_zombie+0x160>
    7004:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    700b:	48 85 c0             	test   %rax,%rax
    700e:	74 07                	je     7017 <fwp_free_zombie+0x77>
    7010:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7017:	8b 42 5c             	mov    0x5c(%rdx),%eax
    701a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    701e:	48 c7 05 67 97 01 00 	movq   $0x0,0x19767(%rip)        # 20790 <fwp_zombie>
    7025:	00 00 00 00 
    7029:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7030:	85 c0                	test   %eax,%eax
    7032:	74 34                	je     7068 <fwp_free_zombie+0xc8>
    7034:	83 f8 01             	cmp    $0x1,%eax
    7037:	0f 84 b3 00 00 00    	je     70f0 <fwp_free_zombie+0x150>
    703d:	48 83 c4 18          	add    $0x18,%rsp
    7041:	c3                   	ret
    7042:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7048:	c3                   	ret
    7049:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7050:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7054:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7059:	e8 82 c5 ff ff       	call   35e0 <munmap@plt>
    705e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7063:	eb 80                	jmp    6fe5 <fwp_free_zombie+0x45>
    7065:	0f 1f 00             	nopl   (%rax)
    7068:	48 8b 0d 29 ab 01 00 	mov    0x1ab29(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    706f:	48 89 d0             	mov    %rdx,%rax
    7072:	48 2b 05 f7 aa 01 00 	sub    0x1aaf7(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7079:	48 c1 e1 10          	shl    $0x10,%rcx
    707d:	48 39 c8             	cmp    %rcx,%rax
    7080:	73 bb                	jae    703d <fwp_free_zombie+0x9d>
    7082:	48 89 c1             	mov    %rax,%rcx
    7085:	48 c1 e9 10          	shr    $0x10,%rcx
    7089:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    708d:	48 8b 0d 24 ab 01 00 	mov    0x1ab24(%rip),%rcx        # 21bb8 <fwp_heap+0x13f8>
    7094:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7098:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    709c:	48 85 c9             	test   %rcx,%rcx
    709f:	74 9c                	je     703d <fwp_free_zombie+0x9d>
    70a1:	0f b6 3e             	movzbl (%rsi),%edi
    70a4:	40 80 ff 02          	cmp    $0x2,%dil
    70a8:	74 66                	je     7110 <fwp_free_zombie+0x170>
    70aa:	40 80 ff 01          	cmp    $0x1,%dil
    70ae:	75 8d                	jne    703d <fwp_free_zombie+0x9d>
    70b0:	8b 7e 18             	mov    0x18(%rsi),%edi
    70b3:	0f b7 c0             	movzwl %ax,%eax
    70b6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    70b9:	48 0f af c7          	imul   %rdi,%rax
    70bd:	48 c1 e8 20          	shr    $0x20,%rax
    70c1:	48 39 f0             	cmp    %rsi,%rax
    70c4:	0f 83 73 ff ff ff    	jae    703d <fwp_free_zombie+0x9d>
    70ca:	48 01 c1             	add    %rax,%rcx
    70cd:	0f b6 01             	movzbl (%rcx),%eax
    70d0:	84 c0                	test   %al,%al
    70d2:	0f 84 65 ff ff ff    	je     703d <fwp_free_zombie+0x9d>
    70d8:	3c 01                	cmp    $0x1,%al
    70da:	74 14                	je     70f0 <fwp_free_zombie+0x150>
    70dc:	3c ff                	cmp    $0xff,%al
    70de:	74 3b                	je     711b <fwp_free_zombie+0x17b>
    70e0:	83 e8 01             	sub    $0x1,%eax
    70e3:	88 01                	mov    %al,(%rcx)
    70e5:	e9 53 ff ff ff       	jmp    703d <fwp_free_zombie+0x9d>
    70ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    70f0:	48 89 d7             	mov    %rdx,%rdi
    70f3:	48 83 c4 18          	add    $0x18,%rsp
    70f7:	e9 c4 fd ff ff       	jmp    6ec0 <fwp_task_dispose>
    70fc:	0f 1f 40 00          	nopl   0x0(%rax)
    7100:	48 89 05 61 96 01 00 	mov    %rax,0x19661(%rip)        # 20768 <fwp_tasks_active>
    7107:	e9 ff fe ff ff       	jmp    700b <fwp_free_zombie+0x6b>
    710c:	0f 1f 40 00          	nopl   0x0(%rax)
    7110:	66 85 c0             	test   %ax,%ax
    7113:	0f 85 24 ff ff ff    	jne    703d <fwp_free_zombie+0x9d>
    7119:	eb b2                	jmp    70cd <fwp_free_zombie+0x12d>
    711b:	48 89 ca             	mov    %rcx,%rdx
    711e:	48 8d 35 9b 96 01 00 	lea    0x1969b(%rip),%rsi        # 207c0 <fwp_heap>
    7125:	48 c1 ea 11          	shr    $0x11,%rdx
    7129:	48 31 ca             	xor    %rcx,%rdx
    712c:	48 89 d0             	mov    %rdx,%rax
    712f:	48 c1 e8 09          	shr    $0x9,%rax
    7133:	48 31 c2             	xor    %rax,%rdx
    7136:	0f b6 d2             	movzbl %dl,%edx
    7139:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7140:	00 
    7141:	48 85 c0             	test   %rax,%rax
    7144:	75 23                	jne    7169 <fwp_free_zombie+0x1c9>
    7146:	eb 5c                	jmp    71a4 <fwp_free_zombie+0x204>
    7148:	66 90                	xchg   %ax,%ax
    714a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7151:	00 00 00 00 
    7155:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    715c:	00 00 00 00 
    7160:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7164:	48 85 c0             	test   %rax,%rax
    7167:	74 3b                	je     71a4 <fwp_free_zombie+0x204>
    7169:	48 89 c2             	mov    %rax,%rdx
    716c:	48 39 08             	cmp    %rcx,(%rax)
    716f:	75 ef                	jne    7160 <fwp_free_zombie+0x1c0>
    7171:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7175:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7179:	48 89 50 08          	mov    %rdx,0x8(%rax)
    717d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7184:	0f 85 b3 fe ff ff    	jne    703d <fwp_free_zombie+0x9d>
    718a:	48 89 cf             	mov    %rcx,%rdi
    718d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7192:	e8 b9 e3 ff ff       	call   5550 <fwp_rc_forget_slot>
    7197:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    719c:	c6 01 fe             	movb   $0xfe,(%rcx)
    719f:	e9 99 fe ff ff       	jmp    703d <fwp_free_zombie+0x9d>
    71a4:	48 8d 3d e5 56 00 00 	lea    0x56e5(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    71ab:	e8 40 d2 ff ff       	call   43f0 <fwp_trap>

00000000000071b0 <fwp_block>:
    71b0:	48 83 ec 08          	sub    $0x8,%rsp
    71b4:	48 8b 05 cd 95 01 00 	mov    0x195cd(%rip),%rax        # 20788 <fwp_ready_head>
    71bb:	48 85 c0             	test   %rax,%rax
    71be:	0f 84 1c 01 00 00    	je     72e0 <fwp_block+0x130>
    71c4:	90                   	nop
    71c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    71cc:	00 00 00 00 
    71d0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    71d7:	48 89 15 aa 95 01 00 	mov    %rdx,0x195aa(%rip)        # 20788 <fwp_ready_head>
    71de:	48 85 d2             	test   %rdx,%rdx
    71e1:	0f 84 19 01 00 00    	je     7300 <fwp_block+0x150>
    71e7:	48 8b 15 b2 95 01 00 	mov    0x195b2(%rip),%rdx        # 207a0 <fwp_cur>
    71ee:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    71f2:	48 39 c2             	cmp    %rax,%rdx
    71f5:	0f 84 d5 00 00 00    	je     72d0 <fwp_block+0x120>
    71fb:	48 8b 0d 26 b2 01 00 	mov    0x1b226(%rip),%rcx        # 22428 <fwp_state_owners>
    7202:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7206:	48 89 05 93 95 01 00 	mov    %rax,0x19593(%rip)        # 207a0 <fwp_cur>
    720d:	f3 0f 7e 05 3b b2 01 	movq   0x1b23b(%rip),%xmm0        # 22450 <fwp_foreign_callbacks>
    7214:	00 
    7215:	0f 16 05 24 b2 01 00 	movhps 0x1b224(%rip),%xmm0        # 22440 <fwp_state>
    721c:	f3 0f 7e 0d 24 b2 01 	movq   0x1b224(%rip),%xmm1        # 22448 <fwp_handlers>
    7223:	00 
    7224:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    722b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7232:	0f 16 0d 1f b2 01 00 	movhps 0x1b21f(%rip),%xmm1        # 22458 <fwp_cleanups>
    7239:	f3 0f 7e 05 f7 b1 01 	movq   0x1b1f7(%rip),%xmm0        # 22438 <fwp_state_len>
    7240:	00 
    7241:	0f 16 05 e8 b1 01 00 	movhps 0x1b1e8(%rip),%xmm0        # 22430 <fwp_state_cap>
    7248:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    724f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7256:	48 8b 70 08          	mov    0x8(%rax),%rsi
    725a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7261:	48 89 0d e0 b1 01 00 	mov    %rcx,0x1b1e0(%rip)        # 22448 <fwp_handlers>
    7268:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    726f:	48 89 0d e2 b1 01 00 	mov    %rcx,0x1b1e2(%rip)        # 22458 <fwp_cleanups>
    7276:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    727d:	48 89 0d cc b1 01 00 	mov    %rcx,0x1b1cc(%rip)        # 22450 <fwp_foreign_callbacks>
    7284:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    728b:	48 89 0d ae b1 01 00 	mov    %rcx,0x1b1ae(%rip)        # 22440 <fwp_state>
    7292:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7299:	48 89 0d 98 b1 01 00 	mov    %rcx,0x1b198(%rip)        # 22438 <fwp_state_len>
    72a0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    72a7:	48 89 0d 82 b1 01 00 	mov    %rcx,0x1b182(%rip)        # 22430 <fwp_state_cap>
    72ae:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    72b5:	48 89 0d 6c b1 01 00 	mov    %rcx,0x1b16c(%rip)        # 22428 <fwp_state_owners>
    72bc:	e8 cf c1 ff ff       	call   3490 <swapcontext@plt>
    72c1:	f3 0f 1e fa          	endbr64
    72c5:	e8 d6 fc ff ff       	call   6fa0 <fwp_free_zombie>
    72ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    72d0:	8b 05 8a 8e 01 00    	mov    0x18e8a(%rip),%eax        # 20160 <fwp_slice>
    72d6:	85 c0                	test   %eax,%eax
    72d8:	74 36                	je     7310 <fwp_block+0x160>
    72da:	48 83 c4 08          	add    $0x8,%rsp
    72de:	c3                   	ret
    72df:	90                   	nop
    72e0:	e8 bb de ff ff       	call   51a0 <fwp_poll_events>
    72e5:	48 8b 05 9c 94 01 00 	mov    0x1949c(%rip),%rax        # 20788 <fwp_ready_head>
    72ec:	48 85 c0             	test   %rax,%rax
    72ef:	0f 85 db fe ff ff    	jne    71d0 <fwp_block+0x20>
    72f5:	eb e9                	jmp    72e0 <fwp_block+0x130>
    72f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    72fe:	00 00 
    7300:	48 c7 05 75 94 01 00 	movq   $0x0,0x19475(%rip)        # 20780 <fwp_ready_tail>
    7307:	00 00 00 00 
    730b:	e9 d7 fe ff ff       	jmp    71e7 <fwp_block+0x37>
    7310:	48 8d 3d 6d 4e 00 00 	lea    0x4e6d(%rip),%rdi        # c184 <_IO_stdin_used+0x184>
    7317:	e8 84 c0 ff ff       	call   33a0 <getenv@plt>
    731c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7321:	48 85 c0             	test   %rax,%rax
    7324:	74 05                	je     732b <fwp_block+0x17b>
    7326:	80 38 00             	cmpb   $0x0,(%rax)
    7329:	75 0b                	jne    7336 <fwp_block+0x186>
    732b:	89 15 2f 8e 01 00    	mov    %edx,0x18e2f(%rip)        # 20160 <fwp_slice>
    7331:	48 83 c4 08          	add    $0x8,%rsp
    7335:	c3                   	ret
    7336:	ba 0a 00 00 00       	mov    $0xa,%edx
    733b:	31 f6                	xor    %esi,%esi
    733d:	48 89 c7             	mov    %rax,%rdi
    7340:	e8 0b c2 ff ff       	call   3550 <strtoll@plt>
    7345:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7349:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7350:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7355:	0f 46 d0             	cmovbe %eax,%edx
    7358:	eb d1                	jmp    732b <fwp_block+0x17b>
    735a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007360 <fwp_caps173>:
    7360:	f3 0f 1e fa          	endbr64
    7364:	85 f6                	test   %esi,%esi
    7366:	74 08                	je     7370 <fwp_caps173+0x10>
    7368:	c3                   	ret
    7369:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7370:	48 8b 15 21 a8 01 00 	mov    0x1a821(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7377:	48 89 f8             	mov    %rdi,%rax
    737a:	48 2b 05 ef a7 01 00 	sub    0x1a7ef(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7381:	48 c1 e2 10          	shl    $0x10,%rdx
    7385:	48 39 d0             	cmp    %rdx,%rax
    7388:	73 de                	jae    7368 <fwp_caps173+0x8>
    738a:	48 89 c2             	mov    %rax,%rdx
    738d:	48 c1 ea 10          	shr    $0x10,%rdx
    7391:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7395:	48 8b 15 1c a8 01 00 	mov    0x1a81c(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    739c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    73a0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    73a4:	48 85 c9             	test   %rcx,%rcx
    73a7:	74 bf                	je     7368 <fwp_caps173+0x8>
    73a9:	0f b6 32             	movzbl (%rdx),%esi
    73ac:	40 80 fe 02          	cmp    $0x2,%sil
    73b0:	74 2e                	je     73e0 <fwp_caps173+0x80>
    73b2:	40 80 fe 01          	cmp    $0x1,%sil
    73b6:	75 b0                	jne    7368 <fwp_caps173+0x8>
    73b8:	8b 72 18             	mov    0x18(%rdx),%esi
    73bb:	0f b7 c0             	movzwl %ax,%eax
    73be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    73c1:	48 0f af c6          	imul   %rsi,%rax
    73c5:	48 c1 e8 20          	shr    $0x20,%rax
    73c9:	48 39 d0             	cmp    %rdx,%rax
    73cc:	73 9a                	jae    7368 <fwp_caps173+0x8>
    73ce:	48 01 c1             	add    %rax,%rcx
    73d1:	80 39 01             	cmpb   $0x1,(%rcx)
    73d4:	75 92                	jne    7368 <fwp_caps173+0x8>
    73d6:	e9 b5 e3 ff ff       	jmp    5790 <fwp_mem_free>
    73db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    73e0:	66 85 c0             	test   %ax,%ax
    73e3:	74 ec                	je     73d1 <fwp_caps173+0x71>
    73e5:	c3                   	ret
    73e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    73ed:	00 00 00 

00000000000073f0 <fwp_args37>:
    73f0:	f3 0f 1e fa          	endbr64
    73f4:	85 d2                	test   %edx,%edx
    73f6:	74 04                	je     73fc <fwp_args37+0xc>
    73f8:	85 f6                	test   %esi,%esi
    73fa:	74 04                	je     7400 <fwp_args37+0x10>
    73fc:	c3                   	ret
    73fd:	0f 1f 00             	nopl   (%rax)
    7400:	48 8b 15 91 a7 01 00 	mov    0x1a791(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7407:	48 8b 07             	mov    (%rdi),%rax
    740a:	48 2b 05 5f a7 01 00 	sub    0x1a75f(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7411:	48 c1 e2 10          	shl    $0x10,%rdx
    7415:	48 39 d0             	cmp    %rdx,%rax
    7418:	73 e2                	jae    73fc <fwp_args37+0xc>
    741a:	48 89 c2             	mov    %rax,%rdx
    741d:	48 c1 ea 10          	shr    $0x10,%rdx
    7421:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7425:	48 8b 15 8c a7 01 00 	mov    0x1a78c(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    742c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7430:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7434:	48 85 ff             	test   %rdi,%rdi
    7437:	74 c3                	je     73fc <fwp_args37+0xc>
    7439:	0f b6 0a             	movzbl (%rdx),%ecx
    743c:	80 f9 02             	cmp    $0x2,%cl
    743f:	74 2f                	je     7470 <fwp_args37+0x80>
    7441:	80 f9 01             	cmp    $0x1,%cl
    7444:	75 b6                	jne    73fc <fwp_args37+0xc>
    7446:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7449:	0f b7 c0             	movzwl %ax,%eax
    744c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    744f:	48 0f af c1          	imul   %rcx,%rax
    7453:	48 c1 e8 20          	shr    $0x20,%rax
    7457:	48 39 d0             	cmp    %rdx,%rax
    745a:	73 a0                	jae    73fc <fwp_args37+0xc>
    745c:	48 01 c7             	add    %rax,%rdi
    745f:	0f b6 07             	movzbl (%rdi),%eax
    7462:	84 c0                	test   %al,%al
    7464:	74 96                	je     73fc <fwp_args37+0xc>
    7466:	3c fd                	cmp    $0xfd,%al
    7468:	77 0c                	ja     7476 <fwp_args37+0x86>
    746a:	83 c0 01             	add    $0x1,%eax
    746d:	88 07                	mov    %al,(%rdi)
    746f:	c3                   	ret
    7470:	66 85 c0             	test   %ax,%ax
    7473:	74 ea                	je     745f <fwp_args37+0x6f>
    7475:	c3                   	ret
    7476:	e9 b5 df ff ff       	jmp    5430 <fwp_rc_wide_dup>
    747b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007480 <fwp_caps37>:
    7480:	f3 0f 1e fa          	endbr64
    7484:	48 83 ec 18          	sub    $0x18,%rsp
    7488:	8b 57 04             	mov    0x4(%rdi),%edx
    748b:	48 89 f8             	mov    %rdi,%rax
    748e:	85 d2                	test   %edx,%edx
    7490:	0f 84 9a 00 00 00    	je     7530 <fwp_caps37+0xb0>
    7496:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    749a:	85 f6                	test   %esi,%esi
    749c:	0f 85 9e 00 00 00    	jne    7540 <fwp_caps37+0xc0>
    74a2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    74a7:	e8 44 f7 ff ff       	call   6bf0 <fwp_drop4>
    74ac:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    74b1:	48 8b 0d e0 a6 01 00 	mov    0x1a6e0(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    74b8:	48 89 c2             	mov    %rax,%rdx
    74bb:	48 2b 15 ae a6 01 00 	sub    0x1a6ae(%rip),%rdx        # 21b70 <fwp_heap+0x13b0>
    74c2:	48 c1 e1 10          	shl    $0x10,%rcx
    74c6:	48 39 ca             	cmp    %rcx,%rdx
    74c9:	73 6d                	jae    7538 <fwp_caps37+0xb8>
    74cb:	48 89 d1             	mov    %rdx,%rcx
    74ce:	48 c1 e9 10          	shr    $0x10,%rcx
    74d2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    74d6:	48 8b 0d db a6 01 00 	mov    0x1a6db(%rip),%rcx        # 21bb8 <fwp_heap+0x13f8>
    74dd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    74e1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    74e5:	48 85 f6             	test   %rsi,%rsi
    74e8:	74 4e                	je     7538 <fwp_caps37+0xb8>
    74ea:	0f b6 39             	movzbl (%rcx),%edi
    74ed:	40 80 ff 02          	cmp    $0x2,%dil
    74f1:	0f 84 b9 00 00 00    	je     75b0 <fwp_caps37+0x130>
    74f7:	40 80 ff 01          	cmp    $0x1,%dil
    74fb:	75 3b                	jne    7538 <fwp_caps37+0xb8>
    74fd:	8b 79 18             	mov    0x18(%rcx),%edi
    7500:	0f b7 d2             	movzwl %dx,%edx
    7503:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7506:	48 0f af d7          	imul   %rdi,%rdx
    750a:	48 c1 ea 20          	shr    $0x20,%rdx
    750e:	48 39 ca             	cmp    %rcx,%rdx
    7511:	73 25                	jae    7538 <fwp_caps37+0xb8>
    7513:	48 01 d6             	add    %rdx,%rsi
    7516:	80 3e 01             	cmpb   $0x1,(%rsi)
    7519:	75 1d                	jne    7538 <fwp_caps37+0xb8>
    751b:	48 89 c7             	mov    %rax,%rdi
    751e:	48 83 c4 18          	add    $0x18,%rsp
    7522:	e9 69 e2 ff ff       	jmp    5790 <fwp_mem_free>
    7527:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    752e:	00 00 
    7530:	85 f6                	test   %esi,%esi
    7532:	0f 84 79 ff ff ff    	je     74b1 <fwp_caps37+0x31>
    7538:	48 83 c4 18          	add    $0x18,%rsp
    753c:	c3                   	ret
    753d:	0f 1f 00             	nopl   (%rax)
    7540:	48 8b 05 51 a6 01 00 	mov    0x1a651(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    7547:	48 2b 3d 22 a6 01 00 	sub    0x1a622(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    754e:	48 c1 e0 10          	shl    $0x10,%rax
    7552:	48 39 c7             	cmp    %rax,%rdi
    7555:	73 e1                	jae    7538 <fwp_caps37+0xb8>
    7557:	48 89 f8             	mov    %rdi,%rax
    755a:	48 c1 e8 10          	shr    $0x10,%rax
    755e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7562:	48 8b 05 4f a6 01 00 	mov    0x1a64f(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    7569:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    756d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7571:	48 85 c0             	test   %rax,%rax
    7574:	74 c2                	je     7538 <fwp_caps37+0xb8>
    7576:	0f b6 0a             	movzbl (%rdx),%ecx
    7579:	80 f9 02             	cmp    $0x2,%cl
    757c:	74 42                	je     75c0 <fwp_caps37+0x140>
    757e:	80 f9 01             	cmp    $0x1,%cl
    7581:	75 b5                	jne    7538 <fwp_caps37+0xb8>
    7583:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7586:	0f b7 ff             	movzwl %di,%edi
    7589:	8b 52 1c             	mov    0x1c(%rdx),%edx
    758c:	48 0f af f9          	imul   %rcx,%rdi
    7590:	48 c1 ef 20          	shr    $0x20,%rdi
    7594:	48 39 d7             	cmp    %rdx,%rdi
    7597:	73 9f                	jae    7538 <fwp_caps37+0xb8>
    7599:	48 01 f8             	add    %rdi,%rax
    759c:	0f b6 10             	movzbl (%rax),%edx
    759f:	84 d2                	test   %dl,%dl
    75a1:	74 95                	je     7538 <fwp_caps37+0xb8>
    75a3:	80 fa fd             	cmp    $0xfd,%dl
    75a6:	77 23                	ja     75cb <fwp_caps37+0x14b>
    75a8:	83 c2 01             	add    $0x1,%edx
    75ab:	88 10                	mov    %dl,(%rax)
    75ad:	eb 89                	jmp    7538 <fwp_caps37+0xb8>
    75af:	90                   	nop
    75b0:	66 85 d2             	test   %dx,%dx
    75b3:	0f 85 7f ff ff ff    	jne    7538 <fwp_caps37+0xb8>
    75b9:	e9 58 ff ff ff       	jmp    7516 <fwp_caps37+0x96>
    75be:	66 90                	xchg   %ax,%ax
    75c0:	66 85 ff             	test   %di,%di
    75c3:	0f 85 6f ff ff ff    	jne    7538 <fwp_caps37+0xb8>
    75c9:	eb d1                	jmp    759c <fwp_caps37+0x11c>
    75cb:	48 89 c7             	mov    %rax,%rdi
    75ce:	48 83 c4 18          	add    $0x18,%rsp
    75d2:	e9 59 de ff ff       	jmp    5430 <fwp_rc_wide_dup>
    75d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    75de:	00 00 

00000000000075e0 <fwp_drop0>:
    75e0:	f3 0f 1e fa          	endbr64
    75e4:	48 8b 15 ad a5 01 00 	mov    0x1a5ad(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    75eb:	48 89 f8             	mov    %rdi,%rax
    75ee:	48 2b 05 7b a5 01 00 	sub    0x1a57b(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    75f5:	48 c1 e2 10          	shl    $0x10,%rdx
    75f9:	48 39 d0             	cmp    %rdx,%rax
    75fc:	0f 83 36 01 00 00    	jae    7738 <fwp_drop0+0x158>
    7602:	48 83 ec 18          	sub    $0x18,%rsp
    7606:	48 8d 35 b3 91 01 00 	lea    0x191b3(%rip),%rsi        # 207c0 <fwp_heap>
    760d:	48 89 c2             	mov    %rax,%rdx
    7610:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7617:	48 c1 ea 10          	shr    $0x10,%rdx
    761b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    761f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7623:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7627:	48 85 d2             	test   %rdx,%rdx
    762a:	74 42                	je     766e <fwp_drop0+0x8e>
    762c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7630:	41 80 f8 02          	cmp    $0x2,%r8b
    7634:	74 42                	je     7678 <fwp_drop0+0x98>
    7636:	41 80 f8 01          	cmp    $0x1,%r8b
    763a:	75 32                	jne    766e <fwp_drop0+0x8e>
    763c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7640:	0f b7 c0             	movzwl %ax,%eax
    7643:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7646:	49 0f af c0          	imul   %r8,%rax
    764a:	48 c1 e8 20          	shr    $0x20,%rax
    764e:	48 39 c8             	cmp    %rcx,%rax
    7651:	73 1b                	jae    766e <fwp_drop0+0x8e>
    7653:	48 01 c2             	add    %rax,%rdx
    7656:	0f b6 02             	movzbl (%rdx),%eax
    7659:	84 c0                	test   %al,%al
    765b:	74 11                	je     766e <fwp_drop0+0x8e>
    765d:	3c 01                	cmp    $0x1,%al
    765f:	74 27                	je     7688 <fwp_drop0+0xa8>
    7661:	3c ff                	cmp    $0xff,%al
    7663:	0f 84 e7 00 00 00    	je     7750 <fwp_drop0+0x170>
    7669:	83 e8 01             	sub    $0x1,%eax
    766c:	88 02                	mov    %al,(%rdx)
    766e:	48 83 c4 18          	add    $0x18,%rsp
    7672:	c3                   	ret
    7673:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7678:	66 85 c0             	test   %ax,%ax
    767b:	74 d9                	je     7656 <fwp_drop0+0x76>
    767d:	48 83 c4 18          	add    $0x18,%rsp
    7681:	c3                   	ret
    7682:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7688:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    768f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7696:	48 89 f8             	mov    %rdi,%rax
    7699:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    769d:	48 29 c8             	sub    %rcx,%rax
    76a0:	48 c1 e2 10          	shl    $0x10,%rdx
    76a4:	48 39 d0             	cmp    %rdx,%rax
    76a7:	73 71                	jae    771a <fwp_drop0+0x13a>
    76a9:	49 89 c2             	mov    %rax,%r10
    76ac:	49 c1 ea 10          	shr    $0x10,%r10
    76b0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    76b4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    76b8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    76bc:	4d 85 d2             	test   %r10,%r10
    76bf:	74 59                	je     771a <fwp_drop0+0x13a>
    76c1:	45 0f b6 19          	movzbl (%r9),%r11d
    76c5:	41 80 fb 02          	cmp    $0x2,%r11b
    76c9:	74 75                	je     7740 <fwp_drop0+0x160>
    76cb:	41 80 fb 01          	cmp    $0x1,%r11b
    76cf:	75 49                	jne    771a <fwp_drop0+0x13a>
    76d1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    76d5:	0f b7 c0             	movzwl %ax,%eax
    76d8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    76dc:	49 0f af c3          	imul   %r11,%rax
    76e0:	48 c1 e8 20          	shr    $0x20,%rax
    76e4:	4c 39 c8             	cmp    %r9,%rax
    76e7:	73 31                	jae    771a <fwp_drop0+0x13a>
    76e9:	49 01 c2             	add    %rax,%r10
    76ec:	41 80 3a 01          	cmpb   $0x1,(%r10)
    76f0:	75 28                	jne    771a <fwp_drop0+0x13a>
    76f2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    76f7:	e8 94 e0 ff ff       	call   5790 <fwp_mem_free>
    76fc:	48 8d 35 bd 90 01 00 	lea    0x190bd(%rip),%rsi        # 207c0 <fwp_heap>
    7703:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7708:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    770f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7716:	48 c1 e2 10          	shl    $0x10,%rdx
    771a:	4c 89 c0             	mov    %r8,%rax
    771d:	48 29 c8             	sub    %rcx,%rax
    7720:	48 39 d0             	cmp    %rdx,%rax
    7723:	0f 83 45 ff ff ff    	jae    766e <fwp_drop0+0x8e>
    7729:	4c 89 c7             	mov    %r8,%rdi
    772c:	e9 dc fe ff ff       	jmp    760d <fwp_drop0+0x2d>
    7731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7738:	c3                   	ret
    7739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7740:	66 85 c0             	test   %ax,%ax
    7743:	75 d5                	jne    771a <fwp_drop0+0x13a>
    7745:	eb a5                	jmp    76ec <fwp_drop0+0x10c>
    7747:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    774e:	00 00 
    7750:	48 89 d0             	mov    %rdx,%rax
    7753:	48 c1 e8 11          	shr    $0x11,%rax
    7757:	48 31 d0             	xor    %rdx,%rax
    775a:	48 89 c1             	mov    %rax,%rcx
    775d:	48 c1 e9 09          	shr    $0x9,%rcx
    7761:	48 31 c8             	xor    %rcx,%rax
    7764:	0f b6 c8             	movzbl %al,%ecx
    7767:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    776e:	00 
    776f:	48 85 c0             	test   %rax,%rax
    7772:	75 15                	jne    7789 <fwp_drop0+0x1a9>
    7774:	eb 4e                	jmp    77c4 <fwp_drop0+0x1e4>
    7776:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    777d:	00 00 00 
    7780:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7784:	48 85 c0             	test   %rax,%rax
    7787:	74 3b                	je     77c4 <fwp_drop0+0x1e4>
    7789:	48 89 c1             	mov    %rax,%rcx
    778c:	48 39 10             	cmp    %rdx,(%rax)
    778f:	75 ef                	jne    7780 <fwp_drop0+0x1a0>
    7791:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7795:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7799:	48 89 48 08          	mov    %rcx,0x8(%rax)
    779d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    77a4:	0f 85 c4 fe ff ff    	jne    766e <fwp_drop0+0x8e>
    77aa:	48 89 d7             	mov    %rdx,%rdi
    77ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    77b2:	e8 99 dd ff ff       	call   5550 <fwp_rc_forget_slot>
    77b7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    77bc:	c6 02 fe             	movb   $0xfe,(%rdx)
    77bf:	e9 aa fe ff ff       	jmp    766e <fwp_drop0+0x8e>
    77c4:	48 8d 3d c5 50 00 00 	lea    0x50c5(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    77cb:	e8 20 cc ff ff       	call   43f0 <fwp_trap>

00000000000077d0 <fwp_drop1>:
    77d0:	f3 0f 1e fa          	endbr64
    77d4:	48 8b 15 bd a3 01 00 	mov    0x1a3bd(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    77db:	48 89 f8             	mov    %rdi,%rax
    77de:	48 2b 05 8b a3 01 00 	sub    0x1a38b(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    77e5:	48 c1 e2 10          	shl    $0x10,%rdx
    77e9:	48 39 d0             	cmp    %rdx,%rax
    77ec:	0f 83 36 01 00 00    	jae    7928 <fwp_drop1+0x158>
    77f2:	48 83 ec 18          	sub    $0x18,%rsp
    77f6:	48 8d 35 c3 8f 01 00 	lea    0x18fc3(%rip),%rsi        # 207c0 <fwp_heap>
    77fd:	48 89 c2             	mov    %rax,%rdx
    7800:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7807:	48 c1 ea 10          	shr    $0x10,%rdx
    780b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    780f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7813:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7817:	48 85 d2             	test   %rdx,%rdx
    781a:	74 42                	je     785e <fwp_drop1+0x8e>
    781c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7820:	41 80 f8 02          	cmp    $0x2,%r8b
    7824:	74 42                	je     7868 <fwp_drop1+0x98>
    7826:	41 80 f8 01          	cmp    $0x1,%r8b
    782a:	75 32                	jne    785e <fwp_drop1+0x8e>
    782c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7830:	0f b7 c0             	movzwl %ax,%eax
    7833:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7836:	49 0f af c0          	imul   %r8,%rax
    783a:	48 c1 e8 20          	shr    $0x20,%rax
    783e:	48 39 c8             	cmp    %rcx,%rax
    7841:	73 1b                	jae    785e <fwp_drop1+0x8e>
    7843:	48 01 c2             	add    %rax,%rdx
    7846:	0f b6 02             	movzbl (%rdx),%eax
    7849:	84 c0                	test   %al,%al
    784b:	74 11                	je     785e <fwp_drop1+0x8e>
    784d:	3c 01                	cmp    $0x1,%al
    784f:	74 27                	je     7878 <fwp_drop1+0xa8>
    7851:	3c ff                	cmp    $0xff,%al
    7853:	0f 84 e7 00 00 00    	je     7940 <fwp_drop1+0x170>
    7859:	83 e8 01             	sub    $0x1,%eax
    785c:	88 02                	mov    %al,(%rdx)
    785e:	48 83 c4 18          	add    $0x18,%rsp
    7862:	c3                   	ret
    7863:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7868:	66 85 c0             	test   %ax,%ax
    786b:	74 d9                	je     7846 <fwp_drop1+0x76>
    786d:	48 83 c4 18          	add    $0x18,%rsp
    7871:	c3                   	ret
    7872:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7878:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    787f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7886:	48 89 f8             	mov    %rdi,%rax
    7889:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    788d:	48 29 c8             	sub    %rcx,%rax
    7890:	48 c1 e2 10          	shl    $0x10,%rdx
    7894:	48 39 d0             	cmp    %rdx,%rax
    7897:	73 71                	jae    790a <fwp_drop1+0x13a>
    7899:	49 89 c2             	mov    %rax,%r10
    789c:	49 c1 ea 10          	shr    $0x10,%r10
    78a0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    78a4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    78a8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    78ac:	4d 85 d2             	test   %r10,%r10
    78af:	74 59                	je     790a <fwp_drop1+0x13a>
    78b1:	45 0f b6 19          	movzbl (%r9),%r11d
    78b5:	41 80 fb 02          	cmp    $0x2,%r11b
    78b9:	74 75                	je     7930 <fwp_drop1+0x160>
    78bb:	41 80 fb 01          	cmp    $0x1,%r11b
    78bf:	75 49                	jne    790a <fwp_drop1+0x13a>
    78c1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    78c5:	0f b7 c0             	movzwl %ax,%eax
    78c8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    78cc:	49 0f af c3          	imul   %r11,%rax
    78d0:	48 c1 e8 20          	shr    $0x20,%rax
    78d4:	4c 39 c8             	cmp    %r9,%rax
    78d7:	73 31                	jae    790a <fwp_drop1+0x13a>
    78d9:	49 01 c2             	add    %rax,%r10
    78dc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    78e0:	75 28                	jne    790a <fwp_drop1+0x13a>
    78e2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    78e7:	e8 a4 de ff ff       	call   5790 <fwp_mem_free>
    78ec:	48 8d 35 cd 8e 01 00 	lea    0x18ecd(%rip),%rsi        # 207c0 <fwp_heap>
    78f3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    78f8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    78ff:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7906:	48 c1 e2 10          	shl    $0x10,%rdx
    790a:	4c 89 c0             	mov    %r8,%rax
    790d:	48 29 c8             	sub    %rcx,%rax
    7910:	48 39 d0             	cmp    %rdx,%rax
    7913:	0f 83 45 ff ff ff    	jae    785e <fwp_drop1+0x8e>
    7919:	4c 89 c7             	mov    %r8,%rdi
    791c:	e9 dc fe ff ff       	jmp    77fd <fwp_drop1+0x2d>
    7921:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7928:	c3                   	ret
    7929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7930:	66 85 c0             	test   %ax,%ax
    7933:	75 d5                	jne    790a <fwp_drop1+0x13a>
    7935:	eb a5                	jmp    78dc <fwp_drop1+0x10c>
    7937:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    793e:	00 00 
    7940:	48 89 d0             	mov    %rdx,%rax
    7943:	48 c1 e8 11          	shr    $0x11,%rax
    7947:	48 31 d0             	xor    %rdx,%rax
    794a:	48 89 c1             	mov    %rax,%rcx
    794d:	48 c1 e9 09          	shr    $0x9,%rcx
    7951:	48 31 c8             	xor    %rcx,%rax
    7954:	0f b6 c8             	movzbl %al,%ecx
    7957:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    795e:	00 
    795f:	48 85 c0             	test   %rax,%rax
    7962:	75 25                	jne    7989 <fwp_drop1+0x1b9>
    7964:	eb 5e                	jmp    79c4 <fwp_drop1+0x1f4>
    7966:	0f 1f 40 00          	nopl   0x0(%rax)
    796a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7971:	00 00 00 00 
    7975:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    797c:	00 00 00 00 
    7980:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7984:	48 85 c0             	test   %rax,%rax
    7987:	74 3b                	je     79c4 <fwp_drop1+0x1f4>
    7989:	48 89 c1             	mov    %rax,%rcx
    798c:	48 39 10             	cmp    %rdx,(%rax)
    798f:	75 ef                	jne    7980 <fwp_drop1+0x1b0>
    7991:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7995:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7999:	48 89 48 08          	mov    %rcx,0x8(%rax)
    799d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    79a4:	0f 85 b4 fe ff ff    	jne    785e <fwp_drop1+0x8e>
    79aa:	48 89 d7             	mov    %rdx,%rdi
    79ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    79b2:	e8 99 db ff ff       	call   5550 <fwp_rc_forget_slot>
    79b7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    79bc:	c6 02 fe             	movb   $0xfe,(%rdx)
    79bf:	e9 9a fe ff ff       	jmp    785e <fwp_drop1+0x8e>
    79c4:	48 8d 3d c5 4e 00 00 	lea    0x4ec5(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    79cb:	e8 20 ca ff ff       	call   43f0 <fwp_trap>

00000000000079d0 <fwp_drop10>:
    79d0:	48 8b 0d c1 a1 01 00 	mov    0x1a1c1(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    79d7:	48 89 f8             	mov    %rdi,%rax
    79da:	48 2b 05 8f a1 01 00 	sub    0x1a18f(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    79e1:	48 c1 e1 10          	shl    $0x10,%rcx
    79e5:	48 39 c8             	cmp    %rcx,%rax
    79e8:	0f 83 c2 01 00 00    	jae    7bb0 <fwp_drop10+0x1e0>
    79ee:	48 83 ec 18          	sub    $0x18,%rsp
    79f2:	48 89 fa             	mov    %rdi,%rdx
    79f5:	48 8d 35 c4 8d 01 00 	lea    0x18dc4(%rip),%rsi        # 207c0 <fwp_heap>
    79fc:	48 89 c1             	mov    %rax,%rcx
    79ff:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7a06:	48 c1 e9 10          	shr    $0x10,%rcx
    7a0a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7a0e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7a12:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7a16:	48 85 c9             	test   %rcx,%rcx
    7a19:	74 46                	je     7a61 <fwp_drop10+0x91>
    7a1b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7a1f:	41 80 f9 02          	cmp    $0x2,%r9b
    7a23:	0f 84 d7 00 00 00    	je     7b00 <fwp_drop10+0x130>
    7a29:	41 80 f9 01          	cmp    $0x1,%r9b
    7a2d:	75 32                	jne    7a61 <fwp_drop10+0x91>
    7a2f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7a33:	0f b7 c0             	movzwl %ax,%eax
    7a36:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7a39:	49 0f af c1          	imul   %r9,%rax
    7a3d:	48 c1 e8 20          	shr    $0x20,%rax
    7a41:	48 39 f8             	cmp    %rdi,%rax
    7a44:	73 1b                	jae    7a61 <fwp_drop10+0x91>
    7a46:	48 01 c1             	add    %rax,%rcx
    7a49:	0f b6 01             	movzbl (%rcx),%eax
    7a4c:	84 c0                	test   %al,%al
    7a4e:	74 11                	je     7a61 <fwp_drop10+0x91>
    7a50:	3c 01                	cmp    $0x1,%al
    7a52:	74 1c                	je     7a70 <fwp_drop10+0xa0>
    7a54:	3c ff                	cmp    $0xff,%al
    7a56:	0f 84 5c 01 00 00    	je     7bb8 <fwp_drop10+0x1e8>
    7a5c:	83 e8 01             	sub    $0x1,%eax
    7a5f:	88 01                	mov    %al,(%rcx)
    7a61:	48 83 c4 18          	add    $0x18,%rsp
    7a65:	c3                   	ret
    7a66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7a6d:	00 00 00 
    7a70:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7a77:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7a7e:	48 89 d0             	mov    %rdx,%rax
    7a81:	49 89 d1             	mov    %rdx,%r9
    7a84:	48 c1 e1 10          	shl    $0x10,%rcx
    7a88:	48 29 f8             	sub    %rdi,%rax
    7a8b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7a8f:	78 7f                	js     7b10 <fwp_drop10+0x140>
    7a91:	48 39 c8             	cmp    %rcx,%rax
    7a94:	73 cb                	jae    7a61 <fwp_drop10+0x91>
    7a96:	48 89 c1             	mov    %rax,%rcx
    7a99:	48 c1 e9 10          	shr    $0x10,%rcx
    7a9d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7aa1:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7aa5:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7aa9:	48 85 f6             	test   %rsi,%rsi
    7aac:	74 b3                	je     7a61 <fwp_drop10+0x91>
    7aae:	0f b6 39             	movzbl (%rcx),%edi
    7ab1:	40 80 ff 02          	cmp    $0x2,%dil
    7ab5:	74 39                	je     7af0 <fwp_drop10+0x120>
    7ab7:	40 80 ff 01          	cmp    $0x1,%dil
    7abb:	75 a4                	jne    7a61 <fwp_drop10+0x91>
    7abd:	8b 79 18             	mov    0x18(%rcx),%edi
    7ac0:	0f b7 c0             	movzwl %ax,%eax
    7ac3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7ac6:	48 0f af c7          	imul   %rdi,%rax
    7aca:	48 c1 e8 20          	shr    $0x20,%rax
    7ace:	48 39 c8             	cmp    %rcx,%rax
    7ad1:	73 8e                	jae    7a61 <fwp_drop10+0x91>
    7ad3:	48 01 c6             	add    %rax,%rsi
    7ad6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7ad9:	75 86                	jne    7a61 <fwp_drop10+0x91>
    7adb:	48 89 d7             	mov    %rdx,%rdi
    7ade:	48 83 c4 18          	add    $0x18,%rsp
    7ae2:	e9 a9 dc ff ff       	jmp    5790 <fwp_mem_free>
    7ae7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7aee:	00 00 
    7af0:	66 85 c0             	test   %ax,%ax
    7af3:	74 e1                	je     7ad6 <fwp_drop10+0x106>
    7af5:	48 83 c4 18          	add    $0x18,%rsp
    7af9:	c3                   	ret
    7afa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b00:	66 85 c0             	test   %ax,%ax
    7b03:	0f 84 40 ff ff ff    	je     7a49 <fwp_drop10+0x79>
    7b09:	48 83 c4 18          	add    $0x18,%rsp
    7b0d:	c3                   	ret
    7b0e:	66 90                	xchg   %ax,%ax
    7b10:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7b14:	48 39 c8             	cmp    %rcx,%rax
    7b17:	73 74                	jae    7b8d <fwp_drop10+0x1bd>
    7b19:	49 89 c2             	mov    %rax,%r10
    7b1c:	49 c1 ea 10          	shr    $0x10,%r10
    7b20:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7b24:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7b28:	4d 8b 50 20          	mov    0x20(%r8),%r10
    7b2c:	4d 85 d2             	test   %r10,%r10
    7b2f:	74 5c                	je     7b8d <fwp_drop10+0x1bd>
    7b31:	45 0f b6 18          	movzbl (%r8),%r11d
    7b35:	41 80 fb 02          	cmp    $0x2,%r11b
    7b39:	74 6d                	je     7ba8 <fwp_drop10+0x1d8>
    7b3b:	41 80 fb 01          	cmp    $0x1,%r11b
    7b3f:	75 4c                	jne    7b8d <fwp_drop10+0x1bd>
    7b41:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7b45:	0f b7 c0             	movzwl %ax,%eax
    7b48:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    7b4c:	49 0f af c3          	imul   %r11,%rax
    7b50:	48 c1 e8 20          	shr    $0x20,%rax
    7b54:	4c 39 c0             	cmp    %r8,%rax
    7b57:	73 34                	jae    7b8d <fwp_drop10+0x1bd>
    7b59:	49 01 c2             	add    %rax,%r10
    7b5c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7b60:	75 2b                	jne    7b8d <fwp_drop10+0x1bd>
    7b62:	4c 89 cf             	mov    %r9,%rdi
    7b65:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7b6a:	e8 21 dc ff ff       	call   5790 <fwp_mem_free>
    7b6f:	48 8d 35 4a 8c 01 00 	lea    0x18c4a(%rip),%rsi        # 207c0 <fwp_heap>
    7b76:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7b7b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7b82:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7b89:	48 c1 e1 10          	shl    $0x10,%rcx
    7b8d:	48 89 d0             	mov    %rdx,%rax
    7b90:	48 29 f8             	sub    %rdi,%rax
    7b93:	48 39 c8             	cmp    %rcx,%rax
    7b96:	0f 82 60 fe ff ff    	jb     79fc <fwp_drop10+0x2c>
    7b9c:	e9 c0 fe ff ff       	jmp    7a61 <fwp_drop10+0x91>
    7ba1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ba8:	66 85 c0             	test   %ax,%ax
    7bab:	75 e0                	jne    7b8d <fwp_drop10+0x1bd>
    7bad:	eb ad                	jmp    7b5c <fwp_drop10+0x18c>
    7baf:	90                   	nop
    7bb0:	c3                   	ret
    7bb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7bb8:	48 89 c8             	mov    %rcx,%rax
    7bbb:	48 c1 e8 11          	shr    $0x11,%rax
    7bbf:	48 31 c8             	xor    %rcx,%rax
    7bc2:	48 89 c2             	mov    %rax,%rdx
    7bc5:	48 c1 ea 09          	shr    $0x9,%rdx
    7bc9:	48 31 d0             	xor    %rdx,%rax
    7bcc:	0f b6 d0             	movzbl %al,%edx
    7bcf:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7bd6:	00 
    7bd7:	48 85 c0             	test   %rax,%rax
    7bda:	75 0d                	jne    7be9 <fwp_drop10+0x219>
    7bdc:	eb 46                	jmp    7c24 <fwp_drop10+0x254>
    7bde:	66 90                	xchg   %ax,%ax
    7be0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7be4:	48 85 c0             	test   %rax,%rax
    7be7:	74 3b                	je     7c24 <fwp_drop10+0x254>
    7be9:	48 89 c2             	mov    %rax,%rdx
    7bec:	48 39 08             	cmp    %rcx,(%rax)
    7bef:	75 ef                	jne    7be0 <fwp_drop10+0x210>
    7bf1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7bf5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7bf9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7bfd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7c04:	0f 85 57 fe ff ff    	jne    7a61 <fwp_drop10+0x91>
    7c0a:	48 89 cf             	mov    %rcx,%rdi
    7c0d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7c12:	e8 39 d9 ff ff       	call   5550 <fwp_rc_forget_slot>
    7c17:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7c1c:	c6 01 fe             	movb   $0xfe,(%rcx)
    7c1f:	e9 3d fe ff ff       	jmp    7a61 <fwp_drop10+0x91>
    7c24:	48 8d 3d 65 4c 00 00 	lea    0x4c65(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    7c2b:	e8 c0 c7 ff ff       	call   43f0 <fwp_trap>

0000000000007c30 <f37>:
    7c30:	41 57                	push   %r15
    7c32:	41 56                	push   %r14
    7c34:	41 55                	push   %r13
    7c36:	41 54                	push   %r12
    7c38:	55                   	push   %rbp
    7c39:	53                   	push   %rbx
    7c3a:	48 83 ec 38          	sub    $0x38,%rsp
    7c3e:	48 8b 15 53 9f 01 00 	mov    0x19f53(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7c45:	48 8b 0d 24 9f 01 00 	mov    0x19f24(%rip),%rcx        # 21b70 <fwp_heap+0x13b0>
    7c4c:	64 4c 8b 2c 25 28 00 	mov    %fs:0x28,%r13
    7c53:	00 00 
    7c55:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
    7c5a:	49 89 fd             	mov    %rdi,%r13
    7c5d:	48 c1 e2 10          	shl    $0x10,%rdx
    7c61:	48 85 ff             	test   %rdi,%rdi
    7c64:	0f 84 0c 03 00 00    	je     7f76 <f37+0x346>
    7c6a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    7c6e:	48 89 d8             	mov    %rbx,%rax
    7c71:	48 29 c8             	sub    %rcx,%rax
    7c74:	48 39 d0             	cmp    %rdx,%rax
    7c77:	0f 83 c3 03 00 00    	jae    8040 <f37+0x410>
    7c7d:	48 89 c2             	mov    %rax,%rdx
    7c80:	48 c1 ea 10          	shr    $0x10,%rdx
    7c84:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7c88:	48 8b 15 29 9f 01 00 	mov    0x19f29(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    7c8f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7c93:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7c97:	48 85 ff             	test   %rdi,%rdi
    7c9a:	0f 84 a0 03 00 00    	je     8040 <f37+0x410>
    7ca0:	0f b6 0a             	movzbl (%rdx),%ecx
    7ca3:	80 f9 02             	cmp    $0x2,%cl
    7ca6:	0f 84 a4 02 00 00    	je     7f50 <f37+0x320>
    7cac:	80 f9 01             	cmp    $0x1,%cl
    7caf:	75 24                	jne    7cd5 <f37+0xa5>
    7cb1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7cb4:	0f b7 c0             	movzwl %ax,%eax
    7cb7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7cba:	48 0f af c1          	imul   %rcx,%rax
    7cbe:	48 c1 e8 20          	shr    $0x20,%rax
    7cc2:	48 39 d0             	cmp    %rdx,%rax
    7cc5:	73 0e                	jae    7cd5 <f37+0xa5>
    7cc7:	48 01 c7             	add    %rax,%rdi
    7cca:	0f b6 07             	movzbl (%rdi),%eax
    7ccd:	84 c0                	test   %al,%al
    7ccf:	0f 85 1b 03 00 00    	jne    7ff0 <f37+0x3c0>
    7cd5:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7cda:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    7cde:	ba 01 00 00 00       	mov    $0x1,%edx
    7ce3:	48 85 db             	test   %rbx,%rbx
    7ce6:	74 15                	je     7cfd <f37+0xcd>
    7ce8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7cef:	00 
    7cf0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7cf4:	48 83 c2 01          	add    $0x1,%rdx
    7cf8:	48 85 db             	test   %rbx,%rbx
    7cfb:	75 f3                	jne    7cf0 <f37+0xc0>
    7cfd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7d02:	48 85 c0             	test   %rax,%rax
    7d05:	0f 84 65 03 00 00    	je     8070 <f37+0x440>
    7d0b:	31 db                	xor    %ebx,%ebx
    7d0d:	0f 1f 00             	nopl   (%rax)
    7d10:	48 8b 40 10          	mov    0x10(%rax),%rax
    7d14:	48 83 c3 01          	add    $0x1,%rbx
    7d18:	48 85 c0             	test   %rax,%rax
    7d1b:	75 f3                	jne    7d10 <f37+0xe0>
    7d1d:	48 39 d3             	cmp    %rdx,%rbx
    7d20:	48 0f 47 da          	cmova  %rdx,%rbx
    7d24:	48 89 d8             	mov    %rbx,%rax
    7d27:	48 c1 e8 3c          	shr    $0x3c,%rax
    7d2b:	0f 85 e3 03 00 00    	jne    8114 <f37+0x4e4>
    7d31:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7d35:	be 02 00 00 00       	mov    $0x2,%esi
    7d3a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7d41:	00 
    7d42:	e8 49 df ff ff       	call   5c90 <fwp_heap_alloc>
    7d47:	48 89 28             	mov    %rbp,(%rax)
    7d4a:	48 8b 15 47 9e 01 00 	mov    0x19e47(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7d51:	49 89 c4             	mov    %rax,%r12
    7d54:	48 2b 05 15 9e 01 00 	sub    0x19e15(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7d5b:	48 c1 e2 10          	shl    $0x10,%rdx
    7d5f:	48 39 d0             	cmp    %rdx,%rax
    7d62:	73 57                	jae    7dbb <f37+0x18b>
    7d64:	48 89 c2             	mov    %rax,%rdx
    7d67:	48 c1 ea 10          	shr    $0x10,%rdx
    7d6b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d6f:	48 8b 15 42 9e 01 00 	mov    0x19e42(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    7d76:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d7a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7d7e:	48 85 ed             	test   %rbp,%rbp
    7d81:	74 38                	je     7dbb <f37+0x18b>
    7d83:	0f b6 0a             	movzbl (%rdx),%ecx
    7d86:	80 f9 02             	cmp    $0x2,%cl
    7d89:	0f 84 a1 02 00 00    	je     8030 <f37+0x400>
    7d8f:	80 f9 01             	cmp    $0x1,%cl
    7d92:	75 27                	jne    7dbb <f37+0x18b>
    7d94:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d97:	0f b7 c0             	movzwl %ax,%eax
    7d9a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d9d:	48 0f af c1          	imul   %rcx,%rax
    7da1:	48 c1 e8 20          	shr    $0x20,%rax
    7da5:	48 39 d0             	cmp    %rdx,%rax
    7da8:	73 11                	jae    7dbb <f37+0x18b>
    7daa:	48 01 c5             	add    %rax,%rbp
    7dad:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7db1:	0f 84 29 03 00 00    	je     80e0 <f37+0x4b0>
    7db7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7dbb:	48 85 db             	test   %rbx,%rbx
    7dbe:	74 5d                	je     7e1d <f37+0x1ed>
    7dc0:	48 c1 e3 04          	shl    $0x4,%rbx
    7dc4:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    7dc9:	4c 89 e5             	mov    %r12,%rbp
    7dcc:	4d 89 ee             	mov    %r13,%r14
    7dcf:	4c 01 e3             	add    %r12,%rbx
    7dd2:	0f 1f 00             	nopl   (%rax)
    7dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7ddc:	00 00 00 00 
    7de0:	49 8b 46 08          	mov    0x8(%r14),%rax
    7de4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    7de8:	48 83 c5 10          	add    $0x10,%rbp
    7dec:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    7df1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    7df5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    7df9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    7dfe:	e8 5d e4 ff ff       	call   6260 <w120>
    7e03:	66 48 0f 6e d0       	movq   %rax,%xmm2
    7e08:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    7e0c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    7e10:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    7e14:	4d 8b 76 10          	mov    0x10(%r14),%r14
    7e18:	48 39 eb             	cmp    %rbp,%rbx
    7e1b:	75 c3                	jne    7de0 <f37+0x1b0>
    7e1d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7e22:	31 db                	xor    %ebx,%ebx
    7e24:	e8 c7 ed ff ff       	call   6bf0 <fwp_drop4>
    7e29:	4c 89 ef             	mov    %r13,%rdi
    7e2c:	e8 bf ed ff ff       	call   6bf0 <fwp_drop4>
    7e31:	4d 8b 2c 24          	mov    (%r12),%r13
    7e35:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7e39:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    7e40:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    7e47:	4d 85 ed             	test   %r13,%r13
    7e4a:	74 3f                	je     7e8b <f37+0x25b>
    7e4c:	0f 1f 40 00          	nopl   0x0(%rax)
    7e50:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    7e57:	49 8b 54 dc 10       	mov    0x10(%r12,%rbx,8),%rdx
    7e5c:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    7e63:	00 f0 3f 
    7e66:	48 83 c3 02          	add    $0x2,%rbx
    7e6a:	48 89 ce             	mov    %rcx,%rsi
    7e6d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    7e73:	e8 68 e0 ff ff       	call   5ee0 <fwp_p_ad_push>
    7e78:	4c 39 eb             	cmp    %r13,%rbx
    7e7b:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    7e81:	48 89 c7             	mov    %rax,%rdi
    7e84:	72 ca                	jb     7e50 <f37+0x220>
    7e86:	66 49 0f 7e c5       	movq   %xmm0,%r13
    7e8b:	4c 89 e7             	mov    %r12,%rdi
    7e8e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7e93:	e8 38 fb ff ff       	call   79d0 <fwp_drop10>
    7e98:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7e9d:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7ea2:	31 ff                	xor    %edi,%edi
    7ea4:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    7ea9:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    7eae:	e8 fd de ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    7eb3:	48 8b 15 de 9c 01 00 	mov    0x19cde(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7eba:	48 89 c5             	mov    %rax,%rbp
    7ebd:	48 2b 05 ac 9c 01 00 	sub    0x19cac(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7ec4:	48 c1 e2 10          	shl    $0x10,%rdx
    7ec8:	48 39 d0             	cmp    %rdx,%rax
    7ecb:	73 55                	jae    7f22 <f37+0x2f2>
    7ecd:	48 89 c2             	mov    %rax,%rdx
    7ed0:	48 c1 ea 10          	shr    $0x10,%rdx
    7ed4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7ed8:	48 8b 15 d9 9c 01 00 	mov    0x19cd9(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    7edf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ee3:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    7ee7:	48 85 db             	test   %rbx,%rbx
    7eea:	74 36                	je     7f22 <f37+0x2f2>
    7eec:	0f b6 0a             	movzbl (%rdx),%ecx
    7eef:	80 f9 02             	cmp    $0x2,%cl
    7ef2:	0f 84 20 01 00 00    	je     8018 <f37+0x3e8>
    7ef8:	80 f9 01             	cmp    $0x1,%cl
    7efb:	75 25                	jne    7f22 <f37+0x2f2>
    7efd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7f00:	0f b7 c0             	movzwl %ax,%eax
    7f03:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7f06:	48 0f af c1          	imul   %rcx,%rax
    7f0a:	48 c1 e8 20          	shr    $0x20,%rax
    7f0e:	48 39 d0             	cmp    %rdx,%rax
    7f11:	73 0f                	jae    7f22 <f37+0x2f2>
    7f13:	48 01 c3             	add    %rax,%rbx
    7f16:	80 3b ff             	cmpb   $0xff,(%rbx)
    7f19:	0f 84 b4 01 00 00    	je     80d3 <f37+0x4a3>
    7f1f:	c6 03 01             	movb   $0x1,(%rbx)
    7f22:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7f27:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7f2e:	00 00 
    7f30:	0f 85 d9 01 00 00    	jne    810f <f37+0x4df>
    7f36:	48 83 c4 38          	add    $0x38,%rsp
    7f3a:	48 89 e8             	mov    %rbp,%rax
    7f3d:	5b                   	pop    %rbx
    7f3e:	5d                   	pop    %rbp
    7f3f:	41 5c                	pop    %r12
    7f41:	41 5d                	pop    %r13
    7f43:	41 5e                	pop    %r14
    7f45:	41 5f                	pop    %r15
    7f47:	c3                   	ret
    7f48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7f4f:	00 
    7f50:	66 85 c0             	test   %ax,%ax
    7f53:	0f 85 7c fd ff ff    	jne    7cd5 <f37+0xa5>
    7f59:	0f b6 07             	movzbl (%rdi),%eax
    7f5c:	84 c0                	test   %al,%al
    7f5e:	0f 84 71 fd ff ff    	je     7cd5 <f37+0xa5>
    7f64:	3c fd                	cmp    $0xfd,%al
    7f66:	0f 87 99 01 00 00    	ja     8105 <f37+0x4d5>
    7f6c:	83 c0 01             	add    $0x1,%eax
    7f6f:	88 07                	mov    %al,(%rdi)
    7f71:	e9 5f fd ff ff       	jmp    7cd5 <f37+0xa5>
    7f76:	48 f7 d9             	neg    %rcx
    7f79:	48 39 d1             	cmp    %rdx,%rcx
    7f7c:	0f 83 ee 00 00 00    	jae    8070 <f37+0x440>
    7f82:	48 89 c8             	mov    %rcx,%rax
    7f85:	48 c1 e8 10          	shr    $0x10,%rax
    7f89:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7f8d:	48 8b 05 24 9c 01 00 	mov    0x19c24(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    7f94:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7f98:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7f9c:	48 85 ff             	test   %rdi,%rdi
    7f9f:	0f 84 cb 00 00 00    	je     8070 <f37+0x440>
    7fa5:	0f b6 02             	movzbl (%rdx),%eax
    7fa8:	3c 02                	cmp    $0x2,%al
    7faa:	0f 84 9a 00 00 00    	je     804a <f37+0x41a>
    7fb0:	3c 01                	cmp    $0x1,%al
    7fb2:	0f 85 b8 00 00 00    	jne    8070 <f37+0x440>
    7fb8:	0f b7 c1             	movzwl %cx,%eax
    7fbb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7fbe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7fc1:	48 0f af c1          	imul   %rcx,%rax
    7fc5:	48 c1 e8 20          	shr    $0x20,%rax
    7fc9:	48 39 d0             	cmp    %rdx,%rax
    7fcc:	0f 83 9e 00 00 00    	jae    8070 <f37+0x440>
    7fd2:	48 01 c7             	add    %rax,%rdi
    7fd5:	0f b6 07             	movzbl (%rdi),%eax
    7fd8:	84 c0                	test   %al,%al
    7fda:	0f 84 90 00 00 00    	je     8070 <f37+0x440>
    7fe0:	31 db                	xor    %ebx,%ebx
    7fe2:	0f 1f 00             	nopl   (%rax)
    7fe5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7fec:	00 00 00 00 
    7ff0:	3c fd                	cmp    $0xfd,%al
    7ff2:	0f 87 f5 00 00 00    	ja     80ed <f37+0x4bd>
    7ff8:	83 c0 01             	add    $0x1,%eax
    7ffb:	88 07                	mov    %al,(%rdi)
    7ffd:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8002:	31 d2                	xor    %edx,%edx
    8004:	4d 85 ed             	test   %r13,%r13
    8007:	0f 85 cd fc ff ff    	jne    7cda <f37+0xaa>
    800d:	e9 eb fc ff ff       	jmp    7cfd <f37+0xcd>
    8012:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8018:	66 85 c0             	test   %ax,%ax
    801b:	0f 85 01 ff ff ff    	jne    7f22 <f37+0x2f2>
    8021:	e9 f0 fe ff ff       	jmp    7f16 <f37+0x2e6>
    8026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    802d:	00 00 00 
    8030:	66 85 c0             	test   %ax,%ax
    8033:	0f 85 82 fd ff ff    	jne    7dbb <f37+0x18b>
    8039:	e9 6f fd ff ff       	jmp    7dad <f37+0x17d>
    803e:	66 90                	xchg   %ax,%ax
    8040:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8045:	e9 94 fc ff ff       	jmp    7cde <f37+0xae>
    804a:	66 85 c9             	test   %cx,%cx
    804d:	75 21                	jne    8070 <f37+0x440>
    804f:	0f b6 07             	movzbl (%rdi),%eax
    8052:	84 c0                	test   %al,%al
    8054:	74 1a                	je     8070 <f37+0x440>
    8056:	3c fd                	cmp    $0xfd,%al
    8058:	0f 87 c2 00 00 00    	ja     8120 <f37+0x4f0>
    805e:	83 c0 01             	add    $0x1,%eax
    8061:	88 07                	mov    %al,(%rdi)
    8063:	66 90                	xchg   %ax,%ax
    8065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    806c:	00 00 00 00 
    8070:	be 02 00 00 00       	mov    $0x2,%esi
    8075:	bf 08 00 00 00       	mov    $0x8,%edi
    807a:	e8 11 dc ff ff       	call   5c90 <fwp_heap_alloc>
    807f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8086:	48 8b 15 0b 9b 01 00 	mov    0x19b0b(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    808d:	49 89 c4             	mov    %rax,%r12
    8090:	48 2b 05 d9 9a 01 00 	sub    0x19ad9(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    8097:	48 c1 e2 10          	shl    $0x10,%rdx
    809b:	48 39 d0             	cmp    %rdx,%rax
    809e:	73 57                	jae    80f7 <f37+0x4c7>
    80a0:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    80a7:	00 00 
    80a9:	48 89 c2             	mov    %rax,%rdx
    80ac:	48 c1 ea 10          	shr    $0x10,%rdx
    80b0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    80b4:	48 8b 15 fd 9a 01 00 	mov    0x19afd(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    80bb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    80bf:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    80c3:	48 85 ed             	test   %rbp,%rbp
    80c6:	0f 84 51 fd ff ff    	je     7e1d <f37+0x1ed>
    80cc:	31 db                	xor    %ebx,%ebx
    80ce:	e9 b0 fc ff ff       	jmp    7d83 <f37+0x153>
    80d3:	48 89 df             	mov    %rbx,%rdi
    80d6:	e8 75 d4 ff ff       	call   5550 <fwp_rc_forget_slot>
    80db:	e9 3f fe ff ff       	jmp    7f1f <f37+0x2ef>
    80e0:	48 89 ef             	mov    %rbp,%rdi
    80e3:	e8 68 d4 ff ff       	call   5550 <fwp_rc_forget_slot>
    80e8:	e9 ca fc ff ff       	jmp    7db7 <f37+0x187>
    80ed:	e8 3e d3 ff ff       	call   5430 <fwp_rc_wide_dup>
    80f2:	e9 06 ff ff ff       	jmp    7ffd <f37+0x3cd>
    80f7:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    80fe:	00 00 
    8100:	e9 18 fd ff ff       	jmp    7e1d <f37+0x1ed>
    8105:	e8 26 d3 ff ff       	call   5430 <fwp_rc_wide_dup>
    810a:	e9 c6 fb ff ff       	jmp    7cd5 <f37+0xa5>
    810f:	e8 4c b3 ff ff       	call   3460 <__stack_chk_fail@plt>
    8114:	48 8d 3d 75 40 00 00 	lea    0x4075(%rip),%rdi        # c190 <_IO_stdin_used+0x190>
    811b:	e8 d0 c2 ff ff       	call   43f0 <fwp_trap>
    8120:	e8 0b d3 ff ff       	call   5430 <fwp_rc_wide_dup>
    8125:	e9 46 ff ff ff       	jmp    8070 <f37+0x440>
    812a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000008130 <fwp_owned_entry37>:
    8130:	f3 0f 1e fa          	endbr64
    8134:	48 8b 3f             	mov    (%rdi),%rdi
    8137:	e9 f4 fa ff ff       	jmp    7c30 <f37>
    813c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008140 <e37>:
    8140:	f3 0f 1e fa          	endbr64
    8144:	53                   	push   %rbx
    8145:	48 8b 1f             	mov    (%rdi),%rbx
    8148:	48 89 df             	mov    %rbx,%rdi
    814b:	e8 80 e2 ff ff       	call   63d0 <fwp_rc_share>
    8150:	48 89 df             	mov    %rbx,%rdi
    8153:	e8 d8 fa ff ff       	call   7c30 <f37>
    8158:	48 89 c3             	mov    %rax,%rbx
    815b:	48 89 c7             	mov    %rax,%rdi
    815e:	e8 6d e2 ff ff       	call   63d0 <fwp_rc_share>
    8163:	48 89 d8             	mov    %rbx,%rax
    8166:	5b                   	pop    %rbx
    8167:	c3                   	ret
    8168:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    816f:	00 

0000000000008170 <fwp_write>:
    8170:	41 57                	push   %r15
    8172:	41 56                	push   %r14
    8174:	41 55                	push   %r13
    8176:	41 54                	push   %r12
    8178:	55                   	push   %rbp
    8179:	53                   	push   %rbx
    817a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8181:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8188:	00 00 
    818a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8191:	00 
    8192:	49 89 d4             	mov    %rdx,%r12
    8195:	8b 12                	mov    (%rdx),%edx
    8197:	83 fa 19             	cmp    $0x19,%edx
    819a:	77 6a                	ja     8206 <fwp_write+0x96>
    819c:	48 89 f5             	mov    %rsi,%rbp
    819f:	89 d0                	mov    %edx,%eax
    81a1:	89 ce                	mov    %ecx,%esi
    81a3:	48 89 fb             	mov    %rdi,%rbx
    81a6:	48 8d 0d 53 49 00 00 	lea    0x4953(%rip),%rcx        # cb00 <_IO_stdin_used+0xb00>
    81ad:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    81b1:	48 01 c8             	add    %rcx,%rax
    81b4:	3e ff e0             	notrack jmp *%rax
    81b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    81be:	00 00 
    81c0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    81c4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    81c8:	48 89 ca             	mov    %rcx,%rdx
    81cb:	48 85 c9             	test   %rcx,%rcx
    81ce:	0f 88 9c 0c 00 00    	js     8e70 <fwp_write+0xd00>
    81d4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    81db:	00 
    81dc:	48 89 c6             	mov    %rax,%rsi
    81df:	4c 89 e7             	mov    %r12,%rdi
    81e2:	e8 59 b8 ff ff       	call   3a40 <fwp_fmt_u128>
    81e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    81ee:	00 00 
    81f0:	4c 89 e7             	mov    %r12,%rdi
    81f3:	e8 58 b2 ff ff       	call   3450 <strlen@plt>
    81f8:	4c 89 e6             	mov    %r12,%rsi
    81fb:	48 89 df             	mov    %rbx,%rdi
    81fe:	48 89 c2             	mov    %rax,%rdx
    8201:	e8 0a c0 ff ff       	call   4210 <buf_put>
    8206:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    820d:	00 
    820e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8215:	00 00 
    8217:	0f 85 28 04 00 00    	jne    8645 <fwp_write+0x4d5>
    821d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8224:	5b                   	pop    %rbx
    8225:	5d                   	pop    %rbp
    8226:	41 5c                	pop    %r12
    8228:	41 5d                	pop    %r13
    822a:	41 5e                	pop    %r14
    822c:	41 5f                	pop    %r15
    822e:	c3                   	ret
    822f:	90                   	nop
    8230:	49 89 e9             	mov    %rbp,%r9
    8233:	4c 8d 05 3b 3e 00 00 	lea    0x3e3b(%rip),%r8        # c075 <_IO_stdin_used+0x75>
    823a:	b9 00 02 00 00       	mov    $0x200,%ecx
    823f:	ba 02 00 00 00       	mov    $0x2,%edx
    8244:	be 00 02 00 00       	mov    $0x200,%esi
    8249:	31 c0                	xor    %eax,%eax
    824b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8252:	00 
    8253:	e8 58 b1 ff ff       	call   33b0 <__snprintf_chk@plt>
    8258:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    825f:	00 
    8260:	e8 eb b1 ff ff       	call   3450 <strlen@plt>
    8265:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    826c:	00 
    826d:	48 89 df             	mov    %rbx,%rdi
    8270:	48 89 c2             	mov    %rax,%rdx
    8273:	e8 98 bf ff ff       	call   4210 <buf_put>
    8278:	eb 8c                	jmp    8206 <fwp_write+0x96>
    827a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8280:	49 89 e9             	mov    %rbp,%r9
    8283:	4c 8d 05 2b 3f 00 00 	lea    0x3f2b(%rip),%r8        # c1b5 <_IO_stdin_used+0x1b5>
    828a:	eb ae                	jmp    823a <fwp_write+0xca>
    828c:	0f 1f 40 00          	nopl   0x0(%rax)
    8290:	83 fa 13             	cmp    $0x13,%edx
    8293:	48 8d 05 11 3f 00 00 	lea    0x3f11(%rip),%rax        # c1ab <_IO_stdin_used+0x1ab>
    829a:	48 8d 35 0f 3f 00 00 	lea    0x3f0f(%rip),%rsi        # c1b0 <_IO_stdin_used+0x1b0>
    82a1:	ba 04 00 00 00       	mov    $0x4,%edx
    82a6:	48 0f 44 f0          	cmove  %rax,%rsi
    82aa:	45 31 ed             	xor    %r13d,%r13d
    82ad:	e8 5e bf ff ff       	call   4210 <buf_put>
    82b2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    82b7:	0f 84 a3 08 00 00    	je     8b60 <fwp_write+0x9f0>
    82bd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    82c2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    82c7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    82cc:	48 89 df             	mov    %rbx,%rdi
    82cf:	49 0f 44 c5          	cmove  %r13,%rax
    82d3:	31 c9                	xor    %ecx,%ecx
    82d5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    82da:	e8 91 fe ff ff       	call   8170 <fwp_write>
    82df:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    82e4:	0f 84 6e 09 00 00    	je     8c58 <fwp_write+0xae8>
    82ea:	49 83 c5 01          	add    $0x1,%r13
    82ee:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    82f2:	0f 83 68 08 00 00    	jae    8b60 <fwp_write+0x9f0>
    82f8:	ba 02 00 00 00       	mov    $0x2,%edx
    82fd:	48 8d 35 f1 3e 00 00 	lea    0x3ef1(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    8304:	48 89 df             	mov    %rbx,%rdi
    8307:	e8 04 bf ff ff       	call   4210 <buf_put>
    830c:	eb af                	jmp    82bd <fwp_write+0x14d>
    830e:	66 90                	xchg   %ax,%ax
    8310:	ba 06 00 00 00       	mov    $0x6,%edx
    8315:	48 8d 35 b2 3e 00 00 	lea    0x3eb2(%rip),%rsi        # c1ce <_IO_stdin_used+0x1ce>
    831c:	48 83 c5 10          	add    $0x10,%rbp
    8320:	e8 eb be ff ff       	call   4210 <buf_put>
    8325:	48 89 ef             	mov    %rbp,%rdi
    8328:	e8 23 b1 ff ff       	call   3450 <strlen@plt>
    832d:	48 89 ee             	mov    %rbp,%rsi
    8330:	48 89 df             	mov    %rbx,%rdi
    8333:	48 89 c2             	mov    %rax,%rdx
    8336:	e8 d5 be ff ff       	call   4210 <buf_put>
    833b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8340:	ba 01 00 00 00       	mov    $0x1,%edx
    8345:	48 89 df             	mov    %rbx,%rdi
    8348:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    834d:	e8 be be ff ff       	call   4210 <buf_put>
    8352:	e9 af fe ff ff       	jmp    8206 <fwp_write+0x96>
    8357:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    835e:	00 00 
    8360:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8367:	00 
    8368:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    836f:	00 00 
    8371:	0f 85 ce 02 00 00    	jne    8645 <fwp_write+0x4d5>
    8377:	ba 0a 00 00 00       	mov    $0xa,%edx
    837c:	48 8d 35 37 3e 00 00 	lea    0x3e37(%rip),%rsi        # c1ba <_IO_stdin_used+0x1ba>
    8383:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    838a:	48 89 df             	mov    %rbx,%rdi
    838d:	5b                   	pop    %rbx
    838e:	5d                   	pop    %rbp
    838f:	41 5c                	pop    %r12
    8391:	41 5d                	pop    %r13
    8393:	41 5e                	pop    %r14
    8395:	41 5f                	pop    %r15
    8397:	e9 74 be ff ff       	jmp    4210 <buf_put>
    839c:	0f 1f 40 00          	nopl   0x0(%rax)
    83a0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    83a5:	4d 85 ed             	test   %r13,%r13
    83a8:	0f 84 02 0c 00 00    	je     8fb0 <fwp_write+0xe40>
    83ae:	48 8d 35 4d 3e 00 00 	lea    0x3e4d(%rip),%rsi        # c202 <_IO_stdin_used+0x202>
    83b5:	4c 89 ef             	mov    %r13,%rdi
    83b8:	e8 73 b1 ff ff       	call   3530 <strcmp@plt>
    83bd:	41 89 c1             	mov    %eax,%r9d
    83c0:	85 c0                	test   %eax,%eax
    83c2:	0f 84 6c 0c 00 00    	je     9034 <fwp_write+0xec4>
    83c8:	4c 89 ef             	mov    %r13,%rdi
    83cb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    83d0:	e8 7b b0 ff ff       	call   3450 <strlen@plt>
    83d5:	4c 89 ee             	mov    %r13,%rsi
    83d8:	48 89 df             	mov    %rbx,%rdi
    83db:	48 89 c2             	mov    %rax,%rdx
    83de:	e8 2d be ff ff       	call   4210 <buf_put>
    83e3:	ba 01 00 00 00       	mov    $0x1,%edx
    83e8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    83ed:	48 89 df             	mov    %rbx,%rdi
    83f0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    83f5:	e8 16 be ff ff       	call   4210 <buf_put>
    83fa:	ba 01 00 00 00       	mov    $0x1,%edx
    83ff:	4c 89 fe             	mov    %r15,%rsi
    8402:	48 89 df             	mov    %rbx,%rdi
    8405:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    840a:	e8 01 be ff ff       	call   4210 <buf_put>
    840f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8414:	45 31 f6             	xor    %r14d,%r14d
    8417:	85 d2                	test   %edx,%edx
    8419:	0f 8e 81 0a 00 00    	jle    8ea0 <fwp_write+0xd30>
    841f:	45 31 ed             	xor    %r13d,%r13d
    8422:	4d 85 ed             	test   %r13,%r13
    8425:	0f 85 75 07 00 00    	jne    8ba0 <fwp_write+0xa30>
    842b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8432:	00 
    8433:	45 85 f6             	test   %r14d,%r14d
    8436:	0f 84 84 07 00 00    	je     8bc0 <fwp_write+0xa50>
    843c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8441:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8446:	48 89 df             	mov    %rbx,%rdi
    8449:	49 83 c5 01          	add    $0x1,%r13
    844d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8451:	31 c9                	xor    %ecx,%ecx
    8453:	e8 18 fd ff ff       	call   8170 <fwp_write>
    8458:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    845d:	7f c3                	jg     8422 <fwp_write+0x2b2>
    845f:	45 85 f6             	test   %r14d,%r14d
    8462:	0f 84 38 0a 00 00    	je     8ea0 <fwp_write+0xd30>
    8468:	b8 29 00 00 00       	mov    $0x29,%eax
    846d:	ba 01 00 00 00       	mov    $0x1,%edx
    8472:	4c 89 fe             	mov    %r15,%rsi
    8475:	48 89 df             	mov    %rbx,%rdi
    8478:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    847c:	e8 8f bd ff ff       	call   4210 <buf_put>
    8481:	e9 80 fd ff ff       	jmp    8206 <fwp_write+0x96>
    8486:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    848d:	00 00 00 
    8490:	ba 01 00 00 00       	mov    $0x1,%edx
    8495:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    849a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    849f:	e8 6c bd ff ff       	call   4210 <buf_put>
    84a4:	48 85 ed             	test   %rbp,%rbp
    84a7:	0f 84 93 06 00 00    	je     8b40 <fwp_write+0x9d0>
    84ad:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    84b1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    84b6:	31 c9                	xor    %ecx,%ecx
    84b8:	48 89 df             	mov    %rbx,%rdi
    84bb:	e8 b0 fc ff ff       	call   8170 <fwp_write>
    84c0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    84c4:	48 85 ed             	test   %rbp,%rbp
    84c7:	0f 84 73 06 00 00    	je     8b40 <fwp_write+0x9d0>
    84cd:	ba 02 00 00 00       	mov    $0x2,%edx
    84d2:	48 8d 35 1c 3d 00 00 	lea    0x3d1c(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    84d9:	48 89 df             	mov    %rbx,%rdi
    84dc:	e8 2f bd ff ff       	call   4210 <buf_put>
    84e1:	eb ca                	jmp    84ad <fwp_write+0x33d>
    84e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    84e8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    84ec:	85 f6                	test   %esi,%esi
    84ee:	0f 84 fc 07 00 00    	je     8cf0 <fwp_write+0xb80>
    84f4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    84fb:	00 
    84fc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8503:	00 00 
    8505:	0f 85 3a 01 00 00    	jne    8645 <fwp_write+0x4d5>
    850b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    850f:	4c 89 ea             	mov    %r13,%rdx
    8512:	e9 6c fe ff ff       	jmp    8383 <fwp_write+0x213>
    8517:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    851e:	00 00 
    8520:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8525:	ba 01 00 00 00       	mov    $0x1,%edx
    852a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    852f:	48 89 ee             	mov    %rbp,%rsi
    8532:	e8 d9 bc ff ff       	call   4210 <buf_put>
    8537:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    853c:	4c 89 e7             	mov    %r12,%rdi
    853f:	e8 0c af ff ff       	call   3450 <strlen@plt>
    8544:	4c 89 e6             	mov    %r12,%rsi
    8547:	48 89 df             	mov    %rbx,%rdi
    854a:	48 89 c2             	mov    %rax,%rdx
    854d:	e8 be bc ff ff       	call   4210 <buf_put>
    8552:	ba 01 00 00 00       	mov    $0x1,%edx
    8557:	48 89 ee             	mov    %rbp,%rsi
    855a:	48 89 df             	mov    %rbx,%rdi
    855d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8562:	e8 a9 bc ff ff       	call   4210 <buf_put>
    8567:	e9 9a fc ff ff       	jmp    8206 <fwp_write+0x96>
    856c:	0f 1f 40 00          	nopl   0x0(%rax)
    8570:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8575:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8579:	0f 8a 8e 0b 00 00    	jp     910d <fwp_write+0xf9d>
    857f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8583:	66 0f 54 05 a5 46 00 	andpd  0x46a5(%rip),%xmm0        # cc30 <msg.4+0xc0>
    858a:	00 
    858b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8590:	66 0f 2e 05 10 46 00 	ucomisd 0x4610(%rip),%xmm0        # cba8 <msg.4+0x38>
    8597:	00 
    8598:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    859f:	00 
    85a0:	0f 87 b2 09 00 00    	ja     8f58 <fwp_write+0xde8>
    85a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    85ad:	00 00 00 
    85b0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    85b4:	89 ee                	mov    %ebp,%esi
    85b6:	4c 89 e7             	mov    %r12,%rdi
    85b9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    85be:	e8 4d c1 ff ff       	call   4710 <fwp_format_g.constprop.0>
    85c3:	31 f6                	xor    %esi,%esi
    85c5:	4c 89 e7             	mov    %r12,%rdi
    85c8:	e8 43 ae ff ff       	call   3410 <strtod@plt>
    85cd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    85d2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    85d6:	7a 06                	jp     85de <fwp_write+0x46e>
    85d8:	0f 84 e9 01 00 00    	je     87c7 <fwp_write+0x657>
    85de:	83 c5 01             	add    $0x1,%ebp
    85e1:	83 fd 12             	cmp    $0x12,%ebp
    85e4:	75 ca                	jne    85b0 <fwp_write+0x440>
    85e6:	be 11 00 00 00       	mov    $0x11,%esi
    85eb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    85ef:	4c 89 e7             	mov    %r12,%rdi
    85f2:	e8 19 c1 ff ff       	call   4710 <fwp_format_g.constprop.0>
    85f7:	e9 cb 01 00 00       	jmp    87c7 <fwp_write+0x657>
    85fc:	0f 1f 40 00          	nopl   0x0(%rax)
    8600:	48 83 fd 01          	cmp    $0x1,%rbp
    8604:	0f 84 e6 08 00 00    	je     8ef0 <fwp_write+0xd80>
    860a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    860e:	b8 02 00 00 00       	mov    $0x2,%eax
    8613:	ba 01 00 00 00       	mov    $0x1,%edx
    8618:	48 0f 44 d0          	cmove  %rax,%rdx
    861c:	48 8d 35 80 3b 00 00 	lea    0x3b80(%rip),%rsi        # c1a3 <_IO_stdin_used+0x1a3>
    8623:	48 8d 05 7e 3b 00 00 	lea    0x3b7e(%rip),%rax        # c1a8 <_IO_stdin_used+0x1a8>
    862a:	48 0f 44 f0          	cmove  %rax,%rsi
    862e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8635:	00 
    8636:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    863d:	00 00 
    863f:	0f 84 3e fd ff ff    	je     8383 <fwp_write+0x213>
    8645:	e8 16 ae ff ff       	call   3460 <__stack_chk_fail@plt>
    864a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8650:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8655:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    865a:	e8 f1 ba ff ff       	call   4150 <buf_grow>
    865f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8663:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8669:	4c 03 0b             	add    (%rbx),%r9
    866c:	66 45 89 11          	mov    %r10w,(%r9)
    8670:	45 85 e4             	test   %r12d,%r12d
    8673:	0f 8e 07 05 00 00    	jle    8b80 <fwp_write+0xa10>
    8679:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8680:	55 55 55 
    8683:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8688:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    868f:	aa aa aa 
    8692:	49 83 c1 01          	add    $0x1,%r9
    8696:	eb 45                	jmp    86dd <fwp_write+0x56d>
    8698:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    869f:	00 
    86a0:	be 01 00 00 00       	mov    $0x1,%esi
    86a5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    86aa:	88 07                	mov    %al,(%rdi)
    86ac:	48 89 e8             	mov    %rbp,%rax
    86af:	49 f7 e8             	imul   %r8
    86b2:	48 89 e8             	mov    %rbp,%rax
    86b5:	48 c1 f8 3f          	sar    $0x3f,%rax
    86b9:	48 29 c2             	sub    %rax,%rdx
    86bc:	48 85 c9             	test   %rcx,%rcx
    86bf:	0f 95 c0             	setne  %al
    86c2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    86c6:	48 83 ef 01          	sub    $0x1,%rdi
    86ca:	48 21 c5             	and    %rax,%rbp
    86cd:	48 29 ea             	sub    %rbp,%rdx
    86d0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    86d4:	49 39 f9             	cmp    %rdi,%r9
    86d7:	0f 84 a3 04 00 00    	je     8b80 <fwp_write+0xa10>
    86dd:	48 89 e8             	mov    %rbp,%rax
    86e0:	49 f7 e8             	imul   %r8
    86e3:	48 89 e8             	mov    %rbp,%rax
    86e6:	48 c1 f8 3f          	sar    $0x3f,%rax
    86ea:	48 89 d1             	mov    %rdx,%rcx
    86ed:	48 29 c1             	sub    %rax,%rcx
    86f0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    86f4:	48 89 e9             	mov    %rbp,%rcx
    86f7:	48 29 c1             	sub    %rax,%rcx
    86fa:	48 8d 41 03          	lea    0x3(%rcx),%rax
    86fe:	49 f7 e2             	mul    %r10
    8701:	b8 30 00 00 00       	mov    $0x30,%eax
    8706:	48 89 d6             	mov    %rdx,%rsi
    8709:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    870d:	48 d1 ee             	shr    $1,%rsi
    8710:	48 01 f2             	add    %rsi,%rdx
    8713:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8717:	48 29 d6             	sub    %rdx,%rsi
    871a:	74 8e                	je     86aa <fwp_write+0x53a>
    871c:	48 83 fe 01          	cmp    $0x1,%rsi
    8720:	0f 85 7a ff ff ff    	jne    86a0 <fwp_write+0x530>
    8726:	31 f6                	xor    %esi,%esi
    8728:	b8 2b 00 00 00       	mov    $0x2b,%eax
    872d:	e9 78 ff ff ff       	jmp    86aa <fwp_write+0x53a>
    8732:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8738:	66 0f 6e cd          	movd   %ebp,%xmm1
    873c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    873f:	0f 8a c8 09 00 00    	jp     910d <fwp_write+0xf9d>
    8745:	0f 28 c1             	movaps %xmm1,%xmm0
    8748:	0f 54 05 d1 44 00 00 	andps  0x44d1(%rip),%xmm0        # cc20 <msg.4+0xb0>
    874f:	0f 2e 05 ae 38 00 00 	ucomiss 0x38ae(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    8756:	0f 87 24 08 00 00    	ja     8f80 <fwp_write+0xe10>
    875c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8760:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8766:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    876d:	00 
    876e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8772:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8777:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    877e:	00 00 
    8780:	44 89 ee             	mov    %r13d,%esi
    8783:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8788:	4c 89 e7             	mov    %r12,%rdi
    878b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8790:	e8 7b bf ff ff       	call   4710 <fwp_format_g.constprop.0>
    8795:	31 f6                	xor    %esi,%esi
    8797:	4c 89 e7             	mov    %r12,%rdi
    879a:	e8 11 ad ff ff       	call   34b0 <strtof@plt>
    879f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    87a4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    87a7:	7a 02                	jp     87ab <fwp_write+0x63b>
    87a9:	74 1c                	je     87c7 <fwp_write+0x657>
    87ab:	41 83 c5 01          	add    $0x1,%r13d
    87af:	41 83 fd 0a          	cmp    $0xa,%r13d
    87b3:	75 cb                	jne    8780 <fwp_write+0x610>
    87b5:	be 09 00 00 00       	mov    $0x9,%esi
    87ba:	66 49 0f 6e c7       	movq   %r15,%xmm0
    87bf:	4c 89 e7             	mov    %r12,%rdi
    87c2:	e8 49 bf ff ff       	call   4710 <fwp_format_g.constprop.0>
    87c7:	4c 89 e7             	mov    %r12,%rdi
    87ca:	e8 b1 bb ff ff       	call   4380 <fwp_finish_float>
    87cf:	e9 1c fa ff ff       	jmp    81f0 <fwp_write+0x80>
    87d4:	0f 1f 40 00          	nopl   0x0(%rax)
    87d8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    87dc:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    87e0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    87e7:	00 
    87e8:	48 89 ef             	mov    %rbp,%rdi
    87eb:	e8 50 b2 ff ff       	call   3a40 <fwp_fmt_u128>
    87f0:	48 89 ef             	mov    %rbp,%rdi
    87f3:	e8 58 ac ff ff       	call   3450 <strlen@plt>
    87f8:	48 89 ee             	mov    %rbp,%rsi
    87fb:	48 89 df             	mov    %rbx,%rdi
    87fe:	48 89 c2             	mov    %rax,%rdx
    8801:	e8 0a ba ff ff       	call   4210 <buf_put>
    8806:	e9 fb f9 ff ff       	jmp    8206 <fwp_write+0x96>
    880b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8810:	ba 06 00 00 00       	mov    $0x6,%edx
    8815:	48 8d 35 dc 39 00 00 	lea    0x39dc(%rip),%rsi        # c1f8 <_IO_stdin_used+0x1f8>
    881c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8822:	e8 e9 b9 ff ff       	call   4210 <buf_put>
    8827:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    882e:	ff ff 7f 
    8831:	48 23 55 00          	and    0x0(%rbp),%rdx
    8835:	0f 84 86 02 00 00    	je     8ac1 <fwp_write+0x951>
    883b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8840:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8844:	48 85 d2             	test   %rdx,%rdx
    8847:	0f 84 ae 00 00 00    	je     88fb <fwp_write+0x78b>
    884d:	8b 0a                	mov    (%rdx),%ecx
    884f:	83 f9 1c             	cmp    $0x1c,%ecx
    8852:	0f 84 58 06 00 00    	je     8eb0 <fwp_write+0xd40>
    8858:	83 f9 1b             	cmp    $0x1b,%ecx
    885b:	0f 87 9a 00 00 00    	ja     88fb <fwp_write+0x78b>
    8861:	be 01 00 00 00       	mov    $0x1,%esi
    8866:	48 d3 e6             	shl    %cl,%rsi
    8869:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    886f:	0f 85 4b 04 00 00    	jne    8cc0 <fwp_write+0xb50>
    8875:	f7 c6 84 04 00 00    	test   $0x484,%esi
    887b:	0f 85 0f 04 00 00    	jne    8c90 <fwp_write+0xb20>
    8881:	83 e6 21             	and    $0x21,%esi
    8884:	74 75                	je     88fb <fwp_write+0x78b>
    8886:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    888b:	48 85 ff             	test   %rdi,%rdi
    888e:	79 07                	jns    8897 <fwp_write+0x727>
    8890:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8894:	4c 01 ee             	add    %r13,%rsi
    8897:	48 0f be 3e          	movsbq (%rsi),%rdi
    889b:	85 c9                	test   %ecx,%ecx
    889d:	40 0f b6 f7          	movzbl %dil,%esi
    88a1:	48 0f 44 f7          	cmove  %rdi,%rsi
    88a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    88ac:	00 00 00 00 
    88b0:	31 c9                	xor    %ecx,%ecx
    88b2:	48 89 df             	mov    %rbx,%rdi
    88b5:	49 83 c5 01          	add    $0x1,%r13
    88b9:	e8 b2 f8 ff ff       	call   8170 <fwp_write>
    88be:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    88c5:	ff ff 7f 
    88c8:	48 23 55 00          	and    0x0(%rbp),%rdx
    88cc:	49 39 d5             	cmp    %rdx,%r13
    88cf:	0f 83 ec 01 00 00    	jae    8ac1 <fwp_write+0x951>
    88d5:	ba 02 00 00 00       	mov    $0x2,%edx
    88da:	48 89 df             	mov    %rbx,%rdi
    88dd:	48 8d 35 11 39 00 00 	lea    0x3911(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    88e4:	e8 27 b9 ff ff       	call   4210 <buf_put>
    88e9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    88ee:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    88f2:	48 85 d2             	test   %rdx,%rdx
    88f5:	0f 85 52 ff ff ff    	jne    884d <fwp_write+0x6dd>
    88fb:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8900:	48 85 ff             	test   %rdi,%rdi
    8903:	0f 88 cf 05 00 00    	js     8ed8 <fwp_write+0xd68>
    8909:	48 8b 31             	mov    (%rcx),%rsi
    890c:	eb a2                	jmp    88b0 <fwp_write+0x740>
    890e:	66 90                	xchg   %ax,%ax
    8910:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8917:	00 
    8918:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    891f:	00 00 
    8921:	0f 85 1e fd ff ff    	jne    8645 <fwp_write+0x4d5>
    8927:	ba 08 00 00 00       	mov    $0x8,%edx
    892c:	48 8d 35 92 38 00 00 	lea    0x3892(%rip),%rsi        # c1c5 <_IO_stdin_used+0x1c5>
    8933:	e9 4b fa ff ff       	jmp    8383 <fwp_write+0x213>
    8938:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    893f:	00 
    8940:	89 e8                	mov    %ebp,%eax
    8942:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8949:	76 03                	jbe    894e <fwp_write+0x7de>
    894b:	8b 45 00             	mov    0x0(%rbp),%eax
    894e:	41 89 c6             	mov    %eax,%r14d
    8951:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8956:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    895b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    895f:	4c 89 ef             	mov    %r13,%rdi
    8962:	e8 e9 aa ff ff       	call   3450 <strlen@plt>
    8967:	4c 89 ee             	mov    %r13,%rsi
    896a:	48 89 df             	mov    %rbx,%rdi
    896d:	48 89 c2             	mov    %rax,%rdx
    8970:	e8 9b b8 ff ff       	call   4210 <buf_put>
    8975:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    897a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    897e:	85 f6                	test   %esi,%esi
    8980:	0f 8e 80 f8 ff ff    	jle    8206 <fwp_write+0x96>
    8986:	45 31 ed             	xor    %r13d,%r13d
    8989:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    898e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8993:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8998:	ba 01 00 00 00       	mov    $0x1,%edx
    899d:	4c 89 fe             	mov    %r15,%rsi
    89a0:	48 89 04 24          	mov    %rax,(%rsp)
    89a4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    89a9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    89ad:	48 89 df             	mov    %rbx,%rdi
    89b0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    89b4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    89b9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    89be:	e8 4d b8 ff ff       	call   4210 <buf_put>
    89c3:	41 8b 06             	mov    (%r14),%eax
    89c6:	83 f8 0e             	cmp    $0xe,%eax
    89c9:	0f 84 71 02 00 00    	je     8c40 <fwp_write+0xad0>
    89cf:	83 f8 10             	cmp    $0x10,%eax
    89d2:	0f 84 38 02 00 00    	je     8c10 <fwp_write+0xaa0>
    89d8:	83 f8 0a             	cmp    $0xa,%eax
    89db:	0f 84 7f 04 00 00    	je     8e60 <fwp_write+0xcf0>
    89e1:	0f 8f f9 00 00 00    	jg     8ae0 <fwp_write+0x970>
    89e7:	83 f8 03             	cmp    $0x3,%eax
    89ea:	0f 8f 50 04 00 00    	jg     8e40 <fwp_write+0xcd0>
    89f0:	85 c0                	test   %eax,%eax
    89f2:	78 10                	js     8a04 <fwp_write+0x894>
    89f4:	48 8b 04 24          	mov    (%rsp),%rax
    89f8:	48 c1 e8 3f          	shr    $0x3f,%rax
    89fc:	85 c0                	test   %eax,%eax
    89fe:	0f 85 f9 00 00 00    	jne    8afd <fwp_write+0x98d>
    8a04:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8a09:	48 8b 34 24          	mov    (%rsp),%rsi
    8a0d:	31 c9                	xor    %ecx,%ecx
    8a0f:	48 89 df             	mov    %rbx,%rdi
    8a12:	e8 59 f7 ff ff       	call   8170 <fwp_write>
    8a17:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8a1c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8a21:	49 83 c5 01          	add    $0x1,%r13
    8a25:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8a29:	0f 8f 5f ff ff ff    	jg     898e <fwp_write+0x81e>
    8a2f:	e9 d2 f7 ff ff       	jmp    8206 <fwp_write+0x96>
    8a34:	0f 1f 40 00          	nopl   0x0(%rax)
    8a38:	ba 06 00 00 00       	mov    $0x6,%edx
    8a3d:	48 8d 35 a7 37 00 00 	lea    0x37a7(%rip),%rsi        # c1eb <_IO_stdin_used+0x1eb>
    8a44:	45 31 ed             	xor    %r13d,%r13d
    8a47:	e8 c4 b7 ff ff       	call   4210 <buf_put>
    8a4c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8a51:	75 19                	jne    8a6c <fwp_write+0x8fc>
    8a53:	eb 6c                	jmp    8ac1 <fwp_write+0x951>
    8a55:	0f 1f 00             	nopl   (%rax)
    8a58:	ba 02 00 00 00       	mov    $0x2,%edx
    8a5d:	48 8d 35 91 37 00 00 	lea    0x3791(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    8a64:	48 89 df             	mov    %rbx,%rdi
    8a67:	e8 a4 b7 ff ff       	call   4210 <buf_put>
    8a6c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8a72:	b9 00 02 00 00       	mov    $0x200,%ecx
    8a77:	31 c0                	xor    %eax,%eax
    8a79:	49 83 c5 01          	add    $0x1,%r13
    8a7d:	4c 8d 05 6e 37 00 00 	lea    0x376e(%rip),%r8        # c1f2 <_IO_stdin_used+0x1f2>
    8a84:	ba 02 00 00 00       	mov    $0x2,%edx
    8a89:	be 00 02 00 00       	mov    $0x200,%esi
    8a8e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8a95:	00 
    8a96:	e8 15 a9 ff ff       	call   33b0 <__snprintf_chk@plt>
    8a9b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8aa2:	00 
    8aa3:	e8 a8 a9 ff ff       	call   3450 <strlen@plt>
    8aa8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8aaf:	00 
    8ab0:	48 89 df             	mov    %rbx,%rdi
    8ab3:	48 89 c2             	mov    %rax,%rdx
    8ab6:	e8 55 b7 ff ff       	call   4210 <buf_put>
    8abb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8abf:	72 97                	jb     8a58 <fwp_write+0x8e8>
    8ac1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8ac6:	ba 01 00 00 00       	mov    $0x1,%edx
    8acb:	48 89 df             	mov    %rbx,%rdi
    8ace:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8ad3:	e8 38 b7 ff ff       	call   4210 <buf_put>
    8ad8:	e9 29 f7 ff ff       	jmp    8206 <fwp_write+0x96>
    8add:	0f 1f 00             	nopl   (%rax)
    8ae0:	83 f8 0b             	cmp    $0xb,%eax
    8ae3:	0f 85 1b ff ff ff    	jne    8a04 <fwp_write+0x894>
    8ae9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8aee:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8af2:	83 e0 01             	and    $0x1,%eax
    8af5:	85 c0                	test   %eax,%eax
    8af7:	0f 84 07 ff ff ff    	je     8a04 <fwp_write+0x894>
    8afd:	4c 89 fe             	mov    %r15,%rsi
    8b00:	48 89 df             	mov    %rbx,%rdi
    8b03:	ba 01 00 00 00       	mov    $0x1,%edx
    8b08:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8b0d:	e8 fe b6 ff ff       	call   4210 <buf_put>
    8b12:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8b17:	48 8b 34 24          	mov    (%rsp),%rsi
    8b1b:	31 c9                	xor    %ecx,%ecx
    8b1d:	48 89 df             	mov    %rbx,%rdi
    8b20:	e8 4b f6 ff ff       	call   8170 <fwp_write>
    8b25:	ba 01 00 00 00       	mov    $0x1,%edx
    8b2a:	4c 89 fe             	mov    %r15,%rsi
    8b2d:	48 89 df             	mov    %rbx,%rdi
    8b30:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8b35:	e8 d6 b6 ff ff       	call   4210 <buf_put>
    8b3a:	e9 d8 fe ff ff       	jmp    8a17 <fwp_write+0x8a7>
    8b3f:	90                   	nop
    8b40:	ba 01 00 00 00       	mov    $0x1,%edx
    8b45:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8b4a:	48 89 df             	mov    %rbx,%rdi
    8b4d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8b52:	e8 b9 b6 ff ff       	call   4210 <buf_put>
    8b57:	e9 aa f6 ff ff       	jmp    8206 <fwp_write+0x96>
    8b5c:	0f 1f 40 00          	nopl   0x0(%rax)
    8b60:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8b65:	ba 01 00 00 00       	mov    $0x1,%edx
    8b6a:	48 89 df             	mov    %rbx,%rdi
    8b6d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8b72:	e8 99 b6 ff ff       	call   4210 <buf_put>
    8b77:	e9 8a f6 ff ff       	jmp    8206 <fwp_write+0x96>
    8b7c:	0f 1f 40 00          	nopl   0x0(%rax)
    8b80:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8b84:	48 8b 13             	mov    (%rbx),%rdx
    8b87:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    8b8c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8b90:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8b94:	e9 6d f6 ff ff       	jmp    8206 <fwp_write+0x96>
    8b99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ba0:	ba 02 00 00 00       	mov    $0x2,%edx
    8ba5:	48 8d 35 49 36 00 00 	lea    0x3649(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    8bac:	48 89 df             	mov    %rbx,%rdi
    8baf:	e8 5c b6 ff ff       	call   4210 <buf_put>
    8bb4:	e9 72 f8 ff ff       	jmp    842b <fwp_write+0x2bb>
    8bb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8bc0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8bc5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8bca:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    8bce:	48 89 f7             	mov    %rsi,%rdi
    8bd1:	48 89 34 24          	mov    %rsi,(%rsp)
    8bd5:	e8 76 a8 ff ff       	call   3450 <strlen@plt>
    8bda:	48 8b 34 24          	mov    (%rsp),%rsi
    8bde:	48 89 df             	mov    %rbx,%rdi
    8be1:	48 89 c2             	mov    %rax,%rdx
    8be4:	e8 27 b6 ff ff       	call   4210 <buf_put>
    8be9:	ba 03 00 00 00       	mov    $0x3,%edx
    8bee:	48 8d 35 23 36 00 00 	lea    0x3623(%rip),%rsi        # c218 <_IO_stdin_used+0x218>
    8bf5:	48 89 df             	mov    %rbx,%rdi
    8bf8:	e8 13 b6 ff ff       	call   4210 <buf_put>
    8bfd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    8c02:	e9 35 f8 ff ff       	jmp    843c <fwp_write+0x2cc>
    8c07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8c0e:	00 00 
    8c10:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8c15:	48 8b 78 08          	mov    0x8(%rax),%rdi
    8c19:	48 85 ff             	test   %rdi,%rdi
    8c1c:	0f 84 e2 fd ff ff    	je     8a04 <fwp_write+0x894>
    8c22:	48 8d 35 d9 35 00 00 	lea    0x35d9(%rip),%rsi        # c202 <_IO_stdin_used+0x202>
    8c29:	e8 02 a9 ff ff       	call   3530 <strcmp@plt>
    8c2e:	85 c0                	test   %eax,%eax
    8c30:	0f 95 c0             	setne  %al
    8c33:	0f b6 c0             	movzbl %al,%eax
    8c36:	e9 c1 fd ff ff       	jmp    89fc <fwp_write+0x88c>
    8c3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8c40:	31 c0                	xor    %eax,%eax
    8c42:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    8c49:	00 
    8c4a:	0f 97 c0             	seta   %al
    8c4d:	e9 aa fd ff ff       	jmp    89fc <fwp_write+0x88c>
    8c52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8c58:	48 89 df             	mov    %rbx,%rdi
    8c5b:	ba 02 00 00 00       	mov    $0x2,%edx
    8c60:	48 8d 35 98 35 00 00 	lea    0x3598(%rip),%rsi        # c1ff <_IO_stdin_used+0x1ff>
    8c67:	e8 a4 b5 ff ff       	call   4210 <buf_put>
    8c6c:	4c 89 e8             	mov    %r13,%rax
    8c6f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    8c74:	31 c9                	xor    %ecx,%ecx
    8c76:	48 c1 e0 04          	shl    $0x4,%rax
    8c7a:	48 89 df             	mov    %rbx,%rdi
    8c7d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    8c82:	e8 e9 f4 ff ff       	call   8170 <fwp_write>
    8c87:	e9 5e f6 ff ff       	jmp    82ea <fwp_write+0x17a>
    8c8c:	0f 1f 40 00          	nopl   0x0(%rax)
    8c90:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    8c95:	48 85 ff             	test   %rdi,%rdi
    8c98:	79 0c                	jns    8ca6 <fwp_write+0xb36>
    8c9a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    8ca1:	00 
    8ca2:	48 03 75 10          	add    0x10(%rbp),%rsi
    8ca6:	48 63 3e             	movslq (%rsi),%rdi
    8ca9:	83 f9 02             	cmp    $0x2,%ecx
    8cac:	89 fe                	mov    %edi,%esi
    8cae:	48 0f 44 f7          	cmove  %rdi,%rsi
    8cb2:	e9 f9 fb ff ff       	jmp    88b0 <fwp_write+0x740>
    8cb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8cbe:	00 00 
    8cc0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    8cc5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    8cca:	48 85 ff             	test   %rdi,%rdi
    8ccd:	0f 88 0f 03 00 00    	js     8fe2 <fwp_write+0xe72>
    8cd3:	49 0f bf 38          	movswq (%r8),%rdi
    8cd7:	83 f9 01             	cmp    $0x1,%ecx
    8cda:	0f b7 f7             	movzwl %di,%esi
    8cdd:	48 0f 44 f7          	cmove  %rdi,%rsi
    8ce1:	e9 ca fb ff ff       	jmp    88b0 <fwp_write+0x740>
    8ce6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8ced:	00 00 00 
    8cf0:	ba 01 00 00 00       	mov    $0x1,%edx
    8cf5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8cfa:	48 83 c5 08          	add    $0x8,%rbp
    8cfe:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8d03:	e8 08 b5 ff ff       	call   4210 <buf_put>
    8d08:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8d0d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    8d12:	4d 85 ed             	test   %r13,%r13
    8d15:	75 46                	jne    8d5d <fwp_write+0xbed>
    8d17:	e9 04 01 00 00       	jmp    8e20 <fwp_write+0xcb0>
    8d1c:	0f 1f 40 00          	nopl   0x0(%rax)
    8d20:	41 80 f9 09          	cmp    $0x9,%r9b
    8d24:	0f 84 d6 00 00 00    	je     8e00 <fwp_write+0xc90>
    8d2a:	41 80 f9 0a          	cmp    $0xa,%r9b
    8d2e:	0f 85 9c 00 00 00    	jne    8dd0 <fwp_write+0xc60>
    8d34:	ba 02 00 00 00       	mov    $0x2,%edx
    8d39:	48 8d 35 9b 34 00 00 	lea    0x349b(%rip),%rsi        # c1db <_IO_stdin_used+0x1db>
    8d40:	48 89 df             	mov    %rbx,%rdi
    8d43:	e8 c8 b4 ff ff       	call   4210 <buf_put>
    8d48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8d4f:	00 
    8d50:	48 83 c5 01          	add    $0x1,%rbp
    8d54:	49 39 ec             	cmp    %rbp,%r12
    8d57:	0f 84 c3 00 00 00    	je     8e20 <fwp_write+0xcb0>
    8d5d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    8d62:	41 80 f9 0d          	cmp    $0xd,%r9b
    8d66:	74 28                	je     8d90 <fwp_write+0xc20>
    8d68:	7e b6                	jle    8d20 <fwp_write+0xbb0>
    8d6a:	41 80 f9 22          	cmp    $0x22,%r9b
    8d6e:	74 40                	je     8db0 <fwp_write+0xc40>
    8d70:	41 80 f9 5c          	cmp    $0x5c,%r9b
    8d74:	75 5a                	jne    8dd0 <fwp_write+0xc60>
    8d76:	ba 02 00 00 00       	mov    $0x2,%edx
    8d7b:	48 8d 35 56 34 00 00 	lea    0x3456(%rip),%rsi        # c1d8 <_IO_stdin_used+0x1d8>
    8d82:	48 89 df             	mov    %rbx,%rdi
    8d85:	e8 86 b4 ff ff       	call   4210 <buf_put>
    8d8a:	eb c4                	jmp    8d50 <fwp_write+0xbe0>
    8d8c:	0f 1f 40 00          	nopl   0x0(%rax)
    8d90:	ba 02 00 00 00       	mov    $0x2,%edx
    8d95:	48 8d 35 45 34 00 00 	lea    0x3445(%rip),%rsi        # c1e1 <_IO_stdin_used+0x1e1>
    8d9c:	48 89 df             	mov    %rbx,%rdi
    8d9f:	e8 6c b4 ff ff       	call   4210 <buf_put>
    8da4:	eb aa                	jmp    8d50 <fwp_write+0xbe0>
    8da6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8dad:	00 00 00 
    8db0:	ba 02 00 00 00       	mov    $0x2,%edx
    8db5:	48 8d 35 19 34 00 00 	lea    0x3419(%rip),%rsi        # c1d5 <_IO_stdin_used+0x1d5>
    8dbc:	48 89 df             	mov    %rbx,%rdi
    8dbf:	e8 4c b4 ff ff       	call   4210 <buf_put>
    8dc4:	eb 8a                	jmp    8d50 <fwp_write+0xbe0>
    8dc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8dcd:	00 00 00 
    8dd0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    8dd4:	0f 86 2e 01 00 00    	jbe    8f08 <fwp_write+0xd98>
    8dda:	41 80 f9 7f          	cmp    $0x7f,%r9b
    8dde:	0f 84 24 01 00 00    	je     8f08 <fwp_write+0xd98>
    8de4:	ba 01 00 00 00       	mov    $0x1,%edx
    8de9:	4c 89 fe             	mov    %r15,%rsi
    8dec:	48 89 df             	mov    %rbx,%rdi
    8def:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    8df4:	e8 17 b4 ff ff       	call   4210 <buf_put>
    8df9:	e9 52 ff ff ff       	jmp    8d50 <fwp_write+0xbe0>
    8dfe:	66 90                	xchg   %ax,%ax
    8e00:	ba 02 00 00 00       	mov    $0x2,%edx
    8e05:	48 8d 35 d2 33 00 00 	lea    0x33d2(%rip),%rsi        # c1de <_IO_stdin_used+0x1de>
    8e0c:	48 89 df             	mov    %rbx,%rdi
    8e0f:	e8 fc b3 ff ff       	call   4210 <buf_put>
    8e14:	e9 37 ff ff ff       	jmp    8d50 <fwp_write+0xbe0>
    8e19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8e20:	ba 01 00 00 00       	mov    $0x1,%edx
    8e25:	4c 89 fe             	mov    %r15,%rsi
    8e28:	48 89 df             	mov    %rbx,%rdi
    8e2b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8e30:	e8 db b3 ff ff       	call   4210 <buf_put>
    8e35:	e9 cc f3 ff ff       	jmp    8206 <fwp_write+0x96>
    8e3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8e40:	83 f8 04             	cmp    $0x4,%eax
    8e43:	0f 85 bb fb ff ff    	jne    8a04 <fwp_write+0x894>
    8e49:	48 8b 04 24          	mov    (%rsp),%rax
    8e4d:	48 8b 40 08          	mov    0x8(%rax),%rax
    8e51:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8e56:	48 c1 e8 3f          	shr    $0x3f,%rax
    8e5a:	e9 96 fc ff ff       	jmp    8af5 <fwp_write+0x985>
    8e5f:	90                   	nop
    8e60:	8b 0c 24             	mov    (%rsp),%ecx
    8e63:	31 c0                	xor    %eax,%eax
    8e65:	85 c9                	test   %ecx,%ecx
    8e67:	0f 98 c0             	sets   %al
    8e6a:	e9 86 fc ff ff       	jmp    8af5 <fwp_write+0x985>
    8e6f:	90                   	nop
    8e70:	48 f7 d8             	neg    %rax
    8e73:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    8e7a:	00 
    8e7b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    8e82:	2d 
    8e83:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8e8a:	00 
    8e8b:	48 83 d2 00          	adc    $0x0,%rdx
    8e8f:	48 89 c6             	mov    %rax,%rsi
    8e92:	48 f7 da             	neg    %rdx
    8e95:	e8 a6 ab ff ff       	call   3a40 <fwp_fmt_u128>
    8e9a:	e9 51 f3 ff ff       	jmp    81f0 <fwp_write+0x80>
    8e9f:	90                   	nop
    8ea0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    8ea5:	e9 c3 f5 ff ff       	jmp    846d <fwp_write+0x2fd>
    8eaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8eb0:	4c 89 e9             	mov    %r13,%rcx
    8eb3:	48 c1 e1 04          	shl    $0x4,%rcx
    8eb7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    8ebc:	48 85 ff             	test   %rdi,%rdi
    8ebf:	0f 89 eb f9 ff ff    	jns    88b0 <fwp_write+0x740>
    8ec5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8ec9:	48 89 ce             	mov    %rcx,%rsi
    8ecc:	e9 df f9 ff ff       	jmp    88b0 <fwp_write+0x740>
    8ed1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ed8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8edf:	00 
    8ee0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8ee4:	e9 20 fa ff ff       	jmp    8909 <fwp_write+0x799>
    8ee9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ef0:	ba 02 00 00 00       	mov    $0x2,%edx
    8ef5:	48 8d 35 a9 32 00 00 	lea    0x32a9(%rip),%rsi        # c1a5 <_IO_stdin_used+0x1a5>
    8efc:	e9 2d f7 ff ff       	jmp    862e <fwp_write+0x4be>
    8f01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8f08:	4c 8d 05 d5 32 00 00 	lea    0x32d5(%rip),%r8        # c1e4 <_IO_stdin_used+0x1e4>
    8f0f:	b9 10 00 00 00       	mov    $0x10,%ecx
    8f14:	31 c0                	xor    %eax,%eax
    8f16:	ba 02 00 00 00       	mov    $0x2,%edx
    8f1b:	be 10 00 00 00       	mov    $0x10,%esi
    8f20:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8f27:	00 
    8f28:	e8 83 a4 ff ff       	call   33b0 <__snprintf_chk@plt>
    8f2d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8f34:	00 
    8f35:	e8 16 a5 ff ff       	call   3450 <strlen@plt>
    8f3a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8f41:	00 
    8f42:	48 89 df             	mov    %rbx,%rdi
    8f45:	48 89 c2             	mov    %rax,%rdx
    8f48:	e8 c3 b2 ff ff       	call   4210 <buf_put>
    8f4d:	e9 fe fd ff ff       	jmp    8d50 <fwp_write+0xbe0>
    8f52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8f58:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8f5c:	48 8d 35 3c 32 00 00 	lea    0x323c(%rip),%rsi        # c19f <_IO_stdin_used+0x19f>
    8f63:	48 8d 05 34 32 00 00 	lea    0x3234(%rip),%rax        # c19e <_IO_stdin_used+0x19e>
    8f6a:	4c 89 e7             	mov    %r12,%rdi
    8f6d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    8f71:	48 0f 46 f0          	cmovbe %rax,%rsi
    8f75:	e8 76 a4 ff ff       	call   33f0 <strcpy@plt>
    8f7a:	e9 71 f2 ff ff       	jmp    81f0 <fwp_write+0x80>
    8f7f:	90                   	nop
    8f80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8f84:	48 8d 35 14 32 00 00 	lea    0x3214(%rip),%rsi        # c19f <_IO_stdin_used+0x19f>
    8f8b:	48 8d 05 0c 32 00 00 	lea    0x320c(%rip),%rax        # c19e <_IO_stdin_used+0x19e>
    8f92:	0f 2f c8             	comiss %xmm0,%xmm1
    8f95:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8f9c:	00 
    8f9d:	4c 89 e7             	mov    %r12,%rdi
    8fa0:	48 0f 46 f0          	cmovbe %rax,%rsi
    8fa4:	e8 47 a4 ff ff       	call   33f0 <strcpy@plt>
    8fa9:	e9 42 f2 ff ff       	jmp    81f0 <fwp_write+0x80>
    8fae:	66 90                	xchg   %ax,%ax
    8fb0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    8fb5:	45 85 c0             	test   %r8d,%r8d
    8fb8:	75 34                	jne    8fee <fwp_write+0xe7e>
    8fba:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8fc1:	00 
    8fc2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8fc9:	00 00 
    8fcb:	0f 85 74 f6 ff ff    	jne    8645 <fwp_write+0x4d5>
    8fd1:	ba 02 00 00 00       	mov    $0x2,%edx
    8fd6:	48 8d 35 38 32 00 00 	lea    0x3238(%rip),%rsi        # c215 <_IO_stdin_used+0x215>
    8fdd:	e9 a1 f3 ff ff       	jmp    8383 <fwp_write+0x213>
    8fe2:	48 03 75 10          	add    0x10(%rbp),%rsi
    8fe6:	49 89 f0             	mov    %rsi,%r8
    8fe9:	e9 e5 fc ff ff       	jmp    8cd3 <fwp_write+0xb63>
    8fee:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    8ff3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8ff8:	85 ff                	test   %edi,%edi
    8ffa:	0f 84 fa f3 ff ff    	je     83fa <fwp_write+0x28a>
    9000:	ba 01 00 00 00       	mov    $0x1,%edx
    9005:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    900a:	48 89 df             	mov    %rbx,%rdi
    900d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9012:	e8 f9 b1 ff ff       	call   4210 <buf_put>
    9017:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    901c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9021:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9027:	85 c0                	test   %eax,%eax
    9029:	0f 8f f0 f3 ff ff    	jg     841f <fwp_write+0x2af>
    902f:	e9 34 f4 ff ff       	jmp    8468 <fwp_write+0x2f8>
    9034:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9038:	49 89 c5             	mov    %rax,%r13
    903b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9040:	49 89 c4             	mov    %rax,%r12
    9043:	49 c1 fd 3f          	sar    $0x3f,%r13
    9047:	4c 09 e8             	or     %r13,%rax
    904a:	0f 84 a7 00 00 00    	je     90f7 <fwp_write+0xf87>
    9050:	48 8d 2d 49 52 00 00 	lea    0x5249(%rip),%rbp        # e2a0 <units.0>
    9057:	4d 89 e7             	mov    %r12,%r15
    905a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    905e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9063:	4c 89 ff             	mov    %r15,%rdi
    9066:	4c 89 ee             	mov    %r13,%rsi
    9069:	44 89 0c 24          	mov    %r9d,(%rsp)
    906d:	48 99                	cqto
    906f:	48 89 d1             	mov    %rdx,%rcx
    9072:	48 89 c2             	mov    %rax,%rdx
    9075:	e8 d6 23 00 00       	call   b450 <__divmodti4>
    907a:	44 8b 0c 24          	mov    (%rsp),%r9d
    907e:	48 89 c1             	mov    %rax,%rcx
    9081:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9086:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    908b:	0f 84 94 00 00 00    	je     9125 <fwp_write+0xfb5>
    9091:	41 83 c1 01          	add    $0x1,%r9d
    9095:	48 83 c5 10          	add    $0x10,%rbp
    9099:	41 83 f9 05          	cmp    $0x5,%r9d
    909d:	75 bb                	jne    905a <fwp_write+0xeea>
    909f:	4d 85 ed             	test   %r13,%r13
    90a2:	79 53                	jns    90f7 <fwp_write+0xf87>
    90a4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    90a9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    90ae:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    90b3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    90b8:	48 99                	cqto
    90ba:	48 f7 d8             	neg    %rax
    90bd:	48 83 d2 00          	adc    $0x0,%rdx
    90c1:	48 89 c6             	mov    %rax,%rsi
    90c4:	48 f7 da             	neg    %rdx
    90c7:	e8 74 a9 ff ff       	call   3a40 <fwp_fmt_u128>
    90cc:	49 89 e8             	mov    %rbp,%r8
    90cf:	ba 00 02 00 00       	mov    $0x200,%edx
    90d4:	be 02 00 00 00       	mov    $0x2,%esi
    90d9:	31 c0                	xor    %eax,%eax
    90db:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    90e2:	00 
    90e3:	48 8d 0d 26 31 00 00 	lea    0x3126(%rip),%rcx        # c210 <_IO_stdin_used+0x210>
    90ea:	4c 89 e7             	mov    %r12,%rdi
    90ed:	e8 ee a5 ff ff       	call   36e0 <__sprintf_chk@plt>
    90f2:	e9 f9 f0 ff ff       	jmp    81f0 <fwp_write+0x80>
    90f7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    90fc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9101:	31 d2                	xor    %edx,%edx
    9103:	48 89 ef             	mov    %rbp,%rdi
    9106:	e8 35 a9 ff ff       	call   3a40 <fwp_fmt_u128>
    910b:	eb bf                	jmp    90cc <fwp_write+0xf5c>
    910d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9114:	4e 61 4e 00 
    9118:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    911f:	00 
    9120:	e9 cb f0 ff ff       	jmp    81f0 <fwp_write+0x80>
    9125:	44 89 0c 24          	mov    %r9d,(%rsp)
    9129:	48 89 c8             	mov    %rcx,%rax
    912c:	48 85 d2             	test   %rdx,%rdx
    912f:	78 51                	js     9182 <fwp_write+0x1012>
    9131:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9136:	48 89 c6             	mov    %rax,%rsi
    9139:	48 89 ef             	mov    %rbp,%rdi
    913c:	e8 ff a8 ff ff       	call   3a40 <fwp_fmt_u128>
    9141:	44 8b 0c 24          	mov    (%rsp),%r9d
    9145:	49 63 c1             	movslq %r9d,%rax
    9148:	49 89 e8             	mov    %rbp,%r8
    914b:	ba 00 02 00 00       	mov    $0x200,%edx
    9150:	be 02 00 00 00       	mov    $0x2,%esi
    9155:	48 c1 e0 04          	shl    $0x4,%rax
    9159:	48 8d 3d 40 51 00 00 	lea    0x5140(%rip),%rdi        # e2a0 <units.0>
    9160:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9167:	00 
    9168:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    916c:	48 8d 0d 98 30 00 00 	lea    0x3098(%rip),%rcx        # c20b <_IO_stdin_used+0x20b>
    9173:	4c 89 e7             	mov    %r12,%rdi
    9176:	31 c0                	xor    %eax,%eax
    9178:	e8 63 a5 ff ff       	call   36e0 <__sprintf_chk@plt>
    917d:	e9 6e f0 ff ff       	jmp    81f0 <fwp_write+0x80>
    9182:	48 f7 d8             	neg    %rax
    9185:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    918a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    918f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9194:	48 83 d2 00          	adc    $0x0,%rdx
    9198:	48 89 c6             	mov    %rax,%rsi
    919b:	48 f7 da             	neg    %rdx
    919e:	e8 9d a8 ff ff       	call   3a40 <fwp_fmt_u128>
    91a3:	44 8b 0c 24          	mov    (%rsp),%r9d
    91a7:	eb 9c                	jmp    9145 <fwp_write+0xfd5>
    91a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000091b0 <fwp_main_thread>:
    91b0:	f3 0f 1e fa          	endbr64
    91b4:	41 57                	push   %r15
    91b6:	41 56                	push   %r14
    91b8:	41 55                	push   %r13
    91ba:	41 54                	push   %r12
    91bc:	55                   	push   %rbp
    91bd:	53                   	push   %rbx
    91be:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
    91c5:	44 8b 15 98 89 01 00 	mov    0x18998(%rip),%r10d        # 21b64 <fwp_heap+0x13a4>
    91cc:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    91d3:	00 00 
    91d5:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    91dc:	00 
    91dd:	31 c0                	xor    %eax,%eax
    91df:	45 85 d2             	test   %r10d,%r10d
    91e2:	0f 84 e2 12 00 00    	je     a4ca <fwp_main_thread+0x131a>
    91e8:	44 8b 0d 79 89 01 00 	mov    0x18979(%rip),%r9d        # 21b68 <fwp_heap+0x13a8>
    91ef:	45 85 c9             	test   %r9d,%r9d
    91f2:	0f 85 c1 12 00 00    	jne    a4b9 <fwp_main_thread+0x1309>
    91f8:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
    91ff:	00 
    9200:	31 f6                	xor    %esi,%esi
    9202:	48 c7 05 43 6f 01 00 	movq   $0x40000000,0x16f43(%rip)        # 20150 <fwp_main_stack_size>
    9209:	00 00 00 40 
    920d:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    9212:	48 89 05 3f 6f 01 00 	mov    %rax,0x16f3f(%rip)        # 20158 <fwp_main_stack_top>
    9219:	48 8d 05 60 6e 00 00 	lea    0x6e60(%rip),%rax        # 10080 <alt.5>
    9220:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
    9227:	00 
    9228:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
    922f:	00 
    9230:	48 89 c7             	mov    %rax,%rdi
    9233:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    9238:	48 c7 84 24 e0 00 00 	movq   $0x10000,0xe0(%rsp)
    923f:	00 00 00 01 00 
    9244:	c7 84 24 d8 00 00 00 	movl   $0x0,0xd8(%rsp)
    924b:	00 00 00 00 
    924f:	e8 6c a4 ff ff       	call   36c0 <sigaltstack@plt>
    9254:	85 c0                	test   %eax,%eax
    9256:	0f 85 9c 21 00 00    	jne    b3f8 <fwp_main_thread+0x2248>
    925c:	31 c0                	xor    %eax,%eax
    925e:	b9 12 00 00 00       	mov    $0x12,%ecx
    9263:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
    926a:	00 
    926b:	f3 48 ab             	rep stos %rax,(%rdi)
    926e:	48 8d 9c 24 40 01 00 	lea    0x140(%rsp),%rbx
    9275:	00 
    9276:	48 8d 05 73 aa ff ff 	lea    -0x558d(%rip),%rax        # 3cf0 <fwp_segv>
    927d:	c7 84 24 c8 01 00 00 	movl   $0x8000004,0x1c8(%rsp)
    9284:	04 00 00 08 
    9288:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
    928f:	00 
    9290:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9295:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
    929c:	00 
    929d:	e8 de a2 ff ff       	call   3580 <sigemptyset@plt>
    92a2:	85 c0                	test   %eax,%eax
    92a4:	0f 85 4e 21 00 00    	jne    b3f8 <fwp_main_thread+0x2248>
    92aa:	31 d2                	xor    %edx,%edx
    92ac:	48 89 de             	mov    %rbx,%rsi
    92af:	bf 0b 00 00 00       	mov    $0xb,%edi
    92b4:	e8 47 a1 ff ff       	call   3400 <sigaction@plt>
    92b9:	85 c0                	test   %eax,%eax
    92bb:	0f 85 37 21 00 00    	jne    b3f8 <fwp_main_thread+0x2248>
    92c1:	31 d2                	xor    %edx,%edx
    92c3:	48 89 de             	mov    %rbx,%rsi
    92c6:	bf 07 00 00 00       	mov    $0x7,%edi
    92cb:	e8 30 a1 ff ff       	call   3400 <sigaction@plt>
    92d0:	85 c0                	test   %eax,%eax
    92d2:	0f 85 20 21 00 00    	jne    b3f8 <fwp_main_thread+0x2248>
    92d8:	44 8b 05 19 6e 01 00 	mov    0x16e19(%rip),%r8d        # 200f8 <descent_registered>
    92df:	45 85 c0             	test   %r8d,%r8d
    92e2:	0f 84 08 05 00 00    	je     97f0 <fwp_main_thread+0x640>
    92e8:	8b 3d 82 6d 00 00    	mov    0x6d82(%rip),%edi        # 10070 <st.3>
    92ee:	85 ff                	test   %edi,%edi
    92f0:	0f 84 26 05 00 00    	je     981c <fwp_main_thread+0x66c>
    92f6:	48 8b 2d a3 74 01 00 	mov    0x174a3(%rip),%rbp        # 207a0 <fwp_cur>
    92fd:	48 85 ed             	test   %rbp,%rbp
    9300:	0f 84 c9 01 00 00    	je     94cf <fwp_main_thread+0x31f>
    9306:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    930b:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    930f:	48 89 eb             	mov    %rbp,%rbx
    9312:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9317:	0f 84 41 01 00 00    	je     945e <fwp_main_thread+0x2ae>
    931d:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    9322:	0f 84 e8 03 00 00    	je     9710 <fwp_main_thread+0x560>
    9328:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    932c:	0f 84 b6 03 00 00    	je     96e8 <fwp_main_thread+0x538>
    9332:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9336:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    933a:	0f 85 50 04 00 00    	jne    9790 <fwp_main_thread+0x5e0>
    9340:	48 8b 43 60          	mov    0x60(%rbx),%rax
    9344:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    934b:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    934f:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9356:	00 00 00 00 
    935a:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9361:	48 85 d2             	test   %rdx,%rdx
    9364:	74 07                	je     936d <fwp_main_thread+0x1bd>
    9366:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    936d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9371:	48 85 c0             	test   %rax,%rax
    9374:	74 34                	je     93aa <fwp_main_thread+0x1fa>
    9376:	48 89 43 68          	mov    %rax,0x68(%rbx)
    937a:	48 8b 05 f7 73 01 00 	mov    0x173f7(%rip),%rax        # 20778 <fwp_timers>
    9381:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    9385:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    938c:	00 00 00 00 
    9390:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    9397:	48 85 c0             	test   %rax,%rax
    939a:	74 07                	je     93a3 <fwp_main_thread+0x1f3>
    939c:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    93a3:	48 89 1d ce 73 01 00 	mov    %rbx,0x173ce(%rip)        # 20778 <fwp_timers>
    93aa:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    93ae:	e8 fd dd ff ff       	call   71b0 <fwp_block>
    93b3:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    93ba:	48 85 c9             	test   %rcx,%rcx
    93bd:	74 47                	je     9406 <fwp_main_thread+0x256>
    93bf:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    93c6:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    93cd:	48 85 d2             	test   %rdx,%rdx
    93d0:	0f 84 fa 03 00 00    	je     97d0 <fwp_main_thread+0x620>
    93d6:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    93dd:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    93e4:	48 85 c0             	test   %rax,%rax
    93e7:	74 07                	je     93f0 <fwp_main_thread+0x240>
    93e9:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    93f0:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    93f7:	00 00 00 00 
    93fb:	66 0f ef ff          	pxor   %xmm7,%xmm7
    93ff:	0f 11 bb 18 01 00 00 	movups %xmm7,0x118(%rbx)
    9406:	48 8b 0d 93 73 01 00 	mov    0x17393(%rip),%rcx        # 207a0 <fwp_cur>
    940d:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9411:	0f 84 69 03 00 00    	je     9780 <fwp_main_thread+0x5d0>
    9417:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    941e:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    9425:	48 85 d2             	test   %rdx,%rdx
    9428:	0f 84 b2 03 00 00    	je     97e0 <fwp_main_thread+0x630>
    942e:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    9435:	48 85 c0             	test   %rax,%rax
    9438:	74 07                	je     9441 <fwp_main_thread+0x291>
    943a:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9441:	66 0f ef ff          	pxor   %xmm7,%xmm7
    9445:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    9449:	0f 11 bb 08 01 00 00 	movups %xmm7,0x108(%rbx)
    9450:	48 89 cb             	mov    %rcx,%rbx
    9453:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9458:	0f 85 bf fe ff ff    	jne    931d <fwp_main_thread+0x16d>
    945e:	48 83 3d d2 8f 01 00 	cmpq   $0x0,0x18fd2(%rip)        # 22438 <fwp_state_len>
    9465:	00 
    9466:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    946a:	75 0e                	jne    947a <fwp_main_thread+0x2ca>
    946c:	48 83 3d b4 8f 01 00 	cmpq   $0x0,0x18fb4(%rip)        # 22428 <fwp_state_owners>
    9473:	00 
    9474:	0f 84 e7 1d 00 00    	je     b261 <fwp_main_thread+0x20b1>
    947a:	48 39 1d 17 73 01 00 	cmp    %rbx,0x17317(%rip)        # 20798 <fwp_root>
    9481:	c7 05 f5 6b 01 00 00 	movl   $0x0,0x16bf5(%rip)        # 20080 <fwp_exit_code>
    9488:	00 00 00 
    948b:	0f 85 a8 1f 00 00    	jne    b439 <fwp_main_thread+0x2289>
    9491:	48 85 db             	test   %rbx,%rbx
    9494:	74 5f                	je     94f5 <fwp_main_thread+0x345>
    9496:	48 8b 15 cb 72 01 00 	mov    0x172cb(%rip),%rdx        # 20768 <fwp_tasks_active>
    949d:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    94a1:	48 85 d2             	test   %rdx,%rdx
    94a4:	74 4f                	je     94f5 <fwp_main_thread+0x345>
    94a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    94ad:	00 00 00 
    94b0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    94b4:	75 08                	jne    94be <fwp_main_thread+0x30e>
    94b6:	48 89 d7             	mov    %rdx,%rdi
    94b9:	e8 42 ae ff ff       	call   4300 <fwp_cancel_tree.part.0>
    94be:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    94c5:	48 85 d2             	test   %rdx,%rdx
    94c8:	75 e6                	jne    94b0 <fwp_main_thread+0x300>
    94ca:	e9 e6 01 00 00       	jmp    96b5 <fwp_main_thread+0x505>
    94cf:	48 83 3d 61 8f 01 00 	cmpq   $0x0,0x18f61(%rip)        # 22438 <fwp_state_len>
    94d6:	00 
    94d7:	0f 84 6a 1c 00 00    	je     b147 <fwp_main_thread+0x1f97>
    94dd:	48 83 3d b3 72 01 00 	cmpq   $0x0,0x172b3(%rip)        # 20798 <fwp_root>
    94e4:	00 
    94e5:	c7 05 91 6b 01 00 00 	movl   $0x0,0x16b91(%rip)        # 20080 <fwp_exit_code>
    94ec:	00 00 00 
    94ef:	0f 85 49 1f 00 00    	jne    b43e <fwp_main_thread+0x228e>
    94f5:	e8 a6 da ff ff       	call   6fa0 <fwp_free_zombie>
    94fa:	48 83 3d 86 72 01 00 	cmpq   $0x0,0x17286(%rip)        # 20788 <fwp_ready_head>
    9501:	00 
    9502:	0f 85 43 a2 ff ff    	jne    374b <fwp_main_thread.cold>
    9508:	48 83 3d 68 72 01 00 	cmpq   $0x0,0x17268(%rip)        # 20778 <fwp_timers>
    950f:	00 
    9510:	0f 85 35 a2 ff ff    	jne    374b <fwp_main_thread.cold>
    9516:	8b 05 48 6c 01 00    	mov    0x16c48(%rip),%eax        # 20164 <fwp_stack_pool_n>
    951c:	85 c0                	test   %eax,%eax
    951e:	74 3d                	je     955d <fwp_main_thread+0x3ad>
    9520:	83 e8 01             	sub    $0x1,%eax
    9523:	4c 8d 25 56 6c 01 00 	lea    0x16c56(%rip),%r12        # 20180 <fwp_stack_pool>
    952a:	48 63 d8             	movslq %eax,%rbx
    952d:	89 c0                	mov    %eax,%eax
    952f:	48 89 da             	mov    %rbx,%rdx
    9532:	48 29 c2             	sub    %rax,%rdx
    9535:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    9539:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9540:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    9544:	89 1d 1a 6c 01 00    	mov    %ebx,0x16c1a(%rip)        # 20164 <fwp_stack_pool_n>
    954a:	be 00 00 00 10       	mov    $0x10000000,%esi
    954f:	48 83 eb 01          	sub    $0x1,%rbx
    9553:	e8 88 a0 ff ff       	call   35e0 <munmap@plt>
    9558:	48 39 eb             	cmp    %rbp,%rbx
    955b:	75 e3                	jne    9540 <fwp_main_thread+0x390>
    955d:	8b 3d b9 6a 00 00    	mov    0x6ab9(%rip),%edi        # 1001c <fwp_epfd>
    9563:	85 ff                	test   %edi,%edi
    9565:	78 05                	js     956c <fwp_main_thread+0x3bc>
    9567:	e8 64 9f ff ff       	call   34d0 <close@plt>
    956c:	4c 8b 25 0d 6e 01 00 	mov    0x16e0d(%rip),%r12        # 20380 <fwp_nfdws>
    9573:	48 8b 2d 0e 6e 01 00 	mov    0x16e0e(%rip),%rbp        # 20388 <fwp_fdws>
    957a:	31 db                	xor    %ebx,%ebx
    957c:	c7 05 96 6a 00 00 ff 	movl   $0xffffffff,0x6a96(%rip)        # 1001c <fwp_epfd>
    9583:	ff ff ff 
    9586:	4d 85 e4             	test   %r12,%r12
    9589:	74 32                	je     95bd <fwp_main_thread+0x40d>
    958b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9590:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9595:	48 85 ff             	test   %rdi,%rdi
    9598:	74 1a                	je     95b4 <fwp_main_thread+0x404>
    959a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    959e:	0f 85 a7 a1 ff ff    	jne    374b <fwp_main_thread.cold>
    95a4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    95a9:	0f 85 9c a1 ff ff    	jne    374b <fwp_main_thread.cold>
    95af:	e8 dc c1 ff ff       	call   5790 <fwp_mem_free>
    95b4:	48 83 c3 01          	add    $0x1,%rbx
    95b8:	4c 39 e3             	cmp    %r12,%rbx
    95bb:	75 d3                	jne    9590 <fwp_main_thread+0x3e0>
    95bd:	48 89 ef             	mov    %rbp,%rdi
    95c0:	e8 cb c1 ff ff       	call   5790 <fwp_mem_free>
    95c5:	48 8b 15 cc 71 01 00 	mov    0x171cc(%rip),%rdx        # 20798 <fwp_root>
    95cc:	48 c7 05 b1 6d 01 00 	movq   $0x0,0x16db1(%rip)        # 20388 <fwp_fdws>
    95d3:	00 00 00 00 
    95d7:	48 c7 05 9e 6d 01 00 	movq   $0x0,0x16d9e(%rip)        # 20380 <fwp_nfdws>
    95de:	00 00 00 00 
    95e2:	48 85 d2             	test   %rdx,%rdx
    95e5:	74 4e                	je     9635 <fwp_main_thread+0x485>
    95e7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    95ec:	0f 85 59 a1 ff ff    	jne    374b <fwp_main_thread.cold>
    95f2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    95f9:	00 
    95fa:	0f 85 4b a1 ff ff    	jne    374b <fwp_main_thread.cold>
    9600:	48 83 3d 30 8e 01 00 	cmpq   $0x0,0x18e30(%rip)        # 22438 <fwp_state_len>
    9607:	00 
    9608:	0f 85 3d a1 ff ff    	jne    374b <fwp_main_thread.cold>
    960e:	48 83 3d 12 8e 01 00 	cmpq   $0x0,0x18e12(%rip)        # 22428 <fwp_state_owners>
    9615:	00 
    9616:	0f 85 2f a1 ff ff    	jne    374b <fwp_main_thread.cold>
    961c:	b9 79 00 00 00       	mov    $0x79,%ecx
    9621:	31 c0                	xor    %eax,%eax
    9623:	48 8d 3d 76 6d 01 00 	lea    0x16d76(%rip),%rdi        # 203a0 <fwp_root_context>
    962a:	f3 48 ab             	rep stos %rax,(%rdi)
    962d:	48 89 d7             	mov    %rdx,%rdi
    9630:	e8 5b c1 ff ff       	call   5790 <fwp_mem_free>
    9635:	48 8b 3d e4 69 00 00 	mov    0x69e4(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    963c:	48 c7 05 59 71 01 00 	movq   $0x0,0x17159(%rip)        # 207a0 <fwp_cur>
    9643:	00 00 00 00 
    9647:	48 c7 05 46 71 01 00 	movq   $0x0,0x17146(%rip)        # 20798 <fwp_root>
    964e:	00 00 00 00 
    9652:	e8 69 9f ff ff       	call   35c0 <fflush@plt>
    9657:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
    965e:	00 
    965f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9666:	00 00 
    9668:	0f 85 96 1d 00 00    	jne    b404 <fwp_main_thread+0x2254>
    966e:	48 81 c4 e8 01 00 00 	add    $0x1e8,%rsp
    9675:	31 c0                	xor    %eax,%eax
    9677:	5b                   	pop    %rbx
    9678:	5d                   	pop    %rbp
    9679:	41 5c                	pop    %r12
    967b:	41 5d                	pop    %r13
    967d:	41 5e                	pop    %r14
    967f:	41 5f                	pop    %r15
    9681:	c3                   	ret
    9682:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9688:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    968f:	48 89 1d ea 70 01 00 	mov    %rbx,0x170ea(%rip)        # 20780 <fwp_ready_tail>
    9696:	e8 15 db ff ff       	call   71b0 <fwp_block>
    969b:	e8 00 d9 ff ff       	call   6fa0 <fwp_free_zombie>
    96a0:	48 83 3d c0 70 01 00 	cmpq   $0x0,0x170c0(%rip)        # 20768 <fwp_tasks_active>
    96a7:	00 
    96a8:	0f 84 47 fe ff ff    	je     94f5 <fwp_main_thread+0x345>
    96ae:	48 8b 1d e3 70 01 00 	mov    0x170e3(%rip),%rbx        # 20798 <fwp_root>
    96b5:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    96b9:	75 db                	jne    9696 <fwp_main_thread+0x4e6>
    96bb:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    96bf:	75 d5                	jne    9696 <fwp_main_thread+0x4e6>
    96c1:	48 8b 05 b8 70 01 00 	mov    0x170b8(%rip),%rax        # 20780 <fwp_ready_tail>
    96c8:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    96cc:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    96d3:	00 00 00 00 
    96d7:	48 85 c0             	test   %rax,%rax
    96da:	75 ac                	jne    9688 <fwp_main_thread+0x4d8>
    96dc:	48 89 1d a5 70 01 00 	mov    %rbx,0x170a5(%rip)        # 20788 <fwp_ready_head>
    96e3:	eb aa                	jmp    968f <fwp_main_thread+0x4df>
    96e5:	0f 1f 00             	nopl   (%rax)
    96e8:	e8 73 ae ff ff       	call   4560 <fwp_now_ns>
    96ed:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    96f1:	7c 1d                	jl     9710 <fwp_main_thread+0x560>
    96f3:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    96f7:	75 17                	jne    9710 <fwp_main_thread+0x560>
    96f9:	48 89 ef             	mov    %rbp,%rdi
    96fc:	e8 ff ab ff ff       	call   4300 <fwp_cancel_tree.part.0>
    9701:	0f 1f 40 00          	nopl   0x0(%rax)
    9705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    970c:	00 00 00 00 
    9710:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9714:	0f 85 18 fc ff ff    	jne    9332 <fwp_main_thread+0x182>
    971a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    971e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9722:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9726:	0f 85 18 fc ff ff    	jne    9344 <fwp_main_thread+0x194>
    972c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    9730:	48 85 c9             	test   %rcx,%rcx
    9733:	0f 84 0b fc ff ff    	je     9344 <fwp_main_thread+0x194>
    9739:	48 39 c8             	cmp    %rcx,%rax
    973c:	48 89 ce             	mov    %rcx,%rsi
    973f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9746:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    974a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9751:	00 00 00 00 
    9755:	48 0f 4e f0          	cmovle %rax,%rsi
    9759:	48 85 c0             	test   %rax,%rax
    975c:	48 89 c8             	mov    %rcx,%rax
    975f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9766:	48 0f 45 c6          	cmovne %rsi,%rax
    976a:	48 85 d2             	test   %rdx,%rdx
    976d:	74 07                	je     9776 <fwp_main_thread+0x5c6>
    976f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9776:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    977a:	e9 f7 fb ff ff       	jmp    9376 <fwp_main_thread+0x1c6>
    977f:	90                   	nop
    9780:	48 89 cb             	mov    %rcx,%rbx
    9783:	e9 8a fb ff ff       	jmp    9312 <fwp_main_thread+0x162>
    9788:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    978f:	00 
    9790:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9794:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    979b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    97a2:	00 00 00 00 
    97a6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    97ad:	48 85 c0             	test   %rax,%rax
    97b0:	0f 84 7a 19 00 00    	je     b130 <fwp_main_thread+0x1f80>
    97b6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    97bd:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    97c1:	e9 e4 fb ff ff       	jmp    93aa <fwp_main_thread+0x1fa>
    97c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    97cd:	00 00 00 
    97d0:	48 89 01             	mov    %rax,(%rcx)
    97d3:	e9 0c fc ff ff       	jmp    93e4 <fwp_main_thread+0x234>
    97d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    97df:	00 
    97e0:	48 89 05 91 6f 01 00 	mov    %rax,0x16f91(%rip)        # 20778 <fwp_timers>
    97e7:	e9 49 fc ff ff       	jmp    9435 <fwp_main_thread+0x285>
    97ec:	0f 1f 40 00          	nopl   0x0(%rax)
    97f0:	48 8d 3d 19 a6 ff ff 	lea    -0x59e7(%rip),%rdi        # 3e10 <descent_phase_report>
    97f7:	e8 64 1e 00 00       	call   b660 <atexit>
    97fc:	85 c0                	test   %eax,%eax
    97fe:	0f 85 24 1c 00 00    	jne    b428 <fwp_main_thread+0x2278>
    9804:	c7 05 ea 68 01 00 01 	movl   $0x1,0x168ea(%rip)        # 200f8 <descent_registered>
    980b:	00 00 00 
    980e:	8b 3d 5c 68 00 00    	mov    0x685c(%rip),%edi        # 10070 <st.3>
    9814:	85 ff                	test   %edi,%edi
    9816:	0f 85 da fa ff ff    	jne    92f6 <fwp_main_thread+0x146>
    981c:	48 8d 05 ad df ff ff 	lea    -0x2053(%rip),%rax        # 77d0 <fwp_drop1>
    9823:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9827:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    982c:	45 31 f6             	xor    %r14d,%r14d
    982f:	66 48 0f 6e f0       	movq   %rax,%xmm6
    9834:	48 8b 05 1d 8c 01 00 	mov    0x18c1d(%rip),%rax        # 22458 <fwp_cleanups>
    983b:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
    9842:	00 00 00 00 00 
    9847:	bb ff 01 00 00       	mov    $0x1ff,%ebx
    984c:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    9850:	48 8d 2d 69 6f 01 00 	lea    0x16f69(%rip),%rbp        # 207c0 <fwp_heap>
    9857:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    985e:	00 
    985f:	48 8d 05 6a a3 ff ff 	lea    -0x5c96(%rip),%rax        # 3bd0 <fwp_range_release>
    9866:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    986d:	00 
    986e:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    9873:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    987a:	00 
    987b:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    9882:	00 
    9883:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
    9888:	48 89 05 c9 8b 01 00 	mov    %rax,0x18bc9(%rip)        # 22458 <fwp_cleanups>
    988f:	eb 47                	jmp    98d8 <fwp_main_thread+0x728>
    9891:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9898:	80 f9 01             	cmp    $0x1,%cl
    989b:	75 29                	jne    98c6 <fwp_main_thread+0x716>
    989d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    98a0:	0f b7 c0             	movzwl %ax,%eax
    98a3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    98a6:	48 0f af c1          	imul   %rcx,%rax
    98aa:	48 c1 e8 20          	shr    $0x20,%rax
    98ae:	48 39 d0             	cmp    %rdx,%rax
    98b1:	73 13                	jae    98c6 <fwp_main_thread+0x716>
    98b3:	49 01 c5             	add    %rax,%r13
    98b6:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    98bb:	0f 84 e7 18 00 00    	je     b1a8 <fwp_main_thread+0x1ff8>
    98c1:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    98c6:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    98cd:	00 
    98ce:	48 83 eb 01          	sub    $0x1,%rbx
    98d2:	0f 82 85 00 00 00    	jb     995d <fwp_main_thread+0x7ad>
    98d8:	4c 89 e6             	mov    %r12,%rsi
    98db:	bf 01 00 00 00       	mov    $0x1,%edi
    98e0:	4c 89 b4 24 48 01 00 	mov    %r14,0x148(%rsp)
    98e7:	00 
    98e8:	48 89 9c 24 d8 00 00 	mov    %rbx,0xd8(%rsp)
    98ef:	00 
    98f0:	48 89 9c 24 40 01 00 	mov    %rbx,0x140(%rsp)
    98f7:	00 
    98f8:	e8 b3 c4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    98fd:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9904:	49 89 c6             	mov    %rax,%r14
    9907:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    990e:	48 c1 e2 10          	shl    $0x10,%rdx
    9912:	48 39 d0             	cmp    %rdx,%rax
    9915:	73 af                	jae    98c6 <fwp_main_thread+0x716>
    9917:	48 89 c2             	mov    %rax,%rdx
    991a:	48 c1 ea 10          	shr    $0x10,%rdx
    991e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9922:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9929:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    992d:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9931:	4d 85 ed             	test   %r13,%r13
    9934:	74 90                	je     98c6 <fwp_main_thread+0x716>
    9936:	0f b6 0a             	movzbl (%rdx),%ecx
    9939:	80 f9 02             	cmp    $0x2,%cl
    993c:	0f 85 56 ff ff ff    	jne    9898 <fwp_main_thread+0x6e8>
    9942:	66 85 c0             	test   %ax,%ax
    9945:	0f 84 6b ff ff ff    	je     98b6 <fwp_main_thread+0x706>
    994b:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    9952:	00 
    9953:	48 83 eb 01          	sub    $0x1,%rbx
    9957:	0f 83 7b ff ff ff    	jae    98d8 <fwp_main_thread+0x728>
    995d:	48 8b 9c 24 b0 00 00 	mov    0xb0(%rsp),%rbx
    9964:	00 
    9965:	66 0f 6f 05 d3 32 00 	movdqa 0x32d3(%rip),%xmm0        # cc40 <msg.4+0xd0>
    996c:	00 
    996d:	bf 01 00 00 00       	mov    $0x1,%edi
    9972:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    9979:	00 
    997a:	48 89 1d d7 8a 01 00 	mov    %rbx,0x18ad7(%rip)        # 22458 <fwp_cleanups>
    9981:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
    9988:	00 
    9989:	e8 22 c4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    998e:	48 8b 15 03 82 01 00 	mov    0x18203(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    9995:	49 89 c5             	mov    %rax,%r13
    9998:	48 2b 05 d1 81 01 00 	sub    0x181d1(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    999f:	48 c1 e2 10          	shl    $0x10,%rdx
    99a3:	48 39 d0             	cmp    %rdx,%rax
    99a6:	73 59                	jae    9a01 <fwp_main_thread+0x851>
    99a8:	48 89 c2             	mov    %rax,%rdx
    99ab:	48 c1 ea 10          	shr    $0x10,%rdx
    99af:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    99b3:	48 8b 15 fe 81 01 00 	mov    0x181fe(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    99ba:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    99be:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    99c2:	4d 85 e4             	test   %r12,%r12
    99c5:	74 3a                	je     9a01 <fwp_main_thread+0x851>
    99c7:	0f b6 0a             	movzbl (%rdx),%ecx
    99ca:	80 f9 02             	cmp    $0x2,%cl
    99cd:	0f 84 ab 17 00 00    	je     b17e <fwp_main_thread+0x1fce>
    99d3:	80 f9 01             	cmp    $0x1,%cl
    99d6:	75 29                	jne    9a01 <fwp_main_thread+0x851>
    99d8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    99db:	0f b7 c0             	movzwl %ax,%eax
    99de:	8b 52 1c             	mov    0x1c(%rdx),%edx
    99e1:	48 0f af c1          	imul   %rcx,%rax
    99e5:	48 c1 e8 20          	shr    $0x20,%rax
    99e9:	48 39 d0             	cmp    %rdx,%rax
    99ec:	73 13                	jae    9a01 <fwp_main_thread+0x851>
    99ee:	49 01 c4             	add    %rax,%r12
    99f1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    99f6:	0f 84 94 19 00 00    	je     b390 <fwp_main_thread+0x21e0>
    99fc:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9a01:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9a08:	00 f0 3f 
    9a0b:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    9a12:	00 
    9a13:	bf 01 00 00 00       	mov    $0x1,%edi
    9a18:	4c 89 ac 24 28 01 00 	mov    %r13,0x128(%rsp)
    9a1f:	00 
    9a20:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
    9a27:	00 
    9a28:	e8 83 c3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    9a2d:	48 8b 15 64 81 01 00 	mov    0x18164(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    9a34:	49 89 c5             	mov    %rax,%r13
    9a37:	48 2b 05 32 81 01 00 	sub    0x18132(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    9a3e:	48 c1 e2 10          	shl    $0x10,%rdx
    9a42:	48 39 d0             	cmp    %rdx,%rax
    9a45:	73 59                	jae    9aa0 <fwp_main_thread+0x8f0>
    9a47:	48 89 c2             	mov    %rax,%rdx
    9a4a:	48 c1 ea 10          	shr    $0x10,%rdx
    9a4e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9a52:	48 8b 15 5f 81 01 00 	mov    0x1815f(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    9a59:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9a5d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9a61:	4d 85 e4             	test   %r12,%r12
    9a64:	74 3a                	je     9aa0 <fwp_main_thread+0x8f0>
    9a66:	0f b6 0a             	movzbl (%rdx),%ecx
    9a69:	80 f9 02             	cmp    $0x2,%cl
    9a6c:	0f 84 28 17 00 00    	je     b19a <fwp_main_thread+0x1fea>
    9a72:	80 f9 01             	cmp    $0x1,%cl
    9a75:	75 29                	jne    9aa0 <fwp_main_thread+0x8f0>
    9a77:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9a7a:	0f b7 c0             	movzwl %ax,%eax
    9a7d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a80:	48 0f af c1          	imul   %rcx,%rax
    9a84:	48 c1 e8 20          	shr    $0x20,%rax
    9a88:	48 39 d0             	cmp    %rdx,%rax
    9a8b:	73 13                	jae    9aa0 <fwp_main_thread+0x8f0>
    9a8d:	49 01 c4             	add    %rax,%r12
    9a90:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9a95:	0f 84 02 19 00 00    	je     b39d <fwp_main_thread+0x21ed>
    9a9b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9aa0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9aa7:	33 f3 bf 
    9aaa:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    9ab1:	00 
    9ab2:	bf 01 00 00 00       	mov    $0x1,%edi
    9ab7:	4c 89 ac 24 18 01 00 	mov    %r13,0x118(%rsp)
    9abe:	00 
    9abf:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
    9ac6:	00 
    9ac7:	e8 e4 c2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    9acc:	48 8b 15 c5 80 01 00 	mov    0x180c5(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    9ad3:	48 8b 0d 96 80 01 00 	mov    0x18096(%rip),%rcx        # 21b70 <fwp_heap+0x13b0>
    9ada:	48 89 04 24          	mov    %rax,(%rsp)
    9ade:	48 89 d6             	mov    %rdx,%rsi
    9ae1:	48 29 c8             	sub    %rcx,%rax
    9ae4:	48 c1 e6 10          	shl    $0x10,%rsi
    9ae8:	48 39 f0             	cmp    %rsi,%rax
    9aeb:	73 69                	jae    9b56 <fwp_main_thread+0x9a6>
    9aed:	48 89 c6             	mov    %rax,%rsi
    9af0:	48 c1 ee 10          	shr    $0x10,%rsi
    9af4:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9af8:	48 8b 35 b9 80 01 00 	mov    0x180b9(%rip),%rsi        # 21bb8 <fwp_heap+0x13f8>
    9aff:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9b03:	4c 8b 66 20          	mov    0x20(%rsi),%r12
    9b07:	4d 85 e4             	test   %r12,%r12
    9b0a:	74 4a                	je     9b56 <fwp_main_thread+0x9a6>
    9b0c:	0f b6 3e             	movzbl (%rsi),%edi
    9b0f:	40 80 ff 02          	cmp    $0x2,%dil
    9b13:	0f 84 73 16 00 00    	je     b18c <fwp_main_thread+0x1fdc>
    9b19:	40 80 ff 01          	cmp    $0x1,%dil
    9b1d:	75 37                	jne    9b56 <fwp_main_thread+0x9a6>
    9b1f:	8b 7e 18             	mov    0x18(%rsi),%edi
    9b22:	0f b7 c0             	movzwl %ax,%eax
    9b25:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9b28:	48 0f af c7          	imul   %rdi,%rax
    9b2c:	48 c1 e8 20          	shr    $0x20,%rax
    9b30:	48 39 f0             	cmp    %rsi,%rax
    9b33:	73 21                	jae    9b56 <fwp_main_thread+0x9a6>
    9b35:	49 01 c4             	add    %rax,%r12
    9b38:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9b3d:	0f 84 67 18 00 00    	je     b3aa <fwp_main_thread+0x21fa>
    9b43:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9b48:	48 8b 0d 21 80 01 00 	mov    0x18021(%rip),%rcx        # 21b70 <fwp_heap+0x13b0>
    9b4f:	48 8b 15 42 80 01 00 	mov    0x18042(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    9b56:	48 8d 84 24 8c 00 00 	lea    0x8c(%rsp),%rax
    9b5d:	00 
    9b5e:	4c 89 74 24 70       	mov    %r14,0x70(%rsp)
    9b63:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    9b68:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    9b6f:	00 
    9b70:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    9b75:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
    9b7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9b80:	48 8b 04 24          	mov    (%rsp),%rax
    9b84:	48 c1 e2 10          	shl    $0x10,%rdx
    9b88:	48 29 c8             	sub    %rcx,%rax
    9b8b:	48 39 d0             	cmp    %rdx,%rax
    9b8e:	73 73                	jae    9c03 <fwp_main_thread+0xa53>
    9b90:	48 89 c6             	mov    %rax,%rsi
    9b93:	48 c1 ee 10          	shr    $0x10,%rsi
    9b97:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9b9b:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    9ba2:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9ba6:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9baa:	48 85 ff             	test   %rdi,%rdi
    9bad:	74 54                	je     9c03 <fwp_main_thread+0xa53>
    9baf:	44 0f b6 06          	movzbl (%rsi),%r8d
    9bb3:	41 80 f8 02          	cmp    $0x2,%r8b
    9bb7:	0f 84 f3 14 00 00    	je     b0b0 <fwp_main_thread+0x1f00>
    9bbd:	41 80 f8 01          	cmp    $0x1,%r8b
    9bc1:	75 40                	jne    9c03 <fwp_main_thread+0xa53>
    9bc3:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    9bc7:	0f b7 c0             	movzwl %ax,%eax
    9bca:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9bcd:	49 0f af c0          	imul   %r8,%rax
    9bd1:	48 c1 e8 20          	shr    $0x20,%rax
    9bd5:	48 39 f0             	cmp    %rsi,%rax
    9bd8:	73 29                	jae    9c03 <fwp_main_thread+0xa53>
    9bda:	48 01 c7             	add    %rax,%rdi
    9bdd:	0f b6 07             	movzbl (%rdi),%eax
    9be0:	84 c0                	test   %al,%al
    9be2:	74 1f                	je     9c03 <fwp_main_thread+0xa53>
    9be4:	3c fd                	cmp    $0xfd,%al
    9be6:	0f 87 52 17 00 00    	ja     b33e <fwp_main_thread+0x218e>
    9bec:	83 c0 01             	add    $0x1,%eax
    9bef:	88 07                	mov    %al,(%rdi)
    9bf1:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9bf8:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    9bff:	48 c1 e2 10          	shl    $0x10,%rdx
    9c03:	48 8d 05 96 ce ff ff 	lea    -0x316a(%rip),%rax        # 6aa0 <fwp_tape_scope_release>
    9c0a:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
    9c11:	00 
    9c12:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    9c19:	00 
    9c1a:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    9c1f:	c7 84 24 8c 00 00 00 	movl   $0xffffffff,0x8c(%rsp)
    9c26:	ff ff ff ff 
    9c2a:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    9c31:	00 
    9c32:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    9c37:	48 89 05 1a 88 01 00 	mov    %rax,0x1881a(%rip)        # 22458 <fwp_cleanups>
    9c3e:	48 8d 05 cb 63 00 00 	lea    0x63cb(%rip),%rax        # 10010 <fc37>
    9c45:	48 29 c8             	sub    %rcx,%rax
    9c48:	48 39 d0             	cmp    %rdx,%rax
    9c4b:	73 5d                	jae    9caa <fwp_main_thread+0xafa>
    9c4d:	48 89 c2             	mov    %rax,%rdx
    9c50:	48 c1 ea 10          	shr    $0x10,%rdx
    9c54:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9c58:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9c5f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9c63:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9c67:	48 85 ff             	test   %rdi,%rdi
    9c6a:	74 3e                	je     9caa <fwp_main_thread+0xafa>
    9c6c:	0f b6 0a             	movzbl (%rdx),%ecx
    9c6f:	80 f9 02             	cmp    $0x2,%cl
    9c72:	0f 84 98 12 00 00    	je     af10 <fwp_main_thread+0x1d60>
    9c78:	80 f9 01             	cmp    $0x1,%cl
    9c7b:	75 2d                	jne    9caa <fwp_main_thread+0xafa>
    9c7d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9c80:	0f b7 c0             	movzwl %ax,%eax
    9c83:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9c86:	48 0f af c1          	imul   %rcx,%rax
    9c8a:	48 c1 e8 20          	shr    $0x20,%rax
    9c8e:	48 39 d0             	cmp    %rdx,%rax
    9c91:	73 17                	jae    9caa <fwp_main_thread+0xafa>
    9c93:	48 01 c7             	add    %rax,%rdi
    9c96:	0f b6 07             	movzbl (%rdi),%eax
    9c99:	84 c0                	test   %al,%al
    9c9b:	74 0d                	je     9caa <fwp_main_thread+0xafa>
    9c9d:	3c fd                	cmp    $0xfd,%al
    9c9f:	0f 87 77 15 00 00    	ja     b21c <fwp_main_thread+0x206c>
    9ca5:	83 c0 01             	add    $0x1,%eax
    9ca8:	88 07                	mov    %al,(%rdi)
    9caa:	48 8d 3d 5f 63 00 00 	lea    0x635f(%rip),%rdi        # 10010 <fc37>
    9cb1:	45 31 ed             	xor    %r13d,%r13d
    9cb4:	e8 a7 ca ff ff       	call   6760 <fwp_closure_drop>
    9cb9:	48 8b 1c 24          	mov    (%rsp),%rbx
    9cbd:	0f 1f 00             	nopl   (%rax)
    9cc0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    9cc4:	49 83 c5 01          	add    $0x1,%r13
    9cc8:	48 85 db             	test   %rbx,%rbx
    9ccb:	75 f3                	jne    9cc0 <fwp_main_thread+0xb10>
    9ccd:	31 ff                	xor    %edi,%edi
    9ccf:	e8 7c a5 ff ff       	call   4250 <descent_phase_step>
    9cd4:	49 81 fd ff ff ff 7f 	cmp    $0x7fffffff,%r13
    9cdb:	0f 87 f3 16 00 00    	ja     b3d4 <fwp_main_thread+0x2224>
    9ce1:	8b 35 79 63 00 00    	mov    0x6379(%rip),%esi        # 10060 <registered_finish.1>
    9ce7:	85 f6                	test   %esi,%esi
    9ce9:	0f 84 f1 11 00 00    	je     aee0 <fwp_main_thread+0x1d30>
    9cef:	48 8b 15 e2 63 01 00 	mov    0x163e2(%rip),%rdx        # 200d8 <fwp_tape_next_slot>
    9cf6:	4c 8b 35 eb 63 01 00 	mov    0x163eb(%rip),%r14        # 200e8 <fwp_ntapes>
    9cfd:	49 39 d6             	cmp    %rdx,%r14
    9d00:	0f 8e 3a 10 00 00    	jle    ad40 <fwp_main_thread+0x1b90>
    9d06:	48 6b c2 68          	imul   $0x68,%rdx,%rax
    9d0a:	48 03 05 df 63 01 00 	add    0x163df(%rip),%rax        # 200f0 <fwp_tapes>
    9d11:	0f 1f 40 00          	nopl   0x0(%rax)
    9d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9d1c:	00 00 00 00 
    9d20:	8b 48 04             	mov    0x4(%rax),%ecx
    9d23:	85 c9                	test   %ecx,%ecx
    9d25:	75 0c                	jne    9d33 <fwp_main_thread+0xb83>
    9d27:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    9d2d:	0f 86 0d 10 00 00    	jbe    ad40 <fwp_main_thread+0x1b90>
    9d33:	48 83 c2 01          	add    $0x1,%rdx
    9d37:	48 83 c0 68          	add    $0x68,%rax
    9d3b:	49 39 d6             	cmp    %rdx,%r14
    9d3e:	75 e0                	jne    9d20 <fwp_main_thread+0xb70>
    9d40:	49 81 fe fe ff 00 00 	cmp    $0xfffe,%r14
    9d47:	0f 8f 9f 16 00 00    	jg     b3ec <fwp_main_thread+0x223c>
    9d4d:	4c 39 35 8c 63 01 00 	cmp    %r14,0x1638c(%rip)        # 200e0 <fwp_tapes_cap>
    9d54:	4c 8b 3d 95 63 01 00 	mov    0x16395(%rip),%r15        # 200f0 <fwp_tapes>
    9d5b:	75 3f                	jne    9d9c <fwp_main_thread+0xbec>
    9d5d:	4d 85 f6             	test   %r14,%r14
    9d60:	0f 84 aa 13 00 00    	je     b110 <fwp_main_thread+0x1f60>
    9d66:	4f 8d 24 36          	lea    (%r14,%r14,1),%r12
    9d6a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    9d6f:	49 39 c4             	cmp    %rax,%r12
    9d72:	4c 0f 4f e0          	cmovg  %rax,%r12
    9d76:	49 6b f4 68          	imul   $0x68,%r12,%rsi
    9d7a:	4c 89 ff             	mov    %r15,%rdi
    9d7d:	e8 4e 98 ff ff       	call   35d0 <realloc@plt>
    9d82:	49 89 c7             	mov    %rax,%r15
    9d85:	48 85 c0             	test   %rax,%rax
    9d88:	0f 84 c5 11 00 00    	je     af53 <fwp_main_thread+0x1da3>
    9d8e:	48 89 05 5b 63 01 00 	mov    %rax,0x1635b(%rip)        # 200f0 <fwp_tapes>
    9d95:	4c 89 25 44 63 01 00 	mov    %r12,0x16344(%rip)        # 200e0 <fwp_tapes_cap>
    9d9c:	49 6b c6 68          	imul   $0x68,%r14,%rax
    9da0:	4d 8d 66 01          	lea    0x1(%r14),%r12
    9da4:	4c 01 f8             	add    %r15,%rax
    9da7:	48 8d 78 08          	lea    0x8(%rax),%rdi
    9dab:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9db2:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    9db6:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    9dbd:	00 
    9dbe:	48 29 f8             	sub    %rdi,%rax
    9dc1:	8d 48 68             	lea    0x68(%rax),%ecx
    9dc4:	31 c0                	xor    %eax,%eax
    9dc6:	c1 e9 03             	shr    $0x3,%ecx
    9dc9:	f3 48 ab             	rep stos %rax,(%rdi)
    9dcc:	4c 89 25 15 63 01 00 	mov    %r12,0x16315(%rip)        # 200e8 <fwp_ntapes>
    9dd3:	49 6b d6 68          	imul   $0x68,%r14,%rdx
    9dd7:	66 49 0f 6e c5       	movq   %r13,%xmm0
    9ddc:	48 8d 3d 3f 23 00 00 	lea    0x233f(%rip),%rdi        # c122 <_IO_stdin_used+0x122>
    9de3:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    9de7:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    9dec:	4c 01 fa             	add    %r15,%rdx
    9def:	48 c7 42 60 00 00 00 	movq   $0x0,0x60(%rdx)
    9df6:	00 
    9df7:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    9dfc:	e8 9f 95 ff ff       	call   33a0 <getenv@plt>
    9e01:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    9e06:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    9e0c:	48 85 c0             	test   %rax,%rax
    9e0f:	0f 84 23 0d 00 00    	je     ab38 <fwp_main_thread+0x1988>
    9e15:	80 38 30             	cmpb   $0x30,(%rax)
    9e18:	0f 85 1a 0d 00 00    	jne    ab38 <fwp_main_thread+0x1988>
    9e1e:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9e22:	0f 85 10 0d 00 00    	jne    ab38 <fwp_main_thread+0x1988>
    9e28:	8b 02                	mov    (%rdx),%eax
    9e2a:	c7 42 04 01 00 00 00 	movl   $0x1,0x4(%rdx)
    9e31:	4c 89 25 a0 62 01 00 	mov    %r12,0x162a0(%rip)        # 200d8 <fwp_tape_next_slot>
    9e38:	44 8d 68 01          	lea    0x1(%rax),%r13d
    9e3c:	48 8b 05 4d 2d 00 00 	mov    0x2d4d(%rip),%rax        # cb90 <msg.4+0x20>
    9e43:	48 c7 42 50 00 00 00 	movq   $0x0,0x50(%rdx)
    9e4a:	00 
    9e4b:	44 89 2a             	mov    %r13d,(%rdx)
    9e4e:	48 89 42 58          	mov    %rax,0x58(%rdx)
    9e52:	48 8b 05 ff 85 01 00 	mov    0x185ff(%rip),%rax        # 22458 <fwp_cleanups>
    9e59:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    9e5d:	48 85 c0             	test   %rax,%rax
    9e60:	75 2a                	jne    9e8c <fwp_main_thread+0xcdc>
    9e62:	e9 a9 15 00 00       	jmp    b410 <fwp_main_thread+0x2260>
    9e67:	0f 1f 00             	nopl   (%rax)
    9e6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9e71:	00 00 00 00 
    9e75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9e7c:	00 00 00 00 
    9e80:	48 8b 00             	mov    (%rax),%rax
    9e83:	48 85 c0             	test   %rax,%rax
    9e86:	0f 84 84 15 00 00    	je     b410 <fwp_main_thread+0x2260>
    9e8c:	48 8d 3d 0d cc ff ff 	lea    -0x33f3(%rip),%rdi        # 6aa0 <fwp_tape_scope_release>
    9e93:	48 39 78 08          	cmp    %rdi,0x8(%rax)
    9e97:	75 e7                	jne    9e80 <fwp_main_thread+0xcd0>
    9e99:	48 8b 70 10          	mov    0x10(%rax),%rsi
    9e9d:	44 89 f1             	mov    %r14d,%ecx
    9ea0:	48 63 06             	movslq (%rsi),%rax
    9ea3:	48 89 72 50          	mov    %rsi,0x50(%rdx)
    9ea7:	89 42 5c             	mov    %eax,0x5c(%rdx)
    9eaa:	85 c0                	test   %eax,%eax
    9eac:	78 09                	js     9eb7 <fwp_main_thread+0xd07>
    9eae:	48 6b c0 68          	imul   $0x68,%rax,%rax
    9eb2:	45 89 74 07 58       	mov    %r14d,0x58(%r15,%rax,1)
    9eb7:	89 0e                	mov    %ecx,(%rsi)
    9eb9:	bf 01 00 00 00       	mov    $0x1,%edi
    9ebe:	e8 8d a3 ff ff       	call   4250 <descent_phase_step>
    9ec3:	48 8b 04 24          	mov    (%rsp),%rax
    9ec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9ece:	00 00 
    9ed0:	48 8b 40 10          	mov    0x10(%rax),%rax
    9ed4:	48 83 c3 01          	add    $0x1,%rbx
    9ed8:	48 85 c0             	test   %rax,%rax
    9edb:	75 f3                	jne    9ed0 <fwp_main_thread+0xd20>
    9edd:	4c 8b 34 24          	mov    (%rsp),%r14
    9ee1:	0f 1f 40 00          	nopl   0x0(%rax)
    9ee5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9eec:	00 00 00 00 
    9ef0:	4d 8b 76 10          	mov    0x10(%r14),%r14
    9ef4:	48 83 c0 01          	add    $0x1,%rax
    9ef8:	4d 85 f6             	test   %r14,%r14
    9efb:	75 f3                	jne    9ef0 <fwp_main_thread+0xd40>
    9efd:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    9f04:	ff ff 1f 
    9f07:	48 39 c2             	cmp    %rax,%rdx
    9f0a:	0f 82 d0 14 00 00    	jb     b3e0 <fwp_main_thread+0x2230>
    9f10:	48 85 db             	test   %rbx,%rbx
    9f13:	0f 8e 47 0e 00 00    	jle    ad60 <fwp_main_thread+0x1bb0>
    9f19:	48 39 c3             	cmp    %rax,%rbx
    9f1c:	48 0f 47 d8          	cmova  %rax,%rbx
    9f20:	48 89 d8             	mov    %rbx,%rax
    9f23:	48 c1 e8 3c          	shr    $0x3c,%rax
    9f27:	0f 85 b3 14 00 00    	jne    b3e0 <fwp_main_thread+0x2230>
    9f2d:	4c 8d 3c 1b          	lea    (%rbx,%rbx,1),%r15
    9f31:	49 c1 e5 10          	shl    $0x10,%r13
    9f35:	be 02 00 00 00       	mov    $0x2,%esi
    9f3a:	4d 09 e5             	or     %r12,%r13
    9f3d:	4a 8d 3c fd 08 00 00 	lea    0x8(,%r15,8),%rdi
    9f44:	00 
    9f45:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    9f4a:	e8 41 bd ff ff       	call   5c90 <fwp_heap_alloc>
    9f4f:	4c 89 38             	mov    %r15,(%rax)
    9f52:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9f59:	49 89 c4             	mov    %rax,%r12
    9f5c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9f63:	48 c1 e2 10          	shl    $0x10,%rdx
    9f67:	48 39 d0             	cmp    %rdx,%rax
    9f6a:	0f 83 10 11 00 00    	jae    b080 <fwp_main_thread+0x1ed0>
    9f70:	48 89 c2             	mov    %rax,%rdx
    9f73:	48 c1 ea 10          	shr    $0x10,%rdx
    9f77:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9f7b:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9f82:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9f86:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9f8a:	4d 85 ed             	test   %r13,%r13
    9f8d:	74 3a                	je     9fc9 <fwp_main_thread+0xe19>
    9f8f:	0f b6 0a             	movzbl (%rdx),%ecx
    9f92:	80 f9 02             	cmp    $0x2,%cl
    9f95:	0f 84 36 0e 00 00    	je     add1 <fwp_main_thread+0x1c21>
    9f9b:	80 f9 01             	cmp    $0x1,%cl
    9f9e:	75 29                	jne    9fc9 <fwp_main_thread+0xe19>
    9fa0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9fa3:	0f b7 c0             	movzwl %ax,%eax
    9fa6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9fa9:	48 0f af c1          	imul   %rcx,%rax
    9fad:	48 c1 e8 20          	shr    $0x20,%rax
    9fb1:	48 39 d0             	cmp    %rdx,%rax
    9fb4:	73 13                	jae    9fc9 <fwp_main_thread+0xe19>
    9fb6:	49 01 c5             	add    %rax,%r13
    9fb9:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9fbe:	0f 84 21 0e 00 00    	je     ade5 <fwp_main_thread+0x1c35>
    9fc4:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9fc9:	48 85 db             	test   %rbx,%rbx
    9fcc:	74 66                	je     a034 <fwp_main_thread+0xe84>
    9fce:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    9fd3:	48 8b 14 24          	mov    (%rsp),%rdx
    9fd7:	31 c0                	xor    %eax,%eax
    9fd9:	48 c1 e1 20          	shl    $0x20,%rcx
    9fdd:	66 90                	xchg   %ax,%ax
    9fdf:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9fe6:	00 00 00 00 
    9fea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9ff1:	00 00 00 00 
    9ff5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9ffc:	00 00 00 00 
    a000:	48 89 c6             	mov    %rax,%rsi
    a003:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    a008:	48 01 ce             	add    %rcx,%rsi
    a00b:	0f 80 b2 13 00 00    	jo     b3c3 <fwp_main_thread+0x2213>
    a011:	66 48 0f 6e de       	movq   %rsi,%xmm3
    a016:	48 89 c6             	mov    %rax,%rsi
    a019:	48 83 c0 01          	add    $0x1,%rax
    a01d:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    a021:	48 c1 e6 04          	shl    $0x4,%rsi
    a025:	41 0f 11 44 34 08    	movups %xmm0,0x8(%r12,%rsi,1)
    a02b:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a02f:	48 39 d8             	cmp    %rbx,%rax
    a032:	72 cc                	jb     a000 <fwp_main_thread+0xe50>
    a034:	49 8b 04 24          	mov    (%r12),%rax
    a038:	48 d1 e8             	shr    $1,%rax
    a03b:	0f 85 5f 0c 00 00    	jne    aca0 <fwp_main_thread+0x1af0>
    a041:	49 c7 04 24 00 00 00 	movq   $0x0,(%r12)
    a048:	00 
    a049:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    a050:	4c 89 e7             	mov    %r12,%rdi
    a053:	e8 78 d9 ff ff       	call   79d0 <fwp_drop10>
    a058:	bf 02 00 00 00       	mov    $0x2,%edi
    a05d:	e8 ee a1 ff ff       	call   4250 <descent_phase_step>
    a062:	4c 63 6c 24 10       	movslq 0x10(%rsp),%r13
    a067:	4c 89 ef             	mov    %r13,%rdi
    a06a:	e8 61 a6 ff ff       	call   46d0 <fwp_tape_of>
    a06f:	48 89 c6             	mov    %rax,%rsi
    a072:	48 8b 40 60          	mov    0x60(%rax),%rax
    a076:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    a07b:	48 85 c0             	test   %rax,%rax
    a07e:	0f 85 98 13 00 00    	jne    b41c <fwp_main_thread+0x226c>
    a084:	48 89 f7             	mov    %rsi,%rdi
    a087:	e8 74 9b ff ff       	call   3c00 <fwp_tape_unlink_scope>
    a08c:	f3 0f 6f 76 20       	movdqu 0x20(%rsi),%xmm6
    a091:	48 8b 5e 48          	mov    0x48(%rsi),%rbx
    a095:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    a09c:	f3 0f 6f 7e 30       	movdqu 0x30(%rsi),%xmm7
    a0a1:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    a0a6:	0f 29 74 24 40       	movaps %xmm6,0x40(%rsp)
    a0ab:	66 48 0f 6e f3       	movq   %rbx,%xmm6
    a0b0:	4c 8b 46 08          	mov    0x8(%rsi),%r8
    a0b4:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    a0b8:	48 8b 4e 40          	mov    0x40(%rsi),%rcx
    a0bc:	0f 29 7c 24 30       	movaps %xmm7,0x30(%rsp)
    a0c1:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    a0c5:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    a0cb:	77 1a                	ja     a0e7 <fwp_main_thread+0xf37>
    a0cd:	0f b7 44 24 10       	movzwl 0x10(%rsp),%eax
    a0d2:	83 e8 01             	sub    $0x1,%eax
    a0d5:	48 98                	cltq
    a0d7:	48 3b 05 fa 5f 01 00 	cmp    0x15ffa(%rip),%rax        # 200d8 <fwp_tape_next_slot>
    a0de:	7d 07                	jge    a0e7 <fwp_main_thread+0xf37>
    a0e0:	48 89 05 f1 5f 01 00 	mov    %rax,0x15ff1(%rip)        # 200d8 <fwp_tape_next_slot>
    a0e7:	48 8b 05 6a 83 01 00 	mov    0x1836a(%rip),%rax        # 22458 <fwp_cleanups>
    a0ee:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a0f2:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    a0f9:	00 
    a0fa:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    a0fe:	66 0f 6f 7c 24 40    	movdqa 0x40(%rsp),%xmm7
    a104:	66 0f 6f 74 24 30    	movdqa 0x30(%rsp),%xmm6
    a10a:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    a111:	00 
    a112:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    a119:	00 
    a11a:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    a11e:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    a122:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    a129:	00 
    a12a:	48 8d 05 3f af ff ff 	lea    -0x50c1(%rip),%rax        # 5070 <fwp_tape_buffers_release>
    a131:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    a138:	00 
    a139:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    a13e:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
    a145:	00 
    a146:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    a14d:	00 
    a14e:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
    a153:	0f 29 bc 24 d0 00 00 	movaps %xmm7,0xd0(%rsp)
    a15a:	00 
    a15b:	48 89 05 f6 82 01 00 	mov    %rax,0x182f6(%rip)        # 22458 <fwp_cleanups>
    a162:	0f 29 b4 24 e0 00 00 	movaps %xmm6,0xe0(%rsp)
    a169:	00 
    a16a:	0f 11 84 24 f8 00 00 	movups %xmm0,0xf8(%rsp)
    a171:	00 
    a172:	4d 85 ff             	test   %r15,%r15
    a175:	0f 88 a5 0d 00 00    	js     af20 <fwp_main_thread+0x1d70>
    a17b:	4c 89 f8             	mov    %r15,%rax
    a17e:	48 c1 f8 20          	sar    $0x20,%rax
    a182:	49 39 c5             	cmp    %rax,%r13
    a185:	0f 85 db 11 00 00    	jne    b366 <fwp_main_thread+0x21b6>
    a18b:	45 89 f9             	mov    %r15d,%r9d
    a18e:	4d 89 cd             	mov    %r9,%r13
    a191:	4c 39 ca             	cmp    %r9,%rdx
    a194:	0f 8e c0 11 00 00    	jle    b35a <fwp_main_thread+0x21aa>
    a19a:	4d 39 c8             	cmp    %r9,%r8
    a19d:	0f 8e 55 0c 00 00    	jle    adf8 <fwp_main_thread+0x1c48>
    a1a3:	49 39 d8             	cmp    %rbx,%r8
    a1a6:	0f 8f 94 0c 00 00    	jg     ae40 <fwp_main_thread+0x1c90>
    a1ac:	48 85 c9             	test   %rcx,%rcx
    a1af:	0f 84 85 0d 00 00    	je     af3a <fwp_main_thread+0x1d8a>
    a1b5:	4a 8d 14 c5 00 00 00 	lea    0x0(,%r8,8),%rdx
    a1bc:	00 
    a1bd:	48 89 cf             	mov    %rcx,%rdi
    a1c0:	31 f6                	xor    %esi,%esi
    a1c2:	31 db                	xor    %ebx,%ebx
    a1c4:	4c 89 4c 24 50       	mov    %r9,0x50(%rsp)
    a1c9:	4d 8d 68 ff          	lea    -0x1(%r8),%r13
    a1cd:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    a1d2:	e8 e9 92 ff ff       	call   34c0 <memset@plt>
    a1d7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    a1dc:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
    a1e1:	48 89 c1             	mov    %rax,%rcx
    a1e4:	f2 0f 10 05 ac 29 00 	movsd  0x29ac(%rip),%xmm0        # cb98 <msg.4+0x28>
    a1eb:	00 
    a1ec:	f2 42 0f 58 04 c9    	addsd  (%rcx,%r9,8),%xmm0
    a1f2:	f2 42 0f 11 04 c9    	movsd  %xmm0,(%rcx,%r9,8)
    a1f8:	bf 03 00 00 00       	mov    $0x3,%edi
    a1fd:	4c 01 05 fc 5e 01 00 	add    %r8,0x15efc(%rip)        # 20100 <descent_inputs>
    a204:	48 01 1d fd 5e 01 00 	add    %rbx,0x15efd(%rip)        # 20108 <descent_nodes>
    a20b:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
    a210:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    a215:	e8 36 a0 ff ff       	call   4250 <descent_phase_step>
    a21a:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    a21f:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    a224:	4d 39 e8             	cmp    %r13,%r8
    a227:	0f 8f 85 00 00 00    	jg     a2b2 <fwp_main_thread+0x1102>
    a22d:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
    a232:	4d 29 c5             	sub    %r8,%r13
    a235:	4e 8d 1c c1          	lea    (%rcx,%r8,8),%r11
    a239:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a23d:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
    a242:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
    a247:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
    a24c:	4b 8d 14 ea          	lea    (%r10,%r13,8),%rdx
    a250:	4d 29 d3             	sub    %r10,%r11
    a253:	4a 8d 04 af          	lea    (%rdi,%r13,4),%rax
    a257:	48 29 fe             	sub    %rdi,%rsi
    a25a:	4d 29 d1             	sub    %r10,%r9
    a25d:	eb 05                	jmp    a264 <fwp_main_thread+0x10b4>
    a25f:	90                   	nop
    a260:	48 83 e8 04          	sub    $0x4,%rax
    a264:	f2 41 0f 10 04 13    	movsd  (%r11,%rdx,1),%xmm0
    a26a:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    a26e:	7a 02                	jp     a272 <fwp_main_thread+0x10c2>
    a270:	74 37                	je     a2a9 <fwp_main_thread+0x10f9>
    a272:	4c 63 14 06          	movslq (%rsi,%rax,1),%r10
    a276:	45 85 d2             	test   %r10d,%r10d
    a279:	78 16                	js     a291 <fwp_main_thread+0x10e1>
    a27b:	f2 41 0f 10 0c 11    	movsd  (%r9,%rdx,1),%xmm1
    a281:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    a285:	f2 42 0f 58 0c d1    	addsd  (%rcx,%r10,8),%xmm1
    a28b:	f2 42 0f 11 0c d1    	movsd  %xmm1,(%rcx,%r10,8)
    a291:	4c 63 10             	movslq (%rax),%r10
    a294:	45 85 d2             	test   %r10d,%r10d
    a297:	78 10                	js     a2a9 <fwp_main_thread+0x10f9>
    a299:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    a29d:	f2 42 0f 58 04 d1    	addsd  (%rcx,%r10,8),%xmm0
    a2a3:	f2 42 0f 11 04 d1    	movsd  %xmm0,(%rcx,%r10,8)
    a2a9:	48 83 ea 08          	sub    $0x8,%rdx
    a2ad:	48 39 f8             	cmp    %rdi,%rax
    a2b0:	75 ae                	jne    a260 <fwp_main_thread+0x10b0>
    a2b2:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a2b9:	ff ff 1f 
    a2bc:	4c 39 c0             	cmp    %r8,%rax
    a2bf:	0f 82 03 11 00 00    	jb     b3c8 <fwp_main_thread+0x2218>
    a2c5:	4a 8d 3c c5 08 00 00 	lea    0x8(,%r8,8),%rdi
    a2cc:	00 
    a2cd:	be 02 00 00 00       	mov    $0x2,%esi
    a2d2:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
    a2d7:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    a2dc:	e8 af b9 ff ff       	call   5c90 <fwp_heap_alloc>
    a2e1:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    a2e6:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    a2eb:	48 89 c3             	mov    %rax,%rbx
    a2ee:	4c 89 00             	mov    %r8,(%rax)
    a2f1:	31 c0                	xor    %eax,%eax
    a2f3:	4d 85 c0             	test   %r8,%r8
    a2f6:	74 1a                	je     a312 <fwp_main_thread+0x1162>
    a2f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a2ff:	00 
    a300:	48 8b 14 c1          	mov    (%rcx,%rax,8),%rdx
    a304:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    a309:	48 83 c0 01          	add    $0x1,%rax
    a30d:	49 39 c0             	cmp    %rax,%r8
    a310:	75 ee                	jne    a300 <fwp_main_thread+0x1150>
    a312:	bf 05 00 00 00       	mov    $0x5,%edi
    a317:	e8 34 9f ff ff       	call   4250 <descent_phase_step>
    a31c:	4c 8b a4 24 b0 00 00 	mov    0xb0(%rsp),%r12
    a323:	00 
    a324:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    a329:	4c 89 25 28 81 01 00 	mov    %r12,0x18128(%rip)        # 22458 <fwp_cleanups>
    a330:	e8 3b ad ff ff       	call   5070 <fwp_tape_buffers_release>
    a335:	bf 06 00 00 00       	mov    $0x6,%edi
    a33a:	e8 11 9f ff ff       	call   4250 <descent_phase_step>
    a33f:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a346:	48 89 d8             	mov    %rbx,%rax
    a349:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a350:	48 c1 e2 10          	shl    $0x10,%rdx
    a354:	48 39 d0             	cmp    %rdx,%rax
    a357:	73 59                	jae    a3b2 <fwp_main_thread+0x1202>
    a359:	48 89 c2             	mov    %rax,%rdx
    a35c:	48 c1 ea 10          	shr    $0x10,%rdx
    a360:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a364:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a36b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a36f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a373:	4d 85 ed             	test   %r13,%r13
    a376:	74 3a                	je     a3b2 <fwp_main_thread+0x1202>
    a378:	0f b6 0a             	movzbl (%rdx),%ecx
    a37b:	80 f9 02             	cmp    $0x2,%cl
    a37e:	0f 84 04 0c 00 00    	je     af88 <fwp_main_thread+0x1dd8>
    a384:	80 f9 01             	cmp    $0x1,%cl
    a387:	75 29                	jne    a3b2 <fwp_main_thread+0x1202>
    a389:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a38c:	0f b7 c0             	movzwl %ax,%eax
    a38f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a392:	48 0f af c1          	imul   %rcx,%rax
    a396:	48 c1 e8 20          	shr    $0x20,%rax
    a39a:	48 39 d0             	cmp    %rdx,%rax
    a39d:	73 13                	jae    a3b2 <fwp_main_thread+0x1202>
    a39f:	49 01 c5             	add    %rax,%r13
    a3a2:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a3a7:	0f 84 ef 0b 00 00    	je     af9c <fwp_main_thread+0x1dec>
    a3ad:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a3b2:	4c 3b 64 24 60       	cmp    0x60(%rsp),%r12
    a3b7:	0f 85 8e 93 ff ff    	jne    374b <fwp_main_thread.cold>
    a3bd:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
    a3c4:	00 
    a3c5:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
    a3ca:	48 89 05 87 80 01 00 	mov    %rax,0x18087(%rip)        # 22458 <fwp_cleanups>
    a3d1:	e8 ca c6 ff ff       	call   6aa0 <fwp_tape_scope_release>
    a3d6:	48 8b 03             	mov    (%rbx),%rax
    a3d9:	49 89 c5             	mov    %rax,%r13
    a3dc:	49 0f ba f5 3f       	btr    $0x3f,%r13
    a3e1:	48 85 c0             	test   %rax,%rax
    a3e4:	0f 88 e6 07 00 00    	js     abd0 <fwp_main_thread+0x1a20>
    a3ea:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a3f1:	48 89 d8             	mov    %rbx,%rax
    a3f4:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a3fb:	48 c1 e2 10          	shl    $0x10,%rdx
    a3ff:	48 39 d0             	cmp    %rdx,%rax
    a402:	0f 83 c8 07 00 00    	jae    abd0 <fwp_main_thread+0x1a20>
    a408:	48 89 c2             	mov    %rax,%rdx
    a40b:	48 c1 ea 10          	shr    $0x10,%rdx
    a40f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a413:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a41a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a41e:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    a422:	48 85 c9             	test   %rcx,%rcx
    a425:	0f 84 a5 07 00 00    	je     abd0 <fwp_main_thread+0x1a20>
    a42b:	0f b6 32             	movzbl (%rdx),%esi
    a42e:	40 80 fe 02          	cmp    $0x2,%sil
    a432:	0f 84 80 07 00 00    	je     abb8 <fwp_main_thread+0x1a08>
    a438:	40 80 fe 01          	cmp    $0x1,%sil
    a43c:	0f 85 8e 07 00 00    	jne    abd0 <fwp_main_thread+0x1a20>
    a442:	8b 72 18             	mov    0x18(%rdx),%esi
    a445:	0f b7 c0             	movzwl %ax,%eax
    a448:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a44b:	48 0f af c6          	imul   %rsi,%rax
    a44f:	48 c1 e8 20          	shr    $0x20,%rax
    a453:	48 39 d0             	cmp    %rdx,%rax
    a456:	0f 83 74 07 00 00    	jae    abd0 <fwp_main_thread+0x1a20>
    a45c:	48 01 c1             	add    %rax,%rcx
    a45f:	80 39 01             	cmpb   $0x1,(%rcx)
    a462:	0f 85 68 07 00 00    	jne    abd0 <fwp_main_thread+0x1a20>
    a468:	48 89 da             	mov    %rbx,%rdx
    a46b:	49 89 dc             	mov    %rbx,%r12
    a46e:	31 ff                	xor    %edi,%edi
    a470:	49 8d 4c 24 08       	lea    0x8(%r12),%rcx
    a475:	31 c0                	xor    %eax,%eax
    a477:	4d 85 ed             	test   %r13,%r13
    a47a:	75 2d                	jne    a4a9 <fwp_main_thread+0x12f9>
    a47c:	eb 5a                	jmp    a4d8 <fwp_main_thread+0x1328>
    a47e:	66 90                	xchg   %ax,%ax
    a480:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    a484:	0f 88 2d 0f 00 00    	js     b3b7 <fwp_main_thread+0x2207>
    a48a:	f2 0f 10 05 1e 27 00 	movsd  0x271e(%rip),%xmm0        # cbb0 <msg.4+0x40>
    a491:	00 
    a492:	f2 0f 59 04 c6       	mulsd  (%rsi,%rax,8),%xmm0
    a497:	48 83 c0 01          	add    $0x1,%rax
    a49b:	48 83 c1 08          	add    $0x8,%rcx
    a49f:	f2 0f 11 41 f8       	movsd  %xmm0,-0x8(%rcx)
    a4a4:	49 39 c5             	cmp    %rax,%r13
    a4a7:	74 2f                	je     a4d8 <fwp_main_thread+0x1328>
    a4a9:	48 8d 73 08          	lea    0x8(%rbx),%rsi
    a4ad:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    a4b1:	79 cd                	jns    a480 <fwp_main_thread+0x12d0>
    a4b3:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    a4b7:	eb c7                	jmp    a480 <fwp_main_thread+0x12d0>
    a4b9:	48 8d 3d a0 a7 ff ff 	lea    -0x5860(%rip),%rdi        # 4c60 <fwp_heap_report>
    a4c0:	e8 9b 11 00 00       	call   b660 <atexit>
    a4c5:	e9 2e ed ff ff       	jmp    91f8 <fwp_main_thread+0x48>
    a4ca:	e8 a1 a8 ff ff       	call   4d70 <fwp_heap_init>
    a4cf:	e9 14 ed ff ff       	jmp    91e8 <fwp_main_thread+0x38>
    a4d4:	0f 1f 40 00          	nopl   0x0(%rax)
    a4d8:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    a4dd:	e8 ee d4 ff ff       	call   79d0 <fwp_drop10>
    a4e2:	48 8b 1c 24          	mov    (%rsp),%rbx
    a4e6:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a4eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a4f0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    a4f4:	49 83 c6 01          	add    $0x1,%r14
    a4f8:	48 85 db             	test   %rbx,%rbx
    a4fb:	75 f3                	jne    a4f0 <fwp_main_thread+0x1340>
    a4fd:	4c 8b 2a             	mov    (%rdx),%r13
    a500:	4d 85 ed             	test   %r13,%r13
    a503:	0f 88 07 01 00 00    	js     a610 <fwp_main_thread+0x1460>
    a509:	48 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%rcx
    a510:	4c 89 e0             	mov    %r12,%rax
    a513:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a51a:	48 c1 e1 10          	shl    $0x10,%rcx
    a51e:	48 39 c8             	cmp    %rcx,%rax
    a521:	0f 83 e9 00 00 00    	jae    a610 <fwp_main_thread+0x1460>
    a527:	48 89 c1             	mov    %rax,%rcx
    a52a:	48 c1 e9 10          	shr    $0x10,%rcx
    a52e:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    a532:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    a539:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    a53d:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    a541:	48 85 f6             	test   %rsi,%rsi
    a544:	0f 84 c6 00 00 00    	je     a610 <fwp_main_thread+0x1460>
    a54a:	0f b6 39             	movzbl (%rcx),%edi
    a54d:	40 80 ff 02          	cmp    $0x2,%dil
    a551:	0f 84 a1 00 00 00    	je     a5f8 <fwp_main_thread+0x1448>
    a557:	40 80 ff 01          	cmp    $0x1,%dil
    a55b:	0f 85 af 00 00 00    	jne    a610 <fwp_main_thread+0x1460>
    a561:	8b 79 18             	mov    0x18(%rcx),%edi
    a564:	0f b7 c0             	movzwl %ax,%eax
    a567:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a56a:	48 0f af c7          	imul   %rdi,%rax
    a56e:	48 c1 e8 20          	shr    $0x20,%rax
    a572:	48 39 c8             	cmp    %rcx,%rax
    a575:	0f 83 95 00 00 00    	jae    a610 <fwp_main_thread+0x1460>
    a57b:	48 01 c6             	add    %rax,%rsi
    a57e:	80 3e 01             	cmpb   $0x1,(%rsi)
    a581:	0f 85 89 00 00 00    	jne    a610 <fwp_main_thread+0x1460>
    a587:	4d 39 ee             	cmp    %r13,%r14
    a58a:	4c 89 e9             	mov    %r13,%rcx
    a58d:	49 0f 46 ce          	cmovbe %r14,%rcx
    a591:	48 85 c9             	test   %rcx,%rcx
    a594:	0f 84 8b 0b 00 00    	je     b125 <fwp_main_thread+0x1f75>
    a59a:	c7 44 24 10 01 00 00 	movl   $0x1,0x10(%rsp)
    a5a1:	00 
    a5a2:	4c 8d 7a 08          	lea    0x8(%rdx),%r15
    a5a6:	48 8b 34 24          	mov    (%rsp),%rsi
    a5aa:	4c 8d 04 cd 00 00 00 	lea    0x0(,%rcx,8),%r8
    a5b1:	00 
    a5b2:	31 c0                	xor    %eax,%eax
    a5b4:	49 8d 7c 24 08       	lea    0x8(%r12),%rdi
    a5b9:	eb 27                	jmp    a5e2 <fwp_main_thread+0x1432>
    a5bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a5c0:	f2 0f 10 46 08       	movsd  0x8(%rsi),%xmm0
    a5c5:	f2 41 0f 5c 04 01    	subsd  (%r9,%rax,1),%xmm0
    a5cb:	f2 41 0f 11 04 07    	movsd  %xmm0,(%r15,%rax,1)
    a5d1:	48 83 c0 08          	add    $0x8,%rax
    a5d5:	48 8b 76 10          	mov    0x10(%rsi),%rsi
    a5d9:	49 39 c0             	cmp    %rax,%r8
    a5dc:	0f 84 de 00 00 00    	je     a6c0 <fwp_main_thread+0x1510>
    a5e2:	49 89 f9             	mov    %rdi,%r9
    a5e5:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    a5e9:	79 d5                	jns    a5c0 <fwp_main_thread+0x1410>
    a5eb:	4d 8b 4c 24 10       	mov    0x10(%r12),%r9
    a5f0:	eb ce                	jmp    a5c0 <fwp_main_thread+0x1410>
    a5f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a5f8:	66 85 c0             	test   %ax,%ax
    a5fb:	0f 84 7d ff ff ff    	je     a57e <fwp_main_thread+0x13ce>
    a601:	0f 1f 40 00          	nopl   0x0(%rax)
    a605:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a60c:	00 00 00 00 
    a610:	48 8b 04 24          	mov    (%rsp),%rax
    a614:	45 31 f6             	xor    %r14d,%r14d
    a617:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a61e:	00 00 
    a620:	48 8b 40 10          	mov    0x10(%rax),%rax
    a624:	4c 89 f1             	mov    %r14,%rcx
    a627:	49 83 c6 01          	add    $0x1,%r14
    a62b:	48 85 c0             	test   %rax,%rax
    a62e:	75 f0                	jne    a620 <fwp_main_thread+0x1470>
    a630:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a637:	ff ff 1f 
    a63a:	4c 39 f0             	cmp    %r14,%rax
    a63d:	0f 82 9d 0d 00 00    	jb     b3e0 <fwp_main_thread+0x2230>
    a643:	48 8d 3c cd 10 00 00 	lea    0x10(,%rcx,8),%rdi
    a64a:	00 
    a64b:	be 02 00 00 00       	mov    $0x2,%esi
    a650:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    a655:	e8 36 b6 ff ff       	call   5c90 <fwp_heap_alloc>
    a65a:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a65f:	49 89 c7             	mov    %rax,%r15
    a662:	48 89 c1             	mov    %rax,%rcx
    a665:	48 8b 04 24          	mov    (%rsp),%rax
    a669:	90                   	nop
    a66a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a671:	00 00 00 00 
    a675:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a67c:	00 00 00 00 
    a680:	48 8b 70 08          	mov    0x8(%rax),%rsi
    a684:	48 83 c1 08          	add    $0x8,%rcx
    a688:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    a68c:	48 8b 40 10          	mov    0x10(%rax),%rax
    a690:	48 85 c0             	test   %rax,%rax
    a693:	75 eb                	jne    a680 <fwp_main_thread+0x14d0>
    a695:	4c 89 e9             	mov    %r13,%rcx
    a698:	48 0f ba f1 3f       	btr    $0x3f,%rcx
    a69d:	4c 39 f1             	cmp    %r14,%rcx
    a6a0:	49 0f 47 ce          	cmova  %r14,%rcx
    a6a4:	48 85 c9             	test   %rcx,%rcx
    a6a7:	0f 84 73 0a 00 00    	je     b120 <fwp_main_thread+0x1f70>
    a6ad:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
    a6b4:	00 
    a6b5:	e9 ec fe ff ff       	jmp    a5a6 <fwp_main_thread+0x13f6>
    a6ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a6c0:	4c 8b 85 d8 13 00 00 	mov    0x13d8(%rbp),%r8
    a6c7:	4c 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%r9
    a6ce:	45 31 f6             	xor    %r14d,%r14d
    a6d1:	4c 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%r10
    a6d8:	48 8b 14 24          	mov    (%rsp),%rdx
    a6dc:	49 c1 e0 10          	shl    $0x10,%r8
    a6e0:	eb 18                	jmp    a6fa <fwp_main_thread+0x154a>
    a6e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a6e8:	49 83 c6 01          	add    $0x1,%r14
    a6ec:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a6f0:	49 39 ce             	cmp    %rcx,%r14
    a6f3:	73 5b                	jae    a750 <fwp_main_thread+0x15a0>
    a6f5:	48 85 d2             	test   %rdx,%rdx
    a6f8:	74 56                	je     a750 <fwp_main_thread+0x15a0>
    a6fa:	48 89 d0             	mov    %rdx,%rax
    a6fd:	4c 29 c8             	sub    %r9,%rax
    a700:	4c 39 c0             	cmp    %r8,%rax
    a703:	73 4b                	jae    a750 <fwp_main_thread+0x15a0>
    a705:	48 89 c6             	mov    %rax,%rsi
    a708:	48 c1 ee 10          	shr    $0x10,%rsi
    a70c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    a710:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    a714:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a718:	48 85 ff             	test   %rdi,%rdi
    a71b:	74 33                	je     a750 <fwp_main_thread+0x15a0>
    a71d:	44 0f b6 1e          	movzbl (%rsi),%r11d
    a721:	41 80 fb 02          	cmp    $0x2,%r11b
    a725:	0f 84 ad 03 00 00    	je     aad8 <fwp_main_thread+0x1928>
    a72b:	41 80 fb 01          	cmp    $0x1,%r11b
    a72f:	75 1f                	jne    a750 <fwp_main_thread+0x15a0>
    a731:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    a735:	0f b7 c0             	movzwl %ax,%eax
    a738:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a73b:	49 0f af c3          	imul   %r11,%rax
    a73f:	48 c1 e8 20          	shr    $0x20,%rax
    a743:	48 39 f0             	cmp    %rsi,%rax
    a746:	73 08                	jae    a750 <fwp_main_thread+0x15a0>
    a748:	48 01 c7             	add    %rax,%rdi
    a74b:	80 3f 01             	cmpb   $0x1,(%rdi)
    a74e:	74 98                	je     a6e8 <fwp_main_thread+0x1538>
    a750:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    a754:	49 39 ce             	cmp    %rcx,%r14
    a757:	72 3f                	jb     a798 <fwp_main_thread+0x15e8>
    a759:	e9 92 03 00 00       	jmp    aaf0 <fwp_main_thread+0x1940>
    a75e:	66 90                	xchg   %ax,%ax
    a760:	40 80 fe 01          	cmp    $0x1,%sil
    a764:	75 25                	jne    a78b <fwp_main_thread+0x15db>
    a766:	8b 71 18             	mov    0x18(%rcx),%esi
    a769:	0f b7 c0             	movzwl %ax,%eax
    a76c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a76f:	48 0f af c6          	imul   %rsi,%rax
    a773:	48 c1 e8 20          	shr    $0x20,%rax
    a777:	48 39 c8             	cmp    %rcx,%rax
    a77a:	73 0f                	jae    a78b <fwp_main_thread+0x15db>
    a77c:	48 01 c2             	add    %rax,%rdx
    a77f:	80 3a ff             	cmpb   $0xff,(%rdx)
    a782:	0f 84 f8 04 00 00    	je     ac80 <fwp_main_thread+0x1ad0>
    a788:	c6 02 01             	movb   $0x1,(%rdx)
    a78b:	4d 39 ee             	cmp    %r13,%r14
    a78e:	0f 84 8c 00 00 00    	je     a820 <fwp_main_thread+0x1670>
    a794:	49 83 ed 01          	sub    $0x1,%r13
    a798:	f3 43 0f 7e 04 ef    	movq   (%r15,%r13,8),%xmm0
    a79e:	66 48 0f 6e eb       	movq   %rbx,%xmm5
    a7a3:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a7a8:	bf 01 00 00 00       	mov    $0x1,%edi
    a7ad:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    a7b1:	0f 29 84 24 40 01 00 	movaps %xmm0,0x140(%rsp)
    a7b8:	00 
    a7b9:	e8 f2 b5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    a7be:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a7c5:	48 89 c3             	mov    %rax,%rbx
    a7c8:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a7cf:	48 c1 e2 10          	shl    $0x10,%rdx
    a7d3:	48 39 d0             	cmp    %rdx,%rax
    a7d6:	73 b3                	jae    a78b <fwp_main_thread+0x15db>
    a7d8:	48 89 c2             	mov    %rax,%rdx
    a7db:	48 c1 ea 10          	shr    $0x10,%rdx
    a7df:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a7e3:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a7ea:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a7ee:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    a7f2:	48 85 d2             	test   %rdx,%rdx
    a7f5:	74 94                	je     a78b <fwp_main_thread+0x15db>
    a7f7:	0f b6 31             	movzbl (%rcx),%esi
    a7fa:	40 80 fe 02          	cmp    $0x2,%sil
    a7fe:	0f 85 5c ff ff ff    	jne    a760 <fwp_main_thread+0x15b0>
    a804:	66 85 c0             	test   %ax,%ax
    a807:	0f 84 72 ff ff ff    	je     a77f <fwp_main_thread+0x15cf>
    a80d:	4d 39 ee             	cmp    %r13,%r14
    a810:	75 82                	jne    a794 <fwp_main_thread+0x15e4>
    a812:	0f 1f 00             	nopl   (%rax)
    a815:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a81c:	00 00 00 00 
    a820:	4d 85 f6             	test   %r14,%r14
    a823:	0f 85 c7 02 00 00    	jne    aaf0 <fwp_main_thread+0x1940>
    a829:	8b 44 24 10          	mov    0x10(%rsp),%eax
    a82d:	4c 8b 34 24          	mov    (%rsp),%r14
    a831:	85 c0                	test   %eax,%eax
    a833:	4c 0f 45 7c 24 20    	cmovne 0x20(%rsp),%r15
    a839:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
    a83e:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    a843:	e8 48 af ff ff       	call   5790 <fwp_mem_free>
    a848:	4c 89 e7             	mov    %r12,%rdi
    a84b:	e8 80 d1 ff ff       	call   79d0 <fwp_drop10>
    a850:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a857:	4c 89 f0             	mov    %r14,%rax
    a85a:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a861:	48 c1 e2 10          	shl    $0x10,%rdx
    a865:	48 39 d0             	cmp    %rdx,%rax
    a868:	73 76                	jae    a8e0 <fwp_main_thread+0x1730>
    a86a:	48 89 c2             	mov    %rax,%rdx
    a86d:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    a874:	48 c1 ea 10          	shr    $0x10,%rdx
    a878:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    a87c:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    a880:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a884:	4d 85 e4             	test   %r12,%r12
    a887:	74 57                	je     a8e0 <fwp_main_thread+0x1730>
    a889:	0f b6 0a             	movzbl (%rdx),%ecx
    a88c:	80 f9 02             	cmp    $0x2,%cl
    a88f:	0f 84 6b 06 00 00    	je     af00 <fwp_main_thread+0x1d50>
    a895:	80 f9 01             	cmp    $0x1,%cl
    a898:	75 46                	jne    a8e0 <fwp_main_thread+0x1730>
    a89a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a89d:	0f b7 c0             	movzwl %ax,%eax
    a8a0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a8a3:	48 0f af c1          	imul   %rcx,%rax
    a8a7:	48 c1 e8 20          	shr    $0x20,%rax
    a8ab:	48 39 d0             	cmp    %rdx,%rax
    a8ae:	73 30                	jae    a8e0 <fwp_main_thread+0x1730>
    a8b0:	49 01 c4             	add    %rax,%r12
    a8b3:	41 0f b6 04 24       	movzbl (%r12),%eax
    a8b8:	84 c0                	test   %al,%al
    a8ba:	74 24                	je     a8e0 <fwp_main_thread+0x1730>
    a8bc:	3c 01                	cmp    $0x1,%al
    a8be:	0f 84 ec 06 00 00    	je     afb0 <fwp_main_thread+0x1e00>
    a8c4:	3c ff                	cmp    $0xff,%al
    a8c6:	0f 84 e9 08 00 00    	je     b1b5 <fwp_main_thread+0x2005>
    a8cc:	83 e8 01             	sub    $0x1,%eax
    a8cf:	41 88 04 24          	mov    %al,(%r12)
    a8d3:	66 90                	xchg   %ax,%ax
    a8d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a8dc:	00 00 00 00 
    a8e0:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    a8e5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a8e9:	b9 01 00 00 00       	mov    $0x1,%ecx
    a8ee:	48 89 de             	mov    %rbx,%rsi
    a8f1:	48 8d 15 88 52 00 00 	lea    0x5288(%rip),%rdx        # fb80 <d0>
    a8f8:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    a8ff:	00 
    a900:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
    a907:	00 00 00 00 00 
    a90c:	e8 5f d8 ff ff       	call   8170 <fwp_write>
    a911:	4c 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%r14
    a918:	00 
    a919:	4c 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%r15
    a920:	00 
    a921:	48 8d 05 69 17 00 00 	lea    0x1769(%rip),%rax        # c091 <_IO_stdin_used+0x91>
    a928:	4d 85 f6             	test   %r14,%r14
    a92b:	4c 0f 44 f0          	cmove  %rax,%r14
    a92f:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    a933:	0f 87 f4 0a 00 00    	ja     b42d <fwp_main_thread+0x227d>
    a939:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    a93d:	be 01 00 00 00       	mov    $0x1,%esi
    a942:	e8 49 b3 ff ff       	call   5c90 <fwp_heap_alloc>
    a947:	4c 89 fa             	mov    %r15,%rdx
    a94a:	4c 89 f6             	mov    %r14,%rsi
    a94d:	4c 89 38             	mov    %r15,(%rax)
    a950:	4c 8d 68 08          	lea    0x8(%rax),%r13
    a954:	49 89 c4             	mov    %rax,%r12
    a957:	4c 89 ef             	mov    %r13,%rdi
    a95a:	e8 41 8c ff ff       	call   35a0 <memcpy@plt>
    a95f:	43 c6 44 3c 08 00    	movb   $0x0,0x8(%r12,%r15,1)
    a965:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
    a96c:	00 
    a96d:	e8 4e 8a ff ff       	call   33c0 <free@plt>
    a972:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a979:	4c 89 e0             	mov    %r12,%rax
    a97c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a983:	48 c1 e2 10          	shl    $0x10,%rdx
    a987:	48 39 d0             	cmp    %rdx,%rax
    a98a:	73 57                	jae    a9e3 <fwp_main_thread+0x1833>
    a98c:	48 89 c2             	mov    %rax,%rdx
    a98f:	48 c1 ea 10          	shr    $0x10,%rdx
    a993:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a997:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a99e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a9a2:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    a9a6:	4d 85 f6             	test   %r14,%r14
    a9a9:	74 38                	je     a9e3 <fwp_main_thread+0x1833>
    a9ab:	0f b6 0a             	movzbl (%rdx),%ecx
    a9ae:	80 f9 02             	cmp    $0x2,%cl
    a9b1:	0f 84 39 07 00 00    	je     b0f0 <fwp_main_thread+0x1f40>
    a9b7:	80 f9 01             	cmp    $0x1,%cl
    a9ba:	75 27                	jne    a9e3 <fwp_main_thread+0x1833>
    a9bc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a9bf:	0f b7 c0             	movzwl %ax,%eax
    a9c2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a9c5:	48 0f af c1          	imul   %rcx,%rax
    a9c9:	48 c1 e8 20          	shr    $0x20,%rax
    a9cd:	48 39 d0             	cmp    %rdx,%rax
    a9d0:	73 11                	jae    a9e3 <fwp_main_thread+0x1833>
    a9d2:	49 01 c6             	add    %rax,%r14
    a9d5:	41 80 3e ff          	cmpb   $0xff,(%r14)
    a9d9:	0f 84 24 07 00 00    	je     b103 <fwp_main_thread+0x1f53>
    a9df:	41 c6 06 01          	movb   $0x1,(%r14)
    a9e3:	48 89 df             	mov    %rbx,%rdi
    a9e6:	e8 f5 cb ff ff       	call   75e0 <fwp_drop0>
    a9eb:	49 8b 14 24          	mov    (%r12),%rdx
    a9ef:	be 01 00 00 00       	mov    $0x1,%esi
    a9f4:	4c 89 ef             	mov    %r13,%rdi
    a9f7:	48 8b 0d 22 7a 01 00 	mov    0x17a22(%rip),%rcx        # 22420 <fwp_prog_out>
    a9fe:	e8 7d 8c ff ff       	call   3680 <fwrite@plt>
    aa03:	48 8b 35 16 7a 01 00 	mov    0x17a16(%rip),%rsi        # 22420 <fwp_prog_out>
    aa0a:	bf 0a 00 00 00       	mov    $0xa,%edi
    aa0f:	e8 cc 8a ff ff       	call   34e0 <fputc@plt>
    aa14:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    aa1b:	4c 89 e0             	mov    %r12,%rax
    aa1e:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    aa25:	48 c1 e2 10          	shl    $0x10,%rdx
    aa29:	48 39 d0             	cmp    %rdx,%rax
    aa2c:	73 72                	jae    aaa0 <fwp_main_thread+0x18f0>
    aa2e:	48 89 c2             	mov    %rax,%rdx
    aa31:	48 c1 ea 10          	shr    $0x10,%rdx
    aa35:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aa39:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    aa40:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aa44:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    aa48:	48 85 db             	test   %rbx,%rbx
    aa4b:	74 53                	je     aaa0 <fwp_main_thread+0x18f0>
    aa4d:	0f b6 0a             	movzbl (%rdx),%ecx
    aa50:	80 f9 02             	cmp    $0x2,%cl
    aa53:	0f 84 67 06 00 00    	je     b0c0 <fwp_main_thread+0x1f10>
    aa59:	80 f9 01             	cmp    $0x1,%cl
    aa5c:	75 42                	jne    aaa0 <fwp_main_thread+0x18f0>
    aa5e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aa61:	0f b7 c0             	movzwl %ax,%eax
    aa64:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aa67:	48 0f af c1          	imul   %rcx,%rax
    aa6b:	48 c1 e8 20          	shr    $0x20,%rax
    aa6f:	48 39 d0             	cmp    %rdx,%rax
    aa72:	73 2c                	jae    aaa0 <fwp_main_thread+0x18f0>
    aa74:	48 01 c3             	add    %rax,%rbx
    aa77:	0f b6 03             	movzbl (%rbx),%eax
    aa7a:	84 c0                	test   %al,%al
    aa7c:	74 22                	je     aaa0 <fwp_main_thread+0x18f0>
    aa7e:	3c 01                	cmp    $0x1,%al
    aa80:	0f 84 56 06 00 00    	je     b0dc <fwp_main_thread+0x1f2c>
    aa86:	3c ff                	cmp    $0xff,%al
    aa88:	0f 84 32 08 00 00    	je     b2c0 <fwp_main_thread+0x2110>
    aa8e:	83 e8 01             	sub    $0x1,%eax
    aa91:	88 03                	mov    %al,(%rbx)
    aa93:	66 90                	xchg   %ax,%ax
    aa95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aa9c:	00 00 00 00 
    aaa0:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    aaa5:	48 8b 40 10          	mov    0x10(%rax),%rax
    aaa9:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    aaae:	48 85 c0             	test   %rax,%rax
    aab1:	0f 84 97 06 00 00    	je     b14e <fwp_main_thread+0x1f9e>
    aab7:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    aabe:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    aac5:	48 8b 1d 8c 79 01 00 	mov    0x1798c(%rip),%rbx        # 22458 <fwp_cleanups>
    aacc:	e9 af f0 ff ff       	jmp    9b80 <fwp_main_thread+0x9d0>
    aad1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aad8:	66 85 c0             	test   %ax,%ax
    aadb:	0f 84 6a fc ff ff    	je     a74b <fwp_main_thread+0x159b>
    aae1:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    aae5:	49 39 ce             	cmp    %rcx,%r14
    aae8:	0f 82 aa fc ff ff    	jb     a798 <fwp_main_thread+0x15e8>
    aaee:	66 90                	xchg   %ax,%ax
    aaf0:	4b 8d 34 f7          	lea    (%r15,%r14,8),%rsi
    aaf4:	4c 8b 34 24          	mov    (%rsp),%r14
    aaf8:	4c 89 f8             	mov    %r15,%rax
    aafb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ab00:	48 8b 10             	mov    (%rax),%rdx
    ab03:	48 83 c0 08          	add    $0x8,%rax
    ab07:	4c 89 f1             	mov    %r14,%rcx
    ab0a:	49 89 56 08          	mov    %rdx,0x8(%r14)
    ab0e:	4d 8b 76 10          	mov    0x10(%r14),%r14
    ab12:	48 39 f0             	cmp    %rsi,%rax
    ab15:	75 e9                	jne    ab00 <fwp_main_thread+0x1950>
    ab17:	8b 54 24 10          	mov    0x10(%rsp),%edx
    ab1b:	48 89 59 10          	mov    %rbx,0x10(%rcx)
    ab1f:	48 8b 1c 24          	mov    (%rsp),%rbx
    ab23:	85 d2                	test   %edx,%edx
    ab25:	4c 0f 45 7c 24 20    	cmovne 0x20(%rsp),%r15
    ab2b:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
    ab30:	e9 09 fd ff ff       	jmp    a83e <fwp_main_thread+0x168e>
    ab35:	0f 1f 00             	nopl   (%rax)
    ab38:	48 83 3d 48 55 01 00 	cmpq   $0x0,0x15548(%rip)        # 20088 <fwp_tape_cached_bytes>
    ab3f:	00 
    ab40:	0f 84 e2 f2 ff ff    	je     9e28 <fwp_main_thread+0xc78>
    ab46:	66 0f 6f 0d 52 55 01 	movdqa 0x15552(%rip),%xmm1        # 200a0 <fwp_tape_workspace>
    ab4d:	00 
    ab4e:	48 c7 05 2f 55 01 00 	movq   $0x0,0x1552f(%rip)        # 20088 <fwp_tape_cached_bytes>
    ab55:	00 00 00 00 
    ab59:	0f 11 4a 20          	movups %xmm1,0x20(%rdx)
    ab5d:	48 8b 05 5c 55 01 00 	mov    0x1555c(%rip),%rax        # 200c0 <fwp_tape_workspace+0x20>
    ab64:	66 0f 6f 0d 44 55 01 	movdqa 0x15544(%rip),%xmm1        # 200b0 <fwp_tape_workspace+0x10>
    ab6b:	00 
    ab6c:	48 89 42 40          	mov    %rax,0x40(%rdx)
    ab70:	48 8b 05 51 55 01 00 	mov    0x15551(%rip),%rax        # 200c8 <fwp_tape_workspace+0x28>
    ab77:	0f 11 4a 30          	movups %xmm1,0x30(%rdx)
    ab7b:	66 0f ef c9          	pxor   %xmm1,%xmm1
    ab7f:	48 89 42 18          	mov    %rax,0x18(%rdx)
    ab83:	48 8b 05 46 55 01 00 	mov    0x15546(%rip),%rax        # 200d0 <fwp_tape_workspace+0x30>
    ab8a:	0f 29 0d 0f 55 01 00 	movaps %xmm1,0x1550f(%rip)        # 200a0 <fwp_tape_workspace>
    ab91:	48 89 42 48          	mov    %rax,0x48(%rdx)
    ab95:	0f 29 0d 14 55 01 00 	movaps %xmm1,0x15514(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    ab9c:	48 c7 05 29 55 01 00 	movq   $0x0,0x15529(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    aba3:	00 00 00 00 
    aba7:	0f 29 0d 12 55 01 00 	movaps %xmm1,0x15512(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    abae:	e9 75 f2 ff ff       	jmp    9e28 <fwp_main_thread+0xc78>
    abb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    abb8:	66 85 c0             	test   %ax,%ax
    abbb:	0f 84 9e f8 ff ff    	je     a45f <fwp_main_thread+0x12af>
    abc1:	0f 1f 40 00          	nopl   0x0(%rax)
    abc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    abcc:	00 00 00 00 
    abd0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    abd7:	ff ff 1f 
    abda:	4c 39 e8             	cmp    %r13,%rax
    abdd:	0f 82 e5 07 00 00    	jb     b3c8 <fwp_main_thread+0x2218>
    abe3:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    abea:	00 
    abeb:	be 01 00 00 00       	mov    $0x1,%esi
    abf0:	e8 9b b0 ff ff       	call   5c90 <fwp_heap_alloc>
    abf5:	4c 89 28             	mov    %r13,(%rax)
    abf8:	48 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%rcx
    abff:	48 89 c2             	mov    %rax,%rdx
    ac02:	49 89 c4             	mov    %rax,%r12
    ac05:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    ac0c:	48 c1 e1 10          	shl    $0x10,%rcx
    ac10:	48 39 c8             	cmp    %rcx,%rax
    ac13:	73 59                	jae    ac6e <fwp_main_thread+0x1abe>
    ac15:	48 89 c1             	mov    %rax,%rcx
    ac18:	48 c1 e9 10          	shr    $0x10,%rcx
    ac1c:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    ac20:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    ac27:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    ac2b:	4c 8b 79 20          	mov    0x20(%rcx),%r15
    ac2f:	4d 85 ff             	test   %r15,%r15
    ac32:	74 3a                	je     ac6e <fwp_main_thread+0x1abe>
    ac34:	0f b6 31             	movzbl (%rcx),%esi
    ac37:	40 80 fe 02          	cmp    $0x2,%sil
    ac3b:	0f 84 0f 04 00 00    	je     b050 <fwp_main_thread+0x1ea0>
    ac41:	40 80 fe 01          	cmp    $0x1,%sil
    ac45:	75 27                	jne    ac6e <fwp_main_thread+0x1abe>
    ac47:	8b 71 18             	mov    0x18(%rcx),%esi
    ac4a:	0f b7 c0             	movzwl %ax,%eax
    ac4d:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    ac50:	48 0f af c6          	imul   %rsi,%rax
    ac54:	48 c1 e8 20          	shr    $0x20,%rax
    ac58:	48 39 c8             	cmp    %rcx,%rax
    ac5b:	73 11                	jae    ac6e <fwp_main_thread+0x1abe>
    ac5d:	49 01 c7             	add    %rax,%r15
    ac60:	41 80 3f ff          	cmpb   $0xff,(%r15)
    ac64:	0f 84 f9 03 00 00    	je     b063 <fwp_main_thread+0x1eb3>
    ac6a:	41 c6 07 01          	movb   $0x1,(%r15)
    ac6e:	48 89 df             	mov    %rbx,%rdi
    ac71:	e9 fa f7 ff ff       	jmp    a470 <fwp_main_thread+0x12c0>
    ac76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ac7d:	00 00 00 
    ac80:	48 89 d7             	mov    %rdx,%rdi
    ac83:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    ac88:	e8 c3 a8 ff ff       	call   5550 <fwp_rc_forget_slot>
    ac8d:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    ac92:	e9 f1 fa ff ff       	jmp    a788 <fwp_main_thread+0x15d8>
    ac97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ac9e:	00 00 
    aca0:	48 8d 58 ff          	lea    -0x1(%rax),%rbx
    aca4:	48 89 df             	mov    %rbx,%rdi
    aca7:	48 c1 ef 3c          	shr    $0x3c,%rdi
    acab:	0f 85 2f 07 00 00    	jne    b3e0 <fwp_main_thread+0x2230>
    acb1:	48 85 db             	test   %rbx,%rbx
    acb4:	0f 84 87 f3 ff ff    	je     a041 <fwp_main_thread+0xe91>
    acba:	48 c1 e0 04          	shl    $0x4,%rax
    acbe:	48 01 db             	add    %rbx,%rbx
    acc1:	4d 8d 7c 24 08       	lea    0x8(%r12),%r15
    acc6:	4d 8d 6c 04 f8       	lea    -0x8(%r12,%rax,1),%r13
    accb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    acd0:	f2 41 0f 10 07       	movsd  (%r15),%xmm0
    acd5:	49 8b 77 18          	mov    0x18(%r15),%rsi
    acd9:	49 83 c7 10          	add    $0x10,%r15
    acdd:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
    ace1:	f2 41 0f 10 0f       	movsd  (%r15),%xmm1
    ace6:	e8 75 b5 ff ff       	call   6260 <w120>
    aceb:	66 48 0f 6e e0       	movq   %rax,%xmm4
    acf0:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    acf4:	41 0f 11 47 f0       	movups %xmm0,-0x10(%r15)
    acf9:	4d 39 fd             	cmp    %r15,%r13
    acfc:	75 d2                	jne    acd0 <fwp_main_thread+0x1b20>
    acfe:	49 89 1c 24          	mov    %rbx,(%r12)
    ad02:	45 31 ed             	xor    %r13d,%r13d
    ad05:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    ad0c:	0f 1f 40 00          	nopl   0x0(%rax)
    ad10:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    ad17:	00 f0 3f 
    ad1a:	4b 8b 54 ec 10       	mov    0x10(%r12,%r13,8),%rdx
    ad1f:	49 83 c5 02          	add    $0x2,%r13
    ad23:	48 89 ce             	mov    %rcx,%rsi
    ad26:	e8 b5 b1 ff ff       	call   5ee0 <fwp_p_ad_push>
    ad2b:	48 89 c7             	mov    %rax,%rdi
    ad2e:	49 39 dd             	cmp    %rbx,%r13
    ad31:	72 dd                	jb     ad10 <fwp_main_thread+0x1b60>
    ad33:	49 89 c7             	mov    %rax,%r15
    ad36:	e9 15 f3 ff ff       	jmp    a050 <fwp_main_thread+0xea0>
    ad3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ad40:	49 39 d6             	cmp    %rdx,%r14
    ad43:	0f 84 f7 ef ff ff    	je     9d40 <fwp_main_thread+0xb90>
    ad49:	4c 8b 3d a0 53 01 00 	mov    0x153a0(%rip),%r15        # 200f0 <fwp_tapes>
    ad50:	49 89 d6             	mov    %rdx,%r14
    ad53:	4c 8d 62 01          	lea    0x1(%rdx),%r12
    ad57:	e9 77 f0 ff ff       	jmp    9dd3 <fwp_main_thread+0xc23>
    ad5c:	0f 1f 40 00          	nopl   0x0(%rax)
    ad60:	49 c1 e5 10          	shl    $0x10,%r13
    ad64:	be 02 00 00 00       	mov    $0x2,%esi
    ad69:	bf 08 00 00 00       	mov    $0x8,%edi
    ad6e:	4d 09 e5             	or     %r12,%r13
    ad71:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    ad76:	e8 15 af ff ff       	call   5c90 <fwp_heap_alloc>
    ad7b:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    ad82:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ad89:	49 89 c4             	mov    %rax,%r12
    ad8c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    ad93:	48 c1 e2 10          	shl    $0x10,%rdx
    ad97:	48 39 d0             	cmp    %rdx,%rax
    ad9a:	0f 83 a1 f2 ff ff    	jae    a041 <fwp_main_thread+0xe91>
    ada0:	48 89 c2             	mov    %rax,%rdx
    ada3:	48 c1 ea 10          	shr    $0x10,%rdx
    ada7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    adab:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    adb2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    adb6:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    adba:	4d 85 ed             	test   %r13,%r13
    adbd:	0f 84 71 f2 ff ff    	je     a034 <fwp_main_thread+0xe84>
    adc3:	0f b6 0a             	movzbl (%rdx),%ecx
    adc6:	31 db                	xor    %ebx,%ebx
    adc8:	80 f9 02             	cmp    $0x2,%cl
    adcb:	0f 85 ca f1 ff ff    	jne    9f9b <fwp_main_thread+0xdeb>
    add1:	66 85 c0             	test   %ax,%ax
    add4:	0f 85 ef f1 ff ff    	jne    9fc9 <fwp_main_thread+0xe19>
    adda:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    addf:	0f 85 df f1 ff ff    	jne    9fc4 <fwp_main_thread+0xe14>
    ade5:	4c 89 ef             	mov    %r13,%rdi
    ade8:	e8 63 a7 ff ff       	call   5550 <fwp_rc_forget_slot>
    aded:	e9 d2 f1 ff ff       	jmp    9fc4 <fwp_main_thread+0xe14>
    adf2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    adf8:	4d 8d 61 01          	lea    0x1(%r9),%r12
    adfc:	4c 39 e3             	cmp    %r12,%rbx
    adff:	7c 42                	jl     ae43 <fwp_main_thread+0x1c93>
    ae01:	48 85 c9             	test   %rcx,%rcx
    ae04:	0f 84 30 01 00 00    	je     af3a <fwp_main_thread+0x1d8a>
    ae0a:	48 89 cf             	mov    %rcx,%rdi
    ae0d:	4c 89 e3             	mov    %r12,%rbx
    ae10:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    ae17:	00 
    ae18:	31 f6                	xor    %esi,%esi
    ae1a:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    ae1f:	4c 29 c3             	sub    %r8,%rbx
    ae22:	4c 89 4c 24 50       	mov    %r9,0x50(%rsp)
    ae27:	e8 94 86 ff ff       	call   34c0 <memset@plt>
    ae2c:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    ae31:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
    ae36:	48 89 c1             	mov    %rax,%rcx
    ae39:	e9 a6 f3 ff ff       	jmp    a1e4 <fwp_main_thread+0x1034>
    ae3e:	66 90                	xchg   %ax,%ax
    ae40:	4d 89 c4             	mov    %r8,%r12
    ae43:	48 85 db             	test   %rbx,%rbx
    ae46:	49 0f 44 dc          	cmove  %r12,%rbx
    ae4a:	eb 29                	jmp    ae75 <fwp_main_thread+0x1cc5>
    ae4c:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ae53:	00 00 
    ae55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ae5c:	00 00 00 00 
    ae60:	48 8d 14 1b          	lea    (%rbx,%rbx,1),%rdx
    ae64:	48 81 fb 00 00 00 40 	cmp    $0x40000000,%rbx
    ae6b:	4c 89 e0             	mov    %r12,%rax
    ae6e:	48 0f 4c c2          	cmovl  %rdx,%rax
    ae72:	48 89 c3             	mov    %rax,%rbx
    ae75:	4c 39 e3             	cmp    %r12,%rbx
    ae78:	7c e6                	jl     ae60 <fwp_main_thread+0x1cb0>
    ae7a:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    ae7f:	48 85 c9             	test   %rcx,%rcx
    ae82:	0f 84 08 02 00 00    	je     b090 <fwp_main_thread+0x1ee0>
    ae88:	48 89 cf             	mov    %rcx,%rdi
    ae8b:	48 8d 34 dd 00 00 00 	lea    0x0(,%rbx,8),%rsi
    ae92:	00 
    ae93:	e8 38 87 ff ff       	call   35d0 <realloc@plt>
    ae98:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    ae9d:	48 89 c1             	mov    %rax,%rcx
    aea0:	48 85 c9             	test   %rcx,%rcx
    aea3:	0f 84 83 00 00 00    	je     af2c <fwp_main_thread+0x1d7c>
    aea9:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
    aeb0:	00 
    aeb1:	48 89 9c 24 00 01 00 	mov    %rbx,0x100(%rsp)
    aeb8:	00 
    aeb9:	4d 85 e4             	test   %r12,%r12
    aebc:	0f 85 70 03 00 00    	jne    b232 <fwp_main_thread+0x2082>
    aec2:	4c 89 c3             	mov    %r8,%rbx
    aec5:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    aecc:	48 f7 db             	neg    %rbx
    aecf:	4d 85 ff             	test   %r15,%r15
    aed2:	0f 88 20 f3 ff ff    	js     a1f8 <fwp_main_thread+0x1048>
    aed8:	45 89 f9             	mov    %r15d,%r9d
    aedb:	e9 04 f3 ff ff       	jmp    a1e4 <fwp_main_thread+0x1034>
    aee0:	48 8d 3d d9 ba ff ff 	lea    -0x4527(%rip),%rdi        # 69c0 <fwp_tape_finish>
    aee7:	e8 74 07 00 00       	call   b660 <atexit>
    aeec:	85 c0                	test   %eax,%eax
    aeee:	75 63                	jne    af53 <fwp_main_thread+0x1da3>
    aef0:	c7 05 66 51 00 00 01 	movl   $0x1,0x5166(%rip)        # 10060 <registered_finish.1>
    aef7:	00 00 00 
    aefa:	e9 f0 ed ff ff       	jmp    9cef <fwp_main_thread+0xb3f>
    aeff:	90                   	nop
    af00:	66 85 c0             	test   %ax,%ax
    af03:	0f 85 d7 f9 ff ff    	jne    a8e0 <fwp_main_thread+0x1730>
    af09:	e9 a5 f9 ff ff       	jmp    a8b3 <fwp_main_thread+0x1703>
    af0e:	66 90                	xchg   %ax,%ax
    af10:	66 85 c0             	test   %ax,%ax
    af13:	0f 85 91 ed ff ff    	jne    9caa <fwp_main_thread+0xafa>
    af19:	e9 78 ed ff ff       	jmp    9c96 <fwp_main_thread+0xae6>
    af1e:	66 90                	xchg   %ax,%ax
    af20:	4d 89 c4             	mov    %r8,%r12
    af23:	49 39 d8             	cmp    %rbx,%r8
    af26:	0f 8f 17 ff ff ff    	jg     ae43 <fwp_main_thread+0x1c93>
    af2c:	4d 85 e4             	test   %r12,%r12
    af2f:	74 91                	je     aec2 <fwp_main_thread+0x1d12>
    af31:	48 85 c9             	test   %rcx,%rcx
    af34:	0f 85 7f ff ff ff    	jne    aeb9 <fwp_main_thread+0x1d09>
    af3a:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    af41:	00 
    af42:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    af47:	48 89 05 0a 75 01 00 	mov    %rax,0x1750a(%rip)        # 22458 <fwp_cleanups>
    af4e:	e8 1d a1 ff ff       	call   5070 <fwp_tape_buffers_release>
    af53:	48 8b 0d e6 50 00 00 	mov    0x50e6(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    af5a:	ba 13 00 00 00       	mov    $0x13,%edx
    af5f:	be 01 00 00 00       	mov    $0x1,%esi
    af64:	48 8d 3d 9d 10 00 00 	lea    0x109d(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    af6b:	e8 10 87 ff ff       	call   3680 <fwrite@plt>
    af70:	31 ff                	xor    %edi,%edi
    af72:	e8 49 86 ff ff       	call   35c0 <fflush@plt>
    af77:	bf 66 00 00 00       	mov    $0x66,%edi
    af7c:	e8 1f 87 ff ff       	call   36a0 <_Exit@plt>
    af81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    af88:	66 85 c0             	test   %ax,%ax
    af8b:	0f 85 21 f4 ff ff    	jne    a3b2 <fwp_main_thread+0x1202>
    af91:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    af96:	0f 85 11 f4 ff ff    	jne    a3ad <fwp_main_thread+0x11fd>
    af9c:	4c 89 ef             	mov    %r13,%rdi
    af9f:	e8 ac a5 ff ff       	call   5550 <fwp_rc_forget_slot>
    afa4:	e9 04 f4 ff ff       	jmp    a3ad <fwp_main_thread+0x11fd>
    afa9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    afb0:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    afb7:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    afbe:	4c 89 f0             	mov    %r14,%rax
    afc1:	4d 8b 66 10          	mov    0x10(%r14),%r12
    afc5:	48 29 c8             	sub    %rcx,%rax
    afc8:	48 c1 e2 10          	shl    $0x10,%rdx
    afcc:	48 39 d0             	cmp    %rdx,%rax
    afcf:	73 65                	jae    b036 <fwp_main_thread+0x1e86>
    afd1:	48 89 c7             	mov    %rax,%rdi
    afd4:	48 c1 ef 10          	shr    $0x10,%rdi
    afd8:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    afdc:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    afe0:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    afe4:	48 85 ff             	test   %rdi,%rdi
    afe7:	74 4d                	je     b036 <fwp_main_thread+0x1e86>
    afe9:	44 0f b6 06          	movzbl (%rsi),%r8d
    afed:	41 80 f8 02          	cmp    $0x2,%r8b
    aff1:	0f 84 42 01 00 00    	je     b139 <fwp_main_thread+0x1f89>
    aff7:	41 80 f8 01          	cmp    $0x1,%r8b
    affb:	75 39                	jne    b036 <fwp_main_thread+0x1e86>
    affd:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    b001:	0f b7 c0             	movzwl %ax,%eax
    b004:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b007:	49 0f af c0          	imul   %r8,%rax
    b00b:	48 c1 e8 20          	shr    $0x20,%rax
    b00f:	48 39 f0             	cmp    %rsi,%rax
    b012:	73 22                	jae    b036 <fwp_main_thread+0x1e86>
    b014:	48 01 c7             	add    %rax,%rdi
    b017:	80 3f 01             	cmpb   $0x1,(%rdi)
    b01a:	75 1a                	jne    b036 <fwp_main_thread+0x1e86>
    b01c:	4c 89 f7             	mov    %r14,%rdi
    b01f:	e8 6c a7 ff ff       	call   5790 <fwp_mem_free>
    b024:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b02b:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b032:	48 c1 e2 10          	shl    $0x10,%rdx
    b036:	4c 89 e0             	mov    %r12,%rax
    b039:	48 29 c8             	sub    %rcx,%rax
    b03c:	48 39 d0             	cmp    %rdx,%rax
    b03f:	0f 83 9b f8 ff ff    	jae    a8e0 <fwp_main_thread+0x1730>
    b045:	4d 89 e6             	mov    %r12,%r14
    b048:	e9 1d f8 ff ff       	jmp    a86a <fwp_main_thread+0x16ba>
    b04d:	0f 1f 00             	nopl   (%rax)
    b050:	66 85 c0             	test   %ax,%ax
    b053:	0f 85 15 fc ff ff    	jne    ac6e <fwp_main_thread+0x1abe>
    b059:	41 80 3f ff          	cmpb   $0xff,(%r15)
    b05d:	0f 85 07 fc ff ff    	jne    ac6a <fwp_main_thread+0x1aba>
    b063:	4c 89 ff             	mov    %r15,%rdi
    b066:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    b06b:	e8 e0 a4 ff ff       	call   5550 <fwp_rc_forget_slot>
    b070:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    b075:	e9 f0 fb ff ff       	jmp    ac6a <fwp_main_thread+0x1aba>
    b07a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b080:	48 85 db             	test   %rbx,%rbx
    b083:	0f 85 45 ef ff ff    	jne    9fce <fwp_main_thread+0xe1e>
    b089:	e9 b3 ef ff ff       	jmp    a041 <fwp_main_thread+0xe91>
    b08e:	66 90                	xchg   %ax,%ax
    b090:	be 08 00 00 00       	mov    $0x8,%esi
    b095:	48 89 df             	mov    %rbx,%rdi
    b098:	e8 83 84 ff ff       	call   3520 <calloc@plt>
    b09d:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    b0a2:	48 89 c1             	mov    %rax,%rcx
    b0a5:	e9 f6 fd ff ff       	jmp    aea0 <fwp_main_thread+0x1cf0>
    b0aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b0b0:	66 85 c0             	test   %ax,%ax
    b0b3:	0f 85 4a eb ff ff    	jne    9c03 <fwp_main_thread+0xa53>
    b0b9:	e9 1f eb ff ff       	jmp    9bdd <fwp_main_thread+0xa2d>
    b0be:	66 90                	xchg   %ax,%ax
    b0c0:	66 85 c0             	test   %ax,%ax
    b0c3:	0f 85 d7 f9 ff ff    	jne    aaa0 <fwp_main_thread+0x18f0>
    b0c9:	0f b6 03             	movzbl (%rbx),%eax
    b0cc:	84 c0                	test   %al,%al
    b0ce:	0f 84 cc f9 ff ff    	je     aaa0 <fwp_main_thread+0x18f0>
    b0d4:	3c 01                	cmp    $0x1,%al
    b0d6:	0f 85 aa f9 ff ff    	jne    aa86 <fwp_main_thread+0x18d6>
    b0dc:	4c 89 e7             	mov    %r12,%rdi
    b0df:	e8 ac a6 ff ff       	call   5790 <fwp_mem_free>
    b0e4:	e9 b7 f9 ff ff       	jmp    aaa0 <fwp_main_thread+0x18f0>
    b0e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b0f0:	66 85 c0             	test   %ax,%ax
    b0f3:	0f 85 ea f8 ff ff    	jne    a9e3 <fwp_main_thread+0x1833>
    b0f9:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b0fd:	0f 85 dc f8 ff ff    	jne    a9df <fwp_main_thread+0x182f>
    b103:	4c 89 f7             	mov    %r14,%rdi
    b106:	e8 45 a4 ff ff       	call   5550 <fwp_rc_forget_slot>
    b10b:	e9 cf f8 ff ff       	jmp    a9df <fwp_main_thread+0x182f>
    b110:	be 68 00 00 00       	mov    $0x68,%esi
    b115:	41 bc 01 00 00 00    	mov    $0x1,%r12d
    b11b:	e9 5a ec ff ff       	jmp    9d7a <fwp_main_thread+0xbca>
    b120:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
    b125:	4c 8b 34 24          	mov    (%rsp),%r14
    b129:	31 db                	xor    %ebx,%ebx
    b12b:	e9 0e f7 ff ff       	jmp    a83e <fwp_main_thread+0x168e>
    b130:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b134:	e9 71 e2 ff ff       	jmp    93aa <fwp_main_thread+0x1fa>
    b139:	66 85 c0             	test   %ax,%ax
    b13c:	0f 85 f4 fe ff ff    	jne    b036 <fwp_main_thread+0x1e86>
    b142:	e9 d0 fe ff ff       	jmp    b017 <fwp_main_thread+0x1e67>
    b147:	31 db                	xor    %ebx,%ebx
    b149:	e9 1e e3 ff ff       	jmp    946c <fwp_main_thread+0x2bc>
    b14e:	4c 8b 74 24 78       	mov    0x78(%rsp),%r14
    b153:	48 8b 3c 24          	mov    (%rsp),%rdi
    b157:	e8 84 c4 ff ff       	call   75e0 <fwp_drop0>
    b15c:	4c 89 f7             	mov    %r14,%rdi
    b15f:	e8 7c c4 ff ff       	call   75e0 <fwp_drop0>
    b164:	48 c7 05 f9 4e 00 00 	movq   $0x0,0x4ef9(%rip)        # 10068 <v.2>
    b16b:	00 00 00 00 
    b16f:	c7 05 f7 4e 00 00 01 	movl   $0x1,0x4ef7(%rip)        # 10070 <st.3>
    b176:	00 00 00 
    b179:	e9 78 e1 ff ff       	jmp    92f6 <fwp_main_thread+0x146>
    b17e:	66 85 c0             	test   %ax,%ax
    b181:	0f 85 7a e8 ff ff    	jne    9a01 <fwp_main_thread+0x851>
    b187:	e9 65 e8 ff ff       	jmp    99f1 <fwp_main_thread+0x841>
    b18c:	66 85 c0             	test   %ax,%ax
    b18f:	0f 85 c1 e9 ff ff    	jne    9b56 <fwp_main_thread+0x9a6>
    b195:	e9 9e e9 ff ff       	jmp    9b38 <fwp_main_thread+0x988>
    b19a:	66 85 c0             	test   %ax,%ax
    b19d:	0f 85 fd e8 ff ff    	jne    9aa0 <fwp_main_thread+0x8f0>
    b1a3:	e9 e8 e8 ff ff       	jmp    9a90 <fwp_main_thread+0x8e0>
    b1a8:	4c 89 ef             	mov    %r13,%rdi
    b1ab:	e8 a0 a3 ff ff       	call   5550 <fwp_rc_forget_slot>
    b1b0:	e9 0c e7 ff ff       	jmp    98c1 <fwp_main_thread+0x711>
    b1b5:	4c 89 e2             	mov    %r12,%rdx
    b1b8:	48 c1 ea 11          	shr    $0x11,%rdx
    b1bc:	4c 31 e2             	xor    %r12,%rdx
    b1bf:	48 89 d0             	mov    %rdx,%rax
    b1c2:	48 c1 e8 09          	shr    $0x9,%rax
    b1c6:	48 31 c2             	xor    %rax,%rdx
    b1c9:	0f b6 d2             	movzbl %dl,%edx
    b1cc:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b1d3:	00 
    b1d4:	48 85 c0             	test   %rax,%rax
    b1d7:	75 10                	jne    b1e9 <fwp_main_thread+0x2039>
    b1d9:	eb 4b                	jmp    b226 <fwp_main_thread+0x2076>
    b1db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b1e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b1e4:	48 85 c0             	test   %rax,%rax
    b1e7:	74 3d                	je     b226 <fwp_main_thread+0x2076>
    b1e9:	48 89 c2             	mov    %rax,%rdx
    b1ec:	4c 39 20             	cmp    %r12,(%rax)
    b1ef:	75 ef                	jne    b1e0 <fwp_main_thread+0x2030>
    b1f1:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b1f5:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b1f9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b1fd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b204:	0f 85 d6 f6 ff ff    	jne    a8e0 <fwp_main_thread+0x1730>
    b20a:	4c 89 e7             	mov    %r12,%rdi
    b20d:	e8 3e a3 ff ff       	call   5550 <fwp_rc_forget_slot>
    b212:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b217:	e9 c4 f6 ff ff       	jmp    a8e0 <fwp_main_thread+0x1730>
    b21c:	e8 0f a2 ff ff       	call   5430 <fwp_rc_wide_dup>
    b221:	e9 84 ea ff ff       	jmp    9caa <fwp_main_thread+0xafa>
    b226:	48 8d 3d 63 16 00 00 	lea    0x1663(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    b22d:	e8 be 91 ff ff       	call   43f0 <fwp_trap>
    b232:	48 89 cf             	mov    %rcx,%rdi
    b235:	4c 89 e3             	mov    %r12,%rbx
    b238:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    b23f:	00 
    b240:	31 f6                	xor    %esi,%esi
    b242:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    b247:	4c 29 c3             	sub    %r8,%rbx
    b24a:	4d 8d 6c 24 ff       	lea    -0x1(%r12),%r13
    b24f:	e8 6c 82 ff ff       	call   34c0 <memset@plt>
    b254:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    b259:	48 89 c1             	mov    %rax,%rcx
    b25c:	e9 6e fc ff ff       	jmp    aecf <fwp_main_thread+0x1d1f>
    b261:	48 8b 3d d8 71 01 00 	mov    0x171d8(%rip),%rdi        # 22440 <fwp_state>
    b268:	e8 23 a5 ff ff       	call   5790 <fwp_mem_free>
    b26d:	48 c7 05 c8 71 01 00 	movq   $0x0,0x171c8(%rip)        # 22440 <fwp_state>
    b274:	00 00 00 00 
    b278:	48 c7 05 ad 71 01 00 	movq   $0x0,0x171ad(%rip)        # 22430 <fwp_state_cap>
    b27f:	00 00 00 00 
    b283:	48 85 db             	test   %rbx,%rbx
    b286:	0f 84 e6 00 00 00    	je     b372 <fwp_main_thread+0x21c2>
    b28c:	48 3b 1d 05 55 01 00 	cmp    0x15505(%rip),%rbx        # 20798 <fwp_root>
    b293:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    b29a:	00 00 00 00 
    b29e:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    b2a5:	00 00 00 00 
    b2a9:	c7 05 cd 4d 01 00 00 	movl   $0x0,0x14dcd(%rip)        # 20080 <fwp_exit_code>
    b2b0:	00 00 00 
    b2b3:	0f 84 dd e1 ff ff    	je     9496 <fwp_main_thread+0x2e6>
    b2b9:	e9 8d 84 ff ff       	jmp    374b <fwp_main_thread.cold>
    b2be:	66 90                	xchg   %ax,%ax
    b2c0:	48 89 d8             	mov    %rbx,%rax
    b2c3:	48 c1 e8 11          	shr    $0x11,%rax
    b2c7:	48 31 d8             	xor    %rbx,%rax
    b2ca:	48 89 c2             	mov    %rax,%rdx
    b2cd:	48 c1 ea 09          	shr    $0x9,%rdx
    b2d1:	48 31 d0             	xor    %rdx,%rax
    b2d4:	0f b6 d0             	movzbl %al,%edx
    b2d7:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b2de:	00 
    b2df:	48 85 c0             	test   %rax,%rax
    b2e2:	75 29                	jne    b30d <fwp_main_thread+0x215d>
    b2e4:	e9 3d ff ff ff       	jmp    b226 <fwp_main_thread+0x2076>
    b2e9:	90                   	nop
    b2ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b2f1:	00 00 00 00 
    b2f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b2fc:	00 00 00 00 
    b300:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b304:	48 85 c0             	test   %rax,%rax
    b307:	0f 84 19 ff ff ff    	je     b226 <fwp_main_thread+0x2076>
    b30d:	48 89 c2             	mov    %rax,%rdx
    b310:	48 3b 18             	cmp    (%rax),%rbx
    b313:	75 eb                	jne    b300 <fwp_main_thread+0x2150>
    b315:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b319:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b31d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b321:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b328:	0f 85 72 f7 ff ff    	jne    aaa0 <fwp_main_thread+0x18f0>
    b32e:	48 89 df             	mov    %rbx,%rdi
    b331:	e8 1a a2 ff ff       	call   5550 <fwp_rc_forget_slot>
    b336:	c6 03 fe             	movb   $0xfe,(%rbx)
    b339:	e9 62 f7 ff ff       	jmp    aaa0 <fwp_main_thread+0x18f0>
    b33e:	e8 ed a0 ff ff       	call   5430 <fwp_rc_wide_dup>
    b343:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b34a:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b351:	48 c1 e2 10          	shl    $0x10,%rdx
    b355:	e9 a9 e8 ff ff       	jmp    9c03 <fwp_main_thread+0xa53>
    b35a:	48 8d 3d 06 0e 00 00 	lea    0xe06(%rip),%rdi        # c167 <_IO_stdin_used+0x167>
    b361:	e8 8a 90 ff ff       	call   43f0 <fwp_trap>
    b366:	48 8d 3d 4b 15 00 00 	lea    0x154b(%rip),%rdi        # c8b8 <_IO_stdin_used+0x8b8>
    b36d:	e8 7e 90 ff ff       	call   43f0 <fwp_trap>
    b372:	48 83 3d 1e 54 01 00 	cmpq   $0x0,0x1541e(%rip)        # 20798 <fwp_root>
    b379:	00 
    b37a:	c7 05 fc 4c 01 00 00 	movl   $0x0,0x14cfc(%rip)        # 20080 <fwp_exit_code>
    b381:	00 00 00 
    b384:	0f 84 6b e1 ff ff    	je     94f5 <fwp_main_thread+0x345>
    b38a:	e9 bc 83 ff ff       	jmp    374b <fwp_main_thread.cold>
    b38f:	90                   	nop
    b390:	4c 89 e7             	mov    %r12,%rdi
    b393:	e8 b8 a1 ff ff       	call   5550 <fwp_rc_forget_slot>
    b398:	e9 5f e6 ff ff       	jmp    99fc <fwp_main_thread+0x84c>
    b39d:	4c 89 e7             	mov    %r12,%rdi
    b3a0:	e8 ab a1 ff ff       	call   5550 <fwp_rc_forget_slot>
    b3a5:	e9 f1 e6 ff ff       	jmp    9a9b <fwp_main_thread+0x8eb>
    b3aa:	4c 89 e7             	mov    %r12,%rdi
    b3ad:	e8 9e a1 ff ff       	call   5550 <fwp_rc_forget_slot>
    b3b2:	e9 8c e7 ff ff       	jmp    9b43 <fwp_main_thread+0x993>
    b3b7:	48 8d 3d fa 15 00 00 	lea    0x15fa(%rip),%rdi        # c9b8 <_IO_stdin_used+0x9b8>
    b3be:	e8 2d 90 ff ff       	call   43f0 <fwp_trap>
    b3c3:	e8 38 83 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    b3c8:	48 8d 3d 67 0e 00 00 	lea    0xe67(%rip),%rdi        # c236 <_IO_stdin_used+0x236>
    b3cf:	e8 1c 90 ff ff       	call   43f0 <fwp_trap>
    b3d4:	48 8d 3d 41 0e 00 00 	lea    0xe41(%rip),%rdi        # c21c <_IO_stdin_used+0x21c>
    b3db:	e8 10 90 ff ff       	call   43f0 <fwp_trap>
    b3e0:	48 8d 3d a9 0d 00 00 	lea    0xda9(%rip),%rdi        # c190 <_IO_stdin_used+0x190>
    b3e7:	e8 04 90 ff ff       	call   43f0 <fwp_trap>
    b3ec:	48 8d 3d 95 15 00 00 	lea    0x1595(%rip),%rdi        # c988 <_IO_stdin_used+0x988>
    b3f3:	e8 f8 8f ff ff       	call   43f0 <fwp_trap>
    b3f8:	48 8d 3d 61 15 00 00 	lea    0x1561(%rip),%rdi        # c960 <_IO_stdin_used+0x960>
    b3ff:	e8 ec 8f ff ff       	call   43f0 <fwp_trap>
    b404:	e8 57 80 ff ff       	call   3460 <__stack_chk_fail@plt>
    b409:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b410:	48 8d 3d c9 15 00 00 	lea    0x15c9(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    b417:	e8 d4 8f ff ff       	call   43f0 <fwp_trap>
    b41c:	48 8d 3d dd 14 00 00 	lea    0x14dd(%rip),%rdi        # c900 <_IO_stdin_used+0x900>
    b423:	e8 c8 8f ff ff       	call   43f0 <fwp_trap>
    b428:	e8 b3 89 ff ff       	call   3de0 <descent_phase_fail>
    b42d:	48 8d 3d 12 0e 00 00 	lea    0xe12(%rip),%rdi        # c246 <_IO_stdin_used+0x246>
    b434:	e8 b7 8f ff ff       	call   43f0 <fwp_trap>
    b439:	e9 0d 83 ff ff       	jmp    374b <fwp_main_thread.cold>
    b43e:	e9 08 83 ff ff       	jmp    374b <fwp_main_thread.cold>
    b443:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b44a:	00 00 00 
    b44d:	0f 1f 00             	nopl   (%rax)

000000000000b450 <__divmodti4>:
    b450:	f3 0f 1e fa          	endbr64
    b454:	55                   	push   %rbp
    b455:	49 89 f1             	mov    %rsi,%r9
    b458:	49 89 d2             	mov    %rdx,%r10
    b45b:	48 89 fe             	mov    %rdi,%rsi
    b45e:	49 89 cb             	mov    %rcx,%r11
    b461:	48 89 e5             	mov    %rsp,%rbp
    b464:	41 57                	push   %r15
    b466:	41 56                	push   %r14
    b468:	41 55                	push   %r13
    b46a:	41 54                	push   %r12
    b46c:	53                   	push   %rbx
    b46d:	4c 89 c3             	mov    %r8,%rbx
    b470:	45 31 c0             	xor    %r8d,%r8d
    b473:	4d 85 c9             	test   %r9,%r9
    b476:	79 12                	jns    b48a <__divmodti4+0x3a>
    b478:	31 ff                	xor    %edi,%edi
    b47a:	48 f7 de             	neg    %rsi
    b47d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    b484:	4c 19 cf             	sbb    %r9,%rdi
    b487:	49 89 f9             	mov    %rdi,%r9
    b48a:	4c 89 d8             	mov    %r11,%rax
    b48d:	4d 85 db             	test   %r11,%r11
    b490:	0f 88 1a 01 00 00    	js     b5b0 <__divmodti4+0x160>
    b496:	4c 89 d9             	mov    %r11,%rcx
    b499:	49 89 f3             	mov    %rsi,%r11
    b49c:	75 62                	jne    b500 <__divmodti4+0xb0>
    b49e:	4d 89 c4             	mov    %r8,%r12
    b4a1:	4d 39 d1             	cmp    %r10,%r9
    b4a4:	0f 83 46 01 00 00    	jae    b5f0 <__divmodti4+0x1a0>
    b4aa:	4c 89 d8             	mov    %r11,%rax
    b4ad:	4c 89 ca             	mov    %r9,%rdx
    b4b0:	49 f7 f2             	div    %r10
    b4b3:	49 89 c3             	mov    %rax,%r11
    b4b6:	31 c0                	xor    %eax,%eax
    b4b8:	48 89 d6             	mov    %rdx,%rsi
    b4bb:	31 ff                	xor    %edi,%edi
    b4bd:	4c 89 d9             	mov    %r11,%rcx
    b4c0:	48 89 c2             	mov    %rax,%rdx
    b4c3:	48 89 c8             	mov    %rcx,%rax
    b4c6:	4d 85 e4             	test   %r12,%r12
    b4c9:	74 0a                	je     b4d5 <__divmodti4+0x85>
    b4cb:	48 f7 d8             	neg    %rax
    b4ce:	48 83 d2 00          	adc    $0x0,%rdx
    b4d2:	48 f7 da             	neg    %rdx
    b4d5:	4d 85 c0             	test   %r8,%r8
    b4d8:	74 0a                	je     b4e4 <__divmodti4+0x94>
    b4da:	48 f7 de             	neg    %rsi
    b4dd:	48 83 d7 00          	adc    $0x0,%rdi
    b4e1:	48 f7 df             	neg    %rdi
    b4e4:	48 89 33             	mov    %rsi,(%rbx)
    b4e7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    b4eb:	5b                   	pop    %rbx
    b4ec:	41 5c                	pop    %r12
    b4ee:	41 5d                	pop    %r13
    b4f0:	41 5e                	pop    %r14
    b4f2:	41 5f                	pop    %r15
    b4f4:	5d                   	pop    %rbp
    b4f5:	c3                   	ret
    b4f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b4fd:	00 00 00 
    b500:	4d 89 c4             	mov    %r8,%r12
    b503:	49 39 c1             	cmp    %rax,%r9
    b506:	0f 82 ce 00 00 00    	jb     b5da <__divmodti4+0x18a>
    b50c:	31 ff                	xor    %edi,%edi
    b50e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    b513:	48 63 c7             	movslq %edi,%rax
    b516:	be 40 00 00 00       	mov    $0x40,%esi
    b51b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    b520:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    b525:	48 29 c6             	sub    %rax,%rsi
    b528:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    b52d:	48 09 c8             	or     %rcx,%rax
    b530:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    b535:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    b53a:	49 89 c6             	mov    %rax,%r14
    b53d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    b541:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    b546:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    b54b:	49 09 c1             	or     %rax,%r9
    b54e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    b552:	4c 89 c8             	mov    %r9,%rax
    b555:	49 f7 f6             	div    %r14
    b558:	48 89 d1             	mov    %rdx,%rcx
    b55b:	49 89 c3             	mov    %rax,%r11
    b55e:	49 89 c1             	mov    %rax,%r9
    b561:	49 f7 e2             	mul    %r10
    b564:	49 89 c6             	mov    %rax,%r14
    b567:	49 89 d2             	mov    %rdx,%r10
    b56a:	48 39 d1             	cmp    %rdx,%rcx
    b56d:	72 07                	jb     b576 <__divmodti4+0x126>
    b56f:	75 17                	jne    b588 <__divmodti4+0x138>
    b571:	49 39 c7             	cmp    %rax,%r15
    b574:	73 12                	jae    b588 <__divmodti4+0x138>
    b576:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    b57a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    b57e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    b582:	49 89 d2             	mov    %rdx,%r10
    b585:	49 89 c6             	mov    %rax,%r14
    b588:	4c 89 f8             	mov    %r15,%rax
    b58b:	4c 29 f0             	sub    %r14,%rax
    b58e:	4c 19 d1             	sbb    %r10,%rcx
    b591:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    b596:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    b59b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    b5a0:	48 09 c6             	or     %rax,%rsi
    b5a3:	48 89 cf             	mov    %rcx,%rdi
    b5a6:	31 c0                	xor    %eax,%eax
    b5a8:	4c 89 c9             	mov    %r9,%rcx
    b5ab:	e9 10 ff ff ff       	jmp    b4c0 <__divmodti4+0x70>
    b5b0:	4c 89 d0             	mov    %r10,%rax
    b5b3:	4c 89 da             	mov    %r11,%rdx
    b5b6:	4d 89 c4             	mov    %r8,%r12
    b5b9:	49 89 f3             	mov    %rsi,%r11
    b5bc:	48 f7 d8             	neg    %rax
    b5bf:	49 f7 d4             	not    %r12
    b5c2:	48 83 d2 00          	adc    $0x0,%rdx
    b5c6:	49 89 c2             	mov    %rax,%r10
    b5c9:	48 f7 da             	neg    %rdx
    b5cc:	48 89 d1             	mov    %rdx,%rcx
    b5cf:	0f 84 cc fe ff ff    	je     b4a1 <__divmodti4+0x51>
    b5d5:	49 39 d1             	cmp    %rdx,%r9
    b5d8:	73 46                	jae    b620 <__divmodti4+0x1d0>
    b5da:	4c 89 cf             	mov    %r9,%rdi
    b5dd:	31 c0                	xor    %eax,%eax
    b5df:	31 c9                	xor    %ecx,%ecx
    b5e1:	e9 da fe ff ff       	jmp    b4c0 <__divmodti4+0x70>
    b5e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b5ed:	00 00 00 
    b5f0:	4d 85 d2             	test   %r10,%r10
    b5f3:	75 0d                	jne    b602 <__divmodti4+0x1b2>
    b5f5:	b8 01 00 00 00       	mov    $0x1,%eax
    b5fa:	31 d2                	xor    %edx,%edx
    b5fc:	49 f7 f2             	div    %r10
    b5ff:	49 89 c2             	mov    %rax,%r10
    b602:	4c 89 c8             	mov    %r9,%rax
    b605:	31 d2                	xor    %edx,%edx
    b607:	49 f7 f2             	div    %r10
    b60a:	49 89 c1             	mov    %rax,%r9
    b60d:	4c 89 d8             	mov    %r11,%rax
    b610:	49 f7 f2             	div    %r10
    b613:	49 89 c3             	mov    %rax,%r11
    b616:	4c 89 c8             	mov    %r9,%rax
    b619:	e9 9a fe ff ff       	jmp    b4b8 <__divmodti4+0x68>
    b61e:	66 90                	xchg   %ax,%ax
    b620:	45 31 f6             	xor    %r14d,%r14d
    b623:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    b628:	44 89 f7             	mov    %r14d,%edi
    b62b:	45 85 f6             	test   %r14d,%r14d
    b62e:	0f 85 df fe ff ff    	jne    b513 <__divmodti4+0xc3>
    b634:	4c 39 ca             	cmp    %r9,%rdx
    b637:	72 17                	jb     b650 <__divmodti4+0x200>
    b639:	31 c9                	xor    %ecx,%ecx
    b63b:	48 39 c6             	cmp    %rax,%rsi
    b63e:	73 10                	jae    b650 <__divmodti4+0x200>
    b640:	4c 89 cf             	mov    %r9,%rdi
    b643:	31 c0                	xor    %eax,%eax
    b645:	e9 76 fe ff ff       	jmp    b4c0 <__divmodti4+0x70>
    b64a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b650:	4c 89 de             	mov    %r11,%rsi
    b653:	b9 01 00 00 00       	mov    $0x1,%ecx
    b658:	48 29 c6             	sub    %rax,%rsi
    b65b:	49 19 d1             	sbb    %rdx,%r9
    b65e:	eb e0                	jmp    b640 <__divmodti4+0x1f0>

000000000000b660 <atexit>:
    b660:	f3 0f 1e fa          	endbr64
    b664:	48 8b 15 9d 49 00 00 	mov    0x499d(%rip),%rdx        # 10008 <__dso_handle>
    b66b:	31 f6                	xor    %esi,%esi
    b66d:	e9 ee 7f ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b674 <_fini>:
    b674:	f3 0f 1e fa          	endbr64
    b678:	48 83 ec 08          	sub    $0x8,%rsp
    b67c:	48 83 c4 08          	add    $0x8,%rsp
    b680:	c3                   	ret
