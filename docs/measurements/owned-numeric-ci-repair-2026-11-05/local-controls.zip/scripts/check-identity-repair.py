import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

parser=argparse.ArgumentParser()
parser.add_argument('--opt',choices=('O1','O2'),required=True)
args=parser.parse_args()
root=Path('../gradient-work/owned-numeric-platforms-258/failure-mac-arm')
out=root/('repair-'+args.opt)
out.mkdir(exist_ok=True)
fixture=Path('tests/fixtures/scalar_array_identity.c').read_text()
old_fixture=subprocess.check_output(['git','show','f71b5308:tests/fixtures/scalar_array_identity.c'],text=True)
environment={k:v for k,v in os.environ.items() if not k.startswith('FWP_')}
environment['MallocDebugReport']='stderr'
records=[]

def check(label,source,expected):
 c=out/(label+'.c'); executable=out/(label+'.exe')
 c.write_text(source)
 command=['clang','-'+args.opt,'-std=gnu11','-ffp-contract=off','-w',str(c),'-o',str(executable),'-lm','-lpthread','-ldl']
 built=subprocess.run(command,capture_output=True,env=environment,timeout=60)
 (out/(label+'-compile.stderr')).write_bytes(built.stderr)
 (out/(label+'-compile.stdout')).write_bytes(built.stdout)
 assert built.returncode==0 and not built.stderr,(label,built.stderr.decode(errors='replace'))
 image=executable.read_bytes()
 assert image[:4]==b'\xcf\xfa\xed\xfe' and int.from_bytes(image[4:8],'little')==0x100000c
 runs=[]
 for control,status,diagnostic in expected:
  actual=subprocess.run([str(executable),control],capture_output=True,env=environment,timeout=20)
  (out/(label+'-'+control+'.stdout')).write_bytes(actual.stdout)
  (out/(label+'-'+control+'.stderr')).write_bytes(actual.stderr)
  runs.append(dict(control=control,status=actual.returncode,stdout=actual.stdout.decode(),stderr=actual.stderr.decode()))
  assert actual.returncode==status and actual.stderr==diagnostic,(label,control,actual)
  if status==0:
   assert actual.stdout.count(b'identity storage:')==4 and actual.stdout.endswith(b'identity arrays: moves, aliases, slices, updates and cleanup pass\n')
 records.append(dict(label=label,command=command,cSha256=hashlib.sha256(c.read_bytes()).hexdigest(),imageSha256=hashlib.sha256(image).hexdigest(),runs=runs))
 print(label,'all expected statuses',flush=True)

original=root/'array-identity-false-packed-false-reuse-true-O1-complete.c'
check('original-failing-expectation',original.read_text(),[('complete',82,b'')])
for path in sorted(root.glob('array-identity-*-O1-complete.c')):
 selected,packed,reuse=re.fullmatch(r'array-identity-(true|false)-packed-(true|false)-reuse-(true|false)-O1-complete.c',path.name).groups()
 raw=path.read_text()
 assert raw.endswith(old_fixture)
 assert ('/* consumed-scalar-array-map :' in raw)==(selected=='false')
 prefix=raw[:-len(old_fixture)]
 source=prefix+'#define IDENTITY_REUSE '+str(int(reuse=='true'))+'\n'+fixture
 label=f'selected-{selected}-packed-{packed}-reuse-{reuse}'
 check(label,source,[('complete',0,b''),('missing-release',90,b''),('allocation-failure',102,b'fwp: out of memory\n')])
report=dict(source='f71b53080008923ea40af8deb6c5cd6b60ca041c',fixtureSha256=hashlib.sha256(fixture.encode()).hexdigest(),compiler=subprocess.check_output(['clang','--version'],text=True),optimization=args.opt,records=records,scope='Saved emitted C and repaired probe only; current Rust harness and GCC require runner checks.')
(out/'verified.json').write_text(json.dumps(report,indent=2)+'\n')
print('Verified original failure, eight configurations, healthy cleanup, missing-release and allocation-failure controls.')
