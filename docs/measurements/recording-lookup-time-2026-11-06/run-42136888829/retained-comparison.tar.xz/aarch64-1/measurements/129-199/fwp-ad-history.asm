
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002608 <_init>:
    2608:	d503201f 	nop
    260c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2610:	910003fd 	mov	x29, sp
    2614:	940001a8 	bl	2cb4 <call_weak_fn>
    2618:	a8c17bfd 	ldp	x29, x30, [sp], #16
    261c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002620 <.plt>:
    2620:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2624:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2628:	f946f611 	ldr	x17, [x16, #3560]
    262c:	9137a210 	add	x16, x16, #0xde8
    2630:	d61f0220 	br	x17
    2634:	d503201f 	nop
    2638:	d503201f 	nop
    263c:	d503201f 	nop

0000000000002640 <memcpy@plt>:
    2640:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2644:	f946fa11 	ldr	x17, [x16, #3568]
    2648:	9137c210 	add	x16, x16, #0xdf0
    264c:	d61f0220 	br	x17

0000000000002650 <sigaltstack@plt>:
    2650:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2654:	f946fe11 	ldr	x17, [x16, #3576]
    2658:	9137e210 	add	x16, x16, #0xdf8
    265c:	d61f0220 	br	x17

0000000000002660 <memmove@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2664:	f9470211 	ldr	x17, [x16, #3584]
    2668:	91380210 	add	x16, x16, #0xe00
    266c:	d61f0220 	br	x17

0000000000002670 <_exit@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2674:	f9470611 	ldr	x17, [x16, #3592]
    2678:	91382210 	add	x16, x16, #0xe08
    267c:	d61f0220 	br	x17

0000000000002680 <strlen@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2684:	f9470a11 	ldr	x17, [x16, #3600]
    2688:	91384210 	add	x16, x16, #0xe10
    268c:	d61f0220 	br	x17

0000000000002690 <__sprintf_chk@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2694:	f9470e11 	ldr	x17, [x16, #3608]
    2698:	91386210 	add	x16, x16, #0xe18
    269c:	d61f0220 	br	x17

00000000000026a0 <exit@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26a4:	f9471211 	ldr	x17, [x16, #3616]
    26a8:	91388210 	add	x16, x16, #0xe20
    26ac:	d61f0220 	br	x17

00000000000026b0 <__libc_start_main@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b4:	f9471611 	ldr	x17, [x16, #3624]
    26b8:	9138a210 	add	x16, x16, #0xe28
    26bc:	d61f0220 	br	x17

00000000000026c0 <strtoll@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26c4:	f9471a11 	ldr	x17, [x16, #3632]
    26c8:	9138c210 	add	x16, x16, #0xe30
    26cc:	d61f0220 	br	x17

00000000000026d0 <strtod@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f9471e11 	ldr	x17, [x16, #3640]
    26d8:	9138e210 	add	x16, x16, #0xe38
    26dc:	d61f0220 	br	x17

00000000000026e0 <__cxa_finalize@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f9472211 	ldr	x17, [x16, #3648]
    26e8:	91390210 	add	x16, x16, #0xe40
    26ec:	d61f0220 	br	x17

00000000000026f0 <__cxa_atexit@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9472611 	ldr	x17, [x16, #3656]
    26f8:	91392210 	add	x16, x16, #0xe48
    26fc:	d61f0220 	br	x17

0000000000002700 <pthread_attr_init@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9472a11 	ldr	x17, [x16, #3664]
    2708:	91394210 	add	x16, x16, #0xe50
    270c:	d61f0220 	br	x17

0000000000002710 <fputc@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9472e11 	ldr	x17, [x16, #3672]
    2718:	91396210 	add	x16, x16, #0xe58
    271c:	d61f0220 	br	x17

0000000000002720 <clock_gettime@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9473211 	ldr	x17, [x16, #3680]
    2728:	91398210 	add	x16, x16, #0xe60
    272c:	d61f0220 	br	x17

0000000000002730 <setvbuf@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9473611 	ldr	x17, [x16, #3688]
    2738:	9139a210 	add	x16, x16, #0xe68
    273c:	d61f0220 	br	x17

0000000000002740 <__memcpy_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9473a11 	ldr	x17, [x16, #3696]
    2748:	9139c210 	add	x16, x16, #0xe70
    274c:	d61f0220 	br	x17

0000000000002750 <signal@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9473e11 	ldr	x17, [x16, #3704]
    2758:	9139e210 	add	x16, x16, #0xe78
    275c:	d61f0220 	br	x17

0000000000002760 <__snprintf_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9474211 	ldr	x17, [x16, #3712]
    2768:	913a0210 	add	x16, x16, #0xe80
    276c:	d61f0220 	br	x17

0000000000002770 <fclose@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9474611 	ldr	x17, [x16, #3720]
    2778:	913a2210 	add	x16, x16, #0xe88
    277c:	d61f0220 	br	x17

0000000000002780 <fopen@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9474a11 	ldr	x17, [x16, #3728]
    2788:	913a4210 	add	x16, x16, #0xe90
    278c:	d61f0220 	br	x17

0000000000002790 <malloc@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9474e11 	ldr	x17, [x16, #3736]
    2798:	913a6210 	add	x16, x16, #0xe98
    279c:	d61f0220 	br	x17

00000000000027a0 <pthread_attr_destroy@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9475211 	ldr	x17, [x16, #3744]
    27a8:	913a8210 	add	x16, x16, #0xea0
    27ac:	d61f0220 	br	x17

00000000000027b0 <sigemptyset@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9475611 	ldr	x17, [x16, #3752]
    27b8:	913aa210 	add	x16, x16, #0xea8
    27bc:	d61f0220 	br	x17

00000000000027c0 <memset@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9475a11 	ldr	x17, [x16, #3760]
    27c8:	913ac210 	add	x16, x16, #0xeb0
    27cc:	d61f0220 	br	x17

00000000000027d0 <calloc@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9475e11 	ldr	x17, [x16, #3768]
    27d8:	913ae210 	add	x16, x16, #0xeb8
    27dc:	d61f0220 	br	x17

00000000000027e0 <realloc@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9476211 	ldr	x17, [x16, #3776]
    27e8:	913b0210 	add	x16, x16, #0xec0
    27ec:	d61f0220 	br	x17

00000000000027f0 <__stack_chk_fail@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9476611 	ldr	x17, [x16, #3784]
    27f8:	913b2210 	add	x16, x16, #0xec8
    27fc:	d61f0220 	br	x17

0000000000002800 <close@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9476a11 	ldr	x17, [x16, #3792]
    2808:	913b4210 	add	x16, x16, #0xed0
    280c:	d61f0220 	br	x17

0000000000002810 <sigaction@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9476e11 	ldr	x17, [x16, #3800]
    2818:	913b6210 	add	x16, x16, #0xed8
    281c:	d61f0220 	br	x17

0000000000002820 <__gmon_start__@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9477211 	ldr	x17, [x16, #3808]
    2828:	913b8210 	add	x16, x16, #0xee0
    282c:	d61f0220 	br	x17

0000000000002830 <write@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9477611 	ldr	x17, [x16, #3816]
    2838:	913ba210 	add	x16, x16, #0xee8
    283c:	d61f0220 	br	x17

0000000000002840 <abort@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9477a11 	ldr	x17, [x16, #3824]
    2848:	913bc210 	add	x16, x16, #0xef0
    284c:	d61f0220 	br	x17

0000000000002850 <swapcontext@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9477e11 	ldr	x17, [x16, #3832]
    2858:	913be210 	add	x16, x16, #0xef8
    285c:	d61f0220 	br	x17

0000000000002860 <__fprintf_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9478211 	ldr	x17, [x16, #3840]
    2868:	913c0210 	add	x16, x16, #0xf00
    286c:	d61f0220 	br	x17

0000000000002870 <strcmp@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9478611 	ldr	x17, [x16, #3848]
    2878:	913c2210 	add	x16, x16, #0xf08
    287c:	d61f0220 	br	x17

0000000000002880 <mmap@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9478a11 	ldr	x17, [x16, #3856]
    2888:	913c4210 	add	x16, x16, #0xf10
    288c:	d61f0220 	br	x17

0000000000002890 <strtol@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9478e11 	ldr	x17, [x16, #3864]
    2898:	913c6210 	add	x16, x16, #0xf18
    289c:	d61f0220 	br	x17

00000000000028a0 <strtof@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9479211 	ldr	x17, [x16, #3872]
    28a8:	913c8210 	add	x16, x16, #0xf20
    28ac:	d61f0220 	br	x17

00000000000028b0 <free@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9479611 	ldr	x17, [x16, #3880]
    28b8:	913ca210 	add	x16, x16, #0xf28
    28bc:	d61f0220 	br	x17

00000000000028c0 <nanosleep@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9479a11 	ldr	x17, [x16, #3888]
    28c8:	913cc210 	add	x16, x16, #0xf30
    28cc:	d61f0220 	br	x17

00000000000028d0 <strchr@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9479e11 	ldr	x17, [x16, #3896]
    28d8:	913ce210 	add	x16, x16, #0xf38
    28dc:	d61f0220 	br	x17

00000000000028e0 <strtoull@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f947a211 	ldr	x17, [x16, #3904]
    28e8:	913d0210 	add	x16, x16, #0xf40
    28ec:	d61f0220 	br	x17

00000000000028f0 <fwrite@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f947a611 	ldr	x17, [x16, #3912]
    28f8:	913d2210 	add	x16, x16, #0xf48
    28fc:	d61f0220 	br	x17

0000000000002900 <pthread_create@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f947aa11 	ldr	x17, [x16, #3920]
    2908:	913d4210 	add	x16, x16, #0xf50
    290c:	d61f0220 	br	x17

0000000000002910 <munmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f947ae11 	ldr	x17, [x16, #3928]
    2918:	913d6210 	add	x16, x16, #0xf58
    291c:	d61f0220 	br	x17

0000000000002920 <fflush@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f947b211 	ldr	x17, [x16, #3936]
    2928:	913d8210 	add	x16, x16, #0xf60
    292c:	d61f0220 	br	x17

0000000000002930 <strcpy@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f947b611 	ldr	x17, [x16, #3944]
    2938:	913da210 	add	x16, x16, #0xf68
    293c:	d61f0220 	br	x17

0000000000002940 <sysconf@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f947ba11 	ldr	x17, [x16, #3952]
    2948:	913dc210 	add	x16, x16, #0xf70
    294c:	d61f0220 	br	x17

0000000000002950 <strstr@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f947be11 	ldr	x17, [x16, #3960]
    2958:	913de210 	add	x16, x16, #0xf78
    295c:	d61f0220 	br	x17

0000000000002960 <_Exit@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f947c211 	ldr	x17, [x16, #3968]
    2968:	913e0210 	add	x16, x16, #0xf80
    296c:	d61f0220 	br	x17

0000000000002970 <pthread_join@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947c611 	ldr	x17, [x16, #3976]
    2978:	913e2210 	add	x16, x16, #0xf88
    297c:	d61f0220 	br	x17

0000000000002980 <getenv@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947ca11 	ldr	x17, [x16, #3984]
    2988:	913e4210 	add	x16, x16, #0xf90
    298c:	d61f0220 	br	x17

0000000000002990 <__memmove_chk@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947ce11 	ldr	x17, [x16, #3992]
    2998:	913e6210 	add	x16, x16, #0xf98
    299c:	d61f0220 	br	x17

00000000000029a0 <mprotect@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947d211 	ldr	x17, [x16, #4000]
    29a8:	913e8210 	add	x16, x16, #0xfa0
    29ac:	d61f0220 	br	x17

00000000000029b0 <fgets@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947d611 	ldr	x17, [x16, #4008]
    29b8:	913ea210 	add	x16, x16, #0xfa8
    29bc:	d61f0220 	br	x17

00000000000029c0 <pthread_attr_setstacksize@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947da11 	ldr	x17, [x16, #4016]
    29c8:	913ec210 	add	x16, x16, #0xfb0
    29cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	f0000045 	adrp	x5, d000 <__modti3+0x1f0>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	910ec0a5 	add	x5, x5, #0x3b0
    2a20:	f0000044 	adrp	x4, d000 <__modti3+0x1f0>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	910ee084 	add	x4, x4, #0x3b8
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff46 	bl	2760 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	940002ac 	bl	3500 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2a7c:	91010261 	add	x1, x19, #0x40
    2a80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2a84:	f947ee94 	ldr	x20, [x20, #4056]
    2a88:	f9400282 	ldr	x2, [x20]
    2a8c:	f90043f5 	str	x21, [sp, #128]
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xed08>
    2aa0:	91132000 	add	x0, x0, #0x4c8
    2aa4:	f9000422 	str	x2, [x1, #8]
    2aa8:	f9001c20 	str	x0, [x1, #56]
    2aac:	940002f5 	bl	3680 <fwp_now_ns>
    2ab0:	f0000040 	adrp	x0, d000 <__modti3+0x1f0>
    2ab4:	911e4000 	add	x0, x0, #0x790
    2ab8:	97ffffb2 	bl	2980 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f5 	mov	x21, x0
    2ac8:	35000801 	cbnz	w1, 2bc8 <main+0x168>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff13 	bl	2720 <clock_gettime@plt>
    2ad8:	35000900 	cbnz	w0, 2bf8 <main+0x198>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b50009a0 	cbnz	x0, 2c38 <main+0x1d8>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f5 	add	x21, sp, #0x18
    2b1c:	97ffff05 	bl	2730 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff0a 	bl	2750 <signal@plt>
    2b2c:	aa1503e0 	mov	x0, x21
    2b30:	97fffef4 	bl	2700 <pthread_attr_init@plt>
    2b34:	350007c0 	cbnz	w0, 2c2c <main+0x1cc>
    2b38:	aa1503e0 	mov	x0, x21
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa0 	bl	29c0 <pthread_attr_setstacksize@plt>
    2b44:	35000680 	cbnz	w0, 2c14 <main+0x1b4>
    2b48:	aa1503e1 	mov	x1, x21
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	d0000042 	adrp	x2, c000 <f0+0x20f0>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	91154042 	add	x2, x2, #0x550
    2b5c:	97ffff69 	bl	2900 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1503e0 	mov	x0, x21
    2b68:	2a0103f5 	mov	w21, w1
    2b6c:	97ffff0d 	bl	27a0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	350004b5 	cbnz	w21, 2c08 <main+0x1a8>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff7c 	bl	2970 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	91010273 	add	x19, x19, #0x40
    2b90:	97ffff64 	bl	2920 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b9430a60 	ldr	w0, [x19, #776]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	540002a1 	b.ne	2c04 <main+0x1a4>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	910003e1 	mov	x1, sp
    2bcc:	52800142 	mov	w2, #0xa                   	// #10
    2bd0:	97ffff44 	bl	28e0 <strtoull@plt>
    2bd4:	f94003e0 	ldr	x0, [sp]
    2bd8:	39400000 	ldrb	w0, [x0]
    2bdc:	35fff780 	cbnz	w0, 2acc <main+0x6c>
    2be0:	394002a0 	ldrb	w0, [x21]
    2be4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2be8:	5100ac00 	sub	w0, w0, #0x2b
    2bec:	6a01001f 	tst	w0, w1
    2bf0:	54fff6e0 	b.eq	2acc <main+0x6c>  // b.none
    2bf4:	17ffffc5 	b	2b08 <main+0xa8>
    2bf8:	f0000040 	adrp	x0, d000 <__modti3+0x1f0>
    2bfc:	911e8000 	add	x0, x0, #0x7a0
    2c00:	94000240 	bl	3500 <fwp_trap>
    2c04:	97fffefb 	bl	27f0 <__stack_chk_fail@plt>
    2c08:	f0000040 	adrp	x0, d000 <__modti3+0x1f0>
    2c0c:	91210000 	add	x0, x0, #0x840
    2c10:	9400023c 	bl	3500 <fwp_trap>
    2c14:	aa1503e0 	mov	x0, x21
    2c18:	97fffee2 	bl	27a0 <pthread_attr_destroy@plt>
    2c1c:	35000140 	cbnz	w0, 2c44 <main+0x1e4>
    2c20:	f0000040 	adrp	x0, d000 <__modti3+0x1f0>
    2c24:	91206000 	add	x0, x0, #0x818
    2c28:	94000236 	bl	3500 <fwp_trap>
    2c2c:	f0000040 	adrp	x0, d000 <__modti3+0x1f0>
    2c30:	911fa000 	add	x0, x0, #0x7e8
    2c34:	94000233 	bl	3500 <fwp_trap>
    2c38:	f0000040 	adrp	x0, d000 <__modti3+0x1f0>
    2c3c:	911f0000 	add	x0, x0, #0x7c0
    2c40:	94000230 	bl	3500 <fwp_trap>
    2c44:	97fffeff 	bl	2840 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe81 	bl	26b0 <__libc_start_main@plt>
    2cb0:	97fffee4 	bl	2840 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffed8 	b	2820 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	9100a000 	add	x0, x0, #0x28
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	9100a021 	add	x1, x1, #0x28
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	9100a000 	add	x0, x0, #0x28
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	9100a021 	add	x1, x1, #0x28
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	3940c260 	ldrb	w0, [x19, #48]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe5c 	bl	26e0 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	3900c260 	strb	w0, [x19, #48]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	f0000041 	adrp	x1, d000 <__modti3+0x1f0>
    2e34:	91390021 	add	x1, x1, #0xe40
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe49 	bl	27f0 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <fwp_tape_unlink_scope>:
    2f10:	f9402803 	ldr	x3, [x0, #80]
    2f14:	b4000223 	cbz	x3, 2f58 <fwp_tape_unlink_scope+0x48>
    2f18:	294b0402 	ldp	w2, w1, [x0, #88]
    2f1c:	37f80202 	tbnz	w2, #31, 2f5c <fwp_tape_unlink_scope+0x4c>
    2f20:	d00000e4 	adrp	x4, 20000 <__data_start>
    2f24:	52800d03 	mov	w3, #0x68                  	// #104
    2f28:	f9402084 	ldr	x4, [x4, #64]
    2f2c:	9b231043 	smaddl	x3, w2, w3, x4
    2f30:	b9005c61 	str	w1, [x3, #92]
    2f34:	37f800c1 	tbnz	w1, #31, 2f4c <fwp_tape_unlink_scope+0x3c>
    2f38:	d00000e3 	adrp	x3, 20000 <__data_start>
    2f3c:	52800d04 	mov	w4, #0x68                  	// #104
    2f40:	f9402063 	ldr	x3, [x3, #64]
    2f44:	9b240c21 	smaddl	x1, w1, w4, x3
    2f48:	b9005822 	str	w2, [x1, #88]
    2f4c:	2f000400 	mvni	v0.2s, #0x0
    2f50:	f900281f 	str	xzr, [x0, #80]
    2f54:	fd002c00 	str	d0, [x0, #88]
    2f58:	d65f03c0 	ret
    2f5c:	b9000061 	str	w1, [x3]
    2f60:	17fffff5 	b	2f34 <fwp_tape_unlink_scope+0x24>

0000000000002f64 <fwp_args161>:
    2f64:	d65f03c0 	ret
    2f68:	d503201f 	nop
    2f6c:	d503201f 	nop

0000000000002f70 <fwp_flush>:
    2f70:	d00000e0 	adrp	x0, 20000 <__data_start>
    2f74:	f9402400 	ldr	x0, [x0, #72]
    2f78:	b4000120 	cbz	x0, 2f9c <fwp_flush+0x2c>
    2f7c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2f80:	910003fd 	mov	x29, sp
    2f84:	97fffe67 	bl	2920 <fflush@plt>
    2f88:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2f8c:	f947ec00 	ldr	x0, [x0, #4056]
    2f90:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2f94:	f9400000 	ldr	x0, [x0]
    2f98:	17fffe62 	b	2920 <fflush@plt>
    2f9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2fa0:	f947ec00 	ldr	x0, [x0, #4056]
    2fa4:	f9400000 	ldr	x0, [x0]
    2fa8:	17fffe5e 	b	2920 <fflush@plt>
    2fac:	d503201f 	nop

0000000000002fb0 <fwp_heap_oom>:
    2fb0:	b00000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    2fb4:	f947e863 	ldr	x3, [x3, #4048]
    2fb8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2fbc:	d2800262 	mov	x2, #0x13                  	// #19
    2fc0:	910003fd 	mov	x29, sp
    2fc4:	f9400063 	ldr	x3, [x3]
    2fc8:	d2800021 	mov	x1, #0x1                   	// #1
    2fcc:	f0000040 	adrp	x0, d000 <__modti3+0x1f0>
    2fd0:	9106e000 	add	x0, x0, #0x1b8
    2fd4:	97fffe47 	bl	28f0 <fwrite@plt>
    2fd8:	d2800000 	mov	x0, #0x0                   	// #0
    2fdc:	97fffe51 	bl	2920 <fflush@plt>
    2fe0:	52800cc0 	mov	w0, #0x66                  	// #102
    2fe4:	97fffe5f 	bl	2960 <_Exit@plt>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_segv>:
    2ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2ff4:	d00000e2 	adrp	x2, 20000 <__data_start>
    2ff8:	91010043 	add	x3, x2, #0x40
    2ffc:	910003fd 	mov	x29, sp
    3000:	a90153f3 	stp	x19, x20, [sp, #16]
    3004:	2a0003f3 	mov	w19, w0
    3008:	f9400860 	ldr	x0, [x3, #16]
    300c:	f90013f5 	str	x21, [sp, #32]
    3010:	f9400835 	ldr	x21, [x1, #16]
    3014:	b4000280 	cbz	x0, 3064 <fwp_segv+0x74>
    3018:	f9400814 	ldr	x20, [x0, #16]
    301c:	b4000254 	cbz	x20, 3064 <fwp_segv+0x74>
    3020:	528003c0 	mov	w0, #0x1e                  	// #30
    3024:	97fffe47 	bl	2940 <sysconf@plt>
    3028:	f144029f 	cmp	x20, #0x100, lsl #12
    302c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3030:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3034:	8b000294 	add	x20, x20, x0
    3038:	d1440021 	sub	x1, x1, #0x100, lsl #12
    303c:	eb0102bf 	cmp	x21, x1
    3040:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3044:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3048:	35000240 	cbnz	w0, 3090 <fwp_segv+0xa0>
    304c:	f94013f5 	ldr	x21, [sp, #32]
    3050:	2a1303e0 	mov	w0, w19
    3054:	a94153f3 	ldp	x19, x20, [sp, #16]
    3058:	d2800001 	mov	x1, #0x0                   	// #0
    305c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3060:	17fffdbc 	b	2750 <signal@plt>
    3064:	91010042 	add	x2, x2, #0x40
    3068:	f9400c40 	ldr	x0, [x2, #24]
    306c:	b4ffff00 	cbz	x0, 304c <fwp_segv+0x5c>
    3070:	f9401041 	ldr	x1, [x2, #32]
    3074:	cb010000 	sub	x0, x0, x1
    3078:	d1440001 	sub	x1, x0, #0x100, lsl #12
    307c:	91440000 	add	x0, x0, #0x100, lsl #12
    3080:	eb15003f 	cmp	x1, x21
    3084:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3088:	1a9f97e0 	cset	w0, hi	// hi = pmore
    308c:	34fffe00 	cbz	w0, 304c <fwp_segv+0x5c>
    3090:	97ffffb8 	bl	2f70 <fwp_flush>
    3094:	d0000041 	adrp	x1, d000 <__modti3+0x1f0>
    3098:	91388021 	add	x1, x1, #0xe20
    309c:	d2800342 	mov	x2, #0x1a                  	// #26
    30a0:	52800040 	mov	w0, #0x2                   	// #2
    30a4:	97fffde3 	bl	2830 <write@plt>
    30a8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ac:	97fffd71 	bl	2670 <_exit@plt>

00000000000030b0 <fwp_heap_chunks>:
    30b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    30b4:	910003fd 	mov	x29, sp
    30b8:	a90153f3 	stp	x19, x20, [sp, #16]
    30bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    30c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    30c4:	911542a1 	add	x1, x21, #0x550
    30c8:	f100041f 	cmp	x0, #0x1
    30cc:	54000ca0 	b.eq	3260 <fwp_heap_chunks+0x1b0>  // b.none
    30d0:	f949f822 	ldr	x2, [x1, #5104]
    30d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xab0>
    30d8:	912500a5 	add	x5, x5, #0x940
    30dc:	911542a1 	add	x1, x21, #0x550
    30e0:	f949ec34 	ldr	x20, [x1, #5080]
    30e4:	eb14005f 	cmp	x2, x20
    30e8:	54000c42 	b.cs	3270 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    30ec:	f949fc23 	ldr	x3, [x1, #5112]
    30f0:	8b020841 	add	x1, x2, x2, lsl #2
    30f4:	d2800004 	mov	x4, #0x0                   	// #0
    30f8:	8b010c61 	add	x1, x3, x1, lsl #3
    30fc:	14000009 	b	3120 <fwp_heap_chunks+0x70>
    3100:	91000483 	add	x3, x4, #0x1
    3104:	eb03001f 	cmp	x0, x3
    3108:	54000940 	b.eq	3230 <fwp_heap_chunks+0x180>  // b.none
    310c:	91000442 	add	x2, x2, #0x1
    3110:	aa0303e4 	mov	x4, x3
    3114:	9100a021 	add	x1, x1, #0x28
    3118:	eb02029f 	cmp	x20, x2
    311c:	54000100 	b.eq	313c <fwp_heap_chunks+0x8c>  // b.none
    3120:	39400023 	ldrb	w3, [x1]
    3124:	34fffee3 	cbz	w3, 3100 <fwp_heap_chunks+0x50>
    3128:	91000442 	add	x2, x2, #0x1
    312c:	9100a021 	add	x1, x1, #0x28
    3130:	d2800004 	mov	x4, #0x0                   	// #0
    3134:	eb02029f 	cmp	x20, x2
    3138:	54ffff41 	b.ne	3120 <fwp_heap_chunks+0x70>  // b.any
    313c:	cb040294 	sub	x20, x20, x4
    3140:	f9001bf7 	str	x23, [sp, #48]
    3144:	911542b7 	add	x23, x21, #0x550
    3148:	8b140013 	add	x19, x0, x20
    314c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3150:	f949f2e0 	ldr	x0, [x23, #5088]
    3154:	cb040021 	sub	x1, x1, x4
    3158:	f90a1ae1 	str	x1, [x23, #5168]
    315c:	eb00027f 	cmp	x19, x0
    3160:	54000429 	b.ls	31e4 <fwp_heap_chunks+0x134>  // b.plast
    3164:	f949eae1 	ldr	x1, [x23, #5072]
    3168:	eb01027f 	cmp	x19, x1
    316c:	54000888 	b.hi	327c <fwp_heap_chunks+0x1cc>  // b.pmore
    3170:	91010276 	add	x22, x19, #0x40
    3174:	52800062 	mov	w2, #0x3                   	// #3
    3178:	f949dae3 	ldr	x3, [x23, #5040]
    317c:	eb0102df 	cmp	x22, x1
    3180:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3184:	cb0002c1 	sub	x1, x22, x0
    3188:	8b004060 	add	x0, x3, x0, lsl #16
    318c:	d370bc21 	lsl	x1, x1, #16
    3190:	97fffe04 	bl	29a0 <mprotect@plt>
    3194:	35000740 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    3198:	528003c0 	mov	w0, #0x1e                  	// #30
    319c:	97fffde9 	bl	2940 <sysconf@plt>
    31a0:	f949f2e2 	ldr	x2, [x23, #5088]
    31a4:	cb0003e5 	neg	x5, x0
    31a8:	aa0003e4 	mov	x4, x0
    31ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    31b0:	f949fee0 	ldr	x0, [x23, #5112]
    31b4:	8b020843 	add	x3, x2, x2, lsl #2
    31b8:	52800062 	mov	w2, #0x3                   	// #3
    31bc:	8b010c01 	add	x1, x0, x1, lsl #3
    31c0:	8b030c03 	add	x3, x0, x3, lsl #3
    31c4:	d1000421 	sub	x1, x1, #0x1
    31c8:	8a050060 	and	x0, x3, x5
    31cc:	8b040021 	add	x1, x1, x4
    31d0:	8a050021 	and	x1, x1, x5
    31d4:	cb000021 	sub	x1, x1, x0
    31d8:	97fffdf2 	bl	29a0 <mprotect@plt>
    31dc:	35000500 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    31e0:	f909f2f6 	str	x22, [x23, #5088]
    31e4:	911542b5 	add	x21, x21, #0x550
    31e8:	d370be60 	lsl	x0, x19, #16
    31ec:	f949e6a1 	ldr	x1, [x21, #5064]
    31f0:	f909eeb3 	str	x19, [x21, #5080]
    31f4:	eb01001f 	cmp	x0, x1
    31f8:	540000e8 	b.hi	3214 <fwp_heap_chunks+0x164>  // b.pmore
    31fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3200:	aa1403e0 	mov	x0, x20
    3204:	a94153f3 	ldp	x19, x20, [sp, #16]
    3208:	f9401bf7 	ldr	x23, [sp, #48]
    320c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3210:	d65f03c0 	ret
    3214:	f9401bf7 	ldr	x23, [sp, #48]
    3218:	f909e6a0 	str	x0, [x21, #5064]
    321c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3220:	aa1403e0 	mov	x0, x20
    3224:	a94153f3 	ldp	x19, x20, [sp, #16]
    3228:	a8c47bfd 	ldp	x29, x30, [sp], #64
    322c:	d65f03c0 	ret
    3230:	911542b5 	add	x21, x21, #0x550
    3234:	91000441 	add	x1, x2, #0x1
    3238:	f90000a1 	str	x1, [x5]
    323c:	cb040054 	sub	x20, x2, x4
    3240:	f94a1aa1 	ldr	x1, [x21, #5168]
    3244:	cb000020 	sub	x0, x1, x0
    3248:	f90a1aa0 	str	x0, [x21, #5168]
    324c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3250:	aa1403e0 	mov	x0, x20
    3254:	a94153f3 	ldp	x19, x20, [sp, #16]
    3258:	a8c47bfd 	ldp	x29, x30, [sp], #64
    325c:	d65f03c0 	ret
    3260:	f949f422 	ldr	x2, [x1, #5096]
    3264:	f0000165 	adrp	x5, 32000 <fwp_heap+0xab0>
    3268:	9124e0a5 	add	x5, x5, #0x938
    326c:	17ffff9c 	b	30dc <fwp_heap_chunks+0x2c>
    3270:	d2800004 	mov	x4, #0x0                   	// #0
    3274:	f9001bf7 	str	x23, [sp, #48]
    3278:	17ffffb3 	b	3144 <fwp_heap_chunks+0x94>
    327c:	97ffff4d 	bl	2fb0 <fwp_heap_oom>

0000000000003280 <fwp_tape_buffers_dispose>:
    3280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3284:	910003fd 	mov	x29, sp
    3288:	f9000bf3 	str	x19, [sp, #16]
    328c:	aa0003f3 	mov	x19, x0
    3290:	f9400000 	ldr	x0, [x0]
    3294:	97fffd87 	bl	28b0 <free@plt>
    3298:	f9400a60 	ldr	x0, [x19, #16]
    329c:	97fffd85 	bl	28b0 <free@plt>
    32a0:	f9401260 	ldr	x0, [x19, #32]
    32a4:	97fffd83 	bl	28b0 <free@plt>
    32a8:	f9001a7f 	str	xzr, [x19, #48]
    32ac:	4f000400 	movi	v0.4s, #0x0
    32b0:	ad000260 	stp	q0, q0, [x19]
    32b4:	3d800a60 	str	q0, [x19, #32]
    32b8:	f9400bf3 	ldr	x19, [sp, #16]
    32bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    32c0:	d65f03c0 	ret

00000000000032c4 <buf_grow>:
    32c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    32c8:	910003fd 	mov	x29, sp
    32cc:	a90153f3 	stp	x19, x20, [sp, #16]
    32d0:	aa0003f4 	mov	x20, x0
    32d4:	f9400400 	ldr	x0, [x0, #8]
    32d8:	b100041f 	cmn	x0, #0x1
    32dc:	54000400 	b.eq	335c <buf_grow+0x98>  // b.none
    32e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    32e4:	cb000042 	sub	x2, x2, x0
    32e8:	eb01005f 	cmp	x2, x1
    32ec:	54000383 	b.cc	335c <buf_grow+0x98>  // b.lo, b.ul, b.last
    32f0:	f9400a82 	ldr	x2, [x20, #16]
    32f4:	91000421 	add	x1, x1, #0x1
    32f8:	8b000033 	add	x19, x1, x0
    32fc:	eb13005f 	cmp	x2, x19
    3300:	54000242 	b.cs	3348 <buf_grow+0x84>  // b.hs, b.nlast
    3304:	f100005f 	cmp	x2, #0x0
    3308:	b5000262 	cbnz	x2, 3354 <buf_grow+0x90>
    330c:	d2800802 	mov	x2, #0x40                  	// #64
    3310:	eb02027f 	cmp	x19, x2
    3314:	54000068 	b.hi	3320 <buf_grow+0x5c>  // b.pmore
    3318:	14000005 	b	332c <buf_grow+0x68>
    331c:	b7f800a2 	tbnz	x2, #63, 3330 <buf_grow+0x6c>
    3320:	d37ff842 	lsl	x2, x2, #1
    3324:	eb02027f 	cmp	x19, x2
    3328:	54ffffa8 	b.hi	331c <buf_grow+0x58>  // b.pmore
    332c:	aa0203f3 	mov	x19, x2
    3330:	f9400280 	ldr	x0, [x20]
    3334:	aa1303e1 	mov	x1, x19
    3338:	97fffd2a 	bl	27e0 <realloc@plt>
    333c:	b4000100 	cbz	x0, 335c <buf_grow+0x98>
    3340:	f9000280 	str	x0, [x20]
    3344:	f9000a93 	str	x19, [x20, #16]
    3348:	a94153f3 	ldp	x19, x20, [sp, #16]
    334c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3350:	d65f03c0 	ret
    3354:	54fffe6a 	b.ge	3320 <buf_grow+0x5c>  // b.tcont
    3358:	17fffff6 	b	3330 <buf_grow+0x6c>
    335c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3360:	f947e863 	ldr	x3, [x3, #4048]
    3364:	d2800262 	mov	x2, #0x13                  	// #19
    3368:	d2800021 	mov	x1, #0x1                   	// #1
    336c:	d0000040 	adrp	x0, d000 <__modti3+0x1f0>
    3370:	9106e000 	add	x0, x0, #0x1b8
    3374:	f9400063 	ldr	x3, [x3]
    3378:	97fffd5e 	bl	28f0 <fwrite@plt>
    337c:	d2800000 	mov	x0, #0x0                   	// #0
    3380:	97fffd68 	bl	2920 <fflush@plt>
    3384:	52800cc0 	mov	w0, #0x66                  	// #102
    3388:	97fffd76 	bl	2960 <_Exit@plt>
    338c:	d503201f 	nop

0000000000003390 <buf_put>:
    3390:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3394:	910003fd 	mov	x29, sp
    3398:	a90153f3 	stp	x19, x20, [sp, #16]
    339c:	aa0003f4 	mov	x20, x0
    33a0:	aa0203f3 	mov	x19, x2
    33a4:	f90013f5 	str	x21, [sp, #32]
    33a8:	aa0103f5 	mov	x21, x1
    33ac:	aa0203e1 	mov	x1, x2
    33b0:	97ffffc5 	bl	32c4 <buf_grow>
    33b4:	a9400283 	ldp	x3, x0, [x20]
    33b8:	aa1503e1 	mov	x1, x21
    33bc:	aa1303e2 	mov	x2, x19
    33c0:	8b000060 	add	x0, x3, x0
    33c4:	97fffc9f 	bl	2640 <memcpy@plt>
    33c8:	a9400680 	ldp	x0, x1, [x20]
    33cc:	8b010273 	add	x19, x19, x1
    33d0:	f9000693 	str	x19, [x20, #8]
    33d4:	3833681f 	strb	wzr, [x0, x19]
    33d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33dc:	f94013f5 	ldr	x21, [sp, #32]
    33e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    33e4:	d65f03c0 	ret
    33e8:	d503201f 	nop
    33ec:	d503201f 	nop

00000000000033f0 <fwp_cancel_tree.part.0>:
    33f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    33f4:	91010022 	add	x2, x1, #0x40
    33f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    33fc:	52800023 	mov	w3, #0x1                   	// #1
    3400:	910003fd 	mov	x29, sp
    3404:	f9400844 	ldr	x4, [x2, #16]
    3408:	f9000bf3 	str	x19, [sp, #16]
    340c:	39014403 	strb	w3, [x0, #81]
    3410:	eb04001f 	cmp	x0, x4
    3414:	54000160 	b.eq	3440 <fwp_cancel_tree.part.0+0x50>  // b.none
    3418:	f9402804 	ldr	x4, [x0, #80]
    341c:	f2001c9f 	tst	x4, #0xff000000ff
    3420:	54000101 	b.ne	3440 <fwp_cancel_tree.part.0+0x50>  // b.any
    3424:	f9401444 	ldr	x4, [x2, #40]
    3428:	39015003 	strb	w3, [x0, #84]
    342c:	f900801f 	str	xzr, [x0, #256]
    3430:	b40001e4 	cbz	x4, 346c <fwp_cancel_tree.part.0+0x7c>
    3434:	f9008080 	str	x0, [x4, #256]
    3438:	91010021 	add	x1, x1, #0x40
    343c:	f9001420 	str	x0, [x1, #40]
    3440:	f9401413 	ldr	x19, [x0, #40]
    3444:	b40000f3 	cbz	x19, 3460 <fwp_cancel_tree.part.0+0x70>
    3448:	39414261 	ldrb	w1, [x19, #80]
    344c:	aa1303e0 	mov	x0, x19
    3450:	37000041 	tbnz	w1, #0, 3458 <fwp_cancel_tree.part.0+0x68>
    3454:	97ffffe7 	bl	33f0 <fwp_cancel_tree.part.0>
    3458:	f9401a73 	ldr	x19, [x19, #48]
    345c:	b5ffff73 	cbnz	x19, 3448 <fwp_cancel_tree.part.0+0x58>
    3460:	f9400bf3 	ldr	x19, [sp, #16]
    3464:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3468:	d65f03c0 	ret
    346c:	f9001840 	str	x0, [x2, #48]
    3470:	17fffff2 	b	3438 <fwp_cancel_tree.part.0+0x48>

0000000000003474 <fwp_finish_float>:
    3474:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3478:	528005c1 	mov	w1, #0x2e                  	// #46
    347c:	910003fd 	mov	x29, sp
    3480:	f9000bf3 	str	x19, [sp, #16]
    3484:	aa0003f3 	mov	x19, x0
    3488:	97fffd12 	bl	28d0 <strchr@plt>
    348c:	b4000080 	cbz	x0, 349c <fwp_finish_float+0x28>
    3490:	f9400bf3 	ldr	x19, [sp, #16]
    3494:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3498:	d65f03c0 	ret
    349c:	aa1303e0 	mov	x0, x19
    34a0:	52800ca1 	mov	w1, #0x65                  	// #101
    34a4:	97fffd0b 	bl	28d0 <strchr@plt>
    34a8:	b5ffff40 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34ac:	d0000041 	adrp	x1, d000 <__modti3+0x1f0>
    34b0:	aa1303e0 	mov	x0, x19
    34b4:	91074021 	add	x1, x1, #0x1d0
    34b8:	97fffd26 	bl	2950 <strstr@plt>
    34bc:	b5fffea0 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34c0:	d0000041 	adrp	x1, d000 <__modti3+0x1f0>
    34c4:	aa1303e0 	mov	x0, x19
    34c8:	91076021 	add	x1, x1, #0x1d8
    34cc:	97fffd21 	bl	2950 <strstr@plt>
    34d0:	b5fffe00 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34d4:	aa1303e0 	mov	x0, x19
    34d8:	97fffc6a 	bl	2680 <strlen@plt>
    34dc:	d0000041 	adrp	x1, d000 <__modti3+0x1f0>
    34e0:	91078021 	add	x1, x1, #0x1e0
    34e4:	8b000262 	add	x2, x19, x0
    34e8:	79400023 	ldrh	w3, [x1]
    34ec:	39400821 	ldrb	w1, [x1, #2]
    34f0:	78206a63 	strh	w3, [x19, x0]
    34f4:	39000841 	strb	w1, [x2, #2]
    34f8:	17ffffe6 	b	3490 <fwp_finish_float+0x1c>
    34fc:	d503201f 	nop

0000000000003500 <fwp_trap>:
    3500:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3504:	d53bd041 	mrs	x1, tpidr_el0
    3508:	91400021 	add	x1, x1, #0x0, lsl #12
    350c:	91004021 	add	x1, x1, #0x10
    3510:	910003fd 	mov	x29, sp
    3514:	a90153f3 	stp	x19, x20, [sp, #16]
    3518:	aa0003f3 	mov	x19, x0
    351c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    3520:	f947ea94 	ldr	x20, [x20, #4048]
    3524:	f90013f5 	str	x21, [sp, #32]
    3528:	f9400035 	ldr	x21, [x1]
    352c:	97fffe91 	bl	2f70 <fwp_flush>
    3530:	f9400280 	ldr	x0, [x20]
    3534:	d0000042 	adrp	x2, d000 <__modti3+0x1f0>
    3538:	aa1303e3 	mov	x3, x19
    353c:	9107a042 	add	x2, x2, #0x1e8
    3540:	52800041 	mov	w1, #0x2                   	// #2
    3544:	97fffcc7 	bl	2860 <__fprintf_chk@plt>
    3548:	b40000b5 	cbz	x21, 355c <fwp_trap+0x5c>
    354c:	f9400280 	ldr	x0, [x20]
    3550:	97fffcf4 	bl	2920 <fflush@plt>
    3554:	52800ca0 	mov	w0, #0x65                  	// #101
    3558:	97fffd02 	bl	2960 <_Exit@plt>
    355c:	52800ca0 	mov	w0, #0x65                  	// #101
    3560:	97fffc50 	bl	26a0 <exit@plt>

0000000000003564 <fwp_closure_drop_push>:
    3564:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3568:	910003fd 	mov	x29, sp
    356c:	a90153f3 	stp	x19, x20, [sp, #16]
    3570:	aa0003f3 	mov	x19, x0
    3574:	a9408014 	ldp	x20, x0, [x0, #8]
    3578:	a9025bf5 	stp	x21, x22, [sp, #32]
    357c:	aa0103f5 	mov	x21, x1
    3580:	a90363f7 	stp	x23, x24, [sp, #48]
    3584:	eb00029f 	cmp	x20, x0
    3588:	54000160 	b.eq	35b4 <fwp_closure_drop_push+0x50>  // b.none
    358c:	f9400276 	ldr	x22, [x19]
    3590:	d37df297 	lsl	x23, x20, #3
    3594:	91000694 	add	x20, x20, #0x1
    3598:	f9000674 	str	x20, [x19, #8]
    359c:	a94153f3 	ldp	x19, x20, [sp, #16]
    35a0:	f8376ad5 	str	x21, [x22, x23]
    35a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    35a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    35ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    35b0:	d65f03c0 	ret
    35b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    35b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    35bc:	eb00029f 	cmp	x20, x0
    35c0:	54000568 	b.hi	366c <fwp_closure_drop_push+0x108>  // b.pmore
    35c4:	d37cee99 	lsl	x25, x20, #4
    35c8:	d37ffa9a 	lsl	x26, x20, #1
    35cc:	aa1903e0 	mov	x0, x25
    35d0:	97fffc70 	bl	2790 <malloc@plt>
    35d4:	aa0003f6 	mov	x22, x0
    35d8:	b4000320 	cbz	x0, 363c <fwp_closure_drop_push+0xd8>
    35dc:	aa1303f8 	mov	x24, x19
    35e0:	aa1903e3 	mov	x3, x25
    35e4:	d37df297 	lsl	x23, x20, #3
    35e8:	aa1703e2 	mov	x2, x23
    35ec:	f8418719 	ldr	x25, [x24], #24
    35f0:	aa1903e1 	mov	x1, x25
    35f4:	97fffc53 	bl	2740 <__memcpy_chk@plt>
    35f8:	eb18033f 	cmp	x25, x24
    35fc:	540000a0 	b.eq	3610 <fwp_closure_drop_push+0xac>  // b.none
    3600:	aa1903e0 	mov	x0, x25
    3604:	97fffcab 	bl	28b0 <free@plt>
    3608:	f9400674 	ldr	x20, [x19, #8]
    360c:	d37df297 	lsl	x23, x20, #3
    3610:	91000694 	add	x20, x20, #0x1
    3614:	f9000276 	str	x22, [x19]
    3618:	f9000a7a 	str	x26, [x19, #16]
    361c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3620:	f9000674 	str	x20, [x19, #8]
    3624:	f8376ad5 	str	x21, [x22, x23]
    3628:	a94153f3 	ldp	x19, x20, [sp, #16]
    362c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3630:	a94363f7 	ldp	x23, x24, [sp, #48]
    3634:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3638:	d65f03c0 	ret
    363c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3640:	f947e863 	ldr	x3, [x3, #4048]
    3644:	d2800262 	mov	x2, #0x13                  	// #19
    3648:	d2800021 	mov	x1, #0x1                   	// #1
    364c:	d0000040 	adrp	x0, d000 <__modti3+0x1f0>
    3650:	9106e000 	add	x0, x0, #0x1b8
    3654:	f9400063 	ldr	x3, [x3]
    3658:	97fffca6 	bl	28f0 <fwrite@plt>
    365c:	d2800000 	mov	x0, #0x0                   	// #0
    3660:	97fffcb0 	bl	2920 <fflush@plt>
    3664:	52800cc0 	mov	w0, #0x66                  	// #102
    3668:	97fffcbe 	bl	2960 <_Exit@plt>
    366c:	d0000040 	adrp	x0, d000 <__modti3+0x1f0>
    3670:	9107e000 	add	x0, x0, #0x1f8
    3674:	97ffffa3 	bl	3500 <fwp_trap>
    3678:	d503201f 	nop
    367c:	d503201f 	nop

0000000000003680 <fwp_now_ns>:
    3680:	d100c3ff 	sub	sp, sp, #0x30
    3684:	52800020 	mov	w0, #0x1                   	// #1
    3688:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    368c:	f947f442 	ldr	x2, [x2, #4072]
    3690:	910023e1 	add	x1, sp, #0x8
    3694:	a9027bfd 	stp	x29, x30, [sp, #32]
    3698:	910083fd 	add	x29, sp, #0x20
    369c:	f9400043 	ldr	x3, [x2]
    36a0:	f9000fe3 	str	x3, [sp, #24]
    36a4:	d2800003 	mov	x3, #0x0                   	// #0
    36a8:	97fffc1e 	bl	2720 <clock_gettime@plt>
    36ac:	350002c0 	cbnz	w0, 3704 <fwp_now_ns+0x84>
    36b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    36b4:	d2994003 	mov	x3, #0xca00                	// #51712
    36b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    36bc:	9b037c20 	mul	x0, x1, x3
    36c0:	9b437c21 	smulh	x1, x1, x3
    36c4:	ab020000 	adds	x0, x0, x2
    36c8:	937ffc42 	asr	x2, x2, #63
    36cc:	9a020021 	adc	x1, x1, x2
    36d0:	f100001f 	cmp	x0, #0x0
    36d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    36d8:	b50001e1 	cbnz	x1, 3714 <fwp_now_ns+0x94>
    36dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    36e0:	f947f421 	ldr	x1, [x1, #4072]
    36e4:	f9400fe3 	ldr	x3, [sp, #24]
    36e8:	f9400022 	ldr	x2, [x1]
    36ec:	eb020063 	subs	x3, x3, x2
    36f0:	d2800002 	mov	x2, #0x0                   	// #0
    36f4:	540000e1 	b.ne	3710 <fwp_now_ns+0x90>  // b.any
    36f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36fc:	9100c3ff 	add	sp, sp, #0x30
    3700:	d65f03c0 	ret
    3704:	d0000040 	adrp	x0, d000 <__modti3+0x1f0>
    3708:	91086000 	add	x0, x0, #0x218
    370c:	97ffff7d 	bl	3500 <fwp_trap>
    3710:	97fffc38 	bl	27f0 <__stack_chk_fail@plt>
    3714:	d0000040 	adrp	x0, d000 <__modti3+0x1f0>
    3718:	9108e000 	add	x0, x0, #0x238
    371c:	97ffff79 	bl	3500 <fwp_trap>

0000000000003720 <fwp_closure_drop.part.0>:
    3720:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3724:	d0000041 	adrp	x1, d000 <__modti3+0x1f0>
    3728:	910003fd 	mov	x29, sp
    372c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3730:	f947f463 	ldr	x3, [x3, #4072]
    3734:	a90153f3 	stp	x19, x20, [sp, #16]
    3738:	d10883ff 	sub	sp, sp, #0x220
    373c:	910003e2 	mov	x2, sp
    3740:	d53bd053 	mrs	x19, tpidr_el0
    3744:	910063f4 	add	x20, sp, #0x18
    3748:	3dc39420 	ldr	q0, [x1, #3664]
    374c:	91400264 	add	x4, x19, #0x0, lsl #12
    3750:	91004084 	add	x4, x4, #0x10
    3754:	aa0003e1 	mov	x1, x0
    3758:	aa0203e0 	mov	x0, x2
    375c:	f9400062 	ldr	x2, [x3]
    3760:	f9010fe2 	str	x2, [sp, #536]
    3764:	d2800002 	mov	x2, #0x0                   	// #0
    3768:	f90003f4 	str	x20, [sp]
    376c:	f9000080 	str	x0, [x4]
    3770:	3c8083e0 	stur	q0, [sp, #8]
    3774:	97ffff7c 	bl	3564 <fwp_closure_drop_push>
    3778:	f94007e0 	ldr	x0, [sp, #8]
    377c:	b4000280 	cbz	x0, 37cc <fwp_closure_drop.part.0+0xac>
    3780:	f90123f5 	str	x21, [sp, #576]
    3784:	b00000f5 	adrp	x21, 20000 <__data_start>
    3788:	910102b5 	add	x21, x21, #0x40
    378c:	d503201f 	nop
    3790:	f94003e1 	ldr	x1, [sp]
    3794:	d1000400 	sub	x0, x0, #0x1
    3798:	f90007e0 	str	x0, [sp, #8]
    379c:	f9401ea2 	ldr	x2, [x21, #56]
    37a0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    37a4:	b9400001 	ldr	w1, [x0]
    37a8:	8b011441 	add	x1, x2, x1, lsl #5
    37ac:	f9400c21 	ldr	x1, [x1, #24]
    37b0:	b4000321 	cbz	x1, 3814 <fwp_closure_drop.part.0+0xf4>
    37b4:	f9400422 	ldr	x2, [x1, #8]
    37b8:	52800001 	mov	w1, #0x0                   	// #0
    37bc:	d63f0040 	blr	x2
    37c0:	f94007e0 	ldr	x0, [sp, #8]
    37c4:	b5fffe60 	cbnz	x0, 3790 <fwp_closure_drop.part.0+0x70>
    37c8:	f94123f5 	ldr	x21, [sp, #576]
    37cc:	91400273 	add	x19, x19, #0x0, lsl #12
    37d0:	91004273 	add	x19, x19, #0x10
    37d4:	f94003e0 	ldr	x0, [sp]
    37d8:	f900027f 	str	xzr, [x19]
    37dc:	eb14001f 	cmp	x0, x20
    37e0:	54000040 	b.eq	37e8 <fwp_closure_drop.part.0+0xc8>  // b.none
    37e4:	97fffc33 	bl	28b0 <free@plt>
    37e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    37ec:	f947f400 	ldr	x0, [x0, #4072]
    37f0:	f9410fe2 	ldr	x2, [sp, #536]
    37f4:	f9400001 	ldr	x1, [x0]
    37f8:	eb010042 	subs	x2, x2, x1
    37fc:	d2800001 	mov	x1, #0x0                   	// #0
    3800:	54000101 	b.ne	3820 <fwp_closure_drop.part.0+0x100>  // b.any
    3804:	910883ff 	add	sp, sp, #0x220
    3808:	a94153f3 	ldp	x19, x20, [sp, #16]
    380c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3810:	d65f03c0 	ret
    3814:	d0000040 	adrp	x0, d000 <__modti3+0x1f0>
    3818:	91098000 	add	x0, x0, #0x260
    381c:	97ffff39 	bl	3500 <fwp_trap>
    3820:	f90123f5 	str	x21, [sp, #576]
    3824:	97fffbf3 	bl	27f0 <__stack_chk_fail@plt>
    3828:	d503201f 	nop
    382c:	d503201f 	nop

0000000000003830 <fwp_tape_of>:
    3830:	92403c02 	and	x2, x0, #0xffff
    3834:	b4000262 	cbz	x2, 3880 <fwp_tape_of+0x50>
    3838:	9350fc01 	asr	x1, x0, #16
    383c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3840:	d1000440 	sub	x0, x2, #0x1
    3844:	91010062 	add	x2, x3, #0x40
    3848:	f9402042 	ldr	x2, [x2, #64]
    384c:	eb00005f 	cmp	x2, x0
    3850:	5400018d 	b.le	3880 <fwp_tape_of+0x50>
    3854:	8b000402 	add	x2, x0, x0, lsl #1
    3858:	f9402063 	ldr	x3, [x3, #64]
    385c:	8b020802 	add	x2, x0, x2, lsl #2
    3860:	d37df042 	lsl	x2, x2, #3
    3864:	8b020060 	add	x0, x3, x2
    3868:	b9400404 	ldr	w4, [x0, #4]
    386c:	340000a4 	cbz	w4, 3880 <fwp_tape_of+0x50>
    3870:	b8626862 	ldr	w2, [x3, x2]
    3874:	6b01005f 	cmp	w2, w1
    3878:	54000041 	b.ne	3880 <fwp_tape_of+0x50>  // b.any
    387c:	d65f03c0 	ret
    3880:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3884:	d0000040 	adrp	x0, d000 <__modti3+0x1f0>
    3888:	910a4000 	add	x0, x0, #0x290
    388c:	910003fd 	mov	x29, sp
    3890:	97ffff1c 	bl	3500 <fwp_trap>

0000000000003894 <fwp_format_g.constprop.0>:
    3894:	d10483ff 	sub	sp, sp, #0x120
    3898:	d0000044 	adrp	x4, d000 <__modti3+0x1f0>
    389c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    38a0:	f947f442 	ldr	x2, [x2, #4072]
    38a4:	910b8084 	add	x4, x4, #0x2e0
    38a8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    38ac:	9102c3fd 	add	x29, sp, #0xb0
    38b0:	d2800803 	mov	x3, #0x40                  	// #64
    38b4:	a90e63f7 	stp	x23, x24, [sp, #224]
    38b8:	93407c38 	sxtw	x24, w1
    38bc:	aa0303e1 	mov	x1, x3
    38c0:	fd008be8 	str	d8, [sp, #272]
    38c4:	1e604008 	fmov	d8, d0
    38c8:	a90c53f3 	stp	x19, x20, [sp, #192]
    38cc:	910083f4 	add	x20, sp, #0x20
    38d0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    38d4:	aa0003f5 	mov	x21, x0
    38d8:	a91073fb 	stp	x27, x28, [sp, #256]
    38dc:	5100071c 	sub	w28, w24, #0x1
    38e0:	2a1c03e5 	mov	w5, w28
    38e4:	f9400040 	ldr	x0, [x2]
    38e8:	f90057e0 	str	x0, [sp, #168]
    38ec:	d2800000 	mov	x0, #0x0                   	// #0
    38f0:	52800042 	mov	w2, #0x2                   	// #2
    38f4:	aa1403e0 	mov	x0, x20
    38f8:	97fffb9a 	bl	2760 <__snprintf_chk@plt>
    38fc:	52800ca1 	mov	w1, #0x65                  	// #101
    3900:	aa1403e0 	mov	x0, x20
    3904:	97fffbf3 	bl	28d0 <strchr@plt>
    3908:	aa0003f3 	mov	x19, x0
    390c:	52800142 	mov	w2, #0xa                   	// #10
    3910:	91000400 	add	x0, x0, #0x1
    3914:	d2800001 	mov	x1, #0x0                   	// #0
    3918:	97fffbde 	bl	2890 <strtol@plt>
    391c:	aa0003f7 	mov	x23, x0
    3920:	11001400 	add	w0, w0, #0x5
    3924:	7100541f 	cmp	w0, #0x15
    3928:	54000d88 	b.hi	3ad8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    392c:	4b170385 	sub	w5, w28, w23
    3930:	710000bf 	cmp	w5, #0x0
    3934:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3938:	54000ba0 	b.eq	3aac <fwp_format_g.constprop.0+0x218>  // b.none
    393c:	394083e0 	ldrb	w0, [sp, #32]
    3940:	cb180273 	sub	x19, x19, x24
    3944:	91000673 	add	x19, x19, #0x1
    3948:	a90f6bf9 	stp	x25, x26, [sp, #240]
    394c:	7100b41f 	cmp	w0, #0x2d
    3950:	9a941681 	cinc	x1, x20, eq	// eq = none
    3954:	1a9f17e4 	cset	w4, eq	// eq = none
    3958:	cb010266 	sub	x6, x19, x1
    395c:	d10004da 	sub	x26, x6, #0x1
    3960:	540018c0 	b.eq	3c78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3964:	910183f9 	add	x25, sp, #0x60
    3968:	d280091b 	mov	x27, #0x48                  	// #72
    396c:	aa1903e7 	mov	x7, x25
    3970:	91000423 	add	x3, x1, #0x1
    3974:	91011cc6 	add	x6, x6, #0x47
    3978:	910004f6 	add	x22, x7, #0x1
    397c:	37f81017 	tbnz	w23, #31, 3b7c <fwp_format_g.constprop.0+0x2e8>
    3980:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3984:	93407ef7 	sxtw	x23, w23
    3988:	390000e4 	strb	w4, [x7]
    398c:	aa1303e1 	mov	x1, x19
    3990:	aa1703e2 	mov	x2, x23
    3994:	aa1603e0 	mov	x0, x22
    3998:	b9000be5 	str	w5, [sp, #8]
    399c:	cb170374 	sub	x20, x27, x23
    39a0:	a9011be3 	stp	x3, x6, [sp, #16]
    39a4:	97fffb27 	bl	2640 <memcpy@plt>
    39a8:	d1000694 	sub	x20, x20, #0x1
    39ac:	f9400be3 	ldr	x3, [sp, #16]
    39b0:	8b1702d6 	add	x22, x22, x23
    39b4:	aa1603e0 	mov	x0, x22
    39b8:	aa1a03e2 	mov	x2, x26
    39bc:	aa0303e1 	mov	x1, x3
    39c0:	aa1403e3 	mov	x3, x20
    39c4:	97fffb5f 	bl	2740 <__memcpy_chk@plt>
    39c8:	8b1a02d6 	add	x22, x22, x26
    39cc:	f9400fe6 	ldr	x6, [sp, #24]
    39d0:	d2800900 	mov	x0, #0x48                  	// #72
    39d4:	b9400be5 	ldr	w5, [sp, #8]
    39d8:	8b170261 	add	x1, x19, x23
    39dc:	cb1400c3 	sub	x3, x6, x20
    39e0:	cb060294 	sub	x20, x20, x6
    39e4:	f101207f 	cmp	x3, #0x48
    39e8:	93407cb8 	sxtw	x24, w5
    39ec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    39f0:	aa1803e2 	mov	x2, x24
    39f4:	8b1802d3 	add	x19, x22, x24
    39f8:	8b140063 	add	x3, x3, x20
    39fc:	aa1603e0 	mov	x0, x22
    3a00:	97fffb50 	bl	2740 <__memcpy_chk@plt>
    3a04:	cb190273 	sub	x19, x19, x25
    3a08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3a0c:	eb00027f 	cmp	x19, x0
    3a10:	aa1903e1 	mov	x1, x25
    3a14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a18:	aa1503e0 	mov	x0, x21
    3a1c:	aa1303e2 	mov	x2, x19
    3a20:	97fffb08 	bl	2640 <memcpy@plt>
    3a24:	38336abf 	strb	wzr, [x21, x19]
    3a28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3a2c:	aa1503e0 	mov	x0, x21
    3a30:	97fffb14 	bl	2680 <strlen@plt>
    3a34:	aa0003f3 	mov	x19, x0
    3a38:	528005c1 	mov	w1, #0x2e                  	// #46
    3a3c:	aa1503e0 	mov	x0, x21
    3a40:	97fffba4 	bl	28d0 <strchr@plt>
    3a44:	b4000160 	cbz	x0, 3a70 <fwp_format_g.constprop.0+0x1dc>
    3a48:	b4000153 	cbz	x19, 3a70 <fwp_format_g.constprop.0+0x1dc>
    3a4c:	d503201f 	nop
    3a50:	aa1303e1 	mov	x1, x19
    3a54:	d1000673 	sub	x19, x19, #0x1
    3a58:	38736aa0 	ldrb	w0, [x21, x19]
    3a5c:	7100c01f 	cmp	w0, #0x30
    3a60:	54001001 	b.ne	3c60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3a64:	38336abf 	strb	wzr, [x21, x19]
    3a68:	b5ffff53 	cbnz	x19, 3a50 <fwp_format_g.constprop.0+0x1bc>
    3a6c:	d503201f 	nop
    3a70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3a74:	f947f400 	ldr	x0, [x0, #4072]
    3a78:	f94057e2 	ldr	x2, [sp, #168]
    3a7c:	f9400001 	ldr	x1, [x0]
    3a80:	eb010042 	subs	x2, x2, x1
    3a84:	d2800001 	mov	x1, #0x0                   	// #0
    3a88:	54001061 	b.ne	3c94 <fwp_format_g.constprop.0+0x400>  // b.any
    3a8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3a90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3a94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3aa0:	fd408be8 	ldr	d8, [sp, #272]
    3aa4:	910483ff 	add	sp, sp, #0x120
    3aa8:	d65f03c0 	ret
    3aac:	1e604100 	fmov	d0, d8
    3ab0:	710000bf 	cmp	w5, #0x0
    3ab4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	d0000044 	adrp	x4, d000 <__modti3+0x1f0>
    3ac0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ac4:	910be084 	add	x4, x4, #0x2f8
    3ac8:	52800042 	mov	w2, #0x2                   	// #2
    3acc:	d2803201 	mov	x1, #0x190                 	// #400
    3ad0:	97fffb24 	bl	2760 <__snprintf_chk@plt>
    3ad4:	17ffffd6 	b	3a2c <fwp_format_g.constprop.0+0x198>
    3ad8:	cb140273 	sub	x19, x19, x20
    3adc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ae0:	910183f9 	add	x25, sp, #0x60
    3ae4:	aa1303e2 	mov	x2, x19
    3ae8:	aa1403e1 	mov	x1, x20
    3aec:	aa1903e0 	mov	x0, x25
    3af0:	d2800803 	mov	x3, #0x40                  	// #64
    3af4:	97fffb13 	bl	2740 <__memcpy_chk@plt>
    3af8:	38336b3f 	strb	wzr, [x25, x19]
    3afc:	aa1903e0 	mov	x0, x25
    3b00:	528005c1 	mov	w1, #0x2e                  	// #46
    3b04:	97fffb73 	bl	28d0 <strchr@plt>
    3b08:	b40001c0 	cbz	x0, 3b40 <fwp_format_g.constprop.0+0x2ac>
    3b0c:	b50000b3 	cbnz	x19, 3b20 <fwp_format_g.constprop.0+0x28c>
    3b10:	1400000c 	b	3b40 <fwp_format_g.constprop.0+0x2ac>
    3b14:	381ff01f 	sturb	wzr, [x0, #-1]
    3b18:	f1000673 	subs	x19, x19, #0x1
    3b1c:	54000120 	b.eq	3b40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3b20:	8b130320 	add	x0, x25, x19
    3b24:	385ff001 	ldurb	w1, [x0, #-1]
    3b28:	7100c03f 	cmp	w1, #0x30
    3b2c:	54ffff40 	b.eq	3b14 <fwp_format_g.constprop.0+0x280>  // b.none
    3b30:	d1000673 	sub	x19, x19, #0x1
    3b34:	38736b20 	ldrb	w0, [x25, x19]
    3b38:	7100b81f 	cmp	w0, #0x2e
    3b3c:	54000a80 	b.eq	3c8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3b40:	710002ff 	cmp	w23, #0x0
    3b44:	528005a1 	mov	w1, #0x2d                  	// #45
    3b48:	aa1903e5 	mov	x5, x25
    3b4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3b50:	aa1503e0 	mov	x0, x21
    3b54:	52800566 	mov	w6, #0x2b                  	// #43
    3b58:	d0000044 	adrp	x4, d000 <__modti3+0x1f0>
    3b5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3b60:	910ba084 	add	x4, x4, #0x2e8
    3b64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b68:	52800042 	mov	w2, #0x2                   	// #2
    3b6c:	d2803201 	mov	x1, #0x190                 	// #400
    3b70:	97fffafc 	bl	2760 <__snprintf_chk@plt>
    3b74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3b78:	17ffffbe 	b	3a70 <fwp_format_g.constprop.0+0x1dc>
    3b7c:	52800605 	mov	w5, #0x30                  	// #48
    3b80:	390000e5 	strb	w5, [x7]
    3b84:	d100077b 	sub	x27, x27, #0x1
    3b88:	aa0303e1 	mov	x1, x3
    3b8c:	aa1603e0 	mov	x0, x22
    3b90:	aa1b03e3 	mov	x3, x27
    3b94:	aa1a03e2 	mov	x2, x26
    3b98:	f90007e6 	str	x6, [sp, #8]
    3b9c:	b90013e4 	str	w4, [sp, #16]
    3ba0:	8b1a02d6 	add	x22, x22, x26
    3ba4:	b9001be5 	str	w5, [sp, #24]
    3ba8:	97fffae6 	bl	2740 <__memcpy_chk@plt>
    3bac:	f94007e6 	ldr	x6, [sp, #8]
    3bb0:	2a3703e7 	mvn	w7, w23
    3bb4:	b94013e4 	ldr	w4, [sp, #16]
    3bb8:	cb1b00c1 	sub	x1, x6, x27
    3bbc:	cb06037b 	sub	x27, x27, x6
    3bc0:	f101203f 	cmp	x1, #0x48
    3bc4:	d2800906 	mov	x6, #0x48                  	// #72
    3bc8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3bcc:	8b1b0023 	add	x3, x1, x27
    3bd0:	310006ff 	cmn	w23, #0x1
    3bd4:	54000220 	b.eq	3c18 <fwp_format_g.constprop.0+0x384>  // b.none
    3bd8:	b9401be5 	ldr	w5, [sp, #24]
    3bdc:	d2800001 	mov	x1, #0x0                   	// #0
    3be0:	f101207f 	cmp	x3, #0x48
    3be4:	d1000462 	sub	x2, x3, #0x1
    3be8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3bec:	38216ac5 	strb	w5, [x22, x1]
    3bf0:	cb030003 	sub	x3, x0, x3
    3bf4:	91000421 	add	x1, x1, #0x1
    3bf8:	91000463 	add	x3, x3, #0x1
    3bfc:	eb00007f 	cmp	x3, x0
    3c00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c04:	cb000063 	sub	x3, x3, x0
    3c08:	8b020063 	add	x3, x3, x2
    3c0c:	6b0100ff 	cmp	w7, w1
    3c10:	54fffe8c 	b.gt	3be0 <fwp_format_g.constprop.0+0x34c>
    3c14:	8b2742d6 	add	x22, x22, w7, uxtw
    3c18:	f101207f 	cmp	x3, #0x48
    3c1c:	d2800905 	mov	x5, #0x48                  	// #72
    3c20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3c24:	aa1603e0 	mov	x0, x22
    3c28:	cb0300a1 	sub	x1, x5, x3
    3c2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3c30:	91000421 	add	x1, x1, #0x1
    3c34:	d1000463 	sub	x3, x3, #0x1
    3c38:	eb05003f 	cmp	x1, x5
    3c3c:	38001402 	strb	w2, [x0], #1
    3c40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3c44:	93407f82 	sxtw	x2, w28
    3c48:	cb050025 	sub	x5, x1, x5
    3c4c:	aa1303e1 	mov	x1, x19
    3c50:	8b0300a3 	add	x3, x5, x3
    3c54:	8b1802d3 	add	x19, x22, x24
    3c58:	97fffaba 	bl	2740 <__memcpy_chk@plt>
    3c5c:	17ffff6a 	b	3a04 <fwp_format_g.constprop.0+0x170>
    3c60:	d1000421 	sub	x1, x1, #0x1
    3c64:	38616aa0 	ldrb	w0, [x21, x1]
    3c68:	7100b81f 	cmp	w0, #0x2e
    3c6c:	54fff021 	b.ne	3a70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3c70:	38216abf 	strb	wzr, [x21, x1]
    3c74:	17ffff7f 	b	3a70 <fwp_format_g.constprop.0+0x1dc>
    3c78:	910187e7 	add	x7, sp, #0x61
    3c7c:	910183f9 	add	x25, sp, #0x60
    3c80:	d28008fb 	mov	x27, #0x47                  	// #71
    3c84:	390183e0 	strb	w0, [sp, #96]
    3c88:	17ffff3a 	b	3970 <fwp_format_g.constprop.0+0xdc>
    3c8c:	38336b3f 	strb	wzr, [x25, x19]
    3c90:	17ffffac 	b	3b40 <fwp_format_g.constprop.0+0x2ac>
    3c94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c98:	97fffad6 	bl	27f0 <__stack_chk_fail@plt>
    3c9c:	d503201f 	nop

0000000000003ca0 <fwp_heap_report>:
    3ca0:	d105c3ff 	sub	sp, sp, #0x170
    3ca4:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    3ca8:	91154042 	add	x2, x2, #0x550
    3cac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3cb0:	f947e821 	ldr	x1, [x1, #4048]
    3cb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3cb8:	910443fd 	add	x29, sp, #0x110
    3cbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3cc0:	f947f400 	ldr	x0, [x0, #4072]
    3cc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3cc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3ccc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3cd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3cd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3cd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3cdc:	f9400036 	ldr	x22, [x1]
    3ce0:	f9400001 	ldr	x1, [x0]
    3ce4:	f90087e1 	str	x1, [sp, #264]
    3ce8:	d2800001 	mov	x1, #0x0                   	// #0
    3cec:	f949e459 	ldr	x25, [x2, #5064]
    3cf0:	d0000041 	adrp	x1, d000 <__modti3+0x1f0>
    3cf4:	f94a1057 	ldr	x23, [x2, #5152]
    3cf8:	d0000040 	adrp	x0, d000 <__modti3+0x1f0>
    3cfc:	f94a1458 	ldr	x24, [x2, #5160]
    3d00:	910c0021 	add	x1, x1, #0x300
    3d04:	910c2000 	add	x0, x0, #0x308
    3d08:	97fffa9e 	bl	2780 <fopen@plt>
    3d0c:	b4000740 	cbz	x0, 3df4 <fwp_heap_report+0x154>
    3d10:	528daad5 	mov	w21, #0x6d56                	// #27990
    3d14:	a91253f3 	stp	x19, x20, [sp, #288]
    3d18:	aa0003f4 	mov	x20, x0
    3d1c:	910023f3 	add	x19, sp, #0x8
    3d20:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d24:	72aae915 	movk	w21, #0x5748, lsl #16
    3d28:	aa1403e2 	mov	x2, x20
    3d2c:	aa1303e0 	mov	x0, x19
    3d30:	52802001 	mov	w1, #0x100                 	// #256
    3d34:	97fffb1f 	bl	29b0 <fgets@plt>
    3d38:	b4000280 	cbz	x0, 3d88 <fwp_heap_report+0xe8>
    3d3c:	b9400261 	ldr	w1, [x19]
    3d40:	6b15003f 	cmp	w1, w21
    3d44:	54ffff21 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d48:	39401260 	ldrb	w0, [x19, #4]
    3d4c:	7101341f 	cmp	w0, #0x4d
    3d50:	54fffec1 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d54:	394037e0 	ldrb	w0, [sp, #13]
    3d58:	7100e81f 	cmp	w0, #0x3a
    3d5c:	54fffe61 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d60:	52800142 	mov	w2, #0xa                   	// #10
    3d64:	d2800001 	mov	x1, #0x0                   	// #0
    3d68:	91003be0 	add	x0, sp, #0xe
    3d6c:	97fffac9 	bl	2890 <strtol@plt>
    3d70:	aa1403e2 	mov	x2, x20
    3d74:	aa0003fa 	mov	x26, x0
    3d78:	52802001 	mov	w1, #0x100                 	// #256
    3d7c:	aa1303e0 	mov	x0, x19
    3d80:	97fffb0c 	bl	29b0 <fgets@plt>
    3d84:	b5fffdc0 	cbnz	x0, 3d3c <fwp_heap_report+0x9c>
    3d88:	aa1403e0 	mov	x0, x20
    3d8c:	97fffa79 	bl	2770 <fclose@plt>
    3d90:	a95253f3 	ldp	x19, x20, [sp, #288]
    3d94:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d98:	f947f400 	ldr	x0, [x0, #4072]
    3d9c:	f94087e2 	ldr	x2, [sp, #264]
    3da0:	f9400001 	ldr	x1, [x0]
    3da4:	eb010042 	subs	x2, x2, x1
    3da8:	d2800001 	mov	x1, #0x0                   	// #0
    3dac:	54000281 	b.ne	3dfc <fwp_heap_report+0x15c>  // b.any
    3db0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3db4:	aa1a03e6 	mov	x6, x26
    3db8:	aa1903e5 	mov	x5, x25
    3dbc:	aa1803e4 	mov	x4, x24
    3dc0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3dc4:	aa1703e3 	mov	x3, x23
    3dc8:	a95463f7 	ldp	x23, x24, [sp, #320]
    3dcc:	aa1603e0 	mov	x0, x22
    3dd0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3dd4:	1e604121 	fmov	d1, d9
    3dd8:	1e604100 	fmov	d0, d8
    3ddc:	d0000042 	adrp	x2, d000 <__modti3+0x1f0>
    3de0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3de4:	910ca042 	add	x2, x2, #0x328
    3de8:	9105c3ff 	add	sp, sp, #0x170
    3dec:	52800041 	mov	w1, #0x2                   	// #2
    3df0:	17fffa9c 	b	2860 <__fprintf_chk@plt>
    3df4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3df8:	17ffffe7 	b	3d94 <fwp_heap_report+0xf4>
    3dfc:	a91253f3 	stp	x19, x20, [sp, #288]
    3e00:	97fffa7c 	bl	27f0 <__stack_chk_fail@plt>

0000000000003e04 <fwp_heap_init>:
    3e04:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3e08:	f0000163 	adrp	x3, 32000 <fwp_heap+0xab0>
    3e0c:	91114061 	add	x1, x3, #0x450
    3e10:	910003fd 	mov	x29, sp
    3e14:	a90153f3 	stp	x19, x20, [sp, #16]
    3e18:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    3e1c:	91154262 	add	x2, x19, #0x550
    3e20:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e24:	52800024 	mov	w4, #0x1                   	// #1
    3e28:	52800200 	mov	w0, #0x10                  	// #16
    3e2c:	b913a444 	str	w4, [x2, #5028]
    3e30:	b8004420 	str	w0, [x1], #4
    3e34:	11004000 	add	w0, w0, #0x10
    3e38:	7104401f 	cmp	w0, #0x110
    3e3c:	54ffffa1 	b.ne	3e30 <fwp_heap_init+0x2c>  // b.any
    3e40:	d0000042 	adrp	x2, d000 <__modti3+0x1f0>
    3e44:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3e48:	f0000161 	adrp	x1, 32000 <fwp_heap+0xab0>
    3e4c:	91124021 	add	x1, x1, #0x490
    3e50:	3dc39843 	ldr	q3, [x2, #3680]
    3e54:	d2800000 	mov	x0, #0x0                   	// #0
    3e58:	4e040401 	dup	v1.4s, v0.s[0]
    3e5c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3e60:	0f215400 	shl	v0.2s, v0.2s, #1
    3e64:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3e68:	3ca06821 	str	q1, [x1, x0]
    3e6c:	91004000 	add	x0, x0, #0x10
    3e70:	f101801f 	cmp	x0, #0x60
    3e74:	54ffff21 	b.ne	3e58 <fwp_heap_init+0x54>  // b.any
    3e78:	f0000164 	adrp	x4, 32000 <fwp_heap+0xab0>
    3e7c:	91114063 	add	x3, x3, #0x450
    3e80:	9113c084 	add	x4, x4, #0x4f0
    3e84:	91154266 	add	x6, x19, #0x550
    3e88:	d2800002 	mov	x2, #0x0                   	// #0
    3e8c:	d2800000 	mov	x0, #0x0                   	// #0
    3e90:	d2880205 	mov	x5, #0x4010                	// #16400
    3e94:	d503201f 	nop
    3e98:	910f0001 	add	x1, x0, #0x3c0
    3e9c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3ea0:	eb02003f 	cmp	x1, x2
    3ea4:	540000a2 	b.cs	3eb8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    3ea8:	91000400 	add	x0, x0, #0x1
    3eac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3eb0:	eb02003f 	cmp	x1, x2
    3eb4:	54ffffa3 	b.cc	3ea8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    3eb8:	91004042 	add	x2, x2, #0x10
    3ebc:	38001480 	strb	w0, [x4], #1
    3ec0:	eb05005f 	cmp	x2, x5
    3ec4:	54fffea1 	b.ne	3e98 <fwp_heap_init+0x94>  // b.any
    3ec8:	528000b5 	mov	w21, #0x5                   	// #5
    3ecc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3ed0:	14000004 	b	3ee0 <fwp_heap_init+0xdc>
    3ed4:	d342fe94 	lsr	x20, x20, #2
    3ed8:	710006b5 	subs	w21, w21, #0x1
    3edc:	54000720 	b.eq	3fc0 <fwp_heap_init+0x1bc>  // b.none
    3ee0:	91404296 	add	x22, x20, #0x10, lsl #12
    3ee4:	d2800005 	mov	x5, #0x0                   	// #0
    3ee8:	aa1603e1 	mov	x1, x22
    3eec:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ef0:	52880443 	mov	w3, #0x4022                	// #16418
    3ef4:	52800002 	mov	w2, #0x0                   	// #0
    3ef8:	d2800000 	mov	x0, #0x0                   	// #0
    3efc:	97fffa61 	bl	2880 <mmap@plt>
    3f00:	aa0003e6 	mov	x6, x0
    3f04:	b100041f 	cmn	x0, #0x1
    3f08:	54fffe60 	b.eq	3ed4 <fwp_heap_init+0xd0>  // b.none
    3f0c:	b40005a0 	cbz	x0, 3fc0 <fwp_heap_init+0x1bc>
    3f10:	d350fe94 	lsr	x20, x20, #16
    3f14:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f18:	8b0000c7 	add	x7, x6, x0
    3f1c:	91154275 	add	x21, x19, #0x550
    3f20:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3f24:	8b140a81 	add	x1, x20, x20, lsl #2
    3f28:	d2800005 	mov	x5, #0x0                   	// #0
    3f2c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f30:	d37df021 	lsl	x1, x1, #3
    3f34:	52880443 	mov	w3, #0x4022                	// #16418
    3f38:	52800002 	mov	w2, #0x0                   	// #0
    3f3c:	d2800000 	mov	x0, #0x0                   	// #0
    3f40:	f909daa7 	str	x7, [x21, #5040]
    3f44:	f909dea6 	str	x6, [x21, #5048]
    3f48:	f909e2b6 	str	x22, [x21, #5056]
    3f4c:	f909eab4 	str	x20, [x21, #5072]
    3f50:	f90a02a1 	str	x1, [x21, #5120]
    3f54:	97fffa4b 	bl	2880 <mmap@plt>
    3f58:	aa0003e1 	mov	x1, x0
    3f5c:	b100041f 	cmn	x0, #0x1
    3f60:	54000300 	b.eq	3fc0 <fwp_heap_init+0x1bc>  // b.none
    3f64:	d0000040 	adrp	x0, d000 <__modti3+0x1f0>
    3f68:	910f6000 	add	x0, x0, #0x3d8
    3f6c:	f909fea1 	str	x1, [x21, #5112]
    3f70:	97fffa84 	bl	2980 <getenv@plt>
    3f74:	52800002 	mov	w2, #0x0                   	// #0
    3f78:	aa0003e1 	mov	x1, x0
    3f7c:	b40000e0 	cbz	x0, 3f98 <fwp_heap_init+0x194>
    3f80:	39400000 	ldrb	w0, [x0]
    3f84:	340000a0 	cbz	w0, 3f98 <fwp_heap_init+0x194>
    3f88:	7100c000 	subs	w0, w0, #0x30
    3f8c:	54000120 	b.eq	3fb0 <fwp_heap_init+0x1ac>  // b.none
    3f90:	7100001f 	cmp	w0, #0x0
    3f94:	1a9f07e2 	cset	w2, ne	// ne = any
    3f98:	91154273 	add	x19, x19, #0x550
    3f9c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3fa0:	b913aa62 	str	w2, [x19, #5032]
    3fa4:	a94153f3 	ldp	x19, x20, [sp, #16]
    3fa8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3fac:	d65f03c0 	ret
    3fb0:	39400420 	ldrb	w0, [x1, #1]
    3fb4:	7100001f 	cmp	w0, #0x0
    3fb8:	1a9f07e2 	cset	w2, ne	// ne = any
    3fbc:	17fffff7 	b	3f98 <fwp_heap_init+0x194>
    3fc0:	97fffbfc 	bl	2fb0 <fwp_heap_oom>

0000000000003fc4 <fwp_wake_io>:
    3fc4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3fc8:	91010122 	add	x2, x9, #0x40
    3fcc:	f9400001 	ldr	x1, [x0]
    3fd0:	5280000a 	mov	w10, #0x0                   	// #0
    3fd4:	f9401446 	ldr	x6, [x2, #40]
    3fd8:	52800008 	mov	w8, #0x0                   	// #0
    3fdc:	4f000400 	movi	v0.4s, #0x0
    3fe0:	52800027 	mov	w7, #0x1                   	// #1
    3fe4:	aa0103e2 	mov	x2, x1
    3fe8:	b4000321 	cbz	x1, 404c <fwp_wake_io+0x88>
    3fec:	f9408c25 	ldr	x5, [x1, #280]
    3ff0:	39015c27 	strb	w7, [x1, #87]
    3ff4:	b4000165 	cbz	x5, 4020 <fwp_wake_io+0x5c>
    3ff8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3ffc:	b4000364 	cbz	x4, 4068 <fwp_wake_io+0xa4>
    4000:	f9009483 	str	x3, [x4, #296]
    4004:	f9409423 	ldr	x3, [x1, #296]
    4008:	b4000043 	cbz	x3, 4010 <fwp_wake_io+0x4c>
    400c:	f9009064 	str	x4, [x3, #288]
    4010:	91080023 	add	x3, x1, #0x200
    4014:	f900943f 	str	xzr, [x1, #296]
    4018:	3c918060 	stur	q0, [x3, #-232]
    401c:	f9400001 	ldr	x1, [x0]
    4020:	f9402843 	ldr	x3, [x2, #80]
    4024:	f2001c7f 	tst	x3, #0xff000000ff
    4028:	54fffde1 	b.ne	3fe4 <fwp_wake_io+0x20>  // b.any
    402c:	39015047 	strb	w7, [x2, #84]
    4030:	f900805f 	str	xzr, [x2, #256]
    4034:	b40001e6 	cbz	x6, 4070 <fwp_wake_io+0xac>
    4038:	f90080c2 	str	x2, [x6, #256]
    403c:	aa0203e6 	mov	x6, x2
    4040:	52800028 	mov	w8, #0x1                   	// #1
    4044:	aa0103e2 	mov	x2, x1
    4048:	b5fffd21 	cbnz	x1, 3fec <fwp_wake_io+0x28>
    404c:	3400006a 	cbz	w10, 4058 <fwp_wake_io+0x94>
    4050:	91010120 	add	x0, x9, #0x40
    4054:	f900180b 	str	x11, [x0, #48]
    4058:	34000068 	cbz	w8, 4064 <fwp_wake_io+0xa0>
    405c:	91010129 	add	x9, x9, #0x40
    4060:	f9001526 	str	x6, [x9, #40]
    4064:	d65f03c0 	ret
    4068:	f90000a3 	str	x3, [x5]
    406c:	17ffffe7 	b	4008 <fwp_wake_io+0x44>
    4070:	aa0203eb 	mov	x11, x2
    4074:	5280002a 	mov	w10, #0x1                   	// #1
    4078:	17fffff1 	b	403c <fwp_wake_io+0x78>
    407c:	d503201f 	nop

0000000000004080 <fwp_tape_buffers_release>:
    4080:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4084:	910003fd 	mov	x29, sp
    4088:	a90153f3 	stp	x19, x20, [sp, #16]
    408c:	aa0003f3 	mov	x19, x0
    4090:	f9401400 	ldr	x0, [x0, #40]
    4094:	b7f80760 	tbnz	x0, #63, 4180 <fwp_tape_buffers_release+0x100>
    4098:	f9401a61 	ldr	x1, [x19, #48]
    409c:	b7f80301 	tbnz	x1, #63, 40fc <fwp_tape_buffers_release+0x7c>
    40a0:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    40a4:	eb02001f 	cmp	x0, x2
    40a8:	540002a8 	b.hi	40fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    40ac:	8b000400 	add	x0, x0, x0, lsl #1
    40b0:	d2a00102 	mov	x2, #0x80000               	// #524288
    40b4:	d37df000 	lsl	x0, x0, #3
    40b8:	cb000042 	sub	x2, x2, x0
    40bc:	eb420c3f 	cmp	x1, x2, lsr #3
    40c0:	540001e8 	b.hi	40fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    40c4:	8b010c14 	add	x20, x0, x1, lsl #3
    40c8:	b0000040 	adrp	x0, d000 <__modti3+0x1f0>
    40cc:	910fa000 	add	x0, x0, #0x3e8
    40d0:	97fffa2c 	bl	2980 <getenv@plt>
    40d4:	b4000240 	cbz	x0, 411c <fwp_tape_buffers_release+0x9c>
    40d8:	39400001 	ldrb	w1, [x0]
    40dc:	7100c03f 	cmp	w1, #0x30
    40e0:	540001e1 	b.ne	411c <fwp_tape_buffers_release+0x9c>  // b.any
    40e4:	39400400 	ldrb	w0, [x0, #1]
    40e8:	350001a0 	cbnz	w0, 411c <fwp_tape_buffers_release+0x9c>
    40ec:	aa1303e0 	mov	x0, x19
    40f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    40f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40f8:	17fffc62 	b	3280 <fwp_tape_buffers_dispose>
    40fc:	b0000040 	adrp	x0, d000 <__modti3+0x1f0>
    4100:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4104:	910fa000 	add	x0, x0, #0x3e8
    4108:	97fffa1e 	bl	2980 <getenv@plt>
    410c:	b4ffff00 	cbz	x0, 40ec <fwp_tape_buffers_release+0x6c>
    4110:	39400001 	ldrb	w1, [x0]
    4114:	7100c03f 	cmp	w1, #0x30
    4118:	54fffe60 	b.eq	40e4 <fwp_tape_buffers_release+0x64>  // b.none
    411c:	d1000681 	sub	x1, x20, #0x1
    4120:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4124:	eb00003f 	cmp	x1, x0
    4128:	54fffe28 	b.hi	40ec <fwp_tape_buffers_release+0x6c>  // b.pmore
    412c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4130:	900000f6 	adrp	x22, 20000 <__data_start>
    4134:	910102d6 	add	x22, x22, #0x40
    4138:	910122d5 	add	x21, x22, #0x48
    413c:	aa1503e0 	mov	x0, x21
    4140:	97fffc50 	bl	3280 <fwp_tape_buffers_dispose>
    4144:	ad400a61 	ldp	q1, q2, [x19]
    4148:	f90042d4 	str	x20, [x22, #128]
    414c:	4f000400 	movi	v0.4s, #0x0
    4150:	ad000aa1 	stp	q1, q2, [x21]
    4154:	3dc00a61 	ldr	q1, [x19, #32]
    4158:	3d800aa1 	str	q1, [x21, #32]
    415c:	f9401a60 	ldr	x0, [x19, #48]
    4160:	f9001aa0 	str	x0, [x21, #48]
    4164:	f9001a7f 	str	xzr, [x19, #48]
    4168:	ad000260 	stp	q0, q0, [x19]
    416c:	3d800a60 	str	q0, [x19, #32]
    4170:	a94153f3 	ldp	x19, x20, [sp, #16]
    4174:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4178:	a8c37bfd 	ldp	x29, x30, [sp], #48
    417c:	d65f03c0 	ret
    4180:	b0000040 	adrp	x0, d000 <__modti3+0x1f0>
    4184:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4188:	910fa000 	add	x0, x0, #0x3e8
    418c:	97fff9fd 	bl	2980 <getenv@plt>
    4190:	b5fffa40 	cbnz	x0, 40d8 <fwp_tape_buffers_release+0x58>
    4194:	17ffffd6 	b	40ec <fwp_tape_buffers_release+0x6c>
    4198:	d503201f 	nop
    419c:	d503201f 	nop

00000000000041a0 <fwp_poll_events>:
    41a0:	d10103ff 	sub	sp, sp, #0x40
    41a4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    41a8:	f947f400 	ldr	x0, [x0, #4072]
    41ac:	a9027bfd 	stp	x29, x30, [sp, #32]
    41b0:	910083fd 	add	x29, sp, #0x20
    41b4:	a90353f3 	stp	x19, x20, [sp, #48]
    41b8:	900000f4 	adrp	x20, 20000 <__data_start>
    41bc:	f9400001 	ldr	x1, [x0]
    41c0:	f9000fe1 	str	x1, [sp, #24]
    41c4:	d2800001 	mov	x1, #0x0                   	// #0
    41c8:	97fffd2e 	bl	3680 <fwp_now_ns>
    41cc:	91010281 	add	x1, x20, #0x40
    41d0:	f9404433 	ldr	x19, [x1, #136]
    41d4:	b4000e93 	cbz	x19, 43a4 <fwp_poll_events+0x204>
    41d8:	aa1303e1 	mov	x1, x19
    41dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    41e0:	14000005 	b	41f4 <fwp_poll_events+0x54>
    41e4:	f9408821 	ldr	x1, [x1, #272]
    41e8:	eb03005f 	cmp	x2, x3
    41ec:	9a83d042 	csel	x2, x2, x3, le
    41f0:	b40000c1 	cbz	x1, 4208 <fwp_poll_events+0x68>
    41f4:	f9403423 	ldr	x3, [x1, #104]
    41f8:	b6ffff62 	tbz	x2, #63, 41e4 <fwp_poll_events+0x44>
    41fc:	f9408821 	ldr	x1, [x1, #272]
    4200:	aa0303e2 	mov	x2, x3
    4204:	b5ffff81 	cbnz	x1, 41f4 <fwp_poll_events+0x54>
    4208:	b7f80ce2 	tbnz	x2, #63, 43a4 <fwp_poll_events+0x204>
    420c:	cb000042 	sub	x2, x2, x0
    4210:	f100005f 	cmp	x2, #0x0
    4214:	540005cd 	b.le	42cc <fwp_poll_events+0x12c>
    4218:	d2869b60 	mov	x0, #0x34db                	// #13531
    421c:	d2884801 	mov	x1, #0x4240                	// #16960
    4220:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4224:	f2a001e1 	movk	x1, #0xf, lsl #16
    4228:	f2dbd040 	movk	x0, #0xde82, lsl #32
    422c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4230:	f2e86360 	movk	x0, #0x431b, lsl #48
    4234:	9b407c40 	smulh	x0, x2, x0
    4238:	9352fc00 	asr	x0, x0, #18
    423c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4240:	9b018802 	msub	x2, x0, x1, x2
    4244:	f100005f 	cmp	x2, #0x0
    4248:	9a800400 	cinc	x0, x0, ne	// ne = any
    424c:	eb03001f 	cmp	x0, x3
    4250:	54000a0c 	b.gt	4390 <fwp_poll_events+0x1f0>
    4254:	340003c0 	cbz	w0, 42cc <fwp_poll_events+0x12c>
    4258:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    425c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4260:	72a20c42 	movk	w2, #0x1062, lsl #16
    4264:	9ba27c02 	umull	x2, w0, w2
    4268:	d366fc43 	lsr	x3, x2, #38
    426c:	aa0303e2 	mov	x2, x3
    4270:	1b048063 	msub	w3, w3, w4, w0
    4274:	9b217c63 	smull	x3, w3, w1
    4278:	d2800001 	mov	x1, #0x0                   	// #0
    427c:	910023e0 	add	x0, sp, #0x8
    4280:	a9008fe2 	stp	x2, x3, [sp, #8]
    4284:	97fff98f 	bl	28c0 <nanosleep@plt>
    4288:	91010280 	add	x0, x20, #0x40
    428c:	f9404413 	ldr	x19, [x0, #136]
    4290:	97fffcfc 	bl	3680 <fwp_now_ns>
    4294:	aa0003e6 	mov	x6, x0
    4298:	b50001f3 	cbnz	x19, 42d4 <fwp_poll_events+0x134>
    429c:	d503201f 	nop
    42a0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    42a4:	f947f400 	ldr	x0, [x0, #4072]
    42a8:	f9400fe2 	ldr	x2, [sp, #24]
    42ac:	f9400001 	ldr	x1, [x0]
    42b0:	eb010042 	subs	x2, x2, x1
    42b4:	d2800001 	mov	x1, #0x0                   	// #0
    42b8:	540008c1 	b.ne	43d0 <fwp_poll_events+0x230>  // b.any
    42bc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    42c0:	a94353f3 	ldp	x19, x20, [sp, #48]
    42c4:	910103ff 	add	sp, sp, #0x40
    42c8:	d65f03c0 	ret
    42cc:	97fffced 	bl	3680 <fwp_now_ns>
    42d0:	aa0003e6 	mov	x6, x0
    42d4:	4f000400 	movi	v0.4s, #0x0
    42d8:	91010288 	add	x8, x20, #0x40
    42dc:	52800027 	mov	w7, #0x1                   	// #1
    42e0:	f9403661 	ldr	x1, [x19, #104]
    42e4:	aa1303e5 	mov	x5, x19
    42e8:	f9408a73 	ldr	x19, [x19, #272]
    42ec:	eb06003f 	cmp	x1, x6
    42f0:	5400032c 	b.gt	4354 <fwp_poll_events+0x1b4>
    42f4:	394154a0 	ldrb	w0, [x5, #85]
    42f8:	36000120 	tbz	w0, #0, 431c <fwp_poll_events+0x17c>
    42fc:	f94084a0 	ldr	x0, [x5, #264]
    4300:	b40003c0 	cbz	x0, 4378 <fwp_poll_events+0x1d8>
    4304:	f9008813 	str	x19, [x0, #272]
    4308:	b4000053 	cbz	x19, 4310 <fwp_poll_events+0x170>
    430c:	f9008660 	str	x0, [x19, #264]
    4310:	910800a0 	add	x0, x5, #0x200
    4314:	390154bf 	strb	wzr, [x5, #85]
    4318:	3c908000 	stur	q0, [x0, #-248]
    431c:	f94030a0 	ldr	x0, [x5, #96]
    4320:	390158a7 	strb	w7, [x5, #86]
    4324:	f100001f 	cmp	x0, #0x0
    4328:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    432c:	5400018d 	b.le	435c <fwp_poll_events+0x1bc>
    4330:	f94028a0 	ldr	x0, [x5, #80]
    4334:	f2001c1f 	tst	x0, #0xff000000ff
    4338:	540000e1 	b.ne	4354 <fwp_poll_events+0x1b4>  // b.any
    433c:	f9401500 	ldr	x0, [x8, #40]
    4340:	390150a7 	strb	w7, [x5, #84]
    4344:	f90080bf 	str	xzr, [x5, #256]
    4348:	b40001e0 	cbz	x0, 4384 <fwp_poll_events+0x1e4>
    434c:	f9001505 	str	x5, [x8, #40]
    4350:	f9008005 	str	x5, [x0, #256]
    4354:	b5fffc73 	cbnz	x19, 42e0 <fwp_poll_events+0x140>
    4358:	17ffffd2 	b	42a0 <fwp_poll_events+0x100>
    435c:	394144a0 	ldrb	w0, [x5, #81]
    4360:	3707fe80 	tbnz	w0, #0, 4330 <fwp_poll_events+0x190>
    4364:	394140a0 	ldrb	w0, [x5, #80]
    4368:	3707fe40 	tbnz	w0, #0, 4330 <fwp_poll_events+0x190>
    436c:	aa0503e0 	mov	x0, x5
    4370:	97fffc20 	bl	33f0 <fwp_cancel_tree.part.0>
    4374:	17ffffef 	b	4330 <fwp_poll_events+0x190>
    4378:	91010281 	add	x1, x20, #0x40
    437c:	f9004433 	str	x19, [x1, #136]
    4380:	17ffffe2 	b	4308 <fwp_poll_events+0x168>
    4384:	f9001505 	str	x5, [x8, #40]
    4388:	f9001905 	str	x5, [x8, #48]
    438c:	17fffff2 	b	4354 <fwp_poll_events+0x1b4>
    4390:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4394:	d2989362 	mov	x2, #0xc49b                	// #50331
    4398:	f2a4d203 	movk	x3, #0x2690, lsl #16
    439c:	f2a00402 	movk	x2, #0x20, lsl #16
    43a0:	17ffffb6 	b	4278 <fwp_poll_events+0xd8>
    43a4:	97fffaf3 	bl	2f70 <fwp_flush>
    43a8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    43ac:	f947e863 	ldr	x3, [x3, #4048]
    43b0:	d2800562 	mov	x2, #0x2b                  	// #43
    43b4:	d2800021 	mov	x1, #0x1                   	// #1
    43b8:	b0000040 	adrp	x0, d000 <__modti3+0x1f0>
    43bc:	91100000 	add	x0, x0, #0x400
    43c0:	f9400063 	ldr	x3, [x3]
    43c4:	97fff94b 	bl	28f0 <fwrite@plt>
    43c8:	52800ca0 	mov	w0, #0x65                  	// #101
    43cc:	97fff8b5 	bl	26a0 <exit@plt>
    43d0:	97fff908 	bl	27f0 <__stack_chk_fail@plt>

00000000000043d4 <fwp_rc_wide_dup>:
    43d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43d8:	910003fd 	mov	x29, sp
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	aa0003f3 	mov	x19, x0
    43e4:	ca404400 	eor	x0, x0, x0, lsr #17
    43e8:	f90013f5 	str	x21, [sp, #32]
    43ec:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    43f0:	ca402400 	eor	x0, x0, x0, lsr #9
    43f4:	911542a2 	add	x2, x21, #0x550
    43f8:	92401c00 	and	x0, x0, #0xff
    43fc:	910a2403 	add	x3, x0, #0x289
    4400:	8b000c40 	add	x0, x2, x0, lsl #3
    4404:	8b030c54 	add	x20, x2, x3, lsl #3
    4408:	f94a2401 	ldr	x1, [x0, #5192]
    440c:	b50000a1 	cbnz	x1, 4420 <fwp_rc_wide_dup+0x4c>
    4410:	1400002d 	b	44c4 <fwp_rc_wide_dup+0xf0>
    4414:	91004034 	add	x20, x1, #0x10
    4418:	f9400821 	ldr	x1, [x1, #16]
    441c:	b4000241 	cbz	x1, 4464 <fwp_rc_wide_dup+0x90>
    4420:	f9400022 	ldr	x2, [x1]
    4424:	eb02027f 	cmp	x19, x2
    4428:	54ffff61 	b.ne	4414 <fwp_rc_wide_dup+0x40>  // b.any
    442c:	f9400281 	ldr	x1, [x20]
    4430:	39400260 	ldrb	w0, [x19]
    4434:	7103f81f 	cmp	w0, #0xfe
    4438:	54000220 	b.eq	447c <fwp_rc_wide_dup+0xa8>  // b.none
    443c:	b40001a1 	cbz	x1, 4470 <fwp_rc_wide_dup+0x9c>
    4440:	f9400420 	ldr	x0, [x1, #8]
    4444:	b100041f 	cmn	x0, #0x1
    4448:	540004a0 	b.eq	44dc <fwp_rc_wide_dup+0x108>  // b.none
    444c:	91000400 	add	x0, x0, #0x1
    4450:	f9000420 	str	x0, [x1, #8]
    4454:	a94153f3 	ldp	x19, x20, [sp, #16]
    4458:	f94013f5 	ldr	x21, [sp, #32]
    445c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4460:	d65f03c0 	ret
    4464:	39400260 	ldrb	w0, [x19]
    4468:	7103f81f 	cmp	w0, #0xfe
    446c:	540000a0 	b.eq	4480 <fwp_rc_wide_dup+0xac>  // b.none
    4470:	b0000040 	adrp	x0, d000 <__modti3+0x1f0>
    4474:	91116000 	add	x0, x0, #0x458
    4478:	97fffc22 	bl	3500 <fwp_trap>
    447c:	b5000281 	cbnz	x1, 44cc <fwp_rc_wide_dup+0xf8>
    4480:	d2800300 	mov	x0, #0x18                  	// #24
    4484:	97fff8c3 	bl	2790 <malloc@plt>
    4488:	b4000280 	cbz	x0, 44d8 <fwp_rc_wide_dup+0x104>
    448c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4490:	a9000413 	stp	x19, x1, [x0]
    4494:	911542b5 	add	x21, x21, #0x550
    4498:	f900081f 	str	xzr, [x0, #16]
    449c:	12800001 	mov	w1, #0xffffffff            	// #-1
    44a0:	f9000280 	str	x0, [x20]
    44a4:	39000261 	strb	w1, [x19]
    44a8:	f94e26a0 	ldr	x0, [x21, #7240]
    44ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    44b0:	91000400 	add	x0, x0, #0x1
    44b4:	f90e26a0 	str	x0, [x21, #7240]
    44b8:	f94013f5 	ldr	x21, [sp, #32]
    44bc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44c0:	d65f03c0 	ret
    44c4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    44c8:	17ffffda 	b	4430 <fwp_rc_wide_dup+0x5c>
    44cc:	b0000040 	adrp	x0, d000 <__modti3+0x1f0>
    44d0:	9110c000 	add	x0, x0, #0x430
    44d4:	97fffc0b 	bl	3500 <fwp_trap>
    44d8:	97fffab6 	bl	2fb0 <fwp_heap_oom>
    44dc:	b0000040 	adrp	x0, d000 <__modti3+0x1f0>
    44e0:	91120000 	add	x0, x0, #0x480
    44e4:	97fffc07 	bl	3500 <fwp_trap>
    44e8:	d503201f 	nop
    44ec:	d503201f 	nop

00000000000044f0 <fwp_rc_forget_slot>:
    44f0:	aa0003e1 	mov	x1, x0
    44f4:	39400000 	ldrb	w0, [x0]
    44f8:	7103fc1f 	cmp	w0, #0xff
    44fc:	54000040 	b.eq	4504 <fwp_rc_forget_slot+0x14>  // b.none
    4500:	d65f03c0 	ret
    4504:	ca414420 	eor	x0, x1, x1, lsr #17
    4508:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    450c:	ca402400 	eor	x0, x0, x0, lsr #9
    4510:	910003fd 	mov	x29, sp
    4514:	92401c00 	and	x0, x0, #0xff
    4518:	f9000bf3 	str	x19, [sp, #16]
    451c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    4520:	91154262 	add	x2, x19, #0x550
    4524:	910a2403 	add	x3, x0, #0x289
    4528:	8b000c40 	add	x0, x2, x0, lsl #3
    452c:	8b030c43 	add	x3, x2, x3, lsl #3
    4530:	f94a2400 	ldr	x0, [x0, #5192]
    4534:	b50000a0 	cbnz	x0, 4548 <fwp_rc_forget_slot+0x58>
    4538:	14000011 	b	457c <fwp_rc_forget_slot+0x8c>
    453c:	91004003 	add	x3, x0, #0x10
    4540:	f9400800 	ldr	x0, [x0, #16]
    4544:	b40001c0 	cbz	x0, 457c <fwp_rc_forget_slot+0x8c>
    4548:	f9400002 	ldr	x2, [x0]
    454c:	eb02003f 	cmp	x1, x2
    4550:	54ffff61 	b.ne	453c <fwp_rc_forget_slot+0x4c>  // b.any
    4554:	f9400801 	ldr	x1, [x0, #16]
    4558:	91154273 	add	x19, x19, #0x550
    455c:	f9000061 	str	x1, [x3]
    4560:	97fff8d4 	bl	28b0 <free@plt>
    4564:	f94e2660 	ldr	x0, [x19, #7240]
    4568:	d1000400 	sub	x0, x0, #0x1
    456c:	f90e2660 	str	x0, [x19, #7240]
    4570:	f9400bf3 	ldr	x19, [sp, #16]
    4574:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4578:	d65f03c0 	ret
    457c:	b0000040 	adrp	x0, d000 <__modti3+0x1f0>
    4580:	91116000 	add	x0, x0, #0x458
    4584:	97fffbdf 	bl	3500 <fwp_trap>
    4588:	d503201f 	nop
    458c:	d503201f 	nop

0000000000004590 <fwp_rc_prepare_chunk>:
    4590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4594:	910003fd 	mov	x29, sp
    4598:	a9025bf5 	stp	x21, x22, [sp, #32]
    459c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc90>
    45a0:	911542c2 	add	x2, x22, #0x550
    45a4:	b9401c03 	ldr	w3, [x0, #28]
    45a8:	aa0103f5 	mov	x21, x1
    45ac:	a90153f3 	stp	x19, x20, [sp, #16]
    45b0:	aa0003f4 	mov	x20, x0
    45b4:	f94e2440 	ldr	x0, [x2, #7240]
    45b8:	b4000440 	cbz	x0, 4640 <fwp_rc_prepare_chunk+0xb0>
    45bc:	d2800013 	mov	x19, #0x0                   	// #0
    45c0:	35000203 	cbnz	w3, 4600 <fwp_rc_prepare_chunk+0x70>
    45c4:	b4000361 	cbz	x1, 4630 <fwp_rc_prepare_chunk+0xa0>
    45c8:	f9401280 	ldr	x0, [x20, #32]
    45cc:	97fff8b9 	bl	28b0 <free@plt>
    45d0:	aa1503e0 	mov	x0, x21
    45d4:	d2800021 	mov	x1, #0x1                   	// #1
    45d8:	97fff87e 	bl	27d0 <calloc@plt>
    45dc:	f9001280 	str	x0, [x20, #32]
    45e0:	b5000460 	cbnz	x0, 466c <fwp_rc_prepare_chunk+0xdc>
    45e4:	97fffa73 	bl	2fb0 <fwp_heap_oom>
    45e8:	97ffffc2 	bl	44f0 <fwp_rc_forget_slot>
    45ec:	91000673 	add	x19, x19, #0x1
    45f0:	b9401e83 	ldr	w3, [x20, #28]
    45f4:	eb13007f 	cmp	x3, x19
    45f8:	54000169 	b.ls	4624 <fwp_rc_prepare_chunk+0x94>  // b.plast
    45fc:	d503201f 	nop
    4600:	f9401283 	ldr	x3, [x20, #32]
    4604:	8b130060 	add	x0, x3, x19
    4608:	38736863 	ldrb	w3, [x3, x19]
    460c:	7103fc7f 	cmp	w3, #0xff
    4610:	54fffec0 	b.eq	45e8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4614:	b9401e83 	ldr	w3, [x20, #28]
    4618:	91000673 	add	x19, x19, #0x1
    461c:	eb13007f 	cmp	x3, x19
    4620:	54ffff08 	b.hi	4600 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4624:	eb0302bf 	cmp	x21, x3
    4628:	54000121 	b.ne	464c <fwp_rc_prepare_chunk+0xbc>  // b.any
    462c:	b5000335 	cbnz	x21, 4690 <fwp_rc_prepare_chunk+0x100>
    4630:	a94153f3 	ldp	x19, x20, [sp, #16]
    4634:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4638:	a8c37bfd 	ldp	x29, x30, [sp], #48
    463c:	d65f03c0 	ret
    4640:	2a0303e3 	mov	w3, w3
    4644:	eb0302bf 	cmp	x21, x3
    4648:	54ffff20 	b.eq	462c <fwp_rc_prepare_chunk+0x9c>  // b.none
    464c:	911542c2 	add	x2, x22, #0x550
    4650:	f9401280 	ldr	x0, [x20, #32]
    4654:	f94e2841 	ldr	x1, [x2, #7248]
    4658:	cb030021 	sub	x1, x1, x3
    465c:	f90e2841 	str	x1, [x2, #7248]
    4660:	97fff894 	bl	28b0 <free@plt>
    4664:	b5fffb75 	cbnz	x21, 45d0 <fwp_rc_prepare_chunk+0x40>
    4668:	f900129f 	str	xzr, [x20, #32]
    466c:	911542d6 	add	x22, x22, #0x550
    4670:	f94e2ac0 	ldr	x0, [x22, #7248]
    4674:	b9001e95 	str	w21, [x20, #28]
    4678:	a94153f3 	ldp	x19, x20, [sp, #16]
    467c:	8b150000 	add	x0, x0, x21
    4680:	f90e2ac0 	str	x0, [x22, #7248]
    4684:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4688:	a8c37bfd 	ldp	x29, x30, [sp], #48
    468c:	d65f03c0 	ret
    4690:	f9401280 	ldr	x0, [x20, #32]
    4694:	aa1503e2 	mov	x2, x21
    4698:	a94153f3 	ldp	x19, x20, [sp, #16]
    469c:	52800001 	mov	w1, #0x0                   	// #0
    46a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46a8:	17fff846 	b	27c0 <memset@plt>
    46ac:	d503201f 	nop

00000000000046b0 <fwp_heap_refill>:
    46b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    46b4:	910003fd 	mov	x29, sp
    46b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    46bc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    46c0:	911542b5 	add	x21, x21, #0x550
    46c4:	aa0003f6 	mov	x22, x0
    46c8:	d2800020 	mov	x0, #0x1                   	// #1
    46cc:	a90153f3 	stp	x19, x20, [sp, #16]
    46d0:	a90363f7 	stp	x23, x24, [sp, #48]
    46d4:	2a0103f7 	mov	w23, w1
    46d8:	2a0203f8 	mov	w24, w2
    46dc:	97fffa75 	bl	30b0 <fwp_heap_chunks>
    46e0:	aa0003f3 	mov	x19, x0
    46e4:	f949fea2 	ldr	x2, [x21, #5112]
    46e8:	8b000800 	add	x0, x0, x0, lsl #2
    46ec:	2a1703e1 	mov	w1, w23
    46f0:	52800025 	mov	w5, #0x1                   	// #1
    46f4:	d37df000 	lsl	x0, x0, #3
    46f8:	910f0021 	add	x1, x1, #0x3c0
    46fc:	8b000054 	add	x20, x2, x0
    4700:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4704:	52a00024 	mov	w4, #0x10000               	// #65536
    4708:	38206845 	strb	w5, [x2, x0]
    470c:	aa1403e0 	mov	x0, x20
    4710:	39000698 	strb	w24, [x20, #1]
    4714:	39000a97 	strb	w23, [x20, #2]
    4718:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    471c:	b9000681 	str	w1, [x20, #4]
    4720:	2a0103e5 	mov	w5, w1
    4724:	8b0300a2 	add	x2, x5, x3
    4728:	1ac10881 	udiv	w1, w4, w1
    472c:	9ac50842 	udiv	x2, x2, x5
    4730:	b9000a81 	str	w1, [x20, #8]
    4734:	92404021 	and	x1, x1, #0x1ffff
    4738:	b9001a82 	str	w2, [x20, #24]
    473c:	97ffff95 	bl	4590 <fwp_rc_prepare_chunk>
    4740:	f949daa0 	ldr	x0, [x21, #5040]
    4744:	29408a81 	ldp	w1, w2, [x20, #4]
    4748:	8b134000 	add	x0, x0, x19, lsl #16
    474c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4750:	8b214003 	add	x3, x0, w1, uxtw
    4754:	9ba20021 	umaddl	x1, w1, w2, x0
    4758:	a94363f7 	ldp	x23, x24, [sp, #48]
    475c:	a90086c3 	stp	x3, x1, [x22, #8]
    4760:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4764:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4768:	d65f03c0 	ret
    476c:	d503201f 	nop

0000000000004770 <fwp_mem_free>:
    4770:	b40003c0 	cbz	x0, 47e8 <fwp_mem_free+0x78>
    4774:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4778:	910003fd 	mov	x29, sp
    477c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4780:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    4784:	911542a1 	add	x1, x21, #0x550
    4788:	a90153f3 	stp	x19, x20, [sp, #16]
    478c:	aa0003f3 	mov	x19, x0
    4790:	f949d823 	ldr	x3, [x1, #5040]
    4794:	f949ec22 	ldr	x2, [x1, #5080]
    4798:	cb030000 	sub	x0, x0, x3
    479c:	eb02401f 	cmp	x0, x2, lsl #16
    47a0:	540001c2 	b.cs	47d8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    47a4:	d350fc16 	lsr	x22, x0, #16
    47a8:	a90363f7 	stp	x23, x24, [sp, #48]
    47ac:	f949fc22 	ldr	x2, [x1, #5112]
    47b0:	8b160ad4 	add	x20, x22, x22, lsl #2
    47b4:	d37df294 	lsl	x20, x20, #3
    47b8:	ab140057 	adds	x23, x2, x20
    47bc:	540000c0 	b.eq	47d4 <fwp_mem_free+0x64>  // b.none
    47c0:	38746842 	ldrb	w2, [x2, x20]
    47c4:	7100045f 	cmp	w2, #0x1
    47c8:	54000120 	b.eq	47ec <fwp_mem_free+0x7c>  // b.none
    47cc:	7100085f 	cmp	w2, #0x2
    47d0:	540005e0 	b.eq	488c <fwp_mem_free+0x11c>  // b.none
    47d4:	a94363f7 	ldp	x23, x24, [sp, #48]
    47d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    47dc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47e0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    47e4:	d65f03c0 	ret
    47e8:	d65f03c0 	ret
    47ec:	f94012f8 	ldr	x24, [x23, #32]
    47f0:	b94006e1 	ldr	w1, [x23, #4]
    47f4:	f90023f9 	str	x25, [sp, #64]
    47f8:	2a0103e2 	mov	w2, w1
    47fc:	394006f9 	ldrb	w25, [x23, #1]
    4800:	39400af4 	ldrb	w20, [x23, #2]
    4804:	b4000158 	cbz	x24, 482c <fwp_mem_free+0xbc>
    4808:	92403e76 	and	x22, x19, #0xffff
    480c:	9ac20ad6 	udiv	x22, x22, x2
    4810:	38766b01 	ldrb	w1, [x24, x22]
    4814:	8b160300 	add	x0, x24, x22
    4818:	7103fc3f 	cmp	w1, #0xff
    481c:	54000980 	b.eq	494c <fwp_mem_free+0x1dc>  // b.none
    4820:	38366b1f 	strb	wzr, [x24, x22]
    4824:	b94006e1 	ldr	w1, [x23, #4]
    4828:	2a0103e2 	mov	w2, w1
    482c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4830:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4834:	cb390000 	sub	x0, x0, w25, uxtb
    4838:	8b340074 	add	x20, x3, w20, uxtb
    483c:	911542b5 	add	x21, x21, #0x550
    4840:	1e630021 	ucvtf	d1, w1
    4844:	d37ae400 	lsl	x0, x0, #6
    4848:	8b140c14 	add	x20, x0, x20, lsl #3
    484c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4850:	f8746aa0 	ldr	x0, [x21, x20]
    4854:	f94023f9 	ldr	x25, [sp, #64]
    4858:	aa2003e0 	mvn	x0, x0
    485c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4860:	f9000260 	str	x0, [x19]
    4864:	f8346ab3 	str	x19, [x21, x20]
    4868:	f94a12a0 	ldr	x0, [x21, #5152]
    486c:	1e612800 	fadd	d0, d0, d1
    4870:	a94153f3 	ldp	x19, x20, [sp, #16]
    4874:	cb020000 	sub	x0, x0, x2
    4878:	f90a12a0 	str	x0, [x21, #5152]
    487c:	fd0a22a0 	str	d0, [x21, #5184]
    4880:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4884:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4888:	d65f03c0 	ret
    488c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4890:	8b000063 	add	x3, x3, x0
    4894:	eb03027f 	cmp	x19, x3
    4898:	54fff9e1 	b.ne	47d4 <fwp_mem_free+0x64>  // b.any
    489c:	fd400ae1 	ldr	d1, [x23, #16]
    48a0:	fd4a2020 	ldr	d0, [x1, #5184]
    48a4:	f9400ae0 	ldr	x0, [x23, #16]
    48a8:	7e61d821 	ucvtf	d1, d1
    48ac:	f94a1022 	ldr	x2, [x1, #5152]
    48b0:	f94012f3 	ldr	x19, [x23, #32]
    48b4:	1e612800 	fadd	d0, d0, d1
    48b8:	cb000042 	sub	x2, x2, x0
    48bc:	f90a1022 	str	x2, [x1, #5152]
    48c0:	fd0a2020 	str	d0, [x1, #5184]
    48c4:	b40000b3 	cbz	x19, 48d8 <fwp_mem_free+0x168>
    48c8:	39400260 	ldrb	w0, [x19]
    48cc:	7103fc1f 	cmp	w0, #0xff
    48d0:	54000380 	b.eq	4940 <fwp_mem_free+0x1d0>  // b.none
    48d4:	3900027f 	strb	wzr, [x19]
    48d8:	b9400ee2 	ldr	w2, [x23, #12]
    48dc:	b4000142 	cbz	x2, 4904 <fwp_mem_free+0x194>
    48e0:	911542a1 	add	x1, x21, #0x550
    48e4:	8b160040 	add	x0, x2, x22
    48e8:	8b000800 	add	x0, x0, x0, lsl #2
    48ec:	f949fc21 	ldr	x1, [x1, #5112]
    48f0:	8b140034 	add	x20, x1, x20
    48f4:	8b000c20 	add	x0, x1, x0, lsl #3
    48f8:	3802869f 	strb	wzr, [x20], #40
    48fc:	eb00029f 	cmp	x20, x0
    4900:	54ffffc1 	b.ne	48f8 <fwp_mem_free+0x188>  // b.any
    4904:	911542a0 	add	x0, x21, #0x550
    4908:	f94a1801 	ldr	x1, [x0, #5168]
    490c:	f949f803 	ldr	x3, [x0, #5104]
    4910:	8b020021 	add	x1, x1, x2
    4914:	f90a1801 	str	x1, [x0, #5168]
    4918:	eb16007f 	cmp	x3, x22
    491c:	54000049 	b.ls	4924 <fwp_mem_free+0x1b4>  // b.plast
    4920:	f909f816 	str	x22, [x0, #5104]
    4924:	911542b5 	add	x21, x21, #0x550
    4928:	f949f6a0 	ldr	x0, [x21, #5096]
    492c:	eb16001f 	cmp	x0, x22
    4930:	54fff529 	b.ls	47d4 <fwp_mem_free+0x64>  // b.plast
    4934:	a94363f7 	ldp	x23, x24, [sp, #48]
    4938:	f909f6b6 	str	x22, [x21, #5096]
    493c:	17ffffa7 	b	47d8 <fwp_mem_free+0x68>
    4940:	aa1303e0 	mov	x0, x19
    4944:	97fffeeb 	bl	44f0 <fwp_rc_forget_slot>
    4948:	17ffffe3 	b	48d4 <fwp_mem_free+0x164>
    494c:	97fffee9 	bl	44f0 <fwp_rc_forget_slot>
    4950:	17ffffb4 	b	4820 <fwp_mem_free+0xb0>

0000000000004954 <fwp_heap_alloc_big>:
    4954:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4958:	910003fd 	mov	x29, sp
    495c:	a90153f3 	stp	x19, x20, [sp, #16]
    4960:	a9025bf5 	stp	x21, x22, [sp, #32]
    4964:	a90363f7 	stp	x23, x24, [sp, #48]
    4968:	aa0003f7 	mov	x23, x0
    496c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4970:	a9046bf9 	stp	x25, x26, [sp, #64]
    4974:	eb0002ff 	cmp	x23, x0
    4978:	54000888 	b.hi	4a88 <fwp_heap_alloc_big+0x134>  // b.pmore
    497c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4980:	8b0002f4 	add	x20, x23, x0
    4984:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc90>
    4988:	91154359 	add	x25, x26, #0x550
    498c:	d350fe94 	lsr	x20, x20, #16
    4990:	2a0103f5 	mov	w21, w1
    4994:	aa1403e0 	mov	x0, x20
    4998:	97fff9c6 	bl	30b0 <fwp_heap_chunks>
    499c:	f949ff22 	ldr	x2, [x25, #5112]
    49a0:	8b000813 	add	x19, x0, x0, lsl #2
    49a4:	aa0003f8 	mov	x24, x0
    49a8:	52800043 	mov	w3, #0x2                   	// #2
    49ac:	d37df273 	lsl	x19, x19, #3
    49b0:	d2800021 	mov	x1, #0x1                   	// #1
    49b4:	8b130040 	add	x0, x2, x19
    49b8:	38336843 	strb	w3, [x2, x19]
    49bc:	39000415 	strb	w21, [x0, #1]
    49c0:	b9000c14 	str	w20, [x0, #12]
    49c4:	f9000817 	str	x23, [x0, #16]
    49c8:	97fffef2 	bl	4590 <fwp_rc_prepare_chunk>
    49cc:	f100069f 	cmp	x20, #0x1
    49d0:	54000269 	b.ls	4a1c <fwp_heap_alloc_big+0xc8>  // b.plast
    49d4:	8b180294 	add	x20, x20, x24
    49d8:	9100a273 	add	x19, x19, #0x28
    49dc:	a90573fb 	stp	x27, x28, [sp, #80]
    49e0:	5280007b 	mov	w27, #0x3                   	// #3
    49e4:	8b140a94 	add	x20, x20, x20, lsl #2
    49e8:	2a1803fc 	mov	w28, w24
    49ec:	9adb2296 	lsl	x22, x20, x27
    49f0:	f949ff35 	ldr	x21, [x25, #5112]
    49f4:	d2800001 	mov	x1, #0x0                   	// #0
    49f8:	8b1302b4 	add	x20, x21, x19
    49fc:	aa1403e0 	mov	x0, x20
    4a00:	97fffee4 	bl	4590 <fwp_rc_prepare_chunk>
    4a04:	38336abb 	strb	w27, [x21, x19]
    4a08:	9100a273 	add	x19, x19, #0x28
    4a0c:	b9000e9c 	str	w28, [x20, #12]
    4a10:	eb1302df 	cmp	x22, x19
    4a14:	54fffee1 	b.ne	49f0 <fwp_heap_alloc_big+0x9c>  // b.any
    4a18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a1c:	91154353 	add	x19, x26, #0x550
    4a20:	aa1703e2 	mov	x2, x23
    4a24:	52800001 	mov	w1, #0x0                   	// #0
    4a28:	f949da60 	ldr	x0, [x19, #5040]
    4a2c:	8b184018 	add	x24, x0, x24, lsl #16
    4a30:	aa1803e0 	mov	x0, x24
    4a34:	97fff763 	bl	27c0 <memset@plt>
    4a38:	f94a1260 	ldr	x0, [x19, #5152]
    4a3c:	ab170000 	adds	x0, x0, x23
    4a40:	54000242 	b.cs	4a88 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4a44:	f94a1661 	ldr	x1, [x19, #5160]
    4a48:	f90a1260 	str	x0, [x19, #5152]
    4a4c:	eb01001f 	cmp	x0, x1
    4a50:	54000049 	b.ls	4a58 <fwp_heap_alloc_big+0x104>  // b.plast
    4a54:	f90a1660 	str	x0, [x19, #5160]
    4a58:	9115435a 	add	x26, x26, #0x550
    4a5c:	9e6202e0 	scvtf	d0, x23
    4a60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a64:	aa1803e0 	mov	x0, x24
    4a68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4a6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a70:	1e602820 	fadd	d0, d1, d0
    4a74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a78:	fd0a1f40 	str	d0, [x26, #5176]
    4a7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4a80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4a84:	d65f03c0 	ret
    4a88:	a90573fb 	stp	x27, x28, [sp, #80]
    4a8c:	97fff949 	bl	2fb0 <fwp_heap_oom>

0000000000004a90 <fwp_heap_alloc_slow>:
    4a90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a94:	910003fd 	mov	x29, sp
    4a98:	a90153f3 	stp	x19, x20, [sp, #16]
    4a9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    4aa0:	91154262 	add	x2, x19, #0x550
    4aa4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4aa8:	aa0003f5 	mov	x21, x0
    4aac:	2a0103f4 	mov	w20, w1
    4ab0:	b953a440 	ldr	w0, [x2, #5028]
    4ab4:	34000600 	cbz	w0, 4b74 <fwp_heap_alloc_slow+0xe4>
    4ab8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4abc:	54000628 	b.hi	4b80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4ac0:	91003ea0 	add	x0, x21, #0xf
    4ac4:	91154262 	add	x2, x19, #0x550
    4ac8:	f9001bf7 	str	x23, [sp, #48]
    4acc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ad0:	8b401040 	add	x0, x2, x0, lsr #4
    4ad4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ad8:	d37ae484 	lsl	x4, x4, #6
    4adc:	397e8003 	ldrb	w3, [x0, #4000]
    4ae0:	910f0060 	add	x0, x3, #0x3c0
    4ae4:	aa0303e1 	mov	x1, x3
    4ae8:	8b030463 	add	x3, x3, x3, lsl #1
    4aec:	8b030c83 	add	x3, x4, x3, lsl #3
    4af0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4af4:	2a1703f6 	mov	w22, w23
    4af8:	f8636844 	ldr	x4, [x2, x3]
    4afc:	b40004e4 	cbz	x4, 4b98 <fwp_heap_alloc_slow+0x108>
    4b00:	f9400080 	ldr	x0, [x4]
    4b04:	aa2003e0 	mvn	x0, x0
    4b08:	f8236840 	str	x0, [x2, x3]
    4b0c:	7100069f 	cmp	w20, #0x1
    4b10:	aa0403e0 	mov	x0, x4
    4b14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b18:	52800001 	mov	w1, #0x0                   	// #0
    4b1c:	97fff729 	bl	27c0 <memset@plt>
    4b20:	aa0003e4 	mov	x4, x0
    4b24:	91154260 	add	x0, x19, #0x550
    4b28:	f94a1001 	ldr	x1, [x0, #5152]
    4b2c:	ab160021 	adds	x1, x1, x22
    4b30:	540005c2 	b.cs	4be8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4b34:	f94a1402 	ldr	x2, [x0, #5160]
    4b38:	f90a1001 	str	x1, [x0, #5152]
    4b3c:	eb02003f 	cmp	x1, x2
    4b40:	54000049 	b.ls	4b48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4b44:	f90a1401 	str	x1, [x0, #5160]
    4b48:	91154273 	add	x19, x19, #0x550
    4b4c:	1e6302e1 	ucvtf	d1, w23
    4b50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b54:	aa0403e0 	mov	x0, x4
    4b58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4b5c:	f9401bf7 	ldr	x23, [sp, #48]
    4b60:	1e612800 	fadd	d0, d0, d1
    4b64:	fd0a1e60 	str	d0, [x19, #5176]
    4b68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b70:	d65f03c0 	ret
    4b74:	97fffca4 	bl	3e04 <fwp_heap_init>
    4b78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b7c:	54fffa29 	b.ls	4ac0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4b80:	2a1403e1 	mov	w1, w20
    4b84:	aa1503e0 	mov	x0, x21
    4b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b94:	17ffff70 	b	4954 <fwp_heap_alloc_big>
    4b98:	8b030042 	add	x2, x2, x3
    4b9c:	f9400444 	ldr	x4, [x2, #8]
    4ba0:	b4000104 	cbz	x4, 4bc0 <fwp_heap_alloc_slow+0x130>
    4ba4:	f9400840 	ldr	x0, [x2, #16]
    4ba8:	cb040000 	sub	x0, x0, x4
    4bac:	eb16001f 	cmp	x0, x22
    4bb0:	54000083 	b.cc	4bc0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4bb4:	8b160080 	add	x0, x4, x22
    4bb8:	f9000440 	str	x0, [x2, #8]
    4bbc:	17ffffd4 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4bc0:	52800302 	mov	w2, #0x18                  	// #24
    4bc4:	52807804 	mov	w4, #0x3c0                 	// #960
    4bc8:	91154260 	add	x0, x19, #0x550
    4bcc:	9ba27c23 	umull	x3, w1, w2
    4bd0:	2a1403e2 	mov	w2, w20
    4bd4:	9b240e84 	smaddl	x4, w20, w4, x3
    4bd8:	8b040000 	add	x0, x0, x4
    4bdc:	97fffeb5 	bl	46b0 <fwp_heap_refill>
    4be0:	aa0003e4 	mov	x4, x0
    4be4:	17ffffca 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4be8:	97fff8f2 	bl	2fb0 <fwp_heap_oom>
    4bec:	d503201f 	nop

0000000000004bf0 <fwp_heap_alloc>:
    4bf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4bf4:	f140101f 	cmp	x0, #0x4, lsl #12
    4bf8:	910003fd 	mov	x29, sp
    4bfc:	a90153f3 	stp	x19, x20, [sp, #16]
    4c00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc90>
    4c04:	91154293 	add	x19, x20, #0x550
    4c08:	b953a662 	ldr	w2, [x19, #5028]
    4c0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c10:	54000640 	b.eq	4cd8 <fwp_heap_alloc+0xe8>  // b.none
    4c14:	91003c03 	add	x3, x0, #0xf
    4c18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4c20:	8b431263 	add	x3, x19, x3, lsr #4
    4c24:	cb21c042 	sub	x2, x2, w1, sxtw
    4c28:	d37ae442 	lsl	x2, x2, #6
    4c2c:	397e8063 	ldrb	w3, [x3, #4000]
    4c30:	910f0064 	add	x4, x3, #0x3c0
    4c34:	8b030463 	add	x3, x3, x3, lsl #1
    4c38:	8b030c43 	add	x3, x2, x3, lsl #3
    4c3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4c40:	2a1603f5 	mov	w21, w22
    4c44:	f8636a64 	ldr	x4, [x19, x3]
    4c48:	b4000384 	cbz	x4, 4cb8 <fwp_heap_alloc+0xc8>
    4c4c:	f9400085 	ldr	x5, [x4]
    4c50:	7100043f 	cmp	w1, #0x1
    4c54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4c58:	aa0403e0 	mov	x0, x4
    4c5c:	aa2503e5 	mvn	x5, x5
    4c60:	52800001 	mov	w1, #0x0                   	// #0
    4c64:	f8236a65 	str	x5, [x19, x3]
    4c68:	97fff6d6 	bl	27c0 <memset@plt>
    4c6c:	aa0003e4 	mov	x4, x0
    4c70:	f94a1260 	ldr	x0, [x19, #5152]
    4c74:	ab150000 	adds	x0, x0, x21
    4c78:	54000442 	b.cs	4d00 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4c7c:	f94a1661 	ldr	x1, [x19, #5160]
    4c80:	f90a1260 	str	x0, [x19, #5152]
    4c84:	eb01001f 	cmp	x0, x1
    4c88:	54000049 	b.ls	4c90 <fwp_heap_alloc+0xa0>  // b.plast
    4c8c:	f90a1660 	str	x0, [x19, #5160]
    4c90:	91154294 	add	x20, x20, #0x550
    4c94:	1e6302c1 	ucvtf	d1, w22
    4c98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c9c:	aa0403e0 	mov	x0, x4
    4ca0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4ca4:	1e612800 	fadd	d0, d0, d1
    4ca8:	fd0a1e80 	str	d0, [x20, #5176]
    4cac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4cb4:	d65f03c0 	ret
    4cb8:	8b030263 	add	x3, x19, x3
    4cbc:	f9400464 	ldr	x4, [x3, #8]
    4cc0:	b40000a4 	cbz	x4, 4cd4 <fwp_heap_alloc+0xe4>
    4cc4:	f9400862 	ldr	x2, [x3, #16]
    4cc8:	cb040042 	sub	x2, x2, x4
    4ccc:	eb15005f 	cmp	x2, x21
    4cd0:	540000a2 	b.cs	4ce4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4cd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4cd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4ce0:	17ffff6c 	b	4a90 <fwp_heap_alloc_slow>
    4ce4:	7100043f 	cmp	w1, #0x1
    4ce8:	8b150085 	add	x5, x4, x21
    4cec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cf0:	52800001 	mov	w1, #0x0                   	// #0
    4cf4:	aa0403e0 	mov	x0, x4
    4cf8:	f9000465 	str	x5, [x3, #8]
    4cfc:	17ffffdb 	b	4c68 <fwp_heap_alloc+0x78>
    4d00:	97fff8ac 	bl	2fb0 <fwp_heap_oom>

0000000000004d04 <fwp_apply>:
    4d04:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4d08:	aa0003e6 	mov	x6, x0
    4d0c:	910003fd 	mov	x29, sp
    4d10:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4d14:	f947f463 	ldr	x3, [x3, #4072]
    4d18:	a90153f3 	stp	x19, x20, [sp, #16]
    4d1c:	aa0203f4 	mov	x20, x2
    4d20:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d24:	2a0103f5 	mov	w21, w1
    4d28:	52800033 	mov	w19, #0x1                   	// #1
    4d2c:	a90363f7 	stp	x23, x24, [sp, #48]
    4d30:	900000f7 	adrp	x23, 20000 <__data_start>
    4d34:	910102f7 	add	x23, x23, #0x40
    4d38:	a9046bf9 	stp	x25, x26, [sp, #64]
    4d3c:	d100c3ff 	sub	sp, sp, #0x30
    4d40:	f9400060 	ldr	x0, [x3]
    4d44:	f81f83a0 	stur	x0, [x29, #-8]
    4d48:	d2800000 	mov	x0, #0x0                   	// #0
    4d4c:	294058c3 	ldp	w3, w22, [x6]
    4d50:	910003f8 	mov	x24, sp
    4d54:	f9401ee0 	ldr	x0, [x23, #56]
    4d58:	710002df 	cmp	w22, #0x0
    4d5c:	d37be863 	lsl	x3, x3, #5
    4d60:	8b030007 	add	x7, x0, x3
    4d64:	b8636819 	ldr	w25, [x0, x3]
    4d68:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    4d6c:	54000163 	b.cc	4d98 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    4d70:	f94004e3 	ldr	x3, [x7, #8]
    4d74:	34000bd9 	cbz	w25, 4eec <fwp_apply+0x1e8>
    4d78:	aa1403e0 	mov	x0, x20
    4d7c:	d63f0060 	blr	x3
    4d80:	aa0003e6 	mov	x6, x0
    4d84:	6b1902bf 	cmp	w21, w25
    4d88:	54000940 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4d8c:	8b394e94 	add	x20, x20, w25, uxtw #3
    4d90:	4b1902b5 	sub	w21, w21, w25
    4d94:	17ffffee 	b	4d4c <fwp_apply+0x48>
    4d98:	0b1602ba 	add	w26, w21, w22
    4d9c:	6b19035f 	cmp	w26, w25
    4da0:	54000543 	b.cc	4e48 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    4da4:	7100033f 	cmp	w25, #0x0
    4da8:	4b16033a 	sub	w26, w25, w22
    4dac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    4db0:	d37df000 	lsl	x0, x0, #3
    4db4:	91003c00 	add	x0, x0, #0xf
    4db8:	92704c01 	and	x1, x0, #0xfffff0000
    4dbc:	927c7c00 	and	x0, x0, #0xffffffff0
    4dc0:	cb2163e1 	sub	x1, sp, x1
    4dc4:	eb2163ff 	cmp	sp, x1
    4dc8:	540000a0 	b.eq	4ddc <fwp_apply+0xd8>  // b.none
    4dcc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    4dd0:	f90203ff 	str	xzr, [sp, #1024]
    4dd4:	eb2163ff 	cmp	sp, x1
    4dd8:	54ffffa1 	b.ne	4dcc <fwp_apply+0xc8>  // b.any
    4ddc:	92403c00 	and	x0, x0, #0xffff
    4de0:	cb2063ff 	sub	sp, sp, x0
    4de4:	f90003ff 	str	xzr, [sp]
    4de8:	f110001f 	cmp	x0, #0x400
    4dec:	54000962 	b.cs	4f18 <fwp_apply+0x214>  // b.hs, b.nlast
    4df0:	910020c6 	add	x6, x6, #0x8
    4df4:	910043e0 	add	x0, sp, #0x10
    4df8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    4dfc:	d2800003 	mov	x3, #0x0                   	// #0
    4e00:	340000f6 	cbz	w22, 4e1c <fwp_apply+0x118>
    4e04:	d503201f 	nop
    4e08:	f86368c4 	ldr	x4, [x6, x3]
    4e0c:	f8236804 	str	x4, [x0, x3]
    4e10:	91002063 	add	x3, x3, #0x8
    4e14:	eb0300bf 	cmp	x5, x3
    4e18:	54ffff81 	b.ne	4e08 <fwp_apply+0x104>  // b.any
    4e1c:	3400013a 	cbz	w26, 4e40 <fwp_apply+0x13c>
    4e20:	2a1a03e6 	mov	w6, w26
    4e24:	d2800003 	mov	x3, #0x0                   	// #0
    4e28:	0b0302c4 	add	w4, w22, w3
    4e2c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    4e30:	91000463 	add	x3, x3, #0x1
    4e34:	f8247805 	str	x5, [x0, x4, lsl #3]
    4e38:	eb0300df 	cmp	x6, x3
    4e3c:	54ffff61 	b.ne	4e28 <fwp_apply+0x124>  // b.any
    4e40:	f94004e3 	ldr	x3, [x7, #8]
    4e44:	1400002c 	b	4ef4 <fwp_apply+0x1f0>
    4e48:	11000740 	add	w0, w26, #0x1
    4e4c:	52800041 	mov	w1, #0x2                   	// #2
    4e50:	f81e83a6 	stur	x6, [x29, #-24]
    4e54:	d37df000 	lsl	x0, x0, #3
    4e58:	97ffff66 	bl	4bf0 <fwp_heap_alloc>
    4e5c:	f85e83a6 	ldur	x6, [x29, #-24]
    4e60:	aa0003f3 	mov	x19, x0
    4e64:	b94000c1 	ldr	w1, [x6]
    4e68:	29006801 	stp	w1, w26, [x0]
    4e6c:	340000b6 	cbz	w22, 4e80 <fwp_apply+0x17c>
    4e70:	910020c1 	add	x1, x6, #0x8
    4e74:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    4e78:	91002000 	add	x0, x0, #0x8
    4e7c:	97fff5f9 	bl	2660 <memmove@plt>
    4e80:	2a1503e3 	mov	w3, w21
    4e84:	d2800000 	mov	x0, #0x0                   	// #0
    4e88:	34000135 	cbz	w21, 4eac <fwp_apply+0x1a8>
    4e8c:	d503201f 	nop
    4e90:	0b0002c1 	add	w1, w22, w0
    4e94:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    4e98:	8b010e61 	add	x1, x19, x1, lsl #3
    4e9c:	91000400 	add	x0, x0, #0x1
    4ea0:	f9000422 	str	x2, [x1, #8]
    4ea4:	eb00007f 	cmp	x3, x0
    4ea8:	54ffff41 	b.ne	4e90 <fwp_apply+0x18c>  // b.any
    4eac:	aa1303e6 	mov	x6, x19
    4eb0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4eb4:	f947f400 	ldr	x0, [x0, #4072]
    4eb8:	f85f83a2 	ldur	x2, [x29, #-8]
    4ebc:	f9400001 	ldr	x1, [x0]
    4ec0:	eb010042 	subs	x2, x2, x1
    4ec4:	d2800001 	mov	x1, #0x0                   	// #0
    4ec8:	540002c1 	b.ne	4f20 <fwp_apply+0x21c>  // b.any
    4ecc:	910003bf 	mov	sp, x29
    4ed0:	aa0603e0 	mov	x0, x6
    4ed4:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ed8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4edc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ee0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4ee4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4ee8:	d65f03c0 	ret
    4eec:	d10043a0 	sub	x0, x29, #0x10
    4ef0:	5280001a 	mov	w26, #0x0                   	// #0
    4ef4:	d63f0060 	blr	x3
    4ef8:	aa0003e6 	mov	x6, x0
    4efc:	6b1a02bf 	cmp	w21, w26
    4f00:	54fffd80 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4f04:	0b1602b6 	add	w22, w21, w22
    4f08:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    4f0c:	4b1902d5 	sub	w21, w22, w25
    4f10:	9100031f 	mov	sp, x24
    4f14:	17ffff8e 	b	4d4c <fwp_apply+0x48>
    4f18:	f90203ff 	str	xzr, [sp, #1024]
    4f1c:	17ffffb5 	b	4df0 <fwp_apply+0xec>
    4f20:	97fff634 	bl	27f0 <__stack_chk_fail@plt>

0000000000004f24 <fwp_p_ad_push>:
    4f24:	f100001f 	cmp	x0, #0x0
    4f28:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    4f2c:	5400118b 	b.lt	515c <fwp_p_ad_push+0x238>  // b.tstop
    4f30:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    4f34:	910003fd 	mov	x29, sp
    4f38:	a90153f3 	stp	x19, x20, [sp, #16]
    4f3c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f40:	aa0403f6 	mov	x22, x4
    4f44:	aa0003f5 	mov	x21, x0
    4f48:	a90363f7 	stp	x23, x24, [sp, #48]
    4f4c:	aa0203f8 	mov	x24, x2
    4f50:	6d0627e8 	stp	d8, d9, [sp, #96]
    4f54:	9e670029 	fmov	d9, x1
    4f58:	9e670068 	fmov	d8, x3
    4f5c:	aa020001 	orr	x1, x0, x2
    4f60:	b6f80dc1 	tbz	x1, #63, 5118 <fwp_p_ad_push+0x1f4>
    4f64:	9360fc14 	asr	x20, x0, #32
    4f68:	b6f800c0 	tbz	x0, #63, 4f80 <fwp_p_ad_push+0x5c>
    4f6c:	1e604109 	fmov	d9, d8
    4f70:	2f00e408 	movi	d8, #0x0
    4f74:	9360fc54 	asr	x20, x2, #32
    4f78:	aa0203f5 	mov	x21, x2
    4f7c:	92800018 	mov	x24, #0xffffffffffffffff    	// #-1
    4f80:	b4001136 	cbz	x22, 51a4 <fwp_p_ad_push+0x280>
    4f84:	f94002c0 	ldr	x0, [x22]
    4f88:	eb14001f 	cmp	x0, x20
    4f8c:	54000e40 	b.eq	5154 <fwp_p_ad_push+0x230>  // b.none
    4f90:	aa1403e0 	mov	x0, x20
    4f94:	97fffa27 	bl	3830 <fwp_tape_of>
    4f98:	aa0003f3 	mov	x19, x0
    4f9c:	f9403000 	ldr	x0, [x0, #96]
    4fa0:	b50010c0 	cbnz	x0, 51b8 <fwp_p_ad_push+0x294>
    4fa4:	a9004ed4 	stp	x20, x19, [x22]
    4fa8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    4fac:	f9400a77 	ldr	x23, [x19, #16]
    4fb0:	a9046bf9 	stp	x25, x26, [sp, #64]
    4fb4:	eb0002ff 	cmp	x23, x0
    4fb8:	540013ec 	b.gt	5234 <fwp_p_ad_push+0x310>
    4fbc:	eb3542ff 	cmp	x23, w21, uxtw
    4fc0:	5400132d 	b.le	5224 <fwp_p_ad_push+0x300>
    4fc4:	b7f80078 	tbnz	x24, #63, 4fd0 <fwp_p_ad_push+0xac>
    4fc8:	eb3842ff 	cmp	x23, w24, uxtw
    4fcc:	540012cd 	b.le	5224 <fwp_p_ad_push+0x300>
    4fd0:	f9400676 	ldr	x22, [x19, #8]
    4fd4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    4fd8:	cb1602f6 	sub	x22, x23, x22
    4fdc:	910006c1 	add	x1, x22, #0x1
    4fe0:	aa1603f9 	mov	x25, x22
    4fe4:	eb00003f 	cmp	x1, x0
    4fe8:	54001268 	b.hi	5234 <fwp_p_ad_push+0x310>  // b.pmore
    4fec:	a9418274 	ldp	x20, x0, [x19, #24]
    4ff0:	eb14003f 	cmp	x1, x20
    4ff4:	54000a6d 	b.le	5140 <fwp_p_ad_push+0x21c>
    4ff8:	f100029f 	cmp	x20, #0x0
    4ffc:	d2800803 	mov	x3, #0x40                  	// #64
    5000:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5004:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    5008:	a90573fb 	stp	x27, x28, [sp, #80]
    500c:	eb14003f 	cmp	x1, x20
    5010:	5400008d 	b.le	5020 <fwp_p_ad_push+0xfc>
    5014:	eb02029f 	cmp	x20, x2
    5018:	5400090d 	b.le	5138 <fwp_p_ad_push+0x214>
    501c:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5020:	d37df29a 	lsl	x26, x20, #3
    5024:	f940327b 	ldr	x27, [x19, #96]
    5028:	aa1a03e1 	mov	x1, x26
    502c:	97fff5ed 	bl	27e0 <realloc@plt>
    5030:	b40010a0 	cbz	x0, 5244 <fwp_p_ad_push+0x320>
    5034:	f9400e61 	ldr	x1, [x19, #24]
    5038:	8b010801 	add	x1, x0, x1, lsl #2
    503c:	a9020660 	stp	x0, x1, [x19, #32]
    5040:	b400093b 	cbz	x27, 5164 <fwp_p_ad_push+0x240>
    5044:	f9403363 	ldr	x3, [x27, #96]
    5048:	f9003be3 	str	x3, [sp, #112]
    504c:	eb03029f 	cmp	x20, x3
    5050:	5400034d 	b.le	50b8 <fwp_p_ad_push+0x194>
    5054:	f940237c 	ldr	x28, [x27, #64]
    5058:	d37cee82 	lsl	x2, x20, #4
    505c:	aa0203e0 	mov	x0, x2
    5060:	52800041 	mov	w1, #0x2                   	// #2
    5064:	f9003fe2 	str	x2, [sp, #120]
    5068:	97fffee2 	bl	4bf0 <fwp_heap_alloc>
    506c:	aa0003fa 	mov	x26, x0
    5070:	b400013c 	cbz	x28, 5094 <fwp_p_ad_push+0x170>
    5074:	a9470be3 	ldp	x3, x2, [sp, #112]
    5078:	aa1c03e1 	mov	x1, x28
    507c:	d37cec63 	lsl	x3, x3, #4
    5080:	eb02007f 	cmp	x3, x2
    5084:	9a829062 	csel	x2, x3, x2, ls	// ls = plast
    5088:	97fff56e 	bl	2640 <memcpy@plt>
    508c:	aa1c03e0 	mov	x0, x28
    5090:	97fffdb8 	bl	4770 <fwp_mem_free>
    5094:	f9403360 	ldr	x0, [x27, #96]
    5098:	52800001 	mov	w1, #0x0                   	// #0
    509c:	cb000282 	sub	x2, x20, x0
    50a0:	8b001340 	add	x0, x26, x0, lsl #4
    50a4:	d37cec42 	lsl	x2, x2, #4
    50a8:	97fff5c6 	bl	27c0 <memset@plt>
    50ac:	f9401260 	ldr	x0, [x19, #32]
    50b0:	f900237a 	str	x26, [x27, #64]
    50b4:	f9003374 	str	x20, [x27, #96]
    50b8:	b50008b6 	cbnz	x22, 51cc <fwp_p_ad_push+0x2a8>
    50bc:	a9431263 	ldp	x3, x4, [x19, #48]
    50c0:	d37ef69a 	lsl	x26, x20, #2
    50c4:	a94573fb 	ldp	x27, x28, [sp, #80]
    50c8:	8b1a0002 	add	x2, x0, x26
    50cc:	f9000e74 	str	x20, [x19, #24]
    50d0:	f9001662 	str	x2, [x19, #40]
    50d4:	b8366815 	str	w21, [x0, x22]
    50d8:	f100031f 	cmp	x24, #0x0
    50dc:	da9fa301 	csinv	x1, x24, xzr, ge	// ge = tcont
    50e0:	92607eb5 	and	x21, x21, #0xffffffff00000000
    50e4:	fc396869 	str	d9, [x3, x25]
    50e8:	aa1702a0 	orr	x0, x21, x23
    50ec:	b8366841 	str	w1, [x2, x22]
    50f0:	910006e1 	add	x1, x23, #0x1
    50f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50f8:	fc396888 	str	d8, [x4, x25]
    50fc:	a94363f7 	ldp	x23, x24, [sp, #48]
    5100:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5104:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5108:	f9000a61 	str	x1, [x19, #16]
    510c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5110:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5114:	d65f03c0 	ret
    5118:	9360fc54 	asr	x20, x2, #32
    511c:	eb80829f 	cmp	x20, x0, asr #32
    5120:	54fff300 	b.eq	4f80 <fwp_p_ad_push+0x5c>  // b.none
    5124:	90000040 	adrp	x0, d000 <__modti3+0x1f0>
    5128:	91128000 	add	x0, x0, #0x4a0
    512c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5130:	a90573fb 	stp	x27, x28, [sp, #80]
    5134:	97fff8f3 	bl	3500 <fwp_trap>
    5138:	d37ffa94 	lsl	x20, x20, #1
    513c:	17ffffb4 	b	500c <fwp_p_ad_push+0xe8>
    5140:	a9428e62 	ldp	x2, x3, [x19, #40]
    5144:	d37ef6d6 	lsl	x22, x22, #2
    5148:	f9401e64 	ldr	x4, [x19, #56]
    514c:	d37df339 	lsl	x25, x25, #3
    5150:	17ffffe1 	b	50d4 <fwp_p_ad_push+0x1b0>
    5154:	f94006d3 	ldr	x19, [x22, #8]
    5158:	17ffff94 	b	4fa8 <fwp_p_ad_push+0x84>
    515c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5160:	d65f03c0 	ret
    5164:	f9401a60 	ldr	x0, [x19, #48]
    5168:	d37cee9b 	lsl	x27, x20, #4
    516c:	aa1b03e1 	mov	x1, x27
    5170:	97fff59c 	bl	27e0 <realloc@plt>
    5174:	aa0003e3 	mov	x3, x0
    5178:	b4000660 	cbz	x0, 5244 <fwp_p_ad_push+0x320>
    517c:	8b1a0004 	add	x4, x0, x26
    5180:	f9400e60 	ldr	x0, [x19, #24]
    5184:	8b000c61 	add	x1, x3, x0, lsl #3
    5188:	a9030663 	stp	x3, x1, [x19, #48]
    518c:	b5000356 	cbnz	x22, 51f4 <fwp_p_ad_push+0x2d0>
    5190:	f9401260 	ldr	x0, [x19, #32]
    5194:	d37ef69a 	lsl	x26, x20, #2
    5198:	d2800016 	mov	x22, #0x0                   	// #0
    519c:	f9001e64 	str	x4, [x19, #56]
    51a0:	17ffffc9 	b	50c4 <fwp_p_ad_push+0x1a0>
    51a4:	aa1403e0 	mov	x0, x20
    51a8:	97fff9a2 	bl	3830 <fwp_tape_of>
    51ac:	aa0003f3 	mov	x19, x0
    51b0:	f9403000 	ldr	x0, [x0, #96]
    51b4:	b4ffefa0 	cbz	x0, 4fa8 <fwp_p_ad_push+0x84>
    51b8:	90000040 	adrp	x0, d000 <__modti3+0x1f0>
    51bc:	9113a000 	add	x0, x0, #0x4e8
    51c0:	a9046bf9 	stp	x25, x26, [sp, #64]
    51c4:	a90573fb 	stp	x27, x28, [sp, #80]
    51c8:	97fff8ce 	bl	3500 <fwp_trap>
    51cc:	d37df2d9 	lsl	x25, x22, #3
    51d0:	f9401661 	ldr	x1, [x19, #40]
    51d4:	d37ef6d6 	lsl	x22, x22, #2
    51d8:	d37ef69a 	lsl	x26, x20, #2
    51dc:	aa1603e2 	mov	x2, x22
    51e0:	8b1a0000 	add	x0, x0, x26
    51e4:	97fff51f 	bl	2660 <memmove@plt>
    51e8:	f9401260 	ldr	x0, [x19, #32]
    51ec:	a9431263 	ldp	x3, x4, [x19, #48]
    51f0:	17ffffb5 	b	50c4 <fwp_p_ad_push+0x1a0>
    51f4:	eb1b035f 	cmp	x26, x27
    51f8:	d37df2d9 	lsl	x25, x22, #3
    51fc:	9a9b2343 	csel	x3, x26, x27, cs	// cs = hs, nlast
    5200:	aa0403e0 	mov	x0, x4
    5204:	cb1a0063 	sub	x3, x3, x26
    5208:	aa1903e2 	mov	x2, x25
    520c:	97fff5e1 	bl	2990 <__memmove_chk@plt>
    5210:	f9401a61 	ldr	x1, [x19, #48]
    5214:	f9401260 	ldr	x0, [x19, #32]
    5218:	8b1a0021 	add	x1, x1, x26
    521c:	f9001e61 	str	x1, [x19, #56]
    5220:	17ffffec 	b	51d0 <fwp_p_ad_push+0x2ac>
    5224:	90000040 	adrp	x0, d000 <__modti3+0x1f0>
    5228:	9114e000 	add	x0, x0, #0x538
    522c:	a90573fb 	stp	x27, x28, [sp, #80]
    5230:	97fff8b4 	bl	3500 <fwp_trap>
    5234:	90000040 	adrp	x0, d000 <__modti3+0x1f0>
    5238:	91146000 	add	x0, x0, #0x518
    523c:	a90573fb 	stp	x27, x28, [sp, #80]
    5240:	97fff8b0 	bl	3500 <fwp_trap>
    5244:	aa1303e0 	mov	x0, x19
    5248:	97fff732 	bl	2f10 <fwp_tape_unlink_scope>
    524c:	f9401260 	ldr	x0, [x19, #32]
    5250:	97fff598 	bl	28b0 <free@plt>
    5254:	f9401a60 	ldr	x0, [x19, #48]
    5258:	97fff596 	bl	28b0 <free@plt>
    525c:	f9402260 	ldr	x0, [x19, #64]
    5260:	97fff594 	bl	28b0 <free@plt>
    5264:	f9000e7f 	str	xzr, [x19, #24]
    5268:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    526c:	f947e821 	ldr	x1, [x1, #4048]
    5270:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5274:	d2800262 	mov	x2, #0x13                  	// #19
    5278:	4f000400 	movi	v0.4s, #0x0
    527c:	90000040 	adrp	x0, d000 <__modti3+0x1f0>
    5280:	f9400023 	ldr	x3, [x1]
    5284:	b900067f 	str	wzr, [x19, #4]
    5288:	d2800021 	mov	x1, #0x1                   	// #1
    528c:	9106e000 	add	x0, x0, #0x1b8
    5290:	3c808260 	stur	q0, [x19, #8]
    5294:	ad010260 	stp	q0, q0, [x19, #32]
    5298:	97fff596 	bl	28f0 <fwrite@plt>
    529c:	d2800000 	mov	x0, #0x0                   	// #0
    52a0:	97fff5a0 	bl	2920 <fflush@plt>
    52a4:	52800cc0 	mov	w0, #0x66                  	// #102
    52a8:	97fff5ae 	bl	2960 <_Exit@plt>
    52ac:	d503201f 	nop

00000000000052b0 <w107>:
    52b0:	d10203ff 	sub	sp, sp, #0x80
    52b4:	9e660003 	fmov	x3, d0
    52b8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    52bc:	f947f442 	ldr	x2, [x2, #4072]
    52c0:	a9027bfd 	stp	x29, x30, [sp, #32]
    52c4:	910083fd 	add	x29, sp, #0x20
    52c8:	6d0627e8 	stp	d8, d9, [sp, #96]
    52cc:	1e604009 	fmov	d9, d0
    52d0:	1e604028 	fmov	d8, d1
    52d4:	fd003bea 	str	d10, [sp, #112]
    52d8:	1e60080a 	fmul	d10, d0, d0
    52dc:	a90353f3 	stp	x19, x20, [sp, #48]
    52e0:	910023f3 	add	x19, sp, #0x8
    52e4:	aa0003f4 	mov	x20, x0
    52e8:	a9045bf5 	stp	x21, x22, [sp, #64]
    52ec:	aa0103f6 	mov	x22, x1
    52f0:	92800015 	mov	x21, #0xffffffffffffffff    	// #-1
    52f4:	a90563f7 	stp	x23, x24, [sp, #80]
    52f8:	aa0303e1 	mov	x1, x3
    52fc:	f9400044 	ldr	x4, [x2]
    5300:	f9000fe4 	str	x4, [sp, #24]
    5304:	d2800004 	mov	x4, #0x0                   	// #0
    5308:	aa0003e2 	mov	x2, x0
    530c:	aa1303e4 	mov	x4, x19
    5310:	a900fff5 	stp	x21, xzr, [sp, #8]
    5314:	97ffff04 	bl	4f24 <fwp_p_ad_push>
    5318:	1e6a3908 	fsub	d8, d8, d10
    531c:	aa1603e2 	mov	x2, x22
    5320:	aa1303e4 	mov	x4, x19
    5324:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5328:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    532c:	9e660118 	fmov	x24, d8
    5330:	97fffefd 	bl	4f24 <fwp_p_ad_push>
    5334:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5338:	aa0003f6 	mov	x22, x0
    533c:	aa1303e4 	mov	x4, x19
    5340:	aa1403e0 	mov	x0, x20
    5344:	1e69394a 	fsub	d10, d10, d9
    5348:	aa1503e2 	mov	x2, x21
    534c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5350:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5354:	9e660157 	fmov	x23, d10
    5358:	97fffef3 	bl	4f24 <fwp_p_ad_push>
    535c:	1e680908 	fmul	d8, d8, d8
    5360:	aa0003f4 	mov	x20, x0
    5364:	aa1303e4 	mov	x4, x19
    5368:	aa1803e3 	mov	x3, x24
    536c:	aa1803e1 	mov	x1, x24
    5370:	aa1603e2 	mov	x2, x22
    5374:	aa1603e0 	mov	x0, x22
    5378:	97fffeeb 	bl	4f24 <fwp_p_ad_push>
    537c:	aa0003e2 	mov	x2, x0
    5380:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5384:	9e670029 	fmov	d9, x1
    5388:	9e660101 	fmov	x1, d8
    538c:	aa1303e4 	mov	x4, x19
    5390:	1e690909 	fmul	d9, d8, d9
    5394:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5398:	aa1503e0 	mov	x0, x21
    539c:	97fffee2 	bl	4f24 <fwp_p_ad_push>
    53a0:	1e6a094a 	fmul	d10, d10, d10
    53a4:	aa1303e4 	mov	x4, x19
    53a8:	aa1703e3 	mov	x3, x23
    53ac:	aa0003f3 	mov	x19, x0
    53b0:	aa1703e1 	mov	x1, x23
    53b4:	aa1403e2 	mov	x2, x20
    53b8:	aa1403e0 	mov	x0, x20
    53bc:	97fffeda 	bl	4f24 <fwp_p_ad_push>
    53c0:	1e6a2929 	fadd	d9, d9, d10
    53c4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    53c8:	d2800004 	mov	x4, #0x0                   	// #0
    53cc:	aa0303e1 	mov	x1, x3
    53d0:	aa1303e2 	mov	x2, x19
    53d4:	97fffed4 	bl	4f24 <fwp_p_ad_push>
    53d8:	aa0003e1 	mov	x1, x0
    53dc:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    53e0:	f947f463 	ldr	x3, [x3, #4072]
    53e4:	f9400fe0 	ldr	x0, [sp, #24]
    53e8:	f9400064 	ldr	x4, [x3]
    53ec:	eb040000 	subs	x0, x0, x4
    53f0:	d2800004 	mov	x4, #0x0                   	// #0
    53f4:	54000161 	b.ne	5420 <w107+0x170>  // b.any
    53f8:	9e660122 	fmov	x2, d9
    53fc:	fd403bea 	ldr	d10, [sp, #112]
    5400:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5404:	a94353f3 	ldp	x19, x20, [sp, #48]
    5408:	aa0203e0 	mov	x0, x2
    540c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    5410:	a94563f7 	ldp	x23, x24, [sp, #80]
    5414:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5418:	910203ff 	add	sp, sp, #0x80
    541c:	d65f03c0 	ret
    5420:	97fff4f4 	bl	27f0 <__stack_chk_fail@plt>

0000000000005424 <w164.constprop.0>:
    5424:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5428:	910003fd 	mov	x29, sp
    542c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5430:	fd001be8 	str	d8, [sp, #48]
    5434:	f9400015 	ldr	x21, [x0]
    5438:	b4000355 	cbz	x21, 54a0 <w164.constprop.0+0x7c>
    543c:	2f00e408 	movi	d8, #0x0
    5440:	91002016 	add	x22, x0, #0x8
    5444:	a90153f3 	stp	x19, x20, [sp, #16]
    5448:	91004014 	add	x20, x0, #0x10
    544c:	d2800013 	mov	x19, #0x0                   	// #0
    5450:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5454:	d503201f 	nop
    5458:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    545c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5460:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    5464:	aa0303e1 	mov	x1, x3
    5468:	1e602908 	fadd	d8, d8, d0
    546c:	d2800004 	mov	x4, #0x0                   	// #0
    5470:	91000a73 	add	x19, x19, #0x2
    5474:	97fffeac 	bl	4f24 <fwp_p_ad_push>
    5478:	eb1302bf 	cmp	x21, x19
    547c:	54fffee8 	b.hi	5458 <w164.constprop.0+0x34>  // b.pmore
    5480:	9e660102 	fmov	x2, d8
    5484:	fd401be8 	ldr	d8, [sp, #48]
    5488:	a94153f3 	ldp	x19, x20, [sp, #16]
    548c:	aa0003e1 	mov	x1, x0
    5490:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5494:	aa0203e0 	mov	x0, x2
    5498:	a8c47bfd 	ldp	x29, x30, [sp], #64
    549c:	d65f03c0 	ret
    54a0:	2f00e408 	movi	d8, #0x0
    54a4:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    54a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    54ac:	aa0003e1 	mov	x1, x0
    54b0:	9e660102 	fmov	x2, d8
    54b4:	fd401be8 	ldr	d8, [sp, #48]
    54b8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    54bc:	aa0203e0 	mov	x0, x2
    54c0:	d65f03c0 	ret

00000000000054c4 <fwp_data.part.0.constprop.0>:
    54c4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    54c8:	910003fd 	mov	x29, sp
    54cc:	a90153f3 	stp	x19, x20, [sp, #16]
    54d0:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc90>
    54d4:	91154283 	add	x3, x20, #0x550
    54d8:	a9025bf5 	stp	x21, x22, [sp, #32]
    54dc:	aa0103f5 	mov	x21, x1
    54e0:	b953a461 	ldr	w1, [x3, #5028]
    54e4:	a90363f7 	stp	x23, x24, [sp, #48]
    54e8:	2a0003f8 	mov	w24, w0
    54ec:	34000701 	cbz	w1, 55cc <fwp_data.part.0.constprop.0+0x108>
    54f0:	397e8862 	ldrb	w2, [x3, #4002]
    54f4:	910f0040 	add	x0, x2, #0x3c0
    54f8:	8b020442 	add	x2, x2, x2, lsl #1
    54fc:	d37df042 	lsl	x2, x2, #3
    5500:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5504:	2a1703f6 	mov	w22, w23
    5508:	f8626873 	ldr	x19, [x3, x2]
    550c:	b40004d3 	cbz	x19, 55a4 <fwp_data.part.0.constprop.0+0xe0>
    5510:	f9400260 	ldr	x0, [x19]
    5514:	aa2003e0 	mvn	x0, x0
    5518:	f8226860 	str	x0, [x3, x2]
    551c:	f10062df 	cmp	x22, #0x18
    5520:	540000e9 	b.ls	553c <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5524:	d10066c2 	sub	x2, x22, #0x19
    5528:	91006260 	add	x0, x19, #0x18
    552c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5530:	52800001 	mov	w1, #0x0                   	// #0
    5534:	91002042 	add	x2, x2, #0x8
    5538:	97fff4a2 	bl	27c0 <memset@plt>
    553c:	91154282 	add	x2, x20, #0x550
    5540:	f94a1041 	ldr	x1, [x2, #5152]
    5544:	ab160021 	adds	x1, x1, x22
    5548:	540004c2 	b.cs	55e0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    554c:	f94a1440 	ldr	x0, [x2, #5160]
    5550:	f90a1041 	str	x1, [x2, #5152]
    5554:	eb00003f 	cmp	x1, x0
    5558:	54000049 	b.ls	5560 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    555c:	f90a1441 	str	x1, [x2, #5160]
    5560:	91154294 	add	x20, x20, #0x550
    5564:	1e6302e1 	ucvtf	d1, w23
    5568:	fd4a1e80 	ldr	d0, [x20, #5176]
    556c:	1e612800 	fadd	d0, d0, d1
    5570:	fd0a1e80 	str	d0, [x20, #5176]
    5574:	52800041 	mov	w1, #0x2                   	// #2
    5578:	29000678 	stp	w24, w1, [x19]
    557c:	aa1303e0 	mov	x0, x19
    5580:	f94002a1 	ldr	x1, [x21]
    5584:	f9000661 	str	x1, [x19, #8]
    5588:	f94006a1 	ldr	x1, [x21, #8]
    558c:	f9000a61 	str	x1, [x19, #16]
    5590:	a94153f3 	ldp	x19, x20, [sp, #16]
    5594:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5598:	a94363f7 	ldp	x23, x24, [sp, #48]
    559c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    55a0:	d65f03c0 	ret
    55a4:	8b020063 	add	x3, x3, x2
    55a8:	f9400473 	ldr	x19, [x3, #8]
    55ac:	b4000113 	cbz	x19, 55cc <fwp_data.part.0.constprop.0+0x108>
    55b0:	f9400860 	ldr	x0, [x3, #16]
    55b4:	cb130000 	sub	x0, x0, x19
    55b8:	eb0002df 	cmp	x22, x0
    55bc:	54000088 	b.hi	55cc <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    55c0:	8b160260 	add	x0, x19, x22
    55c4:	f9000460 	str	x0, [x3, #8]
    55c8:	17ffffd5 	b	551c <fwp_data.part.0.constprop.0+0x58>
    55cc:	52800001 	mov	w1, #0x0                   	// #0
    55d0:	d2800300 	mov	x0, #0x18                  	// #24
    55d4:	97fffd87 	bl	4bf0 <fwp_heap_alloc>
    55d8:	aa0003f3 	mov	x19, x0
    55dc:	17ffffe6 	b	5574 <fwp_data.part.0.constprop.0+0xb0>
    55e0:	97fff674 	bl	2fb0 <fwp_heap_oom>

00000000000055e4 <fwp_rc_share>:
    55e4:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    55e8:	91154042 	add	x2, x2, #0x550
    55ec:	f949d843 	ldr	x3, [x2, #5040]
    55f0:	f949ec41 	ldr	x1, [x2, #5080]
    55f4:	cb030000 	sub	x0, x0, x3
    55f8:	eb01401f 	cmp	x0, x1, lsl #16
    55fc:	540002c2 	b.cs	5654 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5600:	d350fc01 	lsr	x1, x0, #16
    5604:	f949fc44 	ldr	x4, [x2, #5112]
    5608:	8b010821 	add	x1, x1, x1, lsl #2
    560c:	d37df021 	lsl	x1, x1, #3
    5610:	8b010083 	add	x3, x4, x1
    5614:	f9401062 	ldr	x2, [x3, #32]
    5618:	b40001e2 	cbz	x2, 5654 <fwp_rc_share+0x70>
    561c:	38616881 	ldrb	w1, [x4, x1]
    5620:	7100083f 	cmp	w1, #0x2
    5624:	540001a0 	b.eq	5658 <fwp_rc_share+0x74>  // b.none
    5628:	7100043f 	cmp	w1, #0x1
    562c:	54000141 	b.ne	5654 <fwp_rc_share+0x70>  // b.any
    5630:	29430464 	ldp	w4, w1, [x3, #24]
    5634:	92403c00 	and	x0, x0, #0xffff
    5638:	9b047c00 	mul	x0, x0, x4
    563c:	d360fc00 	lsr	x0, x0, #32
    5640:	eb01001f 	cmp	x0, x1
    5644:	54000082 	b.cs	5654 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5648:	8b000042 	add	x2, x2, x0
    564c:	39400040 	ldrb	w0, [x2]
    5650:	350000a0 	cbnz	w0, 5664 <fwp_rc_share+0x80>
    5654:	d65f03c0 	ret
    5658:	72003c1f 	tst	w0, #0xffff
    565c:	54ffff80 	b.eq	564c <fwp_rc_share+0x68>  // b.none
    5660:	d65f03c0 	ret
    5664:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5668:	90000040 	adrp	x0, d000 <__modti3+0x1f0>
    566c:	91156000 	add	x0, x0, #0x558
    5670:	910003fd 	mov	x29, sp
    5674:	97fff7a3 	bl	3500 <fwp_trap>
    5678:	d503201f 	nop
    567c:	d503201f 	nop

0000000000005680 <fwp_rc_fresh>:
    5680:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5684:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    5688:	91154063 	add	x3, x3, #0x550
    568c:	910003fd 	mov	x29, sp
    5690:	a90153f3 	stp	x19, x20, [sp, #16]
    5694:	aa0003f3 	mov	x19, x0
    5698:	f949d861 	ldr	x1, [x3, #5040]
    569c:	f949ec60 	ldr	x0, [x3, #5080]
    56a0:	cb010261 	sub	x1, x19, x1
    56a4:	eb00403f 	cmp	x1, x0, lsl #16
    56a8:	54000322 	b.cs	570c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    56ac:	d350fc22 	lsr	x2, x1, #16
    56b0:	f949fc63 	ldr	x3, [x3, #5112]
    56b4:	8b020842 	add	x2, x2, x2, lsl #2
    56b8:	d37df042 	lsl	x2, x2, #3
    56bc:	8b020060 	add	x0, x3, x2
    56c0:	f9401014 	ldr	x20, [x0, #32]
    56c4:	b4000254 	cbz	x20, 570c <fwp_rc_fresh+0x8c>
    56c8:	38626862 	ldrb	w2, [x3, x2]
    56cc:	7100085f 	cmp	w2, #0x2
    56d0:	54000260 	b.eq	571c <fwp_rc_fresh+0x9c>  // b.none
    56d4:	7100045f 	cmp	w2, #0x1
    56d8:	540001a1 	b.ne	570c <fwp_rc_fresh+0x8c>  // b.any
    56dc:	29430002 	ldp	w2, w0, [x0, #24]
    56e0:	92403c21 	and	x1, x1, #0xffff
    56e4:	9b027c21 	mul	x1, x1, x2
    56e8:	d360fc21 	lsr	x1, x1, #32
    56ec:	eb00003f 	cmp	x1, x0
    56f0:	540000e2 	b.cs	570c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    56f4:	8b010294 	add	x20, x20, x1
    56f8:	39400280 	ldrb	w0, [x20]
    56fc:	7103fc1f 	cmp	w0, #0xff
    5700:	540001a0 	b.eq	5734 <fwp_rc_fresh+0xb4>  // b.none
    5704:	52800020 	mov	w0, #0x1                   	// #1
    5708:	39000280 	strb	w0, [x20]
    570c:	aa1303e0 	mov	x0, x19
    5710:	a94153f3 	ldp	x19, x20, [sp, #16]
    5714:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5718:	d65f03c0 	ret
    571c:	72003c3f 	tst	w1, #0xffff
    5720:	54fffec0 	b.eq	56f8 <fwp_rc_fresh+0x78>  // b.none
    5724:	aa1303e0 	mov	x0, x19
    5728:	a94153f3 	ldp	x19, x20, [sp, #16]
    572c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5730:	d65f03c0 	ret
    5734:	aa1403e0 	mov	x0, x20
    5738:	97fffb6e 	bl	44f0 <fwp_rc_forget_slot>
    573c:	17fffff2 	b	5704 <fwp_rc_fresh+0x84>

0000000000005740 <fwp_rc_free_arr>:
    5740:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    5744:	91154063 	add	x3, x3, #0x550
    5748:	f949d861 	ldr	x1, [x3, #5040]
    574c:	f949ec62 	ldr	x2, [x3, #5080]
    5750:	cb010001 	sub	x1, x0, x1
    5754:	eb02403f 	cmp	x1, x2, lsl #16
    5758:	54000342 	b.cs	57c0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    575c:	d350fc22 	lsr	x2, x1, #16
    5760:	f949fc65 	ldr	x5, [x3, #5112]
    5764:	8b020842 	add	x2, x2, x2, lsl #2
    5768:	d37df042 	lsl	x2, x2, #3
    576c:	8b0200a4 	add	x4, x5, x2
    5770:	f9401083 	ldr	x3, [x4, #32]
    5774:	b4000263 	cbz	x3, 57c0 <fwp_rc_free_arr+0x80>
    5778:	386268a2 	ldrb	w2, [x5, x2]
    577c:	7100085f 	cmp	w2, #0x2
    5780:	540001c0 	b.eq	57b8 <fwp_rc_free_arr+0x78>  // b.none
    5784:	7100045f 	cmp	w2, #0x1
    5788:	540001c1 	b.ne	57c0 <fwp_rc_free_arr+0x80>  // b.any
    578c:	29430885 	ldp	w5, w2, [x4, #24]
    5790:	92403c21 	and	x1, x1, #0xffff
    5794:	9b057c21 	mul	x1, x1, x5
    5798:	d360fc21 	lsr	x1, x1, #32
    579c:	eb02003f 	cmp	x1, x2
    57a0:	54000102 	b.cs	57c0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    57a4:	8b010063 	add	x3, x3, x1
    57a8:	39400061 	ldrb	w1, [x3]
    57ac:	7100043f 	cmp	w1, #0x1
    57b0:	54000081 	b.ne	57c0 <fwp_rc_free_arr+0x80>  // b.any
    57b4:	17fffbef 	b	4770 <fwp_mem_free>
    57b8:	72003c3f 	tst	w1, #0xffff
    57bc:	54ffff60 	b.eq	57a8 <fwp_rc_free_arr+0x68>  // b.none
    57c0:	d65f03c0 	ret

00000000000057c4 <fwp_rc_dup>:
    57c4:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    57c8:	91154042 	add	x2, x2, #0x550
    57cc:	f949d841 	ldr	x1, [x2, #5040]
    57d0:	f949ec43 	ldr	x3, [x2, #5080]
    57d4:	cb010001 	sub	x1, x0, x1
    57d8:	eb03403f 	cmp	x1, x3, lsl #16
    57dc:	54000342 	b.cs	5844 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    57e0:	d350fc20 	lsr	x0, x1, #16
    57e4:	f949fc44 	ldr	x4, [x2, #5112]
    57e8:	8b000800 	add	x0, x0, x0, lsl #2
    57ec:	d37df002 	lsl	x2, x0, #3
    57f0:	8b020083 	add	x3, x4, x2
    57f4:	f9401060 	ldr	x0, [x3, #32]
    57f8:	b4000260 	cbz	x0, 5844 <fwp_rc_dup+0x80>
    57fc:	38626882 	ldrb	w2, [x4, x2]
    5800:	7100085f 	cmp	w2, #0x2
    5804:	54000220 	b.eq	5848 <fwp_rc_dup+0x84>  // b.none
    5808:	7100045f 	cmp	w2, #0x1
    580c:	540001c1 	b.ne	5844 <fwp_rc_dup+0x80>  // b.any
    5810:	29430864 	ldp	w4, w2, [x3, #24]
    5814:	92403c21 	and	x1, x1, #0xffff
    5818:	9b047c21 	mul	x1, x1, x4
    581c:	d360fc21 	lsr	x1, x1, #32
    5820:	eb02003f 	cmp	x1, x2
    5824:	54000102 	b.cs	5844 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5828:	8b010000 	add	x0, x0, x1
    582c:	39400001 	ldrb	w1, [x0]
    5830:	340000a1 	cbz	w1, 5844 <fwp_rc_dup+0x80>
    5834:	7103f43f 	cmp	w1, #0xfd
    5838:	540000e8 	b.hi	5854 <fwp_rc_dup+0x90>  // b.pmore
    583c:	11000421 	add	w1, w1, #0x1
    5840:	39000001 	strb	w1, [x0]
    5844:	d65f03c0 	ret
    5848:	72003c3f 	tst	w1, #0xffff
    584c:	54ffff00 	b.eq	582c <fwp_rc_dup+0x68>  // b.none
    5850:	d65f03c0 	ret
    5854:	17fffae0 	b	43d4 <fwp_rc_wide_dup>
    5858:	d503201f 	nop
    585c:	d503201f 	nop

0000000000005860 <fwp_owned_entry161>:
    5860:	d10103ff 	sub	sp, sp, #0x40
    5864:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    5868:	f947f442 	ldr	x2, [x2, #4072]
    586c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5870:	910083fd 	add	x29, sp, #0x20
    5874:	a90353f3 	stp	x19, x20, [sp, #48]
    5878:	f9400043 	ldr	x3, [x2]
    587c:	f9000fe3 	str	x3, [sp, #24]
    5880:	d2800003 	mov	x3, #0x0                   	// #0
    5884:	a9400c01 	ldp	x1, x3, [x0]
    5888:	f9400802 	ldr	x2, [x0, #16]
    588c:	ab020022 	adds	x2, x1, x2
    5890:	540006e6 	b.vs	596c <fwp_owned_entry161+0x10c>
    5894:	910023e1 	add	x1, sp, #0x8
    5898:	52800000 	mov	w0, #0x0                   	// #0
    589c:	a9008be3 	stp	x3, x2, [sp, #8]
    58a0:	97ffff09 	bl	54c4 <fwp_data.part.0.constprop.0>
    58a4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    58a8:	91154063 	add	x3, x3, #0x550
    58ac:	aa0003f3 	mov	x19, x0
    58b0:	f949d861 	ldr	x1, [x3, #5040]
    58b4:	f949ec60 	ldr	x0, [x3, #5080]
    58b8:	cb010261 	sub	x1, x19, x1
    58bc:	eb00403f 	cmp	x1, x0, lsl #16
    58c0:	54000322 	b.cs	5924 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    58c4:	d350fc22 	lsr	x2, x1, #16
    58c8:	f949fc63 	ldr	x3, [x3, #5112]
    58cc:	8b020842 	add	x2, x2, x2, lsl #2
    58d0:	d37df042 	lsl	x2, x2, #3
    58d4:	8b020060 	add	x0, x3, x2
    58d8:	f9401014 	ldr	x20, [x0, #32]
    58dc:	b4000254 	cbz	x20, 5924 <fwp_owned_entry161+0xc4>
    58e0:	38626862 	ldrb	w2, [x3, x2]
    58e4:	7100085f 	cmp	w2, #0x2
    58e8:	54000360 	b.eq	5954 <fwp_owned_entry161+0xf4>  // b.none
    58ec:	7100045f 	cmp	w2, #0x1
    58f0:	540001a1 	b.ne	5924 <fwp_owned_entry161+0xc4>  // b.any
    58f4:	29430002 	ldp	w2, w0, [x0, #24]
    58f8:	92403c21 	and	x1, x1, #0xffff
    58fc:	9b027c21 	mul	x1, x1, x2
    5900:	d360fc21 	lsr	x1, x1, #32
    5904:	eb00003f 	cmp	x1, x0
    5908:	540000e2 	b.cs	5924 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    590c:	8b010294 	add	x20, x20, x1
    5910:	39400280 	ldrb	w0, [x20]
    5914:	7103fc1f 	cmp	w0, #0xff
    5918:	54000240 	b.eq	5960 <fwp_owned_entry161+0x100>  // b.none
    591c:	52800020 	mov	w0, #0x1                   	// #1
    5920:	39000280 	strb	w0, [x20]
    5924:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5928:	f947f400 	ldr	x0, [x0, #4072]
    592c:	f9400fe2 	ldr	x2, [sp, #24]
    5930:	f9400001 	ldr	x1, [x0]
    5934:	eb010042 	subs	x2, x2, x1
    5938:	d2800001 	mov	x1, #0x0                   	// #0
    593c:	540001a1 	b.ne	5970 <fwp_owned_entry161+0x110>  // b.any
    5940:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5944:	aa1303e0 	mov	x0, x19
    5948:	a94353f3 	ldp	x19, x20, [sp, #48]
    594c:	910103ff 	add	sp, sp, #0x40
    5950:	d65f03c0 	ret
    5954:	72003c3f 	tst	w1, #0xffff
    5958:	54fffe61 	b.ne	5924 <fwp_owned_entry161+0xc4>  // b.any
    595c:	17ffffed 	b	5910 <fwp_owned_entry161+0xb0>
    5960:	aa1403e0 	mov	x0, x20
    5964:	97fffae3 	bl	44f0 <fwp_rc_forget_slot>
    5968:	17ffffed 	b	591c <fwp_owned_entry161+0xbc>
    596c:	97fff425 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5970:	97fff3a0 	bl	27f0 <__stack_chk_fail@plt>

0000000000005974 <e161>:
    5974:	d10103ff 	sub	sp, sp, #0x40
    5978:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    597c:	f947f442 	ldr	x2, [x2, #4072]
    5980:	a9027bfd 	stp	x29, x30, [sp, #32]
    5984:	910083fd 	add	x29, sp, #0x20
    5988:	a90353f3 	stp	x19, x20, [sp, #48]
    598c:	f9400043 	ldr	x3, [x2]
    5990:	f9000fe3 	str	x3, [sp, #24]
    5994:	d2800003 	mov	x3, #0x0                   	// #0
    5998:	a9400c01 	ldp	x1, x3, [x0]
    599c:	f9400802 	ldr	x2, [x0, #16]
    59a0:	ab020022 	adds	x2, x1, x2
    59a4:	54000726 	b.vs	5a88 <e161+0x114>
    59a8:	910023e1 	add	x1, sp, #0x8
    59ac:	52800000 	mov	w0, #0x0                   	// #0
    59b0:	a9008be3 	stp	x3, x2, [sp, #8]
    59b4:	97fffec4 	bl	54c4 <fwp_data.part.0.constprop.0>
    59b8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    59bc:	91154063 	add	x3, x3, #0x550
    59c0:	aa0003f3 	mov	x19, x0
    59c4:	f949d861 	ldr	x1, [x3, #5040]
    59c8:	f949ec60 	ldr	x0, [x3, #5080]
    59cc:	cb010261 	sub	x1, x19, x1
    59d0:	eb00403f 	cmp	x1, x0, lsl #16
    59d4:	54000322 	b.cs	5a38 <e161+0xc4>  // b.hs, b.nlast
    59d8:	d350fc22 	lsr	x2, x1, #16
    59dc:	f949fc63 	ldr	x3, [x3, #5112]
    59e0:	8b020842 	add	x2, x2, x2, lsl #2
    59e4:	d37df042 	lsl	x2, x2, #3
    59e8:	8b020060 	add	x0, x3, x2
    59ec:	f9401014 	ldr	x20, [x0, #32]
    59f0:	b4000254 	cbz	x20, 5a38 <e161+0xc4>
    59f4:	38626862 	ldrb	w2, [x3, x2]
    59f8:	7100085f 	cmp	w2, #0x2
    59fc:	540003a0 	b.eq	5a70 <e161+0xfc>  // b.none
    5a00:	7100045f 	cmp	w2, #0x1
    5a04:	540001a1 	b.ne	5a38 <e161+0xc4>  // b.any
    5a08:	29430002 	ldp	w2, w0, [x0, #24]
    5a0c:	92403c21 	and	x1, x1, #0xffff
    5a10:	9b027c21 	mul	x1, x1, x2
    5a14:	d360fc21 	lsr	x1, x1, #32
    5a18:	eb00003f 	cmp	x1, x0
    5a1c:	540000e2 	b.cs	5a38 <e161+0xc4>  // b.hs, b.nlast
    5a20:	8b010294 	add	x20, x20, x1
    5a24:	39400280 	ldrb	w0, [x20]
    5a28:	7103fc1f 	cmp	w0, #0xff
    5a2c:	54000280 	b.eq	5a7c <e161+0x108>  // b.none
    5a30:	52800020 	mov	w0, #0x1                   	// #1
    5a34:	39000280 	strb	w0, [x20]
    5a38:	aa1303e0 	mov	x0, x19
    5a3c:	97fffeea 	bl	55e4 <fwp_rc_share>
    5a40:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5a44:	f947f400 	ldr	x0, [x0, #4072]
    5a48:	f9400fe2 	ldr	x2, [sp, #24]
    5a4c:	f9400001 	ldr	x1, [x0]
    5a50:	eb010042 	subs	x2, x2, x1
    5a54:	d2800001 	mov	x1, #0x0                   	// #0
    5a58:	540001a1 	b.ne	5a8c <e161+0x118>  // b.any
    5a5c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5a60:	aa1303e0 	mov	x0, x19
    5a64:	a94353f3 	ldp	x19, x20, [sp, #48]
    5a68:	910103ff 	add	sp, sp, #0x40
    5a6c:	d65f03c0 	ret
    5a70:	72003c3f 	tst	w1, #0xffff
    5a74:	54fffe21 	b.ne	5a38 <e161+0xc4>  // b.any
    5a78:	17ffffeb 	b	5a24 <e161+0xb0>
    5a7c:	aa1403e0 	mov	x0, x20
    5a80:	97fffa9c 	bl	44f0 <fwp_rc_forget_slot>
    5a84:	17ffffeb 	b	5a30 <e161+0xbc>
    5a88:	97fff3de 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5a8c:	97fff359 	bl	27f0 <__stack_chk_fail@plt>

0000000000005a90 <fwp_drop1>:
    5a90:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5a94:	910003fd 	mov	x29, sp
    5a98:	a90153f3 	stp	x19, x20, [sp, #16]
    5a9c:	f90013f5 	str	x21, [sp, #32]
    5aa0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    5aa4:	911542b4 	add	x20, x21, #0x550
    5aa8:	f949da81 	ldr	x1, [x20, #5040]
    5aac:	f949ee82 	ldr	x2, [x20, #5080]
    5ab0:	cb010001 	sub	x1, x0, x1
    5ab4:	eb02403f 	cmp	x1, x2, lsl #16
    5ab8:	54000382 	b.cs	5b28 <fwp_drop1+0x98>  // b.hs, b.nlast
    5abc:	d350fc22 	lsr	x2, x1, #16
    5ac0:	f949fe84 	ldr	x4, [x20, #5112]
    5ac4:	8b020842 	add	x2, x2, x2, lsl #2
    5ac8:	d37df042 	lsl	x2, x2, #3
    5acc:	8b020083 	add	x3, x4, x2
    5ad0:	f9401073 	ldr	x19, [x3, #32]
    5ad4:	b40002b3 	cbz	x19, 5b28 <fwp_drop1+0x98>
    5ad8:	38626882 	ldrb	w2, [x4, x2]
    5adc:	7100085f 	cmp	w2, #0x2
    5ae0:	540002c0 	b.eq	5b38 <fwp_drop1+0xa8>  // b.none
    5ae4:	7100045f 	cmp	w2, #0x1
    5ae8:	54000201 	b.ne	5b28 <fwp_drop1+0x98>  // b.any
    5aec:	29430864 	ldp	w4, w2, [x3, #24]
    5af0:	92403c21 	and	x1, x1, #0xffff
    5af4:	9b047c21 	mul	x1, x1, x4
    5af8:	d360fc21 	lsr	x1, x1, #32
    5afc:	eb02003f 	cmp	x1, x2
    5b00:	54000142 	b.cs	5b28 <fwp_drop1+0x98>  // b.hs, b.nlast
    5b04:	8b010273 	add	x19, x19, x1
    5b08:	39400261 	ldrb	w1, [x19]
    5b0c:	340000e1 	cbz	w1, 5b28 <fwp_drop1+0x98>
    5b10:	7100043f 	cmp	w1, #0x1
    5b14:	540001e0 	b.eq	5b50 <fwp_drop1+0xc0>  // b.none
    5b18:	7103fc3f 	cmp	w1, #0xff
    5b1c:	540002e0 	b.eq	5b78 <fwp_drop1+0xe8>  // b.none
    5b20:	51000421 	sub	w1, w1, #0x1
    5b24:	39000261 	strb	w1, [x19]
    5b28:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b2c:	f94013f5 	ldr	x21, [sp, #32]
    5b30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b34:	d65f03c0 	ret
    5b38:	72003c3f 	tst	w1, #0xffff
    5b3c:	54fffe60 	b.eq	5b08 <fwp_drop1+0x78>  // b.none
    5b40:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b44:	f94013f5 	ldr	x21, [sp, #32]
    5b48:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b4c:	d65f03c0 	ret
    5b50:	f9400813 	ldr	x19, [x0, #16]
    5b54:	97fffefb 	bl	5740 <fwp_rc_free_arr>
    5b58:	911542a0 	add	x0, x21, #0x550
    5b5c:	f949d801 	ldr	x1, [x0, #5040]
    5b60:	f949ec00 	ldr	x0, [x0, #5080]
    5b64:	cb010261 	sub	x1, x19, x1
    5b68:	eb00403f 	cmp	x1, x0, lsl #16
    5b6c:	54fffde2 	b.cs	5b28 <fwp_drop1+0x98>  // b.hs, b.nlast
    5b70:	aa1303e0 	mov	x0, x19
    5b74:	17ffffd2 	b	5abc <fwp_drop1+0x2c>
    5b78:	ca534660 	eor	x0, x19, x19, lsr #17
    5b7c:	911542b5 	add	x21, x21, #0x550
    5b80:	ca402400 	eor	x0, x0, x0, lsr #9
    5b84:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5b88:	f94a2400 	ldr	x0, [x0, #5192]
    5b8c:	b5000080 	cbnz	x0, 5b9c <fwp_drop1+0x10c>
    5b90:	14000010 	b	5bd0 <fwp_drop1+0x140>
    5b94:	f9400800 	ldr	x0, [x0, #16]
    5b98:	b40001c0 	cbz	x0, 5bd0 <fwp_drop1+0x140>
    5b9c:	f9400001 	ldr	x1, [x0]
    5ba0:	eb13003f 	cmp	x1, x19
    5ba4:	54ffff81 	b.ne	5b94 <fwp_drop1+0x104>  // b.any
    5ba8:	f9400401 	ldr	x1, [x0, #8]
    5bac:	d1000421 	sub	x1, x1, #0x1
    5bb0:	f9000401 	str	x1, [x0, #8]
    5bb4:	f103f83f 	cmp	x1, #0xfe
    5bb8:	54fffb81 	b.ne	5b28 <fwp_drop1+0x98>  // b.any
    5bbc:	aa1303e0 	mov	x0, x19
    5bc0:	97fffa4c 	bl	44f0 <fwp_rc_forget_slot>
    5bc4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5bc8:	39000260 	strb	w0, [x19]
    5bcc:	17ffffd7 	b	5b28 <fwp_drop1+0x98>
    5bd0:	90000040 	adrp	x0, d000 <__modti3+0x1f0>
    5bd4:	91116000 	add	x0, x0, #0x458
    5bd8:	97fff64a 	bl	3500 <fwp_trap>
    5bdc:	d503201f 	nop

0000000000005be0 <fwp_drop0>:
    5be0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5be4:	910003fd 	mov	x29, sp
    5be8:	a90153f3 	stp	x19, x20, [sp, #16]
    5bec:	f90013f5 	str	x21, [sp, #32]
    5bf0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    5bf4:	911542b4 	add	x20, x21, #0x550
    5bf8:	f949da81 	ldr	x1, [x20, #5040]
    5bfc:	f949ee82 	ldr	x2, [x20, #5080]
    5c00:	cb010001 	sub	x1, x0, x1
    5c04:	eb02403f 	cmp	x1, x2, lsl #16
    5c08:	54000382 	b.cs	5c78 <fwp_drop0+0x98>  // b.hs, b.nlast
    5c0c:	d350fc22 	lsr	x2, x1, #16
    5c10:	f949fe84 	ldr	x4, [x20, #5112]
    5c14:	8b020842 	add	x2, x2, x2, lsl #2
    5c18:	d37df042 	lsl	x2, x2, #3
    5c1c:	8b020083 	add	x3, x4, x2
    5c20:	f9401073 	ldr	x19, [x3, #32]
    5c24:	b40002b3 	cbz	x19, 5c78 <fwp_drop0+0x98>
    5c28:	38626882 	ldrb	w2, [x4, x2]
    5c2c:	7100085f 	cmp	w2, #0x2
    5c30:	540002c0 	b.eq	5c88 <fwp_drop0+0xa8>  // b.none
    5c34:	7100045f 	cmp	w2, #0x1
    5c38:	54000201 	b.ne	5c78 <fwp_drop0+0x98>  // b.any
    5c3c:	29430864 	ldp	w4, w2, [x3, #24]
    5c40:	92403c21 	and	x1, x1, #0xffff
    5c44:	9b047c21 	mul	x1, x1, x4
    5c48:	d360fc21 	lsr	x1, x1, #32
    5c4c:	eb02003f 	cmp	x1, x2
    5c50:	54000142 	b.cs	5c78 <fwp_drop0+0x98>  // b.hs, b.nlast
    5c54:	8b010273 	add	x19, x19, x1
    5c58:	39400261 	ldrb	w1, [x19]
    5c5c:	340000e1 	cbz	w1, 5c78 <fwp_drop0+0x98>
    5c60:	7100043f 	cmp	w1, #0x1
    5c64:	540001e0 	b.eq	5ca0 <fwp_drop0+0xc0>  // b.none
    5c68:	7103fc3f 	cmp	w1, #0xff
    5c6c:	540002e0 	b.eq	5cc8 <fwp_drop0+0xe8>  // b.none
    5c70:	51000421 	sub	w1, w1, #0x1
    5c74:	39000261 	strb	w1, [x19]
    5c78:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c7c:	f94013f5 	ldr	x21, [sp, #32]
    5c80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c84:	d65f03c0 	ret
    5c88:	72003c3f 	tst	w1, #0xffff
    5c8c:	54fffe60 	b.eq	5c58 <fwp_drop0+0x78>  // b.none
    5c90:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c94:	f94013f5 	ldr	x21, [sp, #32]
    5c98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c9c:	d65f03c0 	ret
    5ca0:	f9400813 	ldr	x19, [x0, #16]
    5ca4:	97fffea7 	bl	5740 <fwp_rc_free_arr>
    5ca8:	911542a0 	add	x0, x21, #0x550
    5cac:	f949d801 	ldr	x1, [x0, #5040]
    5cb0:	f949ec00 	ldr	x0, [x0, #5080]
    5cb4:	cb010261 	sub	x1, x19, x1
    5cb8:	eb00403f 	cmp	x1, x0, lsl #16
    5cbc:	54fffde2 	b.cs	5c78 <fwp_drop0+0x98>  // b.hs, b.nlast
    5cc0:	aa1303e0 	mov	x0, x19
    5cc4:	17ffffd2 	b	5c0c <fwp_drop0+0x2c>
    5cc8:	ca534660 	eor	x0, x19, x19, lsr #17
    5ccc:	911542b5 	add	x21, x21, #0x550
    5cd0:	ca402400 	eor	x0, x0, x0, lsr #9
    5cd4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5cd8:	f94a2400 	ldr	x0, [x0, #5192]
    5cdc:	b5000080 	cbnz	x0, 5cec <fwp_drop0+0x10c>
    5ce0:	14000010 	b	5d20 <fwp_drop0+0x140>
    5ce4:	f9400800 	ldr	x0, [x0, #16]
    5ce8:	b40001c0 	cbz	x0, 5d20 <fwp_drop0+0x140>
    5cec:	f9400001 	ldr	x1, [x0]
    5cf0:	eb13003f 	cmp	x1, x19
    5cf4:	54ffff81 	b.ne	5ce4 <fwp_drop0+0x104>  // b.any
    5cf8:	f9400401 	ldr	x1, [x0, #8]
    5cfc:	d1000421 	sub	x1, x1, #0x1
    5d00:	f9000401 	str	x1, [x0, #8]
    5d04:	f103f83f 	cmp	x1, #0xfe
    5d08:	54fffb81 	b.ne	5c78 <fwp_drop0+0x98>  // b.any
    5d0c:	aa1303e0 	mov	x0, x19
    5d10:	97fff9f8 	bl	44f0 <fwp_rc_forget_slot>
    5d14:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5d18:	39000260 	strb	w0, [x19]
    5d1c:	17ffffd7 	b	5c78 <fwp_drop0+0x98>
    5d20:	90000040 	adrp	x0, d000 <__modti3+0x1f0>
    5d24:	91116000 	add	x0, x0, #0x458
    5d28:	97fff5f6 	bl	3500 <fwp_trap>
    5d2c:	d503201f 	nop

0000000000005d30 <fwp_arg_drop12>:
    5d30:	7100003f 	cmp	w1, #0x0
    5d34:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5d38:	54000041 	b.ne	5d40 <fwp_arg_drop12+0x10>  // b.any
    5d3c:	d65f03c0 	ret
    5d40:	f9400000 	ldr	x0, [x0]
    5d44:	17ffffa7 	b	5be0 <fwp_drop0>
    5d48:	d503201f 	nop
    5d4c:	d503201f 	nop

0000000000005d50 <fwp_closure_drop>:
    5d50:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc90>
    5d54:	911540a4 	add	x4, x5, #0x550
    5d58:	aa0003e1 	mov	x1, x0
    5d5c:	f949d882 	ldr	x2, [x4, #5040]
    5d60:	f949ec80 	ldr	x0, [x4, #5080]
    5d64:	cb020022 	sub	x2, x1, x2
    5d68:	eb00405f 	cmp	x2, x0, lsl #16
    5d6c:	54000662 	b.cs	5e38 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5d70:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5d74:	d350fc43 	lsr	x3, x2, #16
    5d78:	910003fd 	mov	x29, sp
    5d7c:	8b030863 	add	x3, x3, x3, lsl #2
    5d80:	f949fc84 	ldr	x4, [x4, #5112]
    5d84:	d37df063 	lsl	x3, x3, #3
    5d88:	f9000bf3 	str	x19, [sp, #16]
    5d8c:	8b030080 	add	x0, x4, x3
    5d90:	f9401013 	ldr	x19, [x0, #32]
    5d94:	b40002b3 	cbz	x19, 5de8 <fwp_closure_drop+0x98>
    5d98:	38636883 	ldrb	w3, [x4, x3]
    5d9c:	7100087f 	cmp	w3, #0x2
    5da0:	54000420 	b.eq	5e24 <fwp_closure_drop+0xd4>  // b.none
    5da4:	7100047f 	cmp	w3, #0x1
    5da8:	54000201 	b.ne	5de8 <fwp_closure_drop+0x98>  // b.any
    5dac:	29430003 	ldp	w3, w0, [x0, #24]
    5db0:	92403c42 	and	x2, x2, #0xffff
    5db4:	9b037c42 	mul	x2, x2, x3
    5db8:	d360fc42 	lsr	x2, x2, #32
    5dbc:	eb00005f 	cmp	x2, x0
    5dc0:	54000142 	b.cs	5de8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5dc4:	8b020273 	add	x19, x19, x2
    5dc8:	39400260 	ldrb	w0, [x19]
    5dcc:	340000e0 	cbz	w0, 5de8 <fwp_closure_drop+0x98>
    5dd0:	7100041f 	cmp	w0, #0x1
    5dd4:	54000100 	b.eq	5df4 <fwp_closure_drop+0xa4>  // b.none
    5dd8:	7103fc1f 	cmp	w0, #0xff
    5ddc:	54000300 	b.eq	5e3c <fwp_closure_drop+0xec>  // b.none
    5de0:	51000400 	sub	w0, w0, #0x1
    5de4:	39000260 	strb	w0, [x19]
    5de8:	f9400bf3 	ldr	x19, [sp, #16]
    5dec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5df0:	d65f03c0 	ret
    5df4:	d53bd040 	mrs	x0, tpidr_el0
    5df8:	91400000 	add	x0, x0, #0x0, lsl #12
    5dfc:	91004000 	add	x0, x0, #0x10
    5e00:	f9400000 	ldr	x0, [x0]
    5e04:	b4000080 	cbz	x0, 5e14 <fwp_closure_drop+0xc4>
    5e08:	f9400bf3 	ldr	x19, [sp, #16]
    5e0c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e10:	17fff5d5 	b	3564 <fwp_closure_drop_push>
    5e14:	f9400bf3 	ldr	x19, [sp, #16]
    5e18:	aa0103e0 	mov	x0, x1
    5e1c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e20:	17fff640 	b	3720 <fwp_closure_drop.part.0>
    5e24:	72003c5f 	tst	w2, #0xffff
    5e28:	54fffd00 	b.eq	5dc8 <fwp_closure_drop+0x78>  // b.none
    5e2c:	f9400bf3 	ldr	x19, [sp, #16]
    5e30:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e34:	d65f03c0 	ret
    5e38:	d65f03c0 	ret
    5e3c:	ca534660 	eor	x0, x19, x19, lsr #17
    5e40:	911540a5 	add	x5, x5, #0x550
    5e44:	ca402400 	eor	x0, x0, x0, lsr #9
    5e48:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5e4c:	f94a2400 	ldr	x0, [x0, #5192]
    5e50:	b5000080 	cbnz	x0, 5e60 <fwp_closure_drop+0x110>
    5e54:	14000010 	b	5e94 <fwp_closure_drop+0x144>
    5e58:	f9400800 	ldr	x0, [x0, #16]
    5e5c:	b40001c0 	cbz	x0, 5e94 <fwp_closure_drop+0x144>
    5e60:	f9400001 	ldr	x1, [x0]
    5e64:	eb13003f 	cmp	x1, x19
    5e68:	54ffff81 	b.ne	5e58 <fwp_closure_drop+0x108>  // b.any
    5e6c:	f9400401 	ldr	x1, [x0, #8]
    5e70:	d1000421 	sub	x1, x1, #0x1
    5e74:	f9000401 	str	x1, [x0, #8]
    5e78:	f103f83f 	cmp	x1, #0xfe
    5e7c:	54fffb61 	b.ne	5de8 <fwp_closure_drop+0x98>  // b.any
    5e80:	aa1303e0 	mov	x0, x19
    5e84:	97fff99b 	bl	44f0 <fwp_rc_forget_slot>
    5e88:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e8c:	39000260 	strb	w0, [x19]
    5e90:	17ffffd6 	b	5de8 <fwp_closure_drop+0x98>
    5e94:	90000040 	adrp	x0, d000 <__modti3+0x1f0>
    5e98:	91116000 	add	x0, x0, #0x458
    5e9c:	97fff599 	bl	3500 <fwp_trap>

0000000000005ea0 <fwp_owned_tape_release>:
    5ea0:	b4000940 	cbz	x0, 5fc8 <fwp_owned_tape_release+0x128>
    5ea4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ea8:	910003fd 	mov	x29, sp
    5eac:	a90153f3 	stp	x19, x20, [sp, #16]
    5eb0:	aa0003f3 	mov	x19, x0
    5eb4:	f9400000 	ldr	x0, [x0]
    5eb8:	b4000060 	cbz	x0, 5ec4 <fwp_owned_tape_release+0x24>
    5ebc:	f9400661 	ldr	x1, [x19, #8]
    5ec0:	f9000401 	str	x1, [x0, #8]
    5ec4:	f9400661 	ldr	x1, [x19, #8]
    5ec8:	b4000041 	cbz	x1, 5ed0 <fwp_owned_tape_release+0x30>
    5ecc:	f9000020 	str	x0, [x1]
    5ed0:	f9400a60 	ldr	x0, [x19, #16]
    5ed4:	f9403401 	ldr	x1, [x0, #104]
    5ed8:	b40005c1 	cbz	x1, 5f90 <fwp_owned_tape_release+0xf0>
    5edc:	a9450a60 	ldp	x0, x2, [x19, #80]
    5ee0:	eb00005f 	cmp	x2, x0
    5ee4:	540002ed 	b.le	5f40 <fwp_owned_tape_release+0xa0>
    5ee8:	d2800014 	mov	x20, #0x0                   	// #0
    5eec:	f90013f5 	str	x21, [sp, #32]
    5ef0:	d2800015 	mov	x21, #0x0                   	// #0
    5ef4:	d503201f 	nop
    5ef8:	f9402260 	ldr	x0, [x19, #64]
    5efc:	910006b5 	add	x21, x21, #0x1
    5f00:	f8746800 	ldr	x0, [x0, x20]
    5f04:	d63f0020 	blr	x1
    5f08:	f9402260 	ldr	x0, [x19, #64]
    5f0c:	f9400a61 	ldr	x1, [x19, #16]
    5f10:	8b140000 	add	x0, x0, x20
    5f14:	91004294 	add	x20, x20, #0x10
    5f18:	f9400400 	ldr	x0, [x0, #8]
    5f1c:	f9403421 	ldr	x1, [x1, #104]
    5f20:	d63f0020 	blr	x1
    5f24:	a9450261 	ldp	x1, x0, [x19, #80]
    5f28:	cb010000 	sub	x0, x0, x1
    5f2c:	eb15001f 	cmp	x0, x21
    5f30:	f9400a60 	ldr	x0, [x19, #16]
    5f34:	f9403401 	ldr	x1, [x0, #104]
    5f38:	54fffe0c 	b.gt	5ef8 <fwp_owned_tape_release+0x58>
    5f3c:	f94013f5 	ldr	x21, [sp, #32]
    5f40:	f9403663 	ldr	x3, [x19, #104]
    5f44:	f9401262 	ldr	x2, [x19, #32]
    5f48:	f100007f 	cmp	x3, #0x0
    5f4c:	540001ed 	b.le	5f88 <fwp_owned_tape_release+0xe8>
    5f50:	d2800014 	mov	x20, #0x0                   	// #0
    5f54:	d503201f 	nop
    5f58:	f9402660 	ldr	x0, [x19, #72]
    5f5c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5f60:	eb02001f 	cmp	x0, x2
    5f64:	540000c0 	b.eq	5f7c <fwp_owned_tape_release+0xdc>  // b.none
    5f68:	d63f0020 	blr	x1
    5f6c:	f9400a60 	ldr	x0, [x19, #16]
    5f70:	f9401262 	ldr	x2, [x19, #32]
    5f74:	f9403663 	ldr	x3, [x19, #104]
    5f78:	f9403401 	ldr	x1, [x0, #104]
    5f7c:	91000694 	add	x20, x20, #0x1
    5f80:	eb14007f 	cmp	x3, x20
    5f84:	54fffeac 	b.gt	5f58 <fwp_owned_tape_release+0xb8>
    5f88:	aa0203e0 	mov	x0, x2
    5f8c:	d63f0020 	blr	x1
    5f90:	f9401660 	ldr	x0, [x19, #40]
    5f94:	97ffff6f 	bl	5d50 <fwp_closure_drop>
    5f98:	f9401a60 	ldr	x0, [x19, #48]
    5f9c:	97ffff6d 	bl	5d50 <fwp_closure_drop>
    5fa0:	f9401e60 	ldr	x0, [x19, #56]
    5fa4:	97ffff6b 	bl	5d50 <fwp_closure_drop>
    5fa8:	f9402260 	ldr	x0, [x19, #64]
    5fac:	97fff9f1 	bl	4770 <fwp_mem_free>
    5fb0:	f9402660 	ldr	x0, [x19, #72]
    5fb4:	97fff9ef 	bl	4770 <fwp_mem_free>
    5fb8:	aa1303e0 	mov	x0, x19
    5fbc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fc0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fc4:	17fff9eb 	b	4770 <fwp_mem_free>
    5fc8:	d65f03c0 	ret
    5fcc:	d503201f 	nop

0000000000005fd0 <fwp_tape_finish>:
    5fd0:	d10203ff 	sub	sp, sp, #0x80
    5fd4:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    5fd8:	f947f421 	ldr	x1, [x1, #4072]
    5fdc:	a9047bfd 	stp	x29, x30, [sp, #64]
    5fe0:	910103fd 	add	x29, sp, #0x40
    5fe4:	a90553f3 	stp	x19, x20, [sp, #80]
    5fe8:	a9065bf5 	stp	x21, x22, [sp, #96]
    5fec:	a90763f7 	stp	x23, x24, [sp, #112]
    5ff0:	f00000d8 	adrp	x24, 20000 <__data_start>
    5ff4:	91010316 	add	x22, x24, #0x40
    5ff8:	f9400022 	ldr	x2, [x1]
    5ffc:	f9001fe2 	str	x2, [sp, #56]
    6000:	d2800002 	mov	x2, #0x0                   	// #0
    6004:	910122c0 	add	x0, x22, #0x48
    6008:	97fff49e 	bl	3280 <fwp_tape_buffers_dispose>
    600c:	f90042df 	str	xzr, [x22, #128]
    6010:	f94022c0 	ldr	x0, [x22, #64]
    6014:	f100001f 	cmp	x0, #0x0
    6018:	5400030d 	b.le	6078 <fwp_tape_finish+0xa8>
    601c:	910003f7 	mov	x23, sp
    6020:	d2800015 	mov	x21, #0x0                   	// #0
    6024:	d2800014 	mov	x20, #0x0                   	// #0
    6028:	f94002d3 	ldr	x19, [x22]
    602c:	91000694 	add	x20, x20, #0x1
    6030:	8b150273 	add	x19, x19, x21
    6034:	9101a2b5 	add	x21, x21, #0x68
    6038:	aa1303e0 	mov	x0, x19
    603c:	97fff3b5 	bl	2f10 <fwp_tape_unlink_scope>
    6040:	aa1703e0 	mov	x0, x23
    6044:	f9401261 	ldr	x1, [x19, #32]
    6048:	f90003e1 	str	x1, [sp]
    604c:	f9401a62 	ldr	x2, [x19, #48]
    6050:	f9000be2 	str	x2, [sp, #16]
    6054:	f9402261 	ldr	x1, [x19, #64]
    6058:	f90013e1 	str	x1, [sp, #32]
    605c:	97fff489 	bl	3280 <fwp_tape_buffers_dispose>
    6060:	f9403260 	ldr	x0, [x19, #96]
    6064:	97ffff8f 	bl	5ea0 <fwp_owned_tape_release>
    6068:	f900327f 	str	xzr, [x19, #96]
    606c:	f94022c0 	ldr	x0, [x22, #64]
    6070:	eb14001f 	cmp	x0, x20
    6074:	54fffdac 	b.gt	6028 <fwp_tape_finish+0x58>
    6078:	f9402300 	ldr	x0, [x24, #64]
    607c:	91010313 	add	x19, x24, #0x40
    6080:	97fff20c 	bl	28b0 <free@plt>
    6084:	f900231f 	str	xzr, [x24, #64]
    6088:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    608c:	f947f400 	ldr	x0, [x0, #4072]
    6090:	f900227f 	str	xzr, [x19, #64]
    6094:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    6098:	f9401fe2 	ldr	x2, [sp, #56]
    609c:	f9400001 	ldr	x1, [x0]
    60a0:	eb010042 	subs	x2, x2, x1
    60a4:	d2800001 	mov	x1, #0x0                   	// #0
    60a8:	540000e1 	b.ne	60c4 <fwp_tape_finish+0xf4>  // b.any
    60ac:	a9447bfd 	ldp	x29, x30, [sp, #64]
    60b0:	a94553f3 	ldp	x19, x20, [sp, #80]
    60b4:	a9465bf5 	ldp	x21, x22, [sp, #96]
    60b8:	a94763f7 	ldp	x23, x24, [sp, #112]
    60bc:	910203ff 	add	sp, sp, #0x80
    60c0:	d65f03c0 	ret
    60c4:	97fff1cb 	bl	27f0 <__stack_chk_fail@plt>
    60c8:	d503201f 	nop
    60cc:	d503201f 	nop

00000000000060d0 <fwp_tape_scope_release>:
    60d0:	d10243ff 	sub	sp, sp, #0x90
    60d4:	a9047bfd 	stp	x29, x30, [sp, #64]
    60d8:	910103fd 	add	x29, sp, #0x40
    60dc:	a90553f3 	stp	x19, x20, [sp, #80]
    60e0:	aa0003f4 	mov	x20, x0
    60e4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    60e8:	f947f400 	ldr	x0, [x0, #4072]
    60ec:	b9400285 	ldr	w5, [x20]
    60f0:	f9400001 	ldr	x1, [x0]
    60f4:	f9001fe1 	str	x1, [sp, #56]
    60f8:	d2800001 	mov	x1, #0x0                   	// #0
    60fc:	37f806c5 	tbnz	w5, #31, 61d4 <fwp_tape_scope_release+0x104>
    6100:	a90763f7 	stp	x23, x24, [sp, #112]
    6104:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6108:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    610c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6110:	d00000d3 	adrp	x19, 20000 <__data_start>
    6114:	910003f7 	mov	x23, sp
    6118:	91010273 	add	x19, x19, #0x40
    611c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6120:	a9065bf5 	stp	x21, x22, [sp, #96]
    6124:	52800d16 	mov	w22, #0x68                  	// #104
    6128:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    612c:	f90043f9 	str	x25, [sp, #128]
    6130:	14000006 	b	6148 <fwp_tape_scope_release+0x78>
    6134:	97fff453 	bl	3280 <fwp_tape_buffers_dispose>
    6138:	aa1903e0 	mov	x0, x25
    613c:	97ffff59 	bl	5ea0 <fwp_owned_tape_release>
    6140:	b9400285 	ldr	w5, [x20]
    6144:	37f80425 	tbnz	w5, #31, 61c8 <fwp_tape_scope_release+0xf8>
    6148:	f9400266 	ldr	x6, [x19]
    614c:	9b367ca5 	smull	x5, w5, w22
    6150:	8b0500c0 	add	x0, x6, x5
    6154:	97fff36f 	bl	2f10 <fwp_tape_unlink_scope>
    6158:	ad410001 	ldp	q1, q0, [x0, #32]
    615c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6160:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6164:	f9400c03 	ldr	x3, [x0, #24]
    6168:	ad0003e1 	stp	q1, q0, [sp]
    616c:	b86568c1 	ldr	w1, [x6, x5]
    6170:	a9440804 	ldp	x4, x2, [x0, #64]
    6174:	b900041f 	str	wzr, [x0, #4]
    6178:	f9403019 	ldr	x25, [x0, #96]
    617c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6180:	f9000c1f 	str	xzr, [x0, #24]
    6184:	a9020fe4 	stp	x4, x3, [sp, #32]
    6188:	f9001be2 	str	x2, [sp, #48]
    618c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6190:	f900301f 	str	xzr, [x0, #96]
    6194:	6b15003f 	cmp	w1, w21
    6198:	540000e8 	b.hi	61b4 <fwp_tape_scope_release+0xe4>  // b.pmore
    619c:	9343fca5 	asr	x5, x5, #3
    61a0:	f9404e60 	ldr	x0, [x19, #152]
    61a4:	9b187ca5 	mul	x5, x5, x24
    61a8:	eb0000bf 	cmp	x5, x0
    61ac:	5400004a 	b.ge	61b4 <fwp_tape_scope_release+0xe4>  // b.tcont
    61b0:	f9004e65 	str	x5, [x19, #152]
    61b4:	aa1703e0 	mov	x0, x23
    61b8:	b5fffbf9 	cbnz	x25, 6134 <fwp_tape_scope_release+0x64>
    61bc:	97fff7b1 	bl	4080 <fwp_tape_buffers_release>
    61c0:	b9400285 	ldr	w5, [x20]
    61c4:	36fffc25 	tbz	w5, #31, 6148 <fwp_tape_scope_release+0x78>
    61c8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    61cc:	a94763f7 	ldp	x23, x24, [sp, #112]
    61d0:	f94043f9 	ldr	x25, [sp, #128]
    61d4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    61d8:	f947f400 	ldr	x0, [x0, #4072]
    61dc:	f9401fe2 	ldr	x2, [sp, #56]
    61e0:	f9400001 	ldr	x1, [x0]
    61e4:	eb010042 	subs	x2, x2, x1
    61e8:	d2800001 	mov	x1, #0x0                   	// #0
    61ec:	540000a1 	b.ne	6200 <fwp_tape_scope_release+0x130>  // b.any
    61f0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    61f4:	a94553f3 	ldp	x19, x20, [sp, #80]
    61f8:	910243ff 	add	sp, sp, #0x90
    61fc:	d65f03c0 	ret
    6200:	a9065bf5 	stp	x21, x22, [sp, #96]
    6204:	a90763f7 	stp	x23, x24, [sp, #112]
    6208:	f90043f9 	str	x25, [sp, #128]
    620c:	97fff179 	bl	27f0 <__stack_chk_fail@plt>

0000000000006210 <fwp_task_dispose>:
    6210:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6214:	910003fd 	mov	x29, sp
    6218:	f9000bf3 	str	x19, [sp, #16]
    621c:	aa0003f3 	mov	x19, x0
    6220:	39414000 	ldrb	w0, [x0, #80]
    6224:	36000720 	tbz	w0, #0, 6308 <fwp_task_dispose+0xf8>
    6228:	f9400a60 	ldr	x0, [x19, #16]
    622c:	b50006e0 	cbnz	x0, 6308 <fwp_task_dispose+0xf8>
    6230:	a9478660 	ldp	x0, x1, [x19, #120]
    6234:	39014e7f 	strb	wzr, [x19, #83]
    6238:	f9003e7f 	str	xzr, [x19, #120]
    623c:	f100003f 	cmp	x1, #0x0
    6240:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6244:	54000040 	b.eq	624c <fwp_task_dispose+0x3c>  // b.none
    6248:	d63f0020 	blr	x1
    624c:	f9405660 	ldr	x0, [x19, #168]
    6250:	97fff948 	bl	4770 <fwp_mem_free>
    6254:	f900567f 	str	xzr, [x19, #168]
    6258:	b9405e60 	ldr	w0, [x19, #92]
    625c:	7100041f 	cmp	w0, #0x1
    6260:	54000420 	b.eq	62e4 <fwp_task_dispose+0xd4>  // b.none
    6264:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6268:	91154042 	add	x2, x2, #0x550
    626c:	f949d840 	ldr	x0, [x2, #5040]
    6270:	f949ec41 	ldr	x1, [x2, #5080]
    6274:	cb000260 	sub	x0, x19, x0
    6278:	eb01401f 	cmp	x0, x1, lsl #16
    627c:	540002e2 	b.cs	62d8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6280:	d350fc01 	lsr	x1, x0, #16
    6284:	f949fc44 	ldr	x4, [x2, #5112]
    6288:	8b010821 	add	x1, x1, x1, lsl #2
    628c:	d37df021 	lsl	x1, x1, #3
    6290:	8b010083 	add	x3, x4, x1
    6294:	f9401062 	ldr	x2, [x3, #32]
    6298:	b4000202 	cbz	x2, 62d8 <fwp_task_dispose+0xc8>
    629c:	38616881 	ldrb	w1, [x4, x1]
    62a0:	7100083f 	cmp	w1, #0x2
    62a4:	54000280 	b.eq	62f4 <fwp_task_dispose+0xe4>  // b.none
    62a8:	7100043f 	cmp	w1, #0x1
    62ac:	54000161 	b.ne	62d8 <fwp_task_dispose+0xc8>  // b.any
    62b0:	29430464 	ldp	w4, w1, [x3, #24]
    62b4:	92403c00 	and	x0, x0, #0xffff
    62b8:	9b047c00 	mul	x0, x0, x4
    62bc:	d360fc00 	lsr	x0, x0, #32
    62c0:	eb01001f 	cmp	x0, x1
    62c4:	540000a2 	b.cs	62d8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    62c8:	8b000042 	add	x2, x2, x0
    62cc:	39400040 	ldrb	w0, [x2]
    62d0:	7100041f 	cmp	w0, #0x1
    62d4:	54000080 	b.eq	62e4 <fwp_task_dispose+0xd4>  // b.none
    62d8:	f9400bf3 	ldr	x19, [sp, #16]
    62dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    62e0:	d65f03c0 	ret
    62e4:	aa1303e0 	mov	x0, x19
    62e8:	f9400bf3 	ldr	x19, [sp, #16]
    62ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    62f0:	17fff920 	b	4770 <fwp_mem_free>
    62f4:	72003c1f 	tst	w0, #0xffff
    62f8:	54fffea0 	b.eq	62cc <fwp_task_dispose+0xbc>  // b.none
    62fc:	f9400bf3 	ldr	x19, [sp, #16]
    6300:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6304:	d65f03c0 	ret
    6308:	97fff14e 	bl	2840 <abort@plt>
    630c:	d503201f 	nop

0000000000006310 <fwp_free_zombie>:
    6310:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6314:	910003fd 	mov	x29, sp
    6318:	a90153f3 	stp	x19, x20, [sp, #16]
    631c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6320:	91010281 	add	x1, x20, #0x40
    6324:	f9405033 	ldr	x19, [x1, #160]
    6328:	b4000333 	cbz	x19, 638c <fwp_free_zombie+0x7c>
    632c:	f9400820 	ldr	x0, [x1, #16]
    6330:	eb00027f 	cmp	x19, x0
    6334:	540002c0 	b.eq	638c <fwp_free_zombie+0x7c>  // b.none
    6338:	b940a822 	ldr	w2, [x1, #168]
    633c:	f9400a60 	ldr	x0, [x19, #16]
    6340:	7100fc5f 	cmp	w2, #0x3f
    6344:	5400078c 	b.gt	6434 <fwp_free_zombie+0x124>
    6348:	9102c023 	add	x3, x1, #0xb0
    634c:	11000444 	add	w4, w2, #0x1
    6350:	b900a824 	str	w4, [x1, #168]
    6354:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6358:	f822d860 	str	x0, [x3, w2, sxtw #3]
    635c:	a9530261 	ldp	x1, x0, [x19, #304]
    6360:	b4000741 	cbz	x1, 6448 <fwp_free_zombie+0x138>
    6364:	f9009c20 	str	x0, [x1, #312]
    6368:	b4000040 	cbz	x0, 6370 <fwp_free_zombie+0x60>
    636c:	f9009801 	str	x1, [x0, #304]
    6370:	91010294 	add	x20, x20, #0x40
    6374:	b9405e60 	ldr	w0, [x19, #92]
    6378:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    637c:	f900529f 	str	xzr, [x20, #160]
    6380:	34000140 	cbz	w0, 63a8 <fwp_free_zombie+0x98>
    6384:	7100041f 	cmp	w0, #0x1
    6388:	54000080 	b.eq	6398 <fwp_free_zombie+0x88>  // b.none
    638c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6390:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6394:	d65f03c0 	ret
    6398:	aa1303e0 	mov	x0, x19
    639c:	a94153f3 	ldp	x19, x20, [sp, #16]
    63a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    63a4:	17ffff9b 	b	6210 <fwp_task_dispose>
    63a8:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc90>
    63ac:	91154082 	add	x2, x4, #0x550
    63b0:	f949d841 	ldr	x1, [x2, #5040]
    63b4:	f949ec40 	ldr	x0, [x2, #5080]
    63b8:	cb010261 	sub	x1, x19, x1
    63bc:	eb00403f 	cmp	x1, x0, lsl #16
    63c0:	54fffe62 	b.cs	638c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    63c4:	d350fc20 	lsr	x0, x1, #16
    63c8:	f949fc43 	ldr	x3, [x2, #5112]
    63cc:	8b000800 	add	x0, x0, x0, lsl #2
    63d0:	d37df000 	lsl	x0, x0, #3
    63d4:	8b000062 	add	x2, x3, x0
    63d8:	f9401054 	ldr	x20, [x2, #32]
    63dc:	b4fffd94 	cbz	x20, 638c <fwp_free_zombie+0x7c>
    63e0:	38606860 	ldrb	w0, [x3, x0]
    63e4:	7100081f 	cmp	w0, #0x2
    63e8:	54000360 	b.eq	6454 <fwp_free_zombie+0x144>  // b.none
    63ec:	7100041f 	cmp	w0, #0x1
    63f0:	54fffce1 	b.ne	638c <fwp_free_zombie+0x7c>  // b.any
    63f4:	29430043 	ldp	w3, w0, [x2, #24]
    63f8:	92403c21 	and	x1, x1, #0xffff
    63fc:	9b037c21 	mul	x1, x1, x3
    6400:	d360fc21 	lsr	x1, x1, #32
    6404:	eb00003f 	cmp	x1, x0
    6408:	54fffc22 	b.cs	638c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    640c:	8b010294 	add	x20, x20, x1
    6410:	39400280 	ldrb	w0, [x20]
    6414:	34fffbc0 	cbz	w0, 638c <fwp_free_zombie+0x7c>
    6418:	7100041f 	cmp	w0, #0x1
    641c:	54fffbe0 	b.eq	6398 <fwp_free_zombie+0x88>  // b.none
    6420:	7103fc1f 	cmp	w0, #0xff
    6424:	540001e0 	b.eq	6460 <fwp_free_zombie+0x150>  // b.none
    6428:	51000400 	sub	w0, w0, #0x1
    642c:	39000280 	strb	w0, [x20]
    6430:	17ffffd7 	b	638c <fwp_free_zombie+0x7c>
    6434:	f9400e61 	ldr	x1, [x19, #24]
    6438:	97fff136 	bl	2910 <munmap@plt>
    643c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6440:	a9530261 	ldp	x1, x0, [x19, #304]
    6444:	b5fff901 	cbnz	x1, 6364 <fwp_free_zombie+0x54>
    6448:	91010282 	add	x2, x20, #0x40
    644c:	f9015840 	str	x0, [x2, #688]
    6450:	17ffffc6 	b	6368 <fwp_free_zombie+0x58>
    6454:	72003c3f 	tst	w1, #0xffff
    6458:	54fff9a1 	b.ne	638c <fwp_free_zombie+0x7c>  // b.any
    645c:	17ffffed 	b	6410 <fwp_free_zombie+0x100>
    6460:	ca544680 	eor	x0, x20, x20, lsr #17
    6464:	91154084 	add	x4, x4, #0x550
    6468:	ca402400 	eor	x0, x0, x0, lsr #9
    646c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6470:	f94a2400 	ldr	x0, [x0, #5192]
    6474:	b5000080 	cbnz	x0, 6484 <fwp_free_zombie+0x174>
    6478:	14000010 	b	64b8 <fwp_free_zombie+0x1a8>
    647c:	f9400800 	ldr	x0, [x0, #16]
    6480:	b40001c0 	cbz	x0, 64b8 <fwp_free_zombie+0x1a8>
    6484:	f9400001 	ldr	x1, [x0]
    6488:	eb14003f 	cmp	x1, x20
    648c:	54ffff81 	b.ne	647c <fwp_free_zombie+0x16c>  // b.any
    6490:	f9400401 	ldr	x1, [x0, #8]
    6494:	d1000421 	sub	x1, x1, #0x1
    6498:	f9000401 	str	x1, [x0, #8]
    649c:	f103f83f 	cmp	x1, #0xfe
    64a0:	54fff761 	b.ne	638c <fwp_free_zombie+0x7c>  // b.any
    64a4:	aa1403e0 	mov	x0, x20
    64a8:	97fff812 	bl	44f0 <fwp_rc_forget_slot>
    64ac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    64b0:	39000280 	strb	w0, [x20]
    64b4:	17ffffb6 	b	638c <fwp_free_zombie+0x7c>
    64b8:	f0000020 	adrp	x0, d000 <__modti3+0x1f0>
    64bc:	91116000 	add	x0, x0, #0x458
    64c0:	97fff410 	bl	3500 <fwp_trap>

00000000000064c4 <fwp_block>:
    64c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    64c8:	910003fd 	mov	x29, sp
    64cc:	a90153f3 	stp	x19, x20, [sp, #16]
    64d0:	d00000d3 	adrp	x19, 20000 <__data_start>
    64d4:	91010274 	add	x20, x19, #0x40
    64d8:	f9401a82 	ldr	x2, [x20, #48]
    64dc:	b4000622 	cbz	x2, 65a0 <fwp_block+0xdc>
    64e0:	91010261 	add	x1, x19, #0x40
    64e4:	f9408040 	ldr	x0, [x2, #256]
    64e8:	f9001820 	str	x0, [x1, #48]
    64ec:	b4000680 	cbz	x0, 65bc <fwp_block+0xf8>
    64f0:	91010263 	add	x3, x19, #0x40
    64f4:	3901505f 	strb	wzr, [x2, #84]
    64f8:	f9400864 	ldr	x4, [x3, #16]
    64fc:	eb02009f 	cmp	x4, x2
    6500:	54000440 	b.eq	6588 <fwp_block+0xc4>  // b.none
    6504:	f9415c65 	ldr	x5, [x3, #696]
    6508:	f9000862 	str	x2, [x3, #16]
    650c:	f9400441 	ldr	x1, [x2, #8]
    6510:	f9004885 	str	x5, [x4, #144]
    6514:	f9416065 	ldr	x5, [x3, #704]
    6518:	f9004c85 	str	x5, [x4, #152]
    651c:	f9416465 	ldr	x5, [x3, #712]
    6520:	f9005085 	str	x5, [x4, #160]
    6524:	f9416865 	ldr	x5, [x3, #720]
    6528:	f9005485 	str	x5, [x4, #168]
    652c:	f9416c65 	ldr	x5, [x3, #728]
    6530:	f9005885 	str	x5, [x4, #176]
    6534:	f9417065 	ldr	x5, [x3, #736]
    6538:	f9005c85 	str	x5, [x4, #184]
    653c:	f9417465 	ldr	x5, [x3, #744]
    6540:	f9006085 	str	x5, [x4, #192]
    6544:	f9400480 	ldr	x0, [x4, #8]
    6548:	f9404844 	ldr	x4, [x2, #144]
    654c:	f9015c64 	str	x4, [x3, #696]
    6550:	f9404c44 	ldr	x4, [x2, #152]
    6554:	f9016064 	str	x4, [x3, #704]
    6558:	f9405044 	ldr	x4, [x2, #160]
    655c:	f9016464 	str	x4, [x3, #712]
    6560:	f9405444 	ldr	x4, [x2, #168]
    6564:	f9016864 	str	x4, [x3, #720]
    6568:	f9405844 	ldr	x4, [x2, #176]
    656c:	f9016c64 	str	x4, [x3, #728]
    6570:	a94b8844 	ldp	x4, x2, [x2, #184]
    6574:	f9017064 	str	x4, [x3, #736]
    6578:	f9017462 	str	x2, [x3, #744]
    657c:	97fff0b5 	bl	2850 <swapcontext@plt>
    6580:	97ffff64 	bl	6310 <fwp_free_zombie>
    6584:	d503201f 	nop
    6588:	91010260 	add	x0, x19, #0x40
    658c:	b942f000 	ldr	w0, [x0, #752]
    6590:	340001a0 	cbz	w0, 65c4 <fwp_block+0x100>
    6594:	a94153f3 	ldp	x19, x20, [sp, #16]
    6598:	a8c27bfd 	ldp	x29, x30, [sp], #32
    659c:	d65f03c0 	ret
    65a0:	97fff700 	bl	41a0 <fwp_poll_events>
    65a4:	f9401a82 	ldr	x2, [x20, #48]
    65a8:	b4ffffc2 	cbz	x2, 65a0 <fwp_block+0xdc>
    65ac:	91010261 	add	x1, x19, #0x40
    65b0:	f9408040 	ldr	x0, [x2, #256]
    65b4:	f9001820 	str	x0, [x1, #48]
    65b8:	b5fff9c0 	cbnz	x0, 64f0 <fwp_block+0x2c>
    65bc:	f900143f 	str	xzr, [x1, #40]
    65c0:	17ffffcc 	b	64f0 <fwp_block+0x2c>
    65c4:	f0000020 	adrp	x0, d000 <__modti3+0x1f0>
    65c8:	91162000 	add	x0, x0, #0x588
    65cc:	97fff0ed 	bl	2980 <getenv@plt>
    65d0:	5284e202 	mov	w2, #0x2710                	// #10000
    65d4:	b4000060 	cbz	x0, 65e0 <fwp_block+0x11c>
    65d8:	39400001 	ldrb	w1, [x0]
    65dc:	350000c1 	cbnz	w1, 65f4 <fwp_block+0x130>
    65e0:	91010273 	add	x19, x19, #0x40
    65e4:	b902f262 	str	w2, [x19, #752]
    65e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    65ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    65f0:	d65f03c0 	ret
    65f4:	52800142 	mov	w2, #0xa                   	// #10
    65f8:	d2800001 	mov	x1, #0x0                   	// #0
    65fc:	97fff031 	bl	26c0 <strtoll@plt>
    6600:	d1000403 	sub	x3, x0, #0x1
    6604:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6608:	eb02007f 	cmp	x3, x2
    660c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6610:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6614:	17fffff3 	b	65e0 <fwp_block+0x11c>
    6618:	d503201f 	nop
    661c:	d503201f 	nop

0000000000006620 <fwp_drop4>:
    6620:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6624:	910003fd 	mov	x29, sp
    6628:	a90153f3 	stp	x19, x20, [sp, #16]
    662c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc90>
    6630:	f90013f5 	str	x21, [sp, #32]
    6634:	91154275 	add	x21, x19, #0x550
    6638:	f949daa1 	ldr	x1, [x21, #5040]
    663c:	f949eea2 	ldr	x2, [x21, #5080]
    6640:	cb010001 	sub	x1, x0, x1
    6644:	eb02403f 	cmp	x1, x2, lsl #16
    6648:	54000382 	b.cs	66b8 <fwp_drop4+0x98>  // b.hs, b.nlast
    664c:	d350fc22 	lsr	x2, x1, #16
    6650:	f949fea3 	ldr	x3, [x21, #5112]
    6654:	8b020842 	add	x2, x2, x2, lsl #2
    6658:	d37df042 	lsl	x2, x2, #3
    665c:	8b020064 	add	x4, x3, x2
    6660:	f9401094 	ldr	x20, [x4, #32]
    6664:	b40002b4 	cbz	x20, 66b8 <fwp_drop4+0x98>
    6668:	38626862 	ldrb	w2, [x3, x2]
    666c:	7100085f 	cmp	w2, #0x2
    6670:	540007a0 	b.eq	6764 <fwp_drop4+0x144>  // b.none
    6674:	7100045f 	cmp	w2, #0x1
    6678:	54000201 	b.ne	66b8 <fwp_drop4+0x98>  // b.any
    667c:	29430885 	ldp	w5, w2, [x4, #24]
    6680:	92403c21 	and	x1, x1, #0xffff
    6684:	9b057c21 	mul	x1, x1, x5
    6688:	d360fc21 	lsr	x1, x1, #32
    668c:	eb02003f 	cmp	x1, x2
    6690:	54000142 	b.cs	66b8 <fwp_drop4+0x98>  // b.hs, b.nlast
    6694:	8b010294 	add	x20, x20, x1
    6698:	39400281 	ldrb	w1, [x20]
    669c:	340000e1 	cbz	w1, 66b8 <fwp_drop4+0x98>
    66a0:	7100043f 	cmp	w1, #0x1
    66a4:	54000120 	b.eq	66c8 <fwp_drop4+0xa8>  // b.none
    66a8:	7103fc3f 	cmp	w1, #0xff
    66ac:	540007c0 	b.eq	67a4 <fwp_drop4+0x184>  // b.none
    66b0:	51000421 	sub	w1, w1, #0x1
    66b4:	39000281 	strb	w1, [x20]
    66b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    66bc:	f94013f5 	ldr	x21, [sp, #32]
    66c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66c4:	d65f03c0 	ret
    66c8:	f9400001 	ldr	x1, [x0]
    66cc:	b7f80581 	tbnz	x1, #63, 677c <fwp_drop4+0x15c>
    66d0:	91154273 	add	x19, x19, #0x550
    66d4:	f949da61 	ldr	x1, [x19, #5040]
    66d8:	f949ee62 	ldr	x2, [x19, #5080]
    66dc:	cb010001 	sub	x1, x0, x1
    66e0:	eb02403f 	cmp	x1, x2, lsl #16
    66e4:	54fffea2 	b.cs	66b8 <fwp_drop4+0x98>  // b.hs, b.nlast
    66e8:	d350fc22 	lsr	x2, x1, #16
    66ec:	8b020842 	add	x2, x2, x2, lsl #2
    66f0:	d37df042 	lsl	x2, x2, #3
    66f4:	8b020065 	add	x5, x3, x2
    66f8:	f94010a4 	ldr	x4, [x5, #32]
    66fc:	b4fffde4 	cbz	x4, 66b8 <fwp_drop4+0x98>
    6700:	38626862 	ldrb	w2, [x3, x2]
    6704:	7100085f 	cmp	w2, #0x2
    6708:	54000220 	b.eq	674c <fwp_drop4+0x12c>  // b.none
    670c:	7100045f 	cmp	w2, #0x1
    6710:	54fffd41 	b.ne	66b8 <fwp_drop4+0x98>  // b.any
    6714:	294308a3 	ldp	w3, w2, [x5, #24]
    6718:	92403c21 	and	x1, x1, #0xffff
    671c:	9b037c21 	mul	x1, x1, x3
    6720:	d360fc21 	lsr	x1, x1, #32
    6724:	eb02003f 	cmp	x1, x2
    6728:	54fffc82 	b.cs	66b8 <fwp_drop4+0x98>  // b.hs, b.nlast
    672c:	8b010084 	add	x4, x4, x1
    6730:	39400081 	ldrb	w1, [x4]
    6734:	7100043f 	cmp	w1, #0x1
    6738:	54fffc01 	b.ne	66b8 <fwp_drop4+0x98>  // b.any
    673c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6740:	f94013f5 	ldr	x21, [sp, #32]
    6744:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6748:	17fff80a 	b	4770 <fwp_mem_free>
    674c:	72003c3f 	tst	w1, #0xffff
    6750:	54ffff00 	b.eq	6730 <fwp_drop4+0x110>  // b.none
    6754:	a94153f3 	ldp	x19, x20, [sp, #16]
    6758:	f94013f5 	ldr	x21, [sp, #32]
    675c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6760:	d65f03c0 	ret
    6764:	72003c3f 	tst	w1, #0xffff
    6768:	54fff980 	b.eq	6698 <fwp_drop4+0x78>  // b.none
    676c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6770:	f94013f5 	ldr	x21, [sp, #32]
    6774:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6778:	d65f03c0 	ret
    677c:	f9400414 	ldr	x20, [x0, #8]
    6780:	97fffbf0 	bl	5740 <fwp_rc_free_arr>
    6784:	91154260 	add	x0, x19, #0x550
    6788:	f949d801 	ldr	x1, [x0, #5040]
    678c:	f949ec00 	ldr	x0, [x0, #5080]
    6790:	cb010281 	sub	x1, x20, x1
    6794:	eb00403f 	cmp	x1, x0, lsl #16
    6798:	54fff902 	b.cs	66b8 <fwp_drop4+0x98>  // b.hs, b.nlast
    679c:	aa1403e0 	mov	x0, x20
    67a0:	17ffffab 	b	664c <fwp_drop4+0x2c>
    67a4:	ca544680 	eor	x0, x20, x20, lsr #17
    67a8:	91154273 	add	x19, x19, #0x550
    67ac:	ca402400 	eor	x0, x0, x0, lsr #9
    67b0:	8b200e60 	add	x0, x19, w0, uxtb #3
    67b4:	f94a2400 	ldr	x0, [x0, #5192]
    67b8:	b5000080 	cbnz	x0, 67c8 <fwp_drop4+0x1a8>
    67bc:	14000010 	b	67fc <fwp_drop4+0x1dc>
    67c0:	f9400800 	ldr	x0, [x0, #16]
    67c4:	b40001c0 	cbz	x0, 67fc <fwp_drop4+0x1dc>
    67c8:	f9400001 	ldr	x1, [x0]
    67cc:	eb14003f 	cmp	x1, x20
    67d0:	54ffff81 	b.ne	67c0 <fwp_drop4+0x1a0>  // b.any
    67d4:	f9400401 	ldr	x1, [x0, #8]
    67d8:	d1000421 	sub	x1, x1, #0x1
    67dc:	f9000401 	str	x1, [x0, #8]
    67e0:	f103f83f 	cmp	x1, #0xfe
    67e4:	54fff6a1 	b.ne	66b8 <fwp_drop4+0x98>  // b.any
    67e8:	aa1403e0 	mov	x0, x20
    67ec:	97fff741 	bl	44f0 <fwp_rc_forget_slot>
    67f0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    67f4:	39000280 	strb	w0, [x20]
    67f8:	17ffffb0 	b	66b8 <fwp_drop4+0x98>
    67fc:	f0000020 	adrp	x0, d000 <__modti3+0x1f0>
    6800:	91116000 	add	x0, x0, #0x458
    6804:	97fff33f 	bl	3500 <fwp_trap>
    6808:	d503201f 	nop
    680c:	d503201f 	nop

0000000000006810 <fwp_caps161>:
    6810:	34000041 	cbz	w1, 6818 <fwp_caps161+0x8>
    6814:	d65f03c0 	ret
    6818:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc90>
    681c:	91154063 	add	x3, x3, #0x550
    6820:	f949d861 	ldr	x1, [x3, #5040]
    6824:	f949ec62 	ldr	x2, [x3, #5080]
    6828:	cb010001 	sub	x1, x0, x1
    682c:	eb02403f 	cmp	x1, x2, lsl #16
    6830:	54ffff22 	b.cs	6814 <fwp_caps161+0x4>  // b.hs, b.nlast
    6834:	d350fc22 	lsr	x2, x1, #16
    6838:	f949fc65 	ldr	x5, [x3, #5112]
    683c:	8b020842 	add	x2, x2, x2, lsl #2
    6840:	d37df042 	lsl	x2, x2, #3
    6844:	8b0200a4 	add	x4, x5, x2
    6848:	f9401083 	ldr	x3, [x4, #32]
    684c:	b4fffe43 	cbz	x3, 6814 <fwp_caps161+0x4>
    6850:	386268a2 	ldrb	w2, [x5, x2]
    6854:	7100085f 	cmp	w2, #0x2
    6858:	540001c0 	b.eq	6890 <fwp_caps161+0x80>  // b.none
    685c:	7100045f 	cmp	w2, #0x1
    6860:	54fffda1 	b.ne	6814 <fwp_caps161+0x4>  // b.any
    6864:	29430885 	ldp	w5, w2, [x4, #24]
    6868:	92403c21 	and	x1, x1, #0xffff
    686c:	9b057c21 	mul	x1, x1, x5
    6870:	d360fc21 	lsr	x1, x1, #32
    6874:	eb02003f 	cmp	x1, x2
    6878:	54fffce2 	b.cs	6814 <fwp_caps161+0x4>  // b.hs, b.nlast
    687c:	8b010063 	add	x3, x3, x1
    6880:	39400061 	ldrb	w1, [x3]
    6884:	7100043f 	cmp	w1, #0x1
    6888:	54fffc61 	b.ne	6814 <fwp_caps161+0x4>  // b.any
    688c:	17fff7b9 	b	4770 <fwp_mem_free>
    6890:	72003c3f 	tst	w1, #0xffff
    6894:	54ffff60 	b.eq	6880 <fwp_caps161+0x70>  // b.none
    6898:	d65f03c0 	ret
    689c:	d503201f 	nop

00000000000068a0 <fwp_args23>:
    68a0:	7100003f 	cmp	w1, #0x0
    68a4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    68a8:	54000041 	b.ne	68b0 <fwp_args23+0x10>  // b.any
    68ac:	d65f03c0 	ret
    68b0:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    68b4:	91154042 	add	x2, x2, #0x550
    68b8:	f9400001 	ldr	x1, [x0]
    68bc:	f949d843 	ldr	x3, [x2, #5040]
    68c0:	f949ec40 	ldr	x0, [x2, #5080]
    68c4:	cb030021 	sub	x1, x1, x3
    68c8:	eb00403f 	cmp	x1, x0, lsl #16
    68cc:	54ffff02 	b.cs	68ac <fwp_args23+0xc>  // b.hs, b.nlast
    68d0:	d350fc20 	lsr	x0, x1, #16
    68d4:	f949fc44 	ldr	x4, [x2, #5112]
    68d8:	8b000800 	add	x0, x0, x0, lsl #2
    68dc:	d37df002 	lsl	x2, x0, #3
    68e0:	8b020083 	add	x3, x4, x2
    68e4:	f9401060 	ldr	x0, [x3, #32]
    68e8:	b4fffe20 	cbz	x0, 68ac <fwp_args23+0xc>
    68ec:	38626882 	ldrb	w2, [x4, x2]
    68f0:	7100085f 	cmp	w2, #0x2
    68f4:	54000220 	b.eq	6938 <fwp_args23+0x98>  // b.none
    68f8:	7100045f 	cmp	w2, #0x1
    68fc:	54fffd81 	b.ne	68ac <fwp_args23+0xc>  // b.any
    6900:	29430864 	ldp	w4, w2, [x3, #24]
    6904:	92403c21 	and	x1, x1, #0xffff
    6908:	9b047c21 	mul	x1, x1, x4
    690c:	d360fc21 	lsr	x1, x1, #32
    6910:	eb02003f 	cmp	x1, x2
    6914:	54fffcc2 	b.cs	68ac <fwp_args23+0xc>  // b.hs, b.nlast
    6918:	8b010000 	add	x0, x0, x1
    691c:	39400001 	ldrb	w1, [x0]
    6920:	34fffc61 	cbz	w1, 68ac <fwp_args23+0xc>
    6924:	7103f43f 	cmp	w1, #0xfd
    6928:	540000e8 	b.hi	6944 <fwp_args23+0xa4>  // b.pmore
    692c:	11000421 	add	w1, w1, #0x1
    6930:	39000001 	strb	w1, [x0]
    6934:	d65f03c0 	ret
    6938:	72003c3f 	tst	w1, #0xffff
    693c:	54ffff00 	b.eq	691c <fwp_args23+0x7c>  // b.none
    6940:	d65f03c0 	ret
    6944:	17fff6a4 	b	43d4 <fwp_rc_wide_dup>
    6948:	d503201f 	nop
    694c:	d503201f 	nop

0000000000006950 <fwp_args12>:
    6950:	7100003f 	cmp	w1, #0x0
    6954:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6958:	54000041 	b.ne	6960 <fwp_args12+0x10>  // b.any
    695c:	d65f03c0 	ret
    6960:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6964:	91154042 	add	x2, x2, #0x550
    6968:	f9400001 	ldr	x1, [x0]
    696c:	f949d843 	ldr	x3, [x2, #5040]
    6970:	f949ec40 	ldr	x0, [x2, #5080]
    6974:	cb030021 	sub	x1, x1, x3
    6978:	eb00403f 	cmp	x1, x0, lsl #16
    697c:	54ffff02 	b.cs	695c <fwp_args12+0xc>  // b.hs, b.nlast
    6980:	d350fc20 	lsr	x0, x1, #16
    6984:	f949fc44 	ldr	x4, [x2, #5112]
    6988:	8b000800 	add	x0, x0, x0, lsl #2
    698c:	d37df002 	lsl	x2, x0, #3
    6990:	8b020083 	add	x3, x4, x2
    6994:	f9401060 	ldr	x0, [x3, #32]
    6998:	b4fffe20 	cbz	x0, 695c <fwp_args12+0xc>
    699c:	38626882 	ldrb	w2, [x4, x2]
    69a0:	7100085f 	cmp	w2, #0x2
    69a4:	54000220 	b.eq	69e8 <fwp_args12+0x98>  // b.none
    69a8:	7100045f 	cmp	w2, #0x1
    69ac:	54fffd81 	b.ne	695c <fwp_args12+0xc>  // b.any
    69b0:	29430864 	ldp	w4, w2, [x3, #24]
    69b4:	92403c21 	and	x1, x1, #0xffff
    69b8:	9b047c21 	mul	x1, x1, x4
    69bc:	d360fc21 	lsr	x1, x1, #32
    69c0:	eb02003f 	cmp	x1, x2
    69c4:	54fffcc2 	b.cs	695c <fwp_args12+0xc>  // b.hs, b.nlast
    69c8:	8b010000 	add	x0, x0, x1
    69cc:	39400001 	ldrb	w1, [x0]
    69d0:	34fffc61 	cbz	w1, 695c <fwp_args12+0xc>
    69d4:	7103f43f 	cmp	w1, #0xfd
    69d8:	540000e8 	b.hi	69f4 <fwp_args12+0xa4>  // b.pmore
    69dc:	11000421 	add	w1, w1, #0x1
    69e0:	39000001 	strb	w1, [x0]
    69e4:	d65f03c0 	ret
    69e8:	72003c3f 	tst	w1, #0xffff
    69ec:	54ffff00 	b.eq	69cc <fwp_args12+0x7c>  // b.none
    69f0:	d65f03c0 	ret
    69f4:	17fff678 	b	43d4 <fwp_rc_wide_dup>
    69f8:	d503201f 	nop
    69fc:	d503201f 	nop

0000000000006a00 <fwp_caps12>:
    6a00:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6a04:	910003fd 	mov	x29, sp
    6a08:	f9000bf3 	str	x19, [sp, #16]
    6a0c:	aa0003f3 	mov	x19, x0
    6a10:	b9400400 	ldr	w0, [x0, #4]
    6a14:	340004a0 	cbz	w0, 6aa8 <fwp_caps12+0xa8>
    6a18:	f9400660 	ldr	x0, [x19, #8]
    6a1c:	350004e1 	cbnz	w1, 6ab8 <fwp_caps12+0xb8>
    6a20:	97fffc70 	bl	5be0 <fwp_drop0>
    6a24:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6a28:	91154042 	add	x2, x2, #0x550
    6a2c:	f949d840 	ldr	x0, [x2, #5040]
    6a30:	f949ec41 	ldr	x1, [x2, #5080]
    6a34:	cb000260 	sub	x0, x19, x0
    6a38:	eb01401f 	cmp	x0, x1, lsl #16
    6a3c:	54000382 	b.cs	6aac <fwp_caps12+0xac>  // b.hs, b.nlast
    6a40:	d350fc01 	lsr	x1, x0, #16
    6a44:	f949fc44 	ldr	x4, [x2, #5112]
    6a48:	8b010821 	add	x1, x1, x1, lsl #2
    6a4c:	d37df021 	lsl	x1, x1, #3
    6a50:	8b010083 	add	x3, x4, x1
    6a54:	f9401062 	ldr	x2, [x3, #32]
    6a58:	b40002a2 	cbz	x2, 6aac <fwp_caps12+0xac>
    6a5c:	38616881 	ldrb	w1, [x4, x1]
    6a60:	7100083f 	cmp	w1, #0x2
    6a64:	540006c0 	b.eq	6b3c <fwp_caps12+0x13c>  // b.none
    6a68:	7100043f 	cmp	w1, #0x1
    6a6c:	54000201 	b.ne	6aac <fwp_caps12+0xac>  // b.any
    6a70:	29430464 	ldp	w4, w1, [x3, #24]
    6a74:	92403c00 	and	x0, x0, #0xffff
    6a78:	9b047c00 	mul	x0, x0, x4
    6a7c:	d360fc00 	lsr	x0, x0, #32
    6a80:	eb01001f 	cmp	x0, x1
    6a84:	54000142 	b.cs	6aac <fwp_caps12+0xac>  // b.hs, b.nlast
    6a88:	8b000042 	add	x2, x2, x0
    6a8c:	39400040 	ldrb	w0, [x2]
    6a90:	7100041f 	cmp	w0, #0x1
    6a94:	540000c1 	b.ne	6aac <fwp_caps12+0xac>  // b.any
    6a98:	aa1303e0 	mov	x0, x19
    6a9c:	f9400bf3 	ldr	x19, [sp, #16]
    6aa0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6aa4:	17fff733 	b	4770 <fwp_mem_free>
    6aa8:	34fffbe1 	cbz	w1, 6a24 <fwp_caps12+0x24>
    6aac:	f9400bf3 	ldr	x19, [sp, #16]
    6ab0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6ab4:	d65f03c0 	ret
    6ab8:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6abc:	91154042 	add	x2, x2, #0x550
    6ac0:	f949d843 	ldr	x3, [x2, #5040]
    6ac4:	f949ec41 	ldr	x1, [x2, #5080]
    6ac8:	cb030000 	sub	x0, x0, x3
    6acc:	eb01401f 	cmp	x0, x1, lsl #16
    6ad0:	54fffee2 	b.cs	6aac <fwp_caps12+0xac>  // b.hs, b.nlast
    6ad4:	d350fc01 	lsr	x1, x0, #16
    6ad8:	f949fc44 	ldr	x4, [x2, #5112]
    6adc:	8b010821 	add	x1, x1, x1, lsl #2
    6ae0:	d37df021 	lsl	x1, x1, #3
    6ae4:	8b010083 	add	x3, x4, x1
    6ae8:	f9401062 	ldr	x2, [x3, #32]
    6aec:	b4fffe02 	cbz	x2, 6aac <fwp_caps12+0xac>
    6af0:	38616881 	ldrb	w1, [x4, x1]
    6af4:	7100083f 	cmp	w1, #0x2
    6af8:	54000280 	b.eq	6b48 <fwp_caps12+0x148>  // b.none
    6afc:	7100043f 	cmp	w1, #0x1
    6b00:	54fffd61 	b.ne	6aac <fwp_caps12+0xac>  // b.any
    6b04:	92403c01 	and	x1, x0, #0xffff
    6b08:	29430064 	ldp	w4, w0, [x3, #24]
    6b0c:	9b047c21 	mul	x1, x1, x4
    6b10:	d360fc21 	lsr	x1, x1, #32
    6b14:	eb00003f 	cmp	x1, x0
    6b18:	54fffca2 	b.cs	6aac <fwp_caps12+0xac>  // b.hs, b.nlast
    6b1c:	8b010042 	add	x2, x2, x1
    6b20:	39400040 	ldrb	w0, [x2]
    6b24:	34fffc40 	cbz	w0, 6aac <fwp_caps12+0xac>
    6b28:	7103f41f 	cmp	w0, #0xfd
    6b2c:	54000148 	b.hi	6b54 <fwp_caps12+0x154>  // b.pmore
    6b30:	11000400 	add	w0, w0, #0x1
    6b34:	39000040 	strb	w0, [x2]
    6b38:	17ffffdd 	b	6aac <fwp_caps12+0xac>
    6b3c:	72003c1f 	tst	w0, #0xffff
    6b40:	54fffb61 	b.ne	6aac <fwp_caps12+0xac>  // b.any
    6b44:	17ffffd2 	b	6a8c <fwp_caps12+0x8c>
    6b48:	72003c1f 	tst	w0, #0xffff
    6b4c:	54fffb01 	b.ne	6aac <fwp_caps12+0xac>  // b.any
    6b50:	17fffff4 	b	6b20 <fwp_caps12+0x120>
    6b54:	f9400bf3 	ldr	x19, [sp, #16]
    6b58:	aa0203e0 	mov	x0, x2
    6b5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b60:	17fff61d 	b	43d4 <fwp_rc_wide_dup>

0000000000006b64 <fwp_drop2>:
    6b64:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6b68:	910003fd 	mov	x29, sp
    6b6c:	a9025bf5 	stp	x21, x22, [sp, #32]
    6b70:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc90>
    6b74:	911542d5 	add	x21, x22, #0x550
    6b78:	a90153f3 	stp	x19, x20, [sp, #16]
    6b7c:	aa0003f3 	mov	x19, x0
    6b80:	f949daa1 	ldr	x1, [x21, #5040]
    6b84:	f949eea0 	ldr	x0, [x21, #5080]
    6b88:	cb010261 	sub	x1, x19, x1
    6b8c:	eb00403f 	cmp	x1, x0, lsl #16
    6b90:	54000382 	b.cs	6c00 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6b94:	d350fc22 	lsr	x2, x1, #16
    6b98:	f949fea3 	ldr	x3, [x21, #5112]
    6b9c:	8b020842 	add	x2, x2, x2, lsl #2
    6ba0:	d37df042 	lsl	x2, x2, #3
    6ba4:	8b020060 	add	x0, x3, x2
    6ba8:	f9401014 	ldr	x20, [x0, #32]
    6bac:	b40002b4 	cbz	x20, 6c00 <fwp_drop2+0x9c>
    6bb0:	38626862 	ldrb	w2, [x3, x2]
    6bb4:	7100085f 	cmp	w2, #0x2
    6bb8:	540002c0 	b.eq	6c10 <fwp_drop2+0xac>  // b.none
    6bbc:	7100045f 	cmp	w2, #0x1
    6bc0:	54000201 	b.ne	6c00 <fwp_drop2+0x9c>  // b.any
    6bc4:	29430002 	ldp	w2, w0, [x0, #24]
    6bc8:	92403c21 	and	x1, x1, #0xffff
    6bcc:	9b027c21 	mul	x1, x1, x2
    6bd0:	d360fc21 	lsr	x1, x1, #32
    6bd4:	eb00003f 	cmp	x1, x0
    6bd8:	54000142 	b.cs	6c00 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6bdc:	8b010294 	add	x20, x20, x1
    6be0:	39400280 	ldrb	w0, [x20]
    6be4:	340000e0 	cbz	w0, 6c00 <fwp_drop2+0x9c>
    6be8:	7100041f 	cmp	w0, #0x1
    6bec:	540001e0 	b.eq	6c28 <fwp_drop2+0xc4>  // b.none
    6bf0:	7103fc1f 	cmp	w0, #0xff
    6bf4:	540007e0 	b.eq	6cf0 <fwp_drop2+0x18c>  // b.none
    6bf8:	51000400 	sub	w0, w0, #0x1
    6bfc:	39000280 	strb	w0, [x20]
    6c00:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c04:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6c08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6c0c:	d65f03c0 	ret
    6c10:	72003c3f 	tst	w1, #0xffff
    6c14:	54fffe60 	b.eq	6be0 <fwp_drop2+0x7c>  // b.none
    6c18:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c1c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6c20:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6c24:	d65f03c0 	ret
    6c28:	911542c2 	add	x2, x22, #0x550
    6c2c:	f9400660 	ldr	x0, [x19, #8]
    6c30:	f949d841 	ldr	x1, [x2, #5040]
    6c34:	f949ec42 	ldr	x2, [x2, #5080]
    6c38:	cb010001 	sub	x1, x0, x1
    6c3c:	eb02403f 	cmp	x1, x2, lsl #16
    6c40:	54000382 	b.cs	6cb0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    6c44:	d350fc22 	lsr	x2, x1, #16
    6c48:	8b020842 	add	x2, x2, x2, lsl #2
    6c4c:	d37df042 	lsl	x2, x2, #3
    6c50:	8b020064 	add	x4, x3, x2
    6c54:	f9401094 	ldr	x20, [x4, #32]
    6c58:	b40002d4 	cbz	x20, 6cb0 <fwp_drop2+0x14c>
    6c5c:	38626862 	ldrb	w2, [x3, x2]
    6c60:	7100085f 	cmp	w2, #0x2
    6c64:	54000400 	b.eq	6ce4 <fwp_drop2+0x180>  // b.none
    6c68:	7100045f 	cmp	w2, #0x1
    6c6c:	54000221 	b.ne	6cb0 <fwp_drop2+0x14c>  // b.any
    6c70:	29430883 	ldp	w3, w2, [x4, #24]
    6c74:	92403c21 	and	x1, x1, #0xffff
    6c78:	9b037c21 	mul	x1, x1, x3
    6c7c:	d360fc21 	lsr	x1, x1, #32
    6c80:	eb02003f 	cmp	x1, x2
    6c84:	54000162 	b.cs	6cb0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    6c88:	8b010294 	add	x20, x20, x1
    6c8c:	39400281 	ldrb	w1, [x20]
    6c90:	34000101 	cbz	w1, 6cb0 <fwp_drop2+0x14c>
    6c94:	7100043f 	cmp	w1, #0x1
    6c98:	54000220 	b.eq	6cdc <fwp_drop2+0x178>  // b.none
    6c9c:	7103fc3f 	cmp	w1, #0xff
    6ca0:	540005a0 	b.eq	6d54 <fwp_drop2+0x1f0>  // b.none
    6ca4:	51000421 	sub	w1, w1, #0x1
    6ca8:	39000281 	strb	w1, [x20]
    6cac:	d503201f 	nop
    6cb0:	f9400a74 	ldr	x20, [x19, #16]
    6cb4:	aa1303e0 	mov	x0, x19
    6cb8:	97fffaa2 	bl	5740 <fwp_rc_free_arr>
    6cbc:	911542c0 	add	x0, x22, #0x550
    6cc0:	f949d801 	ldr	x1, [x0, #5040]
    6cc4:	f949ec00 	ldr	x0, [x0, #5080]
    6cc8:	cb010281 	sub	x1, x20, x1
    6ccc:	eb00403f 	cmp	x1, x0, lsl #16
    6cd0:	54fff982 	b.cs	6c00 <fwp_drop2+0x9c>  // b.hs, b.nlast
    6cd4:	aa1403f3 	mov	x19, x20
    6cd8:	17ffffaf 	b	6b94 <fwp_drop2+0x30>
    6cdc:	97fffa99 	bl	5740 <fwp_rc_free_arr>
    6ce0:	17fffff4 	b	6cb0 <fwp_drop2+0x14c>
    6ce4:	72003c3f 	tst	w1, #0xffff
    6ce8:	54fffe41 	b.ne	6cb0 <fwp_drop2+0x14c>  // b.any
    6cec:	17ffffe8 	b	6c8c <fwp_drop2+0x128>
    6cf0:	ca544681 	eor	x1, x20, x20, lsr #17
    6cf4:	911542c0 	add	x0, x22, #0x550
    6cf8:	ca412421 	eor	x1, x1, x1, lsr #9
    6cfc:	8b210c01 	add	x1, x0, w1, uxtb #3
    6d00:	f94a2420 	ldr	x0, [x1, #5192]
    6d04:	b5000080 	cbnz	x0, 6d14 <fwp_drop2+0x1b0>
    6d08:	14000010 	b	6d48 <fwp_drop2+0x1e4>
    6d0c:	f9400800 	ldr	x0, [x0, #16]
    6d10:	b40001c0 	cbz	x0, 6d48 <fwp_drop2+0x1e4>
    6d14:	f9400001 	ldr	x1, [x0]
    6d18:	eb14003f 	cmp	x1, x20
    6d1c:	54ffff81 	b.ne	6d0c <fwp_drop2+0x1a8>  // b.any
    6d20:	f9400401 	ldr	x1, [x0, #8]
    6d24:	d1000421 	sub	x1, x1, #0x1
    6d28:	f9000401 	str	x1, [x0, #8]
    6d2c:	f103f83f 	cmp	x1, #0xfe
    6d30:	54fff681 	b.ne	6c00 <fwp_drop2+0x9c>  // b.any
    6d34:	aa1403e0 	mov	x0, x20
    6d38:	97fff5ee 	bl	44f0 <fwp_rc_forget_slot>
    6d3c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6d40:	39000280 	strb	w0, [x20]
    6d44:	17ffffaf 	b	6c00 <fwp_drop2+0x9c>
    6d48:	f0000020 	adrp	x0, d000 <__modti3+0x1f0>
    6d4c:	91116000 	add	x0, x0, #0x458
    6d50:	97fff1ec 	bl	3500 <fwp_trap>
    6d54:	ca544680 	eor	x0, x20, x20, lsr #17
    6d58:	911542c1 	add	x1, x22, #0x550
    6d5c:	ca402400 	eor	x0, x0, x0, lsr #9
    6d60:	8b200c20 	add	x0, x1, w0, uxtb #3
    6d64:	f94a2400 	ldr	x0, [x0, #5192]
    6d68:	b5000080 	cbnz	x0, 6d78 <fwp_drop2+0x214>
    6d6c:	17fffff7 	b	6d48 <fwp_drop2+0x1e4>
    6d70:	f9400800 	ldr	x0, [x0, #16]
    6d74:	b4fffea0 	cbz	x0, 6d48 <fwp_drop2+0x1e4>
    6d78:	f9400001 	ldr	x1, [x0]
    6d7c:	eb14003f 	cmp	x1, x20
    6d80:	54ffff81 	b.ne	6d70 <fwp_drop2+0x20c>  // b.any
    6d84:	f9400401 	ldr	x1, [x0, #8]
    6d88:	d1000421 	sub	x1, x1, #0x1
    6d8c:	f9000401 	str	x1, [x0, #8]
    6d90:	f103f83f 	cmp	x1, #0xfe
    6d94:	54fff8e1 	b.ne	6cb0 <fwp_drop2+0x14c>  // b.any
    6d98:	aa1403e0 	mov	x0, x20
    6d9c:	97fff5d5 	bl	44f0 <fwp_rc_forget_slot>
    6da0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6da4:	39000280 	strb	w0, [x20]
    6da8:	17ffffc2 	b	6cb0 <fwp_drop2+0x14c>
    6dac:	d503201f 	nop

0000000000006db0 <fwp_arg_drop23>:
    6db0:	7100003f 	cmp	w1, #0x0
    6db4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6db8:	54000041 	b.ne	6dc0 <fwp_arg_drop23+0x10>  // b.any
    6dbc:	d65f03c0 	ret
    6dc0:	f9400000 	ldr	x0, [x0]
    6dc4:	17ffff68 	b	6b64 <fwp_drop2>
    6dc8:	d503201f 	nop
    6dcc:	d503201f 	nop

0000000000006dd0 <fwp_caps23>:
    6dd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6dd4:	910003fd 	mov	x29, sp
    6dd8:	f9000bf3 	str	x19, [sp, #16]
    6ddc:	aa0003f3 	mov	x19, x0
    6de0:	b9400400 	ldr	w0, [x0, #4]
    6de4:	340004a0 	cbz	w0, 6e78 <fwp_caps23+0xa8>
    6de8:	f9400660 	ldr	x0, [x19, #8]
    6dec:	350004e1 	cbnz	w1, 6e88 <fwp_caps23+0xb8>
    6df0:	97ffff5d 	bl	6b64 <fwp_drop2>
    6df4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6df8:	91154042 	add	x2, x2, #0x550
    6dfc:	f949d840 	ldr	x0, [x2, #5040]
    6e00:	f949ec41 	ldr	x1, [x2, #5080]
    6e04:	cb000260 	sub	x0, x19, x0
    6e08:	eb01401f 	cmp	x0, x1, lsl #16
    6e0c:	54000382 	b.cs	6e7c <fwp_caps23+0xac>  // b.hs, b.nlast
    6e10:	d350fc01 	lsr	x1, x0, #16
    6e14:	f949fc44 	ldr	x4, [x2, #5112]
    6e18:	8b010821 	add	x1, x1, x1, lsl #2
    6e1c:	d37df021 	lsl	x1, x1, #3
    6e20:	8b010083 	add	x3, x4, x1
    6e24:	f9401062 	ldr	x2, [x3, #32]
    6e28:	b40002a2 	cbz	x2, 6e7c <fwp_caps23+0xac>
    6e2c:	38616881 	ldrb	w1, [x4, x1]
    6e30:	7100083f 	cmp	w1, #0x2
    6e34:	540006c0 	b.eq	6f0c <fwp_caps23+0x13c>  // b.none
    6e38:	7100043f 	cmp	w1, #0x1
    6e3c:	54000201 	b.ne	6e7c <fwp_caps23+0xac>  // b.any
    6e40:	29430464 	ldp	w4, w1, [x3, #24]
    6e44:	92403c00 	and	x0, x0, #0xffff
    6e48:	9b047c00 	mul	x0, x0, x4
    6e4c:	d360fc00 	lsr	x0, x0, #32
    6e50:	eb01001f 	cmp	x0, x1
    6e54:	54000142 	b.cs	6e7c <fwp_caps23+0xac>  // b.hs, b.nlast
    6e58:	8b000042 	add	x2, x2, x0
    6e5c:	39400040 	ldrb	w0, [x2]
    6e60:	7100041f 	cmp	w0, #0x1
    6e64:	540000c1 	b.ne	6e7c <fwp_caps23+0xac>  // b.any
    6e68:	aa1303e0 	mov	x0, x19
    6e6c:	f9400bf3 	ldr	x19, [sp, #16]
    6e70:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e74:	17fff63f 	b	4770 <fwp_mem_free>
    6e78:	34fffbe1 	cbz	w1, 6df4 <fwp_caps23+0x24>
    6e7c:	f9400bf3 	ldr	x19, [sp, #16]
    6e80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e84:	d65f03c0 	ret
    6e88:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    6e8c:	91154042 	add	x2, x2, #0x550
    6e90:	f949d843 	ldr	x3, [x2, #5040]
    6e94:	f949ec41 	ldr	x1, [x2, #5080]
    6e98:	cb030000 	sub	x0, x0, x3
    6e9c:	eb01401f 	cmp	x0, x1, lsl #16
    6ea0:	54fffee2 	b.cs	6e7c <fwp_caps23+0xac>  // b.hs, b.nlast
    6ea4:	d350fc01 	lsr	x1, x0, #16
    6ea8:	f949fc44 	ldr	x4, [x2, #5112]
    6eac:	8b010821 	add	x1, x1, x1, lsl #2
    6eb0:	d37df021 	lsl	x1, x1, #3
    6eb4:	8b010083 	add	x3, x4, x1
    6eb8:	f9401062 	ldr	x2, [x3, #32]
    6ebc:	b4fffe02 	cbz	x2, 6e7c <fwp_caps23+0xac>
    6ec0:	38616881 	ldrb	w1, [x4, x1]
    6ec4:	7100083f 	cmp	w1, #0x2
    6ec8:	54000280 	b.eq	6f18 <fwp_caps23+0x148>  // b.none
    6ecc:	7100043f 	cmp	w1, #0x1
    6ed0:	54fffd61 	b.ne	6e7c <fwp_caps23+0xac>  // b.any
    6ed4:	92403c01 	and	x1, x0, #0xffff
    6ed8:	29430064 	ldp	w4, w0, [x3, #24]
    6edc:	9b047c21 	mul	x1, x1, x4
    6ee0:	d360fc21 	lsr	x1, x1, #32
    6ee4:	eb00003f 	cmp	x1, x0
    6ee8:	54fffca2 	b.cs	6e7c <fwp_caps23+0xac>  // b.hs, b.nlast
    6eec:	8b010042 	add	x2, x2, x1
    6ef0:	39400040 	ldrb	w0, [x2]
    6ef4:	34fffc40 	cbz	w0, 6e7c <fwp_caps23+0xac>
    6ef8:	7103f41f 	cmp	w0, #0xfd
    6efc:	54000148 	b.hi	6f24 <fwp_caps23+0x154>  // b.pmore
    6f00:	11000400 	add	w0, w0, #0x1
    6f04:	39000040 	strb	w0, [x2]
    6f08:	17ffffdd 	b	6e7c <fwp_caps23+0xac>
    6f0c:	72003c1f 	tst	w0, #0xffff
    6f10:	54fffb61 	b.ne	6e7c <fwp_caps23+0xac>  // b.any
    6f14:	17ffffd2 	b	6e5c <fwp_caps23+0x8c>
    6f18:	72003c1f 	tst	w0, #0xffff
    6f1c:	54fffb01 	b.ne	6e7c <fwp_caps23+0xac>  // b.any
    6f20:	17fffff4 	b	6ef0 <fwp_caps23+0x120>
    6f24:	f9400bf3 	ldr	x19, [sp, #16]
    6f28:	aa0203e0 	mov	x0, x2
    6f2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6f30:	17fff529 	b	43d4 <fwp_rc_wide_dup>

0000000000006f34 <f23>:
    6f34:	d101c3ff 	sub	sp, sp, #0x70
    6f38:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    6f3c:	f947f421 	ldr	x1, [x1, #4072]
    6f40:	a9027bfd 	stp	x29, x30, [sp, #32]
    6f44:	910083fd 	add	x29, sp, #0x20
    6f48:	a90563f7 	stp	x23, x24, [sp, #80]
    6f4c:	f0000157 	adrp	x23, 31000 <fwp_root_context+0xc90>
    6f50:	911542e3 	add	x3, x23, #0x550
    6f54:	a90353f3 	stp	x19, x20, [sp, #48]
    6f58:	a9045bf5 	stp	x21, x22, [sp, #64]
    6f5c:	aa0003f6 	mov	x22, x0
    6f60:	a9066bf9 	stp	x25, x26, [sp, #96]
    6f64:	f949ec62 	ldr	x2, [x3, #5080]
    6f68:	f9400024 	ldr	x4, [x1]
    6f6c:	f9000fe4 	str	x4, [sp, #24]
    6f70:	d2800004 	mov	x4, #0x0                   	// #0
    6f74:	f949d861 	ldr	x1, [x3, #5040]
    6f78:	d370bc42 	lsl	x2, x2, #16
    6f7c:	b40015a0 	cbz	x0, 7230 <f23+0x2fc>
    6f80:	f9400818 	ldr	x24, [x0, #16]
    6f84:	cb010301 	sub	x1, x24, x1
    6f88:	eb02003f 	cmp	x1, x2
    6f8c:	54000362 	b.cs	6ff8 <f23+0xc4>  // b.hs, b.nlast
    6f90:	f949fc60 	ldr	x0, [x3, #5112]
    6f94:	d350fc22 	lsr	x2, x1, #16
    6f98:	8b020842 	add	x2, x2, x2, lsl #2
    6f9c:	8b020c02 	add	x2, x0, x2, lsl #3
    6fa0:	f9401040 	ldr	x0, [x2, #32]
    6fa4:	b40002a0 	cbz	x0, 6ff8 <f23+0xc4>
    6fa8:	39400043 	ldrb	w3, [x2]
    6fac:	7100087f 	cmp	w3, #0x2
    6fb0:	540013a0 	b.eq	7224 <f23+0x2f0>  // b.none
    6fb4:	7100047f 	cmp	w3, #0x1
    6fb8:	540001c1 	b.ne	6ff0 <f23+0xbc>  // b.any
    6fbc:	29430843 	ldp	w3, w2, [x2, #24]
    6fc0:	92403c21 	and	x1, x1, #0xffff
    6fc4:	9b037c21 	mul	x1, x1, x3
    6fc8:	d360fc21 	lsr	x1, x1, #32
    6fcc:	eb02003f 	cmp	x1, x2
    6fd0:	54000102 	b.cs	6ff0 <f23+0xbc>  // b.hs, b.nlast
    6fd4:	8b010000 	add	x0, x0, x1
    6fd8:	39400001 	ldrb	w1, [x0]
    6fdc:	340000a1 	cbz	w1, 6ff0 <f23+0xbc>
    6fe0:	7103f43f 	cmp	w1, #0xfd
    6fe4:	54001688 	b.hi	72b4 <f23+0x380>  // b.pmore
    6fe8:	11000421 	add	w1, w1, #0x1
    6fec:	39000001 	strb	w1, [x0]
    6ff0:	d2800000 	mov	x0, #0x0                   	// #0
    6ff4:	b40000d6 	cbz	x22, 700c <f23+0xd8>
    6ff8:	aa1603e1 	mov	x1, x22
    6ffc:	d2800000 	mov	x0, #0x0                   	// #0
    7000:	f9400821 	ldr	x1, [x1, #16]
    7004:	91000400 	add	x0, x0, #0x1
    7008:	b5ffffc1 	cbnz	x1, 7000 <f23+0xcc>
    700c:	b40011b8 	cbz	x24, 7240 <f23+0x30c>
    7010:	aa1803e1 	mov	x1, x24
    7014:	d2800002 	mov	x2, #0x0                   	// #0
    7018:	f9400821 	ldr	x1, [x1, #16]
    701c:	91000442 	add	x2, x2, #0x1
    7020:	b5ffffc1 	cbnz	x1, 7018 <f23+0xe4>
    7024:	eb00005f 	cmp	x2, x0
    7028:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    702c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    7030:	eb01033f 	cmp	x25, x1
    7034:	54001468 	b.hi	72c0 <f23+0x38c>  // b.pmore
    7038:	d37ffb33 	lsl	x19, x25, #1
    703c:	52800041 	mov	w1, #0x2                   	// #2
    7040:	91000660 	add	x0, x19, #0x1
    7044:	d37df000 	lsl	x0, x0, #3
    7048:	97fff6ea 	bl	4bf0 <fwp_heap_alloc>
    704c:	911542e1 	add	x1, x23, #0x550
    7050:	aa0003fa 	mov	x26, x0
    7054:	f9000013 	str	x19, [x0]
    7058:	aa0103e0 	mov	x0, x1
    705c:	f949d821 	ldr	x1, [x1, #5040]
    7060:	f949ec00 	ldr	x0, [x0, #5080]
    7064:	cb010341 	sub	x1, x26, x1
    7068:	eb00403f 	cmp	x1, x0, lsl #16
    706c:	54000342 	b.cs	70d4 <f23+0x1a0>  // b.hs, b.nlast
    7070:	911542e2 	add	x2, x23, #0x550
    7074:	d350fc20 	lsr	x0, x1, #16
    7078:	8b000800 	add	x0, x0, x0, lsl #2
    707c:	f949fc43 	ldr	x3, [x2, #5112]
    7080:	d37df002 	lsl	x2, x0, #3
    7084:	8b020060 	add	x0, x3, x2
    7088:	f9401013 	ldr	x19, [x0, #32]
    708c:	b4000253 	cbz	x19, 70d4 <f23+0x1a0>
    7090:	38626862 	ldrb	w2, [x3, x2]
    7094:	7100085f 	cmp	w2, #0x2
    7098:	54000c00 	b.eq	7218 <f23+0x2e4>  // b.none
    709c:	7100045f 	cmp	w2, #0x1
    70a0:	540001a1 	b.ne	70d4 <f23+0x1a0>  // b.any
    70a4:	29430002 	ldp	w2, w0, [x0, #24]
    70a8:	92403c21 	and	x1, x1, #0xffff
    70ac:	9b027c21 	mul	x1, x1, x2
    70b0:	d360fc21 	lsr	x1, x1, #32
    70b4:	eb00003f 	cmp	x1, x0
    70b8:	540000e2 	b.cs	70d4 <f23+0x1a0>  // b.hs, b.nlast
    70bc:	8b010273 	add	x19, x19, x1
    70c0:	39400260 	ldrb	w0, [x19]
    70c4:	7103fc1f 	cmp	w0, #0xff
    70c8:	54000da0 	b.eq	727c <f23+0x348>  // b.none
    70cc:	52800020 	mov	w0, #0x1                   	// #1
    70d0:	39000260 	strb	w0, [x19]
    70d4:	b4000259 	cbz	x25, 711c <f23+0x1e8>
    70d8:	8b191359 	add	x25, x26, x25, lsl #4
    70dc:	aa1a03f3 	mov	x19, x26
    70e0:	aa1603f5 	mov	x21, x22
    70e4:	aa1803f4 	mov	x20, x24
    70e8:	f9400683 	ldr	x3, [x20, #8]
    70ec:	f94006a2 	ldr	x2, [x21, #8]
    70f0:	f9400861 	ldr	x1, [x3, #16]
    70f4:	f9400840 	ldr	x0, [x2, #16]
    70f8:	fd400461 	ldr	d1, [x3, #8]
    70fc:	fd400440 	ldr	d0, [x2, #8]
    7100:	97fff86c 	bl	52b0 <w107>
    7104:	f9000660 	str	x0, [x19, #8]
    7108:	f8010e61 	str	x1, [x19, #16]!
    710c:	f9400a94 	ldr	x20, [x20, #16]
    7110:	f9400ab5 	ldr	x21, [x21, #16]
    7114:	eb13033f 	cmp	x25, x19
    7118:	54fffe81 	b.ne	70e8 <f23+0x1b4>  // b.any
    711c:	aa1803e0 	mov	x0, x24
    7120:	97fffe91 	bl	6b64 <fwp_drop2>
    7124:	aa1603e0 	mov	x0, x22
    7128:	97fffe8f 	bl	6b64 <fwp_drop2>
    712c:	911542f7 	add	x23, x23, #0x550
    7130:	aa1a03e0 	mov	x0, x26
    7134:	97fff8bc 	bl	5424 <w164.constprop.0>
    7138:	aa0103f3 	mov	x19, x1
    713c:	aa0003f4 	mov	x20, x0
    7140:	aa1a03e0 	mov	x0, x26
    7144:	97fffd37 	bl	6620 <fwp_drop4>
    7148:	a900cff4 	stp	x20, x19, [sp, #8]
    714c:	910023e1 	add	x1, sp, #0x8
    7150:	52800000 	mov	w0, #0x0                   	// #0
    7154:	97fff8dc 	bl	54c4 <fwp_data.part.0.constprop.0>
    7158:	f949dae1 	ldr	x1, [x23, #5040]
    715c:	aa0003f3 	mov	x19, x0
    7160:	f949eee0 	ldr	x0, [x23, #5080]
    7164:	cb010261 	sub	x1, x19, x1
    7168:	eb00403f 	cmp	x1, x0, lsl #16
    716c:	54000322 	b.cs	71d0 <f23+0x29c>  // b.hs, b.nlast
    7170:	d350fc22 	lsr	x2, x1, #16
    7174:	f949fee3 	ldr	x3, [x23, #5112]
    7178:	8b020842 	add	x2, x2, x2, lsl #2
    717c:	d37df042 	lsl	x2, x2, #3
    7180:	8b020060 	add	x0, x3, x2
    7184:	f9401014 	ldr	x20, [x0, #32]
    7188:	b4000254 	cbz	x20, 71d0 <f23+0x29c>
    718c:	38626862 	ldrb	w2, [x3, x2]
    7190:	7100085f 	cmp	w2, #0x2
    7194:	540003c0 	b.eq	720c <f23+0x2d8>  // b.none
    7198:	7100045f 	cmp	w2, #0x1
    719c:	540001a1 	b.ne	71d0 <f23+0x29c>  // b.any
    71a0:	29430002 	ldp	w2, w0, [x0, #24]
    71a4:	92403c21 	and	x1, x1, #0xffff
    71a8:	9b027c21 	mul	x1, x1, x2
    71ac:	d360fc21 	lsr	x1, x1, #32
    71b0:	eb00003f 	cmp	x1, x0
    71b4:	540000e2 	b.cs	71d0 <f23+0x29c>  // b.hs, b.nlast
    71b8:	8b010294 	add	x20, x20, x1
    71bc:	39400280 	ldrb	w0, [x20]
    71c0:	7103fc1f 	cmp	w0, #0xff
    71c4:	54000620 	b.eq	7288 <f23+0x354>  // b.none
    71c8:	52800020 	mov	w0, #0x1                   	// #1
    71cc:	39000280 	strb	w0, [x20]
    71d0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    71d4:	f947f400 	ldr	x0, [x0, #4072]
    71d8:	f9400fe2 	ldr	x2, [sp, #24]
    71dc:	f9400001 	ldr	x1, [x0]
    71e0:	eb010042 	subs	x2, x2, x1
    71e4:	d2800001 	mov	x1, #0x0                   	// #0
    71e8:	540006a1 	b.ne	72bc <f23+0x388>  // b.any
    71ec:	a9427bfd 	ldp	x29, x30, [sp, #32]
    71f0:	aa1303e0 	mov	x0, x19
    71f4:	a94353f3 	ldp	x19, x20, [sp, #48]
    71f8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    71fc:	a94563f7 	ldp	x23, x24, [sp, #80]
    7200:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7204:	9101c3ff 	add	sp, sp, #0x70
    7208:	d65f03c0 	ret
    720c:	72003c3f 	tst	w1, #0xffff
    7210:	54fffe01 	b.ne	71d0 <f23+0x29c>  // b.any
    7214:	17ffffea 	b	71bc <f23+0x288>
    7218:	72003c3f 	tst	w1, #0xffff
    721c:	54fff5c1 	b.ne	70d4 <f23+0x1a0>  // b.any
    7220:	17ffffa8 	b	70c0 <f23+0x18c>
    7224:	72003c3f 	tst	w1, #0xffff
    7228:	54ffee41 	b.ne	6ff0 <f23+0xbc>  // b.any
    722c:	17ffff6b 	b	6fd8 <f23+0xa4>
    7230:	cb0103e1 	neg	x1, x1
    7234:	eb02003f 	cmp	x1, x2
    7238:	540002e3 	b.cc	7294 <f23+0x360>  // b.lo, b.ul, b.last
    723c:	d503201f 	nop
    7240:	52800041 	mov	w1, #0x2                   	// #2
    7244:	d2800100 	mov	x0, #0x8                   	// #8
    7248:	97fff66a 	bl	4bf0 <fwp_heap_alloc>
    724c:	aa0003e1 	mov	x1, x0
    7250:	911542e0 	add	x0, x23, #0x550
    7254:	aa0103fa 	mov	x26, x1
    7258:	d2800018 	mov	x24, #0x0                   	// #0
    725c:	f900003f 	str	xzr, [x1]
    7260:	f949d801 	ldr	x1, [x0, #5040]
    7264:	f949ec00 	ldr	x0, [x0, #5080]
    7268:	cb010341 	sub	x1, x26, x1
    726c:	eb00403f 	cmp	x1, x0, lsl #16
    7270:	54fff562 	b.cs	711c <f23+0x1e8>  // b.hs, b.nlast
    7274:	d2800019 	mov	x25, #0x0                   	// #0
    7278:	17ffff7e 	b	7070 <f23+0x13c>
    727c:	aa1303e0 	mov	x0, x19
    7280:	97fff49c 	bl	44f0 <fwp_rc_forget_slot>
    7284:	17ffff92 	b	70cc <f23+0x198>
    7288:	aa1403e0 	mov	x0, x20
    728c:	97fff499 	bl	44f0 <fwp_rc_forget_slot>
    7290:	17ffffce 	b	71c8 <f23+0x294>
    7294:	f949fc62 	ldr	x2, [x3, #5112]
    7298:	d350fc20 	lsr	x0, x1, #16
    729c:	8b000800 	add	x0, x0, x0, lsl #2
    72a0:	8b000c42 	add	x2, x2, x0, lsl #3
    72a4:	f9401040 	ldr	x0, [x2, #32]
    72a8:	b4fffcc0 	cbz	x0, 7240 <f23+0x30c>
    72ac:	d2800018 	mov	x24, #0x0                   	// #0
    72b0:	17ffff3e 	b	6fa8 <f23+0x74>
    72b4:	97fff448 	bl	43d4 <fwp_rc_wide_dup>
    72b8:	17ffff4e 	b	6ff0 <f23+0xbc>
    72bc:	97ffed4d 	bl	27f0 <__stack_chk_fail@plt>
    72c0:	d0000020 	adrp	x0, d000 <__modti3+0x1f0>
    72c4:	91166000 	add	x0, x0, #0x598
    72c8:	97fff08e 	bl	3500 <fwp_trap>
    72cc:	d503201f 	nop

00000000000072d0 <fwp_owned_entry23>:
    72d0:	f9400000 	ldr	x0, [x0]
    72d4:	17ffff18 	b	6f34 <f23>
    72d8:	d503201f 	nop
    72dc:	d503201f 	nop

00000000000072e0 <e23>:
    72e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    72e4:	910003fd 	mov	x29, sp
    72e8:	f9000bf3 	str	x19, [sp, #16]
    72ec:	f9400013 	ldr	x19, [x0]
    72f0:	aa1303e0 	mov	x0, x19
    72f4:	97fff8bc 	bl	55e4 <fwp_rc_share>
    72f8:	aa1303e0 	mov	x0, x19
    72fc:	97ffff0e 	bl	6f34 <f23>
    7300:	aa0003f3 	mov	x19, x0
    7304:	97fff8b8 	bl	55e4 <fwp_rc_share>
    7308:	aa1303e0 	mov	x0, x19
    730c:	f9400bf3 	ldr	x19, [sp, #16]
    7310:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7314:	d65f03c0 	ret
    7318:	d503201f 	nop
    731c:	d503201f 	nop

0000000000007320 <f12>:
    7320:	d10443ff 	sub	sp, sp, #0x110
    7324:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    7328:	f947f442 	ldr	x2, [x2, #4072]
    732c:	a90b7bfd 	stp	x29, x30, [sp, #176]
    7330:	9102c3fd 	add	x29, sp, #0xb0
    7334:	a90d5bf5 	stp	x21, x22, [sp, #208]
    7338:	d0000155 	adrp	x21, 31000 <fwp_root_context+0xc90>
    733c:	911542a3 	add	x3, x21, #0x550
    7340:	a90e63f7 	stp	x23, x24, [sp, #224]
    7344:	b00000d7 	adrp	x23, 20000 <__data_start>
    7348:	910102e4 	add	x4, x23, #0x40
    734c:	f949d861 	ldr	x1, [x3, #5040]
    7350:	a90c53f3 	stp	x19, x20, [sp, #192]
    7354:	b00000d4 	adrp	x20, 20000 <__data_start>
    7358:	f949ec65 	ldr	x5, [x3, #5080]
    735c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    7360:	91004294 	add	x20, x20, #0x10
    7364:	a91073fb 	stp	x27, x28, [sp, #256]
    7368:	9100c3fa 	add	x26, sp, #0x30
    736c:	9100a3f9 	add	x25, sp, #0x28
    7370:	f9416086 	ldr	x6, [x4, #704]
    7374:	f9400047 	ldr	x7, [x2]
    7378:	f90057e7 	str	x7, [sp, #168]
    737c:	d2800007 	mov	x7, #0x0                   	// #0
    7380:	f0fffff3 	adrp	x19, 6000 <fwp_tape_finish+0x30>
    7384:	12800007 	mov	w7, #0xffffffff            	// #-1
    7388:	91034262 	add	x2, x19, #0xd0
    738c:	cb010281 	sub	x1, x20, x1
    7390:	b9002be7 	str	w7, [sp, #40]
    7394:	aa0003f6 	mov	x22, x0
    7398:	a9030be6 	stp	x6, x2, [sp, #48]
    739c:	f90023f9 	str	x25, [sp, #64]
    73a0:	f901609a 	str	x26, [x4, #704]
    73a4:	eb05403f 	cmp	x1, x5, lsl #16
    73a8:	54000342 	b.cs	7410 <f12+0xf0>  // b.hs, b.nlast
    73ac:	d350fc20 	lsr	x0, x1, #16
    73b0:	f949fc64 	ldr	x4, [x3, #5112]
    73b4:	8b000800 	add	x0, x0, x0, lsl #2
    73b8:	d37df002 	lsl	x2, x0, #3
    73bc:	8b020083 	add	x3, x4, x2
    73c0:	f9401060 	ldr	x0, [x3, #32]
    73c4:	b4000260 	cbz	x0, 7410 <f12+0xf0>
    73c8:	38626882 	ldrb	w2, [x4, x2]
    73cc:	7100085f 	cmp	w2, #0x2
    73d0:	54006c80 	b.eq	8160 <f12+0xe40>  // b.none
    73d4:	7100045f 	cmp	w2, #0x1
    73d8:	540001c1 	b.ne	7410 <f12+0xf0>  // b.any
    73dc:	29430864 	ldp	w4, w2, [x3, #24]
    73e0:	92403c21 	and	x1, x1, #0xffff
    73e4:	9b047c21 	mul	x1, x1, x4
    73e8:	d360fc21 	lsr	x1, x1, #32
    73ec:	eb02003f 	cmp	x1, x2
    73f0:	54000102 	b.cs	7410 <f12+0xf0>  // b.hs, b.nlast
    73f4:	8b010000 	add	x0, x0, x1
    73f8:	39400001 	ldrb	w1, [x0]
    73fc:	340000a1 	cbz	w1, 7410 <f12+0xf0>
    7400:	7103f43f 	cmp	w1, #0xfd
    7404:	54007348 	b.hi	826c <f12+0xf4c>  // b.pmore
    7408:	11000421 	add	w1, w1, #0x1
    740c:	39000001 	strb	w1, [x0]
    7410:	aa1403e0 	mov	x0, x20
    7414:	97fffa4f 	bl	5d50 <fwp_closure_drop>
    7418:	b4006af6 	cbz	x22, 8174 <f12+0xe54>
    741c:	aa1603e0 	mov	x0, x22
    7420:	d2800001 	mov	x1, #0x0                   	// #0
    7424:	d503201f 	nop
    7428:	f9400800 	ldr	x0, [x0, #16]
    742c:	91000421 	add	x1, x1, #0x1
    7430:	b5ffffc0 	cbnz	x0, 7428 <f12+0x108>
    7434:	aa0103fc 	mov	x28, x1
    7438:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    743c:	eb00003f 	cmp	x1, x0
    7440:	54007488 	b.hi	82d0 <f12+0xfb0>  // b.pmore
    7444:	910102f4 	add	x20, x23, #0x40
    7448:	b942f680 	ldr	w0, [x20, #756]
    744c:	34006760 	cbz	w0, 8138 <f12+0xe18>
    7450:	910102e0 	add	x0, x23, #0x40
    7454:	f9402014 	ldr	x20, [x0, #64]
    7458:	f9404c1b 	ldr	x27, [x0, #152]
    745c:	eb14037f 	cmp	x27, x20
    7460:	5400066a 	b.ge	752c <f12+0x20c>  // b.tcont
    7464:	f94022e1 	ldr	x1, [x23, #64]
    7468:	8b1b0760 	add	x0, x27, x27, lsl #1
    746c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    7470:	8b000b60 	add	x0, x27, x0, lsl #2
    7474:	8b000c20 	add	x0, x1, x0, lsl #3
    7478:	b9400401 	ldr	w1, [x0, #4]
    747c:	35000081 	cbnz	w1, 748c <f12+0x16c>
    7480:	b9400001 	ldr	w1, [x0]
    7484:	6b02003f 	cmp	w1, w2
    7488:	54000529 	b.ls	752c <f12+0x20c>  // b.plast
    748c:	9100077b 	add	x27, x27, #0x1
    7490:	9101a000 	add	x0, x0, #0x68
    7494:	eb14037f 	cmp	x27, x20
    7498:	54ffff01 	b.ne	7478 <f12+0x158>  // b.any
    749c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    74a0:	eb00029f 	cmp	x20, x0
    74a4:	540071ec 	b.gt	82e0 <f12+0xfc0>
    74a8:	910102e0 	add	x0, x23, #0x40
    74ac:	f94022e3 	ldr	x3, [x23, #64]
    74b0:	f9404800 	ldr	x0, [x0, #144]
    74b4:	eb14001f 	cmp	x0, x20
    74b8:	54000201 	b.ne	74f8 <f12+0x1d8>  // b.any
    74bc:	b4006c14 	cbz	x20, 823c <f12+0xf1c>
    74c0:	d37ffa98 	lsl	x24, x20, #1
    74c4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    74c8:	eb00031f 	cmp	x24, x0
    74cc:	9a80d318 	csel	x24, x24, x0, le
    74d0:	8b180701 	add	x1, x24, x24, lsl #1
    74d4:	8b010b01 	add	x1, x24, x1, lsl #2
    74d8:	d37df021 	lsl	x1, x1, #3
    74dc:	aa0303e0 	mov	x0, x3
    74e0:	97ffecc0 	bl	27e0 <realloc@plt>
    74e4:	aa0003e3 	mov	x3, x0
    74e8:	b40060a0 	cbz	x0, 80fc <f12+0xddc>
    74ec:	910102e0 	add	x0, x23, #0x40
    74f0:	f90022e3 	str	x3, [x23, #64]
    74f4:	f9004818 	str	x24, [x0, #144]
    74f8:	8b140681 	add	x1, x20, x20, lsl #1
    74fc:	910102e0 	add	x0, x23, #0x40
    7500:	4f000400 	movi	v0.4s, #0x0
    7504:	aa1403fb 	mov	x27, x20
    7508:	8b010a81 	add	x1, x20, x1, lsl #2
    750c:	91000694 	add	x20, x20, #0x1
    7510:	f9002014 	str	x20, [x0, #64]
    7514:	8b010c61 	add	x1, x3, x1, lsl #3
    7518:	ad000020 	stp	q0, q0, [x1]
    751c:	ad010020 	stp	q0, q0, [x1, #32]
    7520:	ad020020 	stp	q0, q0, [x1, #64]
    7524:	f900303f 	str	xzr, [x1, #96]
    7528:	14000004 	b	7538 <f12+0x218>
    752c:	eb1b029f 	cmp	x20, x27
    7530:	54fffb60 	b.eq	749c <f12+0x17c>  // b.none
    7534:	f94022e3 	ldr	x3, [x23, #64]
    7538:	8b1b0774 	add	x20, x27, x27, lsl #1
    753c:	d0000020 	adrp	x0, d000 <__modti3+0x1f0>
    7540:	910fa000 	add	x0, x0, #0x3e8
    7544:	8b140b74 	add	x20, x27, x20, lsl #2
    7548:	f90003e3 	str	x3, [sp]
    754c:	8b140c74 	add	x20, x3, x20, lsl #3
    7550:	f900329f 	str	xzr, [x20, #96]
    7554:	97ffed0b 	bl	2980 <getenv@plt>
    7558:	f94003e3 	ldr	x3, [sp]
    755c:	b4000080 	cbz	x0, 756c <f12+0x24c>
    7560:	39400001 	ldrb	w1, [x0]
    7564:	7100c03f 	cmp	w1, #0x30
    7568:	54002e00 	b.eq	7b28 <f12+0x808>  // b.none
    756c:	910102e0 	add	x0, x23, #0x40
    7570:	f9404001 	ldr	x1, [x0, #128]
    7574:	b50060e1 	cbnz	x1, 8190 <f12+0xe70>
    7578:	910102e2 	add	x2, x23, #0x40
    757c:	2f000400 	mvni	v0.2s, #0x0
    7580:	b9400298 	ldr	w24, [x20]
    7584:	52800024 	mov	w4, #0x1                   	// #1
    7588:	91000760 	add	x0, x27, #0x1
    758c:	a900f29c 	stp	x28, x28, [x20, #8]
    7590:	0b040318 	add	w24, w24, w4
    7594:	f9416041 	ldr	x1, [x2, #704]
    7598:	29001298 	stp	w24, w4, [x20]
    759c:	f9002a9f 	str	xzr, [x20, #80]
    75a0:	f9004c40 	str	x0, [x2, #152]
    75a4:	fd002e80 	str	d0, [x20, #88]
    75a8:	b40068e1 	cbz	x1, 82c4 <f12+0xfa4>
    75ac:	91034273 	add	x19, x19, #0xd0
    75b0:	14000003 	b	75bc <f12+0x29c>
    75b4:	f9400021 	ldr	x1, [x1]
    75b8:	b4006861 	cbz	x1, 82c4 <f12+0xfa4>
    75bc:	f9400422 	ldr	x2, [x1, #8]
    75c0:	eb13005f 	cmp	x2, x19
    75c4:	54ffff81 	b.ne	75b4 <f12+0x294>  // b.any
    75c8:	f9400821 	ldr	x1, [x1, #16]
    75cc:	2a1b03e4 	mov	w4, w27
    75d0:	b9400022 	ldr	w2, [x1]
    75d4:	f9002a81 	str	x1, [x20, #80]
    75d8:	b9005e82 	str	w2, [x20, #92]
    75dc:	37f80082 	tbnz	w2, #31, 75ec <f12+0x2cc>
    75e0:	52800d05 	mov	w5, #0x68                  	// #104
    75e4:	9b250c42 	smaddl	x2, w2, w5, x3
    75e8:	b900585b 	str	w27, [x2, #88]
    75ec:	b9000024 	str	w4, [x1]
    75f0:	d3707f18 	ubfiz	x24, x24, #16, #32
    75f4:	aa000318 	orr	x24, x24, x0
    75f8:	d2800002 	mov	x2, #0x0                   	// #0
    75fc:	aa1603e0 	mov	x0, x22
    7600:	b40054f6 	cbz	x22, 809c <f12+0xd7c>
    7604:	d503201f 	nop
    7608:	f9400800 	ldr	x0, [x0, #16]
    760c:	91000442 	add	x2, x2, #0x1
    7610:	b5ffffc0 	cbnz	x0, 7608 <f12+0x2e8>
    7614:	aa1603e1 	mov	x1, x22
    7618:	f9400821 	ldr	x1, [x1, #16]
    761c:	91000400 	add	x0, x0, #0x1
    7620:	b5ffffc1 	cbnz	x1, 7618 <f12+0x2f8>
    7624:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7628:	eb01001f 	cmp	x0, x1
    762c:	54006408 	b.hi	82ac <f12+0xf8c>  // b.pmore
    7630:	f100005f 	cmp	x2, #0x0
    7634:	5400534d 	b.le	809c <f12+0xd7c>
    7638:	eb00005f 	cmp	x2, x0
    763c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7640:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    7644:	eb01027f 	cmp	x19, x1
    7648:	54006328 	b.hi	82ac <f12+0xf8c>  // b.pmore
    764c:	d37ffa74 	lsl	x20, x19, #1
    7650:	52800041 	mov	w1, #0x2                   	// #2
    7654:	91000680 	add	x0, x20, #0x1
    7658:	d37df000 	lsl	x0, x0, #3
    765c:	97fff565 	bl	4bf0 <fwp_heap_alloc>
    7660:	aa0003fb 	mov	x27, x0
    7664:	911542a1 	add	x1, x21, #0x550
    7668:	aa0103e0 	mov	x0, x1
    766c:	f9000374 	str	x20, [x27]
    7670:	f949d821 	ldr	x1, [x1, #5040]
    7674:	f949ec00 	ldr	x0, [x0, #5080]
    7678:	cb010361 	sub	x1, x27, x1
    767c:	eb00403f 	cmp	x1, x0, lsl #16
    7680:	54005562 	b.cs	812c <f12+0xe0c>  // b.hs, b.nlast
    7684:	911542a2 	add	x2, x21, #0x550
    7688:	d350fc20 	lsr	x0, x1, #16
    768c:	8b000800 	add	x0, x0, x0, lsl #2
    7690:	f949fc43 	ldr	x3, [x2, #5112]
    7694:	d37df002 	lsl	x2, x0, #3
    7698:	8b020060 	add	x0, x3, x2
    769c:	f9401014 	ldr	x20, [x0, #32]
    76a0:	b4000254 	cbz	x20, 76e8 <f12+0x3c8>
    76a4:	38626862 	ldrb	w2, [x3, x2]
    76a8:	7100085f 	cmp	w2, #0x2
    76ac:	54005540 	b.eq	8154 <f12+0xe34>  // b.none
    76b0:	7100045f 	cmp	w2, #0x1
    76b4:	540001a1 	b.ne	76e8 <f12+0x3c8>  // b.any
    76b8:	29430002 	ldp	w2, w0, [x0, #24]
    76bc:	92403c21 	and	x1, x1, #0xffff
    76c0:	9b027c21 	mul	x1, x1, x2
    76c4:	d360fc21 	lsr	x1, x1, #32
    76c8:	eb00003f 	cmp	x1, x0
    76cc:	540000e2 	b.cs	76e8 <f12+0x3c8>  // b.hs, b.nlast
    76d0:	8b010294 	add	x20, x20, x1
    76d4:	39400280 	ldrb	w0, [x20]
    76d8:	7103fc1f 	cmp	w0, #0xff
    76dc:	54005bc0 	b.eq	8254 <f12+0xf34>  // b.none
    76e0:	52800020 	mov	w0, #0x1                   	// #1
    76e4:	39000280 	strb	w0, [x20]
    76e8:	b4000233 	cbz	x19, 772c <f12+0x40c>
    76ec:	d3607f04 	lsl	x4, x24, #32
    76f0:	aa1603e2 	mov	x2, x22
    76f4:	f94006c5 	ldr	x5, [x22, #8]
    76f8:	aa0403e3 	mov	x3, x4
    76fc:	91002360 	add	x0, x27, #0x8
    7700:	d2800001 	mov	x1, #0x0                   	// #0
    7704:	14000005 	b	7718 <f12+0x3f8>
    7708:	f9400445 	ldr	x5, [x2, #8]
    770c:	ab040023 	adds	x3, x1, x4
    7710:	91004000 	add	x0, x0, #0x10
    7714:	54005f26 	b.vs	82f8 <f12+0xfd8>
    7718:	a9000c05 	stp	x5, x3, [x0]
    771c:	91000421 	add	x1, x1, #0x1
    7720:	f9400842 	ldr	x2, [x2, #16]
    7724:	eb01027f 	cmp	x19, x1
    7728:	54ffff08 	b.hi	7708 <f12+0x3e8>  // b.pmore
    772c:	f9400360 	ldr	x0, [x27]
    7730:	f100041f 	cmp	x0, #0x1
    7734:	54004fe9 	b.ls	8130 <f12+0xe10>  // b.plast
    7738:	d341fc00 	lsr	x0, x0, #1
    773c:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    7740:	d1000401 	sub	x1, x0, #0x1
    7744:	eb02003f 	cmp	x1, x2
    7748:	54005b28 	b.hi	82ac <f12+0xf8c>  // b.pmore
    774c:	d37ff83c 	lsl	x28, x1, #1
    7750:	b4004f01 	cbz	x1, 8130 <f12+0xe10>
    7754:	d1002361 	sub	x1, x27, #0x8
    7758:	91002373 	add	x19, x27, #0x8
    775c:	8b001034 	add	x20, x1, x0, lsl #4
    7760:	f9400660 	ldr	x0, [x19, #8]
    7764:	f9400e61 	ldr	x1, [x19, #24]
    7768:	fd400260 	ldr	d0, [x19]
    776c:	fd400a61 	ldr	d1, [x19, #16]
    7770:	97fff6d0 	bl	52b0 <w107>
    7774:	a9000660 	stp	x0, x1, [x19]
    7778:	91004273 	add	x19, x19, #0x10
    777c:	eb14027f 	cmp	x19, x20
    7780:	54ffff01 	b.ne	7760 <f12+0x440>  // b.any
    7784:	f900037c 	str	x28, [x27]
    7788:	aa1b03e0 	mov	x0, x27
    778c:	93407f13 	sxtw	x19, w24
    7790:	97fff725 	bl	5424 <w164.constprop.0>
    7794:	aa0103f4 	mov	x20, x1
    7798:	aa1b03e0 	mov	x0, x27
    779c:	97fffba1 	bl	6620 <fwp_drop4>
    77a0:	aa1303e0 	mov	x0, x19
    77a4:	97fff023 	bl	3830 <fwp_tape_of>
    77a8:	f9403001 	ldr	x1, [x0, #96]
    77ac:	aa0003e8 	mov	x8, x0
    77b0:	b5005841 	cbnz	x1, 82b8 <f12+0xf98>
    77b4:	97ffedd7 	bl	2f10 <fwp_tape_unlink_scope>
    77b8:	b9400002 	ldr	w2, [x0]
    77bc:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    77c0:	a940801c 	ldp	x28, x0, [x0, #8]
    77c4:	b900051f 	str	wzr, [x8, #4]
    77c8:	a941910a 	ldp	x10, x4, [x8, #24]
    77cc:	a9429905 	ldp	x5, x6, [x8, #40]
    77d0:	a9438d07 	ldp	x7, x3, [x8, #56]
    77d4:	f940251b 	ldr	x27, [x8, #72]
    77d8:	6b01005f 	cmp	w2, w1
    77dc:	54000108 	b.hi	77fc <f12+0x4dc>  // b.pmore
    77e0:	910102e2 	add	x2, x23, #0x40
    77e4:	92403e61 	and	x1, x19, #0xffff
    77e8:	d1000421 	sub	x1, x1, #0x1
    77ec:	f9404c49 	ldr	x9, [x2, #152]
    77f0:	eb09003f 	cmp	x1, x9
    77f4:	5400004a 	b.ge	77fc <f12+0x4dc>  // b.tcont
    77f8:	f9004c41 	str	x1, [x2, #152]
    77fc:	4f000400 	movi	v0.4s, #0x0
    7800:	910102e9 	add	x9, x23, #0x40
    7804:	f9000d1f 	str	xzr, [x8, #24]
    7808:	910123e1 	add	x1, sp, #0x48
    780c:	910183f8 	add	x24, sp, #0x60
    7810:	b0ffffe2 	adrp	x2, 4000 <fwp_wake_io+0x3c>
    7814:	f941612b 	ldr	x11, [x9, #704]
    7818:	3c808100 	stur	q0, [x8, #8]
    781c:	91020042 	add	x2, x2, #0x80
    7820:	ad010100 	stp	q0, q0, [x8, #32]
    7824:	a9047d1f 	stp	xzr, xzr, [x8, #64]
    7828:	a9048beb 	stp	x11, x2, [sp, #72]
    782c:	a90593f8 	stp	x24, x4, [sp, #88]
    7830:	a9069be5 	stp	x5, x6, [sp, #104]
    7834:	a9078fe7 	stp	x7, x3, [sp, #120]
    7838:	a908efea 	stp	x10, x27, [sp, #136]
    783c:	f9016121 	str	x1, [x9, #704]
    7840:	b7f849f4 	tbnz	x20, #63, 817c <f12+0xe5c>
    7844:	eb94827f 	cmp	x19, x20, asr #32
    7848:	54005261 	b.ne	8294 <f12+0xf74>  // b.any
    784c:	92407e93 	and	x19, x20, #0xffffffff
    7850:	eb34401f 	cmp	x0, w20, uxtw
    7854:	540051ad 	b.le	8288 <f12+0xf68>
    7858:	eb13039f 	cmp	x28, x19
    785c:	9a93c793 	csinc	x19, x28, x19, gt
    7860:	eb13037f 	cmp	x27, x19
    7864:	540043ca 	b.ge	80dc <f12+0xdbc>  // b.tcont
    7868:	f100037f 	cmp	x27, #0x0
    786c:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7870:	9a93137b 	csel	x27, x27, x19, ne	// ne = any
    7874:	14000004 	b	7884 <f12+0x564>
    7878:	eb01037f 	cmp	x27, x1
    787c:	d37ffb7b 	lsl	x27, x27, #1
    7880:	9a93d37b 	csel	x27, x27, x19, le
    7884:	eb13037f 	cmp	x27, x19
    7888:	54ffff8b 	b.lt	7878 <f12+0x558>  // b.tstop
    788c:	a90017e4 	stp	x4, x5, [sp]
    7890:	a9011fe6 	stp	x6, x7, [sp, #16]
    7894:	b4004b03 	cbz	x3, 81f4 <f12+0xed4>
    7898:	aa0303e0 	mov	x0, x3
    789c:	d37df361 	lsl	x1, x27, #3
    78a0:	97ffebd0 	bl	27e0 <realloc@plt>
    78a4:	aa0003e3 	mov	x3, x0
    78a8:	a94017e4 	ldp	x4, x5, [sp]
    78ac:	a9411fe6 	ldp	x6, x7, [sp, #16]
    78b0:	b4004163 	cbz	x3, 80dc <f12+0xdbc>
    78b4:	f90043e3 	str	x3, [sp, #128]
    78b8:	f9004bfb 	str	x27, [sp, #144]
    78bc:	b50013d3 	cbnz	x19, 7b34 <f12+0x814>
    78c0:	b7f800d4 	tbnz	x20, #63, 78d8 <f12+0x5b8>
    78c4:	92407e94 	and	x20, x20, #0xffffffff
    78c8:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    78cc:	fc747860 	ldr	d0, [x3, x20, lsl #3]
    78d0:	1e612800 	fadd	d0, d0, d1
    78d4:	fc347860 	str	d0, [x3, x20, lsl #3]
    78d8:	d1000673 	sub	x19, x19, #0x1
    78dc:	d1000788 	sub	x8, x28, #0x1
    78e0:	eb13039f 	cmp	x28, x19
    78e4:	540003ac 	b.gt	7958 <f12+0x638>
    78e8:	fc737860 	ldr	d0, [x3, x19, lsl #3]
    78ec:	1e602008 	fcmp	d0, #0.0
    78f0:	540002e0 	b.eq	794c <f12+0x62c>  // b.none
    78f4:	cb1c0be0 	neg	x0, x28, lsl #2
    78f8:	cb1c03e2 	neg	x2, x28
    78fc:	8b000081 	add	x1, x4, x0
    7900:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    7904:	37f80101 	tbnz	w1, #31, 7924 <f12+0x604>
    7908:	8b020cc9 	add	x9, x6, x2, lsl #3
    790c:	93407c21 	sxtw	x1, w1
    7910:	fc737922 	ldr	d2, [x9, x19, lsl #3]
    7914:	fc617861 	ldr	d1, [x3, x1, lsl #3]
    7918:	1e620802 	fmul	d2, d0, d2
    791c:	1e622821 	fadd	d1, d1, d2
    7920:	fc217861 	str	d1, [x3, x1, lsl #3]
    7924:	8b0000a0 	add	x0, x5, x0
    7928:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    792c:	37f80100 	tbnz	w0, #31, 794c <f12+0x62c>
    7930:	8b020ce2 	add	x2, x7, x2, lsl #3
    7934:	93407c00 	sxtw	x0, w0
    7938:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    793c:	fc607861 	ldr	d1, [x3, x0, lsl #3]
    7940:	1e620800 	fmul	d0, d0, d2
    7944:	1e602820 	fadd	d0, d1, d0
    7948:	fc207860 	str	d0, [x3, x0, lsl #3]
    794c:	d1000673 	sub	x19, x19, #0x1
    7950:	eb13011f 	cmp	x8, x19
    7954:	54fffca1 	b.ne	78e8 <f12+0x5c8>  // b.any
    7958:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    795c:	eb00039f 	cmp	x28, x0
    7960:	54004c68 	b.hi	82ec <f12+0xfcc>  // b.pmore
    7964:	91000780 	add	x0, x28, #0x1
    7968:	52800041 	mov	w1, #0x2                   	// #2
    796c:	f90003e3 	str	x3, [sp]
    7970:	d37df000 	lsl	x0, x0, #3
    7974:	97fff49f 	bl	4bf0 <fwp_heap_alloc>
    7978:	aa0003e2 	mov	x2, x0
    797c:	aa0003f3 	mov	x19, x0
    7980:	f94003e3 	ldr	x3, [sp]
    7984:	d2800001 	mov	x1, #0x0                   	// #0
    7988:	f800845c 	str	x28, [x2], #8
    798c:	b40000dc 	cbz	x28, 79a4 <f12+0x684>
    7990:	f8617860 	ldr	x0, [x3, x1, lsl #3]
    7994:	f8217840 	str	x0, [x2, x1, lsl #3]
    7998:	91000421 	add	x1, x1, #0x1
    799c:	eb01039f 	cmp	x28, x1
    79a0:	54ffff81 	b.ne	7990 <f12+0x670>  // b.any
    79a4:	910102e1 	add	x1, x23, #0x40
    79a8:	aa1803e0 	mov	x0, x24
    79ac:	f94027f8 	ldr	x24, [sp, #72]
    79b0:	f9016038 	str	x24, [x1, #704]
    79b4:	97fff1b3 	bl	4080 <fwp_tape_buffers_release>
    79b8:	911542a2 	add	x2, x21, #0x550
    79bc:	f949d841 	ldr	x1, [x2, #5040]
    79c0:	f949ec40 	ldr	x0, [x2, #5080]
    79c4:	cb010261 	sub	x1, x19, x1
    79c8:	eb00403f 	cmp	x1, x0, lsl #16
    79cc:	54000322 	b.cs	7a30 <f12+0x710>  // b.hs, b.nlast
    79d0:	d350fc20 	lsr	x0, x1, #16
    79d4:	f949fc43 	ldr	x3, [x2, #5112]
    79d8:	8b000800 	add	x0, x0, x0, lsl #2
    79dc:	d37df002 	lsl	x2, x0, #3
    79e0:	8b020060 	add	x0, x3, x2
    79e4:	f9401014 	ldr	x20, [x0, #32]
    79e8:	b4000254 	cbz	x20, 7a30 <f12+0x710>
    79ec:	38626862 	ldrb	w2, [x3, x2]
    79f0:	7100085f 	cmp	w2, #0x2
    79f4:	54003c80 	b.eq	8184 <f12+0xe64>  // b.none
    79f8:	7100045f 	cmp	w2, #0x1
    79fc:	540001a1 	b.ne	7a30 <f12+0x710>  // b.any
    7a00:	29430002 	ldp	w2, w0, [x0, #24]
    7a04:	92403c21 	and	x1, x1, #0xffff
    7a08:	9b027c21 	mul	x1, x1, x2
    7a0c:	d360fc21 	lsr	x1, x1, #32
    7a10:	eb00003f 	cmp	x1, x0
    7a14:	540000e2 	b.cs	7a30 <f12+0x710>  // b.hs, b.nlast
    7a18:	8b010294 	add	x20, x20, x1
    7a1c:	39400280 	ldrb	w0, [x20]
    7a20:	7103fc1f 	cmp	w0, #0xff
    7a24:	54004120 	b.eq	8248 <f12+0xf28>  // b.none
    7a28:	52800020 	mov	w0, #0x1                   	// #1
    7a2c:	39000280 	strb	w0, [x20]
    7a30:	eb1a031f 	cmp	x24, x26
    7a34:	54004641 	b.ne	82fc <f12+0xfdc>  // b.any
    7a38:	f9401be1 	ldr	x1, [sp, #48]
    7a3c:	910102f7 	add	x23, x23, #0x40
    7a40:	aa1903e0 	mov	x0, x25
    7a44:	f90162e1 	str	x1, [x23, #704]
    7a48:	97fff9a2 	bl	60d0 <fwp_tape_scope_release>
    7a4c:	f9400260 	ldr	x0, [x19]
    7a50:	9240f814 	and	x20, x0, #0x7fffffffffffffff
    7a54:	b7f82ca0 	tbnz	x0, #63, 7fe8 <f12+0xcc8>
    7a58:	911542a2 	add	x2, x21, #0x550
    7a5c:	f949d840 	ldr	x0, [x2, #5040]
    7a60:	f949ec41 	ldr	x1, [x2, #5080]
    7a64:	cb000260 	sub	x0, x19, x0
    7a68:	eb01401f 	cmp	x0, x1, lsl #16
    7a6c:	54002be2 	b.cs	7fe8 <f12+0xcc8>  // b.hs, b.nlast
    7a70:	d350fc01 	lsr	x1, x0, #16
    7a74:	f949fc44 	ldr	x4, [x2, #5112]
    7a78:	8b010821 	add	x1, x1, x1, lsl #2
    7a7c:	d37df021 	lsl	x1, x1, #3
    7a80:	8b010083 	add	x3, x4, x1
    7a84:	f9401062 	ldr	x2, [x3, #32]
    7a88:	b4002b02 	cbz	x2, 7fe8 <f12+0xcc8>
    7a8c:	38616881 	ldrb	w1, [x4, x1]
    7a90:	7100083f 	cmp	w1, #0x2
    7a94:	54002a40 	b.eq	7fdc <f12+0xcbc>  // b.none
    7a98:	7100043f 	cmp	w1, #0x1
    7a9c:	54002a61 	b.ne	7fe8 <f12+0xcc8>  // b.any
    7aa0:	29430464 	ldp	w4, w1, [x3, #24]
    7aa4:	92403c00 	and	x0, x0, #0xffff
    7aa8:	9b047c00 	mul	x0, x0, x4
    7aac:	d360fc00 	lsr	x0, x0, #32
    7ab0:	eb01001f 	cmp	x0, x1
    7ab4:	540029a2 	b.cs	7fe8 <f12+0xcc8>  // b.hs, b.nlast
    7ab8:	8b000042 	add	x2, x2, x0
    7abc:	39400040 	ldrb	w0, [x2]
    7ac0:	7100041f 	cmp	w0, #0x1
    7ac4:	54002921 	b.ne	7fe8 <f12+0xcc8>  // b.any
    7ac8:	aa1303fa 	mov	x26, x19
    7acc:	d2800000 	mov	x0, #0x0                   	// #0
    7ad0:	f90003f3 	str	x19, [sp]
    7ad4:	f94003e1 	ldr	x1, [sp]
    7ad8:	91002023 	add	x3, x1, #0x8
    7adc:	d2800001 	mov	x1, #0x0                   	// #0
    7ae0:	b40003f4 	cbz	x20, 7b5c <f12+0x83c>
    7ae4:	d0000022 	adrp	x2, d000 <__modti3+0x1f0>
    7ae8:	91002265 	add	x5, x19, #0x8
    7aec:	fd474041 	ldr	d1, [x2, #3712]
    7af0:	14000009 	b	7b14 <f12+0x7f4>
    7af4:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    7af8:	f9400342 	ldr	x2, [x26]
    7afc:	1e600820 	fmul	d0, d1, d0
    7b00:	b7f83d02 	tbnz	x2, #63, 82a0 <f12+0xf80>
    7b04:	91000421 	add	x1, x1, #0x1
    7b08:	fc008460 	str	d0, [x3], #8
    7b0c:	eb01029f 	cmp	x20, x1
    7b10:	54000260 	b.eq	7b5c <f12+0x83c>  // b.none
    7b14:	f9400264 	ldr	x4, [x19]
    7b18:	aa0503e2 	mov	x2, x5
    7b1c:	b6fffec4 	tbz	x4, #63, 7af4 <f12+0x7d4>
    7b20:	f9400a62 	ldr	x2, [x19, #16]
    7b24:	17fffff4 	b	7af4 <f12+0x7d4>
    7b28:	39400400 	ldrb	w0, [x0, #1]
    7b2c:	34ffd260 	cbz	w0, 7578 <f12+0x258>
    7b30:	17fffe8f 	b	756c <f12+0x24c>
    7b34:	aa0303e0 	mov	x0, x3
    7b38:	d37df262 	lsl	x2, x19, #3
    7b3c:	52800001 	mov	w1, #0x0                   	// #0
    7b40:	a90017e4 	stp	x4, x5, [sp]
    7b44:	a9011fe6 	stp	x6, x7, [sp, #16]
    7b48:	97ffeb1e 	bl	27c0 <memset@plt>
    7b4c:	aa0003e3 	mov	x3, x0
    7b50:	a94017e4 	ldp	x4, x5, [sp]
    7b54:	a9411fe6 	ldp	x6, x7, [sp, #16]
    7b58:	17ffff5a 	b	78c0 <f12+0x5a0>
    7b5c:	97fffab1 	bl	6620 <fwp_drop4>
    7b60:	aa1603e1 	mov	x1, x22
    7b64:	d2800002 	mov	x2, #0x0                   	// #0
    7b68:	b4003556 	cbz	x22, 8210 <f12+0xef0>
    7b6c:	d503201f 	nop
    7b70:	f9400821 	ldr	x1, [x1, #16]
    7b74:	91000442 	add	x2, x2, #0x1
    7b78:	b5ffffc1 	cbnz	x1, 7b70 <f12+0x850>
    7b7c:	f9400343 	ldr	x3, [x26]
    7b80:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    7b84:	b7f81f43 	tbnz	x3, #63, 7f6c <f12+0xc4c>
    7b88:	911542a1 	add	x1, x21, #0x550
    7b8c:	f94003e4 	ldr	x4, [sp]
    7b90:	f949d820 	ldr	x0, [x1, #5040]
    7b94:	f949ec21 	ldr	x1, [x1, #5080]
    7b98:	cb000080 	sub	x0, x4, x0
    7b9c:	eb01401f 	cmp	x0, x1, lsl #16
    7ba0:	54001e62 	b.cs	7f6c <f12+0xc4c>  // b.hs, b.nlast
    7ba4:	911542a4 	add	x4, x21, #0x550
    7ba8:	d350fc01 	lsr	x1, x0, #16
    7bac:	8b010821 	add	x1, x1, x1, lsl #2
    7bb0:	f949fc86 	ldr	x6, [x4, #5112]
    7bb4:	d37df021 	lsl	x1, x1, #3
    7bb8:	8b0100c5 	add	x5, x6, x1
    7bbc:	f94010a4 	ldr	x4, [x5, #32]
    7bc0:	b4001d44 	cbz	x4, 7f68 <f12+0xc48>
    7bc4:	386168c1 	ldrb	w1, [x6, x1]
    7bc8:	7100083f 	cmp	w1, #0x2
    7bcc:	54001ca0 	b.eq	7f60 <f12+0xc40>  // b.none
    7bd0:	7100043f 	cmp	w1, #0x1
    7bd4:	54001ca1 	b.ne	7f68 <f12+0xc48>  // b.any
    7bd8:	294304a6 	ldp	w6, w1, [x5, #24]
    7bdc:	92403c00 	and	x0, x0, #0xffff
    7be0:	9b067c00 	mul	x0, x0, x6
    7be4:	d360fc00 	lsr	x0, x0, #32
    7be8:	eb01001f 	cmp	x0, x1
    7bec:	54001be2 	b.cs	7f68 <f12+0xc48>  // b.hs, b.nlast
    7bf0:	8b000084 	add	x4, x4, x0
    7bf4:	39400098 	ldrb	w24, [x4]
    7bf8:	7100071f 	cmp	w24, #0x1
    7bfc:	54001b61 	b.ne	7f68 <f12+0xc48>  // b.any
    7c00:	b9000bf8 	str	w24, [sp, #8]
    7c04:	eb1c005f 	cmp	x2, x28
    7c08:	9a9c905c 	csel	x28, x2, x28, ls	// ls = plast
    7c0c:	91002359 	add	x25, x26, #0x8
    7c10:	b400337c 	cbz	x28, 827c <f12+0xf5c>
    7c14:	f94003e0 	ldr	x0, [sp]
    7c18:	d37df385 	lsl	x5, x28, #3
    7c1c:	aa1603e2 	mov	x2, x22
    7c20:	d2800001 	mov	x1, #0x0                   	// #0
    7c24:	91002000 	add	x0, x0, #0x8
    7c28:	1400000a 	b	7c50 <f12+0x930>
    7c2c:	fc616881 	ldr	d1, [x4, x1]
    7c30:	fd400440 	ldr	d0, [x2, #8]
    7c34:	1e613800 	fsub	d0, d0, d1
    7c38:	fc216b20 	str	d0, [x25, x1]
    7c3c:	91002021 	add	x1, x1, #0x8
    7c40:	f9400842 	ldr	x2, [x2, #16]
    7c44:	eb05003f 	cmp	x1, x5
    7c48:	540001c0 	b.eq	7c80 <f12+0x960>  // b.none
    7c4c:	f9400343 	ldr	x3, [x26]
    7c50:	aa0003e4 	mov	x4, x0
    7c54:	b6fffec3 	tbz	x3, #63, 7c2c <f12+0x90c>
    7c58:	f94003e3 	ldr	x3, [sp]
    7c5c:	fd400440 	ldr	d0, [x2, #8]
    7c60:	f9400864 	ldr	x4, [x3, #16]
    7c64:	fc616881 	ldr	d1, [x4, x1]
    7c68:	1e613800 	fsub	d0, d0, d1
    7c6c:	fc216b20 	str	d0, [x25, x1]
    7c70:	91002021 	add	x1, x1, #0x8
    7c74:	f9400842 	ldr	x2, [x2, #16]
    7c78:	eb05003f 	cmp	x1, x5
    7c7c:	54fffe81 	b.ne	7c4c <f12+0x92c>  // b.any
    7c80:	b4002fb6 	cbz	x22, 8274 <f12+0xf54>
    7c84:	911542a0 	add	x0, x21, #0x550
    7c88:	aa1603e2 	mov	x2, x22
    7c8c:	d280001a 	mov	x26, #0x0                   	// #0
    7c90:	f949ec06 	ldr	x6, [x0, #5080]
    7c94:	f949d807 	ldr	x7, [x0, #5040]
    7c98:	f949fc05 	ldr	x5, [x0, #5112]
    7c9c:	d370bcc6 	lsl	x6, x6, #16
    7ca0:	14000006 	b	7cb8 <f12+0x998>
    7ca4:	f9400842 	ldr	x2, [x2, #16]
    7ca8:	9100075a 	add	x26, x26, #0x1
    7cac:	f100005f 	cmp	x2, #0x0
    7cb0:	fa5a1380 	ccmp	x28, x26, #0x0, ne	// ne = any
    7cb4:	54001ee9 	b.ls	8090 <f12+0xd70>  // b.plast
    7cb8:	cb070040 	sub	x0, x2, x7
    7cbc:	eb06001f 	cmp	x0, x6
    7cc0:	540002c2 	b.cs	7d18 <f12+0x9f8>  // b.hs, b.nlast
    7cc4:	d350fc01 	lsr	x1, x0, #16
    7cc8:	8b010821 	add	x1, x1, x1, lsl #2
    7ccc:	d37df021 	lsl	x1, x1, #3
    7cd0:	8b0100a4 	add	x4, x5, x1
    7cd4:	f9401083 	ldr	x3, [x4, #32]
    7cd8:	b4000203 	cbz	x3, 7d18 <f12+0x9f8>
    7cdc:	386168a1 	ldrb	w1, [x5, x1]
    7ce0:	7100083f 	cmp	w1, #0x2
    7ce4:	54000de0 	b.eq	7ea0 <f12+0xb80>  // b.none
    7ce8:	7100043f 	cmp	w1, #0x1
    7cec:	54000161 	b.ne	7d18 <f12+0x9f8>  // b.any
    7cf0:	29430488 	ldp	w8, w1, [x4, #24]
    7cf4:	92403c00 	and	x0, x0, #0xffff
    7cf8:	9b087c00 	mul	x0, x0, x8
    7cfc:	d360fc00 	lsr	x0, x0, #32
    7d00:	eb01001f 	cmp	x0, x1
    7d04:	540000a2 	b.cs	7d18 <f12+0x9f8>  // b.hs, b.nlast
    7d08:	8b000063 	add	x3, x3, x0
    7d0c:	39400060 	ldrb	w0, [x3]
    7d10:	7100041f 	cmp	w0, #0x1
    7d14:	54fffc80 	b.eq	7ca4 <f12+0x984>  // b.none
    7d18:	eb1c035f 	cmp	x26, x28
    7d1c:	54000ca2 	b.cs	7eb0 <f12+0xb90>  // b.hs, b.nlast
    7d20:	d1002337 	sub	x23, x25, #0x8
    7d24:	910263f4 	add	x20, sp, #0x98
    7d28:	911542b8 	add	x24, x21, #0x550
    7d2c:	d2800013 	mov	x19, #0x0                   	// #0
    7d30:	14000012 	b	7d78 <f12+0xa58>
    7d34:	7100045f 	cmp	w2, #0x1
    7d38:	540001a1 	b.ne	7d6c <f12+0xa4c>  // b.any
    7d3c:	29430002 	ldp	w2, w0, [x0, #24]
    7d40:	92403c21 	and	x1, x1, #0xffff
    7d44:	9b027c21 	mul	x1, x1, x2
    7d48:	d360fc21 	lsr	x1, x1, #32
    7d4c:	eb00003f 	cmp	x1, x0
    7d50:	540000e2 	b.cs	7d6c <f12+0xa4c>  // b.hs, b.nlast
    7d54:	8b01037b 	add	x27, x27, x1
    7d58:	39400360 	ldrb	w0, [x27]
    7d5c:	7103fc1f 	cmp	w0, #0xff
    7d60:	54001b80 	b.eq	80d0 <f12+0xdb0>  // b.none
    7d64:	52800020 	mov	w0, #0x1                   	// #1
    7d68:	39000360 	strb	w0, [x27]
    7d6c:	d100079c 	sub	x28, x28, #0x1
    7d70:	eb1c035f 	cmp	x26, x28
    7d74:	54000362 	b.cs	7de0 <f12+0xac0>  // b.hs, b.nlast
    7d78:	f87c7ae2 	ldr	x2, [x23, x28, lsl #3]
    7d7c:	aa1403e1 	mov	x1, x20
    7d80:	52800020 	mov	w0, #0x1                   	// #1
    7d84:	a909cfe2 	stp	x2, x19, [sp, #152]
    7d88:	97fff5cf 	bl	54c4 <fwp_data.part.0.constprop.0>
    7d8c:	aa0003f3 	mov	x19, x0
    7d90:	f949db01 	ldr	x1, [x24, #5040]
    7d94:	f949ef00 	ldr	x0, [x24, #5080]
    7d98:	cb010261 	sub	x1, x19, x1
    7d9c:	eb00403f 	cmp	x1, x0, lsl #16
    7da0:	54fffe62 	b.cs	7d6c <f12+0xa4c>  // b.hs, b.nlast
    7da4:	d350fc22 	lsr	x2, x1, #16
    7da8:	f949ff03 	ldr	x3, [x24, #5112]
    7dac:	8b020842 	add	x2, x2, x2, lsl #2
    7db0:	d37df042 	lsl	x2, x2, #3
    7db4:	8b020060 	add	x0, x3, x2
    7db8:	f940101b 	ldr	x27, [x0, #32]
    7dbc:	b4fffd9b 	cbz	x27, 7d6c <f12+0xa4c>
    7dc0:	38626862 	ldrb	w2, [x3, x2]
    7dc4:	7100085f 	cmp	w2, #0x2
    7dc8:	54fffb61 	b.ne	7d34 <f12+0xa14>  // b.any
    7dcc:	72003c3f 	tst	w1, #0xffff
    7dd0:	54fffc40 	b.eq	7d58 <f12+0xa38>  // b.none
    7dd4:	d100079c 	sub	x28, x28, #0x1
    7dd8:	eb1c035f 	cmp	x26, x28
    7ddc:	54fffce3 	b.cc	7d78 <f12+0xa58>  // b.lo, b.ul, b.last
    7de0:	b50006ba 	cbnz	x26, 7eb4 <f12+0xb94>
    7de4:	b9400be0 	ldr	w0, [sp, #8]
    7de8:	d2800038 	mov	x24, #0x1                   	// #1
    7dec:	d280001b 	mov	x27, #0x0                   	// #0
    7df0:	7100001f 	cmp	w0, #0x0
    7df4:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    7df8:	b40007db 	cbz	x27, 7ef0 <f12+0xbd0>
    7dfc:	d100077b 	sub	x27, x27, #0x1
    7e00:	911542b5 	add	x21, x21, #0x550
    7e04:	d503201f 	nop
    7e08:	f87b7b22 	ldr	x2, [x25, x27, lsl #3]
    7e0c:	aa1403e1 	mov	x1, x20
    7e10:	52800020 	mov	w0, #0x1                   	// #1
    7e14:	a909cfe2 	stp	x2, x19, [sp, #152]
    7e18:	97fff5ab 	bl	54c4 <fwp_data.part.0.constprop.0>
    7e1c:	aa0003f3 	mov	x19, x0
    7e20:	f949daa1 	ldr	x1, [x21, #5040]
    7e24:	f949eea0 	ldr	x0, [x21, #5080]
    7e28:	cb010261 	sub	x1, x19, x1
    7e2c:	eb00403f 	cmp	x1, x0, lsl #16
    7e30:	54000302 	b.cs	7e90 <f12+0xb70>  // b.hs, b.nlast
    7e34:	d350fc22 	lsr	x2, x1, #16
    7e38:	f949fea3 	ldr	x3, [x21, #5112]
    7e3c:	8b020842 	add	x2, x2, x2, lsl #2
    7e40:	d37df042 	lsl	x2, x2, #3
    7e44:	8b020060 	add	x0, x3, x2
    7e48:	f940101a 	ldr	x26, [x0, #32]
    7e4c:	b400023a 	cbz	x26, 7e90 <f12+0xb70>
    7e50:	38626862 	ldrb	w2, [x3, x2]
    7e54:	7100085f 	cmp	w2, #0x2
    7e58:	540007e0 	b.eq	7f54 <f12+0xc34>  // b.none
    7e5c:	7100045f 	cmp	w2, #0x1
    7e60:	54000181 	b.ne	7e90 <f12+0xb70>  // b.any
    7e64:	29430002 	ldp	w2, w0, [x0, #24]
    7e68:	92403c21 	and	x1, x1, #0xffff
    7e6c:	9b027c21 	mul	x1, x1, x2
    7e70:	d360fc21 	lsr	x1, x1, #32
    7e74:	eb00003f 	cmp	x1, x0
    7e78:	540000c2 	b.cs	7e90 <f12+0xb70>  // b.hs, b.nlast
    7e7c:	8b01035a 	add	x26, x26, x1
    7e80:	39400340 	ldrb	w0, [x26]
    7e84:	7103fc1f 	cmp	w0, #0xff
    7e88:	54000600 	b.eq	7f48 <f12+0xc28>  // b.none
    7e8c:	39000358 	strb	w24, [x26]
    7e90:	d100077b 	sub	x27, x27, #0x1
    7e94:	b100077f 	cmn	x27, #0x1
    7e98:	54fffb81 	b.ne	7e08 <f12+0xae8>  // b.any
    7e9c:	14000015 	b	7ef0 <f12+0xbd0>
    7ea0:	72003c1f 	tst	w0, #0xffff
    7ea4:	54fff340 	b.eq	7d0c <f12+0x9ec>  // b.none
    7ea8:	eb1c035f 	cmp	x26, x28
    7eac:	54fff3a3 	b.cc	7d20 <f12+0xa00>  // b.lo, b.ul, b.last
    7eb0:	d2800013 	mov	x19, #0x0                   	// #0
    7eb4:	8b1a0f3a 	add	x26, x25, x26, lsl #3
    7eb8:	aa1903e1 	mov	x1, x25
    7ebc:	aa1603e0 	mov	x0, x22
    7ec0:	f8408422 	ldr	x2, [x1], #8
    7ec4:	f9000402 	str	x2, [x0, #8]
    7ec8:	aa0003e2 	mov	x2, x0
    7ecc:	f9400800 	ldr	x0, [x0, #16]
    7ed0:	eb1a003f 	cmp	x1, x26
    7ed4:	54ffff61 	b.ne	7ec0 <f12+0xba0>  // b.any
    7ed8:	b9400be1 	ldr	w1, [sp, #8]
    7edc:	f9000853 	str	x19, [x2, #16]
    7ee0:	aa1603f3 	mov	x19, x22
    7ee4:	aa0003f6 	mov	x22, x0
    7ee8:	34000041 	cbz	w1, 7ef0 <f12+0xbd0>
    7eec:	d2800019 	mov	x25, #0x0                   	// #0
    7ef0:	aa1903e0 	mov	x0, x25
    7ef4:	97fff21f 	bl	4770 <fwp_mem_free>
    7ef8:	f94003e0 	ldr	x0, [sp]
    7efc:	97fff9c9 	bl	6620 <fwp_drop4>
    7f00:	aa1603e0 	mov	x0, x22
    7f04:	97fff737 	bl	5be0 <fwp_drop0>
    7f08:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    7f0c:	f947f400 	ldr	x0, [x0, #4072]
    7f10:	f94057e2 	ldr	x2, [sp, #168]
    7f14:	f9400001 	ldr	x1, [x0]
    7f18:	eb010042 	subs	x2, x2, x1
    7f1c:	d2800001 	mov	x1, #0x0                   	// #0
    7f20:	54001de1 	b.ne	82dc <f12+0xfbc>  // b.any
    7f24:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    7f28:	aa1303e0 	mov	x0, x19
    7f2c:	a94c53f3 	ldp	x19, x20, [sp, #192]
    7f30:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    7f34:	a94e63f7 	ldp	x23, x24, [sp, #224]
    7f38:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    7f3c:	a95073fb 	ldp	x27, x28, [sp, #256]
    7f40:	910443ff 	add	sp, sp, #0x110
    7f44:	d65f03c0 	ret
    7f48:	aa1a03e0 	mov	x0, x26
    7f4c:	97fff169 	bl	44f0 <fwp_rc_forget_slot>
    7f50:	17ffffcf 	b	7e8c <f12+0xb6c>
    7f54:	72003c3f 	tst	w1, #0xffff
    7f58:	54fff9c1 	b.ne	7e90 <f12+0xb70>  // b.any
    7f5c:	17ffffc9 	b	7e80 <f12+0xb60>
    7f60:	72003c1f 	tst	w0, #0xffff
    7f64:	54ffe480 	b.eq	7bf4 <f12+0x8d4>  // b.none
    7f68:	b4001336 	cbz	x22, 81cc <f12+0xeac>
    7f6c:	aa1603f3 	mov	x19, x22
    7f70:	d2800014 	mov	x20, #0x0                   	// #0
    7f74:	d503201f 	nop
    7f78:	f9400a73 	ldr	x19, [x19, #16]
    7f7c:	aa1403e0 	mov	x0, x20
    7f80:	91000694 	add	x20, x20, #0x1
    7f84:	b5ffffb3 	cbnz	x19, 7f78 <f12+0xc58>
    7f88:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7f8c:	eb01029f 	cmp	x20, x1
    7f90:	540018e8 	b.hi	82ac <f12+0xf8c>  // b.pmore
    7f94:	91000800 	add	x0, x0, #0x2
    7f98:	52800041 	mov	w1, #0x2                   	// #2
    7f9c:	d37df000 	lsl	x0, x0, #3
    7fa0:	97fff314 	bl	4bf0 <fwp_heap_alloc>
    7fa4:	eb1c029f 	cmp	x20, x28
    7fa8:	aa0003f9 	mov	x25, x0
    7fac:	9a9c929c 	csel	x28, x20, x28, ls	// ls = plast
    7fb0:	aa1603e1 	mov	x1, x22
    7fb4:	d503201f 	nop
    7fb8:	f9400420 	ldr	x0, [x1, #8]
    7fbc:	f8337b20 	str	x0, [x25, x19, lsl #3]
    7fc0:	91000673 	add	x19, x19, #0x1
    7fc4:	f9400821 	ldr	x1, [x1, #16]
    7fc8:	b5ffff81 	cbnz	x1, 7fb8 <f12+0xc98>
    7fcc:	b400109c 	cbz	x28, 81dc <f12+0xebc>
    7fd0:	f9400343 	ldr	x3, [x26]
    7fd4:	b9000bff 	str	wzr, [sp, #8]
    7fd8:	17ffff0f 	b	7c14 <f12+0x8f4>
    7fdc:	72003c1f 	tst	w0, #0xffff
    7fe0:	54ffd6e0 	b.eq	7abc <f12+0x79c>  // b.none
    7fe4:	d503201f 	nop
    7fe8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7fec:	eb00029f 	cmp	x20, x0
    7ff0:	540017e8 	b.hi	82ec <f12+0xfcc>  // b.pmore
    7ff4:	91000680 	add	x0, x20, #0x1
    7ff8:	52800021 	mov	w1, #0x1                   	// #1
    7ffc:	d37df000 	lsl	x0, x0, #3
    8000:	97fff2fc 	bl	4bf0 <fwp_heap_alloc>
    8004:	911542a2 	add	x2, x21, #0x550
    8008:	f9000014 	str	x20, [x0]
    800c:	aa0003fa 	mov	x26, x0
    8010:	f90003fa 	str	x26, [sp]
    8014:	f949d841 	ldr	x1, [x2, #5040]
    8018:	f949ec40 	ldr	x0, [x2, #5080]
    801c:	cb010341 	sub	x1, x26, x1
    8020:	eb00403f 	cmp	x1, x0, lsl #16
    8024:	54000322 	b.cs	8088 <f12+0xd68>  // b.hs, b.nlast
    8028:	d350fc20 	lsr	x0, x1, #16
    802c:	f949fc43 	ldr	x3, [x2, #5112]
    8030:	8b000800 	add	x0, x0, x0, lsl #2
    8034:	d37df002 	lsl	x2, x0, #3
    8038:	8b020060 	add	x0, x3, x2
    803c:	f9401018 	ldr	x24, [x0, #32]
    8040:	b4000258 	cbz	x24, 8088 <f12+0xd68>
    8044:	38626862 	ldrb	w2, [x3, x2]
    8048:	7100085f 	cmp	w2, #0x2
    804c:	54000cc0 	b.eq	81e4 <f12+0xec4>  // b.none
    8050:	7100045f 	cmp	w2, #0x1
    8054:	540001a1 	b.ne	8088 <f12+0xd68>  // b.any
    8058:	29430002 	ldp	w2, w0, [x0, #24]
    805c:	92403c21 	and	x1, x1, #0xffff
    8060:	9b027c21 	mul	x1, x1, x2
    8064:	d360fc21 	lsr	x1, x1, #32
    8068:	eb00003f 	cmp	x1, x0
    806c:	540000e2 	b.cs	8088 <f12+0xd68>  // b.hs, b.nlast
    8070:	8b010318 	add	x24, x24, x1
    8074:	39400300 	ldrb	w0, [x24]
    8078:	7103fc1f 	cmp	w0, #0xff
    807c:	54000f20 	b.eq	8260 <f12+0xf40>  // b.none
    8080:	52800020 	mov	w0, #0x1                   	// #1
    8084:	39000300 	strb	w0, [x24]
    8088:	aa1303e0 	mov	x0, x19
    808c:	17fffe92 	b	7ad4 <f12+0x7b4>
    8090:	eb1a039f 	cmp	x28, x26
    8094:	54ffe468 	b.hi	7d20 <f12+0xa00>  // b.pmore
    8098:	17ffff86 	b	7eb0 <f12+0xb90>
    809c:	52800041 	mov	w1, #0x2                   	// #2
    80a0:	d2800100 	mov	x0, #0x8                   	// #8
    80a4:	97fff2d3 	bl	4bf0 <fwp_heap_alloc>
    80a8:	aa0003fb 	mov	x27, x0
    80ac:	911542a0 	add	x0, x21, #0x550
    80b0:	f900037f 	str	xzr, [x27]
    80b4:	f949d801 	ldr	x1, [x0, #5040]
    80b8:	f949ec00 	ldr	x0, [x0, #5080]
    80bc:	cb010361 	sub	x1, x27, x1
    80c0:	eb00403f 	cmp	x1, x0, lsl #16
    80c4:	54000362 	b.cs	8130 <f12+0xe10>  // b.hs, b.nlast
    80c8:	d2800013 	mov	x19, #0x0                   	// #0
    80cc:	17fffd6e 	b	7684 <f12+0x364>
    80d0:	aa1b03e0 	mov	x0, x27
    80d4:	97fff107 	bl	44f0 <fwp_rc_forget_slot>
    80d8:	17ffff23 	b	7d64 <f12+0xa44>
    80dc:	f100027f 	cmp	x19, #0x0
    80e0:	fa401860 	ccmp	x3, #0x0, #0x0, ne	// ne = any
    80e4:	54ffbec1 	b.ne	78bc <f12+0x59c>  // b.any
    80e8:	f94027e1 	ldr	x1, [sp, #72]
    80ec:	910102f7 	add	x23, x23, #0x40
    80f0:	aa1803e0 	mov	x0, x24
    80f4:	f90162e1 	str	x1, [x23, #704]
    80f8:	97ffefe2 	bl	4080 <fwp_tape_buffers_release>
    80fc:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    8100:	f947e863 	ldr	x3, [x3, #4048]
    8104:	d2800262 	mov	x2, #0x13                  	// #19
    8108:	d2800021 	mov	x1, #0x1                   	// #1
    810c:	b0000020 	adrp	x0, d000 <__modti3+0x1f0>
    8110:	9106e000 	add	x0, x0, #0x1b8
    8114:	f9400063 	ldr	x3, [x3]
    8118:	97ffe9f6 	bl	28f0 <fwrite@plt>
    811c:	d2800000 	mov	x0, #0x0                   	// #0
    8120:	97ffea00 	bl	2920 <fflush@plt>
    8124:	52800cc0 	mov	w0, #0x66                  	// #102
    8128:	97ffea0e 	bl	2960 <_Exit@plt>
    812c:	b5ffae13 	cbnz	x19, 76ec <f12+0x3cc>
    8130:	d280001c 	mov	x28, #0x0                   	// #0
    8134:	17fffd94 	b	7784 <f12+0x464>
    8138:	b0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0xdc>
    813c:	913f4000 	add	x0, x0, #0xfd0
    8140:	94001410 	bl	d180 <atexit>
    8144:	35fffdc0 	cbnz	w0, 80fc <f12+0xddc>
    8148:	52800020 	mov	w0, #0x1                   	// #1
    814c:	b902f680 	str	w0, [x20, #756]
    8150:	17fffcc0 	b	7450 <f12+0x130>
    8154:	72003c3f 	tst	w1, #0xffff
    8158:	54ffac81 	b.ne	76e8 <f12+0x3c8>  // b.any
    815c:	17fffd5e 	b	76d4 <f12+0x3b4>
    8160:	72003c3f 	tst	w1, #0xffff
    8164:	54ff94a0 	b.eq	73f8 <f12+0xd8>  // b.none
    8168:	aa1403e0 	mov	x0, x20
    816c:	97fff6f9 	bl	5d50 <fwp_closure_drop>
    8170:	b5ff9576 	cbnz	x22, 741c <f12+0xfc>
    8174:	d280001c 	mov	x28, #0x0                   	// #0
    8178:	17fffcb3 	b	7444 <f12+0x124>
    817c:	aa1c03f3 	mov	x19, x28
    8180:	17fffdb8 	b	7860 <f12+0x540>
    8184:	72003c3f 	tst	w1, #0xffff
    8188:	54ffc541 	b.ne	7a30 <f12+0x710>  // b.any
    818c:	17fffe24 	b	7a1c <f12+0x6fc>
    8190:	3cc48002 	ldur	q2, [x0, #72]
    8194:	91012001 	add	x1, x0, #0x48
    8198:	3cc58001 	ldur	q1, [x0, #88]
    819c:	f900401f 	str	xzr, [x0, #128]
    81a0:	4f000400 	movi	v0.4s, #0x0
    81a4:	ad010682 	stp	q2, q1, [x20, #32]
    81a8:	a9468002 	ldp	x2, x0, [x0, #104]
    81ac:	f9000e80 	str	x0, [x20, #24]
    81b0:	f9401820 	ldr	x0, [x1, #48]
    81b4:	f9002282 	str	x2, [x20, #64]
    81b8:	f9002680 	str	x0, [x20, #72]
    81bc:	ad000020 	stp	q0, q0, [x1]
    81c0:	3d800820 	str	q0, [x1, #32]
    81c4:	f900183f 	str	xzr, [x1, #48]
    81c8:	17fffcec 	b	7578 <f12+0x258>
    81cc:	52800041 	mov	w1, #0x2                   	// #2
    81d0:	d2800100 	mov	x0, #0x8                   	// #8
    81d4:	97fff287 	bl	4bf0 <fwp_heap_alloc>
    81d8:	aa0003f9 	mov	x25, x0
    81dc:	d2800013 	mov	x19, #0x0                   	// #0
    81e0:	17ffff44 	b	7ef0 <f12+0xbd0>
    81e4:	72003c3f 	tst	w1, #0xffff
    81e8:	54fff460 	b.eq	8074 <f12+0xd54>  // b.none
    81ec:	aa1303e0 	mov	x0, x19
    81f0:	17fffe39 	b	7ad4 <f12+0x7b4>
    81f4:	aa1b03e0 	mov	x0, x27
    81f8:	d2800101 	mov	x1, #0x8                   	// #8
    81fc:	97ffe975 	bl	27d0 <calloc@plt>
    8200:	aa0003e3 	mov	x3, x0
    8204:	a94017e4 	ldp	x4, x5, [sp]
    8208:	a9411fe6 	ldp	x6, x7, [sp, #16]
    820c:	17fffda9 	b	78b0 <f12+0x590>
    8210:	f9400343 	ldr	x3, [x26]
    8214:	b7fffdc3 	tbnz	x3, #63, 81cc <f12+0xeac>
    8218:	911542a1 	add	x1, x21, #0x550
    821c:	f94003e4 	ldr	x4, [sp]
    8220:	f949d820 	ldr	x0, [x1, #5040]
    8224:	f949ec21 	ldr	x1, [x1, #5080]
    8228:	cb000080 	sub	x0, x4, x0
    822c:	eb01401f 	cmp	x0, x1, lsl #16
    8230:	54fffce2 	b.cs	81cc <f12+0xeac>  // b.hs, b.nlast
    8234:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    8238:	17fffe5b 	b	7ba4 <f12+0x884>
    823c:	d2800d01 	mov	x1, #0x68                  	// #104
    8240:	d2800038 	mov	x24, #0x1                   	// #1
    8244:	17fffca6 	b	74dc <f12+0x1bc>
    8248:	aa1403e0 	mov	x0, x20
    824c:	97fff0a9 	bl	44f0 <fwp_rc_forget_slot>
    8250:	17fffdf6 	b	7a28 <f12+0x708>
    8254:	aa1403e0 	mov	x0, x20
    8258:	97fff0a6 	bl	44f0 <fwp_rc_forget_slot>
    825c:	17fffd21 	b	76e0 <f12+0x3c0>
    8260:	aa1803e0 	mov	x0, x24
    8264:	97fff0a3 	bl	44f0 <fwp_rc_forget_slot>
    8268:	17ffff86 	b	8080 <f12+0xd60>
    826c:	97fff05a 	bl	43d4 <fwp_rc_wide_dup>
    8270:	17fffc68 	b	7410 <f12+0xf0>
    8274:	d280001a 	mov	x26, #0x0                   	// #0
    8278:	17fffeaa 	b	7d20 <f12+0xa00>
    827c:	d2800019 	mov	x25, #0x0                   	// #0
    8280:	d2800013 	mov	x19, #0x0                   	// #0
    8284:	17ffff1b 	b	7ef0 <f12+0xbd0>
    8288:	b0000020 	adrp	x0, d000 <__modti3+0x1f0>
    828c:	9114e000 	add	x0, x0, #0x538
    8290:	97ffec9c 	bl	3500 <fwp_trap>
    8294:	b0000020 	adrp	x0, d000 <__modti3+0x1f0>
    8298:	91128000 	add	x0, x0, #0x4a0
    829c:	97ffec99 	bl	3500 <fwp_trap>
    82a0:	b0000020 	adrp	x0, d000 <__modti3+0x1f0>
    82a4:	9118e000 	add	x0, x0, #0x638
    82a8:	97ffec96 	bl	3500 <fwp_trap>
    82ac:	b0000020 	adrp	x0, d000 <__modti3+0x1f0>
    82b0:	91166000 	add	x0, x0, #0x598
    82b4:	97ffec93 	bl	3500 <fwp_trap>
    82b8:	b0000020 	adrp	x0, d000 <__modti3+0x1f0>
    82bc:	9113a000 	add	x0, x0, #0x4e8
    82c0:	97ffec90 	bl	3500 <fwp_trap>
    82c4:	b0000020 	adrp	x0, d000 <__modti3+0x1f0>
    82c8:	9117e000 	add	x0, x0, #0x5f8
    82cc:	97ffec8d 	bl	3500 <fwp_trap>
    82d0:	b0000020 	adrp	x0, d000 <__modti3+0x1f0>
    82d4:	9116a000 	add	x0, x0, #0x5a8
    82d8:	97ffec8a 	bl	3500 <fwp_trap>
    82dc:	97ffe945 	bl	27f0 <__stack_chk_fail@plt>
    82e0:	b0000020 	adrp	x0, d000 <__modti3+0x1f0>
    82e4:	91172000 	add	x0, x0, #0x5c8
    82e8:	97ffec86 	bl	3500 <fwp_trap>
    82ec:	b0000020 	adrp	x0, d000 <__modti3+0x1f0>
    82f0:	9118a000 	add	x0, x0, #0x628
    82f4:	97ffec83 	bl	3500 <fwp_trap>
    82f8:	97ffe9c2 	bl	2a00 <fwp_trap_overflow.constprop.0>
    82fc:	97ffe951 	bl	2840 <abort@plt>

0000000000008300 <fwp_owned_entry12>:
    8300:	f9400000 	ldr	x0, [x0]
    8304:	17fffc07 	b	7320 <f12>
    8308:	d503201f 	nop
    830c:	d503201f 	nop

0000000000008310 <e12>:
    8310:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8314:	910003fd 	mov	x29, sp
    8318:	f9000bf3 	str	x19, [sp, #16]
    831c:	f9400013 	ldr	x19, [x0]
    8320:	aa1303e0 	mov	x0, x19
    8324:	97fff4b0 	bl	55e4 <fwp_rc_share>
    8328:	aa1303e0 	mov	x0, x19
    832c:	97fffbfd 	bl	7320 <f12>
    8330:	aa0003f3 	mov	x19, x0
    8334:	97fff4ac 	bl	55e4 <fwp_rc_share>
    8338:	aa1303e0 	mov	x0, x19
    833c:	f9400bf3 	ldr	x19, [sp, #16]
    8340:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8344:	d65f03c0 	ret
    8348:	d503201f 	nop
    834c:	d503201f 	nop

0000000000008350 <fwp_write>:
    8350:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8354:	910003fd 	mov	x29, sp
    8358:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    835c:	f947f484 	ldr	x4, [x4, #4072]
    8360:	a90153f3 	stp	x19, x20, [sp, #16]
    8364:	d10943ff 	sub	sp, sp, #0x250
    8368:	b9400045 	ldr	w5, [x2]
    836c:	aa0003f4 	mov	x20, x0
    8370:	f9400080 	ldr	x0, [x4]
    8374:	f90127e0 	str	x0, [sp, #584]
    8378:	d2800000 	mov	x0, #0x0                   	// #0
    837c:	710064bf 	cmp	w5, #0x19
    8380:	54000408 	b.hi	8400 <fwp_write+0xb0>  // b.pmore
    8384:	b0000020 	adrp	x0, d000 <__modti3+0x1f0>
    8388:	aa0103f3 	mov	x19, x1
    838c:	91378000 	add	x0, x0, #0xde0
    8390:	f9013bf5 	str	x21, [sp, #624]
    8394:	f9013ff6 	str	x22, [sp, #632]
    8398:	f90153fb 	str	x27, [sp, #672]
    839c:	f90157fc 	str	x28, [sp, #680]
    83a0:	aa0203fc 	mov	x28, x2
    83a4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    83a8:	10000061 	adr	x1, 83b4 <fwp_write+0x64>
    83ac:	8b20a820 	add	x0, x1, w0, sxth #2
    83b0:	d61f0000 	br	x0
    83b4:	910123e0 	add	x0, sp, #0x48
    83b8:	aa1303e5 	mov	x5, x19
    83bc:	b0000024 	adrp	x4, d000 <__modti3+0x1f0>
    83c0:	aa0003f3 	mov	x19, x0
    83c4:	911a6084 	add	x4, x4, #0x698
    83c8:	d2804003 	mov	x3, #0x200                 	// #512
    83cc:	aa0303e1 	mov	x1, x3
    83d0:	52800042 	mov	w2, #0x2                   	// #2
    83d4:	97ffe8e3 	bl	2760 <__snprintf_chk@plt>
    83d8:	aa1303e0 	mov	x0, x19
    83dc:	97ffe8a9 	bl	2680 <strlen@plt>
    83e0:	aa1303e1 	mov	x1, x19
    83e4:	aa0003e2 	mov	x2, x0
    83e8:	aa1403e0 	mov	x0, x20
    83ec:	97ffebe9 	bl	3390 <buf_put>
    83f0:	f9413bf5 	ldr	x21, [sp, #624]
    83f4:	f9413ff6 	ldr	x22, [sp, #632]
    83f8:	f94153fb 	ldr	x27, [sp, #672]
    83fc:	f94157fc 	ldr	x28, [sp, #680]
    8400:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8404:	f947f400 	ldr	x0, [x0, #4072]
    8408:	f94127e2 	ldr	x2, [sp, #584]
    840c:	f9400001 	ldr	x1, [x0]
    8410:	eb010042 	subs	x2, x2, x1
    8414:	d2800001 	mov	x1, #0x0                   	// #0
    8418:	540077c1 	b.ne	9310 <fwp_write+0xfc0>  // b.any
    841c:	910943ff 	add	sp, sp, #0x250
    8420:	a94153f3 	ldp	x19, x20, [sp, #16]
    8424:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8428:	d65f03c0 	ret
    842c:	910123e0 	add	x0, sp, #0x48
    8430:	aa1303e5 	mov	x5, x19
    8434:	b0000024 	adrp	x4, d000 <__modti3+0x1f0>
    8438:	aa0003f3 	mov	x19, x0
    843c:	911a4084 	add	x4, x4, #0x690
    8440:	d2804003 	mov	x3, #0x200                 	// #512
    8444:	17ffffe2 	b	83cc <fwp_write+0x7c>
    8448:	71004cbf 	cmp	w5, #0x13
    844c:	b0000020 	adrp	x0, d000 <__modti3+0x1f0>
    8450:	b0000021 	adrp	x1, d000 <__modti3+0x1f0>
    8454:	911a0000 	add	x0, x0, #0x680
    8458:	911a2021 	add	x1, x1, #0x688
    845c:	d2800082 	mov	x2, #0x4                   	// #4
    8460:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8464:	aa1403e0 	mov	x0, x20
    8468:	f90143f7 	str	x23, [sp, #640]
    846c:	d2800016 	mov	x22, #0x0                   	// #0
    8470:	f90147f8 	str	x24, [sp, #648]
    8474:	97ffebc7 	bl	3390 <buf_put>
    8478:	f9400260 	ldr	x0, [x19]
    847c:	b0000037 	adrp	x23, d000 <__modti3+0x1f0>
    8480:	d2800015 	mov	x21, #0x0                   	// #0
    8484:	911c22f7 	add	x23, x23, #0x708
    8488:	b40047a0 	cbz	x0, 8d7c <fwp_write+0xa2c>
    848c:	b9400380 	ldr	w0, [x28]
    8490:	52800003 	mov	w3, #0x0                   	// #0
    8494:	f9401f82 	ldr	x2, [x28, #56]
    8498:	71004c1f 	cmp	w0, #0x13
    849c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    84a0:	aa1403e0 	mov	x0, x20
    84a4:	8b010e61 	add	x1, x19, x1, lsl #3
    84a8:	f9400421 	ldr	x1, [x1, #8]
    84ac:	97ffffa9 	bl	8350 <fwp_write>
    84b0:	b9400380 	ldr	w0, [x28]
    84b4:	7100481f 	cmp	w0, #0x12
    84b8:	54004b40 	b.eq	8e20 <fwp_write+0xad0>  // b.none
    84bc:	f9400260 	ldr	x0, [x19]
    84c0:	910006b5 	add	x21, x21, #0x1
    84c4:	91000ad6 	add	x22, x22, #0x2
    84c8:	eb15001f 	cmp	x0, x21
    84cc:	54004589 	b.ls	8d7c <fwp_write+0xa2c>  // b.plast
    84d0:	aa1703e1 	mov	x1, x23
    84d4:	aa1403e0 	mov	x0, x20
    84d8:	d2800042 	mov	x2, #0x2                   	// #2
    84dc:	97ffebad 	bl	3390 <buf_put>
    84e0:	17ffffeb 	b	848c <fwp_write+0x13c>
    84e4:	b0000021 	adrp	x1, d000 <__modti3+0x1f0>
    84e8:	911b0021 	add	x1, x1, #0x6c0
    84ec:	d28000c2 	mov	x2, #0x6                   	// #6
    84f0:	aa1403e0 	mov	x0, x20
    84f4:	91004273 	add	x19, x19, #0x10
    84f8:	97ffeba6 	bl	3390 <buf_put>
    84fc:	aa1303e0 	mov	x0, x19
    8500:	97ffe860 	bl	2680 <strlen@plt>
    8504:	aa1303e1 	mov	x1, x19
    8508:	aa0003e2 	mov	x2, x0
    850c:	aa1403e0 	mov	x0, x20
    8510:	97ffeba0 	bl	3390 <buf_put>
    8514:	528007c3 	mov	w3, #0x3e                  	// #62
    8518:	aa1403e0 	mov	x0, x20
    851c:	91001fe1 	add	x1, sp, #0x7
    8520:	d2800022 	mov	x2, #0x1                   	// #1
    8524:	39001fe3 	strb	w3, [sp, #7]
    8528:	17ffffb1 	b	83ec <fwp_write+0x9c>
    852c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8530:	f947f400 	ldr	x0, [x0, #4072]
    8534:	f94127e2 	ldr	x2, [sp, #584]
    8538:	f9400001 	ldr	x1, [x0]
    853c:	eb010042 	subs	x2, x2, x1
    8540:	d2800001 	mov	x1, #0x0                   	// #0
    8544:	540034e1 	b.ne	8be0 <fwp_write+0x890>  // b.any
    8548:	f9413bf5 	ldr	x21, [sp, #624]
    854c:	b0000021 	adrp	x1, d000 <__modti3+0x1f0>
    8550:	f9413ff6 	ldr	x22, [sp, #632]
    8554:	aa1403e0 	mov	x0, x20
    8558:	911a8021 	add	x1, x1, #0x6a0
    855c:	d2800142 	mov	x2, #0xa                   	// #10
    8560:	f94153fb 	ldr	x27, [sp, #672]
    8564:	f94157fc 	ldr	x28, [sp, #680]
    8568:	910943ff 	add	sp, sp, #0x250
    856c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8570:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8574:	17ffeb87 	b	3390 <buf_put>
    8578:	f9400456 	ldr	x22, [x2, #8]
    857c:	f90143f7 	str	x23, [sp, #640]
    8580:	f90147f8 	str	x24, [sp, #648]
    8584:	b4005b16 	cbz	x22, 90e4 <fwp_write+0xd94>
    8588:	aa1603e0 	mov	x0, x22
    858c:	b0000021 	adrp	x1, d000 <__modti3+0x1f0>
    8590:	911c8021 	add	x1, x1, #0x720
    8594:	97ffe8b7 	bl	2870 <strcmp@plt>
    8598:	2a0003f5 	mov	w21, w0
    859c:	34005fe0 	cbz	w0, 9198 <fwp_write+0xe48>
    85a0:	aa1603e0 	mov	x0, x22
    85a4:	97ffe837 	bl	2680 <strlen@plt>
    85a8:	aa1603e1 	mov	x1, x22
    85ac:	aa0003e2 	mov	x2, x0
    85b0:	aa1403e0 	mov	x0, x20
    85b4:	97ffeb77 	bl	3390 <buf_put>
    85b8:	52800403 	mov	w3, #0x20                  	// #32
    85bc:	91001ff5 	add	x21, sp, #0x7
    85c0:	aa1503e1 	mov	x1, x21
    85c4:	aa1403e0 	mov	x0, x20
    85c8:	d2800022 	mov	x2, #0x1                   	// #1
    85cc:	39001fe3 	strb	w3, [sp, #7]
    85d0:	97ffeb70 	bl	3390 <buf_put>
    85d4:	52800f63 	mov	w3, #0x7b                  	// #123
    85d8:	aa1403e0 	mov	x0, x20
    85dc:	aa1503e1 	mov	x1, x21
    85e0:	d2800022 	mov	x2, #0x1                   	// #1
    85e4:	39001fe3 	strb	w3, [sp, #7]
    85e8:	97ffeb6a 	bl	3390 <buf_put>
    85ec:	b9401380 	ldr	w0, [x28, #16]
    85f0:	52800018 	mov	w24, #0x0                   	// #0
    85f4:	7100001f 	cmp	w0, #0x0
    85f8:	54003aad 	b.le	8d4c <fwp_write+0x9fc>
    85fc:	f9014bf9 	str	x25, [sp, #656]
    8600:	b0000039 	adrp	x25, d000 <__modti3+0x1f0>
    8604:	911d2339 	add	x25, x25, #0x748
    8608:	f9014ffa 	str	x26, [sp, #664]
    860c:	b000003a 	adrp	x26, d000 <__modti3+0x1f0>
    8610:	911c235a 	add	x26, x26, #0x708
    8614:	91002276 	add	x22, x19, #0x8
    8618:	d2800013 	mov	x19, #0x0                   	// #0
    861c:	b5003e93 	cbnz	x19, 8dec <fwp_write+0xa9c>
    8620:	d37df277 	lsl	x23, x19, #3
    8624:	34003cb8 	cbz	w24, 8db8 <fwp_write+0xa68>
    8628:	f9401382 	ldr	x2, [x28, #32]
    862c:	aa1403e0 	mov	x0, x20
    8630:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8634:	52800003 	mov	w3, #0x0                   	// #0
    8638:	f8776842 	ldr	x2, [x2, x23]
    863c:	91000673 	add	x19, x19, #0x1
    8640:	97ffff44 	bl	8350 <fwp_write>
    8644:	b9401380 	ldr	w0, [x28, #16]
    8648:	6b13001f 	cmp	w0, w19
    864c:	54fffe8c 	b.gt	861c <fwp_write+0x2cc>
    8650:	f9414bf9 	ldr	x25, [sp, #656]
    8654:	f9414ffa 	ldr	x26, [sp, #664]
    8658:	340037b8 	cbz	w24, 8d4c <fwp_write+0x9fc>
    865c:	52800523 	mov	w3, #0x29                  	// #41
    8660:	aa1503e1 	mov	x1, x21
    8664:	aa1403e0 	mov	x0, x20
    8668:	d2800022 	mov	x2, #0x1                   	// #1
    866c:	39001fe3 	strb	w3, [sp, #7]
    8670:	97ffeb48 	bl	3390 <buf_put>
    8674:	f9413bf5 	ldr	x21, [sp, #624]
    8678:	f9413ff6 	ldr	x22, [sp, #632]
    867c:	f94143f7 	ldr	x23, [sp, #640]
    8680:	f94147f8 	ldr	x24, [sp, #648]
    8684:	f94153fb 	ldr	x27, [sp, #672]
    8688:	f94157fc 	ldr	x28, [sp, #680]
    868c:	17ffff5d 	b	8400 <fwp_write+0xb0>
    8690:	b9404855 	ldr	w21, [x2, #72]
    8694:	aa1403e0 	mov	x0, x20
    8698:	93407eb6 	sxtw	x22, w21
    869c:	91000ac1 	add	x1, x22, #0x2
    86a0:	97ffeb09 	bl	32c4 <buf_grow>
    86a4:	a9400281 	ldp	x1, x0, [x20]
    86a8:	528e8603 	mov	w3, #0x7430                	// #29744
    86ac:	78206823 	strh	w3, [x1, x0]
    86b0:	8b000022 	add	x2, x1, x0
    86b4:	710002bf 	cmp	w21, #0x0
    86b8:	540036cd 	b.le	8d90 <fwp_write+0xa40>
    86bc:	110006a3 	add	w3, w21, #0x1
    86c0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    86c4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    86c8:	91000449 	add	x9, x2, #0x1
    86cc:	8b23c043 	add	x3, x2, w3, sxtw
    86d0:	f28aaac6 	movk	x6, #0x5556
    86d4:	f2955568 	movk	x8, #0xaaab
    86d8:	1400000d 	b	870c <fwp_write+0x3bc>
    86dc:	d2800021 	mov	x1, #0x1                   	// #1
    86e0:	528005a5 	mov	w5, #0x2d                  	// #45
    86e4:	f100001f 	cmp	x0, #0x0
    86e8:	9b467e60 	smulh	x0, x19, x6
    86ec:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    86f0:	381ff465 	strb	w5, [x3], #-1
    86f4:	cb040000 	sub	x0, x0, x4
    86f8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    86fc:	cb020000 	sub	x0, x0, x2
    8700:	8b010013 	add	x19, x0, x1
    8704:	eb03013f 	cmp	x9, x3
    8708:	54003440 	b.eq	8d90 <fwp_write+0xa40>  // b.none
    870c:	9b467e60 	smulh	x0, x19, x6
    8710:	937ffe64 	asr	x4, x19, #63
    8714:	52800605 	mov	w5, #0x30                  	// #48
    8718:	cb040000 	sub	x0, x0, x4
    871c:	8b000400 	add	x0, x0, x0, lsl #1
    8720:	cb000260 	sub	x0, x19, x0
    8724:	91000c01 	add	x1, x0, #0x3
    8728:	9bc87c22 	umulh	x2, x1, x8
    872c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8730:	8b4204e2 	add	x2, x7, x2, lsr #1
    8734:	eb020021 	subs	x1, x1, x2
    8738:	54fffd60 	b.eq	86e4 <fwp_write+0x394>  // b.none
    873c:	f100043f 	cmp	x1, #0x1
    8740:	54fffce1 	b.ne	86dc <fwp_write+0x38c>  // b.any
    8744:	d2800001 	mov	x1, #0x0                   	// #0
    8748:	52800565 	mov	w5, #0x2b                  	// #43
    874c:	17ffffe6 	b	86e4 <fwp_write+0x394>
    8750:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8754:	f947f400 	ldr	x0, [x0, #4072]
    8758:	f94127e2 	ldr	x2, [sp, #584]
    875c:	f9400001 	ldr	x1, [x0]
    8760:	eb010042 	subs	x2, x2, x1
    8764:	d2800001 	mov	x1, #0x0                   	// #0
    8768:	540023c1 	b.ne	8be0 <fwp_write+0x890>  // b.any
    876c:	f9413bf5 	ldr	x21, [sp, #624]
    8770:	b0000021 	adrp	x1, d000 <__modti3+0x1f0>
    8774:	f9413ff6 	ldr	x22, [sp, #632]
    8778:	aa1403e0 	mov	x0, x20
    877c:	911ac021 	add	x1, x1, #0x6b0
    8780:	d2800102 	mov	x2, #0x8                   	// #8
    8784:	17ffff77 	b	8560 <fwp_write+0x210>
    8788:	aa1403e0 	mov	x0, x20
    878c:	b0000021 	adrp	x1, d000 <__modti3+0x1f0>
    8790:	d28000c2 	mov	x2, #0x6                   	// #6
    8794:	911c4021 	add	x1, x1, #0x710
    8798:	97ffeafe 	bl	3390 <buf_put>
    879c:	d2800015 	mov	x21, #0x0                   	// #0
    87a0:	f9400263 	ldr	x3, [x19]
    87a4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    87a8:	54002c60 	b.eq	8d34 <fwp_write+0x9e4>  // b.none
    87ac:	f9401f82 	ldr	x2, [x28, #56]
    87b0:	f90143f7 	str	x23, [sp, #640]
    87b4:	f90147f8 	str	x24, [sp, #648]
    87b8:	d2800857 	mov	x23, #0x42                  	// #66
    87bc:	f9014bf9 	str	x25, [sp, #656]
    87c0:	b0000036 	adrp	x22, d000 <__modti3+0x1f0>
    87c4:	f9014ffa 	str	x26, [sp, #664]
    87c8:	911c22d6 	add	x22, x22, #0x708
    87cc:	d2800038 	mov	x24, #0x1                   	// #1
    87d0:	f2a18017 	movk	x23, #0xc00, lsl #16
    87d4:	d2809099 	mov	x25, #0x484                 	// #1156
    87d8:	b40004a2 	cbz	x2, 886c <fwp_write+0x51c>
    87dc:	b9400040 	ldr	w0, [x2]
    87e0:	7100701f 	cmp	w0, #0x1c
    87e4:	540042c0 	b.eq	903c <fwp_write+0xcec>  // b.none
    87e8:	71006c1f 	cmp	w0, #0x1b
    87ec:	54000408 	b.hi	886c <fwp_write+0x51c>  // b.pmore
    87f0:	9ac02301 	lsl	x1, x24, x0
    87f4:	ea17003f 	tst	x1, x23
    87f8:	540036a1 	b.ne	8ecc <fwp_write+0xb7c>  // b.any
    87fc:	ea19003f 	tst	x1, x25
    8800:	54003521 	b.ne	8ea4 <fwp_write+0xb54>  // b.any
    8804:	d2800424 	mov	x4, #0x21                  	// #33
    8808:	ea04003f 	tst	x1, x4
    880c:	54000300 	b.eq	886c <fwp_write+0x51c>  // b.none
    8810:	b7f849c3 	tbnz	x3, #63, 9148 <fwp_write+0xdf8>
    8814:	91002261 	add	x1, x19, #0x8
    8818:	8b150021 	add	x1, x1, x21
    881c:	39400021 	ldrb	w1, [x1]
    8820:	7100001f 	cmp	w0, #0x0
    8824:	93401c23 	sxtb	x3, w1
    8828:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    882c:	d503201f 	nop
    8830:	aa1403e0 	mov	x0, x20
    8834:	52800003 	mov	w3, #0x0                   	// #0
    8838:	97fffec6 	bl	8350 <fwp_write>
    883c:	910006b5 	add	x21, x21, #0x1
    8840:	f9400260 	ldr	x0, [x19]
    8844:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8848:	eb0002bf 	cmp	x21, x0
    884c:	540026c2 	b.cs	8d24 <fwp_write+0x9d4>  // b.hs, b.nlast
    8850:	d2800042 	mov	x2, #0x2                   	// #2
    8854:	aa1603e1 	mov	x1, x22
    8858:	aa1403e0 	mov	x0, x20
    885c:	97ffeacd 	bl	3390 <buf_put>
    8860:	f9401f82 	ldr	x2, [x28, #56]
    8864:	f9400263 	ldr	x3, [x19]
    8868:	b5fffba2 	cbnz	x2, 87dc <fwp_write+0x48c>
    886c:	d37df2a0 	lsl	x0, x21, #3
    8870:	b7f83f03 	tbnz	x3, #63, 9050 <fwp_write+0xd00>
    8874:	91002261 	add	x1, x19, #0x8
    8878:	8b000020 	add	x0, x1, x0
    887c:	f9400001 	ldr	x1, [x0]
    8880:	17ffffec 	b	8830 <fwp_write+0x4e0>
    8884:	a9400e62 	ldp	x2, x3, [x19]
    8888:	b7f83ca3 	tbnz	x3, #63, 901c <fwp_write+0xccc>
    888c:	910123f5 	add	x21, sp, #0x48
    8890:	aa1503e0 	mov	x0, x21
    8894:	97ffe943 	bl	2da0 <fwp_fmt_u128>
    8898:	aa1503e0 	mov	x0, x21
    889c:	97ffe779 	bl	2680 <strlen@plt>
    88a0:	aa1503e1 	mov	x1, x21
    88a4:	aa0003e2 	mov	x2, x0
    88a8:	17fffed0 	b	83e8 <fwp_write+0x98>
    88ac:	fd015be8 	str	d8, [sp, #688]
    88b0:	1e270268 	fmov	s8, w19
    88b4:	fd015fe9 	str	d9, [sp, #696]
    88b8:	1e282100 	fcmp	s8, s8
    88bc:	54004d26 	b.vs	9260 <fwp_write+0xf10>
    88c0:	1e20c101 	fabs	s1, s8
    88c4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    88c8:	1e270000 	fmov	s0, w0
    88cc:	1e202020 	fcmp	s1, s0
    88d0:	54002c0d 	b.le	8e50 <fwp_write+0xb00>
    88d4:	1e202118 	fcmpe	s8, #0.0
    88d8:	b0000022 	adrp	x2, d000 <__modti3+0x1f0>
    88dc:	91074042 	add	x2, x2, #0x1d0
    88e0:	910123f5 	add	x21, sp, #0x48
    88e4:	b0000021 	adrp	x1, d000 <__modti3+0x1f0>
    88e8:	91198021 	add	x1, x1, #0x660
    88ec:	aa1503e0 	mov	x0, x21
    88f0:	9a81c041 	csel	x1, x2, x1, gt
    88f4:	97ffe80f 	bl	2930 <strcpy@plt>
    88f8:	aa1503e0 	mov	x0, x21
    88fc:	97ffe761 	bl	2680 <strlen@plt>
    8900:	aa1503e1 	mov	x1, x21
    8904:	aa0003e2 	mov	x2, x0
    8908:	aa1403e0 	mov	x0, x20
    890c:	97ffeaa1 	bl	3390 <buf_put>
    8910:	f9413bf5 	ldr	x21, [sp, #624]
    8914:	f9413ff6 	ldr	x22, [sp, #632]
    8918:	f94153fb 	ldr	x27, [sp, #672]
    891c:	f94157fc 	ldr	x28, [sp, #680]
    8920:	fd415be8 	ldr	d8, [sp, #688]
    8924:	fd415fe9 	ldr	d9, [sp, #696]
    8928:	17fffeb6 	b	8400 <fwp_write+0xb0>
    892c:	f9400276 	ldr	x22, [x19]
    8930:	34002e03 	cbz	w3, 8ef0 <fwp_write+0xba0>
    8934:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8938:	f947f400 	ldr	x0, [x0, #4072]
    893c:	f94127e2 	ldr	x2, [sp, #584]
    8940:	f9400001 	ldr	x1, [x0]
    8944:	eb010042 	subs	x2, x2, x1
    8948:	d2800001 	mov	x1, #0x0                   	// #0
    894c:	540014a1 	b.ne	8be0 <fwp_write+0x890>  // b.any
    8950:	aa1603e2 	mov	x2, x22
    8954:	91002261 	add	x1, x19, #0x8
    8958:	f9413bf5 	ldr	x21, [sp, #624]
    895c:	aa1403e0 	mov	x0, x20
    8960:	f9413ff6 	ldr	x22, [sp, #632]
    8964:	17fffeff 	b	8560 <fwp_write+0x210>
    8968:	fd015be8 	str	d8, [sp, #688]
    896c:	9e670268 	fmov	d8, x19
    8970:	fd015fe9 	str	d9, [sp, #696]
    8974:	1e682100 	fcmp	d8, d8
    8978:	54004746 	b.vs	9260 <fwp_write+0xf10>
    897c:	1e60c101 	fabs	d1, d8
    8980:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8984:	9e670000 	fmov	d0, x0
    8988:	910123f5 	add	x21, sp, #0x48
    898c:	52800033 	mov	w19, #0x1                   	// #1
    8990:	1e602020 	fcmp	d1, d0
    8994:	540001ad 	b.le	89c8 <fwp_write+0x678>
    8998:	1e602118 	fcmpe	d8, #0.0
    899c:	b0000022 	adrp	x2, d000 <__modti3+0x1f0>
    89a0:	91074042 	add	x2, x2, #0x1d0
    89a4:	b0000021 	adrp	x1, d000 <__modti3+0x1f0>
    89a8:	91198021 	add	x1, x1, #0x660
    89ac:	aa1503e0 	mov	x0, x21
    89b0:	9a81c041 	csel	x1, x2, x1, gt
    89b4:	97ffe7df 	bl	2930 <strcpy@plt>
    89b8:	17ffffd0 	b	88f8 <fwp_write+0x5a8>
    89bc:	11000673 	add	w19, w19, #0x1
    89c0:	71004a7f 	cmp	w19, #0x12
    89c4:	54003860 	b.eq	90d0 <fwp_write+0xd80>  // b.none
    89c8:	1e604100 	fmov	d0, d8
    89cc:	2a1303e1 	mov	w1, w19
    89d0:	aa1503e0 	mov	x0, x21
    89d4:	97ffebb0 	bl	3894 <fwp_format_g.constprop.0>
    89d8:	aa1503e0 	mov	x0, x21
    89dc:	d2800001 	mov	x1, #0x0                   	// #0
    89e0:	97ffe73c 	bl	26d0 <strtod@plt>
    89e4:	1e602100 	fcmp	d8, d0
    89e8:	54fffea1 	b.ne	89bc <fwp_write+0x66c>  // b.any
    89ec:	aa1503e0 	mov	x0, x21
    89f0:	97ffeaa1 	bl	3474 <fwp_finish_float>
    89f4:	17ffffc1 	b	88f8 <fwp_write+0x5a8>
    89f8:	a9400e62 	ldp	x2, x3, [x19]
    89fc:	910123f3 	add	x19, sp, #0x48
    8a00:	aa1303e0 	mov	x0, x19
    8a04:	97ffe8e7 	bl	2da0 <fwp_fmt_u128>
    8a08:	17fffe74 	b	83d8 <fwp_write+0x88>
    8a0c:	f90143f7 	str	x23, [sp, #640]
    8a10:	f90147f8 	str	x24, [sp, #648]
    8a14:	2a1303f8 	mov	w24, w19
    8a18:	f9014bf9 	str	x25, [sp, #656]
    8a1c:	f9014ffa 	str	x26, [sp, #664]
    8a20:	f13ffe7f 	cmp	x19, #0xfff
    8a24:	54000049 	b.ls	8a2c <fwp_write+0x6dc>  // b.plast
    8a28:	b9400278 	ldr	w24, [x19]
    8a2c:	f9400f80 	ldr	x0, [x28, #24]
    8a30:	2a1803f5 	mov	w21, w24
    8a34:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8a38:	d37ef6b9 	lsl	x25, x21, #2
    8a3c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8a40:	aa1603e0 	mov	x0, x22
    8a44:	97ffe70f 	bl	2680 <strlen@plt>
    8a48:	aa1603e1 	mov	x1, x22
    8a4c:	aa0003e2 	mov	x2, x0
    8a50:	aa1403e0 	mov	x0, x20
    8a54:	97ffea4f 	bl	3390 <buf_put>
    8a58:	f9401780 	ldr	x0, [x28, #40]
    8a5c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8a60:	7100001f 	cmp	w0, #0x0
    8a64:	5400068d 	b.le	8b34 <fwp_write+0x7e4>
    8a68:	91002276 	add	x22, x19, #0x8
    8a6c:	91001ff5 	add	x21, sp, #0x7
    8a70:	d280001b 	mov	x27, #0x0                   	// #0
    8a74:	5280041a 	mov	w26, #0x20                  	// #32
    8a78:	f9401b80 	ldr	x0, [x28, #48]
    8a7c:	aa1503e1 	mov	x1, x21
    8a80:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8a84:	d2800022 	mov	x2, #0x1                   	// #1
    8a88:	f8786803 	ldr	x3, [x0, x24]
    8a8c:	aa1403e0 	mov	x0, x20
    8a90:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8a94:	39001ffa 	strb	w26, [sp, #7]
    8a98:	97ffea3e 	bl	3390 <buf_put>
    8a9c:	f13ffeff 	cmp	x23, #0xfff
    8aa0:	b9400261 	ldr	w1, [x19]
    8aa4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8aa8:	7100383f 	cmp	w1, #0xe
    8aac:	54000160 	b.eq	8ad8 <fwp_write+0x788>  // b.none
    8ab0:	7100403f 	cmp	w1, #0x10
    8ab4:	54001a60 	b.eq	8e00 <fwp_write+0xab0>  // b.none
    8ab8:	7100283f 	cmp	w1, #0xa
    8abc:	54002aa0 	b.eq	9010 <fwp_write+0xcc0>  // b.none
    8ac0:	540014ac 	b.gt	8d54 <fwp_write+0xa04>
    8ac4:	71000c3f 	cmp	w1, #0x3
    8ac8:	540029ac 	b.gt	8ffc <fwp_write+0xcac>
    8acc:	d37ffee0 	lsr	x0, x23, #63
    8ad0:	37f814a1 	tbnz	w1, #31, 8d64 <fwp_write+0xa14>
    8ad4:	d503201f 	nop
    8ad8:	34001460 	cbz	w0, 8d64 <fwp_write+0xa14>
    8adc:	52800503 	mov	w3, #0x28                  	// #40
    8ae0:	aa1503e1 	mov	x1, x21
    8ae4:	aa1403e0 	mov	x0, x20
    8ae8:	d2800022 	mov	x2, #0x1                   	// #1
    8aec:	39001fe3 	strb	w3, [sp, #7]
    8af0:	97ffea28 	bl	3390 <buf_put>
    8af4:	aa1303e2 	mov	x2, x19
    8af8:	aa1703e1 	mov	x1, x23
    8afc:	aa1403e0 	mov	x0, x20
    8b00:	52800003 	mov	w3, #0x0                   	// #0
    8b04:	97fffe13 	bl	8350 <fwp_write>
    8b08:	52800523 	mov	w3, #0x29                  	// #41
    8b0c:	aa1503e1 	mov	x1, x21
    8b10:	aa1403e0 	mov	x0, x20
    8b14:	d2800022 	mov	x2, #0x1                   	// #1
    8b18:	39001fe3 	strb	w3, [sp, #7]
    8b1c:	97ffea1d 	bl	3390 <buf_put>
    8b20:	f9401780 	ldr	x0, [x28, #40]
    8b24:	9100077b 	add	x27, x27, #0x1
    8b28:	b8796800 	ldr	w0, [x0, x25]
    8b2c:	6b1b001f 	cmp	w0, w27
    8b30:	54fffa4c 	b.gt	8a78 <fwp_write+0x728>
    8b34:	f9413bf5 	ldr	x21, [sp, #624]
    8b38:	f9413ff6 	ldr	x22, [sp, #632]
    8b3c:	f94143f7 	ldr	x23, [sp, #640]
    8b40:	f94147f8 	ldr	x24, [sp, #648]
    8b44:	f9414bf9 	ldr	x25, [sp, #656]
    8b48:	f9414ffa 	ldr	x26, [sp, #664]
    8b4c:	f94153fb 	ldr	x27, [sp, #672]
    8b50:	f94157fc 	ldr	x28, [sp, #680]
    8b54:	17fffe2b 	b	8400 <fwp_write+0xb0>
    8b58:	52800783 	mov	w3, #0x3c                  	// #60
    8b5c:	91001ff3 	add	x19, sp, #0x7
    8b60:	aa1303e1 	mov	x1, x19
    8b64:	d2800022 	mov	x2, #0x1                   	// #1
    8b68:	aa1403e0 	mov	x0, x20
    8b6c:	39001fe3 	strb	w3, [sp, #7]
    8b70:	97ffea08 	bl	3390 <buf_put>
    8b74:	f9400795 	ldr	x21, [x28, #8]
    8b78:	aa1503e0 	mov	x0, x21
    8b7c:	97ffe6c1 	bl	2680 <strlen@plt>
    8b80:	aa1503e1 	mov	x1, x21
    8b84:	aa0003e2 	mov	x2, x0
    8b88:	aa1403e0 	mov	x0, x20
    8b8c:	97ffea01 	bl	3390 <buf_put>
    8b90:	528007c3 	mov	w3, #0x3e                  	// #62
    8b94:	aa1303e1 	mov	x1, x19
    8b98:	aa1403e0 	mov	x0, x20
    8b9c:	d2800022 	mov	x2, #0x1                   	// #1
    8ba0:	39001fe3 	strb	w3, [sp, #7]
    8ba4:	17fffe12 	b	83ec <fwp_write+0x9c>
    8ba8:	f100067f 	cmp	x19, #0x1
    8bac:	540025a0 	b.eq	9060 <fwp_write+0xd10>  // b.none
    8bb0:	b100067f 	cmn	x19, #0x1
    8bb4:	54002bc0 	b.eq	912c <fwp_write+0xddc>  // b.none
    8bb8:	b0000021 	adrp	x1, d000 <__modti3+0x1f0>
    8bbc:	9119a021 	add	x1, x1, #0x668
    8bc0:	d2800022 	mov	x2, #0x1                   	// #1
    8bc4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8bc8:	f947f400 	ldr	x0, [x0, #4072]
    8bcc:	f94127e4 	ldr	x4, [sp, #584]
    8bd0:	f9400003 	ldr	x3, [x0]
    8bd4:	eb030084 	subs	x4, x4, x3
    8bd8:	d2800003 	mov	x3, #0x0                   	// #0
    8bdc:	54ffebe0 	b.eq	8958 <fwp_write+0x608>  // b.none
    8be0:	f90143f7 	str	x23, [sp, #640]
    8be4:	f90147f8 	str	x24, [sp, #648]
    8be8:	f9014bf9 	str	x25, [sp, #656]
    8bec:	f9014ffa 	str	x26, [sp, #664]
    8bf0:	fd015be8 	str	d8, [sp, #688]
    8bf4:	fd015fe9 	str	d9, [sp, #696]
    8bf8:	97ffe6fe 	bl	27f0 <__stack_chk_fail@plt>
    8bfc:	52800b63 	mov	w3, #0x5b                  	// #91
    8c00:	91001ff5 	add	x21, sp, #0x7
    8c04:	aa1503e1 	mov	x1, x21
    8c08:	aa1403e0 	mov	x0, x20
    8c0c:	d2800022 	mov	x2, #0x1                   	// #1
    8c10:	b0000036 	adrp	x22, d000 <__modti3+0x1f0>
    8c14:	911c22d6 	add	x22, x22, #0x708
    8c18:	39001fe3 	strb	w3, [sp, #7]
    8c1c:	97ffe9dd 	bl	3390 <buf_put>
    8c20:	b4000273 	cbz	x19, 8c6c <fwp_write+0x91c>
    8c24:	f9400661 	ldr	x1, [x19, #8]
    8c28:	aa1403e0 	mov	x0, x20
    8c2c:	f9401f82 	ldr	x2, [x28, #56]
    8c30:	52800003 	mov	w3, #0x0                   	// #0
    8c34:	97fffdc7 	bl	8350 <fwp_write>
    8c38:	f9400a73 	ldr	x19, [x19, #16]
    8c3c:	b4000193 	cbz	x19, 8c6c <fwp_write+0x91c>
    8c40:	aa1603e1 	mov	x1, x22
    8c44:	aa1403e0 	mov	x0, x20
    8c48:	d2800042 	mov	x2, #0x2                   	// #2
    8c4c:	97ffe9d1 	bl	3390 <buf_put>
    8c50:	f9400661 	ldr	x1, [x19, #8]
    8c54:	aa1403e0 	mov	x0, x20
    8c58:	f9401f82 	ldr	x2, [x28, #56]
    8c5c:	52800003 	mov	w3, #0x0                   	// #0
    8c60:	97fffdbc 	bl	8350 <fwp_write>
    8c64:	f9400a73 	ldr	x19, [x19, #16]
    8c68:	b5fffed3 	cbnz	x19, 8c40 <fwp_write+0x8f0>
    8c6c:	52800ba3 	mov	w3, #0x5d                  	// #93
    8c70:	aa1503e1 	mov	x1, x21
    8c74:	aa1403e0 	mov	x0, x20
    8c78:	d2800022 	mov	x2, #0x1                   	// #1
    8c7c:	39001fe3 	strb	w3, [sp, #7]
    8c80:	17fffddb 	b	83ec <fwp_write+0x9c>
    8c84:	aa1403e0 	mov	x0, x20
    8c88:	b0000021 	adrp	x1, d000 <__modti3+0x1f0>
    8c8c:	d28000c2 	mov	x2, #0x6                   	// #6
    8c90:	911be021 	add	x1, x1, #0x6f8
    8c94:	97ffe9bf 	bl	3390 <buf_put>
    8c98:	f9400260 	ldr	x0, [x19]
    8c9c:	b40004c0 	cbz	x0, 8d34 <fwp_write+0x9e4>
    8ca0:	910123f5 	add	x21, sp, #0x48
    8ca4:	91002276 	add	x22, x19, #0x8
    8ca8:	f90143f7 	str	x23, [sp, #640]
    8cac:	d2800017 	mov	x23, #0x0                   	// #0
    8cb0:	f90147f8 	str	x24, [sp, #648]
    8cb4:	b0000038 	adrp	x24, d000 <__modti3+0x1f0>
    8cb8:	911c0318 	add	x24, x24, #0x700
    8cbc:	f9014bf9 	str	x25, [sp, #656]
    8cc0:	b0000039 	adrp	x25, d000 <__modti3+0x1f0>
    8cc4:	911c2339 	add	x25, x25, #0x708
    8cc8:	f9014ffa 	str	x26, [sp, #664]
    8ccc:	14000005 	b	8ce0 <fwp_write+0x990>
    8cd0:	aa1903e1 	mov	x1, x25
    8cd4:	aa1403e0 	mov	x0, x20
    8cd8:	d2800042 	mov	x2, #0x2                   	// #2
    8cdc:	97ffe9ad 	bl	3390 <buf_put>
    8ce0:	38776ac5 	ldrb	w5, [x22, x23]
    8ce4:	d2804003 	mov	x3, #0x200                 	// #512
    8ce8:	aa1803e4 	mov	x4, x24
    8cec:	aa0303e1 	mov	x1, x3
    8cf0:	52800042 	mov	w2, #0x2                   	// #2
    8cf4:	aa1503e0 	mov	x0, x21
    8cf8:	910006f7 	add	x23, x23, #0x1
    8cfc:	97ffe699 	bl	2760 <__snprintf_chk@plt>
    8d00:	aa1503e0 	mov	x0, x21
    8d04:	97ffe65f 	bl	2680 <strlen@plt>
    8d08:	aa1503e1 	mov	x1, x21
    8d0c:	aa0003e2 	mov	x2, x0
    8d10:	aa1403e0 	mov	x0, x20
    8d14:	97ffe99f 	bl	3390 <buf_put>
    8d18:	f9400260 	ldr	x0, [x19]
    8d1c:	eb17001f 	cmp	x0, x23
    8d20:	54fffd88 	b.hi	8cd0 <fwp_write+0x980>  // b.pmore
    8d24:	f94143f7 	ldr	x23, [sp, #640]
    8d28:	f94147f8 	ldr	x24, [sp, #648]
    8d2c:	f9414bf9 	ldr	x25, [sp, #656]
    8d30:	f9414ffa 	ldr	x26, [sp, #664]
    8d34:	52800ba3 	mov	w3, #0x5d                  	// #93
    8d38:	aa1403e0 	mov	x0, x20
    8d3c:	91001fe1 	add	x1, sp, #0x7
    8d40:	d2800022 	mov	x2, #0x1                   	// #1
    8d44:	39001fe3 	strb	w3, [sp, #7]
    8d48:	17fffda9 	b	83ec <fwp_write+0x9c>
    8d4c:	52800fa3 	mov	w3, #0x7d                  	// #125
    8d50:	17fffe44 	b	8660 <fwp_write+0x310>
    8d54:	f10002ff 	cmp	x23, #0x0
    8d58:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8d5c:	71002c3f 	cmp	w1, #0xb
    8d60:	54ffebc0 	b.eq	8ad8 <fwp_write+0x788>  // b.none
    8d64:	aa1303e2 	mov	x2, x19
    8d68:	aa1703e1 	mov	x1, x23
    8d6c:	aa1403e0 	mov	x0, x20
    8d70:	52800003 	mov	w3, #0x0                   	// #0
    8d74:	97fffd77 	bl	8350 <fwp_write>
    8d78:	17ffff6a 	b	8b20 <fwp_write+0x7d0>
    8d7c:	aa1403e0 	mov	x0, x20
    8d80:	91001fe1 	add	x1, sp, #0x7
    8d84:	52800fa3 	mov	w3, #0x7d                  	// #125
    8d88:	d2800022 	mov	x2, #0x1                   	// #1
    8d8c:	17fffe38 	b	866c <fwp_write+0x31c>
    8d90:	a9400281 	ldp	x1, x0, [x20]
    8d94:	91000800 	add	x0, x0, #0x2
    8d98:	8b160000 	add	x0, x0, x22
    8d9c:	f9000680 	str	x0, [x20, #8]
    8da0:	3820683f 	strb	wzr, [x1, x0]
    8da4:	f9413bf5 	ldr	x21, [sp, #624]
    8da8:	f9413ff6 	ldr	x22, [sp, #632]
    8dac:	f94153fb 	ldr	x27, [sp, #672]
    8db0:	f94157fc 	ldr	x28, [sp, #680]
    8db4:	17fffd93 	b	8400 <fwp_write+0xb0>
    8db8:	f9400f80 	ldr	x0, [x28, #24]
    8dbc:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    8dc0:	aa1b03e0 	mov	x0, x27
    8dc4:	97ffe62f 	bl	2680 <strlen@plt>
    8dc8:	aa1b03e1 	mov	x1, x27
    8dcc:	aa0003e2 	mov	x2, x0
    8dd0:	aa1403e0 	mov	x0, x20
    8dd4:	97ffe96f 	bl	3390 <buf_put>
    8dd8:	aa1903e1 	mov	x1, x25
    8ddc:	aa1403e0 	mov	x0, x20
    8de0:	d2800062 	mov	x2, #0x3                   	// #3
    8de4:	97ffe96b 	bl	3390 <buf_put>
    8de8:	17fffe10 	b	8628 <fwp_write+0x2d8>
    8dec:	aa1a03e1 	mov	x1, x26
    8df0:	aa1403e0 	mov	x0, x20
    8df4:	d2800042 	mov	x2, #0x2                   	// #2
    8df8:	97ffe966 	bl	3390 <buf_put>
    8dfc:	17fffe09 	b	8620 <fwp_write+0x2d0>
    8e00:	f9400660 	ldr	x0, [x19, #8]
    8e04:	b4fffb00 	cbz	x0, 8d64 <fwp_write+0xa14>
    8e08:	b0000021 	adrp	x1, d000 <__modti3+0x1f0>
    8e0c:	911c8021 	add	x1, x1, #0x720
    8e10:	97ffe698 	bl	2870 <strcmp@plt>
    8e14:	7100001f 	cmp	w0, #0x0
    8e18:	1a9f07e0 	cset	w0, ne	// ne = any
    8e1c:	17ffff2f 	b	8ad8 <fwp_write+0x788>
    8e20:	aa1403e0 	mov	x0, x20
    8e24:	d2800042 	mov	x2, #0x2                   	// #2
    8e28:	b0000021 	adrp	x1, d000 <__modti3+0x1f0>
    8e2c:	911c6021 	add	x1, x1, #0x718
    8e30:	97ffe958 	bl	3390 <buf_put>
    8e34:	91004261 	add	x1, x19, #0x10
    8e38:	aa1403e0 	mov	x0, x20
    8e3c:	f9402382 	ldr	x2, [x28, #64]
    8e40:	52800003 	mov	w3, #0x0                   	// #0
    8e44:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    8e48:	97fffd42 	bl	8350 <fwp_write>
    8e4c:	17fffd9c 	b	84bc <fwp_write+0x16c>
    8e50:	1e22c109 	fcvt	d9, s8
    8e54:	910123f5 	add	x21, sp, #0x48
    8e58:	52800033 	mov	w19, #0x1                   	// #1
    8e5c:	d503201f 	nop
    8e60:	1e604120 	fmov	d0, d9
    8e64:	2a1303e1 	mov	w1, w19
    8e68:	aa1503e0 	mov	x0, x21
    8e6c:	97ffea8a 	bl	3894 <fwp_format_g.constprop.0>
    8e70:	aa1503e0 	mov	x0, x21
    8e74:	d2800001 	mov	x1, #0x0                   	// #0
    8e78:	97ffe68a 	bl	28a0 <strtof@plt>
    8e7c:	1e202100 	fcmp	s8, s0
    8e80:	54ffdb60 	b.eq	89ec <fwp_write+0x69c>  // b.none
    8e84:	11000673 	add	w19, w19, #0x1
    8e88:	71002a7f 	cmp	w19, #0xa
    8e8c:	54fffea1 	b.ne	8e60 <fwp_write+0xb10>  // b.any
    8e90:	1e604120 	fmov	d0, d9
    8e94:	aa1503e0 	mov	x0, x21
    8e98:	52800121 	mov	w1, #0x9                   	// #9
    8e9c:	97ffea7e 	bl	3894 <fwp_format_g.constprop.0>
    8ea0:	17fffed3 	b	89ec <fwp_write+0x69c>
    8ea4:	d37ef6a1 	lsl	x1, x21, #2
    8ea8:	b7f81563 	tbnz	x3, #63, 9154 <fwp_write+0xe04>
    8eac:	91002263 	add	x3, x19, #0x8
    8eb0:	8b010061 	add	x1, x3, x1
    8eb4:	b9400023 	ldr	w3, [x1]
    8eb8:	7100081f 	cmp	w0, #0x2
    8ebc:	2a0303e1 	mov	w1, w3
    8ec0:	93407c63 	sxtw	x3, w3
    8ec4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8ec8:	17fffe5a 	b	8830 <fwp_write+0x4e0>
    8ecc:	d37ffaa1 	lsl	x1, x21, #1
    8ed0:	b7f81363 	tbnz	x3, #63, 913c <fwp_write+0xdec>
    8ed4:	91002263 	add	x3, x19, #0x8
    8ed8:	8b010061 	add	x1, x3, x1
    8edc:	79400021 	ldrh	w1, [x1]
    8ee0:	7100041f 	cmp	w0, #0x1
    8ee4:	93403c23 	sxth	x3, w1
    8ee8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8eec:	17fffe51 	b	8830 <fwp_write+0x4e0>
    8ef0:	52800443 	mov	w3, #0x22                  	// #34
    8ef4:	91001ff5 	add	x21, sp, #0x7
    8ef8:	91002273 	add	x19, x19, #0x8
    8efc:	aa1503e1 	mov	x1, x21
    8f00:	aa1403e0 	mov	x0, x20
    8f04:	d2800022 	mov	x2, #0x1                   	// #1
    8f08:	39001fe3 	strb	w3, [sp, #7]
    8f0c:	f90143f7 	str	x23, [sp, #640]
    8f10:	8b160277 	add	x23, x19, x22
    8f14:	f90147f8 	str	x24, [sp, #648]
    8f18:	97ffe91e 	bl	3390 <buf_put>
    8f1c:	b4000696 	cbz	x22, 8fec <fwp_write+0xc9c>
    8f20:	b0000038 	adrp	x24, d000 <__modti3+0x1f0>
    8f24:	911b2318 	add	x24, x24, #0x6c8
    8f28:	f9014bf9 	str	x25, [sp, #656]
    8f2c:	b0000039 	adrp	x25, d000 <__modti3+0x1f0>
    8f30:	911ba339 	add	x25, x25, #0x6e8
    8f34:	f9014ffa 	str	x26, [sp, #664]
    8f38:	1400000d 	b	8f6c <fwp_write+0xc1c>
    8f3c:	710024bf 	cmp	w5, #0x9
    8f40:	54000460 	b.eq	8fcc <fwp_write+0xc7c>  // b.none
    8f44:	710028bf 	cmp	w5, #0xa
    8f48:	54000a61 	b.ne	9094 <fwp_write+0xd44>  // b.any
    8f4c:	b0000021 	adrp	x1, d000 <__modti3+0x1f0>
    8f50:	aa1403e0 	mov	x0, x20
    8f54:	911b6021 	add	x1, x1, #0x6d8
    8f58:	d2800042 	mov	x2, #0x2                   	// #2
    8f5c:	97ffe90d 	bl	3390 <buf_put>
    8f60:	91000673 	add	x19, x19, #0x1
    8f64:	eb17027f 	cmp	x19, x23
    8f68:	540003e0 	b.eq	8fe4 <fwp_write+0xc94>  // b.none
    8f6c:	39400265 	ldrb	w5, [x19]
    8f70:	710034bf 	cmp	w5, #0xd
    8f74:	54000180 	b.eq	8fa4 <fwp_write+0xc54>  // b.none
    8f78:	54fffe29 	b.ls	8f3c <fwp_write+0xbec>  // b.plast
    8f7c:	710088bf 	cmp	w5, #0x22
    8f80:	540001c0 	b.eq	8fb8 <fwp_write+0xc68>  // b.none
    8f84:	710170bf 	cmp	w5, #0x5c
    8f88:	54000741 	b.ne	9070 <fwp_write+0xd20>  // b.any
    8f8c:	aa1403e0 	mov	x0, x20
    8f90:	b0000021 	adrp	x1, d000 <__modti3+0x1f0>
    8f94:	d2800042 	mov	x2, #0x2                   	// #2
    8f98:	911b4021 	add	x1, x1, #0x6d0
    8f9c:	97ffe8fd 	bl	3390 <buf_put>
    8fa0:	17fffff0 	b	8f60 <fwp_write+0xc10>
    8fa4:	aa1903e1 	mov	x1, x25
    8fa8:	aa1403e0 	mov	x0, x20
    8fac:	d2800042 	mov	x2, #0x2                   	// #2
    8fb0:	97ffe8f8 	bl	3390 <buf_put>
    8fb4:	17ffffeb 	b	8f60 <fwp_write+0xc10>
    8fb8:	aa1803e1 	mov	x1, x24
    8fbc:	aa1403e0 	mov	x0, x20
    8fc0:	d2800042 	mov	x2, #0x2                   	// #2
    8fc4:	97ffe8f3 	bl	3390 <buf_put>
    8fc8:	17ffffe6 	b	8f60 <fwp_write+0xc10>
    8fcc:	aa1403e0 	mov	x0, x20
    8fd0:	b0000021 	adrp	x1, d000 <__modti3+0x1f0>
    8fd4:	d2800042 	mov	x2, #0x2                   	// #2
    8fd8:	911b8021 	add	x1, x1, #0x6e0
    8fdc:	97ffe8ed 	bl	3390 <buf_put>
    8fe0:	17ffffe0 	b	8f60 <fwp_write+0xc10>
    8fe4:	f9414bf9 	ldr	x25, [sp, #656]
    8fe8:	f9414ffa 	ldr	x26, [sp, #664]
    8fec:	aa1503e1 	mov	x1, x21
    8ff0:	aa1403e0 	mov	x0, x20
    8ff4:	52800443 	mov	w3, #0x22                  	// #34
    8ff8:	17fffd9c 	b	8668 <fwp_write+0x318>
    8ffc:	7100103f 	cmp	w1, #0x4
    9000:	54ffeb21 	b.ne	8d64 <fwp_write+0xa14>  // b.any
    9004:	f94006e0 	ldr	x0, [x23, #8]
    9008:	d37ffc00 	lsr	x0, x0, #63
    900c:	17fffeb3 	b	8ad8 <fwp_write+0x788>
    9010:	710002ff 	cmp	w23, #0x0
    9014:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9018:	17fffeb0 	b	8ad8 <fwp_write+0x788>
    901c:	528005a1 	mov	w1, #0x2d                  	// #45
    9020:	eb0203e2 	negs	x2, x2
    9024:	da0303e3 	ngc	x3, x3
    9028:	910127e0 	add	x0, sp, #0x49
    902c:	910123f5 	add	x21, sp, #0x48
    9030:	390123e1 	strb	w1, [sp, #72]
    9034:	97ffe75b 	bl	2da0 <fwp_fmt_u128>
    9038:	17fffe18 	b	8898 <fwp_write+0x548>
    903c:	d37ceea1 	lsl	x1, x21, #4
    9040:	b7f810a3 	tbnz	x3, #63, 9254 <fwp_write+0xf04>
    9044:	91002260 	add	x0, x19, #0x8
    9048:	8b010001 	add	x1, x0, x1
    904c:	17fffdf9 	b	8830 <fwp_write+0x4e0>
    9050:	f9400a61 	ldr	x1, [x19, #16]
    9054:	8b010000 	add	x0, x0, x1
    9058:	f9400001 	ldr	x1, [x0]
    905c:	17fffdf5 	b	8830 <fwp_write+0x4e0>
    9060:	90000021 	adrp	x1, d000 <__modti3+0x1f0>
    9064:	d2800042 	mov	x2, #0x2                   	// #2
    9068:	9119c021 	add	x1, x1, #0x670
    906c:	17fffed6 	b	8bc4 <fwp_write+0x874>
    9070:	7101fcbf 	cmp	w5, #0x7f
    9074:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9078:	540000e9 	b.ls	9094 <fwp_write+0xd44>  // b.plast
    907c:	aa1503e1 	mov	x1, x21
    9080:	aa1403e0 	mov	x0, x20
    9084:	d2800022 	mov	x2, #0x1                   	// #1
    9088:	39001fe5 	strb	w5, [sp, #7]
    908c:	97ffe8c1 	bl	3390 <buf_put>
    9090:	17ffffb4 	b	8f60 <fwp_write+0xc10>
    9094:	d2800203 	mov	x3, #0x10                  	// #16
    9098:	90000024 	adrp	x4, d000 <__modti3+0x1f0>
    909c:	aa0303e1 	mov	x1, x3
    90a0:	911bc084 	add	x4, x4, #0x6f0
    90a4:	910123f6 	add	x22, sp, #0x48
    90a8:	52800042 	mov	w2, #0x2                   	// #2
    90ac:	aa1603e0 	mov	x0, x22
    90b0:	97ffe5ac 	bl	2760 <__snprintf_chk@plt>
    90b4:	aa1603e0 	mov	x0, x22
    90b8:	97ffe572 	bl	2680 <strlen@plt>
    90bc:	aa1603e1 	mov	x1, x22
    90c0:	aa0003e2 	mov	x2, x0
    90c4:	aa1403e0 	mov	x0, x20
    90c8:	97ffe8b2 	bl	3390 <buf_put>
    90cc:	17ffffa5 	b	8f60 <fwp_write+0xc10>
    90d0:	1e604100 	fmov	d0, d8
    90d4:	aa1503e0 	mov	x0, x21
    90d8:	52800221 	mov	w1, #0x11                  	// #17
    90dc:	97ffe9ee 	bl	3894 <fwp_format_g.constprop.0>
    90e0:	17fffe43 	b	89ec <fwp_write+0x69c>
    90e4:	b9401040 	ldr	w0, [x2, #16]
    90e8:	350003c0 	cbnz	w0, 9160 <fwp_write+0xe10>
    90ec:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    90f0:	f947f400 	ldr	x0, [x0, #4072]
    90f4:	f94127e2 	ldr	x2, [sp, #584]
    90f8:	f9400001 	ldr	x1, [x0]
    90fc:	eb010042 	subs	x2, x2, x1
    9100:	d2800001 	mov	x1, #0x0                   	// #0
    9104:	54ffd721 	b.ne	8be8 <fwp_write+0x898>  // b.any
    9108:	f9413bf5 	ldr	x21, [sp, #624]
    910c:	90000021 	adrp	x1, d000 <__modti3+0x1f0>
    9110:	f9413ff6 	ldr	x22, [sp, #632]
    9114:	aa1403e0 	mov	x0, x20
    9118:	f94143f7 	ldr	x23, [sp, #640]
    911c:	911d0021 	add	x1, x1, #0x740
    9120:	f94147f8 	ldr	x24, [sp, #648]
    9124:	d2800042 	mov	x2, #0x2                   	// #2
    9128:	17fffd0e 	b	8560 <fwp_write+0x210>
    912c:	90000021 	adrp	x1, d000 <__modti3+0x1f0>
    9130:	d2800042 	mov	x2, #0x2                   	// #2
    9134:	9119e021 	add	x1, x1, #0x678
    9138:	17fffea3 	b	8bc4 <fwp_write+0x874>
    913c:	f9400a63 	ldr	x3, [x19, #16]
    9140:	8b030021 	add	x1, x1, x3
    9144:	17ffff66 	b	8edc <fwp_write+0xb8c>
    9148:	f9400a61 	ldr	x1, [x19, #16]
    914c:	8b0102a1 	add	x1, x21, x1
    9150:	17fffdb3 	b	881c <fwp_write+0x4cc>
    9154:	f9400a63 	ldr	x3, [x19, #16]
    9158:	8b030021 	add	x1, x1, x3
    915c:	17ffff56 	b	8eb4 <fwp_write+0xb64>
    9160:	b9404840 	ldr	w0, [x2, #72]
    9164:	91001ff5 	add	x21, sp, #0x7
    9168:	34ffa360 	cbz	w0, 85d4 <fwp_write+0x284>
    916c:	52800503 	mov	w3, #0x28                  	// #40
    9170:	aa1403e0 	mov	x0, x20
    9174:	aa1503e1 	mov	x1, x21
    9178:	d2800022 	mov	x2, #0x1                   	// #1
    917c:	39001fe3 	strb	w3, [sp, #7]
    9180:	97ffe884 	bl	3390 <buf_put>
    9184:	b9401380 	ldr	w0, [x28, #16]
    9188:	52800038 	mov	w24, #0x1                   	// #1
    918c:	7100001f 	cmp	w0, #0x0
    9190:	54ffa36c 	b.gt	85fc <fwp_write+0x2ac>
    9194:	17fffd32 	b	865c <fwp_write+0x30c>
    9198:	f9014bf9 	str	x25, [sp, #656]
    919c:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xed08>
    91a0:	f9014ffa 	str	x26, [sp, #664]
    91a4:	f9400676 	ldr	x22, [x19, #8]
    91a8:	91102333 	add	x19, x25, #0x408
    91ac:	91002273 	add	x19, x19, #0x8
    91b0:	937ffed8 	asr	x24, x22, #63
    91b4:	aa1802c0 	orr	x0, x22, x24
    91b8:	b5000320 	cbnz	x0, 921c <fwp_write+0xecc>
    91bc:	110006b5 	add	w21, w21, #0x1
    91c0:	710016bf 	cmp	w21, #0x5
    91c4:	54ffffc1 	b.ne	91bc <fwp_write+0xe6c>  // b.any
    91c8:	b7f80578 	tbnz	x24, #63, 9274 <fwp_write+0xf24>
    91cc:	910023f3 	add	x19, sp, #0x8
    91d0:	aa1603e2 	mov	x2, x22
    91d4:	aa1303e0 	mov	x0, x19
    91d8:	d2800003 	mov	x3, #0x0                   	// #0
    91dc:	97ffe6f1 	bl	2da0 <fwp_fmt_u128>
    91e0:	910123f5 	add	x21, sp, #0x48
    91e4:	90000023 	adrp	x3, d000 <__modti3+0x1f0>
    91e8:	aa1303e4 	mov	x4, x19
    91ec:	aa1503e0 	mov	x0, x21
    91f0:	911ce063 	add	x3, x3, #0x738
    91f4:	d2804002 	mov	x2, #0x200                 	// #512
    91f8:	52800041 	mov	w1, #0x2                   	// #2
    91fc:	97ffe525 	bl	2690 <__sprintf_chk@plt>
    9200:	aa1503e0 	mov	x0, x21
    9204:	97ffe51f 	bl	2680 <strlen@plt>
    9208:	aa1503e1 	mov	x1, x21
    920c:	aa0003e2 	mov	x2, x0
    9210:	aa1403e0 	mov	x0, x20
    9214:	97ffe85f 	bl	3390 <buf_put>
    9218:	17fffe47 	b	8b34 <fwp_write+0x7e4>
    921c:	f9400277 	ldr	x23, [x19]
    9220:	aa1603e0 	mov	x0, x22
    9224:	aa1803e1 	mov	x1, x24
    9228:	aa1703e2 	mov	x2, x23
    922c:	937ffefa 	asr	x26, x23, #63
    9230:	aa1a03e3 	mov	x3, x26
    9234:	94000ef7 	bl	ce10 <__modti3>
    9238:	aa010000 	orr	x0, x0, x1
    923c:	b40002c0 	cbz	x0, 9294 <fwp_write+0xf44>
    9240:	110006b5 	add	w21, w21, #0x1
    9244:	91004273 	add	x19, x19, #0x10
    9248:	710016bf 	cmp	w21, #0x5
    924c:	54fffe81 	b.ne	921c <fwp_write+0xecc>  // b.any
    9250:	17ffffde 	b	91c8 <fwp_write+0xe78>
    9254:	f9400a60 	ldr	x0, [x19, #16]
    9258:	8b000021 	add	x1, x1, x0
    925c:	17fffd75 	b	8830 <fwp_write+0x4e0>
    9260:	528c29c0 	mov	w0, #0x614e                	// #24910
    9264:	910123f5 	add	x21, sp, #0x48
    9268:	72a009c0 	movk	w0, #0x4e, lsl #16
    926c:	b9004be0 	str	w0, [sp, #72]
    9270:	17fffda2 	b	88f8 <fwp_write+0x5a8>
    9274:	528005a1 	mov	w1, #0x2d                  	// #45
    9278:	eb1603e2 	negs	x2, x22
    927c:	da1803e3 	ngc	x3, x24
    9280:	910027e0 	add	x0, sp, #0x9
    9284:	910023f3 	add	x19, sp, #0x8
    9288:	390023e1 	strb	w1, [sp, #8]
    928c:	97ffe6c5 	bl	2da0 <fwp_fmt_u128>
    9290:	17ffffd4 	b	91e0 <fwp_write+0xe90>
    9294:	aa1703e2 	mov	x2, x23
    9298:	aa1a03e3 	mov	x3, x26
    929c:	aa1603e0 	mov	x0, x22
    92a0:	aa1803e1 	mov	x1, x24
    92a4:	94000dfb 	bl	ca90 <__divti3>
    92a8:	aa0003e2 	mov	x2, x0
    92ac:	aa0103e3 	mov	x3, x1
    92b0:	b7f80201 	tbnz	x1, #63, 92f0 <fwp_write+0xfa0>
    92b4:	910023f3 	add	x19, sp, #0x8
    92b8:	aa1303e0 	mov	x0, x19
    92bc:	97ffe6b9 	bl	2da0 <fwp_fmt_u128>
    92c0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    92c4:	91102339 	add	x25, x25, #0x408
    92c8:	910123f5 	add	x21, sp, #0x48
    92cc:	aa1303e4 	mov	x4, x19
    92d0:	aa1503e0 	mov	x0, x21
    92d4:	90000023 	adrp	x3, d000 <__modti3+0x1f0>
    92d8:	f8616b25 	ldr	x5, [x25, x1]
    92dc:	911cc063 	add	x3, x3, #0x730
    92e0:	d2804002 	mov	x2, #0x200                 	// #512
    92e4:	52800041 	mov	w1, #0x2                   	// #2
    92e8:	97ffe4ea 	bl	2690 <__sprintf_chk@plt>
    92ec:	17ffffc5 	b	9200 <fwp_write+0xeb0>
    92f0:	528005a4 	mov	w4, #0x2d                  	// #45
    92f4:	eb0003e2 	negs	x2, x0
    92f8:	da0103e3 	ngc	x3, x1
    92fc:	910027e0 	add	x0, sp, #0x9
    9300:	910023f3 	add	x19, sp, #0x8
    9304:	390023e4 	strb	w4, [sp, #8]
    9308:	97ffe6a6 	bl	2da0 <fwp_fmt_u128>
    930c:	17ffffed 	b	92c0 <fwp_write+0xf70>
    9310:	f9013bf5 	str	x21, [sp, #624]
    9314:	f9013ff6 	str	x22, [sp, #632]
    9318:	f90143f7 	str	x23, [sp, #640]
    931c:	f90147f8 	str	x24, [sp, #648]
    9320:	f9014bf9 	str	x25, [sp, #656]
    9324:	f9014ffa 	str	x26, [sp, #664]
    9328:	f90153fb 	str	x27, [sp, #672]
    932c:	f90157fc 	str	x28, [sp, #680]
    9330:	fd015be8 	str	d8, [sp, #688]
    9334:	fd015fe9 	str	d9, [sp, #696]
    9338:	97ffe52e 	bl	27f0 <__stack_chk_fail@plt>
    933c:	d503201f 	nop

0000000000009340 <fwp_hof0.constprop.0>:
    9340:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9344:	d00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    9348:	f947f442 	ldr	x2, [x2, #4072]
    934c:	910003fd 	mov	x29, sp
    9350:	a90153f3 	stp	x19, x20, [sp, #16]
    9354:	a9025bf5 	stp	x21, x22, [sp, #32]
    9358:	a90363f7 	stp	x23, x24, [sp, #48]
    935c:	aa0003f7 	mov	x23, x0
    9360:	a9046bf9 	stp	x25, x26, [sp, #64]
    9364:	a90573fb 	stp	x27, x28, [sp, #80]
    9368:	d10243ff 	sub	sp, sp, #0x90
    936c:	f9400040 	ldr	x0, [x2]
    9370:	f81f83a0 	stur	x0, [x29, #-8]
    9374:	d2800000 	mov	x0, #0x0                   	// #0
    9378:	b4002da1 	cbz	x1, 992c <fwp_hof0.constprop.0+0x5ec>
    937c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9380:	9100401c 	add	x28, x0, #0x10
    9384:	9100239c 	add	x28, x28, #0x8
    9388:	f00000a0 	adrp	x0, 20000 <__data_start>
    938c:	aa0103fa 	mov	x26, x1
    9390:	d10083b4 	sub	x20, x29, #0x20
    9394:	91010015 	add	x21, x0, #0x40
    9398:	aa1c03f8 	mov	x24, x28
    939c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    93a0:	91154002 	add	x2, x0, #0x550
    93a4:	f949d841 	ldr	x1, [x2, #5040]
    93a8:	f949ec40 	ldr	x0, [x2, #5080]
    93ac:	cb0102e1 	sub	x1, x23, x1
    93b0:	eb00403f 	cmp	x1, x0, lsl #16
    93b4:	54000342 	b.cs	941c <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    93b8:	d350fc20 	lsr	x0, x1, #16
    93bc:	f949fc44 	ldr	x4, [x2, #5112]
    93c0:	8b000800 	add	x0, x0, x0, lsl #2
    93c4:	d37df002 	lsl	x2, x0, #3
    93c8:	8b020083 	add	x3, x4, x2
    93cc:	f9401060 	ldr	x0, [x3, #32]
    93d0:	b4000260 	cbz	x0, 941c <fwp_hof0.constprop.0+0xdc>
    93d4:	38626882 	ldrb	w2, [x4, x2]
    93d8:	7100085f 	cmp	w2, #0x2
    93dc:	54005240 	b.eq	9e24 <fwp_hof0.constprop.0+0xae4>  // b.none
    93e0:	7100045f 	cmp	w2, #0x1
    93e4:	540001c1 	b.ne	941c <fwp_hof0.constprop.0+0xdc>  // b.any
    93e8:	29430864 	ldp	w4, w2, [x3, #24]
    93ec:	92403c21 	and	x1, x1, #0xffff
    93f0:	9b047c21 	mul	x1, x1, x4
    93f4:	d360fc21 	lsr	x1, x1, #32
    93f8:	eb02003f 	cmp	x1, x2
    93fc:	54000102 	b.cs	941c <fwp_hof0.constprop.0+0xdc>  // b.hs, b.nlast
    9400:	8b010000 	add	x0, x0, x1
    9404:	39400001 	ldrb	w1, [x0]
    9408:	340000a1 	cbz	w1, 941c <fwp_hof0.constprop.0+0xdc>
    940c:	7103f43f 	cmp	w1, #0xfd
    9410:	54005728 	b.hi	9ef4 <fwp_hof0.constprop.0+0xbb4>  // b.pmore
    9414:	11000421 	add	w1, w1, #0x1
    9418:	39000001 	strb	w1, [x0]
    941c:	aa1703f9 	mov	x25, x23
    9420:	a938dfba 	stp	x26, x23, [x29, #-120]
    9424:	aa1803fa 	mov	x26, x24
    9428:	d28018f3 	mov	x19, #0xc7                  	// #199
    942c:	f81983b3 	stur	x19, [x29, #-104]
    9430:	f00000a0 	adrp	x0, 20000 <__data_start>
    9434:	91004000 	add	x0, x0, #0x10
    9438:	f9401ea3 	ldr	x3, [x21, #56]
    943c:	91002005 	add	x5, x0, #0x8
    9440:	b9400802 	ldr	w2, [x0, #8]
    9444:	d37be842 	lsl	x2, x2, #5
    9448:	8b02007b 	add	x27, x3, x2
    944c:	f9400f61 	ldr	x1, [x27, #24]
    9450:	f81e03b9 	stur	x25, [x29, #-32]
    9454:	b4004ee1 	cbz	x1, 9e30 <fwp_hof0.constprop.0+0xaf0>
    9458:	f9400c20 	ldr	x0, [x1, #24]
    945c:	b40042a0 	cbz	x0, 9cb0 <fwp_hof0.constprop.0+0x970>
    9460:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9464:	91154002 	add	x2, x0, #0x550
    9468:	f949d841 	ldr	x1, [x2, #5040]
    946c:	f949ec40 	ldr	x0, [x2, #5080]
    9470:	cb010341 	sub	x1, x26, x1
    9474:	eb00403f 	cmp	x1, x0, lsl #16
    9478:	54000342 	b.cs	94e0 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    947c:	d350fc20 	lsr	x0, x1, #16
    9480:	f949fc45 	ldr	x5, [x2, #5112]
    9484:	8b000800 	add	x0, x0, x0, lsl #2
    9488:	d37df002 	lsl	x2, x0, #3
    948c:	8b0200a3 	add	x3, x5, x2
    9490:	f9401060 	ldr	x0, [x3, #32]
    9494:	b4000260 	cbz	x0, 94e0 <fwp_hof0.constprop.0+0x1a0>
    9498:	386268a2 	ldrb	w2, [x5, x2]
    949c:	7100085f 	cmp	w2, #0x2
    94a0:	54004700 	b.eq	9d80 <fwp_hof0.constprop.0+0xa40>  // b.none
    94a4:	7100045f 	cmp	w2, #0x1
    94a8:	540001c1 	b.ne	94e0 <fwp_hof0.constprop.0+0x1a0>  // b.any
    94ac:	29430865 	ldp	w5, w2, [x3, #24]
    94b0:	92403c21 	and	x1, x1, #0xffff
    94b4:	9b057c21 	mul	x1, x1, x5
    94b8:	d360fc21 	lsr	x1, x1, #32
    94bc:	eb02003f 	cmp	x1, x2
    94c0:	54000102 	b.cs	94e0 <fwp_hof0.constprop.0+0x1a0>  // b.hs, b.nlast
    94c4:	8b010000 	add	x0, x0, x1
    94c8:	39400001 	ldrb	w1, [x0]
    94cc:	340000a1 	cbz	w1, 94e0 <fwp_hof0.constprop.0+0x1a0>
    94d0:	7103f43f 	cmp	w1, #0xfd
    94d4:	54004988 	b.hi	9e04 <fwp_hof0.constprop.0+0xac4>  // b.pmore
    94d8:	11000421 	add	w1, w1, #0x1
    94dc:	39000001 	strb	w1, [x0]
    94e0:	aa1a03f9 	mov	x25, x26
    94e4:	aa1a03e0 	mov	x0, x26
    94e8:	aa1b03e3 	mov	x3, x27
    94ec:	52800037 	mov	w23, #0x1                   	// #1
    94f0:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc90>
    94f4:	91154036 	add	x22, x1, #0x550
    94f8:	a93a6bb4 	stp	x20, x26, [x29, #-96]
    94fc:	f81b03b6 	stur	x22, [x29, #-80]
    9500:	b81cc3b7 	stur	w23, [x29, #-52]
    9504:	f81d03b4 	stur	x20, [x29, #-48]
    9508:	b9400401 	ldr	w1, [x0, #4]
    950c:	b9400078 	ldr	w24, [x3]
    9510:	b85cc3a0 	ldur	w0, [x29, #-52]
    9514:	4b010318 	sub	w24, w24, w1
    9518:	6b17031f 	cmp	w24, w23
    951c:	1a979307 	csel	w7, w24, w23, ls	// ls = plast
    9520:	6b0000ff 	cmp	w7, w0
    9524:	1a8090e0 	csel	w0, w7, w0, ls	// ls = plast
    9528:	b81c83a0 	stur	w0, [x29, #-56]
    952c:	6b0000e2 	subs	w2, w7, w0
    9530:	54000120 	b.eq	9554 <fwp_hof0.constprop.0+0x214>  // b.none
    9534:	f9400c63 	ldr	x3, [x3, #24]
    9538:	0b000021 	add	w1, w1, w0
    953c:	f85d03a4 	ldur	x4, [x29, #-48]
    9540:	b81d83a7 	stur	w7, [x29, #-40]
    9544:	f9400863 	ldr	x3, [x3, #16]
    9548:	8b204c80 	add	x0, x4, w0, uxtw #3
    954c:	d63f0060 	blr	x3
    9550:	b85d83a7 	ldur	w7, [x29, #-40]
    9554:	f9401ea0 	ldr	x0, [x21, #56]
    9558:	aa1903e6 	mov	x6, x25
    955c:	b9400323 	ldr	w3, [x25]
    9560:	2a0703f4 	mov	w20, w7
    9564:	f85d03bb 	ldur	x27, [x29, #-48]
    9568:	aa1903fc 	mov	x28, x25
    956c:	8b03141a 	add	x26, x0, x3, lsl #5
    9570:	f9400f40 	ldr	x0, [x26, #24]
    9574:	b40020e0 	cbz	x0, 9990 <fwp_hof0.constprop.0+0x650>
    9578:	f85b03bc 	ldur	x28, [x29, #-80]
    957c:	29371fb7 	stp	w23, w7, [x29, #-72]
    9580:	aa1a03f7 	mov	x23, x26
    9584:	b81c03b8 	stur	w24, [x29, #-64]
    9588:	aa1b03f8 	mov	x24, x27
    958c:	14000012 	b	95d4 <fwp_hof0.constprop.0+0x294>
    9590:	f9400001 	ldr	x1, [x0]
    9594:	aa1803e0 	mov	x0, x24
    9598:	d63f0020 	blr	x1
    959c:	aa0003fb 	mov	x27, x0
    95a0:	aa1903e0 	mov	x0, x25
    95a4:	97fff1eb 	bl	5d50 <fwp_closure_drop>
    95a8:	6b13029f 	cmp	w20, w19
    95ac:	54000ca0 	b.eq	9740 <fwp_hof0.constprop.0+0x400>  // b.none
    95b0:	f9401ea0 	ldr	x0, [x21, #56]
    95b4:	8b334f18 	add	x24, x24, w19, uxtw #3
    95b8:	b9400363 	ldr	w3, [x27]
    95bc:	4b1a02d4 	sub	w20, w22, w26
    95c0:	aa1b03e6 	mov	x6, x27
    95c4:	8b031417 	add	x23, x0, x3, lsl #5
    95c8:	f9400ee0 	ldr	x0, [x23, #24]
    95cc:	b4001da0 	cbz	x0, 9980 <fwp_hof0.constprop.0+0x640>
    95d0:	aa1b03f9 	mov	x25, x27
    95d4:	b94004c1 	ldr	w1, [x6, #4]
    95d8:	b94002fa 	ldr	w26, [x23]
    95dc:	0b010296 	add	w22, w20, w1
    95e0:	6b16035f 	cmp	w26, w22
    95e4:	54002488 	b.hi	9a74 <fwp_hof0.constprop.0+0x734>  // b.pmore
    95e8:	7100003f 	cmp	w1, #0x0
    95ec:	4b010353 	sub	w19, w26, w1
    95f0:	7a400b44 	ccmp	w26, #0x0, #0x4, eq	// eq = none
    95f4:	54fffce1 	b.ne	9590 <fwp_hof0.constprop.0+0x250>  // b.any
    95f8:	7100035f 	cmp	w26, #0x0
    95fc:	910003e2 	mov	x2, sp
    9600:	1a9f1744 	csinc	w4, w26, wzr, ne	// ne = any
    9604:	f81d83a2 	stur	x2, [x29, #-40]
    9608:	d37df084 	lsl	x4, x4, #3
    960c:	91003c84 	add	x4, x4, #0xf
    9610:	92704c87 	and	x7, x4, #0xfffff0000
    9614:	927c7c84 	and	x4, x4, #0xffffffff0
    9618:	cb2763e7 	sub	x7, sp, x7
    961c:	eb2763ff 	cmp	sp, x7
    9620:	540000a0 	b.eq	9634 <fwp_hof0.constprop.0+0x2f4>  // b.none
    9624:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9628:	f90203ff 	str	xzr, [sp, #1024]
    962c:	eb2763ff 	cmp	sp, x7
    9630:	54ffffa1 	b.ne	9624 <fwp_hof0.constprop.0+0x2e4>  // b.any
    9634:	92403c84 	and	x4, x4, #0xffff
    9638:	cb2463ff 	sub	sp, sp, x4
    963c:	f90003ff 	str	xzr, [sp]
    9640:	f110009f 	cmp	x4, #0x400
    9644:	54000043 	b.cc	964c <fwp_hof0.constprop.0+0x30c>  // b.lo, b.ul, b.last
    9648:	f90203ff 	str	xzr, [sp, #1024]
    964c:	910043fb 	add	x27, sp, #0x10
    9650:	d37d7c2a 	ubfiz	x10, x1, #3, #32
    9654:	910020c9 	add	x9, x6, #0x8
    9658:	d2800004 	mov	x4, #0x0                   	// #0
    965c:	340000c1 	cbz	w1, 9674 <fwp_hof0.constprop.0+0x334>
    9660:	f8646922 	ldr	x2, [x9, x4]
    9664:	f8246b62 	str	x2, [x27, x4]
    9668:	91002084 	add	x4, x4, #0x8
    966c:	eb04015f 	cmp	x10, x4
    9670:	54ffff81 	b.ne	9660 <fwp_hof0.constprop.0+0x320>  // b.any
    9674:	2a1303ea 	mov	w10, w19
    9678:	d2800004 	mov	x4, #0x0                   	// #0
    967c:	340000f3 	cbz	w19, 9698 <fwp_hof0.constprop.0+0x358>
    9680:	0b040022 	add	w2, w1, w4
    9684:	f8647b03 	ldr	x3, [x24, x4, lsl #3]
    9688:	91000484 	add	x4, x4, #0x1
    968c:	f8227b63 	str	x3, [x27, x2, lsl #3]
    9690:	eb04015f 	cmp	x10, x4
    9694:	54ffff61 	b.ne	9680 <fwp_hof0.constprop.0+0x340>  // b.any
    9698:	f949db81 	ldr	x1, [x28, #5040]
    969c:	f949ef84 	ldr	x4, [x28, #5080]
    96a0:	cb010321 	sub	x1, x25, x1
    96a4:	eb04403f 	cmp	x1, x4, lsl #16
    96a8:	540002e2 	b.cs	9704 <fwp_hof0.constprop.0+0x3c4>  // b.hs, b.nlast
    96ac:	d350fc24 	lsr	x4, x1, #16
    96b0:	f949ff8a 	ldr	x10, [x28, #5112]
    96b4:	8b040884 	add	x4, x4, x4, lsl #2
    96b8:	d37df084 	lsl	x4, x4, #3
    96bc:	8b040149 	add	x9, x10, x4
    96c0:	f9401128 	ldr	x8, [x9, #32]
    96c4:	b4000208 	cbz	x8, 9704 <fwp_hof0.constprop.0+0x3c4>
    96c8:	38646944 	ldrb	w4, [x10, x4]
    96cc:	7100089f 	cmp	w4, #0x2
    96d0:	54001520 	b.eq	9974 <fwp_hof0.constprop.0+0x634>  // b.none
    96d4:	7100049f 	cmp	w4, #0x1
    96d8:	54000161 	b.ne	9704 <fwp_hof0.constprop.0+0x3c4>  // b.any
    96dc:	2943112a 	ldp	w10, w4, [x9, #24]
    96e0:	92403c21 	and	x1, x1, #0xffff
    96e4:	9b0a7c21 	mul	x1, x1, x10
    96e8:	d360fc21 	lsr	x1, x1, #32
    96ec:	eb04003f 	cmp	x1, x4
    96f0:	540000a2 	b.cs	9704 <fwp_hof0.constprop.0+0x3c4>  // b.hs, b.nlast
    96f4:	8b010108 	add	x8, x8, x1
    96f8:	39400101 	ldrb	w1, [x8]
    96fc:	7100043f 	cmp	w1, #0x1
    9700:	54001360 	b.eq	996c <fwp_hof0.constprop.0+0x62c>  // b.none
    9704:	f9400404 	ldr	x4, [x0, #8]
    9708:	52800021 	mov	w1, #0x1                   	// #1
    970c:	aa1903e0 	mov	x0, x25
    9710:	d63f0080 	blr	x4
    9714:	f9400ee1 	ldr	x1, [x23, #24]
    9718:	aa1b03e0 	mov	x0, x27
    971c:	f9400021 	ldr	x1, [x1]
    9720:	d63f0020 	blr	x1
    9724:	aa0003fb 	mov	x27, x0
    9728:	f85d83a0 	ldur	x0, [x29, #-40]
    972c:	9100001f 	mov	sp, x0
    9730:	aa1903e0 	mov	x0, x25
    9734:	97fff187 	bl	5d50 <fwp_closure_drop>
    9738:	6b13029f 	cmp	w20, w19
    973c:	54fff3a1 	b.ne	95b0 <fwp_hof0.constprop.0+0x270>  // b.any
    9740:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9744:	aa1b03f9 	mov	x25, x27
    9748:	b85c03b8 	ldur	w24, [x29, #-64]
    974c:	6b17031f 	cmp	w24, w23
    9750:	540014c3 	b.cc	99e8 <fwp_hof0.constprop.0+0x6a8>  // b.lo, b.ul, b.last
    9754:	f85983a0 	ldur	x0, [x29, #-104]
    9758:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    975c:	f1000400 	subs	x0, x0, #0x1
    9760:	f81983a0 	stur	x0, [x29, #-104]
    9764:	54ffe661 	b.ne	9430 <fwp_hof0.constprop.0+0xf0>  // b.any
    9768:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xed08>
    976c:	91102042 	add	x2, x2, #0x408
    9770:	aa1903e1 	mov	x1, x25
    9774:	aa1403e0 	mov	x0, x20
    9778:	aa1a03f8 	mov	x24, x26
    977c:	aa1903fb 	mov	x27, x25
    9780:	a978dfba 	ldp	x26, x23, [x29, #-120]
    9784:	91014042 	add	x2, x2, #0x50
    9788:	52800023 	mov	w3, #0x1                   	// #1
    978c:	a93e7fbf 	stp	xzr, xzr, [x29, #-32]
    9790:	f81f03bf 	stur	xzr, [x29, #-16]
    9794:	97fffaef 	bl	8350 <fwp_write>
    9798:	a97e67b6 	ldp	x22, x25, [x29, #-32]
    979c:	90000020 	adrp	x0, d000 <__modti3+0x1f0>
    97a0:	912ea000 	add	x0, x0, #0xba8
    97a4:	f10002df 	cmp	x22, #0x0
    97a8:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    97ac:	b1002b3f 	cmn	x25, #0xa
    97b0:	540039c8 	b.hi	9ee8 <fwp_hof0.constprop.0+0xba8>  // b.pmore
    97b4:	91002720 	add	x0, x25, #0x9
    97b8:	52800021 	mov	w1, #0x1                   	// #1
    97bc:	97ffed0d 	bl	4bf0 <fwp_heap_alloc>
    97c0:	aa0003f3 	mov	x19, x0
    97c4:	aa1603e1 	mov	x1, x22
    97c8:	aa0003f6 	mov	x22, x0
    97cc:	aa1903e2 	mov	x2, x25
    97d0:	f80086d9 	str	x25, [x22], #8
    97d4:	8b190279 	add	x25, x19, x25
    97d8:	aa1603e0 	mov	x0, x22
    97dc:	97ffe399 	bl	2640 <memcpy@plt>
    97e0:	3900233f 	strb	wzr, [x25, #8]
    97e4:	f85e03a0 	ldur	x0, [x29, #-32]
    97e8:	97ffe432 	bl	28b0 <free@plt>
    97ec:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    97f0:	91154002 	add	x2, x0, #0x550
    97f4:	f949d841 	ldr	x1, [x2, #5040]
    97f8:	f949ec40 	ldr	x0, [x2, #5080]
    97fc:	cb010261 	sub	x1, x19, x1
    9800:	eb00403f 	cmp	x1, x0, lsl #16
    9804:	54000322 	b.cs	9868 <fwp_hof0.constprop.0+0x528>  // b.hs, b.nlast
    9808:	d350fc20 	lsr	x0, x1, #16
    980c:	f949fc43 	ldr	x3, [x2, #5112]
    9810:	8b000800 	add	x0, x0, x0, lsl #2
    9814:	d37df002 	lsl	x2, x0, #3
    9818:	8b020060 	add	x0, x3, x2
    981c:	f9401019 	ldr	x25, [x0, #32]
    9820:	b4000259 	cbz	x25, 9868 <fwp_hof0.constprop.0+0x528>
    9824:	38626862 	ldrb	w2, [x3, x2]
    9828:	7100085f 	cmp	w2, #0x2
    982c:	54003220 	b.eq	9e70 <fwp_hof0.constprop.0+0xb30>  // b.none
    9830:	7100045f 	cmp	w2, #0x1
    9834:	540001a1 	b.ne	9868 <fwp_hof0.constprop.0+0x528>  // b.any
    9838:	29430002 	ldp	w2, w0, [x0, #24]
    983c:	92403c21 	and	x1, x1, #0xffff
    9840:	9b027c21 	mul	x1, x1, x2
    9844:	d360fc21 	lsr	x1, x1, #32
    9848:	eb00003f 	cmp	x1, x0
    984c:	540000e2 	b.cs	9868 <fwp_hof0.constprop.0+0x528>  // b.hs, b.nlast
    9850:	8b010339 	add	x25, x25, x1
    9854:	39400320 	ldrb	w0, [x25]
    9858:	7103fc1f 	cmp	w0, #0xff
    985c:	54003520 	b.eq	9f00 <fwp_hof0.constprop.0+0xbc0>  // b.none
    9860:	52800020 	mov	w0, #0x1                   	// #1
    9864:	39000320 	strb	w0, [x25]
    9868:	aa1b03e0 	mov	x0, x27
    986c:	97fff0dd 	bl	5be0 <fwp_drop0>
    9870:	f00000a0 	adrp	x0, 20000 <__data_start>
    9874:	91010003 	add	x3, x0, #0x40
    9878:	f9400262 	ldr	x2, [x19]
    987c:	aa1603e0 	mov	x0, x22
    9880:	aa0303f6 	mov	x22, x3
    9884:	d2800021 	mov	x1, #0x1                   	// #1
    9888:	f9400463 	ldr	x3, [x3, #8]
    988c:	97ffe419 	bl	28f0 <fwrite@plt>
    9890:	f94006c1 	ldr	x1, [x22, #8]
    9894:	52800140 	mov	w0, #0xa                   	// #10
    9898:	97ffe39e 	bl	2710 <fputc@plt>
    989c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    98a0:	91154002 	add	x2, x0, #0x550
    98a4:	f949d841 	ldr	x1, [x2, #5040]
    98a8:	f949ec40 	ldr	x0, [x2, #5080]
    98ac:	cb010261 	sub	x1, x19, x1
    98b0:	eb00403f 	cmp	x1, x0, lsl #16
    98b4:	54000382 	b.cs	9924 <fwp_hof0.constprop.0+0x5e4>  // b.hs, b.nlast
    98b8:	d350fc20 	lsr	x0, x1, #16
    98bc:	f949fc43 	ldr	x3, [x2, #5112]
    98c0:	8b000800 	add	x0, x0, x0, lsl #2
    98c4:	d37df000 	lsl	x0, x0, #3
    98c8:	8b000062 	add	x2, x3, x0
    98cc:	f9401056 	ldr	x22, [x2, #32]
    98d0:	b40002b6 	cbz	x22, 9924 <fwp_hof0.constprop.0+0x5e4>
    98d4:	38606860 	ldrb	w0, [x3, x0]
    98d8:	7100081f 	cmp	w0, #0x2
    98dc:	54002c40 	b.eq	9e64 <fwp_hof0.constprop.0+0xb24>  // b.none
    98e0:	7100041f 	cmp	w0, #0x1
    98e4:	54000201 	b.ne	9924 <fwp_hof0.constprop.0+0x5e4>  // b.any
    98e8:	29430043 	ldp	w3, w0, [x2, #24]
    98ec:	92403c21 	and	x1, x1, #0xffff
    98f0:	9b037c21 	mul	x1, x1, x3
    98f4:	d360fc21 	lsr	x1, x1, #32
    98f8:	eb00003f 	cmp	x1, x0
    98fc:	54000142 	b.cs	9924 <fwp_hof0.constprop.0+0x5e4>  // b.hs, b.nlast
    9900:	8b0102d6 	add	x22, x22, x1
    9904:	394002c0 	ldrb	w0, [x22]
    9908:	340000e0 	cbz	w0, 9924 <fwp_hof0.constprop.0+0x5e4>
    990c:	7100041f 	cmp	w0, #0x1
    9910:	54002a00 	b.eq	9e50 <fwp_hof0.constprop.0+0xb10>  // b.none
    9914:	7103fc1f 	cmp	w0, #0xff
    9918:	54002b20 	b.eq	9e7c <fwp_hof0.constprop.0+0xb3c>  // b.none
    991c:	51000400 	sub	w0, w0, #0x1
    9920:	390002c0 	strb	w0, [x22]
    9924:	f9400b5a 	ldr	x26, [x26, #16]
    9928:	b5ffd3ba 	cbnz	x26, 939c <fwp_hof0.constprop.0+0x5c>
    992c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9930:	f947f400 	ldr	x0, [x0, #4072]
    9934:	f85f83a2 	ldur	x2, [x29, #-8]
    9938:	f9400001 	ldr	x1, [x0]
    993c:	eb010042 	subs	x2, x2, x1
    9940:	d2800001 	mov	x1, #0x0                   	// #0
    9944:	54002dc1 	b.ne	9efc <fwp_hof0.constprop.0+0xbbc>  // b.any
    9948:	910003bf 	mov	sp, x29
    994c:	d2800000 	mov	x0, #0x0                   	// #0
    9950:	a94153f3 	ldp	x19, x20, [sp, #16]
    9954:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9958:	a94363f7 	ldp	x23, x24, [sp, #48]
    995c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    9960:	a94573fb 	ldp	x27, x28, [sp, #80]
    9964:	a8c67bfd 	ldp	x29, x30, [sp], #96
    9968:	d65f03c0 	ret
    996c:	b90004df 	str	wzr, [x6, #4]
    9970:	17ffff69 	b	9714 <fwp_hof0.constprop.0+0x3d4>
    9974:	72003c3f 	tst	w1, #0xffff
    9978:	54ffec61 	b.ne	9704 <fwp_hof0.constprop.0+0x3c4>  // b.any
    997c:	17ffff5f 	b	96f8 <fwp_hof0.constprop.0+0x3b8>
    9980:	aa1b03fc 	mov	x28, x27
    9984:	aa1803fb 	mov	x27, x24
    9988:	29771fb7 	ldp	w23, w7, [x29, #-72]
    998c:	b85c03b8 	ldur	w24, [x29, #-64]
    9990:	aa1c03e0 	mov	x0, x28
    9994:	b81d83a7 	stur	w7, [x29, #-40]
    9998:	97ffef13 	bl	55e4 <fwp_rc_share>
    999c:	b85d83a7 	ldur	w7, [x29, #-40]
    99a0:	34000134 	cbz	w20, 99c4 <fwp_hof0.constprop.0+0x684>
    99a4:	aa1b03f6 	mov	x22, x27
    99a8:	8b344f73 	add	x19, x27, w20, uxtw #3
    99ac:	2a0703f9 	mov	w25, w7
    99b0:	f84086c0 	ldr	x0, [x22], #8
    99b4:	97ffef0c 	bl	55e4 <fwp_rc_share>
    99b8:	eb16027f 	cmp	x19, x22
    99bc:	54ffffa1 	b.ne	99b0 <fwp_hof0.constprop.0+0x670>  // b.any
    99c0:	2a1903e7 	mov	w7, w25
    99c4:	aa1b03e2 	mov	x2, x27
    99c8:	2a1403e1 	mov	w1, w20
    99cc:	aa1c03e0 	mov	x0, x28
    99d0:	b81d83a7 	stur	w7, [x29, #-40]
    99d4:	97ffeccc 	bl	4d04 <fwp_apply>
    99d8:	aa0003f9 	mov	x25, x0
    99dc:	b85d83a7 	ldur	w7, [x29, #-40]
    99e0:	6b17031f 	cmp	w24, w23
    99e4:	54ffeb82 	b.cs	9754 <fwp_hof0.constprop.0+0x414>  // b.hs, b.nlast
    99e8:	f9401ea1 	ldr	x1, [x21, #56]
    99ec:	4b0702f7 	sub	w23, w23, w7
    99f0:	b9400323 	ldr	w3, [x25]
    99f4:	f85d03a0 	ldur	x0, [x29, #-48]
    99f8:	8b031423 	add	x3, x1, x3, lsl #5
    99fc:	b85c83a2 	ldur	w2, [x29, #-56]
    9a00:	8b274c00 	add	x0, x0, w7, uxtw #3
    9a04:	f81d03a0 	stur	x0, [x29, #-48]
    9a08:	f9400c61 	ldr	x1, [x3, #24]
    9a0c:	b85cc3a0 	ldur	w0, [x29, #-52]
    9a10:	4b020000 	sub	w0, w0, w2
    9a14:	b81cc3a0 	stur	w0, [x29, #-52]
    9a18:	aa1903e0 	mov	x0, x25
    9a1c:	b5ffd761 	cbnz	x1, 9508 <fwp_hof0.constprop.0+0x1c8>
    9a20:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    9a24:	aa1903e0 	mov	x0, x25
    9a28:	97ffeeef 	bl	55e4 <fwp_rc_share>
    9a2c:	34000117 	cbz	w23, 9a4c <fwp_hof0.constprop.0+0x70c>
    9a30:	f85d03b8 	ldur	x24, [x29, #-48]
    9a34:	d2800016 	mov	x22, #0x0                   	// #0
    9a38:	f8767b00 	ldr	x0, [x24, x22, lsl #3]
    9a3c:	910006d6 	add	x22, x22, #0x1
    9a40:	97ffeee9 	bl	55e4 <fwp_rc_share>
    9a44:	6b1602ff 	cmp	w23, w22
    9a48:	54ffff88 	b.hi	9a38 <fwp_hof0.constprop.0+0x6f8>  // b.pmore
    9a4c:	f85d03a2 	ldur	x2, [x29, #-48]
    9a50:	aa1903e0 	mov	x0, x25
    9a54:	2a1703e1 	mov	w1, w23
    9a58:	97ffecab 	bl	4d04 <fwp_apply>
    9a5c:	aa0003f9 	mov	x25, x0
    9a60:	f85983a0 	ldur	x0, [x29, #-104]
    9a64:	f1000400 	subs	x0, x0, #0x1
    9a68:	f81983a0 	stur	x0, [x29, #-104]
    9a6c:	54ffce21 	b.ne	9430 <fwp_hof0.constprop.0+0xf0>  // b.any
    9a70:	17ffff3e 	b	9768 <fwp_hof0.constprop.0+0x428>
    9a74:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9a78:	9115400a 	add	x10, x0, #0x550
    9a7c:	2a0103fc 	mov	w28, w1
    9a80:	110006c0 	add	w0, w22, #0x1
    9a84:	f120001f 	cmp	x0, #0x800
    9a88:	aa1703fa 	mov	x26, x23
    9a8c:	b953a541 	ldr	w1, [x10, #5028]
    9a90:	aa1803fb 	mov	x27, x24
    9a94:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9a98:	d37df000 	lsl	x0, x0, #3
    9a9c:	b85c03b8 	ldur	w24, [x29, #-64]
    9aa0:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    9aa4:	54001860 	b.eq	9db0 <fwp_hof0.constprop.0+0xa70>  // b.none
    9aa8:	91003c01 	add	x1, x0, #0xf
    9aac:	8b411141 	add	x1, x10, x1, lsr #4
    9ab0:	397e8021 	ldrb	w1, [x1, #4000]
    9ab4:	910f002b 	add	x11, x1, #0x3c0
    9ab8:	8b010429 	add	x9, x1, x1, lsl #1
    9abc:	b86b794b 	ldr	w11, [x10, x11, lsl #2]
    9ac0:	8b090d4c 	add	x12, x10, x9, lsl #3
    9ac4:	f8697953 	ldr	x19, [x10, x9, lsl #3]
    9ac8:	2a0b03e1 	mov	w1, w11
    9acc:	b4001613 	cbz	x19, 9d8c <fwp_hof0.constprop.0+0xa4c>
    9ad0:	f940026c 	ldr	x12, [x19]
    9ad4:	aa2c03ec 	mvn	x12, x12
    9ad8:	f829794c 	str	x12, [x10, x9, lsl #3]
    9adc:	eb01001f 	cmp	x0, x1
    9ae0:	540000c2 	b.cs	9af8 <fwp_hof0.constprop.0+0x7b8>  // b.hs, b.nlast
    9ae4:	d503201f 	nop
    9ae8:	f8206a7f 	str	xzr, [x19, x0]
    9aec:	91002000 	add	x0, x0, #0x8
    9af0:	eb00003f 	cmp	x1, x0
    9af4:	54ffffa8 	b.hi	9ae8 <fwp_hof0.constprop.0+0x7a8>  // b.pmore
    9af8:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9afc:	91154009 	add	x9, x0, #0x550
    9b00:	f94a1120 	ldr	x0, [x9, #5152]
    9b04:	ab010000 	adds	x0, x0, x1
    9b08:	54001e82 	b.cs	9ed8 <fwp_hof0.constprop.0+0xb98>  // b.hs, b.nlast
    9b0c:	f94a1521 	ldr	x1, [x9, #5160]
    9b10:	f90a1120 	str	x0, [x9, #5152]
    9b14:	eb01001f 	cmp	x0, x1
    9b18:	54000049 	b.ls	9b20 <fwp_hof0.constprop.0+0x7e0>  // b.plast
    9b1c:	f90a1520 	str	x0, [x9, #5160]
    9b20:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9b24:	91154000 	add	x0, x0, #0x550
    9b28:	1e630161 	ucvtf	d1, w11
    9b2c:	fd4a1c00 	ldr	d0, [x0, #5176]
    9b30:	1e612800 	fadd	d0, d0, d1
    9b34:	fd0a1c00 	str	d0, [x0, #5176]
    9b38:	b94000c0 	ldr	w0, [x6]
    9b3c:	29005a60 	stp	w0, w22, [x19]
    9b40:	3400013c 	cbz	w28, 9b64 <fwp_hof0.constprop.0+0x824>
    9b44:	910020c1 	add	x1, x6, #0x8
    9b48:	d37d7f82 	ubfiz	x2, x28, #3, #32
    9b4c:	91002260 	add	x0, x19, #0x8
    9b50:	b81c03a7 	stur	w7, [x29, #-64]
    9b54:	f81d83a6 	stur	x6, [x29, #-40]
    9b58:	97ffe2c2 	bl	2660 <memmove@plt>
    9b5c:	f85d83a6 	ldur	x6, [x29, #-40]
    9b60:	b85c03a7 	ldur	w7, [x29, #-64]
    9b64:	2a1403e9 	mov	w9, w20
    9b68:	d2800001 	mov	x1, #0x0                   	// #0
    9b6c:	34000114 	cbz	w20, 9b8c <fwp_hof0.constprop.0+0x84c>
    9b70:	0b010380 	add	w0, w28, w1
    9b74:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    9b78:	8b000e60 	add	x0, x19, x0, lsl #3
    9b7c:	91000421 	add	x1, x1, #0x1
    9b80:	f9000402 	str	x2, [x0, #8]
    9b84:	eb01013f 	cmp	x9, x1
    9b88:	54ffff41 	b.ne	9b70 <fwp_hof0.constprop.0+0x830>  // b.any
    9b8c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9b90:	91154002 	add	x2, x0, #0x550
    9b94:	f949d840 	ldr	x0, [x2, #5040]
    9b98:	f949ec41 	ldr	x1, [x2, #5080]
    9b9c:	cb000320 	sub	x0, x25, x0
    9ba0:	eb01401f 	cmp	x0, x1, lsl #16
    9ba4:	540002e2 	b.cs	9c00 <fwp_hof0.constprop.0+0x8c0>  // b.hs, b.nlast
    9ba8:	d350fc01 	lsr	x1, x0, #16
    9bac:	f949fc45 	ldr	x5, [x2, #5112]
    9bb0:	8b010821 	add	x1, x1, x1, lsl #2
    9bb4:	d37df021 	lsl	x1, x1, #3
    9bb8:	8b0100a4 	add	x4, x5, x1
    9bbc:	f9401082 	ldr	x2, [x4, #32]
    9bc0:	b4000202 	cbz	x2, 9c00 <fwp_hof0.constprop.0+0x8c0>
    9bc4:	386168a1 	ldrb	w1, [x5, x1]
    9bc8:	7100083f 	cmp	w1, #0x2
    9bcc:	54001020 	b.eq	9dd0 <fwp_hof0.constprop.0+0xa90>  // b.none
    9bd0:	7100043f 	cmp	w1, #0x1
    9bd4:	54000161 	b.ne	9c00 <fwp_hof0.constprop.0+0x8c0>  // b.any
    9bd8:	29430485 	ldp	w5, w1, [x4, #24]
    9bdc:	92403c00 	and	x0, x0, #0xffff
    9be0:	9b057c00 	mul	x0, x0, x5
    9be4:	d360fc00 	lsr	x0, x0, #32
    9be8:	eb01001f 	cmp	x0, x1
    9bec:	540000a2 	b.cs	9c00 <fwp_hof0.constprop.0+0x8c0>  // b.hs, b.nlast
    9bf0:	8b000042 	add	x2, x2, x0
    9bf4:	39400040 	ldrb	w0, [x2]
    9bf8:	7100041f 	cmp	w0, #0x1
    9bfc:	54000be0 	b.eq	9d78 <fwp_hof0.constprop.0+0xa38>  // b.none
    9c00:	f9400f42 	ldr	x2, [x26, #24]
    9c04:	aa1903e0 	mov	x0, x25
    9c08:	52800021 	mov	w1, #0x1                   	// #1
    9c0c:	b81d83a7 	stur	w7, [x29, #-40]
    9c10:	f9400442 	ldr	x2, [x2, #8]
    9c14:	d63f0040 	blr	x2
    9c18:	b85d83a7 	ldur	w7, [x29, #-40]
    9c1c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9c20:	91154002 	add	x2, x0, #0x550
    9c24:	f949d841 	ldr	x1, [x2, #5040]
    9c28:	f949ec40 	ldr	x0, [x2, #5080]
    9c2c:	cb010261 	sub	x1, x19, x1
    9c30:	eb00403f 	cmp	x1, x0, lsl #16
    9c34:	54000322 	b.cs	9c98 <fwp_hof0.constprop.0+0x958>  // b.hs, b.nlast
    9c38:	d350fc20 	lsr	x0, x1, #16
    9c3c:	f949fc43 	ldr	x3, [x2, #5112]
    9c40:	8b000800 	add	x0, x0, x0, lsl #2
    9c44:	d37df002 	lsl	x2, x0, #3
    9c48:	8b020060 	add	x0, x3, x2
    9c4c:	f9401014 	ldr	x20, [x0, #32]
    9c50:	b4000254 	cbz	x20, 9c98 <fwp_hof0.constprop.0+0x958>
    9c54:	38626862 	ldrb	w2, [x3, x2]
    9c58:	7100085f 	cmp	w2, #0x2
    9c5c:	54000c00 	b.eq	9ddc <fwp_hof0.constprop.0+0xa9c>  // b.none
    9c60:	7100045f 	cmp	w2, #0x1
    9c64:	540001a1 	b.ne	9c98 <fwp_hof0.constprop.0+0x958>  // b.any
    9c68:	29430002 	ldp	w2, w0, [x0, #24]
    9c6c:	92403c21 	and	x1, x1, #0xffff
    9c70:	9b027c21 	mul	x1, x1, x2
    9c74:	d360fc21 	lsr	x1, x1, #32
    9c78:	eb00003f 	cmp	x1, x0
    9c7c:	540000e2 	b.cs	9c98 <fwp_hof0.constprop.0+0x958>  // b.hs, b.nlast
    9c80:	8b010294 	add	x20, x20, x1
    9c84:	39400280 	ldrb	w0, [x20]
    9c88:	7103fc1f 	cmp	w0, #0xff
    9c8c:	54000b20 	b.eq	9df0 <fwp_hof0.constprop.0+0xab0>  // b.none
    9c90:	52800020 	mov	w0, #0x1                   	// #1
    9c94:	39000280 	strb	w0, [x20]
    9c98:	aa1903e0 	mov	x0, x25
    9c9c:	b81d83a7 	stur	w7, [x29, #-40]
    9ca0:	97fff02c 	bl	5d50 <fwp_closure_drop>
    9ca4:	aa1303f9 	mov	x25, x19
    9ca8:	b85d83a7 	ldur	w7, [x29, #-40]
    9cac:	17ffff4d 	b	99e0 <fwp_hof0.constprop.0+0x6a0>
    9cb0:	b8626860 	ldr	w0, [x3, x2]
    9cb4:	b94004a2 	ldr	w2, [x5, #4]
    9cb8:	4b020003 	sub	w3, w0, w2
    9cbc:	7100047f 	cmp	w3, #0x1
    9cc0:	54ffbd01 	b.ne	9460 <fwp_hof0.constprop.0+0x120>  // b.any
    9cc4:	910003f6 	mov	x22, sp
    9cc8:	34000a22 	cbz	w2, 9e0c <fwp_hof0.constprop.0+0xacc>
    9ccc:	7100001f 	cmp	w0, #0x0
    9cd0:	d37d7c00 	ubfiz	x0, x0, #3, #32
    9cd4:	d2800101 	mov	x1, #0x8                   	// #8
    9cd8:	9a811017 	csel	x23, x0, x1, ne	// ne = any
    9cdc:	91003ee0 	add	x0, x23, #0xf
    9ce0:	92704c01 	and	x1, x0, #0xfffff0000
    9ce4:	927c7c00 	and	x0, x0, #0xffffffff0
    9ce8:	cb2163e1 	sub	x1, sp, x1
    9cec:	eb2163ff 	cmp	sp, x1
    9cf0:	540000a0 	b.eq	9d04 <fwp_hof0.constprop.0+0x9c4>  // b.none
    9cf4:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9cf8:	f90203ff 	str	xzr, [sp, #1024]
    9cfc:	eb2163ff 	cmp	sp, x1
    9d00:	54ffffa1 	b.ne	9cf4 <fwp_hof0.constprop.0+0x9b4>  // b.any
    9d04:	92403c00 	and	x0, x0, #0xffff
    9d08:	cb2063ff 	sub	sp, sp, x0
    9d0c:	f90003ff 	str	xzr, [sp]
    9d10:	f110001f 	cmp	x0, #0x400
    9d14:	54000043 	b.cc	9d1c <fwp_hof0.constprop.0+0x9dc>  // b.lo, b.ul, b.last
    9d18:	f90203ff 	str	xzr, [sp, #1024]
    9d1c:	d37d7c5c 	ubfiz	x28, x2, #3, #32
    9d20:	910043f8 	add	x24, sp, #0x10
    9d24:	f00000a0 	adrp	x0, 20000 <__data_start>
    9d28:	91004001 	add	x1, x0, #0x10
    9d2c:	aa1c03e2 	mov	x2, x28
    9d30:	91004021 	add	x1, x1, #0x10
    9d34:	aa1703e3 	mov	x3, x23
    9d38:	aa1803e0 	mov	x0, x24
    9d3c:	97ffe281 	bl	2740 <__memcpy_chk@plt>
    9d40:	eb1c02ff 	cmp	x23, x28
    9d44:	aa1403e1 	mov	x1, x20
    9d48:	9a9c22e3 	csel	x3, x23, x28, cs	// cs = hs, nlast
    9d4c:	d2800102 	mov	x2, #0x8                   	// #8
    9d50:	cb1c0063 	sub	x3, x3, x28
    9d54:	8b1c0300 	add	x0, x24, x28
    9d58:	97ffe27a 	bl	2740 <__memcpy_chk@plt>
    9d5c:	f9400f61 	ldr	x1, [x27, #24]
    9d60:	aa1803e0 	mov	x0, x24
    9d64:	f9400021 	ldr	x1, [x1]
    9d68:	d63f0020 	blr	x1
    9d6c:	aa0003f9 	mov	x25, x0
    9d70:	910002df 	mov	sp, x22
    9d74:	17ffff3b 	b	9a60 <fwp_hof0.constprop.0+0x720>
    9d78:	b90004df 	str	wzr, [x6, #4]
    9d7c:	17ffffa8 	b	9c1c <fwp_hof0.constprop.0+0x8dc>
    9d80:	72003c3f 	tst	w1, #0xffff
    9d84:	54ffbae1 	b.ne	94e0 <fwp_hof0.constprop.0+0x1a0>  // b.any
    9d88:	17fffdd0 	b	94c8 <fwp_hof0.constprop.0+0x188>
    9d8c:	f9400593 	ldr	x19, [x12, #8]
    9d90:	b4000113 	cbz	x19, 9db0 <fwp_hof0.constprop.0+0xa70>
    9d94:	f9400989 	ldr	x9, [x12, #16]
    9d98:	cb130129 	sub	x9, x9, x19
    9d9c:	eb09003f 	cmp	x1, x9
    9da0:	54000088 	b.hi	9db0 <fwp_hof0.constprop.0+0xa70>  // b.pmore
    9da4:	8b010269 	add	x9, x19, x1
    9da8:	f9000589 	str	x9, [x12, #8]
    9dac:	17ffff4c 	b	9adc <fwp_hof0.constprop.0+0x79c>
    9db0:	52800001 	mov	w1, #0x0                   	// #0
    9db4:	f81c03a6 	stur	x6, [x29, #-64]
    9db8:	b81d83a7 	stur	w7, [x29, #-40]
    9dbc:	97ffeb8d 	bl	4bf0 <fwp_heap_alloc>
    9dc0:	f85c03a6 	ldur	x6, [x29, #-64]
    9dc4:	aa0003f3 	mov	x19, x0
    9dc8:	b85d83a7 	ldur	w7, [x29, #-40]
    9dcc:	17ffff5b 	b	9b38 <fwp_hof0.constprop.0+0x7f8>
    9dd0:	72003c1f 	tst	w0, #0xffff
    9dd4:	54fff161 	b.ne	9c00 <fwp_hof0.constprop.0+0x8c0>  // b.any
    9dd8:	17ffff87 	b	9bf4 <fwp_hof0.constprop.0+0x8b4>
    9ddc:	72003c3f 	tst	w1, #0xffff
    9de0:	54fff5c1 	b.ne	9c98 <fwp_hof0.constprop.0+0x958>  // b.any
    9de4:	39400280 	ldrb	w0, [x20]
    9de8:	7103fc1f 	cmp	w0, #0xff
    9dec:	54fff521 	b.ne	9c90 <fwp_hof0.constprop.0+0x950>  // b.any
    9df0:	aa1403e0 	mov	x0, x20
    9df4:	b81d83a7 	stur	w7, [x29, #-40]
    9df8:	97ffe9be 	bl	44f0 <fwp_rc_forget_slot>
    9dfc:	b85d83a7 	ldur	w7, [x29, #-40]
    9e00:	17ffffa4 	b	9c90 <fwp_hof0.constprop.0+0x950>
    9e04:	97ffe974 	bl	43d4 <fwp_rc_wide_dup>
    9e08:	17fffdb6 	b	94e0 <fwp_hof0.constprop.0+0x1a0>
    9e0c:	f9400021 	ldr	x1, [x1]
    9e10:	aa1403e0 	mov	x0, x20
    9e14:	d63f0020 	blr	x1
    9e18:	aa0003f9 	mov	x25, x0
    9e1c:	910002df 	mov	sp, x22
    9e20:	17ffff10 	b	9a60 <fwp_hof0.constprop.0+0x720>
    9e24:	72003c3f 	tst	w1, #0xffff
    9e28:	54ffafa1 	b.ne	941c <fwp_hof0.constprop.0+0xdc>  // b.any
    9e2c:	17fffd76 	b	9404 <fwp_hof0.constprop.0+0xc4>
    9e30:	aa1a03e0 	mov	x0, x26
    9e34:	97ffedec 	bl	55e4 <fwp_rc_share>
    9e38:	aa1903e0 	mov	x0, x25
    9e3c:	52800037 	mov	w23, #0x1                   	// #1
    9e40:	97ffede9 	bl	55e4 <fwp_rc_share>
    9e44:	aa1a03f9 	mov	x25, x26
    9e48:	f81d03b4 	stur	x20, [x29, #-48]
    9e4c:	17ffff00 	b	9a4c <fwp_hof0.constprop.0+0x70c>
    9e50:	aa1303e0 	mov	x0, x19
    9e54:	97ffee3b 	bl	5740 <fwp_rc_free_arr>
    9e58:	f9400b5a 	ldr	x26, [x26, #16]
    9e5c:	b5ffaa1a 	cbnz	x26, 939c <fwp_hof0.constprop.0+0x5c>
    9e60:	17fffeb3 	b	992c <fwp_hof0.constprop.0+0x5ec>
    9e64:	72003c3f 	tst	w1, #0xffff
    9e68:	54ffd5e1 	b.ne	9924 <fwp_hof0.constprop.0+0x5e4>  // b.any
    9e6c:	17fffea6 	b	9904 <fwp_hof0.constprop.0+0x5c4>
    9e70:	72003c3f 	tst	w1, #0xffff
    9e74:	54ffcfa1 	b.ne	9868 <fwp_hof0.constprop.0+0x528>  // b.any
    9e78:	17fffe77 	b	9854 <fwp_hof0.constprop.0+0x514>
    9e7c:	ca5646c0 	eor	x0, x22, x22, lsr #17
    9e80:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc90>
    9e84:	91154021 	add	x1, x1, #0x550
    9e88:	ca402400 	eor	x0, x0, x0, lsr #9
    9e8c:	8b200c20 	add	x0, x1, w0, uxtb #3
    9e90:	f94a2400 	ldr	x0, [x0, #5192]
    9e94:	b5000080 	cbnz	x0, 9ea4 <fwp_hof0.constprop.0+0xb64>
    9e98:	14000011 	b	9edc <fwp_hof0.constprop.0+0xb9c>
    9e9c:	f9400800 	ldr	x0, [x0, #16]
    9ea0:	b40001e0 	cbz	x0, 9edc <fwp_hof0.constprop.0+0xb9c>
    9ea4:	f9400001 	ldr	x1, [x0]
    9ea8:	eb0102df 	cmp	x22, x1
    9eac:	54ffff81 	b.ne	9e9c <fwp_hof0.constprop.0+0xb5c>  // b.any
    9eb0:	f9400401 	ldr	x1, [x0, #8]
    9eb4:	d1000421 	sub	x1, x1, #0x1
    9eb8:	f9000401 	str	x1, [x0, #8]
    9ebc:	f103f83f 	cmp	x1, #0xfe
    9ec0:	54ffd321 	b.ne	9924 <fwp_hof0.constprop.0+0x5e4>  // b.any
    9ec4:	aa1603e0 	mov	x0, x22
    9ec8:	97ffe98a 	bl	44f0 <fwp_rc_forget_slot>
    9ecc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9ed0:	390002c0 	strb	w0, [x22]
    9ed4:	17fffe94 	b	9924 <fwp_hof0.constprop.0+0x5e4>
    9ed8:	97ffe436 	bl	2fb0 <fwp_heap_oom>
    9edc:	90000020 	adrp	x0, d000 <__modti3+0x1f0>
    9ee0:	91116000 	add	x0, x0, #0x458
    9ee4:	97ffe587 	bl	3500 <fwp_trap>
    9ee8:	90000020 	adrp	x0, d000 <__modti3+0x1f0>
    9eec:	911d4000 	add	x0, x0, #0x750
    9ef0:	97ffe584 	bl	3500 <fwp_trap>
    9ef4:	97ffe938 	bl	43d4 <fwp_rc_wide_dup>
    9ef8:	17fffd49 	b	941c <fwp_hof0.constprop.0+0xdc>
    9efc:	97ffe23d 	bl	27f0 <__stack_chk_fail@plt>
    9f00:	aa1903e0 	mov	x0, x25
    9f04:	97ffe97b 	bl	44f0 <fwp_rc_forget_slot>
    9f08:	17fffe56 	b	9860 <fwp_hof0.constprop.0+0x520>
    9f0c:	d503201f 	nop

0000000000009f10 <f0>:
    9f10:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9f14:	910003fd 	mov	x29, sp
    9f18:	a90153f3 	stp	x19, x20, [sp, #16]
    9f1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    9f20:	a90363f7 	stp	x23, x24, [sp, #48]
    9f24:	a9046bf9 	stp	x25, x26, [sp, #64]
    9f28:	a90573fb 	stp	x27, x28, [sp, #80]
    9f2c:	d12183ff 	sub	sp, sp, #0x860
    9f30:	f90203ff 	str	xzr, [sp, #1024]
    9f34:	f00000a0 	adrp	x0, 20000 <__data_start>
    9f38:	91010005 	add	x5, x0, #0x40
    9f3c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9f40:	f947f400 	ldr	x0, [x0, #4072]
    9f44:	90000154 	adrp	x20, 31000 <fwp_root_context+0xc90>
    9f48:	f94160a6 	ldr	x6, [x5, #704]
    9f4c:	f9400001 	ldr	x1, [x0]
    9f50:	f9042fe1 	str	x1, [sp, #2136]
    9f54:	d2800001 	mov	x1, #0x0                   	// #0
    9f58:	91154298 	add	x24, x20, #0x550
    9f5c:	912123f6 	add	x22, sp, #0x848
    9f60:	910023e0 	add	x0, sp, #0x8
    9f64:	910083e2 	add	x2, sp, #0x20
    9f68:	90ffffe1 	adrp	x1, 5000 <fwp_p_ad_push+0xdc>
    9f6c:	b0ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    9f70:	912a4021 	add	x1, x1, #0xa90
    9f74:	913b4084 	add	x4, x4, #0xed0
    9f78:	d2800013 	mov	x19, #0x0                   	// #0
    9f7c:	d2800119 	mov	x25, #0x8                   	// #8
    9f80:	d2800015 	mov	x21, #0x0                   	// #0
    9f84:	52800037 	mov	w23, #0x1                   	// #1
    9f88:	a90093e6 	stp	x6, x4, [sp, #8]
    9f8c:	a901ffe2 	stp	x2, xzr, [sp, #24]
    9f90:	a90307ff 	stp	xzr, x1, [sp, #48]
    9f94:	f90160a0 	str	x0, [x5, #704]
    9f98:	f100073a 	subs	x26, x25, #0x1
    9f9c:	aa1603e1 	mov	x1, x22
    9fa0:	da1f02bc 	sbc	x28, x21, xzr
    9fa4:	52800020 	mov	w0, #0x1                   	// #1
    9fa8:	f90017fa 	str	x26, [sp, #40]
    9fac:	aa1a03f9 	mov	x25, x26
    9fb0:	f90427fa 	str	x26, [sp, #2120]
    9fb4:	aa1c03f5 	mov	x21, x28
    9fb8:	f9042bf3 	str	x19, [sp, #2128]
    9fbc:	97ffed42 	bl	54c4 <fwp_data.part.0.constprop.0>
    9fc0:	f949db02 	ldr	x2, [x24, #5040]
    9fc4:	aa0003f3 	mov	x19, x0
    9fc8:	f949ef00 	ldr	x0, [x24, #5080]
    9fcc:	cb020262 	sub	x2, x19, x2
    9fd0:	eb00405f 	cmp	x2, x0, lsl #16
    9fd4:	54000302 	b.cs	a034 <f0+0x124>  // b.hs, b.nlast
    9fd8:	d350fc40 	lsr	x0, x2, #16
    9fdc:	f949ff04 	ldr	x4, [x24, #5112]
    9fe0:	8b000800 	add	x0, x0, x0, lsl #2
    9fe4:	d37df001 	lsl	x1, x0, #3
    9fe8:	8b010080 	add	x0, x4, x1
    9fec:	f940101b 	ldr	x27, [x0, #32]
    9ff0:	b400023b 	cbz	x27, a034 <f0+0x124>
    9ff4:	38616881 	ldrb	w1, [x4, x1]
    9ff8:	7100083f 	cmp	w1, #0x2
    9ffc:	54010ca0 	b.eq	c190 <f0+0x2280>  // b.none
    a000:	7100043f 	cmp	w1, #0x1
    a004:	54000181 	b.ne	a034 <f0+0x124>  // b.any
    a008:	29430001 	ldp	w1, w0, [x0, #24]
    a00c:	92403c42 	and	x2, x2, #0xffff
    a010:	9b017c42 	mul	x2, x2, x1
    a014:	d360fc42 	lsr	x2, x2, #32
    a018:	eb00005f 	cmp	x2, x0
    a01c:	540000c2 	b.cs	a034 <f0+0x124>  // b.hs, b.nlast
    a020:	8b02037b 	add	x27, x27, x2
    a024:	39400360 	ldrb	w0, [x27]
    a028:	7103fc1f 	cmp	w0, #0xff
    a02c:	54010ac0 	b.eq	c184 <f0+0x2274>  // b.none
    a030:	39000377 	strb	w23, [x27]
    a034:	f90013f3 	str	x19, [sp, #32]
    a038:	aa1c035a 	orr	x26, x26, x28
    a03c:	b5fffafa 	cbnz	x26, 9f98 <f0+0x88>
    a040:	f0000000 	adrp	x0, d000 <__modti3+0x1f0>
    a044:	910103e1 	add	x1, sp, #0x40
    a048:	f94007e2 	ldr	x2, [sp, #8]
    a04c:	3dc39c00 	ldr	q0, [x0, #3696]
    a050:	d00000a0 	adrp	x0, 20000 <__data_start>
    a054:	91010018 	add	x24, x0, #0x40
    a058:	52800020 	mov	w0, #0x1                   	// #1
    a05c:	3d8013e0 	str	q0, [sp, #64]
    a060:	f9016302 	str	x2, [x24, #704]
    a064:	97ffed18 	bl	54c4 <fwp_data.part.0.constprop.0>
    a068:	91154283 	add	x3, x20, #0x550
    a06c:	aa0003f5 	mov	x21, x0
    a070:	f949d861 	ldr	x1, [x3, #5040]
    a074:	f949ec60 	ldr	x0, [x3, #5080]
    a078:	cb0102a1 	sub	x1, x21, x1
    a07c:	eb00403f 	cmp	x1, x0, lsl #16
    a080:	54000322 	b.cs	a0e4 <f0+0x1d4>  // b.hs, b.nlast
    a084:	d350fc22 	lsr	x2, x1, #16
    a088:	f949fc63 	ldr	x3, [x3, #5112]
    a08c:	8b020842 	add	x2, x2, x2, lsl #2
    a090:	d37df042 	lsl	x2, x2, #3
    a094:	8b020060 	add	x0, x3, x2
    a098:	f9401017 	ldr	x23, [x0, #32]
    a09c:	b4000257 	cbz	x23, a0e4 <f0+0x1d4>
    a0a0:	38626862 	ldrb	w2, [x3, x2]
    a0a4:	7100085f 	cmp	w2, #0x2
    a0a8:	54010b60 	b.eq	c214 <f0+0x2304>  // b.none
    a0ac:	7100045f 	cmp	w2, #0x1
    a0b0:	540001a1 	b.ne	a0e4 <f0+0x1d4>  // b.any
    a0b4:	29430002 	ldp	w2, w0, [x0, #24]
    a0b8:	92403c21 	and	x1, x1, #0xffff
    a0bc:	9b027c21 	mul	x1, x1, x2
    a0c0:	d360fc21 	lsr	x1, x1, #32
    a0c4:	eb00003f 	cmp	x1, x0
    a0c8:	540000e2 	b.cs	a0e4 <f0+0x1d4>  // b.hs, b.nlast
    a0cc:	8b0102f7 	add	x23, x23, x1
    a0d0:	394002e0 	ldrb	w0, [x23]
    a0d4:	7103fc1f 	cmp	w0, #0xff
    a0d8:	54011520 	b.eq	c37c <f0+0x246c>  // b.none
    a0dc:	52800020 	mov	w0, #0x1                   	// #1
    a0e0:	390002e0 	strb	w0, [x23]
    a0e4:	910163e1 	add	x1, sp, #0x58
    a0e8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a0ec:	52800020 	mov	w0, #0x1                   	// #1
    a0f0:	a905d7f7 	stp	x23, x21, [sp, #88]
    a0f4:	97ffecf4 	bl	54c4 <fwp_data.part.0.constprop.0>
    a0f8:	97ffed62 	bl	5680 <fwp_rc_fresh>
    a0fc:	aa0003e2 	mov	x2, x0
    a100:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a104:	9101a3e1 	add	x1, sp, #0x68
    a108:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a10c:	52800020 	mov	w0, #0x1                   	// #1
    a110:	a9068be3 	stp	x3, x2, [sp, #104]
    a114:	97ffecec 	bl	54c4 <fwp_data.part.0.constprop.0>
    a118:	97ffed5a 	bl	5680 <fwp_rc_fresh>
    a11c:	aa0003e2 	mov	x2, x0
    a120:	9101e3e1 	add	x1, sp, #0x78
    a124:	52800020 	mov	w0, #0x1                   	// #1
    a128:	a9078bf7 	stp	x23, x2, [sp, #120]
    a12c:	97ffece6 	bl	54c4 <fwp_data.part.0.constprop.0>
    a130:	91154283 	add	x3, x20, #0x550
    a134:	aa0003f5 	mov	x21, x0
    a138:	f949d861 	ldr	x1, [x3, #5040]
    a13c:	f949ec60 	ldr	x0, [x3, #5080]
    a140:	cb0102a1 	sub	x1, x21, x1
    a144:	eb00403f 	cmp	x1, x0, lsl #16
    a148:	54000322 	b.cs	a1ac <f0+0x29c>  // b.hs, b.nlast
    a14c:	d350fc22 	lsr	x2, x1, #16
    a150:	f949fc63 	ldr	x3, [x3, #5112]
    a154:	8b020842 	add	x2, x2, x2, lsl #2
    a158:	d37df042 	lsl	x2, x2, #3
    a15c:	8b020060 	add	x0, x3, x2
    a160:	f9401017 	ldr	x23, [x0, #32]
    a164:	b4000257 	cbz	x23, a1ac <f0+0x29c>
    a168:	38626862 	ldrb	w2, [x3, x2]
    a16c:	7100085f 	cmp	w2, #0x2
    a170:	540104c0 	b.eq	c208 <f0+0x22f8>  // b.none
    a174:	7100045f 	cmp	w2, #0x1
    a178:	540001a1 	b.ne	a1ac <f0+0x29c>  // b.any
    a17c:	29430002 	ldp	w2, w0, [x0, #24]
    a180:	92403c21 	and	x1, x1, #0xffff
    a184:	9b027c21 	mul	x1, x1, x2
    a188:	d360fc21 	lsr	x1, x1, #32
    a18c:	eb00003f 	cmp	x1, x0
    a190:	540000e2 	b.cs	a1ac <f0+0x29c>  // b.hs, b.nlast
    a194:	8b0102f7 	add	x23, x23, x1
    a198:	394002e0 	ldrb	w0, [x23]
    a19c:	7103fc1f 	cmp	w0, #0xff
    a1a0:	54010f40 	b.eq	c388 <f0+0x2478>  // b.none
    a1a4:	52800020 	mov	w0, #0x1                   	// #1
    a1a8:	390002e0 	strb	w0, [x23]
    a1ac:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a1b0:	910223e1 	add	x1, sp, #0x88
    a1b4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a1b8:	52800020 	mov	w0, #0x1                   	// #1
    a1bc:	a908d7e2 	stp	x2, x21, [sp, #136]
    a1c0:	97ffecc1 	bl	54c4 <fwp_data.part.0.constprop.0>
    a1c4:	91154283 	add	x3, x20, #0x550
    a1c8:	aa0003f5 	mov	x21, x0
    a1cc:	f949d861 	ldr	x1, [x3, #5040]
    a1d0:	f949ec60 	ldr	x0, [x3, #5080]
    a1d4:	cb0102a1 	sub	x1, x21, x1
    a1d8:	eb00403f 	cmp	x1, x0, lsl #16
    a1dc:	54000322 	b.cs	a240 <f0+0x330>  // b.hs, b.nlast
    a1e0:	d350fc22 	lsr	x2, x1, #16
    a1e4:	f949fc63 	ldr	x3, [x3, #5112]
    a1e8:	8b020842 	add	x2, x2, x2, lsl #2
    a1ec:	d37df042 	lsl	x2, x2, #3
    a1f0:	8b020060 	add	x0, x3, x2
    a1f4:	f9401017 	ldr	x23, [x0, #32]
    a1f8:	b4000257 	cbz	x23, a240 <f0+0x330>
    a1fc:	38626862 	ldrb	w2, [x3, x2]
    a200:	7100085f 	cmp	w2, #0x2
    a204:	5400ffc0 	b.eq	c1fc <f0+0x22ec>  // b.none
    a208:	7100045f 	cmp	w2, #0x1
    a20c:	540001a1 	b.ne	a240 <f0+0x330>  // b.any
    a210:	29430002 	ldp	w2, w0, [x0, #24]
    a214:	92403c21 	and	x1, x1, #0xffff
    a218:	9b027c21 	mul	x1, x1, x2
    a21c:	d360fc21 	lsr	x1, x1, #32
    a220:	eb00003f 	cmp	x1, x0
    a224:	540000e2 	b.cs	a240 <f0+0x330>  // b.hs, b.nlast
    a228:	8b0102f7 	add	x23, x23, x1
    a22c:	394002e0 	ldrb	w0, [x23]
    a230:	7103fc1f 	cmp	w0, #0xff
    a234:	54010b00 	b.eq	c394 <f0+0x2484>  // b.none
    a238:	52800020 	mov	w0, #0x1                   	// #1
    a23c:	390002e0 	strb	w0, [x23]
    a240:	910263e1 	add	x1, sp, #0x98
    a244:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a248:	52800020 	mov	w0, #0x1                   	// #1
    a24c:	a909d7e2 	stp	x2, x21, [sp, #152]
    a250:	97ffec9d 	bl	54c4 <fwp_data.part.0.constprop.0>
    a254:	97ffed0b 	bl	5680 <fwp_rc_fresh>
    a258:	aa0003e2 	mov	x2, x0
    a25c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a260:	9102a3e1 	add	x1, sp, #0xa8
    a264:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a268:	52800020 	mov	w0, #0x1                   	// #1
    a26c:	a90a8be3 	stp	x3, x2, [sp, #168]
    a270:	97ffec95 	bl	54c4 <fwp_data.part.0.constprop.0>
    a274:	91154283 	add	x3, x20, #0x550
    a278:	aa0003f5 	mov	x21, x0
    a27c:	f949d861 	ldr	x1, [x3, #5040]
    a280:	f949ec60 	ldr	x0, [x3, #5080]
    a284:	cb0102a1 	sub	x1, x21, x1
    a288:	eb00403f 	cmp	x1, x0, lsl #16
    a28c:	54000322 	b.cs	a2f0 <f0+0x3e0>  // b.hs, b.nlast
    a290:	d350fc22 	lsr	x2, x1, #16
    a294:	f949fc63 	ldr	x3, [x3, #5112]
    a298:	8b020842 	add	x2, x2, x2, lsl #2
    a29c:	d37df042 	lsl	x2, x2, #3
    a2a0:	8b020060 	add	x0, x3, x2
    a2a4:	f9401017 	ldr	x23, [x0, #32]
    a2a8:	b4000257 	cbz	x23, a2f0 <f0+0x3e0>
    a2ac:	38626862 	ldrb	w2, [x3, x2]
    a2b0:	7100085f 	cmp	w2, #0x2
    a2b4:	5400fc80 	b.eq	c244 <f0+0x2334>  // b.none
    a2b8:	7100045f 	cmp	w2, #0x1
    a2bc:	540001a1 	b.ne	a2f0 <f0+0x3e0>  // b.any
    a2c0:	29430002 	ldp	w2, w0, [x0, #24]
    a2c4:	92403c21 	and	x1, x1, #0xffff
    a2c8:	9b027c21 	mul	x1, x1, x2
    a2cc:	d360fc21 	lsr	x1, x1, #32
    a2d0:	eb00003f 	cmp	x1, x0
    a2d4:	540000e2 	b.cs	a2f0 <f0+0x3e0>  // b.hs, b.nlast
    a2d8:	8b0102f7 	add	x23, x23, x1
    a2dc:	394002e0 	ldrb	w0, [x23]
    a2e0:	7103fc1f 	cmp	w0, #0xff
    a2e4:	540105e0 	b.eq	c3a0 <f0+0x2490>  // b.none
    a2e8:	52800020 	mov	w0, #0x1                   	// #1
    a2ec:	390002e0 	strb	w0, [x23]
    a2f0:	9102e3e1 	add	x1, sp, #0xb8
    a2f4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a2f8:	52800020 	mov	w0, #0x1                   	// #1
    a2fc:	a90bd7f7 	stp	x23, x21, [sp, #184]
    a300:	97ffec71 	bl	54c4 <fwp_data.part.0.constprop.0>
    a304:	97ffecdf 	bl	5680 <fwp_rc_fresh>
    a308:	aa0003e2 	mov	x2, x0
    a30c:	910323e1 	add	x1, sp, #0xc8
    a310:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a314:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a318:	52800020 	mov	w0, #0x1                   	// #1
    a31c:	a90c8bf5 	stp	x21, x2, [sp, #200]
    a320:	97ffec69 	bl	54c4 <fwp_data.part.0.constprop.0>
    a324:	97ffecd7 	bl	5680 <fwp_rc_fresh>
    a328:	aa0003e2 	mov	x2, x0
    a32c:	910363e1 	add	x1, sp, #0xd8
    a330:	52800020 	mov	w0, #0x1                   	// #1
    a334:	a90d8bf7 	stp	x23, x2, [sp, #216]
    a338:	97ffec63 	bl	54c4 <fwp_data.part.0.constprop.0>
    a33c:	97ffecd1 	bl	5680 <fwp_rc_fresh>
    a340:	aa0003e2 	mov	x2, x0
    a344:	9103a3e1 	add	x1, sp, #0xe8
    a348:	52800020 	mov	w0, #0x1                   	// #1
    a34c:	a90e8bf5 	stp	x21, x2, [sp, #232]
    a350:	97ffec5d 	bl	54c4 <fwp_data.part.0.constprop.0>
    a354:	97ffeccb 	bl	5680 <fwp_rc_fresh>
    a358:	aa0003e2 	mov	x2, x0
    a35c:	9103e3e1 	add	x1, sp, #0xf8
    a360:	52800020 	mov	w0, #0x1                   	// #1
    a364:	a90f8bf7 	stp	x23, x2, [sp, #248]
    a368:	97ffec57 	bl	54c4 <fwp_data.part.0.constprop.0>
    a36c:	97ffecc5 	bl	5680 <fwp_rc_fresh>
    a370:	aa0003e2 	mov	x2, x0
    a374:	910423e1 	add	x1, sp, #0x108
    a378:	52800020 	mov	w0, #0x1                   	// #1
    a37c:	a9108bf5 	stp	x21, x2, [sp, #264]
    a380:	97ffec51 	bl	54c4 <fwp_data.part.0.constprop.0>
    a384:	97ffecbf 	bl	5680 <fwp_rc_fresh>
    a388:	aa0003e2 	mov	x2, x0
    a38c:	910463e1 	add	x1, sp, #0x118
    a390:	52800020 	mov	w0, #0x1                   	// #1
    a394:	a9118bf7 	stp	x23, x2, [sp, #280]
    a398:	97ffec4b 	bl	54c4 <fwp_data.part.0.constprop.0>
    a39c:	97ffecb9 	bl	5680 <fwp_rc_fresh>
    a3a0:	aa0003e2 	mov	x2, x0
    a3a4:	9104a3e1 	add	x1, sp, #0x128
    a3a8:	52800020 	mov	w0, #0x1                   	// #1
    a3ac:	a9128bf5 	stp	x21, x2, [sp, #296]
    a3b0:	97ffec45 	bl	54c4 <fwp_data.part.0.constprop.0>
    a3b4:	97ffecb3 	bl	5680 <fwp_rc_fresh>
    a3b8:	aa0003e2 	mov	x2, x0
    a3bc:	9104e3e1 	add	x1, sp, #0x138
    a3c0:	52800020 	mov	w0, #0x1                   	// #1
    a3c4:	a9138bf7 	stp	x23, x2, [sp, #312]
    a3c8:	97ffec3f 	bl	54c4 <fwp_data.part.0.constprop.0>
    a3cc:	97ffecad 	bl	5680 <fwp_rc_fresh>
    a3d0:	aa0003e2 	mov	x2, x0
    a3d4:	910523e1 	add	x1, sp, #0x148
    a3d8:	52800020 	mov	w0, #0x1                   	// #1
    a3dc:	a9148bf5 	stp	x21, x2, [sp, #328]
    a3e0:	97ffec39 	bl	54c4 <fwp_data.part.0.constprop.0>
    a3e4:	91154283 	add	x3, x20, #0x550
    a3e8:	aa0003f5 	mov	x21, x0
    a3ec:	f949d861 	ldr	x1, [x3, #5040]
    a3f0:	f949ec60 	ldr	x0, [x3, #5080]
    a3f4:	cb0102a1 	sub	x1, x21, x1
    a3f8:	eb00403f 	cmp	x1, x0, lsl #16
    a3fc:	54000322 	b.cs	a460 <f0+0x550>  // b.hs, b.nlast
    a400:	d350fc22 	lsr	x2, x1, #16
    a404:	f949fc63 	ldr	x3, [x3, #5112]
    a408:	8b020842 	add	x2, x2, x2, lsl #2
    a40c:	d37df042 	lsl	x2, x2, #3
    a410:	8b020060 	add	x0, x3, x2
    a414:	f9401017 	ldr	x23, [x0, #32]
    a418:	b4000257 	cbz	x23, a460 <f0+0x550>
    a41c:	38626862 	ldrb	w2, [x3, x2]
    a420:	7100085f 	cmp	w2, #0x2
    a424:	5400f0a0 	b.eq	c238 <f0+0x2328>  // b.none
    a428:	7100045f 	cmp	w2, #0x1
    a42c:	540001a1 	b.ne	a460 <f0+0x550>  // b.any
    a430:	29430002 	ldp	w2, w0, [x0, #24]
    a434:	92403c21 	and	x1, x1, #0xffff
    a438:	9b027c21 	mul	x1, x1, x2
    a43c:	d360fc21 	lsr	x1, x1, #32
    a440:	eb00003f 	cmp	x1, x0
    a444:	540000e2 	b.cs	a460 <f0+0x550>  // b.hs, b.nlast
    a448:	8b0102f7 	add	x23, x23, x1
    a44c:	394002e0 	ldrb	w0, [x23]
    a450:	7103fc1f 	cmp	w0, #0xff
    a454:	5400fac0 	b.eq	c3ac <f0+0x249c>  // b.none
    a458:	52800020 	mov	w0, #0x1                   	// #1
    a45c:	390002e0 	strb	w0, [x23]
    a460:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a464:	910563e1 	add	x1, sp, #0x158
    a468:	52800020 	mov	w0, #0x1                   	// #1
    a46c:	a915d7e2 	stp	x2, x21, [sp, #344]
    a470:	97ffec15 	bl	54c4 <fwp_data.part.0.constprop.0>
    a474:	91154283 	add	x3, x20, #0x550
    a478:	aa0003f5 	mov	x21, x0
    a47c:	f949d861 	ldr	x1, [x3, #5040]
    a480:	f949ec60 	ldr	x0, [x3, #5080]
    a484:	cb0102a1 	sub	x1, x21, x1
    a488:	eb00403f 	cmp	x1, x0, lsl #16
    a48c:	54000322 	b.cs	a4f0 <f0+0x5e0>  // b.hs, b.nlast
    a490:	d350fc22 	lsr	x2, x1, #16
    a494:	f949fc63 	ldr	x3, [x3, #5112]
    a498:	8b020842 	add	x2, x2, x2, lsl #2
    a49c:	d37df042 	lsl	x2, x2, #3
    a4a0:	8b020060 	add	x0, x3, x2
    a4a4:	f9401017 	ldr	x23, [x0, #32]
    a4a8:	b4000257 	cbz	x23, a4f0 <f0+0x5e0>
    a4ac:	38626862 	ldrb	w2, [x3, x2]
    a4b0:	7100085f 	cmp	w2, #0x2
    a4b4:	5400ebc0 	b.eq	c22c <f0+0x231c>  // b.none
    a4b8:	7100045f 	cmp	w2, #0x1
    a4bc:	540001a1 	b.ne	a4f0 <f0+0x5e0>  // b.any
    a4c0:	29430002 	ldp	w2, w0, [x0, #24]
    a4c4:	92403c21 	and	x1, x1, #0xffff
    a4c8:	9b027c21 	mul	x1, x1, x2
    a4cc:	d360fc21 	lsr	x1, x1, #32
    a4d0:	eb00003f 	cmp	x1, x0
    a4d4:	540000e2 	b.cs	a4f0 <f0+0x5e0>  // b.hs, b.nlast
    a4d8:	8b0102f7 	add	x23, x23, x1
    a4dc:	394002e0 	ldrb	w0, [x23]
    a4e0:	7103fc1f 	cmp	w0, #0xff
    a4e4:	5400f6a0 	b.eq	c3b8 <f0+0x24a8>  // b.none
    a4e8:	52800020 	mov	w0, #0x1                   	// #1
    a4ec:	390002e0 	strb	w0, [x23]
    a4f0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a4f4:	9105a3e1 	add	x1, sp, #0x168
    a4f8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a4fc:	52800020 	mov	w0, #0x1                   	// #1
    a500:	a916d7e2 	stp	x2, x21, [sp, #360]
    a504:	97ffebf0 	bl	54c4 <fwp_data.part.0.constprop.0>
    a508:	97ffec5e 	bl	5680 <fwp_rc_fresh>
    a50c:	aa0003e2 	mov	x2, x0
    a510:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a514:	9105e3e1 	add	x1, sp, #0x178
    a518:	52800020 	mov	w0, #0x1                   	// #1
    a51c:	a9178be3 	stp	x3, x2, [sp, #376]
    a520:	97ffebe9 	bl	54c4 <fwp_data.part.0.constprop.0>
    a524:	91154283 	add	x3, x20, #0x550
    a528:	aa0003f5 	mov	x21, x0
    a52c:	f949d861 	ldr	x1, [x3, #5040]
    a530:	f949ec60 	ldr	x0, [x3, #5080]
    a534:	cb0102a1 	sub	x1, x21, x1
    a538:	eb00403f 	cmp	x1, x0, lsl #16
    a53c:	54000322 	b.cs	a5a0 <f0+0x690>  // b.hs, b.nlast
    a540:	d350fc22 	lsr	x2, x1, #16
    a544:	f949fc63 	ldr	x3, [x3, #5112]
    a548:	8b020842 	add	x2, x2, x2, lsl #2
    a54c:	d37df042 	lsl	x2, x2, #3
    a550:	8b020060 	add	x0, x3, x2
    a554:	f9401017 	ldr	x23, [x0, #32]
    a558:	b4000257 	cbz	x23, a5a0 <f0+0x690>
    a55c:	38626862 	ldrb	w2, [x3, x2]
    a560:	7100085f 	cmp	w2, #0x2
    a564:	5400e5e0 	b.eq	c220 <f0+0x2310>  // b.none
    a568:	7100045f 	cmp	w2, #0x1
    a56c:	540001a1 	b.ne	a5a0 <f0+0x690>  // b.any
    a570:	29430002 	ldp	w2, w0, [x0, #24]
    a574:	92403c21 	and	x1, x1, #0xffff
    a578:	9b027c21 	mul	x1, x1, x2
    a57c:	d360fc21 	lsr	x1, x1, #32
    a580:	eb00003f 	cmp	x1, x0
    a584:	540000e2 	b.cs	a5a0 <f0+0x690>  // b.hs, b.nlast
    a588:	8b0102f7 	add	x23, x23, x1
    a58c:	394002e0 	ldrb	w0, [x23]
    a590:	7103fc1f 	cmp	w0, #0xff
    a594:	5400f180 	b.eq	c3c4 <f0+0x24b4>  // b.none
    a598:	52800020 	mov	w0, #0x1                   	// #1
    a59c:	390002e0 	strb	w0, [x23]
    a5a0:	910623e1 	add	x1, sp, #0x188
    a5a4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a5a8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a5ac:	52800020 	mov	w0, #0x1                   	// #1
    a5b0:	a918d7f7 	stp	x23, x21, [sp, #392]
    a5b4:	97ffebc4 	bl	54c4 <fwp_data.part.0.constprop.0>
    a5b8:	97ffec32 	bl	5680 <fwp_rc_fresh>
    a5bc:	aa0003e2 	mov	x2, x0
    a5c0:	910663e1 	add	x1, sp, #0x198
    a5c4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a5c8:	52800020 	mov	w0, #0x1                   	// #1
    a5cc:	a9198bf5 	stp	x21, x2, [sp, #408]
    a5d0:	97ffebbd 	bl	54c4 <fwp_data.part.0.constprop.0>
    a5d4:	97ffec2b 	bl	5680 <fwp_rc_fresh>
    a5d8:	aa0003e2 	mov	x2, x0
    a5dc:	9106a3e1 	add	x1, sp, #0x1a8
    a5e0:	52800020 	mov	w0, #0x1                   	// #1
    a5e4:	a91a8bf7 	stp	x23, x2, [sp, #424]
    a5e8:	97ffebb7 	bl	54c4 <fwp_data.part.0.constprop.0>
    a5ec:	97ffec25 	bl	5680 <fwp_rc_fresh>
    a5f0:	aa0003e2 	mov	x2, x0
    a5f4:	9106e3e1 	add	x1, sp, #0x1b8
    a5f8:	52800020 	mov	w0, #0x1                   	// #1
    a5fc:	a91b8bf5 	stp	x21, x2, [sp, #440]
    a600:	97ffebb1 	bl	54c4 <fwp_data.part.0.constprop.0>
    a604:	91154283 	add	x3, x20, #0x550
    a608:	aa0003f5 	mov	x21, x0
    a60c:	f949d861 	ldr	x1, [x3, #5040]
    a610:	f949ec60 	ldr	x0, [x3, #5080]
    a614:	cb0102a1 	sub	x1, x21, x1
    a618:	eb00403f 	cmp	x1, x0, lsl #16
    a61c:	54000322 	b.cs	a680 <f0+0x770>  // b.hs, b.nlast
    a620:	d350fc22 	lsr	x2, x1, #16
    a624:	f949fc63 	ldr	x3, [x3, #5112]
    a628:	8b020842 	add	x2, x2, x2, lsl #2
    a62c:	d37df042 	lsl	x2, x2, #3
    a630:	8b020060 	add	x0, x3, x2
    a634:	f9401017 	ldr	x23, [x0, #32]
    a638:	b4000257 	cbz	x23, a680 <f0+0x770>
    a63c:	38626862 	ldrb	w2, [x3, x2]
    a640:	7100085f 	cmp	w2, #0x2
    a644:	5400e300 	b.eq	c2a4 <f0+0x2394>  // b.none
    a648:	7100045f 	cmp	w2, #0x1
    a64c:	540001a1 	b.ne	a680 <f0+0x770>  // b.any
    a650:	29430002 	ldp	w2, w0, [x0, #24]
    a654:	92403c21 	and	x1, x1, #0xffff
    a658:	9b027c21 	mul	x1, x1, x2
    a65c:	d360fc21 	lsr	x1, x1, #32
    a660:	eb00003f 	cmp	x1, x0
    a664:	540000e2 	b.cs	a680 <f0+0x770>  // b.hs, b.nlast
    a668:	8b0102f7 	add	x23, x23, x1
    a66c:	394002e0 	ldrb	w0, [x23]
    a670:	7103fc1f 	cmp	w0, #0xff
    a674:	5400eae0 	b.eq	c3d0 <f0+0x24c0>  // b.none
    a678:	52800020 	mov	w0, #0x1                   	// #1
    a67c:	390002e0 	strb	w0, [x23]
    a680:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a684:	910723e1 	add	x1, sp, #0x1c8
    a688:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a68c:	52800020 	mov	w0, #0x1                   	// #1
    a690:	a91cd7e2 	stp	x2, x21, [sp, #456]
    a694:	97ffeb8c 	bl	54c4 <fwp_data.part.0.constprop.0>
    a698:	91154283 	add	x3, x20, #0x550
    a69c:	aa0003f5 	mov	x21, x0
    a6a0:	f949d861 	ldr	x1, [x3, #5040]
    a6a4:	f949ec60 	ldr	x0, [x3, #5080]
    a6a8:	cb0102a1 	sub	x1, x21, x1
    a6ac:	eb00403f 	cmp	x1, x0, lsl #16
    a6b0:	54000322 	b.cs	a714 <f0+0x804>  // b.hs, b.nlast
    a6b4:	d350fc22 	lsr	x2, x1, #16
    a6b8:	f949fc63 	ldr	x3, [x3, #5112]
    a6bc:	8b020842 	add	x2, x2, x2, lsl #2
    a6c0:	d37df042 	lsl	x2, x2, #3
    a6c4:	8b020060 	add	x0, x3, x2
    a6c8:	f9401017 	ldr	x23, [x0, #32]
    a6cc:	b4000257 	cbz	x23, a714 <f0+0x804>
    a6d0:	38626862 	ldrb	w2, [x3, x2]
    a6d4:	7100085f 	cmp	w2, #0x2
    a6d8:	5400de00 	b.eq	c298 <f0+0x2388>  // b.none
    a6dc:	7100045f 	cmp	w2, #0x1
    a6e0:	540001a1 	b.ne	a714 <f0+0x804>  // b.any
    a6e4:	29430002 	ldp	w2, w0, [x0, #24]
    a6e8:	92403c21 	and	x1, x1, #0xffff
    a6ec:	9b027c21 	mul	x1, x1, x2
    a6f0:	d360fc21 	lsr	x1, x1, #32
    a6f4:	eb00003f 	cmp	x1, x0
    a6f8:	540000e2 	b.cs	a714 <f0+0x804>  // b.hs, b.nlast
    a6fc:	8b0102f7 	add	x23, x23, x1
    a700:	394002e0 	ldrb	w0, [x23]
    a704:	7103fc1f 	cmp	w0, #0xff
    a708:	5400e6a0 	b.eq	c3dc <f0+0x24cc>  // b.none
    a70c:	52800020 	mov	w0, #0x1                   	// #1
    a710:	390002e0 	strb	w0, [x23]
    a714:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a718:	910763e1 	add	x1, sp, #0x1d8
    a71c:	52800020 	mov	w0, #0x1                   	// #1
    a720:	a91dd7e2 	stp	x2, x21, [sp, #472]
    a724:	97ffeb68 	bl	54c4 <fwp_data.part.0.constprop.0>
    a728:	91154283 	add	x3, x20, #0x550
    a72c:	aa0003f5 	mov	x21, x0
    a730:	f949d861 	ldr	x1, [x3, #5040]
    a734:	f949ec60 	ldr	x0, [x3, #5080]
    a738:	cb0102a1 	sub	x1, x21, x1
    a73c:	eb00403f 	cmp	x1, x0, lsl #16
    a740:	54000322 	b.cs	a7a4 <f0+0x894>  // b.hs, b.nlast
    a744:	d350fc22 	lsr	x2, x1, #16
    a748:	f949fc63 	ldr	x3, [x3, #5112]
    a74c:	8b020842 	add	x2, x2, x2, lsl #2
    a750:	d37df042 	lsl	x2, x2, #3
    a754:	8b020060 	add	x0, x3, x2
    a758:	f9401017 	ldr	x23, [x0, #32]
    a75c:	b4000257 	cbz	x23, a7a4 <f0+0x894>
    a760:	38626862 	ldrb	w2, [x3, x2]
    a764:	7100085f 	cmp	w2, #0x2
    a768:	5400d920 	b.eq	c28c <f0+0x237c>  // b.none
    a76c:	7100045f 	cmp	w2, #0x1
    a770:	540001a1 	b.ne	a7a4 <f0+0x894>  // b.any
    a774:	29430002 	ldp	w2, w0, [x0, #24]
    a778:	92403c21 	and	x1, x1, #0xffff
    a77c:	9b027c21 	mul	x1, x1, x2
    a780:	d360fc21 	lsr	x1, x1, #32
    a784:	eb00003f 	cmp	x1, x0
    a788:	540000e2 	b.cs	a7a4 <f0+0x894>  // b.hs, b.nlast
    a78c:	8b0102f7 	add	x23, x23, x1
    a790:	394002e0 	ldrb	w0, [x23]
    a794:	7103fc1f 	cmp	w0, #0xff
    a798:	5400e280 	b.eq	c3e8 <f0+0x24d8>  // b.none
    a79c:	52800020 	mov	w0, #0x1                   	// #1
    a7a0:	390002e0 	strb	w0, [x23]
    a7a4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a7a8:	9107a3e1 	add	x1, sp, #0x1e8
    a7ac:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a7b0:	52800020 	mov	w0, #0x1                   	// #1
    a7b4:	a91ed7e2 	stp	x2, x21, [sp, #488]
    a7b8:	97ffeb43 	bl	54c4 <fwp_data.part.0.constprop.0>
    a7bc:	97ffebb1 	bl	5680 <fwp_rc_fresh>
    a7c0:	aa0003e2 	mov	x2, x0
    a7c4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a7c8:	9107e3e1 	add	x1, sp, #0x1f8
    a7cc:	52800020 	mov	w0, #0x1                   	// #1
    a7d0:	a91f8be3 	stp	x3, x2, [sp, #504]
    a7d4:	97ffeb3c 	bl	54c4 <fwp_data.part.0.constprop.0>
    a7d8:	91154283 	add	x3, x20, #0x550
    a7dc:	aa0003f5 	mov	x21, x0
    a7e0:	f949d861 	ldr	x1, [x3, #5040]
    a7e4:	f949ec60 	ldr	x0, [x3, #5080]
    a7e8:	cb0102a1 	sub	x1, x21, x1
    a7ec:	eb00403f 	cmp	x1, x0, lsl #16
    a7f0:	54000322 	b.cs	a854 <f0+0x944>  // b.hs, b.nlast
    a7f4:	d350fc22 	lsr	x2, x1, #16
    a7f8:	f949fc63 	ldr	x3, [x3, #5112]
    a7fc:	8b020842 	add	x2, x2, x2, lsl #2
    a800:	d37df042 	lsl	x2, x2, #3
    a804:	8b020060 	add	x0, x3, x2
    a808:	f9401017 	ldr	x23, [x0, #32]
    a80c:	b4000257 	cbz	x23, a854 <f0+0x944>
    a810:	38626862 	ldrb	w2, [x3, x2]
    a814:	7100085f 	cmp	w2, #0x2
    a818:	5400d340 	b.eq	c280 <f0+0x2370>  // b.none
    a81c:	7100045f 	cmp	w2, #0x1
    a820:	540001a1 	b.ne	a854 <f0+0x944>  // b.any
    a824:	29430002 	ldp	w2, w0, [x0, #24]
    a828:	92403c21 	and	x1, x1, #0xffff
    a82c:	9b027c21 	mul	x1, x1, x2
    a830:	d360fc21 	lsr	x1, x1, #32
    a834:	eb00003f 	cmp	x1, x0
    a838:	540000e2 	b.cs	a854 <f0+0x944>  // b.hs, b.nlast
    a83c:	8b0102f7 	add	x23, x23, x1
    a840:	394002e0 	ldrb	w0, [x23]
    a844:	7103fc1f 	cmp	w0, #0xff
    a848:	5400dd60 	b.eq	c3f4 <f0+0x24e4>  // b.none
    a84c:	52800020 	mov	w0, #0x1                   	// #1
    a850:	390002e0 	strb	w0, [x23]
    a854:	910823e1 	add	x1, sp, #0x208
    a858:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a85c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a860:	52800020 	mov	w0, #0x1                   	// #1
    a864:	f90107f7 	str	x23, [sp, #520]
    a868:	f9010bf5 	str	x21, [sp, #528]
    a86c:	97ffeb16 	bl	54c4 <fwp_data.part.0.constprop.0>
    a870:	97ffeb84 	bl	5680 <fwp_rc_fresh>
    a874:	aa0003e2 	mov	x2, x0
    a878:	910863e1 	add	x1, sp, #0x218
    a87c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a880:	52800020 	mov	w0, #0x1                   	// #1
    a884:	f9010ff5 	str	x21, [sp, #536]
    a888:	f90113e2 	str	x2, [sp, #544]
    a88c:	97ffeb0e 	bl	54c4 <fwp_data.part.0.constprop.0>
    a890:	97ffeb7c 	bl	5680 <fwp_rc_fresh>
    a894:	aa0003e2 	mov	x2, x0
    a898:	9108a3e1 	add	x1, sp, #0x228
    a89c:	52800020 	mov	w0, #0x1                   	// #1
    a8a0:	f90117f7 	str	x23, [sp, #552]
    a8a4:	f9011be2 	str	x2, [sp, #560]
    a8a8:	97ffeb07 	bl	54c4 <fwp_data.part.0.constprop.0>
    a8ac:	97ffeb75 	bl	5680 <fwp_rc_fresh>
    a8b0:	aa0003e2 	mov	x2, x0
    a8b4:	9108e3e1 	add	x1, sp, #0x238
    a8b8:	52800020 	mov	w0, #0x1                   	// #1
    a8bc:	f9011ff5 	str	x21, [sp, #568]
    a8c0:	f90123e2 	str	x2, [sp, #576]
    a8c4:	97ffeb00 	bl	54c4 <fwp_data.part.0.constprop.0>
    a8c8:	91154283 	add	x3, x20, #0x550
    a8cc:	aa0003f5 	mov	x21, x0
    a8d0:	f949d861 	ldr	x1, [x3, #5040]
    a8d4:	f949ec60 	ldr	x0, [x3, #5080]
    a8d8:	cb0102a1 	sub	x1, x21, x1
    a8dc:	eb00403f 	cmp	x1, x0, lsl #16
    a8e0:	54000322 	b.cs	a944 <f0+0xa34>  // b.hs, b.nlast
    a8e4:	d350fc22 	lsr	x2, x1, #16
    a8e8:	f949fc63 	ldr	x3, [x3, #5112]
    a8ec:	8b020842 	add	x2, x2, x2, lsl #2
    a8f0:	d37df042 	lsl	x2, x2, #3
    a8f4:	8b020060 	add	x0, x3, x2
    a8f8:	f9401017 	ldr	x23, [x0, #32]
    a8fc:	b4000257 	cbz	x23, a944 <f0+0xa34>
    a900:	38626862 	ldrb	w2, [x3, x2]
    a904:	7100085f 	cmp	w2, #0x2
    a908:	5400cb60 	b.eq	c274 <f0+0x2364>  // b.none
    a90c:	7100045f 	cmp	w2, #0x1
    a910:	540001a1 	b.ne	a944 <f0+0xa34>  // b.any
    a914:	29430002 	ldp	w2, w0, [x0, #24]
    a918:	92403c21 	and	x1, x1, #0xffff
    a91c:	9b027c21 	mul	x1, x1, x2
    a920:	d360fc21 	lsr	x1, x1, #32
    a924:	eb00003f 	cmp	x1, x0
    a928:	540000e2 	b.cs	a944 <f0+0xa34>  // b.hs, b.nlast
    a92c:	8b0102f7 	add	x23, x23, x1
    a930:	394002e0 	ldrb	w0, [x23]
    a934:	7103fc1f 	cmp	w0, #0xff
    a938:	5400d640 	b.eq	c400 <f0+0x24f0>  // b.none
    a93c:	52800020 	mov	w0, #0x1                   	// #1
    a940:	390002e0 	strb	w0, [x23]
    a944:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a948:	910923e1 	add	x1, sp, #0x248
    a94c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a950:	52800020 	mov	w0, #0x1                   	// #1
    a954:	f90127e2 	str	x2, [sp, #584]
    a958:	f9012bf5 	str	x21, [sp, #592]
    a95c:	97ffeada 	bl	54c4 <fwp_data.part.0.constprop.0>
    a960:	91154283 	add	x3, x20, #0x550
    a964:	aa0003f5 	mov	x21, x0
    a968:	f949d861 	ldr	x1, [x3, #5040]
    a96c:	f949ec60 	ldr	x0, [x3, #5080]
    a970:	cb0102a1 	sub	x1, x21, x1
    a974:	eb00403f 	cmp	x1, x0, lsl #16
    a978:	54000322 	b.cs	a9dc <f0+0xacc>  // b.hs, b.nlast
    a97c:	d350fc22 	lsr	x2, x1, #16
    a980:	f949fc63 	ldr	x3, [x3, #5112]
    a984:	8b020842 	add	x2, x2, x2, lsl #2
    a988:	d37df042 	lsl	x2, x2, #3
    a98c:	8b020060 	add	x0, x3, x2
    a990:	f9401017 	ldr	x23, [x0, #32]
    a994:	b4000257 	cbz	x23, a9dc <f0+0xacc>
    a998:	38626862 	ldrb	w2, [x3, x2]
    a99c:	7100085f 	cmp	w2, #0x2
    a9a0:	5400c640 	b.eq	c268 <f0+0x2358>  // b.none
    a9a4:	7100045f 	cmp	w2, #0x1
    a9a8:	540001a1 	b.ne	a9dc <f0+0xacc>  // b.any
    a9ac:	29430002 	ldp	w2, w0, [x0, #24]
    a9b0:	92403c21 	and	x1, x1, #0xffff
    a9b4:	9b027c21 	mul	x1, x1, x2
    a9b8:	d360fc21 	lsr	x1, x1, #32
    a9bc:	eb00003f 	cmp	x1, x0
    a9c0:	540000e2 	b.cs	a9dc <f0+0xacc>  // b.hs, b.nlast
    a9c4:	8b0102f7 	add	x23, x23, x1
    a9c8:	394002e0 	ldrb	w0, [x23]
    a9cc:	7103fc1f 	cmp	w0, #0xff
    a9d0:	5400d1e0 	b.eq	c40c <f0+0x24fc>  // b.none
    a9d4:	52800020 	mov	w0, #0x1                   	// #1
    a9d8:	390002e0 	strb	w0, [x23]
    a9dc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a9e0:	910963e1 	add	x1, sp, #0x258
    a9e4:	52800020 	mov	w0, #0x1                   	// #1
    a9e8:	f9012fe2 	str	x2, [sp, #600]
    a9ec:	f90133f5 	str	x21, [sp, #608]
    a9f0:	97ffeab5 	bl	54c4 <fwp_data.part.0.constprop.0>
    a9f4:	91154283 	add	x3, x20, #0x550
    a9f8:	aa0003f5 	mov	x21, x0
    a9fc:	f949d861 	ldr	x1, [x3, #5040]
    aa00:	f949ec60 	ldr	x0, [x3, #5080]
    aa04:	cb0102a1 	sub	x1, x21, x1
    aa08:	eb00403f 	cmp	x1, x0, lsl #16
    aa0c:	54000322 	b.cs	aa70 <f0+0xb60>  // b.hs, b.nlast
    aa10:	d350fc22 	lsr	x2, x1, #16
    aa14:	f949fc63 	ldr	x3, [x3, #5112]
    aa18:	8b020842 	add	x2, x2, x2, lsl #2
    aa1c:	d37df042 	lsl	x2, x2, #3
    aa20:	8b020060 	add	x0, x3, x2
    aa24:	f9401017 	ldr	x23, [x0, #32]
    aa28:	b4000257 	cbz	x23, aa70 <f0+0xb60>
    aa2c:	38626862 	ldrb	w2, [x3, x2]
    aa30:	7100085f 	cmp	w2, #0x2
    aa34:	5400c140 	b.eq	c25c <f0+0x234c>  // b.none
    aa38:	7100045f 	cmp	w2, #0x1
    aa3c:	540001a1 	b.ne	aa70 <f0+0xb60>  // b.any
    aa40:	29430002 	ldp	w2, w0, [x0, #24]
    aa44:	92403c21 	and	x1, x1, #0xffff
    aa48:	9b027c21 	mul	x1, x1, x2
    aa4c:	d360fc21 	lsr	x1, x1, #32
    aa50:	eb00003f 	cmp	x1, x0
    aa54:	540000e2 	b.cs	aa70 <f0+0xb60>  // b.hs, b.nlast
    aa58:	8b0102f7 	add	x23, x23, x1
    aa5c:	394002e0 	ldrb	w0, [x23]
    aa60:	7103fc1f 	cmp	w0, #0xff
    aa64:	5400cda0 	b.eq	c418 <f0+0x2508>  // b.none
    aa68:	52800020 	mov	w0, #0x1                   	// #1
    aa6c:	390002e0 	strb	w0, [x23]
    aa70:	9109a3e1 	add	x1, sp, #0x268
    aa74:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    aa78:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    aa7c:	52800020 	mov	w0, #0x1                   	// #1
    aa80:	f90137f7 	str	x23, [sp, #616]
    aa84:	f9013bf5 	str	x21, [sp, #624]
    aa88:	97ffea8f 	bl	54c4 <fwp_data.part.0.constprop.0>
    aa8c:	97ffeafd 	bl	5680 <fwp_rc_fresh>
    aa90:	aa0003e2 	mov	x2, x0
    aa94:	9109e3e1 	add	x1, sp, #0x278
    aa98:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    aa9c:	52800020 	mov	w0, #0x1                   	// #1
    aaa0:	f9013ff5 	str	x21, [sp, #632]
    aaa4:	f90143e2 	str	x2, [sp, #640]
    aaa8:	97ffea87 	bl	54c4 <fwp_data.part.0.constprop.0>
    aaac:	97ffeaf5 	bl	5680 <fwp_rc_fresh>
    aab0:	aa0003e2 	mov	x2, x0
    aab4:	910a23e1 	add	x1, sp, #0x288
    aab8:	52800020 	mov	w0, #0x1                   	// #1
    aabc:	f90147f7 	str	x23, [sp, #648]
    aac0:	f9014be2 	str	x2, [sp, #656]
    aac4:	97ffea80 	bl	54c4 <fwp_data.part.0.constprop.0>
    aac8:	97ffeaee 	bl	5680 <fwp_rc_fresh>
    aacc:	aa0003e2 	mov	x2, x0
    aad0:	910a63e1 	add	x1, sp, #0x298
    aad4:	52800020 	mov	w0, #0x1                   	// #1
    aad8:	f9014ff5 	str	x21, [sp, #664]
    aadc:	f90153e2 	str	x2, [sp, #672]
    aae0:	97ffea79 	bl	54c4 <fwp_data.part.0.constprop.0>
    aae4:	97ffeae7 	bl	5680 <fwp_rc_fresh>
    aae8:	aa0003e2 	mov	x2, x0
    aaec:	910aa3e1 	add	x1, sp, #0x2a8
    aaf0:	52800020 	mov	w0, #0x1                   	// #1
    aaf4:	f90157f7 	str	x23, [sp, #680]
    aaf8:	f9015be2 	str	x2, [sp, #688]
    aafc:	97ffea72 	bl	54c4 <fwp_data.part.0.constprop.0>
    ab00:	91154283 	add	x3, x20, #0x550
    ab04:	aa0003f5 	mov	x21, x0
    ab08:	f949d861 	ldr	x1, [x3, #5040]
    ab0c:	f949ec60 	ldr	x0, [x3, #5080]
    ab10:	cb0102a1 	sub	x1, x21, x1
    ab14:	eb00403f 	cmp	x1, x0, lsl #16
    ab18:	54000322 	b.cs	ab7c <f0+0xc6c>  // b.hs, b.nlast
    ab1c:	d350fc22 	lsr	x2, x1, #16
    ab20:	f949fc63 	ldr	x3, [x3, #5112]
    ab24:	8b020842 	add	x2, x2, x2, lsl #2
    ab28:	d37df042 	lsl	x2, x2, #3
    ab2c:	8b020060 	add	x0, x3, x2
    ab30:	f9401017 	ldr	x23, [x0, #32]
    ab34:	b4000257 	cbz	x23, ab7c <f0+0xc6c>
    ab38:	38626862 	ldrb	w2, [x3, x2]
    ab3c:	7100085f 	cmp	w2, #0x2
    ab40:	5400b880 	b.eq	c250 <f0+0x2340>  // b.none
    ab44:	7100045f 	cmp	w2, #0x1
    ab48:	540001a1 	b.ne	ab7c <f0+0xc6c>  // b.any
    ab4c:	29430002 	ldp	w2, w0, [x0, #24]
    ab50:	92403c21 	and	x1, x1, #0xffff
    ab54:	9b027c21 	mul	x1, x1, x2
    ab58:	d360fc21 	lsr	x1, x1, #32
    ab5c:	eb00003f 	cmp	x1, x0
    ab60:	540000e2 	b.cs	ab7c <f0+0xc6c>  // b.hs, b.nlast
    ab64:	8b0102f7 	add	x23, x23, x1
    ab68:	394002e0 	ldrb	w0, [x23]
    ab6c:	7103fc1f 	cmp	w0, #0xff
    ab70:	5400c5a0 	b.eq	c424 <f0+0x2514>  // b.none
    ab74:	52800020 	mov	w0, #0x1                   	// #1
    ab78:	390002e0 	strb	w0, [x23]
    ab7c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ab80:	910ae3e1 	add	x1, sp, #0x2b8
    ab84:	52800020 	mov	w0, #0x1                   	// #1
    ab88:	f9015fe2 	str	x2, [sp, #696]
    ab8c:	f90163f5 	str	x21, [sp, #704]
    ab90:	97ffea4d 	bl	54c4 <fwp_data.part.0.constprop.0>
    ab94:	91154283 	add	x3, x20, #0x550
    ab98:	aa0003f5 	mov	x21, x0
    ab9c:	f949d861 	ldr	x1, [x3, #5040]
    aba0:	f949ec60 	ldr	x0, [x3, #5080]
    aba4:	cb0102a1 	sub	x1, x21, x1
    aba8:	eb00403f 	cmp	x1, x0, lsl #16
    abac:	54000322 	b.cs	ac10 <f0+0xd00>  // b.hs, b.nlast
    abb0:	d350fc22 	lsr	x2, x1, #16
    abb4:	f949fc63 	ldr	x3, [x3, #5112]
    abb8:	8b020842 	add	x2, x2, x2, lsl #2
    abbc:	d37df042 	lsl	x2, x2, #3
    abc0:	8b020060 	add	x0, x3, x2
    abc4:	f9401017 	ldr	x23, [x0, #32]
    abc8:	b4000257 	cbz	x23, ac10 <f0+0xd00>
    abcc:	38626862 	ldrb	w2, [x3, x2]
    abd0:	7100085f 	cmp	w2, #0x2
    abd4:	5400b0e0 	b.eq	c1f0 <f0+0x22e0>  // b.none
    abd8:	7100045f 	cmp	w2, #0x1
    abdc:	540001a1 	b.ne	ac10 <f0+0xd00>  // b.any
    abe0:	29430002 	ldp	w2, w0, [x0, #24]
    abe4:	92403c21 	and	x1, x1, #0xffff
    abe8:	9b027c21 	mul	x1, x1, x2
    abec:	d360fc21 	lsr	x1, x1, #32
    abf0:	eb00003f 	cmp	x1, x0
    abf4:	540000e2 	b.cs	ac10 <f0+0xd00>  // b.hs, b.nlast
    abf8:	8b0102f7 	add	x23, x23, x1
    abfc:	394002e0 	ldrb	w0, [x23]
    ac00:	7103fc1f 	cmp	w0, #0xff
    ac04:	5400c160 	b.eq	c430 <f0+0x2520>  // b.none
    ac08:	52800020 	mov	w0, #0x1                   	// #1
    ac0c:	390002e0 	strb	w0, [x23]
    ac10:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ac14:	910b23e1 	add	x1, sp, #0x2c8
    ac18:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ac1c:	52800020 	mov	w0, #0x1                   	// #1
    ac20:	f90167e2 	str	x2, [sp, #712]
    ac24:	f9016bf5 	str	x21, [sp, #720]
    ac28:	97ffea27 	bl	54c4 <fwp_data.part.0.constprop.0>
    ac2c:	91154283 	add	x3, x20, #0x550
    ac30:	aa0003f5 	mov	x21, x0
    ac34:	f949d861 	ldr	x1, [x3, #5040]
    ac38:	f949ec60 	ldr	x0, [x3, #5080]
    ac3c:	cb0102a1 	sub	x1, x21, x1
    ac40:	eb00403f 	cmp	x1, x0, lsl #16
    ac44:	54000322 	b.cs	aca8 <f0+0xd98>  // b.hs, b.nlast
    ac48:	d350fc22 	lsr	x2, x1, #16
    ac4c:	f949fc63 	ldr	x3, [x3, #5112]
    ac50:	8b020842 	add	x2, x2, x2, lsl #2
    ac54:	d37df042 	lsl	x2, x2, #3
    ac58:	8b020060 	add	x0, x3, x2
    ac5c:	f9401017 	ldr	x23, [x0, #32]
    ac60:	b4000257 	cbz	x23, aca8 <f0+0xd98>
    ac64:	38626862 	ldrb	w2, [x3, x2]
    ac68:	7100085f 	cmp	w2, #0x2
    ac6c:	5400abc0 	b.eq	c1e4 <f0+0x22d4>  // b.none
    ac70:	7100045f 	cmp	w2, #0x1
    ac74:	540001a1 	b.ne	aca8 <f0+0xd98>  // b.any
    ac78:	29430002 	ldp	w2, w0, [x0, #24]
    ac7c:	92403c21 	and	x1, x1, #0xffff
    ac80:	9b027c21 	mul	x1, x1, x2
    ac84:	d360fc21 	lsr	x1, x1, #32
    ac88:	eb00003f 	cmp	x1, x0
    ac8c:	540000e2 	b.cs	aca8 <f0+0xd98>  // b.hs, b.nlast
    ac90:	8b0102f7 	add	x23, x23, x1
    ac94:	394002e0 	ldrb	w0, [x23]
    ac98:	7103fc1f 	cmp	w0, #0xff
    ac9c:	5400bd00 	b.eq	c43c <f0+0x252c>  // b.none
    aca0:	52800020 	mov	w0, #0x1                   	// #1
    aca4:	390002e0 	strb	w0, [x23]
    aca8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    acac:	910b63e1 	add	x1, sp, #0x2d8
    acb0:	52800020 	mov	w0, #0x1                   	// #1
    acb4:	f9016fe2 	str	x2, [sp, #728]
    acb8:	f90173f5 	str	x21, [sp, #736]
    acbc:	97ffea02 	bl	54c4 <fwp_data.part.0.constprop.0>
    acc0:	91154283 	add	x3, x20, #0x550
    acc4:	aa0003f5 	mov	x21, x0
    acc8:	f949d861 	ldr	x1, [x3, #5040]
    accc:	f949ec60 	ldr	x0, [x3, #5080]
    acd0:	cb0102a1 	sub	x1, x21, x1
    acd4:	eb00403f 	cmp	x1, x0, lsl #16
    acd8:	54000322 	b.cs	ad3c <f0+0xe2c>  // b.hs, b.nlast
    acdc:	d350fc22 	lsr	x2, x1, #16
    ace0:	f949fc63 	ldr	x3, [x3, #5112]
    ace4:	8b020842 	add	x2, x2, x2, lsl #2
    ace8:	d37df042 	lsl	x2, x2, #3
    acec:	8b020060 	add	x0, x3, x2
    acf0:	f9401017 	ldr	x23, [x0, #32]
    acf4:	b4000257 	cbz	x23, ad3c <f0+0xe2c>
    acf8:	38626862 	ldrb	w2, [x3, x2]
    acfc:	7100085f 	cmp	w2, #0x2
    ad00:	5400a6c0 	b.eq	c1d8 <f0+0x22c8>  // b.none
    ad04:	7100045f 	cmp	w2, #0x1
    ad08:	540001a1 	b.ne	ad3c <f0+0xe2c>  // b.any
    ad0c:	29430002 	ldp	w2, w0, [x0, #24]
    ad10:	92403c21 	and	x1, x1, #0xffff
    ad14:	9b027c21 	mul	x1, x1, x2
    ad18:	d360fc21 	lsr	x1, x1, #32
    ad1c:	eb00003f 	cmp	x1, x0
    ad20:	540000e2 	b.cs	ad3c <f0+0xe2c>  // b.hs, b.nlast
    ad24:	8b0102f7 	add	x23, x23, x1
    ad28:	394002e0 	ldrb	w0, [x23]
    ad2c:	7103fc1f 	cmp	w0, #0xff
    ad30:	5400b8c0 	b.eq	c448 <f0+0x2538>  // b.none
    ad34:	52800020 	mov	w0, #0x1                   	// #1
    ad38:	390002e0 	strb	w0, [x23]
    ad3c:	910ba3e1 	add	x1, sp, #0x2e8
    ad40:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ad44:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ad48:	52800020 	mov	w0, #0x1                   	// #1
    ad4c:	f90177f7 	str	x23, [sp, #744]
    ad50:	f9017bf5 	str	x21, [sp, #752]
    ad54:	97ffe9dc 	bl	54c4 <fwp_data.part.0.constprop.0>
    ad58:	97ffea4a 	bl	5680 <fwp_rc_fresh>
    ad5c:	aa0003e2 	mov	x2, x0
    ad60:	910be3e1 	add	x1, sp, #0x2f8
    ad64:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ad68:	52800020 	mov	w0, #0x1                   	// #1
    ad6c:	f9017ff5 	str	x21, [sp, #760]
    ad70:	f90183e2 	str	x2, [sp, #768]
    ad74:	97ffe9d4 	bl	54c4 <fwp_data.part.0.constprop.0>
    ad78:	97ffea42 	bl	5680 <fwp_rc_fresh>
    ad7c:	aa0003e2 	mov	x2, x0
    ad80:	910c23e1 	add	x1, sp, #0x308
    ad84:	52800020 	mov	w0, #0x1                   	// #1
    ad88:	f90187f7 	str	x23, [sp, #776]
    ad8c:	f9018be2 	str	x2, [sp, #784]
    ad90:	97ffe9cd 	bl	54c4 <fwp_data.part.0.constprop.0>
    ad94:	97ffea3b 	bl	5680 <fwp_rc_fresh>
    ad98:	aa0003e2 	mov	x2, x0
    ad9c:	910c63e1 	add	x1, sp, #0x318
    ada0:	52800020 	mov	w0, #0x1                   	// #1
    ada4:	f9018ff5 	str	x21, [sp, #792]
    ada8:	f90193e2 	str	x2, [sp, #800]
    adac:	97ffe9c6 	bl	54c4 <fwp_data.part.0.constprop.0>
    adb0:	91154283 	add	x3, x20, #0x550
    adb4:	aa0003f5 	mov	x21, x0
    adb8:	f949d861 	ldr	x1, [x3, #5040]
    adbc:	f949ec60 	ldr	x0, [x3, #5080]
    adc0:	cb0102a1 	sub	x1, x21, x1
    adc4:	eb00403f 	cmp	x1, x0, lsl #16
    adc8:	54000322 	b.cs	ae2c <f0+0xf1c>  // b.hs, b.nlast
    adcc:	d350fc22 	lsr	x2, x1, #16
    add0:	f949fc63 	ldr	x3, [x3, #5112]
    add4:	8b020842 	add	x2, x2, x2, lsl #2
    add8:	d37df042 	lsl	x2, x2, #3
    addc:	8b020060 	add	x0, x3, x2
    ade0:	f9401017 	ldr	x23, [x0, #32]
    ade4:	b4000257 	cbz	x23, ae2c <f0+0xf1c>
    ade8:	38626862 	ldrb	w2, [x3, x2]
    adec:	7100085f 	cmp	w2, #0x2
    adf0:	54009ee0 	b.eq	c1cc <f0+0x22bc>  // b.none
    adf4:	7100045f 	cmp	w2, #0x1
    adf8:	540001a1 	b.ne	ae2c <f0+0xf1c>  // b.any
    adfc:	29430002 	ldp	w2, w0, [x0, #24]
    ae00:	92403c21 	and	x1, x1, #0xffff
    ae04:	9b027c21 	mul	x1, x1, x2
    ae08:	d360fc21 	lsr	x1, x1, #32
    ae0c:	eb00003f 	cmp	x1, x0
    ae10:	540000e2 	b.cs	ae2c <f0+0xf1c>  // b.hs, b.nlast
    ae14:	8b0102f7 	add	x23, x23, x1
    ae18:	394002e0 	ldrb	w0, [x23]
    ae1c:	7103fc1f 	cmp	w0, #0xff
    ae20:	5400b1a0 	b.eq	c454 <f0+0x2544>  // b.none
    ae24:	52800020 	mov	w0, #0x1                   	// #1
    ae28:	390002e0 	strb	w0, [x23]
    ae2c:	910ca3e1 	add	x1, sp, #0x328
    ae30:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ae34:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ae38:	52800020 	mov	w0, #0x1                   	// #1
    ae3c:	f90197f7 	str	x23, [sp, #808]
    ae40:	f9019bf5 	str	x21, [sp, #816]
    ae44:	97ffe9a0 	bl	54c4 <fwp_data.part.0.constprop.0>
    ae48:	97ffea0e 	bl	5680 <fwp_rc_fresh>
    ae4c:	aa0003e2 	mov	x2, x0
    ae50:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ae54:	910ce3e1 	add	x1, sp, #0x338
    ae58:	52800020 	mov	w0, #0x1                   	// #1
    ae5c:	f9019fe3 	str	x3, [sp, #824]
    ae60:	f901a3e2 	str	x2, [sp, #832]
    ae64:	97ffe998 	bl	54c4 <fwp_data.part.0.constprop.0>
    ae68:	97ffea06 	bl	5680 <fwp_rc_fresh>
    ae6c:	aa0003e2 	mov	x2, x0
    ae70:	910d23e1 	add	x1, sp, #0x348
    ae74:	52800020 	mov	w0, #0x1                   	// #1
    ae78:	f901a7f7 	str	x23, [sp, #840]
    ae7c:	f901abe2 	str	x2, [sp, #848]
    ae80:	97ffe991 	bl	54c4 <fwp_data.part.0.constprop.0>
    ae84:	91154283 	add	x3, x20, #0x550
    ae88:	aa0003f7 	mov	x23, x0
    ae8c:	f949d861 	ldr	x1, [x3, #5040]
    ae90:	f949ec60 	ldr	x0, [x3, #5080]
    ae94:	cb0102e1 	sub	x1, x23, x1
    ae98:	eb00403f 	cmp	x1, x0, lsl #16
    ae9c:	54000322 	b.cs	af00 <f0+0xff0>  // b.hs, b.nlast
    aea0:	d350fc22 	lsr	x2, x1, #16
    aea4:	f949fc63 	ldr	x3, [x3, #5112]
    aea8:	8b020842 	add	x2, x2, x2, lsl #2
    aeac:	d37df042 	lsl	x2, x2, #3
    aeb0:	8b020060 	add	x0, x3, x2
    aeb4:	f9401015 	ldr	x21, [x0, #32]
    aeb8:	b4000255 	cbz	x21, af00 <f0+0xff0>
    aebc:	38626862 	ldrb	w2, [x3, x2]
    aec0:	7100085f 	cmp	w2, #0x2
    aec4:	540097e0 	b.eq	c1c0 <f0+0x22b0>  // b.none
    aec8:	7100045f 	cmp	w2, #0x1
    aecc:	540001a1 	b.ne	af00 <f0+0xff0>  // b.any
    aed0:	29430002 	ldp	w2, w0, [x0, #24]
    aed4:	92403c21 	and	x1, x1, #0xffff
    aed8:	9b027c21 	mul	x1, x1, x2
    aedc:	d360fc21 	lsr	x1, x1, #32
    aee0:	eb00003f 	cmp	x1, x0
    aee4:	540000e2 	b.cs	af00 <f0+0xff0>  // b.hs, b.nlast
    aee8:	8b0102b5 	add	x21, x21, x1
    aeec:	394002a0 	ldrb	w0, [x21]
    aef0:	7103fc1f 	cmp	w0, #0xff
    aef4:	5400ab60 	b.eq	c460 <f0+0x2550>  // b.none
    aef8:	52800020 	mov	w0, #0x1                   	// #1
    aefc:	390002a0 	strb	w0, [x21]
    af00:	910d63e1 	add	x1, sp, #0x358
    af04:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    af08:	52800020 	mov	w0, #0x1                   	// #1
    af0c:	f901aff5 	str	x21, [sp, #856]
    af10:	f901b3f7 	str	x23, [sp, #864]
    af14:	97ffe96c 	bl	54c4 <fwp_data.part.0.constprop.0>
    af18:	97ffe9da 	bl	5680 <fwp_rc_fresh>
    af1c:	aa0003e2 	mov	x2, x0
    af20:	910da3e1 	add	x1, sp, #0x368
    af24:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    af28:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    af2c:	52800020 	mov	w0, #0x1                   	// #1
    af30:	f901b7f7 	str	x23, [sp, #872]
    af34:	f901bbe2 	str	x2, [sp, #880]
    af38:	97ffe963 	bl	54c4 <fwp_data.part.0.constprop.0>
    af3c:	97ffe9d1 	bl	5680 <fwp_rc_fresh>
    af40:	aa0003e2 	mov	x2, x0
    af44:	910de3e1 	add	x1, sp, #0x378
    af48:	52800020 	mov	w0, #0x1                   	// #1
    af4c:	f901bff5 	str	x21, [sp, #888]
    af50:	f901c3e2 	str	x2, [sp, #896]
    af54:	97ffe95c 	bl	54c4 <fwp_data.part.0.constprop.0>
    af58:	97ffe9ca 	bl	5680 <fwp_rc_fresh>
    af5c:	aa0003e2 	mov	x2, x0
    af60:	910e23e1 	add	x1, sp, #0x388
    af64:	52800020 	mov	w0, #0x1                   	// #1
    af68:	f901c7f7 	str	x23, [sp, #904]
    af6c:	f901cbe2 	str	x2, [sp, #912]
    af70:	97ffe955 	bl	54c4 <fwp_data.part.0.constprop.0>
    af74:	97ffe9c3 	bl	5680 <fwp_rc_fresh>
    af78:	aa0003e2 	mov	x2, x0
    af7c:	910e63e1 	add	x1, sp, #0x398
    af80:	52800020 	mov	w0, #0x1                   	// #1
    af84:	f901cff5 	str	x21, [sp, #920]
    af88:	f901d3e2 	str	x2, [sp, #928]
    af8c:	97ffe94e 	bl	54c4 <fwp_data.part.0.constprop.0>
    af90:	97ffe9bc 	bl	5680 <fwp_rc_fresh>
    af94:	aa0003e2 	mov	x2, x0
    af98:	910ea3e1 	add	x1, sp, #0x3a8
    af9c:	52800020 	mov	w0, #0x1                   	// #1
    afa0:	f901d7f7 	str	x23, [sp, #936]
    afa4:	f901dbe2 	str	x2, [sp, #944]
    afa8:	97ffe947 	bl	54c4 <fwp_data.part.0.constprop.0>
    afac:	97ffe9b5 	bl	5680 <fwp_rc_fresh>
    afb0:	aa0003e2 	mov	x2, x0
    afb4:	910ee3e1 	add	x1, sp, #0x3b8
    afb8:	52800020 	mov	w0, #0x1                   	// #1
    afbc:	f901dff5 	str	x21, [sp, #952]
    afc0:	f901e3e2 	str	x2, [sp, #960]
    afc4:	97ffe940 	bl	54c4 <fwp_data.part.0.constprop.0>
    afc8:	97ffe9ae 	bl	5680 <fwp_rc_fresh>
    afcc:	aa0003e2 	mov	x2, x0
    afd0:	910f23e1 	add	x1, sp, #0x3c8
    afd4:	52800020 	mov	w0, #0x1                   	// #1
    afd8:	f901e7f7 	str	x23, [sp, #968]
    afdc:	f901ebe2 	str	x2, [sp, #976]
    afe0:	97ffe939 	bl	54c4 <fwp_data.part.0.constprop.0>
    afe4:	97ffe9a7 	bl	5680 <fwp_rc_fresh>
    afe8:	aa0003e2 	mov	x2, x0
    afec:	910f63e1 	add	x1, sp, #0x3d8
    aff0:	52800020 	mov	w0, #0x1                   	// #1
    aff4:	f901eff5 	str	x21, [sp, #984]
    aff8:	f901f3e2 	str	x2, [sp, #992]
    affc:	97ffe932 	bl	54c4 <fwp_data.part.0.constprop.0>
    b000:	91154283 	add	x3, x20, #0x550
    b004:	aa0003f5 	mov	x21, x0
    b008:	f949d861 	ldr	x1, [x3, #5040]
    b00c:	f949ec60 	ldr	x0, [x3, #5080]
    b010:	cb0102a1 	sub	x1, x21, x1
    b014:	eb00403f 	cmp	x1, x0, lsl #16
    b018:	54000322 	b.cs	b07c <f0+0x116c>  // b.hs, b.nlast
    b01c:	d350fc22 	lsr	x2, x1, #16
    b020:	f949fc63 	ldr	x3, [x3, #5112]
    b024:	8b020842 	add	x2, x2, x2, lsl #2
    b028:	d37df042 	lsl	x2, x2, #3
    b02c:	8b020060 	add	x0, x3, x2
    b030:	f9401017 	ldr	x23, [x0, #32]
    b034:	b4000257 	cbz	x23, b07c <f0+0x116c>
    b038:	38626862 	ldrb	w2, [x3, x2]
    b03c:	7100085f 	cmp	w2, #0x2
    b040:	54008ba0 	b.eq	c1b4 <f0+0x22a4>  // b.none
    b044:	7100045f 	cmp	w2, #0x1
    b048:	540001a1 	b.ne	b07c <f0+0x116c>  // b.any
    b04c:	29430002 	ldp	w2, w0, [x0, #24]
    b050:	92403c21 	and	x1, x1, #0xffff
    b054:	9b027c21 	mul	x1, x1, x2
    b058:	d360fc21 	lsr	x1, x1, #32
    b05c:	eb00003f 	cmp	x1, x0
    b060:	540000e2 	b.cs	b07c <f0+0x116c>  // b.hs, b.nlast
    b064:	8b0102f7 	add	x23, x23, x1
    b068:	394002e0 	ldrb	w0, [x23]
    b06c:	7103fc1f 	cmp	w0, #0xff
    b070:	54009fe0 	b.eq	c46c <f0+0x255c>  // b.none
    b074:	52800020 	mov	w0, #0x1                   	// #1
    b078:	390002e0 	strb	w0, [x23]
    b07c:	910fa3e1 	add	x1, sp, #0x3e8
    b080:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b084:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b088:	52800020 	mov	w0, #0x1                   	// #1
    b08c:	f901f7f7 	str	x23, [sp, #1000]
    b090:	f901fbf5 	str	x21, [sp, #1008]
    b094:	97ffe90c 	bl	54c4 <fwp_data.part.0.constprop.0>
    b098:	97ffe97a 	bl	5680 <fwp_rc_fresh>
    b09c:	aa0003e2 	mov	x2, x0
    b0a0:	910fe3e1 	add	x1, sp, #0x3f8
    b0a4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b0a8:	52800020 	mov	w0, #0x1                   	// #1
    b0ac:	f901fff5 	str	x21, [sp, #1016]
    b0b0:	f90203e2 	str	x2, [sp, #1024]
    b0b4:	97ffe904 	bl	54c4 <fwp_data.part.0.constprop.0>
    b0b8:	97ffe972 	bl	5680 <fwp_rc_fresh>
    b0bc:	aa0003e2 	mov	x2, x0
    b0c0:	911023e1 	add	x1, sp, #0x408
    b0c4:	52800020 	mov	w0, #0x1                   	// #1
    b0c8:	f90207f7 	str	x23, [sp, #1032]
    b0cc:	f9020be2 	str	x2, [sp, #1040]
    b0d0:	97ffe8fd 	bl	54c4 <fwp_data.part.0.constprop.0>
    b0d4:	97ffe96b 	bl	5680 <fwp_rc_fresh>
    b0d8:	aa0003e2 	mov	x2, x0
    b0dc:	911063e1 	add	x1, sp, #0x418
    b0e0:	52800020 	mov	w0, #0x1                   	// #1
    b0e4:	f9020ff5 	str	x21, [sp, #1048]
    b0e8:	f90213e2 	str	x2, [sp, #1056]
    b0ec:	97ffe8f6 	bl	54c4 <fwp_data.part.0.constprop.0>
    b0f0:	97ffe964 	bl	5680 <fwp_rc_fresh>
    b0f4:	aa0003e2 	mov	x2, x0
    b0f8:	9110a3e1 	add	x1, sp, #0x428
    b0fc:	52800020 	mov	w0, #0x1                   	// #1
    b100:	f90217f7 	str	x23, [sp, #1064]
    b104:	f9021be2 	str	x2, [sp, #1072]
    b108:	97ffe8ef 	bl	54c4 <fwp_data.part.0.constprop.0>
    b10c:	97ffe95d 	bl	5680 <fwp_rc_fresh>
    b110:	aa0003e2 	mov	x2, x0
    b114:	9110e3e1 	add	x1, sp, #0x438
    b118:	52800020 	mov	w0, #0x1                   	// #1
    b11c:	f9021ff5 	str	x21, [sp, #1080]
    b120:	f90223e2 	str	x2, [sp, #1088]
    b124:	97ffe8e8 	bl	54c4 <fwp_data.part.0.constprop.0>
    b128:	97ffe956 	bl	5680 <fwp_rc_fresh>
    b12c:	aa0003e2 	mov	x2, x0
    b130:	911123e1 	add	x1, sp, #0x448
    b134:	52800020 	mov	w0, #0x1                   	// #1
    b138:	f90227f7 	str	x23, [sp, #1096]
    b13c:	f9022be2 	str	x2, [sp, #1104]
    b140:	97ffe8e1 	bl	54c4 <fwp_data.part.0.constprop.0>
    b144:	97ffe94f 	bl	5680 <fwp_rc_fresh>
    b148:	aa0003e2 	mov	x2, x0
    b14c:	911163e1 	add	x1, sp, #0x458
    b150:	52800020 	mov	w0, #0x1                   	// #1
    b154:	f9022ff5 	str	x21, [sp, #1112]
    b158:	f90233e2 	str	x2, [sp, #1120]
    b15c:	97ffe8da 	bl	54c4 <fwp_data.part.0.constprop.0>
    b160:	91154283 	add	x3, x20, #0x550
    b164:	aa0003f5 	mov	x21, x0
    b168:	f949d861 	ldr	x1, [x3, #5040]
    b16c:	f949ec60 	ldr	x0, [x3, #5080]
    b170:	cb0102a1 	sub	x1, x21, x1
    b174:	eb00403f 	cmp	x1, x0, lsl #16
    b178:	54000322 	b.cs	b1dc <f0+0x12cc>  // b.hs, b.nlast
    b17c:	d350fc22 	lsr	x2, x1, #16
    b180:	f949fc63 	ldr	x3, [x3, #5112]
    b184:	8b020842 	add	x2, x2, x2, lsl #2
    b188:	d37df042 	lsl	x2, x2, #3
    b18c:	8b020060 	add	x0, x3, x2
    b190:	f9401017 	ldr	x23, [x0, #32]
    b194:	b4000257 	cbz	x23, b1dc <f0+0x12cc>
    b198:	38626862 	ldrb	w2, [x3, x2]
    b19c:	7100085f 	cmp	w2, #0x2
    b1a0:	54008040 	b.eq	c1a8 <f0+0x2298>  // b.none
    b1a4:	7100045f 	cmp	w2, #0x1
    b1a8:	540001a1 	b.ne	b1dc <f0+0x12cc>  // b.any
    b1ac:	29430002 	ldp	w2, w0, [x0, #24]
    b1b0:	92403c21 	and	x1, x1, #0xffff
    b1b4:	9b027c21 	mul	x1, x1, x2
    b1b8:	d360fc21 	lsr	x1, x1, #32
    b1bc:	eb00003f 	cmp	x1, x0
    b1c0:	540000e2 	b.cs	b1dc <f0+0x12cc>  // b.hs, b.nlast
    b1c4:	8b0102f7 	add	x23, x23, x1
    b1c8:	394002e0 	ldrb	w0, [x23]
    b1cc:	7103fc1f 	cmp	w0, #0xff
    b1d0:	54009540 	b.eq	c478 <f0+0x2568>  // b.none
    b1d4:	52800020 	mov	w0, #0x1                   	// #1
    b1d8:	390002e0 	strb	w0, [x23]
    b1dc:	9111a3e1 	add	x1, sp, #0x468
    b1e0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b1e4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b1e8:	52800020 	mov	w0, #0x1                   	// #1
    b1ec:	f90237f7 	str	x23, [sp, #1128]
    b1f0:	f9023bf5 	str	x21, [sp, #1136]
    b1f4:	97ffe8b4 	bl	54c4 <fwp_data.part.0.constprop.0>
    b1f8:	97ffe922 	bl	5680 <fwp_rc_fresh>
    b1fc:	aa0003e2 	mov	x2, x0
    b200:	9111e3e1 	add	x1, sp, #0x478
    b204:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b208:	52800020 	mov	w0, #0x1                   	// #1
    b20c:	f9023ff5 	str	x21, [sp, #1144]
    b210:	f90243e2 	str	x2, [sp, #1152]
    b214:	97ffe8ac 	bl	54c4 <fwp_data.part.0.constprop.0>
    b218:	97ffe91a 	bl	5680 <fwp_rc_fresh>
    b21c:	aa0003e2 	mov	x2, x0
    b220:	911223e1 	add	x1, sp, #0x488
    b224:	52800020 	mov	w0, #0x1                   	// #1
    b228:	f90247f7 	str	x23, [sp, #1160]
    b22c:	f9024be2 	str	x2, [sp, #1168]
    b230:	97ffe8a5 	bl	54c4 <fwp_data.part.0.constprop.0>
    b234:	97ffe913 	bl	5680 <fwp_rc_fresh>
    b238:	aa0003e2 	mov	x2, x0
    b23c:	911263e1 	add	x1, sp, #0x498
    b240:	52800020 	mov	w0, #0x1                   	// #1
    b244:	f9024ff5 	str	x21, [sp, #1176]
    b248:	f90253e2 	str	x2, [sp, #1184]
    b24c:	97ffe89e 	bl	54c4 <fwp_data.part.0.constprop.0>
    b250:	91154283 	add	x3, x20, #0x550
    b254:	aa0003f5 	mov	x21, x0
    b258:	f949d861 	ldr	x1, [x3, #5040]
    b25c:	f949ec60 	ldr	x0, [x3, #5080]
    b260:	cb0102a1 	sub	x1, x21, x1
    b264:	eb00403f 	cmp	x1, x0, lsl #16
    b268:	54000322 	b.cs	b2cc <f0+0x13bc>  // b.hs, b.nlast
    b26c:	d350fc22 	lsr	x2, x1, #16
    b270:	f949fc63 	ldr	x3, [x3, #5112]
    b274:	8b020842 	add	x2, x2, x2, lsl #2
    b278:	d37df042 	lsl	x2, x2, #3
    b27c:	8b020060 	add	x0, x3, x2
    b280:	f9401017 	ldr	x23, [x0, #32]
    b284:	b4000257 	cbz	x23, b2cc <f0+0x13bc>
    b288:	38626862 	ldrb	w2, [x3, x2]
    b28c:	7100085f 	cmp	w2, #0x2
    b290:	54007860 	b.eq	c19c <f0+0x228c>  // b.none
    b294:	7100045f 	cmp	w2, #0x1
    b298:	540001a1 	b.ne	b2cc <f0+0x13bc>  // b.any
    b29c:	29430002 	ldp	w2, w0, [x0, #24]
    b2a0:	92403c21 	and	x1, x1, #0xffff
    b2a4:	9b027c21 	mul	x1, x1, x2
    b2a8:	d360fc21 	lsr	x1, x1, #32
    b2ac:	eb00003f 	cmp	x1, x0
    b2b0:	540000e2 	b.cs	b2cc <f0+0x13bc>  // b.hs, b.nlast
    b2b4:	8b0102f7 	add	x23, x23, x1
    b2b8:	394002e0 	ldrb	w0, [x23]
    b2bc:	7103fc1f 	cmp	w0, #0xff
    b2c0:	54008e20 	b.eq	c484 <f0+0x2574>  // b.none
    b2c4:	52800020 	mov	w0, #0x1                   	// #1
    b2c8:	390002e0 	strb	w0, [x23]
    b2cc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b2d0:	9112a3e1 	add	x1, sp, #0x4a8
    b2d4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b2d8:	52800020 	mov	w0, #0x1                   	// #1
    b2dc:	f90257e2 	str	x2, [sp, #1192]
    b2e0:	f9025bf5 	str	x21, [sp, #1200]
    b2e4:	97ffe878 	bl	54c4 <fwp_data.part.0.constprop.0>
    b2e8:	97ffe8e6 	bl	5680 <fwp_rc_fresh>
    b2ec:	aa0003e2 	mov	x2, x0
    b2f0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b2f4:	9112e3e1 	add	x1, sp, #0x4b8
    b2f8:	52800020 	mov	w0, #0x1                   	// #1
    b2fc:	f9025fe3 	str	x3, [sp, #1208]
    b300:	f90263e2 	str	x2, [sp, #1216]
    b304:	97ffe870 	bl	54c4 <fwp_data.part.0.constprop.0>
    b308:	91154283 	add	x3, x20, #0x550
    b30c:	aa0003f5 	mov	x21, x0
    b310:	f949d861 	ldr	x1, [x3, #5040]
    b314:	f949ec60 	ldr	x0, [x3, #5080]
    b318:	cb0102a1 	sub	x1, x21, x1
    b31c:	eb00403f 	cmp	x1, x0, lsl #16
    b320:	54000322 	b.cs	b384 <f0+0x1474>  // b.hs, b.nlast
    b324:	d350fc22 	lsr	x2, x1, #16
    b328:	f949fc63 	ldr	x3, [x3, #5112]
    b32c:	8b020842 	add	x2, x2, x2, lsl #2
    b330:	d37df042 	lsl	x2, x2, #3
    b334:	8b020060 	add	x0, x3, x2
    b338:	f9401017 	ldr	x23, [x0, #32]
    b33c:	b4000257 	cbz	x23, b384 <f0+0x1474>
    b340:	38626862 	ldrb	w2, [x3, x2]
    b344:	7100085f 	cmp	w2, #0x2
    b348:	540080e0 	b.eq	c364 <f0+0x2454>  // b.none
    b34c:	7100045f 	cmp	w2, #0x1
    b350:	540001a1 	b.ne	b384 <f0+0x1474>  // b.any
    b354:	29430002 	ldp	w2, w0, [x0, #24]
    b358:	92403c21 	and	x1, x1, #0xffff
    b35c:	9b027c21 	mul	x1, x1, x2
    b360:	d360fc21 	lsr	x1, x1, #32
    b364:	eb00003f 	cmp	x1, x0
    b368:	540000e2 	b.cs	b384 <f0+0x1474>  // b.hs, b.nlast
    b36c:	8b0102f7 	add	x23, x23, x1
    b370:	394002e0 	ldrb	w0, [x23]
    b374:	7103fc1f 	cmp	w0, #0xff
    b378:	540088c0 	b.eq	c490 <f0+0x2580>  // b.none
    b37c:	52800020 	mov	w0, #0x1                   	// #1
    b380:	390002e0 	strb	w0, [x23]
    b384:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b388:	911323e1 	add	x1, sp, #0x4c8
    b38c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b390:	52800020 	mov	w0, #0x1                   	// #1
    b394:	f90267e2 	str	x2, [sp, #1224]
    b398:	f9026bf5 	str	x21, [sp, #1232]
    b39c:	97ffe84a 	bl	54c4 <fwp_data.part.0.constprop.0>
    b3a0:	91154283 	add	x3, x20, #0x550
    b3a4:	aa0003f5 	mov	x21, x0
    b3a8:	f949d861 	ldr	x1, [x3, #5040]
    b3ac:	f949ec60 	ldr	x0, [x3, #5080]
    b3b0:	cb0102a1 	sub	x1, x21, x1
    b3b4:	eb00403f 	cmp	x1, x0, lsl #16
    b3b8:	54000322 	b.cs	b41c <f0+0x150c>  // b.hs, b.nlast
    b3bc:	d350fc22 	lsr	x2, x1, #16
    b3c0:	f949fc63 	ldr	x3, [x3, #5112]
    b3c4:	8b020842 	add	x2, x2, x2, lsl #2
    b3c8:	d37df042 	lsl	x2, x2, #3
    b3cc:	8b020060 	add	x0, x3, x2
    b3d0:	f9401017 	ldr	x23, [x0, #32]
    b3d4:	b4000257 	cbz	x23, b41c <f0+0x150c>
    b3d8:	38626862 	ldrb	w2, [x3, x2]
    b3dc:	7100085f 	cmp	w2, #0x2
    b3e0:	54007bc0 	b.eq	c358 <f0+0x2448>  // b.none
    b3e4:	7100045f 	cmp	w2, #0x1
    b3e8:	540001a1 	b.ne	b41c <f0+0x150c>  // b.any
    b3ec:	29430002 	ldp	w2, w0, [x0, #24]
    b3f0:	92403c21 	and	x1, x1, #0xffff
    b3f4:	9b027c21 	mul	x1, x1, x2
    b3f8:	d360fc21 	lsr	x1, x1, #32
    b3fc:	eb00003f 	cmp	x1, x0
    b400:	540000e2 	b.cs	b41c <f0+0x150c>  // b.hs, b.nlast
    b404:	8b0102f7 	add	x23, x23, x1
    b408:	394002e0 	ldrb	w0, [x23]
    b40c:	7103fc1f 	cmp	w0, #0xff
    b410:	54008460 	b.eq	c49c <f0+0x258c>  // b.none
    b414:	52800020 	mov	w0, #0x1                   	// #1
    b418:	390002e0 	strb	w0, [x23]
    b41c:	911363e1 	add	x1, sp, #0x4d8
    b420:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b424:	52800020 	mov	w0, #0x1                   	// #1
    b428:	f9026ff7 	str	x23, [sp, #1240]
    b42c:	f90273f5 	str	x21, [sp, #1248]
    b430:	97ffe825 	bl	54c4 <fwp_data.part.0.constprop.0>
    b434:	97ffe893 	bl	5680 <fwp_rc_fresh>
    b438:	aa0003e2 	mov	x2, x0
    b43c:	9113a3e1 	add	x1, sp, #0x4e8
    b440:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b444:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b448:	52800020 	mov	w0, #0x1                   	// #1
    b44c:	f90277f5 	str	x21, [sp, #1256]
    b450:	f9027be2 	str	x2, [sp, #1264]
    b454:	97ffe81c 	bl	54c4 <fwp_data.part.0.constprop.0>
    b458:	97ffe88a 	bl	5680 <fwp_rc_fresh>
    b45c:	aa0003e2 	mov	x2, x0
    b460:	9113e3e1 	add	x1, sp, #0x4f8
    b464:	52800020 	mov	w0, #0x1                   	// #1
    b468:	f9027ff7 	str	x23, [sp, #1272]
    b46c:	f90283e2 	str	x2, [sp, #1280]
    b470:	97ffe815 	bl	54c4 <fwp_data.part.0.constprop.0>
    b474:	97ffe883 	bl	5680 <fwp_rc_fresh>
    b478:	aa0003e2 	mov	x2, x0
    b47c:	911423e1 	add	x1, sp, #0x508
    b480:	52800020 	mov	w0, #0x1                   	// #1
    b484:	f90287f5 	str	x21, [sp, #1288]
    b488:	f9028be2 	str	x2, [sp, #1296]
    b48c:	97ffe80e 	bl	54c4 <fwp_data.part.0.constprop.0>
    b490:	97ffe87c 	bl	5680 <fwp_rc_fresh>
    b494:	aa0003e2 	mov	x2, x0
    b498:	911463e1 	add	x1, sp, #0x518
    b49c:	52800020 	mov	w0, #0x1                   	// #1
    b4a0:	f9028ff7 	str	x23, [sp, #1304]
    b4a4:	f90293e2 	str	x2, [sp, #1312]
    b4a8:	97ffe807 	bl	54c4 <fwp_data.part.0.constprop.0>
    b4ac:	91154283 	add	x3, x20, #0x550
    b4b0:	aa0003f5 	mov	x21, x0
    b4b4:	f949d861 	ldr	x1, [x3, #5040]
    b4b8:	f949ec60 	ldr	x0, [x3, #5080]
    b4bc:	cb0102a1 	sub	x1, x21, x1
    b4c0:	eb00403f 	cmp	x1, x0, lsl #16
    b4c4:	54000322 	b.cs	b528 <f0+0x1618>  // b.hs, b.nlast
    b4c8:	d350fc22 	lsr	x2, x1, #16
    b4cc:	f949fc63 	ldr	x3, [x3, #5112]
    b4d0:	8b020842 	add	x2, x2, x2, lsl #2
    b4d4:	d37df042 	lsl	x2, x2, #3
    b4d8:	8b020060 	add	x0, x3, x2
    b4dc:	f9401017 	ldr	x23, [x0, #32]
    b4e0:	b4000257 	cbz	x23, b528 <f0+0x1618>
    b4e4:	38626862 	ldrb	w2, [x3, x2]
    b4e8:	7100085f 	cmp	w2, #0x2
    b4ec:	54007300 	b.eq	c34c <f0+0x243c>  // b.none
    b4f0:	7100045f 	cmp	w2, #0x1
    b4f4:	540001a1 	b.ne	b528 <f0+0x1618>  // b.any
    b4f8:	29430002 	ldp	w2, w0, [x0, #24]
    b4fc:	92403c21 	and	x1, x1, #0xffff
    b500:	9b027c21 	mul	x1, x1, x2
    b504:	d360fc21 	lsr	x1, x1, #32
    b508:	eb00003f 	cmp	x1, x0
    b50c:	540000e2 	b.cs	b528 <f0+0x1618>  // b.hs, b.nlast
    b510:	8b0102f7 	add	x23, x23, x1
    b514:	394002e0 	ldrb	w0, [x23]
    b518:	7103fc1f 	cmp	w0, #0xff
    b51c:	54007c60 	b.eq	c4a8 <f0+0x2598>  // b.none
    b520:	52800020 	mov	w0, #0x1                   	// #1
    b524:	390002e0 	strb	w0, [x23]
    b528:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b52c:	9114a3e1 	add	x1, sp, #0x528
    b530:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b534:	52800020 	mov	w0, #0x1                   	// #1
    b538:	f90297e2 	str	x2, [sp, #1320]
    b53c:	f9029bf5 	str	x21, [sp, #1328]
    b540:	97ffe7e1 	bl	54c4 <fwp_data.part.0.constprop.0>
    b544:	91154283 	add	x3, x20, #0x550
    b548:	aa0003f7 	mov	x23, x0
    b54c:	f949d861 	ldr	x1, [x3, #5040]
    b550:	f949ec60 	ldr	x0, [x3, #5080]
    b554:	cb0102e1 	sub	x1, x23, x1
    b558:	eb00403f 	cmp	x1, x0, lsl #16
    b55c:	54000322 	b.cs	b5c0 <f0+0x16b0>  // b.hs, b.nlast
    b560:	d350fc22 	lsr	x2, x1, #16
    b564:	f949fc63 	ldr	x3, [x3, #5112]
    b568:	8b020842 	add	x2, x2, x2, lsl #2
    b56c:	d37df042 	lsl	x2, x2, #3
    b570:	8b020060 	add	x0, x3, x2
    b574:	f9401015 	ldr	x21, [x0, #32]
    b578:	b4000255 	cbz	x21, b5c0 <f0+0x16b0>
    b57c:	38626862 	ldrb	w2, [x3, x2]
    b580:	7100085f 	cmp	w2, #0x2
    b584:	54006de0 	b.eq	c340 <f0+0x2430>  // b.none
    b588:	7100045f 	cmp	w2, #0x1
    b58c:	540001a1 	b.ne	b5c0 <f0+0x16b0>  // b.any
    b590:	29430002 	ldp	w2, w0, [x0, #24]
    b594:	92403c21 	and	x1, x1, #0xffff
    b598:	9b027c21 	mul	x1, x1, x2
    b59c:	d360fc21 	lsr	x1, x1, #32
    b5a0:	eb00003f 	cmp	x1, x0
    b5a4:	540000e2 	b.cs	b5c0 <f0+0x16b0>  // b.hs, b.nlast
    b5a8:	8b0102b5 	add	x21, x21, x1
    b5ac:	394002a0 	ldrb	w0, [x21]
    b5b0:	7103fc1f 	cmp	w0, #0xff
    b5b4:	54007800 	b.eq	c4b4 <f0+0x25a4>  // b.none
    b5b8:	52800020 	mov	w0, #0x1                   	// #1
    b5bc:	390002a0 	strb	w0, [x21]
    b5c0:	9114e3e1 	add	x1, sp, #0x538
    b5c4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b5c8:	52800020 	mov	w0, #0x1                   	// #1
    b5cc:	f9029ff5 	str	x21, [sp, #1336]
    b5d0:	f902a3f7 	str	x23, [sp, #1344]
    b5d4:	97ffe7bc 	bl	54c4 <fwp_data.part.0.constprop.0>
    b5d8:	97ffe82a 	bl	5680 <fwp_rc_fresh>
    b5dc:	aa0003e2 	mov	x2, x0
    b5e0:	911523e1 	add	x1, sp, #0x548
    b5e4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b5e8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b5ec:	52800020 	mov	w0, #0x1                   	// #1
    b5f0:	f902a7f7 	str	x23, [sp, #1352]
    b5f4:	f902abe2 	str	x2, [sp, #1360]
    b5f8:	97ffe7b3 	bl	54c4 <fwp_data.part.0.constprop.0>
    b5fc:	97ffe821 	bl	5680 <fwp_rc_fresh>
    b600:	aa0003e2 	mov	x2, x0
    b604:	911563e1 	add	x1, sp, #0x558
    b608:	52800020 	mov	w0, #0x1                   	// #1
    b60c:	f902aff5 	str	x21, [sp, #1368]
    b610:	f902b3e2 	str	x2, [sp, #1376]
    b614:	97ffe7ac 	bl	54c4 <fwp_data.part.0.constprop.0>
    b618:	97ffe81a 	bl	5680 <fwp_rc_fresh>
    b61c:	aa0003e2 	mov	x2, x0
    b620:	9115a3e1 	add	x1, sp, #0x568
    b624:	52800020 	mov	w0, #0x1                   	// #1
    b628:	f902b7f7 	str	x23, [sp, #1384]
    b62c:	f902bbe2 	str	x2, [sp, #1392]
    b630:	97ffe7a5 	bl	54c4 <fwp_data.part.0.constprop.0>
    b634:	97ffe813 	bl	5680 <fwp_rc_fresh>
    b638:	aa0003e2 	mov	x2, x0
    b63c:	9115e3e1 	add	x1, sp, #0x578
    b640:	52800020 	mov	w0, #0x1                   	// #1
    b644:	f902bff5 	str	x21, [sp, #1400]
    b648:	f902c3e2 	str	x2, [sp, #1408]
    b64c:	97ffe79e 	bl	54c4 <fwp_data.part.0.constprop.0>
    b650:	97ffe80c 	bl	5680 <fwp_rc_fresh>
    b654:	aa0003e2 	mov	x2, x0
    b658:	911623e1 	add	x1, sp, #0x588
    b65c:	52800020 	mov	w0, #0x1                   	// #1
    b660:	f902c7f7 	str	x23, [sp, #1416]
    b664:	f902cbe2 	str	x2, [sp, #1424]
    b668:	97ffe797 	bl	54c4 <fwp_data.part.0.constprop.0>
    b66c:	97ffe805 	bl	5680 <fwp_rc_fresh>
    b670:	aa0003e2 	mov	x2, x0
    b674:	911663e1 	add	x1, sp, #0x598
    b678:	52800020 	mov	w0, #0x1                   	// #1
    b67c:	f902cff5 	str	x21, [sp, #1432]
    b680:	f902d3e2 	str	x2, [sp, #1440]
    b684:	97ffe790 	bl	54c4 <fwp_data.part.0.constprop.0>
    b688:	97ffe7fe 	bl	5680 <fwp_rc_fresh>
    b68c:	aa0003e2 	mov	x2, x0
    b690:	9116a3e1 	add	x1, sp, #0x5a8
    b694:	52800020 	mov	w0, #0x1                   	// #1
    b698:	f902d7f7 	str	x23, [sp, #1448]
    b69c:	f902dbe2 	str	x2, [sp, #1456]
    b6a0:	97ffe789 	bl	54c4 <fwp_data.part.0.constprop.0>
    b6a4:	97ffe7f7 	bl	5680 <fwp_rc_fresh>
    b6a8:	aa0003e2 	mov	x2, x0
    b6ac:	9116e3e1 	add	x1, sp, #0x5b8
    b6b0:	52800020 	mov	w0, #0x1                   	// #1
    b6b4:	f902dff5 	str	x21, [sp, #1464]
    b6b8:	f902e3e2 	str	x2, [sp, #1472]
    b6bc:	97ffe782 	bl	54c4 <fwp_data.part.0.constprop.0>
    b6c0:	91154283 	add	x3, x20, #0x550
    b6c4:	aa0003f5 	mov	x21, x0
    b6c8:	f949d861 	ldr	x1, [x3, #5040]
    b6cc:	f949ec60 	ldr	x0, [x3, #5080]
    b6d0:	cb0102a1 	sub	x1, x21, x1
    b6d4:	eb00403f 	cmp	x1, x0, lsl #16
    b6d8:	54000322 	b.cs	b73c <f0+0x182c>  // b.hs, b.nlast
    b6dc:	d350fc22 	lsr	x2, x1, #16
    b6e0:	f949fc63 	ldr	x3, [x3, #5112]
    b6e4:	8b020842 	add	x2, x2, x2, lsl #2
    b6e8:	d37df042 	lsl	x2, x2, #3
    b6ec:	8b020060 	add	x0, x3, x2
    b6f0:	f9401017 	ldr	x23, [x0, #32]
    b6f4:	b4000257 	cbz	x23, b73c <f0+0x182c>
    b6f8:	38626862 	ldrb	w2, [x3, x2]
    b6fc:	7100085f 	cmp	w2, #0x2
    b700:	540061a0 	b.eq	c334 <f0+0x2424>  // b.none
    b704:	7100045f 	cmp	w2, #0x1
    b708:	540001a1 	b.ne	b73c <f0+0x182c>  // b.any
    b70c:	29430002 	ldp	w2, w0, [x0, #24]
    b710:	92403c21 	and	x1, x1, #0xffff
    b714:	9b027c21 	mul	x1, x1, x2
    b718:	d360fc21 	lsr	x1, x1, #32
    b71c:	eb00003f 	cmp	x1, x0
    b720:	540000e2 	b.cs	b73c <f0+0x182c>  // b.hs, b.nlast
    b724:	8b0102f7 	add	x23, x23, x1
    b728:	394002e0 	ldrb	w0, [x23]
    b72c:	7103fc1f 	cmp	w0, #0xff
    b730:	54006c80 	b.eq	c4c0 <f0+0x25b0>  // b.none
    b734:	52800020 	mov	w0, #0x1                   	// #1
    b738:	390002e0 	strb	w0, [x23]
    b73c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b740:	911723e1 	add	x1, sp, #0x5c8
    b744:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b748:	52800020 	mov	w0, #0x1                   	// #1
    b74c:	f902e7e2 	str	x2, [sp, #1480]
    b750:	f902ebf5 	str	x21, [sp, #1488]
    b754:	97ffe75c 	bl	54c4 <fwp_data.part.0.constprop.0>
    b758:	91154283 	add	x3, x20, #0x550
    b75c:	aa0003f5 	mov	x21, x0
    b760:	f949d861 	ldr	x1, [x3, #5040]
    b764:	f949ec60 	ldr	x0, [x3, #5080]
    b768:	cb0102a1 	sub	x1, x21, x1
    b76c:	eb00403f 	cmp	x1, x0, lsl #16
    b770:	54000322 	b.cs	b7d4 <f0+0x18c4>  // b.hs, b.nlast
    b774:	d350fc22 	lsr	x2, x1, #16
    b778:	f949fc63 	ldr	x3, [x3, #5112]
    b77c:	8b020842 	add	x2, x2, x2, lsl #2
    b780:	d37df042 	lsl	x2, x2, #3
    b784:	8b020060 	add	x0, x3, x2
    b788:	f9401017 	ldr	x23, [x0, #32]
    b78c:	b4000257 	cbz	x23, b7d4 <f0+0x18c4>
    b790:	38626862 	ldrb	w2, [x3, x2]
    b794:	7100085f 	cmp	w2, #0x2
    b798:	54005c80 	b.eq	c328 <f0+0x2418>  // b.none
    b79c:	7100045f 	cmp	w2, #0x1
    b7a0:	540001a1 	b.ne	b7d4 <f0+0x18c4>  // b.any
    b7a4:	29430002 	ldp	w2, w0, [x0, #24]
    b7a8:	92403c21 	and	x1, x1, #0xffff
    b7ac:	9b027c21 	mul	x1, x1, x2
    b7b0:	d360fc21 	lsr	x1, x1, #32
    b7b4:	eb00003f 	cmp	x1, x0
    b7b8:	540000e2 	b.cs	b7d4 <f0+0x18c4>  // b.hs, b.nlast
    b7bc:	8b0102f7 	add	x23, x23, x1
    b7c0:	394002e0 	ldrb	w0, [x23]
    b7c4:	7103fc1f 	cmp	w0, #0xff
    b7c8:	54006820 	b.eq	c4cc <f0+0x25bc>  // b.none
    b7cc:	52800020 	mov	w0, #0x1                   	// #1
    b7d0:	390002e0 	strb	w0, [x23]
    b7d4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b7d8:	911763e1 	add	x1, sp, #0x5d8
    b7dc:	52800020 	mov	w0, #0x1                   	// #1
    b7e0:	f902efe2 	str	x2, [sp, #1496]
    b7e4:	f902f3f5 	str	x21, [sp, #1504]
    b7e8:	97ffe737 	bl	54c4 <fwp_data.part.0.constprop.0>
    b7ec:	91154283 	add	x3, x20, #0x550
    b7f0:	aa0003f7 	mov	x23, x0
    b7f4:	f949d861 	ldr	x1, [x3, #5040]
    b7f8:	f949ec60 	ldr	x0, [x3, #5080]
    b7fc:	cb0102e1 	sub	x1, x23, x1
    b800:	eb00403f 	cmp	x1, x0, lsl #16
    b804:	54000322 	b.cs	b868 <f0+0x1958>  // b.hs, b.nlast
    b808:	d350fc22 	lsr	x2, x1, #16
    b80c:	f949fc63 	ldr	x3, [x3, #5112]
    b810:	8b020842 	add	x2, x2, x2, lsl #2
    b814:	d37df042 	lsl	x2, x2, #3
    b818:	8b020060 	add	x0, x3, x2
    b81c:	f9401015 	ldr	x21, [x0, #32]
    b820:	b4000255 	cbz	x21, b868 <f0+0x1958>
    b824:	38626862 	ldrb	w2, [x3, x2]
    b828:	7100085f 	cmp	w2, #0x2
    b82c:	54005780 	b.eq	c31c <f0+0x240c>  // b.none
    b830:	7100045f 	cmp	w2, #0x1
    b834:	540001a1 	b.ne	b868 <f0+0x1958>  // b.any
    b838:	29430002 	ldp	w2, w0, [x0, #24]
    b83c:	92403c21 	and	x1, x1, #0xffff
    b840:	9b027c21 	mul	x1, x1, x2
    b844:	d360fc21 	lsr	x1, x1, #32
    b848:	eb00003f 	cmp	x1, x0
    b84c:	540000e2 	b.cs	b868 <f0+0x1958>  // b.hs, b.nlast
    b850:	8b0102b5 	add	x21, x21, x1
    b854:	394002a0 	ldrb	w0, [x21]
    b858:	7103fc1f 	cmp	w0, #0xff
    b85c:	540063e0 	b.eq	c4d8 <f0+0x25c8>  // b.none
    b860:	52800020 	mov	w0, #0x1                   	// #1
    b864:	390002a0 	strb	w0, [x21]
    b868:	9117a3e1 	add	x1, sp, #0x5e8
    b86c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b870:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b874:	52800020 	mov	w0, #0x1                   	// #1
    b878:	f902f7f5 	str	x21, [sp, #1512]
    b87c:	f902fbf7 	str	x23, [sp, #1520]
    b880:	97ffe711 	bl	54c4 <fwp_data.part.0.constprop.0>
    b884:	97ffe77f 	bl	5680 <fwp_rc_fresh>
    b888:	aa0003e2 	mov	x2, x0
    b88c:	9117e3e1 	add	x1, sp, #0x5f8
    b890:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b894:	52800020 	mov	w0, #0x1                   	// #1
    b898:	f902fff7 	str	x23, [sp, #1528]
    b89c:	f90303e2 	str	x2, [sp, #1536]
    b8a0:	97ffe709 	bl	54c4 <fwp_data.part.0.constprop.0>
    b8a4:	97ffe777 	bl	5680 <fwp_rc_fresh>
    b8a8:	aa0003e2 	mov	x2, x0
    b8ac:	911823e1 	add	x1, sp, #0x608
    b8b0:	52800020 	mov	w0, #0x1                   	// #1
    b8b4:	f90307f5 	str	x21, [sp, #1544]
    b8b8:	f9030be2 	str	x2, [sp, #1552]
    b8bc:	97ffe702 	bl	54c4 <fwp_data.part.0.constprop.0>
    b8c0:	97ffe770 	bl	5680 <fwp_rc_fresh>
    b8c4:	aa0003e2 	mov	x2, x0
    b8c8:	911863e1 	add	x1, sp, #0x618
    b8cc:	52800020 	mov	w0, #0x1                   	// #1
    b8d0:	f9030ff7 	str	x23, [sp, #1560]
    b8d4:	f90313e2 	str	x2, [sp, #1568]
    b8d8:	97ffe6fb 	bl	54c4 <fwp_data.part.0.constprop.0>
    b8dc:	97ffe769 	bl	5680 <fwp_rc_fresh>
    b8e0:	aa0003e2 	mov	x2, x0
    b8e4:	9118a3e1 	add	x1, sp, #0x628
    b8e8:	52800020 	mov	w0, #0x1                   	// #1
    b8ec:	f90317f5 	str	x21, [sp, #1576]
    b8f0:	f9031be2 	str	x2, [sp, #1584]
    b8f4:	97ffe6f4 	bl	54c4 <fwp_data.part.0.constprop.0>
    b8f8:	97ffe762 	bl	5680 <fwp_rc_fresh>
    b8fc:	aa0003e2 	mov	x2, x0
    b900:	9118e3e1 	add	x1, sp, #0x638
    b904:	52800020 	mov	w0, #0x1                   	// #1
    b908:	f9031ff7 	str	x23, [sp, #1592]
    b90c:	f90323e2 	str	x2, [sp, #1600]
    b910:	97ffe6ed 	bl	54c4 <fwp_data.part.0.constprop.0>
    b914:	97ffe75b 	bl	5680 <fwp_rc_fresh>
    b918:	aa0003e2 	mov	x2, x0
    b91c:	911923e1 	add	x1, sp, #0x648
    b920:	52800020 	mov	w0, #0x1                   	// #1
    b924:	f90327f5 	str	x21, [sp, #1608]
    b928:	f9032be2 	str	x2, [sp, #1616]
    b92c:	97ffe6e6 	bl	54c4 <fwp_data.part.0.constprop.0>
    b930:	91154283 	add	x3, x20, #0x550
    b934:	aa0003f5 	mov	x21, x0
    b938:	f949d861 	ldr	x1, [x3, #5040]
    b93c:	f949ec60 	ldr	x0, [x3, #5080]
    b940:	cb0102a1 	sub	x1, x21, x1
    b944:	eb00403f 	cmp	x1, x0, lsl #16
    b948:	54000322 	b.cs	b9ac <f0+0x1a9c>  // b.hs, b.nlast
    b94c:	d350fc22 	lsr	x2, x1, #16
    b950:	f949fc63 	ldr	x3, [x3, #5112]
    b954:	8b020842 	add	x2, x2, x2, lsl #2
    b958:	d37df042 	lsl	x2, x2, #3
    b95c:	8b020060 	add	x0, x3, x2
    b960:	f9401017 	ldr	x23, [x0, #32]
    b964:	b4000257 	cbz	x23, b9ac <f0+0x1a9c>
    b968:	38626862 	ldrb	w2, [x3, x2]
    b96c:	7100085f 	cmp	w2, #0x2
    b970:	54004d00 	b.eq	c310 <f0+0x2400>  // b.none
    b974:	7100045f 	cmp	w2, #0x1
    b978:	540001a1 	b.ne	b9ac <f0+0x1a9c>  // b.any
    b97c:	29430002 	ldp	w2, w0, [x0, #24]
    b980:	92403c21 	and	x1, x1, #0xffff
    b984:	9b027c21 	mul	x1, x1, x2
    b988:	d360fc21 	lsr	x1, x1, #32
    b98c:	eb00003f 	cmp	x1, x0
    b990:	540000e2 	b.cs	b9ac <f0+0x1a9c>  // b.hs, b.nlast
    b994:	8b0102f7 	add	x23, x23, x1
    b998:	394002e0 	ldrb	w0, [x23]
    b99c:	7103fc1f 	cmp	w0, #0xff
    b9a0:	54005a20 	b.eq	c4e4 <f0+0x25d4>  // b.none
    b9a4:	52800020 	mov	w0, #0x1                   	// #1
    b9a8:	390002e0 	strb	w0, [x23]
    b9ac:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b9b0:	911963e1 	add	x1, sp, #0x658
    b9b4:	52800020 	mov	w0, #0x1                   	// #1
    b9b8:	f9032fe2 	str	x2, [sp, #1624]
    b9bc:	f90333f5 	str	x21, [sp, #1632]
    b9c0:	97ffe6c1 	bl	54c4 <fwp_data.part.0.constprop.0>
    b9c4:	91154283 	add	x3, x20, #0x550
    b9c8:	aa0003f5 	mov	x21, x0
    b9cc:	f949d861 	ldr	x1, [x3, #5040]
    b9d0:	f949ec60 	ldr	x0, [x3, #5080]
    b9d4:	cb0102a1 	sub	x1, x21, x1
    b9d8:	eb00403f 	cmp	x1, x0, lsl #16
    b9dc:	54000322 	b.cs	ba40 <f0+0x1b30>  // b.hs, b.nlast
    b9e0:	d350fc22 	lsr	x2, x1, #16
    b9e4:	f949fc63 	ldr	x3, [x3, #5112]
    b9e8:	8b020842 	add	x2, x2, x2, lsl #2
    b9ec:	d37df042 	lsl	x2, x2, #3
    b9f0:	8b020060 	add	x0, x3, x2
    b9f4:	f9401017 	ldr	x23, [x0, #32]
    b9f8:	b4000257 	cbz	x23, ba40 <f0+0x1b30>
    b9fc:	38626862 	ldrb	w2, [x3, x2]
    ba00:	7100085f 	cmp	w2, #0x2
    ba04:	54004800 	b.eq	c304 <f0+0x23f4>  // b.none
    ba08:	7100045f 	cmp	w2, #0x1
    ba0c:	540001a1 	b.ne	ba40 <f0+0x1b30>  // b.any
    ba10:	29430002 	ldp	w2, w0, [x0, #24]
    ba14:	92403c21 	and	x1, x1, #0xffff
    ba18:	9b027c21 	mul	x1, x1, x2
    ba1c:	d360fc21 	lsr	x1, x1, #32
    ba20:	eb00003f 	cmp	x1, x0
    ba24:	540000e2 	b.cs	ba40 <f0+0x1b30>  // b.hs, b.nlast
    ba28:	8b0102f7 	add	x23, x23, x1
    ba2c:	394002e0 	ldrb	w0, [x23]
    ba30:	7103fc1f 	cmp	w0, #0xff
    ba34:	540055e0 	b.eq	c4f0 <f0+0x25e0>  // b.none
    ba38:	52800020 	mov	w0, #0x1                   	// #1
    ba3c:	390002e0 	strb	w0, [x23]
    ba40:	9119a3e1 	add	x1, sp, #0x668
    ba44:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ba48:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ba4c:	52800020 	mov	w0, #0x1                   	// #1
    ba50:	f90337f7 	str	x23, [sp, #1640]
    ba54:	f9033bf5 	str	x21, [sp, #1648]
    ba58:	97ffe69b 	bl	54c4 <fwp_data.part.0.constprop.0>
    ba5c:	97ffe709 	bl	5680 <fwp_rc_fresh>
    ba60:	aa0003e2 	mov	x2, x0
    ba64:	9119e3e1 	add	x1, sp, #0x678
    ba68:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ba6c:	52800020 	mov	w0, #0x1                   	// #1
    ba70:	f9033ff5 	str	x21, [sp, #1656]
    ba74:	f90343e2 	str	x2, [sp, #1664]
    ba78:	97ffe693 	bl	54c4 <fwp_data.part.0.constprop.0>
    ba7c:	97ffe701 	bl	5680 <fwp_rc_fresh>
    ba80:	aa0003e2 	mov	x2, x0
    ba84:	911a23e1 	add	x1, sp, #0x688
    ba88:	52800020 	mov	w0, #0x1                   	// #1
    ba8c:	f90347f7 	str	x23, [sp, #1672]
    ba90:	f9034be2 	str	x2, [sp, #1680]
    ba94:	97ffe68c 	bl	54c4 <fwp_data.part.0.constprop.0>
    ba98:	97ffe6fa 	bl	5680 <fwp_rc_fresh>
    ba9c:	aa0003e2 	mov	x2, x0
    baa0:	911a63e1 	add	x1, sp, #0x698
    baa4:	52800020 	mov	w0, #0x1                   	// #1
    baa8:	f9034ff5 	str	x21, [sp, #1688]
    baac:	f90353e2 	str	x2, [sp, #1696]
    bab0:	97ffe685 	bl	54c4 <fwp_data.part.0.constprop.0>
    bab4:	91154283 	add	x3, x20, #0x550
    bab8:	aa0003f5 	mov	x21, x0
    babc:	f949d861 	ldr	x1, [x3, #5040]
    bac0:	f949ec60 	ldr	x0, [x3, #5080]
    bac4:	cb0102a1 	sub	x1, x21, x1
    bac8:	eb00403f 	cmp	x1, x0, lsl #16
    bacc:	54000322 	b.cs	bb30 <f0+0x1c20>  // b.hs, b.nlast
    bad0:	d350fc22 	lsr	x2, x1, #16
    bad4:	f949fc63 	ldr	x3, [x3, #5112]
    bad8:	8b020842 	add	x2, x2, x2, lsl #2
    badc:	d37df042 	lsl	x2, x2, #3
    bae0:	8b020060 	add	x0, x3, x2
    bae4:	f9401017 	ldr	x23, [x0, #32]
    bae8:	b4000257 	cbz	x23, bb30 <f0+0x1c20>
    baec:	38626862 	ldrb	w2, [x3, x2]
    baf0:	7100085f 	cmp	w2, #0x2
    baf4:	54004020 	b.eq	c2f8 <f0+0x23e8>  // b.none
    baf8:	7100045f 	cmp	w2, #0x1
    bafc:	540001a1 	b.ne	bb30 <f0+0x1c20>  // b.any
    bb00:	29430002 	ldp	w2, w0, [x0, #24]
    bb04:	92403c21 	and	x1, x1, #0xffff
    bb08:	9b027c21 	mul	x1, x1, x2
    bb0c:	d360fc21 	lsr	x1, x1, #32
    bb10:	eb00003f 	cmp	x1, x0
    bb14:	540000e2 	b.cs	bb30 <f0+0x1c20>  // b.hs, b.nlast
    bb18:	8b0102f7 	add	x23, x23, x1
    bb1c:	394002e0 	ldrb	w0, [x23]
    bb20:	7103fc1f 	cmp	w0, #0xff
    bb24:	54004ec0 	b.eq	c4fc <f0+0x25ec>  // b.none
    bb28:	52800020 	mov	w0, #0x1                   	// #1
    bb2c:	390002e0 	strb	w0, [x23]
    bb30:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bb34:	911aa3e1 	add	x1, sp, #0x6a8
    bb38:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bb3c:	52800020 	mov	w0, #0x1                   	// #1
    bb40:	f90357e2 	str	x2, [sp, #1704]
    bb44:	f9035bf5 	str	x21, [sp, #1712]
    bb48:	97ffe65f 	bl	54c4 <fwp_data.part.0.constprop.0>
    bb4c:	97ffe6cd 	bl	5680 <fwp_rc_fresh>
    bb50:	aa0003e2 	mov	x2, x0
    bb54:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bb58:	911ae3e1 	add	x1, sp, #0x6b8
    bb5c:	52800020 	mov	w0, #0x1                   	// #1
    bb60:	f9035fe3 	str	x3, [sp, #1720]
    bb64:	f90363e2 	str	x2, [sp, #1728]
    bb68:	97ffe657 	bl	54c4 <fwp_data.part.0.constprop.0>
    bb6c:	91154283 	add	x3, x20, #0x550
    bb70:	aa0003f5 	mov	x21, x0
    bb74:	f949d861 	ldr	x1, [x3, #5040]
    bb78:	f949ec60 	ldr	x0, [x3, #5080]
    bb7c:	cb0102a1 	sub	x1, x21, x1
    bb80:	eb00403f 	cmp	x1, x0, lsl #16
    bb84:	54000322 	b.cs	bbe8 <f0+0x1cd8>  // b.hs, b.nlast
    bb88:	d350fc22 	lsr	x2, x1, #16
    bb8c:	f949fc63 	ldr	x3, [x3, #5112]
    bb90:	8b020842 	add	x2, x2, x2, lsl #2
    bb94:	d37df042 	lsl	x2, x2, #3
    bb98:	8b020060 	add	x0, x3, x2
    bb9c:	f9401017 	ldr	x23, [x0, #32]
    bba0:	b4000257 	cbz	x23, bbe8 <f0+0x1cd8>
    bba4:	38626862 	ldrb	w2, [x3, x2]
    bba8:	7100085f 	cmp	w2, #0x2
    bbac:	54003a00 	b.eq	c2ec <f0+0x23dc>  // b.none
    bbb0:	7100045f 	cmp	w2, #0x1
    bbb4:	540001a1 	b.ne	bbe8 <f0+0x1cd8>  // b.any
    bbb8:	29430002 	ldp	w2, w0, [x0, #24]
    bbbc:	92403c21 	and	x1, x1, #0xffff
    bbc0:	9b027c21 	mul	x1, x1, x2
    bbc4:	d360fc21 	lsr	x1, x1, #32
    bbc8:	eb00003f 	cmp	x1, x0
    bbcc:	540000e2 	b.cs	bbe8 <f0+0x1cd8>  // b.hs, b.nlast
    bbd0:	8b0102f7 	add	x23, x23, x1
    bbd4:	394002e0 	ldrb	w0, [x23]
    bbd8:	7103fc1f 	cmp	w0, #0xff
    bbdc:	54004960 	b.eq	c508 <f0+0x25f8>  // b.none
    bbe0:	52800020 	mov	w0, #0x1                   	// #1
    bbe4:	390002e0 	strb	w0, [x23]
    bbe8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bbec:	911b23e1 	add	x1, sp, #0x6c8
    bbf0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bbf4:	52800020 	mov	w0, #0x1                   	// #1
    bbf8:	f90367e2 	str	x2, [sp, #1736]
    bbfc:	f9036bf5 	str	x21, [sp, #1744]
    bc00:	97ffe631 	bl	54c4 <fwp_data.part.0.constprop.0>
    bc04:	91154283 	add	x3, x20, #0x550
    bc08:	aa0003f5 	mov	x21, x0
    bc0c:	f949d861 	ldr	x1, [x3, #5040]
    bc10:	f949ec60 	ldr	x0, [x3, #5080]
    bc14:	cb0102a1 	sub	x1, x21, x1
    bc18:	eb00403f 	cmp	x1, x0, lsl #16
    bc1c:	54000322 	b.cs	bc80 <f0+0x1d70>  // b.hs, b.nlast
    bc20:	d350fc22 	lsr	x2, x1, #16
    bc24:	f949fc63 	ldr	x3, [x3, #5112]
    bc28:	8b020842 	add	x2, x2, x2, lsl #2
    bc2c:	d37df042 	lsl	x2, x2, #3
    bc30:	8b020060 	add	x0, x3, x2
    bc34:	f9401017 	ldr	x23, [x0, #32]
    bc38:	b4000257 	cbz	x23, bc80 <f0+0x1d70>
    bc3c:	38626862 	ldrb	w2, [x3, x2]
    bc40:	7100085f 	cmp	w2, #0x2
    bc44:	540034e0 	b.eq	c2e0 <f0+0x23d0>  // b.none
    bc48:	7100045f 	cmp	w2, #0x1
    bc4c:	540001a1 	b.ne	bc80 <f0+0x1d70>  // b.any
    bc50:	29430002 	ldp	w2, w0, [x0, #24]
    bc54:	92403c21 	and	x1, x1, #0xffff
    bc58:	9b027c21 	mul	x1, x1, x2
    bc5c:	d360fc21 	lsr	x1, x1, #32
    bc60:	eb00003f 	cmp	x1, x0
    bc64:	540000e2 	b.cs	bc80 <f0+0x1d70>  // b.hs, b.nlast
    bc68:	8b0102f7 	add	x23, x23, x1
    bc6c:	394002e0 	ldrb	w0, [x23]
    bc70:	7103fc1f 	cmp	w0, #0xff
    bc74:	54004500 	b.eq	c514 <f0+0x2604>  // b.none
    bc78:	52800020 	mov	w0, #0x1                   	// #1
    bc7c:	390002e0 	strb	w0, [x23]
    bc80:	911b63e1 	add	x1, sp, #0x6d8
    bc84:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bc88:	52800020 	mov	w0, #0x1                   	// #1
    bc8c:	f9036ff7 	str	x23, [sp, #1752]
    bc90:	f90373f5 	str	x21, [sp, #1760]
    bc94:	97ffe60c 	bl	54c4 <fwp_data.part.0.constprop.0>
    bc98:	97ffe67a 	bl	5680 <fwp_rc_fresh>
    bc9c:	aa0003e2 	mov	x2, x0
    bca0:	911ba3e1 	add	x1, sp, #0x6e8
    bca4:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bca8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bcac:	52800020 	mov	w0, #0x1                   	// #1
    bcb0:	f90377f5 	str	x21, [sp, #1768]
    bcb4:	f9037be2 	str	x2, [sp, #1776]
    bcb8:	97ffe603 	bl	54c4 <fwp_data.part.0.constprop.0>
    bcbc:	97ffe671 	bl	5680 <fwp_rc_fresh>
    bcc0:	aa0003e2 	mov	x2, x0
    bcc4:	911be3e1 	add	x1, sp, #0x6f8
    bcc8:	52800020 	mov	w0, #0x1                   	// #1
    bccc:	f9037ff7 	str	x23, [sp, #1784]
    bcd0:	f90383e2 	str	x2, [sp, #1792]
    bcd4:	97ffe5fc 	bl	54c4 <fwp_data.part.0.constprop.0>
    bcd8:	97ffe66a 	bl	5680 <fwp_rc_fresh>
    bcdc:	aa0003e2 	mov	x2, x0
    bce0:	911c23e1 	add	x1, sp, #0x708
    bce4:	52800020 	mov	w0, #0x1                   	// #1
    bce8:	f90387f5 	str	x21, [sp, #1800]
    bcec:	f9038be2 	str	x2, [sp, #1808]
    bcf0:	97ffe5f5 	bl	54c4 <fwp_data.part.0.constprop.0>
    bcf4:	97ffe663 	bl	5680 <fwp_rc_fresh>
    bcf8:	aa0003e2 	mov	x2, x0
    bcfc:	911c63e1 	add	x1, sp, #0x718
    bd00:	52800020 	mov	w0, #0x1                   	// #1
    bd04:	f9038ff7 	str	x23, [sp, #1816]
    bd08:	f90393e2 	str	x2, [sp, #1824]
    bd0c:	97ffe5ee 	bl	54c4 <fwp_data.part.0.constprop.0>
    bd10:	91154283 	add	x3, x20, #0x550
    bd14:	aa0003f5 	mov	x21, x0
    bd18:	f949d861 	ldr	x1, [x3, #5040]
    bd1c:	f949ec60 	ldr	x0, [x3, #5080]
    bd20:	cb0102a1 	sub	x1, x21, x1
    bd24:	eb00403f 	cmp	x1, x0, lsl #16
    bd28:	54000322 	b.cs	bd8c <f0+0x1e7c>  // b.hs, b.nlast
    bd2c:	d350fc22 	lsr	x2, x1, #16
    bd30:	f949fc63 	ldr	x3, [x3, #5112]
    bd34:	8b020842 	add	x2, x2, x2, lsl #2
    bd38:	d37df042 	lsl	x2, x2, #3
    bd3c:	8b020060 	add	x0, x3, x2
    bd40:	f9401017 	ldr	x23, [x0, #32]
    bd44:	b4000257 	cbz	x23, bd8c <f0+0x1e7c>
    bd48:	38626862 	ldrb	w2, [x3, x2]
    bd4c:	7100085f 	cmp	w2, #0x2
    bd50:	54002c20 	b.eq	c2d4 <f0+0x23c4>  // b.none
    bd54:	7100045f 	cmp	w2, #0x1
    bd58:	540001a1 	b.ne	bd8c <f0+0x1e7c>  // b.any
    bd5c:	29430002 	ldp	w2, w0, [x0, #24]
    bd60:	92403c21 	and	x1, x1, #0xffff
    bd64:	9b027c21 	mul	x1, x1, x2
    bd68:	d360fc21 	lsr	x1, x1, #32
    bd6c:	eb00003f 	cmp	x1, x0
    bd70:	540000e2 	b.cs	bd8c <f0+0x1e7c>  // b.hs, b.nlast
    bd74:	8b0102f7 	add	x23, x23, x1
    bd78:	394002e0 	ldrb	w0, [x23]
    bd7c:	7103fc1f 	cmp	w0, #0xff
    bd80:	54003d00 	b.eq	c520 <f0+0x2610>  // b.none
    bd84:	52800020 	mov	w0, #0x1                   	// #1
    bd88:	390002e0 	strb	w0, [x23]
    bd8c:	911ca3e1 	add	x1, sp, #0x728
    bd90:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bd94:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bd98:	52800020 	mov	w0, #0x1                   	// #1
    bd9c:	f90397f7 	str	x23, [sp, #1832]
    bda0:	f9039bf5 	str	x21, [sp, #1840]
    bda4:	97ffe5c8 	bl	54c4 <fwp_data.part.0.constprop.0>
    bda8:	97ffe636 	bl	5680 <fwp_rc_fresh>
    bdac:	aa0003e2 	mov	x2, x0
    bdb0:	911ce3e1 	add	x1, sp, #0x738
    bdb4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bdb8:	52800020 	mov	w0, #0x1                   	// #1
    bdbc:	f9039ff5 	str	x21, [sp, #1848]
    bdc0:	f903a3e2 	str	x2, [sp, #1856]
    bdc4:	97ffe5c0 	bl	54c4 <fwp_data.part.0.constprop.0>
    bdc8:	97ffe62e 	bl	5680 <fwp_rc_fresh>
    bdcc:	aa0003e2 	mov	x2, x0
    bdd0:	911d23e1 	add	x1, sp, #0x748
    bdd4:	52800020 	mov	w0, #0x1                   	// #1
    bdd8:	f903a7f7 	str	x23, [sp, #1864]
    bddc:	f903abe2 	str	x2, [sp, #1872]
    bde0:	97ffe5b9 	bl	54c4 <fwp_data.part.0.constprop.0>
    bde4:	97ffe627 	bl	5680 <fwp_rc_fresh>
    bde8:	aa0003e2 	mov	x2, x0
    bdec:	911d63e1 	add	x1, sp, #0x758
    bdf0:	52800020 	mov	w0, #0x1                   	// #1
    bdf4:	f903aff5 	str	x21, [sp, #1880]
    bdf8:	f903b3e2 	str	x2, [sp, #1888]
    bdfc:	97ffe5b2 	bl	54c4 <fwp_data.part.0.constprop.0>
    be00:	91154283 	add	x3, x20, #0x550
    be04:	aa0003f5 	mov	x21, x0
    be08:	f949d861 	ldr	x1, [x3, #5040]
    be0c:	f949ec60 	ldr	x0, [x3, #5080]
    be10:	cb0102a1 	sub	x1, x21, x1
    be14:	eb00403f 	cmp	x1, x0, lsl #16
    be18:	54000322 	b.cs	be7c <f0+0x1f6c>  // b.hs, b.nlast
    be1c:	d350fc22 	lsr	x2, x1, #16
    be20:	f949fc63 	ldr	x3, [x3, #5112]
    be24:	8b020842 	add	x2, x2, x2, lsl #2
    be28:	d37df042 	lsl	x2, x2, #3
    be2c:	8b020060 	add	x0, x3, x2
    be30:	f9401017 	ldr	x23, [x0, #32]
    be34:	b4000257 	cbz	x23, be7c <f0+0x1f6c>
    be38:	38626862 	ldrb	w2, [x3, x2]
    be3c:	7100085f 	cmp	w2, #0x2
    be40:	54002440 	b.eq	c2c8 <f0+0x23b8>  // b.none
    be44:	7100045f 	cmp	w2, #0x1
    be48:	540001a1 	b.ne	be7c <f0+0x1f6c>  // b.any
    be4c:	29430002 	ldp	w2, w0, [x0, #24]
    be50:	92403c21 	and	x1, x1, #0xffff
    be54:	9b027c21 	mul	x1, x1, x2
    be58:	d360fc21 	lsr	x1, x1, #32
    be5c:	eb00003f 	cmp	x1, x0
    be60:	540000e2 	b.cs	be7c <f0+0x1f6c>  // b.hs, b.nlast
    be64:	8b0102f7 	add	x23, x23, x1
    be68:	394002e0 	ldrb	w0, [x23]
    be6c:	7103fc1f 	cmp	w0, #0xff
    be70:	540035e0 	b.eq	c52c <f0+0x261c>  // b.none
    be74:	52800020 	mov	w0, #0x1                   	// #1
    be78:	390002e0 	strb	w0, [x23]
    be7c:	911da3e1 	add	x1, sp, #0x768
    be80:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    be84:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    be88:	52800020 	mov	w0, #0x1                   	// #1
    be8c:	f903b7f7 	str	x23, [sp, #1896]
    be90:	f903bbf5 	str	x21, [sp, #1904]
    be94:	97ffe58c 	bl	54c4 <fwp_data.part.0.constprop.0>
    be98:	97ffe5fa 	bl	5680 <fwp_rc_fresh>
    be9c:	aa0003e2 	mov	x2, x0
    bea0:	911de3e1 	add	x1, sp, #0x778
    bea4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bea8:	52800020 	mov	w0, #0x1                   	// #1
    beac:	f903bff5 	str	x21, [sp, #1912]
    beb0:	f903c3e2 	str	x2, [sp, #1920]
    beb4:	97ffe584 	bl	54c4 <fwp_data.part.0.constprop.0>
    beb8:	97ffe5f2 	bl	5680 <fwp_rc_fresh>
    bebc:	aa0003e2 	mov	x2, x0
    bec0:	911e23e1 	add	x1, sp, #0x788
    bec4:	52800020 	mov	w0, #0x1                   	// #1
    bec8:	f903c7f7 	str	x23, [sp, #1928]
    becc:	f903cbe2 	str	x2, [sp, #1936]
    bed0:	97ffe57d 	bl	54c4 <fwp_data.part.0.constprop.0>
    bed4:	97ffe5eb 	bl	5680 <fwp_rc_fresh>
    bed8:	aa0003e2 	mov	x2, x0
    bedc:	911e63e1 	add	x1, sp, #0x798
    bee0:	52800020 	mov	w0, #0x1                   	// #1
    bee4:	f903cff5 	str	x21, [sp, #1944]
    bee8:	f903d3e2 	str	x2, [sp, #1952]
    beec:	97ffe576 	bl	54c4 <fwp_data.part.0.constprop.0>
    bef0:	97ffe5e4 	bl	5680 <fwp_rc_fresh>
    bef4:	aa0003e2 	mov	x2, x0
    bef8:	911ea3e1 	add	x1, sp, #0x7a8
    befc:	52800020 	mov	w0, #0x1                   	// #1
    bf00:	f903d7f7 	str	x23, [sp, #1960]
    bf04:	f903dbe2 	str	x2, [sp, #1968]
    bf08:	97ffe56f 	bl	54c4 <fwp_data.part.0.constprop.0>
    bf0c:	97ffe5dd 	bl	5680 <fwp_rc_fresh>
    bf10:	aa0003e2 	mov	x2, x0
    bf14:	911ee3e1 	add	x1, sp, #0x7b8
    bf18:	52800020 	mov	w0, #0x1                   	// #1
    bf1c:	f903dff5 	str	x21, [sp, #1976]
    bf20:	f903e3e2 	str	x2, [sp, #1984]
    bf24:	97ffe568 	bl	54c4 <fwp_data.part.0.constprop.0>
    bf28:	91154283 	add	x3, x20, #0x550
    bf2c:	aa0003f5 	mov	x21, x0
    bf30:	f949d861 	ldr	x1, [x3, #5040]
    bf34:	f949ec60 	ldr	x0, [x3, #5080]
    bf38:	cb0102a1 	sub	x1, x21, x1
    bf3c:	eb00403f 	cmp	x1, x0, lsl #16
    bf40:	54000322 	b.cs	bfa4 <f0+0x2094>  // b.hs, b.nlast
    bf44:	d350fc22 	lsr	x2, x1, #16
    bf48:	f949fc63 	ldr	x3, [x3, #5112]
    bf4c:	8b020842 	add	x2, x2, x2, lsl #2
    bf50:	d37df042 	lsl	x2, x2, #3
    bf54:	8b020060 	add	x0, x3, x2
    bf58:	f9401017 	ldr	x23, [x0, #32]
    bf5c:	b4000257 	cbz	x23, bfa4 <f0+0x2094>
    bf60:	38626862 	ldrb	w2, [x3, x2]
    bf64:	7100085f 	cmp	w2, #0x2
    bf68:	54001aa0 	b.eq	c2bc <f0+0x23ac>  // b.none
    bf6c:	7100045f 	cmp	w2, #0x1
    bf70:	540001a1 	b.ne	bfa4 <f0+0x2094>  // b.any
    bf74:	29430002 	ldp	w2, w0, [x0, #24]
    bf78:	92403c21 	and	x1, x1, #0xffff
    bf7c:	9b027c21 	mul	x1, x1, x2
    bf80:	d360fc21 	lsr	x1, x1, #32
    bf84:	eb00003f 	cmp	x1, x0
    bf88:	540000e2 	b.cs	bfa4 <f0+0x2094>  // b.hs, b.nlast
    bf8c:	8b0102f7 	add	x23, x23, x1
    bf90:	394002e0 	ldrb	w0, [x23]
    bf94:	7103fc1f 	cmp	w0, #0xff
    bf98:	54002d00 	b.eq	c538 <f0+0x2628>  // b.none
    bf9c:	52800020 	mov	w0, #0x1                   	// #1
    bfa0:	390002e0 	strb	w0, [x23]
    bfa4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bfa8:	91154294 	add	x20, x20, #0x550
    bfac:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bfb0:	911f23e1 	add	x1, sp, #0x7c8
    bfb4:	52800020 	mov	w0, #0x1                   	// #1
    bfb8:	f903e7e2 	str	x2, [sp, #1992]
    bfbc:	f903ebf5 	str	x21, [sp, #2000]
    bfc0:	97ffe541 	bl	54c4 <fwp_data.part.0.constprop.0>
    bfc4:	f949da81 	ldr	x1, [x20, #5040]
    bfc8:	aa0003f7 	mov	x23, x0
    bfcc:	f949ee80 	ldr	x0, [x20, #5080]
    bfd0:	cb0102e1 	sub	x1, x23, x1
    bfd4:	eb00403f 	cmp	x1, x0, lsl #16
    bfd8:	54000322 	b.cs	c03c <f0+0x212c>  // b.hs, b.nlast
    bfdc:	d350fc22 	lsr	x2, x1, #16
    bfe0:	f949fe83 	ldr	x3, [x20, #5112]
    bfe4:	8b020842 	add	x2, x2, x2, lsl #2
    bfe8:	d37df042 	lsl	x2, x2, #3
    bfec:	8b020060 	add	x0, x3, x2
    bff0:	f9401014 	ldr	x20, [x0, #32]
    bff4:	b4000254 	cbz	x20, c03c <f0+0x212c>
    bff8:	38626862 	ldrb	w2, [x3, x2]
    bffc:	7100085f 	cmp	w2, #0x2
    c000:	54001580 	b.eq	c2b0 <f0+0x23a0>  // b.none
    c004:	7100045f 	cmp	w2, #0x1
    c008:	540001a1 	b.ne	c03c <f0+0x212c>  // b.any
    c00c:	29430002 	ldp	w2, w0, [x0, #24]
    c010:	92403c21 	and	x1, x1, #0xffff
    c014:	9b027c21 	mul	x1, x1, x2
    c018:	d360fc21 	lsr	x1, x1, #32
    c01c:	eb00003f 	cmp	x1, x0
    c020:	540000e2 	b.cs	c03c <f0+0x212c>  // b.hs, b.nlast
    c024:	8b010294 	add	x20, x20, x1
    c028:	39400280 	ldrb	w0, [x20]
    c02c:	7103fc1f 	cmp	w0, #0xff
    c030:	54001a00 	b.eq	c370 <f0+0x2460>  // b.none
    c034:	52800020 	mov	w0, #0x1                   	// #1
    c038:	39000280 	strb	w0, [x20]
    c03c:	911f63e1 	add	x1, sp, #0x7d8
    c040:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c044:	52800020 	mov	w0, #0x1                   	// #1
    c048:	f903eff5 	str	x21, [sp, #2008]
    c04c:	f903f3f7 	str	x23, [sp, #2016]
    c050:	97ffe51d 	bl	54c4 <fwp_data.part.0.constprop.0>
    c054:	97ffe58b 	bl	5680 <fwp_rc_fresh>
    c058:	aa0003e2 	mov	x2, x0
    c05c:	911fa3e1 	add	x1, sp, #0x7e8
    c060:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    c064:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    c068:	52800020 	mov	w0, #0x1                   	// #1
    c06c:	f903f7f4 	str	x20, [sp, #2024]
    c070:	f903fbe2 	str	x2, [sp, #2032]
    c074:	97ffe514 	bl	54c4 <fwp_data.part.0.constprop.0>
    c078:	97ffe582 	bl	5680 <fwp_rc_fresh>
    c07c:	aa0003e2 	mov	x2, x0
    c080:	911fe3e1 	add	x1, sp, #0x7f8
    c084:	52800020 	mov	w0, #0x1                   	// #1
    c088:	f903fff5 	str	x21, [sp, #2040]
    c08c:	f90403e2 	str	x2, [sp, #2048]
    c090:	97ffe50d 	bl	54c4 <fwp_data.part.0.constprop.0>
    c094:	97ffe57b 	bl	5680 <fwp_rc_fresh>
    c098:	aa0003e2 	mov	x2, x0
    c09c:	912023e1 	add	x1, sp, #0x808
    c0a0:	52800020 	mov	w0, #0x1                   	// #1
    c0a4:	f90407f4 	str	x20, [sp, #2056]
    c0a8:	f9040be2 	str	x2, [sp, #2064]
    c0ac:	97ffe506 	bl	54c4 <fwp_data.part.0.constprop.0>
    c0b0:	97ffe574 	bl	5680 <fwp_rc_fresh>
    c0b4:	aa0003e2 	mov	x2, x0
    c0b8:	912063e1 	add	x1, sp, #0x818
    c0bc:	52800020 	mov	w0, #0x1                   	// #1
    c0c0:	f9040ff5 	str	x21, [sp, #2072]
    c0c4:	f90413e2 	str	x2, [sp, #2080]
    c0c8:	97ffe4ff 	bl	54c4 <fwp_data.part.0.constprop.0>
    c0cc:	97ffe56d 	bl	5680 <fwp_rc_fresh>
    c0d0:	aa0003e2 	mov	x2, x0
    c0d4:	9120a3e1 	add	x1, sp, #0x828
    c0d8:	52800020 	mov	w0, #0x1                   	// #1
    c0dc:	f90417f4 	str	x20, [sp, #2088]
    c0e0:	f9041be2 	str	x2, [sp, #2096]
    c0e4:	97ffe4f8 	bl	54c4 <fwp_data.part.0.constprop.0>
    c0e8:	97ffe566 	bl	5680 <fwp_rc_fresh>
    c0ec:	aa0003e2 	mov	x2, x0
    c0f0:	9120e3e1 	add	x1, sp, #0x838
    c0f4:	52800020 	mov	w0, #0x1                   	// #1
    c0f8:	f9041ff5 	str	x21, [sp, #2104]
    c0fc:	f90423e2 	str	x2, [sp, #2112]
    c100:	97ffe4f1 	bl	54c4 <fwp_data.part.0.constprop.0>
    c104:	97ffe55f 	bl	5680 <fwp_rc_fresh>
    c108:	aa0003e2 	mov	x2, x0
    c10c:	aa1603e1 	mov	x1, x22
    c110:	52800020 	mov	w0, #0x1                   	// #1
    c114:	f90427f4 	str	x20, [sp, #2120]
    c118:	f9042be2 	str	x2, [sp, #2128]
    c11c:	97ffe4ea 	bl	54c4 <fwp_data.part.0.constprop.0>
    c120:	97ffe558 	bl	5680 <fwp_rc_fresh>
    c124:	aa0003f5 	mov	x21, x0
    c128:	aa1303e1 	mov	x1, x19
    c12c:	97fff485 	bl	9340 <fwp_hof0.constprop.0>
    c130:	aa0003f4 	mov	x20, x0
    c134:	aa1503e0 	mov	x0, x21
    c138:	97ffe6aa 	bl	5be0 <fwp_drop0>
    c13c:	aa1303e0 	mov	x0, x19
    c140:	97ffe6a8 	bl	5be0 <fwp_drop0>
    c144:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c148:	f947f400 	ldr	x0, [x0, #4072]
    c14c:	f9442fe2 	ldr	x2, [sp, #2136]
    c150:	f9400001 	ldr	x1, [x0]
    c154:	eb010042 	subs	x2, x2, x1
    c158:	d2800001 	mov	x1, #0x0                   	// #0
    c15c:	54001f41 	b.ne	c544 <f0+0x2634>  // b.any
    c160:	912183ff 	add	sp, sp, #0x860
    c164:	aa1403e0 	mov	x0, x20
    c168:	a94153f3 	ldp	x19, x20, [sp, #16]
    c16c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c170:	a94363f7 	ldp	x23, x24, [sp, #48]
    c174:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c178:	a94573fb 	ldp	x27, x28, [sp, #80]
    c17c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c180:	d65f03c0 	ret
    c184:	aa1b03e0 	mov	x0, x27
    c188:	97ffe0da 	bl	44f0 <fwp_rc_forget_slot>
    c18c:	17fff7a9 	b	a030 <f0+0x120>
    c190:	72003c5f 	tst	w2, #0xffff
    c194:	54fef501 	b.ne	a034 <f0+0x124>  // b.any
    c198:	17fff7a3 	b	a024 <f0+0x114>
    c19c:	72003c3f 	tst	w1, #0xffff
    c1a0:	54ff8961 	b.ne	b2cc <f0+0x13bc>  // b.any
    c1a4:	17fffc45 	b	b2b8 <f0+0x13a8>
    c1a8:	72003c3f 	tst	w1, #0xffff
    c1ac:	54ff8181 	b.ne	b1dc <f0+0x12cc>  // b.any
    c1b0:	17fffc06 	b	b1c8 <f0+0x12b8>
    c1b4:	72003c3f 	tst	w1, #0xffff
    c1b8:	54ff7621 	b.ne	b07c <f0+0x116c>  // b.any
    c1bc:	17fffbab 	b	b068 <f0+0x1158>
    c1c0:	72003c3f 	tst	w1, #0xffff
    c1c4:	54ff69e1 	b.ne	af00 <f0+0xff0>  // b.any
    c1c8:	17fffb49 	b	aeec <f0+0xfdc>
    c1cc:	72003c3f 	tst	w1, #0xffff
    c1d0:	54ff62e1 	b.ne	ae2c <f0+0xf1c>  // b.any
    c1d4:	17fffb11 	b	ae18 <f0+0xf08>
    c1d8:	72003c3f 	tst	w1, #0xffff
    c1dc:	54ff5b01 	b.ne	ad3c <f0+0xe2c>  // b.any
    c1e0:	17fffad2 	b	ad28 <f0+0xe18>
    c1e4:	72003c3f 	tst	w1, #0xffff
    c1e8:	54ff5601 	b.ne	aca8 <f0+0xd98>  // b.any
    c1ec:	17fffaaa 	b	ac94 <f0+0xd84>
    c1f0:	72003c3f 	tst	w1, #0xffff
    c1f4:	54ff50e1 	b.ne	ac10 <f0+0xd00>  // b.any
    c1f8:	17fffa81 	b	abfc <f0+0xcec>
    c1fc:	72003c3f 	tst	w1, #0xffff
    c200:	54ff0201 	b.ne	a240 <f0+0x330>  // b.any
    c204:	17fff80a 	b	a22c <f0+0x31c>
    c208:	72003c3f 	tst	w1, #0xffff
    c20c:	54fefd01 	b.ne	a1ac <f0+0x29c>  // b.any
    c210:	17fff7e2 	b	a198 <f0+0x288>
    c214:	72003c3f 	tst	w1, #0xffff
    c218:	54fef661 	b.ne	a0e4 <f0+0x1d4>  // b.any
    c21c:	17fff7ad 	b	a0d0 <f0+0x1c0>
    c220:	72003c3f 	tst	w1, #0xffff
    c224:	54ff1be1 	b.ne	a5a0 <f0+0x690>  // b.any
    c228:	17fff8d9 	b	a58c <f0+0x67c>
    c22c:	72003c3f 	tst	w1, #0xffff
    c230:	54ff1601 	b.ne	a4f0 <f0+0x5e0>  // b.any
    c234:	17fff8aa 	b	a4dc <f0+0x5cc>
    c238:	72003c3f 	tst	w1, #0xffff
    c23c:	54ff1121 	b.ne	a460 <f0+0x550>  // b.any
    c240:	17fff883 	b	a44c <f0+0x53c>
    c244:	72003c3f 	tst	w1, #0xffff
    c248:	54ff0541 	b.ne	a2f0 <f0+0x3e0>  // b.any
    c24c:	17fff824 	b	a2dc <f0+0x3cc>
    c250:	72003c3f 	tst	w1, #0xffff
    c254:	54ff4941 	b.ne	ab7c <f0+0xc6c>  // b.any
    c258:	17fffa44 	b	ab68 <f0+0xc58>
    c25c:	72003c3f 	tst	w1, #0xffff
    c260:	54ff4081 	b.ne	aa70 <f0+0xb60>  // b.any
    c264:	17fff9fe 	b	aa5c <f0+0xb4c>
    c268:	72003c3f 	tst	w1, #0xffff
    c26c:	54ff3b81 	b.ne	a9dc <f0+0xacc>  // b.any
    c270:	17fff9d6 	b	a9c8 <f0+0xab8>
    c274:	72003c3f 	tst	w1, #0xffff
    c278:	54ff3661 	b.ne	a944 <f0+0xa34>  // b.any
    c27c:	17fff9ad 	b	a930 <f0+0xa20>
    c280:	72003c3f 	tst	w1, #0xffff
    c284:	54ff2e81 	b.ne	a854 <f0+0x944>  // b.any
    c288:	17fff96e 	b	a840 <f0+0x930>
    c28c:	72003c3f 	tst	w1, #0xffff
    c290:	54ff28a1 	b.ne	a7a4 <f0+0x894>  // b.any
    c294:	17fff93f 	b	a790 <f0+0x880>
    c298:	72003c3f 	tst	w1, #0xffff
    c29c:	54ff23c1 	b.ne	a714 <f0+0x804>  // b.any
    c2a0:	17fff918 	b	a700 <f0+0x7f0>
    c2a4:	72003c3f 	tst	w1, #0xffff
    c2a8:	54ff1ec1 	b.ne	a680 <f0+0x770>  // b.any
    c2ac:	17fff8f0 	b	a66c <f0+0x75c>
    c2b0:	72003c3f 	tst	w1, #0xffff
    c2b4:	54ffec41 	b.ne	c03c <f0+0x212c>  // b.any
    c2b8:	17ffff5c 	b	c028 <f0+0x2118>
    c2bc:	72003c3f 	tst	w1, #0xffff
    c2c0:	54ffe721 	b.ne	bfa4 <f0+0x2094>  // b.any
    c2c4:	17ffff33 	b	bf90 <f0+0x2080>
    c2c8:	72003c3f 	tst	w1, #0xffff
    c2cc:	54ffdd81 	b.ne	be7c <f0+0x1f6c>  // b.any
    c2d0:	17fffee6 	b	be68 <f0+0x1f58>
    c2d4:	72003c3f 	tst	w1, #0xffff
    c2d8:	54ffd5a1 	b.ne	bd8c <f0+0x1e7c>  // b.any
    c2dc:	17fffea7 	b	bd78 <f0+0x1e68>
    c2e0:	72003c3f 	tst	w1, #0xffff
    c2e4:	54ffcce1 	b.ne	bc80 <f0+0x1d70>  // b.any
    c2e8:	17fffe61 	b	bc6c <f0+0x1d5c>
    c2ec:	72003c3f 	tst	w1, #0xffff
    c2f0:	54ffc7c1 	b.ne	bbe8 <f0+0x1cd8>  // b.any
    c2f4:	17fffe38 	b	bbd4 <f0+0x1cc4>
    c2f8:	72003c3f 	tst	w1, #0xffff
    c2fc:	54ffc1a1 	b.ne	bb30 <f0+0x1c20>  // b.any
    c300:	17fffe07 	b	bb1c <f0+0x1c0c>
    c304:	72003c3f 	tst	w1, #0xffff
    c308:	54ffb9c1 	b.ne	ba40 <f0+0x1b30>  // b.any
    c30c:	17fffdc8 	b	ba2c <f0+0x1b1c>
    c310:	72003c3f 	tst	w1, #0xffff
    c314:	54ffb4c1 	b.ne	b9ac <f0+0x1a9c>  // b.any
    c318:	17fffda0 	b	b998 <f0+0x1a88>
    c31c:	72003c3f 	tst	w1, #0xffff
    c320:	54ffaa41 	b.ne	b868 <f0+0x1958>  // b.any
    c324:	17fffd4c 	b	b854 <f0+0x1944>
    c328:	72003c3f 	tst	w1, #0xffff
    c32c:	54ffa541 	b.ne	b7d4 <f0+0x18c4>  // b.any
    c330:	17fffd24 	b	b7c0 <f0+0x18b0>
    c334:	72003c3f 	tst	w1, #0xffff
    c338:	54ffa021 	b.ne	b73c <f0+0x182c>  // b.any
    c33c:	17fffcfb 	b	b728 <f0+0x1818>
    c340:	72003c3f 	tst	w1, #0xffff
    c344:	54ff93e1 	b.ne	b5c0 <f0+0x16b0>  // b.any
    c348:	17fffc99 	b	b5ac <f0+0x169c>
    c34c:	72003c3f 	tst	w1, #0xffff
    c350:	54ff8ec1 	b.ne	b528 <f0+0x1618>  // b.any
    c354:	17fffc70 	b	b514 <f0+0x1604>
    c358:	72003c3f 	tst	w1, #0xffff
    c35c:	54ff8601 	b.ne	b41c <f0+0x150c>  // b.any
    c360:	17fffc2a 	b	b408 <f0+0x14f8>
    c364:	72003c3f 	tst	w1, #0xffff
    c368:	54ff80e1 	b.ne	b384 <f0+0x1474>  // b.any
    c36c:	17fffc01 	b	b370 <f0+0x1460>
    c370:	aa1403e0 	mov	x0, x20
    c374:	97ffe05f 	bl	44f0 <fwp_rc_forget_slot>
    c378:	17ffff2f 	b	c034 <f0+0x2124>
    c37c:	aa1703e0 	mov	x0, x23
    c380:	97ffe05c 	bl	44f0 <fwp_rc_forget_slot>
    c384:	17fff756 	b	a0dc <f0+0x1cc>
    c388:	aa1703e0 	mov	x0, x23
    c38c:	97ffe059 	bl	44f0 <fwp_rc_forget_slot>
    c390:	17fff785 	b	a1a4 <f0+0x294>
    c394:	aa1703e0 	mov	x0, x23
    c398:	97ffe056 	bl	44f0 <fwp_rc_forget_slot>
    c39c:	17fff7a7 	b	a238 <f0+0x328>
    c3a0:	aa1703e0 	mov	x0, x23
    c3a4:	97ffe053 	bl	44f0 <fwp_rc_forget_slot>
    c3a8:	17fff7d0 	b	a2e8 <f0+0x3d8>
    c3ac:	aa1703e0 	mov	x0, x23
    c3b0:	97ffe050 	bl	44f0 <fwp_rc_forget_slot>
    c3b4:	17fff829 	b	a458 <f0+0x548>
    c3b8:	aa1703e0 	mov	x0, x23
    c3bc:	97ffe04d 	bl	44f0 <fwp_rc_forget_slot>
    c3c0:	17fff84a 	b	a4e8 <f0+0x5d8>
    c3c4:	aa1703e0 	mov	x0, x23
    c3c8:	97ffe04a 	bl	44f0 <fwp_rc_forget_slot>
    c3cc:	17fff873 	b	a598 <f0+0x688>
    c3d0:	aa1703e0 	mov	x0, x23
    c3d4:	97ffe047 	bl	44f0 <fwp_rc_forget_slot>
    c3d8:	17fff8a8 	b	a678 <f0+0x768>
    c3dc:	aa1703e0 	mov	x0, x23
    c3e0:	97ffe044 	bl	44f0 <fwp_rc_forget_slot>
    c3e4:	17fff8ca 	b	a70c <f0+0x7fc>
    c3e8:	aa1703e0 	mov	x0, x23
    c3ec:	97ffe041 	bl	44f0 <fwp_rc_forget_slot>
    c3f0:	17fff8eb 	b	a79c <f0+0x88c>
    c3f4:	aa1703e0 	mov	x0, x23
    c3f8:	97ffe03e 	bl	44f0 <fwp_rc_forget_slot>
    c3fc:	17fff914 	b	a84c <f0+0x93c>
    c400:	aa1703e0 	mov	x0, x23
    c404:	97ffe03b 	bl	44f0 <fwp_rc_forget_slot>
    c408:	17fff94d 	b	a93c <f0+0xa2c>
    c40c:	aa1703e0 	mov	x0, x23
    c410:	97ffe038 	bl	44f0 <fwp_rc_forget_slot>
    c414:	17fff970 	b	a9d4 <f0+0xac4>
    c418:	aa1703e0 	mov	x0, x23
    c41c:	97ffe035 	bl	44f0 <fwp_rc_forget_slot>
    c420:	17fff992 	b	aa68 <f0+0xb58>
    c424:	aa1703e0 	mov	x0, x23
    c428:	97ffe032 	bl	44f0 <fwp_rc_forget_slot>
    c42c:	17fff9d2 	b	ab74 <f0+0xc64>
    c430:	aa1703e0 	mov	x0, x23
    c434:	97ffe02f 	bl	44f0 <fwp_rc_forget_slot>
    c438:	17fff9f4 	b	ac08 <f0+0xcf8>
    c43c:	aa1703e0 	mov	x0, x23
    c440:	97ffe02c 	bl	44f0 <fwp_rc_forget_slot>
    c444:	17fffa17 	b	aca0 <f0+0xd90>
    c448:	aa1703e0 	mov	x0, x23
    c44c:	97ffe029 	bl	44f0 <fwp_rc_forget_slot>
    c450:	17fffa39 	b	ad34 <f0+0xe24>
    c454:	aa1703e0 	mov	x0, x23
    c458:	97ffe026 	bl	44f0 <fwp_rc_forget_slot>
    c45c:	17fffa72 	b	ae24 <f0+0xf14>
    c460:	aa1503e0 	mov	x0, x21
    c464:	97ffe023 	bl	44f0 <fwp_rc_forget_slot>
    c468:	17fffaa4 	b	aef8 <f0+0xfe8>
    c46c:	aa1703e0 	mov	x0, x23
    c470:	97ffe020 	bl	44f0 <fwp_rc_forget_slot>
    c474:	17fffb00 	b	b074 <f0+0x1164>
    c478:	aa1703e0 	mov	x0, x23
    c47c:	97ffe01d 	bl	44f0 <fwp_rc_forget_slot>
    c480:	17fffb55 	b	b1d4 <f0+0x12c4>
    c484:	aa1703e0 	mov	x0, x23
    c488:	97ffe01a 	bl	44f0 <fwp_rc_forget_slot>
    c48c:	17fffb8e 	b	b2c4 <f0+0x13b4>
    c490:	aa1703e0 	mov	x0, x23
    c494:	97ffe017 	bl	44f0 <fwp_rc_forget_slot>
    c498:	17fffbb9 	b	b37c <f0+0x146c>
    c49c:	aa1703e0 	mov	x0, x23
    c4a0:	97ffe014 	bl	44f0 <fwp_rc_forget_slot>
    c4a4:	17fffbdc 	b	b414 <f0+0x1504>
    c4a8:	aa1703e0 	mov	x0, x23
    c4ac:	97ffe011 	bl	44f0 <fwp_rc_forget_slot>
    c4b0:	17fffc1c 	b	b520 <f0+0x1610>
    c4b4:	aa1503e0 	mov	x0, x21
    c4b8:	97ffe00e 	bl	44f0 <fwp_rc_forget_slot>
    c4bc:	17fffc3f 	b	b5b8 <f0+0x16a8>
    c4c0:	aa1703e0 	mov	x0, x23
    c4c4:	97ffe00b 	bl	44f0 <fwp_rc_forget_slot>
    c4c8:	17fffc9b 	b	b734 <f0+0x1824>
    c4cc:	aa1703e0 	mov	x0, x23
    c4d0:	97ffe008 	bl	44f0 <fwp_rc_forget_slot>
    c4d4:	17fffcbe 	b	b7cc <f0+0x18bc>
    c4d8:	aa1503e0 	mov	x0, x21
    c4dc:	97ffe005 	bl	44f0 <fwp_rc_forget_slot>
    c4e0:	17fffce0 	b	b860 <f0+0x1950>
    c4e4:	aa1703e0 	mov	x0, x23
    c4e8:	97ffe002 	bl	44f0 <fwp_rc_forget_slot>
    c4ec:	17fffd2e 	b	b9a4 <f0+0x1a94>
    c4f0:	aa1703e0 	mov	x0, x23
    c4f4:	97ffdfff 	bl	44f0 <fwp_rc_forget_slot>
    c4f8:	17fffd50 	b	ba38 <f0+0x1b28>
    c4fc:	aa1703e0 	mov	x0, x23
    c500:	97ffdffc 	bl	44f0 <fwp_rc_forget_slot>
    c504:	17fffd89 	b	bb28 <f0+0x1c18>
    c508:	aa1703e0 	mov	x0, x23
    c50c:	97ffdff9 	bl	44f0 <fwp_rc_forget_slot>
    c510:	17fffdb4 	b	bbe0 <f0+0x1cd0>
    c514:	aa1703e0 	mov	x0, x23
    c518:	97ffdff6 	bl	44f0 <fwp_rc_forget_slot>
    c51c:	17fffdd7 	b	bc78 <f0+0x1d68>
    c520:	aa1703e0 	mov	x0, x23
    c524:	97ffdff3 	bl	44f0 <fwp_rc_forget_slot>
    c528:	17fffe17 	b	bd84 <f0+0x1e74>
    c52c:	aa1703e0 	mov	x0, x23
    c530:	97ffdff0 	bl	44f0 <fwp_rc_forget_slot>
    c534:	17fffe50 	b	be74 <f0+0x1f64>
    c538:	aa1703e0 	mov	x0, x23
    c53c:	97ffdfed 	bl	44f0 <fwp_rc_forget_slot>
    c540:	17fffe97 	b	bf9c <f0+0x208c>
    c544:	97ffd8ab 	bl	27f0 <__stack_chk_fail@plt>
    c548:	d503201f 	nop
    c54c:	d503201f 	nop

000000000000c550 <fwp_main_thread>:
    c550:	d10443ff 	sub	sp, sp, #0x110
    c554:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c558:	f947f400 	ldr	x0, [x0, #4072]
    c55c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c560:	910303fd 	add	x29, sp, #0xc0
    c564:	a90d53f3 	stp	x19, x20, [sp, #208]
    c568:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xc90>
    c56c:	91154261 	add	x1, x19, #0x550
    c570:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c574:	b953a421 	ldr	w1, [x1, #5028]
    c578:	f9400002 	ldr	x2, [x0]
    c57c:	f9005fe2 	str	x2, [sp, #184]
    c580:	d2800002 	mov	x2, #0x0                   	// #0
    c584:	340025c1 	cbz	w1, ca3c <fwp_main_thread+0x4ec>
    c588:	91154273 	add	x19, x19, #0x550
    c58c:	b953aa60 	ldr	w0, [x19, #5032]
    c590:	350024e0 	cbnz	w0, ca2c <fwp_main_thread+0x4dc>
    c594:	91001fe2 	add	x2, sp, #0x7
    c598:	900000b5 	adrp	x21, 20000 <__data_start>
    c59c:	900000a3 	adrp	x3, 20000 <__data_start>
    c5a0:	910102b3 	add	x19, x21, #0x40
    c5a4:	910dc063 	add	x3, x3, #0x370
    c5a8:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c5ac:	d2a00025 	mov	x5, #0x10000               	// #65536
    c5b0:	910023e0 	add	x0, sp, #0x8
    c5b4:	d2800001 	mov	x1, #0x0                   	// #0
    c5b8:	f90007e3 	str	x3, [sp, #8]
    c5bc:	b90013ff 	str	wzr, [sp, #16]
    c5c0:	a9019262 	stp	x2, x4, [x19, #24]
    c5c4:	f9000fe5 	str	x5, [sp, #24]
    c5c8:	97ffd822 	bl	2650 <sigaltstack@plt>
    c5cc:	35002520 	cbnz	w0, ca70 <fwp_main_thread+0x520>
    c5d0:	4f000400 	movi	v0.4s, #0x0
    c5d4:	9100a3e0 	add	x0, sp, #0x28
    c5d8:	d0ffffa1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    c5dc:	52800082 	mov	w2, #0x4                   	// #4
    c5e0:	913fc021 	add	x1, x1, #0xff0
    c5e4:	72a10002 	movk	w2, #0x800, lsl #16
    c5e8:	910083f4 	add	x20, sp, #0x20
    c5ec:	f90013e1 	str	x1, [sp, #32]
    c5f0:	3d802000 	str	q0, [x0, #128]
    c5f4:	b900abe2 	str	w2, [sp, #168]
    c5f8:	ad000000 	stp	q0, q0, [x0]
    c5fc:	ad010000 	stp	q0, q0, [x0, #32]
    c600:	ad020000 	stp	q0, q0, [x0, #64]
    c604:	ad030000 	stp	q0, q0, [x0, #96]
    c608:	97ffd86a 	bl	27b0 <sigemptyset@plt>
    c60c:	35002320 	cbnz	w0, ca70 <fwp_main_thread+0x520>
    c610:	aa1403e1 	mov	x1, x20
    c614:	d2800002 	mov	x2, #0x0                   	// #0
    c618:	52800160 	mov	w0, #0xb                   	// #11
    c61c:	97ffd87d 	bl	2810 <sigaction@plt>
    c620:	35002280 	cbnz	w0, ca70 <fwp_main_thread+0x520>
    c624:	aa1403e1 	mov	x1, x20
    c628:	d2800002 	mov	x2, #0x0                   	// #0
    c62c:	528000e0 	mov	w0, #0x7                   	// #7
    c630:	97ffd878 	bl	2810 <sigaction@plt>
    c634:	350021e0 	cbnz	w0, ca70 <fwp_main_thread+0x520>
    c638:	b942fa60 	ldr	w0, [x19, #760]
    c63c:	a90f63f7 	stp	x23, x24, [sp, #240]
    c640:	34002020 	cbz	w0, ca44 <fwp_main_thread+0x4f4>
    c644:	910102b6 	add	x22, x21, #0x40
    c648:	f9400ad4 	ldr	x20, [x22, #16]
    c64c:	b40010d4 	cbz	x20, c864 <fwp_main_thread+0x314>
    c650:	aa1403f3 	mov	x19, x20
    c654:	91010297 	add	x23, x20, #0x40
    c658:	f90083f9 	str	x25, [sp, #256]
    c65c:	52800038 	mov	w24, #0x1                   	// #1
    c660:	39414a99 	ldrb	w25, [x20, #82]
    c664:	39014a98 	strb	w24, [x20, #82]
    c668:	f9401680 	ldr	x0, [x20, #40]
    c66c:	b4000620 	cbz	x0, c730 <fwp_main_thread+0x1e0>
    c670:	f9403281 	ldr	x1, [x20, #96]
    c674:	39414680 	ldrb	w0, [x20, #81]
    c678:	b4000b41 	cbz	x1, c7e0 <fwp_main_thread+0x290>
    c67c:	36000a80 	tbz	w0, #0, c7cc <fwp_main_thread+0x27c>
    c680:	39414a62 	ldrb	w2, [x19, #82]
    c684:	f9402280 	ldr	x0, [x20, #64]
    c688:	37000d62 	tbnz	w2, #0, c834 <fwp_main_thread+0x2e4>
    c68c:	f9403261 	ldr	x1, [x19, #96]
    c690:	a911fe77 	stp	x23, xzr, [x19, #280]
    c694:	f9009660 	str	x0, [x19, #296]
    c698:	b4000040 	cbz	x0, c6a0 <fwp_main_thread+0x150>
    c69c:	f9009013 	str	x19, [x0, #288]
    c6a0:	f9002293 	str	x19, [x20, #64]
    c6a4:	b4000101 	cbz	x1, c6c4 <fwp_main_thread+0x174>
    c6a8:	f94046c0 	ldr	x0, [x22, #136]
    c6ac:	39015678 	strb	w24, [x19, #85]
    c6b0:	f9003661 	str	x1, [x19, #104]
    c6b4:	a910827f 	stp	xzr, x0, [x19, #264]
    c6b8:	b4000040 	cbz	x0, c6c0 <fwp_main_thread+0x170>
    c6bc:	f9008413 	str	x19, [x0, #264]
    c6c0:	f90046d3 	str	x19, [x22, #136]
    c6c4:	39015a7f 	strb	wzr, [x19, #86]
    c6c8:	97ffe77f 	bl	64c4 <fwp_block>
    c6cc:	f9408e62 	ldr	x2, [x19, #280]
    c6d0:	b4000142 	cbz	x2, c6f8 <fwp_main_thread+0x1a8>
    c6d4:	a9520261 	ldp	x1, x0, [x19, #288]
    c6d8:	b4000ba1 	cbz	x1, c84c <fwp_main_thread+0x2fc>
    c6dc:	f9009420 	str	x0, [x1, #296]
    c6e0:	f9409660 	ldr	x0, [x19, #296]
    c6e4:	b4000040 	cbz	x0, c6ec <fwp_main_thread+0x19c>
    c6e8:	f9009001 	str	x1, [x0, #288]
    c6ec:	91080260 	add	x0, x19, #0x200
    c6f0:	f900967f 	str	xzr, [x19, #296]
    c6f4:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c6f8:	39415660 	ldrb	w0, [x19, #85]
    c6fc:	f9400ac2 	ldr	x2, [x22, #16]
    c700:	36000960 	tbz	w0, #0, c82c <fwp_main_thread+0x2dc>
    c704:	a9508261 	ldp	x1, x0, [x19, #264]
    c708:	b4000a61 	cbz	x1, c854 <fwp_main_thread+0x304>
    c70c:	f9008820 	str	x0, [x1, #272]
    c710:	b4000040 	cbz	x0, c718 <fwp_main_thread+0x1c8>
    c714:	f9008401 	str	x1, [x0, #264]
    c718:	91080260 	add	x0, x19, #0x200
    c71c:	3901567f 	strb	wzr, [x19, #85]
    c720:	aa0203f3 	mov	x19, x2
    c724:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c728:	f9401680 	ldr	x0, [x20, #40]
    c72c:	b5fffa20 	cbnz	x0, c670 <fwp_main_thread+0x120>
    c730:	910102a0 	add	x0, x21, #0x40
    c734:	39014a99 	strb	w25, [x20, #82]
    c738:	f94083f9 	ldr	x25, [sp, #256]
    c73c:	f9416c00 	ldr	x0, [x0, #728]
    c740:	b4001560 	cbz	x0, c9ec <fwp_main_thread+0x49c>
    c744:	910102a0 	add	x0, x21, #0x40
    c748:	f9418801 	ldr	x1, [x0, #784]
    c74c:	b903081f 	str	wzr, [x0, #776]
    c750:	eb13003f 	cmp	x1, x19
    c754:	54001681 	b.ne	ca24 <fwp_main_thread+0x4d4>  // b.any
    c758:	b4000913 	cbz	x19, c878 <fwp_main_thread+0x328>
    c75c:	910102a0 	add	x0, x21, #0x40
    c760:	52800021 	mov	w1, #0x1                   	// #1
    c764:	39014a61 	strb	w1, [x19, #82]
    c768:	f9415805 	ldr	x5, [x0, #688]
    c76c:	b4000865 	cbz	x5, c878 <fwp_main_thread+0x328>
    c770:	394140a0 	ldrb	w0, [x5, #80]
    c774:	37000060 	tbnz	w0, #0, c780 <fwp_main_thread+0x230>
    c778:	aa0503e0 	mov	x0, x5
    c77c:	97ffdb1d 	bl	33f0 <fwp_cancel_tree.part.0>
    c780:	f9409ca5 	ldr	x5, [x5, #312]
    c784:	b5ffff65 	cbnz	x5, c770 <fwp_main_thread+0x220>
    c788:	910102b4 	add	x20, x21, #0x40
    c78c:	52800036 	mov	w22, #0x1                   	// #1
    c790:	f9402a60 	ldr	x0, [x19, #80]
    c794:	f2001c1f 	tst	x0, #0xff000000ff
    c798:	540000e1 	b.ne	c7b4 <fwp_main_thread+0x264>  // b.any
    c79c:	f9401680 	ldr	x0, [x20, #40]
    c7a0:	39015276 	strb	w22, [x19, #84]
    c7a4:	f900827f 	str	xzr, [x19, #256]
    c7a8:	b40005a0 	cbz	x0, c85c <fwp_main_thread+0x30c>
    c7ac:	f9008013 	str	x19, [x0, #256]
    c7b0:	f9001693 	str	x19, [x20, #40]
    c7b4:	97ffe744 	bl	64c4 <fwp_block>
    c7b8:	97ffe6d6 	bl	6310 <fwp_free_zombie>
    c7bc:	f9415a80 	ldr	x0, [x20, #688]
    c7c0:	b40005c0 	cbz	x0, c878 <fwp_main_thread+0x328>
    c7c4:	f9418a93 	ldr	x19, [x20, #784]
    c7c8:	17fffff2 	b	c790 <fwp_main_thread+0x240>
    c7cc:	97ffdbad 	bl	3680 <fwp_now_ns>
    c7d0:	f9403281 	ldr	x1, [x20, #96]
    c7d4:	eb01001f 	cmp	x0, x1
    c7d8:	54000fca 	b.ge	c9d0 <fwp_main_thread+0x480>  // b.tcont
    c7dc:	39414680 	ldrb	w0, [x20, #81]
    c7e0:	39414a62 	ldrb	w2, [x19, #82]
    c7e4:	3707f500 	tbnz	w0, #0, c684 <fwp_main_thread+0x134>
    c7e8:	f9403281 	ldr	x1, [x20, #96]
    c7ec:	370001c2 	tbnz	w2, #0, c824 <fwp_main_thread+0x2d4>
    c7f0:	f9403260 	ldr	x0, [x19, #96]
    c7f4:	b4000180 	cbz	x0, c824 <fwp_main_thread+0x2d4>
    c7f8:	b4000061 	cbz	x1, c804 <fwp_main_thread+0x2b4>
    c7fc:	eb01001f 	cmp	x0, x1
    c800:	9a81d000 	csel	x0, x0, x1, le
    c804:	f9402281 	ldr	x1, [x20, #64]
    c808:	a911fe77 	stp	x23, xzr, [x19, #280]
    c80c:	f9009661 	str	x1, [x19, #296]
    c810:	b4001241 	cbz	x1, ca58 <fwp_main_thread+0x508>
    c814:	f9009033 	str	x19, [x1, #288]
    c818:	aa0003e1 	mov	x1, x0
    c81c:	f9002293 	str	x19, [x20, #64]
    c820:	17ffffa2 	b	c6a8 <fwp_main_thread+0x158>
    c824:	f9402280 	ldr	x0, [x20, #64]
    c828:	17ffff9a 	b	c690 <fwp_main_thread+0x140>
    c82c:	aa0203f3 	mov	x19, x2
    c830:	17ffff8e 	b	c668 <fwp_main_thread+0x118>
    c834:	a911fe77 	stp	x23, xzr, [x19, #280]
    c838:	f9009660 	str	x0, [x19, #296]
    c83c:	b4000040 	cbz	x0, c844 <fwp_main_thread+0x2f4>
    c840:	f9009013 	str	x19, [x0, #288]
    c844:	f9002293 	str	x19, [x20, #64]
    c848:	17ffff9f 	b	c6c4 <fwp_main_thread+0x174>
    c84c:	f9000040 	str	x0, [x2]
    c850:	17ffffa5 	b	c6e4 <fwp_main_thread+0x194>
    c854:	f90046c0 	str	x0, [x22, #136]
    c858:	17ffffae 	b	c710 <fwp_main_thread+0x1c0>
    c85c:	f9001a93 	str	x19, [x20, #48]
    c860:	17ffffd4 	b	c7b0 <fwp_main_thread+0x260>
    c864:	f9416ec0 	ldr	x0, [x22, #728]
    c868:	b4000c00 	cbz	x0, c9e8 <fwp_main_thread+0x498>
    c86c:	f9418ac0 	ldr	x0, [x22, #784]
    c870:	b9030adf 	str	wzr, [x22, #776]
    c874:	b5000d80 	cbnz	x0, ca24 <fwp_main_thread+0x4d4>
    c878:	910102b4 	add	x20, x21, #0x40
    c87c:	97ffe6a5 	bl	6310 <fwp_free_zombie>
    c880:	f9401a80 	ldr	x0, [x20, #48]
    c884:	b5000d00 	cbnz	x0, ca24 <fwp_main_thread+0x4d4>
    c888:	f9404680 	ldr	x0, [x20, #136]
    c88c:	b5000cc0 	cbnz	x0, ca24 <fwp_main_thread+0x4d4>
    c890:	b940aa93 	ldr	w19, [x20, #168]
    c894:	340001d3 	cbz	w19, c8cc <fwp_main_thread+0x37c>
    c898:	93407e76 	sxtw	x22, w19
    c89c:	51000673 	sub	w19, w19, #0x1
    c8a0:	d1000ad6 	sub	x22, x22, #0x2
    c8a4:	9102c297 	add	x23, x20, #0xb0
    c8a8:	cb3342d6 	sub	x22, x22, w19, uxtw
    c8ac:	93407e73 	sxtw	x19, w19
    c8b0:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    c8b4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    c8b8:	b900aa93 	str	w19, [x20, #168]
    c8bc:	d1000673 	sub	x19, x19, #0x1
    c8c0:	97ffd814 	bl	2910 <munmap@plt>
    c8c4:	eb16027f 	cmp	x19, x22
    c8c8:	54ffff41 	b.ne	c8b0 <fwp_main_thread+0x360>  // b.any
    c8cc:	900000b3 	adrp	x19, 20000 <__data_start>
    c8d0:	91004260 	add	x0, x19, #0x10
    c8d4:	b9401000 	ldr	w0, [x0, #16]
    c8d8:	37f80040 	tbnz	w0, #31, c8e0 <fwp_main_thread+0x390>
    c8dc:	97ffd7c9 	bl	2800 <close@plt>
    c8e0:	910102a0 	add	x0, x21, #0x40
    c8e4:	91004261 	add	x1, x19, #0x10
    c8e8:	12800002 	mov	w2, #0xffffffff            	// #-1
    c8ec:	d2800013 	mov	x19, #0x0                   	// #0
    c8f0:	f9418c16 	ldr	x22, [x0, #792]
    c8f4:	b9001022 	str	w2, [x1, #16]
    c8f8:	f9419014 	ldr	x20, [x0, #800]
    c8fc:	b4000176 	cbz	x22, c928 <fwp_main_thread+0x3d8>
    c900:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    c904:	b40000c0 	cbz	x0, c91c <fwp_main_thread+0x3cc>
    c908:	f9400001 	ldr	x1, [x0]
    c90c:	b50008c1 	cbnz	x1, ca24 <fwp_main_thread+0x4d4>
    c910:	f9400401 	ldr	x1, [x0, #8]
    c914:	b5000881 	cbnz	x1, ca24 <fwp_main_thread+0x4d4>
    c918:	97ffdf96 	bl	4770 <fwp_mem_free>
    c91c:	91000673 	add	x19, x19, #0x1
    c920:	eb16027f 	cmp	x19, x22
    c924:	54fffee1 	b.ne	c900 <fwp_main_thread+0x3b0>  // b.any
    c928:	aa1403e0 	mov	x0, x20
    c92c:	97ffdf91 	bl	4770 <fwp_mem_free>
    c930:	910102a0 	add	x0, x21, #0x40
    c934:	f9418813 	ldr	x19, [x0, #784]
    c938:	f9018c1f 	str	xzr, [x0, #792]
    c93c:	f901901f 	str	xzr, [x0, #800]
    c940:	b40001f3 	cbz	x19, c97c <fwp_main_thread+0x42c>
    c944:	f9401661 	ldr	x1, [x19, #40]
    c948:	b50006e1 	cbnz	x1, ca24 <fwp_main_thread+0x4d4>
    c94c:	f9405661 	ldr	x1, [x19, #168]
    c950:	b50006a1 	cbnz	x1, ca24 <fwp_main_thread+0x4d4>
    c954:	f9416c01 	ldr	x1, [x0, #728]
    c958:	b5000661 	cbnz	x1, ca24 <fwp_main_thread+0x4d4>
    c95c:	f9417400 	ldr	x0, [x0, #744]
    c960:	b5000620 	cbnz	x0, ca24 <fwp_main_thread+0x4d4>
    c964:	d2823a02 	mov	x2, #0x11d0                	// #4560
    c968:	90000120 	adrp	x0, 30000 <alt.5+0xfc90>
    c96c:	910dc000 	add	x0, x0, #0x370
    c970:	97ffd794 	bl	27c0 <memset@plt>
    c974:	aa1303e0 	mov	x0, x19
    c978:	97ffdf7e 	bl	4770 <fwp_mem_free>
    c97c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c980:	f947ec00 	ldr	x0, [x0, #4056]
    c984:	910102b5 	add	x21, x21, #0x40
    c988:	f9400000 	ldr	x0, [x0]
    c98c:	f9000abf 	str	xzr, [x21, #16]
    c990:	f9018abf 	str	xzr, [x21, #784]
    c994:	97ffd7e3 	bl	2920 <fflush@plt>
    c998:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    c99c:	f947f400 	ldr	x0, [x0, #4072]
    c9a0:	f9405fe2 	ldr	x2, [sp, #184]
    c9a4:	f9400001 	ldr	x1, [x0]
    c9a8:	eb010042 	subs	x2, x2, x1
    c9ac:	d2800001 	mov	x1, #0x0                   	// #0
    c9b0:	540006a1 	b.ne	ca84 <fwp_main_thread+0x534>  // b.any
    c9b4:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    c9b8:	d2800000 	mov	x0, #0x0                   	// #0
    c9bc:	a94d53f3 	ldp	x19, x20, [sp, #208]
    c9c0:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    c9c4:	a94f63f7 	ldp	x23, x24, [sp, #240]
    c9c8:	910443ff 	add	sp, sp, #0x110
    c9cc:	d65f03c0 	ret
    c9d0:	39414280 	ldrb	w0, [x20, #80]
    c9d4:	3707f040 	tbnz	w0, #0, c7dc <fwp_main_thread+0x28c>
    c9d8:	aa1403e0 	mov	x0, x20
    c9dc:	97ffda85 	bl	33f0 <fwp_cancel_tree.part.0>
    c9e0:	39414680 	ldrb	w0, [x20, #81]
    c9e4:	17ffff7f 	b	c7e0 <fwp_main_thread+0x290>
    c9e8:	d2800013 	mov	x19, #0x0                   	// #0
    c9ec:	910102b4 	add	x20, x21, #0x40
    c9f0:	f9417680 	ldr	x0, [x20, #744]
    c9f4:	b5ffea80 	cbnz	x0, c744 <fwp_main_thread+0x1f4>
    c9f8:	f9416a80 	ldr	x0, [x20, #720]
    c9fc:	97ffdf5d 	bl	4770 <fwp_mem_free>
    ca00:	f9016a9f 	str	xzr, [x20, #720]
    ca04:	f901729f 	str	xzr, [x20, #736]
    ca08:	f9418a80 	ldr	x0, [x20, #784]
    ca0c:	b40002d3 	cbz	x19, ca64 <fwp_main_thread+0x514>
    ca10:	f900567f 	str	xzr, [x19, #168]
    ca14:	f9005e7f 	str	xzr, [x19, #184]
    ca18:	b9030a9f 	str	wzr, [x20, #776]
    ca1c:	eb00027f 	cmp	x19, x0
    ca20:	54ffe9e0 	b.eq	c75c <fwp_main_thread+0x20c>  // b.none
    ca24:	f90083f9 	str	x25, [sp, #256]
    ca28:	97ffd786 	bl	2840 <abort@plt>
    ca2c:	f0ffffa0 	adrp	x0, 3000 <fwp_segv+0x10>
    ca30:	91328000 	add	x0, x0, #0xca0
    ca34:	940001d3 	bl	d180 <atexit>
    ca38:	17fffed7 	b	c594 <fwp_main_thread+0x44>
    ca3c:	97ffdcf2 	bl	3e04 <fwp_heap_init>
    ca40:	17fffed2 	b	c588 <fwp_main_thread+0x38>
    ca44:	97fff533 	bl	9f10 <f0>
    ca48:	f9018260 	str	x0, [x19, #768]
    ca4c:	52800021 	mov	w1, #0x1                   	// #1
    ca50:	b902fa61 	str	w1, [x19, #760]
    ca54:	17fffefc 	b	c644 <fwp_main_thread+0xf4>
    ca58:	aa0003e1 	mov	x1, x0
    ca5c:	f9002293 	str	x19, [x20, #64]
    ca60:	17ffff12 	b	c6a8 <fwp_main_thread+0x158>
    ca64:	b9030a9f 	str	wzr, [x20, #776]
    ca68:	b4fff080 	cbz	x0, c878 <fwp_main_thread+0x328>
    ca6c:	17ffffee 	b	ca24 <fwp_main_thread+0x4d4>
    ca70:	b0000000 	adrp	x0, d000 <__modti3+0x1f0>
    ca74:	911da000 	add	x0, x0, #0x768
    ca78:	a90f63f7 	stp	x23, x24, [sp, #240]
    ca7c:	f90083f9 	str	x25, [sp, #256]
    ca80:	97ffdaa0 	bl	3500 <fwp_trap>
    ca84:	f90083f9 	str	x25, [sp, #256]
    ca88:	97ffd75a 	bl	27f0 <__stack_chk_fail@plt>
    ca8c:	d503201f 	nop

000000000000ca90 <__divti3>:
    ca90:	d503245f 	bti	c
    ca94:	d2800004 	mov	x4, #0x0                   	// #0
    ca98:	b7f80721 	tbnz	x1, #63, cb7c <__divti3+0xec>
    ca9c:	b6f80083 	tbz	x3, #63, caac <__divti3+0x1c>
    caa0:	eb0203e2 	negs	x2, x2
    caa4:	aa2403e4 	mvn	x4, x4
    caa8:	da0303e3 	ngc	x3, x3
    caac:	aa0203e6 	mov	x6, x2
    cab0:	aa0003e7 	mov	x7, x0
    cab4:	aa0103e5 	mov	x5, x1
    cab8:	b5000583 	cbnz	x3, cb68 <__divti3+0xd8>
    cabc:	eb01005f 	cmp	x2, x1
    cac0:	54000e69 	b.ls	cc8c <__divti3+0x1fc>  // b.plast
    cac4:	dac01040 	clz	x0, x2
    cac8:	b40000e0 	cbz	x0, cae4 <__divti3+0x54>
    cacc:	4b0003e1 	neg	w1, w0
    cad0:	9ac020a5 	lsl	x5, x5, x0
    cad4:	9ac02046 	lsl	x6, x2, x0
    cad8:	9ac124e1 	lsr	x1, x7, x1
    cadc:	aa050025 	orr	x5, x1, x5
    cae0:	9ac020e7 	lsl	x7, x7, x0
    cae4:	d360fcc8 	lsr	x8, x6, #32
    cae8:	92407cc2 	and	x2, x6, #0xffffffff
    caec:	9ac808a3 	udiv	x3, x5, x8
    caf0:	9b089465 	msub	x5, x3, x8, x5
    caf4:	aa0303e0 	mov	x0, x3
    caf8:	9b037c41 	mul	x1, x2, x3
    cafc:	93c780a5 	extr	x5, x5, x7, #32
    cb00:	eb05003f 	cmp	x1, x5
    cb04:	540000a9 	b.ls	cb18 <__divti3+0x88>  // b.plast
    cb08:	ab0500c5 	adds	x5, x6, x5
    cb0c:	d1000460 	sub	x0, x3, #0x1
    cb10:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    cb14:	540015a8 	b.hi	cdc8 <__divti3+0x338>  // b.pmore
    cb18:	cb0100a5 	sub	x5, x5, x1
    cb1c:	9ac808a3 	udiv	x3, x5, x8
    cb20:	9b089465 	msub	x5, x3, x8, x5
    cb24:	aa0303e1 	mov	x1, x3
    cb28:	9b037c42 	mul	x2, x2, x3
    cb2c:	aa0703e3 	mov	x3, x7
    cb30:	b3607ca3 	bfi	x3, x5, #32, #32
    cb34:	eb03005f 	cmp	x2, x3
    cb38:	540000c9 	b.ls	cb50 <__divti3+0xc0>  // b.plast
    cb3c:	ab0300c3 	adds	x3, x6, x3
    cb40:	d1000425 	sub	x5, x1, #0x1
    cb44:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cb48:	d1000821 	sub	x1, x1, #0x2
    cb4c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    cb50:	aa008020 	orr	x0, x1, x0, lsl #32
    cb54:	d2800001 	mov	x1, #0x0                   	// #0
    cb58:	b4000064 	cbz	x4, cb64 <__divti3+0xd4>
    cb5c:	eb0003e0 	negs	x0, x0
    cb60:	da0103e1 	ngc	x1, x1
    cb64:	d65f03c0 	ret
    cb68:	eb01007f 	cmp	x3, x1
    cb6c:	54000109 	b.ls	cb8c <__divti3+0xfc>  // b.plast
    cb70:	d2800001 	mov	x1, #0x0                   	// #0
    cb74:	d2800000 	mov	x0, #0x0                   	// #0
    cb78:	17fffff8 	b	cb58 <__divti3+0xc8>
    cb7c:	eb0003e0 	negs	x0, x0
    cb80:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cb84:	da0103e1 	ngc	x1, x1
    cb88:	17ffffc5 	b	ca9c <__divti3+0xc>
    cb8c:	dac01067 	clz	x7, x3
    cb90:	b40010e7 	cbz	x7, cdac <__divti3+0x31c>
    cb94:	d2800805 	mov	x5, #0x40                  	// #64
    cb98:	cb0700a5 	sub	x5, x5, x7
    cb9c:	9ac72063 	lsl	x3, x3, x7
    cba0:	9ac52448 	lsr	x8, x2, x5
    cba4:	aa030108 	orr	x8, x8, x3
    cba8:	9ac52426 	lsr	x6, x1, x5
    cbac:	92407d0a 	and	x10, x8, #0xffffffff
    cbb0:	d360fd09 	lsr	x9, x8, #32
    cbb4:	9ac52403 	lsr	x3, x0, x5
    cbb8:	9ac72021 	lsl	x1, x1, x7
    cbbc:	aa010063 	orr	x3, x3, x1
    cbc0:	9ac72042 	lsl	x2, x2, x7
    cbc4:	9ac908cb 	udiv	x11, x6, x9
    cbc8:	9b099965 	msub	x5, x11, x9, x6
    cbcc:	aa0b03e1 	mov	x1, x11
    cbd0:	9b0b7d46 	mul	x6, x10, x11
    cbd4:	93c380a5 	extr	x5, x5, x3, #32
    cbd8:	eb0500df 	cmp	x6, x5
    cbdc:	540000a9 	b.ls	cbf0 <__divti3+0x160>  // b.plast
    cbe0:	ab050105 	adds	x5, x8, x5
    cbe4:	d1000561 	sub	x1, x11, #0x1
    cbe8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    cbec:	54000f48 	b.hi	cdd4 <__divti3+0x344>  // b.pmore
    cbf0:	cb0600a6 	sub	x6, x5, x6
    cbf4:	9ac908cb 	udiv	x11, x6, x9
    cbf8:	9b099969 	msub	x9, x11, x9, x6
    cbfc:	aa0b03e5 	mov	x5, x11
    cc00:	9b0b7d4a 	mul	x10, x10, x11
    cc04:	b3607d23 	bfi	x3, x9, #32, #32
    cc08:	eb03015f 	cmp	x10, x3
    cc0c:	540000a9 	b.ls	cc20 <__divti3+0x190>  // b.plast
    cc10:	ab030103 	adds	x3, x8, x3
    cc14:	d1000565 	sub	x5, x11, #0x1
    cc18:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    cc1c:	54000e28 	b.hi	cde0 <__divti3+0x350>  // b.pmore
    cc20:	aa0180a1 	orr	x1, x5, x1, lsl #32
    cc24:	92407c48 	and	x8, x2, #0xffffffff
    cc28:	2a0503e5 	mov	w5, w5
    cc2c:	d360fc42 	lsr	x2, x2, #32
    cc30:	d360fc26 	lsr	x6, x1, #32
    cc34:	cb0a0063 	sub	x3, x3, x10
    cc38:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    cc3c:	9b087caa 	mul	x10, x5, x8
    cc40:	9b087cc8 	mul	x8, x6, x8
    cc44:	9b0220a5 	madd	x5, x5, x2, x8
    cc48:	9b027cc6 	mul	x6, x6, x2
    cc4c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    cc50:	8b0900c5 	add	x5, x6, x9
    cc54:	eb02011f 	cmp	x8, x2
    cc58:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    cc5c:	8b4280c6 	add	x6, x6, x2, lsr #32
    cc60:	eb06007f 	cmp	x3, x6
    cc64:	540000e3 	b.cc	cc80 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    cc68:	92407d4a 	and	x10, x10, #0xffffffff
    cc6c:	9ac72000 	lsl	x0, x0, x7
    cc70:	8b028142 	add	x2, x10, x2, lsl #32
    cc74:	eb02001f 	cmp	x0, x2
    cc78:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    cc7c:	54000a01 	b.ne	cdbc <__divti3+0x32c>  // b.any
    cc80:	d1000420 	sub	x0, x1, #0x1
    cc84:	d2800001 	mov	x1, #0x0                   	// #0
    cc88:	17ffffb4 	b	cb58 <__divti3+0xc8>
    cc8c:	b5000062 	cbnz	x2, cc98 <__divti3+0x208>
    cc90:	d2800022 	mov	x2, #0x1                   	// #1
    cc94:	9ac30846 	udiv	x6, x2, x3
    cc98:	dac010c8 	clz	x8, x6
    cc9c:	b5000408 	cbnz	x8, cd1c <__divti3+0x28c>
    cca0:	d360fcc9 	lsr	x9, x6, #32
    cca4:	92407cc5 	and	x5, x6, #0xffffffff
    cca8:	cb060023 	sub	x3, x1, x6
    ccac:	d2800021 	mov	x1, #0x1                   	// #1
    ccb0:	9ac90868 	udiv	x8, x3, x9
    ccb4:	9b098d03 	msub	x3, x8, x9, x3
    ccb8:	aa0803e0 	mov	x0, x8
    ccbc:	9b057d02 	mul	x2, x8, x5
    ccc0:	93c78063 	extr	x3, x3, x7, #32
    ccc4:	eb03005f 	cmp	x2, x3
    ccc8:	540000a9 	b.ls	ccdc <__divti3+0x24c>  // b.plast
    cccc:	ab0300c3 	adds	x3, x6, x3
    ccd0:	d1000500 	sub	x0, x8, #0x1
    ccd4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ccd8:	54000968 	b.hi	ce04 <__divti3+0x374>  // b.pmore
    ccdc:	cb020063 	sub	x3, x3, x2
    cce0:	9ac90862 	udiv	x2, x3, x9
    cce4:	aa0203e8 	mov	x8, x2
    cce8:	9b098c42 	msub	x2, x2, x9, x3
    ccec:	aa0703e3 	mov	x3, x7
    ccf0:	9b057d05 	mul	x5, x8, x5
    ccf4:	b3607c43 	bfi	x3, x2, #32, #32
    ccf8:	eb0300bf 	cmp	x5, x3
    ccfc:	540000c9 	b.ls	cd14 <__divti3+0x284>  // b.plast
    cd00:	ab0300c2 	adds	x2, x6, x3
    cd04:	d1000503 	sub	x3, x8, #0x1
    cd08:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    cd0c:	d1000908 	sub	x8, x8, #0x2
    cd10:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    cd14:	aa008100 	orr	x0, x8, x0, lsl #32
    cd18:	17ffff90 	b	cb58 <__divti3+0xc8>
    cd1c:	9ac820c6 	lsl	x6, x6, x8
    cd20:	d2800803 	mov	x3, #0x40                  	// #64
    cd24:	cb080063 	sub	x3, x3, x8
    cd28:	d360fcc9 	lsr	x9, x6, #32
    cd2c:	9ac82027 	lsl	x7, x1, x8
    cd30:	92407cc5 	and	x5, x6, #0xffffffff
    cd34:	9ac32422 	lsr	x2, x1, x3
    cd38:	9ac32403 	lsr	x3, x0, x3
    cd3c:	aa070063 	orr	x3, x3, x7
    cd40:	9ac9084a 	udiv	x10, x2, x9
    cd44:	9ac82007 	lsl	x7, x0, x8
    cd48:	9b098940 	msub	x0, x10, x9, x2
    cd4c:	aa0a03e1 	mov	x1, x10
    cd50:	9b0a7ca2 	mul	x2, x5, x10
    cd54:	93c38000 	extr	x0, x0, x3, #32
    cd58:	eb00005f 	cmp	x2, x0
    cd5c:	540000a9 	b.ls	cd70 <__divti3+0x2e0>  // b.plast
    cd60:	ab0000c0 	adds	x0, x6, x0
    cd64:	d1000541 	sub	x1, x10, #0x1
    cd68:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    cd6c:	54000468 	b.hi	cdf8 <__divti3+0x368>  // b.pmore
    cd70:	cb020000 	sub	x0, x0, x2
    cd74:	9ac9080a 	udiv	x10, x0, x9
    cd78:	9b098140 	msub	x0, x10, x9, x0
    cd7c:	aa0a03e2 	mov	x2, x10
    cd80:	9b0a7ca8 	mul	x8, x5, x10
    cd84:	b3607c03 	bfi	x3, x0, #32, #32
    cd88:	eb03011f 	cmp	x8, x3
    cd8c:	540000a9 	b.ls	cda0 <__divti3+0x310>  // b.plast
    cd90:	ab0300c3 	adds	x3, x6, x3
    cd94:	d1000542 	sub	x2, x10, #0x1
    cd98:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    cd9c:	54000288 	b.hi	cdec <__divti3+0x35c>  // b.pmore
    cda0:	cb080063 	sub	x3, x3, x8
    cda4:	aa018041 	orr	x1, x2, x1, lsl #32
    cda8:	17ffffc2 	b	ccb0 <__divti3+0x220>
    cdac:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    cdb0:	d2800001 	mov	x1, #0x0                   	// #0
    cdb4:	9a9f87e0 	cset	x0, ls	// ls = plast
    cdb8:	17ffff68 	b	cb58 <__divti3+0xc8>
    cdbc:	aa0103e0 	mov	x0, x1
    cdc0:	d2800001 	mov	x1, #0x0                   	// #0
    cdc4:	17ffff65 	b	cb58 <__divti3+0xc8>
    cdc8:	d1000860 	sub	x0, x3, #0x2
    cdcc:	8b0600a5 	add	x5, x5, x6
    cdd0:	17ffff52 	b	cb18 <__divti3+0x88>
    cdd4:	d1000961 	sub	x1, x11, #0x2
    cdd8:	8b0800a5 	add	x5, x5, x8
    cddc:	17ffff85 	b	cbf0 <__divti3+0x160>
    cde0:	d1000965 	sub	x5, x11, #0x2
    cde4:	8b080063 	add	x3, x3, x8
    cde8:	17ffff8e 	b	cc20 <__divti3+0x190>
    cdec:	d1000942 	sub	x2, x10, #0x2
    cdf0:	8b060063 	add	x3, x3, x6
    cdf4:	17ffffeb 	b	cda0 <__divti3+0x310>
    cdf8:	d1000941 	sub	x1, x10, #0x2
    cdfc:	8b060000 	add	x0, x0, x6
    ce00:	17ffffdc 	b	cd70 <__divti3+0x2e0>
    ce04:	d1000900 	sub	x0, x8, #0x2
    ce08:	8b060063 	add	x3, x3, x6
    ce0c:	17ffffb4 	b	ccdc <__divti3+0x24c>

000000000000ce10 <__modti3>:
    ce10:	d503245f 	bti	c
    ce14:	d2800004 	mov	x4, #0x0                   	// #0
    ce18:	b6f80081 	tbz	x1, #63, ce28 <__modti3+0x18>
    ce1c:	eb0003e0 	negs	x0, x0
    ce20:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ce24:	da0103e1 	ngc	x1, x1
    ce28:	f100007f 	cmp	x3, #0x0
    ce2c:	5400128b 	b.lt	d07c <__modti3+0x26c>  // b.tstop
    ce30:	aa0003e7 	mov	x7, x0
    ce34:	aa0103e6 	mov	x6, x1
    ce38:	540004e1 	b.ne	ced4 <__modti3+0xc4>  // b.any
    ce3c:	eb02003f 	cmp	x1, x2
    ce40:	54000dc2 	b.cs	cff8 <__modti3+0x1e8>  // b.hs, b.nlast
    ce44:	dac01043 	clz	x3, x2
    ce48:	aa0303e5 	mov	x5, x3
    ce4c:	b40000e3 	cbz	x3, ce68 <__modti3+0x58>
    ce50:	4b0303e6 	neg	w6, w3
    ce54:	9ac32021 	lsl	x1, x1, x3
    ce58:	9ac32042 	lsl	x2, x2, x3
    ce5c:	9ac62406 	lsr	x6, x0, x6
    ce60:	aa0100c6 	orr	x6, x6, x1
    ce64:	9ac32007 	lsl	x7, x0, x3
    ce68:	d360fc40 	lsr	x0, x2, #32
    ce6c:	92407c43 	and	x3, x2, #0xffffffff
    ce70:	9ac008c1 	udiv	x1, x6, x0
    ce74:	9b009826 	msub	x6, x1, x0, x6
    ce78:	9b017c61 	mul	x1, x3, x1
    ce7c:	93c780c6 	extr	x6, x6, x7, #32
    ce80:	eb06003f 	cmp	x1, x6
    ce84:	540000a9 	b.ls	ce98 <__modti3+0x88>  // b.plast
    ce88:	ab060046 	adds	x6, x2, x6
    ce8c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    ce90:	8b0200c8 	add	x8, x6, x2
    ce94:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    ce98:	cb0100c6 	sub	x6, x6, x1
    ce9c:	9ac008c8 	udiv	x8, x6, x0
    cea0:	9b009901 	msub	x1, x8, x0, x6
    cea4:	aa0703e0 	mov	x0, x7
    cea8:	9b087c63 	mul	x3, x3, x8
    ceac:	b3607c20 	bfi	x0, x1, #32, #32
    ceb0:	eb00007f 	cmp	x3, x0
    ceb4:	54001088 	b.hi	d0c4 <__modti3+0x2b4>  // b.pmore
    ceb8:	cb030000 	sub	x0, x0, x3
    cebc:	9ac52400 	lsr	x0, x0, x5
    cec0:	d2800001 	mov	x1, #0x0                   	// #0
    cec4:	b4000064 	cbz	x4, ced0 <__modti3+0xc0>
    cec8:	eb0003e0 	negs	x0, x0
    cecc:	da0103e1 	ngc	x1, x1
    ced0:	d65f03c0 	ret
    ced4:	dac01066 	clz	x6, x3
    ced8:	eb03003f 	cmp	x1, x3
    cedc:	54ffff43 	b.cc	cec4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    cee0:	93407cc5 	sxtw	x5, w6
    cee4:	d2800808 	mov	x8, #0x40                  	// #64
    cee8:	cb050108 	sub	x8, x8, x5
    ceec:	9ac62063 	lsl	x3, x3, x6
    cef0:	9ac62025 	lsl	x5, x1, x6
    cef4:	9ac82447 	lsr	x7, x2, x8
    cef8:	aa0300e7 	orr	x7, x7, x3
    cefc:	9ac82423 	lsr	x3, x1, x8
    cf00:	92407cec 	and	x12, x7, #0xffffffff
    cf04:	d360fcea 	lsr	x10, x7, #32
    cf08:	9ac82401 	lsr	x1, x0, x8
    cf0c:	aa050021 	orr	x1, x1, x5
    cf10:	9ac62042 	lsl	x2, x2, x6
    cf14:	9ac62000 	lsl	x0, x0, x6
    cf18:	9aca086b 	udiv	x11, x3, x10
    cf1c:	9b0a8d63 	msub	x3, x11, x10, x3
    cf20:	aa0b03e5 	mov	x5, x11
    cf24:	9b0b7d89 	mul	x9, x12, x11
    cf28:	93c18063 	extr	x3, x3, x1, #32
    cf2c:	eb03013f 	cmp	x9, x3
    cf30:	540000a9 	b.ls	cf44 <__modti3+0x134>  // b.plast
    cf34:	ab0300e3 	adds	x3, x7, x3
    cf38:	d1000565 	sub	x5, x11, #0x1
    cf3c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    cf40:	54001168 	b.hi	d16c <__modti3+0x35c>  // b.pmore
    cf44:	cb090063 	sub	x3, x3, x9
    cf48:	9aca086b 	udiv	x11, x3, x10
    cf4c:	9b0a8d6a 	msub	x10, x11, x10, x3
    cf50:	aa0b03e9 	mov	x9, x11
    cf54:	9b0b7d8c 	mul	x12, x12, x11
    cf58:	b3607d41 	bfi	x1, x10, #32, #32
    cf5c:	eb01019f 	cmp	x12, x1
    cf60:	540000a9 	b.ls	cf74 <__modti3+0x164>  // b.plast
    cf64:	ab0100e1 	adds	x1, x7, x1
    cf68:	d1000569 	sub	x9, x11, #0x1
    cf6c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    cf70:	54000f88 	b.hi	d160 <__modti3+0x350>  // b.pmore
    cf74:	aa058123 	orr	x3, x9, x5, lsl #32
    cf78:	92407c4b 	and	x11, x2, #0xffffffff
    cf7c:	2a0903e9 	mov	w9, w9
    cf80:	d360fc4a 	lsr	x10, x2, #32
    cf84:	d360fc63 	lsr	x3, x3, #32
    cf88:	cb0c0021 	sub	x1, x1, x12
    cf8c:	aa0a03ec 	mov	x12, x10
    cf90:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    cf94:	9b0b7d25 	mul	x5, x9, x11
    cf98:	9b0b7c6b 	mul	x11, x3, x11
    cf9c:	9b0a2d29 	madd	x9, x9, x10, x11
    cfa0:	92407caa 	and	x10, x5, #0xffffffff
    cfa4:	9b0c7c63 	mul	x3, x3, x12
    cfa8:	8b458125 	add	x5, x9, x5, lsr #32
    cfac:	8b0d0069 	add	x9, x3, x13
    cfb0:	eb05017f 	cmp	x11, x5
    cfb4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    cfb8:	8b058149 	add	x9, x10, x5, lsl #32
    cfbc:	8b458063 	add	x3, x3, x5, lsr #32
    cfc0:	eb03003f 	cmp	x1, x3
    cfc4:	54000063 	b.cc	cfd0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    cfc8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    cfcc:	54000082 	b.cs	cfdc <__modti3+0x1cc>  // b.hs, b.nlast
    cfd0:	eb020129 	subs	x9, x9, x2
    cfd4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    cfd8:	cb070063 	sub	x3, x3, x7
    cfdc:	eb090000 	subs	x0, x0, x9
    cfe0:	da030021 	sbc	x1, x1, x3
    cfe4:	9ac62400 	lsr	x0, x0, x6
    cfe8:	9ac82028 	lsl	x8, x1, x8
    cfec:	aa000100 	orr	x0, x8, x0
    cff0:	9ac62421 	lsr	x1, x1, x6
    cff4:	17ffffb4 	b	cec4 <__modti3+0xb4>
    cff8:	b5000062 	cbnz	x2, d004 <__modti3+0x1f4>
    cffc:	d2800023 	mov	x3, #0x1                   	// #1
    d000:	9ac20862 	udiv	x2, x3, x2
    d004:	dac01048 	clz	x8, x2
    d008:	aa0803e5 	mov	x5, x8
    d00c:	b5000668 	cbnz	x8, d0d8 <__modti3+0x2c8>
    d010:	cb020020 	sub	x0, x1, x2
    d014:	d360fc49 	lsr	x9, x2, #32
    d018:	92407c4a 	and	x10, x2, #0xffffffff
    d01c:	9ac90801 	udiv	x1, x0, x9
    d020:	9b098020 	msub	x0, x1, x9, x0
    d024:	9b0a7c21 	mul	x1, x1, x10
    d028:	93c78000 	extr	x0, x0, x7, #32
    d02c:	eb00003f 	cmp	x1, x0
    d030:	540000a9 	b.ls	d044 <__modti3+0x234>  // b.plast
    d034:	ab000040 	adds	x0, x2, x0
    d038:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d03c:	8b020003 	add	x3, x0, x2
    d040:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d044:	cb010001 	sub	x1, x0, x1
    d048:	9ac90820 	udiv	x0, x1, x9
    d04c:	9b098403 	msub	x3, x0, x9, x1
    d050:	aa0703e1 	mov	x1, x7
    d054:	9b0a7c00 	mul	x0, x0, x10
    d058:	b3607c61 	bfi	x1, x3, #32, #32
    d05c:	eb01001f 	cmp	x0, x1
    d060:	540000a9 	b.ls	d074 <__modti3+0x264>  // b.plast
    d064:	ab010041 	adds	x1, x2, x1
    d068:	8b020022 	add	x2, x1, x2
    d06c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d070:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d074:	cb000020 	sub	x0, x1, x0
    d078:	17ffff91 	b	cebc <__modti3+0xac>
    d07c:	eb0203e5 	negs	x5, x2
    d080:	aa0003e7 	mov	x7, x0
    d084:	da0303e8 	ngc	x8, x3
    d088:	aa0503e2 	mov	x2, x5
    d08c:	aa0803e3 	mov	x3, x8
    d090:	aa0103e6 	mov	x6, x1
    d094:	b4ffed48 	cbz	x8, ce3c <__modti3+0x2c>
    d098:	eb01011f 	cmp	x8, x1
    d09c:	54fff148 	b.hi	cec4 <__modti3+0xb4>  // b.pmore
    d0a0:	dac01109 	clz	x9, x8
    d0a4:	2a0903e6 	mov	w6, w9
    d0a8:	b5fff1c9 	cbnz	x9, cee0 <__modti3+0xd0>
    d0ac:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d0b0:	54000068 	b.hi	d0bc <__modti3+0x2ac>  // b.pmore
    d0b4:	eb050007 	subs	x7, x0, x5
    d0b8:	da080021 	sbc	x1, x1, x8
    d0bc:	aa0703e0 	mov	x0, x7
    d0c0:	17ffff81 	b	cec4 <__modti3+0xb4>
    d0c4:	ab000040 	adds	x0, x2, x0
    d0c8:	8b020002 	add	x2, x0, x2
    d0cc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d0d0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d0d4:	17ffff79 	b	ceb8 <__modti3+0xa8>
    d0d8:	9ac82042 	lsl	x2, x2, x8
    d0dc:	d2800803 	mov	x3, #0x40                  	// #64
    d0e0:	cb080063 	sub	x3, x3, x8
    d0e4:	d360fc49 	lsr	x9, x2, #32
    d0e8:	9ac82027 	lsl	x7, x1, x8
    d0ec:	92407c4a 	and	x10, x2, #0xffffffff
    d0f0:	9ac32426 	lsr	x6, x1, x3
    d0f4:	9ac32403 	lsr	x3, x0, x3
    d0f8:	aa070063 	orr	x3, x3, x7
    d0fc:	9ac908c1 	udiv	x1, x6, x9
    d100:	9ac82007 	lsl	x7, x0, x8
    d104:	9b099820 	msub	x0, x1, x9, x6
    d108:	9b017d41 	mul	x1, x10, x1
    d10c:	93c38000 	extr	x0, x0, x3, #32
    d110:	eb00003f 	cmp	x1, x0
    d114:	540000a9 	b.ls	d128 <__modti3+0x318>  // b.plast
    d118:	ab000040 	adds	x0, x2, x0
    d11c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d120:	8b020006 	add	x6, x0, x2
    d124:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d128:	cb010000 	sub	x0, x0, x1
    d12c:	9ac90801 	udiv	x1, x0, x9
    d130:	9b098026 	msub	x6, x1, x9, x0
    d134:	aa0303e0 	mov	x0, x3
    d138:	9b017d41 	mul	x1, x10, x1
    d13c:	b3607cc0 	bfi	x0, x6, #32, #32
    d140:	eb00003f 	cmp	x1, x0
    d144:	540000a9 	b.ls	d158 <__modti3+0x348>  // b.plast
    d148:	ab000040 	adds	x0, x2, x0
    d14c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d150:	8b020003 	add	x3, x0, x2
    d154:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d158:	cb010000 	sub	x0, x0, x1
    d15c:	17ffffb0 	b	d01c <__modti3+0x20c>
    d160:	d1000969 	sub	x9, x11, #0x2
    d164:	8b070021 	add	x1, x1, x7
    d168:	17ffff83 	b	cf74 <__modti3+0x164>
    d16c:	d1000965 	sub	x5, x11, #0x2
    d170:	8b070063 	add	x3, x3, x7
    d174:	17ffff74 	b	cf44 <__modti3+0x134>
    d178:	d503201f 	nop
    d17c:	d503201f 	nop

000000000000d180 <atexit>:
    d180:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d184:	f0000082 	adrp	x2, 20000 <__data_start>
    d188:	d2800001 	mov	x1, #0x0                   	// #0
    d18c:	910003fd 	mov	x29, sp
    d190:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d194:	f9400442 	ldr	x2, [x2, #8]
    d198:	17ffd556 	b	26f0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d19c <_fini>:
    d19c:	d503201f 	nop
    d1a0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d1a4:	910003fd 	mov	x29, sp
    d1a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d1ac:	d65f03c0 	ret
