
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-identical:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	d0000045 	adrp	x5, c000 <f0+0x2630>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	913ac0a5 	add	x5, x5, #0xeb0
    2aa0:	d0000044 	adrp	x4, c000 <f0+0x2630>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	913ae084 	add	x4, x4, #0xeb8
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	940002ac 	bl	3580 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	9100c261 	add	x1, x19, #0x30
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xf2f0>
    2b20:	910da000 	add	x0, x0, #0x368
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9001c20 	str	x0, [x1, #56]
    2b2c:	940002f5 	bl	3700 <fwp_now_ns>
    2b30:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x350>
    2b34:	910a4000 	add	x0, x0, #0x290
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000042 	adrp	x2, c000 <f0+0x2630>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	91014042 	add	x2, x2, #0x50
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9100c273 	add	x19, x19, #0x30
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9430a60 	ldr	w0, [x19, #776]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff48 	bl	2970 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x350>
    2c7c:	910a8000 	add	x0, x0, #0x2a0
    2c80:	94000240 	bl	3580 <fwp_trap>
    2c84:	97fffeff 	bl	2880 <__stack_chk_fail@plt>
    2c88:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x350>
    2c8c:	910d0000 	add	x0, x0, #0x340
    2c90:	9400023c 	bl	3580 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffee6 	bl	2830 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x350>
    2ca4:	910c6000 	add	x0, x0, #0x318
    2ca8:	94000236 	bl	3580 <fwp_trap>
    2cac:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x350>
    2cb0:	910ba000 	add	x0, x0, #0x2e8
    2cb4:	94000233 	bl	3580 <fwp_trap>
    2cb8:	f0000040 	adrp	x0, d000 <_IO_stdin_used+0x350>
    2cbc:	910b0000 	add	x0, x0, #0x2c0
    2cc0:	94000230 	bl	3580 <fwp_trap>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91008000 	add	x0, x0, #0x20
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91008021 	add	x1, x1, #0x20
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91008000 	add	x0, x0, #0x20
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91008021 	add	x1, x1, #0x20
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39408260 	ldrb	w0, [x19, #32]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39008260 	strb	w0, [x19, #32]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	f0000041 	adrp	x1, d000 <_IO_stdin_used+0x350>
    2eb4:	91258021 	add	x1, x1, #0x960
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9401884 	ldr	x4, [x4, #48]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9401863 	ldr	x3, [x3, #48]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args173>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9401c00 	ldr	x0, [x0, #56]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	b0000040 	adrp	x0, c000 <f0+0x2630>
    3050:	9132e000 	add	x0, x0, #0xcb8
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9100c043 	add	x3, x2, #0x30
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9100c042 	add	x2, x2, #0x30
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0x350>
    3118:	91250021 	add	x1, x1, #0x940
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    3144:	911502a1 	add	x1, x21, #0x540
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    3158:	9124c0a5 	add	x5, x5, #0x930
    315c:	911502a1 	add	x1, x21, #0x540
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911502b7 	add	x23, x21, #0x540
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffe08 	bl	2a30 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffded 	bl	29d0 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdf6 	bl	2a30 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911502b5 	add	x21, x21, #0x540
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911502b5 	add	x21, x21, #0x540
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    32e8:	9124a0a5 	add	x5, x5, #0x928
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff4d 	bl	3030 <fwp_heap_oom>

0000000000003300 <fwp_tape_buffers_dispose>:
    3300:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3304:	910003fd 	mov	x29, sp
    3308:	f9000bf3 	str	x19, [sp, #16]
    330c:	aa0003f3 	mov	x19, x0
    3310:	f9400000 	ldr	x0, [x0]
    3314:	97fffd8b 	bl	2940 <free@plt>
    3318:	f9400a60 	ldr	x0, [x19, #16]
    331c:	97fffd89 	bl	2940 <free@plt>
    3320:	f9401260 	ldr	x0, [x19, #32]
    3324:	97fffd87 	bl	2940 <free@plt>
    3328:	f9001a7f 	str	xzr, [x19, #48]
    332c:	4f000400 	movi	v0.4s, #0x0
    3330:	ad000260 	stp	q0, q0, [x19]
    3334:	3d800a60 	str	q0, [x19, #32]
    3338:	f9400bf3 	ldr	x19, [sp, #16]
    333c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3340:	d65f03c0 	ret

0000000000003344 <buf_grow>:
    3344:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3348:	910003fd 	mov	x29, sp
    334c:	a90153f3 	stp	x19, x20, [sp, #16]
    3350:	aa0003f4 	mov	x20, x0
    3354:	f9400400 	ldr	x0, [x0, #8]
    3358:	b100041f 	cmn	x0, #0x1
    335c:	54000400 	b.eq	33dc <buf_grow+0x98>  // b.none
    3360:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3364:	cb000042 	sub	x2, x2, x0
    3368:	eb01005f 	cmp	x2, x1
    336c:	54000383 	b.cc	33dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3370:	f9400a82 	ldr	x2, [x20, #16]
    3374:	91000421 	add	x1, x1, #0x1
    3378:	8b000033 	add	x19, x1, x0
    337c:	eb13005f 	cmp	x2, x19
    3380:	54000242 	b.cs	33c8 <buf_grow+0x84>  // b.hs, b.nlast
    3384:	f100005f 	cmp	x2, #0x0
    3388:	b5000262 	cbnz	x2, 33d4 <buf_grow+0x90>
    338c:	d2800802 	mov	x2, #0x40                  	// #64
    3390:	eb02027f 	cmp	x19, x2
    3394:	54000068 	b.hi	33a0 <buf_grow+0x5c>  // b.pmore
    3398:	14000005 	b	33ac <buf_grow+0x68>
    339c:	b7f800a2 	tbnz	x2, #63, 33b0 <buf_grow+0x6c>
    33a0:	d37ff842 	lsl	x2, x2, #1
    33a4:	eb02027f 	cmp	x19, x2
    33a8:	54ffffa8 	b.hi	339c <buf_grow+0x58>  // b.pmore
    33ac:	aa0203f3 	mov	x19, x2
    33b0:	f9400280 	ldr	x0, [x20]
    33b4:	aa1303e1 	mov	x1, x19
    33b8:	97fffd2e 	bl	2870 <realloc@plt>
    33bc:	b4000100 	cbz	x0, 33dc <buf_grow+0x98>
    33c0:	f9000280 	str	x0, [x20]
    33c4:	f9000a93 	str	x19, [x20, #16]
    33c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    33d0:	d65f03c0 	ret
    33d4:	54fffe6a 	b.ge	33a0 <buf_grow+0x5c>  // b.tcont
    33d8:	17fffff6 	b	33b0 <buf_grow+0x6c>
    33dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    33e0:	f947e863 	ldr	x3, [x3, #4048]
    33e4:	d2800262 	mov	x2, #0x13                  	// #19
    33e8:	d2800021 	mov	x1, #0x1                   	// #1
    33ec:	b0000040 	adrp	x0, c000 <f0+0x2630>
    33f0:	9132e000 	add	x0, x0, #0xcb8
    33f4:	f9400063 	ldr	x3, [x3]
    33f8:	97fffd62 	bl	2980 <fwrite@plt>
    33fc:	d2800000 	mov	x0, #0x0                   	// #0
    3400:	97fffd6c 	bl	29b0 <fflush@plt>
    3404:	52800cc0 	mov	w0, #0x66                  	// #102
    3408:	97fffd7a 	bl	29f0 <_Exit@plt>
    340c:	d503201f 	nop

0000000000003410 <buf_put>:
    3410:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3414:	910003fd 	mov	x29, sp
    3418:	a90153f3 	stp	x19, x20, [sp, #16]
    341c:	aa0003f4 	mov	x20, x0
    3420:	aa0203f3 	mov	x19, x2
    3424:	f90013f5 	str	x21, [sp, #32]
    3428:	aa0103f5 	mov	x21, x1
    342c:	aa0203e1 	mov	x1, x2
    3430:	97ffffc5 	bl	3344 <buf_grow>
    3434:	a9400283 	ldp	x3, x0, [x20]
    3438:	aa1503e1 	mov	x1, x21
    343c:	aa1303e2 	mov	x2, x19
    3440:	8b000060 	add	x0, x3, x0
    3444:	97fffca3 	bl	26d0 <memcpy@plt>
    3448:	a9400680 	ldp	x0, x1, [x20]
    344c:	8b010273 	add	x19, x19, x1
    3450:	f9000693 	str	x19, [x20, #8]
    3454:	3833681f 	strb	wzr, [x0, x19]
    3458:	a94153f3 	ldp	x19, x20, [sp, #16]
    345c:	f94013f5 	ldr	x21, [sp, #32]
    3460:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3464:	d65f03c0 	ret
    3468:	d503201f 	nop
    346c:	d503201f 	nop

0000000000003470 <fwp_cancel_tree.part.0>:
    3470:	b00000e1 	adrp	x1, 20000 <__data_start>
    3474:	9100c022 	add	x2, x1, #0x30
    3478:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    347c:	52800023 	mov	w3, #0x1                   	// #1
    3480:	910003fd 	mov	x29, sp
    3484:	f9400844 	ldr	x4, [x2, #16]
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	39014403 	strb	w3, [x0, #81]
    3490:	eb04001f 	cmp	x0, x4
    3494:	54000160 	b.eq	34c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3498:	f9402804 	ldr	x4, [x0, #80]
    349c:	f2001c9f 	tst	x4, #0xff000000ff
    34a0:	54000101 	b.ne	34c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    34a4:	f9401444 	ldr	x4, [x2, #40]
    34a8:	39015003 	strb	w3, [x0, #84]
    34ac:	f900801f 	str	xzr, [x0, #256]
    34b0:	b40001e4 	cbz	x4, 34ec <fwp_cancel_tree.part.0+0x7c>
    34b4:	f9008080 	str	x0, [x4, #256]
    34b8:	9100c021 	add	x1, x1, #0x30
    34bc:	f9001420 	str	x0, [x1, #40]
    34c0:	f9401413 	ldr	x19, [x0, #40]
    34c4:	b40000f3 	cbz	x19, 34e0 <fwp_cancel_tree.part.0+0x70>
    34c8:	39414261 	ldrb	w1, [x19, #80]
    34cc:	aa1303e0 	mov	x0, x19
    34d0:	37000041 	tbnz	w1, #0, 34d8 <fwp_cancel_tree.part.0+0x68>
    34d4:	97ffffe7 	bl	3470 <fwp_cancel_tree.part.0>
    34d8:	f9401a73 	ldr	x19, [x19, #48]
    34dc:	b5ffff73 	cbnz	x19, 34c8 <fwp_cancel_tree.part.0+0x58>
    34e0:	f9400bf3 	ldr	x19, [sp, #16]
    34e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34e8:	d65f03c0 	ret
    34ec:	f9001840 	str	x0, [x2, #48]
    34f0:	17fffff2 	b	34b8 <fwp_cancel_tree.part.0+0x48>

00000000000034f4 <fwp_finish_float>:
    34f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34f8:	528005c1 	mov	w1, #0x2e                  	// #46
    34fc:	910003fd 	mov	x29, sp
    3500:	f9000bf3 	str	x19, [sp, #16]
    3504:	aa0003f3 	mov	x19, x0
    3508:	97fffd16 	bl	2960 <strchr@plt>
    350c:	b4000080 	cbz	x0, 351c <fwp_finish_float+0x28>
    3510:	f9400bf3 	ldr	x19, [sp, #16]
    3514:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3518:	d65f03c0 	ret
    351c:	aa1303e0 	mov	x0, x19
    3520:	52800ca1 	mov	w1, #0x65                  	// #101
    3524:	97fffd0f 	bl	2960 <strchr@plt>
    3528:	b5ffff40 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    352c:	b0000041 	adrp	x1, c000 <f0+0x2630>
    3530:	aa1303e0 	mov	x0, x19
    3534:	91334021 	add	x1, x1, #0xcd0
    3538:	97fffd2a 	bl	29e0 <strstr@plt>
    353c:	b5fffea0 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3540:	b0000041 	adrp	x1, c000 <f0+0x2630>
    3544:	aa1303e0 	mov	x0, x19
    3548:	91336021 	add	x1, x1, #0xcd8
    354c:	97fffd25 	bl	29e0 <strstr@plt>
    3550:	b5fffe00 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3554:	aa1303e0 	mov	x0, x19
    3558:	97fffc6e 	bl	2710 <strlen@plt>
    355c:	b0000041 	adrp	x1, c000 <f0+0x2630>
    3560:	91338021 	add	x1, x1, #0xce0
    3564:	8b000262 	add	x2, x19, x0
    3568:	79400023 	ldrh	w3, [x1]
    356c:	39400821 	ldrb	w1, [x1, #2]
    3570:	78206a63 	strh	w3, [x19, x0]
    3574:	39000841 	strb	w1, [x2, #2]
    3578:	17ffffe6 	b	3510 <fwp_finish_float+0x1c>
    357c:	d503201f 	nop

0000000000003580 <fwp_trap>:
    3580:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3584:	d53bd041 	mrs	x1, tpidr_el0
    3588:	91400021 	add	x1, x1, #0x0, lsl #12
    358c:	91004021 	add	x1, x1, #0x10
    3590:	910003fd 	mov	x29, sp
    3594:	a90153f3 	stp	x19, x20, [sp, #16]
    3598:	aa0003f3 	mov	x19, x0
    359c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    35a0:	f947ea94 	ldr	x20, [x20, #4048]
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	f9400035 	ldr	x21, [x1]
    35ac:	97fffe91 	bl	2ff0 <fwp_flush>
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	b0000042 	adrp	x2, c000 <f0+0x2630>
    35b8:	aa1303e3 	mov	x3, x19
    35bc:	9133a042 	add	x2, x2, #0xce8
    35c0:	52800041 	mov	w1, #0x2                   	// #2
    35c4:	97fffccb 	bl	28f0 <__fprintf_chk@plt>
    35c8:	b40000b5 	cbz	x21, 35dc <fwp_trap+0x5c>
    35cc:	f9400280 	ldr	x0, [x20]
    35d0:	97fffcf8 	bl	29b0 <fflush@plt>
    35d4:	52800ca0 	mov	w0, #0x65                  	// #101
    35d8:	97fffd06 	bl	29f0 <_Exit@plt>
    35dc:	52800ca0 	mov	w0, #0x65                  	// #101
    35e0:	97fffc54 	bl	2730 <exit@plt>

00000000000035e4 <fwp_closure_drop_push>:
    35e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    35e8:	910003fd 	mov	x29, sp
    35ec:	a90153f3 	stp	x19, x20, [sp, #16]
    35f0:	aa0003f3 	mov	x19, x0
    35f4:	a9408014 	ldp	x20, x0, [x0, #8]
    35f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    35fc:	aa0103f5 	mov	x21, x1
    3600:	a90363f7 	stp	x23, x24, [sp, #48]
    3604:	eb00029f 	cmp	x20, x0
    3608:	54000160 	b.eq	3634 <fwp_closure_drop_push+0x50>  // b.none
    360c:	f9400276 	ldr	x22, [x19]
    3610:	d37df297 	lsl	x23, x20, #3
    3614:	91000694 	add	x20, x20, #0x1
    3618:	f9000674 	str	x20, [x19, #8]
    361c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3620:	f8376ad5 	str	x21, [x22, x23]
    3624:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3628:	a94363f7 	ldp	x23, x24, [sp, #48]
    362c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3630:	d65f03c0 	ret
    3634:	a9046bf9 	stp	x25, x26, [sp, #64]
    3638:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    363c:	eb00029f 	cmp	x20, x0
    3640:	54000568 	b.hi	36ec <fwp_closure_drop_push+0x108>  // b.pmore
    3644:	d37cee99 	lsl	x25, x20, #4
    3648:	d37ffa9a 	lsl	x26, x20, #1
    364c:	aa1903e0 	mov	x0, x25
    3650:	97fffc74 	bl	2820 <malloc@plt>
    3654:	aa0003f6 	mov	x22, x0
    3658:	b4000320 	cbz	x0, 36bc <fwp_closure_drop_push+0xd8>
    365c:	aa1303f8 	mov	x24, x19
    3660:	aa1903e3 	mov	x3, x25
    3664:	d37df297 	lsl	x23, x20, #3
    3668:	aa1703e2 	mov	x2, x23
    366c:	f8418719 	ldr	x25, [x24], #24
    3670:	aa1903e1 	mov	x1, x25
    3674:	97fffc57 	bl	27d0 <__memcpy_chk@plt>
    3678:	eb18033f 	cmp	x25, x24
    367c:	540000a0 	b.eq	3690 <fwp_closure_drop_push+0xac>  // b.none
    3680:	aa1903e0 	mov	x0, x25
    3684:	97fffcaf 	bl	2940 <free@plt>
    3688:	f9400674 	ldr	x20, [x19, #8]
    368c:	d37df297 	lsl	x23, x20, #3
    3690:	91000694 	add	x20, x20, #0x1
    3694:	f9000276 	str	x22, [x19]
    3698:	f9000a7a 	str	x26, [x19, #16]
    369c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    36a0:	f9000674 	str	x20, [x19, #8]
    36a4:	f8376ad5 	str	x21, [x22, x23]
    36a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    36b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    36b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    36b8:	d65f03c0 	ret
    36bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    36c0:	f947e863 	ldr	x3, [x3, #4048]
    36c4:	d2800262 	mov	x2, #0x13                  	// #19
    36c8:	d2800021 	mov	x1, #0x1                   	// #1
    36cc:	b0000040 	adrp	x0, c000 <f0+0x2630>
    36d0:	9132e000 	add	x0, x0, #0xcb8
    36d4:	f9400063 	ldr	x3, [x3]
    36d8:	97fffcaa 	bl	2980 <fwrite@plt>
    36dc:	d2800000 	mov	x0, #0x0                   	// #0
    36e0:	97fffcb4 	bl	29b0 <fflush@plt>
    36e4:	52800cc0 	mov	w0, #0x66                  	// #102
    36e8:	97fffcc2 	bl	29f0 <_Exit@plt>
    36ec:	b0000040 	adrp	x0, c000 <f0+0x2630>
    36f0:	9133e000 	add	x0, x0, #0xcf8
    36f4:	97ffffa3 	bl	3580 <fwp_trap>
    36f8:	d503201f 	nop
    36fc:	d503201f 	nop

0000000000003700 <fwp_now_ns>:
    3700:	d100c3ff 	sub	sp, sp, #0x30
    3704:	52800020 	mov	w0, #0x1                   	// #1
    3708:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    370c:	f947f442 	ldr	x2, [x2, #4072]
    3710:	910023e1 	add	x1, sp, #0x8
    3714:	a9027bfd 	stp	x29, x30, [sp, #32]
    3718:	910083fd 	add	x29, sp, #0x20
    371c:	f9400043 	ldr	x3, [x2]
    3720:	f9000fe3 	str	x3, [sp, #24]
    3724:	d2800003 	mov	x3, #0x0                   	// #0
    3728:	97fffc22 	bl	27b0 <clock_gettime@plt>
    372c:	350002c0 	cbnz	w0, 3784 <fwp_now_ns+0x84>
    3730:	a9408be1 	ldp	x1, x2, [sp, #8]
    3734:	d2994003 	mov	x3, #0xca00                	// #51712
    3738:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    373c:	9b037c20 	mul	x0, x1, x3
    3740:	9b437c21 	smulh	x1, x1, x3
    3744:	ab020000 	adds	x0, x0, x2
    3748:	937ffc42 	asr	x2, x2, #63
    374c:	9a020021 	adc	x1, x1, x2
    3750:	f100001f 	cmp	x0, #0x0
    3754:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3758:	b50001e1 	cbnz	x1, 3794 <fwp_now_ns+0x94>
    375c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3760:	f947f421 	ldr	x1, [x1, #4072]
    3764:	f9400fe3 	ldr	x3, [sp, #24]
    3768:	f9400022 	ldr	x2, [x1]
    376c:	eb020063 	subs	x3, x3, x2
    3770:	d2800002 	mov	x2, #0x0                   	// #0
    3774:	540000e1 	b.ne	3790 <fwp_now_ns+0x90>  // b.any
    3778:	a9427bfd 	ldp	x29, x30, [sp, #32]
    377c:	9100c3ff 	add	sp, sp, #0x30
    3780:	d65f03c0 	ret
    3784:	b0000040 	adrp	x0, c000 <f0+0x2630>
    3788:	91346000 	add	x0, x0, #0xd18
    378c:	97ffff7d 	bl	3580 <fwp_trap>
    3790:	97fffc3c 	bl	2880 <__stack_chk_fail@plt>
    3794:	b0000040 	adrp	x0, c000 <f0+0x2630>
    3798:	9134e000 	add	x0, x0, #0xd38
    379c:	97ffff79 	bl	3580 <fwp_trap>

00000000000037a0 <fwp_closure_drop.part.0>:
    37a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    37a4:	d0000041 	adrp	x1, d000 <_IO_stdin_used+0x350>
    37a8:	910003fd 	mov	x29, sp
    37ac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    37b0:	f947f463 	ldr	x3, [x3, #4072]
    37b4:	a90153f3 	stp	x19, x20, [sp, #16]
    37b8:	d10883ff 	sub	sp, sp, #0x220
    37bc:	910003e2 	mov	x2, sp
    37c0:	d53bd053 	mrs	x19, tpidr_el0
    37c4:	910063f4 	add	x20, sp, #0x18
    37c8:	3dc25c20 	ldr	q0, [x1, #2416]
    37cc:	91400264 	add	x4, x19, #0x0, lsl #12
    37d0:	91004084 	add	x4, x4, #0x10
    37d4:	aa0003e1 	mov	x1, x0
    37d8:	aa0203e0 	mov	x0, x2
    37dc:	f9400062 	ldr	x2, [x3]
    37e0:	f9010fe2 	str	x2, [sp, #536]
    37e4:	d2800002 	mov	x2, #0x0                   	// #0
    37e8:	f90003f4 	str	x20, [sp]
    37ec:	f9000080 	str	x0, [x4]
    37f0:	3c8083e0 	stur	q0, [sp, #8]
    37f4:	97ffff7c 	bl	35e4 <fwp_closure_drop_push>
    37f8:	f94007e0 	ldr	x0, [sp, #8]
    37fc:	b4000280 	cbz	x0, 384c <fwp_closure_drop.part.0+0xac>
    3800:	f90123f5 	str	x21, [sp, #576]
    3804:	b00000f5 	adrp	x21, 20000 <__data_start>
    3808:	9100c2b5 	add	x21, x21, #0x30
    380c:	d503201f 	nop
    3810:	f94003e1 	ldr	x1, [sp]
    3814:	d1000400 	sub	x0, x0, #0x1
    3818:	f90007e0 	str	x0, [sp, #8]
    381c:	f9401ea2 	ldr	x2, [x21, #56]
    3820:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3824:	b9400001 	ldr	w1, [x0]
    3828:	8b011441 	add	x1, x2, x1, lsl #5
    382c:	f9400c21 	ldr	x1, [x1, #24]
    3830:	b4000321 	cbz	x1, 3894 <fwp_closure_drop.part.0+0xf4>
    3834:	f9400422 	ldr	x2, [x1, #8]
    3838:	52800001 	mov	w1, #0x0                   	// #0
    383c:	d63f0040 	blr	x2
    3840:	f94007e0 	ldr	x0, [sp, #8]
    3844:	b5fffe60 	cbnz	x0, 3810 <fwp_closure_drop.part.0+0x70>
    3848:	f94123f5 	ldr	x21, [sp, #576]
    384c:	91400273 	add	x19, x19, #0x0, lsl #12
    3850:	91004273 	add	x19, x19, #0x10
    3854:	f94003e0 	ldr	x0, [sp]
    3858:	f900027f 	str	xzr, [x19]
    385c:	eb14001f 	cmp	x0, x20
    3860:	54000040 	b.eq	3868 <fwp_closure_drop.part.0+0xc8>  // b.none
    3864:	97fffc37 	bl	2940 <free@plt>
    3868:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    386c:	f947f400 	ldr	x0, [x0, #4072]
    3870:	f9410fe2 	ldr	x2, [sp, #536]
    3874:	f9400001 	ldr	x1, [x0]
    3878:	eb010042 	subs	x2, x2, x1
    387c:	d2800001 	mov	x1, #0x0                   	// #0
    3880:	54000101 	b.ne	38a0 <fwp_closure_drop.part.0+0x100>  // b.any
    3884:	910883ff 	add	sp, sp, #0x220
    3888:	a94153f3 	ldp	x19, x20, [sp, #16]
    388c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3890:	d65f03c0 	ret
    3894:	b0000040 	adrp	x0, c000 <f0+0x2630>
    3898:	91358000 	add	x0, x0, #0xd60
    389c:	97ffff39 	bl	3580 <fwp_trap>
    38a0:	f90123f5 	str	x21, [sp, #576]
    38a4:	97fffbf7 	bl	2880 <__stack_chk_fail@plt>
    38a8:	d503201f 	nop
    38ac:	d503201f 	nop

00000000000038b0 <fwp_tape_of>:
    38b0:	92403c02 	and	x2, x0, #0xffff
    38b4:	b4000262 	cbz	x2, 3900 <fwp_tape_of+0x50>
    38b8:	9350fc01 	asr	x1, x0, #16
    38bc:	b00000e3 	adrp	x3, 20000 <__data_start>
    38c0:	d1000440 	sub	x0, x2, #0x1
    38c4:	9100c062 	add	x2, x3, #0x30
    38c8:	f9402042 	ldr	x2, [x2, #64]
    38cc:	eb00005f 	cmp	x2, x0
    38d0:	5400018d 	b.le	3900 <fwp_tape_of+0x50>
    38d4:	8b000402 	add	x2, x0, x0, lsl #1
    38d8:	f9401863 	ldr	x3, [x3, #48]
    38dc:	8b020802 	add	x2, x0, x2, lsl #2
    38e0:	d37df042 	lsl	x2, x2, #3
    38e4:	8b020060 	add	x0, x3, x2
    38e8:	b9400404 	ldr	w4, [x0, #4]
    38ec:	340000a4 	cbz	w4, 3900 <fwp_tape_of+0x50>
    38f0:	b8626862 	ldr	w2, [x3, x2]
    38f4:	6b01005f 	cmp	w2, w1
    38f8:	54000041 	b.ne	3900 <fwp_tape_of+0x50>  // b.any
    38fc:	d65f03c0 	ret
    3900:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3904:	b0000040 	adrp	x0, c000 <f0+0x2630>
    3908:	91364000 	add	x0, x0, #0xd90
    390c:	910003fd 	mov	x29, sp
    3910:	97ffff1c 	bl	3580 <fwp_trap>

0000000000003914 <fwp_format_g.constprop.0>:
    3914:	d10483ff 	sub	sp, sp, #0x120
    3918:	b0000044 	adrp	x4, c000 <f0+0x2630>
    391c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3920:	f947f442 	ldr	x2, [x2, #4072]
    3924:	91378084 	add	x4, x4, #0xde0
    3928:	a90b7bfd 	stp	x29, x30, [sp, #176]
    392c:	9102c3fd 	add	x29, sp, #0xb0
    3930:	d2800803 	mov	x3, #0x40                  	// #64
    3934:	a90e63f7 	stp	x23, x24, [sp, #224]
    3938:	93407c38 	sxtw	x24, w1
    393c:	aa0303e1 	mov	x1, x3
    3940:	fd008be8 	str	d8, [sp, #272]
    3944:	1e604008 	fmov	d8, d0
    3948:	a90c53f3 	stp	x19, x20, [sp, #192]
    394c:	910083f4 	add	x20, sp, #0x20
    3950:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3954:	aa0003f5 	mov	x21, x0
    3958:	a91073fb 	stp	x27, x28, [sp, #256]
    395c:	5100071c 	sub	w28, w24, #0x1
    3960:	2a1c03e5 	mov	w5, w28
    3964:	f9400040 	ldr	x0, [x2]
    3968:	f90057e0 	str	x0, [sp, #168]
    396c:	d2800000 	mov	x0, #0x0                   	// #0
    3970:	52800042 	mov	w2, #0x2                   	// #2
    3974:	aa1403e0 	mov	x0, x20
    3978:	97fffb9e 	bl	27f0 <__snprintf_chk@plt>
    397c:	52800ca1 	mov	w1, #0x65                  	// #101
    3980:	aa1403e0 	mov	x0, x20
    3984:	97fffbf7 	bl	2960 <strchr@plt>
    3988:	aa0003f3 	mov	x19, x0
    398c:	52800142 	mov	w2, #0xa                   	// #10
    3990:	91000400 	add	x0, x0, #0x1
    3994:	d2800001 	mov	x1, #0x0                   	// #0
    3998:	97fffbe2 	bl	2920 <strtol@plt>
    399c:	aa0003f7 	mov	x23, x0
    39a0:	11001400 	add	w0, w0, #0x5
    39a4:	7100541f 	cmp	w0, #0x15
    39a8:	54000d88 	b.hi	3b58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    39ac:	4b170385 	sub	w5, w28, w23
    39b0:	710000bf 	cmp	w5, #0x0
    39b4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    39b8:	54000ba0 	b.eq	3b2c <fwp_format_g.constprop.0+0x218>  // b.none
    39bc:	394083e0 	ldrb	w0, [sp, #32]
    39c0:	cb180273 	sub	x19, x19, x24
    39c4:	91000673 	add	x19, x19, #0x1
    39c8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    39cc:	7100b41f 	cmp	w0, #0x2d
    39d0:	9a941681 	cinc	x1, x20, eq	// eq = none
    39d4:	1a9f17e4 	cset	w4, eq	// eq = none
    39d8:	cb010266 	sub	x6, x19, x1
    39dc:	d10004da 	sub	x26, x6, #0x1
    39e0:	540018c0 	b.eq	3cf8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    39e4:	910183f9 	add	x25, sp, #0x60
    39e8:	d280091b 	mov	x27, #0x48                  	// #72
    39ec:	aa1903e7 	mov	x7, x25
    39f0:	91000423 	add	x3, x1, #0x1
    39f4:	91011cc6 	add	x6, x6, #0x47
    39f8:	910004f6 	add	x22, x7, #0x1
    39fc:	37f81017 	tbnz	w23, #31, 3bfc <fwp_format_g.constprop.0+0x2e8>
    3a00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3a04:	93407ef7 	sxtw	x23, w23
    3a08:	390000e4 	strb	w4, [x7]
    3a0c:	aa1303e1 	mov	x1, x19
    3a10:	aa1703e2 	mov	x2, x23
    3a14:	aa1603e0 	mov	x0, x22
    3a18:	b9000be5 	str	w5, [sp, #8]
    3a1c:	cb170374 	sub	x20, x27, x23
    3a20:	a9011be3 	stp	x3, x6, [sp, #16]
    3a24:	97fffb2b 	bl	26d0 <memcpy@plt>
    3a28:	d1000694 	sub	x20, x20, #0x1
    3a2c:	f9400be3 	ldr	x3, [sp, #16]
    3a30:	8b1702d6 	add	x22, x22, x23
    3a34:	aa1603e0 	mov	x0, x22
    3a38:	aa1a03e2 	mov	x2, x26
    3a3c:	aa0303e1 	mov	x1, x3
    3a40:	aa1403e3 	mov	x3, x20
    3a44:	97fffb63 	bl	27d0 <__memcpy_chk@plt>
    3a48:	8b1a02d6 	add	x22, x22, x26
    3a4c:	f9400fe6 	ldr	x6, [sp, #24]
    3a50:	d2800900 	mov	x0, #0x48                  	// #72
    3a54:	b9400be5 	ldr	w5, [sp, #8]
    3a58:	8b170261 	add	x1, x19, x23
    3a5c:	cb1400c3 	sub	x3, x6, x20
    3a60:	cb060294 	sub	x20, x20, x6
    3a64:	f101207f 	cmp	x3, #0x48
    3a68:	93407cb8 	sxtw	x24, w5
    3a6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3a70:	aa1803e2 	mov	x2, x24
    3a74:	8b1802d3 	add	x19, x22, x24
    3a78:	8b140063 	add	x3, x3, x20
    3a7c:	aa1603e0 	mov	x0, x22
    3a80:	97fffb54 	bl	27d0 <__memcpy_chk@plt>
    3a84:	cb190273 	sub	x19, x19, x25
    3a88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3a8c:	eb00027f 	cmp	x19, x0
    3a90:	aa1903e1 	mov	x1, x25
    3a94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a98:	aa1503e0 	mov	x0, x21
    3a9c:	aa1303e2 	mov	x2, x19
    3aa0:	97fffb0c 	bl	26d0 <memcpy@plt>
    3aa4:	38336abf 	strb	wzr, [x21, x19]
    3aa8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3aac:	aa1503e0 	mov	x0, x21
    3ab0:	97fffb18 	bl	2710 <strlen@plt>
    3ab4:	aa0003f3 	mov	x19, x0
    3ab8:	528005c1 	mov	w1, #0x2e                  	// #46
    3abc:	aa1503e0 	mov	x0, x21
    3ac0:	97fffba8 	bl	2960 <strchr@plt>
    3ac4:	b4000160 	cbz	x0, 3af0 <fwp_format_g.constprop.0+0x1dc>
    3ac8:	b4000153 	cbz	x19, 3af0 <fwp_format_g.constprop.0+0x1dc>
    3acc:	d503201f 	nop
    3ad0:	aa1303e1 	mov	x1, x19
    3ad4:	d1000673 	sub	x19, x19, #0x1
    3ad8:	38736aa0 	ldrb	w0, [x21, x19]
    3adc:	7100c01f 	cmp	w0, #0x30
    3ae0:	54001001 	b.ne	3ce0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3ae4:	38336abf 	strb	wzr, [x21, x19]
    3ae8:	b5ffff53 	cbnz	x19, 3ad0 <fwp_format_g.constprop.0+0x1bc>
    3aec:	d503201f 	nop
    3af0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3af4:	f947f400 	ldr	x0, [x0, #4072]
    3af8:	f94057e2 	ldr	x2, [sp, #168]
    3afc:	f9400001 	ldr	x1, [x0]
    3b00:	eb010042 	subs	x2, x2, x1
    3b04:	d2800001 	mov	x1, #0x0                   	// #0
    3b08:	54001061 	b.ne	3d14 <fwp_format_g.constprop.0+0x400>  // b.any
    3b0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3b10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3b14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3b18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3b1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3b20:	fd408be8 	ldr	d8, [sp, #272]
    3b24:	910483ff 	add	sp, sp, #0x120
    3b28:	d65f03c0 	ret
    3b2c:	1e604100 	fmov	d0, d8
    3b30:	710000bf 	cmp	w5, #0x0
    3b34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3b38:	aa1503e0 	mov	x0, x21
    3b3c:	b0000044 	adrp	x4, c000 <f0+0x2630>
    3b40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b44:	9137e084 	add	x4, x4, #0xdf8
    3b48:	52800042 	mov	w2, #0x2                   	// #2
    3b4c:	d2803201 	mov	x1, #0x190                 	// #400
    3b50:	97fffb28 	bl	27f0 <__snprintf_chk@plt>
    3b54:	17ffffd6 	b	3aac <fwp_format_g.constprop.0+0x198>
    3b58:	cb140273 	sub	x19, x19, x20
    3b5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3b60:	910183f9 	add	x25, sp, #0x60
    3b64:	aa1303e2 	mov	x2, x19
    3b68:	aa1403e1 	mov	x1, x20
    3b6c:	aa1903e0 	mov	x0, x25
    3b70:	d2800803 	mov	x3, #0x40                  	// #64
    3b74:	97fffb17 	bl	27d0 <__memcpy_chk@plt>
    3b78:	38336b3f 	strb	wzr, [x25, x19]
    3b7c:	aa1903e0 	mov	x0, x25
    3b80:	528005c1 	mov	w1, #0x2e                  	// #46
    3b84:	97fffb77 	bl	2960 <strchr@plt>
    3b88:	b40001c0 	cbz	x0, 3bc0 <fwp_format_g.constprop.0+0x2ac>
    3b8c:	b50000b3 	cbnz	x19, 3ba0 <fwp_format_g.constprop.0+0x28c>
    3b90:	1400000c 	b	3bc0 <fwp_format_g.constprop.0+0x2ac>
    3b94:	381ff01f 	sturb	wzr, [x0, #-1]
    3b98:	f1000673 	subs	x19, x19, #0x1
    3b9c:	54000120 	b.eq	3bc0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3ba0:	8b130320 	add	x0, x25, x19
    3ba4:	385ff001 	ldurb	w1, [x0, #-1]
    3ba8:	7100c03f 	cmp	w1, #0x30
    3bac:	54ffff40 	b.eq	3b94 <fwp_format_g.constprop.0+0x280>  // b.none
    3bb0:	d1000673 	sub	x19, x19, #0x1
    3bb4:	38736b20 	ldrb	w0, [x25, x19]
    3bb8:	7100b81f 	cmp	w0, #0x2e
    3bbc:	54000a80 	b.eq	3d0c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3bc0:	710002ff 	cmp	w23, #0x0
    3bc4:	528005a1 	mov	w1, #0x2d                  	// #45
    3bc8:	aa1903e5 	mov	x5, x25
    3bcc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3bd0:	aa1503e0 	mov	x0, x21
    3bd4:	52800566 	mov	w6, #0x2b                  	// #43
    3bd8:	b0000044 	adrp	x4, c000 <f0+0x2630>
    3bdc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3be0:	9137a084 	add	x4, x4, #0xde8
    3be4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3be8:	52800042 	mov	w2, #0x2                   	// #2
    3bec:	d2803201 	mov	x1, #0x190                 	// #400
    3bf0:	97fffb00 	bl	27f0 <__snprintf_chk@plt>
    3bf4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3bf8:	17ffffbe 	b	3af0 <fwp_format_g.constprop.0+0x1dc>
    3bfc:	52800605 	mov	w5, #0x30                  	// #48
    3c00:	390000e5 	strb	w5, [x7]
    3c04:	d100077b 	sub	x27, x27, #0x1
    3c08:	aa0303e1 	mov	x1, x3
    3c0c:	aa1603e0 	mov	x0, x22
    3c10:	aa1b03e3 	mov	x3, x27
    3c14:	aa1a03e2 	mov	x2, x26
    3c18:	f90007e6 	str	x6, [sp, #8]
    3c1c:	b90013e4 	str	w4, [sp, #16]
    3c20:	8b1a02d6 	add	x22, x22, x26
    3c24:	b9001be5 	str	w5, [sp, #24]
    3c28:	97fffaea 	bl	27d0 <__memcpy_chk@plt>
    3c2c:	f94007e6 	ldr	x6, [sp, #8]
    3c30:	2a3703e7 	mvn	w7, w23
    3c34:	b94013e4 	ldr	w4, [sp, #16]
    3c38:	cb1b00c1 	sub	x1, x6, x27
    3c3c:	cb06037b 	sub	x27, x27, x6
    3c40:	f101203f 	cmp	x1, #0x48
    3c44:	d2800906 	mov	x6, #0x48                  	// #72
    3c48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3c4c:	8b1b0023 	add	x3, x1, x27
    3c50:	310006ff 	cmn	w23, #0x1
    3c54:	54000220 	b.eq	3c98 <fwp_format_g.constprop.0+0x384>  // b.none
    3c58:	b9401be5 	ldr	w5, [sp, #24]
    3c5c:	d2800001 	mov	x1, #0x0                   	// #0
    3c60:	f101207f 	cmp	x3, #0x48
    3c64:	d1000462 	sub	x2, x3, #0x1
    3c68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3c6c:	38216ac5 	strb	w5, [x22, x1]
    3c70:	cb030003 	sub	x3, x0, x3
    3c74:	91000421 	add	x1, x1, #0x1
    3c78:	91000463 	add	x3, x3, #0x1
    3c7c:	eb00007f 	cmp	x3, x0
    3c80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c84:	cb000063 	sub	x3, x3, x0
    3c88:	8b020063 	add	x3, x3, x2
    3c8c:	6b0100ff 	cmp	w7, w1
    3c90:	54fffe8c 	b.gt	3c60 <fwp_format_g.constprop.0+0x34c>
    3c94:	8b2742d6 	add	x22, x22, w7, uxtw
    3c98:	f101207f 	cmp	x3, #0x48
    3c9c:	d2800905 	mov	x5, #0x48                  	// #72
    3ca0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3ca4:	aa1603e0 	mov	x0, x22
    3ca8:	cb0300a1 	sub	x1, x5, x3
    3cac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3cb0:	91000421 	add	x1, x1, #0x1
    3cb4:	d1000463 	sub	x3, x3, #0x1
    3cb8:	eb05003f 	cmp	x1, x5
    3cbc:	38001402 	strb	w2, [x0], #1
    3cc0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3cc4:	93407f82 	sxtw	x2, w28
    3cc8:	cb050025 	sub	x5, x1, x5
    3ccc:	aa1303e1 	mov	x1, x19
    3cd0:	8b0300a3 	add	x3, x5, x3
    3cd4:	8b1802d3 	add	x19, x22, x24
    3cd8:	97fffabe 	bl	27d0 <__memcpy_chk@plt>
    3cdc:	17ffff6a 	b	3a84 <fwp_format_g.constprop.0+0x170>
    3ce0:	d1000421 	sub	x1, x1, #0x1
    3ce4:	38616aa0 	ldrb	w0, [x21, x1]
    3ce8:	7100b81f 	cmp	w0, #0x2e
    3cec:	54fff021 	b.ne	3af0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3cf0:	38216abf 	strb	wzr, [x21, x1]
    3cf4:	17ffff7f 	b	3af0 <fwp_format_g.constprop.0+0x1dc>
    3cf8:	910187e7 	add	x7, sp, #0x61
    3cfc:	910183f9 	add	x25, sp, #0x60
    3d00:	d28008fb 	mov	x27, #0x47                  	// #71
    3d04:	390183e0 	strb	w0, [sp, #96]
    3d08:	17ffff3a 	b	39f0 <fwp_format_g.constprop.0+0xdc>
    3d0c:	38336b3f 	strb	wzr, [x25, x19]
    3d10:	17ffffac 	b	3bc0 <fwp_format_g.constprop.0+0x2ac>
    3d14:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3d18:	97fffada 	bl	2880 <__stack_chk_fail@plt>
    3d1c:	d503201f 	nop

0000000000003d20 <fwp_heap_report>:
    3d20:	d105c3ff 	sub	sp, sp, #0x170
    3d24:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    3d28:	91150042 	add	x2, x2, #0x540
    3d2c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3d30:	f947e821 	ldr	x1, [x1, #4048]
    3d34:	a9117bfd 	stp	x29, x30, [sp, #272]
    3d38:	910443fd 	add	x29, sp, #0x110
    3d3c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3d40:	f947f400 	ldr	x0, [x0, #4072]
    3d44:	a9135bf5 	stp	x21, x22, [sp, #304]
    3d48:	a91463f7 	stp	x23, x24, [sp, #320]
    3d4c:	a9156bf9 	stp	x25, x26, [sp, #336]
    3d50:	6d1627e8 	stp	d8, d9, [sp, #352]
    3d54:	fd4a1c48 	ldr	d8, [x2, #5176]
    3d58:	fd4a2049 	ldr	d9, [x2, #5184]
    3d5c:	f9400036 	ldr	x22, [x1]
    3d60:	f9400001 	ldr	x1, [x0]
    3d64:	f90087e1 	str	x1, [sp, #264]
    3d68:	d2800001 	mov	x1, #0x0                   	// #0
    3d6c:	f949e459 	ldr	x25, [x2, #5064]
    3d70:	b0000041 	adrp	x1, c000 <f0+0x2630>
    3d74:	f94a1057 	ldr	x23, [x2, #5152]
    3d78:	b0000040 	adrp	x0, c000 <f0+0x2630>
    3d7c:	f94a1458 	ldr	x24, [x2, #5160]
    3d80:	91380021 	add	x1, x1, #0xe00
    3d84:	91382000 	add	x0, x0, #0xe08
    3d88:	97fffaa2 	bl	2810 <fopen@plt>
    3d8c:	b4000740 	cbz	x0, 3e74 <fwp_heap_report+0x154>
    3d90:	528daad5 	mov	w21, #0x6d56                	// #27990
    3d94:	a91253f3 	stp	x19, x20, [sp, #288]
    3d98:	aa0003f4 	mov	x20, x0
    3d9c:	910023f3 	add	x19, sp, #0x8
    3da0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3da4:	72aae915 	movk	w21, #0x5748, lsl #16
    3da8:	aa1403e2 	mov	x2, x20
    3dac:	aa1303e0 	mov	x0, x19
    3db0:	52802001 	mov	w1, #0x100                 	// #256
    3db4:	97fffb23 	bl	2a40 <fgets@plt>
    3db8:	b4000280 	cbz	x0, 3e08 <fwp_heap_report+0xe8>
    3dbc:	b9400261 	ldr	w1, [x19]
    3dc0:	6b15003f 	cmp	w1, w21
    3dc4:	54ffff21 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3dc8:	39401260 	ldrb	w0, [x19, #4]
    3dcc:	7101341f 	cmp	w0, #0x4d
    3dd0:	54fffec1 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3dd4:	394037e0 	ldrb	w0, [sp, #13]
    3dd8:	7100e81f 	cmp	w0, #0x3a
    3ddc:	54fffe61 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3de0:	52800142 	mov	w2, #0xa                   	// #10
    3de4:	d2800001 	mov	x1, #0x0                   	// #0
    3de8:	91003be0 	add	x0, sp, #0xe
    3dec:	97fffacd 	bl	2920 <strtol@plt>
    3df0:	aa1403e2 	mov	x2, x20
    3df4:	aa0003fa 	mov	x26, x0
    3df8:	52802001 	mov	w1, #0x100                 	// #256
    3dfc:	aa1303e0 	mov	x0, x19
    3e00:	97fffb10 	bl	2a40 <fgets@plt>
    3e04:	b5fffdc0 	cbnz	x0, 3dbc <fwp_heap_report+0x9c>
    3e08:	aa1403e0 	mov	x0, x20
    3e0c:	97fffa7d 	bl	2800 <fclose@plt>
    3e10:	a95253f3 	ldp	x19, x20, [sp, #288]
    3e14:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3e18:	f947f400 	ldr	x0, [x0, #4072]
    3e1c:	f94087e2 	ldr	x2, [sp, #264]
    3e20:	f9400001 	ldr	x1, [x0]
    3e24:	eb010042 	subs	x2, x2, x1
    3e28:	d2800001 	mov	x1, #0x0                   	// #0
    3e2c:	54000281 	b.ne	3e7c <fwp_heap_report+0x15c>  // b.any
    3e30:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3e34:	aa1a03e6 	mov	x6, x26
    3e38:	aa1903e5 	mov	x5, x25
    3e3c:	aa1803e4 	mov	x4, x24
    3e40:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3e44:	aa1703e3 	mov	x3, x23
    3e48:	a95463f7 	ldp	x23, x24, [sp, #320]
    3e4c:	aa1603e0 	mov	x0, x22
    3e50:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3e54:	1e604121 	fmov	d1, d9
    3e58:	1e604100 	fmov	d0, d8
    3e5c:	b0000042 	adrp	x2, c000 <f0+0x2630>
    3e60:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3e64:	9138a042 	add	x2, x2, #0xe28
    3e68:	9105c3ff 	add	sp, sp, #0x170
    3e6c:	52800041 	mov	w1, #0x2                   	// #2
    3e70:	17fffaa0 	b	28f0 <__fprintf_chk@plt>
    3e74:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3e78:	17ffffe7 	b	3e14 <fwp_heap_report+0xf4>
    3e7c:	a91253f3 	stp	x19, x20, [sp, #288]
    3e80:	97fffa80 	bl	2880 <__stack_chk_fail@plt>

0000000000003e84 <fwp_heap_init>:
    3e84:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3e88:	f0000163 	adrp	x3, 32000 <fwp_heap+0xac0>
    3e8c:	91110061 	add	x1, x3, #0x440
    3e90:	910003fd 	mov	x29, sp
    3e94:	a90153f3 	stp	x19, x20, [sp, #16]
    3e98:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    3e9c:	91150262 	add	x2, x19, #0x540
    3ea0:	a9025bf5 	stp	x21, x22, [sp, #32]
    3ea4:	52800024 	mov	w4, #0x1                   	// #1
    3ea8:	52800200 	mov	w0, #0x10                  	// #16
    3eac:	b913a444 	str	w4, [x2, #5028]
    3eb0:	b8004420 	str	w0, [x1], #4
    3eb4:	11004000 	add	w0, w0, #0x10
    3eb8:	7104401f 	cmp	w0, #0x110
    3ebc:	54ffffa1 	b.ne	3eb0 <fwp_heap_init+0x2c>  // b.any
    3ec0:	d0000042 	adrp	x2, d000 <_IO_stdin_used+0x350>
    3ec4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3ec8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xac0>
    3ecc:	91120021 	add	x1, x1, #0x480
    3ed0:	3dc26043 	ldr	q3, [x2, #2432]
    3ed4:	d2800000 	mov	x0, #0x0                   	// #0
    3ed8:	4e040401 	dup	v1.4s, v0.s[0]
    3edc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3ee0:	0f215400 	shl	v0.2s, v0.2s, #1
    3ee4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3ee8:	3ca06821 	str	q1, [x1, x0]
    3eec:	91004000 	add	x0, x0, #0x10
    3ef0:	f101801f 	cmp	x0, #0x60
    3ef4:	54ffff21 	b.ne	3ed8 <fwp_heap_init+0x54>  // b.any
    3ef8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xac0>
    3efc:	91110063 	add	x3, x3, #0x440
    3f00:	91138084 	add	x4, x4, #0x4e0
    3f04:	91150266 	add	x6, x19, #0x540
    3f08:	d2800002 	mov	x2, #0x0                   	// #0
    3f0c:	d2800000 	mov	x0, #0x0                   	// #0
    3f10:	d2880205 	mov	x5, #0x4010                	// #16400
    3f14:	d503201f 	nop
    3f18:	910f0001 	add	x1, x0, #0x3c0
    3f1c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3f20:	eb02003f 	cmp	x1, x2
    3f24:	540000a2 	b.cs	3f38 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    3f28:	91000400 	add	x0, x0, #0x1
    3f2c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3f30:	eb02003f 	cmp	x1, x2
    3f34:	54ffffa3 	b.cc	3f28 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    3f38:	91004042 	add	x2, x2, #0x10
    3f3c:	38001480 	strb	w0, [x4], #1
    3f40:	eb05005f 	cmp	x2, x5
    3f44:	54fffea1 	b.ne	3f18 <fwp_heap_init+0x94>  // b.any
    3f48:	528000b5 	mov	w21, #0x5                   	// #5
    3f4c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3f50:	14000004 	b	3f60 <fwp_heap_init+0xdc>
    3f54:	d342fe94 	lsr	x20, x20, #2
    3f58:	710006b5 	subs	w21, w21, #0x1
    3f5c:	54000720 	b.eq	4040 <fwp_heap_init+0x1bc>  // b.none
    3f60:	91404296 	add	x22, x20, #0x10, lsl #12
    3f64:	d2800005 	mov	x5, #0x0                   	// #0
    3f68:	aa1603e1 	mov	x1, x22
    3f6c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f70:	52880443 	mov	w3, #0x4022                	// #16418
    3f74:	52800002 	mov	w2, #0x0                   	// #0
    3f78:	d2800000 	mov	x0, #0x0                   	// #0
    3f7c:	97fffa65 	bl	2910 <mmap@plt>
    3f80:	aa0003e6 	mov	x6, x0
    3f84:	b100041f 	cmn	x0, #0x1
    3f88:	54fffe60 	b.eq	3f54 <fwp_heap_init+0xd0>  // b.none
    3f8c:	b40005a0 	cbz	x0, 4040 <fwp_heap_init+0x1bc>
    3f90:	d350fe94 	lsr	x20, x20, #16
    3f94:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f98:	8b0000c7 	add	x7, x6, x0
    3f9c:	91150275 	add	x21, x19, #0x540
    3fa0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3fa4:	8b140a81 	add	x1, x20, x20, lsl #2
    3fa8:	d2800005 	mov	x5, #0x0                   	// #0
    3fac:	12800004 	mov	w4, #0xffffffff            	// #-1
    3fb0:	d37df021 	lsl	x1, x1, #3
    3fb4:	52880443 	mov	w3, #0x4022                	// #16418
    3fb8:	52800002 	mov	w2, #0x0                   	// #0
    3fbc:	d2800000 	mov	x0, #0x0                   	// #0
    3fc0:	f909daa7 	str	x7, [x21, #5040]
    3fc4:	f909dea6 	str	x6, [x21, #5048]
    3fc8:	f909e2b6 	str	x22, [x21, #5056]
    3fcc:	f909eab4 	str	x20, [x21, #5072]
    3fd0:	f90a02a1 	str	x1, [x21, #5120]
    3fd4:	97fffa4f 	bl	2910 <mmap@plt>
    3fd8:	aa0003e1 	mov	x1, x0
    3fdc:	b100041f 	cmn	x0, #0x1
    3fe0:	54000300 	b.eq	4040 <fwp_heap_init+0x1bc>  // b.none
    3fe4:	b0000040 	adrp	x0, c000 <f0+0x2630>
    3fe8:	913b6000 	add	x0, x0, #0xed8
    3fec:	f909fea1 	str	x1, [x21, #5112]
    3ff0:	97fffa88 	bl	2a10 <getenv@plt>
    3ff4:	52800002 	mov	w2, #0x0                   	// #0
    3ff8:	aa0003e1 	mov	x1, x0
    3ffc:	b40000e0 	cbz	x0, 4018 <fwp_heap_init+0x194>
    4000:	39400000 	ldrb	w0, [x0]
    4004:	340000a0 	cbz	w0, 4018 <fwp_heap_init+0x194>
    4008:	7100c000 	subs	w0, w0, #0x30
    400c:	54000120 	b.eq	4030 <fwp_heap_init+0x1ac>  // b.none
    4010:	7100001f 	cmp	w0, #0x0
    4014:	1a9f07e2 	cset	w2, ne	// ne = any
    4018:	91150273 	add	x19, x19, #0x540
    401c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4020:	b913aa62 	str	w2, [x19, #5032]
    4024:	a94153f3 	ldp	x19, x20, [sp, #16]
    4028:	a8c37bfd 	ldp	x29, x30, [sp], #48
    402c:	d65f03c0 	ret
    4030:	39400420 	ldrb	w0, [x1, #1]
    4034:	7100001f 	cmp	w0, #0x0
    4038:	1a9f07e2 	cset	w2, ne	// ne = any
    403c:	17fffff7 	b	4018 <fwp_heap_init+0x194>
    4040:	97fffbfc 	bl	3030 <fwp_heap_oom>

0000000000004044 <fwp_wake_io>:
    4044:	900000e9 	adrp	x9, 20000 <__data_start>
    4048:	9100c122 	add	x2, x9, #0x30
    404c:	f9400001 	ldr	x1, [x0]
    4050:	5280000a 	mov	w10, #0x0                   	// #0
    4054:	f9401446 	ldr	x6, [x2, #40]
    4058:	52800008 	mov	w8, #0x0                   	// #0
    405c:	4f000400 	movi	v0.4s, #0x0
    4060:	52800027 	mov	w7, #0x1                   	// #1
    4064:	aa0103e2 	mov	x2, x1
    4068:	b4000321 	cbz	x1, 40cc <fwp_wake_io+0x88>
    406c:	f9408c25 	ldr	x5, [x1, #280]
    4070:	39015c27 	strb	w7, [x1, #87]
    4074:	b4000165 	cbz	x5, 40a0 <fwp_wake_io+0x5c>
    4078:	a9520c24 	ldp	x4, x3, [x1, #288]
    407c:	b4000364 	cbz	x4, 40e8 <fwp_wake_io+0xa4>
    4080:	f9009483 	str	x3, [x4, #296]
    4084:	f9409423 	ldr	x3, [x1, #296]
    4088:	b4000043 	cbz	x3, 4090 <fwp_wake_io+0x4c>
    408c:	f9009064 	str	x4, [x3, #288]
    4090:	91080023 	add	x3, x1, #0x200
    4094:	f900943f 	str	xzr, [x1, #296]
    4098:	3c918060 	stur	q0, [x3, #-232]
    409c:	f9400001 	ldr	x1, [x0]
    40a0:	f9402843 	ldr	x3, [x2, #80]
    40a4:	f2001c7f 	tst	x3, #0xff000000ff
    40a8:	54fffde1 	b.ne	4064 <fwp_wake_io+0x20>  // b.any
    40ac:	39015047 	strb	w7, [x2, #84]
    40b0:	f900805f 	str	xzr, [x2, #256]
    40b4:	b40001e6 	cbz	x6, 40f0 <fwp_wake_io+0xac>
    40b8:	f90080c2 	str	x2, [x6, #256]
    40bc:	aa0203e6 	mov	x6, x2
    40c0:	52800028 	mov	w8, #0x1                   	// #1
    40c4:	aa0103e2 	mov	x2, x1
    40c8:	b5fffd21 	cbnz	x1, 406c <fwp_wake_io+0x28>
    40cc:	3400006a 	cbz	w10, 40d8 <fwp_wake_io+0x94>
    40d0:	9100c120 	add	x0, x9, #0x30
    40d4:	f900180b 	str	x11, [x0, #48]
    40d8:	34000068 	cbz	w8, 40e4 <fwp_wake_io+0xa0>
    40dc:	9100c129 	add	x9, x9, #0x30
    40e0:	f9001526 	str	x6, [x9, #40]
    40e4:	d65f03c0 	ret
    40e8:	f90000a3 	str	x3, [x5]
    40ec:	17ffffe7 	b	4088 <fwp_wake_io+0x44>
    40f0:	aa0203eb 	mov	x11, x2
    40f4:	5280002a 	mov	w10, #0x1                   	// #1
    40f8:	17fffff1 	b	40bc <fwp_wake_io+0x78>
    40fc:	d503201f 	nop

0000000000004100 <fwp_tape_buffers_release>:
    4100:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4104:	910003fd 	mov	x29, sp
    4108:	a90153f3 	stp	x19, x20, [sp, #16]
    410c:	aa0003f3 	mov	x19, x0
    4110:	f9401400 	ldr	x0, [x0, #40]
    4114:	b7f80760 	tbnz	x0, #63, 4200 <fwp_tape_buffers_release+0x100>
    4118:	f9401a61 	ldr	x1, [x19, #48]
    411c:	b7f80301 	tbnz	x1, #63, 417c <fwp_tape_buffers_release+0x7c>
    4120:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4124:	eb02001f 	cmp	x0, x2
    4128:	540002a8 	b.hi	417c <fwp_tape_buffers_release+0x7c>  // b.pmore
    412c:	8b000400 	add	x0, x0, x0, lsl #1
    4130:	d2a00102 	mov	x2, #0x80000               	// #524288
    4134:	d37df000 	lsl	x0, x0, #3
    4138:	cb000042 	sub	x2, x2, x0
    413c:	eb420c3f 	cmp	x1, x2, lsr #3
    4140:	540001e8 	b.hi	417c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4144:	8b010c14 	add	x20, x0, x1, lsl #3
    4148:	90000040 	adrp	x0, c000 <f0+0x2630>
    414c:	913ba000 	add	x0, x0, #0xee8
    4150:	97fffa30 	bl	2a10 <getenv@plt>
    4154:	b4000240 	cbz	x0, 419c <fwp_tape_buffers_release+0x9c>
    4158:	39400001 	ldrb	w1, [x0]
    415c:	7100c03f 	cmp	w1, #0x30
    4160:	540001e1 	b.ne	419c <fwp_tape_buffers_release+0x9c>  // b.any
    4164:	39400400 	ldrb	w0, [x0, #1]
    4168:	350001a0 	cbnz	w0, 419c <fwp_tape_buffers_release+0x9c>
    416c:	aa1303e0 	mov	x0, x19
    4170:	a94153f3 	ldp	x19, x20, [sp, #16]
    4174:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4178:	17fffc62 	b	3300 <fwp_tape_buffers_dispose>
    417c:	90000040 	adrp	x0, c000 <f0+0x2630>
    4180:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4184:	913ba000 	add	x0, x0, #0xee8
    4188:	97fffa22 	bl	2a10 <getenv@plt>
    418c:	b4ffff00 	cbz	x0, 416c <fwp_tape_buffers_release+0x6c>
    4190:	39400001 	ldrb	w1, [x0]
    4194:	7100c03f 	cmp	w1, #0x30
    4198:	54fffe60 	b.eq	4164 <fwp_tape_buffers_release+0x64>  // b.none
    419c:	d1000681 	sub	x1, x20, #0x1
    41a0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    41a4:	eb00003f 	cmp	x1, x0
    41a8:	54fffe28 	b.hi	416c <fwp_tape_buffers_release+0x6c>  // b.pmore
    41ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    41b0:	900000f6 	adrp	x22, 20000 <__data_start>
    41b4:	9100c2d6 	add	x22, x22, #0x30
    41b8:	910122d5 	add	x21, x22, #0x48
    41bc:	aa1503e0 	mov	x0, x21
    41c0:	97fffc50 	bl	3300 <fwp_tape_buffers_dispose>
    41c4:	ad400a61 	ldp	q1, q2, [x19]
    41c8:	f90042d4 	str	x20, [x22, #128]
    41cc:	4f000400 	movi	v0.4s, #0x0
    41d0:	ad000aa1 	stp	q1, q2, [x21]
    41d4:	3dc00a61 	ldr	q1, [x19, #32]
    41d8:	3d800aa1 	str	q1, [x21, #32]
    41dc:	f9401a60 	ldr	x0, [x19, #48]
    41e0:	f9001aa0 	str	x0, [x21, #48]
    41e4:	f9001a7f 	str	xzr, [x19, #48]
    41e8:	ad000260 	stp	q0, q0, [x19]
    41ec:	3d800a60 	str	q0, [x19, #32]
    41f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    41f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    41f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    41fc:	d65f03c0 	ret
    4200:	90000040 	adrp	x0, c000 <f0+0x2630>
    4204:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4208:	913ba000 	add	x0, x0, #0xee8
    420c:	97fffa01 	bl	2a10 <getenv@plt>
    4210:	b5fffa40 	cbnz	x0, 4158 <fwp_tape_buffers_release+0x58>
    4214:	17ffffd6 	b	416c <fwp_tape_buffers_release+0x6c>
    4218:	d503201f 	nop
    421c:	d503201f 	nop

0000000000004220 <fwp_poll_events>:
    4220:	d10103ff 	sub	sp, sp, #0x40
    4224:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4228:	f947f400 	ldr	x0, [x0, #4072]
    422c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4230:	910083fd 	add	x29, sp, #0x20
    4234:	a90353f3 	stp	x19, x20, [sp, #48]
    4238:	900000f4 	adrp	x20, 20000 <__data_start>
    423c:	f9400001 	ldr	x1, [x0]
    4240:	f9000fe1 	str	x1, [sp, #24]
    4244:	d2800001 	mov	x1, #0x0                   	// #0
    4248:	97fffd2e 	bl	3700 <fwp_now_ns>
    424c:	9100c281 	add	x1, x20, #0x30
    4250:	f9404433 	ldr	x19, [x1, #136]
    4254:	b4000e93 	cbz	x19, 4424 <fwp_poll_events+0x204>
    4258:	aa1303e1 	mov	x1, x19
    425c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4260:	14000005 	b	4274 <fwp_poll_events+0x54>
    4264:	f9408821 	ldr	x1, [x1, #272]
    4268:	eb03005f 	cmp	x2, x3
    426c:	9a83d042 	csel	x2, x2, x3, le
    4270:	b40000c1 	cbz	x1, 4288 <fwp_poll_events+0x68>
    4274:	f9403423 	ldr	x3, [x1, #104]
    4278:	b6ffff62 	tbz	x2, #63, 4264 <fwp_poll_events+0x44>
    427c:	f9408821 	ldr	x1, [x1, #272]
    4280:	aa0303e2 	mov	x2, x3
    4284:	b5ffff81 	cbnz	x1, 4274 <fwp_poll_events+0x54>
    4288:	b7f80ce2 	tbnz	x2, #63, 4424 <fwp_poll_events+0x204>
    428c:	cb000042 	sub	x2, x2, x0
    4290:	f100005f 	cmp	x2, #0x0
    4294:	540005cd 	b.le	434c <fwp_poll_events+0x12c>
    4298:	d2869b60 	mov	x0, #0x34db                	// #13531
    429c:	d2884801 	mov	x1, #0x4240                	// #16960
    42a0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    42a4:	f2a001e1 	movk	x1, #0xf, lsl #16
    42a8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    42ac:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    42b0:	f2e86360 	movk	x0, #0x431b, lsl #48
    42b4:	9b407c40 	smulh	x0, x2, x0
    42b8:	9352fc00 	asr	x0, x0, #18
    42bc:	cb82fc00 	sub	x0, x0, x2, asr #63
    42c0:	9b018802 	msub	x2, x0, x1, x2
    42c4:	f100005f 	cmp	x2, #0x0
    42c8:	9a800400 	cinc	x0, x0, ne	// ne = any
    42cc:	eb03001f 	cmp	x0, x3
    42d0:	54000a0c 	b.gt	4410 <fwp_poll_events+0x1f0>
    42d4:	340003c0 	cbz	w0, 434c <fwp_poll_events+0x12c>
    42d8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    42dc:	52807d04 	mov	w4, #0x3e8                 	// #1000
    42e0:	72a20c42 	movk	w2, #0x1062, lsl #16
    42e4:	9ba27c02 	umull	x2, w0, w2
    42e8:	d366fc43 	lsr	x3, x2, #38
    42ec:	aa0303e2 	mov	x2, x3
    42f0:	1b048063 	msub	w3, w3, w4, w0
    42f4:	9b217c63 	smull	x3, w3, w1
    42f8:	d2800001 	mov	x1, #0x0                   	// #0
    42fc:	910023e0 	add	x0, sp, #0x8
    4300:	a9008fe2 	stp	x2, x3, [sp, #8]
    4304:	97fff993 	bl	2950 <nanosleep@plt>
    4308:	9100c280 	add	x0, x20, #0x30
    430c:	f9404413 	ldr	x19, [x0, #136]
    4310:	97fffcfc 	bl	3700 <fwp_now_ns>
    4314:	aa0003e6 	mov	x6, x0
    4318:	b50001f3 	cbnz	x19, 4354 <fwp_poll_events+0x134>
    431c:	d503201f 	nop
    4320:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4324:	f947f400 	ldr	x0, [x0, #4072]
    4328:	f9400fe2 	ldr	x2, [sp, #24]
    432c:	f9400001 	ldr	x1, [x0]
    4330:	eb010042 	subs	x2, x2, x1
    4334:	d2800001 	mov	x1, #0x0                   	// #0
    4338:	540008c1 	b.ne	4450 <fwp_poll_events+0x230>  // b.any
    433c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4340:	a94353f3 	ldp	x19, x20, [sp, #48]
    4344:	910103ff 	add	sp, sp, #0x40
    4348:	d65f03c0 	ret
    434c:	97fffced 	bl	3700 <fwp_now_ns>
    4350:	aa0003e6 	mov	x6, x0
    4354:	4f000400 	movi	v0.4s, #0x0
    4358:	9100c288 	add	x8, x20, #0x30
    435c:	52800027 	mov	w7, #0x1                   	// #1
    4360:	f9403661 	ldr	x1, [x19, #104]
    4364:	aa1303e5 	mov	x5, x19
    4368:	f9408a73 	ldr	x19, [x19, #272]
    436c:	eb06003f 	cmp	x1, x6
    4370:	5400032c 	b.gt	43d4 <fwp_poll_events+0x1b4>
    4374:	394154a0 	ldrb	w0, [x5, #85]
    4378:	36000120 	tbz	w0, #0, 439c <fwp_poll_events+0x17c>
    437c:	f94084a0 	ldr	x0, [x5, #264]
    4380:	b40003c0 	cbz	x0, 43f8 <fwp_poll_events+0x1d8>
    4384:	f9008813 	str	x19, [x0, #272]
    4388:	b4000053 	cbz	x19, 4390 <fwp_poll_events+0x170>
    438c:	f9008660 	str	x0, [x19, #264]
    4390:	910800a0 	add	x0, x5, #0x200
    4394:	390154bf 	strb	wzr, [x5, #85]
    4398:	3c908000 	stur	q0, [x0, #-248]
    439c:	f94030a0 	ldr	x0, [x5, #96]
    43a0:	390158a7 	strb	w7, [x5, #86]
    43a4:	f100001f 	cmp	x0, #0x0
    43a8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    43ac:	5400018d 	b.le	43dc <fwp_poll_events+0x1bc>
    43b0:	f94028a0 	ldr	x0, [x5, #80]
    43b4:	f2001c1f 	tst	x0, #0xff000000ff
    43b8:	540000e1 	b.ne	43d4 <fwp_poll_events+0x1b4>  // b.any
    43bc:	f9401500 	ldr	x0, [x8, #40]
    43c0:	390150a7 	strb	w7, [x5, #84]
    43c4:	f90080bf 	str	xzr, [x5, #256]
    43c8:	b40001e0 	cbz	x0, 4404 <fwp_poll_events+0x1e4>
    43cc:	f9001505 	str	x5, [x8, #40]
    43d0:	f9008005 	str	x5, [x0, #256]
    43d4:	b5fffc73 	cbnz	x19, 4360 <fwp_poll_events+0x140>
    43d8:	17ffffd2 	b	4320 <fwp_poll_events+0x100>
    43dc:	394144a0 	ldrb	w0, [x5, #81]
    43e0:	3707fe80 	tbnz	w0, #0, 43b0 <fwp_poll_events+0x190>
    43e4:	394140a0 	ldrb	w0, [x5, #80]
    43e8:	3707fe40 	tbnz	w0, #0, 43b0 <fwp_poll_events+0x190>
    43ec:	aa0503e0 	mov	x0, x5
    43f0:	97fffc20 	bl	3470 <fwp_cancel_tree.part.0>
    43f4:	17ffffef 	b	43b0 <fwp_poll_events+0x190>
    43f8:	9100c281 	add	x1, x20, #0x30
    43fc:	f9004433 	str	x19, [x1, #136]
    4400:	17ffffe2 	b	4388 <fwp_poll_events+0x168>
    4404:	f9001505 	str	x5, [x8, #40]
    4408:	f9001905 	str	x5, [x8, #48]
    440c:	17fffff2 	b	43d4 <fwp_poll_events+0x1b4>
    4410:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4414:	d2989362 	mov	x2, #0xc49b                	// #50331
    4418:	f2a4d203 	movk	x3, #0x2690, lsl #16
    441c:	f2a00402 	movk	x2, #0x20, lsl #16
    4420:	17ffffb6 	b	42f8 <fwp_poll_events+0xd8>
    4424:	97fffaf3 	bl	2ff0 <fwp_flush>
    4428:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    442c:	f947e863 	ldr	x3, [x3, #4048]
    4430:	d2800562 	mov	x2, #0x2b                  	// #43
    4434:	d2800021 	mov	x1, #0x1                   	// #1
    4438:	90000040 	adrp	x0, c000 <f0+0x2630>
    443c:	913c0000 	add	x0, x0, #0xf00
    4440:	f9400063 	ldr	x3, [x3]
    4444:	97fff94f 	bl	2980 <fwrite@plt>
    4448:	52800ca0 	mov	w0, #0x65                  	// #101
    444c:	97fff8b9 	bl	2730 <exit@plt>
    4450:	97fff90c 	bl	2880 <__stack_chk_fail@plt>

0000000000004454 <fwp_rc_wide_dup>:
    4454:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4458:	910003fd 	mov	x29, sp
    445c:	a90153f3 	stp	x19, x20, [sp, #16]
    4460:	aa0003f3 	mov	x19, x0
    4464:	ca404400 	eor	x0, x0, x0, lsr #17
    4468:	f90013f5 	str	x21, [sp, #32]
    446c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4470:	ca402400 	eor	x0, x0, x0, lsr #9
    4474:	911502a2 	add	x2, x21, #0x540
    4478:	92401c00 	and	x0, x0, #0xff
    447c:	910a2403 	add	x3, x0, #0x289
    4480:	8b000c40 	add	x0, x2, x0, lsl #3
    4484:	8b030c54 	add	x20, x2, x3, lsl #3
    4488:	f94a2401 	ldr	x1, [x0, #5192]
    448c:	b50000a1 	cbnz	x1, 44a0 <fwp_rc_wide_dup+0x4c>
    4490:	1400002d 	b	4544 <fwp_rc_wide_dup+0xf0>
    4494:	91004034 	add	x20, x1, #0x10
    4498:	f9400821 	ldr	x1, [x1, #16]
    449c:	b4000241 	cbz	x1, 44e4 <fwp_rc_wide_dup+0x90>
    44a0:	f9400022 	ldr	x2, [x1]
    44a4:	eb02027f 	cmp	x19, x2
    44a8:	54ffff61 	b.ne	4494 <fwp_rc_wide_dup+0x40>  // b.any
    44ac:	f9400281 	ldr	x1, [x20]
    44b0:	39400260 	ldrb	w0, [x19]
    44b4:	7103f81f 	cmp	w0, #0xfe
    44b8:	54000220 	b.eq	44fc <fwp_rc_wide_dup+0xa8>  // b.none
    44bc:	b40001a1 	cbz	x1, 44f0 <fwp_rc_wide_dup+0x9c>
    44c0:	f9400420 	ldr	x0, [x1, #8]
    44c4:	b100041f 	cmn	x0, #0x1
    44c8:	540004a0 	b.eq	455c <fwp_rc_wide_dup+0x108>  // b.none
    44cc:	91000400 	add	x0, x0, #0x1
    44d0:	f9000420 	str	x0, [x1, #8]
    44d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    44d8:	f94013f5 	ldr	x21, [sp, #32]
    44dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44e0:	d65f03c0 	ret
    44e4:	39400260 	ldrb	w0, [x19]
    44e8:	7103f81f 	cmp	w0, #0xfe
    44ec:	540000a0 	b.eq	4500 <fwp_rc_wide_dup+0xac>  // b.none
    44f0:	90000040 	adrp	x0, c000 <f0+0x2630>
    44f4:	913d6000 	add	x0, x0, #0xf58
    44f8:	97fffc22 	bl	3580 <fwp_trap>
    44fc:	b5000281 	cbnz	x1, 454c <fwp_rc_wide_dup+0xf8>
    4500:	d2800300 	mov	x0, #0x18                  	// #24
    4504:	97fff8c7 	bl	2820 <malloc@plt>
    4508:	b4000280 	cbz	x0, 4558 <fwp_rc_wide_dup+0x104>
    450c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4510:	a9000413 	stp	x19, x1, [x0]
    4514:	911502b5 	add	x21, x21, #0x540
    4518:	f900081f 	str	xzr, [x0, #16]
    451c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4520:	f9000280 	str	x0, [x20]
    4524:	39000261 	strb	w1, [x19]
    4528:	f94e26a0 	ldr	x0, [x21, #7240]
    452c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4530:	91000400 	add	x0, x0, #0x1
    4534:	f90e26a0 	str	x0, [x21, #7240]
    4538:	f94013f5 	ldr	x21, [sp, #32]
    453c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4540:	d65f03c0 	ret
    4544:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4548:	17ffffda 	b	44b0 <fwp_rc_wide_dup+0x5c>
    454c:	90000040 	adrp	x0, c000 <f0+0x2630>
    4550:	913cc000 	add	x0, x0, #0xf30
    4554:	97fffc0b 	bl	3580 <fwp_trap>
    4558:	97fffab6 	bl	3030 <fwp_heap_oom>
    455c:	90000040 	adrp	x0, c000 <f0+0x2630>
    4560:	913e0000 	add	x0, x0, #0xf80
    4564:	97fffc07 	bl	3580 <fwp_trap>
    4568:	d503201f 	nop
    456c:	d503201f 	nop

0000000000004570 <fwp_rc_forget_slot>:
    4570:	aa0003e1 	mov	x1, x0
    4574:	39400000 	ldrb	w0, [x0]
    4578:	7103fc1f 	cmp	w0, #0xff
    457c:	54000040 	b.eq	4584 <fwp_rc_forget_slot+0x14>  // b.none
    4580:	d65f03c0 	ret
    4584:	ca414420 	eor	x0, x1, x1, lsr #17
    4588:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    458c:	ca402400 	eor	x0, x0, x0, lsr #9
    4590:	910003fd 	mov	x29, sp
    4594:	92401c00 	and	x0, x0, #0xff
    4598:	f9000bf3 	str	x19, [sp, #16]
    459c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    45a0:	91150262 	add	x2, x19, #0x540
    45a4:	910a2403 	add	x3, x0, #0x289
    45a8:	8b000c40 	add	x0, x2, x0, lsl #3
    45ac:	8b030c43 	add	x3, x2, x3, lsl #3
    45b0:	f94a2400 	ldr	x0, [x0, #5192]
    45b4:	b50000a0 	cbnz	x0, 45c8 <fwp_rc_forget_slot+0x58>
    45b8:	14000011 	b	45fc <fwp_rc_forget_slot+0x8c>
    45bc:	91004003 	add	x3, x0, #0x10
    45c0:	f9400800 	ldr	x0, [x0, #16]
    45c4:	b40001c0 	cbz	x0, 45fc <fwp_rc_forget_slot+0x8c>
    45c8:	f9400002 	ldr	x2, [x0]
    45cc:	eb02003f 	cmp	x1, x2
    45d0:	54ffff61 	b.ne	45bc <fwp_rc_forget_slot+0x4c>  // b.any
    45d4:	f9400801 	ldr	x1, [x0, #16]
    45d8:	91150273 	add	x19, x19, #0x540
    45dc:	f9000061 	str	x1, [x3]
    45e0:	97fff8d8 	bl	2940 <free@plt>
    45e4:	f94e2660 	ldr	x0, [x19, #7240]
    45e8:	d1000400 	sub	x0, x0, #0x1
    45ec:	f90e2660 	str	x0, [x19, #7240]
    45f0:	f9400bf3 	ldr	x19, [sp, #16]
    45f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    45f8:	d65f03c0 	ret
    45fc:	90000040 	adrp	x0, c000 <f0+0x2630>
    4600:	913d6000 	add	x0, x0, #0xf58
    4604:	97fffbdf 	bl	3580 <fwp_trap>
    4608:	d503201f 	nop
    460c:	d503201f 	nop

0000000000004610 <fwp_rc_prepare_chunk>:
    4610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4614:	910003fd 	mov	x29, sp
    4618:	a9025bf5 	stp	x21, x22, [sp, #32]
    461c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xca0>
    4620:	911502c2 	add	x2, x22, #0x540
    4624:	b9401c03 	ldr	w3, [x0, #28]
    4628:	aa0103f5 	mov	x21, x1
    462c:	a90153f3 	stp	x19, x20, [sp, #16]
    4630:	aa0003f4 	mov	x20, x0
    4634:	f94e2440 	ldr	x0, [x2, #7240]
    4638:	b4000440 	cbz	x0, 46c0 <fwp_rc_prepare_chunk+0xb0>
    463c:	d2800013 	mov	x19, #0x0                   	// #0
    4640:	35000203 	cbnz	w3, 4680 <fwp_rc_prepare_chunk+0x70>
    4644:	b4000361 	cbz	x1, 46b0 <fwp_rc_prepare_chunk+0xa0>
    4648:	f9401280 	ldr	x0, [x20, #32]
    464c:	97fff8bd 	bl	2940 <free@plt>
    4650:	aa1503e0 	mov	x0, x21
    4654:	d2800021 	mov	x1, #0x1                   	// #1
    4658:	97fff882 	bl	2860 <calloc@plt>
    465c:	f9001280 	str	x0, [x20, #32]
    4660:	b5000460 	cbnz	x0, 46ec <fwp_rc_prepare_chunk+0xdc>
    4664:	97fffa73 	bl	3030 <fwp_heap_oom>
    4668:	97ffffc2 	bl	4570 <fwp_rc_forget_slot>
    466c:	91000673 	add	x19, x19, #0x1
    4670:	b9401e83 	ldr	w3, [x20, #28]
    4674:	eb13007f 	cmp	x3, x19
    4678:	54000169 	b.ls	46a4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    467c:	d503201f 	nop
    4680:	f9401283 	ldr	x3, [x20, #32]
    4684:	8b130060 	add	x0, x3, x19
    4688:	38736863 	ldrb	w3, [x3, x19]
    468c:	7103fc7f 	cmp	w3, #0xff
    4690:	54fffec0 	b.eq	4668 <fwp_rc_prepare_chunk+0x58>  // b.none
    4694:	b9401e83 	ldr	w3, [x20, #28]
    4698:	91000673 	add	x19, x19, #0x1
    469c:	eb13007f 	cmp	x3, x19
    46a0:	54ffff08 	b.hi	4680 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    46a4:	eb0302bf 	cmp	x21, x3
    46a8:	54000121 	b.ne	46cc <fwp_rc_prepare_chunk+0xbc>  // b.any
    46ac:	b5000335 	cbnz	x21, 4710 <fwp_rc_prepare_chunk+0x100>
    46b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    46b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46bc:	d65f03c0 	ret
    46c0:	2a0303e3 	mov	w3, w3
    46c4:	eb0302bf 	cmp	x21, x3
    46c8:	54ffff20 	b.eq	46ac <fwp_rc_prepare_chunk+0x9c>  // b.none
    46cc:	911502c2 	add	x2, x22, #0x540
    46d0:	f9401280 	ldr	x0, [x20, #32]
    46d4:	f94e2841 	ldr	x1, [x2, #7248]
    46d8:	cb030021 	sub	x1, x1, x3
    46dc:	f90e2841 	str	x1, [x2, #7248]
    46e0:	97fff898 	bl	2940 <free@plt>
    46e4:	b5fffb75 	cbnz	x21, 4650 <fwp_rc_prepare_chunk+0x40>
    46e8:	f900129f 	str	xzr, [x20, #32]
    46ec:	911502d6 	add	x22, x22, #0x540
    46f0:	f94e2ac0 	ldr	x0, [x22, #7248]
    46f4:	b9001e95 	str	w21, [x20, #28]
    46f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    46fc:	8b150000 	add	x0, x0, x21
    4700:	f90e2ac0 	str	x0, [x22, #7248]
    4704:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4708:	a8c37bfd 	ldp	x29, x30, [sp], #48
    470c:	d65f03c0 	ret
    4710:	f9401280 	ldr	x0, [x20, #32]
    4714:	aa1503e2 	mov	x2, x21
    4718:	a94153f3 	ldp	x19, x20, [sp, #16]
    471c:	52800001 	mov	w1, #0x0                   	// #0
    4720:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4724:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4728:	17fff84a 	b	2850 <memset@plt>
    472c:	d503201f 	nop

0000000000004730 <fwp_heap_refill>:
    4730:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4734:	910003fd 	mov	x29, sp
    4738:	a9025bf5 	stp	x21, x22, [sp, #32]
    473c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4740:	911502b5 	add	x21, x21, #0x540
    4744:	aa0003f6 	mov	x22, x0
    4748:	d2800020 	mov	x0, #0x1                   	// #1
    474c:	a90153f3 	stp	x19, x20, [sp, #16]
    4750:	a90363f7 	stp	x23, x24, [sp, #48]
    4754:	2a0103f7 	mov	w23, w1
    4758:	2a0203f8 	mov	w24, w2
    475c:	97fffa75 	bl	3130 <fwp_heap_chunks>
    4760:	aa0003f3 	mov	x19, x0
    4764:	f949fea2 	ldr	x2, [x21, #5112]
    4768:	8b000800 	add	x0, x0, x0, lsl #2
    476c:	2a1703e1 	mov	w1, w23
    4770:	52800025 	mov	w5, #0x1                   	// #1
    4774:	d37df000 	lsl	x0, x0, #3
    4778:	910f0021 	add	x1, x1, #0x3c0
    477c:	8b000054 	add	x20, x2, x0
    4780:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4784:	52a00024 	mov	w4, #0x10000               	// #65536
    4788:	38206845 	strb	w5, [x2, x0]
    478c:	aa1403e0 	mov	x0, x20
    4790:	39000698 	strb	w24, [x20, #1]
    4794:	39000a97 	strb	w23, [x20, #2]
    4798:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    479c:	b9000681 	str	w1, [x20, #4]
    47a0:	2a0103e5 	mov	w5, w1
    47a4:	8b0300a2 	add	x2, x5, x3
    47a8:	1ac10881 	udiv	w1, w4, w1
    47ac:	9ac50842 	udiv	x2, x2, x5
    47b0:	b9000a81 	str	w1, [x20, #8]
    47b4:	92404021 	and	x1, x1, #0x1ffff
    47b8:	b9001a82 	str	w2, [x20, #24]
    47bc:	97ffff95 	bl	4610 <fwp_rc_prepare_chunk>
    47c0:	f949daa0 	ldr	x0, [x21, #5040]
    47c4:	29408a81 	ldp	w1, w2, [x20, #4]
    47c8:	8b134000 	add	x0, x0, x19, lsl #16
    47cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    47d0:	8b214003 	add	x3, x0, w1, uxtw
    47d4:	9ba20021 	umaddl	x1, w1, w2, x0
    47d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    47dc:	a90086c3 	stp	x3, x1, [x22, #8]
    47e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47e4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    47e8:	d65f03c0 	ret
    47ec:	d503201f 	nop

00000000000047f0 <fwp_mem_free>:
    47f0:	b40003c0 	cbz	x0, 4868 <fwp_mem_free+0x78>
    47f4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    47f8:	910003fd 	mov	x29, sp
    47fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4800:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4804:	911502a1 	add	x1, x21, #0x540
    4808:	a90153f3 	stp	x19, x20, [sp, #16]
    480c:	aa0003f3 	mov	x19, x0
    4810:	f949d823 	ldr	x3, [x1, #5040]
    4814:	f949ec22 	ldr	x2, [x1, #5080]
    4818:	cb030000 	sub	x0, x0, x3
    481c:	eb02401f 	cmp	x0, x2, lsl #16
    4820:	540001c2 	b.cs	4858 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4824:	d350fc16 	lsr	x22, x0, #16
    4828:	a90363f7 	stp	x23, x24, [sp, #48]
    482c:	f949fc22 	ldr	x2, [x1, #5112]
    4830:	8b160ad4 	add	x20, x22, x22, lsl #2
    4834:	d37df294 	lsl	x20, x20, #3
    4838:	ab140057 	adds	x23, x2, x20
    483c:	540000c0 	b.eq	4854 <fwp_mem_free+0x64>  // b.none
    4840:	38746842 	ldrb	w2, [x2, x20]
    4844:	7100045f 	cmp	w2, #0x1
    4848:	54000120 	b.eq	486c <fwp_mem_free+0x7c>  // b.none
    484c:	7100085f 	cmp	w2, #0x2
    4850:	540005e0 	b.eq	490c <fwp_mem_free+0x11c>  // b.none
    4854:	a94363f7 	ldp	x23, x24, [sp, #48]
    4858:	a94153f3 	ldp	x19, x20, [sp, #16]
    485c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4860:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4864:	d65f03c0 	ret
    4868:	d65f03c0 	ret
    486c:	f94012f8 	ldr	x24, [x23, #32]
    4870:	b94006e1 	ldr	w1, [x23, #4]
    4874:	f90023f9 	str	x25, [sp, #64]
    4878:	2a0103e2 	mov	w2, w1
    487c:	394006f9 	ldrb	w25, [x23, #1]
    4880:	39400af4 	ldrb	w20, [x23, #2]
    4884:	b4000158 	cbz	x24, 48ac <fwp_mem_free+0xbc>
    4888:	92403e76 	and	x22, x19, #0xffff
    488c:	9ac20ad6 	udiv	x22, x22, x2
    4890:	38766b01 	ldrb	w1, [x24, x22]
    4894:	8b160300 	add	x0, x24, x22
    4898:	7103fc3f 	cmp	w1, #0xff
    489c:	54000980 	b.eq	49cc <fwp_mem_free+0x1dc>  // b.none
    48a0:	38366b1f 	strb	wzr, [x24, x22]
    48a4:	b94006e1 	ldr	w1, [x23, #4]
    48a8:	2a0103e2 	mov	w2, w1
    48ac:	d37c1f20 	ubfiz	x0, x25, #4, #8
    48b0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    48b4:	cb390000 	sub	x0, x0, w25, uxtb
    48b8:	8b340074 	add	x20, x3, w20, uxtb
    48bc:	911502b5 	add	x21, x21, #0x540
    48c0:	1e630021 	ucvtf	d1, w1
    48c4:	d37ae400 	lsl	x0, x0, #6
    48c8:	8b140c14 	add	x20, x0, x20, lsl #3
    48cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    48d0:	f8746aa0 	ldr	x0, [x21, x20]
    48d4:	f94023f9 	ldr	x25, [sp, #64]
    48d8:	aa2003e0 	mvn	x0, x0
    48dc:	fd4a22a0 	ldr	d0, [x21, #5184]
    48e0:	f9000260 	str	x0, [x19]
    48e4:	f8346ab3 	str	x19, [x21, x20]
    48e8:	f94a12a0 	ldr	x0, [x21, #5152]
    48ec:	1e612800 	fadd	d0, d0, d1
    48f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    48f4:	cb020000 	sub	x0, x0, x2
    48f8:	f90a12a0 	str	x0, [x21, #5152]
    48fc:	fd0a22a0 	str	d0, [x21, #5184]
    4900:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4904:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4908:	d65f03c0 	ret
    490c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4910:	8b000063 	add	x3, x3, x0
    4914:	eb03027f 	cmp	x19, x3
    4918:	54fff9e1 	b.ne	4854 <fwp_mem_free+0x64>  // b.any
    491c:	fd400ae1 	ldr	d1, [x23, #16]
    4920:	fd4a2020 	ldr	d0, [x1, #5184]
    4924:	f9400ae0 	ldr	x0, [x23, #16]
    4928:	7e61d821 	ucvtf	d1, d1
    492c:	f94a1022 	ldr	x2, [x1, #5152]
    4930:	f94012f3 	ldr	x19, [x23, #32]
    4934:	1e612800 	fadd	d0, d0, d1
    4938:	cb000042 	sub	x2, x2, x0
    493c:	f90a1022 	str	x2, [x1, #5152]
    4940:	fd0a2020 	str	d0, [x1, #5184]
    4944:	b40000b3 	cbz	x19, 4958 <fwp_mem_free+0x168>
    4948:	39400260 	ldrb	w0, [x19]
    494c:	7103fc1f 	cmp	w0, #0xff
    4950:	54000380 	b.eq	49c0 <fwp_mem_free+0x1d0>  // b.none
    4954:	3900027f 	strb	wzr, [x19]
    4958:	b9400ee2 	ldr	w2, [x23, #12]
    495c:	b4000142 	cbz	x2, 4984 <fwp_mem_free+0x194>
    4960:	911502a1 	add	x1, x21, #0x540
    4964:	8b160040 	add	x0, x2, x22
    4968:	8b000800 	add	x0, x0, x0, lsl #2
    496c:	f949fc21 	ldr	x1, [x1, #5112]
    4970:	8b140034 	add	x20, x1, x20
    4974:	8b000c20 	add	x0, x1, x0, lsl #3
    4978:	3802869f 	strb	wzr, [x20], #40
    497c:	eb00029f 	cmp	x20, x0
    4980:	54ffffc1 	b.ne	4978 <fwp_mem_free+0x188>  // b.any
    4984:	911502a0 	add	x0, x21, #0x540
    4988:	f94a1801 	ldr	x1, [x0, #5168]
    498c:	f949f803 	ldr	x3, [x0, #5104]
    4990:	8b020021 	add	x1, x1, x2
    4994:	f90a1801 	str	x1, [x0, #5168]
    4998:	eb16007f 	cmp	x3, x22
    499c:	54000049 	b.ls	49a4 <fwp_mem_free+0x1b4>  // b.plast
    49a0:	f909f816 	str	x22, [x0, #5104]
    49a4:	911502b5 	add	x21, x21, #0x540
    49a8:	f949f6a0 	ldr	x0, [x21, #5096]
    49ac:	eb16001f 	cmp	x0, x22
    49b0:	54fff529 	b.ls	4854 <fwp_mem_free+0x64>  // b.plast
    49b4:	a94363f7 	ldp	x23, x24, [sp, #48]
    49b8:	f909f6b6 	str	x22, [x21, #5096]
    49bc:	17ffffa7 	b	4858 <fwp_mem_free+0x68>
    49c0:	aa1303e0 	mov	x0, x19
    49c4:	97fffeeb 	bl	4570 <fwp_rc_forget_slot>
    49c8:	17ffffe3 	b	4954 <fwp_mem_free+0x164>
    49cc:	97fffee9 	bl	4570 <fwp_rc_forget_slot>
    49d0:	17ffffb4 	b	48a0 <fwp_mem_free+0xb0>

00000000000049d4 <fwp_heap_alloc_big>:
    49d4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    49d8:	910003fd 	mov	x29, sp
    49dc:	a90153f3 	stp	x19, x20, [sp, #16]
    49e0:	a9025bf5 	stp	x21, x22, [sp, #32]
    49e4:	a90363f7 	stp	x23, x24, [sp, #48]
    49e8:	aa0003f7 	mov	x23, x0
    49ec:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    49f0:	a9046bf9 	stp	x25, x26, [sp, #64]
    49f4:	eb0002ff 	cmp	x23, x0
    49f8:	54000888 	b.hi	4b08 <fwp_heap_alloc_big+0x134>  // b.pmore
    49fc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4a00:	8b0002f4 	add	x20, x23, x0
    4a04:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xca0>
    4a08:	91150359 	add	x25, x26, #0x540
    4a0c:	d350fe94 	lsr	x20, x20, #16
    4a10:	2a0103f5 	mov	w21, w1
    4a14:	aa1403e0 	mov	x0, x20
    4a18:	97fff9c6 	bl	3130 <fwp_heap_chunks>
    4a1c:	f949ff22 	ldr	x2, [x25, #5112]
    4a20:	8b000813 	add	x19, x0, x0, lsl #2
    4a24:	aa0003f8 	mov	x24, x0
    4a28:	52800043 	mov	w3, #0x2                   	// #2
    4a2c:	d37df273 	lsl	x19, x19, #3
    4a30:	d2800021 	mov	x1, #0x1                   	// #1
    4a34:	8b130040 	add	x0, x2, x19
    4a38:	38336843 	strb	w3, [x2, x19]
    4a3c:	39000415 	strb	w21, [x0, #1]
    4a40:	b9000c14 	str	w20, [x0, #12]
    4a44:	f9000817 	str	x23, [x0, #16]
    4a48:	97fffef2 	bl	4610 <fwp_rc_prepare_chunk>
    4a4c:	f100069f 	cmp	x20, #0x1
    4a50:	54000269 	b.ls	4a9c <fwp_heap_alloc_big+0xc8>  // b.plast
    4a54:	8b180294 	add	x20, x20, x24
    4a58:	9100a273 	add	x19, x19, #0x28
    4a5c:	a90573fb 	stp	x27, x28, [sp, #80]
    4a60:	5280007b 	mov	w27, #0x3                   	// #3
    4a64:	8b140a94 	add	x20, x20, x20, lsl #2
    4a68:	2a1803fc 	mov	w28, w24
    4a6c:	9adb2296 	lsl	x22, x20, x27
    4a70:	f949ff35 	ldr	x21, [x25, #5112]
    4a74:	d2800001 	mov	x1, #0x0                   	// #0
    4a78:	8b1302b4 	add	x20, x21, x19
    4a7c:	aa1403e0 	mov	x0, x20
    4a80:	97fffee4 	bl	4610 <fwp_rc_prepare_chunk>
    4a84:	38336abb 	strb	w27, [x21, x19]
    4a88:	9100a273 	add	x19, x19, #0x28
    4a8c:	b9000e9c 	str	w28, [x20, #12]
    4a90:	eb1302df 	cmp	x22, x19
    4a94:	54fffee1 	b.ne	4a70 <fwp_heap_alloc_big+0x9c>  // b.any
    4a98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a9c:	91150353 	add	x19, x26, #0x540
    4aa0:	aa1703e2 	mov	x2, x23
    4aa4:	52800001 	mov	w1, #0x0                   	// #0
    4aa8:	f949da60 	ldr	x0, [x19, #5040]
    4aac:	8b184018 	add	x24, x0, x24, lsl #16
    4ab0:	aa1803e0 	mov	x0, x24
    4ab4:	97fff767 	bl	2850 <memset@plt>
    4ab8:	f94a1260 	ldr	x0, [x19, #5152]
    4abc:	ab170000 	adds	x0, x0, x23
    4ac0:	54000242 	b.cs	4b08 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4ac4:	f94a1661 	ldr	x1, [x19, #5160]
    4ac8:	f90a1260 	str	x0, [x19, #5152]
    4acc:	eb01001f 	cmp	x0, x1
    4ad0:	54000049 	b.ls	4ad8 <fwp_heap_alloc_big+0x104>  // b.plast
    4ad4:	f90a1660 	str	x0, [x19, #5160]
    4ad8:	9115035a 	add	x26, x26, #0x540
    4adc:	9e6202e0 	scvtf	d0, x23
    4ae0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ae4:	aa1803e0 	mov	x0, x24
    4ae8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4aec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4af0:	1e602820 	fadd	d0, d1, d0
    4af4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4af8:	fd0a1f40 	str	d0, [x26, #5176]
    4afc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4b00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4b04:	d65f03c0 	ret
    4b08:	a90573fb 	stp	x27, x28, [sp, #80]
    4b0c:	97fff949 	bl	3030 <fwp_heap_oom>

0000000000004b10 <fwp_heap_alloc_slow>:
    4b10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4b14:	910003fd 	mov	x29, sp
    4b18:	a90153f3 	stp	x19, x20, [sp, #16]
    4b1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    4b20:	91150262 	add	x2, x19, #0x540
    4b24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b28:	aa0003f5 	mov	x21, x0
    4b2c:	2a0103f4 	mov	w20, w1
    4b30:	b953a440 	ldr	w0, [x2, #5028]
    4b34:	34000600 	cbz	w0, 4bf4 <fwp_heap_alloc_slow+0xe4>
    4b38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b3c:	54000628 	b.hi	4c00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4b40:	91003ea0 	add	x0, x21, #0xf
    4b44:	91150262 	add	x2, x19, #0x540
    4b48:	f9001bf7 	str	x23, [sp, #48]
    4b4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4b50:	8b401040 	add	x0, x2, x0, lsr #4
    4b54:	cb34c084 	sub	x4, x4, w20, sxtw
    4b58:	d37ae484 	lsl	x4, x4, #6
    4b5c:	397e8003 	ldrb	w3, [x0, #4000]
    4b60:	910f0060 	add	x0, x3, #0x3c0
    4b64:	aa0303e1 	mov	x1, x3
    4b68:	8b030463 	add	x3, x3, x3, lsl #1
    4b6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4b70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4b74:	2a1703f6 	mov	w22, w23
    4b78:	f8636844 	ldr	x4, [x2, x3]
    4b7c:	b40004e4 	cbz	x4, 4c18 <fwp_heap_alloc_slow+0x108>
    4b80:	f9400080 	ldr	x0, [x4]
    4b84:	aa2003e0 	mvn	x0, x0
    4b88:	f8236840 	str	x0, [x2, x3]
    4b8c:	7100069f 	cmp	w20, #0x1
    4b90:	aa0403e0 	mov	x0, x4
    4b94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b98:	52800001 	mov	w1, #0x0                   	// #0
    4b9c:	97fff72d 	bl	2850 <memset@plt>
    4ba0:	aa0003e4 	mov	x4, x0
    4ba4:	91150260 	add	x0, x19, #0x540
    4ba8:	f94a1001 	ldr	x1, [x0, #5152]
    4bac:	ab160021 	adds	x1, x1, x22
    4bb0:	540005c2 	b.cs	4c68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4bb4:	f94a1402 	ldr	x2, [x0, #5160]
    4bb8:	f90a1001 	str	x1, [x0, #5152]
    4bbc:	eb02003f 	cmp	x1, x2
    4bc0:	54000049 	b.ls	4bc8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4bc4:	f90a1401 	str	x1, [x0, #5160]
    4bc8:	91150273 	add	x19, x19, #0x540
    4bcc:	1e6302e1 	ucvtf	d1, w23
    4bd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bd4:	aa0403e0 	mov	x0, x4
    4bd8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4bdc:	f9401bf7 	ldr	x23, [sp, #48]
    4be0:	1e612800 	fadd	d0, d0, d1
    4be4:	fd0a1e60 	str	d0, [x19, #5176]
    4be8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4bf0:	d65f03c0 	ret
    4bf4:	97fffca4 	bl	3e84 <fwp_heap_init>
    4bf8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4bfc:	54fffa29 	b.ls	4b40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4c00:	2a1403e1 	mov	w1, w20
    4c04:	aa1503e0 	mov	x0, x21
    4c08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c14:	17ffff70 	b	49d4 <fwp_heap_alloc_big>
    4c18:	8b030042 	add	x2, x2, x3
    4c1c:	f9400444 	ldr	x4, [x2, #8]
    4c20:	b4000104 	cbz	x4, 4c40 <fwp_heap_alloc_slow+0x130>
    4c24:	f9400840 	ldr	x0, [x2, #16]
    4c28:	cb040000 	sub	x0, x0, x4
    4c2c:	eb16001f 	cmp	x0, x22
    4c30:	54000083 	b.cc	4c40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4c34:	8b160080 	add	x0, x4, x22
    4c38:	f9000440 	str	x0, [x2, #8]
    4c3c:	17ffffd4 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c40:	52800302 	mov	w2, #0x18                  	// #24
    4c44:	52807804 	mov	w4, #0x3c0                 	// #960
    4c48:	91150260 	add	x0, x19, #0x540
    4c4c:	9ba27c23 	umull	x3, w1, w2
    4c50:	2a1403e2 	mov	w2, w20
    4c54:	9b240e84 	smaddl	x4, w20, w4, x3
    4c58:	8b040000 	add	x0, x0, x4
    4c5c:	97fffeb5 	bl	4730 <fwp_heap_refill>
    4c60:	aa0003e4 	mov	x4, x0
    4c64:	17ffffca 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c68:	97fff8f2 	bl	3030 <fwp_heap_oom>
    4c6c:	d503201f 	nop

0000000000004c70 <fwp_heap_alloc>:
    4c70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4c74:	f140101f 	cmp	x0, #0x4, lsl #12
    4c78:	910003fd 	mov	x29, sp
    4c7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    4c84:	91150293 	add	x19, x20, #0x540
    4c88:	b953a662 	ldr	w2, [x19, #5028]
    4c8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c90:	54000640 	b.eq	4d58 <fwp_heap_alloc+0xe8>  // b.none
    4c94:	91003c03 	add	x3, x0, #0xf
    4c98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4ca0:	8b431263 	add	x3, x19, x3, lsr #4
    4ca4:	cb21c042 	sub	x2, x2, w1, sxtw
    4ca8:	d37ae442 	lsl	x2, x2, #6
    4cac:	397e8063 	ldrb	w3, [x3, #4000]
    4cb0:	910f0064 	add	x4, x3, #0x3c0
    4cb4:	8b030463 	add	x3, x3, x3, lsl #1
    4cb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4cbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4cc0:	2a1603f5 	mov	w21, w22
    4cc4:	f8636a64 	ldr	x4, [x19, x3]
    4cc8:	b4000384 	cbz	x4, 4d38 <fwp_heap_alloc+0xc8>
    4ccc:	f9400085 	ldr	x5, [x4]
    4cd0:	7100043f 	cmp	w1, #0x1
    4cd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cd8:	aa0403e0 	mov	x0, x4
    4cdc:	aa2503e5 	mvn	x5, x5
    4ce0:	52800001 	mov	w1, #0x0                   	// #0
    4ce4:	f8236a65 	str	x5, [x19, x3]
    4ce8:	97fff6da 	bl	2850 <memset@plt>
    4cec:	aa0003e4 	mov	x4, x0
    4cf0:	f94a1260 	ldr	x0, [x19, #5152]
    4cf4:	ab150000 	adds	x0, x0, x21
    4cf8:	54000442 	b.cs	4d80 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4cfc:	f94a1661 	ldr	x1, [x19, #5160]
    4d00:	f90a1260 	str	x0, [x19, #5152]
    4d04:	eb01001f 	cmp	x0, x1
    4d08:	54000049 	b.ls	4d10 <fwp_heap_alloc+0xa0>  // b.plast
    4d0c:	f90a1660 	str	x0, [x19, #5160]
    4d10:	91150294 	add	x20, x20, #0x540
    4d14:	1e6302c1 	ucvtf	d1, w22
    4d18:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d1c:	aa0403e0 	mov	x0, x4
    4d20:	fd4a1e80 	ldr	d0, [x20, #5176]
    4d24:	1e612800 	fadd	d0, d0, d1
    4d28:	fd0a1e80 	str	d0, [x20, #5176]
    4d2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d34:	d65f03c0 	ret
    4d38:	8b030263 	add	x3, x19, x3
    4d3c:	f9400464 	ldr	x4, [x3, #8]
    4d40:	b40000a4 	cbz	x4, 4d54 <fwp_heap_alloc+0xe4>
    4d44:	f9400862 	ldr	x2, [x3, #16]
    4d48:	cb040042 	sub	x2, x2, x4
    4d4c:	eb15005f 	cmp	x2, x21
    4d50:	540000a2 	b.cs	4d64 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4d54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d5c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d60:	17ffff6c 	b	4b10 <fwp_heap_alloc_slow>
    4d64:	7100043f 	cmp	w1, #0x1
    4d68:	8b150085 	add	x5, x4, x21
    4d6c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4d70:	52800001 	mov	w1, #0x0                   	// #0
    4d74:	aa0403e0 	mov	x0, x4
    4d78:	f9000465 	str	x5, [x3, #8]
    4d7c:	17ffffdb 	b	4ce8 <fwp_heap_alloc+0x78>
    4d80:	97fff8ac 	bl	3030 <fwp_heap_oom>

0000000000004d84 <fwp_data.part.0.constprop.0>:
    4d84:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d88:	910003fd 	mov	x29, sp
    4d8c:	a90153f3 	stp	x19, x20, [sp, #16]
    4d90:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    4d94:	91150283 	add	x3, x20, #0x540
    4d98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d9c:	aa0103f5 	mov	x21, x1
    4da0:	b953a461 	ldr	w1, [x3, #5028]
    4da4:	a90363f7 	stp	x23, x24, [sp, #48]
    4da8:	2a0003f8 	mov	w24, w0
    4dac:	34000701 	cbz	w1, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4db0:	397e8862 	ldrb	w2, [x3, #4002]
    4db4:	910f0040 	add	x0, x2, #0x3c0
    4db8:	8b020442 	add	x2, x2, x2, lsl #1
    4dbc:	d37df042 	lsl	x2, x2, #3
    4dc0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    4dc4:	2a1703f6 	mov	w22, w23
    4dc8:	f8626873 	ldr	x19, [x3, x2]
    4dcc:	b40004d3 	cbz	x19, 4e64 <fwp_data.part.0.constprop.0+0xe0>
    4dd0:	f9400260 	ldr	x0, [x19]
    4dd4:	aa2003e0 	mvn	x0, x0
    4dd8:	f8226860 	str	x0, [x3, x2]
    4ddc:	f10062df 	cmp	x22, #0x18
    4de0:	540000e9 	b.ls	4dfc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    4de4:	d10066c2 	sub	x2, x22, #0x19
    4de8:	91006260 	add	x0, x19, #0x18
    4dec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    4df0:	52800001 	mov	w1, #0x0                   	// #0
    4df4:	91002042 	add	x2, x2, #0x8
    4df8:	97fff696 	bl	2850 <memset@plt>
    4dfc:	91150282 	add	x2, x20, #0x540
    4e00:	f94a1041 	ldr	x1, [x2, #5152]
    4e04:	ab160021 	adds	x1, x1, x22
    4e08:	540004c2 	b.cs	4ea0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    4e0c:	f94a1440 	ldr	x0, [x2, #5160]
    4e10:	f90a1041 	str	x1, [x2, #5152]
    4e14:	eb00003f 	cmp	x1, x0
    4e18:	54000049 	b.ls	4e20 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    4e1c:	f90a1441 	str	x1, [x2, #5160]
    4e20:	91150294 	add	x20, x20, #0x540
    4e24:	1e6302e1 	ucvtf	d1, w23
    4e28:	fd4a1e80 	ldr	d0, [x20, #5176]
    4e2c:	1e612800 	fadd	d0, d0, d1
    4e30:	fd0a1e80 	str	d0, [x20, #5176]
    4e34:	52800041 	mov	w1, #0x2                   	// #2
    4e38:	29000678 	stp	w24, w1, [x19]
    4e3c:	aa1303e0 	mov	x0, x19
    4e40:	f94002a1 	ldr	x1, [x21]
    4e44:	f9000661 	str	x1, [x19, #8]
    4e48:	f94006a1 	ldr	x1, [x21, #8]
    4e4c:	f9000a61 	str	x1, [x19, #16]
    4e50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e58:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e5c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e60:	d65f03c0 	ret
    4e64:	8b020063 	add	x3, x3, x2
    4e68:	f9400473 	ldr	x19, [x3, #8]
    4e6c:	b4000113 	cbz	x19, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4e70:	f9400860 	ldr	x0, [x3, #16]
    4e74:	cb130000 	sub	x0, x0, x19
    4e78:	eb0002df 	cmp	x22, x0
    4e7c:	54000088 	b.hi	4e8c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    4e80:	8b160260 	add	x0, x19, x22
    4e84:	f9000460 	str	x0, [x3, #8]
    4e88:	17ffffd5 	b	4ddc <fwp_data.part.0.constprop.0+0x58>
    4e8c:	52800001 	mov	w1, #0x0                   	// #0
    4e90:	d2800300 	mov	x0, #0x18                  	// #24
    4e94:	97ffff77 	bl	4c70 <fwp_heap_alloc>
    4e98:	aa0003f3 	mov	x19, x0
    4e9c:	17ffffe6 	b	4e34 <fwp_data.part.0.constprop.0+0xb0>
    4ea0:	97fff864 	bl	3030 <fwp_heap_oom>

0000000000004ea4 <fwp_p_ad_push>:
    4ea4:	f100001f 	cmp	x0, #0x0
    4ea8:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    4eac:	5400118b 	b.lt	50dc <fwp_p_ad_push+0x238>  // b.tstop
    4eb0:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    4eb4:	910003fd 	mov	x29, sp
    4eb8:	a90153f3 	stp	x19, x20, [sp, #16]
    4ebc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ec0:	aa0403f6 	mov	x22, x4
    4ec4:	aa0003f5 	mov	x21, x0
    4ec8:	a90363f7 	stp	x23, x24, [sp, #48]
    4ecc:	aa0203f8 	mov	x24, x2
    4ed0:	6d0627e8 	stp	d8, d9, [sp, #96]
    4ed4:	9e670029 	fmov	d9, x1
    4ed8:	9e670068 	fmov	d8, x3
    4edc:	aa020001 	orr	x1, x0, x2
    4ee0:	b6f80dc1 	tbz	x1, #63, 5098 <fwp_p_ad_push+0x1f4>
    4ee4:	9360fc14 	asr	x20, x0, #32
    4ee8:	b6f800c0 	tbz	x0, #63, 4f00 <fwp_p_ad_push+0x5c>
    4eec:	1e604109 	fmov	d9, d8
    4ef0:	2f00e408 	movi	d8, #0x0
    4ef4:	9360fc54 	asr	x20, x2, #32
    4ef8:	aa0203f5 	mov	x21, x2
    4efc:	92800018 	mov	x24, #0xffffffffffffffff    	// #-1
    4f00:	b4001136 	cbz	x22, 5124 <fwp_p_ad_push+0x280>
    4f04:	f94002c0 	ldr	x0, [x22]
    4f08:	eb14001f 	cmp	x0, x20
    4f0c:	54000e40 	b.eq	50d4 <fwp_p_ad_push+0x230>  // b.none
    4f10:	aa1403e0 	mov	x0, x20
    4f14:	97fffa67 	bl	38b0 <fwp_tape_of>
    4f18:	aa0003f3 	mov	x19, x0
    4f1c:	f9403000 	ldr	x0, [x0, #96]
    4f20:	b50010c0 	cbnz	x0, 5138 <fwp_p_ad_push+0x294>
    4f24:	a9004ed4 	stp	x20, x19, [x22]
    4f28:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    4f2c:	f9400a77 	ldr	x23, [x19, #16]
    4f30:	a9046bf9 	stp	x25, x26, [sp, #64]
    4f34:	eb0002ff 	cmp	x23, x0
    4f38:	540013ec 	b.gt	51b4 <fwp_p_ad_push+0x310>
    4f3c:	eb3542ff 	cmp	x23, w21, uxtw
    4f40:	5400132d 	b.le	51a4 <fwp_p_ad_push+0x300>
    4f44:	b7f80078 	tbnz	x24, #63, 4f50 <fwp_p_ad_push+0xac>
    4f48:	eb3842ff 	cmp	x23, w24, uxtw
    4f4c:	540012cd 	b.le	51a4 <fwp_p_ad_push+0x300>
    4f50:	f9400676 	ldr	x22, [x19, #8]
    4f54:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    4f58:	cb1602f6 	sub	x22, x23, x22
    4f5c:	910006c1 	add	x1, x22, #0x1
    4f60:	aa1603f9 	mov	x25, x22
    4f64:	eb00003f 	cmp	x1, x0
    4f68:	54001268 	b.hi	51b4 <fwp_p_ad_push+0x310>  // b.pmore
    4f6c:	a9418274 	ldp	x20, x0, [x19, #24]
    4f70:	eb14003f 	cmp	x1, x20
    4f74:	54000a6d 	b.le	50c0 <fwp_p_ad_push+0x21c>
    4f78:	f100029f 	cmp	x20, #0x0
    4f7c:	d2800803 	mov	x3, #0x40                  	// #64
    4f80:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    4f84:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    4f88:	a90573fb 	stp	x27, x28, [sp, #80]
    4f8c:	eb14003f 	cmp	x1, x20
    4f90:	5400008d 	b.le	4fa0 <fwp_p_ad_push+0xfc>
    4f94:	eb02029f 	cmp	x20, x2
    4f98:	5400090d 	b.le	50b8 <fwp_p_ad_push+0x214>
    4f9c:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    4fa0:	d37df29a 	lsl	x26, x20, #3
    4fa4:	f940327b 	ldr	x27, [x19, #96]
    4fa8:	aa1a03e1 	mov	x1, x26
    4fac:	97fff631 	bl	2870 <realloc@plt>
    4fb0:	b40010a0 	cbz	x0, 51c4 <fwp_p_ad_push+0x320>
    4fb4:	f9400e61 	ldr	x1, [x19, #24]
    4fb8:	8b010801 	add	x1, x0, x1, lsl #2
    4fbc:	a9020660 	stp	x0, x1, [x19, #32]
    4fc0:	b400093b 	cbz	x27, 50e4 <fwp_p_ad_push+0x240>
    4fc4:	f9403363 	ldr	x3, [x27, #96]
    4fc8:	f9003be3 	str	x3, [sp, #112]
    4fcc:	eb03029f 	cmp	x20, x3
    4fd0:	5400034d 	b.le	5038 <fwp_p_ad_push+0x194>
    4fd4:	f940237c 	ldr	x28, [x27, #64]
    4fd8:	d37cee82 	lsl	x2, x20, #4
    4fdc:	aa0203e0 	mov	x0, x2
    4fe0:	52800041 	mov	w1, #0x2                   	// #2
    4fe4:	f9003fe2 	str	x2, [sp, #120]
    4fe8:	97ffff22 	bl	4c70 <fwp_heap_alloc>
    4fec:	aa0003fa 	mov	x26, x0
    4ff0:	b400013c 	cbz	x28, 5014 <fwp_p_ad_push+0x170>
    4ff4:	a9470be3 	ldp	x3, x2, [sp, #112]
    4ff8:	aa1c03e1 	mov	x1, x28
    4ffc:	d37cec63 	lsl	x3, x3, #4
    5000:	eb02007f 	cmp	x3, x2
    5004:	9a829062 	csel	x2, x3, x2, ls	// ls = plast
    5008:	97fff5b2 	bl	26d0 <memcpy@plt>
    500c:	aa1c03e0 	mov	x0, x28
    5010:	97fffdf8 	bl	47f0 <fwp_mem_free>
    5014:	f9403360 	ldr	x0, [x27, #96]
    5018:	52800001 	mov	w1, #0x0                   	// #0
    501c:	cb000282 	sub	x2, x20, x0
    5020:	8b001340 	add	x0, x26, x0, lsl #4
    5024:	d37cec42 	lsl	x2, x2, #4
    5028:	97fff60a 	bl	2850 <memset@plt>
    502c:	f9401260 	ldr	x0, [x19, #32]
    5030:	f900237a 	str	x26, [x27, #64]
    5034:	f9003374 	str	x20, [x27, #96]
    5038:	b50008b6 	cbnz	x22, 514c <fwp_p_ad_push+0x2a8>
    503c:	a9431263 	ldp	x3, x4, [x19, #48]
    5040:	d37ef69a 	lsl	x26, x20, #2
    5044:	a94573fb 	ldp	x27, x28, [sp, #80]
    5048:	8b1a0002 	add	x2, x0, x26
    504c:	f9000e74 	str	x20, [x19, #24]
    5050:	f9001662 	str	x2, [x19, #40]
    5054:	b8366815 	str	w21, [x0, x22]
    5058:	f100031f 	cmp	x24, #0x0
    505c:	da9fa301 	csinv	x1, x24, xzr, ge	// ge = tcont
    5060:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5064:	fc396869 	str	d9, [x3, x25]
    5068:	aa1702a0 	orr	x0, x21, x23
    506c:	b8366841 	str	w1, [x2, x22]
    5070:	910006e1 	add	x1, x23, #0x1
    5074:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5078:	fc396888 	str	d8, [x4, x25]
    507c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5080:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5084:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5088:	f9000a61 	str	x1, [x19, #16]
    508c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5090:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5094:	d65f03c0 	ret
    5098:	9360fc54 	asr	x20, x2, #32
    509c:	eb80829f 	cmp	x20, x0, asr #32
    50a0:	54fff300 	b.eq	4f00 <fwp_p_ad_push+0x5c>  // b.none
    50a4:	f0000020 	adrp	x0, c000 <f0+0x2630>
    50a8:	913e8000 	add	x0, x0, #0xfa0
    50ac:	a9046bf9 	stp	x25, x26, [sp, #64]
    50b0:	a90573fb 	stp	x27, x28, [sp, #80]
    50b4:	97fff933 	bl	3580 <fwp_trap>
    50b8:	d37ffa94 	lsl	x20, x20, #1
    50bc:	17ffffb4 	b	4f8c <fwp_p_ad_push+0xe8>
    50c0:	a9428e62 	ldp	x2, x3, [x19, #40]
    50c4:	d37ef6d6 	lsl	x22, x22, #2
    50c8:	f9401e64 	ldr	x4, [x19, #56]
    50cc:	d37df339 	lsl	x25, x25, #3
    50d0:	17ffffe1 	b	5054 <fwp_p_ad_push+0x1b0>
    50d4:	f94006d3 	ldr	x19, [x22, #8]
    50d8:	17ffff94 	b	4f28 <fwp_p_ad_push+0x84>
    50dc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    50e0:	d65f03c0 	ret
    50e4:	f9401a60 	ldr	x0, [x19, #48]
    50e8:	d37cee9b 	lsl	x27, x20, #4
    50ec:	aa1b03e1 	mov	x1, x27
    50f0:	97fff5e0 	bl	2870 <realloc@plt>
    50f4:	aa0003e3 	mov	x3, x0
    50f8:	b4000660 	cbz	x0, 51c4 <fwp_p_ad_push+0x320>
    50fc:	8b1a0004 	add	x4, x0, x26
    5100:	f9400e60 	ldr	x0, [x19, #24]
    5104:	8b000c61 	add	x1, x3, x0, lsl #3
    5108:	a9030663 	stp	x3, x1, [x19, #48]
    510c:	b5000356 	cbnz	x22, 5174 <fwp_p_ad_push+0x2d0>
    5110:	f9401260 	ldr	x0, [x19, #32]
    5114:	d37ef69a 	lsl	x26, x20, #2
    5118:	d2800016 	mov	x22, #0x0                   	// #0
    511c:	f9001e64 	str	x4, [x19, #56]
    5120:	17ffffc9 	b	5044 <fwp_p_ad_push+0x1a0>
    5124:	aa1403e0 	mov	x0, x20
    5128:	97fff9e2 	bl	38b0 <fwp_tape_of>
    512c:	aa0003f3 	mov	x19, x0
    5130:	f9403000 	ldr	x0, [x0, #96]
    5134:	b4ffefa0 	cbz	x0, 4f28 <fwp_p_ad_push+0x84>
    5138:	f0000020 	adrp	x0, c000 <f0+0x2630>
    513c:	913fa000 	add	x0, x0, #0xfe8
    5140:	a9046bf9 	stp	x25, x26, [sp, #64]
    5144:	a90573fb 	stp	x27, x28, [sp, #80]
    5148:	97fff90e 	bl	3580 <fwp_trap>
    514c:	d37df2d9 	lsl	x25, x22, #3
    5150:	f9401661 	ldr	x1, [x19, #40]
    5154:	d37ef6d6 	lsl	x22, x22, #2
    5158:	d37ef69a 	lsl	x26, x20, #2
    515c:	aa1603e2 	mov	x2, x22
    5160:	8b1a0000 	add	x0, x0, x26
    5164:	97fff563 	bl	26f0 <memmove@plt>
    5168:	f9401260 	ldr	x0, [x19, #32]
    516c:	a9431263 	ldp	x3, x4, [x19, #48]
    5170:	17ffffb5 	b	5044 <fwp_p_ad_push+0x1a0>
    5174:	eb1b035f 	cmp	x26, x27
    5178:	d37df2d9 	lsl	x25, x22, #3
    517c:	9a9b2343 	csel	x3, x26, x27, cs	// cs = hs, nlast
    5180:	aa0403e0 	mov	x0, x4
    5184:	cb1a0063 	sub	x3, x3, x26
    5188:	aa1903e2 	mov	x2, x25
    518c:	97fff625 	bl	2a20 <__memmove_chk@plt>
    5190:	f9401a61 	ldr	x1, [x19, #48]
    5194:	f9401260 	ldr	x0, [x19, #32]
    5198:	8b1a0021 	add	x1, x1, x26
    519c:	f9001e61 	str	x1, [x19, #56]
    51a0:	17ffffec 	b	5150 <fwp_p_ad_push+0x2ac>
    51a4:	90000040 	adrp	x0, d000 <_IO_stdin_used+0x350>
    51a8:	9100e000 	add	x0, x0, #0x38
    51ac:	a90573fb 	stp	x27, x28, [sp, #80]
    51b0:	97fff8f4 	bl	3580 <fwp_trap>
    51b4:	90000040 	adrp	x0, d000 <_IO_stdin_used+0x350>
    51b8:	91006000 	add	x0, x0, #0x18
    51bc:	a90573fb 	stp	x27, x28, [sp, #80]
    51c0:	97fff8f0 	bl	3580 <fwp_trap>
    51c4:	aa1303e0 	mov	x0, x19
    51c8:	97fff772 	bl	2f90 <fwp_tape_unlink_scope>
    51cc:	f9401260 	ldr	x0, [x19, #32]
    51d0:	97fff5dc 	bl	2940 <free@plt>
    51d4:	f9401a60 	ldr	x0, [x19, #48]
    51d8:	97fff5da 	bl	2940 <free@plt>
    51dc:	f9402260 	ldr	x0, [x19, #64]
    51e0:	97fff5d8 	bl	2940 <free@plt>
    51e4:	f9000e7f 	str	xzr, [x19, #24]
    51e8:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    51ec:	f947e821 	ldr	x1, [x1, #4048]
    51f0:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    51f4:	d2800262 	mov	x2, #0x13                  	// #19
    51f8:	4f000400 	movi	v0.4s, #0x0
    51fc:	f0000020 	adrp	x0, c000 <f0+0x2630>
    5200:	f9400023 	ldr	x3, [x1]
    5204:	b900067f 	str	wzr, [x19, #4]
    5208:	d2800021 	mov	x1, #0x1                   	// #1
    520c:	9132e000 	add	x0, x0, #0xcb8
    5210:	3c808260 	stur	q0, [x19, #8]
    5214:	ad010260 	stp	q0, q0, [x19, #32]
    5218:	97fff5da 	bl	2980 <fwrite@plt>
    521c:	d2800000 	mov	x0, #0x0                   	// #0
    5220:	97fff5e4 	bl	29b0 <fflush@plt>
    5224:	52800cc0 	mov	w0, #0x66                  	// #102
    5228:	97fff5f2 	bl	29f0 <_Exit@plt>
    522c:	d503201f 	nop

0000000000005230 <w120>:
    5230:	d10203ff 	sub	sp, sp, #0x80
    5234:	9e660003 	fmov	x3, d0
    5238:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    523c:	f947f442 	ldr	x2, [x2, #4072]
    5240:	a9027bfd 	stp	x29, x30, [sp, #32]
    5244:	910083fd 	add	x29, sp, #0x20
    5248:	6d0627e8 	stp	d8, d9, [sp, #96]
    524c:	1e604009 	fmov	d9, d0
    5250:	1e604028 	fmov	d8, d1
    5254:	fd003bea 	str	d10, [sp, #112]
    5258:	1e60080a 	fmul	d10, d0, d0
    525c:	a90353f3 	stp	x19, x20, [sp, #48]
    5260:	910023f3 	add	x19, sp, #0x8
    5264:	aa0003f4 	mov	x20, x0
    5268:	a9045bf5 	stp	x21, x22, [sp, #64]
    526c:	aa0103f6 	mov	x22, x1
    5270:	92800015 	mov	x21, #0xffffffffffffffff    	// #-1
    5274:	a90563f7 	stp	x23, x24, [sp, #80]
    5278:	aa0303e1 	mov	x1, x3
    527c:	f9400044 	ldr	x4, [x2]
    5280:	f9000fe4 	str	x4, [sp, #24]
    5284:	d2800004 	mov	x4, #0x0                   	// #0
    5288:	aa0003e2 	mov	x2, x0
    528c:	aa1303e4 	mov	x4, x19
    5290:	a900fff5 	stp	x21, xzr, [sp, #8]
    5294:	97ffff04 	bl	4ea4 <fwp_p_ad_push>
    5298:	1e6a3908 	fsub	d8, d8, d10
    529c:	aa1603e2 	mov	x2, x22
    52a0:	aa1303e4 	mov	x4, x19
    52a4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    52a8:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    52ac:	9e660118 	fmov	x24, d8
    52b0:	97fffefd 	bl	4ea4 <fwp_p_ad_push>
    52b4:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    52b8:	aa0003f6 	mov	x22, x0
    52bc:	aa1303e4 	mov	x4, x19
    52c0:	aa1403e0 	mov	x0, x20
    52c4:	1e69394a 	fsub	d10, d10, d9
    52c8:	aa1503e2 	mov	x2, x21
    52cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    52d0:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    52d4:	9e660157 	fmov	x23, d10
    52d8:	97fffef3 	bl	4ea4 <fwp_p_ad_push>
    52dc:	1e680908 	fmul	d8, d8, d8
    52e0:	aa0003f4 	mov	x20, x0
    52e4:	aa1303e4 	mov	x4, x19
    52e8:	aa1803e3 	mov	x3, x24
    52ec:	aa1803e1 	mov	x1, x24
    52f0:	aa1603e2 	mov	x2, x22
    52f4:	aa1603e0 	mov	x0, x22
    52f8:	97fffeeb 	bl	4ea4 <fwp_p_ad_push>
    52fc:	aa0003e2 	mov	x2, x0
    5300:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5304:	9e670029 	fmov	d9, x1
    5308:	9e660101 	fmov	x1, d8
    530c:	aa1303e4 	mov	x4, x19
    5310:	1e690909 	fmul	d9, d8, d9
    5314:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5318:	aa1503e0 	mov	x0, x21
    531c:	97fffee2 	bl	4ea4 <fwp_p_ad_push>
    5320:	1e6a094a 	fmul	d10, d10, d10
    5324:	aa1303e4 	mov	x4, x19
    5328:	aa1703e3 	mov	x3, x23
    532c:	aa0003f3 	mov	x19, x0
    5330:	aa1703e1 	mov	x1, x23
    5334:	aa1403e2 	mov	x2, x20
    5338:	aa1403e0 	mov	x0, x20
    533c:	97fffeda 	bl	4ea4 <fwp_p_ad_push>
    5340:	1e6a2929 	fadd	d9, d9, d10
    5344:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5348:	d2800004 	mov	x4, #0x0                   	// #0
    534c:	aa0303e1 	mov	x1, x3
    5350:	aa1303e2 	mov	x2, x19
    5354:	97fffed4 	bl	4ea4 <fwp_p_ad_push>
    5358:	aa0003e1 	mov	x1, x0
    535c:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    5360:	f947f463 	ldr	x3, [x3, #4072]
    5364:	f9400fe0 	ldr	x0, [sp, #24]
    5368:	f9400064 	ldr	x4, [x3]
    536c:	eb040000 	subs	x0, x0, x4
    5370:	d2800004 	mov	x4, #0x0                   	// #0
    5374:	54000161 	b.ne	53a0 <w120+0x170>  // b.any
    5378:	9e660122 	fmov	x2, d9
    537c:	fd403bea 	ldr	d10, [sp, #112]
    5380:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5384:	a94353f3 	ldp	x19, x20, [sp, #48]
    5388:	aa0203e0 	mov	x0, x2
    538c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    5390:	a94563f7 	ldp	x23, x24, [sp, #80]
    5394:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5398:	910203ff 	add	sp, sp, #0x80
    539c:	d65f03c0 	ret
    53a0:	97fff538 	bl	2880 <__stack_chk_fail@plt>

00000000000053a4 <w176.constprop.0>:
    53a4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    53a8:	910003fd 	mov	x29, sp
    53ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    53b0:	fd001be8 	str	d8, [sp, #48]
    53b4:	f9400015 	ldr	x21, [x0]
    53b8:	b4000355 	cbz	x21, 5420 <w176.constprop.0+0x7c>
    53bc:	2f00e408 	movi	d8, #0x0
    53c0:	91002016 	add	x22, x0, #0x8
    53c4:	a90153f3 	stp	x19, x20, [sp, #16]
    53c8:	91004014 	add	x20, x0, #0x10
    53cc:	d2800013 	mov	x19, #0x0                   	// #0
    53d0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    53d4:	d503201f 	nop
    53d8:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    53dc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    53e0:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    53e4:	aa0303e1 	mov	x1, x3
    53e8:	1e602908 	fadd	d8, d8, d0
    53ec:	d2800004 	mov	x4, #0x0                   	// #0
    53f0:	91000a73 	add	x19, x19, #0x2
    53f4:	97fffeac 	bl	4ea4 <fwp_p_ad_push>
    53f8:	eb1302bf 	cmp	x21, x19
    53fc:	54fffee8 	b.hi	53d8 <w176.constprop.0+0x34>  // b.pmore
    5400:	9e660102 	fmov	x2, d8
    5404:	fd401be8 	ldr	d8, [sp, #48]
    5408:	a94153f3 	ldp	x19, x20, [sp, #16]
    540c:	aa0003e1 	mov	x1, x0
    5410:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5414:	aa0203e0 	mov	x0, x2
    5418:	a8c47bfd 	ldp	x29, x30, [sp], #64
    541c:	d65f03c0 	ret
    5420:	2f00e408 	movi	d8, #0x0
    5424:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5428:	a9425bf5 	ldp	x21, x22, [sp, #32]
    542c:	aa0003e1 	mov	x1, x0
    5430:	9e660102 	fmov	x2, d8
    5434:	fd401be8 	ldr	d8, [sp, #48]
    5438:	a8c47bfd 	ldp	x29, x30, [sp], #64
    543c:	aa0203e0 	mov	x0, x2
    5440:	d65f03c0 	ret

0000000000005444 <fwp_rc_share>:
    5444:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    5448:	91150042 	add	x2, x2, #0x540
    544c:	f949d843 	ldr	x3, [x2, #5040]
    5450:	f949ec41 	ldr	x1, [x2, #5080]
    5454:	cb030000 	sub	x0, x0, x3
    5458:	eb01401f 	cmp	x0, x1, lsl #16
    545c:	540002c2 	b.cs	54b4 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5460:	d350fc01 	lsr	x1, x0, #16
    5464:	f949fc44 	ldr	x4, [x2, #5112]
    5468:	8b010821 	add	x1, x1, x1, lsl #2
    546c:	d37df021 	lsl	x1, x1, #3
    5470:	8b010083 	add	x3, x4, x1
    5474:	f9401062 	ldr	x2, [x3, #32]
    5478:	b40001e2 	cbz	x2, 54b4 <fwp_rc_share+0x70>
    547c:	38616881 	ldrb	w1, [x4, x1]
    5480:	7100083f 	cmp	w1, #0x2
    5484:	540001a0 	b.eq	54b8 <fwp_rc_share+0x74>  // b.none
    5488:	7100043f 	cmp	w1, #0x1
    548c:	54000141 	b.ne	54b4 <fwp_rc_share+0x70>  // b.any
    5490:	29430464 	ldp	w4, w1, [x3, #24]
    5494:	92403c00 	and	x0, x0, #0xffff
    5498:	9b047c00 	mul	x0, x0, x4
    549c:	d360fc00 	lsr	x0, x0, #32
    54a0:	eb01001f 	cmp	x0, x1
    54a4:	54000082 	b.cs	54b4 <fwp_rc_share+0x70>  // b.hs, b.nlast
    54a8:	8b000042 	add	x2, x2, x0
    54ac:	39400040 	ldrb	w0, [x2]
    54b0:	350000a0 	cbnz	w0, 54c4 <fwp_rc_share+0x80>
    54b4:	d65f03c0 	ret
    54b8:	72003c1f 	tst	w0, #0xffff
    54bc:	54ffff80 	b.eq	54ac <fwp_rc_share+0x68>  // b.none
    54c0:	d65f03c0 	ret
    54c4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    54c8:	90000040 	adrp	x0, d000 <_IO_stdin_used+0x350>
    54cc:	91016000 	add	x0, x0, #0x58
    54d0:	910003fd 	mov	x29, sp
    54d4:	97fff82b 	bl	3580 <fwp_trap>
    54d8:	d503201f 	nop
    54dc:	d503201f 	nop

00000000000054e0 <fwp_rc_fresh>:
    54e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    54e4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    54e8:	91150063 	add	x3, x3, #0x540
    54ec:	910003fd 	mov	x29, sp
    54f0:	a90153f3 	stp	x19, x20, [sp, #16]
    54f4:	aa0003f3 	mov	x19, x0
    54f8:	f949d861 	ldr	x1, [x3, #5040]
    54fc:	f949ec60 	ldr	x0, [x3, #5080]
    5500:	cb010261 	sub	x1, x19, x1
    5504:	eb00403f 	cmp	x1, x0, lsl #16
    5508:	54000322 	b.cs	556c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    550c:	d350fc22 	lsr	x2, x1, #16
    5510:	f949fc63 	ldr	x3, [x3, #5112]
    5514:	8b020842 	add	x2, x2, x2, lsl #2
    5518:	d37df042 	lsl	x2, x2, #3
    551c:	8b020060 	add	x0, x3, x2
    5520:	f9401014 	ldr	x20, [x0, #32]
    5524:	b4000254 	cbz	x20, 556c <fwp_rc_fresh+0x8c>
    5528:	38626862 	ldrb	w2, [x3, x2]
    552c:	7100085f 	cmp	w2, #0x2
    5530:	54000260 	b.eq	557c <fwp_rc_fresh+0x9c>  // b.none
    5534:	7100045f 	cmp	w2, #0x1
    5538:	540001a1 	b.ne	556c <fwp_rc_fresh+0x8c>  // b.any
    553c:	29430002 	ldp	w2, w0, [x0, #24]
    5540:	92403c21 	and	x1, x1, #0xffff
    5544:	9b027c21 	mul	x1, x1, x2
    5548:	d360fc21 	lsr	x1, x1, #32
    554c:	eb00003f 	cmp	x1, x0
    5550:	540000e2 	b.cs	556c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5554:	8b010294 	add	x20, x20, x1
    5558:	39400280 	ldrb	w0, [x20]
    555c:	7103fc1f 	cmp	w0, #0xff
    5560:	540001a0 	b.eq	5594 <fwp_rc_fresh+0xb4>  // b.none
    5564:	52800020 	mov	w0, #0x1                   	// #1
    5568:	39000280 	strb	w0, [x20]
    556c:	aa1303e0 	mov	x0, x19
    5570:	a94153f3 	ldp	x19, x20, [sp, #16]
    5574:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5578:	d65f03c0 	ret
    557c:	72003c3f 	tst	w1, #0xffff
    5580:	54fffec0 	b.eq	5558 <fwp_rc_fresh+0x78>  // b.none
    5584:	aa1303e0 	mov	x0, x19
    5588:	a94153f3 	ldp	x19, x20, [sp, #16]
    558c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5590:	d65f03c0 	ret
    5594:	aa1403e0 	mov	x0, x20
    5598:	97fffbf6 	bl	4570 <fwp_rc_forget_slot>
    559c:	17fffff2 	b	5564 <fwp_rc_fresh+0x84>

00000000000055a0 <fwp_rc_free_arr>:
    55a0:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    55a4:	91150063 	add	x3, x3, #0x540
    55a8:	f949d861 	ldr	x1, [x3, #5040]
    55ac:	f949ec62 	ldr	x2, [x3, #5080]
    55b0:	cb010001 	sub	x1, x0, x1
    55b4:	eb02403f 	cmp	x1, x2, lsl #16
    55b8:	54000342 	b.cs	5620 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    55bc:	d350fc22 	lsr	x2, x1, #16
    55c0:	f949fc65 	ldr	x5, [x3, #5112]
    55c4:	8b020842 	add	x2, x2, x2, lsl #2
    55c8:	d37df042 	lsl	x2, x2, #3
    55cc:	8b0200a4 	add	x4, x5, x2
    55d0:	f9401083 	ldr	x3, [x4, #32]
    55d4:	b4000263 	cbz	x3, 5620 <fwp_rc_free_arr+0x80>
    55d8:	386268a2 	ldrb	w2, [x5, x2]
    55dc:	7100085f 	cmp	w2, #0x2
    55e0:	540001c0 	b.eq	5618 <fwp_rc_free_arr+0x78>  // b.none
    55e4:	7100045f 	cmp	w2, #0x1
    55e8:	540001c1 	b.ne	5620 <fwp_rc_free_arr+0x80>  // b.any
    55ec:	29430885 	ldp	w5, w2, [x4, #24]
    55f0:	92403c21 	and	x1, x1, #0xffff
    55f4:	9b057c21 	mul	x1, x1, x5
    55f8:	d360fc21 	lsr	x1, x1, #32
    55fc:	eb02003f 	cmp	x1, x2
    5600:	54000102 	b.cs	5620 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5604:	8b010063 	add	x3, x3, x1
    5608:	39400061 	ldrb	w1, [x3]
    560c:	7100043f 	cmp	w1, #0x1
    5610:	54000081 	b.ne	5620 <fwp_rc_free_arr+0x80>  // b.any
    5614:	17fffc77 	b	47f0 <fwp_mem_free>
    5618:	72003c3f 	tst	w1, #0xffff
    561c:	54ffff60 	b.eq	5608 <fwp_rc_free_arr+0x68>  // b.none
    5620:	d65f03c0 	ret

0000000000005624 <fwp_rc_dup>:
    5624:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    5628:	91150042 	add	x2, x2, #0x540
    562c:	f949d841 	ldr	x1, [x2, #5040]
    5630:	f949ec43 	ldr	x3, [x2, #5080]
    5634:	cb010001 	sub	x1, x0, x1
    5638:	eb03403f 	cmp	x1, x3, lsl #16
    563c:	54000342 	b.cs	56a4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5640:	d350fc20 	lsr	x0, x1, #16
    5644:	f949fc44 	ldr	x4, [x2, #5112]
    5648:	8b000800 	add	x0, x0, x0, lsl #2
    564c:	d37df002 	lsl	x2, x0, #3
    5650:	8b020083 	add	x3, x4, x2
    5654:	f9401060 	ldr	x0, [x3, #32]
    5658:	b4000260 	cbz	x0, 56a4 <fwp_rc_dup+0x80>
    565c:	38626882 	ldrb	w2, [x4, x2]
    5660:	7100085f 	cmp	w2, #0x2
    5664:	54000220 	b.eq	56a8 <fwp_rc_dup+0x84>  // b.none
    5668:	7100045f 	cmp	w2, #0x1
    566c:	540001c1 	b.ne	56a4 <fwp_rc_dup+0x80>  // b.any
    5670:	29430864 	ldp	w4, w2, [x3, #24]
    5674:	92403c21 	and	x1, x1, #0xffff
    5678:	9b047c21 	mul	x1, x1, x4
    567c:	d360fc21 	lsr	x1, x1, #32
    5680:	eb02003f 	cmp	x1, x2
    5684:	54000102 	b.cs	56a4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5688:	8b010000 	add	x0, x0, x1
    568c:	39400001 	ldrb	w1, [x0]
    5690:	340000a1 	cbz	w1, 56a4 <fwp_rc_dup+0x80>
    5694:	7103f43f 	cmp	w1, #0xfd
    5698:	540000e8 	b.hi	56b4 <fwp_rc_dup+0x90>  // b.pmore
    569c:	11000421 	add	w1, w1, #0x1
    56a0:	39000001 	strb	w1, [x0]
    56a4:	d65f03c0 	ret
    56a8:	72003c3f 	tst	w1, #0xffff
    56ac:	54ffff00 	b.eq	568c <fwp_rc_dup+0x68>  // b.none
    56b0:	d65f03c0 	ret
    56b4:	17fffb68 	b	4454 <fwp_rc_wide_dup>
    56b8:	d503201f 	nop
    56bc:	d503201f 	nop

00000000000056c0 <fwp_owned_entry173>:
    56c0:	d10103ff 	sub	sp, sp, #0x40
    56c4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    56c8:	f947f442 	ldr	x2, [x2, #4072]
    56cc:	a9027bfd 	stp	x29, x30, [sp, #32]
    56d0:	910083fd 	add	x29, sp, #0x20
    56d4:	a90353f3 	stp	x19, x20, [sp, #48]
    56d8:	f9400043 	ldr	x3, [x2]
    56dc:	f9000fe3 	str	x3, [sp, #24]
    56e0:	d2800003 	mov	x3, #0x0                   	// #0
    56e4:	a9400c01 	ldp	x1, x3, [x0]
    56e8:	f9400802 	ldr	x2, [x0, #16]
    56ec:	ab020022 	adds	x2, x1, x2
    56f0:	540006e6 	b.vs	57cc <fwp_owned_entry173+0x10c>
    56f4:	910023e1 	add	x1, sp, #0x8
    56f8:	52800000 	mov	w0, #0x0                   	// #0
    56fc:	a9008be3 	stp	x3, x2, [sp, #8]
    5700:	97fffda1 	bl	4d84 <fwp_data.part.0.constprop.0>
    5704:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    5708:	91150063 	add	x3, x3, #0x540
    570c:	aa0003f3 	mov	x19, x0
    5710:	f949d861 	ldr	x1, [x3, #5040]
    5714:	f949ec60 	ldr	x0, [x3, #5080]
    5718:	cb010261 	sub	x1, x19, x1
    571c:	eb00403f 	cmp	x1, x0, lsl #16
    5720:	54000322 	b.cs	5784 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5724:	d350fc22 	lsr	x2, x1, #16
    5728:	f949fc63 	ldr	x3, [x3, #5112]
    572c:	8b020842 	add	x2, x2, x2, lsl #2
    5730:	d37df042 	lsl	x2, x2, #3
    5734:	8b020060 	add	x0, x3, x2
    5738:	f9401014 	ldr	x20, [x0, #32]
    573c:	b4000254 	cbz	x20, 5784 <fwp_owned_entry173+0xc4>
    5740:	38626862 	ldrb	w2, [x3, x2]
    5744:	7100085f 	cmp	w2, #0x2
    5748:	54000360 	b.eq	57b4 <fwp_owned_entry173+0xf4>  // b.none
    574c:	7100045f 	cmp	w2, #0x1
    5750:	540001a1 	b.ne	5784 <fwp_owned_entry173+0xc4>  // b.any
    5754:	29430002 	ldp	w2, w0, [x0, #24]
    5758:	92403c21 	and	x1, x1, #0xffff
    575c:	9b027c21 	mul	x1, x1, x2
    5760:	d360fc21 	lsr	x1, x1, #32
    5764:	eb00003f 	cmp	x1, x0
    5768:	540000e2 	b.cs	5784 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    576c:	8b010294 	add	x20, x20, x1
    5770:	39400280 	ldrb	w0, [x20]
    5774:	7103fc1f 	cmp	w0, #0xff
    5778:	54000240 	b.eq	57c0 <fwp_owned_entry173+0x100>  // b.none
    577c:	52800020 	mov	w0, #0x1                   	// #1
    5780:	39000280 	strb	w0, [x20]
    5784:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5788:	f947f400 	ldr	x0, [x0, #4072]
    578c:	f9400fe2 	ldr	x2, [sp, #24]
    5790:	f9400001 	ldr	x1, [x0]
    5794:	eb010042 	subs	x2, x2, x1
    5798:	d2800001 	mov	x1, #0x0                   	// #0
    579c:	540001a1 	b.ne	57d0 <fwp_owned_entry173+0x110>  // b.any
    57a0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    57a4:	aa1303e0 	mov	x0, x19
    57a8:	a94353f3 	ldp	x19, x20, [sp, #48]
    57ac:	910103ff 	add	sp, sp, #0x40
    57b0:	d65f03c0 	ret
    57b4:	72003c3f 	tst	w1, #0xffff
    57b8:	54fffe61 	b.ne	5784 <fwp_owned_entry173+0xc4>  // b.any
    57bc:	17ffffed 	b	5770 <fwp_owned_entry173+0xb0>
    57c0:	aa1403e0 	mov	x0, x20
    57c4:	97fffb6b 	bl	4570 <fwp_rc_forget_slot>
    57c8:	17ffffed 	b	577c <fwp_owned_entry173+0xbc>
    57cc:	97fff4ad 	bl	2a80 <fwp_trap_overflow.constprop.0>
    57d0:	97fff42c 	bl	2880 <__stack_chk_fail@plt>

00000000000057d4 <e173>:
    57d4:	d10103ff 	sub	sp, sp, #0x40
    57d8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    57dc:	f947f442 	ldr	x2, [x2, #4072]
    57e0:	a9027bfd 	stp	x29, x30, [sp, #32]
    57e4:	910083fd 	add	x29, sp, #0x20
    57e8:	a90353f3 	stp	x19, x20, [sp, #48]
    57ec:	f9400043 	ldr	x3, [x2]
    57f0:	f9000fe3 	str	x3, [sp, #24]
    57f4:	d2800003 	mov	x3, #0x0                   	// #0
    57f8:	a9400c01 	ldp	x1, x3, [x0]
    57fc:	f9400802 	ldr	x2, [x0, #16]
    5800:	ab020022 	adds	x2, x1, x2
    5804:	54000726 	b.vs	58e8 <e173+0x114>
    5808:	910023e1 	add	x1, sp, #0x8
    580c:	52800000 	mov	w0, #0x0                   	// #0
    5810:	a9008be3 	stp	x3, x2, [sp, #8]
    5814:	97fffd5c 	bl	4d84 <fwp_data.part.0.constprop.0>
    5818:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    581c:	91150063 	add	x3, x3, #0x540
    5820:	aa0003f3 	mov	x19, x0
    5824:	f949d861 	ldr	x1, [x3, #5040]
    5828:	f949ec60 	ldr	x0, [x3, #5080]
    582c:	cb010261 	sub	x1, x19, x1
    5830:	eb00403f 	cmp	x1, x0, lsl #16
    5834:	54000322 	b.cs	5898 <e173+0xc4>  // b.hs, b.nlast
    5838:	d350fc22 	lsr	x2, x1, #16
    583c:	f949fc63 	ldr	x3, [x3, #5112]
    5840:	8b020842 	add	x2, x2, x2, lsl #2
    5844:	d37df042 	lsl	x2, x2, #3
    5848:	8b020060 	add	x0, x3, x2
    584c:	f9401014 	ldr	x20, [x0, #32]
    5850:	b4000254 	cbz	x20, 5898 <e173+0xc4>
    5854:	38626862 	ldrb	w2, [x3, x2]
    5858:	7100085f 	cmp	w2, #0x2
    585c:	540003a0 	b.eq	58d0 <e173+0xfc>  // b.none
    5860:	7100045f 	cmp	w2, #0x1
    5864:	540001a1 	b.ne	5898 <e173+0xc4>  // b.any
    5868:	29430002 	ldp	w2, w0, [x0, #24]
    586c:	92403c21 	and	x1, x1, #0xffff
    5870:	9b027c21 	mul	x1, x1, x2
    5874:	d360fc21 	lsr	x1, x1, #32
    5878:	eb00003f 	cmp	x1, x0
    587c:	540000e2 	b.cs	5898 <e173+0xc4>  // b.hs, b.nlast
    5880:	8b010294 	add	x20, x20, x1
    5884:	39400280 	ldrb	w0, [x20]
    5888:	7103fc1f 	cmp	w0, #0xff
    588c:	54000280 	b.eq	58dc <e173+0x108>  // b.none
    5890:	52800020 	mov	w0, #0x1                   	// #1
    5894:	39000280 	strb	w0, [x20]
    5898:	aa1303e0 	mov	x0, x19
    589c:	97fffeea 	bl	5444 <fwp_rc_share>
    58a0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    58a4:	f947f400 	ldr	x0, [x0, #4072]
    58a8:	f9400fe2 	ldr	x2, [sp, #24]
    58ac:	f9400001 	ldr	x1, [x0]
    58b0:	eb010042 	subs	x2, x2, x1
    58b4:	d2800001 	mov	x1, #0x0                   	// #0
    58b8:	540001a1 	b.ne	58ec <e173+0x118>  // b.any
    58bc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    58c0:	aa1303e0 	mov	x0, x19
    58c4:	a94353f3 	ldp	x19, x20, [sp, #48]
    58c8:	910103ff 	add	sp, sp, #0x40
    58cc:	d65f03c0 	ret
    58d0:	72003c3f 	tst	w1, #0xffff
    58d4:	54fffe21 	b.ne	5898 <e173+0xc4>  // b.any
    58d8:	17ffffeb 	b	5884 <e173+0xb0>
    58dc:	aa1403e0 	mov	x0, x20
    58e0:	97fffb24 	bl	4570 <fwp_rc_forget_slot>
    58e4:	17ffffeb 	b	5890 <e173+0xbc>
    58e8:	97fff466 	bl	2a80 <fwp_trap_overflow.constprop.0>
    58ec:	97fff3e5 	bl	2880 <__stack_chk_fail@plt>

00000000000058f0 <fwp_drop1>:
    58f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    58f4:	910003fd 	mov	x29, sp
    58f8:	a90153f3 	stp	x19, x20, [sp, #16]
    58fc:	f90013f5 	str	x21, [sp, #32]
    5900:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    5904:	911502b4 	add	x20, x21, #0x540
    5908:	f949da81 	ldr	x1, [x20, #5040]
    590c:	f949ee82 	ldr	x2, [x20, #5080]
    5910:	cb010001 	sub	x1, x0, x1
    5914:	eb02403f 	cmp	x1, x2, lsl #16
    5918:	54000382 	b.cs	5988 <fwp_drop1+0x98>  // b.hs, b.nlast
    591c:	d350fc22 	lsr	x2, x1, #16
    5920:	f949fe84 	ldr	x4, [x20, #5112]
    5924:	8b020842 	add	x2, x2, x2, lsl #2
    5928:	d37df042 	lsl	x2, x2, #3
    592c:	8b020083 	add	x3, x4, x2
    5930:	f9401073 	ldr	x19, [x3, #32]
    5934:	b40002b3 	cbz	x19, 5988 <fwp_drop1+0x98>
    5938:	38626882 	ldrb	w2, [x4, x2]
    593c:	7100085f 	cmp	w2, #0x2
    5940:	540002c0 	b.eq	5998 <fwp_drop1+0xa8>  // b.none
    5944:	7100045f 	cmp	w2, #0x1
    5948:	54000201 	b.ne	5988 <fwp_drop1+0x98>  // b.any
    594c:	29430864 	ldp	w4, w2, [x3, #24]
    5950:	92403c21 	and	x1, x1, #0xffff
    5954:	9b047c21 	mul	x1, x1, x4
    5958:	d360fc21 	lsr	x1, x1, #32
    595c:	eb02003f 	cmp	x1, x2
    5960:	54000142 	b.cs	5988 <fwp_drop1+0x98>  // b.hs, b.nlast
    5964:	8b010273 	add	x19, x19, x1
    5968:	39400261 	ldrb	w1, [x19]
    596c:	340000e1 	cbz	w1, 5988 <fwp_drop1+0x98>
    5970:	7100043f 	cmp	w1, #0x1
    5974:	540001e0 	b.eq	59b0 <fwp_drop1+0xc0>  // b.none
    5978:	7103fc3f 	cmp	w1, #0xff
    597c:	540002e0 	b.eq	59d8 <fwp_drop1+0xe8>  // b.none
    5980:	51000421 	sub	w1, w1, #0x1
    5984:	39000261 	strb	w1, [x19]
    5988:	a94153f3 	ldp	x19, x20, [sp, #16]
    598c:	f94013f5 	ldr	x21, [sp, #32]
    5990:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5994:	d65f03c0 	ret
    5998:	72003c3f 	tst	w1, #0xffff
    599c:	54fffe60 	b.eq	5968 <fwp_drop1+0x78>  // b.none
    59a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    59a4:	f94013f5 	ldr	x21, [sp, #32]
    59a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    59ac:	d65f03c0 	ret
    59b0:	f9400813 	ldr	x19, [x0, #16]
    59b4:	97fffefb 	bl	55a0 <fwp_rc_free_arr>
    59b8:	911502a0 	add	x0, x21, #0x540
    59bc:	f949d801 	ldr	x1, [x0, #5040]
    59c0:	f949ec00 	ldr	x0, [x0, #5080]
    59c4:	cb010261 	sub	x1, x19, x1
    59c8:	eb00403f 	cmp	x1, x0, lsl #16
    59cc:	54fffde2 	b.cs	5988 <fwp_drop1+0x98>  // b.hs, b.nlast
    59d0:	aa1303e0 	mov	x0, x19
    59d4:	17ffffd2 	b	591c <fwp_drop1+0x2c>
    59d8:	ca534660 	eor	x0, x19, x19, lsr #17
    59dc:	911502b5 	add	x21, x21, #0x540
    59e0:	ca402400 	eor	x0, x0, x0, lsr #9
    59e4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    59e8:	f94a2400 	ldr	x0, [x0, #5192]
    59ec:	b5000080 	cbnz	x0, 59fc <fwp_drop1+0x10c>
    59f0:	14000010 	b	5a30 <fwp_drop1+0x140>
    59f4:	f9400800 	ldr	x0, [x0, #16]
    59f8:	b40001c0 	cbz	x0, 5a30 <fwp_drop1+0x140>
    59fc:	f9400001 	ldr	x1, [x0]
    5a00:	eb13003f 	cmp	x1, x19
    5a04:	54ffff81 	b.ne	59f4 <fwp_drop1+0x104>  // b.any
    5a08:	f9400401 	ldr	x1, [x0, #8]
    5a0c:	d1000421 	sub	x1, x1, #0x1
    5a10:	f9000401 	str	x1, [x0, #8]
    5a14:	f103f83f 	cmp	x1, #0xfe
    5a18:	54fffb81 	b.ne	5988 <fwp_drop1+0x98>  // b.any
    5a1c:	aa1303e0 	mov	x0, x19
    5a20:	97fffad4 	bl	4570 <fwp_rc_forget_slot>
    5a24:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5a28:	39000260 	strb	w0, [x19]
    5a2c:	17ffffd7 	b	5988 <fwp_drop1+0x98>
    5a30:	f0000020 	adrp	x0, c000 <f0+0x2630>
    5a34:	913d6000 	add	x0, x0, #0xf58
    5a38:	97fff6d2 	bl	3580 <fwp_trap>
    5a3c:	d503201f 	nop

0000000000005a40 <fwp_drop0>:
    5a40:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5a44:	910003fd 	mov	x29, sp
    5a48:	a90153f3 	stp	x19, x20, [sp, #16]
    5a4c:	f90013f5 	str	x21, [sp, #32]
    5a50:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    5a54:	911502b4 	add	x20, x21, #0x540
    5a58:	f949da81 	ldr	x1, [x20, #5040]
    5a5c:	f949ee82 	ldr	x2, [x20, #5080]
    5a60:	cb010001 	sub	x1, x0, x1
    5a64:	eb02403f 	cmp	x1, x2, lsl #16
    5a68:	54000382 	b.cs	5ad8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5a6c:	d350fc22 	lsr	x2, x1, #16
    5a70:	f949fe84 	ldr	x4, [x20, #5112]
    5a74:	8b020842 	add	x2, x2, x2, lsl #2
    5a78:	d37df042 	lsl	x2, x2, #3
    5a7c:	8b020083 	add	x3, x4, x2
    5a80:	f9401073 	ldr	x19, [x3, #32]
    5a84:	b40002b3 	cbz	x19, 5ad8 <fwp_drop0+0x98>
    5a88:	38626882 	ldrb	w2, [x4, x2]
    5a8c:	7100085f 	cmp	w2, #0x2
    5a90:	540002c0 	b.eq	5ae8 <fwp_drop0+0xa8>  // b.none
    5a94:	7100045f 	cmp	w2, #0x1
    5a98:	54000201 	b.ne	5ad8 <fwp_drop0+0x98>  // b.any
    5a9c:	29430864 	ldp	w4, w2, [x3, #24]
    5aa0:	92403c21 	and	x1, x1, #0xffff
    5aa4:	9b047c21 	mul	x1, x1, x4
    5aa8:	d360fc21 	lsr	x1, x1, #32
    5aac:	eb02003f 	cmp	x1, x2
    5ab0:	54000142 	b.cs	5ad8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ab4:	8b010273 	add	x19, x19, x1
    5ab8:	39400261 	ldrb	w1, [x19]
    5abc:	340000e1 	cbz	w1, 5ad8 <fwp_drop0+0x98>
    5ac0:	7100043f 	cmp	w1, #0x1
    5ac4:	540001e0 	b.eq	5b00 <fwp_drop0+0xc0>  // b.none
    5ac8:	7103fc3f 	cmp	w1, #0xff
    5acc:	540002e0 	b.eq	5b28 <fwp_drop0+0xe8>  // b.none
    5ad0:	51000421 	sub	w1, w1, #0x1
    5ad4:	39000261 	strb	w1, [x19]
    5ad8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5adc:	f94013f5 	ldr	x21, [sp, #32]
    5ae0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ae4:	d65f03c0 	ret
    5ae8:	72003c3f 	tst	w1, #0xffff
    5aec:	54fffe60 	b.eq	5ab8 <fwp_drop0+0x78>  // b.none
    5af0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5af4:	f94013f5 	ldr	x21, [sp, #32]
    5af8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5afc:	d65f03c0 	ret
    5b00:	f9400813 	ldr	x19, [x0, #16]
    5b04:	97fffea7 	bl	55a0 <fwp_rc_free_arr>
    5b08:	911502a0 	add	x0, x21, #0x540
    5b0c:	f949d801 	ldr	x1, [x0, #5040]
    5b10:	f949ec00 	ldr	x0, [x0, #5080]
    5b14:	cb010261 	sub	x1, x19, x1
    5b18:	eb00403f 	cmp	x1, x0, lsl #16
    5b1c:	54fffde2 	b.cs	5ad8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5b20:	aa1303e0 	mov	x0, x19
    5b24:	17ffffd2 	b	5a6c <fwp_drop0+0x2c>
    5b28:	ca534660 	eor	x0, x19, x19, lsr #17
    5b2c:	911502b5 	add	x21, x21, #0x540
    5b30:	ca402400 	eor	x0, x0, x0, lsr #9
    5b34:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5b38:	f94a2400 	ldr	x0, [x0, #5192]
    5b3c:	b5000080 	cbnz	x0, 5b4c <fwp_drop0+0x10c>
    5b40:	14000010 	b	5b80 <fwp_drop0+0x140>
    5b44:	f9400800 	ldr	x0, [x0, #16]
    5b48:	b40001c0 	cbz	x0, 5b80 <fwp_drop0+0x140>
    5b4c:	f9400001 	ldr	x1, [x0]
    5b50:	eb13003f 	cmp	x1, x19
    5b54:	54ffff81 	b.ne	5b44 <fwp_drop0+0x104>  // b.any
    5b58:	f9400401 	ldr	x1, [x0, #8]
    5b5c:	d1000421 	sub	x1, x1, #0x1
    5b60:	f9000401 	str	x1, [x0, #8]
    5b64:	f103f83f 	cmp	x1, #0xfe
    5b68:	54fffb81 	b.ne	5ad8 <fwp_drop0+0x98>  // b.any
    5b6c:	aa1303e0 	mov	x0, x19
    5b70:	97fffa80 	bl	4570 <fwp_rc_forget_slot>
    5b74:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5b78:	39000260 	strb	w0, [x19]
    5b7c:	17ffffd7 	b	5ad8 <fwp_drop0+0x98>
    5b80:	f0000020 	adrp	x0, c000 <f0+0x2630>
    5b84:	913d6000 	add	x0, x0, #0xf58
    5b88:	97fff67e 	bl	3580 <fwp_trap>
    5b8c:	d503201f 	nop

0000000000005b90 <fwp_closure_drop>:
    5b90:	90000165 	adrp	x5, 31000 <fwp_root_context+0xca0>
    5b94:	911500a4 	add	x4, x5, #0x540
    5b98:	aa0003e1 	mov	x1, x0
    5b9c:	f949d882 	ldr	x2, [x4, #5040]
    5ba0:	f949ec80 	ldr	x0, [x4, #5080]
    5ba4:	cb020022 	sub	x2, x1, x2
    5ba8:	eb00405f 	cmp	x2, x0, lsl #16
    5bac:	54000662 	b.cs	5c78 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5bb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5bb4:	d350fc43 	lsr	x3, x2, #16
    5bb8:	910003fd 	mov	x29, sp
    5bbc:	8b030863 	add	x3, x3, x3, lsl #2
    5bc0:	f949fc84 	ldr	x4, [x4, #5112]
    5bc4:	d37df063 	lsl	x3, x3, #3
    5bc8:	f9000bf3 	str	x19, [sp, #16]
    5bcc:	8b030080 	add	x0, x4, x3
    5bd0:	f9401013 	ldr	x19, [x0, #32]
    5bd4:	b40002b3 	cbz	x19, 5c28 <fwp_closure_drop+0x98>
    5bd8:	38636883 	ldrb	w3, [x4, x3]
    5bdc:	7100087f 	cmp	w3, #0x2
    5be0:	54000420 	b.eq	5c64 <fwp_closure_drop+0xd4>  // b.none
    5be4:	7100047f 	cmp	w3, #0x1
    5be8:	54000201 	b.ne	5c28 <fwp_closure_drop+0x98>  // b.any
    5bec:	29430003 	ldp	w3, w0, [x0, #24]
    5bf0:	92403c42 	and	x2, x2, #0xffff
    5bf4:	9b037c42 	mul	x2, x2, x3
    5bf8:	d360fc42 	lsr	x2, x2, #32
    5bfc:	eb00005f 	cmp	x2, x0
    5c00:	54000142 	b.cs	5c28 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5c04:	8b020273 	add	x19, x19, x2
    5c08:	39400260 	ldrb	w0, [x19]
    5c0c:	340000e0 	cbz	w0, 5c28 <fwp_closure_drop+0x98>
    5c10:	7100041f 	cmp	w0, #0x1
    5c14:	54000100 	b.eq	5c34 <fwp_closure_drop+0xa4>  // b.none
    5c18:	7103fc1f 	cmp	w0, #0xff
    5c1c:	54000300 	b.eq	5c7c <fwp_closure_drop+0xec>  // b.none
    5c20:	51000400 	sub	w0, w0, #0x1
    5c24:	39000260 	strb	w0, [x19]
    5c28:	f9400bf3 	ldr	x19, [sp, #16]
    5c2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5c30:	d65f03c0 	ret
    5c34:	d53bd040 	mrs	x0, tpidr_el0
    5c38:	91400000 	add	x0, x0, #0x0, lsl #12
    5c3c:	91004000 	add	x0, x0, #0x10
    5c40:	f9400000 	ldr	x0, [x0]
    5c44:	b4000080 	cbz	x0, 5c54 <fwp_closure_drop+0xc4>
    5c48:	f9400bf3 	ldr	x19, [sp, #16]
    5c4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5c50:	17fff665 	b	35e4 <fwp_closure_drop_push>
    5c54:	f9400bf3 	ldr	x19, [sp, #16]
    5c58:	aa0103e0 	mov	x0, x1
    5c5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5c60:	17fff6d0 	b	37a0 <fwp_closure_drop.part.0>
    5c64:	72003c5f 	tst	w2, #0xffff
    5c68:	54fffd00 	b.eq	5c08 <fwp_closure_drop+0x78>  // b.none
    5c6c:	f9400bf3 	ldr	x19, [sp, #16]
    5c70:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5c74:	d65f03c0 	ret
    5c78:	d65f03c0 	ret
    5c7c:	ca534660 	eor	x0, x19, x19, lsr #17
    5c80:	911500a5 	add	x5, x5, #0x540
    5c84:	ca402400 	eor	x0, x0, x0, lsr #9
    5c88:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5c8c:	f94a2400 	ldr	x0, [x0, #5192]
    5c90:	b5000080 	cbnz	x0, 5ca0 <fwp_closure_drop+0x110>
    5c94:	14000010 	b	5cd4 <fwp_closure_drop+0x144>
    5c98:	f9400800 	ldr	x0, [x0, #16]
    5c9c:	b40001c0 	cbz	x0, 5cd4 <fwp_closure_drop+0x144>
    5ca0:	f9400001 	ldr	x1, [x0]
    5ca4:	eb13003f 	cmp	x1, x19
    5ca8:	54ffff81 	b.ne	5c98 <fwp_closure_drop+0x108>  // b.any
    5cac:	f9400401 	ldr	x1, [x0, #8]
    5cb0:	d1000421 	sub	x1, x1, #0x1
    5cb4:	f9000401 	str	x1, [x0, #8]
    5cb8:	f103f83f 	cmp	x1, #0xfe
    5cbc:	54fffb61 	b.ne	5c28 <fwp_closure_drop+0x98>  // b.any
    5cc0:	aa1303e0 	mov	x0, x19
    5cc4:	97fffa2b 	bl	4570 <fwp_rc_forget_slot>
    5cc8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ccc:	39000260 	strb	w0, [x19]
    5cd0:	17ffffd6 	b	5c28 <fwp_closure_drop+0x98>
    5cd4:	f0000020 	adrp	x0, c000 <f0+0x2630>
    5cd8:	913d6000 	add	x0, x0, #0xf58
    5cdc:	97fff629 	bl	3580 <fwp_trap>

0000000000005ce0 <fwp_owned_tape_release>:
    5ce0:	b4000940 	cbz	x0, 5e08 <fwp_owned_tape_release+0x128>
    5ce4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5ce8:	910003fd 	mov	x29, sp
    5cec:	a90153f3 	stp	x19, x20, [sp, #16]
    5cf0:	aa0003f3 	mov	x19, x0
    5cf4:	f9400000 	ldr	x0, [x0]
    5cf8:	b4000060 	cbz	x0, 5d04 <fwp_owned_tape_release+0x24>
    5cfc:	f9400661 	ldr	x1, [x19, #8]
    5d00:	f9000401 	str	x1, [x0, #8]
    5d04:	f9400661 	ldr	x1, [x19, #8]
    5d08:	b4000041 	cbz	x1, 5d10 <fwp_owned_tape_release+0x30>
    5d0c:	f9000020 	str	x0, [x1]
    5d10:	f9400a60 	ldr	x0, [x19, #16]
    5d14:	f9403401 	ldr	x1, [x0, #104]
    5d18:	b40005c1 	cbz	x1, 5dd0 <fwp_owned_tape_release+0xf0>
    5d1c:	a9450a60 	ldp	x0, x2, [x19, #80]
    5d20:	eb00005f 	cmp	x2, x0
    5d24:	540002ed 	b.le	5d80 <fwp_owned_tape_release+0xa0>
    5d28:	d2800014 	mov	x20, #0x0                   	// #0
    5d2c:	f90013f5 	str	x21, [sp, #32]
    5d30:	d2800015 	mov	x21, #0x0                   	// #0
    5d34:	d503201f 	nop
    5d38:	f9402260 	ldr	x0, [x19, #64]
    5d3c:	910006b5 	add	x21, x21, #0x1
    5d40:	f8746800 	ldr	x0, [x0, x20]
    5d44:	d63f0020 	blr	x1
    5d48:	f9402260 	ldr	x0, [x19, #64]
    5d4c:	f9400a61 	ldr	x1, [x19, #16]
    5d50:	8b140000 	add	x0, x0, x20
    5d54:	91004294 	add	x20, x20, #0x10
    5d58:	f9400400 	ldr	x0, [x0, #8]
    5d5c:	f9403421 	ldr	x1, [x1, #104]
    5d60:	d63f0020 	blr	x1
    5d64:	a9450261 	ldp	x1, x0, [x19, #80]
    5d68:	cb010000 	sub	x0, x0, x1
    5d6c:	eb15001f 	cmp	x0, x21
    5d70:	f9400a60 	ldr	x0, [x19, #16]
    5d74:	f9403401 	ldr	x1, [x0, #104]
    5d78:	54fffe0c 	b.gt	5d38 <fwp_owned_tape_release+0x58>
    5d7c:	f94013f5 	ldr	x21, [sp, #32]
    5d80:	f9403663 	ldr	x3, [x19, #104]
    5d84:	f9401262 	ldr	x2, [x19, #32]
    5d88:	f100007f 	cmp	x3, #0x0
    5d8c:	540001ed 	b.le	5dc8 <fwp_owned_tape_release+0xe8>
    5d90:	d2800014 	mov	x20, #0x0                   	// #0
    5d94:	d503201f 	nop
    5d98:	f9402660 	ldr	x0, [x19, #72]
    5d9c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5da0:	eb02001f 	cmp	x0, x2
    5da4:	540000c0 	b.eq	5dbc <fwp_owned_tape_release+0xdc>  // b.none
    5da8:	d63f0020 	blr	x1
    5dac:	f9400a60 	ldr	x0, [x19, #16]
    5db0:	f9401262 	ldr	x2, [x19, #32]
    5db4:	f9403663 	ldr	x3, [x19, #104]
    5db8:	f9403401 	ldr	x1, [x0, #104]
    5dbc:	91000694 	add	x20, x20, #0x1
    5dc0:	eb14007f 	cmp	x3, x20
    5dc4:	54fffeac 	b.gt	5d98 <fwp_owned_tape_release+0xb8>
    5dc8:	aa0203e0 	mov	x0, x2
    5dcc:	d63f0020 	blr	x1
    5dd0:	f9401660 	ldr	x0, [x19, #40]
    5dd4:	97ffff6f 	bl	5b90 <fwp_closure_drop>
    5dd8:	f9401a60 	ldr	x0, [x19, #48]
    5ddc:	97ffff6d 	bl	5b90 <fwp_closure_drop>
    5de0:	f9401e60 	ldr	x0, [x19, #56]
    5de4:	97ffff6b 	bl	5b90 <fwp_closure_drop>
    5de8:	f9402260 	ldr	x0, [x19, #64]
    5dec:	97fffa81 	bl	47f0 <fwp_mem_free>
    5df0:	f9402660 	ldr	x0, [x19, #72]
    5df4:	97fffa7f 	bl	47f0 <fwp_mem_free>
    5df8:	aa1303e0 	mov	x0, x19
    5dfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e00:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e04:	17fffa7b 	b	47f0 <fwp_mem_free>
    5e08:	d65f03c0 	ret
    5e0c:	d503201f 	nop

0000000000005e10 <fwp_tape_finish>:
    5e10:	d10203ff 	sub	sp, sp, #0x80
    5e14:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    5e18:	f947f421 	ldr	x1, [x1, #4072]
    5e1c:	a9047bfd 	stp	x29, x30, [sp, #64]
    5e20:	910103fd 	add	x29, sp, #0x40
    5e24:	a90553f3 	stp	x19, x20, [sp, #80]
    5e28:	a9065bf5 	stp	x21, x22, [sp, #96]
    5e2c:	a90763f7 	stp	x23, x24, [sp, #112]
    5e30:	f00000d8 	adrp	x24, 20000 <__data_start>
    5e34:	9100c316 	add	x22, x24, #0x30
    5e38:	f9400022 	ldr	x2, [x1]
    5e3c:	f9001fe2 	str	x2, [sp, #56]
    5e40:	d2800002 	mov	x2, #0x0                   	// #0
    5e44:	910122c0 	add	x0, x22, #0x48
    5e48:	97fff52e 	bl	3300 <fwp_tape_buffers_dispose>
    5e4c:	f90042df 	str	xzr, [x22, #128]
    5e50:	f94022c0 	ldr	x0, [x22, #64]
    5e54:	f100001f 	cmp	x0, #0x0
    5e58:	5400030d 	b.le	5eb8 <fwp_tape_finish+0xa8>
    5e5c:	910003f7 	mov	x23, sp
    5e60:	d2800015 	mov	x21, #0x0                   	// #0
    5e64:	d2800014 	mov	x20, #0x0                   	// #0
    5e68:	f94002d3 	ldr	x19, [x22]
    5e6c:	91000694 	add	x20, x20, #0x1
    5e70:	8b150273 	add	x19, x19, x21
    5e74:	9101a2b5 	add	x21, x21, #0x68
    5e78:	aa1303e0 	mov	x0, x19
    5e7c:	97fff445 	bl	2f90 <fwp_tape_unlink_scope>
    5e80:	aa1703e0 	mov	x0, x23
    5e84:	f9401261 	ldr	x1, [x19, #32]
    5e88:	f90003e1 	str	x1, [sp]
    5e8c:	f9401a62 	ldr	x2, [x19, #48]
    5e90:	f9000be2 	str	x2, [sp, #16]
    5e94:	f9402261 	ldr	x1, [x19, #64]
    5e98:	f90013e1 	str	x1, [sp, #32]
    5e9c:	97fff519 	bl	3300 <fwp_tape_buffers_dispose>
    5ea0:	f9403260 	ldr	x0, [x19, #96]
    5ea4:	97ffff8f 	bl	5ce0 <fwp_owned_tape_release>
    5ea8:	f900327f 	str	xzr, [x19, #96]
    5eac:	f94022c0 	ldr	x0, [x22, #64]
    5eb0:	eb14001f 	cmp	x0, x20
    5eb4:	54fffdac 	b.gt	5e68 <fwp_tape_finish+0x58>
    5eb8:	f9401b00 	ldr	x0, [x24, #48]
    5ebc:	9100c313 	add	x19, x24, #0x30
    5ec0:	97fff2a0 	bl	2940 <free@plt>
    5ec4:	f9001b1f 	str	xzr, [x24, #48]
    5ec8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5ecc:	f947f400 	ldr	x0, [x0, #4072]
    5ed0:	f900227f 	str	xzr, [x19, #64]
    5ed4:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    5ed8:	f9401fe2 	ldr	x2, [sp, #56]
    5edc:	f9400001 	ldr	x1, [x0]
    5ee0:	eb010042 	subs	x2, x2, x1
    5ee4:	d2800001 	mov	x1, #0x0                   	// #0
    5ee8:	540000e1 	b.ne	5f04 <fwp_tape_finish+0xf4>  // b.any
    5eec:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5ef0:	a94553f3 	ldp	x19, x20, [sp, #80]
    5ef4:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5ef8:	a94763f7 	ldp	x23, x24, [sp, #112]
    5efc:	910203ff 	add	sp, sp, #0x80
    5f00:	d65f03c0 	ret
    5f04:	97fff25f 	bl	2880 <__stack_chk_fail@plt>
    5f08:	d503201f 	nop
    5f0c:	d503201f 	nop

0000000000005f10 <fwp_tape_scope_release>:
    5f10:	d10243ff 	sub	sp, sp, #0x90
    5f14:	a9047bfd 	stp	x29, x30, [sp, #64]
    5f18:	910103fd 	add	x29, sp, #0x40
    5f1c:	a90553f3 	stp	x19, x20, [sp, #80]
    5f20:	aa0003f4 	mov	x20, x0
    5f24:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5f28:	f947f400 	ldr	x0, [x0, #4072]
    5f2c:	b9400285 	ldr	w5, [x20]
    5f30:	f9400001 	ldr	x1, [x0]
    5f34:	f9001fe1 	str	x1, [sp, #56]
    5f38:	d2800001 	mov	x1, #0x0                   	// #0
    5f3c:	37f806c5 	tbnz	w5, #31, 6014 <fwp_tape_scope_release+0x104>
    5f40:	a90763f7 	stp	x23, x24, [sp, #112]
    5f44:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    5f48:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    5f4c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    5f50:	f00000d3 	adrp	x19, 20000 <__data_start>
    5f54:	910003f7 	mov	x23, sp
    5f58:	9100c273 	add	x19, x19, #0x30
    5f5c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    5f60:	a9065bf5 	stp	x21, x22, [sp, #96]
    5f64:	52800d16 	mov	w22, #0x68                  	// #104
    5f68:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    5f6c:	f90043f9 	str	x25, [sp, #128]
    5f70:	14000006 	b	5f88 <fwp_tape_scope_release+0x78>
    5f74:	97fff4e3 	bl	3300 <fwp_tape_buffers_dispose>
    5f78:	aa1903e0 	mov	x0, x25
    5f7c:	97ffff59 	bl	5ce0 <fwp_owned_tape_release>
    5f80:	b9400285 	ldr	w5, [x20]
    5f84:	37f80425 	tbnz	w5, #31, 6008 <fwp_tape_scope_release+0xf8>
    5f88:	f9400266 	ldr	x6, [x19]
    5f8c:	9b367ca5 	smull	x5, w5, w22
    5f90:	8b0500c0 	add	x0, x6, x5
    5f94:	97fff3ff 	bl	2f90 <fwp_tape_unlink_scope>
    5f98:	ad410001 	ldp	q1, q0, [x0, #32]
    5f9c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    5fa0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    5fa4:	f9400c03 	ldr	x3, [x0, #24]
    5fa8:	ad0003e1 	stp	q1, q0, [sp]
    5fac:	b86568c1 	ldr	w1, [x6, x5]
    5fb0:	a9440804 	ldp	x4, x2, [x0, #64]
    5fb4:	b900041f 	str	wzr, [x0, #4]
    5fb8:	f9403019 	ldr	x25, [x0, #96]
    5fbc:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    5fc0:	f9000c1f 	str	xzr, [x0, #24]
    5fc4:	a9020fe4 	stp	x4, x3, [sp, #32]
    5fc8:	f9001be2 	str	x2, [sp, #48]
    5fcc:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    5fd0:	f900301f 	str	xzr, [x0, #96]
    5fd4:	6b15003f 	cmp	w1, w21
    5fd8:	540000e8 	b.hi	5ff4 <fwp_tape_scope_release+0xe4>  // b.pmore
    5fdc:	9343fca5 	asr	x5, x5, #3
    5fe0:	f9404e60 	ldr	x0, [x19, #152]
    5fe4:	9b187ca5 	mul	x5, x5, x24
    5fe8:	eb0000bf 	cmp	x5, x0
    5fec:	5400004a 	b.ge	5ff4 <fwp_tape_scope_release+0xe4>  // b.tcont
    5ff0:	f9004e65 	str	x5, [x19, #152]
    5ff4:	aa1703e0 	mov	x0, x23
    5ff8:	b5fffbf9 	cbnz	x25, 5f74 <fwp_tape_scope_release+0x64>
    5ffc:	97fff841 	bl	4100 <fwp_tape_buffers_release>
    6000:	b9400285 	ldr	w5, [x20]
    6004:	36fffc25 	tbz	w5, #31, 5f88 <fwp_tape_scope_release+0x78>
    6008:	a9465bf5 	ldp	x21, x22, [sp, #96]
    600c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6010:	f94043f9 	ldr	x25, [sp, #128]
    6014:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6018:	f947f400 	ldr	x0, [x0, #4072]
    601c:	f9401fe2 	ldr	x2, [sp, #56]
    6020:	f9400001 	ldr	x1, [x0]
    6024:	eb010042 	subs	x2, x2, x1
    6028:	d2800001 	mov	x1, #0x0                   	// #0
    602c:	540000a1 	b.ne	6040 <fwp_tape_scope_release+0x130>  // b.any
    6030:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6034:	a94553f3 	ldp	x19, x20, [sp, #80]
    6038:	910243ff 	add	sp, sp, #0x90
    603c:	d65f03c0 	ret
    6040:	a9065bf5 	stp	x21, x22, [sp, #96]
    6044:	a90763f7 	stp	x23, x24, [sp, #112]
    6048:	f90043f9 	str	x25, [sp, #128]
    604c:	97fff20d 	bl	2880 <__stack_chk_fail@plt>

0000000000006050 <fwp_drop4>:
    6050:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6054:	910003fd 	mov	x29, sp
    6058:	a9025bf5 	stp	x21, x22, [sp, #32]
    605c:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xca0>
    6060:	911502d5 	add	x21, x22, #0x540
    6064:	a90153f3 	stp	x19, x20, [sp, #16]
    6068:	aa0003f3 	mov	x19, x0
    606c:	f949daa1 	ldr	x1, [x21, #5040]
    6070:	f949eea0 	ldr	x0, [x21, #5080]
    6074:	cb010261 	sub	x1, x19, x1
    6078:	eb00403f 	cmp	x1, x0, lsl #16
    607c:	54000382 	b.cs	60ec <fwp_drop4+0x9c>  // b.hs, b.nlast
    6080:	d350fc22 	lsr	x2, x1, #16
    6084:	f949fea3 	ldr	x3, [x21, #5112]
    6088:	8b020842 	add	x2, x2, x2, lsl #2
    608c:	d37df042 	lsl	x2, x2, #3
    6090:	8b020060 	add	x0, x3, x2
    6094:	f9401014 	ldr	x20, [x0, #32]
    6098:	b40002b4 	cbz	x20, 60ec <fwp_drop4+0x9c>
    609c:	38626862 	ldrb	w2, [x3, x2]
    60a0:	7100085f 	cmp	w2, #0x2
    60a4:	540002c0 	b.eq	60fc <fwp_drop4+0xac>  // b.none
    60a8:	7100045f 	cmp	w2, #0x1
    60ac:	54000201 	b.ne	60ec <fwp_drop4+0x9c>  // b.any
    60b0:	29430002 	ldp	w2, w0, [x0, #24]
    60b4:	92403c21 	and	x1, x1, #0xffff
    60b8:	9b027c21 	mul	x1, x1, x2
    60bc:	d360fc21 	lsr	x1, x1, #32
    60c0:	eb00003f 	cmp	x1, x0
    60c4:	54000142 	b.cs	60ec <fwp_drop4+0x9c>  // b.hs, b.nlast
    60c8:	8b010294 	add	x20, x20, x1
    60cc:	39400280 	ldrb	w0, [x20]
    60d0:	340000e0 	cbz	w0, 60ec <fwp_drop4+0x9c>
    60d4:	7100041f 	cmp	w0, #0x1
    60d8:	540001e0 	b.eq	6114 <fwp_drop4+0xc4>  // b.none
    60dc:	7103fc1f 	cmp	w0, #0xff
    60e0:	540007c0 	b.eq	61d8 <fwp_drop4+0x188>  // b.none
    60e4:	51000400 	sub	w0, w0, #0x1
    60e8:	39000280 	strb	w0, [x20]
    60ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    60f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    60f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    60f8:	d65f03c0 	ret
    60fc:	72003c3f 	tst	w1, #0xffff
    6100:	54fffe60 	b.eq	60cc <fwp_drop4+0x7c>  // b.none
    6104:	a94153f3 	ldp	x19, x20, [sp, #16]
    6108:	a9425bf5 	ldp	x21, x22, [sp, #32]
    610c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6110:	d65f03c0 	ret
    6114:	911502c2 	add	x2, x22, #0x540
    6118:	f9400660 	ldr	x0, [x19, #8]
    611c:	f949d841 	ldr	x1, [x2, #5040]
    6120:	f949ec42 	ldr	x2, [x2, #5080]
    6124:	cb010001 	sub	x1, x0, x1
    6128:	eb02403f 	cmp	x1, x2, lsl #16
    612c:	54000362 	b.cs	6198 <fwp_drop4+0x148>  // b.hs, b.nlast
    6130:	d350fc22 	lsr	x2, x1, #16
    6134:	8b020842 	add	x2, x2, x2, lsl #2
    6138:	d37df042 	lsl	x2, x2, #3
    613c:	8b020064 	add	x4, x3, x2
    6140:	f9401094 	ldr	x20, [x4, #32]
    6144:	b40002b4 	cbz	x20, 6198 <fwp_drop4+0x148>
    6148:	38626862 	ldrb	w2, [x3, x2]
    614c:	7100085f 	cmp	w2, #0x2
    6150:	540003e0 	b.eq	61cc <fwp_drop4+0x17c>  // b.none
    6154:	7100045f 	cmp	w2, #0x1
    6158:	54000201 	b.ne	6198 <fwp_drop4+0x148>  // b.any
    615c:	29430883 	ldp	w3, w2, [x4, #24]
    6160:	92403c21 	and	x1, x1, #0xffff
    6164:	9b037c21 	mul	x1, x1, x3
    6168:	d360fc21 	lsr	x1, x1, #32
    616c:	eb02003f 	cmp	x1, x2
    6170:	54000142 	b.cs	6198 <fwp_drop4+0x148>  // b.hs, b.nlast
    6174:	8b010294 	add	x20, x20, x1
    6178:	39400281 	ldrb	w1, [x20]
    617c:	340000e1 	cbz	w1, 6198 <fwp_drop4+0x148>
    6180:	7100043f 	cmp	w1, #0x1
    6184:	54000200 	b.eq	61c4 <fwp_drop4+0x174>  // b.none
    6188:	7103fc3f 	cmp	w1, #0xff
    618c:	54000580 	b.eq	623c <fwp_drop4+0x1ec>  // b.none
    6190:	51000421 	sub	w1, w1, #0x1
    6194:	39000281 	strb	w1, [x20]
    6198:	f9400a74 	ldr	x20, [x19, #16]
    619c:	aa1303e0 	mov	x0, x19
    61a0:	97fffd00 	bl	55a0 <fwp_rc_free_arr>
    61a4:	911502c0 	add	x0, x22, #0x540
    61a8:	f949d801 	ldr	x1, [x0, #5040]
    61ac:	f949ec00 	ldr	x0, [x0, #5080]
    61b0:	cb010281 	sub	x1, x20, x1
    61b4:	eb00403f 	cmp	x1, x0, lsl #16
    61b8:	54fff9a2 	b.cs	60ec <fwp_drop4+0x9c>  // b.hs, b.nlast
    61bc:	aa1403f3 	mov	x19, x20
    61c0:	17ffffb0 	b	6080 <fwp_drop4+0x30>
    61c4:	97fffcf7 	bl	55a0 <fwp_rc_free_arr>
    61c8:	17fffff4 	b	6198 <fwp_drop4+0x148>
    61cc:	72003c3f 	tst	w1, #0xffff
    61d0:	54fffe41 	b.ne	6198 <fwp_drop4+0x148>  // b.any
    61d4:	17ffffe9 	b	6178 <fwp_drop4+0x128>
    61d8:	ca544681 	eor	x1, x20, x20, lsr #17
    61dc:	911502c0 	add	x0, x22, #0x540
    61e0:	ca412421 	eor	x1, x1, x1, lsr #9
    61e4:	8b210c01 	add	x1, x0, w1, uxtb #3
    61e8:	f94a2420 	ldr	x0, [x1, #5192]
    61ec:	b5000080 	cbnz	x0, 61fc <fwp_drop4+0x1ac>
    61f0:	14000010 	b	6230 <fwp_drop4+0x1e0>
    61f4:	f9400800 	ldr	x0, [x0, #16]
    61f8:	b40001c0 	cbz	x0, 6230 <fwp_drop4+0x1e0>
    61fc:	f9400001 	ldr	x1, [x0]
    6200:	eb14003f 	cmp	x1, x20
    6204:	54ffff81 	b.ne	61f4 <fwp_drop4+0x1a4>  // b.any
    6208:	f9400401 	ldr	x1, [x0, #8]
    620c:	d1000421 	sub	x1, x1, #0x1
    6210:	f9000401 	str	x1, [x0, #8]
    6214:	f103f83f 	cmp	x1, #0xfe
    6218:	54fff6a1 	b.ne	60ec <fwp_drop4+0x9c>  // b.any
    621c:	aa1403e0 	mov	x0, x20
    6220:	97fff8d4 	bl	4570 <fwp_rc_forget_slot>
    6224:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6228:	39000280 	strb	w0, [x20]
    622c:	17ffffb0 	b	60ec <fwp_drop4+0x9c>
    6230:	d0000020 	adrp	x0, c000 <f0+0x2630>
    6234:	913d6000 	add	x0, x0, #0xf58
    6238:	97fff4d2 	bl	3580 <fwp_trap>
    623c:	ca544680 	eor	x0, x20, x20, lsr #17
    6240:	911502c1 	add	x1, x22, #0x540
    6244:	ca402400 	eor	x0, x0, x0, lsr #9
    6248:	8b200c20 	add	x0, x1, w0, uxtb #3
    624c:	f94a2400 	ldr	x0, [x0, #5192]
    6250:	b5000080 	cbnz	x0, 6260 <fwp_drop4+0x210>
    6254:	17fffff7 	b	6230 <fwp_drop4+0x1e0>
    6258:	f9400800 	ldr	x0, [x0, #16]
    625c:	b4fffea0 	cbz	x0, 6230 <fwp_drop4+0x1e0>
    6260:	f9400001 	ldr	x1, [x0]
    6264:	eb14003f 	cmp	x1, x20
    6268:	54ffff81 	b.ne	6258 <fwp_drop4+0x208>  // b.any
    626c:	f9400401 	ldr	x1, [x0, #8]
    6270:	d1000421 	sub	x1, x1, #0x1
    6274:	f9000401 	str	x1, [x0, #8]
    6278:	f103f83f 	cmp	x1, #0xfe
    627c:	54fff8e1 	b.ne	6198 <fwp_drop4+0x148>  // b.any
    6280:	aa1403e0 	mov	x0, x20
    6284:	97fff8bb 	bl	4570 <fwp_rc_forget_slot>
    6288:	12800020 	mov	w0, #0xfffffffe            	// #-2
    628c:	39000280 	strb	w0, [x20]
    6290:	17ffffc2 	b	6198 <fwp_drop4+0x148>

0000000000006294 <fwp_arg_drop37>:
    6294:	7100003f 	cmp	w1, #0x0
    6298:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    629c:	54000041 	b.ne	62a4 <fwp_arg_drop37+0x10>  // b.any
    62a0:	d65f03c0 	ret
    62a4:	f9400000 	ldr	x0, [x0]
    62a8:	17ffff6a 	b	6050 <fwp_drop4>
    62ac:	d503201f 	nop

00000000000062b0 <fwp_task_dispose>:
    62b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    62b4:	910003fd 	mov	x29, sp
    62b8:	f9000bf3 	str	x19, [sp, #16]
    62bc:	aa0003f3 	mov	x19, x0
    62c0:	39414000 	ldrb	w0, [x0, #80]
    62c4:	36000720 	tbz	w0, #0, 63a8 <fwp_task_dispose+0xf8>
    62c8:	f9400a60 	ldr	x0, [x19, #16]
    62cc:	b50006e0 	cbnz	x0, 63a8 <fwp_task_dispose+0xf8>
    62d0:	a9478660 	ldp	x0, x1, [x19, #120]
    62d4:	39014e7f 	strb	wzr, [x19, #83]
    62d8:	f9003e7f 	str	xzr, [x19, #120]
    62dc:	f100003f 	cmp	x1, #0x0
    62e0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    62e4:	54000040 	b.eq	62ec <fwp_task_dispose+0x3c>  // b.none
    62e8:	d63f0020 	blr	x1
    62ec:	f9405660 	ldr	x0, [x19, #168]
    62f0:	97fff940 	bl	47f0 <fwp_mem_free>
    62f4:	f900567f 	str	xzr, [x19, #168]
    62f8:	b9405e60 	ldr	w0, [x19, #92]
    62fc:	7100041f 	cmp	w0, #0x1
    6300:	54000420 	b.eq	6384 <fwp_task_dispose+0xd4>  // b.none
    6304:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6308:	91150042 	add	x2, x2, #0x540
    630c:	f949d840 	ldr	x0, [x2, #5040]
    6310:	f949ec41 	ldr	x1, [x2, #5080]
    6314:	cb000260 	sub	x0, x19, x0
    6318:	eb01401f 	cmp	x0, x1, lsl #16
    631c:	540002e2 	b.cs	6378 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6320:	d350fc01 	lsr	x1, x0, #16
    6324:	f949fc44 	ldr	x4, [x2, #5112]
    6328:	8b010821 	add	x1, x1, x1, lsl #2
    632c:	d37df021 	lsl	x1, x1, #3
    6330:	8b010083 	add	x3, x4, x1
    6334:	f9401062 	ldr	x2, [x3, #32]
    6338:	b4000202 	cbz	x2, 6378 <fwp_task_dispose+0xc8>
    633c:	38616881 	ldrb	w1, [x4, x1]
    6340:	7100083f 	cmp	w1, #0x2
    6344:	54000280 	b.eq	6394 <fwp_task_dispose+0xe4>  // b.none
    6348:	7100043f 	cmp	w1, #0x1
    634c:	54000161 	b.ne	6378 <fwp_task_dispose+0xc8>  // b.any
    6350:	29430464 	ldp	w4, w1, [x3, #24]
    6354:	92403c00 	and	x0, x0, #0xffff
    6358:	9b047c00 	mul	x0, x0, x4
    635c:	d360fc00 	lsr	x0, x0, #32
    6360:	eb01001f 	cmp	x0, x1
    6364:	540000a2 	b.cs	6378 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6368:	8b000042 	add	x2, x2, x0
    636c:	39400040 	ldrb	w0, [x2]
    6370:	7100041f 	cmp	w0, #0x1
    6374:	54000080 	b.eq	6384 <fwp_task_dispose+0xd4>  // b.none
    6378:	f9400bf3 	ldr	x19, [sp, #16]
    637c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6380:	d65f03c0 	ret
    6384:	aa1303e0 	mov	x0, x19
    6388:	f9400bf3 	ldr	x19, [sp, #16]
    638c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6390:	17fff918 	b	47f0 <fwp_mem_free>
    6394:	72003c1f 	tst	w0, #0xffff
    6398:	54fffea0 	b.eq	636c <fwp_task_dispose+0xbc>  // b.none
    639c:	f9400bf3 	ldr	x19, [sp, #16]
    63a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    63a4:	d65f03c0 	ret
    63a8:	97fff14a 	bl	28d0 <abort@plt>
    63ac:	d503201f 	nop

00000000000063b0 <fwp_free_zombie>:
    63b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    63b4:	910003fd 	mov	x29, sp
    63b8:	a90153f3 	stp	x19, x20, [sp, #16]
    63bc:	d00000d4 	adrp	x20, 20000 <__data_start>
    63c0:	9100c281 	add	x1, x20, #0x30
    63c4:	f9405033 	ldr	x19, [x1, #160]
    63c8:	b4000333 	cbz	x19, 642c <fwp_free_zombie+0x7c>
    63cc:	f9400820 	ldr	x0, [x1, #16]
    63d0:	eb00027f 	cmp	x19, x0
    63d4:	540002c0 	b.eq	642c <fwp_free_zombie+0x7c>  // b.none
    63d8:	b940a822 	ldr	w2, [x1, #168]
    63dc:	f9400a60 	ldr	x0, [x19, #16]
    63e0:	7100fc5f 	cmp	w2, #0x3f
    63e4:	5400078c 	b.gt	64d4 <fwp_free_zombie+0x124>
    63e8:	9102c023 	add	x3, x1, #0xb0
    63ec:	11000444 	add	w4, w2, #0x1
    63f0:	b900a824 	str	w4, [x1, #168]
    63f4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    63f8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    63fc:	a9530261 	ldp	x1, x0, [x19, #304]
    6400:	b4000741 	cbz	x1, 64e8 <fwp_free_zombie+0x138>
    6404:	f9009c20 	str	x0, [x1, #312]
    6408:	b4000040 	cbz	x0, 6410 <fwp_free_zombie+0x60>
    640c:	f9009801 	str	x1, [x0, #304]
    6410:	9100c294 	add	x20, x20, #0x30
    6414:	b9405e60 	ldr	w0, [x19, #92]
    6418:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    641c:	f900529f 	str	xzr, [x20, #160]
    6420:	34000140 	cbz	w0, 6448 <fwp_free_zombie+0x98>
    6424:	7100041f 	cmp	w0, #0x1
    6428:	54000080 	b.eq	6438 <fwp_free_zombie+0x88>  // b.none
    642c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6430:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6434:	d65f03c0 	ret
    6438:	aa1303e0 	mov	x0, x19
    643c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6440:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6444:	17ffff9b 	b	62b0 <fwp_task_dispose>
    6448:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xca0>
    644c:	91150082 	add	x2, x4, #0x540
    6450:	f949d841 	ldr	x1, [x2, #5040]
    6454:	f949ec40 	ldr	x0, [x2, #5080]
    6458:	cb010261 	sub	x1, x19, x1
    645c:	eb00403f 	cmp	x1, x0, lsl #16
    6460:	54fffe62 	b.cs	642c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6464:	d350fc20 	lsr	x0, x1, #16
    6468:	f949fc43 	ldr	x3, [x2, #5112]
    646c:	8b000800 	add	x0, x0, x0, lsl #2
    6470:	d37df000 	lsl	x0, x0, #3
    6474:	8b000062 	add	x2, x3, x0
    6478:	f9401054 	ldr	x20, [x2, #32]
    647c:	b4fffd94 	cbz	x20, 642c <fwp_free_zombie+0x7c>
    6480:	38606860 	ldrb	w0, [x3, x0]
    6484:	7100081f 	cmp	w0, #0x2
    6488:	54000360 	b.eq	64f4 <fwp_free_zombie+0x144>  // b.none
    648c:	7100041f 	cmp	w0, #0x1
    6490:	54fffce1 	b.ne	642c <fwp_free_zombie+0x7c>  // b.any
    6494:	29430043 	ldp	w3, w0, [x2, #24]
    6498:	92403c21 	and	x1, x1, #0xffff
    649c:	9b037c21 	mul	x1, x1, x3
    64a0:	d360fc21 	lsr	x1, x1, #32
    64a4:	eb00003f 	cmp	x1, x0
    64a8:	54fffc22 	b.cs	642c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    64ac:	8b010294 	add	x20, x20, x1
    64b0:	39400280 	ldrb	w0, [x20]
    64b4:	34fffbc0 	cbz	w0, 642c <fwp_free_zombie+0x7c>
    64b8:	7100041f 	cmp	w0, #0x1
    64bc:	54fffbe0 	b.eq	6438 <fwp_free_zombie+0x88>  // b.none
    64c0:	7103fc1f 	cmp	w0, #0xff
    64c4:	540001e0 	b.eq	6500 <fwp_free_zombie+0x150>  // b.none
    64c8:	51000400 	sub	w0, w0, #0x1
    64cc:	39000280 	strb	w0, [x20]
    64d0:	17ffffd7 	b	642c <fwp_free_zombie+0x7c>
    64d4:	f9400e61 	ldr	x1, [x19, #24]
    64d8:	97fff132 	bl	29a0 <munmap@plt>
    64dc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    64e0:	a9530261 	ldp	x1, x0, [x19, #304]
    64e4:	b5fff901 	cbnz	x1, 6404 <fwp_free_zombie+0x54>
    64e8:	9100c282 	add	x2, x20, #0x30
    64ec:	f9015840 	str	x0, [x2, #688]
    64f0:	17ffffc6 	b	6408 <fwp_free_zombie+0x58>
    64f4:	72003c3f 	tst	w1, #0xffff
    64f8:	54fff9a1 	b.ne	642c <fwp_free_zombie+0x7c>  // b.any
    64fc:	17ffffed 	b	64b0 <fwp_free_zombie+0x100>
    6500:	ca544680 	eor	x0, x20, x20, lsr #17
    6504:	91150084 	add	x4, x4, #0x540
    6508:	ca402400 	eor	x0, x0, x0, lsr #9
    650c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6510:	f94a2400 	ldr	x0, [x0, #5192]
    6514:	b5000080 	cbnz	x0, 6524 <fwp_free_zombie+0x174>
    6518:	14000010 	b	6558 <fwp_free_zombie+0x1a8>
    651c:	f9400800 	ldr	x0, [x0, #16]
    6520:	b40001c0 	cbz	x0, 6558 <fwp_free_zombie+0x1a8>
    6524:	f9400001 	ldr	x1, [x0]
    6528:	eb14003f 	cmp	x1, x20
    652c:	54ffff81 	b.ne	651c <fwp_free_zombie+0x16c>  // b.any
    6530:	f9400401 	ldr	x1, [x0, #8]
    6534:	d1000421 	sub	x1, x1, #0x1
    6538:	f9000401 	str	x1, [x0, #8]
    653c:	f103f83f 	cmp	x1, #0xfe
    6540:	54fff761 	b.ne	642c <fwp_free_zombie+0x7c>  // b.any
    6544:	aa1403e0 	mov	x0, x20
    6548:	97fff80a 	bl	4570 <fwp_rc_forget_slot>
    654c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6550:	39000280 	strb	w0, [x20]
    6554:	17ffffb6 	b	642c <fwp_free_zombie+0x7c>
    6558:	d0000020 	adrp	x0, c000 <f0+0x2630>
    655c:	913d6000 	add	x0, x0, #0xf58
    6560:	97fff408 	bl	3580 <fwp_trap>

0000000000006564 <fwp_block>:
    6564:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6568:	910003fd 	mov	x29, sp
    656c:	a90153f3 	stp	x19, x20, [sp, #16]
    6570:	d00000d3 	adrp	x19, 20000 <__data_start>
    6574:	9100c274 	add	x20, x19, #0x30
    6578:	f9401a82 	ldr	x2, [x20, #48]
    657c:	b4000622 	cbz	x2, 6640 <fwp_block+0xdc>
    6580:	9100c261 	add	x1, x19, #0x30
    6584:	f9408040 	ldr	x0, [x2, #256]
    6588:	f9001820 	str	x0, [x1, #48]
    658c:	b4000680 	cbz	x0, 665c <fwp_block+0xf8>
    6590:	9100c263 	add	x3, x19, #0x30
    6594:	3901505f 	strb	wzr, [x2, #84]
    6598:	f9400864 	ldr	x4, [x3, #16]
    659c:	eb02009f 	cmp	x4, x2
    65a0:	54000440 	b.eq	6628 <fwp_block+0xc4>  // b.none
    65a4:	f9415c65 	ldr	x5, [x3, #696]
    65a8:	f9000862 	str	x2, [x3, #16]
    65ac:	f9400441 	ldr	x1, [x2, #8]
    65b0:	f9004885 	str	x5, [x4, #144]
    65b4:	f9416065 	ldr	x5, [x3, #704]
    65b8:	f9004c85 	str	x5, [x4, #152]
    65bc:	f9416465 	ldr	x5, [x3, #712]
    65c0:	f9005085 	str	x5, [x4, #160]
    65c4:	f9416865 	ldr	x5, [x3, #720]
    65c8:	f9005485 	str	x5, [x4, #168]
    65cc:	f9416c65 	ldr	x5, [x3, #728]
    65d0:	f9005885 	str	x5, [x4, #176]
    65d4:	f9417065 	ldr	x5, [x3, #736]
    65d8:	f9005c85 	str	x5, [x4, #184]
    65dc:	f9417465 	ldr	x5, [x3, #744]
    65e0:	f9006085 	str	x5, [x4, #192]
    65e4:	f9400480 	ldr	x0, [x4, #8]
    65e8:	f9404844 	ldr	x4, [x2, #144]
    65ec:	f9015c64 	str	x4, [x3, #696]
    65f0:	f9404c44 	ldr	x4, [x2, #152]
    65f4:	f9016064 	str	x4, [x3, #704]
    65f8:	f9405044 	ldr	x4, [x2, #160]
    65fc:	f9016464 	str	x4, [x3, #712]
    6600:	f9405444 	ldr	x4, [x2, #168]
    6604:	f9016864 	str	x4, [x3, #720]
    6608:	f9405844 	ldr	x4, [x2, #176]
    660c:	f9016c64 	str	x4, [x3, #728]
    6610:	a94b8844 	ldp	x4, x2, [x2, #184]
    6614:	f9017064 	str	x4, [x3, #736]
    6618:	f9017462 	str	x2, [x3, #744]
    661c:	97fff0b1 	bl	28e0 <swapcontext@plt>
    6620:	97ffff64 	bl	63b0 <fwp_free_zombie>
    6624:	d503201f 	nop
    6628:	9100c260 	add	x0, x19, #0x30
    662c:	b942f000 	ldr	w0, [x0, #752]
    6630:	340001a0 	cbz	w0, 6664 <fwp_block+0x100>
    6634:	a94153f3 	ldp	x19, x20, [sp, #16]
    6638:	a8c27bfd 	ldp	x29, x30, [sp], #32
    663c:	d65f03c0 	ret
    6640:	97fff6f8 	bl	4220 <fwp_poll_events>
    6644:	f9401a82 	ldr	x2, [x20, #48]
    6648:	b4ffffc2 	cbz	x2, 6640 <fwp_block+0xdc>
    664c:	9100c261 	add	x1, x19, #0x30
    6650:	f9408040 	ldr	x0, [x2, #256]
    6654:	f9001820 	str	x0, [x1, #48]
    6658:	b5fff9c0 	cbnz	x0, 6590 <fwp_block+0x2c>
    665c:	f900143f 	str	xzr, [x1, #40]
    6660:	17ffffcc 	b	6590 <fwp_block+0x2c>
    6664:	f0000020 	adrp	x0, d000 <_IO_stdin_used+0x350>
    6668:	91022000 	add	x0, x0, #0x88
    666c:	97fff0e9 	bl	2a10 <getenv@plt>
    6670:	5284e202 	mov	w2, #0x2710                	// #10000
    6674:	b4000060 	cbz	x0, 6680 <fwp_block+0x11c>
    6678:	39400001 	ldrb	w1, [x0]
    667c:	350000c1 	cbnz	w1, 6694 <fwp_block+0x130>
    6680:	9100c273 	add	x19, x19, #0x30
    6684:	b902f262 	str	w2, [x19, #752]
    6688:	a94153f3 	ldp	x19, x20, [sp, #16]
    668c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6690:	d65f03c0 	ret
    6694:	52800142 	mov	w2, #0xa                   	// #10
    6698:	d2800001 	mov	x1, #0x0                   	// #0
    669c:	97fff02d 	bl	2750 <strtoll@plt>
    66a0:	d1000403 	sub	x3, x0, #0x1
    66a4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    66a8:	eb02007f 	cmp	x3, x2
    66ac:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    66b0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    66b4:	17fffff3 	b	6680 <fwp_block+0x11c>
    66b8:	d503201f 	nop
    66bc:	d503201f 	nop

00000000000066c0 <fwp_drop10>:
    66c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    66c4:	910003fd 	mov	x29, sp
    66c8:	a90153f3 	stp	x19, x20, [sp, #16]
    66cc:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xca0>
    66d0:	f90013f5 	str	x21, [sp, #32]
    66d4:	91150275 	add	x21, x19, #0x540
    66d8:	f949daa1 	ldr	x1, [x21, #5040]
    66dc:	f949eea2 	ldr	x2, [x21, #5080]
    66e0:	cb010001 	sub	x1, x0, x1
    66e4:	eb02403f 	cmp	x1, x2, lsl #16
    66e8:	54000382 	b.cs	6758 <fwp_drop10+0x98>  // b.hs, b.nlast
    66ec:	d350fc22 	lsr	x2, x1, #16
    66f0:	f949fea3 	ldr	x3, [x21, #5112]
    66f4:	8b020842 	add	x2, x2, x2, lsl #2
    66f8:	d37df042 	lsl	x2, x2, #3
    66fc:	8b020064 	add	x4, x3, x2
    6700:	f9401094 	ldr	x20, [x4, #32]
    6704:	b40002b4 	cbz	x20, 6758 <fwp_drop10+0x98>
    6708:	38626862 	ldrb	w2, [x3, x2]
    670c:	7100085f 	cmp	w2, #0x2
    6710:	540007a0 	b.eq	6804 <fwp_drop10+0x144>  // b.none
    6714:	7100045f 	cmp	w2, #0x1
    6718:	54000201 	b.ne	6758 <fwp_drop10+0x98>  // b.any
    671c:	29430885 	ldp	w5, w2, [x4, #24]
    6720:	92403c21 	and	x1, x1, #0xffff
    6724:	9b057c21 	mul	x1, x1, x5
    6728:	d360fc21 	lsr	x1, x1, #32
    672c:	eb02003f 	cmp	x1, x2
    6730:	54000142 	b.cs	6758 <fwp_drop10+0x98>  // b.hs, b.nlast
    6734:	8b010294 	add	x20, x20, x1
    6738:	39400281 	ldrb	w1, [x20]
    673c:	340000e1 	cbz	w1, 6758 <fwp_drop10+0x98>
    6740:	7100043f 	cmp	w1, #0x1
    6744:	54000120 	b.eq	6768 <fwp_drop10+0xa8>  // b.none
    6748:	7103fc3f 	cmp	w1, #0xff
    674c:	540007c0 	b.eq	6844 <fwp_drop10+0x184>  // b.none
    6750:	51000421 	sub	w1, w1, #0x1
    6754:	39000281 	strb	w1, [x20]
    6758:	a94153f3 	ldp	x19, x20, [sp, #16]
    675c:	f94013f5 	ldr	x21, [sp, #32]
    6760:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6764:	d65f03c0 	ret
    6768:	f9400001 	ldr	x1, [x0]
    676c:	b7f80581 	tbnz	x1, #63, 681c <fwp_drop10+0x15c>
    6770:	91150273 	add	x19, x19, #0x540
    6774:	f949da61 	ldr	x1, [x19, #5040]
    6778:	f949ee62 	ldr	x2, [x19, #5080]
    677c:	cb010001 	sub	x1, x0, x1
    6780:	eb02403f 	cmp	x1, x2, lsl #16
    6784:	54fffea2 	b.cs	6758 <fwp_drop10+0x98>  // b.hs, b.nlast
    6788:	d350fc22 	lsr	x2, x1, #16
    678c:	8b020842 	add	x2, x2, x2, lsl #2
    6790:	d37df042 	lsl	x2, x2, #3
    6794:	8b020065 	add	x5, x3, x2
    6798:	f94010a4 	ldr	x4, [x5, #32]
    679c:	b4fffde4 	cbz	x4, 6758 <fwp_drop10+0x98>
    67a0:	38626862 	ldrb	w2, [x3, x2]
    67a4:	7100085f 	cmp	w2, #0x2
    67a8:	54000220 	b.eq	67ec <fwp_drop10+0x12c>  // b.none
    67ac:	7100045f 	cmp	w2, #0x1
    67b0:	54fffd41 	b.ne	6758 <fwp_drop10+0x98>  // b.any
    67b4:	294308a3 	ldp	w3, w2, [x5, #24]
    67b8:	92403c21 	and	x1, x1, #0xffff
    67bc:	9b037c21 	mul	x1, x1, x3
    67c0:	d360fc21 	lsr	x1, x1, #32
    67c4:	eb02003f 	cmp	x1, x2
    67c8:	54fffc82 	b.cs	6758 <fwp_drop10+0x98>  // b.hs, b.nlast
    67cc:	8b010084 	add	x4, x4, x1
    67d0:	39400081 	ldrb	w1, [x4]
    67d4:	7100043f 	cmp	w1, #0x1
    67d8:	54fffc01 	b.ne	6758 <fwp_drop10+0x98>  // b.any
    67dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    67e0:	f94013f5 	ldr	x21, [sp, #32]
    67e4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    67e8:	17fff802 	b	47f0 <fwp_mem_free>
    67ec:	72003c3f 	tst	w1, #0xffff
    67f0:	54ffff00 	b.eq	67d0 <fwp_drop10+0x110>  // b.none
    67f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    67f8:	f94013f5 	ldr	x21, [sp, #32]
    67fc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6800:	d65f03c0 	ret
    6804:	72003c3f 	tst	w1, #0xffff
    6808:	54fff980 	b.eq	6738 <fwp_drop10+0x78>  // b.none
    680c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6810:	f94013f5 	ldr	x21, [sp, #32]
    6814:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6818:	d65f03c0 	ret
    681c:	f9400414 	ldr	x20, [x0, #8]
    6820:	97fffb60 	bl	55a0 <fwp_rc_free_arr>
    6824:	91150260 	add	x0, x19, #0x540
    6828:	f949d801 	ldr	x1, [x0, #5040]
    682c:	f949ec00 	ldr	x0, [x0, #5080]
    6830:	cb010281 	sub	x1, x20, x1
    6834:	eb00403f 	cmp	x1, x0, lsl #16
    6838:	54fff902 	b.cs	6758 <fwp_drop10+0x98>  // b.hs, b.nlast
    683c:	aa1403e0 	mov	x0, x20
    6840:	17ffffab 	b	66ec <fwp_drop10+0x2c>
    6844:	ca544680 	eor	x0, x20, x20, lsr #17
    6848:	91150273 	add	x19, x19, #0x540
    684c:	ca402400 	eor	x0, x0, x0, lsr #9
    6850:	8b200e60 	add	x0, x19, w0, uxtb #3
    6854:	f94a2400 	ldr	x0, [x0, #5192]
    6858:	b5000080 	cbnz	x0, 6868 <fwp_drop10+0x1a8>
    685c:	14000010 	b	689c <fwp_drop10+0x1dc>
    6860:	f9400800 	ldr	x0, [x0, #16]
    6864:	b40001c0 	cbz	x0, 689c <fwp_drop10+0x1dc>
    6868:	f9400001 	ldr	x1, [x0]
    686c:	eb14003f 	cmp	x1, x20
    6870:	54ffff81 	b.ne	6860 <fwp_drop10+0x1a0>  // b.any
    6874:	f9400401 	ldr	x1, [x0, #8]
    6878:	d1000421 	sub	x1, x1, #0x1
    687c:	f9000401 	str	x1, [x0, #8]
    6880:	f103f83f 	cmp	x1, #0xfe
    6884:	54fff6a1 	b.ne	6758 <fwp_drop10+0x98>  // b.any
    6888:	aa1403e0 	mov	x0, x20
    688c:	97fff739 	bl	4570 <fwp_rc_forget_slot>
    6890:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6894:	39000280 	strb	w0, [x20]
    6898:	17ffffb0 	b	6758 <fwp_drop10+0x98>
    689c:	d0000020 	adrp	x0, c000 <f0+0x2630>
    68a0:	913d6000 	add	x0, x0, #0xf58
    68a4:	97fff337 	bl	3580 <fwp_trap>
    68a8:	d503201f 	nop
    68ac:	d503201f 	nop

00000000000068b0 <fwp_caps173>:
    68b0:	34000041 	cbz	w1, 68b8 <fwp_caps173+0x8>
    68b4:	d65f03c0 	ret
    68b8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xca0>
    68bc:	91150063 	add	x3, x3, #0x540
    68c0:	f949d861 	ldr	x1, [x3, #5040]
    68c4:	f949ec62 	ldr	x2, [x3, #5080]
    68c8:	cb010001 	sub	x1, x0, x1
    68cc:	eb02403f 	cmp	x1, x2, lsl #16
    68d0:	54ffff22 	b.cs	68b4 <fwp_caps173+0x4>  // b.hs, b.nlast
    68d4:	d350fc22 	lsr	x2, x1, #16
    68d8:	f949fc65 	ldr	x5, [x3, #5112]
    68dc:	8b020842 	add	x2, x2, x2, lsl #2
    68e0:	d37df042 	lsl	x2, x2, #3
    68e4:	8b0200a4 	add	x4, x5, x2
    68e8:	f9401083 	ldr	x3, [x4, #32]
    68ec:	b4fffe43 	cbz	x3, 68b4 <fwp_caps173+0x4>
    68f0:	386268a2 	ldrb	w2, [x5, x2]
    68f4:	7100085f 	cmp	w2, #0x2
    68f8:	540001c0 	b.eq	6930 <fwp_caps173+0x80>  // b.none
    68fc:	7100045f 	cmp	w2, #0x1
    6900:	54fffda1 	b.ne	68b4 <fwp_caps173+0x4>  // b.any
    6904:	29430885 	ldp	w5, w2, [x4, #24]
    6908:	92403c21 	and	x1, x1, #0xffff
    690c:	9b057c21 	mul	x1, x1, x5
    6910:	d360fc21 	lsr	x1, x1, #32
    6914:	eb02003f 	cmp	x1, x2
    6918:	54fffce2 	b.cs	68b4 <fwp_caps173+0x4>  // b.hs, b.nlast
    691c:	8b010063 	add	x3, x3, x1
    6920:	39400061 	ldrb	w1, [x3]
    6924:	7100043f 	cmp	w1, #0x1
    6928:	54fffc61 	b.ne	68b4 <fwp_caps173+0x4>  // b.any
    692c:	17fff7b1 	b	47f0 <fwp_mem_free>
    6930:	72003c3f 	tst	w1, #0xffff
    6934:	54ffff60 	b.eq	6920 <fwp_caps173+0x70>  // b.none
    6938:	d65f03c0 	ret
    693c:	d503201f 	nop

0000000000006940 <fwp_args37>:
    6940:	7100003f 	cmp	w1, #0x0
    6944:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6948:	54000041 	b.ne	6950 <fwp_args37+0x10>  // b.any
    694c:	d65f03c0 	ret
    6950:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6954:	91150042 	add	x2, x2, #0x540
    6958:	f9400001 	ldr	x1, [x0]
    695c:	f949d843 	ldr	x3, [x2, #5040]
    6960:	f949ec40 	ldr	x0, [x2, #5080]
    6964:	cb030021 	sub	x1, x1, x3
    6968:	eb00403f 	cmp	x1, x0, lsl #16
    696c:	54ffff02 	b.cs	694c <fwp_args37+0xc>  // b.hs, b.nlast
    6970:	d350fc20 	lsr	x0, x1, #16
    6974:	f949fc44 	ldr	x4, [x2, #5112]
    6978:	8b000800 	add	x0, x0, x0, lsl #2
    697c:	d37df002 	lsl	x2, x0, #3
    6980:	8b020083 	add	x3, x4, x2
    6984:	f9401060 	ldr	x0, [x3, #32]
    6988:	b4fffe20 	cbz	x0, 694c <fwp_args37+0xc>
    698c:	38626882 	ldrb	w2, [x4, x2]
    6990:	7100085f 	cmp	w2, #0x2
    6994:	54000220 	b.eq	69d8 <fwp_args37+0x98>  // b.none
    6998:	7100045f 	cmp	w2, #0x1
    699c:	54fffd81 	b.ne	694c <fwp_args37+0xc>  // b.any
    69a0:	29430864 	ldp	w4, w2, [x3, #24]
    69a4:	92403c21 	and	x1, x1, #0xffff
    69a8:	9b047c21 	mul	x1, x1, x4
    69ac:	d360fc21 	lsr	x1, x1, #32
    69b0:	eb02003f 	cmp	x1, x2
    69b4:	54fffcc2 	b.cs	694c <fwp_args37+0xc>  // b.hs, b.nlast
    69b8:	8b010000 	add	x0, x0, x1
    69bc:	39400001 	ldrb	w1, [x0]
    69c0:	34fffc61 	cbz	w1, 694c <fwp_args37+0xc>
    69c4:	7103f43f 	cmp	w1, #0xfd
    69c8:	540000e8 	b.hi	69e4 <fwp_args37+0xa4>  // b.pmore
    69cc:	11000421 	add	w1, w1, #0x1
    69d0:	39000001 	strb	w1, [x0]
    69d4:	d65f03c0 	ret
    69d8:	72003c3f 	tst	w1, #0xffff
    69dc:	54ffff00 	b.eq	69bc <fwp_args37+0x7c>  // b.none
    69e0:	d65f03c0 	ret
    69e4:	17fff69c 	b	4454 <fwp_rc_wide_dup>
    69e8:	d503201f 	nop
    69ec:	d503201f 	nop

00000000000069f0 <fwp_caps37>:
    69f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    69f4:	910003fd 	mov	x29, sp
    69f8:	f9000bf3 	str	x19, [sp, #16]
    69fc:	aa0003f3 	mov	x19, x0
    6a00:	b9400400 	ldr	w0, [x0, #4]
    6a04:	340004a0 	cbz	w0, 6a98 <fwp_caps37+0xa8>
    6a08:	f9400660 	ldr	x0, [x19, #8]
    6a0c:	350004e1 	cbnz	w1, 6aa8 <fwp_caps37+0xb8>
    6a10:	97fffd90 	bl	6050 <fwp_drop4>
    6a14:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6a18:	91150042 	add	x2, x2, #0x540
    6a1c:	f949d840 	ldr	x0, [x2, #5040]
    6a20:	f949ec41 	ldr	x1, [x2, #5080]
    6a24:	cb000260 	sub	x0, x19, x0
    6a28:	eb01401f 	cmp	x0, x1, lsl #16
    6a2c:	54000382 	b.cs	6a9c <fwp_caps37+0xac>  // b.hs, b.nlast
    6a30:	d350fc01 	lsr	x1, x0, #16
    6a34:	f949fc44 	ldr	x4, [x2, #5112]
    6a38:	8b010821 	add	x1, x1, x1, lsl #2
    6a3c:	d37df021 	lsl	x1, x1, #3
    6a40:	8b010083 	add	x3, x4, x1
    6a44:	f9401062 	ldr	x2, [x3, #32]
    6a48:	b40002a2 	cbz	x2, 6a9c <fwp_caps37+0xac>
    6a4c:	38616881 	ldrb	w1, [x4, x1]
    6a50:	7100083f 	cmp	w1, #0x2
    6a54:	540006c0 	b.eq	6b2c <fwp_caps37+0x13c>  // b.none
    6a58:	7100043f 	cmp	w1, #0x1
    6a5c:	54000201 	b.ne	6a9c <fwp_caps37+0xac>  // b.any
    6a60:	29430464 	ldp	w4, w1, [x3, #24]
    6a64:	92403c00 	and	x0, x0, #0xffff
    6a68:	9b047c00 	mul	x0, x0, x4
    6a6c:	d360fc00 	lsr	x0, x0, #32
    6a70:	eb01001f 	cmp	x0, x1
    6a74:	54000142 	b.cs	6a9c <fwp_caps37+0xac>  // b.hs, b.nlast
    6a78:	8b000042 	add	x2, x2, x0
    6a7c:	39400040 	ldrb	w0, [x2]
    6a80:	7100041f 	cmp	w0, #0x1
    6a84:	540000c1 	b.ne	6a9c <fwp_caps37+0xac>  // b.any
    6a88:	aa1303e0 	mov	x0, x19
    6a8c:	f9400bf3 	ldr	x19, [sp, #16]
    6a90:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a94:	17fff757 	b	47f0 <fwp_mem_free>
    6a98:	34fffbe1 	cbz	w1, 6a14 <fwp_caps37+0x24>
    6a9c:	f9400bf3 	ldr	x19, [sp, #16]
    6aa0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6aa4:	d65f03c0 	ret
    6aa8:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6aac:	91150042 	add	x2, x2, #0x540
    6ab0:	f949d843 	ldr	x3, [x2, #5040]
    6ab4:	f949ec41 	ldr	x1, [x2, #5080]
    6ab8:	cb030000 	sub	x0, x0, x3
    6abc:	eb01401f 	cmp	x0, x1, lsl #16
    6ac0:	54fffee2 	b.cs	6a9c <fwp_caps37+0xac>  // b.hs, b.nlast
    6ac4:	d350fc01 	lsr	x1, x0, #16
    6ac8:	f949fc44 	ldr	x4, [x2, #5112]
    6acc:	8b010821 	add	x1, x1, x1, lsl #2
    6ad0:	d37df021 	lsl	x1, x1, #3
    6ad4:	8b010083 	add	x3, x4, x1
    6ad8:	f9401062 	ldr	x2, [x3, #32]
    6adc:	b4fffe02 	cbz	x2, 6a9c <fwp_caps37+0xac>
    6ae0:	38616881 	ldrb	w1, [x4, x1]
    6ae4:	7100083f 	cmp	w1, #0x2
    6ae8:	54000280 	b.eq	6b38 <fwp_caps37+0x148>  // b.none
    6aec:	7100043f 	cmp	w1, #0x1
    6af0:	54fffd61 	b.ne	6a9c <fwp_caps37+0xac>  // b.any
    6af4:	92403c01 	and	x1, x0, #0xffff
    6af8:	29430064 	ldp	w4, w0, [x3, #24]
    6afc:	9b047c21 	mul	x1, x1, x4
    6b00:	d360fc21 	lsr	x1, x1, #32
    6b04:	eb00003f 	cmp	x1, x0
    6b08:	54fffca2 	b.cs	6a9c <fwp_caps37+0xac>  // b.hs, b.nlast
    6b0c:	8b010042 	add	x2, x2, x1
    6b10:	39400040 	ldrb	w0, [x2]
    6b14:	34fffc40 	cbz	w0, 6a9c <fwp_caps37+0xac>
    6b18:	7103f41f 	cmp	w0, #0xfd
    6b1c:	54000148 	b.hi	6b44 <fwp_caps37+0x154>  // b.pmore
    6b20:	11000400 	add	w0, w0, #0x1
    6b24:	39000040 	strb	w0, [x2]
    6b28:	17ffffdd 	b	6a9c <fwp_caps37+0xac>
    6b2c:	72003c1f 	tst	w0, #0xffff
    6b30:	54fffb61 	b.ne	6a9c <fwp_caps37+0xac>  // b.any
    6b34:	17ffffd2 	b	6a7c <fwp_caps37+0x8c>
    6b38:	72003c1f 	tst	w0, #0xffff
    6b3c:	54fffb01 	b.ne	6a9c <fwp_caps37+0xac>  // b.any
    6b40:	17fffff4 	b	6b10 <fwp_caps37+0x120>
    6b44:	f9400bf3 	ldr	x19, [sp, #16]
    6b48:	aa0203e0 	mov	x0, x2
    6b4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b50:	17fff641 	b	4454 <fwp_rc_wide_dup>

0000000000006b54 <f37>:
    6b54:	d101c3ff 	sub	sp, sp, #0x70
    6b58:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6b5c:	f947f421 	ldr	x1, [x1, #4072]
    6b60:	a9027bfd 	stp	x29, x30, [sp, #32]
    6b64:	910083fd 	add	x29, sp, #0x20
    6b68:	a90563f7 	stp	x23, x24, [sp, #80]
    6b6c:	f0000157 	adrp	x23, 31000 <fwp_root_context+0xca0>
    6b70:	911502e3 	add	x3, x23, #0x540
    6b74:	a90353f3 	stp	x19, x20, [sp, #48]
    6b78:	a9045bf5 	stp	x21, x22, [sp, #64]
    6b7c:	aa0003f6 	mov	x22, x0
    6b80:	a9066bf9 	stp	x25, x26, [sp, #96]
    6b84:	f949ec62 	ldr	x2, [x3, #5080]
    6b88:	f9400024 	ldr	x4, [x1]
    6b8c:	f9000fe4 	str	x4, [sp, #24]
    6b90:	d2800004 	mov	x4, #0x0                   	// #0
    6b94:	f949d861 	ldr	x1, [x3, #5040]
    6b98:	d370bc42 	lsl	x2, x2, #16
    6b9c:	b40015a0 	cbz	x0, 6e50 <f37+0x2fc>
    6ba0:	f9400818 	ldr	x24, [x0, #16]
    6ba4:	cb010301 	sub	x1, x24, x1
    6ba8:	eb02003f 	cmp	x1, x2
    6bac:	54000362 	b.cs	6c18 <f37+0xc4>  // b.hs, b.nlast
    6bb0:	f949fc60 	ldr	x0, [x3, #5112]
    6bb4:	d350fc22 	lsr	x2, x1, #16
    6bb8:	8b020842 	add	x2, x2, x2, lsl #2
    6bbc:	8b020c02 	add	x2, x0, x2, lsl #3
    6bc0:	f9401040 	ldr	x0, [x2, #32]
    6bc4:	b40002a0 	cbz	x0, 6c18 <f37+0xc4>
    6bc8:	39400043 	ldrb	w3, [x2]
    6bcc:	7100087f 	cmp	w3, #0x2
    6bd0:	540013a0 	b.eq	6e44 <f37+0x2f0>  // b.none
    6bd4:	7100047f 	cmp	w3, #0x1
    6bd8:	540001c1 	b.ne	6c10 <f37+0xbc>  // b.any
    6bdc:	29430843 	ldp	w3, w2, [x2, #24]
    6be0:	92403c21 	and	x1, x1, #0xffff
    6be4:	9b037c21 	mul	x1, x1, x3
    6be8:	d360fc21 	lsr	x1, x1, #32
    6bec:	eb02003f 	cmp	x1, x2
    6bf0:	54000102 	b.cs	6c10 <f37+0xbc>  // b.hs, b.nlast
    6bf4:	8b010000 	add	x0, x0, x1
    6bf8:	39400001 	ldrb	w1, [x0]
    6bfc:	340000a1 	cbz	w1, 6c10 <f37+0xbc>
    6c00:	7103f43f 	cmp	w1, #0xfd
    6c04:	54001688 	b.hi	6ed4 <f37+0x380>  // b.pmore
    6c08:	11000421 	add	w1, w1, #0x1
    6c0c:	39000001 	strb	w1, [x0]
    6c10:	d2800000 	mov	x0, #0x0                   	// #0
    6c14:	b40000d6 	cbz	x22, 6c2c <f37+0xd8>
    6c18:	aa1603e1 	mov	x1, x22
    6c1c:	d2800000 	mov	x0, #0x0                   	// #0
    6c20:	f9400821 	ldr	x1, [x1, #16]
    6c24:	91000400 	add	x0, x0, #0x1
    6c28:	b5ffffc1 	cbnz	x1, 6c20 <f37+0xcc>
    6c2c:	b40011b8 	cbz	x24, 6e60 <f37+0x30c>
    6c30:	aa1803e1 	mov	x1, x24
    6c34:	d2800002 	mov	x2, #0x0                   	// #0
    6c38:	f9400821 	ldr	x1, [x1, #16]
    6c3c:	91000442 	add	x2, x2, #0x1
    6c40:	b5ffffc1 	cbnz	x1, 6c38 <f37+0xe4>
    6c44:	eb00005f 	cmp	x2, x0
    6c48:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6c4c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    6c50:	eb01033f 	cmp	x25, x1
    6c54:	54001468 	b.hi	6ee0 <f37+0x38c>  // b.pmore
    6c58:	d37ffb33 	lsl	x19, x25, #1
    6c5c:	52800041 	mov	w1, #0x2                   	// #2
    6c60:	91000660 	add	x0, x19, #0x1
    6c64:	d37df000 	lsl	x0, x0, #3
    6c68:	97fff802 	bl	4c70 <fwp_heap_alloc>
    6c6c:	911502e1 	add	x1, x23, #0x540
    6c70:	aa0003fa 	mov	x26, x0
    6c74:	f9000013 	str	x19, [x0]
    6c78:	aa0103e0 	mov	x0, x1
    6c7c:	f949d821 	ldr	x1, [x1, #5040]
    6c80:	f949ec00 	ldr	x0, [x0, #5080]
    6c84:	cb010341 	sub	x1, x26, x1
    6c88:	eb00403f 	cmp	x1, x0, lsl #16
    6c8c:	54000342 	b.cs	6cf4 <f37+0x1a0>  // b.hs, b.nlast
    6c90:	911502e2 	add	x2, x23, #0x540
    6c94:	d350fc20 	lsr	x0, x1, #16
    6c98:	8b000800 	add	x0, x0, x0, lsl #2
    6c9c:	f949fc43 	ldr	x3, [x2, #5112]
    6ca0:	d37df002 	lsl	x2, x0, #3
    6ca4:	8b020060 	add	x0, x3, x2
    6ca8:	f9401013 	ldr	x19, [x0, #32]
    6cac:	b4000253 	cbz	x19, 6cf4 <f37+0x1a0>
    6cb0:	38626862 	ldrb	w2, [x3, x2]
    6cb4:	7100085f 	cmp	w2, #0x2
    6cb8:	54000c00 	b.eq	6e38 <f37+0x2e4>  // b.none
    6cbc:	7100045f 	cmp	w2, #0x1
    6cc0:	540001a1 	b.ne	6cf4 <f37+0x1a0>  // b.any
    6cc4:	29430002 	ldp	w2, w0, [x0, #24]
    6cc8:	92403c21 	and	x1, x1, #0xffff
    6ccc:	9b027c21 	mul	x1, x1, x2
    6cd0:	d360fc21 	lsr	x1, x1, #32
    6cd4:	eb00003f 	cmp	x1, x0
    6cd8:	540000e2 	b.cs	6cf4 <f37+0x1a0>  // b.hs, b.nlast
    6cdc:	8b010273 	add	x19, x19, x1
    6ce0:	39400260 	ldrb	w0, [x19]
    6ce4:	7103fc1f 	cmp	w0, #0xff
    6ce8:	54000da0 	b.eq	6e9c <f37+0x348>  // b.none
    6cec:	52800020 	mov	w0, #0x1                   	// #1
    6cf0:	39000260 	strb	w0, [x19]
    6cf4:	b4000259 	cbz	x25, 6d3c <f37+0x1e8>
    6cf8:	8b191359 	add	x25, x26, x25, lsl #4
    6cfc:	aa1a03f3 	mov	x19, x26
    6d00:	aa1603f5 	mov	x21, x22
    6d04:	aa1803f4 	mov	x20, x24
    6d08:	f9400683 	ldr	x3, [x20, #8]
    6d0c:	f94006a2 	ldr	x2, [x21, #8]
    6d10:	f9400861 	ldr	x1, [x3, #16]
    6d14:	f9400840 	ldr	x0, [x2, #16]
    6d18:	fd400461 	ldr	d1, [x3, #8]
    6d1c:	fd400440 	ldr	d0, [x2, #8]
    6d20:	97fff944 	bl	5230 <w120>
    6d24:	f9000660 	str	x0, [x19, #8]
    6d28:	f8010e61 	str	x1, [x19, #16]!
    6d2c:	f9400a94 	ldr	x20, [x20, #16]
    6d30:	f9400ab5 	ldr	x21, [x21, #16]
    6d34:	eb13033f 	cmp	x25, x19
    6d38:	54fffe81 	b.ne	6d08 <f37+0x1b4>  // b.any
    6d3c:	aa1803e0 	mov	x0, x24
    6d40:	97fffcc4 	bl	6050 <fwp_drop4>
    6d44:	aa1603e0 	mov	x0, x22
    6d48:	97fffcc2 	bl	6050 <fwp_drop4>
    6d4c:	911502f7 	add	x23, x23, #0x540
    6d50:	aa1a03e0 	mov	x0, x26
    6d54:	97fff994 	bl	53a4 <w176.constprop.0>
    6d58:	aa0103f3 	mov	x19, x1
    6d5c:	aa0003f4 	mov	x20, x0
    6d60:	aa1a03e0 	mov	x0, x26
    6d64:	97fffe57 	bl	66c0 <fwp_drop10>
    6d68:	a900cff4 	stp	x20, x19, [sp, #8]
    6d6c:	910023e1 	add	x1, sp, #0x8
    6d70:	52800000 	mov	w0, #0x0                   	// #0
    6d74:	97fff804 	bl	4d84 <fwp_data.part.0.constprop.0>
    6d78:	f949dae1 	ldr	x1, [x23, #5040]
    6d7c:	aa0003f3 	mov	x19, x0
    6d80:	f949eee0 	ldr	x0, [x23, #5080]
    6d84:	cb010261 	sub	x1, x19, x1
    6d88:	eb00403f 	cmp	x1, x0, lsl #16
    6d8c:	54000322 	b.cs	6df0 <f37+0x29c>  // b.hs, b.nlast
    6d90:	d350fc22 	lsr	x2, x1, #16
    6d94:	f949fee3 	ldr	x3, [x23, #5112]
    6d98:	8b020842 	add	x2, x2, x2, lsl #2
    6d9c:	d37df042 	lsl	x2, x2, #3
    6da0:	8b020060 	add	x0, x3, x2
    6da4:	f9401014 	ldr	x20, [x0, #32]
    6da8:	b4000254 	cbz	x20, 6df0 <f37+0x29c>
    6dac:	38626862 	ldrb	w2, [x3, x2]
    6db0:	7100085f 	cmp	w2, #0x2
    6db4:	540003c0 	b.eq	6e2c <f37+0x2d8>  // b.none
    6db8:	7100045f 	cmp	w2, #0x1
    6dbc:	540001a1 	b.ne	6df0 <f37+0x29c>  // b.any
    6dc0:	29430002 	ldp	w2, w0, [x0, #24]
    6dc4:	92403c21 	and	x1, x1, #0xffff
    6dc8:	9b027c21 	mul	x1, x1, x2
    6dcc:	d360fc21 	lsr	x1, x1, #32
    6dd0:	eb00003f 	cmp	x1, x0
    6dd4:	540000e2 	b.cs	6df0 <f37+0x29c>  // b.hs, b.nlast
    6dd8:	8b010294 	add	x20, x20, x1
    6ddc:	39400280 	ldrb	w0, [x20]
    6de0:	7103fc1f 	cmp	w0, #0xff
    6de4:	54000620 	b.eq	6ea8 <f37+0x354>  // b.none
    6de8:	52800020 	mov	w0, #0x1                   	// #1
    6dec:	39000280 	strb	w0, [x20]
    6df0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6df4:	f947f400 	ldr	x0, [x0, #4072]
    6df8:	f9400fe2 	ldr	x2, [sp, #24]
    6dfc:	f9400001 	ldr	x1, [x0]
    6e00:	eb010042 	subs	x2, x2, x1
    6e04:	d2800001 	mov	x1, #0x0                   	// #0
    6e08:	540006a1 	b.ne	6edc <f37+0x388>  // b.any
    6e0c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6e10:	aa1303e0 	mov	x0, x19
    6e14:	a94353f3 	ldp	x19, x20, [sp, #48]
    6e18:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6e1c:	a94563f7 	ldp	x23, x24, [sp, #80]
    6e20:	a9466bf9 	ldp	x25, x26, [sp, #96]
    6e24:	9101c3ff 	add	sp, sp, #0x70
    6e28:	d65f03c0 	ret
    6e2c:	72003c3f 	tst	w1, #0xffff
    6e30:	54fffe01 	b.ne	6df0 <f37+0x29c>  // b.any
    6e34:	17ffffea 	b	6ddc <f37+0x288>
    6e38:	72003c3f 	tst	w1, #0xffff
    6e3c:	54fff5c1 	b.ne	6cf4 <f37+0x1a0>  // b.any
    6e40:	17ffffa8 	b	6ce0 <f37+0x18c>
    6e44:	72003c3f 	tst	w1, #0xffff
    6e48:	54ffee41 	b.ne	6c10 <f37+0xbc>  // b.any
    6e4c:	17ffff6b 	b	6bf8 <f37+0xa4>
    6e50:	cb0103e1 	neg	x1, x1
    6e54:	eb02003f 	cmp	x1, x2
    6e58:	540002e3 	b.cc	6eb4 <f37+0x360>  // b.lo, b.ul, b.last
    6e5c:	d503201f 	nop
    6e60:	52800041 	mov	w1, #0x2                   	// #2
    6e64:	d2800100 	mov	x0, #0x8                   	// #8
    6e68:	97fff782 	bl	4c70 <fwp_heap_alloc>
    6e6c:	aa0003e1 	mov	x1, x0
    6e70:	911502e0 	add	x0, x23, #0x540
    6e74:	aa0103fa 	mov	x26, x1
    6e78:	d2800018 	mov	x24, #0x0                   	// #0
    6e7c:	f900003f 	str	xzr, [x1]
    6e80:	f949d801 	ldr	x1, [x0, #5040]
    6e84:	f949ec00 	ldr	x0, [x0, #5080]
    6e88:	cb010341 	sub	x1, x26, x1
    6e8c:	eb00403f 	cmp	x1, x0, lsl #16
    6e90:	54fff562 	b.cs	6d3c <f37+0x1e8>  // b.hs, b.nlast
    6e94:	d2800019 	mov	x25, #0x0                   	// #0
    6e98:	17ffff7e 	b	6c90 <f37+0x13c>
    6e9c:	aa1303e0 	mov	x0, x19
    6ea0:	97fff5b4 	bl	4570 <fwp_rc_forget_slot>
    6ea4:	17ffff92 	b	6cec <f37+0x198>
    6ea8:	aa1403e0 	mov	x0, x20
    6eac:	97fff5b1 	bl	4570 <fwp_rc_forget_slot>
    6eb0:	17ffffce 	b	6de8 <f37+0x294>
    6eb4:	f949fc62 	ldr	x2, [x3, #5112]
    6eb8:	d350fc20 	lsr	x0, x1, #16
    6ebc:	8b000800 	add	x0, x0, x0, lsl #2
    6ec0:	8b000c42 	add	x2, x2, x0, lsl #3
    6ec4:	f9401040 	ldr	x0, [x2, #32]
    6ec8:	b4fffcc0 	cbz	x0, 6e60 <f37+0x30c>
    6ecc:	d2800018 	mov	x24, #0x0                   	// #0
    6ed0:	17ffff3e 	b	6bc8 <f37+0x74>
    6ed4:	97fff560 	bl	4454 <fwp_rc_wide_dup>
    6ed8:	17ffff4e 	b	6c10 <f37+0xbc>
    6edc:	97ffee69 	bl	2880 <__stack_chk_fail@plt>
    6ee0:	f0000020 	adrp	x0, d000 <_IO_stdin_used+0x350>
    6ee4:	91026000 	add	x0, x0, #0x98
    6ee8:	97fff1a6 	bl	3580 <fwp_trap>
    6eec:	d503201f 	nop

0000000000006ef0 <fwp_owned_entry37>:
    6ef0:	f9400000 	ldr	x0, [x0]
    6ef4:	17ffff18 	b	6b54 <f37>
    6ef8:	d503201f 	nop
    6efc:	d503201f 	nop

0000000000006f00 <e37>:
    6f00:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6f04:	910003fd 	mov	x29, sp
    6f08:	f9000bf3 	str	x19, [sp, #16]
    6f0c:	f9400013 	ldr	x19, [x0]
    6f10:	aa1303e0 	mov	x0, x19
    6f14:	97fff94c 	bl	5444 <fwp_rc_share>
    6f18:	aa1303e0 	mov	x0, x19
    6f1c:	97ffff0e 	bl	6b54 <f37>
    6f20:	aa0003f3 	mov	x19, x0
    6f24:	97fff948 	bl	5444 <fwp_rc_share>
    6f28:	aa1303e0 	mov	x0, x19
    6f2c:	f9400bf3 	ldr	x19, [sp, #16]
    6f30:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6f34:	d65f03c0 	ret
    6f38:	d503201f 	nop
    6f3c:	d503201f 	nop

0000000000006f40 <fwp_write>:
    6f40:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    6f44:	910003fd 	mov	x29, sp
    6f48:	b00000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    6f4c:	f947f484 	ldr	x4, [x4, #4072]
    6f50:	a90153f3 	stp	x19, x20, [sp, #16]
    6f54:	d10943ff 	sub	sp, sp, #0x250
    6f58:	b9400045 	ldr	w5, [x2]
    6f5c:	aa0003f4 	mov	x20, x0
    6f60:	f9400080 	ldr	x0, [x4]
    6f64:	f90127e0 	str	x0, [sp, #584]
    6f68:	d2800000 	mov	x0, #0x0                   	// #0
    6f6c:	710064bf 	cmp	w5, #0x19
    6f70:	54000408 	b.hi	6ff0 <fwp_write+0xb0>  // b.pmore
    6f74:	f0000020 	adrp	x0, d000 <_IO_stdin_used+0x350>
    6f78:	aa0103f3 	mov	x19, x1
    6f7c:	91240000 	add	x0, x0, #0x900
    6f80:	f9013bf5 	str	x21, [sp, #624]
    6f84:	f9013ff6 	str	x22, [sp, #632]
    6f88:	f90153fb 	str	x27, [sp, #672]
    6f8c:	f90157fc 	str	x28, [sp, #680]
    6f90:	aa0203fc 	mov	x28, x2
    6f94:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    6f98:	10000061 	adr	x1, 6fa4 <fwp_write+0x64>
    6f9c:	8b20a820 	add	x0, x1, w0, sxth #2
    6fa0:	d61f0000 	br	x0
    6fa4:	910123e0 	add	x0, sp, #0x48
    6fa8:	aa1303e5 	mov	x5, x19
    6fac:	f0000024 	adrp	x4, d000 <_IO_stdin_used+0x350>
    6fb0:	aa0003f3 	mov	x19, x0
    6fb4:	91038084 	add	x4, x4, #0xe0
    6fb8:	d2804003 	mov	x3, #0x200                 	// #512
    6fbc:	aa0303e1 	mov	x1, x3
    6fc0:	52800042 	mov	w2, #0x2                   	// #2
    6fc4:	97ffee0b 	bl	27f0 <__snprintf_chk@plt>
    6fc8:	aa1303e0 	mov	x0, x19
    6fcc:	97ffedd1 	bl	2710 <strlen@plt>
    6fd0:	aa1303e1 	mov	x1, x19
    6fd4:	aa0003e2 	mov	x2, x0
    6fd8:	aa1403e0 	mov	x0, x20
    6fdc:	97fff10d 	bl	3410 <buf_put>
    6fe0:	f9413bf5 	ldr	x21, [sp, #624]
    6fe4:	f9413ff6 	ldr	x22, [sp, #632]
    6fe8:	f94153fb 	ldr	x27, [sp, #672]
    6fec:	f94157fc 	ldr	x28, [sp, #680]
    6ff0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6ff4:	f947f400 	ldr	x0, [x0, #4072]
    6ff8:	f94127e2 	ldr	x2, [sp, #584]
    6ffc:	f9400001 	ldr	x1, [x0]
    7000:	eb010042 	subs	x2, x2, x1
    7004:	d2800001 	mov	x1, #0x0                   	// #0
    7008:	540077c1 	b.ne	7f00 <fwp_write+0xfc0>  // b.any
    700c:	910943ff 	add	sp, sp, #0x250
    7010:	a94153f3 	ldp	x19, x20, [sp, #16]
    7014:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7018:	d65f03c0 	ret
    701c:	910123e0 	add	x0, sp, #0x48
    7020:	aa1303e5 	mov	x5, x19
    7024:	d0000024 	adrp	x4, d000 <_IO_stdin_used+0x350>
    7028:	aa0003f3 	mov	x19, x0
    702c:	91036084 	add	x4, x4, #0xd8
    7030:	d2804003 	mov	x3, #0x200                 	// #512
    7034:	17ffffe2 	b	6fbc <fwp_write+0x7c>
    7038:	71004cbf 	cmp	w5, #0x13
    703c:	d0000020 	adrp	x0, d000 <_IO_stdin_used+0x350>
    7040:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x350>
    7044:	91032000 	add	x0, x0, #0xc8
    7048:	91034021 	add	x1, x1, #0xd0
    704c:	d2800082 	mov	x2, #0x4                   	// #4
    7050:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7054:	aa1403e0 	mov	x0, x20
    7058:	f90143f7 	str	x23, [sp, #640]
    705c:	d2800016 	mov	x22, #0x0                   	// #0
    7060:	f90147f8 	str	x24, [sp, #648]
    7064:	97fff0eb 	bl	3410 <buf_put>
    7068:	f9400260 	ldr	x0, [x19]
    706c:	d0000037 	adrp	x23, d000 <_IO_stdin_used+0x350>
    7070:	d2800015 	mov	x21, #0x0                   	// #0
    7074:	910542f7 	add	x23, x23, #0x150
    7078:	b40047a0 	cbz	x0, 796c <fwp_write+0xa2c>
    707c:	b9400380 	ldr	w0, [x28]
    7080:	52800003 	mov	w3, #0x0                   	// #0
    7084:	f9401f82 	ldr	x2, [x28, #56]
    7088:	71004c1f 	cmp	w0, #0x13
    708c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7090:	aa1403e0 	mov	x0, x20
    7094:	8b010e61 	add	x1, x19, x1, lsl #3
    7098:	f9400421 	ldr	x1, [x1, #8]
    709c:	97ffffa9 	bl	6f40 <fwp_write>
    70a0:	b9400380 	ldr	w0, [x28]
    70a4:	7100481f 	cmp	w0, #0x12
    70a8:	54004b40 	b.eq	7a10 <fwp_write+0xad0>  // b.none
    70ac:	f9400260 	ldr	x0, [x19]
    70b0:	910006b5 	add	x21, x21, #0x1
    70b4:	91000ad6 	add	x22, x22, #0x2
    70b8:	eb15001f 	cmp	x0, x21
    70bc:	54004589 	b.ls	796c <fwp_write+0xa2c>  // b.plast
    70c0:	aa1703e1 	mov	x1, x23
    70c4:	aa1403e0 	mov	x0, x20
    70c8:	d2800042 	mov	x2, #0x2                   	// #2
    70cc:	97fff0d1 	bl	3410 <buf_put>
    70d0:	17ffffeb 	b	707c <fwp_write+0x13c>
    70d4:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x350>
    70d8:	91042021 	add	x1, x1, #0x108
    70dc:	d28000c2 	mov	x2, #0x6                   	// #6
    70e0:	aa1403e0 	mov	x0, x20
    70e4:	91004273 	add	x19, x19, #0x10
    70e8:	97fff0ca 	bl	3410 <buf_put>
    70ec:	aa1303e0 	mov	x0, x19
    70f0:	97ffed88 	bl	2710 <strlen@plt>
    70f4:	aa1303e1 	mov	x1, x19
    70f8:	aa0003e2 	mov	x2, x0
    70fc:	aa1403e0 	mov	x0, x20
    7100:	97fff0c4 	bl	3410 <buf_put>
    7104:	528007c3 	mov	w3, #0x3e                  	// #62
    7108:	aa1403e0 	mov	x0, x20
    710c:	91001fe1 	add	x1, sp, #0x7
    7110:	d2800022 	mov	x2, #0x1                   	// #1
    7114:	39001fe3 	strb	w3, [sp, #7]
    7118:	17ffffb1 	b	6fdc <fwp_write+0x9c>
    711c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7120:	f947f400 	ldr	x0, [x0, #4072]
    7124:	f94127e2 	ldr	x2, [sp, #584]
    7128:	f9400001 	ldr	x1, [x0]
    712c:	eb010042 	subs	x2, x2, x1
    7130:	d2800001 	mov	x1, #0x0                   	// #0
    7134:	540034e1 	b.ne	77d0 <fwp_write+0x890>  // b.any
    7138:	f9413bf5 	ldr	x21, [sp, #624]
    713c:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x350>
    7140:	f9413ff6 	ldr	x22, [sp, #632]
    7144:	aa1403e0 	mov	x0, x20
    7148:	9103a021 	add	x1, x1, #0xe8
    714c:	d2800142 	mov	x2, #0xa                   	// #10
    7150:	f94153fb 	ldr	x27, [sp, #672]
    7154:	f94157fc 	ldr	x28, [sp, #680]
    7158:	910943ff 	add	sp, sp, #0x250
    715c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7160:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7164:	17fff0ab 	b	3410 <buf_put>
    7168:	f9400456 	ldr	x22, [x2, #8]
    716c:	f90143f7 	str	x23, [sp, #640]
    7170:	f90147f8 	str	x24, [sp, #648]
    7174:	b4005b16 	cbz	x22, 7cd4 <fwp_write+0xd94>
    7178:	aa1603e0 	mov	x0, x22
    717c:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x350>
    7180:	9105a021 	add	x1, x1, #0x168
    7184:	97ffeddf 	bl	2900 <strcmp@plt>
    7188:	2a0003f5 	mov	w21, w0
    718c:	34005fe0 	cbz	w0, 7d88 <fwp_write+0xe48>
    7190:	aa1603e0 	mov	x0, x22
    7194:	97ffed5f 	bl	2710 <strlen@plt>
    7198:	aa1603e1 	mov	x1, x22
    719c:	aa0003e2 	mov	x2, x0
    71a0:	aa1403e0 	mov	x0, x20
    71a4:	97fff09b 	bl	3410 <buf_put>
    71a8:	52800403 	mov	w3, #0x20                  	// #32
    71ac:	91001ff5 	add	x21, sp, #0x7
    71b0:	aa1503e1 	mov	x1, x21
    71b4:	aa1403e0 	mov	x0, x20
    71b8:	d2800022 	mov	x2, #0x1                   	// #1
    71bc:	39001fe3 	strb	w3, [sp, #7]
    71c0:	97fff094 	bl	3410 <buf_put>
    71c4:	52800f63 	mov	w3, #0x7b                  	// #123
    71c8:	aa1403e0 	mov	x0, x20
    71cc:	aa1503e1 	mov	x1, x21
    71d0:	d2800022 	mov	x2, #0x1                   	// #1
    71d4:	39001fe3 	strb	w3, [sp, #7]
    71d8:	97fff08e 	bl	3410 <buf_put>
    71dc:	b9401380 	ldr	w0, [x28, #16]
    71e0:	52800018 	mov	w24, #0x0                   	// #0
    71e4:	7100001f 	cmp	w0, #0x0
    71e8:	54003aad 	b.le	793c <fwp_write+0x9fc>
    71ec:	f9014bf9 	str	x25, [sp, #656]
    71f0:	d0000039 	adrp	x25, d000 <_IO_stdin_used+0x350>
    71f4:	91064339 	add	x25, x25, #0x190
    71f8:	f9014ffa 	str	x26, [sp, #664]
    71fc:	d000003a 	adrp	x26, d000 <_IO_stdin_used+0x350>
    7200:	9105435a 	add	x26, x26, #0x150
    7204:	91002276 	add	x22, x19, #0x8
    7208:	d2800013 	mov	x19, #0x0                   	// #0
    720c:	b5003e93 	cbnz	x19, 79dc <fwp_write+0xa9c>
    7210:	d37df277 	lsl	x23, x19, #3
    7214:	34003cb8 	cbz	w24, 79a8 <fwp_write+0xa68>
    7218:	f9401382 	ldr	x2, [x28, #32]
    721c:	aa1403e0 	mov	x0, x20
    7220:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7224:	52800003 	mov	w3, #0x0                   	// #0
    7228:	f8776842 	ldr	x2, [x2, x23]
    722c:	91000673 	add	x19, x19, #0x1
    7230:	97ffff44 	bl	6f40 <fwp_write>
    7234:	b9401380 	ldr	w0, [x28, #16]
    7238:	6b13001f 	cmp	w0, w19
    723c:	54fffe8c 	b.gt	720c <fwp_write+0x2cc>
    7240:	f9414bf9 	ldr	x25, [sp, #656]
    7244:	f9414ffa 	ldr	x26, [sp, #664]
    7248:	340037b8 	cbz	w24, 793c <fwp_write+0x9fc>
    724c:	52800523 	mov	w3, #0x29                  	// #41
    7250:	aa1503e1 	mov	x1, x21
    7254:	aa1403e0 	mov	x0, x20
    7258:	d2800022 	mov	x2, #0x1                   	// #1
    725c:	39001fe3 	strb	w3, [sp, #7]
    7260:	97fff06c 	bl	3410 <buf_put>
    7264:	f9413bf5 	ldr	x21, [sp, #624]
    7268:	f9413ff6 	ldr	x22, [sp, #632]
    726c:	f94143f7 	ldr	x23, [sp, #640]
    7270:	f94147f8 	ldr	x24, [sp, #648]
    7274:	f94153fb 	ldr	x27, [sp, #672]
    7278:	f94157fc 	ldr	x28, [sp, #680]
    727c:	17ffff5d 	b	6ff0 <fwp_write+0xb0>
    7280:	b9404855 	ldr	w21, [x2, #72]
    7284:	aa1403e0 	mov	x0, x20
    7288:	93407eb6 	sxtw	x22, w21
    728c:	91000ac1 	add	x1, x22, #0x2
    7290:	97fff02d 	bl	3344 <buf_grow>
    7294:	a9400281 	ldp	x1, x0, [x20]
    7298:	528e8603 	mov	w3, #0x7430                	// #29744
    729c:	78206823 	strh	w3, [x1, x0]
    72a0:	8b000022 	add	x2, x1, x0
    72a4:	710002bf 	cmp	w21, #0x0
    72a8:	540036cd 	b.le	7980 <fwp_write+0xa40>
    72ac:	110006a3 	add	w3, w21, #0x1
    72b0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    72b4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    72b8:	91000449 	add	x9, x2, #0x1
    72bc:	8b23c043 	add	x3, x2, w3, sxtw
    72c0:	f28aaac6 	movk	x6, #0x5556
    72c4:	f2955568 	movk	x8, #0xaaab
    72c8:	1400000d 	b	72fc <fwp_write+0x3bc>
    72cc:	d2800021 	mov	x1, #0x1                   	// #1
    72d0:	528005a5 	mov	w5, #0x2d                  	// #45
    72d4:	f100001f 	cmp	x0, #0x0
    72d8:	9b467e60 	smulh	x0, x19, x6
    72dc:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    72e0:	381ff465 	strb	w5, [x3], #-1
    72e4:	cb040000 	sub	x0, x0, x4
    72e8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    72ec:	cb020000 	sub	x0, x0, x2
    72f0:	8b010013 	add	x19, x0, x1
    72f4:	eb03013f 	cmp	x9, x3
    72f8:	54003440 	b.eq	7980 <fwp_write+0xa40>  // b.none
    72fc:	9b467e60 	smulh	x0, x19, x6
    7300:	937ffe64 	asr	x4, x19, #63
    7304:	52800605 	mov	w5, #0x30                  	// #48
    7308:	cb040000 	sub	x0, x0, x4
    730c:	8b000400 	add	x0, x0, x0, lsl #1
    7310:	cb000260 	sub	x0, x19, x0
    7314:	91000c01 	add	x1, x0, #0x3
    7318:	9bc87c22 	umulh	x2, x1, x8
    731c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7320:	8b4204e2 	add	x2, x7, x2, lsr #1
    7324:	eb020021 	subs	x1, x1, x2
    7328:	54fffd60 	b.eq	72d4 <fwp_write+0x394>  // b.none
    732c:	f100043f 	cmp	x1, #0x1
    7330:	54fffce1 	b.ne	72cc <fwp_write+0x38c>  // b.any
    7334:	d2800001 	mov	x1, #0x0                   	// #0
    7338:	52800565 	mov	w5, #0x2b                  	// #43
    733c:	17ffffe6 	b	72d4 <fwp_write+0x394>
    7340:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7344:	f947f400 	ldr	x0, [x0, #4072]
    7348:	f94127e2 	ldr	x2, [sp, #584]
    734c:	f9400001 	ldr	x1, [x0]
    7350:	eb010042 	subs	x2, x2, x1
    7354:	d2800001 	mov	x1, #0x0                   	// #0
    7358:	540023c1 	b.ne	77d0 <fwp_write+0x890>  // b.any
    735c:	f9413bf5 	ldr	x21, [sp, #624]
    7360:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x350>
    7364:	f9413ff6 	ldr	x22, [sp, #632]
    7368:	aa1403e0 	mov	x0, x20
    736c:	9103e021 	add	x1, x1, #0xf8
    7370:	d2800102 	mov	x2, #0x8                   	// #8
    7374:	17ffff77 	b	7150 <fwp_write+0x210>
    7378:	aa1403e0 	mov	x0, x20
    737c:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x350>
    7380:	d28000c2 	mov	x2, #0x6                   	// #6
    7384:	91056021 	add	x1, x1, #0x158
    7388:	97fff022 	bl	3410 <buf_put>
    738c:	d2800015 	mov	x21, #0x0                   	// #0
    7390:	f9400263 	ldr	x3, [x19]
    7394:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7398:	54002c60 	b.eq	7924 <fwp_write+0x9e4>  // b.none
    739c:	f9401f82 	ldr	x2, [x28, #56]
    73a0:	f90143f7 	str	x23, [sp, #640]
    73a4:	f90147f8 	str	x24, [sp, #648]
    73a8:	d2800857 	mov	x23, #0x42                  	// #66
    73ac:	f9014bf9 	str	x25, [sp, #656]
    73b0:	d0000036 	adrp	x22, d000 <_IO_stdin_used+0x350>
    73b4:	f9014ffa 	str	x26, [sp, #664]
    73b8:	910542d6 	add	x22, x22, #0x150
    73bc:	d2800038 	mov	x24, #0x1                   	// #1
    73c0:	f2a18017 	movk	x23, #0xc00, lsl #16
    73c4:	d2809099 	mov	x25, #0x484                 	// #1156
    73c8:	b40004a2 	cbz	x2, 745c <fwp_write+0x51c>
    73cc:	b9400040 	ldr	w0, [x2]
    73d0:	7100701f 	cmp	w0, #0x1c
    73d4:	540042c0 	b.eq	7c2c <fwp_write+0xcec>  // b.none
    73d8:	71006c1f 	cmp	w0, #0x1b
    73dc:	54000408 	b.hi	745c <fwp_write+0x51c>  // b.pmore
    73e0:	9ac02301 	lsl	x1, x24, x0
    73e4:	ea17003f 	tst	x1, x23
    73e8:	540036a1 	b.ne	7abc <fwp_write+0xb7c>  // b.any
    73ec:	ea19003f 	tst	x1, x25
    73f0:	54003521 	b.ne	7a94 <fwp_write+0xb54>  // b.any
    73f4:	d2800424 	mov	x4, #0x21                  	// #33
    73f8:	ea04003f 	tst	x1, x4
    73fc:	54000300 	b.eq	745c <fwp_write+0x51c>  // b.none
    7400:	b7f849c3 	tbnz	x3, #63, 7d38 <fwp_write+0xdf8>
    7404:	91002261 	add	x1, x19, #0x8
    7408:	8b150021 	add	x1, x1, x21
    740c:	39400021 	ldrb	w1, [x1]
    7410:	7100001f 	cmp	w0, #0x0
    7414:	93401c23 	sxtb	x3, w1
    7418:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    741c:	d503201f 	nop
    7420:	aa1403e0 	mov	x0, x20
    7424:	52800003 	mov	w3, #0x0                   	// #0
    7428:	97fffec6 	bl	6f40 <fwp_write>
    742c:	910006b5 	add	x21, x21, #0x1
    7430:	f9400260 	ldr	x0, [x19]
    7434:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7438:	eb0002bf 	cmp	x21, x0
    743c:	540026c2 	b.cs	7914 <fwp_write+0x9d4>  // b.hs, b.nlast
    7440:	d2800042 	mov	x2, #0x2                   	// #2
    7444:	aa1603e1 	mov	x1, x22
    7448:	aa1403e0 	mov	x0, x20
    744c:	97ffeff1 	bl	3410 <buf_put>
    7450:	f9401f82 	ldr	x2, [x28, #56]
    7454:	f9400263 	ldr	x3, [x19]
    7458:	b5fffba2 	cbnz	x2, 73cc <fwp_write+0x48c>
    745c:	d37df2a0 	lsl	x0, x21, #3
    7460:	b7f83f03 	tbnz	x3, #63, 7c40 <fwp_write+0xd00>
    7464:	91002261 	add	x1, x19, #0x8
    7468:	8b000020 	add	x0, x1, x0
    746c:	f9400001 	ldr	x1, [x0]
    7470:	17ffffec 	b	7420 <fwp_write+0x4e0>
    7474:	a9400e62 	ldp	x2, x3, [x19]
    7478:	b7f83ca3 	tbnz	x3, #63, 7c0c <fwp_write+0xccc>
    747c:	910123f5 	add	x21, sp, #0x48
    7480:	aa1503e0 	mov	x0, x21
    7484:	97ffee67 	bl	2e20 <fwp_fmt_u128>
    7488:	aa1503e0 	mov	x0, x21
    748c:	97ffeca1 	bl	2710 <strlen@plt>
    7490:	aa1503e1 	mov	x1, x21
    7494:	aa0003e2 	mov	x2, x0
    7498:	17fffed0 	b	6fd8 <fwp_write+0x98>
    749c:	fd015be8 	str	d8, [sp, #688]
    74a0:	1e270268 	fmov	s8, w19
    74a4:	fd015fe9 	str	d9, [sp, #696]
    74a8:	1e282100 	fcmp	s8, s8
    74ac:	54004d26 	b.vs	7e50 <fwp_write+0xf10>
    74b0:	1e20c101 	fabs	s1, s8
    74b4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    74b8:	1e270000 	fmov	s0, w0
    74bc:	1e202020 	fcmp	s1, s0
    74c0:	54002c0d 	b.le	7a40 <fwp_write+0xb00>
    74c4:	1e202118 	fcmpe	s8, #0.0
    74c8:	b0000022 	adrp	x2, c000 <f0+0x2630>
    74cc:	91334042 	add	x2, x2, #0xcd0
    74d0:	910123f5 	add	x21, sp, #0x48
    74d4:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x350>
    74d8:	9102a021 	add	x1, x1, #0xa8
    74dc:	aa1503e0 	mov	x0, x21
    74e0:	9a81c041 	csel	x1, x2, x1, gt
    74e4:	97ffed37 	bl	29c0 <strcpy@plt>
    74e8:	aa1503e0 	mov	x0, x21
    74ec:	97ffec89 	bl	2710 <strlen@plt>
    74f0:	aa1503e1 	mov	x1, x21
    74f4:	aa0003e2 	mov	x2, x0
    74f8:	aa1403e0 	mov	x0, x20
    74fc:	97ffefc5 	bl	3410 <buf_put>
    7500:	f9413bf5 	ldr	x21, [sp, #624]
    7504:	f9413ff6 	ldr	x22, [sp, #632]
    7508:	f94153fb 	ldr	x27, [sp, #672]
    750c:	f94157fc 	ldr	x28, [sp, #680]
    7510:	fd415be8 	ldr	d8, [sp, #688]
    7514:	fd415fe9 	ldr	d9, [sp, #696]
    7518:	17fffeb6 	b	6ff0 <fwp_write+0xb0>
    751c:	f9400276 	ldr	x22, [x19]
    7520:	34002e03 	cbz	w3, 7ae0 <fwp_write+0xba0>
    7524:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7528:	f947f400 	ldr	x0, [x0, #4072]
    752c:	f94127e2 	ldr	x2, [sp, #584]
    7530:	f9400001 	ldr	x1, [x0]
    7534:	eb010042 	subs	x2, x2, x1
    7538:	d2800001 	mov	x1, #0x0                   	// #0
    753c:	540014a1 	b.ne	77d0 <fwp_write+0x890>  // b.any
    7540:	aa1603e2 	mov	x2, x22
    7544:	91002261 	add	x1, x19, #0x8
    7548:	f9413bf5 	ldr	x21, [sp, #624]
    754c:	aa1403e0 	mov	x0, x20
    7550:	f9413ff6 	ldr	x22, [sp, #632]
    7554:	17fffeff 	b	7150 <fwp_write+0x210>
    7558:	fd015be8 	str	d8, [sp, #688]
    755c:	9e670268 	fmov	d8, x19
    7560:	fd015fe9 	str	d9, [sp, #696]
    7564:	1e682100 	fcmp	d8, d8
    7568:	54004746 	b.vs	7e50 <fwp_write+0xf10>
    756c:	1e60c101 	fabs	d1, d8
    7570:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7574:	9e670000 	fmov	d0, x0
    7578:	910123f5 	add	x21, sp, #0x48
    757c:	52800033 	mov	w19, #0x1                   	// #1
    7580:	1e602020 	fcmp	d1, d0
    7584:	540001ad 	b.le	75b8 <fwp_write+0x678>
    7588:	1e602118 	fcmpe	d8, #0.0
    758c:	b0000022 	adrp	x2, c000 <f0+0x2630>
    7590:	91334042 	add	x2, x2, #0xcd0
    7594:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x350>
    7598:	9102a021 	add	x1, x1, #0xa8
    759c:	aa1503e0 	mov	x0, x21
    75a0:	9a81c041 	csel	x1, x2, x1, gt
    75a4:	97ffed07 	bl	29c0 <strcpy@plt>
    75a8:	17ffffd0 	b	74e8 <fwp_write+0x5a8>
    75ac:	11000673 	add	w19, w19, #0x1
    75b0:	71004a7f 	cmp	w19, #0x12
    75b4:	54003860 	b.eq	7cc0 <fwp_write+0xd80>  // b.none
    75b8:	1e604100 	fmov	d0, d8
    75bc:	2a1303e1 	mov	w1, w19
    75c0:	aa1503e0 	mov	x0, x21
    75c4:	97fff0d4 	bl	3914 <fwp_format_g.constprop.0>
    75c8:	aa1503e0 	mov	x0, x21
    75cc:	d2800001 	mov	x1, #0x0                   	// #0
    75d0:	97ffec64 	bl	2760 <strtod@plt>
    75d4:	1e602100 	fcmp	d8, d0
    75d8:	54fffea1 	b.ne	75ac <fwp_write+0x66c>  // b.any
    75dc:	aa1503e0 	mov	x0, x21
    75e0:	97ffefc5 	bl	34f4 <fwp_finish_float>
    75e4:	17ffffc1 	b	74e8 <fwp_write+0x5a8>
    75e8:	a9400e62 	ldp	x2, x3, [x19]
    75ec:	910123f3 	add	x19, sp, #0x48
    75f0:	aa1303e0 	mov	x0, x19
    75f4:	97ffee0b 	bl	2e20 <fwp_fmt_u128>
    75f8:	17fffe74 	b	6fc8 <fwp_write+0x88>
    75fc:	f90143f7 	str	x23, [sp, #640]
    7600:	f90147f8 	str	x24, [sp, #648]
    7604:	2a1303f8 	mov	w24, w19
    7608:	f9014bf9 	str	x25, [sp, #656]
    760c:	f9014ffa 	str	x26, [sp, #664]
    7610:	f13ffe7f 	cmp	x19, #0xfff
    7614:	54000049 	b.ls	761c <fwp_write+0x6dc>  // b.plast
    7618:	b9400278 	ldr	w24, [x19]
    761c:	f9400f80 	ldr	x0, [x28, #24]
    7620:	2a1803f5 	mov	w21, w24
    7624:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7628:	d37ef6b9 	lsl	x25, x21, #2
    762c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7630:	aa1603e0 	mov	x0, x22
    7634:	97ffec37 	bl	2710 <strlen@plt>
    7638:	aa1603e1 	mov	x1, x22
    763c:	aa0003e2 	mov	x2, x0
    7640:	aa1403e0 	mov	x0, x20
    7644:	97ffef73 	bl	3410 <buf_put>
    7648:	f9401780 	ldr	x0, [x28, #40]
    764c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7650:	7100001f 	cmp	w0, #0x0
    7654:	5400068d 	b.le	7724 <fwp_write+0x7e4>
    7658:	91002276 	add	x22, x19, #0x8
    765c:	91001ff5 	add	x21, sp, #0x7
    7660:	d280001b 	mov	x27, #0x0                   	// #0
    7664:	5280041a 	mov	w26, #0x20                  	// #32
    7668:	f9401b80 	ldr	x0, [x28, #48]
    766c:	aa1503e1 	mov	x1, x21
    7670:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7674:	d2800022 	mov	x2, #0x1                   	// #1
    7678:	f8786803 	ldr	x3, [x0, x24]
    767c:	aa1403e0 	mov	x0, x20
    7680:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7684:	39001ffa 	strb	w26, [sp, #7]
    7688:	97ffef62 	bl	3410 <buf_put>
    768c:	f13ffeff 	cmp	x23, #0xfff
    7690:	b9400261 	ldr	w1, [x19]
    7694:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7698:	7100383f 	cmp	w1, #0xe
    769c:	54000160 	b.eq	76c8 <fwp_write+0x788>  // b.none
    76a0:	7100403f 	cmp	w1, #0x10
    76a4:	54001a60 	b.eq	79f0 <fwp_write+0xab0>  // b.none
    76a8:	7100283f 	cmp	w1, #0xa
    76ac:	54002aa0 	b.eq	7c00 <fwp_write+0xcc0>  // b.none
    76b0:	540014ac 	b.gt	7944 <fwp_write+0xa04>
    76b4:	71000c3f 	cmp	w1, #0x3
    76b8:	540029ac 	b.gt	7bec <fwp_write+0xcac>
    76bc:	d37ffee0 	lsr	x0, x23, #63
    76c0:	37f814a1 	tbnz	w1, #31, 7954 <fwp_write+0xa14>
    76c4:	d503201f 	nop
    76c8:	34001460 	cbz	w0, 7954 <fwp_write+0xa14>
    76cc:	52800503 	mov	w3, #0x28                  	// #40
    76d0:	aa1503e1 	mov	x1, x21
    76d4:	aa1403e0 	mov	x0, x20
    76d8:	d2800022 	mov	x2, #0x1                   	// #1
    76dc:	39001fe3 	strb	w3, [sp, #7]
    76e0:	97ffef4c 	bl	3410 <buf_put>
    76e4:	aa1303e2 	mov	x2, x19
    76e8:	aa1703e1 	mov	x1, x23
    76ec:	aa1403e0 	mov	x0, x20
    76f0:	52800003 	mov	w3, #0x0                   	// #0
    76f4:	97fffe13 	bl	6f40 <fwp_write>
    76f8:	52800523 	mov	w3, #0x29                  	// #41
    76fc:	aa1503e1 	mov	x1, x21
    7700:	aa1403e0 	mov	x0, x20
    7704:	d2800022 	mov	x2, #0x1                   	// #1
    7708:	39001fe3 	strb	w3, [sp, #7]
    770c:	97ffef41 	bl	3410 <buf_put>
    7710:	f9401780 	ldr	x0, [x28, #40]
    7714:	9100077b 	add	x27, x27, #0x1
    7718:	b8796800 	ldr	w0, [x0, x25]
    771c:	6b1b001f 	cmp	w0, w27
    7720:	54fffa4c 	b.gt	7668 <fwp_write+0x728>
    7724:	f9413bf5 	ldr	x21, [sp, #624]
    7728:	f9413ff6 	ldr	x22, [sp, #632]
    772c:	f94143f7 	ldr	x23, [sp, #640]
    7730:	f94147f8 	ldr	x24, [sp, #648]
    7734:	f9414bf9 	ldr	x25, [sp, #656]
    7738:	f9414ffa 	ldr	x26, [sp, #664]
    773c:	f94153fb 	ldr	x27, [sp, #672]
    7740:	f94157fc 	ldr	x28, [sp, #680]
    7744:	17fffe2b 	b	6ff0 <fwp_write+0xb0>
    7748:	52800783 	mov	w3, #0x3c                  	// #60
    774c:	91001ff3 	add	x19, sp, #0x7
    7750:	aa1303e1 	mov	x1, x19
    7754:	d2800022 	mov	x2, #0x1                   	// #1
    7758:	aa1403e0 	mov	x0, x20
    775c:	39001fe3 	strb	w3, [sp, #7]
    7760:	97ffef2c 	bl	3410 <buf_put>
    7764:	f9400795 	ldr	x21, [x28, #8]
    7768:	aa1503e0 	mov	x0, x21
    776c:	97ffebe9 	bl	2710 <strlen@plt>
    7770:	aa1503e1 	mov	x1, x21
    7774:	aa0003e2 	mov	x2, x0
    7778:	aa1403e0 	mov	x0, x20
    777c:	97ffef25 	bl	3410 <buf_put>
    7780:	528007c3 	mov	w3, #0x3e                  	// #62
    7784:	aa1303e1 	mov	x1, x19
    7788:	aa1403e0 	mov	x0, x20
    778c:	d2800022 	mov	x2, #0x1                   	// #1
    7790:	39001fe3 	strb	w3, [sp, #7]
    7794:	17fffe12 	b	6fdc <fwp_write+0x9c>
    7798:	f100067f 	cmp	x19, #0x1
    779c:	540025a0 	b.eq	7c50 <fwp_write+0xd10>  // b.none
    77a0:	b100067f 	cmn	x19, #0x1
    77a4:	54002bc0 	b.eq	7d1c <fwp_write+0xddc>  // b.none
    77a8:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x350>
    77ac:	9102c021 	add	x1, x1, #0xb0
    77b0:	d2800022 	mov	x2, #0x1                   	// #1
    77b4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    77b8:	f947f400 	ldr	x0, [x0, #4072]
    77bc:	f94127e4 	ldr	x4, [sp, #584]
    77c0:	f9400003 	ldr	x3, [x0]
    77c4:	eb030084 	subs	x4, x4, x3
    77c8:	d2800003 	mov	x3, #0x0                   	// #0
    77cc:	54ffebe0 	b.eq	7548 <fwp_write+0x608>  // b.none
    77d0:	f90143f7 	str	x23, [sp, #640]
    77d4:	f90147f8 	str	x24, [sp, #648]
    77d8:	f9014bf9 	str	x25, [sp, #656]
    77dc:	f9014ffa 	str	x26, [sp, #664]
    77e0:	fd015be8 	str	d8, [sp, #688]
    77e4:	fd015fe9 	str	d9, [sp, #696]
    77e8:	97ffec26 	bl	2880 <__stack_chk_fail@plt>
    77ec:	52800b63 	mov	w3, #0x5b                  	// #91
    77f0:	91001ff5 	add	x21, sp, #0x7
    77f4:	aa1503e1 	mov	x1, x21
    77f8:	aa1403e0 	mov	x0, x20
    77fc:	d2800022 	mov	x2, #0x1                   	// #1
    7800:	d0000036 	adrp	x22, d000 <_IO_stdin_used+0x350>
    7804:	910542d6 	add	x22, x22, #0x150
    7808:	39001fe3 	strb	w3, [sp, #7]
    780c:	97ffef01 	bl	3410 <buf_put>
    7810:	b4000273 	cbz	x19, 785c <fwp_write+0x91c>
    7814:	f9400661 	ldr	x1, [x19, #8]
    7818:	aa1403e0 	mov	x0, x20
    781c:	f9401f82 	ldr	x2, [x28, #56]
    7820:	52800003 	mov	w3, #0x0                   	// #0
    7824:	97fffdc7 	bl	6f40 <fwp_write>
    7828:	f9400a73 	ldr	x19, [x19, #16]
    782c:	b4000193 	cbz	x19, 785c <fwp_write+0x91c>
    7830:	aa1603e1 	mov	x1, x22
    7834:	aa1403e0 	mov	x0, x20
    7838:	d2800042 	mov	x2, #0x2                   	// #2
    783c:	97ffeef5 	bl	3410 <buf_put>
    7840:	f9400661 	ldr	x1, [x19, #8]
    7844:	aa1403e0 	mov	x0, x20
    7848:	f9401f82 	ldr	x2, [x28, #56]
    784c:	52800003 	mov	w3, #0x0                   	// #0
    7850:	97fffdbc 	bl	6f40 <fwp_write>
    7854:	f9400a73 	ldr	x19, [x19, #16]
    7858:	b5fffed3 	cbnz	x19, 7830 <fwp_write+0x8f0>
    785c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7860:	aa1503e1 	mov	x1, x21
    7864:	aa1403e0 	mov	x0, x20
    7868:	d2800022 	mov	x2, #0x1                   	// #1
    786c:	39001fe3 	strb	w3, [sp, #7]
    7870:	17fffddb 	b	6fdc <fwp_write+0x9c>
    7874:	aa1403e0 	mov	x0, x20
    7878:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x350>
    787c:	d28000c2 	mov	x2, #0x6                   	// #6
    7880:	91050021 	add	x1, x1, #0x140
    7884:	97ffeee3 	bl	3410 <buf_put>
    7888:	f9400260 	ldr	x0, [x19]
    788c:	b40004c0 	cbz	x0, 7924 <fwp_write+0x9e4>
    7890:	910123f5 	add	x21, sp, #0x48
    7894:	91002276 	add	x22, x19, #0x8
    7898:	f90143f7 	str	x23, [sp, #640]
    789c:	d2800017 	mov	x23, #0x0                   	// #0
    78a0:	f90147f8 	str	x24, [sp, #648]
    78a4:	d0000038 	adrp	x24, d000 <_IO_stdin_used+0x350>
    78a8:	91052318 	add	x24, x24, #0x148
    78ac:	f9014bf9 	str	x25, [sp, #656]
    78b0:	d0000039 	adrp	x25, d000 <_IO_stdin_used+0x350>
    78b4:	91054339 	add	x25, x25, #0x150
    78b8:	f9014ffa 	str	x26, [sp, #664]
    78bc:	14000005 	b	78d0 <fwp_write+0x990>
    78c0:	aa1903e1 	mov	x1, x25
    78c4:	aa1403e0 	mov	x0, x20
    78c8:	d2800042 	mov	x2, #0x2                   	// #2
    78cc:	97ffeed1 	bl	3410 <buf_put>
    78d0:	38776ac5 	ldrb	w5, [x22, x23]
    78d4:	d2804003 	mov	x3, #0x200                 	// #512
    78d8:	aa1803e4 	mov	x4, x24
    78dc:	aa0303e1 	mov	x1, x3
    78e0:	52800042 	mov	w2, #0x2                   	// #2
    78e4:	aa1503e0 	mov	x0, x21
    78e8:	910006f7 	add	x23, x23, #0x1
    78ec:	97ffebc1 	bl	27f0 <__snprintf_chk@plt>
    78f0:	aa1503e0 	mov	x0, x21
    78f4:	97ffeb87 	bl	2710 <strlen@plt>
    78f8:	aa1503e1 	mov	x1, x21
    78fc:	aa0003e2 	mov	x2, x0
    7900:	aa1403e0 	mov	x0, x20
    7904:	97ffeec3 	bl	3410 <buf_put>
    7908:	f9400260 	ldr	x0, [x19]
    790c:	eb17001f 	cmp	x0, x23
    7910:	54fffd88 	b.hi	78c0 <fwp_write+0x980>  // b.pmore
    7914:	f94143f7 	ldr	x23, [sp, #640]
    7918:	f94147f8 	ldr	x24, [sp, #648]
    791c:	f9414bf9 	ldr	x25, [sp, #656]
    7920:	f9414ffa 	ldr	x26, [sp, #664]
    7924:	52800ba3 	mov	w3, #0x5d                  	// #93
    7928:	aa1403e0 	mov	x0, x20
    792c:	91001fe1 	add	x1, sp, #0x7
    7930:	d2800022 	mov	x2, #0x1                   	// #1
    7934:	39001fe3 	strb	w3, [sp, #7]
    7938:	17fffda9 	b	6fdc <fwp_write+0x9c>
    793c:	52800fa3 	mov	w3, #0x7d                  	// #125
    7940:	17fffe44 	b	7250 <fwp_write+0x310>
    7944:	f10002ff 	cmp	x23, #0x0
    7948:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    794c:	71002c3f 	cmp	w1, #0xb
    7950:	54ffebc0 	b.eq	76c8 <fwp_write+0x788>  // b.none
    7954:	aa1303e2 	mov	x2, x19
    7958:	aa1703e1 	mov	x1, x23
    795c:	aa1403e0 	mov	x0, x20
    7960:	52800003 	mov	w3, #0x0                   	// #0
    7964:	97fffd77 	bl	6f40 <fwp_write>
    7968:	17ffff6a 	b	7710 <fwp_write+0x7d0>
    796c:	aa1403e0 	mov	x0, x20
    7970:	91001fe1 	add	x1, sp, #0x7
    7974:	52800fa3 	mov	w3, #0x7d                  	// #125
    7978:	d2800022 	mov	x2, #0x1                   	// #1
    797c:	17fffe38 	b	725c <fwp_write+0x31c>
    7980:	a9400281 	ldp	x1, x0, [x20]
    7984:	91000800 	add	x0, x0, #0x2
    7988:	8b160000 	add	x0, x0, x22
    798c:	f9000680 	str	x0, [x20, #8]
    7990:	3820683f 	strb	wzr, [x1, x0]
    7994:	f9413bf5 	ldr	x21, [sp, #624]
    7998:	f9413ff6 	ldr	x22, [sp, #632]
    799c:	f94153fb 	ldr	x27, [sp, #672]
    79a0:	f94157fc 	ldr	x28, [sp, #680]
    79a4:	17fffd93 	b	6ff0 <fwp_write+0xb0>
    79a8:	f9400f80 	ldr	x0, [x28, #24]
    79ac:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    79b0:	aa1b03e0 	mov	x0, x27
    79b4:	97ffeb57 	bl	2710 <strlen@plt>
    79b8:	aa1b03e1 	mov	x1, x27
    79bc:	aa0003e2 	mov	x2, x0
    79c0:	aa1403e0 	mov	x0, x20
    79c4:	97ffee93 	bl	3410 <buf_put>
    79c8:	aa1903e1 	mov	x1, x25
    79cc:	aa1403e0 	mov	x0, x20
    79d0:	d2800062 	mov	x2, #0x3                   	// #3
    79d4:	97ffee8f 	bl	3410 <buf_put>
    79d8:	17fffe10 	b	7218 <fwp_write+0x2d8>
    79dc:	aa1a03e1 	mov	x1, x26
    79e0:	aa1403e0 	mov	x0, x20
    79e4:	d2800042 	mov	x2, #0x2                   	// #2
    79e8:	97ffee8a 	bl	3410 <buf_put>
    79ec:	17fffe09 	b	7210 <fwp_write+0x2d0>
    79f0:	f9400660 	ldr	x0, [x19, #8]
    79f4:	b4fffb00 	cbz	x0, 7954 <fwp_write+0xa14>
    79f8:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x350>
    79fc:	9105a021 	add	x1, x1, #0x168
    7a00:	97ffebc0 	bl	2900 <strcmp@plt>
    7a04:	7100001f 	cmp	w0, #0x0
    7a08:	1a9f07e0 	cset	w0, ne	// ne = any
    7a0c:	17ffff2f 	b	76c8 <fwp_write+0x788>
    7a10:	aa1403e0 	mov	x0, x20
    7a14:	d2800042 	mov	x2, #0x2                   	// #2
    7a18:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x350>
    7a1c:	91058021 	add	x1, x1, #0x160
    7a20:	97ffee7c 	bl	3410 <buf_put>
    7a24:	91004261 	add	x1, x19, #0x10
    7a28:	aa1403e0 	mov	x0, x20
    7a2c:	f9402382 	ldr	x2, [x28, #64]
    7a30:	52800003 	mov	w3, #0x0                   	// #0
    7a34:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7a38:	97fffd42 	bl	6f40 <fwp_write>
    7a3c:	17fffd9c 	b	70ac <fwp_write+0x16c>
    7a40:	1e22c109 	fcvt	d9, s8
    7a44:	910123f5 	add	x21, sp, #0x48
    7a48:	52800033 	mov	w19, #0x1                   	// #1
    7a4c:	d503201f 	nop
    7a50:	1e604120 	fmov	d0, d9
    7a54:	2a1303e1 	mov	w1, w19
    7a58:	aa1503e0 	mov	x0, x21
    7a5c:	97ffefae 	bl	3914 <fwp_format_g.constprop.0>
    7a60:	aa1503e0 	mov	x0, x21
    7a64:	d2800001 	mov	x1, #0x0                   	// #0
    7a68:	97ffebb2 	bl	2930 <strtof@plt>
    7a6c:	1e202100 	fcmp	s8, s0
    7a70:	54ffdb60 	b.eq	75dc <fwp_write+0x69c>  // b.none
    7a74:	11000673 	add	w19, w19, #0x1
    7a78:	71002a7f 	cmp	w19, #0xa
    7a7c:	54fffea1 	b.ne	7a50 <fwp_write+0xb10>  // b.any
    7a80:	1e604120 	fmov	d0, d9
    7a84:	aa1503e0 	mov	x0, x21
    7a88:	52800121 	mov	w1, #0x9                   	// #9
    7a8c:	97ffefa2 	bl	3914 <fwp_format_g.constprop.0>
    7a90:	17fffed3 	b	75dc <fwp_write+0x69c>
    7a94:	d37ef6a1 	lsl	x1, x21, #2
    7a98:	b7f81563 	tbnz	x3, #63, 7d44 <fwp_write+0xe04>
    7a9c:	91002263 	add	x3, x19, #0x8
    7aa0:	8b010061 	add	x1, x3, x1
    7aa4:	b9400023 	ldr	w3, [x1]
    7aa8:	7100081f 	cmp	w0, #0x2
    7aac:	2a0303e1 	mov	w1, w3
    7ab0:	93407c63 	sxtw	x3, w3
    7ab4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7ab8:	17fffe5a 	b	7420 <fwp_write+0x4e0>
    7abc:	d37ffaa1 	lsl	x1, x21, #1
    7ac0:	b7f81363 	tbnz	x3, #63, 7d2c <fwp_write+0xdec>
    7ac4:	91002263 	add	x3, x19, #0x8
    7ac8:	8b010061 	add	x1, x3, x1
    7acc:	79400021 	ldrh	w1, [x1]
    7ad0:	7100041f 	cmp	w0, #0x1
    7ad4:	93403c23 	sxth	x3, w1
    7ad8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7adc:	17fffe51 	b	7420 <fwp_write+0x4e0>
    7ae0:	52800443 	mov	w3, #0x22                  	// #34
    7ae4:	91001ff5 	add	x21, sp, #0x7
    7ae8:	91002273 	add	x19, x19, #0x8
    7aec:	aa1503e1 	mov	x1, x21
    7af0:	aa1403e0 	mov	x0, x20
    7af4:	d2800022 	mov	x2, #0x1                   	// #1
    7af8:	39001fe3 	strb	w3, [sp, #7]
    7afc:	f90143f7 	str	x23, [sp, #640]
    7b00:	8b160277 	add	x23, x19, x22
    7b04:	f90147f8 	str	x24, [sp, #648]
    7b08:	97ffee42 	bl	3410 <buf_put>
    7b0c:	b4000696 	cbz	x22, 7bdc <fwp_write+0xc9c>
    7b10:	d0000038 	adrp	x24, d000 <_IO_stdin_used+0x350>
    7b14:	91044318 	add	x24, x24, #0x110
    7b18:	f9014bf9 	str	x25, [sp, #656]
    7b1c:	d0000039 	adrp	x25, d000 <_IO_stdin_used+0x350>
    7b20:	9104c339 	add	x25, x25, #0x130
    7b24:	f9014ffa 	str	x26, [sp, #664]
    7b28:	1400000d 	b	7b5c <fwp_write+0xc1c>
    7b2c:	710024bf 	cmp	w5, #0x9
    7b30:	54000460 	b.eq	7bbc <fwp_write+0xc7c>  // b.none
    7b34:	710028bf 	cmp	w5, #0xa
    7b38:	54000a61 	b.ne	7c84 <fwp_write+0xd44>  // b.any
    7b3c:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x350>
    7b40:	aa1403e0 	mov	x0, x20
    7b44:	91048021 	add	x1, x1, #0x120
    7b48:	d2800042 	mov	x2, #0x2                   	// #2
    7b4c:	97ffee31 	bl	3410 <buf_put>
    7b50:	91000673 	add	x19, x19, #0x1
    7b54:	eb17027f 	cmp	x19, x23
    7b58:	540003e0 	b.eq	7bd4 <fwp_write+0xc94>  // b.none
    7b5c:	39400265 	ldrb	w5, [x19]
    7b60:	710034bf 	cmp	w5, #0xd
    7b64:	54000180 	b.eq	7b94 <fwp_write+0xc54>  // b.none
    7b68:	54fffe29 	b.ls	7b2c <fwp_write+0xbec>  // b.plast
    7b6c:	710088bf 	cmp	w5, #0x22
    7b70:	540001c0 	b.eq	7ba8 <fwp_write+0xc68>  // b.none
    7b74:	710170bf 	cmp	w5, #0x5c
    7b78:	54000741 	b.ne	7c60 <fwp_write+0xd20>  // b.any
    7b7c:	aa1403e0 	mov	x0, x20
    7b80:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x350>
    7b84:	d2800042 	mov	x2, #0x2                   	// #2
    7b88:	91046021 	add	x1, x1, #0x118
    7b8c:	97ffee21 	bl	3410 <buf_put>
    7b90:	17fffff0 	b	7b50 <fwp_write+0xc10>
    7b94:	aa1903e1 	mov	x1, x25
    7b98:	aa1403e0 	mov	x0, x20
    7b9c:	d2800042 	mov	x2, #0x2                   	// #2
    7ba0:	97ffee1c 	bl	3410 <buf_put>
    7ba4:	17ffffeb 	b	7b50 <fwp_write+0xc10>
    7ba8:	aa1803e1 	mov	x1, x24
    7bac:	aa1403e0 	mov	x0, x20
    7bb0:	d2800042 	mov	x2, #0x2                   	// #2
    7bb4:	97ffee17 	bl	3410 <buf_put>
    7bb8:	17ffffe6 	b	7b50 <fwp_write+0xc10>
    7bbc:	aa1403e0 	mov	x0, x20
    7bc0:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x350>
    7bc4:	d2800042 	mov	x2, #0x2                   	// #2
    7bc8:	9104a021 	add	x1, x1, #0x128
    7bcc:	97ffee11 	bl	3410 <buf_put>
    7bd0:	17ffffe0 	b	7b50 <fwp_write+0xc10>
    7bd4:	f9414bf9 	ldr	x25, [sp, #656]
    7bd8:	f9414ffa 	ldr	x26, [sp, #664]
    7bdc:	aa1503e1 	mov	x1, x21
    7be0:	aa1403e0 	mov	x0, x20
    7be4:	52800443 	mov	w3, #0x22                  	// #34
    7be8:	17fffd9c 	b	7258 <fwp_write+0x318>
    7bec:	7100103f 	cmp	w1, #0x4
    7bf0:	54ffeb21 	b.ne	7954 <fwp_write+0xa14>  // b.any
    7bf4:	f94006e0 	ldr	x0, [x23, #8]
    7bf8:	d37ffc00 	lsr	x0, x0, #63
    7bfc:	17fffeb3 	b	76c8 <fwp_write+0x788>
    7c00:	710002ff 	cmp	w23, #0x0
    7c04:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7c08:	17fffeb0 	b	76c8 <fwp_write+0x788>
    7c0c:	528005a1 	mov	w1, #0x2d                  	// #45
    7c10:	eb0203e2 	negs	x2, x2
    7c14:	da0303e3 	ngc	x3, x3
    7c18:	910127e0 	add	x0, sp, #0x49
    7c1c:	910123f5 	add	x21, sp, #0x48
    7c20:	390123e1 	strb	w1, [sp, #72]
    7c24:	97ffec7f 	bl	2e20 <fwp_fmt_u128>
    7c28:	17fffe18 	b	7488 <fwp_write+0x548>
    7c2c:	d37ceea1 	lsl	x1, x21, #4
    7c30:	b7f810a3 	tbnz	x3, #63, 7e44 <fwp_write+0xf04>
    7c34:	91002260 	add	x0, x19, #0x8
    7c38:	8b010001 	add	x1, x0, x1
    7c3c:	17fffdf9 	b	7420 <fwp_write+0x4e0>
    7c40:	f9400a61 	ldr	x1, [x19, #16]
    7c44:	8b010000 	add	x0, x0, x1
    7c48:	f9400001 	ldr	x1, [x0]
    7c4c:	17fffdf5 	b	7420 <fwp_write+0x4e0>
    7c50:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x350>
    7c54:	d2800042 	mov	x2, #0x2                   	// #2
    7c58:	9102e021 	add	x1, x1, #0xb8
    7c5c:	17fffed6 	b	77b4 <fwp_write+0x874>
    7c60:	7101fcbf 	cmp	w5, #0x7f
    7c64:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7c68:	540000e9 	b.ls	7c84 <fwp_write+0xd44>  // b.plast
    7c6c:	aa1503e1 	mov	x1, x21
    7c70:	aa1403e0 	mov	x0, x20
    7c74:	d2800022 	mov	x2, #0x1                   	// #1
    7c78:	39001fe5 	strb	w5, [sp, #7]
    7c7c:	97ffede5 	bl	3410 <buf_put>
    7c80:	17ffffb4 	b	7b50 <fwp_write+0xc10>
    7c84:	d2800203 	mov	x3, #0x10                  	// #16
    7c88:	d0000024 	adrp	x4, d000 <_IO_stdin_used+0x350>
    7c8c:	aa0303e1 	mov	x1, x3
    7c90:	9104e084 	add	x4, x4, #0x138
    7c94:	910123f6 	add	x22, sp, #0x48
    7c98:	52800042 	mov	w2, #0x2                   	// #2
    7c9c:	aa1603e0 	mov	x0, x22
    7ca0:	97ffead4 	bl	27f0 <__snprintf_chk@plt>
    7ca4:	aa1603e0 	mov	x0, x22
    7ca8:	97ffea9a 	bl	2710 <strlen@plt>
    7cac:	aa1603e1 	mov	x1, x22
    7cb0:	aa0003e2 	mov	x2, x0
    7cb4:	aa1403e0 	mov	x0, x20
    7cb8:	97ffedd6 	bl	3410 <buf_put>
    7cbc:	17ffffa5 	b	7b50 <fwp_write+0xc10>
    7cc0:	1e604100 	fmov	d0, d8
    7cc4:	aa1503e0 	mov	x0, x21
    7cc8:	52800221 	mov	w1, #0x11                  	// #17
    7ccc:	97ffef12 	bl	3914 <fwp_format_g.constprop.0>
    7cd0:	17fffe43 	b	75dc <fwp_write+0x69c>
    7cd4:	b9401040 	ldr	w0, [x2, #16]
    7cd8:	350003c0 	cbnz	w0, 7d50 <fwp_write+0xe10>
    7cdc:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7ce0:	f947f400 	ldr	x0, [x0, #4072]
    7ce4:	f94127e2 	ldr	x2, [sp, #584]
    7ce8:	f9400001 	ldr	x1, [x0]
    7cec:	eb010042 	subs	x2, x2, x1
    7cf0:	d2800001 	mov	x1, #0x0                   	// #0
    7cf4:	54ffd721 	b.ne	77d8 <fwp_write+0x898>  // b.any
    7cf8:	f9413bf5 	ldr	x21, [sp, #624]
    7cfc:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x350>
    7d00:	f9413ff6 	ldr	x22, [sp, #632]
    7d04:	aa1403e0 	mov	x0, x20
    7d08:	f94143f7 	ldr	x23, [sp, #640]
    7d0c:	91062021 	add	x1, x1, #0x188
    7d10:	f94147f8 	ldr	x24, [sp, #648]
    7d14:	d2800042 	mov	x2, #0x2                   	// #2
    7d18:	17fffd0e 	b	7150 <fwp_write+0x210>
    7d1c:	d0000021 	adrp	x1, d000 <_IO_stdin_used+0x350>
    7d20:	d2800042 	mov	x2, #0x2                   	// #2
    7d24:	91030021 	add	x1, x1, #0xc0
    7d28:	17fffea3 	b	77b4 <fwp_write+0x874>
    7d2c:	f9400a63 	ldr	x3, [x19, #16]
    7d30:	8b030021 	add	x1, x1, x3
    7d34:	17ffff66 	b	7acc <fwp_write+0xb8c>
    7d38:	f9400a61 	ldr	x1, [x19, #16]
    7d3c:	8b0102a1 	add	x1, x21, x1
    7d40:	17fffdb3 	b	740c <fwp_write+0x4cc>
    7d44:	f9400a63 	ldr	x3, [x19, #16]
    7d48:	8b030021 	add	x1, x1, x3
    7d4c:	17ffff56 	b	7aa4 <fwp_write+0xb64>
    7d50:	b9404840 	ldr	w0, [x2, #72]
    7d54:	91001ff5 	add	x21, sp, #0x7
    7d58:	34ffa360 	cbz	w0, 71c4 <fwp_write+0x284>
    7d5c:	52800503 	mov	w3, #0x28                  	// #40
    7d60:	aa1403e0 	mov	x0, x20
    7d64:	aa1503e1 	mov	x1, x21
    7d68:	d2800022 	mov	x2, #0x1                   	// #1
    7d6c:	39001fe3 	strb	w3, [sp, #7]
    7d70:	97ffeda8 	bl	3410 <buf_put>
    7d74:	b9401380 	ldr	w0, [x28, #16]
    7d78:	52800038 	mov	w24, #0x1                   	// #1
    7d7c:	7100001f 	cmp	w0, #0x0
    7d80:	54ffa36c 	b.gt	71ec <fwp_write+0x2ac>
    7d84:	17fffd32 	b	724c <fwp_write+0x30c>
    7d88:	f9014bf9 	str	x25, [sp, #656]
    7d8c:	f00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xf2f0>
    7d90:	f9014ffa 	str	x26, [sp, #664]
    7d94:	f9400676 	ldr	x22, [x19, #8]
    7d98:	910aa333 	add	x19, x25, #0x2a8
    7d9c:	91002273 	add	x19, x19, #0x8
    7da0:	937ffed8 	asr	x24, x22, #63
    7da4:	aa1802c0 	orr	x0, x22, x24
    7da8:	b5000320 	cbnz	x0, 7e0c <fwp_write+0xecc>
    7dac:	110006b5 	add	w21, w21, #0x1
    7db0:	710016bf 	cmp	w21, #0x5
    7db4:	54ffffc1 	b.ne	7dac <fwp_write+0xe6c>  // b.any
    7db8:	b7f80578 	tbnz	x24, #63, 7e64 <fwp_write+0xf24>
    7dbc:	910023f3 	add	x19, sp, #0x8
    7dc0:	aa1603e2 	mov	x2, x22
    7dc4:	aa1303e0 	mov	x0, x19
    7dc8:	d2800003 	mov	x3, #0x0                   	// #0
    7dcc:	97ffec15 	bl	2e20 <fwp_fmt_u128>
    7dd0:	910123f5 	add	x21, sp, #0x48
    7dd4:	d0000023 	adrp	x3, d000 <_IO_stdin_used+0x350>
    7dd8:	aa1303e4 	mov	x4, x19
    7ddc:	aa1503e0 	mov	x0, x21
    7de0:	91060063 	add	x3, x3, #0x180
    7de4:	d2804002 	mov	x2, #0x200                 	// #512
    7de8:	52800041 	mov	w1, #0x2                   	// #2
    7dec:	97ffea4d 	bl	2720 <__sprintf_chk@plt>
    7df0:	aa1503e0 	mov	x0, x21
    7df4:	97ffea47 	bl	2710 <strlen@plt>
    7df8:	aa1503e1 	mov	x1, x21
    7dfc:	aa0003e2 	mov	x2, x0
    7e00:	aa1403e0 	mov	x0, x20
    7e04:	97ffed83 	bl	3410 <buf_put>
    7e08:	17fffe47 	b	7724 <fwp_write+0x7e4>
    7e0c:	f9400277 	ldr	x23, [x19]
    7e10:	aa1603e0 	mov	x0, x22
    7e14:	aa1803e1 	mov	x1, x24
    7e18:	aa1703e2 	mov	x2, x23
    7e1c:	937ffefa 	asr	x26, x23, #63
    7e20:	aa1a03e3 	mov	x3, x26
    7e24:	940012bb 	bl	c910 <__modti3>
    7e28:	aa010000 	orr	x0, x0, x1
    7e2c:	b40002c0 	cbz	x0, 7e84 <fwp_write+0xf44>
    7e30:	110006b5 	add	w21, w21, #0x1
    7e34:	91004273 	add	x19, x19, #0x10
    7e38:	710016bf 	cmp	w21, #0x5
    7e3c:	54fffe81 	b.ne	7e0c <fwp_write+0xecc>  // b.any
    7e40:	17ffffde 	b	7db8 <fwp_write+0xe78>
    7e44:	f9400a60 	ldr	x0, [x19, #16]
    7e48:	8b000021 	add	x1, x1, x0
    7e4c:	17fffd75 	b	7420 <fwp_write+0x4e0>
    7e50:	528c29c0 	mov	w0, #0x614e                	// #24910
    7e54:	910123f5 	add	x21, sp, #0x48
    7e58:	72a009c0 	movk	w0, #0x4e, lsl #16
    7e5c:	b9004be0 	str	w0, [sp, #72]
    7e60:	17fffda2 	b	74e8 <fwp_write+0x5a8>
    7e64:	528005a1 	mov	w1, #0x2d                  	// #45
    7e68:	eb1603e2 	negs	x2, x22
    7e6c:	da1803e3 	ngc	x3, x24
    7e70:	910027e0 	add	x0, sp, #0x9
    7e74:	910023f3 	add	x19, sp, #0x8
    7e78:	390023e1 	strb	w1, [sp, #8]
    7e7c:	97ffebe9 	bl	2e20 <fwp_fmt_u128>
    7e80:	17ffffd4 	b	7dd0 <fwp_write+0xe90>
    7e84:	aa1703e2 	mov	x2, x23
    7e88:	aa1a03e3 	mov	x3, x26
    7e8c:	aa1603e0 	mov	x0, x22
    7e90:	aa1803e1 	mov	x1, x24
    7e94:	940011bf 	bl	c590 <__divti3>
    7e98:	aa0003e2 	mov	x2, x0
    7e9c:	aa0103e3 	mov	x3, x1
    7ea0:	b7f80201 	tbnz	x1, #63, 7ee0 <fwp_write+0xfa0>
    7ea4:	910023f3 	add	x19, sp, #0x8
    7ea8:	aa1303e0 	mov	x0, x19
    7eac:	97ffebdd 	bl	2e20 <fwp_fmt_u128>
    7eb0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    7eb4:	910aa339 	add	x25, x25, #0x2a8
    7eb8:	910123f5 	add	x21, sp, #0x48
    7ebc:	aa1303e4 	mov	x4, x19
    7ec0:	aa1503e0 	mov	x0, x21
    7ec4:	d0000023 	adrp	x3, d000 <_IO_stdin_used+0x350>
    7ec8:	f8616b25 	ldr	x5, [x25, x1]
    7ecc:	9105e063 	add	x3, x3, #0x178
    7ed0:	d2804002 	mov	x2, #0x200                 	// #512
    7ed4:	52800041 	mov	w1, #0x2                   	// #2
    7ed8:	97ffea12 	bl	2720 <__sprintf_chk@plt>
    7edc:	17ffffc5 	b	7df0 <fwp_write+0xeb0>
    7ee0:	528005a4 	mov	w4, #0x2d                  	// #45
    7ee4:	eb0003e2 	negs	x2, x0
    7ee8:	da0103e3 	ngc	x3, x1
    7eec:	910027e0 	add	x0, sp, #0x9
    7ef0:	910023f3 	add	x19, sp, #0x8
    7ef4:	390023e4 	strb	w4, [sp, #8]
    7ef8:	97ffebca 	bl	2e20 <fwp_fmt_u128>
    7efc:	17ffffed 	b	7eb0 <fwp_write+0xf70>
    7f00:	f9013bf5 	str	x21, [sp, #624]
    7f04:	f9013ff6 	str	x22, [sp, #632]
    7f08:	f90143f7 	str	x23, [sp, #640]
    7f0c:	f90147f8 	str	x24, [sp, #648]
    7f10:	f9014bf9 	str	x25, [sp, #656]
    7f14:	f9014ffa 	str	x26, [sp, #664]
    7f18:	f90153fb 	str	x27, [sp, #672]
    7f1c:	f90157fc 	str	x28, [sp, #680]
    7f20:	fd015be8 	str	d8, [sp, #688]
    7f24:	fd015fe9 	str	d9, [sp, #696]
    7f28:	97ffea56 	bl	2880 <__stack_chk_fail@plt>
    7f2c:	d503201f 	nop

0000000000007f30 <fwp_hof0.constprop.0>:
    7f30:	d10543ff 	sub	sp, sp, #0x150
    7f34:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    7f38:	f947f442 	ldr	x2, [x2, #4072]
    7f3c:	a90e7bfd 	stp	x29, x30, [sp, #224]
    7f40:	910383fd 	add	x29, sp, #0xe0
    7f44:	f90023e0 	str	x0, [sp, #64]
    7f48:	f9400040 	ldr	x0, [x2]
    7f4c:	f9006fe0 	str	x0, [sp, #216]
    7f50:	d2800000 	mov	x0, #0x0                   	// #0
    7f54:	f90027e1 	str	x1, [sp, #72]
    7f58:	b400a321 	cbz	x1, 93bc <fwp_hof0.constprop.0+0x148c>
    7f5c:	b00000c0 	adrp	x0, 20000 <__data_start>
    7f60:	91004000 	add	x0, x0, #0x10
    7f64:	f90017e0 	str	x0, [sp, #40]
    7f68:	910183e0 	add	x0, sp, #0x60
    7f6c:	f90013e0 	str	x0, [sp, #32]
    7f70:	d0000020 	adrp	x0, d000 <_IO_stdin_used+0x350>
    7f74:	fd00a3e8 	str	d8, [sp, #320]
    7f78:	910163e1 	add	x1, sp, #0x58
    7f7c:	fd44d008 	ldr	d8, [x0, #2464]
    7f80:	f9000fe1 	str	x1, [sp, #24]
    7f84:	a90f53f3 	stp	x19, x20, [sp, #240]
    7f88:	d0000154 	adrp	x20, 31000 <fwp_root_context+0xca0>
    7f8c:	a9105bf5 	stp	x21, x22, [sp, #256]
    7f90:	a91163f7 	stp	x23, x24, [sp, #272]
    7f94:	a9126bf9 	stp	x25, x26, [sp, #288]
    7f98:	a91373fb 	stp	x27, x28, [sp, #304]
    7f9c:	91150282 	add	x2, x20, #0x540
    7fa0:	f94023e0 	ldr	x0, [sp, #64]
    7fa4:	f949ec43 	ldr	x3, [x2, #5080]
    7fa8:	f949d841 	ldr	x1, [x2, #5040]
    7fac:	d370bc63 	lsl	x3, x3, #16
    7fb0:	cb010004 	sub	x4, x0, x1
    7fb4:	eb03009f 	cmp	x4, x3
    7fb8:	540003e2 	b.cs	8034 <fwp_hof0.constprop.0+0x104>  // b.hs, b.nlast
    7fbc:	d350fc80 	lsr	x0, x4, #16
    7fc0:	f949fc46 	ldr	x6, [x2, #5112]
    7fc4:	8b000800 	add	x0, x0, x0, lsl #2
    7fc8:	d37df002 	lsl	x2, x0, #3
    7fcc:	8b0200c5 	add	x5, x6, x2
    7fd0:	f94010a0 	ldr	x0, [x5, #32]
    7fd4:	b4000300 	cbz	x0, 8034 <fwp_hof0.constprop.0+0x104>
    7fd8:	386268c2 	ldrb	w2, [x6, x2]
    7fdc:	7100085f 	cmp	w2, #0x2
    7fe0:	5400b820 	b.eq	96e4 <fwp_hof0.constprop.0+0x17b4>  // b.none
    7fe4:	7100045f 	cmp	w2, #0x1
    7fe8:	54000261 	b.ne	8034 <fwp_hof0.constprop.0+0x104>  // b.any
    7fec:	92403c82 	and	x2, x4, #0xffff
    7ff0:	294310a6 	ldp	w6, w4, [x5, #24]
    7ff4:	9b067c42 	mul	x2, x2, x6
    7ff8:	d360fc42 	lsr	x2, x2, #32
    7ffc:	eb04005f 	cmp	x2, x4
    8000:	540001a2 	b.cs	8034 <fwp_hof0.constprop.0+0x104>  // b.hs, b.nlast
    8004:	8b020000 	add	x0, x0, x2
    8008:	39400002 	ldrb	w2, [x0]
    800c:	34000142 	cbz	w2, 8034 <fwp_hof0.constprop.0+0x104>
    8010:	7103f45f 	cmp	w2, #0xfd
    8014:	5400c5c8 	b.hi	98cc <fwp_hof0.constprop.0+0x199c>  // b.pmore
    8018:	91150281 	add	x1, x20, #0x540
    801c:	11000442 	add	w2, w2, #0x1
    8020:	39000002 	strb	w2, [x0]
    8024:	aa0103e0 	mov	x0, x1
    8028:	f949d821 	ldr	x1, [x1, #5040]
    802c:	f949ec03 	ldr	x3, [x0, #5080]
    8030:	d370bc63 	lsl	x3, x3, #16
    8034:	f94023f5 	ldr	x21, [sp, #64]
    8038:	d28018c0 	mov	x0, #0xc6                  	// #198
    803c:	f90007e0 	str	x0, [sp, #8]
    8040:	900000c0 	adrp	x0, 20000 <__data_start>
    8044:	9100c002 	add	x2, x0, #0x30
    8048:	f94017e0 	ldr	x0, [sp, #40]
    804c:	12800004 	mov	w4, #0xffffffff            	// #-1
    8050:	b9005be4 	str	w4, [sp, #88]
    8054:	cb010001 	sub	x1, x0, x1
    8058:	b0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0x15c>
    805c:	913c4000 	add	x0, x0, #0xf10
    8060:	f90037e0 	str	x0, [sp, #104]
    8064:	f9416040 	ldr	x0, [x2, #704]
    8068:	f90033e0 	str	x0, [sp, #96]
    806c:	f9400fe0 	ldr	x0, [sp, #24]
    8070:	f9003be0 	str	x0, [sp, #112]
    8074:	f94013e0 	ldr	x0, [sp, #32]
    8078:	f9016040 	str	x0, [x2, #704]
    807c:	eb03003f 	cmp	x1, x3
    8080:	54000782 	b.cs	8170 <fwp_hof0.constprop.0+0x240>  // b.hs, b.nlast
    8084:	91150282 	add	x2, x20, #0x540
    8088:	d350fc20 	lsr	x0, x1, #16
    808c:	8b000800 	add	x0, x0, x0, lsl #2
    8090:	f949fc44 	ldr	x4, [x2, #5112]
    8094:	d37df003 	lsl	x3, x0, #3
    8098:	8b030082 	add	x2, x4, x3
    809c:	f9401053 	ldr	x19, [x2, #32]
    80a0:	b4000693 	cbz	x19, 8170 <fwp_hof0.constprop.0+0x240>
    80a4:	38636880 	ldrb	w0, [x4, x3]
    80a8:	7100081f 	cmp	w0, #0x2
    80ac:	5400a580 	b.eq	955c <fwp_hof0.constprop.0+0x162c>  // b.none
    80b0:	7100041f 	cmp	w0, #0x1
    80b4:	540005e1 	b.ne	8170 <fwp_hof0.constprop.0+0x240>  // b.any
    80b8:	29430c44 	ldp	w4, w3, [x2, #24]
    80bc:	92403c20 	and	x0, x1, #0xffff
    80c0:	9b047c00 	mul	x0, x0, x4
    80c4:	d360fc00 	lsr	x0, x0, #32
    80c8:	eb03001f 	cmp	x0, x3
    80cc:	540002a2 	b.cs	8120 <fwp_hof0.constprop.0+0x1f0>  // b.hs, b.nlast
    80d0:	8b000260 	add	x0, x19, x0
    80d4:	39400003 	ldrb	w3, [x0]
    80d8:	34000243 	cbz	w3, 8120 <fwp_hof0.constprop.0+0x1f0>
    80dc:	7103f47f 	cmp	w3, #0xfd
    80e0:	5400bb68 	b.hi	984c <fwp_hof0.constprop.0+0x191c>  // b.pmore
    80e4:	11000463 	add	w3, w3, #0x1
    80e8:	39000003 	strb	w3, [x0]
    80ec:	91150280 	add	x0, x20, #0x540
    80f0:	f94017e3 	ldr	x3, [sp, #40]
    80f4:	f949d801 	ldr	x1, [x0, #5040]
    80f8:	f949ec02 	ldr	x2, [x0, #5080]
    80fc:	cb010061 	sub	x1, x3, x1
    8100:	eb02403f 	cmp	x1, x2, lsl #16
    8104:	54000362 	b.cs	8170 <fwp_hof0.constprop.0+0x240>  // b.hs, b.nlast
    8108:	f949fc00 	ldr	x0, [x0, #5112]
    810c:	d350fc22 	lsr	x2, x1, #16
    8110:	8b020842 	add	x2, x2, x2, lsl #2
    8114:	8b020c02 	add	x2, x0, x2, lsl #3
    8118:	f9401053 	ldr	x19, [x2, #32]
    811c:	b40002b3 	cbz	x19, 8170 <fwp_hof0.constprop.0+0x240>
    8120:	39400040 	ldrb	w0, [x2]
    8124:	7100081f 	cmp	w0, #0x2
    8128:	5400a140 	b.eq	9550 <fwp_hof0.constprop.0+0x1620>  // b.none
    812c:	7100041f 	cmp	w0, #0x1
    8130:	54000201 	b.ne	8170 <fwp_hof0.constprop.0+0x240>  // b.any
    8134:	29430043 	ldp	w3, w0, [x2, #24]
    8138:	92403c21 	and	x1, x1, #0xffff
    813c:	9b037c21 	mul	x1, x1, x3
    8140:	d360fc21 	lsr	x1, x1, #32
    8144:	eb00003f 	cmp	x1, x0
    8148:	54000142 	b.cs	8170 <fwp_hof0.constprop.0+0x240>  // b.hs, b.nlast
    814c:	8b010273 	add	x19, x19, x1
    8150:	39400261 	ldrb	w1, [x19]
    8154:	340000e1 	cbz	w1, 8170 <fwp_hof0.constprop.0+0x240>
    8158:	7100043f 	cmp	w1, #0x1
    815c:	54007960 	b.eq	9088 <fwp_hof0.constprop.0+0x1158>  // b.none
    8160:	7103fc3f 	cmp	w1, #0xff
    8164:	5400b780 	b.eq	9854 <fwp_hof0.constprop.0+0x1924>  // b.none
    8168:	51000421 	sub	w1, w1, #0x1
    816c:	39000261 	strb	w1, [x19]
    8170:	b40079d5 	cbz	x21, 90a8 <fwp_hof0.constprop.0+0x1178>
    8174:	aa1503e0 	mov	x0, x21
    8178:	d2800001 	mov	x1, #0x0                   	// #0
    817c:	d503201f 	nop
    8180:	f9400800 	ldr	x0, [x0, #16]
    8184:	91000421 	add	x1, x1, #0x1
    8188:	b5ffffc0 	cbnz	x0, 8180 <fwp_hof0.constprop.0+0x250>
    818c:	aa0103f7 	mov	x23, x1
    8190:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    8194:	eb00003f 	cmp	x1, x0
    8198:	5400bea8 	b.hi	996c <fwp_hof0.constprop.0+0x1a3c>  // b.pmore
    819c:	900000c0 	adrp	x0, 20000 <__data_start>
    81a0:	9100c013 	add	x19, x0, #0x30
    81a4:	b942f660 	ldr	w0, [x19, #756]
    81a8:	340078c0 	cbz	w0, 90c0 <fwp_hof0.constprop.0+0x1190>
    81ac:	900000c0 	adrp	x0, 20000 <__data_start>
    81b0:	9100c000 	add	x0, x0, #0x30
    81b4:	f9402013 	ldr	x19, [x0, #64]
    81b8:	f9404c16 	ldr	x22, [x0, #152]
    81bc:	eb1302df 	cmp	x22, x19
    81c0:	5400726a 	b.ge	900c <fwp_hof0.constprop.0+0x10dc>  // b.tcont
    81c4:	900000c1 	adrp	x1, 20000 <__data_start>
    81c8:	8b1606c0 	add	x0, x22, x22, lsl #1
    81cc:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    81d0:	f9401821 	ldr	x1, [x1, #48]
    81d4:	8b000ac0 	add	x0, x22, x0, lsl #2
    81d8:	8b000c20 	add	x0, x1, x0, lsl #3
    81dc:	d503201f 	nop
    81e0:	b9400401 	ldr	w1, [x0, #4]
    81e4:	35000081 	cbnz	w1, 81f4 <fwp_hof0.constprop.0+0x2c4>
    81e8:	b9400001 	ldr	w1, [x0]
    81ec:	6b02003f 	cmp	w1, w2
    81f0:	540070e9 	b.ls	900c <fwp_hof0.constprop.0+0x10dc>  // b.plast
    81f4:	910006d6 	add	x22, x22, #0x1
    81f8:	9101a000 	add	x0, x0, #0x68
    81fc:	eb1302df 	cmp	x22, x19
    8200:	54ffff01 	b.ne	81e0 <fwp_hof0.constprop.0+0x2b0>  // b.any
    8204:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8208:	eb00027f 	cmp	x19, x0
    820c:	5400baac 	b.gt	9960 <fwp_hof0.constprop.0+0x1a30>
    8210:	900000c0 	adrp	x0, 20000 <__data_start>
    8214:	9100c000 	add	x0, x0, #0x30
    8218:	900000c1 	adrp	x1, 20000 <__data_start>
    821c:	f9404800 	ldr	x0, [x0, #144]
    8220:	f940183c 	ldr	x28, [x1, #48]
    8224:	eb13001f 	cmp	x0, x19
    8228:	54000241 	b.ne	8270 <fwp_hof0.constprop.0+0x340>  // b.any
    822c:	b400a3f3 	cbz	x19, 96a8 <fwp_hof0.constprop.0+0x1778>
    8230:	d37ffa7b 	lsl	x27, x19, #1
    8234:	d29fffe0 	mov	x0, #0xffff                	// #65535
    8238:	eb00037f 	cmp	x27, x0
    823c:	9a80d37b 	csel	x27, x27, x0, le
    8240:	8b1b0761 	add	x1, x27, x27, lsl #1
    8244:	8b010b61 	add	x1, x27, x1, lsl #2
    8248:	d37df021 	lsl	x1, x1, #3
    824c:	aa1c03e0 	mov	x0, x28
    8250:	97ffe988 	bl	2870 <realloc@plt>
    8254:	aa0003fc 	mov	x28, x0
    8258:	b40037c0 	cbz	x0, 8950 <fwp_hof0.constprop.0+0xa20>
    825c:	900000c0 	adrp	x0, 20000 <__data_start>
    8260:	9100c000 	add	x0, x0, #0x30
    8264:	900000c1 	adrp	x1, 20000 <__data_start>
    8268:	f900183c 	str	x28, [x1, #48]
    826c:	f900481b 	str	x27, [x0, #144]
    8270:	8b130660 	add	x0, x19, x19, lsl #1
    8274:	8b1606db 	add	x27, x22, x22, lsl #1
    8278:	4f000400 	movi	v0.4s, #0x0
    827c:	91000662 	add	x2, x19, #0x1
    8280:	8b000a60 	add	x0, x19, x0, lsl #2
    8284:	8b1b0adb 	add	x27, x22, x27, lsl #2
    8288:	900000c1 	adrp	x1, 20000 <__data_start>
    828c:	9100c021 	add	x1, x1, #0x30
    8290:	8b000f80 	add	x0, x28, x0, lsl #3
    8294:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    8298:	f9002022 	str	x2, [x1, #64]
    829c:	ad000000 	stp	q0, q0, [x0]
    82a0:	ad010000 	stp	q0, q0, [x0, #32]
    82a4:	ad020000 	stp	q0, q0, [x0, #64]
    82a8:	f900301f 	str	xzr, [x0, #96]
    82ac:	90000020 	adrp	x0, c000 <f0+0x2630>
    82b0:	f900337f 	str	xzr, [x27, #96]
    82b4:	913ba000 	add	x0, x0, #0xee8
    82b8:	97ffe9d6 	bl	2a10 <getenv@plt>
    82bc:	b4006c00 	cbz	x0, 903c <fwp_hof0.constprop.0+0x110c>
    82c0:	39400001 	ldrb	w1, [x0]
    82c4:	7100c03f 	cmp	w1, #0x30
    82c8:	54006ba1 	b.ne	903c <fwp_hof0.constprop.0+0x110c>  // b.any
    82cc:	39400400 	ldrb	w0, [x0, #1]
    82d0:	35006b60 	cbnz	w0, 903c <fwp_hof0.constprop.0+0x110c>
    82d4:	900000c0 	adrp	x0, 20000 <__data_start>
    82d8:	9100c000 	add	x0, x0, #0x30
    82dc:	2f000400 	mvni	v0.2s, #0x0
    82e0:	b9400373 	ldr	w19, [x27]
    82e4:	52800022 	mov	w2, #0x1                   	// #1
    82e8:	910006c4 	add	x4, x22, #0x1
    82ec:	f9416001 	ldr	x1, [x0, #704]
    82f0:	0b020273 	add	w19, w19, w2
    82f4:	29000b73 	stp	w19, w2, [x27]
    82f8:	a900df77 	stp	x23, x23, [x27, #8]
    82fc:	f9002b7f 	str	xzr, [x27, #80]
    8300:	f9004c04 	str	x4, [x0, #152]
    8304:	fd002f60 	str	d0, [x27, #88]
    8308:	b400b261 	cbz	x1, 9954 <fwp_hof0.constprop.0+0x1a24>
    830c:	b0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0x15c>
    8310:	913c4003 	add	x3, x0, #0xf10
    8314:	14000003 	b	8320 <fwp_hof0.constprop.0+0x3f0>
    8318:	f9400021 	ldr	x1, [x1]
    831c:	b400b1c1 	cbz	x1, 9954 <fwp_hof0.constprop.0+0x1a24>
    8320:	f9400422 	ldr	x2, [x1, #8]
    8324:	eb03005f 	cmp	x2, x3
    8328:	54ffff81 	b.ne	8318 <fwp_hof0.constprop.0+0x3e8>  // b.any
    832c:	f9400820 	ldr	x0, [x1, #16]
    8330:	2a1603e2 	mov	w2, w22
    8334:	b9400001 	ldr	w1, [x0]
    8338:	f9002b60 	str	x0, [x27, #80]
    833c:	b9005f61 	str	w1, [x27, #92]
    8340:	37f80081 	tbnz	w1, #31, 8350 <fwp_hof0.constprop.0+0x420>
    8344:	52800d03 	mov	w3, #0x68                  	// #104
    8348:	9b237021 	smaddl	x1, w1, w3, x28
    834c:	b9005836 	str	w22, [x1, #88]
    8350:	b9000002 	str	w2, [x0]
    8354:	d3707e73 	ubfiz	x19, x19, #16, #32
    8358:	aa040273 	orr	x19, x19, x4
    835c:	aa1503e0 	mov	x0, x21
    8360:	d2800002 	mov	x2, #0x0                   	// #0
    8364:	b4007235 	cbz	x21, 91a8 <fwp_hof0.constprop.0+0x1278>
    8368:	f9400800 	ldr	x0, [x0, #16]
    836c:	91000442 	add	x2, x2, #0x1
    8370:	b5ffffc0 	cbnz	x0, 8368 <fwp_hof0.constprop.0+0x438>
    8374:	aa1503e1 	mov	x1, x21
    8378:	f9400821 	ldr	x1, [x1, #16]
    837c:	91000400 	add	x0, x0, #0x1
    8380:	b5ffffc1 	cbnz	x1, 8378 <fwp_hof0.constprop.0+0x448>
    8384:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8388:	eb01001f 	cmp	x0, x1
    838c:	5400ade8 	b.hi	9948 <fwp_hof0.constprop.0+0x1a18>  // b.pmore
    8390:	f100005f 	cmp	x2, #0x0
    8394:	540070ad 	b.le	91a8 <fwp_hof0.constprop.0+0x1278>
    8398:	eb00005f 	cmp	x2, x0
    839c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    83a0:	9a809056 	csel	x22, x2, x0, ls	// ls = plast
    83a4:	eb0102df 	cmp	x22, x1
    83a8:	5400ad08 	b.hi	9948 <fwp_hof0.constprop.0+0x1a18>  // b.pmore
    83ac:	d37ffadc 	lsl	x28, x22, #1
    83b0:	52800041 	mov	w1, #0x2                   	// #2
    83b4:	91000780 	add	x0, x28, #0x1
    83b8:	d37df000 	lsl	x0, x0, #3
    83bc:	97fff22d 	bl	4c70 <fwp_heap_alloc>
    83c0:	aa0003f7 	mov	x23, x0
    83c4:	91150281 	add	x1, x20, #0x540
    83c8:	aa0003fb 	mov	x27, x0
    83cc:	aa0103e0 	mov	x0, x1
    83d0:	f90002fc 	str	x28, [x23]
    83d4:	f949d821 	ldr	x1, [x1, #5040]
    83d8:	f949ec00 	ldr	x0, [x0, #5080]
    83dc:	cb0102e1 	sub	x1, x23, x1
    83e0:	eb00403f 	cmp	x1, x0, lsl #16
    83e4:	54008022 	b.cs	93e8 <fwp_hof0.constprop.0+0x14b8>  // b.hs, b.nlast
    83e8:	91150282 	add	x2, x20, #0x540
    83ec:	d350fc20 	lsr	x0, x1, #16
    83f0:	8b000800 	add	x0, x0, x0, lsl #2
    83f4:	f949fc43 	ldr	x3, [x2, #5112]
    83f8:	d37df002 	lsl	x2, x0, #3
    83fc:	8b020060 	add	x0, x3, x2
    8400:	f940101c 	ldr	x28, [x0, #32]
    8404:	b400025c 	cbz	x28, 844c <fwp_hof0.constprop.0+0x51c>
    8408:	38626862 	ldrb	w2, [x3, x2]
    840c:	7100085f 	cmp	w2, #0x2
    8410:	54008900 	b.eq	9530 <fwp_hof0.constprop.0+0x1600>  // b.none
    8414:	7100045f 	cmp	w2, #0x1
    8418:	540001a1 	b.ne	844c <fwp_hof0.constprop.0+0x51c>  // b.any
    841c:	29430002 	ldp	w2, w0, [x0, #24]
    8420:	92403c21 	and	x1, x1, #0xffff
    8424:	9b027c21 	mul	x1, x1, x2
    8428:	d360fc21 	lsr	x1, x1, #32
    842c:	eb00003f 	cmp	x1, x0
    8430:	540000e2 	b.cs	844c <fwp_hof0.constprop.0+0x51c>  // b.hs, b.nlast
    8434:	8b01039c 	add	x28, x28, x1
    8438:	39400380 	ldrb	w0, [x28]
    843c:	7103fc1f 	cmp	w0, #0xff
    8440:	54008820 	b.eq	9544 <fwp_hof0.constprop.0+0x1614>  // b.none
    8444:	52800020 	mov	w0, #0x1                   	// #1
    8448:	39000380 	strb	w0, [x28]
    844c:	b4000236 	cbz	x22, 8490 <fwp_hof0.constprop.0+0x560>
    8450:	d3607e64 	lsl	x4, x19, #32
    8454:	aa1503e1 	mov	x1, x21
    8458:	f94006a5 	ldr	x5, [x21, #8]
    845c:	aa0403e3 	mov	x3, x4
    8460:	910022e2 	add	x2, x23, #0x8
    8464:	d2800000 	mov	x0, #0x0                   	// #0
    8468:	14000005 	b	847c <fwp_hof0.constprop.0+0x54c>
    846c:	f9400425 	ldr	x5, [x1, #8]
    8470:	ab000083 	adds	x3, x4, x0
    8474:	91004042 	add	x2, x2, #0x10
    8478:	5400aa46 	b.vs	99c0 <fwp_hof0.constprop.0+0x1a90>
    847c:	a9000c45 	stp	x5, x3, [x2]
    8480:	91000400 	add	x0, x0, #0x1
    8484:	f9400821 	ldr	x1, [x1, #16]
    8488:	eb16001f 	cmp	x0, x22
    848c:	54ffff03 	b.cc	846c <fwp_hof0.constprop.0+0x53c>  // b.lo, b.ul, b.last
    8490:	f94002e0 	ldr	x0, [x23]
    8494:	f100041f 	cmp	x0, #0x1
    8498:	54007ac9 	b.ls	93f0 <fwp_hof0.constprop.0+0x14c0>  // b.plast
    849c:	d341fc00 	lsr	x0, x0, #1
    84a0:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    84a4:	d1000401 	sub	x1, x0, #0x1
    84a8:	eb02003f 	cmp	x1, x2
    84ac:	5400a4e8 	b.hi	9948 <fwp_hof0.constprop.0+0x1a18>  // b.pmore
    84b0:	d37ff83c 	lsl	x28, x1, #1
    84b4:	b40079e1 	cbz	x1, 93f0 <fwp_hof0.constprop.0+0x14c0>
    84b8:	d10022e1 	sub	x1, x23, #0x8
    84bc:	910022f8 	add	x24, x23, #0x8
    84c0:	8b001036 	add	x22, x1, x0, lsl #4
    84c4:	d503201f 	nop
    84c8:	f9400700 	ldr	x0, [x24, #8]
    84cc:	f9400f01 	ldr	x1, [x24, #24]
    84d0:	fd400300 	ldr	d0, [x24]
    84d4:	fd400b01 	ldr	d1, [x24, #16]
    84d8:	97fff356 	bl	5230 <w120>
    84dc:	a9000700 	stp	x0, x1, [x24]
    84e0:	91004318 	add	x24, x24, #0x10
    84e4:	eb16031f 	cmp	x24, x22
    84e8:	54ffff01 	b.ne	84c8 <fwp_hof0.constprop.0+0x598>  // b.any
    84ec:	f90002fc 	str	x28, [x23]
    84f0:	9115029c 	add	x28, x20, #0x540
    84f4:	aa1703e0 	mov	x0, x23
    84f8:	97fff3ab 	bl	53a4 <w176.constprop.0>
    84fc:	aa0103f6 	mov	x22, x1
    8500:	f949db81 	ldr	x1, [x28, #5040]
    8504:	f949ef80 	ldr	x0, [x28, #5080]
    8508:	cb0102e1 	sub	x1, x23, x1
    850c:	eb00403f 	cmp	x1, x0, lsl #16
    8510:	54000382 	b.cs	8580 <fwp_hof0.constprop.0+0x650>  // b.hs, b.nlast
    8514:	d350fc20 	lsr	x0, x1, #16
    8518:	f949ff84 	ldr	x4, [x28, #5112]
    851c:	8b000800 	add	x0, x0, x0, lsl #2
    8520:	d37df000 	lsl	x0, x0, #3
    8524:	8b000082 	add	x2, x4, x0
    8528:	f9401057 	ldr	x23, [x2, #32]
    852c:	b40002b7 	cbz	x23, 8580 <fwp_hof0.constprop.0+0x650>
    8530:	38606880 	ldrb	w0, [x4, x0]
    8534:	7100081f 	cmp	w0, #0x2
    8538:	54007600 	b.eq	93f8 <fwp_hof0.constprop.0+0x14c8>  // b.none
    853c:	7100041f 	cmp	w0, #0x1
    8540:	54000201 	b.ne	8580 <fwp_hof0.constprop.0+0x650>  // b.any
    8544:	29430043 	ldp	w3, w0, [x2, #24]
    8548:	92403c21 	and	x1, x1, #0xffff
    854c:	9b037c21 	mul	x1, x1, x3
    8550:	d360fc21 	lsr	x1, x1, #32
    8554:	eb00003f 	cmp	x1, x0
    8558:	54000142 	b.cs	8580 <fwp_hof0.constprop.0+0x650>  // b.hs, b.nlast
    855c:	8b0102f7 	add	x23, x23, x1
    8560:	394002e0 	ldrb	w0, [x23]
    8564:	340000e0 	cbz	w0, 8580 <fwp_hof0.constprop.0+0x650>
    8568:	7100041f 	cmp	w0, #0x1
    856c:	540020a0 	b.eq	8980 <fwp_hof0.constprop.0+0xa50>  // b.none
    8570:	7103fc1f 	cmp	w0, #0xff
    8574:	54008be0 	b.eq	96f0 <fwp_hof0.constprop.0+0x17c0>  // b.none
    8578:	51000400 	sub	w0, w0, #0x1
    857c:	390002e0 	strb	w0, [x23]
    8580:	93407e73 	sxtw	x19, w19
    8584:	aa1303e0 	mov	x0, x19
    8588:	97ffecca 	bl	38b0 <fwp_tape_of>
    858c:	f9403001 	ldr	x1, [x0, #96]
    8590:	aa0003e8 	mov	x8, x0
    8594:	b5009f21 	cbnz	x1, 9978 <fwp_hof0.constprop.0+0x1a48>
    8598:	97ffea7e 	bl	2f90 <fwp_tape_unlink_scope>
    859c:	b9400002 	ldr	w2, [x0]
    85a0:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    85a4:	a940801c 	ldp	x28, x0, [x0, #8]
    85a8:	b900051f 	str	wzr, [x8, #4]
    85ac:	a941e50a 	ldp	x10, x25, [x8, #24]
    85b0:	a942ed1a 	ldp	x26, x27, [x8, #40]
    85b4:	a943e107 	ldp	x7, x24, [x8, #56]
    85b8:	f9402517 	ldr	x23, [x8, #72]
    85bc:	6b01005f 	cmp	w2, w1
    85c0:	54000128 	b.hi	85e4 <fwp_hof0.constprop.0+0x6b4>  // b.pmore
    85c4:	900000c1 	adrp	x1, 20000 <__data_start>
    85c8:	9100c022 	add	x2, x1, #0x30
    85cc:	92403e61 	and	x1, x19, #0xffff
    85d0:	d1000421 	sub	x1, x1, #0x1
    85d4:	f9404c49 	ldr	x9, [x2, #152]
    85d8:	eb09003f 	cmp	x1, x9
    85dc:	5400004a 	b.ge	85e4 <fwp_hof0.constprop.0+0x6b4>  // b.tcont
    85e0:	f9004c41 	str	x1, [x2, #152]
    85e4:	4f000400 	movi	v0.4s, #0x0
    85e8:	900000c1 	adrp	x1, 20000 <__data_start>
    85ec:	9100c029 	add	x9, x1, #0x30
    85f0:	f9000d1f 	str	xzr, [x8, #24]
    85f4:	a9047d1f 	stp	xzr, xzr, [x8, #64]
    85f8:	910243e3 	add	x3, sp, #0x90
    85fc:	9101e3e1 	add	x1, sp, #0x78
    8600:	f941612b 	ldr	x11, [x9, #704]
    8604:	3c808100 	stur	q0, [x8, #8]
    8608:	90ffffe2 	adrp	x2, 4000 <fwp_heap_init+0x17c>
    860c:	ad010100 	stp	q0, q0, [x8, #32]
    8610:	91040042 	add	x2, x2, #0x100
    8614:	f9000be3 	str	x3, [sp, #16]
    8618:	a9078beb 	stp	x11, x2, [sp, #120]
    861c:	a908e7e3 	stp	x3, x25, [sp, #136]
    8620:	a909effa 	stp	x26, x27, [sp, #152]
    8624:	a90ae3e7 	stp	x7, x24, [sp, #168]
    8628:	a90bdfea 	stp	x10, x23, [sp, #184]
    862c:	f9016121 	str	x1, [x9, #704]
    8630:	b7f879f6 	tbnz	x22, #63, 956c <fwp_hof0.constprop.0+0x163c>
    8634:	eb96827f 	cmp	x19, x22, asr #32
    8638:	540093e1 	b.ne	98b4 <fwp_hof0.constprop.0+0x1984>  // b.any
    863c:	92407ed3 	and	x19, x22, #0xffffffff
    8640:	eb36401f 	cmp	x0, w22, uxtw
    8644:	540093ed 	b.le	98c0 <fwp_hof0.constprop.0+0x1990>
    8648:	eb1c027f 	cmp	x19, x28
    864c:	9a93b793 	csinc	x19, x28, x19, lt	// lt = tstop
    8650:	eb1302ff 	cmp	x23, x19
    8654:	5400168a 	b.ge	8924 <fwp_hof0.constprop.0+0x9f4>  // b.tcont
    8658:	f10002ff 	cmp	x23, #0x0
    865c:	9a9312f7 	csel	x23, x23, x19, ne	// ne = any
    8660:	14000005 	b	8674 <fwp_hof0.constprop.0+0x744>
    8664:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    8668:	eb0002ff 	cmp	x23, x0
    866c:	d37ffaf7 	lsl	x23, x23, #1
    8670:	9a93d2f7 	csel	x23, x23, x19, le
    8674:	eb1302ff 	cmp	x23, x19
    8678:	54ffff6b 	b.lt	8664 <fwp_hof0.constprop.0+0x734>  // b.tstop
    867c:	f9001be7 	str	x7, [sp, #48]
    8680:	b4007f58 	cbz	x24, 9668 <fwp_hof0.constprop.0+0x1738>
    8684:	aa1803e0 	mov	x0, x24
    8688:	d37df2e1 	lsl	x1, x23, #3
    868c:	97ffe879 	bl	2870 <realloc@plt>
    8690:	aa0003f8 	mov	x24, x0
    8694:	f9401be7 	ldr	x7, [sp, #48]
    8698:	b4009838 	cbz	x24, 999c <fwp_hof0.constprop.0+0x1a6c>
    869c:	f9005bf8 	str	x24, [sp, #176]
    86a0:	f90063f7 	str	x23, [sp, #192]
    86a4:	b5001333 	cbnz	x19, 8908 <fwp_hof0.constprop.0+0x9d8>
    86a8:	b7f800d6 	tbnz	x22, #63, 86c0 <fwp_hof0.constprop.0+0x790>
    86ac:	92407ec1 	and	x1, x22, #0xffffffff
    86b0:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    86b4:	fc617b00 	ldr	d0, [x24, x1, lsl #3]
    86b8:	1e612800 	fadd	d0, d0, d1
    86bc:	fc217b00 	str	d0, [x24, x1, lsl #3]
    86c0:	d1000673 	sub	x19, x19, #0x1
    86c4:	d1000788 	sub	x8, x28, #0x1
    86c8:	eb13039f 	cmp	x28, x19
    86cc:	540003ac 	b.gt	8740 <fwp_hof0.constprop.0+0x810>
    86d0:	fc737b00 	ldr	d0, [x24, x19, lsl #3]
    86d4:	1e602008 	fcmp	d0, #0.0
    86d8:	540002e0 	b.eq	8734 <fwp_hof0.constprop.0+0x804>  // b.none
    86dc:	cb1c0be0 	neg	x0, x28, lsl #2
    86e0:	cb1c03e2 	neg	x2, x28
    86e4:	8b000321 	add	x1, x25, x0
    86e8:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    86ec:	37f80101 	tbnz	w1, #31, 870c <fwp_hof0.constprop.0+0x7dc>
    86f0:	8b020f69 	add	x9, x27, x2, lsl #3
    86f4:	93407c21 	sxtw	x1, w1
    86f8:	fc737922 	ldr	d2, [x9, x19, lsl #3]
    86fc:	fc617b01 	ldr	d1, [x24, x1, lsl #3]
    8700:	1e620802 	fmul	d2, d0, d2
    8704:	1e622821 	fadd	d1, d1, d2
    8708:	fc217b01 	str	d1, [x24, x1, lsl #3]
    870c:	8b000340 	add	x0, x26, x0
    8710:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    8714:	37f80100 	tbnz	w0, #31, 8734 <fwp_hof0.constprop.0+0x804>
    8718:	8b020ce2 	add	x2, x7, x2, lsl #3
    871c:	93407c00 	sxtw	x0, w0
    8720:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    8724:	fc607b01 	ldr	d1, [x24, x0, lsl #3]
    8728:	1e620800 	fmul	d0, d0, d2
    872c:	1e602820 	fadd	d0, d1, d0
    8730:	fc207b00 	str	d0, [x24, x0, lsl #3]
    8734:	d1000673 	sub	x19, x19, #0x1
    8738:	eb13011f 	cmp	x8, x19
    873c:	54fffca1 	b.ne	86d0 <fwp_hof0.constprop.0+0x7a0>  // b.any
    8740:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8744:	eb00039f 	cmp	x28, x0
    8748:	54009248 	b.hi	9990 <fwp_hof0.constprop.0+0x1a60>  // b.pmore
    874c:	91000780 	add	x0, x28, #0x1
    8750:	52800041 	mov	w1, #0x2                   	// #2
    8754:	d37df000 	lsl	x0, x0, #3
    8758:	97fff146 	bl	4c70 <fwp_heap_alloc>
    875c:	aa0003e2 	mov	x2, x0
    8760:	aa0003f3 	mov	x19, x0
    8764:	d2800001 	mov	x1, #0x0                   	// #0
    8768:	f800845c 	str	x28, [x2], #8
    876c:	b40000dc 	cbz	x28, 8784 <fwp_hof0.constprop.0+0x854>
    8770:	f8617b00 	ldr	x0, [x24, x1, lsl #3]
    8774:	f8217840 	str	x0, [x2, x1, lsl #3]
    8778:	91000421 	add	x1, x1, #0x1
    877c:	eb01039f 	cmp	x28, x1
    8780:	54ffff81 	b.ne	8770 <fwp_hof0.constprop.0+0x840>  // b.any
    8784:	900000c0 	adrp	x0, 20000 <__data_start>
    8788:	9100c001 	add	x1, x0, #0x30
    878c:	f9400be0 	ldr	x0, [sp, #16]
    8790:	f9403ff7 	ldr	x23, [sp, #120]
    8794:	f9016037 	str	x23, [x1, #704]
    8798:	97ffee5a 	bl	4100 <fwp_tape_buffers_release>
    879c:	91150282 	add	x2, x20, #0x540
    87a0:	f949d841 	ldr	x1, [x2, #5040]
    87a4:	f949ec40 	ldr	x0, [x2, #5080]
    87a8:	cb010261 	sub	x1, x19, x1
    87ac:	eb00403f 	cmp	x1, x0, lsl #16
    87b0:	54000322 	b.cs	8814 <fwp_hof0.constprop.0+0x8e4>  // b.hs, b.nlast
    87b4:	d350fc20 	lsr	x0, x1, #16
    87b8:	f949fc43 	ldr	x3, [x2, #5112]
    87bc:	8b000800 	add	x0, x0, x0, lsl #2
    87c0:	d37df002 	lsl	x2, x0, #3
    87c4:	8b020060 	add	x0, x3, x2
    87c8:	f9401016 	ldr	x22, [x0, #32]
    87cc:	b4000256 	cbz	x22, 8814 <fwp_hof0.constprop.0+0x8e4>
    87d0:	38626862 	ldrb	w2, [x3, x2]
    87d4:	7100085f 	cmp	w2, #0x2
    87d8:	54006ce0 	b.eq	9574 <fwp_hof0.constprop.0+0x1644>  // b.none
    87dc:	7100045f 	cmp	w2, #0x1
    87e0:	540001a1 	b.ne	8814 <fwp_hof0.constprop.0+0x8e4>  // b.any
    87e4:	29430002 	ldp	w2, w0, [x0, #24]
    87e8:	92403c21 	and	x1, x1, #0xffff
    87ec:	9b027c21 	mul	x1, x1, x2
    87f0:	d360fc21 	lsr	x1, x1, #32
    87f4:	eb00003f 	cmp	x1, x0
    87f8:	540000e2 	b.cs	8814 <fwp_hof0.constprop.0+0x8e4>  // b.hs, b.nlast
    87fc:	8b0102d6 	add	x22, x22, x1
    8800:	394002c0 	ldrb	w0, [x22]
    8804:	7103fc1f 	cmp	w0, #0xff
    8808:	54006c00 	b.eq	9588 <fwp_hof0.constprop.0+0x1658>  // b.none
    880c:	52800020 	mov	w0, #0x1                   	// #1
    8810:	390002c0 	strb	w0, [x22]
    8814:	f94013e0 	ldr	x0, [sp, #32]
    8818:	eb0002ff 	cmp	x23, x0
    881c:	54008d41 	b.ne	99c4 <fwp_hof0.constprop.0+0x1a94>  // b.any
    8820:	900000c0 	adrp	x0, 20000 <__data_start>
    8824:	9100c001 	add	x1, x0, #0x30
    8828:	f9400fe0 	ldr	x0, [sp, #24]
    882c:	f94033e2 	ldr	x2, [sp, #96]
    8830:	f9016022 	str	x2, [x1, #704]
    8834:	97fff5b7 	bl	5f10 <fwp_tape_scope_release>
    8838:	f9400260 	ldr	x0, [x19]
    883c:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    8840:	b7f84540 	tbnz	x0, #63, 90e8 <fwp_hof0.constprop.0+0x11b8>
    8844:	91150282 	add	x2, x20, #0x540
    8848:	f949d840 	ldr	x0, [x2, #5040]
    884c:	f949ec41 	ldr	x1, [x2, #5080]
    8850:	cb000260 	sub	x0, x19, x0
    8854:	eb01401f 	cmp	x0, x1, lsl #16
    8858:	54004482 	b.cs	90e8 <fwp_hof0.constprop.0+0x11b8>  // b.hs, b.nlast
    885c:	d350fc01 	lsr	x1, x0, #16
    8860:	f949fc44 	ldr	x4, [x2, #5112]
    8864:	8b010821 	add	x1, x1, x1, lsl #2
    8868:	d37df021 	lsl	x1, x1, #3
    886c:	8b010083 	add	x3, x4, x1
    8870:	f9401062 	ldr	x2, [x3, #32]
    8874:	b40043a2 	cbz	x2, 90e8 <fwp_hof0.constprop.0+0x11b8>
    8878:	38616881 	ldrb	w1, [x4, x1]
    887c:	7100083f 	cmp	w1, #0x2
    8880:	540042e0 	b.eq	90dc <fwp_hof0.constprop.0+0x11ac>  // b.none
    8884:	7100043f 	cmp	w1, #0x1
    8888:	54004301 	b.ne	90e8 <fwp_hof0.constprop.0+0x11b8>  // b.any
    888c:	29430464 	ldp	w4, w1, [x3, #24]
    8890:	92403c00 	and	x0, x0, #0xffff
    8894:	9b047c00 	mul	x0, x0, x4
    8898:	d360fc00 	lsr	x0, x0, #32
    889c:	eb01001f 	cmp	x0, x1
    88a0:	54004242 	b.cs	90e8 <fwp_hof0.constprop.0+0x11b8>  // b.hs, b.nlast
    88a4:	8b000042 	add	x2, x2, x0
    88a8:	39400040 	ldrb	w0, [x2]
    88ac:	7100041f 	cmp	w0, #0x1
    88b0:	540041c1 	b.ne	90e8 <fwp_hof0.constprop.0+0x11b8>  // b.any
    88b4:	aa1303fc 	mov	x28, x19
    88b8:	aa1303f6 	mov	x22, x19
    88bc:	d2800000 	mov	x0, #0x0                   	// #0
    88c0:	910022c3 	add	x3, x22, #0x8
    88c4:	91002265 	add	x5, x19, #0x8
    88c8:	d2800001 	mov	x1, #0x0                   	// #0
    88cc:	b5000157 	cbnz	x23, 88f4 <fwp_hof0.constprop.0+0x9c4>
    88d0:	1400004d 	b	8a04 <fwp_hof0.constprop.0+0xad4>
    88d4:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    88d8:	f9400382 	ldr	x2, [x28]
    88dc:	1e600900 	fmul	d0, d8, d0
    88e0:	b7f882e2 	tbnz	x2, #63, 993c <fwp_hof0.constprop.0+0x1a0c>
    88e4:	91000421 	add	x1, x1, #0x1
    88e8:	fc008460 	str	d0, [x3], #8
    88ec:	eb0102ff 	cmp	x23, x1
    88f0:	540008a0 	b.eq	8a04 <fwp_hof0.constprop.0+0xad4>  // b.none
    88f4:	f9400264 	ldr	x4, [x19]
    88f8:	aa0503e2 	mov	x2, x5
    88fc:	b6fffec4 	tbz	x4, #63, 88d4 <fwp_hof0.constprop.0+0x9a4>
    8900:	f9400a62 	ldr	x2, [x19, #16]
    8904:	17fffff4 	b	88d4 <fwp_hof0.constprop.0+0x9a4>
    8908:	d37df262 	lsl	x2, x19, #3
    890c:	aa1803e0 	mov	x0, x24
    8910:	52800001 	mov	w1, #0x0                   	// #0
    8914:	f9001be7 	str	x7, [sp, #48]
    8918:	97ffe7ce 	bl	2850 <memset@plt>
    891c:	f9401be7 	ldr	x7, [sp, #48]
    8920:	17ffff62 	b	86a8 <fwp_hof0.constprop.0+0x778>
    8924:	f100031f 	cmp	x24, #0x0
    8928:	1a9f17e0 	cset	w0, eq	// eq = none
    892c:	f100027f 	cmp	x19, #0x0
    8930:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    8934:	54ffeb80 	b.eq	86a4 <fwp_hof0.constprop.0+0x774>  // b.none
    8938:	900000c0 	adrp	x0, 20000 <__data_start>
    893c:	9100c018 	add	x24, x0, #0x30
    8940:	f9400be0 	ldr	x0, [sp, #16]
    8944:	f9403fe1 	ldr	x1, [sp, #120]
    8948:	f9016301 	str	x1, [x24, #704]
    894c:	97ffeded 	bl	4100 <fwp_tape_buffers_release>
    8950:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    8954:	f947e863 	ldr	x3, [x3, #4048]
    8958:	d2800262 	mov	x2, #0x13                  	// #19
    895c:	d2800021 	mov	x1, #0x1                   	// #1
    8960:	90000020 	adrp	x0, c000 <f0+0x2630>
    8964:	9132e000 	add	x0, x0, #0xcb8
    8968:	f9400063 	ldr	x3, [x3]
    896c:	97ffe805 	bl	2980 <fwrite@plt>
    8970:	d2800000 	mov	x0, #0x0                   	// #0
    8974:	97ffe80f 	bl	29b0 <fflush@plt>
    8978:	52800cc0 	mov	w0, #0x66                  	// #102
    897c:	97ffe81d 	bl	29f0 <_Exit@plt>
    8980:	f9400365 	ldr	x5, [x27]
    8984:	aa1b03e0 	mov	x0, x27
    8988:	f949ef83 	ldr	x3, [x28, #5080]
    898c:	f949db81 	ldr	x1, [x28, #5040]
    8990:	d370bc63 	lsl	x3, x3, #16
    8994:	cb010362 	sub	x2, x27, x1
    8998:	b7f853c5 	tbnz	x5, #63, 9410 <fwp_hof0.constprop.0+0x14e0>
    899c:	eb02007f 	cmp	x3, x2
    89a0:	54ffdf09 	b.ls	8580 <fwp_hof0.constprop.0+0x650>  // b.plast
    89a4:	d350fc40 	lsr	x0, x2, #16
    89a8:	8b000800 	add	x0, x0, x0, lsl #2
    89ac:	d37df000 	lsl	x0, x0, #3
    89b0:	8b000083 	add	x3, x4, x0
    89b4:	f9401061 	ldr	x1, [x3, #32]
    89b8:	b4ffde41 	cbz	x1, 8580 <fwp_hof0.constprop.0+0x650>
    89bc:	38606880 	ldrb	w0, [x4, x0]
    89c0:	7100081f 	cmp	w0, #0x2
    89c4:	54005e80 	b.eq	9594 <fwp_hof0.constprop.0+0x1664>  // b.none
    89c8:	7100041f 	cmp	w0, #0x1
    89cc:	54ffdda1 	b.ne	8580 <fwp_hof0.constprop.0+0x650>  // b.any
    89d0:	92403c40 	and	x0, x2, #0xffff
    89d4:	29430864 	ldp	w4, w2, [x3, #24]
    89d8:	9b047c00 	mul	x0, x0, x4
    89dc:	d360fc00 	lsr	x0, x0, #32
    89e0:	eb02001f 	cmp	x0, x2
    89e4:	54ffdce2 	b.cs	8580 <fwp_hof0.constprop.0+0x650>  // b.hs, b.nlast
    89e8:	8b000021 	add	x1, x1, x0
    89ec:	39400020 	ldrb	w0, [x1]
    89f0:	7100041f 	cmp	w0, #0x1
    89f4:	54ffdc61 	b.ne	8580 <fwp_hof0.constprop.0+0x650>  // b.any
    89f8:	aa1b03e0 	mov	x0, x27
    89fc:	97ffef7d 	bl	47f0 <fwp_mem_free>
    8a00:	17fffee0 	b	8580 <fwp_hof0.constprop.0+0x650>
    8a04:	97fff72f 	bl	66c0 <fwp_drop10>
    8a08:	aa1503e1 	mov	x1, x21
    8a0c:	d2800002 	mov	x2, #0x0                   	// #0
    8a10:	b4006395 	cbz	x21, 9680 <fwp_hof0.constprop.0+0x1750>
    8a14:	d503201f 	nop
    8a18:	f9400821 	ldr	x1, [x1, #16]
    8a1c:	91000442 	add	x2, x2, #0x1
    8a20:	b5ffffc1 	cbnz	x1, 8a18 <fwp_hof0.constprop.0+0xae8>
    8a24:	f9400384 	ldr	x4, [x28]
    8a28:	9240f885 	and	x5, x4, #0x7fffffffffffffff
    8a2c:	b7f82b64 	tbnz	x4, #63, 8f98 <fwp_hof0.constprop.0+0x1068>
    8a30:	91150281 	add	x1, x20, #0x540
    8a34:	f949d820 	ldr	x0, [x1, #5040]
    8a38:	f949ec21 	ldr	x1, [x1, #5080]
    8a3c:	cb0002c0 	sub	x0, x22, x0
    8a40:	eb01401f 	cmp	x0, x1, lsl #16
    8a44:	54002aa2 	b.cs	8f98 <fwp_hof0.constprop.0+0x1068>  // b.hs, b.nlast
    8a48:	91150283 	add	x3, x20, #0x540
    8a4c:	d350fc01 	lsr	x1, x0, #16
    8a50:	8b010821 	add	x1, x1, x1, lsl #2
    8a54:	f949fc67 	ldr	x7, [x3, #5112]
    8a58:	d37df021 	lsl	x1, x1, #3
    8a5c:	8b0100e6 	add	x6, x7, x1
    8a60:	f94010c3 	ldr	x3, [x6, #32]
    8a64:	b4002983 	cbz	x3, 8f94 <fwp_hof0.constprop.0+0x1064>
    8a68:	386168e1 	ldrb	w1, [x7, x1]
    8a6c:	7100083f 	cmp	w1, #0x2
    8a70:	540028e0 	b.eq	8f8c <fwp_hof0.constprop.0+0x105c>  // b.none
    8a74:	7100043f 	cmp	w1, #0x1
    8a78:	540028e1 	b.ne	8f94 <fwp_hof0.constprop.0+0x1064>  // b.any
    8a7c:	294304c7 	ldp	w7, w1, [x6, #24]
    8a80:	92403c00 	and	x0, x0, #0xffff
    8a84:	9b077c00 	mul	x0, x0, x7
    8a88:	d360fc00 	lsr	x0, x0, #32
    8a8c:	eb01001f 	cmp	x0, x1
    8a90:	54002822 	b.cs	8f94 <fwp_hof0.constprop.0+0x1064>  // b.hs, b.nlast
    8a94:	8b000063 	add	x3, x3, x0
    8a98:	39400060 	ldrb	w0, [x3]
    8a9c:	7100041f 	cmp	w0, #0x1
    8aa0:	540027a1 	b.ne	8f94 <fwp_hof0.constprop.0+0x1064>  // b.any
    8aa4:	b90033e0 	str	w0, [sp, #48]
    8aa8:	eb05005f 	cmp	x2, x5
    8aac:	9a859045 	csel	x5, x2, x5, ls	// ls = plast
    8ab0:	9100239b 	add	x27, x28, #0x8
    8ab4:	b4006c65 	cbz	x5, 9840 <fwp_hof0.constprop.0+0x1910>
    8ab8:	d37df0a7 	lsl	x7, x5, #3
    8abc:	aa1503e2 	mov	x2, x21
    8ac0:	910022c0 	add	x0, x22, #0x8
    8ac4:	d2800001 	mov	x1, #0x0                   	// #0
    8ac8:	1400000a 	b	8af0 <fwp_hof0.constprop.0+0xbc0>
    8acc:	fc6168c1 	ldr	d1, [x6, x1]
    8ad0:	fd400440 	ldr	d0, [x2, #8]
    8ad4:	1e613800 	fsub	d0, d0, d1
    8ad8:	fc216b60 	str	d0, [x27, x1]
    8adc:	91002021 	add	x1, x1, #0x8
    8ae0:	f9400842 	ldr	x2, [x2, #16]
    8ae4:	eb07003f 	cmp	x1, x7
    8ae8:	540001a0 	b.eq	8b1c <fwp_hof0.constprop.0+0xbec>  // b.none
    8aec:	f9400384 	ldr	x4, [x28]
    8af0:	aa0003e6 	mov	x6, x0
    8af4:	b6fffec4 	tbz	x4, #63, 8acc <fwp_hof0.constprop.0+0xb9c>
    8af8:	f9400ac6 	ldr	x6, [x22, #16]
    8afc:	fd400440 	ldr	d0, [x2, #8]
    8b00:	fc6168c1 	ldr	d1, [x6, x1]
    8b04:	1e613800 	fsub	d0, d0, d1
    8b08:	fc216b60 	str	d0, [x27, x1]
    8b0c:	91002021 	add	x1, x1, #0x8
    8b10:	f9400842 	ldr	x2, [x2, #16]
    8b14:	eb07003f 	cmp	x1, x7
    8b18:	54fffea1 	b.ne	8aec <fwp_hof0.constprop.0+0xbbc>  // b.any
    8b1c:	b4006c95 	cbz	x21, 98ac <fwp_hof0.constprop.0+0x197c>
    8b20:	91150280 	add	x0, x20, #0x540
    8b24:	aa1503e7 	mov	x7, x21
    8b28:	d2800017 	mov	x23, #0x0                   	// #0
    8b2c:	f949ec09 	ldr	x9, [x0, #5080]
    8b30:	f949d80a 	ldr	x10, [x0, #5040]
    8b34:	f949fc08 	ldr	x8, [x0, #5112]
    8b38:	d370bd29 	lsl	x9, x9, #16
    8b3c:	14000006 	b	8b54 <fwp_hof0.constprop.0+0xc24>
    8b40:	f94008e7 	ldr	x7, [x7, #16]
    8b44:	910006f7 	add	x23, x23, #0x1
    8b48:	f10000ff 	cmp	x7, #0x0
    8b4c:	fa5710a0 	ccmp	x5, x23, #0x0, ne	// ne = any
    8b50:	54000329 	b.ls	8bb4 <fwp_hof0.constprop.0+0xc84>  // b.plast
    8b54:	cb0a00e0 	sub	x0, x7, x10
    8b58:	eb09001f 	cmp	x0, x9
    8b5c:	540002c2 	b.cs	8bb4 <fwp_hof0.constprop.0+0xc84>  // b.hs, b.nlast
    8b60:	d350fc01 	lsr	x1, x0, #16
    8b64:	8b010821 	add	x1, x1, x1, lsl #2
    8b68:	d37df021 	lsl	x1, x1, #3
    8b6c:	8b010106 	add	x6, x8, x1
    8b70:	f94010c2 	ldr	x2, [x6, #32]
    8b74:	b4000202 	cbz	x2, 8bb4 <fwp_hof0.constprop.0+0xc84>
    8b78:	38616901 	ldrb	w1, [x8, x1]
    8b7c:	7100083f 	cmp	w1, #0x2
    8b80:	54000e00 	b.eq	8d40 <fwp_hof0.constprop.0+0xe10>  // b.none
    8b84:	7100043f 	cmp	w1, #0x1
    8b88:	54000161 	b.ne	8bb4 <fwp_hof0.constprop.0+0xc84>  // b.any
    8b8c:	294304cb 	ldp	w11, w1, [x6, #24]
    8b90:	92403c00 	and	x0, x0, #0xffff
    8b94:	9b0b7c00 	mul	x0, x0, x11
    8b98:	d360fc00 	lsr	x0, x0, #32
    8b9c:	eb01001f 	cmp	x0, x1
    8ba0:	540000a2 	b.cs	8bb4 <fwp_hof0.constprop.0+0xc84>  // b.hs, b.nlast
    8ba4:	8b000042 	add	x2, x2, x0
    8ba8:	39400040 	ldrb	w0, [x2]
    8bac:	7100041f 	cmp	w0, #0x1
    8bb0:	54fffc80 	b.eq	8b40 <fwp_hof0.constprop.0+0xc10>  // b.none
    8bb4:	eb1700bf 	cmp	x5, x23
    8bb8:	54000cc9 	b.ls	8d50 <fwp_hof0.constprop.0+0xe20>  // b.plast
    8bbc:	aa0503f8 	mov	x24, x5
    8bc0:	d1002379 	sub	x25, x27, #0x8
    8bc4:	910323f3 	add	x19, sp, #0xc8
    8bc8:	9115029a 	add	x26, x20, #0x540
    8bcc:	d280001c 	mov	x28, #0x0                   	// #0
    8bd0:	14000012 	b	8c18 <fwp_hof0.constprop.0+0xce8>
    8bd4:	7100045f 	cmp	w2, #0x1
    8bd8:	540001a1 	b.ne	8c0c <fwp_hof0.constprop.0+0xcdc>  // b.any
    8bdc:	29430909 	ldp	w9, w2, [x8, #24]
    8be0:	92403c21 	and	x1, x1, #0xffff
    8be4:	9b097c21 	mul	x1, x1, x9
    8be8:	d360fc21 	lsr	x1, x1, #32
    8bec:	eb02003f 	cmp	x1, x2
    8bf0:	540000e2 	b.cs	8c0c <fwp_hof0.constprop.0+0xcdc>  // b.hs, b.nlast
    8bf4:	8b010000 	add	x0, x0, x1
    8bf8:	39400001 	ldrb	w1, [x0]
    8bfc:	7103fc3f 	cmp	w1, #0xff
    8c00:	54002f00 	b.eq	91e0 <fwp_hof0.constprop.0+0x12b0>  // b.none
    8c04:	52800021 	mov	w1, #0x1                   	// #1
    8c08:	39000001 	strb	w1, [x0]
    8c0c:	d1000718 	sub	x24, x24, #0x1
    8c10:	eb17031f 	cmp	x24, x23
    8c14:	54000369 	b.ls	8c80 <fwp_hof0.constprop.0+0xd50>  // b.plast
    8c18:	f8787b22 	ldr	x2, [x25, x24, lsl #3]
    8c1c:	aa1303e1 	mov	x1, x19
    8c20:	52800020 	mov	w0, #0x1                   	// #1
    8c24:	a90cf3e2 	stp	x2, x28, [sp, #200]
    8c28:	97fff057 	bl	4d84 <fwp_data.part.0.constprop.0>
    8c2c:	aa0003fc 	mov	x28, x0
    8c30:	f949db41 	ldr	x1, [x26, #5040]
    8c34:	f949ef40 	ldr	x0, [x26, #5080]
    8c38:	cb010381 	sub	x1, x28, x1
    8c3c:	eb00403f 	cmp	x1, x0, lsl #16
    8c40:	54fffe62 	b.cs	8c0c <fwp_hof0.constprop.0+0xcdc>  // b.hs, b.nlast
    8c44:	d350fc20 	lsr	x0, x1, #16
    8c48:	f949ff49 	ldr	x9, [x26, #5112]
    8c4c:	8b000800 	add	x0, x0, x0, lsl #2
    8c50:	d37df002 	lsl	x2, x0, #3
    8c54:	8b020128 	add	x8, x9, x2
    8c58:	f9401100 	ldr	x0, [x8, #32]
    8c5c:	b4fffd80 	cbz	x0, 8c0c <fwp_hof0.constprop.0+0xcdc>
    8c60:	38626922 	ldrb	w2, [x9, x2]
    8c64:	7100085f 	cmp	w2, #0x2
    8c68:	54fffb61 	b.ne	8bd4 <fwp_hof0.constprop.0+0xca4>  // b.any
    8c6c:	72003c3f 	tst	w1, #0xffff
    8c70:	54fffc40 	b.eq	8bf8 <fwp_hof0.constprop.0+0xcc8>  // b.none
    8c74:	d1000718 	sub	x24, x24, #0x1
    8c78:	eb17031f 	cmp	x24, x23
    8c7c:	54fffce8 	b.hi	8c18 <fwp_hof0.constprop.0+0xce8>  // b.pmore
    8c80:	b50006b7 	cbnz	x23, 8d54 <fwp_hof0.constprop.0+0xe24>
    8c84:	b94033e0 	ldr	w0, [sp, #48]
    8c88:	d2800004 	mov	x4, #0x0                   	// #0
    8c8c:	7100001f 	cmp	w0, #0x0
    8c90:	d2800020 	mov	x0, #0x1                   	// #1
    8c94:	9a9f037b 	csel	x27, x27, xzr, eq	// eq = none
    8c98:	b40007c4 	cbz	x4, 8d90 <fwp_hof0.constprop.0+0xe60>
    8c9c:	d1000497 	sub	x23, x4, #0x1
    8ca0:	2a0003f9 	mov	w25, w0
    8ca4:	9115029a 	add	x26, x20, #0x540
    8ca8:	f8777b62 	ldr	x2, [x27, x23, lsl #3]
    8cac:	aa1303e1 	mov	x1, x19
    8cb0:	52800020 	mov	w0, #0x1                   	// #1
    8cb4:	a90cf3e2 	stp	x2, x28, [sp, #200]
    8cb8:	97fff033 	bl	4d84 <fwp_data.part.0.constprop.0>
    8cbc:	aa0003fc 	mov	x28, x0
    8cc0:	f949db41 	ldr	x1, [x26, #5040]
    8cc4:	f949ef40 	ldr	x0, [x26, #5080]
    8cc8:	cb010381 	sub	x1, x28, x1
    8ccc:	eb00403f 	cmp	x1, x0, lsl #16
    8cd0:	54000302 	b.cs	8d30 <fwp_hof0.constprop.0+0xe00>  // b.hs, b.nlast
    8cd4:	d350fc22 	lsr	x2, x1, #16
    8cd8:	f949ff47 	ldr	x7, [x26, #5112]
    8cdc:	8b020842 	add	x2, x2, x2, lsl #2
    8ce0:	d37df042 	lsl	x2, x2, #3
    8ce4:	8b0200e6 	add	x6, x7, x2
    8ce8:	f94010d8 	ldr	x24, [x6, #32]
    8cec:	b4000238 	cbz	x24, 8d30 <fwp_hof0.constprop.0+0xe00>
    8cf0:	386268e2 	ldrb	w2, [x7, x2]
    8cf4:	7100085f 	cmp	w2, #0x2
    8cf8:	54001440 	b.eq	8f80 <fwp_hof0.constprop.0+0x1050>  // b.none
    8cfc:	7100045f 	cmp	w2, #0x1
    8d00:	54000181 	b.ne	8d30 <fwp_hof0.constprop.0+0xe00>  // b.any
    8d04:	294308c7 	ldp	w7, w2, [x6, #24]
    8d08:	92403c21 	and	x1, x1, #0xffff
    8d0c:	9b077c21 	mul	x1, x1, x7
    8d10:	d360fc21 	lsr	x1, x1, #32
    8d14:	eb02003f 	cmp	x1, x2
    8d18:	540000c2 	b.cs	8d30 <fwp_hof0.constprop.0+0xe00>  // b.hs, b.nlast
    8d1c:	8b010318 	add	x24, x24, x1
    8d20:	39400301 	ldrb	w1, [x24]
    8d24:	7103fc3f 	cmp	w1, #0xff
    8d28:	54001260 	b.eq	8f74 <fwp_hof0.constprop.0+0x1044>  // b.none
    8d2c:	39000319 	strb	w25, [x24]
    8d30:	d10006f7 	sub	x23, x23, #0x1
    8d34:	b10006ff 	cmn	x23, #0x1
    8d38:	54fffb81 	b.ne	8ca8 <fwp_hof0.constprop.0+0xd78>  // b.any
    8d3c:	14000015 	b	8d90 <fwp_hof0.constprop.0+0xe60>
    8d40:	72003c1f 	tst	w0, #0xffff
    8d44:	54fff320 	b.eq	8ba8 <fwp_hof0.constprop.0+0xc78>  // b.none
    8d48:	eb1700bf 	cmp	x5, x23
    8d4c:	54fff388 	b.hi	8bbc <fwp_hof0.constprop.0+0xc8c>  // b.pmore
    8d50:	d280001c 	mov	x28, #0x0                   	// #0
    8d54:	8b170f64 	add	x4, x27, x23, lsl #3
    8d58:	aa1b03e1 	mov	x1, x27
    8d5c:	aa1503e0 	mov	x0, x21
    8d60:	f8408422 	ldr	x2, [x1], #8
    8d64:	f9000402 	str	x2, [x0, #8]
    8d68:	aa0003e2 	mov	x2, x0
    8d6c:	f9400800 	ldr	x0, [x0, #16]
    8d70:	eb04003f 	cmp	x1, x4
    8d74:	54ffff61 	b.ne	8d60 <fwp_hof0.constprop.0+0xe30>  // b.any
    8d78:	b94033e1 	ldr	w1, [sp, #48]
    8d7c:	f900085c 	str	x28, [x2, #16]
    8d80:	aa1503fc 	mov	x28, x21
    8d84:	aa0003f5 	mov	x21, x0
    8d88:	34000041 	cbz	w1, 8d90 <fwp_hof0.constprop.0+0xe60>
    8d8c:	d280001b 	mov	x27, #0x0                   	// #0
    8d90:	91150293 	add	x19, x20, #0x540
    8d94:	aa1b03e0 	mov	x0, x27
    8d98:	97ffee96 	bl	47f0 <fwp_mem_free>
    8d9c:	f949ee62 	ldr	x2, [x19, #5080]
    8da0:	f949da61 	ldr	x1, [x19, #5040]
    8da4:	d370bc42 	lsl	x2, x2, #16
    8da8:	cb0102c3 	sub	x3, x22, x1
    8dac:	eb02007f 	cmp	x3, x2
    8db0:	54000402 	b.cs	8e30 <fwp_hof0.constprop.0+0xf00>  // b.hs, b.nlast
    8db4:	d350fc60 	lsr	x0, x3, #16
    8db8:	f949fe65 	ldr	x5, [x19, #5112]
    8dbc:	8b000800 	add	x0, x0, x0, lsl #2
    8dc0:	d37df000 	lsl	x0, x0, #3
    8dc4:	8b0000a2 	add	x2, x5, x0
    8dc8:	f9401057 	ldr	x23, [x2, #32]
    8dcc:	b4000cb7 	cbz	x23, 8f60 <fwp_hof0.constprop.0+0x1030>
    8dd0:	386068a1 	ldrb	w1, [x5, x0]
    8dd4:	7100083f 	cmp	w1, #0x2
    8dd8:	54003160 	b.eq	9404 <fwp_hof0.constprop.0+0x14d4>  // b.none
    8ddc:	7100043f 	cmp	w1, #0x1
    8de0:	54000c01 	b.ne	8f60 <fwp_hof0.constprop.0+0x1030>  // b.any
    8de4:	29430844 	ldp	w4, w2, [x2, #24]
    8de8:	92403c61 	and	x1, x3, #0xffff
    8dec:	9b047c21 	mul	x1, x1, x4
    8df0:	d360fc21 	lsr	x1, x1, #32
    8df4:	eb02003f 	cmp	x1, x2
    8df8:	54000b42 	b.cs	8f60 <fwp_hof0.constprop.0+0x1030>  // b.hs, b.nlast
    8dfc:	8b0102f7 	add	x23, x23, x1
    8e00:	394002e1 	ldrb	w1, [x23]
    8e04:	34000ae1 	cbz	w1, 8f60 <fwp_hof0.constprop.0+0x1030>
    8e08:	7100043f 	cmp	w1, #0x1
    8e0c:	540006a0 	b.eq	8ee0 <fwp_hof0.constprop.0+0xfb0>  // b.none
    8e10:	7103fc3f 	cmp	w1, #0xff
    8e14:	54004a00 	b.eq	9754 <fwp_hof0.constprop.0+0x1824>  // b.none
    8e18:	91150280 	add	x0, x20, #0x540
    8e1c:	51000421 	sub	w1, w1, #0x1
    8e20:	390002e1 	strb	w1, [x23]
    8e24:	f949ec02 	ldr	x2, [x0, #5080]
    8e28:	f949d801 	ldr	x1, [x0, #5040]
    8e2c:	d370bc42 	lsl	x2, x2, #16
    8e30:	cb0102a1 	sub	x1, x21, x1
    8e34:	eb02003f 	cmp	x1, x2
    8e38:	540003c2 	b.cs	8eb0 <fwp_hof0.constprop.0+0xf80>  // b.hs, b.nlast
    8e3c:	91150296 	add	x22, x20, #0x540
    8e40:	d350fc20 	lsr	x0, x1, #16
    8e44:	f949fec3 	ldr	x3, [x22, #5112]
    8e48:	8b000800 	add	x0, x0, x0, lsl #2
    8e4c:	d37df000 	lsl	x0, x0, #3
    8e50:	8b000062 	add	x2, x3, x0
    8e54:	f9401053 	ldr	x19, [x2, #32]
    8e58:	b40002d3 	cbz	x19, 8eb0 <fwp_hof0.constprop.0+0xf80>
    8e5c:	38606860 	ldrb	w0, [x3, x0]
    8e60:	7100081f 	cmp	w0, #0x2
    8e64:	54003180 	b.eq	9494 <fwp_hof0.constprop.0+0x1564>  // b.none
    8e68:	7100041f 	cmp	w0, #0x1
    8e6c:	54000221 	b.ne	8eb0 <fwp_hof0.constprop.0+0xf80>  // b.any
    8e70:	29430044 	ldp	w4, w0, [x2, #24]
    8e74:	92403c21 	and	x1, x1, #0xffff
    8e78:	9b047c21 	mul	x1, x1, x4
    8e7c:	d360fc21 	lsr	x1, x1, #32
    8e80:	eb00003f 	cmp	x1, x0
    8e84:	54000162 	b.cs	8eb0 <fwp_hof0.constprop.0+0xf80>  // b.hs, b.nlast
    8e88:	8b010273 	add	x19, x19, x1
    8e8c:	39400260 	ldrb	w0, [x19]
    8e90:	34000100 	cbz	w0, 8eb0 <fwp_hof0.constprop.0+0xf80>
    8e94:	7100041f 	cmp	w0, #0x1
    8e98:	54003840 	b.eq	95a0 <fwp_hof0.constprop.0+0x1670>  // b.none
    8e9c:	7103fc1f 	cmp	w0, #0xff
    8ea0:	54004940 	b.eq	97c8 <fwp_hof0.constprop.0+0x1898>  // b.none
    8ea4:	51000400 	sub	w0, w0, #0x1
    8ea8:	39000260 	strb	w0, [x19]
    8eac:	d503201f 	nop
    8eb0:	f94007e0 	ldr	x0, [sp, #8]
    8eb4:	b40019e0 	cbz	x0, 91f0 <fwp_hof0.constprop.0+0x12c0>
    8eb8:	f94007e0 	ldr	x0, [sp, #8]
    8ebc:	f100041a 	subs	x26, x0, #0x1
    8ec0:	f90007fa 	str	x26, [sp, #8]
    8ec4:	540057e6 	b.vs	99c0 <fwp_hof0.constprop.0+0x1a90>
    8ec8:	91150280 	add	x0, x20, #0x540
    8ecc:	aa1c03f5 	mov	x21, x28
    8ed0:	f949ec03 	ldr	x3, [x0, #5080]
    8ed4:	f949d801 	ldr	x1, [x0, #5040]
    8ed8:	d370bc63 	lsl	x3, x3, #16
    8edc:	17fffc59 	b	8040 <fwp_hof0.constprop.0+0x110>
    8ee0:	f94002c3 	ldr	x3, [x22]
    8ee4:	aa1603e0 	mov	x0, x22
    8ee8:	f949ee62 	ldr	x2, [x19, #5080]
    8eec:	f949da61 	ldr	x1, [x19, #5040]
    8ef0:	d370bc42 	lsl	x2, x2, #16
    8ef4:	cb0102c7 	sub	x7, x22, x1
    8ef8:	b7f82d43 	tbnz	x3, #63, 94a0 <fwp_hof0.constprop.0+0x1570>
    8efc:	eb07005f 	cmp	x2, x7
    8f00:	54fff989 	b.ls	8e30 <fwp_hof0.constprop.0+0xf00>  // b.plast
    8f04:	d350fce3 	lsr	x3, x7, #16
    8f08:	8b030863 	add	x3, x3, x3, lsl #2
    8f0c:	d37df063 	lsl	x3, x3, #3
    8f10:	8b0300a6 	add	x6, x5, x3
    8f14:	f94010c4 	ldr	x4, [x6, #32]
    8f18:	b4fff8c4 	cbz	x4, 8e30 <fwp_hof0.constprop.0+0xf00>
    8f1c:	386368a3 	ldrb	w3, [x5, x3]
    8f20:	7100087f 	cmp	w3, #0x2
    8f24:	540038e0 	b.eq	9640 <fwp_hof0.constprop.0+0x1710>  // b.none
    8f28:	7100047f 	cmp	w3, #0x1
    8f2c:	54fff821 	b.ne	8e30 <fwp_hof0.constprop.0+0xf00>  // b.any
    8f30:	29430cc5 	ldp	w5, w3, [x6, #24]
    8f34:	92403ce0 	and	x0, x7, #0xffff
    8f38:	9b057c00 	mul	x0, x0, x5
    8f3c:	d360fc00 	lsr	x0, x0, #32
    8f40:	eb03001f 	cmp	x0, x3
    8f44:	54fff762 	b.cs	8e30 <fwp_hof0.constprop.0+0xf00>  // b.hs, b.nlast
    8f48:	8b000084 	add	x4, x4, x0
    8f4c:	39400080 	ldrb	w0, [x4]
    8f50:	7100041f 	cmp	w0, #0x1
    8f54:	54fff6e1 	b.ne	8e30 <fwp_hof0.constprop.0+0xf00>  // b.any
    8f58:	aa1603e0 	mov	x0, x22
    8f5c:	97ffee25 	bl	47f0 <fwp_mem_free>
    8f60:	91150280 	add	x0, x20, #0x540
    8f64:	f949ec02 	ldr	x2, [x0, #5080]
    8f68:	f949d801 	ldr	x1, [x0, #5040]
    8f6c:	d370bc42 	lsl	x2, x2, #16
    8f70:	17ffffb0 	b	8e30 <fwp_hof0.constprop.0+0xf00>
    8f74:	aa1803e0 	mov	x0, x24
    8f78:	97ffed7e 	bl	4570 <fwp_rc_forget_slot>
    8f7c:	17ffff6c 	b	8d2c <fwp_hof0.constprop.0+0xdfc>
    8f80:	72003c3f 	tst	w1, #0xffff
    8f84:	54ffed61 	b.ne	8d30 <fwp_hof0.constprop.0+0xe00>  // b.any
    8f88:	17ffff66 	b	8d20 <fwp_hof0.constprop.0+0xdf0>
    8f8c:	72003c1f 	tst	w0, #0xffff
    8f90:	54ffd840 	b.eq	8a98 <fwp_hof0.constprop.0+0xb68>  // b.none
    8f94:	b4000ff5 	cbz	x21, 9190 <fwp_hof0.constprop.0+0x1260>
    8f98:	aa1503f3 	mov	x19, x21
    8f9c:	d2800017 	mov	x23, #0x0                   	// #0
    8fa0:	f9400a73 	ldr	x19, [x19, #16]
    8fa4:	aa1703e0 	mov	x0, x23
    8fa8:	910006f7 	add	x23, x23, #0x1
    8fac:	b5ffffb3 	cbnz	x19, 8fa0 <fwp_hof0.constprop.0+0x1070>
    8fb0:	f9001be5 	str	x5, [sp, #48]
    8fb4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8fb8:	eb0102ff 	cmp	x23, x1
    8fbc:	54004c68 	b.hi	9948 <fwp_hof0.constprop.0+0x1a18>  // b.pmore
    8fc0:	91000800 	add	x0, x0, #0x2
    8fc4:	52800041 	mov	w1, #0x2                   	// #2
    8fc8:	d37df000 	lsl	x0, x0, #3
    8fcc:	97ffef29 	bl	4c70 <fwp_heap_alloc>
    8fd0:	f9401be5 	ldr	x5, [sp, #48]
    8fd4:	aa0003fb 	mov	x27, x0
    8fd8:	aa1503e1 	mov	x1, x21
    8fdc:	eb0502ff 	cmp	x23, x5
    8fe0:	9a8592e5 	csel	x5, x23, x5, ls	// ls = plast
    8fe4:	d503201f 	nop
    8fe8:	f9400420 	ldr	x0, [x1, #8]
    8fec:	f8337b60 	str	x0, [x27, x19, lsl #3]
    8ff0:	91000673 	add	x19, x19, #0x1
    8ff4:	f9400821 	ldr	x1, [x1, #16]
    8ff8:	b5ffff81 	cbnz	x1, 8fe8 <fwp_hof0.constprop.0+0x10b8>
    8ffc:	b4000d25 	cbz	x5, 91a0 <fwp_hof0.constprop.0+0x1270>
    9000:	f9400384 	ldr	x4, [x28]
    9004:	b90033ff 	str	wzr, [sp, #48]
    9008:	17fffeac 	b	8ab8 <fwp_hof0.constprop.0+0xb88>
    900c:	eb1302df 	cmp	x22, x19
    9010:	54ff8fa0 	b.eq	8204 <fwp_hof0.constprop.0+0x2d4>  // b.none
    9014:	f00000a0 	adrp	x0, 20000 <__data_start>
    9018:	8b1606db 	add	x27, x22, x22, lsl #1
    901c:	f940181c 	ldr	x28, [x0, #48]
    9020:	8b1b0adb 	add	x27, x22, x27, lsl #2
    9024:	f0000000 	adrp	x0, c000 <f0+0x2630>
    9028:	913ba000 	add	x0, x0, #0xee8
    902c:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    9030:	f900337f 	str	xzr, [x27, #96]
    9034:	97ffe677 	bl	2a10 <getenv@plt>
    9038:	b5ff9440 	cbnz	x0, 82c0 <fwp_hof0.constprop.0+0x390>
    903c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9040:	9100c000 	add	x0, x0, #0x30
    9044:	f9404001 	ldr	x1, [x0, #128]
    9048:	b4ff9461 	cbz	x1, 82d4 <fwp_hof0.constprop.0+0x3a4>
    904c:	3cc48002 	ldur	q2, [x0, #72]
    9050:	91012001 	add	x1, x0, #0x48
    9054:	3cc58001 	ldur	q1, [x0, #88]
    9058:	f900401f 	str	xzr, [x0, #128]
    905c:	4f000400 	movi	v0.4s, #0x0
    9060:	ad010762 	stp	q2, q1, [x27, #32]
    9064:	a9468002 	ldp	x2, x0, [x0, #104]
    9068:	f9000f60 	str	x0, [x27, #24]
    906c:	f9401820 	ldr	x0, [x1, #48]
    9070:	f9002362 	str	x2, [x27, #64]
    9074:	f9002760 	str	x0, [x27, #72]
    9078:	ad000020 	stp	q0, q0, [x1]
    907c:	3d800820 	str	q0, [x1, #32]
    9080:	f900183f 	str	xzr, [x1, #48]
    9084:	17fffc94 	b	82d4 <fwp_hof0.constprop.0+0x3a4>
    9088:	d53bd040 	mrs	x0, tpidr_el0
    908c:	91400000 	add	x0, x0, #0x0, lsl #12
    9090:	91004000 	add	x0, x0, #0x10
    9094:	f9400000 	ldr	x0, [x0]
    9098:	b4002460 	cbz	x0, 9524 <fwp_hof0.constprop.0+0x15f4>
    909c:	f94017e1 	ldr	x1, [sp, #40]
    90a0:	97ffe951 	bl	35e4 <fwp_closure_drop_push>
    90a4:	b5ff8695 	cbnz	x21, 8174 <fwp_hof0.constprop.0+0x244>
    90a8:	f00000a0 	adrp	x0, 20000 <__data_start>
    90ac:	9100c013 	add	x19, x0, #0x30
    90b0:	d2800017 	mov	x23, #0x0                   	// #0
    90b4:	b942f660 	ldr	w0, [x19, #756]
    90b8:	35ff87a0 	cbnz	w0, 81ac <fwp_hof0.constprop.0+0x27c>
    90bc:	d503201f 	nop
    90c0:	90ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0x15c>
    90c4:	91384000 	add	x0, x0, #0xe10
    90c8:	94000eee 	bl	cc80 <atexit>
    90cc:	35ffc420 	cbnz	w0, 8950 <fwp_hof0.constprop.0+0xa20>
    90d0:	52800020 	mov	w0, #0x1                   	// #1
    90d4:	b902f660 	str	w0, [x19, #756]
    90d8:	17fffc35 	b	81ac <fwp_hof0.constprop.0+0x27c>
    90dc:	72003c1f 	tst	w0, #0xffff
    90e0:	54ffbe40 	b.eq	88a8 <fwp_hof0.constprop.0+0x978>  // b.none
    90e4:	d503201f 	nop
    90e8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    90ec:	eb0002ff 	cmp	x23, x0
    90f0:	54004508 	b.hi	9990 <fwp_hof0.constprop.0+0x1a60>  // b.pmore
    90f4:	910006e0 	add	x0, x23, #0x1
    90f8:	52800021 	mov	w1, #0x1                   	// #1
    90fc:	d37df000 	lsl	x0, x0, #3
    9100:	97ffeedc 	bl	4c70 <fwp_heap_alloc>
    9104:	91150282 	add	x2, x20, #0x540
    9108:	f9000017 	str	x23, [x0]
    910c:	aa0003fc 	mov	x28, x0
    9110:	aa0003f6 	mov	x22, x0
    9114:	f949d841 	ldr	x1, [x2, #5040]
    9118:	f949ec40 	ldr	x0, [x2, #5080]
    911c:	cb010381 	sub	x1, x28, x1
    9120:	eb00403f 	cmp	x1, x0, lsl #16
    9124:	54000322 	b.cs	9188 <fwp_hof0.constprop.0+0x1258>  // b.hs, b.nlast
    9128:	d350fc20 	lsr	x0, x1, #16
    912c:	f949fc44 	ldr	x4, [x2, #5112]
    9130:	8b000800 	add	x0, x0, x0, lsl #2
    9134:	d37df002 	lsl	x2, x0, #3
    9138:	8b020083 	add	x3, x4, x2
    913c:	f9401078 	ldr	x24, [x3, #32]
    9140:	b4000258 	cbz	x24, 9188 <fwp_hof0.constprop.0+0x1258>
    9144:	38626882 	ldrb	w2, [x4, x2]
    9148:	7100085f 	cmp	w2, #0x2
    914c:	54002800 	b.eq	964c <fwp_hof0.constprop.0+0x171c>  // b.none
    9150:	7100045f 	cmp	w2, #0x1
    9154:	540001a1 	b.ne	9188 <fwp_hof0.constprop.0+0x1258>  // b.any
    9158:	29430864 	ldp	w4, w2, [x3, #24]
    915c:	92403c21 	and	x1, x1, #0xffff
    9160:	9b047c21 	mul	x1, x1, x4
    9164:	d360fc21 	lsr	x1, x1, #32
    9168:	eb02003f 	cmp	x1, x2
    916c:	540000e2 	b.cs	9188 <fwp_hof0.constprop.0+0x1258>  // b.hs, b.nlast
    9170:	8b010318 	add	x24, x24, x1
    9174:	39400301 	ldrb	w1, [x24]
    9178:	7103fc3f 	cmp	w1, #0xff
    917c:	54002700 	b.eq	965c <fwp_hof0.constprop.0+0x172c>  // b.none
    9180:	52800021 	mov	w1, #0x1                   	// #1
    9184:	39000301 	strb	w1, [x24]
    9188:	aa1303e0 	mov	x0, x19
    918c:	17fffdcd 	b	88c0 <fwp_hof0.constprop.0+0x990>
    9190:	52800041 	mov	w1, #0x2                   	// #2
    9194:	d2800100 	mov	x0, #0x8                   	// #8
    9198:	97ffeeb6 	bl	4c70 <fwp_heap_alloc>
    919c:	aa0003fb 	mov	x27, x0
    91a0:	d280001c 	mov	x28, #0x0                   	// #0
    91a4:	17fffefb 	b	8d90 <fwp_hof0.constprop.0+0xe60>
    91a8:	52800041 	mov	w1, #0x2                   	// #2
    91ac:	d2800100 	mov	x0, #0x8                   	// #8
    91b0:	97ffeeb0 	bl	4c70 <fwp_heap_alloc>
    91b4:	aa0003f7 	mov	x23, x0
    91b8:	91150280 	add	x0, x20, #0x540
    91bc:	aa1703fb 	mov	x27, x23
    91c0:	f90002ff 	str	xzr, [x23]
    91c4:	f949d801 	ldr	x1, [x0, #5040]
    91c8:	f949ec00 	ldr	x0, [x0, #5080]
    91cc:	cb0102e1 	sub	x1, x23, x1
    91d0:	eb00403f 	cmp	x1, x0, lsl #16
    91d4:	540010e2 	b.cs	93f0 <fwp_hof0.constprop.0+0x14c0>  // b.hs, b.nlast
    91d8:	d2800016 	mov	x22, #0x0                   	// #0
    91dc:	17fffc83 	b	83e8 <fwp_hof0.constprop.0+0x4b8>
    91e0:	f9001fe0 	str	x0, [sp, #56]
    91e4:	97ffece3 	bl	4570 <fwp_rc_forget_slot>
    91e8:	f9401fe0 	ldr	x0, [sp, #56]
    91ec:	17fffe86 	b	8c04 <fwp_hof0.constprop.0+0xcd4>
    91f0:	f9400be0 	ldr	x0, [sp, #16]
    91f4:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xf2f0>
    91f8:	910aa042 	add	x2, x2, #0x2a8
    91fc:	aa1c03e1 	mov	x1, x28
    9200:	91014042 	add	x2, x2, #0x50
    9204:	52800023 	mov	w3, #0x1                   	// #1
    9208:	a9097fff 	stp	xzr, xzr, [sp, #144]
    920c:	f90053ff 	str	xzr, [sp, #160]
    9210:	97fff74c 	bl	6f40 <fwp_write>
    9214:	a9495bf5 	ldp	x21, x22, [sp, #144]
    9218:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x350>
    921c:	911b8000 	add	x0, x0, #0x6e0
    9220:	f10002bf 	cmp	x21, #0x0
    9224:	9a950015 	csel	x21, x0, x21, eq	// eq = none
    9228:	b1002adf 	cmn	x22, #0xa
    922c:	54003ac8 	b.hi	9984 <fwp_hof0.constprop.0+0x1a54>  // b.pmore
    9230:	910026c0 	add	x0, x22, #0x9
    9234:	52800021 	mov	w1, #0x1                   	// #1
    9238:	97ffee8e 	bl	4c70 <fwp_heap_alloc>
    923c:	aa0003f7 	mov	x23, x0
    9240:	aa0003f3 	mov	x19, x0
    9244:	aa1603e2 	mov	x2, x22
    9248:	aa1503e1 	mov	x1, x21
    924c:	f80086f6 	str	x22, [x23], #8
    9250:	8b160276 	add	x22, x19, x22
    9254:	aa1703e0 	mov	x0, x23
    9258:	97ffe51e 	bl	26d0 <memcpy@plt>
    925c:	390022df 	strb	wzr, [x22, #8]
    9260:	f9404be0 	ldr	x0, [sp, #144]
    9264:	97ffe5b7 	bl	2940 <free@plt>
    9268:	91150281 	add	x1, x20, #0x540
    926c:	f949d822 	ldr	x2, [x1, #5040]
    9270:	f949ec20 	ldr	x0, [x1, #5080]
    9274:	cb020262 	sub	x2, x19, x2
    9278:	eb00405f 	cmp	x2, x0, lsl #16
    927c:	54000322 	b.cs	92e0 <fwp_hof0.constprop.0+0x13b0>  // b.hs, b.nlast
    9280:	d350fc40 	lsr	x0, x2, #16
    9284:	f949fc23 	ldr	x3, [x1, #5112]
    9288:	8b000800 	add	x0, x0, x0, lsl #2
    928c:	d37df001 	lsl	x1, x0, #3
    9290:	8b010060 	add	x0, x3, x1
    9294:	f9401015 	ldr	x21, [x0, #32]
    9298:	b4000255 	cbz	x21, 92e0 <fwp_hof0.constprop.0+0x13b0>
    929c:	38616861 	ldrb	w1, [x3, x1]
    92a0:	7100083f 	cmp	w1, #0x2
    92a4:	54002be0 	b.eq	9820 <fwp_hof0.constprop.0+0x18f0>  // b.none
    92a8:	7100043f 	cmp	w1, #0x1
    92ac:	540001a1 	b.ne	92e0 <fwp_hof0.constprop.0+0x13b0>  // b.any
    92b0:	29430003 	ldp	w3, w0, [x0, #24]
    92b4:	92403c41 	and	x1, x2, #0xffff
    92b8:	9b037c21 	mul	x1, x1, x3
    92bc:	d360fc21 	lsr	x1, x1, #32
    92c0:	eb00003f 	cmp	x1, x0
    92c4:	540000e2 	b.cs	92e0 <fwp_hof0.constprop.0+0x13b0>  // b.hs, b.nlast
    92c8:	8b0102b5 	add	x21, x21, x1
    92cc:	394002a0 	ldrb	w0, [x21]
    92d0:	7103fc1f 	cmp	w0, #0xff
    92d4:	54002b00 	b.eq	9834 <fwp_hof0.constprop.0+0x1904>  // b.none
    92d8:	52800020 	mov	w0, #0x1                   	// #1
    92dc:	390002a0 	strb	w0, [x21]
    92e0:	aa1c03e0 	mov	x0, x28
    92e4:	97fff1d7 	bl	5a40 <fwp_drop0>
    92e8:	f00000a0 	adrp	x0, 20000 <__data_start>
    92ec:	9100c015 	add	x21, x0, #0x30
    92f0:	f9400262 	ldr	x2, [x19]
    92f4:	d2800021 	mov	x1, #0x1                   	// #1
    92f8:	f94006a3 	ldr	x3, [x21, #8]
    92fc:	aa1703e0 	mov	x0, x23
    9300:	97ffe5a0 	bl	2980 <fwrite@plt>
    9304:	f94006a1 	ldr	x1, [x21, #8]
    9308:	52800140 	mov	w0, #0xa                   	// #10
    930c:	97ffe525 	bl	27a0 <fputc@plt>
    9310:	91150281 	add	x1, x20, #0x540
    9314:	f949d822 	ldr	x2, [x1, #5040]
    9318:	f949ec20 	ldr	x0, [x1, #5080]
    931c:	cb020262 	sub	x2, x19, x2
    9320:	eb00405f 	cmp	x2, x0, lsl #16
    9324:	54000382 	b.cs	9394 <fwp_hof0.constprop.0+0x1464>  // b.hs, b.nlast
    9328:	d350fc40 	lsr	x0, x2, #16
    932c:	f949fc23 	ldr	x3, [x1, #5112]
    9330:	8b000800 	add	x0, x0, x0, lsl #2
    9334:	d37df001 	lsl	x1, x0, #3
    9338:	8b010060 	add	x0, x3, x1
    933c:	f9401015 	ldr	x21, [x0, #32]
    9340:	b40002b5 	cbz	x21, 9394 <fwp_hof0.constprop.0+0x1464>
    9344:	38616861 	ldrb	w1, [x3, x1]
    9348:	7100083f 	cmp	w1, #0x2
    934c:	54002380 	b.eq	97bc <fwp_hof0.constprop.0+0x188c>  // b.none
    9350:	7100043f 	cmp	w1, #0x1
    9354:	54000201 	b.ne	9394 <fwp_hof0.constprop.0+0x1464>  // b.any
    9358:	29430003 	ldp	w3, w0, [x0, #24]
    935c:	92403c41 	and	x1, x2, #0xffff
    9360:	9b037c21 	mul	x1, x1, x3
    9364:	d360fc21 	lsr	x1, x1, #32
    9368:	eb00003f 	cmp	x1, x0
    936c:	54000142 	b.cs	9394 <fwp_hof0.constprop.0+0x1464>  // b.hs, b.nlast
    9370:	8b0102b5 	add	x21, x21, x1
    9374:	394002a0 	ldrb	w0, [x21]
    9378:	340000e0 	cbz	w0, 9394 <fwp_hof0.constprop.0+0x1464>
    937c:	7100041f 	cmp	w0, #0x1
    9380:	54001a60 	b.eq	96cc <fwp_hof0.constprop.0+0x179c>  // b.none
    9384:	7103fc1f 	cmp	w0, #0xff
    9388:	54002ae0 	b.eq	98e4 <fwp_hof0.constprop.0+0x19b4>  // b.none
    938c:	51000400 	sub	w0, w0, #0x1
    9390:	390002a0 	strb	w0, [x21]
    9394:	f94027e0 	ldr	x0, [sp, #72]
    9398:	f9400800 	ldr	x0, [x0, #16]
    939c:	f90027e0 	str	x0, [sp, #72]
    93a0:	b5ff5fe0 	cbnz	x0, 7f9c <fwp_hof0.constprop.0+0x6c>
    93a4:	a94f53f3 	ldp	x19, x20, [sp, #240]
    93a8:	a9505bf5 	ldp	x21, x22, [sp, #256]
    93ac:	a95163f7 	ldp	x23, x24, [sp, #272]
    93b0:	a9526bf9 	ldp	x25, x26, [sp, #288]
    93b4:	a95373fb 	ldp	x27, x28, [sp, #304]
    93b8:	fd40a3e8 	ldr	d8, [sp, #320]
    93bc:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    93c0:	f947f400 	ldr	x0, [x0, #4072]
    93c4:	f9406fe2 	ldr	x2, [sp, #216]
    93c8:	f9400001 	ldr	x1, [x0]
    93cc:	eb010042 	subs	x2, x2, x1
    93d0:	d2800001 	mov	x1, #0x0                   	// #0
    93d4:	54002e81 	b.ne	99a4 <fwp_hof0.constprop.0+0x1a74>  // b.any
    93d8:	a94e7bfd 	ldp	x29, x30, [sp, #224]
    93dc:	d2800000 	mov	x0, #0x0                   	// #0
    93e0:	910543ff 	add	sp, sp, #0x150
    93e4:	d65f03c0 	ret
    93e8:	b5ff8356 	cbnz	x22, 8450 <fwp_hof0.constprop.0+0x520>
    93ec:	d503201f 	nop
    93f0:	d280001c 	mov	x28, #0x0                   	// #0
    93f4:	17fffc3e 	b	84ec <fwp_hof0.constprop.0+0x5bc>
    93f8:	72003c3f 	tst	w1, #0xffff
    93fc:	54ff8c21 	b.ne	8580 <fwp_hof0.constprop.0+0x650>  // b.any
    9400:	17fffc58 	b	8560 <fwp_hof0.constprop.0+0x630>
    9404:	72003c7f 	tst	w3, #0xffff
    9408:	54ffdac1 	b.ne	8f60 <fwp_hof0.constprop.0+0x1030>  // b.any
    940c:	17fffe7d 	b	8e00 <fwp_hof0.constprop.0+0xed0>
    9410:	f940077b 	ldr	x27, [x27, #8]
    9414:	eb02007f 	cmp	x3, x2
    9418:	54000369 	b.ls	9484 <fwp_hof0.constprop.0+0x1554>  // b.plast
    941c:	d350fc45 	lsr	x5, x2, #16
    9420:	8b0508a5 	add	x5, x5, x5, lsl #2
    9424:	d37df0a5 	lsl	x5, x5, #3
    9428:	8b050087 	add	x7, x4, x5
    942c:	f94010e6 	ldr	x6, [x7, #32]
    9430:	b40002a6 	cbz	x6, 9484 <fwp_hof0.constprop.0+0x1554>
    9434:	38656884 	ldrb	w4, [x4, x5]
    9438:	7100089f 	cmp	w4, #0x2
    943c:	540013c0 	b.eq	96b4 <fwp_hof0.constprop.0+0x1784>  // b.none
    9440:	7100049f 	cmp	w4, #0x1
    9444:	54000201 	b.ne	9484 <fwp_hof0.constprop.0+0x1554>  // b.any
    9448:	294310e5 	ldp	w5, w4, [x7, #24]
    944c:	92403c42 	and	x2, x2, #0xffff
    9450:	9b057c42 	mul	x2, x2, x5
    9454:	d360fc42 	lsr	x2, x2, #32
    9458:	eb04005f 	cmp	x2, x4
    945c:	54000142 	b.cs	9484 <fwp_hof0.constprop.0+0x1554>  // b.hs, b.nlast
    9460:	8b0200c6 	add	x6, x6, x2
    9464:	394000c2 	ldrb	w2, [x6]
    9468:	7100045f 	cmp	w2, #0x1
    946c:	540000c1 	b.ne	9484 <fwp_hof0.constprop.0+0x1554>  // b.any
    9470:	97ffece0 	bl	47f0 <fwp_mem_free>
    9474:	91150280 	add	x0, x20, #0x540
    9478:	f949ec03 	ldr	x3, [x0, #5080]
    947c:	f949d801 	ldr	x1, [x0, #5040]
    9480:	d370bc63 	lsl	x3, x3, #16
    9484:	cb010361 	sub	x1, x27, x1
    9488:	eb03003f 	cmp	x1, x3
    948c:	54ff8443 	b.cc	8514 <fwp_hof0.constprop.0+0x5e4>  // b.lo, b.ul, b.last
    9490:	17fffc3c 	b	8580 <fwp_hof0.constprop.0+0x650>
    9494:	72003c3f 	tst	w1, #0xffff
    9498:	54ffd0c1 	b.ne	8eb0 <fwp_hof0.constprop.0+0xf80>  // b.any
    949c:	17fffe7c 	b	8e8c <fwp_hof0.constprop.0+0xf5c>
    94a0:	f94006d6 	ldr	x22, [x22, #8]
    94a4:	eb07005f 	cmp	x2, x7
    94a8:	54000369 	b.ls	9514 <fwp_hof0.constprop.0+0x15e4>  // b.plast
    94ac:	d350fce3 	lsr	x3, x7, #16
    94b0:	8b030863 	add	x3, x3, x3, lsl #2
    94b4:	d37df063 	lsl	x3, x3, #3
    94b8:	8b0300a6 	add	x6, x5, x3
    94bc:	f94010c4 	ldr	x4, [x6, #32]
    94c0:	b40002a4 	cbz	x4, 9514 <fwp_hof0.constprop.0+0x15e4>
    94c4:	386368a3 	ldrb	w3, [x5, x3]
    94c8:	7100087f 	cmp	w3, #0x2
    94cc:	54000fa0 	b.eq	96c0 <fwp_hof0.constprop.0+0x1790>  // b.none
    94d0:	7100047f 	cmp	w3, #0x1
    94d4:	54000201 	b.ne	9514 <fwp_hof0.constprop.0+0x15e4>  // b.any
    94d8:	294314c8 	ldp	w8, w5, [x6, #24]
    94dc:	92403ce3 	and	x3, x7, #0xffff
    94e0:	9b087c63 	mul	x3, x3, x8
    94e4:	d360fc63 	lsr	x3, x3, #32
    94e8:	eb05007f 	cmp	x3, x5
    94ec:	54000142 	b.cs	9514 <fwp_hof0.constprop.0+0x15e4>  // b.hs, b.nlast
    94f0:	8b030084 	add	x4, x4, x3
    94f4:	39400083 	ldrb	w3, [x4]
    94f8:	7100047f 	cmp	w3, #0x1
    94fc:	540000c1 	b.ne	9514 <fwp_hof0.constprop.0+0x15e4>  // b.any
    9500:	97ffecbc 	bl	47f0 <fwp_mem_free>
    9504:	91150280 	add	x0, x20, #0x540
    9508:	f949ec02 	ldr	x2, [x0, #5080]
    950c:	f949d801 	ldr	x1, [x0, #5040]
    9510:	d370bc42 	lsl	x2, x2, #16
    9514:	cb0102c3 	sub	x3, x22, x1
    9518:	eb03005f 	cmp	x2, x3
    951c:	54ffc4c8 	b.hi	8db4 <fwp_hof0.constprop.0+0xe84>  // b.pmore
    9520:	17fffe44 	b	8e30 <fwp_hof0.constprop.0+0xf00>
    9524:	f94017e0 	ldr	x0, [sp, #40]
    9528:	97ffe89e 	bl	37a0 <fwp_closure_drop.part.0>
    952c:	17fffb11 	b	8170 <fwp_hof0.constprop.0+0x240>
    9530:	72003c3f 	tst	w1, #0xffff
    9534:	54ff78c1 	b.ne	844c <fwp_hof0.constprop.0+0x51c>  // b.any
    9538:	39400380 	ldrb	w0, [x28]
    953c:	7103fc1f 	cmp	w0, #0xff
    9540:	54ff7821 	b.ne	8444 <fwp_hof0.constprop.0+0x514>  // b.any
    9544:	aa1c03e0 	mov	x0, x28
    9548:	97ffec0a 	bl	4570 <fwp_rc_forget_slot>
    954c:	17fffbbe 	b	8444 <fwp_hof0.constprop.0+0x514>
    9550:	72003c3f 	tst	w1, #0xffff
    9554:	54ff60e1 	b.ne	8170 <fwp_hof0.constprop.0+0x240>  // b.any
    9558:	17fffafe 	b	8150 <fwp_hof0.constprop.0+0x220>
    955c:	72003c3f 	tst	w1, #0xffff
    9560:	54ff5e01 	b.ne	8120 <fwp_hof0.constprop.0+0x1f0>  // b.any
    9564:	aa1303e0 	mov	x0, x19
    9568:	17fffadb 	b	80d4 <fwp_hof0.constprop.0+0x1a4>
    956c:	aa1c03f3 	mov	x19, x28
    9570:	17fffc38 	b	8650 <fwp_hof0.constprop.0+0x720>
    9574:	72003c3f 	tst	w1, #0xffff
    9578:	54ff94e1 	b.ne	8814 <fwp_hof0.constprop.0+0x8e4>  // b.any
    957c:	394002c0 	ldrb	w0, [x22]
    9580:	7103fc1f 	cmp	w0, #0xff
    9584:	54ff9441 	b.ne	880c <fwp_hof0.constprop.0+0x8dc>  // b.any
    9588:	aa1603e0 	mov	x0, x22
    958c:	97ffebf9 	bl	4570 <fwp_rc_forget_slot>
    9590:	17fffc9f 	b	880c <fwp_hof0.constprop.0+0x8dc>
    9594:	72003c5f 	tst	w2, #0xffff
    9598:	54ff7f41 	b.ne	8580 <fwp_hof0.constprop.0+0x650>  // b.any
    959c:	17fffd14 	b	89ec <fwp_hof0.constprop.0+0xabc>
    95a0:	91150280 	add	x0, x20, #0x540
    95a4:	f9400ab3 	ldr	x19, [x21, #16]
    95a8:	f949ec04 	ldr	x4, [x0, #5080]
    95ac:	f949d801 	ldr	x1, [x0, #5040]
    95b0:	d370bc84 	lsl	x4, x4, #16
    95b4:	cb0102a0 	sub	x0, x21, x1
    95b8:	eb04001f 	cmp	x0, x4
    95bc:	54000382 	b.cs	962c <fwp_hof0.constprop.0+0x16fc>  // b.hs, b.nlast
    95c0:	d350fc02 	lsr	x2, x0, #16
    95c4:	8b020842 	add	x2, x2, x2, lsl #2
    95c8:	d37df042 	lsl	x2, x2, #3
    95cc:	8b020066 	add	x6, x3, x2
    95d0:	f94010c5 	ldr	x5, [x6, #32]
    95d4:	b40002c5 	cbz	x5, 962c <fwp_hof0.constprop.0+0x16fc>
    95d8:	38626862 	ldrb	w2, [x3, x2]
    95dc:	7100085f 	cmp	w2, #0x2
    95e0:	540007c0 	b.eq	96d8 <fwp_hof0.constprop.0+0x17a8>  // b.none
    95e4:	7100045f 	cmp	w2, #0x1
    95e8:	54000221 	b.ne	962c <fwp_hof0.constprop.0+0x16fc>  // b.any
    95ec:	294308c3 	ldp	w3, w2, [x6, #24]
    95f0:	92403c00 	and	x0, x0, #0xffff
    95f4:	9b037c00 	mul	x0, x0, x3
    95f8:	d360fc00 	lsr	x0, x0, #32
    95fc:	eb02001f 	cmp	x0, x2
    9600:	54000162 	b.cs	962c <fwp_hof0.constprop.0+0x16fc>  // b.hs, b.nlast
    9604:	8b0000a5 	add	x5, x5, x0
    9608:	394000a0 	ldrb	w0, [x5]
    960c:	7100041f 	cmp	w0, #0x1
    9610:	540000e1 	b.ne	962c <fwp_hof0.constprop.0+0x16fc>  // b.any
    9614:	aa1503e0 	mov	x0, x21
    9618:	97ffec76 	bl	47f0 <fwp_mem_free>
    961c:	91150280 	add	x0, x20, #0x540
    9620:	f949ec04 	ldr	x4, [x0, #5080]
    9624:	f949d801 	ldr	x1, [x0, #5040]
    9628:	d370bc84 	lsl	x4, x4, #16
    962c:	cb010261 	sub	x1, x19, x1
    9630:	eb01009f 	cmp	x4, x1
    9634:	54ffc3e9 	b.ls	8eb0 <fwp_hof0.constprop.0+0xf80>  // b.plast
    9638:	aa1303f5 	mov	x21, x19
    963c:	17fffe01 	b	8e40 <fwp_hof0.constprop.0+0xf10>
    9640:	72003cff 	tst	w7, #0xffff
    9644:	54ffbf61 	b.ne	8e30 <fwp_hof0.constprop.0+0xf00>  // b.any
    9648:	17fffe41 	b	8f4c <fwp_hof0.constprop.0+0x101c>
    964c:	72003c3f 	tst	w1, #0xffff
    9650:	54ffd920 	b.eq	9174 <fwp_hof0.constprop.0+0x1244>  // b.none
    9654:	aa1303e0 	mov	x0, x19
    9658:	17fffc9a 	b	88c0 <fwp_hof0.constprop.0+0x990>
    965c:	aa1803e0 	mov	x0, x24
    9660:	97ffebc4 	bl	4570 <fwp_rc_forget_slot>
    9664:	17fffec7 	b	9180 <fwp_hof0.constprop.0+0x1250>
    9668:	aa1703e0 	mov	x0, x23
    966c:	d2800101 	mov	x1, #0x8                   	// #8
    9670:	97ffe47c 	bl	2860 <calloc@plt>
    9674:	aa0003f8 	mov	x24, x0
    9678:	f9401be7 	ldr	x7, [sp, #48]
    967c:	17fffc07 	b	8698 <fwp_hof0.constprop.0+0x768>
    9680:	f9400384 	ldr	x4, [x28]
    9684:	b7ffd864 	tbnz	x4, #63, 9190 <fwp_hof0.constprop.0+0x1260>
    9688:	91150281 	add	x1, x20, #0x540
    968c:	f949d820 	ldr	x0, [x1, #5040]
    9690:	f949ec21 	ldr	x1, [x1, #5080]
    9694:	cb0002c0 	sub	x0, x22, x0
    9698:	eb01401f 	cmp	x0, x1, lsl #16
    969c:	54ffd7a2 	b.cs	9190 <fwp_hof0.constprop.0+0x1260>  // b.hs, b.nlast
    96a0:	9240f885 	and	x5, x4, #0x7fffffffffffffff
    96a4:	17fffce9 	b	8a48 <fwp_hof0.constprop.0+0xb18>
    96a8:	d2800d01 	mov	x1, #0x68                  	// #104
    96ac:	d280003b 	mov	x27, #0x1                   	// #1
    96b0:	17fffae7 	b	824c <fwp_hof0.constprop.0+0x31c>
    96b4:	72003c5f 	tst	w2, #0xffff
    96b8:	54ffee61 	b.ne	9484 <fwp_hof0.constprop.0+0x1554>  // b.any
    96bc:	17ffff6a 	b	9464 <fwp_hof0.constprop.0+0x1534>
    96c0:	72003cff 	tst	w7, #0xffff
    96c4:	54fff281 	b.ne	9514 <fwp_hof0.constprop.0+0x15e4>  // b.any
    96c8:	17ffff8b 	b	94f4 <fwp_hof0.constprop.0+0x15c4>
    96cc:	aa1303e0 	mov	x0, x19
    96d0:	97ffefb4 	bl	55a0 <fwp_rc_free_arr>
    96d4:	17ffff30 	b	9394 <fwp_hof0.constprop.0+0x1464>
    96d8:	72003c1f 	tst	w0, #0xffff
    96dc:	54fffa81 	b.ne	962c <fwp_hof0.constprop.0+0x16fc>  // b.any
    96e0:	17ffffca 	b	9608 <fwp_hof0.constprop.0+0x16d8>
    96e4:	72003c9f 	tst	w4, #0xffff
    96e8:	54ff4a61 	b.ne	8034 <fwp_hof0.constprop.0+0x104>  // b.any
    96ec:	17fffa47 	b	8008 <fwp_hof0.constprop.0+0xd8>
    96f0:	ca5746e0 	eor	x0, x23, x23, lsr #17
    96f4:	91150281 	add	x1, x20, #0x540
    96f8:	ca402400 	eor	x0, x0, x0, lsr #9
    96fc:	8b200c20 	add	x0, x1, w0, uxtb #3
    9700:	f94a2400 	ldr	x0, [x0, #5192]
    9704:	b5000080 	cbnz	x0, 9714 <fwp_hof0.constprop.0+0x17e4>
    9708:	14000010 	b	9748 <fwp_hof0.constprop.0+0x1818>
    970c:	f9400800 	ldr	x0, [x0, #16]
    9710:	b40001c0 	cbz	x0, 9748 <fwp_hof0.constprop.0+0x1818>
    9714:	f9400001 	ldr	x1, [x0]
    9718:	eb17003f 	cmp	x1, x23
    971c:	54ffff81 	b.ne	970c <fwp_hof0.constprop.0+0x17dc>  // b.any
    9720:	f9400401 	ldr	x1, [x0, #8]
    9724:	d1000421 	sub	x1, x1, #0x1
    9728:	f9000401 	str	x1, [x0, #8]
    972c:	f103f83f 	cmp	x1, #0xfe
    9730:	54ff7281 	b.ne	8580 <fwp_hof0.constprop.0+0x650>  // b.any
    9734:	aa1703e0 	mov	x0, x23
    9738:	97ffeb8e 	bl	4570 <fwp_rc_forget_slot>
    973c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9740:	390002e0 	strb	w0, [x23]
    9744:	17fffb8f 	b	8580 <fwp_hof0.constprop.0+0x650>
    9748:	f0000000 	adrp	x0, c000 <f0+0x2630>
    974c:	913d6000 	add	x0, x0, #0xf58
    9750:	97ffe78c 	bl	3580 <fwp_trap>
    9754:	ca5746e0 	eor	x0, x23, x23, lsr #17
    9758:	91150281 	add	x1, x20, #0x540
    975c:	ca402400 	eor	x0, x0, x0, lsr #9
    9760:	8b200c20 	add	x0, x1, w0, uxtb #3
    9764:	f94a2401 	ldr	x1, [x0, #5192]
    9768:	b5000081 	cbnz	x1, 9778 <fwp_hof0.constprop.0+0x1848>
    976c:	17fffff7 	b	9748 <fwp_hof0.constprop.0+0x1818>
    9770:	f9400821 	ldr	x1, [x1, #16]
    9774:	b4fffea1 	cbz	x1, 9748 <fwp_hof0.constprop.0+0x1818>
    9778:	f9400020 	ldr	x0, [x1]
    977c:	eb17001f 	cmp	x0, x23
    9780:	54ffff81 	b.ne	9770 <fwp_hof0.constprop.0+0x1840>  // b.any
    9784:	f9400420 	ldr	x0, [x1, #8]
    9788:	d1000400 	sub	x0, x0, #0x1
    978c:	f9000420 	str	x0, [x1, #8]
    9790:	f103f81f 	cmp	x0, #0xfe
    9794:	54ffbe61 	b.ne	8f60 <fwp_hof0.constprop.0+0x1030>  // b.any
    9798:	aa1703e0 	mov	x0, x23
    979c:	97ffeb75 	bl	4570 <fwp_rc_forget_slot>
    97a0:	91150280 	add	x0, x20, #0x540
    97a4:	12800021 	mov	w1, #0xfffffffe            	// #-2
    97a8:	390002e1 	strb	w1, [x23]
    97ac:	f949ec02 	ldr	x2, [x0, #5080]
    97b0:	f949d801 	ldr	x1, [x0, #5040]
    97b4:	d370bc42 	lsl	x2, x2, #16
    97b8:	17fffd9e 	b	8e30 <fwp_hof0.constprop.0+0xf00>
    97bc:	72003c5f 	tst	w2, #0xffff
    97c0:	54ffdea1 	b.ne	9394 <fwp_hof0.constprop.0+0x1464>  // b.any
    97c4:	17fffeec 	b	9374 <fwp_hof0.constprop.0+0x1444>
    97c8:	ca534660 	eor	x0, x19, x19, lsr #17
    97cc:	91150281 	add	x1, x20, #0x540
    97d0:	ca402400 	eor	x0, x0, x0, lsr #9
    97d4:	8b200c20 	add	x0, x1, w0, uxtb #3
    97d8:	f94a2400 	ldr	x0, [x0, #5192]
    97dc:	b5000080 	cbnz	x0, 97ec <fwp_hof0.constprop.0+0x18bc>
    97e0:	17ffffda 	b	9748 <fwp_hof0.constprop.0+0x1818>
    97e4:	f9400800 	ldr	x0, [x0, #16]
    97e8:	b4fffb00 	cbz	x0, 9748 <fwp_hof0.constprop.0+0x1818>
    97ec:	f9400001 	ldr	x1, [x0]
    97f0:	eb01027f 	cmp	x19, x1
    97f4:	54ffff81 	b.ne	97e4 <fwp_hof0.constprop.0+0x18b4>  // b.any
    97f8:	f9400401 	ldr	x1, [x0, #8]
    97fc:	d1000421 	sub	x1, x1, #0x1
    9800:	f9000401 	str	x1, [x0, #8]
    9804:	f103f83f 	cmp	x1, #0xfe
    9808:	54ffb541 	b.ne	8eb0 <fwp_hof0.constprop.0+0xf80>  // b.any
    980c:	aa1303e0 	mov	x0, x19
    9810:	97ffeb58 	bl	4570 <fwp_rc_forget_slot>
    9814:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9818:	39000260 	strb	w0, [x19]
    981c:	17fffda5 	b	8eb0 <fwp_hof0.constprop.0+0xf80>
    9820:	72003c5f 	tst	w2, #0xffff
    9824:	54ffd5e1 	b.ne	92e0 <fwp_hof0.constprop.0+0x13b0>  // b.any
    9828:	394002a0 	ldrb	w0, [x21]
    982c:	7103fc1f 	cmp	w0, #0xff
    9830:	54ffd541 	b.ne	92d8 <fwp_hof0.constprop.0+0x13a8>  // b.any
    9834:	aa1503e0 	mov	x0, x21
    9838:	97ffeb4e 	bl	4570 <fwp_rc_forget_slot>
    983c:	17fffea7 	b	92d8 <fwp_hof0.constprop.0+0x13a8>
    9840:	d280001b 	mov	x27, #0x0                   	// #0
    9844:	d280001c 	mov	x28, #0x0                   	// #0
    9848:	17fffd52 	b	8d90 <fwp_hof0.constprop.0+0xe60>
    984c:	97ffeb02 	bl	4454 <fwp_rc_wide_dup>
    9850:	17fffa27 	b	80ec <fwp_hof0.constprop.0+0x1bc>
    9854:	ca534660 	eor	x0, x19, x19, lsr #17
    9858:	91150281 	add	x1, x20, #0x540
    985c:	ca402400 	eor	x0, x0, x0, lsr #9
    9860:	8b200c20 	add	x0, x1, w0, uxtb #3
    9864:	f94a2400 	ldr	x0, [x0, #5192]
    9868:	b5000080 	cbnz	x0, 9878 <fwp_hof0.constprop.0+0x1948>
    986c:	17ffffb7 	b	9748 <fwp_hof0.constprop.0+0x1818>
    9870:	f9400800 	ldr	x0, [x0, #16]
    9874:	b4fff6a0 	cbz	x0, 9748 <fwp_hof0.constprop.0+0x1818>
    9878:	f9400001 	ldr	x1, [x0]
    987c:	eb13003f 	cmp	x1, x19
    9880:	54ffff81 	b.ne	9870 <fwp_hof0.constprop.0+0x1940>  // b.any
    9884:	f9400401 	ldr	x1, [x0, #8]
    9888:	d1000421 	sub	x1, x1, #0x1
    988c:	f9000401 	str	x1, [x0, #8]
    9890:	f103f83f 	cmp	x1, #0xfe
    9894:	54ff46e1 	b.ne	8170 <fwp_hof0.constprop.0+0x240>  // b.any
    9898:	aa1303e0 	mov	x0, x19
    989c:	97ffeb35 	bl	4570 <fwp_rc_forget_slot>
    98a0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    98a4:	39000260 	strb	w0, [x19]
    98a8:	17fffa32 	b	8170 <fwp_hof0.constprop.0+0x240>
    98ac:	d2800017 	mov	x23, #0x0                   	// #0
    98b0:	17fffcc3 	b	8bbc <fwp_hof0.constprop.0+0xc8c>
    98b4:	f0000000 	adrp	x0, c000 <f0+0x2630>
    98b8:	913e8000 	add	x0, x0, #0xfa0
    98bc:	97ffe731 	bl	3580 <fwp_trap>
    98c0:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x350>
    98c4:	9100e000 	add	x0, x0, #0x38
    98c8:	97ffe72e 	bl	3580 <fwp_trap>
    98cc:	97ffeae2 	bl	4454 <fwp_rc_wide_dup>
    98d0:	91150280 	add	x0, x20, #0x540
    98d4:	f949ec03 	ldr	x3, [x0, #5080]
    98d8:	f949d801 	ldr	x1, [x0, #5040]
    98dc:	d370bc63 	lsl	x3, x3, #16
    98e0:	17fff9d5 	b	8034 <fwp_hof0.constprop.0+0x104>
    98e4:	ca5546a0 	eor	x0, x21, x21, lsr #17
    98e8:	91150281 	add	x1, x20, #0x540
    98ec:	ca402400 	eor	x0, x0, x0, lsr #9
    98f0:	8b200c20 	add	x0, x1, w0, uxtb #3
    98f4:	f94a2400 	ldr	x0, [x0, #5192]
    98f8:	b5000080 	cbnz	x0, 9908 <fwp_hof0.constprop.0+0x19d8>
    98fc:	17ffff93 	b	9748 <fwp_hof0.constprop.0+0x1818>
    9900:	f9400800 	ldr	x0, [x0, #16]
    9904:	b4fff220 	cbz	x0, 9748 <fwp_hof0.constprop.0+0x1818>
    9908:	f9400001 	ldr	x1, [x0]
    990c:	eb15003f 	cmp	x1, x21
    9910:	54ffff81 	b.ne	9900 <fwp_hof0.constprop.0+0x19d0>  // b.any
    9914:	f9400401 	ldr	x1, [x0, #8]
    9918:	d1000421 	sub	x1, x1, #0x1
    991c:	f9000401 	str	x1, [x0, #8]
    9920:	f103f83f 	cmp	x1, #0xfe
    9924:	54ffd381 	b.ne	9394 <fwp_hof0.constprop.0+0x1464>  // b.any
    9928:	aa1503e0 	mov	x0, x21
    992c:	97ffeb11 	bl	4570 <fwp_rc_forget_slot>
    9930:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9934:	390002a0 	strb	w0, [x21]
    9938:	17fffe97 	b	9394 <fwp_hof0.constprop.0+0x1464>
    993c:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x350>
    9940:	9107e000 	add	x0, x0, #0x1f8
    9944:	97ffe70f 	bl	3580 <fwp_trap>
    9948:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x350>
    994c:	91026000 	add	x0, x0, #0x98
    9950:	97ffe70c 	bl	3580 <fwp_trap>
    9954:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x350>
    9958:	9108e000 	add	x0, x0, #0x238
    995c:	97ffe709 	bl	3580 <fwp_trap>
    9960:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x350>
    9964:	9106e000 	add	x0, x0, #0x1b8
    9968:	97ffe706 	bl	3580 <fwp_trap>
    996c:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x350>
    9970:	91066000 	add	x0, x0, #0x198
    9974:	97ffe703 	bl	3580 <fwp_trap>
    9978:	f0000000 	adrp	x0, c000 <f0+0x2630>
    997c:	913fa000 	add	x0, x0, #0xfe8
    9980:	97ffe700 	bl	3580 <fwp_trap>
    9984:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x350>
    9988:	91088000 	add	x0, x0, #0x220
    998c:	97ffe6fd 	bl	3580 <fwp_trap>
    9990:	90000020 	adrp	x0, d000 <_IO_stdin_used+0x350>
    9994:	9107a000 	add	x0, x0, #0x1e8
    9998:	97ffe6fa 	bl	3580 <fwp_trap>
    999c:	52800020 	mov	w0, #0x1                   	// #1
    99a0:	17fffbe3 	b	892c <fwp_hof0.constprop.0+0x9fc>
    99a4:	a90f53f3 	stp	x19, x20, [sp, #240]
    99a8:	a9105bf5 	stp	x21, x22, [sp, #256]
    99ac:	a91163f7 	stp	x23, x24, [sp, #272]
    99b0:	a9126bf9 	stp	x25, x26, [sp, #288]
    99b4:	a91373fb 	stp	x27, x28, [sp, #304]
    99b8:	fd00a3e8 	str	d8, [sp, #320]
    99bc:	97ffe3b1 	bl	2880 <__stack_chk_fail@plt>
    99c0:	97ffe430 	bl	2a80 <fwp_trap_overflow.constprop.0>
    99c4:	97ffe3c3 	bl	28d0 <abort@plt>
    99c8:	d503201f 	nop
    99cc:	d503201f 	nop

00000000000099d0 <f0>:
    99d0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    99d4:	910003fd 	mov	x29, sp
    99d8:	a90153f3 	stp	x19, x20, [sp, #16]
    99dc:	a9025bf5 	stp	x21, x22, [sp, #32]
    99e0:	a90363f7 	stp	x23, x24, [sp, #48]
    99e4:	a9046bf9 	stp	x25, x26, [sp, #64]
    99e8:	a90573fb 	stp	x27, x28, [sp, #80]
    99ec:	d12183ff 	sub	sp, sp, #0x860
    99f0:	f90203ff 	str	xzr, [sp, #1024]
    99f4:	f00000a0 	adrp	x0, 20000 <__data_start>
    99f8:	9100c005 	add	x5, x0, #0x30
    99fc:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    9a00:	f947f400 	ldr	x0, [x0, #4072]
    9a04:	90000154 	adrp	x20, 31000 <fwp_root_context+0xca0>
    9a08:	f94160a6 	ldr	x6, [x5, #704]
    9a0c:	f9400001 	ldr	x1, [x0]
    9a10:	f9042fe1 	str	x1, [sp, #2136]
    9a14:	d2800001 	mov	x1, #0x0                   	// #0
    9a18:	91150298 	add	x24, x20, #0x540
    9a1c:	912123f6 	add	x22, sp, #0x848
    9a20:	910023e0 	add	x0, sp, #0x8
    9a24:	910083e2 	add	x2, sp, #0x20
    9a28:	90ffffe1 	adrp	x1, 5000 <fwp_p_ad_push+0x15c>
    9a2c:	b0ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    9a30:	9123c021 	add	x1, x1, #0x8f0
    9a34:	913d4084 	add	x4, x4, #0xf50
    9a38:	d2800013 	mov	x19, #0x0                   	// #0
    9a3c:	d2800119 	mov	x25, #0x8                   	// #8
    9a40:	d2800015 	mov	x21, #0x0                   	// #0
    9a44:	52800037 	mov	w23, #0x1                   	// #1
    9a48:	a90093e6 	stp	x6, x4, [sp, #8]
    9a4c:	a901ffe2 	stp	x2, xzr, [sp, #24]
    9a50:	a90307ff 	stp	xzr, x1, [sp, #48]
    9a54:	f90160a0 	str	x0, [x5, #704]
    9a58:	f100073a 	subs	x26, x25, #0x1
    9a5c:	aa1603e1 	mov	x1, x22
    9a60:	da1f02bc 	sbc	x28, x21, xzr
    9a64:	52800020 	mov	w0, #0x1                   	// #1
    9a68:	f90017fa 	str	x26, [sp, #40]
    9a6c:	aa1a03f9 	mov	x25, x26
    9a70:	f90427fa 	str	x26, [sp, #2120]
    9a74:	aa1c03f5 	mov	x21, x28
    9a78:	f9042bf3 	str	x19, [sp, #2128]
    9a7c:	97ffecc2 	bl	4d84 <fwp_data.part.0.constprop.0>
    9a80:	f949db02 	ldr	x2, [x24, #5040]
    9a84:	aa0003f3 	mov	x19, x0
    9a88:	f949ef00 	ldr	x0, [x24, #5080]
    9a8c:	cb020262 	sub	x2, x19, x2
    9a90:	eb00405f 	cmp	x2, x0, lsl #16
    9a94:	54000302 	b.cs	9af4 <f0+0x124>  // b.hs, b.nlast
    9a98:	d350fc40 	lsr	x0, x2, #16
    9a9c:	f949ff04 	ldr	x4, [x24, #5112]
    9aa0:	8b000800 	add	x0, x0, x0, lsl #2
    9aa4:	d37df001 	lsl	x1, x0, #3
    9aa8:	8b010080 	add	x0, x4, x1
    9aac:	f940101b 	ldr	x27, [x0, #32]
    9ab0:	b400023b 	cbz	x27, 9af4 <f0+0x124>
    9ab4:	38616881 	ldrb	w1, [x4, x1]
    9ab8:	7100083f 	cmp	w1, #0x2
    9abc:	54010ee0 	b.eq	bc98 <f0+0x22c8>  // b.none
    9ac0:	7100043f 	cmp	w1, #0x1
    9ac4:	54000181 	b.ne	9af4 <f0+0x124>  // b.any
    9ac8:	29430001 	ldp	w1, w0, [x0, #24]
    9acc:	92403c42 	and	x2, x2, #0xffff
    9ad0:	9b017c42 	mul	x2, x2, x1
    9ad4:	d360fc42 	lsr	x2, x2, #32
    9ad8:	eb00005f 	cmp	x2, x0
    9adc:	540000c2 	b.cs	9af4 <f0+0x124>  // b.hs, b.nlast
    9ae0:	8b02037b 	add	x27, x27, x2
    9ae4:	39400360 	ldrb	w0, [x27]
    9ae8:	7103fc1f 	cmp	w0, #0xff
    9aec:	54010d00 	b.eq	bc8c <f0+0x22bc>  // b.none
    9af0:	39000377 	strb	w23, [x27]
    9af4:	f90013f3 	str	x19, [sp, #32]
    9af8:	aa1c035a 	orr	x26, x26, x28
    9afc:	b5fffafa 	cbnz	x26, 9a58 <f0+0x88>
    9b00:	90000023 	adrp	x3, d000 <_IO_stdin_used+0x350>
    9b04:	910103e1 	add	x1, sp, #0x40
    9b08:	f94007e2 	ldr	x2, [sp, #8]
    9b0c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9b10:	3dc26460 	ldr	q0, [x3, #2448]
    9b14:	9100c018 	add	x24, x0, #0x30
    9b18:	52800020 	mov	w0, #0x1                   	// #1
    9b1c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    9b20:	3d8013e0 	str	q0, [sp, #64]
    9b24:	f9016302 	str	x2, [x24, #704]
    9b28:	97ffec97 	bl	4d84 <fwp_data.part.0.constprop.0>
    9b2c:	97ffee6d 	bl	54e0 <fwp_rc_fresh>
    9b30:	aa0003e2 	mov	x2, x0
    9b34:	910163e1 	add	x1, sp, #0x58
    9b38:	52800020 	mov	w0, #0x1                   	// #1
    9b3c:	a9058bf5 	stp	x21, x2, [sp, #88]
    9b40:	97ffec91 	bl	4d84 <fwp_data.part.0.constprop.0>
    9b44:	97ffee67 	bl	54e0 <fwp_rc_fresh>
    9b48:	aa0003e2 	mov	x2, x0
    9b4c:	9101a3e1 	add	x1, sp, #0x68
    9b50:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    9b54:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    9b58:	52800020 	mov	w0, #0x1                   	// #1
    9b5c:	a9068be3 	stp	x3, x2, [sp, #104]
    9b60:	97ffec89 	bl	4d84 <fwp_data.part.0.constprop.0>
    9b64:	97ffee5f 	bl	54e0 <fwp_rc_fresh>
    9b68:	aa0003e2 	mov	x2, x0
    9b6c:	9101e3e1 	add	x1, sp, #0x78
    9b70:	52800020 	mov	w0, #0x1                   	// #1
    9b74:	a9078bf5 	stp	x21, x2, [sp, #120]
    9b78:	97ffec83 	bl	4d84 <fwp_data.part.0.constprop.0>
    9b7c:	97ffee59 	bl	54e0 <fwp_rc_fresh>
    9b80:	aa0003e2 	mov	x2, x0
    9b84:	910223e1 	add	x1, sp, #0x88
    9b88:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    9b8c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    9b90:	52800020 	mov	w0, #0x1                   	// #1
    9b94:	a9088be3 	stp	x3, x2, [sp, #136]
    9b98:	97ffec7b 	bl	4d84 <fwp_data.part.0.constprop.0>
    9b9c:	97ffee51 	bl	54e0 <fwp_rc_fresh>
    9ba0:	aa0003e2 	mov	x2, x0
    9ba4:	910263e1 	add	x1, sp, #0x98
    9ba8:	52800020 	mov	w0, #0x1                   	// #1
    9bac:	a9098bf5 	stp	x21, x2, [sp, #152]
    9bb0:	97ffec75 	bl	4d84 <fwp_data.part.0.constprop.0>
    9bb4:	97ffee4b 	bl	54e0 <fwp_rc_fresh>
    9bb8:	aa0003e2 	mov	x2, x0
    9bbc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    9bc0:	9102a3e1 	add	x1, sp, #0xa8
    9bc4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    9bc8:	52800020 	mov	w0, #0x1                   	// #1
    9bcc:	a90a8be3 	stp	x3, x2, [sp, #168]
    9bd0:	97ffec6d 	bl	4d84 <fwp_data.part.0.constprop.0>
    9bd4:	97ffee43 	bl	54e0 <fwp_rc_fresh>
    9bd8:	aa0003e2 	mov	x2, x0
    9bdc:	9102e3e1 	add	x1, sp, #0xb8
    9be0:	52800020 	mov	w0, #0x1                   	// #1
    9be4:	a90b8bf5 	stp	x21, x2, [sp, #184]
    9be8:	97ffec67 	bl	4d84 <fwp_data.part.0.constprop.0>
    9bec:	91150283 	add	x3, x20, #0x540
    9bf0:	aa0003f5 	mov	x21, x0
    9bf4:	f949d861 	ldr	x1, [x3, #5040]
    9bf8:	f949ec60 	ldr	x0, [x3, #5080]
    9bfc:	cb0102a1 	sub	x1, x21, x1
    9c00:	eb00403f 	cmp	x1, x0, lsl #16
    9c04:	54000322 	b.cs	9c68 <f0+0x298>  // b.hs, b.nlast
    9c08:	d350fc22 	lsr	x2, x1, #16
    9c0c:	f949fc63 	ldr	x3, [x3, #5112]
    9c10:	8b020842 	add	x2, x2, x2, lsl #2
    9c14:	d37df042 	lsl	x2, x2, #3
    9c18:	8b020060 	add	x0, x3, x2
    9c1c:	f9401017 	ldr	x23, [x0, #32]
    9c20:	b4000257 	cbz	x23, 9c68 <f0+0x298>
    9c24:	38626862 	ldrb	w2, [x3, x2]
    9c28:	7100085f 	cmp	w2, #0x2
    9c2c:	54010780 	b.eq	bd1c <f0+0x234c>  // b.none
    9c30:	7100045f 	cmp	w2, #0x1
    9c34:	540001a1 	b.ne	9c68 <f0+0x298>  // b.any
    9c38:	29430002 	ldp	w2, w0, [x0, #24]
    9c3c:	92403c21 	and	x1, x1, #0xffff
    9c40:	9b027c21 	mul	x1, x1, x2
    9c44:	d360fc21 	lsr	x1, x1, #32
    9c48:	eb00003f 	cmp	x1, x0
    9c4c:	540000e2 	b.cs	9c68 <f0+0x298>  // b.hs, b.nlast
    9c50:	8b0102f7 	add	x23, x23, x1
    9c54:	394002e0 	ldrb	w0, [x23]
    9c58:	7103fc1f 	cmp	w0, #0xff
    9c5c:	54011140 	b.eq	be84 <f0+0x24b4>  // b.none
    9c60:	52800020 	mov	w0, #0x1                   	// #1
    9c64:	390002e0 	strb	w0, [x23]
    9c68:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9c6c:	910323e1 	add	x1, sp, #0xc8
    9c70:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9c74:	52800020 	mov	w0, #0x1                   	// #1
    9c78:	a90cd7e2 	stp	x2, x21, [sp, #200]
    9c7c:	97ffec42 	bl	4d84 <fwp_data.part.0.constprop.0>
    9c80:	97ffee18 	bl	54e0 <fwp_rc_fresh>
    9c84:	aa0003e2 	mov	x2, x0
    9c88:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    9c8c:	910363e1 	add	x1, sp, #0xd8
    9c90:	52800020 	mov	w0, #0x1                   	// #1
    9c94:	a90d8be3 	stp	x3, x2, [sp, #216]
    9c98:	97ffec3b 	bl	4d84 <fwp_data.part.0.constprop.0>
    9c9c:	91150283 	add	x3, x20, #0x540
    9ca0:	aa0003f5 	mov	x21, x0
    9ca4:	f949d861 	ldr	x1, [x3, #5040]
    9ca8:	f949ec60 	ldr	x0, [x3, #5080]
    9cac:	cb0102a1 	sub	x1, x21, x1
    9cb0:	eb00403f 	cmp	x1, x0, lsl #16
    9cb4:	54000322 	b.cs	9d18 <f0+0x348>  // b.hs, b.nlast
    9cb8:	d350fc22 	lsr	x2, x1, #16
    9cbc:	f949fc63 	ldr	x3, [x3, #5112]
    9cc0:	8b020842 	add	x2, x2, x2, lsl #2
    9cc4:	d37df042 	lsl	x2, x2, #3
    9cc8:	8b020060 	add	x0, x3, x2
    9ccc:	f9401017 	ldr	x23, [x0, #32]
    9cd0:	b4000257 	cbz	x23, 9d18 <f0+0x348>
    9cd4:	38626862 	ldrb	w2, [x3, x2]
    9cd8:	7100085f 	cmp	w2, #0x2
    9cdc:	540101a0 	b.eq	bd10 <f0+0x2340>  // b.none
    9ce0:	7100045f 	cmp	w2, #0x1
    9ce4:	540001a1 	b.ne	9d18 <f0+0x348>  // b.any
    9ce8:	29430002 	ldp	w2, w0, [x0, #24]
    9cec:	92403c21 	and	x1, x1, #0xffff
    9cf0:	9b027c21 	mul	x1, x1, x2
    9cf4:	d360fc21 	lsr	x1, x1, #32
    9cf8:	eb00003f 	cmp	x1, x0
    9cfc:	540000e2 	b.cs	9d18 <f0+0x348>  // b.hs, b.nlast
    9d00:	8b0102f7 	add	x23, x23, x1
    9d04:	394002e0 	ldrb	w0, [x23]
    9d08:	7103fc1f 	cmp	w0, #0xff
    9d0c:	54010c20 	b.eq	be90 <f0+0x24c0>  // b.none
    9d10:	52800020 	mov	w0, #0x1                   	// #1
    9d14:	390002e0 	strb	w0, [x23]
    9d18:	9103a3e1 	add	x1, sp, #0xe8
    9d1c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    9d20:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    9d24:	52800020 	mov	w0, #0x1                   	// #1
    9d28:	a90ed7f7 	stp	x23, x21, [sp, #232]
    9d2c:	97ffec16 	bl	4d84 <fwp_data.part.0.constprop.0>
    9d30:	97ffedec 	bl	54e0 <fwp_rc_fresh>
    9d34:	aa0003e2 	mov	x2, x0
    9d38:	9103e3e1 	add	x1, sp, #0xf8
    9d3c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    9d40:	52800020 	mov	w0, #0x1                   	// #1
    9d44:	a90f8bf5 	stp	x21, x2, [sp, #248]
    9d48:	97ffec0f 	bl	4d84 <fwp_data.part.0.constprop.0>
    9d4c:	97ffede5 	bl	54e0 <fwp_rc_fresh>
    9d50:	aa0003e2 	mov	x2, x0
    9d54:	910423e1 	add	x1, sp, #0x108
    9d58:	52800020 	mov	w0, #0x1                   	// #1
    9d5c:	a9108bf7 	stp	x23, x2, [sp, #264]
    9d60:	97ffec09 	bl	4d84 <fwp_data.part.0.constprop.0>
    9d64:	97ffeddf 	bl	54e0 <fwp_rc_fresh>
    9d68:	aa0003e2 	mov	x2, x0
    9d6c:	910463e1 	add	x1, sp, #0x118
    9d70:	52800020 	mov	w0, #0x1                   	// #1
    9d74:	a9118bf5 	stp	x21, x2, [sp, #280]
    9d78:	97ffec03 	bl	4d84 <fwp_data.part.0.constprop.0>
    9d7c:	97ffedd9 	bl	54e0 <fwp_rc_fresh>
    9d80:	aa0003e2 	mov	x2, x0
    9d84:	9104a3e1 	add	x1, sp, #0x128
    9d88:	52800020 	mov	w0, #0x1                   	// #1
    9d8c:	a9128bf7 	stp	x23, x2, [sp, #296]
    9d90:	97ffebfd 	bl	4d84 <fwp_data.part.0.constprop.0>
    9d94:	97ffedd3 	bl	54e0 <fwp_rc_fresh>
    9d98:	aa0003e2 	mov	x2, x0
    9d9c:	9104e3e1 	add	x1, sp, #0x138
    9da0:	52800020 	mov	w0, #0x1                   	// #1
    9da4:	a9138bf5 	stp	x21, x2, [sp, #312]
    9da8:	97ffebf7 	bl	4d84 <fwp_data.part.0.constprop.0>
    9dac:	97ffedcd 	bl	54e0 <fwp_rc_fresh>
    9db0:	aa0003e2 	mov	x2, x0
    9db4:	910523e1 	add	x1, sp, #0x148
    9db8:	52800020 	mov	w0, #0x1                   	// #1
    9dbc:	a9148bf7 	stp	x23, x2, [sp, #328]
    9dc0:	97ffebf1 	bl	4d84 <fwp_data.part.0.constprop.0>
    9dc4:	97ffedc7 	bl	54e0 <fwp_rc_fresh>
    9dc8:	aa0003e2 	mov	x2, x0
    9dcc:	910563e1 	add	x1, sp, #0x158
    9dd0:	52800020 	mov	w0, #0x1                   	// #1
    9dd4:	a9158bf5 	stp	x21, x2, [sp, #344]
    9dd8:	97ffebeb 	bl	4d84 <fwp_data.part.0.constprop.0>
    9ddc:	97ffedc1 	bl	54e0 <fwp_rc_fresh>
    9de0:	aa0003e2 	mov	x2, x0
    9de4:	9105a3e1 	add	x1, sp, #0x168
    9de8:	52800020 	mov	w0, #0x1                   	// #1
    9dec:	a9168bf7 	stp	x23, x2, [sp, #360]
    9df0:	97ffebe5 	bl	4d84 <fwp_data.part.0.constprop.0>
    9df4:	97ffedbb 	bl	54e0 <fwp_rc_fresh>
    9df8:	aa0003e2 	mov	x2, x0
    9dfc:	9105e3e1 	add	x1, sp, #0x178
    9e00:	52800020 	mov	w0, #0x1                   	// #1
    9e04:	a9178bf5 	stp	x21, x2, [sp, #376]
    9e08:	97ffebdf 	bl	4d84 <fwp_data.part.0.constprop.0>
    9e0c:	97ffedb5 	bl	54e0 <fwp_rc_fresh>
    9e10:	aa0003e2 	mov	x2, x0
    9e14:	910623e1 	add	x1, sp, #0x188
    9e18:	52800020 	mov	w0, #0x1                   	// #1
    9e1c:	a9188bf7 	stp	x23, x2, [sp, #392]
    9e20:	97ffebd9 	bl	4d84 <fwp_data.part.0.constprop.0>
    9e24:	97ffedaf 	bl	54e0 <fwp_rc_fresh>
    9e28:	aa0003e2 	mov	x2, x0
    9e2c:	910663e1 	add	x1, sp, #0x198
    9e30:	52800020 	mov	w0, #0x1                   	// #1
    9e34:	a9198bf5 	stp	x21, x2, [sp, #408]
    9e38:	97ffebd3 	bl	4d84 <fwp_data.part.0.constprop.0>
    9e3c:	97ffeda9 	bl	54e0 <fwp_rc_fresh>
    9e40:	aa0003e2 	mov	x2, x0
    9e44:	9106a3e1 	add	x1, sp, #0x1a8
    9e48:	52800020 	mov	w0, #0x1                   	// #1
    9e4c:	a91a8bf7 	stp	x23, x2, [sp, #424]
    9e50:	97ffebcd 	bl	4d84 <fwp_data.part.0.constprop.0>
    9e54:	97ffeda3 	bl	54e0 <fwp_rc_fresh>
    9e58:	aa0003e2 	mov	x2, x0
    9e5c:	9106e3e1 	add	x1, sp, #0x1b8
    9e60:	52800020 	mov	w0, #0x1                   	// #1
    9e64:	a91b8bf5 	stp	x21, x2, [sp, #440]
    9e68:	97ffebc7 	bl	4d84 <fwp_data.part.0.constprop.0>
    9e6c:	97ffed9d 	bl	54e0 <fwp_rc_fresh>
    9e70:	aa0003e2 	mov	x2, x0
    9e74:	910723e1 	add	x1, sp, #0x1c8
    9e78:	52800020 	mov	w0, #0x1                   	// #1
    9e7c:	a91c8bf7 	stp	x23, x2, [sp, #456]
    9e80:	97ffebc1 	bl	4d84 <fwp_data.part.0.constprop.0>
    9e84:	97ffed97 	bl	54e0 <fwp_rc_fresh>
    9e88:	aa0003e2 	mov	x2, x0
    9e8c:	910763e1 	add	x1, sp, #0x1d8
    9e90:	52800020 	mov	w0, #0x1                   	// #1
    9e94:	a91d8bf5 	stp	x21, x2, [sp, #472]
    9e98:	97ffebbb 	bl	4d84 <fwp_data.part.0.constprop.0>
    9e9c:	91150283 	add	x3, x20, #0x540
    9ea0:	aa0003f5 	mov	x21, x0
    9ea4:	f949d861 	ldr	x1, [x3, #5040]
    9ea8:	f949ec60 	ldr	x0, [x3, #5080]
    9eac:	cb0102a1 	sub	x1, x21, x1
    9eb0:	eb00403f 	cmp	x1, x0, lsl #16
    9eb4:	54000322 	b.cs	9f18 <f0+0x548>  // b.hs, b.nlast
    9eb8:	d350fc22 	lsr	x2, x1, #16
    9ebc:	f949fc63 	ldr	x3, [x3, #5112]
    9ec0:	8b020842 	add	x2, x2, x2, lsl #2
    9ec4:	d37df042 	lsl	x2, x2, #3
    9ec8:	8b020060 	add	x0, x3, x2
    9ecc:	f9401017 	ldr	x23, [x0, #32]
    9ed0:	b4000257 	cbz	x23, 9f18 <f0+0x548>
    9ed4:	38626862 	ldrb	w2, [x3, x2]
    9ed8:	7100085f 	cmp	w2, #0x2
    9edc:	5400f140 	b.eq	bd04 <f0+0x2334>  // b.none
    9ee0:	7100045f 	cmp	w2, #0x1
    9ee4:	540001a1 	b.ne	9f18 <f0+0x548>  // b.any
    9ee8:	29430002 	ldp	w2, w0, [x0, #24]
    9eec:	92403c21 	and	x1, x1, #0xffff
    9ef0:	9b027c21 	mul	x1, x1, x2
    9ef4:	d360fc21 	lsr	x1, x1, #32
    9ef8:	eb00003f 	cmp	x1, x0
    9efc:	540000e2 	b.cs	9f18 <f0+0x548>  // b.hs, b.nlast
    9f00:	8b0102f7 	add	x23, x23, x1
    9f04:	394002e0 	ldrb	w0, [x23]
    9f08:	7103fc1f 	cmp	w0, #0xff
    9f0c:	5400fc80 	b.eq	be9c <f0+0x24cc>  // b.none
    9f10:	52800020 	mov	w0, #0x1                   	// #1
    9f14:	390002e0 	strb	w0, [x23]
    9f18:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9f1c:	9107a3e1 	add	x1, sp, #0x1e8
    9f20:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9f24:	52800020 	mov	w0, #0x1                   	// #1
    9f28:	a91ed7e2 	stp	x2, x21, [sp, #488]
    9f2c:	97ffeb96 	bl	4d84 <fwp_data.part.0.constprop.0>
    9f30:	97ffed6c 	bl	54e0 <fwp_rc_fresh>
    9f34:	aa0003e2 	mov	x2, x0
    9f38:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    9f3c:	9107e3e1 	add	x1, sp, #0x1f8
    9f40:	52800020 	mov	w0, #0x1                   	// #1
    9f44:	a91f8be3 	stp	x3, x2, [sp, #504]
    9f48:	97ffeb8f 	bl	4d84 <fwp_data.part.0.constprop.0>
    9f4c:	91150283 	add	x3, x20, #0x540
    9f50:	aa0003f5 	mov	x21, x0
    9f54:	f949d861 	ldr	x1, [x3, #5040]
    9f58:	f949ec60 	ldr	x0, [x3, #5080]
    9f5c:	cb0102a1 	sub	x1, x21, x1
    9f60:	eb00403f 	cmp	x1, x0, lsl #16
    9f64:	54000322 	b.cs	9fc8 <f0+0x5f8>  // b.hs, b.nlast
    9f68:	d350fc22 	lsr	x2, x1, #16
    9f6c:	f949fc63 	ldr	x3, [x3, #5112]
    9f70:	8b020842 	add	x2, x2, x2, lsl #2
    9f74:	d37df042 	lsl	x2, x2, #3
    9f78:	8b020060 	add	x0, x3, x2
    9f7c:	f9401017 	ldr	x23, [x0, #32]
    9f80:	b4000257 	cbz	x23, 9fc8 <f0+0x5f8>
    9f84:	38626862 	ldrb	w2, [x3, x2]
    9f88:	7100085f 	cmp	w2, #0x2
    9f8c:	5400ee00 	b.eq	bd4c <f0+0x237c>  // b.none
    9f90:	7100045f 	cmp	w2, #0x1
    9f94:	540001a1 	b.ne	9fc8 <f0+0x5f8>  // b.any
    9f98:	29430002 	ldp	w2, w0, [x0, #24]
    9f9c:	92403c21 	and	x1, x1, #0xffff
    9fa0:	9b027c21 	mul	x1, x1, x2
    9fa4:	d360fc21 	lsr	x1, x1, #32
    9fa8:	eb00003f 	cmp	x1, x0
    9fac:	540000e2 	b.cs	9fc8 <f0+0x5f8>  // b.hs, b.nlast
    9fb0:	8b0102f7 	add	x23, x23, x1
    9fb4:	394002e0 	ldrb	w0, [x23]
    9fb8:	7103fc1f 	cmp	w0, #0xff
    9fbc:	5400f760 	b.eq	bea8 <f0+0x24d8>  // b.none
    9fc0:	52800020 	mov	w0, #0x1                   	// #1
    9fc4:	390002e0 	strb	w0, [x23]
    9fc8:	910823e1 	add	x1, sp, #0x208
    9fcc:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    9fd0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    9fd4:	52800020 	mov	w0, #0x1                   	// #1
    9fd8:	f90107f7 	str	x23, [sp, #520]
    9fdc:	f9010bf5 	str	x21, [sp, #528]
    9fe0:	97ffeb69 	bl	4d84 <fwp_data.part.0.constprop.0>
    9fe4:	97ffed3f 	bl	54e0 <fwp_rc_fresh>
    9fe8:	aa0003e2 	mov	x2, x0
    9fec:	910863e1 	add	x1, sp, #0x218
    9ff0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    9ff4:	52800020 	mov	w0, #0x1                   	// #1
    9ff8:	f9010ff5 	str	x21, [sp, #536]
    9ffc:	f90113e2 	str	x2, [sp, #544]
    a000:	97ffeb61 	bl	4d84 <fwp_data.part.0.constprop.0>
    a004:	97ffed37 	bl	54e0 <fwp_rc_fresh>
    a008:	aa0003e2 	mov	x2, x0
    a00c:	9108a3e1 	add	x1, sp, #0x228
    a010:	52800020 	mov	w0, #0x1                   	// #1
    a014:	f90117f7 	str	x23, [sp, #552]
    a018:	f9011be2 	str	x2, [sp, #560]
    a01c:	97ffeb5a 	bl	4d84 <fwp_data.part.0.constprop.0>
    a020:	97ffed30 	bl	54e0 <fwp_rc_fresh>
    a024:	aa0003e2 	mov	x2, x0
    a028:	9108e3e1 	add	x1, sp, #0x238
    a02c:	52800020 	mov	w0, #0x1                   	// #1
    a030:	f9011ff5 	str	x21, [sp, #568]
    a034:	f90123e2 	str	x2, [sp, #576]
    a038:	97ffeb53 	bl	4d84 <fwp_data.part.0.constprop.0>
    a03c:	97ffed29 	bl	54e0 <fwp_rc_fresh>
    a040:	aa0003e2 	mov	x2, x0
    a044:	910923e1 	add	x1, sp, #0x248
    a048:	52800020 	mov	w0, #0x1                   	// #1
    a04c:	f90127f7 	str	x23, [sp, #584]
    a050:	f9012be2 	str	x2, [sp, #592]
    a054:	97ffeb4c 	bl	4d84 <fwp_data.part.0.constprop.0>
    a058:	97ffed22 	bl	54e0 <fwp_rc_fresh>
    a05c:	aa0003e2 	mov	x2, x0
    a060:	910963e1 	add	x1, sp, #0x258
    a064:	52800020 	mov	w0, #0x1                   	// #1
    a068:	f9012ff5 	str	x21, [sp, #600]
    a06c:	f90133e2 	str	x2, [sp, #608]
    a070:	97ffeb45 	bl	4d84 <fwp_data.part.0.constprop.0>
    a074:	91150283 	add	x3, x20, #0x540
    a078:	aa0003f5 	mov	x21, x0
    a07c:	f949d861 	ldr	x1, [x3, #5040]
    a080:	f949ec60 	ldr	x0, [x3, #5080]
    a084:	cb0102a1 	sub	x1, x21, x1
    a088:	eb00403f 	cmp	x1, x0, lsl #16
    a08c:	54000322 	b.cs	a0f0 <f0+0x720>  // b.hs, b.nlast
    a090:	d350fc22 	lsr	x2, x1, #16
    a094:	f949fc63 	ldr	x3, [x3, #5112]
    a098:	8b020842 	add	x2, x2, x2, lsl #2
    a09c:	d37df042 	lsl	x2, x2, #3
    a0a0:	8b020060 	add	x0, x3, x2
    a0a4:	f9401017 	ldr	x23, [x0, #32]
    a0a8:	b4000257 	cbz	x23, a0f0 <f0+0x720>
    a0ac:	38626862 	ldrb	w2, [x3, x2]
    a0b0:	7100085f 	cmp	w2, #0x2
    a0b4:	5400e460 	b.eq	bd40 <f0+0x2370>  // b.none
    a0b8:	7100045f 	cmp	w2, #0x1
    a0bc:	540001a1 	b.ne	a0f0 <f0+0x720>  // b.any
    a0c0:	29430002 	ldp	w2, w0, [x0, #24]
    a0c4:	92403c21 	and	x1, x1, #0xffff
    a0c8:	9b027c21 	mul	x1, x1, x2
    a0cc:	d360fc21 	lsr	x1, x1, #32
    a0d0:	eb00003f 	cmp	x1, x0
    a0d4:	540000e2 	b.cs	a0f0 <f0+0x720>  // b.hs, b.nlast
    a0d8:	8b0102f7 	add	x23, x23, x1
    a0dc:	394002e0 	ldrb	w0, [x23]
    a0e0:	7103fc1f 	cmp	w0, #0xff
    a0e4:	5400ee80 	b.eq	beb4 <f0+0x24e4>  // b.none
    a0e8:	52800020 	mov	w0, #0x1                   	// #1
    a0ec:	390002e0 	strb	w0, [x23]
    a0f0:	9109a3e1 	add	x1, sp, #0x268
    a0f4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a0f8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a0fc:	52800020 	mov	w0, #0x1                   	// #1
    a100:	f90137f7 	str	x23, [sp, #616]
    a104:	f9013bf5 	str	x21, [sp, #624]
    a108:	97ffeb1f 	bl	4d84 <fwp_data.part.0.constprop.0>
    a10c:	97ffecf5 	bl	54e0 <fwp_rc_fresh>
    a110:	aa0003e2 	mov	x2, x0
    a114:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a118:	9109e3e1 	add	x1, sp, #0x278
    a11c:	52800020 	mov	w0, #0x1                   	// #1
    a120:	f9013fe3 	str	x3, [sp, #632]
    a124:	f90143e2 	str	x2, [sp, #640]
    a128:	97ffeb17 	bl	4d84 <fwp_data.part.0.constprop.0>
    a12c:	97ffeced 	bl	54e0 <fwp_rc_fresh>
    a130:	aa0003e2 	mov	x2, x0
    a134:	910a23e1 	add	x1, sp, #0x288
    a138:	52800020 	mov	w0, #0x1                   	// #1
    a13c:	f90147f7 	str	x23, [sp, #648]
    a140:	f9014be2 	str	x2, [sp, #656]
    a144:	97ffeb10 	bl	4d84 <fwp_data.part.0.constprop.0>
    a148:	91150283 	add	x3, x20, #0x540
    a14c:	aa0003f5 	mov	x21, x0
    a150:	f949d861 	ldr	x1, [x3, #5040]
    a154:	f949ec60 	ldr	x0, [x3, #5080]
    a158:	cb0102a1 	sub	x1, x21, x1
    a15c:	eb00403f 	cmp	x1, x0, lsl #16
    a160:	54000322 	b.cs	a1c4 <f0+0x7f4>  // b.hs, b.nlast
    a164:	d350fc22 	lsr	x2, x1, #16
    a168:	f949fc63 	ldr	x3, [x3, #5112]
    a16c:	8b020842 	add	x2, x2, x2, lsl #2
    a170:	d37df042 	lsl	x2, x2, #3
    a174:	8b020060 	add	x0, x3, x2
    a178:	f9401017 	ldr	x23, [x0, #32]
    a17c:	b4000257 	cbz	x23, a1c4 <f0+0x7f4>
    a180:	38626862 	ldrb	w2, [x3, x2]
    a184:	7100085f 	cmp	w2, #0x2
    a188:	5400dd60 	b.eq	bd34 <f0+0x2364>  // b.none
    a18c:	7100045f 	cmp	w2, #0x1
    a190:	540001a1 	b.ne	a1c4 <f0+0x7f4>  // b.any
    a194:	29430002 	ldp	w2, w0, [x0, #24]
    a198:	92403c21 	and	x1, x1, #0xffff
    a19c:	9b027c21 	mul	x1, x1, x2
    a1a0:	d360fc21 	lsr	x1, x1, #32
    a1a4:	eb00003f 	cmp	x1, x0
    a1a8:	540000e2 	b.cs	a1c4 <f0+0x7f4>  // b.hs, b.nlast
    a1ac:	8b0102f7 	add	x23, x23, x1
    a1b0:	394002e0 	ldrb	w0, [x23]
    a1b4:	7103fc1f 	cmp	w0, #0xff
    a1b8:	5400e840 	b.eq	bec0 <f0+0x24f0>  // b.none
    a1bc:	52800020 	mov	w0, #0x1                   	// #1
    a1c0:	390002e0 	strb	w0, [x23]
    a1c4:	910a63e1 	add	x1, sp, #0x298
    a1c8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a1cc:	52800020 	mov	w0, #0x1                   	// #1
    a1d0:	f9014ff7 	str	x23, [sp, #664]
    a1d4:	f90153f5 	str	x21, [sp, #672]
    a1d8:	97ffeaeb 	bl	4d84 <fwp_data.part.0.constprop.0>
    a1dc:	97ffecc1 	bl	54e0 <fwp_rc_fresh>
    a1e0:	aa0003e2 	mov	x2, x0
    a1e4:	910aa3e1 	add	x1, sp, #0x2a8
    a1e8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a1ec:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a1f0:	52800020 	mov	w0, #0x1                   	// #1
    a1f4:	f90157f5 	str	x21, [sp, #680]
    a1f8:	f9015be2 	str	x2, [sp, #688]
    a1fc:	97ffeae2 	bl	4d84 <fwp_data.part.0.constprop.0>
    a200:	97ffecb8 	bl	54e0 <fwp_rc_fresh>
    a204:	aa0003e2 	mov	x2, x0
    a208:	910ae3e1 	add	x1, sp, #0x2b8
    a20c:	52800020 	mov	w0, #0x1                   	// #1
    a210:	f9015ff7 	str	x23, [sp, #696]
    a214:	f90163e2 	str	x2, [sp, #704]
    a218:	97ffeadb 	bl	4d84 <fwp_data.part.0.constprop.0>
    a21c:	97ffecb1 	bl	54e0 <fwp_rc_fresh>
    a220:	aa0003e2 	mov	x2, x0
    a224:	910b23e1 	add	x1, sp, #0x2c8
    a228:	52800020 	mov	w0, #0x1                   	// #1
    a22c:	f90167f5 	str	x21, [sp, #712]
    a230:	f9016be2 	str	x2, [sp, #720]
    a234:	97ffead4 	bl	4d84 <fwp_data.part.0.constprop.0>
    a238:	97ffecaa 	bl	54e0 <fwp_rc_fresh>
    a23c:	aa0003e2 	mov	x2, x0
    a240:	910b63e1 	add	x1, sp, #0x2d8
    a244:	52800020 	mov	w0, #0x1                   	// #1
    a248:	f9016ff7 	str	x23, [sp, #728]
    a24c:	f90173e2 	str	x2, [sp, #736]
    a250:	97ffeacd 	bl	4d84 <fwp_data.part.0.constprop.0>
    a254:	97ffeca3 	bl	54e0 <fwp_rc_fresh>
    a258:	aa0003e2 	mov	x2, x0
    a25c:	910ba3e1 	add	x1, sp, #0x2e8
    a260:	52800020 	mov	w0, #0x1                   	// #1
    a264:	f90177f5 	str	x21, [sp, #744]
    a268:	f9017be2 	str	x2, [sp, #752]
    a26c:	97ffeac6 	bl	4d84 <fwp_data.part.0.constprop.0>
    a270:	91150283 	add	x3, x20, #0x540
    a274:	aa0003f5 	mov	x21, x0
    a278:	f949d861 	ldr	x1, [x3, #5040]
    a27c:	f949ec60 	ldr	x0, [x3, #5080]
    a280:	cb0102a1 	sub	x1, x21, x1
    a284:	eb00403f 	cmp	x1, x0, lsl #16
    a288:	54000322 	b.cs	a2ec <f0+0x91c>  // b.hs, b.nlast
    a28c:	d350fc22 	lsr	x2, x1, #16
    a290:	f949fc63 	ldr	x3, [x3, #5112]
    a294:	8b020842 	add	x2, x2, x2, lsl #2
    a298:	d37df042 	lsl	x2, x2, #3
    a29c:	8b020060 	add	x0, x3, x2
    a2a0:	f9401017 	ldr	x23, [x0, #32]
    a2a4:	b4000257 	cbz	x23, a2ec <f0+0x91c>
    a2a8:	38626862 	ldrb	w2, [x3, x2]
    a2ac:	7100085f 	cmp	w2, #0x2
    a2b0:	5400d3c0 	b.eq	bd28 <f0+0x2358>  // b.none
    a2b4:	7100045f 	cmp	w2, #0x1
    a2b8:	540001a1 	b.ne	a2ec <f0+0x91c>  // b.any
    a2bc:	29430002 	ldp	w2, w0, [x0, #24]
    a2c0:	92403c21 	and	x1, x1, #0xffff
    a2c4:	9b027c21 	mul	x1, x1, x2
    a2c8:	d360fc21 	lsr	x1, x1, #32
    a2cc:	eb00003f 	cmp	x1, x0
    a2d0:	540000e2 	b.cs	a2ec <f0+0x91c>  // b.hs, b.nlast
    a2d4:	8b0102f7 	add	x23, x23, x1
    a2d8:	394002e0 	ldrb	w0, [x23]
    a2dc:	7103fc1f 	cmp	w0, #0xff
    a2e0:	5400df60 	b.eq	becc <f0+0x24fc>  // b.none
    a2e4:	52800020 	mov	w0, #0x1                   	// #1
    a2e8:	390002e0 	strb	w0, [x23]
    a2ec:	910be3e1 	add	x1, sp, #0x2f8
    a2f0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a2f4:	52800020 	mov	w0, #0x1                   	// #1
    a2f8:	f9017ff7 	str	x23, [sp, #760]
    a2fc:	f90183f5 	str	x21, [sp, #768]
    a300:	97ffeaa1 	bl	4d84 <fwp_data.part.0.constprop.0>
    a304:	97ffec77 	bl	54e0 <fwp_rc_fresh>
    a308:	aa0003e2 	mov	x2, x0
    a30c:	910c23e1 	add	x1, sp, #0x308
    a310:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a314:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a318:	52800020 	mov	w0, #0x1                   	// #1
    a31c:	f90187f5 	str	x21, [sp, #776]
    a320:	f9018be2 	str	x2, [sp, #784]
    a324:	97ffea98 	bl	4d84 <fwp_data.part.0.constprop.0>
    a328:	97ffec6e 	bl	54e0 <fwp_rc_fresh>
    a32c:	aa0003e2 	mov	x2, x0
    a330:	910c63e1 	add	x1, sp, #0x318
    a334:	52800020 	mov	w0, #0x1                   	// #1
    a338:	f9018ff7 	str	x23, [sp, #792]
    a33c:	f90193e2 	str	x2, [sp, #800]
    a340:	97ffea91 	bl	4d84 <fwp_data.part.0.constprop.0>
    a344:	97ffec67 	bl	54e0 <fwp_rc_fresh>
    a348:	aa0003e2 	mov	x2, x0
    a34c:	910ca3e1 	add	x1, sp, #0x328
    a350:	52800020 	mov	w0, #0x1                   	// #1
    a354:	f90197f5 	str	x21, [sp, #808]
    a358:	f9019be2 	str	x2, [sp, #816]
    a35c:	97ffea8a 	bl	4d84 <fwp_data.part.0.constprop.0>
    a360:	97ffec60 	bl	54e0 <fwp_rc_fresh>
    a364:	aa0003e2 	mov	x2, x0
    a368:	910ce3e1 	add	x1, sp, #0x338
    a36c:	52800020 	mov	w0, #0x1                   	// #1
    a370:	f9019ff7 	str	x23, [sp, #824]
    a374:	f901a3e2 	str	x2, [sp, #832]
    a378:	97ffea83 	bl	4d84 <fwp_data.part.0.constprop.0>
    a37c:	97ffec59 	bl	54e0 <fwp_rc_fresh>
    a380:	aa0003e2 	mov	x2, x0
    a384:	910d23e1 	add	x1, sp, #0x348
    a388:	52800020 	mov	w0, #0x1                   	// #1
    a38c:	f901a7f5 	str	x21, [sp, #840]
    a390:	f901abe2 	str	x2, [sp, #848]
    a394:	97ffea7c 	bl	4d84 <fwp_data.part.0.constprop.0>
    a398:	97ffec52 	bl	54e0 <fwp_rc_fresh>
    a39c:	aa0003e2 	mov	x2, x0
    a3a0:	910d63e1 	add	x1, sp, #0x358
    a3a4:	52800020 	mov	w0, #0x1                   	// #1
    a3a8:	f901aff7 	str	x23, [sp, #856]
    a3ac:	f901b3e2 	str	x2, [sp, #864]
    a3b0:	97ffea75 	bl	4d84 <fwp_data.part.0.constprop.0>
    a3b4:	97ffec4b 	bl	54e0 <fwp_rc_fresh>
    a3b8:	aa0003e2 	mov	x2, x0
    a3bc:	910da3e1 	add	x1, sp, #0x368
    a3c0:	52800020 	mov	w0, #0x1                   	// #1
    a3c4:	f901b7f5 	str	x21, [sp, #872]
    a3c8:	f901bbe2 	str	x2, [sp, #880]
    a3cc:	97ffea6e 	bl	4d84 <fwp_data.part.0.constprop.0>
    a3d0:	97ffec44 	bl	54e0 <fwp_rc_fresh>
    a3d4:	aa0003e2 	mov	x2, x0
    a3d8:	910de3e1 	add	x1, sp, #0x378
    a3dc:	52800020 	mov	w0, #0x1                   	// #1
    a3e0:	f901bff7 	str	x23, [sp, #888]
    a3e4:	f901c3e2 	str	x2, [sp, #896]
    a3e8:	97ffea67 	bl	4d84 <fwp_data.part.0.constprop.0>
    a3ec:	97ffec3d 	bl	54e0 <fwp_rc_fresh>
    a3f0:	aa0003e2 	mov	x2, x0
    a3f4:	910e23e1 	add	x1, sp, #0x388
    a3f8:	52800020 	mov	w0, #0x1                   	// #1
    a3fc:	f901c7f5 	str	x21, [sp, #904]
    a400:	f901cbe2 	str	x2, [sp, #912]
    a404:	97ffea60 	bl	4d84 <fwp_data.part.0.constprop.0>
    a408:	91150283 	add	x3, x20, #0x540
    a40c:	aa0003f5 	mov	x21, x0
    a410:	f949d861 	ldr	x1, [x3, #5040]
    a414:	f949ec60 	ldr	x0, [x3, #5080]
    a418:	cb0102a1 	sub	x1, x21, x1
    a41c:	eb00403f 	cmp	x1, x0, lsl #16
    a420:	54000322 	b.cs	a484 <f0+0xab4>  // b.hs, b.nlast
    a424:	d350fc22 	lsr	x2, x1, #16
    a428:	f949fc63 	ldr	x3, [x3, #5112]
    a42c:	8b020842 	add	x2, x2, x2, lsl #2
    a430:	d37df042 	lsl	x2, x2, #3
    a434:	8b020060 	add	x0, x3, x2
    a438:	f9401017 	ldr	x23, [x0, #32]
    a43c:	b4000257 	cbz	x23, a484 <f0+0xab4>
    a440:	38626862 	ldrb	w2, [x3, x2]
    a444:	7100085f 	cmp	w2, #0x2
    a448:	5400cb20 	b.eq	bdac <f0+0x23dc>  // b.none
    a44c:	7100045f 	cmp	w2, #0x1
    a450:	540001a1 	b.ne	a484 <f0+0xab4>  // b.any
    a454:	29430002 	ldp	w2, w0, [x0, #24]
    a458:	92403c21 	and	x1, x1, #0xffff
    a45c:	9b027c21 	mul	x1, x1, x2
    a460:	d360fc21 	lsr	x1, x1, #32
    a464:	eb00003f 	cmp	x1, x0
    a468:	540000e2 	b.cs	a484 <f0+0xab4>  // b.hs, b.nlast
    a46c:	8b0102f7 	add	x23, x23, x1
    a470:	394002e0 	ldrb	w0, [x23]
    a474:	7103fc1f 	cmp	w0, #0xff
    a478:	5400d300 	b.eq	bed8 <f0+0x2508>  // b.none
    a47c:	52800020 	mov	w0, #0x1                   	// #1
    a480:	390002e0 	strb	w0, [x23]
    a484:	910e63e1 	add	x1, sp, #0x398
    a488:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a48c:	52800020 	mov	w0, #0x1                   	// #1
    a490:	f901cfe2 	str	x2, [sp, #920]
    a494:	f901d3f5 	str	x21, [sp, #928]
    a498:	97ffea3b 	bl	4d84 <fwp_data.part.0.constprop.0>
    a49c:	97ffec11 	bl	54e0 <fwp_rc_fresh>
    a4a0:	aa0003e2 	mov	x2, x0
    a4a4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a4a8:	910ea3e1 	add	x1, sp, #0x3a8
    a4ac:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a4b0:	52800020 	mov	w0, #0x1                   	// #1
    a4b4:	f901d7e3 	str	x3, [sp, #936]
    a4b8:	f901dbe2 	str	x2, [sp, #944]
    a4bc:	97ffea32 	bl	4d84 <fwp_data.part.0.constprop.0>
    a4c0:	91150283 	add	x3, x20, #0x540
    a4c4:	aa0003f5 	mov	x21, x0
    a4c8:	f949d861 	ldr	x1, [x3, #5040]
    a4cc:	f949ec60 	ldr	x0, [x3, #5080]
    a4d0:	cb0102a1 	sub	x1, x21, x1
    a4d4:	eb00403f 	cmp	x1, x0, lsl #16
    a4d8:	54000322 	b.cs	a53c <f0+0xb6c>  // b.hs, b.nlast
    a4dc:	d350fc22 	lsr	x2, x1, #16
    a4e0:	f949fc63 	ldr	x3, [x3, #5112]
    a4e4:	8b020842 	add	x2, x2, x2, lsl #2
    a4e8:	d37df042 	lsl	x2, x2, #3
    a4ec:	8b020060 	add	x0, x3, x2
    a4f0:	f9401017 	ldr	x23, [x0, #32]
    a4f4:	b4000257 	cbz	x23, a53c <f0+0xb6c>
    a4f8:	38626862 	ldrb	w2, [x3, x2]
    a4fc:	7100085f 	cmp	w2, #0x2
    a500:	5400c500 	b.eq	bda0 <f0+0x23d0>  // b.none
    a504:	7100045f 	cmp	w2, #0x1
    a508:	540001a1 	b.ne	a53c <f0+0xb6c>  // b.any
    a50c:	29430002 	ldp	w2, w0, [x0, #24]
    a510:	92403c21 	and	x1, x1, #0xffff
    a514:	9b027c21 	mul	x1, x1, x2
    a518:	d360fc21 	lsr	x1, x1, #32
    a51c:	eb00003f 	cmp	x1, x0
    a520:	540000e2 	b.cs	a53c <f0+0xb6c>  // b.hs, b.nlast
    a524:	8b0102f7 	add	x23, x23, x1
    a528:	394002e0 	ldrb	w0, [x23]
    a52c:	7103fc1f 	cmp	w0, #0xff
    a530:	5400cda0 	b.eq	bee4 <f0+0x2514>  // b.none
    a534:	52800020 	mov	w0, #0x1                   	// #1
    a538:	390002e0 	strb	w0, [x23]
    a53c:	910ee3e1 	add	x1, sp, #0x3b8
    a540:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a544:	52800020 	mov	w0, #0x1                   	// #1
    a548:	f901dfe2 	str	x2, [sp, #952]
    a54c:	f901e3f5 	str	x21, [sp, #960]
    a550:	97ffea0d 	bl	4d84 <fwp_data.part.0.constprop.0>
    a554:	97ffebe3 	bl	54e0 <fwp_rc_fresh>
    a558:	aa0003e2 	mov	x2, x0
    a55c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a560:	910f23e1 	add	x1, sp, #0x3c8
    a564:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a568:	52800020 	mov	w0, #0x1                   	// #1
    a56c:	f901e7e3 	str	x3, [sp, #968]
    a570:	f901ebe2 	str	x2, [sp, #976]
    a574:	97ffea04 	bl	4d84 <fwp_data.part.0.constprop.0>
    a578:	91150283 	add	x3, x20, #0x540
    a57c:	aa0003f7 	mov	x23, x0
    a580:	f949d861 	ldr	x1, [x3, #5040]
    a584:	f949ec60 	ldr	x0, [x3, #5080]
    a588:	cb0102e1 	sub	x1, x23, x1
    a58c:	eb00403f 	cmp	x1, x0, lsl #16
    a590:	54000322 	b.cs	a5f4 <f0+0xc24>  // b.hs, b.nlast
    a594:	d350fc22 	lsr	x2, x1, #16
    a598:	f949fc63 	ldr	x3, [x3, #5112]
    a59c:	8b020842 	add	x2, x2, x2, lsl #2
    a5a0:	d37df042 	lsl	x2, x2, #3
    a5a4:	8b020060 	add	x0, x3, x2
    a5a8:	f9401015 	ldr	x21, [x0, #32]
    a5ac:	b4000255 	cbz	x21, a5f4 <f0+0xc24>
    a5b0:	38626862 	ldrb	w2, [x3, x2]
    a5b4:	7100085f 	cmp	w2, #0x2
    a5b8:	5400bee0 	b.eq	bd94 <f0+0x23c4>  // b.none
    a5bc:	7100045f 	cmp	w2, #0x1
    a5c0:	540001a1 	b.ne	a5f4 <f0+0xc24>  // b.any
    a5c4:	29430002 	ldp	w2, w0, [x0, #24]
    a5c8:	92403c21 	and	x1, x1, #0xffff
    a5cc:	9b027c21 	mul	x1, x1, x2
    a5d0:	d360fc21 	lsr	x1, x1, #32
    a5d4:	eb00003f 	cmp	x1, x0
    a5d8:	540000e2 	b.cs	a5f4 <f0+0xc24>  // b.hs, b.nlast
    a5dc:	8b0102b5 	add	x21, x21, x1
    a5e0:	394002a0 	ldrb	w0, [x21]
    a5e4:	7103fc1f 	cmp	w0, #0xff
    a5e8:	5400c840 	b.eq	bef0 <f0+0x2520>  // b.none
    a5ec:	52800020 	mov	w0, #0x1                   	// #1
    a5f0:	390002a0 	strb	w0, [x21]
    a5f4:	910f63e1 	add	x1, sp, #0x3d8
    a5f8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a5fc:	52800020 	mov	w0, #0x1                   	// #1
    a600:	f901eff5 	str	x21, [sp, #984]
    a604:	f901f3f7 	str	x23, [sp, #992]
    a608:	97ffe9df 	bl	4d84 <fwp_data.part.0.constprop.0>
    a60c:	97ffebb5 	bl	54e0 <fwp_rc_fresh>
    a610:	aa0003e2 	mov	x2, x0
    a614:	910fa3e1 	add	x1, sp, #0x3e8
    a618:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a61c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a620:	52800020 	mov	w0, #0x1                   	// #1
    a624:	f901f7f7 	str	x23, [sp, #1000]
    a628:	f901fbe2 	str	x2, [sp, #1008]
    a62c:	97ffe9d6 	bl	4d84 <fwp_data.part.0.constprop.0>
    a630:	97ffebac 	bl	54e0 <fwp_rc_fresh>
    a634:	aa0003e2 	mov	x2, x0
    a638:	910fe3e1 	add	x1, sp, #0x3f8
    a63c:	52800020 	mov	w0, #0x1                   	// #1
    a640:	f901fff5 	str	x21, [sp, #1016]
    a644:	f90203e2 	str	x2, [sp, #1024]
    a648:	97ffe9cf 	bl	4d84 <fwp_data.part.0.constprop.0>
    a64c:	97ffeba5 	bl	54e0 <fwp_rc_fresh>
    a650:	aa0003e2 	mov	x2, x0
    a654:	911023e1 	add	x1, sp, #0x408
    a658:	52800020 	mov	w0, #0x1                   	// #1
    a65c:	f90207f7 	str	x23, [sp, #1032]
    a660:	f9020be2 	str	x2, [sp, #1040]
    a664:	97ffe9c8 	bl	4d84 <fwp_data.part.0.constprop.0>
    a668:	97ffeb9e 	bl	54e0 <fwp_rc_fresh>
    a66c:	aa0003e2 	mov	x2, x0
    a670:	911063e1 	add	x1, sp, #0x418
    a674:	52800020 	mov	w0, #0x1                   	// #1
    a678:	f9020ff5 	str	x21, [sp, #1048]
    a67c:	f90213e2 	str	x2, [sp, #1056]
    a680:	97ffe9c1 	bl	4d84 <fwp_data.part.0.constprop.0>
    a684:	97ffeb97 	bl	54e0 <fwp_rc_fresh>
    a688:	aa0003e2 	mov	x2, x0
    a68c:	9110a3e1 	add	x1, sp, #0x428
    a690:	52800020 	mov	w0, #0x1                   	// #1
    a694:	f90217f7 	str	x23, [sp, #1064]
    a698:	f9021be2 	str	x2, [sp, #1072]
    a69c:	97ffe9ba 	bl	4d84 <fwp_data.part.0.constprop.0>
    a6a0:	97ffeb90 	bl	54e0 <fwp_rc_fresh>
    a6a4:	aa0003e2 	mov	x2, x0
    a6a8:	9110e3e1 	add	x1, sp, #0x438
    a6ac:	52800020 	mov	w0, #0x1                   	// #1
    a6b0:	f9021ff5 	str	x21, [sp, #1080]
    a6b4:	f90223e2 	str	x2, [sp, #1088]
    a6b8:	97ffe9b3 	bl	4d84 <fwp_data.part.0.constprop.0>
    a6bc:	91150283 	add	x3, x20, #0x540
    a6c0:	aa0003f5 	mov	x21, x0
    a6c4:	f949d861 	ldr	x1, [x3, #5040]
    a6c8:	f949ec60 	ldr	x0, [x3, #5080]
    a6cc:	cb0102a1 	sub	x1, x21, x1
    a6d0:	eb00403f 	cmp	x1, x0, lsl #16
    a6d4:	54000322 	b.cs	a738 <f0+0xd68>  // b.hs, b.nlast
    a6d8:	d350fc22 	lsr	x2, x1, #16
    a6dc:	f949fc63 	ldr	x3, [x3, #5112]
    a6e0:	8b020842 	add	x2, x2, x2, lsl #2
    a6e4:	d37df042 	lsl	x2, x2, #3
    a6e8:	8b020060 	add	x0, x3, x2
    a6ec:	f9401017 	ldr	x23, [x0, #32]
    a6f0:	b4000257 	cbz	x23, a738 <f0+0xd68>
    a6f4:	38626862 	ldrb	w2, [x3, x2]
    a6f8:	7100085f 	cmp	w2, #0x2
    a6fc:	5400b460 	b.eq	bd88 <f0+0x23b8>  // b.none
    a700:	7100045f 	cmp	w2, #0x1
    a704:	540001a1 	b.ne	a738 <f0+0xd68>  // b.any
    a708:	29430002 	ldp	w2, w0, [x0, #24]
    a70c:	92403c21 	and	x1, x1, #0xffff
    a710:	9b027c21 	mul	x1, x1, x2
    a714:	d360fc21 	lsr	x1, x1, #32
    a718:	eb00003f 	cmp	x1, x0
    a71c:	540000e2 	b.cs	a738 <f0+0xd68>  // b.hs, b.nlast
    a720:	8b0102f7 	add	x23, x23, x1
    a724:	394002e0 	ldrb	w0, [x23]
    a728:	7103fc1f 	cmp	w0, #0xff
    a72c:	5400be80 	b.eq	befc <f0+0x252c>  // b.none
    a730:	52800020 	mov	w0, #0x1                   	// #1
    a734:	390002e0 	strb	w0, [x23]
    a738:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a73c:	911123e1 	add	x1, sp, #0x448
    a740:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a744:	52800020 	mov	w0, #0x1                   	// #1
    a748:	f90227e2 	str	x2, [sp, #1096]
    a74c:	f9022bf5 	str	x21, [sp, #1104]
    a750:	97ffe98d 	bl	4d84 <fwp_data.part.0.constprop.0>
    a754:	91150283 	add	x3, x20, #0x540
    a758:	aa0003f5 	mov	x21, x0
    a75c:	f949d861 	ldr	x1, [x3, #5040]
    a760:	f949ec60 	ldr	x0, [x3, #5080]
    a764:	cb0102a1 	sub	x1, x21, x1
    a768:	eb00403f 	cmp	x1, x0, lsl #16
    a76c:	54000322 	b.cs	a7d0 <f0+0xe00>  // b.hs, b.nlast
    a770:	d350fc22 	lsr	x2, x1, #16
    a774:	f949fc63 	ldr	x3, [x3, #5112]
    a778:	8b020842 	add	x2, x2, x2, lsl #2
    a77c:	d37df042 	lsl	x2, x2, #3
    a780:	8b020060 	add	x0, x3, x2
    a784:	f9401017 	ldr	x23, [x0, #32]
    a788:	b4000257 	cbz	x23, a7d0 <f0+0xe00>
    a78c:	38626862 	ldrb	w2, [x3, x2]
    a790:	7100085f 	cmp	w2, #0x2
    a794:	5400af40 	b.eq	bd7c <f0+0x23ac>  // b.none
    a798:	7100045f 	cmp	w2, #0x1
    a79c:	540001a1 	b.ne	a7d0 <f0+0xe00>  // b.any
    a7a0:	29430002 	ldp	w2, w0, [x0, #24]
    a7a4:	92403c21 	and	x1, x1, #0xffff
    a7a8:	9b027c21 	mul	x1, x1, x2
    a7ac:	d360fc21 	lsr	x1, x1, #32
    a7b0:	eb00003f 	cmp	x1, x0
    a7b4:	540000e2 	b.cs	a7d0 <f0+0xe00>  // b.hs, b.nlast
    a7b8:	8b0102f7 	add	x23, x23, x1
    a7bc:	394002e0 	ldrb	w0, [x23]
    a7c0:	7103fc1f 	cmp	w0, #0xff
    a7c4:	5400ba20 	b.eq	bf08 <f0+0x2538>  // b.none
    a7c8:	52800020 	mov	w0, #0x1                   	// #1
    a7cc:	390002e0 	strb	w0, [x23]
    a7d0:	911163e1 	add	x1, sp, #0x458
    a7d4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a7d8:	52800020 	mov	w0, #0x1                   	// #1
    a7dc:	f9022fe2 	str	x2, [sp, #1112]
    a7e0:	f90233f5 	str	x21, [sp, #1120]
    a7e4:	97ffe968 	bl	4d84 <fwp_data.part.0.constprop.0>
    a7e8:	97ffeb3e 	bl	54e0 <fwp_rc_fresh>
    a7ec:	aa0003e2 	mov	x2, x0
    a7f0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a7f4:	9111a3e1 	add	x1, sp, #0x468
    a7f8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a7fc:	52800020 	mov	w0, #0x1                   	// #1
    a800:	f90237e3 	str	x3, [sp, #1128]
    a804:	f9023be2 	str	x2, [sp, #1136]
    a808:	97ffe95f 	bl	4d84 <fwp_data.part.0.constprop.0>
    a80c:	91150283 	add	x3, x20, #0x540
    a810:	aa0003f5 	mov	x21, x0
    a814:	f949d861 	ldr	x1, [x3, #5040]
    a818:	f949ec60 	ldr	x0, [x3, #5080]
    a81c:	cb0102a1 	sub	x1, x21, x1
    a820:	eb00403f 	cmp	x1, x0, lsl #16
    a824:	54000322 	b.cs	a888 <f0+0xeb8>  // b.hs, b.nlast
    a828:	d350fc22 	lsr	x2, x1, #16
    a82c:	f949fc63 	ldr	x3, [x3, #5112]
    a830:	8b020842 	add	x2, x2, x2, lsl #2
    a834:	d37df042 	lsl	x2, x2, #3
    a838:	8b020060 	add	x0, x3, x2
    a83c:	f9401017 	ldr	x23, [x0, #32]
    a840:	b4000257 	cbz	x23, a888 <f0+0xeb8>
    a844:	38626862 	ldrb	w2, [x3, x2]
    a848:	7100085f 	cmp	w2, #0x2
    a84c:	5400a920 	b.eq	bd70 <f0+0x23a0>  // b.none
    a850:	7100045f 	cmp	w2, #0x1
    a854:	540001a1 	b.ne	a888 <f0+0xeb8>  // b.any
    a858:	29430002 	ldp	w2, w0, [x0, #24]
    a85c:	92403c21 	and	x1, x1, #0xffff
    a860:	9b027c21 	mul	x1, x1, x2
    a864:	d360fc21 	lsr	x1, x1, #32
    a868:	eb00003f 	cmp	x1, x0
    a86c:	540000e2 	b.cs	a888 <f0+0xeb8>  // b.hs, b.nlast
    a870:	8b0102f7 	add	x23, x23, x1
    a874:	394002e0 	ldrb	w0, [x23]
    a878:	7103fc1f 	cmp	w0, #0xff
    a87c:	5400b4c0 	b.eq	bf14 <f0+0x2544>  // b.none
    a880:	52800020 	mov	w0, #0x1                   	// #1
    a884:	390002e0 	strb	w0, [x23]
    a888:	9111e3e1 	add	x1, sp, #0x478
    a88c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a890:	52800020 	mov	w0, #0x1                   	// #1
    a894:	f9023fe2 	str	x2, [sp, #1144]
    a898:	f90243f5 	str	x21, [sp, #1152]
    a89c:	97ffe93a 	bl	4d84 <fwp_data.part.0.constprop.0>
    a8a0:	97ffeb10 	bl	54e0 <fwp_rc_fresh>
    a8a4:	aa0003e2 	mov	x2, x0
    a8a8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a8ac:	911223e1 	add	x1, sp, #0x488
    a8b0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a8b4:	52800020 	mov	w0, #0x1                   	// #1
    a8b8:	f90247e3 	str	x3, [sp, #1160]
    a8bc:	f9024be2 	str	x2, [sp, #1168]
    a8c0:	97ffe931 	bl	4d84 <fwp_data.part.0.constprop.0>
    a8c4:	91150283 	add	x3, x20, #0x540
    a8c8:	aa0003f5 	mov	x21, x0
    a8cc:	f949d861 	ldr	x1, [x3, #5040]
    a8d0:	f949ec60 	ldr	x0, [x3, #5080]
    a8d4:	cb0102a1 	sub	x1, x21, x1
    a8d8:	eb00403f 	cmp	x1, x0, lsl #16
    a8dc:	54000322 	b.cs	a940 <f0+0xf70>  // b.hs, b.nlast
    a8e0:	d350fc22 	lsr	x2, x1, #16
    a8e4:	f949fc63 	ldr	x3, [x3, #5112]
    a8e8:	8b020842 	add	x2, x2, x2, lsl #2
    a8ec:	d37df042 	lsl	x2, x2, #3
    a8f0:	8b020060 	add	x0, x3, x2
    a8f4:	f9401017 	ldr	x23, [x0, #32]
    a8f8:	b4000257 	cbz	x23, a940 <f0+0xf70>
    a8fc:	38626862 	ldrb	w2, [x3, x2]
    a900:	7100085f 	cmp	w2, #0x2
    a904:	5400a300 	b.eq	bd64 <f0+0x2394>  // b.none
    a908:	7100045f 	cmp	w2, #0x1
    a90c:	540001a1 	b.ne	a940 <f0+0xf70>  // b.any
    a910:	29430002 	ldp	w2, w0, [x0, #24]
    a914:	92403c21 	and	x1, x1, #0xffff
    a918:	9b027c21 	mul	x1, x1, x2
    a91c:	d360fc21 	lsr	x1, x1, #32
    a920:	eb00003f 	cmp	x1, x0
    a924:	540000e2 	b.cs	a940 <f0+0xf70>  // b.hs, b.nlast
    a928:	8b0102f7 	add	x23, x23, x1
    a92c:	394002e0 	ldrb	w0, [x23]
    a930:	7103fc1f 	cmp	w0, #0xff
    a934:	5400af60 	b.eq	bf20 <f0+0x2550>  // b.none
    a938:	52800020 	mov	w0, #0x1                   	// #1
    a93c:	390002e0 	strb	w0, [x23]
    a940:	911263e1 	add	x1, sp, #0x498
    a944:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a948:	52800020 	mov	w0, #0x1                   	// #1
    a94c:	f9024ff7 	str	x23, [sp, #1176]
    a950:	f90253f5 	str	x21, [sp, #1184]
    a954:	97ffe90c 	bl	4d84 <fwp_data.part.0.constprop.0>
    a958:	97ffeae2 	bl	54e0 <fwp_rc_fresh>
    a95c:	aa0003e2 	mov	x2, x0
    a960:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a964:	9112a3e1 	add	x1, sp, #0x4a8
    a968:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a96c:	52800020 	mov	w0, #0x1                   	// #1
    a970:	f90257e3 	str	x3, [sp, #1192]
    a974:	f9025be2 	str	x2, [sp, #1200]
    a978:	97ffe903 	bl	4d84 <fwp_data.part.0.constprop.0>
    a97c:	97ffead9 	bl	54e0 <fwp_rc_fresh>
    a980:	aa0003e2 	mov	x2, x0
    a984:	9112e3e1 	add	x1, sp, #0x4b8
    a988:	52800020 	mov	w0, #0x1                   	// #1
    a98c:	f9025ff7 	str	x23, [sp, #1208]
    a990:	f90263e2 	str	x2, [sp, #1216]
    a994:	97ffe8fc 	bl	4d84 <fwp_data.part.0.constprop.0>
    a998:	91150283 	add	x3, x20, #0x540
    a99c:	aa0003f5 	mov	x21, x0
    a9a0:	f949d861 	ldr	x1, [x3, #5040]
    a9a4:	f949ec60 	ldr	x0, [x3, #5080]
    a9a8:	cb0102a1 	sub	x1, x21, x1
    a9ac:	eb00403f 	cmp	x1, x0, lsl #16
    a9b0:	54000322 	b.cs	aa14 <f0+0x1044>  // b.hs, b.nlast
    a9b4:	d350fc22 	lsr	x2, x1, #16
    a9b8:	f949fc63 	ldr	x3, [x3, #5112]
    a9bc:	8b020842 	add	x2, x2, x2, lsl #2
    a9c0:	d37df042 	lsl	x2, x2, #3
    a9c4:	8b020060 	add	x0, x3, x2
    a9c8:	f9401017 	ldr	x23, [x0, #32]
    a9cc:	b4000257 	cbz	x23, aa14 <f0+0x1044>
    a9d0:	38626862 	ldrb	w2, [x3, x2]
    a9d4:	7100085f 	cmp	w2, #0x2
    a9d8:	54009c00 	b.eq	bd58 <f0+0x2388>  // b.none
    a9dc:	7100045f 	cmp	w2, #0x1
    a9e0:	540001a1 	b.ne	aa14 <f0+0x1044>  // b.any
    a9e4:	29430002 	ldp	w2, w0, [x0, #24]
    a9e8:	92403c21 	and	x1, x1, #0xffff
    a9ec:	9b027c21 	mul	x1, x1, x2
    a9f0:	d360fc21 	lsr	x1, x1, #32
    a9f4:	eb00003f 	cmp	x1, x0
    a9f8:	540000e2 	b.cs	aa14 <f0+0x1044>  // b.hs, b.nlast
    a9fc:	8b0102f7 	add	x23, x23, x1
    aa00:	394002e0 	ldrb	w0, [x23]
    aa04:	7103fc1f 	cmp	w0, #0xff
    aa08:	5400a920 	b.eq	bf2c <f0+0x255c>  // b.none
    aa0c:	52800020 	mov	w0, #0x1                   	// #1
    aa10:	390002e0 	strb	w0, [x23]
    aa14:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aa18:	911323e1 	add	x1, sp, #0x4c8
    aa1c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aa20:	52800020 	mov	w0, #0x1                   	// #1
    aa24:	f90267e2 	str	x2, [sp, #1224]
    aa28:	f9026bf5 	str	x21, [sp, #1232]
    aa2c:	97ffe8d6 	bl	4d84 <fwp_data.part.0.constprop.0>
    aa30:	91150283 	add	x3, x20, #0x540
    aa34:	aa0003f5 	mov	x21, x0
    aa38:	f949d861 	ldr	x1, [x3, #5040]
    aa3c:	f949ec60 	ldr	x0, [x3, #5080]
    aa40:	cb0102a1 	sub	x1, x21, x1
    aa44:	eb00403f 	cmp	x1, x0, lsl #16
    aa48:	54000322 	b.cs	aaac <f0+0x10dc>  // b.hs, b.nlast
    aa4c:	d350fc22 	lsr	x2, x1, #16
    aa50:	f949fc63 	ldr	x3, [x3, #5112]
    aa54:	8b020842 	add	x2, x2, x2, lsl #2
    aa58:	d37df042 	lsl	x2, x2, #3
    aa5c:	8b020060 	add	x0, x3, x2
    aa60:	f9401017 	ldr	x23, [x0, #32]
    aa64:	b4000257 	cbz	x23, aaac <f0+0x10dc>
    aa68:	38626862 	ldrb	w2, [x3, x2]
    aa6c:	7100085f 	cmp	w2, #0x2
    aa70:	54009440 	b.eq	bcf8 <f0+0x2328>  // b.none
    aa74:	7100045f 	cmp	w2, #0x1
    aa78:	540001a1 	b.ne	aaac <f0+0x10dc>  // b.any
    aa7c:	29430002 	ldp	w2, w0, [x0, #24]
    aa80:	92403c21 	and	x1, x1, #0xffff
    aa84:	9b027c21 	mul	x1, x1, x2
    aa88:	d360fc21 	lsr	x1, x1, #32
    aa8c:	eb00003f 	cmp	x1, x0
    aa90:	540000e2 	b.cs	aaac <f0+0x10dc>  // b.hs, b.nlast
    aa94:	8b0102f7 	add	x23, x23, x1
    aa98:	394002e0 	ldrb	w0, [x23]
    aa9c:	7103fc1f 	cmp	w0, #0xff
    aaa0:	5400a4c0 	b.eq	bf38 <f0+0x2568>  // b.none
    aaa4:	52800020 	mov	w0, #0x1                   	// #1
    aaa8:	390002e0 	strb	w0, [x23]
    aaac:	911363e1 	add	x1, sp, #0x4d8
    aab0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aab4:	52800020 	mov	w0, #0x1                   	// #1
    aab8:	f9026fe2 	str	x2, [sp, #1240]
    aabc:	f90273f5 	str	x21, [sp, #1248]
    aac0:	97ffe8b1 	bl	4d84 <fwp_data.part.0.constprop.0>
    aac4:	97ffea87 	bl	54e0 <fwp_rc_fresh>
    aac8:	aa0003e2 	mov	x2, x0
    aacc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aad0:	9113a3e1 	add	x1, sp, #0x4e8
    aad4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aad8:	52800020 	mov	w0, #0x1                   	// #1
    aadc:	f90277e3 	str	x3, [sp, #1256]
    aae0:	f9027be2 	str	x2, [sp, #1264]
    aae4:	97ffe8a8 	bl	4d84 <fwp_data.part.0.constprop.0>
    aae8:	91150283 	add	x3, x20, #0x540
    aaec:	aa0003f5 	mov	x21, x0
    aaf0:	f949d861 	ldr	x1, [x3, #5040]
    aaf4:	f949ec60 	ldr	x0, [x3, #5080]
    aaf8:	cb0102a1 	sub	x1, x21, x1
    aafc:	eb00403f 	cmp	x1, x0, lsl #16
    ab00:	54000322 	b.cs	ab64 <f0+0x1194>  // b.hs, b.nlast
    ab04:	d350fc22 	lsr	x2, x1, #16
    ab08:	f949fc63 	ldr	x3, [x3, #5112]
    ab0c:	8b020842 	add	x2, x2, x2, lsl #2
    ab10:	d37df042 	lsl	x2, x2, #3
    ab14:	8b020060 	add	x0, x3, x2
    ab18:	f9401017 	ldr	x23, [x0, #32]
    ab1c:	b4000257 	cbz	x23, ab64 <f0+0x1194>
    ab20:	38626862 	ldrb	w2, [x3, x2]
    ab24:	7100085f 	cmp	w2, #0x2
    ab28:	54008e20 	b.eq	bcec <f0+0x231c>  // b.none
    ab2c:	7100045f 	cmp	w2, #0x1
    ab30:	540001a1 	b.ne	ab64 <f0+0x1194>  // b.any
    ab34:	29430002 	ldp	w2, w0, [x0, #24]
    ab38:	92403c21 	and	x1, x1, #0xffff
    ab3c:	9b027c21 	mul	x1, x1, x2
    ab40:	d360fc21 	lsr	x1, x1, #32
    ab44:	eb00003f 	cmp	x1, x0
    ab48:	540000e2 	b.cs	ab64 <f0+0x1194>  // b.hs, b.nlast
    ab4c:	8b0102f7 	add	x23, x23, x1
    ab50:	394002e0 	ldrb	w0, [x23]
    ab54:	7103fc1f 	cmp	w0, #0xff
    ab58:	54009f60 	b.eq	bf44 <f0+0x2574>  // b.none
    ab5c:	52800020 	mov	w0, #0x1                   	// #1
    ab60:	390002e0 	strb	w0, [x23]
    ab64:	9113e3e1 	add	x1, sp, #0x4f8
    ab68:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ab6c:	52800020 	mov	w0, #0x1                   	// #1
    ab70:	f9027fe2 	str	x2, [sp, #1272]
    ab74:	f90283f5 	str	x21, [sp, #1280]
    ab78:	97ffe883 	bl	4d84 <fwp_data.part.0.constprop.0>
    ab7c:	97ffea59 	bl	54e0 <fwp_rc_fresh>
    ab80:	aa0003e2 	mov	x2, x0
    ab84:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ab88:	911423e1 	add	x1, sp, #0x508
    ab8c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ab90:	52800020 	mov	w0, #0x1                   	// #1
    ab94:	f90287e3 	str	x3, [sp, #1288]
    ab98:	f9028be2 	str	x2, [sp, #1296]
    ab9c:	97ffe87a 	bl	4d84 <fwp_data.part.0.constprop.0>
    aba0:	91150283 	add	x3, x20, #0x540
    aba4:	aa0003f5 	mov	x21, x0
    aba8:	f949d861 	ldr	x1, [x3, #5040]
    abac:	f949ec60 	ldr	x0, [x3, #5080]
    abb0:	cb0102a1 	sub	x1, x21, x1
    abb4:	eb00403f 	cmp	x1, x0, lsl #16
    abb8:	54000322 	b.cs	ac1c <f0+0x124c>  // b.hs, b.nlast
    abbc:	d350fc22 	lsr	x2, x1, #16
    abc0:	f949fc63 	ldr	x3, [x3, #5112]
    abc4:	8b020842 	add	x2, x2, x2, lsl #2
    abc8:	d37df042 	lsl	x2, x2, #3
    abcc:	8b020060 	add	x0, x3, x2
    abd0:	f9401017 	ldr	x23, [x0, #32]
    abd4:	b4000257 	cbz	x23, ac1c <f0+0x124c>
    abd8:	38626862 	ldrb	w2, [x3, x2]
    abdc:	7100085f 	cmp	w2, #0x2
    abe0:	54008800 	b.eq	bce0 <f0+0x2310>  // b.none
    abe4:	7100045f 	cmp	w2, #0x1
    abe8:	540001a1 	b.ne	ac1c <f0+0x124c>  // b.any
    abec:	29430002 	ldp	w2, w0, [x0, #24]
    abf0:	92403c21 	and	x1, x1, #0xffff
    abf4:	9b027c21 	mul	x1, x1, x2
    abf8:	d360fc21 	lsr	x1, x1, #32
    abfc:	eb00003f 	cmp	x1, x0
    ac00:	540000e2 	b.cs	ac1c <f0+0x124c>  // b.hs, b.nlast
    ac04:	8b0102f7 	add	x23, x23, x1
    ac08:	394002e0 	ldrb	w0, [x23]
    ac0c:	7103fc1f 	cmp	w0, #0xff
    ac10:	54009a00 	b.eq	bf50 <f0+0x2580>  // b.none
    ac14:	52800020 	mov	w0, #0x1                   	// #1
    ac18:	390002e0 	strb	w0, [x23]
    ac1c:	911463e1 	add	x1, sp, #0x518
    ac20:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ac24:	52800020 	mov	w0, #0x1                   	// #1
    ac28:	f9028ff7 	str	x23, [sp, #1304]
    ac2c:	f90293f5 	str	x21, [sp, #1312]
    ac30:	97ffe855 	bl	4d84 <fwp_data.part.0.constprop.0>
    ac34:	97ffea2b 	bl	54e0 <fwp_rc_fresh>
    ac38:	aa0003e2 	mov	x2, x0
    ac3c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ac40:	9114a3e1 	add	x1, sp, #0x528
    ac44:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ac48:	52800020 	mov	w0, #0x1                   	// #1
    ac4c:	f90297e3 	str	x3, [sp, #1320]
    ac50:	f9029be2 	str	x2, [sp, #1328]
    ac54:	97ffe84c 	bl	4d84 <fwp_data.part.0.constprop.0>
    ac58:	97ffea22 	bl	54e0 <fwp_rc_fresh>
    ac5c:	aa0003e2 	mov	x2, x0
    ac60:	9114e3e1 	add	x1, sp, #0x538
    ac64:	52800020 	mov	w0, #0x1                   	// #1
    ac68:	f9029ff7 	str	x23, [sp, #1336]
    ac6c:	f902a3e2 	str	x2, [sp, #1344]
    ac70:	97ffe845 	bl	4d84 <fwp_data.part.0.constprop.0>
    ac74:	91150283 	add	x3, x20, #0x540
    ac78:	aa0003f5 	mov	x21, x0
    ac7c:	f949d861 	ldr	x1, [x3, #5040]
    ac80:	f949ec60 	ldr	x0, [x3, #5080]
    ac84:	cb0102a1 	sub	x1, x21, x1
    ac88:	eb00403f 	cmp	x1, x0, lsl #16
    ac8c:	54000322 	b.cs	acf0 <f0+0x1320>  // b.hs, b.nlast
    ac90:	d350fc22 	lsr	x2, x1, #16
    ac94:	f949fc63 	ldr	x3, [x3, #5112]
    ac98:	8b020842 	add	x2, x2, x2, lsl #2
    ac9c:	d37df042 	lsl	x2, x2, #3
    aca0:	8b020060 	add	x0, x3, x2
    aca4:	f9401017 	ldr	x23, [x0, #32]
    aca8:	b4000257 	cbz	x23, acf0 <f0+0x1320>
    acac:	38626862 	ldrb	w2, [x3, x2]
    acb0:	7100085f 	cmp	w2, #0x2
    acb4:	54008100 	b.eq	bcd4 <f0+0x2304>  // b.none
    acb8:	7100045f 	cmp	w2, #0x1
    acbc:	540001a1 	b.ne	acf0 <f0+0x1320>  // b.any
    acc0:	29430002 	ldp	w2, w0, [x0, #24]
    acc4:	92403c21 	and	x1, x1, #0xffff
    acc8:	9b027c21 	mul	x1, x1, x2
    accc:	d360fc21 	lsr	x1, x1, #32
    acd0:	eb00003f 	cmp	x1, x0
    acd4:	540000e2 	b.cs	acf0 <f0+0x1320>  // b.hs, b.nlast
    acd8:	8b0102f7 	add	x23, x23, x1
    acdc:	394002e0 	ldrb	w0, [x23]
    ace0:	7103fc1f 	cmp	w0, #0xff
    ace4:	540093c0 	b.eq	bf5c <f0+0x258c>  // b.none
    ace8:	52800020 	mov	w0, #0x1                   	// #1
    acec:	390002e0 	strb	w0, [x23]
    acf0:	911523e1 	add	x1, sp, #0x548
    acf4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    acf8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    acfc:	52800020 	mov	w0, #0x1                   	// #1
    ad00:	f902a7f7 	str	x23, [sp, #1352]
    ad04:	f902abf5 	str	x21, [sp, #1360]
    ad08:	97ffe81f 	bl	4d84 <fwp_data.part.0.constprop.0>
    ad0c:	97ffe9f5 	bl	54e0 <fwp_rc_fresh>
    ad10:	aa0003e2 	mov	x2, x0
    ad14:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ad18:	911563e1 	add	x1, sp, #0x558
    ad1c:	52800020 	mov	w0, #0x1                   	// #1
    ad20:	f902afe3 	str	x3, [sp, #1368]
    ad24:	f902b3e2 	str	x2, [sp, #1376]
    ad28:	97ffe817 	bl	4d84 <fwp_data.part.0.constprop.0>
    ad2c:	97ffe9ed 	bl	54e0 <fwp_rc_fresh>
    ad30:	aa0003e2 	mov	x2, x0
    ad34:	9115a3e1 	add	x1, sp, #0x568
    ad38:	52800020 	mov	w0, #0x1                   	// #1
    ad3c:	f902b7f7 	str	x23, [sp, #1384]
    ad40:	f902bbe2 	str	x2, [sp, #1392]
    ad44:	97ffe810 	bl	4d84 <fwp_data.part.0.constprop.0>
    ad48:	91150283 	add	x3, x20, #0x540
    ad4c:	aa0003f5 	mov	x21, x0
    ad50:	f949d861 	ldr	x1, [x3, #5040]
    ad54:	f949ec60 	ldr	x0, [x3, #5080]
    ad58:	cb0102a1 	sub	x1, x21, x1
    ad5c:	eb00403f 	cmp	x1, x0, lsl #16
    ad60:	54000322 	b.cs	adc4 <f0+0x13f4>  // b.hs, b.nlast
    ad64:	d350fc22 	lsr	x2, x1, #16
    ad68:	f949fc63 	ldr	x3, [x3, #5112]
    ad6c:	8b020842 	add	x2, x2, x2, lsl #2
    ad70:	d37df042 	lsl	x2, x2, #3
    ad74:	8b020060 	add	x0, x3, x2
    ad78:	f9401017 	ldr	x23, [x0, #32]
    ad7c:	b4000257 	cbz	x23, adc4 <f0+0x13f4>
    ad80:	38626862 	ldrb	w2, [x3, x2]
    ad84:	7100085f 	cmp	w2, #0x2
    ad88:	54007a00 	b.eq	bcc8 <f0+0x22f8>  // b.none
    ad8c:	7100045f 	cmp	w2, #0x1
    ad90:	540001a1 	b.ne	adc4 <f0+0x13f4>  // b.any
    ad94:	29430002 	ldp	w2, w0, [x0, #24]
    ad98:	92403c21 	and	x1, x1, #0xffff
    ad9c:	9b027c21 	mul	x1, x1, x2
    ada0:	d360fc21 	lsr	x1, x1, #32
    ada4:	eb00003f 	cmp	x1, x0
    ada8:	540000e2 	b.cs	adc4 <f0+0x13f4>  // b.hs, b.nlast
    adac:	8b0102f7 	add	x23, x23, x1
    adb0:	394002e0 	ldrb	w0, [x23]
    adb4:	7103fc1f 	cmp	w0, #0xff
    adb8:	54008d80 	b.eq	bf68 <f0+0x2598>  // b.none
    adbc:	52800020 	mov	w0, #0x1                   	// #1
    adc0:	390002e0 	strb	w0, [x23]
    adc4:	9115e3e1 	add	x1, sp, #0x578
    adc8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    adcc:	52800020 	mov	w0, #0x1                   	// #1
    add0:	f902bfe2 	str	x2, [sp, #1400]
    add4:	f902c3f5 	str	x21, [sp, #1408]
    add8:	97ffe7eb 	bl	4d84 <fwp_data.part.0.constprop.0>
    addc:	97ffe9c1 	bl	54e0 <fwp_rc_fresh>
    ade0:	aa0003e2 	mov	x2, x0
    ade4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ade8:	911623e1 	add	x1, sp, #0x588
    adec:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    adf0:	52800020 	mov	w0, #0x1                   	// #1
    adf4:	f902c7e3 	str	x3, [sp, #1416]
    adf8:	f902cbe2 	str	x2, [sp, #1424]
    adfc:	97ffe7e2 	bl	4d84 <fwp_data.part.0.constprop.0>
    ae00:	91150283 	add	x3, x20, #0x540
    ae04:	aa0003f5 	mov	x21, x0
    ae08:	f949d861 	ldr	x1, [x3, #5040]
    ae0c:	f949ec60 	ldr	x0, [x3, #5080]
    ae10:	cb0102a1 	sub	x1, x21, x1
    ae14:	eb00403f 	cmp	x1, x0, lsl #16
    ae18:	54000322 	b.cs	ae7c <f0+0x14ac>  // b.hs, b.nlast
    ae1c:	d350fc22 	lsr	x2, x1, #16
    ae20:	f949fc63 	ldr	x3, [x3, #5112]
    ae24:	8b020842 	add	x2, x2, x2, lsl #2
    ae28:	d37df042 	lsl	x2, x2, #3
    ae2c:	8b020060 	add	x0, x3, x2
    ae30:	f9401017 	ldr	x23, [x0, #32]
    ae34:	b4000257 	cbz	x23, ae7c <f0+0x14ac>
    ae38:	38626862 	ldrb	w2, [x3, x2]
    ae3c:	7100085f 	cmp	w2, #0x2
    ae40:	540073e0 	b.eq	bcbc <f0+0x22ec>  // b.none
    ae44:	7100045f 	cmp	w2, #0x1
    ae48:	540001a1 	b.ne	ae7c <f0+0x14ac>  // b.any
    ae4c:	29430002 	ldp	w2, w0, [x0, #24]
    ae50:	92403c21 	and	x1, x1, #0xffff
    ae54:	9b027c21 	mul	x1, x1, x2
    ae58:	d360fc21 	lsr	x1, x1, #32
    ae5c:	eb00003f 	cmp	x1, x0
    ae60:	540000e2 	b.cs	ae7c <f0+0x14ac>  // b.hs, b.nlast
    ae64:	8b0102f7 	add	x23, x23, x1
    ae68:	394002e0 	ldrb	w0, [x23]
    ae6c:	7103fc1f 	cmp	w0, #0xff
    ae70:	54008820 	b.eq	bf74 <f0+0x25a4>  // b.none
    ae74:	52800020 	mov	w0, #0x1                   	// #1
    ae78:	390002e0 	strb	w0, [x23]
    ae7c:	911663e1 	add	x1, sp, #0x598
    ae80:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ae84:	52800020 	mov	w0, #0x1                   	// #1
    ae88:	f902cff7 	str	x23, [sp, #1432]
    ae8c:	f902d3f5 	str	x21, [sp, #1440]
    ae90:	97ffe7bd 	bl	4d84 <fwp_data.part.0.constprop.0>
    ae94:	97ffe993 	bl	54e0 <fwp_rc_fresh>
    ae98:	aa0003e2 	mov	x2, x0
    ae9c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aea0:	9116a3e1 	add	x1, sp, #0x5a8
    aea4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aea8:	52800020 	mov	w0, #0x1                   	// #1
    aeac:	f902d7e3 	str	x3, [sp, #1448]
    aeb0:	f902dbe2 	str	x2, [sp, #1456]
    aeb4:	97ffe7b4 	bl	4d84 <fwp_data.part.0.constprop.0>
    aeb8:	97ffe98a 	bl	54e0 <fwp_rc_fresh>
    aebc:	aa0003e2 	mov	x2, x0
    aec0:	9116e3e1 	add	x1, sp, #0x5b8
    aec4:	52800020 	mov	w0, #0x1                   	// #1
    aec8:	f902dff7 	str	x23, [sp, #1464]
    aecc:	f902e3e2 	str	x2, [sp, #1472]
    aed0:	97ffe7ad 	bl	4d84 <fwp_data.part.0.constprop.0>
    aed4:	91150283 	add	x3, x20, #0x540
    aed8:	aa0003f5 	mov	x21, x0
    aedc:	f949d861 	ldr	x1, [x3, #5040]
    aee0:	f949ec60 	ldr	x0, [x3, #5080]
    aee4:	cb0102a1 	sub	x1, x21, x1
    aee8:	eb00403f 	cmp	x1, x0, lsl #16
    aeec:	54000322 	b.cs	af50 <f0+0x1580>  // b.hs, b.nlast
    aef0:	d350fc22 	lsr	x2, x1, #16
    aef4:	f949fc63 	ldr	x3, [x3, #5112]
    aef8:	8b020842 	add	x2, x2, x2, lsl #2
    aefc:	d37df042 	lsl	x2, x2, #3
    af00:	8b020060 	add	x0, x3, x2
    af04:	f9401017 	ldr	x23, [x0, #32]
    af08:	b4000257 	cbz	x23, af50 <f0+0x1580>
    af0c:	38626862 	ldrb	w2, [x3, x2]
    af10:	7100085f 	cmp	w2, #0x2
    af14:	54006ce0 	b.eq	bcb0 <f0+0x22e0>  // b.none
    af18:	7100045f 	cmp	w2, #0x1
    af1c:	540001a1 	b.ne	af50 <f0+0x1580>  // b.any
    af20:	29430002 	ldp	w2, w0, [x0, #24]
    af24:	92403c21 	and	x1, x1, #0xffff
    af28:	9b027c21 	mul	x1, x1, x2
    af2c:	d360fc21 	lsr	x1, x1, #32
    af30:	eb00003f 	cmp	x1, x0
    af34:	540000e2 	b.cs	af50 <f0+0x1580>  // b.hs, b.nlast
    af38:	8b0102f7 	add	x23, x23, x1
    af3c:	394002e0 	ldrb	w0, [x23]
    af40:	7103fc1f 	cmp	w0, #0xff
    af44:	540081e0 	b.eq	bf80 <f0+0x25b0>  // b.none
    af48:	52800020 	mov	w0, #0x1                   	// #1
    af4c:	390002e0 	strb	w0, [x23]
    af50:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    af54:	911723e1 	add	x1, sp, #0x5c8
    af58:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    af5c:	52800020 	mov	w0, #0x1                   	// #1
    af60:	f902e7e2 	str	x2, [sp, #1480]
    af64:	f902ebf5 	str	x21, [sp, #1488]
    af68:	97ffe787 	bl	4d84 <fwp_data.part.0.constprop.0>
    af6c:	91150283 	add	x3, x20, #0x540
    af70:	aa0003f5 	mov	x21, x0
    af74:	f949d861 	ldr	x1, [x3, #5040]
    af78:	f949ec60 	ldr	x0, [x3, #5080]
    af7c:	cb0102a1 	sub	x1, x21, x1
    af80:	eb00403f 	cmp	x1, x0, lsl #16
    af84:	54000322 	b.cs	afe8 <f0+0x1618>  // b.hs, b.nlast
    af88:	d350fc22 	lsr	x2, x1, #16
    af8c:	f949fc63 	ldr	x3, [x3, #5112]
    af90:	8b020842 	add	x2, x2, x2, lsl #2
    af94:	d37df042 	lsl	x2, x2, #3
    af98:	8b020060 	add	x0, x3, x2
    af9c:	f9401017 	ldr	x23, [x0, #32]
    afa0:	b4000257 	cbz	x23, afe8 <f0+0x1618>
    afa4:	38626862 	ldrb	w2, [x3, x2]
    afa8:	7100085f 	cmp	w2, #0x2
    afac:	540067c0 	b.eq	bca4 <f0+0x22d4>  // b.none
    afb0:	7100045f 	cmp	w2, #0x1
    afb4:	540001a1 	b.ne	afe8 <f0+0x1618>  // b.any
    afb8:	29430002 	ldp	w2, w0, [x0, #24]
    afbc:	92403c21 	and	x1, x1, #0xffff
    afc0:	9b027c21 	mul	x1, x1, x2
    afc4:	d360fc21 	lsr	x1, x1, #32
    afc8:	eb00003f 	cmp	x1, x0
    afcc:	540000e2 	b.cs	afe8 <f0+0x1618>  // b.hs, b.nlast
    afd0:	8b0102f7 	add	x23, x23, x1
    afd4:	394002e0 	ldrb	w0, [x23]
    afd8:	7103fc1f 	cmp	w0, #0xff
    afdc:	54007d80 	b.eq	bf8c <f0+0x25bc>  // b.none
    afe0:	52800020 	mov	w0, #0x1                   	// #1
    afe4:	390002e0 	strb	w0, [x23]
    afe8:	911763e1 	add	x1, sp, #0x5d8
    afec:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aff0:	52800020 	mov	w0, #0x1                   	// #1
    aff4:	f902efe2 	str	x2, [sp, #1496]
    aff8:	f902f3f5 	str	x21, [sp, #1504]
    affc:	97ffe762 	bl	4d84 <fwp_data.part.0.constprop.0>
    b000:	97ffe938 	bl	54e0 <fwp_rc_fresh>
    b004:	aa0003e2 	mov	x2, x0
    b008:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b00c:	9117a3e1 	add	x1, sp, #0x5e8
    b010:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b014:	52800020 	mov	w0, #0x1                   	// #1
    b018:	f902f7e3 	str	x3, [sp, #1512]
    b01c:	f902fbe2 	str	x2, [sp, #1520]
    b020:	97ffe759 	bl	4d84 <fwp_data.part.0.constprop.0>
    b024:	91150283 	add	x3, x20, #0x540
    b028:	aa0003f5 	mov	x21, x0
    b02c:	f949d861 	ldr	x1, [x3, #5040]
    b030:	f949ec60 	ldr	x0, [x3, #5080]
    b034:	cb0102a1 	sub	x1, x21, x1
    b038:	eb00403f 	cmp	x1, x0, lsl #16
    b03c:	54000322 	b.cs	b0a0 <f0+0x16d0>  // b.hs, b.nlast
    b040:	d350fc22 	lsr	x2, x1, #16
    b044:	f949fc63 	ldr	x3, [x3, #5112]
    b048:	8b020842 	add	x2, x2, x2, lsl #2
    b04c:	d37df042 	lsl	x2, x2, #3
    b050:	8b020060 	add	x0, x3, x2
    b054:	f9401017 	ldr	x23, [x0, #32]
    b058:	b4000257 	cbz	x23, b0a0 <f0+0x16d0>
    b05c:	38626862 	ldrb	w2, [x3, x2]
    b060:	7100085f 	cmp	w2, #0x2
    b064:	54007040 	b.eq	be6c <f0+0x249c>  // b.none
    b068:	7100045f 	cmp	w2, #0x1
    b06c:	540001a1 	b.ne	b0a0 <f0+0x16d0>  // b.any
    b070:	29430002 	ldp	w2, w0, [x0, #24]
    b074:	92403c21 	and	x1, x1, #0xffff
    b078:	9b027c21 	mul	x1, x1, x2
    b07c:	d360fc21 	lsr	x1, x1, #32
    b080:	eb00003f 	cmp	x1, x0
    b084:	540000e2 	b.cs	b0a0 <f0+0x16d0>  // b.hs, b.nlast
    b088:	8b0102f7 	add	x23, x23, x1
    b08c:	394002e0 	ldrb	w0, [x23]
    b090:	7103fc1f 	cmp	w0, #0xff
    b094:	54007820 	b.eq	bf98 <f0+0x25c8>  // b.none
    b098:	52800020 	mov	w0, #0x1                   	// #1
    b09c:	390002e0 	strb	w0, [x23]
    b0a0:	9117e3e1 	add	x1, sp, #0x5f8
    b0a4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b0a8:	52800020 	mov	w0, #0x1                   	// #1
    b0ac:	f902ffe2 	str	x2, [sp, #1528]
    b0b0:	f90303f5 	str	x21, [sp, #1536]
    b0b4:	97ffe734 	bl	4d84 <fwp_data.part.0.constprop.0>
    b0b8:	97ffe90a 	bl	54e0 <fwp_rc_fresh>
    b0bc:	aa0003e2 	mov	x2, x0
    b0c0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b0c4:	911823e1 	add	x1, sp, #0x608
    b0c8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b0cc:	52800020 	mov	w0, #0x1                   	// #1
    b0d0:	f90307e3 	str	x3, [sp, #1544]
    b0d4:	f9030be2 	str	x2, [sp, #1552]
    b0d8:	97ffe72b 	bl	4d84 <fwp_data.part.0.constprop.0>
    b0dc:	91150283 	add	x3, x20, #0x540
    b0e0:	aa0003f5 	mov	x21, x0
    b0e4:	f949d861 	ldr	x1, [x3, #5040]
    b0e8:	f949ec60 	ldr	x0, [x3, #5080]
    b0ec:	cb0102a1 	sub	x1, x21, x1
    b0f0:	eb00403f 	cmp	x1, x0, lsl #16
    b0f4:	54000322 	b.cs	b158 <f0+0x1788>  // b.hs, b.nlast
    b0f8:	d350fc22 	lsr	x2, x1, #16
    b0fc:	f949fc63 	ldr	x3, [x3, #5112]
    b100:	8b020842 	add	x2, x2, x2, lsl #2
    b104:	d37df042 	lsl	x2, x2, #3
    b108:	8b020060 	add	x0, x3, x2
    b10c:	f9401017 	ldr	x23, [x0, #32]
    b110:	b4000257 	cbz	x23, b158 <f0+0x1788>
    b114:	38626862 	ldrb	w2, [x3, x2]
    b118:	7100085f 	cmp	w2, #0x2
    b11c:	54006a20 	b.eq	be60 <f0+0x2490>  // b.none
    b120:	7100045f 	cmp	w2, #0x1
    b124:	540001a1 	b.ne	b158 <f0+0x1788>  // b.any
    b128:	29430002 	ldp	w2, w0, [x0, #24]
    b12c:	92403c21 	and	x1, x1, #0xffff
    b130:	9b027c21 	mul	x1, x1, x2
    b134:	d360fc21 	lsr	x1, x1, #32
    b138:	eb00003f 	cmp	x1, x0
    b13c:	540000e2 	b.cs	b158 <f0+0x1788>  // b.hs, b.nlast
    b140:	8b0102f7 	add	x23, x23, x1
    b144:	394002e0 	ldrb	w0, [x23]
    b148:	7103fc1f 	cmp	w0, #0xff
    b14c:	540072c0 	b.eq	bfa4 <f0+0x25d4>  // b.none
    b150:	52800020 	mov	w0, #0x1                   	// #1
    b154:	390002e0 	strb	w0, [x23]
    b158:	911863e1 	add	x1, sp, #0x618
    b15c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b160:	52800020 	mov	w0, #0x1                   	// #1
    b164:	f9030ff7 	str	x23, [sp, #1560]
    b168:	f90313f5 	str	x21, [sp, #1568]
    b16c:	97ffe706 	bl	4d84 <fwp_data.part.0.constprop.0>
    b170:	97ffe8dc 	bl	54e0 <fwp_rc_fresh>
    b174:	aa0003e2 	mov	x2, x0
    b178:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b17c:	9118a3e1 	add	x1, sp, #0x628
    b180:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b184:	52800020 	mov	w0, #0x1                   	// #1
    b188:	f90317e3 	str	x3, [sp, #1576]
    b18c:	f9031be2 	str	x2, [sp, #1584]
    b190:	97ffe6fd 	bl	4d84 <fwp_data.part.0.constprop.0>
    b194:	97ffe8d3 	bl	54e0 <fwp_rc_fresh>
    b198:	aa0003e2 	mov	x2, x0
    b19c:	9118e3e1 	add	x1, sp, #0x638
    b1a0:	52800020 	mov	w0, #0x1                   	// #1
    b1a4:	f9031ff7 	str	x23, [sp, #1592]
    b1a8:	f90323e2 	str	x2, [sp, #1600]
    b1ac:	97ffe6f6 	bl	4d84 <fwp_data.part.0.constprop.0>
    b1b0:	91150283 	add	x3, x20, #0x540
    b1b4:	aa0003f5 	mov	x21, x0
    b1b8:	f949d861 	ldr	x1, [x3, #5040]
    b1bc:	f949ec60 	ldr	x0, [x3, #5080]
    b1c0:	cb0102a1 	sub	x1, x21, x1
    b1c4:	eb00403f 	cmp	x1, x0, lsl #16
    b1c8:	54000322 	b.cs	b22c <f0+0x185c>  // b.hs, b.nlast
    b1cc:	d350fc22 	lsr	x2, x1, #16
    b1d0:	f949fc63 	ldr	x3, [x3, #5112]
    b1d4:	8b020842 	add	x2, x2, x2, lsl #2
    b1d8:	d37df042 	lsl	x2, x2, #3
    b1dc:	8b020060 	add	x0, x3, x2
    b1e0:	f9401017 	ldr	x23, [x0, #32]
    b1e4:	b4000257 	cbz	x23, b22c <f0+0x185c>
    b1e8:	38626862 	ldrb	w2, [x3, x2]
    b1ec:	7100085f 	cmp	w2, #0x2
    b1f0:	54006320 	b.eq	be54 <f0+0x2484>  // b.none
    b1f4:	7100045f 	cmp	w2, #0x1
    b1f8:	540001a1 	b.ne	b22c <f0+0x185c>  // b.any
    b1fc:	29430002 	ldp	w2, w0, [x0, #24]
    b200:	92403c21 	and	x1, x1, #0xffff
    b204:	9b027c21 	mul	x1, x1, x2
    b208:	d360fc21 	lsr	x1, x1, #32
    b20c:	eb00003f 	cmp	x1, x0
    b210:	540000e2 	b.cs	b22c <f0+0x185c>  // b.hs, b.nlast
    b214:	8b0102f7 	add	x23, x23, x1
    b218:	394002e0 	ldrb	w0, [x23]
    b21c:	7103fc1f 	cmp	w0, #0xff
    b220:	54006c80 	b.eq	bfb0 <f0+0x25e0>  // b.none
    b224:	52800020 	mov	w0, #0x1                   	// #1
    b228:	390002e0 	strb	w0, [x23]
    b22c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b230:	911923e1 	add	x1, sp, #0x648
    b234:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b238:	52800020 	mov	w0, #0x1                   	// #1
    b23c:	f90327e2 	str	x2, [sp, #1608]
    b240:	f9032bf5 	str	x21, [sp, #1616]
    b244:	97ffe6d0 	bl	4d84 <fwp_data.part.0.constprop.0>
    b248:	91150283 	add	x3, x20, #0x540
    b24c:	aa0003f5 	mov	x21, x0
    b250:	f949d861 	ldr	x1, [x3, #5040]
    b254:	f949ec60 	ldr	x0, [x3, #5080]
    b258:	cb0102a1 	sub	x1, x21, x1
    b25c:	eb00403f 	cmp	x1, x0, lsl #16
    b260:	54000322 	b.cs	b2c4 <f0+0x18f4>  // b.hs, b.nlast
    b264:	d350fc22 	lsr	x2, x1, #16
    b268:	f949fc63 	ldr	x3, [x3, #5112]
    b26c:	8b020842 	add	x2, x2, x2, lsl #2
    b270:	d37df042 	lsl	x2, x2, #3
    b274:	8b020060 	add	x0, x3, x2
    b278:	f9401017 	ldr	x23, [x0, #32]
    b27c:	b4000257 	cbz	x23, b2c4 <f0+0x18f4>
    b280:	38626862 	ldrb	w2, [x3, x2]
    b284:	7100085f 	cmp	w2, #0x2
    b288:	54005e00 	b.eq	be48 <f0+0x2478>  // b.none
    b28c:	7100045f 	cmp	w2, #0x1
    b290:	540001a1 	b.ne	b2c4 <f0+0x18f4>  // b.any
    b294:	29430002 	ldp	w2, w0, [x0, #24]
    b298:	92403c21 	and	x1, x1, #0xffff
    b29c:	9b027c21 	mul	x1, x1, x2
    b2a0:	d360fc21 	lsr	x1, x1, #32
    b2a4:	eb00003f 	cmp	x1, x0
    b2a8:	540000e2 	b.cs	b2c4 <f0+0x18f4>  // b.hs, b.nlast
    b2ac:	8b0102f7 	add	x23, x23, x1
    b2b0:	394002e0 	ldrb	w0, [x23]
    b2b4:	7103fc1f 	cmp	w0, #0xff
    b2b8:	54006820 	b.eq	bfbc <f0+0x25ec>  // b.none
    b2bc:	52800020 	mov	w0, #0x1                   	// #1
    b2c0:	390002e0 	strb	w0, [x23]
    b2c4:	911963e1 	add	x1, sp, #0x658
    b2c8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b2cc:	52800020 	mov	w0, #0x1                   	// #1
    b2d0:	f9032ff7 	str	x23, [sp, #1624]
    b2d4:	f90333f5 	str	x21, [sp, #1632]
    b2d8:	97ffe6ab 	bl	4d84 <fwp_data.part.0.constprop.0>
    b2dc:	97ffe881 	bl	54e0 <fwp_rc_fresh>
    b2e0:	aa0003e2 	mov	x2, x0
    b2e4:	9119a3e1 	add	x1, sp, #0x668
    b2e8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b2ec:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b2f0:	52800020 	mov	w0, #0x1                   	// #1
    b2f4:	f90337f5 	str	x21, [sp, #1640]
    b2f8:	f9033be2 	str	x2, [sp, #1648]
    b2fc:	97ffe6a2 	bl	4d84 <fwp_data.part.0.constprop.0>
    b300:	97ffe878 	bl	54e0 <fwp_rc_fresh>
    b304:	aa0003e2 	mov	x2, x0
    b308:	9119e3e1 	add	x1, sp, #0x678
    b30c:	52800020 	mov	w0, #0x1                   	// #1
    b310:	f9033ff7 	str	x23, [sp, #1656]
    b314:	f90343e2 	str	x2, [sp, #1664]
    b318:	97ffe69b 	bl	4d84 <fwp_data.part.0.constprop.0>
    b31c:	97ffe871 	bl	54e0 <fwp_rc_fresh>
    b320:	aa0003e2 	mov	x2, x0
    b324:	911a23e1 	add	x1, sp, #0x688
    b328:	52800020 	mov	w0, #0x1                   	// #1
    b32c:	f90347f5 	str	x21, [sp, #1672]
    b330:	f9034be2 	str	x2, [sp, #1680]
    b334:	97ffe694 	bl	4d84 <fwp_data.part.0.constprop.0>
    b338:	91150283 	add	x3, x20, #0x540
    b33c:	aa0003f5 	mov	x21, x0
    b340:	f949d861 	ldr	x1, [x3, #5040]
    b344:	f949ec60 	ldr	x0, [x3, #5080]
    b348:	cb0102a1 	sub	x1, x21, x1
    b34c:	eb00403f 	cmp	x1, x0, lsl #16
    b350:	54000322 	b.cs	b3b4 <f0+0x19e4>  // b.hs, b.nlast
    b354:	d350fc22 	lsr	x2, x1, #16
    b358:	f949fc63 	ldr	x3, [x3, #5112]
    b35c:	8b020842 	add	x2, x2, x2, lsl #2
    b360:	d37df042 	lsl	x2, x2, #3
    b364:	8b020060 	add	x0, x3, x2
    b368:	f9401017 	ldr	x23, [x0, #32]
    b36c:	b4000257 	cbz	x23, b3b4 <f0+0x19e4>
    b370:	38626862 	ldrb	w2, [x3, x2]
    b374:	7100085f 	cmp	w2, #0x2
    b378:	54005620 	b.eq	be3c <f0+0x246c>  // b.none
    b37c:	7100045f 	cmp	w2, #0x1
    b380:	540001a1 	b.ne	b3b4 <f0+0x19e4>  // b.any
    b384:	29430002 	ldp	w2, w0, [x0, #24]
    b388:	92403c21 	and	x1, x1, #0xffff
    b38c:	9b027c21 	mul	x1, x1, x2
    b390:	d360fc21 	lsr	x1, x1, #32
    b394:	eb00003f 	cmp	x1, x0
    b398:	540000e2 	b.cs	b3b4 <f0+0x19e4>  // b.hs, b.nlast
    b39c:	8b0102f7 	add	x23, x23, x1
    b3a0:	394002e0 	ldrb	w0, [x23]
    b3a4:	7103fc1f 	cmp	w0, #0xff
    b3a8:	54006100 	b.eq	bfc8 <f0+0x25f8>  // b.none
    b3ac:	52800020 	mov	w0, #0x1                   	// #1
    b3b0:	390002e0 	strb	w0, [x23]
    b3b4:	911a63e1 	add	x1, sp, #0x698
    b3b8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b3bc:	52800020 	mov	w0, #0x1                   	// #1
    b3c0:	f9034fe2 	str	x2, [sp, #1688]
    b3c4:	f90353f5 	str	x21, [sp, #1696]
    b3c8:	97ffe66f 	bl	4d84 <fwp_data.part.0.constprop.0>
    b3cc:	97ffe845 	bl	54e0 <fwp_rc_fresh>
    b3d0:	aa0003e2 	mov	x2, x0
    b3d4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b3d8:	911aa3e1 	add	x1, sp, #0x6a8
    b3dc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b3e0:	52800020 	mov	w0, #0x1                   	// #1
    b3e4:	f90357e3 	str	x3, [sp, #1704]
    b3e8:	f9035be2 	str	x2, [sp, #1712]
    b3ec:	97ffe666 	bl	4d84 <fwp_data.part.0.constprop.0>
    b3f0:	91150283 	add	x3, x20, #0x540
    b3f4:	aa0003f5 	mov	x21, x0
    b3f8:	f949d861 	ldr	x1, [x3, #5040]
    b3fc:	f949ec60 	ldr	x0, [x3, #5080]
    b400:	cb0102a1 	sub	x1, x21, x1
    b404:	eb00403f 	cmp	x1, x0, lsl #16
    b408:	54000322 	b.cs	b46c <f0+0x1a9c>  // b.hs, b.nlast
    b40c:	d350fc22 	lsr	x2, x1, #16
    b410:	f949fc63 	ldr	x3, [x3, #5112]
    b414:	8b020842 	add	x2, x2, x2, lsl #2
    b418:	d37df042 	lsl	x2, x2, #3
    b41c:	8b020060 	add	x0, x3, x2
    b420:	f9401017 	ldr	x23, [x0, #32]
    b424:	b4000257 	cbz	x23, b46c <f0+0x1a9c>
    b428:	38626862 	ldrb	w2, [x3, x2]
    b42c:	7100085f 	cmp	w2, #0x2
    b430:	54005000 	b.eq	be30 <f0+0x2460>  // b.none
    b434:	7100045f 	cmp	w2, #0x1
    b438:	540001a1 	b.ne	b46c <f0+0x1a9c>  // b.any
    b43c:	29430002 	ldp	w2, w0, [x0, #24]
    b440:	92403c21 	and	x1, x1, #0xffff
    b444:	9b027c21 	mul	x1, x1, x2
    b448:	d360fc21 	lsr	x1, x1, #32
    b44c:	eb00003f 	cmp	x1, x0
    b450:	540000e2 	b.cs	b46c <f0+0x1a9c>  // b.hs, b.nlast
    b454:	8b0102f7 	add	x23, x23, x1
    b458:	394002e0 	ldrb	w0, [x23]
    b45c:	7103fc1f 	cmp	w0, #0xff
    b460:	54005ba0 	b.eq	bfd4 <f0+0x2604>  // b.none
    b464:	52800020 	mov	w0, #0x1                   	// #1
    b468:	390002e0 	strb	w0, [x23]
    b46c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b470:	911ae3e1 	add	x1, sp, #0x6b8
    b474:	52800020 	mov	w0, #0x1                   	// #1
    b478:	f9035fe2 	str	x2, [sp, #1720]
    b47c:	f90363f5 	str	x21, [sp, #1728]
    b480:	97ffe641 	bl	4d84 <fwp_data.part.0.constprop.0>
    b484:	91150283 	add	x3, x20, #0x540
    b488:	aa0003f5 	mov	x21, x0
    b48c:	f949d861 	ldr	x1, [x3, #5040]
    b490:	f949ec60 	ldr	x0, [x3, #5080]
    b494:	cb0102a1 	sub	x1, x21, x1
    b498:	eb00403f 	cmp	x1, x0, lsl #16
    b49c:	54000322 	b.cs	b500 <f0+0x1b30>  // b.hs, b.nlast
    b4a0:	d350fc22 	lsr	x2, x1, #16
    b4a4:	f949fc63 	ldr	x3, [x3, #5112]
    b4a8:	8b020842 	add	x2, x2, x2, lsl #2
    b4ac:	d37df042 	lsl	x2, x2, #3
    b4b0:	8b020060 	add	x0, x3, x2
    b4b4:	f9401017 	ldr	x23, [x0, #32]
    b4b8:	b4000257 	cbz	x23, b500 <f0+0x1b30>
    b4bc:	38626862 	ldrb	w2, [x3, x2]
    b4c0:	7100085f 	cmp	w2, #0x2
    b4c4:	54004b00 	b.eq	be24 <f0+0x2454>  // b.none
    b4c8:	7100045f 	cmp	w2, #0x1
    b4cc:	540001a1 	b.ne	b500 <f0+0x1b30>  // b.any
    b4d0:	29430002 	ldp	w2, w0, [x0, #24]
    b4d4:	92403c21 	and	x1, x1, #0xffff
    b4d8:	9b027c21 	mul	x1, x1, x2
    b4dc:	d360fc21 	lsr	x1, x1, #32
    b4e0:	eb00003f 	cmp	x1, x0
    b4e4:	540000e2 	b.cs	b500 <f0+0x1b30>  // b.hs, b.nlast
    b4e8:	8b0102f7 	add	x23, x23, x1
    b4ec:	394002e0 	ldrb	w0, [x23]
    b4f0:	7103fc1f 	cmp	w0, #0xff
    b4f4:	54005760 	b.eq	bfe0 <f0+0x2610>  // b.none
    b4f8:	52800020 	mov	w0, #0x1                   	// #1
    b4fc:	390002e0 	strb	w0, [x23]
    b500:	911b23e1 	add	x1, sp, #0x6c8
    b504:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b508:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b50c:	52800020 	mov	w0, #0x1                   	// #1
    b510:	f90367f7 	str	x23, [sp, #1736]
    b514:	f9036bf5 	str	x21, [sp, #1744]
    b518:	97ffe61b 	bl	4d84 <fwp_data.part.0.constprop.0>
    b51c:	97ffe7f1 	bl	54e0 <fwp_rc_fresh>
    b520:	aa0003e2 	mov	x2, x0
    b524:	911b63e1 	add	x1, sp, #0x6d8
    b528:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b52c:	52800020 	mov	w0, #0x1                   	// #1
    b530:	f9036ff5 	str	x21, [sp, #1752]
    b534:	f90373e2 	str	x2, [sp, #1760]
    b538:	97ffe613 	bl	4d84 <fwp_data.part.0.constprop.0>
    b53c:	97ffe7e9 	bl	54e0 <fwp_rc_fresh>
    b540:	aa0003e2 	mov	x2, x0
    b544:	911ba3e1 	add	x1, sp, #0x6e8
    b548:	52800020 	mov	w0, #0x1                   	// #1
    b54c:	f90377f7 	str	x23, [sp, #1768]
    b550:	f9037be2 	str	x2, [sp, #1776]
    b554:	97ffe60c 	bl	4d84 <fwp_data.part.0.constprop.0>
    b558:	97ffe7e2 	bl	54e0 <fwp_rc_fresh>
    b55c:	aa0003e2 	mov	x2, x0
    b560:	911be3e1 	add	x1, sp, #0x6f8
    b564:	52800020 	mov	w0, #0x1                   	// #1
    b568:	f9037ff5 	str	x21, [sp, #1784]
    b56c:	f90383e2 	str	x2, [sp, #1792]
    b570:	97ffe605 	bl	4d84 <fwp_data.part.0.constprop.0>
    b574:	97ffe7db 	bl	54e0 <fwp_rc_fresh>
    b578:	aa0003e2 	mov	x2, x0
    b57c:	911c23e1 	add	x1, sp, #0x708
    b580:	52800020 	mov	w0, #0x1                   	// #1
    b584:	f90387f7 	str	x23, [sp, #1800]
    b588:	f9038be2 	str	x2, [sp, #1808]
    b58c:	97ffe5fe 	bl	4d84 <fwp_data.part.0.constprop.0>
    b590:	97ffe7d4 	bl	54e0 <fwp_rc_fresh>
    b594:	aa0003e2 	mov	x2, x0
    b598:	911c63e1 	add	x1, sp, #0x718
    b59c:	52800020 	mov	w0, #0x1                   	// #1
    b5a0:	f9038ff5 	str	x21, [sp, #1816]
    b5a4:	f90393e2 	str	x2, [sp, #1824]
    b5a8:	97ffe5f7 	bl	4d84 <fwp_data.part.0.constprop.0>
    b5ac:	97ffe7cd 	bl	54e0 <fwp_rc_fresh>
    b5b0:	aa0003e2 	mov	x2, x0
    b5b4:	911ca3e1 	add	x1, sp, #0x728
    b5b8:	52800020 	mov	w0, #0x1                   	// #1
    b5bc:	f90397f7 	str	x23, [sp, #1832]
    b5c0:	f9039be2 	str	x2, [sp, #1840]
    b5c4:	97ffe5f0 	bl	4d84 <fwp_data.part.0.constprop.0>
    b5c8:	97ffe7c6 	bl	54e0 <fwp_rc_fresh>
    b5cc:	aa0003e2 	mov	x2, x0
    b5d0:	911ce3e1 	add	x1, sp, #0x738
    b5d4:	52800020 	mov	w0, #0x1                   	// #1
    b5d8:	f9039ff5 	str	x21, [sp, #1848]
    b5dc:	f903a3e2 	str	x2, [sp, #1856]
    b5e0:	97ffe5e9 	bl	4d84 <fwp_data.part.0.constprop.0>
    b5e4:	91150283 	add	x3, x20, #0x540
    b5e8:	aa0003f5 	mov	x21, x0
    b5ec:	f949d861 	ldr	x1, [x3, #5040]
    b5f0:	f949ec60 	ldr	x0, [x3, #5080]
    b5f4:	cb0102a1 	sub	x1, x21, x1
    b5f8:	eb00403f 	cmp	x1, x0, lsl #16
    b5fc:	54000322 	b.cs	b660 <f0+0x1c90>  // b.hs, b.nlast
    b600:	d350fc22 	lsr	x2, x1, #16
    b604:	f949fc63 	ldr	x3, [x3, #5112]
    b608:	8b020842 	add	x2, x2, x2, lsl #2
    b60c:	d37df042 	lsl	x2, x2, #3
    b610:	8b020060 	add	x0, x3, x2
    b614:	f9401017 	ldr	x23, [x0, #32]
    b618:	b4000257 	cbz	x23, b660 <f0+0x1c90>
    b61c:	38626862 	ldrb	w2, [x3, x2]
    b620:	7100085f 	cmp	w2, #0x2
    b624:	54003fa0 	b.eq	be18 <f0+0x2448>  // b.none
    b628:	7100045f 	cmp	w2, #0x1
    b62c:	540001a1 	b.ne	b660 <f0+0x1c90>  // b.any
    b630:	29430002 	ldp	w2, w0, [x0, #24]
    b634:	92403c21 	and	x1, x1, #0xffff
    b638:	9b027c21 	mul	x1, x1, x2
    b63c:	d360fc21 	lsr	x1, x1, #32
    b640:	eb00003f 	cmp	x1, x0
    b644:	540000e2 	b.cs	b660 <f0+0x1c90>  // b.hs, b.nlast
    b648:	8b0102f7 	add	x23, x23, x1
    b64c:	394002e0 	ldrb	w0, [x23]
    b650:	7103fc1f 	cmp	w0, #0xff
    b654:	54004cc0 	b.eq	bfec <f0+0x261c>  // b.none
    b658:	52800020 	mov	w0, #0x1                   	// #1
    b65c:	390002e0 	strb	w0, [x23]
    b660:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b664:	911d23e1 	add	x1, sp, #0x748
    b668:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b66c:	52800020 	mov	w0, #0x1                   	// #1
    b670:	f903a7e2 	str	x2, [sp, #1864]
    b674:	f903abf5 	str	x21, [sp, #1872]
    b678:	97ffe5c3 	bl	4d84 <fwp_data.part.0.constprop.0>
    b67c:	91150283 	add	x3, x20, #0x540
    b680:	aa0003f5 	mov	x21, x0
    b684:	f949d861 	ldr	x1, [x3, #5040]
    b688:	f949ec60 	ldr	x0, [x3, #5080]
    b68c:	cb0102a1 	sub	x1, x21, x1
    b690:	eb00403f 	cmp	x1, x0, lsl #16
    b694:	54000322 	b.cs	b6f8 <f0+0x1d28>  // b.hs, b.nlast
    b698:	d350fc22 	lsr	x2, x1, #16
    b69c:	f949fc63 	ldr	x3, [x3, #5112]
    b6a0:	8b020842 	add	x2, x2, x2, lsl #2
    b6a4:	d37df042 	lsl	x2, x2, #3
    b6a8:	8b020060 	add	x0, x3, x2
    b6ac:	f9401017 	ldr	x23, [x0, #32]
    b6b0:	b4000257 	cbz	x23, b6f8 <f0+0x1d28>
    b6b4:	38626862 	ldrb	w2, [x3, x2]
    b6b8:	7100085f 	cmp	w2, #0x2
    b6bc:	54003a80 	b.eq	be0c <f0+0x243c>  // b.none
    b6c0:	7100045f 	cmp	w2, #0x1
    b6c4:	540001a1 	b.ne	b6f8 <f0+0x1d28>  // b.any
    b6c8:	29430002 	ldp	w2, w0, [x0, #24]
    b6cc:	92403c21 	and	x1, x1, #0xffff
    b6d0:	9b027c21 	mul	x1, x1, x2
    b6d4:	d360fc21 	lsr	x1, x1, #32
    b6d8:	eb00003f 	cmp	x1, x0
    b6dc:	540000e2 	b.cs	b6f8 <f0+0x1d28>  // b.hs, b.nlast
    b6e0:	8b0102f7 	add	x23, x23, x1
    b6e4:	394002e0 	ldrb	w0, [x23]
    b6e8:	7103fc1f 	cmp	w0, #0xff
    b6ec:	54004860 	b.eq	bff8 <f0+0x2628>  // b.none
    b6f0:	52800020 	mov	w0, #0x1                   	// #1
    b6f4:	390002e0 	strb	w0, [x23]
    b6f8:	911d63e1 	add	x1, sp, #0x758
    b6fc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b700:	52800020 	mov	w0, #0x1                   	// #1
    b704:	f903aff7 	str	x23, [sp, #1880]
    b708:	f903b3f5 	str	x21, [sp, #1888]
    b70c:	97ffe59e 	bl	4d84 <fwp_data.part.0.constprop.0>
    b710:	97ffe774 	bl	54e0 <fwp_rc_fresh>
    b714:	aa0003e2 	mov	x2, x0
    b718:	911da3e1 	add	x1, sp, #0x768
    b71c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b720:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b724:	52800020 	mov	w0, #0x1                   	// #1
    b728:	f903b7f5 	str	x21, [sp, #1896]
    b72c:	f903bbe2 	str	x2, [sp, #1904]
    b730:	97ffe595 	bl	4d84 <fwp_data.part.0.constprop.0>
    b734:	97ffe76b 	bl	54e0 <fwp_rc_fresh>
    b738:	aa0003e2 	mov	x2, x0
    b73c:	911de3e1 	add	x1, sp, #0x778
    b740:	52800020 	mov	w0, #0x1                   	// #1
    b744:	f903bff7 	str	x23, [sp, #1912]
    b748:	f903c3e2 	str	x2, [sp, #1920]
    b74c:	97ffe58e 	bl	4d84 <fwp_data.part.0.constprop.0>
    b750:	97ffe764 	bl	54e0 <fwp_rc_fresh>
    b754:	aa0003e2 	mov	x2, x0
    b758:	911e23e1 	add	x1, sp, #0x788
    b75c:	52800020 	mov	w0, #0x1                   	// #1
    b760:	f903c7f5 	str	x21, [sp, #1928]
    b764:	f903cbe2 	str	x2, [sp, #1936]
    b768:	97ffe587 	bl	4d84 <fwp_data.part.0.constprop.0>
    b76c:	91150283 	add	x3, x20, #0x540
    b770:	aa0003f5 	mov	x21, x0
    b774:	f949d861 	ldr	x1, [x3, #5040]
    b778:	f949ec60 	ldr	x0, [x3, #5080]
    b77c:	cb0102a1 	sub	x1, x21, x1
    b780:	eb00403f 	cmp	x1, x0, lsl #16
    b784:	54000322 	b.cs	b7e8 <f0+0x1e18>  // b.hs, b.nlast
    b788:	d350fc22 	lsr	x2, x1, #16
    b78c:	f949fc63 	ldr	x3, [x3, #5112]
    b790:	8b020842 	add	x2, x2, x2, lsl #2
    b794:	d37df042 	lsl	x2, x2, #3
    b798:	8b020060 	add	x0, x3, x2
    b79c:	f9401017 	ldr	x23, [x0, #32]
    b7a0:	b4000257 	cbz	x23, b7e8 <f0+0x1e18>
    b7a4:	38626862 	ldrb	w2, [x3, x2]
    b7a8:	7100085f 	cmp	w2, #0x2
    b7ac:	540032a0 	b.eq	be00 <f0+0x2430>  // b.none
    b7b0:	7100045f 	cmp	w2, #0x1
    b7b4:	540001a1 	b.ne	b7e8 <f0+0x1e18>  // b.any
    b7b8:	29430002 	ldp	w2, w0, [x0, #24]
    b7bc:	92403c21 	and	x1, x1, #0xffff
    b7c0:	9b027c21 	mul	x1, x1, x2
    b7c4:	d360fc21 	lsr	x1, x1, #32
    b7c8:	eb00003f 	cmp	x1, x0
    b7cc:	540000e2 	b.cs	b7e8 <f0+0x1e18>  // b.hs, b.nlast
    b7d0:	8b0102f7 	add	x23, x23, x1
    b7d4:	394002e0 	ldrb	w0, [x23]
    b7d8:	7103fc1f 	cmp	w0, #0xff
    b7dc:	54004140 	b.eq	c004 <f0+0x2634>  // b.none
    b7e0:	52800020 	mov	w0, #0x1                   	// #1
    b7e4:	390002e0 	strb	w0, [x23]
    b7e8:	911e63e1 	add	x1, sp, #0x798
    b7ec:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b7f0:	52800020 	mov	w0, #0x1                   	// #1
    b7f4:	f903cfe2 	str	x2, [sp, #1944]
    b7f8:	f903d3f5 	str	x21, [sp, #1952]
    b7fc:	97ffe562 	bl	4d84 <fwp_data.part.0.constprop.0>
    b800:	97ffe738 	bl	54e0 <fwp_rc_fresh>
    b804:	aa0003e2 	mov	x2, x0
    b808:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b80c:	911ea3e1 	add	x1, sp, #0x7a8
    b810:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b814:	52800020 	mov	w0, #0x1                   	// #1
    b818:	f903d7e3 	str	x3, [sp, #1960]
    b81c:	f903dbe2 	str	x2, [sp, #1968]
    b820:	97ffe559 	bl	4d84 <fwp_data.part.0.constprop.0>
    b824:	91150283 	add	x3, x20, #0x540
    b828:	aa0003f5 	mov	x21, x0
    b82c:	f949d861 	ldr	x1, [x3, #5040]
    b830:	f949ec60 	ldr	x0, [x3, #5080]
    b834:	cb0102a1 	sub	x1, x21, x1
    b838:	eb00403f 	cmp	x1, x0, lsl #16
    b83c:	54000322 	b.cs	b8a0 <f0+0x1ed0>  // b.hs, b.nlast
    b840:	d350fc22 	lsr	x2, x1, #16
    b844:	f949fc63 	ldr	x3, [x3, #5112]
    b848:	8b020842 	add	x2, x2, x2, lsl #2
    b84c:	d37df042 	lsl	x2, x2, #3
    b850:	8b020060 	add	x0, x3, x2
    b854:	f9401017 	ldr	x23, [x0, #32]
    b858:	b4000257 	cbz	x23, b8a0 <f0+0x1ed0>
    b85c:	38626862 	ldrb	w2, [x3, x2]
    b860:	7100085f 	cmp	w2, #0x2
    b864:	54002c80 	b.eq	bdf4 <f0+0x2424>  // b.none
    b868:	7100045f 	cmp	w2, #0x1
    b86c:	540001a1 	b.ne	b8a0 <f0+0x1ed0>  // b.any
    b870:	29430002 	ldp	w2, w0, [x0, #24]
    b874:	92403c21 	and	x1, x1, #0xffff
    b878:	9b027c21 	mul	x1, x1, x2
    b87c:	d360fc21 	lsr	x1, x1, #32
    b880:	eb00003f 	cmp	x1, x0
    b884:	540000e2 	b.cs	b8a0 <f0+0x1ed0>  // b.hs, b.nlast
    b888:	8b0102f7 	add	x23, x23, x1
    b88c:	394002e0 	ldrb	w0, [x23]
    b890:	7103fc1f 	cmp	w0, #0xff
    b894:	54003be0 	b.eq	c010 <f0+0x2640>  // b.none
    b898:	52800020 	mov	w0, #0x1                   	// #1
    b89c:	390002e0 	strb	w0, [x23]
    b8a0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b8a4:	911ee3e1 	add	x1, sp, #0x7b8
    b8a8:	52800020 	mov	w0, #0x1                   	// #1
    b8ac:	f903dfe2 	str	x2, [sp, #1976]
    b8b0:	f903e3f5 	str	x21, [sp, #1984]
    b8b4:	97ffe534 	bl	4d84 <fwp_data.part.0.constprop.0>
    b8b8:	91150283 	add	x3, x20, #0x540
    b8bc:	aa0003f5 	mov	x21, x0
    b8c0:	f949d861 	ldr	x1, [x3, #5040]
    b8c4:	f949ec60 	ldr	x0, [x3, #5080]
    b8c8:	cb0102a1 	sub	x1, x21, x1
    b8cc:	eb00403f 	cmp	x1, x0, lsl #16
    b8d0:	54000322 	b.cs	b934 <f0+0x1f64>  // b.hs, b.nlast
    b8d4:	d350fc22 	lsr	x2, x1, #16
    b8d8:	f949fc63 	ldr	x3, [x3, #5112]
    b8dc:	8b020842 	add	x2, x2, x2, lsl #2
    b8e0:	d37df042 	lsl	x2, x2, #3
    b8e4:	8b020060 	add	x0, x3, x2
    b8e8:	f9401017 	ldr	x23, [x0, #32]
    b8ec:	b4000257 	cbz	x23, b934 <f0+0x1f64>
    b8f0:	38626862 	ldrb	w2, [x3, x2]
    b8f4:	7100085f 	cmp	w2, #0x2
    b8f8:	54002780 	b.eq	bde8 <f0+0x2418>  // b.none
    b8fc:	7100045f 	cmp	w2, #0x1
    b900:	540001a1 	b.ne	b934 <f0+0x1f64>  // b.any
    b904:	29430002 	ldp	w2, w0, [x0, #24]
    b908:	92403c21 	and	x1, x1, #0xffff
    b90c:	9b027c21 	mul	x1, x1, x2
    b910:	d360fc21 	lsr	x1, x1, #32
    b914:	eb00003f 	cmp	x1, x0
    b918:	540000e2 	b.cs	b934 <f0+0x1f64>  // b.hs, b.nlast
    b91c:	8b0102f7 	add	x23, x23, x1
    b920:	394002e0 	ldrb	w0, [x23]
    b924:	7103fc1f 	cmp	w0, #0xff
    b928:	540037a0 	b.eq	c01c <f0+0x264c>  // b.none
    b92c:	52800020 	mov	w0, #0x1                   	// #1
    b930:	390002e0 	strb	w0, [x23]
    b934:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b938:	911f23e1 	add	x1, sp, #0x7c8
    b93c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b940:	52800020 	mov	w0, #0x1                   	// #1
    b944:	f903e7e2 	str	x2, [sp, #1992]
    b948:	f903ebf5 	str	x21, [sp, #2000]
    b94c:	97ffe50e 	bl	4d84 <fwp_data.part.0.constprop.0>
    b950:	91150283 	add	x3, x20, #0x540
    b954:	aa0003f5 	mov	x21, x0
    b958:	f949d861 	ldr	x1, [x3, #5040]
    b95c:	f949ec60 	ldr	x0, [x3, #5080]
    b960:	cb0102a1 	sub	x1, x21, x1
    b964:	eb00403f 	cmp	x1, x0, lsl #16
    b968:	54000322 	b.cs	b9cc <f0+0x1ffc>  // b.hs, b.nlast
    b96c:	d350fc22 	lsr	x2, x1, #16
    b970:	f949fc63 	ldr	x3, [x3, #5112]
    b974:	8b020842 	add	x2, x2, x2, lsl #2
    b978:	d37df042 	lsl	x2, x2, #3
    b97c:	8b020060 	add	x0, x3, x2
    b980:	f9401017 	ldr	x23, [x0, #32]
    b984:	b4000257 	cbz	x23, b9cc <f0+0x1ffc>
    b988:	38626862 	ldrb	w2, [x3, x2]
    b98c:	7100085f 	cmp	w2, #0x2
    b990:	54002260 	b.eq	bddc <f0+0x240c>  // b.none
    b994:	7100045f 	cmp	w2, #0x1
    b998:	540001a1 	b.ne	b9cc <f0+0x1ffc>  // b.any
    b99c:	29430002 	ldp	w2, w0, [x0, #24]
    b9a0:	92403c21 	and	x1, x1, #0xffff
    b9a4:	9b027c21 	mul	x1, x1, x2
    b9a8:	d360fc21 	lsr	x1, x1, #32
    b9ac:	eb00003f 	cmp	x1, x0
    b9b0:	540000e2 	b.cs	b9cc <f0+0x1ffc>  // b.hs, b.nlast
    b9b4:	8b0102f7 	add	x23, x23, x1
    b9b8:	394002e0 	ldrb	w0, [x23]
    b9bc:	7103fc1f 	cmp	w0, #0xff
    b9c0:	54003340 	b.eq	c028 <f0+0x2658>  // b.none
    b9c4:	52800020 	mov	w0, #0x1                   	// #1
    b9c8:	390002e0 	strb	w0, [x23]
    b9cc:	911f63e1 	add	x1, sp, #0x7d8
    b9d0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b9d4:	52800020 	mov	w0, #0x1                   	// #1
    b9d8:	f903eff7 	str	x23, [sp, #2008]
    b9dc:	f903f3f5 	str	x21, [sp, #2016]
    b9e0:	97ffe4e9 	bl	4d84 <fwp_data.part.0.constprop.0>
    b9e4:	97ffe6bf 	bl	54e0 <fwp_rc_fresh>
    b9e8:	aa0003e2 	mov	x2, x0
    b9ec:	911fa3e1 	add	x1, sp, #0x7e8
    b9f0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b9f4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b9f8:	52800020 	mov	w0, #0x1                   	// #1
    b9fc:	f903f7f5 	str	x21, [sp, #2024]
    ba00:	f903fbe2 	str	x2, [sp, #2032]
    ba04:	97ffe4e0 	bl	4d84 <fwp_data.part.0.constprop.0>
    ba08:	97ffe6b6 	bl	54e0 <fwp_rc_fresh>
    ba0c:	aa0003e2 	mov	x2, x0
    ba10:	911fe3e1 	add	x1, sp, #0x7f8
    ba14:	52800020 	mov	w0, #0x1                   	// #1
    ba18:	f903fff7 	str	x23, [sp, #2040]
    ba1c:	f90403e2 	str	x2, [sp, #2048]
    ba20:	97ffe4d9 	bl	4d84 <fwp_data.part.0.constprop.0>
    ba24:	97ffe6af 	bl	54e0 <fwp_rc_fresh>
    ba28:	aa0003e2 	mov	x2, x0
    ba2c:	912023e1 	add	x1, sp, #0x808
    ba30:	52800020 	mov	w0, #0x1                   	// #1
    ba34:	f90407f5 	str	x21, [sp, #2056]
    ba38:	f9040be2 	str	x2, [sp, #2064]
    ba3c:	97ffe4d2 	bl	4d84 <fwp_data.part.0.constprop.0>
    ba40:	91150283 	add	x3, x20, #0x540
    ba44:	aa0003f5 	mov	x21, x0
    ba48:	f949d861 	ldr	x1, [x3, #5040]
    ba4c:	f949ec60 	ldr	x0, [x3, #5080]
    ba50:	cb0102a1 	sub	x1, x21, x1
    ba54:	eb00403f 	cmp	x1, x0, lsl #16
    ba58:	54000322 	b.cs	babc <f0+0x20ec>  // b.hs, b.nlast
    ba5c:	d350fc22 	lsr	x2, x1, #16
    ba60:	f949fc63 	ldr	x3, [x3, #5112]
    ba64:	8b020842 	add	x2, x2, x2, lsl #2
    ba68:	d37df042 	lsl	x2, x2, #3
    ba6c:	8b020060 	add	x0, x3, x2
    ba70:	f9401017 	ldr	x23, [x0, #32]
    ba74:	b4000257 	cbz	x23, babc <f0+0x20ec>
    ba78:	38626862 	ldrb	w2, [x3, x2]
    ba7c:	7100085f 	cmp	w2, #0x2
    ba80:	54001a80 	b.eq	bdd0 <f0+0x2400>  // b.none
    ba84:	7100045f 	cmp	w2, #0x1
    ba88:	540001a1 	b.ne	babc <f0+0x20ec>  // b.any
    ba8c:	29430002 	ldp	w2, w0, [x0, #24]
    ba90:	92403c21 	and	x1, x1, #0xffff
    ba94:	9b027c21 	mul	x1, x1, x2
    ba98:	d360fc21 	lsr	x1, x1, #32
    ba9c:	eb00003f 	cmp	x1, x0
    baa0:	540000e2 	b.cs	babc <f0+0x20ec>  // b.hs, b.nlast
    baa4:	8b0102f7 	add	x23, x23, x1
    baa8:	394002e0 	ldrb	w0, [x23]
    baac:	7103fc1f 	cmp	w0, #0xff
    bab0:	54002c20 	b.eq	c034 <f0+0x2664>  // b.none
    bab4:	52800020 	mov	w0, #0x1                   	// #1
    bab8:	390002e0 	strb	w0, [x23]
    babc:	912063e1 	add	x1, sp, #0x818
    bac0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bac4:	52800020 	mov	w0, #0x1                   	// #1
    bac8:	f9040fe2 	str	x2, [sp, #2072]
    bacc:	f90413f5 	str	x21, [sp, #2080]
    bad0:	97ffe4ad 	bl	4d84 <fwp_data.part.0.constprop.0>
    bad4:	97ffe683 	bl	54e0 <fwp_rc_fresh>
    bad8:	aa0003e2 	mov	x2, x0
    badc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bae0:	9120a3e1 	add	x1, sp, #0x828
    bae4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bae8:	52800020 	mov	w0, #0x1                   	// #1
    baec:	f90417e3 	str	x3, [sp, #2088]
    baf0:	f9041be2 	str	x2, [sp, #2096]
    baf4:	97ffe4a4 	bl	4d84 <fwp_data.part.0.constprop.0>
    baf8:	91150283 	add	x3, x20, #0x540
    bafc:	aa0003f5 	mov	x21, x0
    bb00:	f949d861 	ldr	x1, [x3, #5040]
    bb04:	f949ec60 	ldr	x0, [x3, #5080]
    bb08:	cb0102a1 	sub	x1, x21, x1
    bb0c:	eb00403f 	cmp	x1, x0, lsl #16
    bb10:	54000322 	b.cs	bb74 <f0+0x21a4>  // b.hs, b.nlast
    bb14:	d350fc22 	lsr	x2, x1, #16
    bb18:	f949fc63 	ldr	x3, [x3, #5112]
    bb1c:	8b020842 	add	x2, x2, x2, lsl #2
    bb20:	d37df042 	lsl	x2, x2, #3
    bb24:	8b020060 	add	x0, x3, x2
    bb28:	f9401017 	ldr	x23, [x0, #32]
    bb2c:	b4000257 	cbz	x23, bb74 <f0+0x21a4>
    bb30:	38626862 	ldrb	w2, [x3, x2]
    bb34:	7100085f 	cmp	w2, #0x2
    bb38:	54001460 	b.eq	bdc4 <f0+0x23f4>  // b.none
    bb3c:	7100045f 	cmp	w2, #0x1
    bb40:	540001a1 	b.ne	bb74 <f0+0x21a4>  // b.any
    bb44:	29430002 	ldp	w2, w0, [x0, #24]
    bb48:	92403c21 	and	x1, x1, #0xffff
    bb4c:	9b027c21 	mul	x1, x1, x2
    bb50:	d360fc21 	lsr	x1, x1, #32
    bb54:	eb00003f 	cmp	x1, x0
    bb58:	540000e2 	b.cs	bb74 <f0+0x21a4>  // b.hs, b.nlast
    bb5c:	8b0102f7 	add	x23, x23, x1
    bb60:	394002e0 	ldrb	w0, [x23]
    bb64:	7103fc1f 	cmp	w0, #0xff
    bb68:	540026c0 	b.eq	c040 <f0+0x2670>  // b.none
    bb6c:	52800020 	mov	w0, #0x1                   	// #1
    bb70:	390002e0 	strb	w0, [x23]
    bb74:	9120e3e1 	add	x1, sp, #0x838
    bb78:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bb7c:	52800020 	mov	w0, #0x1                   	// #1
    bb80:	f9041fe2 	str	x2, [sp, #2104]
    bb84:	f90423f5 	str	x21, [sp, #2112]
    bb88:	97ffe47f 	bl	4d84 <fwp_data.part.0.constprop.0>
    bb8c:	97ffe655 	bl	54e0 <fwp_rc_fresh>
    bb90:	aa0003e2 	mov	x2, x0
    bb94:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bb98:	91150294 	add	x20, x20, #0x540
    bb9c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bba0:	aa1603e1 	mov	x1, x22
    bba4:	52800020 	mov	w0, #0x1                   	// #1
    bba8:	f90427e3 	str	x3, [sp, #2120]
    bbac:	f9042be2 	str	x2, [sp, #2128]
    bbb0:	97ffe475 	bl	4d84 <fwp_data.part.0.constprop.0>
    bbb4:	f949da81 	ldr	x1, [x20, #5040]
    bbb8:	aa0003f5 	mov	x21, x0
    bbbc:	f949ee80 	ldr	x0, [x20, #5080]
    bbc0:	cb0102a1 	sub	x1, x21, x1
    bbc4:	eb00403f 	cmp	x1, x0, lsl #16
    bbc8:	54000322 	b.cs	bc2c <f0+0x225c>  // b.hs, b.nlast
    bbcc:	d350fc22 	lsr	x2, x1, #16
    bbd0:	f949fe83 	ldr	x3, [x20, #5112]
    bbd4:	8b020842 	add	x2, x2, x2, lsl #2
    bbd8:	d37df042 	lsl	x2, x2, #3
    bbdc:	8b020060 	add	x0, x3, x2
    bbe0:	f9401014 	ldr	x20, [x0, #32]
    bbe4:	b4000254 	cbz	x20, bc2c <f0+0x225c>
    bbe8:	38626862 	ldrb	w2, [x3, x2]
    bbec:	7100085f 	cmp	w2, #0x2
    bbf0:	54000e40 	b.eq	bdb8 <f0+0x23e8>  // b.none
    bbf4:	7100045f 	cmp	w2, #0x1
    bbf8:	540001a1 	b.ne	bc2c <f0+0x225c>  // b.any
    bbfc:	29430002 	ldp	w2, w0, [x0, #24]
    bc00:	92403c21 	and	x1, x1, #0xffff
    bc04:	9b027c21 	mul	x1, x1, x2
    bc08:	d360fc21 	lsr	x1, x1, #32
    bc0c:	eb00003f 	cmp	x1, x0
    bc10:	540000e2 	b.cs	bc2c <f0+0x225c>  // b.hs, b.nlast
    bc14:	8b010294 	add	x20, x20, x1
    bc18:	39400280 	ldrb	w0, [x20]
    bc1c:	7103fc1f 	cmp	w0, #0xff
    bc20:	540012c0 	b.eq	be78 <f0+0x24a8>  // b.none
    bc24:	52800020 	mov	w0, #0x1                   	// #1
    bc28:	39000280 	strb	w0, [x20]
    bc2c:	aa1303e1 	mov	x1, x19
    bc30:	aa1503e0 	mov	x0, x21
    bc34:	97fff0bf 	bl	7f30 <fwp_hof0.constprop.0>
    bc38:	aa0003f4 	mov	x20, x0
    bc3c:	aa1503e0 	mov	x0, x21
    bc40:	97ffe780 	bl	5a40 <fwp_drop0>
    bc44:	aa1303e0 	mov	x0, x19
    bc48:	97ffe77e 	bl	5a40 <fwp_drop0>
    bc4c:	900000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    bc50:	f947f400 	ldr	x0, [x0, #4072]
    bc54:	f9442fe2 	ldr	x2, [sp, #2136]
    bc58:	f9400001 	ldr	x1, [x0]
    bc5c:	eb010042 	subs	x2, x2, x1
    bc60:	d2800001 	mov	x1, #0x0                   	// #0
    bc64:	54001f41 	b.ne	c04c <f0+0x267c>  // b.any
    bc68:	912183ff 	add	sp, sp, #0x860
    bc6c:	aa1403e0 	mov	x0, x20
    bc70:	a94153f3 	ldp	x19, x20, [sp, #16]
    bc74:	a9425bf5 	ldp	x21, x22, [sp, #32]
    bc78:	a94363f7 	ldp	x23, x24, [sp, #48]
    bc7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    bc80:	a94573fb 	ldp	x27, x28, [sp, #80]
    bc84:	a8c67bfd 	ldp	x29, x30, [sp], #96
    bc88:	d65f03c0 	ret
    bc8c:	aa1b03e0 	mov	x0, x27
    bc90:	97ffe238 	bl	4570 <fwp_rc_forget_slot>
    bc94:	17fff797 	b	9af0 <f0+0x120>
    bc98:	72003c5f 	tst	w2, #0xffff
    bc9c:	54fef2c1 	b.ne	9af4 <f0+0x124>  // b.any
    bca0:	17fff791 	b	9ae4 <f0+0x114>
    bca4:	72003c3f 	tst	w1, #0xffff
    bca8:	54ff9a01 	b.ne	afe8 <f0+0x1618>  // b.any
    bcac:	17fffcca 	b	afd4 <f0+0x1604>
    bcb0:	72003c3f 	tst	w1, #0xffff
    bcb4:	54ff94e1 	b.ne	af50 <f0+0x1580>  // b.any
    bcb8:	17fffca1 	b	af3c <f0+0x156c>
    bcbc:	72003c3f 	tst	w1, #0xffff
    bcc0:	54ff8de1 	b.ne	ae7c <f0+0x14ac>  // b.any
    bcc4:	17fffc69 	b	ae68 <f0+0x1498>
    bcc8:	72003c3f 	tst	w1, #0xffff
    bccc:	54ff87c1 	b.ne	adc4 <f0+0x13f4>  // b.any
    bcd0:	17fffc38 	b	adb0 <f0+0x13e0>
    bcd4:	72003c3f 	tst	w1, #0xffff
    bcd8:	54ff80c1 	b.ne	acf0 <f0+0x1320>  // b.any
    bcdc:	17fffc00 	b	acdc <f0+0x130c>
    bce0:	72003c3f 	tst	w1, #0xffff
    bce4:	54ff79c1 	b.ne	ac1c <f0+0x124c>  // b.any
    bce8:	17fffbc8 	b	ac08 <f0+0x1238>
    bcec:	72003c3f 	tst	w1, #0xffff
    bcf0:	54ff73a1 	b.ne	ab64 <f0+0x1194>  // b.any
    bcf4:	17fffb97 	b	ab50 <f0+0x1180>
    bcf8:	72003c3f 	tst	w1, #0xffff
    bcfc:	54ff6d81 	b.ne	aaac <f0+0x10dc>  // b.any
    bd00:	17fffb66 	b	aa98 <f0+0x10c8>
    bd04:	72003c3f 	tst	w1, #0xffff
    bd08:	54ff1081 	b.ne	9f18 <f0+0x548>  // b.any
    bd0c:	17fff87e 	b	9f04 <f0+0x534>
    bd10:	72003c3f 	tst	w1, #0xffff
    bd14:	54ff0021 	b.ne	9d18 <f0+0x348>  // b.any
    bd18:	17fff7fb 	b	9d04 <f0+0x334>
    bd1c:	72003c3f 	tst	w1, #0xffff
    bd20:	54fefa41 	b.ne	9c68 <f0+0x298>  // b.any
    bd24:	17fff7cc 	b	9c54 <f0+0x284>
    bd28:	72003c3f 	tst	w1, #0xffff
    bd2c:	54ff2e01 	b.ne	a2ec <f0+0x91c>  // b.any
    bd30:	17fff96a 	b	a2d8 <f0+0x908>
    bd34:	72003c3f 	tst	w1, #0xffff
    bd38:	54ff2461 	b.ne	a1c4 <f0+0x7f4>  // b.any
    bd3c:	17fff91d 	b	a1b0 <f0+0x7e0>
    bd40:	72003c3f 	tst	w1, #0xffff
    bd44:	54ff1d61 	b.ne	a0f0 <f0+0x720>  // b.any
    bd48:	17fff8e5 	b	a0dc <f0+0x70c>
    bd4c:	72003c3f 	tst	w1, #0xffff
    bd50:	54ff13c1 	b.ne	9fc8 <f0+0x5f8>  // b.any
    bd54:	17fff898 	b	9fb4 <f0+0x5e4>
    bd58:	72003c3f 	tst	w1, #0xffff
    bd5c:	54ff65c1 	b.ne	aa14 <f0+0x1044>  // b.any
    bd60:	17fffb28 	b	aa00 <f0+0x1030>
    bd64:	72003c3f 	tst	w1, #0xffff
    bd68:	54ff5ec1 	b.ne	a940 <f0+0xf70>  // b.any
    bd6c:	17fffaf0 	b	a92c <f0+0xf5c>
    bd70:	72003c3f 	tst	w1, #0xffff
    bd74:	54ff58a1 	b.ne	a888 <f0+0xeb8>  // b.any
    bd78:	17fffabf 	b	a874 <f0+0xea4>
    bd7c:	72003c3f 	tst	w1, #0xffff
    bd80:	54ff5281 	b.ne	a7d0 <f0+0xe00>  // b.any
    bd84:	17fffa8e 	b	a7bc <f0+0xdec>
    bd88:	72003c3f 	tst	w1, #0xffff
    bd8c:	54ff4d61 	b.ne	a738 <f0+0xd68>  // b.any
    bd90:	17fffa65 	b	a724 <f0+0xd54>
    bd94:	72003c3f 	tst	w1, #0xffff
    bd98:	54ff42e1 	b.ne	a5f4 <f0+0xc24>  // b.any
    bd9c:	17fffa11 	b	a5e0 <f0+0xc10>
    bda0:	72003c3f 	tst	w1, #0xffff
    bda4:	54ff3cc1 	b.ne	a53c <f0+0xb6c>  // b.any
    bda8:	17fff9e0 	b	a528 <f0+0xb58>
    bdac:	72003c3f 	tst	w1, #0xffff
    bdb0:	54ff36a1 	b.ne	a484 <f0+0xab4>  // b.any
    bdb4:	17fff9af 	b	a470 <f0+0xaa0>
    bdb8:	72003c3f 	tst	w1, #0xffff
    bdbc:	54fff381 	b.ne	bc2c <f0+0x225c>  // b.any
    bdc0:	17ffff96 	b	bc18 <f0+0x2248>
    bdc4:	72003c3f 	tst	w1, #0xffff
    bdc8:	54ffed61 	b.ne	bb74 <f0+0x21a4>  // b.any
    bdcc:	17ffff65 	b	bb60 <f0+0x2190>
    bdd0:	72003c3f 	tst	w1, #0xffff
    bdd4:	54ffe741 	b.ne	babc <f0+0x20ec>  // b.any
    bdd8:	17ffff34 	b	baa8 <f0+0x20d8>
    bddc:	72003c3f 	tst	w1, #0xffff
    bde0:	54ffdf61 	b.ne	b9cc <f0+0x1ffc>  // b.any
    bde4:	17fffef5 	b	b9b8 <f0+0x1fe8>
    bde8:	72003c3f 	tst	w1, #0xffff
    bdec:	54ffda41 	b.ne	b934 <f0+0x1f64>  // b.any
    bdf0:	17fffecc 	b	b920 <f0+0x1f50>
    bdf4:	72003c3f 	tst	w1, #0xffff
    bdf8:	54ffd541 	b.ne	b8a0 <f0+0x1ed0>  // b.any
    bdfc:	17fffea4 	b	b88c <f0+0x1ebc>
    be00:	72003c3f 	tst	w1, #0xffff
    be04:	54ffcf21 	b.ne	b7e8 <f0+0x1e18>  // b.any
    be08:	17fffe73 	b	b7d4 <f0+0x1e04>
    be0c:	72003c3f 	tst	w1, #0xffff
    be10:	54ffc741 	b.ne	b6f8 <f0+0x1d28>  // b.any
    be14:	17fffe34 	b	b6e4 <f0+0x1d14>
    be18:	72003c3f 	tst	w1, #0xffff
    be1c:	54ffc221 	b.ne	b660 <f0+0x1c90>  // b.any
    be20:	17fffe0b 	b	b64c <f0+0x1c7c>
    be24:	72003c3f 	tst	w1, #0xffff
    be28:	54ffb6c1 	b.ne	b500 <f0+0x1b30>  // b.any
    be2c:	17fffdb0 	b	b4ec <f0+0x1b1c>
    be30:	72003c3f 	tst	w1, #0xffff
    be34:	54ffb1c1 	b.ne	b46c <f0+0x1a9c>  // b.any
    be38:	17fffd88 	b	b458 <f0+0x1a88>
    be3c:	72003c3f 	tst	w1, #0xffff
    be40:	54ffaba1 	b.ne	b3b4 <f0+0x19e4>  // b.any
    be44:	17fffd57 	b	b3a0 <f0+0x19d0>
    be48:	72003c3f 	tst	w1, #0xffff
    be4c:	54ffa3c1 	b.ne	b2c4 <f0+0x18f4>  // b.any
    be50:	17fffd18 	b	b2b0 <f0+0x18e0>
    be54:	72003c3f 	tst	w1, #0xffff
    be58:	54ff9ea1 	b.ne	b22c <f0+0x185c>  // b.any
    be5c:	17fffcef 	b	b218 <f0+0x1848>
    be60:	72003c3f 	tst	w1, #0xffff
    be64:	54ff97a1 	b.ne	b158 <f0+0x1788>  // b.any
    be68:	17fffcb7 	b	b144 <f0+0x1774>
    be6c:	72003c3f 	tst	w1, #0xffff
    be70:	54ff9181 	b.ne	b0a0 <f0+0x16d0>  // b.any
    be74:	17fffc86 	b	b08c <f0+0x16bc>
    be78:	aa1403e0 	mov	x0, x20
    be7c:	97ffe1bd 	bl	4570 <fwp_rc_forget_slot>
    be80:	17ffff69 	b	bc24 <f0+0x2254>
    be84:	aa1703e0 	mov	x0, x23
    be88:	97ffe1ba 	bl	4570 <fwp_rc_forget_slot>
    be8c:	17fff775 	b	9c60 <f0+0x290>
    be90:	aa1703e0 	mov	x0, x23
    be94:	97ffe1b7 	bl	4570 <fwp_rc_forget_slot>
    be98:	17fff79e 	b	9d10 <f0+0x340>
    be9c:	aa1703e0 	mov	x0, x23
    bea0:	97ffe1b4 	bl	4570 <fwp_rc_forget_slot>
    bea4:	17fff81b 	b	9f10 <f0+0x540>
    bea8:	aa1703e0 	mov	x0, x23
    beac:	97ffe1b1 	bl	4570 <fwp_rc_forget_slot>
    beb0:	17fff844 	b	9fc0 <f0+0x5f0>
    beb4:	aa1703e0 	mov	x0, x23
    beb8:	97ffe1ae 	bl	4570 <fwp_rc_forget_slot>
    bebc:	17fff88b 	b	a0e8 <f0+0x718>
    bec0:	aa1703e0 	mov	x0, x23
    bec4:	97ffe1ab 	bl	4570 <fwp_rc_forget_slot>
    bec8:	17fff8bd 	b	a1bc <f0+0x7ec>
    becc:	aa1703e0 	mov	x0, x23
    bed0:	97ffe1a8 	bl	4570 <fwp_rc_forget_slot>
    bed4:	17fff904 	b	a2e4 <f0+0x914>
    bed8:	aa1703e0 	mov	x0, x23
    bedc:	97ffe1a5 	bl	4570 <fwp_rc_forget_slot>
    bee0:	17fff967 	b	a47c <f0+0xaac>
    bee4:	aa1703e0 	mov	x0, x23
    bee8:	97ffe1a2 	bl	4570 <fwp_rc_forget_slot>
    beec:	17fff992 	b	a534 <f0+0xb64>
    bef0:	aa1503e0 	mov	x0, x21
    bef4:	97ffe19f 	bl	4570 <fwp_rc_forget_slot>
    bef8:	17fff9bd 	b	a5ec <f0+0xc1c>
    befc:	aa1703e0 	mov	x0, x23
    bf00:	97ffe19c 	bl	4570 <fwp_rc_forget_slot>
    bf04:	17fffa0b 	b	a730 <f0+0xd60>
    bf08:	aa1703e0 	mov	x0, x23
    bf0c:	97ffe199 	bl	4570 <fwp_rc_forget_slot>
    bf10:	17fffa2e 	b	a7c8 <f0+0xdf8>
    bf14:	aa1703e0 	mov	x0, x23
    bf18:	97ffe196 	bl	4570 <fwp_rc_forget_slot>
    bf1c:	17fffa59 	b	a880 <f0+0xeb0>
    bf20:	aa1703e0 	mov	x0, x23
    bf24:	97ffe193 	bl	4570 <fwp_rc_forget_slot>
    bf28:	17fffa84 	b	a938 <f0+0xf68>
    bf2c:	aa1703e0 	mov	x0, x23
    bf30:	97ffe190 	bl	4570 <fwp_rc_forget_slot>
    bf34:	17fffab6 	b	aa0c <f0+0x103c>
    bf38:	aa1703e0 	mov	x0, x23
    bf3c:	97ffe18d 	bl	4570 <fwp_rc_forget_slot>
    bf40:	17fffad9 	b	aaa4 <f0+0x10d4>
    bf44:	aa1703e0 	mov	x0, x23
    bf48:	97ffe18a 	bl	4570 <fwp_rc_forget_slot>
    bf4c:	17fffb04 	b	ab5c <f0+0x118c>
    bf50:	aa1703e0 	mov	x0, x23
    bf54:	97ffe187 	bl	4570 <fwp_rc_forget_slot>
    bf58:	17fffb2f 	b	ac14 <f0+0x1244>
    bf5c:	aa1703e0 	mov	x0, x23
    bf60:	97ffe184 	bl	4570 <fwp_rc_forget_slot>
    bf64:	17fffb61 	b	ace8 <f0+0x1318>
    bf68:	aa1703e0 	mov	x0, x23
    bf6c:	97ffe181 	bl	4570 <fwp_rc_forget_slot>
    bf70:	17fffb93 	b	adbc <f0+0x13ec>
    bf74:	aa1703e0 	mov	x0, x23
    bf78:	97ffe17e 	bl	4570 <fwp_rc_forget_slot>
    bf7c:	17fffbbe 	b	ae74 <f0+0x14a4>
    bf80:	aa1703e0 	mov	x0, x23
    bf84:	97ffe17b 	bl	4570 <fwp_rc_forget_slot>
    bf88:	17fffbf0 	b	af48 <f0+0x1578>
    bf8c:	aa1703e0 	mov	x0, x23
    bf90:	97ffe178 	bl	4570 <fwp_rc_forget_slot>
    bf94:	17fffc13 	b	afe0 <f0+0x1610>
    bf98:	aa1703e0 	mov	x0, x23
    bf9c:	97ffe175 	bl	4570 <fwp_rc_forget_slot>
    bfa0:	17fffc3e 	b	b098 <f0+0x16c8>
    bfa4:	aa1703e0 	mov	x0, x23
    bfa8:	97ffe172 	bl	4570 <fwp_rc_forget_slot>
    bfac:	17fffc69 	b	b150 <f0+0x1780>
    bfb0:	aa1703e0 	mov	x0, x23
    bfb4:	97ffe16f 	bl	4570 <fwp_rc_forget_slot>
    bfb8:	17fffc9b 	b	b224 <f0+0x1854>
    bfbc:	aa1703e0 	mov	x0, x23
    bfc0:	97ffe16c 	bl	4570 <fwp_rc_forget_slot>
    bfc4:	17fffcbe 	b	b2bc <f0+0x18ec>
    bfc8:	aa1703e0 	mov	x0, x23
    bfcc:	97ffe169 	bl	4570 <fwp_rc_forget_slot>
    bfd0:	17fffcf7 	b	b3ac <f0+0x19dc>
    bfd4:	aa1703e0 	mov	x0, x23
    bfd8:	97ffe166 	bl	4570 <fwp_rc_forget_slot>
    bfdc:	17fffd22 	b	b464 <f0+0x1a94>
    bfe0:	aa1703e0 	mov	x0, x23
    bfe4:	97ffe163 	bl	4570 <fwp_rc_forget_slot>
    bfe8:	17fffd44 	b	b4f8 <f0+0x1b28>
    bfec:	aa1703e0 	mov	x0, x23
    bff0:	97ffe160 	bl	4570 <fwp_rc_forget_slot>
    bff4:	17fffd99 	b	b658 <f0+0x1c88>
    bff8:	aa1703e0 	mov	x0, x23
    bffc:	97ffe15d 	bl	4570 <fwp_rc_forget_slot>
    c000:	17fffdbc 	b	b6f0 <f0+0x1d20>
    c004:	aa1703e0 	mov	x0, x23
    c008:	97ffe15a 	bl	4570 <fwp_rc_forget_slot>
    c00c:	17fffdf5 	b	b7e0 <f0+0x1e10>
    c010:	aa1703e0 	mov	x0, x23
    c014:	97ffe157 	bl	4570 <fwp_rc_forget_slot>
    c018:	17fffe20 	b	b898 <f0+0x1ec8>
    c01c:	aa1703e0 	mov	x0, x23
    c020:	97ffe154 	bl	4570 <fwp_rc_forget_slot>
    c024:	17fffe42 	b	b92c <f0+0x1f5c>
    c028:	aa1703e0 	mov	x0, x23
    c02c:	97ffe151 	bl	4570 <fwp_rc_forget_slot>
    c030:	17fffe65 	b	b9c4 <f0+0x1ff4>
    c034:	aa1703e0 	mov	x0, x23
    c038:	97ffe14e 	bl	4570 <fwp_rc_forget_slot>
    c03c:	17fffe9e 	b	bab4 <f0+0x20e4>
    c040:	aa1703e0 	mov	x0, x23
    c044:	97ffe14b 	bl	4570 <fwp_rc_forget_slot>
    c048:	17fffec9 	b	bb6c <f0+0x219c>
    c04c:	97ffda0d 	bl	2880 <__stack_chk_fail@plt>

000000000000c050 <fwp_main_thread>:
    c050:	d10443ff 	sub	sp, sp, #0x110
    c054:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c058:	f947f400 	ldr	x0, [x0, #4072]
    c05c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c060:	910303fd 	add	x29, sp, #0xc0
    c064:	a90d53f3 	stp	x19, x20, [sp, #208]
    c068:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xca0>
    c06c:	91150261 	add	x1, x19, #0x540
    c070:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c074:	b953a421 	ldr	w1, [x1, #5028]
    c078:	f9400002 	ldr	x2, [x0]
    c07c:	f9005fe2 	str	x2, [sp, #184]
    c080:	d2800002 	mov	x2, #0x0                   	// #0
    c084:	340025c1 	cbz	w1, c53c <fwp_main_thread+0x4ec>
    c088:	91150273 	add	x19, x19, #0x540
    c08c:	b953aa60 	ldr	w0, [x19, #5032]
    c090:	350024e0 	cbnz	w0, c52c <fwp_main_thread+0x4dc>
    c094:	91001fe2 	add	x2, sp, #0x7
    c098:	900000b5 	adrp	x21, 20000 <__data_start>
    c09c:	900000a3 	adrp	x3, 20000 <__data_start>
    c0a0:	9100c2b3 	add	x19, x21, #0x30
    c0a4:	910d8063 	add	x3, x3, #0x360
    c0a8:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c0ac:	d2a00025 	mov	x5, #0x10000               	// #65536
    c0b0:	910023e0 	add	x0, sp, #0x8
    c0b4:	d2800001 	mov	x1, #0x0                   	// #0
    c0b8:	f90007e3 	str	x3, [sp, #8]
    c0bc:	b90013ff 	str	wzr, [sp, #16]
    c0c0:	a9019262 	stp	x2, x4, [x19, #24]
    c0c4:	f9000fe5 	str	x5, [sp, #24]
    c0c8:	97ffd986 	bl	26e0 <sigaltstack@plt>
    c0cc:	35002520 	cbnz	w0, c570 <fwp_main_thread+0x520>
    c0d0:	4f000400 	movi	v0.4s, #0x0
    c0d4:	9100a3e0 	add	x0, sp, #0x28
    c0d8:	f0ffffa1 	adrp	x1, 3000 <fwp_flush+0x10>
    c0dc:	52800082 	mov	w2, #0x4                   	// #4
    c0e0:	9101c021 	add	x1, x1, #0x70
    c0e4:	72a10002 	movk	w2, #0x800, lsl #16
    c0e8:	910083f4 	add	x20, sp, #0x20
    c0ec:	f90013e1 	str	x1, [sp, #32]
    c0f0:	3d802000 	str	q0, [x0, #128]
    c0f4:	b900abe2 	str	w2, [sp, #168]
    c0f8:	ad000000 	stp	q0, q0, [x0]
    c0fc:	ad010000 	stp	q0, q0, [x0, #32]
    c100:	ad020000 	stp	q0, q0, [x0, #64]
    c104:	ad030000 	stp	q0, q0, [x0, #96]
    c108:	97ffd9ce 	bl	2840 <sigemptyset@plt>
    c10c:	35002320 	cbnz	w0, c570 <fwp_main_thread+0x520>
    c110:	aa1403e1 	mov	x1, x20
    c114:	d2800002 	mov	x2, #0x0                   	// #0
    c118:	52800160 	mov	w0, #0xb                   	// #11
    c11c:	97ffd9e1 	bl	28a0 <sigaction@plt>
    c120:	35002280 	cbnz	w0, c570 <fwp_main_thread+0x520>
    c124:	aa1403e1 	mov	x1, x20
    c128:	d2800002 	mov	x2, #0x0                   	// #0
    c12c:	528000e0 	mov	w0, #0x7                   	// #7
    c130:	97ffd9dc 	bl	28a0 <sigaction@plt>
    c134:	350021e0 	cbnz	w0, c570 <fwp_main_thread+0x520>
    c138:	b942fa60 	ldr	w0, [x19, #760]
    c13c:	a90f63f7 	stp	x23, x24, [sp, #240]
    c140:	34002020 	cbz	w0, c544 <fwp_main_thread+0x4f4>
    c144:	9100c2b6 	add	x22, x21, #0x30
    c148:	f9400ad4 	ldr	x20, [x22, #16]
    c14c:	b40010d4 	cbz	x20, c364 <fwp_main_thread+0x314>
    c150:	aa1403f3 	mov	x19, x20
    c154:	91010297 	add	x23, x20, #0x40
    c158:	f90083f9 	str	x25, [sp, #256]
    c15c:	52800038 	mov	w24, #0x1                   	// #1
    c160:	39414a99 	ldrb	w25, [x20, #82]
    c164:	39014a98 	strb	w24, [x20, #82]
    c168:	f9401680 	ldr	x0, [x20, #40]
    c16c:	b4000620 	cbz	x0, c230 <fwp_main_thread+0x1e0>
    c170:	f9403281 	ldr	x1, [x20, #96]
    c174:	39414680 	ldrb	w0, [x20, #81]
    c178:	b4000b41 	cbz	x1, c2e0 <fwp_main_thread+0x290>
    c17c:	36000a80 	tbz	w0, #0, c2cc <fwp_main_thread+0x27c>
    c180:	39414a62 	ldrb	w2, [x19, #82]
    c184:	f9402280 	ldr	x0, [x20, #64]
    c188:	37000d62 	tbnz	w2, #0, c334 <fwp_main_thread+0x2e4>
    c18c:	f9403261 	ldr	x1, [x19, #96]
    c190:	a911fe77 	stp	x23, xzr, [x19, #280]
    c194:	f9009660 	str	x0, [x19, #296]
    c198:	b4000040 	cbz	x0, c1a0 <fwp_main_thread+0x150>
    c19c:	f9009013 	str	x19, [x0, #288]
    c1a0:	f9002293 	str	x19, [x20, #64]
    c1a4:	b4000101 	cbz	x1, c1c4 <fwp_main_thread+0x174>
    c1a8:	f94046c0 	ldr	x0, [x22, #136]
    c1ac:	39015678 	strb	w24, [x19, #85]
    c1b0:	f9003661 	str	x1, [x19, #104]
    c1b4:	a910827f 	stp	xzr, x0, [x19, #264]
    c1b8:	b4000040 	cbz	x0, c1c0 <fwp_main_thread+0x170>
    c1bc:	f9008413 	str	x19, [x0, #264]
    c1c0:	f90046d3 	str	x19, [x22, #136]
    c1c4:	39015a7f 	strb	wzr, [x19, #86]
    c1c8:	97ffe8e7 	bl	6564 <fwp_block>
    c1cc:	f9408e62 	ldr	x2, [x19, #280]
    c1d0:	b4000142 	cbz	x2, c1f8 <fwp_main_thread+0x1a8>
    c1d4:	a9520261 	ldp	x1, x0, [x19, #288]
    c1d8:	b4000ba1 	cbz	x1, c34c <fwp_main_thread+0x2fc>
    c1dc:	f9009420 	str	x0, [x1, #296]
    c1e0:	f9409660 	ldr	x0, [x19, #296]
    c1e4:	b4000040 	cbz	x0, c1ec <fwp_main_thread+0x19c>
    c1e8:	f9009001 	str	x1, [x0, #288]
    c1ec:	91080260 	add	x0, x19, #0x200
    c1f0:	f900967f 	str	xzr, [x19, #296]
    c1f4:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c1f8:	39415660 	ldrb	w0, [x19, #85]
    c1fc:	f9400ac2 	ldr	x2, [x22, #16]
    c200:	36000960 	tbz	w0, #0, c32c <fwp_main_thread+0x2dc>
    c204:	a9508261 	ldp	x1, x0, [x19, #264]
    c208:	b4000a61 	cbz	x1, c354 <fwp_main_thread+0x304>
    c20c:	f9008820 	str	x0, [x1, #272]
    c210:	b4000040 	cbz	x0, c218 <fwp_main_thread+0x1c8>
    c214:	f9008401 	str	x1, [x0, #264]
    c218:	91080260 	add	x0, x19, #0x200
    c21c:	3901567f 	strb	wzr, [x19, #85]
    c220:	aa0203f3 	mov	x19, x2
    c224:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c228:	f9401680 	ldr	x0, [x20, #40]
    c22c:	b5fffa20 	cbnz	x0, c170 <fwp_main_thread+0x120>
    c230:	9100c2a0 	add	x0, x21, #0x30
    c234:	39014a99 	strb	w25, [x20, #82]
    c238:	f94083f9 	ldr	x25, [sp, #256]
    c23c:	f9416c00 	ldr	x0, [x0, #728]
    c240:	b4001560 	cbz	x0, c4ec <fwp_main_thread+0x49c>
    c244:	9100c2a0 	add	x0, x21, #0x30
    c248:	f9418801 	ldr	x1, [x0, #784]
    c24c:	b903081f 	str	wzr, [x0, #776]
    c250:	eb13003f 	cmp	x1, x19
    c254:	54001681 	b.ne	c524 <fwp_main_thread+0x4d4>  // b.any
    c258:	b4000913 	cbz	x19, c378 <fwp_main_thread+0x328>
    c25c:	9100c2a0 	add	x0, x21, #0x30
    c260:	52800021 	mov	w1, #0x1                   	// #1
    c264:	39014a61 	strb	w1, [x19, #82]
    c268:	f9415805 	ldr	x5, [x0, #688]
    c26c:	b4000865 	cbz	x5, c378 <fwp_main_thread+0x328>
    c270:	394140a0 	ldrb	w0, [x5, #80]
    c274:	37000060 	tbnz	w0, #0, c280 <fwp_main_thread+0x230>
    c278:	aa0503e0 	mov	x0, x5
    c27c:	97ffdc7d 	bl	3470 <fwp_cancel_tree.part.0>
    c280:	f9409ca5 	ldr	x5, [x5, #312]
    c284:	b5ffff65 	cbnz	x5, c270 <fwp_main_thread+0x220>
    c288:	9100c2b4 	add	x20, x21, #0x30
    c28c:	52800036 	mov	w22, #0x1                   	// #1
    c290:	f9402a60 	ldr	x0, [x19, #80]
    c294:	f2001c1f 	tst	x0, #0xff000000ff
    c298:	540000e1 	b.ne	c2b4 <fwp_main_thread+0x264>  // b.any
    c29c:	f9401680 	ldr	x0, [x20, #40]
    c2a0:	39015276 	strb	w22, [x19, #84]
    c2a4:	f900827f 	str	xzr, [x19, #256]
    c2a8:	b40005a0 	cbz	x0, c35c <fwp_main_thread+0x30c>
    c2ac:	f9008013 	str	x19, [x0, #256]
    c2b0:	f9001693 	str	x19, [x20, #40]
    c2b4:	97ffe8ac 	bl	6564 <fwp_block>
    c2b8:	97ffe83e 	bl	63b0 <fwp_free_zombie>
    c2bc:	f9415a80 	ldr	x0, [x20, #688]
    c2c0:	b40005c0 	cbz	x0, c378 <fwp_main_thread+0x328>
    c2c4:	f9418a93 	ldr	x19, [x20, #784]
    c2c8:	17fffff2 	b	c290 <fwp_main_thread+0x240>
    c2cc:	97ffdd0d 	bl	3700 <fwp_now_ns>
    c2d0:	f9403281 	ldr	x1, [x20, #96]
    c2d4:	eb01001f 	cmp	x0, x1
    c2d8:	54000fca 	b.ge	c4d0 <fwp_main_thread+0x480>  // b.tcont
    c2dc:	39414680 	ldrb	w0, [x20, #81]
    c2e0:	39414a62 	ldrb	w2, [x19, #82]
    c2e4:	3707f500 	tbnz	w0, #0, c184 <fwp_main_thread+0x134>
    c2e8:	f9403281 	ldr	x1, [x20, #96]
    c2ec:	370001c2 	tbnz	w2, #0, c324 <fwp_main_thread+0x2d4>
    c2f0:	f9403260 	ldr	x0, [x19, #96]
    c2f4:	b4000180 	cbz	x0, c324 <fwp_main_thread+0x2d4>
    c2f8:	b4000061 	cbz	x1, c304 <fwp_main_thread+0x2b4>
    c2fc:	eb01001f 	cmp	x0, x1
    c300:	9a81d000 	csel	x0, x0, x1, le
    c304:	f9402281 	ldr	x1, [x20, #64]
    c308:	a911fe77 	stp	x23, xzr, [x19, #280]
    c30c:	f9009661 	str	x1, [x19, #296]
    c310:	b4001241 	cbz	x1, c558 <fwp_main_thread+0x508>
    c314:	f9009033 	str	x19, [x1, #288]
    c318:	aa0003e1 	mov	x1, x0
    c31c:	f9002293 	str	x19, [x20, #64]
    c320:	17ffffa2 	b	c1a8 <fwp_main_thread+0x158>
    c324:	f9402280 	ldr	x0, [x20, #64]
    c328:	17ffff9a 	b	c190 <fwp_main_thread+0x140>
    c32c:	aa0203f3 	mov	x19, x2
    c330:	17ffff8e 	b	c168 <fwp_main_thread+0x118>
    c334:	a911fe77 	stp	x23, xzr, [x19, #280]
    c338:	f9009660 	str	x0, [x19, #296]
    c33c:	b4000040 	cbz	x0, c344 <fwp_main_thread+0x2f4>
    c340:	f9009013 	str	x19, [x0, #288]
    c344:	f9002293 	str	x19, [x20, #64]
    c348:	17ffff9f 	b	c1c4 <fwp_main_thread+0x174>
    c34c:	f9000040 	str	x0, [x2]
    c350:	17ffffa5 	b	c1e4 <fwp_main_thread+0x194>
    c354:	f90046c0 	str	x0, [x22, #136]
    c358:	17ffffae 	b	c210 <fwp_main_thread+0x1c0>
    c35c:	f9001a93 	str	x19, [x20, #48]
    c360:	17ffffd4 	b	c2b0 <fwp_main_thread+0x260>
    c364:	f9416ec0 	ldr	x0, [x22, #728]
    c368:	b4000c00 	cbz	x0, c4e8 <fwp_main_thread+0x498>
    c36c:	f9418ac0 	ldr	x0, [x22, #784]
    c370:	b9030adf 	str	wzr, [x22, #776]
    c374:	b5000d80 	cbnz	x0, c524 <fwp_main_thread+0x4d4>
    c378:	9100c2b4 	add	x20, x21, #0x30
    c37c:	97ffe80d 	bl	63b0 <fwp_free_zombie>
    c380:	f9401a80 	ldr	x0, [x20, #48]
    c384:	b5000d00 	cbnz	x0, c524 <fwp_main_thread+0x4d4>
    c388:	f9404680 	ldr	x0, [x20, #136]
    c38c:	b5000cc0 	cbnz	x0, c524 <fwp_main_thread+0x4d4>
    c390:	b940aa93 	ldr	w19, [x20, #168]
    c394:	340001d3 	cbz	w19, c3cc <fwp_main_thread+0x37c>
    c398:	93407e76 	sxtw	x22, w19
    c39c:	51000673 	sub	w19, w19, #0x1
    c3a0:	d1000ad6 	sub	x22, x22, #0x2
    c3a4:	9102c297 	add	x23, x20, #0xb0
    c3a8:	cb3342d6 	sub	x22, x22, w19, uxtw
    c3ac:	93407e73 	sxtw	x19, w19
    c3b0:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    c3b4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    c3b8:	b900aa93 	str	w19, [x20, #168]
    c3bc:	d1000673 	sub	x19, x19, #0x1
    c3c0:	97ffd978 	bl	29a0 <munmap@plt>
    c3c4:	eb16027f 	cmp	x19, x22
    c3c8:	54ffff41 	b.ne	c3b0 <fwp_main_thread+0x360>  // b.any
    c3cc:	900000b3 	adrp	x19, 20000 <__data_start>
    c3d0:	91004260 	add	x0, x19, #0x10
    c3d4:	b9400800 	ldr	w0, [x0, #8]
    c3d8:	37f80040 	tbnz	w0, #31, c3e0 <fwp_main_thread+0x390>
    c3dc:	97ffd92d 	bl	2890 <close@plt>
    c3e0:	9100c2a0 	add	x0, x21, #0x30
    c3e4:	91004261 	add	x1, x19, #0x10
    c3e8:	12800002 	mov	w2, #0xffffffff            	// #-1
    c3ec:	d2800013 	mov	x19, #0x0                   	// #0
    c3f0:	f9418c16 	ldr	x22, [x0, #792]
    c3f4:	b9000822 	str	w2, [x1, #8]
    c3f8:	f9419014 	ldr	x20, [x0, #800]
    c3fc:	b4000176 	cbz	x22, c428 <fwp_main_thread+0x3d8>
    c400:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    c404:	b40000c0 	cbz	x0, c41c <fwp_main_thread+0x3cc>
    c408:	f9400001 	ldr	x1, [x0]
    c40c:	b50008c1 	cbnz	x1, c524 <fwp_main_thread+0x4d4>
    c410:	f9400401 	ldr	x1, [x0, #8]
    c414:	b5000881 	cbnz	x1, c524 <fwp_main_thread+0x4d4>
    c418:	97ffe0f6 	bl	47f0 <fwp_mem_free>
    c41c:	91000673 	add	x19, x19, #0x1
    c420:	eb16027f 	cmp	x19, x22
    c424:	54fffee1 	b.ne	c400 <fwp_main_thread+0x3b0>  // b.any
    c428:	aa1403e0 	mov	x0, x20
    c42c:	97ffe0f1 	bl	47f0 <fwp_mem_free>
    c430:	9100c2a0 	add	x0, x21, #0x30
    c434:	f9418813 	ldr	x19, [x0, #784]
    c438:	f9018c1f 	str	xzr, [x0, #792]
    c43c:	f901901f 	str	xzr, [x0, #800]
    c440:	b40001f3 	cbz	x19, c47c <fwp_main_thread+0x42c>
    c444:	f9401661 	ldr	x1, [x19, #40]
    c448:	b50006e1 	cbnz	x1, c524 <fwp_main_thread+0x4d4>
    c44c:	f9405661 	ldr	x1, [x19, #168]
    c450:	b50006a1 	cbnz	x1, c524 <fwp_main_thread+0x4d4>
    c454:	f9416c01 	ldr	x1, [x0, #728]
    c458:	b5000661 	cbnz	x1, c524 <fwp_main_thread+0x4d4>
    c45c:	f9417400 	ldr	x0, [x0, #744]
    c460:	b5000620 	cbnz	x0, c524 <fwp_main_thread+0x4d4>
    c464:	d2823a02 	mov	x2, #0x11d0                	// #4560
    c468:	90000120 	adrp	x0, 30000 <alt.5+0xfca0>
    c46c:	910d8000 	add	x0, x0, #0x360
    c470:	97ffd8f8 	bl	2850 <memset@plt>
    c474:	aa1303e0 	mov	x0, x19
    c478:	97ffe0de 	bl	47f0 <fwp_mem_free>
    c47c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c480:	f947ec00 	ldr	x0, [x0, #4056]
    c484:	9100c2b5 	add	x21, x21, #0x30
    c488:	f9400000 	ldr	x0, [x0]
    c48c:	f9000abf 	str	xzr, [x21, #16]
    c490:	f9018abf 	str	xzr, [x21, #784]
    c494:	97ffd947 	bl	29b0 <fflush@plt>
    c498:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c49c:	f947f400 	ldr	x0, [x0, #4072]
    c4a0:	f9405fe2 	ldr	x2, [sp, #184]
    c4a4:	f9400001 	ldr	x1, [x0]
    c4a8:	eb010042 	subs	x2, x2, x1
    c4ac:	d2800001 	mov	x1, #0x0                   	// #0
    c4b0:	540006a1 	b.ne	c584 <fwp_main_thread+0x534>  // b.any
    c4b4:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    c4b8:	d2800000 	mov	x0, #0x0                   	// #0
    c4bc:	a94d53f3 	ldp	x19, x20, [sp, #208]
    c4c0:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    c4c4:	a94f63f7 	ldp	x23, x24, [sp, #240]
    c4c8:	910443ff 	add	sp, sp, #0x110
    c4cc:	d65f03c0 	ret
    c4d0:	39414280 	ldrb	w0, [x20, #80]
    c4d4:	3707f040 	tbnz	w0, #0, c2dc <fwp_main_thread+0x28c>
    c4d8:	aa1403e0 	mov	x0, x20
    c4dc:	97ffdbe5 	bl	3470 <fwp_cancel_tree.part.0>
    c4e0:	39414680 	ldrb	w0, [x20, #81]
    c4e4:	17ffff7f 	b	c2e0 <fwp_main_thread+0x290>
    c4e8:	d2800013 	mov	x19, #0x0                   	// #0
    c4ec:	9100c2b4 	add	x20, x21, #0x30
    c4f0:	f9417680 	ldr	x0, [x20, #744]
    c4f4:	b5ffea80 	cbnz	x0, c244 <fwp_main_thread+0x1f4>
    c4f8:	f9416a80 	ldr	x0, [x20, #720]
    c4fc:	97ffe0bd 	bl	47f0 <fwp_mem_free>
    c500:	f9016a9f 	str	xzr, [x20, #720]
    c504:	f901729f 	str	xzr, [x20, #736]
    c508:	f9418a80 	ldr	x0, [x20, #784]
    c50c:	b40002d3 	cbz	x19, c564 <fwp_main_thread+0x514>
    c510:	f900567f 	str	xzr, [x19, #168]
    c514:	f9005e7f 	str	xzr, [x19, #184]
    c518:	b9030a9f 	str	wzr, [x20, #776]
    c51c:	eb00027f 	cmp	x19, x0
    c520:	54ffe9e0 	b.eq	c25c <fwp_main_thread+0x20c>  // b.none
    c524:	f90083f9 	str	x25, [sp, #256]
    c528:	97ffd8ea 	bl	28d0 <abort@plt>
    c52c:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    c530:	91348000 	add	x0, x0, #0xd20
    c534:	940001d3 	bl	cc80 <atexit>
    c538:	17fffed7 	b	c094 <fwp_main_thread+0x44>
    c53c:	97ffde52 	bl	3e84 <fwp_heap_init>
    c540:	17fffed2 	b	c088 <fwp_main_thread+0x38>
    c544:	97fff523 	bl	99d0 <f0>
    c548:	f9018260 	str	x0, [x19, #768]
    c54c:	52800021 	mov	w1, #0x1                   	// #1
    c550:	b902fa61 	str	w1, [x19, #760]
    c554:	17fffefc 	b	c144 <fwp_main_thread+0xf4>
    c558:	aa0003e1 	mov	x1, x0
    c55c:	f9002293 	str	x19, [x20, #64]
    c560:	17ffff12 	b	c1a8 <fwp_main_thread+0x158>
    c564:	b9030a9f 	str	wzr, [x20, #776]
    c568:	b4fff080 	cbz	x0, c378 <fwp_main_thread+0x328>
    c56c:	17ffffee 	b	c524 <fwp_main_thread+0x4d4>
    c570:	b0000000 	adrp	x0, d000 <_IO_stdin_used+0x350>
    c574:	9109a000 	add	x0, x0, #0x268
    c578:	a90f63f7 	stp	x23, x24, [sp, #240]
    c57c:	f90083f9 	str	x25, [sp, #256]
    c580:	97ffdc00 	bl	3580 <fwp_trap>
    c584:	f90083f9 	str	x25, [sp, #256]
    c588:	97ffd8be 	bl	2880 <__stack_chk_fail@plt>
    c58c:	d503201f 	nop

000000000000c590 <__divti3>:
    c590:	d503245f 	bti	c
    c594:	d2800004 	mov	x4, #0x0                   	// #0
    c598:	b7f80721 	tbnz	x1, #63, c67c <__divti3+0xec>
    c59c:	b6f80083 	tbz	x3, #63, c5ac <__divti3+0x1c>
    c5a0:	eb0203e2 	negs	x2, x2
    c5a4:	aa2403e4 	mvn	x4, x4
    c5a8:	da0303e3 	ngc	x3, x3
    c5ac:	aa0203e6 	mov	x6, x2
    c5b0:	aa0003e7 	mov	x7, x0
    c5b4:	aa0103e5 	mov	x5, x1
    c5b8:	b5000583 	cbnz	x3, c668 <__divti3+0xd8>
    c5bc:	eb01005f 	cmp	x2, x1
    c5c0:	54000e69 	b.ls	c78c <__divti3+0x1fc>  // b.plast
    c5c4:	dac01040 	clz	x0, x2
    c5c8:	b40000e0 	cbz	x0, c5e4 <__divti3+0x54>
    c5cc:	4b0003e1 	neg	w1, w0
    c5d0:	9ac020a5 	lsl	x5, x5, x0
    c5d4:	9ac02046 	lsl	x6, x2, x0
    c5d8:	9ac124e1 	lsr	x1, x7, x1
    c5dc:	aa050025 	orr	x5, x1, x5
    c5e0:	9ac020e7 	lsl	x7, x7, x0
    c5e4:	d360fcc8 	lsr	x8, x6, #32
    c5e8:	92407cc2 	and	x2, x6, #0xffffffff
    c5ec:	9ac808a3 	udiv	x3, x5, x8
    c5f0:	9b089465 	msub	x5, x3, x8, x5
    c5f4:	aa0303e0 	mov	x0, x3
    c5f8:	9b037c41 	mul	x1, x2, x3
    c5fc:	93c780a5 	extr	x5, x5, x7, #32
    c600:	eb05003f 	cmp	x1, x5
    c604:	540000a9 	b.ls	c618 <__divti3+0x88>  // b.plast
    c608:	ab0500c5 	adds	x5, x6, x5
    c60c:	d1000460 	sub	x0, x3, #0x1
    c610:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    c614:	540015a8 	b.hi	c8c8 <__divti3+0x338>  // b.pmore
    c618:	cb0100a5 	sub	x5, x5, x1
    c61c:	9ac808a3 	udiv	x3, x5, x8
    c620:	9b089465 	msub	x5, x3, x8, x5
    c624:	aa0303e1 	mov	x1, x3
    c628:	9b037c42 	mul	x2, x2, x3
    c62c:	aa0703e3 	mov	x3, x7
    c630:	b3607ca3 	bfi	x3, x5, #32, #32
    c634:	eb03005f 	cmp	x2, x3
    c638:	540000c9 	b.ls	c650 <__divti3+0xc0>  // b.plast
    c63c:	ab0300c3 	adds	x3, x6, x3
    c640:	d1000425 	sub	x5, x1, #0x1
    c644:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    c648:	d1000821 	sub	x1, x1, #0x2
    c64c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    c650:	aa008020 	orr	x0, x1, x0, lsl #32
    c654:	d2800001 	mov	x1, #0x0                   	// #0
    c658:	b4000064 	cbz	x4, c664 <__divti3+0xd4>
    c65c:	eb0003e0 	negs	x0, x0
    c660:	da0103e1 	ngc	x1, x1
    c664:	d65f03c0 	ret
    c668:	eb01007f 	cmp	x3, x1
    c66c:	54000109 	b.ls	c68c <__divti3+0xfc>  // b.plast
    c670:	d2800001 	mov	x1, #0x0                   	// #0
    c674:	d2800000 	mov	x0, #0x0                   	// #0
    c678:	17fffff8 	b	c658 <__divti3+0xc8>
    c67c:	eb0003e0 	negs	x0, x0
    c680:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    c684:	da0103e1 	ngc	x1, x1
    c688:	17ffffc5 	b	c59c <__divti3+0xc>
    c68c:	dac01067 	clz	x7, x3
    c690:	b40010e7 	cbz	x7, c8ac <__divti3+0x31c>
    c694:	d2800805 	mov	x5, #0x40                  	// #64
    c698:	cb0700a5 	sub	x5, x5, x7
    c69c:	9ac72063 	lsl	x3, x3, x7
    c6a0:	9ac52448 	lsr	x8, x2, x5
    c6a4:	aa030108 	orr	x8, x8, x3
    c6a8:	9ac52426 	lsr	x6, x1, x5
    c6ac:	92407d0a 	and	x10, x8, #0xffffffff
    c6b0:	d360fd09 	lsr	x9, x8, #32
    c6b4:	9ac52403 	lsr	x3, x0, x5
    c6b8:	9ac72021 	lsl	x1, x1, x7
    c6bc:	aa010063 	orr	x3, x3, x1
    c6c0:	9ac72042 	lsl	x2, x2, x7
    c6c4:	9ac908cb 	udiv	x11, x6, x9
    c6c8:	9b099965 	msub	x5, x11, x9, x6
    c6cc:	aa0b03e1 	mov	x1, x11
    c6d0:	9b0b7d46 	mul	x6, x10, x11
    c6d4:	93c380a5 	extr	x5, x5, x3, #32
    c6d8:	eb0500df 	cmp	x6, x5
    c6dc:	540000a9 	b.ls	c6f0 <__divti3+0x160>  // b.plast
    c6e0:	ab050105 	adds	x5, x8, x5
    c6e4:	d1000561 	sub	x1, x11, #0x1
    c6e8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    c6ec:	54000f48 	b.hi	c8d4 <__divti3+0x344>  // b.pmore
    c6f0:	cb0600a6 	sub	x6, x5, x6
    c6f4:	9ac908cb 	udiv	x11, x6, x9
    c6f8:	9b099969 	msub	x9, x11, x9, x6
    c6fc:	aa0b03e5 	mov	x5, x11
    c700:	9b0b7d4a 	mul	x10, x10, x11
    c704:	b3607d23 	bfi	x3, x9, #32, #32
    c708:	eb03015f 	cmp	x10, x3
    c70c:	540000a9 	b.ls	c720 <__divti3+0x190>  // b.plast
    c710:	ab030103 	adds	x3, x8, x3
    c714:	d1000565 	sub	x5, x11, #0x1
    c718:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    c71c:	54000e28 	b.hi	c8e0 <__divti3+0x350>  // b.pmore
    c720:	aa0180a1 	orr	x1, x5, x1, lsl #32
    c724:	92407c48 	and	x8, x2, #0xffffffff
    c728:	2a0503e5 	mov	w5, w5
    c72c:	d360fc42 	lsr	x2, x2, #32
    c730:	d360fc26 	lsr	x6, x1, #32
    c734:	cb0a0063 	sub	x3, x3, x10
    c738:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    c73c:	9b087caa 	mul	x10, x5, x8
    c740:	9b087cc8 	mul	x8, x6, x8
    c744:	9b0220a5 	madd	x5, x5, x2, x8
    c748:	9b027cc6 	mul	x6, x6, x2
    c74c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    c750:	8b0900c5 	add	x5, x6, x9
    c754:	eb02011f 	cmp	x8, x2
    c758:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    c75c:	8b4280c6 	add	x6, x6, x2, lsr #32
    c760:	eb06007f 	cmp	x3, x6
    c764:	540000e3 	b.cc	c780 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    c768:	92407d4a 	and	x10, x10, #0xffffffff
    c76c:	9ac72000 	lsl	x0, x0, x7
    c770:	8b028142 	add	x2, x10, x2, lsl #32
    c774:	eb02001f 	cmp	x0, x2
    c778:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    c77c:	54000a01 	b.ne	c8bc <__divti3+0x32c>  // b.any
    c780:	d1000420 	sub	x0, x1, #0x1
    c784:	d2800001 	mov	x1, #0x0                   	// #0
    c788:	17ffffb4 	b	c658 <__divti3+0xc8>
    c78c:	b5000062 	cbnz	x2, c798 <__divti3+0x208>
    c790:	d2800022 	mov	x2, #0x1                   	// #1
    c794:	9ac30846 	udiv	x6, x2, x3
    c798:	dac010c8 	clz	x8, x6
    c79c:	b5000408 	cbnz	x8, c81c <__divti3+0x28c>
    c7a0:	d360fcc9 	lsr	x9, x6, #32
    c7a4:	92407cc5 	and	x5, x6, #0xffffffff
    c7a8:	cb060023 	sub	x3, x1, x6
    c7ac:	d2800021 	mov	x1, #0x1                   	// #1
    c7b0:	9ac90868 	udiv	x8, x3, x9
    c7b4:	9b098d03 	msub	x3, x8, x9, x3
    c7b8:	aa0803e0 	mov	x0, x8
    c7bc:	9b057d02 	mul	x2, x8, x5
    c7c0:	93c78063 	extr	x3, x3, x7, #32
    c7c4:	eb03005f 	cmp	x2, x3
    c7c8:	540000a9 	b.ls	c7dc <__divti3+0x24c>  // b.plast
    c7cc:	ab0300c3 	adds	x3, x6, x3
    c7d0:	d1000500 	sub	x0, x8, #0x1
    c7d4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    c7d8:	54000968 	b.hi	c904 <__divti3+0x374>  // b.pmore
    c7dc:	cb020063 	sub	x3, x3, x2
    c7e0:	9ac90862 	udiv	x2, x3, x9
    c7e4:	aa0203e8 	mov	x8, x2
    c7e8:	9b098c42 	msub	x2, x2, x9, x3
    c7ec:	aa0703e3 	mov	x3, x7
    c7f0:	9b057d05 	mul	x5, x8, x5
    c7f4:	b3607c43 	bfi	x3, x2, #32, #32
    c7f8:	eb0300bf 	cmp	x5, x3
    c7fc:	540000c9 	b.ls	c814 <__divti3+0x284>  // b.plast
    c800:	ab0300c2 	adds	x2, x6, x3
    c804:	d1000503 	sub	x3, x8, #0x1
    c808:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    c80c:	d1000908 	sub	x8, x8, #0x2
    c810:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    c814:	aa008100 	orr	x0, x8, x0, lsl #32
    c818:	17ffff90 	b	c658 <__divti3+0xc8>
    c81c:	9ac820c6 	lsl	x6, x6, x8
    c820:	d2800803 	mov	x3, #0x40                  	// #64
    c824:	cb080063 	sub	x3, x3, x8
    c828:	d360fcc9 	lsr	x9, x6, #32
    c82c:	9ac82027 	lsl	x7, x1, x8
    c830:	92407cc5 	and	x5, x6, #0xffffffff
    c834:	9ac32422 	lsr	x2, x1, x3
    c838:	9ac32403 	lsr	x3, x0, x3
    c83c:	aa070063 	orr	x3, x3, x7
    c840:	9ac9084a 	udiv	x10, x2, x9
    c844:	9ac82007 	lsl	x7, x0, x8
    c848:	9b098940 	msub	x0, x10, x9, x2
    c84c:	aa0a03e1 	mov	x1, x10
    c850:	9b0a7ca2 	mul	x2, x5, x10
    c854:	93c38000 	extr	x0, x0, x3, #32
    c858:	eb00005f 	cmp	x2, x0
    c85c:	540000a9 	b.ls	c870 <__divti3+0x2e0>  // b.plast
    c860:	ab0000c0 	adds	x0, x6, x0
    c864:	d1000541 	sub	x1, x10, #0x1
    c868:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    c86c:	54000468 	b.hi	c8f8 <__divti3+0x368>  // b.pmore
    c870:	cb020000 	sub	x0, x0, x2
    c874:	9ac9080a 	udiv	x10, x0, x9
    c878:	9b098140 	msub	x0, x10, x9, x0
    c87c:	aa0a03e2 	mov	x2, x10
    c880:	9b0a7ca8 	mul	x8, x5, x10
    c884:	b3607c03 	bfi	x3, x0, #32, #32
    c888:	eb03011f 	cmp	x8, x3
    c88c:	540000a9 	b.ls	c8a0 <__divti3+0x310>  // b.plast
    c890:	ab0300c3 	adds	x3, x6, x3
    c894:	d1000542 	sub	x2, x10, #0x1
    c898:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    c89c:	54000288 	b.hi	c8ec <__divti3+0x35c>  // b.pmore
    c8a0:	cb080063 	sub	x3, x3, x8
    c8a4:	aa018041 	orr	x1, x2, x1, lsl #32
    c8a8:	17ffffc2 	b	c7b0 <__divti3+0x220>
    c8ac:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    c8b0:	d2800001 	mov	x1, #0x0                   	// #0
    c8b4:	9a9f87e0 	cset	x0, ls	// ls = plast
    c8b8:	17ffff68 	b	c658 <__divti3+0xc8>
    c8bc:	aa0103e0 	mov	x0, x1
    c8c0:	d2800001 	mov	x1, #0x0                   	// #0
    c8c4:	17ffff65 	b	c658 <__divti3+0xc8>
    c8c8:	d1000860 	sub	x0, x3, #0x2
    c8cc:	8b0600a5 	add	x5, x5, x6
    c8d0:	17ffff52 	b	c618 <__divti3+0x88>
    c8d4:	d1000961 	sub	x1, x11, #0x2
    c8d8:	8b0800a5 	add	x5, x5, x8
    c8dc:	17ffff85 	b	c6f0 <__divti3+0x160>
    c8e0:	d1000965 	sub	x5, x11, #0x2
    c8e4:	8b080063 	add	x3, x3, x8
    c8e8:	17ffff8e 	b	c720 <__divti3+0x190>
    c8ec:	d1000942 	sub	x2, x10, #0x2
    c8f0:	8b060063 	add	x3, x3, x6
    c8f4:	17ffffeb 	b	c8a0 <__divti3+0x310>
    c8f8:	d1000941 	sub	x1, x10, #0x2
    c8fc:	8b060000 	add	x0, x0, x6
    c900:	17ffffdc 	b	c870 <__divti3+0x2e0>
    c904:	d1000900 	sub	x0, x8, #0x2
    c908:	8b060063 	add	x3, x3, x6
    c90c:	17ffffb4 	b	c7dc <__divti3+0x24c>

000000000000c910 <__modti3>:
    c910:	d503245f 	bti	c
    c914:	d2800004 	mov	x4, #0x0                   	// #0
    c918:	b6f80081 	tbz	x1, #63, c928 <__modti3+0x18>
    c91c:	eb0003e0 	negs	x0, x0
    c920:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    c924:	da0103e1 	ngc	x1, x1
    c928:	f100007f 	cmp	x3, #0x0
    c92c:	5400128b 	b.lt	cb7c <__modti3+0x26c>  // b.tstop
    c930:	aa0003e7 	mov	x7, x0
    c934:	aa0103e6 	mov	x6, x1
    c938:	540004e1 	b.ne	c9d4 <__modti3+0xc4>  // b.any
    c93c:	eb02003f 	cmp	x1, x2
    c940:	54000dc2 	b.cs	caf8 <__modti3+0x1e8>  // b.hs, b.nlast
    c944:	dac01043 	clz	x3, x2
    c948:	aa0303e5 	mov	x5, x3
    c94c:	b40000e3 	cbz	x3, c968 <__modti3+0x58>
    c950:	4b0303e6 	neg	w6, w3
    c954:	9ac32021 	lsl	x1, x1, x3
    c958:	9ac32042 	lsl	x2, x2, x3
    c95c:	9ac62406 	lsr	x6, x0, x6
    c960:	aa0100c6 	orr	x6, x6, x1
    c964:	9ac32007 	lsl	x7, x0, x3
    c968:	d360fc40 	lsr	x0, x2, #32
    c96c:	92407c43 	and	x3, x2, #0xffffffff
    c970:	9ac008c1 	udiv	x1, x6, x0
    c974:	9b009826 	msub	x6, x1, x0, x6
    c978:	9b017c61 	mul	x1, x3, x1
    c97c:	93c780c6 	extr	x6, x6, x7, #32
    c980:	eb06003f 	cmp	x1, x6
    c984:	540000a9 	b.ls	c998 <__modti3+0x88>  // b.plast
    c988:	ab060046 	adds	x6, x2, x6
    c98c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    c990:	8b0200c8 	add	x8, x6, x2
    c994:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    c998:	cb0100c6 	sub	x6, x6, x1
    c99c:	9ac008c8 	udiv	x8, x6, x0
    c9a0:	9b009901 	msub	x1, x8, x0, x6
    c9a4:	aa0703e0 	mov	x0, x7
    c9a8:	9b087c63 	mul	x3, x3, x8
    c9ac:	b3607c20 	bfi	x0, x1, #32, #32
    c9b0:	eb00007f 	cmp	x3, x0
    c9b4:	54001088 	b.hi	cbc4 <__modti3+0x2b4>  // b.pmore
    c9b8:	cb030000 	sub	x0, x0, x3
    c9bc:	9ac52400 	lsr	x0, x0, x5
    c9c0:	d2800001 	mov	x1, #0x0                   	// #0
    c9c4:	b4000064 	cbz	x4, c9d0 <__modti3+0xc0>
    c9c8:	eb0003e0 	negs	x0, x0
    c9cc:	da0103e1 	ngc	x1, x1
    c9d0:	d65f03c0 	ret
    c9d4:	dac01066 	clz	x6, x3
    c9d8:	eb03003f 	cmp	x1, x3
    c9dc:	54ffff43 	b.cc	c9c4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    c9e0:	93407cc5 	sxtw	x5, w6
    c9e4:	d2800808 	mov	x8, #0x40                  	// #64
    c9e8:	cb050108 	sub	x8, x8, x5
    c9ec:	9ac62063 	lsl	x3, x3, x6
    c9f0:	9ac62025 	lsl	x5, x1, x6
    c9f4:	9ac82447 	lsr	x7, x2, x8
    c9f8:	aa0300e7 	orr	x7, x7, x3
    c9fc:	9ac82423 	lsr	x3, x1, x8
    ca00:	92407cec 	and	x12, x7, #0xffffffff
    ca04:	d360fcea 	lsr	x10, x7, #32
    ca08:	9ac82401 	lsr	x1, x0, x8
    ca0c:	aa050021 	orr	x1, x1, x5
    ca10:	9ac62042 	lsl	x2, x2, x6
    ca14:	9ac62000 	lsl	x0, x0, x6
    ca18:	9aca086b 	udiv	x11, x3, x10
    ca1c:	9b0a8d63 	msub	x3, x11, x10, x3
    ca20:	aa0b03e5 	mov	x5, x11
    ca24:	9b0b7d89 	mul	x9, x12, x11
    ca28:	93c18063 	extr	x3, x3, x1, #32
    ca2c:	eb03013f 	cmp	x9, x3
    ca30:	540000a9 	b.ls	ca44 <__modti3+0x134>  // b.plast
    ca34:	ab0300e3 	adds	x3, x7, x3
    ca38:	d1000565 	sub	x5, x11, #0x1
    ca3c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    ca40:	54001168 	b.hi	cc6c <__modti3+0x35c>  // b.pmore
    ca44:	cb090063 	sub	x3, x3, x9
    ca48:	9aca086b 	udiv	x11, x3, x10
    ca4c:	9b0a8d6a 	msub	x10, x11, x10, x3
    ca50:	aa0b03e9 	mov	x9, x11
    ca54:	9b0b7d8c 	mul	x12, x12, x11
    ca58:	b3607d41 	bfi	x1, x10, #32, #32
    ca5c:	eb01019f 	cmp	x12, x1
    ca60:	540000a9 	b.ls	ca74 <__modti3+0x164>  // b.plast
    ca64:	ab0100e1 	adds	x1, x7, x1
    ca68:	d1000569 	sub	x9, x11, #0x1
    ca6c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    ca70:	54000f88 	b.hi	cc60 <__modti3+0x350>  // b.pmore
    ca74:	aa058123 	orr	x3, x9, x5, lsl #32
    ca78:	92407c4b 	and	x11, x2, #0xffffffff
    ca7c:	2a0903e9 	mov	w9, w9
    ca80:	d360fc4a 	lsr	x10, x2, #32
    ca84:	d360fc63 	lsr	x3, x3, #32
    ca88:	cb0c0021 	sub	x1, x1, x12
    ca8c:	aa0a03ec 	mov	x12, x10
    ca90:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    ca94:	9b0b7d25 	mul	x5, x9, x11
    ca98:	9b0b7c6b 	mul	x11, x3, x11
    ca9c:	9b0a2d29 	madd	x9, x9, x10, x11
    caa0:	92407caa 	and	x10, x5, #0xffffffff
    caa4:	9b0c7c63 	mul	x3, x3, x12
    caa8:	8b458125 	add	x5, x9, x5, lsr #32
    caac:	8b0d0069 	add	x9, x3, x13
    cab0:	eb05017f 	cmp	x11, x5
    cab4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    cab8:	8b058149 	add	x9, x10, x5, lsl #32
    cabc:	8b458063 	add	x3, x3, x5, lsr #32
    cac0:	eb03003f 	cmp	x1, x3
    cac4:	54000063 	b.cc	cad0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    cac8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    cacc:	54000082 	b.cs	cadc <__modti3+0x1cc>  // b.hs, b.nlast
    cad0:	eb020129 	subs	x9, x9, x2
    cad4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    cad8:	cb070063 	sub	x3, x3, x7
    cadc:	eb090000 	subs	x0, x0, x9
    cae0:	da030021 	sbc	x1, x1, x3
    cae4:	9ac62400 	lsr	x0, x0, x6
    cae8:	9ac82028 	lsl	x8, x1, x8
    caec:	aa000100 	orr	x0, x8, x0
    caf0:	9ac62421 	lsr	x1, x1, x6
    caf4:	17ffffb4 	b	c9c4 <__modti3+0xb4>
    caf8:	b5000062 	cbnz	x2, cb04 <__modti3+0x1f4>
    cafc:	d2800023 	mov	x3, #0x1                   	// #1
    cb00:	9ac20862 	udiv	x2, x3, x2
    cb04:	dac01048 	clz	x8, x2
    cb08:	aa0803e5 	mov	x5, x8
    cb0c:	b5000668 	cbnz	x8, cbd8 <__modti3+0x2c8>
    cb10:	cb020020 	sub	x0, x1, x2
    cb14:	d360fc49 	lsr	x9, x2, #32
    cb18:	92407c4a 	and	x10, x2, #0xffffffff
    cb1c:	9ac90801 	udiv	x1, x0, x9
    cb20:	9b098020 	msub	x0, x1, x9, x0
    cb24:	9b0a7c21 	mul	x1, x1, x10
    cb28:	93c78000 	extr	x0, x0, x7, #32
    cb2c:	eb00003f 	cmp	x1, x0
    cb30:	540000a9 	b.ls	cb44 <__modti3+0x234>  // b.plast
    cb34:	ab000040 	adds	x0, x2, x0
    cb38:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cb3c:	8b020003 	add	x3, x0, x2
    cb40:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    cb44:	cb010001 	sub	x1, x0, x1
    cb48:	9ac90820 	udiv	x0, x1, x9
    cb4c:	9b098403 	msub	x3, x0, x9, x1
    cb50:	aa0703e1 	mov	x1, x7
    cb54:	9b0a7c00 	mul	x0, x0, x10
    cb58:	b3607c61 	bfi	x1, x3, #32, #32
    cb5c:	eb01001f 	cmp	x0, x1
    cb60:	540000a9 	b.ls	cb74 <__modti3+0x264>  // b.plast
    cb64:	ab010041 	adds	x1, x2, x1
    cb68:	8b020022 	add	x2, x1, x2
    cb6c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    cb70:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    cb74:	cb000020 	sub	x0, x1, x0
    cb78:	17ffff91 	b	c9bc <__modti3+0xac>
    cb7c:	eb0203e5 	negs	x5, x2
    cb80:	aa0003e7 	mov	x7, x0
    cb84:	da0303e8 	ngc	x8, x3
    cb88:	aa0503e2 	mov	x2, x5
    cb8c:	aa0803e3 	mov	x3, x8
    cb90:	aa0103e6 	mov	x6, x1
    cb94:	b4ffed48 	cbz	x8, c93c <__modti3+0x2c>
    cb98:	eb01011f 	cmp	x8, x1
    cb9c:	54fff148 	b.hi	c9c4 <__modti3+0xb4>  // b.pmore
    cba0:	dac01109 	clz	x9, x8
    cba4:	2a0903e6 	mov	w6, w9
    cba8:	b5fff1c9 	cbnz	x9, c9e0 <__modti3+0xd0>
    cbac:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    cbb0:	54000068 	b.hi	cbbc <__modti3+0x2ac>  // b.pmore
    cbb4:	eb050007 	subs	x7, x0, x5
    cbb8:	da080021 	sbc	x1, x1, x8
    cbbc:	aa0703e0 	mov	x0, x7
    cbc0:	17ffff81 	b	c9c4 <__modti3+0xb4>
    cbc4:	ab000040 	adds	x0, x2, x0
    cbc8:	8b020002 	add	x2, x0, x2
    cbcc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    cbd0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    cbd4:	17ffff79 	b	c9b8 <__modti3+0xa8>
    cbd8:	9ac82042 	lsl	x2, x2, x8
    cbdc:	d2800803 	mov	x3, #0x40                  	// #64
    cbe0:	cb080063 	sub	x3, x3, x8
    cbe4:	d360fc49 	lsr	x9, x2, #32
    cbe8:	9ac82027 	lsl	x7, x1, x8
    cbec:	92407c4a 	and	x10, x2, #0xffffffff
    cbf0:	9ac32426 	lsr	x6, x1, x3
    cbf4:	9ac32403 	lsr	x3, x0, x3
    cbf8:	aa070063 	orr	x3, x3, x7
    cbfc:	9ac908c1 	udiv	x1, x6, x9
    cc00:	9ac82007 	lsl	x7, x0, x8
    cc04:	9b099820 	msub	x0, x1, x9, x6
    cc08:	9b017d41 	mul	x1, x10, x1
    cc0c:	93c38000 	extr	x0, x0, x3, #32
    cc10:	eb00003f 	cmp	x1, x0
    cc14:	540000a9 	b.ls	cc28 <__modti3+0x318>  // b.plast
    cc18:	ab000040 	adds	x0, x2, x0
    cc1c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cc20:	8b020006 	add	x6, x0, x2
    cc24:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    cc28:	cb010000 	sub	x0, x0, x1
    cc2c:	9ac90801 	udiv	x1, x0, x9
    cc30:	9b098026 	msub	x6, x1, x9, x0
    cc34:	aa0303e0 	mov	x0, x3
    cc38:	9b017d41 	mul	x1, x10, x1
    cc3c:	b3607cc0 	bfi	x0, x6, #32, #32
    cc40:	eb00003f 	cmp	x1, x0
    cc44:	540000a9 	b.ls	cc58 <__modti3+0x348>  // b.plast
    cc48:	ab000040 	adds	x0, x2, x0
    cc4c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cc50:	8b020003 	add	x3, x0, x2
    cc54:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    cc58:	cb010000 	sub	x0, x0, x1
    cc5c:	17ffffb0 	b	cb1c <__modti3+0x20c>
    cc60:	d1000969 	sub	x9, x11, #0x2
    cc64:	8b070021 	add	x1, x1, x7
    cc68:	17ffff83 	b	ca74 <__modti3+0x164>
    cc6c:	d1000965 	sub	x5, x11, #0x2
    cc70:	8b070063 	add	x3, x3, x7
    cc74:	17ffff74 	b	ca44 <__modti3+0x134>
    cc78:	d503201f 	nop
    cc7c:	d503201f 	nop

000000000000cc80 <atexit>:
    cc80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    cc84:	900000a2 	adrp	x2, 20000 <__data_start>
    cc88:	d2800001 	mov	x1, #0x0                   	// #0
    cc8c:	910003fd 	mov	x29, sp
    cc90:	a8c17bfd 	ldp	x29, x30, [sp], #16
    cc94:	f9400442 	ldr	x2, [x2, #8]
    cc98:	17ffd6ba 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000cc9c <_fini>:
    cc9c:	d503201f 	nop
    cca0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    cca4:	910003fd 	mov	x29, sp
    cca8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    ccac:	d65f03c0 	ret
