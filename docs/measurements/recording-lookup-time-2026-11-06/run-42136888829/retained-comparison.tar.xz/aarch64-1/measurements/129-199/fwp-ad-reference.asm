
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-reference:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000045 	adrp	x5, d000 <fwp_main_thread+0x10d0>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	913640a5 	add	x5, x5, #0xd90
    2aa0:	f0000044 	adrp	x4, d000 <fwp_main_thread+0x10d0>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	91366084 	add	x4, x4, #0xd98
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	940002ac 	bl	3580 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	9100c261 	add	x1, x19, #0x30
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe430>
    2b20:	910da000 	add	x0, x0, #0x368
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9001c20 	str	x0, [x1, #56]
    2b2c:	940002f5 	bl	3700 <fwp_now_ns>
    2b30:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x470>
    2b34:	9105c000 	add	x0, x0, #0x170
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	b0000042 	adrp	x2, b000 <f0+0x1750>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	913cc042 	add	x2, x2, #0xf30
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9100c273 	add	x19, x19, #0x30
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9430a60 	ldr	w0, [x19, #776]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff48 	bl	2970 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x470>
    2c7c:	91060000 	add	x0, x0, #0x180
    2c80:	94000240 	bl	3580 <fwp_trap>
    2c84:	97fffeff 	bl	2880 <__stack_chk_fail@plt>
    2c88:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x470>
    2c8c:	91088000 	add	x0, x0, #0x220
    2c90:	9400023c 	bl	3580 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffee6 	bl	2830 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x470>
    2ca4:	9107e000 	add	x0, x0, #0x1f8
    2ca8:	94000236 	bl	3580 <fwp_trap>
    2cac:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x470>
    2cb0:	91072000 	add	x0, x0, #0x1c8
    2cb4:	94000233 	bl	3580 <fwp_trap>
    2cb8:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x470>
    2cbc:	91068000 	add	x0, x0, #0x1a0
    2cc0:	94000230 	bl	3580 <fwp_trap>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91008000 	add	x0, x0, #0x20
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91008021 	add	x1, x1, #0x20
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91008000 	add	x0, x0, #0x20
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91008021 	add	x1, x1, #0x20
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39408260 	ldrb	w0, [x19, #32]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39008260 	strb	w0, [x19, #32]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000061 	adrp	x1, e000 <_IO_stdin_used+0x470>
    2eb4:	91210021 	add	x1, x1, #0x840
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9401884 	ldr	x4, [x4, #48]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9401863 	ldr	x3, [x3, #48]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args173>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9401c00 	ldr	x0, [x0, #56]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    3050:	912e6000 	add	x0, x0, #0xb98
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9100c043 	add	x3, x2, #0x30
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9100c042 	add	x2, x2, #0x30
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x470>
    3118:	91208021 	add	x1, x1, #0x820
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    3144:	911502a1 	add	x1, x21, #0x540
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    3158:	9124c0a5 	add	x5, x5, #0x930
    315c:	911502a1 	add	x1, x21, #0x540
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911502b7 	add	x23, x21, #0x540
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffe08 	bl	2a30 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffded 	bl	29d0 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdf6 	bl	2a30 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911502b5 	add	x21, x21, #0x540
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911502b5 	add	x21, x21, #0x540
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    32e8:	9124a0a5 	add	x5, x5, #0x928
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff4d 	bl	3030 <fwp_heap_oom>

0000000000003300 <fwp_tape_buffers_dispose>:
    3300:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3304:	910003fd 	mov	x29, sp
    3308:	f9000bf3 	str	x19, [sp, #16]
    330c:	aa0003f3 	mov	x19, x0
    3310:	f9400000 	ldr	x0, [x0]
    3314:	97fffd8b 	bl	2940 <free@plt>
    3318:	f9400a60 	ldr	x0, [x19, #16]
    331c:	97fffd89 	bl	2940 <free@plt>
    3320:	f9401260 	ldr	x0, [x19, #32]
    3324:	97fffd87 	bl	2940 <free@plt>
    3328:	f9001a7f 	str	xzr, [x19, #48]
    332c:	4f000400 	movi	v0.4s, #0x0
    3330:	ad000260 	stp	q0, q0, [x19]
    3334:	3d800a60 	str	q0, [x19, #32]
    3338:	f9400bf3 	ldr	x19, [sp, #16]
    333c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3340:	d65f03c0 	ret

0000000000003344 <buf_grow>:
    3344:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3348:	910003fd 	mov	x29, sp
    334c:	a90153f3 	stp	x19, x20, [sp, #16]
    3350:	aa0003f4 	mov	x20, x0
    3354:	f9400400 	ldr	x0, [x0, #8]
    3358:	b100041f 	cmn	x0, #0x1
    335c:	54000400 	b.eq	33dc <buf_grow+0x98>  // b.none
    3360:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3364:	cb000042 	sub	x2, x2, x0
    3368:	eb01005f 	cmp	x2, x1
    336c:	54000383 	b.cc	33dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3370:	f9400a82 	ldr	x2, [x20, #16]
    3374:	91000421 	add	x1, x1, #0x1
    3378:	8b000033 	add	x19, x1, x0
    337c:	eb13005f 	cmp	x2, x19
    3380:	54000242 	b.cs	33c8 <buf_grow+0x84>  // b.hs, b.nlast
    3384:	f100005f 	cmp	x2, #0x0
    3388:	b5000262 	cbnz	x2, 33d4 <buf_grow+0x90>
    338c:	d2800802 	mov	x2, #0x40                  	// #64
    3390:	eb02027f 	cmp	x19, x2
    3394:	54000068 	b.hi	33a0 <buf_grow+0x5c>  // b.pmore
    3398:	14000005 	b	33ac <buf_grow+0x68>
    339c:	b7f800a2 	tbnz	x2, #63, 33b0 <buf_grow+0x6c>
    33a0:	d37ff842 	lsl	x2, x2, #1
    33a4:	eb02027f 	cmp	x19, x2
    33a8:	54ffffa8 	b.hi	339c <buf_grow+0x58>  // b.pmore
    33ac:	aa0203f3 	mov	x19, x2
    33b0:	f9400280 	ldr	x0, [x20]
    33b4:	aa1303e1 	mov	x1, x19
    33b8:	97fffd2e 	bl	2870 <realloc@plt>
    33bc:	b4000100 	cbz	x0, 33dc <buf_grow+0x98>
    33c0:	f9000280 	str	x0, [x20]
    33c4:	f9000a93 	str	x19, [x20, #16]
    33c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    33d0:	d65f03c0 	ret
    33d4:	54fffe6a 	b.ge	33a0 <buf_grow+0x5c>  // b.tcont
    33d8:	17fffff6 	b	33b0 <buf_grow+0x6c>
    33dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    33e0:	f947e863 	ldr	x3, [x3, #4048]
    33e4:	d2800262 	mov	x2, #0x13                  	// #19
    33e8:	d2800021 	mov	x1, #0x1                   	// #1
    33ec:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    33f0:	912e6000 	add	x0, x0, #0xb98
    33f4:	f9400063 	ldr	x3, [x3]
    33f8:	97fffd62 	bl	2980 <fwrite@plt>
    33fc:	d2800000 	mov	x0, #0x0                   	// #0
    3400:	97fffd6c 	bl	29b0 <fflush@plt>
    3404:	52800cc0 	mov	w0, #0x66                  	// #102
    3408:	97fffd7a 	bl	29f0 <_Exit@plt>
    340c:	d503201f 	nop

0000000000003410 <buf_put>:
    3410:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3414:	910003fd 	mov	x29, sp
    3418:	a90153f3 	stp	x19, x20, [sp, #16]
    341c:	aa0003f4 	mov	x20, x0
    3420:	aa0203f3 	mov	x19, x2
    3424:	f90013f5 	str	x21, [sp, #32]
    3428:	aa0103f5 	mov	x21, x1
    342c:	aa0203e1 	mov	x1, x2
    3430:	97ffffc5 	bl	3344 <buf_grow>
    3434:	a9400283 	ldp	x3, x0, [x20]
    3438:	aa1503e1 	mov	x1, x21
    343c:	aa1303e2 	mov	x2, x19
    3440:	8b000060 	add	x0, x3, x0
    3444:	97fffca3 	bl	26d0 <memcpy@plt>
    3448:	a9400680 	ldp	x0, x1, [x20]
    344c:	8b010273 	add	x19, x19, x1
    3450:	f9000693 	str	x19, [x20, #8]
    3454:	3833681f 	strb	wzr, [x0, x19]
    3458:	a94153f3 	ldp	x19, x20, [sp, #16]
    345c:	f94013f5 	ldr	x21, [sp, #32]
    3460:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3464:	d65f03c0 	ret
    3468:	d503201f 	nop
    346c:	d503201f 	nop

0000000000003470 <fwp_cancel_tree.part.0>:
    3470:	b00000e1 	adrp	x1, 20000 <__data_start>
    3474:	9100c022 	add	x2, x1, #0x30
    3478:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    347c:	52800023 	mov	w3, #0x1                   	// #1
    3480:	910003fd 	mov	x29, sp
    3484:	f9400844 	ldr	x4, [x2, #16]
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	39014403 	strb	w3, [x0, #81]
    3490:	eb04001f 	cmp	x0, x4
    3494:	54000160 	b.eq	34c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3498:	f9402804 	ldr	x4, [x0, #80]
    349c:	f2001c9f 	tst	x4, #0xff000000ff
    34a0:	54000101 	b.ne	34c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    34a4:	f9401444 	ldr	x4, [x2, #40]
    34a8:	39015003 	strb	w3, [x0, #84]
    34ac:	f900801f 	str	xzr, [x0, #256]
    34b0:	b40001e4 	cbz	x4, 34ec <fwp_cancel_tree.part.0+0x7c>
    34b4:	f9008080 	str	x0, [x4, #256]
    34b8:	9100c021 	add	x1, x1, #0x30
    34bc:	f9001420 	str	x0, [x1, #40]
    34c0:	f9401413 	ldr	x19, [x0, #40]
    34c4:	b40000f3 	cbz	x19, 34e0 <fwp_cancel_tree.part.0+0x70>
    34c8:	39414261 	ldrb	w1, [x19, #80]
    34cc:	aa1303e0 	mov	x0, x19
    34d0:	37000041 	tbnz	w1, #0, 34d8 <fwp_cancel_tree.part.0+0x68>
    34d4:	97ffffe7 	bl	3470 <fwp_cancel_tree.part.0>
    34d8:	f9401a73 	ldr	x19, [x19, #48]
    34dc:	b5ffff73 	cbnz	x19, 34c8 <fwp_cancel_tree.part.0+0x58>
    34e0:	f9400bf3 	ldr	x19, [sp, #16]
    34e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34e8:	d65f03c0 	ret
    34ec:	f9001840 	str	x0, [x2, #48]
    34f0:	17fffff2 	b	34b8 <fwp_cancel_tree.part.0+0x48>

00000000000034f4 <fwp_finish_float>:
    34f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34f8:	528005c1 	mov	w1, #0x2e                  	// #46
    34fc:	910003fd 	mov	x29, sp
    3500:	f9000bf3 	str	x19, [sp, #16]
    3504:	aa0003f3 	mov	x19, x0
    3508:	97fffd16 	bl	2960 <strchr@plt>
    350c:	b4000080 	cbz	x0, 351c <fwp_finish_float+0x28>
    3510:	f9400bf3 	ldr	x19, [sp, #16]
    3514:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3518:	d65f03c0 	ret
    351c:	aa1303e0 	mov	x0, x19
    3520:	52800ca1 	mov	w1, #0x65                  	// #101
    3524:	97fffd0f 	bl	2960 <strchr@plt>
    3528:	b5ffff40 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    352c:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x10d0>
    3530:	aa1303e0 	mov	x0, x19
    3534:	912ec021 	add	x1, x1, #0xbb0
    3538:	97fffd2a 	bl	29e0 <strstr@plt>
    353c:	b5fffea0 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3540:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x10d0>
    3544:	aa1303e0 	mov	x0, x19
    3548:	912ee021 	add	x1, x1, #0xbb8
    354c:	97fffd25 	bl	29e0 <strstr@plt>
    3550:	b5fffe00 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3554:	aa1303e0 	mov	x0, x19
    3558:	97fffc6e 	bl	2710 <strlen@plt>
    355c:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x10d0>
    3560:	912f0021 	add	x1, x1, #0xbc0
    3564:	8b000262 	add	x2, x19, x0
    3568:	79400023 	ldrh	w3, [x1]
    356c:	39400821 	ldrb	w1, [x1, #2]
    3570:	78206a63 	strh	w3, [x19, x0]
    3574:	39000841 	strb	w1, [x2, #2]
    3578:	17ffffe6 	b	3510 <fwp_finish_float+0x1c>
    357c:	d503201f 	nop

0000000000003580 <fwp_trap>:
    3580:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3584:	d53bd041 	mrs	x1, tpidr_el0
    3588:	91400021 	add	x1, x1, #0x0, lsl #12
    358c:	91004021 	add	x1, x1, #0x10
    3590:	910003fd 	mov	x29, sp
    3594:	a90153f3 	stp	x19, x20, [sp, #16]
    3598:	aa0003f3 	mov	x19, x0
    359c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    35a0:	f947ea94 	ldr	x20, [x20, #4048]
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	f9400035 	ldr	x21, [x1]
    35ac:	97fffe91 	bl	2ff0 <fwp_flush>
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x10d0>
    35b8:	aa1303e3 	mov	x3, x19
    35bc:	912f2042 	add	x2, x2, #0xbc8
    35c0:	52800041 	mov	w1, #0x2                   	// #2
    35c4:	97fffccb 	bl	28f0 <__fprintf_chk@plt>
    35c8:	b40000b5 	cbz	x21, 35dc <fwp_trap+0x5c>
    35cc:	f9400280 	ldr	x0, [x20]
    35d0:	97fffcf8 	bl	29b0 <fflush@plt>
    35d4:	52800ca0 	mov	w0, #0x65                  	// #101
    35d8:	97fffd06 	bl	29f0 <_Exit@plt>
    35dc:	52800ca0 	mov	w0, #0x65                  	// #101
    35e0:	97fffc54 	bl	2730 <exit@plt>

00000000000035e4 <fwp_closure_drop_push>:
    35e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    35e8:	910003fd 	mov	x29, sp
    35ec:	a90153f3 	stp	x19, x20, [sp, #16]
    35f0:	aa0003f3 	mov	x19, x0
    35f4:	a9408014 	ldp	x20, x0, [x0, #8]
    35f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    35fc:	aa0103f5 	mov	x21, x1
    3600:	a90363f7 	stp	x23, x24, [sp, #48]
    3604:	eb00029f 	cmp	x20, x0
    3608:	54000160 	b.eq	3634 <fwp_closure_drop_push+0x50>  // b.none
    360c:	f9400276 	ldr	x22, [x19]
    3610:	d37df297 	lsl	x23, x20, #3
    3614:	91000694 	add	x20, x20, #0x1
    3618:	f9000674 	str	x20, [x19, #8]
    361c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3620:	f8376ad5 	str	x21, [x22, x23]
    3624:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3628:	a94363f7 	ldp	x23, x24, [sp, #48]
    362c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3630:	d65f03c0 	ret
    3634:	a9046bf9 	stp	x25, x26, [sp, #64]
    3638:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    363c:	eb00029f 	cmp	x20, x0
    3640:	54000568 	b.hi	36ec <fwp_closure_drop_push+0x108>  // b.pmore
    3644:	d37cee99 	lsl	x25, x20, #4
    3648:	d37ffa9a 	lsl	x26, x20, #1
    364c:	aa1903e0 	mov	x0, x25
    3650:	97fffc74 	bl	2820 <malloc@plt>
    3654:	aa0003f6 	mov	x22, x0
    3658:	b4000320 	cbz	x0, 36bc <fwp_closure_drop_push+0xd8>
    365c:	aa1303f8 	mov	x24, x19
    3660:	aa1903e3 	mov	x3, x25
    3664:	d37df297 	lsl	x23, x20, #3
    3668:	aa1703e2 	mov	x2, x23
    366c:	f8418719 	ldr	x25, [x24], #24
    3670:	aa1903e1 	mov	x1, x25
    3674:	97fffc57 	bl	27d0 <__memcpy_chk@plt>
    3678:	eb18033f 	cmp	x25, x24
    367c:	540000a0 	b.eq	3690 <fwp_closure_drop_push+0xac>  // b.none
    3680:	aa1903e0 	mov	x0, x25
    3684:	97fffcaf 	bl	2940 <free@plt>
    3688:	f9400674 	ldr	x20, [x19, #8]
    368c:	d37df297 	lsl	x23, x20, #3
    3690:	91000694 	add	x20, x20, #0x1
    3694:	f9000276 	str	x22, [x19]
    3698:	f9000a7a 	str	x26, [x19, #16]
    369c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    36a0:	f9000674 	str	x20, [x19, #8]
    36a4:	f8376ad5 	str	x21, [x22, x23]
    36a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    36b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    36b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    36b8:	d65f03c0 	ret
    36bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    36c0:	f947e863 	ldr	x3, [x3, #4048]
    36c4:	d2800262 	mov	x2, #0x13                  	// #19
    36c8:	d2800021 	mov	x1, #0x1                   	// #1
    36cc:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    36d0:	912e6000 	add	x0, x0, #0xb98
    36d4:	f9400063 	ldr	x3, [x3]
    36d8:	97fffcaa 	bl	2980 <fwrite@plt>
    36dc:	d2800000 	mov	x0, #0x0                   	// #0
    36e0:	97fffcb4 	bl	29b0 <fflush@plt>
    36e4:	52800cc0 	mov	w0, #0x66                  	// #102
    36e8:	97fffcc2 	bl	29f0 <_Exit@plt>
    36ec:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    36f0:	912f6000 	add	x0, x0, #0xbd8
    36f4:	97ffffa3 	bl	3580 <fwp_trap>
    36f8:	d503201f 	nop
    36fc:	d503201f 	nop

0000000000003700 <fwp_now_ns>:
    3700:	d100c3ff 	sub	sp, sp, #0x30
    3704:	52800020 	mov	w0, #0x1                   	// #1
    3708:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    370c:	f947f442 	ldr	x2, [x2, #4072]
    3710:	910023e1 	add	x1, sp, #0x8
    3714:	a9027bfd 	stp	x29, x30, [sp, #32]
    3718:	910083fd 	add	x29, sp, #0x20
    371c:	f9400043 	ldr	x3, [x2]
    3720:	f9000fe3 	str	x3, [sp, #24]
    3724:	d2800003 	mov	x3, #0x0                   	// #0
    3728:	97fffc22 	bl	27b0 <clock_gettime@plt>
    372c:	350002c0 	cbnz	w0, 3784 <fwp_now_ns+0x84>
    3730:	a9408be1 	ldp	x1, x2, [sp, #8]
    3734:	d2994003 	mov	x3, #0xca00                	// #51712
    3738:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    373c:	9b037c20 	mul	x0, x1, x3
    3740:	9b437c21 	smulh	x1, x1, x3
    3744:	ab020000 	adds	x0, x0, x2
    3748:	937ffc42 	asr	x2, x2, #63
    374c:	9a020021 	adc	x1, x1, x2
    3750:	f100001f 	cmp	x0, #0x0
    3754:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3758:	b50001e1 	cbnz	x1, 3794 <fwp_now_ns+0x94>
    375c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3760:	f947f421 	ldr	x1, [x1, #4072]
    3764:	f9400fe3 	ldr	x3, [sp, #24]
    3768:	f9400022 	ldr	x2, [x1]
    376c:	eb020063 	subs	x3, x3, x2
    3770:	d2800002 	mov	x2, #0x0                   	// #0
    3774:	540000e1 	b.ne	3790 <fwp_now_ns+0x90>  // b.any
    3778:	a9427bfd 	ldp	x29, x30, [sp, #32]
    377c:	9100c3ff 	add	sp, sp, #0x30
    3780:	d65f03c0 	ret
    3784:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    3788:	912fe000 	add	x0, x0, #0xbf8
    378c:	97ffff7d 	bl	3580 <fwp_trap>
    3790:	97fffc3c 	bl	2880 <__stack_chk_fail@plt>
    3794:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    3798:	91306000 	add	x0, x0, #0xc18
    379c:	97ffff79 	bl	3580 <fwp_trap>

00000000000037a0 <fwp_closure_drop.part.0>:
    37a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    37a4:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x470>
    37a8:	910003fd 	mov	x29, sp
    37ac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    37b0:	f947f463 	ldr	x3, [x3, #4072]
    37b4:	a90153f3 	stp	x19, x20, [sp, #16]
    37b8:	d10883ff 	sub	sp, sp, #0x220
    37bc:	910003e2 	mov	x2, sp
    37c0:	d53bd053 	mrs	x19, tpidr_el0
    37c4:	910063f4 	add	x20, sp, #0x18
    37c8:	3dc21420 	ldr	q0, [x1, #2128]
    37cc:	91400264 	add	x4, x19, #0x0, lsl #12
    37d0:	91004084 	add	x4, x4, #0x10
    37d4:	aa0003e1 	mov	x1, x0
    37d8:	aa0203e0 	mov	x0, x2
    37dc:	f9400062 	ldr	x2, [x3]
    37e0:	f9010fe2 	str	x2, [sp, #536]
    37e4:	d2800002 	mov	x2, #0x0                   	// #0
    37e8:	f90003f4 	str	x20, [sp]
    37ec:	f9000080 	str	x0, [x4]
    37f0:	3c8083e0 	stur	q0, [sp, #8]
    37f4:	97ffff7c 	bl	35e4 <fwp_closure_drop_push>
    37f8:	f94007e0 	ldr	x0, [sp, #8]
    37fc:	b4000280 	cbz	x0, 384c <fwp_closure_drop.part.0+0xac>
    3800:	f90123f5 	str	x21, [sp, #576]
    3804:	b00000f5 	adrp	x21, 20000 <__data_start>
    3808:	9100c2b5 	add	x21, x21, #0x30
    380c:	d503201f 	nop
    3810:	f94003e1 	ldr	x1, [sp]
    3814:	d1000400 	sub	x0, x0, #0x1
    3818:	f90007e0 	str	x0, [sp, #8]
    381c:	f9401ea2 	ldr	x2, [x21, #56]
    3820:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3824:	b9400001 	ldr	w1, [x0]
    3828:	8b011441 	add	x1, x2, x1, lsl #5
    382c:	f9400c21 	ldr	x1, [x1, #24]
    3830:	b4000321 	cbz	x1, 3894 <fwp_closure_drop.part.0+0xf4>
    3834:	f9400422 	ldr	x2, [x1, #8]
    3838:	52800001 	mov	w1, #0x0                   	// #0
    383c:	d63f0040 	blr	x2
    3840:	f94007e0 	ldr	x0, [sp, #8]
    3844:	b5fffe60 	cbnz	x0, 3810 <fwp_closure_drop.part.0+0x70>
    3848:	f94123f5 	ldr	x21, [sp, #576]
    384c:	91400273 	add	x19, x19, #0x0, lsl #12
    3850:	91004273 	add	x19, x19, #0x10
    3854:	f94003e0 	ldr	x0, [sp]
    3858:	f900027f 	str	xzr, [x19]
    385c:	eb14001f 	cmp	x0, x20
    3860:	54000040 	b.eq	3868 <fwp_closure_drop.part.0+0xc8>  // b.none
    3864:	97fffc37 	bl	2940 <free@plt>
    3868:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    386c:	f947f400 	ldr	x0, [x0, #4072]
    3870:	f9410fe2 	ldr	x2, [sp, #536]
    3874:	f9400001 	ldr	x1, [x0]
    3878:	eb010042 	subs	x2, x2, x1
    387c:	d2800001 	mov	x1, #0x0                   	// #0
    3880:	54000101 	b.ne	38a0 <fwp_closure_drop.part.0+0x100>  // b.any
    3884:	910883ff 	add	sp, sp, #0x220
    3888:	a94153f3 	ldp	x19, x20, [sp, #16]
    388c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3890:	d65f03c0 	ret
    3894:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    3898:	91310000 	add	x0, x0, #0xc40
    389c:	97ffff39 	bl	3580 <fwp_trap>
    38a0:	f90123f5 	str	x21, [sp, #576]
    38a4:	97fffbf7 	bl	2880 <__stack_chk_fail@plt>
    38a8:	d503201f 	nop
    38ac:	d503201f 	nop

00000000000038b0 <fwp_tape_of>:
    38b0:	92403c02 	and	x2, x0, #0xffff
    38b4:	b4000262 	cbz	x2, 3900 <fwp_tape_of+0x50>
    38b8:	9350fc01 	asr	x1, x0, #16
    38bc:	b00000e3 	adrp	x3, 20000 <__data_start>
    38c0:	d1000440 	sub	x0, x2, #0x1
    38c4:	9100c062 	add	x2, x3, #0x30
    38c8:	f9402042 	ldr	x2, [x2, #64]
    38cc:	eb00005f 	cmp	x2, x0
    38d0:	5400018d 	b.le	3900 <fwp_tape_of+0x50>
    38d4:	8b000402 	add	x2, x0, x0, lsl #1
    38d8:	f9401863 	ldr	x3, [x3, #48]
    38dc:	8b020802 	add	x2, x0, x2, lsl #2
    38e0:	d37df042 	lsl	x2, x2, #3
    38e4:	8b020060 	add	x0, x3, x2
    38e8:	b9400404 	ldr	w4, [x0, #4]
    38ec:	340000a4 	cbz	w4, 3900 <fwp_tape_of+0x50>
    38f0:	b8626862 	ldr	w2, [x3, x2]
    38f4:	6b01005f 	cmp	w2, w1
    38f8:	54000041 	b.ne	3900 <fwp_tape_of+0x50>  // b.any
    38fc:	d65f03c0 	ret
    3900:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3904:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    3908:	9131c000 	add	x0, x0, #0xc70
    390c:	910003fd 	mov	x29, sp
    3910:	97ffff1c 	bl	3580 <fwp_trap>

0000000000003914 <fwp_format_g.constprop.0>:
    3914:	d10483ff 	sub	sp, sp, #0x120
    3918:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x10d0>
    391c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    3920:	f947f442 	ldr	x2, [x2, #4072]
    3924:	91330084 	add	x4, x4, #0xcc0
    3928:	a90b7bfd 	stp	x29, x30, [sp, #176]
    392c:	9102c3fd 	add	x29, sp, #0xb0
    3930:	d2800803 	mov	x3, #0x40                  	// #64
    3934:	a90e63f7 	stp	x23, x24, [sp, #224]
    3938:	93407c38 	sxtw	x24, w1
    393c:	aa0303e1 	mov	x1, x3
    3940:	fd008be8 	str	d8, [sp, #272]
    3944:	1e604008 	fmov	d8, d0
    3948:	a90c53f3 	stp	x19, x20, [sp, #192]
    394c:	910083f4 	add	x20, sp, #0x20
    3950:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3954:	aa0003f5 	mov	x21, x0
    3958:	a91073fb 	stp	x27, x28, [sp, #256]
    395c:	5100071c 	sub	w28, w24, #0x1
    3960:	2a1c03e5 	mov	w5, w28
    3964:	f9400040 	ldr	x0, [x2]
    3968:	f90057e0 	str	x0, [sp, #168]
    396c:	d2800000 	mov	x0, #0x0                   	// #0
    3970:	52800042 	mov	w2, #0x2                   	// #2
    3974:	aa1403e0 	mov	x0, x20
    3978:	97fffb9e 	bl	27f0 <__snprintf_chk@plt>
    397c:	52800ca1 	mov	w1, #0x65                  	// #101
    3980:	aa1403e0 	mov	x0, x20
    3984:	97fffbf7 	bl	2960 <strchr@plt>
    3988:	aa0003f3 	mov	x19, x0
    398c:	52800142 	mov	w2, #0xa                   	// #10
    3990:	91000400 	add	x0, x0, #0x1
    3994:	d2800001 	mov	x1, #0x0                   	// #0
    3998:	97fffbe2 	bl	2920 <strtol@plt>
    399c:	aa0003f7 	mov	x23, x0
    39a0:	11001400 	add	w0, w0, #0x5
    39a4:	7100541f 	cmp	w0, #0x15
    39a8:	54000d88 	b.hi	3b58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    39ac:	4b170385 	sub	w5, w28, w23
    39b0:	710000bf 	cmp	w5, #0x0
    39b4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    39b8:	54000ba0 	b.eq	3b2c <fwp_format_g.constprop.0+0x218>  // b.none
    39bc:	394083e0 	ldrb	w0, [sp, #32]
    39c0:	cb180273 	sub	x19, x19, x24
    39c4:	91000673 	add	x19, x19, #0x1
    39c8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    39cc:	7100b41f 	cmp	w0, #0x2d
    39d0:	9a941681 	cinc	x1, x20, eq	// eq = none
    39d4:	1a9f17e4 	cset	w4, eq	// eq = none
    39d8:	cb010266 	sub	x6, x19, x1
    39dc:	d10004da 	sub	x26, x6, #0x1
    39e0:	540018c0 	b.eq	3cf8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    39e4:	910183f9 	add	x25, sp, #0x60
    39e8:	d280091b 	mov	x27, #0x48                  	// #72
    39ec:	aa1903e7 	mov	x7, x25
    39f0:	91000423 	add	x3, x1, #0x1
    39f4:	91011cc6 	add	x6, x6, #0x47
    39f8:	910004f6 	add	x22, x7, #0x1
    39fc:	37f81017 	tbnz	w23, #31, 3bfc <fwp_format_g.constprop.0+0x2e8>
    3a00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3a04:	93407ef7 	sxtw	x23, w23
    3a08:	390000e4 	strb	w4, [x7]
    3a0c:	aa1303e1 	mov	x1, x19
    3a10:	aa1703e2 	mov	x2, x23
    3a14:	aa1603e0 	mov	x0, x22
    3a18:	b9000be5 	str	w5, [sp, #8]
    3a1c:	cb170374 	sub	x20, x27, x23
    3a20:	a9011be3 	stp	x3, x6, [sp, #16]
    3a24:	97fffb2b 	bl	26d0 <memcpy@plt>
    3a28:	d1000694 	sub	x20, x20, #0x1
    3a2c:	f9400be3 	ldr	x3, [sp, #16]
    3a30:	8b1702d6 	add	x22, x22, x23
    3a34:	aa1603e0 	mov	x0, x22
    3a38:	aa1a03e2 	mov	x2, x26
    3a3c:	aa0303e1 	mov	x1, x3
    3a40:	aa1403e3 	mov	x3, x20
    3a44:	97fffb63 	bl	27d0 <__memcpy_chk@plt>
    3a48:	8b1a02d6 	add	x22, x22, x26
    3a4c:	f9400fe6 	ldr	x6, [sp, #24]
    3a50:	d2800900 	mov	x0, #0x48                  	// #72
    3a54:	b9400be5 	ldr	w5, [sp, #8]
    3a58:	8b170261 	add	x1, x19, x23
    3a5c:	cb1400c3 	sub	x3, x6, x20
    3a60:	cb060294 	sub	x20, x20, x6
    3a64:	f101207f 	cmp	x3, #0x48
    3a68:	93407cb8 	sxtw	x24, w5
    3a6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3a70:	aa1803e2 	mov	x2, x24
    3a74:	8b1802d3 	add	x19, x22, x24
    3a78:	8b140063 	add	x3, x3, x20
    3a7c:	aa1603e0 	mov	x0, x22
    3a80:	97fffb54 	bl	27d0 <__memcpy_chk@plt>
    3a84:	cb190273 	sub	x19, x19, x25
    3a88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3a8c:	eb00027f 	cmp	x19, x0
    3a90:	aa1903e1 	mov	x1, x25
    3a94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a98:	aa1503e0 	mov	x0, x21
    3a9c:	aa1303e2 	mov	x2, x19
    3aa0:	97fffb0c 	bl	26d0 <memcpy@plt>
    3aa4:	38336abf 	strb	wzr, [x21, x19]
    3aa8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3aac:	aa1503e0 	mov	x0, x21
    3ab0:	97fffb18 	bl	2710 <strlen@plt>
    3ab4:	aa0003f3 	mov	x19, x0
    3ab8:	528005c1 	mov	w1, #0x2e                  	// #46
    3abc:	aa1503e0 	mov	x0, x21
    3ac0:	97fffba8 	bl	2960 <strchr@plt>
    3ac4:	b4000160 	cbz	x0, 3af0 <fwp_format_g.constprop.0+0x1dc>
    3ac8:	b4000153 	cbz	x19, 3af0 <fwp_format_g.constprop.0+0x1dc>
    3acc:	d503201f 	nop
    3ad0:	aa1303e1 	mov	x1, x19
    3ad4:	d1000673 	sub	x19, x19, #0x1
    3ad8:	38736aa0 	ldrb	w0, [x21, x19]
    3adc:	7100c01f 	cmp	w0, #0x30
    3ae0:	54001001 	b.ne	3ce0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3ae4:	38336abf 	strb	wzr, [x21, x19]
    3ae8:	b5ffff53 	cbnz	x19, 3ad0 <fwp_format_g.constprop.0+0x1bc>
    3aec:	d503201f 	nop
    3af0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3af4:	f947f400 	ldr	x0, [x0, #4072]
    3af8:	f94057e2 	ldr	x2, [sp, #168]
    3afc:	f9400001 	ldr	x1, [x0]
    3b00:	eb010042 	subs	x2, x2, x1
    3b04:	d2800001 	mov	x1, #0x0                   	// #0
    3b08:	54001061 	b.ne	3d14 <fwp_format_g.constprop.0+0x400>  // b.any
    3b0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3b10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3b14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3b18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3b1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3b20:	fd408be8 	ldr	d8, [sp, #272]
    3b24:	910483ff 	add	sp, sp, #0x120
    3b28:	d65f03c0 	ret
    3b2c:	1e604100 	fmov	d0, d8
    3b30:	710000bf 	cmp	w5, #0x0
    3b34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3b38:	aa1503e0 	mov	x0, x21
    3b3c:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x10d0>
    3b40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b44:	91336084 	add	x4, x4, #0xcd8
    3b48:	52800042 	mov	w2, #0x2                   	// #2
    3b4c:	d2803201 	mov	x1, #0x190                 	// #400
    3b50:	97fffb28 	bl	27f0 <__snprintf_chk@plt>
    3b54:	17ffffd6 	b	3aac <fwp_format_g.constprop.0+0x198>
    3b58:	cb140273 	sub	x19, x19, x20
    3b5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3b60:	910183f9 	add	x25, sp, #0x60
    3b64:	aa1303e2 	mov	x2, x19
    3b68:	aa1403e1 	mov	x1, x20
    3b6c:	aa1903e0 	mov	x0, x25
    3b70:	d2800803 	mov	x3, #0x40                  	// #64
    3b74:	97fffb17 	bl	27d0 <__memcpy_chk@plt>
    3b78:	38336b3f 	strb	wzr, [x25, x19]
    3b7c:	aa1903e0 	mov	x0, x25
    3b80:	528005c1 	mov	w1, #0x2e                  	// #46
    3b84:	97fffb77 	bl	2960 <strchr@plt>
    3b88:	b40001c0 	cbz	x0, 3bc0 <fwp_format_g.constprop.0+0x2ac>
    3b8c:	b50000b3 	cbnz	x19, 3ba0 <fwp_format_g.constprop.0+0x28c>
    3b90:	1400000c 	b	3bc0 <fwp_format_g.constprop.0+0x2ac>
    3b94:	381ff01f 	sturb	wzr, [x0, #-1]
    3b98:	f1000673 	subs	x19, x19, #0x1
    3b9c:	54000120 	b.eq	3bc0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3ba0:	8b130320 	add	x0, x25, x19
    3ba4:	385ff001 	ldurb	w1, [x0, #-1]
    3ba8:	7100c03f 	cmp	w1, #0x30
    3bac:	54ffff40 	b.eq	3b94 <fwp_format_g.constprop.0+0x280>  // b.none
    3bb0:	d1000673 	sub	x19, x19, #0x1
    3bb4:	38736b20 	ldrb	w0, [x25, x19]
    3bb8:	7100b81f 	cmp	w0, #0x2e
    3bbc:	54000a80 	b.eq	3d0c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3bc0:	710002ff 	cmp	w23, #0x0
    3bc4:	528005a1 	mov	w1, #0x2d                  	// #45
    3bc8:	aa1903e5 	mov	x5, x25
    3bcc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3bd0:	aa1503e0 	mov	x0, x21
    3bd4:	52800566 	mov	w6, #0x2b                  	// #43
    3bd8:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x10d0>
    3bdc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3be0:	91332084 	add	x4, x4, #0xcc8
    3be4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3be8:	52800042 	mov	w2, #0x2                   	// #2
    3bec:	d2803201 	mov	x1, #0x190                 	// #400
    3bf0:	97fffb00 	bl	27f0 <__snprintf_chk@plt>
    3bf4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3bf8:	17ffffbe 	b	3af0 <fwp_format_g.constprop.0+0x1dc>
    3bfc:	52800605 	mov	w5, #0x30                  	// #48
    3c00:	390000e5 	strb	w5, [x7]
    3c04:	d100077b 	sub	x27, x27, #0x1
    3c08:	aa0303e1 	mov	x1, x3
    3c0c:	aa1603e0 	mov	x0, x22
    3c10:	aa1b03e3 	mov	x3, x27
    3c14:	aa1a03e2 	mov	x2, x26
    3c18:	f90007e6 	str	x6, [sp, #8]
    3c1c:	b90013e4 	str	w4, [sp, #16]
    3c20:	8b1a02d6 	add	x22, x22, x26
    3c24:	b9001be5 	str	w5, [sp, #24]
    3c28:	97fffaea 	bl	27d0 <__memcpy_chk@plt>
    3c2c:	f94007e6 	ldr	x6, [sp, #8]
    3c30:	2a3703e7 	mvn	w7, w23
    3c34:	b94013e4 	ldr	w4, [sp, #16]
    3c38:	cb1b00c1 	sub	x1, x6, x27
    3c3c:	cb06037b 	sub	x27, x27, x6
    3c40:	f101203f 	cmp	x1, #0x48
    3c44:	d2800906 	mov	x6, #0x48                  	// #72
    3c48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3c4c:	8b1b0023 	add	x3, x1, x27
    3c50:	310006ff 	cmn	w23, #0x1
    3c54:	54000220 	b.eq	3c98 <fwp_format_g.constprop.0+0x384>  // b.none
    3c58:	b9401be5 	ldr	w5, [sp, #24]
    3c5c:	d2800001 	mov	x1, #0x0                   	// #0
    3c60:	f101207f 	cmp	x3, #0x48
    3c64:	d1000462 	sub	x2, x3, #0x1
    3c68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3c6c:	38216ac5 	strb	w5, [x22, x1]
    3c70:	cb030003 	sub	x3, x0, x3
    3c74:	91000421 	add	x1, x1, #0x1
    3c78:	91000463 	add	x3, x3, #0x1
    3c7c:	eb00007f 	cmp	x3, x0
    3c80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c84:	cb000063 	sub	x3, x3, x0
    3c88:	8b020063 	add	x3, x3, x2
    3c8c:	6b0100ff 	cmp	w7, w1
    3c90:	54fffe8c 	b.gt	3c60 <fwp_format_g.constprop.0+0x34c>
    3c94:	8b2742d6 	add	x22, x22, w7, uxtw
    3c98:	f101207f 	cmp	x3, #0x48
    3c9c:	d2800905 	mov	x5, #0x48                  	// #72
    3ca0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3ca4:	aa1603e0 	mov	x0, x22
    3ca8:	cb0300a1 	sub	x1, x5, x3
    3cac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3cb0:	91000421 	add	x1, x1, #0x1
    3cb4:	d1000463 	sub	x3, x3, #0x1
    3cb8:	eb05003f 	cmp	x1, x5
    3cbc:	38001402 	strb	w2, [x0], #1
    3cc0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3cc4:	93407f82 	sxtw	x2, w28
    3cc8:	cb050025 	sub	x5, x1, x5
    3ccc:	aa1303e1 	mov	x1, x19
    3cd0:	8b0300a3 	add	x3, x5, x3
    3cd4:	8b1802d3 	add	x19, x22, x24
    3cd8:	97fffabe 	bl	27d0 <__memcpy_chk@plt>
    3cdc:	17ffff6a 	b	3a84 <fwp_format_g.constprop.0+0x170>
    3ce0:	d1000421 	sub	x1, x1, #0x1
    3ce4:	38616aa0 	ldrb	w0, [x21, x1]
    3ce8:	7100b81f 	cmp	w0, #0x2e
    3cec:	54fff021 	b.ne	3af0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3cf0:	38216abf 	strb	wzr, [x21, x1]
    3cf4:	17ffff7f 	b	3af0 <fwp_format_g.constprop.0+0x1dc>
    3cf8:	910187e7 	add	x7, sp, #0x61
    3cfc:	910183f9 	add	x25, sp, #0x60
    3d00:	d28008fb 	mov	x27, #0x47                  	// #71
    3d04:	390183e0 	strb	w0, [sp, #96]
    3d08:	17ffff3a 	b	39f0 <fwp_format_g.constprop.0+0xdc>
    3d0c:	38336b3f 	strb	wzr, [x25, x19]
    3d10:	17ffffac 	b	3bc0 <fwp_format_g.constprop.0+0x2ac>
    3d14:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3d18:	97fffada 	bl	2880 <__stack_chk_fail@plt>
    3d1c:	d503201f 	nop

0000000000003d20 <fwp_heap_report>:
    3d20:	d105c3ff 	sub	sp, sp, #0x170
    3d24:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    3d28:	91150042 	add	x2, x2, #0x540
    3d2c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3d30:	f947e821 	ldr	x1, [x1, #4048]
    3d34:	a9117bfd 	stp	x29, x30, [sp, #272]
    3d38:	910443fd 	add	x29, sp, #0x110
    3d3c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3d40:	f947f400 	ldr	x0, [x0, #4072]
    3d44:	a9135bf5 	stp	x21, x22, [sp, #304]
    3d48:	a91463f7 	stp	x23, x24, [sp, #320]
    3d4c:	a9156bf9 	stp	x25, x26, [sp, #336]
    3d50:	6d1627e8 	stp	d8, d9, [sp, #352]
    3d54:	fd4a1c48 	ldr	d8, [x2, #5176]
    3d58:	fd4a2049 	ldr	d9, [x2, #5184]
    3d5c:	f9400036 	ldr	x22, [x1]
    3d60:	f9400001 	ldr	x1, [x0]
    3d64:	f90087e1 	str	x1, [sp, #264]
    3d68:	d2800001 	mov	x1, #0x0                   	// #0
    3d6c:	f949e459 	ldr	x25, [x2, #5064]
    3d70:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x10d0>
    3d74:	f94a1057 	ldr	x23, [x2, #5152]
    3d78:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    3d7c:	f94a1458 	ldr	x24, [x2, #5160]
    3d80:	91338021 	add	x1, x1, #0xce0
    3d84:	9133a000 	add	x0, x0, #0xce8
    3d88:	97fffaa2 	bl	2810 <fopen@plt>
    3d8c:	b4000740 	cbz	x0, 3e74 <fwp_heap_report+0x154>
    3d90:	528daad5 	mov	w21, #0x6d56                	// #27990
    3d94:	a91253f3 	stp	x19, x20, [sp, #288]
    3d98:	aa0003f4 	mov	x20, x0
    3d9c:	910023f3 	add	x19, sp, #0x8
    3da0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3da4:	72aae915 	movk	w21, #0x5748, lsl #16
    3da8:	aa1403e2 	mov	x2, x20
    3dac:	aa1303e0 	mov	x0, x19
    3db0:	52802001 	mov	w1, #0x100                 	// #256
    3db4:	97fffb23 	bl	2a40 <fgets@plt>
    3db8:	b4000280 	cbz	x0, 3e08 <fwp_heap_report+0xe8>
    3dbc:	b9400261 	ldr	w1, [x19]
    3dc0:	6b15003f 	cmp	w1, w21
    3dc4:	54ffff21 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3dc8:	39401260 	ldrb	w0, [x19, #4]
    3dcc:	7101341f 	cmp	w0, #0x4d
    3dd0:	54fffec1 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3dd4:	394037e0 	ldrb	w0, [sp, #13]
    3dd8:	7100e81f 	cmp	w0, #0x3a
    3ddc:	54fffe61 	b.ne	3da8 <fwp_heap_report+0x88>  // b.any
    3de0:	52800142 	mov	w2, #0xa                   	// #10
    3de4:	d2800001 	mov	x1, #0x0                   	// #0
    3de8:	91003be0 	add	x0, sp, #0xe
    3dec:	97fffacd 	bl	2920 <strtol@plt>
    3df0:	aa1403e2 	mov	x2, x20
    3df4:	aa0003fa 	mov	x26, x0
    3df8:	52802001 	mov	w1, #0x100                 	// #256
    3dfc:	aa1303e0 	mov	x0, x19
    3e00:	97fffb10 	bl	2a40 <fgets@plt>
    3e04:	b5fffdc0 	cbnz	x0, 3dbc <fwp_heap_report+0x9c>
    3e08:	aa1403e0 	mov	x0, x20
    3e0c:	97fffa7d 	bl	2800 <fclose@plt>
    3e10:	a95253f3 	ldp	x19, x20, [sp, #288]
    3e14:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3e18:	f947f400 	ldr	x0, [x0, #4072]
    3e1c:	f94087e2 	ldr	x2, [sp, #264]
    3e20:	f9400001 	ldr	x1, [x0]
    3e24:	eb010042 	subs	x2, x2, x1
    3e28:	d2800001 	mov	x1, #0x0                   	// #0
    3e2c:	54000281 	b.ne	3e7c <fwp_heap_report+0x15c>  // b.any
    3e30:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3e34:	aa1a03e6 	mov	x6, x26
    3e38:	aa1903e5 	mov	x5, x25
    3e3c:	aa1803e4 	mov	x4, x24
    3e40:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3e44:	aa1703e3 	mov	x3, x23
    3e48:	a95463f7 	ldp	x23, x24, [sp, #320]
    3e4c:	aa1603e0 	mov	x0, x22
    3e50:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3e54:	1e604121 	fmov	d1, d9
    3e58:	1e604100 	fmov	d0, d8
    3e5c:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x10d0>
    3e60:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3e64:	91342042 	add	x2, x2, #0xd08
    3e68:	9105c3ff 	add	sp, sp, #0x170
    3e6c:	52800041 	mov	w1, #0x2                   	// #2
    3e70:	17fffaa0 	b	28f0 <__fprintf_chk@plt>
    3e74:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3e78:	17ffffe7 	b	3e14 <fwp_heap_report+0xf4>
    3e7c:	a91253f3 	stp	x19, x20, [sp, #288]
    3e80:	97fffa80 	bl	2880 <__stack_chk_fail@plt>

0000000000003e84 <fwp_heap_init>:
    3e84:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3e88:	f0000163 	adrp	x3, 32000 <fwp_heap+0xac0>
    3e8c:	91110061 	add	x1, x3, #0x440
    3e90:	910003fd 	mov	x29, sp
    3e94:	a90153f3 	stp	x19, x20, [sp, #16]
    3e98:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    3e9c:	91150262 	add	x2, x19, #0x540
    3ea0:	a9025bf5 	stp	x21, x22, [sp, #32]
    3ea4:	52800024 	mov	w4, #0x1                   	// #1
    3ea8:	52800200 	mov	w0, #0x10                  	// #16
    3eac:	b913a444 	str	w4, [x2, #5028]
    3eb0:	b8004420 	str	w0, [x1], #4
    3eb4:	11004000 	add	w0, w0, #0x10
    3eb8:	7104401f 	cmp	w0, #0x110
    3ebc:	54ffffa1 	b.ne	3eb0 <fwp_heap_init+0x2c>  // b.any
    3ec0:	f0000042 	adrp	x2, e000 <_IO_stdin_used+0x470>
    3ec4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3ec8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xac0>
    3ecc:	91120021 	add	x1, x1, #0x480
    3ed0:	3dc21843 	ldr	q3, [x2, #2144]
    3ed4:	d2800000 	mov	x0, #0x0                   	// #0
    3ed8:	4e040401 	dup	v1.4s, v0.s[0]
    3edc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3ee0:	0f215400 	shl	v0.2s, v0.2s, #1
    3ee4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3ee8:	3ca06821 	str	q1, [x1, x0]
    3eec:	91004000 	add	x0, x0, #0x10
    3ef0:	f101801f 	cmp	x0, #0x60
    3ef4:	54ffff21 	b.ne	3ed8 <fwp_heap_init+0x54>  // b.any
    3ef8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xac0>
    3efc:	91110063 	add	x3, x3, #0x440
    3f00:	91138084 	add	x4, x4, #0x4e0
    3f04:	91150266 	add	x6, x19, #0x540
    3f08:	d2800002 	mov	x2, #0x0                   	// #0
    3f0c:	d2800000 	mov	x0, #0x0                   	// #0
    3f10:	d2880205 	mov	x5, #0x4010                	// #16400
    3f14:	d503201f 	nop
    3f18:	910f0001 	add	x1, x0, #0x3c0
    3f1c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3f20:	eb02003f 	cmp	x1, x2
    3f24:	540000a2 	b.cs	3f38 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    3f28:	91000400 	add	x0, x0, #0x1
    3f2c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3f30:	eb02003f 	cmp	x1, x2
    3f34:	54ffffa3 	b.cc	3f28 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    3f38:	91004042 	add	x2, x2, #0x10
    3f3c:	38001480 	strb	w0, [x4], #1
    3f40:	eb05005f 	cmp	x2, x5
    3f44:	54fffea1 	b.ne	3f18 <fwp_heap_init+0x94>  // b.any
    3f48:	528000b5 	mov	w21, #0x5                   	// #5
    3f4c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3f50:	14000004 	b	3f60 <fwp_heap_init+0xdc>
    3f54:	d342fe94 	lsr	x20, x20, #2
    3f58:	710006b5 	subs	w21, w21, #0x1
    3f5c:	54000720 	b.eq	4040 <fwp_heap_init+0x1bc>  // b.none
    3f60:	91404296 	add	x22, x20, #0x10, lsl #12
    3f64:	d2800005 	mov	x5, #0x0                   	// #0
    3f68:	aa1603e1 	mov	x1, x22
    3f6c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f70:	52880443 	mov	w3, #0x4022                	// #16418
    3f74:	52800002 	mov	w2, #0x0                   	// #0
    3f78:	d2800000 	mov	x0, #0x0                   	// #0
    3f7c:	97fffa65 	bl	2910 <mmap@plt>
    3f80:	aa0003e6 	mov	x6, x0
    3f84:	b100041f 	cmn	x0, #0x1
    3f88:	54fffe60 	b.eq	3f54 <fwp_heap_init+0xd0>  // b.none
    3f8c:	b40005a0 	cbz	x0, 4040 <fwp_heap_init+0x1bc>
    3f90:	d350fe94 	lsr	x20, x20, #16
    3f94:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f98:	8b0000c7 	add	x7, x6, x0
    3f9c:	91150275 	add	x21, x19, #0x540
    3fa0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3fa4:	8b140a81 	add	x1, x20, x20, lsl #2
    3fa8:	d2800005 	mov	x5, #0x0                   	// #0
    3fac:	12800004 	mov	w4, #0xffffffff            	// #-1
    3fb0:	d37df021 	lsl	x1, x1, #3
    3fb4:	52880443 	mov	w3, #0x4022                	// #16418
    3fb8:	52800002 	mov	w2, #0x0                   	// #0
    3fbc:	d2800000 	mov	x0, #0x0                   	// #0
    3fc0:	f909daa7 	str	x7, [x21, #5040]
    3fc4:	f909dea6 	str	x6, [x21, #5048]
    3fc8:	f909e2b6 	str	x22, [x21, #5056]
    3fcc:	f909eab4 	str	x20, [x21, #5072]
    3fd0:	f90a02a1 	str	x1, [x21, #5120]
    3fd4:	97fffa4f 	bl	2910 <mmap@plt>
    3fd8:	aa0003e1 	mov	x1, x0
    3fdc:	b100041f 	cmn	x0, #0x1
    3fe0:	54000300 	b.eq	4040 <fwp_heap_init+0x1bc>  // b.none
    3fe4:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    3fe8:	9136e000 	add	x0, x0, #0xdb8
    3fec:	f909fea1 	str	x1, [x21, #5112]
    3ff0:	97fffa88 	bl	2a10 <getenv@plt>
    3ff4:	52800002 	mov	w2, #0x0                   	// #0
    3ff8:	aa0003e1 	mov	x1, x0
    3ffc:	b40000e0 	cbz	x0, 4018 <fwp_heap_init+0x194>
    4000:	39400000 	ldrb	w0, [x0]
    4004:	340000a0 	cbz	w0, 4018 <fwp_heap_init+0x194>
    4008:	7100c000 	subs	w0, w0, #0x30
    400c:	54000120 	b.eq	4030 <fwp_heap_init+0x1ac>  // b.none
    4010:	7100001f 	cmp	w0, #0x0
    4014:	1a9f07e2 	cset	w2, ne	// ne = any
    4018:	91150273 	add	x19, x19, #0x540
    401c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4020:	b913aa62 	str	w2, [x19, #5032]
    4024:	a94153f3 	ldp	x19, x20, [sp, #16]
    4028:	a8c37bfd 	ldp	x29, x30, [sp], #48
    402c:	d65f03c0 	ret
    4030:	39400420 	ldrb	w0, [x1, #1]
    4034:	7100001f 	cmp	w0, #0x0
    4038:	1a9f07e2 	cset	w2, ne	// ne = any
    403c:	17fffff7 	b	4018 <fwp_heap_init+0x194>
    4040:	97fffbfc 	bl	3030 <fwp_heap_oom>

0000000000004044 <fwp_wake_io>:
    4044:	900000e9 	adrp	x9, 20000 <__data_start>
    4048:	9100c122 	add	x2, x9, #0x30
    404c:	f9400001 	ldr	x1, [x0]
    4050:	5280000a 	mov	w10, #0x0                   	// #0
    4054:	f9401446 	ldr	x6, [x2, #40]
    4058:	52800008 	mov	w8, #0x0                   	// #0
    405c:	4f000400 	movi	v0.4s, #0x0
    4060:	52800027 	mov	w7, #0x1                   	// #1
    4064:	aa0103e2 	mov	x2, x1
    4068:	b4000321 	cbz	x1, 40cc <fwp_wake_io+0x88>
    406c:	f9408c25 	ldr	x5, [x1, #280]
    4070:	39015c27 	strb	w7, [x1, #87]
    4074:	b4000165 	cbz	x5, 40a0 <fwp_wake_io+0x5c>
    4078:	a9520c24 	ldp	x4, x3, [x1, #288]
    407c:	b4000364 	cbz	x4, 40e8 <fwp_wake_io+0xa4>
    4080:	f9009483 	str	x3, [x4, #296]
    4084:	f9409423 	ldr	x3, [x1, #296]
    4088:	b4000043 	cbz	x3, 4090 <fwp_wake_io+0x4c>
    408c:	f9009064 	str	x4, [x3, #288]
    4090:	91080023 	add	x3, x1, #0x200
    4094:	f900943f 	str	xzr, [x1, #296]
    4098:	3c918060 	stur	q0, [x3, #-232]
    409c:	f9400001 	ldr	x1, [x0]
    40a0:	f9402843 	ldr	x3, [x2, #80]
    40a4:	f2001c7f 	tst	x3, #0xff000000ff
    40a8:	54fffde1 	b.ne	4064 <fwp_wake_io+0x20>  // b.any
    40ac:	39015047 	strb	w7, [x2, #84]
    40b0:	f900805f 	str	xzr, [x2, #256]
    40b4:	b40001e6 	cbz	x6, 40f0 <fwp_wake_io+0xac>
    40b8:	f90080c2 	str	x2, [x6, #256]
    40bc:	aa0203e6 	mov	x6, x2
    40c0:	52800028 	mov	w8, #0x1                   	// #1
    40c4:	aa0103e2 	mov	x2, x1
    40c8:	b5fffd21 	cbnz	x1, 406c <fwp_wake_io+0x28>
    40cc:	3400006a 	cbz	w10, 40d8 <fwp_wake_io+0x94>
    40d0:	9100c120 	add	x0, x9, #0x30
    40d4:	f900180b 	str	x11, [x0, #48]
    40d8:	34000068 	cbz	w8, 40e4 <fwp_wake_io+0xa0>
    40dc:	9100c129 	add	x9, x9, #0x30
    40e0:	f9001526 	str	x6, [x9, #40]
    40e4:	d65f03c0 	ret
    40e8:	f90000a3 	str	x3, [x5]
    40ec:	17ffffe7 	b	4088 <fwp_wake_io+0x44>
    40f0:	aa0203eb 	mov	x11, x2
    40f4:	5280002a 	mov	w10, #0x1                   	// #1
    40f8:	17fffff1 	b	40bc <fwp_wake_io+0x78>
    40fc:	d503201f 	nop

0000000000004100 <fwp_tape_buffers_release>:
    4100:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4104:	910003fd 	mov	x29, sp
    4108:	a90153f3 	stp	x19, x20, [sp, #16]
    410c:	aa0003f3 	mov	x19, x0
    4110:	f9401400 	ldr	x0, [x0, #40]
    4114:	b7f80760 	tbnz	x0, #63, 4200 <fwp_tape_buffers_release+0x100>
    4118:	f9401a61 	ldr	x1, [x19, #48]
    411c:	b7f80301 	tbnz	x1, #63, 417c <fwp_tape_buffers_release+0x7c>
    4120:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4124:	eb02001f 	cmp	x0, x2
    4128:	540002a8 	b.hi	417c <fwp_tape_buffers_release+0x7c>  // b.pmore
    412c:	8b000400 	add	x0, x0, x0, lsl #1
    4130:	d2a00102 	mov	x2, #0x80000               	// #524288
    4134:	d37df000 	lsl	x0, x0, #3
    4138:	cb000042 	sub	x2, x2, x0
    413c:	eb420c3f 	cmp	x1, x2, lsr #3
    4140:	540001e8 	b.hi	417c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4144:	8b010c14 	add	x20, x0, x1, lsl #3
    4148:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    414c:	91372000 	add	x0, x0, #0xdc8
    4150:	97fffa30 	bl	2a10 <getenv@plt>
    4154:	b4000240 	cbz	x0, 419c <fwp_tape_buffers_release+0x9c>
    4158:	39400001 	ldrb	w1, [x0]
    415c:	7100c03f 	cmp	w1, #0x30
    4160:	540001e1 	b.ne	419c <fwp_tape_buffers_release+0x9c>  // b.any
    4164:	39400400 	ldrb	w0, [x0, #1]
    4168:	350001a0 	cbnz	w0, 419c <fwp_tape_buffers_release+0x9c>
    416c:	aa1303e0 	mov	x0, x19
    4170:	a94153f3 	ldp	x19, x20, [sp, #16]
    4174:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4178:	17fffc62 	b	3300 <fwp_tape_buffers_dispose>
    417c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    4180:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4184:	91372000 	add	x0, x0, #0xdc8
    4188:	97fffa22 	bl	2a10 <getenv@plt>
    418c:	b4ffff00 	cbz	x0, 416c <fwp_tape_buffers_release+0x6c>
    4190:	39400001 	ldrb	w1, [x0]
    4194:	7100c03f 	cmp	w1, #0x30
    4198:	54fffe60 	b.eq	4164 <fwp_tape_buffers_release+0x64>  // b.none
    419c:	d1000681 	sub	x1, x20, #0x1
    41a0:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    41a4:	eb00003f 	cmp	x1, x0
    41a8:	54fffe28 	b.hi	416c <fwp_tape_buffers_release+0x6c>  // b.pmore
    41ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    41b0:	900000f6 	adrp	x22, 20000 <__data_start>
    41b4:	9100c2d6 	add	x22, x22, #0x30
    41b8:	910122d5 	add	x21, x22, #0x48
    41bc:	aa1503e0 	mov	x0, x21
    41c0:	97fffc50 	bl	3300 <fwp_tape_buffers_dispose>
    41c4:	ad400a61 	ldp	q1, q2, [x19]
    41c8:	f90042d4 	str	x20, [x22, #128]
    41cc:	4f000400 	movi	v0.4s, #0x0
    41d0:	ad000aa1 	stp	q1, q2, [x21]
    41d4:	3dc00a61 	ldr	q1, [x19, #32]
    41d8:	3d800aa1 	str	q1, [x21, #32]
    41dc:	f9401a60 	ldr	x0, [x19, #48]
    41e0:	f9001aa0 	str	x0, [x21, #48]
    41e4:	f9001a7f 	str	xzr, [x19, #48]
    41e8:	ad000260 	stp	q0, q0, [x19]
    41ec:	3d800a60 	str	q0, [x19, #32]
    41f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    41f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    41f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    41fc:	d65f03c0 	ret
    4200:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    4204:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4208:	91372000 	add	x0, x0, #0xdc8
    420c:	97fffa01 	bl	2a10 <getenv@plt>
    4210:	b5fffa40 	cbnz	x0, 4158 <fwp_tape_buffers_release+0x58>
    4214:	17ffffd6 	b	416c <fwp_tape_buffers_release+0x6c>
    4218:	d503201f 	nop
    421c:	d503201f 	nop

0000000000004220 <fwp_poll_events>:
    4220:	d10103ff 	sub	sp, sp, #0x40
    4224:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4228:	f947f400 	ldr	x0, [x0, #4072]
    422c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4230:	910083fd 	add	x29, sp, #0x20
    4234:	a90353f3 	stp	x19, x20, [sp, #48]
    4238:	900000f4 	adrp	x20, 20000 <__data_start>
    423c:	f9400001 	ldr	x1, [x0]
    4240:	f9000fe1 	str	x1, [sp, #24]
    4244:	d2800001 	mov	x1, #0x0                   	// #0
    4248:	97fffd2e 	bl	3700 <fwp_now_ns>
    424c:	9100c281 	add	x1, x20, #0x30
    4250:	f9404433 	ldr	x19, [x1, #136]
    4254:	b4000e93 	cbz	x19, 4424 <fwp_poll_events+0x204>
    4258:	aa1303e1 	mov	x1, x19
    425c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4260:	14000005 	b	4274 <fwp_poll_events+0x54>
    4264:	f9408821 	ldr	x1, [x1, #272]
    4268:	eb03005f 	cmp	x2, x3
    426c:	9a83d042 	csel	x2, x2, x3, le
    4270:	b40000c1 	cbz	x1, 4288 <fwp_poll_events+0x68>
    4274:	f9403423 	ldr	x3, [x1, #104]
    4278:	b6ffff62 	tbz	x2, #63, 4264 <fwp_poll_events+0x44>
    427c:	f9408821 	ldr	x1, [x1, #272]
    4280:	aa0303e2 	mov	x2, x3
    4284:	b5ffff81 	cbnz	x1, 4274 <fwp_poll_events+0x54>
    4288:	b7f80ce2 	tbnz	x2, #63, 4424 <fwp_poll_events+0x204>
    428c:	cb000042 	sub	x2, x2, x0
    4290:	f100005f 	cmp	x2, #0x0
    4294:	540005cd 	b.le	434c <fwp_poll_events+0x12c>
    4298:	d2869b60 	mov	x0, #0x34db                	// #13531
    429c:	d2884801 	mov	x1, #0x4240                	// #16960
    42a0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    42a4:	f2a001e1 	movk	x1, #0xf, lsl #16
    42a8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    42ac:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    42b0:	f2e86360 	movk	x0, #0x431b, lsl #48
    42b4:	9b407c40 	smulh	x0, x2, x0
    42b8:	9352fc00 	asr	x0, x0, #18
    42bc:	cb82fc00 	sub	x0, x0, x2, asr #63
    42c0:	9b018802 	msub	x2, x0, x1, x2
    42c4:	f100005f 	cmp	x2, #0x0
    42c8:	9a800400 	cinc	x0, x0, ne	// ne = any
    42cc:	eb03001f 	cmp	x0, x3
    42d0:	54000a0c 	b.gt	4410 <fwp_poll_events+0x1f0>
    42d4:	340003c0 	cbz	w0, 434c <fwp_poll_events+0x12c>
    42d8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    42dc:	52807d04 	mov	w4, #0x3e8                 	// #1000
    42e0:	72a20c42 	movk	w2, #0x1062, lsl #16
    42e4:	9ba27c02 	umull	x2, w0, w2
    42e8:	d366fc43 	lsr	x3, x2, #38
    42ec:	aa0303e2 	mov	x2, x3
    42f0:	1b048063 	msub	w3, w3, w4, w0
    42f4:	9b217c63 	smull	x3, w3, w1
    42f8:	d2800001 	mov	x1, #0x0                   	// #0
    42fc:	910023e0 	add	x0, sp, #0x8
    4300:	a9008fe2 	stp	x2, x3, [sp, #8]
    4304:	97fff993 	bl	2950 <nanosleep@plt>
    4308:	9100c280 	add	x0, x20, #0x30
    430c:	f9404413 	ldr	x19, [x0, #136]
    4310:	97fffcfc 	bl	3700 <fwp_now_ns>
    4314:	aa0003e6 	mov	x6, x0
    4318:	b50001f3 	cbnz	x19, 4354 <fwp_poll_events+0x134>
    431c:	d503201f 	nop
    4320:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4324:	f947f400 	ldr	x0, [x0, #4072]
    4328:	f9400fe2 	ldr	x2, [sp, #24]
    432c:	f9400001 	ldr	x1, [x0]
    4330:	eb010042 	subs	x2, x2, x1
    4334:	d2800001 	mov	x1, #0x0                   	// #0
    4338:	540008c1 	b.ne	4450 <fwp_poll_events+0x230>  // b.any
    433c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4340:	a94353f3 	ldp	x19, x20, [sp, #48]
    4344:	910103ff 	add	sp, sp, #0x40
    4348:	d65f03c0 	ret
    434c:	97fffced 	bl	3700 <fwp_now_ns>
    4350:	aa0003e6 	mov	x6, x0
    4354:	4f000400 	movi	v0.4s, #0x0
    4358:	9100c288 	add	x8, x20, #0x30
    435c:	52800027 	mov	w7, #0x1                   	// #1
    4360:	f9403661 	ldr	x1, [x19, #104]
    4364:	aa1303e5 	mov	x5, x19
    4368:	f9408a73 	ldr	x19, [x19, #272]
    436c:	eb06003f 	cmp	x1, x6
    4370:	5400032c 	b.gt	43d4 <fwp_poll_events+0x1b4>
    4374:	394154a0 	ldrb	w0, [x5, #85]
    4378:	36000120 	tbz	w0, #0, 439c <fwp_poll_events+0x17c>
    437c:	f94084a0 	ldr	x0, [x5, #264]
    4380:	b40003c0 	cbz	x0, 43f8 <fwp_poll_events+0x1d8>
    4384:	f9008813 	str	x19, [x0, #272]
    4388:	b4000053 	cbz	x19, 4390 <fwp_poll_events+0x170>
    438c:	f9008660 	str	x0, [x19, #264]
    4390:	910800a0 	add	x0, x5, #0x200
    4394:	390154bf 	strb	wzr, [x5, #85]
    4398:	3c908000 	stur	q0, [x0, #-248]
    439c:	f94030a0 	ldr	x0, [x5, #96]
    43a0:	390158a7 	strb	w7, [x5, #86]
    43a4:	f100001f 	cmp	x0, #0x0
    43a8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    43ac:	5400018d 	b.le	43dc <fwp_poll_events+0x1bc>
    43b0:	f94028a0 	ldr	x0, [x5, #80]
    43b4:	f2001c1f 	tst	x0, #0xff000000ff
    43b8:	540000e1 	b.ne	43d4 <fwp_poll_events+0x1b4>  // b.any
    43bc:	f9401500 	ldr	x0, [x8, #40]
    43c0:	390150a7 	strb	w7, [x5, #84]
    43c4:	f90080bf 	str	xzr, [x5, #256]
    43c8:	b40001e0 	cbz	x0, 4404 <fwp_poll_events+0x1e4>
    43cc:	f9001505 	str	x5, [x8, #40]
    43d0:	f9008005 	str	x5, [x0, #256]
    43d4:	b5fffc73 	cbnz	x19, 4360 <fwp_poll_events+0x140>
    43d8:	17ffffd2 	b	4320 <fwp_poll_events+0x100>
    43dc:	394144a0 	ldrb	w0, [x5, #81]
    43e0:	3707fe80 	tbnz	w0, #0, 43b0 <fwp_poll_events+0x190>
    43e4:	394140a0 	ldrb	w0, [x5, #80]
    43e8:	3707fe40 	tbnz	w0, #0, 43b0 <fwp_poll_events+0x190>
    43ec:	aa0503e0 	mov	x0, x5
    43f0:	97fffc20 	bl	3470 <fwp_cancel_tree.part.0>
    43f4:	17ffffef 	b	43b0 <fwp_poll_events+0x190>
    43f8:	9100c281 	add	x1, x20, #0x30
    43fc:	f9004433 	str	x19, [x1, #136]
    4400:	17ffffe2 	b	4388 <fwp_poll_events+0x168>
    4404:	f9001505 	str	x5, [x8, #40]
    4408:	f9001905 	str	x5, [x8, #48]
    440c:	17fffff2 	b	43d4 <fwp_poll_events+0x1b4>
    4410:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4414:	d2989362 	mov	x2, #0xc49b                	// #50331
    4418:	f2a4d203 	movk	x3, #0x2690, lsl #16
    441c:	f2a00402 	movk	x2, #0x20, lsl #16
    4420:	17ffffb6 	b	42f8 <fwp_poll_events+0xd8>
    4424:	97fffaf3 	bl	2ff0 <fwp_flush>
    4428:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    442c:	f947e863 	ldr	x3, [x3, #4048]
    4430:	d2800562 	mov	x2, #0x2b                  	// #43
    4434:	d2800021 	mov	x1, #0x1                   	// #1
    4438:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    443c:	91378000 	add	x0, x0, #0xde0
    4440:	f9400063 	ldr	x3, [x3]
    4444:	97fff94f 	bl	2980 <fwrite@plt>
    4448:	52800ca0 	mov	w0, #0x65                  	// #101
    444c:	97fff8b9 	bl	2730 <exit@plt>
    4450:	97fff90c 	bl	2880 <__stack_chk_fail@plt>

0000000000004454 <fwp_rc_wide_dup>:
    4454:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4458:	910003fd 	mov	x29, sp
    445c:	a90153f3 	stp	x19, x20, [sp, #16]
    4460:	aa0003f3 	mov	x19, x0
    4464:	ca404400 	eor	x0, x0, x0, lsr #17
    4468:	f90013f5 	str	x21, [sp, #32]
    446c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4470:	ca402400 	eor	x0, x0, x0, lsr #9
    4474:	911502a2 	add	x2, x21, #0x540
    4478:	92401c00 	and	x0, x0, #0xff
    447c:	910a2403 	add	x3, x0, #0x289
    4480:	8b000c40 	add	x0, x2, x0, lsl #3
    4484:	8b030c54 	add	x20, x2, x3, lsl #3
    4488:	f94a2401 	ldr	x1, [x0, #5192]
    448c:	b50000a1 	cbnz	x1, 44a0 <fwp_rc_wide_dup+0x4c>
    4490:	1400002d 	b	4544 <fwp_rc_wide_dup+0xf0>
    4494:	91004034 	add	x20, x1, #0x10
    4498:	f9400821 	ldr	x1, [x1, #16]
    449c:	b4000241 	cbz	x1, 44e4 <fwp_rc_wide_dup+0x90>
    44a0:	f9400022 	ldr	x2, [x1]
    44a4:	eb02027f 	cmp	x19, x2
    44a8:	54ffff61 	b.ne	4494 <fwp_rc_wide_dup+0x40>  // b.any
    44ac:	f9400281 	ldr	x1, [x20]
    44b0:	39400260 	ldrb	w0, [x19]
    44b4:	7103f81f 	cmp	w0, #0xfe
    44b8:	54000220 	b.eq	44fc <fwp_rc_wide_dup+0xa8>  // b.none
    44bc:	b40001a1 	cbz	x1, 44f0 <fwp_rc_wide_dup+0x9c>
    44c0:	f9400420 	ldr	x0, [x1, #8]
    44c4:	b100041f 	cmn	x0, #0x1
    44c8:	540004a0 	b.eq	455c <fwp_rc_wide_dup+0x108>  // b.none
    44cc:	91000400 	add	x0, x0, #0x1
    44d0:	f9000420 	str	x0, [x1, #8]
    44d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    44d8:	f94013f5 	ldr	x21, [sp, #32]
    44dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44e0:	d65f03c0 	ret
    44e4:	39400260 	ldrb	w0, [x19]
    44e8:	7103f81f 	cmp	w0, #0xfe
    44ec:	540000a0 	b.eq	4500 <fwp_rc_wide_dup+0xac>  // b.none
    44f0:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    44f4:	9138e000 	add	x0, x0, #0xe38
    44f8:	97fffc22 	bl	3580 <fwp_trap>
    44fc:	b5000281 	cbnz	x1, 454c <fwp_rc_wide_dup+0xf8>
    4500:	d2800300 	mov	x0, #0x18                  	// #24
    4504:	97fff8c7 	bl	2820 <malloc@plt>
    4508:	b4000280 	cbz	x0, 4558 <fwp_rc_wide_dup+0x104>
    450c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4510:	a9000413 	stp	x19, x1, [x0]
    4514:	911502b5 	add	x21, x21, #0x540
    4518:	f900081f 	str	xzr, [x0, #16]
    451c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4520:	f9000280 	str	x0, [x20]
    4524:	39000261 	strb	w1, [x19]
    4528:	f94e26a0 	ldr	x0, [x21, #7240]
    452c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4530:	91000400 	add	x0, x0, #0x1
    4534:	f90e26a0 	str	x0, [x21, #7240]
    4538:	f94013f5 	ldr	x21, [sp, #32]
    453c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4540:	d65f03c0 	ret
    4544:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4548:	17ffffda 	b	44b0 <fwp_rc_wide_dup+0x5c>
    454c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    4550:	91384000 	add	x0, x0, #0xe10
    4554:	97fffc0b 	bl	3580 <fwp_trap>
    4558:	97fffab6 	bl	3030 <fwp_heap_oom>
    455c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    4560:	91398000 	add	x0, x0, #0xe60
    4564:	97fffc07 	bl	3580 <fwp_trap>
    4568:	d503201f 	nop
    456c:	d503201f 	nop

0000000000004570 <fwp_rc_forget_slot>:
    4570:	aa0003e1 	mov	x1, x0
    4574:	39400000 	ldrb	w0, [x0]
    4578:	7103fc1f 	cmp	w0, #0xff
    457c:	54000040 	b.eq	4584 <fwp_rc_forget_slot+0x14>  // b.none
    4580:	d65f03c0 	ret
    4584:	ca414420 	eor	x0, x1, x1, lsr #17
    4588:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    458c:	ca402400 	eor	x0, x0, x0, lsr #9
    4590:	910003fd 	mov	x29, sp
    4594:	92401c00 	and	x0, x0, #0xff
    4598:	f9000bf3 	str	x19, [sp, #16]
    459c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    45a0:	91150262 	add	x2, x19, #0x540
    45a4:	910a2403 	add	x3, x0, #0x289
    45a8:	8b000c40 	add	x0, x2, x0, lsl #3
    45ac:	8b030c43 	add	x3, x2, x3, lsl #3
    45b0:	f94a2400 	ldr	x0, [x0, #5192]
    45b4:	b50000a0 	cbnz	x0, 45c8 <fwp_rc_forget_slot+0x58>
    45b8:	14000011 	b	45fc <fwp_rc_forget_slot+0x8c>
    45bc:	91004003 	add	x3, x0, #0x10
    45c0:	f9400800 	ldr	x0, [x0, #16]
    45c4:	b40001c0 	cbz	x0, 45fc <fwp_rc_forget_slot+0x8c>
    45c8:	f9400002 	ldr	x2, [x0]
    45cc:	eb02003f 	cmp	x1, x2
    45d0:	54ffff61 	b.ne	45bc <fwp_rc_forget_slot+0x4c>  // b.any
    45d4:	f9400801 	ldr	x1, [x0, #16]
    45d8:	91150273 	add	x19, x19, #0x540
    45dc:	f9000061 	str	x1, [x3]
    45e0:	97fff8d8 	bl	2940 <free@plt>
    45e4:	f94e2660 	ldr	x0, [x19, #7240]
    45e8:	d1000400 	sub	x0, x0, #0x1
    45ec:	f90e2660 	str	x0, [x19, #7240]
    45f0:	f9400bf3 	ldr	x19, [sp, #16]
    45f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    45f8:	d65f03c0 	ret
    45fc:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    4600:	9138e000 	add	x0, x0, #0xe38
    4604:	97fffbdf 	bl	3580 <fwp_trap>
    4608:	d503201f 	nop
    460c:	d503201f 	nop

0000000000004610 <fwp_rc_prepare_chunk>:
    4610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4614:	910003fd 	mov	x29, sp
    4618:	a9025bf5 	stp	x21, x22, [sp, #32]
    461c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xca0>
    4620:	911502c2 	add	x2, x22, #0x540
    4624:	b9401c03 	ldr	w3, [x0, #28]
    4628:	aa0103f5 	mov	x21, x1
    462c:	a90153f3 	stp	x19, x20, [sp, #16]
    4630:	aa0003f4 	mov	x20, x0
    4634:	f94e2440 	ldr	x0, [x2, #7240]
    4638:	b4000440 	cbz	x0, 46c0 <fwp_rc_prepare_chunk+0xb0>
    463c:	d2800013 	mov	x19, #0x0                   	// #0
    4640:	35000203 	cbnz	w3, 4680 <fwp_rc_prepare_chunk+0x70>
    4644:	b4000361 	cbz	x1, 46b0 <fwp_rc_prepare_chunk+0xa0>
    4648:	f9401280 	ldr	x0, [x20, #32]
    464c:	97fff8bd 	bl	2940 <free@plt>
    4650:	aa1503e0 	mov	x0, x21
    4654:	d2800021 	mov	x1, #0x1                   	// #1
    4658:	97fff882 	bl	2860 <calloc@plt>
    465c:	f9001280 	str	x0, [x20, #32]
    4660:	b5000460 	cbnz	x0, 46ec <fwp_rc_prepare_chunk+0xdc>
    4664:	97fffa73 	bl	3030 <fwp_heap_oom>
    4668:	97ffffc2 	bl	4570 <fwp_rc_forget_slot>
    466c:	91000673 	add	x19, x19, #0x1
    4670:	b9401e83 	ldr	w3, [x20, #28]
    4674:	eb13007f 	cmp	x3, x19
    4678:	54000169 	b.ls	46a4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    467c:	d503201f 	nop
    4680:	f9401283 	ldr	x3, [x20, #32]
    4684:	8b130060 	add	x0, x3, x19
    4688:	38736863 	ldrb	w3, [x3, x19]
    468c:	7103fc7f 	cmp	w3, #0xff
    4690:	54fffec0 	b.eq	4668 <fwp_rc_prepare_chunk+0x58>  // b.none
    4694:	b9401e83 	ldr	w3, [x20, #28]
    4698:	91000673 	add	x19, x19, #0x1
    469c:	eb13007f 	cmp	x3, x19
    46a0:	54ffff08 	b.hi	4680 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    46a4:	eb0302bf 	cmp	x21, x3
    46a8:	54000121 	b.ne	46cc <fwp_rc_prepare_chunk+0xbc>  // b.any
    46ac:	b5000335 	cbnz	x21, 4710 <fwp_rc_prepare_chunk+0x100>
    46b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    46b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46bc:	d65f03c0 	ret
    46c0:	2a0303e3 	mov	w3, w3
    46c4:	eb0302bf 	cmp	x21, x3
    46c8:	54ffff20 	b.eq	46ac <fwp_rc_prepare_chunk+0x9c>  // b.none
    46cc:	911502c2 	add	x2, x22, #0x540
    46d0:	f9401280 	ldr	x0, [x20, #32]
    46d4:	f94e2841 	ldr	x1, [x2, #7248]
    46d8:	cb030021 	sub	x1, x1, x3
    46dc:	f90e2841 	str	x1, [x2, #7248]
    46e0:	97fff898 	bl	2940 <free@plt>
    46e4:	b5fffb75 	cbnz	x21, 4650 <fwp_rc_prepare_chunk+0x40>
    46e8:	f900129f 	str	xzr, [x20, #32]
    46ec:	911502d6 	add	x22, x22, #0x540
    46f0:	f94e2ac0 	ldr	x0, [x22, #7248]
    46f4:	b9001e95 	str	w21, [x20, #28]
    46f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    46fc:	8b150000 	add	x0, x0, x21
    4700:	f90e2ac0 	str	x0, [x22, #7248]
    4704:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4708:	a8c37bfd 	ldp	x29, x30, [sp], #48
    470c:	d65f03c0 	ret
    4710:	f9401280 	ldr	x0, [x20, #32]
    4714:	aa1503e2 	mov	x2, x21
    4718:	a94153f3 	ldp	x19, x20, [sp, #16]
    471c:	52800001 	mov	w1, #0x0                   	// #0
    4720:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4724:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4728:	17fff84a 	b	2850 <memset@plt>
    472c:	d503201f 	nop

0000000000004730 <fwp_heap_refill>:
    4730:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4734:	910003fd 	mov	x29, sp
    4738:	a9025bf5 	stp	x21, x22, [sp, #32]
    473c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4740:	911502b5 	add	x21, x21, #0x540
    4744:	aa0003f6 	mov	x22, x0
    4748:	d2800020 	mov	x0, #0x1                   	// #1
    474c:	a90153f3 	stp	x19, x20, [sp, #16]
    4750:	a90363f7 	stp	x23, x24, [sp, #48]
    4754:	2a0103f7 	mov	w23, w1
    4758:	2a0203f8 	mov	w24, w2
    475c:	97fffa75 	bl	3130 <fwp_heap_chunks>
    4760:	aa0003f3 	mov	x19, x0
    4764:	f949fea2 	ldr	x2, [x21, #5112]
    4768:	8b000800 	add	x0, x0, x0, lsl #2
    476c:	2a1703e1 	mov	w1, w23
    4770:	52800025 	mov	w5, #0x1                   	// #1
    4774:	d37df000 	lsl	x0, x0, #3
    4778:	910f0021 	add	x1, x1, #0x3c0
    477c:	8b000054 	add	x20, x2, x0
    4780:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4784:	52a00024 	mov	w4, #0x10000               	// #65536
    4788:	38206845 	strb	w5, [x2, x0]
    478c:	aa1403e0 	mov	x0, x20
    4790:	39000698 	strb	w24, [x20, #1]
    4794:	39000a97 	strb	w23, [x20, #2]
    4798:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    479c:	b9000681 	str	w1, [x20, #4]
    47a0:	2a0103e5 	mov	w5, w1
    47a4:	8b0300a2 	add	x2, x5, x3
    47a8:	1ac10881 	udiv	w1, w4, w1
    47ac:	9ac50842 	udiv	x2, x2, x5
    47b0:	b9000a81 	str	w1, [x20, #8]
    47b4:	92404021 	and	x1, x1, #0x1ffff
    47b8:	b9001a82 	str	w2, [x20, #24]
    47bc:	97ffff95 	bl	4610 <fwp_rc_prepare_chunk>
    47c0:	f949daa0 	ldr	x0, [x21, #5040]
    47c4:	29408a81 	ldp	w1, w2, [x20, #4]
    47c8:	8b134000 	add	x0, x0, x19, lsl #16
    47cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    47d0:	8b214003 	add	x3, x0, w1, uxtw
    47d4:	9ba20021 	umaddl	x1, w1, w2, x0
    47d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    47dc:	a90086c3 	stp	x3, x1, [x22, #8]
    47e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47e4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    47e8:	d65f03c0 	ret
    47ec:	d503201f 	nop

00000000000047f0 <fwp_mem_free>:
    47f0:	b40003c0 	cbz	x0, 4868 <fwp_mem_free+0x78>
    47f4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    47f8:	910003fd 	mov	x29, sp
    47fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4800:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4804:	911502a1 	add	x1, x21, #0x540
    4808:	a90153f3 	stp	x19, x20, [sp, #16]
    480c:	aa0003f3 	mov	x19, x0
    4810:	f949d823 	ldr	x3, [x1, #5040]
    4814:	f949ec22 	ldr	x2, [x1, #5080]
    4818:	cb030000 	sub	x0, x0, x3
    481c:	eb02401f 	cmp	x0, x2, lsl #16
    4820:	540001c2 	b.cs	4858 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4824:	d350fc16 	lsr	x22, x0, #16
    4828:	a90363f7 	stp	x23, x24, [sp, #48]
    482c:	f949fc22 	ldr	x2, [x1, #5112]
    4830:	8b160ad4 	add	x20, x22, x22, lsl #2
    4834:	d37df294 	lsl	x20, x20, #3
    4838:	ab140057 	adds	x23, x2, x20
    483c:	540000c0 	b.eq	4854 <fwp_mem_free+0x64>  // b.none
    4840:	38746842 	ldrb	w2, [x2, x20]
    4844:	7100045f 	cmp	w2, #0x1
    4848:	54000120 	b.eq	486c <fwp_mem_free+0x7c>  // b.none
    484c:	7100085f 	cmp	w2, #0x2
    4850:	540005e0 	b.eq	490c <fwp_mem_free+0x11c>  // b.none
    4854:	a94363f7 	ldp	x23, x24, [sp, #48]
    4858:	a94153f3 	ldp	x19, x20, [sp, #16]
    485c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4860:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4864:	d65f03c0 	ret
    4868:	d65f03c0 	ret
    486c:	f94012f8 	ldr	x24, [x23, #32]
    4870:	b94006e1 	ldr	w1, [x23, #4]
    4874:	f90023f9 	str	x25, [sp, #64]
    4878:	2a0103e2 	mov	w2, w1
    487c:	394006f9 	ldrb	w25, [x23, #1]
    4880:	39400af4 	ldrb	w20, [x23, #2]
    4884:	b4000158 	cbz	x24, 48ac <fwp_mem_free+0xbc>
    4888:	92403e76 	and	x22, x19, #0xffff
    488c:	9ac20ad6 	udiv	x22, x22, x2
    4890:	38766b01 	ldrb	w1, [x24, x22]
    4894:	8b160300 	add	x0, x24, x22
    4898:	7103fc3f 	cmp	w1, #0xff
    489c:	54000980 	b.eq	49cc <fwp_mem_free+0x1dc>  // b.none
    48a0:	38366b1f 	strb	wzr, [x24, x22]
    48a4:	b94006e1 	ldr	w1, [x23, #4]
    48a8:	2a0103e2 	mov	w2, w1
    48ac:	d37c1f20 	ubfiz	x0, x25, #4, #8
    48b0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    48b4:	cb390000 	sub	x0, x0, w25, uxtb
    48b8:	8b340074 	add	x20, x3, w20, uxtb
    48bc:	911502b5 	add	x21, x21, #0x540
    48c0:	1e630021 	ucvtf	d1, w1
    48c4:	d37ae400 	lsl	x0, x0, #6
    48c8:	8b140c14 	add	x20, x0, x20, lsl #3
    48cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    48d0:	f8746aa0 	ldr	x0, [x21, x20]
    48d4:	f94023f9 	ldr	x25, [sp, #64]
    48d8:	aa2003e0 	mvn	x0, x0
    48dc:	fd4a22a0 	ldr	d0, [x21, #5184]
    48e0:	f9000260 	str	x0, [x19]
    48e4:	f8346ab3 	str	x19, [x21, x20]
    48e8:	f94a12a0 	ldr	x0, [x21, #5152]
    48ec:	1e612800 	fadd	d0, d0, d1
    48f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    48f4:	cb020000 	sub	x0, x0, x2
    48f8:	f90a12a0 	str	x0, [x21, #5152]
    48fc:	fd0a22a0 	str	d0, [x21, #5184]
    4900:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4904:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4908:	d65f03c0 	ret
    490c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4910:	8b000063 	add	x3, x3, x0
    4914:	eb03027f 	cmp	x19, x3
    4918:	54fff9e1 	b.ne	4854 <fwp_mem_free+0x64>  // b.any
    491c:	fd400ae1 	ldr	d1, [x23, #16]
    4920:	fd4a2020 	ldr	d0, [x1, #5184]
    4924:	f9400ae0 	ldr	x0, [x23, #16]
    4928:	7e61d821 	ucvtf	d1, d1
    492c:	f94a1022 	ldr	x2, [x1, #5152]
    4930:	f94012f3 	ldr	x19, [x23, #32]
    4934:	1e612800 	fadd	d0, d0, d1
    4938:	cb000042 	sub	x2, x2, x0
    493c:	f90a1022 	str	x2, [x1, #5152]
    4940:	fd0a2020 	str	d0, [x1, #5184]
    4944:	b40000b3 	cbz	x19, 4958 <fwp_mem_free+0x168>
    4948:	39400260 	ldrb	w0, [x19]
    494c:	7103fc1f 	cmp	w0, #0xff
    4950:	54000380 	b.eq	49c0 <fwp_mem_free+0x1d0>  // b.none
    4954:	3900027f 	strb	wzr, [x19]
    4958:	b9400ee2 	ldr	w2, [x23, #12]
    495c:	b4000142 	cbz	x2, 4984 <fwp_mem_free+0x194>
    4960:	911502a1 	add	x1, x21, #0x540
    4964:	8b160040 	add	x0, x2, x22
    4968:	8b000800 	add	x0, x0, x0, lsl #2
    496c:	f949fc21 	ldr	x1, [x1, #5112]
    4970:	8b140034 	add	x20, x1, x20
    4974:	8b000c20 	add	x0, x1, x0, lsl #3
    4978:	3802869f 	strb	wzr, [x20], #40
    497c:	eb00029f 	cmp	x20, x0
    4980:	54ffffc1 	b.ne	4978 <fwp_mem_free+0x188>  // b.any
    4984:	911502a0 	add	x0, x21, #0x540
    4988:	f94a1801 	ldr	x1, [x0, #5168]
    498c:	f949f803 	ldr	x3, [x0, #5104]
    4990:	8b020021 	add	x1, x1, x2
    4994:	f90a1801 	str	x1, [x0, #5168]
    4998:	eb16007f 	cmp	x3, x22
    499c:	54000049 	b.ls	49a4 <fwp_mem_free+0x1b4>  // b.plast
    49a0:	f909f816 	str	x22, [x0, #5104]
    49a4:	911502b5 	add	x21, x21, #0x540
    49a8:	f949f6a0 	ldr	x0, [x21, #5096]
    49ac:	eb16001f 	cmp	x0, x22
    49b0:	54fff529 	b.ls	4854 <fwp_mem_free+0x64>  // b.plast
    49b4:	a94363f7 	ldp	x23, x24, [sp, #48]
    49b8:	f909f6b6 	str	x22, [x21, #5096]
    49bc:	17ffffa7 	b	4858 <fwp_mem_free+0x68>
    49c0:	aa1303e0 	mov	x0, x19
    49c4:	97fffeeb 	bl	4570 <fwp_rc_forget_slot>
    49c8:	17ffffe3 	b	4954 <fwp_mem_free+0x164>
    49cc:	97fffee9 	bl	4570 <fwp_rc_forget_slot>
    49d0:	17ffffb4 	b	48a0 <fwp_mem_free+0xb0>

00000000000049d4 <fwp_heap_alloc_big>:
    49d4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    49d8:	910003fd 	mov	x29, sp
    49dc:	a90153f3 	stp	x19, x20, [sp, #16]
    49e0:	a9025bf5 	stp	x21, x22, [sp, #32]
    49e4:	a90363f7 	stp	x23, x24, [sp, #48]
    49e8:	aa0003f7 	mov	x23, x0
    49ec:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    49f0:	a9046bf9 	stp	x25, x26, [sp, #64]
    49f4:	eb0002ff 	cmp	x23, x0
    49f8:	54000888 	b.hi	4b08 <fwp_heap_alloc_big+0x134>  // b.pmore
    49fc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4a00:	8b0002f4 	add	x20, x23, x0
    4a04:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xca0>
    4a08:	91150359 	add	x25, x26, #0x540
    4a0c:	d350fe94 	lsr	x20, x20, #16
    4a10:	2a0103f5 	mov	w21, w1
    4a14:	aa1403e0 	mov	x0, x20
    4a18:	97fff9c6 	bl	3130 <fwp_heap_chunks>
    4a1c:	f949ff22 	ldr	x2, [x25, #5112]
    4a20:	8b000813 	add	x19, x0, x0, lsl #2
    4a24:	aa0003f8 	mov	x24, x0
    4a28:	52800043 	mov	w3, #0x2                   	// #2
    4a2c:	d37df273 	lsl	x19, x19, #3
    4a30:	d2800021 	mov	x1, #0x1                   	// #1
    4a34:	8b130040 	add	x0, x2, x19
    4a38:	38336843 	strb	w3, [x2, x19]
    4a3c:	39000415 	strb	w21, [x0, #1]
    4a40:	b9000c14 	str	w20, [x0, #12]
    4a44:	f9000817 	str	x23, [x0, #16]
    4a48:	97fffef2 	bl	4610 <fwp_rc_prepare_chunk>
    4a4c:	f100069f 	cmp	x20, #0x1
    4a50:	54000269 	b.ls	4a9c <fwp_heap_alloc_big+0xc8>  // b.plast
    4a54:	8b180294 	add	x20, x20, x24
    4a58:	9100a273 	add	x19, x19, #0x28
    4a5c:	a90573fb 	stp	x27, x28, [sp, #80]
    4a60:	5280007b 	mov	w27, #0x3                   	// #3
    4a64:	8b140a94 	add	x20, x20, x20, lsl #2
    4a68:	2a1803fc 	mov	w28, w24
    4a6c:	9adb2296 	lsl	x22, x20, x27
    4a70:	f949ff35 	ldr	x21, [x25, #5112]
    4a74:	d2800001 	mov	x1, #0x0                   	// #0
    4a78:	8b1302b4 	add	x20, x21, x19
    4a7c:	aa1403e0 	mov	x0, x20
    4a80:	97fffee4 	bl	4610 <fwp_rc_prepare_chunk>
    4a84:	38336abb 	strb	w27, [x21, x19]
    4a88:	9100a273 	add	x19, x19, #0x28
    4a8c:	b9000e9c 	str	w28, [x20, #12]
    4a90:	eb1302df 	cmp	x22, x19
    4a94:	54fffee1 	b.ne	4a70 <fwp_heap_alloc_big+0x9c>  // b.any
    4a98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a9c:	91150353 	add	x19, x26, #0x540
    4aa0:	aa1703e2 	mov	x2, x23
    4aa4:	52800001 	mov	w1, #0x0                   	// #0
    4aa8:	f949da60 	ldr	x0, [x19, #5040]
    4aac:	8b184018 	add	x24, x0, x24, lsl #16
    4ab0:	aa1803e0 	mov	x0, x24
    4ab4:	97fff767 	bl	2850 <memset@plt>
    4ab8:	f94a1260 	ldr	x0, [x19, #5152]
    4abc:	ab170000 	adds	x0, x0, x23
    4ac0:	54000242 	b.cs	4b08 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4ac4:	f94a1661 	ldr	x1, [x19, #5160]
    4ac8:	f90a1260 	str	x0, [x19, #5152]
    4acc:	eb01001f 	cmp	x0, x1
    4ad0:	54000049 	b.ls	4ad8 <fwp_heap_alloc_big+0x104>  // b.plast
    4ad4:	f90a1660 	str	x0, [x19, #5160]
    4ad8:	9115035a 	add	x26, x26, #0x540
    4adc:	9e6202e0 	scvtf	d0, x23
    4ae0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ae4:	aa1803e0 	mov	x0, x24
    4ae8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4aec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4af0:	1e602820 	fadd	d0, d1, d0
    4af4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4af8:	fd0a1f40 	str	d0, [x26, #5176]
    4afc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4b00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4b04:	d65f03c0 	ret
    4b08:	a90573fb 	stp	x27, x28, [sp, #80]
    4b0c:	97fff949 	bl	3030 <fwp_heap_oom>

0000000000004b10 <fwp_heap_alloc_slow>:
    4b10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4b14:	910003fd 	mov	x29, sp
    4b18:	a90153f3 	stp	x19, x20, [sp, #16]
    4b1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    4b20:	91150262 	add	x2, x19, #0x540
    4b24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b28:	aa0003f5 	mov	x21, x0
    4b2c:	2a0103f4 	mov	w20, w1
    4b30:	b953a440 	ldr	w0, [x2, #5028]
    4b34:	34000600 	cbz	w0, 4bf4 <fwp_heap_alloc_slow+0xe4>
    4b38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b3c:	54000628 	b.hi	4c00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4b40:	91003ea0 	add	x0, x21, #0xf
    4b44:	91150262 	add	x2, x19, #0x540
    4b48:	f9001bf7 	str	x23, [sp, #48]
    4b4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4b50:	8b401040 	add	x0, x2, x0, lsr #4
    4b54:	cb34c084 	sub	x4, x4, w20, sxtw
    4b58:	d37ae484 	lsl	x4, x4, #6
    4b5c:	397e8003 	ldrb	w3, [x0, #4000]
    4b60:	910f0060 	add	x0, x3, #0x3c0
    4b64:	aa0303e1 	mov	x1, x3
    4b68:	8b030463 	add	x3, x3, x3, lsl #1
    4b6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4b70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4b74:	2a1703f6 	mov	w22, w23
    4b78:	f8636844 	ldr	x4, [x2, x3]
    4b7c:	b40004e4 	cbz	x4, 4c18 <fwp_heap_alloc_slow+0x108>
    4b80:	f9400080 	ldr	x0, [x4]
    4b84:	aa2003e0 	mvn	x0, x0
    4b88:	f8236840 	str	x0, [x2, x3]
    4b8c:	7100069f 	cmp	w20, #0x1
    4b90:	aa0403e0 	mov	x0, x4
    4b94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b98:	52800001 	mov	w1, #0x0                   	// #0
    4b9c:	97fff72d 	bl	2850 <memset@plt>
    4ba0:	aa0003e4 	mov	x4, x0
    4ba4:	91150260 	add	x0, x19, #0x540
    4ba8:	f94a1001 	ldr	x1, [x0, #5152]
    4bac:	ab160021 	adds	x1, x1, x22
    4bb0:	540005c2 	b.cs	4c68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4bb4:	f94a1402 	ldr	x2, [x0, #5160]
    4bb8:	f90a1001 	str	x1, [x0, #5152]
    4bbc:	eb02003f 	cmp	x1, x2
    4bc0:	54000049 	b.ls	4bc8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4bc4:	f90a1401 	str	x1, [x0, #5160]
    4bc8:	91150273 	add	x19, x19, #0x540
    4bcc:	1e6302e1 	ucvtf	d1, w23
    4bd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bd4:	aa0403e0 	mov	x0, x4
    4bd8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4bdc:	f9401bf7 	ldr	x23, [sp, #48]
    4be0:	1e612800 	fadd	d0, d0, d1
    4be4:	fd0a1e60 	str	d0, [x19, #5176]
    4be8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4bf0:	d65f03c0 	ret
    4bf4:	97fffca4 	bl	3e84 <fwp_heap_init>
    4bf8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4bfc:	54fffa29 	b.ls	4b40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4c00:	2a1403e1 	mov	w1, w20
    4c04:	aa1503e0 	mov	x0, x21
    4c08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c14:	17ffff70 	b	49d4 <fwp_heap_alloc_big>
    4c18:	8b030042 	add	x2, x2, x3
    4c1c:	f9400444 	ldr	x4, [x2, #8]
    4c20:	b4000104 	cbz	x4, 4c40 <fwp_heap_alloc_slow+0x130>
    4c24:	f9400840 	ldr	x0, [x2, #16]
    4c28:	cb040000 	sub	x0, x0, x4
    4c2c:	eb16001f 	cmp	x0, x22
    4c30:	54000083 	b.cc	4c40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4c34:	8b160080 	add	x0, x4, x22
    4c38:	f9000440 	str	x0, [x2, #8]
    4c3c:	17ffffd4 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c40:	52800302 	mov	w2, #0x18                  	// #24
    4c44:	52807804 	mov	w4, #0x3c0                 	// #960
    4c48:	91150260 	add	x0, x19, #0x540
    4c4c:	9ba27c23 	umull	x3, w1, w2
    4c50:	2a1403e2 	mov	w2, w20
    4c54:	9b240e84 	smaddl	x4, w20, w4, x3
    4c58:	8b040000 	add	x0, x0, x4
    4c5c:	97fffeb5 	bl	4730 <fwp_heap_refill>
    4c60:	aa0003e4 	mov	x4, x0
    4c64:	17ffffca 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c68:	97fff8f2 	bl	3030 <fwp_heap_oom>
    4c6c:	d503201f 	nop

0000000000004c70 <fwp_heap_alloc>:
    4c70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4c74:	f140101f 	cmp	x0, #0x4, lsl #12
    4c78:	910003fd 	mov	x29, sp
    4c7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    4c84:	91150293 	add	x19, x20, #0x540
    4c88:	b953a662 	ldr	w2, [x19, #5028]
    4c8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c90:	54000640 	b.eq	4d58 <fwp_heap_alloc+0xe8>  // b.none
    4c94:	91003c03 	add	x3, x0, #0xf
    4c98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4ca0:	8b431263 	add	x3, x19, x3, lsr #4
    4ca4:	cb21c042 	sub	x2, x2, w1, sxtw
    4ca8:	d37ae442 	lsl	x2, x2, #6
    4cac:	397e8063 	ldrb	w3, [x3, #4000]
    4cb0:	910f0064 	add	x4, x3, #0x3c0
    4cb4:	8b030463 	add	x3, x3, x3, lsl #1
    4cb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4cbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4cc0:	2a1603f5 	mov	w21, w22
    4cc4:	f8636a64 	ldr	x4, [x19, x3]
    4cc8:	b4000384 	cbz	x4, 4d38 <fwp_heap_alloc+0xc8>
    4ccc:	f9400085 	ldr	x5, [x4]
    4cd0:	7100043f 	cmp	w1, #0x1
    4cd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cd8:	aa0403e0 	mov	x0, x4
    4cdc:	aa2503e5 	mvn	x5, x5
    4ce0:	52800001 	mov	w1, #0x0                   	// #0
    4ce4:	f8236a65 	str	x5, [x19, x3]
    4ce8:	97fff6da 	bl	2850 <memset@plt>
    4cec:	aa0003e4 	mov	x4, x0
    4cf0:	f94a1260 	ldr	x0, [x19, #5152]
    4cf4:	ab150000 	adds	x0, x0, x21
    4cf8:	54000442 	b.cs	4d80 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4cfc:	f94a1661 	ldr	x1, [x19, #5160]
    4d00:	f90a1260 	str	x0, [x19, #5152]
    4d04:	eb01001f 	cmp	x0, x1
    4d08:	54000049 	b.ls	4d10 <fwp_heap_alloc+0xa0>  // b.plast
    4d0c:	f90a1660 	str	x0, [x19, #5160]
    4d10:	91150294 	add	x20, x20, #0x540
    4d14:	1e6302c1 	ucvtf	d1, w22
    4d18:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d1c:	aa0403e0 	mov	x0, x4
    4d20:	fd4a1e80 	ldr	d0, [x20, #5176]
    4d24:	1e612800 	fadd	d0, d0, d1
    4d28:	fd0a1e80 	str	d0, [x20, #5176]
    4d2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d34:	d65f03c0 	ret
    4d38:	8b030263 	add	x3, x19, x3
    4d3c:	f9400464 	ldr	x4, [x3, #8]
    4d40:	b40000a4 	cbz	x4, 4d54 <fwp_heap_alloc+0xe4>
    4d44:	f9400862 	ldr	x2, [x3, #16]
    4d48:	cb040042 	sub	x2, x2, x4
    4d4c:	eb15005f 	cmp	x2, x21
    4d50:	540000a2 	b.cs	4d64 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4d54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d5c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d60:	17ffff6c 	b	4b10 <fwp_heap_alloc_slow>
    4d64:	7100043f 	cmp	w1, #0x1
    4d68:	8b150085 	add	x5, x4, x21
    4d6c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4d70:	52800001 	mov	w1, #0x0                   	// #0
    4d74:	aa0403e0 	mov	x0, x4
    4d78:	f9000465 	str	x5, [x3, #8]
    4d7c:	17ffffdb 	b	4ce8 <fwp_heap_alloc+0x78>
    4d80:	97fff8ac 	bl	3030 <fwp_heap_oom>

0000000000004d84 <fwp_data.part.0.constprop.0>:
    4d84:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d88:	910003fd 	mov	x29, sp
    4d8c:	a90153f3 	stp	x19, x20, [sp, #16]
    4d90:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    4d94:	91150283 	add	x3, x20, #0x540
    4d98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d9c:	aa0103f5 	mov	x21, x1
    4da0:	b953a461 	ldr	w1, [x3, #5028]
    4da4:	a90363f7 	stp	x23, x24, [sp, #48]
    4da8:	2a0003f8 	mov	w24, w0
    4dac:	34000701 	cbz	w1, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4db0:	397e8862 	ldrb	w2, [x3, #4002]
    4db4:	910f0040 	add	x0, x2, #0x3c0
    4db8:	8b020442 	add	x2, x2, x2, lsl #1
    4dbc:	d37df042 	lsl	x2, x2, #3
    4dc0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    4dc4:	2a1703f6 	mov	w22, w23
    4dc8:	f8626873 	ldr	x19, [x3, x2]
    4dcc:	b40004d3 	cbz	x19, 4e64 <fwp_data.part.0.constprop.0+0xe0>
    4dd0:	f9400260 	ldr	x0, [x19]
    4dd4:	aa2003e0 	mvn	x0, x0
    4dd8:	f8226860 	str	x0, [x3, x2]
    4ddc:	f10062df 	cmp	x22, #0x18
    4de0:	540000e9 	b.ls	4dfc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    4de4:	d10066c2 	sub	x2, x22, #0x19
    4de8:	91006260 	add	x0, x19, #0x18
    4dec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    4df0:	52800001 	mov	w1, #0x0                   	// #0
    4df4:	91002042 	add	x2, x2, #0x8
    4df8:	97fff696 	bl	2850 <memset@plt>
    4dfc:	91150282 	add	x2, x20, #0x540
    4e00:	f94a1041 	ldr	x1, [x2, #5152]
    4e04:	ab160021 	adds	x1, x1, x22
    4e08:	540004c2 	b.cs	4ea0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    4e0c:	f94a1440 	ldr	x0, [x2, #5160]
    4e10:	f90a1041 	str	x1, [x2, #5152]
    4e14:	eb00003f 	cmp	x1, x0
    4e18:	54000049 	b.ls	4e20 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    4e1c:	f90a1441 	str	x1, [x2, #5160]
    4e20:	91150294 	add	x20, x20, #0x540
    4e24:	1e6302e1 	ucvtf	d1, w23
    4e28:	fd4a1e80 	ldr	d0, [x20, #5176]
    4e2c:	1e612800 	fadd	d0, d0, d1
    4e30:	fd0a1e80 	str	d0, [x20, #5176]
    4e34:	52800041 	mov	w1, #0x2                   	// #2
    4e38:	29000678 	stp	w24, w1, [x19]
    4e3c:	aa1303e0 	mov	x0, x19
    4e40:	f94002a1 	ldr	x1, [x21]
    4e44:	f9000661 	str	x1, [x19, #8]
    4e48:	f94006a1 	ldr	x1, [x21, #8]
    4e4c:	f9000a61 	str	x1, [x19, #16]
    4e50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e58:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e5c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e60:	d65f03c0 	ret
    4e64:	8b020063 	add	x3, x3, x2
    4e68:	f9400473 	ldr	x19, [x3, #8]
    4e6c:	b4000113 	cbz	x19, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4e70:	f9400860 	ldr	x0, [x3, #16]
    4e74:	cb130000 	sub	x0, x0, x19
    4e78:	eb0002df 	cmp	x22, x0
    4e7c:	54000088 	b.hi	4e8c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    4e80:	8b160260 	add	x0, x19, x22
    4e84:	f9000460 	str	x0, [x3, #8]
    4e88:	17ffffd5 	b	4ddc <fwp_data.part.0.constprop.0+0x58>
    4e8c:	52800001 	mov	w1, #0x0                   	// #0
    4e90:	d2800300 	mov	x0, #0x18                  	// #24
    4e94:	97ffff77 	bl	4c70 <fwp_heap_alloc>
    4e98:	aa0003f3 	mov	x19, x0
    4e9c:	17ffffe6 	b	4e34 <fwp_data.part.0.constprop.0+0xb0>
    4ea0:	97fff864 	bl	3030 <fwp_heap_oom>

0000000000004ea4 <fwp_p_ad_push.constprop.0>:
    4ea4:	f100001f 	cmp	x0, #0x0
    4ea8:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    4eac:	54000e8b 	b.lt	507c <fwp_p_ad_push.constprop.0+0x1d8>  // b.tstop
    4eb0:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    4eb4:	aa0003e4 	mov	x4, x0
    4eb8:	910003fd 	mov	x29, sp
    4ebc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ec0:	aa0003f5 	mov	x21, x0
    4ec4:	aa020000 	orr	x0, x0, x2
    4ec8:	a90363f7 	stp	x23, x24, [sp, #48]
    4ecc:	aa0203f7 	mov	x23, x2
    4ed0:	6d0627e8 	stp	d8, d9, [sp, #96]
    4ed4:	9e670029 	fmov	d9, x1
    4ed8:	9e670068 	fmov	d8, x3
    4edc:	b6f80900 	tbz	x0, #63, 4ffc <fwp_p_ad_push.constprop.0+0x158>
    4ee0:	a90153f3 	stp	x19, x20, [sp, #16]
    4ee4:	9360fc80 	asr	x0, x4, #32
    4ee8:	b6f800c4 	tbz	x4, #63, 4f00 <fwp_p_ad_push.constprop.0+0x5c>
    4eec:	1e604109 	fmov	d9, d8
    4ef0:	2f00e408 	movi	d8, #0x0
    4ef4:	9360fc40 	asr	x0, x2, #32
    4ef8:	aa0203f5 	mov	x21, x2
    4efc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    4f00:	97fffa6c 	bl	38b0 <fwp_tape_of>
    4f04:	aa0003f3 	mov	x19, x0
    4f08:	f9403000 	ldr	x0, [x0, #96]
    4f0c:	b5001280 	cbnz	x0, 515c <fwp_p_ad_push.constprop.0+0x2b8>
    4f10:	f9400a76 	ldr	x22, [x19, #16]
    4f14:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    4f18:	eb0002df 	cmp	x22, x0
    4f1c:	54000e2c 	b.gt	50e0 <fwp_p_ad_push.constprop.0+0x23c>
    4f20:	eb3542df 	cmp	x22, w21, uxtw
    4f24:	54000d4d 	b.le	50cc <fwp_p_ad_push.constprop.0+0x228>
    4f28:	b7f80077 	tbnz	x23, #63, 4f34 <fwp_p_ad_push.constprop.0+0x90>
    4f2c:	eb3742df 	cmp	x22, w23, uxtw
    4f30:	54000ced 	b.le	50cc <fwp_p_ad_push.constprop.0+0x228>
    4f34:	f9400678 	ldr	x24, [x19, #8]
    4f38:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    4f3c:	cb1802d8 	sub	x24, x22, x24
    4f40:	91000701 	add	x1, x24, #0x1
    4f44:	eb00003f 	cmp	x1, x0
    4f48:	54000cc8 	b.hi	50e0 <fwp_p_ad_push.constprop.0+0x23c>  // b.pmore
    4f4c:	a9418274 	ldp	x20, x0, [x19, #24]
    4f50:	a90573fb 	stp	x27, x28, [sp, #80]
    4f54:	eb14003f 	cmp	x1, x20
    4f58:	5400068d 	b.le	5028 <fwp_p_ad_push.constprop.0+0x184>
    4f5c:	f100029f 	cmp	x20, #0x0
    4f60:	d2800803 	mov	x3, #0x40                  	// #64
    4f64:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    4f68:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    4f6c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4f70:	eb14003f 	cmp	x1, x20
    4f74:	5400008d 	b.le	4f84 <fwp_p_ad_push.constprop.0+0xe0>
    4f78:	eb02029f 	cmp	x20, x2
    4f7c:	5400052d 	b.le	5020 <fwp_p_ad_push.constprop.0+0x17c>
    4f80:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    4f84:	d37df299 	lsl	x25, x20, #3
    4f88:	aa1903e1 	mov	x1, x25
    4f8c:	97fff639 	bl	2870 <realloc@plt>
    4f90:	aa0003e1 	mov	x1, x0
    4f94:	b4000b00 	cbz	x0, 50f4 <fwp_p_ad_push.constprop.0+0x250>
    4f98:	f9400e62 	ldr	x2, [x19, #24]
    4f9c:	f9001261 	str	x1, [x19, #32]
    4fa0:	f9401a60 	ldr	x0, [x19, #48]
    4fa4:	d37cee9a 	lsl	x26, x20, #4
    4fa8:	8b020821 	add	x1, x1, x2, lsl #2
    4fac:	f9001661 	str	x1, [x19, #40]
    4fb0:	aa1a03e1 	mov	x1, x26
    4fb4:	97fff62f 	bl	2870 <realloc@plt>
    4fb8:	aa0003e2 	mov	x2, x0
    4fbc:	b40009c0 	cbz	x0, 50f4 <fwp_p_ad_push.constprop.0+0x250>
    4fc0:	f9400e61 	ldr	x1, [x19, #24]
    4fc4:	d37df31b 	lsl	x27, x24, #3
    4fc8:	d37ef685 	lsl	x5, x20, #2
    4fcc:	d37ef71c 	lsl	x28, x24, #2
    4fd0:	8b190004 	add	x4, x0, x25
    4fd4:	8b010c01 	add	x1, x0, x1, lsl #3
    4fd8:	a9030660 	stp	x0, x1, [x19, #48]
    4fdc:	b5000558 	cbnz	x24, 5084 <fwp_p_ad_push.constprop.0+0x1e0>
    4fe0:	f9001e64 	str	x4, [x19, #56]
    4fe4:	f9401260 	ldr	x0, [x19, #32]
    4fe8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4fec:	8b050001 	add	x1, x0, x5
    4ff0:	f9000e74 	str	x20, [x19, #24]
    4ff4:	f9001661 	str	x1, [x19, #40]
    4ff8:	14000010 	b	5038 <fwp_p_ad_push.constprop.0+0x194>
    4ffc:	9360fc40 	asr	x0, x2, #32
    5000:	a90153f3 	stp	x19, x20, [sp, #16]
    5004:	eb84801f 	cmp	x0, x4, asr #32
    5008:	54fff7c0 	b.eq	4f00 <fwp_p_ad_push.constprop.0+0x5c>  // b.none
    500c:	90000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    5010:	913a0000 	add	x0, x0, #0xe80
    5014:	a9046bf9 	stp	x25, x26, [sp, #64]
    5018:	a90573fb 	stp	x27, x28, [sp, #80]
    501c:	97fff959 	bl	3580 <fwp_trap>
    5020:	d37ffa94 	lsl	x20, x20, #1
    5024:	17ffffd3 	b	4f70 <fwp_p_ad_push.constprop.0+0xcc>
    5028:	a9428a61 	ldp	x1, x2, [x19, #40]
    502c:	d37ef71c 	lsl	x28, x24, #2
    5030:	f9401e64 	ldr	x4, [x19, #56]
    5034:	d37df31b 	lsl	x27, x24, #3
    5038:	b83c6815 	str	w21, [x0, x28]
    503c:	f10002ff 	cmp	x23, #0x0
    5040:	da9fa2f7 	csinv	x23, x23, xzr, ge	// ge = tcont
    5044:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5048:	fc3b6849 	str	d9, [x2, x27]
    504c:	aa1602a0 	orr	x0, x21, x22
    5050:	b83c6837 	str	w23, [x1, x28]
    5054:	910006d6 	add	x22, x22, #0x1
    5058:	a94363f7 	ldp	x23, x24, [sp, #48]
    505c:	fc3b6888 	str	d8, [x4, x27]
    5060:	a94573fb 	ldp	x27, x28, [sp, #80]
    5064:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5068:	f9000a76 	str	x22, [x19, #16]
    506c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5070:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5074:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5078:	d65f03c0 	ret
    507c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5080:	d65f03c0 	ret
    5084:	eb1a033f 	cmp	x25, x26
    5088:	aa0403e0 	mov	x0, x4
    508c:	9a9a2323 	csel	x3, x25, x26, cs	// cs = hs, nlast
    5090:	aa1b03e2 	mov	x2, x27
    5094:	cb190063 	sub	x3, x3, x25
    5098:	f9003fe5 	str	x5, [sp, #120]
    509c:	97fff661 	bl	2a20 <__memmove_chk@plt>
    50a0:	a9420660 	ldp	x0, x1, [x19, #32]
    50a4:	aa1c03e2 	mov	x2, x28
    50a8:	f9401a63 	ldr	x3, [x19, #48]
    50ac:	f9403fe5 	ldr	x5, [sp, #120]
    50b0:	8b190063 	add	x3, x3, x25
    50b4:	f9001e63 	str	x3, [x19, #56]
    50b8:	8b050000 	add	x0, x0, x5
    50bc:	97fff58d 	bl	26f0 <memmove@plt>
    50c0:	a9431262 	ldp	x2, x4, [x19, #48]
    50c4:	f9403fe5 	ldr	x5, [sp, #120]
    50c8:	17ffffc7 	b	4fe4 <fwp_p_ad_push.constprop.0+0x140>
    50cc:	90000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    50d0:	913c6000 	add	x0, x0, #0xf18
    50d4:	a9046bf9 	stp	x25, x26, [sp, #64]
    50d8:	a90573fb 	stp	x27, x28, [sp, #80]
    50dc:	97fff929 	bl	3580 <fwp_trap>
    50e0:	90000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    50e4:	913be000 	add	x0, x0, #0xef8
    50e8:	a9046bf9 	stp	x25, x26, [sp, #64]
    50ec:	a90573fb 	stp	x27, x28, [sp, #80]
    50f0:	97fff924 	bl	3580 <fwp_trap>
    50f4:	aa1303e0 	mov	x0, x19
    50f8:	97fff7a6 	bl	2f90 <fwp_tape_unlink_scope>
    50fc:	f9401260 	ldr	x0, [x19, #32]
    5100:	97fff610 	bl	2940 <free@plt>
    5104:	f9401a60 	ldr	x0, [x19, #48]
    5108:	97fff60e 	bl	2940 <free@plt>
    510c:	f9402260 	ldr	x0, [x19, #64]
    5110:	97fff60c 	bl	2940 <free@plt>
    5114:	f9000e7f 	str	xzr, [x19, #24]
    5118:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    511c:	f947e821 	ldr	x1, [x1, #4048]
    5120:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5124:	d2800262 	mov	x2, #0x13                  	// #19
    5128:	4f000400 	movi	v0.4s, #0x0
    512c:	90000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    5130:	f9400023 	ldr	x3, [x1]
    5134:	b900067f 	str	wzr, [x19, #4]
    5138:	d2800021 	mov	x1, #0x1                   	// #1
    513c:	912e6000 	add	x0, x0, #0xb98
    5140:	3c808260 	stur	q0, [x19, #8]
    5144:	ad010260 	stp	q0, q0, [x19, #32]
    5148:	97fff60e 	bl	2980 <fwrite@plt>
    514c:	d2800000 	mov	x0, #0x0                   	// #0
    5150:	97fff618 	bl	29b0 <fflush@plt>
    5154:	52800cc0 	mov	w0, #0x66                  	// #102
    5158:	97fff626 	bl	29f0 <_Exit@plt>
    515c:	90000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    5160:	913b2000 	add	x0, x0, #0xec8
    5164:	a9046bf9 	stp	x25, x26, [sp, #64]
    5168:	a90573fb 	stp	x27, x28, [sp, #80]
    516c:	97fff905 	bl	3580 <fwp_trap>

0000000000005170 <w120>:
    5170:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5174:	9e660003 	fmov	x3, d0
    5178:	aa0003e2 	mov	x2, x0
    517c:	910003fd 	mov	x29, sp
    5180:	6d0327e8 	stp	d8, d9, [sp, #48]
    5184:	1e604028 	fmov	d8, d1
    5188:	1e600809 	fmul	d9, d0, d0
    518c:	fd0023ea 	str	d10, [sp, #64]
    5190:	1e60400a 	fmov	d10, d0
    5194:	a90153f3 	stp	x19, x20, [sp, #16]
    5198:	aa0003f3 	mov	x19, x0
    519c:	aa0103f4 	mov	x20, x1
    51a0:	aa0303e1 	mov	x1, x3
    51a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    51a8:	97ffff3f 	bl	4ea4 <fwp_p_ad_push.constprop.0>
    51ac:	1e693908 	fsub	d8, d8, d9
    51b0:	aa1403e2 	mov	x2, x20
    51b4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    51b8:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    51bc:	9e660116 	fmov	x22, d8
    51c0:	97ffff39 	bl	4ea4 <fwp_p_ad_push.constprop.0>
    51c4:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    51c8:	aa0003e1 	mov	x1, x0
    51cc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    51d0:	aa1303e0 	mov	x0, x19
    51d4:	1e6a3929 	fsub	d9, d9, d10
    51d8:	aa0103f3 	mov	x19, x1
    51dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    51e0:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    51e4:	9e660135 	fmov	x21, d9
    51e8:	97ffff2f 	bl	4ea4 <fwp_p_ad_push.constprop.0>
    51ec:	1e680908 	fmul	d8, d8, d8
    51f0:	aa0003f4 	mov	x20, x0
    51f4:	aa1603e3 	mov	x3, x22
    51f8:	aa1603e1 	mov	x1, x22
    51fc:	aa1303e2 	mov	x2, x19
    5200:	aa1303e0 	mov	x0, x19
    5204:	97ffff28 	bl	4ea4 <fwp_p_ad_push.constprop.0>
    5208:	aa0003e2 	mov	x2, x0
    520c:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5210:	9e670020 	fmov	d0, x1
    5214:	9e660101 	fmov	x1, d8
    5218:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    521c:	1e600908 	fmul	d8, d8, d0
    5220:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5224:	97ffff20 	bl	4ea4 <fwp_p_ad_push.constprop.0>
    5228:	1e690929 	fmul	d9, d9, d9
    522c:	aa0003f3 	mov	x19, x0
    5230:	aa1503e3 	mov	x3, x21
    5234:	aa1503e1 	mov	x1, x21
    5238:	aa1403e2 	mov	x2, x20
    523c:	aa1403e0 	mov	x0, x20
    5240:	97ffff19 	bl	4ea4 <fwp_p_ad_push.constprop.0>
    5244:	1e692908 	fadd	d8, d8, d9
    5248:	aa1303e2 	mov	x2, x19
    524c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5250:	aa0303e1 	mov	x1, x3
    5254:	97ffff14 	bl	4ea4 <fwp_p_ad_push.constprop.0>
    5258:	aa0003e1 	mov	x1, x0
    525c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5260:	9e660100 	fmov	x0, d8
    5264:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5268:	6d4327e8 	ldp	d8, d9, [sp, #48]
    526c:	fd4023ea 	ldr	d10, [sp, #64]
    5270:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5274:	d65f03c0 	ret
    5278:	d503201f 	nop
    527c:	d503201f 	nop

0000000000005280 <w176.constprop.0>:
    5280:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5284:	910003fd 	mov	x29, sp
    5288:	a9025bf5 	stp	x21, x22, [sp, #32]
    528c:	fd001be8 	str	d8, [sp, #48]
    5290:	f9400015 	ldr	x21, [x0]
    5294:	b4000315 	cbz	x21, 52f4 <w176.constprop.0+0x74>
    5298:	2f00e408 	movi	d8, #0x0
    529c:	91002016 	add	x22, x0, #0x8
    52a0:	a90153f3 	stp	x19, x20, [sp, #16]
    52a4:	91004014 	add	x20, x0, #0x10
    52a8:	d2800013 	mov	x19, #0x0                   	// #0
    52ac:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    52b0:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    52b4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    52b8:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    52bc:	aa0303e1 	mov	x1, x3
    52c0:	1e602908 	fadd	d8, d8, d0
    52c4:	91000a73 	add	x19, x19, #0x2
    52c8:	97fffef7 	bl	4ea4 <fwp_p_ad_push.constprop.0>
    52cc:	eb1302bf 	cmp	x21, x19
    52d0:	54ffff08 	b.hi	52b0 <w176.constprop.0+0x30>  // b.pmore
    52d4:	9e660102 	fmov	x2, d8
    52d8:	fd401be8 	ldr	d8, [sp, #48]
    52dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    52e0:	aa0003e1 	mov	x1, x0
    52e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    52e8:	aa0203e0 	mov	x0, x2
    52ec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    52f0:	d65f03c0 	ret
    52f4:	2f00e408 	movi	d8, #0x0
    52f8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    52fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5300:	aa0003e1 	mov	x1, x0
    5304:	9e660102 	fmov	x2, d8
    5308:	fd401be8 	ldr	d8, [sp, #48]
    530c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5310:	aa0203e0 	mov	x0, x2
    5314:	d65f03c0 	ret
    5318:	d503201f 	nop
    531c:	d503201f 	nop

0000000000005320 <fwp_rc_share>:
    5320:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    5324:	91150042 	add	x2, x2, #0x540
    5328:	f949d843 	ldr	x3, [x2, #5040]
    532c:	f949ec41 	ldr	x1, [x2, #5080]
    5330:	cb030000 	sub	x0, x0, x3
    5334:	eb01401f 	cmp	x0, x1, lsl #16
    5338:	540002c2 	b.cs	5390 <fwp_rc_share+0x70>  // b.hs, b.nlast
    533c:	d350fc01 	lsr	x1, x0, #16
    5340:	f949fc44 	ldr	x4, [x2, #5112]
    5344:	8b010821 	add	x1, x1, x1, lsl #2
    5348:	d37df021 	lsl	x1, x1, #3
    534c:	8b010083 	add	x3, x4, x1
    5350:	f9401062 	ldr	x2, [x3, #32]
    5354:	b40001e2 	cbz	x2, 5390 <fwp_rc_share+0x70>
    5358:	38616881 	ldrb	w1, [x4, x1]
    535c:	7100083f 	cmp	w1, #0x2
    5360:	540001a0 	b.eq	5394 <fwp_rc_share+0x74>  // b.none
    5364:	7100043f 	cmp	w1, #0x1
    5368:	54000141 	b.ne	5390 <fwp_rc_share+0x70>  // b.any
    536c:	29430464 	ldp	w4, w1, [x3, #24]
    5370:	92403c00 	and	x0, x0, #0xffff
    5374:	9b047c00 	mul	x0, x0, x4
    5378:	d360fc00 	lsr	x0, x0, #32
    537c:	eb01001f 	cmp	x0, x1
    5380:	54000082 	b.cs	5390 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5384:	8b000042 	add	x2, x2, x0
    5388:	39400040 	ldrb	w0, [x2]
    538c:	350000a0 	cbnz	w0, 53a0 <fwp_rc_share+0x80>
    5390:	d65f03c0 	ret
    5394:	72003c1f 	tst	w0, #0xffff
    5398:	54ffff80 	b.eq	5388 <fwp_rc_share+0x68>  // b.none
    539c:	d65f03c0 	ret
    53a0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    53a4:	90000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    53a8:	913ce000 	add	x0, x0, #0xf38
    53ac:	910003fd 	mov	x29, sp
    53b0:	97fff874 	bl	3580 <fwp_trap>

00000000000053b4 <fwp_rc_fresh>:
    53b4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    53b8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    53bc:	91150063 	add	x3, x3, #0x540
    53c0:	910003fd 	mov	x29, sp
    53c4:	a90153f3 	stp	x19, x20, [sp, #16]
    53c8:	aa0003f3 	mov	x19, x0
    53cc:	f949d861 	ldr	x1, [x3, #5040]
    53d0:	f949ec60 	ldr	x0, [x3, #5080]
    53d4:	cb010261 	sub	x1, x19, x1
    53d8:	eb00403f 	cmp	x1, x0, lsl #16
    53dc:	54000322 	b.cs	5440 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    53e0:	d350fc22 	lsr	x2, x1, #16
    53e4:	f949fc63 	ldr	x3, [x3, #5112]
    53e8:	8b020842 	add	x2, x2, x2, lsl #2
    53ec:	d37df042 	lsl	x2, x2, #3
    53f0:	8b020060 	add	x0, x3, x2
    53f4:	f9401014 	ldr	x20, [x0, #32]
    53f8:	b4000254 	cbz	x20, 5440 <fwp_rc_fresh+0x8c>
    53fc:	38626862 	ldrb	w2, [x3, x2]
    5400:	7100085f 	cmp	w2, #0x2
    5404:	54000260 	b.eq	5450 <fwp_rc_fresh+0x9c>  // b.none
    5408:	7100045f 	cmp	w2, #0x1
    540c:	540001a1 	b.ne	5440 <fwp_rc_fresh+0x8c>  // b.any
    5410:	29430002 	ldp	w2, w0, [x0, #24]
    5414:	92403c21 	and	x1, x1, #0xffff
    5418:	9b027c21 	mul	x1, x1, x2
    541c:	d360fc21 	lsr	x1, x1, #32
    5420:	eb00003f 	cmp	x1, x0
    5424:	540000e2 	b.cs	5440 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5428:	8b010294 	add	x20, x20, x1
    542c:	39400280 	ldrb	w0, [x20]
    5430:	7103fc1f 	cmp	w0, #0xff
    5434:	540001a0 	b.eq	5468 <fwp_rc_fresh+0xb4>  // b.none
    5438:	52800020 	mov	w0, #0x1                   	// #1
    543c:	39000280 	strb	w0, [x20]
    5440:	aa1303e0 	mov	x0, x19
    5444:	a94153f3 	ldp	x19, x20, [sp, #16]
    5448:	a8c27bfd 	ldp	x29, x30, [sp], #32
    544c:	d65f03c0 	ret
    5450:	72003c3f 	tst	w1, #0xffff
    5454:	54fffec0 	b.eq	542c <fwp_rc_fresh+0x78>  // b.none
    5458:	aa1303e0 	mov	x0, x19
    545c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5460:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5464:	d65f03c0 	ret
    5468:	aa1403e0 	mov	x0, x20
    546c:	97fffc41 	bl	4570 <fwp_rc_forget_slot>
    5470:	17fffff2 	b	5438 <fwp_rc_fresh+0x84>

0000000000005474 <fwp_rc_free_arr>:
    5474:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    5478:	91150063 	add	x3, x3, #0x540
    547c:	f949d861 	ldr	x1, [x3, #5040]
    5480:	f949ec62 	ldr	x2, [x3, #5080]
    5484:	cb010001 	sub	x1, x0, x1
    5488:	eb02403f 	cmp	x1, x2, lsl #16
    548c:	54000342 	b.cs	54f4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5490:	d350fc22 	lsr	x2, x1, #16
    5494:	f949fc65 	ldr	x5, [x3, #5112]
    5498:	8b020842 	add	x2, x2, x2, lsl #2
    549c:	d37df042 	lsl	x2, x2, #3
    54a0:	8b0200a4 	add	x4, x5, x2
    54a4:	f9401083 	ldr	x3, [x4, #32]
    54a8:	b4000263 	cbz	x3, 54f4 <fwp_rc_free_arr+0x80>
    54ac:	386268a2 	ldrb	w2, [x5, x2]
    54b0:	7100085f 	cmp	w2, #0x2
    54b4:	540001c0 	b.eq	54ec <fwp_rc_free_arr+0x78>  // b.none
    54b8:	7100045f 	cmp	w2, #0x1
    54bc:	540001c1 	b.ne	54f4 <fwp_rc_free_arr+0x80>  // b.any
    54c0:	29430885 	ldp	w5, w2, [x4, #24]
    54c4:	92403c21 	and	x1, x1, #0xffff
    54c8:	9b057c21 	mul	x1, x1, x5
    54cc:	d360fc21 	lsr	x1, x1, #32
    54d0:	eb02003f 	cmp	x1, x2
    54d4:	54000102 	b.cs	54f4 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    54d8:	8b010063 	add	x3, x3, x1
    54dc:	39400061 	ldrb	w1, [x3]
    54e0:	7100043f 	cmp	w1, #0x1
    54e4:	54000081 	b.ne	54f4 <fwp_rc_free_arr+0x80>  // b.any
    54e8:	17fffcc2 	b	47f0 <fwp_mem_free>
    54ec:	72003c3f 	tst	w1, #0xffff
    54f0:	54ffff60 	b.eq	54dc <fwp_rc_free_arr+0x68>  // b.none
    54f4:	d65f03c0 	ret
    54f8:	d503201f 	nop
    54fc:	d503201f 	nop

0000000000005500 <fwp_rc_dup>:
    5500:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    5504:	91150042 	add	x2, x2, #0x540
    5508:	f949d841 	ldr	x1, [x2, #5040]
    550c:	f949ec43 	ldr	x3, [x2, #5080]
    5510:	cb010001 	sub	x1, x0, x1
    5514:	eb03403f 	cmp	x1, x3, lsl #16
    5518:	54000342 	b.cs	5580 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    551c:	d350fc20 	lsr	x0, x1, #16
    5520:	f949fc44 	ldr	x4, [x2, #5112]
    5524:	8b000800 	add	x0, x0, x0, lsl #2
    5528:	d37df002 	lsl	x2, x0, #3
    552c:	8b020083 	add	x3, x4, x2
    5530:	f9401060 	ldr	x0, [x3, #32]
    5534:	b4000260 	cbz	x0, 5580 <fwp_rc_dup+0x80>
    5538:	38626882 	ldrb	w2, [x4, x2]
    553c:	7100085f 	cmp	w2, #0x2
    5540:	54000220 	b.eq	5584 <fwp_rc_dup+0x84>  // b.none
    5544:	7100045f 	cmp	w2, #0x1
    5548:	540001c1 	b.ne	5580 <fwp_rc_dup+0x80>  // b.any
    554c:	29430864 	ldp	w4, w2, [x3, #24]
    5550:	92403c21 	and	x1, x1, #0xffff
    5554:	9b047c21 	mul	x1, x1, x4
    5558:	d360fc21 	lsr	x1, x1, #32
    555c:	eb02003f 	cmp	x1, x2
    5560:	54000102 	b.cs	5580 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5564:	8b010000 	add	x0, x0, x1
    5568:	39400001 	ldrb	w1, [x0]
    556c:	340000a1 	cbz	w1, 5580 <fwp_rc_dup+0x80>
    5570:	7103f43f 	cmp	w1, #0xfd
    5574:	540000e8 	b.hi	5590 <fwp_rc_dup+0x90>  // b.pmore
    5578:	11000421 	add	w1, w1, #0x1
    557c:	39000001 	strb	w1, [x0]
    5580:	d65f03c0 	ret
    5584:	72003c3f 	tst	w1, #0xffff
    5588:	54ffff00 	b.eq	5568 <fwp_rc_dup+0x68>  // b.none
    558c:	d65f03c0 	ret
    5590:	17fffbb1 	b	4454 <fwp_rc_wide_dup>

0000000000005594 <fwp_owned_entry173>:
    5594:	d10103ff 	sub	sp, sp, #0x40
    5598:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    559c:	f947f442 	ldr	x2, [x2, #4072]
    55a0:	a9027bfd 	stp	x29, x30, [sp, #32]
    55a4:	910083fd 	add	x29, sp, #0x20
    55a8:	a90353f3 	stp	x19, x20, [sp, #48]
    55ac:	f9400043 	ldr	x3, [x2]
    55b0:	f9000fe3 	str	x3, [sp, #24]
    55b4:	d2800003 	mov	x3, #0x0                   	// #0
    55b8:	a9400c01 	ldp	x1, x3, [x0]
    55bc:	f9400802 	ldr	x2, [x0, #16]
    55c0:	ab020022 	adds	x2, x1, x2
    55c4:	540006e6 	b.vs	56a0 <fwp_owned_entry173+0x10c>
    55c8:	910023e1 	add	x1, sp, #0x8
    55cc:	52800000 	mov	w0, #0x0                   	// #0
    55d0:	a9008be3 	stp	x3, x2, [sp, #8]
    55d4:	97fffdec 	bl	4d84 <fwp_data.part.0.constprop.0>
    55d8:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    55dc:	91150063 	add	x3, x3, #0x540
    55e0:	aa0003f3 	mov	x19, x0
    55e4:	f949d861 	ldr	x1, [x3, #5040]
    55e8:	f949ec60 	ldr	x0, [x3, #5080]
    55ec:	cb010261 	sub	x1, x19, x1
    55f0:	eb00403f 	cmp	x1, x0, lsl #16
    55f4:	54000322 	b.cs	5658 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    55f8:	d350fc22 	lsr	x2, x1, #16
    55fc:	f949fc63 	ldr	x3, [x3, #5112]
    5600:	8b020842 	add	x2, x2, x2, lsl #2
    5604:	d37df042 	lsl	x2, x2, #3
    5608:	8b020060 	add	x0, x3, x2
    560c:	f9401014 	ldr	x20, [x0, #32]
    5610:	b4000254 	cbz	x20, 5658 <fwp_owned_entry173+0xc4>
    5614:	38626862 	ldrb	w2, [x3, x2]
    5618:	7100085f 	cmp	w2, #0x2
    561c:	54000360 	b.eq	5688 <fwp_owned_entry173+0xf4>  // b.none
    5620:	7100045f 	cmp	w2, #0x1
    5624:	540001a1 	b.ne	5658 <fwp_owned_entry173+0xc4>  // b.any
    5628:	29430002 	ldp	w2, w0, [x0, #24]
    562c:	92403c21 	and	x1, x1, #0xffff
    5630:	9b027c21 	mul	x1, x1, x2
    5634:	d360fc21 	lsr	x1, x1, #32
    5638:	eb00003f 	cmp	x1, x0
    563c:	540000e2 	b.cs	5658 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5640:	8b010294 	add	x20, x20, x1
    5644:	39400280 	ldrb	w0, [x20]
    5648:	7103fc1f 	cmp	w0, #0xff
    564c:	54000240 	b.eq	5694 <fwp_owned_entry173+0x100>  // b.none
    5650:	52800020 	mov	w0, #0x1                   	// #1
    5654:	39000280 	strb	w0, [x20]
    5658:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    565c:	f947f400 	ldr	x0, [x0, #4072]
    5660:	f9400fe2 	ldr	x2, [sp, #24]
    5664:	f9400001 	ldr	x1, [x0]
    5668:	eb010042 	subs	x2, x2, x1
    566c:	d2800001 	mov	x1, #0x0                   	// #0
    5670:	540001a1 	b.ne	56a4 <fwp_owned_entry173+0x110>  // b.any
    5674:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5678:	aa1303e0 	mov	x0, x19
    567c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5680:	910103ff 	add	sp, sp, #0x40
    5684:	d65f03c0 	ret
    5688:	72003c3f 	tst	w1, #0xffff
    568c:	54fffe61 	b.ne	5658 <fwp_owned_entry173+0xc4>  // b.any
    5690:	17ffffed 	b	5644 <fwp_owned_entry173+0xb0>
    5694:	aa1403e0 	mov	x0, x20
    5698:	97fffbb6 	bl	4570 <fwp_rc_forget_slot>
    569c:	17ffffed 	b	5650 <fwp_owned_entry173+0xbc>
    56a0:	97fff4f8 	bl	2a80 <fwp_trap_overflow.constprop.0>
    56a4:	97fff477 	bl	2880 <__stack_chk_fail@plt>
    56a8:	d503201f 	nop
    56ac:	d503201f 	nop

00000000000056b0 <e173>:
    56b0:	d10103ff 	sub	sp, sp, #0x40
    56b4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    56b8:	f947f442 	ldr	x2, [x2, #4072]
    56bc:	a9027bfd 	stp	x29, x30, [sp, #32]
    56c0:	910083fd 	add	x29, sp, #0x20
    56c4:	a90353f3 	stp	x19, x20, [sp, #48]
    56c8:	f9400043 	ldr	x3, [x2]
    56cc:	f9000fe3 	str	x3, [sp, #24]
    56d0:	d2800003 	mov	x3, #0x0                   	// #0
    56d4:	a9400c01 	ldp	x1, x3, [x0]
    56d8:	f9400802 	ldr	x2, [x0, #16]
    56dc:	ab020022 	adds	x2, x1, x2
    56e0:	54000726 	b.vs	57c4 <e173+0x114>
    56e4:	910023e1 	add	x1, sp, #0x8
    56e8:	52800000 	mov	w0, #0x0                   	// #0
    56ec:	a9008be3 	stp	x3, x2, [sp, #8]
    56f0:	97fffda5 	bl	4d84 <fwp_data.part.0.constprop.0>
    56f4:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    56f8:	91150063 	add	x3, x3, #0x540
    56fc:	aa0003f3 	mov	x19, x0
    5700:	f949d861 	ldr	x1, [x3, #5040]
    5704:	f949ec60 	ldr	x0, [x3, #5080]
    5708:	cb010261 	sub	x1, x19, x1
    570c:	eb00403f 	cmp	x1, x0, lsl #16
    5710:	54000322 	b.cs	5774 <e173+0xc4>  // b.hs, b.nlast
    5714:	d350fc22 	lsr	x2, x1, #16
    5718:	f949fc63 	ldr	x3, [x3, #5112]
    571c:	8b020842 	add	x2, x2, x2, lsl #2
    5720:	d37df042 	lsl	x2, x2, #3
    5724:	8b020060 	add	x0, x3, x2
    5728:	f9401014 	ldr	x20, [x0, #32]
    572c:	b4000254 	cbz	x20, 5774 <e173+0xc4>
    5730:	38626862 	ldrb	w2, [x3, x2]
    5734:	7100085f 	cmp	w2, #0x2
    5738:	540003a0 	b.eq	57ac <e173+0xfc>  // b.none
    573c:	7100045f 	cmp	w2, #0x1
    5740:	540001a1 	b.ne	5774 <e173+0xc4>  // b.any
    5744:	29430002 	ldp	w2, w0, [x0, #24]
    5748:	92403c21 	and	x1, x1, #0xffff
    574c:	9b027c21 	mul	x1, x1, x2
    5750:	d360fc21 	lsr	x1, x1, #32
    5754:	eb00003f 	cmp	x1, x0
    5758:	540000e2 	b.cs	5774 <e173+0xc4>  // b.hs, b.nlast
    575c:	8b010294 	add	x20, x20, x1
    5760:	39400280 	ldrb	w0, [x20]
    5764:	7103fc1f 	cmp	w0, #0xff
    5768:	54000280 	b.eq	57b8 <e173+0x108>  // b.none
    576c:	52800020 	mov	w0, #0x1                   	// #1
    5770:	39000280 	strb	w0, [x20]
    5774:	aa1303e0 	mov	x0, x19
    5778:	97fffeea 	bl	5320 <fwp_rc_share>
    577c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5780:	f947f400 	ldr	x0, [x0, #4072]
    5784:	f9400fe2 	ldr	x2, [sp, #24]
    5788:	f9400001 	ldr	x1, [x0]
    578c:	eb010042 	subs	x2, x2, x1
    5790:	d2800001 	mov	x1, #0x0                   	// #0
    5794:	540001a1 	b.ne	57c8 <e173+0x118>  // b.any
    5798:	a9427bfd 	ldp	x29, x30, [sp, #32]
    579c:	aa1303e0 	mov	x0, x19
    57a0:	a94353f3 	ldp	x19, x20, [sp, #48]
    57a4:	910103ff 	add	sp, sp, #0x40
    57a8:	d65f03c0 	ret
    57ac:	72003c3f 	tst	w1, #0xffff
    57b0:	54fffe21 	b.ne	5774 <e173+0xc4>  // b.any
    57b4:	17ffffeb 	b	5760 <e173+0xb0>
    57b8:	aa1403e0 	mov	x0, x20
    57bc:	97fffb6d 	bl	4570 <fwp_rc_forget_slot>
    57c0:	17ffffeb 	b	576c <e173+0xbc>
    57c4:	97fff4af 	bl	2a80 <fwp_trap_overflow.constprop.0>
    57c8:	97fff42e 	bl	2880 <__stack_chk_fail@plt>
    57cc:	d503201f 	nop

00000000000057d0 <fwp_drop1>:
    57d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    57d4:	910003fd 	mov	x29, sp
    57d8:	a90153f3 	stp	x19, x20, [sp, #16]
    57dc:	f90013f5 	str	x21, [sp, #32]
    57e0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    57e4:	911502b4 	add	x20, x21, #0x540
    57e8:	f949da81 	ldr	x1, [x20, #5040]
    57ec:	f949ee82 	ldr	x2, [x20, #5080]
    57f0:	cb010001 	sub	x1, x0, x1
    57f4:	eb02403f 	cmp	x1, x2, lsl #16
    57f8:	54000382 	b.cs	5868 <fwp_drop1+0x98>  // b.hs, b.nlast
    57fc:	d350fc22 	lsr	x2, x1, #16
    5800:	f949fe84 	ldr	x4, [x20, #5112]
    5804:	8b020842 	add	x2, x2, x2, lsl #2
    5808:	d37df042 	lsl	x2, x2, #3
    580c:	8b020083 	add	x3, x4, x2
    5810:	f9401073 	ldr	x19, [x3, #32]
    5814:	b40002b3 	cbz	x19, 5868 <fwp_drop1+0x98>
    5818:	38626882 	ldrb	w2, [x4, x2]
    581c:	7100085f 	cmp	w2, #0x2
    5820:	540002c0 	b.eq	5878 <fwp_drop1+0xa8>  // b.none
    5824:	7100045f 	cmp	w2, #0x1
    5828:	54000201 	b.ne	5868 <fwp_drop1+0x98>  // b.any
    582c:	29430864 	ldp	w4, w2, [x3, #24]
    5830:	92403c21 	and	x1, x1, #0xffff
    5834:	9b047c21 	mul	x1, x1, x4
    5838:	d360fc21 	lsr	x1, x1, #32
    583c:	eb02003f 	cmp	x1, x2
    5840:	54000142 	b.cs	5868 <fwp_drop1+0x98>  // b.hs, b.nlast
    5844:	8b010273 	add	x19, x19, x1
    5848:	39400261 	ldrb	w1, [x19]
    584c:	340000e1 	cbz	w1, 5868 <fwp_drop1+0x98>
    5850:	7100043f 	cmp	w1, #0x1
    5854:	540001e0 	b.eq	5890 <fwp_drop1+0xc0>  // b.none
    5858:	7103fc3f 	cmp	w1, #0xff
    585c:	540002e0 	b.eq	58b8 <fwp_drop1+0xe8>  // b.none
    5860:	51000421 	sub	w1, w1, #0x1
    5864:	39000261 	strb	w1, [x19]
    5868:	a94153f3 	ldp	x19, x20, [sp, #16]
    586c:	f94013f5 	ldr	x21, [sp, #32]
    5870:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5874:	d65f03c0 	ret
    5878:	72003c3f 	tst	w1, #0xffff
    587c:	54fffe60 	b.eq	5848 <fwp_drop1+0x78>  // b.none
    5880:	a94153f3 	ldp	x19, x20, [sp, #16]
    5884:	f94013f5 	ldr	x21, [sp, #32]
    5888:	a8c37bfd 	ldp	x29, x30, [sp], #48
    588c:	d65f03c0 	ret
    5890:	f9400813 	ldr	x19, [x0, #16]
    5894:	97fffef8 	bl	5474 <fwp_rc_free_arr>
    5898:	911502a0 	add	x0, x21, #0x540
    589c:	f949d801 	ldr	x1, [x0, #5040]
    58a0:	f949ec00 	ldr	x0, [x0, #5080]
    58a4:	cb010261 	sub	x1, x19, x1
    58a8:	eb00403f 	cmp	x1, x0, lsl #16
    58ac:	54fffde2 	b.cs	5868 <fwp_drop1+0x98>  // b.hs, b.nlast
    58b0:	aa1303e0 	mov	x0, x19
    58b4:	17ffffd2 	b	57fc <fwp_drop1+0x2c>
    58b8:	ca534660 	eor	x0, x19, x19, lsr #17
    58bc:	911502b5 	add	x21, x21, #0x540
    58c0:	ca402400 	eor	x0, x0, x0, lsr #9
    58c4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    58c8:	f94a2400 	ldr	x0, [x0, #5192]
    58cc:	b5000080 	cbnz	x0, 58dc <fwp_drop1+0x10c>
    58d0:	14000010 	b	5910 <fwp_drop1+0x140>
    58d4:	f9400800 	ldr	x0, [x0, #16]
    58d8:	b40001c0 	cbz	x0, 5910 <fwp_drop1+0x140>
    58dc:	f9400001 	ldr	x1, [x0]
    58e0:	eb13003f 	cmp	x1, x19
    58e4:	54ffff81 	b.ne	58d4 <fwp_drop1+0x104>  // b.any
    58e8:	f9400401 	ldr	x1, [x0, #8]
    58ec:	d1000421 	sub	x1, x1, #0x1
    58f0:	f9000401 	str	x1, [x0, #8]
    58f4:	f103f83f 	cmp	x1, #0xfe
    58f8:	54fffb81 	b.ne	5868 <fwp_drop1+0x98>  // b.any
    58fc:	aa1303e0 	mov	x0, x19
    5900:	97fffb1c 	bl	4570 <fwp_rc_forget_slot>
    5904:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5908:	39000260 	strb	w0, [x19]
    590c:	17ffffd7 	b	5868 <fwp_drop1+0x98>
    5910:	90000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    5914:	9138e000 	add	x0, x0, #0xe38
    5918:	97fff71a 	bl	3580 <fwp_trap>
    591c:	d503201f 	nop

0000000000005920 <fwp_drop0>:
    5920:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5924:	910003fd 	mov	x29, sp
    5928:	a90153f3 	stp	x19, x20, [sp, #16]
    592c:	f90013f5 	str	x21, [sp, #32]
    5930:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    5934:	911502b4 	add	x20, x21, #0x540
    5938:	f949da81 	ldr	x1, [x20, #5040]
    593c:	f949ee82 	ldr	x2, [x20, #5080]
    5940:	cb010001 	sub	x1, x0, x1
    5944:	eb02403f 	cmp	x1, x2, lsl #16
    5948:	54000382 	b.cs	59b8 <fwp_drop0+0x98>  // b.hs, b.nlast
    594c:	d350fc22 	lsr	x2, x1, #16
    5950:	f949fe84 	ldr	x4, [x20, #5112]
    5954:	8b020842 	add	x2, x2, x2, lsl #2
    5958:	d37df042 	lsl	x2, x2, #3
    595c:	8b020083 	add	x3, x4, x2
    5960:	f9401073 	ldr	x19, [x3, #32]
    5964:	b40002b3 	cbz	x19, 59b8 <fwp_drop0+0x98>
    5968:	38626882 	ldrb	w2, [x4, x2]
    596c:	7100085f 	cmp	w2, #0x2
    5970:	540002c0 	b.eq	59c8 <fwp_drop0+0xa8>  // b.none
    5974:	7100045f 	cmp	w2, #0x1
    5978:	54000201 	b.ne	59b8 <fwp_drop0+0x98>  // b.any
    597c:	29430864 	ldp	w4, w2, [x3, #24]
    5980:	92403c21 	and	x1, x1, #0xffff
    5984:	9b047c21 	mul	x1, x1, x4
    5988:	d360fc21 	lsr	x1, x1, #32
    598c:	eb02003f 	cmp	x1, x2
    5990:	54000142 	b.cs	59b8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5994:	8b010273 	add	x19, x19, x1
    5998:	39400261 	ldrb	w1, [x19]
    599c:	340000e1 	cbz	w1, 59b8 <fwp_drop0+0x98>
    59a0:	7100043f 	cmp	w1, #0x1
    59a4:	540001e0 	b.eq	59e0 <fwp_drop0+0xc0>  // b.none
    59a8:	7103fc3f 	cmp	w1, #0xff
    59ac:	540002e0 	b.eq	5a08 <fwp_drop0+0xe8>  // b.none
    59b0:	51000421 	sub	w1, w1, #0x1
    59b4:	39000261 	strb	w1, [x19]
    59b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    59bc:	f94013f5 	ldr	x21, [sp, #32]
    59c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    59c4:	d65f03c0 	ret
    59c8:	72003c3f 	tst	w1, #0xffff
    59cc:	54fffe60 	b.eq	5998 <fwp_drop0+0x78>  // b.none
    59d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    59d4:	f94013f5 	ldr	x21, [sp, #32]
    59d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    59dc:	d65f03c0 	ret
    59e0:	f9400813 	ldr	x19, [x0, #16]
    59e4:	97fffea4 	bl	5474 <fwp_rc_free_arr>
    59e8:	911502a0 	add	x0, x21, #0x540
    59ec:	f949d801 	ldr	x1, [x0, #5040]
    59f0:	f949ec00 	ldr	x0, [x0, #5080]
    59f4:	cb010261 	sub	x1, x19, x1
    59f8:	eb00403f 	cmp	x1, x0, lsl #16
    59fc:	54fffde2 	b.cs	59b8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5a00:	aa1303e0 	mov	x0, x19
    5a04:	17ffffd2 	b	594c <fwp_drop0+0x2c>
    5a08:	ca534660 	eor	x0, x19, x19, lsr #17
    5a0c:	911502b5 	add	x21, x21, #0x540
    5a10:	ca402400 	eor	x0, x0, x0, lsr #9
    5a14:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5a18:	f94a2400 	ldr	x0, [x0, #5192]
    5a1c:	b5000080 	cbnz	x0, 5a2c <fwp_drop0+0x10c>
    5a20:	14000010 	b	5a60 <fwp_drop0+0x140>
    5a24:	f9400800 	ldr	x0, [x0, #16]
    5a28:	b40001c0 	cbz	x0, 5a60 <fwp_drop0+0x140>
    5a2c:	f9400001 	ldr	x1, [x0]
    5a30:	eb13003f 	cmp	x1, x19
    5a34:	54ffff81 	b.ne	5a24 <fwp_drop0+0x104>  // b.any
    5a38:	f9400401 	ldr	x1, [x0, #8]
    5a3c:	d1000421 	sub	x1, x1, #0x1
    5a40:	f9000401 	str	x1, [x0, #8]
    5a44:	f103f83f 	cmp	x1, #0xfe
    5a48:	54fffb81 	b.ne	59b8 <fwp_drop0+0x98>  // b.any
    5a4c:	aa1303e0 	mov	x0, x19
    5a50:	97fffac8 	bl	4570 <fwp_rc_forget_slot>
    5a54:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5a58:	39000260 	strb	w0, [x19]
    5a5c:	17ffffd7 	b	59b8 <fwp_drop0+0x98>
    5a60:	90000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    5a64:	9138e000 	add	x0, x0, #0xe38
    5a68:	97fff6c6 	bl	3580 <fwp_trap>
    5a6c:	d503201f 	nop

0000000000005a70 <fwp_closure_drop>:
    5a70:	90000165 	adrp	x5, 31000 <fwp_root_context+0xca0>
    5a74:	911500a4 	add	x4, x5, #0x540
    5a78:	aa0003e1 	mov	x1, x0
    5a7c:	f949d882 	ldr	x2, [x4, #5040]
    5a80:	f949ec80 	ldr	x0, [x4, #5080]
    5a84:	cb020022 	sub	x2, x1, x2
    5a88:	eb00405f 	cmp	x2, x0, lsl #16
    5a8c:	54000662 	b.cs	5b58 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5a90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5a94:	d350fc43 	lsr	x3, x2, #16
    5a98:	910003fd 	mov	x29, sp
    5a9c:	8b030863 	add	x3, x3, x3, lsl #2
    5aa0:	f949fc84 	ldr	x4, [x4, #5112]
    5aa4:	d37df063 	lsl	x3, x3, #3
    5aa8:	f9000bf3 	str	x19, [sp, #16]
    5aac:	8b030080 	add	x0, x4, x3
    5ab0:	f9401013 	ldr	x19, [x0, #32]
    5ab4:	b40002b3 	cbz	x19, 5b08 <fwp_closure_drop+0x98>
    5ab8:	38636883 	ldrb	w3, [x4, x3]
    5abc:	7100087f 	cmp	w3, #0x2
    5ac0:	54000420 	b.eq	5b44 <fwp_closure_drop+0xd4>  // b.none
    5ac4:	7100047f 	cmp	w3, #0x1
    5ac8:	54000201 	b.ne	5b08 <fwp_closure_drop+0x98>  // b.any
    5acc:	29430003 	ldp	w3, w0, [x0, #24]
    5ad0:	92403c42 	and	x2, x2, #0xffff
    5ad4:	9b037c42 	mul	x2, x2, x3
    5ad8:	d360fc42 	lsr	x2, x2, #32
    5adc:	eb00005f 	cmp	x2, x0
    5ae0:	54000142 	b.cs	5b08 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5ae4:	8b020273 	add	x19, x19, x2
    5ae8:	39400260 	ldrb	w0, [x19]
    5aec:	340000e0 	cbz	w0, 5b08 <fwp_closure_drop+0x98>
    5af0:	7100041f 	cmp	w0, #0x1
    5af4:	54000100 	b.eq	5b14 <fwp_closure_drop+0xa4>  // b.none
    5af8:	7103fc1f 	cmp	w0, #0xff
    5afc:	54000300 	b.eq	5b5c <fwp_closure_drop+0xec>  // b.none
    5b00:	51000400 	sub	w0, w0, #0x1
    5b04:	39000260 	strb	w0, [x19]
    5b08:	f9400bf3 	ldr	x19, [sp, #16]
    5b0c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b10:	d65f03c0 	ret
    5b14:	d53bd040 	mrs	x0, tpidr_el0
    5b18:	91400000 	add	x0, x0, #0x0, lsl #12
    5b1c:	91004000 	add	x0, x0, #0x10
    5b20:	f9400000 	ldr	x0, [x0]
    5b24:	b4000080 	cbz	x0, 5b34 <fwp_closure_drop+0xc4>
    5b28:	f9400bf3 	ldr	x19, [sp, #16]
    5b2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b30:	17fff6ad 	b	35e4 <fwp_closure_drop_push>
    5b34:	f9400bf3 	ldr	x19, [sp, #16]
    5b38:	aa0103e0 	mov	x0, x1
    5b3c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b40:	17fff718 	b	37a0 <fwp_closure_drop.part.0>
    5b44:	72003c5f 	tst	w2, #0xffff
    5b48:	54fffd00 	b.eq	5ae8 <fwp_closure_drop+0x78>  // b.none
    5b4c:	f9400bf3 	ldr	x19, [sp, #16]
    5b50:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b54:	d65f03c0 	ret
    5b58:	d65f03c0 	ret
    5b5c:	ca534660 	eor	x0, x19, x19, lsr #17
    5b60:	911500a5 	add	x5, x5, #0x540
    5b64:	ca402400 	eor	x0, x0, x0, lsr #9
    5b68:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5b6c:	f94a2400 	ldr	x0, [x0, #5192]
    5b70:	b5000080 	cbnz	x0, 5b80 <fwp_closure_drop+0x110>
    5b74:	14000010 	b	5bb4 <fwp_closure_drop+0x144>
    5b78:	f9400800 	ldr	x0, [x0, #16]
    5b7c:	b40001c0 	cbz	x0, 5bb4 <fwp_closure_drop+0x144>
    5b80:	f9400001 	ldr	x1, [x0]
    5b84:	eb13003f 	cmp	x1, x19
    5b88:	54ffff81 	b.ne	5b78 <fwp_closure_drop+0x108>  // b.any
    5b8c:	f9400401 	ldr	x1, [x0, #8]
    5b90:	d1000421 	sub	x1, x1, #0x1
    5b94:	f9000401 	str	x1, [x0, #8]
    5b98:	f103f83f 	cmp	x1, #0xfe
    5b9c:	54fffb61 	b.ne	5b08 <fwp_closure_drop+0x98>  // b.any
    5ba0:	aa1303e0 	mov	x0, x19
    5ba4:	97fffa73 	bl	4570 <fwp_rc_forget_slot>
    5ba8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5bac:	39000260 	strb	w0, [x19]
    5bb0:	17ffffd6 	b	5b08 <fwp_closure_drop+0x98>
    5bb4:	90000040 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    5bb8:	9138e000 	add	x0, x0, #0xe38
    5bbc:	97fff671 	bl	3580 <fwp_trap>

0000000000005bc0 <fwp_owned_tape_release>:
    5bc0:	b4000940 	cbz	x0, 5ce8 <fwp_owned_tape_release+0x128>
    5bc4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5bc8:	910003fd 	mov	x29, sp
    5bcc:	a90153f3 	stp	x19, x20, [sp, #16]
    5bd0:	aa0003f3 	mov	x19, x0
    5bd4:	f9400000 	ldr	x0, [x0]
    5bd8:	b4000060 	cbz	x0, 5be4 <fwp_owned_tape_release+0x24>
    5bdc:	f9400661 	ldr	x1, [x19, #8]
    5be0:	f9000401 	str	x1, [x0, #8]
    5be4:	f9400661 	ldr	x1, [x19, #8]
    5be8:	b4000041 	cbz	x1, 5bf0 <fwp_owned_tape_release+0x30>
    5bec:	f9000020 	str	x0, [x1]
    5bf0:	f9400a60 	ldr	x0, [x19, #16]
    5bf4:	f9403401 	ldr	x1, [x0, #104]
    5bf8:	b40005c1 	cbz	x1, 5cb0 <fwp_owned_tape_release+0xf0>
    5bfc:	a9450a60 	ldp	x0, x2, [x19, #80]
    5c00:	eb00005f 	cmp	x2, x0
    5c04:	540002ed 	b.le	5c60 <fwp_owned_tape_release+0xa0>
    5c08:	d2800014 	mov	x20, #0x0                   	// #0
    5c0c:	f90013f5 	str	x21, [sp, #32]
    5c10:	d2800015 	mov	x21, #0x0                   	// #0
    5c14:	d503201f 	nop
    5c18:	f9402260 	ldr	x0, [x19, #64]
    5c1c:	910006b5 	add	x21, x21, #0x1
    5c20:	f8746800 	ldr	x0, [x0, x20]
    5c24:	d63f0020 	blr	x1
    5c28:	f9402260 	ldr	x0, [x19, #64]
    5c2c:	f9400a61 	ldr	x1, [x19, #16]
    5c30:	8b140000 	add	x0, x0, x20
    5c34:	91004294 	add	x20, x20, #0x10
    5c38:	f9400400 	ldr	x0, [x0, #8]
    5c3c:	f9403421 	ldr	x1, [x1, #104]
    5c40:	d63f0020 	blr	x1
    5c44:	a9450261 	ldp	x1, x0, [x19, #80]
    5c48:	cb010000 	sub	x0, x0, x1
    5c4c:	eb15001f 	cmp	x0, x21
    5c50:	f9400a60 	ldr	x0, [x19, #16]
    5c54:	f9403401 	ldr	x1, [x0, #104]
    5c58:	54fffe0c 	b.gt	5c18 <fwp_owned_tape_release+0x58>
    5c5c:	f94013f5 	ldr	x21, [sp, #32]
    5c60:	f9403663 	ldr	x3, [x19, #104]
    5c64:	f9401262 	ldr	x2, [x19, #32]
    5c68:	f100007f 	cmp	x3, #0x0
    5c6c:	540001ed 	b.le	5ca8 <fwp_owned_tape_release+0xe8>
    5c70:	d2800014 	mov	x20, #0x0                   	// #0
    5c74:	d503201f 	nop
    5c78:	f9402660 	ldr	x0, [x19, #72]
    5c7c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5c80:	eb02001f 	cmp	x0, x2
    5c84:	540000c0 	b.eq	5c9c <fwp_owned_tape_release+0xdc>  // b.none
    5c88:	d63f0020 	blr	x1
    5c8c:	f9400a60 	ldr	x0, [x19, #16]
    5c90:	f9401262 	ldr	x2, [x19, #32]
    5c94:	f9403663 	ldr	x3, [x19, #104]
    5c98:	f9403401 	ldr	x1, [x0, #104]
    5c9c:	91000694 	add	x20, x20, #0x1
    5ca0:	eb14007f 	cmp	x3, x20
    5ca4:	54fffeac 	b.gt	5c78 <fwp_owned_tape_release+0xb8>
    5ca8:	aa0203e0 	mov	x0, x2
    5cac:	d63f0020 	blr	x1
    5cb0:	f9401660 	ldr	x0, [x19, #40]
    5cb4:	97ffff6f 	bl	5a70 <fwp_closure_drop>
    5cb8:	f9401a60 	ldr	x0, [x19, #48]
    5cbc:	97ffff6d 	bl	5a70 <fwp_closure_drop>
    5cc0:	f9401e60 	ldr	x0, [x19, #56]
    5cc4:	97ffff6b 	bl	5a70 <fwp_closure_drop>
    5cc8:	f9402260 	ldr	x0, [x19, #64]
    5ccc:	97fffac9 	bl	47f0 <fwp_mem_free>
    5cd0:	f9402660 	ldr	x0, [x19, #72]
    5cd4:	97fffac7 	bl	47f0 <fwp_mem_free>
    5cd8:	aa1303e0 	mov	x0, x19
    5cdc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ce0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ce4:	17fffac3 	b	47f0 <fwp_mem_free>
    5ce8:	d65f03c0 	ret
    5cec:	d503201f 	nop

0000000000005cf0 <fwp_tape_finish>:
    5cf0:	d10203ff 	sub	sp, sp, #0x80
    5cf4:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    5cf8:	f947f421 	ldr	x1, [x1, #4072]
    5cfc:	a9047bfd 	stp	x29, x30, [sp, #64]
    5d00:	910103fd 	add	x29, sp, #0x40
    5d04:	a90553f3 	stp	x19, x20, [sp, #80]
    5d08:	a9065bf5 	stp	x21, x22, [sp, #96]
    5d0c:	a90763f7 	stp	x23, x24, [sp, #112]
    5d10:	f00000d8 	adrp	x24, 20000 <__data_start>
    5d14:	9100c316 	add	x22, x24, #0x30
    5d18:	f9400022 	ldr	x2, [x1]
    5d1c:	f9001fe2 	str	x2, [sp, #56]
    5d20:	d2800002 	mov	x2, #0x0                   	// #0
    5d24:	910122c0 	add	x0, x22, #0x48
    5d28:	97fff576 	bl	3300 <fwp_tape_buffers_dispose>
    5d2c:	f90042df 	str	xzr, [x22, #128]
    5d30:	f94022c0 	ldr	x0, [x22, #64]
    5d34:	f100001f 	cmp	x0, #0x0
    5d38:	5400030d 	b.le	5d98 <fwp_tape_finish+0xa8>
    5d3c:	910003f7 	mov	x23, sp
    5d40:	d2800015 	mov	x21, #0x0                   	// #0
    5d44:	d2800014 	mov	x20, #0x0                   	// #0
    5d48:	f94002d3 	ldr	x19, [x22]
    5d4c:	91000694 	add	x20, x20, #0x1
    5d50:	8b150273 	add	x19, x19, x21
    5d54:	9101a2b5 	add	x21, x21, #0x68
    5d58:	aa1303e0 	mov	x0, x19
    5d5c:	97fff48d 	bl	2f90 <fwp_tape_unlink_scope>
    5d60:	aa1703e0 	mov	x0, x23
    5d64:	f9401261 	ldr	x1, [x19, #32]
    5d68:	f90003e1 	str	x1, [sp]
    5d6c:	f9401a62 	ldr	x2, [x19, #48]
    5d70:	f9000be2 	str	x2, [sp, #16]
    5d74:	f9402261 	ldr	x1, [x19, #64]
    5d78:	f90013e1 	str	x1, [sp, #32]
    5d7c:	97fff561 	bl	3300 <fwp_tape_buffers_dispose>
    5d80:	f9403260 	ldr	x0, [x19, #96]
    5d84:	97ffff8f 	bl	5bc0 <fwp_owned_tape_release>
    5d88:	f900327f 	str	xzr, [x19, #96]
    5d8c:	f94022c0 	ldr	x0, [x22, #64]
    5d90:	eb14001f 	cmp	x0, x20
    5d94:	54fffdac 	b.gt	5d48 <fwp_tape_finish+0x58>
    5d98:	f9401b00 	ldr	x0, [x24, #48]
    5d9c:	9100c313 	add	x19, x24, #0x30
    5da0:	97fff2e8 	bl	2940 <free@plt>
    5da4:	f9001b1f 	str	xzr, [x24, #48]
    5da8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5dac:	f947f400 	ldr	x0, [x0, #4072]
    5db0:	f900227f 	str	xzr, [x19, #64]
    5db4:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    5db8:	f9401fe2 	ldr	x2, [sp, #56]
    5dbc:	f9400001 	ldr	x1, [x0]
    5dc0:	eb010042 	subs	x2, x2, x1
    5dc4:	d2800001 	mov	x1, #0x0                   	// #0
    5dc8:	540000e1 	b.ne	5de4 <fwp_tape_finish+0xf4>  // b.any
    5dcc:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5dd0:	a94553f3 	ldp	x19, x20, [sp, #80]
    5dd4:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5dd8:	a94763f7 	ldp	x23, x24, [sp, #112]
    5ddc:	910203ff 	add	sp, sp, #0x80
    5de0:	d65f03c0 	ret
    5de4:	97fff2a7 	bl	2880 <__stack_chk_fail@plt>
    5de8:	d503201f 	nop
    5dec:	d503201f 	nop

0000000000005df0 <fwp_tape_scope_release>:
    5df0:	d10243ff 	sub	sp, sp, #0x90
    5df4:	a9047bfd 	stp	x29, x30, [sp, #64]
    5df8:	910103fd 	add	x29, sp, #0x40
    5dfc:	a90553f3 	stp	x19, x20, [sp, #80]
    5e00:	aa0003f4 	mov	x20, x0
    5e04:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5e08:	f947f400 	ldr	x0, [x0, #4072]
    5e0c:	b9400285 	ldr	w5, [x20]
    5e10:	f9400001 	ldr	x1, [x0]
    5e14:	f9001fe1 	str	x1, [sp, #56]
    5e18:	d2800001 	mov	x1, #0x0                   	// #0
    5e1c:	37f806c5 	tbnz	w5, #31, 5ef4 <fwp_tape_scope_release+0x104>
    5e20:	a90763f7 	stp	x23, x24, [sp, #112]
    5e24:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    5e28:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    5e2c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    5e30:	f00000d3 	adrp	x19, 20000 <__data_start>
    5e34:	910003f7 	mov	x23, sp
    5e38:	9100c273 	add	x19, x19, #0x30
    5e3c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    5e40:	a9065bf5 	stp	x21, x22, [sp, #96]
    5e44:	52800d16 	mov	w22, #0x68                  	// #104
    5e48:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    5e4c:	f90043f9 	str	x25, [sp, #128]
    5e50:	14000006 	b	5e68 <fwp_tape_scope_release+0x78>
    5e54:	97fff52b 	bl	3300 <fwp_tape_buffers_dispose>
    5e58:	aa1903e0 	mov	x0, x25
    5e5c:	97ffff59 	bl	5bc0 <fwp_owned_tape_release>
    5e60:	b9400285 	ldr	w5, [x20]
    5e64:	37f80425 	tbnz	w5, #31, 5ee8 <fwp_tape_scope_release+0xf8>
    5e68:	f9400266 	ldr	x6, [x19]
    5e6c:	9b367ca5 	smull	x5, w5, w22
    5e70:	8b0500c0 	add	x0, x6, x5
    5e74:	97fff447 	bl	2f90 <fwp_tape_unlink_scope>
    5e78:	ad410001 	ldp	q1, q0, [x0, #32]
    5e7c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    5e80:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    5e84:	f9400c03 	ldr	x3, [x0, #24]
    5e88:	ad0003e1 	stp	q1, q0, [sp]
    5e8c:	b86568c1 	ldr	w1, [x6, x5]
    5e90:	a9440804 	ldp	x4, x2, [x0, #64]
    5e94:	b900041f 	str	wzr, [x0, #4]
    5e98:	f9403019 	ldr	x25, [x0, #96]
    5e9c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    5ea0:	f9000c1f 	str	xzr, [x0, #24]
    5ea4:	a9020fe4 	stp	x4, x3, [sp, #32]
    5ea8:	f9001be2 	str	x2, [sp, #48]
    5eac:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    5eb0:	f900301f 	str	xzr, [x0, #96]
    5eb4:	6b15003f 	cmp	w1, w21
    5eb8:	540000e8 	b.hi	5ed4 <fwp_tape_scope_release+0xe4>  // b.pmore
    5ebc:	9343fca5 	asr	x5, x5, #3
    5ec0:	f9404e60 	ldr	x0, [x19, #152]
    5ec4:	9b187ca5 	mul	x5, x5, x24
    5ec8:	eb0000bf 	cmp	x5, x0
    5ecc:	5400004a 	b.ge	5ed4 <fwp_tape_scope_release+0xe4>  // b.tcont
    5ed0:	f9004e65 	str	x5, [x19, #152]
    5ed4:	aa1703e0 	mov	x0, x23
    5ed8:	b5fffbf9 	cbnz	x25, 5e54 <fwp_tape_scope_release+0x64>
    5edc:	97fff889 	bl	4100 <fwp_tape_buffers_release>
    5ee0:	b9400285 	ldr	w5, [x20]
    5ee4:	36fffc25 	tbz	w5, #31, 5e68 <fwp_tape_scope_release+0x78>
    5ee8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5eec:	a94763f7 	ldp	x23, x24, [sp, #112]
    5ef0:	f94043f9 	ldr	x25, [sp, #128]
    5ef4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5ef8:	f947f400 	ldr	x0, [x0, #4072]
    5efc:	f9401fe2 	ldr	x2, [sp, #56]
    5f00:	f9400001 	ldr	x1, [x0]
    5f04:	eb010042 	subs	x2, x2, x1
    5f08:	d2800001 	mov	x1, #0x0                   	// #0
    5f0c:	540000a1 	b.ne	5f20 <fwp_tape_scope_release+0x130>  // b.any
    5f10:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5f14:	a94553f3 	ldp	x19, x20, [sp, #80]
    5f18:	910243ff 	add	sp, sp, #0x90
    5f1c:	d65f03c0 	ret
    5f20:	a9065bf5 	stp	x21, x22, [sp, #96]
    5f24:	a90763f7 	stp	x23, x24, [sp, #112]
    5f28:	f90043f9 	str	x25, [sp, #128]
    5f2c:	97fff255 	bl	2880 <__stack_chk_fail@plt>

0000000000005f30 <fwp_drop4>:
    5f30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5f34:	910003fd 	mov	x29, sp
    5f38:	a9025bf5 	stp	x21, x22, [sp, #32]
    5f3c:	90000176 	adrp	x22, 31000 <fwp_root_context+0xca0>
    5f40:	911502d5 	add	x21, x22, #0x540
    5f44:	a90153f3 	stp	x19, x20, [sp, #16]
    5f48:	aa0003f3 	mov	x19, x0
    5f4c:	f949daa1 	ldr	x1, [x21, #5040]
    5f50:	f949eea0 	ldr	x0, [x21, #5080]
    5f54:	cb010261 	sub	x1, x19, x1
    5f58:	eb00403f 	cmp	x1, x0, lsl #16
    5f5c:	54000382 	b.cs	5fcc <fwp_drop4+0x9c>  // b.hs, b.nlast
    5f60:	d350fc22 	lsr	x2, x1, #16
    5f64:	f949fea3 	ldr	x3, [x21, #5112]
    5f68:	8b020842 	add	x2, x2, x2, lsl #2
    5f6c:	d37df042 	lsl	x2, x2, #3
    5f70:	8b020060 	add	x0, x3, x2
    5f74:	f9401014 	ldr	x20, [x0, #32]
    5f78:	b40002b4 	cbz	x20, 5fcc <fwp_drop4+0x9c>
    5f7c:	38626862 	ldrb	w2, [x3, x2]
    5f80:	7100085f 	cmp	w2, #0x2
    5f84:	540002c0 	b.eq	5fdc <fwp_drop4+0xac>  // b.none
    5f88:	7100045f 	cmp	w2, #0x1
    5f8c:	54000201 	b.ne	5fcc <fwp_drop4+0x9c>  // b.any
    5f90:	29430002 	ldp	w2, w0, [x0, #24]
    5f94:	92403c21 	and	x1, x1, #0xffff
    5f98:	9b027c21 	mul	x1, x1, x2
    5f9c:	d360fc21 	lsr	x1, x1, #32
    5fa0:	eb00003f 	cmp	x1, x0
    5fa4:	54000142 	b.cs	5fcc <fwp_drop4+0x9c>  // b.hs, b.nlast
    5fa8:	8b010294 	add	x20, x20, x1
    5fac:	39400280 	ldrb	w0, [x20]
    5fb0:	340000e0 	cbz	w0, 5fcc <fwp_drop4+0x9c>
    5fb4:	7100041f 	cmp	w0, #0x1
    5fb8:	540001e0 	b.eq	5ff4 <fwp_drop4+0xc4>  // b.none
    5fbc:	7103fc1f 	cmp	w0, #0xff
    5fc0:	540007c0 	b.eq	60b8 <fwp_drop4+0x188>  // b.none
    5fc4:	51000400 	sub	w0, w0, #0x1
    5fc8:	39000280 	strb	w0, [x20]
    5fcc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5fd4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fd8:	d65f03c0 	ret
    5fdc:	72003c3f 	tst	w1, #0xffff
    5fe0:	54fffe60 	b.eq	5fac <fwp_drop4+0x7c>  // b.none
    5fe4:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fe8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5fec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ff0:	d65f03c0 	ret
    5ff4:	911502c2 	add	x2, x22, #0x540
    5ff8:	f9400660 	ldr	x0, [x19, #8]
    5ffc:	f949d841 	ldr	x1, [x2, #5040]
    6000:	f949ec42 	ldr	x2, [x2, #5080]
    6004:	cb010001 	sub	x1, x0, x1
    6008:	eb02403f 	cmp	x1, x2, lsl #16
    600c:	54000362 	b.cs	6078 <fwp_drop4+0x148>  // b.hs, b.nlast
    6010:	d350fc22 	lsr	x2, x1, #16
    6014:	8b020842 	add	x2, x2, x2, lsl #2
    6018:	d37df042 	lsl	x2, x2, #3
    601c:	8b020064 	add	x4, x3, x2
    6020:	f9401094 	ldr	x20, [x4, #32]
    6024:	b40002b4 	cbz	x20, 6078 <fwp_drop4+0x148>
    6028:	38626862 	ldrb	w2, [x3, x2]
    602c:	7100085f 	cmp	w2, #0x2
    6030:	540003e0 	b.eq	60ac <fwp_drop4+0x17c>  // b.none
    6034:	7100045f 	cmp	w2, #0x1
    6038:	54000201 	b.ne	6078 <fwp_drop4+0x148>  // b.any
    603c:	29430883 	ldp	w3, w2, [x4, #24]
    6040:	92403c21 	and	x1, x1, #0xffff
    6044:	9b037c21 	mul	x1, x1, x3
    6048:	d360fc21 	lsr	x1, x1, #32
    604c:	eb02003f 	cmp	x1, x2
    6050:	54000142 	b.cs	6078 <fwp_drop4+0x148>  // b.hs, b.nlast
    6054:	8b010294 	add	x20, x20, x1
    6058:	39400281 	ldrb	w1, [x20]
    605c:	340000e1 	cbz	w1, 6078 <fwp_drop4+0x148>
    6060:	7100043f 	cmp	w1, #0x1
    6064:	54000200 	b.eq	60a4 <fwp_drop4+0x174>  // b.none
    6068:	7103fc3f 	cmp	w1, #0xff
    606c:	54000580 	b.eq	611c <fwp_drop4+0x1ec>  // b.none
    6070:	51000421 	sub	w1, w1, #0x1
    6074:	39000281 	strb	w1, [x20]
    6078:	f9400a74 	ldr	x20, [x19, #16]
    607c:	aa1303e0 	mov	x0, x19
    6080:	97fffcfd 	bl	5474 <fwp_rc_free_arr>
    6084:	911502c0 	add	x0, x22, #0x540
    6088:	f949d801 	ldr	x1, [x0, #5040]
    608c:	f949ec00 	ldr	x0, [x0, #5080]
    6090:	cb010281 	sub	x1, x20, x1
    6094:	eb00403f 	cmp	x1, x0, lsl #16
    6098:	54fff9a2 	b.cs	5fcc <fwp_drop4+0x9c>  // b.hs, b.nlast
    609c:	aa1403f3 	mov	x19, x20
    60a0:	17ffffb0 	b	5f60 <fwp_drop4+0x30>
    60a4:	97fffcf4 	bl	5474 <fwp_rc_free_arr>
    60a8:	17fffff4 	b	6078 <fwp_drop4+0x148>
    60ac:	72003c3f 	tst	w1, #0xffff
    60b0:	54fffe41 	b.ne	6078 <fwp_drop4+0x148>  // b.any
    60b4:	17ffffe9 	b	6058 <fwp_drop4+0x128>
    60b8:	ca544681 	eor	x1, x20, x20, lsr #17
    60bc:	911502c0 	add	x0, x22, #0x540
    60c0:	ca412421 	eor	x1, x1, x1, lsr #9
    60c4:	8b210c01 	add	x1, x0, w1, uxtb #3
    60c8:	f94a2420 	ldr	x0, [x1, #5192]
    60cc:	b5000080 	cbnz	x0, 60dc <fwp_drop4+0x1ac>
    60d0:	14000010 	b	6110 <fwp_drop4+0x1e0>
    60d4:	f9400800 	ldr	x0, [x0, #16]
    60d8:	b40001c0 	cbz	x0, 6110 <fwp_drop4+0x1e0>
    60dc:	f9400001 	ldr	x1, [x0]
    60e0:	eb14003f 	cmp	x1, x20
    60e4:	54ffff81 	b.ne	60d4 <fwp_drop4+0x1a4>  // b.any
    60e8:	f9400401 	ldr	x1, [x0, #8]
    60ec:	d1000421 	sub	x1, x1, #0x1
    60f0:	f9000401 	str	x1, [x0, #8]
    60f4:	f103f83f 	cmp	x1, #0xfe
    60f8:	54fff6a1 	b.ne	5fcc <fwp_drop4+0x9c>  // b.any
    60fc:	aa1403e0 	mov	x0, x20
    6100:	97fff91c 	bl	4570 <fwp_rc_forget_slot>
    6104:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6108:	39000280 	strb	w0, [x20]
    610c:	17ffffb0 	b	5fcc <fwp_drop4+0x9c>
    6110:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    6114:	9138e000 	add	x0, x0, #0xe38
    6118:	97fff51a 	bl	3580 <fwp_trap>
    611c:	ca544680 	eor	x0, x20, x20, lsr #17
    6120:	911502c1 	add	x1, x22, #0x540
    6124:	ca402400 	eor	x0, x0, x0, lsr #9
    6128:	8b200c20 	add	x0, x1, w0, uxtb #3
    612c:	f94a2400 	ldr	x0, [x0, #5192]
    6130:	b5000080 	cbnz	x0, 6140 <fwp_drop4+0x210>
    6134:	17fffff7 	b	6110 <fwp_drop4+0x1e0>
    6138:	f9400800 	ldr	x0, [x0, #16]
    613c:	b4fffea0 	cbz	x0, 6110 <fwp_drop4+0x1e0>
    6140:	f9400001 	ldr	x1, [x0]
    6144:	eb14003f 	cmp	x1, x20
    6148:	54ffff81 	b.ne	6138 <fwp_drop4+0x208>  // b.any
    614c:	f9400401 	ldr	x1, [x0, #8]
    6150:	d1000421 	sub	x1, x1, #0x1
    6154:	f9000401 	str	x1, [x0, #8]
    6158:	f103f83f 	cmp	x1, #0xfe
    615c:	54fff8e1 	b.ne	6078 <fwp_drop4+0x148>  // b.any
    6160:	aa1403e0 	mov	x0, x20
    6164:	97fff903 	bl	4570 <fwp_rc_forget_slot>
    6168:	12800020 	mov	w0, #0xfffffffe            	// #-2
    616c:	39000280 	strb	w0, [x20]
    6170:	17ffffc2 	b	6078 <fwp_drop4+0x148>

0000000000006174 <fwp_arg_drop37>:
    6174:	7100003f 	cmp	w1, #0x0
    6178:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    617c:	54000041 	b.ne	6184 <fwp_arg_drop37+0x10>  // b.any
    6180:	d65f03c0 	ret
    6184:	f9400000 	ldr	x0, [x0]
    6188:	17ffff6a 	b	5f30 <fwp_drop4>
    618c:	d503201f 	nop

0000000000006190 <fwp_task_dispose>:
    6190:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6194:	910003fd 	mov	x29, sp
    6198:	f9000bf3 	str	x19, [sp, #16]
    619c:	aa0003f3 	mov	x19, x0
    61a0:	39414000 	ldrb	w0, [x0, #80]
    61a4:	36000720 	tbz	w0, #0, 6288 <fwp_task_dispose+0xf8>
    61a8:	f9400a60 	ldr	x0, [x19, #16]
    61ac:	b50006e0 	cbnz	x0, 6288 <fwp_task_dispose+0xf8>
    61b0:	a9478660 	ldp	x0, x1, [x19, #120]
    61b4:	39014e7f 	strb	wzr, [x19, #83]
    61b8:	f9003e7f 	str	xzr, [x19, #120]
    61bc:	f100003f 	cmp	x1, #0x0
    61c0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    61c4:	54000040 	b.eq	61cc <fwp_task_dispose+0x3c>  // b.none
    61c8:	d63f0020 	blr	x1
    61cc:	f9405660 	ldr	x0, [x19, #168]
    61d0:	97fff988 	bl	47f0 <fwp_mem_free>
    61d4:	f900567f 	str	xzr, [x19, #168]
    61d8:	b9405e60 	ldr	w0, [x19, #92]
    61dc:	7100041f 	cmp	w0, #0x1
    61e0:	54000420 	b.eq	6264 <fwp_task_dispose+0xd4>  // b.none
    61e4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    61e8:	91150042 	add	x2, x2, #0x540
    61ec:	f949d840 	ldr	x0, [x2, #5040]
    61f0:	f949ec41 	ldr	x1, [x2, #5080]
    61f4:	cb000260 	sub	x0, x19, x0
    61f8:	eb01401f 	cmp	x0, x1, lsl #16
    61fc:	540002e2 	b.cs	6258 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6200:	d350fc01 	lsr	x1, x0, #16
    6204:	f949fc44 	ldr	x4, [x2, #5112]
    6208:	8b010821 	add	x1, x1, x1, lsl #2
    620c:	d37df021 	lsl	x1, x1, #3
    6210:	8b010083 	add	x3, x4, x1
    6214:	f9401062 	ldr	x2, [x3, #32]
    6218:	b4000202 	cbz	x2, 6258 <fwp_task_dispose+0xc8>
    621c:	38616881 	ldrb	w1, [x4, x1]
    6220:	7100083f 	cmp	w1, #0x2
    6224:	54000280 	b.eq	6274 <fwp_task_dispose+0xe4>  // b.none
    6228:	7100043f 	cmp	w1, #0x1
    622c:	54000161 	b.ne	6258 <fwp_task_dispose+0xc8>  // b.any
    6230:	29430464 	ldp	w4, w1, [x3, #24]
    6234:	92403c00 	and	x0, x0, #0xffff
    6238:	9b047c00 	mul	x0, x0, x4
    623c:	d360fc00 	lsr	x0, x0, #32
    6240:	eb01001f 	cmp	x0, x1
    6244:	540000a2 	b.cs	6258 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6248:	8b000042 	add	x2, x2, x0
    624c:	39400040 	ldrb	w0, [x2]
    6250:	7100041f 	cmp	w0, #0x1
    6254:	54000080 	b.eq	6264 <fwp_task_dispose+0xd4>  // b.none
    6258:	f9400bf3 	ldr	x19, [sp, #16]
    625c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6260:	d65f03c0 	ret
    6264:	aa1303e0 	mov	x0, x19
    6268:	f9400bf3 	ldr	x19, [sp, #16]
    626c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6270:	17fff960 	b	47f0 <fwp_mem_free>
    6274:	72003c1f 	tst	w0, #0xffff
    6278:	54fffea0 	b.eq	624c <fwp_task_dispose+0xbc>  // b.none
    627c:	f9400bf3 	ldr	x19, [sp, #16]
    6280:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6284:	d65f03c0 	ret
    6288:	97fff192 	bl	28d0 <abort@plt>
    628c:	d503201f 	nop

0000000000006290 <fwp_free_zombie>:
    6290:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6294:	910003fd 	mov	x29, sp
    6298:	a90153f3 	stp	x19, x20, [sp, #16]
    629c:	d00000d4 	adrp	x20, 20000 <__data_start>
    62a0:	9100c281 	add	x1, x20, #0x30
    62a4:	f9405033 	ldr	x19, [x1, #160]
    62a8:	b4000333 	cbz	x19, 630c <fwp_free_zombie+0x7c>
    62ac:	f9400820 	ldr	x0, [x1, #16]
    62b0:	eb00027f 	cmp	x19, x0
    62b4:	540002c0 	b.eq	630c <fwp_free_zombie+0x7c>  // b.none
    62b8:	b940a822 	ldr	w2, [x1, #168]
    62bc:	f9400a60 	ldr	x0, [x19, #16]
    62c0:	7100fc5f 	cmp	w2, #0x3f
    62c4:	5400078c 	b.gt	63b4 <fwp_free_zombie+0x124>
    62c8:	9102c023 	add	x3, x1, #0xb0
    62cc:	11000444 	add	w4, w2, #0x1
    62d0:	b900a824 	str	w4, [x1, #168]
    62d4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    62d8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    62dc:	a9530261 	ldp	x1, x0, [x19, #304]
    62e0:	b4000741 	cbz	x1, 63c8 <fwp_free_zombie+0x138>
    62e4:	f9009c20 	str	x0, [x1, #312]
    62e8:	b4000040 	cbz	x0, 62f0 <fwp_free_zombie+0x60>
    62ec:	f9009801 	str	x1, [x0, #304]
    62f0:	9100c294 	add	x20, x20, #0x30
    62f4:	b9405e60 	ldr	w0, [x19, #92]
    62f8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    62fc:	f900529f 	str	xzr, [x20, #160]
    6300:	34000140 	cbz	w0, 6328 <fwp_free_zombie+0x98>
    6304:	7100041f 	cmp	w0, #0x1
    6308:	54000080 	b.eq	6318 <fwp_free_zombie+0x88>  // b.none
    630c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6310:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6314:	d65f03c0 	ret
    6318:	aa1303e0 	mov	x0, x19
    631c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6320:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6324:	17ffff9b 	b	6190 <fwp_task_dispose>
    6328:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xca0>
    632c:	91150082 	add	x2, x4, #0x540
    6330:	f949d841 	ldr	x1, [x2, #5040]
    6334:	f949ec40 	ldr	x0, [x2, #5080]
    6338:	cb010261 	sub	x1, x19, x1
    633c:	eb00403f 	cmp	x1, x0, lsl #16
    6340:	54fffe62 	b.cs	630c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6344:	d350fc20 	lsr	x0, x1, #16
    6348:	f949fc43 	ldr	x3, [x2, #5112]
    634c:	8b000800 	add	x0, x0, x0, lsl #2
    6350:	d37df000 	lsl	x0, x0, #3
    6354:	8b000062 	add	x2, x3, x0
    6358:	f9401054 	ldr	x20, [x2, #32]
    635c:	b4fffd94 	cbz	x20, 630c <fwp_free_zombie+0x7c>
    6360:	38606860 	ldrb	w0, [x3, x0]
    6364:	7100081f 	cmp	w0, #0x2
    6368:	54000360 	b.eq	63d4 <fwp_free_zombie+0x144>  // b.none
    636c:	7100041f 	cmp	w0, #0x1
    6370:	54fffce1 	b.ne	630c <fwp_free_zombie+0x7c>  // b.any
    6374:	29430043 	ldp	w3, w0, [x2, #24]
    6378:	92403c21 	and	x1, x1, #0xffff
    637c:	9b037c21 	mul	x1, x1, x3
    6380:	d360fc21 	lsr	x1, x1, #32
    6384:	eb00003f 	cmp	x1, x0
    6388:	54fffc22 	b.cs	630c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    638c:	8b010294 	add	x20, x20, x1
    6390:	39400280 	ldrb	w0, [x20]
    6394:	34fffbc0 	cbz	w0, 630c <fwp_free_zombie+0x7c>
    6398:	7100041f 	cmp	w0, #0x1
    639c:	54fffbe0 	b.eq	6318 <fwp_free_zombie+0x88>  // b.none
    63a0:	7103fc1f 	cmp	w0, #0xff
    63a4:	540001e0 	b.eq	63e0 <fwp_free_zombie+0x150>  // b.none
    63a8:	51000400 	sub	w0, w0, #0x1
    63ac:	39000280 	strb	w0, [x20]
    63b0:	17ffffd7 	b	630c <fwp_free_zombie+0x7c>
    63b4:	f9400e61 	ldr	x1, [x19, #24]
    63b8:	97fff17a 	bl	29a0 <munmap@plt>
    63bc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    63c0:	a9530261 	ldp	x1, x0, [x19, #304]
    63c4:	b5fff901 	cbnz	x1, 62e4 <fwp_free_zombie+0x54>
    63c8:	9100c282 	add	x2, x20, #0x30
    63cc:	f9015840 	str	x0, [x2, #688]
    63d0:	17ffffc6 	b	62e8 <fwp_free_zombie+0x58>
    63d4:	72003c3f 	tst	w1, #0xffff
    63d8:	54fff9a1 	b.ne	630c <fwp_free_zombie+0x7c>  // b.any
    63dc:	17ffffed 	b	6390 <fwp_free_zombie+0x100>
    63e0:	ca544680 	eor	x0, x20, x20, lsr #17
    63e4:	91150084 	add	x4, x4, #0x540
    63e8:	ca402400 	eor	x0, x0, x0, lsr #9
    63ec:	8b200c80 	add	x0, x4, w0, uxtb #3
    63f0:	f94a2400 	ldr	x0, [x0, #5192]
    63f4:	b5000080 	cbnz	x0, 6404 <fwp_free_zombie+0x174>
    63f8:	14000010 	b	6438 <fwp_free_zombie+0x1a8>
    63fc:	f9400800 	ldr	x0, [x0, #16]
    6400:	b40001c0 	cbz	x0, 6438 <fwp_free_zombie+0x1a8>
    6404:	f9400001 	ldr	x1, [x0]
    6408:	eb14003f 	cmp	x1, x20
    640c:	54ffff81 	b.ne	63fc <fwp_free_zombie+0x16c>  // b.any
    6410:	f9400401 	ldr	x1, [x0, #8]
    6414:	d1000421 	sub	x1, x1, #0x1
    6418:	f9000401 	str	x1, [x0, #8]
    641c:	f103f83f 	cmp	x1, #0xfe
    6420:	54fff761 	b.ne	630c <fwp_free_zombie+0x7c>  // b.any
    6424:	aa1403e0 	mov	x0, x20
    6428:	97fff852 	bl	4570 <fwp_rc_forget_slot>
    642c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6430:	39000280 	strb	w0, [x20]
    6434:	17ffffb6 	b	630c <fwp_free_zombie+0x7c>
    6438:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    643c:	9138e000 	add	x0, x0, #0xe38
    6440:	97fff450 	bl	3580 <fwp_trap>

0000000000006444 <fwp_block>:
    6444:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6448:	910003fd 	mov	x29, sp
    644c:	a90153f3 	stp	x19, x20, [sp, #16]
    6450:	d00000d3 	adrp	x19, 20000 <__data_start>
    6454:	9100c274 	add	x20, x19, #0x30
    6458:	f9401a82 	ldr	x2, [x20, #48]
    645c:	b4000622 	cbz	x2, 6520 <fwp_block+0xdc>
    6460:	9100c261 	add	x1, x19, #0x30
    6464:	f9408040 	ldr	x0, [x2, #256]
    6468:	f9001820 	str	x0, [x1, #48]
    646c:	b4000680 	cbz	x0, 653c <fwp_block+0xf8>
    6470:	9100c263 	add	x3, x19, #0x30
    6474:	3901505f 	strb	wzr, [x2, #84]
    6478:	f9400864 	ldr	x4, [x3, #16]
    647c:	eb02009f 	cmp	x4, x2
    6480:	54000440 	b.eq	6508 <fwp_block+0xc4>  // b.none
    6484:	f9415c65 	ldr	x5, [x3, #696]
    6488:	f9000862 	str	x2, [x3, #16]
    648c:	f9400441 	ldr	x1, [x2, #8]
    6490:	f9004885 	str	x5, [x4, #144]
    6494:	f9416065 	ldr	x5, [x3, #704]
    6498:	f9004c85 	str	x5, [x4, #152]
    649c:	f9416465 	ldr	x5, [x3, #712]
    64a0:	f9005085 	str	x5, [x4, #160]
    64a4:	f9416865 	ldr	x5, [x3, #720]
    64a8:	f9005485 	str	x5, [x4, #168]
    64ac:	f9416c65 	ldr	x5, [x3, #728]
    64b0:	f9005885 	str	x5, [x4, #176]
    64b4:	f9417065 	ldr	x5, [x3, #736]
    64b8:	f9005c85 	str	x5, [x4, #184]
    64bc:	f9417465 	ldr	x5, [x3, #744]
    64c0:	f9006085 	str	x5, [x4, #192]
    64c4:	f9400480 	ldr	x0, [x4, #8]
    64c8:	f9404844 	ldr	x4, [x2, #144]
    64cc:	f9015c64 	str	x4, [x3, #696]
    64d0:	f9404c44 	ldr	x4, [x2, #152]
    64d4:	f9016064 	str	x4, [x3, #704]
    64d8:	f9405044 	ldr	x4, [x2, #160]
    64dc:	f9016464 	str	x4, [x3, #712]
    64e0:	f9405444 	ldr	x4, [x2, #168]
    64e4:	f9016864 	str	x4, [x3, #720]
    64e8:	f9405844 	ldr	x4, [x2, #176]
    64ec:	f9016c64 	str	x4, [x3, #728]
    64f0:	a94b8844 	ldp	x4, x2, [x2, #184]
    64f4:	f9017064 	str	x4, [x3, #736]
    64f8:	f9017462 	str	x2, [x3, #744]
    64fc:	97fff0f9 	bl	28e0 <swapcontext@plt>
    6500:	97ffff64 	bl	6290 <fwp_free_zombie>
    6504:	d503201f 	nop
    6508:	9100c260 	add	x0, x19, #0x30
    650c:	b942f000 	ldr	w0, [x0, #752]
    6510:	340001a0 	cbz	w0, 6544 <fwp_block+0x100>
    6514:	a94153f3 	ldp	x19, x20, [sp, #16]
    6518:	a8c27bfd 	ldp	x29, x30, [sp], #32
    651c:	d65f03c0 	ret
    6520:	97fff740 	bl	4220 <fwp_poll_events>
    6524:	f9401a82 	ldr	x2, [x20, #48]
    6528:	b4ffffc2 	cbz	x2, 6520 <fwp_block+0xdc>
    652c:	9100c261 	add	x1, x19, #0x30
    6530:	f9408040 	ldr	x0, [x2, #256]
    6534:	f9001820 	str	x0, [x1, #48]
    6538:	b5fff9c0 	cbnz	x0, 6470 <fwp_block+0x2c>
    653c:	f900143f 	str	xzr, [x1, #40]
    6540:	17ffffcc 	b	6470 <fwp_block+0x2c>
    6544:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    6548:	913da000 	add	x0, x0, #0xf68
    654c:	97fff131 	bl	2a10 <getenv@plt>
    6550:	5284e202 	mov	w2, #0x2710                	// #10000
    6554:	b4000060 	cbz	x0, 6560 <fwp_block+0x11c>
    6558:	39400001 	ldrb	w1, [x0]
    655c:	350000c1 	cbnz	w1, 6574 <fwp_block+0x130>
    6560:	9100c273 	add	x19, x19, #0x30
    6564:	b902f262 	str	w2, [x19, #752]
    6568:	a94153f3 	ldp	x19, x20, [sp, #16]
    656c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6570:	d65f03c0 	ret
    6574:	52800142 	mov	w2, #0xa                   	// #10
    6578:	d2800001 	mov	x1, #0x0                   	// #0
    657c:	97fff075 	bl	2750 <strtoll@plt>
    6580:	d1000403 	sub	x3, x0, #0x1
    6584:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6588:	eb02007f 	cmp	x3, x2
    658c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6590:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6594:	17fffff3 	b	6560 <fwp_block+0x11c>
    6598:	d503201f 	nop
    659c:	d503201f 	nop

00000000000065a0 <fwp_drop10>:
    65a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    65a4:	910003fd 	mov	x29, sp
    65a8:	a90153f3 	stp	x19, x20, [sp, #16]
    65ac:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xca0>
    65b0:	f90013f5 	str	x21, [sp, #32]
    65b4:	91150275 	add	x21, x19, #0x540
    65b8:	f949daa1 	ldr	x1, [x21, #5040]
    65bc:	f949eea2 	ldr	x2, [x21, #5080]
    65c0:	cb010001 	sub	x1, x0, x1
    65c4:	eb02403f 	cmp	x1, x2, lsl #16
    65c8:	54000382 	b.cs	6638 <fwp_drop10+0x98>  // b.hs, b.nlast
    65cc:	d350fc22 	lsr	x2, x1, #16
    65d0:	f949fea3 	ldr	x3, [x21, #5112]
    65d4:	8b020842 	add	x2, x2, x2, lsl #2
    65d8:	d37df042 	lsl	x2, x2, #3
    65dc:	8b020064 	add	x4, x3, x2
    65e0:	f9401094 	ldr	x20, [x4, #32]
    65e4:	b40002b4 	cbz	x20, 6638 <fwp_drop10+0x98>
    65e8:	38626862 	ldrb	w2, [x3, x2]
    65ec:	7100085f 	cmp	w2, #0x2
    65f0:	540007a0 	b.eq	66e4 <fwp_drop10+0x144>  // b.none
    65f4:	7100045f 	cmp	w2, #0x1
    65f8:	54000201 	b.ne	6638 <fwp_drop10+0x98>  // b.any
    65fc:	29430885 	ldp	w5, w2, [x4, #24]
    6600:	92403c21 	and	x1, x1, #0xffff
    6604:	9b057c21 	mul	x1, x1, x5
    6608:	d360fc21 	lsr	x1, x1, #32
    660c:	eb02003f 	cmp	x1, x2
    6610:	54000142 	b.cs	6638 <fwp_drop10+0x98>  // b.hs, b.nlast
    6614:	8b010294 	add	x20, x20, x1
    6618:	39400281 	ldrb	w1, [x20]
    661c:	340000e1 	cbz	w1, 6638 <fwp_drop10+0x98>
    6620:	7100043f 	cmp	w1, #0x1
    6624:	54000120 	b.eq	6648 <fwp_drop10+0xa8>  // b.none
    6628:	7103fc3f 	cmp	w1, #0xff
    662c:	540007c0 	b.eq	6724 <fwp_drop10+0x184>  // b.none
    6630:	51000421 	sub	w1, w1, #0x1
    6634:	39000281 	strb	w1, [x20]
    6638:	a94153f3 	ldp	x19, x20, [sp, #16]
    663c:	f94013f5 	ldr	x21, [sp, #32]
    6640:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6644:	d65f03c0 	ret
    6648:	f9400001 	ldr	x1, [x0]
    664c:	b7f80581 	tbnz	x1, #63, 66fc <fwp_drop10+0x15c>
    6650:	91150273 	add	x19, x19, #0x540
    6654:	f949da61 	ldr	x1, [x19, #5040]
    6658:	f949ee62 	ldr	x2, [x19, #5080]
    665c:	cb010001 	sub	x1, x0, x1
    6660:	eb02403f 	cmp	x1, x2, lsl #16
    6664:	54fffea2 	b.cs	6638 <fwp_drop10+0x98>  // b.hs, b.nlast
    6668:	d350fc22 	lsr	x2, x1, #16
    666c:	8b020842 	add	x2, x2, x2, lsl #2
    6670:	d37df042 	lsl	x2, x2, #3
    6674:	8b020065 	add	x5, x3, x2
    6678:	f94010a4 	ldr	x4, [x5, #32]
    667c:	b4fffde4 	cbz	x4, 6638 <fwp_drop10+0x98>
    6680:	38626862 	ldrb	w2, [x3, x2]
    6684:	7100085f 	cmp	w2, #0x2
    6688:	54000220 	b.eq	66cc <fwp_drop10+0x12c>  // b.none
    668c:	7100045f 	cmp	w2, #0x1
    6690:	54fffd41 	b.ne	6638 <fwp_drop10+0x98>  // b.any
    6694:	294308a3 	ldp	w3, w2, [x5, #24]
    6698:	92403c21 	and	x1, x1, #0xffff
    669c:	9b037c21 	mul	x1, x1, x3
    66a0:	d360fc21 	lsr	x1, x1, #32
    66a4:	eb02003f 	cmp	x1, x2
    66a8:	54fffc82 	b.cs	6638 <fwp_drop10+0x98>  // b.hs, b.nlast
    66ac:	8b010084 	add	x4, x4, x1
    66b0:	39400081 	ldrb	w1, [x4]
    66b4:	7100043f 	cmp	w1, #0x1
    66b8:	54fffc01 	b.ne	6638 <fwp_drop10+0x98>  // b.any
    66bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    66c0:	f94013f5 	ldr	x21, [sp, #32]
    66c4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66c8:	17fff84a 	b	47f0 <fwp_mem_free>
    66cc:	72003c3f 	tst	w1, #0xffff
    66d0:	54ffff00 	b.eq	66b0 <fwp_drop10+0x110>  // b.none
    66d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    66d8:	f94013f5 	ldr	x21, [sp, #32]
    66dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66e0:	d65f03c0 	ret
    66e4:	72003c3f 	tst	w1, #0xffff
    66e8:	54fff980 	b.eq	6618 <fwp_drop10+0x78>  // b.none
    66ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    66f0:	f94013f5 	ldr	x21, [sp, #32]
    66f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66f8:	d65f03c0 	ret
    66fc:	f9400414 	ldr	x20, [x0, #8]
    6700:	97fffb5d 	bl	5474 <fwp_rc_free_arr>
    6704:	91150260 	add	x0, x19, #0x540
    6708:	f949d801 	ldr	x1, [x0, #5040]
    670c:	f949ec00 	ldr	x0, [x0, #5080]
    6710:	cb010281 	sub	x1, x20, x1
    6714:	eb00403f 	cmp	x1, x0, lsl #16
    6718:	54fff902 	b.cs	6638 <fwp_drop10+0x98>  // b.hs, b.nlast
    671c:	aa1403e0 	mov	x0, x20
    6720:	17ffffab 	b	65cc <fwp_drop10+0x2c>
    6724:	ca544680 	eor	x0, x20, x20, lsr #17
    6728:	91150273 	add	x19, x19, #0x540
    672c:	ca402400 	eor	x0, x0, x0, lsr #9
    6730:	8b200e60 	add	x0, x19, w0, uxtb #3
    6734:	f94a2400 	ldr	x0, [x0, #5192]
    6738:	b5000080 	cbnz	x0, 6748 <fwp_drop10+0x1a8>
    673c:	14000010 	b	677c <fwp_drop10+0x1dc>
    6740:	f9400800 	ldr	x0, [x0, #16]
    6744:	b40001c0 	cbz	x0, 677c <fwp_drop10+0x1dc>
    6748:	f9400001 	ldr	x1, [x0]
    674c:	eb14003f 	cmp	x1, x20
    6750:	54ffff81 	b.ne	6740 <fwp_drop10+0x1a0>  // b.any
    6754:	f9400401 	ldr	x1, [x0, #8]
    6758:	d1000421 	sub	x1, x1, #0x1
    675c:	f9000401 	str	x1, [x0, #8]
    6760:	f103f83f 	cmp	x1, #0xfe
    6764:	54fff6a1 	b.ne	6638 <fwp_drop10+0x98>  // b.any
    6768:	aa1403e0 	mov	x0, x20
    676c:	97fff781 	bl	4570 <fwp_rc_forget_slot>
    6770:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6774:	39000280 	strb	w0, [x20]
    6778:	17ffffb0 	b	6638 <fwp_drop10+0x98>
    677c:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    6780:	9138e000 	add	x0, x0, #0xe38
    6784:	97fff37f 	bl	3580 <fwp_trap>
    6788:	d503201f 	nop
    678c:	d503201f 	nop

0000000000006790 <fwp_caps173>:
    6790:	34000041 	cbz	w1, 6798 <fwp_caps173+0x8>
    6794:	d65f03c0 	ret
    6798:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xca0>
    679c:	91150063 	add	x3, x3, #0x540
    67a0:	f949d861 	ldr	x1, [x3, #5040]
    67a4:	f949ec62 	ldr	x2, [x3, #5080]
    67a8:	cb010001 	sub	x1, x0, x1
    67ac:	eb02403f 	cmp	x1, x2, lsl #16
    67b0:	54ffff22 	b.cs	6794 <fwp_caps173+0x4>  // b.hs, b.nlast
    67b4:	d350fc22 	lsr	x2, x1, #16
    67b8:	f949fc65 	ldr	x5, [x3, #5112]
    67bc:	8b020842 	add	x2, x2, x2, lsl #2
    67c0:	d37df042 	lsl	x2, x2, #3
    67c4:	8b0200a4 	add	x4, x5, x2
    67c8:	f9401083 	ldr	x3, [x4, #32]
    67cc:	b4fffe43 	cbz	x3, 6794 <fwp_caps173+0x4>
    67d0:	386268a2 	ldrb	w2, [x5, x2]
    67d4:	7100085f 	cmp	w2, #0x2
    67d8:	540001c0 	b.eq	6810 <fwp_caps173+0x80>  // b.none
    67dc:	7100045f 	cmp	w2, #0x1
    67e0:	54fffda1 	b.ne	6794 <fwp_caps173+0x4>  // b.any
    67e4:	29430885 	ldp	w5, w2, [x4, #24]
    67e8:	92403c21 	and	x1, x1, #0xffff
    67ec:	9b057c21 	mul	x1, x1, x5
    67f0:	d360fc21 	lsr	x1, x1, #32
    67f4:	eb02003f 	cmp	x1, x2
    67f8:	54fffce2 	b.cs	6794 <fwp_caps173+0x4>  // b.hs, b.nlast
    67fc:	8b010063 	add	x3, x3, x1
    6800:	39400061 	ldrb	w1, [x3]
    6804:	7100043f 	cmp	w1, #0x1
    6808:	54fffc61 	b.ne	6794 <fwp_caps173+0x4>  // b.any
    680c:	17fff7f9 	b	47f0 <fwp_mem_free>
    6810:	72003c3f 	tst	w1, #0xffff
    6814:	54ffff60 	b.eq	6800 <fwp_caps173+0x70>  // b.none
    6818:	d65f03c0 	ret
    681c:	d503201f 	nop

0000000000006820 <fwp_args37>:
    6820:	7100003f 	cmp	w1, #0x0
    6824:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6828:	54000041 	b.ne	6830 <fwp_args37+0x10>  // b.any
    682c:	d65f03c0 	ret
    6830:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6834:	91150042 	add	x2, x2, #0x540
    6838:	f9400001 	ldr	x1, [x0]
    683c:	f949d843 	ldr	x3, [x2, #5040]
    6840:	f949ec40 	ldr	x0, [x2, #5080]
    6844:	cb030021 	sub	x1, x1, x3
    6848:	eb00403f 	cmp	x1, x0, lsl #16
    684c:	54ffff02 	b.cs	682c <fwp_args37+0xc>  // b.hs, b.nlast
    6850:	d350fc20 	lsr	x0, x1, #16
    6854:	f949fc44 	ldr	x4, [x2, #5112]
    6858:	8b000800 	add	x0, x0, x0, lsl #2
    685c:	d37df002 	lsl	x2, x0, #3
    6860:	8b020083 	add	x3, x4, x2
    6864:	f9401060 	ldr	x0, [x3, #32]
    6868:	b4fffe20 	cbz	x0, 682c <fwp_args37+0xc>
    686c:	38626882 	ldrb	w2, [x4, x2]
    6870:	7100085f 	cmp	w2, #0x2
    6874:	54000220 	b.eq	68b8 <fwp_args37+0x98>  // b.none
    6878:	7100045f 	cmp	w2, #0x1
    687c:	54fffd81 	b.ne	682c <fwp_args37+0xc>  // b.any
    6880:	29430864 	ldp	w4, w2, [x3, #24]
    6884:	92403c21 	and	x1, x1, #0xffff
    6888:	9b047c21 	mul	x1, x1, x4
    688c:	d360fc21 	lsr	x1, x1, #32
    6890:	eb02003f 	cmp	x1, x2
    6894:	54fffcc2 	b.cs	682c <fwp_args37+0xc>  // b.hs, b.nlast
    6898:	8b010000 	add	x0, x0, x1
    689c:	39400001 	ldrb	w1, [x0]
    68a0:	34fffc61 	cbz	w1, 682c <fwp_args37+0xc>
    68a4:	7103f43f 	cmp	w1, #0xfd
    68a8:	540000e8 	b.hi	68c4 <fwp_args37+0xa4>  // b.pmore
    68ac:	11000421 	add	w1, w1, #0x1
    68b0:	39000001 	strb	w1, [x0]
    68b4:	d65f03c0 	ret
    68b8:	72003c3f 	tst	w1, #0xffff
    68bc:	54ffff00 	b.eq	689c <fwp_args37+0x7c>  // b.none
    68c0:	d65f03c0 	ret
    68c4:	17fff6e4 	b	4454 <fwp_rc_wide_dup>
    68c8:	d503201f 	nop
    68cc:	d503201f 	nop

00000000000068d0 <fwp_caps37>:
    68d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    68d4:	910003fd 	mov	x29, sp
    68d8:	f9000bf3 	str	x19, [sp, #16]
    68dc:	aa0003f3 	mov	x19, x0
    68e0:	b9400400 	ldr	w0, [x0, #4]
    68e4:	340004a0 	cbz	w0, 6978 <fwp_caps37+0xa8>
    68e8:	f9400660 	ldr	x0, [x19, #8]
    68ec:	350004e1 	cbnz	w1, 6988 <fwp_caps37+0xb8>
    68f0:	97fffd90 	bl	5f30 <fwp_drop4>
    68f4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    68f8:	91150042 	add	x2, x2, #0x540
    68fc:	f949d840 	ldr	x0, [x2, #5040]
    6900:	f949ec41 	ldr	x1, [x2, #5080]
    6904:	cb000260 	sub	x0, x19, x0
    6908:	eb01401f 	cmp	x0, x1, lsl #16
    690c:	54000382 	b.cs	697c <fwp_caps37+0xac>  // b.hs, b.nlast
    6910:	d350fc01 	lsr	x1, x0, #16
    6914:	f949fc44 	ldr	x4, [x2, #5112]
    6918:	8b010821 	add	x1, x1, x1, lsl #2
    691c:	d37df021 	lsl	x1, x1, #3
    6920:	8b010083 	add	x3, x4, x1
    6924:	f9401062 	ldr	x2, [x3, #32]
    6928:	b40002a2 	cbz	x2, 697c <fwp_caps37+0xac>
    692c:	38616881 	ldrb	w1, [x4, x1]
    6930:	7100083f 	cmp	w1, #0x2
    6934:	540006c0 	b.eq	6a0c <fwp_caps37+0x13c>  // b.none
    6938:	7100043f 	cmp	w1, #0x1
    693c:	54000201 	b.ne	697c <fwp_caps37+0xac>  // b.any
    6940:	29430464 	ldp	w4, w1, [x3, #24]
    6944:	92403c00 	and	x0, x0, #0xffff
    6948:	9b047c00 	mul	x0, x0, x4
    694c:	d360fc00 	lsr	x0, x0, #32
    6950:	eb01001f 	cmp	x0, x1
    6954:	54000142 	b.cs	697c <fwp_caps37+0xac>  // b.hs, b.nlast
    6958:	8b000042 	add	x2, x2, x0
    695c:	39400040 	ldrb	w0, [x2]
    6960:	7100041f 	cmp	w0, #0x1
    6964:	540000c1 	b.ne	697c <fwp_caps37+0xac>  // b.any
    6968:	aa1303e0 	mov	x0, x19
    696c:	f9400bf3 	ldr	x19, [sp, #16]
    6970:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6974:	17fff79f 	b	47f0 <fwp_mem_free>
    6978:	34fffbe1 	cbz	w1, 68f4 <fwp_caps37+0x24>
    697c:	f9400bf3 	ldr	x19, [sp, #16]
    6980:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6984:	d65f03c0 	ret
    6988:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    698c:	91150042 	add	x2, x2, #0x540
    6990:	f949d843 	ldr	x3, [x2, #5040]
    6994:	f949ec41 	ldr	x1, [x2, #5080]
    6998:	cb030000 	sub	x0, x0, x3
    699c:	eb01401f 	cmp	x0, x1, lsl #16
    69a0:	54fffee2 	b.cs	697c <fwp_caps37+0xac>  // b.hs, b.nlast
    69a4:	d350fc01 	lsr	x1, x0, #16
    69a8:	f949fc44 	ldr	x4, [x2, #5112]
    69ac:	8b010821 	add	x1, x1, x1, lsl #2
    69b0:	d37df021 	lsl	x1, x1, #3
    69b4:	8b010083 	add	x3, x4, x1
    69b8:	f9401062 	ldr	x2, [x3, #32]
    69bc:	b4fffe02 	cbz	x2, 697c <fwp_caps37+0xac>
    69c0:	38616881 	ldrb	w1, [x4, x1]
    69c4:	7100083f 	cmp	w1, #0x2
    69c8:	54000280 	b.eq	6a18 <fwp_caps37+0x148>  // b.none
    69cc:	7100043f 	cmp	w1, #0x1
    69d0:	54fffd61 	b.ne	697c <fwp_caps37+0xac>  // b.any
    69d4:	92403c01 	and	x1, x0, #0xffff
    69d8:	29430064 	ldp	w4, w0, [x3, #24]
    69dc:	9b047c21 	mul	x1, x1, x4
    69e0:	d360fc21 	lsr	x1, x1, #32
    69e4:	eb00003f 	cmp	x1, x0
    69e8:	54fffca2 	b.cs	697c <fwp_caps37+0xac>  // b.hs, b.nlast
    69ec:	8b010042 	add	x2, x2, x1
    69f0:	39400040 	ldrb	w0, [x2]
    69f4:	34fffc40 	cbz	w0, 697c <fwp_caps37+0xac>
    69f8:	7103f41f 	cmp	w0, #0xfd
    69fc:	54000148 	b.hi	6a24 <fwp_caps37+0x154>  // b.pmore
    6a00:	11000400 	add	w0, w0, #0x1
    6a04:	39000040 	strb	w0, [x2]
    6a08:	17ffffdd 	b	697c <fwp_caps37+0xac>
    6a0c:	72003c1f 	tst	w0, #0xffff
    6a10:	54fffb61 	b.ne	697c <fwp_caps37+0xac>  // b.any
    6a14:	17ffffd2 	b	695c <fwp_caps37+0x8c>
    6a18:	72003c1f 	tst	w0, #0xffff
    6a1c:	54fffb01 	b.ne	697c <fwp_caps37+0xac>  // b.any
    6a20:	17fffff4 	b	69f0 <fwp_caps37+0x120>
    6a24:	f9400bf3 	ldr	x19, [sp, #16]
    6a28:	aa0203e0 	mov	x0, x2
    6a2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a30:	17fff689 	b	4454 <fwp_rc_wide_dup>

0000000000006a34 <f37>:
    6a34:	d101c3ff 	sub	sp, sp, #0x70
    6a38:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6a3c:	f947f421 	ldr	x1, [x1, #4072]
    6a40:	a9027bfd 	stp	x29, x30, [sp, #32]
    6a44:	910083fd 	add	x29, sp, #0x20
    6a48:	a90563f7 	stp	x23, x24, [sp, #80]
    6a4c:	f0000157 	adrp	x23, 31000 <fwp_root_context+0xca0>
    6a50:	911502e3 	add	x3, x23, #0x540
    6a54:	a90353f3 	stp	x19, x20, [sp, #48]
    6a58:	a9045bf5 	stp	x21, x22, [sp, #64]
    6a5c:	aa0003f6 	mov	x22, x0
    6a60:	a9066bf9 	stp	x25, x26, [sp, #96]
    6a64:	f949ec62 	ldr	x2, [x3, #5080]
    6a68:	f9400024 	ldr	x4, [x1]
    6a6c:	f9000fe4 	str	x4, [sp, #24]
    6a70:	d2800004 	mov	x4, #0x0                   	// #0
    6a74:	f949d861 	ldr	x1, [x3, #5040]
    6a78:	d370bc42 	lsl	x2, x2, #16
    6a7c:	b40015a0 	cbz	x0, 6d30 <f37+0x2fc>
    6a80:	f9400818 	ldr	x24, [x0, #16]
    6a84:	cb010301 	sub	x1, x24, x1
    6a88:	eb02003f 	cmp	x1, x2
    6a8c:	54000362 	b.cs	6af8 <f37+0xc4>  // b.hs, b.nlast
    6a90:	f949fc60 	ldr	x0, [x3, #5112]
    6a94:	d350fc22 	lsr	x2, x1, #16
    6a98:	8b020842 	add	x2, x2, x2, lsl #2
    6a9c:	8b020c02 	add	x2, x0, x2, lsl #3
    6aa0:	f9401040 	ldr	x0, [x2, #32]
    6aa4:	b40002a0 	cbz	x0, 6af8 <f37+0xc4>
    6aa8:	39400043 	ldrb	w3, [x2]
    6aac:	7100087f 	cmp	w3, #0x2
    6ab0:	540013a0 	b.eq	6d24 <f37+0x2f0>  // b.none
    6ab4:	7100047f 	cmp	w3, #0x1
    6ab8:	540001c1 	b.ne	6af0 <f37+0xbc>  // b.any
    6abc:	29430843 	ldp	w3, w2, [x2, #24]
    6ac0:	92403c21 	and	x1, x1, #0xffff
    6ac4:	9b037c21 	mul	x1, x1, x3
    6ac8:	d360fc21 	lsr	x1, x1, #32
    6acc:	eb02003f 	cmp	x1, x2
    6ad0:	54000102 	b.cs	6af0 <f37+0xbc>  // b.hs, b.nlast
    6ad4:	8b010000 	add	x0, x0, x1
    6ad8:	39400001 	ldrb	w1, [x0]
    6adc:	340000a1 	cbz	w1, 6af0 <f37+0xbc>
    6ae0:	7103f43f 	cmp	w1, #0xfd
    6ae4:	54001688 	b.hi	6db4 <f37+0x380>  // b.pmore
    6ae8:	11000421 	add	w1, w1, #0x1
    6aec:	39000001 	strb	w1, [x0]
    6af0:	d2800000 	mov	x0, #0x0                   	// #0
    6af4:	b40000d6 	cbz	x22, 6b0c <f37+0xd8>
    6af8:	aa1603e1 	mov	x1, x22
    6afc:	d2800000 	mov	x0, #0x0                   	// #0
    6b00:	f9400821 	ldr	x1, [x1, #16]
    6b04:	91000400 	add	x0, x0, #0x1
    6b08:	b5ffffc1 	cbnz	x1, 6b00 <f37+0xcc>
    6b0c:	b40011b8 	cbz	x24, 6d40 <f37+0x30c>
    6b10:	aa1803e1 	mov	x1, x24
    6b14:	d2800002 	mov	x2, #0x0                   	// #0
    6b18:	f9400821 	ldr	x1, [x1, #16]
    6b1c:	91000442 	add	x2, x2, #0x1
    6b20:	b5ffffc1 	cbnz	x1, 6b18 <f37+0xe4>
    6b24:	eb00005f 	cmp	x2, x0
    6b28:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6b2c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    6b30:	eb01033f 	cmp	x25, x1
    6b34:	54001468 	b.hi	6dc0 <f37+0x38c>  // b.pmore
    6b38:	d37ffb33 	lsl	x19, x25, #1
    6b3c:	52800041 	mov	w1, #0x2                   	// #2
    6b40:	91000660 	add	x0, x19, #0x1
    6b44:	d37df000 	lsl	x0, x0, #3
    6b48:	97fff84a 	bl	4c70 <fwp_heap_alloc>
    6b4c:	911502e1 	add	x1, x23, #0x540
    6b50:	aa0003fa 	mov	x26, x0
    6b54:	f9000013 	str	x19, [x0]
    6b58:	aa0103e0 	mov	x0, x1
    6b5c:	f949d821 	ldr	x1, [x1, #5040]
    6b60:	f949ec00 	ldr	x0, [x0, #5080]
    6b64:	cb010341 	sub	x1, x26, x1
    6b68:	eb00403f 	cmp	x1, x0, lsl #16
    6b6c:	54000342 	b.cs	6bd4 <f37+0x1a0>  // b.hs, b.nlast
    6b70:	911502e2 	add	x2, x23, #0x540
    6b74:	d350fc20 	lsr	x0, x1, #16
    6b78:	8b000800 	add	x0, x0, x0, lsl #2
    6b7c:	f949fc43 	ldr	x3, [x2, #5112]
    6b80:	d37df002 	lsl	x2, x0, #3
    6b84:	8b020060 	add	x0, x3, x2
    6b88:	f9401013 	ldr	x19, [x0, #32]
    6b8c:	b4000253 	cbz	x19, 6bd4 <f37+0x1a0>
    6b90:	38626862 	ldrb	w2, [x3, x2]
    6b94:	7100085f 	cmp	w2, #0x2
    6b98:	54000c00 	b.eq	6d18 <f37+0x2e4>  // b.none
    6b9c:	7100045f 	cmp	w2, #0x1
    6ba0:	540001a1 	b.ne	6bd4 <f37+0x1a0>  // b.any
    6ba4:	29430002 	ldp	w2, w0, [x0, #24]
    6ba8:	92403c21 	and	x1, x1, #0xffff
    6bac:	9b027c21 	mul	x1, x1, x2
    6bb0:	d360fc21 	lsr	x1, x1, #32
    6bb4:	eb00003f 	cmp	x1, x0
    6bb8:	540000e2 	b.cs	6bd4 <f37+0x1a0>  // b.hs, b.nlast
    6bbc:	8b010273 	add	x19, x19, x1
    6bc0:	39400260 	ldrb	w0, [x19]
    6bc4:	7103fc1f 	cmp	w0, #0xff
    6bc8:	54000da0 	b.eq	6d7c <f37+0x348>  // b.none
    6bcc:	52800020 	mov	w0, #0x1                   	// #1
    6bd0:	39000260 	strb	w0, [x19]
    6bd4:	b4000259 	cbz	x25, 6c1c <f37+0x1e8>
    6bd8:	8b191359 	add	x25, x26, x25, lsl #4
    6bdc:	aa1a03f3 	mov	x19, x26
    6be0:	aa1603f5 	mov	x21, x22
    6be4:	aa1803f4 	mov	x20, x24
    6be8:	f9400683 	ldr	x3, [x20, #8]
    6bec:	f94006a2 	ldr	x2, [x21, #8]
    6bf0:	f9400861 	ldr	x1, [x3, #16]
    6bf4:	f9400840 	ldr	x0, [x2, #16]
    6bf8:	fd400461 	ldr	d1, [x3, #8]
    6bfc:	fd400440 	ldr	d0, [x2, #8]
    6c00:	97fff95c 	bl	5170 <w120>
    6c04:	f9000660 	str	x0, [x19, #8]
    6c08:	f8010e61 	str	x1, [x19, #16]!
    6c0c:	f9400a94 	ldr	x20, [x20, #16]
    6c10:	f9400ab5 	ldr	x21, [x21, #16]
    6c14:	eb13033f 	cmp	x25, x19
    6c18:	54fffe81 	b.ne	6be8 <f37+0x1b4>  // b.any
    6c1c:	aa1803e0 	mov	x0, x24
    6c20:	97fffcc4 	bl	5f30 <fwp_drop4>
    6c24:	aa1603e0 	mov	x0, x22
    6c28:	97fffcc2 	bl	5f30 <fwp_drop4>
    6c2c:	911502f7 	add	x23, x23, #0x540
    6c30:	aa1a03e0 	mov	x0, x26
    6c34:	97fff993 	bl	5280 <w176.constprop.0>
    6c38:	aa0103f3 	mov	x19, x1
    6c3c:	aa0003f4 	mov	x20, x0
    6c40:	aa1a03e0 	mov	x0, x26
    6c44:	97fffe57 	bl	65a0 <fwp_drop10>
    6c48:	a900cff4 	stp	x20, x19, [sp, #8]
    6c4c:	910023e1 	add	x1, sp, #0x8
    6c50:	52800000 	mov	w0, #0x0                   	// #0
    6c54:	97fff84c 	bl	4d84 <fwp_data.part.0.constprop.0>
    6c58:	f949dae1 	ldr	x1, [x23, #5040]
    6c5c:	aa0003f3 	mov	x19, x0
    6c60:	f949eee0 	ldr	x0, [x23, #5080]
    6c64:	cb010261 	sub	x1, x19, x1
    6c68:	eb00403f 	cmp	x1, x0, lsl #16
    6c6c:	54000322 	b.cs	6cd0 <f37+0x29c>  // b.hs, b.nlast
    6c70:	d350fc22 	lsr	x2, x1, #16
    6c74:	f949fee3 	ldr	x3, [x23, #5112]
    6c78:	8b020842 	add	x2, x2, x2, lsl #2
    6c7c:	d37df042 	lsl	x2, x2, #3
    6c80:	8b020060 	add	x0, x3, x2
    6c84:	f9401014 	ldr	x20, [x0, #32]
    6c88:	b4000254 	cbz	x20, 6cd0 <f37+0x29c>
    6c8c:	38626862 	ldrb	w2, [x3, x2]
    6c90:	7100085f 	cmp	w2, #0x2
    6c94:	540003c0 	b.eq	6d0c <f37+0x2d8>  // b.none
    6c98:	7100045f 	cmp	w2, #0x1
    6c9c:	540001a1 	b.ne	6cd0 <f37+0x29c>  // b.any
    6ca0:	29430002 	ldp	w2, w0, [x0, #24]
    6ca4:	92403c21 	and	x1, x1, #0xffff
    6ca8:	9b027c21 	mul	x1, x1, x2
    6cac:	d360fc21 	lsr	x1, x1, #32
    6cb0:	eb00003f 	cmp	x1, x0
    6cb4:	540000e2 	b.cs	6cd0 <f37+0x29c>  // b.hs, b.nlast
    6cb8:	8b010294 	add	x20, x20, x1
    6cbc:	39400280 	ldrb	w0, [x20]
    6cc0:	7103fc1f 	cmp	w0, #0xff
    6cc4:	54000620 	b.eq	6d88 <f37+0x354>  // b.none
    6cc8:	52800020 	mov	w0, #0x1                   	// #1
    6ccc:	39000280 	strb	w0, [x20]
    6cd0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6cd4:	f947f400 	ldr	x0, [x0, #4072]
    6cd8:	f9400fe2 	ldr	x2, [sp, #24]
    6cdc:	f9400001 	ldr	x1, [x0]
    6ce0:	eb010042 	subs	x2, x2, x1
    6ce4:	d2800001 	mov	x1, #0x0                   	// #0
    6ce8:	540006a1 	b.ne	6dbc <f37+0x388>  // b.any
    6cec:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6cf0:	aa1303e0 	mov	x0, x19
    6cf4:	a94353f3 	ldp	x19, x20, [sp, #48]
    6cf8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6cfc:	a94563f7 	ldp	x23, x24, [sp, #80]
    6d00:	a9466bf9 	ldp	x25, x26, [sp, #96]
    6d04:	9101c3ff 	add	sp, sp, #0x70
    6d08:	d65f03c0 	ret
    6d0c:	72003c3f 	tst	w1, #0xffff
    6d10:	54fffe01 	b.ne	6cd0 <f37+0x29c>  // b.any
    6d14:	17ffffea 	b	6cbc <f37+0x288>
    6d18:	72003c3f 	tst	w1, #0xffff
    6d1c:	54fff5c1 	b.ne	6bd4 <f37+0x1a0>  // b.any
    6d20:	17ffffa8 	b	6bc0 <f37+0x18c>
    6d24:	72003c3f 	tst	w1, #0xffff
    6d28:	54ffee41 	b.ne	6af0 <f37+0xbc>  // b.any
    6d2c:	17ffff6b 	b	6ad8 <f37+0xa4>
    6d30:	cb0103e1 	neg	x1, x1
    6d34:	eb02003f 	cmp	x1, x2
    6d38:	540002e3 	b.cc	6d94 <f37+0x360>  // b.lo, b.ul, b.last
    6d3c:	d503201f 	nop
    6d40:	52800041 	mov	w1, #0x2                   	// #2
    6d44:	d2800100 	mov	x0, #0x8                   	// #8
    6d48:	97fff7ca 	bl	4c70 <fwp_heap_alloc>
    6d4c:	aa0003e1 	mov	x1, x0
    6d50:	911502e0 	add	x0, x23, #0x540
    6d54:	aa0103fa 	mov	x26, x1
    6d58:	d2800018 	mov	x24, #0x0                   	// #0
    6d5c:	f900003f 	str	xzr, [x1]
    6d60:	f949d801 	ldr	x1, [x0, #5040]
    6d64:	f949ec00 	ldr	x0, [x0, #5080]
    6d68:	cb010341 	sub	x1, x26, x1
    6d6c:	eb00403f 	cmp	x1, x0, lsl #16
    6d70:	54fff562 	b.cs	6c1c <f37+0x1e8>  // b.hs, b.nlast
    6d74:	d2800019 	mov	x25, #0x0                   	// #0
    6d78:	17ffff7e 	b	6b70 <f37+0x13c>
    6d7c:	aa1303e0 	mov	x0, x19
    6d80:	97fff5fc 	bl	4570 <fwp_rc_forget_slot>
    6d84:	17ffff92 	b	6bcc <f37+0x198>
    6d88:	aa1403e0 	mov	x0, x20
    6d8c:	97fff5f9 	bl	4570 <fwp_rc_forget_slot>
    6d90:	17ffffce 	b	6cc8 <f37+0x294>
    6d94:	f949fc62 	ldr	x2, [x3, #5112]
    6d98:	d350fc20 	lsr	x0, x1, #16
    6d9c:	8b000800 	add	x0, x0, x0, lsl #2
    6da0:	8b000c42 	add	x2, x2, x0, lsl #3
    6da4:	f9401040 	ldr	x0, [x2, #32]
    6da8:	b4fffcc0 	cbz	x0, 6d40 <f37+0x30c>
    6dac:	d2800018 	mov	x24, #0x0                   	// #0
    6db0:	17ffff3e 	b	6aa8 <f37+0x74>
    6db4:	97fff5a8 	bl	4454 <fwp_rc_wide_dup>
    6db8:	17ffff4e 	b	6af0 <f37+0xbc>
    6dbc:	97ffeeb1 	bl	2880 <__stack_chk_fail@plt>
    6dc0:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    6dc4:	913de000 	add	x0, x0, #0xf78
    6dc8:	97fff1ee 	bl	3580 <fwp_trap>
    6dcc:	d503201f 	nop

0000000000006dd0 <fwp_owned_entry37>:
    6dd0:	f9400000 	ldr	x0, [x0]
    6dd4:	17ffff18 	b	6a34 <f37>
    6dd8:	d503201f 	nop
    6ddc:	d503201f 	nop

0000000000006de0 <e37>:
    6de0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6de4:	910003fd 	mov	x29, sp
    6de8:	f9000bf3 	str	x19, [sp, #16]
    6dec:	f9400013 	ldr	x19, [x0]
    6df0:	aa1303e0 	mov	x0, x19
    6df4:	97fff94b 	bl	5320 <fwp_rc_share>
    6df8:	aa1303e0 	mov	x0, x19
    6dfc:	97ffff0e 	bl	6a34 <f37>
    6e00:	aa0003f3 	mov	x19, x0
    6e04:	97fff947 	bl	5320 <fwp_rc_share>
    6e08:	aa1303e0 	mov	x0, x19
    6e0c:	f9400bf3 	ldr	x19, [sp, #16]
    6e10:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e14:	d65f03c0 	ret
    6e18:	d503201f 	nop
    6e1c:	d503201f 	nop

0000000000006e20 <fwp_write>:
    6e20:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    6e24:	910003fd 	mov	x29, sp
    6e28:	b00000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    6e2c:	f947f484 	ldr	x4, [x4, #4072]
    6e30:	a90153f3 	stp	x19, x20, [sp, #16]
    6e34:	d10943ff 	sub	sp, sp, #0x250
    6e38:	b9400045 	ldr	w5, [x2]
    6e3c:	aa0003f4 	mov	x20, x0
    6e40:	f9400080 	ldr	x0, [x4]
    6e44:	f90127e0 	str	x0, [sp, #584]
    6e48:	d2800000 	mov	x0, #0x0                   	// #0
    6e4c:	710064bf 	cmp	w5, #0x19
    6e50:	54000408 	b.hi	6ed0 <fwp_write+0xb0>  // b.pmore
    6e54:	90000040 	adrp	x0, e000 <_IO_stdin_used+0x470>
    6e58:	aa0103f3 	mov	x19, x1
    6e5c:	911f8000 	add	x0, x0, #0x7e0
    6e60:	f9013bf5 	str	x21, [sp, #624]
    6e64:	f9013ff6 	str	x22, [sp, #632]
    6e68:	f90153fb 	str	x27, [sp, #672]
    6e6c:	f90157fc 	str	x28, [sp, #680]
    6e70:	aa0203fc 	mov	x28, x2
    6e74:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    6e78:	10000061 	adr	x1, 6e84 <fwp_write+0x64>
    6e7c:	8b20a820 	add	x0, x1, w0, sxth #2
    6e80:	d61f0000 	br	x0
    6e84:	910123e0 	add	x0, sp, #0x48
    6e88:	aa1303e5 	mov	x5, x19
    6e8c:	f0000024 	adrp	x4, d000 <fwp_main_thread+0x10d0>
    6e90:	aa0003f3 	mov	x19, x0
    6e94:	913f0084 	add	x4, x4, #0xfc0
    6e98:	d2804003 	mov	x3, #0x200                 	// #512
    6e9c:	aa0303e1 	mov	x1, x3
    6ea0:	52800042 	mov	w2, #0x2                   	// #2
    6ea4:	97ffee53 	bl	27f0 <__snprintf_chk@plt>
    6ea8:	aa1303e0 	mov	x0, x19
    6eac:	97ffee19 	bl	2710 <strlen@plt>
    6eb0:	aa1303e1 	mov	x1, x19
    6eb4:	aa0003e2 	mov	x2, x0
    6eb8:	aa1403e0 	mov	x0, x20
    6ebc:	97fff155 	bl	3410 <buf_put>
    6ec0:	f9413bf5 	ldr	x21, [sp, #624]
    6ec4:	f9413ff6 	ldr	x22, [sp, #632]
    6ec8:	f94153fb 	ldr	x27, [sp, #672]
    6ecc:	f94157fc 	ldr	x28, [sp, #680]
    6ed0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6ed4:	f947f400 	ldr	x0, [x0, #4072]
    6ed8:	f94127e2 	ldr	x2, [sp, #584]
    6edc:	f9400001 	ldr	x1, [x0]
    6ee0:	eb010042 	subs	x2, x2, x1
    6ee4:	d2800001 	mov	x1, #0x0                   	// #0
    6ee8:	540077c1 	b.ne	7de0 <fwp_write+0xfc0>  // b.any
    6eec:	910943ff 	add	sp, sp, #0x250
    6ef0:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ef4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    6ef8:	d65f03c0 	ret
    6efc:	910123e0 	add	x0, sp, #0x48
    6f00:	aa1303e5 	mov	x5, x19
    6f04:	f0000024 	adrp	x4, d000 <fwp_main_thread+0x10d0>
    6f08:	aa0003f3 	mov	x19, x0
    6f0c:	913ee084 	add	x4, x4, #0xfb8
    6f10:	d2804003 	mov	x3, #0x200                 	// #512
    6f14:	17ffffe2 	b	6e9c <fwp_write+0x7c>
    6f18:	71004cbf 	cmp	w5, #0x13
    6f1c:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    6f20:	f0000021 	adrp	x1, d000 <fwp_main_thread+0x10d0>
    6f24:	913ea000 	add	x0, x0, #0xfa8
    6f28:	913ec021 	add	x1, x1, #0xfb0
    6f2c:	d2800082 	mov	x2, #0x4                   	// #4
    6f30:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    6f34:	aa1403e0 	mov	x0, x20
    6f38:	f90143f7 	str	x23, [sp, #640]
    6f3c:	d2800016 	mov	x22, #0x0                   	// #0
    6f40:	f90147f8 	str	x24, [sp, #648]
    6f44:	97fff133 	bl	3410 <buf_put>
    6f48:	f9400260 	ldr	x0, [x19]
    6f4c:	90000057 	adrp	x23, e000 <_IO_stdin_used+0x470>
    6f50:	d2800015 	mov	x21, #0x0                   	// #0
    6f54:	9100c2f7 	add	x23, x23, #0x30
    6f58:	b40047a0 	cbz	x0, 784c <fwp_write+0xa2c>
    6f5c:	b9400380 	ldr	w0, [x28]
    6f60:	52800003 	mov	w3, #0x0                   	// #0
    6f64:	f9401f82 	ldr	x2, [x28, #56]
    6f68:	71004c1f 	cmp	w0, #0x13
    6f6c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    6f70:	aa1403e0 	mov	x0, x20
    6f74:	8b010e61 	add	x1, x19, x1, lsl #3
    6f78:	f9400421 	ldr	x1, [x1, #8]
    6f7c:	97ffffa9 	bl	6e20 <fwp_write>
    6f80:	b9400380 	ldr	w0, [x28]
    6f84:	7100481f 	cmp	w0, #0x12
    6f88:	54004b40 	b.eq	78f0 <fwp_write+0xad0>  // b.none
    6f8c:	f9400260 	ldr	x0, [x19]
    6f90:	910006b5 	add	x21, x21, #0x1
    6f94:	91000ad6 	add	x22, x22, #0x2
    6f98:	eb15001f 	cmp	x0, x21
    6f9c:	54004589 	b.ls	784c <fwp_write+0xa2c>  // b.plast
    6fa0:	aa1703e1 	mov	x1, x23
    6fa4:	aa1403e0 	mov	x0, x20
    6fa8:	d2800042 	mov	x2, #0x2                   	// #2
    6fac:	97fff119 	bl	3410 <buf_put>
    6fb0:	17ffffeb 	b	6f5c <fwp_write+0x13c>
    6fb4:	f0000021 	adrp	x1, d000 <fwp_main_thread+0x10d0>
    6fb8:	913fa021 	add	x1, x1, #0xfe8
    6fbc:	d28000c2 	mov	x2, #0x6                   	// #6
    6fc0:	aa1403e0 	mov	x0, x20
    6fc4:	91004273 	add	x19, x19, #0x10
    6fc8:	97fff112 	bl	3410 <buf_put>
    6fcc:	aa1303e0 	mov	x0, x19
    6fd0:	97ffedd0 	bl	2710 <strlen@plt>
    6fd4:	aa1303e1 	mov	x1, x19
    6fd8:	aa0003e2 	mov	x2, x0
    6fdc:	aa1403e0 	mov	x0, x20
    6fe0:	97fff10c 	bl	3410 <buf_put>
    6fe4:	528007c3 	mov	w3, #0x3e                  	// #62
    6fe8:	aa1403e0 	mov	x0, x20
    6fec:	91001fe1 	add	x1, sp, #0x7
    6ff0:	d2800022 	mov	x2, #0x1                   	// #1
    6ff4:	39001fe3 	strb	w3, [sp, #7]
    6ff8:	17ffffb1 	b	6ebc <fwp_write+0x9c>
    6ffc:	100c0020 	adr	x0, 1f000 <fwp_fn_table+0xc98>
    7000:	f947f400 	ldr	x0, [x0, #4072]
    7004:	f94127e2 	ldr	x2, [sp, #584]
    7008:	f9400001 	ldr	x1, [x0]
    700c:	eb010042 	subs	x2, x2, x1
    7010:	d2800001 	mov	x1, #0x0                   	// #0
    7014:	540034e1 	b.ne	76b0 <fwp_write+0x890>  // b.any
    7018:	f9413bf5 	ldr	x21, [sp, #624]
    701c:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x10d0>
    7020:	f9413ff6 	ldr	x22, [sp, #632]
    7024:	aa1403e0 	mov	x0, x20
    7028:	913f2021 	add	x1, x1, #0xfc8
    702c:	d2800142 	mov	x2, #0xa                   	// #10
    7030:	f94153fb 	ldr	x27, [sp, #672]
    7034:	f94157fc 	ldr	x28, [sp, #680]
    7038:	910943ff 	add	sp, sp, #0x250
    703c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7040:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7044:	17fff0f3 	b	3410 <buf_put>
    7048:	f9400456 	ldr	x22, [x2, #8]
    704c:	f90143f7 	str	x23, [sp, #640]
    7050:	f90147f8 	str	x24, [sp, #648]
    7054:	b4005b16 	cbz	x22, 7bb4 <fwp_write+0xd94>
    7058:	aa1603e0 	mov	x0, x22
    705c:	f0000021 	adrp	x1, e000 <_IO_stdin_used+0x470>
    7060:	91012021 	add	x1, x1, #0x48
    7064:	97ffee27 	bl	2900 <strcmp@plt>
    7068:	2a0003f5 	mov	w21, w0
    706c:	34005fe0 	cbz	w0, 7c68 <fwp_write+0xe48>
    7070:	aa1603e0 	mov	x0, x22
    7074:	97ffeda7 	bl	2710 <strlen@plt>
    7078:	aa1603e1 	mov	x1, x22
    707c:	aa0003e2 	mov	x2, x0
    7080:	aa1403e0 	mov	x0, x20
    7084:	97fff0e3 	bl	3410 <buf_put>
    7088:	52800403 	mov	w3, #0x20                  	// #32
    708c:	91001ff5 	add	x21, sp, #0x7
    7090:	aa1503e1 	mov	x1, x21
    7094:	aa1403e0 	mov	x0, x20
    7098:	d2800022 	mov	x2, #0x1                   	// #1
    709c:	39001fe3 	strb	w3, [sp, #7]
    70a0:	97fff0dc 	bl	3410 <buf_put>
    70a4:	52800f63 	mov	w3, #0x7b                  	// #123
    70a8:	aa1403e0 	mov	x0, x20
    70ac:	aa1503e1 	mov	x1, x21
    70b0:	d2800022 	mov	x2, #0x1                   	// #1
    70b4:	39001fe3 	strb	w3, [sp, #7]
    70b8:	97fff0d6 	bl	3410 <buf_put>
    70bc:	b9401380 	ldr	w0, [x28, #16]
    70c0:	52800018 	mov	w24, #0x0                   	// #0
    70c4:	7100001f 	cmp	w0, #0x0
    70c8:	54003aad 	b.le	781c <fwp_write+0x9fc>
    70cc:	f9014bf9 	str	x25, [sp, #656]
    70d0:	f0000039 	adrp	x25, e000 <_IO_stdin_used+0x470>
    70d4:	9101c339 	add	x25, x25, #0x70
    70d8:	f9014ffa 	str	x26, [sp, #664]
    70dc:	f000003a 	adrp	x26, e000 <_IO_stdin_used+0x470>
    70e0:	9100c35a 	add	x26, x26, #0x30
    70e4:	91002276 	add	x22, x19, #0x8
    70e8:	d2800013 	mov	x19, #0x0                   	// #0
    70ec:	b5003e93 	cbnz	x19, 78bc <fwp_write+0xa9c>
    70f0:	d37df277 	lsl	x23, x19, #3
    70f4:	34003cb8 	cbz	w24, 7888 <fwp_write+0xa68>
    70f8:	f9401382 	ldr	x2, [x28, #32]
    70fc:	aa1403e0 	mov	x0, x20
    7100:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7104:	52800003 	mov	w3, #0x0                   	// #0
    7108:	f8776842 	ldr	x2, [x2, x23]
    710c:	91000673 	add	x19, x19, #0x1
    7110:	97ffff44 	bl	6e20 <fwp_write>
    7114:	b9401380 	ldr	w0, [x28, #16]
    7118:	6b13001f 	cmp	w0, w19
    711c:	54fffe8c 	b.gt	70ec <fwp_write+0x2cc>
    7120:	f9414bf9 	ldr	x25, [sp, #656]
    7124:	f9414ffa 	ldr	x26, [sp, #664]
    7128:	340037b8 	cbz	w24, 781c <fwp_write+0x9fc>
    712c:	52800523 	mov	w3, #0x29                  	// #41
    7130:	aa1503e1 	mov	x1, x21
    7134:	aa1403e0 	mov	x0, x20
    7138:	d2800022 	mov	x2, #0x1                   	// #1
    713c:	39001fe3 	strb	w3, [sp, #7]
    7140:	97fff0b4 	bl	3410 <buf_put>
    7144:	f9413bf5 	ldr	x21, [sp, #624]
    7148:	f9413ff6 	ldr	x22, [sp, #632]
    714c:	f94143f7 	ldr	x23, [sp, #640]
    7150:	f94147f8 	ldr	x24, [sp, #648]
    7154:	f94153fb 	ldr	x27, [sp, #672]
    7158:	f94157fc 	ldr	x28, [sp, #680]
    715c:	17ffff5d 	b	6ed0 <fwp_write+0xb0>
    7160:	b9404855 	ldr	w21, [x2, #72]
    7164:	aa1403e0 	mov	x0, x20
    7168:	93407eb6 	sxtw	x22, w21
    716c:	91000ac1 	add	x1, x22, #0x2
    7170:	97fff075 	bl	3344 <buf_grow>
    7174:	a9400281 	ldp	x1, x0, [x20]
    7178:	528e8603 	mov	w3, #0x7430                	// #29744
    717c:	78206823 	strh	w3, [x1, x0]
    7180:	8b000022 	add	x2, x1, x0
    7184:	710002bf 	cmp	w21, #0x0
    7188:	540036cd 	b.le	7860 <fwp_write+0xa40>
    718c:	110006a3 	add	w3, w21, #0x1
    7190:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7194:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    7198:	91000449 	add	x9, x2, #0x1
    719c:	8b23c043 	add	x3, x2, w3, sxtw
    71a0:	f28aaac6 	movk	x6, #0x5556
    71a4:	f2955568 	movk	x8, #0xaaab
    71a8:	1400000d 	b	71dc <fwp_write+0x3bc>
    71ac:	d2800021 	mov	x1, #0x1                   	// #1
    71b0:	528005a5 	mov	w5, #0x2d                  	// #45
    71b4:	f100001f 	cmp	x0, #0x0
    71b8:	9b467e60 	smulh	x0, x19, x6
    71bc:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    71c0:	381ff465 	strb	w5, [x3], #-1
    71c4:	cb040000 	sub	x0, x0, x4
    71c8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    71cc:	cb020000 	sub	x0, x0, x2
    71d0:	8b010013 	add	x19, x0, x1
    71d4:	eb03013f 	cmp	x9, x3
    71d8:	54003440 	b.eq	7860 <fwp_write+0xa40>  // b.none
    71dc:	9b467e60 	smulh	x0, x19, x6
    71e0:	937ffe64 	asr	x4, x19, #63
    71e4:	52800605 	mov	w5, #0x30                  	// #48
    71e8:	cb040000 	sub	x0, x0, x4
    71ec:	8b000400 	add	x0, x0, x0, lsl #1
    71f0:	cb000260 	sub	x0, x19, x0
    71f4:	91000c01 	add	x1, x0, #0x3
    71f8:	9bc87c22 	umulh	x2, x1, x8
    71fc:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7200:	8b4204e2 	add	x2, x7, x2, lsr #1
    7204:	eb020021 	subs	x1, x1, x2
    7208:	54fffd60 	b.eq	71b4 <fwp_write+0x394>  // b.none
    720c:	f100043f 	cmp	x1, #0x1
    7210:	54fffce1 	b.ne	71ac <fwp_write+0x38c>  // b.any
    7214:	d2800001 	mov	x1, #0x0                   	// #0
    7218:	52800565 	mov	w5, #0x2b                  	// #43
    721c:	17ffffe6 	b	71b4 <fwp_write+0x394>
    7220:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7224:	f947f400 	ldr	x0, [x0, #4072]
    7228:	f94127e2 	ldr	x2, [sp, #584]
    722c:	f9400001 	ldr	x1, [x0]
    7230:	eb010042 	subs	x2, x2, x1
    7234:	d2800001 	mov	x1, #0x0                   	// #0
    7238:	540023c1 	b.ne	76b0 <fwp_write+0x890>  // b.any
    723c:	f9413bf5 	ldr	x21, [sp, #624]
    7240:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x10d0>
    7244:	f9413ff6 	ldr	x22, [sp, #632]
    7248:	aa1403e0 	mov	x0, x20
    724c:	913f6021 	add	x1, x1, #0xfd8
    7250:	d2800102 	mov	x2, #0x8                   	// #8
    7254:	17ffff77 	b	7030 <fwp_write+0x210>
    7258:	aa1403e0 	mov	x0, x20
    725c:	f0000021 	adrp	x1, e000 <_IO_stdin_used+0x470>
    7260:	d28000c2 	mov	x2, #0x6                   	// #6
    7264:	9100e021 	add	x1, x1, #0x38
    7268:	97fff06a 	bl	3410 <buf_put>
    726c:	d2800015 	mov	x21, #0x0                   	// #0
    7270:	f9400263 	ldr	x3, [x19]
    7274:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7278:	54002c60 	b.eq	7804 <fwp_write+0x9e4>  // b.none
    727c:	f9401f82 	ldr	x2, [x28, #56]
    7280:	f90143f7 	str	x23, [sp, #640]
    7284:	f90147f8 	str	x24, [sp, #648]
    7288:	d2800857 	mov	x23, #0x42                  	// #66
    728c:	f9014bf9 	str	x25, [sp, #656]
    7290:	f0000036 	adrp	x22, e000 <_IO_stdin_used+0x470>
    7294:	f9014ffa 	str	x26, [sp, #664]
    7298:	9100c2d6 	add	x22, x22, #0x30
    729c:	d2800038 	mov	x24, #0x1                   	// #1
    72a0:	f2a18017 	movk	x23, #0xc00, lsl #16
    72a4:	d2809099 	mov	x25, #0x484                 	// #1156
    72a8:	b40004a2 	cbz	x2, 733c <fwp_write+0x51c>
    72ac:	b9400040 	ldr	w0, [x2]
    72b0:	7100701f 	cmp	w0, #0x1c
    72b4:	540042c0 	b.eq	7b0c <fwp_write+0xcec>  // b.none
    72b8:	71006c1f 	cmp	w0, #0x1b
    72bc:	54000408 	b.hi	733c <fwp_write+0x51c>  // b.pmore
    72c0:	9ac02301 	lsl	x1, x24, x0
    72c4:	ea17003f 	tst	x1, x23
    72c8:	540036a1 	b.ne	799c <fwp_write+0xb7c>  // b.any
    72cc:	ea19003f 	tst	x1, x25
    72d0:	54003521 	b.ne	7974 <fwp_write+0xb54>  // b.any
    72d4:	d2800424 	mov	x4, #0x21                  	// #33
    72d8:	ea04003f 	tst	x1, x4
    72dc:	54000300 	b.eq	733c <fwp_write+0x51c>  // b.none
    72e0:	b7f849c3 	tbnz	x3, #63, 7c18 <fwp_write+0xdf8>
    72e4:	91002261 	add	x1, x19, #0x8
    72e8:	8b150021 	add	x1, x1, x21
    72ec:	39400021 	ldrb	w1, [x1]
    72f0:	7100001f 	cmp	w0, #0x0
    72f4:	93401c23 	sxtb	x3, w1
    72f8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    72fc:	d503201f 	nop
    7300:	aa1403e0 	mov	x0, x20
    7304:	52800003 	mov	w3, #0x0                   	// #0
    7308:	97fffec6 	bl	6e20 <fwp_write>
    730c:	910006b5 	add	x21, x21, #0x1
    7310:	f9400260 	ldr	x0, [x19]
    7314:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7318:	eb0002bf 	cmp	x21, x0
    731c:	540026c2 	b.cs	77f4 <fwp_write+0x9d4>  // b.hs, b.nlast
    7320:	d2800042 	mov	x2, #0x2                   	// #2
    7324:	aa1603e1 	mov	x1, x22
    7328:	aa1403e0 	mov	x0, x20
    732c:	97fff039 	bl	3410 <buf_put>
    7330:	f9401f82 	ldr	x2, [x28, #56]
    7334:	f9400263 	ldr	x3, [x19]
    7338:	b5fffba2 	cbnz	x2, 72ac <fwp_write+0x48c>
    733c:	d37df2a0 	lsl	x0, x21, #3
    7340:	b7f83f03 	tbnz	x3, #63, 7b20 <fwp_write+0xd00>
    7344:	91002261 	add	x1, x19, #0x8
    7348:	8b000020 	add	x0, x1, x0
    734c:	f9400001 	ldr	x1, [x0]
    7350:	17ffffec 	b	7300 <fwp_write+0x4e0>
    7354:	a9400e62 	ldp	x2, x3, [x19]
    7358:	b7f83ca3 	tbnz	x3, #63, 7aec <fwp_write+0xccc>
    735c:	910123f5 	add	x21, sp, #0x48
    7360:	aa1503e0 	mov	x0, x21
    7364:	97ffeeaf 	bl	2e20 <fwp_fmt_u128>
    7368:	aa1503e0 	mov	x0, x21
    736c:	97ffece9 	bl	2710 <strlen@plt>
    7370:	aa1503e1 	mov	x1, x21
    7374:	aa0003e2 	mov	x2, x0
    7378:	17fffed0 	b	6eb8 <fwp_write+0x98>
    737c:	fd015be8 	str	d8, [sp, #688]
    7380:	1e270268 	fmov	s8, w19
    7384:	fd015fe9 	str	d9, [sp, #696]
    7388:	1e282100 	fcmp	s8, s8
    738c:	54004d26 	b.vs	7d30 <fwp_write+0xf10>
    7390:	1e20c101 	fabs	s1, s8
    7394:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7398:	1e270000 	fmov	s0, w0
    739c:	1e202020 	fcmp	s1, s0
    73a0:	54002c0d 	b.le	7920 <fwp_write+0xb00>
    73a4:	1e202118 	fcmpe	s8, #0.0
    73a8:	d0000022 	adrp	x2, d000 <fwp_main_thread+0x10d0>
    73ac:	912ec042 	add	x2, x2, #0xbb0
    73b0:	910123f5 	add	x21, sp, #0x48
    73b4:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x10d0>
    73b8:	913e2021 	add	x1, x1, #0xf88
    73bc:	aa1503e0 	mov	x0, x21
    73c0:	9a81c041 	csel	x1, x2, x1, gt
    73c4:	97ffed7f 	bl	29c0 <strcpy@plt>
    73c8:	aa1503e0 	mov	x0, x21
    73cc:	97ffecd1 	bl	2710 <strlen@plt>
    73d0:	aa1503e1 	mov	x1, x21
    73d4:	aa0003e2 	mov	x2, x0
    73d8:	aa1403e0 	mov	x0, x20
    73dc:	97fff00d 	bl	3410 <buf_put>
    73e0:	f9413bf5 	ldr	x21, [sp, #624]
    73e4:	f9413ff6 	ldr	x22, [sp, #632]
    73e8:	f94153fb 	ldr	x27, [sp, #672]
    73ec:	f94157fc 	ldr	x28, [sp, #680]
    73f0:	fd415be8 	ldr	d8, [sp, #688]
    73f4:	fd415fe9 	ldr	d9, [sp, #696]
    73f8:	17fffeb6 	b	6ed0 <fwp_write+0xb0>
    73fc:	f9400276 	ldr	x22, [x19]
    7400:	34002e03 	cbz	w3, 79c0 <fwp_write+0xba0>
    7404:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7408:	f947f400 	ldr	x0, [x0, #4072]
    740c:	f94127e2 	ldr	x2, [sp, #584]
    7410:	f9400001 	ldr	x1, [x0]
    7414:	eb010042 	subs	x2, x2, x1
    7418:	d2800001 	mov	x1, #0x0                   	// #0
    741c:	540014a1 	b.ne	76b0 <fwp_write+0x890>  // b.any
    7420:	aa1603e2 	mov	x2, x22
    7424:	91002261 	add	x1, x19, #0x8
    7428:	f9413bf5 	ldr	x21, [sp, #624]
    742c:	aa1403e0 	mov	x0, x20
    7430:	f9413ff6 	ldr	x22, [sp, #632]
    7434:	17fffeff 	b	7030 <fwp_write+0x210>
    7438:	fd015be8 	str	d8, [sp, #688]
    743c:	9e670268 	fmov	d8, x19
    7440:	fd015fe9 	str	d9, [sp, #696]
    7444:	1e682100 	fcmp	d8, d8
    7448:	54004746 	b.vs	7d30 <fwp_write+0xf10>
    744c:	1e60c101 	fabs	d1, d8
    7450:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7454:	9e670000 	fmov	d0, x0
    7458:	910123f5 	add	x21, sp, #0x48
    745c:	52800033 	mov	w19, #0x1                   	// #1
    7460:	1e602020 	fcmp	d1, d0
    7464:	540001ad 	b.le	7498 <fwp_write+0x678>
    7468:	1e602118 	fcmpe	d8, #0.0
    746c:	d0000022 	adrp	x2, d000 <fwp_main_thread+0x10d0>
    7470:	912ec042 	add	x2, x2, #0xbb0
    7474:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x10d0>
    7478:	913e2021 	add	x1, x1, #0xf88
    747c:	aa1503e0 	mov	x0, x21
    7480:	9a81c041 	csel	x1, x2, x1, gt
    7484:	97ffed4f 	bl	29c0 <strcpy@plt>
    7488:	17ffffd0 	b	73c8 <fwp_write+0x5a8>
    748c:	11000673 	add	w19, w19, #0x1
    7490:	71004a7f 	cmp	w19, #0x12
    7494:	54003860 	b.eq	7ba0 <fwp_write+0xd80>  // b.none
    7498:	1e604100 	fmov	d0, d8
    749c:	2a1303e1 	mov	w1, w19
    74a0:	aa1503e0 	mov	x0, x21
    74a4:	97fff11c 	bl	3914 <fwp_format_g.constprop.0>
    74a8:	aa1503e0 	mov	x0, x21
    74ac:	d2800001 	mov	x1, #0x0                   	// #0
    74b0:	97ffecac 	bl	2760 <strtod@plt>
    74b4:	1e602100 	fcmp	d8, d0
    74b8:	54fffea1 	b.ne	748c <fwp_write+0x66c>  // b.any
    74bc:	aa1503e0 	mov	x0, x21
    74c0:	97fff00d 	bl	34f4 <fwp_finish_float>
    74c4:	17ffffc1 	b	73c8 <fwp_write+0x5a8>
    74c8:	a9400e62 	ldp	x2, x3, [x19]
    74cc:	910123f3 	add	x19, sp, #0x48
    74d0:	aa1303e0 	mov	x0, x19
    74d4:	97ffee53 	bl	2e20 <fwp_fmt_u128>
    74d8:	17fffe74 	b	6ea8 <fwp_write+0x88>
    74dc:	f90143f7 	str	x23, [sp, #640]
    74e0:	f90147f8 	str	x24, [sp, #648]
    74e4:	2a1303f8 	mov	w24, w19
    74e8:	f9014bf9 	str	x25, [sp, #656]
    74ec:	f9014ffa 	str	x26, [sp, #664]
    74f0:	f13ffe7f 	cmp	x19, #0xfff
    74f4:	54000049 	b.ls	74fc <fwp_write+0x6dc>  // b.plast
    74f8:	b9400278 	ldr	w24, [x19]
    74fc:	f9400f80 	ldr	x0, [x28, #24]
    7500:	2a1803f5 	mov	w21, w24
    7504:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7508:	d37ef6b9 	lsl	x25, x21, #2
    750c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7510:	aa1603e0 	mov	x0, x22
    7514:	97ffec7f 	bl	2710 <strlen@plt>
    7518:	aa1603e1 	mov	x1, x22
    751c:	aa0003e2 	mov	x2, x0
    7520:	aa1403e0 	mov	x0, x20
    7524:	97ffefbb 	bl	3410 <buf_put>
    7528:	f9401780 	ldr	x0, [x28, #40]
    752c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7530:	7100001f 	cmp	w0, #0x0
    7534:	5400068d 	b.le	7604 <fwp_write+0x7e4>
    7538:	91002276 	add	x22, x19, #0x8
    753c:	91001ff5 	add	x21, sp, #0x7
    7540:	d280001b 	mov	x27, #0x0                   	// #0
    7544:	5280041a 	mov	w26, #0x20                  	// #32
    7548:	f9401b80 	ldr	x0, [x28, #48]
    754c:	aa1503e1 	mov	x1, x21
    7550:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7554:	d2800022 	mov	x2, #0x1                   	// #1
    7558:	f8786803 	ldr	x3, [x0, x24]
    755c:	aa1403e0 	mov	x0, x20
    7560:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7564:	39001ffa 	strb	w26, [sp, #7]
    7568:	97ffefaa 	bl	3410 <buf_put>
    756c:	f13ffeff 	cmp	x23, #0xfff
    7570:	b9400261 	ldr	w1, [x19]
    7574:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7578:	7100383f 	cmp	w1, #0xe
    757c:	54000160 	b.eq	75a8 <fwp_write+0x788>  // b.none
    7580:	7100403f 	cmp	w1, #0x10
    7584:	54001a60 	b.eq	78d0 <fwp_write+0xab0>  // b.none
    7588:	7100283f 	cmp	w1, #0xa
    758c:	54002aa0 	b.eq	7ae0 <fwp_write+0xcc0>  // b.none
    7590:	540014ac 	b.gt	7824 <fwp_write+0xa04>
    7594:	71000c3f 	cmp	w1, #0x3
    7598:	540029ac 	b.gt	7acc <fwp_write+0xcac>
    759c:	d37ffee0 	lsr	x0, x23, #63
    75a0:	37f814a1 	tbnz	w1, #31, 7834 <fwp_write+0xa14>
    75a4:	d503201f 	nop
    75a8:	34001460 	cbz	w0, 7834 <fwp_write+0xa14>
    75ac:	52800503 	mov	w3, #0x28                  	// #40
    75b0:	aa1503e1 	mov	x1, x21
    75b4:	aa1403e0 	mov	x0, x20
    75b8:	d2800022 	mov	x2, #0x1                   	// #1
    75bc:	39001fe3 	strb	w3, [sp, #7]
    75c0:	97ffef94 	bl	3410 <buf_put>
    75c4:	aa1303e2 	mov	x2, x19
    75c8:	aa1703e1 	mov	x1, x23
    75cc:	aa1403e0 	mov	x0, x20
    75d0:	52800003 	mov	w3, #0x0                   	// #0
    75d4:	97fffe13 	bl	6e20 <fwp_write>
    75d8:	52800523 	mov	w3, #0x29                  	// #41
    75dc:	aa1503e1 	mov	x1, x21
    75e0:	aa1403e0 	mov	x0, x20
    75e4:	d2800022 	mov	x2, #0x1                   	// #1
    75e8:	39001fe3 	strb	w3, [sp, #7]
    75ec:	97ffef89 	bl	3410 <buf_put>
    75f0:	f9401780 	ldr	x0, [x28, #40]
    75f4:	9100077b 	add	x27, x27, #0x1
    75f8:	b8796800 	ldr	w0, [x0, x25]
    75fc:	6b1b001f 	cmp	w0, w27
    7600:	54fffa4c 	b.gt	7548 <fwp_write+0x728>
    7604:	f9413bf5 	ldr	x21, [sp, #624]
    7608:	f9413ff6 	ldr	x22, [sp, #632]
    760c:	f94143f7 	ldr	x23, [sp, #640]
    7610:	f94147f8 	ldr	x24, [sp, #648]
    7614:	f9414bf9 	ldr	x25, [sp, #656]
    7618:	f9414ffa 	ldr	x26, [sp, #664]
    761c:	f94153fb 	ldr	x27, [sp, #672]
    7620:	f94157fc 	ldr	x28, [sp, #680]
    7624:	17fffe2b 	b	6ed0 <fwp_write+0xb0>
    7628:	52800783 	mov	w3, #0x3c                  	// #60
    762c:	91001ff3 	add	x19, sp, #0x7
    7630:	aa1303e1 	mov	x1, x19
    7634:	d2800022 	mov	x2, #0x1                   	// #1
    7638:	aa1403e0 	mov	x0, x20
    763c:	39001fe3 	strb	w3, [sp, #7]
    7640:	97ffef74 	bl	3410 <buf_put>
    7644:	f9400795 	ldr	x21, [x28, #8]
    7648:	aa1503e0 	mov	x0, x21
    764c:	97ffec31 	bl	2710 <strlen@plt>
    7650:	aa1503e1 	mov	x1, x21
    7654:	aa0003e2 	mov	x2, x0
    7658:	aa1403e0 	mov	x0, x20
    765c:	97ffef6d 	bl	3410 <buf_put>
    7660:	528007c3 	mov	w3, #0x3e                  	// #62
    7664:	aa1303e1 	mov	x1, x19
    7668:	aa1403e0 	mov	x0, x20
    766c:	d2800022 	mov	x2, #0x1                   	// #1
    7670:	39001fe3 	strb	w3, [sp, #7]
    7674:	17fffe12 	b	6ebc <fwp_write+0x9c>
    7678:	f100067f 	cmp	x19, #0x1
    767c:	540025a0 	b.eq	7b30 <fwp_write+0xd10>  // b.none
    7680:	b100067f 	cmn	x19, #0x1
    7684:	54002bc0 	b.eq	7bfc <fwp_write+0xddc>  // b.none
    7688:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x10d0>
    768c:	913e4021 	add	x1, x1, #0xf90
    7690:	d2800022 	mov	x2, #0x1                   	// #1
    7694:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7698:	f947f400 	ldr	x0, [x0, #4072]
    769c:	f94127e4 	ldr	x4, [sp, #584]
    76a0:	f9400003 	ldr	x3, [x0]
    76a4:	eb030084 	subs	x4, x4, x3
    76a8:	d2800003 	mov	x3, #0x0                   	// #0
    76ac:	54ffebe0 	b.eq	7428 <fwp_write+0x608>  // b.none
    76b0:	f90143f7 	str	x23, [sp, #640]
    76b4:	f90147f8 	str	x24, [sp, #648]
    76b8:	f9014bf9 	str	x25, [sp, #656]
    76bc:	f9014ffa 	str	x26, [sp, #664]
    76c0:	fd015be8 	str	d8, [sp, #688]
    76c4:	fd015fe9 	str	d9, [sp, #696]
    76c8:	97ffec6e 	bl	2880 <__stack_chk_fail@plt>
    76cc:	52800b63 	mov	w3, #0x5b                  	// #91
    76d0:	91001ff5 	add	x21, sp, #0x7
    76d4:	aa1503e1 	mov	x1, x21
    76d8:	aa1403e0 	mov	x0, x20
    76dc:	d2800022 	mov	x2, #0x1                   	// #1
    76e0:	f0000036 	adrp	x22, e000 <_IO_stdin_used+0x470>
    76e4:	9100c2d6 	add	x22, x22, #0x30
    76e8:	39001fe3 	strb	w3, [sp, #7]
    76ec:	97ffef49 	bl	3410 <buf_put>
    76f0:	b4000273 	cbz	x19, 773c <fwp_write+0x91c>
    76f4:	f9400661 	ldr	x1, [x19, #8]
    76f8:	aa1403e0 	mov	x0, x20
    76fc:	f9401f82 	ldr	x2, [x28, #56]
    7700:	52800003 	mov	w3, #0x0                   	// #0
    7704:	97fffdc7 	bl	6e20 <fwp_write>
    7708:	f9400a73 	ldr	x19, [x19, #16]
    770c:	b4000193 	cbz	x19, 773c <fwp_write+0x91c>
    7710:	aa1603e1 	mov	x1, x22
    7714:	aa1403e0 	mov	x0, x20
    7718:	d2800042 	mov	x2, #0x2                   	// #2
    771c:	97ffef3d 	bl	3410 <buf_put>
    7720:	f9400661 	ldr	x1, [x19, #8]
    7724:	aa1403e0 	mov	x0, x20
    7728:	f9401f82 	ldr	x2, [x28, #56]
    772c:	52800003 	mov	w3, #0x0                   	// #0
    7730:	97fffdbc 	bl	6e20 <fwp_write>
    7734:	f9400a73 	ldr	x19, [x19, #16]
    7738:	b5fffed3 	cbnz	x19, 7710 <fwp_write+0x8f0>
    773c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7740:	aa1503e1 	mov	x1, x21
    7744:	aa1403e0 	mov	x0, x20
    7748:	d2800022 	mov	x2, #0x1                   	// #1
    774c:	39001fe3 	strb	w3, [sp, #7]
    7750:	17fffddb 	b	6ebc <fwp_write+0x9c>
    7754:	aa1403e0 	mov	x0, x20
    7758:	f0000021 	adrp	x1, e000 <_IO_stdin_used+0x470>
    775c:	d28000c2 	mov	x2, #0x6                   	// #6
    7760:	91008021 	add	x1, x1, #0x20
    7764:	97ffef2b 	bl	3410 <buf_put>
    7768:	f9400260 	ldr	x0, [x19]
    776c:	b40004c0 	cbz	x0, 7804 <fwp_write+0x9e4>
    7770:	910123f5 	add	x21, sp, #0x48
    7774:	91002276 	add	x22, x19, #0x8
    7778:	f90143f7 	str	x23, [sp, #640]
    777c:	d2800017 	mov	x23, #0x0                   	// #0
    7780:	f90147f8 	str	x24, [sp, #648]
    7784:	f0000038 	adrp	x24, e000 <_IO_stdin_used+0x470>
    7788:	9100a318 	add	x24, x24, #0x28
    778c:	f9014bf9 	str	x25, [sp, #656]
    7790:	f0000039 	adrp	x25, e000 <_IO_stdin_used+0x470>
    7794:	9100c339 	add	x25, x25, #0x30
    7798:	f9014ffa 	str	x26, [sp, #664]
    779c:	14000005 	b	77b0 <fwp_write+0x990>
    77a0:	aa1903e1 	mov	x1, x25
    77a4:	aa1403e0 	mov	x0, x20
    77a8:	d2800042 	mov	x2, #0x2                   	// #2
    77ac:	97ffef19 	bl	3410 <buf_put>
    77b0:	38776ac5 	ldrb	w5, [x22, x23]
    77b4:	d2804003 	mov	x3, #0x200                 	// #512
    77b8:	aa1803e4 	mov	x4, x24
    77bc:	aa0303e1 	mov	x1, x3
    77c0:	52800042 	mov	w2, #0x2                   	// #2
    77c4:	aa1503e0 	mov	x0, x21
    77c8:	910006f7 	add	x23, x23, #0x1
    77cc:	97ffec09 	bl	27f0 <__snprintf_chk@plt>
    77d0:	aa1503e0 	mov	x0, x21
    77d4:	97ffebcf 	bl	2710 <strlen@plt>
    77d8:	aa1503e1 	mov	x1, x21
    77dc:	aa0003e2 	mov	x2, x0
    77e0:	aa1403e0 	mov	x0, x20
    77e4:	97ffef0b 	bl	3410 <buf_put>
    77e8:	f9400260 	ldr	x0, [x19]
    77ec:	eb17001f 	cmp	x0, x23
    77f0:	54fffd88 	b.hi	77a0 <fwp_write+0x980>  // b.pmore
    77f4:	f94143f7 	ldr	x23, [sp, #640]
    77f8:	f94147f8 	ldr	x24, [sp, #648]
    77fc:	f9414bf9 	ldr	x25, [sp, #656]
    7800:	f9414ffa 	ldr	x26, [sp, #664]
    7804:	52800ba3 	mov	w3, #0x5d                  	// #93
    7808:	aa1403e0 	mov	x0, x20
    780c:	91001fe1 	add	x1, sp, #0x7
    7810:	d2800022 	mov	x2, #0x1                   	// #1
    7814:	39001fe3 	strb	w3, [sp, #7]
    7818:	17fffda9 	b	6ebc <fwp_write+0x9c>
    781c:	52800fa3 	mov	w3, #0x7d                  	// #125
    7820:	17fffe44 	b	7130 <fwp_write+0x310>
    7824:	f10002ff 	cmp	x23, #0x0
    7828:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    782c:	71002c3f 	cmp	w1, #0xb
    7830:	54ffebc0 	b.eq	75a8 <fwp_write+0x788>  // b.none
    7834:	aa1303e2 	mov	x2, x19
    7838:	aa1703e1 	mov	x1, x23
    783c:	aa1403e0 	mov	x0, x20
    7840:	52800003 	mov	w3, #0x0                   	// #0
    7844:	97fffd77 	bl	6e20 <fwp_write>
    7848:	17ffff6a 	b	75f0 <fwp_write+0x7d0>
    784c:	aa1403e0 	mov	x0, x20
    7850:	91001fe1 	add	x1, sp, #0x7
    7854:	52800fa3 	mov	w3, #0x7d                  	// #125
    7858:	d2800022 	mov	x2, #0x1                   	// #1
    785c:	17fffe38 	b	713c <fwp_write+0x31c>
    7860:	a9400281 	ldp	x1, x0, [x20]
    7864:	91000800 	add	x0, x0, #0x2
    7868:	8b160000 	add	x0, x0, x22
    786c:	f9000680 	str	x0, [x20, #8]
    7870:	3820683f 	strb	wzr, [x1, x0]
    7874:	f9413bf5 	ldr	x21, [sp, #624]
    7878:	f9413ff6 	ldr	x22, [sp, #632]
    787c:	f94153fb 	ldr	x27, [sp, #672]
    7880:	f94157fc 	ldr	x28, [sp, #680]
    7884:	17fffd93 	b	6ed0 <fwp_write+0xb0>
    7888:	f9400f80 	ldr	x0, [x28, #24]
    788c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7890:	aa1b03e0 	mov	x0, x27
    7894:	97ffeb9f 	bl	2710 <strlen@plt>
    7898:	aa1b03e1 	mov	x1, x27
    789c:	aa0003e2 	mov	x2, x0
    78a0:	aa1403e0 	mov	x0, x20
    78a4:	97ffeedb 	bl	3410 <buf_put>
    78a8:	aa1903e1 	mov	x1, x25
    78ac:	aa1403e0 	mov	x0, x20
    78b0:	d2800062 	mov	x2, #0x3                   	// #3
    78b4:	97ffeed7 	bl	3410 <buf_put>
    78b8:	17fffe10 	b	70f8 <fwp_write+0x2d8>
    78bc:	aa1a03e1 	mov	x1, x26
    78c0:	aa1403e0 	mov	x0, x20
    78c4:	d2800042 	mov	x2, #0x2                   	// #2
    78c8:	97ffeed2 	bl	3410 <buf_put>
    78cc:	17fffe09 	b	70f0 <fwp_write+0x2d0>
    78d0:	f9400660 	ldr	x0, [x19, #8]
    78d4:	b4fffb00 	cbz	x0, 7834 <fwp_write+0xa14>
    78d8:	f0000021 	adrp	x1, e000 <_IO_stdin_used+0x470>
    78dc:	91012021 	add	x1, x1, #0x48
    78e0:	97ffec08 	bl	2900 <strcmp@plt>
    78e4:	7100001f 	cmp	w0, #0x0
    78e8:	1a9f07e0 	cset	w0, ne	// ne = any
    78ec:	17ffff2f 	b	75a8 <fwp_write+0x788>
    78f0:	aa1403e0 	mov	x0, x20
    78f4:	d2800042 	mov	x2, #0x2                   	// #2
    78f8:	f0000021 	adrp	x1, e000 <_IO_stdin_used+0x470>
    78fc:	91010021 	add	x1, x1, #0x40
    7900:	97ffeec4 	bl	3410 <buf_put>
    7904:	91004261 	add	x1, x19, #0x10
    7908:	aa1403e0 	mov	x0, x20
    790c:	f9402382 	ldr	x2, [x28, #64]
    7910:	52800003 	mov	w3, #0x0                   	// #0
    7914:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7918:	97fffd42 	bl	6e20 <fwp_write>
    791c:	17fffd9c 	b	6f8c <fwp_write+0x16c>
    7920:	1e22c109 	fcvt	d9, s8
    7924:	910123f5 	add	x21, sp, #0x48
    7928:	52800033 	mov	w19, #0x1                   	// #1
    792c:	d503201f 	nop
    7930:	1e604120 	fmov	d0, d9
    7934:	2a1303e1 	mov	w1, w19
    7938:	aa1503e0 	mov	x0, x21
    793c:	97ffeff6 	bl	3914 <fwp_format_g.constprop.0>
    7940:	aa1503e0 	mov	x0, x21
    7944:	d2800001 	mov	x1, #0x0                   	// #0
    7948:	97ffebfa 	bl	2930 <strtof@plt>
    794c:	1e202100 	fcmp	s8, s0
    7950:	54ffdb60 	b.eq	74bc <fwp_write+0x69c>  // b.none
    7954:	11000673 	add	w19, w19, #0x1
    7958:	71002a7f 	cmp	w19, #0xa
    795c:	54fffea1 	b.ne	7930 <fwp_write+0xb10>  // b.any
    7960:	1e604120 	fmov	d0, d9
    7964:	aa1503e0 	mov	x0, x21
    7968:	52800121 	mov	w1, #0x9                   	// #9
    796c:	97ffefea 	bl	3914 <fwp_format_g.constprop.0>
    7970:	17fffed3 	b	74bc <fwp_write+0x69c>
    7974:	d37ef6a1 	lsl	x1, x21, #2
    7978:	b7f81563 	tbnz	x3, #63, 7c24 <fwp_write+0xe04>
    797c:	91002263 	add	x3, x19, #0x8
    7980:	8b010061 	add	x1, x3, x1
    7984:	b9400023 	ldr	w3, [x1]
    7988:	7100081f 	cmp	w0, #0x2
    798c:	2a0303e1 	mov	w1, w3
    7990:	93407c63 	sxtw	x3, w3
    7994:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7998:	17fffe5a 	b	7300 <fwp_write+0x4e0>
    799c:	d37ffaa1 	lsl	x1, x21, #1
    79a0:	b7f81363 	tbnz	x3, #63, 7c0c <fwp_write+0xdec>
    79a4:	91002263 	add	x3, x19, #0x8
    79a8:	8b010061 	add	x1, x3, x1
    79ac:	79400021 	ldrh	w1, [x1]
    79b0:	7100041f 	cmp	w0, #0x1
    79b4:	93403c23 	sxth	x3, w1
    79b8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    79bc:	17fffe51 	b	7300 <fwp_write+0x4e0>
    79c0:	52800443 	mov	w3, #0x22                  	// #34
    79c4:	91001ff5 	add	x21, sp, #0x7
    79c8:	91002273 	add	x19, x19, #0x8
    79cc:	aa1503e1 	mov	x1, x21
    79d0:	aa1403e0 	mov	x0, x20
    79d4:	d2800022 	mov	x2, #0x1                   	// #1
    79d8:	39001fe3 	strb	w3, [sp, #7]
    79dc:	f90143f7 	str	x23, [sp, #640]
    79e0:	8b160277 	add	x23, x19, x22
    79e4:	f90147f8 	str	x24, [sp, #648]
    79e8:	97ffee8a 	bl	3410 <buf_put>
    79ec:	b4000696 	cbz	x22, 7abc <fwp_write+0xc9c>
    79f0:	d0000038 	adrp	x24, d000 <fwp_main_thread+0x10d0>
    79f4:	913fc318 	add	x24, x24, #0xff0
    79f8:	f9014bf9 	str	x25, [sp, #656]
    79fc:	f0000039 	adrp	x25, e000 <_IO_stdin_used+0x470>
    7a00:	91004339 	add	x25, x25, #0x10
    7a04:	f9014ffa 	str	x26, [sp, #664]
    7a08:	1400000d 	b	7a3c <fwp_write+0xc1c>
    7a0c:	710024bf 	cmp	w5, #0x9
    7a10:	54000460 	b.eq	7a9c <fwp_write+0xc7c>  // b.none
    7a14:	710028bf 	cmp	w5, #0xa
    7a18:	54000a61 	b.ne	7b64 <fwp_write+0xd44>  // b.any
    7a1c:	f0000021 	adrp	x1, e000 <_IO_stdin_used+0x470>
    7a20:	aa1403e0 	mov	x0, x20
    7a24:	91000021 	add	x1, x1, #0x0
    7a28:	d2800042 	mov	x2, #0x2                   	// #2
    7a2c:	97ffee79 	bl	3410 <buf_put>
    7a30:	91000673 	add	x19, x19, #0x1
    7a34:	eb17027f 	cmp	x19, x23
    7a38:	540003e0 	b.eq	7ab4 <fwp_write+0xc94>  // b.none
    7a3c:	39400265 	ldrb	w5, [x19]
    7a40:	710034bf 	cmp	w5, #0xd
    7a44:	54000180 	b.eq	7a74 <fwp_write+0xc54>  // b.none
    7a48:	54fffe29 	b.ls	7a0c <fwp_write+0xbec>  // b.plast
    7a4c:	710088bf 	cmp	w5, #0x22
    7a50:	540001c0 	b.eq	7a88 <fwp_write+0xc68>  // b.none
    7a54:	710170bf 	cmp	w5, #0x5c
    7a58:	54000741 	b.ne	7b40 <fwp_write+0xd20>  // b.any
    7a5c:	aa1403e0 	mov	x0, x20
    7a60:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x10d0>
    7a64:	d2800042 	mov	x2, #0x2                   	// #2
    7a68:	913fe021 	add	x1, x1, #0xff8
    7a6c:	97ffee69 	bl	3410 <buf_put>
    7a70:	17fffff0 	b	7a30 <fwp_write+0xc10>
    7a74:	aa1903e1 	mov	x1, x25
    7a78:	aa1403e0 	mov	x0, x20
    7a7c:	d2800042 	mov	x2, #0x2                   	// #2
    7a80:	97ffee64 	bl	3410 <buf_put>
    7a84:	17ffffeb 	b	7a30 <fwp_write+0xc10>
    7a88:	aa1803e1 	mov	x1, x24
    7a8c:	aa1403e0 	mov	x0, x20
    7a90:	d2800042 	mov	x2, #0x2                   	// #2
    7a94:	97ffee5f 	bl	3410 <buf_put>
    7a98:	17ffffe6 	b	7a30 <fwp_write+0xc10>
    7a9c:	aa1403e0 	mov	x0, x20
    7aa0:	f0000021 	adrp	x1, e000 <_IO_stdin_used+0x470>
    7aa4:	d2800042 	mov	x2, #0x2                   	// #2
    7aa8:	91002021 	add	x1, x1, #0x8
    7aac:	97ffee59 	bl	3410 <buf_put>
    7ab0:	17ffffe0 	b	7a30 <fwp_write+0xc10>
    7ab4:	f9414bf9 	ldr	x25, [sp, #656]
    7ab8:	f9414ffa 	ldr	x26, [sp, #664]
    7abc:	aa1503e1 	mov	x1, x21
    7ac0:	aa1403e0 	mov	x0, x20
    7ac4:	52800443 	mov	w3, #0x22                  	// #34
    7ac8:	17fffd9c 	b	7138 <fwp_write+0x318>
    7acc:	7100103f 	cmp	w1, #0x4
    7ad0:	54ffeb21 	b.ne	7834 <fwp_write+0xa14>  // b.any
    7ad4:	f94006e0 	ldr	x0, [x23, #8]
    7ad8:	d37ffc00 	lsr	x0, x0, #63
    7adc:	17fffeb3 	b	75a8 <fwp_write+0x788>
    7ae0:	710002ff 	cmp	w23, #0x0
    7ae4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7ae8:	17fffeb0 	b	75a8 <fwp_write+0x788>
    7aec:	528005a1 	mov	w1, #0x2d                  	// #45
    7af0:	eb0203e2 	negs	x2, x2
    7af4:	da0303e3 	ngc	x3, x3
    7af8:	910127e0 	add	x0, sp, #0x49
    7afc:	910123f5 	add	x21, sp, #0x48
    7b00:	390123e1 	strb	w1, [sp, #72]
    7b04:	97ffecc7 	bl	2e20 <fwp_fmt_u128>
    7b08:	17fffe18 	b	7368 <fwp_write+0x548>
    7b0c:	d37ceea1 	lsl	x1, x21, #4
    7b10:	b7f810a3 	tbnz	x3, #63, 7d24 <fwp_write+0xf04>
    7b14:	91002260 	add	x0, x19, #0x8
    7b18:	8b010001 	add	x1, x0, x1
    7b1c:	17fffdf9 	b	7300 <fwp_write+0x4e0>
    7b20:	f9400a61 	ldr	x1, [x19, #16]
    7b24:	8b010000 	add	x0, x0, x1
    7b28:	f9400001 	ldr	x1, [x0]
    7b2c:	17fffdf5 	b	7300 <fwp_write+0x4e0>
    7b30:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x10d0>
    7b34:	d2800042 	mov	x2, #0x2                   	// #2
    7b38:	913e6021 	add	x1, x1, #0xf98
    7b3c:	17fffed6 	b	7694 <fwp_write+0x874>
    7b40:	7101fcbf 	cmp	w5, #0x7f
    7b44:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7b48:	540000e9 	b.ls	7b64 <fwp_write+0xd44>  // b.plast
    7b4c:	aa1503e1 	mov	x1, x21
    7b50:	aa1403e0 	mov	x0, x20
    7b54:	d2800022 	mov	x2, #0x1                   	// #1
    7b58:	39001fe5 	strb	w5, [sp, #7]
    7b5c:	97ffee2d 	bl	3410 <buf_put>
    7b60:	17ffffb4 	b	7a30 <fwp_write+0xc10>
    7b64:	d2800203 	mov	x3, #0x10                  	// #16
    7b68:	f0000024 	adrp	x4, e000 <_IO_stdin_used+0x470>
    7b6c:	aa0303e1 	mov	x1, x3
    7b70:	91006084 	add	x4, x4, #0x18
    7b74:	910123f6 	add	x22, sp, #0x48
    7b78:	52800042 	mov	w2, #0x2                   	// #2
    7b7c:	aa1603e0 	mov	x0, x22
    7b80:	97ffeb1c 	bl	27f0 <__snprintf_chk@plt>
    7b84:	aa1603e0 	mov	x0, x22
    7b88:	97ffeae2 	bl	2710 <strlen@plt>
    7b8c:	aa1603e1 	mov	x1, x22
    7b90:	aa0003e2 	mov	x2, x0
    7b94:	aa1403e0 	mov	x0, x20
    7b98:	97ffee1e 	bl	3410 <buf_put>
    7b9c:	17ffffa5 	b	7a30 <fwp_write+0xc10>
    7ba0:	1e604100 	fmov	d0, d8
    7ba4:	aa1503e0 	mov	x0, x21
    7ba8:	52800221 	mov	w1, #0x11                  	// #17
    7bac:	97ffef5a 	bl	3914 <fwp_format_g.constprop.0>
    7bb0:	17fffe43 	b	74bc <fwp_write+0x69c>
    7bb4:	b9401040 	ldr	w0, [x2, #16]
    7bb8:	350003c0 	cbnz	w0, 7c30 <fwp_write+0xe10>
    7bbc:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7bc0:	f947f400 	ldr	x0, [x0, #4072]
    7bc4:	f94127e2 	ldr	x2, [sp, #584]
    7bc8:	f9400001 	ldr	x1, [x0]
    7bcc:	eb010042 	subs	x2, x2, x1
    7bd0:	d2800001 	mov	x1, #0x0                   	// #0
    7bd4:	54ffd721 	b.ne	76b8 <fwp_write+0x898>  // b.any
    7bd8:	f9413bf5 	ldr	x21, [sp, #624]
    7bdc:	f0000021 	adrp	x1, e000 <_IO_stdin_used+0x470>
    7be0:	f9413ff6 	ldr	x22, [sp, #632]
    7be4:	aa1403e0 	mov	x0, x20
    7be8:	f94143f7 	ldr	x23, [sp, #640]
    7bec:	9101a021 	add	x1, x1, #0x68
    7bf0:	f94147f8 	ldr	x24, [sp, #648]
    7bf4:	d2800042 	mov	x2, #0x2                   	// #2
    7bf8:	17fffd0e 	b	7030 <fwp_write+0x210>
    7bfc:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x10d0>
    7c00:	d2800042 	mov	x2, #0x2                   	// #2
    7c04:	913e8021 	add	x1, x1, #0xfa0
    7c08:	17fffea3 	b	7694 <fwp_write+0x874>
    7c0c:	f9400a63 	ldr	x3, [x19, #16]
    7c10:	8b030021 	add	x1, x1, x3
    7c14:	17ffff66 	b	79ac <fwp_write+0xb8c>
    7c18:	f9400a61 	ldr	x1, [x19, #16]
    7c1c:	8b0102a1 	add	x1, x21, x1
    7c20:	17fffdb3 	b	72ec <fwp_write+0x4cc>
    7c24:	f9400a63 	ldr	x3, [x19, #16]
    7c28:	8b030021 	add	x1, x1, x3
    7c2c:	17ffff56 	b	7984 <fwp_write+0xb64>
    7c30:	b9404840 	ldr	w0, [x2, #72]
    7c34:	91001ff5 	add	x21, sp, #0x7
    7c38:	34ffa360 	cbz	w0, 70a4 <fwp_write+0x284>
    7c3c:	52800503 	mov	w3, #0x28                  	// #40
    7c40:	aa1403e0 	mov	x0, x20
    7c44:	aa1503e1 	mov	x1, x21
    7c48:	d2800022 	mov	x2, #0x1                   	// #1
    7c4c:	39001fe3 	strb	w3, [sp, #7]
    7c50:	97ffedf0 	bl	3410 <buf_put>
    7c54:	b9401380 	ldr	w0, [x28, #16]
    7c58:	52800038 	mov	w24, #0x1                   	// #1
    7c5c:	7100001f 	cmp	w0, #0x0
    7c60:	54ffa36c 	b.gt	70cc <fwp_write+0x2ac>
    7c64:	17fffd32 	b	712c <fwp_write+0x30c>
    7c68:	f9014bf9 	str	x25, [sp, #656]
    7c6c:	f00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe430>
    7c70:	f9014ffa 	str	x26, [sp, #664]
    7c74:	f9400676 	ldr	x22, [x19, #8]
    7c78:	910aa333 	add	x19, x25, #0x2a8
    7c7c:	91002273 	add	x19, x19, #0x8
    7c80:	937ffed8 	asr	x24, x22, #63
    7c84:	aa1802c0 	orr	x0, x22, x24
    7c88:	b5000320 	cbnz	x0, 7cec <fwp_write+0xecc>
    7c8c:	110006b5 	add	w21, w21, #0x1
    7c90:	710016bf 	cmp	w21, #0x5
    7c94:	54ffffc1 	b.ne	7c8c <fwp_write+0xe6c>  // b.any
    7c98:	b7f80578 	tbnz	x24, #63, 7d44 <fwp_write+0xf24>
    7c9c:	910023f3 	add	x19, sp, #0x8
    7ca0:	aa1603e2 	mov	x2, x22
    7ca4:	aa1303e0 	mov	x0, x19
    7ca8:	d2800003 	mov	x3, #0x0                   	// #0
    7cac:	97ffec5d 	bl	2e20 <fwp_fmt_u128>
    7cb0:	910123f5 	add	x21, sp, #0x48
    7cb4:	f0000023 	adrp	x3, e000 <_IO_stdin_used+0x470>
    7cb8:	aa1303e4 	mov	x4, x19
    7cbc:	aa1503e0 	mov	x0, x21
    7cc0:	91018063 	add	x3, x3, #0x60
    7cc4:	d2804002 	mov	x2, #0x200                 	// #512
    7cc8:	52800041 	mov	w1, #0x2                   	// #2
    7ccc:	97ffea95 	bl	2720 <__sprintf_chk@plt>
    7cd0:	aa1503e0 	mov	x0, x21
    7cd4:	97ffea8f 	bl	2710 <strlen@plt>
    7cd8:	aa1503e1 	mov	x1, x21
    7cdc:	aa0003e2 	mov	x2, x0
    7ce0:	aa1403e0 	mov	x0, x20
    7ce4:	97ffedcb 	bl	3410 <buf_put>
    7ce8:	17fffe47 	b	7604 <fwp_write+0x7e4>
    7cec:	f9400277 	ldr	x23, [x19]
    7cf0:	aa1603e0 	mov	x0, x22
    7cf4:	aa1803e1 	mov	x1, x24
    7cf8:	aa1703e2 	mov	x2, x23
    7cfc:	937ffefa 	asr	x26, x23, #63
    7d00:	aa1a03e3 	mov	x3, x26
    7d04:	940016bb 	bl	d7f0 <__modti3>
    7d08:	aa010000 	orr	x0, x0, x1
    7d0c:	b40002c0 	cbz	x0, 7d64 <fwp_write+0xf44>
    7d10:	110006b5 	add	w21, w21, #0x1
    7d14:	91004273 	add	x19, x19, #0x10
    7d18:	710016bf 	cmp	w21, #0x5
    7d1c:	54fffe81 	b.ne	7cec <fwp_write+0xecc>  // b.any
    7d20:	17ffffde 	b	7c98 <fwp_write+0xe78>
    7d24:	f9400a60 	ldr	x0, [x19, #16]
    7d28:	8b000021 	add	x1, x1, x0
    7d2c:	17fffd75 	b	7300 <fwp_write+0x4e0>
    7d30:	528c29c0 	mov	w0, #0x614e                	// #24910
    7d34:	910123f5 	add	x21, sp, #0x48
    7d38:	72a009c0 	movk	w0, #0x4e, lsl #16
    7d3c:	b9004be0 	str	w0, [sp, #72]
    7d40:	17fffda2 	b	73c8 <fwp_write+0x5a8>
    7d44:	528005a1 	mov	w1, #0x2d                  	// #45
    7d48:	eb1603e2 	negs	x2, x22
    7d4c:	da1803e3 	ngc	x3, x24
    7d50:	910027e0 	add	x0, sp, #0x9
    7d54:	910023f3 	add	x19, sp, #0x8
    7d58:	390023e1 	strb	w1, [sp, #8]
    7d5c:	97ffec31 	bl	2e20 <fwp_fmt_u128>
    7d60:	17ffffd4 	b	7cb0 <fwp_write+0xe90>
    7d64:	aa1703e2 	mov	x2, x23
    7d68:	aa1a03e3 	mov	x3, x26
    7d6c:	aa1603e0 	mov	x0, x22
    7d70:	aa1803e1 	mov	x1, x24
    7d74:	940015bf 	bl	d470 <__divti3>
    7d78:	aa0003e2 	mov	x2, x0
    7d7c:	aa0103e3 	mov	x3, x1
    7d80:	b7f80201 	tbnz	x1, #63, 7dc0 <fwp_write+0xfa0>
    7d84:	910023f3 	add	x19, sp, #0x8
    7d88:	aa1303e0 	mov	x0, x19
    7d8c:	97ffec25 	bl	2e20 <fwp_fmt_u128>
    7d90:	937c7ea1 	sbfiz	x1, x21, #4, #32
    7d94:	910aa339 	add	x25, x25, #0x2a8
    7d98:	910123f5 	add	x21, sp, #0x48
    7d9c:	aa1303e4 	mov	x4, x19
    7da0:	aa1503e0 	mov	x0, x21
    7da4:	f0000023 	adrp	x3, e000 <_IO_stdin_used+0x470>
    7da8:	f8616b25 	ldr	x5, [x25, x1]
    7dac:	91016063 	add	x3, x3, #0x58
    7db0:	d2804002 	mov	x2, #0x200                 	// #512
    7db4:	52800041 	mov	w1, #0x2                   	// #2
    7db8:	97ffea5a 	bl	2720 <__sprintf_chk@plt>
    7dbc:	17ffffc5 	b	7cd0 <fwp_write+0xeb0>
    7dc0:	528005a4 	mov	w4, #0x2d                  	// #45
    7dc4:	eb0003e2 	negs	x2, x0
    7dc8:	da0103e3 	ngc	x3, x1
    7dcc:	910027e0 	add	x0, sp, #0x9
    7dd0:	910023f3 	add	x19, sp, #0x8
    7dd4:	390023e4 	strb	w4, [sp, #8]
    7dd8:	97ffec12 	bl	2e20 <fwp_fmt_u128>
    7ddc:	17ffffed 	b	7d90 <fwp_write+0xf70>
    7de0:	f9013bf5 	str	x21, [sp, #624]
    7de4:	f9013ff6 	str	x22, [sp, #632]
    7de8:	f90143f7 	str	x23, [sp, #640]
    7dec:	f90147f8 	str	x24, [sp, #648]
    7df0:	f9014bf9 	str	x25, [sp, #656]
    7df4:	f9014ffa 	str	x26, [sp, #664]
    7df8:	f90153fb 	str	x27, [sp, #672]
    7dfc:	f90157fc 	str	x28, [sp, #680]
    7e00:	fd015be8 	str	d8, [sp, #688]
    7e04:	fd015fe9 	str	d9, [sp, #696]
    7e08:	97ffea9e 	bl	2880 <__stack_chk_fail@plt>
    7e0c:	d503201f 	nop

0000000000007e10 <fwp_hof0.constprop.0>:
    7e10:	d10543ff 	sub	sp, sp, #0x150
    7e14:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    7e18:	f947f442 	ldr	x2, [x2, #4072]
    7e1c:	a90e7bfd 	stp	x29, x30, [sp, #224]
    7e20:	910383fd 	add	x29, sp, #0xe0
    7e24:	f90023e0 	str	x0, [sp, #64]
    7e28:	f9400040 	ldr	x0, [x2]
    7e2c:	f9006fe0 	str	x0, [sp, #216]
    7e30:	d2800000 	mov	x0, #0x0                   	// #0
    7e34:	f90027e1 	str	x1, [sp, #72]
    7e38:	b400a321 	cbz	x1, 929c <fwp_hof0.constprop.0+0x148c>
    7e3c:	b00000c0 	adrp	x0, 20000 <__data_start>
    7e40:	91004000 	add	x0, x0, #0x10
    7e44:	f90017e0 	str	x0, [sp, #40]
    7e48:	910183e0 	add	x0, sp, #0x60
    7e4c:	f90013e0 	str	x0, [sp, #32]
    7e50:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0x470>
    7e54:	fd00a3e8 	str	d8, [sp, #320]
    7e58:	910163e1 	add	x1, sp, #0x58
    7e5c:	fd444008 	ldr	d8, [x0, #2176]
    7e60:	f9000fe1 	str	x1, [sp, #24]
    7e64:	a90f53f3 	stp	x19, x20, [sp, #240]
    7e68:	d0000154 	adrp	x20, 31000 <fwp_root_context+0xca0>
    7e6c:	a9105bf5 	stp	x21, x22, [sp, #256]
    7e70:	a91163f7 	stp	x23, x24, [sp, #272]
    7e74:	a9126bf9 	stp	x25, x26, [sp, #288]
    7e78:	a91373fb 	stp	x27, x28, [sp, #304]
    7e7c:	91150282 	add	x2, x20, #0x540
    7e80:	f94023e0 	ldr	x0, [sp, #64]
    7e84:	f949ec43 	ldr	x3, [x2, #5080]
    7e88:	f949d841 	ldr	x1, [x2, #5040]
    7e8c:	d370bc63 	lsl	x3, x3, #16
    7e90:	cb010004 	sub	x4, x0, x1
    7e94:	eb03009f 	cmp	x4, x3
    7e98:	540003e2 	b.cs	7f14 <fwp_hof0.constprop.0+0x104>  // b.hs, b.nlast
    7e9c:	d350fc80 	lsr	x0, x4, #16
    7ea0:	f949fc46 	ldr	x6, [x2, #5112]
    7ea4:	8b000800 	add	x0, x0, x0, lsl #2
    7ea8:	d37df002 	lsl	x2, x0, #3
    7eac:	8b0200c5 	add	x5, x6, x2
    7eb0:	f94010a0 	ldr	x0, [x5, #32]
    7eb4:	b4000300 	cbz	x0, 7f14 <fwp_hof0.constprop.0+0x104>
    7eb8:	386268c2 	ldrb	w2, [x6, x2]
    7ebc:	7100085f 	cmp	w2, #0x2
    7ec0:	5400b820 	b.eq	95c4 <fwp_hof0.constprop.0+0x17b4>  // b.none
    7ec4:	7100045f 	cmp	w2, #0x1
    7ec8:	54000261 	b.ne	7f14 <fwp_hof0.constprop.0+0x104>  // b.any
    7ecc:	92403c82 	and	x2, x4, #0xffff
    7ed0:	294310a6 	ldp	w6, w4, [x5, #24]
    7ed4:	9b067c42 	mul	x2, x2, x6
    7ed8:	d360fc42 	lsr	x2, x2, #32
    7edc:	eb04005f 	cmp	x2, x4
    7ee0:	540001a2 	b.cs	7f14 <fwp_hof0.constprop.0+0x104>  // b.hs, b.nlast
    7ee4:	8b020000 	add	x0, x0, x2
    7ee8:	39400002 	ldrb	w2, [x0]
    7eec:	34000142 	cbz	w2, 7f14 <fwp_hof0.constprop.0+0x104>
    7ef0:	7103f45f 	cmp	w2, #0xfd
    7ef4:	5400c5c8 	b.hi	97ac <fwp_hof0.constprop.0+0x199c>  // b.pmore
    7ef8:	91150281 	add	x1, x20, #0x540
    7efc:	11000442 	add	w2, w2, #0x1
    7f00:	39000002 	strb	w2, [x0]
    7f04:	aa0103e0 	mov	x0, x1
    7f08:	f949d821 	ldr	x1, [x1, #5040]
    7f0c:	f949ec03 	ldr	x3, [x0, #5080]
    7f10:	d370bc63 	lsl	x3, x3, #16
    7f14:	f94023f5 	ldr	x21, [sp, #64]
    7f18:	d28018c0 	mov	x0, #0xc6                  	// #198
    7f1c:	f90007e0 	str	x0, [sp, #8]
    7f20:	b00000c0 	adrp	x0, 20000 <__data_start>
    7f24:	9100c002 	add	x2, x0, #0x30
    7f28:	f94017e0 	ldr	x0, [sp, #40]
    7f2c:	12800004 	mov	w4, #0xffffffff            	// #-1
    7f30:	b9005be4 	str	w4, [sp, #88]
    7f34:	cb010001 	sub	x1, x0, x1
    7f38:	d0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push.constprop.0+0x15c>
    7f3c:	9137c000 	add	x0, x0, #0xdf0
    7f40:	f90037e0 	str	x0, [sp, #104]
    7f44:	f9416040 	ldr	x0, [x2, #704]
    7f48:	f90033e0 	str	x0, [sp, #96]
    7f4c:	f9400fe0 	ldr	x0, [sp, #24]
    7f50:	f9003be0 	str	x0, [sp, #112]
    7f54:	f94013e0 	ldr	x0, [sp, #32]
    7f58:	f9016040 	str	x0, [x2, #704]
    7f5c:	eb03003f 	cmp	x1, x3
    7f60:	54000782 	b.cs	8050 <fwp_hof0.constprop.0+0x240>  // b.hs, b.nlast
    7f64:	91150282 	add	x2, x20, #0x540
    7f68:	d350fc20 	lsr	x0, x1, #16
    7f6c:	8b000800 	add	x0, x0, x0, lsl #2
    7f70:	f949fc44 	ldr	x4, [x2, #5112]
    7f74:	d37df003 	lsl	x3, x0, #3
    7f78:	8b030082 	add	x2, x4, x3
    7f7c:	f9401053 	ldr	x19, [x2, #32]
    7f80:	b4000693 	cbz	x19, 8050 <fwp_hof0.constprop.0+0x240>
    7f84:	38636880 	ldrb	w0, [x4, x3]
    7f88:	7100081f 	cmp	w0, #0x2
    7f8c:	5400a580 	b.eq	943c <fwp_hof0.constprop.0+0x162c>  // b.none
    7f90:	7100041f 	cmp	w0, #0x1
    7f94:	540005e1 	b.ne	8050 <fwp_hof0.constprop.0+0x240>  // b.any
    7f98:	29430c44 	ldp	w4, w3, [x2, #24]
    7f9c:	92403c20 	and	x0, x1, #0xffff
    7fa0:	9b047c00 	mul	x0, x0, x4
    7fa4:	d360fc00 	lsr	x0, x0, #32
    7fa8:	eb03001f 	cmp	x0, x3
    7fac:	540002a2 	b.cs	8000 <fwp_hof0.constprop.0+0x1f0>  // b.hs, b.nlast
    7fb0:	8b000260 	add	x0, x19, x0
    7fb4:	39400003 	ldrb	w3, [x0]
    7fb8:	34000243 	cbz	w3, 8000 <fwp_hof0.constprop.0+0x1f0>
    7fbc:	7103f47f 	cmp	w3, #0xfd
    7fc0:	5400bb68 	b.hi	972c <fwp_hof0.constprop.0+0x191c>  // b.pmore
    7fc4:	11000463 	add	w3, w3, #0x1
    7fc8:	39000003 	strb	w3, [x0]
    7fcc:	91150280 	add	x0, x20, #0x540
    7fd0:	f94017e3 	ldr	x3, [sp, #40]
    7fd4:	f949d801 	ldr	x1, [x0, #5040]
    7fd8:	f949ec02 	ldr	x2, [x0, #5080]
    7fdc:	cb010061 	sub	x1, x3, x1
    7fe0:	eb02403f 	cmp	x1, x2, lsl #16
    7fe4:	54000362 	b.cs	8050 <fwp_hof0.constprop.0+0x240>  // b.hs, b.nlast
    7fe8:	f949fc00 	ldr	x0, [x0, #5112]
    7fec:	d350fc22 	lsr	x2, x1, #16
    7ff0:	8b020842 	add	x2, x2, x2, lsl #2
    7ff4:	8b020c02 	add	x2, x0, x2, lsl #3
    7ff8:	f9401053 	ldr	x19, [x2, #32]
    7ffc:	b40002b3 	cbz	x19, 8050 <fwp_hof0.constprop.0+0x240>
    8000:	39400040 	ldrb	w0, [x2]
    8004:	7100081f 	cmp	w0, #0x2
    8008:	5400a140 	b.eq	9430 <fwp_hof0.constprop.0+0x1620>  // b.none
    800c:	7100041f 	cmp	w0, #0x1
    8010:	54000201 	b.ne	8050 <fwp_hof0.constprop.0+0x240>  // b.any
    8014:	29430043 	ldp	w3, w0, [x2, #24]
    8018:	92403c21 	and	x1, x1, #0xffff
    801c:	9b037c21 	mul	x1, x1, x3
    8020:	d360fc21 	lsr	x1, x1, #32
    8024:	eb00003f 	cmp	x1, x0
    8028:	54000142 	b.cs	8050 <fwp_hof0.constprop.0+0x240>  // b.hs, b.nlast
    802c:	8b010273 	add	x19, x19, x1
    8030:	39400261 	ldrb	w1, [x19]
    8034:	340000e1 	cbz	w1, 8050 <fwp_hof0.constprop.0+0x240>
    8038:	7100043f 	cmp	w1, #0x1
    803c:	54007960 	b.eq	8f68 <fwp_hof0.constprop.0+0x1158>  // b.none
    8040:	7103fc3f 	cmp	w1, #0xff
    8044:	5400b780 	b.eq	9734 <fwp_hof0.constprop.0+0x1924>  // b.none
    8048:	51000421 	sub	w1, w1, #0x1
    804c:	39000261 	strb	w1, [x19]
    8050:	b40079d5 	cbz	x21, 8f88 <fwp_hof0.constprop.0+0x1178>
    8054:	aa1503e0 	mov	x0, x21
    8058:	d2800001 	mov	x1, #0x0                   	// #0
    805c:	d503201f 	nop
    8060:	f9400800 	ldr	x0, [x0, #16]
    8064:	91000421 	add	x1, x1, #0x1
    8068:	b5ffffc0 	cbnz	x0, 8060 <fwp_hof0.constprop.0+0x250>
    806c:	aa0103f7 	mov	x23, x1
    8070:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    8074:	eb00003f 	cmp	x1, x0
    8078:	5400bea8 	b.hi	984c <fwp_hof0.constprop.0+0x1a3c>  // b.pmore
    807c:	900000c0 	adrp	x0, 20000 <__data_start>
    8080:	9100c013 	add	x19, x0, #0x30
    8084:	b942f660 	ldr	w0, [x19, #756]
    8088:	340078c0 	cbz	w0, 8fa0 <fwp_hof0.constprop.0+0x1190>
    808c:	900000c0 	adrp	x0, 20000 <__data_start>
    8090:	9100c000 	add	x0, x0, #0x30
    8094:	f9402013 	ldr	x19, [x0, #64]
    8098:	f9404c16 	ldr	x22, [x0, #152]
    809c:	eb1302df 	cmp	x22, x19
    80a0:	5400726a 	b.ge	8eec <fwp_hof0.constprop.0+0x10dc>  // b.tcont
    80a4:	900000c1 	adrp	x1, 20000 <__data_start>
    80a8:	8b1606c0 	add	x0, x22, x22, lsl #1
    80ac:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    80b0:	f9401821 	ldr	x1, [x1, #48]
    80b4:	8b000ac0 	add	x0, x22, x0, lsl #2
    80b8:	8b000c20 	add	x0, x1, x0, lsl #3
    80bc:	d503201f 	nop
    80c0:	b9400401 	ldr	w1, [x0, #4]
    80c4:	35000081 	cbnz	w1, 80d4 <fwp_hof0.constprop.0+0x2c4>
    80c8:	b9400001 	ldr	w1, [x0]
    80cc:	6b02003f 	cmp	w1, w2
    80d0:	540070e9 	b.ls	8eec <fwp_hof0.constprop.0+0x10dc>  // b.plast
    80d4:	910006d6 	add	x22, x22, #0x1
    80d8:	9101a000 	add	x0, x0, #0x68
    80dc:	eb1302df 	cmp	x22, x19
    80e0:	54ffff01 	b.ne	80c0 <fwp_hof0.constprop.0+0x2b0>  // b.any
    80e4:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    80e8:	eb00027f 	cmp	x19, x0
    80ec:	5400baac 	b.gt	9840 <fwp_hof0.constprop.0+0x1a30>
    80f0:	900000c0 	adrp	x0, 20000 <__data_start>
    80f4:	9100c000 	add	x0, x0, #0x30
    80f8:	900000c1 	adrp	x1, 20000 <__data_start>
    80fc:	f9404800 	ldr	x0, [x0, #144]
    8100:	f940183c 	ldr	x28, [x1, #48]
    8104:	eb13001f 	cmp	x0, x19
    8108:	54000241 	b.ne	8150 <fwp_hof0.constprop.0+0x340>  // b.any
    810c:	b400a3f3 	cbz	x19, 9588 <fwp_hof0.constprop.0+0x1778>
    8110:	d37ffa7b 	lsl	x27, x19, #1
    8114:	d29fffe0 	mov	x0, #0xffff                	// #65535
    8118:	eb00037f 	cmp	x27, x0
    811c:	9a80d37b 	csel	x27, x27, x0, le
    8120:	8b1b0761 	add	x1, x27, x27, lsl #1
    8124:	8b010b61 	add	x1, x27, x1, lsl #2
    8128:	d37df021 	lsl	x1, x1, #3
    812c:	aa1c03e0 	mov	x0, x28
    8130:	97ffe9d0 	bl	2870 <realloc@plt>
    8134:	aa0003fc 	mov	x28, x0
    8138:	b40037c0 	cbz	x0, 8830 <fwp_hof0.constprop.0+0xa20>
    813c:	900000c0 	adrp	x0, 20000 <__data_start>
    8140:	9100c000 	add	x0, x0, #0x30
    8144:	900000c1 	adrp	x1, 20000 <__data_start>
    8148:	f900183c 	str	x28, [x1, #48]
    814c:	f900481b 	str	x27, [x0, #144]
    8150:	8b130660 	add	x0, x19, x19, lsl #1
    8154:	8b1606db 	add	x27, x22, x22, lsl #1
    8158:	4f000400 	movi	v0.4s, #0x0
    815c:	91000662 	add	x2, x19, #0x1
    8160:	8b000a60 	add	x0, x19, x0, lsl #2
    8164:	8b1b0adb 	add	x27, x22, x27, lsl #2
    8168:	900000c1 	adrp	x1, 20000 <__data_start>
    816c:	9100c021 	add	x1, x1, #0x30
    8170:	8b000f80 	add	x0, x28, x0, lsl #3
    8174:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    8178:	f9002022 	str	x2, [x1, #64]
    817c:	ad000000 	stp	q0, q0, [x0]
    8180:	ad010000 	stp	q0, q0, [x0, #32]
    8184:	ad020000 	stp	q0, q0, [x0, #64]
    8188:	f900301f 	str	xzr, [x0, #96]
    818c:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    8190:	f900337f 	str	xzr, [x27, #96]
    8194:	91372000 	add	x0, x0, #0xdc8
    8198:	97ffea1e 	bl	2a10 <getenv@plt>
    819c:	b4006c00 	cbz	x0, 8f1c <fwp_hof0.constprop.0+0x110c>
    81a0:	39400001 	ldrb	w1, [x0]
    81a4:	7100c03f 	cmp	w1, #0x30
    81a8:	54006ba1 	b.ne	8f1c <fwp_hof0.constprop.0+0x110c>  // b.any
    81ac:	39400400 	ldrb	w0, [x0, #1]
    81b0:	35006b60 	cbnz	w0, 8f1c <fwp_hof0.constprop.0+0x110c>
    81b4:	900000c0 	adrp	x0, 20000 <__data_start>
    81b8:	9100c000 	add	x0, x0, #0x30
    81bc:	2f000400 	mvni	v0.2s, #0x0
    81c0:	b9400373 	ldr	w19, [x27]
    81c4:	52800022 	mov	w2, #0x1                   	// #1
    81c8:	910006c4 	add	x4, x22, #0x1
    81cc:	f9416001 	ldr	x1, [x0, #704]
    81d0:	0b020273 	add	w19, w19, w2
    81d4:	29000b73 	stp	w19, w2, [x27]
    81d8:	a900df77 	stp	x23, x23, [x27, #8]
    81dc:	f9002b7f 	str	xzr, [x27, #80]
    81e0:	f9004c04 	str	x4, [x0, #152]
    81e4:	fd002f60 	str	d0, [x27, #88]
    81e8:	b400b261 	cbz	x1, 9834 <fwp_hof0.constprop.0+0x1a24>
    81ec:	b0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push.constprop.0+0x15c>
    81f0:	9137c003 	add	x3, x0, #0xdf0
    81f4:	14000003 	b	8200 <fwp_hof0.constprop.0+0x3f0>
    81f8:	f9400021 	ldr	x1, [x1]
    81fc:	b400b1c1 	cbz	x1, 9834 <fwp_hof0.constprop.0+0x1a24>
    8200:	f9400422 	ldr	x2, [x1, #8]
    8204:	eb03005f 	cmp	x2, x3
    8208:	54ffff81 	b.ne	81f8 <fwp_hof0.constprop.0+0x3e8>  // b.any
    820c:	f9400820 	ldr	x0, [x1, #16]
    8210:	2a1603e2 	mov	w2, w22
    8214:	b9400001 	ldr	w1, [x0]
    8218:	f9002b60 	str	x0, [x27, #80]
    821c:	b9005f61 	str	w1, [x27, #92]
    8220:	37f80081 	tbnz	w1, #31, 8230 <fwp_hof0.constprop.0+0x420>
    8224:	52800d03 	mov	w3, #0x68                  	// #104
    8228:	9b237021 	smaddl	x1, w1, w3, x28
    822c:	b9005836 	str	w22, [x1, #88]
    8230:	b9000002 	str	w2, [x0]
    8234:	d3707e73 	ubfiz	x19, x19, #16, #32
    8238:	aa040273 	orr	x19, x19, x4
    823c:	aa1503e0 	mov	x0, x21
    8240:	d2800002 	mov	x2, #0x0                   	// #0
    8244:	b4007235 	cbz	x21, 9088 <fwp_hof0.constprop.0+0x1278>
    8248:	f9400800 	ldr	x0, [x0, #16]
    824c:	91000442 	add	x2, x2, #0x1
    8250:	b5ffffc0 	cbnz	x0, 8248 <fwp_hof0.constprop.0+0x438>
    8254:	aa1503e1 	mov	x1, x21
    8258:	f9400821 	ldr	x1, [x1, #16]
    825c:	91000400 	add	x0, x0, #0x1
    8260:	b5ffffc1 	cbnz	x1, 8258 <fwp_hof0.constprop.0+0x448>
    8264:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8268:	eb01001f 	cmp	x0, x1
    826c:	5400ade8 	b.hi	9828 <fwp_hof0.constprop.0+0x1a18>  // b.pmore
    8270:	f100005f 	cmp	x2, #0x0
    8274:	540070ad 	b.le	9088 <fwp_hof0.constprop.0+0x1278>
    8278:	eb00005f 	cmp	x2, x0
    827c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8280:	9a809056 	csel	x22, x2, x0, ls	// ls = plast
    8284:	eb0102df 	cmp	x22, x1
    8288:	5400ad08 	b.hi	9828 <fwp_hof0.constprop.0+0x1a18>  // b.pmore
    828c:	d37ffadc 	lsl	x28, x22, #1
    8290:	52800041 	mov	w1, #0x2                   	// #2
    8294:	91000780 	add	x0, x28, #0x1
    8298:	d37df000 	lsl	x0, x0, #3
    829c:	97fff275 	bl	4c70 <fwp_heap_alloc>
    82a0:	aa0003f7 	mov	x23, x0
    82a4:	91150281 	add	x1, x20, #0x540
    82a8:	aa0003fb 	mov	x27, x0
    82ac:	aa0103e0 	mov	x0, x1
    82b0:	f90002fc 	str	x28, [x23]
    82b4:	f949d821 	ldr	x1, [x1, #5040]
    82b8:	f949ec00 	ldr	x0, [x0, #5080]
    82bc:	cb0102e1 	sub	x1, x23, x1
    82c0:	eb00403f 	cmp	x1, x0, lsl #16
    82c4:	54008022 	b.cs	92c8 <fwp_hof0.constprop.0+0x14b8>  // b.hs, b.nlast
    82c8:	91150282 	add	x2, x20, #0x540
    82cc:	d350fc20 	lsr	x0, x1, #16
    82d0:	8b000800 	add	x0, x0, x0, lsl #2
    82d4:	f949fc43 	ldr	x3, [x2, #5112]
    82d8:	d37df002 	lsl	x2, x0, #3
    82dc:	8b020060 	add	x0, x3, x2
    82e0:	f940101c 	ldr	x28, [x0, #32]
    82e4:	b400025c 	cbz	x28, 832c <fwp_hof0.constprop.0+0x51c>
    82e8:	38626862 	ldrb	w2, [x3, x2]
    82ec:	7100085f 	cmp	w2, #0x2
    82f0:	54008900 	b.eq	9410 <fwp_hof0.constprop.0+0x1600>  // b.none
    82f4:	7100045f 	cmp	w2, #0x1
    82f8:	540001a1 	b.ne	832c <fwp_hof0.constprop.0+0x51c>  // b.any
    82fc:	29430002 	ldp	w2, w0, [x0, #24]
    8300:	92403c21 	and	x1, x1, #0xffff
    8304:	9b027c21 	mul	x1, x1, x2
    8308:	d360fc21 	lsr	x1, x1, #32
    830c:	eb00003f 	cmp	x1, x0
    8310:	540000e2 	b.cs	832c <fwp_hof0.constprop.0+0x51c>  // b.hs, b.nlast
    8314:	8b01039c 	add	x28, x28, x1
    8318:	39400380 	ldrb	w0, [x28]
    831c:	7103fc1f 	cmp	w0, #0xff
    8320:	54008820 	b.eq	9424 <fwp_hof0.constprop.0+0x1614>  // b.none
    8324:	52800020 	mov	w0, #0x1                   	// #1
    8328:	39000380 	strb	w0, [x28]
    832c:	b4000236 	cbz	x22, 8370 <fwp_hof0.constprop.0+0x560>
    8330:	d3607e64 	lsl	x4, x19, #32
    8334:	aa1503e1 	mov	x1, x21
    8338:	f94006a5 	ldr	x5, [x21, #8]
    833c:	aa0403e3 	mov	x3, x4
    8340:	910022e2 	add	x2, x23, #0x8
    8344:	d2800000 	mov	x0, #0x0                   	// #0
    8348:	14000005 	b	835c <fwp_hof0.constprop.0+0x54c>
    834c:	f9400425 	ldr	x5, [x1, #8]
    8350:	ab000083 	adds	x3, x4, x0
    8354:	91004042 	add	x2, x2, #0x10
    8358:	5400aa46 	b.vs	98a0 <fwp_hof0.constprop.0+0x1a90>
    835c:	a9000c45 	stp	x5, x3, [x2]
    8360:	91000400 	add	x0, x0, #0x1
    8364:	f9400821 	ldr	x1, [x1, #16]
    8368:	eb16001f 	cmp	x0, x22
    836c:	54ffff03 	b.cc	834c <fwp_hof0.constprop.0+0x53c>  // b.lo, b.ul, b.last
    8370:	f94002e0 	ldr	x0, [x23]
    8374:	f100041f 	cmp	x0, #0x1
    8378:	54007ac9 	b.ls	92d0 <fwp_hof0.constprop.0+0x14c0>  // b.plast
    837c:	d341fc00 	lsr	x0, x0, #1
    8380:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    8384:	d1000401 	sub	x1, x0, #0x1
    8388:	eb02003f 	cmp	x1, x2
    838c:	5400a4e8 	b.hi	9828 <fwp_hof0.constprop.0+0x1a18>  // b.pmore
    8390:	d37ff83c 	lsl	x28, x1, #1
    8394:	b40079e1 	cbz	x1, 92d0 <fwp_hof0.constprop.0+0x14c0>
    8398:	d10022e1 	sub	x1, x23, #0x8
    839c:	910022f8 	add	x24, x23, #0x8
    83a0:	8b001036 	add	x22, x1, x0, lsl #4
    83a4:	d503201f 	nop
    83a8:	f9400700 	ldr	x0, [x24, #8]
    83ac:	f9400f01 	ldr	x1, [x24, #24]
    83b0:	fd400300 	ldr	d0, [x24]
    83b4:	fd400b01 	ldr	d1, [x24, #16]
    83b8:	97fff36e 	bl	5170 <w120>
    83bc:	a9000700 	stp	x0, x1, [x24]
    83c0:	91004318 	add	x24, x24, #0x10
    83c4:	eb16031f 	cmp	x24, x22
    83c8:	54ffff01 	b.ne	83a8 <fwp_hof0.constprop.0+0x598>  // b.any
    83cc:	f90002fc 	str	x28, [x23]
    83d0:	9115029c 	add	x28, x20, #0x540
    83d4:	aa1703e0 	mov	x0, x23
    83d8:	97fff3aa 	bl	5280 <w176.constprop.0>
    83dc:	aa0103f6 	mov	x22, x1
    83e0:	f949db81 	ldr	x1, [x28, #5040]
    83e4:	f949ef80 	ldr	x0, [x28, #5080]
    83e8:	cb0102e1 	sub	x1, x23, x1
    83ec:	eb00403f 	cmp	x1, x0, lsl #16
    83f0:	54000382 	b.cs	8460 <fwp_hof0.constprop.0+0x650>  // b.hs, b.nlast
    83f4:	d350fc20 	lsr	x0, x1, #16
    83f8:	f949ff84 	ldr	x4, [x28, #5112]
    83fc:	8b000800 	add	x0, x0, x0, lsl #2
    8400:	d37df000 	lsl	x0, x0, #3
    8404:	8b000082 	add	x2, x4, x0
    8408:	f9401057 	ldr	x23, [x2, #32]
    840c:	b40002b7 	cbz	x23, 8460 <fwp_hof0.constprop.0+0x650>
    8410:	38606880 	ldrb	w0, [x4, x0]
    8414:	7100081f 	cmp	w0, #0x2
    8418:	54007600 	b.eq	92d8 <fwp_hof0.constprop.0+0x14c8>  // b.none
    841c:	7100041f 	cmp	w0, #0x1
    8420:	54000201 	b.ne	8460 <fwp_hof0.constprop.0+0x650>  // b.any
    8424:	29430043 	ldp	w3, w0, [x2, #24]
    8428:	92403c21 	and	x1, x1, #0xffff
    842c:	9b037c21 	mul	x1, x1, x3
    8430:	d360fc21 	lsr	x1, x1, #32
    8434:	eb00003f 	cmp	x1, x0
    8438:	54000142 	b.cs	8460 <fwp_hof0.constprop.0+0x650>  // b.hs, b.nlast
    843c:	8b0102f7 	add	x23, x23, x1
    8440:	394002e0 	ldrb	w0, [x23]
    8444:	340000e0 	cbz	w0, 8460 <fwp_hof0.constprop.0+0x650>
    8448:	7100041f 	cmp	w0, #0x1
    844c:	540020a0 	b.eq	8860 <fwp_hof0.constprop.0+0xa50>  // b.none
    8450:	7103fc1f 	cmp	w0, #0xff
    8454:	54008be0 	b.eq	95d0 <fwp_hof0.constprop.0+0x17c0>  // b.none
    8458:	51000400 	sub	w0, w0, #0x1
    845c:	390002e0 	strb	w0, [x23]
    8460:	93407e73 	sxtw	x19, w19
    8464:	aa1303e0 	mov	x0, x19
    8468:	97ffed12 	bl	38b0 <fwp_tape_of>
    846c:	f9403001 	ldr	x1, [x0, #96]
    8470:	aa0003e8 	mov	x8, x0
    8474:	b5009f21 	cbnz	x1, 9858 <fwp_hof0.constprop.0+0x1a48>
    8478:	97ffeac6 	bl	2f90 <fwp_tape_unlink_scope>
    847c:	b9400002 	ldr	w2, [x0]
    8480:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    8484:	a940801c 	ldp	x28, x0, [x0, #8]
    8488:	b900051f 	str	wzr, [x8, #4]
    848c:	a941e50a 	ldp	x10, x25, [x8, #24]
    8490:	a942ed1a 	ldp	x26, x27, [x8, #40]
    8494:	a943e107 	ldp	x7, x24, [x8, #56]
    8498:	f9402517 	ldr	x23, [x8, #72]
    849c:	6b01005f 	cmp	w2, w1
    84a0:	54000128 	b.hi	84c4 <fwp_hof0.constprop.0+0x6b4>  // b.pmore
    84a4:	900000c1 	adrp	x1, 20000 <__data_start>
    84a8:	9100c022 	add	x2, x1, #0x30
    84ac:	92403e61 	and	x1, x19, #0xffff
    84b0:	d1000421 	sub	x1, x1, #0x1
    84b4:	f9404c49 	ldr	x9, [x2, #152]
    84b8:	eb09003f 	cmp	x1, x9
    84bc:	5400004a 	b.ge	84c4 <fwp_hof0.constprop.0+0x6b4>  // b.tcont
    84c0:	f9004c41 	str	x1, [x2, #152]
    84c4:	4f000400 	movi	v0.4s, #0x0
    84c8:	900000c1 	adrp	x1, 20000 <__data_start>
    84cc:	9100c029 	add	x9, x1, #0x30
    84d0:	f9000d1f 	str	xzr, [x8, #24]
    84d4:	a9047d1f 	stp	xzr, xzr, [x8, #64]
    84d8:	910243e3 	add	x3, sp, #0x90
    84dc:	9101e3e1 	add	x1, sp, #0x78
    84e0:	f941612b 	ldr	x11, [x9, #704]
    84e4:	3c808100 	stur	q0, [x8, #8]
    84e8:	90ffffe2 	adrp	x2, 4000 <fwp_heap_init+0x17c>
    84ec:	ad010100 	stp	q0, q0, [x8, #32]
    84f0:	91040042 	add	x2, x2, #0x100
    84f4:	f9000be3 	str	x3, [sp, #16]
    84f8:	a9078beb 	stp	x11, x2, [sp, #120]
    84fc:	a908e7e3 	stp	x3, x25, [sp, #136]
    8500:	a909effa 	stp	x26, x27, [sp, #152]
    8504:	a90ae3e7 	stp	x7, x24, [sp, #168]
    8508:	a90bdfea 	stp	x10, x23, [sp, #184]
    850c:	f9016121 	str	x1, [x9, #704]
    8510:	b7f879f6 	tbnz	x22, #63, 944c <fwp_hof0.constprop.0+0x163c>
    8514:	eb96827f 	cmp	x19, x22, asr #32
    8518:	540093e1 	b.ne	9794 <fwp_hof0.constprop.0+0x1984>  // b.any
    851c:	92407ed3 	and	x19, x22, #0xffffffff
    8520:	eb36401f 	cmp	x0, w22, uxtw
    8524:	540093ed 	b.le	97a0 <fwp_hof0.constprop.0+0x1990>
    8528:	eb1c027f 	cmp	x19, x28
    852c:	9a93b793 	csinc	x19, x28, x19, lt	// lt = tstop
    8530:	eb1302ff 	cmp	x23, x19
    8534:	5400168a 	b.ge	8804 <fwp_hof0.constprop.0+0x9f4>  // b.tcont
    8538:	f10002ff 	cmp	x23, #0x0
    853c:	9a9312f7 	csel	x23, x23, x19, ne	// ne = any
    8540:	14000005 	b	8554 <fwp_hof0.constprop.0+0x744>
    8544:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    8548:	eb0002ff 	cmp	x23, x0
    854c:	d37ffaf7 	lsl	x23, x23, #1
    8550:	9a93d2f7 	csel	x23, x23, x19, le
    8554:	eb1302ff 	cmp	x23, x19
    8558:	54ffff6b 	b.lt	8544 <fwp_hof0.constprop.0+0x734>  // b.tstop
    855c:	f9001be7 	str	x7, [sp, #48]
    8560:	b4007f58 	cbz	x24, 9548 <fwp_hof0.constprop.0+0x1738>
    8564:	aa1803e0 	mov	x0, x24
    8568:	d37df2e1 	lsl	x1, x23, #3
    856c:	97ffe8c1 	bl	2870 <realloc@plt>
    8570:	aa0003f8 	mov	x24, x0
    8574:	f9401be7 	ldr	x7, [sp, #48]
    8578:	b4009838 	cbz	x24, 987c <fwp_hof0.constprop.0+0x1a6c>
    857c:	f9005bf8 	str	x24, [sp, #176]
    8580:	f90063f7 	str	x23, [sp, #192]
    8584:	b5001333 	cbnz	x19, 87e8 <fwp_hof0.constprop.0+0x9d8>
    8588:	b7f800d6 	tbnz	x22, #63, 85a0 <fwp_hof0.constprop.0+0x790>
    858c:	92407ec1 	and	x1, x22, #0xffffffff
    8590:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    8594:	fc617b00 	ldr	d0, [x24, x1, lsl #3]
    8598:	1e612800 	fadd	d0, d0, d1
    859c:	fc217b00 	str	d0, [x24, x1, lsl #3]
    85a0:	d1000673 	sub	x19, x19, #0x1
    85a4:	d1000788 	sub	x8, x28, #0x1
    85a8:	eb13039f 	cmp	x28, x19
    85ac:	540003ac 	b.gt	8620 <fwp_hof0.constprop.0+0x810>
    85b0:	fc737b00 	ldr	d0, [x24, x19, lsl #3]
    85b4:	1e602008 	fcmp	d0, #0.0
    85b8:	540002e0 	b.eq	8614 <fwp_hof0.constprop.0+0x804>  // b.none
    85bc:	cb1c0be0 	neg	x0, x28, lsl #2
    85c0:	cb1c03e2 	neg	x2, x28
    85c4:	8b000321 	add	x1, x25, x0
    85c8:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    85cc:	37f80101 	tbnz	w1, #31, 85ec <fwp_hof0.constprop.0+0x7dc>
    85d0:	8b020f69 	add	x9, x27, x2, lsl #3
    85d4:	93407c21 	sxtw	x1, w1
    85d8:	fc737922 	ldr	d2, [x9, x19, lsl #3]
    85dc:	fc617b01 	ldr	d1, [x24, x1, lsl #3]
    85e0:	1e620802 	fmul	d2, d0, d2
    85e4:	1e622821 	fadd	d1, d1, d2
    85e8:	fc217b01 	str	d1, [x24, x1, lsl #3]
    85ec:	8b000340 	add	x0, x26, x0
    85f0:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    85f4:	37f80100 	tbnz	w0, #31, 8614 <fwp_hof0.constprop.0+0x804>
    85f8:	8b020ce2 	add	x2, x7, x2, lsl #3
    85fc:	93407c00 	sxtw	x0, w0
    8600:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    8604:	fc607b01 	ldr	d1, [x24, x0, lsl #3]
    8608:	1e620800 	fmul	d0, d0, d2
    860c:	1e602820 	fadd	d0, d1, d0
    8610:	fc207b00 	str	d0, [x24, x0, lsl #3]
    8614:	d1000673 	sub	x19, x19, #0x1
    8618:	eb13011f 	cmp	x8, x19
    861c:	54fffca1 	b.ne	85b0 <fwp_hof0.constprop.0+0x7a0>  // b.any
    8620:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8624:	eb00039f 	cmp	x28, x0
    8628:	54009248 	b.hi	9870 <fwp_hof0.constprop.0+0x1a60>  // b.pmore
    862c:	91000780 	add	x0, x28, #0x1
    8630:	52800041 	mov	w1, #0x2                   	// #2
    8634:	d37df000 	lsl	x0, x0, #3
    8638:	97fff18e 	bl	4c70 <fwp_heap_alloc>
    863c:	aa0003e2 	mov	x2, x0
    8640:	aa0003f3 	mov	x19, x0
    8644:	d2800001 	mov	x1, #0x0                   	// #0
    8648:	f800845c 	str	x28, [x2], #8
    864c:	b40000dc 	cbz	x28, 8664 <fwp_hof0.constprop.0+0x854>
    8650:	f8617b00 	ldr	x0, [x24, x1, lsl #3]
    8654:	f8217840 	str	x0, [x2, x1, lsl #3]
    8658:	91000421 	add	x1, x1, #0x1
    865c:	eb01039f 	cmp	x28, x1
    8660:	54ffff81 	b.ne	8650 <fwp_hof0.constprop.0+0x840>  // b.any
    8664:	900000c0 	adrp	x0, 20000 <__data_start>
    8668:	9100c001 	add	x1, x0, #0x30
    866c:	f9400be0 	ldr	x0, [sp, #16]
    8670:	f9403ff7 	ldr	x23, [sp, #120]
    8674:	f9016037 	str	x23, [x1, #704]
    8678:	97ffeea2 	bl	4100 <fwp_tape_buffers_release>
    867c:	91150282 	add	x2, x20, #0x540
    8680:	f949d841 	ldr	x1, [x2, #5040]
    8684:	f949ec40 	ldr	x0, [x2, #5080]
    8688:	cb010261 	sub	x1, x19, x1
    868c:	eb00403f 	cmp	x1, x0, lsl #16
    8690:	54000322 	b.cs	86f4 <fwp_hof0.constprop.0+0x8e4>  // b.hs, b.nlast
    8694:	d350fc20 	lsr	x0, x1, #16
    8698:	f949fc43 	ldr	x3, [x2, #5112]
    869c:	8b000800 	add	x0, x0, x0, lsl #2
    86a0:	d37df002 	lsl	x2, x0, #3
    86a4:	8b020060 	add	x0, x3, x2
    86a8:	f9401016 	ldr	x22, [x0, #32]
    86ac:	b4000256 	cbz	x22, 86f4 <fwp_hof0.constprop.0+0x8e4>
    86b0:	38626862 	ldrb	w2, [x3, x2]
    86b4:	7100085f 	cmp	w2, #0x2
    86b8:	54006ce0 	b.eq	9454 <fwp_hof0.constprop.0+0x1644>  // b.none
    86bc:	7100045f 	cmp	w2, #0x1
    86c0:	540001a1 	b.ne	86f4 <fwp_hof0.constprop.0+0x8e4>  // b.any
    86c4:	29430002 	ldp	w2, w0, [x0, #24]
    86c8:	92403c21 	and	x1, x1, #0xffff
    86cc:	9b027c21 	mul	x1, x1, x2
    86d0:	d360fc21 	lsr	x1, x1, #32
    86d4:	eb00003f 	cmp	x1, x0
    86d8:	540000e2 	b.cs	86f4 <fwp_hof0.constprop.0+0x8e4>  // b.hs, b.nlast
    86dc:	8b0102d6 	add	x22, x22, x1
    86e0:	394002c0 	ldrb	w0, [x22]
    86e4:	7103fc1f 	cmp	w0, #0xff
    86e8:	54006c00 	b.eq	9468 <fwp_hof0.constprop.0+0x1658>  // b.none
    86ec:	52800020 	mov	w0, #0x1                   	// #1
    86f0:	390002c0 	strb	w0, [x22]
    86f4:	f94013e0 	ldr	x0, [sp, #32]
    86f8:	eb0002ff 	cmp	x23, x0
    86fc:	54008d41 	b.ne	98a4 <fwp_hof0.constprop.0+0x1a94>  // b.any
    8700:	900000c0 	adrp	x0, 20000 <__data_start>
    8704:	9100c001 	add	x1, x0, #0x30
    8708:	f9400fe0 	ldr	x0, [sp, #24]
    870c:	f94033e2 	ldr	x2, [sp, #96]
    8710:	f9016022 	str	x2, [x1, #704]
    8714:	97fff5b7 	bl	5df0 <fwp_tape_scope_release>
    8718:	f9400260 	ldr	x0, [x19]
    871c:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    8720:	b7f84540 	tbnz	x0, #63, 8fc8 <fwp_hof0.constprop.0+0x11b8>
    8724:	91150282 	add	x2, x20, #0x540
    8728:	f949d840 	ldr	x0, [x2, #5040]
    872c:	f949ec41 	ldr	x1, [x2, #5080]
    8730:	cb000260 	sub	x0, x19, x0
    8734:	eb01401f 	cmp	x0, x1, lsl #16
    8738:	54004482 	b.cs	8fc8 <fwp_hof0.constprop.0+0x11b8>  // b.hs, b.nlast
    873c:	d350fc01 	lsr	x1, x0, #16
    8740:	f949fc44 	ldr	x4, [x2, #5112]
    8744:	8b010821 	add	x1, x1, x1, lsl #2
    8748:	d37df021 	lsl	x1, x1, #3
    874c:	8b010083 	add	x3, x4, x1
    8750:	f9401062 	ldr	x2, [x3, #32]
    8754:	b40043a2 	cbz	x2, 8fc8 <fwp_hof0.constprop.0+0x11b8>
    8758:	38616881 	ldrb	w1, [x4, x1]
    875c:	7100083f 	cmp	w1, #0x2
    8760:	540042e0 	b.eq	8fbc <fwp_hof0.constprop.0+0x11ac>  // b.none
    8764:	7100043f 	cmp	w1, #0x1
    8768:	54004301 	b.ne	8fc8 <fwp_hof0.constprop.0+0x11b8>  // b.any
    876c:	29430464 	ldp	w4, w1, [x3, #24]
    8770:	92403c00 	and	x0, x0, #0xffff
    8774:	9b047c00 	mul	x0, x0, x4
    8778:	d360fc00 	lsr	x0, x0, #32
    877c:	eb01001f 	cmp	x0, x1
    8780:	54004242 	b.cs	8fc8 <fwp_hof0.constprop.0+0x11b8>  // b.hs, b.nlast
    8784:	8b000042 	add	x2, x2, x0
    8788:	39400040 	ldrb	w0, [x2]
    878c:	7100041f 	cmp	w0, #0x1
    8790:	540041c1 	b.ne	8fc8 <fwp_hof0.constprop.0+0x11b8>  // b.any
    8794:	aa1303fc 	mov	x28, x19
    8798:	aa1303f6 	mov	x22, x19
    879c:	d2800000 	mov	x0, #0x0                   	// #0
    87a0:	910022c3 	add	x3, x22, #0x8
    87a4:	91002265 	add	x5, x19, #0x8
    87a8:	d2800001 	mov	x1, #0x0                   	// #0
    87ac:	b5000157 	cbnz	x23, 87d4 <fwp_hof0.constprop.0+0x9c4>
    87b0:	1400004d 	b	88e4 <fwp_hof0.constprop.0+0xad4>
    87b4:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    87b8:	f9400382 	ldr	x2, [x28]
    87bc:	1e600900 	fmul	d0, d8, d0
    87c0:	b7f882e2 	tbnz	x2, #63, 981c <fwp_hof0.constprop.0+0x1a0c>
    87c4:	91000421 	add	x1, x1, #0x1
    87c8:	fc008460 	str	d0, [x3], #8
    87cc:	eb0102ff 	cmp	x23, x1
    87d0:	540008a0 	b.eq	88e4 <fwp_hof0.constprop.0+0xad4>  // b.none
    87d4:	f9400264 	ldr	x4, [x19]
    87d8:	aa0503e2 	mov	x2, x5
    87dc:	b6fffec4 	tbz	x4, #63, 87b4 <fwp_hof0.constprop.0+0x9a4>
    87e0:	f9400a62 	ldr	x2, [x19, #16]
    87e4:	17fffff4 	b	87b4 <fwp_hof0.constprop.0+0x9a4>
    87e8:	d37df262 	lsl	x2, x19, #3
    87ec:	aa1803e0 	mov	x0, x24
    87f0:	52800001 	mov	w1, #0x0                   	// #0
    87f4:	f9001be7 	str	x7, [sp, #48]
    87f8:	97ffe816 	bl	2850 <memset@plt>
    87fc:	f9401be7 	ldr	x7, [sp, #48]
    8800:	17ffff62 	b	8588 <fwp_hof0.constprop.0+0x778>
    8804:	f100031f 	cmp	x24, #0x0
    8808:	1a9f17e0 	cset	w0, eq	// eq = none
    880c:	f100027f 	cmp	x19, #0x0
    8810:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    8814:	54ffeb80 	b.eq	8584 <fwp_hof0.constprop.0+0x774>  // b.none
    8818:	900000c0 	adrp	x0, 20000 <__data_start>
    881c:	9100c018 	add	x24, x0, #0x30
    8820:	f9400be0 	ldr	x0, [sp, #16]
    8824:	f9403fe1 	ldr	x1, [sp, #120]
    8828:	f9016301 	str	x1, [x24, #704]
    882c:	97ffee35 	bl	4100 <fwp_tape_buffers_release>
    8830:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    8834:	f947e863 	ldr	x3, [x3, #4048]
    8838:	d2800262 	mov	x2, #0x13                  	// #19
    883c:	d2800021 	mov	x1, #0x1                   	// #1
    8840:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    8844:	912e6000 	add	x0, x0, #0xb98
    8848:	f9400063 	ldr	x3, [x3]
    884c:	97ffe84d 	bl	2980 <fwrite@plt>
    8850:	d2800000 	mov	x0, #0x0                   	// #0
    8854:	97ffe857 	bl	29b0 <fflush@plt>
    8858:	52800cc0 	mov	w0, #0x66                  	// #102
    885c:	97ffe865 	bl	29f0 <_Exit@plt>
    8860:	f9400365 	ldr	x5, [x27]
    8864:	aa1b03e0 	mov	x0, x27
    8868:	f949ef83 	ldr	x3, [x28, #5080]
    886c:	f949db81 	ldr	x1, [x28, #5040]
    8870:	d370bc63 	lsl	x3, x3, #16
    8874:	cb010362 	sub	x2, x27, x1
    8878:	b7f853c5 	tbnz	x5, #63, 92f0 <fwp_hof0.constprop.0+0x14e0>
    887c:	eb02007f 	cmp	x3, x2
    8880:	54ffdf09 	b.ls	8460 <fwp_hof0.constprop.0+0x650>  // b.plast
    8884:	d350fc40 	lsr	x0, x2, #16
    8888:	8b000800 	add	x0, x0, x0, lsl #2
    888c:	d37df000 	lsl	x0, x0, #3
    8890:	8b000083 	add	x3, x4, x0
    8894:	f9401061 	ldr	x1, [x3, #32]
    8898:	b4ffde41 	cbz	x1, 8460 <fwp_hof0.constprop.0+0x650>
    889c:	38606880 	ldrb	w0, [x4, x0]
    88a0:	7100081f 	cmp	w0, #0x2
    88a4:	54005e80 	b.eq	9474 <fwp_hof0.constprop.0+0x1664>  // b.none
    88a8:	7100041f 	cmp	w0, #0x1
    88ac:	54ffdda1 	b.ne	8460 <fwp_hof0.constprop.0+0x650>  // b.any
    88b0:	92403c40 	and	x0, x2, #0xffff
    88b4:	29430864 	ldp	w4, w2, [x3, #24]
    88b8:	9b047c00 	mul	x0, x0, x4
    88bc:	d360fc00 	lsr	x0, x0, #32
    88c0:	eb02001f 	cmp	x0, x2
    88c4:	54ffdce2 	b.cs	8460 <fwp_hof0.constprop.0+0x650>  // b.hs, b.nlast
    88c8:	8b000021 	add	x1, x1, x0
    88cc:	39400020 	ldrb	w0, [x1]
    88d0:	7100041f 	cmp	w0, #0x1
    88d4:	54ffdc61 	b.ne	8460 <fwp_hof0.constprop.0+0x650>  // b.any
    88d8:	aa1b03e0 	mov	x0, x27
    88dc:	97ffefc5 	bl	47f0 <fwp_mem_free>
    88e0:	17fffee0 	b	8460 <fwp_hof0.constprop.0+0x650>
    88e4:	97fff72f 	bl	65a0 <fwp_drop10>
    88e8:	aa1503e1 	mov	x1, x21
    88ec:	d2800002 	mov	x2, #0x0                   	// #0
    88f0:	b4006395 	cbz	x21, 9560 <fwp_hof0.constprop.0+0x1750>
    88f4:	d503201f 	nop
    88f8:	f9400821 	ldr	x1, [x1, #16]
    88fc:	91000442 	add	x2, x2, #0x1
    8900:	b5ffffc1 	cbnz	x1, 88f8 <fwp_hof0.constprop.0+0xae8>
    8904:	f9400384 	ldr	x4, [x28]
    8908:	9240f885 	and	x5, x4, #0x7fffffffffffffff
    890c:	b7f82b64 	tbnz	x4, #63, 8e78 <fwp_hof0.constprop.0+0x1068>
    8910:	91150281 	add	x1, x20, #0x540
    8914:	f949d820 	ldr	x0, [x1, #5040]
    8918:	f949ec21 	ldr	x1, [x1, #5080]
    891c:	cb0002c0 	sub	x0, x22, x0
    8920:	eb01401f 	cmp	x0, x1, lsl #16
    8924:	54002aa2 	b.cs	8e78 <fwp_hof0.constprop.0+0x1068>  // b.hs, b.nlast
    8928:	91150283 	add	x3, x20, #0x540
    892c:	d350fc01 	lsr	x1, x0, #16
    8930:	8b010821 	add	x1, x1, x1, lsl #2
    8934:	f949fc67 	ldr	x7, [x3, #5112]
    8938:	d37df021 	lsl	x1, x1, #3
    893c:	8b0100e6 	add	x6, x7, x1
    8940:	f94010c3 	ldr	x3, [x6, #32]
    8944:	b4002983 	cbz	x3, 8e74 <fwp_hof0.constprop.0+0x1064>
    8948:	386168e1 	ldrb	w1, [x7, x1]
    894c:	7100083f 	cmp	w1, #0x2
    8950:	540028e0 	b.eq	8e6c <fwp_hof0.constprop.0+0x105c>  // b.none
    8954:	7100043f 	cmp	w1, #0x1
    8958:	540028e1 	b.ne	8e74 <fwp_hof0.constprop.0+0x1064>  // b.any
    895c:	294304c7 	ldp	w7, w1, [x6, #24]
    8960:	92403c00 	and	x0, x0, #0xffff
    8964:	9b077c00 	mul	x0, x0, x7
    8968:	d360fc00 	lsr	x0, x0, #32
    896c:	eb01001f 	cmp	x0, x1
    8970:	54002822 	b.cs	8e74 <fwp_hof0.constprop.0+0x1064>  // b.hs, b.nlast
    8974:	8b000063 	add	x3, x3, x0
    8978:	39400060 	ldrb	w0, [x3]
    897c:	7100041f 	cmp	w0, #0x1
    8980:	540027a1 	b.ne	8e74 <fwp_hof0.constprop.0+0x1064>  // b.any
    8984:	b90033e0 	str	w0, [sp, #48]
    8988:	eb05005f 	cmp	x2, x5
    898c:	9a859045 	csel	x5, x2, x5, ls	// ls = plast
    8990:	9100239b 	add	x27, x28, #0x8
    8994:	b4006c65 	cbz	x5, 9720 <fwp_hof0.constprop.0+0x1910>
    8998:	d37df0a7 	lsl	x7, x5, #3
    899c:	aa1503e2 	mov	x2, x21
    89a0:	910022c0 	add	x0, x22, #0x8
    89a4:	d2800001 	mov	x1, #0x0                   	// #0
    89a8:	1400000a 	b	89d0 <fwp_hof0.constprop.0+0xbc0>
    89ac:	fc6168c1 	ldr	d1, [x6, x1]
    89b0:	fd400440 	ldr	d0, [x2, #8]
    89b4:	1e613800 	fsub	d0, d0, d1
    89b8:	fc216b60 	str	d0, [x27, x1]
    89bc:	91002021 	add	x1, x1, #0x8
    89c0:	f9400842 	ldr	x2, [x2, #16]
    89c4:	eb07003f 	cmp	x1, x7
    89c8:	540001a0 	b.eq	89fc <fwp_hof0.constprop.0+0xbec>  // b.none
    89cc:	f9400384 	ldr	x4, [x28]
    89d0:	aa0003e6 	mov	x6, x0
    89d4:	b6fffec4 	tbz	x4, #63, 89ac <fwp_hof0.constprop.0+0xb9c>
    89d8:	f9400ac6 	ldr	x6, [x22, #16]
    89dc:	fd400440 	ldr	d0, [x2, #8]
    89e0:	fc6168c1 	ldr	d1, [x6, x1]
    89e4:	1e613800 	fsub	d0, d0, d1
    89e8:	fc216b60 	str	d0, [x27, x1]
    89ec:	91002021 	add	x1, x1, #0x8
    89f0:	f9400842 	ldr	x2, [x2, #16]
    89f4:	eb07003f 	cmp	x1, x7
    89f8:	54fffea1 	b.ne	89cc <fwp_hof0.constprop.0+0xbbc>  // b.any
    89fc:	b4006c95 	cbz	x21, 978c <fwp_hof0.constprop.0+0x197c>
    8a00:	91150280 	add	x0, x20, #0x540
    8a04:	aa1503e7 	mov	x7, x21
    8a08:	d2800017 	mov	x23, #0x0                   	// #0
    8a0c:	f949ec09 	ldr	x9, [x0, #5080]
    8a10:	f949d80a 	ldr	x10, [x0, #5040]
    8a14:	f949fc08 	ldr	x8, [x0, #5112]
    8a18:	d370bd29 	lsl	x9, x9, #16
    8a1c:	14000006 	b	8a34 <fwp_hof0.constprop.0+0xc24>
    8a20:	f94008e7 	ldr	x7, [x7, #16]
    8a24:	910006f7 	add	x23, x23, #0x1
    8a28:	f10000ff 	cmp	x7, #0x0
    8a2c:	fa5710a0 	ccmp	x5, x23, #0x0, ne	// ne = any
    8a30:	54000329 	b.ls	8a94 <fwp_hof0.constprop.0+0xc84>  // b.plast
    8a34:	cb0a00e0 	sub	x0, x7, x10
    8a38:	eb09001f 	cmp	x0, x9
    8a3c:	540002c2 	b.cs	8a94 <fwp_hof0.constprop.0+0xc84>  // b.hs, b.nlast
    8a40:	d350fc01 	lsr	x1, x0, #16
    8a44:	8b010821 	add	x1, x1, x1, lsl #2
    8a48:	d37df021 	lsl	x1, x1, #3
    8a4c:	8b010106 	add	x6, x8, x1
    8a50:	f94010c2 	ldr	x2, [x6, #32]
    8a54:	b4000202 	cbz	x2, 8a94 <fwp_hof0.constprop.0+0xc84>
    8a58:	38616901 	ldrb	w1, [x8, x1]
    8a5c:	7100083f 	cmp	w1, #0x2
    8a60:	54000e00 	b.eq	8c20 <fwp_hof0.constprop.0+0xe10>  // b.none
    8a64:	7100043f 	cmp	w1, #0x1
    8a68:	54000161 	b.ne	8a94 <fwp_hof0.constprop.0+0xc84>  // b.any
    8a6c:	294304cb 	ldp	w11, w1, [x6, #24]
    8a70:	92403c00 	and	x0, x0, #0xffff
    8a74:	9b0b7c00 	mul	x0, x0, x11
    8a78:	d360fc00 	lsr	x0, x0, #32
    8a7c:	eb01001f 	cmp	x0, x1
    8a80:	540000a2 	b.cs	8a94 <fwp_hof0.constprop.0+0xc84>  // b.hs, b.nlast
    8a84:	8b000042 	add	x2, x2, x0
    8a88:	39400040 	ldrb	w0, [x2]
    8a8c:	7100041f 	cmp	w0, #0x1
    8a90:	54fffc80 	b.eq	8a20 <fwp_hof0.constprop.0+0xc10>  // b.none
    8a94:	eb1700bf 	cmp	x5, x23
    8a98:	54000cc9 	b.ls	8c30 <fwp_hof0.constprop.0+0xe20>  // b.plast
    8a9c:	aa0503f8 	mov	x24, x5
    8aa0:	d1002379 	sub	x25, x27, #0x8
    8aa4:	910323f3 	add	x19, sp, #0xc8
    8aa8:	9115029a 	add	x26, x20, #0x540
    8aac:	d280001c 	mov	x28, #0x0                   	// #0
    8ab0:	14000012 	b	8af8 <fwp_hof0.constprop.0+0xce8>
    8ab4:	7100045f 	cmp	w2, #0x1
    8ab8:	540001a1 	b.ne	8aec <fwp_hof0.constprop.0+0xcdc>  // b.any
    8abc:	29430909 	ldp	w9, w2, [x8, #24]
    8ac0:	92403c21 	and	x1, x1, #0xffff
    8ac4:	9b097c21 	mul	x1, x1, x9
    8ac8:	d360fc21 	lsr	x1, x1, #32
    8acc:	eb02003f 	cmp	x1, x2
    8ad0:	540000e2 	b.cs	8aec <fwp_hof0.constprop.0+0xcdc>  // b.hs, b.nlast
    8ad4:	8b010000 	add	x0, x0, x1
    8ad8:	39400001 	ldrb	w1, [x0]
    8adc:	7103fc3f 	cmp	w1, #0xff
    8ae0:	54002f00 	b.eq	90c0 <fwp_hof0.constprop.0+0x12b0>  // b.none
    8ae4:	52800021 	mov	w1, #0x1                   	// #1
    8ae8:	39000001 	strb	w1, [x0]
    8aec:	d1000718 	sub	x24, x24, #0x1
    8af0:	eb17031f 	cmp	x24, x23
    8af4:	54000369 	b.ls	8b60 <fwp_hof0.constprop.0+0xd50>  // b.plast
    8af8:	f8787b22 	ldr	x2, [x25, x24, lsl #3]
    8afc:	aa1303e1 	mov	x1, x19
    8b00:	52800020 	mov	w0, #0x1                   	// #1
    8b04:	a90cf3e2 	stp	x2, x28, [sp, #200]
    8b08:	97fff09f 	bl	4d84 <fwp_data.part.0.constprop.0>
    8b0c:	aa0003fc 	mov	x28, x0
    8b10:	f949db41 	ldr	x1, [x26, #5040]
    8b14:	f949ef40 	ldr	x0, [x26, #5080]
    8b18:	cb010381 	sub	x1, x28, x1
    8b1c:	eb00403f 	cmp	x1, x0, lsl #16
    8b20:	54fffe62 	b.cs	8aec <fwp_hof0.constprop.0+0xcdc>  // b.hs, b.nlast
    8b24:	d350fc20 	lsr	x0, x1, #16
    8b28:	f949ff49 	ldr	x9, [x26, #5112]
    8b2c:	8b000800 	add	x0, x0, x0, lsl #2
    8b30:	d37df002 	lsl	x2, x0, #3
    8b34:	8b020128 	add	x8, x9, x2
    8b38:	f9401100 	ldr	x0, [x8, #32]
    8b3c:	b4fffd80 	cbz	x0, 8aec <fwp_hof0.constprop.0+0xcdc>
    8b40:	38626922 	ldrb	w2, [x9, x2]
    8b44:	7100085f 	cmp	w2, #0x2
    8b48:	54fffb61 	b.ne	8ab4 <fwp_hof0.constprop.0+0xca4>  // b.any
    8b4c:	72003c3f 	tst	w1, #0xffff
    8b50:	54fffc40 	b.eq	8ad8 <fwp_hof0.constprop.0+0xcc8>  // b.none
    8b54:	d1000718 	sub	x24, x24, #0x1
    8b58:	eb17031f 	cmp	x24, x23
    8b5c:	54fffce8 	b.hi	8af8 <fwp_hof0.constprop.0+0xce8>  // b.pmore
    8b60:	b50006b7 	cbnz	x23, 8c34 <fwp_hof0.constprop.0+0xe24>
    8b64:	b94033e0 	ldr	w0, [sp, #48]
    8b68:	d2800004 	mov	x4, #0x0                   	// #0
    8b6c:	7100001f 	cmp	w0, #0x0
    8b70:	d2800020 	mov	x0, #0x1                   	// #1
    8b74:	9a9f037b 	csel	x27, x27, xzr, eq	// eq = none
    8b78:	b40007c4 	cbz	x4, 8c70 <fwp_hof0.constprop.0+0xe60>
    8b7c:	d1000497 	sub	x23, x4, #0x1
    8b80:	2a0003f9 	mov	w25, w0
    8b84:	9115029a 	add	x26, x20, #0x540
    8b88:	f8777b62 	ldr	x2, [x27, x23, lsl #3]
    8b8c:	aa1303e1 	mov	x1, x19
    8b90:	52800020 	mov	w0, #0x1                   	// #1
    8b94:	a90cf3e2 	stp	x2, x28, [sp, #200]
    8b98:	97fff07b 	bl	4d84 <fwp_data.part.0.constprop.0>
    8b9c:	aa0003fc 	mov	x28, x0
    8ba0:	f949db41 	ldr	x1, [x26, #5040]
    8ba4:	f949ef40 	ldr	x0, [x26, #5080]
    8ba8:	cb010381 	sub	x1, x28, x1
    8bac:	eb00403f 	cmp	x1, x0, lsl #16
    8bb0:	54000302 	b.cs	8c10 <fwp_hof0.constprop.0+0xe00>  // b.hs, b.nlast
    8bb4:	d350fc22 	lsr	x2, x1, #16
    8bb8:	f949ff47 	ldr	x7, [x26, #5112]
    8bbc:	8b020842 	add	x2, x2, x2, lsl #2
    8bc0:	d37df042 	lsl	x2, x2, #3
    8bc4:	8b0200e6 	add	x6, x7, x2
    8bc8:	f94010d8 	ldr	x24, [x6, #32]
    8bcc:	b4000238 	cbz	x24, 8c10 <fwp_hof0.constprop.0+0xe00>
    8bd0:	386268e2 	ldrb	w2, [x7, x2]
    8bd4:	7100085f 	cmp	w2, #0x2
    8bd8:	54001440 	b.eq	8e60 <fwp_hof0.constprop.0+0x1050>  // b.none
    8bdc:	7100045f 	cmp	w2, #0x1
    8be0:	54000181 	b.ne	8c10 <fwp_hof0.constprop.0+0xe00>  // b.any
    8be4:	294308c7 	ldp	w7, w2, [x6, #24]
    8be8:	92403c21 	and	x1, x1, #0xffff
    8bec:	9b077c21 	mul	x1, x1, x7
    8bf0:	d360fc21 	lsr	x1, x1, #32
    8bf4:	eb02003f 	cmp	x1, x2
    8bf8:	540000c2 	b.cs	8c10 <fwp_hof0.constprop.0+0xe00>  // b.hs, b.nlast
    8bfc:	8b010318 	add	x24, x24, x1
    8c00:	39400301 	ldrb	w1, [x24]
    8c04:	7103fc3f 	cmp	w1, #0xff
    8c08:	54001260 	b.eq	8e54 <fwp_hof0.constprop.0+0x1044>  // b.none
    8c0c:	39000319 	strb	w25, [x24]
    8c10:	d10006f7 	sub	x23, x23, #0x1
    8c14:	b10006ff 	cmn	x23, #0x1
    8c18:	54fffb81 	b.ne	8b88 <fwp_hof0.constprop.0+0xd78>  // b.any
    8c1c:	14000015 	b	8c70 <fwp_hof0.constprop.0+0xe60>
    8c20:	72003c1f 	tst	w0, #0xffff
    8c24:	54fff320 	b.eq	8a88 <fwp_hof0.constprop.0+0xc78>  // b.none
    8c28:	eb1700bf 	cmp	x5, x23
    8c2c:	54fff388 	b.hi	8a9c <fwp_hof0.constprop.0+0xc8c>  // b.pmore
    8c30:	d280001c 	mov	x28, #0x0                   	// #0
    8c34:	8b170f64 	add	x4, x27, x23, lsl #3
    8c38:	aa1b03e1 	mov	x1, x27
    8c3c:	aa1503e0 	mov	x0, x21
    8c40:	f8408422 	ldr	x2, [x1], #8
    8c44:	f9000402 	str	x2, [x0, #8]
    8c48:	aa0003e2 	mov	x2, x0
    8c4c:	f9400800 	ldr	x0, [x0, #16]
    8c50:	eb04003f 	cmp	x1, x4
    8c54:	54ffff61 	b.ne	8c40 <fwp_hof0.constprop.0+0xe30>  // b.any
    8c58:	b94033e1 	ldr	w1, [sp, #48]
    8c5c:	f900085c 	str	x28, [x2, #16]
    8c60:	aa1503fc 	mov	x28, x21
    8c64:	aa0003f5 	mov	x21, x0
    8c68:	34000041 	cbz	w1, 8c70 <fwp_hof0.constprop.0+0xe60>
    8c6c:	d280001b 	mov	x27, #0x0                   	// #0
    8c70:	91150293 	add	x19, x20, #0x540
    8c74:	aa1b03e0 	mov	x0, x27
    8c78:	97ffeede 	bl	47f0 <fwp_mem_free>
    8c7c:	f949ee62 	ldr	x2, [x19, #5080]
    8c80:	f949da61 	ldr	x1, [x19, #5040]
    8c84:	d370bc42 	lsl	x2, x2, #16
    8c88:	cb0102c3 	sub	x3, x22, x1
    8c8c:	eb02007f 	cmp	x3, x2
    8c90:	54000402 	b.cs	8d10 <fwp_hof0.constprop.0+0xf00>  // b.hs, b.nlast
    8c94:	d350fc60 	lsr	x0, x3, #16
    8c98:	f949fe65 	ldr	x5, [x19, #5112]
    8c9c:	8b000800 	add	x0, x0, x0, lsl #2
    8ca0:	d37df000 	lsl	x0, x0, #3
    8ca4:	8b0000a2 	add	x2, x5, x0
    8ca8:	f9401057 	ldr	x23, [x2, #32]
    8cac:	b4000cb7 	cbz	x23, 8e40 <fwp_hof0.constprop.0+0x1030>
    8cb0:	386068a1 	ldrb	w1, [x5, x0]
    8cb4:	7100083f 	cmp	w1, #0x2
    8cb8:	54003160 	b.eq	92e4 <fwp_hof0.constprop.0+0x14d4>  // b.none
    8cbc:	7100043f 	cmp	w1, #0x1
    8cc0:	54000c01 	b.ne	8e40 <fwp_hof0.constprop.0+0x1030>  // b.any
    8cc4:	29430844 	ldp	w4, w2, [x2, #24]
    8cc8:	92403c61 	and	x1, x3, #0xffff
    8ccc:	9b047c21 	mul	x1, x1, x4
    8cd0:	d360fc21 	lsr	x1, x1, #32
    8cd4:	eb02003f 	cmp	x1, x2
    8cd8:	54000b42 	b.cs	8e40 <fwp_hof0.constprop.0+0x1030>  // b.hs, b.nlast
    8cdc:	8b0102f7 	add	x23, x23, x1
    8ce0:	394002e1 	ldrb	w1, [x23]
    8ce4:	34000ae1 	cbz	w1, 8e40 <fwp_hof0.constprop.0+0x1030>
    8ce8:	7100043f 	cmp	w1, #0x1
    8cec:	540006a0 	b.eq	8dc0 <fwp_hof0.constprop.0+0xfb0>  // b.none
    8cf0:	7103fc3f 	cmp	w1, #0xff
    8cf4:	54004a00 	b.eq	9634 <fwp_hof0.constprop.0+0x1824>  // b.none
    8cf8:	91150280 	add	x0, x20, #0x540
    8cfc:	51000421 	sub	w1, w1, #0x1
    8d00:	390002e1 	strb	w1, [x23]
    8d04:	f949ec02 	ldr	x2, [x0, #5080]
    8d08:	f949d801 	ldr	x1, [x0, #5040]
    8d0c:	d370bc42 	lsl	x2, x2, #16
    8d10:	cb0102a1 	sub	x1, x21, x1
    8d14:	eb02003f 	cmp	x1, x2
    8d18:	540003c2 	b.cs	8d90 <fwp_hof0.constprop.0+0xf80>  // b.hs, b.nlast
    8d1c:	91150296 	add	x22, x20, #0x540
    8d20:	d350fc20 	lsr	x0, x1, #16
    8d24:	f949fec3 	ldr	x3, [x22, #5112]
    8d28:	8b000800 	add	x0, x0, x0, lsl #2
    8d2c:	d37df000 	lsl	x0, x0, #3
    8d30:	8b000062 	add	x2, x3, x0
    8d34:	f9401053 	ldr	x19, [x2, #32]
    8d38:	b40002d3 	cbz	x19, 8d90 <fwp_hof0.constprop.0+0xf80>
    8d3c:	38606860 	ldrb	w0, [x3, x0]
    8d40:	7100081f 	cmp	w0, #0x2
    8d44:	54003180 	b.eq	9374 <fwp_hof0.constprop.0+0x1564>  // b.none
    8d48:	7100041f 	cmp	w0, #0x1
    8d4c:	54000221 	b.ne	8d90 <fwp_hof0.constprop.0+0xf80>  // b.any
    8d50:	29430044 	ldp	w4, w0, [x2, #24]
    8d54:	92403c21 	and	x1, x1, #0xffff
    8d58:	9b047c21 	mul	x1, x1, x4
    8d5c:	d360fc21 	lsr	x1, x1, #32
    8d60:	eb00003f 	cmp	x1, x0
    8d64:	54000162 	b.cs	8d90 <fwp_hof0.constprop.0+0xf80>  // b.hs, b.nlast
    8d68:	8b010273 	add	x19, x19, x1
    8d6c:	39400260 	ldrb	w0, [x19]
    8d70:	34000100 	cbz	w0, 8d90 <fwp_hof0.constprop.0+0xf80>
    8d74:	7100041f 	cmp	w0, #0x1
    8d78:	54003840 	b.eq	9480 <fwp_hof0.constprop.0+0x1670>  // b.none
    8d7c:	7103fc1f 	cmp	w0, #0xff
    8d80:	54004940 	b.eq	96a8 <fwp_hof0.constprop.0+0x1898>  // b.none
    8d84:	51000400 	sub	w0, w0, #0x1
    8d88:	39000260 	strb	w0, [x19]
    8d8c:	d503201f 	nop
    8d90:	f94007e0 	ldr	x0, [sp, #8]
    8d94:	b40019e0 	cbz	x0, 90d0 <fwp_hof0.constprop.0+0x12c0>
    8d98:	f94007e0 	ldr	x0, [sp, #8]
    8d9c:	f100041a 	subs	x26, x0, #0x1
    8da0:	f90007fa 	str	x26, [sp, #8]
    8da4:	540057e6 	b.vs	98a0 <fwp_hof0.constprop.0+0x1a90>
    8da8:	91150280 	add	x0, x20, #0x540
    8dac:	aa1c03f5 	mov	x21, x28
    8db0:	f949ec03 	ldr	x3, [x0, #5080]
    8db4:	f949d801 	ldr	x1, [x0, #5040]
    8db8:	d370bc63 	lsl	x3, x3, #16
    8dbc:	17fffc59 	b	7f20 <fwp_hof0.constprop.0+0x110>
    8dc0:	f94002c3 	ldr	x3, [x22]
    8dc4:	aa1603e0 	mov	x0, x22
    8dc8:	f949ee62 	ldr	x2, [x19, #5080]
    8dcc:	f949da61 	ldr	x1, [x19, #5040]
    8dd0:	d370bc42 	lsl	x2, x2, #16
    8dd4:	cb0102c7 	sub	x7, x22, x1
    8dd8:	b7f82d43 	tbnz	x3, #63, 9380 <fwp_hof0.constprop.0+0x1570>
    8ddc:	eb07005f 	cmp	x2, x7
    8de0:	54fff989 	b.ls	8d10 <fwp_hof0.constprop.0+0xf00>  // b.plast
    8de4:	d350fce3 	lsr	x3, x7, #16
    8de8:	8b030863 	add	x3, x3, x3, lsl #2
    8dec:	d37df063 	lsl	x3, x3, #3
    8df0:	8b0300a6 	add	x6, x5, x3
    8df4:	f94010c4 	ldr	x4, [x6, #32]
    8df8:	b4fff8c4 	cbz	x4, 8d10 <fwp_hof0.constprop.0+0xf00>
    8dfc:	386368a3 	ldrb	w3, [x5, x3]
    8e00:	7100087f 	cmp	w3, #0x2
    8e04:	540038e0 	b.eq	9520 <fwp_hof0.constprop.0+0x1710>  // b.none
    8e08:	7100047f 	cmp	w3, #0x1
    8e0c:	54fff821 	b.ne	8d10 <fwp_hof0.constprop.0+0xf00>  // b.any
    8e10:	29430cc5 	ldp	w5, w3, [x6, #24]
    8e14:	92403ce0 	and	x0, x7, #0xffff
    8e18:	9b057c00 	mul	x0, x0, x5
    8e1c:	d360fc00 	lsr	x0, x0, #32
    8e20:	eb03001f 	cmp	x0, x3
    8e24:	54fff762 	b.cs	8d10 <fwp_hof0.constprop.0+0xf00>  // b.hs, b.nlast
    8e28:	8b000084 	add	x4, x4, x0
    8e2c:	39400080 	ldrb	w0, [x4]
    8e30:	7100041f 	cmp	w0, #0x1
    8e34:	54fff6e1 	b.ne	8d10 <fwp_hof0.constprop.0+0xf00>  // b.any
    8e38:	aa1603e0 	mov	x0, x22
    8e3c:	97ffee6d 	bl	47f0 <fwp_mem_free>
    8e40:	91150280 	add	x0, x20, #0x540
    8e44:	f949ec02 	ldr	x2, [x0, #5080]
    8e48:	f949d801 	ldr	x1, [x0, #5040]
    8e4c:	d370bc42 	lsl	x2, x2, #16
    8e50:	17ffffb0 	b	8d10 <fwp_hof0.constprop.0+0xf00>
    8e54:	aa1803e0 	mov	x0, x24
    8e58:	97ffedc6 	bl	4570 <fwp_rc_forget_slot>
    8e5c:	17ffff6c 	b	8c0c <fwp_hof0.constprop.0+0xdfc>
    8e60:	72003c3f 	tst	w1, #0xffff
    8e64:	54ffed61 	b.ne	8c10 <fwp_hof0.constprop.0+0xe00>  // b.any
    8e68:	17ffff66 	b	8c00 <fwp_hof0.constprop.0+0xdf0>
    8e6c:	72003c1f 	tst	w0, #0xffff
    8e70:	54ffd840 	b.eq	8978 <fwp_hof0.constprop.0+0xb68>  // b.none
    8e74:	b4000ff5 	cbz	x21, 9070 <fwp_hof0.constprop.0+0x1260>
    8e78:	aa1503f3 	mov	x19, x21
    8e7c:	d2800017 	mov	x23, #0x0                   	// #0
    8e80:	f9400a73 	ldr	x19, [x19, #16]
    8e84:	aa1703e0 	mov	x0, x23
    8e88:	910006f7 	add	x23, x23, #0x1
    8e8c:	b5ffffb3 	cbnz	x19, 8e80 <fwp_hof0.constprop.0+0x1070>
    8e90:	f9001be5 	str	x5, [sp, #48]
    8e94:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8e98:	eb0102ff 	cmp	x23, x1
    8e9c:	54004c68 	b.hi	9828 <fwp_hof0.constprop.0+0x1a18>  // b.pmore
    8ea0:	91000800 	add	x0, x0, #0x2
    8ea4:	52800041 	mov	w1, #0x2                   	// #2
    8ea8:	d37df000 	lsl	x0, x0, #3
    8eac:	97ffef71 	bl	4c70 <fwp_heap_alloc>
    8eb0:	f9401be5 	ldr	x5, [sp, #48]
    8eb4:	aa0003fb 	mov	x27, x0
    8eb8:	aa1503e1 	mov	x1, x21
    8ebc:	eb0502ff 	cmp	x23, x5
    8ec0:	9a8592e5 	csel	x5, x23, x5, ls	// ls = plast
    8ec4:	d503201f 	nop
    8ec8:	f9400420 	ldr	x0, [x1, #8]
    8ecc:	f8337b60 	str	x0, [x27, x19, lsl #3]
    8ed0:	91000673 	add	x19, x19, #0x1
    8ed4:	f9400821 	ldr	x1, [x1, #16]
    8ed8:	b5ffff81 	cbnz	x1, 8ec8 <fwp_hof0.constprop.0+0x10b8>
    8edc:	b4000d25 	cbz	x5, 9080 <fwp_hof0.constprop.0+0x1270>
    8ee0:	f9400384 	ldr	x4, [x28]
    8ee4:	b90033ff 	str	wzr, [sp, #48]
    8ee8:	17fffeac 	b	8998 <fwp_hof0.constprop.0+0xb88>
    8eec:	eb1302df 	cmp	x22, x19
    8ef0:	54ff8fa0 	b.eq	80e4 <fwp_hof0.constprop.0+0x2d4>  // b.none
    8ef4:	900000c0 	adrp	x0, 20000 <__data_start>
    8ef8:	8b1606db 	add	x27, x22, x22, lsl #1
    8efc:	f940181c 	ldr	x28, [x0, #48]
    8f00:	8b1b0adb 	add	x27, x22, x27, lsl #2
    8f04:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    8f08:	91372000 	add	x0, x0, #0xdc8
    8f0c:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    8f10:	f900337f 	str	xzr, [x27, #96]
    8f14:	97ffe6bf 	bl	2a10 <getenv@plt>
    8f18:	b5ff9440 	cbnz	x0, 81a0 <fwp_hof0.constprop.0+0x390>
    8f1c:	900000c0 	adrp	x0, 20000 <__data_start>
    8f20:	9100c000 	add	x0, x0, #0x30
    8f24:	f9404001 	ldr	x1, [x0, #128]
    8f28:	b4ff9461 	cbz	x1, 81b4 <fwp_hof0.constprop.0+0x3a4>
    8f2c:	3cc48002 	ldur	q2, [x0, #72]
    8f30:	91012001 	add	x1, x0, #0x48
    8f34:	3cc58001 	ldur	q1, [x0, #88]
    8f38:	f900401f 	str	xzr, [x0, #128]
    8f3c:	4f000400 	movi	v0.4s, #0x0
    8f40:	ad010762 	stp	q2, q1, [x27, #32]
    8f44:	a9468002 	ldp	x2, x0, [x0, #104]
    8f48:	f9000f60 	str	x0, [x27, #24]
    8f4c:	f9401820 	ldr	x0, [x1, #48]
    8f50:	f9002362 	str	x2, [x27, #64]
    8f54:	f9002760 	str	x0, [x27, #72]
    8f58:	ad000020 	stp	q0, q0, [x1]
    8f5c:	3d800820 	str	q0, [x1, #32]
    8f60:	f900183f 	str	xzr, [x1, #48]
    8f64:	17fffc94 	b	81b4 <fwp_hof0.constprop.0+0x3a4>
    8f68:	d53bd040 	mrs	x0, tpidr_el0
    8f6c:	91400000 	add	x0, x0, #0x0, lsl #12
    8f70:	91004000 	add	x0, x0, #0x10
    8f74:	f9400000 	ldr	x0, [x0]
    8f78:	b4002460 	cbz	x0, 9404 <fwp_hof0.constprop.0+0x15f4>
    8f7c:	f94017e1 	ldr	x1, [sp, #40]
    8f80:	97ffe999 	bl	35e4 <fwp_closure_drop_push>
    8f84:	b5ff8695 	cbnz	x21, 8054 <fwp_hof0.constprop.0+0x244>
    8f88:	900000c0 	adrp	x0, 20000 <__data_start>
    8f8c:	9100c013 	add	x19, x0, #0x30
    8f90:	d2800017 	mov	x23, #0x0                   	// #0
    8f94:	b942f660 	ldr	w0, [x19, #756]
    8f98:	35ff87a0 	cbnz	w0, 808c <fwp_hof0.constprop.0+0x27c>
    8f9c:	d503201f 	nop
    8fa0:	b0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push.constprop.0+0x15c>
    8fa4:	9133c000 	add	x0, x0, #0xcf0
    8fa8:	940012ee 	bl	db60 <atexit>
    8fac:	35ffc420 	cbnz	w0, 8830 <fwp_hof0.constprop.0+0xa20>
    8fb0:	52800020 	mov	w0, #0x1                   	// #1
    8fb4:	b902f660 	str	w0, [x19, #756]
    8fb8:	17fffc35 	b	808c <fwp_hof0.constprop.0+0x27c>
    8fbc:	72003c1f 	tst	w0, #0xffff
    8fc0:	54ffbe40 	b.eq	8788 <fwp_hof0.constprop.0+0x978>  // b.none
    8fc4:	d503201f 	nop
    8fc8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8fcc:	eb0002ff 	cmp	x23, x0
    8fd0:	54004508 	b.hi	9870 <fwp_hof0.constprop.0+0x1a60>  // b.pmore
    8fd4:	910006e0 	add	x0, x23, #0x1
    8fd8:	52800021 	mov	w1, #0x1                   	// #1
    8fdc:	d37df000 	lsl	x0, x0, #3
    8fe0:	97ffef24 	bl	4c70 <fwp_heap_alloc>
    8fe4:	91150282 	add	x2, x20, #0x540
    8fe8:	f9000017 	str	x23, [x0]
    8fec:	aa0003fc 	mov	x28, x0
    8ff0:	aa0003f6 	mov	x22, x0
    8ff4:	f949d841 	ldr	x1, [x2, #5040]
    8ff8:	f949ec40 	ldr	x0, [x2, #5080]
    8ffc:	cb010381 	sub	x1, x28, x1
    9000:	eb00403f 	cmp	x1, x0, lsl #16
    9004:	54000322 	b.cs	9068 <fwp_hof0.constprop.0+0x1258>  // b.hs, b.nlast
    9008:	d350fc20 	lsr	x0, x1, #16
    900c:	f949fc44 	ldr	x4, [x2, #5112]
    9010:	8b000800 	add	x0, x0, x0, lsl #2
    9014:	d37df002 	lsl	x2, x0, #3
    9018:	8b020083 	add	x3, x4, x2
    901c:	f9401078 	ldr	x24, [x3, #32]
    9020:	b4000258 	cbz	x24, 9068 <fwp_hof0.constprop.0+0x1258>
    9024:	38626882 	ldrb	w2, [x4, x2]
    9028:	7100085f 	cmp	w2, #0x2
    902c:	54002800 	b.eq	952c <fwp_hof0.constprop.0+0x171c>  // b.none
    9030:	7100045f 	cmp	w2, #0x1
    9034:	540001a1 	b.ne	9068 <fwp_hof0.constprop.0+0x1258>  // b.any
    9038:	29430864 	ldp	w4, w2, [x3, #24]
    903c:	92403c21 	and	x1, x1, #0xffff
    9040:	9b047c21 	mul	x1, x1, x4
    9044:	d360fc21 	lsr	x1, x1, #32
    9048:	eb02003f 	cmp	x1, x2
    904c:	540000e2 	b.cs	9068 <fwp_hof0.constprop.0+0x1258>  // b.hs, b.nlast
    9050:	8b010318 	add	x24, x24, x1
    9054:	39400301 	ldrb	w1, [x24]
    9058:	7103fc3f 	cmp	w1, #0xff
    905c:	54002700 	b.eq	953c <fwp_hof0.constprop.0+0x172c>  // b.none
    9060:	52800021 	mov	w1, #0x1                   	// #1
    9064:	39000301 	strb	w1, [x24]
    9068:	aa1303e0 	mov	x0, x19
    906c:	17fffdcd 	b	87a0 <fwp_hof0.constprop.0+0x990>
    9070:	52800041 	mov	w1, #0x2                   	// #2
    9074:	d2800100 	mov	x0, #0x8                   	// #8
    9078:	97ffeefe 	bl	4c70 <fwp_heap_alloc>
    907c:	aa0003fb 	mov	x27, x0
    9080:	d280001c 	mov	x28, #0x0                   	// #0
    9084:	17fffefb 	b	8c70 <fwp_hof0.constprop.0+0xe60>
    9088:	52800041 	mov	w1, #0x2                   	// #2
    908c:	d2800100 	mov	x0, #0x8                   	// #8
    9090:	97ffeef8 	bl	4c70 <fwp_heap_alloc>
    9094:	aa0003f7 	mov	x23, x0
    9098:	91150280 	add	x0, x20, #0x540
    909c:	aa1703fb 	mov	x27, x23
    90a0:	f90002ff 	str	xzr, [x23]
    90a4:	f949d801 	ldr	x1, [x0, #5040]
    90a8:	f949ec00 	ldr	x0, [x0, #5080]
    90ac:	cb0102e1 	sub	x1, x23, x1
    90b0:	eb00403f 	cmp	x1, x0, lsl #16
    90b4:	540010e2 	b.cs	92d0 <fwp_hof0.constprop.0+0x14c0>  // b.hs, b.nlast
    90b8:	d2800016 	mov	x22, #0x0                   	// #0
    90bc:	17fffc83 	b	82c8 <fwp_hof0.constprop.0+0x4b8>
    90c0:	f9001fe0 	str	x0, [sp, #56]
    90c4:	97ffed2b 	bl	4570 <fwp_rc_forget_slot>
    90c8:	f9401fe0 	ldr	x0, [sp, #56]
    90cc:	17fffe86 	b	8ae4 <fwp_hof0.constprop.0+0xcd4>
    90d0:	f9400be0 	ldr	x0, [sp, #16]
    90d4:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe430>
    90d8:	910aa042 	add	x2, x2, #0x2a8
    90dc:	aa1c03e1 	mov	x1, x28
    90e0:	91014042 	add	x2, x2, #0x50
    90e4:	52800023 	mov	w3, #0x1                   	// #1
    90e8:	a9097fff 	stp	xzr, xzr, [sp, #144]
    90ec:	f90053ff 	str	xzr, [sp, #160]
    90f0:	97fff74c 	bl	6e20 <fwp_write>
    90f4:	a9495bf5 	ldp	x21, x22, [sp, #144]
    90f8:	b0000020 	adrp	x0, e000 <_IO_stdin_used+0x470>
    90fc:	91170000 	add	x0, x0, #0x5c0
    9100:	f10002bf 	cmp	x21, #0x0
    9104:	9a950015 	csel	x21, x0, x21, eq	// eq = none
    9108:	b1002adf 	cmn	x22, #0xa
    910c:	54003ac8 	b.hi	9864 <fwp_hof0.constprop.0+0x1a54>  // b.pmore
    9110:	910026c0 	add	x0, x22, #0x9
    9114:	52800021 	mov	w1, #0x1                   	// #1
    9118:	97ffeed6 	bl	4c70 <fwp_heap_alloc>
    911c:	aa0003f7 	mov	x23, x0
    9120:	aa0003f3 	mov	x19, x0
    9124:	aa1603e2 	mov	x2, x22
    9128:	aa1503e1 	mov	x1, x21
    912c:	f80086f6 	str	x22, [x23], #8
    9130:	8b160276 	add	x22, x19, x22
    9134:	aa1703e0 	mov	x0, x23
    9138:	97ffe566 	bl	26d0 <memcpy@plt>
    913c:	390022df 	strb	wzr, [x22, #8]
    9140:	f9404be0 	ldr	x0, [sp, #144]
    9144:	97ffe5ff 	bl	2940 <free@plt>
    9148:	91150281 	add	x1, x20, #0x540
    914c:	f949d822 	ldr	x2, [x1, #5040]
    9150:	f949ec20 	ldr	x0, [x1, #5080]
    9154:	cb020262 	sub	x2, x19, x2
    9158:	eb00405f 	cmp	x2, x0, lsl #16
    915c:	54000322 	b.cs	91c0 <fwp_hof0.constprop.0+0x13b0>  // b.hs, b.nlast
    9160:	d350fc40 	lsr	x0, x2, #16
    9164:	f949fc23 	ldr	x3, [x1, #5112]
    9168:	8b000800 	add	x0, x0, x0, lsl #2
    916c:	d37df001 	lsl	x1, x0, #3
    9170:	8b010060 	add	x0, x3, x1
    9174:	f9401015 	ldr	x21, [x0, #32]
    9178:	b4000255 	cbz	x21, 91c0 <fwp_hof0.constprop.0+0x13b0>
    917c:	38616861 	ldrb	w1, [x3, x1]
    9180:	7100083f 	cmp	w1, #0x2
    9184:	54002be0 	b.eq	9700 <fwp_hof0.constprop.0+0x18f0>  // b.none
    9188:	7100043f 	cmp	w1, #0x1
    918c:	540001a1 	b.ne	91c0 <fwp_hof0.constprop.0+0x13b0>  // b.any
    9190:	29430003 	ldp	w3, w0, [x0, #24]
    9194:	92403c41 	and	x1, x2, #0xffff
    9198:	9b037c21 	mul	x1, x1, x3
    919c:	d360fc21 	lsr	x1, x1, #32
    91a0:	eb00003f 	cmp	x1, x0
    91a4:	540000e2 	b.cs	91c0 <fwp_hof0.constprop.0+0x13b0>  // b.hs, b.nlast
    91a8:	8b0102b5 	add	x21, x21, x1
    91ac:	394002a0 	ldrb	w0, [x21]
    91b0:	7103fc1f 	cmp	w0, #0xff
    91b4:	54002b00 	b.eq	9714 <fwp_hof0.constprop.0+0x1904>  // b.none
    91b8:	52800020 	mov	w0, #0x1                   	// #1
    91bc:	390002a0 	strb	w0, [x21]
    91c0:	aa1c03e0 	mov	x0, x28
    91c4:	97fff1d7 	bl	5920 <fwp_drop0>
    91c8:	f00000a0 	adrp	x0, 20000 <__data_start>
    91cc:	9100c015 	add	x21, x0, #0x30
    91d0:	f9400262 	ldr	x2, [x19]
    91d4:	d2800021 	mov	x1, #0x1                   	// #1
    91d8:	f94006a3 	ldr	x3, [x21, #8]
    91dc:	aa1703e0 	mov	x0, x23
    91e0:	97ffe5e8 	bl	2980 <fwrite@plt>
    91e4:	f94006a1 	ldr	x1, [x21, #8]
    91e8:	52800140 	mov	w0, #0xa                   	// #10
    91ec:	97ffe56d 	bl	27a0 <fputc@plt>
    91f0:	91150281 	add	x1, x20, #0x540
    91f4:	f949d822 	ldr	x2, [x1, #5040]
    91f8:	f949ec20 	ldr	x0, [x1, #5080]
    91fc:	cb020262 	sub	x2, x19, x2
    9200:	eb00405f 	cmp	x2, x0, lsl #16
    9204:	54000382 	b.cs	9274 <fwp_hof0.constprop.0+0x1464>  // b.hs, b.nlast
    9208:	d350fc40 	lsr	x0, x2, #16
    920c:	f949fc23 	ldr	x3, [x1, #5112]
    9210:	8b000800 	add	x0, x0, x0, lsl #2
    9214:	d37df001 	lsl	x1, x0, #3
    9218:	8b010060 	add	x0, x3, x1
    921c:	f9401015 	ldr	x21, [x0, #32]
    9220:	b40002b5 	cbz	x21, 9274 <fwp_hof0.constprop.0+0x1464>
    9224:	38616861 	ldrb	w1, [x3, x1]
    9228:	7100083f 	cmp	w1, #0x2
    922c:	54002380 	b.eq	969c <fwp_hof0.constprop.0+0x188c>  // b.none
    9230:	7100043f 	cmp	w1, #0x1
    9234:	54000201 	b.ne	9274 <fwp_hof0.constprop.0+0x1464>  // b.any
    9238:	29430003 	ldp	w3, w0, [x0, #24]
    923c:	92403c41 	and	x1, x2, #0xffff
    9240:	9b037c21 	mul	x1, x1, x3
    9244:	d360fc21 	lsr	x1, x1, #32
    9248:	eb00003f 	cmp	x1, x0
    924c:	54000142 	b.cs	9274 <fwp_hof0.constprop.0+0x1464>  // b.hs, b.nlast
    9250:	8b0102b5 	add	x21, x21, x1
    9254:	394002a0 	ldrb	w0, [x21]
    9258:	340000e0 	cbz	w0, 9274 <fwp_hof0.constprop.0+0x1464>
    925c:	7100041f 	cmp	w0, #0x1
    9260:	54001a60 	b.eq	95ac <fwp_hof0.constprop.0+0x179c>  // b.none
    9264:	7103fc1f 	cmp	w0, #0xff
    9268:	54002ae0 	b.eq	97c4 <fwp_hof0.constprop.0+0x19b4>  // b.none
    926c:	51000400 	sub	w0, w0, #0x1
    9270:	390002a0 	strb	w0, [x21]
    9274:	f94027e0 	ldr	x0, [sp, #72]
    9278:	f9400800 	ldr	x0, [x0, #16]
    927c:	f90027e0 	str	x0, [sp, #72]
    9280:	b5ff5fe0 	cbnz	x0, 7e7c <fwp_hof0.constprop.0+0x6c>
    9284:	a94f53f3 	ldp	x19, x20, [sp, #240]
    9288:	a9505bf5 	ldp	x21, x22, [sp, #256]
    928c:	a95163f7 	ldp	x23, x24, [sp, #272]
    9290:	a9526bf9 	ldp	x25, x26, [sp, #288]
    9294:	a95373fb 	ldp	x27, x28, [sp, #304]
    9298:	fd40a3e8 	ldr	d8, [sp, #320]
    929c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    92a0:	f947f400 	ldr	x0, [x0, #4072]
    92a4:	f9406fe2 	ldr	x2, [sp, #216]
    92a8:	f9400001 	ldr	x1, [x0]
    92ac:	eb010042 	subs	x2, x2, x1
    92b0:	d2800001 	mov	x1, #0x0                   	// #0
    92b4:	54002e81 	b.ne	9884 <fwp_hof0.constprop.0+0x1a74>  // b.any
    92b8:	a94e7bfd 	ldp	x29, x30, [sp, #224]
    92bc:	d2800000 	mov	x0, #0x0                   	// #0
    92c0:	910543ff 	add	sp, sp, #0x150
    92c4:	d65f03c0 	ret
    92c8:	b5ff8356 	cbnz	x22, 8330 <fwp_hof0.constprop.0+0x520>
    92cc:	d503201f 	nop
    92d0:	d280001c 	mov	x28, #0x0                   	// #0
    92d4:	17fffc3e 	b	83cc <fwp_hof0.constprop.0+0x5bc>
    92d8:	72003c3f 	tst	w1, #0xffff
    92dc:	54ff8c21 	b.ne	8460 <fwp_hof0.constprop.0+0x650>  // b.any
    92e0:	17fffc58 	b	8440 <fwp_hof0.constprop.0+0x630>
    92e4:	72003c7f 	tst	w3, #0xffff
    92e8:	54ffdac1 	b.ne	8e40 <fwp_hof0.constprop.0+0x1030>  // b.any
    92ec:	17fffe7d 	b	8ce0 <fwp_hof0.constprop.0+0xed0>
    92f0:	f940077b 	ldr	x27, [x27, #8]
    92f4:	eb02007f 	cmp	x3, x2
    92f8:	54000369 	b.ls	9364 <fwp_hof0.constprop.0+0x1554>  // b.plast
    92fc:	d350fc45 	lsr	x5, x2, #16
    9300:	8b0508a5 	add	x5, x5, x5, lsl #2
    9304:	d37df0a5 	lsl	x5, x5, #3
    9308:	8b050087 	add	x7, x4, x5
    930c:	f94010e6 	ldr	x6, [x7, #32]
    9310:	b40002a6 	cbz	x6, 9364 <fwp_hof0.constprop.0+0x1554>
    9314:	38656884 	ldrb	w4, [x4, x5]
    9318:	7100089f 	cmp	w4, #0x2
    931c:	540013c0 	b.eq	9594 <fwp_hof0.constprop.0+0x1784>  // b.none
    9320:	7100049f 	cmp	w4, #0x1
    9324:	54000201 	b.ne	9364 <fwp_hof0.constprop.0+0x1554>  // b.any
    9328:	294310e5 	ldp	w5, w4, [x7, #24]
    932c:	92403c42 	and	x2, x2, #0xffff
    9330:	9b057c42 	mul	x2, x2, x5
    9334:	d360fc42 	lsr	x2, x2, #32
    9338:	eb04005f 	cmp	x2, x4
    933c:	54000142 	b.cs	9364 <fwp_hof0.constprop.0+0x1554>  // b.hs, b.nlast
    9340:	8b0200c6 	add	x6, x6, x2
    9344:	394000c2 	ldrb	w2, [x6]
    9348:	7100045f 	cmp	w2, #0x1
    934c:	540000c1 	b.ne	9364 <fwp_hof0.constprop.0+0x1554>  // b.any
    9350:	97ffed28 	bl	47f0 <fwp_mem_free>
    9354:	91150280 	add	x0, x20, #0x540
    9358:	f949ec03 	ldr	x3, [x0, #5080]
    935c:	f949d801 	ldr	x1, [x0, #5040]
    9360:	d370bc63 	lsl	x3, x3, #16
    9364:	cb010361 	sub	x1, x27, x1
    9368:	eb03003f 	cmp	x1, x3
    936c:	54ff8443 	b.cc	83f4 <fwp_hof0.constprop.0+0x5e4>  // b.lo, b.ul, b.last
    9370:	17fffc3c 	b	8460 <fwp_hof0.constprop.0+0x650>
    9374:	72003c3f 	tst	w1, #0xffff
    9378:	54ffd0c1 	b.ne	8d90 <fwp_hof0.constprop.0+0xf80>  // b.any
    937c:	17fffe7c 	b	8d6c <fwp_hof0.constprop.0+0xf5c>
    9380:	f94006d6 	ldr	x22, [x22, #8]
    9384:	eb07005f 	cmp	x2, x7
    9388:	54000369 	b.ls	93f4 <fwp_hof0.constprop.0+0x15e4>  // b.plast
    938c:	d350fce3 	lsr	x3, x7, #16
    9390:	8b030863 	add	x3, x3, x3, lsl #2
    9394:	d37df063 	lsl	x3, x3, #3
    9398:	8b0300a6 	add	x6, x5, x3
    939c:	f94010c4 	ldr	x4, [x6, #32]
    93a0:	b40002a4 	cbz	x4, 93f4 <fwp_hof0.constprop.0+0x15e4>
    93a4:	386368a3 	ldrb	w3, [x5, x3]
    93a8:	7100087f 	cmp	w3, #0x2
    93ac:	54000fa0 	b.eq	95a0 <fwp_hof0.constprop.0+0x1790>  // b.none
    93b0:	7100047f 	cmp	w3, #0x1
    93b4:	54000201 	b.ne	93f4 <fwp_hof0.constprop.0+0x15e4>  // b.any
    93b8:	294314c8 	ldp	w8, w5, [x6, #24]
    93bc:	92403ce3 	and	x3, x7, #0xffff
    93c0:	9b087c63 	mul	x3, x3, x8
    93c4:	d360fc63 	lsr	x3, x3, #32
    93c8:	eb05007f 	cmp	x3, x5
    93cc:	54000142 	b.cs	93f4 <fwp_hof0.constprop.0+0x15e4>  // b.hs, b.nlast
    93d0:	8b030084 	add	x4, x4, x3
    93d4:	39400083 	ldrb	w3, [x4]
    93d8:	7100047f 	cmp	w3, #0x1
    93dc:	540000c1 	b.ne	93f4 <fwp_hof0.constprop.0+0x15e4>  // b.any
    93e0:	97ffed04 	bl	47f0 <fwp_mem_free>
    93e4:	91150280 	add	x0, x20, #0x540
    93e8:	f949ec02 	ldr	x2, [x0, #5080]
    93ec:	f949d801 	ldr	x1, [x0, #5040]
    93f0:	d370bc42 	lsl	x2, x2, #16
    93f4:	cb0102c3 	sub	x3, x22, x1
    93f8:	eb03005f 	cmp	x2, x3
    93fc:	54ffc4c8 	b.hi	8c94 <fwp_hof0.constprop.0+0xe84>  // b.pmore
    9400:	17fffe44 	b	8d10 <fwp_hof0.constprop.0+0xf00>
    9404:	f94017e0 	ldr	x0, [sp, #40]
    9408:	97ffe8e6 	bl	37a0 <fwp_closure_drop.part.0>
    940c:	17fffb11 	b	8050 <fwp_hof0.constprop.0+0x240>
    9410:	72003c3f 	tst	w1, #0xffff
    9414:	54ff78c1 	b.ne	832c <fwp_hof0.constprop.0+0x51c>  // b.any
    9418:	39400380 	ldrb	w0, [x28]
    941c:	7103fc1f 	cmp	w0, #0xff
    9420:	54ff7821 	b.ne	8324 <fwp_hof0.constprop.0+0x514>  // b.any
    9424:	aa1c03e0 	mov	x0, x28
    9428:	97ffec52 	bl	4570 <fwp_rc_forget_slot>
    942c:	17fffbbe 	b	8324 <fwp_hof0.constprop.0+0x514>
    9430:	72003c3f 	tst	w1, #0xffff
    9434:	54ff60e1 	b.ne	8050 <fwp_hof0.constprop.0+0x240>  // b.any
    9438:	17fffafe 	b	8030 <fwp_hof0.constprop.0+0x220>
    943c:	72003c3f 	tst	w1, #0xffff
    9440:	54ff5e01 	b.ne	8000 <fwp_hof0.constprop.0+0x1f0>  // b.any
    9444:	aa1303e0 	mov	x0, x19
    9448:	17fffadb 	b	7fb4 <fwp_hof0.constprop.0+0x1a4>
    944c:	aa1c03f3 	mov	x19, x28
    9450:	17fffc38 	b	8530 <fwp_hof0.constprop.0+0x720>
    9454:	72003c3f 	tst	w1, #0xffff
    9458:	54ff94e1 	b.ne	86f4 <fwp_hof0.constprop.0+0x8e4>  // b.any
    945c:	394002c0 	ldrb	w0, [x22]
    9460:	7103fc1f 	cmp	w0, #0xff
    9464:	54ff9441 	b.ne	86ec <fwp_hof0.constprop.0+0x8dc>  // b.any
    9468:	aa1603e0 	mov	x0, x22
    946c:	97ffec41 	bl	4570 <fwp_rc_forget_slot>
    9470:	17fffc9f 	b	86ec <fwp_hof0.constprop.0+0x8dc>
    9474:	72003c5f 	tst	w2, #0xffff
    9478:	54ff7f41 	b.ne	8460 <fwp_hof0.constprop.0+0x650>  // b.any
    947c:	17fffd14 	b	88cc <fwp_hof0.constprop.0+0xabc>
    9480:	91150280 	add	x0, x20, #0x540
    9484:	f9400ab3 	ldr	x19, [x21, #16]
    9488:	f949ec04 	ldr	x4, [x0, #5080]
    948c:	f949d801 	ldr	x1, [x0, #5040]
    9490:	d370bc84 	lsl	x4, x4, #16
    9494:	cb0102a0 	sub	x0, x21, x1
    9498:	eb04001f 	cmp	x0, x4
    949c:	54000382 	b.cs	950c <fwp_hof0.constprop.0+0x16fc>  // b.hs, b.nlast
    94a0:	d350fc02 	lsr	x2, x0, #16
    94a4:	8b020842 	add	x2, x2, x2, lsl #2
    94a8:	d37df042 	lsl	x2, x2, #3
    94ac:	8b020066 	add	x6, x3, x2
    94b0:	f94010c5 	ldr	x5, [x6, #32]
    94b4:	b40002c5 	cbz	x5, 950c <fwp_hof0.constprop.0+0x16fc>
    94b8:	38626862 	ldrb	w2, [x3, x2]
    94bc:	7100085f 	cmp	w2, #0x2
    94c0:	540007c0 	b.eq	95b8 <fwp_hof0.constprop.0+0x17a8>  // b.none
    94c4:	7100045f 	cmp	w2, #0x1
    94c8:	54000221 	b.ne	950c <fwp_hof0.constprop.0+0x16fc>  // b.any
    94cc:	294308c3 	ldp	w3, w2, [x6, #24]
    94d0:	92403c00 	and	x0, x0, #0xffff
    94d4:	9b037c00 	mul	x0, x0, x3
    94d8:	d360fc00 	lsr	x0, x0, #32
    94dc:	eb02001f 	cmp	x0, x2
    94e0:	54000162 	b.cs	950c <fwp_hof0.constprop.0+0x16fc>  // b.hs, b.nlast
    94e4:	8b0000a5 	add	x5, x5, x0
    94e8:	394000a0 	ldrb	w0, [x5]
    94ec:	7100041f 	cmp	w0, #0x1
    94f0:	540000e1 	b.ne	950c <fwp_hof0.constprop.0+0x16fc>  // b.any
    94f4:	aa1503e0 	mov	x0, x21
    94f8:	97ffecbe 	bl	47f0 <fwp_mem_free>
    94fc:	91150280 	add	x0, x20, #0x540
    9500:	f949ec04 	ldr	x4, [x0, #5080]
    9504:	f949d801 	ldr	x1, [x0, #5040]
    9508:	d370bc84 	lsl	x4, x4, #16
    950c:	cb010261 	sub	x1, x19, x1
    9510:	eb01009f 	cmp	x4, x1
    9514:	54ffc3e9 	b.ls	8d90 <fwp_hof0.constprop.0+0xf80>  // b.plast
    9518:	aa1303f5 	mov	x21, x19
    951c:	17fffe01 	b	8d20 <fwp_hof0.constprop.0+0xf10>
    9520:	72003cff 	tst	w7, #0xffff
    9524:	54ffbf61 	b.ne	8d10 <fwp_hof0.constprop.0+0xf00>  // b.any
    9528:	17fffe41 	b	8e2c <fwp_hof0.constprop.0+0x101c>
    952c:	72003c3f 	tst	w1, #0xffff
    9530:	54ffd920 	b.eq	9054 <fwp_hof0.constprop.0+0x1244>  // b.none
    9534:	aa1303e0 	mov	x0, x19
    9538:	17fffc9a 	b	87a0 <fwp_hof0.constprop.0+0x990>
    953c:	aa1803e0 	mov	x0, x24
    9540:	97ffec0c 	bl	4570 <fwp_rc_forget_slot>
    9544:	17fffec7 	b	9060 <fwp_hof0.constprop.0+0x1250>
    9548:	aa1703e0 	mov	x0, x23
    954c:	d2800101 	mov	x1, #0x8                   	// #8
    9550:	97ffe4c4 	bl	2860 <calloc@plt>
    9554:	aa0003f8 	mov	x24, x0
    9558:	f9401be7 	ldr	x7, [sp, #48]
    955c:	17fffc07 	b	8578 <fwp_hof0.constprop.0+0x768>
    9560:	f9400384 	ldr	x4, [x28]
    9564:	b7ffd864 	tbnz	x4, #63, 9070 <fwp_hof0.constprop.0+0x1260>
    9568:	91150281 	add	x1, x20, #0x540
    956c:	f949d820 	ldr	x0, [x1, #5040]
    9570:	f949ec21 	ldr	x1, [x1, #5080]
    9574:	cb0002c0 	sub	x0, x22, x0
    9578:	eb01401f 	cmp	x0, x1, lsl #16
    957c:	54ffd7a2 	b.cs	9070 <fwp_hof0.constprop.0+0x1260>  // b.hs, b.nlast
    9580:	9240f885 	and	x5, x4, #0x7fffffffffffffff
    9584:	17fffce9 	b	8928 <fwp_hof0.constprop.0+0xb18>
    9588:	d2800d01 	mov	x1, #0x68                  	// #104
    958c:	d280003b 	mov	x27, #0x1                   	// #1
    9590:	17fffae7 	b	812c <fwp_hof0.constprop.0+0x31c>
    9594:	72003c5f 	tst	w2, #0xffff
    9598:	54ffee61 	b.ne	9364 <fwp_hof0.constprop.0+0x1554>  // b.any
    959c:	17ffff6a 	b	9344 <fwp_hof0.constprop.0+0x1534>
    95a0:	72003cff 	tst	w7, #0xffff
    95a4:	54fff281 	b.ne	93f4 <fwp_hof0.constprop.0+0x15e4>  // b.any
    95a8:	17ffff8b 	b	93d4 <fwp_hof0.constprop.0+0x15c4>
    95ac:	aa1303e0 	mov	x0, x19
    95b0:	97ffefb1 	bl	5474 <fwp_rc_free_arr>
    95b4:	17ffff30 	b	9274 <fwp_hof0.constprop.0+0x1464>
    95b8:	72003c1f 	tst	w0, #0xffff
    95bc:	54fffa81 	b.ne	950c <fwp_hof0.constprop.0+0x16fc>  // b.any
    95c0:	17ffffca 	b	94e8 <fwp_hof0.constprop.0+0x16d8>
    95c4:	72003c9f 	tst	w4, #0xffff
    95c8:	54ff4a61 	b.ne	7f14 <fwp_hof0.constprop.0+0x104>  // b.any
    95cc:	17fffa47 	b	7ee8 <fwp_hof0.constprop.0+0xd8>
    95d0:	ca5746e0 	eor	x0, x23, x23, lsr #17
    95d4:	91150281 	add	x1, x20, #0x540
    95d8:	ca402400 	eor	x0, x0, x0, lsr #9
    95dc:	8b200c20 	add	x0, x1, w0, uxtb #3
    95e0:	f94a2400 	ldr	x0, [x0, #5192]
    95e4:	b5000080 	cbnz	x0, 95f4 <fwp_hof0.constprop.0+0x17e4>
    95e8:	14000010 	b	9628 <fwp_hof0.constprop.0+0x1818>
    95ec:	f9400800 	ldr	x0, [x0, #16]
    95f0:	b40001c0 	cbz	x0, 9628 <fwp_hof0.constprop.0+0x1818>
    95f4:	f9400001 	ldr	x1, [x0]
    95f8:	eb17003f 	cmp	x1, x23
    95fc:	54ffff81 	b.ne	95ec <fwp_hof0.constprop.0+0x17dc>  // b.any
    9600:	f9400401 	ldr	x1, [x0, #8]
    9604:	d1000421 	sub	x1, x1, #0x1
    9608:	f9000401 	str	x1, [x0, #8]
    960c:	f103f83f 	cmp	x1, #0xfe
    9610:	54ff7281 	b.ne	8460 <fwp_hof0.constprop.0+0x650>  // b.any
    9614:	aa1703e0 	mov	x0, x23
    9618:	97ffebd6 	bl	4570 <fwp_rc_forget_slot>
    961c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9620:	390002e0 	strb	w0, [x23]
    9624:	17fffb8f 	b	8460 <fwp_hof0.constprop.0+0x650>
    9628:	90000020 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    962c:	9138e000 	add	x0, x0, #0xe38
    9630:	97ffe7d4 	bl	3580 <fwp_trap>
    9634:	ca5746e0 	eor	x0, x23, x23, lsr #17
    9638:	91150281 	add	x1, x20, #0x540
    963c:	ca402400 	eor	x0, x0, x0, lsr #9
    9640:	8b200c20 	add	x0, x1, w0, uxtb #3
    9644:	f94a2401 	ldr	x1, [x0, #5192]
    9648:	b5000081 	cbnz	x1, 9658 <fwp_hof0.constprop.0+0x1848>
    964c:	17fffff7 	b	9628 <fwp_hof0.constprop.0+0x1818>
    9650:	f9400821 	ldr	x1, [x1, #16]
    9654:	b4fffea1 	cbz	x1, 9628 <fwp_hof0.constprop.0+0x1818>
    9658:	f9400020 	ldr	x0, [x1]
    965c:	eb17001f 	cmp	x0, x23
    9660:	54ffff81 	b.ne	9650 <fwp_hof0.constprop.0+0x1840>  // b.any
    9664:	f9400420 	ldr	x0, [x1, #8]
    9668:	d1000400 	sub	x0, x0, #0x1
    966c:	f9000420 	str	x0, [x1, #8]
    9670:	f103f81f 	cmp	x0, #0xfe
    9674:	54ffbe61 	b.ne	8e40 <fwp_hof0.constprop.0+0x1030>  // b.any
    9678:	aa1703e0 	mov	x0, x23
    967c:	97ffebbd 	bl	4570 <fwp_rc_forget_slot>
    9680:	91150280 	add	x0, x20, #0x540
    9684:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9688:	390002e1 	strb	w1, [x23]
    968c:	f949ec02 	ldr	x2, [x0, #5080]
    9690:	f949d801 	ldr	x1, [x0, #5040]
    9694:	d370bc42 	lsl	x2, x2, #16
    9698:	17fffd9e 	b	8d10 <fwp_hof0.constprop.0+0xf00>
    969c:	72003c5f 	tst	w2, #0xffff
    96a0:	54ffdea1 	b.ne	9274 <fwp_hof0.constprop.0+0x1464>  // b.any
    96a4:	17fffeec 	b	9254 <fwp_hof0.constprop.0+0x1444>
    96a8:	ca534660 	eor	x0, x19, x19, lsr #17
    96ac:	91150281 	add	x1, x20, #0x540
    96b0:	ca402400 	eor	x0, x0, x0, lsr #9
    96b4:	8b200c20 	add	x0, x1, w0, uxtb #3
    96b8:	f94a2400 	ldr	x0, [x0, #5192]
    96bc:	b5000080 	cbnz	x0, 96cc <fwp_hof0.constprop.0+0x18bc>
    96c0:	17ffffda 	b	9628 <fwp_hof0.constprop.0+0x1818>
    96c4:	f9400800 	ldr	x0, [x0, #16]
    96c8:	b4fffb00 	cbz	x0, 9628 <fwp_hof0.constprop.0+0x1818>
    96cc:	f9400001 	ldr	x1, [x0]
    96d0:	eb01027f 	cmp	x19, x1
    96d4:	54ffff81 	b.ne	96c4 <fwp_hof0.constprop.0+0x18b4>  // b.any
    96d8:	f9400401 	ldr	x1, [x0, #8]
    96dc:	d1000421 	sub	x1, x1, #0x1
    96e0:	f9000401 	str	x1, [x0, #8]
    96e4:	f103f83f 	cmp	x1, #0xfe
    96e8:	54ffb541 	b.ne	8d90 <fwp_hof0.constprop.0+0xf80>  // b.any
    96ec:	aa1303e0 	mov	x0, x19
    96f0:	97ffeba0 	bl	4570 <fwp_rc_forget_slot>
    96f4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    96f8:	39000260 	strb	w0, [x19]
    96fc:	17fffda5 	b	8d90 <fwp_hof0.constprop.0+0xf80>
    9700:	72003c5f 	tst	w2, #0xffff
    9704:	54ffd5e1 	b.ne	91c0 <fwp_hof0.constprop.0+0x13b0>  // b.any
    9708:	394002a0 	ldrb	w0, [x21]
    970c:	7103fc1f 	cmp	w0, #0xff
    9710:	54ffd541 	b.ne	91b8 <fwp_hof0.constprop.0+0x13a8>  // b.any
    9714:	aa1503e0 	mov	x0, x21
    9718:	97ffeb96 	bl	4570 <fwp_rc_forget_slot>
    971c:	17fffea7 	b	91b8 <fwp_hof0.constprop.0+0x13a8>
    9720:	d280001b 	mov	x27, #0x0                   	// #0
    9724:	d280001c 	mov	x28, #0x0                   	// #0
    9728:	17fffd52 	b	8c70 <fwp_hof0.constprop.0+0xe60>
    972c:	97ffeb4a 	bl	4454 <fwp_rc_wide_dup>
    9730:	17fffa27 	b	7fcc <fwp_hof0.constprop.0+0x1bc>
    9734:	ca534660 	eor	x0, x19, x19, lsr #17
    9738:	91150281 	add	x1, x20, #0x540
    973c:	ca402400 	eor	x0, x0, x0, lsr #9
    9740:	8b200c20 	add	x0, x1, w0, uxtb #3
    9744:	f94a2400 	ldr	x0, [x0, #5192]
    9748:	b5000080 	cbnz	x0, 9758 <fwp_hof0.constprop.0+0x1948>
    974c:	17ffffb7 	b	9628 <fwp_hof0.constprop.0+0x1818>
    9750:	f9400800 	ldr	x0, [x0, #16]
    9754:	b4fff6a0 	cbz	x0, 9628 <fwp_hof0.constprop.0+0x1818>
    9758:	f9400001 	ldr	x1, [x0]
    975c:	eb13003f 	cmp	x1, x19
    9760:	54ffff81 	b.ne	9750 <fwp_hof0.constprop.0+0x1940>  // b.any
    9764:	f9400401 	ldr	x1, [x0, #8]
    9768:	d1000421 	sub	x1, x1, #0x1
    976c:	f9000401 	str	x1, [x0, #8]
    9770:	f103f83f 	cmp	x1, #0xfe
    9774:	54ff46e1 	b.ne	8050 <fwp_hof0.constprop.0+0x240>  // b.any
    9778:	aa1303e0 	mov	x0, x19
    977c:	97ffeb7d 	bl	4570 <fwp_rc_forget_slot>
    9780:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9784:	39000260 	strb	w0, [x19]
    9788:	17fffa32 	b	8050 <fwp_hof0.constprop.0+0x240>
    978c:	d2800017 	mov	x23, #0x0                   	// #0
    9790:	17fffcc3 	b	8a9c <fwp_hof0.constprop.0+0xc8c>
    9794:	90000020 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    9798:	913a0000 	add	x0, x0, #0xe80
    979c:	97ffe779 	bl	3580 <fwp_trap>
    97a0:	90000020 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    97a4:	913c6000 	add	x0, x0, #0xf18
    97a8:	97ffe776 	bl	3580 <fwp_trap>
    97ac:	97ffeb2a 	bl	4454 <fwp_rc_wide_dup>
    97b0:	91150280 	add	x0, x20, #0x540
    97b4:	f949ec03 	ldr	x3, [x0, #5080]
    97b8:	f949d801 	ldr	x1, [x0, #5040]
    97bc:	d370bc63 	lsl	x3, x3, #16
    97c0:	17fff9d5 	b	7f14 <fwp_hof0.constprop.0+0x104>
    97c4:	ca5546a0 	eor	x0, x21, x21, lsr #17
    97c8:	91150281 	add	x1, x20, #0x540
    97cc:	ca402400 	eor	x0, x0, x0, lsr #9
    97d0:	8b200c20 	add	x0, x1, w0, uxtb #3
    97d4:	f94a2400 	ldr	x0, [x0, #5192]
    97d8:	b5000080 	cbnz	x0, 97e8 <fwp_hof0.constprop.0+0x19d8>
    97dc:	17ffff93 	b	9628 <fwp_hof0.constprop.0+0x1818>
    97e0:	f9400800 	ldr	x0, [x0, #16]
    97e4:	b4fff220 	cbz	x0, 9628 <fwp_hof0.constprop.0+0x1818>
    97e8:	f9400001 	ldr	x1, [x0]
    97ec:	eb15003f 	cmp	x1, x21
    97f0:	54ffff81 	b.ne	97e0 <fwp_hof0.constprop.0+0x19d0>  // b.any
    97f4:	f9400401 	ldr	x1, [x0, #8]
    97f8:	d1000421 	sub	x1, x1, #0x1
    97fc:	f9000401 	str	x1, [x0, #8]
    9800:	f103f83f 	cmp	x1, #0xfe
    9804:	54ffd381 	b.ne	9274 <fwp_hof0.constprop.0+0x1464>  // b.any
    9808:	aa1503e0 	mov	x0, x21
    980c:	97ffeb59 	bl	4570 <fwp_rc_forget_slot>
    9810:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9814:	390002a0 	strb	w0, [x21]
    9818:	17fffe97 	b	9274 <fwp_hof0.constprop.0+0x1464>
    981c:	b0000020 	adrp	x0, e000 <_IO_stdin_used+0x470>
    9820:	91036000 	add	x0, x0, #0xd8
    9824:	97ffe757 	bl	3580 <fwp_trap>
    9828:	90000020 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    982c:	913de000 	add	x0, x0, #0xf78
    9830:	97ffe754 	bl	3580 <fwp_trap>
    9834:	b0000020 	adrp	x0, e000 <_IO_stdin_used+0x470>
    9838:	91046000 	add	x0, x0, #0x118
    983c:	97ffe751 	bl	3580 <fwp_trap>
    9840:	b0000020 	adrp	x0, e000 <_IO_stdin_used+0x470>
    9844:	91026000 	add	x0, x0, #0x98
    9848:	97ffe74e 	bl	3580 <fwp_trap>
    984c:	b0000020 	adrp	x0, e000 <_IO_stdin_used+0x470>
    9850:	9101e000 	add	x0, x0, #0x78
    9854:	97ffe74b 	bl	3580 <fwp_trap>
    9858:	90000020 	adrp	x0, d000 <fwp_main_thread+0x10d0>
    985c:	913b2000 	add	x0, x0, #0xec8
    9860:	97ffe748 	bl	3580 <fwp_trap>
    9864:	b0000020 	adrp	x0, e000 <_IO_stdin_used+0x470>
    9868:	91040000 	add	x0, x0, #0x100
    986c:	97ffe745 	bl	3580 <fwp_trap>
    9870:	b0000020 	adrp	x0, e000 <_IO_stdin_used+0x470>
    9874:	91032000 	add	x0, x0, #0xc8
    9878:	97ffe742 	bl	3580 <fwp_trap>
    987c:	52800020 	mov	w0, #0x1                   	// #1
    9880:	17fffbe3 	b	880c <fwp_hof0.constprop.0+0x9fc>
    9884:	a90f53f3 	stp	x19, x20, [sp, #240]
    9888:	a9105bf5 	stp	x21, x22, [sp, #256]
    988c:	a91163f7 	stp	x23, x24, [sp, #272]
    9890:	a9126bf9 	stp	x25, x26, [sp, #288]
    9894:	a91373fb 	stp	x27, x28, [sp, #304]
    9898:	fd00a3e8 	str	d8, [sp, #320]
    989c:	97ffe3f9 	bl	2880 <__stack_chk_fail@plt>
    98a0:	97ffe478 	bl	2a80 <fwp_trap_overflow.constprop.0>
    98a4:	97ffe40b 	bl	28d0 <abort@plt>
    98a8:	d503201f 	nop
    98ac:	d503201f 	nop

00000000000098b0 <f0>:
    98b0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    98b4:	910003fd 	mov	x29, sp
    98b8:	a90153f3 	stp	x19, x20, [sp, #16]
    98bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    98c0:	a90363f7 	stp	x23, x24, [sp, #48]
    98c4:	a9046bf9 	stp	x25, x26, [sp, #64]
    98c8:	a90573fb 	stp	x27, x28, [sp, #80]
    98cc:	d12183ff 	sub	sp, sp, #0x860
    98d0:	f90203ff 	str	xzr, [sp, #1024]
    98d4:	f00000a0 	adrp	x0, 20000 <__data_start>
    98d8:	9100c005 	add	x5, x0, #0x30
    98dc:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    98e0:	f947f400 	ldr	x0, [x0, #4072]
    98e4:	90000154 	adrp	x20, 31000 <fwp_root_context+0xca0>
    98e8:	f94160a6 	ldr	x6, [x5, #704]
    98ec:	f9400001 	ldr	x1, [x0]
    98f0:	f9042fe1 	str	x1, [sp, #2136]
    98f4:	d2800001 	mov	x1, #0x0                   	// #0
    98f8:	91150298 	add	x24, x20, #0x540
    98fc:	912123f6 	add	x22, sp, #0x848
    9900:	910023e0 	add	x0, sp, #0x8
    9904:	910083e2 	add	x2, sp, #0x20
    9908:	90ffffe1 	adrp	x1, 5000 <fwp_p_ad_push.constprop.0+0x15c>
    990c:	b0ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    9910:	911f4021 	add	x1, x1, #0x7d0
    9914:	913d4084 	add	x4, x4, #0xf50
    9918:	d2800013 	mov	x19, #0x0                   	// #0
    991c:	d2800119 	mov	x25, #0x8                   	// #8
    9920:	d2800015 	mov	x21, #0x0                   	// #0
    9924:	52800037 	mov	w23, #0x1                   	// #1
    9928:	a90093e6 	stp	x6, x4, [sp, #8]
    992c:	a901ffe2 	stp	x2, xzr, [sp, #24]
    9930:	a90307ff 	stp	xzr, x1, [sp, #48]
    9934:	f90160a0 	str	x0, [x5, #704]
    9938:	f100073a 	subs	x26, x25, #0x1
    993c:	aa1603e1 	mov	x1, x22
    9940:	da1f02bc 	sbc	x28, x21, xzr
    9944:	52800020 	mov	w0, #0x1                   	// #1
    9948:	f90017fa 	str	x26, [sp, #40]
    994c:	aa1a03f9 	mov	x25, x26
    9950:	f90427fa 	str	x26, [sp, #2120]
    9954:	aa1c03f5 	mov	x21, x28
    9958:	f9042bf3 	str	x19, [sp, #2128]
    995c:	97ffed0a 	bl	4d84 <fwp_data.part.0.constprop.0>
    9960:	f949db02 	ldr	x2, [x24, #5040]
    9964:	aa0003f3 	mov	x19, x0
    9968:	f949ef00 	ldr	x0, [x24, #5080]
    996c:	cb020262 	sub	x2, x19, x2
    9970:	eb00405f 	cmp	x2, x0, lsl #16
    9974:	54000302 	b.cs	99d4 <f0+0x124>  // b.hs, b.nlast
    9978:	d350fc40 	lsr	x0, x2, #16
    997c:	f949ff04 	ldr	x4, [x24, #5112]
    9980:	8b000800 	add	x0, x0, x0, lsl #2
    9984:	d37df001 	lsl	x1, x0, #3
    9988:	8b010080 	add	x0, x4, x1
    998c:	f940101b 	ldr	x27, [x0, #32]
    9990:	b400023b 	cbz	x27, 99d4 <f0+0x124>
    9994:	38616881 	ldrb	w1, [x4, x1]
    9998:	7100083f 	cmp	w1, #0x2
    999c:	54010ee0 	b.eq	bb78 <f0+0x22c8>  // b.none
    99a0:	7100043f 	cmp	w1, #0x1
    99a4:	54000181 	b.ne	99d4 <f0+0x124>  // b.any
    99a8:	29430001 	ldp	w1, w0, [x0, #24]
    99ac:	92403c42 	and	x2, x2, #0xffff
    99b0:	9b017c42 	mul	x2, x2, x1
    99b4:	d360fc42 	lsr	x2, x2, #32
    99b8:	eb00005f 	cmp	x2, x0
    99bc:	540000c2 	b.cs	99d4 <f0+0x124>  // b.hs, b.nlast
    99c0:	8b02037b 	add	x27, x27, x2
    99c4:	39400360 	ldrb	w0, [x27]
    99c8:	7103fc1f 	cmp	w0, #0xff
    99cc:	54010d00 	b.eq	bb6c <f0+0x22bc>  // b.none
    99d0:	39000377 	strb	w23, [x27]
    99d4:	f90013f3 	str	x19, [sp, #32]
    99d8:	aa1c035a 	orr	x26, x26, x28
    99dc:	b5fffafa 	cbnz	x26, 9938 <f0+0x88>
    99e0:	b0000023 	adrp	x3, e000 <_IO_stdin_used+0x470>
    99e4:	910103e1 	add	x1, sp, #0x40
    99e8:	f94007e2 	ldr	x2, [sp, #8]
    99ec:	f00000a0 	adrp	x0, 20000 <__data_start>
    99f0:	3dc21c60 	ldr	q0, [x3, #2160]
    99f4:	9100c018 	add	x24, x0, #0x30
    99f8:	52800020 	mov	w0, #0x1                   	// #1
    99fc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    9a00:	3d8013e0 	str	q0, [sp, #64]
    9a04:	f9016302 	str	x2, [x24, #704]
    9a08:	97ffecdf 	bl	4d84 <fwp_data.part.0.constprop.0>
    9a0c:	97ffee6a 	bl	53b4 <fwp_rc_fresh>
    9a10:	aa0003e2 	mov	x2, x0
    9a14:	910163e1 	add	x1, sp, #0x58
    9a18:	52800020 	mov	w0, #0x1                   	// #1
    9a1c:	a9058bf5 	stp	x21, x2, [sp, #88]
    9a20:	97ffecd9 	bl	4d84 <fwp_data.part.0.constprop.0>
    9a24:	97ffee64 	bl	53b4 <fwp_rc_fresh>
    9a28:	aa0003e2 	mov	x2, x0
    9a2c:	9101a3e1 	add	x1, sp, #0x68
    9a30:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    9a34:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    9a38:	52800020 	mov	w0, #0x1                   	// #1
    9a3c:	a9068be3 	stp	x3, x2, [sp, #104]
    9a40:	97ffecd1 	bl	4d84 <fwp_data.part.0.constprop.0>
    9a44:	97ffee5c 	bl	53b4 <fwp_rc_fresh>
    9a48:	aa0003e2 	mov	x2, x0
    9a4c:	9101e3e1 	add	x1, sp, #0x78
    9a50:	52800020 	mov	w0, #0x1                   	// #1
    9a54:	a9078bf5 	stp	x21, x2, [sp, #120]
    9a58:	97ffeccb 	bl	4d84 <fwp_data.part.0.constprop.0>
    9a5c:	97ffee56 	bl	53b4 <fwp_rc_fresh>
    9a60:	aa0003e2 	mov	x2, x0
    9a64:	910223e1 	add	x1, sp, #0x88
    9a68:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    9a6c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    9a70:	52800020 	mov	w0, #0x1                   	// #1
    9a74:	a9088be3 	stp	x3, x2, [sp, #136]
    9a78:	97ffecc3 	bl	4d84 <fwp_data.part.0.constprop.0>
    9a7c:	97ffee4e 	bl	53b4 <fwp_rc_fresh>
    9a80:	aa0003e2 	mov	x2, x0
    9a84:	910263e1 	add	x1, sp, #0x98
    9a88:	52800020 	mov	w0, #0x1                   	// #1
    9a8c:	a9098bf5 	stp	x21, x2, [sp, #152]
    9a90:	97ffecbd 	bl	4d84 <fwp_data.part.0.constprop.0>
    9a94:	97ffee48 	bl	53b4 <fwp_rc_fresh>
    9a98:	aa0003e2 	mov	x2, x0
    9a9c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    9aa0:	9102a3e1 	add	x1, sp, #0xa8
    9aa4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    9aa8:	52800020 	mov	w0, #0x1                   	// #1
    9aac:	a90a8be3 	stp	x3, x2, [sp, #168]
    9ab0:	97ffecb5 	bl	4d84 <fwp_data.part.0.constprop.0>
    9ab4:	97ffee40 	bl	53b4 <fwp_rc_fresh>
    9ab8:	aa0003e2 	mov	x2, x0
    9abc:	9102e3e1 	add	x1, sp, #0xb8
    9ac0:	52800020 	mov	w0, #0x1                   	// #1
    9ac4:	a90b8bf5 	stp	x21, x2, [sp, #184]
    9ac8:	97ffecaf 	bl	4d84 <fwp_data.part.0.constprop.0>
    9acc:	91150283 	add	x3, x20, #0x540
    9ad0:	aa0003f5 	mov	x21, x0
    9ad4:	f949d861 	ldr	x1, [x3, #5040]
    9ad8:	f949ec60 	ldr	x0, [x3, #5080]
    9adc:	cb0102a1 	sub	x1, x21, x1
    9ae0:	eb00403f 	cmp	x1, x0, lsl #16
    9ae4:	54000322 	b.cs	9b48 <f0+0x298>  // b.hs, b.nlast
    9ae8:	d350fc22 	lsr	x2, x1, #16
    9aec:	f949fc63 	ldr	x3, [x3, #5112]
    9af0:	8b020842 	add	x2, x2, x2, lsl #2
    9af4:	d37df042 	lsl	x2, x2, #3
    9af8:	8b020060 	add	x0, x3, x2
    9afc:	f9401017 	ldr	x23, [x0, #32]
    9b00:	b4000257 	cbz	x23, 9b48 <f0+0x298>
    9b04:	38626862 	ldrb	w2, [x3, x2]
    9b08:	7100085f 	cmp	w2, #0x2
    9b0c:	54010780 	b.eq	bbfc <f0+0x234c>  // b.none
    9b10:	7100045f 	cmp	w2, #0x1
    9b14:	540001a1 	b.ne	9b48 <f0+0x298>  // b.any
    9b18:	29430002 	ldp	w2, w0, [x0, #24]
    9b1c:	92403c21 	and	x1, x1, #0xffff
    9b20:	9b027c21 	mul	x1, x1, x2
    9b24:	d360fc21 	lsr	x1, x1, #32
    9b28:	eb00003f 	cmp	x1, x0
    9b2c:	540000e2 	b.cs	9b48 <f0+0x298>  // b.hs, b.nlast
    9b30:	8b0102f7 	add	x23, x23, x1
    9b34:	394002e0 	ldrb	w0, [x23]
    9b38:	7103fc1f 	cmp	w0, #0xff
    9b3c:	54011140 	b.eq	bd64 <f0+0x24b4>  // b.none
    9b40:	52800020 	mov	w0, #0x1                   	// #1
    9b44:	390002e0 	strb	w0, [x23]
    9b48:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9b4c:	910323e1 	add	x1, sp, #0xc8
    9b50:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9b54:	52800020 	mov	w0, #0x1                   	// #1
    9b58:	a90cd7e2 	stp	x2, x21, [sp, #200]
    9b5c:	97ffec8a 	bl	4d84 <fwp_data.part.0.constprop.0>
    9b60:	97ffee15 	bl	53b4 <fwp_rc_fresh>
    9b64:	aa0003e2 	mov	x2, x0
    9b68:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    9b6c:	910363e1 	add	x1, sp, #0xd8
    9b70:	52800020 	mov	w0, #0x1                   	// #1
    9b74:	a90d8be3 	stp	x3, x2, [sp, #216]
    9b78:	97ffec83 	bl	4d84 <fwp_data.part.0.constprop.0>
    9b7c:	91150283 	add	x3, x20, #0x540
    9b80:	aa0003f5 	mov	x21, x0
    9b84:	f949d861 	ldr	x1, [x3, #5040]
    9b88:	f949ec60 	ldr	x0, [x3, #5080]
    9b8c:	cb0102a1 	sub	x1, x21, x1
    9b90:	eb00403f 	cmp	x1, x0, lsl #16
    9b94:	54000322 	b.cs	9bf8 <f0+0x348>  // b.hs, b.nlast
    9b98:	d350fc22 	lsr	x2, x1, #16
    9b9c:	f949fc63 	ldr	x3, [x3, #5112]
    9ba0:	8b020842 	add	x2, x2, x2, lsl #2
    9ba4:	d37df042 	lsl	x2, x2, #3
    9ba8:	8b020060 	add	x0, x3, x2
    9bac:	f9401017 	ldr	x23, [x0, #32]
    9bb0:	b4000257 	cbz	x23, 9bf8 <f0+0x348>
    9bb4:	38626862 	ldrb	w2, [x3, x2]
    9bb8:	7100085f 	cmp	w2, #0x2
    9bbc:	540101a0 	b.eq	bbf0 <f0+0x2340>  // b.none
    9bc0:	7100045f 	cmp	w2, #0x1
    9bc4:	540001a1 	b.ne	9bf8 <f0+0x348>  // b.any
    9bc8:	29430002 	ldp	w2, w0, [x0, #24]
    9bcc:	92403c21 	and	x1, x1, #0xffff
    9bd0:	9b027c21 	mul	x1, x1, x2
    9bd4:	d360fc21 	lsr	x1, x1, #32
    9bd8:	eb00003f 	cmp	x1, x0
    9bdc:	540000e2 	b.cs	9bf8 <f0+0x348>  // b.hs, b.nlast
    9be0:	8b0102f7 	add	x23, x23, x1
    9be4:	394002e0 	ldrb	w0, [x23]
    9be8:	7103fc1f 	cmp	w0, #0xff
    9bec:	54010c20 	b.eq	bd70 <f0+0x24c0>  // b.none
    9bf0:	52800020 	mov	w0, #0x1                   	// #1
    9bf4:	390002e0 	strb	w0, [x23]
    9bf8:	9103a3e1 	add	x1, sp, #0xe8
    9bfc:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    9c00:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    9c04:	52800020 	mov	w0, #0x1                   	// #1
    9c08:	a90ed7f7 	stp	x23, x21, [sp, #232]
    9c0c:	97ffec5e 	bl	4d84 <fwp_data.part.0.constprop.0>
    9c10:	97ffede9 	bl	53b4 <fwp_rc_fresh>
    9c14:	aa0003e2 	mov	x2, x0
    9c18:	9103e3e1 	add	x1, sp, #0xf8
    9c1c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    9c20:	52800020 	mov	w0, #0x1                   	// #1
    9c24:	a90f8bf5 	stp	x21, x2, [sp, #248]
    9c28:	97ffec57 	bl	4d84 <fwp_data.part.0.constprop.0>
    9c2c:	97ffede2 	bl	53b4 <fwp_rc_fresh>
    9c30:	aa0003e2 	mov	x2, x0
    9c34:	910423e1 	add	x1, sp, #0x108
    9c38:	52800020 	mov	w0, #0x1                   	// #1
    9c3c:	a9108bf7 	stp	x23, x2, [sp, #264]
    9c40:	97ffec51 	bl	4d84 <fwp_data.part.0.constprop.0>
    9c44:	97ffeddc 	bl	53b4 <fwp_rc_fresh>
    9c48:	aa0003e2 	mov	x2, x0
    9c4c:	910463e1 	add	x1, sp, #0x118
    9c50:	52800020 	mov	w0, #0x1                   	// #1
    9c54:	a9118bf5 	stp	x21, x2, [sp, #280]
    9c58:	97ffec4b 	bl	4d84 <fwp_data.part.0.constprop.0>
    9c5c:	97ffedd6 	bl	53b4 <fwp_rc_fresh>
    9c60:	aa0003e2 	mov	x2, x0
    9c64:	9104a3e1 	add	x1, sp, #0x128
    9c68:	52800020 	mov	w0, #0x1                   	// #1
    9c6c:	a9128bf7 	stp	x23, x2, [sp, #296]
    9c70:	97ffec45 	bl	4d84 <fwp_data.part.0.constprop.0>
    9c74:	97ffedd0 	bl	53b4 <fwp_rc_fresh>
    9c78:	aa0003e2 	mov	x2, x0
    9c7c:	9104e3e1 	add	x1, sp, #0x138
    9c80:	52800020 	mov	w0, #0x1                   	// #1
    9c84:	a9138bf5 	stp	x21, x2, [sp, #312]
    9c88:	97ffec3f 	bl	4d84 <fwp_data.part.0.constprop.0>
    9c8c:	97ffedca 	bl	53b4 <fwp_rc_fresh>
    9c90:	aa0003e2 	mov	x2, x0
    9c94:	910523e1 	add	x1, sp, #0x148
    9c98:	52800020 	mov	w0, #0x1                   	// #1
    9c9c:	a9148bf7 	stp	x23, x2, [sp, #328]
    9ca0:	97ffec39 	bl	4d84 <fwp_data.part.0.constprop.0>
    9ca4:	97ffedc4 	bl	53b4 <fwp_rc_fresh>
    9ca8:	aa0003e2 	mov	x2, x0
    9cac:	910563e1 	add	x1, sp, #0x158
    9cb0:	52800020 	mov	w0, #0x1                   	// #1
    9cb4:	a9158bf5 	stp	x21, x2, [sp, #344]
    9cb8:	97ffec33 	bl	4d84 <fwp_data.part.0.constprop.0>
    9cbc:	97ffedbe 	bl	53b4 <fwp_rc_fresh>
    9cc0:	aa0003e2 	mov	x2, x0
    9cc4:	9105a3e1 	add	x1, sp, #0x168
    9cc8:	52800020 	mov	w0, #0x1                   	// #1
    9ccc:	a9168bf7 	stp	x23, x2, [sp, #360]
    9cd0:	97ffec2d 	bl	4d84 <fwp_data.part.0.constprop.0>
    9cd4:	97ffedb8 	bl	53b4 <fwp_rc_fresh>
    9cd8:	aa0003e2 	mov	x2, x0
    9cdc:	9105e3e1 	add	x1, sp, #0x178
    9ce0:	52800020 	mov	w0, #0x1                   	// #1
    9ce4:	a9178bf5 	stp	x21, x2, [sp, #376]
    9ce8:	97ffec27 	bl	4d84 <fwp_data.part.0.constprop.0>
    9cec:	97ffedb2 	bl	53b4 <fwp_rc_fresh>
    9cf0:	aa0003e2 	mov	x2, x0
    9cf4:	910623e1 	add	x1, sp, #0x188
    9cf8:	52800020 	mov	w0, #0x1                   	// #1
    9cfc:	a9188bf7 	stp	x23, x2, [sp, #392]
    9d00:	97ffec21 	bl	4d84 <fwp_data.part.0.constprop.0>
    9d04:	97ffedac 	bl	53b4 <fwp_rc_fresh>
    9d08:	aa0003e2 	mov	x2, x0
    9d0c:	910663e1 	add	x1, sp, #0x198
    9d10:	52800020 	mov	w0, #0x1                   	// #1
    9d14:	a9198bf5 	stp	x21, x2, [sp, #408]
    9d18:	97ffec1b 	bl	4d84 <fwp_data.part.0.constprop.0>
    9d1c:	97ffeda6 	bl	53b4 <fwp_rc_fresh>
    9d20:	aa0003e2 	mov	x2, x0
    9d24:	9106a3e1 	add	x1, sp, #0x1a8
    9d28:	52800020 	mov	w0, #0x1                   	// #1
    9d2c:	a91a8bf7 	stp	x23, x2, [sp, #424]
    9d30:	97ffec15 	bl	4d84 <fwp_data.part.0.constprop.0>
    9d34:	97ffeda0 	bl	53b4 <fwp_rc_fresh>
    9d38:	aa0003e2 	mov	x2, x0
    9d3c:	9106e3e1 	add	x1, sp, #0x1b8
    9d40:	52800020 	mov	w0, #0x1                   	// #1
    9d44:	a91b8bf5 	stp	x21, x2, [sp, #440]
    9d48:	97ffec0f 	bl	4d84 <fwp_data.part.0.constprop.0>
    9d4c:	97ffed9a 	bl	53b4 <fwp_rc_fresh>
    9d50:	aa0003e2 	mov	x2, x0
    9d54:	910723e1 	add	x1, sp, #0x1c8
    9d58:	52800020 	mov	w0, #0x1                   	// #1
    9d5c:	a91c8bf7 	stp	x23, x2, [sp, #456]
    9d60:	97ffec09 	bl	4d84 <fwp_data.part.0.constprop.0>
    9d64:	97ffed94 	bl	53b4 <fwp_rc_fresh>
    9d68:	aa0003e2 	mov	x2, x0
    9d6c:	910763e1 	add	x1, sp, #0x1d8
    9d70:	52800020 	mov	w0, #0x1                   	// #1
    9d74:	a91d8bf5 	stp	x21, x2, [sp, #472]
    9d78:	97ffec03 	bl	4d84 <fwp_data.part.0.constprop.0>
    9d7c:	91150283 	add	x3, x20, #0x540
    9d80:	aa0003f5 	mov	x21, x0
    9d84:	f949d861 	ldr	x1, [x3, #5040]
    9d88:	f949ec60 	ldr	x0, [x3, #5080]
    9d8c:	cb0102a1 	sub	x1, x21, x1
    9d90:	eb00403f 	cmp	x1, x0, lsl #16
    9d94:	54000322 	b.cs	9df8 <f0+0x548>  // b.hs, b.nlast
    9d98:	d350fc22 	lsr	x2, x1, #16
    9d9c:	f949fc63 	ldr	x3, [x3, #5112]
    9da0:	8b020842 	add	x2, x2, x2, lsl #2
    9da4:	d37df042 	lsl	x2, x2, #3
    9da8:	8b020060 	add	x0, x3, x2
    9dac:	f9401017 	ldr	x23, [x0, #32]
    9db0:	b4000257 	cbz	x23, 9df8 <f0+0x548>
    9db4:	38626862 	ldrb	w2, [x3, x2]
    9db8:	7100085f 	cmp	w2, #0x2
    9dbc:	5400f140 	b.eq	bbe4 <f0+0x2334>  // b.none
    9dc0:	7100045f 	cmp	w2, #0x1
    9dc4:	540001a1 	b.ne	9df8 <f0+0x548>  // b.any
    9dc8:	29430002 	ldp	w2, w0, [x0, #24]
    9dcc:	92403c21 	and	x1, x1, #0xffff
    9dd0:	9b027c21 	mul	x1, x1, x2
    9dd4:	d360fc21 	lsr	x1, x1, #32
    9dd8:	eb00003f 	cmp	x1, x0
    9ddc:	540000e2 	b.cs	9df8 <f0+0x548>  // b.hs, b.nlast
    9de0:	8b0102f7 	add	x23, x23, x1
    9de4:	394002e0 	ldrb	w0, [x23]
    9de8:	7103fc1f 	cmp	w0, #0xff
    9dec:	5400fc80 	b.eq	bd7c <f0+0x24cc>  // b.none
    9df0:	52800020 	mov	w0, #0x1                   	// #1
    9df4:	390002e0 	strb	w0, [x23]
    9df8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9dfc:	9107a3e1 	add	x1, sp, #0x1e8
    9e00:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9e04:	52800020 	mov	w0, #0x1                   	// #1
    9e08:	a91ed7e2 	stp	x2, x21, [sp, #488]
    9e0c:	97ffebde 	bl	4d84 <fwp_data.part.0.constprop.0>
    9e10:	97ffed69 	bl	53b4 <fwp_rc_fresh>
    9e14:	aa0003e2 	mov	x2, x0
    9e18:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    9e1c:	9107e3e1 	add	x1, sp, #0x1f8
    9e20:	52800020 	mov	w0, #0x1                   	// #1
    9e24:	a91f8be3 	stp	x3, x2, [sp, #504]
    9e28:	97ffebd7 	bl	4d84 <fwp_data.part.0.constprop.0>
    9e2c:	91150283 	add	x3, x20, #0x540
    9e30:	aa0003f5 	mov	x21, x0
    9e34:	f949d861 	ldr	x1, [x3, #5040]
    9e38:	f949ec60 	ldr	x0, [x3, #5080]
    9e3c:	cb0102a1 	sub	x1, x21, x1
    9e40:	eb00403f 	cmp	x1, x0, lsl #16
    9e44:	54000322 	b.cs	9ea8 <f0+0x5f8>  // b.hs, b.nlast
    9e48:	d350fc22 	lsr	x2, x1, #16
    9e4c:	f949fc63 	ldr	x3, [x3, #5112]
    9e50:	8b020842 	add	x2, x2, x2, lsl #2
    9e54:	d37df042 	lsl	x2, x2, #3
    9e58:	8b020060 	add	x0, x3, x2
    9e5c:	f9401017 	ldr	x23, [x0, #32]
    9e60:	b4000257 	cbz	x23, 9ea8 <f0+0x5f8>
    9e64:	38626862 	ldrb	w2, [x3, x2]
    9e68:	7100085f 	cmp	w2, #0x2
    9e6c:	5400ee00 	b.eq	bc2c <f0+0x237c>  // b.none
    9e70:	7100045f 	cmp	w2, #0x1
    9e74:	540001a1 	b.ne	9ea8 <f0+0x5f8>  // b.any
    9e78:	29430002 	ldp	w2, w0, [x0, #24]
    9e7c:	92403c21 	and	x1, x1, #0xffff
    9e80:	9b027c21 	mul	x1, x1, x2
    9e84:	d360fc21 	lsr	x1, x1, #32
    9e88:	eb00003f 	cmp	x1, x0
    9e8c:	540000e2 	b.cs	9ea8 <f0+0x5f8>  // b.hs, b.nlast
    9e90:	8b0102f7 	add	x23, x23, x1
    9e94:	394002e0 	ldrb	w0, [x23]
    9e98:	7103fc1f 	cmp	w0, #0xff
    9e9c:	5400f760 	b.eq	bd88 <f0+0x24d8>  // b.none
    9ea0:	52800020 	mov	w0, #0x1                   	// #1
    9ea4:	390002e0 	strb	w0, [x23]
    9ea8:	910823e1 	add	x1, sp, #0x208
    9eac:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    9eb0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    9eb4:	52800020 	mov	w0, #0x1                   	// #1
    9eb8:	f90107f7 	str	x23, [sp, #520]
    9ebc:	f9010bf5 	str	x21, [sp, #528]
    9ec0:	97ffebb1 	bl	4d84 <fwp_data.part.0.constprop.0>
    9ec4:	97ffed3c 	bl	53b4 <fwp_rc_fresh>
    9ec8:	aa0003e2 	mov	x2, x0
    9ecc:	910863e1 	add	x1, sp, #0x218
    9ed0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    9ed4:	52800020 	mov	w0, #0x1                   	// #1
    9ed8:	f9010ff5 	str	x21, [sp, #536]
    9edc:	f90113e2 	str	x2, [sp, #544]
    9ee0:	97ffeba9 	bl	4d84 <fwp_data.part.0.constprop.0>
    9ee4:	97ffed34 	bl	53b4 <fwp_rc_fresh>
    9ee8:	aa0003e2 	mov	x2, x0
    9eec:	9108a3e1 	add	x1, sp, #0x228
    9ef0:	52800020 	mov	w0, #0x1                   	// #1
    9ef4:	f90117f7 	str	x23, [sp, #552]
    9ef8:	f9011be2 	str	x2, [sp, #560]
    9efc:	97ffeba2 	bl	4d84 <fwp_data.part.0.constprop.0>
    9f00:	97ffed2d 	bl	53b4 <fwp_rc_fresh>
    9f04:	aa0003e2 	mov	x2, x0
    9f08:	9108e3e1 	add	x1, sp, #0x238
    9f0c:	52800020 	mov	w0, #0x1                   	// #1
    9f10:	f9011ff5 	str	x21, [sp, #568]
    9f14:	f90123e2 	str	x2, [sp, #576]
    9f18:	97ffeb9b 	bl	4d84 <fwp_data.part.0.constprop.0>
    9f1c:	97ffed26 	bl	53b4 <fwp_rc_fresh>
    9f20:	aa0003e2 	mov	x2, x0
    9f24:	910923e1 	add	x1, sp, #0x248
    9f28:	52800020 	mov	w0, #0x1                   	// #1
    9f2c:	f90127f7 	str	x23, [sp, #584]
    9f30:	f9012be2 	str	x2, [sp, #592]
    9f34:	97ffeb94 	bl	4d84 <fwp_data.part.0.constprop.0>
    9f38:	97ffed1f 	bl	53b4 <fwp_rc_fresh>
    9f3c:	aa0003e2 	mov	x2, x0
    9f40:	910963e1 	add	x1, sp, #0x258
    9f44:	52800020 	mov	w0, #0x1                   	// #1
    9f48:	f9012ff5 	str	x21, [sp, #600]
    9f4c:	f90133e2 	str	x2, [sp, #608]
    9f50:	97ffeb8d 	bl	4d84 <fwp_data.part.0.constprop.0>
    9f54:	91150283 	add	x3, x20, #0x540
    9f58:	aa0003f5 	mov	x21, x0
    9f5c:	f949d861 	ldr	x1, [x3, #5040]
    9f60:	f949ec60 	ldr	x0, [x3, #5080]
    9f64:	cb0102a1 	sub	x1, x21, x1
    9f68:	eb00403f 	cmp	x1, x0, lsl #16
    9f6c:	54000322 	b.cs	9fd0 <f0+0x720>  // b.hs, b.nlast
    9f70:	d350fc22 	lsr	x2, x1, #16
    9f74:	f949fc63 	ldr	x3, [x3, #5112]
    9f78:	8b020842 	add	x2, x2, x2, lsl #2
    9f7c:	d37df042 	lsl	x2, x2, #3
    9f80:	8b020060 	add	x0, x3, x2
    9f84:	f9401017 	ldr	x23, [x0, #32]
    9f88:	b4000257 	cbz	x23, 9fd0 <f0+0x720>
    9f8c:	38626862 	ldrb	w2, [x3, x2]
    9f90:	7100085f 	cmp	w2, #0x2
    9f94:	5400e460 	b.eq	bc20 <f0+0x2370>  // b.none
    9f98:	7100045f 	cmp	w2, #0x1
    9f9c:	540001a1 	b.ne	9fd0 <f0+0x720>  // b.any
    9fa0:	29430002 	ldp	w2, w0, [x0, #24]
    9fa4:	92403c21 	and	x1, x1, #0xffff
    9fa8:	9b027c21 	mul	x1, x1, x2
    9fac:	d360fc21 	lsr	x1, x1, #32
    9fb0:	eb00003f 	cmp	x1, x0
    9fb4:	540000e2 	b.cs	9fd0 <f0+0x720>  // b.hs, b.nlast
    9fb8:	8b0102f7 	add	x23, x23, x1
    9fbc:	394002e0 	ldrb	w0, [x23]
    9fc0:	7103fc1f 	cmp	w0, #0xff
    9fc4:	5400ee80 	b.eq	bd94 <f0+0x24e4>  // b.none
    9fc8:	52800020 	mov	w0, #0x1                   	// #1
    9fcc:	390002e0 	strb	w0, [x23]
    9fd0:	9109a3e1 	add	x1, sp, #0x268
    9fd4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    9fd8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    9fdc:	52800020 	mov	w0, #0x1                   	// #1
    9fe0:	f90137f7 	str	x23, [sp, #616]
    9fe4:	f9013bf5 	str	x21, [sp, #624]
    9fe8:	97ffeb67 	bl	4d84 <fwp_data.part.0.constprop.0>
    9fec:	97ffecf2 	bl	53b4 <fwp_rc_fresh>
    9ff0:	aa0003e2 	mov	x2, x0
    9ff4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    9ff8:	9109e3e1 	add	x1, sp, #0x278
    9ffc:	52800020 	mov	w0, #0x1                   	// #1
    a000:	f9013fe3 	str	x3, [sp, #632]
    a004:	f90143e2 	str	x2, [sp, #640]
    a008:	97ffeb5f 	bl	4d84 <fwp_data.part.0.constprop.0>
    a00c:	97ffecea 	bl	53b4 <fwp_rc_fresh>
    a010:	aa0003e2 	mov	x2, x0
    a014:	910a23e1 	add	x1, sp, #0x288
    a018:	52800020 	mov	w0, #0x1                   	// #1
    a01c:	f90147f7 	str	x23, [sp, #648]
    a020:	f9014be2 	str	x2, [sp, #656]
    a024:	97ffeb58 	bl	4d84 <fwp_data.part.0.constprop.0>
    a028:	91150283 	add	x3, x20, #0x540
    a02c:	aa0003f5 	mov	x21, x0
    a030:	f949d861 	ldr	x1, [x3, #5040]
    a034:	f949ec60 	ldr	x0, [x3, #5080]
    a038:	cb0102a1 	sub	x1, x21, x1
    a03c:	eb00403f 	cmp	x1, x0, lsl #16
    a040:	54000322 	b.cs	a0a4 <f0+0x7f4>  // b.hs, b.nlast
    a044:	d350fc22 	lsr	x2, x1, #16
    a048:	f949fc63 	ldr	x3, [x3, #5112]
    a04c:	8b020842 	add	x2, x2, x2, lsl #2
    a050:	d37df042 	lsl	x2, x2, #3
    a054:	8b020060 	add	x0, x3, x2
    a058:	f9401017 	ldr	x23, [x0, #32]
    a05c:	b4000257 	cbz	x23, a0a4 <f0+0x7f4>
    a060:	38626862 	ldrb	w2, [x3, x2]
    a064:	7100085f 	cmp	w2, #0x2
    a068:	5400dd60 	b.eq	bc14 <f0+0x2364>  // b.none
    a06c:	7100045f 	cmp	w2, #0x1
    a070:	540001a1 	b.ne	a0a4 <f0+0x7f4>  // b.any
    a074:	29430002 	ldp	w2, w0, [x0, #24]
    a078:	92403c21 	and	x1, x1, #0xffff
    a07c:	9b027c21 	mul	x1, x1, x2
    a080:	d360fc21 	lsr	x1, x1, #32
    a084:	eb00003f 	cmp	x1, x0
    a088:	540000e2 	b.cs	a0a4 <f0+0x7f4>  // b.hs, b.nlast
    a08c:	8b0102f7 	add	x23, x23, x1
    a090:	394002e0 	ldrb	w0, [x23]
    a094:	7103fc1f 	cmp	w0, #0xff
    a098:	5400e840 	b.eq	bda0 <f0+0x24f0>  // b.none
    a09c:	52800020 	mov	w0, #0x1                   	// #1
    a0a0:	390002e0 	strb	w0, [x23]
    a0a4:	910a63e1 	add	x1, sp, #0x298
    a0a8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a0ac:	52800020 	mov	w0, #0x1                   	// #1
    a0b0:	f9014ff7 	str	x23, [sp, #664]
    a0b4:	f90153f5 	str	x21, [sp, #672]
    a0b8:	97ffeb33 	bl	4d84 <fwp_data.part.0.constprop.0>
    a0bc:	97ffecbe 	bl	53b4 <fwp_rc_fresh>
    a0c0:	aa0003e2 	mov	x2, x0
    a0c4:	910aa3e1 	add	x1, sp, #0x2a8
    a0c8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a0cc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a0d0:	52800020 	mov	w0, #0x1                   	// #1
    a0d4:	f90157f5 	str	x21, [sp, #680]
    a0d8:	f9015be2 	str	x2, [sp, #688]
    a0dc:	97ffeb2a 	bl	4d84 <fwp_data.part.0.constprop.0>
    a0e0:	97ffecb5 	bl	53b4 <fwp_rc_fresh>
    a0e4:	aa0003e2 	mov	x2, x0
    a0e8:	910ae3e1 	add	x1, sp, #0x2b8
    a0ec:	52800020 	mov	w0, #0x1                   	// #1
    a0f0:	f9015ff7 	str	x23, [sp, #696]
    a0f4:	f90163e2 	str	x2, [sp, #704]
    a0f8:	97ffeb23 	bl	4d84 <fwp_data.part.0.constprop.0>
    a0fc:	97ffecae 	bl	53b4 <fwp_rc_fresh>
    a100:	aa0003e2 	mov	x2, x0
    a104:	910b23e1 	add	x1, sp, #0x2c8
    a108:	52800020 	mov	w0, #0x1                   	// #1
    a10c:	f90167f5 	str	x21, [sp, #712]
    a110:	f9016be2 	str	x2, [sp, #720]
    a114:	97ffeb1c 	bl	4d84 <fwp_data.part.0.constprop.0>
    a118:	97ffeca7 	bl	53b4 <fwp_rc_fresh>
    a11c:	aa0003e2 	mov	x2, x0
    a120:	910b63e1 	add	x1, sp, #0x2d8
    a124:	52800020 	mov	w0, #0x1                   	// #1
    a128:	f9016ff7 	str	x23, [sp, #728]
    a12c:	f90173e2 	str	x2, [sp, #736]
    a130:	97ffeb15 	bl	4d84 <fwp_data.part.0.constprop.0>
    a134:	97ffeca0 	bl	53b4 <fwp_rc_fresh>
    a138:	aa0003e2 	mov	x2, x0
    a13c:	910ba3e1 	add	x1, sp, #0x2e8
    a140:	52800020 	mov	w0, #0x1                   	// #1
    a144:	f90177f5 	str	x21, [sp, #744]
    a148:	f9017be2 	str	x2, [sp, #752]
    a14c:	97ffeb0e 	bl	4d84 <fwp_data.part.0.constprop.0>
    a150:	91150283 	add	x3, x20, #0x540
    a154:	aa0003f5 	mov	x21, x0
    a158:	f949d861 	ldr	x1, [x3, #5040]
    a15c:	f949ec60 	ldr	x0, [x3, #5080]
    a160:	cb0102a1 	sub	x1, x21, x1
    a164:	eb00403f 	cmp	x1, x0, lsl #16
    a168:	54000322 	b.cs	a1cc <f0+0x91c>  // b.hs, b.nlast
    a16c:	d350fc22 	lsr	x2, x1, #16
    a170:	f949fc63 	ldr	x3, [x3, #5112]
    a174:	8b020842 	add	x2, x2, x2, lsl #2
    a178:	d37df042 	lsl	x2, x2, #3
    a17c:	8b020060 	add	x0, x3, x2
    a180:	f9401017 	ldr	x23, [x0, #32]
    a184:	b4000257 	cbz	x23, a1cc <f0+0x91c>
    a188:	38626862 	ldrb	w2, [x3, x2]
    a18c:	7100085f 	cmp	w2, #0x2
    a190:	5400d3c0 	b.eq	bc08 <f0+0x2358>  // b.none
    a194:	7100045f 	cmp	w2, #0x1
    a198:	540001a1 	b.ne	a1cc <f0+0x91c>  // b.any
    a19c:	29430002 	ldp	w2, w0, [x0, #24]
    a1a0:	92403c21 	and	x1, x1, #0xffff
    a1a4:	9b027c21 	mul	x1, x1, x2
    a1a8:	d360fc21 	lsr	x1, x1, #32
    a1ac:	eb00003f 	cmp	x1, x0
    a1b0:	540000e2 	b.cs	a1cc <f0+0x91c>  // b.hs, b.nlast
    a1b4:	8b0102f7 	add	x23, x23, x1
    a1b8:	394002e0 	ldrb	w0, [x23]
    a1bc:	7103fc1f 	cmp	w0, #0xff
    a1c0:	5400df60 	b.eq	bdac <f0+0x24fc>  // b.none
    a1c4:	52800020 	mov	w0, #0x1                   	// #1
    a1c8:	390002e0 	strb	w0, [x23]
    a1cc:	910be3e1 	add	x1, sp, #0x2f8
    a1d0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a1d4:	52800020 	mov	w0, #0x1                   	// #1
    a1d8:	f9017ff7 	str	x23, [sp, #760]
    a1dc:	f90183f5 	str	x21, [sp, #768]
    a1e0:	97ffeae9 	bl	4d84 <fwp_data.part.0.constprop.0>
    a1e4:	97ffec74 	bl	53b4 <fwp_rc_fresh>
    a1e8:	aa0003e2 	mov	x2, x0
    a1ec:	910c23e1 	add	x1, sp, #0x308
    a1f0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a1f4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a1f8:	52800020 	mov	w0, #0x1                   	// #1
    a1fc:	f90187f5 	str	x21, [sp, #776]
    a200:	f9018be2 	str	x2, [sp, #784]
    a204:	97ffeae0 	bl	4d84 <fwp_data.part.0.constprop.0>
    a208:	97ffec6b 	bl	53b4 <fwp_rc_fresh>
    a20c:	aa0003e2 	mov	x2, x0
    a210:	910c63e1 	add	x1, sp, #0x318
    a214:	52800020 	mov	w0, #0x1                   	// #1
    a218:	f9018ff7 	str	x23, [sp, #792]
    a21c:	f90193e2 	str	x2, [sp, #800]
    a220:	97ffead9 	bl	4d84 <fwp_data.part.0.constprop.0>
    a224:	97ffec64 	bl	53b4 <fwp_rc_fresh>
    a228:	aa0003e2 	mov	x2, x0
    a22c:	910ca3e1 	add	x1, sp, #0x328
    a230:	52800020 	mov	w0, #0x1                   	// #1
    a234:	f90197f5 	str	x21, [sp, #808]
    a238:	f9019be2 	str	x2, [sp, #816]
    a23c:	97ffead2 	bl	4d84 <fwp_data.part.0.constprop.0>
    a240:	97ffec5d 	bl	53b4 <fwp_rc_fresh>
    a244:	aa0003e2 	mov	x2, x0
    a248:	910ce3e1 	add	x1, sp, #0x338
    a24c:	52800020 	mov	w0, #0x1                   	// #1
    a250:	f9019ff7 	str	x23, [sp, #824]
    a254:	f901a3e2 	str	x2, [sp, #832]
    a258:	97ffeacb 	bl	4d84 <fwp_data.part.0.constprop.0>
    a25c:	97ffec56 	bl	53b4 <fwp_rc_fresh>
    a260:	aa0003e2 	mov	x2, x0
    a264:	910d23e1 	add	x1, sp, #0x348
    a268:	52800020 	mov	w0, #0x1                   	// #1
    a26c:	f901a7f5 	str	x21, [sp, #840]
    a270:	f901abe2 	str	x2, [sp, #848]
    a274:	97ffeac4 	bl	4d84 <fwp_data.part.0.constprop.0>
    a278:	97ffec4f 	bl	53b4 <fwp_rc_fresh>
    a27c:	aa0003e2 	mov	x2, x0
    a280:	910d63e1 	add	x1, sp, #0x358
    a284:	52800020 	mov	w0, #0x1                   	// #1
    a288:	f901aff7 	str	x23, [sp, #856]
    a28c:	f901b3e2 	str	x2, [sp, #864]
    a290:	97ffeabd 	bl	4d84 <fwp_data.part.0.constprop.0>
    a294:	97ffec48 	bl	53b4 <fwp_rc_fresh>
    a298:	aa0003e2 	mov	x2, x0
    a29c:	910da3e1 	add	x1, sp, #0x368
    a2a0:	52800020 	mov	w0, #0x1                   	// #1
    a2a4:	f901b7f5 	str	x21, [sp, #872]
    a2a8:	f901bbe2 	str	x2, [sp, #880]
    a2ac:	97ffeab6 	bl	4d84 <fwp_data.part.0.constprop.0>
    a2b0:	97ffec41 	bl	53b4 <fwp_rc_fresh>
    a2b4:	aa0003e2 	mov	x2, x0
    a2b8:	910de3e1 	add	x1, sp, #0x378
    a2bc:	52800020 	mov	w0, #0x1                   	// #1
    a2c0:	f901bff7 	str	x23, [sp, #888]
    a2c4:	f901c3e2 	str	x2, [sp, #896]
    a2c8:	97ffeaaf 	bl	4d84 <fwp_data.part.0.constprop.0>
    a2cc:	97ffec3a 	bl	53b4 <fwp_rc_fresh>
    a2d0:	aa0003e2 	mov	x2, x0
    a2d4:	910e23e1 	add	x1, sp, #0x388
    a2d8:	52800020 	mov	w0, #0x1                   	// #1
    a2dc:	f901c7f5 	str	x21, [sp, #904]
    a2e0:	f901cbe2 	str	x2, [sp, #912]
    a2e4:	97ffeaa8 	bl	4d84 <fwp_data.part.0.constprop.0>
    a2e8:	91150283 	add	x3, x20, #0x540
    a2ec:	aa0003f5 	mov	x21, x0
    a2f0:	f949d861 	ldr	x1, [x3, #5040]
    a2f4:	f949ec60 	ldr	x0, [x3, #5080]
    a2f8:	cb0102a1 	sub	x1, x21, x1
    a2fc:	eb00403f 	cmp	x1, x0, lsl #16
    a300:	54000322 	b.cs	a364 <f0+0xab4>  // b.hs, b.nlast
    a304:	d350fc22 	lsr	x2, x1, #16
    a308:	f949fc63 	ldr	x3, [x3, #5112]
    a30c:	8b020842 	add	x2, x2, x2, lsl #2
    a310:	d37df042 	lsl	x2, x2, #3
    a314:	8b020060 	add	x0, x3, x2
    a318:	f9401017 	ldr	x23, [x0, #32]
    a31c:	b4000257 	cbz	x23, a364 <f0+0xab4>
    a320:	38626862 	ldrb	w2, [x3, x2]
    a324:	7100085f 	cmp	w2, #0x2
    a328:	5400cb20 	b.eq	bc8c <f0+0x23dc>  // b.none
    a32c:	7100045f 	cmp	w2, #0x1
    a330:	540001a1 	b.ne	a364 <f0+0xab4>  // b.any
    a334:	29430002 	ldp	w2, w0, [x0, #24]
    a338:	92403c21 	and	x1, x1, #0xffff
    a33c:	9b027c21 	mul	x1, x1, x2
    a340:	d360fc21 	lsr	x1, x1, #32
    a344:	eb00003f 	cmp	x1, x0
    a348:	540000e2 	b.cs	a364 <f0+0xab4>  // b.hs, b.nlast
    a34c:	8b0102f7 	add	x23, x23, x1
    a350:	394002e0 	ldrb	w0, [x23]
    a354:	7103fc1f 	cmp	w0, #0xff
    a358:	5400d300 	b.eq	bdb8 <f0+0x2508>  // b.none
    a35c:	52800020 	mov	w0, #0x1                   	// #1
    a360:	390002e0 	strb	w0, [x23]
    a364:	910e63e1 	add	x1, sp, #0x398
    a368:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a36c:	52800020 	mov	w0, #0x1                   	// #1
    a370:	f901cfe2 	str	x2, [sp, #920]
    a374:	f901d3f5 	str	x21, [sp, #928]
    a378:	97ffea83 	bl	4d84 <fwp_data.part.0.constprop.0>
    a37c:	97ffec0e 	bl	53b4 <fwp_rc_fresh>
    a380:	aa0003e2 	mov	x2, x0
    a384:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a388:	910ea3e1 	add	x1, sp, #0x3a8
    a38c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a390:	52800020 	mov	w0, #0x1                   	// #1
    a394:	f901d7e3 	str	x3, [sp, #936]
    a398:	f901dbe2 	str	x2, [sp, #944]
    a39c:	97ffea7a 	bl	4d84 <fwp_data.part.0.constprop.0>
    a3a0:	91150283 	add	x3, x20, #0x540
    a3a4:	aa0003f5 	mov	x21, x0
    a3a8:	f949d861 	ldr	x1, [x3, #5040]
    a3ac:	f949ec60 	ldr	x0, [x3, #5080]
    a3b0:	cb0102a1 	sub	x1, x21, x1
    a3b4:	eb00403f 	cmp	x1, x0, lsl #16
    a3b8:	54000322 	b.cs	a41c <f0+0xb6c>  // b.hs, b.nlast
    a3bc:	d350fc22 	lsr	x2, x1, #16
    a3c0:	f949fc63 	ldr	x3, [x3, #5112]
    a3c4:	8b020842 	add	x2, x2, x2, lsl #2
    a3c8:	d37df042 	lsl	x2, x2, #3
    a3cc:	8b020060 	add	x0, x3, x2
    a3d0:	f9401017 	ldr	x23, [x0, #32]
    a3d4:	b4000257 	cbz	x23, a41c <f0+0xb6c>
    a3d8:	38626862 	ldrb	w2, [x3, x2]
    a3dc:	7100085f 	cmp	w2, #0x2
    a3e0:	5400c500 	b.eq	bc80 <f0+0x23d0>  // b.none
    a3e4:	7100045f 	cmp	w2, #0x1
    a3e8:	540001a1 	b.ne	a41c <f0+0xb6c>  // b.any
    a3ec:	29430002 	ldp	w2, w0, [x0, #24]
    a3f0:	92403c21 	and	x1, x1, #0xffff
    a3f4:	9b027c21 	mul	x1, x1, x2
    a3f8:	d360fc21 	lsr	x1, x1, #32
    a3fc:	eb00003f 	cmp	x1, x0
    a400:	540000e2 	b.cs	a41c <f0+0xb6c>  // b.hs, b.nlast
    a404:	8b0102f7 	add	x23, x23, x1
    a408:	394002e0 	ldrb	w0, [x23]
    a40c:	7103fc1f 	cmp	w0, #0xff
    a410:	5400cda0 	b.eq	bdc4 <f0+0x2514>  // b.none
    a414:	52800020 	mov	w0, #0x1                   	// #1
    a418:	390002e0 	strb	w0, [x23]
    a41c:	910ee3e1 	add	x1, sp, #0x3b8
    a420:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a424:	52800020 	mov	w0, #0x1                   	// #1
    a428:	f901dfe2 	str	x2, [sp, #952]
    a42c:	f901e3f5 	str	x21, [sp, #960]
    a430:	97ffea55 	bl	4d84 <fwp_data.part.0.constprop.0>
    a434:	97ffebe0 	bl	53b4 <fwp_rc_fresh>
    a438:	aa0003e2 	mov	x2, x0
    a43c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a440:	910f23e1 	add	x1, sp, #0x3c8
    a444:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a448:	52800020 	mov	w0, #0x1                   	// #1
    a44c:	f901e7e3 	str	x3, [sp, #968]
    a450:	f901ebe2 	str	x2, [sp, #976]
    a454:	97ffea4c 	bl	4d84 <fwp_data.part.0.constprop.0>
    a458:	91150283 	add	x3, x20, #0x540
    a45c:	aa0003f7 	mov	x23, x0
    a460:	f949d861 	ldr	x1, [x3, #5040]
    a464:	f949ec60 	ldr	x0, [x3, #5080]
    a468:	cb0102e1 	sub	x1, x23, x1
    a46c:	eb00403f 	cmp	x1, x0, lsl #16
    a470:	54000322 	b.cs	a4d4 <f0+0xc24>  // b.hs, b.nlast
    a474:	d350fc22 	lsr	x2, x1, #16
    a478:	f949fc63 	ldr	x3, [x3, #5112]
    a47c:	8b020842 	add	x2, x2, x2, lsl #2
    a480:	d37df042 	lsl	x2, x2, #3
    a484:	8b020060 	add	x0, x3, x2
    a488:	f9401015 	ldr	x21, [x0, #32]
    a48c:	b4000255 	cbz	x21, a4d4 <f0+0xc24>
    a490:	38626862 	ldrb	w2, [x3, x2]
    a494:	7100085f 	cmp	w2, #0x2
    a498:	5400bee0 	b.eq	bc74 <f0+0x23c4>  // b.none
    a49c:	7100045f 	cmp	w2, #0x1
    a4a0:	540001a1 	b.ne	a4d4 <f0+0xc24>  // b.any
    a4a4:	29430002 	ldp	w2, w0, [x0, #24]
    a4a8:	92403c21 	and	x1, x1, #0xffff
    a4ac:	9b027c21 	mul	x1, x1, x2
    a4b0:	d360fc21 	lsr	x1, x1, #32
    a4b4:	eb00003f 	cmp	x1, x0
    a4b8:	540000e2 	b.cs	a4d4 <f0+0xc24>  // b.hs, b.nlast
    a4bc:	8b0102b5 	add	x21, x21, x1
    a4c0:	394002a0 	ldrb	w0, [x21]
    a4c4:	7103fc1f 	cmp	w0, #0xff
    a4c8:	5400c840 	b.eq	bdd0 <f0+0x2520>  // b.none
    a4cc:	52800020 	mov	w0, #0x1                   	// #1
    a4d0:	390002a0 	strb	w0, [x21]
    a4d4:	910f63e1 	add	x1, sp, #0x3d8
    a4d8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a4dc:	52800020 	mov	w0, #0x1                   	// #1
    a4e0:	f901eff5 	str	x21, [sp, #984]
    a4e4:	f901f3f7 	str	x23, [sp, #992]
    a4e8:	97ffea27 	bl	4d84 <fwp_data.part.0.constprop.0>
    a4ec:	97ffebb2 	bl	53b4 <fwp_rc_fresh>
    a4f0:	aa0003e2 	mov	x2, x0
    a4f4:	910fa3e1 	add	x1, sp, #0x3e8
    a4f8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a4fc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a500:	52800020 	mov	w0, #0x1                   	// #1
    a504:	f901f7f7 	str	x23, [sp, #1000]
    a508:	f901fbe2 	str	x2, [sp, #1008]
    a50c:	97ffea1e 	bl	4d84 <fwp_data.part.0.constprop.0>
    a510:	97ffeba9 	bl	53b4 <fwp_rc_fresh>
    a514:	aa0003e2 	mov	x2, x0
    a518:	910fe3e1 	add	x1, sp, #0x3f8
    a51c:	52800020 	mov	w0, #0x1                   	// #1
    a520:	f901fff5 	str	x21, [sp, #1016]
    a524:	f90203e2 	str	x2, [sp, #1024]
    a528:	97ffea17 	bl	4d84 <fwp_data.part.0.constprop.0>
    a52c:	97ffeba2 	bl	53b4 <fwp_rc_fresh>
    a530:	aa0003e2 	mov	x2, x0
    a534:	911023e1 	add	x1, sp, #0x408
    a538:	52800020 	mov	w0, #0x1                   	// #1
    a53c:	f90207f7 	str	x23, [sp, #1032]
    a540:	f9020be2 	str	x2, [sp, #1040]
    a544:	97ffea10 	bl	4d84 <fwp_data.part.0.constprop.0>
    a548:	97ffeb9b 	bl	53b4 <fwp_rc_fresh>
    a54c:	aa0003e2 	mov	x2, x0
    a550:	911063e1 	add	x1, sp, #0x418
    a554:	52800020 	mov	w0, #0x1                   	// #1
    a558:	f9020ff5 	str	x21, [sp, #1048]
    a55c:	f90213e2 	str	x2, [sp, #1056]
    a560:	97ffea09 	bl	4d84 <fwp_data.part.0.constprop.0>
    a564:	97ffeb94 	bl	53b4 <fwp_rc_fresh>
    a568:	aa0003e2 	mov	x2, x0
    a56c:	9110a3e1 	add	x1, sp, #0x428
    a570:	52800020 	mov	w0, #0x1                   	// #1
    a574:	f90217f7 	str	x23, [sp, #1064]
    a578:	f9021be2 	str	x2, [sp, #1072]
    a57c:	97ffea02 	bl	4d84 <fwp_data.part.0.constprop.0>
    a580:	97ffeb8d 	bl	53b4 <fwp_rc_fresh>
    a584:	aa0003e2 	mov	x2, x0
    a588:	9110e3e1 	add	x1, sp, #0x438
    a58c:	52800020 	mov	w0, #0x1                   	// #1
    a590:	f9021ff5 	str	x21, [sp, #1080]
    a594:	f90223e2 	str	x2, [sp, #1088]
    a598:	97ffe9fb 	bl	4d84 <fwp_data.part.0.constprop.0>
    a59c:	91150283 	add	x3, x20, #0x540
    a5a0:	aa0003f5 	mov	x21, x0
    a5a4:	f949d861 	ldr	x1, [x3, #5040]
    a5a8:	f949ec60 	ldr	x0, [x3, #5080]
    a5ac:	cb0102a1 	sub	x1, x21, x1
    a5b0:	eb00403f 	cmp	x1, x0, lsl #16
    a5b4:	54000322 	b.cs	a618 <f0+0xd68>  // b.hs, b.nlast
    a5b8:	d350fc22 	lsr	x2, x1, #16
    a5bc:	f949fc63 	ldr	x3, [x3, #5112]
    a5c0:	8b020842 	add	x2, x2, x2, lsl #2
    a5c4:	d37df042 	lsl	x2, x2, #3
    a5c8:	8b020060 	add	x0, x3, x2
    a5cc:	f9401017 	ldr	x23, [x0, #32]
    a5d0:	b4000257 	cbz	x23, a618 <f0+0xd68>
    a5d4:	38626862 	ldrb	w2, [x3, x2]
    a5d8:	7100085f 	cmp	w2, #0x2
    a5dc:	5400b460 	b.eq	bc68 <f0+0x23b8>  // b.none
    a5e0:	7100045f 	cmp	w2, #0x1
    a5e4:	540001a1 	b.ne	a618 <f0+0xd68>  // b.any
    a5e8:	29430002 	ldp	w2, w0, [x0, #24]
    a5ec:	92403c21 	and	x1, x1, #0xffff
    a5f0:	9b027c21 	mul	x1, x1, x2
    a5f4:	d360fc21 	lsr	x1, x1, #32
    a5f8:	eb00003f 	cmp	x1, x0
    a5fc:	540000e2 	b.cs	a618 <f0+0xd68>  // b.hs, b.nlast
    a600:	8b0102f7 	add	x23, x23, x1
    a604:	394002e0 	ldrb	w0, [x23]
    a608:	7103fc1f 	cmp	w0, #0xff
    a60c:	5400be80 	b.eq	bddc <f0+0x252c>  // b.none
    a610:	52800020 	mov	w0, #0x1                   	// #1
    a614:	390002e0 	strb	w0, [x23]
    a618:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a61c:	911123e1 	add	x1, sp, #0x448
    a620:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a624:	52800020 	mov	w0, #0x1                   	// #1
    a628:	f90227e2 	str	x2, [sp, #1096]
    a62c:	f9022bf5 	str	x21, [sp, #1104]
    a630:	97ffe9d5 	bl	4d84 <fwp_data.part.0.constprop.0>
    a634:	91150283 	add	x3, x20, #0x540
    a638:	aa0003f5 	mov	x21, x0
    a63c:	f949d861 	ldr	x1, [x3, #5040]
    a640:	f949ec60 	ldr	x0, [x3, #5080]
    a644:	cb0102a1 	sub	x1, x21, x1
    a648:	eb00403f 	cmp	x1, x0, lsl #16
    a64c:	54000322 	b.cs	a6b0 <f0+0xe00>  // b.hs, b.nlast
    a650:	d350fc22 	lsr	x2, x1, #16
    a654:	f949fc63 	ldr	x3, [x3, #5112]
    a658:	8b020842 	add	x2, x2, x2, lsl #2
    a65c:	d37df042 	lsl	x2, x2, #3
    a660:	8b020060 	add	x0, x3, x2
    a664:	f9401017 	ldr	x23, [x0, #32]
    a668:	b4000257 	cbz	x23, a6b0 <f0+0xe00>
    a66c:	38626862 	ldrb	w2, [x3, x2]
    a670:	7100085f 	cmp	w2, #0x2
    a674:	5400af40 	b.eq	bc5c <f0+0x23ac>  // b.none
    a678:	7100045f 	cmp	w2, #0x1
    a67c:	540001a1 	b.ne	a6b0 <f0+0xe00>  // b.any
    a680:	29430002 	ldp	w2, w0, [x0, #24]
    a684:	92403c21 	and	x1, x1, #0xffff
    a688:	9b027c21 	mul	x1, x1, x2
    a68c:	d360fc21 	lsr	x1, x1, #32
    a690:	eb00003f 	cmp	x1, x0
    a694:	540000e2 	b.cs	a6b0 <f0+0xe00>  // b.hs, b.nlast
    a698:	8b0102f7 	add	x23, x23, x1
    a69c:	394002e0 	ldrb	w0, [x23]
    a6a0:	7103fc1f 	cmp	w0, #0xff
    a6a4:	5400ba20 	b.eq	bde8 <f0+0x2538>  // b.none
    a6a8:	52800020 	mov	w0, #0x1                   	// #1
    a6ac:	390002e0 	strb	w0, [x23]
    a6b0:	911163e1 	add	x1, sp, #0x458
    a6b4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a6b8:	52800020 	mov	w0, #0x1                   	// #1
    a6bc:	f9022fe2 	str	x2, [sp, #1112]
    a6c0:	f90233f5 	str	x21, [sp, #1120]
    a6c4:	97ffe9b0 	bl	4d84 <fwp_data.part.0.constprop.0>
    a6c8:	97ffeb3b 	bl	53b4 <fwp_rc_fresh>
    a6cc:	aa0003e2 	mov	x2, x0
    a6d0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a6d4:	9111a3e1 	add	x1, sp, #0x468
    a6d8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a6dc:	52800020 	mov	w0, #0x1                   	// #1
    a6e0:	f90237e3 	str	x3, [sp, #1128]
    a6e4:	f9023be2 	str	x2, [sp, #1136]
    a6e8:	97ffe9a7 	bl	4d84 <fwp_data.part.0.constprop.0>
    a6ec:	91150283 	add	x3, x20, #0x540
    a6f0:	aa0003f5 	mov	x21, x0
    a6f4:	f949d861 	ldr	x1, [x3, #5040]
    a6f8:	f949ec60 	ldr	x0, [x3, #5080]
    a6fc:	cb0102a1 	sub	x1, x21, x1
    a700:	eb00403f 	cmp	x1, x0, lsl #16
    a704:	54000322 	b.cs	a768 <f0+0xeb8>  // b.hs, b.nlast
    a708:	d350fc22 	lsr	x2, x1, #16
    a70c:	f949fc63 	ldr	x3, [x3, #5112]
    a710:	8b020842 	add	x2, x2, x2, lsl #2
    a714:	d37df042 	lsl	x2, x2, #3
    a718:	8b020060 	add	x0, x3, x2
    a71c:	f9401017 	ldr	x23, [x0, #32]
    a720:	b4000257 	cbz	x23, a768 <f0+0xeb8>
    a724:	38626862 	ldrb	w2, [x3, x2]
    a728:	7100085f 	cmp	w2, #0x2
    a72c:	5400a920 	b.eq	bc50 <f0+0x23a0>  // b.none
    a730:	7100045f 	cmp	w2, #0x1
    a734:	540001a1 	b.ne	a768 <f0+0xeb8>  // b.any
    a738:	29430002 	ldp	w2, w0, [x0, #24]
    a73c:	92403c21 	and	x1, x1, #0xffff
    a740:	9b027c21 	mul	x1, x1, x2
    a744:	d360fc21 	lsr	x1, x1, #32
    a748:	eb00003f 	cmp	x1, x0
    a74c:	540000e2 	b.cs	a768 <f0+0xeb8>  // b.hs, b.nlast
    a750:	8b0102f7 	add	x23, x23, x1
    a754:	394002e0 	ldrb	w0, [x23]
    a758:	7103fc1f 	cmp	w0, #0xff
    a75c:	5400b4c0 	b.eq	bdf4 <f0+0x2544>  // b.none
    a760:	52800020 	mov	w0, #0x1                   	// #1
    a764:	390002e0 	strb	w0, [x23]
    a768:	9111e3e1 	add	x1, sp, #0x478
    a76c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a770:	52800020 	mov	w0, #0x1                   	// #1
    a774:	f9023fe2 	str	x2, [sp, #1144]
    a778:	f90243f5 	str	x21, [sp, #1152]
    a77c:	97ffe982 	bl	4d84 <fwp_data.part.0.constprop.0>
    a780:	97ffeb0d 	bl	53b4 <fwp_rc_fresh>
    a784:	aa0003e2 	mov	x2, x0
    a788:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a78c:	911223e1 	add	x1, sp, #0x488
    a790:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a794:	52800020 	mov	w0, #0x1                   	// #1
    a798:	f90247e3 	str	x3, [sp, #1160]
    a79c:	f9024be2 	str	x2, [sp, #1168]
    a7a0:	97ffe979 	bl	4d84 <fwp_data.part.0.constprop.0>
    a7a4:	91150283 	add	x3, x20, #0x540
    a7a8:	aa0003f5 	mov	x21, x0
    a7ac:	f949d861 	ldr	x1, [x3, #5040]
    a7b0:	f949ec60 	ldr	x0, [x3, #5080]
    a7b4:	cb0102a1 	sub	x1, x21, x1
    a7b8:	eb00403f 	cmp	x1, x0, lsl #16
    a7bc:	54000322 	b.cs	a820 <f0+0xf70>  // b.hs, b.nlast
    a7c0:	d350fc22 	lsr	x2, x1, #16
    a7c4:	f949fc63 	ldr	x3, [x3, #5112]
    a7c8:	8b020842 	add	x2, x2, x2, lsl #2
    a7cc:	d37df042 	lsl	x2, x2, #3
    a7d0:	8b020060 	add	x0, x3, x2
    a7d4:	f9401017 	ldr	x23, [x0, #32]
    a7d8:	b4000257 	cbz	x23, a820 <f0+0xf70>
    a7dc:	38626862 	ldrb	w2, [x3, x2]
    a7e0:	7100085f 	cmp	w2, #0x2
    a7e4:	5400a300 	b.eq	bc44 <f0+0x2394>  // b.none
    a7e8:	7100045f 	cmp	w2, #0x1
    a7ec:	540001a1 	b.ne	a820 <f0+0xf70>  // b.any
    a7f0:	29430002 	ldp	w2, w0, [x0, #24]
    a7f4:	92403c21 	and	x1, x1, #0xffff
    a7f8:	9b027c21 	mul	x1, x1, x2
    a7fc:	d360fc21 	lsr	x1, x1, #32
    a800:	eb00003f 	cmp	x1, x0
    a804:	540000e2 	b.cs	a820 <f0+0xf70>  // b.hs, b.nlast
    a808:	8b0102f7 	add	x23, x23, x1
    a80c:	394002e0 	ldrb	w0, [x23]
    a810:	7103fc1f 	cmp	w0, #0xff
    a814:	5400af60 	b.eq	be00 <f0+0x2550>  // b.none
    a818:	52800020 	mov	w0, #0x1                   	// #1
    a81c:	390002e0 	strb	w0, [x23]
    a820:	911263e1 	add	x1, sp, #0x498
    a824:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a828:	52800020 	mov	w0, #0x1                   	// #1
    a82c:	f9024ff7 	str	x23, [sp, #1176]
    a830:	f90253f5 	str	x21, [sp, #1184]
    a834:	97ffe954 	bl	4d84 <fwp_data.part.0.constprop.0>
    a838:	97ffeadf 	bl	53b4 <fwp_rc_fresh>
    a83c:	aa0003e2 	mov	x2, x0
    a840:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a844:	9112a3e1 	add	x1, sp, #0x4a8
    a848:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a84c:	52800020 	mov	w0, #0x1                   	// #1
    a850:	f90257e3 	str	x3, [sp, #1192]
    a854:	f9025be2 	str	x2, [sp, #1200]
    a858:	97ffe94b 	bl	4d84 <fwp_data.part.0.constprop.0>
    a85c:	97ffead6 	bl	53b4 <fwp_rc_fresh>
    a860:	aa0003e2 	mov	x2, x0
    a864:	9112e3e1 	add	x1, sp, #0x4b8
    a868:	52800020 	mov	w0, #0x1                   	// #1
    a86c:	f9025ff7 	str	x23, [sp, #1208]
    a870:	f90263e2 	str	x2, [sp, #1216]
    a874:	97ffe944 	bl	4d84 <fwp_data.part.0.constprop.0>
    a878:	91150283 	add	x3, x20, #0x540
    a87c:	aa0003f5 	mov	x21, x0
    a880:	f949d861 	ldr	x1, [x3, #5040]
    a884:	f949ec60 	ldr	x0, [x3, #5080]
    a888:	cb0102a1 	sub	x1, x21, x1
    a88c:	eb00403f 	cmp	x1, x0, lsl #16
    a890:	54000322 	b.cs	a8f4 <f0+0x1044>  // b.hs, b.nlast
    a894:	d350fc22 	lsr	x2, x1, #16
    a898:	f949fc63 	ldr	x3, [x3, #5112]
    a89c:	8b020842 	add	x2, x2, x2, lsl #2
    a8a0:	d37df042 	lsl	x2, x2, #3
    a8a4:	8b020060 	add	x0, x3, x2
    a8a8:	f9401017 	ldr	x23, [x0, #32]
    a8ac:	b4000257 	cbz	x23, a8f4 <f0+0x1044>
    a8b0:	38626862 	ldrb	w2, [x3, x2]
    a8b4:	7100085f 	cmp	w2, #0x2
    a8b8:	54009c00 	b.eq	bc38 <f0+0x2388>  // b.none
    a8bc:	7100045f 	cmp	w2, #0x1
    a8c0:	540001a1 	b.ne	a8f4 <f0+0x1044>  // b.any
    a8c4:	29430002 	ldp	w2, w0, [x0, #24]
    a8c8:	92403c21 	and	x1, x1, #0xffff
    a8cc:	9b027c21 	mul	x1, x1, x2
    a8d0:	d360fc21 	lsr	x1, x1, #32
    a8d4:	eb00003f 	cmp	x1, x0
    a8d8:	540000e2 	b.cs	a8f4 <f0+0x1044>  // b.hs, b.nlast
    a8dc:	8b0102f7 	add	x23, x23, x1
    a8e0:	394002e0 	ldrb	w0, [x23]
    a8e4:	7103fc1f 	cmp	w0, #0xff
    a8e8:	5400a920 	b.eq	be0c <f0+0x255c>  // b.none
    a8ec:	52800020 	mov	w0, #0x1                   	// #1
    a8f0:	390002e0 	strb	w0, [x23]
    a8f4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a8f8:	911323e1 	add	x1, sp, #0x4c8
    a8fc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a900:	52800020 	mov	w0, #0x1                   	// #1
    a904:	f90267e2 	str	x2, [sp, #1224]
    a908:	f9026bf5 	str	x21, [sp, #1232]
    a90c:	97ffe91e 	bl	4d84 <fwp_data.part.0.constprop.0>
    a910:	91150283 	add	x3, x20, #0x540
    a914:	aa0003f5 	mov	x21, x0
    a918:	f949d861 	ldr	x1, [x3, #5040]
    a91c:	f949ec60 	ldr	x0, [x3, #5080]
    a920:	cb0102a1 	sub	x1, x21, x1
    a924:	eb00403f 	cmp	x1, x0, lsl #16
    a928:	54000322 	b.cs	a98c <f0+0x10dc>  // b.hs, b.nlast
    a92c:	d350fc22 	lsr	x2, x1, #16
    a930:	f949fc63 	ldr	x3, [x3, #5112]
    a934:	8b020842 	add	x2, x2, x2, lsl #2
    a938:	d37df042 	lsl	x2, x2, #3
    a93c:	8b020060 	add	x0, x3, x2
    a940:	f9401017 	ldr	x23, [x0, #32]
    a944:	b4000257 	cbz	x23, a98c <f0+0x10dc>
    a948:	38626862 	ldrb	w2, [x3, x2]
    a94c:	7100085f 	cmp	w2, #0x2
    a950:	54009440 	b.eq	bbd8 <f0+0x2328>  // b.none
    a954:	7100045f 	cmp	w2, #0x1
    a958:	540001a1 	b.ne	a98c <f0+0x10dc>  // b.any
    a95c:	29430002 	ldp	w2, w0, [x0, #24]
    a960:	92403c21 	and	x1, x1, #0xffff
    a964:	9b027c21 	mul	x1, x1, x2
    a968:	d360fc21 	lsr	x1, x1, #32
    a96c:	eb00003f 	cmp	x1, x0
    a970:	540000e2 	b.cs	a98c <f0+0x10dc>  // b.hs, b.nlast
    a974:	8b0102f7 	add	x23, x23, x1
    a978:	394002e0 	ldrb	w0, [x23]
    a97c:	7103fc1f 	cmp	w0, #0xff
    a980:	5400a4c0 	b.eq	be18 <f0+0x2568>  // b.none
    a984:	52800020 	mov	w0, #0x1                   	// #1
    a988:	390002e0 	strb	w0, [x23]
    a98c:	911363e1 	add	x1, sp, #0x4d8
    a990:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a994:	52800020 	mov	w0, #0x1                   	// #1
    a998:	f9026fe2 	str	x2, [sp, #1240]
    a99c:	f90273f5 	str	x21, [sp, #1248]
    a9a0:	97ffe8f9 	bl	4d84 <fwp_data.part.0.constprop.0>
    a9a4:	97ffea84 	bl	53b4 <fwp_rc_fresh>
    a9a8:	aa0003e2 	mov	x2, x0
    a9ac:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a9b0:	9113a3e1 	add	x1, sp, #0x4e8
    a9b4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a9b8:	52800020 	mov	w0, #0x1                   	// #1
    a9bc:	f90277e3 	str	x3, [sp, #1256]
    a9c0:	f9027be2 	str	x2, [sp, #1264]
    a9c4:	97ffe8f0 	bl	4d84 <fwp_data.part.0.constprop.0>
    a9c8:	91150283 	add	x3, x20, #0x540
    a9cc:	aa0003f5 	mov	x21, x0
    a9d0:	f949d861 	ldr	x1, [x3, #5040]
    a9d4:	f949ec60 	ldr	x0, [x3, #5080]
    a9d8:	cb0102a1 	sub	x1, x21, x1
    a9dc:	eb00403f 	cmp	x1, x0, lsl #16
    a9e0:	54000322 	b.cs	aa44 <f0+0x1194>  // b.hs, b.nlast
    a9e4:	d350fc22 	lsr	x2, x1, #16
    a9e8:	f949fc63 	ldr	x3, [x3, #5112]
    a9ec:	8b020842 	add	x2, x2, x2, lsl #2
    a9f0:	d37df042 	lsl	x2, x2, #3
    a9f4:	8b020060 	add	x0, x3, x2
    a9f8:	f9401017 	ldr	x23, [x0, #32]
    a9fc:	b4000257 	cbz	x23, aa44 <f0+0x1194>
    aa00:	38626862 	ldrb	w2, [x3, x2]
    aa04:	7100085f 	cmp	w2, #0x2
    aa08:	54008e20 	b.eq	bbcc <f0+0x231c>  // b.none
    aa0c:	7100045f 	cmp	w2, #0x1
    aa10:	540001a1 	b.ne	aa44 <f0+0x1194>  // b.any
    aa14:	29430002 	ldp	w2, w0, [x0, #24]
    aa18:	92403c21 	and	x1, x1, #0xffff
    aa1c:	9b027c21 	mul	x1, x1, x2
    aa20:	d360fc21 	lsr	x1, x1, #32
    aa24:	eb00003f 	cmp	x1, x0
    aa28:	540000e2 	b.cs	aa44 <f0+0x1194>  // b.hs, b.nlast
    aa2c:	8b0102f7 	add	x23, x23, x1
    aa30:	394002e0 	ldrb	w0, [x23]
    aa34:	7103fc1f 	cmp	w0, #0xff
    aa38:	54009f60 	b.eq	be24 <f0+0x2574>  // b.none
    aa3c:	52800020 	mov	w0, #0x1                   	// #1
    aa40:	390002e0 	strb	w0, [x23]
    aa44:	9113e3e1 	add	x1, sp, #0x4f8
    aa48:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aa4c:	52800020 	mov	w0, #0x1                   	// #1
    aa50:	f9027fe2 	str	x2, [sp, #1272]
    aa54:	f90283f5 	str	x21, [sp, #1280]
    aa58:	97ffe8cb 	bl	4d84 <fwp_data.part.0.constprop.0>
    aa5c:	97ffea56 	bl	53b4 <fwp_rc_fresh>
    aa60:	aa0003e2 	mov	x2, x0
    aa64:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aa68:	911423e1 	add	x1, sp, #0x508
    aa6c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aa70:	52800020 	mov	w0, #0x1                   	// #1
    aa74:	f90287e3 	str	x3, [sp, #1288]
    aa78:	f9028be2 	str	x2, [sp, #1296]
    aa7c:	97ffe8c2 	bl	4d84 <fwp_data.part.0.constprop.0>
    aa80:	91150283 	add	x3, x20, #0x540
    aa84:	aa0003f5 	mov	x21, x0
    aa88:	f949d861 	ldr	x1, [x3, #5040]
    aa8c:	f949ec60 	ldr	x0, [x3, #5080]
    aa90:	cb0102a1 	sub	x1, x21, x1
    aa94:	eb00403f 	cmp	x1, x0, lsl #16
    aa98:	54000322 	b.cs	aafc <f0+0x124c>  // b.hs, b.nlast
    aa9c:	d350fc22 	lsr	x2, x1, #16
    aaa0:	f949fc63 	ldr	x3, [x3, #5112]
    aaa4:	8b020842 	add	x2, x2, x2, lsl #2
    aaa8:	d37df042 	lsl	x2, x2, #3
    aaac:	8b020060 	add	x0, x3, x2
    aab0:	f9401017 	ldr	x23, [x0, #32]
    aab4:	b4000257 	cbz	x23, aafc <f0+0x124c>
    aab8:	38626862 	ldrb	w2, [x3, x2]
    aabc:	7100085f 	cmp	w2, #0x2
    aac0:	54008800 	b.eq	bbc0 <f0+0x2310>  // b.none
    aac4:	7100045f 	cmp	w2, #0x1
    aac8:	540001a1 	b.ne	aafc <f0+0x124c>  // b.any
    aacc:	29430002 	ldp	w2, w0, [x0, #24]
    aad0:	92403c21 	and	x1, x1, #0xffff
    aad4:	9b027c21 	mul	x1, x1, x2
    aad8:	d360fc21 	lsr	x1, x1, #32
    aadc:	eb00003f 	cmp	x1, x0
    aae0:	540000e2 	b.cs	aafc <f0+0x124c>  // b.hs, b.nlast
    aae4:	8b0102f7 	add	x23, x23, x1
    aae8:	394002e0 	ldrb	w0, [x23]
    aaec:	7103fc1f 	cmp	w0, #0xff
    aaf0:	54009a00 	b.eq	be30 <f0+0x2580>  // b.none
    aaf4:	52800020 	mov	w0, #0x1                   	// #1
    aaf8:	390002e0 	strb	w0, [x23]
    aafc:	911463e1 	add	x1, sp, #0x518
    ab00:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ab04:	52800020 	mov	w0, #0x1                   	// #1
    ab08:	f9028ff7 	str	x23, [sp, #1304]
    ab0c:	f90293f5 	str	x21, [sp, #1312]
    ab10:	97ffe89d 	bl	4d84 <fwp_data.part.0.constprop.0>
    ab14:	97ffea28 	bl	53b4 <fwp_rc_fresh>
    ab18:	aa0003e2 	mov	x2, x0
    ab1c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ab20:	9114a3e1 	add	x1, sp, #0x528
    ab24:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ab28:	52800020 	mov	w0, #0x1                   	// #1
    ab2c:	f90297e3 	str	x3, [sp, #1320]
    ab30:	f9029be2 	str	x2, [sp, #1328]
    ab34:	97ffe894 	bl	4d84 <fwp_data.part.0.constprop.0>
    ab38:	97ffea1f 	bl	53b4 <fwp_rc_fresh>
    ab3c:	aa0003e2 	mov	x2, x0
    ab40:	9114e3e1 	add	x1, sp, #0x538
    ab44:	52800020 	mov	w0, #0x1                   	// #1
    ab48:	f9029ff7 	str	x23, [sp, #1336]
    ab4c:	f902a3e2 	str	x2, [sp, #1344]
    ab50:	97ffe88d 	bl	4d84 <fwp_data.part.0.constprop.0>
    ab54:	91150283 	add	x3, x20, #0x540
    ab58:	aa0003f5 	mov	x21, x0
    ab5c:	f949d861 	ldr	x1, [x3, #5040]
    ab60:	f949ec60 	ldr	x0, [x3, #5080]
    ab64:	cb0102a1 	sub	x1, x21, x1
    ab68:	eb00403f 	cmp	x1, x0, lsl #16
    ab6c:	54000322 	b.cs	abd0 <f0+0x1320>  // b.hs, b.nlast
    ab70:	d350fc22 	lsr	x2, x1, #16
    ab74:	f949fc63 	ldr	x3, [x3, #5112]
    ab78:	8b020842 	add	x2, x2, x2, lsl #2
    ab7c:	d37df042 	lsl	x2, x2, #3
    ab80:	8b020060 	add	x0, x3, x2
    ab84:	f9401017 	ldr	x23, [x0, #32]
    ab88:	b4000257 	cbz	x23, abd0 <f0+0x1320>
    ab8c:	38626862 	ldrb	w2, [x3, x2]
    ab90:	7100085f 	cmp	w2, #0x2
    ab94:	54008100 	b.eq	bbb4 <f0+0x2304>  // b.none
    ab98:	7100045f 	cmp	w2, #0x1
    ab9c:	540001a1 	b.ne	abd0 <f0+0x1320>  // b.any
    aba0:	29430002 	ldp	w2, w0, [x0, #24]
    aba4:	92403c21 	and	x1, x1, #0xffff
    aba8:	9b027c21 	mul	x1, x1, x2
    abac:	d360fc21 	lsr	x1, x1, #32
    abb0:	eb00003f 	cmp	x1, x0
    abb4:	540000e2 	b.cs	abd0 <f0+0x1320>  // b.hs, b.nlast
    abb8:	8b0102f7 	add	x23, x23, x1
    abbc:	394002e0 	ldrb	w0, [x23]
    abc0:	7103fc1f 	cmp	w0, #0xff
    abc4:	540093c0 	b.eq	be3c <f0+0x258c>  // b.none
    abc8:	52800020 	mov	w0, #0x1                   	// #1
    abcc:	390002e0 	strb	w0, [x23]
    abd0:	911523e1 	add	x1, sp, #0x548
    abd4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    abd8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    abdc:	52800020 	mov	w0, #0x1                   	// #1
    abe0:	f902a7f7 	str	x23, [sp, #1352]
    abe4:	f902abf5 	str	x21, [sp, #1360]
    abe8:	97ffe867 	bl	4d84 <fwp_data.part.0.constprop.0>
    abec:	97ffe9f2 	bl	53b4 <fwp_rc_fresh>
    abf0:	aa0003e2 	mov	x2, x0
    abf4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    abf8:	911563e1 	add	x1, sp, #0x558
    abfc:	52800020 	mov	w0, #0x1                   	// #1
    ac00:	f902afe3 	str	x3, [sp, #1368]
    ac04:	f902b3e2 	str	x2, [sp, #1376]
    ac08:	97ffe85f 	bl	4d84 <fwp_data.part.0.constprop.0>
    ac0c:	97ffe9ea 	bl	53b4 <fwp_rc_fresh>
    ac10:	aa0003e2 	mov	x2, x0
    ac14:	9115a3e1 	add	x1, sp, #0x568
    ac18:	52800020 	mov	w0, #0x1                   	// #1
    ac1c:	f902b7f7 	str	x23, [sp, #1384]
    ac20:	f902bbe2 	str	x2, [sp, #1392]
    ac24:	97ffe858 	bl	4d84 <fwp_data.part.0.constprop.0>
    ac28:	91150283 	add	x3, x20, #0x540
    ac2c:	aa0003f5 	mov	x21, x0
    ac30:	f949d861 	ldr	x1, [x3, #5040]
    ac34:	f949ec60 	ldr	x0, [x3, #5080]
    ac38:	cb0102a1 	sub	x1, x21, x1
    ac3c:	eb00403f 	cmp	x1, x0, lsl #16
    ac40:	54000322 	b.cs	aca4 <f0+0x13f4>  // b.hs, b.nlast
    ac44:	d350fc22 	lsr	x2, x1, #16
    ac48:	f949fc63 	ldr	x3, [x3, #5112]
    ac4c:	8b020842 	add	x2, x2, x2, lsl #2
    ac50:	d37df042 	lsl	x2, x2, #3
    ac54:	8b020060 	add	x0, x3, x2
    ac58:	f9401017 	ldr	x23, [x0, #32]
    ac5c:	b4000257 	cbz	x23, aca4 <f0+0x13f4>
    ac60:	38626862 	ldrb	w2, [x3, x2]
    ac64:	7100085f 	cmp	w2, #0x2
    ac68:	54007a00 	b.eq	bba8 <f0+0x22f8>  // b.none
    ac6c:	7100045f 	cmp	w2, #0x1
    ac70:	540001a1 	b.ne	aca4 <f0+0x13f4>  // b.any
    ac74:	29430002 	ldp	w2, w0, [x0, #24]
    ac78:	92403c21 	and	x1, x1, #0xffff
    ac7c:	9b027c21 	mul	x1, x1, x2
    ac80:	d360fc21 	lsr	x1, x1, #32
    ac84:	eb00003f 	cmp	x1, x0
    ac88:	540000e2 	b.cs	aca4 <f0+0x13f4>  // b.hs, b.nlast
    ac8c:	8b0102f7 	add	x23, x23, x1
    ac90:	394002e0 	ldrb	w0, [x23]
    ac94:	7103fc1f 	cmp	w0, #0xff
    ac98:	54008d80 	b.eq	be48 <f0+0x2598>  // b.none
    ac9c:	52800020 	mov	w0, #0x1                   	// #1
    aca0:	390002e0 	strb	w0, [x23]
    aca4:	9115e3e1 	add	x1, sp, #0x578
    aca8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    acac:	52800020 	mov	w0, #0x1                   	// #1
    acb0:	f902bfe2 	str	x2, [sp, #1400]
    acb4:	f902c3f5 	str	x21, [sp, #1408]
    acb8:	97ffe833 	bl	4d84 <fwp_data.part.0.constprop.0>
    acbc:	97ffe9be 	bl	53b4 <fwp_rc_fresh>
    acc0:	aa0003e2 	mov	x2, x0
    acc4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    acc8:	911623e1 	add	x1, sp, #0x588
    accc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    acd0:	52800020 	mov	w0, #0x1                   	// #1
    acd4:	f902c7e3 	str	x3, [sp, #1416]
    acd8:	f902cbe2 	str	x2, [sp, #1424]
    acdc:	97ffe82a 	bl	4d84 <fwp_data.part.0.constprop.0>
    ace0:	91150283 	add	x3, x20, #0x540
    ace4:	aa0003f5 	mov	x21, x0
    ace8:	f949d861 	ldr	x1, [x3, #5040]
    acec:	f949ec60 	ldr	x0, [x3, #5080]
    acf0:	cb0102a1 	sub	x1, x21, x1
    acf4:	eb00403f 	cmp	x1, x0, lsl #16
    acf8:	54000322 	b.cs	ad5c <f0+0x14ac>  // b.hs, b.nlast
    acfc:	d350fc22 	lsr	x2, x1, #16
    ad00:	f949fc63 	ldr	x3, [x3, #5112]
    ad04:	8b020842 	add	x2, x2, x2, lsl #2
    ad08:	d37df042 	lsl	x2, x2, #3
    ad0c:	8b020060 	add	x0, x3, x2
    ad10:	f9401017 	ldr	x23, [x0, #32]
    ad14:	b4000257 	cbz	x23, ad5c <f0+0x14ac>
    ad18:	38626862 	ldrb	w2, [x3, x2]
    ad1c:	7100085f 	cmp	w2, #0x2
    ad20:	540073e0 	b.eq	bb9c <f0+0x22ec>  // b.none
    ad24:	7100045f 	cmp	w2, #0x1
    ad28:	540001a1 	b.ne	ad5c <f0+0x14ac>  // b.any
    ad2c:	29430002 	ldp	w2, w0, [x0, #24]
    ad30:	92403c21 	and	x1, x1, #0xffff
    ad34:	9b027c21 	mul	x1, x1, x2
    ad38:	d360fc21 	lsr	x1, x1, #32
    ad3c:	eb00003f 	cmp	x1, x0
    ad40:	540000e2 	b.cs	ad5c <f0+0x14ac>  // b.hs, b.nlast
    ad44:	8b0102f7 	add	x23, x23, x1
    ad48:	394002e0 	ldrb	w0, [x23]
    ad4c:	7103fc1f 	cmp	w0, #0xff
    ad50:	54008820 	b.eq	be54 <f0+0x25a4>  // b.none
    ad54:	52800020 	mov	w0, #0x1                   	// #1
    ad58:	390002e0 	strb	w0, [x23]
    ad5c:	911663e1 	add	x1, sp, #0x598
    ad60:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ad64:	52800020 	mov	w0, #0x1                   	// #1
    ad68:	f902cff7 	str	x23, [sp, #1432]
    ad6c:	f902d3f5 	str	x21, [sp, #1440]
    ad70:	97ffe805 	bl	4d84 <fwp_data.part.0.constprop.0>
    ad74:	97ffe990 	bl	53b4 <fwp_rc_fresh>
    ad78:	aa0003e2 	mov	x2, x0
    ad7c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ad80:	9116a3e1 	add	x1, sp, #0x5a8
    ad84:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ad88:	52800020 	mov	w0, #0x1                   	// #1
    ad8c:	f902d7e3 	str	x3, [sp, #1448]
    ad90:	f902dbe2 	str	x2, [sp, #1456]
    ad94:	97ffe7fc 	bl	4d84 <fwp_data.part.0.constprop.0>
    ad98:	97ffe987 	bl	53b4 <fwp_rc_fresh>
    ad9c:	aa0003e2 	mov	x2, x0
    ada0:	9116e3e1 	add	x1, sp, #0x5b8
    ada4:	52800020 	mov	w0, #0x1                   	// #1
    ada8:	f902dff7 	str	x23, [sp, #1464]
    adac:	f902e3e2 	str	x2, [sp, #1472]
    adb0:	97ffe7f5 	bl	4d84 <fwp_data.part.0.constprop.0>
    adb4:	91150283 	add	x3, x20, #0x540
    adb8:	aa0003f5 	mov	x21, x0
    adbc:	f949d861 	ldr	x1, [x3, #5040]
    adc0:	f949ec60 	ldr	x0, [x3, #5080]
    adc4:	cb0102a1 	sub	x1, x21, x1
    adc8:	eb00403f 	cmp	x1, x0, lsl #16
    adcc:	54000322 	b.cs	ae30 <f0+0x1580>  // b.hs, b.nlast
    add0:	d350fc22 	lsr	x2, x1, #16
    add4:	f949fc63 	ldr	x3, [x3, #5112]
    add8:	8b020842 	add	x2, x2, x2, lsl #2
    addc:	d37df042 	lsl	x2, x2, #3
    ade0:	8b020060 	add	x0, x3, x2
    ade4:	f9401017 	ldr	x23, [x0, #32]
    ade8:	b4000257 	cbz	x23, ae30 <f0+0x1580>
    adec:	38626862 	ldrb	w2, [x3, x2]
    adf0:	7100085f 	cmp	w2, #0x2
    adf4:	54006ce0 	b.eq	bb90 <f0+0x22e0>  // b.none
    adf8:	7100045f 	cmp	w2, #0x1
    adfc:	540001a1 	b.ne	ae30 <f0+0x1580>  // b.any
    ae00:	29430002 	ldp	w2, w0, [x0, #24]
    ae04:	92403c21 	and	x1, x1, #0xffff
    ae08:	9b027c21 	mul	x1, x1, x2
    ae0c:	d360fc21 	lsr	x1, x1, #32
    ae10:	eb00003f 	cmp	x1, x0
    ae14:	540000e2 	b.cs	ae30 <f0+0x1580>  // b.hs, b.nlast
    ae18:	8b0102f7 	add	x23, x23, x1
    ae1c:	394002e0 	ldrb	w0, [x23]
    ae20:	7103fc1f 	cmp	w0, #0xff
    ae24:	540081e0 	b.eq	be60 <f0+0x25b0>  // b.none
    ae28:	52800020 	mov	w0, #0x1                   	// #1
    ae2c:	390002e0 	strb	w0, [x23]
    ae30:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ae34:	911723e1 	add	x1, sp, #0x5c8
    ae38:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ae3c:	52800020 	mov	w0, #0x1                   	// #1
    ae40:	f902e7e2 	str	x2, [sp, #1480]
    ae44:	f902ebf5 	str	x21, [sp, #1488]
    ae48:	97ffe7cf 	bl	4d84 <fwp_data.part.0.constprop.0>
    ae4c:	91150283 	add	x3, x20, #0x540
    ae50:	aa0003f5 	mov	x21, x0
    ae54:	f949d861 	ldr	x1, [x3, #5040]
    ae58:	f949ec60 	ldr	x0, [x3, #5080]
    ae5c:	cb0102a1 	sub	x1, x21, x1
    ae60:	eb00403f 	cmp	x1, x0, lsl #16
    ae64:	54000322 	b.cs	aec8 <f0+0x1618>  // b.hs, b.nlast
    ae68:	d350fc22 	lsr	x2, x1, #16
    ae6c:	f949fc63 	ldr	x3, [x3, #5112]
    ae70:	8b020842 	add	x2, x2, x2, lsl #2
    ae74:	d37df042 	lsl	x2, x2, #3
    ae78:	8b020060 	add	x0, x3, x2
    ae7c:	f9401017 	ldr	x23, [x0, #32]
    ae80:	b4000257 	cbz	x23, aec8 <f0+0x1618>
    ae84:	38626862 	ldrb	w2, [x3, x2]
    ae88:	7100085f 	cmp	w2, #0x2
    ae8c:	540067c0 	b.eq	bb84 <f0+0x22d4>  // b.none
    ae90:	7100045f 	cmp	w2, #0x1
    ae94:	540001a1 	b.ne	aec8 <f0+0x1618>  // b.any
    ae98:	29430002 	ldp	w2, w0, [x0, #24]
    ae9c:	92403c21 	and	x1, x1, #0xffff
    aea0:	9b027c21 	mul	x1, x1, x2
    aea4:	d360fc21 	lsr	x1, x1, #32
    aea8:	eb00003f 	cmp	x1, x0
    aeac:	540000e2 	b.cs	aec8 <f0+0x1618>  // b.hs, b.nlast
    aeb0:	8b0102f7 	add	x23, x23, x1
    aeb4:	394002e0 	ldrb	w0, [x23]
    aeb8:	7103fc1f 	cmp	w0, #0xff
    aebc:	54007d80 	b.eq	be6c <f0+0x25bc>  // b.none
    aec0:	52800020 	mov	w0, #0x1                   	// #1
    aec4:	390002e0 	strb	w0, [x23]
    aec8:	911763e1 	add	x1, sp, #0x5d8
    aecc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aed0:	52800020 	mov	w0, #0x1                   	// #1
    aed4:	f902efe2 	str	x2, [sp, #1496]
    aed8:	f902f3f5 	str	x21, [sp, #1504]
    aedc:	97ffe7aa 	bl	4d84 <fwp_data.part.0.constprop.0>
    aee0:	97ffe935 	bl	53b4 <fwp_rc_fresh>
    aee4:	aa0003e2 	mov	x2, x0
    aee8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aeec:	9117a3e1 	add	x1, sp, #0x5e8
    aef0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aef4:	52800020 	mov	w0, #0x1                   	// #1
    aef8:	f902f7e3 	str	x3, [sp, #1512]
    aefc:	f902fbe2 	str	x2, [sp, #1520]
    af00:	97ffe7a1 	bl	4d84 <fwp_data.part.0.constprop.0>
    af04:	91150283 	add	x3, x20, #0x540
    af08:	aa0003f5 	mov	x21, x0
    af0c:	f949d861 	ldr	x1, [x3, #5040]
    af10:	f949ec60 	ldr	x0, [x3, #5080]
    af14:	cb0102a1 	sub	x1, x21, x1
    af18:	eb00403f 	cmp	x1, x0, lsl #16
    af1c:	54000322 	b.cs	af80 <f0+0x16d0>  // b.hs, b.nlast
    af20:	d350fc22 	lsr	x2, x1, #16
    af24:	f949fc63 	ldr	x3, [x3, #5112]
    af28:	8b020842 	add	x2, x2, x2, lsl #2
    af2c:	d37df042 	lsl	x2, x2, #3
    af30:	8b020060 	add	x0, x3, x2
    af34:	f9401017 	ldr	x23, [x0, #32]
    af38:	b4000257 	cbz	x23, af80 <f0+0x16d0>
    af3c:	38626862 	ldrb	w2, [x3, x2]
    af40:	7100085f 	cmp	w2, #0x2
    af44:	54007040 	b.eq	bd4c <f0+0x249c>  // b.none
    af48:	7100045f 	cmp	w2, #0x1
    af4c:	540001a1 	b.ne	af80 <f0+0x16d0>  // b.any
    af50:	29430002 	ldp	w2, w0, [x0, #24]
    af54:	92403c21 	and	x1, x1, #0xffff
    af58:	9b027c21 	mul	x1, x1, x2
    af5c:	d360fc21 	lsr	x1, x1, #32
    af60:	eb00003f 	cmp	x1, x0
    af64:	540000e2 	b.cs	af80 <f0+0x16d0>  // b.hs, b.nlast
    af68:	8b0102f7 	add	x23, x23, x1
    af6c:	394002e0 	ldrb	w0, [x23]
    af70:	7103fc1f 	cmp	w0, #0xff
    af74:	54007820 	b.eq	be78 <f0+0x25c8>  // b.none
    af78:	52800020 	mov	w0, #0x1                   	// #1
    af7c:	390002e0 	strb	w0, [x23]
    af80:	9117e3e1 	add	x1, sp, #0x5f8
    af84:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    af88:	52800020 	mov	w0, #0x1                   	// #1
    af8c:	f902ffe2 	str	x2, [sp, #1528]
    af90:	f90303f5 	str	x21, [sp, #1536]
    af94:	97ffe77c 	bl	4d84 <fwp_data.part.0.constprop.0>
    af98:	97ffe907 	bl	53b4 <fwp_rc_fresh>
    af9c:	aa0003e2 	mov	x2, x0
    afa0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    afa4:	911823e1 	add	x1, sp, #0x608
    afa8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    afac:	52800020 	mov	w0, #0x1                   	// #1
    afb0:	f90307e3 	str	x3, [sp, #1544]
    afb4:	f9030be2 	str	x2, [sp, #1552]
    afb8:	97ffe773 	bl	4d84 <fwp_data.part.0.constprop.0>
    afbc:	91150283 	add	x3, x20, #0x540
    afc0:	aa0003f5 	mov	x21, x0
    afc4:	f949d861 	ldr	x1, [x3, #5040]
    afc8:	f949ec60 	ldr	x0, [x3, #5080]
    afcc:	cb0102a1 	sub	x1, x21, x1
    afd0:	eb00403f 	cmp	x1, x0, lsl #16
    afd4:	54000322 	b.cs	b038 <f0+0x1788>  // b.hs, b.nlast
    afd8:	d350fc22 	lsr	x2, x1, #16
    afdc:	f949fc63 	ldr	x3, [x3, #5112]
    afe0:	8b020842 	add	x2, x2, x2, lsl #2
    afe4:	d37df042 	lsl	x2, x2, #3
    afe8:	8b020060 	add	x0, x3, x2
    afec:	f9401017 	ldr	x23, [x0, #32]
    aff0:	b4000257 	cbz	x23, b038 <f0+0x1788>
    aff4:	38626862 	ldrb	w2, [x3, x2]
    aff8:	7100085f 	cmp	w2, #0x2
    affc:	54006a20 	b.eq	bd40 <f0+0x2490>  // b.none
    b000:	7100045f 	cmp	w2, #0x1
    b004:	540001a1 	b.ne	b038 <f0+0x1788>  // b.any
    b008:	29430002 	ldp	w2, w0, [x0, #24]
    b00c:	92403c21 	and	x1, x1, #0xffff
    b010:	9b027c21 	mul	x1, x1, x2
    b014:	d360fc21 	lsr	x1, x1, #32
    b018:	eb00003f 	cmp	x1, x0
    b01c:	540000e2 	b.cs	b038 <f0+0x1788>  // b.hs, b.nlast
    b020:	8b0102f7 	add	x23, x23, x1
    b024:	394002e0 	ldrb	w0, [x23]
    b028:	7103fc1f 	cmp	w0, #0xff
    b02c:	540072c0 	b.eq	be84 <f0+0x25d4>  // b.none
    b030:	52800020 	mov	w0, #0x1                   	// #1
    b034:	390002e0 	strb	w0, [x23]
    b038:	911863e1 	add	x1, sp, #0x618
    b03c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b040:	52800020 	mov	w0, #0x1                   	// #1
    b044:	f9030ff7 	str	x23, [sp, #1560]
    b048:	f90313f5 	str	x21, [sp, #1568]
    b04c:	97ffe74e 	bl	4d84 <fwp_data.part.0.constprop.0>
    b050:	97ffe8d9 	bl	53b4 <fwp_rc_fresh>
    b054:	aa0003e2 	mov	x2, x0
    b058:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b05c:	9118a3e1 	add	x1, sp, #0x628
    b060:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b064:	52800020 	mov	w0, #0x1                   	// #1
    b068:	f90317e3 	str	x3, [sp, #1576]
    b06c:	f9031be2 	str	x2, [sp, #1584]
    b070:	97ffe745 	bl	4d84 <fwp_data.part.0.constprop.0>
    b074:	97ffe8d0 	bl	53b4 <fwp_rc_fresh>
    b078:	aa0003e2 	mov	x2, x0
    b07c:	9118e3e1 	add	x1, sp, #0x638
    b080:	52800020 	mov	w0, #0x1                   	// #1
    b084:	f9031ff7 	str	x23, [sp, #1592]
    b088:	f90323e2 	str	x2, [sp, #1600]
    b08c:	97ffe73e 	bl	4d84 <fwp_data.part.0.constprop.0>
    b090:	91150283 	add	x3, x20, #0x540
    b094:	aa0003f5 	mov	x21, x0
    b098:	f949d861 	ldr	x1, [x3, #5040]
    b09c:	f949ec60 	ldr	x0, [x3, #5080]
    b0a0:	cb0102a1 	sub	x1, x21, x1
    b0a4:	eb00403f 	cmp	x1, x0, lsl #16
    b0a8:	54000322 	b.cs	b10c <f0+0x185c>  // b.hs, b.nlast
    b0ac:	d350fc22 	lsr	x2, x1, #16
    b0b0:	f949fc63 	ldr	x3, [x3, #5112]
    b0b4:	8b020842 	add	x2, x2, x2, lsl #2
    b0b8:	d37df042 	lsl	x2, x2, #3
    b0bc:	8b020060 	add	x0, x3, x2
    b0c0:	f9401017 	ldr	x23, [x0, #32]
    b0c4:	b4000257 	cbz	x23, b10c <f0+0x185c>
    b0c8:	38626862 	ldrb	w2, [x3, x2]
    b0cc:	7100085f 	cmp	w2, #0x2
    b0d0:	54006320 	b.eq	bd34 <f0+0x2484>  // b.none
    b0d4:	7100045f 	cmp	w2, #0x1
    b0d8:	540001a1 	b.ne	b10c <f0+0x185c>  // b.any
    b0dc:	29430002 	ldp	w2, w0, [x0, #24]
    b0e0:	92403c21 	and	x1, x1, #0xffff
    b0e4:	9b027c21 	mul	x1, x1, x2
    b0e8:	d360fc21 	lsr	x1, x1, #32
    b0ec:	eb00003f 	cmp	x1, x0
    b0f0:	540000e2 	b.cs	b10c <f0+0x185c>  // b.hs, b.nlast
    b0f4:	8b0102f7 	add	x23, x23, x1
    b0f8:	394002e0 	ldrb	w0, [x23]
    b0fc:	7103fc1f 	cmp	w0, #0xff
    b100:	54006c80 	b.eq	be90 <f0+0x25e0>  // b.none
    b104:	52800020 	mov	w0, #0x1                   	// #1
    b108:	390002e0 	strb	w0, [x23]
    b10c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b110:	911923e1 	add	x1, sp, #0x648
    b114:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b118:	52800020 	mov	w0, #0x1                   	// #1
    b11c:	f90327e2 	str	x2, [sp, #1608]
    b120:	f9032bf5 	str	x21, [sp, #1616]
    b124:	97ffe718 	bl	4d84 <fwp_data.part.0.constprop.0>
    b128:	91150283 	add	x3, x20, #0x540
    b12c:	aa0003f5 	mov	x21, x0
    b130:	f949d861 	ldr	x1, [x3, #5040]
    b134:	f949ec60 	ldr	x0, [x3, #5080]
    b138:	cb0102a1 	sub	x1, x21, x1
    b13c:	eb00403f 	cmp	x1, x0, lsl #16
    b140:	54000322 	b.cs	b1a4 <f0+0x18f4>  // b.hs, b.nlast
    b144:	d350fc22 	lsr	x2, x1, #16
    b148:	f949fc63 	ldr	x3, [x3, #5112]
    b14c:	8b020842 	add	x2, x2, x2, lsl #2
    b150:	d37df042 	lsl	x2, x2, #3
    b154:	8b020060 	add	x0, x3, x2
    b158:	f9401017 	ldr	x23, [x0, #32]
    b15c:	b4000257 	cbz	x23, b1a4 <f0+0x18f4>
    b160:	38626862 	ldrb	w2, [x3, x2]
    b164:	7100085f 	cmp	w2, #0x2
    b168:	54005e00 	b.eq	bd28 <f0+0x2478>  // b.none
    b16c:	7100045f 	cmp	w2, #0x1
    b170:	540001a1 	b.ne	b1a4 <f0+0x18f4>  // b.any
    b174:	29430002 	ldp	w2, w0, [x0, #24]
    b178:	92403c21 	and	x1, x1, #0xffff
    b17c:	9b027c21 	mul	x1, x1, x2
    b180:	d360fc21 	lsr	x1, x1, #32
    b184:	eb00003f 	cmp	x1, x0
    b188:	540000e2 	b.cs	b1a4 <f0+0x18f4>  // b.hs, b.nlast
    b18c:	8b0102f7 	add	x23, x23, x1
    b190:	394002e0 	ldrb	w0, [x23]
    b194:	7103fc1f 	cmp	w0, #0xff
    b198:	54006820 	b.eq	be9c <f0+0x25ec>  // b.none
    b19c:	52800020 	mov	w0, #0x1                   	// #1
    b1a0:	390002e0 	strb	w0, [x23]
    b1a4:	911963e1 	add	x1, sp, #0x658
    b1a8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b1ac:	52800020 	mov	w0, #0x1                   	// #1
    b1b0:	f9032ff7 	str	x23, [sp, #1624]
    b1b4:	f90333f5 	str	x21, [sp, #1632]
    b1b8:	97ffe6f3 	bl	4d84 <fwp_data.part.0.constprop.0>
    b1bc:	97ffe87e 	bl	53b4 <fwp_rc_fresh>
    b1c0:	aa0003e2 	mov	x2, x0
    b1c4:	9119a3e1 	add	x1, sp, #0x668
    b1c8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b1cc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b1d0:	52800020 	mov	w0, #0x1                   	// #1
    b1d4:	f90337f5 	str	x21, [sp, #1640]
    b1d8:	f9033be2 	str	x2, [sp, #1648]
    b1dc:	97ffe6ea 	bl	4d84 <fwp_data.part.0.constprop.0>
    b1e0:	97ffe875 	bl	53b4 <fwp_rc_fresh>
    b1e4:	aa0003e2 	mov	x2, x0
    b1e8:	9119e3e1 	add	x1, sp, #0x678
    b1ec:	52800020 	mov	w0, #0x1                   	// #1
    b1f0:	f9033ff7 	str	x23, [sp, #1656]
    b1f4:	f90343e2 	str	x2, [sp, #1664]
    b1f8:	97ffe6e3 	bl	4d84 <fwp_data.part.0.constprop.0>
    b1fc:	97ffe86e 	bl	53b4 <fwp_rc_fresh>
    b200:	aa0003e2 	mov	x2, x0
    b204:	911a23e1 	add	x1, sp, #0x688
    b208:	52800020 	mov	w0, #0x1                   	// #1
    b20c:	f90347f5 	str	x21, [sp, #1672]
    b210:	f9034be2 	str	x2, [sp, #1680]
    b214:	97ffe6dc 	bl	4d84 <fwp_data.part.0.constprop.0>
    b218:	91150283 	add	x3, x20, #0x540
    b21c:	aa0003f5 	mov	x21, x0
    b220:	f949d861 	ldr	x1, [x3, #5040]
    b224:	f949ec60 	ldr	x0, [x3, #5080]
    b228:	cb0102a1 	sub	x1, x21, x1
    b22c:	eb00403f 	cmp	x1, x0, lsl #16
    b230:	54000322 	b.cs	b294 <f0+0x19e4>  // b.hs, b.nlast
    b234:	d350fc22 	lsr	x2, x1, #16
    b238:	f949fc63 	ldr	x3, [x3, #5112]
    b23c:	8b020842 	add	x2, x2, x2, lsl #2
    b240:	d37df042 	lsl	x2, x2, #3
    b244:	8b020060 	add	x0, x3, x2
    b248:	f9401017 	ldr	x23, [x0, #32]
    b24c:	b4000257 	cbz	x23, b294 <f0+0x19e4>
    b250:	38626862 	ldrb	w2, [x3, x2]
    b254:	7100085f 	cmp	w2, #0x2
    b258:	54005620 	b.eq	bd1c <f0+0x246c>  // b.none
    b25c:	7100045f 	cmp	w2, #0x1
    b260:	540001a1 	b.ne	b294 <f0+0x19e4>  // b.any
    b264:	29430002 	ldp	w2, w0, [x0, #24]
    b268:	92403c21 	and	x1, x1, #0xffff
    b26c:	9b027c21 	mul	x1, x1, x2
    b270:	d360fc21 	lsr	x1, x1, #32
    b274:	eb00003f 	cmp	x1, x0
    b278:	540000e2 	b.cs	b294 <f0+0x19e4>  // b.hs, b.nlast
    b27c:	8b0102f7 	add	x23, x23, x1
    b280:	394002e0 	ldrb	w0, [x23]
    b284:	7103fc1f 	cmp	w0, #0xff
    b288:	54006100 	b.eq	bea8 <f0+0x25f8>  // b.none
    b28c:	52800020 	mov	w0, #0x1                   	// #1
    b290:	390002e0 	strb	w0, [x23]
    b294:	911a63e1 	add	x1, sp, #0x698
    b298:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b29c:	52800020 	mov	w0, #0x1                   	// #1
    b2a0:	f9034fe2 	str	x2, [sp, #1688]
    b2a4:	f90353f5 	str	x21, [sp, #1696]
    b2a8:	97ffe6b7 	bl	4d84 <fwp_data.part.0.constprop.0>
    b2ac:	97ffe842 	bl	53b4 <fwp_rc_fresh>
    b2b0:	aa0003e2 	mov	x2, x0
    b2b4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b2b8:	911aa3e1 	add	x1, sp, #0x6a8
    b2bc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b2c0:	52800020 	mov	w0, #0x1                   	// #1
    b2c4:	f90357e3 	str	x3, [sp, #1704]
    b2c8:	f9035be2 	str	x2, [sp, #1712]
    b2cc:	97ffe6ae 	bl	4d84 <fwp_data.part.0.constprop.0>
    b2d0:	91150283 	add	x3, x20, #0x540
    b2d4:	aa0003f5 	mov	x21, x0
    b2d8:	f949d861 	ldr	x1, [x3, #5040]
    b2dc:	f949ec60 	ldr	x0, [x3, #5080]
    b2e0:	cb0102a1 	sub	x1, x21, x1
    b2e4:	eb00403f 	cmp	x1, x0, lsl #16
    b2e8:	54000322 	b.cs	b34c <f0+0x1a9c>  // b.hs, b.nlast
    b2ec:	d350fc22 	lsr	x2, x1, #16
    b2f0:	f949fc63 	ldr	x3, [x3, #5112]
    b2f4:	8b020842 	add	x2, x2, x2, lsl #2
    b2f8:	d37df042 	lsl	x2, x2, #3
    b2fc:	8b020060 	add	x0, x3, x2
    b300:	f9401017 	ldr	x23, [x0, #32]
    b304:	b4000257 	cbz	x23, b34c <f0+0x1a9c>
    b308:	38626862 	ldrb	w2, [x3, x2]
    b30c:	7100085f 	cmp	w2, #0x2
    b310:	54005000 	b.eq	bd10 <f0+0x2460>  // b.none
    b314:	7100045f 	cmp	w2, #0x1
    b318:	540001a1 	b.ne	b34c <f0+0x1a9c>  // b.any
    b31c:	29430002 	ldp	w2, w0, [x0, #24]
    b320:	92403c21 	and	x1, x1, #0xffff
    b324:	9b027c21 	mul	x1, x1, x2
    b328:	d360fc21 	lsr	x1, x1, #32
    b32c:	eb00003f 	cmp	x1, x0
    b330:	540000e2 	b.cs	b34c <f0+0x1a9c>  // b.hs, b.nlast
    b334:	8b0102f7 	add	x23, x23, x1
    b338:	394002e0 	ldrb	w0, [x23]
    b33c:	7103fc1f 	cmp	w0, #0xff
    b340:	54005ba0 	b.eq	beb4 <f0+0x2604>  // b.none
    b344:	52800020 	mov	w0, #0x1                   	// #1
    b348:	390002e0 	strb	w0, [x23]
    b34c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b350:	911ae3e1 	add	x1, sp, #0x6b8
    b354:	52800020 	mov	w0, #0x1                   	// #1
    b358:	f9035fe2 	str	x2, [sp, #1720]
    b35c:	f90363f5 	str	x21, [sp, #1728]
    b360:	97ffe689 	bl	4d84 <fwp_data.part.0.constprop.0>
    b364:	91150283 	add	x3, x20, #0x540
    b368:	aa0003f5 	mov	x21, x0
    b36c:	f949d861 	ldr	x1, [x3, #5040]
    b370:	f949ec60 	ldr	x0, [x3, #5080]
    b374:	cb0102a1 	sub	x1, x21, x1
    b378:	eb00403f 	cmp	x1, x0, lsl #16
    b37c:	54000322 	b.cs	b3e0 <f0+0x1b30>  // b.hs, b.nlast
    b380:	d350fc22 	lsr	x2, x1, #16
    b384:	f949fc63 	ldr	x3, [x3, #5112]
    b388:	8b020842 	add	x2, x2, x2, lsl #2
    b38c:	d37df042 	lsl	x2, x2, #3
    b390:	8b020060 	add	x0, x3, x2
    b394:	f9401017 	ldr	x23, [x0, #32]
    b398:	b4000257 	cbz	x23, b3e0 <f0+0x1b30>
    b39c:	38626862 	ldrb	w2, [x3, x2]
    b3a0:	7100085f 	cmp	w2, #0x2
    b3a4:	54004b00 	b.eq	bd04 <f0+0x2454>  // b.none
    b3a8:	7100045f 	cmp	w2, #0x1
    b3ac:	540001a1 	b.ne	b3e0 <f0+0x1b30>  // b.any
    b3b0:	29430002 	ldp	w2, w0, [x0, #24]
    b3b4:	92403c21 	and	x1, x1, #0xffff
    b3b8:	9b027c21 	mul	x1, x1, x2
    b3bc:	d360fc21 	lsr	x1, x1, #32
    b3c0:	eb00003f 	cmp	x1, x0
    b3c4:	540000e2 	b.cs	b3e0 <f0+0x1b30>  // b.hs, b.nlast
    b3c8:	8b0102f7 	add	x23, x23, x1
    b3cc:	394002e0 	ldrb	w0, [x23]
    b3d0:	7103fc1f 	cmp	w0, #0xff
    b3d4:	54005760 	b.eq	bec0 <f0+0x2610>  // b.none
    b3d8:	52800020 	mov	w0, #0x1                   	// #1
    b3dc:	390002e0 	strb	w0, [x23]
    b3e0:	911b23e1 	add	x1, sp, #0x6c8
    b3e4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b3e8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b3ec:	52800020 	mov	w0, #0x1                   	// #1
    b3f0:	f90367f7 	str	x23, [sp, #1736]
    b3f4:	f9036bf5 	str	x21, [sp, #1744]
    b3f8:	97ffe663 	bl	4d84 <fwp_data.part.0.constprop.0>
    b3fc:	97ffe7ee 	bl	53b4 <fwp_rc_fresh>
    b400:	aa0003e2 	mov	x2, x0
    b404:	911b63e1 	add	x1, sp, #0x6d8
    b408:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b40c:	52800020 	mov	w0, #0x1                   	// #1
    b410:	f9036ff5 	str	x21, [sp, #1752]
    b414:	f90373e2 	str	x2, [sp, #1760]
    b418:	97ffe65b 	bl	4d84 <fwp_data.part.0.constprop.0>
    b41c:	97ffe7e6 	bl	53b4 <fwp_rc_fresh>
    b420:	aa0003e2 	mov	x2, x0
    b424:	911ba3e1 	add	x1, sp, #0x6e8
    b428:	52800020 	mov	w0, #0x1                   	// #1
    b42c:	f90377f7 	str	x23, [sp, #1768]
    b430:	f9037be2 	str	x2, [sp, #1776]
    b434:	97ffe654 	bl	4d84 <fwp_data.part.0.constprop.0>
    b438:	97ffe7df 	bl	53b4 <fwp_rc_fresh>
    b43c:	aa0003e2 	mov	x2, x0
    b440:	911be3e1 	add	x1, sp, #0x6f8
    b444:	52800020 	mov	w0, #0x1                   	// #1
    b448:	f9037ff5 	str	x21, [sp, #1784]
    b44c:	f90383e2 	str	x2, [sp, #1792]
    b450:	97ffe64d 	bl	4d84 <fwp_data.part.0.constprop.0>
    b454:	97ffe7d8 	bl	53b4 <fwp_rc_fresh>
    b458:	aa0003e2 	mov	x2, x0
    b45c:	911c23e1 	add	x1, sp, #0x708
    b460:	52800020 	mov	w0, #0x1                   	// #1
    b464:	f90387f7 	str	x23, [sp, #1800]
    b468:	f9038be2 	str	x2, [sp, #1808]
    b46c:	97ffe646 	bl	4d84 <fwp_data.part.0.constprop.0>
    b470:	97ffe7d1 	bl	53b4 <fwp_rc_fresh>
    b474:	aa0003e2 	mov	x2, x0
    b478:	911c63e1 	add	x1, sp, #0x718
    b47c:	52800020 	mov	w0, #0x1                   	// #1
    b480:	f9038ff5 	str	x21, [sp, #1816]
    b484:	f90393e2 	str	x2, [sp, #1824]
    b488:	97ffe63f 	bl	4d84 <fwp_data.part.0.constprop.0>
    b48c:	97ffe7ca 	bl	53b4 <fwp_rc_fresh>
    b490:	aa0003e2 	mov	x2, x0
    b494:	911ca3e1 	add	x1, sp, #0x728
    b498:	52800020 	mov	w0, #0x1                   	// #1
    b49c:	f90397f7 	str	x23, [sp, #1832]
    b4a0:	f9039be2 	str	x2, [sp, #1840]
    b4a4:	97ffe638 	bl	4d84 <fwp_data.part.0.constprop.0>
    b4a8:	97ffe7c3 	bl	53b4 <fwp_rc_fresh>
    b4ac:	aa0003e2 	mov	x2, x0
    b4b0:	911ce3e1 	add	x1, sp, #0x738
    b4b4:	52800020 	mov	w0, #0x1                   	// #1
    b4b8:	f9039ff5 	str	x21, [sp, #1848]
    b4bc:	f903a3e2 	str	x2, [sp, #1856]
    b4c0:	97ffe631 	bl	4d84 <fwp_data.part.0.constprop.0>
    b4c4:	91150283 	add	x3, x20, #0x540
    b4c8:	aa0003f5 	mov	x21, x0
    b4cc:	f949d861 	ldr	x1, [x3, #5040]
    b4d0:	f949ec60 	ldr	x0, [x3, #5080]
    b4d4:	cb0102a1 	sub	x1, x21, x1
    b4d8:	eb00403f 	cmp	x1, x0, lsl #16
    b4dc:	54000322 	b.cs	b540 <f0+0x1c90>  // b.hs, b.nlast
    b4e0:	d350fc22 	lsr	x2, x1, #16
    b4e4:	f949fc63 	ldr	x3, [x3, #5112]
    b4e8:	8b020842 	add	x2, x2, x2, lsl #2
    b4ec:	d37df042 	lsl	x2, x2, #3
    b4f0:	8b020060 	add	x0, x3, x2
    b4f4:	f9401017 	ldr	x23, [x0, #32]
    b4f8:	b4000257 	cbz	x23, b540 <f0+0x1c90>
    b4fc:	38626862 	ldrb	w2, [x3, x2]
    b500:	7100085f 	cmp	w2, #0x2
    b504:	54003fa0 	b.eq	bcf8 <f0+0x2448>  // b.none
    b508:	7100045f 	cmp	w2, #0x1
    b50c:	540001a1 	b.ne	b540 <f0+0x1c90>  // b.any
    b510:	29430002 	ldp	w2, w0, [x0, #24]
    b514:	92403c21 	and	x1, x1, #0xffff
    b518:	9b027c21 	mul	x1, x1, x2
    b51c:	d360fc21 	lsr	x1, x1, #32
    b520:	eb00003f 	cmp	x1, x0
    b524:	540000e2 	b.cs	b540 <f0+0x1c90>  // b.hs, b.nlast
    b528:	8b0102f7 	add	x23, x23, x1
    b52c:	394002e0 	ldrb	w0, [x23]
    b530:	7103fc1f 	cmp	w0, #0xff
    b534:	54004cc0 	b.eq	becc <f0+0x261c>  // b.none
    b538:	52800020 	mov	w0, #0x1                   	// #1
    b53c:	390002e0 	strb	w0, [x23]
    b540:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b544:	911d23e1 	add	x1, sp, #0x748
    b548:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b54c:	52800020 	mov	w0, #0x1                   	// #1
    b550:	f903a7e2 	str	x2, [sp, #1864]
    b554:	f903abf5 	str	x21, [sp, #1872]
    b558:	97ffe60b 	bl	4d84 <fwp_data.part.0.constprop.0>
    b55c:	91150283 	add	x3, x20, #0x540
    b560:	aa0003f5 	mov	x21, x0
    b564:	f949d861 	ldr	x1, [x3, #5040]
    b568:	f949ec60 	ldr	x0, [x3, #5080]
    b56c:	cb0102a1 	sub	x1, x21, x1
    b570:	eb00403f 	cmp	x1, x0, lsl #16
    b574:	54000322 	b.cs	b5d8 <f0+0x1d28>  // b.hs, b.nlast
    b578:	d350fc22 	lsr	x2, x1, #16
    b57c:	f949fc63 	ldr	x3, [x3, #5112]
    b580:	8b020842 	add	x2, x2, x2, lsl #2
    b584:	d37df042 	lsl	x2, x2, #3
    b588:	8b020060 	add	x0, x3, x2
    b58c:	f9401017 	ldr	x23, [x0, #32]
    b590:	b4000257 	cbz	x23, b5d8 <f0+0x1d28>
    b594:	38626862 	ldrb	w2, [x3, x2]
    b598:	7100085f 	cmp	w2, #0x2
    b59c:	54003a80 	b.eq	bcec <f0+0x243c>  // b.none
    b5a0:	7100045f 	cmp	w2, #0x1
    b5a4:	540001a1 	b.ne	b5d8 <f0+0x1d28>  // b.any
    b5a8:	29430002 	ldp	w2, w0, [x0, #24]
    b5ac:	92403c21 	and	x1, x1, #0xffff
    b5b0:	9b027c21 	mul	x1, x1, x2
    b5b4:	d360fc21 	lsr	x1, x1, #32
    b5b8:	eb00003f 	cmp	x1, x0
    b5bc:	540000e2 	b.cs	b5d8 <f0+0x1d28>  // b.hs, b.nlast
    b5c0:	8b0102f7 	add	x23, x23, x1
    b5c4:	394002e0 	ldrb	w0, [x23]
    b5c8:	7103fc1f 	cmp	w0, #0xff
    b5cc:	54004860 	b.eq	bed8 <f0+0x2628>  // b.none
    b5d0:	52800020 	mov	w0, #0x1                   	// #1
    b5d4:	390002e0 	strb	w0, [x23]
    b5d8:	911d63e1 	add	x1, sp, #0x758
    b5dc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b5e0:	52800020 	mov	w0, #0x1                   	// #1
    b5e4:	f903aff7 	str	x23, [sp, #1880]
    b5e8:	f903b3f5 	str	x21, [sp, #1888]
    b5ec:	97ffe5e6 	bl	4d84 <fwp_data.part.0.constprop.0>
    b5f0:	97ffe771 	bl	53b4 <fwp_rc_fresh>
    b5f4:	aa0003e2 	mov	x2, x0
    b5f8:	911da3e1 	add	x1, sp, #0x768
    b5fc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b600:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b604:	52800020 	mov	w0, #0x1                   	// #1
    b608:	f903b7f5 	str	x21, [sp, #1896]
    b60c:	f903bbe2 	str	x2, [sp, #1904]
    b610:	97ffe5dd 	bl	4d84 <fwp_data.part.0.constprop.0>
    b614:	97ffe768 	bl	53b4 <fwp_rc_fresh>
    b618:	aa0003e2 	mov	x2, x0
    b61c:	911de3e1 	add	x1, sp, #0x778
    b620:	52800020 	mov	w0, #0x1                   	// #1
    b624:	f903bff7 	str	x23, [sp, #1912]
    b628:	f903c3e2 	str	x2, [sp, #1920]
    b62c:	97ffe5d6 	bl	4d84 <fwp_data.part.0.constprop.0>
    b630:	97ffe761 	bl	53b4 <fwp_rc_fresh>
    b634:	aa0003e2 	mov	x2, x0
    b638:	911e23e1 	add	x1, sp, #0x788
    b63c:	52800020 	mov	w0, #0x1                   	// #1
    b640:	f903c7f5 	str	x21, [sp, #1928]
    b644:	f903cbe2 	str	x2, [sp, #1936]
    b648:	97ffe5cf 	bl	4d84 <fwp_data.part.0.constprop.0>
    b64c:	91150283 	add	x3, x20, #0x540
    b650:	aa0003f5 	mov	x21, x0
    b654:	f949d861 	ldr	x1, [x3, #5040]
    b658:	f949ec60 	ldr	x0, [x3, #5080]
    b65c:	cb0102a1 	sub	x1, x21, x1
    b660:	eb00403f 	cmp	x1, x0, lsl #16
    b664:	54000322 	b.cs	b6c8 <f0+0x1e18>  // b.hs, b.nlast
    b668:	d350fc22 	lsr	x2, x1, #16
    b66c:	f949fc63 	ldr	x3, [x3, #5112]
    b670:	8b020842 	add	x2, x2, x2, lsl #2
    b674:	d37df042 	lsl	x2, x2, #3
    b678:	8b020060 	add	x0, x3, x2
    b67c:	f9401017 	ldr	x23, [x0, #32]
    b680:	b4000257 	cbz	x23, b6c8 <f0+0x1e18>
    b684:	38626862 	ldrb	w2, [x3, x2]
    b688:	7100085f 	cmp	w2, #0x2
    b68c:	540032a0 	b.eq	bce0 <f0+0x2430>  // b.none
    b690:	7100045f 	cmp	w2, #0x1
    b694:	540001a1 	b.ne	b6c8 <f0+0x1e18>  // b.any
    b698:	29430002 	ldp	w2, w0, [x0, #24]
    b69c:	92403c21 	and	x1, x1, #0xffff
    b6a0:	9b027c21 	mul	x1, x1, x2
    b6a4:	d360fc21 	lsr	x1, x1, #32
    b6a8:	eb00003f 	cmp	x1, x0
    b6ac:	540000e2 	b.cs	b6c8 <f0+0x1e18>  // b.hs, b.nlast
    b6b0:	8b0102f7 	add	x23, x23, x1
    b6b4:	394002e0 	ldrb	w0, [x23]
    b6b8:	7103fc1f 	cmp	w0, #0xff
    b6bc:	54004140 	b.eq	bee4 <f0+0x2634>  // b.none
    b6c0:	52800020 	mov	w0, #0x1                   	// #1
    b6c4:	390002e0 	strb	w0, [x23]
    b6c8:	911e63e1 	add	x1, sp, #0x798
    b6cc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b6d0:	52800020 	mov	w0, #0x1                   	// #1
    b6d4:	f903cfe2 	str	x2, [sp, #1944]
    b6d8:	f903d3f5 	str	x21, [sp, #1952]
    b6dc:	97ffe5aa 	bl	4d84 <fwp_data.part.0.constprop.0>
    b6e0:	97ffe735 	bl	53b4 <fwp_rc_fresh>
    b6e4:	aa0003e2 	mov	x2, x0
    b6e8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b6ec:	911ea3e1 	add	x1, sp, #0x7a8
    b6f0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b6f4:	52800020 	mov	w0, #0x1                   	// #1
    b6f8:	f903d7e3 	str	x3, [sp, #1960]
    b6fc:	f903dbe2 	str	x2, [sp, #1968]
    b700:	97ffe5a1 	bl	4d84 <fwp_data.part.0.constprop.0>
    b704:	91150283 	add	x3, x20, #0x540
    b708:	aa0003f5 	mov	x21, x0
    b70c:	f949d861 	ldr	x1, [x3, #5040]
    b710:	f949ec60 	ldr	x0, [x3, #5080]
    b714:	cb0102a1 	sub	x1, x21, x1
    b718:	eb00403f 	cmp	x1, x0, lsl #16
    b71c:	54000322 	b.cs	b780 <f0+0x1ed0>  // b.hs, b.nlast
    b720:	d350fc22 	lsr	x2, x1, #16
    b724:	f949fc63 	ldr	x3, [x3, #5112]
    b728:	8b020842 	add	x2, x2, x2, lsl #2
    b72c:	d37df042 	lsl	x2, x2, #3
    b730:	8b020060 	add	x0, x3, x2
    b734:	f9401017 	ldr	x23, [x0, #32]
    b738:	b4000257 	cbz	x23, b780 <f0+0x1ed0>
    b73c:	38626862 	ldrb	w2, [x3, x2]
    b740:	7100085f 	cmp	w2, #0x2
    b744:	54002c80 	b.eq	bcd4 <f0+0x2424>  // b.none
    b748:	7100045f 	cmp	w2, #0x1
    b74c:	540001a1 	b.ne	b780 <f0+0x1ed0>  // b.any
    b750:	29430002 	ldp	w2, w0, [x0, #24]
    b754:	92403c21 	and	x1, x1, #0xffff
    b758:	9b027c21 	mul	x1, x1, x2
    b75c:	d360fc21 	lsr	x1, x1, #32
    b760:	eb00003f 	cmp	x1, x0
    b764:	540000e2 	b.cs	b780 <f0+0x1ed0>  // b.hs, b.nlast
    b768:	8b0102f7 	add	x23, x23, x1
    b76c:	394002e0 	ldrb	w0, [x23]
    b770:	7103fc1f 	cmp	w0, #0xff
    b774:	54003be0 	b.eq	bef0 <f0+0x2640>  // b.none
    b778:	52800020 	mov	w0, #0x1                   	// #1
    b77c:	390002e0 	strb	w0, [x23]
    b780:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b784:	911ee3e1 	add	x1, sp, #0x7b8
    b788:	52800020 	mov	w0, #0x1                   	// #1
    b78c:	f903dfe2 	str	x2, [sp, #1976]
    b790:	f903e3f5 	str	x21, [sp, #1984]
    b794:	97ffe57c 	bl	4d84 <fwp_data.part.0.constprop.0>
    b798:	91150283 	add	x3, x20, #0x540
    b79c:	aa0003f5 	mov	x21, x0
    b7a0:	f949d861 	ldr	x1, [x3, #5040]
    b7a4:	f949ec60 	ldr	x0, [x3, #5080]
    b7a8:	cb0102a1 	sub	x1, x21, x1
    b7ac:	eb00403f 	cmp	x1, x0, lsl #16
    b7b0:	54000322 	b.cs	b814 <f0+0x1f64>  // b.hs, b.nlast
    b7b4:	d350fc22 	lsr	x2, x1, #16
    b7b8:	f949fc63 	ldr	x3, [x3, #5112]
    b7bc:	8b020842 	add	x2, x2, x2, lsl #2
    b7c0:	d37df042 	lsl	x2, x2, #3
    b7c4:	8b020060 	add	x0, x3, x2
    b7c8:	f9401017 	ldr	x23, [x0, #32]
    b7cc:	b4000257 	cbz	x23, b814 <f0+0x1f64>
    b7d0:	38626862 	ldrb	w2, [x3, x2]
    b7d4:	7100085f 	cmp	w2, #0x2
    b7d8:	54002780 	b.eq	bcc8 <f0+0x2418>  // b.none
    b7dc:	7100045f 	cmp	w2, #0x1
    b7e0:	540001a1 	b.ne	b814 <f0+0x1f64>  // b.any
    b7e4:	29430002 	ldp	w2, w0, [x0, #24]
    b7e8:	92403c21 	and	x1, x1, #0xffff
    b7ec:	9b027c21 	mul	x1, x1, x2
    b7f0:	d360fc21 	lsr	x1, x1, #32
    b7f4:	eb00003f 	cmp	x1, x0
    b7f8:	540000e2 	b.cs	b814 <f0+0x1f64>  // b.hs, b.nlast
    b7fc:	8b0102f7 	add	x23, x23, x1
    b800:	394002e0 	ldrb	w0, [x23]
    b804:	7103fc1f 	cmp	w0, #0xff
    b808:	540037a0 	b.eq	befc <f0+0x264c>  // b.none
    b80c:	52800020 	mov	w0, #0x1                   	// #1
    b810:	390002e0 	strb	w0, [x23]
    b814:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b818:	911f23e1 	add	x1, sp, #0x7c8
    b81c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b820:	52800020 	mov	w0, #0x1                   	// #1
    b824:	f903e7e2 	str	x2, [sp, #1992]
    b828:	f903ebf5 	str	x21, [sp, #2000]
    b82c:	97ffe556 	bl	4d84 <fwp_data.part.0.constprop.0>
    b830:	91150283 	add	x3, x20, #0x540
    b834:	aa0003f5 	mov	x21, x0
    b838:	f949d861 	ldr	x1, [x3, #5040]
    b83c:	f949ec60 	ldr	x0, [x3, #5080]
    b840:	cb0102a1 	sub	x1, x21, x1
    b844:	eb00403f 	cmp	x1, x0, lsl #16
    b848:	54000322 	b.cs	b8ac <f0+0x1ffc>  // b.hs, b.nlast
    b84c:	d350fc22 	lsr	x2, x1, #16
    b850:	f949fc63 	ldr	x3, [x3, #5112]
    b854:	8b020842 	add	x2, x2, x2, lsl #2
    b858:	d37df042 	lsl	x2, x2, #3
    b85c:	8b020060 	add	x0, x3, x2
    b860:	f9401017 	ldr	x23, [x0, #32]
    b864:	b4000257 	cbz	x23, b8ac <f0+0x1ffc>
    b868:	38626862 	ldrb	w2, [x3, x2]
    b86c:	7100085f 	cmp	w2, #0x2
    b870:	54002260 	b.eq	bcbc <f0+0x240c>  // b.none
    b874:	7100045f 	cmp	w2, #0x1
    b878:	540001a1 	b.ne	b8ac <f0+0x1ffc>  // b.any
    b87c:	29430002 	ldp	w2, w0, [x0, #24]
    b880:	92403c21 	and	x1, x1, #0xffff
    b884:	9b027c21 	mul	x1, x1, x2
    b888:	d360fc21 	lsr	x1, x1, #32
    b88c:	eb00003f 	cmp	x1, x0
    b890:	540000e2 	b.cs	b8ac <f0+0x1ffc>  // b.hs, b.nlast
    b894:	8b0102f7 	add	x23, x23, x1
    b898:	394002e0 	ldrb	w0, [x23]
    b89c:	7103fc1f 	cmp	w0, #0xff
    b8a0:	54003340 	b.eq	bf08 <f0+0x2658>  // b.none
    b8a4:	52800020 	mov	w0, #0x1                   	// #1
    b8a8:	390002e0 	strb	w0, [x23]
    b8ac:	911f63e1 	add	x1, sp, #0x7d8
    b8b0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b8b4:	52800020 	mov	w0, #0x1                   	// #1
    b8b8:	f903eff7 	str	x23, [sp, #2008]
    b8bc:	f903f3f5 	str	x21, [sp, #2016]
    b8c0:	97ffe531 	bl	4d84 <fwp_data.part.0.constprop.0>
    b8c4:	97ffe6bc 	bl	53b4 <fwp_rc_fresh>
    b8c8:	aa0003e2 	mov	x2, x0
    b8cc:	911fa3e1 	add	x1, sp, #0x7e8
    b8d0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b8d4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b8d8:	52800020 	mov	w0, #0x1                   	// #1
    b8dc:	f903f7f5 	str	x21, [sp, #2024]
    b8e0:	f903fbe2 	str	x2, [sp, #2032]
    b8e4:	97ffe528 	bl	4d84 <fwp_data.part.0.constprop.0>
    b8e8:	97ffe6b3 	bl	53b4 <fwp_rc_fresh>
    b8ec:	aa0003e2 	mov	x2, x0
    b8f0:	911fe3e1 	add	x1, sp, #0x7f8
    b8f4:	52800020 	mov	w0, #0x1                   	// #1
    b8f8:	f903fff7 	str	x23, [sp, #2040]
    b8fc:	f90403e2 	str	x2, [sp, #2048]
    b900:	97ffe521 	bl	4d84 <fwp_data.part.0.constprop.0>
    b904:	97ffe6ac 	bl	53b4 <fwp_rc_fresh>
    b908:	aa0003e2 	mov	x2, x0
    b90c:	912023e1 	add	x1, sp, #0x808
    b910:	52800020 	mov	w0, #0x1                   	// #1
    b914:	f90407f5 	str	x21, [sp, #2056]
    b918:	f9040be2 	str	x2, [sp, #2064]
    b91c:	97ffe51a 	bl	4d84 <fwp_data.part.0.constprop.0>
    b920:	91150283 	add	x3, x20, #0x540
    b924:	aa0003f5 	mov	x21, x0
    b928:	f949d861 	ldr	x1, [x3, #5040]
    b92c:	f949ec60 	ldr	x0, [x3, #5080]
    b930:	cb0102a1 	sub	x1, x21, x1
    b934:	eb00403f 	cmp	x1, x0, lsl #16
    b938:	54000322 	b.cs	b99c <f0+0x20ec>  // b.hs, b.nlast
    b93c:	d350fc22 	lsr	x2, x1, #16
    b940:	f949fc63 	ldr	x3, [x3, #5112]
    b944:	8b020842 	add	x2, x2, x2, lsl #2
    b948:	d37df042 	lsl	x2, x2, #3
    b94c:	8b020060 	add	x0, x3, x2
    b950:	f9401017 	ldr	x23, [x0, #32]
    b954:	b4000257 	cbz	x23, b99c <f0+0x20ec>
    b958:	38626862 	ldrb	w2, [x3, x2]
    b95c:	7100085f 	cmp	w2, #0x2
    b960:	54001a80 	b.eq	bcb0 <f0+0x2400>  // b.none
    b964:	7100045f 	cmp	w2, #0x1
    b968:	540001a1 	b.ne	b99c <f0+0x20ec>  // b.any
    b96c:	29430002 	ldp	w2, w0, [x0, #24]
    b970:	92403c21 	and	x1, x1, #0xffff
    b974:	9b027c21 	mul	x1, x1, x2
    b978:	d360fc21 	lsr	x1, x1, #32
    b97c:	eb00003f 	cmp	x1, x0
    b980:	540000e2 	b.cs	b99c <f0+0x20ec>  // b.hs, b.nlast
    b984:	8b0102f7 	add	x23, x23, x1
    b988:	394002e0 	ldrb	w0, [x23]
    b98c:	7103fc1f 	cmp	w0, #0xff
    b990:	54002c20 	b.eq	bf14 <f0+0x2664>  // b.none
    b994:	52800020 	mov	w0, #0x1                   	// #1
    b998:	390002e0 	strb	w0, [x23]
    b99c:	912063e1 	add	x1, sp, #0x818
    b9a0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b9a4:	52800020 	mov	w0, #0x1                   	// #1
    b9a8:	f9040fe2 	str	x2, [sp, #2072]
    b9ac:	f90413f5 	str	x21, [sp, #2080]
    b9b0:	97ffe4f5 	bl	4d84 <fwp_data.part.0.constprop.0>
    b9b4:	97ffe680 	bl	53b4 <fwp_rc_fresh>
    b9b8:	aa0003e2 	mov	x2, x0
    b9bc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b9c0:	9120a3e1 	add	x1, sp, #0x828
    b9c4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b9c8:	52800020 	mov	w0, #0x1                   	// #1
    b9cc:	f90417e3 	str	x3, [sp, #2088]
    b9d0:	f9041be2 	str	x2, [sp, #2096]
    b9d4:	97ffe4ec 	bl	4d84 <fwp_data.part.0.constprop.0>
    b9d8:	91150283 	add	x3, x20, #0x540
    b9dc:	aa0003f5 	mov	x21, x0
    b9e0:	f949d861 	ldr	x1, [x3, #5040]
    b9e4:	f949ec60 	ldr	x0, [x3, #5080]
    b9e8:	cb0102a1 	sub	x1, x21, x1
    b9ec:	eb00403f 	cmp	x1, x0, lsl #16
    b9f0:	54000322 	b.cs	ba54 <f0+0x21a4>  // b.hs, b.nlast
    b9f4:	d350fc22 	lsr	x2, x1, #16
    b9f8:	f949fc63 	ldr	x3, [x3, #5112]
    b9fc:	8b020842 	add	x2, x2, x2, lsl #2
    ba00:	d37df042 	lsl	x2, x2, #3
    ba04:	8b020060 	add	x0, x3, x2
    ba08:	f9401017 	ldr	x23, [x0, #32]
    ba0c:	b4000257 	cbz	x23, ba54 <f0+0x21a4>
    ba10:	38626862 	ldrb	w2, [x3, x2]
    ba14:	7100085f 	cmp	w2, #0x2
    ba18:	54001460 	b.eq	bca4 <f0+0x23f4>  // b.none
    ba1c:	7100045f 	cmp	w2, #0x1
    ba20:	540001a1 	b.ne	ba54 <f0+0x21a4>  // b.any
    ba24:	29430002 	ldp	w2, w0, [x0, #24]
    ba28:	92403c21 	and	x1, x1, #0xffff
    ba2c:	9b027c21 	mul	x1, x1, x2
    ba30:	d360fc21 	lsr	x1, x1, #32
    ba34:	eb00003f 	cmp	x1, x0
    ba38:	540000e2 	b.cs	ba54 <f0+0x21a4>  // b.hs, b.nlast
    ba3c:	8b0102f7 	add	x23, x23, x1
    ba40:	394002e0 	ldrb	w0, [x23]
    ba44:	7103fc1f 	cmp	w0, #0xff
    ba48:	540026c0 	b.eq	bf20 <f0+0x2670>  // b.none
    ba4c:	52800020 	mov	w0, #0x1                   	// #1
    ba50:	390002e0 	strb	w0, [x23]
    ba54:	9120e3e1 	add	x1, sp, #0x838
    ba58:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ba5c:	52800020 	mov	w0, #0x1                   	// #1
    ba60:	f9041fe2 	str	x2, [sp, #2104]
    ba64:	f90423f5 	str	x21, [sp, #2112]
    ba68:	97ffe4c7 	bl	4d84 <fwp_data.part.0.constprop.0>
    ba6c:	97ffe652 	bl	53b4 <fwp_rc_fresh>
    ba70:	aa0003e2 	mov	x2, x0
    ba74:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ba78:	91150294 	add	x20, x20, #0x540
    ba7c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ba80:	aa1603e1 	mov	x1, x22
    ba84:	52800020 	mov	w0, #0x1                   	// #1
    ba88:	f90427e3 	str	x3, [sp, #2120]
    ba8c:	f9042be2 	str	x2, [sp, #2128]
    ba90:	97ffe4bd 	bl	4d84 <fwp_data.part.0.constprop.0>
    ba94:	f949da81 	ldr	x1, [x20, #5040]
    ba98:	aa0003f5 	mov	x21, x0
    ba9c:	f949ee80 	ldr	x0, [x20, #5080]
    baa0:	cb0102a1 	sub	x1, x21, x1
    baa4:	eb00403f 	cmp	x1, x0, lsl #16
    baa8:	54000322 	b.cs	bb0c <f0+0x225c>  // b.hs, b.nlast
    baac:	d350fc22 	lsr	x2, x1, #16
    bab0:	f949fe83 	ldr	x3, [x20, #5112]
    bab4:	8b020842 	add	x2, x2, x2, lsl #2
    bab8:	d37df042 	lsl	x2, x2, #3
    babc:	8b020060 	add	x0, x3, x2
    bac0:	f9401014 	ldr	x20, [x0, #32]
    bac4:	b4000254 	cbz	x20, bb0c <f0+0x225c>
    bac8:	38626862 	ldrb	w2, [x3, x2]
    bacc:	7100085f 	cmp	w2, #0x2
    bad0:	54000e40 	b.eq	bc98 <f0+0x23e8>  // b.none
    bad4:	7100045f 	cmp	w2, #0x1
    bad8:	540001a1 	b.ne	bb0c <f0+0x225c>  // b.any
    badc:	29430002 	ldp	w2, w0, [x0, #24]
    bae0:	92403c21 	and	x1, x1, #0xffff
    bae4:	9b027c21 	mul	x1, x1, x2
    bae8:	d360fc21 	lsr	x1, x1, #32
    baec:	eb00003f 	cmp	x1, x0
    baf0:	540000e2 	b.cs	bb0c <f0+0x225c>  // b.hs, b.nlast
    baf4:	8b010294 	add	x20, x20, x1
    baf8:	39400280 	ldrb	w0, [x20]
    bafc:	7103fc1f 	cmp	w0, #0xff
    bb00:	540012c0 	b.eq	bd58 <f0+0x24a8>  // b.none
    bb04:	52800020 	mov	w0, #0x1                   	// #1
    bb08:	39000280 	strb	w0, [x20]
    bb0c:	aa1303e1 	mov	x1, x19
    bb10:	aa1503e0 	mov	x0, x21
    bb14:	97fff0bf 	bl	7e10 <fwp_hof0.constprop.0>
    bb18:	aa0003f4 	mov	x20, x0
    bb1c:	aa1503e0 	mov	x0, x21
    bb20:	97ffe780 	bl	5920 <fwp_drop0>
    bb24:	aa1303e0 	mov	x0, x19
    bb28:	97ffe77e 	bl	5920 <fwp_drop0>
    bb2c:	900000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    bb30:	f947f400 	ldr	x0, [x0, #4072]
    bb34:	f9442fe2 	ldr	x2, [sp, #2136]
    bb38:	f9400001 	ldr	x1, [x0]
    bb3c:	eb010042 	subs	x2, x2, x1
    bb40:	d2800001 	mov	x1, #0x0                   	// #0
    bb44:	54001f41 	b.ne	bf2c <f0+0x267c>  // b.any
    bb48:	912183ff 	add	sp, sp, #0x860
    bb4c:	aa1403e0 	mov	x0, x20
    bb50:	a94153f3 	ldp	x19, x20, [sp, #16]
    bb54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    bb58:	a94363f7 	ldp	x23, x24, [sp, #48]
    bb5c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    bb60:	a94573fb 	ldp	x27, x28, [sp, #80]
    bb64:	a8c67bfd 	ldp	x29, x30, [sp], #96
    bb68:	d65f03c0 	ret
    bb6c:	aa1b03e0 	mov	x0, x27
    bb70:	97ffe280 	bl	4570 <fwp_rc_forget_slot>
    bb74:	17fff797 	b	99d0 <f0+0x120>
    bb78:	72003c5f 	tst	w2, #0xffff
    bb7c:	54fef2c1 	b.ne	99d4 <f0+0x124>  // b.any
    bb80:	17fff791 	b	99c4 <f0+0x114>
    bb84:	72003c3f 	tst	w1, #0xffff
    bb88:	54ff9a01 	b.ne	aec8 <f0+0x1618>  // b.any
    bb8c:	17fffcca 	b	aeb4 <f0+0x1604>
    bb90:	72003c3f 	tst	w1, #0xffff
    bb94:	54ff94e1 	b.ne	ae30 <f0+0x1580>  // b.any
    bb98:	17fffca1 	b	ae1c <f0+0x156c>
    bb9c:	72003c3f 	tst	w1, #0xffff
    bba0:	54ff8de1 	b.ne	ad5c <f0+0x14ac>  // b.any
    bba4:	17fffc69 	b	ad48 <f0+0x1498>
    bba8:	72003c3f 	tst	w1, #0xffff
    bbac:	54ff87c1 	b.ne	aca4 <f0+0x13f4>  // b.any
    bbb0:	17fffc38 	b	ac90 <f0+0x13e0>
    bbb4:	72003c3f 	tst	w1, #0xffff
    bbb8:	54ff80c1 	b.ne	abd0 <f0+0x1320>  // b.any
    bbbc:	17fffc00 	b	abbc <f0+0x130c>
    bbc0:	72003c3f 	tst	w1, #0xffff
    bbc4:	54ff79c1 	b.ne	aafc <f0+0x124c>  // b.any
    bbc8:	17fffbc8 	b	aae8 <f0+0x1238>
    bbcc:	72003c3f 	tst	w1, #0xffff
    bbd0:	54ff73a1 	b.ne	aa44 <f0+0x1194>  // b.any
    bbd4:	17fffb97 	b	aa30 <f0+0x1180>
    bbd8:	72003c3f 	tst	w1, #0xffff
    bbdc:	54ff6d81 	b.ne	a98c <f0+0x10dc>  // b.any
    bbe0:	17fffb66 	b	a978 <f0+0x10c8>
    bbe4:	72003c3f 	tst	w1, #0xffff
    bbe8:	54ff1081 	b.ne	9df8 <f0+0x548>  // b.any
    bbec:	17fff87e 	b	9de4 <f0+0x534>
    bbf0:	72003c3f 	tst	w1, #0xffff
    bbf4:	54ff0021 	b.ne	9bf8 <f0+0x348>  // b.any
    bbf8:	17fff7fb 	b	9be4 <f0+0x334>
    bbfc:	72003c3f 	tst	w1, #0xffff
    bc00:	54fefa41 	b.ne	9b48 <f0+0x298>  // b.any
    bc04:	17fff7cc 	b	9b34 <f0+0x284>
    bc08:	72003c3f 	tst	w1, #0xffff
    bc0c:	54ff2e01 	b.ne	a1cc <f0+0x91c>  // b.any
    bc10:	17fff96a 	b	a1b8 <f0+0x908>
    bc14:	72003c3f 	tst	w1, #0xffff
    bc18:	54ff2461 	b.ne	a0a4 <f0+0x7f4>  // b.any
    bc1c:	17fff91d 	b	a090 <f0+0x7e0>
    bc20:	72003c3f 	tst	w1, #0xffff
    bc24:	54ff1d61 	b.ne	9fd0 <f0+0x720>  // b.any
    bc28:	17fff8e5 	b	9fbc <f0+0x70c>
    bc2c:	72003c3f 	tst	w1, #0xffff
    bc30:	54ff13c1 	b.ne	9ea8 <f0+0x5f8>  // b.any
    bc34:	17fff898 	b	9e94 <f0+0x5e4>
    bc38:	72003c3f 	tst	w1, #0xffff
    bc3c:	54ff65c1 	b.ne	a8f4 <f0+0x1044>  // b.any
    bc40:	17fffb28 	b	a8e0 <f0+0x1030>
    bc44:	72003c3f 	tst	w1, #0xffff
    bc48:	54ff5ec1 	b.ne	a820 <f0+0xf70>  // b.any
    bc4c:	17fffaf0 	b	a80c <f0+0xf5c>
    bc50:	72003c3f 	tst	w1, #0xffff
    bc54:	54ff58a1 	b.ne	a768 <f0+0xeb8>  // b.any
    bc58:	17fffabf 	b	a754 <f0+0xea4>
    bc5c:	72003c3f 	tst	w1, #0xffff
    bc60:	54ff5281 	b.ne	a6b0 <f0+0xe00>  // b.any
    bc64:	17fffa8e 	b	a69c <f0+0xdec>
    bc68:	72003c3f 	tst	w1, #0xffff
    bc6c:	54ff4d61 	b.ne	a618 <f0+0xd68>  // b.any
    bc70:	17fffa65 	b	a604 <f0+0xd54>
    bc74:	72003c3f 	tst	w1, #0xffff
    bc78:	54ff42e1 	b.ne	a4d4 <f0+0xc24>  // b.any
    bc7c:	17fffa11 	b	a4c0 <f0+0xc10>
    bc80:	72003c3f 	tst	w1, #0xffff
    bc84:	54ff3cc1 	b.ne	a41c <f0+0xb6c>  // b.any
    bc88:	17fff9e0 	b	a408 <f0+0xb58>
    bc8c:	72003c3f 	tst	w1, #0xffff
    bc90:	54ff36a1 	b.ne	a364 <f0+0xab4>  // b.any
    bc94:	17fff9af 	b	a350 <f0+0xaa0>
    bc98:	72003c3f 	tst	w1, #0xffff
    bc9c:	54fff381 	b.ne	bb0c <f0+0x225c>  // b.any
    bca0:	17ffff96 	b	baf8 <f0+0x2248>
    bca4:	72003c3f 	tst	w1, #0xffff
    bca8:	54ffed61 	b.ne	ba54 <f0+0x21a4>  // b.any
    bcac:	17ffff65 	b	ba40 <f0+0x2190>
    bcb0:	72003c3f 	tst	w1, #0xffff
    bcb4:	54ffe741 	b.ne	b99c <f0+0x20ec>  // b.any
    bcb8:	17ffff34 	b	b988 <f0+0x20d8>
    bcbc:	72003c3f 	tst	w1, #0xffff
    bcc0:	54ffdf61 	b.ne	b8ac <f0+0x1ffc>  // b.any
    bcc4:	17fffef5 	b	b898 <f0+0x1fe8>
    bcc8:	72003c3f 	tst	w1, #0xffff
    bccc:	54ffda41 	b.ne	b814 <f0+0x1f64>  // b.any
    bcd0:	17fffecc 	b	b800 <f0+0x1f50>
    bcd4:	72003c3f 	tst	w1, #0xffff
    bcd8:	54ffd541 	b.ne	b780 <f0+0x1ed0>  // b.any
    bcdc:	17fffea4 	b	b76c <f0+0x1ebc>
    bce0:	72003c3f 	tst	w1, #0xffff
    bce4:	54ffcf21 	b.ne	b6c8 <f0+0x1e18>  // b.any
    bce8:	17fffe73 	b	b6b4 <f0+0x1e04>
    bcec:	72003c3f 	tst	w1, #0xffff
    bcf0:	54ffc741 	b.ne	b5d8 <f0+0x1d28>  // b.any
    bcf4:	17fffe34 	b	b5c4 <f0+0x1d14>
    bcf8:	72003c3f 	tst	w1, #0xffff
    bcfc:	54ffc221 	b.ne	b540 <f0+0x1c90>  // b.any
    bd00:	17fffe0b 	b	b52c <f0+0x1c7c>
    bd04:	72003c3f 	tst	w1, #0xffff
    bd08:	54ffb6c1 	b.ne	b3e0 <f0+0x1b30>  // b.any
    bd0c:	17fffdb0 	b	b3cc <f0+0x1b1c>
    bd10:	72003c3f 	tst	w1, #0xffff
    bd14:	54ffb1c1 	b.ne	b34c <f0+0x1a9c>  // b.any
    bd18:	17fffd88 	b	b338 <f0+0x1a88>
    bd1c:	72003c3f 	tst	w1, #0xffff
    bd20:	54ffaba1 	b.ne	b294 <f0+0x19e4>  // b.any
    bd24:	17fffd57 	b	b280 <f0+0x19d0>
    bd28:	72003c3f 	tst	w1, #0xffff
    bd2c:	54ffa3c1 	b.ne	b1a4 <f0+0x18f4>  // b.any
    bd30:	17fffd18 	b	b190 <f0+0x18e0>
    bd34:	72003c3f 	tst	w1, #0xffff
    bd38:	54ff9ea1 	b.ne	b10c <f0+0x185c>  // b.any
    bd3c:	17fffcef 	b	b0f8 <f0+0x1848>
    bd40:	72003c3f 	tst	w1, #0xffff
    bd44:	54ff97a1 	b.ne	b038 <f0+0x1788>  // b.any
    bd48:	17fffcb7 	b	b024 <f0+0x1774>
    bd4c:	72003c3f 	tst	w1, #0xffff
    bd50:	54ff9181 	b.ne	af80 <f0+0x16d0>  // b.any
    bd54:	17fffc86 	b	af6c <f0+0x16bc>
    bd58:	aa1403e0 	mov	x0, x20
    bd5c:	97ffe205 	bl	4570 <fwp_rc_forget_slot>
    bd60:	17ffff69 	b	bb04 <f0+0x2254>
    bd64:	aa1703e0 	mov	x0, x23
    bd68:	97ffe202 	bl	4570 <fwp_rc_forget_slot>
    bd6c:	17fff775 	b	9b40 <f0+0x290>
    bd70:	aa1703e0 	mov	x0, x23
    bd74:	97ffe1ff 	bl	4570 <fwp_rc_forget_slot>
    bd78:	17fff79e 	b	9bf0 <f0+0x340>
    bd7c:	aa1703e0 	mov	x0, x23
    bd80:	97ffe1fc 	bl	4570 <fwp_rc_forget_slot>
    bd84:	17fff81b 	b	9df0 <f0+0x540>
    bd88:	aa1703e0 	mov	x0, x23
    bd8c:	97ffe1f9 	bl	4570 <fwp_rc_forget_slot>
    bd90:	17fff844 	b	9ea0 <f0+0x5f0>
    bd94:	aa1703e0 	mov	x0, x23
    bd98:	97ffe1f6 	bl	4570 <fwp_rc_forget_slot>
    bd9c:	17fff88b 	b	9fc8 <f0+0x718>
    bda0:	aa1703e0 	mov	x0, x23
    bda4:	97ffe1f3 	bl	4570 <fwp_rc_forget_slot>
    bda8:	17fff8bd 	b	a09c <f0+0x7ec>
    bdac:	aa1703e0 	mov	x0, x23
    bdb0:	97ffe1f0 	bl	4570 <fwp_rc_forget_slot>
    bdb4:	17fff904 	b	a1c4 <f0+0x914>
    bdb8:	aa1703e0 	mov	x0, x23
    bdbc:	97ffe1ed 	bl	4570 <fwp_rc_forget_slot>
    bdc0:	17fff967 	b	a35c <f0+0xaac>
    bdc4:	aa1703e0 	mov	x0, x23
    bdc8:	97ffe1ea 	bl	4570 <fwp_rc_forget_slot>
    bdcc:	17fff992 	b	a414 <f0+0xb64>
    bdd0:	aa1503e0 	mov	x0, x21
    bdd4:	97ffe1e7 	bl	4570 <fwp_rc_forget_slot>
    bdd8:	17fff9bd 	b	a4cc <f0+0xc1c>
    bddc:	aa1703e0 	mov	x0, x23
    bde0:	97ffe1e4 	bl	4570 <fwp_rc_forget_slot>
    bde4:	17fffa0b 	b	a610 <f0+0xd60>
    bde8:	aa1703e0 	mov	x0, x23
    bdec:	97ffe1e1 	bl	4570 <fwp_rc_forget_slot>
    bdf0:	17fffa2e 	b	a6a8 <f0+0xdf8>
    bdf4:	aa1703e0 	mov	x0, x23
    bdf8:	97ffe1de 	bl	4570 <fwp_rc_forget_slot>
    bdfc:	17fffa59 	b	a760 <f0+0xeb0>
    be00:	aa1703e0 	mov	x0, x23
    be04:	97ffe1db 	bl	4570 <fwp_rc_forget_slot>
    be08:	17fffa84 	b	a818 <f0+0xf68>
    be0c:	aa1703e0 	mov	x0, x23
    be10:	97ffe1d8 	bl	4570 <fwp_rc_forget_slot>
    be14:	17fffab6 	b	a8ec <f0+0x103c>
    be18:	aa1703e0 	mov	x0, x23
    be1c:	97ffe1d5 	bl	4570 <fwp_rc_forget_slot>
    be20:	17fffad9 	b	a984 <f0+0x10d4>
    be24:	aa1703e0 	mov	x0, x23
    be28:	97ffe1d2 	bl	4570 <fwp_rc_forget_slot>
    be2c:	17fffb04 	b	aa3c <f0+0x118c>
    be30:	aa1703e0 	mov	x0, x23
    be34:	97ffe1cf 	bl	4570 <fwp_rc_forget_slot>
    be38:	17fffb2f 	b	aaf4 <f0+0x1244>
    be3c:	aa1703e0 	mov	x0, x23
    be40:	97ffe1cc 	bl	4570 <fwp_rc_forget_slot>
    be44:	17fffb61 	b	abc8 <f0+0x1318>
    be48:	aa1703e0 	mov	x0, x23
    be4c:	97ffe1c9 	bl	4570 <fwp_rc_forget_slot>
    be50:	17fffb93 	b	ac9c <f0+0x13ec>
    be54:	aa1703e0 	mov	x0, x23
    be58:	97ffe1c6 	bl	4570 <fwp_rc_forget_slot>
    be5c:	17fffbbe 	b	ad54 <f0+0x14a4>
    be60:	aa1703e0 	mov	x0, x23
    be64:	97ffe1c3 	bl	4570 <fwp_rc_forget_slot>
    be68:	17fffbf0 	b	ae28 <f0+0x1578>
    be6c:	aa1703e0 	mov	x0, x23
    be70:	97ffe1c0 	bl	4570 <fwp_rc_forget_slot>
    be74:	17fffc13 	b	aec0 <f0+0x1610>
    be78:	aa1703e0 	mov	x0, x23
    be7c:	97ffe1bd 	bl	4570 <fwp_rc_forget_slot>
    be80:	17fffc3e 	b	af78 <f0+0x16c8>
    be84:	aa1703e0 	mov	x0, x23
    be88:	97ffe1ba 	bl	4570 <fwp_rc_forget_slot>
    be8c:	17fffc69 	b	b030 <f0+0x1780>
    be90:	aa1703e0 	mov	x0, x23
    be94:	97ffe1b7 	bl	4570 <fwp_rc_forget_slot>
    be98:	17fffc9b 	b	b104 <f0+0x1854>
    be9c:	aa1703e0 	mov	x0, x23
    bea0:	97ffe1b4 	bl	4570 <fwp_rc_forget_slot>
    bea4:	17fffcbe 	b	b19c <f0+0x18ec>
    bea8:	aa1703e0 	mov	x0, x23
    beac:	97ffe1b1 	bl	4570 <fwp_rc_forget_slot>
    beb0:	17fffcf7 	b	b28c <f0+0x19dc>
    beb4:	aa1703e0 	mov	x0, x23
    beb8:	97ffe1ae 	bl	4570 <fwp_rc_forget_slot>
    bebc:	17fffd22 	b	b344 <f0+0x1a94>
    bec0:	aa1703e0 	mov	x0, x23
    bec4:	97ffe1ab 	bl	4570 <fwp_rc_forget_slot>
    bec8:	17fffd44 	b	b3d8 <f0+0x1b28>
    becc:	aa1703e0 	mov	x0, x23
    bed0:	97ffe1a8 	bl	4570 <fwp_rc_forget_slot>
    bed4:	17fffd99 	b	b538 <f0+0x1c88>
    bed8:	aa1703e0 	mov	x0, x23
    bedc:	97ffe1a5 	bl	4570 <fwp_rc_forget_slot>
    bee0:	17fffdbc 	b	b5d0 <f0+0x1d20>
    bee4:	aa1703e0 	mov	x0, x23
    bee8:	97ffe1a2 	bl	4570 <fwp_rc_forget_slot>
    beec:	17fffdf5 	b	b6c0 <f0+0x1e10>
    bef0:	aa1703e0 	mov	x0, x23
    bef4:	97ffe19f 	bl	4570 <fwp_rc_forget_slot>
    bef8:	17fffe20 	b	b778 <f0+0x1ec8>
    befc:	aa1703e0 	mov	x0, x23
    bf00:	97ffe19c 	bl	4570 <fwp_rc_forget_slot>
    bf04:	17fffe42 	b	b80c <f0+0x1f5c>
    bf08:	aa1703e0 	mov	x0, x23
    bf0c:	97ffe199 	bl	4570 <fwp_rc_forget_slot>
    bf10:	17fffe65 	b	b8a4 <f0+0x1ff4>
    bf14:	aa1703e0 	mov	x0, x23
    bf18:	97ffe196 	bl	4570 <fwp_rc_forget_slot>
    bf1c:	17fffe9e 	b	b994 <f0+0x20e4>
    bf20:	aa1703e0 	mov	x0, x23
    bf24:	97ffe193 	bl	4570 <fwp_rc_forget_slot>
    bf28:	17fffec9 	b	ba4c <f0+0x219c>
    bf2c:	97ffda55 	bl	2880 <__stack_chk_fail@plt>

000000000000bf30 <fwp_main_thread>:
    bf30:	d10443ff 	sub	sp, sp, #0x110
    bf34:	900000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    bf38:	f947f400 	ldr	x0, [x0, #4072]
    bf3c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    bf40:	910303fd 	add	x29, sp, #0xc0
    bf44:	a90d53f3 	stp	x19, x20, [sp, #208]
    bf48:	d0000133 	adrp	x19, 31000 <fwp_root_context+0xca0>
    bf4c:	91150261 	add	x1, x19, #0x540
    bf50:	a90e5bf5 	stp	x21, x22, [sp, #224]
    bf54:	b953a421 	ldr	w1, [x1, #5028]
    bf58:	f9400002 	ldr	x2, [x0]
    bf5c:	f9005fe2 	str	x2, [sp, #184]
    bf60:	d2800002 	mov	x2, #0x0                   	// #0
    bf64:	340025c1 	cbz	w1, c41c <fwp_main_thread+0x4ec>
    bf68:	91150273 	add	x19, x19, #0x540
    bf6c:	b953aa60 	ldr	w0, [x19, #5032]
    bf70:	350024e0 	cbnz	w0, c40c <fwp_main_thread+0x4dc>
    bf74:	91001fe2 	add	x2, sp, #0x7
    bf78:	b00000b5 	adrp	x21, 20000 <__data_start>
    bf7c:	b00000a3 	adrp	x3, 20000 <__data_start>
    bf80:	9100c2b3 	add	x19, x21, #0x30
    bf84:	910d8063 	add	x3, x3, #0x360
    bf88:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    bf8c:	d2a00025 	mov	x5, #0x10000               	// #65536
    bf90:	910023e0 	add	x0, sp, #0x8
    bf94:	d2800001 	mov	x1, #0x0                   	// #0
    bf98:	f90007e3 	str	x3, [sp, #8]
    bf9c:	b90013ff 	str	wzr, [sp, #16]
    bfa0:	a9019262 	stp	x2, x4, [x19, #24]
    bfa4:	f9000fe5 	str	x5, [sp, #24]
    bfa8:	97ffd9ce 	bl	26e0 <sigaltstack@plt>
    bfac:	35002520 	cbnz	w0, c450 <fwp_main_thread+0x520>
    bfb0:	4f000400 	movi	v0.4s, #0x0
    bfb4:	9100a3e0 	add	x0, sp, #0x28
    bfb8:	90ffffc1 	adrp	x1, 3000 <fwp_flush+0x10>
    bfbc:	52800082 	mov	w2, #0x4                   	// #4
    bfc0:	9101c021 	add	x1, x1, #0x70
    bfc4:	72a10002 	movk	w2, #0x800, lsl #16
    bfc8:	910083f4 	add	x20, sp, #0x20
    bfcc:	f90013e1 	str	x1, [sp, #32]
    bfd0:	3d802000 	str	q0, [x0, #128]
    bfd4:	b900abe2 	str	w2, [sp, #168]
    bfd8:	ad000000 	stp	q0, q0, [x0]
    bfdc:	ad010000 	stp	q0, q0, [x0, #32]
    bfe0:	ad020000 	stp	q0, q0, [x0, #64]
    bfe4:	ad030000 	stp	q0, q0, [x0, #96]
    bfe8:	97ffda16 	bl	2840 <sigemptyset@plt>
    bfec:	35002320 	cbnz	w0, c450 <fwp_main_thread+0x520>
    bff0:	aa1403e1 	mov	x1, x20
    bff4:	d2800002 	mov	x2, #0x0                   	// #0
    bff8:	52800160 	mov	w0, #0xb                   	// #11
    bffc:	97ffda29 	bl	28a0 <sigaction@plt>
    c000:	35002280 	cbnz	w0, c450 <fwp_main_thread+0x520>
    c004:	aa1403e1 	mov	x1, x20
    c008:	d2800002 	mov	x2, #0x0                   	// #0
    c00c:	528000e0 	mov	w0, #0x7                   	// #7
    c010:	97ffda24 	bl	28a0 <sigaction@plt>
    c014:	350021e0 	cbnz	w0, c450 <fwp_main_thread+0x520>
    c018:	b942fa60 	ldr	w0, [x19, #760]
    c01c:	a90f63f7 	stp	x23, x24, [sp, #240]
    c020:	34002020 	cbz	w0, c424 <fwp_main_thread+0x4f4>
    c024:	9100c2b6 	add	x22, x21, #0x30
    c028:	f9400ad4 	ldr	x20, [x22, #16]
    c02c:	b40010d4 	cbz	x20, c244 <fwp_main_thread+0x314>
    c030:	aa1403f3 	mov	x19, x20
    c034:	91010297 	add	x23, x20, #0x40
    c038:	f90083f9 	str	x25, [sp, #256]
    c03c:	52800038 	mov	w24, #0x1                   	// #1
    c040:	39414a99 	ldrb	w25, [x20, #82]
    c044:	39014a98 	strb	w24, [x20, #82]
    c048:	f9401680 	ldr	x0, [x20, #40]
    c04c:	b4000620 	cbz	x0, c110 <fwp_main_thread+0x1e0>
    c050:	f9403281 	ldr	x1, [x20, #96]
    c054:	39414680 	ldrb	w0, [x20, #81]
    c058:	b4000b41 	cbz	x1, c1c0 <fwp_main_thread+0x290>
    c05c:	36000a80 	tbz	w0, #0, c1ac <fwp_main_thread+0x27c>
    c060:	39414a62 	ldrb	w2, [x19, #82]
    c064:	f9402280 	ldr	x0, [x20, #64]
    c068:	37000d62 	tbnz	w2, #0, c214 <fwp_main_thread+0x2e4>
    c06c:	f9403261 	ldr	x1, [x19, #96]
    c070:	a911fe77 	stp	x23, xzr, [x19, #280]
    c074:	f9009660 	str	x0, [x19, #296]
    c078:	b4000040 	cbz	x0, c080 <fwp_main_thread+0x150>
    c07c:	f9009013 	str	x19, [x0, #288]
    c080:	f9002293 	str	x19, [x20, #64]
    c084:	b4000101 	cbz	x1, c0a4 <fwp_main_thread+0x174>
    c088:	f94046c0 	ldr	x0, [x22, #136]
    c08c:	39015678 	strb	w24, [x19, #85]
    c090:	f9003661 	str	x1, [x19, #104]
    c094:	a910827f 	stp	xzr, x0, [x19, #264]
    c098:	b4000040 	cbz	x0, c0a0 <fwp_main_thread+0x170>
    c09c:	f9008413 	str	x19, [x0, #264]
    c0a0:	f90046d3 	str	x19, [x22, #136]
    c0a4:	39015a7f 	strb	wzr, [x19, #86]
    c0a8:	97ffe8e7 	bl	6444 <fwp_block>
    c0ac:	f9408e62 	ldr	x2, [x19, #280]
    c0b0:	b4000142 	cbz	x2, c0d8 <fwp_main_thread+0x1a8>
    c0b4:	a9520261 	ldp	x1, x0, [x19, #288]
    c0b8:	b4000ba1 	cbz	x1, c22c <fwp_main_thread+0x2fc>
    c0bc:	f9009420 	str	x0, [x1, #296]
    c0c0:	f9409660 	ldr	x0, [x19, #296]
    c0c4:	b4000040 	cbz	x0, c0cc <fwp_main_thread+0x19c>
    c0c8:	f9009001 	str	x1, [x0, #288]
    c0cc:	91080260 	add	x0, x19, #0x200
    c0d0:	f900967f 	str	xzr, [x19, #296]
    c0d4:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c0d8:	39415660 	ldrb	w0, [x19, #85]
    c0dc:	f9400ac2 	ldr	x2, [x22, #16]
    c0e0:	36000960 	tbz	w0, #0, c20c <fwp_main_thread+0x2dc>
    c0e4:	a9508261 	ldp	x1, x0, [x19, #264]
    c0e8:	b4000a61 	cbz	x1, c234 <fwp_main_thread+0x304>
    c0ec:	f9008820 	str	x0, [x1, #272]
    c0f0:	b4000040 	cbz	x0, c0f8 <fwp_main_thread+0x1c8>
    c0f4:	f9008401 	str	x1, [x0, #264]
    c0f8:	91080260 	add	x0, x19, #0x200
    c0fc:	3901567f 	strb	wzr, [x19, #85]
    c100:	aa0203f3 	mov	x19, x2
    c104:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c108:	f9401680 	ldr	x0, [x20, #40]
    c10c:	b5fffa20 	cbnz	x0, c050 <fwp_main_thread+0x120>
    c110:	9100c2a0 	add	x0, x21, #0x30
    c114:	39014a99 	strb	w25, [x20, #82]
    c118:	f94083f9 	ldr	x25, [sp, #256]
    c11c:	f9416c00 	ldr	x0, [x0, #728]
    c120:	b4001560 	cbz	x0, c3cc <fwp_main_thread+0x49c>
    c124:	9100c2a0 	add	x0, x21, #0x30
    c128:	f9418801 	ldr	x1, [x0, #784]
    c12c:	b903081f 	str	wzr, [x0, #776]
    c130:	eb13003f 	cmp	x1, x19
    c134:	54001681 	b.ne	c404 <fwp_main_thread+0x4d4>  // b.any
    c138:	b4000913 	cbz	x19, c258 <fwp_main_thread+0x328>
    c13c:	9100c2a0 	add	x0, x21, #0x30
    c140:	52800021 	mov	w1, #0x1                   	// #1
    c144:	39014a61 	strb	w1, [x19, #82]
    c148:	f9415805 	ldr	x5, [x0, #688]
    c14c:	b4000865 	cbz	x5, c258 <fwp_main_thread+0x328>
    c150:	394140a0 	ldrb	w0, [x5, #80]
    c154:	37000060 	tbnz	w0, #0, c160 <fwp_main_thread+0x230>
    c158:	aa0503e0 	mov	x0, x5
    c15c:	97ffdcc5 	bl	3470 <fwp_cancel_tree.part.0>
    c160:	f9409ca5 	ldr	x5, [x5, #312]
    c164:	b5ffff65 	cbnz	x5, c150 <fwp_main_thread+0x220>
    c168:	9100c2b4 	add	x20, x21, #0x30
    c16c:	52800036 	mov	w22, #0x1                   	// #1
    c170:	f9402a60 	ldr	x0, [x19, #80]
    c174:	f2001c1f 	tst	x0, #0xff000000ff
    c178:	540000e1 	b.ne	c194 <fwp_main_thread+0x264>  // b.any
    c17c:	f9401680 	ldr	x0, [x20, #40]
    c180:	39015276 	strb	w22, [x19, #84]
    c184:	f900827f 	str	xzr, [x19, #256]
    c188:	b40005a0 	cbz	x0, c23c <fwp_main_thread+0x30c>
    c18c:	f9008013 	str	x19, [x0, #256]
    c190:	f9001693 	str	x19, [x20, #40]
    c194:	97ffe8ac 	bl	6444 <fwp_block>
    c198:	97ffe83e 	bl	6290 <fwp_free_zombie>
    c19c:	f9415a80 	ldr	x0, [x20, #688]
    c1a0:	b40005c0 	cbz	x0, c258 <fwp_main_thread+0x328>
    c1a4:	f9418a93 	ldr	x19, [x20, #784]
    c1a8:	17fffff2 	b	c170 <fwp_main_thread+0x240>
    c1ac:	97ffdd55 	bl	3700 <fwp_now_ns>
    c1b0:	f9403281 	ldr	x1, [x20, #96]
    c1b4:	eb01001f 	cmp	x0, x1
    c1b8:	54000fca 	b.ge	c3b0 <fwp_main_thread+0x480>  // b.tcont
    c1bc:	39414680 	ldrb	w0, [x20, #81]
    c1c0:	39414a62 	ldrb	w2, [x19, #82]
    c1c4:	3707f500 	tbnz	w0, #0, c064 <fwp_main_thread+0x134>
    c1c8:	f9403281 	ldr	x1, [x20, #96]
    c1cc:	370001c2 	tbnz	w2, #0, c204 <fwp_main_thread+0x2d4>
    c1d0:	f9403260 	ldr	x0, [x19, #96]
    c1d4:	b4000180 	cbz	x0, c204 <fwp_main_thread+0x2d4>
    c1d8:	b4000061 	cbz	x1, c1e4 <fwp_main_thread+0x2b4>
    c1dc:	eb01001f 	cmp	x0, x1
    c1e0:	9a81d000 	csel	x0, x0, x1, le
    c1e4:	f9402281 	ldr	x1, [x20, #64]
    c1e8:	a911fe77 	stp	x23, xzr, [x19, #280]
    c1ec:	f9009661 	str	x1, [x19, #296]
    c1f0:	b4001241 	cbz	x1, c438 <fwp_main_thread+0x508>
    c1f4:	f9009033 	str	x19, [x1, #288]
    c1f8:	aa0003e1 	mov	x1, x0
    c1fc:	f9002293 	str	x19, [x20, #64]
    c200:	17ffffa2 	b	c088 <fwp_main_thread+0x158>
    c204:	f9402280 	ldr	x0, [x20, #64]
    c208:	17ffff9a 	b	c070 <fwp_main_thread+0x140>
    c20c:	aa0203f3 	mov	x19, x2
    c210:	17ffff8e 	b	c048 <fwp_main_thread+0x118>
    c214:	a911fe77 	stp	x23, xzr, [x19, #280]
    c218:	f9009660 	str	x0, [x19, #296]
    c21c:	b4000040 	cbz	x0, c224 <fwp_main_thread+0x2f4>
    c220:	f9009013 	str	x19, [x0, #288]
    c224:	f9002293 	str	x19, [x20, #64]
    c228:	17ffff9f 	b	c0a4 <fwp_main_thread+0x174>
    c22c:	f9000040 	str	x0, [x2]
    c230:	17ffffa5 	b	c0c4 <fwp_main_thread+0x194>
    c234:	f90046c0 	str	x0, [x22, #136]
    c238:	17ffffae 	b	c0f0 <fwp_main_thread+0x1c0>
    c23c:	f9001a93 	str	x19, [x20, #48]
    c240:	17ffffd4 	b	c190 <fwp_main_thread+0x260>
    c244:	f9416ec0 	ldr	x0, [x22, #728]
    c248:	b4000c00 	cbz	x0, c3c8 <fwp_main_thread+0x498>
    c24c:	f9418ac0 	ldr	x0, [x22, #784]
    c250:	b9030adf 	str	wzr, [x22, #776]
    c254:	b5000d80 	cbnz	x0, c404 <fwp_main_thread+0x4d4>
    c258:	9100c2b4 	add	x20, x21, #0x30
    c25c:	97ffe80d 	bl	6290 <fwp_free_zombie>
    c260:	f9401a80 	ldr	x0, [x20, #48]
    c264:	b5000d00 	cbnz	x0, c404 <fwp_main_thread+0x4d4>
    c268:	f9404680 	ldr	x0, [x20, #136]
    c26c:	b5000cc0 	cbnz	x0, c404 <fwp_main_thread+0x4d4>
    c270:	b940aa93 	ldr	w19, [x20, #168]
    c274:	340001d3 	cbz	w19, c2ac <fwp_main_thread+0x37c>
    c278:	93407e76 	sxtw	x22, w19
    c27c:	51000673 	sub	w19, w19, #0x1
    c280:	d1000ad6 	sub	x22, x22, #0x2
    c284:	9102c297 	add	x23, x20, #0xb0
    c288:	cb3342d6 	sub	x22, x22, w19, uxtw
    c28c:	93407e73 	sxtw	x19, w19
    c290:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    c294:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    c298:	b900aa93 	str	w19, [x20, #168]
    c29c:	d1000673 	sub	x19, x19, #0x1
    c2a0:	97ffd9c0 	bl	29a0 <munmap@plt>
    c2a4:	eb16027f 	cmp	x19, x22
    c2a8:	54ffff41 	b.ne	c290 <fwp_main_thread+0x360>  // b.any
    c2ac:	900000b3 	adrp	x19, 20000 <__data_start>
    c2b0:	91004260 	add	x0, x19, #0x10
    c2b4:	b9400800 	ldr	w0, [x0, #8]
    c2b8:	37f80040 	tbnz	w0, #31, c2c0 <fwp_main_thread+0x390>
    c2bc:	97ffd975 	bl	2890 <close@plt>
    c2c0:	9100c2a0 	add	x0, x21, #0x30
    c2c4:	91004261 	add	x1, x19, #0x10
    c2c8:	12800002 	mov	w2, #0xffffffff            	// #-1
    c2cc:	d2800013 	mov	x19, #0x0                   	// #0
    c2d0:	f9418c16 	ldr	x22, [x0, #792]
    c2d4:	b9000822 	str	w2, [x1, #8]
    c2d8:	f9419014 	ldr	x20, [x0, #800]
    c2dc:	b4000176 	cbz	x22, c308 <fwp_main_thread+0x3d8>
    c2e0:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    c2e4:	b40000c0 	cbz	x0, c2fc <fwp_main_thread+0x3cc>
    c2e8:	f9400001 	ldr	x1, [x0]
    c2ec:	b50008c1 	cbnz	x1, c404 <fwp_main_thread+0x4d4>
    c2f0:	f9400401 	ldr	x1, [x0, #8]
    c2f4:	b5000881 	cbnz	x1, c404 <fwp_main_thread+0x4d4>
    c2f8:	97ffe13e 	bl	47f0 <fwp_mem_free>
    c2fc:	91000673 	add	x19, x19, #0x1
    c300:	eb16027f 	cmp	x19, x22
    c304:	54fffee1 	b.ne	c2e0 <fwp_main_thread+0x3b0>  // b.any
    c308:	aa1403e0 	mov	x0, x20
    c30c:	97ffe139 	bl	47f0 <fwp_mem_free>
    c310:	9100c2a0 	add	x0, x21, #0x30
    c314:	f9418813 	ldr	x19, [x0, #784]
    c318:	f9018c1f 	str	xzr, [x0, #792]
    c31c:	f901901f 	str	xzr, [x0, #800]
    c320:	b40001f3 	cbz	x19, c35c <fwp_main_thread+0x42c>
    c324:	f9401661 	ldr	x1, [x19, #40]
    c328:	b50006e1 	cbnz	x1, c404 <fwp_main_thread+0x4d4>
    c32c:	f9405661 	ldr	x1, [x19, #168]
    c330:	b50006a1 	cbnz	x1, c404 <fwp_main_thread+0x4d4>
    c334:	f9416c01 	ldr	x1, [x0, #728]
    c338:	b5000661 	cbnz	x1, c404 <fwp_main_thread+0x4d4>
    c33c:	f9417400 	ldr	x0, [x0, #744]
    c340:	b5000620 	cbnz	x0, c404 <fwp_main_thread+0x4d4>
    c344:	d2823a02 	mov	x2, #0x11d0                	// #4560
    c348:	90000120 	adrp	x0, 30000 <alt.5+0xfca0>
    c34c:	910d8000 	add	x0, x0, #0x360
    c350:	97ffd940 	bl	2850 <memset@plt>
    c354:	aa1303e0 	mov	x0, x19
    c358:	97ffe126 	bl	47f0 <fwp_mem_free>
    c35c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c360:	f947ec00 	ldr	x0, [x0, #4056]
    c364:	9100c2b5 	add	x21, x21, #0x30
    c368:	f9400000 	ldr	x0, [x0]
    c36c:	f9000abf 	str	xzr, [x21, #16]
    c370:	f9018abf 	str	xzr, [x21, #784]
    c374:	97ffd98f 	bl	29b0 <fflush@plt>
    c378:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c37c:	f947f400 	ldr	x0, [x0, #4072]
    c380:	f9405fe2 	ldr	x2, [sp, #184]
    c384:	f9400001 	ldr	x1, [x0]
    c388:	eb010042 	subs	x2, x2, x1
    c38c:	d2800001 	mov	x1, #0x0                   	// #0
    c390:	540006a1 	b.ne	c464 <fwp_main_thread+0x534>  // b.any
    c394:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    c398:	d2800000 	mov	x0, #0x0                   	// #0
    c39c:	a94d53f3 	ldp	x19, x20, [sp, #208]
    c3a0:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    c3a4:	a94f63f7 	ldp	x23, x24, [sp, #240]
    c3a8:	910443ff 	add	sp, sp, #0x110
    c3ac:	d65f03c0 	ret
    c3b0:	39414280 	ldrb	w0, [x20, #80]
    c3b4:	3707f040 	tbnz	w0, #0, c1bc <fwp_main_thread+0x28c>
    c3b8:	aa1403e0 	mov	x0, x20
    c3bc:	97ffdc2d 	bl	3470 <fwp_cancel_tree.part.0>
    c3c0:	39414680 	ldrb	w0, [x20, #81]
    c3c4:	17ffff7f 	b	c1c0 <fwp_main_thread+0x290>
    c3c8:	d2800013 	mov	x19, #0x0                   	// #0
    c3cc:	9100c2b4 	add	x20, x21, #0x30
    c3d0:	f9417680 	ldr	x0, [x20, #744]
    c3d4:	b5ffea80 	cbnz	x0, c124 <fwp_main_thread+0x1f4>
    c3d8:	f9416a80 	ldr	x0, [x20, #720]
    c3dc:	97ffe105 	bl	47f0 <fwp_mem_free>
    c3e0:	f9016a9f 	str	xzr, [x20, #720]
    c3e4:	f901729f 	str	xzr, [x20, #736]
    c3e8:	f9418a80 	ldr	x0, [x20, #784]
    c3ec:	b40002d3 	cbz	x19, c444 <fwp_main_thread+0x514>
    c3f0:	f900567f 	str	xzr, [x19, #168]
    c3f4:	f9005e7f 	str	xzr, [x19, #184]
    c3f8:	b9030a9f 	str	wzr, [x20, #776]
    c3fc:	eb00027f 	cmp	x19, x0
    c400:	54ffe9e0 	b.eq	c13c <fwp_main_thread+0x20c>  // b.none
    c404:	f90083f9 	str	x25, [sp, #256]
    c408:	97ffd932 	bl	28d0 <abort@plt>
    c40c:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    c410:	91348000 	add	x0, x0, #0xd20
    c414:	940005d3 	bl	db60 <atexit>
    c418:	17fffed7 	b	bf74 <fwp_main_thread+0x44>
    c41c:	97ffde9a 	bl	3e84 <fwp_heap_init>
    c420:	17fffed2 	b	bf68 <fwp_main_thread+0x38>
    c424:	97fff523 	bl	98b0 <f0>
    c428:	f9018260 	str	x0, [x19, #768]
    c42c:	52800021 	mov	w1, #0x1                   	// #1
    c430:	b902fa61 	str	w1, [x19, #760]
    c434:	17fffefc 	b	c024 <fwp_main_thread+0xf4>
    c438:	aa0003e1 	mov	x1, x0
    c43c:	f9002293 	str	x19, [x20, #64]
    c440:	17ffff12 	b	c088 <fwp_main_thread+0x158>
    c444:	b9030a9f 	str	wzr, [x20, #776]
    c448:	b4fff080 	cbz	x0, c258 <fwp_main_thread+0x328>
    c44c:	17ffffee 	b	c404 <fwp_main_thread+0x4d4>
    c450:	d0000000 	adrp	x0, e000 <_IO_stdin_used+0x470>
    c454:	91052000 	add	x0, x0, #0x148
    c458:	a90f63f7 	stp	x23, x24, [sp, #240]
    c45c:	f90083f9 	str	x25, [sp, #256]
    c460:	97ffdc48 	bl	3580 <fwp_trap>
    c464:	f90083f9 	str	x25, [sp, #256]
    c468:	97ffd906 	bl	2880 <__stack_chk_fail@plt>
    c46c:	d503201f 	nop
    c470:	14000400 	b	d470 <__divti3>
    c474:	d503201f 	nop
    c478:	f9400001 	ldr	x1, [x0]
    c47c:	17ffeae4 	b	700c <fwp_write+0x1ec>
	...

000000000000d470 <__divti3>:
    d470:	d503245f 	bti	c
    d474:	d2800004 	mov	x4, #0x0                   	// #0
    d478:	b7f80721 	tbnz	x1, #63, d55c <__divti3+0xec>
    d47c:	b6f80083 	tbz	x3, #63, d48c <__divti3+0x1c>
    d480:	eb0203e2 	negs	x2, x2
    d484:	aa2403e4 	mvn	x4, x4
    d488:	da0303e3 	ngc	x3, x3
    d48c:	aa0203e6 	mov	x6, x2
    d490:	aa0003e7 	mov	x7, x0
    d494:	aa0103e5 	mov	x5, x1
    d498:	b5000583 	cbnz	x3, d548 <__divti3+0xd8>
    d49c:	eb01005f 	cmp	x2, x1
    d4a0:	54000e69 	b.ls	d66c <__divti3+0x1fc>  // b.plast
    d4a4:	dac01040 	clz	x0, x2
    d4a8:	b40000e0 	cbz	x0, d4c4 <__divti3+0x54>
    d4ac:	4b0003e1 	neg	w1, w0
    d4b0:	9ac020a5 	lsl	x5, x5, x0
    d4b4:	9ac02046 	lsl	x6, x2, x0
    d4b8:	9ac124e1 	lsr	x1, x7, x1
    d4bc:	aa050025 	orr	x5, x1, x5
    d4c0:	9ac020e7 	lsl	x7, x7, x0
    d4c4:	d360fcc8 	lsr	x8, x6, #32
    d4c8:	92407cc2 	and	x2, x6, #0xffffffff
    d4cc:	9ac808a3 	udiv	x3, x5, x8
    d4d0:	9b089465 	msub	x5, x3, x8, x5
    d4d4:	aa0303e0 	mov	x0, x3
    d4d8:	9b037c41 	mul	x1, x2, x3
    d4dc:	93c780a5 	extr	x5, x5, x7, #32
    d4e0:	eb05003f 	cmp	x1, x5
    d4e4:	540000a9 	b.ls	d4f8 <__divti3+0x88>  // b.plast
    d4e8:	ab0500c5 	adds	x5, x6, x5
    d4ec:	d1000460 	sub	x0, x3, #0x1
    d4f0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    d4f4:	540015a8 	b.hi	d7a8 <__divti3+0x338>  // b.pmore
    d4f8:	cb0100a5 	sub	x5, x5, x1
    d4fc:	9ac808a3 	udiv	x3, x5, x8
    d500:	9b089465 	msub	x5, x3, x8, x5
    d504:	aa0303e1 	mov	x1, x3
    d508:	9b037c42 	mul	x2, x2, x3
    d50c:	aa0703e3 	mov	x3, x7
    d510:	b3607ca3 	bfi	x3, x5, #32, #32
    d514:	eb03005f 	cmp	x2, x3
    d518:	540000c9 	b.ls	d530 <__divti3+0xc0>  // b.plast
    d51c:	ab0300c3 	adds	x3, x6, x3
    d520:	d1000425 	sub	x5, x1, #0x1
    d524:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d528:	d1000821 	sub	x1, x1, #0x2
    d52c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    d530:	aa008020 	orr	x0, x1, x0, lsl #32
    d534:	d2800001 	mov	x1, #0x0                   	// #0
    d538:	b4000064 	cbz	x4, d544 <__divti3+0xd4>
    d53c:	eb0003e0 	negs	x0, x0
    d540:	da0103e1 	ngc	x1, x1
    d544:	d65f03c0 	ret
    d548:	eb01007f 	cmp	x3, x1
    d54c:	54000109 	b.ls	d56c <__divti3+0xfc>  // b.plast
    d550:	d2800001 	mov	x1, #0x0                   	// #0
    d554:	d2800000 	mov	x0, #0x0                   	// #0
    d558:	17fffff8 	b	d538 <__divti3+0xc8>
    d55c:	eb0003e0 	negs	x0, x0
    d560:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d564:	da0103e1 	ngc	x1, x1
    d568:	17ffffc5 	b	d47c <__divti3+0xc>
    d56c:	dac01067 	clz	x7, x3
    d570:	b40010e7 	cbz	x7, d78c <__divti3+0x31c>
    d574:	d2800805 	mov	x5, #0x40                  	// #64
    d578:	cb0700a5 	sub	x5, x5, x7
    d57c:	9ac72063 	lsl	x3, x3, x7
    d580:	9ac52448 	lsr	x8, x2, x5
    d584:	aa030108 	orr	x8, x8, x3
    d588:	9ac52426 	lsr	x6, x1, x5
    d58c:	92407d0a 	and	x10, x8, #0xffffffff
    d590:	d360fd09 	lsr	x9, x8, #32
    d594:	9ac52403 	lsr	x3, x0, x5
    d598:	9ac72021 	lsl	x1, x1, x7
    d59c:	aa010063 	orr	x3, x3, x1
    d5a0:	9ac72042 	lsl	x2, x2, x7
    d5a4:	9ac908cb 	udiv	x11, x6, x9
    d5a8:	9b099965 	msub	x5, x11, x9, x6
    d5ac:	aa0b03e1 	mov	x1, x11
    d5b0:	9b0b7d46 	mul	x6, x10, x11
    d5b4:	93c380a5 	extr	x5, x5, x3, #32
    d5b8:	eb0500df 	cmp	x6, x5
    d5bc:	540000a9 	b.ls	d5d0 <__divti3+0x160>  // b.plast
    d5c0:	ab050105 	adds	x5, x8, x5
    d5c4:	d1000561 	sub	x1, x11, #0x1
    d5c8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    d5cc:	54000f48 	b.hi	d7b4 <__divti3+0x344>  // b.pmore
    d5d0:	cb0600a6 	sub	x6, x5, x6
    d5d4:	9ac908cb 	udiv	x11, x6, x9
    d5d8:	9b099969 	msub	x9, x11, x9, x6
    d5dc:	aa0b03e5 	mov	x5, x11
    d5e0:	9b0b7d4a 	mul	x10, x10, x11
    d5e4:	b3607d23 	bfi	x3, x9, #32, #32
    d5e8:	eb03015f 	cmp	x10, x3
    d5ec:	540000a9 	b.ls	d600 <__divti3+0x190>  // b.plast
    d5f0:	ab030103 	adds	x3, x8, x3
    d5f4:	d1000565 	sub	x5, x11, #0x1
    d5f8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    d5fc:	54000e28 	b.hi	d7c0 <__divti3+0x350>  // b.pmore
    d600:	aa0180a1 	orr	x1, x5, x1, lsl #32
    d604:	92407c48 	and	x8, x2, #0xffffffff
    d608:	2a0503e5 	mov	w5, w5
    d60c:	d360fc42 	lsr	x2, x2, #32
    d610:	d360fc26 	lsr	x6, x1, #32
    d614:	cb0a0063 	sub	x3, x3, x10
    d618:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    d61c:	9b087caa 	mul	x10, x5, x8
    d620:	9b087cc8 	mul	x8, x6, x8
    d624:	9b0220a5 	madd	x5, x5, x2, x8
    d628:	9b027cc6 	mul	x6, x6, x2
    d62c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    d630:	8b0900c5 	add	x5, x6, x9
    d634:	eb02011f 	cmp	x8, x2
    d638:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    d63c:	8b4280c6 	add	x6, x6, x2, lsr #32
    d640:	eb06007f 	cmp	x3, x6
    d644:	540000e3 	b.cc	d660 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    d648:	92407d4a 	and	x10, x10, #0xffffffff
    d64c:	9ac72000 	lsl	x0, x0, x7
    d650:	8b028142 	add	x2, x10, x2, lsl #32
    d654:	eb02001f 	cmp	x0, x2
    d658:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    d65c:	54000a01 	b.ne	d79c <__divti3+0x32c>  // b.any
    d660:	d1000420 	sub	x0, x1, #0x1
    d664:	d2800001 	mov	x1, #0x0                   	// #0
    d668:	17ffffb4 	b	d538 <__divti3+0xc8>
    d66c:	b5000062 	cbnz	x2, d678 <__divti3+0x208>
    d670:	d2800022 	mov	x2, #0x1                   	// #1
    d674:	9ac30846 	udiv	x6, x2, x3
    d678:	dac010c8 	clz	x8, x6
    d67c:	b5000408 	cbnz	x8, d6fc <__divti3+0x28c>
    d680:	d360fcc9 	lsr	x9, x6, #32
    d684:	92407cc5 	and	x5, x6, #0xffffffff
    d688:	cb060023 	sub	x3, x1, x6
    d68c:	d2800021 	mov	x1, #0x1                   	// #1
    d690:	9ac90868 	udiv	x8, x3, x9
    d694:	9b098d03 	msub	x3, x8, x9, x3
    d698:	aa0803e0 	mov	x0, x8
    d69c:	9b057d02 	mul	x2, x8, x5
    d6a0:	93c78063 	extr	x3, x3, x7, #32
    d6a4:	eb03005f 	cmp	x2, x3
    d6a8:	540000a9 	b.ls	d6bc <__divti3+0x24c>  // b.plast
    d6ac:	ab0300c3 	adds	x3, x6, x3
    d6b0:	d1000500 	sub	x0, x8, #0x1
    d6b4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d6b8:	54000968 	b.hi	d7e4 <__divti3+0x374>  // b.pmore
    d6bc:	cb020063 	sub	x3, x3, x2
    d6c0:	9ac90862 	udiv	x2, x3, x9
    d6c4:	aa0203e8 	mov	x8, x2
    d6c8:	9b098c42 	msub	x2, x2, x9, x3
    d6cc:	aa0703e3 	mov	x3, x7
    d6d0:	9b057d05 	mul	x5, x8, x5
    d6d4:	b3607c43 	bfi	x3, x2, #32, #32
    d6d8:	eb0300bf 	cmp	x5, x3
    d6dc:	540000c9 	b.ls	d6f4 <__divti3+0x284>  // b.plast
    d6e0:	ab0300c2 	adds	x2, x6, x3
    d6e4:	d1000503 	sub	x3, x8, #0x1
    d6e8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    d6ec:	d1000908 	sub	x8, x8, #0x2
    d6f0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    d6f4:	aa008100 	orr	x0, x8, x0, lsl #32
    d6f8:	17ffff90 	b	d538 <__divti3+0xc8>
    d6fc:	9ac820c6 	lsl	x6, x6, x8
    d700:	d2800803 	mov	x3, #0x40                  	// #64
    d704:	cb080063 	sub	x3, x3, x8
    d708:	d360fcc9 	lsr	x9, x6, #32
    d70c:	9ac82027 	lsl	x7, x1, x8
    d710:	92407cc5 	and	x5, x6, #0xffffffff
    d714:	9ac32422 	lsr	x2, x1, x3
    d718:	9ac32403 	lsr	x3, x0, x3
    d71c:	aa070063 	orr	x3, x3, x7
    d720:	9ac9084a 	udiv	x10, x2, x9
    d724:	9ac82007 	lsl	x7, x0, x8
    d728:	9b098940 	msub	x0, x10, x9, x2
    d72c:	aa0a03e1 	mov	x1, x10
    d730:	9b0a7ca2 	mul	x2, x5, x10
    d734:	93c38000 	extr	x0, x0, x3, #32
    d738:	eb00005f 	cmp	x2, x0
    d73c:	540000a9 	b.ls	d750 <__divti3+0x2e0>  // b.plast
    d740:	ab0000c0 	adds	x0, x6, x0
    d744:	d1000541 	sub	x1, x10, #0x1
    d748:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    d74c:	54000468 	b.hi	d7d8 <__divti3+0x368>  // b.pmore
    d750:	cb020000 	sub	x0, x0, x2
    d754:	9ac9080a 	udiv	x10, x0, x9
    d758:	9b098140 	msub	x0, x10, x9, x0
    d75c:	aa0a03e2 	mov	x2, x10
    d760:	9b0a7ca8 	mul	x8, x5, x10
    d764:	b3607c03 	bfi	x3, x0, #32, #32
    d768:	eb03011f 	cmp	x8, x3
    d76c:	540000a9 	b.ls	d780 <__divti3+0x310>  // b.plast
    d770:	ab0300c3 	adds	x3, x6, x3
    d774:	d1000542 	sub	x2, x10, #0x1
    d778:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    d77c:	54000288 	b.hi	d7cc <__divti3+0x35c>  // b.pmore
    d780:	cb080063 	sub	x3, x3, x8
    d784:	aa018041 	orr	x1, x2, x1, lsl #32
    d788:	17ffffc2 	b	d690 <__divti3+0x220>
    d78c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    d790:	d2800001 	mov	x1, #0x0                   	// #0
    d794:	9a9f87e0 	cset	x0, ls	// ls = plast
    d798:	17ffff68 	b	d538 <__divti3+0xc8>
    d79c:	aa0103e0 	mov	x0, x1
    d7a0:	d2800001 	mov	x1, #0x0                   	// #0
    d7a4:	17ffff65 	b	d538 <__divti3+0xc8>
    d7a8:	d1000860 	sub	x0, x3, #0x2
    d7ac:	8b0600a5 	add	x5, x5, x6
    d7b0:	17ffff52 	b	d4f8 <__divti3+0x88>
    d7b4:	d1000961 	sub	x1, x11, #0x2
    d7b8:	8b0800a5 	add	x5, x5, x8
    d7bc:	17ffff85 	b	d5d0 <__divti3+0x160>
    d7c0:	d1000965 	sub	x5, x11, #0x2
    d7c4:	8b080063 	add	x3, x3, x8
    d7c8:	17ffff8e 	b	d600 <__divti3+0x190>
    d7cc:	d1000942 	sub	x2, x10, #0x2
    d7d0:	8b060063 	add	x3, x3, x6
    d7d4:	17ffffeb 	b	d780 <__divti3+0x310>
    d7d8:	d1000941 	sub	x1, x10, #0x2
    d7dc:	8b060000 	add	x0, x0, x6
    d7e0:	17ffffdc 	b	d750 <__divti3+0x2e0>
    d7e4:	d1000900 	sub	x0, x8, #0x2
    d7e8:	8b060063 	add	x3, x3, x6
    d7ec:	17ffffb4 	b	d6bc <__divti3+0x24c>

000000000000d7f0 <__modti3>:
    d7f0:	d503245f 	bti	c
    d7f4:	d2800004 	mov	x4, #0x0                   	// #0
    d7f8:	b6f80081 	tbz	x1, #63, d808 <__modti3+0x18>
    d7fc:	eb0003e0 	negs	x0, x0
    d800:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d804:	da0103e1 	ngc	x1, x1
    d808:	f100007f 	cmp	x3, #0x0
    d80c:	5400128b 	b.lt	da5c <__modti3+0x26c>  // b.tstop
    d810:	aa0003e7 	mov	x7, x0
    d814:	aa0103e6 	mov	x6, x1
    d818:	540004e1 	b.ne	d8b4 <__modti3+0xc4>  // b.any
    d81c:	eb02003f 	cmp	x1, x2
    d820:	54000dc2 	b.cs	d9d8 <__modti3+0x1e8>  // b.hs, b.nlast
    d824:	dac01043 	clz	x3, x2
    d828:	aa0303e5 	mov	x5, x3
    d82c:	b40000e3 	cbz	x3, d848 <__modti3+0x58>
    d830:	4b0303e6 	neg	w6, w3
    d834:	9ac32021 	lsl	x1, x1, x3
    d838:	9ac32042 	lsl	x2, x2, x3
    d83c:	9ac62406 	lsr	x6, x0, x6
    d840:	aa0100c6 	orr	x6, x6, x1
    d844:	9ac32007 	lsl	x7, x0, x3
    d848:	d360fc40 	lsr	x0, x2, #32
    d84c:	92407c43 	and	x3, x2, #0xffffffff
    d850:	9ac008c1 	udiv	x1, x6, x0
    d854:	9b009826 	msub	x6, x1, x0, x6
    d858:	9b017c61 	mul	x1, x3, x1
    d85c:	93c780c6 	extr	x6, x6, x7, #32
    d860:	eb06003f 	cmp	x1, x6
    d864:	540000a9 	b.ls	d878 <__modti3+0x88>  // b.plast
    d868:	ab060046 	adds	x6, x2, x6
    d86c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d870:	8b0200c8 	add	x8, x6, x2
    d874:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d878:	cb0100c6 	sub	x6, x6, x1
    d87c:	9ac008c8 	udiv	x8, x6, x0
    d880:	9b009901 	msub	x1, x8, x0, x6
    d884:	aa0703e0 	mov	x0, x7
    d888:	9b087c63 	mul	x3, x3, x8
    d88c:	b3607c20 	bfi	x0, x1, #32, #32
    d890:	eb00007f 	cmp	x3, x0
    d894:	54001088 	b.hi	daa4 <__modti3+0x2b4>  // b.pmore
    d898:	cb030000 	sub	x0, x0, x3
    d89c:	9ac52400 	lsr	x0, x0, x5
    d8a0:	d2800001 	mov	x1, #0x0                   	// #0
    d8a4:	b4000064 	cbz	x4, d8b0 <__modti3+0xc0>
    d8a8:	eb0003e0 	negs	x0, x0
    d8ac:	da0103e1 	ngc	x1, x1
    d8b0:	d65f03c0 	ret
    d8b4:	dac01066 	clz	x6, x3
    d8b8:	eb03003f 	cmp	x1, x3
    d8bc:	54ffff43 	b.cc	d8a4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d8c0:	93407cc5 	sxtw	x5, w6
    d8c4:	d2800808 	mov	x8, #0x40                  	// #64
    d8c8:	cb050108 	sub	x8, x8, x5
    d8cc:	9ac62063 	lsl	x3, x3, x6
    d8d0:	9ac62025 	lsl	x5, x1, x6
    d8d4:	9ac82447 	lsr	x7, x2, x8
    d8d8:	aa0300e7 	orr	x7, x7, x3
    d8dc:	9ac82423 	lsr	x3, x1, x8
    d8e0:	92407cec 	and	x12, x7, #0xffffffff
    d8e4:	d360fcea 	lsr	x10, x7, #32
    d8e8:	9ac82401 	lsr	x1, x0, x8
    d8ec:	aa050021 	orr	x1, x1, x5
    d8f0:	9ac62042 	lsl	x2, x2, x6
    d8f4:	9ac62000 	lsl	x0, x0, x6
    d8f8:	9aca086b 	udiv	x11, x3, x10
    d8fc:	9b0a8d63 	msub	x3, x11, x10, x3
    d900:	aa0b03e5 	mov	x5, x11
    d904:	9b0b7d89 	mul	x9, x12, x11
    d908:	93c18063 	extr	x3, x3, x1, #32
    d90c:	eb03013f 	cmp	x9, x3
    d910:	540000a9 	b.ls	d924 <__modti3+0x134>  // b.plast
    d914:	ab0300e3 	adds	x3, x7, x3
    d918:	d1000565 	sub	x5, x11, #0x1
    d91c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d920:	54001168 	b.hi	db4c <__modti3+0x35c>  // b.pmore
    d924:	cb090063 	sub	x3, x3, x9
    d928:	9aca086b 	udiv	x11, x3, x10
    d92c:	9b0a8d6a 	msub	x10, x11, x10, x3
    d930:	aa0b03e9 	mov	x9, x11
    d934:	9b0b7d8c 	mul	x12, x12, x11
    d938:	b3607d41 	bfi	x1, x10, #32, #32
    d93c:	eb01019f 	cmp	x12, x1
    d940:	540000a9 	b.ls	d954 <__modti3+0x164>  // b.plast
    d944:	ab0100e1 	adds	x1, x7, x1
    d948:	d1000569 	sub	x9, x11, #0x1
    d94c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d950:	54000f88 	b.hi	db40 <__modti3+0x350>  // b.pmore
    d954:	aa058123 	orr	x3, x9, x5, lsl #32
    d958:	92407c4b 	and	x11, x2, #0xffffffff
    d95c:	2a0903e9 	mov	w9, w9
    d960:	d360fc4a 	lsr	x10, x2, #32
    d964:	d360fc63 	lsr	x3, x3, #32
    d968:	cb0c0021 	sub	x1, x1, x12
    d96c:	aa0a03ec 	mov	x12, x10
    d970:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d974:	9b0b7d25 	mul	x5, x9, x11
    d978:	9b0b7c6b 	mul	x11, x3, x11
    d97c:	9b0a2d29 	madd	x9, x9, x10, x11
    d980:	92407caa 	and	x10, x5, #0xffffffff
    d984:	9b0c7c63 	mul	x3, x3, x12
    d988:	8b458125 	add	x5, x9, x5, lsr #32
    d98c:	8b0d0069 	add	x9, x3, x13
    d990:	eb05017f 	cmp	x11, x5
    d994:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d998:	8b058149 	add	x9, x10, x5, lsl #32
    d99c:	8b458063 	add	x3, x3, x5, lsr #32
    d9a0:	eb03003f 	cmp	x1, x3
    d9a4:	54000063 	b.cc	d9b0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d9a8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d9ac:	54000082 	b.cs	d9bc <__modti3+0x1cc>  // b.hs, b.nlast
    d9b0:	eb020129 	subs	x9, x9, x2
    d9b4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d9b8:	cb070063 	sub	x3, x3, x7
    d9bc:	eb090000 	subs	x0, x0, x9
    d9c0:	da030021 	sbc	x1, x1, x3
    d9c4:	9ac62400 	lsr	x0, x0, x6
    d9c8:	9ac82028 	lsl	x8, x1, x8
    d9cc:	aa000100 	orr	x0, x8, x0
    d9d0:	9ac62421 	lsr	x1, x1, x6
    d9d4:	17ffffb4 	b	d8a4 <__modti3+0xb4>
    d9d8:	b5000062 	cbnz	x2, d9e4 <__modti3+0x1f4>
    d9dc:	d2800023 	mov	x3, #0x1                   	// #1
    d9e0:	9ac20862 	udiv	x2, x3, x2
    d9e4:	dac01048 	clz	x8, x2
    d9e8:	aa0803e5 	mov	x5, x8
    d9ec:	b5000668 	cbnz	x8, dab8 <__modti3+0x2c8>
    d9f0:	cb020020 	sub	x0, x1, x2
    d9f4:	d360fc49 	lsr	x9, x2, #32
    d9f8:	92407c4a 	and	x10, x2, #0xffffffff
    d9fc:	9ac90801 	udiv	x1, x0, x9
    da00:	9b098020 	msub	x0, x1, x9, x0
    da04:	9b0a7c21 	mul	x1, x1, x10
    da08:	93c78000 	extr	x0, x0, x7, #32
    da0c:	eb00003f 	cmp	x1, x0
    da10:	540000a9 	b.ls	da24 <__modti3+0x234>  // b.plast
    da14:	ab000040 	adds	x0, x2, x0
    da18:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    da1c:	8b020003 	add	x3, x0, x2
    da20:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    da24:	cb010001 	sub	x1, x0, x1
    da28:	9ac90820 	udiv	x0, x1, x9
    da2c:	9b098403 	msub	x3, x0, x9, x1
    da30:	aa0703e1 	mov	x1, x7
    da34:	9b0a7c00 	mul	x0, x0, x10
    da38:	b3607c61 	bfi	x1, x3, #32, #32
    da3c:	eb01001f 	cmp	x0, x1
    da40:	540000a9 	b.ls	da54 <__modti3+0x264>  // b.plast
    da44:	ab010041 	adds	x1, x2, x1
    da48:	8b020022 	add	x2, x1, x2
    da4c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    da50:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    da54:	cb000020 	sub	x0, x1, x0
    da58:	17ffff91 	b	d89c <__modti3+0xac>
    da5c:	eb0203e5 	negs	x5, x2
    da60:	aa0003e7 	mov	x7, x0
    da64:	da0303e8 	ngc	x8, x3
    da68:	aa0503e2 	mov	x2, x5
    da6c:	aa0803e3 	mov	x3, x8
    da70:	aa0103e6 	mov	x6, x1
    da74:	b4ffed48 	cbz	x8, d81c <__modti3+0x2c>
    da78:	eb01011f 	cmp	x8, x1
    da7c:	54fff148 	b.hi	d8a4 <__modti3+0xb4>  // b.pmore
    da80:	dac01109 	clz	x9, x8
    da84:	2a0903e6 	mov	w6, w9
    da88:	b5fff1c9 	cbnz	x9, d8c0 <__modti3+0xd0>
    da8c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    da90:	54000068 	b.hi	da9c <__modti3+0x2ac>  // b.pmore
    da94:	eb050007 	subs	x7, x0, x5
    da98:	da080021 	sbc	x1, x1, x8
    da9c:	aa0703e0 	mov	x0, x7
    daa0:	17ffff81 	b	d8a4 <__modti3+0xb4>
    daa4:	ab000040 	adds	x0, x2, x0
    daa8:	8b020002 	add	x2, x0, x2
    daac:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    dab0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    dab4:	17ffff79 	b	d898 <__modti3+0xa8>
    dab8:	9ac82042 	lsl	x2, x2, x8
    dabc:	d2800803 	mov	x3, #0x40                  	// #64
    dac0:	cb080063 	sub	x3, x3, x8
    dac4:	d360fc49 	lsr	x9, x2, #32
    dac8:	9ac82027 	lsl	x7, x1, x8
    dacc:	92407c4a 	and	x10, x2, #0xffffffff
    dad0:	9ac32426 	lsr	x6, x1, x3
    dad4:	9ac32403 	lsr	x3, x0, x3
    dad8:	aa070063 	orr	x3, x3, x7
    dadc:	9ac908c1 	udiv	x1, x6, x9
    dae0:	9ac82007 	lsl	x7, x0, x8
    dae4:	9b099820 	msub	x0, x1, x9, x6
    dae8:	9b017d41 	mul	x1, x10, x1
    daec:	93c38000 	extr	x0, x0, x3, #32
    daf0:	eb00003f 	cmp	x1, x0
    daf4:	540000a9 	b.ls	db08 <__modti3+0x318>  // b.plast
    daf8:	ab000040 	adds	x0, x2, x0
    dafc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    db00:	8b020006 	add	x6, x0, x2
    db04:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    db08:	cb010000 	sub	x0, x0, x1
    db0c:	9ac90801 	udiv	x1, x0, x9
    db10:	9b098026 	msub	x6, x1, x9, x0
    db14:	aa0303e0 	mov	x0, x3
    db18:	9b017d41 	mul	x1, x10, x1
    db1c:	b3607cc0 	bfi	x0, x6, #32, #32
    db20:	eb00003f 	cmp	x1, x0
    db24:	540000a9 	b.ls	db38 <__modti3+0x348>  // b.plast
    db28:	ab000040 	adds	x0, x2, x0
    db2c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    db30:	8b020003 	add	x3, x0, x2
    db34:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    db38:	cb010000 	sub	x0, x0, x1
    db3c:	17ffffb0 	b	d9fc <__modti3+0x20c>
    db40:	d1000969 	sub	x9, x11, #0x2
    db44:	8b070021 	add	x1, x1, x7
    db48:	17ffff83 	b	d954 <__modti3+0x164>
    db4c:	d1000965 	sub	x5, x11, #0x2
    db50:	8b070063 	add	x3, x3, x7
    db54:	17ffff74 	b	d924 <__modti3+0x134>
    db58:	d503201f 	nop
    db5c:	d503201f 	nop

000000000000db60 <atexit>:
    db60:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    db64:	f0000082 	adrp	x2, 20000 <__data_start>
    db68:	d2800001 	mov	x1, #0x0                   	// #0
    db6c:	910003fd 	mov	x29, sp
    db70:	a8c17bfd 	ldp	x29, x30, [sp], #16
    db74:	f9400442 	ldr	x2, [x2, #8]
    db78:	17ffd302 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000db7c <_fini>:
    db7c:	d503201f 	nop
    db80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    db84:	910003fd 	mov	x29, sp
    db88:	a8c17bfd 	ldp	x29, x30, [sp], #16
    db8c:	d65f03c0 	ret
